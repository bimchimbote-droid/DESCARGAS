using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Una misma retícula para iconos, textos y pies de todos los grupos de la vista.</summary>
internal static class MYGVistaPreliminarCintaDiseno
{
    internal static Panel Grupo(FlowLayoutPanel padre, string titulo, int ancho)
    {
        var grupo = new GrupoPanel(titulo, ancho);
        padre.Controls.Add(grupo);
        return grupo;
    }

    internal static ToolStrip Fila(Panel grupo, int y, params ToolStripItem[] items) => Fila(grupo, 4, y, items);
    internal static ToolStrip Fila(Panel grupo, int x, int y, params ToolStripItem[] items)
    {
        var fila = new FilaPreliminar
        {
            Dock = DockStyle.None, AutoSize = false, GripStyle = ToolStripGripStyle.Hidden,
            CanOverflow = false, Padding = Padding.Empty, Margin = Padding.Empty,
            BackColor = Color.Transparent,
            LayoutStyle = ToolStripLayoutStyle.HorizontalStackWithOverflow
        };
        fila.Items.AddRange(items);
        grupo.Controls.Add(fila);
        ((GrupoPanel)grupo).Agregar(fila, x, y);
        return fila;
    }

    internal sealed class GrupoPanel : Panel
    {
        private readonly Label pie;
        private readonly List<(ToolStrip Fila, int X, int Y)> filas = new();
        private bool ajustando;
        internal int SeparadorY => Height - pie.Height;
        internal Label Pie => pie;

        internal GrupoPanel(string titulo, int ancho)
        {
            Name = "vista_grupo_" + titulo;
            Size = new Size(ancho, 112); Margin = Padding.Empty; Padding = Padding.Empty;
            BackColor = MYGEspecificacionesCinta.AzulFondo;
            ForeColor = MYGEspecificacionesCinta.Texto;
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            pie = new Label { Name = "vista_etiqueta_" + titulo, Text = titulo, Dock = DockStyle.Bottom,
                Height = 24, AutoEllipsis = false, TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent, ForeColor = MYGEspecificacionesCinta.Texto };
            Controls.Add(pie);
        }

        internal void Agregar(ToolStrip fila, int x, int y)
        {
            filas.Add((fila, x, y));
            fila.HandleCreated += (_, _) => Recalcular();
            fila.DpiChangedAfterParent += (_, _) => Recalcular();
            fila.FontChanged += (_, _) => Recalcular();
            Recalcular();
        }

        internal void Recalcular()
        {
            if (ajustando || pie == null) return;
            ajustando = true;
            try
            {
                float factor = DeviceDpi / 96f;
                int P(float valor) => (int)Math.Ceiling(valor * factor);
                Height = P(112); pie.Height = P(24);
                int anchoGrupo = P(12);
                using var contexto = CreateGraphics();
                foreach (var row in filas)
                {
                    int ancho = 0, alto = P(32);
                    foreach (ToolStripItem item in row.Fila.Items)
                    {
                        bool pequeno = item.DisplayStyle == ToolStripItemDisplayStyle.Image;
                        int icono = pequeno ? 24 : 32;
                        if (item.Tag is string id && item.Image?.Width != P(icono))
                            MYGEspecificacionesCinta.Icono(item, id, MYGVistaPreliminarCintaIconos.Dibujar, icono, !pequeno);
                        int texto = item.Text.Split('\n').Select(linea => TextRenderer.MeasureText(contexto, linea,
                            item.Font, Size.Empty, TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix).Width).DefaultIfEmpty().Max();
                        int flecha = item is ToolStripDropDownButton ? P(14) : 0;
                        item.AutoSize = false; item.Margin = Padding.Empty;
                        item.Size = new Size(pequeno ? P(32) : Math.Max(P(56), texto + P(12) + flecha), P(pequeno ? 32 : 80));
                        ancho += item.Width; alto = Math.Max(alto, item.Height);
                    }
                    row.Fila.Location = new Point(P(row.X), P(row.Y));
                    row.Fila.Size = new Size(ancho, alto);
                    anchoGrupo = Math.Max(anchoGrupo, row.Fila.Right + P(4));
                }
                int anchoPie = TextRenderer.MeasureText(contexto, pie.Text, pie.Font, Size.Empty,
                    TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix).Width + P(12);
                Width = Math.Max(anchoGrupo, anchoPie);
                pie.BringToFront(); Invalidate();
            }
            finally { ajustando = false; }
        }

        protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); Recalcular(); }
        protected override void OnDpiChangedAfterParent(EventArgs e) { base.OnDpiChangedAfterParent(e); Recalcular(); }
        protected override void OnFontChanged(EventArgs e) { base.OnFontChanged(e); Recalcular(); }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using var linea = new Pen(MYGEspecificacionesCinta.AzulBorde);
            int margen = (int)Math.Ceiling(4 * DeviceDpi / 96f);
            e.Graphics.DrawLine(linea, margen, SeparadorY, Width - margen, SeparadorY);
            e.Graphics.DrawLine(linea, Width - 1, margen, Width - 1, Height - margen);
        }
    }

    private sealed class FilaPreliminar : ToolStrip
    {
        private readonly ToolStripRenderer renderer = new Renderer();
        private bool restaurando;
        internal FilaPreliminar() => Renderer = renderer;
        protected override void OnRendererChanged(EventArgs e)
        {
            base.OnRendererChanged(e);
            // El tema global puede asignar otro renderer al abrir o alternar la
            // apariencia. Esta cinta conserva su retícula, usando los colores del tema.
            if (restaurando || renderer == null || ReferenceEquals(Renderer, renderer)) return;
            restaurando = true;
            try { Renderer = renderer; }
            finally { restaurando = false; }
        }
    }

    private sealed class Renderer : ToolStripProfessionalRenderer
    {
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
        { if (e.ToolStrip is ToolStripDropDown) base.OnRenderToolStripBorder(e); }
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        { if (e.ToolStrip is ToolStripDropDown) base.OnRenderToolStripBackground(e); }
        protected override void OnRenderItemImage(ToolStripItemImageRenderEventArgs e)
        {
            if (e.ToolStrip is ToolStripDropDown) { base.OnRenderItemImage(e); return; }
            if (e.Image == null) return;
            float factor = e.ToolStrip.DeviceDpi / 96f;
            bool pequeno = e.Item.DisplayStyle == ToolStripItemDisplayStyle.Image;
            int lado = (int)Math.Ceiling((pequeno ? 24 : 32) * factor);
            var rectangulo = new Rectangle((e.Item.Width - lado) / 2, (int)Math.Ceiling(4 * factor), lado, lado);
            if (e.Item.Tag is string id)
            {
                using var imagen = MYGVistaPreliminarCintaIconos.Dibujar(id, lado, e.Item.Selected);
                if (e.Item.Enabled) e.Graphics.DrawImageUnscaled(imagen, rectangulo.Location);
                else ControlPaint.DrawImageDisabled(e.Graphics, imagen, rectangulo.X, rectangulo.Y, e.ToolStrip.BackColor);
            }
            else base.OnRenderItemImage(new ToolStripItemImageRenderEventArgs(e.Graphics, e.Item, e.Image, rectangulo));
        }
        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            if (e.ToolStrip is ToolStripDropDown) { base.OnRenderItemText(e); return; }
            float factor = e.ToolStrip.DeviceDpi / 96f;
            bool menu = e.Item is ToolStripDropDownButton;
            int margen = (int)Math.Ceiling(4 * factor), flecha = menu ? (int)Math.Ceiling(14 * factor) : 0;
            int y = (int)Math.Ceiling(42 * factor);
            var area = new Rectangle(margen, y, e.Item.Width - 2 * margen - flecha, e.Item.Height - y - margen);
            TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, area,
                e.Item.Enabled ? MYGEspecificacionesCinta.Texto : SystemColors.GrayText,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.Top | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
        }
        protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
        {
            if (e.Item.Owner is ToolStripDropDown) { base.OnRenderArrow(e); return; }
            int dpi = e.Item.Owner?.DeviceDpi ?? 96;
            int lado = (int)Math.Ceiling(4 * dpi / 96f);
            int x = e.Item.Width - lado * 2, y = (int)Math.Ceiling(49 * dpi / 96f);
            using var tinta = new SolidBrush(e.Item.Enabled ? MYGEspecificacionesCinta.Texto : SystemColors.GrayText);
            e.Graphics.FillPolygon(tinta, new[] { new Point(x - lado, y), new Point(x + lado, y), new Point(x, y + lado) });
        }
    }
}
