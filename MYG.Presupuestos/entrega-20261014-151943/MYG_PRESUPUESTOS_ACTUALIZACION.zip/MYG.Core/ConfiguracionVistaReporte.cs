using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

/// <summary>Configuración temporal de la vista previa. Conserva los datos del proyecto
/// y las dependencias de las fórmulas en instantáneas independientes.</summary>
public sealed class MYGConfiguracionVistaReporte
{
    private readonly IReadOnlyList<MYGHojaReporteProyecto> originales;
    private float escala = 1f;

    public IReadOnlyList<MYGHojaReporteProyecto> Reportes { get; private set; }

    /// <summary>Escala del contenido impreso; el zoom de la vista previa es independiente.</summary>
    public float Escala
    {
        get => escala;
        set
        {
            if (!float.IsFinite(value) || value < .25f || value > 2f)
                throw new ArgumentOutOfRangeException(nameof(value), "La escala debe estar entre 25 % y 200 %.");
            escala = value;
        }
    }

    public MYGConfiguracionVistaReporte(IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        ArgumentNullException.ThrowIfNull(reportes);
        if (reportes.Count == 0 || reportes.Any(r => r == null || r.Hoja == null))
            throw new ArgumentException("Seleccione al menos un reporte válido para la vista previa.", nameof(reportes));
        originales = Copiar(reportes);
        Reportes = Copiar(originales);
    }

    /// <summary>Aplica papel, orientación y márgenes en pulgadas a todas las hojas.
    /// Valida toda la configuración antes de cambiar cualquier hoja.</summary>
    public void ConfigurarPagina(string papel, string orientacion,
        decimal izq, decimal der, decimal sup, decimal inf)
    {
        (decimal Ancho, decimal Alto) tamano = papel switch
        {
            "A4" => (8.27m, 11.69m), "A3" => (11.69m, 16.54m),
            "Carta" => (8.5m, 11m), "Oficio" => (8.5m, 14m),
            _ => throw new ArgumentException("Seleccione papel A4, A3, Carta u Oficio.", nameof(papel))
        };
        if (orientacion is not ("Vertical" or "Horizontal"))
            throw new ArgumentException("Seleccione orientación Vertical u Horizontal.", nameof(orientacion));
        if (new[] { izq, der, sup, inf }.Any(m => m < 0 || m > 3))
            throw new ArgumentOutOfRangeException(nameof(izq), "Los márgenes deben estar entre 0 y 3 pulgadas.");
        if (orientacion == "Horizontal") tamano = (tamano.Alto, tamano.Ancho);
        if (tamano.Ancho - izq - der <= .4m || tamano.Alto - sup - inf <= .5m)
            throw new ArgumentException("Los márgenes dejan un área de impresión demasiado pequeña.");
        foreach (var reporte in Reportes)
        {
            var hoja = reporte.Hoja;
            hoja.TamanoPapel = papel; hoja.OrientacionPagina = orientacion;
            hoja.MargenIzquierdo = izq; hoja.MargenDerecho = der;
            hoja.MargenSuperior = sup; hoja.MargenInferior = inf;
        }
    }

    /// <summary>Cambia sólo la familia tipográfica; conserva tamaños, estilos y fórmulas.</summary>
    public void Fuente(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre) || nombre.Length > 100 || nombre.Any(char.IsControl))
            throw new ArgumentException("Seleccione una fuente válida de hasta 100 caracteres.", nameof(nombre));
        nombre = nombre.Trim();
        foreach (var reporte in Reportes)
            foreach (var celda in reporte.Hoja.Celdas.Values) celda.Fuente = nombre;
    }

    public void Restaurar()
    {
        var restaurados = Copiar(originales);
        Reportes = restaurados;
        escala = 1f;
    }

    private static IReadOnlyList<MYGHojaReporteProyecto> Copiar(IReadOnlyList<MYGHojaReporteProyecto> origen)
    {
        var copias = origen.Select(r => new MYGHojaReporteProyecto(r.Titulo, MYGProyectoStorage.Copia(r.Hoja), r.DatosProyecto)).ToArray();
        var hojas = new Dictionary<MYGHojaMetrado, MYGHojaMetrado>(ReferenceEqualityComparer.Instance);
        for (int i = 0; i < origen.Count; i++) hojas.TryAdd(origen[i].Hoja, copias[i].Hoja);

        // Copiar una hoja conserva su contexto para evaluar METRADO. También se
        // congelan las dependencias que no aparecen entre los reportes visibles.
        var presupuestos = new Dictionary<MYGPresupuestoDocumento, MYGPresupuestoDocumento>(ReferenceEqualityComparer.Instance);
        foreach (var reporte in origen)
            foreach (var presupuesto in reporte.Hoja.ContextoReferencias?.Presupuestos ?? Array.Empty<MYGPresupuestoDocumento>())
                if (!presupuestos.ContainsKey(presupuesto)) presupuestos.Add(presupuesto, MYGProyectoStorage.Copia(presupuesto));
        MYGReferenciasMetrado.Vincular(presupuestos.Values);

        for (int n = 0; n < origen.Count; n++)
        {
            var contextoOrigen = origen[n].Hoja.ContextoReferencias;
            if (contextoOrigen == null) continue;
            var contexto = new MYGContextoReferenciasMetrado(contextoOrigen.Presupuestos.Select(p => presupuestos[p]), aislado: true);
            foreach (var presupuesto in contextoOrigen.Presupuestos)
                foreach (var partida in presupuesto.Items ?? new())
                {
                    if (partida == null) continue;
                    var hoja = contextoOrigen.Hoja(presupuesto.Id, partida.IdLocalMYG ?? partida.Id);
                    if (hoja == null || ReferenceEquals(hoja, partida.Costos?.Hoja)) continue;
                    if (!hojas.TryGetValue(hoja, out var copia)) hojas.Add(hoja, copia = MYGProyectoStorage.Copia(hoja));
                    contexto = contexto.ConHoja(copia);
                }
            // Las fórmulas entre reportes usan las copias del mismo conjunto.
            for (int i = 0; i < origen.Count; i++)
                if (origen[i].Hoja.ContextoReferencias?.Presupuestos.Any(p => contextoOrigen.Presupuestos.Contains(p)) == true)
                    contexto = contexto.ConHoja(copias[i].Hoja);
            copias[n].Hoja.ContextoReferencias = contexto;
        }
        foreach (var reporte in copias) MYGHojaCalculo.Validar(reporte.Hoja);
        return Array.AsReadOnly(copias);
    }
}
