using System.Globalization;
using MYG_2027;

internal static class EscrituraSqlS10Check
{
    internal static void Ejecutar(Action<string> pasa)
    {
        PerfilYObligatorias();
        pasa("SQL S10 usa columnas reales y su nulabilidad, identidad y valores predeterminados, sin inventar datos obligatorios");
        TextoEInyeccion();
        pasa("SQL S10 escapa texto y variables tipadas, exige identificadores del perfil y valida Windows1252 y UTF16 sin sustitución ni truncado");
        DescripcionesCompatibles();
        pasa("SQL S10 adapta símbolos conocidos y acentos Unicode sólo al solicitarlo, conserva ASCII y acentos compatibles y valida la longitud después de convertir");
        DescripcionesLargas();
        pasa("SQL S10 ajusta descripciones extensas sólo cuando puede conservar el original, mide bytes1252 y valida el texto completo antes de reducirlo");
        UnicodeNoAdmitido();
        pasa("SQL S10 identifica en español los caracteres no admitidos sin ocultarlos con signos de interrogación ni alterar códigos, unidades o texto Unicode nativo");
        NumerosYFechas();
        pasa("SQL S10 conserva precisión y escala, rechaza conversiones numéricas con pérdida y emite fechas y GUID compatibles con SQL Server2005");
    }

    private static void PerfilYObligatorias()
    {
        var unidad = MYGSqlS10.Tabla("Unidad");
        Exige(unidad.NombreSql == "[dbo].[Unidad]" && !unidad.Columna("CodUnidad").PermiteNull
            && unidad.Columna("Descripcion").PermiteNull && unidad.Columna("CodUnidad").Longitud == 3,
            "El perfil debe respetar status&1 como NOT NULL y conservar la longitud nativa de códigos.");
        Exige(MYGSqlS10.Tabla("Presupuesto").Columna("Fecha").PermiteNull,
            "Las columnas status0 deben admitir NULL; no deben llenarse con fechas o ceros arbitrarios.");
        string insert = MYGSqlS10.Insertar("Unidad", new Dictionary<string, object> { ["CodUnidad"] = "001" });
        Exige(insert == "INSERT INTO [dbo].[Unidad] ([CodUnidad]) VALUES (N'001');",
            "Omitir columnas opcionales/predeterminadas debe producir un INSERT mínimo sobre tablas nativas.");
        Rechaza(() => MYGSqlS10.Insertar("Unidad", new Dictionary<string, object> { ["Descripcion"] = "Metros" }), "CodUnidad");
        Rechaza(() => MYGSqlS10.Insertar("Unidad", new Dictionary<string, object> { ["CodUnidad"] = null }), "NULL");
        Exige(MYGSqlS10.Literal("Unidad", "Descripcion", null) == "NULL", "Una columna nullable debe admitir NULL explícito.");
        var insumo = MYGSqlS10.Tabla("Insumo");
        Exige(insumo.Columna("OID").Identidad, "OID debe reconocerse como identidad nativa.");
        Rechaza(() => MYGSqlS10.Insertar("Insumo", new Dictionary<string, object>
        { ["CodInsumo"] = "MAT00001", ["Nivel"] = 1, ["Descripcion"] = "Material", ["OID"] = 2 }), "generada");
        var partida = MYGSqlS10.Tabla("Partida");
        Exige(partida.Columna("CodPresupuesto").TienePredeterminado && !partida.Columna("CodPresupuesto").PermiteNull,
            "El perfil debe distinguir el valor predeterminado de la nulabilidad sin copiar el ID privado de su restricción.");
        string conDefecto = MYGSqlS10.Insertar("Partida", new Dictionary<string, object>
        { ["CodPartida"] = "P00001", ["Nivel"] = 1, ["Descripcion"] = "Partida" });
        Exige(!conDefecto.Contains("[CodPresupuesto]", StringComparison.Ordinal),
            "Un valor predeterminado conocido sólo por su existencia debe omitirse, no inventarse ni sustituirse por NULL.");
    }

    private static void TextoEInyeccion()
    {
        string dato = "O'Brien'); DELETE FROM Usuario;--\nNiño áéíóú µ²";
        string literal = MYGSqlS10.Literal("Unidad", "Descripcion", dato);
        Exige(literal == "N'" + dato.Replace("'", "''") + "'", "Las comillas de datos deben duplicarse incluso con saltos de línea.");
        string insert = MYGSqlS10.Insertar("Unidad", new Dictionary<string, object>
        { ["Descripcion"] = dato, ["CodUnidad"] = "001" });
        Exige(ContarSentencias(insert) == 1, "Un valor con SQL aparente debe seguir dentro de un único INSERT.");
        Exige(MYGSqlS10.Literal("Unidad", "Descripcion", new string('ñ', 50)).Length > 50,
            "Windows1252 debe medir bytes del destino, no los dos bytes UTF8 de cada letra española.");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", new string('a', 51)), "truncar");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", "Obra 😀"));
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", "Obra\0oculta"), "nulo");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion", "e\u0301"));
        Exige(MYGSqlS10.Literal("Insumo", "RR", "😀") == "N'😀'",
            "NVARCHAR debe contar unidades UTF16 válidas; un par sustituto completo ocupa cuatro bytes.");
        Rechaza(() => MYGSqlS10.Literal("Insumo", "RR", "😀X"), "truncar");
        Rechaza(() => MYGSqlS10.Literal("Insumo", "RR", "\ud800"));
        Rechaza(() => MYGSqlS10.Tabla("Unidad]; DELETE FROM Usuario;--"));
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Descripcion]", "texto"));
        Rechaza(() => MYGSqlS10.Insertar("Unidad", new Dictionary<string, object>
        { ["CodUnidad"] = "001", ["codunidad"] = "002" }), "duplicada");

        var variable = new MYGVariableSqlS10("@Unidad0001");
        Exige(MYGSqlS10.Literal("Unidad", "CodUnidad", variable) == "@Unidad0001"
            && MYGSqlS10.Literal("Unidad", "CodUnidad", "@U") == "N'@U'",
            "Sólo una referencia tipada del generador puede convertirse en variable; el texto del usuario sigue siendo un literal.");
        Rechaza(() => new MYGVariableSqlS10("@U; DROP TABLE Unidad"));
        Rechaza(() => new MYGVariableSqlS10("@@VERSION"));
        Rechaza(() => new MYGVariableSqlS10("U"));
    }

    private static void DescripcionesCompatibles()
    {
        var avisos = new List<string>();
        const string original = "Diámetro ≈ 3; a ≤ b ≥ c ≠ d − e";
        string adaptado = MYGSqlS10.AdaptarDescripcion("Insumo", original, avisos.Add);
        Exige(adaptado == "Diámetro aprox. 3; a <= b >= c <> d - e"
            && avisos.Count > 0 && avisos.Any(a => a.Contains("≈", StringComparison.Ordinal) && a.Contains("aprox.", StringComparison.Ordinal)),
            "La adaptación debe usar equivalentes legibles y comunicar el cambio del símbolo que provocaba el error.");
        Exige(MYGSqlS10.AdaptarDescripcion("Partida", "˂ ˃ ː ❴ ❵ ⟩ ⟨ │ ; ？ ˋ ∼") == "< > : { } ] [ | ; ? ` ~",
            "Las variantes Unicode usadas por los reemplazos del usuario deben volver a sus signos compatibles con S10.");
        avisos.Clear();
        const string valido = "áéíóú ñ Ñ Ø µ²³ < > : { } ] [ | ; ? ` ~ O'Brien\r\ntexto\tfinal";
        Exige(MYGSqlS10.AdaptarDescripcion("Insumo", valido, avisos.Add) == valido && avisos.Count == 0,
            "La adaptación no debe alterar acentos válidos, puntuación ASCII ni saltos de línea que ya pueden guardarse como datos SQL.");
        Exige(MYGSqlS10.AdaptarDescripcion("Partida", "cafe\u0301") == "café",
            "Los acentos descompuestos deben componerse con NFC, conservando la letra acentuada.");
        Exige(MYGSqlS10.AdaptarDescripcion("Unidad", new string('a', 44) + "≈").Length == 50,
            "La expansión exacta al límite de la columna debe conservarse completa.");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Unidad", new string('a', 45) + "≈"), "truncar");
        string inyeccion = MYGSqlS10.AdaptarDescripcion("Partida", "≈ O'Brien'); DELETE FROM Usuario;--");
        string sql = MYGSqlS10.Insertar("Partida", new Dictionary<string, object>
        { ["CodPartida"] = "P00001", ["Nivel"] = 1, ["Descripcion"] = inyeccion });
        Exige(ContarSentencias(sql) == 1 && sql.Contains("O''Brien", StringComparison.Ordinal),
            "Adaptar símbolos debe preceder al escape SQL y nunca convertir datos en instrucciones.");
    }

    private static void UnicodeNoAdmitido()
    {
        Rechaza(() => MYGSqlS10.Literal("Insumo", "Descripcion", "≈"), "U+2248");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Simbolo", "≈"), "U+2248");
        Rechaza(() => MYGSqlS10.Literal("Insumo", "CodInsumoAnterior", "˂"), "U+02C2");
        Rechaza(() => MYGSqlS10.Literal("PieSubpresupuesto", "Formula", "≈"), "U+2248");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Insumo", "Material 😀"), "U+1F600");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Insumo", "Material 😀"), "Insumo.Descripcion");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Partida", "Unicode incompleto \ud800"), "Unicode");
        Exige(MYGSqlS10.Literal("Insumo", "RR", "😀") == "N'😀'",
            "La validación de campos varchar no debe modificar columnas Unicode del esquema nativo.");
    }

    private static void DescripcionesLargas()
    {
        const string porcelanato = "PORCELANATO NO ESMALTADO/RECTIFICADO MATE 60x120 cm, e=10.5 mm, GRIS CENIZA, TIPO PIEDRA, ANTIDESLIZANTE R10, TRÁFICO ALTO";
        Exige(porcelanato.Length == 122, "El caso debe reproducir los122bytes de la captura del usuario.");
        var conservados = new List<MYGDescripcionLargaS10>();
        var avisos = new List<string>();
        string reducido = MYGSqlS10.AdaptarDescripcion("Insumo", porcelanato, avisos.Add, conservados.Add);
        Exige(reducido.Length <= 120 && reducido.Replace(" ", "") == porcelanato.Replace(" ", ""),
            "El exceso de dos bytes debe poder resolverse compactando espacios sin perder las dimensiones ni el acabado del porcelanato.");
        Exige(conservados.Count == 1 && conservados[0].Tabla == "Insumo"
            && conservados[0].Original == porcelanato && conservados[0].AdaptadoCompleto == porcelanato
            && conservados[0].TextoS10 == reducido && conservados[0].LimiteBytes == 120
            && avisos.Any(a => a.Contains("Insumo.Descripcion", StringComparison.Ordinal) && a.Contains("120", StringComparison.Ordinal)),
            "Una descripción ajustada debe conservar su original completo y comunicar el campo y su límite nativo.");

        conservados.Clear(); avisos.Clear();
        string exacto = new string('ñ', 120);
        Exige(MYGSqlS10.AdaptarDescripcion("Insumo", exacto, avisos.Add, conservados.Add) == exacto
            && conservados.Count == 0 && avisos.Count == 0,
            "Ciento veinte eñes ocupan120bytes1252 y deben permanecer completas, aunque UTF8 las almacene con más bytes.");
        string largo = new string('ñ', 121);
        reducido = MYGSqlS10.AdaptarDescripcion("Insumo", largo, avisos.Add, conservados.Add);
        Exige(reducido.Length <= 120 && reducido.EndsWith("...", StringComparison.Ordinal)
            && conservados.Single().Original == largo,
            "Si no basta con compactar espacios, la versión reducida debe mostrar una marca y conservar todas las letras originales.");

        conservados.Clear();
        string expansion = new string('a', 115) + "≈";
        reducido = MYGSqlS10.AdaptarDescripcion("Insumo", expansion, null, conservados.Add);
        Exige(reducido.Length <= 120 && conservados.Single().Original == expansion
            && conservados[0].AdaptadoCompleto == new string('a', 115) + "aprox.",
            "El límite debe aplicarse después de expandir símbolos, conservando tanto el texto original como el adaptado completo.");

        conservados.Clear();
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Insumo", new string('a', 200) + "😀", null, conservados.Add), "U+1F600");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Insumo", new string('a', 200) + "\0", null, conservados.Add), "nulo");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Insumo", new string('a', 200) + "\ud800", null, conservados.Add), "Unicode");
        Exige(conservados.Count == 0, "Los caracteres incompatibles después del límite no deben desaparecer por el recorte.");
        Rechaza(() => MYGSqlS10.AdaptarDescripcion("Insumo", largo), "truncar");
        Rechaza(() => MYGSqlS10.Literal("Insumo", "CodInsumoAnterior", new string('a', 121)), "truncar");
        Rechaza(() => MYGSqlS10.Literal("Unidad", "Simbolo", new string('a', 9)), "truncar");
        Rechaza(() => MYGSqlS10.Literal("PieSubpresupuesto", "Formula", new string('a', 121)), "truncar");
    }

    private static void NumerosYFechas()
    {
        var anterior = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = new CultureInfo("es-PE");
            Exige(MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", -1234.125m) == "-1234.125",
                "Un decimal debe conservar el punto invariante y no tener separadores de miles.");
            Exige(MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", 1.23000000000000m) == "1.23",
                "Eliminar ceros finales es exacto; no debe rechazarse un valor equivalente con escala interna mayor.");
            Rechaza(() => MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", .00000000000001m), "redondear");
            Rechaza(() => MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", 10000000000000000m), "supera");
            Rechaza(() => MYGSqlS10.Literal("PresupuestoPartidaAnalisis", "Cantidad", 1.2d), "exacto");
            Exige(MYGSqlS10.Literal("Presupuesto", "Nivel", short.MaxValue) == "32767", "Un smallint límite debe conservarse.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Nivel", 32768), "entero");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Nivel", 1.5m), "entero");
            Exige(MYGSqlS10.Literal("Unidad", "TieneNota", true) == "1", "El bit debe emitirse como valor numérico SQL.");
            Rechaza(() => MYGSqlS10.Literal("Unidad", "TieneNota", 2));
            Exige(MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .5m) == "CONVERT(real,N'0.5')",
                "Un decimal binario exacto puede representarse en real sin pérdida.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .1m), "exacta");
            Exige(MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .1f).StartsWith("CONVERT(real,"),
                "Un float ya elegido explícitamente puede conservarse como aproximado nativo.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", double.NaN));
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", double.PositiveInfinity));
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "PorcentajeGG", .1d), "precisión");

            Exige(MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(2024, 2, 29)) == "CONVERT(datetime,N'20240229',112)",
                "La fecha debe usar formato112 independiente del idioma del servidor SQL2005.");
            Exige(MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(2024, 2, 29, 14, 3, 0, 123)) ==
                "CONVERT(datetime,N'2024-02-29T14:03:00.123',126)", "Una fecha con hora debe usar formato126 canónico.");
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(1600, 1, 1)));
            Rechaza(() => MYGSqlS10.Literal("Presupuesto", "Fecha", new DateTime(2024, 1, 1).AddTicks(1)), "precisión");
            Guid id = Guid.Parse("ee2d90b7-232f-471e-b9ce-ceb9629b8cd4");
            Exige(MYGSqlS10.Literal("Partida", "NroPartida", id) == "CONVERT(uniqueidentifier,N'ee2d90b7-232f-471e-b9ce-ceb9629b8cd4')",
                "Los GUID deben emitirse con tipoSQL sin concatenar contenido arbitrario.");
            Rechaza(() => MYGSqlS10.Literal("Partida", "NroPartida", "x'); DROP TABLE Partida;--"));
        }
        finally { CultureInfo.CurrentCulture = anterior; }
    }

    private static int ContarSentencias(string sql)
    {
        bool cadena = false; int cantidad = 0;
        for (int i = 0; i < sql.Length; i++)
            if (sql[i] == '\'')
            {
                if (cadena && i + 1 < sql.Length && sql[i + 1] == '\'') i++;
                else cadena = !cadena;
            }
            else if (sql[i] == ';' && !cadena) cantidad++;
        Exige(!cadena, "Las cadenas SQL deben terminar dentro de sus propios límites.");
        return cantidad;
    }

    private static void Rechaza(Action accion, string detalle = null)
    {
        try { accion(); }
        catch (InvalidDataException ex)
        {
            Exige(detalle == null || ex.Message.Contains(detalle, StringComparison.OrdinalIgnoreCase),
                "El error debe explicar el dato incompatible: " + detalle + ". Error real: " + ex.Message);
            return;
        }
        throw new Exception("El emisor SQL debió rechazar un dato incompatible.");
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
}
