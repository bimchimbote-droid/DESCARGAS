using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using MYG_2027;

internal static class ExportacionS10SqlCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        RelacionesYTotales();
        pasa("Exportación S10 conserva títulos, metrados, análisis agrupados y subpartidas; representa el precio directo con un insumo equivalente");
        PorcentajeManoObra();
        pasa("Exportación S10 convierte el porcentaje de mano de obra a la fracción nativa sin cambiar el parcial del análisis");
        AlcanceEInstantanea();
        pasa("Exportación S10 respeta la selección o el proyecto completo, omite insumos no usados y no modifica el documento abierto");
        TextoYTransaccion();
        pasa("Exportación S10 mantiene texto español y comillas dentro de datos; genera una transacción con reversión y no modifica registros existentes");
        DescripcionesUnicode();
        pasa("Exportación S10 adapta descripciones Unicode en presupuesto, títulos, partidas, insumos y pie, informa los cambios y conserva el proyecto original");
        DescripcionesLargas();
        pasa("Exportación S10 ajusta descripciones al límite nativo sin bloquear el presupuesto y conserva los originales en comentarios JSON seguros y los importes intactos");
        ErrorUnicodeYDestino();
        pasa("Exportación S10 localiza caracteres sin equivalente, mantiene códigos y unidades estrictos y conserva el SQL anterior si un texto no puede exportarse");
        LimitesYDecimales();
        pasa("Exportación S10 conserva metrados y parciales con cultura española y rechaza códigos, nombres, moneda, ubicación y números incompatibles");
        ArchivoAtomico();
        pasa("Exportación S10 escribe SQL UTF8 y conserva el archivo anterior cuando falla la validación, sin residuos temporales");
    }

    private static void PorcentajeManoObra()
    {
        var d = MYGProyectoStorage.Nuevo("Porcentaje S10"); var p = d.Presupuestos.Single();
        var mo = new MYGInsumo { Codigo = "MO", Descripcion = "Operario", Grupo = MYGGrupoRecurso.ManoObra, Unidad = "hh", Precio = 10 };
        var herramienta = new MYGInsumo { Codigo = "HERR", Descripcion = "Herramienta porcentual", Grupo = MYGGrupoRecurso.Equipo, Unidad = "%mo", Precio = 1 };
        p.Costos.Insumos.Add(mo); p.Costos.Insumos.Add(herramienta);
        var n = Nodo(p, "01", "Partida con porcentaje"); n.Costos.Cantidad = 1;
        n.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo.Id, Cantidad = 2 });
        n.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Equipo, InsumoId = herramienta.Id, Cantidad = 3, Modo = MYGModoCantidad.PorcentajeManoObra });
        string sql = MYGExportacionS10Sql.CrearDocumento(d, Opciones()).Contenido;
        var insumo = Filas(sql, "Insumo").Single(f => f.GetValueOrDefault("Descripcion") == "Herramienta porcentual");
        var detalle = Filas(sql, "PartidaDetalle").Single(f => f["CodInsumo"] == insumo["CodInsumo"]);
        var partida = Filas(sql, "Partida").Single(f => f.GetValueOrDefault("Descripcion") == "Partida con porcentaje");
        Exige(Numero(detalle, "Cantidad") == .03m && Numero(partida, "Precio1") == 20.60m,
            "El 3% de una mano de obra de20 debe conservar20.60 de precio total usando la fracción .03 del formato nativo.");
    }

    // También permite que la comprobación con el parser oficial de SQL Server
    // use un lote representativo, sin datos de las bases privadas del usuario.
    internal static string DocumentoRepresentativo() => MYGExportacionS10Sql.CrearDocumento(Proyecto(), Opciones()).Contenido;

    internal static string DocumentoLargoRepresentativo()
    {
        var proyecto = Proyecto(); var opciones = Opciones();
        opciones.Nombre = new string('ñ', 251);
        proyecto.Presupuestos.Single().Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion =
            new string('A', 135) + "\r\nGO\r\nDELETE FROM [dbo].[Usuario]; /* cierre */ --\t O'Brien ≈";
        return MYGExportacionS10Sql.CrearDocumento(proyecto, opciones).Contenido;
    }

    private static void RelacionesYTotales()
    {
        var proyecto = Proyecto();
        var documento = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        var detalle = Filas(documento.Contenido, "SubpresupuestoDetalle");
        Exige(documento.Resultado.Presupuestos == 1 && documento.Resultado.Partidas == 3
            && documento.Resultado.Insumos == 3,
            "Deben exportarse tres partidas y sólo los dos insumos usados más el equivalente del precio directo.");
        Exige(detalle.Count == 4 && detalle[0]["Tipo"] == "5" && detalle.Skip(1).All(f => f["Tipo"] == "1"),
            "S10 debe distinguir el título y las partidas que se pueden reprocesar con su análisis.");
        Exige(detalle.Select(f => f["Item"]).SequenceEqual(new[] { "000000000000001", "000000000000002", "000000000000003", "000000000000004" })
            && detalle.Select(f => f["Orden"]).SequenceEqual(new[] { "01", "01.01", "01.02", "01.03" }),
            "La clave interna de quince dígitos debe mantenerse separada de la numeración visible del presupuesto.");
        Exige(detalle.Skip(1).Sum(f => Numero(f, "Parcial1")) == 111m
            && Numero(detalle.Single(f => f["Orden"] == "01.01"), "Metrado") == 2m
            && Numero(detalle.Single(f => f["Orden"] == "01.01"), "Precio1") == 45m,
            "Metrado, precio y parcial deben conservar el costo directo calculado por MYG, sin sumar la subpartida dos veces.");

        var partidas = Filas(documento.Contenido, "Partida");
        var analisis = Filas(documento.Contenido, "PartidaDetalle");
        var principal = partidas.Single(f => f["Descripcion"] == "Partida compuesta");
        var auxiliar = partidas.Single(f => f["Descripcion"] == "Subpartida auxiliar");
        var directa = partidas.Single(f => f["Descripcion"] == "Precio directo");
        var lineas = analisis.Where(f => f["CodPartida"] == principal["CodPartida"]).ToArray();
        Exige(lineas.Length == 3 && lineas.Count(f => f["Tipo"] == "1") == 2
            && lineas.Single(f => f["Tipo"] == "2")["CodPartidaR"] == auxiliar["CodPartida"]
            && lineas.Single(f => f["Tipo"] == "2")["CodInsumo"] == "9999999999",
            "Los recursos repetidos deben agruparse, y una subpartida debe apuntar a la partida creada usando el discriminador y centinela nativos.");
        Exige(lineas.Any(f => f["Tipo"] == "1" && Numero(f, "Cantidad") == 3m)
            && lineas.Where(f => f["Tipo"] == "1").All(f => f["CodPartidaR"] == "999999999999" && f["CodPresupuestoR"] == "9999999"),
            "Agrupar materiales repetidos debe conservar el coeficiente y las referencias de sistema de un insumo normal.");
        Exige(analisis.Single(f => f["CodPartida"] == directa["CodPartida"])["Cantidad"] == "1"
            && documento.Resultado.Advertencias.Any(a => a.Contains("precio directo", StringComparison.OrdinalIgnoreCase)
                && a.Contains("insumo equivalente", StringComparison.OrdinalIgnoreCase)),
            "Un precio directo debe obtener un análisis equivalente y comunicar al usuario esa representación.");
        Exige(Numero(principal, "Precio1") == 45m && Numero(auxiliar, "Precio1") == 20m && Numero(directa, "Precio1") == 7m,
            "Cada análisis debe conservar el precio unitario calculado para la partida y su subpartida.");
    }

    private static void AlcanceEInstantanea()
    {
        var proyecto = Proyecto();
        var segundo = new MYGPresupuestoDocumento { Item = "02", Nombre = "ALCANCE SEGUNDO", Posicion = 2 };
        proyecto.Presupuestos.Add(segundo);
        Nodo(segundo, "01", "Sólo en segundo").Costos.Cantidad = 4;
        string antes = JsonSerializer.Serialize(proyecto);
        var opciones = Opciones(); opciones.PresupuestoId = proyecto.Presupuestos[0].Id;
        var seleccionado = MYGExportacionS10Sql.CrearDocumento(proyecto, opciones);
        var todos = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        Exige(seleccionado.Resultado.Presupuestos == 1 && todos.Resultado.Presupuestos == 2
            && Filas(seleccionado.Contenido, "Subpresupuesto").Count == 1 && Filas(todos.Contenido, "Subpresupuesto").Count == 2
            && !seleccionado.Contenido.Contains("ALCANCE SEGUNDO", StringComparison.Ordinal)
            && todos.Contenido.Contains("ALCANCE SEGUNDO", StringComparison.Ordinal),
            "Cada alcance debe incluir exactamente los presupuestos elegidos.");
        Exige(!todos.Contenido.Contains("NO-UTILIZADO", StringComparison.Ordinal),
            "Los catálogos ajenos al análisis no deben copiarse a la base de S10.");
        Exige(JsonSerializer.Serialize(proyecto) == antes,
            "Preparar y generar SQL no debe alterar cantidades, firmas, referencias ni la lista de recursos del proyecto abierto.");
        Exige(seleccionado.Contenido == MYGExportacionS10Sql.CrearDocumento(proyecto, opciones).Contenido,
            "La misma instantánea y opciones deben generar un lote reproducible.");
    }

    private static void TextoYTransaccion()
    {
        var proyecto = Proyecto(); var opciones = Opciones();
        const string texto = "O'Brien');\nDELETE FROM [dbo].[Usuario];-- Niño áéíóú";
        opciones.Nombre = texto;
        proyecto.Presupuestos[0].Items[1].Descripcion = texto;
        string sql = MYGExportacionS10Sql.CrearDocumento(proyecto, opciones).Contenido;
        Exige(Filas(sql, "Presupuesto").Any(f => f.GetValueOrDefault("Descripcion") == texto)
            && Filas(sql, "SubpresupuestoDetalle").Any(f => f.GetValueOrDefault("Descripcion") == texto),
            "Los datos con comillas, saltos de línea y texto que parece SQL deben conservarse dentro del literal original.");
        string codigo = SoloCodigo(sql);
        Exige(!Regex.IsMatch(codigo, @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE|DISABLE)\b", RegexOptions.IgnoreCase),
            "El lote no debe escribir sobre registros existentes ni desactivar restricciones.");
        Exige(Regex.Matches(codigo, @"\bBEGIN\s+TRANSACTION\b", RegexOptions.IgnoreCase).Count == 1
            && Regex.Matches(codigo, @"\bCOMMIT\s+TRANSACTION\b", RegexOptions.IgnoreCase).Count == 1
            && Regex.IsMatch(codigo, @"\bBEGIN\s+CATCH\b", RegexOptions.IgnoreCase)
            && Regex.IsMatch(codigo, @"\bROLLBACK\s+TRANSACTION\b", RegexOptions.IgnoreCase)
            && codigo.IndexOf("COMMIT TRANSACTION", StringComparison.Ordinal) > codigo.LastIndexOf("INSERT INTO", StringComparison.Ordinal),
            "Todas las inserciones deben completarse dentro de una sola transacción, con reversión ante errores.");
        Exige(sql.Contains("UPDLOCK,HOLDLOCK", StringComparison.Ordinal)
            && sql.Contains("sys.sp_getapplock", StringComparison.Ordinal)
            && sql.Contains("sys.columns", StringComparison.Ordinal),
            "La importación debe reservar códigos y comprobar el esquema antes de completar las inserciones.");
    }

    private static void DescripcionesUnicode()
    {
        var proyecto = Proyecto(); var p = proyecto.Presupuestos.Single(); var op = Opciones();
        op.Nombre = "Presupuesto ≈ Pampas";
        p.Nombre = "Subpresupuesto ≈ 1";
        p.Items[0].Descripcion = "Título ≈ 1";
        p.Items[1].Descripcion = "Partida ≤ 10 y ≥ 2";
        p.Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion = "Alambre ≈ 3 mm O'Brien";
        p.Costos.Insumos.Single(i => i.Codigo == "MO").Descripcion = "Operario de cafe\u0301";
        p.Costos.PiePersonalizado = new()
        {
            new() { Nombre = "Gasto ≈ 5", Modo = MYGModoFilaResumen.ValorManual, ValorManual = 5m }
        };
        string antes = JsonSerializer.Serialize(proyecto);
        var doc = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        Exige(Filas(doc.Contenido, "Presupuesto").Any(f => f.GetValueOrDefault("Descripcion") == "Presupuesto aprox. Pampas")
            && Filas(doc.Contenido, "Subpresupuesto").Single()["Descripcion"] == "Subpresupuesto aprox. 1"
            && Filas(doc.Contenido, "Titulo").Any(f => f.GetValueOrDefault("Descripcion") == "Título aprox. 1")
            && Filas(doc.Contenido, "Partida").Any(f => f.GetValueOrDefault("Descripcion") == "Partida <= 10 y >= 2")
            && Filas(doc.Contenido, "SubpresupuestoDetalle").Any(f => f.GetValueOrDefault("Descripcion") == "Partida <= 10 y >= 2"),
            "El nombre inicial y todas las descripciones visibles del presupuesto deben usar la misma adaptación antes de validar sus columnas.");
        Exige(Filas(doc.Contenido, "Insumo").Any(f => f.GetValueOrDefault("Descripcion") == "Alambre aprox. 3 mm O'Brien")
            && Filas(doc.Contenido, "Insumo").Any(f => f.GetValueOrDefault("Descripcion") == "Operario de café")
            && Filas(doc.Contenido, "PieSubpresupuesto").Any(f => f.GetValueOrDefault("Descripcion") == "Gasto aprox. 5")
            && Filas(doc.Contenido, "ResultadoPieSubpresupuesto").Any(f => f.GetValueOrDefault("Descripcion") == "Gasto aprox. 5"),
            "La corrección del insumo de la captura también debe alcanzar el pie y los acentos descompuestos sin modificar las comillas del dato.");
        Exige(doc.Resultado.Advertencias.Any(a => a.Contains("≈", StringComparison.Ordinal) && a.Contains("aprox.", StringComparison.Ordinal))
            && doc.Resultado.Advertencias.Any(a => a.Contains("Insumo.Descripcion", StringComparison.Ordinal)),
            "El usuario debe conocer los equivalentes aplicados y el campo donde se usaron.");
        Exige(JsonSerializer.Serialize(proyecto) == antes && op.Nombre == "Presupuesto ≈ Pampas",
            "La adaptación sólo debe afectar la salida SQL, nunca el documento, su pie ni las opciones de entrada.");
        string codigo = SoloCodigo(doc.Contenido);
        Exige(!Regex.IsMatch(codigo, @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE)\b", RegexOptions.IgnoreCase),
            "Adaptar texto no debe agregar operaciones sobre registros existentes.");
    }

    private static void ErrorUnicodeYDestino()
    {
        var proyecto = Proyecto(); var p = proyecto.Presupuestos.Single();
        var material = p.Costos.Insumos.Single(i => i.Codigo == "MAT");
        material.Descripcion = "Material pendiente 😀";
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "U+1F600", "Insumo.Descripcion", "Material pendiente");
        material.Descripcion = "Material ≈ 3";
        material.Codigo = "MAT≈";
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "U+2248", "CodInsumoAnterior");
        material.Codigo = "MAT";
        material.Unidad = "˂";
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "U+02C2", "Simbolo");
        material.Unidad = "und";
        material.Descripcion = new string('a', 115) + "≈";
        var ajustado = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        var conservado = DescripcionesConservadas(ajustado.Contenido).Single(r => r.GetProperty("Original").GetString() == material.Descripcion);
        string textoS10 = conservado.GetProperty("TextoS10").GetString();
        Exige(textoS10.Length <= 120 && Filas(ajustado.Contenido, "Insumo").Any(f => f.GetValueOrDefault("Descripcion") == textoS10),
            "Una expansión que rebasa el límite debe exportarse con su original conservado, sin obligar a editar el proyecto.");
        material.Descripcion = new string('a', 200) + "Material pendiente 😀";
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-S10-Unicode-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "existente.sql");
            byte[] original = Encoding.UTF8.GetBytes("SQL anterior válido"); File.WriteAllBytes(ruta, original);
            ErrorConDetalle(() => MYGExportacionS10Sql.Guardar(ruta, proyecto, Opciones()), "U+1F600");
            Exige(File.ReadAllBytes(ruta).SequenceEqual(original) && Directory.GetFiles(carpeta).Length == 1,
                "Un carácter sin equivalente no debe destruir el archivo previo ni dejar una exportación parcial.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static void DescripcionesLargas()
    {
        const string porcelanato = "PORCELANATO NO ESMALTADO/RECTIFICADO MATE 60x120 cm, e=10.5 mm, GRIS CENIZA, TIPO PIEDRA, ANTIDESLIZANTE R10, TRÁFICO ALTO";
        var proyecto = Proyecto(); var p = proyecto.Presupuestos.Single(); var op = Opciones();
        op.Nombre = new string('ñ', 251);
        p.Nombre = new string('S', 260);
        p.Items[0].Descripcion = new string('T', 260);
        p.Items[1].Descripcion = new string('P', 260);
        p.Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion = porcelanato;
        p.Costos.PiePersonalizado = new()
        {
            new() { Nombre = new string('G', 260), Modo = MYGModoFilaResumen.ValorManual, ValorManual = 5m }
        };
        string antes = JsonSerializer.Serialize(proyecto);
        var modelo = MYGPreparacionExportacionS10.Crear(proyecto).Presupuestos.Single();
        var doc = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        var registros = DescripcionesConservadas(doc.Contenido);
        foreach (var (tabla, original, limite) in new[]
        {
            ("Presupuesto", op.Nombre, 250), ("Subpresupuesto", p.Nombre, 250),
            ("Titulo", p.Items[0].Descripcion, 250), ("Partida", p.Items[1].Descripcion, 250),
            ("Insumo", porcelanato, 120), ("PieSubpresupuesto", p.Costos.PiePersonalizado[0].Nombre, 250)
        })
        {
            Exige(Filas(doc.Contenido, tabla).Where(f => f.ContainsKey("Descripcion")).All(f => f["Descripcion"].Length <= limite),
                "Las descripciones de " + tabla + " deben caber en la columna nativa después de adaptar la longitud.");
            Exige(registros.Any(r => r.GetProperty("Tabla").GetString() == tabla && r.GetProperty("Original").GetString() == original),
                "El SQL debe conservar la descripción completa de " + tabla + " para que pueda recuperarse exactamente.");
        }
        var filas = Filas(doc.Contenido, "SubpresupuestoDetalle").Where(f => f["Tipo"] == "1").ToArray();
        Exige(modelo.Nodos.Where(n => !n.EsTitulo).All(n => filas.Any(f => f["Orden"] == n.Codigo
            && Numero(f, "Metrado") == n.Cantidad && Numero(f, "Precio1") == n.PrecioUnitario && Numero(f, "Parcial1") == n.Parcial)),
            "Ajustar textos no debe cambiar metrados, precios, parciales ni relaciones entre partidas.");
        Exige(JsonSerializer.Serialize(proyecto) == antes && op.Nombre == new string('ñ', 251)
            && doc.Resultado.Advertencias.Any(a => a.Contains("Insumo.Descripcion", StringComparison.Ordinal)),
            "El resultado debe informar la adaptación y preservar el documento abierto y las opciones originales.");

        string ataque = new string('A', 135) + "\r\nGO\r\nDELETE FROM Usuario; /* cierre */ --\t O'Brien";
        p.Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion = ataque;
        doc = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        Exige(DescripcionesConservadas(doc.Contenido).Any(r => r.GetProperty("Original").GetString() == ataque),
            "Las comillas y los saltos de línea del original deben recuperarse desde JSON sin exponer instrucciones SQL.");
        Exige(!Regex.IsMatch(SoloCodigo(doc.Contenido), @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE)\b", RegexOptions.IgnoreCase)
            && !Regex.IsMatch(doc.Contenido, @"(?m)^\s*GO\s*$"),
            "El registro de originales no debe permitir que los saltos de línea o cierres de comentario agreguen instrucciones ni separadores de lote.");
    }

    private static List<JsonElement> DescripcionesConservadas(string sql)
    {
        const string prefijo = "-- MYG_DESCRIPCION_COMPLETA ";
        var resultado = new List<JsonElement>();
        foreach (string linea in sql.Split('\n').Select(l => l.TrimEnd('\r')).Where(l => l.StartsWith(prefijo, StringComparison.Ordinal)))
        {
            using var json = JsonDocument.Parse(linea[prefijo.Length..]);
            resultado.Add(json.RootElement.Clone());
        }
        return resultado;
    }

    private static void ErrorConDetalle(Action accion, params string[] detalles)
    {
        try { accion(); }
        catch (InvalidDataException ex)
        {
            Exige(detalles.All(d => ex.Message.Contains(d, StringComparison.OrdinalIgnoreCase)),
                "El error debe localizar el texto incompatible. Detalles esperados: " + string.Join(", ", detalles) + ". Error real: " + ex.Message);
            Exige(!ex.Message.Contains("Unable to translate", StringComparison.OrdinalIgnoreCase),
                "El diagnóstico debe explicar el problema en español, sin mostrar el error interno del codificador.");
            return;
        }
        throw new Exception("La exportación debió rechazar el texto que no puede representar fielmente.");
    }

    private static void LimitesYDecimales()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Decimales de exportación");
        var n = Nodo(proyecto.Presupuestos.Single(), "12345678901234567890", "Partida decimal");
        n.Costos.Cantidad = 1.2345m; n.Costos.PrecioDirecto = 2.34m;
        var anterior = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = new CultureInfo("es-PE");
            string sql = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()).Contenido;
            var fila = Filas(sql, "SubpresupuestoDetalle").Single();
            Exige(Numero(fila, "Metrado") == 1.2345m && Numero(fila, "Parcial1") == 2.89m,
                "Los literales numéricos deben usar punto decimal y conservar el redondeo monetario de MYG.");
        }
        finally { CultureInfo.CurrentCulture = anterior; }
        n.Item += "1";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
        n.Item = "01";
        var op = Opciones(); op.Nombre = new string('a', 251);
        var largo = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        Exige(DescripcionesConservadas(largo.Contenido).Any(r => r.GetProperty("Original").GetString() == op.Nombre),
            "El nombre largo del presupuesto debe adaptarse junto con su original, igual que las descripciones de los insumos.");
        op = Opciones(); op.CodigoLugar = "999999";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, op));
        op = Opciones(); op.CodigoUsuario = "12345678";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, op));
        op = Opciones(); op.FechaCosto = new DateTime(1600, 1, 1);
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, op));
        n.Costos.PrecioDirecto = 10000000000000000m;
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
        n.Costos.PrecioDirecto = 2.34m;
        n.Descripcion = "Partida 😀";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
        n.Descripcion = "Partida decimal";
        var segundo = new MYGPresupuestoDocumento { Item = "02", Nombre = "Otra moneda", Posicion = 2 };
        segundo.Costos.Moneda = "USD"; proyecto.Presupuestos.Add(segundo);
        Nodo(segundo, "01", "Dólares");
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
    }

    private static void ArchivoAtomico()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-S10-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "presupuesto.sql");
            byte[] original = Encoding.UTF8.GetBytes("archivo anterior que debe conservarse"); File.WriteAllBytes(ruta, original);
            var op = Opciones(); op.CodigoUsuario = "12345678";
            Rechaza(() => MYGExportacionS10Sql.Guardar(ruta, Proyecto(), op));
            Exige(File.ReadAllBytes(ruta).SequenceEqual(original) && Directory.GetFiles(carpeta).Length == 1,
                "Una exportación inválida debe conservar el archivo anterior y no dejar archivos temporales.");
            Rechaza(() => MYGExportacionS10Sql.Guardar(Path.Combine(carpeta, "presupuesto.S2K"), Proyecto(), Opciones()));
            var mensajes = new List<string>();
            var resultado = MYGExportacionS10Sql.Guardar(ruta, Proyecto(), Opciones(), mensajes.Add);
            byte[] bytes = File.ReadAllBytes(ruta);
            Exige(resultado.Partidas == 3 && mensajes.Count > 0 && bytes.AsSpan(0, 3).SequenceEqual(new byte[] { 0xEF, 0xBB, 0xBF })
                && File.ReadAllText(ruta).Contains("Importación MYG completada", StringComparison.Ordinal)
                && Directory.GetFiles(carpeta).Length == 1,
                "Guardar debe publicar un archivo SQL UTF8 completo, informar progreso y retirar su archivo temporal.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static MYGOpcionesExportacionS10 Opciones() => new()
    {
        Nombre = "Prueba de integración MYG", CodigoLugar = MYGExportacionS10Sql.Ubicaciones.First().Codigo,
        FechaCosto = new DateTime(2026, 11, 17)
    };

    private static MYGProyectoDocumento Proyecto()
    {
        var d = MYGProyectoStorage.Nuevo("Integración S10", "SUBPRESUPUESTO DE PRUEBA"); var p = d.Presupuestos.Single();
        var titulo = Nodo(p, "01", "Título", titulo: true);
        var mo = new MYGInsumo { Codigo = "MO", Descripcion = "Operario", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 10 };
        var material = new MYGInsumo { Codigo = "MAT", Descripcion = "Material de prueba", Unidad = "und", Grupo = MYGGrupoRecurso.Materiales, Precio = 5 };
        p.Costos.Insumos.Add(mo); p.Costos.Insumos.Add(material);
        p.Costos.Insumos.Add(new() { Codigo = "NO-UTILIZADO", Descripcion = "NO-UTILIZADO", Unidad = "und", Precio = 999 });
        var principal = Nodo(p, "01.01", "Partida compuesta", titulo.Id); principal.Costos.Cantidad = 2;
        var auxiliar = Nodo(p, "01.02", "Subpartida auxiliar", titulo.Id); auxiliar.Costos.Cantidad = 0;
        auxiliar.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 4 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo.Id, Cantidad = 2 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 1 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 2 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = auxiliar.IdLocalMYG, Cantidad = .5m });
        var directa = Nodo(p, "01.03", "Precio directo", titulo.Id); directa.Costos.Cantidad = 3; directa.Costos.PrecioDirecto = 7;
        return d;
    }

    private static ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento p, string codigo, string nombre, string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        var n = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Item = codigo, Descripcion = nombre, ParentId = padre,
            Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Posicion = p.Items.Count + 1,
            Origen = "MODELO", Estado = "PROPUESTA", Costos = new MYGDatosPartida { PrecioDirecto = 1 }
        };
        p.Items.Add(n); return n;
    }

    private static decimal Numero(IReadOnlyDictionary<string, string> fila, string columna) => decimal.Parse(fila[columna], CultureInfo.InvariantCulture);

    private static void Rechaza(Action accion)
    {
        try { accion(); } catch (InvalidDataException) { return; }
        throw new Exception("La exportación S10 debió rechazar los datos incompatibles.");
    }
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }

    private static List<Dictionary<string, string>> Filas(string sql, string tabla)
    {
        string codigo = SoloCodigo(sql);
        var resultado = new List<Dictionary<string, string>>();
        foreach (Match m in Regex.Matches(codigo, @"\bINSERT\s+INTO\s+\[dbo\]\.\[" + Regex.Escape(tabla) + @"\]\s*\(", RegexOptions.IgnoreCase))
        {
            int inicioColumnas = m.Index + m.Length, finColumnas = codigo.IndexOf(')', inicioColumnas);
            string[] columnas = sql[inicioColumnas..finColumnas].Split(',').Select(c => c.Trim().Trim('[', ']')).ToArray();
            int inicioValores = codigo.IndexOf('(', finColumnas) + 1, profundidad = 0, inicio = inicioValores;
            var valores = new List<string>();
            for (int i = inicioValores; i < codigo.Length; i++)
            {
                if (codigo[i] == '(') profundidad++;
                else if (codigo[i] == ')' && profundidad-- == 0)
                { valores.Add(sql[inicio..i].Trim()); break; }
                else if (codigo[i] == ',' && profundidad == 0)
                { valores.Add(sql[inicio..i].Trim()); inicio = i + 1; }
            }
            Exige(columnas.Length == valores.Count, "Cada INSERT debe declarar un valor por columna.");
            resultado.Add(columnas.Zip(valores).ToDictionary(v => v.First, v => Texto(v.Second), StringComparer.Ordinal));
        }
        return resultado;
    }

    private static string Texto(string valor) => valor.StartsWith("N'", StringComparison.Ordinal)
        ? valor[2..^1].Replace("''", "'") : valor.StartsWith("'", StringComparison.Ordinal) ? valor[1..^1].Replace("''", "'") : valor;

    // Conserva posiciones para que las pruebas lean valores reales de los
    // INSERT sin confundir instrucciones con texto o comentarios del usuario.
    private static string SoloCodigo(string sql)
    {
        var b = sql.ToCharArray();
        for (int i = 0; i < sql.Length; i++)
        {
            int inicio = i;
            if (sql[i] == '\'')
            {
                if (i > 0 && sql[i - 1] == 'N') b[i - 1] = ' ';
                for (i++; i < sql.Length; i++)
                    if (sql[i] == '\'') { if (i + 1 < sql.Length && sql[i + 1] == '\'') i++; else break; }
                Exige(i < sql.Length, "No debe quedar un literal SQL sin cerrar.");
            }
            else if (sql[i] == '-' && i + 1 < sql.Length && sql[i + 1] == '-')
                while (i < sql.Length && sql[i] != '\n') i++;
            else continue;
            for (int j = inicio; j <= i && j < b.Length; j++) b[j] = ' ';
        }
        return new string(b);
    }
}
