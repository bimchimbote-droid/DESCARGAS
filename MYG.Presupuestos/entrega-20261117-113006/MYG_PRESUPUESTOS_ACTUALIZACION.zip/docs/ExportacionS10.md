# Exportar desde MYG a S10 Presupuestos 2005

En el editor del proyecto, abra **Exportar → Exportar a S10 Presupuestos 2005…**.
Seleccione el presupuesto activo o todos, el nombre, la fecha de costos y la
ubicación del catálogo de S10. El código de usuario S10 es opcional: vacío, el
script busca un usuario activo asociado a la conexión SQL que realiza la importación.
Si no encuentra esa asociación, se detiene y pide exportar con el código indicado.

El resultado es un **archivo .sql**, no un respaldo .S2K. MYG no se conecta ni
escribe automáticamente en SQL Server. El icono de Exportar ahora representa
una salida de documentos y se comparte con la herramienta de cronograma.

## Importar en una copia de la base

1. Respalde su base de S10 y restaure ese respaldo como una base de prueba.
2. Abra el archivo .sql en SQL Server Management Studio y seleccione
   expresamente esa copia de la base S10 como destino.
3. Ejecute el lote completo con un usuario autorizado para insertar registros.
   Comprueba tablas, tipos, límites de columnas, moneda, ubicación, usuario y
   registros de sistema. Si falla una inserción, revierte la transacción.
4. El resultado muestra el código del presupuesto nuevo. En S10, búsquelo
   dentro de **MYG Presupuestos** y procese sus análisis con el procedimiento
   normal del programa. S10 genera sus resultados internos; no se copian cachés
   de análisis de otra aplicación.
5. Compare partidas, metrados, precios y totales con MYG. Revise las fórmulas del
   pie antes de editar o reprocesar; luego genere el respaldo desde S10 si lo necesita.

El script crea códigos nuevos y recursos separados por exportación. Ejecutarlo
otra vez crea otro presupuesto. No actualiza, elimina ni reemplaza los existentes
y mantiene habilitadas las restricciones de la base.

## Datos y diferencias de representación

- Exporta títulos, partidas, metrados calculados, unidades, ACU, subpartidas,
  recursos utilizados, precios y el pie del presupuesto.
- Las cantidades manuales, BIM y Excel se exportan como valores calculados.
  Los vínculos, documentos técnicos, cronogramas y archivos adjuntos no se transfieren.
- Una partida sin ACU utiliza un insumo equivalente por su precio directo. Así
  puede reprocesarse sin perder ese precio.
- El porcentaje de mano de obra usa la fracción nativa de S10: 3% se guarda
  como 0.03. Las cuadrillas se derivan del consumo efectivo, rendimiento y jornada.
- Una unidad porcentual usada como cantidad directa en MYG pasa a unidad `coef`
  para evitar que S10 la interprete como una fórmula diferente.
- El pie conserva los importes actuales mediante fórmulas numéricas. **Los gastos,
  utilidad e impuestos no quedan vinculados dinámicamente al costo directo**;
  deberá revisar sus fórmulas si cambia cantidades o precios en S10.
- Las diferencias de redondeo importadas se muestran como avisos. El reprocesado
  de S10 puede aplicar sus propias reglas; compare los resultados antes de usarlo.
- Cada exportación admite una sola moneda. Exporte por separado presupuestos
  con monedas distintas. Los códigos, unidades, fórmulas y números que exceden
  los tipos de S10 se rechazan con un mensaje, sin modificarlos.
- Si una descripción supera la longitud de S10 (por ejemplo, 120 bytes para
  un insumo), se compactan los espacios. También se pueden quitar espacios tras
  comas o punto y coma cuando sigue una palabra; la separación entre cifras se
  conserva. Si aún no cabe, se usa una versión abreviada terminada en `...`.
  Se informa cada ajuste. El texto original completo permanece en MYG y se
  guarda en el mismo SQL, en comentarios con la marca `MYG_DESCRIPCION_COMPLETA`.
  Esos comentarios contienen JSON con la tabla, las claves de la fila, el texto
  original, el adaptado completo y la versión que recibe S10. Se pueden localizar
  con Buscar en un editor de texto. El original no se añade a una nota nativa de
  S10: conserve el SQL junto con el proyecto MYG para consultar el texto completo.
- Las descripciones adaptan símbolos incompatibles de forma explícita: `≈` pasa
  a `aprox.`, `≤` a `<=`, `≥` a `>=`, `≠` a `<>` y el signo menos Unicode a `-`.
  Los acentos descompuestos se normalizan. Los signos decorativos `˂ ˃ ː ❴ ❵
  ⟩ ⟨ │ ; ？ ˋ ∼` vuelven a sus equivalentes ASCII: menor, mayor, dos puntos,
  llaves, corchetes, barra vertical, punto y coma, interrogación, acento grave y `~`.
  El resultado informa las adaptaciones; los datos originales permanecen intactos.
  Los signos ASCII, comillas y acentos ya compatibles se conservan y se escapan
  como datos SQL. Las claves, unidades y fórmulas no se adaptan. Un símbolo sin
  equivalente admitido detiene la exportación e indica su código Unicode y campo.

## Compatibilidad y validación

El perfil de columnas y las reglas se verificaron mediante lectura de la base
S10 2005 proporcionada. Incluye únicamente metadatos y ubicaciones genéricas;
no incorpora presupuestos, precios, usuarios ni credenciales del archivo de ejemplo.
El SQL utiliza sintaxis de SQL Server 2005 y valida la página de códigos 1252
en las columnas de texto no Unicode. Una base con otro esquema se rechaza.

Se ejecutaron las pruebas de preparación, emisión de SQL y exportación en .NET 10.
El lote representativo también se verificó con el analizador oficial
`TSql90Parser` de Microsoft. Este analizador se utilizó como herramienta externa
de desarrollo y no añade dependencias al programa.

**Pendiente:** ejecutar la importación y comprobar el reprocesado en S10 sobre
Windows. Las comprobaciones de sintaxis y del esquema no sustituyen esa prueba.

Para ejecutar las pruebas de la exportación:

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true
dotnet MYG.Pruebas/bin/Release/net10.0/MYG.Pruebas.dll --exportacion-s10
```
