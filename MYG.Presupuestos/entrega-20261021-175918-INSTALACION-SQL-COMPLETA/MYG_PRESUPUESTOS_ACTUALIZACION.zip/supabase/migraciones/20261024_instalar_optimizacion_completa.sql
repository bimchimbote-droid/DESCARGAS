-- INSTALACIÓN COMPLETA DE OPTIMIZACIÓN DE NUBE MYG.
-- Ejecutar TODO este archivo en SQL Editor, como administrador del proyecto.
-- Resuelve la falta de 20261021_contenido_grande.sql antes de las migraciones22/23.
-- Requiere el contrato de usuarios/permisos de 20261020_usuarios_myg_roles.sql.
-- Una sola transacción: cualquier error revierte todos los pasos de esta ejecución.
-- Repetible tanto con límite32/127MiB como con paquetes compactos ya instalados.
-- No elimina ni reescribe obras, miembros, identidades, historial u operaciones.
-- No requiere una sesión MYG/JWT en SQL Editor: la comprobación final lee catálogo.
-- Origen de los cuerpos incluidos (SHA-256 de cada archivo original):
-- 20261021_contenido_grande.sql 7c7e10778b7af658d1116e24ad52318e8ca44dd4118967b0ae7f4eddf5462d05
-- 20261022_paquete_compacto.sql ad59641a0b00175c8871653098be5ecfcd78f797a0c93c78c5a5efb1883ee01a
-- 20261023_sincronizacion_incremental.sql c0a45b4c5b3f7f73a874530694909c1f678462c709cffeab0dcc464d42d1a817

begin;

-- El límite anterior se actualiza antes de crear las funciones compactas.
-- Si ya existe un wrapper compacto correcto, se conserva su validador v1;
-- volver a aplicar la migración21 directamente sobre el wrapper sería incorrecto.
do $instalador_requisito$
declare
    v_actual record;
    v_anterior record;
    v_cuerpo text;
begin
    select p.*,l.lanname into v_actual
      from pg_catalog.pg_proc p join pg_catalog.pg_language l on l.oid=p.prolang
      where p.oid=pg_catalog.to_regprocedure('myg_nube_privado.validar_contenido(jsonb)');
    if not found then
        raise exception 'Instalación cancelada: falta el contrato previo de Nube MYG. Aplique primero la actualización de usuarios/permisos.';
    end if;
    if pg_catalog.to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)') is not null then
        select p.*,l.lanname into v_anterior
          from pg_catalog.pg_proc p join pg_catalog.pg_language l on l.oid=p.prolang
          where p.oid=pg_catalog.to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)');
        v_cuerpo:=pg_catalog.regexp_replace(v_anterior.prosrc,'[[:space:]]','','g');
        if v_actual.prokind<>'f' or v_actual.prorettype<>'void'::regtype
           or v_actual.lanname<>'plpgsql' or v_actual.provolatile<>'i' or v_actual.prosecdef
           or v_actual.proargnames is distinct from array['p_contenido']::text[]
           or pg_catalog.strpos(v_actual.prosrc,'myg_nube_privado.validar_contenido_v1')=0
           or pg_catalog.strpos(v_actual.prosrc,'myg_nube_privado.expandir_paquete')=0
           or v_anterior.prokind<>'f' or v_anterior.prorettype<>'void'::regtype
           or v_anterior.lanname<>'plpgsql' or v_anterior.provolatile<>'i' or v_anterior.prosecdef
           or v_anterior.proargnames is distinct from array['p_contenido']::text[]
           or pg_catalog.strpos(v_cuerpo,'p_contenidoisnull')=0
           or pg_catalog.strpos(v_cuerpo,'jsonb_typeof(p_contenido)<>''object''')=0
           or (select count(*) from pg_catalog.regexp_matches(v_cuerpo,
               'octet_length\(p_contenido::text\)>133169152([^0-9]|$)','g'))<>1
           or pg_catalog.strpos(v_anterior.prosrc,'MYG_CONTENIDO_INVALIDO_MAX_127_MIB')=0 then
            raise exception 'Instalación cancelada: el validador compacto o su copia v1 no tienen el contrato esperado. No se sustituyeron datos ni validaciones.';
        end if;
        raise notice 'El requisito de contenido grande ya está incorporado al validador compacto.';
    else
        execute $requisito_21$
-- Paquetes Nube MYG de hasta 127 MiB (133169152 bytes de JSONB textual).
-- Ejecutar completo en SQL Editor como administrador, después de la migración
-- 20261020_usuarios_myg_roles.sql. Es repetible y no modifica tablas ni datos.
-- El cliente actualizado reserva otro MiB para la respuesta RPC (128 MiB).

do $contenido_grande$
declare
    v_helper record;
    v_despues record;
    v_rpc record;
    v_definicion text;
    v_cuerpo text;
begin
    select p.*, l.lanname into v_helper
    from pg_catalog.pg_proc p join pg_catalog.pg_language l on l.oid=p.prolang
    where p.oid=pg_catalog.to_regprocedure('myg_nube_privado.validar_contenido(jsonb)');
    if not found or v_helper.prokind<>'f' or v_helper.prorettype<>'void'::regtype
       or v_helper.lanname<>'plpgsql' or v_helper.provolatile<>'i'
       or v_helper.proargnames is distinct from array['p_contenido']::text[] then
        raise exception 'Migración cancelada: validar_contenido(jsonb) no tiene la firma compatible esperada.';
    end if;
    -- Reconocer el límite anterior o esta misma actualización. Nunca sustituir
    -- silenciosamente un validador con otro contrato. Se conserva TODO el resto
    -- del cuerpo, sus atributos, search_path, propietario y ACL originales.
    v_cuerpo:=pg_catalog.regexp_replace(v_helper.prosrc,'[[:space:]]','','g');
    if pg_catalog.strpos(v_cuerpo,'p_contenidoisnull')=0
       or pg_catalog.strpos(v_cuerpo,'jsonb_typeof(p_contenido)<>''object''')=0
       or (select count(*) from pg_catalog.regexp_matches(v_cuerpo,
           'octet_length\(p_contenido::text\)>(33554432|133169152)([^0-9]|$)','g'))<>1
       or (pg_catalog.strpos(v_helper.prosrc,'MYG_CONTENIDO_INVALIDO_MAX_32_MIB')=0
           and pg_catalog.strpos(v_helper.prosrc,'MYG_CONTENIDO_INVALIDO_MAX_127_MIB')=0) then
        raise exception 'Migración cancelada: el validador actual no contiene el contrato de objeto JSON y límite 32/127 MiB esperado.';
    end if;
    for v_rpc in select * from (values
        ('public.myg_nube_crear(uuid,text,jsonb,text)'),
        ('public.myg_nube_abrir(uuid)'),
        ('public.myg_nube_guardar(uuid,uuid,bigint,jsonb)')
    ) r(firma) loop
        if not exists(select 1 from pg_catalog.pg_proc p
            where p.oid=pg_catalog.to_regprocedure(v_rpc.firma)
                and p.prokind='f' and p.prosecdef and p.prorettype='jsonb'::regtype) then
            raise exception 'Migración cancelada: falta el RPC SECURITY DEFINER compatible %.',v_rpc.firma;
        end if;
    end loop;

    v_definicion:=pg_catalog.pg_get_functiondef(v_helper.oid);
    v_definicion:=pg_catalog.regexp_replace(v_definicion,
        'octet_length[[:space:]]*\([[:space:]]*p_contenido[[:space:]]*::[[:space:]]*text[[:space:]]*\)[[:space:]]*>[[:space:]]*(33554432|133169152)([^0-9]|$)',
        'octet_length(p_contenido::text) > 133169152\2','g');
    v_definicion:=pg_catalog.replace(v_definicion,
        'MYG_CONTENIDO_INVALIDO_MAX_32_MIB','MYG_CONTENIDO_INVALIDO_MAX_127_MIB');
    execute v_definicion;

    select p.* into v_despues from pg_catalog.pg_proc p where p.oid=v_helper.oid;
    if v_despues.proowner is distinct from v_helper.proowner
       or v_despues.proacl is distinct from v_helper.proacl
       or v_despues.proconfig is distinct from v_helper.proconfig
       or v_despues.prosecdef is distinct from v_helper.prosecdef then
        raise exception 'Migración cancelada: cambiaron atributos protegidos del validador.';
    end if;
end;
$contenido_grande$;

-- Plazos por función para REST/Supabase. No se altera ningún rol, base, política,
-- permiso ni cuerpo de los RPC; se mantienen sus revisiones y UUID idempotentes.
alter function public.myg_nube_crear(uuid,text,jsonb,text) set statement_timeout to '120s';
alter function public.myg_nube_abrir(uuid) set statement_timeout to '120s';
alter function public.myg_nube_guardar(uuid,uuid,bigint,jsonb) set statement_timeout to '120s';

$requisito_21$;
    end if;
end $instalador_requisito$;

-- PASO2: paquete compacto; conserva todas las comprobaciones de la migración22.
-- Formato portable compacto v2. Ejecutar después de 20261021_contenido_grande.sql.
-- Repetible: no convierte ni reescribe proyectos, historial u operaciones previos.
-- El paquete se almacena COMPACTO. La expansión existe únicamente para verificar
-- tipos y comparar los módulos protegidos con el guard ya probado de v1.

do $preflight$
declare v record; v_def text;
begin
    for v in select * from (values
        ('validar_contenido','jsonb','void'),
        ('exigir_modulos','jsonb,jsonb,jsonb','void')
    ) r(nombre,argumentos,resultado) loop
        if not exists(select 1 from pg_proc p where p.oid=to_regprocedure(
            'myg_nube_privado.'||v.nombre||'('||v.argumentos||')')
            and p.prorettype=to_regtype(v.resultado) and p.provolatile='i' and not p.prosecdef) then
            raise exception 'Migración cancelada: falta el auxiliar compatible %.',v.nombre;
        end if;
        if to_regprocedure('myg_nube_privado.'||v.nombre||'_v1('||v.argumentos||')') is null then
            select pg_get_functiondef(p.oid) into v_def from pg_proc p
            where p.oid=to_regprocedure('myg_nube_privado.'||v.nombre||'('||v.argumentos||')');
            if v.nombre='validar_contenido' and strpos(v_def,'MYG_CONTENIDO_INVALIDO_MAX_127_MIB')=0 then
                raise exception 'Migración cancelada: aplique primero 20261021_contenido_grande.sql.';
            end if;
            -- Copiar, en vez de renombrar, mantiene los OID originales. También
            -- las sesiones que ya ejecutaron los RPC reciben el nuevo validador.
            v_def:=replace(v_def,'FUNCTION myg_nube_privado.'||v.nombre||'(',
                'FUNCTION myg_nube_privado.'||v.nombre||'_v1(');
            execute v_def;
        elsif not exists(select 1 from pg_proc p where p.oid=to_regprocedure(
            'myg_nube_privado.'||v.nombre||'('||v.argumentos||')')
            and strpos(p.prosrc,'myg_nube_privado.expandir_paquete')>0) then
            raise exception 'Migración cancelada: el auxiliar % cambió después de guardar su versión anterior.',v.nombre;
        end if;
    end loop;
end $preflight$;

create or replace function myg_nube_privado.expandir_celda(p_celda jsonb,p_textos jsonb,p_documentos jsonb,p_tabla text,p_columna text,p_materializar boolean)
returns jsonb language plpgsql immutable set search_path=pg_catalog as $function$
declare v_tag text; v_valor text; v_indice numeric; v_real double precision; v_documento jsonb;
begin
    if p_celda='null'::jsonb then
        return case when p_materializar then '{"Tipo":"nulo","Valor":null}'::jsonb else null end;
    elsif jsonb_typeof(p_celda)='string' then
        return case when p_materializar then jsonb_build_object('Tipo','texto','Valor',p_celda) else null end;
    elsif jsonb_typeof(p_celda) is distinct from 'array' then
        raise exception using errcode='22023',message='MYG_CELDA_COMPACTA_INVALIDA';
    end if;
    if jsonb_array_length(p_celda)<>2 or jsonb_typeof(p_celda->0) is distinct from 'string' then
        raise exception using errcode='22023',message='MYG_CELDA_COMPACTA_INVALIDA';
    end if;
    v_tag:=p_celda->>0;
    if v_tag='s' then
        if jsonb_typeof(p_celda->1) is distinct from 'number'
            or (p_celda->>1)!~'^(0|[1-9][0-9]*)$' then
            raise exception using errcode='22023',message='MYG_REFERENCIA_COMPACTA_INVALIDA';
        end if;
        v_indice:=(p_celda->>1)::numeric;
        if v_indice>=jsonb_array_length(p_textos) then
            raise exception using errcode='22023',message='MYG_REFERENCIA_COMPACTA_INVALIDA';
        end if;
        return case when p_materializar then jsonb_build_object('Tipo','texto','Valor',p_textos->v_indice::integer) else null end;
    end if;
    if v_tag='d' then
        if p_tabla<>'myg_proyecto' or p_columna<>'json_documento'
            or jsonb_typeof(p_celda->1) is distinct from 'string' then
            raise exception using errcode='22023',message='MYG_REFERENCIA_DOCUMENTO_INVALIDA';
        end if;
        v_documento:=p_documentos->(p_celda->>1);
        if v_documento is null then
            raise exception using errcode='22023',message='MYG_REFERENCIA_DOCUMENTO_INVALIDA';
        end if;
        return case when p_materializar then jsonb_build_object('Tipo','texto','Valor',v_documento::text) else null end;
    end if;
    if v_tag not in ('i','r','b') or jsonb_typeof(p_celda->1) is distinct from 'string' then
        raise exception using errcode='22023',message='MYG_CELDA_COMPACTA_INVALIDA';
    end if;
    v_valor:=p_celda->>1;
    begin
        if v_tag='i' then
            if v_valor!~'^[+-]?[0-9]+$' then raise invalid_text_representation; end if;
            perform v_valor::bigint;
        elsif v_tag='r' then
            v_real:=v_valor::double precision;
            if v_real in ('NaN'::float8,'Infinity'::float8,'-Infinity'::float8) then
                raise invalid_text_representation;
            end if;
        else
            perform decode(v_valor,'base64');
        end if;
    exception when invalid_text_representation or numeric_value_out_of_range or invalid_parameter_value then
        raise exception using errcode='22023',message='MYG_CELDA_COMPACTA_VALOR_INVALIDO';
    end;
    if not p_materializar then return null; end if;
    return jsonb_build_object('Tipo',case v_tag when 'i' then 'entero' when 'r' then 'real' else 'blob' end,'Valor',v_valor);
end $function$;

create or replace function myg_nube_privado.expandir_paquete(p_contenido jsonb,p_materializar boolean)
returns jsonb language plpgsql immutable set search_path=pg_catalog as $function$
declare
    v_textos jsonb; v_tabla jsonb; v_tablas jsonb[]:=array[]::jsonb[];
    v_fila jsonb; v_celdas jsonb; v_nombre text;
    v_nombres text[]:=array[]::text[]; v_documentos jsonb; v_ids text[];
    v_documento jsonb; v_id text; v_total integer; v_documentos_mapa jsonb;
    v_bytes bigint; v_ref jsonb; v_textos_bytes bigint[]; v_documentos_bytes jsonb;
begin
    -- Los paquetes anteriores y los objetos de pruebas/baseline mantienen su
    -- contrato previo. No interpretar marcadores v2 con casing alternativo.
    if jsonb_typeof(p_contenido) is distinct from 'object'
        or p_contenido->>'formato' is distinct from 'MYG_COLABORACION' then return p_contenido; end if;
    if p_contenido->'version' is distinct from '2'::jsonb then
        if p_contenido->>'formato'='MYG_COLABORACION'
            and p_contenido ? 'version' and p_contenido->'version' is distinct from '1'::jsonb then
            raise exception using errcode='22023',message='MYG_PAQUETE_VERSION_NO_COMPATIBLE';
        end if;
        return p_contenido;
    end if;
    if p_contenido->>'formato' is distinct from 'MYG_COLABORACION'
        or p_contenido->>'version'<>'2'
        or not p_contenido ?& array['formato','version','alcance','documento','documentos','tablas','recursos','textos']
        or p_contenido-array['formato','version','alcance','documento','documentos','tablas','recursos','textos','avisos','exclusiones']<>'{}'::jsonb
        or p_contenido->>'alcance' is null or p_contenido->>'alcance' not in ('obra','base')
        or jsonb_typeof(p_contenido->'documento') is distinct from 'object'
        or jsonb_typeof(p_contenido->'documentos') is distinct from 'array'
        or jsonb_typeof(p_contenido->'tablas') is distinct from 'array'
        or jsonb_typeof(p_contenido->'recursos') is distinct from 'array' then
        raise exception using errcode='22023',message='MYG_PAQUETE_COMPACTO_INVALIDO';
    end if;
    v_textos:=p_contenido->'textos';
    if jsonb_typeof(v_textos) is distinct from 'array'
        or exists(select 1 from jsonb_array_elements(v_textos) where jsonb_typeof(value)<>'string')
        or (select count(*)<>count(distinct value) from jsonb_array_elements(v_textos)) then
        raise exception using errcode='22023',message='MYG_TEXTOS_COMPACTOS_INVALIDOS';
    end if;
    v_id:=p_contenido#>>'{documento,Id}';
    if jsonb_typeof(p_contenido#>'{documento,Id}') is distinct from 'string' or nullif(btrim(v_id),'') is null
        or (select count(*)<>count(distinct lower(key)) from jsonb_object_keys(p_contenido->'documento') k(key)) then
        raise exception using errcode='22023',message='MYG_DOCUMENTOS_COMPACTOS_INVALIDOS';
    end if;
    v_ids:=array[upper(v_id)];
    v_documentos_mapa:=jsonb_build_object(v_id,p_contenido->'documento');
    for v_documento in select value from jsonb_array_elements(p_contenido->'documentos') loop
        v_id:=v_documento->>'Id';
        if jsonb_typeof(v_documento) is distinct from 'object'
            or jsonb_typeof(v_documento->'Id') is distinct from 'string'
            or nullif(btrim(v_id),'') is null or upper(v_id)=any(v_ids)
            or (select count(*)<>count(distinct lower(key)) from jsonb_object_keys(v_documento) k(key)) then
            raise exception using errcode='22023',message='MYG_DOCUMENTOS_COMPACTOS_INVALIDOS';
        end if;
        v_ids:=array_append(v_ids,upper(v_id));
        v_documentos_mapa:=v_documentos_mapa||jsonb_build_object(v_id,v_documento);
    end loop;
    v_documentos:=(p_contenido->'documentos')||jsonb_build_array(p_contenido->'documento');
    select coalesce(array_agg(octet_length(value::text)::bigint order by ord),array[]::bigint[])
        into v_textos_bytes from jsonb_array_elements(v_textos) with ordinality d(value,ord);
    select coalesce(jsonb_object_agg(key,octet_length(to_jsonb(value::text)::text)),'{}'::jsonb)
        into v_documentos_bytes from jsonb_each(v_documentos_mapa);
    -- Estimar referencias ANTES de materializar sus valores. Un diccionario
    -- pequeño no debe permitir expandir varios GiB en memoria del servidor.
    v_bytes:=octet_length(p_contenido::text)+octet_length((p_contenido->'documento')::text);
    for v_tabla in select value from jsonb_array_elements(p_contenido->'tablas') loop
        v_nombre:=v_tabla->>'Nombre';
        if jsonb_typeof(v_tabla) is distinct from 'object'
            or not v_tabla ?& array['Nombre','Columnas','Filas']
            or v_tabla-array['Nombre','Columnas','Filas']<>'{}'::jsonb
            or jsonb_typeof(v_tabla->'Nombre') is distinct from 'string'
            or nullif(btrim(v_nombre),'') is null or lower(v_nombre)=any(v_nombres)
            or jsonb_typeof(v_tabla->'Columnas') is distinct from 'array'
            or jsonb_typeof(v_tabla->'Filas') is distinct from 'array' then
            raise exception using errcode='22023',message='MYG_TABLAS_COMPACTAS_INVALIDAS';
        end if;
        v_nombres:=array_append(v_nombres,lower(v_nombre));
        v_total:=jsonb_array_length(v_tabla->'Columnas');
        if exists(select 1 from jsonb_array_elements(v_tabla->'Columnas') where jsonb_typeof(value)<>'string' or nullif(btrim(value#>>'{}'),'') is null)
            or (select count(*)<>count(distinct lower(value#>>'{}')) from jsonb_array_elements(v_tabla->'Columnas')) then
            raise exception using errcode='22023',message='MYG_COLUMNAS_COMPACTAS_INVALIDAS';
        end if;
        for v_fila in select value from jsonb_array_elements(v_tabla->'Filas') loop
            if jsonb_typeof(v_fila) is distinct from 'array' or jsonb_array_length(v_fila)<>v_total then
                raise exception using errcode='22023',message='MYG_FILA_COMPACTA_INVALIDA';
            end if;
            for v_ref in select value from jsonb_array_elements(v_fila) loop
                v_bytes:=v_bytes+64;
                if jsonb_typeof(v_ref)='array' and v_ref->>0='s'
                    and jsonb_typeof(v_ref->1)='number' and (v_ref->>1)~'^(0|[1-9][0-9]*)$'
                    and (v_ref->>1)::numeric<jsonb_array_length(v_textos) then
                    v_bytes:=v_bytes+v_textos_bytes[(v_ref->>1)::integer+1];
                elsif jsonb_typeof(v_ref)='array' and v_ref->>0='d'
                    and jsonb_typeof(v_ref->1)='string' and v_documentos_mapa ? (v_ref->>1) then
                    v_bytes:=v_bytes+(v_documentos_bytes->>(v_ref->>1))::bigint;
                end if;
                if v_bytes>536870912 then
                    raise exception using errcode='22023',message='MYG_PAQUETE_EXPANDIDO_MAX_512_MIB';
                end if;
            end loop;
        end loop;
    end loop;
    -- Tras la estimación completa se validan todas las celdas. La comprobación
    -- previa al guardado no materializa otra copia expandida del paquete.
    for v_tabla in select value from jsonb_array_elements(p_contenido->'tablas') loop
        if not p_materializar then
            perform myg_nube_privado.expandir_celda(c.value,v_textos,v_documentos_mapa,
                v_tabla->>'Nombre',v_tabla->'Columnas'->>(c.ord-1)::integer,false)
            from jsonb_array_elements(v_tabla->'Filas') f(value)
            cross join lateral jsonb_array_elements(f.value) with ordinality c(value,ord);
        else
            select coalesce(jsonb_agg((select coalesce(jsonb_agg(
                myg_nube_privado.expandir_celda(c.value,v_textos,v_documentos_mapa,
                    v_tabla->>'Nombre',v_tabla->'Columnas'->>(c.ord-1)::integer,true) order by c.ord),'[]'::jsonb)
                from jsonb_array_elements(f.value) with ordinality c(value,ord)) order by f.ord),'[]'::jsonb)
                into v_celdas from jsonb_array_elements(v_tabla->'Filas') with ordinality f(value,ord);
            v_tablas:=array_append(v_tablas,jsonb_set(v_tabla,'{Filas}',v_celdas));
        end if;
    end loop;
    if not p_materializar then return p_contenido; end if;
    return (p_contenido-'textos')||jsonb_build_object('version',1,'documentos',v_documentos,'tablas',to_jsonb(v_tablas));
end $function$;

create or replace function myg_nube_privado.expandir_paquete(p_contenido jsonb)
returns jsonb language sql immutable set search_path=pg_catalog as $function$
    select myg_nube_privado.expandir_paquete(p_contenido,true);
$function$;

create or replace function myg_nube_privado.validar_contenido(p_contenido jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $function$
begin
    -- Aplicar tamaño a lo que se almacena, nunca a una representación expandida.
    perform myg_nube_privado.validar_contenido_v1(p_contenido);
    perform myg_nube_privado.expandir_paquete(p_contenido,false);
end $function$;

-- Comprueba exclusivamente las columnas de navegación que el guard v1 ya
-- excluye de TODOS los módulos. Mantiene encabezados, orden, IDs y todas las
-- demás celdas, incluidas las referencias d o los JSON literales.
create or replace function myg_nube_privado.tablas_solo_metadatos(p_anterior jsonb,p_nuevo jsonb)
returns boolean language plpgsql immutable set search_path=pg_catalog as $function$
declare v_antes jsonb; v_despues jsonb; v_fila jsonb; v_otra jsonb;
    v_nombre text; v_columnas jsonb; v_permitidas text[]; t integer; f integer; c integer;
begin
    if jsonb_typeof(p_anterior) is distinct from 'array' or jsonb_typeof(p_nuevo) is distinct from 'array'
        or jsonb_array_length(p_anterior)<>jsonb_array_length(p_nuevo) then return false; end if;
    for t in 0..jsonb_array_length(p_anterior)-1 loop
        v_antes:=p_anterior->t; v_despues:=p_nuevo->t;
        if v_antes=v_despues then continue; end if;
        if v_antes-'Filas'<>v_despues-'Filas' then return false; end if;
        v_nombre:=v_antes->>'Nombre';
        v_permitidas:=case v_nombre when 'myg_proyecto' then array['nombre','modificado_utc']
            when 'proyecto' then array['nombre_proyecto'] else null end;
        if v_permitidas is null or jsonb_typeof(v_antes->'Filas') is distinct from 'array'
            or jsonb_typeof(v_despues->'Filas') is distinct from 'array'
            or jsonb_array_length(v_antes->'Filas')<>jsonb_array_length(v_despues->'Filas') then return false; end if;
        v_columnas:=v_antes->'Columnas';
        for f in 0..jsonb_array_length(v_antes->'Filas')-1 loop
            v_fila:=v_antes->'Filas'->f; v_otra:=v_despues->'Filas'->f;
            if v_fila=v_otra then continue; end if;
            if jsonb_typeof(v_fila) is distinct from 'array' or jsonb_typeof(v_otra) is distinct from 'array'
                or jsonb_array_length(v_fila)<>jsonb_array_length(v_otra)
                or jsonb_array_length(v_fila)<>jsonb_array_length(v_columnas) then return false; end if;
            for c in 0..jsonb_array_length(v_columnas)-1 loop
                if v_fila->c is distinct from v_otra->c and not (v_columnas->>c)=any(v_permitidas) then return false; end if;
            end loop;
        end loop;
    end loop;
    return true;
end $function$;

create or replace function myg_nube_privado.exigir_modulos(p_anterior jsonb,p_nuevo jsonb,p_permisos jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $function$
begin
    if p_permisos='{"acu":true,"especificaciones":true,"metrados_excel":true}'::jsonb then return; end if;
    -- Una referencia d solo puede apuntar a json_documento de un documento
    -- canónico. Si solo cambian los tres metadatos de navegación del principal
    -- y sus columnas nativas permitidas, no cambia ningún módulo al resolver
    -- esa referencia. No expandir dos veces una base grande para renombrarla.
    -- Las RPC validan íntegramente p_nuevo antes de llamar a este guard.
    if myg_nube_privado.permisos_modulos_validos(p_permisos)
        and p_anterior->>'formato'='MYG_COLABORACION' and p_nuevo->>'formato'='MYG_COLABORACION'
        and p_anterior->'version'='2'::jsonb and p_nuevo->'version'='2'::jsonb
        and jsonb_typeof(p_anterior->'documento')='object'
        and jsonb_typeof(p_nuevo->'documento')='object'
        and p_anterior-array['documento','tablas']=p_nuevo-array['documento','tablas']
        and (p_anterior->'documento')-array['Nombre','ModificadoUtc','PresupuestoActivoId'] =
            (p_nuevo->'documento')-array['Nombre','ModificadoUtc','PresupuestoActivoId']
        and myg_nube_privado.tablas_solo_metadatos(p_anterior->'tablas',p_nuevo->'tablas') then
        return;
    end if;

    -- El guard v1 inspecciona TODAS las representaciones, también los textos
    -- referenciados, antes de autorizar. Un diccionario no oculta datos protegidos.
    perform myg_nube_privado.exigir_modulos_v1(
        myg_nube_privado.expandir_paquete(p_anterior),
        myg_nube_privado.expandir_paquete(p_nuevo),p_permisos);
end $function$;

create or replace function public.myg_nube_capacidades()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $function$
begin
    perform myg_nube_privado.identidad();
    return '{"paquete_compacto":2}'::jsonb;
end $function$;

revoke all on function myg_nube_privado.validar_contenido_v1(jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.exigir_modulos_v1(jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.expandir_celda(jsonb,jsonb,jsonb,text,text,boolean) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.expandir_paquete(jsonb,boolean) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.expandir_paquete(jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.validar_contenido(jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.tablas_solo_metadatos(jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.myg_nube_capacidades() from public,anon;
grant execute on function public.myg_nube_capacidades() to authenticated,service_role;

-- PASO3: sincronización e historial; conserva las comprobaciones de la migración23.
-- Aplicar después de 20261022_paquete_compacto.sql. No modifica proyectos existentes.
-- Los cambios mantienen concurrencia por revisión de proyecto, permisos por módulo
-- y UUID idempotentes. No se combinan escrituras concurrentes silenciosamente.

do $precondiciones$
begin
    if to_regprocedure('myg_nube_privado.expandir_paquete(jsonb)') is null then
        raise exception 'Aplique primero 20261022_paquete_compacto.sql';
    end if;
end $precondiciones$;

create table if not exists myg_nube_privado.historial_cambios (
    proyecto_id uuid not null references public.myg_nube_proyectos(id) on delete cascade,
    revision bigint not null,
    revision_base bigint not null check(revision_base > 0 and revision = revision_base + 1),
    usuario_id uuid not null,
    operacion_id uuid not null,
    cambios jsonb not null,
    creado_en timestamptz not null default clock_timestamp(),
    primary key(proyecto_id, revision)
);
revoke all on myg_nube_privado.historial_cambios from public, anon, authenticated, service_role;

create or replace function myg_nube_privado.cambiar_coleccion(
    p_anterior jsonb, p_cambio jsonb, p_identidad text)
returns jsonb language plpgsql immutable set search_path to pg_catalog
as $func$
declare
    v_mapa jsonb; v_salida jsonb; v_ids text[]; v_bajas text[];
    v_id text; v_elemento jsonb; v_total integer;
begin
    if jsonb_typeof(p_anterior) is distinct from 'array'
       or jsonb_typeof(p_cambio) is distinct from 'object'
       or not p_cambio ?& array['poner','quitar','orden']
       or p_cambio - array['poner','quitar','orden'] <> '{}'::jsonb
       or jsonb_typeof(p_cambio->'poner') is distinct from 'array'
       or jsonb_typeof(p_cambio->'quitar') is distinct from 'array'
       or jsonb_typeof(p_cambio->'orden') is distinct from 'array' then
        raise exception using errcode='22023',message='MYG_CAMBIOS_INVALIDOS';
    end if;
    if exists(select 1 from jsonb_array_elements(p_anterior) e
        where jsonb_typeof(e) is distinct from 'object'
           or jsonb_typeof(e->p_identidad) is distinct from 'string'
           or btrim(e->>p_identidad)='') then
        raise exception using errcode='22023',message='MYG_COLECCION_INVALIDA';
    end if;
    select coalesce(jsonb_object_agg(e->>p_identidad,e),'{}'::jsonb), count(*)
      into v_mapa,v_total from jsonb_array_elements(p_anterior) e;
    if (select count(*) from jsonb_object_keys(v_mapa)) <> v_total then
        raise exception using errcode='22023',message='MYG_IDENTIDAD_REPETIDA';
    end if;
    v_bajas:=array[]::text[];
    for v_elemento in select value from jsonb_array_elements(p_cambio->'quitar') loop
        if jsonb_typeof(v_elemento) is distinct from 'string' then
            raise exception using errcode='22023',message='MYG_CAMBIOS_INVALIDOS';
        end if;
        v_id:=v_elemento#>>'{}';
        if v_id=any(v_bajas) or not v_mapa ? v_id then
            raise exception using errcode='22023',message='MYG_BAJA_INVALIDA';
        end if;
        v_bajas:=array_append(v_bajas,v_id); v_mapa:=v_mapa-v_id;
    end loop;
    v_ids:=array[]::text[];
    for v_elemento in select value from jsonb_array_elements(p_cambio->'poner') loop
        if jsonb_typeof(v_elemento) is distinct from 'object'
           or jsonb_typeof(v_elemento->p_identidad) is distinct from 'string'
           or btrim(v_elemento->>p_identidad)='' then
            raise exception using errcode='22023',message='MYG_CAMBIOS_INVALIDOS';
        end if;
        v_id:=v_elemento->>p_identidad;
        if v_id=any(v_ids) or v_id=any(v_bajas) then
            raise exception using errcode='22023',message='MYG_IDENTIDAD_REPETIDA';
        end if;
        v_ids:=array_append(v_ids,v_id);
        v_mapa:=v_mapa||jsonb_build_object(v_id,v_elemento);
    end loop;
    if exists(select 1 from jsonb_array_elements(p_cambio->'orden') e
        where jsonb_typeof(e) is distinct from 'string') then
        raise exception using errcode='22023',message='MYG_ORDEN_INVALIDO';
    end if;
    select coalesce(array_agg(value#>>'{}' order by ord),array[]::text[])
      into v_ids from jsonb_array_elements(p_cambio->'orden') with ordinality d(value,ord);
    if cardinality(v_ids) <> (select count(*) from jsonb_object_keys(v_mapa))
       or cardinality(v_ids) <> (select count(distinct x) from unnest(v_ids) x)
       or exists(select 1 from unnest(v_ids) x where not v_mapa ? x) then
        raise exception using errcode='22023',message='MYG_ORDEN_INVALIDO';
    end if;
    select coalesce(jsonb_agg(v_mapa->x order by ord),'[]'::jsonb)
      into v_salida from unnest(v_ids) with ordinality d(x,ord);
    return v_salida;
end $func$;

create or replace function myg_nube_privado.aplicar_rutas(p_anterior jsonb,p_cambios jsonb)
returns jsonb language plpgsql immutable set search_path to pg_catalog,myg_nube_privado
as $func$
declare
    v_resultado jsonb:=p_anterior; v_operacion jsonb; v_ruta text[]; v_padre jsonb;
    v_segmento text; v_indice integer; i integer; v_quitar boolean;
begin
    if jsonb_typeof(p_cambios) is distinct from 'object'
       or p_cambios->'version' is distinct from '2'::jsonb
       or p_cambios-array['version','operaciones'] <> '{}'::jsonb
       or jsonb_typeof(p_cambios->'operaciones') is distinct from 'array'
       or jsonb_array_length(p_cambios->'operaciones')>4096 then
        raise exception using errcode='22023',message='MYG_RUTAS_INVALIDAS';
    end if;
    for v_operacion in select value from jsonb_array_elements(p_cambios->'operaciones') loop
        if jsonb_typeof(v_operacion) is distinct from 'object'
           or (select count(*) from jsonb_object_keys(v_operacion))<>2
           or jsonb_typeof(v_operacion->'ruta') is distinct from 'array'
           or jsonb_array_length(v_operacion->'ruta') not between 1 and 126
           or exists(select 1 from jsonb_array_elements(v_operacion->'ruta') s where jsonb_typeof(s)<>'string') then
            raise exception using errcode='22023',message='MYG_RUTAS_INVALIDAS';
        end if;
        v_quitar:=v_operacion?'quitar';
        if (v_quitar and v_operacion->'quitar' is distinct from 'true'::jsonb)
           or (not v_quitar and not v_operacion?'valor') then
            raise exception using errcode='22023',message='MYG_RUTAS_INVALIDAS';
        end if;
        select array_agg(value#>>'{}' order by ord) into v_ruta
          from jsonb_array_elements(v_operacion->'ruta') with ordinality d(value,ord);
        if v_ruta[1] not in ('formato','version','alcance','documento','textos','avisos','exclusiones','documentos','tablas','recursos') then
            raise exception using errcode='22023',message='MYG_RUTAS_INVALIDAS';
        end if;
        v_padre:=v_resultado;
        for i in 1..cardinality(v_ruta) loop
            v_segmento:=v_ruta[i];
            if jsonb_typeof(v_padre)='array' then
                if v_segmento!~'^(0|[1-9][0-9]*)$' or length(v_segmento)>10 then
                    raise exception using errcode='22023',message='MYG_INDICE_INVALIDO';
                end if;
                if v_segmento::bigint>2147483647 then
                    raise exception using errcode='22023',message='MYG_INDICE_INVALIDO';
                end if;
                v_indice:=v_segmento::integer;
                if v_indice>=jsonb_array_length(v_padre) or (i=cardinality(v_ruta) and v_quitar) then
                    raise exception using errcode='22023',message='MYG_INDICE_INVALIDO';
                end if;
                if i<cardinality(v_ruta) then v_padre:=v_padre->v_indice; end if;
            elsif jsonb_typeof(v_padre)='object' then
                if (i<cardinality(v_ruta) or v_quitar) and not v_padre?v_segmento then
                    raise exception using errcode='22023',message='MYG_RUTA_INEXISTENTE';
                end if;
                if i<cardinality(v_ruta) then v_padre:=v_padre->v_segmento; end if;
            else
                raise exception using errcode='22023',message='MYG_RUTA_INEXISTENTE';
            end if;
        end loop;
        if v_quitar then v_resultado:=v_resultado#-v_ruta;
        else v_resultado:=jsonb_set(v_resultado,v_ruta,v_operacion->'valor',true); end if;
    end loop;
    return v_resultado;
end $func$;

create or replace function myg_nube_privado.aplicar_cambios(p_anterior jsonb,p_cambios jsonb)
returns jsonb language plpgsql immutable set search_path to pg_catalog,myg_nube_privado
as $func$
declare v_resultado jsonb; v_nombre text; v_identidad text;
begin
    if jsonb_typeof(p_anterior) is distinct from 'object'
       or p_anterior->>'formato' is distinct from 'MYG_COLABORACION'
       or p_anterior->'version' is distinct from '2'::jsonb then
        raise exception using errcode='22023',message='MYG_PAQUETE_COMPACTO_REQUERIDO';
    end if;
    if p_cambios->'version'='2'::jsonb then
        v_resultado:=myg_nube_privado.aplicar_rutas(p_anterior,p_cambios);
        if v_resultado->>'formato' is distinct from 'MYG_COLABORACION'
           or v_resultado->'version' is distinct from '2'::jsonb then
            raise exception using errcode='22023',message='MYG_PAQUETE_COMPACTO_REQUERIDO';
        end if;
        return v_resultado;
    end if;
    if jsonb_typeof(p_cambios) is distinct from 'object'
       or p_cambios->'version' is distinct from '1'::jsonb
       or jsonb_typeof(p_cambios->'campos') is distinct from 'object'
       or p_cambios-array['version','campos','documentos','tablas','recursos'] <> '{}'::jsonb
       or (p_cambios->'campos')-array['formato','version','alcance','documento','textos','avisos','exclusiones'] <> '{}'::jsonb then
        raise exception using errcode='22023',message='MYG_CAMBIOS_INVALIDOS';
    end if;
    v_resultado:=p_anterior||(p_cambios->'campos');
    foreach v_nombre in array array['documentos','tablas','recursos'] loop
        if p_cambios ? v_nombre then
            v_identidad:=case v_nombre when 'documentos' then 'Id' when 'tablas' then 'Nombre' else 'Referencia' end;
            v_resultado:=jsonb_set(v_resultado,array[v_nombre],
                myg_nube_privado.cambiar_coleccion(p_anterior->v_nombre,p_cambios->v_nombre,v_identidad));
        end if;
    end loop;
    if v_resultado->>'formato' is distinct from 'MYG_COLABORACION'
       or v_resultado->'version' is distinct from '2'::jsonb then
        raise exception using errcode='22023',message='MYG_PAQUETE_COMPACTO_REQUERIDO';
    end if;
    return v_resultado;
end $func$;

-- Recuperación interna sin copiar un snapshot completo por cada edición.
-- Las escrituras antiguas siguen dejando checkpoints en el historial existente.
create or replace function myg_nube_privado.reconstruir_revision(p_id uuid,p_revision bigint)
returns jsonb language plpgsql stable security definer
set search_path to pg_catalog,myg_nube_privado
as $func$
declare v_contenido jsonb; v_revision bigint; v_delta jsonb; v_checkpoint jsonb;
begin
    select revision,contenido into v_revision,v_contenido from public.myg_nube_historial
      where proyecto_id=p_id and revision<=p_revision order by revision desc limit 1;
    if v_revision is null then
        raise exception using errcode='22023',message='MYG_REVISION_NO_RECUPERABLE';
    end if;
    while v_revision<p_revision loop
        select contenido into v_checkpoint from public.myg_nube_historial
          where proyecto_id=p_id and revision=v_revision+1;
        if found then
            v_contenido:=v_checkpoint;
        else
            select cambios into v_delta from myg_nube_privado.historial_cambios
              where proyecto_id=p_id and revision_base=v_revision and revision=v_revision+1;
            if not found then
                raise exception using errcode='22023',message='MYG_REVISION_NO_RECUPERABLE';
            end if;
            v_contenido:=myg_nube_privado.aplicar_cambios(v_contenido,v_delta);
        end if;
        v_revision:=v_revision+1;
    end loop;
    return v_contenido;
end $func$;

create or replace function public.myg_nube_revision(p_id uuid)
returns jsonb language plpgsql stable security definer
set search_path to pg_catalog,myg_nube_privado
as $func$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_resultado jsonb;
begin
    select jsonb_build_object('id',p.id,'codigo',p.codigo,'nombre',p.nombre,'rol',m.rol,
        'revision',p.revision,'alcance',p.alcance,'permisos_modulos',m.permisos_modulos)
      into v_resultado from public.myg_nube_proyectos p
      join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario
      where p.id=p_id;
    if v_resultado is null then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    return v_resultado;
end $func$;

create or replace function public.myg_nube_guardar_cambios(
    p_id uuid,p_operacion uuid,p_revision bigint,p_cambios jsonb)
returns jsonb language plpgsql security definer
set search_path to pg_catalog,myg_nube_privado set statement_timeout to '60s'
as $func$
declare
    v_usuario uuid:=myg_nube_privado.identidad();
    v_proyecto public.myg_nube_proyectos%rowtype;
    v_anterior public.myg_nube_operaciones%rowtype;
    v_rol text; v_permisos jsonb; v_solicitud jsonb; v_respuesta jsonb; v_nuevo jsonb;
begin
    if p_operacion is null or p_operacion='00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision<1 or p_revision=9223372036854775807
       or jsonb_typeof(p_cambios) is distinct from 'object'
       or p_cambios->'version' not in ('1'::jsonb,'2'::jsonb)
       or p_cambios->'version' is null
       or (p_cambios->'version'='1'::jsonb and jsonb_typeof(p_cambios->'campos') is distinct from 'object')
       or (p_cambios->'version'='2'::jsonb and jsonb_typeof(p_cambios->'operaciones') is distinct from 'array')
       or octet_length(p_cambios::text)>133169152 then
        raise exception using errcode='22023',message='MYG_CAMBIOS_INVALIDOS';
    end if;
    select * into v_proyecto from public.myg_nube_proyectos where id=p_id for update;
    select rol,permisos_modulos into v_rol,v_permisos from public.myg_nube_miembros
      where proyecto_id=p_id and usuario_id=v_usuario;
    -- Un reintento nunca recupera acceso revocado, ni siquiera si antes fue aplicado.
    if v_proyecto.id is null or v_rol is null or v_rol not in ('propietario','administrador','editor') then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-op:'||v_usuario::text||':'||p_operacion::text,0));
    v_solicitud:=jsonb_build_object('tipo','cambios','revision',p_revision,'cambios',p_cambios);
    select * into v_anterior from public.myg_nube_operaciones
      where usuario_id=v_usuario and operacion_id=p_operacion;
    if found then
        if v_anterior.proyecto_id<>p_id or v_anterior.solicitud<>v_solicitud then
            raise exception using errcode='22023',message='MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return v_anterior.respuesta;
    end if;
    if v_proyecto.revision<>p_revision then
        -- Los conflictos conservan la respuesta exacta, aunque cambie el estado posterior.
        v_respuesta:=jsonb_build_object('estado','conflicto','revision',v_proyecto.revision,
            'contenido',v_proyecto.contenido,'operacion_id',p_operacion);
    else
        v_nuevo:=myg_nube_privado.aplicar_cambios(v_proyecto.contenido,p_cambios);
        perform myg_nube_privado.validar_contenido(v_nuevo);
        if v_nuevo->>'alcance' is distinct from v_proyecto.alcance then
            raise exception using errcode='22023',message='MYG_ALCANCE_INVALIDO';
        end if;
        perform myg_nube_privado.exigir_modulos(v_proyecto.contenido,v_nuevo,v_permisos);
        -- Primer cambio incremental: asegurar una base de reconstrucción, sin alterar
        -- snapshots existentes. En adelante se guarda un checkpoint cada 20 revisiones.
        if not exists(select 1 from myg_nube_privado.historial_cambios where proyecto_id=p_id) then
            insert into public.myg_nube_historial(proyecto_id,revision,usuario_id,contenido)
              values(p_id,v_proyecto.revision,v_usuario,v_proyecto.contenido) on conflict(proyecto_id,revision) do nothing;
        end if;
        update public.myg_nube_proyectos set contenido=v_nuevo,revision=revision+1,
            actualizado_en=clock_timestamp() where id=p_id returning * into v_proyecto;
        insert into myg_nube_privado.historial_cambios(proyecto_id,revision,revision_base,usuario_id,operacion_id,cambios)
          values(p_id,v_proyecto.revision,p_revision,v_usuario,p_operacion,p_cambios);
        if mod(v_proyecto.revision,20)=0 then
            insert into public.myg_nube_historial(proyecto_id,revision,usuario_id,operacion_id,contenido)
              values(p_id,v_proyecto.revision,v_usuario,p_operacion,v_nuevo);
        end if;
        -- La solicitud ya contiene solo cambios; el ACK no duplica la base entera.
        v_respuesta:=jsonb_build_object('estado','aplicada','revision',v_proyecto.revision,'operacion_id',p_operacion);
    end if;
    insert into public.myg_nube_operaciones(usuario_id,operacion_id,proyecto_id,solicitud,respuesta)
      values(v_usuario,p_operacion,p_id,v_solicitud,v_respuesta);
    return v_respuesta;
end $func$;

create or replace function public.myg_nube_capacidades()
returns jsonb language plpgsql stable security definer
set search_path to pg_catalog,myg_nube_privado
as $func$
begin
    perform myg_nube_privado.identidad();
    return jsonb_build_object('paquete_compacto',2,'cambios',1,'historial_intervalo',20);
end $func$;

revoke all on function myg_nube_privado.cambiar_coleccion(jsonb,jsonb,text) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.aplicar_rutas(jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.aplicar_cambios(jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function myg_nube_privado.reconstruir_revision(uuid,bigint) from public,anon,authenticated,service_role;
revoke all on function public.myg_nube_revision(uuid) from public,anon;
revoke all on function public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb) from public,anon;
revoke all on function public.myg_nube_capacidades() from public,anon;
grant execute on function public.myg_nube_revision(uuid) to authenticated,service_role;
grant execute on function public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb) to authenticated,service_role;
grant execute on function public.myg_nube_capacidades() to authenticated,service_role;

-- Verificación de instalación sin invocar RPC autenticados como administrador.
do $instalador_verificar$
declare v_firma text;
begin
    foreach v_firma in array array[
        'public.myg_nube_capacidades()',
        'public.myg_nube_revision(uuid)',
        'public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)'
    ] loop
        if not exists(select 1 from pg_catalog.pg_proc p
            where p.oid=pg_catalog.to_regprocedure(v_firma) and p.prokind='f'
              and p.prosecdef and p.prorettype='jsonb'::regtype)
           or not pg_catalog.has_function_privilege('authenticated',v_firma,'EXECUTE')
           or pg_catalog.has_function_privilege('anon',v_firma,'EXECUTE') then
            raise exception 'Instalación cancelada: la función % o sus permisos no quedaron correctamente instalados.',v_firma;
        end if;
    end loop;
    if pg_catalog.to_regclass('myg_nube_privado.historial_cambios') is null then
        raise exception 'Instalación cancelada: falta el historial de cambios incrementales.';
    end if;
end $instalador_verificar$;

notify pgrst,'reload schema';
commit;

select 'ACTUALIZACION_COMPLETA'::text as resultado,
       pg_catalog.to_regprocedure('public.myg_nube_capacidades()') is not null as paquete_compacto,
       pg_catalog.to_regprocedure('public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)') is not null as sincronizacion_incremental,
       'Cierre y vuelva a abrir Nube MYG; después reintente la publicación pendiente.'::text as siguiente_paso;
