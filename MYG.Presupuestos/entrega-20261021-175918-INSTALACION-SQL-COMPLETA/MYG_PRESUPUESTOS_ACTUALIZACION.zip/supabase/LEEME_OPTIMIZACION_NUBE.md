# Publicaciones compactas y sincronización incremental

Esta actualización reduce la representación de la base compartida y el tamaño de
las ediciones enviadas. SQLite sigue siendo la copia de trabajo local; la nube
conserva datos editables, revisiones y permisos. No se sustituye la colaboración
por un archivo ZIP que todos tengan que sobrescribir.

## Si los SQL anteriores se cancelaron por falta de una migración

Los mensajes `aplique primero 20261021_contenido_grande.sql` y después
`Aplique primero 20261022_paquete_compacto.sql` significan que las actualizaciones
se cancelaron antes de instalar las funciones. Recargar el esquema no instala
esas funciones por sí solo.

Ejecute **todo** `migraciones/20261024_instalar_optimizacion_completa.sql` en una
consulta nueva del SQL Editor de su proyecto Supabase. Este único archivo incluye
el requisito de tamaño y las actualizaciones compacta e incremental en el orden
correcto. Es transaccional y también admite una instalación parcial o completa
previa; cualquier error revierte todos los pasos de esa ejecución.

Al terminar debe aparecer una fila con `resultado = ACTUALIZACION_COMPLETA`,
`paquete_compacto = true` y `sincronizacion_incremental = true`. Después cierre y
vuelva a abrir Nube MYG y reintente la publicación pendiente. No hace falta
recompilar la aplicación si ya aplicó la entrega de los 26 archivos.

Este complemento entrega cuatro archivos: este manual actualizado, el instalador
SQL único y dos archivos de pruebas. Los archivos de pruebas se ejecutan solo en
PostgreSQL desechable; el único que se ejecuta en Supabase real es el instalador
ubicado en `supabase/migraciones/`.

## Contenido y base de esta entrega

La entrega anterior de código `MYG_PRESUPUESTOS_ACTUALIZACION.zip` contiene 26 archivos nuevos o
modificados, con sus rutas originales: 13 archivos completos para reemplazar y
13 para crear. No contiene el proyecto completo, ejecutables, runtime, bases de
usuario, configuración de conexión ni carpetas `.git`, `.vs`, `bin`, `obj` o
paquetes restaurables. No hay archivos que eliminar.

La base utilizada es `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`,
commit `4ba66afdfba50b572fc077b272d86692e6fc8df6`. Se comprobó que seguía siendo
el último commit remoto al preparar esta entrega. Si tiene cambios locales o
posteriores en los archivos entregados, compárelos antes de reemplazarlos.
Publicar el ZIP en `bimchimbote-droid/DESCARGAS` no publica el código en `main`.

## Actualizar una instalación existente

1. Conserve una copia de su SQLite y respalde o confirme sus cambios locales en
   Git. Descargue y extraiga el ZIP fuera del repositorio. Copie sus archivos a la
   raíz del repositorio local conservando las rutas incluidas. Este complemento
   solo agrega archivos en `scripts` y `supabase` y reemplaza este manual; requiere
   tener aplicada la entrega anterior de los 26 archivos de código.
   Mantenga la carpeta `.git` y los archivos que no se incluyen. No sustituya la
   carpeta completa del proyecto. En Supabase, use los mecanismos de respaldo
   habituales antes de actualizar funciones.
2. En el editor SQL de **su proyecto Supabase**, ejecute completo
   `migraciones/20261024_instalar_optimizacion_completa.sql`. Incluye las
   actualizaciones 21, 22 y 23, comprueba el contrato previo de usuarios/permisos y
   admite repetición sin convertir ni eliminar obras, miembros o intentos anteriores.
3. **Si ya aplicó y compiló los 26 archivos anteriores, este complemento no
   requiere recompilar:** continúe con los pasos 4 y 5. Si aún debe actualizar
   la aplicación, abra `MYG.Presupuestos.sln` en Visual Studio 2026 y restaure los paquetes con
   el SDK .NET 10.0.100 o uno compatible con `global.json`. Compile y ejecute las
   pruebas indicadas abajo. Para compilar el conector fuera de Revit se utiliza
   `UseRevitReferencePackages=true`; con Revit 2027 instalado puede usar sus API
   locales según `LEEME.md`. Cierre MYG antes de actualizar su instalación a partir
   de la compilación. Conserve `nube-myg.json`, si su distribución lo utiliza, y
   su configuración local existente. Esta entrega no incluye claves ni modifica
   la conexión a Supabase. Actualice también las DLL de la aplicación compilada;
   cambiar solo el ejecutable no incorpora los cambios de Core y Colaboracion.
4. Para el intento antiguo que excedía el límite: revise primero **Mis proyectos**.
   Si no fue publicado, en **Publicaciones pendientes** elija **Retirar y conservar
   copia** y cree una publicación nueva desde el SQLite. Reintentar un intento
   anterior conserva sus bytes y su identificador; no lo transforma a escondidas.
5. Las publicaciones nuevas usan el formato compacto. Todos los colaboradores
   que abran esas publicaciones deben utilizar la aplicación actualizada. Las
   publicaciones anteriores conservan su protocolo hasta que se cree una nueva
   publicación compacta; no se altera su historial automáticamente.

La instalación de funciones en el Supabase real y la ejecución visual en Windows
son pasos separados de las pruebas Linux. No se han ejecutado contra la cuenta
del usuario desde este entorno.

## Qué cambia

- **Paquete v2:** celdas compactas con tipo exacto, un solo documento principal,
  diccionario de textos repetidos y referencias a documentos conocidos en
  `myg_proyecto.json_documento`. Los datos nativos no se eliminan por parecer
  redundantes. La reconstrucción admite tanto v1 como v2.
- **Menor memoria al preparar:** se puede escribir el paquete compacto directamente
  desde las tablas leídas, sin construir antes el JSON v1 completo.
- **Ediciones incrementales:** consulta de revisión y permisos sin descargar toda
  la base cuando no ha cambiado. Se elige la diferencia más pequeña entre bloques
  modificados y rutas a propiedades o celdas concretas. Un renombrado no envía el
  documento completo; las listas que cambian de longitud pueden requerir un bloque
  completo. Los cambios se aplican en una transacción y
  conservan el control de revisión global: dos ediciones incompatibles producen
  un conflicto, nunca una combinación silenciosa.
- **Reintentos duraderos:** SQLite conserva el cuerpo incremental exacto antes
  de enviarlo. Una respuesta perdida no duplica la operación ni reemplaza un
  borrador posterior. Los intentos antiguos ya enviados no cambian de protocolo.
- **Historial:** diferencias entre revisiones y una instantánea cada 20 revisiones,
  con una base inicial para reconstruirlas. Se preservan los registros antiguos.
- **Adjuntos:** los archivos externos continúan en almacenamiento privado con
  SHA-256; una copia local ya verificada evita una descarga repetida. Los BLOB
  nativos permanecen tipados en el paquete para conservar su reconstrucción.
- **Tamaños visibles:** la lista de pendientes distingue SQLite original y paquete
  guardado. Los adjuntos preparados pueden reducir posteriormente el envío.

El límite de entrada compacta sigue siendo 127 MiB. La expansión de referencias
está acotada a 512 MiB para impedir que un paquete pequeño genere datos sin límite.
La compresión del transporte no sustituye estas comprobaciones.

## Comprobar la actualización

Desde la raíz del repositorio con el SDK fijado en `global.json`:

```bash
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
bash scripts/pruebas/Probar-ContenidoGrande.sh
```

El último comando requiere Docker y crea únicamente PostgreSQL desechable sin
puertos publicados. Genera paquetes sintéticos con el código C#, prueba las
migraciones y elimina el contenedor al terminar; no conecta a Supabase real.

Para comprobar el instalador único desde los cuatro estados previos admitidos
(límite antiguo, tamaño actualizado, formato compacto e instalación completa):

```bash
bash scripts/pruebas/Probar-InstalacionNube.sh
```

También se comprueba que un error posterior al primer paso revierte toda la
instalación, conservando los datos y el validador anterior.

Validación de este complemento: el ejecutor terminó correctamente en PostgreSQL
17 con 24 comprobaciones en cada uno de los cuatro estados (96 en total) y tres
comprobaciones de reversión ante un error provocado. La instalación se ejecutó
dos veces en cada estado para comprobar la repetición. No se modificó el C# de
la entrega anterior ni se repitió su compilación completa para esta corrección SQL.

Las pruebas incluyen tipos SQLite, Int64 y decimales, bases con varias obras,
adjuntos, privacidad, permisos de módulos, conflictos entre dos usuarios,
recuperación tras perder una respuesta y conservación de intentos anteriores.
El benchmark informa bytes antes y después sobre datos sintéticos; no estima ni
garantiza el tamaño de una base privada que no se haya medido.

En una prueba sintética de 400 partidas y 4.800 insumos, el SQLite ocupó
42.876.928 bytes: el paquete anterior ocupó 78.529.437 bytes y el compacto
39.810.772 bytes, un 49,3 % menos. El guardado de un renombrado real como editor
con los tres módulos bloqueados terminó en unos 3,1 segundos en PostgreSQL 17.
La aplicación se publicó para Windows x64 con su runtime; la comprobación visual
de esa publicación anterior sigue pendiente de ejecución en Windows. Ese binario
y su runtime no forman parte de este ZIP de fuentes.

## Confirmar los cambios del código en GitHub

Después de aplicar y validar los archivos, abra **Visual Studio → Cambios de Git**.
Revise los archivos de ambas entregas y confirme que su rama de trabajo es `main`.
Si la entrega anterior ya está confirmada, este complemento solo cambia cuatro
rutas. Haga Commit con
un mensaje como `Optimizar paquetes y sincronización de Nube MYG`, haga Push y
compruebe en GitHub que el commit aparece en `bimchimbote-droid/MYG.Presupuestos`,
rama `main`. Si GitHub contiene cambios posteriores, incorpórelos y resuelva las
diferencias antes de publicar; no haga Push forzado. Esta entrega no realiza esas
acciones por usted y no cambia la visibilidad de ningún repositorio.
