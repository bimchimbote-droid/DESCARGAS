-- SOLO PostgreSQL desechable, con usuarios_myg_roles.sql ya ejecutado.
-- El ejecutor usa bases separadas para estados32MiB,127MiB,compacto e incremental.
-- Nunca ejecutar este fixture en el Supabase de un usuario.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren una base desechable.'; end $$;
\endif

reset role;
create table qa.antes_instalacion as select
    (select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p) proyectos,
    (select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h) historial,
    (select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m) miembros,
    (select coalesce(jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id),'[]'::jsonb) from public.myg_nube_operaciones o) operaciones,
    (select coalesce(jsonb_agg(to_jsonb(i) order by auth_usuario_id),'[]'::jsonb) from myg_nube_privado.identidades_verificadas i) identidades,
    (select rolconfig from pg_roles where rolname='authenticated') rolconfig,
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'definer',p.prosecdef) order by p.oid)
      from pg_proc p where p.oid in (
        'myg_nube_privado.validar_contenido(jsonb)'::regprocedure,
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure)) atributos,
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'acl',p.proacl) order by p.oid)
      from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure)) acl_rpc,
    (select jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definicion',pg_get_functiondef(p.oid))
      from pg_proc p where p.oid=to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)')) validador_anterior,
    null::jsonb historial_incremental,
    (select count(*) from qa.resultados) resultados_antes;

do $$ begin
    if to_regclass('myg_nube_privado.historial_cambios') is not null then
        execute 'update qa.antes_instalacion set historial_incremental=(select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),''[]''::jsonb) from myg_nube_privado.historial_cambios h)';
    end if;
end $$;

\ir ../migraciones/20261024_instalar_optimizacion_completa.sql

select qa.exige((select proyectos=(select coalesce(jsonb_agg(to_jsonb(p) order by id),'[]'::jsonb) from public.myg_nube_proyectos p)
    from qa.antes_instalacion),'Instalador único: conserva proyectos y sus revisiones');
select qa.exige((select historial=(select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from public.myg_nube_historial h)
    from qa.antes_instalacion),'Instalador único: conserva historial anterior');
select qa.exige((select miembros=(select coalesce(jsonb_agg(to_jsonb(m) order by proyecto_id,usuario_id),'[]'::jsonb) from public.myg_nube_miembros m)
    from qa.antes_instalacion),'Instalador único: conserva miembros, roles y máscaras');
select qa.exige((select operaciones=(select coalesce(jsonb_agg(to_jsonb(o) order by usuario_id,operacion_id),'[]'::jsonb) from public.myg_nube_operaciones o)
    from qa.antes_instalacion),'Instalador único: conserva UUID, solicitudes y respuestas históricas');
select qa.exige((select identidades=(select coalesce(jsonb_agg(to_jsonb(i) order by auth_usuario_id),'[]'::jsonb) from myg_nube_privado.identidades_verificadas i)
    from qa.antes_instalacion),'Instalador único: conserva vinculaciones de identidad');
select qa.exige((select rolconfig is not distinct from (select rolconfig from pg_roles where rolname='authenticated')
    from qa.antes_instalacion),'Instalador único: conserva configuración del rol authenticated');
select qa.exige((select atributos=(select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'definer',p.prosecdef) order by p.oid)
      from pg_proc p where p.oid in (
        'myg_nube_privado.validar_contenido(jsonb)'::regprocedure,
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure))
    from qa.antes_instalacion),'Instalador único: conserva OID, propietario y SECURITY de validador y RPC existentes');
-- El validador del fixture antiguo nace con EXECUTE público por defecto; la
-- migración22 lo restringe deliberadamente. Su OID/propietario sí deben conservarse.
-- Los tres RPC públicos existentes, en cambio, conservan sus ACL íntegramente.
select qa.exige((select acl_rpc=(select jsonb_agg(jsonb_build_object('oid',p.oid,'acl',p.proacl) order by p.oid)
      from pg_proc p where p.oid in (
        'public.myg_nube_crear(uuid,text,jsonb,text)'::regprocedure,
        'public.myg_nube_abrir(uuid)'::regprocedure,
        'public.myg_nube_guardar(uuid,uuid,bigint,jsonb)'::regprocedure))
    from qa.antes_instalacion),'Instalador único: conserva ACL de los tres RPC existentes');
select qa.exige((select validador_anterior is null or validador_anterior=(
    select jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definicion',pg_get_functiondef(p.oid))
    from pg_proc p where p.oid=to_regprocedure('myg_nube_privado.validar_contenido_v1(jsonb)'))
    from qa.antes_instalacion),'Instalador único: conserva el validador v1 ya existente');
select qa.exige((select historial_incremental is null or historial_incremental=(
    select coalesce(jsonb_agg(to_jsonb(h) order by proyecto_id,revision),'[]'::jsonb) from myg_nube_privado.historial_cambios h)
    from qa.antes_instalacion),'Instalador único: conserva diferencias incrementales existentes');

create table qa.instalacion_primera as select
    (select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
      from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace)) funciones;
\ir ../migraciones/20261024_instalar_optimizacion_completa.sql
select qa.exige((select funciones=(select jsonb_agg(jsonb_build_object('oid',p.oid,'owner',p.proowner,'acl',p.proacl,'definicion',pg_get_functiondef(p.oid)) order by p.oid)
      from pg_proc p where p.pronamespace in ('public'::regnamespace,'myg_nube_privado'::regnamespace))
    from qa.instalacion_primera),'Instalador único: repetir conserva definiciones, OID, propietarios y ACL');
select qa.exige((select strpos(prosrc,'MYG_CONTENIDO_INVALIDO_MAX_127_MIB')>0 and strpos(prosrc,'133169152')>0
    from pg_proc where oid='myg_nube_privado.validar_contenido_v1(jsonb)'::regprocedure),
    'Instalador único: incorpora requisito127MiB en el validador original');
select qa.exige(to_regprocedure('public.myg_nube_capacidades()') is not null
    and to_regprocedure('public.myg_nube_revision(uuid)') is not null
    and to_regprocedure('public.myg_nube_guardar_cambios(uuid,uuid,bigint,jsonb)') is not null,
    'Instalador único: instala las tres funciones públicas requeridas');
-- snapshot(uuid,uuid) pertenece al contrato anterior y conserva su ACL heredada.
-- Se comprueban todas las firmas nuevas, envueltas y respaldadas por22/23;
-- coalesce con acldefault también detecta EXECUTE público implícito.
with auxiliares as (
    select to_regprocedure(firma) oid from unnest(array[
        'myg_nube_privado.validar_contenido_v1(jsonb)',
        'myg_nube_privado.exigir_modulos_v1(jsonb,jsonb,jsonb)',
        'myg_nube_privado.expandir_celda(jsonb,jsonb,jsonb,text,text,boolean)',
        'myg_nube_privado.expandir_paquete(jsonb,boolean)',
        'myg_nube_privado.expandir_paquete(jsonb)',
        'myg_nube_privado.validar_contenido(jsonb)',
        'myg_nube_privado.tablas_solo_metadatos(jsonb,jsonb)',
        'myg_nube_privado.exigir_modulos(jsonb,jsonb,jsonb)',
        'myg_nube_privado.cambiar_coleccion(jsonb,jsonb,text)',
        'myg_nube_privado.aplicar_rutas(jsonb,jsonb)',
        'myg_nube_privado.aplicar_cambios(jsonb,jsonb)',
        'myg_nube_privado.reconstruir_revision(uuid,bigint)']) firma
)
select qa.exige((select count(oid)=12 from auxiliares) and not exists(
    select 1 from auxiliares f join pg_proc p on p.oid=f.oid
    cross join lateral aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
    where a.privilege_type='EXECUTE'
      and a.grantee in (0,'anon'::regrole,'authenticated'::regrole,'service_role'::regrole)),
    'Instalador único: auxiliares, backups y reconstrucción permanecen privados');
select qa.exige(not has_table_privilege('authenticated','myg_nube_privado.historial_cambios','SELECT')
    and not has_table_privilege('authenticated','myg_nube_privado.historial_cambios','INSERT')
    and not has_table_privilege('anon','myg_nube_privado.historial_cambios','SELECT'),
    'Instalador único: historial incremental no concede acceso directo');
select qa.exige(not has_table_privilege('authenticated','public.myg_nube_proyectos','UPDATE')
    and not has_table_privilege('authenticated','public.myg_nube_miembros','UPDATE'),
    'Instalador único: conserva prohibición de DML directo');

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_nube_capacidades()='{"paquete_compacto":2,"cambios":1,"historial_intervalo":20}'::jsonb,
    'Instalador único: RPC autenticado anuncia formato y cambios compatibles');
reset request.jwt.claim.sub;
select qa.rechaza($$select public.myg_nube_capacidades()$$,'42501',
    'Instalador único: capacidades sin identidad no autentican al usuario');
reset role;
set role anon;
select qa.rechaza($$select public.myg_nube_capacidades()$$,'42501',
    'Instalador único: anon no ejecuta capacidades');
select qa.rechaza($$select public.myg_nube_guardar_cambios(gen_random_uuid(),gen_random_uuid(),1,'{}')$$,'42501',
    'Instalador único: anon no ejecuta guardado incremental');
reset role;

create table qa.instalador_paquete as select '{
    "formato":"MYG_COLABORACION","version":2,"alcance":"obra",
    "documento":{"Id":"INSTALADOR-A","Nombre":"Obra de prueba"},"documentos":[],
    "textos":["Texto compartido"],"recursos":[],
    "tablas":[{"Nombre":"myg_proyecto","Columnas":["id","json_documento","nombre"],
        "Filas":[["INSTALADOR-A",["d","INSTALADOR-A"],["s",0]]]},
        {"Nombre":"caso_codec","Columnas":["entero","real","vacio"],
        "Filas":[[["i","9223372036854775807"],["r","-0"],null]]}]
}'::jsonb contenido;
select myg_nube_privado.validar_contenido(contenido) from qa.instalador_paquete;
select qa.exige((select myg_nube_privado.expandir_paquete(contenido)#>>'{tablas,0,Filas,0,1,Tipo}'='texto'
    and (myg_nube_privado.expandir_paquete(contenido)#>>'{tablas,0,Filas,0,1,Valor}')::jsonb=contenido->'documento'
    and myg_nube_privado.expandir_paquete(contenido)#>>'{tablas,0,Filas,0,2,Valor}'='Texto compartido'
    from qa.instalador_paquete),'Instalador único: decodifica referencias de documento y diccionario');
select qa.exige((select myg_nube_privado.expandir_paquete(contenido)#>>'{tablas,1,Filas,0,0,Valor}'='9223372036854775807'
    and myg_nube_privado.expandir_paquete(contenido)#>>'{tablas,1,Filas,0,1,Valor}'='-0'
    and myg_nube_privado.expandir_paquete(contenido)#>>'{tablas,1,Filas,0,2,Tipo}'='nulo'
    from qa.instalador_paquete),'Instalador único: conserva Int64, real y nulo');
select qa.rechaza($$select myg_nube_privado.validar_contenido(jsonb_set(contenido,'{tablas,0,Filas,0,2}','["s",99]')) from qa.instalador_paquete$$,
    '22023','Instalador único: rechaza referencias inexistentes tras instalación');
select qa.rechaza($$select myg_nube_privado.validar_contenido('[]'::jsonb)$$,
    '22023','Instalador único: conserva rechazo de contenido escalar');

select format('PRUEBAS INSTALADOR COMPLETADAS: %s',count(*)-(select resultados_antes from qa.antes_instalacion))
    from qa.resultados;
