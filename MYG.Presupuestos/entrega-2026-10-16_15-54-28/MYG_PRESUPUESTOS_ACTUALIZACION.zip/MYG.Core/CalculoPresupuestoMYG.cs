using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

// Un cálculo vive únicamente durante una operación/actualización del editor.
// El documento es mutable: cree otra instancia después de editarlo. No hay
// cachés globales ni resultados persistidos en el presupuesto.
public sealed class MYGCalculoPresupuesto
{
    private readonly MYGPresupuestoDocumento presupuesto;
    private Dictionary<string, MYGInsumo> insumos;
    private Dictionary<string, ItemPresupuestoDelphin> subpartidas;
    private Dictionary<string, List<ItemPresupuestoDelphin>> hijos;
    private readonly Dictionary<string, MYGResultadoACU> analisis = new(StringComparer.Ordinal);
    private readonly Dictionary<string, int> profundidades = new(StringComparer.Ordinal);
    private readonly Dictionary<ItemPresupuestoDelphin, bool> conserva = new();
    private readonly Dictionary<ItemPresupuestoDelphin, decimal> cantidades = new();
    private readonly Dictionary<ItemPresupuestoDelphin, decimal> totales = new();
    private MYGResumenCostos resumen;
    private List<MYGInsumoConsolidado> consolidado;

    internal MYGCalculoPresupuesto(MYGPresupuestoDocumento presupuesto)
    { this.presupuesto = presupuesto ?? throw new ArgumentNullException(nameof(presupuesto)); }

    public MYGPresupuestoDocumento Presupuesto => presupuesto;

    private decimal FactorIgv(MYGInsumo insumo) =>
        presupuesto.Costos.ConfiguracionCostoDirecto?.IncluirIgv(insumo.Grupo) == true
            ? 1m + insumo.IGVPorcentaje / 100m : 1m;

    private decimal PrecioInsumo(MYGInsumo insumo) => insumo.Precio * FactorIgv(insumo);

    // Sólo se añade información a las firmas históricas cuando el IGV cambia
    // un importe. Se recorren las subpartidas porque las firmas antiguas no
    // incluían sus precios; nunca se grava otra vez el precio de una subpartida.
    internal List<object> EfectosIgv(ItemPresupuestoDelphin raiz)
    {
        var efectos = new List<object>();
        if (presupuesto.Costos.ConfiguracionCostoDirecto == null) return efectos;
        var pendientes = new Stack<ItemPresupuestoDelphin>();
        var visitadas = new HashSet<ItemPresupuestoDelphin>();
        pendientes.Push(raiz);
        while (pendientes.TryPop(out var partida))
        {
            if (!visitadas.Add(partida)) continue;
            decimal manoObra = partida.Costos.Analisis.Where(r => r.Grupo == MYGGrupoRecurso.ManoObra)
                .Sum(r => Insumo(r.InsumoId) is { } insumo
                    ? MYGMotorPresupuestos.Dinero(presupuesto, CantidadRecurso(partida.Costos, r, insumo.Unidad) * PrecioInsumo(insumo)) : 0);
            foreach (var r in partida.Costos.Analisis)
            {
                if (r.Grupo == MYGGrupoRecurso.Subpartidas)
                {
                    if (Subpartida(r.SubpartidaIdLocal) is { } sub) pendientes.Push(sub);
                    continue;
                }
                var insumo = Insumo(r.InsumoId);
                if (insumo == null || FactorIgv(insumo) == 1m) continue;
                decimal precio = r.Modo == MYGModoCantidad.PorcentajeManoObra ? manoObra : insumo.Precio;
                decimal cantidad = CantidadRecurso(partida.Costos, r, insumo.Unidad);
                decimal divisor = r.Modo == MYGModoCantidad.PorcentajeManoObra ? 100m : 1m;
                if (MYGMotorPresupuestos.Dinero(presupuesto, cantidad * precio / divisor) ==
                    MYGMotorPresupuestos.Dinero(presupuesto, cantidad * precio * FactorIgv(insumo) / divisor)) continue;
                efectos.Add(new { Partida = partida.IdLocalMYG ?? partida.Id, Recurso = r.Id,
                    Cantidad = cantidad, Precio = precio * FactorIgv(insumo) });
            }
            if (MYGProyectoStorage.EsTitulo(partida))
                foreach (var hijo in presupuesto.Items.Where(x => x.ParentId == partida.Id)) pendientes.Push(hijo);
        }
        return efectos;
    }

    private decimal CantidadRecurso(MYGDatosPartida partida, MYGRecursoACU recurso, string unidad) =>
        MYGMotorPresupuestos.Coeficiente(presupuesto,
            MYGCalculoCantidadRecursoACU.CantidadBase(partida, recurso, unidad) * (1m + recurso.DesperdicioPorcentaje / 100m));

    internal MYGInsumo Insumo(string id)
    {
        if (id == null) return presupuesto.Costos.Insumos.FirstOrDefault(x => x.Id == id);
        if (insumos == null)
        {
            insumos = new(StringComparer.Ordinal);
            foreach (var r in presupuesto.Costos.Insumos)
                if (r.Id != null) insumos.TryAdd(r.Id, r);
        }
        return insumos.GetValueOrDefault(id);
    }

    internal ItemPresupuestoDelphin Subpartida(string id)
    {
        if (id == null) return presupuesto.Items.FirstOrDefault(x => x.IdLocalMYG == id && !MYGProyectoStorage.EsTitulo(x));
        if (subpartidas == null)
        {
            subpartidas = new(StringComparer.Ordinal);
            foreach (var i in presupuesto.Items)
                if (!MYGProyectoStorage.EsTitulo(i) && i.IdLocalMYG != null) subpartidas.TryAdd(i.IdLocalMYG, i);
        }
        return subpartidas.GetValueOrDefault(id);
    }

    internal bool ConservaAnalisisDelphin(ItemPresupuestoDelphin i)
    {
        if (conserva.TryGetValue(i, out bool valor)) return valor;
        valor = i.Costos.PrecioImportadoDelphin.HasValue && string.Equals(i.Costos.FirmaAnalisisImportadoDelphin,
            MYGMotorPresupuestos.FirmaAnalisis(presupuesto, i, this), StringComparison.Ordinal) &&
            !TieneReglaPorUnidadEnDescendientes(i);
        conserva.Add(i, valor);
        return valor;
    }

    internal bool TieneReglaPorUnidadEnDescendientes(ItemPresupuestoDelphin i)
    {
        var pendientes = new Stack<ItemPresupuestoDelphin>();
        var visitadas = new HashSet<ItemPresupuestoDelphin>();
        Dictionary<string, List<ItemPresupuestoDelphin>> hijosTitulo = null;
        void AgregarDescendientes(ItemPresupuestoDelphin partida)
        {
            foreach (var recurso in partida.Costos.Analisis)
                if (recurso.Grupo == MYGGrupoRecurso.Subpartidas && Subpartida(recurso.SubpartidaIdLocal) is { } subpartida)
                    pendientes.Push(subpartida);
            // Los títulos agregan su estructura; una partida real sólo depende
            // de las subpartidas declaradas expresamente en su análisis.
            if (!MYGProyectoStorage.EsTitulo(partida) || partida.Id == null) return;
            hijosTitulo ??= presupuesto.Items.Where(x => x.ParentId != null)
                .GroupBy(x => x.ParentId, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
            if (hijosTitulo.TryGetValue(partida.Id, out var descendientes))
                foreach (var descendiente in descendientes) pendientes.Push(descendiente);
        }
        AgregarDescendientes(i);
        while (pendientes.TryPop(out var subpartida))
        {
            if (!visitadas.Add(subpartida)) continue;
            // Las firmas anteriores no incluyen los costos de los descendientes.
            // Una regla activada en un descendiente obliga a recalcular al padre,
            // manteniendo intactas las firmas de los análisis históricos.
            if (subpartida.Costos.Analisis.Any(r => r.CalcularCantidadPorUnidad &&
                MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(r, Insumo(r.InsumoId)?.Unidad))) return true;
            AgregarDescendientes(subpartida);
        }
        return false;
    }

    public decimal Cantidad(ItemPresupuestoDelphin i)
    {
        if (!cantidades.TryGetValue(i, out decimal valor))
            cantidades.Add(i, valor = MYGMotorPresupuestos.Cantidad(presupuesto, i));
        return valor;
    }

    public MYGResultadoACU Analizar(ItemPresupuestoDelphin i) =>
        Analizar(i, new HashSet<string>(StringComparer.OrdinalIgnoreCase));

    private MYGResultadoACU Analizar(ItemPresupuestoDelphin i, HashSet<string> camino)
    {
        string clave = i.IdLocalMYG ?? i.Id;
        // Una subpartida calculada desde otra raíz no debe ocultar el límite
        // de 64 niveles al reutilizarla dentro de una rama más profunda.
        if (analisis.TryGetValue(clave, out var anterior) && camino.Count + profundidades[clave] <= 64) return anterior;
        if (camino.Count >= 64 || !camino.Add(clave))
            throw new InvalidDataException("Referencia circular entre subpartidas: " + i.Descripcion);
        try
        {
            var p = presupuesto; var d = i.Costos; var resultado = new MYGResultadoACU(); int profundidad = 1;
            if (d.Analisis.Count == 0)
            {
                resultado.PrecioUnitario = ConservaAnalisisDelphin(i) ? d.PrecioImportadoDelphin.Value : MYGMotorPresupuestos.Dinero(p, d.PrecioDirecto);
                analisis[clave] = resultado; profundidades[clave] = profundidad; return resultado;
            }
            decimal manoObra = 0;
            foreach (var r in d.Analisis.OrderBy(x => x.Grupo))
            {
                var v = new MYGResultadoRecurso { Recurso = r };
                if (r.Grupo == MYGGrupoRecurso.Subpartidas)
                {
                    var sub = Subpartida(r.SubpartidaIdLocal);
                    if (sub == null) throw new InvalidDataException("Subpartida inexistente: " + r.SubpartidaIdLocal);
                    v.Codigo = sub.Item; v.Descripcion = sub.Descripcion; v.Unidad = sub.Unidad;
                    v.Precio = Analizar(sub, camino).PrecioUnitario;
                    profundidad = Math.Max(profundidad, 1 + profundidades[sub.IdLocalMYG ?? sub.Id]);
                }
                else
                {
                    var insumo = Insumo(r.InsumoId);
                    if (insumo == null) throw new InvalidDataException("No existe el insumo del ACU: " + r.InsumoId);
                    v.Codigo = insumo.Codigo; v.Descripcion = insumo.Descripcion; v.Unidad = insumo.Unidad; v.Precio = PrecioInsumo(insumo);
                }
                decimal cantidad = MYGCalculoCantidadRecursoACU.CantidadBase(d, r, v.Unidad);
                v.Cantidad = MYGMotorPresupuestos.Coeficiente(p, cantidad * (1m + r.DesperdicioPorcentaje / 100m));
                if (r.Modo == MYGModoCantidad.PorcentajeManoObra)
                { v.Unidad = "%mo"; v.Precio = manoObra * FactorIgv(Insumo(r.InsumoId)); v.Total = MYGMotorPresupuestos.Dinero(p, v.Cantidad * v.Precio / 100m); }
                else v.Total = MYGMotorPresupuestos.Dinero(p, v.Cantidad * v.Precio);
                if (r.Grupo == MYGGrupoRecurso.ManoObra) manoObra += v.Total;
                resultado.Recursos.Add(v);
            }
            resultado.PrecioUnitario = ConservaAnalisisDelphin(i) ? d.PrecioImportadoDelphin.Value : resultado.Recursos.Sum(x => x.Total);
            analisis[clave] = resultado; profundidades[clave] = profundidad; return resultado;
        }
        finally { camino.Remove(clave); }
    }

    public decimal TotalPartida(ItemPresupuestoDelphin i)
    {
        if (totales.TryGetValue(i, out decimal valor)) return valor;
        if (MYGProyectoStorage.EsTitulo(i))
        {
            if (hijos == null)
                hijos = presupuesto.Items.Where(x => x.ParentId != null).GroupBy(x => x.ParentId, StringComparer.Ordinal)
                    .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
            var rama = i.Id == null ? presupuesto.Items.Where(x => x.ParentId == null) :
                hijos.TryGetValue(i.Id, out var lista) ? lista : Enumerable.Empty<ItemPresupuestoDelphin>();
            valor = rama.Sum(TotalPartida);
        }
        else
        {
            decimal cantidad = Cantidad(i);
            valor = ConservaAnalisisDelphin(i) && i.Costos.ParcialImportadoDelphin.HasValue && i.Costos.CantidadImportadaDelphin == cantidad
                ? i.Costos.ParcialImportadoDelphin.Value : MYGMotorPresupuestos.Dinero(presupuesto, cantidad * Analizar(i).PrecioUnitario);
        }
        totales.Add(i, valor); return valor;
    }

    public MYGResumenCostos Resumen()
    {
        if (resumen != null) return resumen;
        var p = presupuesto;
        var r = new MYGResumenCostos { CostoDirecto = p.Items.Where(x => !MYGProyectoStorage.EsTitulo(x)).Sum(TotalPartida) };
        if (p.Costos.PiePersonalizado != null)
        {
            // Las tasas históricas permanecen guardadas para restaurar el pie,
            // pero sólo las filas visibles participan en un pie personalizado.
            r.Subtotal = r.Total = MYGPiePresupuesto.CalcularPersonalizado(p, r.CostoDirecto).Sum(f => f.Importe);
            resumen = r; return r;
        }
        r.GastosGenerales = MYGMotorPresupuestos.Dinero(p, r.CostoDirecto * p.Costos.GastosGeneralesPorcentaje / 100m);
        r.Utilidad = MYGMotorPresupuestos.Dinero(p, r.CostoDirecto * p.Costos.UtilidadPorcentaje / 100m);
        r.Subtotal = r.CostoDirecto + r.GastosGenerales + r.Utilidad;
        r.Impuesto = MYGMotorPresupuestos.Dinero(p, r.Subtotal * p.Costos.ImpuestoPorcentaje / 100m);
        r.OtrosImpuestos = MYGMotorPresupuestos.Dinero(p, r.Subtotal * p.Costos.OtrosImpuestosPorcentaje / 100m);
        r.Total = r.Subtotal + r.Impuesto + r.OtrosImpuestos; resumen = r; return r;
    }

    public List<MYGInsumoConsolidado> Consolidar(ItemPresupuestoDelphin partida = null)
    {
        if (partida == null && consolidado != null) return consolidado;
        var p = presupuesto; decimal acumulado = 0;
        decimal limiteExacto = decimal.MaxValue;
        for (int n = 0; n < p.Costos.DecimalesPrecio; n++) limiteExacto /= 10m;
        limiteExacto /= 2m;
        bool sumarCompleto = false;
        var resultado = new Dictionary<string, MYGInsumoConsolidado>(StringComparer.OrdinalIgnoreCase);
        decimal Suma() => sumarCompleto ? resultado.Values.Sum(x => x.Total) : acumulado;
        void Agregar(string clave, MYGGrupoRecurso grupo, string codigo, string descripcion, string unidad, decimal cantidad, decimal precio, decimal total)
        {
            if (!resultado.TryGetValue(clave, out var r)) resultado[clave] = r = new MYGInsumoConsolidado
            { Clave = clave, Grupo = grupo, Codigo = codigo, Descripcion = descripcion, Unidad = unidad, Precio = precio };
            r.Cantidad += cantidad; r.Total += total;
            // A escalas cercanas al límite decimal, la asociación de sumas
            // puede perder decimales. Se conserva entonces el orden de suma
            // original, sin introducir desbordamientos en el acumulador.
            if (Math.Abs(acumulado) > limiteExacto || Math.Abs(total) > limiteExacto) sumarCompleto = true;
            if (!sumarCompleto) acumulado += total;
        }
        void Expandir(ItemPresupuestoDelphin i, decimal cantidad, HashSet<string> camino)
        {
            if (!camino.Add(i.Id)) throw new InvalidDataException("Consolidado circular.");
            var a = Analizar(i); decimal anterior = Suma();
            if (a.Recursos.Count == 0)
                Agregar("DIRECTO:" + i.IdLocalMYG, MYGGrupoRecurso.Subcontratos, i.Item,
                    i.Descripcion + " (precio directo)", i.Unidad, cantidad, a.PrecioUnitario, MYGMotorPresupuestos.Dinero(p, cantidad * a.PrecioUnitario));
            foreach (var r in a.Recursos)
            {
                if (r.Recurso.Grupo == MYGGrupoRecurso.Subpartidas)
                    Expandir(Subpartida(r.Recurso.SubpartidaIdLocal), cantidad * r.Cantidad, camino);
                else if (r.Recurso.Modo == MYGModoCantidad.PorcentajeManoObra)
                {
                    decimal total = MYGMotorPresupuestos.Dinero(p, cantidad * r.Total);
                    Agregar("PORCENTAJE:" + r.Recurso.InsumoId, MYGGrupoRecurso.Equipo, r.Codigo,
                        r.Descripcion + " (% mano de obra)", p.Costos.Moneda, total, 1m, total);
                }
                else Agregar(r.Recurso.InsumoId, r.Recurso.Grupo, r.Codigo, r.Descripcion, r.Unidad,
                    cantidad * r.Cantidad, r.Precio, MYGMotorPresupuestos.Dinero(p, cantidad * r.Total));
            }
            decimal diferencia = MYGMotorPresupuestos.Dinero(p, cantidad * a.PrecioUnitario) - (Suma() - anterior);
            if (diferencia != 0) Agregar("REDONDEO", MYGGrupoRecurso.Equipo, "", "Ajuste por redondeo", p.Costos.Moneda, diferencia, 1m, diferencia);
            camino.Remove(i.Id);
        }
        foreach (var i in (partida == null ? p.Items.Where(x => !MYGProyectoStorage.EsTitulo(x)) : new[] { partida }))
            Expandir(i, Cantidad(i), new HashSet<string>());
        var valores = resultado.Values.Where(x => x.Total != 0 || x.Cantidad != 0).OrderBy(x => x.Grupo).ThenBy(x => x.Codigo).ToList();
        if (partida == null) consolidado = valores;
        return valores;
    }
}
