# Actualización: edición de costo directo y fuente del resumen

Proyecto: bimchimbote-droid/MYG.Presupuestos. Base: main, commit 48765e07163a63217f87048fb4a6a1a76b5b504d.
El ZIP contiene únicamente archivos nuevos o modificados completos. No contiene ejecutables, bases de datos, dependencias ni el repositorio Git.

## Cambios

- Clic derecho en Costo directo > Editar Fila abre Configurar tipo de costo: nombre y cuatro selecciones de IGV. Los editores del resto de las filas conservan su funcionamiento.
- Al escribir la etiqueta de una fila personalizada, el identificador se actualiza con user_, minúsculas, espacios convertidos en _, sin tildes, cifras ni signos. Los identificadores guardados se conservan hasta editar la etiqueta. La validación rechaza duplicados.
- Fuente abre un diálogo con familia, estilo, tamaño decimal, tachado, subrayado, color, fondo, ejemplo en tiempo real y restauración del formato inicial. El formato se guarda por fila y presupuesto. En alcance por proyecto se aplica a sus presupuestos.
- Las casillas usan el porcentaje IGV de cada insumo seleccionado. Un insumo con tasa cero conserva su precio. Los documentos anteriores conservan sus importes y comienzan sin inclusión de IGV por grupo. La tasa del IGV del pie conserva su funcionamiento independiente.

## Archivos de la entrega

| Ruta | Acción |
|---|---|
| INSTRUCCIONES_ACTUALIZACION.md | CREAR |
| MYG.Core/CalculoPresupuestoMYG.cs | REEMPLAZAR |
| MYG.Core/EstiloFilaResumenMYG.cs | CREAR |
| MYG.Core/MotorPresupuestos.cs | REEMPLAZAR |
| MYG.Core/PiePresupuestoMYG.cs | REEMPLAZAR |
| MYG.Core/PresupuestosModelos.cs | REEMPLAZAR |
| MYG.Core/ReportesProyectoMYG.cs | REEMPLAZAR |
| MYG.Desktop/ConfigurarCostoDirectoForm.cs | CREAR |
| MYG.Desktop/EditarFilaResumenForm.cs | REEMPLAZAR |
| MYG.Desktop/FuenteResumenForm.cs | CREAR |
| MYG.Desktop/PresupuestosPiePanel.cs | REEMPLAZAR |
| MYG.Desktop/PresupuestosResumenMenu.cs | REEMPLAZAR |
| MYG.Pruebas/CostoDirectoCheck.cs | CREAR |
| MYG.Pruebas/Program.cs | REEMPLAZAR |
| MYG.PruebasUI/CostoDirectoDialogoCheck.cs | CREAR |
| MYG.PruebasUI/FilaResumenDialogoCheck.cs | REEMPLAZAR |
| MYG.PruebasUI/FuenteResumenDialogoCheck.cs | CREAR |
| MYG.PruebasUI/Program.cs | REEMPLAZAR |

## Instalación manual

1. En Visual Studio > Cambios de Git, confirme o respalde sus cambios locales antes de reemplazar archivos. Si modificó estos mismos archivos después del commit base, compare y fusione sus cambios para conservarlos.
2. Cierre la aplicación MYG y extraiga MYG_PRESUPUESTOS_ACTUALIZACION.zip fuera del proyecto.
3. Copie su contenido a la raíz del proyecto (por ejemplo D:\ADDIN\repos\MYG.Presupuestos_GITHUB), conservando todas las rutas relativas. Acepte reemplazar únicamente los archivos indicados.
4. No hay archivos que eliminar ni parches que aplicar. No hace falta modificar solución, proyectos o paquetes: los proyectos SDK incluyen automáticamente las clases nuevas.
5. Abra MYG.Presupuestos.sln en Visual Studio 2026 y compile Release. SDK probado: .NET 10.0.100. Desde la raíz también puede ejecutar:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

El indicador UseRevitReferencePackages permite compilar el conector sin una instalación local de Revit. Para ejecutar la integración real necesita Revit 2027.

## Validación realizada y pendiente

- Compilación completa Release en Linux: 0 errores y 0 advertencias.
- Suite MYG.Pruebas: 397 comprobaciones aprobadas en Release, incluidas persistencia SQLite/JSON, firmas históricas, configuración por grupo y subpartidas sin duplicación del IGV.
- MYG.PruebasUI compiló con las comprobaciones nuevas, pero no se ejecutó: requiere Windows Desktop. Named Pipes de Windows fue omitida por el runner. Las muestras externas opcionales no se ejecutaron.
- En Windows: abrir Costo directo > Editar Fila; cambiar nombre/grupos, Aceptar y Cerrar; comprobar las otras filas; probar etiqueta con tildes/espacios/cifras; probar todos los controles de Fuente, guardar/reabrir el proyecto y verificar aislamiento por fila, presupuesto y conservación al cambiar de tema.
- No se ha probado visualmente el aspecto de los diálogos ni ejecutado Revit o licencias reales en este entorno.

## Guardar el código en GitHub

La entrega ZIP se publica separadamente en bimchimbote-droid/DESCARGAS. No se hizo push ni se modificó main del repositorio del código.
Después de aplicar y comprobar: abra Cambios de Git en Visual Studio, revise las diferencias, confirme los archivos de esta entrega, haga Commit y Push a su rama de trabajo y verifique el commit en GitHub. Publicar el ZIP no aplica los archivos a su copia local.

No se agregaron paquetes ni se requieren credenciales, migraciones o cambios de configuración externos para esta modificación. Las fuentes seleccionadas deben existir en el equipo donde se usan.
