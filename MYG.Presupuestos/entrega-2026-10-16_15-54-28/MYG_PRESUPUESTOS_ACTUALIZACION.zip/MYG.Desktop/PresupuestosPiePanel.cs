using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly DataGridView tablaPie = Tabla();
    private readonly ComboBox alcancePie = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 130 };
    private readonly Label tituloPie = new() { Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly MYGGraficoIncidencia graficoIncidencia = new() { Dock = DockStyle.Fill };
    private bool actualizandoPie;
    private int alcancePieAnterior;
    private List<MYGPresupuestoDocumento> presupuestosPieEnEdicion;
    private string valorPieAntes;
    private List<MYGPresupuestoDocumento> AlcancePie() => alcancePie.SelectedIndex == 1
        ? PresupuestosEstructura.ToList() : P == null ? new() : new() { P };

    private static void AplicarSombreadoResumenPie(DataGridViewCellStyle estilo)
    {
        estilo.BackColor = SystemInformation.HighContrast ? SystemColors.Control : MYG2027_TemaComercial.Oscuro
            ? Color.FromArgb(52, 61, 73) : Color.FromArgb(236, 238, 240);
        estilo.ForeColor = SystemInformation.HighContrast ? SystemColors.ControlText : MYG2027_TemaComercial.Texto;
        estilo.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
        estilo.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
    }

    private Control PrepararPiePresupuesto()
    {
        var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, Margin = new(0), BackColor = AzulClaro };
        panel.ColumnStyles.Add(new(SizeType.Percent, 43)); panel.ColumnStyles.Add(new(SizeType.Percent, 57));
        panel.RowStyles.Add(new(SizeType.Absolute, 31)); panel.RowStyles.Add(new(SizeType.Percent, 100));
        var cabeceraPie = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new(0), Padding = new(3) };
        cabeceraPie.ColumnStyles.Add(new(SizeType.Absolute, 138)); cabeceraPie.ColumnStyles.Add(new(SizeType.Percent, 100));
        alcancePie.Items.AddRange(new object[] { "Por presupuesto", "Por proyecto" }); alcancePie.SelectedIndex = 0;
        cabeceraPie.Controls.Add(PrepararOpcionesResumen(), 0, 0); cabeceraPie.Controls.Add(tituloPie, 1, 0);
        panel.Controls.Add(cabeceraPie, 0, 0); panel.SetColumnSpan(cabeceraPie, 2);
        panel.Controls.Add(graficoIncidencia, 0, 1); panel.Controls.Add(tablaPie, 1, 1);
        tablaPie.ReadOnly = false; tablaPie.EditMode = DataGridViewEditMode.EditOnEnter;
        tablaPie.RowTemplate.Height = 23; tablaPie.ColumnHeadersHeight = 25;
        tablaPie.DefaultCellStyle.Font = new Font("Segoe UI", 8.25F);
        Columna(tablaPie, "CONCEPTO", "Concepto", 108);
        Columna(tablaPie, "PORC", "%", 61, true); Columna(tablaPie, "IMPORTE", "Importe", 98); Columna(tablaPie, "COEF", "Coef.", 49);
        tablaPie.Columns["CONCEPTO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        tablaPie.Columns["CONCEPTO"].MinimumWidth = 95;
        foreach (string c in new[] { "PORC", "IMPORTE", "COEF" }) tablaPie.Columns[c].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        tablaPie.Columns["PORC"].ToolTipText = "Edite el porcentaje. En Por proyecto se aplica este concepto a todos sus presupuestos. GG y utilidad usan el costo directo; IGV y otros impuestos usan el parcial.";
        MYG2027_TemaComercial.DesactivarFilasAlternas(tablaPie);
        // El gris del resumen tiene significado propio: la paleta general no
        // debe convertirlo en blanco ni sustituirlo por el color de una fila alterna.
        MYG2027_TemaComercial.ConservarColoresDocumento(tablaPie);
        tablaPie.CellFormatting += (_, e) =>
        {
            if (e.RowIndex >= 0)
            {
                var fila = tablaPie.Rows[e.RowIndex];
                if (!EsConceptoEditablePie(fila.Tag)) AplicarSombreadoResumenPie(e.CellStyle);
                AplicarFormatoFilaResumen(fila, e.CellStyle);
            }
        };
        void ActualizarSombreado(object sender, EventArgs e)
        {
            foreach (DataGridViewRow fila in tablaPie.Rows)
                foreach (DataGridViewCell celda in fila.Cells)
                {
                    if (!EsConceptoEditablePie(fila.Tag)) AplicarSombreadoResumenPie(celda.Style);
                    AplicarFormatoFilaResumen(fila, celda.Style);
                }
            tablaPie.Invalidate();
        }
        MYG2027_TemaComercial.CambioTema += ActualizarSombreado;
        tablaPie.Disposed += (_, _) => MYG2027_TemaComercial.CambioTema -= ActualizarSombreado;
        alcancePie.SelectedIndexChanged += (s, e) =>
        {
            if (actualizandoPie) return;
            try { FinalizarEdicion(); alcancePieAnterior = alcancePie.SelectedIndex; RefrescarPiePresupuesto(); }
            catch (Exception ex)
            {
                actualizandoPie = true; alcancePie.SelectedIndex = alcancePieAnterior; actualizandoPie = false;
                MessageBox.Show(this, ex.Message, "Pie de presupuesto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        };
        tablaPie.CellBeginEdit += (s, e) =>
        {
            if (actualizandoPie || e.ColumnIndex != tablaPie.Columns["PORC"].Index ||
                tablaPie.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly || !EsConceptoEditablePie(tablaPie.Rows[e.RowIndex].Tag) || !PiesCompatibles(AlcancePie())) { e.Cancel = true; return; }
            presupuestosPieEnEdicion = AlcancePie(); valorPieAntes = Convert.ToString(tablaPie.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);
        };
        tablaPie.CellValidating += (s, e) =>
        {
            if (actualizandoPie || presupuestosPieEnEdicion == null || e.ColumnIndex != tablaPie.Columns["PORC"].Index ||
                tablaPie.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly || !EsConceptoEditablePie(tablaPie.Rows[e.RowIndex].Tag)) return;
            string texto = Convert.ToString(e.FormattedValue)?.Trim().TrimEnd('%').Trim();
            if (texto == valorPieAntes) return;
            try
            {
                RequerirPermisoCatalogos();
                if (!MYGHojaCalculo.IntentarNumero(texto, out decimal porcentaje)) throw new InvalidOperationException("Escriba un porcentaje válido.");
                var destino = presupuestosPieEnEdicion ?? AlcancePie();
                // Validar una copia también evita registrar una edición inválida en el historial.
                object concepto = tablaPie.Rows[e.RowIndex].Tag;
                AplicarPorcentajeFilaPie(destino.Select(MYGProyectoStorage.Copia).ToList(), concepto, porcentaje);
                antes(); AplicarPorcentajeFilaPie(destino, concepto, porcentaje);
                valorPieAntes = texto; tablaPie.Rows[e.RowIndex].ErrorText = ""; despues();
            }
            catch (Exception ex) { e.Cancel = true; tablaPie.Rows[e.RowIndex].ErrorText = ex.Message; }
        };
        tablaPie.CellEndEdit += (s, e) =>
        {
            presupuestosPieEnEdicion = null; valorPieAntes = null;
            if (actualizandoPie || IsDisposed || !IsHandleCreated) return;
            SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        };
        PrepararMenuResumen();
        return panel;
    }

    private void RefrescarPiePresupuesto(Func<MYGPresupuestoDocumento, MYGCalculoPresupuesto> calcular = null)
    {
        if (actualizandoPie || tablaPie.IsCurrentCellInEditMode || tablaPie.Columns.Count == 0) return;
        actualizandoPie = true;
        try
        {
            string seleccion = IdFilaResumen(tablaPie.CurrentRow);
            var presupuestos = AlcancePie(); tablaPie.Rows.Clear();
            PrepararFormatosFilasResumen(presupuestos);
            if (presupuestos.Count == 0)
            { tituloPie.Text = "PIE DE PRESUPUESTO · Sin presupuesto"; graficoIncidencia.Actualizar(new(), "S/"); return; }
            var calculos = presupuestos.Select(p => calcular?.Invoke(p) ?? MYGMotorPresupuestos.CrearCalculo(p)).ToList();
            var r = MYGPiePresupuesto.Resumen(calculos); string moneda = MYGPiePresupuesto.Moneda(presupuestos);
            tituloPie.Text = alcancePie.SelectedIndex == 1 ? "PIE RESUMEN ÚNICO POR PROYECTO · " + moneda : "PIE DE " + P.Nombre + " · " + moneda;
            bool compatibles = PiesCompatibles(presupuestos);
            var filas = MYGPiePresupuesto.Filas(calculos);
            if (filas.Count > 1 && filas.All(f => f.Id != MYGPiePresupuesto.IdTotal))
                filas.Add(new MYGFilaResumenPie { Id = MYGPiePresupuesto.IdTotal, Nombre = "Total", Importe = r.Total });
            foreach (var dato in filas)
            {
                bool concepto = dato.Concepto.HasValue || dato.Id != MYGPiePresupuesto.IdCostoDirecto && dato.Id != MYGPiePresupuesto.IdTotal && dato.Id != "parcial";
                bool porcentual = dato.Concepto.HasValue || presupuestos.Any(p => p.Costos.PiePersonalizado?.Any(f => f.Id == dato.Id && MYGPiePresupuesto.EsPorcentual(f)) == true);
                string porcentaje = dato.Porcentaje?.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture) ?? (porcentual ? "Varios" : "");
                var fila = tablaPie.Rows[tablaPie.Rows.Add(dato.Nombre, porcentaje, MYGFormatoPresupuesto.Dinero(dato.Importe), r.CostoDirecto == 0 ? "0.00" : (dato.Importe / r.CostoDirecto).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture))];
                fila.HeaderCell.Tag = dato.Id;
                fila.Tag = dato.Concepto.HasValue ? dato.Concepto.Value : concepto ? dato : null;
                fila.Cells["PORC"].ReadOnly = !dato.Editable || !compatibles;
                if (!concepto)
                    foreach (DataGridViewCell celda in fila.Cells) AplicarSombreadoResumenPie(celda.Style);
                if (dato.Id == MYGPiePresupuesto.IdTotal) fila.DefaultCellStyle.Font = negrita;
                AplicarFormatoFilaResumen(fila, fila.DefaultCellStyle);
                foreach (DataGridViewCell celda in fila.Cells) AplicarFormatoFilaResumen(fila, celda.Style);
                fila.Height = Math.Max(23, (fila.DefaultCellStyle.Font ?? tablaPie.DefaultCellStyle.Font).Height + 8);
                if (porcentual && !dato.Porcentaje.HasValue) fila.Cells["PORC"].ToolTipText = "Los presupuestos usan porcentajes distintos. Escribir uno aquí lo aplicará a todos para este concepto.";
                else if (concepto && !porcentual) fila.Cells["PORC"].ToolTipText = "Valor manual o fórmula. Use Editar fila para modificarlo.";
                if (!compatibles) fila.Cells["PORC"].ToolTipText = "Los presupuestos tienen pies distintos. Edítelos por presupuesto o copie y pegue un resumen común.";
                if (seleccion != null && IdFilaResumen(fila) == seleccion) tablaPie.CurrentCell = fila.Cells["CONCEPTO"];
            }
            ActualizarMenuResumen();
            graficoIncidencia.Actualizar(MYGPiePresupuesto.Incidencia(calculos), moneda);
        }
        catch (Exception ex) { tablaPie.Rows.Clear(); tituloPie.Text = ex.Message; graficoIncidencia.Actualizar(new(), "", ex.Message); }
        finally { actualizandoPie = false; }
    }
}

internal sealed class MYGGraficoIncidencia : Control
{
    private List<MYGIncidenciaCosto> datos = new();
    private string moneda = "S/", error;
    private readonly ToolTip ayuda = new();
    private readonly List<(RectangleF Area, MYGIncidenciaCosto Valor)> barras = new();
    private static Color ColorBarra(int numero) => (numero % 5) switch
    {
        0 => MYG2027_TemaComercial.Azul,
        1 => MYG2027_TemaComercial.ColorTitulo(0),
        2 => MYG2027_TemaComercial.ColorTitulo(2),
        3 => MYG2027_TemaComercial.ColorTitulo(5),
        _ => MYG2027_TemaComercial.Secundario
    };
    internal MYGGraficoIncidencia() { DoubleBuffered = true; BackColor = MYG2027_TemaComercial.Superficie; ForeColor = MYG2027_TemaComercial.Texto; Font = new("Segoe UI", 8); }
    internal void Actualizar(List<MYGIncidenciaCosto> valores, string simbolo, string problema = null)
    { datos = valores; moneda = simbolo; error = problema; Invalidate(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e); barras.Clear(); var g = e.Graphics; float escala = DeviceDpi / 96F;
        using var titulo = new Font(Font, FontStyle.Bold);
        using var texto = new SolidBrush(ForeColor);
        using var secundario = new SolidBrush(MYG2027_TemaComercial.Secundario);
        using var centrado = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        g.DrawString("Incidencia de costos", titulo, texto, new RectangleF(0, 0, Width, 23 * escala), centrado);
        if (datos.Count == 0 || datos.Sum(x => x.Importe) == 0 || error != null)
        {
            g.DrawString(error ?? "Sin costos en el alcance seleccionado", Font, secundario, new RectangleF(8, 30 * escala, Math.Max(1, Width - 16), Math.Max(1, Height - 35 * escala)), centrado); return;
        }
        var area = new RectangleF(51 * escala, 39 * escala, Width - 61 * escala, Height - 86 * escala);
        if (area.Width < 35 || area.Height < 20) return;
        double maximo = (double)datos.Max(x => x.Importe);
        double potencia = Math.Pow(10, Math.Floor(Math.Log10(maximo)));
        double limite = Math.Ceiling(maximo / potencia / 0.5) * potencia * 0.5;
        using var linea = new Pen(MYG2027_TemaComercial.Borde);
        using var derecha = new StringFormat { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Center };
        string Eje(double v) => v >= 1000000 ? (v / 1000000).ToString("0.#") + " M" : v >= 1000 ? (v / 1000).ToString("0.#") + " mil" : v.ToString("0.##");
        for (int n = 0; n <= 4; n++)
        {
            float y = area.Bottom - area.Height * n / 4;
            g.DrawLine(linea, area.Left, y, area.Right, y);
            g.DrawString(Eje(limite * n / 4), Font, secundario, new RectangleF(0, y - 8 * escala, area.Left - 4 * escala, 16 * escala), derecha);
        }
        g.DrawString(moneda, Font, secundario, 4 * escala, 23 * escala);
        float espacio = area.Width / datos.Count;
        for (int n = 0; n < datos.Count; n++)
        {
            var d = datos[n]; float alto = (float)((double)d.Importe / limite * area.Height);
            var bar = new RectangleF(area.Left + n * espacio + espacio * 0.16F, area.Bottom - alto, espacio * 0.68F, alto);
            using var color = new SolidBrush(ColorBarra(n)); g.FillRectangle(color, bar);
            g.DrawString(d.Porcentaje.ToString("0.00") + "%", Font, color, new RectangleF(area.Left + n * espacio - 2, bar.Top - 18 * escala, espacio + 4, 18 * escala), centrado);
            string nombre = d.Nombre.Replace("MANO DE OBRA", "MANO DE\nOBRA").Replace("SUBCONTRATOS", "SUB-\nCONTRATOS").Replace("SIN DESGLOSE", "SIN\nDESGLOSE");
            g.DrawString(nombre, Font, texto, new RectangleF(area.Left + n * espacio, area.Bottom + 3 * escala, espacio, 40 * escala), centrado);
            barras.Add((bar, d));
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e); var valor = barras.FirstOrDefault(x => x.Area.Contains(e.Location)).Valor;
        string texto = valor == null ? "" : valor.Nombre + ": " + moneda + " " + MYGFormatoPresupuesto.Dinero(valor.Importe) + " · " + valor.Porcentaje.ToString("0.00") + "%";
        if (ayuda.GetToolTip(this) != texto) ayuda.SetToolTip(this, texto);
    }
    protected override void Dispose(bool disposing) { if (disposing) ayuda.Dispose(); base.Dispose(disposing); }
}
