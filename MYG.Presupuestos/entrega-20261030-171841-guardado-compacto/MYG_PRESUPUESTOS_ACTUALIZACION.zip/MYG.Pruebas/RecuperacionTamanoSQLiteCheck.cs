using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class RecuperacionTamanoSQLiteCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "recuperacion-espacio-libre.sqlite");
        Crear(ruta, grande: true);
        long antes = new FileInfo(ruta).Length;
        Exige(MYGRecuperacionTamanoSQLite.Recuperar(ruta), "No se recuperó una base con más de 8 MiB y 25 % de páginas libres.");
        Exige(new FileInfo(ruta).Length < antes / 4, "La compactación no devolvió las páginas libres al sistema.");
        Verificar(ruta);
        Exige(!MYGRecuperacionTamanoSQLite.Recuperar(ruta), "Una base recién compactada se reescribió otra vez.");
        pasa("SQLite recupera páginas libres importantes sin perder claves, BLOB, decimales, relaciones ni integridad y evita repetir VACUUM sin necesidad");

        string pequena = Path.Combine(carpeta, "recuperacion-base-pequena.sqlite");
        Crear(pequena, grande: false);
        string huella = Huella(pequena);
        Exige(!MYGRecuperacionTamanoSQLite.Recuperar(pequena) && Huella(pequena) == huella,
            "La compactación modificó una base pequeña que no llega al umbral.");
        Verificar(pequena);
        pasa("SQLite conserva byte por byte las bases pequeñas sin espacio libre suficiente");

        string reducida = Path.Combine(carpeta, "recuperacion-documento-reducido.sqlite");
        Crear(reducida, grande: false);
        using (var conexion = Conexion(reducida, escritura: true))
        {
            using (var comando = conexion.CreateCommand())
            {
                comando.CommandText = "INSERT INTO temporal VALUES(1,zeroblob(1048576)); DELETE FROM temporal";
                comando.ExecuteNonQuery();
            }
            Exige(!MYGRecuperacionTamanoSQLite.Intentar(conexion),
                "Una escritura ordinaria activó el umbral de migración del documento.");
            long antesReducida = new FileInfo(reducida).Length;
            Exige(MYGRecuperacionTamanoSQLite.Intentar(conexion, reduccionDocumento: true) &&
                new FileInfo(reducida).Length < antesReducida / 4,
                "Una reducción importante del documento no devolvió las páginas al archivo.");
            Exige(!MYGRecuperacionTamanoSQLite.Intentar(conexion, reduccionDocumento: true),
                "El mantenimiento posterior a la reducción repitió VACUUM sin páginas libres suficientes.");
        }
        Verificar(reducida);
        pasa("SQLite devuelve el ahorro de documentos reducidos sin esperar 8 MiB libres ni repetir compactaciones en guardados sucesivos");

        string ocupada = Path.Combine(carpeta, "recuperacion-base-ocupada.sqlite");
        Crear(ocupada, grande: true);
        long tamanoOcupada = new FileInfo(ocupada).Length;
        using (var bloqueo = Conexion(ocupada, escritura: true))
        using (var transaccion = bloqueo.BeginTransaction())
        {
            // La transacción de la otra conexión se mantiene abierta; todos los
            // datos de Crear ya fueron confirmados antes de adquirir el bloqueo.
            using var comando = bloqueo.CreateCommand(); comando.Transaction = transaccion;
            comando.CommandText = "UPDATE padre SET nota=nota WHERE id='PRESERVAR'";
            comando.ExecuteNonQuery();
            var reloj = Stopwatch.StartNew();
            Exige(!MYGRecuperacionTamanoSQLite.Recuperar(ocupada), "VACUUM ignoró un escritor ajeno activo.");
            Exige(reloj.Elapsed < TimeSpan.FromSeconds(5), "Un bloqueo de mantenimiento esperó el timeout largo del guardado.");
            Exige(new FileInfo(ocupada).Length == tamanoOcupada, "El intento bloqueado reescribió el archivo.");
            transaccion.Rollback();
        }
        Verificar(ocupada);
        Exige(MYGRecuperacionTamanoSQLite.Recuperar(ocupada), "No se pudo recuperar espacio después de liberar el bloqueo.");
        Verificar(ocupada);
        pasa("SQLite pospone la recuperación ante un escritor ajeno sin perder datos confirmados y permite compactar tras liberar el bloqueo");

        string rutaWal = Path.Combine(carpeta, "recuperacion-con-wal.sqlite");
        Crear(rutaWal, grande: true);
        long antesWal = new FileInfo(rutaWal).Length;
        using (var escritor = Conexion(rutaWal, escritura: true))
        using (var comando = escritor.CreateCommand())
        {
            comando.CommandText = "PRAGMA journal_mode=WAL; INSERT INTO hijo VALUES(7002,'PRESERVAR','Confirmado en WAL')";
            comando.ExecuteNonQuery();
            Exige(File.Exists(rutaWal + "-wal") && new FileInfo(rutaWal + "-wal").Length > 0,
                "La prueba no dejó un cambio confirmado en WAL.");
            Exige(MYGRecuperacionTamanoSQLite.Recuperar(rutaWal), "No se recuperaron páginas libres con WAL activo.");
            Verificar(rutaWal);
            comando.CommandText = "SELECT COUNT(*) FROM hijo WHERE id=7002 AND dato='Confirmado en WAL'";
            Exige(Convert.ToInt64(comando.ExecuteScalar(), CultureInfo.InvariantCulture) == 1,
                "La compactación perdió un cambio confirmado que estaba en WAL.");
        }
        Exige(new FileInfo(rutaWal).Length < antesWal / 4,
            "El cierre de las conexiones WAL no conservó la reducción de páginas.");
        Verificar(rutaWal);
        pasa("SQLite recupera espacio con WAL activo y conserva transacciones confirmadas antes y después de cerrar las conexiones");
    }

    private static void Crear(string ruta, bool grande)
    {
        using var conexion = Conexion(ruta, escritura: true);
        using var comando = conexion.CreateCommand();
        comando.CommandText = """
            PRAGMA auto_vacuum=NONE;
            CREATE TABLE padre(id TEXT PRIMARY KEY,importe TEXT NOT NULL,nota TEXT,binario BLOB NOT NULL);
            CREATE TABLE hijo(id INTEGER PRIMARY KEY,padre_id TEXT REFERENCES padre(id),dato TEXT);
            CREATE TABLE temporal(id INTEGER PRIMARY KEY,contenido BLOB);
            INSERT INTO padre VALUES('PRESERVAR','1234567890.1234567890123456789','Texto ñ 漢字',X'000102FF');
            INSERT INTO hijo VALUES(7001,'PRESERVAR','Relación confirmada');
            """;
        comando.ExecuteNonQuery();
        using (var transaccion = conexion.BeginTransaction())
        {
            comando.Transaction = transaccion;
            comando.CommandText = grande ? "INSERT INTO temporal VALUES(1,zeroblob(12582912)); DELETE FROM temporal"
                : "INSERT INTO temporal VALUES(1,zeroblob(1024)); DELETE FROM temporal";
            comando.ExecuteNonQuery(); transaccion.Commit();
        }
    }

    private static void Verificar(string ruta)
    {
        using var conexion = Conexion(ruta, escritura: false);
        using var comando = conexion.CreateCommand();
        comando.CommandText = "SELECT id,importe,nota,hex(binario),typeof(importe),typeof(binario) FROM padre";
        using (var lector = comando.ExecuteReader())
            Exige(lector.Read() && lector.GetString(0) == "PRESERVAR" && lector.GetString(1) == "1234567890.1234567890123456789" &&
                lector.GetString(2) == "Texto ñ 漢字" && lector.GetString(3) == "000102FF" && lector.GetString(4) == "text" &&
                lector.GetString(5) == "blob" && !lector.Read(), "La recuperación alteró valores, tipos o filas de la base.");
        comando.CommandText = "SELECT COUNT(*) FROM hijo WHERE id=7001 AND padre_id='PRESERVAR' AND dato='Relación confirmada'";
        Exige(Convert.ToInt64(comando.ExecuteScalar(), CultureInfo.InvariantCulture) == 1, "La recuperación perdió una relación confirmada.");
        comando.CommandText = "PRAGMA integrity_check";
        Exige((string)comando.ExecuteScalar() == "ok", "La base compactada no supera integrity_check.");
        comando.CommandText = "PRAGMA foreign_key_check";
        using var relaciones = comando.ExecuteReader();
        Exige(!relaciones.Read(), "La compactación dejó relaciones sin destino.");
    }

    private static SqliteConnection Conexion(string ruta, bool escritura)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWriteCreate : SqliteOpenMode.ReadOnly,
            Pooling = false, ForeignKeys = true, DefaultTimeout = 1 }.ToString());
        conexion.Open(); return conexion;
    }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
}
