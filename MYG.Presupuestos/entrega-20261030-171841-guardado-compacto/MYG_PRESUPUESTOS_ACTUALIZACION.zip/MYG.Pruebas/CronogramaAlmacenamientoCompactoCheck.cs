using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class CronogramaAlmacenamientoCompactoCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Sintetica(carpeta, pasa);
        string muestra = Environment.GetEnvironmentVariable("MYG_QA_ALMACENAMIENTO_SQLITE");
        if (string.IsNullOrWhiteSpace(muestra))
            Console.WriteLine("OMITIDA: almacenamiento compacto en muestra externa (MYG_QA_ALMACENAMIENTO_SQLITE no definido).");
        else Muestra(Path.GetFullPath(muestra), carpeta, pasa);
    }

    private static void Sintetica(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Cronograma extensiones agrupadas.sqlite");
        var semilla = MYGProyectoStorage.Nuevo("Muestra sintética de almacenamiento");
        semilla.Id = "PR-COMPACTO";
        semilla.Datos = MYGDatosProyecto.Crear();
        semilla.Datos.FechaInicio = new DateTime(2026, 6, 8);
        semilla.Datos.FechaElaboracion = new DateTime(2026, 6, 1);
        var presupuesto = semilla.Presupuestos.Single();
        presupuesto.Id = "PP-COMPACTO";
        semilla.PresupuestoActivoId = presupuesto.Id;
        for (int n = 0; n < 120; n++)
        {
            string id = "CC-" + n.ToString("D3");
            presupuesto.Items.Add(new() { Id = id, IdLocalMYG = id, IdPropuesta = id,
                TipoPropuesta = "PARTIDA", Descripcion = "Partida sintética " + n, Unidad = "und", Posicion = n + 1,
                Costos = new() { Cantidad = 2m, PrecioDirecto = 10m } });
        }
        MYGProyectoStorage.Guardar(ruta, semilla);
        SQL(ruta, """
            UPDATE costo_unitario SET duracion=2,duracion_new=2,fecha_inicio='2026-06-08 08:00:00',
                fecha_fin='2026-06-09 17:00:00',task_mode=1,es_hito='N',porcentaje_completado=0;
            INSERT INTO dependencia_tarea(id_dependencia,id_costounitarioorigen,id_costounitariodestino,id_proyecto,tipo,lag_size)
                VALUES('DP-COMPACTO','CC-000','CC-001','PR-COMPACTO',0,0);
            """);
        using var conexion = Conexion(ruta);
        var documento = Nativo(conexion, semilla.Id);
        Exige(documento.Cronograma != null, "La semilla no tiene cronograma nativo.");
        foreach (var tarea in documento.Cronograma.Tareas.Where(t => !t.EsResumen))
        {
            tarea.InicioManual = null;
            tarea.FechasImportadasDelphin = null;
            tarea.Notas = "Nota propia común; conservar Unicode ñ 漢字.";
        }
        var primera = documento.Cronograma.Tareas.First(t => !t.EsResumen);
        primera.InicioBase = new DateTime(2026, 6, 8);
        primera.FinBase = new DateTime(2026, 6, 9);
        primera.DuracionBase = 2;
        primera.NumeroCuadrillas = 1.75m;
        primera.CuadrillasIniciales = 1.25m;
        primera.Responsables.Add("Responsable sintético");
        documento.Cronograma.OpcionesVista["zoom"] = "125";
        documento.Cronograma.OpcionesVista["columnas"] = "Notas;Predecesoras";
        documento.Cronograma.Tareas.Add(new() { Id = "TAREA-SIN-PARTIDA", Nombre = "Actividad propia sin partida",
            DuracionDias = 3, Notas = "No tiene fila Delphin y debe conservarse.",
            Predecesoras = new() { new() { PredecesoraId = primera.Id, DesfaseDias = 1 } } });
        const string avisoPropio = "Aviso propio de la prueba, ajeno al importador.";
        documento.Cronograma.AdvertenciasImportacion.Add(avisoPropio);
        documento.Cronograma.AdvertenciasImportacion.Add("El vínculo Delphin «ANTIGUO» se conserva en el archivo; MYG no puede calcularlo como vínculo entre tareas individuales.");
        documento.Cronograma.VinculosImportadosDelphin.Clear();
        string original = JsonSerializer.Serialize(documento);
        string guardado = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, documento);
        var raiz = JsonNode.Parse(guardado);
        Exige(raiz["VersionAlmacenamiento"].GetValue<int>() == 2, "La escritura no usa el formato compacto versionado.");
        var tareas = raiz["Cambios"][1]["Cronograma"][1]["Tareas"].AsArray();
        Exige(tareas[0].GetValue<string>() == "g" && tareas[2].AsArray().Count < 10,
            "Las mismas anulaciones y notas se guardan repetidamente en vez de compartir patrones.");
        Exige(JsonSerializer.Serialize(documento) == original, "La normalización modificó el documento en memoria.");
        var reabierto = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, guardado);
        Iguales(documento, reabierto);
        Exige(reabierto.Cronograma.AdvertenciasImportacion.Contains(avisoPropio) &&
            !reabierto.Cronograma.AdvertenciasImportacion.Any(a => a.Contains("«ANTIGUO»", StringComparison.Ordinal)) &&
            reabierto.Cronograma.VinculosImportadosDelphin.Count == 1,
            "No se regeneraron los diagnósticos nativos o se perdió una advertencia propia.");
        Exige(guardado == MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, reabierto),
            "El formato agrupado crece al volver a escribir el mismo documento.");
        pasa("Cronograma compacto comparte cambios repetidos y preserva notas, líneas base, cuadrillas, vista, responsables, tarea propia y anulaciones explícitas sin mutar el documento");

        // Un patrón inválido nunca debe convertirse en una lectura parcial exitosa.
        var roto = raiz.DeepClone();
        var grupo = roto["Cambios"][1]["Cronograma"][1]["Tareas"].AsArray();
        grupo[3][1] = new JsonArray(0, 999999);
        Rechaza(() => MYGDocumentoDelphinAlmacenamiento.Leer(conexion, roto.ToJsonString()));
        roto = raiz.DeepClone();
        grupo = roto["Cambios"][1]["Cronograma"][1]["Tareas"].AsArray();
        grupo[3][1] = grupo[3][0].DeepClone();
        Rechaza(() => MYGDocumentoDelphinAlmacenamiento.Leer(conexion, roto.ToJsonString()));
        pasa("Referencias agrupadas rechazan patrones fuera de rango y filas duplicadas con un error explícito");

        SQL(ruta, """
            INSERT INTO dependencia_tarea(id_dependencia,id_costounitarioorigen,id_costounitariodestino,id_proyecto,tipo,lag_size)
                VALUES('DP-COMPACTO-EXTERNA','CC-000','CC-002','PR-COMPACTO',0,0);
            UPDATE costo_unitario SET tipo_restriccion=8,fecha_restriccion='2026-06-08' WHERE id_costounitario='CC-003';
            """);
        var externo = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, guardado);
        Exige(Escalar(ruta, "SELECT COUNT(*) FROM costo_unitario WHERE id_costounitario='CC-003' AND tipo_restriccion=8") == 1,
            "La prueba no actualizó la restricción nativa esperada.");
        var vivo = Nativo(conexion, semilla.Id);
        Exige(externo.Cronograma.VinculosImportadosDelphin.Count == 2 &&
            externo.Cronograma.AdvertenciasImportacion.Contains(avisoPropio) &&
            externo.Cronograma.AdvertenciasImportacion.Any(a => a.StartsWith("La restricción nativa Delphin de «", StringComparison.Ordinal)),
            "Las extensiones compactas ocultan los vínculos o diagnósticos nativos actuales. Vínculos=" +
            externo.Cronograma.VinculosImportadosDelphin.Count + "; aviso propio=" +
            externo.Cronograma.AdvertenciasImportacion.Contains(avisoPropio) + "; restricción=" +
            externo.Cronograma.AdvertenciasImportacion.Any(a => a.StartsWith("La restricción nativa Delphin de «", StringComparison.Ordinal)) +
            "; avisos nativos=" + vivo.Cronograma.AdvertenciasImportacion.Count);
        var esperadoExterno = MYGProyectoStorage.Copia(documento);
        esperadoExterno.Cronograma.Tareas.Single(t => t.PartidaId == "CC-002").Predecesoras.Add(new()
            { PredecesoraId = primera.Id, Tipo = MYGTipoVinculo.FC });
        Iguales(esperadoExterno, externo);
        pasa("Vínculos y diagnósticos importados se reconstruyen desde Delphin al abrir, sin sustituir predecesoras editadas ni advertencias propias");
    }

    private static void Muestra(string original, string carpeta, Action<string> pasa)
    {
        Exige(File.Exists(original), "No existe la muestra externa indicada.");
        string huella = Huella(original);
        long archivoAntes = new FileInfo(original).Length;
        string ruta = Path.Combine(carpeta, "Muestra privada almacenamiento compacto.sqlite");
        File.Copy(original, ruta, overwrite: false);
        long bytesAntes = BytesDocumento(ruta);
        var documentos = MYGBaseDatos.ListarProyectos(ruta).Select(p => MYGBaseDatos.LeerProyecto(ruta, p.Id)).ToList();
        var planes = documentos.Select(d => Resultado(d.Cronograma)).ToList();
        long dependenciasAntes = Escalar(ruta, "SELECT COUNT(*) FROM dependencia_tarea");
        for (int i = 0; i < documentos.Count; i++)
        {
            MYGProyectoStorage.Guardar(ruta, documentos[i]);
            var despues = MYGBaseDatos.LeerProyecto(ruta, documentos[i].Id);
            Iguales(documentos[i], despues);
            Exige(planes[i] == Resultado(despues.Cronograma), "La compactación cambió fechas o resultados calculados de la muestra.");
        }
        Exige(Escalar(ruta, "SELECT COUNT(*) FROM dependencia_tarea") == dependenciasAntes,
            "Guardar sin editar cambió el número de vínculos nativos de la muestra.");
        long bytesDespues = BytesDocumento(ruta);
        foreach (var proyecto in MYGBaseDatos.ListarProyectos(ruta))
        {
            var documento = MYGBaseDatos.LeerProyecto(ruta, proyecto.Id);
            MYGProyectoStorage.Guardar(ruta, documento);
            Iguales(documento, MYGBaseDatos.LeerProyecto(ruta, proyecto.Id));
        }
        Exige(BytesDocumento(ruta) <= bytesDespues + 256,
            "El segundo guardado produjo crecimiento acumulativo de extensiones.");
        using (var c = Conexion(ruta))
        using (var q = c.CreateCommand())
        {
            q.CommandText = "PRAGMA integrity_check";
            Exige((string)q.ExecuteScalar() == "ok", "Falló la integridad de la copia compactada.");
        }
        Exige(huella == Huella(original), "La prueba modificó la base original.");
        Console.WriteLine($"Muestra externa: JSON {bytesAntes:N0} → {bytesDespues:N0} bytes; archivo {archivoAntes:N0} → {new FileInfo(ruta).Length:N0} bytes; original intacto; sin publicar datos privados.");
        pasa("Muestra externa conserva documento, cálculo, dependencias e integridad al guardar/reabrir dos veces sobre una copia");
    }

    private static MYGProyectoDocumento Nativo(SqliteConnection c, string id) =>
        MYGDocumentoDelphinAlmacenamiento.Leer(c, JsonSerializer.Serialize(new {
            FormatoAlmacenamiento = "MYG_DELPHIN_EXTENSIONES", VersionAlmacenamiento = 1, Id = id, Cambios = (object)null }));

    private static void Iguales(MYGProyectoDocumento a, MYGProyectoDocumento b)
    {
        JsonNode Normalizar(MYGProyectoDocumento d)
        {
            var copia = MYGProyectoStorage.Copia(d);
            copia.ModificadoUtc = default;
            if (copia.Cronograma != null)
            {
                copia.Cronograma.AdvertenciasImportacion.Clear();
                copia.Cronograma.VinculosImportadosDelphin.Clear();
            }
            return JsonSerializer.SerializeToNode(copia);
        }
        Exige(JsonNode.DeepEquals(Normalizar(a), Normalizar(b)), "Se perdió o cambió información editable MYG al reconstruir extensiones compactas.");
    }

    private static string Resultado(MYGCronograma plan) => plan == null ? "null" : JsonSerializer.Serialize(
        MYGMotorCronograma.Calcular(plan).Filas.Select(f => new { Id = f.Tarea.Id, f.Inicio, f.Fin, f.DuracionDias, f.HolguraDias, f.EsCritica }));

    private static SqliteConnection Conexion(string ruta, bool escribir = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta,
            Mode = escribir ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        c.Open(); return c;
    }
    private static void SQL(string ruta, string sql)
    {
        using var c = Conexion(ruta, true); using var q = c.CreateCommand();
        q.CommandText = sql; q.ExecuteNonQuery();
    }
    private static long Escalar(string ruta, string sql)
    {
        using var c = Conexion(ruta); using var q = c.CreateCommand();
        q.CommandText = sql; return Convert.ToInt64(q.ExecuteScalar());
    }
    private static long BytesDocumento(string ruta) => Escalar(ruta, "SELECT COALESCE(SUM(length(CAST(json_documento AS BLOB))),0) FROM myg_proyecto");
    private static string Huella(string ruta) { using var s = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(s)); }
    private static void Exige(bool bien, string mensaje) { if (!bien) throw new Exception(mensaje); }
    private static void Rechaza(Action accion)
    {
        try { accion(); } catch (InvalidDataException) { return; }
        throw new Exception("Se aceptó una referencia agrupada corrupta.");
    }
}
