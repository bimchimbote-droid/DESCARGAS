using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DocumentoDelphinAlmacenamientoCheck
{
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Extensiones Delphin sin duplicados.sqlite");
        var semilla = MYGProyectoStorage.Nuevo("Conservación nativa");
        semilla.Id = "PR-ALMACEN";
        var presupuesto = semilla.Presupuestos.Single();
        presupuesto.Id = "PS-ALMACEN";
        semilla.PresupuestoActivoId = presupuesto.Id;
        for (int n = 0; n < 20; n++)
            presupuesto.Items.Add(new()
            {
                Id = "CU-" + n.ToString("D3"), IdLocalMYG = "LOCAL-" + n.ToString("D3"),
                TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
                Descripcion = "Partida nativa sintética " + n, Unidad = "m³", Posicion = n + 1,
                Costos = new() { Cantidad = n + 1, PrecioDirecto = 12.25m }
            });
        MYGProyectoStorage.Guardar(ruta, semilla);
        using var conexion = Conexion(ruta);
        var nativo = MYGDocumentoDelphinAlmacenamiento.Leer(conexion,
            "{\"FormatoAlmacenamiento\":\"MYG_DELPHIN_EXTENSIONES\",\"VersionAlmacenamiento\":1," +
            "\"Id\":\"PR-ALMACEN\",\"Cambios\":null}");
        string completo = MYGJsonAlmacenamiento.Serializar(nativo);
        string sinCambios = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, nativo);
        using (var json = JsonDocument.Parse(sinCambios))
            Exige(json.RootElement.GetProperty("Cambios").ValueKind == JsonValueKind.Null,
                "El documento guarda copias de datos que ya se encuentran en las tablas nativas.");
        Exige(sinCambios.Length < completo.Length / 3, "El almacenamiento de extensiones sigue duplicando el documento nativo.");
        Iguales(nativo, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, sinCambios));
        pasa("Documento Delphin se reconstruye desde sus tablas nativas sin duplicar presupuestos, partidas ni costos intactos");

        // Fixture explícita del formato anterior: conserva la operación 'a'
        // y sus referencias por Id, sin usar el codificador actual para crearla.
        var esperadoLegado = MYGProyectoStorage.Copia(nativo);
        esperadoLegado.Presupuestos.Single().Nombre = "Presupuesto de versión 1";
        var legado = new JsonObject
        {
            ["FormatoAlmacenamiento"] = "MYG_DELPHIN_EXTENSIONES", ["VersionAlmacenamiento"] = 1,
            ["Id"] = nativo.Id,
            ["Cambios"] = new JsonArray("o", new JsonObject
            {
                ["Presupuestos"] = new JsonArray("a", new JsonArray(new JsonArray("r", presupuesto.Id,
                    new JsonArray("o", new JsonObject { ["Nombre"] = new JsonArray("v", "Presupuesto de versión 1") }, new JsonArray()))),
                    new JsonArray(presupuesto.Id))
            }, new JsonArray())
        };
        Iguales(esperadoLegado, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, legado.ToJsonString()));
        pasa("Lectura mantiene compatibilidad con listas por identidad y diferencias de documentos versión 1");

        var repetido = MYGProyectoStorage.Copia(nativo);
        foreach (var item in repetido.Presupuestos.Single().Items) item.Origen = "EXTENSION-SINTETICA";
        string agrupado = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, repetido);
        Iguales(repetido, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, agrupado));
        var raizAgrupada = JsonNode.Parse(agrupado);
        var listaAgrupada = BuscarAgrupada(raizAgrupada["Cambios"], 2);
        Exige(listaAgrupada != null && listaAgrupada[2].AsArray().Count == 1 &&
            listaAgrupada[3].AsArray().Count == 20,
            "Las diferencias idénticas de veinte partidas no se compartieron en un único patrón.");
        Exige(raizAgrupada["VersionAlmacenamiento"].GetValue<int>() == 2,
            "El escritor no identifica la versión necesaria para sus referencias agrupadas.");

        void RechazaAgrupada(Action<JsonArray> corromper, string detalle)
        {
            var copia = JsonNode.Parse(agrupado);
            var lista = BuscarAgrupada(copia["Cambios"], 2);
            Exige(lista != null, "No se encontró la lista agrupada de prueba.");
            corromper(lista);
            Rechaza(() => MYGDocumentoDelphinAlmacenamiento.Leer(conexion, copia.ToJsonString()), detalle);
        }
        RechazaAgrupada(g => g[3][1] = g[3][0].DeepClone(),
            "Una referencia agrupada duplicada fue aceptada.");
        RechazaAgrupada(g => g[1][1] = g[1][0].DeepClone(),
            "Una identidad duplicada de la membresía agrupada fue aceptada.");
        RechazaAgrupada(g => g[3][0] = new JsonArray(g[1].AsArray().Count, 0),
            "Una referencia agrupada fuera de rango fue aceptada.");
        RechazaAgrupada(g => g[3][0] = new JsonArray(-1, 0),
            "Una referencia agrupada negativa fue aceptada.");
        RechazaAgrupada(g => g[3][0] = new JsonArray(0, g[2].AsArray().Count),
            "Un patrón agrupado fuera de rango fue aceptado.");
        RechazaAgrupada(g => g[3][0] = new JsonArray(0, -1),
            "Un patrón agrupado negativo fue aceptado.");
        var versionAntiguaConGrupos = JsonNode.Parse(agrupado);
        versionAntiguaConGrupos["VersionAlmacenamiento"] = 1;
        Rechaza(() => MYGDocumentoDelphinAlmacenamiento.Leer(conexion, versionAntiguaConGrupos.ToJsonString()),
            "Una operación agrupada se aceptó con un marcador de versión 1.");
        pasa("Diferencias repetidas se guardan una sola vez y referencias agrupadas inválidas se rechazan sin pérdida silenciosa");

        var editado = MYGProyectoStorage.Copia(nativo);
        var p = editado.Presupuestos.Single();
        var partida = p.Items[0];
        partida.Costos.Cantidad = 0.1234567890123456789012345678m;
        partida.Costos.PrecioDirecto = 9876543210.123456789012345678m;
        partida.Costos.Hoja.Poner("B3", "3.1415926535897932384626433832");
        partida.Filtros.Add(new() { Parametro = "Nivel", Regla = "igual", Valor = "N-Ñ-漢字" });
        partida.Costos.EspecificacionTexto = "No es un comando: [\"r\",\"ID\",null]";
        editado.FuenteCatalogo = new() { Id = "EXTENSION", RutaSQLite = "C:\\Obras\\datos.sqlite" };
        // Cronograma es omitido al escribir null; el patch debe recordar el borrado.
        editado.Cronograma = null;
        string ampliado = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, editado);
        Iguales(editado, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, ampliado));
        Iguales(nativo, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, sinCambios));
        Exige(MYGJsonAlmacenamiento.Serializar(nativo) == completo, "El cálculo de diferencias modificó el documento original.");
        pasa("Extensiones preservan decimales de alta precisión, Unicode, null, hojas editadas, filtros y borrados sin mutar el documento original");

        p.Items.Reverse();
        string eliminada = p.Items[1].Id;
        p.Items.RemoveAt(1);
        p.Items.Insert(2, new()
        {
            Id = "NUEVO-ID", IdLocalMYG = "NUEVO-LOCAL", TipoPropuesta = "PARTIDA", Unidad = "und",
            Descripcion = "Partida propia con información adicional", Posicion = 99,
            Costos = new() { Cantidad = 5.75m, PrecioDirecto = 8.25m }
        });
        string ordenado = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, editado);
        Iguales(editado, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, ordenado));
        var vacio = MYGProyectoStorage.Copia(editado);
        vacio.Presupuestos[0].Items.Clear();
        string sinPartidas = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, vacio);
        Iguales(vacio, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, sinPartidas));
        vacio.Presupuestos.Clear();
        Iguales(vacio, MYGDocumentoDelphinAlmacenamiento.Leer(conexion,
            MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, vacio)));
        pasa("Extensiones conservan el orden por identidades, filas nuevas, eliminación de partidas y listas vacías sin resucitar datos borrados");

        for (int n = 0; n < 3; n++)
        {
            var leido = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, ordenado);
            string siguiente = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, leido);
            Exige(siguiente == ordenado, "Reabrir y serializar las mismas extensiones produce crecimiento acumulativo.");
            ordenado = siguiente;
        }
        Iguales(editado, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, MYGJsonAlmacenamiento.Serializar(editado)));
        var propio = MYGProyectoStorage.Nuevo("Proyecto MYG con identidad propia");
        string jsonPropio = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, propio);
        Exige(!jsonPropio.Contains("FormatoAlmacenamiento", StringComparison.Ordinal), "Se infirieron identidades nativas para un proyecto MYG.");
        Iguales(propio, MYGDocumentoDelphinAlmacenamiento.Leer(conexion, jsonPropio));
        pasa("Almacenamiento Delphin es estable en lecturas sucesivas y conserva compatibilidad con documentos completos anteriores y proyectos propios de MYG");

        var versionFutura = JsonNode.Parse(sinCambios);
        versionFutura["VersionAlmacenamiento"] = 99;
        Rechaza(() => MYGDocumentoDelphinAlmacenamiento.Leer(conexion, versionFutura.ToJsonString()),
            "Una versión futura de almacenamiento se interpretó silenciosamente.");
        var referenciaInvalida = JsonNode.Parse(ordenado);
        Exige(CorromperReferencia(referenciaInvalida["Cambios"]), "La prueba no ejercitó las listas por referencia.");
        Rechaza(() => MYGDocumentoDelphinAlmacenamiento.Leer(conexion, referenciaInvalida.ToJsonString()),
            "Una referencia a una fila nativa ausente perdió información silenciosamente.");
        pasa("Almacenamiento rechaza versiones desconocidas y referencias nativas ausentes con un error explícito");

        using (var escritura = Conexion(ruta, escritura: true))
        {
            var columnas = new System.Collections.Generic.List<string>();
            using (var consulta = escritura.CreateCommand())
            {
                consulta.CommandText = "PRAGMA table_info('costo_unitario')";
                using var lector = consulta.ExecuteReader();
                while (lector.Read()) columnas.Add(lector.GetString(1));
            }
            using var alta = escritura.CreateCommand();
            string Columna(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";
            alta.CommandText = "INSERT INTO costo_unitario(" + string.Join(",", columnas.Select(Columna)) + ") SELECT " +
                string.Join(",", columnas.Select(c => c == "id_costounitario" ? "$nuevo" : Columna(c))) +
                " FROM costo_unitario WHERE id_costounitario=$origen";
            alta.Parameters.AddWithValue("$nuevo", "CU-EXTERNA");
            alta.Parameters.AddWithValue("$origen", nativo.Presupuestos[0].Items[0].Id);
            Exige(alta.ExecuteNonQuery() == 1, "No se añadió la fila nativa externa de prueba.");
        }
        var conAltaExterna = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, ordenado).Presupuestos.Single().Items;
        Exige(conAltaExterna.Count == p.Items.Count + 1 && conAltaExterna.Last().Id == "CU-EXTERNA" &&
            conAltaExterna.Take(p.Items.Count).Select(i => i.Id).SequenceEqual(p.Items.Select(i => i.Id)) &&
            !conAltaExterna.Any(i => i.Id == eliminada) &&
            conAltaExterna.Single(i => i.Id == partida.Id).Costos.Cantidad == partida.Costos.Cantidad,
            "Las extensiones ocultaron un alta nativa posterior, resucitaron una baja explícita o perdieron las ediciones MYG.");
        Exige(MYGDocumentoDelphinAlmacenamiento.Leer(conexion, sinPartidas).Presupuestos.Single().Items.Single().Id == "CU-EXTERNA",
            "Una lista vaciada antes del alta externa ocultó la nueva partida o resucitó sus partidas eliminadas.");
        var vacioConAlta = MYGDocumentoDelphinAlmacenamiento.Leer(conexion,
            MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, vacio));
        Exige(vacioConAlta.Presupuestos.Count == 0,
            "Serializar un documento vacío contra la base actual resucitó un presupuesto eliminado expresamente.");
        pasa("Extensiones incorporan altas nativas posteriores manteniendo el orden MYG y las bajas explícitas de sus miembros originales");

        // La base nativa sin fechas inicializa el plan con el día de apertura.
        // Simulamos otra fecha base modificando sólo la copia sintética; no se
        // cambia el reloj del proceso ni se espera al siguiente día real.
        using (var escritura = Conexion(ruta, escritura: true))
        using (var comando = escritura.CreateCommand())
        {
            comando.CommandText = "UPDATE proyecto SET fecha_inicio=NULL,fecha_proyecto=NULL,fecha_fin=NULL WHERE id_proyecto='PR-ALMACEN'; " +
                "UPDATE costo_unitario SET fecha_inicio='01/01/2026',fecha_fin='02/01/2026',duracion=2 WHERE id_presupuesto='PS-ALMACEN'";
            comando.ExecuteNonQuery();
        }
        var sinFechas = MYGDocumentoDelphinAlmacenamiento.Leer(conexion,
            "{\"FormatoAlmacenamiento\":\"MYG_DELPHIN_EXTENSIONES\",\"VersionAlmacenamiento\":1," +
            "\"Id\":\"PR-ALMACEN\",\"Cambios\":null}");
        Exige(sinFechas.Datos.FechaInicio == null && sinFechas.Datos.FechaElaboracion == null && sinFechas.Cronograma != null,
            "La muestra sintética no ejercita el cronograma sin fechas nativas.");
        string fijo = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, sinFechas);
        var patchFijo = JsonNode.Parse(fijo)["Cambios"];
        Exige(patchFijo[1]["Cronograma"][0].GetValue<string>() == "v",
            "El cronograma inicializado por el día de apertura sigue dependiendo de una futura lectura nativa.");
        using (var escritura = Conexion(ruta, escritura: true))
        using (var comando = escritura.CreateCommand())
        {
            comando.CommandText = "UPDATE proyecto SET fecha_inicio=$fecha,fecha_proyecto=$fecha WHERE id_proyecto='PR-ALMACEN'";
            comando.Parameters.AddWithValue("$fecha", sinFechas.Cronograma.FechaInicio.AddDays(1).ToString("dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture));
            comando.ExecuteNonQuery();
        }
        var despues = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, fijo);
        Exige(JsonElement.DeepEquals(JsonSerializer.SerializeToElement(sinFechas.Cronograma), JsonSerializer.SerializeToElement(despues.Cronograma)),
            "Cambiar la fecha base de lectura desplazó el cronograma guardado sin fechas nativas.");
        pasa("Cronograma sin fechas nativas conserva su instantánea completa aunque cambie el día base de la siguiente apertura");

        var conAvisosPropios = MYGProyectoStorage.Copia(sinFechas);
        string[] avisosPropios =
        {
            "La partida «CU-000» debe revisarse antes de publicar.",
            "La restricción nativa Delphin de «CU-000» requiere autorización del responsable.",
            "El calendario Delphin no contiene la excepción particular del usuario."
        };
        conAvisosPropios.Cronograma.AdvertenciasImportacion.AddRange(avisosPropios);
        string conAvisos = MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, conAvisosPropios);
        var avisosRecuperados = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, conAvisos).Cronograma.AdvertenciasImportacion;
        Exige(avisosPropios.All(a => avisosRecuperados.Contains(a, StringComparer.Ordinal)),
            "Un aviso propio con prefijo parecido al lector Delphin fue descartado.");
        var conListaNula = JsonNode.Parse(conAvisos);
        conListaNula["Cambios"][1]["Cronograma"][1]["AdvertenciasImportacion"] = null;
        var recuperadaDeNulo = MYGDocumentoDelphinAlmacenamiento.Leer(conexion, conListaNula.ToJsonString()).Cronograma.AdvertenciasImportacion;
        Exige(avisosPropios.All(a => recuperadaDeNulo.Contains(a, StringComparer.Ordinal)),
            "Los avisos adicionales no reconstruyeron una lista de importación nula.");
        pasa("Avisos propios con prefijos similares a Delphin sobreviven y sus listas nulas se reconstruyen sin error");

        var fechado = MYGDocumentoDelphinAlmacenamiento.Leer(conexion,
            "{\"FormatoAlmacenamiento\":\"MYG_DELPHIN_EXTENSIONES\",\"VersionAlmacenamiento\":1," +
            "\"Id\":\"PR-ALMACEN\",\"Cambios\":null}");
        Exige(fechado.Datos.FechaInicio.HasValue && fechado.Cronograma != null,
            "La prueba de firmas no tiene un cronograma nativo con fecha estable.");
        fechado.Cronograma.AdvertenciasImportacion.Add(
            "El vínculo Delphin «ANTIGUO-SOLO-CACHE» se conserva en el archivo; MYG no puede calcularlo como vínculo entre tareas individuales.");
        fechado.Cronograma.VinculosImportadosDelphin.Add(new()
            { Id = "ANTIGUO-SOLO-CACHE", OrigenId = "CU-000", DestinoId = "CU-001", Tipo = 0 });
        string confirmado = MYGColaboracionLocal.ExportarDocumento(fechado);
        var actualizado = MYGDocumentoDelphinAlmacenamiento.Leer(conexion,
            MYGDocumentoDelphinAlmacenamiento.Serializar(conexion, null, fechado));
        MYGVinculoNube Vinculo(string rol) => new()
        {
            ProyectoId = Guid.Parse("55555555-5555-4555-8555-555555555555"),
            UsuarioId = "66666666-6666-4666-8666-666666666666", Servidor = "https://prueba.example", Rol = rol,
            Revision = 1, JsonConfirmado = confirmado
        };
        var vinculoLector = Vinculo("lector");
        Exige(MYGColaboracionLocal.PrepararPendiente(actualizado, vinculoLector) == null && vinculoLector.Pendiente == null,
            "Regenerar diagnósticos nativos rechazó un documento de solo lectura sin ediciones.");
        var editor = Vinculo("editor");
        Exige(MYGColaboracionLocal.PrepararPendiente(actualizado, editor) == null && editor.Pendiente == null,
            "Regenerar diagnósticos nativos creó una operación fantasma para el editor.");
        Exige(vinculoLector.JsonConfirmado == confirmado && editor.JsonConfirmado == confirmado &&
            MYGColaboracionLocal.ExportarDocumento(fechado) == confirmado,
            "La firma de comparación modificó el documento o el cuerpo confirmado de colaboración.");
        void RechazaSoloLectura(MYGProyectoDocumento modificado, string detalle)
        {
            try { MYGColaboracionLocal.PrepararPendiente(modificado, Vinculo("lector")); }
            catch (InvalidOperationException) { return; }
            throw new Exception(detalle);
        }
        var conNota = MYGProyectoStorage.Copia(actualizado);
        conNota.Cronograma.Tareas.First(t => !t.EsResumen).Notas = "Cambio editable que debe seguir protegido";
        RechazaSoloLectura(conNota, "Ignorar diagnósticos permitió editar notas con rol de solo lectura.");
        var conAvisoNuevo = MYGProyectoStorage.Copia(actualizado);
        conAvisoNuevo.Cronograma.AdvertenciasImportacion.Add("La partida «CU-000» necesita revisión personal.");
        RechazaSoloLectura(conAvisoNuevo, "Ignorar diagnósticos descartó también una advertencia propia editable.");
        var propioConCache = MYGProyectoStorage.Copia(fechado);
        propioConCache.Id = Guid.NewGuid().ToString("N");
        var propioSinCache = MYGProyectoStorage.Copia(propioConCache);
        propioSinCache.Cronograma.VinculosImportadosDelphin.Clear();
        Exige(MYGProyectoStorage.Firma(propioConCache) != MYGProyectoStorage.Firma(propioSinCache),
            "La exclusión de cachés se aplicó a una identidad propia MYG ajena a las extensiones nativas.");
        pasa("Firmas de colaboración ignoran sólo cachés nativas regeneradas, sin operaciones fantasma, sin alterar cuerpos y conservando la protección de notas y avisos propios");
    }

    private static bool CorromperReferencia(JsonNode nodo)
    {
        if (nodo is JsonArray lista)
        {
            if (lista.Count == 3 && lista[0] is JsonValue tipo && tipo.TryGetValue<string>(out string texto) && texto == "r")
            { lista[1] = "REFERENCIA-AUSENTE"; return true; }
            if (EsAgrupada(lista) && lista[1] is JsonArray miembros && miembros.Count > 0)
            { miembros[0] = "REFERENCIA-AUSENTE"; return true; }
            foreach (var elemento in lista) if (CorromperReferencia(elemento)) return true;
        }
        else if (nodo is JsonObject objeto)
            foreach (var campo in objeto) if (CorromperReferencia(campo.Value)) return true;
        return false;
    }

    private static bool EsAgrupada(JsonArray lista) => lista.Count == 4 &&
        lista[0] is JsonValue etiqueta && etiqueta.TryGetValue<string>(out string tipo) && tipo == "g";

    private static JsonArray BuscarAgrupada(JsonNode nodo, int minimoMiembros)
    {
        if (nodo is JsonArray lista)
        {
            if (EsAgrupada(lista) && lista[1] is JsonArray miembros && miembros.Count >= minimoMiembros) return lista;
            foreach (var elemento in lista)
                if (BuscarAgrupada(elemento, minimoMiembros) is { } encontrada) return encontrada;
        }
        else if (nodo is JsonObject objeto)
            foreach (var campo in objeto)
                if (BuscarAgrupada(campo.Value, minimoMiembros) is { } encontrada) return encontrada;
        return null;
    }

    private static SqliteConnection Conexion(string ruta, bool escritura = false)
    {
        SQLiteDependencyBootstrapper.Initialize();
        var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = escritura ? SqliteOpenMode.ReadWrite : SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        conexion.Open(); return conexion;
    }

    private static void Iguales(MYGProyectoDocumento esperado, MYGProyectoDocumento real) =>
        Exige(JsonElement.DeepEquals(JsonSerializer.SerializeToElement(esperado), JsonSerializer.SerializeToElement(real)),
            "La materialización perdió o cambió información del documento MYG.");
    private static void Exige(bool condicion, string detalle) { if (!condicion) throw new Exception(detalle); }
    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception(detalle);
    }
}
