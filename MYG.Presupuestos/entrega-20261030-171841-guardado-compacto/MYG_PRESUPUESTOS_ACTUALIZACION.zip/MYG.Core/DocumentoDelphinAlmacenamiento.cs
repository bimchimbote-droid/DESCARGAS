using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

/// <summary>Las tablas Delphin son la fuente de los datos nativos; el documento
/// adicional conserva únicamente diferencias y extensiones de MYG. El formato
/// de intercambio y las bases anteriores siguen conteniendo documentos completos.</summary>
public static class MYGDocumentoDelphinAlmacenamiento
{
    private const string Formato = "MYG_DELPHIN_EXTENSIONES";
    private const int Version = 2;
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private static readonly JsonDocumentOptions LecturaJson = new() { MaxDepth = 128 };

    // Invocar después de sincronizar las tablas nativas, en la MISMA transacción.
    // Los proyectos creados por MYG usan identidades distintas de las nativas y
    // conservan su documento compacto completo, sin intentar inferir equivalencias.
    public static string Serializar(SqliteConnection conexion, SqliteTransaction transaccion,
        MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(conexion);
        ArgumentNullException.ThrowIfNull(documento);
        if (!string.Equals(documento.Id, MYGDelphinFormato.IdNativo(documento.Id), StringComparison.Ordinal))
            return MYGJsonAlmacenamiento.Serializar(documento);

        var nativo = DelphinImportacionMYG.LeerProyecto(conexion, documento.Id, transaccion);
        var actual = Nodo(documento);
        var baseNativa = Nodo(nativo);
        var avisosAdicionales = new JsonArray();
        if (actual["Cronograma"] is JsonObject plan && baseNativa["Cronograma"] is JsonObject planNativo)
        {
            // Estas dos listas describen la importación, no las predecesoras
            // editables de las tareas. Después de sincronizar, su fuente es la
            // base nativa actual; persistir las listas antiguas duplica datos y
            // vuelve a mostrar avisos de vínculos ya corregidos.
            foreach (string aviso in (documento.Cronograma.AdvertenciasImportacion ?? new()).Distinct(StringComparer.Ordinal))
                if (!EsAvisoNativo(aviso) && !(nativo.Cronograma.AdvertenciasImportacion ?? new()).Contains(aviso, StringComparer.Ordinal))
                    avisosAdicionales.Add(aviso);
            plan["VinculosImportadosDelphin"] = planNativo["VinculosImportadosDelphin"]?.DeepClone();
            plan["AdvertenciasImportacion"] = planNativo["AdvertenciasImportacion"]?.DeepClone();
        }
        var cambios = Diferencia(baseNativa, actual);
        // Sin fechas de proyecto el importador inicializa el cronograma con el
        // día de apertura. Ese valor es una instantánea de MYG, no un dato nativo
        // reproducible: debe conservarse incluso si hoy coincide con la lectura.
        if (documento.Cronograma != null && documento.Datos?.FechaInicio == null &&
            documento.Datos?.FechaElaboracion == null)
        {
            cambios ??= new JsonArray("o", new JsonObject(), new JsonArray());
            cambios[1]["Cronograma"] = Valor(actual["Cronograma"]);
        }
        var salida = new JsonObject
        {
            ["FormatoAlmacenamiento"] = Formato,
            ["VersionAlmacenamiento"] = Version,
            ["Id"] = documento.Id,
            // ListarProyectos consulta estos dos campos sin materializar documentos.
            ["Datos"] = actual["Datos"]?.DeepClone(),
            ["Cambios"] = cambios
        };
        if (avisosAdicionales.Count > 0) salida["AdvertenciasAdicionalesCronograma"] = avisosAdicionales;
        return salida.ToJsonString(Json);
    }

    public static MYGProyectoDocumento Leer(SqliteConnection conexion, string json)
    {
        ArgumentNullException.ThrowIfNull(conexion);
        using var estructura = JsonDocument.Parse(json, LecturaJson);
        if (estructura.RootElement.ValueKind != JsonValueKind.Object)
            throw Invalido("El documento de almacenamiento no es un objeto JSON.");
        if (!estructura.RootElement.TryGetProperty("FormatoAlmacenamiento", out var formato))
            return MYGJsonAlmacenamiento.Deserializar<MYGProyectoDocumento>(json);
        if (formato.ValueKind != JsonValueKind.String || formato.GetString() != Formato ||
            !estructura.RootElement.TryGetProperty("VersionAlmacenamiento", out var version) || version.ValueKind != JsonValueKind.Number ||
            !version.TryGetInt32(out int numero) || numero is < 1 or > Version ||
            !estructura.RootElement.TryGetProperty("Id", out var identidad) || identidad.ValueKind != JsonValueKind.String ||
            string.IsNullOrWhiteSpace(identidad.GetString()) ||
            !estructura.RootElement.TryGetProperty("Cambios", out _))
            throw Invalido("Formato o versión de extensiones Delphin no compatible.");
        string id = identidad.GetString();
        var nativo = DelphinImportacionMYG.LeerProyecto(conexion, id);
        var raiz = JsonNode.Parse(json, documentOptions: LecturaJson);
        var restaurado = Aplicar(Nodo(nativo), raiz["Cambios"], numero >= 2);
        if (restaurado is not JsonObject) throw Invalido("Las extensiones no contienen un proyecto válido.");
        var documento = MYGJsonAlmacenamiento.Deserializar<MYGProyectoDocumento>(restaurado.ToJsonString(Json));
        if (!string.Equals(id, documento?.Id, StringComparison.Ordinal))
            throw Invalido("La identidad de las extensiones no coincide con el proyecto nativo.");
        if (raiz.AsObject().TryGetPropertyValue("AdvertenciasAdicionalesCronograma", out var avisos))
        {
            if (numero < 2 || avisos is not JsonArray lista || documento.Cronograma == null)
                throw Invalido("Las advertencias adicionales del cronograma no son válidas.");
            documento.Cronograma.AdvertenciasImportacion ??= new();
            foreach (var aviso in lista)
            {
                if (aviso is not JsonValue valor || !valor.TryGetValue<string>(out string texto) || texto == null)
                    throw Invalido("Una advertencia adicional del cronograma está dañada.");
                if (!documento.Cronograma.AdvertenciasImportacion.Contains(texto, StringComparer.Ordinal))
                    documento.Cronograma.AdvertenciasImportacion.Add(texto);
            }
        }
        return documento;
    }

    // Usar únicamente sobre la copia destinada a una firma de comparación.
    // Los documentos exportados y los cuerpos de cola enviados siguen íntegros.
    internal static void OmitirDiagnosticosParaComparacion(MYGProyectoDocumento documento)
    {
        if (documento?.Cronograma == null ||
            !string.Equals(documento.Id, MYGDelphinFormato.IdNativo(documento.Id), StringComparison.Ordinal)) return;
        documento.Cronograma.VinculosImportadosDelphin = new();
        documento.Cronograma.AdvertenciasImportacion = (documento.Cronograma.AdvertenciasImportacion ?? new())
            .Where(aviso => !EsAvisoNativo(aviso)).Distinct(StringComparer.Ordinal).ToList();
    }

    // Sólo diagnósticos generados por los lectores nativos y su migración.
    // Las notas, líneas base, responsables y avisos ajenos se conservan.
    private static bool EsAvisoNativo(string aviso)
    {
        if (aviso == null) return false;
        // Reconocer la plantilla completa evita descartar avisos propios que
        // sólo comparten un comienzo, por ejemplo «La partida ...».
        bool Plantilla(string prefijo, string sufijo) =>
            aviso.StartsWith(prefijo, StringComparison.Ordinal) && aviso.EndsWith(sufijo, StringComparison.Ordinal);
        return aviso is
            "La red Delphin contiene un ciclo. Se muestran las fechas guardadas y se conservan sus vínculos originales, sin calcular la red circular." or
            "El calendario Delphin no contiene una semana laborable válida; se utiliza lunes a viernes." or
            "El calendario Delphin tiene jornadas de distinta duración. MYG conserva las fechas nativas y usa la jornada máxima para tareas nuevas." or
            "La ficha Delphin contiene una fecha final anterior al inicio. Se conservan ambas fechas originales; para editar la ficha del proyecto debe corregirlas expresamente." or
            "La duración nativa Delphin no es positiva. MYG muestra 1 como valor de presentación; la duración original se conserva en el archivo mientras no se cambie expresamente." ||
            Plantilla("La restricción nativa Delphin de «", ") se conserva en el archivo y en sus fechas importadas. Su código nativo aún no se traduce a una restricción MYG.") ||
            Plantilla("No se pudo representar el tramo Delphin «", "»: sus fechas no son válidas.") ||
            Plantilla("La partida «", "» carece de fechas de programación válidas; requiere programación en MYG.") ||
            Plantilla("La duración fraccionaria de «", "» se representa en días laborables completos; se conservan las fechas y tramos nativos.") ||
            Plantilla("El vínculo Delphin «", "» se conserva en el archivo; MYG no puede calcularlo como vínculo entre tareas individuales.") ||
            Plantilla("El modo de tarea Delphin de «", "); se utiliza Automática y se conservan las fechas importadas.") ||
            Plantilla("La excepción de calendario «", "» requiere una regla que MYG aún no calcula; las fechas nativas se conservan.") ||
            Plantilla("Se actualizó la lectura del modo, fechas y duración de ",
                " tareas Delphin importadas con una versión anterior. La base original no se modificó al abrirla.");
    }

    private static JsonObject Nodo(MYGProyectoDocumento documento) =>
        JsonNode.Parse(MYGJsonAlmacenamiento.Serializar(documento), documentOptions: LecturaJson).AsObject();

    // El patch tiene un vocabulario propio; nunca interpreta propiedades del
    // documento del usuario como instrucciones. null significa sin diferencias;
    // un null explícito se representa ['v',null], y una lista vacía ['v',[]].
    private static JsonNode Diferencia(JsonNode anterior, JsonNode actual)
    {
        if (JsonNode.DeepEquals(anterior, actual)) return null;
        if (anterior is JsonObject objetoAnterior && actual is JsonObject objetoActual)
        {
            var campos = new JsonObject();
            var borrados = new JsonArray();
            foreach (var campo in objetoAnterior)
                if (!objetoActual.ContainsKey(campo.Key)) borrados.Add(campo.Key);
            foreach (var campo in objetoActual)
            {
                if (!objetoAnterior.TryGetPropertyValue(campo.Key, out var valorAnterior))
                    campos[campo.Key] = Valor(campo.Value);
                else
                {
                    var diferencia = Diferencia(valorAnterior, campo.Value);
                    if (diferencia != null) campos[campo.Key] = diferencia;
                }
            }
            return new JsonArray("o", campos, borrados);
        }
        if (anterior is JsonArray listaAnterior && actual is JsonArray listaActual &&
            Identidades(listaAnterior, out var indice) && Identidades(listaActual, out _))
        {
            var elementos = new JsonArray();
            var membresia = new JsonArray();
            var posiciones = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (string id in indice.Keys)
            {
                posiciones.Add(id, membresia.Count);
                membresia.Add(id);
            }
            var patrones = new JsonArray();
            var patronesPorTexto = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var elemento in listaActual)
            {
                string id = elemento["Id"].GetValue<string>();
                if (!indice.TryGetValue(id, out var original))
                { elementos.Add(Valor(elemento)); continue; }
                int posicion = posiciones[id];
                var diferencia = Diferencia(original, elemento);
                if (diferencia == null)
                { elementos.Add(posicion); continue; }
                string texto = diferencia.ToJsonString(Json);
                if (!patronesPorTexto.TryGetValue(texto, out int patron))
                {
                    patron = patrones.Count;
                    patronesPorTexto.Add(texto, patron);
                    patrones.Add(diferencia);
                }
                elementos.Add(new JsonArray(posicion, patron));
            }
            // La membresía original permite distinguir las bajas expresas de
            // MYG de las filas añadidas después por Delphin. Estas últimas no
            // deben desaparecer al aplicar una extensión de otra partida.
            // No sustituir este patch por la lista completa aunque ocupe menos:
            // también una lista pequeña o vaciada debe reconocer altas nativas
            // posteriores en vez de ocultarlas bajo una instantánea completa.
            // Una misma diferencia (por ejemplo, desactivar una instantánea
            // importada) se guarda una vez aunque afecte a miles de tareas.
            // Las referencias numéricas evitan repetir las identidades nativas.
            return new JsonArray("g", membresia, patrones, elementos);
        }
        return Valor(actual);
    }

    private static bool Identidades(JsonArray lista, out Dictionary<string, JsonNode> indice)
    {
        indice = new Dictionary<string, JsonNode>(StringComparer.Ordinal);
        foreach (var elemento in lista)
        {
            if (elemento is not JsonObject objeto || objeto["Id"] is not JsonValue valor ||
                !valor.TryGetValue<string>(out string id) || string.IsNullOrEmpty(id) ||
                !indice.TryAdd(id, elemento)) return false;
        }
        return true;
    }

    private static JsonArray Valor(JsonNode valor) => new("v", valor?.DeepClone());

    private static JsonNode Aplicar(JsonNode anterior, JsonNode patch, bool permitirAgrupadas)
    {
        if (patch == null) return anterior?.DeepClone();
        if (patch is not JsonArray instrucciones || instrucciones.Count == 0 ||
            instrucciones[0] is not JsonValue etiqueta || !etiqueta.TryGetValue<string>(out string tipo))
            throw Invalido("Las extensiones del documento están dañadas.");
        if (tipo == "v" && instrucciones.Count == 2) return instrucciones[1]?.DeepClone();
        if (tipo == "o" && instrucciones.Count == 3 && anterior is JsonObject objetoAnterior &&
            instrucciones[1] is JsonObject campos && instrucciones[2] is JsonArray borrados)
        {
            var resultado = (JsonObject)objetoAnterior.DeepClone();
            foreach (var borrado in borrados)
            {
                if (borrado is not JsonValue nombre || !nombre.TryGetValue<string>(out string campo) ||
                    !resultado.Remove(campo)) throw Invalido("Una propiedad nativa requerida ya no existe.");
            }
            foreach (var campo in campos)
            {
                resultado.TryGetPropertyValue(campo.Key, out var original);
                resultado[campo.Key] = Aplicar(original, campo.Value, permitirAgrupadas);
            }
            return resultado;
        }
        if (tipo == "a" && instrucciones.Count == 3 && anterior is JsonArray listaAnterior &&
            instrucciones[1] is JsonArray elementos && instrucciones[2] is JsonArray membresia &&
            Identidades(listaAnterior, out var indice))
        {
            var resultado = new JsonArray();
            var referencias = new HashSet<string>(StringComparer.Ordinal);
            var originales = new HashSet<string>(StringComparer.Ordinal);
            foreach (var identidadOriginal in membresia)
                if (identidadOriginal is not JsonValue valorOriginal || !valorOriginal.TryGetValue<string>(out string idOriginal) ||
                    string.IsNullOrEmpty(idOriginal) || !originales.Add(idOriginal))
                    throw Invalido("La membresía original de una lista está dañada.");
            foreach (var entrada in elementos)
            {
                if (entrada is not JsonArray elemento || elemento.Count == 0 || elemento[0] is not JsonValue marca ||
                    !marca.TryGetValue<string>(out string operacion)) throw Invalido("Una referencia de la lista está dañada.");
                if (operacion == "v" && elemento.Count == 2) resultado.Add(elemento[1]?.DeepClone());
                else if (operacion == "r" && elemento.Count == 3 && elemento[1] is JsonValue identidad &&
                    identidad.TryGetValue<string>(out string id) && originales.Contains(id) &&
                    referencias.Add(id) && indice.TryGetValue(id, out var original))
                    resultado.Add(Aplicar(original, elemento[2], permitirAgrupadas));
                else throw Invalido("Falta una fila nativa requerida por las extensiones Delphin.");
            }
            if (!Identidades(resultado, out var presentes)) throw Invalido("Las extensiones contienen identidades de lista inválidas.");
            foreach (var nueva in listaAnterior)
            {
                string id = nueva["Id"].GetValue<string>();
                if (!originales.Contains(id) && !presentes.ContainsKey(id)) resultado.Add(nueva.DeepClone());
            }
            return resultado;
        }
        if (permitirAgrupadas && tipo == "g" && instrucciones.Count == 4 && anterior is JsonArray listaNativa &&
            instrucciones[1] is JsonArray miembros && instrucciones[2] is JsonArray patrones &&
            instrucciones[3] is JsonArray entradas && Identidades(listaNativa, out var porId))
        {
            var ids = new List<string>();
            var originales = new HashSet<string>(StringComparer.Ordinal);
            foreach (var miembro in miembros)
            {
                if (miembro is not JsonValue valor || !valor.TryGetValue<string>(out string id) ||
                    string.IsNullOrEmpty(id) || !originales.Add(id))
                    throw Invalido("La membresía original de una lista agrupada está dañada.");
                ids.Add(id);
            }
            var resultado = new JsonArray();
            var referencias = new HashSet<int>();
            foreach (var entrada in entradas)
            {
                int posicion, patron = -1;
                if (entrada is JsonValue referencia && referencia.TryGetValue<int>(out posicion)) { }
                else if (entrada is JsonArray elemento && elemento.Count == 2)
                {
                    if (elemento[0] is JsonValue marca && marca.TryGetValue<string>(out string operacion) && operacion == "v")
                    { resultado.Add(elemento[1]?.DeepClone()); continue; }
                    if (elemento[0] is not JsonValue numero || !numero.TryGetValue<int>(out posicion) ||
                        elemento[1] is not JsonValue numeroPatron || !numeroPatron.TryGetValue<int>(out patron) ||
                        patron < 0 || patron >= patrones.Count)
                        throw Invalido("Una referencia agrupada o su patrón están dañados.");
                }
                else throw Invalido("Una referencia de la lista agrupada está dañada.");
                if (posicion < 0 || posicion >= ids.Count || !referencias.Add(posicion) ||
                    !porId.TryGetValue(ids[posicion], out var original))
                    throw Invalido("Falta una fila nativa requerida por las extensiones agrupadas Delphin.");
                resultado.Add(patron < 0 ? original.DeepClone() : Aplicar(original, patrones[patron], permitirAgrupadas));
            }
            if (!Identidades(resultado, out var presentes))
                throw Invalido("Las extensiones agrupadas contienen identidades de lista inválidas.");
            foreach (var nueva in listaNativa)
            {
                string id = nueva["Id"].GetValue<string>();
                if (!originales.Contains(id) && !presentes.ContainsKey(id)) resultado.Add(nueva.DeepClone());
            }
            return resultado;
        }
        throw Invalido("La operación de extensiones Delphin no es compatible con sus datos nativos.");
    }

    private static InvalidDataException Invalido(string mensaje) => new(mensaje);
}
