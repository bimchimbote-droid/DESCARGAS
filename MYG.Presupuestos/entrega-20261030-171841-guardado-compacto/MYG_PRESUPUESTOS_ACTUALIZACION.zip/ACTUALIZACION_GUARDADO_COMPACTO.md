# Guardado compacto de cronogramas

Base de la entrega: `main`, commit `157d267aaf68dd53fed115e549cf79abecdb4d77`.
Tecnologías: C#, SDK .NET 10.0.100 y Microsoft.Data.Sqlite 10.0.0.

## Qué cambia

Las tablas nativas de Delphin siguen siendo la fuente de los datos nativos.
Al guardar un proyecto con identidad nativa, las extensiones MYG usan el formato
versionado 2: cada identidad se registra una vez y las diferencias idénticas
entre tareas comparten un único patrón. Se conservan el orden y las bajas
expresas, y se reconocen altas nativas posteriores.

Los vínculos importados y los diagnósticos reconocidos del importador se vuelven
a leer desde las tablas actuales de Delphin. No se conservan copias históricas
de esos diagnósticos. Las predecesoras editables, notas, líneas base, responsables,
cuadrillas, preferencias, calendarios propios, tareas sin partida y avisos ajenos
al importador permanecen en las extensiones cuando no pueden reconstruirse
exactamente desde Delphin. No se eliminan las tablas de propiedad de filas MYG.

La lectura admite documentos completos anteriores y extensiones versión 1.
Abrir no migra ni escribe: la conversión se hace al pulsar Guardar, después de
sincronizar Delphin y dentro de la misma transacción. Los formatos de intercambio
y colaboración continúan materializando documentos completos.
Las firmas de comparación de proyectos nativos excluyen únicamente esas cachés
regenerables; conservan avisos propios y campos editables. Así una reapertura no
crea cambios pendientes ficticios ni bloquea al lector por avisos actualizados.
Los cuerpos de operaciones de nube ya enviados no se modifican.

Si las extensiones se reducen al menos 256 KiB, el mantenimiento posterior al
guardado permite recuperar páginas libres desde 256 KiB y 1 % del archivo.
Fuera de ese caso se conservan los umbrales anteriores. No se compacta en cada
guardado; un bloqueo de mantenimiento no invalida un guardado ya confirmado.

## Aplicación manual

1. Cierre MYG y Delphin. Respalde el código local y el SQLite antes de abrirlo
   con la actualización; no sustituya ni borre su base de datos.
2. Extraiga el ZIP sobre la raíz de `MYG.Presupuestos_GITHUB`, conservando las
   rutas. Compare antes los archivos si tiene modificaciones locales o posteriores
   al commit base. El ZIP contiene archivos completos para reemplazar o crear.
3. Compile en Windows con .NET 10. Para compilar la solución con Revit instalado:

   ```powershell
   dotnet restore MYG.Presupuestos.sln
   dotnet build MYG.Presupuestos.sln -c Release
   ```

   Para compilar sin la instalación de Revit, el proyecto admite referencias NuGet:

   ```powershell
   dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2
   ```

4. Abra una copia de su base, revise el cronograma y pulse Guardar. Cierre y
   vuelva a abrir esa copia tanto en MYG como en Delphin. Compare predecesoras,
   fechas, duraciones, calendario, notas y líneas base.

## Comprobaciones reproducibles

Desde la raíz del repositorio:

```text
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release -- --almacenamiento-delphin
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release
```

Opcionalmente defina `MYG_QA_ALMACENAMIENTO_SQLITE` con una muestra local antes
del primer comando. La prueba trabaja en una copia temporal y comprueba que el
SHA-256 del original no cambie; no publica ni incluye esa muestra en la entrega.
El resumen de esa prueba informa tamaños de JSON y archivo, integridad, cálculo
del cronograma y estabilidad tras dos guardados.

Validación de esta entrega: compilación completa con 0 errores y 0 advertencias;
15 comprobaciones de almacenamiento aprobadas, incluida una copia de la muestra
aportada. En esa copia, las extensiones bajaron de 889.499 a 128.246 bytes
(85,6 %) y el SQLite de 23.429.120 a 22.087.680 bytes (5,7 %). Se conservaron los
datos editables, los resultados del cronograma y las 6.312 dependencias nativas;
el segundo guardado no produjo crecimiento acumulativo. `integrity_check=ok` y
el SHA-256 de la muestra original permaneció intacto. El ahorro depende de los
datos de cada base; no implica que toda la base estuviera duplicada.
La suite general terminó con 746 comprobaciones aprobadas. La suite de nube
terminó con 40 grupos y 982 comprobaciones de contrato HTTP, además de sus
verificaciones internas de SQLite, paquetes y recuperación; usa HTTP simulado.

## Compatibilidad

Después de guardar extensiones versión 2, use esta versión de MYG o una posterior.
Las versiones antiguas de MYG que sólo entienden extensiones versión 1 rechazan
ese documento: para volver a ellas restaure el respaldo completo del SQLite.
No intente cambiar manualmente el número de versión. Las tablas nativas que usa
Delphin conservan su esquema y no necesitan otro SQL de migración.

En Linux se compila la interfaz y el conector; ejecutarlos, probar los formularios
y validar el Gantt real de Delphin/Revit requiere Windows. La prueba con el SQLite
no equivale a ejecutar Delphin.

## GitHub

El ZIP se entrega en el repositorio independiente `bimchimbote-droid/DESCARGAS`.
No incluye bases privadas ni modifica la rama del repositorio del código.
Después de aplicar y comprobar los archivos, revise Cambios de Git en Visual
Studio, confirme los archivos de esta entrega, haga Commit y luego Push a su
rama de trabajo. Verifique el commit resultante en GitHub.
