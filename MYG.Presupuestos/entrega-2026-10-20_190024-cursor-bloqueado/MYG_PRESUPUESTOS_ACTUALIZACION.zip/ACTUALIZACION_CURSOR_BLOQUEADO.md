# Puntero de bloqueo — MYG Presupuestos

Esta actualización complementa la entrega de módulos en gris del 20/10/2026,
que ya debe estar aplicada. Añade el puntero estándar de Windows de prohibido
(`Cursors.No`) sobre el contenido de cada módulo mientras esté bloqueado.
Al recuperar el permiso vuelve el puntero normal.

## Comportamiento

- ACU bloqueado: puntero de prohibido en su tabla y campos de edición.
- Especificaciones bloqueadas: puntero de prohibido en el documento y las reglas.
- Metrados Excel bloqueados: puntero de prohibido en hoja, fórmula y celda total.
- Un lector global también ve ese puntero en estructura y pie del presupuesto.
- Los módulos editables y las opciones disponibles de copiar, zoom y consulta
  conservan sus cursores. El contenido sigue permitiendo selección y consulta.
- El cursor de bloqueo se mantiene al mover el ratón, cambiar tema, salir y
  volver al control o recrear su ventana. Las barras de desplazamiento conservan
  su funcionamiento normal.

Excel y RichEdit eligen cursores propios. Por eso se actualizan sus manejadores
y el mensaje nativo de cursor, limitando este último al área cliente del control
bloqueado. No se consumen clics ni mensajes de selección, copia o desplazamiento.

## Archivos que contiene este ZIP

Todos los archivos REEMPLAZAR se entregan completos. Las rutas parten de
`D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.

| N.º | Ruta | Acción | Función |
|---|---|---|---|
| 1 | `MYG.Desktop/EstadoSoloLecturaNube.cs` | REEMPLAZAR | Cursor de bloqueo para tablas y campos; restauración al recuperar permisos. |
| 2 | `MYG.Desktop/PermisosVisualesEspecificaciones.cs` | REEMPLAZAR | Aplica el bloqueo de cursor a las reglas del documento. |
| 3 | `MYG.Desktop/EspecificacionesVistaOscura.cs` | REEMPLAZAR | Evita el cursor nativo de edición sobre el documento bloqueado. |
| 4 | `MYG.Desktop/EspecificacionesSuperficie.cs` | REEMPLAZAR | Mantiene el cursor de bloqueo en reglas y márgenes. |
| 5 | `MYG.Desktop/PresupuestosExcelSeleccion.cs` | REEMPLAZAR | Evita cruces, cursores de edición y arrastre mientras Excel esté bloqueado. |
| 6 | `MYG.PruebasUI/PermisosModulosUICheck.cs` | REEMPLAZAR | Prueba cursores, restauración y permisos independientes. |
| 7 | `ACTUALIZACION_CURSOR_BLOQUEADO.md` | CREAR | Estas instrucciones. |

Se incluyen sólo los archivos que cambian respecto de la entrega gris anterior.
Conserve los demás archivos ya instalados, las migraciones SQL y las vinculaciones.
No hay archivos que eliminar.

## Instalación

1. Cierre MYG. Respalde o confirme sus modificaciones locales.
2. Extraiga el ZIP en una carpeta temporal.
3. Copie su contenido a `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, combinando
   `MYG.Desktop` y `MYG.PruebasUI` con las carpetas existentes. Reemplace únicamente
   los archivos de la tabla. El documento `.md` queda junto a la solución.
4. Abra `MYG.Presupuestos.sln` en Visual Studio compatible con .NET 10.
   Restaure NuGet y compile en Release. Ejecute el programa recién compilado.
   Copiar estos archivos no actualiza por sí solo un ejecutable o instalador anterior.

Esta entrega no requiere SQL, dependencias nuevas ni referencias adicionales.
No modifica obras, usuarios ni datos reales de Supabase.

## Compilación y validación

C#, .NET SDK 10.0.100, WinForms/WPF. Código base `main` de
`bimchimbote-droid/MYG.Presupuestos`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`, más la entrega gris publicada en
`DESCARGAS` con commit `8cc453baeedd4af65dd23db1caedaca8627108ef`.
Trabajo preparado en rama local `work`.

Desde la carpeta del proyecto:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore -- --permisos-modulos
```

Validación en Linux del 20/10/2026: solución completa y pruebas UI compiladas
con 0 errores y 0 advertencias; `git diff --check` aprobado. Las pruebas UI se
compilaron, pero no se ejecutaron: requieren Windows con escritorio y WinForms.
Esta mejora modifica únicamente la interfaz y sus pruebas, sin cambios en el
motor de datos, contratos HTTP, SQLite ni integración de Revit.

Las pruebas ampliadas comprueban el cursor de prohibido, su conservación ante
intentos de reemplazarlo, restauración al recuperar permisos, independencia de
los módulos y mantenimiento de copiar/zoom. La prueba no mueve el ratón del usuario.

Comprobación manual en Windows:

1. Bloquee sólo ACU y pase el ratón sobre su tabla: debe aparecer prohibido.
   Especificaciones y Excel deben conservar sus punteros habituales.
2. Repita con Especificaciones (texto y reglas) y Excel (celdas, cabeceras,
   fórmula y total). Mueva el ratón, salga y vuelva a entrar.
3. Compruebe selección, copiar, zoom y desplazamiento. Cambie el tema y el DPI
   de Windows mientras el módulo esté bloqueado.
4. Restituya un permiso mientras otros módulos continúan bloqueados:
   sólo ese módulo recupera su cursor y edición normales.
5. Compruebe un usuario lector global y después una cuenta con edición.

## GitHub y precauciones

En Visual Studio, abra Cambios de Git, revise el diff, compruebe la rama `main`,
cree el Commit y pulse Push. Verifique los cambios en la rama de GitHub.
La publicación de esta entrega sube sólo su ZIP a una ruta nueva de `DESCARGAS`;
no publica automáticamente cambios del repositorio del código.

Si personalizó alguno de los archivos después de la entrega anterior, compare
y combine esas modificaciones antes de reemplazar el archivo completo.
Queda comprobar los punteros en Windows y, si utiliza el complemento, en Revit.
