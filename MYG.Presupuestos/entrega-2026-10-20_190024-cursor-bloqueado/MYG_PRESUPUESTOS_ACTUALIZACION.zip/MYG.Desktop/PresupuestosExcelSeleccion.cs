using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private int anclaEncabezadoColumnaHoja = -1, anclaEncabezadoFilaHoja = -1;
    private MYGCursoresMetrado cursoresHoja;
    private RangoArrastreHoja? seleccionCursorHoja, origenArrastreHoja, destinoArrastreHoja;
    private MYGHojaMetrado libroArrastreHoja;
    private Point anclaArrastreHoja, inicioArrastreHoja;
    private bool rellenandoArrastreHoja, desplazadoArrastreHoja;

    private readonly record struct RangoArrastreHoja(int F1, int C1, int F2, int C2)
    {
        internal string Direccion => DireccionCelda(F1, C1) + ":" + DireccionCelda(F2, C2);
    }

    private void PrepararCursoresHoja()
    {
        cursoresHoja = new(hoja, ElegirCursorHoja, ProcesarRatonArrastreHoja);
        hoja.SelectionChanged += (_, _) => { ActualizarSeleccionCursorHoja(); hoja.Invalidate(); };
        hoja.Paint += PintarSeleccionArrastreHoja;
        hoja.EditingControlShowing += (_, e) => { e.Control.Cursor = EdicionMetradosExcelNubePermitida ? Cursors.IBeam : Cursors.No; hoja.Invalidate(); };
        hoja.CellEndEdit += (_, _) => { ActualizarSeleccionCursorHoja(); hoja.Invalidate(); };
        hoja.MouseCaptureChanged += (_, _) => { if (!hoja.Capture) CancelarArrastreHoja(); };
        hoja.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Escape && (origenArrastreHoja != null || arrastrandoEncabezadosHoja))
            { e.Handled = e.SuppressKeyPress = true; CancelarArrastreHoja(); }
        };
        paginaExcel.VisibleChanged += (_, _) => { if (!paginaExcel.Visible) CancelarArrastreHoja(); };
        hoja.DpiChangedAfterParent += (_, _) => CancelarArrastreHoja();
        relojSeleccionEncabezadosHoja = new() { Interval = 100 };
        relojSeleccionEncabezadosHoja.Tick += DesplazarSeleccionEncabezadosHoja;
        Disposed += (_, _) => { CancelarArrastreHoja(); relojSeleccionEncabezadosHoja.Dispose(); cursoresHoja.Dispose(); };
    }

    private void ActualizarSeleccionCursorHoja()
    {
        if (origenArrastreHoja != null) return;
        seleccionCursorHoja = null;
        if (cargando || !HayPartida || !EdicionMetradosExcelNubePermitida || hoja.ReadOnly || hoja.SelectedCells.Count == 0) return;
        var celdas = hoja.SelectedCells.Cast<DataGridViewCell>().ToArray();
        var r = new RangoArrastreHoja(celdas.Min(c => c.RowIndex), celdas.Min(c => c.ColumnIndex),
            celdas.Max(c => c.RowIndex), celdas.Max(c => c.ColumnIndex));
        if ((long)(r.F2 - r.F1 + 1) * (r.C2 - r.C1 + 1) != celdas.Length || celdas.Any(c => c.ReadOnly)) return;
        if (!RangoVisibleArrastreHoja(r)) return;
        foreach (string combinado in actual.Costos.Hoja.RangosCombinados)
        {
            var c = RangoHoja(combinado);
            if (r.F1 <= c.f2 && r.F2 >= c.f1 && r.C1 <= c.c2 && r.C2 >= c.c1) return;
        }
        seleccionCursorHoja = r;
    }

    private bool RangoVisibleArrastreHoja(RangoArrastreHoja r) =>
        r.F1 >= 0 && r.C1 >= 0 && r.F2 < hoja.RowCount && r.C2 < hoja.ColumnCount &&
        Enumerable.Range(r.F1, r.F2 - r.F1 + 1).All(f => hoja.Rows[f].Visible) &&
        Enumerable.Range(r.C1, r.C2 - r.C1 + 1).All(c => hoja.Columns[c].Visible);

    private Rectangle AreaCeldasHoja()
    {
        int izquierda = hoja.RowHeadersVisible ? hoja.RowHeadersWidth : 0, arriba = hoja.ColumnHeadersVisible ? hoja.ColumnHeadersHeight : 0;
        int derecha = hoja.ClientSize.Width - (hoja.Controls.OfType<VScrollBar>().Any(b => b.Visible) ? SystemInformation.VerticalScrollBarWidth : 0);
        int abajo = hoja.ClientSize.Height - (hoja.Controls.OfType<HScrollBar>().Any(b => b.Visible) ? SystemInformation.HorizontalScrollBarHeight : 0);
        return Rectangle.FromLTRB(izquierda + 1, arriba + 1, Math.Max(izquierda + 1, derecha - 1), Math.Max(arriba + 1, abajo - 1));
    }

    private Rectangle RectanguloRangoArrastreHoja(RangoArrastreHoja r)
    {
        var a = hoja.GetCellDisplayRectangle(r.C1, r.F1, false);
        var b = hoja.GetCellDisplayRectangle(r.C2, r.F2, false);
        return Rectangle.FromLTRB(a.Left, a.Top, b.Right, b.Bottom);
    }

    private Rectangle TiradorRellenoHoja()
    {
        if (seleccionCursorHoja is not { } r || hoja.IsCurrentCellInEditMode || editandoFormulaBarraHoja) return Rectangle.Empty;
        var rect = RectanguloRangoArrastreHoja(r);
        if (!AreaCeldasHoja().Contains(new Point(rect.Right - 1, rect.Bottom - 1))) return Rectangle.Empty;
        int tamano = Math.Max(6, (int)Math.Ceiling(7 * hoja.DeviceDpi / 96d));
        return new(rect.Right - 1 - tamano / 2, rect.Bottom - 1 - tamano / 2, tamano, tamano);
    }

    private bool BordeSeleccionArrastreHoja(Point punto)
    {
        if (seleccionCursorHoja is not { } r || hoja.IsCurrentCellInEditMode || editandoFormulaBarraHoja || !AreaCeldasHoja().Contains(punto)) return false;
        var rect = RectanguloRangoArrastreHoja(r);
        var interior = Rectangle.Inflate(rect, -Math.Max(2, (int)Math.Ceiling(3 * hoja.DeviceDpi / 96d)), -Math.Max(2, (int)Math.Ceiling(3 * hoja.DeviceDpi / 96d)));
        return rect.Contains(punto) && !interior.Contains(punto);
    }

    private Cursor ElegirCursorHoja(Point punto)
    {
        if (!hoja.Enabled || !hoja.ClientRectangle.Contains(punto)) return Cursors.Default;
        if (!EdicionMetradosExcelNubePermitida)
        {
            var zona = hoja.HitTest(punto.X, punto.Y).Type;
            return zona is DataGridViewHitTestType.HorizontalScrollBar or DataGridViewHitTestType.VerticalScrollBar
                ? Cursors.Default : Cursors.No;
        }
        if (editorElegirReferenciasHoja != null && referenciaRedimensionadaHoja != null) return Cursors.SizeNWSE;
        if (arrastrandoEncabezadosHoja) return columnasSeleccionEncabezadosHoja ? cursoresHoja.Columna : cursoresHoja.Fila;
        if (origenArrastreHoja != null) return destinoArrastreHoja == null ? Cursors.No : rellenandoArrastreHoja ? cursoresHoja.Relleno : cursoresHoja.Movimiento;
        var hit = hoja.HitTest(punto.X, punto.Y);
        int margen = Math.Max(3, (int)Math.Ceiling(4 * hoja.DeviceDpi / 96d));
        if (hit.Type == DataGridViewHitTestType.ColumnHeader && hit.ColumnIndex >= 0)
        {
            var rect = hoja.GetCellDisplayRectangle(hit.ColumnIndex, -1, false);
            bool Derecha(int c) => c >= 0 && hoja.Columns[c].Resizable != DataGridViewTriState.False;
            if (hoja.AllowUserToResizeColumns && ((Math.Abs(punto.X - rect.Right) <= margen && Derecha(hit.ColumnIndex)) ||
                (Math.Abs(punto.X - rect.Left) <= margen && Derecha(hit.ColumnIndex - 1)))) return Cursors.SizeWE;
            return cursoresHoja.Columna;
        }
        if (hit.Type == DataGridViewHitTestType.RowHeader && hit.RowIndex >= 0)
        {
            var rect = hoja.GetCellDisplayRectangle(-1, hit.RowIndex, false);
            bool Abajo(int f) => f >= 0 && hoja.Rows[f].Resizable != DataGridViewTriState.False;
            if (hoja.AllowUserToResizeRows && ((Math.Abs(punto.Y - rect.Bottom) <= margen && Abajo(hit.RowIndex)) ||
                (Math.Abs(punto.Y - rect.Top) <= margen && Abajo(hit.RowIndex - 1)))) return Cursors.SizeNS;
            return cursoresHoja.Fila;
        }
        if (hit.Type != DataGridViewHitTestType.Cell) return Cursors.Default;
        if (ReferenciaTiradorHoja(punto, EditorActivoElegirReferenciasHoja()) != null) return Cursors.SizeNWSE;
        if (hoja.IsCurrentCellInEditMode && hoja.CurrentCell is { } activa && activa.RowIndex == hit.RowIndex && activa.ColumnIndex == hit.ColumnIndex) return Cursors.IBeam;
        if (TiradorRellenoHoja().Contains(punto)) return cursoresHoja.Relleno;
        if (BordeSeleccionArrastreHoja(punto)) return cursoresHoja.Movimiento;
        return cursoresHoja.Seleccion;
    }

    private bool ProcesarRatonArrastreHoja(int mensaje, Point punto)
    {
        if ((origenArrastreHoja != null || arrastrandoEncabezadosHoja) && (mensaje is 0x0008 or 0x001f || mensaje == 0x0100 && punto.X == (int)Keys.Escape))
        { CancelarArrastreHoja(); return true; }
        if (ProcesarRatonSeleccionEncabezadosHoja(mensaje, punto)) return true;
        if (mensaje == 0x0204 && origenArrastreHoja == null)
        { Intentar(() => SeleccionarContextoHoja(punto)); return true; }
        if (mensaje == 0x0201 && origenArrastreHoja == null)
        {
            if (cargando || !HayPartida || seleccionCursorHoja is not { } r || hoja.IsCurrentCellInEditMode || editandoFormulaBarraHoja ||
                (ModifierKeys & (Keys.Control | Keys.Shift | Keys.Alt)) != 0) return false;
            bool rellenar = TiradorRellenoHoja().Contains(punto);
            if (!rellenar && !BordeSeleccionArrastreHoja(punto)) return false;
            Intentar(() =>
            {
                FinalizarEdicion();
                var hit = hoja.HitTest(punto.X, punto.Y);
                anclaArrastreHoja = new(Math.Clamp(hit.ColumnIndex, r.C1, r.C2), Math.Clamp(hit.RowIndex, r.F1, r.F2));
                inicioArrastreHoja = punto; desplazadoArrastreHoja = false;
                rellenandoArrastreHoja = rellenar; origenArrastreHoja = destinoArrastreHoja = r;
                libroArrastreHoja = actual.Costos.Hoja;
                hoja.Focus(); hoja.Capture = true; hoja.Invalidate();
            });
            return true;
        }
        if (origenArrastreHoja == null) return false;
        if (mensaje == 0x0200)
        {
            if (Math.Abs(punto.X - inicioArrastreHoja.X) >= SystemInformation.DragSize.Width / 2 ||
                Math.Abs(punto.Y - inicioArrastreHoja.Y) >= SystemInformation.DragSize.Height / 2) desplazadoArrastreHoja = true;
            ActualizarDestinoArrastreHoja(punto);
            hoja.Cursor = ElegirCursorHoja(punto); Cursor.Current = hoja.Cursor; hoja.Invalidate(); return true;
        }
        if (mensaje == 0x0202)
        {
            ActualizarDestinoArrastreHoja(punto);
            var origen = origenArrastreHoja.Value; var destino = destinoArrastreHoja;
            bool rellenar = rellenandoArrastreHoja, ejecutar = desplazadoArrastreHoja && destino != null && destino != origen && HayPartida && ReferenceEquals(libroArrastreHoja, actual.Costos.Hoja);
            CancelarArrastreHoja();
            if (ejecutar) Intentar(() => AplicarArrastreHoja(origen.Direccion, destino.Value.Direccion, rellenar));
            return true;
        }
        return false;
    }

    private void ActualizarDestinoArrastreHoja(Point punto)
    {
        destinoArrastreHoja = null;
        if (origenArrastreHoja is not { } r || !HayPartida || !ReferenceEquals(libroArrastreHoja, actual.Costos.Hoja) || !AreaCeldasHoja().Contains(punto)) return;
        var hit = hoja.HitTest(punto.X, punto.Y);
        if (hit.Type != DataGridViewHitTestType.Cell) return;
        RangoArrastreHoja destino;
        if (rellenandoArrastreHoja)
        {
            int df = hit.RowIndex < r.F1 ? r.F1 - hit.RowIndex : Math.Max(0, hit.RowIndex - r.F2);
            int dc = hit.ColumnIndex < r.C1 ? r.C1 - hit.ColumnIndex : Math.Max(0, hit.ColumnIndex - r.C2);
            destino = df >= dc ? new(Math.Min(r.F1, hit.RowIndex), r.C1, Math.Max(r.F2, hit.RowIndex), r.C2)
                : new(r.F1, Math.Min(r.C1, hit.ColumnIndex), r.F2, Math.Max(r.C2, hit.ColumnIndex));
        }
        else
        {
            int df = hit.RowIndex - anclaArrastreHoja.Y, dc = hit.ColumnIndex - anclaArrastreHoja.X;
            destino = new(r.F1 + df, r.C1 + dc, r.F2 + df, r.C2 + dc);
        }
        if (RangoVisibleArrastreHoja(destino)) destinoArrastreHoja = destino;
    }

    private void AplicarArrastreHoja(string origen, string destino, bool rellenar)
    {
        ExigirPermisoMetradosExcel();
        RequerirPartida(); FinalizarEdicion();
        var copia = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        if (rellenar) MYGEdicionHoja.RellenarRango(copia, origen, destino);
        else MYGEdicionHoja.MoverRango(copia, origen, destino.Split(':')[0]);
        ExigirPermisoMetradosExcel(); antes(); ConfirmarCambioHoja(copia);
        celdaTotal.Text = copia.CeldaTotal;
        RecalcularHoja();
        var r = RangoHoja(destino); bool previo = cargando; cargando = true;
        try
        {
            hoja.ClearSelection(); hoja.CurrentCell = hoja[r.c1, r.f1];
            for (int f = r.f1; f <= r.f2; f++) for (int c = r.c1; c <= r.c2; c++) hoja[c, f].Selected = true;
        }
        finally { cargando = previo; }
        ActualizarSeleccionCursorHoja(); ActualizarFormula(); hoja.Invalidate(); Cambiado();
    }

    private void CancelarArrastreHoja()
    {
        CancelarSeleccionEncabezadosHoja();
        origenArrastreHoja = destinoArrastreHoja = null; libroArrastreHoja = null;
        if (hoja.IsDisposed) return;
        if (hoja.Capture) hoja.Capture = false;
        hoja.Cursor = EdicionMetradosExcelNubePermitida ? Cursors.Default : Cursors.No;
        ActualizarSeleccionCursorHoja(); hoja.Invalidate();
    }

    private void PintarSeleccionArrastreHoja(object sender, PaintEventArgs e)
    {
        if (seleccionCursorHoja is not { } seleccion || hoja.IsCurrentCellInEditMode || editandoFormulaBarraHoja) return;
        var estado = e.Graphics.Save(); e.Graphics.SetClip(AreaCeldasHoja());
        try
        {
            using var borde = new Pen(!EdicionMetradosExcelNubePermitida ? MYGEstadoSoloLecturaNube.Texto
                : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(110, 183, 255) : Color.FromArgb(41, 110, 178), Math.Max(1, hoja.DeviceDpi / 96f));
            var rect = RectanguloRangoArrastreHoja(seleccion);
            e.Graphics.DrawRectangle(borde, rect.X, rect.Y, Math.Max(0, rect.Width - 1), Math.Max(0, rect.Height - 1));
            if (desplazadoArrastreHoja && destinoArrastreHoja is { } destino && destino != seleccion)
            {
                borde.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                var vista = RectanguloRangoArrastreHoja(destino);
                e.Graphics.DrawRectangle(borde, vista.X, vista.Y, Math.Max(0, vista.Width - 1), Math.Max(0, vista.Height - 1));
            }
            var tirador = TiradorRellenoHoja();
            if (!tirador.IsEmpty) { using var fondo = new SolidBrush(borde.Color); e.Graphics.FillRectangle(fondo, tirador); }
        }
        finally { e.Graphics.Restore(estado); }
    }

    private void SeleccionarEncabezadoHoja(int fila, int columna, bool control, bool ampliar)
    {
        if (!HayPartida || hoja.RowCount == 0 || hoja.ColumnCount == 0) return;
        if (fila >= hoja.RowCount || columna >= hoja.ColumnCount || fila < -1 || columna < -1) return;
        FinalizarEdicion();
        var conservar = control ? CapturarSeleccionEncabezadosHoja() : Array.Empty<Point>();
        if (fila == -1 && columna >= 0)
        {
            int ancla = ampliar && anclaEncabezadoColumnaHoja >= 0 ? anclaEncabezadoColumnaHoja : columna;
            if (!ampliar || anclaEncabezadoColumnaHoja < 0) anclaEncabezadoColumnaHoja = columna;
            SeleccionarIntervaloEncabezadosHoja(true, ancla, columna, conservar);
        }
        else if (columna == -1 && fila >= 0)
        {
            if (!hoja.Rows[fila].Visible) return;
            int ancla = ampliar && anclaEncabezadoFilaHoja >= 0 ? anclaEncabezadoFilaHoja : fila;
            if (!ampliar || anclaEncabezadoFilaHoja < 0) anclaEncabezadoFilaHoja = fila;
            SeleccionarIntervaloEncabezadosHoja(false, ancla, fila, conservar);
        }
        else if (fila == -1 && columna == -1) hoja.SelectAll();
        hoja.Focus();
    }
}
