using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace MYG_2027;

// Paleta de pantalla: nunca se escribe en las celdas del modelo ni en el RTF.
internal static class MYGEstadoSoloLecturaNube
{
    private static readonly ConditionalWeakTable<Control, CursorBloqueado> cursores = new();
    internal static Color Fondo => SystemInformation.HighContrast ? SystemColors.Control
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(53, 53, 53) : Color.FromArgb(236, 236, 236);
    internal static Color Texto => SystemInformation.HighContrast ? SystemColors.ControlText
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(185, 185, 185) : Color.FromArgb(100, 100, 100);
    internal static Color Seleccion => SystemInformation.HighContrast ? SystemColors.Highlight
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(76, 76, 76) : Color.FromArgb(211, 211, 211);
    internal static Color TextoSeleccion => SystemInformation.HighContrast ? SystemColors.HighlightText
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(240, 240, 240) : Color.FromArgb(65, 65, 65);
    internal static Color Borde => SystemInformation.HighContrast ? SystemColors.WindowFrame
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(85, 85, 85) : Color.FromArgb(203, 203, 203);

    internal static void Colorear(DataGridViewCellStyle estilo)
    {
        estilo.BackColor = Fondo;
        estilo.ForeColor = Texto;
        estilo.SelectionBackColor = Seleccion;
        estilo.SelectionForeColor = TextoSeleccion;
    }

    internal static void Aplicar(DataGridView tabla, bool bloqueada)
    {
        if (tabla is MYG2027_TablaPresupuesto presupuesto) presupuesto.SoloLecturaNube = bloqueada;
        AplicarCursor(tabla, bloqueada);
        tabla.BackgroundColor = bloqueada ? Fondo : MYG2027_TemaComercial.Superficie;
        tabla.GridColor = bloqueada ? Borde : MYG2027_TemaComercial.Borde;
        if (bloqueada)
        {
            Colorear(tabla.ColumnHeadersDefaultCellStyle);
            Colorear(tabla.RowHeadersDefaultCellStyle);
        }
        else
        {
            var cabecera = tabla.ColumnHeadersDefaultCellStyle;
            cabecera.BackColor = cabecera.SelectionBackColor = MYG2027_TemaComercial.CabeceraTabla;
            cabecera.ForeColor = cabecera.SelectionForeColor = MYG2027_TemaComercial.TextoCabeceraTabla;
            var filas = tabla.RowHeadersDefaultCellStyle;
            filas.BackColor = MYG2027_TemaComercial.AzulSuave;
            filas.ForeColor = MYG2027_TemaComercial.Texto;
            filas.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
            filas.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
        }
        tabla.Invalidate();
    }

    internal static void AplicarCursor(Control control, bool bloqueado)
    {
        if (control == null || control.IsDisposed) return;
        if (!cursores.TryGetValue(control, out var estado))
        {
            if (!bloqueado) return;
            estado = cursores.GetValue(control, c => new CursorBloqueado(c));
        }
        estado.Actualizar(bloqueado);
    }

    private sealed class CursorBloqueado : NativeWindow
    {
        private readonly Control control;
        private readonly Dictionary<ScrollBar, (Cursor Cursor, bool Personalizado)> cursoresBarras = new();
        private Cursor cursorNormal;
        private bool bloqueado;

        internal CursorBloqueado(Control control)
        {
            this.control = control;
            control.HandleCreated += CrearHandle;
            control.HandleDestroyed += DestruirHandle;
            control.CursorChanged += CambiarCursor;
            control.ControlAdded += AgregarControl;
            control.Disposed += Liberar;
            if (control.IsHandleCreated) AssignHandle(control.Handle);
        }

        internal void Actualizar(bool bloquear)
        {
            if (bloquear == bloqueado) return;
            if (bloquear)
            {
                // La hoja crea y libera sus cursores al cambiar el DPI. No
                // retener uno de esos handles; al volver, su selector dinámico
                // elegirá el cursor correspondiente a la posición del ratón.
                cursorNormal = control is DataGridView ? Cursors.Default : control.Cursor;
            }
            bloqueado = bloquear;
            if (bloquear)
                foreach (Control hijo in control.Controls) PrepararBarra(hijo);
            control.Cursor = bloquear ? Cursors.No : cursorNormal;
            if (!bloquear)
            {
                foreach (var par in cursoresBarras)
                    if (!par.Key.IsDisposed)
                    {
                        if (par.Value.Personalizado) par.Key.Cursor = par.Value.Cursor;
                        else par.Key.ResetCursor();
                    }
                cursoresBarras.Clear();
            }
        }

        private void CrearHandle(object sender, EventArgs e) => AssignHandle(control.Handle);
        private void DestruirHandle(object sender, EventArgs e) => ReleaseHandle();
        private void AgregarControl(object sender, ControlEventArgs e)
        {
            if (bloqueado) PrepararBarra(e.Control);
        }

        private void PrepararBarra(Control hijo)
        {
            // Las barras de DataGridView son controles hijos: sin un cursor
            // explícito heredarían No del padre aunque su HWND no se intercepte.
            if (hijo is not ScrollBar barra || barra.IsDisposed) return;
            if (!cursoresBarras.ContainsKey(barra))
                cursoresBarras.Add(barra, (barra.Cursor,
                    TypeDescriptor.GetProperties(barra)[nameof(Control.Cursor)]?.ShouldSerializeValue(barra) == true));
            barra.Cursor = Cursors.Default;
        }
        private void CambiarCursor(object sender, EventArgs e)
        {
            // Los controles de tabla también asignan cursores desde MouseMove,
            // MouseLeave y cambios de DPI. El permiso tiene prioridad mientras
            // dure el bloqueo, sin consumir los mensajes de selección o copia.
            if (bloqueado && control.Cursor != Cursors.No) control.Cursor = Cursors.No;
        }

        protected override void WndProc(ref Message mensaje)
        {
            // Sólo el contenido cliente de este control. Las barras nativas y
            // los mensajes de otros HWND conservan su comportamiento normal.
            if (bloqueado && mensaje.Msg == 0x0020 && mensaje.WParam == Handle &&
                (mensaje.LParam.ToInt64() & 0xffff) == 1)
            {
                // Al cambiar Cursor, WinForms también envía este mensaje al
                // padre cuando el ratón está sobre uno de sus hijos.
                var hijo = control.GetChildAtPoint(control.PointToClient(Cursor.Position), GetChildAtPointSkip.Invisible);
                Cursor.Current = hijo is ScrollBar ? Cursors.Default : Cursors.No;
                mensaje.Result = new IntPtr(1);
                return;
            }
            base.WndProc(ref mensaje);
        }

        private void Liberar(object sender, EventArgs e)
        {
            control.HandleCreated -= CrearHandle;
            control.HandleDestroyed -= DestruirHandle;
            control.CursorChanged -= CambiarCursor;
            control.ControlAdded -= AgregarControl;
            control.Disposed -= Liberar;
            ReleaseHandle();
            cursoresBarras.Clear();
            cursores.Remove(control);
        }
    }
}

internal sealed partial class MYGPanelPresupuesto
{
    private void AplicarAspectoPermisosNube()
    {
        MYGEstadoSoloLecturaNube.Aplicar(estructura, !EdicionNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(tablaPie, !EdicionNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(acu, !EdicionACUNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(hoja, !EdicionMetradosExcelNubePermitida);
        hoja.GridColor = ColorRejillaHoja;

        formula.SoloLecturaNube = !EdicionMetradosExcelNubePermitida;
        MYGEstadoSoloLecturaNube.AplicarCursor(formula, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarCursor(celdaTotal, !EdicionMetradosExcelNubePermitida);
        MYGEstadoSoloLecturaNube.AplicarCursor(fuente, !EdicionMetradosExcelNubePermitida);
        foreach (Control control in new Control[] { precioDirecto, rendimiento, jornada })
            MYGEstadoSoloLecturaNube.AplicarCursor(control, !EdicionACUNubePermitida);
        formula.AplicarTema();
        ActualizarColoresReferenciasHoja();
        celdaTotal.BackColor = EdicionMetradosExcelNubePermitida ? MYG2027_TemaComercial.Superficie : MYGEstadoSoloLecturaNube.Fondo;
        celdaTotal.ForeColor = EdicionMetradosExcelNubePermitida ? MYG2027_TemaComercial.Texto : MYGEstadoSoloLecturaNube.Texto;
        foreach (var boton in botonesFormulaHoja) boton.Enabled = EdicionMetradosExcelNubePermitida && HayPartida;

        AplicarTemaContextoACU();
        if (!EdicionACUNubePermitida)
        {
            totalPrecioACU.BackColor = MYGEstadoSoloLecturaNube.Fondo;
            totalPrecioACU.ForeColor = MYGEstadoSoloLecturaNube.Texto;
            if (barraRendimientoACU != null)
            {
                barraRendimientoACU.BackColor = MYGEstadoSoloLecturaNube.Fondo;
                foreach (Control grupo in barraRendimientoACU.Controls) grupo.BackColor = MYGEstadoSoloLecturaNube.Fondo;
            }
            foreach (Control control in new Control[] { porRendimientoACU, porAsignacionACU, unidadRendimientoACU })
            { control.BackColor = MYGEstadoSoloLecturaNube.Fondo; control.ForeColor = MYGEstadoSoloLecturaNube.Texto; }
        }
        foreach (var par in new[] { (herramientasEstructura, EdicionNubePermitida), (herramientasACU, EdicionACUNubePermitida) })
            if (par.Item1 != null)
            {
                par.Item1.BackColor = par.Item2 ? AzulClaro : MYGEstadoSoloLecturaNube.Fondo;
                par.Item1.ForeColor = par.Item2 ? MYG2027_TemaComercial.Texto : MYGEstadoSoloLecturaNube.Texto;
            }
    }
}
