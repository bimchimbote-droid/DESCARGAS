using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;

namespace MYG_2027;

// RichEdit mueve el cursor al recibir el botón derecho. El menú debe actuar
// sobre la selección existente; el botón izquierdo conserva su comportamiento.
internal sealed class MYGEspecificacionesCursorContextual : NativeWindow, IDisposable
{
    private readonly RichTextBox documento;
    internal MYGEspecificacionesCursorContextual(RichTextBox documento)
    {
        this.documento = documento;
        documento.HandleCreated += CrearHandle;
        documento.HandleDestroyed += DestruirHandle;
        if (documento.IsHandleCreated) AssignHandle(documento.Handle);
    }
    private void CrearHandle(object sender, EventArgs e) => AssignHandle(documento.Handle);
    private void DestruirHandle(object sender, EventArgs e) => ReleaseHandle();
    protected override void WndProc(ref Message mensaje)
    {
        const int WmRButtonDown = 0x0204, WmRButtonDblClk = 0x0206;
        if (mensaje.Msg is WmRButtonDown or WmRButtonDblClk)
        {
            mensaje.Result = IntPtr.Zero;
            return;
        }
        // WM_RBUTTONUP/WM_CONTEXTMENU siguen llegando al control y permiten
        // abrir el menú con ratón, Shift+F10 o la tecla de menú contextual.
        base.WndProc(ref mensaje);
    }
    public void Dispose()
    {
        documento.HandleCreated -= CrearHandle;
        documento.HandleDestroyed -= DestruirHandle;
        ReleaseHandle();
    }
}

// Intercepta la rueda antes de que RichEdit aplique su zoom nativo sólo al texto.
// Se vuelve a conectar si Windows recrea el handle del control.
internal sealed class MYGEspecificacionesRueda : NativeWindow, IDisposable
{
    private readonly Control control;
    private readonly Func<int, bool, Point, bool> mover;
    internal MYGEspecificacionesRueda(Control control, Func<int, bool, Point, bool> mover)
    {
        this.control = control;
        this.mover = mover;
        control.HandleCreated += CrearHandle;
        control.HandleDestroyed += DestruirHandle;
        if (control.IsHandleCreated) AssignHandle(control.Handle);
    }
    private void CrearHandle(object sender, EventArgs e) => AssignHandle(control.Handle);
    private void DestruirHandle(object sender, EventArgs e) => ReleaseHandle();
    protected override void WndProc(ref Message mensaje)
    {
        const int WM_MOUSEWHEEL = 0x020A, MK_CONTROL = 0x0008;
        if (mensaje.Msg == WM_MOUSEWHEEL)
        {
            long parametros = mensaje.WParam.ToInt64();
            int delta = unchecked((short)((parametros >> 16) & 0xffff));
            long posicion = mensaje.LParam.ToInt64();
            var punto = new Point(unchecked((short)(posicion & 0xffff)),
                unchecked((short)((posicion >> 16) & 0xffff)));
            if (mover(delta, (parametros & MK_CONTROL) != 0, punto))
            {
                mensaje.Result = IntPtr.Zero;
                return;
            }
        }
        base.WndProc(ref mensaje);
    }
    public void Dispose()
    {
        control.HandleCreated -= CrearHandle;
        control.HandleDestroyed -= DestruirHandle;
        ReleaseHandle();
    }
}

// RichEdit es una ventana nativa: el doble búfer del lienzo no evita sus
// repintados entre cambiar el rectángulo, el zoom y la posición de scroll.
internal sealed class MYGEspecificacionesRepintado : IDisposable
{
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessagePunto(IntPtr ventana, int mensaje, IntPtr wParam, ref Point punto);
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool RedrawWindow(IntPtr ventana, IntPtr rectangulo, IntPtr region, uint opciones);
    private readonly RichTextBox documento;
    private readonly IntPtr ventana;
    private readonly bool suspendido;
    private Point scroll;
    private readonly float factorAnterior;

    internal MYGEspecificacionesRepintado(RichTextBox documento)
    {
        this.documento = documento;
        factorAnterior = documento.ZoomFactor;
        suspendido = documento.IsHandleCreated && documento.Visible;
        if (!suspendido) return;
        ventana = documento.Handle;
        SendMessagePunto(ventana, 0x04DD, IntPtr.Zero, ref scroll); // EM_GETSCROLLPOS
        SendMessage(ventana, 0x000B, IntPtr.Zero, IntPtr.Zero); // WM_SETREDRAW
    }
    public void Dispose()
    {
        if (!suspendido || documento.IsDisposed || !documento.IsHandleCreated || documento.Handle != ventana) return;
        float proporcion = documento.ZoomFactor / factorAnterior;
        scroll = new Point((int)Math.Round(scroll.X * proporcion), (int)Math.Round(scroll.Y * proporcion));
        SendMessagePunto(ventana, 0x04DE, IntPtr.Zero, ref scroll); // EM_SETSCROLLPOS
        SendMessage(ventana, 0x000B, new IntPtr(1), IntPtr.Zero);
        // WM_SETREDRAW conserva píxeles mientras RichEdit cambia de tamaño y
        // reformatea las líneas. Invalidar sólo el texto deja copias de letras
        // anteriores y no limpia el papel que descubre el margen desplazado.
        // RedrawWindow con borrado reconstruye el fondo y sus ventanas hijas,
        // tal como requiere la reactivación de WM_SETREDRAW.
        Control superficie = documento.Parent;
        IntPtr destino = superficie != null && !superficie.IsDisposed && superficie.IsHandleCreated
            ? superficie.Handle : ventana;
        const uint RdwInvalidar = 0x0001, RdwBorrar = 0x0004, RdwHijos = 0x0080, RdwMarco = 0x0400;
        RedrawWindow(destino, IntPtr.Zero, IntPtr.Zero, RdwInvalidar | RdwBorrar | RdwHijos | RdwMarco);
    }
}

// Marcas superpuestas: nunca se añaden símbolos ni números al texto guardado.
internal sealed class MYGEspecificacionesMarcas : NativeWindow
{
    private readonly RichTextBox documento;
    private bool parrafos, numeros;
    internal bool MostrarParrafos { get => parrafos; set { parrafos = value; documento.Invalidate(); } }
    internal bool MostrarNumeros { get => numeros; set { numeros = value; documento.Parent?.Invalidate(); documento.Invalidate(); } }
    internal MYGEspecificacionesMarcas(RichTextBox documento)
    {
        this.documento = documento;
        documento.HandleCreated += (_, _) => AssignHandle(documento.Handle);
        documento.HandleDestroyed += (_, _) => ReleaseHandle();
        if (documento.IsHandleCreated) AssignHandle(documento.Handle);
    }
    protected override void WndProc(ref Message mensaje)
    {
        base.WndProc(ref mensaje);
        if (mensaje.Msg != 0x000F || (!parrafos && !numeros) || documento.IsDisposed) return;
        using var g = documento.CreateGraphics();
        using var fuente = new Font("Arial", Math.Max(6, 8 * documento.ZoomFactor));
        using var tinta = new SolidBrush(MYG2027_TemaComercial.Secundario);
        string texto = documento.Text;
        int desde = documento.GetCharIndexFromPosition(Point.Empty);
        int hasta = Math.Min(texto.Length, documento.GetCharIndexFromPosition(new(documento.ClientSize.Width - 1, documento.ClientSize.Height - 1)) + 1);
        int primeraLinea = documento.GetLineFromCharIndex(desde);
        int ultimaLinea = documento.GetLineFromCharIndex(hasta);
        if (numeros && documento.Parent != null)
        {
            using var margen = documento.Parent.CreateGraphics();
            using var fondo = new SolidBrush(documento.Parent.BackColor);
            int x = Math.Max(0, documento.Left - 32);
            margen.FillRectangle(fondo, x, documento.Top, 30, documento.Height);
            for (int linea = primeraLinea; linea <= ultimaLinea; linea++)
            {
                int indice = documento.GetFirstCharIndexFromLine(linea); if (indice < 0) break;
                Point p = documento.GetPositionFromCharIndex(indice);
                if (p.Y >= 0 && p.Y < documento.ClientSize.Height)
                    margen.DrawString((linea + 1).ToString(CultureInfo.InvariantCulture), fuente, tinta, x, documento.Top + p.Y);
            }
        }
        if (parrafos)
            for (int i = desde; i < hasta; i++)
                if (texto[i] is '\n' or '\t')
                {
                    Point p = documento.GetPositionFromCharIndex(i);
                    if (p.Y >= 0 && p.Y < documento.ClientSize.Height) g.DrawString(texto[i] == '\n' ? "¶" : "→", fuente, tinta, p.X, p.Y);
                }
    }
}

// La cabecera de la sección se actualiza al seleccionar otra partida.
internal sealed class MYGEspecificacionesCabecera : Panel
{
    private readonly Func<string> presupuesto, item, descripcion;
    private readonly Label titulo = new();
    private readonly Label etiquetaPresupuesto = new() { Text = "Presupuesto:" };
    private readonly Label nombrePresupuesto = new();
    private readonly Label numeroPartida = new();
    private readonly Label nombrePartida = new();
    private readonly Panel tiempoEjecucion;
    private readonly Label cantidadEjecucion, diasEjecucion;
    private readonly Button word, pdf;
    private readonly ToolTip ayuda = new();
    private readonly Font fuenteTitulo = new("Segoe UI", 14f, FontStyle.Bold);
    private readonly Font fuenteEtiqueta = new("Segoe UI", 9.5f, FontStyle.Regular);
    private readonly Font fuenteDatos = new("Segoe UI", 9f, FontStyle.Regular);
    private readonly Font fuenteItem = new("Segoe UI", 9.5f, FontStyle.Bold);
    private int dpiIconos;
    private bool inicializada;

    internal MYGEspecificacionesCabecera(Func<string> presupuesto, Func<string> item,
        Func<string> descripcion, Action exportarWord = null, Action imprimirPdf = null,
        string tituloSeccion = "Especificaciones técnicas", string nombreControl = "espec_cabecera",
        bool mostrarTiempoEjecucion = false)
    {
        this.presupuesto = presupuesto;
        this.item = item;
        this.descripcion = descripcion;
        Name = nombreControl;
        Dock = DockStyle.Top;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = MYG2027_TemaComercial.Superficie;
        titulo.Text = tituloSeccion;
        titulo.Font = fuenteTitulo;
        etiquetaPresupuesto.Font = fuenteEtiqueta;
        nombrePresupuesto.Font = fuenteDatos;
        numeroPartida.Font = fuenteItem;
        nombrePartida.Font = fuenteDatos;
        titulo.ForeColor = nombrePartida.ForeColor = MYG2027_TemaComercial.Texto;
        etiquetaPresupuesto.ForeColor = nombrePresupuesto.ForeColor = numeroPartida.ForeColor = MYG2027_TemaComercial.Secundario;
        titulo.Name = nombreControl + "_titulo";
        nombrePresupuesto.Name = nombreControl + "_presupuesto";
        numeroPartida.Name = nombreControl + "_item";
        nombrePartida.Name = nombreControl + "_partida";
        foreach (Label etiqueta in new[] { titulo, etiquetaPresupuesto, nombrePresupuesto, numeroPartida, nombrePartida })
        {
            etiqueta.BackColor = Color.Transparent;
            etiqueta.AutoEllipsis = true;
            etiqueta.TextAlign = ContentAlignment.MiddleLeft;
            etiqueta.Margin = Padding.Empty;
            Controls.Add(etiqueta);
        }
        if (mostrarTiempoEjecucion)
        {
            tiempoEjecucion = new Panel { Name = nombreControl + "_tiempo" };
            var leyenda = new Label { Text = "TIEMPO PROGRAMADO\npara ejecutar", Font = fuenteEtiqueta };
            cantidadEjecucion = new Label { Name = nombreControl + "_tiempo_cantidad", Font = fuenteDatos, Text = "—" };
            diasEjecucion = new Label { Name = nombreControl + "_tiempo_dias", Font = fuenteItem, Text = "—" };
            foreach (var etiqueta in new[] { leyenda, cantidadEjecucion, diasEjecucion })
            {
                etiqueta.TextAlign = ContentAlignment.MiddleCenter;
                etiqueta.AutoEllipsis = true;
                etiqueta.BackColor = Color.Transparent;
                tiempoEjecucion.Controls.Add(etiqueta);
            }
            tiempoEjecucion.Resize += (_, _) =>
            {
                int ancho = tiempoEjecucion.ClientSize.Width;
                leyenda.Bounds = new(0, 0, ancho, Escala(36));
                cantidadEjecucion.Bounds = new(Escala(4), Escala(36), Math.Max(1, ancho - Escala(8)), Escala(22));
                diasEjecucion.Bounds = new(Escala(4), Escala(60), Math.Max(1, ancho - Escala(8)), Escala(24));
            };
            tiempoEjecucion.Paint += (_, e) =>
            {
                using var borde = new Pen(MYG2027_TemaComercial.Borde);
                e.Graphics.DrawRectangle(borde, 0, 0, Math.Max(0, tiempoEjecucion.Width - 1), Math.Max(0, tiempoEjecucion.Height - 1));
            };
            ayuda.SetToolTip(diasEjecucion, "Días calculados: metrado de la partida ÷ rendimiento diario.");
            Controls.Add(tiempoEjecucion);
        }
        if (exportarWord != null)
        {
            word = Exportacion("espec_exportar_word", "Exportar a Microsoft Word", exportarWord);
            Controls.Add(word);
        }
        if (imprimirPdf != null)
        {
            pdf = Exportacion("espec_exportar_pdf", "Imprimir o generar PDF", imprimirPdf);
            Controls.Add(pdf);
        }
        inicializada = true;
        Dimensionar();
        AplicarPaleta();
        Actualizar();
    }

    private Button Exportacion(string nombre, string texto, Action accion)
    {
        var boton = new MYG2027_BotonComercial
        {
            Name = nombre,
            AccessibleName = texto,
            AccessibleDescription = texto,
            FlatStyle = FlatStyle.Flat,
            BackColor = MYG2027_TemaComercial.Superficie,
            UseVisualStyleBackColor = false,
            Cursor = Cursors.Hand,
            ImageAlign = ContentAlignment.MiddleCenter,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            TabStop = true
        };
        MYG2027_TemaComercial.EstilizarBoton(boton);
        MYGAnimacionUI.PrepararBoton(boton);
        boton.Click += (_, _) => accion();
        ayuda.SetToolTip(boton, texto);
        return boton;
    }

    internal void Actualizar()
    {
        nombrePresupuesto.Text = presupuesto() ?? "";
        numeroPartida.Text = item() ?? "";
        nombrePartida.Text = descripcion() ?? "";
        ayuda.SetToolTip(nombrePresupuesto, nombrePresupuesto.Text);
        ayuda.SetToolTip(nombrePartida, nombrePartida.Text);
    }

    internal void ActualizarTiempoEjecucion(string cantidad, string dias)
    {
        if (tiempoEjecucion == null) return;
        cantidadEjecucion.Text = cantidad;
        diasEjecucion.Text = dias;
        ayuda.SetToolTip(cantidadEjecucion, cantidad);
    }

    internal void AplicarPaleta()
    {
        BackColor = MYG2027_TemaComercial.Superficie;
        titulo.ForeColor = nombrePartida.ForeColor = MYG2027_TemaComercial.Texto;
        etiquetaPresupuesto.ForeColor = nombrePresupuesto.ForeColor = numeroPartida.ForeColor =
            MYG2027_TemaComercial.Secundario;
        foreach (Label etiqueta in new[] { titulo, etiquetaPresupuesto, nombrePresupuesto, numeroPartida, nombrePartida }) etiqueta.BackColor = Color.Transparent;
        foreach (Button boton in new[] { word, pdf })
        {
            if (boton != null) MYG2027_TemaComercial.EstilizarBoton(boton);
        }
        if (tiempoEjecucion != null)
        {
            tiempoEjecucion.BackColor = MYG2027_TemaComercial.SuperficieAlterna;
            foreach (Control etiqueta in tiempoEjecucion.Controls) etiqueta.ForeColor = MYG2027_TemaComercial.Texto;
            tiempoEjecucion.Invalidate();
        }
        ActualizarIconos();
        Invalidate();
    }

    private int Escala(int valor) => (int)Math.Round(valor * DeviceDpi / 96f);

    private void Dimensionar()
    {
        bool tiempoDebajo = tiempoEjecucion != null && ClientSize.Width < Escala(700);
        Height = Escala(tiempoDebajo ? 193 : 103);
        int cantidadBotones = (word != null ? 1 : 0) + (pdf != null ? 1 : 0);
        int reservaBotones = cantidadBotones > 0 ? 15 + 48 * cantidadBotones : 0;
        int derecha = Math.Max(Escala(145), ClientSize.Width - Escala(reservaBotones));
        if (tiempoEjecucion != null)
        {
            tiempoEjecucion.Bounds = tiempoDebajo
                ? new(Escala(16), Escala(99), Math.Max(Escala(40), ClientSize.Width - Escala(32)), Escala(86))
                : new(ClientSize.Width - Escala(216), Escala(6), Escala(200), Escala(91));
            if (!tiempoDebajo) derecha = tiempoEjecucion.Left - Escala(8);
        }
        titulo.Bounds = new(Escala(16), Escala(10), Math.Max(Escala(40), derecha - Escala(22)), Escala(27));
        etiquetaPresupuesto.Bounds = new(Escala(16), Escala(44), Escala(109), Escala(20));
        nombrePresupuesto.Bounds = new(Escala(132), Escala(44), Math.Max(Escala(30), derecha - Escala(138)), Escala(20));
        numeroPartida.Bounds = new(Escala(16), Escala(65), Escala(109), Escala(20));
        nombrePartida.Bounds = new(Escala(132), Escala(65), Math.Max(Escala(30), derecha - Escala(138)), Escala(20));
        if (word != null)
            word.Bounds = new(ClientSize.Width - Escala(pdf != null ? 108 : 60), Escala(17), Escala(40), Escala(40));
        if (pdf != null)
            pdf.Bounds = new(ClientSize.Width - Escala(60), Escala(17), Escala(40), Escala(40));
        if (dpiIconos != DeviceDpi) ActualizarIconos();
    }

    private void ActualizarIconos()
    {
        dpiIconos = DeviceDpi;
        if (word != null)
        {
            Image anteriorWord = word.Image;
            word.Image = MYGEspecificacionesCinta.DibujarIcono("word", Escala(28));
            anteriorWord?.Dispose();
        }
        if (pdf != null)
        {
            Image anteriorPdf = pdf.Image;
            pdf.Image = MYGEspecificacionesCinta.DibujarIcono("pdf", Escala(28));
            anteriorPdf?.Dispose();
        }
    }

    protected override void OnSizeChanged(EventArgs e)
    {
        base.OnSizeChanged(e);
        if (inicializada) Dimensionar();
    }

    protected override void OnDpiChangedAfterParent(EventArgs e)
    {
        base.OnDpiChangedAfterParent(e);
        Dimensionar();
        Invalidate();
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        if (ClientSize.Width <= 0 || ClientSize.Height <= 0) return;
        base.OnPaintBackground(e);
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        e.Graphics.DrawLine(borde, 0, Height - 1, Width, Height - 1);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            ayuda.Dispose();
            word?.Image?.Dispose();
            pdf?.Image?.Dispose();
            fuenteTitulo.Dispose();
            fuenteEtiqueta.Dispose();
            fuenteDatos.Dispose();
            fuenteItem.Dispose();
        }
        base.Dispose(disposing);
    }
}

// El papel sigue siendo un control independiente: el fondo y la sombra no alteran su RTF.
internal sealed class MYGEspecificacionesLienzo : Panel
{
    // Reutiliza el desplazamiento de WinForms, incluida la preferencia del sistema.
    internal bool DesplazarRueda(int delta)
    {
        Point anterior = AutoScrollPosition;
        base.OnMouseWheel(new HandledMouseEventArgs(MouseButtons.None, 0, 0, 0, delta));
        Invalidate();
        return anterior != AutoScrollPosition;
    }

    internal MYGEspecificacionesLienzo()
    {
        Name = "espec_lienzo";
        Dock = DockStyle.Fill;
        AutoScroll = true;
        BackColor = MYG2027_TemaComercial.Fondo;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        Scroll += (_, _) => Invalidate();
    }

    protected override void OnControlAdded(ControlEventArgs e)
    {
        base.OnControlAdded(e);
        e.Control.LocationChanged += PapelCambiado;
        e.Control.SizeChanged += PapelCambiado;
        e.Control.VisibleChanged += PapelCambiado;
        Invalidate();
    }

    protected override void OnControlRemoved(ControlEventArgs e)
    {
        e.Control.LocationChanged -= PapelCambiado;
        e.Control.SizeChanged -= PapelCambiado;
        e.Control.VisibleChanged -= PapelCambiado;
        base.OnControlRemoved(e);
        Invalidate();
    }

    private void PapelCambiado(object sender, EventArgs e) => Invalidate();

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        if (ClientSize.Width <= 0 || ClientSize.Height <= 0) return;
        base.OnPaintBackground(e);
        if (SystemInformation.HighContrast) return;
        float escala = DeviceDpi / 96f;
        int alcance = Math.Max(1, (int)Math.Round(5 * escala));
        int desplazamiento = (int)Math.Round(3 * escala);
        int opacidad = Math.Clamp((int)Math.Round(4 / escala), 1, 4);
        foreach (Control papel in Controls)
        {
            if (!papel.Visible || papel.BackColor != Color.White || papel.Width < 32 || papel.Height < 32) continue;
            for (int radio = alcance; radio > 0; radio--)
            {
                Rectangle sombra = papel.Bounds;
                sombra.Offset(0, desplazamiento);
                sombra.Inflate(radio, radio);
                using var pincel = new SolidBrush(Color.FromArgb(opacidad, MYG2027_TemaComercial.Texto));
                e.Graphics.FillRectangle(pincel, sombra);
            }
        }
    }
}

internal enum MYGEspecificacionesMargenRegla { Inicio, Fin }

internal sealed class MYGEspecificacionesMargenesEventArgs : EventArgs
{
    internal MYGEspecificacionesMargenRegla Margen { get; }
    internal float MargenInicioMm { get; }
    internal float MargenFinMm { get; }

    internal MYGEspecificacionesMargenesEventArgs(MYGEspecificacionesMargenRegla margen,
        float margenInicioMm, float margenFinMm)
    {
        Margen = margen;
        MargenInicioMm = margenInicioMm;
        MargenFinMm = margenFinMm;
    }
}

// Las medidas parten del inicio del texto. El arrastre se calcula desde el papel,
// cuya referencia permanece estable mientras cambia el margen de la página.
internal sealed class MYGEspecificacionesRegla : Control, IMessageFilter
{
    private readonly bool vertical;
    private float origenPapel, pxMm = 3.78f, longitudPaginaMm = 220f;
    private float margenInicioMm = 25f, margenFinMm = 25f, minimoTextoMm = 10f;
    private float margenInicioAnterior, margenFinAnterior, desplazamientoAgarre;
    private bool margenesConfigurados, arrastrando, soloLecturaNube, edicionHabilitada = true;
    private MYGEspecificacionesMargenRegla margenArrastrado;
    private readonly Font fuenteNumeros = new("Segoe UI", 7.5f);
    private readonly ToolTip ayuda = new();

    internal event EventHandler<MYGEspecificacionesMargenesEventArgs> ArrastreIniciado;
    internal event EventHandler<MYGEspecificacionesMargenesEventArgs> MargenesCambiados;
    internal event EventHandler<MYGEspecificacionesMargenesEventArgs> ArrastreFinalizado;
    internal event EventHandler<MYGEspecificacionesMargenesEventArgs> ArrastreCancelado;

    internal bool Arrastrando => arrastrando;
    [System.ComponentModel.Browsable(false)]
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool SoloLecturaNube
    {
        get => soloLecturaNube;
        set
        {
            if (soloLecturaNube == value) return;
            soloLecturaNube = value;
            if (value) CancelarArrastre();
            Cursor = CursorReposo;
        }
    }
    private Cursor CursorReposo => soloLecturaNube ? Cursors.No : Cursors.Default;

    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool EdicionHabilitada
    {
        get => edicionHabilitada;
        set
        {
            if (edicionHabilitada == value) return;
            edicionHabilitada = value;
            if (!value) CancelarArrastre();
            Cursor = CursorReposo;
            Invalidate();
        }
    }

    private float OrigenTexto => origenPapel + margenInicioMm * pxMm;

    internal MYGEspecificacionesRegla(bool vertical = false)
    {
        this.vertical = vertical;
        Name = vertical ? "espec_regla_vertical" : "espec_regla_horizontal";
        AccessibleName = vertical ? "Regla vertical en centímetros" : "Regla horizontal en centímetros";
        AccessibleDescription = vertical
            ? "Arrastra los marcadores para cambiar los márgenes superior e inferior. Escape cancela el cambio."
            : "Arrastra los marcadores para cambiar los márgenes izquierdo y derecho. Escape cancela el cambio.";
        BackColor = MYG2027_TemaComercial.Fondo;
        ForeColor = MYG2027_TemaComercial.Secundario;
        TabStop = false;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        // Capturar el ratón no debe quitar el foco ni cambiar la selección del editor.
        SetStyle(ControlStyles.Selectable, false);
        ayuda.SetToolTip(this, vertical
            ? "Arrastra los marcadores del margen superior o inferior"
            : "Arrastra los marcadores del margen izquierdo o derecho");
        if (vertical) { Dock = DockStyle.Left; Width = 29; }
        else { Dock = DockStyle.Top; Height = 33; }
    }

    // Compatibilidad con vistas antiguas: origen corresponde al texto y no al papel.
    // Sólo la configuración completa habilita la edición de márgenes.
    internal void Configurar(float origen, float pxMm, float anchoMm)
    {
        CancelarArrastre();
        this.pxMm = float.IsFinite(pxMm) ? Math.Max(.05f, pxMm) : 3.78f;
        origenPapel = (float.IsFinite(origen) ? origen : 0f) - 25f * this.pxMm;
        margenInicioMm = margenFinMm = 25f;
        longitudPaginaMm = (float.IsFinite(anchoMm) ? Math.Max(0f, anchoMm) : 170f) + 50f;
        margenesConfigurados = false;
        Invalidate();
    }

    internal void Configurar(float origenPapel, float pxMm, float longitudPaginaMm,
        float margenInicioMm, float margenFinMm, float minimoTextoMm = 10f)
    {
        this.origenPapel = float.IsFinite(origenPapel) ? origenPapel : 0f;
        this.pxMm = float.IsFinite(pxMm) ? Math.Max(.05f, pxMm) : 3.78f;
        this.longitudPaginaMm = float.IsFinite(longitudPaginaMm) ? Math.Max(1f, longitudPaginaMm) : 220f;
        this.minimoTextoMm = float.IsFinite(minimoTextoMm)
            ? Math.Clamp(minimoTextoMm, 1f, this.longitudPaginaMm) : Math.Min(10f, this.longitudPaginaMm);
        // Una página heredada puede tener menos del mínimo recomendado. No
        // cambiamos sus medidas al mostrarla; el cálculo del gesto conserva el
        // área previa cuando ya era menor que ese mínimo.
        float espacio = this.longitudPaginaMm - .01f;
        this.margenInicioMm = float.IsFinite(margenInicioMm) ? Math.Clamp(margenInicioMm, 0f, espacio) : 0f;
        this.margenFinMm = float.IsFinite(margenFinMm)
            ? Math.Clamp(margenFinMm, 0f, espacio - this.margenInicioMm) : 0f;
        margenesConfigurados = true;
        // El editor llama nuevamente durante la vista previa; no se reemplaza el
        // estado inicial, para que Escape también revierta todos esos movimientos.
        Invalidate();
    }

    internal void Desplazar(float origenPapel)
    {
        this.origenPapel = (float.IsFinite(origenPapel) ? origenPapel : 0f)
            - (margenesConfigurados ? 0f : margenInicioMm * pxMm);
        Invalidate();
    }

    private float PosicionMargen(MYGEspecificacionesMargenRegla margen) => origenPapel
        + (margen == MYGEspecificacionesMargenRegla.Inicio ? margenInicioMm : longitudPaginaMm - margenFinMm) * pxMm;

    private void Banda(float factor, out float inicio, out float ancho)
    {
        inicio = (vertical ? 5f : 6f) * factor;
        ancho = (vertical ? 12f : 17f) * factor;
    }

    private bool EncontrarMargen(Point punto, out MYGEspecificacionesMargenRegla margen)
    {
        margen = MYGEspecificacionesMargenRegla.Inicio;
        if (!margenesConfigurados || !edicionHabilitada || soloLecturaNube || !Enabled) return false;
        float factor = DeviceDpi / 96f;
        float eje = vertical ? punto.Y : punto.X, transversal = vertical ? punto.X : punto.Y;
        if (!vertical && eje <= 31f * factor) return false;
        Banda(factor, out float inicio, out float ancho);
        if (transversal < inicio - 4f * factor || transversal > inicio + ancho + 6f * factor) return false;
        float distanciaInicio = Math.Abs(eje - PosicionMargen(MYGEspecificacionesMargenRegla.Inicio));
        float distanciaFin = Math.Abs(eje - PosicionMargen(MYGEspecificacionesMargenRegla.Fin));
        margen = distanciaInicio <= distanciaFin ? MYGEspecificacionesMargenRegla.Inicio : MYGEspecificacionesMargenRegla.Fin;
        return Math.Min(distanciaInicio, distanciaFin) <= 7f * factor;
    }

    private MYGEspecificacionesMargenesEventArgs DatosArrastre() =>
        new(margenArrastrado, margenInicioMm, margenFinMm);

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || arrastrando || !EncontrarMargen(e.Location, out var margen)) return;
        margenArrastrado = margen;
        margenInicioAnterior = margenInicioMm;
        margenFinAnterior = margenFinMm;
        desplazamientoAgarre = (vertical ? e.Y : e.X) - PosicionMargen(margen);
        arrastrando = true;
        Application.AddMessageFilter(this);
        Capture = true;
        Cursor = vertical ? Cursors.SizeNS : Cursors.SizeWE;
        ArrastreIniciado?.Invoke(this, DatosArrastre());
        Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (!arrastrando)
        {
            Cursor = EncontrarMargen(e.Location, out _) ? (vertical ? Cursors.SizeNS : Cursors.SizeWE) : CursorReposo;
            return;
        }
        ActualizarArrastre(vertical ? e.Y : e.X);
    }

    private void ActualizarArrastre(float posicionRaton)
    {
        float desdeInicio = (float)Math.Round((posicionRaton - desplazamientoAgarre - origenPapel) / pxMm, 1);
        var margenes = MYGEspecificacionesMargenes.Arrastrar((decimal)longitudPaginaMm,
            (decimal)margenInicioAnterior, (decimal)margenFinAnterior, (decimal)desdeInicio,
            margenArrastrado == MYGEspecificacionesMargenRegla.Inicio, (decimal)minimoTextoMm);
        float nuevo = (float)(margenArrastrado == MYGEspecificacionesMargenRegla.Inicio ? margenes.InicioMm : margenes.FinMm);
        float anterior = margenArrastrado == MYGEspecificacionesMargenRegla.Inicio ? margenInicioMm : margenFinMm;
        if (Math.Abs(nuevo - anterior) < .001f) return;
        if (margenArrastrado == MYGEspecificacionesMargenRegla.Inicio) margenInicioMm = nuevo;
        else margenFinMm = nuevo;
        Invalidate();
        MargenesCambiados?.Invoke(this, DatosArrastre());
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button != MouseButtons.Left || !arrastrando) return;
        ActualizarArrastre(vertical ? e.Y : e.X);
        // Una devolución de la vista previa puede haber cancelado la operación.
        if (!arrastrando) return;
        TerminarCaptura();
        ArrastreFinalizado?.Invoke(this, DatosArrastre());
    }

    private void TerminarCaptura()
    {
        arrastrando = false;
        Application.RemoveMessageFilter(this);
        Capture = false;
        Cursor = CursorReposo;
        Invalidate();
    }

    internal void CancelarArrastre()
    {
        if (!arrastrando) return;
        margenInicioMm = margenInicioAnterior;
        margenFinMm = margenFinAnterior;
        TerminarCaptura();
        ArrastreCancelado?.Invoke(this, DatosArrastre());
    }

    bool IMessageFilter.PreFilterMessage(ref Message mensaje)
    {
        if (arrastrando && (mensaje.Msg is 0x0100 or 0x0104) && mensaje.WParam.ToInt64() == (int)Keys.Escape)
        {
            CancelarArrastre();
            return true;
        }
        return false;
    }

    protected override void WndProc(ref Message mensaje)
    {
        // También atiende mensajes enviados directamente al handle de la regla.
        // En uso normal el filtro conserva el foco y la selección del documento.
        if (((IMessageFilter)this).PreFilterMessage(ref mensaje))
        {
            mensaje.Result = IntPtr.Zero;
            return;
        }
        base.WndProc(ref mensaje);
    }

    protected override void OnMouseCaptureChanged(EventArgs e)
    {
        base.OnMouseCaptureChanged(e);
        if (!Capture) CancelarArrastre();
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        if (!arrastrando) Cursor = CursorReposo;
    }

    protected override void OnEnabledChanged(EventArgs e)
    {
        base.OnEnabledChanged(e);
        if (!Enabled) CancelarArrastre();
    }

    protected override void OnVisibleChanged(EventArgs e)
    {
        base.OnVisibleChanged(e);
        if (!Visible) CancelarArrastre();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (ClientSize.Width <= 0 || ClientSize.Height <= 0) return;
        float factor = DeviceDpi / 96f;
        using var tinta = new SolidBrush(ForeColor);
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        using var rayas = new Pen(ForeColor);
        using var fondoRegla = new SolidBrush(MYG2027_TemaComercial.SuperficieAlterna);
        using var bordeMarcador = new Pen(SystemInformation.HighContrast ? MYG2027_TemaComercial.Texto : ForeColor);
        using var fondoMarcador = new SolidBrush(MYG2027_TemaComercial.Superficie);
        using var bordeActivo = new Pen(MYG2027_TemaComercial.Azul);
        using var fondoActivo = new SolidBrush(MYG2027_TemaComercial.AzulSuave);
        bool inicioActivo = arrastrando && margenArrastrado == MYGEspecificacionesMargenRegla.Inicio;
        bool finActivo = arrastrando && margenArrastrado == MYGEspecificacionesMargenRegla.Fin;
        if (vertical)
        {
            Banda(factor, out float inicioBanda, out float anchoBanda);
            int izquierda = (int)Math.Round(inicioBanda), ancho = (int)Math.Round(anchoBanda);
            e.Graphics.FillRectangle(fondoRegla, izquierda, 0, ancho, Height);
            e.Graphics.DrawRectangle(borde, izquierda, -1, ancho, Height);
            DibujarMarcas(e.Graphics, rayas, tinta, factor, izquierda + ancho - 1, Height, true);
            DibujarMargen(e.Graphics, PosicionMargen(MYGEspecificacionesMargenRegla.Inicio), izquierda, ancho, factor,
                inicioActivo ? bordeActivo : bordeMarcador, inicioActivo ? fondoActivo : fondoMarcador, false);
            DibujarMargen(e.Graphics, PosicionMargen(MYGEspecificacionesMargenRegla.Fin), izquierda, ancho, factor,
                finActivo ? bordeActivo : bordeMarcador, finActivo ? fondoActivo : fondoMarcador, true);
        }
        else
        {
            int esquina = (int)Math.Round(29 * factor), arriba = (int)Math.Round(6 * factor), alto = (int)Math.Round(17 * factor);
            int desde = Math.Max(esquina + 2, (int)Math.Round(origenPapel));
            int hasta = Math.Min(Width - 3, (int)Math.Round(origenPapel + longitudPaginaMm * pxMm));
            if (hasta > desde)
            {
                e.Graphics.FillRectangle(fondoRegla, desde, arriba, hasta - desde, alto);
                e.Graphics.DrawRectangle(borde, desde, arriba, hasta - desde, alto);
                var guardado = e.Graphics.Save();
                e.Graphics.SetClip(new Rectangle(desde + 1, arriba + 1, hasta - desde - 1, alto - 1));
                DibujarMarcas(e.Graphics, rayas, tinta, factor, arriba + alto - 1, Width, false);
                e.Graphics.Restore(guardado);
                DibujarMargen(e.Graphics, PosicionMargen(MYGEspecificacionesMargenRegla.Inicio), arriba, alto, factor,
                    inicioActivo ? bordeActivo : bordeMarcador, inicioActivo ? fondoActivo : fondoMarcador, false);
                DibujarMargen(e.Graphics, PosicionMargen(MYGEspecificacionesMargenRegla.Fin), arriba, alto, factor,
                    finActivo ? bordeActivo : bordeMarcador, finActivo ? fondoActivo : fondoMarcador, true);
            }
            e.Graphics.DrawLine(borde, esquina, 0, esquina, Height);
            e.Graphics.FillRectangle(fondoRegla, 5 * factor, 5 * factor, 18 * factor, 18 * factor);
            e.Graphics.DrawRectangle(borde, 5 * factor, 5 * factor, 18 * factor, 18 * factor);
            using var tabulacion = new Pen(ForeColor, 2 * factor);
            e.Graphics.DrawLines(tabulacion, new[] { new PointF(11 * factor, 10 * factor), new PointF(11 * factor, 17 * factor), new PointF(17 * factor, 17 * factor) });
        }
    }

    private void DibujarMarcas(Graphics g, Pen rayas, Brush tinta, float factor, float borde,
        int longitud, bool esVertical)
    {
        float origen = OrigenTexto;
        int primero = (int)Math.Floor(-origen / pxMm) - 1;
        int ultimo = (int)Math.Ceiling((longitud - origen) / pxMm) + 1;
        for (int mm = primero; mm <= ultimo; mm++)
        {
            float posicion = origen + mm * pxMm;
            float largo = (mm % 10 == 0 ? 7f : mm % 5 == 0 ? 5f : 3f) * factor;
            if (esVertical) g.DrawLine(rayas, borde - largo, posicion, borde, posicion);
            else g.DrawLine(rayas, posicion, borde - largo, posicion, borde);
            if (mm == 0 || mm % 10 != 0) continue;
            string numero = Math.Abs(mm / 10).ToString(CultureInfo.InvariantCulture);
            if (esVertical)
            {
                var guardado = g.Save();
                g.TranslateTransform(7 * factor, posicion - 1 * factor);
                g.RotateTransform(-90);
                g.DrawString(numero, fuenteNumeros, tinta, 0, 0);
                g.Restore(guardado);
            }
            else g.DrawString(numero, fuenteNumeros, tinta, posicion + 2 * factor, 5 * factor);
        }
    }

    private void DibujarMargen(Graphics g, float x, int arriba, int alto, float factor,
        Pen borde, Brush fondo, bool derecha)
    {
        SmoothingMode anterior = g.SmoothingMode;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        float mitad = 4 * factor;
        PointF Punto(float eje, float transversal) => vertical ? new(transversal, eje) : new(eje, transversal);
        if (!derecha)
        {
            PointF[] primeraLinea = { Punto(x - mitad, arriba - 2 * factor), Punto(x + mitad, arriba - 2 * factor), Punto(x, arriba + 3 * factor) };
            g.FillPolygon(fondo, primeraLinea);
            g.DrawPolygon(borde, primeraLinea);
        }
        PointF[] sangria = { Punto(x - mitad, arriba + alto - 2 * factor), Punto(x + mitad, arriba + alto - 2 * factor), Punto(x, arriba + alto - 7 * factor) };
        g.FillPolygon(fondo, sangria);
        g.DrawPolygon(borde, sangria);
        if (!derecha)
        {
            RectangleF baseMarcador = vertical
                ? new(arriba + alto - 1 * factor, x - mitad, 5 * factor, mitad * 2)
                : new(x - mitad, arriba + alto - 1 * factor, mitad * 2, 5 * factor);
            g.FillRectangle(fondo, baseMarcador);
            g.DrawRectangle(borde, baseMarcador.X, baseMarcador.Y, baseMarcador.Width, baseMarcador.Height);
        }
        g.SmoothingMode = anterior;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            CancelarArrastre();
            ayuda.Dispose();
            fuenteNumeros.Dispose();
        }
        base.Dispose(disposing);
    }
}
