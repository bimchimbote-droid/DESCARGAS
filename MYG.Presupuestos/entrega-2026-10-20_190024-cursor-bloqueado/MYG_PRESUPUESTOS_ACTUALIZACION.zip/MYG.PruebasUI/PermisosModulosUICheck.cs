using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG_2027;

internal static class PermisosModulosUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Permisos por módulo", "Presupuesto");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), IdLocalMYG = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Partida de prueba", Unidad = "m3", Posicion = 1
        };
        partida.Costos.EspecificacionTexto = "Contenido visible de la especificación";
        partida.Costos.Hoja.Poner("A3", "Contenido visible de la hoja");
        presupuesto.Items.Add(partida);
        int cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => cambios++, () => { }, _ => { },
            () => System.Threading.Tasks.Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var ventana = new Form { ClientSize = new Size(1300, 850) };
        ventana.Controls.Add(panel); ventana.Show(); panel.Refrescar(); panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        var permisos = new MYGPermisosModulos();
        bool edicionGlobal = true;
        panel.ConfigurarPermisoNube(() => edicionGlobal, () => permisos);
        var acu = Campo<DataGridView>(panel, "acu");
        var hoja = Campo<DataGridView>(panel, "hoja");
        var especificacion = Campo<RichTextBox>(panel, "especificacion");
        var formula = Campo<TextBoxBase>(panel, "formula");
        var celdaTotal = Campo<TextBox>(panel, "celdaTotal");
        var estructura = Campo<DataGridView>(panel, "estructura");
        var tablaPie = Campo<DataGridView>(panel, "tablaPie");
        var editor = Campo<MYGEspecificacionesEditor>(panel, "editorEspecificaciones");
        var zoom = Campo<NumericUpDown>(editor, "zoom");
        var copiar = Elemento(editor, "Copiar");
        var pestanas = Campo<TabControl>(panel, "detalle");
        int paginas = pestanas.TabPages.Count;
        Color acuEditable = acu.BackgroundColor, hojaEditable = hoja.BackgroundColor;
        Color estructuraEditable = estructura.BackgroundColor, pieEditable = tablaPie.BackgroundColor;
        Color especificacionEditable = especificacion.BackColor, formulaEditable = formula.BackColor;
        Cursor cursorAcu = acu.Cursor, cursorHoja = hoja.Cursor, cursorEspecificacion = especificacion.Cursor;
        Cursor cursorFormula = formula.Cursor, cursorTotal = celdaTotal.Cursor;
        Cursor cursorEstructura = estructura.Cursor, cursorPie = tablaPie.Cursor;
        Cursor cursorZoom = zoom.Cursor, cursorCopiar = copiar.Owner.Cursor;
        var barrasAcu = acu.Controls.OfType<ScrollBar>().Select(barra => (Barra: barra, Habilitada: barra.Enabled)).ToArray();
        var barrasHoja = hoja.Controls.OfType<ScrollBar>().Select(barra => (Barra: barra, Habilitada: barra.Enabled)).ToArray();
        string rtfSinBloqueo = especificacion.Rtf;

        permisos.Acu = false; panel.ActualizarPermisoNube();
        exige(acu.ReadOnly && !hoja.ReadOnly && !especificacion.ReadOnly,
            "Bloquear ACU conserva editables los otros módulos y mantiene visible el análisis.");
        Gris(acu.BackgroundColor, exige, "El fondo de ACU comunica visualmente el bloqueo.");
        exige((SystemInformation.HighContrast || acu.BackgroundColor != acuEditable) && acu.Enabled
            && hoja.BackgroundColor == hojaEditable && especificacion.BackColor == especificacionEditable,
            "Sólo ACU cambia de aspecto y su tabla permanece habilitada para consultar.");
        exige(acu.Cursor == Cursors.No && hoja.Cursor == cursorHoja && especificacion.Cursor == cursorEspecificacion
            && formula.Cursor == cursorFormula && celdaTotal.Cursor == cursorTotal
            && estructura.Cursor == cursorEstructura && tablaPie.Cursor == cursorPie,
            "El puntero de prohibido sólo identifica el contenido de ACU bloqueado.");
        foreach (var barra in barrasAcu)
            exige(barra.Barra.Cursor == Cursors.Default && barra.Barra.Enabled == barra.Habilitada,
                "Las barras de desplazamiento de ACU conservan su habilitación y no heredan el puntero de prohibido.");
        exige(!Campo<NumericUpDown>(panel, "rendimiento").Enabled && !Campo<NumericUpDown>(panel, "jornada").Enabled,
            "Rendimiento y jornada muestran el estado deshabilitado al bloquear ACU.");
        int historial = cambios;
        Rechaza(() => Invocar(panel, "EliminarRecurso"), exige);
        exige(cambios == historial, "La entrada directa de eliminación ACU bloqueada no genera historial.");

        permisos.Especificaciones = false; panel.ActualizarPermisoNube();
        exige(especificacion.ReadOnly && especificacion.Text.Contains("Contenido visible"),
            "Las especificaciones bloqueadas conservan su contenido visible en solo lectura.");
        Gris(especificacion.BackColor, exige, "El papel de especificaciones aparece gris cuando no se puede editar.");
        exige((SystemInformation.HighContrast || especificacion.BackColor != especificacionEditable) && especificacion.Enabled
            && especificacion.Rtf == rtfSinBloqueo,
            "El bloqueo visual permite seleccionar texto y conserva el RTF sin modificarlo.");
        exige(especificacion.Cursor == Cursors.No && hoja.Cursor == cursorHoja && formula.Cursor == cursorFormula,
            "El documento bloqueado muestra prohibido sin cambiar el puntero de Excel editable.");
        exige(!Campo<ToolStripComboBox>(editor, "fuentes").Enabled && !Campo<ToolStripComboBox>(editor, "tamanos").Enabled
            && !Campo<ToolStripButton>(editor, "negrita").Enabled && !Campo<Button>(editor, "insertarTitulo").Enabled,
            "La cinta de especificaciones deshabilita las herramientas que modifican el documento.");
        especificacion.Select(0, Math.Min(5, especificacion.TextLength));
        exige(especificacion.SelectionLength > 0 && zoom.Enabled && copiar.Enabled
            && zoom.Cursor == cursorZoom && copiar.Owner.Cursor == cursorCopiar,
            "Una especificación bloqueada conserva selección, copiar y zoom disponibles.");

        permisos.MetradosExcel = false; panel.ActualizarPermisoNube();
        exige(hoja.ReadOnly && formula.ReadOnly,
            "La hoja y su barra de fórmulas quedan en solo lectura.");
        Gris(hoja.BackgroundColor, exige, "El fondo de la hoja comunica el bloqueo de Metrados Excel.");
        Gris(formula.BackColor, exige, "La barra de fórmulas bloqueada usa un fondo gris.");
        exige((SystemInformation.HighContrast || hoja.BackgroundColor != hojaEditable && formula.BackColor != formulaEditable)
            && hoja.Enabled && formula.Enabled,
            "La hoja y la fórmula cambian de aspecto conservando la consulta y selección.");
        exige(hoja.Cursor == Cursors.No && formula.Cursor == Cursors.No && celdaTotal.Cursor == Cursors.No,
            "Hoja, fórmula y celda total muestran el puntero de prohibido cuando Excel está bloqueado.");
        hoja.Cursor = Cursors.Cross;
        exige(hoja.Cursor == Cursors.No,
            "Un cambio externo de puntero no sustituye prohibido mientras la hoja está bloqueada.");
        foreach (var barra in barrasHoja)
            exige(barra.Barra.Cursor == Cursors.Default && barra.Barra.Enabled == barra.Habilitada,
                "Las barras de desplazamiento de Excel conservan su habilitación y no heredan el puntero de prohibido.");
        var puntoHoja = new Point(hoja.ClientSize.Width / 2, hoja.ClientSize.Height / 2);
        exige(hoja.ClientRectangle.Contains(puntoHoja) && CursorHoja(panel, puntoHoja) == Cursors.No,
            "El selector de puntero de Excel conserva prohibido al desplazarse dentro de la hoja bloqueada.");
        exige(CursorHoja(panel, new Point(-1, -1)) != Cursors.No,
            "El puntero de prohibido de Excel no se extiende fuera de su área cliente.");
        if (hoja.Rows.Count > 0 && hoja.Columns.Count > 0)
        {
            hoja.CurrentCell = hoja.Rows[0].Cells[0];
            exige(hoja.CurrentCell == hoja.Rows[0].Cells[0] && hoja.ReadOnly,
                "Seleccionar una celda sigue permitido en la hoja bloqueada.");
        }
        Rechaza(() => Invocar(panel, "EjecutarComandoHoja", "limpiar"), exige);
        Rechaza(() => Invocar(panel, "ImportarHoja"), exige);
        exige(cambios == historial && partida.Costos.Hoja.Celdas["A3"].Contenido == "Contenido visible de la hoja",
            "Los comandos de hoja bloqueados no alteran datos ni historial.");
        partida.Costos.Hoja.RangoCuerpoPlantilla = null;
        partida.Costos.Hoja.RellenoCabeceraEstandarAplicado = false;
        string legado = MYGProyectoStorage.Firma(proyecto);
        Invocar(panel, "CargarHoja");
        exige(MYGProyectoStorage.Firma(proyecto) == legado,
            "Consultar una hoja heredada bloqueada no aplica reparaciones persistentes ni cambia el documento.");
        exige(pestanas.TabPages.Count == paginas, "Los permisos no ocultan ni eliminan las pestañas de módulos.");

        permisos.Acu = true; panel.ActualizarPermisoNube();
        exige(!acu.ReadOnly && acu.BackgroundColor == acuEditable && hoja.ReadOnly && especificacion.ReadOnly,
            "Restituir sólo ACU recupera su edición y colores sin desbloquear los otros módulos.");
        exige(acu.Cursor == cursorAcu && hoja.Cursor == Cursors.No && especificacion.Cursor == Cursors.No
            && formula.Cursor == Cursors.No && celdaTotal.Cursor == Cursors.No,
            "Restituir sólo ACU recupera su puntero y conserva prohibido en los otros módulos bloqueados.");
        Gris(hoja.BackgroundColor, exige, "Restituir ACU conserva gris la hoja bloqueada.");
        Gris(especificacion.BackColor, exige, "Restituir ACU conserva gris la especificación bloqueada.");
        permisos.Acu = false; panel.ActualizarPermisoNube();

        permisos.Acu = permisos.Especificaciones = permisos.MetradosExcel = true;
        edicionGlobal = false; panel.ActualizarPermisoNube();
        exige(acu.ReadOnly && hoja.ReadOnly && especificacion.ReadOnly,
            "Los permisos de módulo no elevan a un lector global ni una sesión revocada.");
        Gris(estructura.BackgroundColor, exige, "La estructura del presupuesto se muestra gris para un lector global.");
        Gris(tablaPie.BackgroundColor, exige, "El pie del presupuesto se muestra gris para un lector global.");
        exige((SystemInformation.HighContrast || estructura.BackgroundColor != estructuraEditable && tablaPie.BackgroundColor != pieEditable)
            && estructura.Enabled && tablaPie.Enabled,
            "El bloqueo global conserva la navegación por estructura y resumen.");
        exige(estructura.Cursor == Cursors.No && tablaPie.Cursor == Cursors.No,
            "Un lector global ve el puntero de prohibido en estructura y resumen.");

        bool temaOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos(); Application.DoEvents();
            Gris(acu.BackgroundColor, exige, "Cambiar de tema mantiene gris el ACU bloqueado.");
            Gris(hoja.BackgroundColor, exige, "Cambiar de tema mantiene gris la hoja bloqueada.");
            Gris(especificacion.BackColor, exige, "Cambiar de tema mantiene gris el documento bloqueado.");
            exige(acu.ReadOnly && hoja.ReadOnly && especificacion.ReadOnly && especificacion.Rtf == rtfSinBloqueo,
                "Cambiar el tema no reactiva editores ni altera el formato del documento bloqueado.");
            exige(acu.Cursor == Cursors.No && hoja.Cursor == Cursors.No && especificacion.Cursor == Cursors.No
                && formula.Cursor == Cursors.No && celdaTotal.Cursor == Cursors.No
                && estructura.Cursor == Cursors.No && tablaPie.Cursor == Cursors.No,
                "Cambiar el tema conserva prohibido en el contenido bloqueado.");
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != temaOriginal) MYG2027_TemaComercial.Alternar(false);
            panel.AplicarTemaPresupuestos(); panel.ActualizarPermisoNube();
        }
        edicionGlobal = true; panel.ActualizarPermisoNube();
        exige(!acu.ReadOnly && !hoja.ReadOnly && !especificacion.ReadOnly,
            "Restituir los permisos reactiva los editores sin recrear el proyecto.");
        exige(acu.BackgroundColor == acuEditable && hoja.BackgroundColor == hojaEditable
            && estructura.BackgroundColor == estructuraEditable && tablaPie.BackgroundColor == pieEditable
            && especificacion.BackColor == especificacionEditable && formula.BackColor == formulaEditable,
            "Recuperar permisos restaura los colores editables sin recrear los controles.");
        exige(acu.Cursor == cursorAcu && hoja.Cursor != Cursors.No && especificacion.Cursor == cursorEspecificacion
            && formula.Cursor == cursorFormula && celdaTotal.Cursor == cursorTotal
            && estructura.Cursor == cursorEstructura && tablaPie.Cursor == cursorPie
            && zoom.Cursor == cursorZoom && copiar.Owner.Cursor == cursorCopiar,
            "Recuperar permisos restaura los punteros de edición y conserva los de consulta.");
        exige(CursorHoja(panel, puntoHoja) != Cursors.No,
            "Al recuperar Excel el selector dinámico vuelve a elegir un puntero normal.");
        exige(Campo<ToolStripComboBox>(editor, "fuentes").Enabled && Campo<ToolStripComboBox>(editor, "tamanos").Enabled
            && Campo<ToolStripButton>(editor, "negrita").Enabled && especificacion.Rtf == rtfSinBloqueo
            && cambios == historial,
            "La cinta vuelve a permitir edición y los cambios visuales no modifican contenido ni historial.");
        ventana.Close();
    }

    private static void Gris(Color color, Action<bool, string> exige, string mensaje) =>
        exige(color.A == 255 && (SystemInformation.HighContrast ||
            Math.Abs(color.R - color.G) <= 3 && Math.Abs(color.G - color.B) <= 3), mensaje);

    private static ToolStripItem Elemento(Control raiz, string texto) =>
        Controles(raiz).OfType<ToolStrip>().SelectMany(t => t.Items.Cast<ToolStripItem>())
            .First(i => i.Text == texto);

    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (Control control in Controles(hijo)) yield return control;
    }

    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static Cursor CursorHoja(MYGPanelPresupuesto panel, Point punto) =>
        (Cursor)panel.GetType().GetMethod("ElegirCursorHoja", Privados).Invoke(panel, new object[] { punto });
    private static void Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); }
    }
    private static void Rechaza(Action accion, Action<bool, string> exige)
    {
        bool rechazo = false;
        try { accion(); } catch (InvalidOperationException) { rechazo = true; }
        exige(rechazo, "La mutación del módulo bloqueado exige permiso incluso al invocarse directamente.");
    }
}
