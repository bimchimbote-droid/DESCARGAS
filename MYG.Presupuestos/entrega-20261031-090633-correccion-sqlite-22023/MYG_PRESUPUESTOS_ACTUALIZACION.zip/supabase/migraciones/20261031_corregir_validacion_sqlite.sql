-- Corrección de compatibilidad del marcador SQLite con el trigger legado de
-- adjuntos. Ejecutar TODO después de 20261030_archivos_sqlite.sql.
-- No borra obras/objetos, no convierte contenido ni cambia el validador legado.
-- Cambia únicamente el WHEN del trigger conocido: los proyectos JSON siguen
-- pasando por su mismo validador; SQLite usa su guarda nativa ya instalada.
begin;

do $corregir_trigger$
declare
    v_trigger record; v_def text; v_nueva text; v_comentario text; v_condicion text;
    v_funcion_antes jsonb;
begin
    -- Excluir el marcador exacto solo es seguro si la guarda nativa está activa
    -- y sigue comprobando proyecto privado, revisión y contenido exacto.
    if not exists(select 1 from pg_proc where oid=to_regprocedure('myg_nube_privado.sqlite_proteger_proyecto()')
        and md5(replace(prosrc,E'\r\n',E'\n'))='32e17689ae85991a836956f829dc45cd'
        and prosecdef and prorettype='trigger'::regtype)
        or not exists(select 1 from pg_trigger where tgrelid=to_regclass('public.myg_nube_proyectos')
            and tgname='myg_nube_sqlite_proteger' and not tgisinternal
            and tgfoid=to_regprocedure('myg_nube_privado.sqlite_proteger_proyecto()')
            and tgtype=23 and tgnargs=0 and tgattr=''::int2vector
            and tgqual is null and tgenabled in ('O','A')) then
        raise exception 'La guarda SQLite nativa no coincide o está inactiva. Instale primero 20261030_archivos_sqlite.sql; no se cambió ningún trigger.';
    end if;

    -- pg_get_expr(tgqual,...) no sabe resolver Vars NEW/OLD de triggers en PG17.
    -- pg_get_triggerdef sí utiliza el contexto correcto y conserva UPDATE OF.
    select t.*,pg_get_triggerdef(t.oid) definicion
      into v_trigger from pg_trigger t
      where t.tgrelid='public.myg_nube_proyectos'::regclass
        and t.tgname='myg_nube_validar_adjuntos' and not t.tgisinternal;
    if not found then
        raise notice 'No existe el trigger legado myg_nube_validar_adjuntos. No fue necesario modificarlo.';
        return;
    end if;
    if v_trigger.tgfoid is distinct from to_regprocedure('myg_nube_privado.validar_paquete_archivos()')
       or v_trigger.tgtype<>23 or v_trigger.tgnargs<>0 then
        raise exception 'El trigger de adjuntos tiene una definición desconocida; se conserva intacto.';
    end if;
    v_condicion:=regexp_replace(substring(v_trigger.definicion
        from ' WHEN (.*) EXECUTE (?:FUNCTION|PROCEDURE) '),'[[:space:]]','','g');
    if v_condicion=regexp_replace(
        $expr$(((NOT new.es_comprimido) AND (new.contenido IS DISTINCT FROM '{"formato": "MYG_SQLITE", "version": 1}'::jsonb)))$expr$,
        '[[:space:]]','','g') then
        raise notice 'El trigger de adjuntos ya excluye el marcador SQLite exacto.';
        return;
    end if;
    if v_condicion is distinct from '((NOTnew.es_comprimido))' then
        raise exception 'La condición del trigger de adjuntos es personalizada; se conserva intacta.';
    end if;

    select to_jsonb(p) into v_funcion_antes from pg_proc p where oid=v_trigger.tgfoid;
    v_def:=v_trigger.definicion;
    v_comentario:=obj_description(v_trigger.oid,'pg_trigger');
    v_nueva:=regexp_replace(v_def,' WHEN \(.*\) EXECUTE (FUNCTION|PROCEDURE) ',
        ' WHEN ((NOT new.es_comprimido) AND (new.contenido IS DISTINCT FROM ''{"formato":"MYG_SQLITE","version":1}''::jsonb)) EXECUTE \1 ');
    if v_nueva=v_def then raise exception 'No se pudo adaptar la condición conservando el trigger.'; end if;
    execute 'drop trigger myg_nube_validar_adjuntos on public.myg_nube_proyectos';
    execute v_nueva;
    if v_comentario is not null then
        execute format('comment on trigger myg_nube_validar_adjuntos on public.myg_nube_proyectos is %L',v_comentario);
    end if;
    if v_trigger.tgenabled='D' then alter table public.myg_nube_proyectos disable trigger myg_nube_validar_adjuntos;
    elsif v_trigger.tgenabled='R' then alter table public.myg_nube_proyectos enable replica trigger myg_nube_validar_adjuntos;
    elsif v_trigger.tgenabled='A' then alter table public.myg_nube_proyectos enable always trigger myg_nube_validar_adjuntos;
    end if;
    if not exists(select 1 from pg_trigger t where t.tgrelid=v_trigger.tgrelid and t.tgname=v_trigger.tgname
        and t.tgfoid=v_trigger.tgfoid and t.tgtype=v_trigger.tgtype and t.tgattr=v_trigger.tgattr
        and t.tgnargs=v_trigger.tgnargs and t.tgargs=v_trigger.tgargs and t.tgenabled=v_trigger.tgenabled
        and obj_description(t.oid,'pg_trigger') is not distinct from v_comentario)
       or not exists(select 1 from pg_proc p where oid=v_trigger.tgfoid and to_jsonb(p)=v_funcion_antes) then
        raise exception 'La adaptación no conservó los atributos/validador originales; se revierte completa.';
    end if;
end $corregir_trigger$;
notify pgrst,'reload schema';
commit;
select 'CORRECCION_VALIDACION_SQLITE_INSTALADA' resultado;
