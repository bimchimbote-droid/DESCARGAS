-- SOLO PostgreSQL DESECHABLE. El cuerpo productivo del validador de adjuntos
-- NO está en el repositorio. Este fixture reproduce la definición del trigger
-- documentada en LEEME_CORRECCION_TRIGGER_20261028 y usa un guard/contador
-- sintético claramente identificado; no afirma ejecutar el validador real.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren PostgreSQL desechable.'; end $$;
\endif
\ir archivos_sqlite.sql
reset role;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';

-- El log recibido confirma MYG_ALCANCE_NO_COINCIDE. Reproducir esa regla
-- mínima no equivale a disponer del cuerpo completo del validador productivo.
insert into public.myg_nube_proyectos(id,propietario,nombre,contenido,alcance) values
('d9000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000001',
 'LEGADO QA ALCANCE','{"formato":"MYG_COLABORACION","version":1,"alcance":"obra"}','obra');

create table qa.llamadas_validacion_sqlite(nombre text,proyecto uuid,evento text);
create function myg_nube_privado.validar_paquete_archivos() returns trigger
language plpgsql security definer set search_path=pg_catalog as $$
begin
    insert into qa.llamadas_validacion_sqlite values('legado',new.id,tg_op);
    if new.contenido->>'alcance' is distinct from new.alcance then
        raise exception using errcode='22023',message='MYG_ALCANCE_NO_COINCIDE';
    end if;
    return new;
end $$;
comment on function myg_nube_privado.validar_paquete_archivos()
is 'SINTETICO: guard/contador de contrato; no contiene el validador productivo';
revoke all on function myg_nube_privado.validar_paquete_archivos() from public;
grant execute on function myg_nube_privado.validar_paquete_archivos() to anon;
create trigger myg_nube_validar_adjuntos before insert or update of contenido,alcance
on public.myg_nube_proyectos for each row when (not new.es_comprimido)
execute function myg_nube_privado.validar_paquete_archivos();
comment on trigger myg_nube_validar_adjuntos on public.myg_nube_proyectos
is 'SINTETICO: misma estructura UPDATE OF observada, comentario preservado';
alter table public.myg_nube_proyectos enable always trigger myg_nube_validar_adjuntos;
create function qa.trigger_ajeno_sqlite() returns trigger language plpgsql as $$
begin insert into qa.llamadas_validacion_sqlite values('ajeno',new.id,tg_op); return new; end $$;
create trigger qa_trigger_ajeno_sqlite before insert or update on public.myg_nube_proyectos
for each row execute function qa.trigger_ajeno_sqlite();

create table qa.antes_correccion_sqlite as select
    (select to_jsonb(p) from pg_proc p where oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure) funcion,
    (select to_jsonb(t)-array['oid','tgqual'] from pg_trigger t
        where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos') trigger_atributos,
    (select obj_description(oid,'pg_trigger') from pg_trigger
        where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos') comentario,
    (select pg_get_triggerdef(oid) from pg_trigger
        where tgrelid='public.myg_nube_proyectos'::regclass and tgname='qa_trigger_ajeno_sqlite') ajeno;
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000002/'||repeat('d',64)||'.sqlite','{"size":4096}');
create function qa.rechaza_mensaje(p_sql text,p_codigo text,p_mensaje text,p_detalle text)
returns void language plpgsql as $$
declare v_codigo text; v_mensaje text;
begin
    begin
        execute p_sql;
    exception when others then
        get stacked diagnostics v_codigo=returned_sqlstate,v_mensaje=message_text;
        perform qa.exige(v_codigo=p_codigo and v_mensaje=p_mensaje,p_detalle);
        return;
    end;
    raise exception 'Se esperaba rechazo: %',p_detalle;
end $$;
select qa.rechaza_mensaje($$select public.myg_nube_sqlite_crear('d9000000-0000-0000-0000-000000000002',
    'SQLite TRIGGER QA','obra','doc-qa-trigger',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000002/'||repeat('d',64)||'.sqlite',repeat('d',64),4096)$$,
    '22023','MYG_ALCANCE_NO_COINCIDE',
    'Corrección SQLite: reproducido el SQLSTATE22023 y mensaje MYG_ALCANCE_NO_COINCIDE recibidos');
select qa.exige(not exists(select 1 from public.myg_nube_proyectos where id='d9000000-0000-0000-0000-000000000002')
    and not exists(select 1 from myg_nube_privado.sqlite_proyectos where proyecto_id='d9000000-0000-0000-0000-000000000002'),
    'Corrección SQLite: el rechazo revierte la creación completa sin tocar el archivo subido');

\ir ../migraciones/20261031_corregir_validacion_sqlite.sql
select qa.exige((select funcion=(select to_jsonb(p) from pg_proc p where oid='myg_nube_privado.validar_paquete_archivos()'::regprocedure)
    and trigger_atributos=(select to_jsonb(t)-array['oid','tgqual'] from pg_trigger t
        where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos')
    and comentario=(select obj_description(oid,'pg_trigger') from pg_trigger
        where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos')
    and ajeno=(select pg_get_triggerdef(oid) from pg_trigger
        where tgrelid='public.myg_nube_proyectos'::regclass and tgname='qa_trigger_ajeno_sqlite')
    from qa.antes_correccion_sqlite),
    'Corrección SQLite: conserva cuerpo/OID/ACL/propietario del validador y atributos/UPDATE OF/estado/comentario del trigger');
select qa.exige(public.myg_nube_sqlite_crear('d9000000-0000-0000-0000-000000000002',
    'SQLite TRIGGER QA','obra','doc-qa-trigger',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000002/'||repeat('d',64)||'.sqlite',repeat('d',64),4096)->>'revision'='1',
    'Corrección SQLite: el mismo intento y objeto pueden publicarse tras corregir el trigger');
select qa.exige(not exists(select 1 from qa.llamadas_validacion_sqlite where nombre='legado')
    and exists(select 1 from qa.llamadas_validacion_sqlite where nombre='ajeno'),
    'Corrección SQLite: marcador exacto usa su guarda nativa; los triggers ajenos siguen ejecutándose');
update public.myg_nube_proyectos set contenido=contenido where id='d9000000-0000-0000-0000-000000000004';
select qa.exige((select count(*)=1 from qa.llamadas_validacion_sqlite where nombre='legado'),
    'Corrección SQLite: las actualizaciones de JSON legado conservan su validador');
select qa.rechaza($$insert into public.myg_nube_proyectos(id,propietario,nombre,contenido)
    values('d9000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000001',
    'MARCADOR FALSO','{"formato":"MYG_SQLITE","version":1}')$$,
    'MGS01','Corrección SQLite: un marcador falso sigue rechazado por la guarda nativa');

create table qa.primera_correccion_sqlite as select oid,pg_get_triggerdef(oid) definicion
from pg_trigger where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos';
\ir ../migraciones/20261031_corregir_validacion_sqlite.sql
select qa.exige((select a.oid=t.oid and a.definicion=pg_get_triggerdef(t.oid)
    from qa.primera_correccion_sqlite a cross join pg_trigger t
    where t.tgrelid='public.myg_nube_proyectos'::regclass and t.tgname='myg_nube_validar_adjuntos'),
    'Corrección SQLite: reinstalar es idempotente y ni siquiera recrea el trigger');

-- Ejecutar el DO real de la migración (sin envolver BEGIN/COMMIT en una función)
-- permite demostrar rechazo seguro sin copiar su implementación a la prueba.
create table qa.bloque_correccion_sqlite as select substring(
    pg_read_file('/pruebas/supabase/migraciones/20261031_corregir_validacion_sqlite.sql')
    from '(do \$corregir_trigger\$.*\$corregir_trigger\$;)') sentencia;
select qa.exige((select sentencia is not null from qa.bloque_correccion_sqlite),
    'Corrección SQLite: se verifica el bloque real del instalador');
alter table public.myg_nube_proyectos disable trigger myg_nube_sqlite_proteger;
select qa.rechaza((select sentencia from qa.bloque_correccion_sqlite),'P0001',
    'Corrección SQLite: no excluye validación si la guarda nativa está deshabilitada');
alter table public.myg_nube_proyectos enable trigger myg_nube_sqlite_proteger;
drop trigger myg_nube_validar_adjuntos on public.myg_nube_proyectos;
create trigger myg_nube_validar_adjuntos before insert or update of contenido,alcance
on public.myg_nube_proyectos for each row when (new.nombre<>'')
execute function myg_nube_privado.validar_paquete_archivos();
create table qa.personalizado_sqlite as select pg_get_triggerdef(oid) definicion
from pg_trigger where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos';
select qa.rechaza((select sentencia from qa.bloque_correccion_sqlite),'P0001',
    'Corrección SQLite: una condición personalizada no se sustituye ni se amplía');
select qa.exige((select definicion=(select pg_get_triggerdef(oid) from pg_trigger
    where tgrelid='public.myg_nube_proyectos'::regclass and tgname='myg_nube_validar_adjuntos')
    from qa.personalizado_sqlite),'Corrección SQLite: rechazo conserva el trigger personalizado intacto');
select 'CORRECCION_VALIDACION_SQLITE_PRUEBAS_APROBADAS' resultado;
