-- SOLO LECTURA. Ejecutar como administrador para diagnosticar HTTP400/22023.
-- No imprime cuerpos de funciones, credenciales ni datos/archivos de proyectos.
begin read only;
select t.tgname,n.nspname esquema_funcion,p.proname funcion,
    t.tgenabled estado,pg_get_triggerdef(t.oid) definicion,
    md5(replace(p.prosrc,E'\r\n',E'\n')) huella_funcion
from pg_trigger t join pg_proc p on p.oid=t.tgfoid join pg_namespace n on n.oid=p.pronamespace
where t.tgrelid=to_regclass('public.myg_nube_proyectos') and not t.tgisinternal
order by t.tgname;

select p.proname,md5(replace(p.prosrc,E'\r\n',E'\n')) huella,
    position('MYG_CREACION_SQLITE_INVALIDA' in p.prosrc)>0 comprueba_creacion,
    position('MYG_ARCHIVO_SQLITE_INVALIDO' in p.prosrc)>0 comprueba_referencia,
    position('MYG_ARCHIVO_SQLITE_NO_DISPONIBLE' in p.prosrc)>0 comprueba_storage,
    position('MYG_ID_REUTILIZADO_CON_OTRA_CREACION' in p.prosrc)>0 comprueba_reintento
from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where (n.nspname='public' and p.proname='myg_nube_sqlite_crear')
   or (n.nspname='myg_nube_privado' and p.proname in ('sqlite_validar_datos','sqlite_validar_objeto'))
order by n.nspname,p.proname;

select count(*) objetos_sqlite,
    count(*) filter(where metadata->>'size' is null) sin_tamano_storage,
    count(*) filter(where metadata->>'size' is not null and metadata->>'size' !~ '^[0-9]{1,10}$') tamano_no_entero,
    count(*) filter(where jsonb_typeof(metadata->'size')='number') tamano_numerico,
    count(*) filter(where jsonb_typeof(metadata->'size')='string') tamano_textual
from storage.objects where bucket_id='myg-nube-sqlite';
rollback;
