# Corrección de publicación SQLite: MYG_ALCANCE_NO_COINCIDE

El registro de Supabase confirmó `MYG_ALCANCE_NO_COINCIDE` para el rechazo HTTP 400 / SQLSTATE 22023. El trigger anterior de adjuntos se ejecutaba también al insertar el marcador del formato SQLite. Ese formato conserva el alcance en los metadatos del proyecto; no contiene el paquete JSON anterior con el que trabaja ese validador.

La corrección adapta únicamente la condición del trigger conocido `myg_nube_validar_adjuntos`: los proyectos SQLite válidos usan su guarda nativa; los proyectos anteriores conservan su mismo validador. Se mantienen función, permisos, eventos, columnas UPDATE OF, estado y comentario. La instalación se detiene si encuentra una definición personalizada o una guarda nativa incompatible/inactiva. No cambia archivos C#, no convierte datos y no activa compresión.

## Archivos

| Ruta exacta | Acción | Uso |
|---|---|---|
| `supabase/migraciones/20261031_corregir_validacion_sqlite.sql` | CREAR | Ejecutar completo en Supabase SQL Editor. |
| `supabase/diagnosticos/20261031_sqlite_validacion_solo_lectura.sql` | CREAR | Diagnóstico opcional de solo lectura si el error continúa. |
| `supabase/pruebas/corregir_validacion_sqlite.sql` | CREAR | Pruebas locales; NO ejecutar en Supabase real. |
| `scripts/pruebas/Probar-CorreccionValidacionSqlite.sh` | CREAR | Runner opcional de pruebas locales con Docker y .NET. |
| `supabase/LEEME_CORRECCION_SQLITE_22023_20261031.md` | CREAR | Leer estas instrucciones. |

Copiar los archivos a sus rutas dentro del repositorio conserva la actualización para su siguiente commit. Para aplicar el arreglo al servicio solo se ejecuta el archivo de migración indicado.

## Aplicar la corrección

1. Conservar el respaldo de su configuración y la publicación pendiente. No borrar ni retirar el intento fallido.
2. Abrir el mismo proyecto Supabase que usa MYG, entrar a **SQL Editor → New query**.
3. Abrir `supabase/migraciones/20261031_corregir_validacion_sqlite.sql` con Bloc de notas y copiar **todo su contenido**, incluyendo BEGIN, COMMIT y la consulta final.
4. Pegar y pulsar **Run** una vez. El resultado esperado es `CORRECCION_VALIDACION_SQLITE_INSTALADA`.
5. Volver a MYG → **Publicaciones pendientes** → **Reintentar** el intento existente. Se conserva el mismo identificador y archivo SQLite; no es necesario crear otra publicación.
6. Comprobar que aparece en Mis proyectos y que permite abrir y descargar su archivo SQLite.

Requiere tener instalada `20261030_archivos_sqlite.sql`. Si ya se instaló, no repetirla ni volver a ejecutar las migraciones anteriores para resolver este error. No cambiar el alcance manualmente, no hacer público el bucket y no desactivar los triggers.

No necesita recompilar ni reemplazar archivos `.cs` por esta corrección.

## Si aparece otro error

Conservar el intento y copiar el mensaje exacto del registro. El script `supabase/diagnosticos/20261031_sqlite_validacion_solo_lectura.sql` puede ejecutarse en otra consulta SQL Editor para consultar las definiciones de triggers, huellas de funciones y contadores de metadatos Storage. No modifica filas ni muestra archivos, credenciales o cuerpos de funciones.

## Pruebas y alcance

El runner utiliza PostgreSQL 17 local desechable, aislado de Supabase real. Reproduce el control de alcance informado y la estructura del trigger documentada anteriormente. El cuerpo completo de la función productiva no está en el repositorio: se conserva intacto y no se afirma haberlo ejecutado en laboratorio.

El runner terminó con código 0: **12 comprobaciones correctivas y 32 regresiones SQLite aprobadas**. Se reprodujo `22023 / MYG_ALCANCE_NO_COINCIDE` antes del arreglo y se confirmó la misma publicación, con el mismo UUID y objeto, después. También se verificaron preservación del validador antiguo, rechazo de marcadores falsificados, instalación repetible y rechazo seguro de personalizaciones incompatibles. La aplicación en su proyecto remoto y el reintento se verifican mediante los pasos anteriores.

## GitHub

El ZIP correctivo se entrega en una ruta nueva del repositorio independiente `bimchimbote-droid/DESCARGAS`. No se publica automáticamente el código de MYG.Presupuestos. Después de aplicar el arreglo, revisar estos cinco archivos en Cambios de Git de Visual Studio, realizar el commit y hacer push a su rama habitual.
