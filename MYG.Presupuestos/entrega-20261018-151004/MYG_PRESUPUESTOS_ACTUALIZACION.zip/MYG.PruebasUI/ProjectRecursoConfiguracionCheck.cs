using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using MYG_2027;

// Contrato de las escrituras de recurso usadas por el adaptador COM.
// Se ejecuta también en Linux sin Office ni WinForms.
internal static class ProjectRecursoConfiguracionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarUnidades(exige);
        VerificarTipos(exige);
        VerificarErrores(exige);
    }

    private static void VerificarUnidades(Action<bool, string> exige)
    {
        // El setter simulado acepta unidades literales; no presupone que
        // Project necesite o permita prefijos inventados.
        foreach (string unidad in new[] { "mes", "kg", "m³", "p²", "kg/m³", "%mo", "und", "bol", "área", "日本語", "", null, " m³ " })
        {
            var datos = Recurso(unidad);
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige((string)simulado.Valores["MaterialLabel"] == (unidad ?? "") &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                simulado.Operaciones.Count(o => o == "set:MaterialLabel") == 1 &&
                simulado.Operaciones.Contains("get:MaterialLabel") && datos == original,
                "MaterialLabel debe conservar y verificar la unidad exacta de la base, incluidos Unicode, símbolos, espacios y vacío, sin modificar el DTO.");
            exige(simulado.Valores.Keys.All(p => p is "Type" or "Code" or "Group" or "MaterialLabel" or "StandardRate") &&
                (string)simulado.Valores["Code"] == datos.Codigo && (string)simulado.Valores["Group"] == datos.Grupo,
                "Exportar una unidad no debe añadir Text1/Notes decorativos ni alterar código, grupo o nombre del origen.");
        }

        var culturaOriginal = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
            var datos = Recurso("%mo") with { Tarifa = 1234.56789m };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige(simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                (string)simulado.Valores["MaterialLabel"] == "%mo",
                "El recurso porcentual material debe recibir %mo literal y una tarifa numérica independiente de la cultura.");
        }
        finally { CultureInfo.CurrentCulture = culturaOriginal; }
    }

    private static void VerificarTipos(Action<bool, string> exige)
    {
        foreach (int tipo in new[] { 1, 2 })
        {
            var datos = Recurso(tipo == 1 ? "hh" : "%mo") with { Tipo = tipo };
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Calendario específico", simulado.Leer, simulado.Escribir);
            exige(Convert.ToInt32(simulado.Valores["Type"], CultureInfo.InvariantCulture) == (tipo == 1 ? 0 : 2) &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                !simulado.Valores.ContainsKey("MaterialLabel") && datos == original,
                "Los recursos de trabajo y el tipo de costo explícito legado deben confirmar su tipo COM sin recibir una etiqueta material.");
            exige(tipo == 1
                    ? simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                      (string)simulado.Valores["BaseCalendar"] == "Calendario específico"
                    : !simulado.Valores.ContainsKey("StandardRate") && !simulado.Valores.ContainsKey("BaseCalendar"),
                "El trabajo conserva tarifa y calendario, y el costo explícito legado no debe convertirse en trabajo o material.");
        }
    }

    private static void VerificarErrores(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var tipoRechazado = new RecursoSimulado { TipoLeido = 0 };
        Exception fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoRechazado.Leer, tipoRechazado.Escribir));
        exige(fallo is InvalidOperationException && tipoRechazado.Operaciones.SequenceEqual(new[] { "set:Type", "get:Type" }),
            "Si Project no conserva el tipo material, la configuración debe abortar antes de escribir etiquetas o tarifas.");

        var rechazoEtiqueta = new COMException("MaterialLabel rechazado por Project", unchecked((int)0x800A044D));
        var etiquetaConError = new RecursoSimulado { FalloEtiqueta = rechazoEtiqueta };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", etiquetaConError.Leer, etiquetaConError.Escribir));
        exige(fallo is InvalidOperationException && ReferenceEquals(fallo.InnerException, rechazoEtiqueta) &&
            fallo.Message.Contains("mes", StringComparison.Ordinal) && fallo.Message.Contains(datos.Nombre, StringComparison.Ordinal) &&
            etiquetaConError.Operaciones.Count(o => o == "set:MaterialLabel") == 1 &&
            etiquetaConError.Operaciones.Last() == "set:MaterialLabel" && !etiquetaConError.Valores.ContainsKey("StandardRate"),
            "Un rechazo real de mes debe conservar el error COM y explicar recurso y unidad, sin intentar MYGmes u otra etiqueta ni continuar con tarifas.");

        var etiquetaCambiada = new RecursoSimulado { EtiquetaLeida = "MYGmes" };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", etiquetaCambiada.Leer, etiquetaCambiada.Escribir));
        exige(fallo is InvalidOperationException && fallo.Message.Contains("mes", StringComparison.Ordinal) &&
            !etiquetaCambiada.Valores.ContainsKey("StandardRate"),
            "Una unidad que Project normalice o prefije debe rechazarse al verificarla, antes de exportar costos.");

        var errorTipo = new COMException("Fallo COM al asignar Type", unchecked((int)0x80020009));
        var tipoConError = new RecursoSimulado { FalloTipo = errorTipo };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoConError.Leer, tipoConError.Escribir));
        exige(ReferenceEquals(fallo, errorTipo) && tipoConError.Operaciones.SequenceEqual(new[] { "set:Type" }),
            "Un error COM al establecer el tipo debe propagarse sin continuar con otros datos.");

        var errorTarifa = new COMException("Error COM específico en StandardRate", unchecked((int)0x80020009));
        var tarifaConError = new RecursoSimulado { FalloTarifa = errorTarifa };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tarifaConError.Leer, tarifaConError.Escribir));
        exige(ReferenceEquals(fallo, errorTarifa) && tarifaConError.Operaciones.Count(o => o == "set:StandardRate") == 1 &&
            tarifaConError.Operaciones.Last() == "set:StandardRate" && (string)tarifaConError.Valores["MaterialLabel"] == "mes",
            "Un error de tarifa debe conservar su excepción sin reintentos que lo oculten como un problema de unidades.");

        var desconocido = new RecursoSimulado();
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos with { Tipo = 37 }, "Obra", desconocido.Leer, desconocido.Escribir));
        exige(fallo is InvalidDataException && desconocido.Operaciones.Count == 0,
            "Un tipo de recurso desconocido debe rechazarse antes de cualquier escritura COM.");
    }

    private static MYGRecursoExportacionProject Recurso(string unidad) =>
        new(27, 0, "Recurso de prueba", "130001", "Materiales", unidad, 22.07m);

    private static Exception Capturar(Action accion)
    {
        try { accion(); return null; }
        catch (Exception ex) { return ex; }
    }

    private sealed class RecursoSimulado
    {
        internal readonly Dictionary<string, object> Valores = new(StringComparer.Ordinal);
        internal readonly List<string> Operaciones = new();
        internal int? TipoLeido;
        internal string EtiquetaLeida;
        internal COMException FalloTipo, FalloEtiqueta, FalloTarifa;
        private bool tipoConfirmado;

        internal object Leer(string propiedad)
        {
            Operaciones.Add("get:" + propiedad);
            object valor = propiedad == "Type" && TipoLeido.HasValue ? TipoLeido.Value :
                propiedad == "MaterialLabel" && EtiquetaLeida != null ? EtiquetaLeida : Valores[propiedad];
            if (propiedad == "Type") tipoConfirmado = Convert.ToInt32(valor, CultureInfo.InvariantCulture) ==
                Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture);
            return valor;
        }

        internal void Escribir(string propiedad, object valor)
        {
            Operaciones.Add("set:" + propiedad);
            if (propiedad == "Type")
            {
                tipoConfirmado = false;
                if (FalloTipo != null) throw FalloTipo;
            }
            if (propiedad == "MaterialLabel")
            {
                if (!tipoConfirmado || Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture) != 1)
                    throw new InvalidOperationException("MaterialLabel requiere Type material confirmado.");
                if (FalloEtiqueta != null) throw FalloEtiqueta;
            }
            if (propiedad == "StandardRate" && FalloTarifa != null) throw FalloTarifa;
            Valores[propiedad] = valor;
        }
    }
}
