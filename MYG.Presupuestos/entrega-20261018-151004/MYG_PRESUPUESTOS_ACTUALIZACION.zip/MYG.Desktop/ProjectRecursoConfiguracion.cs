using System;
using System.Globalization;
using System.IO;

namespace MYG_2027;

// Se comparte con las comprobaciones de contrato para ejercitar las mismas
// escrituras que utiliza el adaptador COM, sin necesitar una instalación Office.
internal static class MYGConfiguracionRecursoProject
{
    internal static void Configurar(MYGRecursoExportacionProject datos, string calendario,
        Func<string, object> leer, Action<string, object> escribir)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        ArgumentNullException.ThrowIfNull(escribir);
        // Tipo del modelo: material=0, trabajo=1. Tipo COM: trabajo=0, material=1.
        int tipo = datos.Tipo switch { 0 => 1, 1 => 0, 2 => 2,
            _ => throw new InvalidDataException("Tipo de recurso desconocido.") };
        escribir("Type", tipo);
        if (Convert.ToInt32(leer("Type"), CultureInfo.InvariantCulture) != tipo)
            throw new InvalidOperationException("Microsoft Project no aceptó el tipo del recurso «" + datos.Nombre + "».");
        escribir("Code", datos.Codigo ?? "");
        escribir("Group", datos.Grupo ?? "");
        if (datos.Tipo == 0)
        {
            // MaterialLabel es la unidad que Project muestra en la asignación.
            // Conservarla literalmente: los prefijos y la normalización ASCII
            // cambian m³, p², %mo y las demás unidades guardadas en la base.
            // Un rechazo COM se propaga; no se sustituye por una unidad inventada.
            string unidad = datos.Unidad ?? "";
            try { escribir("MaterialLabel", unidad); }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Microsoft Project rechazó la unidad original «" + unidad +
                    "» del recurso «" + datos.Nombre + "». No se sustituyó por otra etiqueta.", ex);
            }
            if (!string.Equals(Convert.ToString(leer("MaterialLabel"), CultureInfo.InvariantCulture), unidad, StringComparison.Ordinal))
                throw new InvalidOperationException("Microsoft Project cambió la unidad original «" + unidad +
                    "» del recurso «" + datos.Nombre + "». No se sustituyó por otra etiqueta.");
        }
        if (datos.Tipo != 2) escribir("StandardRate", (double)datos.Tarifa);
        if (datos.Tipo == 1) escribir("BaseCalendar", calendario);
    }

}
