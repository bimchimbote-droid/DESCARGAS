using System;
using System.Collections.Generic;
using System.Globalization;

namespace MYG_2027;

// Una tarea nueva hereda el calendario del proyecto. No inmovilizar su inicio
// ni asignarle un calendario propio para reproducir una instantánea.
internal static class MYGConfiguracionProgramacionProject
{
    internal static void ConfigurarAutomatica(MYGTareaExportacionProject datos, Action<string, object> escribir)
    {
        if (!datos.Resumen && !datos.Manual)
            escribir("Duration", (double)datos.DuracionMinutos);
    }

    internal static void AnclarDivision(MYGTareaExportacionProject datos,
        IReadOnlyList<MYGTramoTareaExportacionProject> tramos, Action<string, object> escribir)
    {
        // Split interpreta fechas absolutas. Preparar la posición original
        // evita perder una pausa posterior al fin provisional de una tarea
        // todavía sin calcular. QuitarRestricciones libera este anclaje antes
        // del cálculo: no se guarda como restricción del MPP.
        if (!datos.Resumen && !datos.Manual && tramos.Count > 1) escribir("Start", datos.Inicio);
    }

    internal static void QuitarRestricciones(MYGTareaExportacionProject datos, Action<string, object> escribir)
    {
        // El avance, los vínculos o las divisiones pueden introducir una
        // restricción. Esta es la última escritura de programación antes de
        // calcular; las fechas automáticas las decide entonces Project.
        if (datos.Resumen || !datos.Manual) escribir("ConstraintType", 0); // pjASAP
    }

    internal static void CalcularConAvance(IReadOnlyList<MYGTareaExportacionProject> tareas,
        Action quitarRestricciones, Action calcular, Action<MYGTareaExportacionProject, int> escribirAvance)
    {
        quitarRestricciones();
        calcular();
        bool avanceAplicado = false;
        foreach (var datos in tareas)
        {
            if (datos.Resumen || datos.Avance == 0m) continue;
            escribirAvance(datos, decimal.ToInt32(decimal.Round(datos.Avance, MidpointRounding.AwayFromZero)));
            avanceAplicado = true;
        }
        if (avanceAplicado)
        {
            quitarRestricciones();
            calcular();
        }
    }

    internal static string Verificar(MYGTareaExportacionProject datos, Func<string, object> leer)
    {
        if (!datos.Resumen && datos.Manual) return null;
        object modo = leer("Manual");
        if (!(modo is bool automatico) || automatico)
            Fallo(datos, "modo automático", modo);
        object restriccion = leer("ConstraintType");
        if (!Numero(restriccion, out decimal tipo) || tipo != 0m)
            Fallo(datos, "restricción Lo antes posible", restriccion);
        object valorInicio = leer("Start"), valorFin = leer("Finish"), valorDuracion = leer("Duration");
        if (!(valorInicio is DateTime inicio) || inicio == DateTime.MinValue || inicio == DateTime.MaxValue)
            throw Error(datos, "inicio válido", valorInicio);
        if (!(valorFin is DateTime fin) || fin == DateTime.MinValue || fin == DateTime.MaxValue || fin < inicio)
            throw Error(datos, "fin válido posterior o igual al inicio", valorFin);
        if (!Numero(valorDuracion, out decimal duracion) || duracion < 0m)
            throw Error(datos, "duración válida no negativa en minutos", valorDuracion);

        var cambios = new List<string>();
        if (Math.Abs((inicio - datos.Inicio).TotalSeconds) >= 1)
            cambios.Add("inicio " + Fecha(datos.Inicio) + " → " + Fecha(inicio));
        if (Math.Abs((fin - datos.Fin).TotalSeconds) >= 1)
            cambios.Add("fin " + Fecha(datos.Fin) + " → " + Fecha(fin));
        if (Math.Abs(duracion - datos.DuracionMinutos) > 0.01m)
            cambios.Add("duración " + Minutos(datos.DuracionMinutos) + " → " + Minutos(duracion) + " minutos");
        if (cambios.Count == 0) return null;
        return "Microsoft Project recalculó la tarea " + (datos.Resumen ? "resumen" : "automática") +
            " «" + datos.Nombre + "» (UID " + datos.Uid.ToString(CultureInfo.InvariantCulture) + "): " +
            string.Join("; ", cambios) + ". Las fechas guardadas en MYG se conservan.";
    }

    private static void Fallo(MYGTareaExportacionProject datos, string campo, object valor) => throw Error(datos, campo, valor);

    private static InvalidOperationException Error(MYGTareaExportacionProject datos, string campo, object valor) =>
        new("Microsoft Project no conservó un " + campo + " en la tarea «" + datos.Nombre + "» (UID " +
            datos.Uid.ToString(CultureInfo.InvariantCulture) + "). Recibido: " +
            (Convert.ToString(valor, CultureInfo.InvariantCulture) ?? "(vacío)") + ". No se reemplazó el archivo de destino.");

    private static string Fecha(DateTime fecha) => fecha.ToString(
        fecha.Ticks % TimeSpan.TicksPerMinute == 0 ? "yyyy-MM-dd HH:mm" : "yyyy-MM-dd HH:mm:ss.fffffff", CultureInfo.InvariantCulture);
    private static string Minutos(decimal minutos) => minutos.ToString("0.########", CultureInfo.InvariantCulture);

    private static bool Numero(object valor, out decimal numero)
    {
        numero = 0m;
        if (valor == null || valor is bool || valor is char || valor is DateTime) return false;
        try
        {
            if (valor is string texto)
                return decimal.TryParse(texto, NumberStyles.Float, CultureInfo.InvariantCulture, out numero);
            switch (Type.GetTypeCode(valor.GetType()))
            {
                case TypeCode.Byte: case TypeCode.SByte: case TypeCode.UInt16: case TypeCode.Int16:
                case TypeCode.UInt32: case TypeCode.Int32: case TypeCode.UInt64: case TypeCode.Int64:
                case TypeCode.Single: case TypeCode.Double: case TypeCode.Decimal:
                    numero = Convert.ToDecimal(valor, CultureInfo.InvariantCulture);
                    return true;
                default: return false;
            }
        }
        catch (OverflowException) { return false; }
    }
}
