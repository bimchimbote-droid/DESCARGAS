# Tablas Revit por activo del modelo abierto

Base de esta actualización: `bimchimbote-droid/MYG.Presupuestos`, rama remota
`main`, commit `14cc8c2cf78d7a60901c3cd175adbcfc761eac39`.

## Uso

1. En **Activos de la obra**, registre cada modelo local o Autodesk. Para
   Autodesk use los GUID de proyecto y modelo de Revit, no el nombre visible ni
   una ruta de caché.
2. En cada partida, abra **Metrados Revit**, configure su plantilla y filtros y
   asigne los activos correspondientes. Una partida puede tener varios activos.
3. Abra el modelo en Revit 2027. En MYG pulse **Tablas del modelo abierto**
   (nombre accesible: **Crear / actualizar tablas del modelo abierto**).
4. La primera vez, vincule explícitamente ese documento con su activo y confirme.
   MYG guarda el vínculo antes de solicitar cambios en Revit. Después basta el
   mismo botón: no se seleccionan otra vez el activo ni las partidas.

Ejemplo: columnas asignadas a A y B, losas a A y cimientos a B. Al activar A en
Revit y pulsar el botón se procesan columnas y losas. Al activar B, columnas y
cimientos. Se consultan las asignaciones de **todos los presupuestos de la obra**,
independientemente de la fila o presupuesto seleccionados en MYG.

Si hay varias sesiones de Revit y aún no se eligió una, MYG pide elegir la sesión.
Dentro de ella siempre consulta de nuevo el documento activo en cada clic. Para
cambiar de sesión posteriormente use **Conectar Revit**. Si cambia el documento
entre consulta y ejecución, el conector rechaza la orden.

## Comportamiento

- Se reconoce el modelo por identidad persistente obtenida de Revit: GUID de
  creación del documento local, GUID central de Revit Server cuando corresponde,
  o GUID de proyecto/modelo Autodesk. El ID de la apertura actual se verifica
  aparte. No se identifica automáticamente por nombre o ruta.
- Antes de modificar se validan todas las partidas asignadas y sus plantillas,
  parámetros y filtros, también contra el documento real. Una configuración
  inválida bloquea la operación completa.
- Se crean o reemplazan únicamente las tablas MYG marcadas del mismo proyecto,
  presupuesto y partida. Repetir no acumula duplicados. Las tablas manuales y las
  partidas no asignadas se conservan; no hay limpieza global de tablas.
- Se usa una transacción para todos los presupuestos. Un error revierte tanto
  tablas nuevas como reemplazos. Los conflictos de nombre se resuelven con un
  sufijo estable por presupuesto, o se rechazan si sigue existiendo conflicto.
- Los reemplazos regeneran las tablas a partir de su plantilla y filtros; los
  ajustes manuales de una tabla generada se deben incorporar a la plantilla.
  Se reponen las ubicaciones compatibles en láminas dentro de la misma
  transacción. Se rechazan las distribuciones especiales que no se pueden
  conservar con seguridad (tablas divididas, filtradas por lámina o instancias
  agrupadas/en cajetines). Si una tabla a reemplazar es la vista activa, abra
  primero una planta, vista 3D o lámina.
- **Usar en total** afecta las cantidades recibidas; desmarcarlo no quita la
  asignación ni impide crear su tabla. Este botón no importa metrados al
  presupuesto ni conecta directamente a servicios Autodesk: trabaja mediante
  Revit abierto y con sus permisos. La consulta/importación de metrados existente
  conserva su flujo anterior.

## Instalar la actualización en Windows

1. Cierre MYG y Revit. Respalde o confirme sus cambios locales antes de sustituir
   archivos. El ZIP contiene únicamente archivos nuevos/modificados y conserva
   sus rutas relativas; los existentes se entregan completos. Compare con su
   versión si tiene cambios posteriores al commit base.
2. Extraiga y copie el contenido en la raíz de su checkout de MYG.Presupuestos.
   No hay eliminaciones, migraciones SQL ni cambios de dependencias.
3. Con SDK .NET 10 y Revit 2027 instalado, desde esa raíz:

   ```powershell
   dotnet restore MYG.Presupuestos.sln
   dotnet build MYG.Presupuestos.sln -c Release --no-restore -m:1 -nr:false
   dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --tablas-activos-revit
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore -- --tablas-modelo-abierto
   .\scripts\Instalar-Conector.ps1 -Origen .\MYG.Revit2027\bin\Release\net10.0-windows
   ```

4. Inicie la aplicación de escritorio recién compilada y reinicie Revit para
   cargar el conector actualizado. Actualice **ambos** componentes y sus copias
   de MYG.Core; un conector anterior no proporciona la identidad necesaria.
   El script existente de instalación excluye las DLL de referencia RevitAPI.

## Validación

En Linux puede compilarse con referencias NuGet soportadas:

```bash
source /workspace/.cloud-setup/myg/activate.sh
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --tablas-activos-revit
```

Las pruebas del núcleo usan datos sintéticos y SQLite real. Comprueban primera
vinculación, persistencia JSON/SQLite, reabrir/renombrar, A/B, varios presupuestos,
inclusión de cantidades, filtros inválidos, conflictos de identidad, Autodesk y
protocolo. No ejecutan la API de Revit. Las pruebas de interfaz y la ejecución
real del conector necesitan Windows; compilarlas en Linux no las ejecuta.

Resultados de esta entrega con SDK .NET 10.0.100: solución completa Release
compilada con cero errores y cero advertencias; siete grupos focales aprobados y
suite del núcleo completada con **790 comprobaciones correctas**. Se omitieron
las muestras externas no suministradas y Named Pipes de Windows. Las pruebas UI
nuevas se compilaron, pero no se ejecutaron en Linux. La suite independiente de
nube tiene un fallo de diagnóstico de renovación de sesión ya reproducido antes
de esta entrega (`PublicacionLigeraCheck.cs:399`); no se modifica ni se presenta
como aprobada aquí.

Comprobación manual pendiente en Revit, sobre copias de modelos de prueba:

- Vincular A, cancelar y comprobar que no se crearon tablas; después confirmar.
- Repetir el botón y comprobar que el número de tablas no crece.
- Activar B, comprobar columnas/cimientos y verificar que las tablas ajenas se
  conservan, incluso si otra fila o presupuesto está seleccionado en MYG.
- Reabrir el modelo y la obra: deben reconocer el vínculo guardado.
- Incluir partidas de dos presupuestos con nombres de tabla coincidentes.
- Provocar plantilla o filtro inválido: ninguna tabla debe cambiar.
- Cambiar el documento activo durante la espera: la orden debe rechazarse.
- Comprobar ubicación/fijación/rotación de tablas ordinarias colocadas en láminas
  y el rechazo sin cambios de distribuciones especiales.
- Validar modelos Autodesk con los permisos del usuario y GUID reales.

## Límites de identidad y compatibilidad

Una copia física o determinados flujos de **Guardar como** pueden conservar la
identidad de creación del modelo. No trate esas copias como activos independientes
sin comprobar sus identidades: un documento con identidad ya vinculada pertenece
al mismo activo. Si su ruta coincide con la de otro activo local registrado, la
identidad compartida se considera un conflicto y la operación se bloquea sin
elegir un activo por la ruta. El sistema también bloquea una segunda vinculación
con esa identidad; no inventa una distinción por el nombre del archivo. Copias
no registradas con identidad compartida no se pueden distinguir automáticamente.
Modelos de bloques distintos
deben tener identidades de documento distintas.

Se conserva el formato del registro de activos existente; los nuevos campos del
protocolo son aditivos. No se cambian las bases de datos existentes fuera del
guardado habitual de la obra. El servicio de licencia y los permisos de edición
siguen siendo requisitos para enviar operaciones al conector.

Tras aplicar y validar, en Visual Studio revise **Cambios de Git**, confirme solo
los archivos de esta actualización y sus cambios deseados, haga Commit y luego
Push a su rama de trabajo (`main` si mantiene ese flujo). Compruebe el commit y la
rama en GitHub. Esta entrega no hace Push del repositorio del código.
