using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class TablasModeloAbiertoUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Tablas del modelo abierto", "Presupuesto sin selección de partidas");
        MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit
        { Nombre = "Bloque A", RutaLocal = @"C:\Modelos\Bloque A.rvt" });
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion);
        editor.Show(); Application.DoEvents();
        var botones = Descendientes(editor).OfType<Button>().Where(b => b.Name == "tablas_modelo_abierto_button").ToArray();
        exige(botones.Length == 1 && botones[0].AccessibleName == "Crear / actualizar tablas del modelo abierto" && botones[0].Image != null,
            "La obra debe ofrecer un único botón global de crear/actualizar tablas con nombre accesible e icono.");
        var boton = botones.Single();
        exige(!boton.Enabled && boton.Tag is true,
            "Crear tablas en Revit requiere una sesión autorizada, incluso sin seleccionar una partida.");
        string firma = MYGProyectoStorage.Firma(proyecto);
        try
        {
            var tarea = (Task)typeof(EditorForm).GetMethod("AplicarTablasModeloAbierto", Privados)!.Invoke(editor, null)!;
            tarea.GetAwaiter().GetResult();
            exige(false, "El acceso directo sin permiso debe rechazarse antes de consultar Revit.");
        }
        catch (InvalidOperationException)
        {
            exige(MYGProyectoStorage.Firma(proyecto) == firma,
                "Rechazar la creación sin permiso conserva activos, partidas e historial del documento.");
        }
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))!.SetValue(sesion,
            new CredencialMYG { Usuario = "prueba-local", Token = "token-sintetico-no-enviado" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, true);
        EstadoCinta(editor);
        exige(boton.Enabled,
            "Una sesión autorizada puede iniciar el flujo global sin seleccionar partidas en la estructura.");
        typeof(EditorForm).GetField("ocupado", Privados)!.SetValue(editor, true);
        EstadoCinta(editor);
        exige(!boton.Enabled, "El botón debe bloquearse mientras otra operación está en curso para evitar envíos dobles.");
        typeof(EditorForm).GetField("ocupado", Privados)!.SetValue(editor, false);
        EstadoCinta(editor);

        bool dialogoComprobado = false;
        Exception errorDialogo = null;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
        temporizador.Tick += (_, _) =>
        {
            var dialogo = Application.OpenForms.Cast<Form>().FirstOrDefault(f => f != editor &&
                f.Text.EndsWith("Vincular modelo abierto con un activo", StringComparison.Ordinal));
            if (dialogo == null) return;
            temporizador.Stop();
            try
            {
                var controles = Descendientes(dialogo).ToArray();
                var lista = controles.OfType<ComboBox>().Single();
                var aceptar = controles.OfType<Button>().Single(b => b.Text == "Vincular y continuar");
                exige(lista.SelectedIndex == -1 && !aceptar.Enabled,
                    "La primera vinculación exige elegir el activo explícitamente y no adivina por nombre o ruta.");
                lista.SelectedIndex = 0;
                exige(aceptar.Enabled, "Elegir el activo permite confirmar la vinculación inicial.");
                dialogoComprobado = true;
            }
            catch (Exception error) { errorDialogo = error; }
            finally { dialogo.DialogResult = DialogResult.Cancel; dialogo.Close(); }
        };
        temporizador.Start();
        var respuesta = typeof(EditorForm).GetMethod("ElegirVinculoModeloAbierto", Privados)!.Invoke(editor,
            new object[] { new DocumentoRevitInfo { Id = "sesion-sintetica", DocumentoRevitId = "documento-estable-prueba", Nombre = "Bloque A",
                Ruta = @"C:\Modelos\Bloque A.rvt", Origen = MYGOrigenActivoRevit.Local }, null });
        temporizador.Stop();
        if (errorDialogo != null) throw errorDialogo;
        exige(dialogoComprobado && respuesta == null && MYGProyectoStorage.Firma(proyecto) == firma,
            "Cancelar la primera vinculación conserva la obra y no envía una orden de creación a Revit.");
    }

    private static void EstadoCinta(EditorForm editor)
        => typeof(EditorForm).GetMethod("EstadoCintaPresupuestos", Privados)!.Invoke(editor, null);

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
