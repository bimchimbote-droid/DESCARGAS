using MYG.Externo;

namespace MYG_2027;

/// <summary>Prepara exclusivamente las tablas asignadas al modelo reconocido de una obra.</summary>
public static class MYGTablasActivosRevit
{
    private static bool Igual(string a, string b) => string.Equals(a?.Trim(), b?.Trim(), StringComparison.OrdinalIgnoreCase);
    private static string RutaLocal(string ruta) => string.IsNullOrWhiteSpace(ruta)
        ? null : ruta.Trim().Replace('\\', '/').TrimEnd('/');

    private static void ValidarDocumento(DocumentoRevitInfo documento)
    {
        if (documento == null || string.IsNullOrWhiteSpace(documento.Id) || string.IsNullOrWhiteSpace(documento.DocumentoRevitId))
            throw new InvalidDataException("El conector no informó la identidad persistente del modelo. Actualice el conector y vuelva a conectar Revit.");
        if (!Enum.IsDefined(documento.Origen) || (documento.Origen == MYGOrigenActivoRevit.Autodesk &&
            (string.IsNullOrWhiteSpace(documento.ProyectoAutodeskId) || string.IsNullOrWhiteSpace(documento.ModeloAutodeskId))))
            throw new InvalidDataException("La identidad del modelo Revit está incompleta.");
    }

    private static void ComprobarOrigen(MYGActivoRevit activo, DocumentoRevitInfo documento)
    {
        if (activo.Origen != documento.Origen || (activo.Origen == MYGOrigenActivoRevit.Autodesk &&
            (!Igual(activo.ProyectoAutodeskId, documento.ProyectoAutodeskId) || !Igual(activo.ModeloAutodeskId, documento.ModeloAutodeskId))))
            throw new InvalidDataException("El modelo abierto no corresponde al origen o a los identificadores Autodesk del activo.");
    }

    public static MYGActivoRevit ResolverActivo(MYGProyectoDocumento proyecto, DocumentoRevitInfo documento)
    {
        MYGActivosRevit.Validar(proyecto);
        ValidarDocumento(documento);
        var activo = proyecto.ActivosRevit?.Activos.SingleOrDefault(a => !string.IsNullOrWhiteSpace(a.DocumentoRevitId) &&
            Igual(a.DocumentoRevitId, documento.DocumentoRevitId));
        if (activo != null)
        {
            ComprobarOrigen(activo, documento);
            // Una copia RVT puede conservar la identidad de creación. Una ruta
            // registrada expresamente a otro activo evidencia esa contradicción;
            // bloqueamos el envío sin usar la ruta para elegir otro activo.
            string ruta = RutaLocal(documento.Ruta);
            if (activo.Origen == MYGOrigenActivoRevit.Local && ruta != null &&
                proyecto.ActivosRevit.Activos.Any(a => a.Origen == MYGOrigenActivoRevit.Local &&
                    !Igual(a.Id, activo.Id) && Igual(RutaLocal(a.RutaLocal), ruta)))
                throw new InvalidDataException("El modelo comparte una identidad Revit con otro activo, pero su ruta está registrada a un activo distinto. Revise las copias del modelo antes de aplicar tablas.");
        }
        // Una coincidencia de nombre, ruta o UUID cloud aún no acredita la
        // primera vinculación: el usuario debe confirmarla explícitamente.
        return activo;
    }

    public static MYGActivoRevit VincularDocumento(MYGProyectoDocumento proyecto, string activoId, DocumentoRevitInfo documento)
    {
        MYGActivosRevit.Validar(proyecto);
        ValidarDocumento(documento);
        var activo = proyecto.ActivosRevit?.Activos.SingleOrDefault(a => Igual(a.Id, activoId))
            ?? throw new InvalidDataException("Registre el activo en esta obra antes de vincular el modelo.");
        ComprobarOrigen(activo, documento);
        if (!string.IsNullOrWhiteSpace(activo.DocumentoRevitId) && !Igual(activo.DocumentoRevitId, documento.DocumentoRevitId))
            throw new InvalidDataException("Ese activo ya está vinculado a otro modelo Revit. Revise su registro antes de cambiar la vinculación.");
        var identificado = ResolverActivo(proyecto, documento);
        if (identificado != null && !Igual(identificado.Id, activo.Id))
            throw new InvalidDataException("El modelo abierto ya está vinculado a otro activo de la obra.");
        var copia = MYGProyectoStorage.Copia(activo);
        copia.DocumentoRevitId = documento.DocumentoRevitId.Trim();
        return MYGActivosRevit.GuardarActivo(proyecto, copia);
    }

    public static List<LoteTablasRevit> PrepararLotes(MYGProyectoDocumento proyecto, DocumentoRevitInfo documento)
    {
        var activo = ResolverActivo(proyecto, documento)
            ?? throw new InvalidDataException("Vincule primero el modelo abierto con uno de los activos de esta obra.");
        var lotes = new List<LoteTablasRevit>();
        foreach (var presupuesto in proyecto.Presupuestos)
        {
            var ids = proyecto.ActivosRevit.Asignaciones.Where(a => Igual(a.ActivoId, activo.Id) && Igual(a.PresupuestoId, presupuesto.Id))
                .Select(a => a.PartidaId).ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (ids.Count == 0) continue;
            var lote = new LoteTablasRevit { PresupuestoId = presupuesto.IdPresupuestoRevit };
            if (string.IsNullOrWhiteSpace(lote.PresupuestoId))
                throw new InvalidDataException("El presupuesto no tiene identidad de Revit. Guarde la obra antes de generar sus tablas.");
            foreach (var partida in presupuesto.Items.Where(i => ids.Contains(i.Id)))
            {
                ValidarConfiguracion(partida, documento);
                lote.Configuraciones.Add(Configuracion(partida));
            }
            lotes.Add(lote);
        }
        if (lotes.Count == 0) throw new InvalidDataException("El activo reconocido no tiene partidas asignadas en esta obra.");
        if (lotes.Select(l => l.PresupuestoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != lotes.Count)
            throw new InvalidDataException("Dos presupuestos comparten la misma identidad de Revit. Revise la obra antes de generar tablas.");
        return lotes;
    }

    private static void ValidarConfiguracion(ItemPresupuestoDelphin partida, DocumentoRevitInfo documento)
    {
        string contexto = "La partida «" + (partida.Item + " " + partida.Descripcion).Trim() + "» ";
        if (string.IsNullOrWhiteSpace(partida.Plantilla) || documento.Plantillas?.Any(p => Igual(p, partida.Plantilla)) != true)
            throw new InvalidDataException(contexto + "necesita una plantilla disponible en el modelo abierto.");
        if (partida.Filtros?.Any(f => f == null) == true)
            throw new InvalidDataException(contexto + "contiene un filtro inválido.");
        var filtros = MYGBibliotecaPartidas.FiltrosGuardables(partida);
        if (filtros.Count > 8) throw new InvalidDataException(contexto + "supera el máximo de ocho filtros.");
        foreach (var filtro in filtros.Where(f => !f.EstaVacio()))
        {
            if (string.IsNullOrWhiteSpace(filtro.Parametro) || string.IsNullOrWhiteSpace(filtro.Regla))
                throw new InvalidDataException(contexto + "tiene un filtro sin parámetro o regla.");
            bool sinValor = new[] { "parámetro existe", "tiene valor", "no tiene valor" }.Any(r => Igual(r, filtro.Regla));
            if (!sinValor && string.IsNullOrWhiteSpace(filtro.Valor))
                throw new InvalidDataException(contexto + "tiene un filtro cuya regla necesita un valor.");
            // INFO enumera los campos ya presentes en la plantilla. Revit puede
            // añadir otros campos programables durante su preflight real; su
            // ausencia en esta instantánea no demuestra que sean inválidos.
            if (documento.Reglas.TryGetValue(partida.Plantilla.Trim(), out var reglas) &&
                reglas.TryGetValue(filtro.Parametro.Trim(), out var aplicables) && aplicables?.Count > 0 &&
                !aplicables.Any(r => Igual(r, filtro.Regla)))
                throw new InvalidDataException(contexto + "usa una regla no compatible con el parámetro «" + filtro.Parametro + "».");
        }
    }

    private static ConfiguracionTablaPlanificacion Configuracion(ItemPresupuestoDelphin i) => new()
    {
        IdInterno = i.Id, ParentId = i.ParentId, IdInternoDelphin = i.IdInternoDelphin, IdLocalMYG = i.IdLocalMYG,
        IdPropuesta = i.IdPropuesta, IdAnalisisDelphin = i.IdAnalisisDelphin, IdCatalogoDelphin = i.IdCatalogoDelphin,
        FuenteCatalogoId = i.FuenteCatalogoId, FuenteCatalogoRuta = i.FuenteCatalogoRuta, CodigoCatalogoDelphin = i.CodigoCatalogoDelphin,
        CodigoDelphin = i.CodigoDelphin, IdConfiguracionBibliotecaMYG = i.IdConfiguracionBibliotecaMYG,
        Item = i.Item, Partida = i.Descripcion, Unidad = i.Unidad, Plantilla = i.Plantilla.Trim(),
        Filtros = MYGBibliotecaPartidas.FiltrosGuardables(i), Estado = i.Estado, Origen = i.Origen, TipoPropuesta = i.TipoPropuesta,
        Posicion = i.Posicion, PartidaOriginal = i.PartidaOriginal, UnidadOriginal = i.UnidadOriginal,
        PartidaPropuesta = i.PartidaPropuesta, UnidadPropuesta = i.UnidadPropuesta
    };
}
