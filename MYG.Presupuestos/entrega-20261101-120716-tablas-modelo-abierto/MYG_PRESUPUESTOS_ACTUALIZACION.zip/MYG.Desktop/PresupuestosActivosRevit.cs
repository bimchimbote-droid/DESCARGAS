using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private void GestionarActivosRevit()
    {
        Sincronizar();
        using var ventana = new MYGActivosRevitForm(documento, PuedeModificarProyecto);
        if (ventana.ShowDialog(this) != DialogResult.OK) return;
        Recordar();
        documento.ActivosRevit = MYGProyectoStorage.Copia(ventana.Resultado);
        Refrescar();
    }
}

internal sealed partial class MYGPanelPresupuesto
{
    private Func<MYGProyectoDocumento> obtenerProyectoActivosRevit;
    private Action gestionarActivosRevit;
    private readonly DataGridView asignacionesRevit = Tabla();
    private readonly Label resumenAsignacionesRevit = new() { Dock = DockStyle.Bottom, Height = 42,
        TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true, Padding = new Padding(5) };
    private bool cargandoAsignacionesRevit;

    internal void InicializarActivosRevit(Func<MYGProyectoDocumento> obtenerProyecto, Action gestionar)
    {
        obtenerProyectoActivosRevit = obtenerProyecto;
        gestionarActivosRevit = gestionar;
        CargarAsignacionesRevit();
    }

    private TabControl PrepararActivosMetradosRevit(Panel resultados)
    {
        var paginas = new TabControl { Name = "activos_y_resultados_revit", Dock = DockStyle.Fill };
        var asignados = new TabPage("Activos asignados") { Padding = new Padding(0) };
        var recibidos = new TabPage("Metrados recibidos") { Padding = new Padding(0) };
        paginas.TabPages.AddRange(new[] { asignados, recibidos });
        recibidos.Controls.Add(resultados);
        asignados.Controls.Add(asignacionesRevit);
        asignados.Controls.Add(resumenAsignacionesRevit);
        asignados.Controls.Add(Barra(
            Boton("Asignar activos…", AsignarActivosPartidaRevit),
            Boton("Quitar asignación", QuitarAsignacionPartidaRevit),
            Boton("Activos de la obra…", () => gestionarActivosRevit?.Invoke())));
        asignacionesRevit.Name = "activos_asignados_revit";
        asignacionesRevit.ReadOnly = false;
        asignacionesRevit.AllowUserToAddRows = asignacionesRevit.AllowUserToDeleteRows = false;
        var incluir = new DataGridViewCheckBoxColumn { Name = "INCLUIR", HeaderText = "Usar en total", Width = 85 };
        asignacionesRevit.Columns.Add(incluir);
        Columna(asignacionesRevit, "ACTIVO", "Activo de la obra", 190);
        Columna(asignacionesRevit, "ORIGEN", "Origen", 120);
        Columna(asignacionesRevit, "ESTADO", "Estado", 240);
        asignacionesRevit.Columns["ESTADO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        asignacionesRevit.Columns["ESTADO"].MinimumWidth = 190;
        asignacionesRevit.CurrentCellDirtyStateChanged += (_, _) =>
        {
            if (asignacionesRevit.IsCurrentCellDirty)
                asignacionesRevit.CommitEdit(DataGridViewDataErrorContexts.Commit);
        };
        asignacionesRevit.CellValueChanged += (_, e) =>
        {
            if (cargando || cargandoAsignacionesRevit || e.RowIndex < 0 || e.ColumnIndex != incluir.Index) return;
            Intentar(() =>
            {
                var fila = asignacionesRevit.Rows[e.RowIndex];
                if (fila.Tag is not MYGAsignacionActivoRevit asignacion) return;
                ExigirEdicionActivosRevit(); ExigirPermisoMetradosExcel();
                bool valor = Convert.ToBoolean(fila.Cells["INCLUIR"].Value);
                if (valor == asignacion.IncluirEnTotal) return;
                antes();
                MYGActivosRevit.CambiarInclusion(obtenerProyectoActivosRevit(), P.Id, PartidaActual.Id, asignacion.ActivoId, valor);
                CargarDetalle(); Cambiado();
            });
            CargarAsignacionesRevit();
        };
        MYGTemaPestanas.Preparar(paginas);
        return paginas;
    }

    private void ExigirEdicionActivosRevit()
    {
        RequerirPartida();
        if (!EdicionNubePermitida) throw new InvalidOperationException("El proyecto está disponible solo para lectura.");
        RequerirPermisoCatalogos();
        if (obtenerProyectoActivosRevit?.Invoke() == null)
            throw new InvalidOperationException("No se ha cargado la obra de los activos.");
    }

    private void CargarAsignacionesRevit()
    {
        if (cargandoAsignacionesRevit) return;
        cargandoAsignacionesRevit = true;
        try
        {
            asignacionesRevit.Rows.Clear();
            var proyecto = obtenerProyectoActivosRevit?.Invoke();
            var partida = HayPartida ? PartidaActual : null;
            var registro = proyecto?.ActivosRevit;
            var asignaciones = registro?.Asignaciones.Where(a => a.PresupuestoId == P?.Id && a.PartidaId == partida?.Id).ToList()
                ?? new List<MYGAsignacionActivoRevit>();
            foreach (var asignacion in asignaciones)
            {
                var activo = registro.Activos.FirstOrDefault(a => a.Id == asignacion.ActivoId);
                if (activo == null) continue;
                bool recibido = partida.Costos.MetradosBIM.Any(m => m.ActivoId == activo.Id);
                string estado = recibido ? (string.IsNullOrWhiteSpace(activo.DocumentoRevitId)
                    ? "Metrado recibido; origen pendiente de verificar" : "Metrado recibido; consultar fecha")
                    : string.IsNullOrWhiteSpace(activo.DocumentoRevitId) ? "Pendiente de vincular modelo" : "Vinculado; aplicar tablas del modelo abierto";
                var fila = asignacionesRevit.Rows[asignacionesRevit.Rows.Add(asignacion.IncluirEnTotal, activo.Nombre,
                    activo.Origen == MYGOrigenActivoRevit.Local ? "Archivo local" : "Nube Autodesk", estado)];
                fila.Tag = asignacion;
                fila.Cells["ACTIVO"].ToolTipText = activo.Id;
                fila.Cells["ORIGEN"].ToolTipText = activo.Origen == MYGOrigenActivoRevit.Local ? activo.RutaLocal
                    : $"Proyecto: {activo.ProyectoAutodeskId}\nModelo: {activo.ModeloAutodeskId}";
            }
            asignacionesRevit.ReadOnly = partida == null || !EdicionMetradosExcelNubePermitida;
            resumenAsignacionesRevit.Text = partida == null ? "Seleccione una partida para asignar activos."
                : asignaciones.Count == 0 ? "Sin activos asignados. Registre los modelos de la obra y seleccione dónde aplicar esta partida."
                : $"{asignaciones.Count} activo(s) asignado(s). Registrar o asignar no conecta con Autodesk ni genera tablas. La inclusión se aplica a resultados vinculados por ID.";
        }
        finally { cargandoAsignacionesRevit = false; }
    }

    private void AsignarActivosPartidaRevit()
    {
        FinalizarEdicion();
        ExigirEdicionActivosRevit();
        ExigirPermisoMetradosExcel();
        var proyecto = obtenerProyectoActivosRevit();
        var activos = proyecto.ActivosRevit?.Activos;
        if (activos == null || activos.Count == 0)
        {
            gestionarActivosRevit?.Invoke();
            proyecto = obtenerProyectoActivosRevit();
            activos = proyecto.ActivosRevit?.Activos;
            if (activos == null || activos.Count == 0) return;
        }
        var asignados = proyecto.ActivosRevit.Asignaciones.Where(a => a.PresupuestoId == P.Id && a.PartidaId == PartidaActual.Id)
            .Select(a => a.ActivoId).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var disponibles = activos.Where(a => !asignados.Contains(a.Id)).ToList();
        if (disponibles.Count == 0) { MessageBox.Show(this, "Todos los activos de la obra ya están asignados a esta partida.", "Metrados Revit"); return; }
        using var dialogo = new Form();
        MYGProyectoUI.Preparar(dialogo, "Asignar activos a la partida", 640, 420);
        var lista = new CheckedListBox { Dock = DockStyle.Fill, CheckOnClick = true, IntegralHeight = false };
        foreach (var activo in disponibles) lista.Items.Add($"{activo.Nombre} · {(activo.Origen == MYGOrigenActivoRevit.Local ? "Local" : "Autodesk")}");
        var aceptar = MYGProyectoUI.Boton("Asignar seleccionados");
        aceptar.DialogResult = DialogResult.OK;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        var botones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 46, FlowDirection = FlowDirection.RightToLeft };
        botones.Controls.Add(cancelar); botones.Controls.Add(aceptar);
        dialogo.Controls.Add(lista); dialogo.Controls.Add(botones);
        dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
        MYG2027_TemaComercial.Aplicar(dialogo);
        if (dialogo.ShowDialog(this) != DialogResult.OK || lista.CheckedIndices.Count == 0) return;
        ExigirEdicionActivosRevit();
        antes();
        foreach (int indice in lista.CheckedIndices)
        {
            var asignacion = MYGActivosRevit.Asignar(proyecto, P.Id, PartidaActual.Id, disponibles[indice].Id);
            // Asignar un modelo no reactiva cantidades que el usuario había excluido.
            bool incluir = !PartidaActual.Costos.MetradosBIM.Any(m => m.ActivoId == asignacion.ActivoId && m.ExcluirDelTotal);
            MYGActivosRevit.CambiarInclusion(proyecto, P.Id, PartidaActual.Id, asignacion.ActivoId, incluir);
        }
        CargarDetalle(); Cambiado();
    }

    private void QuitarAsignacionPartidaRevit()
    {
        FinalizarEdicion(); ExigirEdicionActivosRevit();
        if (asignacionesRevit.CurrentRow?.Tag is not MYGAsignacionActivoRevit asignacion) return;
        if (MessageBox.Show(this, "¿Quitar esta asignación? Los metrados ya recibidos se conservan en la pestaña Metrados recibidos.",
            "Metrados Revit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        antes();
        MYGActivosRevit.QuitarAsignacion(obtenerProyectoActivosRevit(), P.Id, PartidaActual.Id, asignacion.ActivoId);
        CargarDetalle(); Cambiado();
    }

    private void PrepararInclusionResultadosRevit()
    {
        var incluir = new DataGridViewCheckBoxColumn { Name = "INCLUIR", HeaderText = "Usar en total", Width = 85 };
        bim.Columns.Insert(0, incluir);
        bim.ReadOnly = false;
        bim.CurrentCellDirtyStateChanged += (_, _) =>
        {
            if (bim.IsCurrentCellDirty) bim.CommitEdit(DataGridViewDataErrorContexts.Commit);
        };
        bim.CellValueChanged += (_, e) =>
        {
            if (cargando || e.RowIndex < 0 || e.ColumnIndex != incluir.Index) return;
            Intentar(() =>
            {
                if (bim.Rows[e.RowIndex].Tag is not MYGMetradoBIM resultado) return;
                ExigirEdicionActivosRevit(); ExigirPermisoMetradosExcel();
                bool usar = Convert.ToBoolean(bim.Rows[e.RowIndex].Cells["INCLUIR"].Value);
                if (usar == !resultado.ExcluirDelTotal) return;
                antes(); resultado.ExcluirDelTotal = !usar;
                var proyecto = obtenerProyectoActivosRevit();
                if (proyecto.ActivosRevit?.Asignaciones.Any(a => a.PresupuestoId == P.Id && a.PartidaId == PartidaActual.Id && a.ActivoId == resultado.ActivoId) == true)
                    MYGActivosRevit.CambiarInclusion(proyecto, P.Id, PartidaActual.Id, resultado.ActivoId, usar);
                CargarDetalle(); Cambiado();
            });
            CargarDetalle();
        };
    }
}
