using System.Security.Cryptography;
using System.Text;
using MYG.Externo;
using RevitDB = Autodesk.Revit.DB;
using RevitUI = Autodesk.Revit.UI;

namespace MYG_2027;

public partial class TablasAutomaticasExternalHandler
{
    private sealed class TablaActivoPendiente
    {
        internal string PresupuestoId;
        internal ConfiguracionTablaPlanificacion Configuracion;
        internal string Nombre;
        internal RevitDB.ElementId PlantillaId;
        internal List<RevitDB.ElementId> Reemplazar = new();
        internal List<UbicacionTablaActivo> Ubicaciones = new();
    }

    private sealed class UbicacionTablaActivo
    {
        internal RevitDB.ElementId HojaId;
        internal RevitDB.XYZ Punto;
        internal RevitDB.ViewportRotation Rotacion;
        internal bool Fijada;
    }

    /// <summary>Sincroniza exclusivamente las asignaciones recibidas, sin limpieza global.</summary>
    private RespuestaRevit AplicarTablasActivo(RevitUI.UIDocument uidoc, SolicitudRevit solicitud)
    {
        var doc = uidoc.Document;
        var respuesta = new RespuestaRevit { Id = solicitud.Id, Ok = false };
        var planes = new List<TablaActivoPendiente>();
        var tablas = new RevitDB.FilteredElementCollector(doc)
            .OfClass(typeof(RevitDB.ViewSchedule)).Cast<RevitDB.ViewSchedule>()
            .Where(t => !t.IsTemplate).ToList();
        var nombresNuevos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var fuentes = new HashSet<long>();

        foreach (var lote in solicitud.LotesTablas)
        {
            var claves = lote.Configuraciones.Select(ClaveMarcaActivo).ToList();
            if (claves.Any(string.IsNullOrWhiteSpace) || claves.Distinct(StringComparer.OrdinalIgnoreCase).Count() != claves.Count)
                throw new InvalidOperationException("Las partidas del presupuesto deben tener identidades BIM únicas antes de crear sus tablas.");
            // Los índices antiguos están limitados a un presupuesto. Se reinician
            // entre lotes para impedir que una marca se atribuya a otro ámbito.
            ReiniciarCachesEjecucionRapida();
            ProjectId = solicitud.ProyectoId;
            ProjectName = solicitud.ProyectoNombre;
            PresupuestoIdActual = lote.PresupuestoId;
            var resultados = ValidarConfiguracionesRevit(uidoc, lote.Configuraciones);
            respuesta.Resultados.AddRange(resultados);
            if (resultados.Count != lote.Configuraciones.Count || resultados.Any(r => !r.PuedeSincronizar))
            {
                respuesta.Mensaje = "No se modificó ninguna tabla. Revise las plantillas y filtros de las partidas asignadas al activo.";
                return respuesta;
            }
            var marcadas = ObtenerTablasMYG2027DelPresupuesto(tablas, solicitud.ProyectoId, lote.PresupuestoId);
            foreach (var cfg in lote.Configuraciones)
            {
                // Se usa la misma precedencia que la marca Extensible Storage existente.
                string clave = ClaveMarcaActivo(cfg);
                var plan = new TablaActivoPendiente
                {
                    PresupuestoId = lote.PresupuestoId,
                    Configuracion = cfg,
                    Nombre = ConstruirNombreTablaBase(cfg.Item, cfg.Partida),
                    PlantillaId = tablas.Single(t => string.Equals(t.Name.Trim(), cfg.Plantilla.Trim(), StringComparison.OrdinalIgnoreCase)).Id,
                    Reemplazar = marcadas.Where(t => string.Equals(ObtenerPartidaKeyTablaMYG2027(t), clave?.Trim(), StringComparison.OrdinalIgnoreCase))
                        .Select(t => t.Id).ToList()
                };
                fuentes.Add(plan.PlantillaId.Value);
                planes.Add(plan);
            }
        }

        var reemplazar = planes.SelectMany(p => p.Reemplazar).Distinct().ToList();
        var idsReemplazar = reemplazar.Select(id => id.Value).ToHashSet();
        if (fuentes.Overlaps(idsReemplazar))
            throw new InvalidOperationException("Una tabla que debe actualizarse también está configurada como plantilla. Elija una plantilla independiente antes de continuar.");

        var ubicaciones = new RevitDB.FilteredElementCollector(doc)
            .OfClass(typeof(RevitDB.ScheduleSheetInstance)).Cast<RevitDB.ScheduleSheetInstance>()
            .Where(i => idsReemplazar.Contains(i.ScheduleId.Value)).ToList();
        foreach (var plan in planes)
        {
            foreach (var id in plan.Reemplazar)
            {
                var anterior = (RevitDB.ViewSchedule)doc.GetElement(id);
                // Una plantilla nueva no acredita conservar las divisiones ni
                // los filtros específicos de cada lámina. Se conserva el modelo
                // completo hasta que el usuario prepare una tabla compatible.
                if (anterior.GetSegmentCount() > 1 || anterior.Definition.IsFilteredBySheet)
                    throw new InvalidOperationException("La tabla '" + anterior.Name
                        + "' está dividida en segmentos o filtrada por lámina. Esta actualización automática no modifica esas tablas; conserve su distribución y actualícela por separado.");
                foreach (var ubicacion in ubicaciones.Where(i => i.ScheduleId.Value == id.Value))
                {
                    if (ubicacion.IsTitleblockRevisionSchedule || ubicacion.GroupId != RevitDB.ElementId.InvalidElementId)
                        throw new InvalidOperationException("Una tabla está colocada en un cajetín o grupo. No se modificó ninguna tabla para conservar esa colocación.");
                    plan.Ubicaciones.Add(new UbicacionTablaActivo
                    {
                        HojaId = ubicacion.OwnerViewId,
                        Punto = ubicacion.Point,
                        Rotacion = ubicacion.Rotation,
                        Fijada = ubicacion.Pinned
                    });
                }
            }
        }

        // Las tablas manuales y las de otros ámbitos se conservan. Un sufijo de
        // presupuesto resuelve nombres iguales entre presupuestos de la obra.
        var ocupados = tablas.Where(t => !idsReemplazar.Contains(t.Id.Value))
            .Select(t => t.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var basesRepetidas = planes.GroupBy(p => p.Nombre, StringComparer.OrdinalIgnoreCase)
            .Where(g => g.Count() > 1).Select(g => g.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var plan in planes)
        {
            if (basesRepetidas.Contains(plan.Nombre) || ocupados.Contains(plan.Nombre))
            {
                string sufijo = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(plan.PresupuestoId))).Substring(0, 12);
                plan.Nombre += " (MYG " + sufijo + ")";
            }
            if (ocupados.Contains(plan.Nombre) || !nombresNuevos.Add(plan.Nombre))
                throw new InvalidOperationException("El nombre de tabla '" + plan.Nombre + "' ya está en uso. Cambie el ítem o la descripción de la partida; se conservaron las tablas existentes.");
        }
        if (uidoc.ActiveView != null && idsReemplazar.Contains(uidoc.ActiveView.Id.Value))
            throw new InvalidOperationException("La vista activa es una tabla que debe actualizarse. Abra una planta, una vista 3D o una lámina y vuelva a pulsar el botón.");

        // Una sola transacción abarca todos los presupuestos. Ante cualquier
        // fallo se revierten tanto los reemplazos como las tablas recién creadas.
        using var transaccion = new RevitDB.Transaction(doc, "MYG - Tablas del activo del modelo abierto");
        try
        {
            if (transaccion.Start() != RevitDB.TransactionStatus.Started)
                throw new InvalidOperationException("No se pudo iniciar la actualización de tablas del activo.");
            if (reemplazar.Count > 0) doc.Delete(reemplazar);
            var schema = ObtenerOCrearSchemaMYG2027();
            foreach (var plan in planes)
            {
                var plantilla = doc.GetElement(plan.PlantillaId) as RevitDB.ViewSchedule
                    ?? throw new InvalidOperationException("La plantilla dejó de estar disponible.");
                var id = plantilla.Duplicate(RevitDB.ViewDuplicateOption.Duplicate);
                var tabla = doc.GetElement(id) as RevitDB.ViewSchedule
                    ?? throw new InvalidOperationException("Revit no devolvió la tabla creada.");
                tabla.Name = plan.Nombre;
                for (int f = tabla.Definition.GetFilterCount() - 1; f >= 0; f--) tabla.Definition.RemoveFilter(f);
                AplicarFiltrosConfiguracionRevit(doc, tabla, plan.Configuracion);
                MarcarTablaComoMYG2027(tabla, schema, plan.Configuracion, solicitud.ProyectoId, plan.PresupuestoId);
                foreach (var ubicacion in plan.Ubicaciones)
                {
                    var instancia = RevitDB.ScheduleSheetInstance.Create(doc, ubicacion.HojaId, tabla.Id, ubicacion.Punto);
                    instancia.Rotation = ubicacion.Rotacion;
                    instancia.Pinned = ubicacion.Fijada;
                }
            }
            if (transaccion.Commit() != RevitDB.TransactionStatus.Committed)
                throw new InvalidOperationException("Revit no confirmó la actualización de las tablas del activo.");
        }
        catch
        {
            if (transaccion.GetStatus() == RevitDB.TransactionStatus.Started) transaccion.RollBack();
            throw;
        }
        finally { ReiniciarCachesEjecucionRapida(); }

        respuesta.Ok = true;
        foreach (var resultado in respuesta.Resultados)
            resultado.Mensaje = "Tabla del activo creada o actualizada en Revit.";
        respuesta.Mensaje = planes.Count + " tablas creadas o actualizadas para el modelo abierto, en "
            + solicitud.LotesTablas.Count + " presupuestos. Las demás partidas y tablas se conservaron.";
        return respuesta;
    }

    private static string ClaveMarcaActivo(ConfiguracionTablaPlanificacion configuracion) =>
        (!string.IsNullOrWhiteSpace(configuracion.IdInternoDelphin) ? configuracion.IdInternoDelphin
            : !string.IsNullOrWhiteSpace(configuracion.IdPropuesta) ? configuracion.IdPropuesta : configuracion.IdInterno)?.Trim();
}
