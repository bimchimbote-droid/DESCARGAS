using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Globalization;
using System.Text.RegularExpressions;
using RevitUI = Autodesk.Revit.UI;
using RevitDB = Autodesk.Revit.DB;

namespace MYG_2027
{
    // =======================================
    // METRADOS POR ACTIVO / FEDERACION
    // =======================================
    public class MetradoPartidaActivo
    {
        public string ClavePartida { get; set; }
        public string IdInternoDelphin { get; set; }
        public string IdPropuesta { get; set; }
        public string Item { get; set; }
        public string Partida { get; set; }
        public string Unidad { get; set; }
        public double Metrado { get; set; }
        public string TablaPlanificacion { get; set; }
        public string Advertencia { get; set; }
    }

    public class MetradoActivoSnapshot
    {
        public int VersionFormato { get; set; } = 1;
        public string Proyecto { get; set; }
        // Opcionales para mantener la lectura de snapshots anteriores.
        public string ProyectoId { get; set; }
        public string PresupuestoId { get; set; }
        public string ActivoId { get; set; }
        public string ArchivoRvt { get; set; }
        public DateTime FechaUtc { get; set; }
        public List<MetradoPartidaActivo> Partidas { get; set; } =
            new List<MetradoPartidaActivo>();
        public List<string> Advertencias { get; set; } =
            new List<string>();
    }

    // Handler sincronizado con MYG_2027_TablasAutomaticas.cs.
    // Incluye la cola necesaria para cargar los valores dinámicos de FILTRO.
    public partial class TablasAutomaticasExternalHandler :
        RevitUI.IExternalEventHandler
    {
        public MYG.Externo.RespuestaRevit ProcesarExterno(RevitUI.UIApplication app, MYG.Externo.SolicitudRevit solicitud)
        {
            ReiniciarCachesEjecucionRapida();
            var uidoc = app.ActiveUIDocument;
            if (uidoc == null) throw new InvalidOperationException("No hay un modelo activo en Revit.");
            if (solicitud.Accion == "APLICAR_ACTIVO")
                return AplicarTablasActivo(uidoc, solicitud);
            ConfiguracionesTablas = solicitud.Configuraciones;
            ProjectId = solicitud.ProyectoId; ProjectName = solicitud.ProyectoNombre;
            PresupuestoIdActual = solicitud.PresupuestoId;
            var respuesta = new MYG.Externo.RespuestaRevit { Id = solicitud.Id, Ok = true };
            if (solicitud.Accion == "VALORES")
            {
                PlantillaParametrosRevitCache.CargarValores(uidoc.Document, solicitud.Plantilla, solicitud.Parametro);
                respuesta.Valores = PlantillaParametrosRevitCache.ObtenerValores(solicitud.Plantilla, solicitud.Parametro);
                return respuesta;
            }
            if (solicitud.Accion == "METRADO")
            {
                string carpeta = Path.Combine(Path.GetTempPath(), "MYG_Metrado_" + Guid.NewGuid().ToString("N"));
                string destino = Path.Combine(carpeta, "activo.json");
                try
                {
                    ExportarMetradoActivo(uidoc.Document, ConfiguracionesTablas,
                        solicitud.ActivoId, carpeta, destino, false);
                    respuesta.MetradoJson = File.ReadAllText(destino, Encoding.UTF8);
                    respuesta.Mensaje = "Metrado del activo consultado.";
                    return respuesta;
                }
                finally
                {
                    try { if (Directory.Exists(carpeta)) Directory.Delete(carpeta, true); } catch { }
                }
            }
            var resultados = ValidarConfiguracionesRevit(uidoc, ConfiguracionesTablas);
            respuesta.Resultados = resultados;
            if (solicitud.Accion == "CREAR")
                CrearTablasPlanificacion(uidoc, ConfiguracionesTablas, resultados);
            else if (solicitud.Accion == "ACTUALIZAR")
            {
                ActualizarTablaIndividualPendiente = true; ConfiguracionesTablasIndividuales = ConfiguracionesTablas;
                ResultadoActualizacionIndividualCallback = r => respuesta.Resultados = r;
                Execute(app);
            }
            respuesta.Mensaje = solicitud.Accion == "REVISAR" ? "Revisión completada." :
                "Operación procesada en Revit. Consulte los resultados y el resumen mostrado en Revit.";
            return respuesta;
        }

        public string SQLitePath { get; set; }
        public string ProjectId { get; set; }
        public string ProjectName { get; set; }

        // Presupuesto seleccionado actualmente en el editor.
        // Se usa como ámbito de sincronización para no tocar
        // tablas MYG_2027 de otros presupuestos.
        public string PresupuestoIdActual { get; set; }

        public bool CrearTablasPendiente { get; set; }

        // =======================================
        // ACTUALIZAR UNA SOLA TABLA
        //
        // Se procesa en un flujo independiente para que la actualización
        // de una partida NO ejecute la limpieza/sincronización global
        // de todas las tablas del presupuesto.
        // =======================================
        public bool ActualizarTablaIndividualPendiente { get; set; }

        public ConfiguracionTablaPlanificacion
            ConfiguracionTablaIndividual
        { get; set; }

        // NUEVO:
        // permite actualizar un conjunto exacto de tablas seleccionadas
        // sin ejecutar la sincronización global del presupuesto.
        public List<ConfiguracionTablaPlanificacion>
            ConfiguracionesTablasIndividuales
        { get; set; } =
            new List<ConfiguracionTablaPlanificacion>();

        public Action<List<ResultadoValidacionRevitPartida>>
            ResultadoActualizacionIndividualCallback
        { get; set; }

        // Revisión previa contra el documento Revit real.
        // Puede ejecutarse sola (REVISAR REVIT) o inmediatamente antes
        // de sincronizar (CREAR TABLAS).
        public bool ValidarTablasRevitPendiente { get; set; }
        public bool CrearDespuesDeValidarRevit { get; set; }

        public Action<List<ResultadoValidacionRevitPartida>>
            ResultadosValidacionRevitCallback
        { get; set; }

        // =======================================
        // REFRESCAR PLANTILLAS DESDE LA VENTANA
        //
        // La ventana es modeless, por lo que no debe consultar la API de
        // Revit directamente desde el Click. Esta bandera hace que la lectura
        // se ejecute dentro del ExternalEvent y luego devuelve la lista nueva
        // mediante callback sin cerrar ni reconstruir toda la ventana.
        // =======================================
        public bool RefrescarPlantillasPendiente { get; set; }

        public Action<List<string>>
            PlantillasRevitRefrescadasCallback
        { get; set; }

        public bool ExportarMetradoActivoPendiente { get; set; }
        public string ActivoIdExportacion { get; set; }
        public string CarpetaExportacionMetrados { get; set; }

        // Ruta exacta seleccionada en Guardar como.
        public string ArchivoExportacionMetrado { get; set; }

        // Las lecturas de valores deben ejecutarse dentro del contexto
        // válido de la API de Revit. Una cola evita que dos clics rápidos
        // sobrescriban la solicitud anterior.
        private class SolicitudValoresFiltro
        {
            public string Plantilla { get; set; }
            public string Parametro { get; set; }
            public Action Callback { get; set; }
        }

        private readonly object _lockSolicitudesValores =
            new object();

        private readonly Queue<SolicitudValoresFiltro>
            _solicitudesValores =
                new Queue<SolicitudValoresFiltro>();

        public void EncolarCargaValoresFiltro(
            string plantilla,
            string parametro,
            Action callback)
        {
            if (string.IsNullOrWhiteSpace(
                    plantilla) ||
                string.IsNullOrWhiteSpace(
                    parametro))
            {
                callback?.Invoke();
                return;
            }

            lock (_lockSolicitudesValores)
            {
                _solicitudesValores.Enqueue(
                    new SolicitudValoresFiltro()
                    {
                        Plantilla =
                            plantilla.Trim(),

                        Parametro =
                            parametro.Trim(),

                        Callback =
                            callback
                    });
            }
        }

        public void DescartarCargaValoresFiltro(
            string plantilla,
            string parametro)
        {
            if (string.IsNullOrWhiteSpace(
                    plantilla) ||
                string.IsNullOrWhiteSpace(
                    parametro))
            {
                return;
            }

            lock (_lockSolicitudesValores)
            {
                List<SolicitudValoresFiltro> restantes =
                    _solicitudesValores
                        .Where(
                            x =>
                                !(
                                    string.Equals(
                                        x.Plantilla,
                                        plantilla,
                                        StringComparison.OrdinalIgnoreCase) &&
                                    string.Equals(
                                        x.Parametro,
                                        parametro,
                                        StringComparison.OrdinalIgnoreCase)
                                 ))
                        .ToList();

                _solicitudesValores.Clear();

                foreach (
                    SolicitudValoresFiltro solicitud
                    in restantes)
                {
                    _solicitudesValores.Enqueue(
                        solicitud);
                }
            }
        }

        public List<ConfiguracionTablaPlanificacion>
            ConfiguracionesTablas
        { get; set; } =
                new List<ConfiguracionTablaPlanificacion>();

        // Categorías reales disponibles en el documento activo de Revit.
        public List<string> PlantillasRevit { get; set; } =
            new List<string>();


        // =======================================
        // CACHE DE REVISION / INDICES DE APOYO
        //
        // Objetivo: evitar repetir consultas costosas a Revit cuando
        // el usuario pulsa REVISAR REVIT y luego CREAR TABLAS sin
        // modificar la configuración BIM.
        //
        // Los índices de tipos se reconstruyen al iniciar una revisión
        // nueva; no se persisten entre documentos.
        // =======================================
        private string _ultimaFirmaValidacionRevit =
            null;

        private string _ultimoDocumentoValidacionRevit =
            null;

        private List<ResultadoValidacionRevitPartida>
            _ultimosResultadosValidacionRevit =
                null;

        private readonly Dictionary<long, Dictionary<string, RevitDB.ElementId>>
            _indiceTiposPorCategoria =
                new Dictionary<long, Dictionary<string, RevitDB.ElementId>>();

        private readonly Dictionary<string, RevitDB.StorageType>
            _storageTypeCampoCache =
                new Dictionary<string, RevitDB.StorageType>(
                    StringComparer.OrdinalIgnoreCase);

        // =======================================
        // CACHÉS DE RENDIMIENTO - SOLO DURANTE UN EXECUTE
        //
        // No cambian ninguna regla de creación/validación.
        // Únicamente evitan volver a pedir a Revit la misma información
        // varias veces dentro de la misma ejecución.
        // =======================================
        private List<RevitDB.ElementId>
            _idsViewScheduleEjecucionCache =
                null;

        private bool
            _indicesTiposTodasCategoriasConstruidos =
                false;

        private Autodesk.Revit.DB.ExtensibleStorage.Schema
            _schemaMYGLecturaCache =
                null;

        private Autodesk.Revit.DB.ExtensibleStorage.Field
            _schemaFieldCreadoPorCache =
                null;

        private Autodesk.Revit.DB.ExtensibleStorage.Field
            _schemaFieldProjectIdCache =
                null;

        private Autodesk.Revit.DB.ExtensibleStorage.Field
            _schemaFieldPresupuestoIdCache =
                null;

        private Autodesk.Revit.DB.ExtensibleStorage.Field
            _schemaFieldPartidaKeyCache =
                null;

        private readonly Dictionary<long, string>
            _partidaKeyTablaEjecucionCache =
                new Dictionary<long, string>();

        private readonly Dictionary<long, bool>
            _esTablaMYGPresupuestoEjecucionCache =
                new Dictionary<long, bool>();

        public void Execute(
            RevitUI.UIApplication app)
        {
            try
            {
                ReiniciarCachesEjecucionRapida();

                bool procesoValores =
                    ProcesarSolicitudesValores(
                        app);

                // Una solicitud de valores no debe disparar las demás
                // tareas generales del handler. Si coincidió con Crear o
                // Exportar, esas tareas sí continúan en esta ejecución.
                if (procesoValores &&
                    !ExportarMetradoActivoPendiente &&
                    !CrearTablasPendiente &&
                    !ActualizarTablaIndividualPendiente &&
                    !ValidarTablasRevitPendiente &&
                    !RefrescarPlantillasPendiente)
                {
                    return;
                }

                // =======================================
                // REFRESCAR PLANTILLAS DE REVIT
                // =======================================
                if (RefrescarPlantillasPendiente)
                {
                    RefrescarPlantillasPendiente =
                        false;

                    RevitUI.UIDocument uidoc =
                        app?.ActiveUIDocument;

                    if (uidoc == null)
                    {
                        try
                        {
                            PlantillasRevitRefrescadasCallback
                                ?.Invoke(
                                    new List<string>());
                        }
                        catch
                        {
                        }

                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas",
                            "No existe un documento activo de Revit.");

                        return;
                    }

                    try
                    {
                        // 1. Volver a leer las tablas cuyo nombre empieza por
                        //    PLANTILLA directamente del documento actual.
                        CargarPlantillasRevit(
                            uidoc.Document);

                        // 2. Volver a leer los campos/reglas de cada plantilla.
                        //    Este método también vacía la caché de VALORES para
                        //    que se vuelvan a consultar bajo demanda.
                        PlantillaParametrosRevitCache.Cargar(
                            uidoc.Document);

                        // 3. Una plantilla nueva o modificada puede cambiar el
                        //    resultado de una revisión anterior. Invalidamos
                        //    solamente las cachés de revisión; no tocamos la
                        //    configuración BIM del usuario.
                        _ultimaFirmaValidacionRevit =
                            null;

                        _ultimoDocumentoValidacionRevit =
                            null;

                        _ultimosResultadosValidacionRevit =
                            null;

                        ReiniciarIndicesRapidosRevit();

                        List<string> plantillasActualizadas =
                            new List<string>(
                                PlantillasRevit ??
                                new List<string>());

                        try
                        {
                            PlantillasRevitRefrescadasCallback
                                ?.Invoke(
                                    plantillasActualizadas);
                        }
                        catch
                        {
                        }
                    }
                    catch (Exception ex)
                    {
                        // Devolver al menos la lista que siga disponible para
                        // que la ventana restaure el botón aun si Revit falla.
                        try
                        {
                            PlantillasRevitRefrescadasCallback
                                ?.Invoke(
                                    new List<string>(
                                        PlantillasRevit ??
                                        new List<string>()));
                        }
                        catch
                        {
                        }

                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas - Refrescar plantillas",
                            "No se pudieron actualizar las plantillas de Revit.\n\n" +
                            ex.Message);
                    }

                    return;
                }

                if (ExportarMetradoActivoPendiente)
                {
                    ExportarMetradoActivoPendiente = false;

                    RevitUI.UIDocument uidoc =
                        app.ActiveUIDocument;

                    if (uidoc == null)
                    {
                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas",
                            "No existe un documento activo de Revit.");
                        return;
                    }

                    ExportarMetradoActivo(
                        uidoc.Document,
                        ConfiguracionesTablas,
                        ActivoIdExportacion,
                        CarpetaExportacionMetrados,
                        ArchivoExportacionMetrado);

                    return;
                }

                // =======================================
                // ACTUALIZAR SOLO LAS TABLAS SELECCIONADAS
                //
                // 1 fila  -> conserva el comportamiento individual anterior.
                // 2 o más -> procesa exclusivamente esas tablas, una por una,
                //           cada una con su propia Transaction de protección.
                //
                // NO ejecuta limpieza/sincronización global.
                // NO toca tablas que no fueron seleccionadas.
                // =======================================
                if (ActualizarTablaIndividualPendiente)
                {
                    ActualizarTablaIndividualPendiente =
                        false;

                    List<ConfiguracionTablaPlanificacion> objetivos =
                        (ConfiguracionesTablasIndividuales ??
                         new List<ConfiguracionTablaPlanificacion>())
                            .Where(
                                x =>
                                    x != null)
                            .ToList();

                    // Compatibilidad con versiones anteriores de la ventana.
                    if (objetivos.Count == 0 &&
                        ConfiguracionTablaIndividual != null)
                    {
                        objetivos.Add(
                            ConfiguracionTablaIndividual);
                    }

                    ConfiguracionesTablasIndividuales =
                        new List<ConfiguracionTablaPlanificacion>();

                    ConfiguracionTablaIndividual =
                        null;

                    RevitUI.UIDocument uidoc =
                        app?.ActiveUIDocument;

                    var resultados =
                        new List<ResultadoValidacionRevitPartida>();

                    if (uidoc == null)
                    {
                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas",
                            "No existe un documento activo de Revit.");

                        try
                        {
                            ResultadoActualizacionIndividualCallback
                                ?.Invoke(
                                    resultados);
                        }
                        catch
                        {
                        }

                        return;
                    }

                    if (objetivos.Count == 0)
                    {
                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas",
                            "No se recibieron tablas seleccionadas para actualizar.");

                        try
                        {
                            ResultadoActualizacionIndividualCallback
                                ?.Invoke(
                                    resultados);
                        }
                        catch
                        {
                        }

                        return;
                    }

                    bool modoMultiple =
                        objetivos.Count > 1;

                    System.Diagnostics.Stopwatch relojTotalSeleccion =
                        System.Diagnostics.Stopwatch.StartNew();

                    // Los índices rápidos se reinician una sola vez para
                    // todo el lote seleccionado.
                    ReiniciarIndicesRapidosRevit();

                    foreach (
                        ConfiguracionTablaPlanificacion cfg
                        in objetivos)
                    {
                        ResultadoValidacionRevitPartida resultado =
                            new ResultadoValidacionRevitPartida()
                            {
                                ClavePartida =
                                    ObtenerClaveConfiguracion(
                                        cfg),

                                Estado =
                                    "LISTO",

                                Mensaje =
                                    modoMultiple
                                    ? "Actualización seleccionada rápida."
                                    : "Actualización individual rápida."
                            };

                        resultados.Add(
                            resultado);

                        try
                        {
                            ActualizarTablaPlanificacionIndividual(
                                uidoc,
                                cfg,
                                resultado,
                                ConfiguracionesTablas,
                                relojTotalSeleccion,
                                !modoMultiple,
                                !modoMultiple);

                            if (!resultado.PuedeSincronizar &&
                                !modoMultiple)
                            {
                                if (relojTotalSeleccion.IsRunning)
                                {
                                    relojTotalSeleccion.Stop();
                                }

                                RevitUI.TaskDialog.Show(
                                    "Actualizar tabla",
                                    "La tabla seleccionada no se modificó.\n\n" +
                                    (resultado.Mensaje ??
                                     "Revisa la columna REVIT.") +
                                    "\n\nTiempo total: " +
                                    relojTotalSeleccion.Elapsed.TotalSeconds.ToString(
                                        "0.0",
                                        CultureInfo.InvariantCulture) +
                                    " s");
                            }
                        }
                        catch (Exception ex)
                        {
                            AgregarErrorResultadoRevit(
                                resultado,
                                "No se pudo actualizar la tabla seleccionada: " +
                                ex.Message);

                            // En modo múltiple un error aislado NO cancela
                            // las demás tablas seleccionadas.
                            if (!modoMultiple)
                            {
                                RevitUI.TaskDialog.Show(
                                    "Actualizar tabla - Error",
                                    ex.Message);
                            }
                        }
                    }

                    if (relojTotalSeleccion.IsRunning)
                    {
                        relojTotalSeleccion.Stop();
                    }

                    if (modoMultiple)
                    {
                        int listas =
                            resultados.Count(
                                x =>
                                    x != null &&
                                    string.Equals(
                                        x.Estado,
                                        "LISTO",
                                        StringComparison.OrdinalIgnoreCase));

                        int alertas =
                            resultados.Count(
                                x =>
                                    x != null &&
                                    string.Equals(
                                        x.Estado,
                                        "ALERTA",
                                        StringComparison.OrdinalIgnoreCase));

                        int errores =
                            resultados.Count(
                                x =>
                                    x != null &&
                                    string.Equals(
                                        x.Estado,
                                        "ERROR",
                                        StringComparison.OrdinalIgnoreCase));

                        RevitUI.TaskDialog.Show(
                            "Actualizar tablas",
                            "Actualización selectiva completada.\n\n" +
                            "Tablas seleccionadas: " +
                            objetivos.Count +
                            "\nActualizadas correctamente: " +
                            listas +
                            "\nCon alerta / conservadas: " +
                            alertas +
                            "\nCon error / conservadas: " +
                            errores +
                            "\n\nTiempo total: " +
                            relojTotalSeleccion.Elapsed.TotalSeconds.ToString(
                                "0.0",
                                CultureInfo.InvariantCulture) +
                            " s" +
                            "\n\nNo se procesaron las demás tablas del presupuesto.");
                    }

                    try
                    {
                        ResultadoActualizacionIndividualCallback
                            ?.Invoke(
                                resultados);
                    }
                    catch
                    {
                    }

                    return;
                }


                if (ValidarTablasRevitPendiente)
                {
                    ValidarTablasRevitPendiente =
                        false;

                    bool crearDespues =
                        CrearDespuesDeValidarRevit;

                    CrearDespuesDeValidarRevit =
                        false;

                    RevitUI.UIDocument uidoc =
                        app.ActiveUIDocument;

                    if (uidoc == null)
                    {
                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas",
                            "No existe un documento activo de Revit.");

                        ResultadosValidacionRevitCallback
                            ?.Invoke(
                                new List<ResultadoValidacionRevitPartida>());

                        return;
                    }

                    List<ResultadoValidacionRevitPartida> resultados;

                    // Medición REAL del proceso completo que ocurre cuando
                    // CREAR TABLAS primero solicita la revisión y después
                    // ejecuta la sincronización.
                    System.Diagnostics.Stopwatch relojProcesoCompleto =
                        crearDespues
                        ? System.Diagnostics.Stopwatch.StartNew()
                        : null;

                    System.Diagnostics.Stopwatch relojValidacion =
                        System.Diagnostics.Stopwatch.StartNew();

                    bool validacionDesdeCache =
                        false;

                    // Si el usuario acaba de pulsar REVISAR REVIT y luego
                    // CREAR TABLAS sin tocar la configuración BIM, reutilizar
                    // esa revisión. Esto evita ejecutar dos veces el bloque
                    // más costoso del proceso.
                    if (crearDespues &&
                        IntentarObtenerValidacionRevitCache(
                            uidoc.Document,
                            ConfiguracionesTablas,
                            out resultados))
                    {
                        validacionDesdeCache =
                            true;
                    }
                    else
                    {
                        resultados =
                            ValidarConfiguracionesRevit(
                                uidoc,
                                ConfiguracionesTablas);

                        GuardarValidacionRevitCache(
                            uidoc.Document,
                            ConfiguracionesTablas,
                            resultados);
                    }

                    relojValidacion.Stop();

                    if (crearDespues)
                    {
                        CrearTablasPlanificacion(
                            uidoc,
                            ConfiguracionesTablas,
                            resultados,
                            relojProcesoCompleto,
                            relojValidacion.Elapsed,
                            validacionDesdeCache);
                    }
                    else
                    {
                        MostrarResumenRevisionRevit(
                            resultados);
                    }

                    try
                    {
                        ResultadosValidacionRevitCallback
                            ?.Invoke(
                                resultados);
                    }
                    catch
                    {
                    }

                    return;
                }

                if (CrearTablasPendiente)
                {
                    CrearTablasPendiente = false;

                    RevitUI.UIDocument uidoc =
                        app.ActiveUIDocument;

                    if (uidoc == null)
                    {
                        RevitUI.TaskDialog.Show(
                            "Tablas Automáticas",
                            "No existe un documento activo de Revit.");
                        return;
                    }

                    CrearTablasPlanificacion(
                        uidoc,
                        ConfiguracionesTablas);

                    return;
                }

                if (string.IsNullOrWhiteSpace(SQLitePath))
                {
                    RevitUI.TaskDialog.Show(
                        "Tablas Automáticas",
                        "No se seleccionó una base SQLite.");
                    return;
                }

                if (!File.Exists(SQLitePath))
                {
                    RevitUI.TaskDialog.Show(
                        "Tablas Automáticas",
                        "La base SQLite seleccionada ya no existe.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(ProjectId))
                {
                    RevitUI.TaskDialog.Show(
                        "Tablas Automáticas",
                        "No se seleccionó un proyecto.");
                    return;
                }

                RevitUI.TaskDialog.Show(
                    "Tablas Automáticas",
                    "Proyecto seleccionado:\n\n" +
                    ProjectName +
                    "\n\nID Proyecto:\n" +
                    ProjectId);
            }
            catch (Exception ex)
            {
                RevitUI.TaskDialog.Show(
                    "Tablas Automáticas - Error",
                    ex.ToString());
            }
        }

        private bool ProcesarSolicitudesValores(
            RevitUI.UIApplication app)
        {
            var solicitudes =
                new List<SolicitudValoresFiltro>();

            lock (_lockSolicitudesValores)
            {
                while (_solicitudesValores.Count > 0)
                {
                    solicitudes.Add(
                        _solicitudesValores.Dequeue());
                }
            }

            if (solicitudes.Count == 0)
                return false;

            RevitUI.UIDocument uidoc =
                app?.ActiveUIDocument;

            foreach (
                SolicitudValoresFiltro solicitud
                in solicitudes)
            {
                try
                {
                    if (uidoc != null)
                    {
                        PlantillaParametrosRevitCache
                            .CargarValores(
                                uidoc.Document,
                                solicitud.Plantilla,
                                solicitud.Parametro);
                    }
                }
                catch
                {
                }
                finally
                {
                    try
                    {
                        solicitud.Callback
                            ?.Invoke();
                    }
                    catch
                    {
                    }
                }
            }

            return true;
        }

        // =======================================
        // EXPORTAR / ACTUALIZAR METRADO DE UN ACTIVO
        // =======================================
        private void ExportarMetradoActivo(
            RevitDB.Document doc,
            List<ConfiguracionTablaPlanificacion> configuraciones,
            string activoId,
            string carpeta,
            string archivoDestino,
            bool mostrarResumen = true)
        {
            if (doc == null)
                throw new InvalidOperationException(
                    "No existe documento activo.");

            if (string.IsNullOrWhiteSpace(activoId))
                throw new InvalidOperationException(
                    "No se indicó el ID/nombre del activo.");

            if (string.IsNullOrWhiteSpace(carpeta))
                throw new InvalidOperationException(
                    "No se indicó la carpeta de metrados.");

            Directory.CreateDirectory(carpeta);

            System.Diagnostics.Stopwatch relojTotalActivo =
                System.Diagnostics.Stopwatch.StartNew();

            System.Diagnostics.Stopwatch relojPreparacionActivo =
                System.Diagnostics.Stopwatch.StartNew();

            var snapshot =
                new MetradoActivoSnapshot()
                {
                    Proyecto =
                        ProjectName ?? doc.Title,

                    ProyectoId = ProjectId,
                    PresupuestoId = PresupuestoIdActual,

                    ActivoId =
                        activoId.Trim(),

                    ArchivoRvt =
                        string.IsNullOrWhiteSpace(doc.PathName)
                        ? doc.Title
                        : doc.PathName,

                    FechaUtc =
                        DateTime.UtcNow
                };

            List<ConfiguracionTablaPlanificacion> configs =
                (configuraciones ??
                 new List<ConfiguracionTablaPlanificacion>())
                .Where(
                    x =>
                        x != null &&
                        !string.Equals(
                            x.Estado,
                            "PROP. ELIMINAR",
                            StringComparison.OrdinalIgnoreCase) &&
                        !string.IsNullOrWhiteSpace(x.Plantilla))
                .ToList();

            // =======================================
            // ÍNDICE ÚNICO DE TABLAS
            //
            // Antes se creaba un FilteredElementCollector completo por
            // cada partida exportada. Para 100 partidas eran 100 lecturas
            // globales del documento. Ahora Revit se consulta una sola vez.
            // =======================================
            List<RevitDB.ViewSchedule> tablasDisponibles =
                new RevitDB.FilteredElementCollector(
                    doc)
                    .OfClass(
                        typeof(RevitDB.ViewSchedule))
                    .Cast<RevitDB.ViewSchedule>()
                    .Where(
                        x =>
                            x != null &&
                            !x.IsTemplate &&
                            !string.IsNullOrWhiteSpace(
                                x.Name))
                    .ToList();

            Dictionary<string, RevitDB.ViewSchedule>
                tablasPorNombreExacto =
                    tablasDisponibles
                        .GroupBy(
                            x =>
                                x.Name,
                            StringComparer.OrdinalIgnoreCase)
                        .ToDictionary(
                            g => g.Key,
                            g => g.First(),
                            StringComparer.OrdinalIgnoreCase);

            // =======================================
            // ÍNDICE ÚNICO DE VERSIONES
            //
            // Antes, si no existía el nombre exacto, cada partida volvía
            // a recorrer TODAS las tablas para buscar "Nombre (2)",
            // "Nombre (3)", etc. Ahora ese trabajo se hace una sola vez.
            //
            // Se conserva exactamente la prioridad anterior:
            // 1) nombre exacto;
            // 2) si no existe, mayor versión numérica.
            // =======================================
            var tablasVersionadasPorBase =
                new Dictionary<string, RevitDB.ViewSchedule>(
                    StringComparer.OrdinalIgnoreCase);

            var numeroVersionPorBase =
                new Dictionary<string, int>(
                    StringComparer.OrdinalIgnoreCase);

            Regex regexVersionTabla =
                new Regex(
                    @"^(.*) \((\d+)\)$",
                    RegexOptions.Compiled);

            foreach (
                RevitDB.ViewSchedule tabla
                in tablasDisponibles)
            {
                string nombre =
                    tabla?.Name ?? "";

                Match match =
                    regexVersionTabla.Match(
                        nombre);

                if (!match.Success)
                {
                    continue;
                }

                string nombreBaseVersion =
                    match.Groups[1].Value;

                if (string.IsNullOrWhiteSpace(
                        nombreBaseVersion) ||
                    !int.TryParse(
                        match.Groups[2].Value,
                        out int numeroVersion))
                {
                    continue;
                }

                if (!numeroVersionPorBase.TryGetValue(
                        nombreBaseVersion,
                        out int versionActual) ||
                    numeroVersion > versionActual)
                {
                    numeroVersionPorBase[
                        nombreBaseVersion] =
                            numeroVersion;

                    tablasVersionadasPorBase[
                        nombreBaseVersion] =
                            tabla;
                }
            }

            // Si dos configuraciones terminan apuntando a la misma tabla,
            // Revit se consulta una sola vez. El valor resultante es idéntico
            // porque ObtenerMetradoSchedule no modifica la tabla.
            var metradosLeidos =
                new Dictionary<long, double>();

            var advertenciasLeidas =
                new Dictionary<long, string>();

            relojPreparacionActivo.Stop();

            System.Diagnostics.Stopwatch relojLecturaTablas =
                System.Diagnostics.Stopwatch.StartNew();

            foreach (
                ConfiguracionTablaPlanificacion cfg
                in configs)
            {
                string clave =
                    !string.IsNullOrWhiteSpace(
                        cfg.IdInternoDelphin)
                    ? cfg.IdInternoDelphin
                    : (
                        !string.IsNullOrWhiteSpace(
                            cfg.IdPropuesta)
                        ? cfg.IdPropuesta
                        : cfg.IdInterno
                      );

                string nombreBase =
                    ConstruirNombreTablaBase(
                        cfg.Item,
                        cfg.Partida);

                RevitDB.ViewSchedule schedule =
                    tablasPorNombreExacto.TryGetValue(
                        nombreBase,
                        out RevitDB.ViewSchedule tablaExacta)
                    ? tablaExacta
                    : (
                        tablasVersionadasPorBase.TryGetValue(
                            nombreBase,
                            out RevitDB.ViewSchedule tablaVersionada)
                        ? tablaVersionada
                        : null
                      );

                if (schedule == null)
                {
                    snapshot.Advertencias.Add(
                        (cfg.Item ?? "") +
                        " " +
                        (cfg.Partida ?? "") +
                        ": no se encontró tabla de planificación.");

                    continue;
                }

                string advertencia;
                double metrado;

                long scheduleId =
                    schedule.Id.Value;

                if (metradosLeidos.TryGetValue(
                        scheduleId,
                        out double metradoCache))
                {
                    metrado =
                        metradoCache;

                    advertenciasLeidas.TryGetValue(
                        scheduleId,
                        out advertencia);
                }
                else
                {
                    metrado =
                        ObtenerMetradoSchedule(
                            schedule,
                            cfg.Unidad,
                            out advertencia);

                    metradosLeidos[
                        scheduleId] =
                            metrado;

                    advertenciasLeidas[
                        scheduleId] =
                            advertencia;
                }

                if (!string.IsNullOrWhiteSpace(
                        advertencia))
                {
                    snapshot.Advertencias.Add(
                        (cfg.Item ?? "") +
                        " " +
                        (cfg.Partida ?? "") +
                        ": " +
                        advertencia);

                    // Si no pudimos leer correctamente el TOTAL
                    // GENERAL, no agregamos una cantidad inventada.
                    continue;
                }

                snapshot.Partidas.Add(
                    new MetradoPartidaActivo()
                    {
                        ClavePartida =
                            clave,

                        IdInternoDelphin =
                            cfg.IdInternoDelphin,

                        IdPropuesta =
                            cfg.IdPropuesta,

                        Item =
                            cfg.Item,

                        Partida =
                            cfg.Partida,

                        Unidad =
                            cfg.Unidad,

                        Metrado =
                            metrado,

                        TablaPlanificacion =
                            schedule.Name,

                        Advertencia =
                            null
                    });
            }

            relojLecturaTablas.Stop();

            System.Diagnostics.Stopwatch relojEscrituraActivo =
                System.Diagnostics.Stopwatch.StartNew();

            string archivo =
                !string.IsNullOrWhiteSpace(
                    archivoDestino)
                ? archivoDestino
                : Path.Combine(
                    carpeta,
                    "MYG_METRADO_" +
                    SanitizarNombreArchivoMetrado(
                        activoId) +
                    ".json");

            string carpetaArchivo =
                Path.GetDirectoryName(
                    archivo);

            if (!string.IsNullOrWhiteSpace(
                    carpetaArchivo))
            {
                Directory.CreateDirectory(
                    carpetaArchivo);
            }

            string json =
                JsonSerializer.Serialize(
                    snapshot,
                    new JsonSerializerOptions()
                    {
                        WriteIndented = true
                    });

            File.WriteAllText(
                archivo,
                json,
                new UTF8Encoding(false));

            relojEscrituraActivo.Stop();
            relojTotalActivo.Stop();

            if (mostrarResumen)
                RevitUI.TaskDialog.Show(
                    "Tablas Automáticas",
                    "Metrado del activo actualizado.\n\n" +
                    "Activo: " +
                    snapshot.ActivoId +
                    "\nPartidas exportadas: " +
                    snapshot.Partidas.Count +
                    "\nAdvertencias: " +
                    snapshot.Advertencias.Count +
                    "\n\nTIEMPOS:" +
                    "\nTiempo total real: " +
                    relojTotalActivo.Elapsed.TotalSeconds.ToString(
                        "0.0",
                        CultureInfo.InvariantCulture) +
                    " s" +
                    "\nPreparación / índices: " +
                    relojPreparacionActivo.Elapsed.TotalSeconds.ToString(
                        "0.0",
                        CultureInfo.InvariantCulture) +
                    " s" +
                    "\nLectura de tablas Revit: " +
                    relojLecturaTablas.Elapsed.TotalSeconds.ToString(
                        "0.0",
                        CultureInfo.InvariantCulture) +
                    " s" +
                    "\nEscritura JSON: " +
                    relojEscrituraActivo.Elapsed.TotalSeconds.ToString(
                        "0.0",
                        CultureInfo.InvariantCulture) +
                    " s" +
                    "\n\n" +
                    archivo);
        }

        private RevitDB.ViewSchedule
            BuscarTablaMetradoMasReciente(
                IEnumerable<RevitDB.ViewSchedule> tablas,
                string nombreBase)
        {
            if (tablas == null ||
                string.IsNullOrWhiteSpace(nombreBase))
            {
                return null;
            }

            return
                tablas
                    .Where(
                        x =>
                            x != null &&
                            !x.IsTemplate &&
                            EsNombreTablaDePartida(
                                x.Name,
                                nombreBase))
                    .OrderByDescending(
                        x =>
                            ObtenerNumeroVersionNombre(
                                x.Name,
                                nombreBase))
                    .FirstOrDefault();
        }

        private bool EsNombreTablaDePartida(
            string nombre,
            string nombreBase)
        {
            if (string.Equals(
                    nombre,
                    nombreBase,
                    StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (string.IsNullOrWhiteSpace(nombre))
                return false;

            if (!nombre.StartsWith(
                    nombreBase + " (",
                    StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            return
                Regex.IsMatch(
                    nombre,
                    @" \(\d+\)$");
        }

        private int ObtenerNumeroVersionNombre(
            string nombre,
            string nombreBase)
        {
            if (string.Equals(
                    nombre,
                    nombreBase,
                    StringComparison.OrdinalIgnoreCase))
            {
                return 1;
            }

            Match match =
                Regex.Match(
                    nombre ?? "",
                    @" \((\d+)\)$");

            if (match.Success &&
                int.TryParse(
                    match.Groups[1].Value,
                    out int numero))
            {
                return numero;
            }

            return 0;
        }

        private double ObtenerMetradoSchedule(
            RevitDB.ViewSchedule schedule,
            string unidad,
            out string advertencia)
        {
            advertencia =
                null;

            if (schedule == null)
            {
                advertencia =
                    "Tabla no válida.";

                return 0.0;
            }

            try
            {
                RevitDB.TableData tableData =
                    schedule.GetTableData();

                RevitDB.TableSectionData body =
                    tableData.GetSectionData(
                        RevitDB.SectionType.Body);

                if (body == null ||
                    body.NumberOfRows <= 0 ||
                    body.NumberOfColumns <= 0)
                {
                    // La tabla EXISTE pero actualmente no contiene
                    // elementos. Para federación eso significa
                    // metrado válido igual a 0.
                    advertencia =
                        null;

                    return 0.0;
                }

                // =======================================
                // ESTRATEGIA MYG
                //
                // La tabla ya viene filtrada para UNA partida.
                // El metrado válido es el TOTAL GENERAL visible
                // al final de la tabla.
                //
                // Buscamos desde abajo hacia arriba:
                // 1. La última fila que contenga datos.
                // 2. Dentro de esa fila, desde la derecha hacia
                //    la izquierda, el último valor numérico válido.
                //
                // En las plantillas MYG ese valor corresponde al
                // TOTAL GENERAL mostrado por Revit.
                // =======================================

                int filaInicial =
                    body.FirstRowNumber;

                int filaFinal =
                    body.LastRowNumber;

                int columnaInicial =
                    body.FirstColumnNumber;

                int columnaFinal =
                    body.LastColumnNumber;

                // -------------------------------------------------
                // LECTURA RÁPIDA:
                //
                // El TOTAL GENERAL de las plantillas MYG está al final.
                // El código anterior primero recorría TODAS las filas y
                // TODAS las columnas buscando literalmente el texto
                // "TOTAL GENERAL". Si Revit no mostraba ese rótulo, luego
                // repetía todo el recorrido para buscar el número.
                //
                // Empezar directamente desde abajo produce el mismo valor
                // que ya utilizaba ese fallback, normalmente leyendo solo
                // una fila y unas pocas celdas.
                // -------------------------------------------------
                for (
                    int row = filaFinal;
                    row >= filaInicial;
                    row--)
                {
                    if (TryObtenerUltimoNumeroFila(
                            schedule,
                            row,
                            columnaInicial,
                            columnaFinal,
                            out double totalFila))
                    {
                        return
                            totalFila;
                    }
                }

                // La tabla existe pero no contiene actualmente
                // ningún valor numérico en el cuerpo. Se considera
                // metrado cero, no un error.
                advertencia =
                    null;

                return 0.0;
            }
            catch (Exception ex)
            {
                advertencia =
                    "Error leyendo TOTAL GENERAL: " +
                    ex.Message;

                return 0.0;
            }
        }

        private bool TryObtenerUltimoNumeroFila(
            RevitDB.ViewSchedule schedule,
            int row,
            int columnaInicial,
            int columnaFinal,
            out double valor)
        {
            valor =
                0.0;

            // Recorremos de derecha a izquierda porque el TOTAL
            // GENERAL de las plantillas MYG está al extremo derecho.
            for (
                int col = columnaFinal;
                col >= columnaInicial;
                col--)
            {
                string texto;

                try
                {
                    texto =
                        schedule.GetCellText(
                            RevitDB.SectionType.Body,
                            row,
                            col);
                }
                catch
                {
                    continue;
                }

                if (string.IsNullOrWhiteSpace(
                    texto))
                {
                    continue;
                }

                if (TryParseNumeroMetrado(
                        texto,
                        out double numero))
                {
                    valor =
                        numero;

                    return true;
                }
            }

            return false;
        }

        // =======================================
        // CONVERTIR NUMERO DE TABLA REVIT
        //
        // IMPORTANTE:
        // NO usar CurrentCulture como primer intento.
        //
        // Ejemplo del problema:
        // Revit muestra: 482710.51
        // Windows ES puede interpretar "." como miles
        // y producir:   48271051
        //
        // Esta rutina identifica primero cuál separador
        // representa DECIMALES y cuáles son agrupadores.
        //
        // Soporta, entre otros:
        // 482710.51
        // 482710,51
        // 1,234,567.89
        // 1.234.567,89
        // 482 710,51
        // =======================================
        private bool TryParseNumeroMetrado(
            string texto,
            out double valor)
        {
            valor =
                0.0;

            if (string.IsNullOrWhiteSpace(
                texto))
            {
                return false;
            }


            // Extraer solamente el primer bloque numérico.
            Match match =
                Regex.Match(
                    texto,
                    @"[-+]?\d[\d\s\u00A0\u202F'.,]*");

            if (!match.Success)
                return false;


            string numero =
                match.Value
                    .Trim()
                    .Replace(
                        "\u00A0",
                        "")
                    .Replace(
                        "\u202F",
                        "")
                    .Replace(
                        " ",
                        "")
                    .Replace(
                        "'",
                        "");


            if (string.IsNullOrWhiteSpace(
                numero))
            {
                return false;
            }


            int ultimaComa =
                numero.LastIndexOf(',');

            int ultimoPunto =
                numero.LastIndexOf('.');


            // ===================================
            // CASO 1:
            // existen PUNTO y COMA.
            //
            // El último separador es el decimal.
            // El anterior funciona como agrupador.
            // ===================================
            if (ultimaComa >= 0 &&
                ultimoPunto >= 0)
            {
                if (ultimoPunto >
                    ultimaComa)
                {
                    // 1,234,567.89
                    numero =
                        numero.Replace(
                            ",",
                            "");
                }
                else
                {
                    // 1.234.567,89
                    numero =
                        numero.Replace(
                            ".",
                            "");

                    numero =
                        numero.Replace(
                            ",",
                            ".");
                }

                return
                    double.TryParse(
                        numero,
                        NumberStyles.Float |
                        NumberStyles.AllowLeadingSign,
                        CultureInfo.InvariantCulture,
                        out valor);
            }


            // ===================================
            // CASO 2:
            // solamente COMA.
            // ===================================
            if (ultimaComa >= 0)
            {
                numero =
                    NormalizarSeparadorUnico(
                        numero,
                        ',');

                return
                    double.TryParse(
                        numero,
                        NumberStyles.Float |
                        NumberStyles.AllowLeadingSign,
                        CultureInfo.InvariantCulture,
                        out valor);
            }


            // ===================================
            // CASO 3:
            // solamente PUNTO.
            //
            // Este es precisamente el caso:
            // 482710.51
            // ===================================
            if (ultimoPunto >= 0)
            {
                numero =
                    NormalizarSeparadorUnico(
                        numero,
                        '.');

                return
                    double.TryParse(
                        numero,
                        NumberStyles.Float |
                        NumberStyles.AllowLeadingSign,
                        CultureInfo.InvariantCulture,
                        out valor);
            }


            // ===================================
            // CASO 4:
            // número entero.
            // ===================================
            return
                double.TryParse(
                    numero,
                    NumberStyles.Integer |
                    NumberStyles.AllowLeadingSign,
                    CultureInfo.InvariantCulture,
                    out valor);
        }


        private string NormalizarSeparadorUnico(
            string numero,
            char separador)
        {
            if (string.IsNullOrWhiteSpace(
                numero))
            {
                return numero;
            }


            int cantidad =
                numero.Count(
                    c =>
                        c == separador);


            if (cantidad <= 0)
                return numero;


            int ultimaPosicion =
                numero.LastIndexOf(
                    separador);

            int decimales =
                numero.Length -
                ultimaPosicion -
                1;


            // ===================================
            // UN SOLO SEPARADOR
            //
            // En metrados de Revit un único "." o ","
            // seguido de 1 a 6 dígitos se considera
            // separador decimal.
            //
            // Ej:
            // 482710.51
            // 125,375
            // ===================================
            if (cantidad == 1)
            {
                if (decimales >= 1 &&
                    decimales <= 6)
                {
                    if (separador == ',')
                    {
                        return
                            numero.Replace(
                                ",",
                                ".");
                    }

                    return
                        numero;
                }

                // Sin decimales razonables:
                // tratar como agrupador.
                return
                    numero.Replace(
                        separador.ToString(),
                        "");
            }


            // ===================================
            // VARIOS SEPARADORES IGUALES
            //
            // Ejemplo agrupación pura:
            // 1,234,567
            //
            // Si TODAS las agrupaciones posteriores
            // tienen exactamente 3 dígitos, se trata
            // como separador de miles.
            // ===================================
            string signo =
                "";

            string cuerpo =
                numero;

            if (cuerpo.StartsWith(
                "-") ||
                cuerpo.StartsWith(
                    "+"))
            {
                signo =
                    cuerpo.Substring(
                        0,
                        1);

                cuerpo =
                    cuerpo.Substring(
                        1);
            }


            string[] partes =
                cuerpo.Split(
                    separador);


            bool todasAgrupacionesTres =
                partes.Length > 1 &&
                partes
                    .Skip(1)
                    .All(
                        p =>
                            p.Length == 3);


            if (todasAgrupacionesTres)
            {
                return
                    signo +
                    string.Concat(
                        partes);
            }


            // Si el último grupo NO tiene 3 dígitos,
            // consideramos el último separador decimal
            // y los anteriores como miles.
            string parteEntera =
                string.Concat(
                    partes.Take(
                        partes.Length - 1));

            string parteDecimal =
                partes.LastOrDefault() ??
                "";


            if (string.IsNullOrWhiteSpace(
                parteDecimal))
            {
                return
                    signo +
                    parteEntera;
            }


            return
                signo +
                parteEntera +
                "." +
                parteDecimal;
        }


        private string SanitizarNombreArchivoMetrado(
            string texto)
        {
            string resultado =
                string.IsNullOrWhiteSpace(
                    texto)
                ? "ACTIVO"
                : texto.Trim();

            foreach (
                char c
                in Path.GetInvalidFileNameChars())
            {
                resultado =
                    resultado.Replace(
                        c,
                        '_');
            }

            return
                resultado;
        }


        // =======================================
        // CACHE DE RESULTADOS DE REVISION REVIT
        // =======================================
        private string ObtenerClaveDocumentoCache(
            RevitDB.Document doc)
        {
            if (doc == null)
                return "";

            string ruta =
                "";

            try
            {
                ruta =
                    doc.PathName ??
                    "";
            }
            catch
            {
            }

            return
                (doc.Title ?? "") +
                "|" +
                ruta +
                "|" +
                doc.GetHashCode().ToString(
                    CultureInfo.InvariantCulture);
        }


        private string ConstruirFirmaConfiguracionesRevit(
            IEnumerable<ConfiguracionTablaPlanificacion> configuraciones)
        {
            var sb =
                new StringBuilder();

            foreach (
                ConfiguracionTablaPlanificacion cfg
                in (configuraciones ??
                    Enumerable.Empty<ConfiguracionTablaPlanificacion>())
                    .Where(
                        x =>
                            x != null &&
                            !string.Equals(
                                x.Estado,
                                "PROP. ELIMINAR",
                                StringComparison.OrdinalIgnoreCase))
                    .OrderBy(
                        x =>
                            ObtenerClaveConfiguracion(
                                x),
                        StringComparer.OrdinalIgnoreCase))
            {
                sb.Append(
                    ObtenerClaveConfiguracion(
                        cfg) ??
                    "");

                sb.Append('\u001F');
                sb.Append(
                    cfg.Item ??
                    "");

                sb.Append('\u001F');
                sb.Append(
                    cfg.Partida ??
                    "");

                sb.Append('\u001F');
                sb.Append(
                    cfg.Plantilla ??
                    "");

                foreach (
                    FiltroPlanificacion filtro
                    in cfg.ObtenerFiltros() ??
                       new List<FiltroPlanificacion>())
                {
                    if (filtro == null)
                        continue;

                    sb.Append('\u001E');
                    sb.Append(
                        filtro.Parametro ??
                        "");

                    sb.Append('\u001D');
                    sb.Append(
                        filtro.Regla ??
                        "");

                    sb.Append('\u001D');
                    sb.Append(
                        filtro.Valor ??
                        "");
                }

                sb.Append('\u001C');
            }

            return
                sb.ToString();
        }


        private List<ResultadoValidacionRevitPartida>
            ClonarResultadosValidacionRevit(
                IEnumerable<ResultadoValidacionRevitPartida> resultados)
        {
            return
                (resultados ??
                 Enumerable.Empty<ResultadoValidacionRevitPartida>())
                    .Where(
                        x =>
                            x != null)
                    .Select(
                        x =>
                            new ResultadoValidacionRevitPartida()
                            {
                                ClavePartida =
                                    x.ClavePartida,

                                Estado =
                                    x.Estado,

                                Mensaje =
                                    x.Mensaje
                            })
                    .ToList();
        }


        private void GuardarValidacionRevitCache(
            RevitDB.Document doc,
            IEnumerable<ConfiguracionTablaPlanificacion> configuraciones,
            IEnumerable<ResultadoValidacionRevitPartida> resultados)
        {
            _ultimoDocumentoValidacionRevit =
                ObtenerClaveDocumentoCache(
                    doc);

            _ultimaFirmaValidacionRevit =
                ConstruirFirmaConfiguracionesRevit(
                    configuraciones);

            _ultimosResultadosValidacionRevit =
                ClonarResultadosValidacionRevit(
                    resultados);
        }


        private bool IntentarObtenerValidacionRevitCache(
            RevitDB.Document doc,
            IEnumerable<ConfiguracionTablaPlanificacion> configuraciones,
            out List<ResultadoValidacionRevitPartida> resultados)
        {
            resultados =
                null;

            if (_ultimosResultadosValidacionRevit == null ||
                _ultimosResultadosValidacionRevit.Count == 0)
            {
                return false;
            }

            string documento =
                ObtenerClaveDocumentoCache(
                    doc);

            string firma =
                ConstruirFirmaConfiguracionesRevit(
                    configuraciones);

            if (!string.Equals(
                    documento,
                    _ultimoDocumentoValidacionRevit,
                    StringComparison.Ordinal) ||
                !string.Equals(
                    firma,
                    _ultimaFirmaValidacionRevit,
                    StringComparison.Ordinal))
            {
                return false;
            }

            resultados =
                ClonarResultadosValidacionRevit(
                    _ultimosResultadosValidacionRevit);

            return true;
        }


        private void ReiniciarIndicesRapidosRevit()
        {
            _indiceTiposPorCategoria.Clear();
            _storageTypeCampoCache.Clear();

            _indicesTiposTodasCategoriasConstruidos =
                false;
        }


        private void ReiniciarCachesEjecucionRapida()
        {
            _idsViewScheduleEjecucionCache =
                null;

            _schemaMYGLecturaCache =
                null;

            _schemaFieldCreadoPorCache =
                null;

            _schemaFieldProjectIdCache =
                null;

            _schemaFieldPresupuestoIdCache =
                null;

            _schemaFieldPartidaKeyCache =
                null;

            _partidaKeyTablaEjecucionCache.Clear();
            _esTablaMYGPresupuestoEjecucionCache.Clear();
        }


        private List<RevitDB.ViewSchedule>
            ObtenerViewSchedulesEjecucion(
                RevitDB.Document doc)
        {
            if (doc == null)
            {
                return
                    new List<RevitDB.ViewSchedule>();
            }

            if (_idsViewScheduleEjecucionCache == null)
            {
                _idsViewScheduleEjecucionCache =
                    new RevitDB.FilteredElementCollector(
                        doc)
                        .OfClass(
                            typeof(RevitDB.ViewSchedule))
                        .ToElementIds()
                        .ToList();
            }

            var resultado =
                new List<RevitDB.ViewSchedule>(
                    _idsViewScheduleEjecucionCache.Count);

            foreach (
                RevitDB.ElementId id
                in _idsViewScheduleEjecucionCache)
            {
                RevitDB.ViewSchedule schedule =
                    doc.GetElement(
                        id)
                    as RevitDB.ViewSchedule;

                if (schedule != null)
                {
                    resultado.Add(
                        schedule);
                }
            }

            return resultado;
        }


        private Autodesk.Revit.DB.ExtensibleStorage.Schema
            ObtenerSchemaMYGLecturaRapida()
        {
            if (_schemaMYGLecturaCache != null)
            {
                return
                    _schemaMYGLecturaCache;
            }

            _schemaMYGLecturaCache =
                Autodesk.Revit.DB.ExtensibleStorage.Schema.Lookup(
                    MYG2027_SCHEMA_GUID);

            if (_schemaMYGLecturaCache != null)
            {
                _schemaFieldCreadoPorCache =
                    _schemaMYGLecturaCache.GetField(
                        "CreadoPor");

                _schemaFieldProjectIdCache =
                    _schemaMYGLecturaCache.GetField(
                        "ProjectId");

                _schemaFieldPresupuestoIdCache =
                    _schemaMYGLecturaCache.GetField(
                        "PresupuestoId");

                _schemaFieldPartidaKeyCache =
                    _schemaMYGLecturaCache.GetField(
                        "PartidaKey");
            }

            return
                _schemaMYGLecturaCache;
        }


        // =======================================
        // REVISION PREVIA DE CONFIGURACIONES REVIT
        // =======================================
        private List<ResultadoValidacionRevitPartida>
            ValidarConfiguracionesRevit(
                RevitUI.UIDocument uidoc,
                List<ConfiguracionTablaPlanificacion> configuraciones)
        {
            RevitDB.Document doc =
                uidoc?.Document;

            var resultados =
                new List<ResultadoValidacionRevitPartida>();

            if (doc == null)
            {
                return resultados;
            }

            // Los índices dependen del documento Revit actual.
            // Una revisión completa los reconstruye una sola vez y luego
            // se reutilizan durante la creación que sigue inmediatamente.
            ReiniciarIndicesRapidosRevit();

            List<ConfiguracionTablaPlanificacion> configs =
                (configuraciones ??
                 new List<ConfiguracionTablaPlanificacion>())
                    .Where(
                        x =>
                            x != null &&
                            !string.Equals(
                                x.Estado,
                                "PROP. ELIMINAR",
                                StringComparison.OrdinalIgnoreCase))
                    .ToList();

            foreach (
                ConfiguracionTablaPlanificacion cfg
                in configs)
            {
                resultados.Add(
                    new ResultadoValidacionRevitPartida()
                    {
                        ClavePartida =
                            ObtenerClaveConfiguracion(
                                cfg),

                        Estado =
                            "LISTO",

                        Mensaje =
                            "Configuración válida para el documento Revit actual."
                    });
            }

            Dictionary<string, ResultadoValidacionRevitPartida> porClave =
                resultados
                    .Where(
                        x =>
                            !string.IsNullOrWhiteSpace(
                                x.ClavePartida))
                    .GroupBy(
                        x =>
                            x.ClavePartida,
                        StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(
                        g =>
                            g.Key,
                        g =>
                            g.First(),
                        StringComparer.OrdinalIgnoreCase);

            ResultadoValidacionRevitPartida ObtenerResultado(
                ConfiguracionTablaPlanificacion cfg)
            {
                string clave =
                    ObtenerClaveConfiguracion(
                        cfg);

                if (!string.IsNullOrWhiteSpace(
                        clave) &&
                    porClave.TryGetValue(
                        clave,
                        out ResultadoValidacionRevitPartida r))
                {
                    return r;
                }

                ResultadoValidacionRevitPartida nuevo =
                    new ResultadoValidacionRevitPartida()
                    {
                        ClavePartida =
                            clave,

                        Estado =
                            "LISTO",

                        Mensaje =
                            "Configuración válida para el documento Revit actual."
                    };

                resultados.Add(
                    nuevo);

                if (!string.IsNullOrWhiteSpace(
                        clave))
                {
                    porClave[clave] =
                        nuevo;
                }

                return nuevo;
            }

            // ---------------------------------------
            // Comprobaciones generales de la data.
            // ---------------------------------------
            foreach (
                ConfiguracionTablaPlanificacion cfg
                in configs)
            {
                ResultadoValidacionRevitPartida resultado =
                    ObtenerResultado(
                        cfg);

                if (string.IsNullOrWhiteSpace(
                        ObtenerClaveConfiguracion(
                            cfg)))
                {
                    AgregarErrorResultadoRevit(
                        resultado,
                        "La partida no tiene una clave interna estable para sincronizarla con Revit.");
                }

                if (string.IsNullOrWhiteSpace(
                        cfg.Plantilla))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        "Hay configuración BIM, pero no se seleccionó una PLANTILLA de Revit.");
                }
            }

            Dictionary<string, List<ConfiguracionTablaPlanificacion>>
                clavesDuplicadas =
                    configs
                        .Where(
                            x =>
                                !string.IsNullOrWhiteSpace(
                                    ObtenerClaveConfiguracion(
                                        x)))
                        .GroupBy(
                            x =>
                                ObtenerClaveConfiguracion(
                                    x),
                            StringComparer.OrdinalIgnoreCase)
                        .Where(
                            g =>
                                g.Count() > 1)
                        .ToDictionary(
                            g =>
                                g.Key,
                            g =>
                                g.ToList(),
                            StringComparer.OrdinalIgnoreCase);

            foreach (
                string claveDuplicada
                in clavesDuplicadas.Keys)
            {
                foreach (
                    ResultadoValidacionRevitPartida resultado
                    in resultados.Where(
                        x =>
                            x != null &&
                            string.Equals(
                                x.ClavePartida,
                                claveDuplicada,
                                StringComparison.OrdinalIgnoreCase)))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        "La misma clave interna '" +
                        claveDuplicada +
                        "' aparece en más de una partida. Debe existir una sola identidad BIM por partida.");
                }
            }

            Dictionary<string, List<ConfiguracionTablaPlanificacion>>
                nombresDuplicados =
                    configs
                        .Where(
                            x =>
                                !string.IsNullOrWhiteSpace(
                                    x.Plantilla))
                        .GroupBy(
                            x =>
                                ConstruirNombreTablaBase(
                                    x.Item,
                                    x.Partida),
                            StringComparer.OrdinalIgnoreCase)
                        .Where(
                            g =>
                                g.Count() > 1)
                        .ToDictionary(
                            g =>
                                g.Key,
                            g =>
                                g.ToList(),
                            StringComparer.OrdinalIgnoreCase);

            foreach (
                KeyValuePair<string, List<ConfiguracionTablaPlanificacion>> par
                in nombresDuplicados)
            {
                foreach (
                    ConfiguracionTablaPlanificacion cfg
                    in par.Value)
                {
                    AgregarAlertaResultadoRevit(
                        ObtenerResultado(
                            cfg),
                        "El nombre de tabla '" +
                        par.Key +
                        "' también sería generado por otra partida. Revit no admite dos vistas con el mismo nombre.");
                }
            }

            // La validación y la creación ocurren en el mismo Execute.
            // Reutilizar el mismo inventario evita recorrer dos veces todas
            // las ViewSchedule del documento.
            List<RevitDB.ViewSchedule> todasLasTablas =
                ObtenerViewSchedulesEjecucion(
                    doc);

            Dictionary<string, RevitDB.ViewSchedule> plantillasPorNombre =
                todasLasTablas
                    .Where(
                        x =>
                            !x.IsTemplate &&
                            !string.IsNullOrWhiteSpace(
                                x.Name))
                    .GroupBy(
                        x =>
                            x.Name.Trim(),
                        StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(
                        g =>
                            g.Key,
                        g =>
                            g.First(),
                        StringComparer.OrdinalIgnoreCase);

            foreach (
                ConfiguracionTablaPlanificacion cfg
                in configs)
            {
                if (string.IsNullOrWhiteSpace(
                        cfg.Plantilla))
                {
                    continue;
                }

                ResultadoValidacionRevitPartida resultado =
                    ObtenerResultado(
                        cfg);

                if (!plantillasPorNombre.TryGetValue(
                        cfg.Plantilla.Trim(),
                        out RevitDB.ViewSchedule plantilla))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        "No existe la tabla plantilla '" +
                        cfg.Plantilla.Trim() +
                        "' en el documento Revit actual.");

                    continue;
                }

                try
                {
                    if (!plantilla.CanViewBeDuplicated(
                            RevitDB.ViewDuplicateOption.Duplicate))
                    {
                        AgregarAlertaResultadoRevit(
                            resultado,
                            "La tabla plantilla '" +
                            plantilla.Name +
                            "' no puede duplicarse en Revit.");
                    }
                }
                catch (Exception ex)
                {
                    AgregarErrorResultadoRevit(
                        resultado,
                        "No se pudo comprobar si la plantilla '" +
                        plantilla.Name +
                        "' puede duplicarse: " +
                        ex.Message);
                }
            }

            // ---------------------------------------
            // Validación exacta de filtros - OPTIMIZADA.
            //
            // Antes:
            //   por CADA partida se quitaban filtros + Regenerate +
            //   RefreshData. Esa reconstrucción de Revit era el principal
            //   cuello de botella.
            //
            // Ahora:
            //   1. Se crea UNA copia temporal por plantilla.
            //   2. Se limpian sus filtros UNA sola vez.
            //   3. Se agregan de antemano los campos que usarán las partidas.
            //   4. Se hace UN SOLO Regenerate global.
            //   5. Cada partida únicamente prueba sus filtros dentro de una
            //      SubTransaction y hace rollback.
            //
            // La lógica de validación es la misma y nada queda guardado.
            // ---------------------------------------
            Dictionary<string, RevitDB.ViewSchedule> temporales =
                new Dictionary<string, RevitDB.ViewSchedule>(
                    StringComparer.OrdinalIgnoreCase);

            using (
                RevitDB.Transaction trans =
                    new RevitDB.Transaction(
                        doc,
                        "MYG - Revisar configuraciones Revit"))
            {
                try
                {
                    trans.Start();

                    Dictionary<string, List<ConfiguracionTablaPlanificacion>>
                        configsPorPlantilla =
                            configs
                                .Where(
                                    x =>
                                        x != null &&
                                        !string.IsNullOrWhiteSpace(
                                            x.Plantilla))
                                .GroupBy(
                                    x =>
                                        x.Plantilla.Trim(),
                                    StringComparer.OrdinalIgnoreCase)
                                .ToDictionary(
                                    g =>
                                        g.Key,
                                    g =>
                                        g.ToList(),
                                    StringComparer.OrdinalIgnoreCase);

                    List<string> nombresPlantillaUsados =
                        configsPorPlantilla
                            .Keys
                            .Where(
                                nombre =>
                                    plantillasPorNombre.ContainsKey(
                                        nombre))
                            .ToList();

                    foreach (
                        string nombrePlantilla
                        in nombresPlantillaUsados)
                    {
                        RevitDB.ViewSchedule original =
                            plantillasPorNombre[
                                nombrePlantilla];

                        try
                        {
                            if (!original.CanViewBeDuplicated(
                                    RevitDB.ViewDuplicateOption.Duplicate))
                            {
                                continue;
                            }

                            RevitDB.ElementId idTemporal =
                                original.Duplicate(
                                    RevitDB.ViewDuplicateOption.Duplicate);

                            RevitDB.ViewSchedule temporal =
                                doc.GetElement(
                                    idTemporal)
                                as RevitDB.ViewSchedule;

                            if (temporal == null)
                            {
                                continue;
                            }

                            RevitDB.ScheduleDefinition definition =
                                temporal.Definition;

                            // Limpiar filtros heredados UNA sola vez.
                            for (
                                int i =
                                    definition.GetFilterCount() - 1;
                                i >= 0;
                                i--)
                            {
                                definition.RemoveFilter(
                                    i);
                            }

                            temporales[nombrePlantilla] =
                                temporal;

                            // Añadir una sola vez los campos que serán usados
                            // por todas las partidas de esta plantilla.
                            List<string> parametrosNecesarios =
                                configsPorPlantilla[
                                    nombrePlantilla]
                                    .SelectMany(
                                        x =>
                                            x.ObtenerFiltros() ??
                                            new List<FiltroPlanificacion>())
                                    .Where(
                                        x =>
                                            x != null &&
                                            !string.IsNullOrWhiteSpace(
                                                x.Parametro))
                                    .Select(
                                        x =>
                                            x.Parametro.Trim())
                                    .Distinct(
                                        StringComparer.OrdinalIgnoreCase)
                                    .ToList();

                            foreach (
                                string parametro
                                in parametrosNecesarios)
                            {
                                try
                                {
                                    BuscarOCrearCampo(
                                        temporal,
                                        doc,
                                        parametro);
                                }
                                catch
                                {
                                    // La validación por partida emitirá el
                                    // detalle correspondiente si no es válido.
                                }
                            }
                        }
                        catch
                        {
                            // El detalle ya se mostrará por partida si
                            // no existe una copia temporal disponible.
                        }
                    }

                    // ÚNICA regeneración para todas las plantillas temporales.
                    if (temporales.Count > 0)
                    {
                        doc.Regenerate();

                        // OPTIMIZACIÓN:
                        // No llamar RefreshData() sobre las copias temporales.
                        //
                        // La revisión que sigue trabaja exclusivamente con
                        // ScheduleDefinition, ScheduleField y AddFilter.
                        // No lee el cuerpo renderizado ni las filas/valores
                        // calculados de la tabla temporal.
                        //
                        // RefreshData() fuerza a Revit a recalcular los datos
                        // completos de cada tabla y, en modelos grandes, puede
                        // consumir varios segundos POR PLANTILLA.
                        //
                        // Se conserva doc.Regenerate(), por lo que los campos
                        // añadidos quedan actualizados antes de probar filtros.
                    }

                    foreach (
                        ConfiguracionTablaPlanificacion cfg
                        in configs)
                    {
                        if (string.IsNullOrWhiteSpace(
                                cfg.Plantilla))
                        {
                            continue;
                        }

                        ResultadoValidacionRevitPartida resultado =
                            ObtenerResultado(
                                cfg);

                        if (!temporales.TryGetValue(
                                cfg.Plantilla.Trim(),
                                out RevitDB.ViewSchedule scheduleTemporal) ||
                            scheduleTemporal == null)
                        {
                            if (string.Equals(
                                    resultado.Estado,
                                    "LISTO",
                                    StringComparison.OrdinalIgnoreCase))
                            {
                                AgregarAlertaResultadoRevit(
                                    resultado,
                                    "No se pudo generar una copia temporal de la plantilla para comprobar sus filtros.");
                            }

                            continue;
                        }

                        using (
                            RevitDB.SubTransaction sub =
                                new RevitDB.SubTransaction(
                                    doc))
                        {
                            try
                            {
                                sub.Start();

                                // La copia temporal ya está limpia y
                                // regenerada. Solo se prueban los filtros de
                                // esta partida.
                                ValidarFiltrosConfiguracionRevit(
                                    doc,
                                    scheduleTemporal,
                                    cfg,
                                    resultado);

                                sub.RollBack();
                            }
                            catch (Exception ex)
                            {
                                try
                                {
                                    if (sub.GetStatus() ==
                                        RevitDB.TransactionStatus.Started)
                                    {
                                        sub.RollBack();
                                    }
                                }
                                catch
                                {
                                }

                                AgregarErrorResultadoRevit(
                                    resultado,
                                    "Revit produjo un error inesperado al revisar esta partida: " +
                                    ex.Message);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    foreach (
                        ResultadoValidacionRevitPartida resultado
                        in resultados)
                    {
                        AgregarErrorResultadoRevit(
                            resultado,
                            "No se pudo completar la revisión temporal de Revit: " +
                            ex.Message);
                    }
                }
                finally
                {
                    try
                    {
                        if (trans.GetStatus() ==
                            RevitDB.TransactionStatus.Started)
                        {
                            trans.RollBack();
                        }
                    }
                    catch
                    {
                    }
                }
            }

            foreach (
                ResultadoValidacionRevitPartida resultado
                in resultados)
            {
                if (string.Equals(
                        resultado.Estado,
                        "LISTO",
                        StringComparison.OrdinalIgnoreCase))
                {
                    resultado.Mensaje =
                        "Configuración comprobada: Revit puede crear la tabla y aplicar sus filtros.";
                }
            }

            return resultados;
        }


        private void ValidarFiltrosConfiguracionRevit(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            ConfiguracionTablaPlanificacion cfg,
            ResultadoValidacionRevitPartida resultado)
        {
            List<FiltroPlanificacion> filtros =
                (cfg?.ObtenerFiltros() ??
                 new List<FiltroPlanificacion>())
                    .Where(
                        x =>
                            x != null &&
                            !x.EstaVacio())
                    .Take(
                        8)
                    .ToList();

            RevitDB.ScheduleDefinition definition =
                schedule.Definition;

            for (
                int indice = 0;
                indice < filtros.Count;
                indice++)
            {
                FiltroPlanificacion filtroCfg =
                    filtros[indice];

                string prefijo =
                    "FILTRO " +
                    (indice + 1).ToString(
                        "00") +
                    ": ";

                if (string.IsNullOrWhiteSpace(
                        filtroCfg.Parametro))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        prefijo +
                        "falta seleccionar PARÁMETRO.");
                    continue;
                }

                if (string.IsNullOrWhiteSpace(
                        filtroCfg.Regla))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        prefijo +
                        "falta seleccionar REGLA para el parámetro '" +
                        filtroCfg.Parametro +
                        "'.");
                    continue;
                }

                if (ReglaRequiereValor(
                        filtroCfg.Regla) &&
                    string.IsNullOrWhiteSpace(
                        filtroCfg.Valor))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        prefijo +
                        "la regla '" +
                        filtroCfg.Regla +
                        "' necesita un VALOR.");
                    continue;
                }

                RevitDB.ScheduleField field =
                    BuscarOCrearCampo(
                        schedule,
                        doc,
                        filtroCfg.Parametro);

                if (field == null)
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        prefijo +
                        "el parámetro '" +
                        filtroCfg.Parametro +
                        "' no está disponible en la plantilla '" +
                        (cfg.Plantilla ?? "") +
                        "'.");
                    continue;
                }

                List<string> reglasAplicables =
                    PlantillaParametrosRevitCache
                        .ObtenerReglas(
                            cfg.Plantilla,
                            filtroCfg.Parametro);

                if (reglasAplicables.Count > 0 &&
                    !reglasAplicables.Any(
                        x =>
                            string.Equals(
                                x,
                                filtroCfg.Regla,
                                StringComparison.OrdinalIgnoreCase)))
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        prefijo +
                        "la regla '" +
                        filtroCfg.Regla +
                        "' no es compatible con el parámetro '" +
                        filtroCfg.Parametro +
                        "' en Revit.");
                    continue;
                }

                RevitDB.ScheduleFilterType tipo;

                try
                {
                    tipo =
                        ConvertirRegla(
                            filtroCfg.Regla);
                }
                catch (Exception ex)
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        prefijo +
                        ex.Message);
                    continue;
                }

                try
                {
                    RevitDB.ScheduleFilter filtroRevit;

                    if (tipo ==
                            RevitDB.ScheduleFilterType.HasParameter ||
                        tipo ==
                            RevitDB.ScheduleFilterType.HasValue ||
                        tipo ==
                            RevitDB.ScheduleFilterType.HasNoValue)
                    {
                        filtroRevit =
                            new RevitDB.ScheduleFilter(
                                field.FieldId,
                                tipo);
                    }
                    else
                    {
                        filtroRevit =
                            CrearFiltroRevitConValorTipado(
                                doc,
                                schedule,
                                field,
                                filtroCfg.Parametro,
                                tipo,
                                filtroCfg.Valor);
                    }

                    definition.AddFilter(
                        filtroRevit);
                }
                catch (Exception ex)
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        ConstruirMensajeAlertaFiltro(
                            prefijo,
                            filtroCfg,
                            ex));
                }
            }
        }


        private string ConstruirMensajeAlertaFiltro(
            string prefijo,
            FiltroPlanificacion filtro,
            Exception ex)
        {
            string mensaje =
                ex?.Message ??
                "Revit rechazó el filtro.";

            if (mensaje.IndexOf(
                    "referencia de Revit",
                    StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return
                    prefijo +
                    "el valor '" +
                    (filtro?.Valor ?? "") +
                    "' todavía no existe o no está cargado como referencia válida de Revit para el parámetro '" +
                    (filtro?.Parametro ?? "") +
                    "'. La configuración se conserva y esta tabla se omitirá hasta que el valor exista.";
            }

            return
                prefijo +
                "Revit no puede aplicar " +
                (filtro?.Parametro ?? "") +
                " / " +
                (filtro?.Regla ?? "") +
                " / " +
                (filtro?.Valor ?? "") +
                ". " +
                mensaje;
        }


        private bool ReglaRequiereValor(
            string regla)
        {
            return
                !string.Equals(
                    regla,
                    "parámetro existe",
                    StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(
                    regla,
                    "tiene valor",
                    StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(
                    regla,
                    "no tiene valor",
                    StringComparison.OrdinalIgnoreCase);
        }


        private void AgregarAlertaResultadoRevit(
            ResultadoValidacionRevitPartida resultado,
            string mensaje)
        {
            if (resultado == null ||
                string.IsNullOrWhiteSpace(
                    mensaje))
            {
                return;
            }

            if (!string.Equals(
                    resultado.Estado,
                    "ERROR",
                    StringComparison.OrdinalIgnoreCase))
            {
                resultado.Estado =
                    "ALERTA";
            }

            AgregarMensajeResultadoRevit(
                resultado,
                mensaje);
        }


        private void AgregarErrorResultadoRevit(
            ResultadoValidacionRevitPartida resultado,
            string mensaje)
        {
            if (resultado == null)
                return;

            resultado.Estado =
                "ERROR";

            AgregarMensajeResultadoRevit(
                resultado,
                mensaje);
        }


        private void AgregarMensajeResultadoRevit(
            ResultadoValidacionRevitPartida resultado,
            string mensaje)
        {
            if (resultado == null ||
                string.IsNullOrWhiteSpace(
                    mensaje))
            {
                return;
            }

            string actual =
                (resultado.Mensaje ?? "")
                    .Trim();

            if (actual ==
                "Configuración válida para el documento Revit actual." ||
                actual ==
                "Configuración comprobada: Revit puede crear la tabla y aplicar sus filtros.")
            {
                actual =
                    "";
            }

            if (actual.IndexOf(
                    mensaje,
                    StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return;
            }

            resultado.Mensaje =
                string.IsNullOrWhiteSpace(
                    actual)
                ? mensaje.Trim()
                : actual +
                  "\n" +
                  mensaje.Trim();
        }


        private string ObtenerClaveConfiguracion(
            ConfiguracionTablaPlanificacion cfg)
        {
            if (cfg == null)
                return "";

            if (!string.IsNullOrWhiteSpace(
                    cfg.IdPropuesta))
            {
                return
                    cfg.IdPropuesta.Trim();
            }

            if (!string.IsNullOrWhiteSpace(
                    cfg.IdInternoDelphin))
            {
                return
                    cfg.IdInternoDelphin.Trim();
            }

            return
                (cfg.IdInterno ?? "")
                    .Trim();
        }


        private ResultadoValidacionRevitPartida
            BuscarResultadoConfiguracion(
                IEnumerable<ResultadoValidacionRevitPartida> resultados,
                ConfiguracionTablaPlanificacion cfg)
        {
            string clave =
                ObtenerClaveConfiguracion(
                    cfg);

            return
                (resultados ??
                 Enumerable.Empty<ResultadoValidacionRevitPartida>())
                    .FirstOrDefault(
                        x =>
                            x != null &&
                            string.Equals(
                                x.ClavePartida ?? "",
                                clave,
                                StringComparison.OrdinalIgnoreCase));
        }


        private void MostrarResumenRevisionRevit(
            List<ResultadoValidacionRevitPartida> resultados)
        {
            int listos =
                (resultados ??
                 new List<ResultadoValidacionRevitPartida>())
                    .Count(
                        x =>
                            x != null &&
                            string.Equals(
                                x.Estado,
                                "LISTO",
                                StringComparison.OrdinalIgnoreCase));

            int alertas =
                (resultados ??
                 new List<ResultadoValidacionRevitPartida>())
                    .Count(
                        x =>
                            x != null &&
                            string.Equals(
                                x.Estado,
                                "ALERTA",
                                StringComparison.OrdinalIgnoreCase));

            int errores =
                (resultados ??
                 new List<ResultadoValidacionRevitPartida>())
                    .Count(
                        x =>
                            x != null &&
                            string.Equals(
                                x.Estado,
                                "ERROR",
                                StringComparison.OrdinalIgnoreCase));

            RevitUI.TaskDialog.Show(
                "Revisión Revit",
                "Revisión completada.\n\n" +
                "LISTO: " +
                listos +
                "\nALERTA: " +
                alertas +
                "\nERROR: " +
                errores +
                "\n\nRevisa la nueva columna REVIT. Pasa el cursor sobre una ALERTA o ERROR para ver el detalle.");
        }


        // =======================================
        // SINCRONIZAR TABLAS MYG_2027 EN REVIT
        //
        // NUEVO COMPORTAMIENTO TOLERANTE:
        // - Cada configuración se revisa antes de tocar el modelo.
        // - LISTO se sincroniza.
        // - ALERTA / ERROR se omite y su tabla anterior se conserva.
        // - Cada partida LISTO se procesa en SubTransaction propia.
        //   Un fallo aislado ya no hace perder las demás tablas.
        // =======================================
        // =======================================
        // ACTUALIZAR UNA SOLA TABLA DE PLANIFICACIÓN
        //
        // IMPORTANTE:
        // Este método NO llama a CrearTablasPlanificacion con una lista de
        // un solo elemento, porque el flujo global también contiene lógica
        // de limpieza de tablas obsoletas. Aquí solo se reemplaza/crea la
        // tabla correspondiente a cfg y jamás se tocan las demás.
        // =======================================
        private void ActualizarTablaPlanificacionIndividual(
            RevitUI.UIDocument uidoc,
            ConfiguracionTablaPlanificacion cfg,
            ResultadoValidacionRevitPartida resultado,
            List<ConfiguracionTablaPlanificacion> configuracionesCompletas,
            System.Diagnostics.Stopwatch relojTotalIndividual,
            bool mostrarMensajeFinal = true,
            bool detenerRelojTotal = true)
        {
            RevitDB.Document doc =
                uidoc?.Document;

            if (doc == null)
            {
                throw new InvalidOperationException(
                    "No existe un documento activo de Revit.");
            }

            if (cfg == null)
            {
                throw new InvalidOperationException(
                    "No existe configuración para la tabla seleccionada.");
            }

            if (resultado == null ||
                !resultado.PuedeSincronizar)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(
                    ProjectId))
            {
                throw new InvalidOperationException(
                    "No se encontró el ID del proyecto actual.");
            }

            if (string.IsNullOrWhiteSpace(
                    PresupuestoIdActual))
            {
                throw new InvalidOperationException(
                    "No se encontró el ID del presupuesto actual.");
            }

            if (string.IsNullOrWhiteSpace(
                    cfg.Plantilla))
            {
                AgregarAlertaResultadoRevit(
                    resultado,
                    "La partida seleccionada no tiene PLANTILLA.");

                return;
            }

            System.Diagnostics.Stopwatch relojOperacion =
                System.Diagnostics.Stopwatch.StartNew();

            string nombreTabla =
                ConstruirNombreTablaBase(
                    cfg.Item,
                    cfg.Partida);

            string claveCfg =
                ObtenerClaveConfiguracion(
                    cfg);

            List<RevitDB.ViewSchedule> todasLasTablas =
                new RevitDB.FilteredElementCollector(
                    doc)
                    .OfClass(
                        typeof(RevitDB.ViewSchedule))
                    .Cast<RevitDB.ViewSchedule>()
                    .Where(
                        x =>
                            x != null)
                    .ToList();

            RevitDB.ViewSchedule plantilla =
                todasLasTablas
                    .FirstOrDefault(
                        x =>
                            x != null &&
                            !x.IsTemplate &&
                            string.Equals(
                                x.Name?.Trim(),
                                cfg.Plantilla.Trim(),
                                StringComparison.OrdinalIgnoreCase));

            if (plantilla == null)
            {
                AgregarAlertaResultadoRevit(
                    resultado,
                    "No existe la tabla plantilla '" +
                    cfg.Plantilla.Trim() +
                    "' en el documento Revit actual.");

                return;
            }

            List<RevitDB.ViewSchedule> tablasMarcadas =
                ObtenerTablasMYG2027DelPresupuesto(
                    todasLasTablas,
                    ProjectId,
                    PresupuestoIdActual);

            HashSet<string> clavesActivas =
                new HashSet<string>(
                    (configuracionesCompletas ??
                     new List<ConfiguracionTablaPlanificacion>())
                        .Where(
                            x =>
                                x != null)
                        .Select(
                            ObtenerClaveConfiguracion)
                        .Where(
                            x =>
                                !string.IsNullOrWhiteSpace(
                                    x)),
                    StringComparer.OrdinalIgnoreCase);

            HashSet<RevitDB.ElementId> idsReemplazar =
                new HashSet<RevitDB.ElementId>();

            // 1) Identidad exacta MYG: es la tabla de esta partida.
            foreach (
                RevitDB.ViewSchedule schedule
                in tablasMarcadas)
            {
                if (schedule == null)
                    continue;

                string claveTabla =
                    ObtenerPartidaKeyTablaMYG2027(
                        schedule);

                if (!string.IsNullOrWhiteSpace(
                        claveTabla) &&
                    !string.IsNullOrWhiteSpace(
                        claveCfg) &&
                    string.Equals(
                        claveTabla,
                        claveCfg,
                        StringComparison.OrdinalIgnoreCase))
                {
                    idsReemplazar.Add(
                        schedule.Id);

                    continue;
                }

                // Mismo nombre pero otra clave todavía activa:
                // NO tocarla, porque pertenece a otra partida.
                if (EsNombreTablaDePartida(
                        schedule.Name,
                        nombreTabla))
                {
                    if (!string.IsNullOrWhiteSpace(
                            claveTabla) &&
                        clavesActivas.Contains(
                            claveTabla) &&
                        !string.Equals(
                            claveTabla,
                            claveCfg,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        AgregarErrorResultadoRevit(
                            resultado,
                            "Ya existe otra tabla MYG_2027 activa con el nombre '" +
                            nombreTabla +
                            "'. Cambia el ITEM/PARTIDA o revisa la configuración duplicada.");

                        return;
                    }

                    // Si la clave anterior ya no está activa, es una tabla stale
                    // de esta misma posición y puede reemplazarse.
                    idsReemplazar.Add(
                        schedule.Id);
                }
            }

            // 2) Tabla legacy/manual con el mismo nombre.
            // Solo se considera si no está marcada como MYG del presupuesto.
            List<RevitDB.ViewSchedule> conflictosNoMarcados =
                todasLasTablas
                    .Where(
                        x =>
                            x != null &&
                            !x.IsTemplate &&
                            EsNombreTablaDePartida(
                                x.Name,
                                nombreTabla) &&
                            !tablasMarcadas.Any(
                                m =>
                                    m != null &&
                                    m.Id.Value ==
                                        x.Id.Value))
                    .ToList();

            if (conflictosNoMarcados.Count > 0)
            {
                string lista =
                    string.Join(
                        "\n",
                        conflictosNoMarcados
                            .Take(8)
                            .Select(
                                x =>
                                    "• " +
                                    x.Name));

                RevitUI.TaskDialog dialog =
                    new RevitUI.TaskDialog(
                        "Actualizar tabla seleccionada");

                dialog.MainInstruction =
                    "Ya existe una tabla con el mismo nombre.";

                dialog.MainContent =
                    lista +
                    "\n\nSi esa tabla fue creada anteriormente por MYG y deseas reemplazarla, pulsa SÍ.\n\n" +
                    "Si es una tabla manual que deseas conservar, pulsa NO.";

                dialog.CommonButtons =
                    RevitUI.TaskDialogCommonButtons.Yes |
                    RevitUI.TaskDialogCommonButtons.No;

                dialog.DefaultButton =
                    RevitUI.TaskDialogResult.No;

                if (dialog.Show() !=
                    RevitUI.TaskDialogResult.Yes)
                {
                    AgregarAlertaResultadoRevit(
                        resultado,
                        "La actualización individual fue cancelada para conservar una tabla existente con el mismo nombre.");

                    return;
                }

                foreach (
                    RevitDB.ViewSchedule schedule
                    in conflictosNoMarcados)
                {
                    idsReemplazar.Add(
                        schedule.Id);
                }
            }

            // Si la propia tabla a reemplazar está activa, abrir una vista segura.
            if (uidoc.ActiveView != null &&
                idsReemplazar.Contains(
                    uidoc.ActiveView.Id) &&
                !IntentarAbrirVistaSegura(
                    uidoc,
                    idsReemplazar))
            {
                AgregarAlertaResultadoRevit(
                    resultado,
                    "La tabla seleccionada está abierta como vista activa y no se encontró otra vista segura. Abre una planta, una vista 3D o una lámina y vuelve a intentar.");

                return;
            }

            RevitDB.ElementId idNuevaTabla =
                RevitDB.ElementId.InvalidElementId;

            using (
                RevitDB.Transaction trans =
                    new RevitDB.Transaction(
                        doc,
                        "Actualizar tabla MYG_2027"))
            {
                try
                {
                    trans.Start();

                    if (idsReemplazar.Count > 0)
                    {
                        doc.Delete(
                            idsReemplazar.ToList());
                    }

                    RevitDB.ElementId nuevaId =
                        plantilla.Duplicate(
                            RevitDB.ViewDuplicateOption.Duplicate);

                    RevitDB.ViewSchedule schedule =
                        doc.GetElement(
                            nuevaId)
                        as RevitDB.ViewSchedule;

                    if (schedule == null)
                    {
                        throw new InvalidOperationException(
                            "No se pudo obtener la tabla duplicada.");
                    }

                    schedule.Name =
                        nombreTabla;

                    RevitDB.ScheduleDefinition definition =
                        schedule.Definition;

                    for (
                        int i =
                            definition.GetFilterCount() - 1;
                        i >= 0;
                        i--)
                    {
                        definition.RemoveFilter(
                            i);
                    }

                    AplicarFiltrosConfiguracionRevit(
                        doc,
                        schedule,
                        cfg);

                    Autodesk.Revit.DB.ExtensibleStorage.Schema schema =
                        ObtenerOCrearSchemaMYG2027();

                    MarcarTablaComoMYG2027(
                        schedule,
                        schema,
                        cfg,
                        ProjectId,
                        PresupuestoIdActual);

                    idNuevaTabla =
                        schedule.Id;

                    trans.Commit();
                }
                catch
                {
                    try
                    {
                        if (trans.GetStatus() ==
                            RevitDB.TransactionStatus.Started)
                        {
                            trans.RollBack();
                        }
                    }
                    catch
                    {
                    }

                    throw;
                }
            }

            resultado.Estado =
                "LISTO";

            resultado.Mensaje =
                "Tabla actualizada individualmente en Revit. No se modificó ninguna otra tabla del presupuesto.";

            relojOperacion.Stop();

            if (detenerRelojTotal &&
                relojTotalIndividual != null &&
                relojTotalIndividual.IsRunning)
            {
                relojTotalIndividual.Stop();
            }

            double tiempoTotal =
                relojTotalIndividual != null
                ? relojTotalIndividual.Elapsed.TotalSeconds
                : relojOperacion.Elapsed.TotalSeconds;

            if (mostrarMensajeFinal)
            {
                RevitUI.TaskDialog.Show(
                    "Actualizar tabla",
                    "Tabla actualizada correctamente.\n\n" +
                    (cfg.Item ?? "") +
                    "  " +
                    (cfg.Partida ?? "") +
                    "\n\nTablas anteriores reemplazadas: " +
                    idsReemplazar.Count +
                    "\nTiempo total: " +
                    tiempoTotal.ToString(
                        "0.0",
                        CultureInfo.InvariantCulture) +
                    " s" +
                    "\nOperación Revit: " +
                    relojOperacion.Elapsed.TotalSeconds.ToString(
                        "0.0",
                        CultureInfo.InvariantCulture) +
                    " s" +
                    "\n\nModo rápido: no se ejecutó la validación temporal pesada." +
                    "\nNo se procesaron las demás tablas del presupuesto.");
            }
        }


        private void CrearTablasPlanificacion(
            RevitUI.UIDocument uidoc,
            List<ConfiguracionTablaPlanificacion> configuraciones,
            List<ResultadoValidacionRevitPartida> resultadosPrevalidacion = null,
            System.Diagnostics.Stopwatch relojProcesoCompleto = null,
            TimeSpan? tiempoValidacionPrevia = null,
            bool validacionDesdeCache = false)
        {
            RevitDB.Document doc =
                uidoc?.Document;

            if (doc == null)
            {
                throw new InvalidOperationException(
                    "No existe un documento activo de Revit.");
            }

            System.Diagnostics.Stopwatch relojSincronizacion =
                System.Diagnostics.Stopwatch.StartNew();

            if (relojProcesoCompleto == null)
            {
                relojProcesoCompleto =
                    System.Diagnostics.Stopwatch.StartNew();
            }

            System.Diagnostics.Stopwatch relojValidacionInterna =
                null;

            if (string.IsNullOrWhiteSpace(
                    ProjectId))
            {
                throw new InvalidOperationException(
                    "No se encontró el ID del proyecto actual.");
            }

            if (string.IsNullOrWhiteSpace(
                    PresupuestoIdActual))
            {
                throw new InvalidOperationException(
                    "No se encontró el ID del presupuesto actual.");
            }

            List<ConfiguracionTablaPlanificacion> configsActuales =
                (configuraciones ??
                 new List<ConfiguracionTablaPlanificacion>())
                    .Where(
                        x =>
                            x != null &&
                            !string.Equals(
                                x.Estado,
                                "PROP. ELIMINAR",
                                StringComparison.OrdinalIgnoreCase))
                    .ToList();

            if (configsActuales.Count == 0)
            {
                RevitUI.TaskDialog.Show(
                    "Tablas Automáticas",
                    "No existen configuraciones BIM para sincronizar.");

                return;
            }

            List<ResultadoValidacionRevitPartida> resultados =
                resultadosPrevalidacion;

            if (resultados == null)
            {
                relojValidacionInterna =
                    System.Diagnostics.Stopwatch.StartNew();

                if (!IntentarObtenerValidacionRevitCache(
                        doc,
                        configsActuales,
                        out resultados))
                {
                    resultados =
                        ValidarConfiguracionesRevit(
                            uidoc,
                            configsActuales);

                    GuardarValidacionRevitCache(
                        doc,
                        configsActuales,
                        resultados);
                }
                else
                {
                    validacionDesdeCache =
                        true;
                }

                relojValidacionInterna.Stop();

                tiempoValidacionPrevia =
                    relojValidacionInterna.Elapsed;
            }

            Dictionary<string, ResultadoValidacionRevitPartida>
                resultadoPorClave =
                    (resultados ??
                     new List<ResultadoValidacionRevitPartida>())
                        .Where(
                            x =>
                                x != null &&
                                !string.IsNullOrWhiteSpace(
                                    x.ClavePartida))
                        .GroupBy(
                            x =>
                                x.ClavePartida,
                            StringComparer.OrdinalIgnoreCase)
                        .ToDictionary(
                            g =>
                                g.Key,
                            g =>
                                g.First(),
                            StringComparer.OrdinalIgnoreCase);

            var claveCfgCache =
                new Dictionary<ConfiguracionTablaPlanificacion, string>();

            var nombreCfgCache =
                new Dictionary<ConfiguracionTablaPlanificacion, string>();

            foreach (
                ConfiguracionTablaPlanificacion cfg
                in configsActuales)
            {
                claveCfgCache[
                    cfg] =
                        ObtenerClaveConfiguracion(
                            cfg);

                nombreCfgCache[
                    cfg] =
                        ConstruirNombreTablaBase(
                            cfg.Item,
                            cfg.Partida);
            }

            List<ConfiguracionTablaPlanificacion> configsListas =
                configsActuales
                    .Where(
                        cfg =>
                        {
                            string clave =
                                claveCfgCache[
                                    cfg];

                            return
                                !string.IsNullOrWhiteSpace(
                                    clave) &&
                                resultadoPorClave.TryGetValue(
                                    clave,
                                    out ResultadoValidacionRevitPartida r) &&
                                r != null &&
                                r.PuedeSincronizar &&
                                !string.IsNullOrWhiteSpace(
                                    cfg.Plantilla);
                        })
                    .ToList();

            HashSet<ConfiguracionTablaPlanificacion> setConfigsListas =
                new HashSet<ConfiguracionTablaPlanificacion>(
                    configsListas);

            List<ConfiguracionTablaPlanificacion> configsBloqueadas =
                configsActuales
                    .Where(
                        cfg =>
                            !setConfigsListas.Contains(
                                cfg))
                    .ToList();

            if (configsListas.Count == 0)
            {
                RevitUI.TaskDialog.Show(
                    "Tablas Automáticas",
                    "No se creó ninguna tabla.\n\n" +
                    "Todas las configuraciones BIM presentan ALERTA o ERROR.\n" +
                    "Las tablas MYG_2027 anteriores se conservaron.\n\n" +
                    "Revisa la columna REVIT para ver el detalle.");

                return;
            }

            List<RevitDB.ViewSchedule> todasLasTablas =
                ObtenerViewSchedulesEjecucion(
                    doc);

            Dictionary<string, RevitDB.ViewSchedule> plantillasPorNombre =
                todasLasTablas
                    .Where(
                        x =>
                            !x.IsTemplate &&
                            !string.IsNullOrWhiteSpace(
                                x.Name))
                    .GroupBy(
                        x =>
                            x.Name.Trim(),
                        StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(
                        g =>
                            g.Key,
                        g =>
                            g.First(),
                        StringComparer.OrdinalIgnoreCase);

            List<RevitDB.ViewSchedule> tablasMarcadas =
                ObtenerTablasMYG2027DelPresupuesto(
                    todasLasTablas,
                    ProjectId,
                    PresupuestoIdActual);

            List<RevitDB.ViewSchedule> tablasLegacy =
                ObtenerTablasLegacyCoincidentes(
                    configsListas,
                    tablasMarcadas,
                    todasLasTablas);

            // Guardar IDs estables ANTES de comenzar a borrar/recrear vistas.
            // Un objeto ViewSchedule de la API queda inválido después de
            // doc.Delete(). Si luego se vuelve a consultar existente.Id,
            // existente.Name, etc., Revit puede lanzar:
            // "The referenced object is not valid...".
            // Trabajar con ElementId y volver a obtener la vista desde el
            // documento evita conservar wrappers muertos entre partidas.
            List<RevitDB.ElementId> idsTablasMarcadasOriginales =
                tablasMarcadas
                    .Where(
                        x =>
                            x != null)
                    .Select(
                        x =>
                            x.Id)
                    .Distinct()
                    .ToList();

            List<RevitDB.ElementId> idsTablasLegacyOriginales =
                tablasLegacy
                    .Where(
                        x =>
                            x != null)
                    .Select(
                        x =>
                            x.Id)
                    .Distinct()
                    .ToList();


            // =======================================
            // INDICES DE TABLAS EXISTENTES
            //
            // Antes, por CADA partida nueva se recorrían TODAS las tablas
            // MYG existentes y se volvía a leer su Extensible Storage.
            // Con N tablas eso se convertía en un trabajo O(N²).
            //
            // Ahora cada tabla existente se inspecciona UNA sola vez y luego
            // las búsquedas son directas por clave o por nombre.
            // =======================================
            var idsMarcadasPorClave =
                new Dictionary<string, List<RevitDB.ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            var idsMarcadasPorNombre =
                new Dictionary<string, List<RevitDB.ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            var claveMarcadaPorId =
                new Dictionary<long, string>();

            foreach (
                RevitDB.ViewSchedule schedule
                in tablasMarcadas)
            {
                if (schedule == null)
                    continue;

                string clave =
                    ObtenerPartidaKeyTablaMYG2027(
                        schedule);

                claveMarcadaPorId[
                    schedule.Id.Value] =
                        clave;

                if (!string.IsNullOrWhiteSpace(
                        clave))
                {
                    if (!idsMarcadasPorClave.TryGetValue(
                            clave,
                            out List<RevitDB.ElementId> listaClave))
                    {
                        listaClave =
                            new List<RevitDB.ElementId>();

                        idsMarcadasPorClave[
                            clave] =
                                listaClave;
                    }

                    listaClave.Add(
                        schedule.Id);
                }

                string nombre =
                    schedule.Name ??
                    "";

                if (!idsMarcadasPorNombre.TryGetValue(
                        nombre,
                        out List<RevitDB.ElementId> listaNombre))
                {
                    listaNombre =
                        new List<RevitDB.ElementId>();

                    idsMarcadasPorNombre[
                        nombre] =
                            listaNombre;
                }

                listaNombre.Add(
                    schedule.Id);
            }

            var idsLegacyPorNombre =
                new Dictionary<string, List<RevitDB.ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (
                RevitDB.ViewSchedule schedule
                in tablasLegacy)
            {
                if (schedule == null)
                    continue;

                string nombre =
                    schedule.Name ??
                    "";

                if (!idsLegacyPorNombre.TryGetValue(
                        nombre,
                        out List<RevitDB.ElementId> lista))
                {
                    lista =
                        new List<RevitDB.ElementId>();

                    idsLegacyPorNombre[
                        nombre] =
                            lista;
                }

                lista.Add(
                    schedule.Id);
            }

            if (tablasLegacy.Count > 0)
            {
                string lista =
                    string.Join(
                        "\n",
                        tablasLegacy
                            .Take(
                                15)
                            .Select(
                                x =>
                                    "• " +
                                    x.Name));

                if (tablasLegacy.Count > 15)
                {
                    lista +=
                        "\n• ... y " +
                        (tablasLegacy.Count - 15) +
                        " más";
                }

                RevitUI.TaskDialog dialog =
                    new RevitUI.TaskDialog(
                        "Tablas MYG_2027 antiguas");

                dialog.MainInstruction =
                    "Se encontraron tablas antiguas sin marca interna MYG_2027.";

                dialog.MainContent =
                    "Estas tablas coinciden con partidas LISTO que vas a sincronizar:\n\n" +
                    lista +
                    "\n\nSi fueron creadas por MYG_2027, pulsa SÍ para reemplazarlas y marcarlas correctamente.\n\n" +
                    "Si alguna es una tabla manual que deseas conservar, pulsa NO. No se realizará ningún cambio.";

                dialog.CommonButtons =
                    RevitUI.TaskDialogCommonButtons.Yes |
                    RevitUI.TaskDialogCommonButtons.No;

                dialog.DefaultButton =
                    RevitUI.TaskDialogResult.No;

                if (dialog.Show() !=
                    RevitUI.TaskDialogResult.Yes)
                {
                    RevitUI.TaskDialog.Show(
                        "Tablas Automáticas",
                        "Sincronización cancelada.\n\nNo se eliminó ni modificó ninguna tabla.");

                    return;
                }
            }

            // Las tablas asociadas a configuraciones con ALERTA/ERROR
            // deben quedar fuera de cualquier eliminación.
            //
            // Misma regla anterior, pero las claves/nombres bloqueados se
            // calculan una sola vez en vez de recorrer todas las configs
            // bloqueadas por cada ViewSchedule.
            HashSet<string> clavesBloqueadas =
                new HashSet<string>(
                    configsBloqueadas
                        .Select(
                            cfg =>
                                claveCfgCache[
                                    cfg])
                        .Where(
                            x =>
                                !string.IsNullOrWhiteSpace(
                                    x)),
                    StringComparer.OrdinalIgnoreCase);

            HashSet<string> nombresBloqueados =
                new HashSet<string>(
                    configsBloqueadas
                        .Select(
                            cfg =>
                                nombreCfgCache[
                                    cfg])
                        .Where(
                            x =>
                                !string.IsNullOrWhiteSpace(
                                    x)),
                    StringComparer.OrdinalIgnoreCase);

            HashSet<RevitDB.ElementId> idsPotencialmenteEliminables =
                new HashSet<RevitDB.ElementId>();

            foreach (
                RevitDB.ViewSchedule schedule
                in tablasMarcadas)
            {
                if (schedule == null)
                    continue;

                string claveTabla =
                    ObtenerPartidaKeyTablaMYG2027(
                        schedule);

                bool protegidaPorClave =
                    !string.IsNullOrWhiteSpace(
                        claveTabla) &&
                    clavesBloqueadas.Contains(
                        claveTabla);

                bool protegidaPorNombre =
                    !protegidaPorClave &&
                    EsNombreTablaDeAlgunaPartida(
                        schedule.Name,
                        nombresBloqueados);

                if (protegidaPorClave ||
                    protegidaPorNombre)
                {
                    continue;
                }

                idsPotencialmenteEliminables.Add(
                    schedule.Id);
            }

            foreach (
                RevitDB.ViewSchedule schedule
                in tablasLegacy)
            {
                if (schedule != null)
                {
                    idsPotencialmenteEliminables.Add(
                        schedule.Id);
                }
            }

            RevitDB.View vistaActivaAnterior =
                uidoc.ActiveView;

            RevitDB.ElementId idVistaActivaAnterior =
                vistaActivaAnterior?.Id;

            bool seCambioVistaActiva =
                vistaActivaAnterior != null &&
                idsPotencialmenteEliminables.Contains(
                    vistaActivaAnterior.Id);

            string nombreVistaAReabrir =
                ObtenerNombreTablaNuevaEquivalente(
                    vistaActivaAnterior,
                    configsListas);

            if (seCambioVistaActiva &&
                !IntentarAbrirVistaSegura(
                    uidoc,
                    idsPotencialmenteEliminables))
            {
                RevitUI.TaskDialog.Show(
                    "Tablas Automáticas",
                    "La tabla que se intenta reemplazar está abierta como vista activa y no se encontró otra vista segura.\n\n" +
                    "Abre una planta, una vista 3D o una lámina y vuelve a ejecutar CREAR TABLAS.");

                return;
            }

            int reemplazadas =
                0;

            int creadas =
                0;

            int retiradas =
                0;

            int fallidasDuranteCreacion =
                0;

            using (
                RevitDB.Transaction trans =
                    new RevitDB.Transaction(
                        doc,
                        "Sincronizar tablas MYG_2027"))
            {
                try
                {
                    trans.Start();

                    Autodesk.Revit.DB.ExtensibleStorage.Schema schema =
                        ObtenerOCrearSchemaMYG2027();

                    HashSet<string> clavesActuales =
                        new HashSet<string>(
                            claveCfgCache
                                .Values
                                .Where(
                                    x =>
                                        !string.IsNullOrWhiteSpace(
                                            x)),
                            StringComparer.OrdinalIgnoreCase);

                    foreach (
                        ConfiguracionTablaPlanificacion cfg
                        in configsListas
                            .OrderBy(
                                x =>
                                    x.Plantilla,
                                StringComparer.OrdinalIgnoreCase)
                            .ThenBy(
                                x =>
                                    x.Item,
                                StringComparer.OrdinalIgnoreCase))
                    {
                        string claveCfg =
                            claveCfgCache[
                                cfg];

                        ResultadoValidacionRevitPartida resultado =
                            resultadoPorClave[
                                claveCfg];

                        using (
                            RevitDB.SubTransaction sub =
                                new RevitDB.SubTransaction(
                                    doc))
                        {
                            try
                            {
                                sub.Start();

                                string nombreTabla =
                                    nombreCfgCache[
                                        cfg];

                                HashSet<RevitDB.ElementId> idsReemplazar =
                                    new HashSet<RevitDB.ElementId>();

                                // 1. Coincidencia directa por identidad BIM.
                                if (!string.IsNullOrWhiteSpace(
                                        claveCfg) &&
                                    idsMarcadasPorClave.TryGetValue(
                                        claveCfg,
                                        out List<RevitDB.ElementId> porClave))
                                {
                                    foreach (
                                        RevitDB.ElementId id
                                        in porClave)
                                    {
                                        idsReemplazar.Add(
                                            id);
                                    }
                                }

                                // 2. Conflicto stale con el mismo nombre.
                                if (idsMarcadasPorNombre.TryGetValue(
                                        nombreTabla,
                                        out List<RevitDB.ElementId> porNombre))
                                {
                                    foreach (
                                        RevitDB.ElementId id
                                        in porNombre)
                                    {
                                        claveMarcadaPorId.TryGetValue(
                                            id.Value,
                                            out string claveExistente);

                                        if (!clavesActuales.Contains(
                                                claveExistente ?? ""))
                                        {
                                            idsReemplazar.Add(
                                                id);
                                        }
                                    }
                                }

                                // 3. Tabla legacy del mismo nombre.
                                if (idsLegacyPorNombre.TryGetValue(
                                        nombreTabla,
                                        out List<RevitDB.ElementId> legacyMismoNombre))
                                {
                                    foreach (
                                        RevitDB.ElementId id
                                        in legacyMismoNombre)
                                    {
                                        idsReemplazar.Add(
                                            id);
                                    }
                                }

                                if (idsReemplazar.Count > 0)
                                {
                                    doc.Delete(
                                        idsReemplazar.ToList());

                                    // No regenerar aquí. Revit ya registra los
                                    // elementos como eliminados dentro de la
                                    // SubTransaction. Regenerate por cada tabla
                                    // era extremadamente costoso.
                                }

                                RevitDB.ViewSchedule plantilla =
                                    plantillasPorNombre[
                                        cfg.Plantilla.Trim()];

                                RevitDB.ElementId nuevaId =
                                    plantilla.Duplicate(
                                        RevitDB.ViewDuplicateOption.Duplicate);

                                RevitDB.ViewSchedule schedule =
                                    doc.GetElement(
                                        nuevaId)
                                    as RevitDB.ViewSchedule;

                                if (schedule == null)
                                {
                                    throw new InvalidOperationException(
                                        "No se pudo obtener la tabla duplicada.");
                                }

                                schedule.Name =
                                    nombreTabla;

                                RevitDB.ScheduleDefinition definition =
                                    schedule.Definition;

                                for (
                                    int i =
                                        definition.GetFilterCount() - 1;
                                    i >= 0;
                                    i--)
                                {
                                    definition.RemoveFilter(
                                        i);
                                }

                                AplicarFiltrosConfiguracionRevit(
                                    doc,
                                    schedule,
                                    cfg);

                                MarcarTablaComoMYG2027(
                                    schedule,
                                    schema,
                                    cfg,
                                    ProjectId,
                                    PresupuestoIdActual);

                                sub.Commit();

                                reemplazadas +=
                                    idsReemplazar.Count;

                                creadas++;
                            }
                            catch (Exception ex)
                            {
                                try
                                {
                                    if (sub.GetStatus() ==
                                        RevitDB.TransactionStatus.Started)
                                    {
                                        sub.RollBack();
                                    }
                                }
                                catch
                                {
                                }

                                fallidasDuranteCreacion++;

                                AgregarErrorResultadoRevit(
                                    resultado,
                                    "Durante la sincronización Revit rechazó esta tabla. Se restauró su estado anterior y se continuó con las demás. " +
                                    ex.Message);
                            }
                        }
                    }

                    // ---------------------------------------
                    // LIMPIEZA DE TABLAS OBSOLETAS
                    // Solo se retiran tablas MYG cuya partida ya no tiene
                    // configuración BIM. Las ALERTA/ERROR sí están dentro de
                    // configsActuales y por eso se conservan.
                    // ---------------------------------------
                    using (
                        RevitDB.SubTransaction subLimpieza =
                            new RevitDB.SubTransaction(
                                doc))
                    {
                        try
                        {
                            subLimpieza.Start();

                            var idsObsoletos =
                                new List<RevitDB.ElementId>();

                            foreach (
                                RevitDB.ElementId idOriginal
                                in idsTablasMarcadasOriginales)
                            {
                                RevitDB.ViewSchedule existente =
                                    doc.GetElement(
                                        idOriginal)
                                    as RevitDB.ViewSchedule;

                                if (existente == null)
                                {
                                    continue;
                                }

                                if (!TablaCorrespondeAAlgunaConfiguracion(
                                        existente,
                                        configsActuales))
                                {
                                    idsObsoletos.Add(
                                        idOriginal);
                                }
                            }

                            idsObsoletos =
                                idsObsoletos
                                    .Distinct()
                                    .ToList();

                            if (idsObsoletos.Count > 0)
                            {
                                doc.Delete(
                                    idsObsoletos);

                                retiradas =
                                    idsObsoletos.Count;
                            }

                            subLimpieza.Commit();
                        }
                        catch
                        {
                            try
                            {
                                if (subLimpieza.GetStatus() ==
                                    RevitDB.TransactionStatus.Started)
                                {
                                    subLimpieza.RollBack();
                                }
                            }
                            catch
                            {
                            }
                        }
                    }

                    trans.Commit();
                }
                catch (Exception ex)
                {
                    try
                    {
                        if (trans.GetStatus() ==
                            RevitDB.TransactionStatus.Started)
                        {
                            trans.RollBack();
                        }
                    }
                    catch
                    {
                    }

                    RestaurarVistaAnteriorTrasRollback(
                        uidoc,
                        idVistaActivaAnterior,
                        seCambioVistaActiva);

                    RevitUI.TaskDialog.Show(
                        "Tablas Automáticas - Error",
                        "No se pudo completar la transacción general de sincronización.\n\n" +
                        "Se hizo rollback de esta ejecución, por lo que las tablas anteriores se conservan.\n\n" +
                        ex.Message);

                    return;
                }
            }

            if (seCambioVistaActiva)
            {
                AbrirTablaNuevaEquivalente(
                    uidoc,
                    doc,
                    nombreVistaAReabrir);
            }

            int alertas =
                resultados.Count(
                    x =>
                        x != null &&
                        string.Equals(
                            x.Estado,
                            "ALERTA",
                            StringComparison.OrdinalIgnoreCase));

            int errores =
                resultados.Count(
                    x =>
                        x != null &&
                        string.Equals(
                            x.Estado,
                            "ERROR",
                            StringComparison.OrdinalIgnoreCase));

            relojSincronizacion.Stop();

            if (relojProcesoCompleto != null &&
                relojProcesoCompleto.IsRunning)
            {
                relojProcesoCompleto.Stop();
            }

            double segundosValidacion =
                tiempoValidacionPrevia.HasValue
                ? tiempoValidacionPrevia.Value.TotalSeconds
                : 0.0;

            double segundosSincronizacion =
                relojSincronizacion.Elapsed.TotalSeconds;

            double segundosTotal =
                relojProcesoCompleto != null
                ? relojProcesoCompleto.Elapsed.TotalSeconds
                : segundosValidacion +
                  segundosSincronizacion;

            RevitUI.TaskDialog.Show(
                "Tablas Automáticas",
                "Sincronización completada.\n\n" +
                "Tablas creadas / actualizadas: " +
                creadas +
                "\nTablas anteriores reemplazadas: " +
                reemplazadas +
                "\nTablas obsoletas retiradas: " +
                retiradas +
                "\nConfiguraciones con ALERTA: " +
                alertas +
                "\nConfiguraciones con ERROR: " +
                errores +
                (fallidasDuranteCreacion > 0
                    ? "\nFallos detectados durante la creación: " +
                      fallidasDuranteCreacion
                    : "") +
                "\n\nTIEMPOS:" +
                "\nTiempo total real: " +
                segundosTotal.ToString(
                    "0.0",
                    CultureInfo.InvariantCulture) +
                " s" +
                "\nValidación Revit: " +
                segundosValidacion.ToString(
                    "0.0",
                    CultureInfo.InvariantCulture) +
                " s" +
                (validacionDesdeCache
                    ? " (caché)"
                    : "") +
                "\nCreación / sincronización: " +
                segundosSincronizacion.ToString(
                    "0.0",
                    CultureInfo.InvariantCulture) +
                " s" +
                "\n\nLas partidas con ALERTA o ERROR fueron omitidas y sus tablas anteriores se conservaron.\n" +
                "Las tablas manuales sin marca MYG_2027 no fueron modificadas.");
        }


        private void AplicarFiltrosConfiguracionRevit(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            ConfiguracionTablaPlanificacion cfg)
        {
            RevitDB.ScheduleDefinition definition =
                schedule.Definition;

            List<FiltroPlanificacion> filtros =
                (cfg?.ObtenerFiltros() ??
                 new List<FiltroPlanificacion>())
                    .Where(
                        x =>
                            x != null &&
                            !x.EstaVacio())
                    .Take(
                        8)
                    .ToList();

            foreach (
                FiltroPlanificacion filtroCfg
                in filtros)
            {
                if (string.IsNullOrWhiteSpace(
                        filtroCfg.Parametro))
                {
                    throw new InvalidOperationException(
                        "Existe un filtro sin PARÁMETRO.");
                }

                if (string.IsNullOrWhiteSpace(
                        filtroCfg.Regla))
                {
                    throw new InvalidOperationException(
                        "Existe un filtro sin REGLA.");
                }

                if (ReglaRequiereValor(
                        filtroCfg.Regla) &&
                    string.IsNullOrWhiteSpace(
                        filtroCfg.Valor))
                {
                    throw new InvalidOperationException(
                        "La regla '" +
                        filtroCfg.Regla +
                        "' necesita un VALOR.");
                }

                RevitDB.ScheduleField field =
                    BuscarOCrearCampo(
                        schedule,
                        doc,
                        filtroCfg.Parametro);

                if (field == null)
                {
                    throw new InvalidOperationException(
                        "No se encontró el parámetro '" +
                        filtroCfg.Parametro +
                        "' en la plantilla '" +
                        (cfg.Plantilla ?? "") +
                        "'.");
                }

                RevitDB.ScheduleFilterType tipo =
                    ConvertirRegla(
                        filtroCfg.Regla);

                RevitDB.ScheduleFilter filtroRevit;

                if (tipo ==
                        RevitDB.ScheduleFilterType.HasParameter ||
                    tipo ==
                        RevitDB.ScheduleFilterType.HasValue ||
                    tipo ==
                        RevitDB.ScheduleFilterType.HasNoValue)
                {
                    filtroRevit =
                        new RevitDB.ScheduleFilter(
                            field.FieldId,
                            tipo);
                }
                else
                {
                    filtroRevit =
                        CrearFiltroRevitConValorTipado(
                            doc,
                            schedule,
                            field,
                            filtroCfg.Parametro,
                            tipo,
                            filtroCfg.Valor);
                }

                definition.AddFilter(
                    filtroRevit);
            }
        }


        private bool TablaCorrespondeAAlgunaConfiguracion(
            RevitDB.ViewSchedule schedule,
            IEnumerable<ConfiguracionTablaPlanificacion> configuraciones)
        {
            if (schedule == null)
                return false;

            string claveTabla =
                ObtenerPartidaKeyTablaMYG2027(
                    schedule);

            foreach (
                ConfiguracionTablaPlanificacion cfg
                in configuraciones ??
                   Enumerable.Empty<ConfiguracionTablaPlanificacion>())
            {
                if (cfg == null)
                    continue;

                string claveCfg =
                    ObtenerClaveConfiguracion(
                        cfg);

                if (!string.IsNullOrWhiteSpace(
                        claveTabla) &&
                    !string.IsNullOrWhiteSpace(
                        claveCfg) &&
                    string.Equals(
                        claveTabla,
                        claveCfg,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                // Respaldo por nombre. También protege una tabla
                // anterior si la identidad de la partida cambió durante una
                // reconciliación, pero la configuración actual está en ALERTA.
                if (EsNombreTablaDePartida(
                        schedule.Name,
                        ConstruirNombreTablaBase(
                            cfg.Item,
                            cfg.Partida)))
                {
                    return true;
                }
            }

            return false;
        }


        private string ObtenerNombreTablaNuevaEquivalente(
            RevitDB.View vistaActiva,
            List<ConfiguracionTablaPlanificacion> configuraciones)
        {
            if (!(vistaActiva
                    is RevitDB.ViewSchedule tablaActiva))
            {
                return null;
            }

            ConfiguracionTablaPlanificacion equivalente =
                (configuraciones ??
                 new List<ConfiguracionTablaPlanificacion>())
                .FirstOrDefault(
                    cfg =>
                        cfg != null &&
                        EsNombreTablaDePartida(
                            tablaActiva.Name,
                            ConstruirNombreTablaBase(
                                cfg.Item,
                                cfg.Partida)));

            return
                equivalente == null
                ? tablaActiva.Name
                : ConstruirNombreTablaBase(
                    equivalente.Item,
                    equivalente.Partida);
        }


        private bool IntentarAbrirVistaSegura(
            RevitUI.UIDocument uidoc,
            HashSet<RevitDB.ElementId> idsExcluir)
        {
            if (uidoc == null ||
                uidoc.Document == null)
            {
                return false;
            }

            List<RevitDB.View> candidatas =
                new RevitDB.FilteredElementCollector(
                    uidoc.Document)
                    .OfClass(
                        typeof(RevitDB.View))
                    .Cast<RevitDB.View>()
                    .Where(
                        vista =>
                            vista != null &&
                            !vista.IsTemplate &&
                            (idsExcluir == null ||
                             !idsExcluir.Contains(
                                 vista.Id)))
                    .OrderBy(
                        PrioridadVistaSegura)
                    .ThenBy(
                        vista =>
                            vista.Name,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();

            foreach (
                RevitDB.View vista
                in candidatas)
            {
                try
                {
                    uidoc.ActiveView =
                        vista;

                    if (uidoc.ActiveView != null &&
                        uidoc.ActiveView.Id.Value ==
                            vista.Id.Value)
                    {
                        return true;
                    }
                }
                catch
                {
                    // Algunas vistas internas aparecen en el collector,
                    // pero no pueden activarse. Probar con la siguiente.
                }
            }

            return false;
        }


        private int PrioridadVistaSegura(
            RevitDB.View vista)
        {
            if (vista is RevitDB.View3D)
                return 0;

            if (vista is RevitDB.ViewPlan)
                return 1;

            if (vista is RevitDB.ViewSheet)
                return 2;

            if (vista is RevitDB.ViewSchedule)
                return 3;

            return 4;
        }


        private void RestaurarVistaAnteriorTrasRollback(
            RevitUI.UIDocument uidoc,
            RevitDB.ElementId idVistaAnterior,
            bool seCambioVista)
        {
            if (!seCambioVista ||
                uidoc == null ||
                uidoc.Document == null ||
                idVistaAnterior == null)
            {
                return;
            }

            try
            {
                RevitDB.View vistaRestaurada =
                    uidoc.Document.GetElement(
                        idVistaAnterior)
                    as RevitDB.View;

                if (vistaRestaurada != null &&
                    !vistaRestaurada.IsTemplate)
                {
                    uidoc.ActiveView =
                        vistaRestaurada;
                }
            }
            catch
            {
            }
        }


        private void AbrirTablaNuevaEquivalente(
            RevitUI.UIDocument uidoc,
            RevitDB.Document doc,
            string nombreTabla)
        {
            if (uidoc == null ||
                doc == null ||
                string.IsNullOrWhiteSpace(
                    nombreTabla))
            {
                return;
            }

            try
            {
                RevitDB.ViewSchedule nuevaTabla =
                    new RevitDB.FilteredElementCollector(
                        doc)
                        .OfClass(
                            typeof(RevitDB.ViewSchedule))
                        .Cast<RevitDB.ViewSchedule>()
                        .FirstOrDefault(
                            tabla =>
                                tabla != null &&
                                !tabla.IsTemplate &&
                                string.Equals(
                                    tabla.Name,
                                    nombreTabla,
                                    StringComparison.OrdinalIgnoreCase));

                if (nuevaTabla != null)
                {
                    uidoc.ActiveView =
                        nuevaTabla;
                }
            }
            catch
            {
                // La sincronización ya se completó. Si Revit no permite
                // activar la tabla en ese instante, mantener la vista segura.
            }
        }


        // =======================================
        // EXTENSIBLE STORAGE MYG_2027
        // =======================================
        private static readonly Guid
            MYG2027_SCHEMA_GUID =
                new Guid(
                    "C70C4C4F-2EEA-4E55-90B3-5F91B8B8F127");

        private const string
            MYG2027_SCHEMA_NAME =
                "MYG2027ManagedSchedule";

        private const string
            MYG2027_CREATED_BY =
                "MYG_2027";


        private Autodesk.Revit.DB.ExtensibleStorage.Schema
            ObtenerOCrearSchemaMYG2027()
        {
            Autodesk.Revit.DB.ExtensibleStorage.Schema schema =
                Autodesk.Revit.DB.ExtensibleStorage.Schema.Lookup(
                    MYG2027_SCHEMA_GUID);

            if (schema != null)
            {
                return
                    schema;
            }

            Autodesk.Revit.DB.ExtensibleStorage.SchemaBuilder builder =
                new Autodesk.Revit.DB.ExtensibleStorage.SchemaBuilder(
                    MYG2027_SCHEMA_GUID);

            builder.SetSchemaName(
                MYG2027_SCHEMA_NAME);

            builder.SetReadAccessLevel(
                Autodesk.Revit.DB.ExtensibleStorage.AccessLevel.Public);

            builder.SetWriteAccessLevel(
                Autodesk.Revit.DB.ExtensibleStorage.AccessLevel.Public);

            builder.AddSimpleField(
                "CreadoPor",
                typeof(string));

            builder.AddSimpleField(
                "ProjectId",
                typeof(string));

            builder.AddSimpleField(
                "PresupuestoId",
                typeof(string));

            builder.AddSimpleField(
                "PartidaKey",
                typeof(string));

            builder.AddSimpleField(
                "IdInternoDelphin",
                typeof(string));

            builder.AddSimpleField(
                "IdPropuesta",
                typeof(string));

            builder.AddSimpleField(
                "Version",
                typeof(int));

            return
                builder.Finish();
        }


        private void MarcarTablaComoMYG2027(
            RevitDB.ViewSchedule schedule,
            Autodesk.Revit.DB.ExtensibleStorage.Schema schema,
            ConfiguracionTablaPlanificacion cfg,
            string projectId,
            string presupuestoId)
        {
            if (schedule == null ||
                schema == null ||
                cfg == null)
            {
                return;
            }

            string partidaKey =
                !string.IsNullOrWhiteSpace(
                    cfg.IdInternoDelphin)
                ? cfg.IdInternoDelphin
                : (
                    !string.IsNullOrWhiteSpace(
                        cfg.IdPropuesta)
                    ? cfg.IdPropuesta
                    : cfg.IdInterno
                  );

            Autodesk.Revit.DB.ExtensibleStorage.Entity entity =
                new Autodesk.Revit.DB.ExtensibleStorage.Entity(
                    schema);

            entity.Set<string>(
                schema.GetField(
                    "CreadoPor"),
                MYG2027_CREATED_BY);

            entity.Set<string>(
                schema.GetField(
                    "ProjectId"),
                projectId ?? "");

            entity.Set<string>(
                schema.GetField(
                    "PresupuestoId"),
                presupuestoId ?? "");

            entity.Set<string>(
                schema.GetField(
                    "PartidaKey"),
                partidaKey ?? "");

            entity.Set<string>(
                schema.GetField(
                    "IdInternoDelphin"),
                cfg.IdInternoDelphin ?? "");

            entity.Set<string>(
                schema.GetField(
                    "IdPropuesta"),
                cfg.IdPropuesta ?? "");

            entity.Set<int>(
                schema.GetField(
                    "Version"),
                1);

            schedule.SetEntity(
                entity);
        }


        private bool EsTablaMYG2027DelPresupuesto(
            RevitDB.ViewSchedule schedule,
            string projectId,
            string presupuestoId)
        {
            if (schedule == null)
                return false;

            long id =
                schedule.Id.Value;

            if (_esTablaMYGPresupuestoEjecucionCache.TryGetValue(
                    id,
                    out bool cache))
            {
                return cache;
            }

            bool resultado =
                false;

            try
            {
                Autodesk.Revit.DB.ExtensibleStorage.Schema schema =
                    ObtenerSchemaMYGLecturaRapida();

                if (schema != null &&
                    _schemaFieldCreadoPorCache != null &&
                    _schemaFieldProjectIdCache != null &&
                    _schemaFieldPresupuestoIdCache != null)
                {
                    Autodesk.Revit.DB.ExtensibleStorage.Entity entity =
                        schedule.GetEntity(
                            schema);

                    if (entity != null &&
                        entity.IsValid())
                    {
                        string creadoPor =
                            entity.Get<string>(
                                _schemaFieldCreadoPorCache);

                        string projectGuardado =
                            entity.Get<string>(
                                _schemaFieldProjectIdCache);

                        string presupuestoGuardado =
                            entity.Get<string>(
                                _schemaFieldPresupuestoIdCache);

                        resultado =
                            string.Equals(
                                creadoPor,
                                MYG2027_CREATED_BY,
                                StringComparison.OrdinalIgnoreCase) &&
                            string.Equals(
                                projectGuardado ?? "",
                                projectId ?? "",
                                StringComparison.OrdinalIgnoreCase) &&
                            string.Equals(
                                presupuestoGuardado ?? "",
                                presupuestoId ?? "",
                                StringComparison.OrdinalIgnoreCase);
                    }
                }
            }
            catch
            {
                resultado =
                    false;
            }

            _esTablaMYGPresupuestoEjecucionCache[
                id] =
                    resultado;

            return resultado;
        }


        private string ObtenerPartidaKeyTablaMYG2027(
            RevitDB.ViewSchedule schedule)
        {
            if (schedule == null)
                return "";

            long id =
                schedule.Id.Value;

            if (_partidaKeyTablaEjecucionCache.TryGetValue(
                    id,
                    out string cache))
            {
                return cache ?? "";
            }

            string resultado =
                "";

            try
            {
                Autodesk.Revit.DB.ExtensibleStorage.Schema schema =
                    ObtenerSchemaMYGLecturaRapida();

                if (schema != null &&
                    _schemaFieldPartidaKeyCache != null)
                {
                    Autodesk.Revit.DB.ExtensibleStorage.Entity entity =
                        schedule.GetEntity(
                            schema);

                    if (entity != null &&
                        entity.IsValid())
                    {
                        resultado =
                            (entity.Get<string>(
                                _schemaFieldPartidaKeyCache) ?? "")
                                .Trim();
                    }
                }
            }
            catch
            {
                resultado =
                    "";
            }

            _partidaKeyTablaEjecucionCache[
                id] =
                    resultado;

            return resultado;
        }


        private List<RevitDB.ViewSchedule>
            ObtenerTablasMYG2027DelPresupuesto(
                IEnumerable<RevitDB.ViewSchedule> tablas,
                string projectId,
                string presupuestoId)
        {
            return
                (tablas ??
                 Enumerable.Empty<RevitDB.ViewSchedule>())
                    .Where(
                        x =>
                            x != null &&
                            !x.IsTemplate &&
                            EsTablaMYG2027DelPresupuesto(
                                x,
                                projectId,
                                presupuestoId))
                    .ToList();
        }


        // =======================================
        // MIGRACIÓN DE TABLAS CREADAS ANTES DE
        // IMPLEMENTAR EXTENSIBLE STORAGE
        // =======================================
        private List<RevitDB.ViewSchedule>
            ObtenerTablasLegacyCoincidentes(
                List<ConfiguracionTablaPlanificacion> configuraciones,
                List<RevitDB.ViewSchedule> yaMarcadas,
                IEnumerable<RevitDB.ViewSchedule> tablas)
        {
            HashSet<long> idsMarcadas =
                new HashSet<long>(
                    (yaMarcadas ??
                     new List<RevitDB.ViewSchedule>())
                    .Where(
                        x =>
                            x != null)
                    .Select(
                        x =>
                            x.Id.Value));

            HashSet<string> nombresBase =
                new HashSet<string>(
                    (configuraciones ??
                     new List<ConfiguracionTablaPlanificacion>())
                    .Where(
                        x =>
                            x != null)
                    .Select(
                        x =>
                            ConstruirNombreTablaBase(
                                x.Item,
                                x.Partida))
                    .Where(
                        x =>
                            !string.IsNullOrWhiteSpace(
                                x)),
                    StringComparer.OrdinalIgnoreCase);

            if (nombresBase.Count == 0)
            {
                return
                    new List<RevitDB.ViewSchedule>();
            }

            return
                (tablas ??
                 Enumerable.Empty<RevitDB.ViewSchedule>())
                    .Where(
                        schedule =>
                            schedule != null &&
                            !schedule.IsTemplate &&
                            !idsMarcadas.Contains(
                                schedule.Id.Value) &&
                            EsNombreTablaDeAlgunaPartida(
                                schedule.Name,
                                nombresBase))
                    .OrderBy(
                        x =>
                            x.Name)
                    .ToList();
        }

        private bool EsNombreTablaDeAlgunaPartida(
            string nombre,
            HashSet<string> nombresBase)
        {
            if (string.IsNullOrWhiteSpace(
                    nombre) ||
                nombresBase == null ||
                nombresBase.Count == 0)
            {
                return false;
            }

            if (nombresBase.Contains(
                    nombre))
            {
                return true;
            }

            Match version =
                Regex.Match(
                    nombre,
                    @"^(.*) \(\d+\)$");

            return
                version.Success &&
                nombresBase.Contains(
                    version.Groups[1].Value);
        }

        // =======================================
        // BUSCAR TABLA "PLANTILLA..."
        // =======================================
        private RevitDB.ViewSchedule BuscarPlantilla(
            RevitDB.Document doc,
            string nombre)
        {
            if (doc == null ||
                string.IsNullOrWhiteSpace(nombre))
            {
                return null;
            }

            return new RevitDB.FilteredElementCollector(doc)
                .OfClass(typeof(RevitDB.ViewSchedule))
                .Cast<RevitDB.ViewSchedule>()
                .FirstOrDefault(
                    x =>
                        !x.IsTemplate &&
                        string.Equals(
                            x.Name,
                            nombre.Trim(),
                            StringComparison.OrdinalIgnoreCase));
        }

        // =======================================
        // BUSCAR CAMPO EXISTENTE O AGREGARLO
        // =======================================
        private RevitDB.ScheduleField BuscarOCrearCampo(
            RevitDB.ViewSchedule schedule,
            RevitDB.Document doc,
            string nombreParametro)
        {
            if (schedule == null ||
                doc == null ||
                string.IsNullOrWhiteSpace(nombreParametro))
            {
                return null;
            }

            RevitDB.ScheduleDefinition definition =
                schedule.Definition;

            string objetivo =
                NormalizarTexto(nombreParametro);

            for (
                int i = 0;
                i < definition.GetFieldCount();
                i++)
            {
                RevitDB.ScheduleField field =
                    definition.GetField(i);

                string nombre;

                try
                {
                    nombre = field.GetName();
                }
                catch
                {
                    continue;
                }

                if (NormalizarTexto(nombre) ==
                    objetivo)
                {
                    return field;
                }
            }

            foreach (
                RevitDB.SchedulableField sf
                in definition.GetSchedulableFields())
            {
                string nombre;

                try
                {
                    nombre = sf.GetName(doc);
                }
                catch
                {
                    continue;
                }

                if (NormalizarTexto(nombre) ==
                    objetivo)
                {
                    return definition.AddField(sf);
                }
            }

            return null;
        }


        private string ObtenerClaveStorageTypeCampo(
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField field,
            string nombreParametro)
        {
            long categoria =
                long.MinValue;

            long parametro =
                long.MinValue;

            try
            {
                RevitDB.ElementId categoriaId =
                    schedule?.Definition?.CategoryId;

                if (categoriaId != null &&
                    categoriaId !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    categoria =
                        categoriaId.Value;
                }
            }
            catch
            {
            }

            try
            {
                RevitDB.ElementId parameterId =
                    field?.ParameterId;

                if (parameterId != null &&
                    parameterId !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    parametro =
                        parameterId.Value;
                }
            }
            catch
            {
            }

            string nombre =
                !string.IsNullOrWhiteSpace(
                    nombreParametro)
                ? nombreParametro.Trim()
                : "";

            if (string.IsNullOrWhiteSpace(
                    nombre))
            {
                try
                {
                    nombre =
                        field?.GetName() ??
                        "";
                }
                catch
                {
                }
            }

            return
                categoria.ToString(
                    CultureInfo.InvariantCulture) +
                "|" +
                parametro.ToString(
                    CultureInfo.InvariantCulture) +
                "|" +
                NormalizarValorFiltro(
                    nombre,
                    false);
        }


        // =======================================
        // CREAR FILTRO CON EL TIPO REAL DE REVIT
        //
        // El texto del ComboBox es exactamente lo que Revit muestra
        // (por ejemplo "20 mm"), pero ScheduleFilter necesita el valor
        // interno: double, int, ElementId o string según el campo.
        // =======================================
        private RevitDB.ScheduleFilter
            CrearFiltroRevitConValorTipado(
                RevitDB.Document doc,
                RevitDB.ViewSchedule schedule,
                RevitDB.ScheduleField field,
                string nombreParametro,
                RevitDB.ScheduleFilterType tipo,
                string valorMostrado)
        {
            if (doc == null ||
                schedule == null ||
                field == null)
            {
                throw new InvalidOperationException(
                    "No se pudo determinar el campo del filtro.");
            }

            string texto =
                (valorMostrado ?? "")
                    .Trim();

            // Los operadores de búsqueda textual solo son aplicables a
            // campos de texto en Revit. No hace falta recorrer todos los
            // elementos visibles de la tabla para volver a descubrir su
            // StorageType en cada duplicado.
            if (tipo ==
                    RevitDB.ScheduleFilterType.Contains ||
                tipo ==
                    RevitDB.ScheduleFilterType.NotContains ||
                tipo ==
                    RevitDB.ScheduleFilterType.BeginsWith ||
                tipo ==
                    RevitDB.ScheduleFilterType.NotBeginsWith ||
                tipo ==
                    RevitDB.ScheduleFilterType.EndsWith ||
                tipo ==
                    RevitDB.ScheduleFilterType.NotEndsWith)
            {
                return
                    new RevitDB.ScheduleFilter(
                        field.FieldId,
                        tipo,
                        texto);
            }

            // COUNT es entero y no siempre tiene un Parameter asociado.
            bool esCampoConteo =
                string.Equals(
                    field.FieldType.ToString(),
                    "Count",
                    StringComparison.OrdinalIgnoreCase);

            if (esCampoConteo)
            {
                if (int.TryParse(
                        texto,
                        NumberStyles.Integer,
                        CultureInfo.CurrentCulture,
                        out int conteo) ||
                    int.TryParse(
                        texto,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out conteo))
                {
                    return
                        new RevitDB.ScheduleFilter(
                            field.FieldId,
                            tipo,
                            conteo);
                }

                throw new InvalidOperationException(
                    "El valor '" +
                    texto +
                    "' no es un número entero válido para el campo '" +
                    field.GetName() +
                    "'.");
            }

            // Ruta rápida para el caso más frecuente en tablas BIM:
            // TIPO / FAMILIA Y TIPO. Antes, por cada partida se recorrían
            // otra vez las instancias de la tabla y después todos los tipos
            // cargados del documento. Ahora el índice de tipos de la categoría
            // se construye una sola vez.
            string nombreCampoRapido =
                NormalizarValorFiltro(
                    !string.IsNullOrWhiteSpace(
                        nombreParametro)
                    ? nombreParametro
                    : field.GetName(),
                    false);

            if (nombreCampoRapido == "TIPO" ||
                nombreCampoRapido == "FAMILIA Y TIPO")
            {
                RevitDB.ElementId idTipoRapido =
                    BuscarReferenciaElementIdPorTexto(
                        doc,
                        schedule,
                        field,
                        nombreParametro,
                        texto);

                if (idTipoRapido != null &&
                    idTipoRapido !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    return
                        new RevitDB.ScheduleFilter(
                            field.FieldId,
                            tipo,
                            idTipoRapido);
                }

                throw CrearErrorConversionFiltro(
                    field,
                    texto,
                    "referencia de Revit");
            }

            string claveStorage =
                ObtenerClaveStorageTypeCampo(
                    schedule,
                    field,
                    nombreParametro);

            if (_storageTypeCampoCache.TryGetValue(
                    claveStorage,
                    out RevitDB.StorageType storageCache) &&
                storageCache ==
                    RevitDB.StorageType.String)
            {
                return
                    new RevitDB.ScheduleFilter(
                        field.FieldId,
                        tipo,
                        texto);
            }

            RevitDB.Parameter parametroMuestra =
                ObtenerParametroMuestraCampo(
                    doc,
                    schedule,
                    field,
                    nombreParametro);

            if (parametroMuestra != null)
            {
                _storageTypeCampoCache[
                    claveStorage] =
                        parametroMuestra.StorageType;
                switch (parametroMuestra.StorageType)
                {
                    case RevitDB.StorageType.String:
                        return
                            new RevitDB.ScheduleFilter(
                                field.FieldId,
                                tipo,
                                texto);

                    case RevitDB.StorageType.Double:
                        RevitDB.Parameter doubleCoincidente =
                            BuscarParametroConValorMostrado(
                                doc,
                                schedule,
                                field,
                                nombreParametro,
                                texto);

                        if (doubleCoincidente != null &&
                            doubleCoincidente.StorageType ==
                                RevitDB.StorageType.Double)
                        {
                            return
                                new RevitDB.ScheduleFilter(
                                    field.FieldId,
                                    tipo,
                                    doubleCoincidente.AsDouble());
                        }

                        if (IntentarConvertirValorMedible(
                                doc,
                                field,
                                texto,
                                out double valorInterno))
                        {
                            return
                                new RevitDB.ScheduleFilter(
                                    field.FieldId,
                                    tipo,
                                    valorInterno);
                        }

                        throw CrearErrorConversionFiltro(
                            field,
                            texto,
                            "numérico con unidades");

                    case RevitDB.StorageType.Integer:
                        RevitDB.Parameter enteroCoincidente =
                            BuscarParametroConValorMostrado(
                                doc,
                                schedule,
                                field,
                                nombreParametro,
                                texto);

                        if (enteroCoincidente != null &&
                            enteroCoincidente.StorageType ==
                                RevitDB.StorageType.Integer)
                        {
                            return
                                new RevitDB.ScheduleFilter(
                                    field.FieldId,
                                    tipo,
                                    enteroCoincidente.AsInteger());
                        }

                        if (IntentarConvertirEntero(
                                texto,
                                out int valorEntero))
                        {
                            return
                                new RevitDB.ScheduleFilter(
                                    field.FieldId,
                                    tipo,
                                    valorEntero);
                        }

                        throw CrearErrorConversionFiltro(
                            field,
                            texto,
                            "entero");

                    case RevitDB.StorageType.ElementId:
                        RevitDB.Parameter idCoincidente =
                            BuscarParametroConValorMostrado(
                                doc,
                                schedule,
                                field,
                                nombreParametro,
                                texto);

                        if (idCoincidente != null &&
                            idCoincidente.StorageType ==
                                RevitDB.StorageType.ElementId)
                        {
                            return
                                new RevitDB.ScheduleFilter(
                                    field.FieldId,
                                    tipo,
                                    idCoincidente.AsElementId());
                        }

                        RevitDB.ElementId idReferenciaAlternativa =
                            BuscarReferenciaElementIdPorTexto(
                                doc,
                                schedule,
                                field,
                                nombreParametro,
                                texto);

                        if (idReferenciaAlternativa != null &&
                            idReferenciaAlternativa !=
                                RevitDB.ElementId.InvalidElementId)
                        {
                            return
                                new RevitDB.ScheduleFilter(
                                    field.FieldId,
                                    tipo,
                                    idReferenciaAlternativa);
                        }

                        throw CrearErrorConversionFiltro(
                            field,
                            texto,
                            "referencia de Revit");
                }
            }

            // Si la tabla está vacía puede no existir un Parameter de
            // muestra, pero campos como TIPO siguen siendo referencias
            // ElementId. Intentar resolver tipos/niveles/materiales cargados
            // en el documento aunque todavía no tengan instancias visibles.
            if (EsCampoReferenciaElementId(
                    doc,
                    schedule,
                    field,
                    nombreParametro))
            {
                RevitDB.ElementId idReferencia =
                    BuscarReferenciaElementIdPorTexto(
                        doc,
                        schedule,
                        field,
                        nombreParametro,
                        texto);

                if (idReferencia != null &&
                    idReferencia !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    return
                        new RevitDB.ScheduleFilter(
                            field.FieldId,
                            tipo,
                            idReferencia);
                }

                throw CrearErrorConversionFiltro(
                    field,
                    texto,
                    "referencia de Revit");
            }

            // Respaldo para tablas que incluyen vínculos o no devuelven
            // elementos mediante FilteredElementCollector(viewId).
            if (IntentarConvertirValorMedible(
                    doc,
                    field,
                    texto,
                    out double numeroSinMuestra))
            {
                return
                    new RevitDB.ScheduleFilter(
                        field.FieldId,
                        tipo,
                        numeroSinMuestra);
            }

            // Si no es un campo medible ni existe un Parameter de muestra,
            // conservar la compatibilidad con campos de texto normales.
            return
                new RevitDB.ScheduleFilter(
                    field.FieldId,
                    tipo,
                    texto);
        }


        private bool IntentarConvertirValorMedible(
            RevitDB.Document doc,
            RevitDB.ScheduleField field,
            string texto,
            out double valorInterno)
        {
            valorInterno =
                0.0;

            if (doc == null ||
                field == null ||
                string.IsNullOrWhiteSpace(
                    texto))
            {
                return false;
            }

            try
            {
                RevitDB.ForgeTypeId spec =
                    field.GetSpecTypeId();

                if (spec == null ||
                    !RevitDB.UnitUtils.IsMeasurableSpec(
                        spec))
                {
                    return false;
                }

                RevitDB.Units unidades =
                    doc.GetUnits();

                // =======================================
                // 1. SI EL CAMPO SE MUESTRA EN PULGADAS,
                //    RESPETAR PRIMERO ESE FORMATO VISUAL
                //
                // Esto es clave cuando Revit muestra valores SIN símbolo:
                //
                //      1/4
                //      3/8
                //      1
                //      1 1/8
                //
                // En ese caso un texto desnudo como "1" NO significa
                // "1 unidad del proyecto" (por ejemplo 1 mm), sino
                // exactamente 1 pulgada según el formato del campo.
                //
                // Sin esta comprobación, UnitFormatUtils.TryParse("1")
                // puede interpretarlo como 1 mm y Revit termina mostrando
                // aproximadamente 1/16".
                // =======================================
                if (CampoSeMuestraEnPulgadas(
                        doc,
                        field,
                        spec) &&
                    IntentarParsearPulgadasFraccionarias(
                        texto,
                        out double pulgadasCampo))
                {
                    valorInterno =
                        RevitDB.UnitUtils.ConvertToInternalUnits(
                            pulgadasCampo,
                            RevitDB.UnitTypeId.Inches);

                    return true;
                }

                // =======================================
                // 2. RUTA NORMAL DE REVIT
                // =======================================
                if (RevitDB.UnitFormatUtils.TryParse(
                        unidades,
                        spec,
                        texto,
                        out valorInterno))
                {
                    return true;
                }

                // Algunas plantillas ocultan el espacio entre número y
                // símbolo ("20mm"). Reintentar como "20 mm".
                string textoConEspacio =
                    Regex.Replace(
                        texto,
                        @"(?<=\d)(?=[A-Za-z°])",
                        " ");

                if (!string.Equals(
                        textoConEspacio,
                        texto,
                        StringComparison.Ordinal) &&
                    RevitDB.UnitFormatUtils.TryParse(
                        unidades,
                        spec,
                        textoConEspacio,
                        out valorInterno))
                {
                    return true;
                }

                // =======================================
                // 3. RESPALDO GENÉRICO PARA NOTACIÓN
                //    EXPLÍCITAMENTE FRACCIONARIA EN PULGADAS
                //
                // Para campos que admiten pulgadas pero NO están
                // configurados visualmente en pulgadas, solo activar este
                // respaldo si el usuario escribió una notación inequívoca
                // de fracción/pulgadas. Así evitamos interpretar, por
                // ejemplo, un "500" métrico como 500 pulgadas.
                // =======================================
                if (SpecAdmitePulgadas(
                        spec) &&
                    EsNotacionFraccionariaOExplicitaPulgadas(
                        texto) &&
                    IntentarParsearPulgadasFraccionarias(
                        texto,
                        out double pulgadas))
                {
                    valorInterno =
                        RevitDB.UnitUtils.ConvertToInternalUnits(
                            pulgadas,
                            RevitDB.UnitTypeId.Inches);

                    return true;
                }

                return false;
            }
            catch
            {
                valorInterno =
                    0.0;

                return false;
            }
        }


        private bool CampoSeMuestraEnPulgadas(
            RevitDB.Document doc,
            RevitDB.ScheduleField field,
            RevitDB.ForgeTypeId spec)
        {
            if (doc == null ||
                field == null ||
                spec == null)
            {
                return false;
            }

            try
            {
                RevitDB.FormatOptions opcionesCampo =
                    field.GetFormatOptions();

                if (opcionesCampo != null)
                {
                    RevitDB.ForgeTypeId unidadCampo =
                        opcionesCampo.GetUnitTypeId();

                    if (EsUnidadPulgadas(
                            unidadCampo))
                    {
                        return true;
                    }
                }
            }
            catch
            {
            }

            try
            {
                RevitDB.FormatOptions opcionesProyecto =
                    doc.GetUnits()
                        .GetFormatOptions(
                            spec);

                if (opcionesProyecto != null)
                {
                    RevitDB.ForgeTypeId unidadProyecto =
                        opcionesProyecto.GetUnitTypeId();

                    if (EsUnidadPulgadas(
                            unidadProyecto))
                    {
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }


        private bool EsUnidadPulgadas(
            RevitDB.ForgeTypeId unidad)
        {
            if (unidad == null)
                return false;

            try
            {
                string typeId =
                    unidad.TypeId ?? "";

                return
                    typeId.IndexOf(
                        "inch",
                        StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch
            {
                return false;
            }
        }


        private bool EsNotacionFraccionariaOExplicitaPulgadas(
            string texto)
        {
            if (string.IsNullOrWhiteSpace(
                    texto))
            {
                return false;
            }

            string valor =
                texto.Trim();

            return
                valor.Contains("/") ||
                valor.Contains("\"") ||
                valor.Contains("″") ||
                valor.Contains("”") ||
                Regex.IsMatch(
                    valor,
                    @"^\s*\d+\s*-\s*\d+\s*/\s*\d+\s*$");
        }


        private bool SpecAdmitePulgadas(
            RevitDB.ForgeTypeId spec)
        {
            if (spec == null)
                return false;

            try
            {
                IList<RevitDB.ForgeTypeId> unidadesValidas =
                    RevitDB.UnitUtils.GetValidUnits(
                        spec);

                if (unidadesValidas == null)
                    return false;

                foreach (
                    RevitDB.ForgeTypeId unidad
                    in unidadesValidas)
                {
                    if (unidad != null &&
                        unidad.Equals(
                            RevitDB.UnitTypeId.Inches))
                    {
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }


        private bool IntentarParsearPulgadasFraccionarias(
            string texto,
            out double pulgadas)
        {
            pulgadas =
                0.0;

            if (string.IsNullOrWhiteSpace(
                    texto))
            {
                return false;
            }

            string valor =
                texto
                    .Trim()
                    .Replace(
                        "″",
                        "")
                    .Replace(
                        "”",
                        "")
                    .Replace(
                        "\"",
                        "")
                    .Trim();

            // Aceptar también notación mixta:
            // 1-1/8  ->  1 1/8
            valor =
                Regex.Replace(
                    valor,
                    @"(?<=\d)\s*-\s*(?=\d+\s*/\s*\d+)",
                    " ");

            // =======================================
            // FRACCIÓN MIXTA: 1 1/8
            // =======================================
            Match mixta =
                Regex.Match(
                    valor,
                    @"^\s*(?<entero>\d+)\s+(?<num>\d+)\s*/\s*(?<den>\d+)\s*$");

            if (mixta.Success)
            {
                if (!double.TryParse(
                        mixta.Groups["entero"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out double entero) ||
                    !double.TryParse(
                        mixta.Groups["num"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out double numerador) ||
                    !double.TryParse(
                        mixta.Groups["den"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out double denominador) ||
                    Math.Abs(
                        denominador) <
                        1e-12)
                {
                    return false;
                }

                pulgadas =
                    entero +
                    numerador /
                    denominador;

                return true;
            }

            // =======================================
            // FRACCIÓN SIMPLE: 1/4, 3/8, 7/8...
            // =======================================
            Match simple =
                Regex.Match(
                    valor,
                    @"^\s*(?<num>\d+)\s*/\s*(?<den>\d+)\s*$");

            if (simple.Success)
            {
                if (!double.TryParse(
                        simple.Groups["num"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out double numerador) ||
                    !double.TryParse(
                        simple.Groups["den"].Value,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out double denominador) ||
                    Math.Abs(
                        denominador) <
                        1e-12)
                {
                    return false;
                }

                pulgadas =
                    numerador /
                    denominador;

                return true;
            }

            // =======================================
            // DECIMAL / ENTERO SIN SÍMBOLO:
            // Se usa SOLO como último respaldo y únicamente si el SPEC
            // admite pulgadas. UnitFormatUtils ya tuvo prioridad arriba.
            // =======================================
            string decimalNormalizado =
                valor.Replace(
                    ',',
                    '.');

            if (double.TryParse(
                    decimalNormalizado,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double decimalPulgadas))
            {
                pulgadas =
                    decimalPulgadas;

                return true;
            }

            return false;
        }


        private RevitDB.Parameter ObtenerParametroMuestraCampo(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField field,
            string nombreParametro)
        {
            if (doc == null ||
                schedule == null ||
                field == null)
            {
                return null;
            }

            try
            {
                foreach (
                    RevitDB.Element elemento
                    in new RevitDB.FilteredElementCollector(
                        doc,
                        schedule.Id)
                        .WhereElementIsNotElementType()
                        .Cast<RevitDB.Element>())
                {
                    RevitDB.Parameter parametro =
                        ObtenerParametroCampoFiltro(
                            doc,
                            elemento,
                            field,
                            nombreParametro);

                    if (parametro != null)
                    {
                        return parametro;
                    }
                }
            }
            catch
            {
            }

            return null;
        }


        private RevitDB.Parameter BuscarParametroConValorMostrado(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField field,
            string nombreParametro,
            string valorMostrado)
        {
            if (doc == null ||
                schedule == null ||
                field == null)
            {
                return null;
            }

            try
            {
                foreach (
                    RevitDB.Element elemento
                    in new RevitDB.FilteredElementCollector(
                        doc,
                        schedule.Id)
                        .WhereElementIsNotElementType()
                        .Cast<RevitDB.Element>())
                {
                    RevitDB.Parameter parametro =
                        ObtenerParametroCampoFiltro(
                            doc,
                            elemento,
                            field,
                            nombreParametro);

                    if (parametro != null &&
                        CoincideValorMostradoParametro(
                            doc,
                            parametro,
                            valorMostrado))
                    {
                        return parametro;
                    }
                }
            }
            catch
            {
            }

            return null;
        }


        private bool EsCampoReferenciaElementId(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField field,
            string nombreParametro)
        {
            RevitDB.Parameter muestraGlobal =
                ObtenerParametroMuestraCampoGlobal(
                    doc,
                    schedule,
                    field,
                    nombreParametro);

            if (muestraGlobal != null &&
                muestraGlobal.StorageType ==
                    RevitDB.StorageType.ElementId)
            {
                return true;
            }

            string nombre =
                NormalizarValorFiltro(
                    !string.IsNullOrWhiteSpace(
                        nombreParametro)
                    ? nombreParametro
                    : field?.GetName(),
                    false);

            return
                nombre == "TIPO" ||
                nombre == "FAMILIA Y TIPO" ||
                nombre == "FAMILIA" ||
                nombre == "NIVEL" ||
                nombre == "NIVEL BASE" ||
                nombre == "NIVEL SUPERIOR" ||
                nombre == "MATERIAL" ||
                nombre == "FASE" ||
                nombre == "TIPO DE SISTEMA" ||
                nombre == "SISTEMA";
        }


        private RevitDB.Parameter ObtenerParametroMuestraCampoGlobal(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField field,
            string nombreParametro)
        {
            if (doc == null ||
                schedule == null ||
                field == null)
            {
                return null;
            }

            RevitDB.ElementId categoriaId =
                null;

            try
            {
                categoriaId =
                    schedule.Definition.CategoryId;
            }
            catch
            {
            }

            try
            {
                RevitDB.FilteredElementCollector collector =
                    new RevitDB.FilteredElementCollector(
                        doc)
                        .WhereElementIsNotElementType();

                // Si la tabla es de una categoría concreta, pedirle a Revit
                // únicamente esa categoría. El código anterior recorría TODO
                // el documento y descartaba categorías en C#.
                if (categoriaId != null &&
                    categoriaId !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    try
                    {
                        collector =
                            collector.WherePasses(
                                new RevitDB.ElementCategoryFilter(
                                    categoriaId));
                    }
                    catch
                    {
                    }
                }

                foreach (
                    RevitDB.Element elemento
                    in collector.Cast<RevitDB.Element>())
                {
                    RevitDB.Parameter parametro =
                        ObtenerParametroCampoFiltro(
                            doc,
                            elemento,
                            field,
                            nombreParametro);

                    if (parametro != null)
                    {
                        return parametro;
                    }
                }
            }
            catch
            {
            }

            return null;
        }



        private void ConstruirIndicesTiposTodasCategorias(
            RevitDB.Document doc)
        {
            if (_indicesTiposTodasCategoriasConstruidos)
            {
                return;
            }

            _indicesTiposTodasCategoriasConstruidos =
                true;

            _indiceTiposPorCategoria.Clear();

            Dictionary<string, RevitDB.ElementId> indiceGlobal =
                new Dictionary<string, RevitDB.ElementId>(
                    StringComparer.OrdinalIgnoreCase);

            _indiceTiposPorCategoria[
                long.MinValue] =
                    indiceGlobal;

            if (doc == null)
            {
                return;
            }

            try
            {
                IEnumerable<RevitDB.ElementType> tipos =
                    new RevitDB.FilteredElementCollector(
                        doc)
                        .WhereElementIsElementType()
                        .Cast<RevitDB.ElementType>();

                foreach (
                    RevitDB.ElementType tipo
                    in tipos)
                {
                    if (tipo == null)
                        continue;

                    long categoriaKey =
                        long.MinValue;

                    try
                    {
                        RevitDB.Category categoria =
                            tipo.Category;

                        if (categoria != null &&
                            categoria.Id != null)
                        {
                            categoriaKey =
                                categoria.Id.Value;
                        }
                    }
                    catch
                    {
                    }

                    if (!_indiceTiposPorCategoria.TryGetValue(
                            categoriaKey,
                            out Dictionary<string, RevitDB.ElementId> indiceCategoria))
                    {
                        indiceCategoria =
                            new Dictionary<string, RevitDB.ElementId>(
                                StringComparer.OrdinalIgnoreCase);

                        _indiceTiposPorCategoria[
                            categoriaKey] =
                                indiceCategoria;
                    }

                    var candidatos =
                        new List<string>();

                    try
                    {
                        candidatos.Add(
                            tipo.Name);
                    }
                    catch
                    {
                    }

                    try
                    {
                        candidatos.Add(
                            tipo.FamilyName);

                        candidatos.Add(
                            (tipo.FamilyName ?? "") +
                            ": " +
                            (tipo.Name ?? ""));

                        candidatos.Add(
                            (tipo.FamilyName ?? "") +
                            " - " +
                            (tipo.Name ?? ""));
                    }
                    catch
                    {
                    }

                    foreach (
                        string candidato
                        in candidatos)
                    {
                        if (string.IsNullOrWhiteSpace(
                                candidato))
                        {
                            continue;
                        }

                        string clave =
                            NormalizarValorFiltro(
                                candidato,
                                false);

                        if (string.IsNullOrWhiteSpace(
                                clave))
                        {
                            continue;
                        }

                        if (!indiceGlobal.ContainsKey(
                                clave))
                        {
                            indiceGlobal[
                                clave] =
                                    tipo.Id;
                        }

                        if (!indiceCategoria.ContainsKey(
                                clave))
                        {
                            indiceCategoria[
                                clave] =
                                    tipo.Id;
                        }
                    }
                }
            }
            catch
            {
            }
        }


        private Dictionary<string, RevitDB.ElementId>
            ObtenerIndiceTiposPorCategoria(
                RevitDB.Document doc,
                RevitDB.ViewSchedule schedule)
        {
            long categoriaKey =
                long.MinValue;

            try
            {
                RevitDB.ElementId categoriaId =
                    schedule?.Definition?.CategoryId ??
                    RevitDB.ElementId.InvalidElementId;

                if (categoriaId != null &&
                    categoriaId !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    categoriaKey =
                        categoriaId.Value;
                }
            }
            catch
            {
            }

            ConstruirIndicesTiposTodasCategorias(
                doc);

            if (_indiceTiposPorCategoria.TryGetValue(
                    categoriaKey,
                    out Dictionary<string, RevitDB.ElementId> existente) &&
                existente != null)
            {
                return existente;
            }

            var vacio =
                new Dictionary<string, RevitDB.ElementId>(
                    StringComparer.OrdinalIgnoreCase);

            _indiceTiposPorCategoria[
                categoriaKey] =
                    vacio;

            return vacio;
        }


        private RevitDB.ElementId BuscarReferenciaElementIdPorTexto(
            RevitDB.Document doc,
            RevitDB.ViewSchedule schedule,
            RevitDB.ScheduleField field,
            string nombreParametro,
            string texto)
        {
            if (doc == null ||
                schedule == null ||
                field == null ||
                string.IsNullOrWhiteSpace(
                    texto))
            {
                return
                    RevitDB.ElementId.InvalidElementId;
            }

            string nombreCampo =
                NormalizarValorFiltro(
                    !string.IsNullOrWhiteSpace(
                        nombreParametro)
                    ? nombreParametro
                    : field.GetName(),
                    false);

            // RUTA RÁPIDA PRIMERO: en la mayoría de las tablas MYG el
            // filtro es por TIPO. Resolverlo desde el índice de tipos evita
            // recorrer instancias y clases de referencia para cada partida.
            if (nombreCampo == "TIPO" ||
                nombreCampo == "FAMILIA Y TIPO")
            {
                try
                {
                    Dictionary<string, RevitDB.ElementId> indiceTipos =
                        ObtenerIndiceTiposPorCategoria(
                            doc,
                            schedule);

                    string claveTipo =
                        NormalizarValorFiltro(
                            texto,
                            false);

                    if (!string.IsNullOrWhiteSpace(
                            claveTipo) &&
                        indiceTipos.TryGetValue(
                            claveTipo,
                            out RevitDB.ElementId idTipo) &&
                        idTipo != null &&
                        idTipo !=
                            RevitDB.ElementId.InvalidElementId)
                    {
                        return
                            idTipo;
                    }
                }
                catch
                {
                }
            }

            // 1. Si existe una muestra global, usar la clase real de la
            // referencia para limitar la búsqueda (Level, Material, etc.).
            try
            {
                RevitDB.Parameter muestra =
                    ObtenerParametroMuestraCampoGlobal(
                        doc,
                        schedule,
                        field,
                        nombreParametro);

                if (muestra != null &&
                    muestra.StorageType ==
                        RevitDB.StorageType.ElementId)
                {
                    RevitDB.Element referidoMuestra =
                        doc.GetElement(
                            muestra.AsElementId());

                    if (referidoMuestra != null)
                    {
                        Type claseReferencia =
                            referidoMuestra.GetType();

                        RevitDB.Element encontrado =
                            new RevitDB.FilteredElementCollector(
                                doc)
                                .OfClass(
                                    claseReferencia)
                                .Cast<RevitDB.Element>()
                                .FirstOrDefault(
                                    x =>
                                        CoincideNombreReferenciaRevit(
                                            x,
                                            texto));

                        if (encontrado != null)
                        {
                            return
                                encontrado.Id;
                        }
                    }
                }
            }
            catch
            {
            }

            // 2. TIPO / FAMILIA Y TIPO: buscar tipos cargados aunque no
            // exista todavía ninguna instancia colocada en el modelo.
            if (nombreCampo == "TIPO" ||
                nombreCampo == "FAMILIA Y TIPO" ||
                nombreCampo == "FAMILIA")
            {
                try
                {
                    Dictionary<string, RevitDB.ElementId> indiceTipos =
                        ObtenerIndiceTiposPorCategoria(
                            doc,
                            schedule);

                    string claveTipo =
                        NormalizarValorFiltro(
                            texto,
                            false);

                    if (!string.IsNullOrWhiteSpace(
                            claveTipo) &&
                        indiceTipos.TryGetValue(
                            claveTipo,
                            out RevitDB.ElementId idTipo) &&
                        idTipo != null &&
                        idTipo !=
                            RevitDB.ElementId.InvalidElementId)
                    {
                        return
                            idTipo;
                    }
                }
                catch
                {
                }
            }

            // 3. Referencias nombradas frecuentes cuando no hay muestra.
            Type claseConocida =
                null;

            if (nombreCampo == "NIVEL" ||
                nombreCampo == "NIVEL BASE" ||
                nombreCampo == "NIVEL SUPERIOR")
            {
                claseConocida =
                    typeof(RevitDB.Level);
            }
            else if (nombreCampo == "MATERIAL")
            {
                claseConocida =
                    typeof(RevitDB.Material);
            }
            else if (nombreCampo == "FASE")
            {
                claseConocida =
                    typeof(RevitDB.Phase);
            }

            if (claseConocida != null)
            {
                try
                {
                    RevitDB.Element encontrado =
                        new RevitDB.FilteredElementCollector(
                            doc)
                            .OfClass(
                                claseConocida)
                            .Cast<RevitDB.Element>()
                            .FirstOrDefault(
                                x =>
                                    CoincideNombreReferenciaRevit(
                                        x,
                                        texto));

                    if (encontrado != null)
                    {
                        return
                            encontrado.Id;
                    }
                }
                catch
                {
                }
            }

            return
                RevitDB.ElementId.InvalidElementId;
        }


        private bool CoincideNombreReferenciaRevit(
            RevitDB.Element elemento,
            string texto)
        {
            if (elemento == null ||
                string.IsNullOrWhiteSpace(
                    texto))
            {
                return false;
            }

            string objetivo =
                NormalizarValorFiltro(
                    texto,
                    false);

            var candidatos =
                new List<string>();

            try
            {
                candidatos.Add(
                    elemento.Name);
            }
            catch
            {
            }

            if (elemento
                is RevitDB.ElementType tipoElemento)
            {
                try
                {
                    candidatos.Add(
                        tipoElemento.FamilyName);

                    candidatos.Add(
                        (tipoElemento.FamilyName ?? "") +
                        ": " +
                        (tipoElemento.Name ?? ""));

                    candidatos.Add(
                        (tipoElemento.FamilyName ?? "") +
                        " - " +
                        (tipoElemento.Name ?? ""));
                }
                catch
                {
                }
            }

            return
                candidatos
                    .Where(
                        x =>
                            !string.IsNullOrWhiteSpace(
                                x))
                    .Any(
                        x =>
                            string.Equals(
                                NormalizarValorFiltro(
                                    x,
                                    false),
                                objetivo,
                                StringComparison.OrdinalIgnoreCase));
        }


        private RevitDB.Parameter ObtenerParametroCampoFiltro(
            RevitDB.Document doc,
            RevitDB.Element elemento,
            RevitDB.ScheduleField field,
            string nombreParametro)
        {
            if (elemento == null ||
                field == null)
            {
                return null;
            }

            RevitDB.Parameter parametro =
                BuscarParametroEnElemento(
                    elemento,
                    field,
                    nombreParametro);

            if (parametro != null ||
                doc == null)
            {
                return parametro;
            }

            try
            {
                RevitDB.Element tipo =
                    doc.GetElement(
                        elemento.GetTypeId());

                if (tipo != null)
                {
                    parametro =
                        BuscarParametroEnElemento(
                            tipo,
                            field,
                            nombreParametro);
                }
            }
            catch
            {
            }

            return parametro;
        }


        private RevitDB.Parameter BuscarParametroEnElemento(
            RevitDB.Element elemento,
            RevitDB.ScheduleField field,
            string nombreParametro)
        {
            if (elemento == null ||
                field == null)
            {
                return null;
            }

            RevitDB.Parameter parametro =
                null;

            try
            {
                RevitDB.ElementId parameterId =
                    field.ParameterId;

                if (parameterId != null &&
                    parameterId !=
                        RevitDB.ElementId.InvalidElementId)
                {
                    parametro =
                        elemento.Parameters
                            .Cast<RevitDB.Parameter>()
                            .FirstOrDefault(
                                x =>
                                    x != null &&
                                    x.Id != null &&
                                    x.Id.Value ==
                                        parameterId.Value);

                    if (parametro == null &&
                        parameterId.Value < 0)
                    {
                        parametro =
                            elemento.get_Parameter(
                                (RevitDB.BuiltInParameter)
                                    (int)parameterId.Value);
                    }
                }
            }
            catch
            {
            }

            if (parametro == null &&
                !string.IsNullOrWhiteSpace(
                    nombreParametro))
            {
                try
                {
                    parametro =
                        elemento.LookupParameter(
                            nombreParametro);
                }
                catch
                {
                }
            }

            return parametro;
        }


        private bool CoincideValorMostradoParametro(
            RevitDB.Document doc,
            RevitDB.Parameter parametro,
            string valorMostrado)
        {
            if (parametro == null)
                return false;

            var candidatos =
                new List<string>();

            try
            {
                candidatos.Add(
                    parametro.AsValueString());
            }
            catch
            {
            }

            try
            {
                switch (parametro.StorageType)
                {
                    case RevitDB.StorageType.String:
                        candidatos.Add(
                            parametro.AsString());
                        break;

                    case RevitDB.StorageType.Integer:
                        candidatos.Add(
                            parametro.AsInteger()
                                .ToString(
                                    CultureInfo.InvariantCulture));
                        break;

                    case RevitDB.StorageType.Double:
                        candidatos.Add(
                            parametro.AsDouble()
                                .ToString(
                                    "G17",
                                    CultureInfo.InvariantCulture));
                        break;

                    case RevitDB.StorageType.ElementId:
                        RevitDB.ElementId id =
                            parametro.AsElementId();

                        candidatos.Add(
                            id == null
                            ? null
                            : id.Value.ToString(
                                CultureInfo.InvariantCulture));

                        RevitDB.Element referido =
                            id == null
                            ? null
                            : doc?.GetElement(
                                id);

                        candidatos.Add(
                            referido?.Name);
                        break;
                }
            }
            catch
            {
            }

            string objetivo =
                NormalizarValorFiltro(
                    valorMostrado,
                    false);

            bool esNumero =
                parametro.StorageType ==
                    RevitDB.StorageType.Double ||
                parametro.StorageType ==
                    RevitDB.StorageType.Integer;

            foreach (
                string candidato
                in candidatos)
            {
                if (string.IsNullOrWhiteSpace(
                        candidato))
                {
                    continue;
                }

                if (string.Equals(
                        NormalizarValorFiltro(
                            candidato,
                            false),
                        objetivo,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                // Para medidas, "20mm" y "20 mm" representan lo mismo.
                if (esNumero &&
                    string.Equals(
                        NormalizarValorFiltro(
                            candidato,
                            true),
                        NormalizarValorFiltro(
                            valorMostrado,
                            true),
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }


        private string NormalizarValorFiltro(
            string texto,
            bool quitarEspacios)
        {
            if (string.IsNullOrWhiteSpace(
                    texto))
            {
                return "";
            }

            string normalizado =
                texto.Trim()
                    .Normalize(
                        NormalizationForm.FormD);

            var sb =
                new StringBuilder();

            foreach (
                char caracter
                in normalizado)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(
                        caracter) ==
                    UnicodeCategory.NonSpacingMark)
                {
                    continue;
                }

                if (quitarEspacios &&
                    char.IsWhiteSpace(
                        caracter))
                {
                    continue;
                }

                sb.Append(
                    caracter);
            }

            return
                sb.ToString()
                    .Normalize(
                        NormalizationForm.FormC)
                    .Trim()
                    .ToUpperInvariant();
        }


        private bool IntentarConvertirEntero(
            string texto,
            out int valor)
        {
            if (int.TryParse(
                    texto,
                    NumberStyles.Integer,
                    CultureInfo.CurrentCulture,
                    out valor) ||
                int.TryParse(
                    texto,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out valor))
            {
                return true;
            }

            string normalizado =
                NormalizarValorFiltro(
                    texto,
                    true);

            if (normalizado == "SI" ||
                normalizado == "YES" ||
                normalizado == "TRUE")
            {
                valor = 1;
                return true;
            }

            if (normalizado == "NO" ||
                normalizado == "FALSE")
            {
                valor = 0;
                return true;
            }

            valor = 0;
            return false;
        }


        private InvalidOperationException CrearErrorConversionFiltro(
            RevitDB.ScheduleField field,
            string valor,
            string tipoEsperado)
        {
            string nombreCampo;

            try
            {
                nombreCampo =
                    field?.GetName() ??
                    "";
            }
            catch
            {
                nombreCampo =
                    "";
            }

            return
                new InvalidOperationException(
                    "No se pudo convertir el valor '" +
                    (valor ?? "") +
                    "' del parámetro '" +
                    nombreCampo +
                    "' al tipo " +
                    tipoEsperado +
                    " que exige Revit.");
        }

        private RevitDB.SchedulableField
            BuscarCampoProgramable(
                RevitDB.ScheduleDefinition definition,
                RevitDB.Document doc,
                string nombreParametro)
        {
            string objetivo =
                NormalizarTexto(
                    nombreParametro);

            foreach (
                RevitDB.SchedulableField sf
                in definition.GetSchedulableFields())
            {
                string nombre;

                try
                {
                    nombre =
                        sf.GetName(doc);
                }
                catch
                {
                    continue;
                }

                if (NormalizarTexto(nombre) ==
                    objetivo)
                {
                    return sf;
                }
            }

            return null;
        }

        private RevitDB.ScheduleFilterType
            ConvertirRegla(
                string regla)
        {
            switch (NormalizarTexto(regla))
            {
                case "parametro existe":
                    return RevitDB.ScheduleFilterType.HasParameter;

                case "es igual a":
                    return RevitDB.ScheduleFilterType.Equal;

                case "no es igual a":
                    return RevitDB.ScheduleFilterType.NotEqual;

                case "contiene":
                    return RevitDB.ScheduleFilterType.Contains;

                case "no contiene":
                    return RevitDB.ScheduleFilterType.NotContains;

                case "comienza por":
                    return RevitDB.ScheduleFilterType.BeginsWith;

                case "no comienza por":
                    return RevitDB.ScheduleFilterType.NotBeginsWith;

                case "termina en":
                    return RevitDB.ScheduleFilterType.EndsWith;

                case "no termina en":
                    return RevitDB.ScheduleFilterType.NotEndsWith;

                case "es mayor que":
                    return RevitDB.ScheduleFilterType.GreaterThan;

                case "es mayor o igual que":
                    return RevitDB.ScheduleFilterType.GreaterThanOrEqual;

                case "es menor que":
                    return RevitDB.ScheduleFilterType.LessThan;

                case "es menor o igual que":
                    return RevitDB.ScheduleFilterType.LessThanOrEqual;

                case "tiene valor":
                    return RevitDB.ScheduleFilterType.HasValue;

                case "no tiene valor":
                    return RevitDB.ScheduleFilterType.HasNoValue;

                default:
                    throw new InvalidOperationException(
                        "Regla no reconocida: " +
                        regla);
            }
        }

        private string ConstruirNombreTablaBase(
            string item,
            string partida)
        {
            string itemLimpio =
                (item ?? "")
                    .Trim();

            string partidaLimpia =
                (partida ?? "")
                    .Trim();

            string nombreBase;

            if (!string.IsNullOrWhiteSpace(
                    itemLimpio) &&
                !string.IsNullOrWhiteSpace(
                    partidaLimpia))
            {
                nombreBase =
                    itemLimpio +
                    " " +
                    partidaLimpia;
            }
            else if (!string.IsNullOrWhiteSpace(
                itemLimpio))
            {
                nombreBase =
                    itemLimpio;
            }
            else
            {
                nombreBase =
                    partidaLimpia;
            }

            nombreBase =
                (nombreBase ?? "")
                    // Revit no debe recibir los signos angulares ASCII
                    // dentro del nombre generado. Cuando aparezca la
                    // secuencia "<>", se reemplaza visualmente por "˂˃".
                    .Replace(
                        "<",
                        "˂")
                    .Replace(
                        ">",
                        "˃")
                    .Replace(
                        ":",
                        "ː")
                    .Replace(
                        '{',
                        '❴')
                    .Replace(
                        '}',
                        '❵')
                    .Replace(
                        ']',
                        '⟩')
                    .Replace(
                        '[',
                        '⟨')
                    .Replace(
                        '|',
                        '│')
                    .Replace(
                        ';',
                        ';')
                    .Replace(
                        '?',
                        '？')
                    .Replace(
                        '`',
                        'ˋ')
                    .Replace(
                        '~',
                        '∼')
                    .Replace(
                        "\r",
                        " ")
                    .Replace(
                        "\n",
                        " ")
                    .Replace(
                        "\t",
                        " ");

            while (
                nombreBase.Contains(
                    "  "))
            {
                nombreBase =
                    nombreBase.Replace(
                        "  ",
                        " ");
            }

            nombreBase =
                nombreBase.Trim();

            if (string.IsNullOrWhiteSpace(
                nombreBase))
            {
                nombreBase =
                    "Tabla automática";
            }

            if (nombreBase.Length > 120)
            {
                nombreBase =
                    nombreBase.Substring(
                        0,
                        120)
                        .Trim();
            }

            return
                nombreBase;
        }

        private string ObtenerNombreTablaUnico(
            RevitDB.Document doc,
            string item,
            string partida)
        {
            string nombreBase =
                ConstruirNombreTablaBase(
                    item,
                    partida);

            var nombres =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (
                RevitDB.ViewSchedule schedule
                in new RevitDB.FilteredElementCollector(
                    doc)
                    .OfClass(
                        typeof(
                            RevitDB.ViewSchedule))
                    .Cast<
                        RevitDB.ViewSchedule>())
            {
                if (schedule == null)
                    continue;

                if (!string.IsNullOrWhiteSpace(
                    schedule.Name))
                {
                    nombres.Add(
                        schedule.Name);
                }
            }

            if (!nombres.Contains(
                nombreBase))
            {
                return
                    nombreBase;
            }

            int n = 2;

            while (true)
            {
                string sufijo =
                    " (" +
                    n +
                    ")";

                string baseConEspacio =
                    nombreBase;

                int maxBase =
                    120 -
                    sufijo.Length;

                if (baseConEspacio.Length >
                    maxBase)
                {
                    baseConEspacio =
                        baseConEspacio.Substring(
                            0,
                            maxBase)
                            .Trim();
                }

                string candidato =
                    baseConEspacio +
                    sufijo;

                if (!nombres.Contains(
                    candidato))
                {
                    return
                        candidato;
                }

                n++;
            }
        }

        private string NormalizarTexto(
            string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string normalizado =
                texto.Trim()
                    .ToLowerInvariant()
                    .Normalize(
                        System.Text.NormalizationForm.FormD);

            var chars =
                new List<char>();

            foreach (char c in normalizado)
            {
                var categoria =
                    System.Globalization.CharUnicodeInfo
                        .GetUnicodeCategory(c);

                if (categoria !=
                    System.Globalization.UnicodeCategory
                        .NonSpacingMark)
                {
                    chars.Add(c);
                }
            }

            return new string(chars.ToArray());
        }

        // =======================================
        // OBTENER CATEGORIAS REALES DEL DOCUMENTO
        // =======================================
        // LEER TABLAS DE PLANIFICACION "PLANTILLA..."
        // =======================================
        public void CargarPlantillasRevit(
            RevitDB.Document doc)
        {
            PlantillasRevit.Clear();

            if (doc == null)
                return;

            PlantillasRevit =
                new RevitDB.FilteredElementCollector(doc)
                    .OfClass(typeof(RevitDB.ViewSchedule))
                    .Cast<RevitDB.ViewSchedule>()
                    .Where(
                        x =>
                            !x.IsTemplate &&
                            !string.IsNullOrWhiteSpace(x.Name) &&
                            x.Name.StartsWith(
                                "PLANTILLA",
                                StringComparison.OrdinalIgnoreCase))
                    .Select(x => x.Name)
                    .Distinct(
                        StringComparer.OrdinalIgnoreCase)
                    .OrderBy(x => x)
                    .ToList();
        }

        public string GetName()
        {
            return "MYG Presupuestos - Tablas";
        }

        public static List<ProyectoDelphin>
            LeerProyectosSQLite(
                string sqlitePath)
        {
            var resultado =
                new List<ProyectoDelphin>();

            using (DbConnection connection =
                AbrirConexionSQLite(sqlitePath))
            {
                using (DbCommand command =
                    connection.CreateCommand())
                {
                    command.CommandText = @"
                        SELECT
                            id_proyecto,
                            nombre_proyecto
                        FROM proyecto
                        ORDER BY nombre_proyecto;
                    ";

                    using (DbDataReader reader =
                        command.ExecuteReader())
                    {
                        int idxId =
                            reader.GetOrdinal("id_proyecto");

                        int idxNombre =
                            reader.GetOrdinal("nombre_proyecto");

                        while (reader.Read())
                        {
                            string id =
                                LeerTexto(reader, idxId);

                            string nombre =
                                LeerTexto(reader, idxNombre);

                            if (string.IsNullOrWhiteSpace(nombre))
                            {
                                nombre =
                                    "(Proyecto sin nombre)";
                            }

                            resultado.Add(
                                new ProyectoDelphin()
                                {
                                    Id = id,
                                    Nombre = nombre
                                });
                        }
                    }
                }
            }

            return resultado;
        }

        public static List<PresupuestoDelphin>
            LeerPresupuestosSQLite(
                string sqlitePath,
                string projectId)
        {
            var resultado =
                new List<PresupuestoDelphin>();

            using (DbConnection connection =
                AbrirConexionSQLite(sqlitePath))
            {
                using (DbCommand command =
                    connection.CreateCommand())
                {
                    command.CommandText = @"
                        SELECT
                            id_presupuesto,
                            numeracion_presupuesto,
                            nombre_presupuesto,
                            posicion_presupuesto
                        FROM presupuesto
                        WHERE id_proyecto = @idProyecto
                        ORDER BY
                            posicion_presupuesto,
                            numeracion_presupuesto,
                            nombre_presupuesto;
                    ";

                    AgregarParametro(
                        command,
                        "@idProyecto",
                        projectId);

                    using (DbDataReader reader =
                        command.ExecuteReader())
                    {
                        int idxId =
                            reader.GetOrdinal("id_presupuesto");

                        int idxItem =
                            reader.GetOrdinal("numeracion_presupuesto");

                        int idxNombre =
                            reader.GetOrdinal("nombre_presupuesto");

                        int idxPosicion =
                            reader.GetOrdinal("posicion_presupuesto");

                        while (reader.Read())
                        {
                            resultado.Add(
                                new PresupuestoDelphin()
                                {
                                    Id = LeerTexto(reader, idxId),
                                    Item = LeerTexto(reader, idxItem),
                                    Nombre = LeerTexto(reader, idxNombre),
                                    Posicion = LeerEntero(reader, idxPosicion)
                                });
                        }
                    }
                }
            }

            return resultado;
        }

        // =======================================
        // UNIDAD DE MEDIDA DESDE DELPHIN / SQLITE
        // =======================================
        private class ColumnaSQLiteInfo
        {
            public string Nombre { get; set; }
            public string Tipo { get; set; }
        }

        private static List<ColumnaSQLiteInfo>
            LeerColumnasTabla(
                DbConnection connection,
                string tabla)
        {
            var resultado =
                new List<ColumnaSQLiteInfo>();

            using (
                DbCommand command =
                    connection.CreateCommand())
            {
                command.CommandText =
                    "PRAGMA table_info(" +
                    EscaparIdentificadorSQLite(
                        tabla) +
                    ");";

                using (
                    DbDataReader reader =
                        command.ExecuteReader())
                {
                    int idxNombre =
                        reader.GetOrdinal(
                            "name");

                    int idxTipo =
                        reader.GetOrdinal(
                            "type");

                    while (
                        reader.Read())
                    {
                        resultado.Add(
                            new ColumnaSQLiteInfo()
                            {
                                Nombre =
                                    LeerTexto(
                                        reader,
                                        idxNombre),

                                Tipo =
                                    LeerTexto(
                                        reader,
                                        idxTipo)
                            });
                    }
                }
            }

            return resultado;
        }

        private static bool EsTipoTextoSQLite(
            string tipo)
        {
            string t =
                (tipo ?? "")
                    .Trim()
                    .ToUpperInvariant();

            // SQLite admite afinidad flexible.
            // Consideramos texto si explícitamente declara
            // CHAR / CLOB / TEXT / VARCHAR.
            return
                t.Contains("CHAR") ||
                t.Contains("CLOB") ||
                t.Contains("TEXT") ||
                t.Contains("VARCHAR");
        }

        private static bool PareceColumnaUnidad(
            string nombre)
        {
            if (string.IsNullOrWhiteSpace(
                nombre))
            {
                return false;
            }

            string n =
                nombre
                    .Trim()
                    .ToLowerInvariant();

            return
                n.Contains("unidad") ||
                n.Contains("medida") ||
                n == "um" ||
                n == "u_medida" ||
                n.Contains("abreviatura") ||
                n.Contains("simbolo");
        }

        private static string BuscarColumnaUnidadTexto(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "unidad_costo",
                "unidad",
                "unidad_medida",
                "unidad_medida_costo",
                "abreviatura_unidad",
                "simbolo_unidad",
                "abreviatura",
                "simbolo",
                "um"
            };

            // 1. Coincidencia exacta + tipo texto.
            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase) &&
                            EsTipoTextoSQLite(
                                x.Tipo));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            // 2. Cualquier columna de unidad,
            // siempre que sea de tipo texto.
            ColumnaSQLiteInfo candidata =
                columnas.FirstOrDefault(
                    x =>
                        PareceColumnaUnidad(
                            x.Nombre) &&
                        EsTipoTextoSQLite(
                            x.Tipo) &&
                        !x.Nombre.StartsWith(
                            "id_",
                            StringComparison.OrdinalIgnoreCase));

            return
                candidata?.Nombre;
        }

        private static string BuscarColumnaIdUnidad(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "id_unidad",
                "id_unidadmedida",
                "id_unidad_medida",
                "id_unidad_costo",
                "idunidad",
                "unidad_id",
                "unidadmedida_id"
            };

            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            return
                columnas
                    .FirstOrDefault(
                        x =>
                            PareceColumnaUnidad(
                                x.Nombre) &&
                            (
                                x.Nombre.StartsWith(
                                    "id_",
                                    StringComparison.OrdinalIgnoreCase) ||
                                x.Nombre.EndsWith(
                                    "_id",
                                    StringComparison.OrdinalIgnoreCase)
                            ))
                    ?.Nombre;
        }

        private class RelacionUnidadSQLite
        {
            public string TablaDestino { get; set; }
            public string ColumnaOrigen { get; set; }
            public string ColumnaDestino { get; set; }
        }

        private static RelacionUnidadSQLite
            BuscarRelacionForeignKey(
                DbConnection connection,
                string tablaOrigen,
                string columnaOrigen)
        {
            if (string.IsNullOrWhiteSpace(
                columnaOrigen))
            {
                return null;
            }

            using (
                DbCommand command =
                    connection.CreateCommand())
            {
                command.CommandText =
                    "PRAGMA foreign_key_list(" +
                    EscaparIdentificadorSQLite(
                        tablaOrigen) +
                    ");";

                using (
                    DbDataReader reader =
                        command.ExecuteReader())
                {
                    int idxTabla =
                        reader.GetOrdinal(
                            "table");

                    int idxFrom =
                        reader.GetOrdinal(
                            "from");

                    int idxTo =
                        reader.GetOrdinal(
                            "to");

                    while (
                        reader.Read())
                    {
                        string from =
                            LeerTexto(
                                reader,
                                idxFrom);

                        if (!string.Equals(
                            from,
                            columnaOrigen,
                            StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        return
                            new RelacionUnidadSQLite()
                            {
                                TablaDestino =
                                    LeerTexto(
                                        reader,
                                        idxTabla),

                                ColumnaOrigen =
                                    from,

                                ColumnaDestino =
                                    LeerTexto(
                                        reader,
                                        idxTo)
                            };
                    }
                }
            }

            return null;
        }

        private static string BuscarColumnaDescripcionUnidad(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "simbolo",
                "abreviatura",
                "abreviacion",
                "unidad",
                "unidad_medida",
                "nombre_unidad",
                "descripcion_unidad",
                "nombre",
                "descripcion"
            };

            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase) &&
                            EsTipoTextoSQLite(
                                x.Tipo));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            return
                columnas
                    .FirstOrDefault(
                        x =>
                            EsTipoTextoSQLite(
                                x.Tipo) &&
                            !x.Nombre.StartsWith(
                                "id_",
                                StringComparison.OrdinalIgnoreCase))
                    ?.Nombre;
        }

        private static List<string>
            LeerNombresTablas(
                DbConnection connection)
        {
            var resultado =
                new List<string>();

            using (
                DbCommand command =
                    connection.CreateCommand())
            {
                command.CommandText =
                    @"SELECT name
                      FROM sqlite_master
                      WHERE type = 'table'
                        AND name NOT LIKE 'sqlite_%'
                      ORDER BY name;";

                using (
                    DbDataReader reader =
                        command.ExecuteReader())
                {
                    int idxNombre =
                        reader.GetOrdinal(
                            "name");

                    while (
                        reader.Read())
                    {
                        string nombre =
                            LeerTexto(
                                reader,
                                idxNombre);

                        if (!string.IsNullOrWhiteSpace(
                            nombre))
                        {
                            resultado.Add(
                                nombre);
                        }
                    }
                }
            }

            return resultado;
        }

        private static bool PareceTablaUnidad(
            string tabla)
        {
            if (string.IsNullOrWhiteSpace(
                tabla))
            {
                return false;
            }

            string t =
                tabla
                    .Trim()
                    .ToLowerInvariant();

            return
                t.Contains("unidad") ||
                t.Contains("medida");
        }

        private static string BuscarColumnaClaveUnidad(
            DbConnection connection,
            string tabla)
        {
            List<ColumnaSQLiteInfo> columnas =
                LeerColumnasTabla(
                    connection,
                    tabla);

            string[] preferidas =
            {
                "id_unidad",
                "id_unidadmedida",
                "id_unidad_medida",
                "idunidad",
                "codigo_unidad",
                "codigo",
                "id"
            };

            foreach (
                string preferida
                in preferidas)
            {
                ColumnaSQLiteInfo encontrada =
                    columnas.FirstOrDefault(
                        x =>
                            string.Equals(
                                x.Nombre,
                                preferida,
                                StringComparison.OrdinalIgnoreCase));

                if (encontrada != null)
                {
                    return encontrada.Nombre;
                }
            }

            return
                columnas
                    .FirstOrDefault(
                        x =>
                            x.Nombre.StartsWith(
                                "id_",
                                StringComparison.OrdinalIgnoreCase) ||
                            x.Nombre.EndsWith(
                                "_id",
                                StringComparison.OrdinalIgnoreCase))
                    ?.Nombre;
        }

        private static string ResolverUnidadPorTablaHeuristica(
            DbConnection connection,
            string aliasOrigen,
            string tablaOrigen)
        {
            string idUnidad =
                BuscarColumnaIdUnidad(
                    connection,
                    tablaOrigen);

            if (string.IsNullOrWhiteSpace(
                idUnidad))
            {
                return null;
            }

            List<string> tablasUnidad =
                LeerNombresTablas(
                    connection)
                    .Where(
                        PareceTablaUnidad)
                    .ToList();

            foreach (
                string tablaUnidad
                in tablasUnidad)
            {
                string clave =
                    BuscarColumnaClaveUnidad(
                        connection,
                        tablaUnidad);

                string descripcion =
                    BuscarColumnaDescripcionUnidad(
                        connection,
                        tablaUnidad);

                if (string.IsNullOrWhiteSpace(
                        clave) ||
                    string.IsNullOrWhiteSpace(
                        descripcion))
                {
                    continue;
                }

                return
                    "(SELECT " +
                    "NULLIF(NULLIF(TRIM(CAST(u." +
                    EscaparIdentificadorSQLite(
                        descripcion) +
                    " AS TEXT)), ''), '0') " +
                    "FROM " +
                    EscaparIdentificadorSQLite(
                        tablaUnidad) +
                    " u " +
                    "WHERE CAST(u." +
                    EscaparIdentificadorSQLite(
                        clave) +
                    " AS TEXT) = CAST(" +
                    aliasOrigen +
                    "." +
                    EscaparIdentificadorSQLite(
                        idUnidad) +
                    " AS TEXT) " +
                    "LIMIT 1)";
            }

            return null;
        }

        private static string ResolverUnidadDesdeTablaRelacionada(
            DbConnection connection,
            string aliasOrigen,
            string tablaOrigen)
        {
            string idUnidad =
                BuscarColumnaIdUnidad(
                    connection,
                    tablaOrigen);

            if (string.IsNullOrWhiteSpace(
                idUnidad))
            {
                return null;
            }

            RelacionUnidadSQLite relacion =
                BuscarRelacionForeignKey(
                    connection,
                    tablaOrigen,
                    idUnidad);

            if (relacion != null &&
                !string.IsNullOrWhiteSpace(
                    relacion.TablaDestino))
            {
                string descripcion =
                    BuscarColumnaDescripcionUnidad(
                        connection,
                        relacion.TablaDestino);

                string columnaDestino =
                    !string.IsNullOrWhiteSpace(
                        relacion.ColumnaDestino)
                    ? relacion.ColumnaDestino
                    : BuscarColumnaClaveUnidad(
                        connection,
                        relacion.TablaDestino);

                if (!string.IsNullOrWhiteSpace(
                    descripcion) &&
                    !string.IsNullOrWhiteSpace(
                    columnaDestino))
                {
                    return
                        "(SELECT " +
                        "NULLIF(NULLIF(TRIM(CAST(u." +
                        EscaparIdentificadorSQLite(
                            descripcion) +
                        " AS TEXT)), ''), '0') " +
                        "FROM " +
                        EscaparIdentificadorSQLite(
                            relacion.TablaDestino) +
                        " u " +
                        "WHERE CAST(u." +
                        EscaparIdentificadorSQLite(
                            columnaDestino) +
                        " AS TEXT) = CAST(" +
                        aliasOrigen +
                        "." +
                        EscaparIdentificadorSQLite(
                            idUnidad) +
                        " AS TEXT) " +
                        "LIMIT 1)";
                }
            }

            // Muchas bases SQLite no declaran FOREIGN KEY.
            // Intentar relación por nombres/esquema.
            return
                ResolverUnidadPorTablaHeuristica(
                    connection,
                    aliasOrigen,
                    tablaOrigen);
        }

        private static string ResolverExpresionUnidadSql(
            DbConnection connection)
        {
            var expresiones =
                new List<string>();

            // =======================================
            // 1. TEXTO DIRECTO costo_unitario
            // =======================================
            string directaCosto =
                BuscarColumnaUnidadTexto(
                    connection,
                    "costo_unitario");

            if (!string.IsNullOrWhiteSpace(
                directaCosto))
            {
                expresiones.Add(
                    "NULLIF(NULLIF(TRIM(CAST(cu." +
                    EscaparIdentificadorSQLite(
                        directaCosto) +
                    " AS TEXT)), ''), '0')");
            }

            // =======================================
            // 2. TEXTO DIRECTO analisis_costo
            // =======================================
            string directaAnalisis =
                BuscarColumnaUnidadTexto(
                    connection,
                    "analisis_costo");

            if (!string.IsNullOrWhiteSpace(
                directaAnalisis))
            {
                expresiones.Add(
                    "NULLIF(NULLIF(TRIM(CAST(ac." +
                    EscaparIdentificadorSQLite(
                        directaAnalisis) +
                    " AS TEXT)), ''), '0')");
            }

            // =======================================
            // 3. RELACIÓN unidad costo_unitario
            //    con FK o heurística.
            // =======================================
            string relacionadaCosto =
                ResolverUnidadDesdeTablaRelacionada(
                    connection,
                    "cu",
                    "costo_unitario");

            if (!string.IsNullOrWhiteSpace(
                relacionadaCosto))
            {
                expresiones.Add(
                    relacionadaCosto);
            }

            // =======================================
            // 4. RELACIÓN unidad analisis_costo
            // =======================================
            string relacionadaAnalisis =
                ResolverUnidadDesdeTablaRelacionada(
                    connection,
                    "ac",
                    "analisis_costo");

            if (!string.IsNullOrWhiteSpace(
                relacionadaAnalisis))
            {
                expresiones.Add(
                    relacionadaAnalisis);
            }

            // Nada encontrado.
            if (expresiones.Count == 0)
            {
                return
                    "NULL";
            }

            if (expresiones.Count == 1) return expresiones[0];

            // COALESCE toma la primera unidad válida.
            return
                "COALESCE(" +
                string.Join(
                    ", ",
                    expresiones) +
                ")";
        }

        private static string EscaparIdentificadorSQLite(
            string nombre)
        {
            if (string.IsNullOrWhiteSpace(
                nombre))
            {
                return null;
            }

            return
                "\"" +
                nombre.Replace(
                    "\"",
                    "\"\"") +
                "\"";
        }

        public static List<ItemPresupuestoDelphin>
            LeerItemsPresupuestoSQLite(
                string sqlitePath,
                string presupuestoId)
        {
            var resultado =
                new List<ItemPresupuestoDelphin>();

            using (
                DbConnection connection =
                    AbrirConexionSQLite(
                        sqlitePath))
            {
                string expresionUnidad =
                    ResolverExpresionUnidadSql(
                        connection);

                string selectUnidad =
                    ", " +
                    expresionUnidad +
                    " AS unidad_myg";

                using (
                    DbCommand command =
                        connection.CreateCommand())
                {
                    command.CommandText =
                        @"
                        SELECT
                            cu.id_costounitario,
                            cu.id_costopadre,
                            cu.numeracion_costo,
                            cu.descripcion_costo,
                            cu.posicion_costo,

                            cu.id_analisiscosto,

                            ac.codigo_clase,
                            ac.codigo_subclase,
                            ac.codigo_listaprecio
                        " +
                        selectUnidad +
                        @"

                        FROM costo_unitario cu

                        LEFT JOIN analisis_costo ac
                            ON ac.id_analisiscosto =
                               cu.id_analisiscosto

                        WHERE
                            cu.id_presupuesto =
                            @idPresupuesto

                        ORDER BY
                            cu.posicion_costo,
                            cu.numeracion_costo;
                    ";

                    AgregarParametro(
                        command,
                        "@idPresupuesto",
                        presupuestoId);

                    using (
                        DbDataReader reader =
                            command.ExecuteReader())
                    {
                        int idxAnalisis = reader.GetOrdinal("id_analisiscosto");
                        int idxId =
                            reader.GetOrdinal(
                                "id_costounitario");

                        int idxPadre =
                            reader.GetOrdinal(
                                "id_costopadre");

                        int idxItem =
                            reader.GetOrdinal(
                                "numeracion_costo");

                        int idxDescripcion =
                            reader.GetOrdinal(
                                "descripcion_costo");

                        int idxPosicion =
                            reader.GetOrdinal(
                                "posicion_costo");

                        int idxCodigoDelphin =
                            reader.GetOrdinal(
                                "codigo_listaprecio");

                        int idxUnidad =
                            reader.GetOrdinal(
                                "unidad_myg");

                        while (
                            reader.Read())
                        {
                            string id =
                                LeerTexto(
                                    reader,
                                    idxId);

                            if (string.IsNullOrWhiteSpace(
                                id))
                            {
                                continue;
                            }

                            resultado.Add(
                                new ItemPresupuestoDelphin()
                                {
                                    Id = id,
                                    IdInternoDelphin = id,
                                    IdAnalisisDelphin = LeerTexto(reader, idxAnalisis),
                                    Origen = "DELPHIN",
                                    Estado = "OFICIAL",

                                    ParentId =
                                        LeerTexto(
                                            reader,
                                            idxPadre),

                                    Item =
                                        LeerTexto(
                                            reader,
                                            idxItem),

                                    Descripcion =
                                        LeerTexto(
                                            reader,
                                            idxDescripcion),

                                    CodigoDelphin =
                                        LeerTexto(
                                            reader,
                                            idxCodigoDelphin),

                                    Unidad =
                                        NormalizarUnidad(
                                            LeerTexto(
                                                reader,
                                                idxUnidad)),

                                    // Datos BIM:
                                    // se llenan desde interfaz/JSON.
                                    Plantilla =
                                        null,

                                    Parametro =
                                        null,

                                    Regla =
                                        null,

                                    Valor =
                                        null,

                                    Posicion =
                                        LeerEntero(
                                            reader,
                                            idxPosicion)
                                });
                        }
                    }
                }
            }

            return
                resultado;
        }

        private static string NormalizarUnidad(
            string unidad)
        {
            string valor =
                (unidad ?? "")
                    .Trim();

            if (string.IsNullOrWhiteSpace(
                valor))
            {
                return null;
            }

            if (valor == "0" ||
                valor == "0.0" ||
                valor == "0,0")
            {
                return null;
            }

            return valor;
        }

        // Lee los análisis disponibles en la base completa, incluyendo los que
        // no están utilizados en el presupuesto seleccionado. Solo lectura.
        public static List<MYGPartidaCatalogo> LeerCatalogoPartidasSQLite(string sqlitePath)
        {
            using (DbConnection connection = AbrirConexionSQLite(sqlitePath))
            {
                var columnas = LeerColumnasTabla(connection, "analisis_costo");
                if (!columnas.Any(c => string.Equals(c.Nombre, "id_analisiscosto", StringComparison.OrdinalIgnoreCase)))
                    throw new InvalidDataException("Esta base no contiene la tabla de análisis de Delphin esperada (analisis_costo). " +
                        "Conecta una base que incluya el catálogo de partidas.");
                string descripcion = BuscarColumnaCatalogo(columnas, new[]
                { "descripcion_analisiscosto", "descripcion_analisis", "descripcion_analisis_costo", "descripcion_costo",
                    "nombre_analisiscosto", "nombre_analisis", "descripcion", "nombre" }, "descripcion");
                if (descripcion == null) descripcion = BuscarColumnaCatalogo(columnas,
                    new[] { "nombre_costo", "nombre_costounitario" }, "nombre");
                string codigo = BuscarColumnaCatalogo(columnas,
                    new[] { "codigo_listaprecio", "codigo_analisis", "codigo_analisiscosto", "codigo" }, null);
                bool tieneCosto = LeerColumnasTabla(connection, "costo_unitario")
                    .Any(c => string.Equals(c.Nombre, "id_analisiscosto", StringComparison.OrdinalIgnoreCase));
                string descAc = descripcion == null ? "NULL" : "NULLIF(TRIM(CAST(ac." + EscaparIdentificadorSQLite(descripcion) + " AS TEXT)), '')";
                string descCu = tieneCosto ? "NULLIF(TRIM(CAST(cu.descripcion_costo AS TEXT)), '')" : "NULL";
                string codigoSql = codigo == null ? "NULL" : "CAST(ac." + EscaparIdentificadorSQLite(codigo) + " AS TEXT)";
                string unidadSql;
                if (tieneCosto) unidadSql = ResolverExpresionUnidadSql(connection);
                else
                {
                    string texto = BuscarColumnaUnidadTexto(connection, "analisis_costo");
                    string relacionada = ResolverUnidadDesdeTablaRelacionada(connection, "ac", "analisis_costo");
                    var unidades = new List<string>();
                    if (texto != null) unidades.Add("NULLIF(TRIM(CAST(ac." + EscaparIdentificadorSQLite(texto) + " AS TEXT)), '')");
                    if (!string.IsNullOrWhiteSpace(relacionada)) unidades.Add(relacionada);
                    unidadSql = unidades.Count == 0 ? "NULL" : unidades.Count == 1 ? unidades[0] : "COALESCE(" + string.Join(",", unidades) + ")";
                }
                string join = tieneCosto ? @"
                    LEFT JOIN costo_unitario cu ON cu.id_costounitario = (
                        SELECT cu2.id_costounitario FROM costo_unitario cu2
                        WHERE cu2.id_analisiscosto = ac.id_analisiscosto
                        ORDER BY cu2.id_costounitario LIMIT 1)
                    " : "";
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT ac.id_analisiscosto AS id_catalogo, " + codigoSql + " AS codigo, " +
                        "COALESCE(" + descAc + ", " + descCu + ") AS descripcion, " + unidadSql + " AS unidad_myg " +
                        "FROM analisis_costo ac " + join + " ORDER BY codigo, descripcion, ac.id_analisiscosto;";
                    var resultado = new List<MYGPartidaCatalogo>();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string id = LeerTexto(reader, 0); if (string.IsNullOrWhiteSpace(id)) continue;
                            string desc = LeerTexto(reader, 2);
                            if (string.IsNullOrWhiteSpace(desc)) continue; // Una referencia sin descripción no sirve como partida seleccionable.
                            resultado.Add(new MYGPartidaCatalogo
                            {
                                Id = id,
                                Codigo = LeerTexto(reader, 1),
                                Descripcion = desc,
                                Unidad = NormalizarUnidad(LeerTexto(reader, 3)),
                                RutaSQLite = sqlitePath
                            });
                        }
                    }
                    return resultado;
                }
            }
        }

        private static string BuscarColumnaCatalogo(List<ColumnaSQLiteInfo> columnas, string[] preferidas, string prefijo)
        {
            foreach (string nombre in preferidas)
            {
                var c = columnas.FirstOrDefault(x => string.Equals(x.Nombre, nombre, StringComparison.OrdinalIgnoreCase));
                if (c != null) return c.Nombre;
            }
            return prefijo == null ? null : columnas.FirstOrDefault(c =>
                c.Nombre.StartsWith(prefijo, StringComparison.OrdinalIgnoreCase))?.Nombre;
        }

        private static DbConnection AbrirConexionSQLite(
            string sqlitePath)
        {
            SQLiteDependencyBootstrapper.Initialize();

            if (string.IsNullOrWhiteSpace(sqlitePath))
                throw new ArgumentException("La ruta SQLite está vacía.");

            if (!File.Exists(sqlitePath))
                throw new FileNotFoundException("No existe la base SQLite.", sqlitePath);

            Assembly sqliteAssembly =
                SQLiteDependencyBootstrapper.MicrosoftDataSqliteAssembly;

            if (sqliteAssembly == null)
                throw new InvalidOperationException("Microsoft.Data.Sqlite no está cargado.");

            Type connectionType =
                sqliteAssembly.GetType(
                    "Microsoft.Data.Sqlite.SqliteConnection",
                    true);

            var builder = new DbConnectionStringBuilder();
            builder["Data Source"] = Path.GetFullPath(sqlitePath);
            builder["Mode"] = "ReadOnly";
            builder["Pooling"] = false;
            string connectionString = builder.ConnectionString;

            object connectionObject =
                Activator.CreateInstance(
                    connectionType,
                    connectionString);

            DbConnection connection =
                connectionObject as DbConnection;

            if (connection == null)
                throw new InvalidCastException("No se pudo convertir SqliteConnection a DbConnection.");

            connection.Open();

            return connection;
        }

        private static void AgregarParametro(
            DbCommand command,
            string nombre,
            object valor)
        {
            DbParameter parametro =
                command.CreateParameter();

            parametro.ParameterName = nombre;
            parametro.Value = valor ?? DBNull.Value;

            command.Parameters.Add(parametro);
        }

        private static string LeerTexto(
            DbDataReader reader,
            int index)
        {
            if (reader.IsDBNull(index))
                return null;

            return reader.GetValue(index)?.ToString();
        }

        private static int LeerEntero(
            DbDataReader reader,
            int index)
        {
            if (reader.IsDBNull(index))
                return 0;

            object valor = reader.GetValue(index);

            if (valor == null)
                return 0;

            if (int.TryParse(
                valor.ToString(),
                out int resultado))
            {
                return resultado;
            }

            return 0;
        }
    }
}
