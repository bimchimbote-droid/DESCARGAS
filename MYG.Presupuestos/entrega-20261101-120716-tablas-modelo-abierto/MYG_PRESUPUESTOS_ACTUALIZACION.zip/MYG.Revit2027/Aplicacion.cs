using System.Collections.Concurrent;
using System.IO.Pipes;
using System.IO;
using Autodesk.Revit.UI;
using MYG.Externo;
using MYG_2027;

namespace MYG.Conector;

public sealed class Aplicacion : IExternalApplication
{
    private ExternalEvent evento;
    private Receptor receptor;
    private CancellationTokenSource cierre;
    private readonly ConcurrentQueue<OperacionPendiente> cola = new();
    private readonly Dictionary<Autodesk.Revit.DB.Document, string> documentos = new();
    public Result OnStartup(UIControlledApplication app)
    {
        cierre = new(); app.Idling += Inicializar;
        try { app.CreateRibbonTab("MYG"); } catch (ArgumentException) { }
        var panel = app.GetRibbonPanels("MYG").FirstOrDefault(p => p.Name == "Presupuestos") ?? app.CreateRibbonPanel("MYG", "Presupuestos");
        if (!panel.GetItems().Any(i => i.Name == "MYG_AbrirPresupuestos"))
            panel.AddItem(new PushButtonData("MYG_AbrirPresupuestos", "Presupuestos", typeof(Aplicacion).Assembly.Location,
                typeof(AbrirPresupuestos).FullName)
            { ToolTip = "Abrir MYG para editar presupuestos, ACU, especificaciones y metrados." });
        return Result.Succeeded;
    }
    private void Inicializar(object sender, Autodesk.Revit.UI.Events.IdlingEventArgs e)
    {
        if (evento != null || cierre.IsCancellationRequested) return;
        evento = ExternalEvent.Create(new Ejecutor(cola, documentos));
        receptor = new Receptor(cola, evento, cierre.Token); receptor.Iniciar();
    }
    public Result OnShutdown(UIControlledApplication app)
    {
        app.Idling -= Inicializar; cierre?.Cancel();
        while (cola.TryDequeue(out var p)) p.CancelarAntesDeIniciar();
        evento?.Dispose(); cierre?.Dispose(); return Result.Succeeded;
    }
}

internal sealed class Receptor
{
    private readonly ConcurrentQueue<OperacionPendiente> cola;
    private readonly ExternalEvent evento;
    private readonly CancellationToken cierre;
    private readonly LicenciaServicio licencia = AccesoWindows.Servicio();
    private readonly ConcurrentDictionary<string, Task<RespuestaRevit>> recibidas = new();
    private string identidadValidada;
    private long validadoTick;
    internal Receptor(ConcurrentQueue<OperacionPendiente> cola, ExternalEvent evento, CancellationToken cierre)
    { this.cola = cola; this.evento = evento; this.cierre = cierre; }
    internal void Iniciar() => _ = Task.Run(EscucharAsync);
    private async Task EscucharAsync()
    {
        while (!cierre.IsCancellationRequested)
        {
            try
            {
                using var pipe = new NamedPipeServerStream(ProtocoloMYG.Pipe(Environment.ProcessId), PipeDirection.InOut,
                    1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
                await pipe.WaitForConnectionAsync(cierre);
                using var limite = CancellationTokenSource.CreateLinkedTokenSource(cierre);
                limite.CancelAfter(TimeSpan.FromMinutes(10));
                SolicitudRevit s = null;
                try
                {
                    s = await ProtocoloMYG.LeerAsync<SolicitudRevit>(pipe, limite.Token);
                    ProtocoloMYG.Validar(s);
                    var credencial = s.Credencial;
                    if (credencial == null) throw new InvalidDataException("Inicie sesión en MYG.");
                    string identidad = credencial.Identidad();
                    if (identidad != identidadValidada || System.Diagnostics.Stopwatch.GetElapsedTime(validadoTick).TotalSeconds >= 45)
                    {
                        var acceso = await licencia.ValidarAsync(credencial, limite.Token);
                        if (!acceso.Ok)
                        { identidadValidada = null; await ProtocoloMYG.EscribirAsync(pipe, RespuestaRevit.Error(s.Id, acceso.Mensaje), limite.Token); continue; }
                        if (credencial.RecordarIngreso && acceso.Token != null) AccesoWindows.GuardarAutomatico(credencial.Usuario, acceso.Token);
                        identidadValidada = identidad; validadoTick = System.Diagnostics.Stopwatch.GetTimestamp();
                    }
                    string clave = identidad + "|" + s.Id;
                    if (!recibidas.TryGetValue(clave, out var resultado))
                    {
                        var p = new OperacionPendiente(s);
                        resultado = p.Fin.Task; recibidas[clave] = resultado;
                        using var cancel = limite.Token.Register(() => p.CancelarAntesDeIniciar());
                        cola.Enqueue(p);
                        var aceptado = evento.Raise();
                        if (aceptado != ExternalEventRequest.Accepted && aceptado != ExternalEventRequest.Pending)
                            p.CancelarAntesDeIniciar();
                        var r = await resultado.WaitAsync(limite.Token);
                        await ProtocoloMYG.EscribirAsync(pipe, r, limite.Token);
                    }
                    else await ProtocoloMYG.EscribirAsync(pipe, await resultado.WaitAsync(limite.Token), limite.Token);
                    if (recibidas.Count > 200) foreach (var key in recibidas.Where(x => x.Value.IsCompleted).Take(100).Select(x => x.Key)) recibidas.TryRemove(key, out _);
                }
                catch (Exception ex) when (ex is InvalidDataException or System.Text.Json.JsonException)
                { await ProtocoloMYG.EscribirAsync(pipe, RespuestaRevit.Error(s?.Id, "Solicitud no válida: " + ex.Message), limite.Token); }
            }
            catch (OperationCanceledException) { if (cierre.IsCancellationRequested) return; }
            catch (IOException) { }
            catch (Exception) { if (!cierre.IsCancellationRequested) await Task.Delay(500, cierre); }
        }
    }
}

internal sealed class Ejecutor : IExternalEventHandler
{
    private readonly ConcurrentQueue<OperacionPendiente> cola;
    private readonly Dictionary<Autodesk.Revit.DB.Document, string> documentos;
    private readonly TablasAutomaticasExternalHandler motor = new();
    internal Ejecutor(ConcurrentQueue<OperacionPendiente> cola, Dictionary<Autodesk.Revit.DB.Document, string> documentos)
    { this.cola = cola; this.documentos = documentos; }
    public string GetName() => "MYG Presupuestos | Conector Revit";
    public void Execute(UIApplication app)
    {
        while (cola.TryDequeue(out var p))
        {
            if (!p.Iniciar()) continue;
            try
            {
                var s = p.Solicitud;
                if ((DateTime.UtcNow - p.AutorizadoUtc).TotalSeconds > 45)
                    throw new InvalidOperationException("Revit estaba ocupado. Repita la operación para validar el acceso nuevamente.");
                var doc = app.ActiveUIDocument?.Document;
                if (doc == null || doc.IsFamilyDocument) throw new InvalidOperationException("Abra un modelo de proyecto en Revit.");
                if (!documentos.TryGetValue(doc, out var id)) documentos[doc] = id = Guid.NewGuid().ToString("N");
                foreach (var d in documentos.Keys.Where(d => !d.IsValidObject).ToList()) documentos.Remove(d);
                if (s.Accion != "INFO" && s.DocumentoId != id)
                    throw new InvalidOperationException("El modelo activo cambió. Active el modelo seleccionado y vuelva a conectar desde MYG.");
                if (s.Accion == "INFO")
                {
                    PlantillaParametrosRevitCache.Cargar(doc);
                    var campos = PlantillaParametrosRevitCache.ObtenerCopia();
                    var info = IdentidadDocumentoRevit.Describir(doc, id);
                    info.Plantillas = campos.Keys.OrderBy(x => x).ToList();
                    info.Parametros = campos;
                    info.Reglas = campos.ToDictionary(x => x.Key, x => x.Value.ToDictionary(v => v, v => PlantillaParametrosRevitCache.ObtenerReglas(x.Key, v)));
                    p.Completar(new() { Id = s.Id, Ok = true, Documento = info, Mensaje = "Modelo conectado." });
                }
                else
                {
                    if ((s.Accion is "CREAR" or "ACTUALIZAR" or "APLICAR_ACTIVO") && (doc.IsReadOnly || doc.IsModifiable))
                        throw new InvalidOperationException("El modelo no está disponible para modificar tablas en este momento.");
                    if (s.Accion == "APLICAR_ACTIVO" &&
                        !string.Equals(s.DocumentoRevitId, IdentidadDocumentoRevit.Describir(doc, id).DocumentoRevitId, StringComparison.Ordinal))
                        throw new InvalidOperationException("La identidad del modelo activo cambió. Vuelva a conectar y compruebe su vinculación con el activo.");
                    p.Completar(motor.ProcesarExterno(app, s));
                }
            }
            catch (Exception ex) { p.Completar(RespuestaRevit.Error(p.Solicitud.Id, ex.Message)); }
        }
    }
}
