using System.Text.Json;
using MYG.Externo;
using MYG_2027;

internal static class TablasActivosRevitCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new InvalidOperationException(detalle); }
    private static void Rechaza(Action accion)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new InvalidOperationException("Se aceptó una configuración o vinculación inválida de tablas por activo.");
    }
    private static ItemPresupuestoDelphin Partida(string nombre) => new()
    {
        Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = nombre, Unidad = "m³", Plantilla = "Concreto",
        Filtros = new() { new() { Parametro = "Tipo", Regla = "es igual a", Valor = "210" } }
    };
    private static DocumentoRevitInfo Documento() => new()
    {
        Id = "apertura-A", DocumentoRevitId = "local:identidad-A", Nombre = "Bloque A", Ruta = @"D:\Obras\BloqueA.rvt",
        Plantillas = new() { "Concreto" }, Parametros = new() { ["Concreto"] = new() { "Tipo" } },
        Reglas = new() { ["Concreto"] = new() { ["Tipo"] = new() { "es igual a", "tiene valor" } } }
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Obra", "Estructuras");
        var p = proyecto.Presupuestos.Single();
        var columnas = Partida("Columnas"); var losas = Partida("Losas"); var cimientos = Partida("Cimientos");
        p.Items.AddRange(new[] { columnas, losas, cimientos });
        var p2 = new MYGPresupuestoDocumento { Nombre = "Otro presupuesto" };
        var muros = Partida("Muros"); p2.Items.Add(muros); proyecto.Presupuestos.Add(p2);
        MYGProyectoStorage.Validar(proyecto);
        var a = MYGActivosRevit.GuardarActivo(proyecto, new() { Nombre = "Bloque A", RutaLocal = @"D:\Obras\BloqueA.rvt" });
        var b = MYGActivosRevit.GuardarActivo(proyecto, new() { Nombre = "Bloque B", RutaLocal = @"D:\Obras\BloqueB.rvt" });
        MYGActivosRevit.Asignar(proyecto, p.Id, columnas.Id, a.Id);
        MYGActivosRevit.Asignar(proyecto, p.Id, columnas.Id, b.Id);
        MYGActivosRevit.Asignar(proyecto, p.Id, losas.Id, a.Id);
        MYGActivosRevit.Asignar(proyecto, p.Id, cimientos.Id, b.Id);
        MYGActivosRevit.Asignar(proyecto, p2.Id, muros.Id, a.Id);
        MYGActivosRevit.CambiarInclusion(proyecto, p.Id, losas.Id, a.Id, false);
        var info = Documento();
        string firma = MYGProyectoStorage.Firma(proyecto);
        Exige(MYGTablasActivosRevit.ResolverActivo(proyecto, info) == null, "Nombre y ruta iguales vincularon el documento sin confirmación.");
        Rechaza(() => MYGTablasActivosRevit.PrepararLotes(proyecto, info));
        Exige(MYGProyectoStorage.Firma(proyecto) == firma, "Reconocer o rechazar un modelo desconocido cambió la obra.");
        pasa("Tablas por activo exigen primera vinculación explícita y no infieren identidad por nombre o ruta");

        MYGTablasActivosRevit.VincularDocumento(proyecto, a.Id, info);
        info.Id = "otra-apertura"; info.Nombre = "Modelo renombrado"; info.Ruta = @"E:\Movido.rvt";
        Exige(MYGTablasActivosRevit.ResolverActivo(proyecto, info).Id == a.Id, "Reabrir o mover el archivo perdió la identidad del activo.");
        string rutaMovida = info.Ruta;
        info.Ruta = "d:/obras/BLOQUEB.RVT";
        string firmaCopia = MYGProyectoStorage.Firma(proyecto);
        Rechaza(() => MYGTablasActivosRevit.ResolverActivo(proyecto, info));
        Rechaza(() => MYGTablasActivosRevit.PrepararLotes(proyecto, info));
        Exige(MYGProyectoStorage.Firma(proyecto) == firmaCopia &&
            proyecto.ActivosRevit.Activos.Single(x => x.Id == b.Id).DocumentoRevitId == null,
            "Una copia con identidad compartida eligió el activo por ruta o sobrescribió su vínculo.");
        info.Ruta = rutaMovida;
        string ruta = Path.Combine(carpeta, "tablas-activos.myg.json");
        MYGProyectoStorage.Guardar(ruta, proyecto);
        foreach (var archivo in new[] { ruta, MYGBaseDatos.RutaDeProyecto(ruta) })
            Exige(MYGTablasActivosRevit.ResolverActivo(MYGProyectoStorage.Leer(archivo), info).Id == a.Id,
                "Guardar y reabrir JSON/SQLite perdió la vinculación del modelo.");
        pasa("La vinculación persistente reconoce el modelo reabierto o renombrado y sobrevive JSON y SQLite");

        var lotes = MYGTablasActivosRevit.PrepararLotes(proyecto, info);
        Exige(lotes.Count == 2 && lotes.Single(l => l.PresupuestoId == p.IdPresupuestoRevit).Configuraciones.Select(c => c.IdInterno)
            .OrderBy(x => x).SequenceEqual(new[] { columnas.Id, losas.Id }.OrderBy(x => x)) &&
            lotes.Single(l => l.PresupuestoId == p2.IdPresupuestoRevit).Configuraciones.Single().IdInterno == muros.Id,
            "El batch omitió presupuestos, incluyó partidas ajenas o confundió exclusión de cantidades con generación de tablas.");
        var lotesBInfo = Documento(); lotesBInfo.DocumentoRevitId = "local:identidad-B";
        lotesBInfo.Ruta = b.RutaLocal; lotesBInfo.Nombre = b.Nombre;
        MYGTablasActivosRevit.VincularDocumento(proyecto, b.Id, lotesBInfo);
        var loteB = MYGTablasActivosRevit.PrepararLotes(proyecto, lotesBInfo).Single();
        Exige(loteB.Configuraciones.Select(c => c.IdInterno).ToHashSet().SetEquals(new[] { columnas.Id, cimientos.Id }),
            "Cambiar de documento no seleccionó exclusivamente las partidas de Bloque B.");
        pasa("Un botón prepara todas las partidas asignadas al activo del modelo, aísla otros activos y conserva el alcance por presupuesto");

        lotes[0].Configuraciones[0].Filtros[0].Valor = "Solo batch";
        Exige(columnas.Filtros[0].Valor == "210", "Preparar el batch compartió filtros con la obra.");
        firma = MYGProyectoStorage.Firma(proyecto);
        Rechaza(() => MYGTablasActivosRevit.VincularDocumento(proyecto, a.Id, lotesBInfo));
        var nuevo = Documento(); nuevo.DocumentoRevitId = "local:otro";
        Rechaza(() => MYGTablasActivosRevit.VincularDocumento(proyecto, a.Id, nuevo));
        nuevo.DocumentoRevitId = null;
        Rechaza(() => MYGTablasActivosRevit.ResolverActivo(proyecto, nuevo));
        Exige(MYGProyectoStorage.Firma(proyecto) == firma, "Una vinculación conflictiva cambió el activo o las asignaciones.");
        pasa("Los conflictos de identidad y conectores anteriores se rechazan sin sobrescribir vínculos ni modificar filtros guardados");

        void ConfiguracionInvalida(Action cambiar)
        {
            var copia = MYGProyectoStorage.Copia(proyecto);
            cambiar();
            string antes = MYGProyectoStorage.Firma(proyecto);
            Rechaza(() => MYGTablasActivosRevit.PrepararLotes(proyecto, info));
            Exige(MYGProyectoStorage.Firma(proyecto) == antes, "La validación fallida modificó la obra.");
            proyecto = copia;
        }
        ConfiguracionInvalida(() => proyecto.Presupuestos[1].Items[0].Plantilla = "No existe");
        var campoProgramable = MYGProyectoStorage.Copia(proyecto);
        campoProgramable.Presupuestos[1].Items[0].Filtros[0].Parametro = "Campo programable aún no añadido";
        string firmaCampoProgramable = MYGProyectoStorage.Firma(campoProgramable);
        Exige(MYGTablasActivosRevit.PrepararLotes(campoProgramable, info).Single(l => l.PresupuestoId == p2.IdPresupuestoRevit)
            .Configuraciones.Single().Filtros[0].Parametro == "Campo programable aún no añadido" &&
            MYGProyectoStorage.Firma(campoProgramable) == firmaCampoProgramable,
            "INFO descartó un campo programable ausente de la plantilla o preparar el batch modificó la fuente.");
        ConfiguracionInvalida(() => proyecto.Presupuestos[1].Items[0].Filtros[0].Regla = "Otra regla");
        ConfiguracionInvalida(() => proyecto.Presupuestos[1].Items[0].Filtros[0].Valor = "");
        ConfiguracionInvalida(() => proyecto.Presupuestos[1].Items[0].Filtros.Add(null));
        var pLibre = proyecto.Presupuestos[0].Items.Single(i => i.Id == cimientos.Id);
        pLibre.Plantilla = null;
        Exige(MYGTablasActivosRevit.PrepararLotes(proyecto, info).Count == 2, "Una partida ajena al activo bloqueó el batch.");
        pasa("Una plantilla o filtro básico inválido bloquea el batch; los campos programables ausentes de INFO se reservan al preflight real de Revit");

        var nube = MYGActivosRevit.GuardarActivo(proyecto, new() { Nombre = "Nube", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "proyecto-cloud", ModeloAutodeskId = "modelo-cloud" });
        var infoNube = Documento(); infoNube.Origen = MYGOrigenActivoRevit.Autodesk;
        infoNube.DocumentoRevitId = "autodesk:proyecto-cloud:modelo-cloud";
        infoNube.ProyectoAutodeskId = "proyecto-cloud"; infoNube.ModeloAutodeskId = "modelo-cloud";
        Rechaza(() => MYGTablasActivosRevit.VincularDocumento(proyecto, a.Id, infoNube));
        Rechaza(() => MYGTablasActivosRevit.VincularDocumento(proyecto, nube.Id, info));
        MYGTablasActivosRevit.VincularDocumento(proyecto, nube.Id, infoNube);
        infoNube.ModeloAutodeskId = "otro-modelo";
        Rechaza(() => MYGTablasActivosRevit.ResolverActivo(proyecto, infoNube));
        infoNube.DocumentoRevitId = "autodesk:otro";
        Rechaza(() => MYGTablasActivosRevit.VincularDocumento(proyecto, nube.Id, infoNube));
        pasa("Autodesk verifica los identificadores exactos de proyecto y modelo y no acepta una vinculación local o cruzada");

        var solicitud = new SolicitudRevit { Accion = "APLICAR_ACTIVO", DocumentoId = info.Id, DocumentoRevitId = info.DocumentoRevitId,
            ActivoId = a.Id, ProyectoId = proyecto.IdProyectoRevit, LotesTablas = MYGTablasActivosRevit.PrepararLotes(proyecto, info) };
        ProtocoloMYG.Validar(solicitud);
        var copiaSolicitud = JsonSerializer.Deserialize<SolicitudRevit>(JsonSerializer.Serialize(solicitud, ProtocoloMYG.Json), ProtocoloMYG.Json);
        ProtocoloMYG.Validar(copiaSolicitud);
        copiaSolicitud.DocumentoRevitId = null; Rechaza(() => ProtocoloMYG.Validar(copiaSolicitud));
        copiaSolicitud.DocumentoRevitId = info.DocumentoRevitId;
        copiaSolicitud.LotesTablas.Add(copiaSolicitud.LotesTablas[0]); Rechaza(() => ProtocoloMYG.Validar(copiaSolicitud));
        copiaSolicitud.LotesTablas.RemoveAt(copiaSolicitud.LotesTablas.Count - 1);
        copiaSolicitud.LotesTablas[0].Configuraciones.Add(copiaSolicitud.LotesTablas[0].Configuraciones[0]);
        Rechaza(() => ProtocoloMYG.Validar(copiaSolicitud));
        ProtocoloMYG.Validar(new() { Accion = "INFO" });
        pasa("El protocolo conserva INFO y transporta lotes por activo con guardias de identidad y rechazo de presupuestos o partidas duplicados");
    }
}
