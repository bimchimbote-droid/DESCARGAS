using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

internal static partial class MYG2027_TemaComercial
{
    private enum FondoControl { Fondo, Superficie, Suave, Cabecera, Transparente }
    private sealed class EstadoControl
    {
        internal FondoControl Fondo;
        internal Drawing.Color TextoOriginal, UltimoTexto;
        internal bool ColoresDeDocumento;
        internal bool SinFilasAlternas;
    }
    private sealed class EstiloBoton { internal int Estilo; }
    private sealed class EstadoTemaEspecificaciones { internal bool Aplicando; }
    private static readonly ConditionalWeakTable<WinForms.Control, EstadoControl> controles = new();
    private static readonly ConditionalWeakTable<WinForms.Button, EstiloBoton> estilosBoton = new();
    private static readonly ConditionalWeakTable<MYGEspecificacionesEditor, EstadoTemaEspecificaciones> temasEspecificaciones = new();
    private static readonly WinForms.ToolStripRenderer renderer = new RendererTema();
    private static bool inicializado;
    internal static bool Oscuro { get; private set; }
    internal static event EventHandler CambioTema;

    private static string RutaPreferencia => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MYG", "Presupuestos", "tema.txt");

    internal static void Inicializar()
    {
        if (inicializado) return;
        inicializado = true;
        MYGTamanoTextoUI.Inicializar();
        try { Oscuro = File.Exists(RutaPreferencia) && File.ReadAllText(RutaPreferencia).Trim() == "oscuro"; }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or System.Security.SecurityException) { }
        WinForms.Application.AddMessageFilter(new FiltroTema());
        WinForms.Application.Idle += (_, _) =>
        {
            foreach (var form in WinForms.Application.OpenForms.Cast<WinForms.Form>().ToArray())
                if (!form.IsDisposed && !controles.TryGetValue(form, out _)) Aplicar(form);
        };
    }

    internal static void Alternar(bool guardarPreferencia = true)
    {
        Inicializar();
        Oscuro = !Oscuro;
        try
        {
            if (guardarPreferencia)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(RutaPreferencia));
                File.WriteAllText(RutaPreferencia, Oscuro ? "oscuro" : "normal");
            }
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or System.Security.SecurityException) { }
        foreach (var form in WinForms.Application.OpenForms.Cast<WinForms.Form>().ToArray()) Aplicar(form);
        // Los editores especializados pueden restaurar los colores de filas,
        // filtros y gráficos con la misma paleta después de los controles base.
        CambioTema?.Invoke(null, EventArgs.Empty);
    }

    internal static WinForms.Button CrearBotonAlternar()
    {
        var boton = new MYG2027_BotonComercial
        {
            Name = "alternarTema", AutoSize = false, Width = 134, Height = 34,
            AccessibleRole = WinForms.AccessibleRole.PushButton,
            AccessibleDescription = "Cambia entre el modo normal y el modo oscuro. La preferencia se guarda para este usuario.",
            TabStop = true, Margin = new WinForms.Padding(8, 4, 8, 4)
        };
        void Actualizar(object sender, EventArgs e)
        {
            boton.Text = Oscuro ? "Modo normal" : "Modo oscuro";
            boton.AccessibleName = boton.Text;
            EstilizarBoton(boton, 2);
        }
        Actualizar(null, EventArgs.Empty);
        CambioTema += Actualizar;
        boton.Click += (_, _) => Alternar();
        boton.Disposed += (_, _) => CambioTema -= Actualizar;
        return boton;
    }

    internal static void Aplicar(WinForms.Control control)
    {
        if (control == null || control.IsDisposed || control.Disposing) return;
        MYGCursoresUI.Aplicar(control);
        var editorEspecificaciones = PropietarioEspecificaciones(control);
        if (editorEspecificaciones != null)
        {
            // Su paleta incluye los controles nativos, el papel y los menús.
            // Registrar sus hijos como controles genéricos volvería a imponer
            // el fondo blanco y un segundo renderer al mostrar o crear ventanas.
            if (!editorEspecificaciones.TemaPreparado || editorEspecificaciones.IsDisposed
                || editorEspecificaciones.Disposing) return;
            var tema = temasEspecificaciones.GetValue(editorEspecificaciones, _ => new EstadoTemaEspecificaciones());
            if (tema.Aplicando) return;
            tema.Aplicando = true;
            try { editorEspecificaciones.AplicarTema(); }
            finally { tema.Aplicando = false; }
            return;
        }
        var estado = controles.GetValue(control, Registrar);
        MYGTemaNativo.Aplicar(control);
        if (control is WinForms.DataGridView tabla) AplicarTabla(tabla);
        else if (control is WinForms.Button boton)
            EstilizarBoton(boton, estilosBoton.GetValue(boton, b => new EstiloBoton { Estilo = InferirBoton(b) }).Estilo);
        else if (control is MYGEditorTextoFormulaHoja editorFormula)
            editorFormula.AplicarTema();
        else if (control is WinForms.RichTextBox)
        {
            // El documento conserva su papel y sus colores de autor. ForeColor
            // y SelectionColor modifican el RTF y no son opciones de tema.
            control.BackColor = Drawing.Color.White;
        }
        else
        {
            control.BackColor = estado.Fondo switch
            {
                FondoControl.Superficie => Superficie,
                FondoControl.Suave => AzulSuave,
                FondoControl.Cabecera => Marino,
                FondoControl.Transparente => Drawing.Color.Transparent,
                _ => Fondo
            };
            if (control.ForeColor != estado.UltimoTexto) estado.TextoOriginal = control.ForeColor;
            bool cabecera = estado.Fondo == FondoControl.Cabecera || (estado.Fondo == FondoControl.Transparente
                && (control.Parent is MYG2027_CabeceraComercial
                    || (control.Parent != null && controles.TryGetValue(control.Parent, out var padre) && padre.Fondo == FondoControl.Cabecera)));
            control.ForeColor = cabecera ? TextoCabecera : TextoSemantico(estado.TextoOriginal);
            estado.UltimoTexto = control.ForeColor;
            if (control is WinForms.LinkLabel enlace)
            {
                enlace.LinkColor = Azul; enlace.ActiveLinkColor = Azul;
                enlace.VisitedLinkColor = Azul; enlace.DisabledLinkColor = Secundario;
            }
            if (control is WinForms.ComboBox combo) combo.FlatStyle = WinForms.FlatStyle.Flat;
            if (control is MYG2027_TarjetaComercial tarjeta) tarjeta.ColorBorde = Borde;
            if (control is WinForms.ToolStrip menu) AplicarMenu(menu);
        }
        if (control.ContextMenuStrip != null) Aplicar(control.ContextMenuStrip);
        if (control is WinForms.TabControl pestanas) MYGTemaPestanas.Aplicar(pestanas);
        foreach (var hijo in control.Controls.Cast<WinForms.Control>().ToArray()) Aplicar(hijo);
        MYGTamanoTextoUI.Aplicar(control);
        if (control is WinForms.Form form) AplicarTitulo(form);
        control.Invalidate();
    }

    private static MYGEspecificacionesEditor PropietarioEspecificaciones(WinForms.Control control)
    {
        var visitados = new HashSet<WinForms.Control>();
        for (var actual = control; actual != null && visitados.Add(actual);)
        {
            if (actual is MYGEspecificacionesEditor editor) return editor;
            // Los desplegables son ventanas independientes: Parent no lleva
            // al editor. OwnerItem mantiene el vínculo incluso en el overflow.
            WinForms.Control propietario = actual is WinForms.ToolStripDropDown desplegable
                ? desplegable.OwnerItem?.Owner ?? desplegable.OwnerItem?.GetCurrentParent() : null;
            if (propietario == null && actual is WinForms.ContextMenuStrip contexto)
                propietario = contexto.SourceControl;
            actual = propietario ?? actual.Parent;
        }
        return null;
    }

    // El rol explícito conserva las cabeceras al alternar los modos.
    internal static void EstilizarCabecera(WinForms.Control control)
    {
        if (control == null || control.IsDisposed) return;
        controles.GetValue(control, Registrar).Fondo = FondoControl.Cabecera;
        Aplicar(control);
    }

    // Los colores de una hoja son formato del documento, no colores de la
    // interfaz que puedan convertirse en blanco al aplicar la paleta.
    internal static void ConservarColoresDocumento(WinForms.DataGridView tabla)
    {
        controles.GetValue(tabla, Registrar).ColoresDeDocumento = true;
    }

    // La estructura y el pie usan una superficie uniforme. Guardar la opción
    // evita que aplicar la paleta general o alternar el tema reponga las franjas.
    internal static void DesactivarFilasAlternas(WinForms.DataGridView tabla)
    {
        controles.GetValue(tabla, Registrar).SinFilasAlternas = true;
        tabla.AlternatingRowsDefaultCellStyle.BackColor = Superficie;
    }

    private static Drawing.Color FondoFilasAlternas(WinForms.DataGridView tabla) =>
        controles.TryGetValue(tabla, out var estado) && estado.SinFilasAlternas ? Superficie : SuperficieAlterna;

    internal static Drawing.Color TextoSobreFondoDocumento(Drawing.Color fondo)
    {
        static double Luminancia(Drawing.Color c)
        {
            static double Canal(byte v) { double n = v / 255d; return n <= .04045 ? n / 12.92 : Math.Pow((n + .055) / 1.055, 2.4); }
            return .2126 * Canal(c.R) + .7152 * Canal(c.G) + .0722 * Canal(c.B);
        }
        var oscuro = RGB(0x263446); var claro = RGB(0xE7EDF5);
        double l = Luminancia(fondo);
        double Contraste(Drawing.Color c) { double t = Luminancia(c); return (Math.Max(l, t) + .05) / (Math.Min(l, t) + .05); }
        return Contraste(oscuro) >= Contraste(claro) ? oscuro : claro;
    }

    private static EstadoControl Registrar(WinForms.Control control)
    {
        var estado = new EstadoControl
        { Fondo = InferirFondo(control), TextoOriginal = control.ForeColor, UltimoTexto = control.ForeColor };
        PrepararTipografia(control);
        control.ControlAdded += (_, e) => Aplicar(e.Control);
        control.ContextMenuStripChanged += (_, _) => { if (control.ContextMenuStrip != null) Aplicar(control.ContextMenuStrip); };
        if (control is WinForms.Form form) form.HandleCreated += (_, _) => AplicarTitulo(form);
        if (control is WinForms.DataGridView tabla)
        {
            tabla.EditingControlShowing += (_, e) => Aplicar(e.Control);
            tabla.CellFormatting += (_, e) =>
            {
                // También adapta estilos creados al refrescar los datos o al
                // abrir una celda; no escribe en filas ni cambia sus valores.
                if (!estado.ColoresDeDocumento)
                {
                    e.CellStyle.BackColor = FondoSemantico(e.CellStyle.BackColor);
                    e.CellStyle.ForeColor = TextoSemantico(e.CellStyle.ForeColor);
                }
                e.CellStyle.SelectionBackColor = Seleccion;
                e.CellStyle.SelectionForeColor = WinForms.SystemInformation.HighContrast
                    ? Drawing.SystemColors.HighlightText : estado.ColoresDeDocumento ? TextoSeleccion : e.CellStyle.ForeColor;
            };
        }
        if (control is WinForms.TabControl pestanas) MYGTemaPestanas.Preparar(pestanas);
        if (control is WinForms.ToolStrip toolStrip) toolStrip.ItemAdded += (_, e) => AplicarItem(e.Item);
        return estado;
    }

    private static void PrepararTipografia(WinForms.Control control)
    {
        // Cambiar la fuente de un contenedor propaga WM_SETFONT al documento.
        // Sólo se normalizan controles de interfaz con fuente pequeña; el RTF,
        // las fuentes de iconos y los encabezados grandes conservan su autoría.
        if (control is not (WinForms.Label or WinForms.CheckBox or WinForms.RadioButton
            or WinForms.TextBox or WinForms.ComboBox or WinForms.UpDownBase
            or WinForms.ListBox or WinForms.ListView or WinForms.TreeView)) return;
        var anterior = MYGTamanoTextoUI.FuenteOriginal(control.Font);
        if (anterior.Size > 10F || anterior.Name.Contains("Symbol", StringComparison.OrdinalIgnoreCase)
            || anterior.Name.Contains("Wingdings", StringComparison.OrdinalIgnoreCase)
            || anterior.Name.Contains("Webdings", StringComparison.OrdinalIgnoreCase)
            || anterior.Name.Contains("MDL2", StringComparison.OrdinalIgnoreCase)
            || anterior.Name.Contains("Consolas", StringComparison.OrdinalIgnoreCase)
            || anterior.Name.Contains("Courier", StringComparison.OrdinalIgnoreCase)) return;
        if (anterior.Name == "Segoe UI" && anterior.Size >= 9F) return;
        var fuente = new Drawing.Font("Segoe UI", Math.Max(9F, anterior.Size), anterior.Style);
        control.Font = fuente;
        control.Disposed += (_, _) => fuente.Dispose();
    }

    private static FondoControl InferirFondo(WinForms.Control control)
    {
        if (control is MYG2027_CabeceraComercial) return FondoControl.Cabecera;
        if (control is WinForms.Form) return FondoControl.Fondo;
        if (control is WinForms.TextBoxBase or WinForms.ComboBox or WinForms.UpDownBase or WinForms.ListBox
            or WinForms.ListView or WinForms.TreeView or WinForms.TabPage or MYG2027_TarjetaComercial or MYG2027_CabeceraFiltros)
            return FondoControl.Superficie;
        var color = control.BackColor;
        if (color.A == 0) return FondoControl.Transparente;
        if (Igual(color, 0x12243B, 0x1D3855, 0x0F1F38, 0x1A375B, 0x1F2F46, 0x1B2431, 0x2D405B, 0x283547)) return FondoControl.Cabecera;
        if (Igual(color, 0xDDEAF7, 0x293A4F, 0xDEE9F6, 0xCCDBED, 0xBFD1E6, 0xDCF0FF,
            0xDCE8F6, 0xB6C8DD, 0xEAF2FF, 0xEDF3FA, 0x25374B)) return FondoControl.Suave;
        if (Igual(color, 0xFFFFFF, 0x303640, 0x2B3039, 0x2B2B2B, 0x242D39, 0x202834, 0xFAFBFC)) return FondoControl.Superficie;
        return FondoControl.Fondo;
    }

    private static int InferirBoton(WinForms.Button boton)
    {
        if (Igual(boton.BackColor, 0x12243B, 0x1D3855, 0x0F1F38, 0x1A375B, 0x303640, 0x1F2F46, 0x1B2431, 0x2D405B, 0x283547)
            && boton.ForeColor.GetBrightness() > .8F) return 3;
        if (Igual(boton.BackColor, 0x2B78C5, 0x479DE8, 0x1E6FEB, 0x0078D7, 0x2C6DAE, 0x2B6CB0, 0x77AFE5)) return 1;
        if (boton.ForeColor.GetBrightness() > .8F && boton.BackColor.GetBrightness() < .6F
            && Math.Abs(boton.BackColor.R - boton.BackColor.B) > 20) return 1;
        return 0;
    }

    private static void AplicarTabla(WinForms.DataGridView tabla)
    {
        bool coloresDeDocumento = controles.TryGetValue(tabla, out var estado) && estado.ColoresDeDocumento;
        tabla.EnableHeadersVisualStyles = false;
        tabla.BorderStyle = WinForms.BorderStyle.None;
        tabla.CellBorderStyle = WinForms.DataGridViewCellBorderStyle.SingleHorizontal;
        tabla.ColumnHeadersBorderStyle = WinForms.DataGridViewHeaderBorderStyle.None;
        tabla.RowHeadersBorderStyle = WinForms.DataGridViewHeaderBorderStyle.None;
        tabla.BackgroundColor = Superficie; tabla.GridColor = Borde;
        tabla.BackColor = Superficie; tabla.ForeColor = Texto;
        tabla.DefaultCellStyle.BackColor = Superficie;
        tabla.DefaultCellStyle.ForeColor = Texto;
        tabla.DefaultCellStyle.SelectionBackColor = Seleccion;
        tabla.DefaultCellStyle.SelectionForeColor = WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.HighlightText : Texto;
        tabla.AlternatingRowsDefaultCellStyle.BackColor = FondoFilasAlternas(tabla);
        tabla.ColumnHeadersDefaultCellStyle.BackColor = CabeceraTabla;
        tabla.ColumnHeadersDefaultCellStyle.ForeColor = TextoCabeceraTabla;
        tabla.ColumnHeadersDefaultCellStyle.SelectionBackColor = CabeceraTabla;
        tabla.ColumnHeadersDefaultCellStyle.SelectionForeColor = TextoCabeceraTabla;
        tabla.RowHeadersDefaultCellStyle.BackColor = Fondo;
        tabla.RowHeadersDefaultCellStyle.ForeColor = Texto;
        tabla.RowHeadersDefaultCellStyle.SelectionBackColor = Seleccion;
        tabla.RowHeadersDefaultCellStyle.SelectionForeColor = TextoSeleccion;
        foreach (WinForms.DataGridViewColumn columna in tabla.Columns)
        {
            if (!coloresDeDocumento) AdaptarEstilo(columna.DefaultCellStyle);
            if (columna.HeaderCell.HasStyle)
            {
                var estilo = columna.HeaderCell.Style;
                estilo.BackColor = FondoSemantico(estilo.BackColor);
                if (!estilo.BackColor.IsEmpty) estilo.ForeColor = Texto;
            }
        }
        if (!coloresDeDocumento) foreach (WinForms.DataGridViewRow fila in tabla.Rows)
        {
            if (fila.HasDefaultCellStyle) AdaptarEstilo(fila.DefaultCellStyle);
            foreach (WinForms.DataGridViewCell celda in fila.Cells)
                if (celda.HasStyle) AdaptarEstilo(celda.Style);
        }
        if (tabla.EditingControl != null) Aplicar(tabla.EditingControl);
    }

    private static void AdaptarEstilo(WinForms.DataGridViewCellStyle estilo)
    {
        if (!estilo.BackColor.IsEmpty) estilo.BackColor = FondoSemantico(estilo.BackColor);
        if (!estilo.ForeColor.IsEmpty) estilo.ForeColor = TextoSemantico(estilo.ForeColor);
        if (!estilo.SelectionBackColor.IsEmpty) estilo.SelectionBackColor = Seleccion;
        if (!estilo.SelectionForeColor.IsEmpty) estilo.SelectionForeColor = WinForms.SystemInformation.HighContrast
            ? Drawing.SystemColors.HighlightText : TextoSemantico(estilo.ForeColor.IsEmpty
                ? estilo.SelectionForeColor : estilo.ForeColor);
    }

    private static Drawing.Color FondoSemantico(Drawing.Color color)
    {
        if (color.IsEmpty) return color;
        for (int i = 0; i < filtrosClaros.Length; i++)
        {
            if (Igual(color, filtrosClaros[i], filtrosOscuros[i])) return ColorFiltro(i + 1);
            if (Igual(color, cabecerasFiltroClaras[i], cabecerasFiltroOscuras[i])) return ColorCabeceraFiltro(i + 1);
        }
        if (Igual(color, 0xF0F3F7, 0x2A3645)) return CabeceraTabla;
        if (Igual(color, 0xDDEAF7, 0x293A4F, 0xDEE9F6, 0xCCDBED, 0xBFD1E6, 0xEAF2FF, 0xEDF3FA, 0x25374B)) return AzulSuave;
        if (Igual(color, 0xEFF4F9, 0x1C1F26, 0xF4F7FB, 0xF4F6F8, 0x191F28)) return Fondo;
        if (Igual(color, 0xF7F9FC, 0x2B3039, 0xF8FAFD, 0xFAFBFC, 0x202834)) return SuperficieAlterna;
        if (color.GetBrightness() > .65F || Igual(color, 0xFFFFFF, 0x303640, 0x242D39)) return Superficie;
        return color;
    }

    private static Drawing.Color TextoSemantico(Drawing.Color color)
    {
        if (WinForms.SystemInformation.HighContrast) return Drawing.SystemColors.WindowText;
        if (color.IsEmpty) return color;
        for (int i = 0; i < titulosClaros.Length; i++)
            if (Igual(color, titulosClaros[i], titulosOscuros[i])) return ColorTitulo(i);
        if (color.ToArgb() == Drawing.Color.Red.ToArgb()) return ColorTitulo(0);
        if (color.ToArgb() == Drawing.Color.Blue.ToArgb()) return ColorTitulo(1);
        if (Igual(color, 0x00AA46, 0x008000)) return ColorTitulo(2);
        if (Igual(color, 0x9646BE)) return ColorTitulo(3);
        if (Igual(color, 0xD27800)) return ColorTitulo(4);
        if (Igual(color, 0x00879B)) return ColorTitulo(5);
        if (Igual(color, 0xAF3769)) return ColorTitulo(6);
        if (Igual(color, 0xB3C0D0, 0x596B80, 0x67788D, 0x4B5C74, 0xD3D3D3, 0x808080, 0xA9B7C8, 0x66758A, 0x647184)) return Secundario;
        if (Igual(color, 0x000000, 0xFFFFFF, 0x20344D, 0xEDF2F7, 0x1F2F44, 0x243549, 0x233D5A, 0x213750, 0xE7EDF5, 0x263446)) return Texto;
        // Colores semánticos arbitrarios (p. ej. avisos) conservan su matiz.
        // Los neutros heredados de Windows se normalizan a texto de la paleta.
        int diferencia = Math.Max(color.R, Math.Max(color.G, color.B)) - Math.Min(color.R, Math.Min(color.G, color.B));
        return diferencia < 35 ? Texto : Oscuro && color.GetBrightness() < .45F ? Mezclar(color, Drawing.Color.White, .45F) : color;
    }

    private static bool Igual(Drawing.Color color, params int[] valores)
    {
        int rgb = color.ToArgb() & 0xFFFFFF;
        return valores.Contains(rgb);
    }

    private static Drawing.Color Mezclar(Drawing.Color a, Drawing.Color b, float proporcion)
        => Drawing.Color.FromArgb(255, (int)Math.Round(a.R + (b.R - a.R) * proporcion),
            (int)Math.Round(a.G + (b.G - a.G) * proporcion), (int)Math.Round(a.B + (b.B - a.B) * proporcion));

    private static void AplicarMenu(WinForms.ToolStrip menu)
    {
        menu.Renderer = renderer; menu.BackColor = Superficie; menu.ForeColor = Texto;
        foreach (WinForms.ToolStripItem item in menu.Items) AplicarItem(item);
    }

    private static void AplicarItem(WinForms.ToolStripItem item)
    {
        item.BackColor = Superficie; item.ForeColor = Texto;
        MYGTamanoTextoUI.Aplicar(item);
        if (item is WinForms.ToolStripMenuItem && item.Owner is WinForms.ToolStripDropDown desplegableMenu)
        {
            float escala = desplegableMenu.DeviceDpi / 96F;
            int horizontal = (int)Math.Round(4F * escala), vertical = (int)Math.Round(5F * escala);
            item.Padding = new WinForms.Padding(horizontal, vertical, horizontal, vertical);
        }
        if (item is WinForms.ToolStripControlHost host) Aplicar(host.Control);
        if (item is WinForms.ToolStripDropDownItem desplegable && desplegable.HasDropDownItems)
        {
            desplegable.DropDown.Renderer = renderer;
            desplegable.DropDown.BackColor = Superficie; desplegable.DropDown.ForeColor = Texto;
            foreach (WinForms.ToolStripItem hijo in desplegable.DropDownItems) AplicarItem(hijo);
        }
    }

    private sealed class ColoresMenu : WinForms.ProfessionalColorTable
    {
        public override Drawing.Color ToolStripDropDownBackground => Superficie;
        public override Drawing.Color ToolStripBorder => Borde;
        public override Drawing.Color MenuBorder => Borde;
        public override Drawing.Color MenuItemBorder => Azul;
        public override Drawing.Color MenuItemSelected => AzulSuave;
        public override Drawing.Color MenuItemSelectedGradientBegin => AzulSuave;
        public override Drawing.Color MenuItemSelectedGradientEnd => AzulSuave;
        public override Drawing.Color MenuItemPressedGradientBegin => Seleccion;
        public override Drawing.Color MenuItemPressedGradientMiddle => Seleccion;
        public override Drawing.Color MenuItemPressedGradientEnd => Seleccion;
        public override Drawing.Color MenuStripGradientBegin => Fondo;
        public override Drawing.Color MenuStripGradientEnd => Fondo;
        public override Drawing.Color ToolStripGradientBegin => Superficie;
        public override Drawing.Color ToolStripGradientMiddle => Superficie;
        public override Drawing.Color ToolStripGradientEnd => Superficie;
        public override Drawing.Color ImageMarginGradientBegin => SuperficieAlterna;
        public override Drawing.Color ImageMarginGradientMiddle => SuperficieAlterna;
        public override Drawing.Color ImageMarginGradientEnd => SuperficieAlterna;
        public override Drawing.Color SeparatorDark => Borde;
        public override Drawing.Color SeparatorLight => Superficie;
        public override Drawing.Color CheckBackground => AzulSuave;
        public override Drawing.Color CheckSelectedBackground => Seleccion;
        public override Drawing.Color CheckPressedBackground => Seleccion;
        public override Drawing.Color ButtonSelectedGradientBegin => AzulSuave;
        public override Drawing.Color ButtonSelectedGradientMiddle => AzulSuave;
        public override Drawing.Color ButtonSelectedGradientEnd => AzulSuave;
        public override Drawing.Color ButtonPressedGradientBegin => Seleccion;
        public override Drawing.Color ButtonPressedGradientMiddle => Seleccion;
        public override Drawing.Color ButtonPressedGradientEnd => Seleccion;
    }

    private sealed class RendererTema : WinForms.ToolStripProfessionalRenderer
    {
        internal RendererTema() : base(new ColoresMenu()) { RoundedEdges = false; }
        protected override void OnRenderMenuItemBackground(WinForms.ToolStripItemRenderEventArgs e)
        {
            if (WinForms.SystemInformation.HighContrast) { base.OnRenderMenuItemBackground(e); return; }
            if (!e.Item.Selected && !e.Item.Pressed) return;
            DibujarSeleccion(e, e.Item.Pressed ? Seleccion : AzulSuave);
        }
        protected override void OnRenderButtonBackground(WinForms.ToolStripItemRenderEventArgs e)
        {
            if (WinForms.SystemInformation.HighContrast) { base.OnRenderButtonBackground(e); return; }
            bool marcado = e.Item is WinForms.ToolStripButton { Checked: true };
            if (!e.Item.Selected && !e.Item.Pressed && !marcado) return;
            DibujarSeleccion(e, e.Item.Pressed || marcado ? Seleccion : AzulSuave);
        }
        private static void DibujarSeleccion(WinForms.ToolStripItemRenderEventArgs e, Drawing.Color color)
        {
            float s = e.ToolStrip.DeviceDpi / 96F;
            var area = new Drawing.RectangleF(2F * s, s,
                Math.Max(0F, e.Item.Width - 4F * s), Math.Max(0F, e.Item.Height - 2F * s));
            if (area.Width < 1F || area.Height < 1F) return;
            var anterior = e.Graphics.SmoothingMode;
            e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var camino = Contorno(area, 5F * s);
            using var fondo = new Drawing.SolidBrush(color);
            e.Graphics.FillPath(fondo, camino);
            e.Graphics.SmoothingMode = anterior;
        }
        protected override void OnRenderImageMargin(WinForms.ToolStripRenderEventArgs e)
        {
            using var fondo = new Drawing.SolidBrush(Superficie);
            e.Graphics.FillRectangle(fondo, e.AffectedBounds);
        }
        protected override void OnRenderSeparator(WinForms.ToolStripSeparatorRenderEventArgs e)
        {
            float s = e.ToolStrip.DeviceDpi / 96F;
            using var borde = new Drawing.Pen(Borde, Math.Max(1F, s));
            if (e.Vertical)
                e.Graphics.DrawLine(borde, e.Item.Width / 2F, 4F * s, e.Item.Width / 2F, e.Item.Height - 4F * s);
            else
                e.Graphics.DrawLine(borde, 10F * s, e.Item.Height / 2F, Math.Max(10F * s, e.Item.Width - 10F * s), e.Item.Height / 2F);
        }
        protected override void OnRenderItemText(WinForms.ToolStripItemTextRenderEventArgs e)
        { e.TextColor = e.Item.Enabled ? Texto : Secundario; base.OnRenderItemText(e); }
        protected override void OnRenderArrow(WinForms.ToolStripArrowRenderEventArgs e)
        { e.ArrowColor = e.Item.Enabled ? Texto : Secundario; base.OnRenderArrow(e); }
    }

    private sealed class FiltroTema : WinForms.IMessageFilter
    {
        public bool PreFilterMessage(ref WinForms.Message m)
        {
            const int MostrarVentana = 0x0018;
            const int Pintar = 0x000F;
            if (m.Msg == MostrarVentana && m.WParam != IntPtr.Zero)
            {
                var control = WinForms.Control.FromHandle(m.HWnd);
                if (control is WinForms.Form or WinForms.ToolStripDropDown) Aplicar(control);
            }
            else if (m.Msg == Pintar)
            {
                var control = WinForms.Control.FromChildHandle(m.HWnd);
                var raiz = control is WinForms.ToolStripDropDown ? control : control?.FindForm();
                if (raiz != null && !controles.TryGetValue(raiz, out _)) Aplicar(raiz);
            }
            return false;
        }
    }

    private static void AplicarTitulo(WinForms.Form form)
    {
        if (!OperatingSystem.IsWindows() || !form.IsHandleCreated) return;
        // DWM sólo cambia el marco de la ventana, nunca el contenido.
        int oscuro = Oscuro && !WinForms.SystemInformation.HighContrast ? 1 : 0;
        try { DwmSetWindowAttribute(form.Handle, 20, ref oscuro, sizeof(int)); }
        catch (Exception e) when (e is DllNotFoundException or EntryPointNotFoundException) { }
    }

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int atributo, ref int valor, int tamano);
}
