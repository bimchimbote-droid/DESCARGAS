using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class TamanoTextoUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        int original = MYGTamanoTextoUI.Porcentaje;
        bool oscuro = MYG2027_TemaComercial.Oscuro;
        try
        {
            MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
            VerificarLecturaYEdicion(exige);
            VerificarDocumentos(exige);
            VerificarCambioDpi(exige);
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
            MYGTamanoTextoUI.Cambiar(original, guardarPreferencia: false);
        }
    }

    private static void VerificarLecturaYEdicion(Action<bool, string> exige)
    {
        using var normal = new Font("Segoe UI", 9);
        using var negrita = new Font("Segoe UI", 9, FontStyle.Bold);
        using var formulario = new Form { ClientSize = new Size(900, 550), Font = normal };
        using var contenedor = new Panel { Dock = DockStyle.Fill, Font = normal };
        using var etiqueta = new Label { Text = "Presupuesto", Font = negrita, AutoSize = true, Dock = DockStyle.Top };
        using var boton = MYGTamanoTextoUI.CrearBoton();
        using var selector = MYGTamanoTextoUI.CrearSelector();
        using var otroSelector = MYGTamanoTextoUI.CrearSelector();
        using var tabla = new DataGridView
        {
            Dock = DockStyle.Fill, Font = normal, AllowUserToAddRows = false,
            DefaultCellStyle = new DataGridViewCellStyle { Font = normal },
            ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { Font = negrita }
        };
        // El pie de costos conserva colores y formato de autor: eso no debe
        // impedir una escala de lectura reversible de su texto en pantalla.
        MYG2027_TemaComercial.ConservarColoresDocumento(tabla);
        tabla.Columns.Add("descripcion", "Descripción");
        tabla.Rows.Add("Trabajo original");
        tabla.Rows[0].DefaultCellStyle.Font = negrita;
        var opciones = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 80 };
        opciones.Controls.AddRange(new Control[] { boton, selector, otroSelector });
        contenedor.Controls.Add(tabla); contenedor.Controls.Add(etiqueta); contenedor.Controls.Add(opciones);
        formulario.Controls.Add(contenedor);
        formulario.Show();
        MYG2027_TemaComercial.Aplicar(formulario);
        Application.DoEvents();
        exige(selector.DropDownStyle == ComboBoxStyle.DropDownList && selector.Items.Count == 3
            && selector.Items.Cast<object>().Select(x => x.ToString()).SequenceEqual(new[]
                { "Compacto (85 %)", "Normal (100 %)", "Grande (115 %)" }),
            "Tamaño del texto debe ofrecer compacto, normal y grande mediante una lista de opciones explícitas.");

        Font efectiva = null;
        tabla.CellFormatting += (_, e) => { if (e.RowIndex == 0) efectiva = e.CellStyle.Font; };
        foreach (int porcentaje in new[] { 85, 115, 100, 85, 100 })
        {
            MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
            // Renovar el tema no debe reinterpretar el tamaño reducido como un
            // nuevo tamaño base ni restaurar el mínimo histórico de 9 puntos.
            MYG2027_TemaComercial.Aplicar(formulario);
            MYG2027_TemaComercial.Aplicar(formulario);
            Application.DoEvents();
            float esperado = 9 * porcentaje / 100f;
            exige(Cerca(etiqueta.Font.SizeInPoints, esperado) && etiqueta.Font.Bold
                && Cerca(boton.Font.SizeInPoints, esperado)
                && Cerca(tabla.DefaultCellStyle.Font.SizeInPoints, esperado)
                && Cerca(tabla.ColumnHeadersDefaultCellStyle.Font.SizeInPoints, esperado)
                && tabla.ColumnHeadersDefaultCellStyle.Font.Bold,
                "Cambiar el tamaño y renovar la apariencia debe conservar la escala exacta y las negritas sin acumular ajustes.");
            _ = tabla.Rows[0].Cells[0].FormattedValue;
            exige(efectiva != null && Cerca(efectiva.SizeInPoints, esperado) && efectiva.Bold,
                "Los estilos explícitos de las filas deben usar el mismo tamaño del texto que la interfaz.");
            exige(Cerca(MYGTamanoTextoUI.FuenteOriginal(efectiva).SizeInPoints, 9)
                && MYGTamanoTextoUI.FuenteOriginal(efectiva).Bold,
                "Una tabla con colores propios debe permitir recuperar la fuente de autor sin la escala de lectura.");
            exige(selector.SelectedIndex == otroSelector.SelectedIndex
                && selector.Text.Contains(porcentaje.ToString()) && boton.Text == $"Texto {porcentaje} % ▾",
                "Los accesos al tamaño del texto deben reflejar el mismo valor al cambiarlo desde otra ventana.");
            exige(Cerca(formulario.Font.SizeInPoints, 9) && Cerca(contenedor.Font.SizeInPoints, 9),
                "La preferencia de lectura no debe modificar las fuentes de formularios ni contenedores.");
        }

        MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
        tabla.Rows.Clear(); tabla.Rows.Add("Fila regenerada");
        tabla.Rows[0].DefaultCellStyle.Font = negrita;
        efectiva = null;
        _ = tabla.Rows[0].Cells[0].FormattedValue;
        exige(efectiva != null && Cerca(efectiva.SizeInPoints, 7.65f) && efectiva.Bold,
            "La escala debe aplicarse también a las filas creadas después de refrescar los datos.");
        using (var nueva = new Label { Text = "Creada después", Font = normal, AutoSize = true })
        {
            opciones.Controls.Add(nueva);
            exige(Cerca(nueva.Font.SizeInPoints, 7.65f),
                "Los controles de interfaz creados después del cambio deben heredar la preferencia de lectura.");
        }
        tabla.CurrentCell = tabla.Rows[0].Cells[0]; tabla.BeginEdit(true);
        var editor = (TextBox)tabla.EditingControl;
        editor.Text = "Edición pendiente"; editor.Select(3, 4);
        MYGTamanoTextoUI.Cambiar(115, guardarPreferencia: false);
        exige(tabla.IsCurrentCellInEditMode && editor.Text == "Edición pendiente"
            && editor.SelectionStart == 3 && editor.SelectionLength == 4
            && Cerca(editor.Font.SizeInPoints, 10.35f),
            "Cambiar el tamaño debe conservar la edición de una celda y su selección sin confirmar ni perder el texto.");
        tabla.CancelEdit(); formulario.Close();
    }

    private static void VerificarDocumentos(Action<bool, string> exige)
    {
        MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
        using var fuente = new Font("Arial", 11);
        using var formulario = new Form { ClientSize = new Size(900, 650) };
        using var documento = new RichTextBox
        {
            Dock = DockStyle.Top, Height = 120, Font = fuente,
            Rtf = @"{\rtf1\ansi{\fonttbl{\f0 Arial;}{\f1 Courier New;}}\f0\fs22\b Título\b0\par\f1\fs19 Texto de autor.}"
        };
        using var hoja = new DataGridView
        {
            Name = "metrado_hoja", Dock = DockStyle.Fill, Font = fuente, AllowUserToAddRows = false,
            DefaultCellStyle = new DataGridViewCellStyle { Font = fuente }
        };
        hoja.Columns.Add("celda", "A"); hoja.Rows.Add("=B2*C2");
        MYG2027_TemaComercial.ConservarColoresDocumento(hoja);
        formulario.Controls.Add(hoja); formulario.Controls.Add(documento);
        formulario.Show(); MYG2027_TemaComercial.Aplicar(formulario); Application.DoEvents();
        documento.Select(3, 4);
        string rtf = documento.Rtf;
        Font fuenteCelda = hoja.DefaultCellStyle.Font;
        foreach (int valor in new[] { 85, 115, 100 })
        {
            MYGTamanoTextoUI.Cambiar(valor, guardarPreferencia: false);
            MYG2027_TemaComercial.Aplicar(formulario);
            exige(documento.Rtf == rtf && documento.SelectionStart == 3 && documento.SelectionLength == 4,
                "La escala de texto de interfaz debe conservar exactamente el RTF y la selección del documento.");
            exige(ReferenceEquals(hoja.DefaultCellStyle.Font, fuenteCelda)
                && Cerca(hoja.Font.SizeInPoints, 11) && Convert.ToString(hoja[0, 0].Value) == "=B2*C2",
                "La escala de interfaz debe conservar las fuentes y fórmulas de la hoja de metrado.");
        }
        formulario.Close();
    }

    private static bool Cerca(float actual, float esperado) => Math.Abs(actual - esperado) < .03f;

    private sealed class EtiquetaDpiPrueba : Label
    {
        internal void SimularCambioDpi(float factor)
        {
            OnDpiChangedBeforeParent(EventArgs.Empty);
            using var nativa = new Font(Font.FontFamily, Font.Size * factor, Font.Style, Font.Unit);
            Font = nativa;
            OnDpiChangedAfterParent(EventArgs.Empty);
        }
    }

    private static void VerificarCambioDpi(Action<bool, string> exige)
    {
        MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
        using var fuente = new Font("Segoe UI", 9);
        using var etiqueta = new EtiquetaDpiPrueba { Font = fuente, Text = "Cambio de monitor" };
        MYG2027_TemaComercial.Aplicar(etiqueta);
        etiqueta.SimularCambioDpi(1.5f);
        exige(Cerca(etiqueta.Font.SizeInPoints, 9 * .85f * 1.5f),
            "Una fuente nativa nueva durante el cambio de DPI debe conservar el porcentaje de lectura sin aplicarlo dos veces.");
        MYGTamanoTextoUI.Cambiar(100, guardarPreferencia: false);
        exige(Cerca(etiqueta.Font.SizeInPoints, 9 * 1.5f),
            "Volver al tamaño normal después de cambiar de monitor debe conservar el factor de DPI nativo.");
        MYGTamanoTextoUI.Cambiar(85, guardarPreferencia: false);
        etiqueta.SimularCambioDpi(1 / 1.5f);
        exige(Cerca(etiqueta.Font.SizeInPoints, 9 * .85f),
            "Regresar al DPI inicial debe recuperar el tamaño compacto sin acumular reducciones.");
        using var explicita = new Font("Segoe UI", 12, FontStyle.Bold);
        etiqueta.Font = explicita;
        exige(Cerca(etiqueta.Font.SizeInPoints, 12 * .85f) && etiqueta.Font.Bold,
            "Un cambio explícito de fuente fuera de una notificación DPI debe respetarse como un nuevo tamaño base.");
    }
}
