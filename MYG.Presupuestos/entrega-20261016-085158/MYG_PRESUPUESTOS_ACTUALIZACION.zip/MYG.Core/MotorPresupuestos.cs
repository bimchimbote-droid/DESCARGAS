using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MYG_2027
{
    public static class MYGMotorPresupuestos
    {
        public static MYGCalculoPresupuesto CrearCalculo(MYGPresupuestoDocumento p) => new(p);
        public static decimal Dinero(MYGPresupuestoDocumento p, decimal n) =>
            decimal.Round(n, p.Costos.DecimalesPrecio, MidpointRounding.AwayFromZero);
        public static decimal Coeficiente(MYGPresupuestoDocumento p, decimal n) =>
            decimal.Round(n, p.Costos.DecimalesCantidad, MidpointRounding.AwayFromZero);
        public static string Grupo(MYGGrupoRecurso g) => g switch
        {
            MYGGrupoRecurso.ManoObra => "MANO DE OBRA",
            MYGGrupoRecurso.Materiales => "MATERIALES",
            MYGGrupoRecurso.Equipo => "EQUIPO",
            MYGGrupoRecurso.Subcontratos => "SUB-CONTRATOS",
            _ => "SUB-PARTIDAS"
        };
        private static void NoNegativo(decimal n, string campo)
        { if (n < 0) throw new InvalidDataException(campo + " no puede ser negativo."); }
        public static bool TieneDatosPropios(MYGDatosPartida d)
        {
            if (d == null) return false;
            if (d.Cantidad != 0 || d.PrecioDirecto != 0 || d.FuenteMetrado != MYGFuenteMetrado.Cantidad ||
                d.RendimientoDiario != 1 || d.JornadaHoras != 8 || !string.IsNullOrEmpty(d.EspecificacionRtf) ||
                !string.IsNullOrEmpty(d.EspecificacionTexto) || d.Analisis.Count > 0 || d.Metrados.Count > 0 || d.MetradosBIM.Count > 0) return true;
            if (!MYGOrdenPresupuestos.OrdenGruposACU(d).SequenceEqual(Enum.GetValues<MYGGrupoRecurso>())) return true;
            var plantilla = MYGHojaMetrado.Crear();
            var hoja = d.Hoja;
            // La identidad integrada no existía en las hojas anteriores. Al
            // comparar, una identidad vacía equivale a la estándar; el resto
            // de las celdas, estilos y configuración se compara íntegramente.
            // Trabajar con una copia evita modificar una hoja al abrir/vincular.
            if (hoja != null && string.IsNullOrEmpty(hoja.IdPlantilla))
            {
                hoja = MYGProyectoStorage.Copia(hoja);
                hoja.IdPlantilla = MYGPlantillasMetrado.Estandar;
            }
            if (hoja != null && hoja.RangoCuerpoPlantilla == null)
            {
                // El nuevo límite de bordes no convierte por sí solo una hoja
                // estándar anterior en datos propios. Comparar sin migrarla.
                hoja = MYGProyectoStorage.Copia(hoja);
                hoja.RangoCuerpoPlantilla = MYGBordesPlantillaMetrado.ObtenerRango(hoja);
            }
            // La hoja también contiene estilos, validación y configuración de impresión.
            // Comparar todo el documento evita perder estos datos al guardar plantillas.
            return hoja != null && !JsonElement.DeepEquals(JsonSerializer.SerializeToElement(hoja), JsonSerializer.SerializeToElement(plantilla));
        }
        public static bool TieneCostos(MYGPresupuestoDocumento p) => p.Costos.Insumos.Count > 0 || p.Costos.Moneda != "S/" ||
            p.Costos.GastosGeneralesPorcentaje != 0 || p.Costos.UtilidadPorcentaje != 0 || p.Costos.ImpuestoPorcentaje != 0 || p.Costos.OtrosImpuestosPorcentaje != 0 ||
            p.Costos.DecimalesPrecio != 2 || p.Costos.DecimalesCantidad != 4 || p.Costos.Responsables?.Count > 0 ||
            p.Items.Any(x => TieneDatosPropios(x.Costos) || x.Costos.Responsables?.Count > 0);
        public static void Validar(MYGPresupuestoDocumento p)
        {
            p.Costos ??= new MYGCostosPresupuesto();
            var c = p.Costos;
            if (c.DecimalesPrecio < 0 || c.DecimalesPrecio > 6 || c.DecimalesCantidad < 0 || c.DecimalesCantidad > 8)
                throw new InvalidDataException("Precisión de costos fuera del rango permitido.");
            if (string.IsNullOrWhiteSpace(c.Moneda)) throw new InvalidDataException("Indique la moneda del presupuesto.");
            NoNegativo(c.GastosGeneralesPorcentaje, "Gastos generales"); NoNegativo(c.UtilidadPorcentaje, "Utilidad");
            NoNegativo(c.ImpuestoPorcentaje, "Impuesto"); NoNegativo(c.OtrosImpuestosPorcentaje, "Otros impuestos"); c.Insumos ??= new();
            var insumos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var r in c.Insumos)
            {
                if (r == null || string.IsNullOrWhiteSpace(r.Id) || !insumos.Add(r.Id) ||
                    string.IsNullOrWhiteSpace(r.Descripcion) || string.IsNullOrWhiteSpace(r.Unidad) ||
                    !Enum.IsDefined(r.Grupo) || r.Grupo == MYGGrupoRecurso.Subpartidas)
                    throw new InvalidDataException("Insumo incompleto o duplicado.");
                NoNegativo(r.Precio, "Precio de " + r.Descripcion);
            }
            var calculo = CrearCalculo(p);
            foreach (var i in p.Items)
            {
                i.Costos ??= new MYGDatosPartida();
                var d = i.Costos; d.Analisis ??= new(); d.Metrados ??= new(); d.MetradosBIM ??= new();
                var ordenGrupos = MYGOrdenPresupuestos.OrdenGruposACU(d);
                if (d.OrdenGruposACU == null || d.OrdenGruposACU.Count == 0) d.OrdenGruposACU = ordenGrupos.ToList();
                d.Hoja ??= MYGHojaMetrado.Crear();
                if (!Enum.IsDefined(d.FuenteMetrado)) throw new InvalidDataException("Fuente de metrado no reconocida.");
                NoNegativo(d.Cantidad, "Metrado"); NoNegativo(d.PrecioDirecto, "Precio directo");
                if (d.RendimientoDiario <= 0 || d.JornadaHoras <= 0)
                    throw new InvalidDataException("Rendimiento y jornada deben ser mayores que cero: " + i.Descripcion);
                var lineas = new HashSet<string>();
                foreach (var r in d.Analisis)
                {
                    if (r == null || string.IsNullOrWhiteSpace(r.Id) || !lineas.Add(r.Id) ||
                        !Enum.IsDefined(r.Grupo) || !Enum.IsDefined(r.Modo))
                        throw new InvalidDataException("Línea de ACU no válida: " + i.Descripcion);
                    NoNegativo(r.Cantidad, "Cantidad ACU"); NoNegativo(r.NumeroRecursos, "Cuadrilla");
                    NoNegativo(r.DesperdicioPorcentaje, "Desperdicio");
                    if (r.Grupo == MYGGrupoRecurso.Subpartidas)
                    {
                        if (r.Modo != MYGModoCantidad.Directa || calculo.Subpartida(r.SubpartidaIdLocal) == null)
                            throw new InvalidDataException("Subpartida inexistente o con modo incompatible: " + i.Descripcion);
                    }
                    else if (!insumos.Contains(r.InsumoId ?? "") ||
                        (calculo.Insumo(r.InsumoId) ?? throw new InvalidOperationException("Sequence contains no matching element")).Grupo != r.Grupo)
                        throw new InvalidDataException("El ACU referencia un insumo inexistente o de otro grupo.");
                    if (r.Modo == MYGModoCantidad.Rendimiento && r.Grupo != MYGGrupoRecurso.ManoObra && r.Grupo != MYGGrupoRecurso.Equipo &&
                        !(r.CalcularCantidadPorUnidad && MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(r, calculo.Insumo(r.InsumoId)?.Unidad)))
                        throw new InvalidDataException("Rendimiento se aplica a mano de obra y equipo.");
                    if (r.Modo == MYGModoCantidad.PorcentajeManoObra && r.Grupo != MYGGrupoRecurso.Equipo)
                        throw new InvalidDataException("El porcentaje de mano de obra se aplica al equipo/herramientas.");
                }
                foreach (var m in d.Metrados)
                {
                    if (m == null) throw new InvalidDataException("Línea de metrado vacía.");
                    NoNegativo(m.Elementos, "Elementos"); NoNegativo(m.CantidadPorElemento, "Cantidad por elemento");
                    NoNegativo(m.Largo ?? 0, "Largo"); NoNegativo(m.Ancho ?? 0, "Ancho"); NoNegativo(m.Alto ?? 0, "Alto");
                }
                if (d.MetradosBIM.Any(x => x == null || x.Cantidad < 0 || string.IsNullOrWhiteSpace(x.ActivoId) ||
                    !MYGProyectoStorage.MismaUnidad(x.Unidad, i.Unidad)))
                    throw new InvalidDataException("Metrado BIM sin activo, con cantidad negativa o unidad incompatible.");
                if (d.MetradosBIM.GroupBy(x => x.ActivoId, StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1))
                    throw new InvalidDataException("El mismo activo BIM aparece dos veces en la partida.");
                MYGHojaCalculo.Validar(d.Hoja);
            }
            // Recorre también subanálisis sin metrado y evita referencias circulares antes de guardar.
            foreach (var i in p.Items.Where(x => !MYGProyectoStorage.EsTitulo(x)))
            { calculo.Analizar(i); calculo.Cantidad(i); }
        }
        public static decimal Parcial(MYGLineaMetrado m) =>
            (m.Descuento ? -1m : 1m) * m.Elementos * m.CantidadPorElemento * (m.Largo ?? 1m) * (m.Ancho ?? 1m) * (m.Alto ?? 1m);
        public static decimal Cantidad(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i)
        {
            if (MYGProyectoStorage.EsTitulo(i)) return 0;
            var d = i.Costos;
            decimal n = d.FuenteMetrado switch
            {
                MYGFuenteMetrado.Manual => d.Metrados.Sum(Parcial),
                MYGFuenteMetrado.BIM => d.MetradosBIM.Sum(x => x.Cantidad),
                MYGFuenteMetrado.Excel => new MYGHojaCalculo(d.Hoja).Numero(d.Hoja.CeldaTotal),
                _ => d.Cantidad
            };
            if (n < 0) throw new InvalidDataException("El metrado neto es negativo: " + i.Descripcion);
            return Coeficiente(p, n);
        }
        public static MYGResultadoACU Analizar(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            CrearCalculo(p).Analizar(i);
        public static string FirmaAnalisis(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            FirmaAnalisis(p, i, CrearCalculo(p));
        internal static string FirmaAnalisis(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i, MYGCalculoPresupuesto calculo)
        {
            var d = i.Costos;
            var contenido = new
            {
                i.Unidad,
                d.PrecioDirecto,
                d.RendimientoDiario,
                d.JornadaHoras,
                p.Costos.DecimalesCantidad,
                p.Costos.DecimalesPrecio,
                d.Analisis,
                Insumos = d.Analisis.Where(r => r.Grupo != MYGGrupoRecurso.Subpartidas)
                    .Select(r => calculo.Insumo(r.InsumoId))
                    .Select(x => new { x?.Id, x?.Precio, x?.Unidad }).ToList()
            };
            return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(contenido))));
        }
        public static bool ConservaAnalisisDelphin(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            CrearCalculo(p).ConservaAnalisisDelphin(i);
        private static string FirmaDatosDelphin(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new
            {
                i.Id,
                i.Descripcion,
                i.Unidad,
                i.Item,
                i.ParentId,
                i.Posicion,
                i.TipoPropuesta,
                Cantidad = Cantidad(p, i),
                Analisis = FirmaAnalisis(p, i),
                i.Costos.EspecificacionTexto,
                i.Costos.EspecificacionRtf
            }))));
        public static void CapturarDatosDelphin(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            i.Costos.FirmaDatosImportadosDelphin = FirmaDatosDelphin(p, i);
        public static bool ConservaDatosDelphin(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            string.Equals(i.Costos.FirmaDatosImportadosDelphin, FirmaDatosDelphin(p, i), StringComparison.Ordinal) &&
            !CrearCalculo(p).TieneReglaPorUnidadEnDescendientes(i);
        private static string FirmaPresupuestoDelphin(MYGPresupuestoDocumento p) =>
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new
            {
                p.Nombre,
                p.Item,
                p.Posicion,
                p.Costos.Moneda,
                p.Costos.DecimalesPrecio,
                p.Costos.DecimalesCantidad,
                p.Costos.GastosGeneralesPorcentaje,
                p.Costos.UtilidadPorcentaje,
                p.Costos.ImpuestoPorcentaje,
                p.Costos.OtrosImpuestosPorcentaje,
                Partidas = p.Items.Select(i => FirmaDatosDelphin(p, i)).ToList()
            }))));
        public static void CapturarPresupuestoDelphin(MYGPresupuestoDocumento p) =>
            p.Costos.FirmaDatosImportadosDelphin = FirmaPresupuestoDelphin(p);
        public static bool ConservaPresupuestoDelphin(MYGPresupuestoDocumento p) =>
            string.Equals(p.Costos.FirmaDatosImportadosDelphin, FirmaPresupuestoDelphin(p), StringComparison.Ordinal);
        public static void CapturarPrecioDelphin(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i, decimal precio, decimal parcial)
        {
            i.Costos.PrecioImportadoDelphin = precio;
            i.Costos.ParcialImportadoDelphin = parcial;
            i.Costos.CantidadImportadaDelphin = Cantidad(p, i);
            i.Costos.FirmaAnalisisImportadoDelphin = FirmaAnalisis(p, i);
        }
        public static decimal TotalPartida(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) =>
            CrearCalculo(p).TotalPartida(i);
        public static MYGResumenCostos Resumen(MYGPresupuestoDocumento p) => CrearCalculo(p).Resumen();
        public static List<MYGInsumoConsolidado> Consolidar(MYGPresupuestoDocumento p, ItemPresupuestoDelphin partida = null) =>
            CrearCalculo(p).Consolidar(partida);
        // Reemplaza el activo, no lo suma otra vez. Ante cualquier ambigüedad no modifica el documento.
        public static int ImportarMetradoBIM(MYGProyectoDocumento proyecto, MYGPresupuestoDocumento p, string json)
        {
            using var doc = JsonDocument.Parse(json); var raiz = doc.RootElement;
            string Texto(JsonElement e, string nombre) => e.TryGetProperty(nombre, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
            string activo = Texto(raiz, "ActivoId"), proyectoId = Texto(raiz, "ProyectoId"), presupuestoId = Texto(raiz, "PresupuestoId");
            if (!raiz.TryGetProperty("VersionFormato", out var version) || version.GetInt32() != 1 || string.IsNullOrWhiteSpace(activo))
                throw new InvalidDataException("El archivo no es un snapshot de metrados MYG.");
            if (!string.IsNullOrWhiteSpace(proyectoId) ? proyectoId != proyecto.IdProyectoRevit :
                !string.Equals(Texto(raiz, "Proyecto"), proyecto.Nombre, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("El snapshot pertenece a otro proyecto.");
            if (!string.IsNullOrWhiteSpace(presupuestoId) && presupuestoId != p.IdPresupuestoRevit)
                throw new InvalidDataException("El snapshot pertenece a otro presupuesto.");
            if (raiz.TryGetProperty("Advertencias", out var advertencias) && advertencias.ValueKind == JsonValueKind.Array && advertencias.GetArrayLength() > 0)
                throw new InvalidDataException("El snapshot tiene advertencias de Revit. Revise las tablas y vuelva a generar el activo antes de aplicarlo al presupuesto.");
            var cambios = new List<(ItemPresupuestoDelphin Item, MYGMetradoBIM Metrado)>();
            foreach (var r in raiz.GetProperty("Partidas").EnumerateArray())
            {
                string clave = Texto(r, "ClavePartida"), delphin = Texto(r, "IdInternoDelphin"), propuesta = Texto(r, "IdPropuesta");
                var candidatas = p.Items.Where(x => !MYGProyectoStorage.EsTitulo(x) &&
                    ((!string.IsNullOrWhiteSpace(clave) && (x.Id == clave || x.IdLocalMYG == clave || x.IdInternoDelphin == clave || x.IdPropuesta == clave)) ||
                    (!string.IsNullOrWhiteSpace(delphin) && x.IdInternoDelphin == delphin) ||
                    (!string.IsNullOrWhiteSpace(propuesta) && x.IdPropuesta == propuesta))).Distinct().ToList();
                if (candidatas.Count != 1) throw new InvalidDataException("Partida BIM no encontrada o ambigua: " + clave);
                var i = candidatas[0]; string unidad = Texto(r, "Unidad");
                if (!string.IsNullOrWhiteSpace(Texto(r, "Advertencia"))) throw new InvalidDataException("Revit informa: " + Texto(r, "Advertencia"));
                if (!MYGProyectoStorage.MismaUnidad(i.Unidad, unidad)) throw new InvalidDataException("La unidad BIM no coincide: " + i.Descripcion);
                if (!r.GetProperty("Metrado").TryGetDecimal(out var cantidad) || cantidad < 0)
                    throw new InvalidDataException("Cantidad BIM no válida.");
                cambios.Add((i, new MYGMetradoBIM
                {
                    ActivoId = activo,
                    DocumentoId = Texto(raiz, "ArchivoRvt"),
                    Tabla = Texto(r, "TablaPlanificacion"),
                    Cantidad = cantidad,
                    Unidad = unidad,
                    FechaUtc = raiz.TryGetProperty("FechaUtc", out var fecha) ? fecha.GetDateTime() : DateTime.UtcNow
                }));
            }
            if (cambios.Count == 0 || cambios.GroupBy(x => x.Item.Id).Any(x => x.Count() > 1))
                throw new InvalidDataException("El snapshot está vacío o contiene partidas duplicadas.");
            foreach (var i in p.Items) i.Costos.MetradosBIM.RemoveAll(x => string.Equals(x.ActivoId, activo, StringComparison.OrdinalIgnoreCase));
            foreach (var c in cambios) c.Item.Costos.MetradosBIM.Add(c.Metrado);
            return cambios.Count;
        }
    }
}
