using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class PresupuestoDetalleCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            var proyecto = MYGProyectoStorage.Nuevo("Proyecto de detalle", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            presupuesto.Item = "01";
            var primera = Partida("01", "CONCRETO EN COLUMNAS", 1);
            var segunda = Partida("02", "ACERO EN COLUMNAS", 2);
            var titulo = Partida("03", "TÍTULO DE ESTRUCTURAS", 3);
            titulo.TipoPropuesta = "TITULO";
            presupuesto.Items.AddRange(new[] { primera, segunda, titulo });
            var manual = new MYGLineaMetrado
            {
                Descripcion = "Metrado existente", Elementos = 2m, CantidadPorElemento = 3m,
                Largo = 2m, Referencia = "Plano E-01", ImagenRuta = "referencia-existente.png"
            };
            primera.Costos.Metrados.Add(manual);
            primera.Costos.MetradosBIM.Add(new MYGMetradoBIM
            {
                ActivoId = "activo-01", DocumentoId = "documento-01", Tabla = "Columnas",
                Unidad = "m³", Cantidad = 48.25m, FechaUtc = new DateTime(2026, 10, 12, 12, 0, 0, DateTimeKind.Utc)
            });
            primera.Costos.Hoja.Poner("G16", "37.5");
            primera.Costos.EspecificacionTexto = "Especificación de concreto conservada.";
            int antes = 0, cambios = 0, guardados = 0, edicionesEstructura = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (nodo, columna, valor) =>
            {
                edicionesEstructura++;
                var vigente = presupuesto.Items.Single(i => i.Id == ((ItemPresupuestoDelphin)nodo).Id);
                if (columna == "ITEM") vigente.Item = valor;
                else if (columna == "DESC") vigente.Descripcion = valor;
            }, () => Array.Empty<MYGUnidadCatalogo>());
            using var formulario = new Form { ClientSize = new Size(1500, 850) };
            formulario.Controls.Add(panel);
            formulario.Show();
            panel.Refrescar();
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();

            var detalle = Controles(panel).OfType<TabControl>().Single(t =>
                t.TabPages.Cast<TabPage>().Any(p => p.Text == "Análisis de C.U."));
            string[] orden = { "Análisis de C.U.", "Específ. técnicas", "Metrados en Excel", "Metrados BIM", "Σ Consol. de Partida" };
            exige(detalle.TabPages.Cast<TabPage>().Select(p => p.Text).SequenceEqual(orden),
                "El detalle debe ofrecer ACU, especificaciones, Excel, BIM y consolidado en ese orden, sin la pestaña de metrado manual.");
            var paginaACU = detalle.TabPages[0];
            var paginaEspecificaciones = detalle.TabPages[1];
            var paginaExcel = detalle.TabPages[2];
            var paginaBIM = detalle.TabPages[3];
            var paginaConsolidado = detalle.TabPages[4];
            var acu = Controles(paginaACU).OfType<DataGridView>().Single(t => t.Columns.Contains("NREC"));
            var hoja = Controles(paginaExcel).OfType<DataGridView>().Single();
            var bim = Controles(paginaBIM).OfType<DataGridView>().Single();
            var consolidado = Controles(paginaConsolidado).OfType<DataGridView>().Single();
            var cabeceraACU = Controles(paginaACU).Single(c => c.Name == "acu_cabecera");
            var cabeceraEspecificaciones = Controles(paginaEspecificaciones).Single(c => c.Name == "espec_cabecera");
            var fuente = Controles(panel).OfType<ComboBox>().Single(c =>
                c.Items.Cast<object>().OfType<MYGFuenteMetrado>().SequenceEqual(Enum.GetValues<MYGFuenteMetrado>()));
            exige(Controles(paginaACU).Contains(fuente) && !Controles(panel).OfType<Button>().Any(b => b.Text == "Usar metrado manual"),
                "El origen del metrado debe seguir disponible desde ACU sin conservar los comandos de la pestaña eliminada.");
            exige(cabeceraACU is MYGEspecificacionesCabecera && !Controles(cabeceraACU).OfType<Button>().Any(),
                "La cabecera de ACU debe compartir el diseño de especificaciones y no ofrecer exportación de documentos Word/PDF.");
            VerificarIconos(detalle, exige);
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", primera.Descripcion, exige);
            VerificarResumenACU(cabeceraACU, panel, 4m, "m³", 4m, 10m, exige);

            var sinCambios = (antes, cambios, guardados);
            foreach (var (pagina, contenido) in new[]
            {
                (paginaACU, (Control)acu), (paginaEspecificaciones, cabeceraEspecificaciones),
                (paginaExcel, hoja), (paginaBIM, bim), (paginaConsolidado, consolidado)
            })
            {
                detalle.SelectedTab = pagina;
                Application.DoEvents();
                exige(detalle.SelectedTab == pagina && contenido.Visible,
                    $"Seleccionar {pagina.Text} debe mostrar su propio contenido tras reorganizar las pestañas.");
                exige(detalle.Top == 0,
                    $"La pestaña {pagina.Text} debe utilizar el espacio superior del detalle sin reservar una franja redundante.");
                VerificarManual();
            }
            exige((antes, cambios, guardados) == sinCambios,
                "Recorrer las nuevas pestañas no debe cambiar los datos, crear historial ni guardar el proyecto.");
            VerificarAnchoACU();

            detalle.SelectedTab = paginaExcel;
            Application.DoEvents();
            exige(hoja.Columns.Contains("G") && hoja.Rows.Count >= 16,
                "La pestaña Excel debe cargar la hoja de la partida antes de utilizar su total.");
            Controles(paginaExcel).OfType<Button>().Single(b => b.Text == "Usar total Excel").PerformClick();
            Application.DoEvents();
            exige(detalle.SelectedTab == paginaExcel && hoja.Visible && !consolidado.Visible &&
                primera.Costos.FuenteMetrado == MYGFuenteMetrado.Excel && MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 37.5m,
                "Usar total Excel debe conservar la página Excel y calcular su metrado; no debe saltar al consolidado por un índice antiguo.");
            VerificarResumenACU(cabeceraACU, panel, 37.5m, "m³", 37.5m, 10m, exige);
            VerificarManual();
            detalle.SelectedTab = paginaBIM;
            Application.DoEvents();
            Controles(paginaBIM).OfType<Button>().Single(b => b.Text == "Usar cantidad BIM").PerformClick();
            Application.DoEvents();
            exige(detalle.SelectedTab == paginaACU && acu.Visible && primera.Costos.FuenteMetrado == MYGFuenteMetrado.BIM &&
                MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 48.25m,
                "Usar cantidad BIM debe volver al ACU y utilizar la cantidad BIM después de cambiar el orden de pestañas.");
            VerificarResumenACU(cabeceraACU, panel, 48.25m, "m³", 48.25m, 10m, exige);
            fuente.SelectedItem = MYGFuenteMetrado.Manual;
            Application.DoEvents();
            exige(primera.Costos.FuenteMetrado == MYGFuenteMetrado.Manual && MYGMotorPresupuestos.Cantidad(presupuesto, primera) == 12m,
                "Los proyectos existentes deben poder seguir usando su metrado manual mediante el selector de origen del ACU.");
            VerificarResumenACU(cabeceraACU, panel, 12m, "m³", 12m, 10m, exige);
            var rendimiento = Controles(panel).OfType<NumericUpDown>().Single(n => n.Name == "acu_rendimiento");
            var jornada = Controles(panel).OfType<NumericUpDown>().Single(n => n.Name == "acu_jornada");
            var precioDirecto = Controles(panel).OfType<NumericUpDown>().Single(n => n.Name == "acu_precio_directo");
            rendimiento.Value = 2m;
            Application.DoEvents();
            VerificarResumenACU(cabeceraACU, panel, 12m, "m³", 6m, 10m, exige);
            jornada.Value = 6m;
            precioDirecto.Value = 12.5m;
            Application.DoEvents();
            exige(primera.Costos.RendimientoDiario == 2m && primera.Costos.JornadaHoras == 6m &&
                primera.Costos.PrecioDirecto == 12.5m,
                "Los controles del ACU deben actualizar el rendimiento, la jornada y el precio directo de la partida seleccionada.");
            VerificarResumenACU(cabeceraACU, panel, 12m, "m³", 6m, 12.5m, exige);
            rendimiento.Value = 1m;
            jornada.Value = 8m;
            precioDirecto.Value = 10m;
            Application.DoEvents();
            VerificarManual();

            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                detalle.SelectedTab = paginaEspecificaciones;
                Application.DoEvents();
                detalle.SelectedTab = paginaACU;
                Application.DoEvents();
                exige(detalle.Top == 0,
                    "Cambiar de tema y de pestaña no debe restaurar la franja redundante del detalle.");
                VerificarEstilo(cabeceraACU, cabeceraEspecificaciones, acu, exige);
                VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", primera.Descripcion, exige);
                VerificarResumenACU(cabeceraACU, panel, 12m, "m³", 12m, 10m, exige);
                VerificarManual();
                VerificarAnchoACU();
            }

            sinCambios = (antes, cambios, guardados);
            panel.SeleccionarEstructura(segunda);
            Application.DoEvents();
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.02", segunda.Descripcion, exige);
            VerificarResumenACU(cabeceraACU, panel, 4m, "m³", 4m, 10m, exige);
            panel.SeleccionarEstructura(presupuesto);
            Application.DoEvents();
            exige(Etiqueta(cabeceraACU, "item").Text == "" &&
                Etiqueta(cabeceraACU, "partida").Text != primera.Descripcion && Etiqueta(cabeceraACU, "partida").Text != segunda.Descripcion &&
                Etiqueta(cabeceraACU, "presupuesto").Text == presupuesto.Nombre,
                "Al seleccionar el presupuesto la cabecera de ACU debe vaciar el ítem y descartar el contexto de la partida anterior.");
            VerificarResumenACUVacio(cabeceraACU, panel, exige);
            panel.SeleccionarEstructura(titulo);
            Application.DoEvents();
            VerificarResumenACUVacio(cabeceraACU, panel, exige);
            panel.SeleccionarEstructura(primera);
            Application.DoEvents();
            exige((antes, cambios, guardados) == sinCambios,
                "Cambiar entre partidas y presupuesto debe actualizar la cabecera sin modificar el modelo ni guardar archivos.");

            var estructura = Controles(panel).OfType<DataGridView>().Single(t => t.Columns.Contains("EXP") && t.Columns.Contains("ITEM"));
            Editar("DESC", "CONCRETO EDITADO");
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", "CONCRETO EDITADO", exige);
            VerificarItemSoloLectura();
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", "CONCRETO EDITADO", exige);

            // El historial sustituye el modelo y conserva sus Id. La cabecera
            // debe volver a leer la instancia actual en vez del Tag anterior.
            presupuesto = MYGProyectoStorage.Copia(presupuesto);
            proyecto.Presupuestos[0] = presupuesto;
            var vigente = presupuesto.Items.Single(i => i.Id == primera.Id);
            vigente.Descripcion = "CONCRETO RESTAURADO";
            panel.Refrescar();
            Application.DoEvents();
            VerificarContexto(cabeceraACU, presupuesto.Nombre, "01.01", vigente.Descripcion, exige);
            VerificarResumenACU(cabeceraACU, panel, 12m, "m³", 12m, 10m, exige);
            exige(vigente.Costos.Metrados.Count == 1 && vigente.Costos.Metrados[0].Descripcion == manual.Descripcion &&
                vigente.Costos.Metrados[0].ImagenRuta == manual.ImagenRuta && MYGMotorPresupuestos.Cantidad(presupuesto, vigente) == 12m && guardados == 0,
                "Refrescar y restaurar el modelo debe conservar el metrado manual existente sin guardar el proyecto.");
            formulario.Close();
            VerificarModalidadRecursosACU(exige);
            VerificarUnidadesNumeroRecursosACU(exige);

            void VerificarAnchoACU()
            {
                detalle.SelectedTab = paginaACU;
                Application.DoEvents();
                acu.CurrentCell = acu.CurrentRow.Cells["DESC"];
                var divisor = (SplitContainer)detalle.Parent.Parent;
                var herramientas = Controles(paginaACU).OfType<ToolStrip>().Single(t => t.Name == "barraHerramientasACU");
                var tamanoOriginal = formulario.ClientSize;
                int distanciaOriginal = divisor.SplitterDistance;
                var seleccionACU = acu.CurrentRow.Tag;
                var seleccionEstructura = Controles(panel).OfType<DataGridView>()
                    .Single(t => t.Columns.Contains("EXP")).CurrentRow.Tag;
                string firmaOriginal = MYGProyectoStorage.Firma(proyecto);
                var contadoresOriginales = (antes, cambios, guardados);
                var anchosFijos = new[] { "UND", "NREC", "CANT", "DESP", "PRECIO", "TOTAL" }
                    .ToDictionary(nombre => nombre, nombre => acu.Columns[nombre].Width);
                int margen = (int)Math.Ceiling(220F * acu.DeviceDpi / 96F);
                int anchoColumnas = acu.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).Sum(c => c.Width);
                try
                {
                    formulario.ClientSize = new Size(Math.Max(tamanoOriginal.Width,
                        divisor.Panel1MinSize + anchoColumnas + herramientas.Width + margen * 2), tamanoOriginal.Height);
                    divisor.SplitterDistance = divisor.Panel1MinSize;
                    Application.DoEvents();
                    VerificarBorde("al ampliar la ventana");
                    int anchoAmplio = acu.Columns["DESC"].Width;
                    divisor.SplitterDistance += margen;
                    Application.DoEvents();
                    VerificarBorde("al mover el divisor");
                    exige(acu.Columns["DESC"].Width < anchoAmplio,
                        "La descripción del ACU debe adaptar su ancho cuando se reduce el panel de detalle.");

                    foreach (bool indice in new[] { true, false })
                    {
                        var menu = acu.ContextMenuStrip;
                        menu.Show(acu, new Point(10, 10));
                        Application.DoEvents();
                        exige(menu.Visible, "El menú del ACU debe abrirse para comprobar sus dos identificaciones.");
                        menu.Items.OfType<ToolStripMenuItem>().Single(i =>
                            i.Text == (indice ? "Mostrar índice unificado" : "Mostrar código estándar")).PerformClick();
                        menu.Close();
                        Application.DoEvents();
                        exige(acu.Columns["INDICE"].Visible == indice && acu.Columns["COD"].Visible != indice,
                            "Cambiar de identificación debe mostrar exclusivamente la columna elegida.");
                        VerificarBorde(indice ? "con índice unificado" : "con código estándar");
                    }
                    int altoAmplio = cabeceraACU.Height;
                    formulario.ClientSize = new Size(divisor.Panel1MinSize +
                        (int)Math.Ceiling(580F * cabeceraACU.DeviceDpi / 96F), tamanoOriginal.Height);
                    divisor.SplitterDistance = divisor.Panel1MinSize;
                    Application.DoEvents();
                    var tiempo = Controles(cabeceraACU).Single(c => c.Name == "acu_cabecera_tiempo");
                    exige(cabeceraACU.Width < (int)Math.Ceiling(700F * cabeceraACU.DeviceDpi / 96F) &&
                        tiempo.Top >= Etiqueta(cabeceraACU, "partida").Bottom && cabeceraACU.Height > altoAmplio,
                        "Al estrechar el detalle, Tiempo debe pasar debajo de la identificación y aumentar la cabecera para no tapar la partida ni la tabla.");
                    VerificarDistribucionResumen(cabeceraACU, acu, exige);
                }
                finally
                {
                    formulario.ClientSize = tamanoOriginal;
                    divisor.SplitterDistance = distanciaOriginal;
                    Application.DoEvents();
                }
                exige(Equals(acu.CurrentRow?.Tag, seleccionACU) &&
                    ReferenceEquals(Controles(panel).OfType<DataGridView>().Single(t => t.Columns.Contains("EXP")).CurrentRow?.Tag,
                        seleccionEstructura) && MYGProyectoStorage.Firma(proyecto) == firmaOriginal &&
                    (antes, cambios, guardados) == contadoresOriginales,
                    "Redimensionar el detalle y alternar sus códigos debe conservar la selección, el modelo, el historial y los guardados.");

                void VerificarBorde(string estado)
                {
                    int tolerancia = Math.Max(3, (int)Math.Ceiling(3F * acu.DeviceDpi / 96F));
                    int bordeDisponible = acu.ClientSize.Width - acu.Controls.OfType<VScrollBar>()
                        .Where(b => b.Visible).Sum(b => b.Width);
                    var total = acu.GetColumnDisplayRectangle(acu.Columns["TOTAL"].Index, false);
                    exige(total.Width > 0 && Math.Abs(total.Right - bordeDisponible) <= tolerancia &&
                        acu.HorizontalScrollingOffset == 0,
                        $"La columna Total del ACU debe llegar al borde útil de la tabla {estado}, sin dejar espacio vacío ni ocultar columnas.");
                    exige(Math.Abs(acu.Right - (herramientas.Visible ? herramientas.Left : paginaACU.ClientSize.Width)) <= tolerancia &&
                        anchosFijos.All(a => acu.Columns[a.Key].Width == a.Value),
                        $"El ACU debe ocupar el ancho disponible y conservar el ancho de las columnas de datos {estado}.");
                }
            }

            void VerificarManual()
            {
                exige(primera.Costos.Metrados.Count == 1 && ReferenceEquals(primera.Costos.Metrados[0], manual) &&
                    manual.Descripcion == "Metrado existente" && manual.Elementos == 2m && manual.CantidadPorElemento == 3m &&
                    manual.Largo == 2m && manual.Ancho == null && manual.Alto == null && !manual.Descuento &&
                    manual.Referencia == "Plano E-01" && manual.ImagenRuta == "referencia-existente.png",
                    "Eliminar la pestaña manual y cambiar de vista o fuente no debe borrar ni modificar las líneas de metrado guardadas.");
            }

            void Editar(string columna, string texto)
            {
                var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is ItemPresupuestoDelphin i && i.Id == primera.Id);
                estructura.CurrentCell = fila.Cells[columna];
                exige(estructura.BeginEdit(true) && estructura.EditingControl is TextBox,
                    $"La prueba de contexto debe editar la celda real {columna} de la estructura.");
                ((TextBox)estructura.EditingControl).Text = texto;
                panel.FinalizarEdicion();
                Application.DoEvents();
            }

            void VerificarItemSoloLectura()
            {
                const BindingFlags privados = BindingFlags.Instance | BindingFlags.NonPublic;
                string firma = MYGProyectoStorage.Firma(proyecto);
                var contadores = (antes, cambios, guardados, edicionesEstructura);
                exige(estructura.Columns["ITEM"].ReadOnly,
                    "La columna Ítem debe mostrar la numeración generada sin permitir su edición.");
                foreach (object nodo in new object[] { presupuesto, titulo, primera, segunda })
                {
                    panel.SeleccionarEstructura(nodo);
                    Application.DoEvents();
                    var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, nodo));
                    var celda = fila.Cells["ITEM"];
                    estructura.CurrentCell = celda;
                    string codigo = Convert.ToString(celda.Value);
                    exige(celda.ReadOnly,
                        "El código de presupuestos, títulos y partidas debe permanecer de solo lectura.");
                    // Clic en el texto, fuera del símbolo de expansión, y doble clic.
                    int x = estructura.Columns["ITEM"].Width - 5;
                    typeof(DataGridView).GetMethod("OnCellMouseClick", privados).Invoke(estructura,
                        new object[] { new DataGridViewCellMouseEventArgs(celda.ColumnIndex, fila.Index,
                            x, 8, new MouseEventArgs(MouseButtons.Left, 1, x, 8, 0)) });
                    typeof(DataGridView).GetMethod("OnCellDoubleClick", privados).Invoke(estructura,
                        new object[] { new DataGridViewCellEventArgs(celda.ColumnIndex, fila.Index) });
                    Application.DoEvents();
                    exige(!estructura.IsCurrentCellInEditMode && ReferenceEquals(estructura.CurrentCell, celda),
                        "Un clic o doble clic en el número del ítem no debe abrir un editor ni cambiar de columna.");

                    var f2 = new KeyEventArgs(Keys.F2);
                    typeof(Control).GetMethod("OnKeyDown", privados).Invoke(estructura, new object[] { f2 });
                    typeof(Control).GetMethod("OnKeyPress", privados).Invoke(estructura, new object[] { new KeyPressEventArgs('9') });
                    Application.DoEvents();
                    exige(f2.Handled && f2.SuppressKeyPress && !estructura.IsCurrentCellInEditMode &&
                        ReferenceEquals(estructura.CurrentCell, celda) && !estructura.BeginEdit(true),
                        "F2, escritura y BeginEdit sobre Ítem deben conservar el código sin abrir otro editor.");

                    // La protección no depende exclusivamente del estilo ReadOnly.
                    estructura.Columns["ITEM"].ReadOnly = false;
                    celda.ReadOnly = false;
                    try
                    {
                        exige(!estructura.BeginEdit(true) && !estructura.IsCurrentCellInEditMode,
                            "CellBeginEdit debe rechazar Ítem aunque un estilo retire ReadOnly por error.");
                    }
                    finally
                    {
                        celda.ReadOnly = true;
                        estructura.Columns["ITEM"].ReadOnly = true;
                    }
                    panel.FinalizarEdicion();
                    Application.DoEvents();
                    exige(Convert.ToString(celda.Value) == codigo && MYGProyectoStorage.Firma(proyecto) == firma &&
                        (antes, cambios, guardados, edicionesEstructura) == contadores,
                        "Intentar editar un ítem no debe cambiar datos, invocar edición, crear historial ni guardar archivos.");
                }
                panel.SeleccionarEstructura(presupuesto);
                estructura.CurrentCell = estructura.CurrentRow.Cells["ITEM"];
                typeof(Control).GetMethod("OnKeyDown", privados).Invoke(estructura,
                    new object[] { new KeyEventArgs(Keys.Left) });
                Application.DoEvents();
                exige(estructura.Rows.Count == 1,
                    "Bloquear el ítem debe conservar el comando de contraer la jerarquía.");
                typeof(Control).GetMethod("OnKeyDown", privados).Invoke(estructura,
                    new object[] { new KeyEventArgs(Keys.Right) });
                Application.DoEvents();
                exige(estructura.Rows.Count == 4 && MYGProyectoStorage.Firma(proyecto) == firma &&
                    (antes, cambios, guardados, edicionesEstructura) == contadores,
                    "Expandir de nuevo debe conservar las filas, la numeración y los datos del presupuesto.");
                panel.SeleccionarEstructura(primera);
                Application.DoEvents();
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static ItemPresupuestoDelphin Partida(string item, string nombre, int posicion) => new()
    {
        Id = MYGProyectoStorage.NuevoId(), Item = item, Descripcion = nombre, Unidad = "m³",
        TipoPropuesta = "PARTIDA", Posicion = posicion,
        Costos = new MYGDatosPartida { Cantidad = 4m, PrecioDirecto = 10m }
    };

    private static void VerificarContexto(Control cabecera, string presupuesto, string item, string partida, Action<bool, string> exige)
    {
        exige(Etiqueta(cabecera, "titulo").Text == "Análisis de costos unitarios" &&
            Etiqueta(cabecera, "presupuesto").Text == presupuesto && Etiqueta(cabecera, "item").Text == item &&
            Etiqueta(cabecera, "partida").Text == partida,
            "La cabecera de ACU debe mostrar su título, presupuesto, código y descripción de la partida vigente.");
    }

    private static void VerificarEstilo(Control acu, Control especificaciones, DataGridView tabla, Action<bool, string> exige)
    {
        exige(acu.Dock == DockStyle.Top && acu.Visible && acu.Top == 0 && tabla.Top >= acu.Bottom &&
            acu.Height >= especificaciones.Height && acu.BackColor.ToArgb() == especificaciones.BackColor.ToArgb() &&
            acu.BackColor.ToArgb() == MYG2027_TemaComercial.Superficie.ToArgb(),
            "El título de ACU debe ocupar una cabecera superior con el fondo de especificaciones y altura suficiente para Tiempo, sin superponerse a la tabla.");
        foreach (string dato in new[] { "titulo", "presupuesto", "item", "partida" })
        {
            var etiquetaACU = Etiqueta(acu, dato);
            var etiquetaEspecificaciones = Etiqueta(especificaciones, dato);
            exige(etiquetaACU.Font.Name == etiquetaEspecificaciones.Font.Name &&
                Math.Abs(etiquetaACU.Font.SizeInPoints - etiquetaEspecificaciones.Font.SizeInPoints) < .01f &&
                etiquetaACU.Font.Style == etiquetaEspecificaciones.Font.Style && etiquetaACU.Location == etiquetaEspecificaciones.Location &&
                etiquetaACU.Height == etiquetaEspecificaciones.Height &&
                etiquetaACU.ForeColor.ToArgb() == etiquetaEspecificaciones.ForeColor.ToArgb() &&
                etiquetaACU.BackColor.ToArgb() == etiquetaEspecificaciones.BackColor.ToArgb(),
                $"La etiqueta {dato} de ACU debe mantener tipografía, posición y colores del diseño de especificaciones en ambos temas.");
        }
        exige(Etiqueta(acu, "titulo").ForeColor.ToArgb() == MYG2027_TemaComercial.Texto.ToArgb() &&
            Etiqueta(acu, "item").ForeColor.ToArgb() == MYG2027_TemaComercial.Secundario.ToArgb(),
            "La cabecera de ACU debe tomar los colores actuales del tema, también después de alternar entre normal y oscuro.");
        var coloresLegibles = new[] { MYG2027_TemaComercial.Texto.ToArgb(), MYG2027_TemaComercial.Secundario.ToArgb() };
        exige(new[] { Etiqueta(acu, "tiempo_cantidad"), Etiqueta(acu, "tiempo_dias") }
                .All(e => coloresLegibles.Contains(e.ForeColor.ToArgb())),
            "Cantidad y días de Tiempo deben conservar los colores de texto legibles del tema claro u oscuro.");
        VerificarDistribucionResumen(acu, tabla, exige);
    }

    private static void VerificarResumenACU(Control cabecera, Control panel, decimal cantidad, string unidad,
        decimal dias, decimal precioUnitario, Action<bool, string> exige, string moneda = "S/")
    {
        exige(Etiqueta(cabecera, "tiempo_cantidad").Text == cantidad.ToString("N3", CultureInfo.InvariantCulture) + " " + unidad &&
            Etiqueta(cabecera, "tiempo_dias").Text == dias.ToString("N3", CultureInfo.InvariantCulture) + " días",
            "Tiempo debe mostrar el metrado vigente con su unidad y los días calculados con cantidad/rendimiento, también al cambiar la fuente del metrado.");
        exige(Controles(panel).OfType<Label>().Single(e => e.Name == "acu_total_precio_unitario").Text ==
                "Total ACU · " + moneda + " " + MYGFormatoPresupuesto.Dinero(precioUnitario) &&
            Controles(panel).OfType<Label>().Single(e => e.Name == "acu_unidad_rendimiento").Text == unidad + "/día ×",
            "El total del ACU debe mostrar su precio unitario y moneda, sin multiplicarlo por el metrado, y el rendimiento debe identificar la unidad diaria de la partida.");
    }

    private static void VerificarResumenACUVacio(Control cabecera, Control panel, Action<bool, string> exige)
    {
        exige(Etiqueta(cabecera, "tiempo_cantidad").Text == "—" && Etiqueta(cabecera, "tiempo_dias").Text == "—" &&
            Controles(panel).OfType<Label>().Single(e => e.Name == "acu_total_precio_unitario").Text == "Total ACU · —",
            "Seleccionar un presupuesto o un título debe vaciar Tiempo y el total unitario para no conservar los valores de la partida anterior.");
    }

    private static void VerificarDistribucionResumen(Control cabecera, DataGridView tabla, Action<bool, string> exige)
    {
        var tiempo = Controles(cabecera).Single(c => c.Name == "acu_cabecera_tiempo");
        Rectangle areaTiempo = tiempo.RectangleToScreen(tiempo.ClientRectangle);
        exige(cabecera.ClientRectangle.Contains(tiempo.Bounds) && tabla.Top >= cabecera.Bottom &&
            new[] { "titulo", "presupuesto", "item", "partida" }.All(dato =>
            {
                var etiqueta = Etiqueta(cabecera, dato);
                return !areaTiempo.IntersectsWith(etiqueta.RectangleToScreen(etiqueta.ClientRectangle));
            }), "Tiempo debe caber completo en la cabecera, sin tapar el título, presupuesto, ítem, descripción ni las filas del ACU.");
    }

    private static void VerificarModalidadRecursosACU(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Cabecera y modalidad del ACU", "ESTRUCTURAS");
        proyecto.Datos = new MYGDatosProyecto { PorRendimientoCuadrilla = true, PorAsignacionRecursos = false };
        var presupuesto = proyecto.Presupuestos.Single();
        presupuesto.Costos.Moneda = "US$";
        var partida = Partida("01", "PARTIDA CON MODOS EXISTENTES", 1);
        partida.Costos.Cantidad = 6m;
        partida.Costos.RendimientoDiario = 2m;
        var operario = new MYGInsumo { Codigo = "MO", Descripcion = "OPERARIO", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 10m };
        var material = new MYGInsumo { Codigo = "MAT", Descripcion = "MATERIAL", Unidad = "kg", Grupo = MYGGrupoRecurso.Materiales, Precio = 3m };
        var herramienta = new MYGInsumo { Codigo = "EQ", Descripcion = "HERRAMIENTAS", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo };
        presupuesto.Costos.Insumos.AddRange(new[] { operario, material, herramienta });
        var manoObra = new MYGRecursoACU { Grupo = operario.Grupo, InsumoId = operario.Id,
            Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 2m, Cantidad = 17m };
        var materialDirecto = new MYGRecursoACU { Grupo = material.Grupo, InsumoId = material.Id,
            Modo = MYGModoCantidad.Directa, Cantidad = 3m };
        var porcentaje = new MYGRecursoACU { Grupo = herramienta.Grupo, InsumoId = herramienta.Id,
            Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 5m };
        partida.Costos.Analisis.AddRange(new[] { manoObra, materialDirecto, porcentaje });
        presupuesto.Items.Add(partida);
        int antes = 0, cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => cambios++, _ => { },
            () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1600, 850) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar();
        panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        var acu = Controles(panel).OfType<DataGridView>().Single(t => t.Name == "acu_recursos");
        var cabecera = Controles(panel).Single(c => c.Name == "acu_cabecera");
        var rendimiento = Controles(panel).OfType<NumericUpDown>().Single(n => n.Name == "acu_rendimiento");
        var jornada = Controles(panel).OfType<NumericUpDown>().Single(n => n.Name == "acu_jornada");
        var porRendimiento = Controles(panel).OfType<RadioButton>().Single(r => r.Name == "acu_por_rendimiento");
        var porAsignacion = Controles(panel).OfType<RadioButton>().Single(r => r.Name == "acu_por_asignacion");
        exige(!acu.Columns.Contains("MODO") && acu.Columns.Contains("NREC") && acu.Columns.Contains("CANT") &&
            porRendimiento.Enabled && porAsignacion.Enabled && porRendimiento.Checked && !porAsignacion.Checked,
            "El ACU debe retirar la columna Modo y mostrar los dos tipos de análisis exclusivos del proyecto sin alterar sus columnas numéricas.");
        VerificarResumenACU(cabecera, panel, 6m, "m³", 3m, 93m, exige, "US$");
        string recursosOriginales = System.Text.Json.JsonSerializer.Serialize(partida.Costos.Analisis);
        var contadores = (antes, cambios);
        porAsignacion.Checked = true;
        Application.DoEvents();
        exige(proyecto.Datos.PorAsignacionRecursos && !proyecto.Datos.PorRendimientoCuadrilla &&
            porAsignacion.Checked && !porRendimiento.Checked && (antes, cambios) == (contadores.antes + 1, contadores.cambios + 1) &&
            System.Text.Json.JsonSerializer.Serialize(partida.Costos.Analisis) == recursosOriginales,
            "Seleccionar Por asignación de recursos debe actualizar únicamente la modalidad del proyecto en un cambio, conservando los modos y coeficientes del ACU existente.");
        VerificarResumenACU(cabecera, panel, 6m, "m³", 3m, 93m, exige, "US$");
        porRendimiento.Checked = true;
        Application.DoEvents();
        exige(proyecto.Datos.PorRendimientoCuadrilla && !proyecto.Datos.PorAsignacionRecursos &&
            porRendimiento.Checked && !porAsignacion.Checked &&
            System.Text.Json.JsonSerializer.Serialize(partida.Costos.Analisis) == recursosOriginales,
            "Volver a Por rendimiento debe conservar los recursos directos, por rendimiento y por porcentaje y sus valores guardados.");
        rendimiento.Value = 4m;
        Application.DoEvents();
        VerificarResumenACU(cabecera, panel, 6m, "m³", 1.5m, 51m, exige, "US$");
        jornada.Value = 4m;
        Application.DoEvents();
        VerificarResumenACU(cabecera, panel, 6m, "m³", 1.5m, 30m, exige, "US$");
        jornada.Value = 2m;
        Application.DoEvents();
        exige(!manoObra.CalcularCantidadPorUnidad,
            "Cambiar rendimiento y jornada debe conservar el cálculo legado de los recursos existentes hasta editar su número de recursos.");
        VerificarResumenACU(cabecera, panel, 6m, "m³", 1.5m, 19.5m, exige, "US$");
        Editar(manoObra, "NREC", "3");
        exige(manoObra.CalcularCantidadPorUnidad && manoObra.Modo == MYGModoCantidad.Rendimiento &&
            manoObra.NumeroRecursos == 3m && manoObra.Cantidad == 17m,
            "Editar Nro. Rec. de hh debe activar rendimiento/jornada × recursos y conservar la cantidad directa almacenada.");
        VerificarResumenACU(cabecera, panel, 6m, "m³", 1.5m, 72m, exige, "US$");
        jornada.Value = 4m;
        Application.DoEvents();
        VerificarResumenACU(cabecera, panel, 6m, "m³", 1.5m, 40.5m, exige, "US$");
        Editar(materialDirecto, "CANT", "4");
        Editar(materialDirecto, "DESP", "25");
        exige(materialDirecto.Modo == MYGModoCantidad.Directa && materialDirecto.Cantidad == 4m &&
            materialDirecto.DesperdicioPorcentaje == 25m && porcentaje.Modo == MYGModoCantidad.PorcentajeManoObra && porcentaje.Cantidad == 5m,
            "Editar cantidad y desperdicio debe conservar el modo directo y las herramientas por porcentaje sin convertirlos por la modalidad global.");
        VerificarResumenACU(cabecera, panel, 6m, "m³", 1.5m, 46.5m, exige, "US$");
        partida.Costos.Cantidad = 0m;
        panel.Refrescar();
        Application.DoEvents();
        VerificarResumenACU(cabecera, panel, 0m, "m³", 0m, 46.5m, exige, "US$");
        panel.SeleccionarEstructura(presupuesto);
        Application.DoEvents();
        VerificarResumenACUVacio(cabecera, panel, exige);
        exige(!porRendimiento.Enabled && !porAsignacion.Enabled,
            "Sin partida seleccionada los tipos de análisis no deben permitir editar la modalidad desde el detalle inactivo.");
        formulario.Close();

        void Editar(MYGRecursoACU recurso, string columna, string texto)
        {
            var fila = acu.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is MYGRecursoACU actual && actual.Id == recurso.Id);
            acu.CurrentCell = fila.Cells[columna];
            exige(acu.BeginEdit(true) && acu.EditingControl is TextBox,
                "La prueba debe editar la celda numérica real del ACU " + columna + ".");
            ((TextBox)acu.EditingControl).Text = texto;
            panel.FinalizarEdicion();
            Application.DoEvents();
        }
    }

    private static void VerificarUnidadesNumeroRecursosACU(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Número de recursos por unidad", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = Partida("01", "RECURSOS CON CANTIDADES GUARDADAS", 1);
        partida.Costos.RendimientoDiario = 12m;
        partida.Costos.JornadaHoras = 8m;
        presupuesto.Items.Add(partida);
        var hh = Agregar("hh", MYGGrupoRecurso.ManoObra, 5m);
        var hm = Agregar("HM", MYGGrupoRecurso.Equipo, 7m, MYGModoCantidad.Rendimiento);
        var he = Agregar(" he ", MYGGrupoRecurso.Equipo, 9m);
        var kg = Agregar("kg", MYGGrupoRecurso.Materiales, 3m);
        var und = Agregar("und", MYGGrupoRecurso.Equipo, 4m);
        var hom = Agregar("hom", MYGGrupoRecurso.ManoObra, 6m);
        var porcentaje = Agregar("%mo", MYGGrupoRecurso.Equipo, 10m, MYGModoCantidad.PorcentajeManoObra);
        var legado = Agregar("jgo", MYGGrupoRecurso.Equipo, 17m, MYGModoCantidad.Rendimiento);
        var subpartida = Partida("02", "SUBPARTIDA CON UNIDAD HH", 2);
        subpartida.Unidad = "hh";
        subpartida.IdLocalMYG = subpartida.Id;
        presupuesto.Items.Add(subpartida);
        var sub = new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = subpartida.Id, Cantidad = 2m, NumeroRecursos = 11m };
        partida.Costos.Analisis.Add(sub);
        MYGProyectoStorage.Renumerar(presupuesto);
        MYGProyectoStorage.Validar(proyecto);
        string firmaOriginal = MYGProyectoStorage.Firma(proyecto);
        int antes = 0, cambios = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antes++, () => cambios++, _ => { },
            () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { }, () => Array.Empty<MYGUnidadCatalogo>());
        panel.InicializarCatalogos(() => null, () => true, () => { });
        using var formulario = new Form { ClientSize = new Size(1600, 850) };
        formulario.Controls.Add(panel);
        formulario.Show();
        panel.Refrescar();
        panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        var acu = Controles(panel).OfType<DataGridView>().Single(t => t.Name == "acu_recursos");
        exige(new[] { hh, hm, he }.All(r => !Fila(r).Cells["NREC"].ReadOnly && Fila(r).Cells["CANT"].ReadOnly) &&
            new[] { kg, und, hom, porcentaje, legado, sub }.All(r => Fila(r).Cells["NREC"].ReadOnly &&
                string.IsNullOrWhiteSpace(Convert.ToString(Fila(r).Cells["NREC"].Value)) &&
                string.IsNullOrWhiteSpace(Convert.ToString(Fila(r).Cells["NREC"].FormattedValue)) &&
                !Fila(r).Cells["CANT"].ReadOnly),
            "Solo he, hh y hm deben mostrar y permitir editar Nro. Rec.; kg, und, hom, porcentajes, jgo legado y subpartidas deben dejarlo vacío y permitir introducir Cantidad.");
        exige(Cantidad(hh) == 5m && Cantidad(hm) == 1.3333m && Cantidad(he) == 9m && Cantidad(kg) == 3m &&
            Cantidad(legado) == 1.3333m && !hh.CalcularCantidadPorUnidad && !hm.CalcularCantidadPorUnidad &&
            MYGProyectoStorage.Firma(proyecto) == firmaOriginal && antes == 0 && cambios == 0,
            "Abrir un proyecto debe conservar las cantidades y costos guardados de recursos directos y por rendimiento sin activar la nueva fórmula ni registrar historial.");

        foreach (var recurso in new[] { kg, und, hom, porcentaje, legado, sub })
        {
            acu.CurrentCell = Fila(recurso).Cells["NREC"];
            exige(!acu.BeginEdit(true), "Nro. Rec. debe impedir la edición de unidades distintas de he/hh/hm, porcentajes y subpartidas.");
        }
        exige(MYGProyectoStorage.Firma(proyecto) == firmaOriginal && antes == 0 && cambios == 0,
            "Intentar editar números de recursos bloqueados debe conservar el modelo y el historial.");

        foreach (var recurso in new[] { hh, hm, he, kg, und, hom, porcentaje, legado, sub })
        {
            acu.CurrentCell = Fila(recurso).Cells["DESC"];
            acu.ContextMenuStrip.Show(acu, new Point(8, 8));
            Application.DoEvents();
            var calculo = acu.ContextMenuStrip.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "calculoRecursoACU");
            var rendimiento = calculo.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Text == "Por rendimiento");
            exige(rendimiento.Enabled == new[] { hh, hm, he }.Contains(recurso),
                "El menú Por rendimiento debe habilitarse únicamente para insumos con unidad he, hh o hm, incluyendo sus variantes de mayúsculas y espacios.");
            acu.ContextMenuStrip.Close();
        }

        var rendimientoDiario = Controles(panel).OfType<NumericUpDown>().Single(n => n.Name == "acu_rendimiento");
        rendimientoDiario.Value = 6m;
        Application.DoEvents();
        exige(Cantidad(hh) == 5m && Cantidad(he) == 9m && !hh.CalcularCantidadPorUnidad && !he.CalcularCantidadPorUnidad &&
            Cantidad(hm) == 2.6667m && !hm.CalcularCantidadPorUnidad,
            "Cambiar el rendimiento debe conservar cantidades directas guardadas y la fórmula legada de hh/hm/he hasta activar expresamente la regla por unidad.");
        rendimientoDiario.Value = 12m;
        Application.DoEvents();
        var antesMenu = (antes, cambios);
        acu.CurrentCell = Fila(hm).Cells["DESC"];
        acu.ContextMenuStrip.Show(acu, new Point(8, 8));
        Application.DoEvents();
        var modoRecurso = acu.ContextMenuStrip.Items.OfType<ToolStripMenuItem>().Single(i => i.Name == "calculoRecursoACU");
        modoRecurso.DropDownItems.OfType<ToolStripMenuItem>().Single(i => i.Text == "Por rendimiento").PerformClick();
        acu.ContextMenuStrip.Close();
        Application.DoEvents();
        exige(hm.CalcularCantidadPorUnidad && hm.Modo == MYGModoCantidad.Rendimiento && hm.Cantidad == 7m &&
            hm.NumeroRecursos == 2m && Cantidad(hm) == 3m && (antes, cambios) == (antesMenu.antes + 1, antesMenu.cambios + 1),
            "Elegir Por rendimiento para un hm legado debe activar rendimiento/jornada × recursos aunque su modo ya fuese Rendimiento, con un cambio y sin sobrescribir su cantidad guardada.");

        EditarYSaltar(hh, "NREC", "1", kg, "CANT");
        exige(hh.NumeroRecursos == 1m && hh.CalcularCantidadPorUnidad && hh.Cantidad == 5m && Cantidad(hh) == 1.5m,
            "Introducir Nro. Rec. 1 y seleccionar otra fila debe confirmar el coeficiente sin reentrada ni modificar la cantidad anterior guardada.");
        EditarYSaltar(hh, "NREC", "3", hh, "DESP");
        EditarYSaltar(hh, "NREC", "1", und, "CANT");
        EditarYSaltar(hh, "NREC", "1", kg, "CANT", permitirSinCambio: true);
        exige(hh.NumeroRecursos == 1m && Cantidad(hh) == 1.5m,
            "Volver a 1 y confirmarlo otra vez debe conservar el cálculo y la celda de destino sin duplicar cambios ni mostrar errores.");

        Editar(hh, "NREC", "3");
        Editar(hm, "NREC", "4");
        Editar(he, "NREC", "2");
        exige(Cantidad(hh) == 4.5m && Cantidad(hm) == 6m && Cantidad(he) == 3m &&
            new[] { hh, hm, he }.All(r => r.CalcularCantidadPorUnidad && r.Modo == MYGModoCantidad.Rendimiento) &&
            hh.Cantidad == 5m && hm.Cantidad == 7m && he.Cantidad == 9m,
            "Editar Nro. Rec. debe activar rendimiento/jornada × recursos para hh/hm/he sin sobrescribir sus cantidades directas almacenadas.");
        Editar(hh, "NREC", "0");
        exige(Cantidad(hh) == 0m && hh.NumeroRecursos == 0m && hh.CalcularCantidadPorUnidad && hh.Cantidad == 5m,
            "Un número de recursos cero debe generar cantidad cero y conservar la cantidad anterior guardada.");
        Editar(kg, "CANT", "0");
        exige(Cantidad(kg) == 0m && kg.Cantidad == 0m && !kg.CalcularCantidadPorUnidad &&
            !porcentaje.CalcularCantidadPorUnidad && porcentaje.Modo == MYGModoCantidad.PorcentajeManoObra &&
            !legado.CalcularCantidadPorUnidad && legado.Modo == MYGModoCantidad.Rendimiento && legado.Cantidad == 17m,
            "Las cantidades manuales deben aceptar cero y conservar porcentajes y modos legados ajenos a la regla por unidad.");
        EditarYSaltar(legado, "CANT", "2.75", kg, "CANT");
        exige(legado.Modo == MYGModoCantidad.Directa && !legado.CalcularCantidadPorUnidad && legado.Cantidad == 2.75m &&
            Cantidad(legado) == 2.75m && legado.NumeroRecursos == 2m &&
            string.IsNullOrWhiteSpace(Convert.ToString(Fila(legado).Cells["NREC"].FormattedValue)),
            "Editar Cantidad de jgo legado debe pasar a cantidad directa, conservar el número almacenado sin mostrarlo y desactivar la fórmula por recursos.");
        panel.Refrescar();
        Application.DoEvents();
        exige(Cantidad(hh) == 0m && Cantidad(hm) == 6m && Cantidad(he) == 3m && Cantidad(legado) == 2.75m &&
            new[] { kg, und, hom, porcentaje, legado, sub }.All(r =>
                string.IsNullOrWhiteSpace(Convert.ToString(Fila(r).Cells["NREC"].FormattedValue))),
            "Refrescar debe conservar las cantidades por unidad y manuales, dejando vacío Nro. Rec. en todas las unidades restantes.");
        formulario.Close();

        MYGRecursoACU Agregar(string unidad, MYGGrupoRecurso grupo, decimal cantidad,
            MYGModoCantidad modo = MYGModoCantidad.Directa)
        {
            var insumo = new MYGInsumo { Codigo = "R-" + partida.Costos.Analisis.Count,
                Descripcion = "RECURSO " + unidad, Unidad = unidad, Grupo = grupo, Precio = 2m };
            presupuesto.Costos.Insumos.Add(insumo);
            var recurso = new MYGRecursoACU { Grupo = grupo, InsumoId = insumo.Id,
                Modo = modo, Cantidad = cantidad, NumeroRecursos = 2m };
            partida.Costos.Analisis.Add(recurso);
            return recurso;
        }
        DataGridViewRow Fila(MYGRecursoACU recurso) => acu.Rows.Cast<DataGridViewRow>()
            .Single(r => r.Tag is MYGRecursoACU actual && actual.Id == recurso.Id);
        decimal Cantidad(MYGRecursoACU recurso) => Convert.ToDecimal(Fila(recurso).Cells["CANT"].Value);
        void EditarYSaltar(MYGRecursoACU recurso, string columna, string texto, MYGRecursoACU recursoDestino,
            string columnaDestino, bool permitirSinCambio = false)
        {
            acu.CurrentCell = Fila(recurso).Cells[columna];
            var filasOriginales = acu.Rows.Cast<DataGridViewRow>().ToArray();
            var recursosOriginales = partida.Costos.Analisis.ToArray();
            var destino = Fila(recursoDestino).Cells[columnaDestino];
            var contadores = (antes, cambios);
            SinErroresNiDialogos(() =>
            {
                exige(acu.BeginEdit(true) && acu.EditingControl is TextBox,
                    "La regresión debe iniciar la edición real de la celda " + columna + ".");
                ((TextBox)acu.EditingControl).Text = texto;
                // El setter confirma la edición dentro de SetCurrentCellAddressCore.
                // No llamar EndEdit ni FinalizarEdicion antes de navegar.
                acu.CurrentCell = destino;
            }, exige, "Confirmar " + columna + "=" + texto + " al cambiar de celda");
            exige(ReferenceEquals(acu.CurrentCell, destino) &&
                acu.Rows.Cast<DataGridViewRow>().SequenceEqual(filasOriginales) &&
                partida.Costos.Analisis.SequenceEqual(recursosOriginales),
                "Confirmar una celda debe conservar las instancias de filas y recursos y dejar seleccionada exactamente la celda elegida por el usuario.");
            exige((antes, cambios) == (contadores.antes + 1, contadores.cambios + 1) ||
                permitirSinCambio && (antes, cambios) == contadores,
                "Confirmar una edición al navegar debe producir un único cambio de historial; repetir el mismo valor puede conservar el historial intacto.");
        }
        void Editar(MYGRecursoACU recurso, string columna, string texto)
        {
            acu.CurrentCell = Fila(recurso).Cells[columna];
            exige(acu.BeginEdit(true) && acu.EditingControl is TextBox, "La prueba debe editar la celda real " + columna + " del recurso.");
            ((TextBox)acu.EditingControl).Text = texto;
            panel.FinalizarEdicion();
            Application.DoEvents();
        }
    }

    private static void VerificarIconos(TabControl detalle, Action<bool, string> exige)
    {
        string[] nombres = { "acu", "especificacion", "excel", "bim", "resumen" };
        exige(detalle.ImageList != null && detalle.ImageList.Images.Count == nombres.Length,
            "Las pestañas de detalle deben conservar un icono por página y retirar el icono del metrado manual.");
        for (int i = 0; i < nombres.Length; i++)
        {
            using var imagen = MYGIconos.Obtener(nombres[i]);
            using var esperados = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
            esperados.Images.Add(imagen);
            int indice = detalle.TabPages[i].ImageIndex;
            exige(indice >= 0 && indice < detalle.ImageList.Images.Count,
                $"La pestaña {detalle.TabPages[i].Text} debe tener un icono válido.");
            using var actual = new Bitmap(detalle.ImageList.Images[indice]);
            using var esperado = new Bitmap(esperados.Images[0]);
            exige(actual.Size == esperado.Size && Enumerable.Range(0, actual.Height).All(y =>
                Enumerable.Range(0, actual.Width).All(x => actual.GetPixel(x, y).ToArgb() == esperado.GetPixel(x, y).ToArgb())),
                $"La pestaña {detalle.TabPages[i].Text} debe mostrar el icono {nombres[i]} tras reorganizar el detalle.");
        }
    }

    private static Label Etiqueta(Control cabecera, string dato) =>
        Controles(cabecera).OfType<Label>().Single(e => e.Name == cabecera.Name + "_" + dato);

    private static void SinErroresNiDialogos(Action accion, Action<bool, string> exige, string contexto)
    {
        var errores = new List<Exception>();
        bool dialogo = false;
        System.Threading.ThreadExceptionEventHandler capturar = (_, e) => errores.Add(e.Exception);
        using var vigilancia = new System.Windows.Forms.Timer { Interval = 25 };
        vigilancia.Tick += (_, _) => EnumThreadWindows(GetCurrentThreadId(), (ventana, _) =>
        {
            if (!IsWindowVisible(ventana)) return true;
            var clase = new StringBuilder(64);
            GetClassName(ventana, clase, clase.Capacity);
            if (clase.ToString() != "#32770") return true;
            // Intentar presenta los errores del editor en un MessageBox nativo.
            // Cerrarlo permite que la prueba falle sin quedar bloqueada allí.
            dialogo = true;
            PostMessage(ventana, 0x0010, IntPtr.Zero, IntPtr.Zero);
            return true;
        }, IntPtr.Zero);
        Application.ThreadException += capturar;
        try
        {
            vigilancia.Start();
            accion();
            Application.DoEvents();
        }
        catch (Exception ex) { errores.Add(ex); }
        finally
        {
            vigilancia.Stop();
            Application.ThreadException -= capturar;
        }
        exige(errores.Count == 0 && !dialogo,
            contexto + " debe completarse sin excepción de reentrada ni diálogo de error." +
            (errores.Count == 0 ? "" : " " + errores[0].Message));
    }

    private delegate bool EnumerarVentana(IntPtr ventana, IntPtr datos);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    private static extern bool EnumThreadWindows(uint hilo, EnumerarVentana enumerar, IntPtr datos);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr ventana, StringBuilder nombre, int capacidad);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr ventana);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern bool PostMessage(IntPtr ventana, uint mensaje, IntPtr wParam, IntPtr lParam);

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
        }
    }
}
