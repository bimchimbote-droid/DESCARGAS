using System;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGEspecificacionesEditor
{
    private MYGEspecificacionesVistaPaginada vistaPaginada;
    private bool vistaPaginadaActiva, actualizacionPaginadaPendiente;
    private bool reglaVerticalAntesPrevia = true;
    private string rtfVistaPaginada;
    private string formatoEntrega = ".doc";
    private ToolStripComboBox selectorFormatoEntrega;

    internal string ExtensionEntrega => formatoEntrega;

    private void PrepararVistaPaginadaExportacion()
    {
        if (vistaPaginada != null) return;
        vistaPaginada = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill, Visible = false };
        lienzo.Parent.Controls.Add(vistaPaginada);
        var fichero = (FlowLayoutPanel)cinta.TabPages[0].Controls[0];
        var grupoFormato = MYGEspecificacionesCinta.Grupo(fichero, "Formato de salida", 210);
        selectorFormatoEntrega = new ToolStripComboBox
        {
            Name = "espec_formato_entrega", AccessibleName = "Formato del documento que se muestra y exporta",
            DropDownStyle = ComboBoxStyle.DropDownList, AutoSize = false, Width = 185
        };
        selectorFormatoEntrega.Items.AddRange(new object[] { "Word 97-2003 (.doc)", "Documento Word (.docx)", "Documento RTF (.rtf)" });
        selectorFormatoEntrega.SelectedIndex = 0;
        selectorFormatoEntrega.SelectedIndexChanged += (_, _) =>
        {
            formatoEntrega = selectorFormatoEntrega.SelectedIndex switch { 1 => ".docx", 2 => ".rtf", _ => ".doc" };
            rtfVistaPaginada = null;
            ActualizarDocumentoVistaPaginada();
        };
        MYGEspecificacionesCinta.Fila(grupoFormato, 16, selectorFormatoEntrega);
        cinta.SelectedIndexChanged += (_, _) => ActualizarModoVistaPaginada();
        documento.TextChanged += (_, _) => ProgramarActualizacionVistaPaginada();
        ActualizarModoVistaPaginada();
    }

    private void ActualizarModoVistaPaginada()
    {
        if (vistaPaginada == null || IsDisposed || Disposing) return;
        bool mostrar = modoExportacion && cinta.SelectedIndex == 0;
        if (mostrar && !vistaPaginadaActiva)
        {
            CancelarArrastreMargenes(); DetenerZoom();
            if (lienzo.Visible) reglaVerticalAntesPrevia = reglaVertical.Visible;
        }
        vistaPaginadaActiva = mostrar;
        lienzo.Visible = !mostrar;
        regla.Visible = !mostrar && verRegla.Checked;
        reglaVertical.Visible = !mostrar && reglaVerticalAntesPrevia;
        vistaPaginada.Visible = mostrar;
        if (mostrar)
        {
            vistaPaginada.BringToFront();
            ActualizarDocumentoVistaPaginada();
        }
        else
        {
            // No retener la copia y las imágenes de impresión mientras se edita.
            vistaPaginada.LiberarDocumento();
            rtfVistaPaginada = null;
            ActualizarVista();
        }
    }

    private void ActualizarDocumentoVistaPaginada()
    {
        if (!vistaPaginadaActiva || vistaPaginada == null || IsDisposed || Disposing) return;
        string rtf = DocumentoRtf, clave = formatoEntrega + rtf;
        if (clave == rtfVistaPaginada) return;
        try
        {
            // Word pagina el archivo final del formato elegido. Guardar copia
            // ese mismo archivo; nunca vuelve a convertirlo después de verlo.
            string contenido = documento.Rtf, extension = formatoEntrega;
            string rtfArchivo = extension == ".rtf" ? RtfParaArchivo : null;
            var configuracion = ConfiguracionImpresion();
            string encabezado = pagina.Encabezado, pie = pagina.Pie;
            bool numerar = pagina.NumerarPaginas;
            vistaPaginada.Cargar(() =>
            {
                using var copia = new RichTextBox { Rtf = contenido, DetectUrls = false };
                return MYGEspecificacionesDocumento.CrearEntregaWord(copia, extension, configuracion,
                    encabezado, pie, numerar, rtfArchivo);
            });
            rtfVistaPaginada = clave;
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            vistaPaginada.MostrarError("No se pudo preparar la vista por páginas. " + ex.Message);
        }
    }

    private void ProgramarActualizacionVistaPaginada()
    {
        if (!vistaPaginadaActiva || actualizacionPaginadaPendiente || !IsHandleCreated || IsDisposed || Disposing) return;
        actualizacionPaginadaPendiente = true;
        BeginInvoke(new Action(() =>
        {
            actualizacionPaginadaPendiente = false;
            if (!IsDisposed && !Disposing) ActualizarDocumentoVistaPaginada();
        }));
    }

    private void MostrarVistaPreliminarPaginada()
    {
        // Una petición explícita también reintenta después de configurar una
        // impresora o corregir un fallo, aunque no haya cambiado el contenido.
        rtfVistaPaginada = null;
        cinta.SelectedIndex = 0;
        ActualizarModoVistaPaginada();
        vistaPaginada?.Focus();
    }

    // La ventana llama también desde Shown: la primera vista siempre es la
    // entrega paginada, sin una casilla ni una orden previa del usuario.
    internal void MostrarVistaPreviaExportacionDirecta()
    {
        cinta.SelectedIndex = 0;
        PrepararVistaPaginadaExportacion();
        ActualizarModoVistaPaginada();
    }

    internal void GuardarEntregaExportacion(string ruta)
    {
        string extension = Path.GetExtension(ruta).ToLowerInvariant();
        int indice = extension switch { ".doc" => 0, ".docx" => 1, ".rtf" => 2,
            _ => throw new InvalidOperationException("Elija una extensión .doc, .docx o .rtf.") };
        MostrarVistaPreviaExportacionDirecta();
        selectorFormatoEntrega.SelectedIndex = indice;
        var entrega = ExigirEntregaExportacion();
        if (entrega.Extension != extension)
            throw new InvalidOperationException("El formato de la vista previa no corresponde al destino.");
        entrega.Guardar(ruta);
    }

    private MYGEspecificacionesEntregaPaginada ExigirEntregaExportacion()
    {
        MostrarVistaPreviaExportacionDirecta();
        // Reintentar si la preparación anterior falló por Word o su configuración.
        if (vistaPaginada.EntregaActual == null) rtfVistaPaginada = null;
        ActualizarDocumentoVistaPaginada();
        if (!vistaPaginada.PrepararEntregaAhora() || vistaPaginada.EntregaActual == null)
            throw new InvalidOperationException("No se pudo preparar el documento de entrega. Revise el mensaje de la vista previa.");
        return vistaPaginada.EntregaActual;
    }

    private void ImprimirEntregaExportacion()
    {
        var entrega = ExigirEntregaExportacion();
        // Imprimir las mismas páginas vectoriales de Word evita recomponer el
        // texto con otra fuente o con otro motor después de la vista previa.
        using var impresion = new PrintDocument { DocumentName = titulo(), DefaultPageSettings = ConfiguracionImpresion() };
        int indice = 0;
        impresion.BeginPrint += (_, _) => indice = 0;
        impresion.QueryPageSettings += (_, e) =>
        {
            var medida = entrega.Paginas[indice].PhysicalSize;
            bool horizontal = medida.Width > medida.Height;
            e.PageSettings.PaperSize = new PaperSize("MYG", horizontal ? medida.Height : medida.Width,
                horizontal ? medida.Width : medida.Height);
            e.PageSettings.Landscape = horizontal;
        };
        impresion.PrintPage += (_, e) =>
        {
            var hoja = entrega.Paginas[indice++];
            var destino = new RectangleF(-e.PageSettings.HardMarginX, -e.PageSettings.HardMarginY,
                hoja.PhysicalSize.Width, hoja.PhysicalSize.Height);
            e.Graphics.DrawImage(hoja.Image, destino);
            e.HasMorePages = indice < entrega.Paginas.Length;
        };
        using var dialogo = new PrintDialog { Document = impresion, UseEXDialog = true, AllowSomePages = false, AllowSelection = false };
        if (dialogo.ShowDialog(this) == DialogResult.OK) impresion.Print();
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (vistaPaginadaActiva && keyData == (Keys.Control | Keys.S))
        { Intentar(() => guardarExportacion?.Invoke()); return true; }
        if (vistaPaginadaActiva && keyData == (Keys.Control | Keys.P))
        { Intentar(() => Imprimir(false)); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
}
