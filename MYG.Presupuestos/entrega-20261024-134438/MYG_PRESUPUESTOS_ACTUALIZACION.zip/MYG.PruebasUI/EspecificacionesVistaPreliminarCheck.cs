using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesVistaPreliminarCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var original = new RichTextBox
        {
            Rtf = @"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}{\f1 Courier New;}}{\colortbl;\red0\green0\blue255;}" +
                @"\pard\qc\f0\fs32\b Encabezado\b0\par\pard\ql\f1\fs20\i\ul\cf1 Cuerpo con formato\ul0\i0\cf0\par" +
                @"\trowd\trgaph90\cellx2000\cellx4000\pard\intbl A\cell B\cell\row\pard\par}"
        };
        original.Select(2, 5);
        original.Modified = false;
        string rtfOriginal = original.Rtf;
        using var copia = MYGEspecificacionesDocumento.CrearCopiaImpresion(original);
        exige(copia.Text == original.Text && copia.Rtf.Contains("Arial Narrow;", StringComparison.Ordinal) &&
                copia.Rtf.Contains(@"\trowd", StringComparison.Ordinal),
            "La copia de impresión debe usar Arial Narrow y conservar el texto y las tablas de la especificación.");

        copia.Select(0, "Encabezado".Length);
        using (var titulo = copia.SelectionFont)
            exige(titulo != null && titulo.Bold && Math.Abs(titulo.SizeInPoints - 16) < .01 &&
                    copia.SelectionAlignment == HorizontalAlignment.Center,
                "La fuente de impresión debe conservar el tamaño, negrita y alineación del encabezado RTF.");
        copia.Select(copia.Text.IndexOf("Cuerpo", StringComparison.Ordinal), "Cuerpo con formato".Length);
        using (var cuerpo = copia.SelectionFont)
            exige(cuerpo != null && cuerpo.Italic && cuerpo.Underline && Math.Abs(cuerpo.SizeInPoints - 10) < .01 &&
                    copia.SelectionColor.ToArgb() == Color.Blue.ToArgb(),
                "Cambiar la familia de impresión debe conservar cursiva, subrayado, tamaño y color de una selección mixta.");
        exige(original.Rtf == rtfOriginal && original.SelectionStart == 2 && original.SelectionLength == 5 && !original.Modified,
            "Preparar Arial Narrow para la vista y la impresión no debe modificar el RTF, la selección ni el estado del editor.");
        VerificarVistaPaginada(exige);
        VerificarEntregaWordPaginada(exige);
    }

    private static void VerificarVistaPaginada(Action<bool, string> exige)
    {
        // Cada sección cabe holgadamente en una hoja; los dos saltos nativos
        // deben crear al menos tres páginas, incluso con un papel amplio.
        using var original = new RichTextBox { Rtf = DocumentoTresPaginas() };
        original.ClearUndo();
        string textoSinEdicion = original.Text;
        original.Select(original.TextLength, 0);
        original.SelectedText = "Edicion reversible para comprobar el historial.";
        exige(original.CanUndo, "El documento de prueba debe conservar una edición real en su historial antes de previsualizar.");
        original.Select(3, 7);
        original.Modified = false;
        string rtfOriginal = original.Rtf;
        bool podiaDeshacer = original.CanUndo, podiaRehacer = original.CanRedo;

        var impresora = new PrinterSettings();
        if (!impresora.IsValid)
        {
            impresora = PrinterSettings.InstalledPrinters.Cast<string>()
                .Select(nombre => new PrinterSettings { PrinterName = nombre }).FirstOrDefault(p => p.IsValid);
        }
        if (impresora == null || !impresora.IsValid)
        {
            Console.WriteLine("OMITIDA: paginación real de especificaciones y navegación de la vista; no hay una impresora válida en Windows. Las comprobaciones de copia y formato sí se ejecutaron.");
            return;
        }

        using var host = new Form { ClientSize = new Size(1000, 720), ShowInTaskbar = false };
        using var vista = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill };
        host.Controls.Add(vista);
        var pagina = new PageSettings(impresora)
        {
            PaperSize = new PaperSize("A4", 827, 1169), Margins = new Margins(75, 75, 75, 75)
        };
        using var documento = MYGEspecificacionesDocumento.CrearDocumentoImpresion(original,
            "Especificaciones paginadas de prueba", pagina, "CABECERA DE PRUEBA", "PIE DE PRUEBA", numeroPagina: true);
        documento.PrinterSettings = impresora;
        int generaciones = 0, paginasImpresas = 0;
        bool soloVistaPrevia = true, liberado = false;
        documento.BeginPrint += (_, e) =>
        {
            generaciones++;
            soloVistaPrevia &= e.PrintAction == PrintAction.PrintToPreview;
        };
        documento.PrintPage += (_, _) => paginasImpresas++;
        documento.Disposed += (_, _) => liberado = true;
        host.Show();
        vista.Cargar(documento);
        exige(Esperar(() => vista.CantidadPaginas >= 3, TimeSpan.FromSeconds(10)),
            "La vista debe generar al menos tres páginas reales con los saltos RTF, encabezado, pie y numeración, sin imprimir papel.");
        exige(soloVistaPrevia && generaciones > 0 && paginasImpresas >= 3 && !liberado,
            "Las páginas deben proceder del motor de impresión en modo de vista previa y conservar su documento mientras se muestran.");
        exige(vista.AjustarPagina && vista.Columnas == 1 &&
                vista.PaginaActual == 1 && !Controles(vista).OfType<RichTextBox>().Any(),
            "La vista debe ajustar una página completa sin mostrar un RichTextBox con desplazamiento interno.");

        var botones = Controles(vista).OfType<ToolStrip>().SelectMany(b => b.Items.OfType<ToolStripButton>())
            .ToDictionary(b => b.Name);
        exige(!botones["espec_previa_anterior"].Enabled && botones["espec_previa_siguiente"].Enabled,
            "La primera página debe permitir avanzar y bloquear el retroceso anterior al inicio.");
        int generacionesIniciales = generaciones;
        botones["espec_previa_siguiente"].PerformClick();
        Application.DoEvents();
        exige(vista.PaginaActual == 2 && botones["espec_previa_anterior"].Enabled,
            "La flecha siguiente debe mostrar la segunda página y habilitar el regreso.");
        botones["espec_previa_anterior"].PerformClick();
        exige(vista.PaginaActual == 1, "La flecha anterior debe recuperar la primera página.");
        vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 2, "La rueda hacia abajo debe avanzar una página completa.");
        vista.NavegarRueda(SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 1, "La rueda hacia arriba debe recuperar la página anterior.");
        vista.NavegarRueda(SystemInformation.MouseWheelScrollDelta);
        vista.IrAPagina(int.MinValue);
        exige(vista.PaginaActual == 1, "La rueda y la selección directa deben respetar el límite inicial.");
        vista.IrAPagina(int.MaxValue);
        exige(vista.PaginaActual == vista.CantidadPaginas && !botones["espec_previa_siguiente"].Enabled,
            "La selección directa debe limitarse a la última página y deshabilitar el avance posterior.");
        vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == vista.CantidadPaginas, "La rueda no debe avanzar más allá de la última página.");
        vista.IrAPagina(1);
        botones["espec_previa_dos_paginas"].PerformClick();
        Application.DoEvents();
        exige(vista.AjustarPagina && vista.Columnas == 2,
            "Dos páginas debe mostrar dos columnas ajustadas al espacio de la vista.");
        botones["espec_previa_una_pagina"].PerformClick();
        vista.Vista.Refresh();
        Application.DoEvents();
        exige(vista.AjustarPagina && vista.Columnas == 1 &&
                generaciones == generacionesIniciales,
            "Volver a una página y navegar debe reutilizar las páginas generadas sin iniciar otra impresión.");
        exige(original.Rtf == rtfOriginal && original.SelectionStart == 3 && original.SelectionLength == 7 &&
                !original.Modified && original.CanUndo == podiaDeshacer && original.CanRedo == podiaRehacer,
            "Generar y recorrer la vista no debe modificar el RTF, selección, estado ni historial del documento original.");

        vista.LiberarDocumento();
        Application.DoEvents();
        exige(liberado && vista.CantidadPaginas == 0 && vista.PaginaActual == 0 &&
                !botones["espec_previa_anterior"].Enabled && !botones["espec_previa_siguiente"].Enabled,
            "Liberar la vista debe disponer su documento y desactivar la navegación sin conservar páginas obsoletas.");
        original.Undo();
        exige(original.Text == textoSinEdicion,
            "El historial anterior a la vista previa debe seguir deshaciendo exactamente la edición original.");
        host.Close();
    }

    private static void VerificarEntregaWordPaginada(Action<bool, string> exige)
    {
        if (!OperatingSystem.IsWindows() || Type.GetTypeFromProgID("Word.Application", throwOnError: false) == null)
        {
            Console.WriteLine("OMITIDA: paginación Word real y coincidencia de los archivos DOC/DOCX exportados; Microsoft Word de escritorio no está instalado. Las comprobaciones de copia y vista MYG mantienen su resultado independiente.");
            return;
        }

        using var original = new RichTextBox { Rtf = DocumentoTresPaginas() };
        original.ClearUndo();
        string textoAntes = original.Text;
        original.Select(original.TextLength, 0);
        original.SelectedText = "Nota reversible que pertenece únicamente a la copia de entrega.";
        original.Select(4, 6);
        original.Modified = false;
        string rtfOriginal = original.Rtf;
        bool deshacerOriginal = original.CanUndo, rehacerOriginal = original.CanRedo;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Entrega-Word-Paginada-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            foreach (string extension in new[] { ".doc", ".docx" })
            {
                using var host = new Form { ClientSize = new Size(1000, 720), ShowInTaskbar = false };
                using var vista = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill };
                host.Controls.Add(vista);
                int conversiones = 0;
                host.Show();
                vista.Cargar(() =>
                {
                    conversiones++;
                    var pagina = new PageSettings
                    {
                        PaperSize = new PaperSize("A4", 827, 1169), Landscape = false,
                        Margins = new Margins(75, 75, 75, 75)
                    };
                    return MYGEspecificacionesDocumento.CrearEntregaWord(original, extension, pagina,
                        "CABECERA WORD DE PRUEBA", "PIE WORD DE PRUEBA", numeroPagina: true);
                });

                // Guardar puede solicitarse antes del callback de pintura: debe
                // preparar exactamente la misma entrega que aparecerá en pantalla.
                exige(vista.PrepararEntregaAhora(),
                    "La entrega " + extension + " debe prepararse con Word incluso antes de procesar el callback pendiente de la vista.");
                var entrega = vista.EntregaActual;
                Application.DoEvents();
                exige(entrega != null && ReferenceEquals(entrega, vista.EntregaActual) && conversiones == 1 &&
                        entrega.Extension == extension && entrega.Paginas.Length >= 3 &&
                        vista.CantidadPaginas == entrega.Paginas.Length,
                    "La vista " + extension + " debe usar una única conversión real de Word y conservar al menos las tres páginas marcadas por sus saltos.");
                exige(entrega.Paginas.All(p => p.Image != null && p.Image.Width > 0 && p.Image.Height > 0 &&
                        p.PhysicalSize.Width > 0 && p.PhysicalSize.Height > 0),
                    "Cada página " + extension + " debe tener la imagen y el tamaño físico devueltos por Word.");

                vista.IrAPagina(2);
                vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
                vista.NavegarRueda(SystemInformation.MouseWheelScrollDelta);
                var botones = Controles(vista).OfType<ToolStrip>().SelectMany(b => b.Items.OfType<ToolStripButton>())
                    .ToDictionary(b => b.Name);
                botones["espec_previa_dos_paginas"].PerformClick();
                vista.Vista.Refresh();
                Application.DoEvents();
                exige(vista.PaginaActual == 2 && vista.Columnas == 2 && vista.PrepararEntregaAhora() &&
                        conversiones == 1 && ReferenceEquals(entrega, vista.EntregaActual),
                    "Navegar, mostrar dos páginas y volver a preparar " + extension + " debe reutilizar el mismo archivo paginado, sin convertirlo otra vez.");

                string primera = Path.Combine(carpeta, "entrega-primera" + extension);
                string segunda = Path.Combine(carpeta, "entrega-segunda" + extension);
                entrega.Guardar(primera);
                entrega.Guardar(segunda);
                exige(MYGEspecificacionesDocumento.EsDocumentoWordValido(primera) &&
                        MYGEspecificacionesDocumento.EsDocumentoWordValido(segunda) &&
                        new FileInfo(primera).Length > 0,
                    "Los dos guardados " + extension + " deben producir documentos Word válidos para su extensión.");
                byte[] bytesPrimera = File.ReadAllBytes(primera), bytesSegunda = File.ReadAllBytes(segunda);
                exige(bytesPrimera.AsSpan().SequenceEqual(bytesSegunda) &&
                        SHA256.HashData(bytesPrimera).AsSpan().SequenceEqual(SHA256.HashData(bytesSegunda)) &&
                        conversiones == 1 && ReferenceEquals(entrega, vista.EntregaActual),
                    "Guardar dos veces " + extension + " debe copiar exactamente los mismos bytes de la entrega mostrada, sin una nueva conversión o repaginación.");
                exige(original.Rtf == rtfOriginal && original.SelectionStart == 4 && original.SelectionLength == 6 &&
                        !original.Modified && original.CanUndo == deshacerOriginal && original.CanRedo == rehacerOriginal,
                    "Preparar, recorrer y guardar " + extension + " no debe cambiar el RTF, la selección ni el historial de la copia original.");
                vista.LiberarDocumento();
                exige(vista.EntregaActual == null && vista.CantidadPaginas == 0,
                    "Liberar " + extension + " debe retirar el snapshot Word y sus páginas de la vista.");
                host.Close();
            }
            original.Undo();
            exige(original.Text == textoAntes,
                "Después de preparar ambas extensiones, el historial debe seguir deshaciendo exactamente la edición previa.");
            Console.WriteLine("OK Word real: paginación DOC y DOCX, navegación sin reconversión y dos copias idénticas de cada entrega.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static string DocumentoTresPaginas()
    {
        var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\f0\fs22 ");
        for (int seccion = 1; seccion <= 3; seccion++)
        {
            rtf.Append(seccion == 1 ? @"\pard " : @"\pard\pagebb ");
            rtf.Append(@"\b SECCION ").Append(seccion).Append(@"\b0\par\pard ");
            for (int linea = 1; linea <= 8; linea++)
                rtf.Append("Contenido sintetico ").Append(seccion).Append('.').Append(linea).Append(@"\par ");
        }
        return rtf.Append('}').ToString();
    }

    private static bool Esperar(Func<bool> listo, TimeSpan limite)
    {
        var reloj = Stopwatch.StartNew();
        while (!listo() && reloj.Elapsed < limite)
        {
            Application.DoEvents();
            Thread.Sleep(15);
        }
        Application.DoEvents();
        return listo();
    }

    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var control in Controles(hijo)) yield return control;
    }
}
