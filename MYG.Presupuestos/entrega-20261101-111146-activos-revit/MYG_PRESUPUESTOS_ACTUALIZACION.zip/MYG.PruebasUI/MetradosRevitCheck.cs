using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradosRevitCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Interfaz Revit", "Estructuras");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Muros", Unidad = "m²" };
        var otra = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Losas", Unidad = "m³", Plantilla = "Otra plantilla" };
        presupuesto.Items.Add(partida); presupuesto.Items.Add(otra);
        int historial = 0, consultas = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => historial++, () => { },
            _ => { }, () => { consultas++; return Task.CompletedTask; }, _ => { });
        panel.InicializarCatalogos(() => "no-usado", () => true, () => { });
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
        var tipo = typeof(MYGPanelPresupuesto);
        T Campo<T>(string nombre) => (T)tipo.GetField(nombre, flags)!.GetValue(panel)!;
        void Cargar(ItemPresupuestoDelphin item)
        {
            tipo.GetField("actual", flags)!.SetValue(panel, item);
            tipo.GetMethod("CargarConfiguracionMetradosRevit", flags)!.Invoke(panel, null);
        }
        Cargar(partida);
        var plantilla = Campo<TextBox>("plantillaMetradoRevit");
        var filtros = Campo<DataGridView>("filtrosMetradoRevit");
        var pestanas = Campo<TabControl>("detalle");
        exige(pestanas.TabPages.Cast<TabPage>().Any(p => p.Text == "Metrados Revit"), "Falta la pestaña Revit junto al metrado XLS.");
        exige(filtros.Rows.Count == 5 && !filtros.AllowUserToAddRows, "La interfaz debe limitarse a cinco filtros.");
        plantilla.Text = "Metrado de muros";
        filtros.Rows[4].Cells["PARAMETRO"].Value = "Nivel";
        filtros.Rows[4].Cells["REGLA"].Value = "Igual";
        filtros.Rows[4].Cells["VALOR"].Value = "01";
        panel.FinalizarEdicion();
        exige(partida.Plantilla == "Metrado de muros" && partida.Filtros.Count == 5 && partida.Filtros[4].Valor == "01",
            "No se conserva la plantilla y la posición del quinto filtro.");
        exige(historial == 1 && consultas == 0, "La edición debe registrar historial sin consultar Revit.");
        panel.FinalizarEdicion();
        exige(historial == 1, "Finalizar sin cambios no debe duplicar historial.");
        Cargar(otra);
        exige(plantilla.Text == "Otra plantilla" && partida.Plantilla == "Metrado de muros", "Las partidas deben conservar configuraciones independientes.");
        Cargar(partida);
        exige(Convert.ToString(filtros.Rows[4].Cells["VALOR"].Value) == "01", "El filtro debe sobrevivir al cambio de partida.");
        partida.Filtros.Add(new FiltroPlanificacion { Parametro = "Legado", Regla = "Igual", Valor = "Conservar" });
        Cargar(partida);
        exige(filtros.ReadOnly && filtros.Rows.Count == 6, "Los filtros heredados adicionales deben conservarse y mostrarse para consulta.");
    }
}
