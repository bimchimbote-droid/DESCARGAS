using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class ActivosRevitUICheck
{
    private const BindingFlags Privados = BindingFlags.NonPublic | BindingFlags.Instance;
    private static T Campo<T>(object objeto, string nombre) => (T)objeto.GetType().GetField(nombre, Privados)!.GetValue(objeto)!;
    private static void Invocar(object objeto, string nombre) => objeto.GetType().GetMethod(nombre, Privados)!.Invoke(objeto, null);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Activos de prueba", "Estructuras");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Columnas", Unidad = "m³" };
        presupuesto.Items.Add(partida);
        var local = MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Bloque A", RutaLocal = @"C:\Modelos\A.rvt" });
        MYGActivosRevit.GuardarActivo(proyecto, new MYGActivoRevit { Nombre = "Bloque B", Origen = MYGOrigenActivoRevit.Autodesk,
            ProyectoAutodeskId = "proyecto-prueba", ModeloAutodeskId = "modelo-prueba" });
        string firma = MYGProyectoStorage.Firma(proyecto);
        using (var dialogo = new MYGActivosRevitForm(proyecto, true))
        {
            Campo<TextBox>(dialogo, "nombre").Text = "Otro activo";
            Campo<TextBox>(dialogo, "ruta").Text = @"C:\Modelos\C.rvt";
            Invocar(dialogo, "GuardarEditor");
            exige(MYGProyectoStorage.Firma(proyecto) == firma, "Guardar en el diálogo no debe modificar la obra antes de Aplicar.");
            exige(Campo<MYGProyectoDocumento>(dialogo, "copia").ActivosRevit!.Activos.Count == 3, "El alta debe quedar en la copia del diálogo.");
        }
        exige(MYGProyectoStorage.Firma(proyecto) == firma, "Cancelar el gestor debe conservar la obra original.");
        using (var consulta = new MYGActivosRevitForm(proyecto, false))
            exige(Campo<TextBox>(consulta, "nombre").ReadOnly, "El gestor debe admitir consulta sin editar.");

        MYGActivosRevit.Asignar(proyecto, presupuesto.Id, partida.Id, local.Id);
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.BIM;
        partida.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = local.Id, Tabla = "Columnas", Cantidad = 12m, Unidad = "m³", FechaUtc = DateTime.UtcNow });
        int historial = 0, consultas = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => historial++, () => { }, _ => { },
            () => { consultas++; return Task.CompletedTask; }, _ => { });
        panel.InicializarCatalogos(() => "no-usado", () => true, () => { });
        panel.InicializarActivosRevit(() => proyecto, () => { });
        typeof(MYGPanelPresupuesto).GetField("actual", Privados)!.SetValue(panel, partida);
        Invocar(panel, "CargarConfiguracionMetradosRevit");
        var asignaciones = Campo<DataGridView>(panel, "asignacionesRevit");
        exige(asignaciones.Rows.Count == 1 && Convert.ToString(asignaciones.Rows[0].Cells["ACTIVO"].Value) == "Bloque A",
            "La partida debe mostrar únicamente sus activos asignados, con nombre legible.");
        asignaciones.Rows[0].Cells["INCLUIR"].Value = false;
        exige(partida.Costos.MetradosBIM.Single().ExcluirDelTotal && !proyecto.ActivosRevit!.Asignaciones.Single().IncluirEnTotal,
            "El checkbox de asignación debe excluir el resultado asociado sin borrarlo.");
        exige(historial == 1 && consultas == 0, "La asignación debe guardar historial sin contactar Revit o Autodesk.");
        panel.ConfigurarPermisoNube(() => true, () => new MYGPermisosModulos { MetradosExcel = false });
        exige(Campo<DataGridView>(panel, "bim").ReadOnly && asignaciones.ReadOnly,
            "El permiso de metrados debe bloquear cambios de inclusión.");
    }
}
