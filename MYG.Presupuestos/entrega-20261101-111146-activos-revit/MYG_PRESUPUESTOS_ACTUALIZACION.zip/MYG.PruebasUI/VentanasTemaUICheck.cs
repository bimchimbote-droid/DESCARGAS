using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class VentanasTemaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private const int WmSysCommand = 0x0112;
    private const int ScMinimize = 0xF020, ScMaximize = 0xF030, ScClose = 0xF060, ScRestore = 0xF120;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    [DllImport("dwmapi.dll")]
    private static extern int DwmGetWindowAttribute(IntPtr ventana, int atributo, out int valor, int tamano);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            VerificarVentanasConTitulo(exige);
            VerificarDialogos(exige);
            VerificarVentanasSinTitulo(exige);
            VerificarEditor(exige);
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != original) MYG2027_TemaComercial.Alternar(false);
        }
    }

    private static void VerificarVentanasConTitulo(Action<bool, string> exige)
    {
        foreach (var borde in new[] { FormBorderStyle.FixedDialog, FormBorderStyle.FixedSingle })
        {
            using var ventana = new Form
            {
                Text = "Edición conservada", FormBorderStyle = borde,
                ControlBox = false, MinimizeBox = false, MaximizeBox = false,
                ClientSize = new Size(520, 230), ShowInTaskbar = false
            };
            using var entrada = new TextBox { Text = "Dato pendiente sin guardar", Dock = DockStyle.Top };
            using var aceptar = new Button { Text = "Aceptar", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom };
            using var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Dock = DockStyle.Bottom };
            ventana.Controls.AddRange(new Control[] { entrada, aceptar, cancelar });
            ventana.AcceptButton = aceptar; ventana.CancelButton = cancelar;
            // Mostrar una ventana creada después de Inicializar también debe
            // prepararla; no se llama al tema desde su propio constructor.
            ventana.Show(); Application.DoEvents();
            foreach (bool oscuro in new[] { false, true, false })
            {
                CambiarTema(oscuro);
                exige(ventana.ControlBox && ventana.MinimizeBox && ventana.MaximizeBox,
                    $"Una ventana {borde} debe ofrecer minimizar, maximizar/restaurar y cerrar en ambos temas.");
                exige(ventana.FormBorderStyle == borde && !ventana.ShowInTaskbar,
                    "Añadir los botones del título debe conservar el borde y la pertenencia a la barra de tareas.");
                VerificarColoresTitulo(ventana, exige);
                foreach (var paso in new[]
                {
                    (ScMinimize, FormWindowState.Minimized), (ScRestore, FormWindowState.Normal),
                    (ScMaximize, FormWindowState.Maximized), (ScRestore, FormWindowState.Normal)
                })
                {
                    Comando(ventana, paso.Item1);
                    exige(ventana.WindowState == paso.Item2 && ventana.Visible,
                        "Los comandos nativos de minimizar, maximizar y restaurar deben seguir funcionando.");
                    exige(entrada.Text == "Dato pendiente sin guardar" && ventana.DialogResult == DialogResult.None &&
                        ReferenceEquals(ventana.AcceptButton, aceptar) && ReferenceEquals(ventana.CancelButton, cancelar) &&
                        aceptar.DialogResult == DialogResult.OK && cancelar.DialogResult == DialogResult.Cancel,
                        "Usar los botones del título debe conservar la edición y los resultados de Aceptar y Cancelar.");
                }
                typeof(Control).GetMethod("RecreateHandle", Privados).Invoke(ventana, null); Application.DoEvents();
                exige(ventana.ControlBox && ventana.MinimizeBox && ventana.MaximizeBox &&
                    entrada.Text == "Dato pendiente sin guardar",
                    "Recrear el identificador nativo debe conservar los botones y los datos de la ventana.");
                VerificarColoresTitulo(ventana, exige);
            }
            ventana.Close();
        }
    }

    private static void VerificarDialogos(Action<bool, string> exige)
    {
        foreach (int accion in new[] { 0, 1, 2 })
        {
            using var dialogo = new Form
            {
                Text = "Confirmar cambios", FormBorderStyle = FormBorderStyle.FixedDialog,
                MinimizeBox = false, MaximizeBox = false, ClientSize = new Size(460, 220)
            };
            using var entrada = new TextBox { Text = "Contenido del diálogo", Dock = DockStyle.Top };
            using var aceptar = new Button { Text = "Aceptar", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom };
            using var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Dock = DockStyle.Bottom };
            dialogo.Controls.AddRange(new Control[] { entrada, aceptar, cancelar });
            dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
            Exception fallo = null;
            dialogo.Shown += (_, _) => dialogo.BeginInvoke(new Action(() =>
            {
                try
                {
                    exige(dialogo.ControlBox && dialogo.MinimizeBox && dialogo.MaximizeBox,
                        "Los diálogos modales deben tener los tres botones nativos del título.");
                    Comando(dialogo, ScMaximize); Comando(dialogo, ScRestore);
                    exige(entrada.Text == "Contenido del diálogo" && dialogo.DialogResult == DialogResult.None &&
                        ReferenceEquals(dialogo.AcceptButton, aceptar) && ReferenceEquals(dialogo.CancelButton, cancelar),
                        "Maximizar y restaurar un diálogo no debe confirmarlo, cancelarlo ni perder sus campos.");
                    if (accion == 0) PulsarDialogo(dialogo, Keys.Enter);
                    else if (accion == 1) PulsarDialogo(dialogo, Keys.Escape);
                    else Comando(dialogo, ScClose);
                    exige(dialogo.DialogResult != DialogResult.None,
                        "Aceptar, cancelar o cerrar debe terminar el diálogo sin dejar una ventana modal bloqueada.");
                }
                catch (Exception ex) { fallo = ex; dialogo.DialogResult = DialogResult.Abort; dialogo.Close(); }
            }));
            var resultado = dialogo.ShowDialog();
            if (fallo != null) throw new InvalidOperationException("Falló la comprobación del marco de un diálogo modal.", fallo);
            exige(resultado == (accion == 0 ? DialogResult.OK : DialogResult.Cancel),
                "Enter debe aceptar el diálogo; Escape y el botón Cerrar deben conservar el resultado Cancelar.");
        }
    }

    private static void VerificarVentanasSinTitulo(Action<bool, string> exige)
    {
        using var propietario = new Form { ClientSize = new Size(540, 300) };
        using var incrustada = new Form
        {
            TopLevel = false, FormBorderStyle = FormBorderStyle.FixedSingle,
            ControlBox = false, MinimizeBox = false, MaximizeBox = false, Dock = DockStyle.Fill
        };
        propietario.Controls.Add(incrustada); propietario.Show(); incrustada.Show();
        using var sinBorde = new Form
        {
            FormBorderStyle = FormBorderStyle.None, ControlBox = false,
            MinimizeBox = false, MaximizeBox = false, ClientSize = new Size(320, 180)
        };
        sinBorde.Show(); Application.DoEvents();
        foreach (bool oscuro in new[] { false, true })
        {
            CambiarTema(oscuro);
            exige(!incrustada.TopLevel && !incrustada.ControlBox && !incrustada.MinimizeBox && !incrustada.MaximizeBox &&
                incrustada.FormBorderStyle == FormBorderStyle.FixedSingle &&
                sinBorde.FormBorderStyle == FormBorderStyle.None && !sinBorde.ControlBox &&
                !sinBorde.MinimizeBox && !sinBorde.MaximizeBox,
                "La adaptación de títulos no debe crear botones ni bordes en formularios incrustados o sin marco.");
        }
        sinBorde.Close(); propietario.Close();
    }

    private static void VerificarEditor(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Cabecera del proyecto", "ESTRUCTURAS");
        var primero = proyecto.Presupuestos.Single();
        var segundo = MYGEstructuraPresupuestos.AgregarPresupuesto(proyecto); segundo.Nombre = "ARQUITECTURA";
        proyecto.PresupuestoActivoId = primero.Id;
        MYGProyectoStorage.Validar(proyecto);
        string firma = MYGProyectoStorage.Firma(proyecto);
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion, firma);
        editor.WindowState = FormWindowState.Normal; editor.ClientSize = new Size(1600, 900);
        editor.Show(); Application.DoEvents();
        var panel = Campo<MYGPanelPresupuesto>(editor, "panelPresupuesto");
        var presupuesto = Campo<ComboBox>(editor, "presupuesto");
        var cabecera = editor.Controls.Find("cabecera_proyecto", true).Single();
        var pestanas = Campo<TabControl>(editor, "espacioPresupuestos");
        var cinta = Campo<FlowLayoutPanel>(editor, "cintaPresupuestos");
        var cintaCronograma = Campo<FlowLayoutPanel>(editor, "cintaCronograma");
        var modos = editor.Controls.Find("selector_vistas_proyecto", true).Single();
        var marcoCinta = editor.Controls.Find("cabecera_vistas_proyecto", true).Single();
        exige(!Descendientes(cabecera).Contains(presupuesto) && !Descendientes(cabecera).OfType<ComboBox>().Any() &&
            !Descendientes(cabecera).OfType<Label>().Any(l => l.Text == "Presupuesto:") && !presupuesto.Visible,
            "La cabecera principal debe retirar la etiqueta y el desplegable de presupuesto señalados en la imagen.");
        exige(Descendientes(cabecera).OfType<Label>().Any(l => l.Text == proyecto.Nombre && l.Visible),
            "La cabecera debe conservar el nombre visible del proyecto.");
        foreach (bool oscuro in new[] { false, true, false })
        {
            CambiarTema(oscuro);
            exige(new[] { (Control)cinta, marcoCinta, modos }.All(c => c.BackColor == MYG2027_TemaComercial.Fondo),
                "Toda la franja superior, incluidos R y CPM, debe adoptar el fondo del tema normal u oscuro.");
            exige(Descendientes(marcoCinta).OfType<Button>().Where(b => b.Visible && b.Enabled)
                .All(b => b.ForeColor == MYG2027_TemaComercial.Texto &&
                    (SystemInformation.HighContrast || DisenoProfesionalCheck.Contraste(b.ForeColor, b.BackColor) >= 4.5)),
                "El texto de las herramientas debe mantener el contraste de la paleta en ambos temas.");
            ((Button)editor.Controls.Find("vista_cronograma_button", true).Single()).PerformClick();
            Application.DoEvents();
            exige(cintaCronograma.Visible && cintaCronograma.BackColor == MYG2027_TemaComercial.Fondo &&
                Descendientes(cintaCronograma).OfType<Button>().Where(b => b.Visible && b.Enabled)
                    .All(b => b.ForeColor == MYG2027_TemaComercial.Texto &&
                        (SystemInformation.HighContrast || DisenoProfesionalCheck.Contraste(b.ForeColor, b.BackColor) >= 4.5)),
                "Cambiar a CPM debe conservar el fondo del tema y el contraste de sus herramientas.");
            ((Button)editor.Controls.Find("vista_presupuesto_button", true).Single()).PerformClick();
            Application.DoEvents();
            foreach (var seleccionado in new[] { segundo, primero })
            {
                panel.SeleccionarEstructura(seleccionado); Application.DoEvents();
                exige(proyecto.PresupuestoActivoId == seleccionado.Id && ReferenceEquals(presupuesto.SelectedItem, seleccionado) &&
                    ReferenceEquals(typeof(EditorForm).GetProperty("P", Privados).GetValue(editor), seleccionado),
                    "Elegir un presupuesto desde la estructura debe activar el modelo y conservar sincronizada la selección interna.");
                VerificarMenuActivo(editor, cinta, exige);
            }
        }
        exige(pestanas.TabPages.Count == 1 && pestanas is MYGEspacioProyecto,
            "El presupuesto debe ser el único espacio principal, sin la antigua pestaña de configuración BIM.");
        exige(Campo<Panel>(editor, "selector").Contains(presupuesto) && !Descendientes(cabecera).Contains(presupuesto),
            "El selector anterior debe conservarse en las herramientas avanzadas y mantenerse fuera de la cabecera principal.");
        Exception errorHerramientas = null;
        editor.BeginInvoke(new Action(() =>
        {
            var ventana = Campo<Form>(editor, "ventanaHerramientasBim");
            try
            {
                exige(ventana.Visible && presupuesto.Visible &&
                    ReferenceEquals(Campo<Control>(editor, "raiz").Parent, ventana),
                    "La configuración anterior debe abrirse solo dentro del diálogo de herramientas avanzadas.");
                presupuesto.SelectedItem = segundo; Application.DoEvents();
                exige(proyecto.PresupuestoActivoId == segundo.Id,
                    "El selector de las herramientas debe seguir cambiando el presupuesto activo.");
            }
            catch (Exception error) { errorHerramientas = error; }
            finally { ventana.Close(); }
        }));
        typeof(EditorForm).GetMethod("AbrirHerramientasBimAvanzadas", Privados).Invoke(editor, null);
        if (errorHerramientas != null) throw errorHerramientas;
        exige(Campo<Control>(editor, "raiz").Parent == null &&
            !Campo<Control>(editor, "raiz").Visible && !panel.IsDisposed,
            "Cerrar las herramientas debe devolver el presupuesto sin destruir los controles internos ni reabrir pestañas.");
        Application.DoEvents();
        exige(!presupuesto.Visible && MYGProyectoStorage.Firma(proyecto) == firma &&
            Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "undo").Count == 0 &&
            Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "redo").Count == 0,
            "Navegar por la estructura, BIM y los temas debe conservar los datos sin historial ni reaparecer el selector en la cabecera.");
        editor.Close();
    }

    private static void VerificarMenuActivo(EditorForm editor, FlowLayoutPanel cinta, Action<bool, string> exige)
    {
        var componentes = Campo<Container>(editor, "componentesMenus");
        var anteriores = componentes.Components.OfType<ContextMenuStrip>().ToArray();
        var boton = cinta.Controls.OfType<Button>().Single(b => b.Name == "exportar_proyecto_button");
        // Abrir el menú real sin iniciar sesión ni ejecutar una exportación.
        typeof(EditorForm).GetMethod("MenuExportarProyecto", Privados).Invoke(editor, new object[] { boton });
        Application.DoEvents();
        var menu = componentes.Components.OfType<ContextMenuStrip>().Except(anteriores).Single();
        exige(menu.Visible && menu.Items["exportar_presupuesto_activo"].Enabled,
            "Tras elegir un presupuesto en la estructura, sus comandos de exportación deben conservar un presupuesto activo.");
        menu.Close(); Application.DoEvents();
    }

    private static void VerificarColoresTitulo(Form ventana, Action<bool, string> exige)
    {
        if (SystemInformation.HighContrast) return;
        try
        {
            // Los atributos de color sólo están disponibles en versiones
            // recientes de Windows. Si DWM los admite, comprobar su valor real.
            if (DwmGetWindowAttribute(ventana.Handle, 35, out int fondo, sizeof(int)) == 0)
                exige(fondo == ColorRef(MYG2027_TemaComercial.Fondo),
                    "La barra nativa del título debe usar el mismo fondo que el tema activo.");
            if (DwmGetWindowAttribute(ventana.Handle, 36, out int texto, sizeof(int)) == 0)
                exige(texto == ColorRef(MYG2027_TemaComercial.Texto),
                    "Los textos y botones nativos del título deben adoptar el color legible del tema activo.");
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException) { }
    }

    private static int ColorRef(Color color) => color.R | (color.G << 8) | (color.B << 16);

    private static void CambiarTema(bool oscuro)
    {
        if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
        Application.DoEvents();
    }

    private static void Comando(Form ventana, int comando)
    {
        Enviar(ventana.Handle, WmSysCommand, new IntPtr(comando), IntPtr.Zero);
        Application.DoEvents();
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static void PulsarDialogo(Form ventana, Keys tecla) =>
        typeof(Form).GetMethod("ProcessDialogKey", Privados).Invoke(ventana, new object[] { tecla });

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }

}
