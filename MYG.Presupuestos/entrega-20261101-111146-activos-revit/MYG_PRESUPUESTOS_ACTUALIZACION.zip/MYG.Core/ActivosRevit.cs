using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public enum MYGOrigenActivoRevit { Local, Autodesk }

public sealed class MYGActivoRevit
{
    public string Id { get; set; } = MYGProyectoStorage.NuevoId();
    public string Nombre { get; set; }
    public MYGOrigenActivoRevit Origen { get; set; }
    public string RutaLocal { get; set; }
    public string ProyectoAutodeskId { get; set; }
    public string ModeloAutodeskId { get; set; }
    // Se completa al identificar un documento mediante el conector. El registro
    // manual de una ubicación no acredita acceso ni una conexión con Autodesk.
    public string DocumentoRevitId { get; set; }
}

public sealed class MYGAsignacionActivoRevit
{
    public string PresupuestoId { get; set; }
    public string PartidaId { get; set; }
    public string ActivoId { get; set; }
    public bool IncluirEnTotal { get; set; } = true;
}

public sealed class MYGConfiguracionActivosRevit
{
    public List<MYGActivoRevit> Activos { get; set; } = new();
    public List<MYGAsignacionActivoRevit> Asignaciones { get; set; } = new();
}

/// <summary>Registro propio de cada obra. No inicia conexiones ni modifica RVT.</summary>
public static class MYGActivosRevit
{
    private static bool Igual(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    private static string Texto(string valor) => string.IsNullOrWhiteSpace(valor) ? null : valor.Trim();
    private static string Ruta(string valor) => Texto(valor)?.Replace('\\', '/').TrimEnd('/');

    public static void Validar(MYGProyectoDocumento proyecto)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        var registro = proyecto.ActivosRevit;
        if (registro == null) return;
        if (registro.Activos == null || registro.Asignaciones == null)
            throw new InvalidDataException("El registro de activos Revit está incompleto.");
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var nombres = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var rutas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var modelos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var documentos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var activo in registro.Activos)
        {
            if (activo == null || string.IsNullOrWhiteSpace(activo.Id) || !ids.Add(activo.Id) ||
                string.IsNullOrWhiteSpace(activo.Nombre) || !nombres.Add(activo.Nombre.Trim()))
                throw new InvalidDataException("Cada activo necesita un identificador y un nombre únicos.");
            if (!Enum.IsDefined(activo.Origen)) throw new InvalidDataException("El origen del activo Revit no es válido.");
            if (activo.Origen == MYGOrigenActivoRevit.Local)
            {
                string ruta = Ruta(activo.RutaLocal);
                if (ruta == null || !ruta.EndsWith(".rvt", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("El activo local necesita la ruta de un archivo RVT.");
                if (!rutas.Add(ruta)) throw new InvalidDataException("Ese archivo RVT ya está registrado en otro activo.");
                if (!string.IsNullOrWhiteSpace(activo.ProyectoAutodeskId) || !string.IsNullOrWhiteSpace(activo.ModeloAutodeskId))
                    throw new InvalidDataException("El activo local no debe contener identificadores de nube Autodesk.");
            }
            else
            {
                if (string.IsNullOrWhiteSpace(activo.ProyectoAutodeskId) || string.IsNullOrWhiteSpace(activo.ModeloAutodeskId))
                    throw new InvalidDataException("El activo Autodesk necesita los identificadores de proyecto y modelo.");
                string clave = activo.ProyectoAutodeskId.Trim().Length + ":" + activo.ProyectoAutodeskId.Trim() + activo.ModeloAutodeskId.Trim();
                if (!modelos.Add(clave)) throw new InvalidDataException("Ese modelo Autodesk ya está registrado en otro activo.");
                if (!string.IsNullOrWhiteSpace(activo.RutaLocal))
                    throw new InvalidDataException("El modelo Autodesk no se identifica mediante una ruta de caché local.");
            }
            if (!string.IsNullOrWhiteSpace(activo.DocumentoRevitId) && !documentos.Add(activo.DocumentoRevitId.Trim()))
                throw new InvalidDataException("El documento Revit ya está vinculado con otro activo.");
        }
        var asignaciones = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var asignacion in registro.Asignaciones)
        {
            if (asignacion == null || !ids.Contains(asignacion.ActivoId ?? ""))
                throw new InvalidDataException("Una asignación hace referencia a un activo inexistente.");
            var partida = Partida(proyecto, asignacion.PresupuestoId, asignacion.PartidaId);
            if (!asignaciones.Add(asignacion.PresupuestoId + "\0" + partida.Id + "\0" + asignacion.ActivoId))
                throw new InvalidDataException("El activo ya está asignado a esa partida.");
        }
    }

    private static ItemPresupuestoDelphin Partida(MYGProyectoDocumento proyecto, string presupuestoId, string partidaId)
    {
        var presupuesto = proyecto.Presupuestos?.FirstOrDefault(p => Igual(p.Id, presupuestoId));
        var partida = presupuesto?.Items?.FirstOrDefault(i => Igual(i.Id, partidaId));
        if (partida == null || MYGProyectoStorage.EsTitulo(partida))
            throw new InvalidDataException("La asignación necesita una partida existente del presupuesto seleccionado.");
        return partida;
    }

    public static MYGActivoRevit GuardarActivo(MYGProyectoDocumento proyecto, MYGActivoRevit activo)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(activo);
        var candidato = MYGProyectoStorage.Copia(proyecto);
        candidato.ActivosRevit ??= new();
        var copia = MYGProyectoStorage.Copia(activo);
        if (string.IsNullOrWhiteSpace(copia.Id)) copia.Id = MYGProyectoStorage.NuevoId();
        copia.Nombre = Texto(copia.Nombre); copia.RutaLocal = Texto(copia.RutaLocal);
        copia.ProyectoAutodeskId = Texto(copia.ProyectoAutodeskId); copia.ModeloAutodeskId = Texto(copia.ModeloAutodeskId);
        copia.DocumentoRevitId = Texto(copia.DocumentoRevitId);
        int indice = candidato.ActivosRevit.Activos.FindIndex(a => Igual(a.Id, copia.Id));
        if (indice >= 0) candidato.ActivosRevit.Activos[indice] = copia;
        else candidato.ActivosRevit.Activos.Add(copia);
        Validar(candidato);
        proyecto.ActivosRevit = candidato.ActivosRevit;
        return copia;
    }

    public static MYGAsignacionActivoRevit Asignar(MYGProyectoDocumento proyecto, string presupuestoId, string partidaId, string activoId)
    {
        Validar(proyecto);
        Partida(proyecto, presupuestoId, partidaId);
        var registro = proyecto.ActivosRevit;
        if (registro?.Activos.Any(a => Igual(a.Id, activoId)) != true)
            throw new InvalidDataException("Registre el activo en la obra antes de asignarlo.");
        var existente = registro.Asignaciones.FirstOrDefault(a => Igual(a.PresupuestoId, presupuestoId) && Igual(a.PartidaId, partidaId) && Igual(a.ActivoId, activoId));
        if (existente != null) return existente;
        var asignacion = new MYGAsignacionActivoRevit { PresupuestoId = presupuestoId, PartidaId = partidaId, ActivoId = activoId };
        registro.Asignaciones.Add(asignacion);
        return asignacion;
    }

    public static void QuitarAsignacion(MYGProyectoDocumento proyecto, string presupuestoId, string partidaId, string activoId)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        proyecto.ActivosRevit?.Asignaciones.RemoveAll(a => Igual(a.PresupuestoId, presupuestoId) && Igual(a.PartidaId, partidaId) && Igual(a.ActivoId, activoId));
    }

    public static void CambiarInclusion(MYGProyectoDocumento proyecto, string presupuestoId, string partidaId, string activoId, bool incluir)
    {
        Validar(proyecto);
        var partida = Partida(proyecto, presupuestoId, partidaId);
        var asignacion = proyecto.ActivosRevit?.Asignaciones.FirstOrDefault(a => Igual(a.PresupuestoId, presupuestoId) && Igual(a.PartidaId, partidaId) && Igual(a.ActivoId, activoId));
        if (asignacion == null) throw new InvalidDataException("El activo no está asignado a esa partida.");
        asignacion.IncluirEnTotal = incluir;
        foreach (var resultado in partida.Costos.MetradosBIM.Where(m => Igual(m.ActivoId, activoId)))
            resultado.ExcluirDelTotal = !incluir;
    }

    public static void EliminarActivo(MYGProyectoDocumento proyecto, string activoId)
    {
        Validar(proyecto);
        if (proyecto.ActivosRevit?.Asignaciones.Any(a => Igual(a.ActivoId, activoId)) == true)
            throw new InvalidDataException("Quite las asignaciones del activo antes de eliminarlo de la obra.");
        if (proyecto.Presupuestos.Any(p => p.Items.Any(i => i.Costos.MetradosBIM.Any(m => Igual(m.ActivoId, activoId)))))
            throw new InvalidDataException("El activo conserva metrados recibidos. Retírelos antes de eliminarlo.");
        proyecto.ActivosRevit?.Activos.RemoveAll(a => Igual(a.Id, activoId));
    }

    // Las operaciones que eliminan partidas o presupuestos deben llamar a este
    // método después de su confirmación, dentro de la misma entrada de historial.
    public static void LimpiarAsignacionesHuerfanas(MYGProyectoDocumento proyecto)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        proyecto.ActivosRevit?.Asignaciones.RemoveAll(a =>
            proyecto.Presupuestos?.Any(p => Igual(p.Id, a.PresupuestoId) &&
                p.Items?.Any(i => Igual(i.Id, a.PartidaId) && !MYGProyectoStorage.EsTitulo(i)) == true) != true);
    }
}
