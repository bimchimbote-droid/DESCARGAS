# Entrega: presupuesto único y activos Revit

Base comprobada de `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`:
`dd0e51c9bb217e75565c0d1e98e89ef0b97300b2`.

Esta actualización incluye la interfaz Metrados Revit entregada anteriormente;
no es necesario aplicar primero el ZIP anterior. Los archivos existentes se
entregan completos para reemplazar, y los nuevos se copian en sus rutas relativas.
Si su proyecto tiene modificaciones posteriores, compare antes de reemplazar.

## Qué cambia

- El presupuesto es el único espacio principal, sin las dos pestañas inferiores
  Presupuesto / Configuración BIM-Revit. Se conserva el selector R/CPM.
- Activos de la obra registra en una misma lista modelos RVT locales y modelos
  Autodesk. El origen no representa por sí mismo el estado de colaboración.
- Cada activo tiene un identificador MYG estable. Los archivos locales se
  registran por ruta; Autodesk por identificadores de proyecto y modelo. Los
  nombres y las ubicaciones editables no sustituyen la identidad del activo.
- En Metrados Revit cada partida conserva su plantilla y hasta cinco filtros,
  y puede asignarse a varios activos de la obra. El mismo activo puede asignarse
  a otras partidas. Las asignaciones pertenecen a la obra y presupuesto concretos.
- Las pestañas internas Activos asignados y Metrados recibidos distinguen la
  selección de modelos de las cantidades ya importadas. Registrar o asignar un
  activo no crea una cantidad ni genera tablas.
- Usar en total excluye o incluye resultados BIM sin borrarlos. Solo influye en
  la cantidad de la partida cuando su origen del metrado es BIM. La exclusión se
  conserva al reimportar un snapshot del mismo activo y partida.
- Las relaciones con resultados se identifican por ID; los resultados antiguos
  no se vinculan automáticamente por nombre o ruta a un nuevo activo.
- El registro y las asignaciones se conservan al guardar/abrir JSON y SQLite.
  No se requieren paquetes, referencias ni migraciones SQL nuevas.
- Herramientas BIM conserva las utilidades anteriores de biblioteca, filtros
  en lote y modelo abierto en Revit, dentro de un diálogo avanzado. Las
  configuraciones anteriores de más de cinco filtros se conservan allí.

## Alcance de Autodesk y Revit

El registro Autodesk es manual y queda pendiente de verificar. Esta entrega no
implementa inicio de sesión Autodesk, consulta de proyectos, sincronización de
modelos, detección automática de documentos cloud ni generación de tablas para
las nuevas asignaciones. No modifica archivos RVT. Las funciones anteriores del
conector permanecen como herramientas del modelo abierto y no se convierten en
automatización cloud por registrar activos.

Para registrar un modelo Autodesk se necesitan sus identificadores de proyecto
y modelo; no escriba tokens, contraseñas ni rutas de caché. La integración futura
comprobará esos datos y los permisos. Los modelos conceptuales nativos de Forma
no se convierten mediante este registro en documentos Revit.

Cambiar la referencia de un activo conserva su identidad y asignaciones. Si ya
tiene metrados recibidos se muestra una advertencia: esos resultados siguen
siendo históricos y no acreditan el contenido del nuevo modelo. Para otro
bloque/modelo independiente, cree otro activo. Revise siempre las fechas e
inclusiones antes de utilizar cantidades antiguas.

## Instalación manual

1. Cierre MYG y respalde la carpeta y las bases de datos de la obra. Confirme o
   guarde también los cambios locales de código en Visual Studio.
2. Extraiga el ZIP y copie su contenido sobre la raíz del proyecto manteniendo
   las carpetas MYG.Core, MYG.Desktop, MYG.Pruebas y MYG.PruebasUI.
3. No hay archivos que eliminar ni parches adicionales que aplicar.
4. Restaure y compile con los comandos siguientes. Ejecute las pruebas y revise
   la interfaz en Windows antes de usar la actualización con una obra real.
5. En Visual Studio, abra Cambios de Git, revise la lista de archivos, haga
   Commit y luego Push a su rama main. Compruebe el commit en GitHub.

Publicar este ZIP en DESCARGAS no aplica la actualización en su equipo y no
publica cambios en el repositorio del código.

## Compilación y comprobaciones

Tecnologías: C#, SDK .NET 10.0.100, WinForms/WPF y Microsoft.Data.Sqlite 10.0.0.
Use la versión compatible con global.json. Desde la raíz:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --activos-revit
```

Resultados en Linux: compilación completa con cero errores y cero advertencias;
suite principal con 783 comprobaciones correctas, incluidos ocho grupos nuevos
de activos. Las comprobaciones con muestras privadas y Named Pipes de Windows
siguen omitidas explícitamente cuando no están disponibles. Se comprobaron JSON
y SQLite reales, aislamiento entre obras, referencias, duplicados, conservación
de identidad, exclusión y reimportación de metrados.

Pruebas de interfaz compiladas; ejecutar en Windows con .NET Desktop 10:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --activos-revit
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Las pruebas de interfaz no se ejecutaron en Linux porque requieren
Microsoft.WindowsDesktop.App. La interfaz real, el conector Revit y Autodesk
quedan pendientes de prueba en Windows y con modelos autorizados. La suite
MYG.PruebasNube no se repitió para esta entrega; se mantiene como antecedente su
fallo previo en PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar,
independiente del registro de activos.

## Revisión manual recomendada

1. Abra una copia de la obra y compruebe la vista única y los modos R/CPM.
2. Registre un activo local y otro Autodesk; cancele primero y verifique que
   no se aplicó nada. Repita y pulse Aplicar a la obra.
3. Seleccione una partida, asigne uno o ambos activos y cambie de partida.
   Compruebe que cada partida mantiene su plantilla, filtros y asignaciones.
4. Guarde y reabra la obra; confirme los registros y asignaciones.
5. Con resultados BIM existentes, cambie Usar en total y compruebe el total,
   deshaga y rehaga. La cantidad original del resultado debe conservarse.
6. Compruebe Biblioteca y configuración BIM en lote desde Herramientas BIM.

No se transfieren el registro ni las asignaciones de la obra al copiar una
plantilla de presupuesto. La conducta anterior de copiar datos de partidas,
incluidos metrados BIM históricos, se conserva: revíselos al reutilizar un
presupuesto en otra obra.
