using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly TextBox plantillaMetradoRevit = new() { Name = "plantilla_metrados_revit", Dock = DockStyle.Fill,
        PlaceholderText = "Nombre de la plantilla de Revit" };
    private readonly DataGridView filtrosMetradoRevit = Tabla();
    private readonly Label contextoMetradoRevit = new() { Dock = DockStyle.Fill, AutoEllipsis = true,
        TextAlign = ContentAlignment.MiddleLeft };
    private bool cargandoMetradosRevit;
    private string partidaConfiguracionRevit;
    internal Action CambioConfiguracionMetradosRevit;

    private TableLayoutPanel PrepararConfiguracionMetradosRevit()
    {
        var contenido = new TableLayoutPanel { Name = "metrados_revit", Dock = DockStyle.Fill,
            ColumnCount = 1, RowCount = 3, Padding = new Padding(6) };
        contenido.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
        contenido.RowStyles.Add(new RowStyle(SizeType.Absolute, 184));
        contenido.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var cabecera = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3 };
        cabecera.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 85));
        cabecera.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        cabecera.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        cabecera.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        cabecera.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        cabecera.Controls.Add(contextoMetradoRevit, 0, 0); cabecera.SetColumnSpan(contextoMetradoRevit, 2);
        cabecera.Controls.Add(Etiqueta("Plantilla"), 0, 1); cabecera.Controls.Add(plantillaMetradoRevit, 1, 1);
        var ayuda = new Label { Dock = DockStyle.Fill, Text = "Una plantilla por partida · Hasta 5 filtros · Edición local, sin consulta a Revit", AutoEllipsis = true };
        cabecera.Controls.Add(ayuda, 0, 2); cabecera.SetColumnSpan(ayuda, 2);
        contenido.Controls.Add(cabecera, 0, 0);
        filtrosMetradoRevit.Name = "filtros_metrados_revit";
        filtrosMetradoRevit.ReadOnly = false;
        filtrosMetradoRevit.AllowUserToAddRows = false;
        filtrosMetradoRevit.AllowUserToDeleteRows = false;
        filtrosMetradoRevit.RowTemplate.Height = 28;
        Columna(filtrosMetradoRevit, "FILTRO", "Filtro", 75);
        Columna(filtrosMetradoRevit, "PARAMETRO", "Parámetro", 160, true);
        Columna(filtrosMetradoRevit, "REGLA", "Regla", 140, true);
        Columna(filtrosMetradoRevit, "VALOR", "Valor", 180, true);
        foreach (string nombre in new[] { "PARAMETRO", "REGLA", "VALOR" })
        { filtrosMetradoRevit.Columns[nombre].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
          filtrosMetradoRevit.Columns[nombre].MinimumWidth = 100; }
        filtrosMetradoRevit.CellEndEdit += (_, _) => Intentar(GuardarConfiguracionMetradosRevit);
        plantillaMetradoRevit.Validated += (_, _) => Intentar(GuardarConfiguracionMetradosRevit);
        contenido.Controls.Add(filtrosMetradoRevit, 0, 1);
        return contenido;
    }

    private void CargarConfiguracionMetradosRevit()
    {
        if (cargandoMetradosRevit) return;
        cargandoMetradosRevit = true;
        try
        {
            var partida = HayPartida ? PartidaActual : null;
            partidaConfiguracionRevit = partida?.Id;
            var filtros = partida == null ? new System.Collections.Generic.List<FiltroPlanificacion>()
                : MYGBibliotecaPartidas.FiltrosGuardables(partida);
            bool legado = filtros.Count > 5;
            contextoMetradoRevit.Text = partida == null ? "Seleccione una partida para configurar sus metrados Revit."
                : $"{partida.Item} · {partida.Descripcion} · {partida.Unidad}";
            plantillaMetradoRevit.Text = partida?.Plantilla ?? "";
            plantillaMetradoRevit.ReadOnly = partida == null || legado || !EdicionNubePermitida;
            filtrosMetradoRevit.ReadOnly = plantillaMetradoRevit.ReadOnly;
            filtrosMetradoRevit.Rows.Clear();
            for (int n = 0; n < Math.Max(5, filtros.Count); n++)
            {
                var filtro = n < filtros.Count ? filtros[n] : new FiltroPlanificacion();
                filtrosMetradoRevit.Rows.Add($"Filtro {n + 1:00}", filtro.Parametro ?? "", filtro.Regla ?? "", filtro.Valor ?? "");
            }
            if (legado) contextoMetradoRevit.Text += " · Configuración anterior con más de 5 filtros: consulta; editar desde Herramientas BIM avanzadas.";
            CargarAsignacionesRevit();
        }
        finally { cargandoMetradosRevit = false; }
    }

    private void FinalizarMetradosRevit()
    {
        if (cargandoMetradosRevit) return;
        if (!filtrosMetradoRevit.EndEdit()) throw new InvalidOperationException("Complete la edición del filtro Revit.");
        GuardarConfiguracionMetradosRevit();
    }

    private void GuardarConfiguracionMetradosRevit()
    {
        if (cargandoMetradosRevit || partidaConfiguracionRevit == null || plantillaMetradoRevit.ReadOnly) return;
        var partida = P?.Items.FirstOrDefault(i => i.Id == partidaConfiguracionRevit);
        if (partida == null) return;
        var filtros = filtrosMetradoRevit.Rows.Cast<DataGridViewRow>().Select(r => new FiltroPlanificacion
        {
            Parametro = r.Cells["PARAMETRO"].Value?.ToString() ?? "",
            Regla = r.Cells["REGLA"].Value?.ToString() ?? "",
            Valor = r.Cells["VALOR"].Value?.ToString() ?? ""
        }).ToList();
        // Conservar las posiciones de los filtros durante una edición parcial.
        while (filtros.Count > 0 && filtros[^1].EstaVacio()) filtros.RemoveAt(filtros.Count - 1);
        string plantilla = plantillaMetradoRevit.Text;
        var anteriores = MYGBibliotecaPartidas.FiltrosGuardables(partida);
        if ((partida.Plantilla ?? "") == plantilla && anteriores.Count == filtros.Count &&
            anteriores.Zip(filtros).All(x => (x.First.Parametro ?? "") == x.Second.Parametro &&
                (x.First.Regla ?? "") == x.Second.Regla && (x.First.Valor ?? "") == x.Second.Valor)) return;
        if (!EdicionNubePermitida) throw new InvalidOperationException("El proyecto está disponible solo para lectura.");
        RequerirPermisoCatalogos();
        antes();
        partida.Plantilla = plantilla;
        partida.Filtros = filtros;
        var primero = filtros.FirstOrDefault();
        partida.Parametro = primero?.Parametro; partida.Regla = primero?.Regla; partida.Valor = primero?.Valor;
        partida.EstadoRevit = null; partida.MensajeRevit = null;
        P.CantidadFiltros = Math.Max(P.CantidadFiltros, Math.Max(1, filtros.Count));
        // El editor general comparte el modelo: renovar sus celdas evita que
        // Sincronizar restaure valores antiguos al guardar el proyecto.
        cargandoMetradosRevit = true;
        try { CambioConfiguracionMetradosRevit?.Invoke(); Cambiado(); }
        finally { cargandoMetradosRevit = false; }
    }
}
