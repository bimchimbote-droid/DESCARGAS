using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto : UserControl
{
    internal static Color AzulClaro => MYG2027_TemaComercial.AzulSuave;
    private readonly Func<MYGPresupuestoDocumento> obtener;
    private readonly Action antes, despues;
    private readonly Action guardarProyecto, deshacerProyecto, rehacerProyecto;
    private readonly Action<string> seleccionar;
    private readonly Func<Task> consultarBIM;
    private readonly Action<string> importarBIM;
    private readonly DataGridView estructura = Tabla(), acu = Tabla(), bim = Tabla(), consolidado = Tabla(), insumos = Tabla(), listaCostos = Tabla();
    private readonly DataGridView hoja = Tabla();
    private readonly TabControl detalle = new() { Dock = DockStyle.Fill, Alignment = TabAlignment.Bottom };
    private readonly Panel vistas = new() { Name = "presupuesto_vistas", Dock = DockStyle.Fill };
    private readonly Panel principal = new() { Name = "presupuesto_vista_principal", Dock = DockStyle.Fill };
    private readonly Panel paginaInsumos = new() { Name = "presupuesto_vista_catalogo_insumos", Dock = DockStyle.Fill, Visible = false };
    private readonly Panel paginaCostos = new() { Name = "presupuesto_vista_costos", Dock = DockStyle.Fill, Visible = false };
    private Panel vistaSeleccionada;
    private SplitContainer divisionPresupuesto;
    private readonly Label pie = new() { Dock = DockStyle.Bottom, Height = 28, TextAlign = ContentAlignment.MiddleRight, Padding = new(5), BackColor = AzulClaro };
    private readonly RichTextBox especificacion = new MYGEspecificacionesRichTextBox() { Dock = DockStyle.Fill, BackColor = Color.White, AcceptsTab = true, DetectUrls = false, HideSelection = false };
    private MYGEspecificacionesEditor editorEspecificaciones;
    private MYGEspecificacionesCabecera cabeceraACU;
    private readonly ComboBox fuente = new() { Width = 110, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly NumericUpDown precioDirecto = Numero(), rendimiento = Numero(), jornada = Numero();
    private readonly TextBox buscar = new() { Dock = DockStyle.Top, PlaceholderText = "Buscar partida, código o unidad…", Height = 28 };
    private readonly MYGEditorTextoFormulaHoja formula = new() { Width = 420 };
    private readonly TextBox direccion = new() { Width = 65, ReadOnly = true }, celdaTotal = new() { Width = 65, Text = "G16" };
    private readonly HashSet<string> contraidos = new(StringComparer.OrdinalIgnoreCase);
    private readonly Font negrita = new("Segoe UI", 9, FontStyle.Bold), cursiva = new("Segoe UI", 9, FontStyle.Italic);
    private ItemPresupuestoDelphin actual;
    private bool cargando, finalizandoEdicion, actualizandoCalculos, confirmandoEdicionACU;
    private MYGRefrescoDiferido refrescoDiferidoACU;
    private bool consolidadoPendiente = true, listaCostosPendiente = true, hojaPendiente = true;
    private string contenidoAntes;
    private MYGPresupuestoDocumento P => obtener();
    // Las transacciones y el historial pueden sustituir las instancias del
    // modelo conservando sus Id. El detalle siempre debe leer la partida vigente.
    private ItemPresupuestoDelphin PartidaActual => actual == null ? null : P?.Items.FirstOrDefault(i => i.Id == actual.Id);
    internal bool EditandoTexto => especificacion.ContainsFocus || editorEspecificaciones?.ContainsFocus == true || formula.ContainsFocus || buscar.ContainsFocus ||
        direccion.ContainsFocus || estructura.IsCurrentCellInEditMode || tablaPie.IsCurrentCellInEditMode || hoja.IsCurrentCellInEditMode || acu.IsCurrentCellInEditMode ||
        fuente.ContainsFocus || rendimiento.ContainsFocus || jornada.ContainsFocus || precioDirecto.ContainsFocus || plantillaMetradoRevit.ContainsFocus || filtrosMetradoRevit.IsCurrentCellInEditMode || tablaInsumosContexto?.IsCurrentCellInEditMode == true;
    internal void FinalizarEdicion()
    {
        if (navegandoReferenciaPartidaHoja || restaurandoReferenciaPartidaHoja || preparandoBotonReferenciaPartidaHoja) return;
        if (EligiendoReferenciaPartidaHoja)
            throw new InvalidOperationException("Seleccione la celda de origen o pulse Cancelar (Esc) antes de continuar.");
        if (cargando || finalizandoEdicion) return;
        finalizandoEdicion = true;
        try
        {
            CerrarSelectorUnidadEstructura();
            ConfirmarValorEstructuraEnEdicion();
            if (!estructura.EndEdit() || !tablaPie.EndEdit() || !acu.EndEdit() || !hoja.EndEdit() ||
                tablaInsumosContexto != null && !tablaInsumosContexto.EndEdit()) throw new InvalidOperationException("Corrija la celda que está editando antes de continuar.");
            FinalizarMetradosRevit();
            ConfirmarFormulaHoja();
        }
        finally
        {
            finalizandoEdicion = false;
            refrescoDiferidoEstructura?.Reintentar();
            refrescoDiferidoACU?.Reintentar();
        }
    }
    internal MYGPanelPresupuesto(Func<MYGPresupuestoDocumento> obtener, Action antes, Action despues,
        Action<string> seleccionar, Func<Task> consultarBIM, Action<string> importarBIM, Action guardarProyecto = null,
        Action deshacerProyecto = null, Action rehacerProyecto = null)
    {
        this.obtener = obtener; this.antes = antes; this.despues = despues; this.seleccionar = seleccionar;
        this.consultarBIM = consultarBIM; this.importarBIM = importarBIM;
        this.guardarProyecto = guardarProyecto;
        this.deshacerProyecto = deshacerProyecto; this.rehacerProyecto = rehacerProyecto;
        Dock = DockStyle.Fill; BackColor = AzulClaro; Margin = new(0);
        // La selección de títulos y presupuestos ya ofrece sus listas en el
        // detalle. Conservar las vistas internas sin una segunda barra inferior.
        vistas.Controls.AddRange(new Control[] { principal, paginaInsumos, paginaCostos });
        vistaSeleccionada = principal; Controls.Add(vistas);
        var split = divisionPresupuesto = new SplitContainer { Name = "divisionPresupuesto", Size = new(1400, 600), Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterWidth = 5, Panel1MinSize = 280, Panel2MinSize = 420, BackColor = MYG2027_TemaComercial.Borde };
        principal.Controls.Add(split);
        // La proporción se aplica después de que el contenedor tenga un tamaño válido.
        split.SizeChanged += (s, e) => { if (split.Width > 710 && !split.IsSplitterFixed && !Visible) split.SplitterDistance = split.Width / 2; };
        Load += (s, e) => { if (split.Width > 710) split.SplitterDistance = split.Width / 2; };
        var izquierdo = new SplitContainer
        {
            Size = new(700, 600),
            Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal,
            SplitterWidth = 5,
            SplitterDistance = 360,
            Panel1MinSize = 100,
            Panel2MinSize = 160,
            BackColor = AzulClaro
        };
        split.Panel1.Controls.Add(izquierdo);
        // La franja central abarca también el gráfico y el resumen, y sigue
        // accesible cuando se oculta el detalle de la derecha.
        split.Panel1.Controls.Add(PrepararHerramientasEstructura());
        izquierdo.Panel1.Controls.Add(estructura); izquierdo.Panel1.Controls.Add(PrepararBusqueda());
        izquierdo.Panel2.Controls.Add(PrepararPiePresupuesto());
        Load += (s, e) =>
        {
            int altoPie = (int)Math.Round(235F * DeviceDpi / 96F);
            if (izquierdo.Height > izquierdo.Panel1MinSize + izquierdo.Panel2MinSize + izquierdo.SplitterWidth)
                izquierdo.SplitterDistance = Math.Max(izquierdo.Panel1MinSize, izquierdo.Height - Math.Min(altoPie, izquierdo.Height - izquierdo.Panel1MinSize - izquierdo.SplitterWidth));
        };
        split.Panel2.Controls.Add(detalle); split.Panel2.Controls.Add(pie);
        split.Panel2.Controls.Add(PrepararInsumosContexto());
        Columna(estructura, "EXP", "", 28); estructura.Columns["EXP"].Visible = false;
        Columna(estructura, "ITEM", "Ítem", 150); Columna(estructura, "DESC", "Descripción", 280);
        Columna(estructura, "CANT", "Cantidad", 90, true);
        Columna(estructura, "UND", "Unidad", 68, true);
        Columna(estructura, "PU", "Precio", 100); Columna(estructura, "TOTAL", "Total", 120);
        estructura.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        estructura.Columns["DESC"].MinimumWidth = 170;
        MYG2027_TemaComercial.DesactivarFilasAlternas(estructura);
        PrepararEstructura();
        InicializarFormatoVistaEstructura();
        buscar.TextChanged += (s, e) => { if (!cargando) Refrescar(); };
        PrepararACU(); PrepararEspecificacion(); PrepararHoja(); PrepararBIM();
        var pConsolidado = Pagina("Σ Consol. de Partida"); pConsolidado.Controls.Add(consolidado);
        Columna(consolidado, "GRUPO", "Grupo", 120); Columna(consolidado, "COD", "Código", 95); Columna(consolidado, "DESC", "Descripción", 300);
        Columna(consolidado, "UND", "Und.", 55); Columna(consolidado, "CANT", "Cantidad", 95); Columna(consolidado, "PRECIO", "Precio", 95); Columna(consolidado, "TOTAL", "Total", 110);
        paginaInsumos.Controls.Add(insumos); paginaInsumos.Controls.Add(Barra(
            Boton("+ Insumo", NuevoInsumo), Boton("Editar insumo", EditarInsumo), Boton("Eliminar insumo", EliminarInsumo),
            Boton("Guardar insumo en catálogo", GuardarInsumoEnCatalogo), Boton("Catálogo de insumos", MostrarCatalogoInsumos), Boton("Exportar", ExportarPresupuesto)));
        Columna(insumos, "GRUPO", "Grupo", 140); Columna(insumos, "COD", "Código", 110); Columna(insumos, "DESC", "Descripción", 380); Columna(insumos, "UND", "Und.", 75); Columna(insumos, "PRECIO", "Precio", 110);
        insumos.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditarInsumo(); };
        paginaCostos.Controls.Add(listaCostos);
        foreach (DataGridViewColumn c in consolidado.Columns) listaCostos.Columns.Add((DataGridViewColumn)c.Clone());
        paginaCostos.Controls.Add(Barra(Boton("Exportar libro", ExportarPresupuesto), Boton("Resumen del presupuesto", Resumen)));
        detalle.SelectedIndexChanged += (s, e) => { ActualizarPresentacionEspecificaciones(); ActualizarHerramientasACU(); if (!cargando) Intentar(ActualizarVistasPendientes); };
        PrepararPestanasDetalle();
        AplicarTemaPresupuestos();
        DisposeFontsOnClose();
    }
    private void DisposeFontsOnClose() => Disposed += (s, e) => { negrita.Dispose(); cursiva.Dispose(); };
    private static NumericUpDown Numero() => new() { Width = 90, DecimalPlaces = 4, Maximum = 1000000000000m, Minimum = 0, ThousandsSeparator = true };
    private static DataGridView Tabla() => new MYG2027_TablaPresupuesto
    {
        Dock = DockStyle.Fill,
        AllowUserToAddRows = false,
        AllowUserToDeleteRows = false,
        AllowUserToOrderColumns = false,
        AutoGenerateColumns = false,
        ReadOnly = true,
        RowHeadersVisible = false,
        BackgroundColor = MYG2027_TemaComercial.Superficie,
        BorderStyle = BorderStyle.FixedSingle,
        EnableHeadersVisualStyles = false,
        ColumnHeadersHeight = 30,
        ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
        ColumnHeadersDefaultCellStyle = new() { BackColor = MYG2027_TemaComercial.CabeceraTabla, ForeColor = MYG2027_TemaComercial.TextoCabeceraTabla, SelectionBackColor = MYG2027_TemaComercial.CabeceraTabla, SelectionForeColor = MYG2027_TemaComercial.TextoCabeceraTabla, Font = new("Segoe UI", 9) },
        DefaultCellStyle = new() { BackColor = MYG2027_TemaComercial.Superficie, ForeColor = MYG2027_TemaComercial.Texto, SelectionBackColor = MYG2027_TemaComercial.Seleccion, SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion, Font = new("Segoe UI", 9) },
        GridColor = MYG2027_TemaComercial.Borde,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        MultiSelect = false,
        RowTemplate = { Height = 24 }
    };
    private static void Columna(DataGridView g, string nombre, string titulo, int ancho, bool editable = false)
    {
        g.Columns.Add(new DataGridViewTextBoxColumn { Name = nombre, HeaderText = titulo, Width = ancho, ReadOnly = !editable, SortMode = DataGridViewColumnSortMode.NotSortable });
        if (nombre is "CANT" or "PU" or "TOTAL" or "PRECIO" or "PARCIAL")
        {
            g.Columns[nombre].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            g.Columns[nombre].DefaultCellStyle.Format = nombre == "CANT" ? "N4" : "N2";
            g.Columns[nombre].DefaultCellStyle.FormatProvider = CultureInfo.InvariantCulture;
        }
    }
    private TabPage Pagina(string titulo)
    { var p = new TabPage(titulo) { Padding = new(0), BackColor = MYG2027_TemaComercial.Superficie }; detalle.TabPages.Add(p); return p; }
    private static FlowLayoutPanel Barra(params Control[] controles)
    {
        var b = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 38, Padding = new(4), WrapContents = false, AutoScroll = true, BackColor = MYG2027_TemaComercial.Superficie, Margin = new(0) };
        b.Controls.AddRange(controles); return b;
    }
    private Control PrepararBusqueda()
    {
        var barra = new Panel { Name = "presupuesto_busqueda", Dock = DockStyle.Top, Height = 40,
            Padding = new(12, 10, 12, 8), BackColor = MYG2027_TemaComercial.Superficie };
        buscar.BorderStyle = BorderStyle.None;
        buscar.AccessibleName = "Buscar partida, código o unidad";
        barra.Controls.Add(buscar);
        barra.Paint += (_, e) =>
        {
            using var borde = new Pen(MYG2027_TemaComercial.Borde);
            e.Graphics.DrawLine(borde, 0, barra.Height - 1, barra.Width, barra.Height - 1);
        };
        return barra;
    }
    private Button Boton(string texto, Action accion)
    {
        var b = new MYG2027_BotonComercial { Text = texto, AutoSize = true, Height = 28, FlatStyle = FlatStyle.Flat, BackColor = MYG2027_TemaComercial.Superficie, Margin = new(3, 0, 3, 0) };
        b.FlatAppearance.BorderColor = MYG2027_TemaComercial.Borde; b.ForeColor = MYG2027_TemaComercial.Texto; MYGAnimacionUI.PrepararBoton(b); b.Click += (s, e) => Intentar(accion); return b;
    }
    // Cambiar la paleta conserva la selección, las filas y cualquier edición en curso.
    internal void AplicarTemaPresupuestos()
    {
        BackColor = MYG2027_TemaComercial.Fondo;
        ForeColor = MYG2027_TemaComercial.Texto;
        pie.BackColor = MYG2027_TemaComercial.SuperficieAlterna;
        pie.ForeColor = MYG2027_TemaComercial.Texto;
        // El editor administra el fondo de pantalla y conserva los colores del RTF.
        editorEspecificaciones?.AplicarTema();
        cabeceraACU?.AplicarPaleta();
        AplicarTemaContextoACU();
        // No modificar SelectionColor: forma parte del documento RTF de la especificación.
        foreach (var tabla in new[] { estructura, acu, bim, filtrosMetradoRevit, asignacionesRevit, consolidado, insumos, listaCostos, hoja, tablaPie })
            AplicarTemaTablaPresupuesto(tabla);
        AplicarTemaEstructura();
        foreach (DataGridViewRow fila in acu.Rows)
            if (fila.Tag is MYGGrupoRecurso)
            {
                fila.DefaultCellStyle.BackColor = AzulClaro;
                fila.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
            }
        foreach (DataGridViewRow fila in tablaPie.Rows)
            if (string.Equals(Convert.ToString(fila.Cells["CONCEPTO"].Value), "Total", StringComparison.Ordinal))
                fila.DefaultCellStyle.BackColor = AzulClaro;
        AplicarTemaHoja();
        formula.AplicarTema();
        ActualizarColoresReferenciasHoja();
        AplicarTemaCintaHoja(); cabeceraExcel?.AplicarPaleta();
        AplicarTemaReferenciasPartidasHoja();
        graficoIncidencia.BackColor = MYG2027_TemaComercial.Superficie;
        graficoIncidencia.ForeColor = MYG2027_TemaComercial.Texto;
        graficoIncidencia.Invalidate();
        selectorUnidadEstructura?.AplicarTema();
        AplicarTemaHerramientas();
        AplicarTemaInsumosContexto();
        AplicarAspectoPermisosNube();
        Invalidate(true);
    }
    private static void AplicarTemaTablaPresupuesto(DataGridView tabla)
    {
        tabla.BackgroundColor = MYG2027_TemaComercial.Superficie;
        tabla.GridColor = MYG2027_TemaComercial.Borde;
        tabla.ColumnHeadersDefaultCellStyle.BackColor = MYG2027_TemaComercial.CabeceraTabla;
        tabla.ColumnHeadersDefaultCellStyle.ForeColor = MYG2027_TemaComercial.TextoCabeceraTabla;
        tabla.ColumnHeadersDefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.CabeceraTabla;
        tabla.ColumnHeadersDefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.TextoCabeceraTabla;
        tabla.RowHeadersDefaultCellStyle.BackColor = AzulClaro;
        tabla.RowHeadersDefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
        tabla.RowHeadersDefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
        tabla.RowHeadersDefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
        tabla.DefaultCellStyle.BackColor = MYG2027_TemaComercial.Superficie;
        tabla.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
        tabla.DefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
        tabla.DefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
        if (tabla.EditingControl is MYGEditorTextoFormulaHoja editorFormula) editorFormula.AplicarTema();
        else if (tabla.EditingControl is Control editor)
        { editor.BackColor = MYG2027_TemaComercial.Superficie; editor.ForeColor = MYG2027_TemaComercial.Texto; }
    }
    private static Label Etiqueta(string texto) => new() { Text = texto, AutoSize = true, Margin = new(8, 6, 2, 0) };
    private void Intentar(Action accion)
    { try { accion(); } catch (Exception ex) { MessageBox.Show(this, ex.Message, "MYG | Presupuestos", MessageBoxButtons.OK, MessageBoxIcon.Warning); } }
    private bool HayPartida => actual != null && !MYGProyectoStorage.EsTitulo(actual);
    private void RequerirPartida()
    { if (!HayPartida) throw new InvalidOperationException("Seleccione una partida del presupuesto."); }
    private void Cambiado() { despues(); SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos); }
    internal void Refrescar()
    {
        RefrescarEstructura();
        // Las filas nuevas nacen sin importes. Publicar el cálculo junto al
        // árbol evita depender de un mensaje posterior para mostrar precios,
        // totales e incidencia por primera vez. Una edición activa sigue
        // esperando su confirmación mediante la cola habitual.
        if (PuedeActualizarCalculosEstructura) ActualizarCalculos();
        else SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
    }
    private void PrepararACU()
    {
        refrescoDiferidoACU = new MYGRefrescoDiferido(
            accion => BeginInvoke(accion),
            () => IsHandleCreated && !IsDisposed && !Disposing && !cargando && !finalizandoEdicion &&
                !confirmandoEdicionACU && !acu.IsCurrentCellInEditMode,
            tipo => Intentar(() =>
            {
                if ((tipo & MYGTipoRefresco.Calculos) != 0) ActualizarValoresACU();
                ActualizarHerramientasACU();
            }));
        HandleCreated += (_, _) => refrescoDiferidoACU.Reintentar();
        Disposed += (_, _) => refrescoDiferidoACU.Cancelar();
        var p = paginaACU = Pagina("Análisis de C.U."); p.Controls.Add(acu); acu.ReadOnly = false; acu.Name = "acu_recursos";
        Columna(acu, "COD", "Código", 95); Columna(acu, "INDICE", "Índice unificado", 120);
        Columna(acu, "DESC", "Descripción", 300); acu.Columns["DESC"].CellTemplate = new MYGDescripcionInsumoCell();
        // Usar el ancho disponible sin comprimir las columnas de cantidades y precios.
        // En paneles estrechos, conservar la lectura mediante desplazamiento horizontal.
        acu.Columns["DESC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        acu.Columns["DESC"].MinimumWidth = 300;
        acu.AllowUserToResizeRows = false;
        acu.RowTemplate.Resizable = DataGridViewTriState.False;
        acu.RowTemplate.MinimumHeight = 24;
        acu.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
        acu.Columns["DESC"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        // La medición debe reservar el mismo espacio que la flecha del selector.
        // Así el ajuste de alto usa el ancho real disponible para el texto.
        void AjustarMargenDescripcion() => acu.Columns["DESC"].DefaultCellStyle.Padding =
            new Padding(0, 0, (int)Math.Round(22F * DeviceDpi / 96F) + 2, 0);
        AjustarMargenDescripcion();
        DpiChangedAfterParent += (_, _) => AjustarMargenDescripcion();
        acu.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
        Columna(acu, "UND", "Und.", 55);
        acu.CellMouseClick += (s, e) =>
        {
            if (cargando || e.Button != MouseButtons.Left || e.RowIndex < 0 || e.ColumnIndex < 0 || acu.Columns[e.ColumnIndex].Name != "DESC" ||
                acu.Rows[e.RowIndex].Tag is not MYGRecursoACU || e.X < acu.Columns[e.ColumnIndex].Width - (int)Math.Round(24F * DeviceDpi / 96F)) return;
            acu.CurrentCell = acu.Rows[e.RowIndex].Cells["DESC"]; Intentar(EditarReemplazarRecurso);
        };
        acu.CellDoubleClick += (s, e) =>
        { if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && acu.Columns[e.ColumnIndex].Name == "DESC" && acu.Rows[e.RowIndex].Tag is MYGRecursoACU) Intentar(EditarReemplazarRecurso); };
        acu.KeyDown += (s, e) =>
        { if (e.KeyCode == Keys.F4 && acu.CurrentCell?.OwningColumn.Name == "DESC") { e.Handled = true; Intentar(EditarReemplazarRecurso); } };
        Columna(acu, "NREC", "Nro. Rec.", 75, true); Columna(acu, "CANT", "Cantidad", 90, true); Columna(acu, "DESP", "% Desp.", 65, true);
        Columna(acu, "PRECIO", "Precio", 90); Columna(acu, "TOTAL", "Total", 90);
        acu.DataError += (s, e) => { e.ThrowException = false; };
        acu.CellBeginEdit += (s, e) =>
        {
            if (!EdicionACUNubePermitida) { e.Cancel = true; return; }
            if (!cargando)
            {
                bool preparado = false;
                Intentar(() => { antes(); preparado = true; });
                e.Cancel = !preparado;
            }
        };
        acu.CellValidating += (s, e) =>
        {
            if (cargando || e.RowIndex < 0 || e.ColumnIndex < 0 || acu.Rows[e.RowIndex].Tag is not MYGRecursoACU) return;
            // Enter conserva la columna al bajar de fila. WinForms valida
            // también celdas sin editor: NREC vacío en materiales es válido
            // porque es de solo lectura y no admite un número de recursos.
            if (acu.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly) return;
            if (acu.Columns[e.ColumnIndex].Name is "NREC" or "CANT" or "DESP" && (!MYGHojaCalculo.IntentarNumero(Convert.ToString(e.FormattedValue), out var n) || n < 0))
            { e.Cancel = true; acu.Rows[e.RowIndex].ErrorText = "Introduzca un número mayor o igual que cero."; }
            else acu.Rows[e.RowIndex].ErrorText = "";
        };
        acu.CellEndEdit += (s, e) =>
        {
            if (cargando || !EdicionACUNubePermitida || acu.Rows[e.RowIndex].Tag is not MYGRecursoACU r) return;
            confirmandoEdicionACU = true;
            try
            {
                var anterior = MYGProyectoStorage.Copia(r); var fila = acu.Rows[e.RowIndex];
                Intentar(() =>
                {
                    try
                    {
                        // La modalidad pertenece al recurso y ya no se edita en una columna.
                        // No copiar coeficientes calculados sobre su cantidad directa guardada.
                        string columna = acu.Columns[e.ColumnIndex].Name;
                        MYGHojaCalculo.IntentarNumero(Convert.ToString(fila.Cells[columna].Value), out var n);
                        if (columna == "NREC")
                        {
                            var unidad = P.Costos.Insumos.FirstOrDefault(x => x.Id == r.InsumoId)?.Unidad;
                            if (!MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(r, unidad))
                                throw new InvalidOperationException("Nro. Rec. se edita para insumos con unidades he, hh o hm.");
                            r.NumeroRecursos = n; r.Modo = MYGModoCantidad.Rendimiento; r.CalcularCantidadPorUnidad = true;
                        }
                        else if (columna == "CANT")
                        {
                            r.Cantidad = n;
                            // Una cantidad escrita expresamente deja de depender de
                            // la fórmula histórica de cuadrilla. Los porcentajes siguen
                            // usando su magnitud y su cálculo propios.
                            if (r.Modo == MYGModoCantidad.Rendimiento) r.Modo = MYGModoCantidad.Directa;
                            r.CalcularCantidadPorUnidad = false;
                        }
                        else if (columna == "DESP") r.DesperdicioPorcentaje = n;
                        MYGMotorPresupuestos.Validar(P);
                    }
                    catch
                    {
                        r.Modo = anterior.Modo; r.CalcularCantidadPorUnidad = anterior.CalcularCantidadPorUnidad;
                        r.NumeroRecursos = anterior.NumeroRecursos; r.Cantidad = anterior.Cantidad;
                        r.DesperdicioPorcentaje = anterior.DesperdicioPorcentaje;
                        throw;
                    }
                    Cambiado();
                });
            }
            finally
            {
                confirmandoEdicionACU = false;
                // WinForms aún puede estar dentro de SetCurrentCellAddressCore.
                // Confirmar el modelo ahora y actualizar la vista en otro mensaje,
                // sin tocar el siguiente editor ni reconstruir sus filas.
                refrescoDiferidoACU.Solicitar(MYGTipoRefresco.Calculos);
                // Algunas salidas todavía notifican IsCurrentCellInEditMode.
                // Reintentar al salir del evento, sin sondear ni forzar EndEdit.
                if (IsHandleCreated && !IsDisposed && !Disposing)
                    BeginInvoke(new Action(refrescoDiferidoACU.Reintentar));
            }
        };
        PrepararMenuACU();
        p.Controls.Add(PrepararHerramientasACU());
        fuente.DataSource = Enum.GetValues<MYGFuenteMetrado>();
        fuente.SelectedIndexChanged += (s, e) =>
        {
            if (cargando || !HayPartida || !EdicionMetradosExcelNubePermitida) return;
            var previo = actual.Costos.FuenteMetrado;
            Intentar(() =>
            {
                ExigirPermisoMetradosExcel(); antes();
                try { actual.Costos.FuenteMetrado = (MYGFuenteMetrado)fuente.SelectedItem; MYGMotorPresupuestos.Cantidad(P, actual); }
                catch { actual.Costos.FuenteMetrado = previo; CargarDetalle(); throw; }
                ActualizarContextoACU(); Cambiado();
            });
        };
        void NumeroCambio(NumericUpDown n, Action<decimal> asignar)
        {
            n.ValueChanged += (s, e) =>
            {
                if (cargando || !HayPartida || !EdicionACUNubePermitida) return;
                Intentar(() => { ExigirPermisoACU(); antes(); asignar(n.Value); CargarACU(); Cambiado(); });
            };
        }
        rendimiento.Minimum = jornada.Minimum = 0.0001m;
        NumeroCambio(precioDirecto, n => actual.Costos.PrecioDirecto = n);
        NumeroCambio(rendimiento, n => actual.Costos.RendimientoDiario = n); NumeroCambio(jornada, n => actual.Costos.JornadaHoras = n);
        p.Controls.Add(Barra(Etiqueta("PU directo"), precioDirecto, Etiqueta("Origen del metrado"), fuente));
        p.Controls.Add(PrepararBarraRendimientoACU());
        cabeceraACU = new MYGEspecificacionesCabecera(() => P?.Nombre ?? "",
            () => PartidaActual is { } partida && !MYGProyectoStorage.EsTitulo(partida) ? CodigoEstructura(P, partida) : "",
            () => PartidaActual is { } partida && !MYGProyectoStorage.EsTitulo(partida) ? partida.Descripcion : "Seleccione una partida",
            tituloSeccion: "Análisis de costos unitarios", nombreControl: "acu_cabecera", mostrarTiempoEjecucion: true);
        p.Controls.Add(cabeceraACU);
        PrepararTotalACU(p);
    }
    private static string CodigoIndiceUnificado(string clasificacion) =>
        MYGCatalogoIndicesUnificados.CodigoDeClasificacion(clasificacion);

    private void CargarACU()
    {
        bool previo = cargando; cargando = true;
        try
        {
            string recursoSeleccionado = (acu.CurrentRow?.Tag as MYGRecursoACU)?.Id;
            MYGGrupoRecurso? tituloSeleccionado = acu.CurrentRow?.Tag is MYGGrupoRecurso grupoActual ? grupoActual : null;
            acu.Rows.Clear(); if (!HayPartida) return;
            var calculo = MYGMotorPresupuestos.CrearCalculo(P);
            var resultado = calculo.Analizar(actual);
            foreach (MYGGrupoRecurso grupo in MYGOrdenPresupuestos.GruposACU(actual))
            {
                var lineas = resultado.Recursos.Where(x => x.Recurso.Grupo == grupo).ToList();
                var titulo = acu.Rows[acu.Rows.Add("", "", MYGMotorPresupuestos.Grupo(grupo), "", null, null, null, null, lineas.Sum(x => x.Total))];
                titulo.Tag = grupo; titulo.ReadOnly = true; titulo.DefaultCellStyle.BackColor = AzulClaro; titulo.DefaultCellStyle.Font = negrita;
                foreach (var v in lineas)
                {
                    var insumo = v.Recurso.InsumoId == null ? null : P.Costos.Insumos.FirstOrDefault(i => i.Id == v.Recurso.InsumoId);
                    string indice = CodigoIndiceUnificado(insumo?.GrupoGenerico);
                    bool usaNumeroRecursos = MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(v.Recurso, insumo?.Unidad);
                    var r = acu.Rows[acu.Rows.Add(v.Codigo, indice, v.Descripcion, v.Unidad, usaNumeroRecursos ? v.Recurso.NumeroRecursos : null,
                        v.Recurso.Modo == MYGModoCantidad.Rendimiento || v.Recurso.CalcularCantidadPorUnidad && usaNumeroRecursos
                            ? v.Cantidad : v.Recurso.Cantidad, v.Recurso.DesperdicioPorcentaje, v.Precio, v.Total)];
                    r.Tag = v.Recurso; r.Cells["CANT"].ReadOnly = usaNumeroRecursos;
                    r.Cells["NREC"].ReadOnly = !usaNumeroRecursos;
                    r.Cells["NREC"].ToolTipText = usaNumeroRecursos
                        ? "Al editar: cantidad = (rendimiento ÷ horas por día) × Nro. Rec."
                        : "Nro. Rec. se edita sólo para unidades he, hh y hm.";
                }
            }
            precioDirecto.Enabled = EdicionACUNubePermitida && actual.Costos.Analisis.Count == 0;
            var seleccionada = acu.Rows.Cast<DataGridViewRow>().FirstOrDefault(r =>
                recursoSeleccionado != null && r.Tag is MYGRecursoACU recurso && recurso.Id == recursoSeleccionado ||
                tituloSeleccionado.HasValue && r.Tag is MYGGrupoRecurso grupo && grupo == tituloSeleccionado.Value);
            if (seleccionada != null) { acu.CurrentCell = seleccionada.Cells["DESC"]; seleccionada.Selected = true; }
            ActualizarIdentificacionACU();
            ActualizarContextoACU(calculo);
        }
        finally { cargando = previo; ActualizarHerramientasACU(); ActualizarPermisoNube(); }
    }

    private void ActualizarValoresACU()
    {
        if (!HayPartida) return;
        bool previo = cargando; cargando = true;
        try
        {
            var calculo = MYGMotorPresupuestos.CrearCalculo(P);
            var resultado = calculo.Analizar(actual);
            var porRecurso = resultado.Recursos.ToDictionary(x => x.Recurso.Id, StringComparer.Ordinal);
            var porGrupo = resultado.Recursos.GroupBy(x => x.Recurso.Grupo)
                .ToDictionary(g => g.Key, g => g.Sum(x => x.Total));
            foreach (DataGridViewRow fila in acu.Rows)
            {
                if (fila.Tag is MYGGrupoRecurso grupo)
                {
                    PonerValor(fila.Cells["TOTAL"], porGrupo.GetValueOrDefault(grupo));
                    continue;
                }
                if (fila.Tag is not MYGRecursoACU recurso || !porRecurso.TryGetValue(recurso.Id, out var valor)) continue;
                var insumo = P.Costos.Insumos.FirstOrDefault(x => x.Id == recurso.InsumoId);
                bool usaNumeroRecursos = MYGCalculoCantidadRecursoACU.UsaNumeroRecursos(recurso, insumo?.Unidad);
                PonerValor(fila.Cells["NREC"], usaNumeroRecursos ? recurso.NumeroRecursos : null);
                PonerValor(fila.Cells["CANT"], recurso.Modo == MYGModoCantidad.Rendimiento || recurso.CalcularCantidadPorUnidad && usaNumeroRecursos
                    ? valor.Cantidad : recurso.Cantidad);
                PonerValor(fila.Cells["DESP"], recurso.DesperdicioPorcentaje);
                PonerValor(fila.Cells["PRECIO"], valor.Precio);
                PonerValor(fila.Cells["TOTAL"], valor.Total);
                fila.Cells["NREC"].ReadOnly = !usaNumeroRecursos;
                fila.Cells["CANT"].ReadOnly = usaNumeroRecursos;
            }
            ActualizarContextoACU(calculo);
        }
        finally { cargando = previo; }
    }
    private void PrepararEspecificacion()
    {
        var p = Pagina("Específ. técnicas");
        editorEspecificaciones = new MYGEspecificacionesEditor(especificacion,
            PrepararCambioEspecificacion, GuardarEspecificacion,
            () => PartidaActual?.Descripcion ?? "Especificaciones técnicas", () => PartidaActual?.Unidad ?? "",
            () => PartidaActual is { } partida ? CodigoEstructura(P, partida) : "", () => P?.Nombre ?? "", guardarProyecto,
            confirmarGuardado: ConfirmarGuardadoEspecificacion);
        editorEspecificaciones.PermisoEdicionNube = () => EdicionEspecificacionesNubePermitida;
        p.Controls.Add(editorEspecificaciones);
    }
    private void PrepararCambioEspecificacion()
    {
        if (cargando || !EdicionEspecificacionesNubePermitida) return;
        // Insertar título también confirma el texto de una celda que todavía
        // esté en edición. Esto modifica sólo el modelo en memoria, sin guardar.
        FinalizarEdicion();
        ActualizarIdentificacionDetalle();
        RequerirPartida(); antes();
    }
    private void ActualizarIdentificacionDetalle()
    {
        actual = PartidaActual;
        editorEspecificaciones?.ActualizarIdentificacion();
        cabeceraACU?.Actualizar();
        ActualizarContextoACU();
        cabeceraExcel?.Actualizar();
    }
    private void ActualizarPresentacionEspecificaciones()
    {
        // Mantener el mismo espacio de detalle y el divisor que utiliza el ACU.
        pie.Visible = !EsSeleccionInsumosContexto;
        editorEspecificaciones?.AplicarTema(); detalle.Invalidate();
    }
    private void PrepararPestanasDetalle()
    {
        var imagenes = new ImageList { ImageSize = new(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        var originales = new List<Bitmap>();
        foreach (string nombre in new[] { "acu", "especificacion", "excel", "bim", "resumen" })
        { var imagen = MYGIconos.Obtener(nombre); originales.Add(imagen); imagenes.Images.Add(imagen); }
        detalle.ImageList = imagenes;
        for (int i = 0; i < detalle.TabPages.Count; i++) detalle.TabPages[i].ImageIndex = i;
        MYGTemaPestanas.Preparar(detalle);
        Disposed += (_, _) => { imagenes.Dispose(); foreach (var imagen in originales) imagen.Dispose(); };
    }
    private void GuardarEspecificacion()
    {
        if (cargando || !EdicionEspecificacionesNubePermitida) return;
        actual = PartidaActual;
        if (!HayPartida) return;
        // Conservar el autoguardado del texto sin presentar una especificación
        // nueva como guardada antes de que el usuario pulse Guardar.
        actual.Costos.EspecificacionEsBorrador |= !MYGContenidoPartida.TieneEspecificacionGuardada(actual.Costos);
        actual.Costos.EspecificacionRtf = editorEspecificaciones.DocumentoRtf;
        actual.Costos.EspecificacionTexto = especificacion.Text; Cambiado();
    }
    private void ConfirmarGuardadoEspecificacion()
    {
        if (cargando || !EdicionEspecificacionesNubePermitida) return;
        FinalizarEdicion();
        ActualizarIdentificacionDetalle();
        if (!HayPartida) return;
        string rtf = editorEspecificaciones.DocumentoRtf, texto = especificacion.Text;
        if (!actual.Costos.EspecificacionEsBorrador && actual.Costos.EspecificacionRtf == rtf &&
            actual.Costos.EspecificacionTexto == texto) return;
        antes();
        actual = PartidaActual;
        actual.Costos.EspecificacionRtf = rtf;
        actual.Costos.EspecificacionTexto = texto;
        actual.Costos.EspecificacionEsBorrador = false;
        Cambiado();
    }
    private void PrepararBIM()
    {
        var p = Pagina("Metrados Revit");
        var contenidoRevit = PrepararConfiguracionMetradosRevit();
        var activosRevit = new Panel { Dock = DockStyle.Fill };
        activosRevit.Controls.Add(bim);
        contenidoRevit.Controls.Add(PrepararActivosMetradosRevit(activosRevit), 0, 2);
        p.Controls.Add(contenidoRevit);
        Columna(bim, "ACTIVO", "Activo", 140); Columna(bim, "TABLA", "Tabla de Revit", 290); Columna(bim, "CANT", "Cantidad", 100); Columna(bim, "UND", "Und.", 55); Columna(bim, "FECHA", "Fecha", 135);
        PrepararInclusionResultadosRevit();
        var actualizar = Boton("Consultar Revit abierto", () => { });
        actualizar.Click += async (s, e) => { actualizar.Enabled = false; try { await consultarBIM(); } finally { if (!IsDisposed) actualizar.Enabled = true; } };
        activosRevit.Controls.Add(Barra(actualizar, Boton("Importar metrados JSON", () =>
        { using var d = new OpenFileDialog { Filter = "Metrado MYG (*.json)|*.json" }; if (d.ShowDialog(this) == DialogResult.OK) importarBIM(File.ReadAllText(d.FileName)); }),
            Boton("Quitar metrado recibido", () =>
            { ExigirEdicionActivosRevit(); ExigirPermisoMetradosExcel(); if (bim.CurrentRow?.Tag is MYGMetradoBIM m) { antes(); actual.Costos.MetradosBIM.Remove(m); CargarDetalle(); Cambiado(); } }),
            Boton("Usar cantidad BIM", () => { RequerirPartida(); fuente.SelectedItem = MYGFuenteMetrado.BIM; detalle.SelectedTab = paginaACU; })));
    }
    private void CargarDetalle(bool solicitarCalculos = true)
    {
        if (IsDisposed) return; bool previo = cargando; cargando = true;
        bool hojaCargada = false;
        try
        {
            ActualizarIdentificacionDetalle();
            CargarConfiguracionMetradosRevit();
            MostrarInsumosContexto();
            foreach (TabPage p in detalle.TabPages) p.Enabled = HayPartida;
            bim.Rows.Clear(); consolidado.Rows.Clear();
            direccion.Clear(); formula.Clear();
            direccionFormulaHoja = null; formulaPendienteHoja = false;
            consolidadoPendiente = true;
            if (!HayPartida) { editorEspecificaciones.Cargar(null, "", ""); acu.Rows.Clear(); hoja.Rows.Clear(); return; }
            var d = actual.Costos; fuente.SelectedItem = d.FuenteMetrado;
            precioDirecto.Value = Math.Min(precioDirecto.Maximum, d.PrecioDirecto); rendimiento.Value = Math.Clamp(d.RendimientoDiario, rendimiento.Minimum, rendimiento.Maximum);
            jornada.Value = Math.Clamp(d.JornadaHoras, jornada.Minimum, jornada.Maximum);
            editorEspecificaciones.Cargar(actual.Id, d.EspecificacionRtf, d.EspecificacionTexto, insertarTituloInicial: true);
            foreach (var m in d.MetradosBIM)
            {
                var registrado = obtenerProyectoActivosRevit?.Invoke()?.ActivosRevit?.Activos.FirstOrDefault(a => a.Id == m.ActivoId);
                var fila = bim.Rows[bim.Rows.Add(!m.ExcluirDelTotal, registrado?.Nombre ?? m.ActivoId, m.Tabla, m.Cantidad, m.Unidad, m.FechaUtc.ToLocalTime())];
                fila.Tag = m;
                fila.Cells["ACTIVO"].ToolTipText = registrado == null ? "Resultado anterior sin vínculo verificado al registro de activos de esta obra." : registrado.Id;
                fila.Cells["TABLA"].ToolTipText = "Modelo de origen: " + m.DocumentoId;
            }
            CargarACU(); hojaPendiente = true;
            if (detalle.SelectedTab?.Controls.Contains(hoja) == true) { CargarHoja(); hojaPendiente = false; hojaCargada = true; }
        }
        finally
        {
            cargando = previo;
            ActualizarHerramientasACU();
            ActualizarBarraReferenciasPartidasHoja();
            ActualizarPermisoNube();
            if (hojaCargada && !cargando) ActualizarFormula();
            if (solicitarCalculos) SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        }
    }
    private void ActualizarCalculos()
    {
        if (IsDisposed || actualizandoCalculos) return;
        bool previo = cargando;
        bool hojaCargada = false;
        var ajusteFilas = estructura.AutoSizeRowsMode;
        actualizandoCalculos = true; cargando = true;
        estructura.SuspendLayout(); estructura.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        try
        {
            // Conservar la sesión para selección y plegado puramente visuales.
            // Una solicitud por edición o reconstrucción invalida sus resultados.
            PrepararActualizacionAlertasPartidas();
            calculosEstructura.Clear();
            MYGCalculoPresupuesto Calculo(MYGPresupuestoDocumento p)
            {
                if (!calculosEstructura.TryGetValue(p, out var c)) calculosEstructura.Add(p, c = MYGMotorPresupuestos.CrearCalculo(p));
                return c;
            }
            RefrescarPiePresupuesto(Calculo);
            foreach (var r in filasEstructura)
            {
                try
                {
                    if (!propietariosEstructura.TryGetValue(r, out var propietario)) continue;
                    var c = Calculo(propietario);
                    if (r.Tag is MYGPresupuestoDocumento presupuesto)
                        PonerValor(CeldaEstructura(r, "TOTAL"), c.Resumen().CostoDirecto);
                    else if (r.Tag is ItemPresupuestoDelphin i)
                    {
                        bool titulo = MYGProyectoStorage.EsTitulo(i);
                        if (!estructura.IsCurrentCellInEditMode || estructura.CurrentCell != CeldaEstructura(r, "CANT"))
                            PonerValor(CeldaEstructura(r, "CANT"), titulo ? null : c.Cantidad(i));
                        PonerValor(CeldaEstructura(r, "PU"), titulo ? null : c.Analizar(i).PrecioUnitario);
                        PonerValor(CeldaEstructura(r, "TOTAL"), c.TotalPartida(i));
                        if (!titulo) CeldaEstructura(r, "CANT").ToolTipText = "Origen actual: " + i.Costos.FuenteMetrado + ". Al editar se usará cantidad directa; los metrados BIM, manuales y de Excel se conservan. Máximo dos decimales.";
                    }
                    r.ErrorText = "";
                }
                catch (Exception ex) { PonerValor(CeldaEstructura(r, "TOTAL"), "#ERROR"); r.ErrorText = ex.Message; }
                if (r.Tag is ItemPresupuestoDelphin partida && propietariosEstructura.TryGetValue(r, out var propietarioAlertas))
                    ActualizarAlertaPartida(r, propietarioAlertas, partida, Calculo(propietarioAlertas));
            }
            estructura.Invalidate();
            consolidadoPendiente = listaCostosPendiente = true;
            ActualizarInsumosContexto();
            if (P == null) { pie.Text = "Agregue un presupuesto con clic derecho en el área en blanco."; consolidado.Rows.Clear(); listaCostos.Rows.Clear(); return; }
            try
            {
                hojaCargada = ActualizarContextoCalculosEstructura(Calculo(P));
            }
            catch (Exception ex) { pie.Text = ex.Message; consolidado.Rows.Clear(); listaCostos.Rows.Clear(); ActualizarContextoACU(); }
        }
        finally
        {
            estructura.AutoSizeRowsMode = ajusteFilas; estructura.ResumeLayout();
            cargando = previo; actualizandoCalculos = false;
            if (hojaCargada && !cargando) ActualizarFormula();
        }
        cabeceraExcel?.Actualizar();
    }
    private bool ActualizarContextoCalculosEstructura(MYGCalculoPresupuesto calculo)
    {
        var resumen = calculo.Resumen();
        pie.Text = P.Costos.Moneda + "  Total presupuesto: " + MYGFormatoPresupuesto.Dinero(resumen.Total);
        if (HayPartida)
        {
            fuente.SelectedItem = actual.Costos.FuenteMetrado;
            pie.Text = "PU: " + MYGFormatoPresupuesto.Dinero(calculo.Analizar(actual).PrecioUnitario) + "   Cantidad (" + actual.Costos.FuenteMetrado + "): " + MYGFormatoPresupuesto.Cantidad(calculo.Cantidad(actual)) + " " + actual.Unidad + "   |   " + pie.Text;
        }
        bool hojaCargada = ActualizarVistasPendientes(calculo);
        ActualizarContextoACU(calculo);
        return hojaCargada;
    }
    private void ActualizarCalculosSeleccionEstructura(bool cambioPresupuesto)
    {
        // Cambiar la selección no cambia cantidades ni precios. Reutilizar
        // el último cálculo evita recalcular el proyecto al pulsar una flecha.
        if (P == null || !calculosEstructura.TryGetValue(P, out var calculo))
        { SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos); return; }
        bool previo = cargando;
        bool hojaCargada = false;
        cargando = true;
        try
        {
            if (cambioPresupuesto)
                RefrescarPiePresupuesto(p => calculosEstructura.TryGetValue(p, out var c) ? c : MYGMotorPresupuestos.CrearCalculo(p));
            hojaCargada = ActualizarContextoCalculosEstructura(calculo);
        }
        finally
        {
            cargando = previo;
            if (hojaCargada && !cargando) ActualizarFormula();
        }
        cabeceraExcel?.Actualizar();
    }
    private static void PonerValor(DataGridViewCell celda, object valor)
    { if (!Equals(celda.Value, valor)) celda.Value = valor; }
    private void ActualizarVistasPendientes() { ActualizarVistasPendientes(null); }
    private bool ActualizarVistasPendientes(MYGCalculoPresupuesto calculo)
    {
        if (IsDisposed || P == null) return false;
        bool previo = cargando; cargando = true;
        bool hojaCargada = false;
        try
        {
            if (consolidadoPendiente && vistaSeleccionada == principal && detalle.SelectedTab?.Controls.Contains(consolidado) == true)
            {
                calculo ??= MYGMotorPresupuestos.CrearCalculo(P);
                LlenarConsolidado(consolidado, HayPartida ? calculo.Consolidar(actual) : new());
                consolidadoPendiente = false;
            }
            if (listaCostosPendiente && vistaSeleccionada == paginaCostos)
            {
                calculo ??= MYGMotorPresupuestos.CrearCalculo(P);
                LlenarConsolidado(listaCostos, calculo.Consolidar()); listaCostosPendiente = false;
            }
            if (hojaPendiente && HayPartida && vistaSeleccionada == principal && detalle.SelectedTab?.Controls.Contains(hoja) == true)
            { CargarHoja(); hojaPendiente = false; hojaCargada = true; }
        }
        finally
        {
            cargando = previo;
            if (hojaCargada && !cargando) ActualizarFormula();
        }
        return hojaCargada;
    }
    private static void LlenarConsolidado(DataGridView tabla, IEnumerable<MYGInsumoConsolidado> datos)
    {
        tabla.Rows.Clear(); foreach (var r in datos) tabla.Rows.Add(MYGMotorPresupuestos.Grupo(r.Grupo), r.Codigo, r.Descripcion, r.Unidad, r.Cantidad, r.Precio, r.Total);
    }
    private void NuevoInsumo()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        if (P == null) throw new InvalidOperationException("Agregue un presupuesto antes de crear insumos.");
        string ruta = RutaCatalogos();
        var nuevo = new MYGInsumo(); MYGParametrosUsuario.Leer().Aplicar(nuevo);
        using var f = new MYGInsumoForm(nuevo, MYGCatalogoUnidades.Listar(ruta), conservarUnidadInicial: true);
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        var prueba = MYGProyectoStorage.Copia(P); prueba.Costos.Insumos.Add(f.Valor); MYGProyectoStorage.ValidarPresupuesto(prueba);
        MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { f.Valor });
        antes(); P.Costos.Insumos.Add(f.Valor); Refrescar(); despues();
    }
    private void EditarInsumo()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion();
        if (insumos.CurrentRow?.Tag is not MYGInsumo i) return;
        string id = i.Id;
        var unidades = MYGCatalogoUnidades.Listar(RutaCatalogos());
        i = P.Costos.Insumos.First(x => x.Id == id);
        using var f = new MYGInsumoForm(MYGProyectoStorage.Copia(i), unidades);
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos(); MYGInsumosEdicion.EditarInsumo(P, f.Valor, antes); Refrescar(); despues();
    }
    private void EliminarInsumo()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); FinalizarEdicion();
        if (insumos.CurrentRow?.Tag is not MYGInsumo i) return;
        if (P.Items.Any(x => x.Costos.Analisis.Any(r => r.InsumoId == i.Id))) throw new InvalidOperationException("El insumo está usado en un ACU; quite esas referencias primero.");
        antes(); P.Costos.Insumos.Remove(i); Refrescar(); despues();
    }
    private void MostrarVista(Panel pagina)
    {
        if (vistaSeleccionada == pagina) return;
        FinalizarEdicion();
        vistas.SuspendLayout();
        try
        {
            vistaSeleccionada.Visible = false;
            vistaSeleccionada = pagina;
            pagina.Visible = true;
            pagina.BringToFront();
        }
        finally { vistas.ResumeLayout(); }
        ActualizarPresentacionEspecificaciones(); ActualizarHerramientasACU();
        if (!cargando) Intentar(ActualizarVistasPendientes);
    }
    internal void MostrarInsumos() { MostrarVista(paginaInsumos); }
    internal void MostrarEspecificacion() { MostrarVista(principal); detalle.SelectedIndex = 1; }
    private void AgregarRecurso() => AgregarRecurso(false);
    private void AgregarRecurso(bool sobreSeleccion, bool compuestoInicial = false, MYGGrupoRecurso? grupoInicial = null)
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); RequerirPartida();
        // Finalizar una celda puede reconstruir el ACU; guardar el destino antes.
        string partidaId = actual.Id, anteriorId = (acu.CurrentRow?.Tag as MYGRecursoACU)?.Id;
        MYGGrupoRecurso? grupo = grupoInicial ?? (acu.CurrentRow?.Tag is MYGGrupoRecurso g ? g : (acu.CurrentRow?.Tag as MYGRecursoACU)?.Grupo);
        FinalizarEdicion();
        // Consultar el selector no registra los demás insumos del presupuesto.
        // Sólo los nuevos que se acepten se publican en AplicarInsumosAlACU.
        string ruta = RutaCatalogos(); var unidades = MYGCatalogoUnidades.Listar(ruta);
        actual = P.Items.First(x => x.Id == partidaId);
        using var f = new MYGSelectorInsumoForm(P, actual, null, unidades, ruta, grupo);
        if (compuestoInicial || grupo == MYGGrupoRecurso.Subpartidas) f.MostrarCompuesto();
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        var recursos = AplicarInsumosAlACU(ruta, partidaId, f.Selecciones, sobreSeleccion ? anteriorId : null);
        Refrescar(); SeleccionarRecursoACU(recursos[0].Id); despues();
    }
    private void EditarReemplazarRecurso()
    {
        ExigirPermisoACU(); RequerirPermisoCatalogos(); RequerirPartida();
        if (acu.CurrentRow?.Tag is not MYGRecursoACU recurso) throw new InvalidOperationException("Seleccione un recurso del ACU.");
        string partidaId = actual.Id, recursoId = recurso.Id;
        FinalizarEdicion();
        if (actual?.Id != partidaId) throw new InvalidOperationException("Seleccione nuevamente la partida para editar su insumo.");
        // Una diferencia en otro insumo del presupuesto no debe bloquear la
        // consulta ni la edición de este recurso. El alta se valida al aceptar.
        string ruta = RutaCatalogos(); var unidades = MYGCatalogoUnidades.Listar(ruta);
        actual = P.Items.First(x => x.Id == partidaId); recurso = actual.Costos.Analisis.First(x => x.Id == recursoId);
        using var f = new MYGSelectorInsumoForm(P, actual, recurso, unidades, ruta);
        if (f.ShowDialog(this) != DialogResult.OK) return;
        ExigirPermisoACU(); RequerirPermisoCatalogos();
        MYGInsumosEdicion.Aplicar(MYGProyectoStorage.Copia(P), partidaId, recursoId, f.Seleccion);
        if (f.Seleccion.NuevoInsumo != null && !f.Seleccion.EditarCompartido)
            MYGCatalogos.RegistrarInsumosAutomaticamente(ruta, new[] { f.Seleccion.NuevoInsumo });
        MYGInsumosEdicion.Aplicar(P, partidaId, recursoId, f.Seleccion, antes: antes);
        Refrescar(); SeleccionarRecursoACU(recursoId); despues();
    }
    private void SeleccionarRecursoACU(string id)
    {
        var fila = acu.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => x.Tag is MYGRecursoACU r && r.Id == id);
        if (fila != null) { acu.CurrentCell = fila.Cells["DESC"]; fila.Selected = true; }
    }
    private void AgregarSubpartida()
    {
        AgregarRecurso(false, true);
    }
    private void EliminarRecurso()
    {
        ExigirPermisoACU(); RequerirPartida(); if (acu.CurrentRow?.Tag is MYGRecursoACU r) { antes(); actual.Costos.Analisis.Remove(r); CargarACU(); Cambiado(); } }
}

internal sealed class MYGElegirCostoForm : Form
{
    internal object Elegido { get; private set; }
    internal MYGElegirCostoForm(string titulo, object[] opciones)
    {
        Text = titulo; StartPosition = FormStartPosition.CenterParent; ClientSize = new(720, 440);
        var buscar = new TextBox { Dock = DockStyle.Top, PlaceholderText = "Buscar…" }; var lista = new ListBox { Dock = DockStyle.Fill, HorizontalScrollbar = true, Font = new("Segoe UI", 10) };
        var aceptar = new Button { Text = "Usar selección", Dock = DockStyle.Bottom, Height = 36 };
        void Filtrar() { lista.Items.Clear(); lista.Items.AddRange(opciones.Where(x => x.ToString().Contains(buscar.Text, StringComparison.OrdinalIgnoreCase)).ToArray()); }
        void Elegir() { if (lista.SelectedItem == null) return; Elegido = lista.SelectedItem; DialogResult = DialogResult.OK; }
        buscar.TextChanged += (s, e) => Filtrar(); aceptar.Click += (s, e) => Elegir(); lista.DoubleClick += (s, e) => Elegir();
        Controls.Add(lista); Controls.Add(buscar); Controls.Add(aceptar); Filtrar();
    }
}
