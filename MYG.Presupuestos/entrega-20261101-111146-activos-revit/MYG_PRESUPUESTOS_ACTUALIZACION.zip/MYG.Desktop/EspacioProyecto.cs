using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

// Conserva el contenedor que comparten Presupuesto y CPM, sin una segunda
// navegación inferior. La única página ocupa también el área de cabeceras.
internal sealed class MYGEspacioProyecto : TabControl
{
    public override Rectangle DisplayRectangle => ClientRectangle;
}
