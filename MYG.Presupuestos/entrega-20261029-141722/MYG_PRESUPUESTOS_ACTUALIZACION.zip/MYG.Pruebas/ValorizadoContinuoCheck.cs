using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ValorizadoContinuoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static string Texto(MYGHojaMetrado hoja, string direccion) => new MYGHojaCalculo(hoja).Mostrar(direccion);
    private static int Cuenta(MYGHojaMetrado hoja, string texto) => hoja.Celdas.Values.Count(c => c.Contenido == texto);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        HojaContinua(carpeta, pasa);
        FechasYVista(carpeta, pasa);
    }

    private static (MYGProyectoDocumento Documento, MYGCronograma Plan) Crear(int cantidad, DateTime inicio)
    {
        var documento = MYGProyectoStorage.Nuevo("VALORIZADO CONTINUO QA");
        documento.Datos = new() { FechaElaboracion = new DateTime(2027, 12, 15) };
        var presupuesto = documento.Presupuestos.Single();
        presupuesto.Nombre = "PRESUPUESTO QA";
        var plan = new MYGCronograma { FechaInicio = inicio, FechaEstado = inicio };
        for (int n = 1; n <= cantidad; n++)
        {
            string id = "P" + n;
            var item = new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, Item = n.ToString("0000"), Descripcion = "PARTIDA QA " + n,
                TipoPropuesta = "PARTIDA", Unidad = "und"
            };
            item.Costos.Cantidad = 1; item.Costos.PrecioDirecto = n;
            presupuesto.Items.Add(item);
            plan.Tareas.Add(new() { Id = "T" + n, Nombre = item.Descripcion, DuracionDias = 1,
                PresupuestoId = presupuesto.Id, PartidaId = id });
        }
        return (documento, plan);
    }

    private static void HojaContinua(string carpeta, Action<string> pasa)
    {
        const int cantidad = 1005;
        var (documento, plan) = Crear(cantidad, new DateTime(2028, 1, 3));
        string origen = Firma(documento), programacion = Firma(plan);
        var reportes = MYGReportesCronograma.CrearValorizado(documento, plan);
        Exige(reportes.Count == 1, "El valorizado todavía divide las partidas al superar mil filas.");
        var hoja = reportes.Single().Hoja;
        var calculo = new MYGHojaCalculo(hoja);
        decimal total = cantidad * (cantidad + 1m) / 2;
        Exige(hoja.Filas > 1000 && Cuenta(hoja, "PARTIDA QA 1") == 1 && Cuenta(hoja, "PARTIDA QA 1005") == 1 &&
            hoja.Celdas.Values.Count(c => c.Contenido?.StartsWith("PARTIDA QA ", StringComparison.Ordinal) == true) == cantidad &&
            Cuenta(hoja, "Costo directo") == 1 && Cuenta(hoja, "Porcentaje de avance por Mes") == 1 &&
            Cuenta(hoja, "Porcentaje de avance acumulado") == 1 &&
            !hoja.Celdas.Values.Any(c => c.Contenido?.StartsWith("Continúa en la siguiente hoja", StringComparison.Ordinal) == true) &&
            calculo.Numero(hoja.CeldaTotal) == total &&
            calculo.Numero("G" + MYGHojaCalculo.Coordenadas(hoja.CeldaTotal).Fila) == total,
            "La hoja continua perdió partidas, duplicó pie/porcentajes o alteró la conciliación mensual.");
        MYGHojaCalculo.Validar(hoja);
        string ruta = Path.Combine(carpeta, "Valorizado continuo 1005.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, reportes);
        var nombres = MYGExcelPresupuestos.Hojas(ruta);
        Exige(nombres.Length == 1, "El XLSX volvió a crear hojas de continuación.");
        var reabierta = MYGExcelPresupuestos.Importar(ruta, nombres.Single(), hoja.CeldaTotal);
        Exige(Cuenta(reabierta, "PARTIDA QA 1005") == 1 && Cuenta(reabierta, "Costo directo") == 1 &&
            Cuenta(reabierta, "Porcentaje de avance acumulado") == 1 &&
            new MYGHojaCalculo(reabierta).Numero(reabierta.CeldaTotal) == total &&
            Firma(documento) == origen && Firma(plan) == programacion,
            "Reabrir el XLSX continuo perdió filas/totales o la exportación modificó el proyecto.");
        pasa("Valorizado con 1005 partidas exporta una sola hoja, conserva primera y última fila y un único pie, total y avance acumulado");

        // Las mismas partidas en 194 meses exceden 200.000 celdas. Rechazar
        // explícitamente protege el modelo sin volver a crear continuaciones.
        var ultima = plan.Tareas.Last();
        ultima.Modo = MYGModoTarea.Manual;
        ultima.InicioManual = new DateTime(2044, 2, 1);
        bool rechazado = false;
        try { MYGReportesCronograma.CrearValorizado(documento, plan); }
        catch (InvalidDataException) { rechazado = true; }
        Exige(rechazado, "El valorizado aceptó o dividió silenciosamente una hoja que supera 200.000 celdas.");
        pasa("Valorizado rechaza explícitamente los límites de una sola hoja sin truncar partidas ni crear continuaciones");
    }

    private static void FechasYVista(string carpeta, Action<string> pasa)
    {
        var (documento, plan) = Crear(2, new DateTime(2028, 1, 3));
        documento.Datos.FechaInicio = plan.FechaInicio;
        documento.Datos.FechaFin = new DateTime(2028, 2, 16);
        plan.Tareas[1].Modo = MYGModoTarea.Manual;
        plan.Tareas[1].InicioManual = documento.Datos.FechaFin;
        string origen = Firma(documento), programacion = Firma(plan);
        var reporte = MYGReportesCronograma.CrearValorizado(documento, plan).Single();
        var hoja = reporte.Hoja;
        string primerMes = "Mes 1\nDel 01/01/2028\nAl 31/01/2028";
        string ultimoMes = "Mes 2\nDel 01/02/2028\nAl 16/02/2028";
        Exige(Texto(hoja, "G9") == primerMes && Texto(hoja, "H9") == ultimoMes &&
            new MYGHojaCalculo(hoja).Numero(hoja.CeldaTotal) == 3 &&
            reporte.EncabezadosPeriodosSinFechas.Count == 2 &&
            reporte.EncabezadosPeriodosSinFechas["G9"] == "Mes 1" &&
            reporte.EncabezadosPeriodosSinFechas["H9"] == "Mes 2",
            "El último mes no usa el fin configurado del proyecto o perdió sus rótulos sin fechas.");

        var vista = new MYGConfiguracionVistaReporte(new[] { reporte });
        Exige(vista.TieneFechasPeriodos && vista.MostrarFechasPeriodos, "La vista no detecta el fechado mensual activado inicialmente.");
        var fechada = vista.CapturarSolicitud();
        vista.FechasPeriodos(false);
        vista.Fuente("Calibri"); vista.RepetirTitulos(false);
        var sinFechas = vista.CapturarSolicitud();
        var visible = vista.Reportes.Single().Hoja;
        Exige(!vista.MostrarFechasPeriodos && Texto(visible, "G9") == "Mes 1" && Texto(visible, "H9") == "Mes 2" &&
            Texto(visible, "B6") == "15/12/2027" && visible.Celdas["H9"].Negrita && visible.Celdas["H9"].Fuente == "Calibri" &&
            !visible.RepetirTitulos && Texto(hoja, "H9") == ultimoMes,
            "Ocultar el fechado alteró fecha de elaboración, estilos, ajustes u hoja original.");
        string rutaDirecta = Path.Combine(carpeta, "Valorizado sin fechado vista directa.xlsx");
        MYGReportesExportacion.Guardar(rutaDirecta, MYGFormatoExportacionReporte.Xlsx, vista.Reportes);
        var directa = MYGExcelPresupuestos.Importar(rutaDirecta, MYGExcelPresupuestos.Hojas(rutaDirecta).Single(), hoja.CeldaTotal);
        Exige(Texto(directa, "H9") == "Mes 2" && Texto(directa, "B6") == "15/12/2027" &&
            new MYGHojaCalculo(directa).Numero(directa.CeldaTotal) == 3,
            "Exportar directamente las hojas visibles reactivó fechas o cambió importes.");
        vista.FechasPeriodos(true);
        Exige(Texto(vista.Reportes.Single().Hoja, "H9") == ultimoMes &&
            vista.Reportes.Single().Hoja.Celdas["H9"].Fuente == "Calibri" && !vista.Reportes.Single().Hoja.RepetirTitulos,
            "Reactivar fechas no recuperó el texto original o deshizo otros ajustes.");
        vista.FechasPeriodos(false); vista.Restaurar();
        Exige(vista.MostrarFechasPeriodos && Texto(vista.Reportes.Single().Hoja, "H9") == ultimoMes &&
            Texto(sinFechas.CrearReportes().Single().Hoja, "H9") == "Mes 2" &&
            Texto(fechada.CrearReportes().Single().Hoja, "H9") == ultimoMes,
            "Restaurar o cambiar el panel alteró las capturas independientes del fechado.");

        void ExportarYComprobar(string nombre, MYGConfiguracionVistaReporte.Solicitud solicitud, string esperado)
        {
            string ruta = Path.Combine(carpeta, nombre);
            var actuales = solicitud.CrearReportes();
            MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, actuales);
            var leida = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta).Single(), hoja.CeldaTotal);
            Exige(Texto(leida, "H9") == esperado && Texto(leida, "B6") == "15/12/2027" &&
                new MYGHojaCalculo(leida).Numero(leida.CeldaTotal) == 3,
                "El XLSX no obedece la opción de fechado o modifica fechas generales/importes.");
        }
        ExportarYComprobar("Valorizado con fechado.xlsx", fechada, ultimoMes);
        ExportarYComprobar("Valorizado sin fechado.xlsx", sinFechas, "Mes 2");
        Exige(Firma(documento) == origen && Firma(plan) == programacion && Texto(hoja, "H9") == ultimoMes,
            "Configurar o exportar el fechado cambió los datos editables.");
        pasa("Fechado mensual se oculta/reactiva/restaura en vista y XLSX con capturas independientes sin cambiar fecha del proyecto, estilos ni costos");

        documento.Datos.FechaFin = null;
        var sinFin = MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja;
        Exige(Texto(sinFin, "H9") == "Mes 2\nDel 01/02/2028\nAl 29/02/2028",
            "Sin fecha de fin configurada debe conservarse el cierre mensual bisiesto.");
        documento.Datos.FechaFin = new DateTime(2028, 2, 29);
        Exige(Texto(MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja, "H9") ==
            "Mes 2\nDel 01/02/2028\nAl 29/02/2028", "El fin contractual bisiesto se desplazó de día.");

        documento.Datos.FechaFin = new DateTime(2028, 3, 16);
        var extendida = MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja;
        int filaTotal = MYGHojaCalculo.Coordenadas(extendida.CeldaTotal).Fila;
        var calculoExtendido = new MYGHojaCalculo(extendida);
        Exige(extendida.Columnas == 9 && Texto(extendida, "I9") == "Mes 3\nDel 01/03/2028\nAl 16/03/2028" &&
            calculoExtendido.Numero("G" + filaTotal) == 1 && calculoExtendido.Numero("H" + filaTotal) == 2 &&
            calculoExtendido.Numero("I" + filaTotal) == 0 && calculoExtendido.Numero(extendida.CeldaTotal) == 3,
            "Un fin contractual posterior a las tareas perdió el mes final vacío o alteró las valorizaciones previas.");

        plan.Tareas[1].InicioManual = new DateTime(2028, 4, 4);
        var fueraContrato = MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja;
        int totalFuera = MYGHojaCalculo.Coordenadas(fueraContrato.CeldaTotal).Fila;
        var calculoFuera = new MYGHojaCalculo(fueraContrato);
        Exige(fueraContrato.Columnas == 10 && Texto(fueraContrato, "J9") == "Mes 4\nDel 01/04/2028\nAl 30/04/2028" &&
            calculoFuera.Numero("J" + totalFuera) == 2 && calculoFuera.Numero(fueraContrato.CeldaTotal) == 3,
            "Una actividad posterior al contrato perdió su mes o su importe al exportar.");

        documento.Datos.FechaFin = new DateTime(2028, 2, 10);
        plan.Tareas[1].InicioManual = new DateTime(2028, 2, 16);
        var mismoMes = MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja;
        int totalMismoMes = MYGHojaCalculo.Coordenadas(mismoMes.CeldaTotal).Fila;
        var calculoMismoMes = new MYGHojaCalculo(mismoMes);
        Exige(Texto(mismoMes, "H9") == "Mes 2\nDel 01/02/2028\nAl 10/02/2028" &&
            calculoMismoMes.Numero("H" + totalMismoMes) == 2 && calculoMismoMes.Numero(mismoMes.CeldaTotal) == 3,
            "El rótulo contractual recortó el importe de una actividad posterior dentro del mismo mes.");
        pasa("Periodo contractual extiende meses vacíos y fija el último día sin ocultar ni recortar tareas e importes posteriores al contrato");

        var ajena = new MYGHojaReporteProyecto("Otro informe", MYGProyectoStorage.Copia(hoja));
        var otraVista = new MYGConfiguracionVistaReporte(new[] { ajena });
        otraVista.FechasPeriodos(false);
        Exige(!otraVista.TieneFechasPeriodos && Texto(otraVista.Reportes.Single().Hoja, "H9") == ultimoMes,
            "La opción infirió y modificó fechas de un informe sin metadatos mensuales.");
        pasa("Último mes usa el fin contractual inclusive y respeta febrero bisiesto; sin configuración conserva fin de mes y no modifica otros informes");
    }
}
