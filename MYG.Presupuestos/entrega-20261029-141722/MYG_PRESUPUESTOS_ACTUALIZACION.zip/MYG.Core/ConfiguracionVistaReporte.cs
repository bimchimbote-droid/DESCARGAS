using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

/// <summary>Formatos de papel compartidos por la vista previa, impresión y OOXML.</summary>
public static class MYGPapelReporte
{
    private sealed record Formato(string Nombre, int CodigoExcel, decimal AnchoMm, decimal AltoMm);
    // Los códigos coinciden con pageSetup.paperSize de OOXML y PaperKind de Windows.
    private static readonly Formato[] formatos =
    {
        new("A4", 9, 210m, 297m), new("A3", 8, 297m, 420m), new("A2", 66, 420m, 594m),
        new("A5", 11, 148m, 210m), new("A6", 70, 105m, 148m),
        new("B4", 12, 250m, 353m), new("B5", 13, 176m, 250m),
        new("Carta", 1, 215.9m, 279.4m), new("Oficio", 5, 215.9m, 355.6m)
    };

    public static IReadOnlyList<string> Nombres { get; } = Array.AsReadOnly(formatos.Select(f => f.Nombre).ToArray());
    public static bool EsValido(string papel) => formatos.Any(f => f.Nombre == papel);
    private static Formato Buscar(string papel) => formatos.FirstOrDefault(f => f.Nombre == papel) ??
        throw new ArgumentException("Seleccione un tamaño de papel válido.", nameof(papel));

    public static (decimal Ancho, decimal Alto) DimensionesMm(string papel)
    {
        var formato = Buscar(papel);
        return (formato.AnchoMm, formato.AltoMm);
    }

    public static (decimal Ancho, decimal Alto) DimensionesPulgadas(string papel)
    {
        var formato = Buscar(papel);
        // Mantener la precisión de impresión y los tamaños históricos A3/A4.
        return (decimal.Round(formato.AnchoMm / 25.4m, 2), decimal.Round(formato.AltoMm / 25.4m, 2));
    }

    public static int CodigoExcel(string papel) => Buscar(papel).CodigoExcel;
    public static string DesdeCodigoExcel(int codigo) => formatos.FirstOrDefault(f => f.CodigoExcel == codigo)?.Nombre ?? "A4";
}

/// <summary>Configuración temporal de la vista previa. Conserva los datos del proyecto
/// y las dependencias de las fórmulas en instantáneas independientes.</summary>
public sealed class MYGConfiguracionVistaReporte
{
    private readonly IReadOnlyList<MYGHojaReporteProyecto> originales;
    private IReadOnlyList<MYGHojaReporteProyecto> reportes;
    private float escala = 1f;
    private int paginasDeAncho;
    private string fuenteAplicada;
    private bool fuentePendiente, coloresPendientes, fechasPendientes;
    private IReadOnlyDictionary<int, string> paletaTitulos = new Dictionary<int, string>();

    // Materializar sólo cuando se solicita el contenido para exportarlo o
    // inspeccionarlo. Cambiar opciones y capturar un trabajo no recorre celdas.
    public IReadOnlyList<MYGHojaReporteProyecto> Reportes
    {
        get { AplicarPendientes(); return reportes; }
    }
    public bool TitulosConColor { get; private set; }
    public bool MostrarFechasPeriodos { get; private set; } = true;
    public bool TieneFechasPeriodos => originales.Any(r => r.EncabezadosPeriodosSinFechas.Count > 0);

    /// <summary>Cero utiliza el porcentaje; de 1 a 10 ajusta a ese máximo de páginas de ancho.</summary>
    public int PaginasDeAncho
    {
        get => paginasDeAncho;
        set
        {
            if (value < 0 || value > 10) throw new ArgumentOutOfRangeException(nameof(value), "Indique entre 1 y 10 páginas de ancho, o cero para usar porcentaje.");
            paginasDeAncho = value;
        }
    }

    /// <summary>Escala del contenido impreso; el zoom de la vista previa es independiente.</summary>
    public float Escala
    {
        get => escala;
        set
        {
            if (!float.IsFinite(value) || value < .25f || value > 2f)
                throw new ArgumentOutOfRangeException(nameof(value), "La escala debe estar entre 25 % y 200 %.");
            escala = value;
        }
    }

    public MYGConfiguracionVistaReporte(IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        ArgumentNullException.ThrowIfNull(reportes);
        if (reportes.Count == 0 || reportes.Any(r => r == null || r.Hoja == null))
            throw new ArgumentException("Seleccione al menos un reporte válido para la vista previa.", nameof(reportes));
        originales = Copiar(reportes);
        this.reportes = Copiar(originales);
    }

    /// <summary>Aplica papel, orientación y márgenes en pulgadas a todas las hojas.
    /// Valida toda la configuración antes de cambiar cualquier hoja.</summary>
    public void ConfigurarPagina(string papel, string orientacion,
        decimal izq, decimal der, decimal sup, decimal inf)
    {
        var tamano = MYGPapelReporte.DimensionesPulgadas(papel);
        if (orientacion is not ("Vertical" or "Horizontal"))
            throw new ArgumentException("Seleccione orientación Vertical u Horizontal.", nameof(orientacion));
        if (new[] { izq, der, sup, inf }.Any(m => m < 0 || m > 3))
            throw new ArgumentOutOfRangeException(nameof(izq), "Los márgenes deben estar entre 0 y 3 pulgadas.");
        if (orientacion == "Horizontal") tamano = (tamano.Alto, tamano.Ancho);
        if (tamano.Ancho - izq - der <= .4m || tamano.Alto - sup - inf <= .5m)
            throw new ArgumentException("Los márgenes dejan un área de impresión demasiado pequeña.");
        foreach (var reporte in reportes)
        {
            var hoja = reporte.Hoja;
            hoja.TamanoPapel = papel; hoja.OrientacionPagina = orientacion;
            hoja.MargenIzquierdo = izq; hoja.MargenDerecho = der;
            hoja.MargenSuperior = sup; hoja.MargenInferior = inf;
        }
    }

    /// <summary>Cambia sólo la familia tipográfica; conserva tamaños, estilos y fórmulas.</summary>
    public void Fuente(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre) || nombre.Length > 100 || nombre.Any(char.IsControl))
            throw new ArgumentException("Seleccione una fuente válida de hasta 100 caracteres.", nameof(nombre));
        fuenteAplicada = nombre.Trim();
        fuentePendiente = true;
    }

    public void Restaurar()
    {
        var restaurados = Copiar(originales);
        reportes = restaurados;
        escala = 1f;
        paginasDeAncho = 0;
        TitulosConColor = false;
        MostrarFechasPeriodos = true;
        fuenteAplicada = null;
        fuentePendiente = coloresPendientes = fechasPendientes = false;
        paletaTitulos = new Dictionary<int, string>();
    }

    /// <summary>Aplica los colores de la estructura únicamente a sus títulos.
    /// Desactivar recupera los colores iniciales sin alterar los demás ajustes.</summary>
    public void ColorearTitulos(bool activar, Func<int, string> colorNivel = null)
    {
        if (activar) ArgumentNullException.ThrowIfNull(colorNivel);
        // Resolver y validar toda la paleta antes de cambiar las copias.
        var paleta = new Dictionary<int, string>();
        if (activar)
            foreach (int nivel in reportes.SelectMany(r => r.NivelesTitulos.Values).Distinct())
            {
                string color = colorNivel(nivel)?.Trim().TrimStart('#');
                if (color == null || color.Length != 6 || !color.All(Uri.IsHexDigit))
                    throw new ArgumentException("Indique colores de títulos RGB de seis dígitos hexadecimales.", nameof(colorNivel));
                paleta[nivel] = color.ToUpperInvariant();
            }
        paletaTitulos = paleta;
        coloresPendientes = true;
        TitulosConColor = activar;
    }

    public void LineasDivision(bool activar)
    { foreach (var reporte in reportes) reporte.Hoja.ImprimirLineasDivision = activar; }

    public void Encabezados(bool activar)
    { foreach (var reporte in reportes) reporte.Hoja.ImprimirEncabezados = activar; }

    public void RepetirTitulos(bool activar)
    { foreach (var reporte in reportes) reporte.Hoja.RepetirTitulos = activar; }

    /// <summary>Cambia sólo los rótulos de los períodos marcados por el informe.
    /// La fecha general del proyecto y los importes permanecen intactos.</summary>
    public void FechasPeriodos(bool mostrar)
    {
        MostrarFechasPeriodos = mostrar;
        fechasPendientes = true;
    }

    public string ColorOriginalTitulo(int indiceReporte, string direccion)
        => originales[indiceReporte].Hoja.Celdas.GetValueOrDefault(direccion)?.ColorTexto ?? "";

    private void AplicarPendientes()
    {
        if (!fuentePendiente && !coloresPendientes && !fechasPendientes) return;
        if (fuentePendiente)
            foreach (var reporte in reportes)
                foreach (var celda in reporte.Hoja.Celdas.Values) celda.Fuente = fuenteAplicada;
        if (coloresPendientes)
            AplicarColores(reportes, originales, TitulosConColor, paletaTitulos);
        if (fechasPendientes)
            AplicarFechasPeriodos(reportes, originales, MostrarFechasPeriodos);
        fuentePendiente = coloresPendientes = fechasPendientes = false;
    }

    private static void AplicarFechasPeriodos(IReadOnlyList<MYGHojaReporteProyecto> destino,
        IReadOnlyList<MYGHojaReporteProyecto> origen, bool mostrar)
    {
        for (int indice = 0; indice < destino.Count; indice++)
            foreach (var encabezado in origen[indice].EncabezadosPeriodosSinFechas)
                if (destino[indice].Hoja.Celdas.TryGetValue(encabezado.Key, out var celda) &&
                    origen[indice].Hoja.Celdas.TryGetValue(encabezado.Key, out var original))
                    celda.Contenido = mostrar ? original.Contenido : encabezado.Value;
    }

    private static void AplicarColores(IReadOnlyList<MYGHojaReporteProyecto> destino,
        IReadOnlyList<MYGHojaReporteProyecto> origen, bool activar, IReadOnlyDictionary<int, string> paleta)
    {
        for (int indice = 0; indice < destino.Count; indice++)
        {
            var reporte = destino[indice];
            foreach (var entrada in reporte.Hoja.Celdas)
            {
                int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
                if (!reporte.NivelesTitulos.TryGetValue(fila, out int nivel)) continue;
                entrada.Value.ColorTexto = activar ? paleta[nivel]
                    : origen[indice].Hoja.Celdas.GetValueOrDefault(entrada.Key)?.ColorTexto ?? "";
            }
        }
    }

    /// <summary>Captura únicamente los ajustes del panel; no copia celdas ni
    /// dependencias y puede crearse en el hilo de interfaz en cada cambio.</summary>
    public Solicitud CapturarSolicitud() => new(originales, reportes, fuenteAplicada,
        TitulosConColor, paletaTitulos, escala, paginasDeAncho, MostrarFechasPeriodos);

    /// <summary>Copia exacta para llamadores que modifican las hojas directamente.
    /// La actualización interactiva utiliza CapturarSolicitud en su lugar.</summary>
    public IReadOnlyList<MYGHojaReporteProyecto> CopiarReportesActuales() => Copiar(Reportes);

    public sealed class Solicitud
    {
        private sealed record Ajustes(string Papel, string Orientacion, decimal Izquierda, decimal Derecha,
            decimal Superior, decimal Inferior, bool Titulos, bool Lineas, bool Encabezados);
        private readonly IReadOnlyList<MYGHojaReporteProyecto> origen;
        private readonly Ajustes[] ajustes;
        private readonly string fuente;
        private readonly bool colorear;
        private readonly bool mostrarFechasPeriodos;
        private readonly IReadOnlyDictionary<int, string> paleta;
        public float Escala { get; }
        public int PaginasDeAncho { get; }

        internal Solicitud(IReadOnlyList<MYGHojaReporteProyecto> origen,
            IReadOnlyList<MYGHojaReporteProyecto> actuales, string fuente, bool colorear,
            IReadOnlyDictionary<int, string> paleta, float escala, int paginasDeAncho, bool mostrarFechasPeriodos)
        {
            this.origen = origen;
            ajustes = actuales.Select(r => new Ajustes(r.Hoja.TamanoPapel, r.Hoja.OrientacionPagina,
                r.Hoja.MargenIzquierdo, r.Hoja.MargenDerecho, r.Hoja.MargenSuperior, r.Hoja.MargenInferior,
                r.Hoja.RepetirTitulos, r.Hoja.ImprimirLineasDivision, r.Hoja.ImprimirEncabezados)).ToArray();
            this.fuente = fuente;
            this.colorear = colorear;
            this.mostrarFechasPeriodos = mostrarFechasPeriodos;
            this.paleta = new Dictionary<int, string>(paleta);
            Escala = escala;
            PaginasDeAncho = paginasDeAncho;
        }

        /// <summary>Materializa una instantánea independiente en el trabajador.
        /// Cambios posteriores del panel no pueden alterar este resultado.</summary>
        public IReadOnlyList<MYGHojaReporteProyecto> CrearReportes()
        {
            var resultado = Copiar(origen);
            for (int i = 0; i < resultado.Count; i++)
            {
                var h = resultado[i].Hoja; var a = ajustes[i];
                h.TamanoPapel = a.Papel; h.OrientacionPagina = a.Orientacion;
                h.MargenIzquierdo = a.Izquierda; h.MargenDerecho = a.Derecha;
                h.MargenSuperior = a.Superior; h.MargenInferior = a.Inferior;
                h.RepetirTitulos = a.Titulos; h.ImprimirLineasDivision = a.Lineas; h.ImprimirEncabezados = a.Encabezados;
                if (fuente != null) foreach (var celda in h.Celdas.Values) celda.Fuente = fuente;
            }
            if (colorear) AplicarColores(resultado, origen, true, paleta);
            AplicarFechasPeriodos(resultado, origen, mostrarFechasPeriodos);
            return resultado;
        }
    }

    /// <summary>Ajusta columnas contiguas, repitiendo la primera como identificador.
    /// Conserva todos los datos y devuelve como máximo el número de bandas solicitado.
    /// Los anchos y el espacio disponible deben usar la misma unidad.</summary>
    public static (float Escala, IReadOnlyList<int[]> Segmentos) AjustarAnchura(
        IReadOnlyList<float> anchos, float disponible, int paginas)
    {
        if (anchos == null || anchos.Count == 0 || !float.IsFinite(disponible) || disponible <= 0 ||
            anchos.Any(a => !float.IsFinite(a) || a <= 0) || paginas < 1 || paginas > 10)
            throw new ArgumentException("Indique anchos positivos, espacio disponible y entre 1 y 10 páginas.");
        double total = anchos.Sum(a => (double)a);
        if (total <= disponible) return (1, new[] { Enumerable.Range(0, anchos.Count).ToArray() });
        if (anchos.Count == 1) return ((float)(disponible / total), new[] { new[] { 0 } });

        List<int[]> Dividir(double capacidad)
        {
            var bandas = new List<int[]>();
            int siguiente = 1;
            while (siguiente < anchos.Count)
            {
                var banda = new List<int> { 0 };
                double ancho = anchos[0];
                while (siguiente < anchos.Count && ancho + anchos[siguiente] <= capacidad)
                { ancho += anchos[siguiente]; banda.Add(siguiente++); }
                if (banda.Count == 1) return null;
                bandas.Add(banda.ToArray());
            }
            return bandas;
        }
        double minimo = anchos[0] + anchos.Skip(1).Max(a => (double)a), maximo = total;
        // Busca la partición contigua de menor ancho máximo; ninguna columna se corta.
        for (int i = 0; i < 60; i++)
        {
            double medio = (minimo + maximo) / 2;
            var grupos = Dividir(medio);
            if (grupos != null && grupos.Count <= paginas) maximo = medio;
            else minimo = medio;
        }
        var segmentos = Dividir(Math.Max(disponible, maximo) + total * 1e-12);
        double mayor = segmentos.Max(s => s.Sum(c => (double)anchos[c]));
        return ((float)Math.Min(1, disponible / mayor), segmentos.AsReadOnly());
    }

    private static IReadOnlyList<MYGHojaReporteProyecto> Copiar(IReadOnlyList<MYGHojaReporteProyecto> origen)
    {
        var copias = origen.Select(r => new MYGHojaReporteProyecto(r.Titulo, MYGProyectoStorage.Copia(r.Hoja),
            r.DatosProyecto, r.EsPresupuestoObra, r.NivelesTitulos, r.EsAnalisisCostosUnitarios, r.CabeceraEnHoja,
            r.EsResumenProyecto, r.EsConsolidadoCostosUnitarios, r.EsListadoMetrados, r.EsListaInsumos,
            r.EncabezadosPeriodosSinFechas)
            { AltosMinimosFilas = new Dictionary<int, int>(r.AltosMinimosFilas) }).ToArray();
        var hojas = new Dictionary<MYGHojaMetrado, MYGHojaMetrado>(ReferenceEqualityComparer.Instance);
        for (int i = 0; i < origen.Count; i++) hojas.TryAdd(origen[i].Hoja, copias[i].Hoja);

        // Copiar una hoja conserva su contexto para evaluar METRADO. También se
        // congelan las dependencias que no aparecen entre los reportes visibles.
        var presupuestos = new Dictionary<MYGPresupuestoDocumento, MYGPresupuestoDocumento>(ReferenceEqualityComparer.Instance);
        foreach (var reporte in origen)
            foreach (var presupuesto in reporte.Hoja.ContextoReferencias?.Presupuestos ?? Array.Empty<MYGPresupuestoDocumento>())
                if (!presupuestos.ContainsKey(presupuesto)) presupuestos.Add(presupuesto, MYGProyectoStorage.Copia(presupuesto));
        MYGReferenciasMetrado.Vincular(presupuestos.Values);

        for (int n = 0; n < origen.Count; n++)
        {
            var contextoOrigen = origen[n].Hoja.ContextoReferencias;
            if (contextoOrigen == null) continue;
            var contexto = new MYGContextoReferenciasMetrado(contextoOrigen.Presupuestos.Select(p => presupuestos[p]), aislado: true);
            foreach (var presupuesto in contextoOrigen.Presupuestos)
                foreach (var partida in presupuesto.Items ?? new())
                {
                    if (partida == null) continue;
                    var hoja = contextoOrigen.Hoja(presupuesto.Id, partida.IdLocalMYG ?? partida.Id);
                    if (hoja == null || ReferenceEquals(hoja, partida.Costos?.Hoja)) continue;
                    if (!hojas.TryGetValue(hoja, out var copia)) hojas.Add(hoja, copia = MYGProyectoStorage.Copia(hoja));
                    contexto = contexto.ConHoja(copia);
                }
            // Las fórmulas entre reportes usan las copias del mismo conjunto.
            for (int i = 0; i < origen.Count; i++)
                if (origen[i].Hoja.ContextoReferencias?.Presupuestos.Any(p => contextoOrigen.Presupuestos.Contains(p)) == true)
                    contexto = contexto.ConHoja(copias[i].Hoja);
            copias[n].Hoja.ContextoReferencias = contexto;
        }
        foreach (var reporte in copias) MYGHojaCalculo.Validar(reporte.Hoja);
        return Array.AsReadOnly(copias);
    }
}
