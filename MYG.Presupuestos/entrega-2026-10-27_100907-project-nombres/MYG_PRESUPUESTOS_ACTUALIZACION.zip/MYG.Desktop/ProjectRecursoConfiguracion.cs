using System;
using System.Globalization;
using System.IO;
using System.Reflection;

namespace MYG_2027;

// Se comparte con las comprobaciones de contrato para ejercitar las mismas
// escrituras que utiliza el adaptador COM, sin necesitar una instalación Office.
internal static class MYGConfiguracionRecursoProject
{
    internal const int CampoEtiquetaMaterial = 205521195; // pjResourceMaterialLabel

    internal static string Crear(MYGRecursoExportacionProject datos, string separadorListas,
        Action<string> crear, Func<string, object> leer, Action<string, object> escribir)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(crear);
        ArgumentNullException.ThrowIfNull(leer);
        ArgumentNullException.ThrowIfNull(escribir);
        if (string.IsNullOrEmpty(separadorListas))
            throw new InvalidDataException("Microsoft Project no indicó su separador de listas para crear los recursos.");

        // Resource.Name no admite corchetes ni el separador de listas de
        // Project. Usar el de la instancia Office, no el idioma de la llamada
        // COM ni CurrentCulture. No modificar el modelo ni el nombre en MYG.
        string Adaptar(string texto) => texto.Replace('[', '(').Replace(']', ')')
            .Replace(separadorListas, separadorListas == " " ? "_" : " ", StringComparison.Ordinal);
        string original = datos.Nombre ?? "";
        string nombre = Adaptar(original);
        if (string.IsNullOrWhiteSpace(nombre))
            nombre = Adaptar("Recurso MYG " + datos.Uid.ToString(CultureInfo.InvariantCulture));
        crear(nombre);
        if (!string.Equals(Convert.ToString(leer("Name"), CultureInfo.InvariantCulture), nombre, StringComparison.Ordinal))
            throw new InvalidOperationException("Microsoft Project no conservó el nombre exportado del recurso «" + original + "».");
        if (string.Equals(nombre, original, StringComparison.Ordinal)) return null;

        // Texto1 está reservado a las unidades que Project no admite. Notas
        // conserva la descripción completa sin afectar códigos ni asignaciones.
        escribir("Notes", original);
        if (!string.Equals(Convert.ToString(leer("Notes"), CultureInfo.InvariantCulture), original, StringComparison.Ordinal))
            throw new InvalidOperationException("Microsoft Project no conservó el nombre original del recurso «" + original + "» en Notas.");
        return "Nombre del recurso «" + original + "» adaptado a «" + nombre + "» para Microsoft Project; nombre original en Notas.";
    }

    internal static string Configurar(MYGRecursoExportacionProject datos, string calendario,
        Func<string, object> leer, Action<string, object> escribir, Action<int, string> establecerCampo = null)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        ArgumentNullException.ThrowIfNull(escribir);
        // Tipo del modelo: material=0, trabajo=1. Tipo COM: trabajo=0, material=1.
        int tipo = datos.Tipo switch { 0 => 1, 1 => 0, 2 => 2,
            _ => throw new InvalidDataException("Tipo de recurso desconocido.") };
        escribir("Type", tipo);
        if (Convert.ToInt32(leer("Type"), CultureInfo.InvariantCulture) != tipo)
            throw new InvalidOperationException("Microsoft Project no aceptó el tipo del recurso «" + datos.Nombre + "».");
        escribir("Code", datos.Codigo ?? "");
        escribir("Group", datos.Grupo ?? "");
        string advertencia = datos.Tipo == 0 ? ConfigurarUnidad(datos, leer, escribir, establecerCampo) : null;
        if (datos.Tipo != 2) escribir("StandardRate", (double)datos.Tarifa);
        if (datos.Tipo == 1) escribir("BaseCalendar", calendario);
        return advertencia;
    }

    private static string ConfigurarUnidad(MYGRecursoExportacionProject datos,
        Func<string, object> leer, Action<string, object> escribir, Action<int, string> establecerCampo)
    {
        string unidad = datos.Unidad ?? "";
        bool Coincide(string campo, string esperado) => string.Equals(
            Convert.ToString(leer(campo), CultureInfo.InvariantCulture), esperado, StringComparison.Ordinal);
        void VerificarTipo()
        {
            if (Convert.ToInt32(leer("Type"), CultureInfo.InvariantCulture) != 1)
                throw new InvalidOperationException("Microsoft Project cambió el tipo material del recurso «" + datos.Nombre + "».");
        }
        // Conservar literalmente símbolos, espacios y Unicode. Algunas
        // versiones de Project rechazan etiquetas que reconocen como tiempo.
        // Intentar también la API de campo, sin prefijos ni texto invisible.
        try
        {
            escribir("MaterialLabel", unidad);
            if (Coincide("MaterialLabel", unidad)) return null;
        }
        catch (Exception ex) when (EsRechazoDeArgumento(ex)) { }
        VerificarTipo();
        if (establecerCampo != null)
        {
            try
            {
                establecerCampo(CampoEtiquetaMaterial, unidad);
                VerificarTipo();
                if (Coincide("MaterialLabel", unidad)) return null;
            }
            catch (Exception ex) when (EsRechazoDeArgumento(ex)) { }
        }
        // Si ambas rutas rechazan la etiqueta, preservar la naturaleza
        // material y la unidad de origen en un campo visible. Una etiqueta
        // vacía no cambia Units ni StandardRate ni el cálculo del costo.
        VerificarTipo();
        escribir("MaterialLabel", "");
        if (!Coincide("MaterialLabel", ""))
            throw new InvalidOperationException("Microsoft Project no pudo vaciar la etiqueta rechazada del recurso «" + datos.Nombre + "».");
        escribir("Text1", unidad);
        if (!Coincide("Text1", unidad))
            throw new InvalidOperationException("Microsoft Project no conservó la unidad original «" + unidad +
                "» del recurso «" + datos.Nombre + "» en Texto1.");
        VerificarTipo();
        return "Project no admitió «" + unidad + "» en Unidades del recurso «" + datos.Nombre +
            "»; unidad original en Texto1; cantidad, tarifa y costo conservados.";
    }

    private static bool EsRechazoDeArgumento(Exception error)
    {
        while (error is TargetInvocationException && error.InnerException != null) error = error.InnerException;
        return error.HResult is unchecked((int)0x800A044D) or unchecked((int)0x80070057);
    }
}
