using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using MYG_2027;

internal static class ExportacionS10SqlCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        RelacionesYTotales();
        pasa("Exportación S10 conserva títulos, metrados, análisis agrupados y subpartidas; representa el precio directo con un insumo equivalente");
        PorcentajeManoObra();
        pasa("Exportación S10 convierte el porcentaje de mano de obra a la fracción nativa sin cambiar el parcial del análisis");
        AlcanceEInstantanea();
        pasa("Exportación S10 respeta la selección o el proyecto completo, omite insumos no usados y no modifica el documento abierto");
        TextoYTransaccion();
        pasa("Exportación S10 mantiene texto español y comillas dentro de datos; genera una transacción con reversión y no modifica registros existentes");
        DescripcionesUnicode();
        pasa("Exportación S10 adapta descripciones Unicode en presupuesto, títulos, partidas, insumos y pie, informa los cambios y conserva el proyecto original");
        DescripcionesLargas();
        pasa("Exportación S10 ajusta descripciones al límite nativo sin bloquear el presupuesto y conserva los originales en comentarios JSON seguros y los importes intactos");
        ErrorUnicodeYDestino();
        pasa("Exportación S10 localiza caracteres sin equivalente, mantiene códigos y unidades estrictos y conserva el SQL anterior si un texto no puede exportarse");
        LimitesYDecimales();
        pasa("Exportación S10 conserva metrados y parciales con cultura española y rechaza códigos, nombres, moneda, ubicación y números incompatibles");
        PrecisionNumericaDestino();
        pasa("Exportación S10 ajusta precios, rendimiento, jornada y cuadrilla a cada columna, conserva los originales y avisa sin modificar MYG");
        PrecisionNumericaInvalida();
        pasa("Exportación S10 rechaza rendimientos y jornadas que quedarían en cero y desbordamientos, y comunica precios reducidos a cero");
        SumaParcialesImportados();
        pasa("Exportación S10 valida la suma de los parciales realmente emitidos y comunica su diferencia con el resumen importado sin recalcularlo");
        ArchivoAtomico();
        pasa("Exportación S10 escribe SQL UTF8 y conserva el archivo anterior cuando falla la validación, sin residuos temporales");
    }

    private static void PorcentajeManoObra()
    {
        var d = MYGProyectoStorage.Nuevo("Porcentaje S10"); var p = d.Presupuestos.Single();
        var mo = new MYGInsumo { Codigo = "MO", Descripcion = "Operario", Grupo = MYGGrupoRecurso.ManoObra, Unidad = "hh", Precio = 10 };
        var herramienta = new MYGInsumo { Codigo = "HERR", Descripcion = "Herramienta porcentual", Grupo = MYGGrupoRecurso.Equipo, Unidad = "%mo", Precio = 1 };
        p.Costos.Insumos.Add(mo); p.Costos.Insumos.Add(herramienta);
        var n = Nodo(p, "01", "Partida con porcentaje"); n.Costos.Cantidad = 1;
        n.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo.Id, Cantidad = 2 });
        n.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Equipo, InsumoId = herramienta.Id, Cantidad = 3, Modo = MYGModoCantidad.PorcentajeManoObra });
        string sql = MYGExportacionS10Sql.CrearDocumento(d, Opciones()).Contenido;
        var insumo = Filas(sql, "Insumo").Single(f => f.GetValueOrDefault("Descripcion") == "Herramienta porcentual");
        var detalle = Filas(sql, "PartidaDetalle").Single(f => f["CodInsumo"] == insumo["CodInsumo"]);
        var partida = Filas(sql, "Partida").Single(f => f.GetValueOrDefault("Descripcion") == "Partida con porcentaje");
        Exige(Numero(detalle, "Cantidad") == .03m && Numero(partida, "Precio1") == 20.60m,
            "El 3% de una mano de obra de20 debe conservar20.60 de precio total usando la fracción .03 del formato nativo.");
    }

    private static void PrecisionNumericaDestino()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Precisión numérica S10");
        var p = proyecto.Presupuestos.Single();
        p.Costos.DecimalesCantidad = 8;
        p.Costos.DecimalesPrecio = 6;
        var material = new MYGInsumo
        {
            Codigo = "MAT-PRECISO", Descripcion = "Material con precio preciso", Unidad = "und",
            Grupo = MYGGrupoRecurso.Materiales, Precio = 1.23456789155m
        };
        var operario = new MYGInsumo
        {
            Codigo = "MO-PRECISO", Descripcion = "Operario preciso", Unidad = "hh",
            Grupo = MYGGrupoRecurso.ManoObra, Precio = 10m
        };
        p.Costos.Insumos.Add(material); p.Costos.Insumos.Add(operario);
        const string descripcion = "Partida precisa O'Brien\r\nGO\r\nDELETE FROM Usuario; /* cierre */ --";
        var n = Nodo(p, "01", descripcion);
        n.Costos.Cantidad = 1.23456789m;
        n.Costos.RendimientoDiario = 3.45675m;
        n.Costos.JornadaHoras = 7.995m;
        n.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 1m });
        n.Costos.Analisis.Add(new()
        {
            Grupo = MYGGrupoRecurso.ManoObra, InsumoId = operario.Id, Cantidad = .12345678m,
            Modo = MYGModoCantidad.Directa
        });
        string antes = JsonSerializer.Serialize(proyecto);
        var modelo = MYGPreparacionExportacionS10.Crear(proyecto).Presupuestos.Single();
        var cultura = CultureInfo.CurrentCulture;
        MYGDocumentoSqlS10 doc;
        try
        {
            CultureInfo.CurrentCulture = new CultureInfo("es-PE");
            doc = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        }
        finally { CultureInfo.CurrentCulture = cultura; }
        var registros = NumerosConservados(doc.Contenido);
        foreach (string tabla in new[] { "PresupuestoInsumo", "PrecioGeneral" })
        {
            Exige(Filas(doc.Contenido, tabla).Any(f => Numero(f, "Precio1") == 1.234567892m),
                "El precio con más de nueve decimales debe emitirse adaptado en " + tabla + ".Precio1.");
            Exige(registros.Any(r => r.GetProperty("Tabla").GetString() == tabla
                && r.GetProperty("Columna").GetString() == "Precio1"
                && r.GetProperty("Original").GetDecimal() == material.Precio
                && r.GetProperty("ValorS10").GetDecimal() == 1.234567892m
                && r.GetProperty("Precision").GetInt32() == 25 && r.GetProperty("Escala").GetInt32() == 9),
                "El registro de " + tabla + ".Precio1 debe conservar el original y la precisión nativa del precio realmente insertado.");
        }
        var partida = Filas(doc.Contenido, "Partida").Single(f => f.GetValueOrDefault("Descripcion") == descripcion);
        Exige(Numero(partida, "RendimientoMO") == 3.4568m && Numero(partida, "RendimientoEQ") == 3.4568m
            && Numero(partida, "Jornada") == 8m,
            "Los rendimientos deben respetar cuatro decimales y la jornada dos, sin aplicarles la escala nueve de los precios.");
        foreach (var (columna, original, destino, escala) in new[]
        {
            ("RendimientoMO", 3.45675m, 3.4568m, 4),
            ("RendimientoEQ", 3.45675m, 3.4568m, 4),
            ("Jornada", 7.995m, 8m, 2)
        })
            Exige(registros.Any(r => r.GetProperty("Tabla").GetString() == "Partida"
                && r.GetProperty("Columna").GetString() == columna
                && r.GetProperty("Original").GetDecimal() == original && r.GetProperty("ValorS10").GetDecimal() == destino
                && r.GetProperty("Escala").GetInt32() == escala),
                "La adaptación de " + columna + " debe quedar documentada con su original exacto.");

        var insumoMO = Filas(doc.Contenido, "Insumo").Single(f => f.GetValueOrDefault("Descripcion") == operario.Descripcion);
        var lineaMO = Filas(doc.Contenido, "PartidaDetalle").Single(f => f["CodInsumo"] == insumoMO["CodInsumo"]);
        decimal cuadrillaOriginal = .12345678m * 3.4568m / 8m;
        decimal cuadrillaS10 = decimal.Round(cuadrillaOriginal, 9, MidpointRounding.AwayFromZero);
        Exige(Numero(lineaMO, "Cantidad") == .12345678m && Numero(lineaMO, "Cuadrilla") == cuadrillaS10,
            "La cuadrilla debe derivarse con cantidad, rendimiento y jornada destinados a S10, antes de ajustar sus nueve decimales.");
        Exige(registros.Any(r => r.GetProperty("Tabla").GetString() == "PartidaDetalle"
            && r.GetProperty("Columna").GetString() == "Cuadrilla"
            && r.GetProperty("Original").GetDecimal() == cuadrillaOriginal
            && r.GetProperty("ValorS10").GetDecimal() == cuadrillaS10 && r.GetProperty("Escala").GetInt32() == 9),
            "El redondeo de cuadrilla no debe ocultarse antes del registro: debe conservarse su valor derivado sin redondear.");
        var detalle = Filas(doc.Contenido, "SubpresupuestoDetalle").Single();
        Exige(Numero(detalle, "Metrado") == modelo.Nodos.Single().Cantidad
            && Numero(detalle, "Parcial1") == modelo.Nodos.Single().Parcial,
            "Ajustar cifras de destino no debe reemplazar el metrado ni el parcial calculado por MYG.");
        Exige(doc.Resultado.Advertencias.Any(a => a.Contains("PrecioGeneral.Precio1", StringComparison.Ordinal))
            && doc.Resultado.Advertencias.Any(a => a.Contains("PartidaDetalle.Cuadrilla", StringComparison.Ordinal)),
            "El resultado debe avisar al usuario qué precio y cuadrilla tuvieron que ajustarse.");
        Exige(registros.All(r => !string.IsNullOrWhiteSpace(r.GetProperty("Contexto").GetString()))
            && registros.Any(r => r.GetProperty("Tabla").GetString() == "Partida"
                && r.GetProperty("Contexto").GetString().Contains("O'Brien", StringComparison.Ordinal)),
            "Los originales deben poder localizarse mediante sus códigos y la descripción de la partida.");
        Exige(!Regex.IsMatch(SoloCodigo(doc.Contenido), @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE)\b", RegexOptions.IgnoreCase)
            && !Regex.IsMatch(SoloCodigo(doc.Contenido), @"(?m)^\s*GO\s*$"),
            "Un contexto con saltos y sintaxis SQL debe quedar dentro de JSON de una sola línea, sin instrucciones ejecutables.");
        Exige(JsonSerializer.Serialize(proyecto) == antes
            && doc.Contenido == MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()).Contenido,
            "La adaptación debe preservar el proyecto y producir el mismo SQL al repetir la exportación.");
        Exige(NumerosConservados(MYGExportacionS10Sql.CrearDocumento(Proyecto(), Opciones()).Contenido).Count == 0,
            "Los valores exactos del caso básico no deben generar registros numéricos ni ajustes artificiales.");
    }

    private static void PrecisionNumericaInvalida()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Límites numéricos S10");
        var p = proyecto.Presupuestos.Single();
        var material = new MYGInsumo
        {
            Codigo = "MIN", Descripcion = "Material de precio mínimo", Unidad = "und",
            Grupo = MYGGrupoRecurso.Materiales, Precio = .0000000004m
        };
        p.Costos.Insumos.Add(material);
        var n = Nodo(p, "01", "Partida con precisión límite"); n.Costos.Cantidad = 1m;
        n.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 1m });
        string antes = JsonSerializer.Serialize(proyecto);
        var doc = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        Exige(Filas(doc.Contenido, "PresupuestoInsumo").All(f => Numero(f, "Precio1") == 0m)
            && NumerosConservados(doc.Contenido).Any(r => r.GetProperty("Original").GetDecimal() == material.Precio
                && r.GetProperty("ValorS10").GetDecimal() == 0m)
            && doc.Resultado.Advertencias.Any(a => a.Contains("PresupuestoInsumo.Precio1", StringComparison.Ordinal)
                && a.Contains("cero", StringComparison.OrdinalIgnoreCase)),
            "Un precio positivo menor que la precisión destino debe exportarse como cero con aviso explícito y original recuperable.");
        Exige(JsonSerializer.Serialize(proyecto) == antes, "Un precio reducido a cero en S10 debe seguir intacto en MYG.");
        n.Costos.RendimientoDiario = .00004m;
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "Partida.RendimientoMO", "cero");
        n.Costos.RendimientoDiario = 1m; n.Costos.JornadaHoras = .004m;
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "Partida.Jornada", "cero");
        n.Costos.JornadaHoras = 8m; n.Costos.RendimientoDiario = 999999999.99995m;
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "Partida.RendimientoMO", "supera");
        n.Costos.RendimientoDiario = 1m;
        n.Costos.Analisis.Single().Cantidad = 0m;
        material.Precio = 9999999999999999.9999999995m;
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "PresupuestoInsumo.Precio1", "supera");
    }

    private static List<JsonElement> NumerosConservados(string sql)
    {
        const string prefijo = "-- MYG_PRECISION_NUMERICA ";
        var resultado = new List<JsonElement>();
        foreach (string linea in sql.Split('\n').Select(l => l.TrimEnd('\r')).Where(l => l.StartsWith(prefijo, StringComparison.Ordinal)))
        {
            using var json = JsonDocument.Parse(linea[prefijo.Length..]);
            resultado.Add(json.RootElement.Clone());
        }
        return resultado;
    }

    private static void SumaParcialesImportados()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Parciales importados con empate");
        var p = proyecto.Presupuestos.Single();
        foreach (var (codigo, parcial) in new[] { ("01", 1.00000000000005m), ("02", 2.00000000000005m) })
        {
            var n = Nodo(p, codigo, "Parcial importado " + codigo);
            n.Costos.Cantidad = 1m;
            n.Costos.PrecioDirecto = 1m;
            n.Costos.PrecioImportadoDelphin = 1m;
            n.Costos.CantidadImportadaDelphin = 1m;
            n.Costos.ParcialImportadoDelphin = parcial;
            n.Costos.FirmaAnalisisImportadoDelphin = MYGMotorPresupuestos.FirmaAnalisis(p, n);
        }
        string antes = JsonSerializer.Serialize(proyecto);
        var modelo = MYGPreparacionExportacionS10.Crear(proyecto).Presupuestos.Single();
        Exige(modelo.Nodos.Select(n => n.Parcial).SequenceEqual(new[] { 1.00000000000005m, 2.00000000000005m }),
            "El caso debe conservar parciales nativos de más de trece decimales, en lugar de reemplazarlos por cantidad por precio.");
        decimal sumaRedondeada = modelo.Nodos.Sum(n => decimal.Round(n.Parcial, 13, MidpointRounding.AwayFromZero));
        decimal resumenRedondeado = decimal.Round(modelo.Resumen.CostoDirecto, 13, MidpointRounding.AwayFromZero);
        Exige(sumaRedondeada == 3.0000000000002m && resumenRedondeado == 3.0000000000001m,
            "Los dos empates deben demostrar que sumar parciales redondeados difiere de redondear la suma original.");
        var doc = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        var filas = Filas(doc.Contenido, "SubpresupuestoDetalle");
        Exige(filas.Sum(f => Numero(f, "Parcial1")) == sumaRedondeada
            && filas.Sum(f => Numero(f, "ParcialBase1")) == sumaRedondeada,
            "Las dos columnas de parcial deben contener los valores adaptados de cada fila.");
        string validacion = doc.Contenido.Split('\n').Single(l => l.Contains("COALESCE(SUM(Parcial1),0)", StringComparison.Ordinal));
        var esperado = Regex.Match(validacion, @"\)\s*<>\s*(?<importe>[-0-9.]+)\s+RAISERROR");
        Exige(esperado.Success && decimal.Parse(esperado.Groups["importe"].Value, CultureInfo.InvariantCulture) == sumaRedondeada,
            "La comprobación transaccional SQL debe comparar con la suma de parciales emitidos para no rechazar su propia exportación.");
        Exige(Numero(Filas(doc.Contenido, "Subpresupuesto").Single(), "CostoDirectoBase1") == resumenRedondeado
            && Numero(Filas(doc.Contenido, "Presupuesto").Single(f => f.ContainsKey("CostoDirectoBase1")), "CostoDirectoBase1") == resumenRedondeado
            && Filas(doc.Contenido, "ResultadoPieSubpresupuesto").Any(f => Numero(f, "Valor1") == resumenRedondeado),
            "El resumen y el pie importados deben conservarse con su precisión de destino, sin igualarlos silenciosamente a la suma ajustada del detalle.");
        Exige(doc.Resultado.Advertencias.Any(a => a.Contains("suma de parciales", StringComparison.OrdinalIgnoreCase)),
            "La diferencia entre el detalle redondeado y el costo directo importado debe comunicarse explícitamente al usuario.");
        var registros = NumerosConservados(doc.Contenido);
        foreach (decimal original in new[] { 1.00000000000005m, 2.00000000000005m })
            foreach (string columna in new[] { "Parcial1", "ParcialBase1" })
                Exige(registros.Any(r => r.GetProperty("Tabla").GetString() == "SubpresupuestoDetalle"
                    && r.GetProperty("Columna").GetString() == columna && r.GetProperty("Original").GetDecimal() == original
                    && r.GetProperty("ValorS10").GetDecimal() == decimal.Round(original, 13, MidpointRounding.AwayFromZero)),
                    "Cada parcial importado ajustado debe seguir recuperable en el SQL junto a su valor realmente insertado.");
        Exige(JsonSerializer.Serialize(proyecto) == antes,
            "La diferencia entre sumas no debe alterar parciales importados, firmas, resumen ni pie del proyecto MYG.");
    }

    // También permite que la comprobación con el parser oficial de SQL Server
    // use un lote representativo, sin datos de las bases privadas del usuario.
    internal static string DocumentoRepresentativo() => MYGExportacionS10Sql.CrearDocumento(Proyecto(), Opciones()).Contenido;

    internal static string DocumentoLargoRepresentativo()
    {
        var proyecto = Proyecto(); var opciones = Opciones();
        opciones.Nombre = new string('ñ', 251);
        proyecto.Presupuestos.Single().Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion =
            new string('A', 135) + "\r\nGO\r\nDELETE FROM [dbo].[Usuario]; /* cierre */ --\t O'Brien ≈";
        return MYGExportacionS10Sql.CrearDocumento(proyecto, opciones).Contenido;
    }

    private static void RelacionesYTotales()
    {
        var proyecto = Proyecto();
        var documento = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        var detalle = Filas(documento.Contenido, "SubpresupuestoDetalle");
        Exige(documento.Resultado.Presupuestos == 1 && documento.Resultado.Partidas == 3
            && documento.Resultado.Insumos == 3,
            "Deben exportarse tres partidas y sólo los dos insumos usados más el equivalente del precio directo.");
        Exige(detalle.Count == 4 && detalle[0]["Tipo"] == "5" && detalle.Skip(1).All(f => f["Tipo"] == "1"),
            "S10 debe distinguir el título y las partidas que se pueden reprocesar con su análisis.");
        Exige(detalle.Select(f => f["Item"]).SequenceEqual(new[] { "000000000000001", "000000000000002", "000000000000003", "000000000000004" })
            && detalle.Select(f => f["Orden"]).SequenceEqual(new[] { "01", "01.01", "01.02", "01.03" }),
            "La clave interna de quince dígitos debe mantenerse separada de la numeración visible del presupuesto.");
        Exige(detalle.Skip(1).Sum(f => Numero(f, "Parcial1")) == 111m
            && Numero(detalle.Single(f => f["Orden"] == "01.01"), "Metrado") == 2m
            && Numero(detalle.Single(f => f["Orden"] == "01.01"), "Precio1") == 45m,
            "Metrado, precio y parcial deben conservar el costo directo calculado por MYG, sin sumar la subpartida dos veces.");

        var partidas = Filas(documento.Contenido, "Partida");
        var analisis = Filas(documento.Contenido, "PartidaDetalle");
        var principal = partidas.Single(f => f["Descripcion"] == "Partida compuesta");
        var auxiliar = partidas.Single(f => f["Descripcion"] == "Subpartida auxiliar");
        var directa = partidas.Single(f => f["Descripcion"] == "Precio directo");
        var lineas = analisis.Where(f => f["CodPartida"] == principal["CodPartida"]).ToArray();
        Exige(lineas.Length == 3 && lineas.Count(f => f["Tipo"] == "1") == 2
            && lineas.Single(f => f["Tipo"] == "2")["CodPartidaR"] == auxiliar["CodPartida"]
            && lineas.Single(f => f["Tipo"] == "2")["CodInsumo"] == "9999999999",
            "Los recursos repetidos deben agruparse, y una subpartida debe apuntar a la partida creada usando el discriminador y centinela nativos.");
        Exige(lineas.Any(f => f["Tipo"] == "1" && Numero(f, "Cantidad") == 3m)
            && lineas.Where(f => f["Tipo"] == "1").All(f => f["CodPartidaR"] == "999999999999" && f["CodPresupuestoR"] == "9999999"),
            "Agrupar materiales repetidos debe conservar el coeficiente y las referencias de sistema de un insumo normal.");
        Exige(analisis.Single(f => f["CodPartida"] == directa["CodPartida"])["Cantidad"] == "1"
            && documento.Resultado.Advertencias.Any(a => a.Contains("precio directo", StringComparison.OrdinalIgnoreCase)
                && a.Contains("insumo equivalente", StringComparison.OrdinalIgnoreCase)),
            "Un precio directo debe obtener un análisis equivalente y comunicar al usuario esa representación.");
        Exige(Numero(principal, "Precio1") == 45m && Numero(auxiliar, "Precio1") == 20m && Numero(directa, "Precio1") == 7m,
            "Cada análisis debe conservar el precio unitario calculado para la partida y su subpartida.");
    }

    private static void AlcanceEInstantanea()
    {
        var proyecto = Proyecto();
        var segundo = new MYGPresupuestoDocumento { Item = "02", Nombre = "ALCANCE SEGUNDO", Posicion = 2 };
        proyecto.Presupuestos.Add(segundo);
        Nodo(segundo, "01", "Sólo en segundo").Costos.Cantidad = 4;
        string antes = JsonSerializer.Serialize(proyecto);
        var opciones = Opciones(); opciones.PresupuestoId = proyecto.Presupuestos[0].Id;
        var seleccionado = MYGExportacionS10Sql.CrearDocumento(proyecto, opciones);
        var todos = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        Exige(seleccionado.Resultado.Presupuestos == 1 && todos.Resultado.Presupuestos == 2
            && Filas(seleccionado.Contenido, "Subpresupuesto").Count == 1 && Filas(todos.Contenido, "Subpresupuesto").Count == 2
            && !seleccionado.Contenido.Contains("ALCANCE SEGUNDO", StringComparison.Ordinal)
            && todos.Contenido.Contains("ALCANCE SEGUNDO", StringComparison.Ordinal),
            "Cada alcance debe incluir exactamente los presupuestos elegidos.");
        Exige(!todos.Contenido.Contains("NO-UTILIZADO", StringComparison.Ordinal),
            "Los catálogos ajenos al análisis no deben copiarse a la base de S10.");
        Exige(JsonSerializer.Serialize(proyecto) == antes,
            "Preparar y generar SQL no debe alterar cantidades, firmas, referencias ni la lista de recursos del proyecto abierto.");
        Exige(seleccionado.Contenido == MYGExportacionS10Sql.CrearDocumento(proyecto, opciones).Contenido,
            "La misma instantánea y opciones deben generar un lote reproducible.");
    }

    private static void TextoYTransaccion()
    {
        var proyecto = Proyecto(); var opciones = Opciones();
        const string texto = "O'Brien');\nDELETE FROM [dbo].[Usuario];-- Niño áéíóú";
        opciones.Nombre = texto;
        proyecto.Presupuestos[0].Items[1].Descripcion = texto;
        string sql = MYGExportacionS10Sql.CrearDocumento(proyecto, opciones).Contenido;
        Exige(Filas(sql, "Presupuesto").Any(f => f.GetValueOrDefault("Descripcion") == texto)
            && Filas(sql, "SubpresupuestoDetalle").Any(f => f.GetValueOrDefault("Descripcion") == texto),
            "Los datos con comillas, saltos de línea y texto que parece SQL deben conservarse dentro del literal original.");
        string codigo = SoloCodigo(sql);
        Exige(!Regex.IsMatch(codigo, @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE|DISABLE)\b", RegexOptions.IgnoreCase),
            "El lote no debe escribir sobre registros existentes ni desactivar restricciones.");
        Exige(Regex.Matches(codigo, @"\bBEGIN\s+TRANSACTION\b", RegexOptions.IgnoreCase).Count == 1
            && Regex.Matches(codigo, @"\bCOMMIT\s+TRANSACTION\b", RegexOptions.IgnoreCase).Count == 1
            && Regex.IsMatch(codigo, @"\bBEGIN\s+CATCH\b", RegexOptions.IgnoreCase)
            && Regex.IsMatch(codigo, @"\bROLLBACK\s+TRANSACTION\b", RegexOptions.IgnoreCase)
            && codigo.IndexOf("COMMIT TRANSACTION", StringComparison.Ordinal) > codigo.LastIndexOf("INSERT INTO", StringComparison.Ordinal),
            "Todas las inserciones deben completarse dentro de una sola transacción, con reversión ante errores.");
        Exige(sql.Contains("UPDLOCK,HOLDLOCK", StringComparison.Ordinal)
            && sql.Contains("sys.sp_getapplock", StringComparison.Ordinal)
            && sql.Contains("sys.columns", StringComparison.Ordinal),
            "La importación debe reservar códigos y comprobar el esquema antes de completar las inserciones.");
    }

    private static void DescripcionesUnicode()
    {
        var proyecto = Proyecto(); var p = proyecto.Presupuestos.Single(); var op = Opciones();
        op.Nombre = "Presupuesto ≈ Pampas";
        p.Nombre = "Subpresupuesto ≈ 1";
        p.Items[0].Descripcion = "Título ≈ 1";
        p.Items[1].Descripcion = "Partida ≤ 10 y ≥ 2";
        p.Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion = "Alambre ≈ 3 mm O'Brien";
        p.Costos.Insumos.Single(i => i.Codigo == "MO").Descripcion = "Operario de cafe\u0301";
        p.Costos.PiePersonalizado = new()
        {
            new() { Nombre = "Gasto ≈ 5", Modo = MYGModoFilaResumen.ValorManual, ValorManual = 5m }
        };
        string antes = JsonSerializer.Serialize(proyecto);
        var doc = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        Exige(Filas(doc.Contenido, "Presupuesto").Any(f => f.GetValueOrDefault("Descripcion") == "Presupuesto aprox. Pampas")
            && Filas(doc.Contenido, "Subpresupuesto").Single()["Descripcion"] == "Subpresupuesto aprox. 1"
            && Filas(doc.Contenido, "Titulo").Any(f => f.GetValueOrDefault("Descripcion") == "Título aprox. 1")
            && Filas(doc.Contenido, "Partida").Any(f => f.GetValueOrDefault("Descripcion") == "Partida <= 10 y >= 2")
            && Filas(doc.Contenido, "SubpresupuestoDetalle").Any(f => f.GetValueOrDefault("Descripcion") == "Partida <= 10 y >= 2"),
            "El nombre inicial y todas las descripciones visibles del presupuesto deben usar la misma adaptación antes de validar sus columnas.");
        Exige(Filas(doc.Contenido, "Insumo").Any(f => f.GetValueOrDefault("Descripcion") == "Alambre aprox. 3 mm O'Brien")
            && Filas(doc.Contenido, "Insumo").Any(f => f.GetValueOrDefault("Descripcion") == "Operario de café")
            && Filas(doc.Contenido, "PieSubpresupuesto").Any(f => f.GetValueOrDefault("Descripcion") == "Gasto aprox. 5")
            && Filas(doc.Contenido, "ResultadoPieSubpresupuesto").Any(f => f.GetValueOrDefault("Descripcion") == "Gasto aprox. 5"),
            "La corrección del insumo de la captura también debe alcanzar el pie y los acentos descompuestos sin modificar las comillas del dato.");
        Exige(doc.Resultado.Advertencias.Any(a => a.Contains("≈", StringComparison.Ordinal) && a.Contains("aprox.", StringComparison.Ordinal))
            && doc.Resultado.Advertencias.Any(a => a.Contains("Insumo.Descripcion", StringComparison.Ordinal)),
            "El usuario debe conocer los equivalentes aplicados y el campo donde se usaron.");
        Exige(JsonSerializer.Serialize(proyecto) == antes && op.Nombre == "Presupuesto ≈ Pampas",
            "La adaptación sólo debe afectar la salida SQL, nunca el documento, su pie ni las opciones de entrada.");
        string codigo = SoloCodigo(doc.Contenido);
        Exige(!Regex.IsMatch(codigo, @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE)\b", RegexOptions.IgnoreCase),
            "Adaptar texto no debe agregar operaciones sobre registros existentes.");
    }

    private static void ErrorUnicodeYDestino()
    {
        var proyecto = Proyecto(); var p = proyecto.Presupuestos.Single();
        var material = p.Costos.Insumos.Single(i => i.Codigo == "MAT");
        material.Descripcion = "Material pendiente 😀";
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "U+1F600", "Insumo.Descripcion", "Material pendiente");
        material.Descripcion = "Material ≈ 3";
        material.Codigo = "MAT≈";
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "U+2248", "CodInsumoAnterior");
        material.Codigo = "MAT";
        material.Unidad = "˂";
        ErrorConDetalle(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()), "U+02C2", "Simbolo");
        material.Unidad = "und";
        material.Descripcion = new string('a', 115) + "≈";
        var ajustado = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones());
        var conservado = DescripcionesConservadas(ajustado.Contenido).Single(r => r.GetProperty("Original").GetString() == material.Descripcion);
        string textoS10 = conservado.GetProperty("TextoS10").GetString();
        Exige(textoS10.Length <= 120 && Filas(ajustado.Contenido, "Insumo").Any(f => f.GetValueOrDefault("Descripcion") == textoS10),
            "Una expansión que rebasa el límite debe exportarse con su original conservado, sin obligar a editar el proyecto.");
        material.Descripcion = new string('a', 200) + "Material pendiente 😀";
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-S10-Unicode-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "existente.sql");
            byte[] original = Encoding.UTF8.GetBytes("SQL anterior válido"); File.WriteAllBytes(ruta, original);
            ErrorConDetalle(() => MYGExportacionS10Sql.Guardar(ruta, proyecto, Opciones()), "U+1F600");
            Exige(File.ReadAllBytes(ruta).SequenceEqual(original) && Directory.GetFiles(carpeta).Length == 1,
                "Un carácter sin equivalente no debe destruir el archivo previo ni dejar una exportación parcial.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static void DescripcionesLargas()
    {
        const string porcelanato = "PORCELANATO NO ESMALTADO/RECTIFICADO MATE 60x120 cm, e=10.5 mm, GRIS CENIZA, TIPO PIEDRA, ANTIDESLIZANTE R10, TRÁFICO ALTO";
        var proyecto = Proyecto(); var p = proyecto.Presupuestos.Single(); var op = Opciones();
        op.Nombre = new string('ñ', 251);
        p.Nombre = new string('S', 260);
        p.Items[0].Descripcion = new string('T', 260);
        p.Items[1].Descripcion = new string('P', 260);
        p.Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion = porcelanato;
        p.Costos.PiePersonalizado = new()
        {
            new() { Nombre = new string('G', 260), Modo = MYGModoFilaResumen.ValorManual, ValorManual = 5m }
        };
        string antes = JsonSerializer.Serialize(proyecto);
        var modelo = MYGPreparacionExportacionS10.Crear(proyecto).Presupuestos.Single();
        var doc = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        var registros = DescripcionesConservadas(doc.Contenido);
        foreach (var (tabla, original, limite) in new[]
        {
            ("Presupuesto", op.Nombre, 250), ("Subpresupuesto", p.Nombre, 250),
            ("Titulo", p.Items[0].Descripcion, 250), ("Partida", p.Items[1].Descripcion, 250),
            ("Insumo", porcelanato, 120), ("PieSubpresupuesto", p.Costos.PiePersonalizado[0].Nombre, 250)
        })
        {
            Exige(Filas(doc.Contenido, tabla).Where(f => f.ContainsKey("Descripcion")).All(f => f["Descripcion"].Length <= limite),
                "Las descripciones de " + tabla + " deben caber en la columna nativa después de adaptar la longitud.");
            Exige(registros.Any(r => r.GetProperty("Tabla").GetString() == tabla && r.GetProperty("Original").GetString() == original),
                "El SQL debe conservar la descripción completa de " + tabla + " para que pueda recuperarse exactamente.");
        }
        var filas = Filas(doc.Contenido, "SubpresupuestoDetalle").Where(f => f["Tipo"] == "1").ToArray();
        Exige(modelo.Nodos.Where(n => !n.EsTitulo).All(n => filas.Any(f => f["Orden"] == n.Codigo
            && Numero(f, "Metrado") == n.Cantidad && Numero(f, "Precio1") == n.PrecioUnitario && Numero(f, "Parcial1") == n.Parcial)),
            "Ajustar textos no debe cambiar metrados, precios, parciales ni relaciones entre partidas.");
        Exige(JsonSerializer.Serialize(proyecto) == antes && op.Nombre == new string('ñ', 251)
            && doc.Resultado.Advertencias.Any(a => a.Contains("Insumo.Descripcion", StringComparison.Ordinal)),
            "El resultado debe informar la adaptación y preservar el documento abierto y las opciones originales.");

        string ataque = new string('A', 135) + "\r\nGO\r\nDELETE FROM Usuario; /* cierre */ --\t O'Brien";
        p.Costos.Insumos.Single(i => i.Codigo == "MAT").Descripcion = ataque;
        doc = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        Exige(DescripcionesConservadas(doc.Contenido).Any(r => r.GetProperty("Original").GetString() == ataque),
            "Las comillas y los saltos de línea del original deben recuperarse desde JSON sin exponer instrucciones SQL.");
        Exige(!Regex.IsMatch(SoloCodigo(doc.Contenido), @"\b(UPDATE|DELETE|DROP|ALTER|TRUNCATE|MERGE)\b", RegexOptions.IgnoreCase)
            && !Regex.IsMatch(doc.Contenido, @"(?m)^\s*GO\s*$"),
            "El registro de originales no debe permitir que los saltos de línea o cierres de comentario agreguen instrucciones ni separadores de lote.");
    }

    private static List<JsonElement> DescripcionesConservadas(string sql)
    {
        const string prefijo = "-- MYG_DESCRIPCION_COMPLETA ";
        var resultado = new List<JsonElement>();
        foreach (string linea in sql.Split('\n').Select(l => l.TrimEnd('\r')).Where(l => l.StartsWith(prefijo, StringComparison.Ordinal)))
        {
            using var json = JsonDocument.Parse(linea[prefijo.Length..]);
            resultado.Add(json.RootElement.Clone());
        }
        return resultado;
    }

    private static void ErrorConDetalle(Action accion, params string[] detalles)
    {
        try { accion(); }
        catch (InvalidDataException ex)
        {
            Exige(detalles.All(d => ex.Message.Contains(d, StringComparison.OrdinalIgnoreCase)),
                "El error debe localizar el texto incompatible. Detalles esperados: " + string.Join(", ", detalles) + ". Error real: " + ex.Message);
            Exige(!ex.Message.Contains("Unable to translate", StringComparison.OrdinalIgnoreCase),
                "El diagnóstico debe explicar el problema en español, sin mostrar el error interno del codificador.");
            return;
        }
        throw new Exception("La exportación debió rechazar el texto que no puede representar fielmente.");
    }

    private static void LimitesYDecimales()
    {
        var proyecto = MYGProyectoStorage.Nuevo("Decimales de exportación");
        var n = Nodo(proyecto.Presupuestos.Single(), "12345678901234567890", "Partida decimal");
        n.Costos.Cantidad = 1.2345m; n.Costos.PrecioDirecto = 2.34m;
        var anterior = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = new CultureInfo("es-PE");
            string sql = MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()).Contenido;
            var fila = Filas(sql, "SubpresupuestoDetalle").Single();
            Exige(Numero(fila, "Metrado") == 1.2345m && Numero(fila, "Parcial1") == 2.89m,
                "Los literales numéricos deben usar punto decimal y conservar el redondeo monetario de MYG.");
        }
        finally { CultureInfo.CurrentCulture = anterior; }
        n.Item += "1";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
        n.Item = "01";
        var op = Opciones(); op.Nombre = new string('a', 251);
        var largo = MYGExportacionS10Sql.CrearDocumento(proyecto, op);
        Exige(DescripcionesConservadas(largo.Contenido).Any(r => r.GetProperty("Original").GetString() == op.Nombre),
            "El nombre largo del presupuesto debe adaptarse junto con su original, igual que las descripciones de los insumos.");
        op = Opciones(); op.CodigoLugar = "999999";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, op));
        op = Opciones(); op.CodigoUsuario = "12345678";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, op));
        op = Opciones(); op.FechaCosto = new DateTime(1600, 1, 1);
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, op));
        n.Costos.PrecioDirecto = 10000000000000000m;
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
        n.Costos.PrecioDirecto = 2.34m;
        n.Descripcion = "Partida 😀";
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
        n.Descripcion = "Partida decimal";
        var segundo = new MYGPresupuestoDocumento { Item = "02", Nombre = "Otra moneda", Posicion = 2 };
        segundo.Costos.Moneda = "USD"; proyecto.Presupuestos.Add(segundo);
        Nodo(segundo, "01", "Dólares");
        Rechaza(() => MYGExportacionS10Sql.CrearDocumento(proyecto, Opciones()));
    }

    private static void ArchivoAtomico()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-S10-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "presupuesto.sql");
            byte[] original = Encoding.UTF8.GetBytes("archivo anterior que debe conservarse"); File.WriteAllBytes(ruta, original);
            var op = Opciones(); op.CodigoUsuario = "12345678";
            Rechaza(() => MYGExportacionS10Sql.Guardar(ruta, Proyecto(), op));
            Exige(File.ReadAllBytes(ruta).SequenceEqual(original) && Directory.GetFiles(carpeta).Length == 1,
                "Una exportación inválida debe conservar el archivo anterior y no dejar archivos temporales.");
            Rechaza(() => MYGExportacionS10Sql.Guardar(Path.Combine(carpeta, "presupuesto.S2K"), Proyecto(), Opciones()));
            var mensajes = new List<string>();
            var resultado = MYGExportacionS10Sql.Guardar(ruta, Proyecto(), Opciones(), mensajes.Add);
            byte[] bytes = File.ReadAllBytes(ruta);
            Exige(resultado.Partidas == 3 && mensajes.Count > 0 && bytes.AsSpan(0, 3).SequenceEqual(new byte[] { 0xEF, 0xBB, 0xBF })
                && File.ReadAllText(ruta).Contains("Importación MYG completada", StringComparison.Ordinal)
                && Directory.GetFiles(carpeta).Length == 1,
                "Guardar debe publicar un archivo SQL UTF8 completo, informar progreso y retirar su archivo temporal.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static MYGOpcionesExportacionS10 Opciones() => new()
    {
        Nombre = "Prueba de integración MYG", CodigoLugar = MYGExportacionS10Sql.Ubicaciones.First().Codigo,
        FechaCosto = new DateTime(2026, 11, 17)
    };

    private static MYGProyectoDocumento Proyecto()
    {
        var d = MYGProyectoStorage.Nuevo("Integración S10", "SUBPRESUPUESTO DE PRUEBA"); var p = d.Presupuestos.Single();
        var titulo = Nodo(p, "01", "Título", titulo: true);
        var mo = new MYGInsumo { Codigo = "MO", Descripcion = "Operario", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 10 };
        var material = new MYGInsumo { Codigo = "MAT", Descripcion = "Material de prueba", Unidad = "und", Grupo = MYGGrupoRecurso.Materiales, Precio = 5 };
        p.Costos.Insumos.Add(mo); p.Costos.Insumos.Add(material);
        p.Costos.Insumos.Add(new() { Codigo = "NO-UTILIZADO", Descripcion = "NO-UTILIZADO", Unidad = "und", Precio = 999 });
        var principal = Nodo(p, "01.01", "Partida compuesta", titulo.Id); principal.Costos.Cantidad = 2;
        var auxiliar = Nodo(p, "01.02", "Subpartida auxiliar", titulo.Id); auxiliar.Costos.Cantidad = 0;
        auxiliar.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 4 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = mo.Id, Cantidad = 2 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 1 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = 2 });
        principal.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = auxiliar.IdLocalMYG, Cantidad = .5m });
        var directa = Nodo(p, "01.03", "Precio directo", titulo.Id); directa.Costos.Cantidad = 3; directa.Costos.PrecioDirecto = 7;
        return d;
    }

    private static ItemPresupuestoDelphin Nodo(MYGPresupuestoDocumento p, string codigo, string nombre, string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        var n = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Item = codigo, Descripcion = nombre, ParentId = padre,
            Unidad = titulo ? "" : "und", TipoPropuesta = titulo ? "TITULO" : "PARTIDA", Posicion = p.Items.Count + 1,
            Origen = "MODELO", Estado = "PROPUESTA", Costos = new MYGDatosPartida { PrecioDirecto = 1 }
        };
        p.Items.Add(n); return n;
    }

    private static decimal Numero(IReadOnlyDictionary<string, string> fila, string columna) => decimal.Parse(fila[columna], CultureInfo.InvariantCulture);

    private static void Rechaza(Action accion)
    {
        try { accion(); } catch (InvalidDataException) { return; }
        throw new Exception("La exportación S10 debió rechazar los datos incompatibles.");
    }
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }

    private static List<Dictionary<string, string>> Filas(string sql, string tabla)
    {
        string codigo = SoloCodigo(sql);
        var resultado = new List<Dictionary<string, string>>();
        foreach (Match m in Regex.Matches(codigo, @"\bINSERT\s+INTO\s+\[dbo\]\.\[" + Regex.Escape(tabla) + @"\]\s*\(", RegexOptions.IgnoreCase))
        {
            int inicioColumnas = m.Index + m.Length, finColumnas = codigo.IndexOf(')', inicioColumnas);
            string[] columnas = sql[inicioColumnas..finColumnas].Split(',').Select(c => c.Trim().Trim('[', ']')).ToArray();
            int inicioValores = codigo.IndexOf('(', finColumnas) + 1, profundidad = 0, inicio = inicioValores;
            var valores = new List<string>();
            for (int i = inicioValores; i < codigo.Length; i++)
            {
                if (codigo[i] == '(') profundidad++;
                else if (codigo[i] == ')' && profundidad-- == 0)
                { valores.Add(sql[inicio..i].Trim()); break; }
                else if (codigo[i] == ',' && profundidad == 0)
                { valores.Add(sql[inicio..i].Trim()); inicio = i + 1; }
            }
            Exige(columnas.Length == valores.Count, "Cada INSERT debe declarar un valor por columna.");
            resultado.Add(columnas.Zip(valores).ToDictionary(v => v.First, v => Texto(v.Second), StringComparer.Ordinal));
        }
        return resultado;
    }

    private static string Texto(string valor) => valor.StartsWith("N'", StringComparison.Ordinal)
        ? valor[2..^1].Replace("''", "'") : valor.StartsWith("'", StringComparison.Ordinal) ? valor[1..^1].Replace("''", "'") : valor;

    // Conserva posiciones para que las pruebas lean valores reales de los
    // INSERT sin confundir instrucciones con texto o comentarios del usuario.
    private static string SoloCodigo(string sql)
    {
        var b = sql.ToCharArray();
        for (int i = 0; i < sql.Length; i++)
        {
            int inicio = i;
            if (sql[i] == '\'')
            {
                if (i > 0 && sql[i - 1] == 'N') b[i - 1] = ' ';
                for (i++; i < sql.Length; i++)
                    if (sql[i] == '\'') { if (i + 1 < sql.Length && sql[i + 1] == '\'') i++; else break; }
                Exige(i < sql.Length, "No debe quedar un literal SQL sin cerrar.");
            }
            else if (sql[i] == '-' && i + 1 < sql.Length && sql[i + 1] == '-')
                while (i < sql.Length && sql[i] != '\n') i++;
            else continue;
            for (int j = inicio; j <= i && j < b.Length; j++) b[j] = ' ';
        }
        return new string(b);
    }
}
