# Colaboradores de una obra de una base privada

Base de esta entrega: `bimchimbote-droid/MYG.Presupuestos`, rama `main`, commit
`83974008e17cf37a292a75d5e18db7a49523ee46`.

## Comportamiento

El propietario de una fila «Base SQLite» puede pulsar **Elegir obra…** o
**Agregar colaborador**. También puede abrir **Colaboradores de esta obra…**
desde el menú de una obra en Inicio. Debe elegir una obra concreta.

La primera vez se prepara una copia colaborativa aislada de esa obra, se publica
y se vincula a la base privada. Después se administran sus miembros y permisos
con las opciones existentes. El colaborador actualiza «Compartidos conmigo» y
abre la entrada de tipo **Obra**.

La base completa conserva su privacidad. La obra colaborativa tiene una revisión
independiente: los cambios no se incorporan automáticamente al respaldo SQLite
original. Propietario y colaboradores deben abrir esa Obra en Nube MYG para
trabajar juntos. Volver a elegirla recupera su publicación existente y conserva
las ediciones remotas, sin reemplazarlas por la instantánea original.

Un fallo de red conserva UUID, paquete y hash localmente. Vuelva a elegir la
misma base y obra con la misma cuenta para reanudar. No borre la carpeta local
de recuperación de Nube MYG mientras haya un intento pendiente.

## Instalación manual

1. Cierre MYG y respalde o confirme los cambios locales de su repositorio.
2. Extraiga el ZIP de actualización fuera de su copia de trabajo.
3. Copie su contenido a la raíz de `MYG.Presupuestos`, conservando las rutas.
   Los archivos existentes se entregan completos: compare cambios locales o
   posteriores antes de reemplazarlos. No se elimina ningún archivo.
4. Restaure y compile con el SDK .NET 10, desde la raíz:

   ```powershell
   dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
   dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -p:UseSharedCompilation=false -m:1 -nr:false
   dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --colaboracion-obra
   ```

   La propiedad de referencias Revit permite compilar sin instalar Revit. Para
   usar el conector real se sigue necesitando Windows y Revit 2027.
5. En Windows, compruebe el flujo visual con una base de prueba de dos obras:
   cancelar la selección no debe publicar nada; compartir una obra no debe
   mostrar la base ni la otra obra al colaborador. Compruebe lector, editor,
   permisos por módulo, retirada de acceso y recuperación tras reconectar.
6. Ejecute las pruebas de interfaz en Windows:

   ```powershell
   dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
   ```

## Configuración

No se añaden paquetes ni se cambian proyectos o lockfiles. No se incluye una
migración nueva. El servidor debe tener las migraciones existentes de nube,
incluidas `20261030_archivos_sqlite.sql`, `20261101_bases_obras.sql` y los permisos
por módulo que ya utilice su instalación. La comprobación de capacidades informa
si falta soporte de bases/obras; esta entrega no ejecuta SQL en producción.

## Validación realizada

- SDK .NET 10.0.100, Linux x64, SQLite real y HTTP simulado.
- Solución completa Release: 0 errores y 0 advertencias.
- Nueva prueba `--colaboracion-obra`: 206 comprobaciones correctas. Incluye
  aislamiento de dos obras, integridad del origen, permisos, cancelación,
  paquete alterado y recuperación en tres ventanas de fallo sin sobrescribir
  ediciones remotas.
- Pruebas existentes `--bases-obras`: aprobadas.
- Baseline del entorno: 810 comprobaciones Core y 21 del preparador CLI aprobadas.
- Pruebas UI nuevas: compiladas, no ejecutadas en Linux.
- La suite completa de Nube ya fallaba antes del cambio en
  `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`: el escenario caduca
  la sesión durante la consulta de estado, pero espera que el error se atribuya
  a la creación posterior. Es un desajuste previo de la prueba, independiente
  de colaboradores; no se ha modificado ni ocultado.
- No se ejecutaron Windows Forms, Revit, licencia real ni servicios de producción.
  Core omite Named Pipes de Windows y las muestras privadas opcionales ausentes.

## Revisión y publicación del código

En Visual Studio, abra **Cambios de Git**, revise los archivos, compile y ejecute
las comprobaciones de Windows. Haga Commit y luego Push en su rama de trabajo
cuando haya validado la actualización. Verifique la rama y el commit en GitHub.
Publicar el ZIP en DESCARGAS no actualiza la rama `main` del código ni aplica
los cambios a su equipo.
