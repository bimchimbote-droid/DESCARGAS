using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class NubeBaseUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var sesion = new SesionDesktop();
        using var nube = new NubeForm(sesion, null);
        var tabla = Campo<DataGridView>(nube, "propios");
        exige(tabla.Columns.Contains("Tamano") && tabla.Columns["Tamano"].HeaderText == "Tamaño en nube",
            "La lista debe mostrar el tamaño junto a cada proyecto.");
        exige(tabla.Columns.Contains("Tipo") && tabla.Columns["Tipo"].HeaderText == "Tipo"
            && tabla.Columns["Tipo"].DisplayIndex == 1,
            "La lista debe distinguir el tipo de entrada junto al nombre del proyecto.");
        var basePrivada = new ProyectoNube(Guid.NewGuid(), "MYG-BASE", "Base privada", "propietario", 1,
            "base", default) { TamanoBytes = 1536 * 1024 };
        int fila = tabla.Rows.Add(basePrivada.Nombre, basePrivada.Codigo, basePrivada.Rol, 1, "1,50 MiB");
        tabla.Rows[fila].Tag = basePrivada;
        tabla.CurrentCell = tabla.Rows[fila].Cells[0];
        Llamar(nube, "CambioSeleccion");
        exige(!Propiedad<bool>(nube, "PuedeAdministrar"),
            "Ni el propietario debe administrar miembros de la base completa.");
        exige(Campo<Label>(nube, "detalle").Text.Contains("1", StringComparison.Ordinal)
            && Campo<Label>(nube, "detalle").Text.Contains("MiB", StringComparison.Ordinal)
            && Campo<Label>(nube, "detalle").Text.Contains("mismo archivo SQLite", StringComparison.Ordinal),
            "Seleccionar la base debe informar que todas sus obras usan el mismo archivo SQLite.");
        exige(!Campo<Button>(nube, "colaboracion").Enabled && !Campo<Button>(nube, "compartirUsuario").Enabled,
            "La base privada no debe ofrecer acciones para conceder acceso completo.");
        try
        {
            ((Task)Llamar(nube, "CargarColaboracionAsync")).GetAwaiter().GetResult();
            throw new InvalidOperationException("Se permitió consultar colaboración de la base.");
        }
        catch (InvalidOperationException ex)
        {
            exige(ex.Message.Contains("base completa es privada", StringComparison.Ordinal),
                "La ruta programática también debe impedir administrar la base antes de consultar la red.");
        }
        tabla.Rows[fila].Tag = basePrivada with { Alcance = "obra" };
        exige(Propiedad<bool>(nube, "PuedeAdministrar"),
            "Las obras independientes deben conservar administración de colaboradores para el propietario.");
        VerificarSeleccionObraColaboracion(exige);
        VerificarDialogoSeleccionObra(exige);

        using var publicar = new NubePublicarForm(null, null);
        var modo = Campo<ComboBox>(publicar, "modo");
        modo.SelectedIndex = 2;
        exige(publicar.Alcance == "base" && modo.Items.Count == 3,
            "Todos los modos deben publicar una sola base completa, sin ofrecer obras aisladas.");
        exige(Campo<ListBox>(publicar, "proyectos").SelectionMode == SelectionMode.None,
            "La lista de obras debe ser informativa y no recortar el alcance del archivo.");
        exige(Campo<CheckBox>(publicar, "confirmarBase").Text.Contains("una sola base SQLite", StringComparison.Ordinal),
            "La confirmación debe explicar que se publica un único archivo con todas sus obras.");
        exige(Campo<Label>(publicar, "explicacion").Text.Contains("original se conserva", StringComparison.Ordinal),
            "La publicación debe indicar que conserva el archivo original.");
        VerificarInicio(sesion, exige);
    }

    private static void VerificarSeleccionObraColaboracion(Action<bool, string> exige)
    {
        const string servidor = "https://colaboracion-base-ui.supabase.co";
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion,
            new CredencialMYG { Usuario = "propietario_ui" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
        var basePrivada = new ProyectoNube(Guid.NewGuid(), "MYG-BASE", "Base privada", "propietario", 1, "base", default);
        var obra = new ProyectoNube(Guid.NewGuid(), "MYG-OBRA", "Obra elegida", "propietario", 1, "obra", default);
        using var transporte = new ColaboracionSintetica(basePrivada, obra);
        using var cliente = new ClienteSupabase(servidor, "sb_publishable_ui_sintetica", transporte);
        cliente.IniciarSesionMygAsync(new TicketNubeMYG(
            "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwcm9waWV0YXJpb191aSJ9.firma_solo_pruebas",
            "propietario_ui", servidor, DateTimeOffset.UtcNow.AddMinutes(1))).GetAwaiter().GetResult();
        using var nube = new NubeForm(sesion, cliente);
        var tabla = Campo<DataGridView>(nube, "propios");
        int fila = tabla.Rows.Add(basePrivada.Nombre, basePrivada.Codigo, basePrivada.Rol, basePrivada.Revision);
        tabla.Rows[fila].Tag = basePrivada;
        tabla.CurrentCell = tabla.Rows[fila].Cells[0];
        Llamar(nube, "CambioSeleccion");
        exige(!Campo<Button>(nube, "colaboracion").Enabled && !Campo<Button>(nube, "compartirUsuario").Enabled,
            "Con identidad válida, la base debe exigir una ruta de selección de obra antes de habilitar colaboración.");

        int elecciones = 0;
        Func<ProyectoNube, Task<ProyectoNube>> cancelar = origen =>
        {
            elecciones++;
            exige(origen.Id == basePrivada.Id && origen.Alcance == "base",
                "El selector debe recibir la base elegida, sin convertirla en una obra compartible.");
            return Task.FromResult<ProyectoNube>(null);
        };
        nube.ElegirObraColaboracionSolicitado += cancelar;
        Llamar(nube, "ActualizarAcciones");
        exige(Campo<Button>(nube, "colaboracion").Enabled
            && Campo<Button>(nube, "colaboracion").Text == "Elegir obra…"
            && Campo<Button>(nube, "compartirUsuario").Enabled
            && !Propiedad<bool>(nube, "PuedeAdministrar"),
            "El propietario puede elegir una obra desde la base, sin habilitar administración de la base completa.");
        exige(!Campo<Button>(nube, "aceptar").Enabled && !Campo<Button>(nube, "cambiarRol").Enabled
            && !Campo<Button>(nube, "permisosMiembro").Enabled,
            "Elegir obra no debe habilitar cambios de miembros ni permisos para la base privada.");
        tabla.Rows[fila].Tag = basePrivada with { Rol = "administrador" };
        Llamar(nube, "CambioSeleccion");
        exige(!Campo<Button>(nube, "colaboracion").Enabled && !Campo<Button>(nube, "compartirUsuario").Enabled
            && !Propiedad<bool>(nube, "PuedeAdministrar"),
            "La ruta desde una base privada debe estar reservada a su propietario aunque exista un selector de obra.");
        tabla.Rows[fila].Tag = basePrivada;
        Llamar(nube, "CambioSeleccion");
        ((Task)Llamar(nube, "CargarColaboracionAsync")).GetAwaiter().GetResult();
        Campo<TextBox>(nube, "usuarioColaborador").Text = "colaborador_ui";
        ((Task)Llamar(nube, "CompartirUsuarioAsync")).GetAwaiter().GetResult();
        exige(elecciones == 2 && transporte.Rpc.Count == 0
            && Propiedad<ProyectoNube>(nube, "Seleccionado").Id == basePrivada.Id,
            "Cancelar cualquiera de las dos rutas debe conservar la base seleccionada sin consultar ni compartir la base.");
        nube.ElegirObraColaboracionSolicitado -= cancelar;

        Func<ProyectoNube, Task<ProyectoNube>> elegir = _ => Task.FromResult(obra);
        nube.ElegirObraColaboracionSolicitado += elegir;
        ((Task)Llamar(nube, "CargarColaboracionAsync")).GetAwaiter().GetResult();
        exige(Propiedad<ProyectoNube>(nube, "Seleccionado").Id == obra.Id
            && Propiedad<bool>(nube, "PuedeAdministrar")
            && Campo<Guid?>(nube, "proyectoColaboracion") == obra.Id,
            "Elegir una obra debe seleccionarla y cargar sus colaboradores con sus propios permisos.");
        exige(transporte.Rpc.Contains("myg_nube_miembros") && transporte.Rpc.Contains("myg_nube_solicitudes")
            && !transporte.Rpc.Any(rpc => rpc.Contains("compartir", StringComparison.Ordinal)),
            "La ruta desde la base debe consultar solo miembros de la obra y nunca conceder acceso a la base completa.");

        foreach (var actualizada in new[]
        {
            obra with { EliminacionPendiente = true },
            obra with { Rol = "lector" }
        })
        {
            transporte.ObraActual = actualizada;
            foreach (string accion in new[] { "CargarColaboracionAsync", "CompartirUsuarioAsync" })
            {
                Campo<TabControl>(nube, "paginas").SelectedIndex = 0;
                tabla.CurrentCell = tabla.Rows.Cast<DataGridViewRow>()
                    .Single(r => r.Tag is ProyectoNube p && p.Id == basePrivada.Id).Cells[0];
                Llamar(nube, "CambioSeleccion");
                transporte.Rpc.Clear();
                bool rechazada = false;
                try { ((Task)Llamar(nube, accion)).GetAwaiter().GetResult(); }
                catch (InvalidOperationException) { rechazada = true; }
                exige(rechazada && transporte.Rpc.SequenceEqual(new[] { "myg_nube_listar" })
                    && Campo<Guid?>(nube, "proyectoColaboracion") is null,
                    "Si la obra cambia de rol o queda en eliminación al actualizar la lista, "
                    + accion + " debe rechazarla antes de consultar miembros o conceder acceso.");
            }
        }
    }

    private static void VerificarDialogoSeleccionObra(Action<bool, string> exige)
    {
        var obras = new[]
        {
            new MYGProyectoResumen { Id = "obra-norte", Nombre = "Obra con nombre repetido" },
            new MYGProyectoResumen { Id = "obra-sur", Nombre = "Obra con nombre repetido" }
        };
        var publicada = new ProyectoNube(Guid.NewGuid(), "MYG-OBRA", obras[1].Nombre, "propietario", 7, "obra", default);
        var publicadas = new[] { new ObraBaseNube(publicada, obras[1].Id) };
        using (var elegir = new ElegirObraColaboracionForm("Base privada", obras, publicadas))
        {
            var lista = Campo<ListBox>(elegir, "obras");
            var aceptar = Controles(elegir).OfType<Button>().Single(b => b.Name == "confirmarObraColaboracion");
            exige(lista.SelectedIndex == -1 && elegir.DocumentoId is null && !aceptar.Enabled
                && ReferenceEquals(elegir.AcceptButton, aceptar),
                "El selector debe exigir una elección explícita y no aceptar con Enter una obra predeterminada.");
            lista.SelectedIndex = 1;
            exige(aceptar.Enabled && elegir.DocumentoId == obras[1].Id,
                "Elegir una obra debe habilitar la confirmación y conservar su ID aunque el nombre se repita.");
            lista.SelectedIndex = -1;
            exige(!aceptar.Enabled && elegir.DocumentoId is null,
                "Quitar la selección debe volver a impedir la confirmación.");
            string aviso = string.Join(" ", Controles(elegir).OfType<Label>().Select(l => l.Text));
            exige(aviso.Contains("otras obras seguirán privadas", StringComparison.Ordinal)
                && aviso.Contains("propia revisión", StringComparison.Ordinal)
                && aviso.Contains("no se incorporan automáticamente a la base original", StringComparison.Ordinal)
                && aviso.Contains("abra esa Obra desde Nube MYG", StringComparison.Ordinal),
                "Antes de confirmar debe explicarse la privacidad de la base, la revisión independiente "
                + "y dónde abrir la copia para colaborar.");
        }
        using (var elegir = new ElegirObraColaboracionForm("Base privada", obras, publicadas, obras[1].Id))
        {
            var lista = Campo<ListBox>(elegir, "obras");
            exige(lista.SelectedIndex == 1 && elegir.DocumentoId == obras[1].Id
                && Controles(elegir).OfType<Button>().Single(b => b.Name == "confirmarObraColaboracion").Enabled,
                "Abrir colaboración desde una obra debe preseleccionar exactamente su ID, sin confundir nombres repetidos.");
            exige(!lista.Items[0].ToString().Contains("colaboración existente", StringComparison.Ordinal)
                && lista.Items[1].ToString().Contains("colaboración existente", StringComparison.Ordinal),
                "La colaboración existente debe identificarse por la obra original y no por su nombre visible.");
        }
        using (var elegir = new ElegirObraColaboracionForm("Base privada", obras, publicadas, "obra-ausente"))
            exige(elegir.DocumentoId is null
                && !Controles(elegir).OfType<Button>().Single(b => b.Name == "confirmarObraColaboracion").Enabled,
                "Una obra que ya no está en la lista no debe sustituirse silenciosamente por otra al preseleccionar.");
    }

    private static void VerificarInicio(SesionDesktop sesion, Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Indice-Nube-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "trabajo.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Obra Norte");
            var sur = MYGProyectoStorage.Nuevo("Obra Sur");
            MYGProyectoStorage.Guardar(ruta, norte); MYGProyectoStorage.Guardar(ruta, sur);
            byte[] original = File.ReadAllBytes(ruta);
            using var cliente = new ClienteSupabase("https://bases-ui.supabase.co", "sb_publishable_ui_sintetica", new AccesoSintetico());
            cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica").GetAwaiter().GetResult();
            var proyecto = new ProyectoNube(Guid.NewGuid(), "MYG-BASE", "Base de dos obras", "propietario", 3, "base", default);
            var remoto = new ProyectoSqliteNube(proyecto, norte.Id,
                new ArchivoSqliteNube("archivo-sintetico.sqlite", Convert.ToHexString(SHA256.HashData(original)), original.Length));
            CopiaSqliteNube.Vincular(ruta, remoto, cliente);
            using var inicio = new InicioForm(sesion);
            var lista = MYGBaseDatos.ListarProyectos(ruta);
            Poner(inicio, "rutaBase", ruta);
            Poner(inicio, "datos", lista);
            Llamar(inicio, "MostrarProyectos");
            var tabla = Campo<DataGridView>(inicio, "proyectos");
            exige(tabla.Columns["NUBE_OBRA"] is DataGridViewButtonColumn boton
                && boton.Text == "⋮" && boton.UseColumnTextForButtonValue,
                "Cada obra de Inicio debe conservar su botón de apertura.");
            exige(tabla.Rows.Count == 2 && tabla.Rows.Cast<DataGridViewRow>()
                .Select(r => ((MYGProyectoResumen)r.Tag).Id).ToHashSet().SetEquals(new[] { norte.Id, sur.Id }),
                "La lista local de la base descargada debe mostrar todas sus obras originales.");
            exige(tabla.Rows.Cast<DataGridViewRow>().All(r => r.Cells["NUBE_ESTADO"].Value.ToString().Contains("r3", StringComparison.Ordinal)),
                "Todas las obras deben mostrar la misma revisión de la base SQLite.");
            Llamar(inicio, "ExigirBaseLocalEditable");
            exige(File.ReadAllBytes(ruta).SequenceEqual(original),
                "Vincular y mostrar la lista no debe reescribir el archivo SQLite descargado.");
            VerificarMenuObra(inicio, sesion, tabla, exige);
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static void VerificarMenuObra(InicioForm inicio, SesionDesktop sesion,
        DataGridView tabla, Action<bool, string> exige)
    {
        bool autorizado = sesion.Autorizado;
        try
        {
            // Mostrar con la sesión sin autorizar evita una recarga de la base
            // sintética. Las acciones de esta prueba son locales y no usan red.
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, false);
            inicio.Show(); Application.DoEvents();
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
            Campo<Panel>(inicio, "contenido").Enabled = true;
            var componentes = Campo<Container>(inicio, "componentesMenusInicio");

            ContextMenuStrip AbrirMenuReal()
            {
                Llamar(inicio, "MenuObraNube", tabla,
                    new DataGridViewCellEventArgs(tabla.Columns["NUBE_OBRA"].Index, 0));
                return componentes.Components.OfType<ContextMenuStrip>().Single();
            }

            var menu = AbrirMenuReal();
            exige(menu.Visible && menu.Items[0].Text == "Abrir obra",
                "El botón de la obra debe mostrar el menú real registrado en Inicio.");
            ToolStripDropDownClosingEventHandler cancelar = (_, e) => e.Cancel = true;
            menu.Closing += cancelar;
            menu.Close(ToolStripDropDownCloseReason.CloseCalled);
            Application.DoEvents();
            exige(menu.Visible && !menu.IsDisposed && componentes.Components.Cast<IComponent>().Contains(menu),
                "Cancelar Closing debe conservar el menú visible y registrado, sin programar su liberación.");
            menu.Closing -= cancelar;
            bool vivoDuranteClosed = false;
            int cierres = 0;
            menu.Closed += (_, _) => { cierres++; vivoDuranteClosed = !menu.IsDisposed; };
            menu.Close(ToolStripDropDownCloseReason.CloseCalled);
            exige(vivoDuranteClosed && cierres == 1 && !menu.IsDisposed,
                "El menú debe seguir vivo durante Closed y al volver de Close: WinForms aún está terminando su cierre.");
            Application.DoEvents();
            exige(menu.IsDisposed && !componentes.Components.Cast<IComponent>().Contains(menu),
                "El siguiente ciclo de Inicio debe liberar y desregistrar el menú cerrado.");

            int ejecuciones = 0;
            bool dentroDelClick = false, ejecutoDentroDelClick = false;
            var menuAccion = new ContextMenuStrip();
            var opcion = menuAccion.Items.Add("Acción local de apertura");
            opcion.Click += (_, _) =>
            {
                dentroDelClick = true;
                Llamar(inicio, "EjecutarDesdeMenuObraNube", (Func<Task>)(() =>
                {
                    ejecuciones++; ejecutoDentroDelClick |= dentroDelClick;
                    return Task.CompletedTask;
                }));
                dentroDelClick = false;
            };
            Llamar(inicio, "MostrarMenuObraNube", menuAccion);
            opcion.PerformClick();
            menuAccion.Close(ToolStripDropDownCloseReason.ItemClicked);
            exige(ejecuciones == 0,
                "Seleccionar una acción debe volver del clic y cerrar el desplegable antes de comenzar la operación.");
            Application.DoEvents(); Application.DoEvents();
            exige(ejecuciones == 1 && !ejecutoDentroDelClick && menuAccion.IsDisposed,
                "La operación debe ejecutarse exactamente una vez en el siguiente ciclo y el menú debe quedar liberado.");

            var abiertoAlCerrar = AbrirMenuReal();
            int accionesTrasCerrar = 0;
            Llamar(inicio, "EjecutarDesdeMenuObraNube", (Func<Task>)(() =>
            { accionesTrasCerrar++; return Task.CompletedTask; }));
            inicio.Close();
            exige(inicio.IsDisposed && abiertoAlCerrar.IsDisposed,
                "Cerrar Inicio con un desplegable abierto debe liberar también el menú que todavía no emitió Closed.");
            Application.DoEvents();
            exige(accionesTrasCerrar == 0,
                "Una acción pendiente no debe abrir una obra ni procesar controles después de cerrar Inicio.");
        }
        finally
        {
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, autorizado);
        }
    }

    private sealed class AccesoSintetico : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            if (solicitud.RequestUri!.AbsolutePath != "/auth/v1/token")
                throw new InvalidOperationException("La prueba de lista local no debe consultar obras en la red.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonSerializer.Serialize(new { access_token = "acceso_ui",
                    refresh_token = "refresco_ui", expires_in = 3600,
                    user = new { id = "11111111-1111-4111-8111-111111111111" } }), Encoding.UTF8, "application/json")
            });
        }
    }

    private sealed class ColaboracionSintetica(ProyectoNube basePrivada, ProyectoNube obra) : HttpMessageHandler
    {
        public List<string> Rpc { get; } = new();
        public ProyectoNube ObraActual { get; set; } = obra;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/functions/v1/myg-login")
                return Json(new { access_token = "acceso_ui", refresh_token = "refresco_ui", expires_in = 3600,
                    user = new { id = "11111111-1111-4111-8111-111111111111" }, usuario_myg = "propietario_ui" });
            string rpc = ruta.Split('/').Last();
            Rpc.Add(rpc);
            if (rpc == "myg_nube_listar") return Json(new[] { Metadatos(basePrivada), Metadatos(ObraActual) });
            if (rpc is not ("myg_nube_miembros" or "myg_nube_solicitudes"))
                throw new InvalidOperationException("La selección de obra no debe enviar operaciones de compartir ni administrar la base.");
            using var cuerpo = JsonDocument.Parse(await solicitud.Content.ReadAsStringAsync(ct));
            if (cuerpo.RootElement.GetProperty("p_id").GetGuid() != ObraActual.Id)
                throw new InvalidOperationException("La colaboración debe consultar exclusivamente la obra elegida.");
            return Json(Array.Empty<object>());
        }

        private static object Metadatos(ProyectoNube proyecto) => new
        {
            id = proyecto.Id, codigo = proyecto.Codigo, nombre = proyecto.Nombre,
            rol = proyecto.Rol, revision = proyecto.Revision, alcance = proyecto.Alcance,
            eliminacion_pendiente = proyecto.EliminacionPendiente
        };

        private static HttpResponseMessage Json(object valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }

    private static IEnumerable<Control> Controles(Control raiz)
    {
        foreach (Control control in raiz.Controls)
        {
            yield return control;
            foreach (var descendiente in Controles(control)) yield return descendiente;
        }
    }

    private static void RechazaIndice(Func<object> accion, Action<bool, string> exige, string operacion)
    {
        try
        {
            object resultado = accion();
            if (resultado is Task tarea) tarea.GetAwaiter().GetResult();
            exige(false, operacion + " no debe editar el índice privado.");
        }
        catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException)
        {
            exige(ex.InnerException.Message.Contains("índice privado", StringComparison.Ordinal),
                operacion + " debe informar la restricción del índice privado.");
        }
        catch (InvalidOperationException ex)
        {
            exige(ex.Message.Contains("índice privado", StringComparison.Ordinal),
                operacion + " debe informar la restricción del índice privado.");
        }
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static T Propiedad<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetProperty(nombre, Privados).GetValue(objeto);
    private static void Poner(object objeto, string nombre, object valor) =>
        objeto.GetType().GetField(nombre, Privados).SetValue(objeto, valor);
    private static object Llamar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);
}
