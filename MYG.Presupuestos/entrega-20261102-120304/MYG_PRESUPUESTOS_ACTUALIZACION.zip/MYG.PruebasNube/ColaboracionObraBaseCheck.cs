using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Compartir una obra de una base privada con SQLite real y servidor HTTP simulado.</summary>
internal static class ColaboracionObraBaseCheck
{
    private const string Servidor = "https://colaboracion-obra.supabase.co";
    private const string Clave = "sb_publishable_colaboracion_obra_sintetica";
    private static readonly Guid Usuario = Guid.Parse("6358bb10-35eb-493d-a97a-fb7e4702fd05");
    private static readonly Guid Base = Guid.Parse("5c612c76-2fea-4473-a95f-04dd89a92e70");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string temporal = Path.Combine(Path.GetTempPath(), "MYG-Colaboracion-Obra-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temporal);
        try
        {
            await PublicarSoloElegida(temporal);
            foreach (var fallo in new[] { Fallo.AntesDeCrear, Fallo.DespuesDeCrear, Fallo.DespuesDeVincular })
                await ReanudarSinSobrescribir(temporal, fallo);
            await ReutilizarVinculoExistente(temporal);
            await PaqueteAlterado(temporal);
            await CuentaPermisosYCancelacion(temporal);
            Console.WriteLine($"OK Colaboración por obra: {comprobaciones} comprobaciones de aislamiento SQLite, base privada, recuperación durable, permisos y cancelación; HTTP simulado, sin red ni GUI.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(temporal, true); }
    }

    private static async Task PublicarSoloElegida(string temporal)
    {
        var datos = PrepararBase(temporal, "aislamiento");
        string original = Hash(datos.Ruta);
        using var http = new Transporte(datos.Norte, datos.Sur);
        using var cliente = await Conectar(http);
        var servicio = Servicio(datos.Carpeta);
        var resultado = await servicio.PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id);
        Exige(resultado.DocumentoId == datos.Norte.Id && resultado.Proyecto.Alcance == "obra"
            && resultado.Proyecto.Id != Base && resultado.Proyecto.Rol == "propietario",
            "la colaboración debe tener una identidad propia y alcance obra.");
        Exige(http.Creaciones == 1 && http.IntentosCrear.Count == 1 && http.Vinculaciones == 1,
            "debe crear y vincular exactamente una obra.");
        Exige(http.Vinculada && http.DocumentoPublicado == datos.Norte.Id,
            "el vínculo confirmado no corresponde al documento elegido.");
        Exige(Hash(datos.Ruta) == original && MYGBaseDatos.ListarProyectos(datos.Ruta).Count == 2,
            "la preparación debe conservar sin cambios la base de dos obras.");
        Exige(MYGBaseDatos.LeerProyecto(datos.Ruta, datos.Sur.Id).Nombre == datos.Sur.Nombre,
            "compartir la obra norte cambió su vecina privada.");
    }

    private static async Task ReanudarSinSobrescribir(string temporal, Fallo fallo)
    {
        var datos = PrepararBase(temporal, fallo.ToString());
        using var http = new Transporte(datos.Norte, datos.Sur) { FallarUnaVez = fallo };
        using var cliente = await Conectar(http);
        var error = await Rechaza<NubeException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id));
        Exige(error.EsErrorDeConexion && http.IntentosCrear.Count == 1,
            "el fallo simulado debe conservar una publicación recuperable.");
        Guid idOriginal = http.IdObra;
        string contenidoOriginal = http.IntentosCrear[0];
        var archivosAntes = Directory.EnumerateFiles(Path.Combine(datos.Carpeta, "pendientes"), "*", SearchOption.AllDirectories)
            .Where(p => !p.EndsWith(".lock", StringComparison.Ordinal)).ToDictionary(p => p, Hash);
        Exige(archivosAntes.Count >= 2, "el intento y su paquete deben persistir antes de recibir el ACK.");

        // Una edición local posterior no puede sustituir los bytes congelados con el mismo UUID.
        var editada = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(datos.Ruta, datos.Norte.Id);
        editada.Nombre = "Edición local posterior al fallo";
        editada.Presupuestos[0].Items[0].Costos.Cantidad = 987.65m;
        MYGProyectoStorage.Guardar(datos.Ruta, editada);
        string origenAntesReintento = Hash(datos.Ruta);
        if (fallo != Fallo.AntesDeCrear)
        {
            http.Revision = 7;
            http.NombreRemoto = "Edición remota del colaborador";
        }

        // Reabrir el servicio reproduce un reinicio del programa sin estado en memoria.
        var recuperada = await Servicio(datos.Carpeta).PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id);
        Exige(recuperada.Proyecto.Id == idOriginal && recuperada.DocumentoId == datos.Norte.Id,
            "el reintento no debe crear otra identidad para la misma obra.");
        Exige(http.Creaciones == 1 && http.Vinculada,
            "reanudar debe dejar una sola obra remota vinculada.");
        Exige(http.IntentosCrear.All(c => c == contenidoOriginal),
            "el reintento debe conservar los bytes del paquete preparado, aunque cambie el origen.");
        Exige(Hash(datos.Ruta) == origenAntesReintento,
            "reanudar no debe modificar el archivo de trabajo.");
        if (fallo == Fallo.AntesDeCrear)
            Exige(http.IntentosCrear.Count == 2, "un envío no recibido debe poder repetirse con el paquete durable.");
        else
            Exige(http.IntentosCrear.Count == 1 && recuperada.Proyecto.Revision == 7
                && recuperada.Proyecto.Nombre == http.NombreRemoto,
                "una obra ya creada o vinculada debe conservar sus ediciones remotas sin reenviar la instantánea.");
        Exige(fallo != Fallo.DespuesDeVincular || http.Vinculaciones == 1,
            "un ACK perdido del vínculo debe recuperarse consultando, sin repetir la asociación.");
    }

    private static async Task ReutilizarVinculoExistente(string temporal)
    {
        var datos = PrepararBase(temporal, "existente");
        using var http = new Transporte(datos.Norte, datos.Sur)
        { IdObra = Guid.NewGuid(), Creada = true, Vinculada = true, Revision = 9, NombreRemoto = "Obra editada en nube" };
        using var cliente = await Conectar(http);
        var resultado = await Servicio(datos.Carpeta).PrepararYEnviarAsync(cliente, Base,
            Path.Combine(datos.Carpeta, "archivo-ya-no-disponible.sqlite"), datos.Norte.Id);
        Exige(resultado.Proyecto.Id == http.IdObra && resultado.Proyecto.Revision == 9,
            "debe recuperar el vínculo confirmado aun si la copia local ya no está disponible.");
        Exige(http.Creaciones == 0 && http.IntentosCrear.Count == 0 && http.Vinculaciones == 0,
            "consultar una obra existente no debe crear, publicar ni modificar su vínculo.");
    }

    private static async Task CuentaPermisosYCancelacion(string temporal)
    {
        var datos = PrepararBase(temporal, "permisos");
        using var http = new Transporte(datos.Norte, datos.Sur);
        using var cliente = await Conectar(http);
        using var cancelacion = new CancellationTokenSource();
        cancelacion.Cancel();
        int antes = http.Peticiones;
        await Rechaza<OperationCanceledException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id, cancelacion.Token));
        Exige(http.Peticiones == antes && http.Creaciones == 0,
            "cancelar antes de empezar no debe enviar datos ni consultar el servidor.");
        await Rechaza<ArgumentException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Guid.Empty, datos.Ruta, datos.Norte.Id));
        await Rechaza<ArgumentException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, " " + datos.Norte.Id));
        Exige(http.Peticiones == antes, "las identidades inválidas deben rechazarse sin consultar la red.");

        using var otraHttp = new Transporte(datos.Norte, datos.Sur)
        { UsuarioSesion = Guid.Parse("6e346bda-e9f5-44a6-84cc-c8a1538ac9bc") };
        using var otraCuenta = await Conectar(otraHttp);
        antes = otraHttp.Peticiones;
        var error = await Rechaza<NubeException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(otraCuenta, Base, datos.Ruta, datos.Norte.Id));
        Exige(error.NecesitaIniciarSesion && otraHttp.Peticiones == antes,
            "un almacén de otra cuenta debe rechazarse antes de cualquier RPC.");

        using var otroServidorHttp = new Transporte(datos.Norte, datos.Sur);
        using var otroServidor = await Conectar(otroServidorHttp, "https://otro-servidor.supabase.co");
        antes = otroServidorHttp.Peticiones;
        error = await Rechaza<NubeException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(otroServidor, Base, datos.Ruta, datos.Norte.Id));
        Exige(error.NecesitaIniciarSesion && otroServidorHttp.Peticiones == antes,
            "el mismo usuario de otro servidor no puede enviar el intento.");

        http.RolBase = "editor";
        error = await Rechaza<NubeException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id));
        Exige(error.AccesoDenegado && http.IntentosCrear.Count == 0 && http.Vinculaciones == 0,
            "un editor de la base no puede publicar obras ni conceder acceso.");
        http.RolBase = "propietario";
        await Rechaza<InvalidDataException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, "documento-inexistente"));
        Exige(http.IntentosCrear.Count == 0 && http.Vinculaciones == 0,
            "un documento ajeno al archivo no debe publicarse.");
        Exige(MYGBaseDatos.ListarProyectos(datos.Ruta).Count == 2,
            "los rechazos de cuenta, permisos o documento deben conservar las obras locales.");
    }

    private static async Task PaqueteAlterado(string temporal)
    {
        var datos = PrepararBase(temporal, "integridad");
        using var http = new Transporte(datos.Norte, datos.Sur) { FallarUnaVez = Fallo.AntesDeCrear };
        using var cliente = await Conectar(http);
        await Rechaza<NubeException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id));
        string paquete = Directory.EnumerateFiles(Path.Combine(datos.Carpeta, "pendientes"), "p-*.json",
            SearchOption.AllDirectories).Single();
        File.AppendAllText(paquete, " ");
        string alterado = Hash(paquete), origen = Hash(datos.Ruta);
        await Rechaza<InvalidDataException>(() => Servicio(datos.Carpeta)
            .PrepararYEnviarAsync(cliente, Base, datos.Ruta, datos.Norte.Id));
        Exige(http.IntentosCrear.Count == 1 && http.Creaciones == 0 && http.Vinculaciones == 0,
            "un paquete alterado no debe enviarse con el UUID del intento original.");
        Exige(Hash(paquete) == alterado && Hash(datos.Ruta) == origen,
            "rechazar un paquete alterado debe conservar sus archivos para recuperación y el origen intacto.");
    }

    private static PublicacionObraBasePendiente Servicio(string carpeta) =>
        new(Path.Combine(carpeta, "pendientes"), Servidor, Usuario.ToString("D"));

    private static async Task<ClienteSupabase> Conectar(Transporte http, string servidor = Servidor)
    {
        var cliente = new ClienteSupabase(servidor, Clave, http);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        return cliente;
    }

    private sealed record Datos(string Carpeta, string Ruta, MYGProyectoDocumento Norte, MYGProyectoDocumento Sur);

    private static Datos PrepararBase(string temporal, string nombre)
    {
        string carpeta = Path.Combine(temporal, nombre);
        Directory.CreateDirectory(carpeta);
        string ruta = Path.Combine(carpeta, "dos-obras.sqlite");
        var norte = CrearObra("Obra norte compartible " + nombre, 12.5m);
        var sur = CrearObra("Obra sur privada " + nombre, 81.25m);
        MYGProyectoStorage.Guardar(ruta, norte);
        MYGProyectoStorage.Guardar(ruta, sur);
        return new(carpeta, ruta, norte, sur);
    }

    private static MYGProyectoDocumento CrearObra(string nombre, decimal cantidad)
    {
        var documento = MYGProyectoStorage.Nuevo(nombre, "Presupuesto " + nombre);
        string id = MYGProyectoStorage.NuevoId();
        documento.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, TipoPropuesta = "PARTIDA", Posicion = 1,
            Descripcion = "Partida " + nombre, Unidad = "m³", Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = cantidad, PrecioDirecto = 27.35m }
        });
        return documento;
    }

    private static string Hash(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }

    private static async Task<T> Rechaza<T>(Func<Task> accion) where T : Exception
    {
        try { await accion(); }
        catch (T error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Colaboración por obra: faltó el rechazo esperado " + typeof(T).Name + ".");
    }

    private static void Exige(bool valor, string detalle)
    { comprobaciones++; if (!valor) throw new InvalidOperationException("Colaboración por obra: " + detalle); }

    private enum Fallo { Ninguno, AntesDeCrear, DespuesDeCrear, DespuesDeVincular }

    private sealed class Transporte(MYGProyectoDocumento norte, MYGProyectoDocumento sur) : HttpMessageHandler
    {
        internal Guid UsuarioSesion = Usuario, IdObra;
        internal string RolBase = "propietario", NombreRemoto = norte.Nombre;
        internal bool Creada, Vinculada;
        internal long Revision = 1;
        internal int Peticiones, Creaciones, Vinculaciones;
        internal Fallo FallarUnaVez;
        internal string? DocumentoPublicado;
        internal readonly List<string> IntentosCrear = new();

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            Peticiones++;
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = UsuarioSesion } });
            Exige(solicitud.Headers.Authorization?.Scheme == "Bearer" && solicitud.Headers.Contains("apikey"),
                "una operación perdió la cuenta autenticada.");
            Exige(ruta.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal),
                "compartir una obra no debe transferir el archivo SQLite privado ni usar Storage.");
            using var json = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(ct),
                new JsonDocumentOptions { MaxDepth = 128 });
            var p = json.RootElement;
            string rpc = ruta.Split('/').Last();
            switch (rpc)
            {
                case "myg_nube_listar":
                {
                    var lista = new List<object> { new { id = Base, codigo = "MYG-BASE-PRIVADA", nombre = "Base privada",
                        rol = RolBase, revision = 1, alcance = "base" } };
                    if (Creada) lista.Add(DescriptorProyecto());
                    return Json(lista);
                }
                case "myg_nube_bases_capacidades": return Json(new { version = 1 });
                case "myg_nube_capacidades": return Json(new { paquete_compacto = 2, cambios = 1,
                    max_contenido_mib = 300, publicacion_ligera = 1, publicacion_comprimida = 0 });
                case "myg_nube_base_obras_listar":
                    Exige(p.GetProperty("p_base").GetGuid() == Base,
                        "se consultaron obras de una base distinta.");
                    return Json(Vinculada ? new[] { DescriptorVinculo() } : Array.Empty<object>());
                case "myg_nube_estado_publicacion":
                    if (IdObra != Guid.Empty) Exige(p.GetProperty("p_id").GetGuid() == IdObra,
                        "el reintento cambió la identidad preparada.");
                    return Json(new { estado = Creada ? "existente" : "disponible" });
                case "myg_nube_crear_confirmacion":
                {
                    Guid id = p.GetProperty("p_id").GetGuid();
                    Exige(id != Base && (IdObra == Guid.Empty || id == IdObra),
                        "la obra necesita un UUID propio que debe mantenerse al reintentar.");
                    IdObra = id;
                    Exige(p.GetProperty("p_alcance").GetString() == "obra",
                        "se intentó compartir la base completa.");
                    string paquete = p.GetProperty("p_contenido").GetRawText();
                    IntentosCrear.Add(paquete);
                    Exige(IntentosCrear.All(c => c == paquete), "los reintentos cambiaron el payload preparado.");
                    var contenido = FormatoPaqueteNube.Expandir(p.GetProperty("p_contenido"));
                    var obra = PaqueteNube.LeerDocumento(contenido);
                    Exige(contenido.GetProperty("alcance").GetString() == "obra"
                        && contenido.GetProperty("documentos").GetArrayLength() == 1
                        && obra.Id == norte.Id && obra.Nombre == norte.Nombre
                        && obra.Presupuestos[0].Items[0].Costos.Cantidad == 12.5m,
                        "el paquete no conserva exactamente la obra elegida antes de los reintentos.");
                    Exige(!contenido.GetRawText().Contains(sur.Id, StringComparison.Ordinal)
                        && !contenido.GetRawText().Contains(sur.Nombre, StringComparison.Ordinal),
                        "el paquete de colaboración filtró otra obra privada de la base.");
                    Exige(!Vinculada && !Creada,
                        "una obra que ya existe no debe volver a crearse ni recibir la instantánea inicial.");
                    if (FallarUnaVez == Fallo.AntesDeCrear)
                    { FallarUnaVez = Fallo.Ninguno; throw new HttpRequestException("Envío sintético interrumpido antes de crear."); }
                    Creada = true; Creaciones++; DocumentoPublicado = obra.Id;
                    if (FallarUnaVez == Fallo.DespuesDeCrear)
                    { FallarUnaVez = Fallo.Ninguno; throw new HttpRequestException("ACK sintético perdido después de crear."); }
                    return Json(DescriptorProyecto());
                }
                case "myg_nube_base_obra_vincular":
                    Exige(Creada && p.GetProperty("p_base").GetGuid() == Base
                        && p.GetProperty("p_obra").GetGuid() == IdObra
                        && p.GetProperty("p_documento").GetString() == norte.Id,
                        "se vinculó otra obra o se concedió acceso a la identidad de la base.");
                    Vinculaciones++; Vinculada = true;
                    if (FallarUnaVez == Fallo.DespuesDeVincular)
                    { FallarUnaVez = Fallo.Ninguno; throw new HttpRequestException("ACK sintético perdido después de vincular."); }
                    return Json(DescriptorVinculo());
                default: throw new InvalidOperationException("Colaboración por obra: RPC inesperada " + rpc
                    + "; no se permite compartir, alterar ni publicar de nuevo la base privada.");
            }
        }

        private object DescriptorProyecto() => new
        { id = IdObra, codigo = "MYG-OBRA-QA", nombre = NombreRemoto, rol = "propietario", revision = Revision, alcance = "obra" };
        private object DescriptorVinculo() => new
        { base_id = Base, id = IdObra, codigo = "MYG-OBRA-QA", nombre = NombreRemoto,
            rol = "propietario", revision = Revision, alcance = "obra", documento_id = norte.Id };
        private static HttpResponseMessage Json(object valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
