using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace MYG.Colaboracion;

/// <summary>
/// Publica únicamente la obra elegida de una base privada. Conserva sus bytes y
/// UUID antes de enviar datos; volver a elegir la obra recupera el mismo intento.
/// La obra independiente no sustituye ni reescribe el respaldo SQLite de la base.
/// </summary>
public sealed class PublicacionObraBasePendiente
{
    private const long MaxBytesContenido = 300L * 1024 * 1024;
    private static readonly JsonSerializerOptions Json = new()
    {
        MaxDepth = 128,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };
    private readonly string carpeta, servidor, usuario, ambito;
    private sealed record Intento(Guid BaseId, string DocumentoId, Guid ObraId,
        string Nombre, string Sha256, long Bytes);

    public PublicacionObraBasePendiente(string carpeta, string servidor, string usuario)
    {
        if (string.IsNullOrWhiteSpace(carpeta))
            throw new ArgumentException("Indique la carpeta de publicaciones de obras.", nameof(carpeta));
        if (!Uri.TryCreate(servidor, UriKind.Absolute, out var destino)
            || destino.Scheme != Uri.UriSchemeHttps || destino.UserInfo.Length != 0
            || destino.AbsolutePath != "/" || destino.Query.Length != 0 || destino.Fragment.Length != 0)
            throw new ArgumentException("Indique el servidor HTTPS de nube sin credenciales ni rutas.", nameof(servidor));
        if (!Guid.TryParse(usuario, out var identidad) || identidad == Guid.Empty)
            throw new ArgumentException("Indique la identidad de la cuenta de nube.", nameof(usuario));
        this.carpeta = Path.GetFullPath(carpeta);
        this.servidor = destino.GetLeftPart(UriPartial.Authority);
        this.usuario = identidad.ToString("D");
        ambito = HashTexto(this.servidor.ToLowerInvariant() + "\n" + this.usuario);
    }

    public async Task<ObraBaseNube> PrepararYEnviarAsync(ClienteSupabase cliente, Guid baseId,
        string rutaSQLite, string documentoId, CancellationToken ct = default,
        IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(cliente);
        if (baseId == Guid.Empty || !DocumentoValido(documentoId))
            throw new ArgumentException("Seleccione una base y una obra con identidades válidas.");
        ValidarCuenta(cliente);
        ct.ThrowIfCancellationRequested();

        // Ni los nombres de obras ni sus IDs se utilizan como rutas de disco.
        string directorio = Path.Combine(carpeta, "o-" + HashTexto(ambito + "\n" + baseId.ToString("D") + "\n" + documentoId));
        Directory.CreateDirectory(directorio);
        using var bloqueo = new FileStream(Path.Combine(directorio, "intento.lock"),
            FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);

        var proyectos = await cliente.ListarProyectosAsync(ct);
        ValidarCuenta(cliente);
        var baseRemota = proyectos.SingleOrDefault(p => p.Id == baseId);
        if (baseRemota is not { Alcance: "base", Rol: "propietario", EliminacionPendiente: false })
            throw new NubeException("Solo el propietario de una base disponible puede preparar sus obras para colaboración.", accesoDenegado: true);

        var vinculadas = await cliente.ListarObrasBaseAsync(baseId, ct);
        ValidarCuenta(cliente);
        var existente = vinculadas.SingleOrDefault(o => o.DocumentoId == documentoId);
        if (existente is not null)
        {
            ValidarObra(existente, documentoId);
            // No leer la base, recrear la publicación ni reenviar la instantánea:
            // la obra ya puede contener ediciones de sus colaboradores.
            progreso?.Report("Recuperando la colaboración existente de la obra…");
            return existente;
        }

        string metadata = Path.Combine(directorio, "intento.json");
        var intento = File.Exists(metadata)
            ? LeerIntento(metadata, baseId, documentoId)
            : PrepararIntento(metadata, directorio, baseId, rutaSQLite, documentoId, ct, progreso);
        ct.ThrowIfCancellationRequested();
        ValidarCuenta(cliente);

        var publicada = proyectos.SingleOrDefault(p => p.Id == intento.ObraId);
        if (publicada is not null)
        {
            if (publicada is not { Alcance: "obra", Rol: "propietario", EliminacionPendiente: false }
                || publicada.TamanoFormato == "sqlite")
                throw new NubeException("El identificador pendiente corresponde a otra clase de publicación. Se conservan sus archivos; no se modificó la nube.");
            // El ACK de creación puede haberse perdido. La identidad quedó
            // congelada antes de subir; vincularla no restablece su contenido.
            progreso?.Report("Recuperando la obra publicada sin sustituir sus cambios…");
        }
        else
        {
            using var contenido = LeerContenido(directorio, intento);
            ct.ThrowIfCancellationRequested();
            ValidarCuenta(cliente);
            progreso?.Report("Publicando únicamente la obra seleccionada…");
            publicada = await cliente.CrearProyectoConfirmacionAsync(intento.ObraId,
                intento.Nombre, contenido.RootElement, "obra", ct, progreso);
            ValidarCuenta(cliente);
            if (publicada.Id != intento.ObraId || publicada.Alcance != "obra" || publicada.Rol != "propietario")
                throw new NubeException("La confirmación no corresponde a la obra pendiente. Se conserva el intento local.");
        }

        ct.ThrowIfCancellationRequested();
        try
        {
            var vinculada = await cliente.VincularObraBaseAsync(baseId, intento.ObraId, documentoId, ct);
            ValidarCuenta(cliente);
            ValidarObra(vinculada, documentoId);
            return vinculada;
        }
        catch (NubeException error) when (error.Codigo == "22023")
        {
            // Otro equipo pudo vincular esta misma obra durante la preparación.
            // Reutilizar el vínculo confirmado nunca concede acceso al respaldo.
            ValidarCuenta(cliente);
            var actuales = await cliente.ListarObrasBaseAsync(baseId, ct);
            ValidarCuenta(cliente);
            var confirmada = actuales.SingleOrDefault(o => o.DocumentoId == documentoId);
            if (confirmada is null) throw;
            ValidarObra(confirmada, documentoId);
            return confirmada;
        }
    }

    private static Intento PrepararIntento(string metadata, string directorio, Guid baseId,
        string rutaSQLite, string documentoId, CancellationToken ct, IProgress<string>? progreso)
    {
        if (string.IsNullOrWhiteSpace(rutaSQLite) || !File.Exists(rutaSQLite))
            throw new FileNotFoundException("Abra la base SQLite antes de preparar la obra para colaboración.");
        progreso?.Report("Preparando una copia aislada de la obra seleccionada…");
        var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(rutaSQLite, documentoId);
        if (documento.Id != documentoId)
            throw new InvalidDataException("El documento leído no corresponde a la obra seleccionada.");
        string nombre = documento.Nombre?.Trim() ?? "";
        if (!NombreValido(nombre))
            throw new InvalidDataException("La obra necesita un nombre de hasta 2000 caracteres sin saltos de línea. Corríjalo en sus datos antes de publicar.");
        ct.ThrowIfCancellationRequested();
        var contenido = PaqueteNube.CrearContenido(documento, rutaSQLite, "obra", compacto: true);
        ct.ThrowIfCancellationRequested();
        Guid id = Guid.NewGuid();
        string archivo = RutaContenido(directorio, id);
        using (var salida = new FileStream(archivo, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            JsonSerializer.Serialize(salida, contenido, Json);
            salida.Flush(true);
        }
        long bytes = new FileInfo(archivo).Length;
        if (bytes is < 2 or > MaxBytesContenido)
            throw new InvalidDataException("El paquete de la obra supera el límite de 300 MiB. La base original se conserva.");
        using var lectura = File.OpenRead(archivo);
        var intento = new Intento(baseId, documentoId, id, nombre,
            Convert.ToHexString(SHA256.HashData(lectura)), bytes);
        ct.ThrowIfCancellationRequested();
        string temporal = metadata + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var salida = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                JsonSerializer.Serialize(salida, intento, Json);
                salida.Flush(true);
            }
            // Desde este punto todo reintento utiliza el mismo UUID y paquete.
            File.Move(temporal, metadata);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
        return intento;
    }

    private static Intento LeerIntento(string metadata, Guid baseId, string documentoId)
    {
        if (new FileInfo(metadata).Length is < 2 or > 65536)
            throw new InvalidDataException("Los metadatos de la obra pendiente no son válidos. Se conservan sus archivos.");
        Intento intento;
        try
        {
            intento = JsonSerializer.Deserialize<Intento>(File.ReadAllBytes(metadata), Json)
                ?? throw new InvalidDataException("La obra pendiente no es legible.");
        }
        catch (JsonException error)
        {
            throw new InvalidDataException("La obra pendiente no es legible. Se conserva para recuperación.", error);
        }
        if (intento.BaseId != baseId || intento.DocumentoId != documentoId
            || intento.ObraId == Guid.Empty || intento.ObraId == baseId || !NombreValido(intento.Nombre)
            || intento.Bytes is < 2 or > MaxBytesContenido || intento.Sha256 is not { Length: 64 }
            || !intento.Sha256.All(Uri.IsHexDigit))
            throw new InvalidDataException("La identidad o integridad de la obra pendiente no es válida. No se publicará otra copia.");
        return intento;
    }

    private static JsonDocument LeerContenido(string directorio, Intento intento)
    {
        string ruta = RutaContenido(directorio, intento.ObraId);
        using var archivo = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (archivo.Length != intento.Bytes
            || !string.Equals(Convert.ToHexString(SHA256.HashData(archivo)), intento.Sha256, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("El paquete de la obra pendiente falta o cambió. No se enviarán otros bytes con el mismo identificador.");
        archivo.Position = 0;
        var contenido = JsonDocument.Parse(archivo, new JsonDocumentOptions { MaxDepth = 128 });
        try
        {
            if (!contenido.RootElement.TryGetProperty("alcance", out var alcance)
                || alcance.ValueKind != JsonValueKind.String || alcance.GetString() != "obra"
                || PaqueteNube.LeerDocumento(contenido.RootElement).Id != intento.DocumentoId)
                throw new InvalidDataException("El paquete pendiente no corresponde exclusivamente a la obra seleccionada.");
            return contenido;
        }
        catch { contenido.Dispose(); throw; }
    }

    private void ValidarCuenta(ClienteSupabase cliente)
    {
        if (!cliente.SesionIniciada
            || !string.Equals(cliente.UrlServidor.TrimEnd('/'), servidor, StringComparison.OrdinalIgnoreCase)
            || !Guid.TryParse(cliente.UsuarioId, out var identidad) || identidad.ToString("D") != usuario)
            throw new NubeException("Inicie la misma cuenta de nube que preparó esta obra.", necesitaIniciarSesion: true);
    }

    private static void ValidarObra(ObraBaseNube obra, string documentoId)
    {
        if (obra.DocumentoId != documentoId || obra.Proyecto.Alcance != "obra"
            || obra.Proyecto.Rol != "propietario" || obra.Proyecto.EliminacionPendiente)
            throw new NubeException("La obra seleccionada no está disponible para administrar su colaboración.", accesoDenegado: true);
    }

    private static bool NombreValido(string? nombre) => !string.IsNullOrWhiteSpace(nombre)
        && nombre.Length <= ClienteSupabase.MaxNombreProyectoNube && !nombre.Any(char.IsControl);
    private static bool DocumentoValido(string? id) => !string.IsNullOrWhiteSpace(id)
        && id.Length <= 200 && id == id.Trim() && !id.Any(char.IsControl);
    private static string RutaContenido(string directorio, Guid id) => Path.Combine(directorio, "p-" + id.ToString("N") + ".json");
    private static string HashTexto(string texto) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(texto)));
}
