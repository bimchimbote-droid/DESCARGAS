#nullable enable
using System.IO;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private Task<ProyectoNube?> ElegirObraColaboracionAsync(ProyectoNube basePrivada) =>
        PrepararColaboracionObraAsync(basePrivada, null);

    private async Task<ProyectoNube?> PrepararColaboracionObraAsync(ProyectoNube basePrivada, string? documentoId)
    {
        var cliente = RequerirNube();
        if (basePrivada is not { Alcance: "base", Rol: "propietario", EliminacionPendiente: false })
            throw new InvalidOperationException("Solo el propietario puede preparar una obra de su base privada.");
        var preparacion = await MYGCargaAnimada.EjecutarAsync(this, "Consultando las obras de la base…", async () =>
        {
            var publicadas = await cliente.ListarObrasBaseAsync(basePrivada.Id);
            ComprobarClienteActual(cliente);
            var remoto = await cliente.AbrirSqliteAsync(basePrivada.Id);
            ComprobarClienteActual(cliente);
            string ruta = await PrepararArchivoBaseNubeAsync(cliente, remoto);
            var lista = await Task.Run(() => MYGBaseDatos.ListarProyectos(ruta));
            ComprobarClienteActual(cliente);
            return (Ruta: ruta, Lista: lista, Publicadas: publicadas);
        });
        ComprobarClienteActual(cliente);
        using var elegir = new ElegirObraColaboracionForm(basePrivada.Nombre,
            preparacion.Lista, preparacion.Publicadas, documentoId);
        if (elegir.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return null;
        ComprobarClienteActual(cliente);
        string id = elegir.DocumentoId ?? throw new InvalidOperationException("Seleccione una obra.");
        var existente = preparacion.Publicadas.SingleOrDefault(o => o.DocumentoId == id);
        if (existente is not null) return existente.Proyecto;
        var almacen = new PublicacionObraBasePendiente(Path.Combine(CarpetaNube, "colaboracion-obras"),
            cliente.UrlServidor, cliente.UsuarioId!);
        var obra = await MYGCargaAnimada.EjecutarAsync(this, "Preparando la colaboración de la obra elegida…",
            async () =>
            {
                await PrepararPublicacionBaseAsync(preparacion.Ruta);
                ComprobarClienteActual(cliente);
                return await Task.Run(() => almacen.PrepararYEnviarAsync(cliente, basePrivada.Id, preparacion.Ruta, id));
            });
        ComprobarClienteActual(cliente);
        return obra.Proyecto;
    }
}
