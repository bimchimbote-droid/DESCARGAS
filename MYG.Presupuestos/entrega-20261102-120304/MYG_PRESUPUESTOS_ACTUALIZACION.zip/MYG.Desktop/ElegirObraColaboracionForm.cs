#nullable enable
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

internal sealed class ElegirObraColaboracionForm : WinForms.Form
{
    private readonly WinForms.ListBox obras = new() { Name = "obrasColaboracionBase", Dock = WinForms.DockStyle.Fill };
    private sealed record Opcion(string Id, string Nombre, bool Publicada)
    {
        public override string ToString() => Nombre + (Publicada ? " · colaboración existente" : "");
    }

    internal string? DocumentoId => (obras.SelectedItem as Opcion)?.Id;

    internal ElegirObraColaboracionForm(string nombreBase, IReadOnlyList<MYGProyectoResumen> lista,
        IReadOnlyList<ObraBaseNube> publicadas, string? seleccion = null)
    {
        Name = "elegirObraColaboracionBase";
        MYGProyectoUI.Preparar(this, "Colaboración de una obra", 720, 480);
        MinimumSize = new(580, 420);
        var panel = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill,
            ColumnCount = 1, RowCount = 4, Padding = new(18) };
        panel.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 38, 0, 100, 46 })
            panel.RowStyles.Add(alto == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, alto));
        panel.Controls.Add(new WinForms.Label { Text = "Elija una obra de «" + nombreBase + "»",
            Dock = WinForms.DockStyle.Fill, AutoEllipsis = true }, 0, 0);
        foreach (var obra in lista)
            obras.Items.Add(new Opcion(obra.Id, obra.Nombre, publicadas.Any(p => p.DocumentoId == obra.Id)));
        obras.SelectedIndex = -1;
        if (seleccion is not null)
            for (int i = 0; i < obras.Items.Count; i++)
                if (((Opcion)obras.Items[i]).Id == seleccion) obras.SelectedIndex = i;
        panel.Controls.Add(obras, 0, 1);
        panel.Controls.Add(new WinForms.Label { Dock = WinForms.DockStyle.Fill, Text =
            "Se preparará una copia colaborativa únicamente de la obra elegida. La base completa y sus otras obras seguirán privadas. "
            + "La copia tendrá su propia revisión: sus cambios no se incorporan automáticamente a la base original. "
            + "Para trabajar juntos, abra esa Obra desde Nube MYG. Si ya existe, se conservarán sus cambios." }, 0, 2);
        var botones = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft };
        var aceptar = MYGProyectoUI.Boton("Continuar con esta obra");
        aceptar.Name = "confirmarObraColaboracion";
        aceptar.DialogResult = WinForms.DialogResult.OK;
        aceptar.Enabled = DocumentoId is not null;
        obras.SelectedIndexChanged += (_, _) => aceptar.Enabled = DocumentoId is not null;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        botones.Controls.Add(aceptar); botones.Controls.Add(cancelar);
        panel.Controls.Add(botones, 0, 3); Controls.Add(panel);
        AcceptButton = aceptar; CancelButton = cancelar;
    }
}
