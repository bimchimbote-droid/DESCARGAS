using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class CamposTemaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;
    private const int WmKeyDown = 0x0100, WmKeyUp = 0x0101;
    private const int WmLeftButtonDown = 0x0201, WmLeftButtonUp = 0x0202;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr Enviar(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr ConsultarFecha(IntPtr ventana, int mensaje, IntPtr wParam, ref InformacionFecha informacion);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint cantidad, EntradaMouse[] entradas, int tamano);
    [DllImport("user32.dll")]
    private static extern bool GetComboBoxInfo(IntPtr ventana, ref InformacionCombo informacion);
    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr ventana, out Rectangulo rectangulo);
    [DllImport("user32.dll", EntryPoint = "SystemParametersInfoW")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ConsultarAnimacionCliente(uint accion, uint parametro,
        [MarshalAs(UnmanagedType.Bool)] out bool habilitada, uint opciones);
    private delegate bool EnumerarVentana(IntPtr ventana, IntPtr parametro);
    [DllImport("user32.dll")]
    private static extern bool EnumThreadWindows(uint hilo, EnumerarVentana enumerar, IntPtr parametro);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    private static extern IntPtr GetDC(IntPtr ventana);
    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr ventana, IntPtr dc);
    [DllImport("gdi32.dll")]
    private static extern bool BitBlt(IntPtr destino, int x, int y, int ancho, int alto,
        IntPtr origen, int origenX, int origenY, uint operacion);
    [DllImport("gdi32.dll", EntryPoint = "GetObjectW", CharSet = CharSet.Unicode)]
    private static extern int ConsultarFuenteNativa(IntPtr fuente, int tamano, out FuenteNativa descripcion);

    [StructLayout(LayoutKind.Sequential)]
    private struct Rectangulo { internal int Izquierda, Arriba, Derecha, Abajo; }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct FuenteNativa
    {
        internal int Alto, Ancho, Escapamiento, Orientacion, Peso;
        internal byte Cursiva, Subrayada, Tachada, Caracteres, PrecisionSalida, PrecisionRecorte, Calidad, Familia;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        internal string Nombre;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct EntradaMouse { internal uint Tipo; internal DatosMouse Mouse; }
    [StructLayout(LayoutKind.Sequential)]
    private struct DatosMouse
    {
        internal int X, Y;
        internal uint Datos, Opciones, Tiempo;
        internal UIntPtr InformacionExtra;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct InformacionCombo
    {
        internal int Tamano;
        internal Rectangulo Item, Boton;
        internal uint EstadoBoton;
        internal IntPtr Ventana, Edicion, Lista;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct InformacionFecha
    {
        internal int Tamano;
        internal Rectangulo Casilla;
        internal uint EstadoCasilla;
        internal Rectangulo Boton;
        internal uint EstadoBoton;
        internal IntPtr Edicion, Incremento, Calendario;
    }

    private sealed class Opcion
    {
        public string Nombre { get; init; }
        public override string ToString() => "ESTE TEXTO NO ES EL DISPLAYMEMBER";
    }

    internal static void Ejecutar(Action<bool, string> exige)
    {
        bool original = MYG2027_TemaComercial.Oscuro;
        try
        {
            FechaPaletaCheck.Ejecutar(exige);
            VerificarControles(exige);
            VerificarDatosProyecto(exige);
            VerificarDialogosConPaletaPropia(exige);
        }
        finally { CambiarTema(original); }
    }

    private static void VerificarControles(Action<bool, string> exige)
    {
        using var ventana = new Form { Text = "Campos de tema", ClientSize = new Size(560, 400) };
        var texto = new TextBox { Text = "Texto pendiente", Bounds = new Rectangle(16, 16, 300, 26) };
        var numero = new NumericUpDown { Value = 12.5m, DecimalPlaces = 2, Bounds = new Rectangle(16, 52, 300, 26) };
        var lista = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList,
            DisplayMember = nameof(Opcion.Nombre), Bounds = new Rectangle(16, 88, 300, 26) };
        lista.Items.AddRange(new object[] { new Opcion { Nombre = "Primera opción" }, new Opcion { Nombre = "Segunda opción" } });
        lista.SelectedIndex = 1;
        var editable = new ComboBox { DropDownStyle = ComboBoxStyle.DropDown,
            Bounds = new Rectangle(16, 124, 300, 26), Text = "Edición libre pendiente" };
        editable.Items.Add("Opción de lista");
        var propia = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DrawMode = DrawMode.OwnerDrawFixed,
            Bounds = new Rectangle(16, 160, 300, 26) };
        propia.Items.Add("Dibujo propio"); propia.SelectedIndex = 0;
        int dibujosPropios = 0;
        propia.DrawItem += (_, e) =>
        {
            dibujosPropios++; e.DrawBackground();
            if (e.Index >= 0) TextRenderer.DrawText(e.Graphics, propia.GetItemText(propia.Items[e.Index]),
                propia.Font, e.Bounds, e.ForeColor, TextFormatFlags.VerticalCenter);
        };
        var fecha = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy",
            Value = new DateTime(2026, 10, 27), MinDate = new DateTime(2020, 1, 1), MaxDate = new DateTime(2030, 12, 31),
            ShowCheckBox = true, Checked = false, Bounds = new Rectangle(16, 196, 300, 26) };
        var fechaTeclado = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy",
            Value = new DateTime(2026, 10, 27), ShowUpDown = true, Bounds = new Rectangle(16, 232, 300, 26) };
        ventana.Controls.AddRange(new Control[] { texto, numero, lista, editable, propia, fecha, fechaTeclado });
        ventana.Show(); Application.DoEvents();
        foreach (bool oscuro in new[] { false, true, false, true })
        {
            CambiarTema(oscuro);
            VerificarPaleta(new Control[] { texto, numero, lista, editable, propia, fecha, fechaTeclado }, exige);
            exige(texto.Text == "Texto pendiente" && numero.Value == 12.5m &&
                lista.SelectedIndex == 1 && lista.Text == "Segunda opción" &&
                editable.Text == "Edición libre pendiente" && propia.SelectedIndex == 0 &&
                fecha.Value == new DateTime(2026, 10, 27) && !fecha.Checked &&
                fecha.MinDate == new DateTime(2020, 1, 1) && fecha.MaxDate == new DateTime(2030, 12, 31),
                "Alternar el tema debe conservar textos, DisplayMember, selecciones, valores numéricos y límites/estado de las fechas.");
            exige(propia.DrawMode == DrawMode.OwnerDrawFixed,
                "El tema debe conservar el dibujo propio de los selectores de colores, fuentes y orientación.");
            propia.Refresh();
            exige(dibujosPropios > 0, "Los selectores con dibujo propio deben seguir recibiendo DrawItem.");
            if (!oscuro || SystemInformation.HighContrast) continue;
            foreach (var control in new Control[] { texto, numero, lista, editable, propia, fecha, fechaTeclado })
                VerificarFondoOscuro(control, exige);
            VerificarListaDesplegada(lista, exige);
        }

        var dinamico = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList,
            Bounds = new Rectangle(16, 268, 300, 26) };
        dinamico.Items.Add("Creado después de abrir"); dinamico.SelectedIndex = 0;
        ventana.Controls.Add(dinamico); Application.DoEvents();
        VerificarPaleta(new Control[] { dinamico }, exige);
        foreach (var control in new Control[] { lista, editable, propia, fecha, fechaTeclado, dinamico })
        {
            typeof(Control).GetMethod("RecreateHandle", Privados).Invoke(control, null);
            Application.DoEvents();
            if (!SystemInformation.HighContrast) VerificarFondoOscuro(control, exige);
        }
        exige(lista.SelectedIndex == 1 && propia.DrawMode == DrawMode.OwnerDrawFixed && !fecha.Checked &&
            fecha.Value == new DateTime(2026, 10, 27) && editable.Text == "Edición libre pendiente",
            "Recrear los controles nativos en oscuro debe conservar su edición y los estilos especializados.");

        if (!SystemInformation.HighContrast) VerificarHoverFecha(fecha, texto, exige);

        fechaTeclado.Focus(); Application.DoEvents();
        var antes = fechaTeclado.Value;
        Tecla(fechaTeclado, Keys.Right);
        if (!SystemInformation.HighContrast)
        {
            using var seleccionada = Capturar(fechaTeclado);
            exige(Pixeles(seleccionada, c => Math.Max(c.R, Math.Max(c.G, c.B)) - Math.Min(c.R, Math.Min(c.G, c.B)) > 35) > 3,
                "El selector de fecha enfocado debe mostrar el segmento seleccionado al navegar con el teclado.");
        }
        Tecla(fechaTeclado, Keys.Up);
        exige(fechaTeclado.Value != antes,
            "La fecha oscura debe conservar la edición nativa por segmentos y los controles de incremento.");
        var infoIncremento = new InformacionFecha { Tamano = Marshal.SizeOf<InformacionFecha>() };
        ConsultarFecha(fechaTeclado.Handle, 0x100E, IntPtr.Zero, ref infoIncremento);
        if (infoIncremento.Incremento != IntPtr.Zero)
        {
            exige(GetClientRect(infoIncremento.Incremento, out var botones),
                "El incremento de fecha debe conservar el área de sus botones nativos.");
            var previo = fechaTeclado.Value;
            Pulsar(infoIncremento.Incremento, (botones.Derecha - botones.Izquierda) / 2,
                Math.Max(1, (botones.Abajo - botones.Arriba) / 4));
            exige(fechaTeclado.Value != previo,
                "Pulsar el incremento nativo debe seguir editando el segmento activo de la fecha oscura.");
            if (!SystemInformation.HighContrast)
            {
                using var incrementoVisible = CapturarPantalla(infoIncremento.Incremento, exige);
                VerificarFondoOscuro(incrementoVisible, "incremento nativo de la fecha", exige);
            }
        }
        // Una captura del HWND comprueba el repintado visible después de una
        // interacción nativa, además de la ruta WM_PRINTCLIENT de DrawToBitmap.
        var informacionFecha = new InformacionFecha { Tamano = Marshal.SizeOf<InformacionFecha>() };
        ConsultarFecha(fecha.Handle, 0x100E, IntPtr.Zero, ref informacionFecha); // DTM_GETDATETIMEPICKERINFO.
        exige(informacionFecha.Casilla.Derecha > informacionFecha.Casilla.Izquierda,
            "La fecha opcional debe conservar el área nativa de su casilla.");
        int casillaX = (informacionFecha.Casilla.Izquierda + informacionFecha.Casilla.Derecha) / 2;
        int casillaY = (informacionFecha.Casilla.Arriba + informacionFecha.Casilla.Abajo) / 2;
        foreach (bool marcada in new[] { true, false })
        {
            Pulsar(fecha.Handle, casillaX, casillaY); fecha.Update(); Application.DoEvents();
            exige(fecha.Checked == marcada && fecha.Value == new DateTime(2026, 10, 27),
                "Pulsar la casilla nativa debe cambiar su estado sin alterar la fecha guardada.");
            if (!SystemInformation.HighContrast)
            {
                using var pantalla = CapturarPantalla(fecha.Handle, exige);
                VerificarFondoOscuro(pantalla, "DateTimePicker después de pulsar su casilla", exige);
            }
        }
        if (!SystemInformation.HighContrast)
        {
            using var pantalla = CapturarPantalla(fechaTeclado.Handle, exige);
            VerificarFondoOscuro(pantalla, "DateTimePicker después de editar con el teclado", exige);
        }
        fecha.Checked = true;
        if (!SystemInformation.HighContrast)
        {
            var calendario = AbrirCalendario(fecha, exige);
            VerificarCalendarioVisible(calendario, exige);
            TeclaCalendario(calendario, Keys.Escape);
            exige(!calendario.Visible && fecha.Value == new DateTime(2026, 10, 27) && fecha.Checked,
                "Escape debe cerrar el calendario oscuro sin cambiar la fecha ni la casilla.");
            VerificarCalendarioTecladoYLimites(fecha, exige);
            VerificarCalendarioZoomYAnimaciones(fecha, exige);
            VerificarCalendarioConFuentes(fecha, exige);
        }
        fecha.Checked = false;
        dinamico.Enabled = false; fecha.Enabled = false;
        if (!SystemInformation.HighContrast)
        {
            VerificarFondoOscuro(dinamico, exige); VerificarFondoOscuro(fecha, exige);
        }
        CambiarTema(false);
        exige(lista.DrawMode == DrawMode.Normal && editable.DrawMode == DrawMode.Normal &&
            propia.DrawMode == DrawMode.OwnerDrawFixed,
            "Volver al modo normal debe restaurar el dibujo original sin eliminar los DrawItem personalizados.");
        fecha.Enabled = true; fecha.Checked = true;
        Pulsar(fecha.Handle, (informacionFecha.Boton.Izquierda + informacionFecha.Boton.Derecha) / 2,
            (informacionFecha.Boton.Arriba + informacionFecha.Boton.Abajo) / 2);
        try
        {
            exige(Enviar(fecha.Handle, 0x1008, IntPtr.Zero, IntPtr.Zero) != IntPtr.Zero && BuscarCalendario() == null,
                "En modo normal y alto contraste debe seguir abriéndose el calendario de Windows.");
        }
        finally { Enviar(fecha.Handle, 0x100D, IntPtr.Zero, IntPtr.Zero); Application.DoEvents(); }
        ventana.Close();
    }

    private static void VerificarHoverFecha(DateTimePicker fecha, Control foco, Action<bool, string> exige)
    {
        var valor = fecha.Value;
        bool marcada = fecha.Checked;
        fecha.Checked = true; foco.Focus();
        int y = Math.Max(2, fecha.ClientSize.Height / 2);
        int xInicial = Math.Min(36, fecha.ClientSize.Width / 3);
        // Estabilizar el seguimiento del mouse antes de medir: no interesa
        // prohibir un primer repintado de entrada, sino el ciclo de cada píxel.
        for (int i = 0; i < 3; i++) MoverMouse(fecha, xInicial, y);
        fecha.Refresh(); Application.DoEvents();
        using var referencia = CapturarPantalla(fecha.Handle, exige);
        int invalidaciones = 0;
        InvalidateEventHandler contar = (_, _) => invalidaciones++;
        fecha.Invalidated += contar;
        try
        {
            for (int i = 0; i < 12; i++)
            {
                MoverMouse(fecha, xInicial, y);
                using var cuadro = CapturarPantalla(fecha.Handle, exige);
                VerificarFondoOscuro(cuadro, "fecha con mouse estacionario", exige);
                exige(MismoTexto(referencia, cuadro),
                    "El texto de una fecha sin foco debe mantenerse estable cuando el mouse permanece sobre sus dígitos.");
            }
            for (int i = 0; i < 24; i++)
            {
                int x = xInicial + i % Math.Max(1, Math.Min(72, fecha.ClientSize.Width - xInicial - 24));
                MoverMouse(fecha, x, y);
                if (i % 4 == 0)
                {
                    using var cuadro = CapturarPantalla(fecha.Handle, exige);
                    VerificarFondoOscuro(cuadro, "fecha al recorrer sus dígitos", exige);
                }
            }
            exige(invalidaciones < 18,
                "Recorrer los dígitos de una fecha no debe invalidar el control completo en cada mensaje WM_MOUSEMOVE.");
            exige(fecha.Value == valor && fecha.Checked,
                "Pasar el mouse sobre una fecha debe conservar su valor y su casilla opcional.");
        }
        finally { fecha.Invalidated -= contar; fecha.Checked = marcada; }
    }

    private static bool MismoTexto(Bitmap a, Bitmap b)
    {
        if (a.Size != b.Size) return false;
        int derecha = Math.Min(a.Width - 24, 140);
        for (int y = 3; y < a.Height - 3; y++)
            for (int x = Math.Min(26, derecha); x < derecha; x++)
                if (a.GetPixel(x, y).ToArgb() != b.GetPixel(x, y).ToArgb()) return false;
        return true;
    }

    private static void MoverMouse(DateTimePicker fecha, int x, int y)
    {
        Enviar(fecha.Handle, 0x0200, IntPtr.Zero, new IntPtr((x & 0xffff) | (y << 16)));
        fecha.Update(); Application.DoEvents();
    }

    private static void VerificarCalendarioConFuentes(DateTimePicker fecha, Action<bool, string> exige)
    {
        Font original = fecha.CalendarFont;
        bool marcada = fecha.Checked;
        DateTime valor = fecha.Value;
        try
        {
            foreach (float tamano in new[] { 9F, 12F, 16F })
            {
                using var fuente = new Font("Segoe UI", tamano, FontStyle.Regular);
                fecha.CalendarFont = fuente; fecha.Checked = true;
                var calendario = AbrirCalendario(fecha, exige);
                try { VerificarCalendarioVisible(calendario, exige); }
                finally
                {
                    calendario.Close(ToolStripDropDownCloseReason.AppClicked);
                    Application.DoEvents();
                    // No dejar que DateTimePicker conserve una referencia a
                    // una fuente que se libera al acabar esta iteración.
                    fecha.CalendarFont = original;
                }
            }
            exige(fecha.Value == valor,
                "Medir y ampliar el calendario para distintas fuentes debe conservar la fecha guardada.");
        }
        finally { fecha.CalendarFont = original; fecha.Checked = marcada; }
    }

    private static ToolStripDropDown BuscarCalendario()
    {
        ToolStripDropDown resultado = null;
        EnumThreadWindows(GetCurrentThreadId(), (ventana, _) =>
        {
            if (Control.FromHandle(ventana) is ToolStripDropDown { Name: "calendarioFechaPopup", Visible: true } popup)
                resultado = popup;
            return true;
        }, IntPtr.Zero);
        return resultado;
    }

    private static ToolStripDropDown AbrirCalendario(DateTimePicker fecha, Action<bool, string> exige)
    {
        var info = new InformacionFecha { Tamano = Marshal.SizeOf<InformacionFecha>() };
        ConsultarFecha(fecha.Handle, 0x100E, IntPtr.Zero, ref info);
        Pulsar(fecha.Handle, (info.Boton.Izquierda + info.Boton.Derecha) / 2,
            (info.Boton.Arriba + info.Boton.Abajo) / 2);
        Application.DoEvents();
        return CalendarioAbierto(fecha, exige);
    }

    private static ToolStripDropDown CalendarioAbierto(DateTimePicker fecha, Action<bool, string> exige)
    {
        var calendario = BuscarCalendario();
        exige(calendario != null && Enviar(fecha.Handle, 0x1008, IntPtr.Zero, IntPtr.Zero) == IntPtr.Zero,
            "En oscuro debe abrirse el calendario de la aplicación sin el desplegable nativo que quedaba vacío.");
        return calendario;
    }

    private static IEnumerable<Control> ControlesCalendario(ToolStripDropDown calendario) =>
        calendario.Items.OfType<ToolStripControlHost>().SelectMany(host =>
            new[] { host.Control }.Concat(Controles(host.Control)));

    private static Button BotonCalendario(ToolStripDropDown calendario, string nombre) =>
        ControlesCalendario(calendario).OfType<Button>().Single(b => b.Name == nombre);

    private static Button[] DiasCalendario(ToolStripDropDown calendario) =>
        ControlesCalendario(calendario).OfType<Button>().Where(b =>
            b.Name.StartsWith("calendarioFechaDia", StringComparison.Ordinal)).ToArray();

    private static void VerificarCalendarioVisible(ToolStripDropDown calendario, Action<bool, string> exige)
    {
        var dias = DiasCalendario(calendario);
        exige(dias.Length == 42 && dias.Count(d => d.Visible && !string.IsNullOrWhiteSpace(d.Text)) >= 28,
            "El calendario debe mostrar su grilla de días como botones legibles.");
        exige(!string.IsNullOrWhiteSpace(ControlesCalendario(calendario).Single(c => c.Name == "calendarioFechaMes").Text),
            "El calendario debe mostrar el nombre del mes y su año.");
        exige(calendario.AutoClose && dias.Where(d => d.Enabled).All(d =>
            d.Parent.ClientRectangle.Contains(d.Bounds) &&
            d.ClientSize.Height >= d.Font.Height &&
            DisenoProfesionalCheck.Contraste(d.ForeColor, d.BackColor) >= 4.5),
            "Los días deben caber completos y conservar texto contrastado, también con fuentes de 9, 12 y 16 puntos.");
        exige(Screen.FromHandle(calendario.Handle).WorkingArea.Contains(calendario.Bounds),
            "El calendario desplegado debe permanecer dentro del área de trabajo de su monitor.");
        // Capturar el dibujo ya visible; no forzar Refresh/DrawToBitmap antes
        // de detectar la regresión que mostraba únicamente una superficie vacía.
        using var imagen = CapturarPantalla(calendario.Handle, exige);
        VerificarFondoOscuro(imagen, "calendario de la aplicación", exige);
        exige(Pixeles(imagen, c => c.GetBrightness() > .65F) >= 40,
            "La pantalla del calendario debe contener glifos visibles, no sólo su fondo oscuro.");
    }

    private static void TeclaCalendario(ToolStripDropDown calendario, Keys tecla)
    {
        var contenido = calendario.Items.OfType<ToolStripControlHost>().Single().Control;
        var mensaje = Message.Create(contenido.Handle, WmKeyDown, new IntPtr((int)tecla), new IntPtr(1));
        if (!contenido.PreProcessMessage(ref mensaje))
            Enviar(contenido.Handle, WmKeyDown, new IntPtr((int)tecla), new IntPtr(1));
        Application.DoEvents();
    }

    private static void VerificarCalendarioTecladoYLimites(DateTimePicker fecha, Action<bool, string> exige)
    {
        DateTime original = fecha.Value, minimo = fecha.MinDate, maximo = fecha.MaxDate;
        bool marcada = fecha.Checked;
        try
        {
            DateTime conHora = new(2026, 10, 27, 14, 35, 17);
            fecha.Value = conHora; fecha.Checked = false;
            Tecla(fecha, Keys.F4);
            var calendario = CalendarioAbierto(fecha, exige);
            TeclaCalendario(calendario, Keys.PageDown);
            exige(fecha.Value == conHora && !fecha.Checked,
                "Navegar por el calendario debe conservar la fecha y la casilla hasta confirmar.");
            TeclaCalendario(calendario, Keys.Enter);
            exige(!calendario.Visible && fecha.Value == conHora.AddMonths(1) && fecha.Checked,
                "F4, AvPág e Intro deben elegir el día y conservar la hora de la fecha nativa.");

            fecha.Value = conHora; fecha.Checked = false;
            Enviar(fecha.Handle, 0x0104, new IntPtr((int)Keys.Down), new IntPtr(0x20000001)); // Alt+Abajo.
            Application.DoEvents();
            calendario = CalendarioAbierto(fecha, exige);
            TeclaCalendario(calendario, Keys.Right);
            TeclaCalendario(calendario, Keys.Escape);
            exige(!calendario.Visible && fecha.Value == conHora && !fecha.Checked,
                "Alt+Abajo y Escape deben cancelar incluso después de mover la fecha activa.");

            fecha.Value = new DateTime(2026, 10, 15, 14, 35, 17);
            fecha.MinDate = new DateTime(2026, 10, 10, 12, 0, 0);
            fecha.MaxDate = new DateTime(2026, 10, 20, 10, 0, 0);
            calendario = AbrirCalendario(fecha, exige);
            var dias = DiasCalendario(calendario);
            exige(dias.Where(b => b.Tag is DateTime d && (d.Date < fecha.MinDate.Date || d.Date > fecha.MaxDate.Date))
                    .All(b => !b.Enabled),
                "Los días fuera del rango permitido deben estar deshabilitados en el desplegable.");
            dias.Single(b => b.Tag is DateTime d && d == fecha.MaxDate.Date).PerformClick();
            Application.DoEvents();
            exige(fecha.Value == fecha.MaxDate && fecha.Checked,
                "Elegir el día máximo debe respetar también la hora exacta de MaxDate.");

            fecha.MinDate = DateTimePicker.MinimumDateTime;
            fecha.MaxDate = DateTimePicker.MaximumDateTime;
            fecha.Value = DateTime.Today.AddDays(-1).AddHours(14).AddMinutes(35);
            calendario = AbrirCalendario(fecha, exige);
            BotonCalendario(calendario, "calendarioFechaHoy").PerformClick();
            Application.DoEvents();
            exige(!calendario.Visible && fecha.Value == DateTime.Today.AddHours(14).AddMinutes(35),
                "Hoy debe confirmar la fecha actual y conservar su hora.");
        }
        finally
        {
            BuscarCalendario()?.Close(ToolStripDropDownCloseReason.AppClicked);
            fecha.MinDate = DateTimePicker.MinimumDateTime;
            fecha.MaxDate = DateTimePicker.MaximumDateTime;
            fecha.Value = original; fecha.MinDate = minimo; fecha.MaxDate = maximo; fecha.Checked = marcada;
            Application.DoEvents();
        }
    }

    private static Button[] PeriodosCalendario(ToolStripDropDown calendario) =>
        ControlesCalendario(calendario).OfType<Button>().Where(b => b.Visible &&
            b.Name.StartsWith("calendarioFechaPeriodo", StringComparison.Ordinal)).ToArray();

    private static void EsperarTransicionCalendario(ToolStripDropDown calendario, Action<bool, string> exige)
    {
        bool TransicionVisible() => !calendario.IsDisposed && ControlesCalendario(calendario)
            .Any(c => c.Name == "calendarioFechaTransicion" && c.Visible);
        if (TransicionVisible())
        {
            using var fotograma = CapturarPantalla(calendario.Handle, exige);
            VerificarFondoOscuro(fotograma, "transición del calendario", exige);
        }
        // Procesar el temporizador real: una transición bloqueada no debe
        // ocultarse forzando Refresh o sustituyendo la pintura de la ventana.
        var plazo = System.Diagnostics.Stopwatch.StartNew();
        while (TransicionVisible() && plazo.Elapsed < TimeSpan.FromSeconds(2))
        {
            Application.DoEvents();
            System.Threading.Thread.Sleep(10);
        }
        exige(!TransicionVisible(), "La transición del calendario debe terminar y devolver la interacción a su grilla.");
        if (calendario.IsDisposed || !calendario.Visible) return;
        using var imagen = CapturarPantalla(calendario.Handle, exige);
        VerificarFondoOscuro(imagen, "calendario después de animar", exige);
        exige(Pixeles(imagen, c => c.GetBrightness() > .65F) >= 40,
            "Después de animar deben seguir visibles los textos del calendario, sin dejar una superficie vacía.");
    }

    private static void VerificarCalendarioZoomYAnimaciones(DateTimePicker fecha, Action<bool, string> exige)
    {
        DateTime original = fecha.Value, minimo = fecha.MinDate, maximo = fecha.MaxDate;
        bool marcada = fecha.Checked;
        MYGCalendarioFechaPopup calendarioConEvento = null;
        int confirmaciones = 0;
        Action<DateTime> contar = _ => confirmaciones++;
        try
        {
            fecha.MinDate = new DateTime(1900, 1, 1);
            fecha.MaxDate = new DateTime(2199, 12, 31);
            DateTime conHora = new(2026, 10, 27, 14, 35, 17);
            fecha.Value = conHora; fecha.Checked = false;
            var calendario = AbrirCalendario(fecha, exige);
            calendarioConEvento = (MYGCalendarioFechaPopup)calendario;
            calendarioConEvento.FechaElegida += contar;

            Subir();
            var periodos = PeriodosCalendario(calendario);
            exige(periodos.Length == 12 && periodos.All(b => b.Tag is MYGPeriodoFecha p &&
                    p.Inicio.Year == 2026 && p.Inicio.Day == 1) &&
                periodos.Select(b => ((MYGPeriodoFecha)b.Tag).Inicio.Month).OrderBy(m => m)
                    .SequenceEqual(Enumerable.Range(1, 12)),
                "Pulsar la cabecera debe mostrar los doce meses del año sin confirmar una fecha.");
            Subir();
            periodos = PeriodosCalendario(calendario);
            exige(CabeceraContiene("2020", "2029") && periodos.Length == 12 &&
                periodos.Select(b => ((MYGPeriodoFecha)b.Tag).Inicio.Year)
                    .SequenceEqual(Enumerable.Range(2019, 12)),
                "La vista de años debe mostrar 2020–2029 y sus dos vecinos, como el calendario normal.");
            exige(periodos.Single(b => b.TabStop).Tag is MYGPeriodoFecha seleccionado && seleccionado.Inicio.Year == 2026,
                "El año de la fecha activa debe conservar la selección al ampliar la vista.");
            Subir();
            periodos = PeriodosCalendario(calendario);
            exige(CabeceraContiene("2000", "2099") && periodos.Length == 12 &&
                periodos.Select(b => ((MYGPeriodoFecha)b.Tag).Inicio.Year)
                    .SequenceEqual(Enumerable.Range(0, 12).Select(i => 1990 + i * 10)),
                "La vista de décadas debe mostrar el siglo y las décadas vecinas.");
            BotonCalendario(calendario, "calendarioFechaAnterior").PerformClick();
            EsperarTransicionCalendario(calendario, exige);
            exige(CabeceraContiene("1900", "1999"), "La flecha anterior debe avanzar un siglo en la vista de décadas.");
            BotonCalendario(calendario, "calendarioFechaSiguiente").PerformClick();
            EsperarTransicionCalendario(calendario, exige);
            exige(CabeceraContiene("2000", "2099"), "La flecha siguiente debe recuperar el siglo anterior sin cambiar el valor guardado.");
            ElegirPeriodo(p => p.Inicio.Year == 2030);
            exige(CabeceraContiene("2030", "2039"), "Elegir una década debe abrir sus años sin cerrar el calendario.");
            ElegirPeriodo(p => p.Inicio.Year == 2032);
            exige(PeriodosCalendario(calendario).All(b => ((MYGPeriodoFecha)b.Tag).Inicio.Year == 2032),
                "Elegir un año debe mostrar sus meses antes de confirmar el día.");
            ElegirPeriodo(p => p.Inicio.Month == 2);
            VerificarCalendarioVisible(calendario, exige);
            exige(fecha.Value == conHora && !fecha.Checked && confirmaciones == 0,
                "Navegar por meses, años y décadas no debe modificar la fecha ni su casilla opcional.");
            DiasCalendario(calendario).Single(b => b.Tag is DateTime d && d == new DateTime(2032, 2, 29)).PerformClick();
            Application.DoEvents();
            exige(!calendario.Visible && confirmaciones == 1 && fecha.Checked &&
                fecha.Value == new DateTime(2032, 2, 29, 14, 35, 17),
                "Elegir un día tras el zoom debe confirmar una sola vez y conservar la hora original.");

            fecha.Value = conHora; fecha.Checked = false;
            calendario = AbrirCalendario(fecha, exige);
            TeclaCalendario(calendario, Keys.Control | Keys.Down);
            exige(calendario.Visible && DiasCalendario(calendario).Any(b => b.Visible) &&
                fecha.Value == conHora && !fecha.Checked && confirmaciones == 1,
                "Ctrl+Abajo en la vista de días debe conservar el calendario abierto sin confirmar una fecha.");
            TeclaCalendario(calendario, Keys.Control | Keys.Up);
            TeclaCalendario(calendario, Keys.Control | Keys.Up);
            TeclaCalendario(calendario, Keys.Right);
            EsperarTransicionCalendario(calendario, exige);
            exige(PeriodosCalendario(calendario).Single(b => b.TabStop).Tag is MYGPeriodoFecha teclado &&
                teclado.Inicio.Year == 2027, "Las flechas deben recorrer años cuando la vista activa muestra años.");
            TeclaCalendario(calendario, Keys.Control | Keys.Down);
            TeclaCalendario(calendario, Keys.Enter);
            EsperarTransicionCalendario(calendario, exige);
            exige(calendario.Visible && DiasCalendario(calendario).Any(b => b.Visible) && fecha.Value == conHora && !fecha.Checked,
                "Ctrl+Abajo e Intro deben reducir el zoom sin confirmar hasta llegar a la vista de días.");
            TeclaCalendario(calendario, Keys.Escape);
            exige(!calendario.Visible && fecha.Value == conHora && !fecha.Checked && confirmaciones == 1,
                "Escape debe cancelar la navegación de niveles sin confirmar una fecha.");

            fecha.Value = new DateTime(2026, 10, 15, 14, 35, 17);
            fecha.MinDate = new DateTime(2026, 10, 10, 12, 0, 0);
            fecha.MaxDate = new DateTime(2026, 11, 20, 10, 0, 0);
            calendario = AbrirCalendario(fecha, exige);
            Subir();
            exige(PeriodosCalendario(calendario).Where(b => b.Enabled)
                .Select(b => ((MYGPeriodoFecha)b.Tag).Inicio.Month).SequenceEqual(new[] { 10, 11 }),
                "Los meses parcialmente incluidos deben seguir disponibles y los demás deben deshabilitarse.");
            Subir();
            exige(PeriodosCalendario(calendario).Where(b => b.Enabled).Single().Tag is MYGPeriodoFecha ano && ano.Inicio.Year == 2026,
                "La vista de años debe respetar un rango limitado a parte de un único año.");
            Subir();
            exige(PeriodosCalendario(calendario).Where(b => b.Enabled).Single().Tag is MYGPeriodoFecha decada && decada.Inicio.Year == 2020 &&
                !BotonCalendario(calendario, "calendarioFechaAnterior").Enabled &&
                !BotonCalendario(calendario, "calendarioFechaSiguiente").Enabled,
                "Las décadas y la paginación deben respetar la intersección del rango permitido.");
            ElegirPeriodo(p => p.Inicio.Year == 2020);
            ElegirPeriodo(p => p.Inicio.Year == 2026);
            ElegirPeriodo(p => p.Inicio.Month == 11);
            DiasCalendario(calendario).Single(b => b.Tag is DateTime d && d == fecha.MaxDate.Date).PerformClick();
            Application.DoEvents();
            exige(fecha.Value == fecha.MaxDate && confirmaciones == 2,
                "Elegir un período parcialmente permitido debe conservar también la hora exacta del límite final.");

            calendario = AbrirCalendario(fecha, exige);
            // No esperar entre acciones: cerrar o cambiar el tema en mitad
            // de una transición debe cancelar los fotogramas pendientes.
            BotonCalendario(calendario, "calendarioFechaMes").PerformClick();
            DateTime antesTema = fecha.Value;
            bool marcadaAntesTema = fecha.Checked;
            CambiarTema(false);
            exige(!calendario.Visible && !ControlesCalendario(calendario)
                .Any(c => c.Name == "calendarioFechaTransicion" && c.Visible),
                "Cambiar al tema normal debe cerrar el calendario y detener su animación pendiente.");
            CambiarTema(true);
            calendario = AbrirCalendario(fecha, exige);
            VerificarCalendarioVisible(calendario, exige);
            exige(fecha.Value == antesTema && fecha.Checked == marcadaAntesTema,
                "Cerrar y reabrir tras un cambio de tema debe volver a los días sin alterar los datos.");
            TeclaCalendario(calendario, Keys.Control | Keys.Up);
            TeclaCalendario(calendario, Keys.Escape);
            exige(!calendario.Visible && !ControlesCalendario(calendario)
                .Any(c => c.Name == "calendarioFechaTransicion" && c.Visible),
                "Escape durante el zoom debe detener la animación sin dejar una capa visible.");

            void Subir()
            {
                BotonCalendario(calendario, "calendarioFechaMes").PerformClick();
                exige(ConsultarAnimacionCliente(0x1042, 0, out bool animacionesCliente, 0),
                    "Debe poder consultarse la preferencia de animaciones del área de cliente de Windows.");
                exige(!SystemInformation.IsMenuAnimationEnabled || !animacionesCliente || ControlesCalendario(calendario)
                    .Any(c => c.Name == "calendarioFechaTransicion" && c.Visible),
                    "Ampliar la vista debe iniciar una transición cuando las animaciones del sistema están habilitadas.");
                EsperarTransicionCalendario(calendario, exige);
            }
            void ElegirPeriodo(Func<MYGPeriodoFecha, bool> condicion)
            {
                PeriodosCalendario(calendario).Single(b => b.Enabled && b.Tag is MYGPeriodoFecha p && condicion(p)).PerformClick();
                EsperarTransicionCalendario(calendario, exige);
                exige(calendario.Visible, "Seleccionar un período debe mantener el calendario abierto hasta elegir el día.");
            }
            bool CabeceraContiene(string desde, string hasta)
            {
                string texto = BotonCalendario(calendario, "calendarioFechaMes").Text;
                return texto.Contains(desde, StringComparison.Ordinal) && texto.Contains(hasta, StringComparison.Ordinal);
            }
        }
        finally
        {
            if (calendarioConEvento != null) calendarioConEvento.FechaElegida -= contar;
            BuscarCalendario()?.Close(ToolStripDropDownCloseReason.AppClicked);
            fecha.MinDate = DateTimePicker.MinimumDateTime;
            fecha.MaxDate = DateTimePicker.MaximumDateTime;
            fecha.Value = original; fecha.MinDate = minimo; fecha.MaxDate = maximo; fecha.Checked = marcada;
            CambiarTema(true);
            Application.DoEvents();
        }
    }

    private static void VerificarDatosProyecto(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-CamposTema-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "proyectos.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            byte[] antes = File.ReadAllBytes(ruta);
            var datos = MYGDatosProyecto.Crear(); datos.Propietario = "Propietario conservado";
            datos.FechaElaboracion = new DateTime(2026, 10, 27);
            datos.FechaInicio = new DateTime(2026, 10, 27); datos.CalcularFin();
            string firma = JsonSerializer.Serialize(datos);
            using var dialogo = new MYGDatosProyectoForm(ruta, "Proyecto conservado", datos);
            dialogo.Show(); Application.DoEvents();
            var entradas = Controles(dialogo).Where(c => c is TextBox or ComboBox or NumericUpDown or DateTimePicker).ToArray();
            VerificarTipografiaDatosProyecto(dialogo, ruta, exige);
            CambiarTema(true);
            if (!SystemInformation.HighContrast)
            {
                var fechas = entradas.OfType<DateTimePicker>().ToArray();
                exige(fechas.Length == 2, "Datos del proyecto debe conservar ambos selectores de fecha para comprobar sus flechas.");
                VerificarReaperturaConFlecha(fechas, exige);
            }
            foreach (bool oscuro in new[] { true, false, true })
            {
                CambiarTema(oscuro); VerificarPaleta(entradas, exige);
                if (oscuro && !SystemInformation.HighContrast)
                    foreach (var entrada in entradas.Where(c => c.Visible)) VerificarFondoOscuro(entrada, exige);
                if (oscuro && !SystemInformation.HighContrast) VerificarCalendariosDatosProyecto(dialogo, exige);
            }
            var catalogos = (Dictionary<MYGCatalogoProyecto, ComboBox>)typeof(MYGDatosProyectoForm)
                .GetField("catalogos", Privados).GetValue(dialogo);
            exige(catalogos[MYGCatalogoProyecto.Propietarios].Text.Contains("Propietario conservado", StringComparison.Ordinal) &&
                JsonSerializer.Serialize(datos) == firma,
                "Información del proyecto debe conservar los catálogos y datos mientras cambia su apariencia.");
            dialogo.DialogResult = DialogResult.Cancel; dialogo.Close();
            exige(dialogo.Datos == null && JsonSerializer.Serialize(datos) == firma && antes.SequenceEqual(File.ReadAllBytes(ruta)),
                "Abrir, cambiar de tema y cancelar Información del proyecto debe conservar el documento y su base de datos.");
        }
        finally { Directory.Delete(carpeta, recursive: true); }
    }

    private static void VerificarTipografiaDatosProyecto(MYGDatosProyectoForm dialogo, string ruta, Action<bool, string> exige)
    {
        int porcentajeOriginal = MYGTamanoTextoUI.Porcentaje;
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        byte[] baseOriginal = File.ReadAllBytes(ruta);
        var campos = Controles(dialogo).Where(c => c is TextBox or ComboBox or NumericUpDown or DateTimePicker).ToArray();
        var textos = Controles(dialogo).Where(c => c is Label or CheckBox or RadioButton).ToArray();
        var valores = campos.Select(c => new
        {
            Control = c, Texto = c.Text,
            Numero = c is NumericUpDown numero ? numero.Value : 0,
            Fecha = c is DateTimePicker fecha ? fecha.Value : DateTime.MinValue,
            Marcada = c is DateTimePicker opcional && opcional.Checked,
            Seleccion = c is ComboBox lista ? lista.SelectedIndex : -1
        }).ToArray();
        var nombre = (TextBox)typeof(MYGDatosProyectoForm).GetField("nombre", Privados).GetValue(dialogo);
        int inicioOriginal = nombre.SelectionStart, longitudOriginal = nombre.SelectionLength;
        int inicio = Math.Min(2, nombre.TextLength), longitud = Math.Min(8, nombre.TextLength - inicio);
        var errores = new List<Exception>();
        System.Threading.ThreadExceptionEventHandler capturar = (_, e) => errores.Add(e.Exception);
        Application.ThreadException += capturar;
        try
        {
            nombre.Focus(); nombre.Select(inicio, longitud);
            foreach (int porcentaje in new[] { 85, 100, 115, 85, 115, 100 })
            {
                MYGTamanoTextoUI.Cambiar(porcentaje, guardarPreferencia: false);
                foreach (bool oscuro in new[] { false, true, false })
                {
                    CambiarTema(oscuro);
                    // Reaplicar la apariencia comprueba que no se acumule el
                    // porcentaje al normalizar fuentes ya escaladas.
                    MYG2027_TemaComercial.Aplicar(dialogo);
                    MYG2027_TemaComercial.Aplicar(dialogo);
                    Application.DoEvents();
                    float esperado = 9 * porcentaje / 100f;
                    foreach (var control in campos.Concat(textos))
                    {
                        exige(control.Font.Name == "Segoe UI" && Math.Abs(control.Font.SizeInPoints - esperado) < .02F,
                            "Los campos y etiquetas de Datos del proyecto deben compartir Segoe UI y el tamaño elegido: "
                            + control.GetType().Name + " / " + control.Text + ".");
                        exige(MYGTamanoTextoUI.EsFuenteInterfaz(control.Font, 9, FontStyle.Regular),
                            "La escala de lectura debe conservar nueve puntos como base, sin reducciones acumuladas.");
                    }
                    foreach (var numero in campos.OfType<NumericUpDown>())
                    {
                        var editor = numero.Controls.OfType<TextBox>().Single();
                        exige(editor.Font.Equals(numero.Font),
                            "El editor interno de Duración debe heredar la misma fuente que su NumericUpDown.");
                    }
                    foreach (var fecha in campos.OfType<DateTimePicker>())
                        exige(fecha.CalendarFont.Equals(fecha.Font),
                            "El calendario predeterminado debe usar el mismo tamaño que su campo de fecha en ambos modos.");

                    // Consultar el HFONT que usa Windows detecta una fuente
                    // nativa desfasada aunque la propiedad Font parezca correcta.
                    foreach (var control in campos.Where(c => c is TextBox or DateTimePicker))
                        VerificarFuenteNativa(control, esperado, exige);
                    SinCambios();
                    if (oscuro && !SystemInformation.HighContrast)
                        foreach (var fecha in campos.OfType<DateTimePicker>())
                            for (int apertura = 0; apertura < 2; apertura++)
                            {
                                var calendario = AbrirCalendario(fecha, exige);
                                try
                                {
                                    exige(Math.Abs(calendario.Font.SizeInPoints - fecha.Font.SizeInPoints) < .02F,
                                        "Abrir y reabrir el calendario oscuro debe conservar el tamaño del campo sin aplicar la escala dos veces.");
                                    foreach (var boton in ControlesCalendario(calendario).OfType<Button>().Where(b => b.Visible))
                                        exige(Math.Abs(boton.Font.SizeInPoints - fecha.Font.SizeInPoints) < .02F,
                                            "Los días, la cabecera y los controles del calendario deben compartir la escala de su fecha.");
                                }
                                finally { TeclaCalendario(calendario, Keys.Escape); }
                                Application.DoEvents();
                                SinCambios();
                            }
                    exige(errores.Count == 0,
                        "Uniformar la tipografía y reabrir los calendarios no debe producir excepciones: " + errores.FirstOrDefault());
                }
            }

            void SinCambios()
            {
                exige(valores.All(v => v.Control.Text == v.Texto
                    && (v.Control is not NumericUpDown numero || numero.Value == v.Numero)
                    && (v.Control is not DateTimePicker fecha || fecha.Value == v.Fecha && fecha.Checked == v.Marcada)
                    && (v.Control is not ComboBox lista || lista.SelectedIndex == v.Seleccion)),
                    "Los cambios de tema y tamaño deben conservar nombres, fechas, casillas, duración y selecciones.");
                exige(nombre.SelectionStart == inicio && nombre.SelectionLength == longitud,
                    "Cambiar la tipografía debe conservar la selección pendiente del nombre del proyecto.");
                exige(baseOriginal.SequenceEqual(File.ReadAllBytes(ruta)),
                    "Ajustar tamaños, temas y calendarios no debe escribir en la base del proyecto.");
            }
        }
        finally
        {
            BuscarCalendario()?.Close(ToolStripDropDownCloseReason.CloseCalled);
            MYGTamanoTextoUI.Cambiar(porcentajeOriginal, guardarPreferencia: false);
            CambiarTema(oscuroOriginal);
            nombre.Select(inicioOriginal, longitudOriginal);
            Application.DoEvents();
            Application.ThreadException -= capturar;
        }
    }

    private static void VerificarFuenteNativa(Control control, float puntos, Action<bool, string> exige)
    {
        IntPtr fuente = Enviar(control.Handle, 0x0031, IntPtr.Zero, IntPtr.Zero); // WM_GETFONT.
        exige(fuente != IntPtr.Zero && ConsultarFuenteNativa(fuente, Marshal.SizeOf<FuenteNativa>(), out _) > 0,
            "El HWND de " + control.GetType().Name + " debe conservar una fuente nativa válida.");
        ConsultarFuenteNativa(fuente, Marshal.SizeOf<FuenteNativa>(), out var descripcion);
        double pixeles = puntos * control.DeviceDpi / 72D;
        exige(descripcion.Nombre == "Segoe UI" && Math.Abs(Math.Abs(descripcion.Alto) - pixeles) <= 1,
            "El HWND de " + control.GetType().Name + " debe dibujar Segoe UI al tamaño elegido y al DPI de su monitor.");
    }

    private static void VerificarReaperturaConFlecha(DateTimePicker[] fechas, Action<bool, string> exige)
    {
        var originales = fechas.Select(f => (Fecha: f, Valor: f.Value, Marcada: f.Checked, Fuente: f.CalendarFont)).ToArray();
        var fuentes = new List<Font>();
        var errores = new List<Exception>();
        Point cursorOriginal = Cursor.Position;
        System.Threading.ThreadExceptionEventHandler capturar = (_, e) => errores.Add(e.Exception);
        Application.ThreadException += capturar;
        try
        {
            // Repetir valores iguales con instancias distintas reproduce el
            // caso en que Control.Font conserva la referencia anterior por Equals.
            foreach (float? tamano in new float?[] { null, 9F, 9F, 12F, 16F, 16F })
                foreach (var item in originales)
                {
                    if (tamano.HasValue)
                    {
                        var fuente = new Font("Segoe UI", tamano.Value, FontStyle.Regular);
                        fuentes.Add(fuente);
                        item.Fecha.CalendarFont = fuente;
                    }
                    for (int ciclo = 0; ciclo < 3; ciclo++)
                    {
                        PulsarFlechaReal(item.Fecha, exige);
                        SinErrores();
                        var calendario = CalendarioAbierto(item.Fecha, exige);
                        FuentesUtilizables(calendario, item.Fecha);
                        VerificarCalendarioVisible(calendario, exige);
                        ConservarDatos();
                        PulsarFlechaReal(item.Fecha, exige);
                        SinErrores();
                        exige(!calendario.Visible && BuscarCalendario() == null,
                            "La segunda pulsación de la misma flecha debe cerrar el calendario sin reabrirlo ni mostrar errores.");
                        ConservarDatos();
                        FuentesUtilizables(calendario, item.Fecha);
                    }
                }

            foreach (var item in originales)
            {
                var anteriorFuente = new Font("Segoe UI", 11.25F, FontStyle.Regular);
                fuentes.Add(anteriorFuente);
                item.Fecha.CalendarFont = anteriorFuente;
                PulsarFlechaReal(item.Fecha, exige);
                SinErrores();
                var calendario = CalendarioAbierto(item.Fecha, exige);
                FuentesUtilizables(calendario, item.Fecha);
                PulsarFlechaReal(item.Fecha, exige);
                SinErrores();
                exige(!calendario.Visible, "El calendario debe estar oculto antes de sustituir su fuente externa.");
                var reemplazo = (Font)anteriorFuente.Clone();
                fuentes.Add(reemplazo);
                // DateTimePicker también compara fuentes por Equals. Pasar
                // por su valor predeterminado fuerza el cambio de propietario
                // antes de liberar la fuente anterior del propio campo.
                item.Fecha.CalendarFont = null;
                item.Fecha.CalendarFont = reemplazo;
                exige(ReferenceEquals(item.Fecha.CalendarFont, reemplazo),
                    "La prueba debe sustituir realmente CalendarFont antes de liberar su instancia anterior.");
                anteriorFuente.Dispose();
                fuentes.Remove(anteriorFuente);
                for (int ciclo = 0; ciclo < 2; ciclo++)
                {
                    PulsarFlechaReal(item.Fecha, exige);
                    SinErrores();
                    calendario = CalendarioAbierto(item.Fecha, exige);
                    FuentesUtilizables(calendario, item.Fecha);
                    VerificarCalendarioVisible(calendario, exige);
                    PulsarFlechaReal(item.Fecha, exige);
                    SinErrores();
                    exige(!calendario.Visible,
                        "Sustituir CalendarFont por un clon igual y liberar la anterior no debe impedir cerrar o reabrir el calendario.");
                    FuentesUtilizables(calendario, item.Fecha);
                    ConservarDatos();
                }
            }

            foreach (var item in originales)
            {
                item.Fecha.CalendarFont = null;
                item.Fecha.CalendarFont = item.Fuente;
            }
            // Cambiar directamente de campo comprueba también el cierre por
            // clic exterior. Si el popup tapa la otra flecha, se cierra primero:
            // no se debe pulsar accidentalmente un día en su lugar.
            foreach (var primera in fechas)
            {
                PulsarFlechaReal(primera, exige);
                SinErrores();
                var anterior = CalendarioAbierto(primera, exige);
                var otra = fechas.First(f => f != primera);
                if (anterior.Bounds.Contains(CentroFlecha(otra, exige)))
                {
                    PulsarFlechaReal(primera, exige);
                    SinErrores();
                    exige(!anterior.Visible, "La flecha del primer campo debe cerrar su calendario antes de cambiar al otro.");
                }
                PulsarFlechaReal(otra, exige);
                SinErrores();
                var actual = CalendarioAbierto(otra, exige);
                exige(!anterior.Visible && !ReferenceEquals(anterior, actual),
                    "Alternar Elaboración e Inicio debe cerrar el calendario anterior y abrir el del otro campo.");
                FuentesUtilizables(actual, otra);
                VerificarCalendarioVisible(actual, exige);
                PulsarFlechaReal(otra, exige);
                SinErrores();
                exige(!actual.Visible && BuscarCalendario() == null,
                    "También después de cambiar de campo, una segunda pulsación debe cerrar su calendario.");
                ConservarDatos();
            }

            void SinErrores() => exige(errores.Count == 0,
                "Los clics reales de apertura/cierre no deben provocar excepciones de Windows Forms: "
                + (errores.Count == 0 ? "" : errores[0].ToString()));
            void ConservarDatos() => exige(originales.All(i => i.Fecha.Value == i.Valor && i.Fecha.Checked == i.Marcada),
                "Abrir, cerrar y alternar los dos calendarios debe conservar sus fechas y casillas hasta elegir un día.");
            void FuentesUtilizables(ToolStripDropDown calendario, DateTimePicker campo)
            {
                using var dibujo = campo.CreateGraphics();
                exige(campo.CalendarFont.GetHeight(dibujo) > 0,
                    "Abrir y cerrar el calendario no debe liberar CalendarFont, que pertenece al campo de fecha.");
                foreach (var control in new Control[] { calendario }.Concat(ControlesCalendario(calendario)))
                    exige(control.Font.GetHeight(dibujo) > 0,
                        "La fuente de " + control.Name + " debe seguir siendo válida después de cada reapertura del calendario.");
                foreach (var host in calendario.Items.OfType<ToolStripControlHost>())
                    exige(host.Font.GetHeight(dibujo) > 0,
                        "El alojamiento del calendario debe conservar una fuente válida al reabrirse.");
            }
        }
        finally
        {
            BuscarCalendario()?.Close(ToolStripDropDownCloseReason.AppClicked);
            foreach (var item in originales)
            {
                item.Fecha.CalendarFont = null;
                item.Fecha.CalendarFont = item.Fuente;
            }
            foreach (var fuente in fuentes) fuente.Dispose();
            Cursor.Position = cursorOriginal;
            Application.DoEvents();
            Application.ThreadException -= capturar;
        }
    }

    private static Point CentroFlecha(DateTimePicker fecha, Action<bool, string> exige)
    {
        var info = new InformacionFecha { Tamano = Marshal.SizeOf<InformacionFecha>() };
        ConsultarFecha(fecha.Handle, 0x100E, IntPtr.Zero, ref info);
        exige(info.Boton.Derecha > info.Boton.Izquierda && info.Boton.Abajo > info.Boton.Arriba,
            "El campo de fecha debe conservar una flecha desplegable visible para la prueba de clic real.");
        return fecha.PointToScreen(new Point((info.Boton.Izquierda + info.Boton.Derecha) / 2,
            (info.Boton.Arriba + info.Boton.Abajo) / 2));
    }

    private static void PulsarFlechaReal(DateTimePicker fecha, Action<bool, string> exige)
    {
        Cursor.Position = CentroFlecha(fecha, exige);
        Bombear(30);
        var bajar = new[] { new EntradaMouse { Mouse = new DatosMouse { Opciones = 0x0002 } } };
        var subir = new[] { new EntradaMouse { Mouse = new DatosMouse { Opciones = 0x0004 } } };
        // SendMessage omite el filtro modal de ToolStripDropDown. SendInput
        // pasa por la cola real y reproduce AutoClose antes del WM_LBUTTONUP.
        exige(SendInput(1, bajar, Marshal.SizeOf<EntradaMouse>()) == 1,
            "Debe poder inyectarse la pulsación real de la flecha del calendario.");
        try { Bombear(40); }
        finally
        {
            exige(SendInput(1, subir, Marshal.SizeOf<EntradaMouse>()) == 1,
                "Debe poder soltarse la pulsación real de la flecha del calendario.");
        }
        Bombear(60);

        static void Bombear(int milisegundos)
        {
            var reloj = System.Diagnostics.Stopwatch.StartNew();
            do
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(5);
            } while (reloj.ElapsedMilliseconds < milisegundos);
        }
    }

    private static void VerificarCalendariosDatosProyecto(Form dialogo, Action<bool, string> exige)
    {
        foreach (var fecha in Controles(dialogo).OfType<DateTimePicker>())
        {
            DateTime original = fecha.Value;
            bool marcada = fecha.Checked;
            try
            {
                for (int apertura = 0; apertura < 2; apertura++)
                {
                    var calendario = AbrirCalendario(fecha, exige);
                    // Capturar la pantalla después de procesar la apertura, sin
                    // Refresh, DrawToBitmap ni invalidaciones que oculten un mes vacío.
                    VerificarCalendarioVisible(calendario, exige);
                    exige(fecha.Value == original && fecha.Checked == marcada,
                        "Abrir el calendario de Datos del proyecto debe conservar la fecha y su casilla opcional.");
                    if (apertura == 0)
                    {
                        calendario.Close(ToolStripDropDownCloseReason.AppClicked);
                        Application.DoEvents();
                        continue;
                    }

                    BotonCalendario(calendario, "calendarioFechaSiguiente").PerformClick();
                    Application.DoEvents();
                    DateTime elegida = original.Date.AddMonths(1);
                    var dia = DiasCalendario(calendario).Single(b => b.Tag is DateTime d && d == elegida);
                    Pulsar(dia.Handle, dia.Width / 2, dia.Height / 2);
                    exige(fecha.Value.Date == elegida && fecha.Checked,
                        "Navegar al mes siguiente y pulsar un día debe actualizar la fecha real de Datos del proyecto.");
                }
            }
            finally
            {
                BuscarCalendario()?.Close(ToolStripDropDownCloseReason.AppClicked);
                Application.DoEvents();
                fecha.Value = original; fecha.Checked = marcada;
            }
        }
    }

    private static void VerificarDialogosConPaletaPropia(Action<bool, string> exige)
    {
        using var fuente = new Font("Segoe UI", 10F, FontStyle.Bold);
        using var formato = new MYGFuenteResumenForm(fuente, Color.DarkBlue, Color.LightYellow);
        using var costo = new MYGConfigurarCostoDirectoForm(new MYGConfiguracionCostoDirecto { Nombre = "Costo sin cambios" });
        formato.Show(); costo.Show(); Application.DoEvents();
        foreach (bool oscuro in new[] { false, true, false, true })
        {
            CambiarTema(oscuro);
            foreach (var dialogo in new Form[] { formato, costo })
            {
                var entradas = Controles(dialogo).Where(c => c is TextBox or ListBox or ComboBox).ToArray();
                exige(entradas.All(c => c.BackColor == (oscuro && !SystemInformation.HighContrast
                    ? MYG2027_TemaComercial.Superficie : SystemColors.Window)),
                    "Los diálogos Fuente y Costo directo deben adaptar sus entradas sin reponer el blanco en oscuro.");
                if (oscuro && !SystemInformation.HighContrast)
                    // Las muestras de color son contenido de autor y pueden
                    // ocupar casi todo el selector, incluso en modo oscuro.
                    foreach (var entrada in entradas.Where(c => c is not ComboBox { DrawMode: not DrawMode.Normal }))
                        VerificarFondoOscuro(entrada, exige);
            }
            var ejemplo = formato.Controls.Find("ejemploFuenteResumen", true).Single();
            using var imagen = Capturar(ejemplo);
            exige(imagen.GetPixel(1, 1).ToArgb() == Color.LightYellow.ToArgb() &&
                formato.ColorTexto.ToArgb() == Color.DarkBlue.ToArgb() && formato.ColorFondo.ToArgb() == Color.LightYellow.ToArgb(),
                "La apariencia oscura de los campos debe conservar los colores de autor y el papel de la muestra de fuente.");
        }
        formato.Close(); costo.Close();
    }

    private static void VerificarPaleta(IEnumerable<Control> controles, Action<bool, string> exige)
    {
        foreach (var control in controles)
            exige(control.BackColor == MYG2027_TemaComercial.Superficie &&
                (SystemInformation.HighContrast || DisenoProfesionalCheck.Contraste(control.ForeColor, control.BackColor) >= 4.5),
                $"El campo {control.GetType().Name} debe usar la superficie y texto legible del tema.");
    }

    private static void VerificarFondoOscuro(Control control, Action<bool, string> exige)
    {
        using var imagen = Capturar(control);
        VerificarFondoOscuro(imagen, control.GetType().Name, exige);
    }

    private static void VerificarFondoOscuro(Bitmap imagen, string nombre, Action<bool, string> exige)
    {
        var interior = new Rectangle(Math.Min(20, imagen.Width / 4), 3,
            Math.Max(1, imagen.Width - Math.Min(20, imagen.Width / 4) - 24), Math.Max(1, imagen.Height - 6));
        int oscuros = 0, total = 0;
        for (int y = interior.Top; y < interior.Bottom; y++)
            for (int x = interior.Left; x < interior.Right; x++)
            {
                if (imagen.GetPixel(x, y).GetBrightness() < .48F) oscuros++;
                total++;
            }
        exige(oscuros >= total * .60,
            $"El área visible de {nombre} debe ser oscura, incluidos los campos nativos de fecha y lista.");
    }

    private static void VerificarListaDesplegada(ComboBox combo, Action<bool, string> exige)
    {
        combo.DroppedDown = true; Application.DoEvents();
        try
        {
            var info = new InformacionCombo { Tamano = Marshal.SizeOf<InformacionCombo>() };
            exige(GetComboBoxInfo(combo.Handle, ref info) && info.Lista != IntPtr.Zero,
                "El desplegable oscuro debe conservar su lista nativa accesible.");
            using var imagen = CapturarPantalla(info.Lista, exige);
            exige(Pixeles(imagen, c => c.GetBrightness() < .48F) >= imagen.Width * imagen.Height * .50,
                "Al abrir un desplegable su lista debe mantener el fondo oscuro y la selección visible.");
        }
        finally { combo.DroppedDown = false; Application.DoEvents(); }
    }

    private static Bitmap Capturar(Control control)
    {
        control.Refresh(); Application.DoEvents();
        var imagen = new Bitmap(control.Width, control.Height);
        control.DrawToBitmap(imagen, control.ClientRectangle);
        return imagen;
    }

    private static Bitmap CapturarPantalla(IntPtr ventana, Action<bool, string> exige)
    {
        exige(GetClientRect(ventana, out var rectangulo), "La ventana nativa debe conservar su área de cliente.");
        int ancho = rectangulo.Derecha - rectangulo.Izquierda, alto = rectangulo.Abajo - rectangulo.Arriba;
        exige(ancho > 0 && alto > 0, "El campo nativo debe mantener su área visible.");
        var imagen = new Bitmap(ancho, alto);
        try
        {
            using var dibujo = Graphics.FromImage(imagen);
            IntPtr origen = GetDC(ventana), destino = dibujo.GetHdc();
            try
            {
                exige(origen != IntPtr.Zero && BitBlt(destino, 0, 0, ancho, alto, origen, 0, 0, 0x00CC0020),
                    "Debe poder capturarse el repintado visible del campo nativo.");
            }
            finally { dibujo.ReleaseHdc(destino); if (origen != IntPtr.Zero) ReleaseDC(ventana, origen); }
            return imagen;
        }
        catch { imagen.Dispose(); throw; }
    }

    private static int Pixeles(Bitmap imagen, Func<Color, bool> cumple)
    {
        int cantidad = 0;
        for (int y = 0; y < imagen.Height; y++)
            for (int x = 0; x < imagen.Width; x++)
                if (cumple(imagen.GetPixel(x, y))) cantidad++;
        return cantidad;
    }

    private static void Tecla(Control control, Keys tecla)
    {
        Enviar(control.Handle, WmKeyDown, new IntPtr((int)tecla), new IntPtr(1));
        Enviar(control.Handle, WmKeyUp, new IntPtr((int)tecla), new IntPtr(unchecked((int)0xC0000001)));
        Application.DoEvents();
    }

    private static void Pulsar(IntPtr ventana, int x, int y)
    {
        var punto = new IntPtr((x & 0xffff) | (y << 16));
        Enviar(ventana, WmLeftButtonDown, new IntPtr(1), punto);
        Enviar(ventana, WmLeftButtonUp, IntPtr.Zero, punto);
        Application.DoEvents();
    }

    private static void CambiarTema(bool oscuro)
    {
        if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
        Application.DoEvents();
    }

    private static IEnumerable<Control> Controles(Control control)
    {
        foreach (Control hijo in control.Controls)
        {
            yield return hijo;
            foreach (var nieto in Controles(hijo)) yield return nieto;
        }
    }
}
