using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Documento continuo con páginas vectoriales; sólo prepara las hojas que se ven.</summary>
internal sealed class MYGVistaPaginaControl : ScrollableControl
{
    private sealed class PaginaVector : IDisposable
    {
        internal MemoryStream Memoria;
        internal Metafile Imagen;
        public void Dispose() { Imagen?.Dispose(); Memoria?.Dispose(); }
    }

    private readonly Dictionary<int, PaginaVector> cache = new();
    private readonly LinkedList<int> ordenCache = new();
    private const int LimitePaginasCache = 128;
    private const long LimiteBytesCache = 128L * 1024 * 1024;
    private long bytesCache, deltaRueda;
    private int grabaciones, colorCache, pagina, revision;
    private string filigranaCache;
    private MYGReportesImpresion.Vista vista;
    private SizeF[] medidas = Array.Empty<SizeF>();
    private MYGDisposicionPaginas disposicion;
    private int[] indicesVisibles = Array.Empty<int>();
    private float ampliacion = 1;
    private float ampliacionObjetivo = 1, ampliacionOrigen = 1;
    private readonly System.Windows.Forms.Timer temporizadorZoom = new() { Interval = 15 };
    private long instanteZoom;
    private double tiempoZoom;
    private bool zoomEnCurso;
    private Point anclaZoom;
    private PointF relativoZoom;
    private int paginaAnclaZoom;
    private const double DuracionZoom = .14;
    private bool variasPaginas, arrastrar, arrastrando, ajustando, desplazando, actualizandoVisibles;
    private Point inicioArrastre, scrollArrastre, scrollNotificado;
    private Size ultimaArea;

    internal event EventHandler AmpliacionChanged;
    internal event EventHandler PaginaActualChanged;
    internal event Action<Exception> ErrorPreparacion;
    internal float Ampliacion => ampliacion;
    internal float AmpliacionObjetivo => ampliacionObjetivo;
    internal bool ZoomEnCurso => zoomEnCurso;
    internal int ContadorGrabaciones => grabaciones;
    internal int CantidadPaginasCache => cache.Count;
    internal long BytesPaginasCache => bytesCache;
    internal int PaginaActual { get { ActualizarGeometriaVisible(); return pagina; } }
    internal IReadOnlyList<int> IndicesPaginasVisibles { get { ActualizarGeometriaVisible(); return indicesVisibles; } }
    internal SizeF TamanoPapel => vista == null ? SizeF.Empty : medidas[Math.Clamp(PaginaActual, 0, medidas.Length - 1)];
    internal RectangleF RectanguloPapel => RectangulosPapel.FirstOrDefault();
    internal IReadOnlyList<RectangleF> RectangulosPapel
    {
        get
        {
            ActualizarGeometriaVisible();
            if (disposicion == null) return Array.Empty<RectangleF>();
            var origen = OrigenDocumento(ClientSize, AutoScrollPosition);
            return indicesVisibles.Select(i => Trasladar(disposicion.Pagina(i), origen)).ToArray();
        }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal bool VariasPaginas
    {
        get => variasPaginas;
        set
        {
            if (variasPaginas == value) return;
            DetenerZoom();
            int conservar = PaginaActual;
            variasPaginas = value && (vista == null || vista.CantidadPaginas > 1);
            if (vista == null) return;
            try
            {
                RecalcularExtension();
                DesplazarHastaPagina(conservar);
                PrepararVisibles();
                Invalidate();
            }
            catch { Limpiar(); throw; }
        }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal bool Arrastrar
    {
        get => arrastrar;
        set
        {
            arrastrar = value;
            if (!value && arrastrando) Capture = false;
            Cursor = value ? Cursors.Hand : Cursors.Default;
        }
    }

    private float Separacion => 24f * DeviceDpi / 96f;
    private SizeF TamanoDocumento => disposicion?.TamanoDocumento ?? SizeF.Empty;

    internal MYGVistaPaginaControl()
    {
        temporizadorZoom.Tick += (_, _) =>
        {
            long ahora = Stopwatch.GetTimestamp();
            double segundos = (ahora - instanteZoom) / (double)Stopwatch.Frequency;
            instanteZoom = ahora;
            EjecutarSeguro(() => AvanzarZoom(segundos));
        };
        Name = "vista_superficie";
        Dock = DockStyle.Fill;
        AutoScroll = true;
        TabStop = true;
        BackColor = Color.FromArgb(159, 183, 205);
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
    }

    internal void Cargar(MYGReportesImpresion.Vista nuevaVista, int indice)
    {
        ArgumentNullException.ThrowIfNull(nuevaVista);
        if (indice < 0 || indice >= nuevaVista.CantidadPaginas) throw new ArgumentOutOfRangeException(nameof(indice));
        DetenerZoom();
        revision++;
        try
        {
            bool otraVista = !ReferenceEquals(vista, nuevaVista);
            if (otraVista || colorCache != nuevaVista.ColorPagina.ToArgb() || filigranaCache != nuevaVista.Filigrana)
                LiberarCache();
            vista = nuevaVista;
            colorCache = nuevaVista.ColorPagina.ToArgb();
            filigranaCache = nuevaVista.Filigrana;
            if (otraVista) medidas = Enumerable.Range(0, vista.CantidadPaginas).Select(vista.TamanoPagina).ToArray();
            if (medidas.Length == 1) variasPaginas = false;
            RecalcularExtension();
            DesplazarHastaPagina(indice);
            PrepararVisibles();
            Invalidate();
        }
        catch { Limpiar(); throw; }
    }

    private static RectangleF Trasladar(RectangleF papel, PointF origen)
        => new(papel.X + origen.X, papel.Y + origen.Y, papel.Width, papel.Height);

    private PointF OrigenDocumento(Size area, Point scroll)
    {
        var tamano = TamanoDocumento;
        return new PointF(Math.Max(Separacion, (area.Width - tamano.Width) / 2f) + scroll.X,
            Math.Max(Separacion, (area.Height - tamano.Height) / 2f) + scroll.Y);
    }

    private void ActualizarGeometriaVisible()
    {
        if (actualizandoVisibles || ajustando) return;
        actualizandoVisibles = true;
        try
        {
            int anterior = pagina;
            int[] anteriores = indicesVisibles;
            if (disposicion == null || ClientSize.Width <= 0 || ClientSize.Height <= 0)
            { indicesVisibles = Array.Empty<int>(); pagina = 0; }
            else
            {
                var origen = OrigenDocumento(ClientSize, AutoScrollPosition);
                indicesVisibles = disposicion.Visibles(new RectangleF(-origen.X, -origen.Y, ClientSize.Width, ClientSize.Height));
                pagina = disposicion.PrimeraVisible(Math.Max(0, -origen.Y));
            }
            bool cambio = anterior != pagina || !anteriores.SequenceEqual(indicesVisibles) || scrollNotificado != AutoScrollPosition;
            scrollNotificado = AutoScrollPosition;
            if (cambio && vista != null) PaginaActualChanged?.Invoke(this, EventArgs.Empty);
        }
        finally { actualizandoVisibles = false; }
    }

    // Sólo los índices que intersectan el área de lectura necesitan un EMF.
    // La geometría de todas las hojas es barata y no implica dibujarlas.
    private void PrepararVisibles()
    {
        ActualizarGeometriaVisible();
        if (vista == null) return;
        foreach (int indice in indicesVisibles)
        {
            if (!cache.TryGetValue(indice, out var vector))
            {
                vector = GrabarPagina(vista, indice);
                cache.Add(indice, vector);
                bytesCache += vector.Memoria.Capacity;
                grabaciones++;
            }
            ordenCache.Remove(indice);
            ordenCache.AddLast(indice);
        }
        var retenidas = indicesVisibles.ToHashSet();
        while ((cache.Count > LimitePaginasCache || bytesCache > LimiteBytesCache) && cache.Count > retenidas.Count)
        {
            var nodo = ordenCache.First;
            while (nodo != null && retenidas.Contains(nodo.Value)) nodo = nodo.Next;
            if (nodo == null) break;
            int retirar = nodo.Value;
            ordenCache.Remove(nodo);
            var vector = cache[retirar];
            cache.Remove(retirar);
            bytesCache -= vector.Memoria.Capacity;
            vector.Dispose();
        }
    }

    internal void InvalidarPaginas()
    {
        DetenerZoom();
        LiberarCache();
        if (vista != null)
        {
            colorCache = vista.ColorPagina.ToArgb();
            filigranaCache = vista.Filigrana;
            try { PrepararVisibles(); }
            catch { Limpiar(); throw; }
        }
        Invalidate();
    }

    private void LiberarCache()
    {
        foreach (var vector in cache.Values) vector.Dispose();
        cache.Clear();
        ordenCache.Clear();
        bytesCache = 0;
    }

    private PaginaVector GrabarPagina(MYGReportesImpresion.Vista documento, int indice)
    {
        var resultado = new PaginaVector { Memoria = new MemoryStream() };
        try
        {
            using var referencia = CreateGraphics();
            IntPtr hdc = referencia.GetHdc();
            try
            {
                resultado.Imagen = new Metafile(resultado.Memoria, hdc,
                    new RectangleF(PointF.Empty, medidas[indice]), MetafileFrameUnit.Inch, EmfType.EmfPlusOnly);
            }
            finally { referencia.ReleaseHdc(hdc); }
            using var dibujo = Graphics.FromImage(resultado.Imagen);
            Calidad(dibujo);
            dibujo.PageUnit = GraphicsUnit.Inch;
            documento.DibujarPagina(dibujo, indice);
            return resultado;
        }
        catch { resultado.Dispose(); throw; }
    }

    internal void Limpiar()
    {
        DetenerZoom();
        revision++;
        vista = null;
        disposicion = null;
        medidas = Array.Empty<SizeF>();
        indicesVisibles = Array.Empty<int>();
        pagina = 0;
        deltaRueda = 0;
        LiberarCache();
        ajustando = desplazando = true;
        try { AutoScrollMinSize = Size.Empty; AutoScrollPosition = Point.Empty; }
        finally { ajustando = desplazando = false; }
        scrollNotificado = Point.Empty;
        Invalidate();
    }

    internal void CambiarZoom(float valor, Point? ancla = null)
    {
        if (!float.IsFinite(valor)) throw new ArgumentOutOfRangeException(nameof(valor));
        DetenerZoom();
        AplicarZoom(valor, ancla);
        ampliacionObjetivo = ampliacion;
    }

    private void AplicarZoom(float valor, Point? ancla, PointF? relativoFijo = null, int? paginaFija = null,
        bool respetarColumnas = false)
    {
        if (!float.IsFinite(valor)) throw new ArgumentOutOfRangeException(nameof(valor));
        valor = Math.Clamp(valor, .1f, 5);
        if (Math.Abs(valor - ampliacion) < .00001f) return;
        ActualizarGeometriaVisible();
        var punto = ancla ?? new Point(ClientSize.Width / 2, ClientSize.Height / 2);
        PointF relativo = relativoFijo ?? PuntoRelativoPagina(punto, out paginaAnclaZoom);
        int indice = paginaFija ?? paginaAnclaZoom;
        ampliacion = valor;
        if (!respetarColumnas) ActualizarColumnasAutomaticas(valor);
        RecalcularExtension();
        RestaurarAncla(indice, relativo, punto);
        PrepararVisibles();
        Invalidate();
        AmpliacionChanged?.Invoke(this, EventArgs.Empty);
    }

    private void ActualizarColumnasAutomaticas(float valor)
    {
        if (vista == null) return;
        if (vista.CantidadPaginas < 2) { variasPaginas = false; return; }
        int actual = Math.Clamp(pagina, 0, medidas.Length - 1);
        var primera = medidas[actual];
        var segunda = medidas[actual + 1 < medidas.Length ? actual + 1 : actual - 1];
        float ancho = ClientSize.Width + (VerticalScroll.Visible ? SystemInformation.VerticalScrollBarWidth : 0);
        float alto = ClientSize.Height + (HorizontalScroll.Visible ? SystemInformation.HorizontalScrollBarHeight : 0);
        float ajusteUna = Math.Min((ancho - 2 * Separacion) / (primera.Width * DeviceDpi),
            (alto - 2 * Separacion) / (primera.Height * DeviceDpi));
        float ajusteDos = Math.Min((ancho - 3 * Separacion) / ((primera.Width + segunda.Width) * DeviceDpi),
            (alto - 2 * Separacion) / (Math.Max(primera.Height, segunda.Height) * DeviceDpi));
        variasPaginas = valor <= Math.Min(ajusteUna * .85f, ajusteDos);
    }

    internal void AjustarPagina()
    {
        DetenerZoom();
        if (disposicion == null || ClientSize.Width < 1 || ClientSize.Height < 1) return;
        int actual = PaginaActual;
        int inicio = disposicion.FilaInicio(actual);
        int cantidad = variasPaginas ? Math.Min(2, medidas.Length - inicio) : 1;
        var fila = medidas.Skip(inicio).Take(cantidad).ToArray();
        float anchoArea = ClientSize.Width + (VerticalScroll.Visible ? SystemInformation.VerticalScrollBarWidth : 0);
        float altoArea = ClientSize.Height + (HorizontalScroll.Visible ? SystemInformation.HorizontalScrollBarHeight : 0);
        float ancho = fila.Sum(p => p.Width) * DeviceDpi;
        float alto = fila.Max(p => p.Height) * DeviceDpi;
        float factor = Math.Min((anchoArea - 2 * Separacion - Separacion * (cantidad - 1)) / ancho,
            (altoArea - 2 * Separacion) / alto);
        AplicarZoom(Math.Max(.1f, factor), null, respetarColumnas: true);
        ampliacionObjetivo = ampliacion;
        DesplazarHastaPagina(actual);
        PrepararVisibles();
        Invalidate();
    }

    /// <summary>Los deltas fraccionarios acercan suavemente alrededor del punto del documento bajo el cursor.</summary>
    internal bool ProcesarRueda(int delta, bool control, Point punto)
    {
        if (!control || disposicion == null) return false;
        if (delta != 0)
        {
            bool iniciando = !zoomEnCurso;
            if (iniciando || punto != anclaZoom)
            {
                anclaZoom = punto;
                relativoZoom = PuntoRelativoPagina(punto, out paginaAnclaZoom);
            }
            double destino = (iniciando ? ampliacion : ampliacionObjetivo) * Math.Pow(1.12, delta / 120d);
            ampliacionObjetivo = (float)Math.Clamp(destino, .1f, 5);
            ampliacionOrigen = ampliacion;
            tiempoZoom = 0;
            if (Math.Abs(ampliacionObjetivo - ampliacion) < .00001f) { DetenerZoom(); Invalidate(); }
            else
            {
                zoomEnCurso = true;
                if (iniciando) instanteZoom = Stopwatch.GetTimestamp();
                temporizadorZoom.Start();
            }
        }
        return true;
    }

    internal bool DesplazarRueda(int delta)
    {
        if (disposicion == null) return false;
        DetenerZoom();
        deltaRueda += delta;
        long pasos = deltaRueda / 120;
        deltaRueda %= 120;
        if (pasos == 0) return true;
        int lineas = SystemInformation.MouseWheelScrollLines;
        long avance = lineas < 0 ? Math.Max(1, ClientSize.Height - (int)(2 * Separacion)) : Math.Max(0, lineas) * (long)Math.Max(1, Font.Height);
        long y = -AutoScrollPosition.Y - pasos * avance;
        PonerDesplazamiento(new Point(-AutoScrollPosition.X, (int)Math.Clamp(y, 0, MaximoDesplazamiento().Y)));
        PrepararVisibles();
        Invalidate();
        return true;
    }

    internal void AvanzarZoom(double segundos)
    {
        if (!double.IsFinite(segundos) || segundos < 0) throw new ArgumentOutOfRangeException(nameof(segundos));
        if (!zoomEnCurso || segundos == 0) return;
        tiempoZoom += segundos;
        double progreso = Math.Min(1, tiempoZoom / DuracionZoom);
        float valor = InterpolarZoom(ampliacionOrigen, ampliacionObjetivo, progreso);
        AplicarZoom(valor, anclaZoom, relativoZoom, paginaAnclaZoom);
        if (progreso >= 1) { DetenerZoom(); Invalidate(); }
    }

    internal static float InterpolarZoom(float inicio, float objetivo, double progreso)
    {
        if (!float.IsFinite(inicio) || inicio <= 0) throw new ArgumentOutOfRangeException(nameof(inicio));
        if (!float.IsFinite(objetivo) || objetivo <= 0) throw new ArgumentOutOfRangeException(nameof(objetivo));
        if (!double.IsFinite(progreso)) throw new ArgumentOutOfRangeException(nameof(progreso));
        double t = Math.Clamp(progreso, 0, 1);
        if (t == 0) return inicio;
        if (t == 1) return objetivo;
        double peso = 1 - Math.Pow(1 - t, 3);
        return (float)Math.Exp(Math.Log(inicio) + (Math.Log(objetivo) - Math.Log(inicio)) * peso);
    }

    private void DetenerZoom()
    {
        temporizadorZoom.Stop(); zoomEnCurso = false; tiempoZoom = 0; ampliacionObjetivo = ampliacion;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        EjecutarSeguro(() =>
        {
            if (ProcesarRueda(e.Delta, (ModifierKeys & Keys.Control) != 0, e.Location) || DesplazarRueda(e.Delta))
                if (e is HandledMouseEventArgs manejado) manejado.Handled = true;
        });
    }

    protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); if (CanFocus) Focus(); }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (!arrastrar || e.Button != MouseButtons.Left || disposicion == null) return;
        DetenerZoom();
        inicioArrastre = e.Location; scrollArrastre = new Point(-AutoScrollPosition.X, -AutoScrollPosition.Y);
        arrastrando = true; Capture = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (!arrastrando) return;
        EjecutarSeguro(() =>
        {
            PonerDesplazamiento(new Point(Math.Max(0, scrollArrastre.X + inicioArrastre.X - e.X),
                Math.Max(0, scrollArrastre.Y + inicioArrastre.Y - e.Y)));
            PrepararVisibles(); Invalidate();
        });
    }

    protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); if (e.Button == MouseButtons.Left && arrastrando) Capture = false; }
    protected override void OnMouseCaptureChanged(EventArgs e) { if (!Capture) arrastrando = false; base.OnMouseCaptureChanged(e); }

    protected override void OnScroll(ScrollEventArgs se)
    {
        base.OnScroll(se);
        if (ajustando || desplazando) return;
        DetenerZoom();
        EjecutarSeguro(() => { PrepararVisibles(); Invalidate(); });
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (ajustando || disposicion == null) return;
        DetenerZoom();
        var anterior = ultimaArea.IsEmpty ? ClientSize : ultimaArea;
        var relativo = PuntoRelativoPagina(new Point(anterior.Width / 2, anterior.Height / 2), out int indice, anterior);
        EjecutarSeguro(() =>
        {
            RecalcularExtension();
            RestaurarAncla(indice, relativo, new Point(ClientSize.Width / 2, ClientSize.Height / 2));
            PrepararVisibles(); Invalidate();
        });
    }

    protected override void OnDpiChangedAfterParent(EventArgs e)
    {
        var punto = new Point(ClientSize.Width / 2, ClientSize.Height / 2);
        var relativo = PuntoRelativoPagina(punto, out int indice);
        base.OnDpiChangedAfterParent(e);
        DetenerZoom();
        if (disposicion == null) return;
        EjecutarSeguro(() => { RecalcularExtension(); RestaurarAncla(indice, relativo, punto); PrepararVisibles(); Invalidate(); });
    }

    private PointF PuntoRelativoPagina(Point punto, out int indice, Size? area = null)
    {
        if (disposicion == null) { indice = 0; return new PointF(.5f, .5f); }
        var origen = OrigenDocumento(area ?? ClientSize, AutoScrollPosition);
        var documento = new PointF(punto.X - origen.X, punto.Y - origen.Y);
        indice = disposicion.PaginaEnPunto(documento);
        var papel = disposicion.Pagina(indice);
        return new PointF((documento.X - papel.X) / papel.Width, (documento.Y - papel.Y) / papel.Height);
    }

    private void RecalcularExtension()
    {
        if (ajustando) return;
        ajustando = true;
        try
        {
            disposicion = vista == null ? null : new MYGDisposicionPaginas(medidas, variasPaginas ? 2 : 1, DeviceDpi, ampliacion, Separacion);
            var tamano = TamanoDocumento;
            var extension = disposicion == null ? Size.Empty : new Size(
                checked((int)Math.Ceiling(tamano.Width + 2 * Separacion)), checked((int)Math.Ceiling(tamano.Height + 2 * Separacion)));
            if (AutoScrollMinSize != extension) AutoScrollMinSize = extension;
            ultimaArea = ClientSize;
        }
        finally { ajustando = false; }
    }

    private Point MaximoDesplazamiento() => new(Math.Max(0, AutoScrollMinSize.Width - ClientSize.Width),
        Math.Max(0, AutoScrollMinSize.Height - ClientSize.Height));

    private void PonerDesplazamiento(Point valor)
    {
        var maximo = MaximoDesplazamiento();
        desplazando = true;
        try { AutoScrollPosition = new Point(Math.Clamp(valor.X, 0, maximo.X), Math.Clamp(valor.Y, 0, maximo.Y)); }
        finally { desplazando = false; }
        ActualizarGeometriaVisible();
    }

    private void DesplazarHastaPagina(int indice)
    {
        if (disposicion == null) return;
        int inicio = disposicion.FilaInicio(Math.Clamp(indice, 0, medidas.Length - 1));
        float y = disposicion.Pagina(inicio).Top;
        if (variasPaginas && inicio + 1 < medidas.Length) y = Math.Min(y, disposicion.Pagina(inicio + 1).Top);
        PonerDesplazamiento(new Point(Math.Max(0, (AutoScrollMinSize.Width - ClientSize.Width) / 2), (int)Math.Round(y)));
    }

    private void RestaurarAncla(int indice, PointF relativo, Point punto)
    {
        if (disposicion == null) return;
        indice = Math.Clamp(indice, 0, medidas.Length - 1);
        var papel = disposicion.Pagina(indice);
        var origen = OrigenDocumento(ClientSize, Point.Empty);
        PonerDesplazamiento(new Point((int)Math.Round(origen.X + papel.X + papel.Width * relativo.X - punto.X),
            (int)Math.Round(origen.Y + papel.Y + papel.Height * relativo.Y - punto.Y)));
    }

    // Conservadas para los consumidores y pruebas de geometría de una hoja.
    internal static RectangleF CentrarPapel(SizeF medida, Size area, Point scroll, float margen)
    {
        if (medida.IsEmpty) return RectangleF.Empty;
        return new RectangleF(Math.Max(margen, (area.Width - medida.Width) / 2f) + scroll.X,
            Math.Max(margen, (area.Height - medida.Height) / 2f) + scroll.Y, medida.Width, medida.Height);
    }

    internal static Point DesplazamientoParaAncla(SizeF medida, Size area, float margen, Point punto, PointF relativo)
    {
        var rectangulo = CentrarPapel(medida, area, Point.Empty, margen);
        int maximoX = Math.Max(0, (int)Math.Ceiling(medida.Width + 2 * margen) - area.Width);
        int maximoY = Math.Max(0, (int)Math.Ceiling(medida.Height + 2 * margen) - area.Height);
        return new Point(Math.Clamp((int)Math.Round(rectangulo.Left + medida.Width * relativo.X - punto.X), 0, maximoX),
            Math.Clamp((int)Math.Round(rectangulo.Top + medida.Height * relativo.Y - punto.Y), 0, maximoY));
    }

    private void EjecutarSeguro(Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        { Limpiar(); ErrorPreparacion?.Invoke(ex); }
    }

    private static void Calidad(Graphics dibujo, bool textoPantalla = false)
    {
        dibujo.SmoothingMode = SmoothingMode.AntiAlias;
        dibujo.PixelOffsetMode = PixelOffsetMode.HighQuality;
        dibujo.CompositingQuality = CompositingQuality.HighQuality;
        dibujo.TextRenderingHint = textoPantalla ? TextRenderingHint.ClearTypeGridFit : TextRenderingHint.AntiAliasGridFit;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (vista == null) return;
        try
        {
            PrepararVisibles();
            var estado = e.Graphics.Save();
            try
            {
                e.Graphics.PageUnit = GraphicsUnit.Pixel;
                Calidad(e.Graphics, true);
                var rectangulos = RectangulosPapel;
                using var sombra = new SolidBrush(Color.FromArgb(48, 52, 71, 88));
                using var borde = new Pen(Color.FromArgb(167, 147, 98), Math.Max(1, DeviceDpi / 96f));
                for (int i = 0; i < indicesVisibles.Length; i++)
                {
                    int indice = indicesVisibles[i];
                    var rectangulo = rectangulos[i];
                    var marco = rectangulo; marco.Inflate(6 * DeviceDpi / 96f, 6 * DeviceDpi / 96f);
                    if (!marco.IntersectsWith(e.ClipRectangle)) continue;
                    e.Graphics.FillRectangle(sombra, rectangulo.X + 4, rectangulo.Y + 4, rectangulo.Width, rectangulo.Height);
                    e.Graphics.FillRectangle(Brushes.White, rectangulo);
                    var recorte = e.Graphics.Save();
                    try
                    {
                        e.Graphics.SetClip(rectangulo, CombineMode.Intersect);
                        if (zoomEnCurso) e.Graphics.DrawImage(cache[indice].Imagen, rectangulo);
                        else
                        {
                            e.Graphics.PageUnit = GraphicsUnit.Inch;
                            e.Graphics.TranslateTransform(rectangulo.X / e.Graphics.DpiX, rectangulo.Y / e.Graphics.DpiY);
                            var medida = medidas[indice];
                            e.Graphics.ScaleTransform(rectangulo.Width / (medida.Width * e.Graphics.DpiX),
                                rectangulo.Height / (medida.Height * e.Graphics.DpiY));
                            vista.DibujarPagina(e.Graphics, indice);
                        }
                    }
                    finally { e.Graphics.Restore(recorte); }
                    DibujarMargenes(e.Graphics, rectangulo, medidas[indice], vista.AreaMargenes(indice));
                    e.Graphics.DrawRectangle(borde, rectangulo.X, rectangulo.Y, rectangulo.Width, rectangulo.Height);
                }
            }
            finally { e.Graphics.Restore(estado); }
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            Limpiar();
            int version = revision;
            if (IsHandleCreated && !IsDisposed)
            {
                try { BeginInvoke(new Action(() => { if (!IsDisposed && revision == version) ErrorPreparacion?.Invoke(ex); })); }
                catch (InvalidOperationException) when (IsDisposed || Disposing || !IsHandleCreated) { }
            }
        }
    }

    private void DibujarMargenes(Graphics dibujo, RectangleF papel, SizeF medida, RectangleF area)
    {
        var estado = dibujo.Save();
        try
        {
            dibujo.SetClip(papel, CombineMode.Intersect); dibujo.SmoothingMode = SmoothingMode.None;
            using var guia = new Pen(Color.FromArgb(150, 150, 150), Math.Max(1, DeviceDpi / 96f)) { DashStyle = DashStyle.Dash };
            float izq = papel.Left + area.Left / medida.Width * papel.Width;
            float der = papel.Left + area.Right / medida.Width * papel.Width;
            float sup = papel.Top + area.Top / medida.Height * papel.Height;
            float inf = papel.Top + area.Bottom / medida.Height * papel.Height;
            dibujo.DrawLine(guia, izq, papel.Top, izq, papel.Bottom); dibujo.DrawLine(guia, der, papel.Top, der, papel.Bottom);
            dibujo.DrawLine(guia, papel.Left, sup, papel.Right, sup); dibujo.DrawLine(guia, papel.Left, inf, papel.Right, inf);
        }
        finally { dibujo.Restore(estado); }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { DetenerZoom(); temporizadorZoom.Dispose(); LiberarCache(); vista = null; disposicion = null; }
        base.Dispose(disposing);
    }
}
