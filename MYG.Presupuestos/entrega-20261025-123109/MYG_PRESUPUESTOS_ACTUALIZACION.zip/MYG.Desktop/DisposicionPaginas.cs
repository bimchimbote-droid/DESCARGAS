using System;
using System.Collections.Generic;
using System.Drawing;

namespace MYG_2027;

// Geometría de todo el documento, sin dibujar ni generar imágenes. La barra
// vertical recorre esta extensión; el lienzo sólo prepara las hojas visibles.
internal sealed class MYGDisposicionPaginas
{
    private readonly RectangleF[] paginas;
    private readonly float[] superiores, inferiores;
    private readonly int columnas;

    internal SizeF TamanoDocumento { get; }
    internal int CantidadPaginas => paginas.Length;

    internal MYGDisposicionPaginas(IReadOnlyList<SizeF> medidas, int columnas, float dpi, float zoom, float separacion)
    {
        ArgumentNullException.ThrowIfNull(medidas);
        if (columnas is not (1 or 2)) throw new ArgumentOutOfRangeException(nameof(columnas));
        if (!float.IsFinite(dpi) || dpi <= 0) throw new ArgumentOutOfRangeException(nameof(dpi));
        if (!float.IsFinite(zoom) || zoom < .1f || zoom > 5) throw new ArgumentOutOfRangeException(nameof(zoom));
        if (!float.IsFinite(separacion) || separacion < 0) throw new ArgumentOutOfRangeException(nameof(separacion));
        this.columnas = columnas;
        paginas = new RectangleF[medidas.Count];
        int filas = (medidas.Count + columnas - 1) / columnas;
        superiores = new float[filas]; inferiores = new float[filas];
        var anchos = new float[filas]; var altos = new float[filas];
        float ancho = 0;
        for (int i = 0; i < medidas.Count; i++)
        {
            var medida = medidas[i];
            if (!float.IsFinite(medida.Width) || !float.IsFinite(medida.Height) || medida.Width <= 0 || medida.Height <= 0)
                throw new ArgumentException("Las páginas deben tener dimensiones positivas y finitas.", nameof(medidas));
            float w = medida.Width * dpi * zoom, h = medida.Height * dpi * zoom;
            if (!float.IsFinite(w) || !float.IsFinite(h)) throw new ArgumentOutOfRangeException(nameof(medidas));
            int fila = i / columnas;
            anchos[fila] += w + (i % columnas == 0 ? 0 : separacion);
            altos[fila] = Math.Max(altos[fila], h);
            ancho = Math.Max(ancho, anchos[fila]);
            paginas[i] = new RectangleF(0, 0, w, h);
        }
        float y = 0;
        for (int fila = 0; fila < filas; fila++)
        {
            superiores[fila] = y;
            inferiores[fila] = y + altos[fila];
            float x = (ancho - anchos[fila]) / 2;
            for (int i = fila * columnas; i < Math.Min(medidas.Count, (fila + 1) * columnas); i++)
            {
                var papel = paginas[i];
                paginas[i] = new RectangleF(x, y + (altos[fila] - papel.Height) / 2, papel.Width, papel.Height);
                x += papel.Width + separacion;
            }
            y = inferiores[fila] + (fila + 1 < filas ? separacion : 0);
        }
        if (!float.IsFinite(ancho) || !float.IsFinite(y)) throw new ArgumentOutOfRangeException(nameof(medidas));
        TamanoDocumento = new SizeF(ancho, y);
    }

    internal RectangleF Pagina(int indice) => paginas[indice];
    internal int FilaInicio(int indice)
    {
        if ((uint)indice >= (uint)paginas.Length) throw new ArgumentOutOfRangeException(nameof(indice));
        return indice / columnas * columnas;
    }

    internal int[] Visibles(RectangleF ventanaDocumento)
    {
        if (paginas.Length == 0 || ventanaDocumento.Width <= 0 || ventanaDocumento.Height <= 0) return Array.Empty<int>();
        var visibles = new List<int>();
        int fila = BuscarFila(ventanaDocumento.Top);
        while (fila < superiores.Length && superiores[fila] < ventanaDocumento.Bottom)
        {
            for (int i = fila * columnas; i < Math.Min(paginas.Length, (fila + 1) * columnas); i++)
                if (paginas[i].IntersectsWith(ventanaDocumento)) visibles.Add(i);
            fila++;
        }
        return visibles.ToArray();
    }

    internal int PrimeraVisible(float superior)
        => paginas.Length == 0 ? -1 : BuscarFila(superior) * columnas;

    private int BuscarFila(float superior)
    {
        int inicio = 0, fin = inferiores.Length;
        while (inicio < fin)
        {
            int medio = inicio + (fin - inicio) / 2;
            if (inferiores[medio] <= superior) inicio = medio + 1;
            else fin = medio;
        }
        return Math.Min(inicio, Math.Max(0, inferiores.Length - 1));
    }

    internal int PaginaEnPunto(PointF punto)
    {
        if (paginas.Length == 0) return -1;
        int elegida = 0;
        double distanciaMinima = double.MaxValue;
        for (int i = 0; i < paginas.Length; i++)
            {
                var papel = paginas[i];
                double dx = punto.X - Math.Clamp(punto.X, papel.Left, papel.Right);
                double dy = punto.Y - Math.Clamp(punto.Y, papel.Top, papel.Bottom);
                double distancia = dx * dx + dy * dy;
                if (distancia < distanciaMinima) { distanciaMinima = distancia; elegida = i; }
            }
        return elegida;
    }
}
