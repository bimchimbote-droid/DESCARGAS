using System;
using System.Drawing;
using System.Linq;
using MYG_2027;

internal static class DisposicionPaginasCheck
{
    internal static void Ejecutar(Action<string> pasa)
    {
        var papeles = Enumerable.Repeat(new SizeF(8.27f, 11.69f), 39).ToArray();
        var una = new MYGDisposicionPaginas(papeles, 1, 96, .53f, 24);
        Exige(una.CantidadPaginas == 39 && una.Pagina(38).Bottom == una.TamanoDocumento.Height &&
            una.TamanoDocumento.Height > una.Pagina(0).Height * 39,
            "La extensión vertical debe incluir las 39 hojas y sus separaciones.");
        for (int i = 0; i < 39; i++)
        {
            var papel = una.Pagina(i);
            var visibles = una.Visibles(new RectangleF(0, papel.Top, una.TamanoDocumento.Width, papel.Height));
            Exige(visibles.SequenceEqual(new[] { i }) && una.PrimeraVisible(papel.Top) == i &&
                una.PaginaEnPunto(new PointF(papel.Left + 10, papel.Top + 10)) == i,
                "Desplazarse a una hoja debe mostrarla sin reiniciar el documento en la primera.");
            if (i > 0) Exige(papel.Top > una.Pagina(i - 1).Bottom, "Las hojas no deben solaparse.");
        }
        var dos = new MYGDisposicionPaginas(papeles, 2, 96, .4f, 24);
        Exige(dos.Pagina(0).Top == dos.Pagina(1).Top && dos.Pagina(2).Top > dos.Pagina(0).Bottom &&
            dos.FilaInicio(37) == 36 && dos.FilaInicio(38) == 38 &&
            dos.Pagina(38).Bottom == dos.TamanoDocumento.Height,
            "Dos columnas deben avanzar por filas e incluir la última hoja impar sin inventar otra.");
        Exige(dos.Visibles(new RectangleF(0, dos.Pagina(2).Top, dos.TamanoDocumento.Width, dos.Pagina(2).Height))
            .SequenceEqual(new[] { 2, 3 }), "La siguiente fila debe contener las páginas tercera y cuarta.");
        var pequenas = new MYGDisposicionPaginas(papeles, 2, 96, .1f, 24);
        Exige(pequenas.Visibles(new RectangleF(0, 0, pequenas.TamanoDocumento.Width, 900)).Length > 2,
            "Al alejar deben poder verse varias filas, sin limitar el documento a dos hojas.");
        Exige(pequenas.Visibles(new RectangleF(0, pequenas.TamanoDocumento.Height - 900, pequenas.TamanoDocumento.Width, 900))
            .Contains(38), "La barra al final debe alcanzar la última página.");
        var mixtas = new MYGDisposicionPaginas(new[] { new SizeF(8, 12), new SizeF(12, 8), new SizeF(8, 12) }, 2, 144, 5, 36);
        Exige(mixtas.Pagina(0).Top < mixtas.Pagina(1).Top && mixtas.Pagina(2).Top >= mixtas.Pagina(0).Bottom + 36 &&
            mixtas.Pagina(2).Right <= mixtas.TamanoDocumento.Width,
            "Papel mixto, DPI alto y zoom máximo deben conservar filas separadas y completas.");
        var vacia = new MYGDisposicionPaginas(Array.Empty<SizeF>(), 1, 96, 1, 24);
        Exige(vacia.TamanoDocumento.IsEmpty && vacia.Visibles(new RectangleF(0, 0, 100, 100)).Length == 0 &&
            vacia.PrimeraVisible(0) == -1, "Una vista vacía no debe producir páginas ficticias.");
        pasa("Desplazamiento continuo recorre 39 páginas, filas de dos columnas y la última hoja sin generar imágenes fuera de vista");
    }

    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }
}
