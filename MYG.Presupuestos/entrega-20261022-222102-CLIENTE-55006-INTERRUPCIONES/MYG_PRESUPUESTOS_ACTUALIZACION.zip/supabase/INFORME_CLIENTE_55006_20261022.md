# Cliente MYG ante filas ocupadas: verificación posterior a la instalación

## Estado confirmado

El usuario informó que el instalador 27 corregido terminó en Supabase con:

```text
resultado: PUBLICACION_SIN_ESPERA_INSTALADA
rechazo_inmediato_de_fila_ocupada: true
codigo_recurso_ocupado: 55006
```

Esto confirma la instalación comunicada por el usuario. No confirma una
publicación de 200,1 MiB ni identifica la causa de los HTTP 502/520 anteriores.

Quedan solucionados el defecto de espera por fila del contrato de confirmación
y la incompatibilidad del instalador con los saltos de línea de Windows. Las
comprobaciones anteriores de esos cambios se conservan como evidencia previa.

## Cobertura pendiente encontrada

Las pruebas anteriores de cliente contemplaban `55006` en guardado o con otro
estado HTTP. Faltaba probar, en la publicación con confirmación, la secuencia
exacta que devuelve el parche:

```text
HTTP 500 + 55006 + MYG_RECURSO_OCUPADO
  → conservar sesión, archivo e identificador
  → recuperar el pendiente desde disco
  → reenviar los mismos bytes mediante una acción explícita
  → aceptar únicamente una confirmación válida
  → cerrar el pendiente después de esa confirmación
```

La nueva suite focal cubre esa integración entre `ClienteSupabase` y
`ArchivoPublicacionPendienteNube`, con respuestas HTTP controladas. También
comprueba el marcador de otra publicación concurrente, `MYG_PUBLICACION_EN_CURSO`.
No se presenta el transporte controlado como una ejecución contra Supabase real.

## Manejo del rechazo en el software

La lectura del código de producción confirma:

- `ClienteNubeProyectos.cs` interpreta el SQLSTATE `55006` antes del mensaje
  genérico de HTTP 5xx. Conserva ese código e indica recurso ocupado o publicación
  en curso; no lo convierte en éxito ni en acceso denegado.
- La excepción conserva la sesión y no exige volver a iniciar sesión. El
  indicador `EsErrorDeConexion` se utiliza aquí para errores transitorios; no
  demuestra por sí mismo un corte físico de conexión.
- `ClienteNubePublicacion.cs` no reenvía automáticamente un POST por `55006`,
  `502` o `520`. La renovación y reenvío por `401` es un mecanismo diferente.
- Reintentar lee el intento guardado, con su UUID y contenido. La sonda de estado
  es informativa: `procesando` evita otro envío, y `existente` no sustituye la
  comparación completa del contenido de creación.
- En `MYG.Desktop/InicioNube.cs`, `almacen.Confirmar` solo se alcanza después de
  que `CrearProyectoConfirmacionAsync` devuelve un ACK válido y de comprobar que
  sigue siendo el cliente actual. El rechazo no ejecuta ese cierre. El bloque
  `finally` termina el estado de publicación de la ventana.

El contexto conservador de la excepción también indica resultado incierto.
Un `55006` conocido rechaza esa llamada; el texto no debe interpretarse como
confirmación de que publicó o de que el proyecto remoto no existe. Un intento
anterior con el mismo identificador requiere su propia confirmación.

## Verificaciones de esta entrega

Se ejecutó únicamente el nuevo selector:

```bash
dotnet build MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --publicacion-sin-espera
```

Resultado: **dos casos y 116 comprobaciones superadas**, compilación sin errores
ni advertencias. Se verificaron ambos marcadores `55006`, diagnóstico seguro y
sesión conservada, ausencia de reintento automático, persistencia y reapertura
del archivo con SHA-256 idéntico, POST idéntico byte a byte, precisión decimal y
Unicode, ACK con UUID incorrecto rechazado y ACK válido con revisión vigente y
permisos. El pendiente se cerró explícitamente solo después del ACK válido.

La primera ejecución aprobó 114 comprobaciones. La revisión independiente pidió
una aserción positiva del texto específico de recurso ocupado para que un
fallback genérico no pudiera pasar la prueba. Se recompiló y repitió únicamente
esta suite nueva después de ese refuerzo; de ahí las 116 comprobaciones finales.
La compilación final utilizó `-p:BuildProjectReferences=false` para reutilizar las
dependencias ya compiladas. No se volvieron a ejecutar suites anteriores.

El modo normal del programa de pruebas conserva las suites existentes y añade
la nueva. No se modificaron archivos de producción ni SQL en esta entrega.
Los veinte archivos previos ajenos al selector mantienen sus SHA-256; `Program.cs`
conserva sus cambios anteriores y añade únicamente la entrada de pruebas.

La interfaz WinForms no se ejecuta en este entorno Linux. Sus guardas de cierre
del pendiente se verifican por lectura del código; las pruebas automatizadas
ejercitan el cliente y almacenamiento reales con transporte HTTP controlado.

## Evidencia anterior reutilizada, sin repetir

1. **Servidor y PostgREST reales en laboratorio:** 16 comprobaciones SQL,
   28 comprobaciones del runner y nueve solicitudes HTTP. Con una fila ocupada,
   el propietario recibió HTTP 500/55006 en 0,0439 s; otra identidad conservó
   `42501`. Tras liberar la fila, el mismo UUID obtuvo ACK y un cuerpo diferente
   se rechazó con `22023`. Los snapshots de proyectos, miembros, operaciones e
   historial no cambiaron por los rechazos ni el replay.
2. **Instalador LF/CRLF:** 62 comprobaciones, preservación de cuerpo, atributos,
   permisos, configuración e idempotencia. La huella final corresponde al mismo
   cambio de bloqueo validado antes.
3. **Cargas grandes aisladas:** en ensayos sintéticos de unos 200 MiB, PostgREST
   limitado a 512 MiB fue terminado por memoria; con más memoria para la API y
   PostgreSQL limitado a 512 MiB, el proceso de PostgreSQL fue terminado durante
   la conversión anterior al cuerpo de la RPC. Una función que solo convertía
   los argumentos también falló antes de entrar. Estos resultados demuestran un
   riesgo del procesamiento, no la causa del incidente del servidor real.
4. **WAL fallido aislado:** publicaciones pequeñas y COMMIT correctos con el
   archivador fallando. No prueba que una retención prolongada, disco lleno o
   problemas de infraestructura sean inocuos; tampoco permite atribuirles el
   HTTP real.

No se repiten la batería completa, benchmarks, compilaciones generales ni estos
ensayos del servidor: la brecha nueva es la secuencia del cliente ante el rechazo.

## Investigación abierta de los 502/520 de 200,1 MiB

El tamaño de `Paquete guardado` no mide necesariamente el POST final después de
preparar los adjuntos. Tampoco los 300 MiB permitidos por MYG son una garantía de
capacidad en Nano. La memoria real de los procesos de Supabase, la duración
efectiva de la solicitud y su motivo de terminación siguen sin confirmarse.

El diagnóstico productivo recibido se tomó el 22/10 a las **16:57:36 de Perú**:
el postmaster había iniciado a las **16:42:15**, el archivador registraba cuatro
éxitos y cero fallos desde ese reinicio de estadísticas, no había `.ready`
pendientes ni otras sesiones cliente activas de esa base. No había evidencia de
atasco WAL o espera en ese instante. Los contadores recientes no reconstruyen
el fallo de las 11:24 ni descartan bloqueos pasados.

### Actualización: dos cierres no limpios confirmados

Mientras se terminaba esta entrega, el usuario aportó los registros solicitados
y confirmó que no reinició, pausó ni modificó intencionalmente la infraestructura.
Se incorporan estos datos sin repetir las pruebas del cliente ni del servidor:

| Hora Perú del 22/10 | Hora UTC | Evidencia aportada |
|---|---|---|
| 16:42:15 | 21:42:15 | `database system was interrupted`, `not properly shut down`, recuperación automática, redo, checkpoint de fin de recuperación y disponibilidad. El inicio del postmaster a esa hora también figura en la captura anterior. |
| 17:08:48–17:08:49 | 22:08:48–22:08:49 | `starting PostgreSQL 17.11`, cierre anterior no limpio, recuperación automática, redo y disponibilidad. |

Esto demuestra interrupciones y recuperación de PostgreSQL en el servidor real.
El inicio del postmaster de la primera captura y el mensaje `starting PostgreSQL`
de la segunda muestran arranques del proceso principal observado. No son
únicamente un mensaje del cliente o una consulta bloqueada. El motivo de la
terminación sigue sin constar. Un rechazo SQL controlado `55006`, un timeout
ordinario de consulta o una desconexión de un cliente no demuestran por sí mismos
que el proceso principal haya sido terminado.

En el ensayo grande anterior, PostgreSQL registró la terminación de un proceso
de consulta y la reinicialización de procesos hijos; no se equipara ese patrón
con los arranques del proceso principal ahora aportados. Una terminación del
contenedor completo por memoria es una posibilidad distinta que requiere su
propio evento de infraestructura, al igual que una expulsión de nodo, failover o
reinicio gestionado. Los ensayos existentes no eligen entre esas causas.

Las horas `last known up` de 21:40:54 y 22:07:20 UTC son referencias de estado
persistido de PostgreSQL, no horas exactas demostradas de la caída. No se calculan
duraciones de indisponibilidad restándolas a las horas de recuperación. El fin
correcto del redo no certifica por sí solo el contenido de cada proyecto ni
demuestra pérdida de datos.

La captura anterior de las 16:57 está entre ambos eventos. Sus estadísticas no
describen el segundo ni explican el primero. Tampoco se han correlacionado estos
eventos con una solicitud HTTP 502/520 específica; el 502 de las 11:24 es anterior.
El aviso general de Supabase de que investiga un problema técnico no identifica
el proyecto, región o motivo de estas interrupciones.

Se intentó consultar la API pública oficial de estado de Supabase para contrastar
el aviso, pero la salida de red de este entorno devolvió `403 Forbidden` al
establecer la conexión. No se obtuvo información del incidente público y no se
atribuye el fallo a ese aviso.

### Evidencia que todavía falta

- **Motivo anterior al arranque**, especialmente alrededor de 21:42:15 y
  22:08:48 UTC: líneas que identifiquen señal/exit code, proceso terminado,
  `PANIC`, petición de cierre, error de I/O o falta de espacio. No es necesario
  reenviar las mismas líneas de recuperación ya aportadas.
- Si PostgreSQL no lo registra, eventos del contenedor o infraestructura que
  indiquen `OOMKilled`, expulsión/reinicio del nodo, mantenimiento, failover u
  otra causa. La ausencia de un mensaje OOM en el registro visible no lo demuestra
  ni lo descarta. Un exit 137 o señal 9 aislados tampoco bastan para atribuirlo a
  memoria sin el evento del sistema correspondiente.
- RAM/CPU, conexiones y almacenamiento libre/I/O del intervalo de terminación,
  si el proveedor conserva esas métricas. La configuración de 512 MB y los
  `shared_buffers` no reemplazan una medición del consumo.
- **Correlación con la publicación:** referencia y hora UTC del POST fallido
  en los intervalos **21:40–21:44 o 22:06–22:10 UTC** (16:40–16:44 o
  17:06–17:10 de Perú), ruta, duración y SQLSTATE si constan. Esos datos permiten
  separar una interrupción durante el procesamiento de otra ocurrida sin un
  envío activo. La coincidencia aproximada de horas por sí sola no prueba causa.

No se pide otra ejecución del paquete grande. Si los logs del panel solo muestran
la recuperación y no el motivo de la terminación, la siguiente evidencia depende
de los registros de infraestructura de Supabase. No hay otro cambio de la RPC
justificado por esas líneas de recuperación. La relación causal con los errores
de archivado WAL anteriores sigue sin demostrarse.

Texto sugerido para que el propietario consulte al soporte de Supabase, sin
enviar claves ni contenido de obras:

> En PostgreSQL 17.11, instancia Nano Free de hasta 512 MB, observamos dos
> recuperaciones tras cierres no limpios el 22/10/2026 a las 21:42:15 UTC y
> 22:08:48–22:08:49 UTC. No hubo reinicios, pausas ni cambios intencionales por
> nuestra parte. Los logs visibles solo muestran interrupted/not properly shut
> down, redo y posterior disponibilidad. Solicitamos identificar el motivo de
> terminación del postmaster/contenedor y si hubo OOM, evento de nodo,
> mantenimiento/failover, señal de terminación o error de almacenamiento.
> También investigamos POST con HTTP 502/520 a
> `/rest/v1/rpc/myg_nube_crear_confirmacion`; todavía no se ha demostrado relación
> temporal o causal con estas dos interrupciones. ¿Estuvo este proyecto y su
> región afectado por el incidente técnico anunciado en el panel?

Este texto es un borrador; no se ha enviado ningún mensaje externo.

## Qué hacer con los archivos

| Archivo | Acción |
|---|---|
| `MYG.PruebasNube/Program.cs` | Reemplazar conservando la ruta; añade el selector focal y la suite al modo normal. |
| `MYG.PruebasNube/PublicacionSinEsperaClienteCheck.cs` | Añadir a esa carpeta; comprueba el cliente y los pendientes con datos sintéticos. |
| `supabase/INFORME_CLIENTE_55006_20261022.md` | Añadir y leer; no se ejecuta en Supabase. |

Esta entrega contiene pruebas e informe. No requiere otro SQL en Supabase ni
cambios de claves o recompilación del ejecutable MYG instalado. Para ejecutar
las pruebas se necesita el SDK .NET 10 y las dependencias del repositorio.

Copiar los archivos desde la raíz del ZIP a la carpeta de la solución,
manteniendo las rutas y respaldando cambios propios antes de reemplazarlos.
Después de revisar los cambios junto con el trabajo pendiente anterior, hacer
Commit y Push en el repositorio de código. Publicar el ZIP en `DESCARGAS` no
actualiza automáticamente `MYG.Presupuestos`.
