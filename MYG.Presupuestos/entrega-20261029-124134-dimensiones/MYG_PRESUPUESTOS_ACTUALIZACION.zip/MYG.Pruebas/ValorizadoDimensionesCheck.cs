using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ValorizadoDimensionesCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static string Ver(MYGHojaMetrado hoja, string direccion) => new MYGHojaCalculo(hoja).Mostrar(direccion);
    private static int Fila(MYGHojaMetrado hoja, string descripcion) => hoja.Celdas.Keys
        .Where(c => MYGHojaCalculo.Coordenadas(c).Columna == 2 && Ver(hoja, c) == descripcion)
        .Select(c => MYGHojaCalculo.Coordenadas(c).Fila).Single();

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        const string codigoLargo = "0004.0003.0004.0006.00000062";
        const string unidadLarga = "m3/estructura";
        const string descripcionCorta = "MÓDULO DIRECCIONABLE";
        const string descripcionLarga = "GABINETE METÁLICO CON FUENTE AUXILIAR PARA SISTEMA DE DETECCIÓN Y ALARMA DE INCENDIOS, " +
            "INCLUYE CABLEADO, ACCESORIOS, PRUEBAS DE FUNCIONAMIENTO, MONTAJE, CONEXIÓN Y PUESTA EN SERVICIO DEL EQUIPO COMPLETO";
        const string descripcionConSaltos = "PRIMERA LÍNEA\nSEGUNDA LÍNEA\nTERCERA LÍNEA\nCUARTA LÍNEA\nQUINTA LÍNEA\nSEXTA LÍNEA";
        var documento = MYGProyectoStorage.Nuevo("PROYECTO DIMENSIONES DEL VALORIZADO");
        documento.Datos = new() { Propietario = "PROPIETARIO QA", Departamento = "ÁNCASH", Provincia = "SANTA", Distrito = "CHIMBOTE" };
        var presupuesto = documento.Presupuestos.Single();
        presupuesto.Nombre = "PRESUPUESTO DIMENSIONES";
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        void Partida(string id, string codigo, string descripcion, string unidad, decimal cantidad, decimal precio)
        {
            presupuesto.Items.Add(new()
            {
                Id = id, IdLocalMYG = id, Item = codigo, Descripcion = descripcion, Unidad = unidad, TipoPropuesta = "PARTIDA",
                Costos = new() { Cantidad = cantidad, PrecioDirecto = precio }
            });
            plan.Tareas.Add(new() { Id = "T-" + id, Nombre = descripcion, Codigo = codigo,
                PresupuestoId = presupuesto.Id, PartidaId = id, DuracionDias = 1 });
        }
        Partida("CORTA", "01", descripcionCorta, "und", 11, 333.50m);
        Partida("LARGA", codigoLargo, descripcionLarga, unidadLarga, 123456.1234m, 1234567.89m);
        Partida("SALTOS", "03", descripcionConSaltos, "und", 2.1256m, 12.34m);
        MYGProyectoStorage.Validar(documento);
        var pequeno = MYGProyectoStorage.Copia(documento);
        foreach (var i in pequeno.Presupuestos.Single().Items)
        { i.Item = "01"; i.Unidad = "und"; i.Costos.Cantidad = 1; i.Costos.PrecioDirecto = 1; }
        var hojaPequena = MYGReportesCronograma.CrearValorizado(pequeno, plan).Single().Hoja;
        var sinPieFijo = MYGReportesCronograma.CrearValorizado(documento, plan).Single().Hoja;
        presupuesto.Costos.PiePersonalizado = new()
        { new() { Id = "fijo-dimensiones", Nombre = "SUMINISTRO Y PUESTA EN SERVICIO", Modo = MYGModoFilaResumen.ValorManual,
            ValorManual = 1_000_000_000_000m } };
        plan.OpcionesVista["Presentacion"] = JsonSerializer.Serialize(new
        { ImprimirInformacionPagina = true, TipoInformacionPagina = "Número", TituloPagina = "CONTROL DE PRESENTACIÓN" });
        string documentoAntes = JsonSerializer.Serialize(documento), planAntes = JsonSerializer.Serialize(plan);
        var reporte = MYGReportesCronograma.CrearValorizado(documento, plan).Single();
        var h = reporte.Hoja; var calculo = new MYGHojaCalculo(h);
        int corta = Fila(h, descripcionCorta), larga = Fila(h, descripcionLarga), saltos = Fila(h, descripcionConSaltos);
        Exige(h.AnchosColumnas[2] > 330 && new[] { 1, 3, 4, 5 }.All(c => h.AnchosColumnas[c] > hojaPequena.AnchosColumnas[c]) &&
            h.AnchosColumnas[6] > sinPieFijo.AnchosColumnas[6] && h.AnchosColumnas[7] > sinPieFijo.AnchosColumnas[7],
            "El valorizado debe ampliar descripción y calcular anchos por códigos, unidades, cantidades, precios y totales del pie, también en los meses.");
        // Una columna de XLSX expresa su ancho en caracteres del estilo Normal,
        // no en los píxeles con los que el motor mide la tabla. Este límite
        // independiente impide que un ajuste relativo siga siendo insuficiente
        // después de la conversión a unidades de columna de Excel.
        decimal CaracteresExcel(int columna) => (h.AnchosColumnas[columna] - 5m) / 7m;
        foreach (int columna in new[] { 4, 5, 6, 7 })
        {
            var visibles = h.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == columna &&
                decimal.TryParse(c.Value.Contenido, NumberStyles.Number, CultureInfo.InvariantCulture, out _))
                .Select(c => decimal.Parse(c.Value.Contenido, CultureInfo.InvariantCulture)
                    .ToString(c.Value.FormatoNumero, CultureInfo.InvariantCulture)).ToArray();
            decimal minimo = visibles.Max(t => t.Count(char.IsDigit) + (t.Length - t.Count(char.IsDigit)) * .5m + 1);
            Exige(CaracteresExcel(columna) >= minimo,
                "El ancho guardado de una columna numérica debe admitir todos sus dígitos formateados, separadores y margen en las unidades reales de Excel.");
        }
        Exige(CaracteresExcel(1) >= codigoLargo.Count(char.IsDigit) + codigoLargo.Count(c => c == '.') * .5m + 1,
            "La columna Item debe admitir el código completo en unidades de ancho de Excel, sin partir sus dígitos en otra línea.");
        Exige(Ver(h, "A" + larga) == codigoLargo && Ver(h, "C" + larga) == unidadLarga &&
            new[] { "A", "C", "D", "E", "F", "G" }.All(c => !h.Celdas[c + larga].AjustarTexto) &&
            !h.Celdas["C9"].AjustarTexto,
            "Códigos con ceros, unidades, cabeceras cortas y valores numéricos deben conservarse completos sin dividirse en varias líneas.");
        Exige(h.AltosFilas[larga] > h.AltosFilas[corta] && h.AltosFilas[saltos] > h.AltosFilas[corta] &&
            h.AltosFilas[saltos] >= 6 * 12 && h.Celdas["B" + larga].AjustarTexto &&
            h.Celdas["B" + saltos].AjustarTexto && h.AltosFilas[9] >= 4 * 12 &&
            h.Celdas.Values.All(c => c.AlineacionVertical == "Centro"),
            "Las alturas deben seguir la descripción, sus saltos y la cabecera mensual, manteniendo todas las celdas centradas verticalmente incluido el pie de página.");
        string cantidad = h.Celdas["D" + corta].FormatoNumero;
        decimal precio = 0;
        Exige(calculo.Numero("D" + corta) == 11 && calculo.Numero("D" + saltos) == 2.1256m &&
            cantidad == "#,##0.00" &&
            11m.ToString(cantidad, CultureInfo.InvariantCulture) == "11.00" &&
            2.1256m.ToString(cantidad, CultureInfo.InvariantCulture) == "2.13" &&
            !h.Celdas["D" + corta].Contenido.StartsWith('=') &&
            decimal.TryParse(h.Celdas["E" + larga].Contenido, NumberStyles.Number, CultureInfo.InvariantCulture, out precio) && precio == 1234567.89m &&
            calculo.Numero(h.CeldaTotal) == MYGPiePresupuesto.Resumen(documento.Presupuestos).Total &&
            JsonSerializer.Serialize(documento) == documentoAntes && JsonSerializer.Serialize(plan) == planAntes,
            "El ajuste visual no debe crear cantidades con punto final, perder decimales, convertir importes a texto ni alterar costos, presupuesto o cronograma.");
        var numericas = h.Celdas.Where(c => decimal.TryParse(c.Value.Contenido, NumberStyles.Number,
            CultureInfo.InvariantCulture, out _)).ToArray();
        Exige(numericas.Length > 0 && numericas.All(c => c.Value.FormatoNumero is "#,##0.00" or "0.00%"),
            "Todas las cantidades, precios, importes y porcentajes numéricos del valorizado deben mostrarse con exactamente dos decimales, conservando su valor interno.");
        pasa("Valorizado dimensiona columnas según contenido y pie, amplía descripción, adapta alturas y centra verticalmente sin cambiar importes");

        string ruta = Path.Combine(carpeta, "Valorizado dimensiones.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, new[] { reporte });
        var leido = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta).Single(), h.CeldaTotal);
        Exige(Enumerable.Range(1, h.Columnas).All(c => Math.Abs(leido.AnchosColumnas[c] - h.AnchosColumnas[c]) <= 1) &&
            new[] { corta, larga, saltos, 9 }.All(f => leido.AltosFilas[f] == h.AltosFilas[f]) &&
            leido.Celdas.Values.All(c => c.AlineacionVertical == "Centro") &&
            Ver(leido, "A" + larga) == codigoLargo && Ver(leido, "B" + saltos) == descripcionConSaltos &&
            !leido.Celdas["F" + larga].AjustarTexto && leido.Celdas["B" + larga].AjustarTexto &&
            numericas.All(c => leido.Celdas[c.Key].FormatoNumero == c.Value.FormatoNumero) &&
            new MYGHojaCalculo(leido).Numero(leido.CeldaTotal) == calculo.Numero(h.CeldaTotal),
            "El XLSX reabierto debe conservar anchos, altos, alineación vertical, saltos y valores numéricos del informe dimensionado.");
        using (var zip = ZipFile.OpenRead(ruta))
        using (var sheetStream = zip.GetEntry("xl/worksheets/sheet1.xml").Open())
        using (var stylesStream = zip.GetEntry("xl/styles.xml").Open())
        {
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            var sheet = XDocument.Load(sheetStream); var styles = XDocument.Load(stylesStream);
            var formatos = styles.Root.Element(ns + "cellXfs").Elements(ns + "xf").ToArray();
            foreach (var celda in sheet.Descendants(ns + "c"))
            {
                int estilo = (int?)celda.Attribute("s") ?? 0;
                Exige((string)formatos[estilo].Element(ns + "alignment")?.Attribute("vertical") == "center",
                    "El archivo OOXML debe guardar alineación vertical central en todas las celdas exportadas.");
            }
            var precioXml = sheet.Descendants(ns + "c").Single(c => (string)c.Attribute("r") == "E" + larga);
            var totalXml = sheet.Descendants(ns + "c").Single(c => (string)c.Attribute("r") == h.CeldaTotal);
            Exige(precioXml.Attribute("t") == null && totalXml.Attribute("t") == null &&
                decimal.Parse(precioXml.Element(ns + "v").Value, CultureInfo.InvariantCulture) == precio &&
                decimal.Parse(totalXml.Element(ns + "v").Value, CultureInfo.InvariantCulture) == calculo.Numero(h.CeldaTotal) &&
                sheet.Descendants(ns + "row").Where(r => (int)r.Attribute("r") == saltos)
                    .All(r => (decimal)r.Attribute("ht") == h.AltosFilas[saltos] * .75m),
                "XLSX debe conservar importes numéricos y escribir la altura explícita de las descripciones multilínea.");
        }
        pasa("XLSX del valorizado conserva anchos, alturas, números y alineación central al reabrirlo y en sus estilos OOXML");
    }
}
