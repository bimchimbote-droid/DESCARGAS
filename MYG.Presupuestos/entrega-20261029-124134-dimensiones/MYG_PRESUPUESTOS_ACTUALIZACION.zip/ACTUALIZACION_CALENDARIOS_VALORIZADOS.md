# Calendarios por presupuesto y proyecto

Esta actualización parte de `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`0fce317f93a0ad0627101e173dd26e3f2870740c`. Los cambios se prepararon en el checkout
aislado de trabajo; la entrega no hace Commit ni Push al repositorio del código.

## Revisión de anchos y alturas

Esta revisión es incremental sobre el ZIP de calendarios publicado en
`DESCARGAS`, commit `cfa2853077981f71c38aaed92dcb73c4ad488f26`.
Debe tener instalada esa entrega antes de aplicar esta revisión.

Las columnas de ítem, unidad, cantidad, precio y parcial se dimensionan según
el contenido mostrado, incluidos los importes más grandes del pie. Los meses
también contemplan sus totales. Los códigos y números no se parten en líneas.
La descripción es más ancha y la altura de cada fila se calcula para su texto,
incluidos los saltos de línea. Cabeceras, cuerpo y pie quedan centrados
verticalmente. Cantidades, precios, parciales y totales se muestran con
exactamente dos decimales; los porcentajes también muestran dos decimales.
La precisión interna de los cálculos se conserva.

No se cambian los costos, porcentajes ni fechas del cronograma. Los anchos y
altos se calculan al generar una nueva exportación; los archivos Excel ya
exportados no se modifican automáticamente. El cálculo reserva espacio para
la fuente del informe sin necesitar Microsoft Excel instalado.

## Uso

1. Seleccione el presupuesto que desea consultar en la vista Presupuesto.
2. Abra Cronograma y despliegue **Calendario de adquisiciones ▾** o
   **Calendario valorizado ▾**.
3. Elija **Calendario del presupuesto** para el presupuesto activo, o
   **Calendario del proyecto** para todos sus presupuestos.
4. Revise el informe en la vista previa y use su opción **Exportar a XLSX**.
   No se necesita Microsoft Excel para generar XLSX.

El valorizado incluye ítem, descripción, unidad, cantidad, precio, parcial,
meses numerados con sus fechas, títulos jerárquicos, pie de presupuesto,
total, avance mensual y avance acumulado. El avance es el financiero
**programado**, calculado sobre los importes del calendario; no representa una
medición física ejecutada ni una valorización aprobada.

El calendario toma las partidas vinculadas al cronograma. No crea tareas ni
costos para partidas que no estén programadas. Antes de exportar, revise esos
vínculos y las fechas; sincronice el cronograma si corresponde. Las monedas se
mantienen separadas, sin convertirlas ni sumarlas entre sí.

## Instalación manual

1. En `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, respalde sus archivos o confirme
   sus cambios locales en Visual Studio. Si usa otra ubicación, adapte la ruta.
2. Compruebe la rama `main`, el commit base y la entrega previa indicados arriba. Si modificó alguno
   de los archivos de la entrega después de ese commit, compare y combine los
   cambios antes de reemplazarlo; reemplazarlo completo puede perder su trabajo.
3. Cierre la aplicación MYG. Descargue y extraiga
   `MYG_PRESUPUESTOS_ACTUALIZACION.zip` en una carpeta temporal.
4. Copie el contenido en la raíz del proyecto, conservando exactamente las rutas
   relativas. Reemplace los archivos existentes y cree los nuevos. No hay archivos
   que eliminar, parches que aplicar ni bases de datos que sustituir.
5. Restaure, compile y ejecute las pruebas indicadas abajo.
6. Abra MYG en Windows y compruebe los pasos de uso con un presupuesto de prueba.

## Compilación y pruebas

Tecnologías: C#, SDK .NET 10 (validación con 10.0.100), SQLite, Windows Forms/WPF
y referencias de Revit 2027. No se agregan paquetes NuGet ni migraciones SQL.

Desde la raíz del repositorio:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
```

Validación de esta entrega (29 de octubre de 2026, Linux x64, SDK 10.0.100):

- Solución completa compilada: 0 errores y 0 advertencias. En el entorno de
  validación se añadió `-p:UseSharedCompilation=false` al comando de compilación.
- Suite principal: 669 comprobaciones completadas, salida 0. Incluye exportación
  y reapertura de XLSX, jerarquía, fechas, alcance, tasas distintas, pies mixtos,
  fórmulas, valores manuales, pie único Delphin, precisión y redondeo mensual.
  Las pruebas nuevas comprueban anchos en unidades Excel, alturas por contenido,
  alineación central y dos decimales, incluidos los estilos del archivo XLSX.
- Colaboración: en la entrega anterior se aprobaron 39 grupos principales y
  982 comprobaciones de contrato HTTP, con SQLite y HTTP simulado. Esa suite no
  se repitió en esta revisión de dimensiones y formatos.
- Omitidas: Named Pipes de Windows y muestra externa LLACUSBAMBA no proporcionada.
- Pruebas de interfaz: compiladas, no ejecutadas en Linux. Su ejecución visual
  en Windows, Microsoft Excel y una sesión real de Revit queda pendiente.

`UseRevitReferencePackages=true` permite compilar sin una instalación de Revit.
En Windows con Revit 2027 instalado puede compilar normalmente con sus DLL
locales, según `LEEME.md`. El conector y sus referencias no necesitan cambiar
para esta actualización.

La compilación en Linux incluye los proyectos de interfaz, pero no ejecuta
Windows Forms/WPF, pruebas visuales ni Revit. Para ejecutar las comprobaciones
de interfaz en Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Compruebe manualmente ambos desplegables; cambie de presupuesto y contraste el
alcance de las dos opciones. Exporte XLSX y revise datos del proyecto, códigos,
fechas mensuales, pie configurado, total, porcentajes y formatos de impresión.
Pruebe también un proyecto con varios presupuestos y monedas distintas.
En esta revisión, revise especialmente códigos largos, precios y totales del
pie, descripciones extensas y alineación vertical. Si cambia la fuente o los
anchos manualmente en Excel después de exportar, revise nuevamente el ajuste.

## Actualizar su repositorio de código

En Visual Studio, abra **Cambios de Git**, revise el diff y compruebe la rama
`main`. Incluya los archivos de la entrega, escriba un mensaje de Commit y haga
Commit. Después use Push y verifique en GitHub que la rama contiene su Commit.
La publicación del ZIP en el repositorio independiente `DESCARGAS` no aplica los
archivos a su copia local ni publica estos cambios en `MYG.Presupuestos`.
