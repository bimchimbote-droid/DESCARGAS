using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

public static partial class MYGReportesCronograma
{
    private sealed record FilaValorizada(string Codigo, string Descripcion, string Unidad,
        decimal? Cantidad, decimal? Precio, decimal Parcial, decimal[] Meses, bool Titulo);

    /// <summary>Calendario mensual continuo de las partidas vinculadas al plan.
    /// El presupuesto opcional se filtra después de calcular todas las tareas,
    /// conservando las fechas de las dependencias entre presupuestos.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> CrearValorizado(
        MYGProyectoDocumento documento, MYGCronograma plan, string presupuestoId = null)
    {
        var partidas = PrepararPartidas(documento, plan, out _, presupuestoId);
        string titulo = "CRONOGRAMA VALORIZADO DEL " + (presupuestoId == null ? "PROYECTO" : "PRESUPUESTO");
        if (partidas.Count == 0)
            return new[] { SinDatos(documento, plan, titulo, "Sin partidas de presupuesto vinculadas al cronograma.") };
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var reportes = new List<MYGHojaReporteProyecto>();
        var gruposDimensiones = new List<List<MYGHojaMetrado>>();
        int numero = 0;
        foreach (var moneda in partidas.GroupBy(p => Moneda(p.Presupuesto), StringComparer.OrdinalIgnoreCase))
        {
            var hojasMoneda = new List<MYGHojaMetrado>();
            gruposDimensiones.Add(hojasMoneda);
            var entradas = moneda.Select(p => (Partida: p, Meses: Repartir(p, calendario))).ToArray();
            var periodos = Periodos(entradas.Min(p => p.Partida.Fila.Inicio), entradas.Max(p => p.Partida.Fila.Fin), false);
            if (periodos.Length > 194)
                throw new InvalidDataException("El cronograma valorizado admite hasta 194 meses por moneda. Reduzca el alcance de la programación para exportarlo.");
            var presupuestos = entradas.Select(e => e.Partida.Presupuesto).DistinctBy(p => p.Id)
                .OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.OrdinalIgnoreCase).ToArray();
            var filas = new List<FilaValorizada>();
            var calculos = new List<MYGCalculoPresupuesto>();
            var directos = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in presupuestos)
            {
                var propias = entradas.Where(e => e.Partida.Presupuesto.Id == p.Id).ToArray();
                var porId = p.Items.ToDictionary(i => i.Id, StringComparer.OrdinalIgnoreCase);
                var montos = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
                var vinculadas = propias.ToDictionary(e => e.Partida.Partida.Id, StringComparer.OrdinalIgnoreCase);
                foreach (var entrada in propias)
                {
                    var i = entrada.Partida.Partida;
                    var mensual = periodos.Select(m => entrada.Meses.GetValueOrDefault(m.Inicio)).ToArray();
                    montos.Add(i.Id, mensual);
                    string padre = i.ParentId;
                    var vistos = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { i.Id };
                    while (padre != null && porId.TryGetValue(padre, out var ancestro))
                    {
                        if (!vistos.Add(padre)) throw new InvalidDataException("La estructura del presupuesto contiene un ciclo.");
                        if (!montos.TryGetValue(padre, out var suma)) montos.Add(padre, suma = new decimal[periodos.Length]);
                        for (int n = 0; n < mensual.Length; n++) suma[n] += mensual[n];
                        padre = ancestro.ParentId;
                    }
                }
                var meses = periodos.Select(m => propias.Sum(e => e.Meses.GetValueOrDefault(m.Inicio))).ToArray();
                decimal directo = meses.Sum();
                directos.Add(p.Id, meses);
                // Los análisis se calcularon en la copia completa. Este snapshot
                // sólo entrega al motor del pie el costo directo ya calculado;
                // no corta referencias de subanálisis ni grava de nuevo insumos.
                var alcance = new MYGPresupuestoDocumento
                {
                    Id = p.Id, Item = p.Item, Nombre = p.Nombre, Posicion = p.Posicion,
                    Costos = MYGProyectoStorage.Copia(p.Costos),
                    Items = new() { new() { Id = "programado", IdLocalMYG = "programado", TipoPropuesta = "PARTIDA",
                        Costos = new() { Cantidad = 1, PrecioDirecto = directo } } }
                };
                // El parcial nativo puede conservar más decimales que la
                // presentación del precio unitario. Evitar redondearlo otra vez
                // sin alterar la precisión propia de los conceptos del pie.
                MYGMotorPresupuestos.CapturarPrecioDelphin(alcance, alcance.Items[0], directo, directo);
                calculos.Add(MYGMotorPresupuestos.CrearCalculo(alcance));
                filas.Add(new(p.Item ?? "", p.Nombre ?? "", "", null, null, directo, meses, true));
                foreach (var i in MYGOrdenPresupuestos.FilasOrdenadas(p))
                {
                    if (!montos.TryGetValue(i.Id, out var mensual)) continue;
                    bool esTitulo = MYGProyectoStorage.EsTitulo(i);
                    if (!esTitulo && !vinculadas.ContainsKey(i.Id)) continue;
                    var calculo = propias[0].Partida.Calculo;
                    filas.Add(new(i.Item ?? "", i.Descripcion ?? "", esTitulo ? "" : i.Unidad ?? "",
                        esTitulo ? null : calculo.Cantidad(i), esTitulo ? null : calculo.Analizar(i).PrecioUnitario,
                        mensual.Sum(), mensual, esTitulo));
                }
            }
            var pie = MYGPiePresupuesto.Filas(calculos);
            decimal total = MYGPiePresupuesto.Resumen(calculos).Total;
            var pieMensual = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
            var totalesMes = new decimal[periodos.Length];
            // Los fijos de un pie Delphin compartido se aplican una sola vez.
            var gruposPie = MYGPiePresupuesto.EsPieUnicoDelphin(calculos.Select(c => c.Presupuesto))
                ? new[] { calculos.ToArray() } : calculos.Select(c => new[] { c }).ToArray();
            foreach (var grupo in gruposPie)
            {
                var pesos = Enumerable.Range(0, periodos.Length).Select(n => grupo.Sum(c => directos[c.Presupuesto.Id][n])).ToArray();
                int decimales = grupo.Max(c => Math.Max(c.Presupuesto.Costos.DecimalesPrecio,
                    c.Presupuesto.Costos.PieDelphin?.Decimales ?? 0));
                var estado = pesos.ToArray();
                decimal acumuladoPie = pesos.Sum();
                var conceptos = MYGPiePresupuesto.Filas(grupo);
                var mesesGrupo = new Dictionary<string, decimal[]>(StringComparer.OrdinalIgnoreCase);
                bool nativo = grupo.All(c => MYGPiePresupuesto.EsPieDelphin(c.Presupuesto));
                var configuracionNativa = nativo ? grupo.OrderBy(c => c.Presupuesto.Posicion).First().Presupuesto.Costos.PieDelphin : null;
                for (int indice = 0; indice < conceptos.Count; indice++)
                {
                    var concepto = conceptos[indice];
                    decimal[] reparto;
                    if (concepto.Id == MYGPiePresupuesto.IdCostoDirecto) reparto = pesos.ToArray();
                    else
                    {
                        bool acumulada = concepto.Id == MYGPiePresupuesto.IdTotal ||
                            (configuracionNativa != null ? configuracionNativa.Filas[indice - 1].Tipo == "F" :
                                grupo[0].Presupuesto.Costos.PiePersonalizado == null && concepto.Id == "parcial");
                        // Una fila F muestra el acumulado: no vuelve a sumar sus
                        // componentes. Repartir sólo su diferencia conserva tanto
                        // el total nativo como la conciliación de cada mes.
                        decimal incremento = acumulada ? concepto.Importe - acumuladoPie : concepto.Importe;
                        var cambio = RepartirImporteValorizado(incremento, pesos, decimales);
                        for (int n = 0; n < estado.Length; n++) estado[n] += cambio[n];
                        acumuladoPie += incremento;
                        reparto = acumulada ? estado.ToArray() : cambio;
                    }
                    mesesGrupo[concepto.Id] = reparto;
                    if (!pieMensual.TryGetValue(concepto.Id, out var meses)) pieMensual.Add(concepto.Id, meses = new decimal[periodos.Length]);
                    for (int n = 0; n < meses.Length; n++) meses[n] += reparto[n];
                }
                var resumenGrupo = MYGPiePresupuesto.Resumen(grupo);
                // El motor agrega el Parcial de todo el alcance aunque algunos
                // pies personalizados/nativos no tengan una fila con ese ID.
                if (pie.Any(f => f.Id == "parcial") && !mesesGrupo.ContainsKey("parcial"))
                {
                    decimal[] subtotal;
                    if (grupo[0].Presupuesto.Costos.PiePersonalizado != null) subtotal = estado.ToArray();
                    else
                    {
                        var filaSubtotal = configuracionNativa?.Filas.LastOrDefault(f =>
                            f.Clave.Equals("user_sub_total", StringComparison.OrdinalIgnoreCase) ||
                            f.Clave.Equals("parcial_presupuesto", StringComparison.OrdinalIgnoreCase));
                        subtotal = filaSubtotal != null && mesesGrupo.TryGetValue("delphin:" + filaSubtotal.Clave, out var nativos)
                            ? nativos : RepartirImporteValorizado(resumenGrupo.Subtotal, pesos, decimales);
                    }
                    if (!pieMensual.TryGetValue("parcial", out var parciales)) pieMensual.Add("parcial", parciales = new decimal[periodos.Length]);
                    for (int n = 0; n < subtotal.Length; n++) parciales[n] += subtotal[n];
                }
                decimal totalGrupo = resumenGrupo.Total;
                var ajusteFinal = RepartirImporteValorizado(totalGrupo - acumuladoPie, pesos, decimales);
                for (int n = 0; n < estado.Length; n++) totalesMes[n] += estado[n] + ajusteFinal[n];
            }
            // El modelo de hoja admite 200.000 celdas. Sólo la última
            // continuación contiene el pie y el total global, sin duplicarlos.
            int maxFilas = Math.Min(10000, 200000 / (6 + periodos.Length));
            int porHoja = Math.Min(FilasPorHoja, maxFilas - pie.Count - 20);
            if (porHoja < 1) throw new InvalidDataException("El pie del presupuesto supera las filas disponibles para exportar.");
            var partes = filas.Chunk(porHoja).ToArray();
            for (int parte = 0; parte < partes.Length; parte++)
            {
                var h = Hoja("Valorizado " + ++numero, new[] { 90, 420, 44, 78, 78, 100 }, periodos.Length, 105);
                hojasMoneda.Add(h);
                CabeceraValorizado(h, documento, presupuestoId, titulo, moneda.Key, periodos);
                int fila = 10;
                foreach (var dato in partes[parte])
                {
                    Texto(h, fila, 1, dato.Codigo, dato.Titulo);
                    Texto(h, fila, 2, dato.Descripcion, dato.Titulo);
                    Texto(h, fila, 3, dato.Unidad, alineacion: "Centro");
                    if (dato.Cantidad.HasValue) Numero(h, fila, 4, dato.Cantidad.Value, "#,##0.00");
                    if (dato.Precio.HasValue) Numero(h, fila, 5, dato.Precio.Value);
                    Numero(h, fila, 6, dato.Parcial, negrita: dato.Titulo);
                    for (int n = 0; n < periodos.Length; n++)
                        if (dato.Meses[n] != 0) Numero(h, fila, 7 + n, dato.Meses[n], negrita: dato.Titulo);
                        else Texto(h, fila, 7 + n, "");
                    for (int c = 1; c <= h.Columnas; c++)
                    {
                        var celda = Celda(h, fila, c); celda.ColorTexto = "000000";
                        if (dato.Titulo) { celda.Subrayado = true; celda.ColorFondo = "F4F5F7"; }
                    }
                    h.AltosFilas[fila++] = 26;
                }
                fila++;
                if (parte == partes.Length - 1)
                {
                    foreach (var concepto in pie.Where(f => f.Id != MYGPiePresupuesto.IdTotal))
                    {
                        string nombre = concepto.Nombre + (concepto.Porcentaje.HasValue
                            ? " (" + concepto.Porcentaje.Value.ToString("0.00", Espanol) + "%)" : "");
                        FilaPieValorizado(h, fila++, nombre, concepto.Importe,
                            pieMensual.GetValueOrDefault(concepto.Id) ?? new decimal[periodos.Length],
                            concepto.Id is MYGPiePresupuesto.IdCostoDirecto or "parcial");
                    }
                    fila++;
                    string nombreTotal = pie.LastOrDefault(f => f.Id == MYGPiePresupuesto.IdTotal)?.Nombre;
                    string alcanceTotal = presupuestoId == null ? "PROYECTO" : "PRESUPUESTO";
                    string rotuloTotal = string.IsNullOrWhiteSpace(nombreTotal) || nombreTotal.Equals("Total", StringComparison.OrdinalIgnoreCase)
                        ? "TOTAL " + alcanceTotal : nombreTotal + " · " + alcanceTotal;
                    FilaPieValorizado(h, fila, rotuloTotal + " · " + moneda.Key, total, totalesMes, true);
                    h.CeldaTotal = "F" + fila++;
                    fila++;
                    decimal acumulado = 0;
                    Texto(h, fila, 2, "Porcentaje de avance por Mes");
                    Texto(h, fila + 1, 2, "Porcentaje de avance acumulado");
                    h.RangosCombinados.Add("B" + fila + ":F" + fila);
                    h.RangosCombinados.Add("B" + (fila + 1) + ":F" + (fila + 1));
                    for (int n = 0; n < periodos.Length; n++)
                    {
                        acumulado += totalesMes[n];
                        Numero(h, fila, 7 + n, total == 0 ? 0 : totalesMes[n] / total, "0.00%");
                        Numero(h, fila + 1, 7 + n, total == 0 ? 0 : acumulado / total, "0.00%");
                    }
                    fila += 3;
                    Pie(h, fila, "Alcance: partidas vinculadas al cronograma; los títulos suman sólo esas partidas. " +
                        "El pie conserva la configuración activa aplicada al costo directo programado, incluidos importes fijos una sola vez según su alcance. " +
                        "Distribución mensual proporcional a los costos directos, respetando partes, pausas y redondeos; no es avance físico ejecutado. " +
                        "Los porcentajes usan el total programado con pie de esta moneda. Puede diferir del total contractual si hay partidas sin programar.");
                }
                else
                {
                    Texto(h, fila, 2, "Continúa en la siguiente hoja; pie y totales globales en la última.");
                    Numero(h, fila, 6, 0); h.CeldaTotal = "F" + fila;
                }
                Terminar(h, fila);
                reportes.Add(new(titulo + " · " + moneda.Key, h, Datos(documento, plan), cabeceraEnHoja: true));
            }
        }
        var presentados = AplicarPresentacion(reportes, plan);
        // La presentación puede añadir una nota de página. Ajustar al final
        // incluye esa nota y conserva la misma geometría en vista y XLSX.
        foreach (var grupo in gruposDimensiones) AjustarDimensionesValorizado(grupo);
        return presentados;
    }

    private static decimal[] RepartirImporteValorizado(decimal importe, decimal[] pesos, int decimales)
    {
        var resultado = new decimal[pesos.Length];
        decimal total = pesos.Sum();
        if (total == 0) { resultado[0] = importe; return resultado; }
        decimal acumulado = 0, asignado = 0;
        int ultimo = Array.FindLastIndex(pesos, p => p != 0);
        for (int n = 0; n < pesos.Length; n++)
        {
            acumulado += pesos[n];
            decimal objetivo = n >= ultimo ? importe : decimal.Round(importe * acumulado / total, decimales, MidpointRounding.AwayFromZero);
            resultado[n] = objetivo - asignado; asignado = objetivo;
        }
        return resultado;
    }

    private static void FilaPieValorizado(MYGHojaMetrado h, int fila, string nombre, decimal importe, decimal[] meses, bool fuerte)
    {
        for (int c = 2; c <= h.Columnas; c++)
            Texto(h, fila, c, "", fuerte).ColorFondo = fuerte ? "ECEEF1" : "FFFFFF";
        Texto(h, fila, 2, nombre, fuerte).ColorFondo = fuerte ? "ECEEF1" : "FFFFFF";
        h.RangosCombinados.Add("B" + fila + ":E" + fila);
        Numero(h, fila, 6, importe, negrita: fuerte);
        for (int n = 0; n < meses.Length; n++) Numero(h, fila, 7 + n, meses[n], negrita: fuerte);
        if (fuerte) for (int c = 2; c <= h.Columnas; c++) Celda(h, fila, c).ColorFondo = "ECEEF1";
        h.AltosFilas[fila] = 24;
    }

    private static void CabeceraValorizado(MYGHojaMetrado h, MYGProyectoDocumento documento, string presupuestoId,
        string titulo, string moneda, Periodo[] periodos)
    {
        h.AltosFilas.Clear(); h.FilasInmovilizadas = 9; h.ColumnasInmovilizadas = 6;
        string ultima = MYGHojaCalculo.Columna(h.Columnas);
        Texto(h, 1, 1, titulo, true, "Centro").TamanoFuente = 12;
        h.RangosCombinados.Add("A1:" + ultima + "1"); h.AltosFilas[1] = 30;
        h.AltosFilas[2] = 12;
        string ubicacion = "DPTO: " + (documento.Datos?.Departamento ?? "") + "  PROV: " +
            (documento.Datos?.Provincia ?? "") + "  DIST: " + (documento.Datos?.Distrito ?? "");
        var datos = new[] { ("PROYECTO", documento.Nombre ?? ""), ("PROPIETARIO", documento.Datos?.Propietario ?? ""),
            ("UBICACIÓN", ubicacion), ("FECHA DE PROY.", documento.Datos?.FechaElaboracion?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "No registrado"),
            ("PRESUPUESTO", presupuestoId == null ? "Todos los presupuestos · " + moneda :
                documento.Presupuestos.Single(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).ToString() + " · " + moneda) };
        for (int n = 0; n < datos.Length; n++)
        {
            int fila = n + 3;
            Texto(h, fila, 1, datos[n].Item1 + ":").Bordes = false;
            Texto(h, fila, 2, datos[n].Item2).Bordes = false;
            h.RangosCombinados.Add("B" + fila + ":" + ultima + fila);
            h.AltosFilas[fila] = n == 0 ? 38 : 24;
        }
        Celda(h, 1, 1).Bordes = false; h.AltosFilas[8] = 12; h.AltosFilas[9] = 54;
        string[] titulos = { "Item", "Descripción", "Unidad", "Cantidad", "Precio", "Parcial" };
        for (int c = 1; c <= h.Columnas; c++)
            Texto(h, 9, c, c <= 6 ? titulos[c - 1] : "Mes " + (c - 6) + "\nDel " + Fecha(periodos[c - 7].Inicio) + "\nAl " + Fecha(periodos[c - 7].Fin),
                true, "Centro").ColorFondo = "ECEEF1";
    }

    private static void AjustarDimensionesValorizado(IReadOnlyList<MYGHojaMetrado> hojas)
    {
        if (hojas.Count == 0) return;
        // El escritor convierte píxeles del modelo a unidades Excel dividiendo
        // por 7. La fuente Normal de este libro es Arial Narrow de 9 puntos,
        // cuyo dígito ocupa aproximadamente 5 píxeles. Compensar esa diferencia
        // evita volver a guardar anchos que Excel dibujaría demasiado pequeños.
        const double unidadesModeloPorPixel = 7d / 5d;
        const int anchoMaximo = 1790; // 255 unidades: límite de columna de Excel.
        const int altoMaximo = 546; // 409,5 puntos: límite de fila de Excel.
        var anchos = Enumerable.Range(1, hojas[0].Columnas).ToDictionary(c => c,
            c => c == 2 ? 420 : c >= 7 ? 105 : 8);
        var preparadas = hojas.Select(h =>
        {
            var combinadas = new Dictionary<(int Fila, int Columna), (int Primera, int Ultima)>();
            foreach (string rango in h.RangosCombinados)
            {
                var extremos = rango.Split(':');
                var inicio = MYGHojaCalculo.Coordenadas(extremos[0]);
                var fin = MYGHojaCalculo.Coordenadas(extremos[^1]);
                if (inicio.Fila != fin.Fila) continue;
                for (int c = inicio.Columna; c <= fin.Columna; c++)
                    combinadas[(inicio.Fila, c)] = (inicio.Columna, fin.Columna);
            }
            return (Hoja: h, Combinadas: combinadas, Calculo: new MYGHojaCalculo(h));
        }).ToArray();
        foreach (var preparada in preparadas)
        foreach (var entrada in preparada.Hoja.Celdas)
        {
            var posicion = MYGHojaCalculo.Coordenadas(entrada.Key);
            var celda = entrada.Value;
            celda.AlineacionVertical = "Centro";
            bool combinada = preparada.Combinadas.TryGetValue(posicion, out var region);
            // Las descripciones y los rótulos combinados pueden ocupar varias
            // líneas. Los códigos, unidades e importes conservan una sola línea.
            celda.AjustarTexto = combinada ? posicion.Columna == region.Primera :
                posicion.Columna == 2 || posicion.Fila == 9 && posicion.Columna >= 7;
            if (posicion.Columna == 2 || combinada) continue;
            string texto = preparada.Calculo.Mostrar(entrada.Key);
            double ancho = texto.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n')
                .Select(linea => AnchoLineaValorizado(linea, celda)).DefaultIfEmpty(0).Max();
            int requerido = (int)Math.Min(anchoMaximo, Math.Ceiling(ancho * unidadesModeloPorPixel + 18));
            anchos[posicion.Columna] = Math.Max(anchos[posicion.Columna], requerido);
        }
        foreach (var preparada in preparadas)
        {
            var h = preparada.Hoja;
            foreach (var ancho in anchos) h.AnchosColumnas[ancho.Key] = ancho.Value;
            foreach (var entrada in h.Celdas)
            {
                var posicion = MYGHojaCalculo.Coordenadas(entrada.Key);
                int primera = posicion.Columna, ultima = primera;
                if (preparada.Combinadas.TryGetValue(posicion, out var region))
                {
                    if (primera != region.Primera) continue;
                    ultima = region.Ultima;
                }
                string texto = preparada.Calculo.Mostrar(entrada.Key);
                if (texto.Length == 0) continue;
                var celda = entrada.Value;
                int anchoModelo = Enumerable.Range(primera, ultima - primera + 1).Sum(c => anchos[c]);
                double disponible = Math.Max(1, (anchoModelo - 5) / unidadesModeloPorPixel - 10);
                int lineas = LineasValorizado(texto, disponible, celda);
                double altoLinea = (double)celda.TamanoFuente * 96d / 72d * 1.3d;
                int requerido = (int)Math.Min(altoMaximo, Math.Ceiling(lineas * altoLinea + 10));
                h.AltosFilas[posicion.Fila] = Math.Max(h.AltosFilas.GetValueOrDefault(posicion.Fila, 24), requerido);
            }
            MYGHojaCalculo.Validar(h);
        }
    }

    // Medida conservadora independiente de GDI, fuentes instaladas y Office.
    // Las cifras formateadas se miden con sus separadores, signo y porcentaje;
    // los anchos distintos de las letras evitan cortar palabras anchas.
    private static double AnchoGlifoValorizado(char caracter, MYGCeldaHoja celda)
    {
        var categoria = CharUnicodeInfo.GetUnicodeCategory(caracter);
        if (categoria is UnicodeCategory.NonSpacingMark or UnicodeCategory.EnclosingMark or UnicodeCategory.Format) return 0;
        double proporcion = caracter switch
        {
            '\t' => 1.04,
            ' ' => .26,
            '.' or ',' or ':' or ';' or '\'' or '"' or '!' or '|' => .26,
            'i' or 'l' or 'I' => .28,
            'm' or 'w' or 'M' or 'W' => .82,
            '-' or '+' or '/' or '\\' or '(' or ')' or '[' or ']' => .34,
            _ when char.IsDigit(caracter) => .45,
            _ when caracter >= '\u2E80' => 1,
            _ when char.IsUpper(caracter) => .56,
            _ => .45
        };
        return proporcion * (double)celda.TamanoFuente * 96d / 72d * (celda.Negrita ? 1.1 : 1);
    }

    private static double AnchoLineaValorizado(string texto, MYGCeldaHoja celda) =>
        texto.Sum(c => AnchoGlifoValorizado(c, celda));

    private static int LineasValorizado(string texto, double disponible, MYGCeldaHoja celda)
    {
        int total = 0;
        foreach (string parrafo in texto.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
        {
            int lineas = 1;
            double ocupado = 0, espacios = 0;
            for (int i = 0; i < parrafo.Length;)
            {
                int inicio = i;
                bool blanco = char.IsWhiteSpace(parrafo[i]);
                while (i < parrafo.Length && char.IsWhiteSpace(parrafo[i]) == blanco) i++;
                string parte = parrafo[inicio..i];
                double ancho = AnchoLineaValorizado(parte, celda);
                if (blanco) { espacios += ancho; continue; }
                if (!celda.AjustarTexto) continue;
                if (ancho <= disponible)
                {
                    if (ocupado > 0 && ocupado + espacios + ancho > disponible) { lineas++; ocupado = 0; }
                    ocupado += (ocupado > 0 ? espacios : 0) + ancho;
                }
                else
                {
                    if (ocupado > 0) { lineas++; ocupado = 0; }
                    foreach (char caracter in parte)
                    {
                        double glifo = AnchoGlifoValorizado(caracter, celda);
                        if (ocupado > 0 && ocupado + glifo > disponible) { lineas++; ocupado = 0; }
                        ocupado += glifo;
                    }
                }
                espacios = 0;
            }
            total += lineas;
        }
        return total;
    }
}
