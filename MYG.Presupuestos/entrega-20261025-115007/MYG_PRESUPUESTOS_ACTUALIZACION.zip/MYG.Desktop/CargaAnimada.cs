using System;
using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.ExceptionServices;
using System.Threading;
using System.Threading.Tasks;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

// La tarea de lectura se ejecuta fuera de la interfaz; sus resultados se aplican
// después del await, en el hilo de WinForms. El diálogo nunca simula progreso.
internal static class MYGCargaAnimada
{
    internal static Task<T> EjecutarAsync<T>(WinForms.Form propietario, string detalle, Func<T> trabajo)
        => EjecutarAsync<T>(propietario, detalle, () => Task.Run(trabajo));

    internal static Task EjecutarAsync(WinForms.Form propietario, string detalle, Action trabajo)
        => EjecutarAsync<bool>(propietario, detalle, () => Task.Run(() => { trabajo(); return true; }));

    internal static Task EjecutarAsync(WinForms.Form propietario, string detalle, Func<Task> trabajo)
        => EjecutarAsync<bool>(propietario, detalle, async () => { await trabajo(); return true; });

    internal static Task<T> EjecutarAsync<T>(WinForms.Form propietario, string detalle, Func<Task<T>> trabajo)
        => EjecutarConProgresoAsync(propietario, detalle, _ => trabajo());

    internal static Task<T> EjecutarStaAsync<T>(WinForms.Form propietario, string detalle, Func<Action<string>, T> trabajo)
        => EjecutarConProgresoAsync(propietario, detalle, progreso => EnHiloSta(() => trabajo(progreso.Report)));

    // Conserva APIs síncronas de WinForms sin bloquear el bombeo de mensajes.
    // El bucle es el normal de ShowDialog; todo Word/RichEdit temporal pertenece
    // exclusivamente al hilo STA de trabajo, nunca al hilo de la ventana.
    internal static T EjecutarSta<T>(WinForms.Form propietario, string detalle, Func<Action<string>, T> trabajo)
    {
        ValidarPropietario(propietario);
        propietario = propietario.TopLevelControl as WinForms.Form ?? propietario;
        ArgumentNullException.ThrowIfNull(trabajo);
        using var dialogo = new MYGDialogoCarga(detalle);
        var progreso = new ProgresoCarga(dialogo);
        T resultado = default;
        ExceptionDispatchInfo fallo = null;
        bool habilitado = propietario.Enabled;
        dialogo.Shown += async (_, _) =>
        {
            try { resultado = await EnHiloSta(() => trabajo(progreso.Report)); }
            catch (Exception ex) { fallo = ExceptionDispatchInfo.Capture(ex); }
            finally { await dialogo.DespedirAsync(); }
        };
        try { dialogo.ShowDialog(propietario); }
        finally
        {
            if (!propietario.IsDisposed && !propietario.Disposing) propietario.Enabled = habilitado;
        }
        fallo?.Throw();
        return resultado;
    }

    internal static Task<T> EnStaAsync<T>(Func<Action<string>, T> trabajo, Action<string> informar)
    {
        ArgumentNullException.ThrowIfNull(trabajo);
        return EnHiloSta(() => trabajo(informar ?? (_ => { })));
    }

    private static Task<T> EnHiloSta<T>(Func<T> trabajo)
    {
        var terminado = new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
        var hilo = new Thread(() =>
        {
            try { terminado.TrySetResult(trabajo()); }
            catch (Exception ex) { terminado.TrySetException(ex); }
        }) { IsBackground = true, Name = "MYG carga STA" };
        hilo.SetApartmentState(ApartmentState.STA);
        hilo.Start();
        return terminado.Task;
    }

    internal static async Task<T> EjecutarConProgresoAsync<T>(WinForms.Form propietario, string detalle,
        Func<IProgress<string>, Task<T>> trabajo)
    {
        ValidarPropietario(propietario);
        propietario = propietario.TopLevelControl as WinForms.Form ?? propietario;
        ArgumentNullException.ThrowIfNull(trabajo);
        using var dialogo = new MYGDialogoCarga(detalle);
        var progreso = new ProgresoCarga(dialogo);
        bool habilitado = propietario.Enabled;
        var ventanas = propietario.OwnedForms.Where(f => !f.IsDisposed && !f.Disposing)
            .Select(f => (Ventana: f, Habilitada: f.Enabled)).ToArray();
        WinForms.FormClosingEventHandler impedirCierre = (s, e) => e.Cancel = true;
        propietario.FormClosing += impedirCierre;
        try
        {
            dialogo.Show(propietario);
            propietario.Enabled = false;
            foreach (var ventana in ventanas) ventana.Ventana.Enabled = false;
            dialogo.Refresh();
            await Task.Yield();
            return await trabajo(progreso);
        }
        finally
        {
            try { await dialogo.DespedirAsync(); }
            finally
            {
                propietario.FormClosing -= impedirCierre;
                foreach (var ventana in ventanas)
                    if (!ventana.Ventana.IsDisposed && !ventana.Ventana.Disposing) ventana.Ventana.Enabled = ventana.Habilitada;
                if (!propietario.IsDisposed && !propietario.Disposing)
                {
                    propietario.Enabled = habilitado;
                    propietario.Activate();
                }
            }
        }
    }

    private static void ValidarPropietario(WinForms.Form propietario)
    {
        ArgumentNullException.ThrowIfNull(propietario);
        if (propietario.IsDisposed || propietario.Disposing) throw new ObjectDisposedException(nameof(propietario));
        if (propietario.InvokeRequired) throw new InvalidOperationException("La carga debe iniciarse desde la ventana.");
    }

    private sealed class ProgresoCarga(MYGDialogoCarga dialogo) : IProgress<string>
    {
        private long siguiente, aplicado;

        private void Aplicar(long orden, string detalle)
        {
            if (orden <= aplicado || dialogo.IsDisposed || dialogo.Disposing) return;
            aplicado = orden;
            dialogo.ActualizarDetalle(detalle);
        }

        public void Report(string detalle)
        {
            long orden = Interlocked.Increment(ref siguiente);
            if (dialogo.IsDisposed || dialogo.Disposing || !dialogo.IsHandleCreated) return;
            if (!dialogo.InvokeRequired) { Aplicar(orden, detalle); return; }
            try
            {
                dialogo.BeginInvoke(new Action(() =>
                {
                    Aplicar(orden, detalle);
                }));
            }
            catch (InvalidOperationException) when (dialogo.IsDisposed || dialogo.Disposing || !dialogo.IsHandleCreated) { }
        }
    }
}

internal sealed class MYGDialogoCarga : WinForms.Form
{
    private readonly WinForms.Timer reloj = new() { Interval = 16 };
    private readonly Stopwatch tiempo = Stopwatch.StartNew();
    private readonly MYGCirculoCarga circulo = new();
    private readonly bool animar = WinForms.SystemInformation.IsMenuAnimationEnabled && !WinForms.SystemInformation.HighContrast;
    private TaskCompletionSource<bool> cierre;
    private double inicioSalida, opacidadSalida;
    private bool cerrando;
    private readonly WinForms.Label etapa = new()
    {
        Name = "carga_etapa_actual", Dock = WinForms.DockStyle.Fill,
        TextAlign = Drawing.ContentAlignment.MiddleLeft, AutoEllipsis = true
    };
    private readonly WinForms.Label historial = new()
    {
        Name = "carga_etapas_realizadas", Dock = WinForms.DockStyle.Fill,
        TextAlign = Drawing.ContentAlignment.TopLeft, AutoEllipsis = true
    };
    private readonly Queue<string> etapas = new();
    internal string EtapaActual => etapa.Text;
    internal string[] Etapas => etapas.ToArray();

    internal MYGDialogoCarga(string detalle)
    {
        AutoScaleMode = WinForms.AutoScaleMode.Dpi;
        ClientSize = new(600, 228);
        FormBorderStyle = WinForms.FormBorderStyle.None;
        StartPosition = WinForms.FormStartPosition.CenterParent;
        ShowInTaskbar = false; ControlBox = false; DoubleBuffered = true;
        BackColor = WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Window : MYG2027_TemaComercial.Fondo;
        Text = "Cargando"; AccessibleName = "Espere, por favor";
        AccessibleDescription = detalle;
        Padding = new(16); Opacity = 1;
        circulo.Dock = WinForms.DockStyle.Left; circulo.Width = 58;
        var texto = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 3,
            BackColor = Drawing.Color.Transparent, Padding = new(12, 3, 0, 3) };
        texto.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        texto.RowStyles.Add(new(WinForms.SizeType.Absolute, 32));
        texto.RowStyles.Add(new(WinForms.SizeType.Absolute, 44));
        texto.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        texto.Controls.Add(new WinForms.Label { Text = "Espere, por favor", Dock = WinForms.DockStyle.Fill,
            TextAlign = Drawing.ContentAlignment.MiddleLeft, Font = new("Segoe UI", 13, Drawing.FontStyle.Bold),
            ForeColor = WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.WindowText : MYG2027_TemaComercial.Texto, AutoEllipsis = true }, 0, 0);
        etapa.Font = new("Segoe UI", 10);
        etapa.ForeColor = WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.WindowText : MYG2027_TemaComercial.Texto;
        etapa.AccessibleName = "Proceso actual";
        historial.Font = new("Segoe UI", 8.5f);
        historial.ForeColor = WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.WindowText : MYG2027_TemaComercial.Secundario;
        historial.AccessibleName = "Etapas de carga realizadas";
        texto.Controls.Add(etapa, 0, 1);
        texto.Controls.Add(historial, 0, 2);
        ActualizarDetalle(detalle);
        Controls.Add(texto); Controls.Add(circulo);
        reloj.Tick += Animar;
        Load += (s, e) => CenterToParent();
        Shown += (s, e) => { tiempo.Restart(); if (animar) reloj.Start(); };
        FormClosing += (s, e) => { if (!cerrando) e.Cancel = true; };
    }

    internal void ActualizarDetalle(string detalle)
    {
        if (IsDisposed || Disposing || cerrando || string.IsNullOrWhiteSpace(detalle)) return;
        detalle = detalle.Trim();
        if (detalle == etapa.Text) return;
        if (!string.IsNullOrWhiteSpace(etapa.Text))
        {
            etapas.Enqueue(etapa.Text);
            while (etapas.Count > 5) etapas.Dequeue();
        }
        etapa.Text = detalle;
        historial.Text = string.Join(Environment.NewLine, etapas.Select(x => "✓ " + x));
        AccessibleDescription = detalle;
        // Pintar las etapas de construcción UI antes de ejecutar el siguiente
        // bloque síncrono, sin despachar eventos de entrada ni reentrancia.
        if (IsHandleCreated) Refresh();
    }

    protected override WinForms.CreateParams CreateParams
    {
        get { var parametros = base.CreateParams; parametros.ClassStyle |= 0x20000; return parametros; }
    }

    protected override void OnPaint(WinForms.PaintEventArgs e)
    {
        base.OnPaint(e);
        using var borde = new Drawing.Pen(WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.WindowFrame : MYG2027_TemaComercial.Borde);
        e.Graphics.DrawRectangle(borde, 0, 0, ClientSize.Width - 1, ClientSize.Height - 1);
    }

    private void Animar(object sender, EventArgs e)
    {
        if (!animar) return;
        circulo.Angulo = (float)(tiempo.Elapsed.TotalMilliseconds * .25 % 360);
        circulo.Invalidate();
        double progreso = cierre == null ? Math.Min(1, tiempo.Elapsed.TotalMilliseconds / 180)
            : Math.Min(1, (tiempo.Elapsed.TotalMilliseconds - inicioSalida) / 140);
        double curva = progreso * progreso * (3 - 2 * progreso);
        if (cierre != null) Opacity = opacidadSalida * (1 - curva);
        if (cierre != null && progreso >= 1) Terminar();
    }

    internal Task DespedirAsync()
    {
        if (IsDisposed) return Task.CompletedTask;
        if (cierre != null) return cierre.Task;
        cierre = new(TaskCreationOptions.RunContinuationsAsynchronously);
        inicioSalida = tiempo.Elapsed.TotalMilliseconds; opacidadSalida = Opacity;
        if (!animar || opacidadSalida <= .01) Terminar();
        return cierre.Task;
    }

    private void Terminar()
    {
        reloj.Stop(); cerrando = true; Close(); cierre?.TrySetResult(true);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { reloj.Stop(); reloj.Dispose(); cierre?.TrySetResult(true); }
        base.Dispose(disposing);
    }
}

internal sealed class MYGCirculoCarga : WinForms.Control
{
    [System.ComponentModel.Browsable(false)]
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal float Angulo { get; set; }
    internal MYGCirculoCarga()
    {
        SetStyle(WinForms.ControlStyles.UserPaint | WinForms.ControlStyles.AllPaintingInWmPaint |
            WinForms.ControlStyles.OptimizedDoubleBuffer | WinForms.ControlStyles.SupportsTransparentBackColor, true);
        BackColor = Drawing.Color.Transparent;
        AccessibleName = "Carga en curso"; TabStop = false;
    }
    protected override void OnPaint(WinForms.PaintEventArgs e)
    {
        base.OnPaint(e); e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        float lado = Math.Min(Width, Height) * .66f;
        var rectangulo = new Drawing.RectangleF((Width - lado) / 2, (Height - lado) / 2, lado, lado);
        using var pista = new Drawing.Pen(WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.GrayText : MYG2027_TemaComercial.Borde, 4);
        using var activo = new Drawing.Pen(WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Highlight : MYG2027_TemaComercial.Azul, 4)
            { StartCap = LineCap.Round, EndCap = LineCap.Round };
        e.Graphics.DrawEllipse(pista, rectangulo); e.Graphics.DrawArc(activo, rectangulo, Angulo - 90, 95);
    }
}
