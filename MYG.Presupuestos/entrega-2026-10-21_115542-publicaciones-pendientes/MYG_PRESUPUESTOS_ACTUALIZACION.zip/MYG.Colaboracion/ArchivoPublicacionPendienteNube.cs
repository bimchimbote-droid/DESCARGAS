using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MYG.Colaboracion;

// Mantiene el mismo contrato JSON que el record privado de InicioNube.
public sealed record PublicacionPendienteNube(Guid Id, string Nombre, string Alcance, JsonElement Contenido);

public sealed record ResumenPublicacionPendienteNube(string Ambito, Guid? Id, string Nombre, string Alcance,
    long BytesArchivo, DateTime FechaUtc, bool DatosLegibles);

/// <summary>Gestiona solo el intento local de una cuenta y servidor; nunca elimina obras ni proyectos remotos.</summary>
public sealed class ArchivoPublicacionPendienteNube
{
    private const int MaxPrefijo = 64 * 1024;
    private static readonly JsonSerializerOptions Opciones = new() { MaxDepth = 128 };
    private readonly string carpeta;
    private readonly string ambito;
    private readonly string rutaBloqueo;

    public string RutaActiva { get; }

    public ArchivoPublicacionPendienteNube(string carpetaPublicaciones, string servidor, string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(carpetaPublicaciones)) throw new ArgumentException("Indique la carpeta de publicaciones.", nameof(carpetaPublicaciones));
        if (!Uri.TryCreate(servidor, UriKind.Absolute, out var destino) || destino.Scheme != Uri.UriSchemeHttps
            || destino.UserInfo.Length != 0 || destino.AbsolutePath != "/" || destino.Query.Length != 0 || destino.Fragment.Length != 0)
            throw new ArgumentException("Indique el servidor HTTPS de la cuenta.", nameof(servidor));
        if (!Guid.TryParse(usuarioId, out var usuario) || usuario == Guid.Empty)
            throw new ArgumentException("Indique la identidad de la cuenta de nube.", nameof(usuarioId));
        carpeta = Path.GetFullPath(carpetaPublicaciones);
        // No normalizar estos valores: debe localizar exactamente los pendientes anteriores.
        ambito = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(servidor + "\n" + usuarioId)));
        RutaActiva = Path.Combine(carpeta, ambito + ".json");
        rutaBloqueo = Path.Combine(carpeta, ambito + ".lock");
    }

    public ResumenPublicacionPendienteNube? Consultar()
    {
        if (!Directory.Exists(carpeta)) return null;
        using var bloqueo = Bloquear();
        return ConsultarSinBloqueo();
    }

    public PublicacionPendienteNube Leer(ResumenPublicacionPendienteNube? esperado = null)
    {
        using var bloqueo = Bloquear();
        var actual = RequerirActual(esperado);
        PublicacionPendienteNube publicacion;
        try
        {
            using var archivo = new FileStream(RutaActiva, FileMode.Open, FileAccess.Read, FileShare.Read);
            publicacion = JsonSerializer.Deserialize<PublicacionPendienteNube>(archivo, Opciones)
                ?? throw new InvalidDataException("La publicación pendiente no contiene una solicitud válida. Puede retirarla conservando una copia.");
        }
        catch (JsonException ex)
        {
            throw new InvalidDataException("La publicación pendiente no es legible. Puede retirarla conservando una copia.", ex);
        }
        Validar(publicacion);
        if (actual.Id.HasValue && actual.Id != publicacion.Id)
            throw new InvalidDataException("La identidad del archivo pendiente no coincide con sus metadatos. Consérvelo para recuperarlo.");
        return publicacion;
    }

    public void Guardar(PublicacionPendienteNube publicacion)
    {
        ArgumentNullException.ThrowIfNull(publicacion);
        Validar(publicacion);
        using var bloqueo = Bloquear();
        if (File.Exists(RutaActiva))
            throw new IOException("Ya hay una publicación pendiente para esta cuenta. Reinténtela o retírela antes de crear otra.");
        string temporal = Path.Combine(carpeta, ambito + "." + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                JsonSerializer.Serialize(archivo, publicacion, Opciones);
                archivo.Flush(flushToDisk: true);
            }
            File.Move(temporal, RutaActiva);
        }
        finally
        {
            if (File.Exists(temporal)) File.Delete(temporal);
        }
    }

    /// <summary>Retira el intento local mediante un archivo reversible, sin cambiar sus bytes ni su UUID.</summary>
    public string Retirar(ResumenPublicacionPendienteNube esperado)
    {
        ArgumentNullException.ThrowIfNull(esperado);
        using var bloqueo = Bloquear();
        var actual = RequerirActual(esperado);
        string retiradas = Path.Combine(carpeta, "retiradas", ambito);
        Directory.CreateDirectory(retiradas);
        string identidad = actual.Id?.ToString("N") ?? "no-legible";
        string destino = Path.Combine(retiradas, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff") + "-" + identidad + "-" + Guid.NewGuid().ToString("N") + ".json");
        File.Move(RutaActiva, destino);
        return destino;
    }

    /// <summary>El llamador debe haber recibido la confirmación RPC; elimina solo el intento que confirmó.</summary>
    public void Confirmar(ResumenPublicacionPendienteNube esperado)
    {
        ArgumentNullException.ThrowIfNull(esperado);
        using var bloqueo = Bloquear();
        RequerirActual(esperado);
        File.Delete(RutaActiva);
    }

    private FileStream Bloquear()
    {
        Directory.CreateDirectory(carpeta);
        return new FileStream(rutaBloqueo, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    }

    private ResumenPublicacionPendienteNube RequerirActual(ResumenPublicacionPendienteNube? esperado)
    {
        if (esperado is not null && !string.Equals(esperado.Ambito, ambito, StringComparison.Ordinal))
            throw new InvalidOperationException("La publicación seleccionada pertenece a otra cuenta o servidor.");
        var actual = ConsultarSinBloqueo()
            ?? throw new FileNotFoundException("Ya no existe la publicación pendiente seleccionada.", RutaActiva);
        if (esperado is not null && (esperado.Id != actual.Id || esperado.BytesArchivo != actual.BytesArchivo
            || esperado.FechaUtc != actual.FechaUtc))
            throw new InvalidOperationException("La publicación pendiente cambió. Actualice la lista antes de continuar.");
        return actual;
    }

    private ResumenPublicacionPendienteNube? ConsultarSinBloqueo()
    {
        if (!File.Exists(RutaActiva)) return null;
        using var archivo = new FileStream(RutaActiva, FileMode.Open, FileAccess.Read, FileShare.Read);
        long longitud = archivo.Length;
        DateTime fecha = File.GetLastWriteTimeUtc(RutaActiva);
        byte[] prefijo = new byte[(int)Math.Min(MaxPrefijo, longitud)];
        archivo.ReadExactly(prefijo);
        var datos = LeerMetadatos(prefijo, longitud <= MaxPrefijo);
        return new(ambito, datos.Id, datos.Nombre, datos.Alcance, longitud, fecha, datos.Legibles);
    }

    private static (Guid? Id, string Nombre, string Alcance, bool Legibles) LeerMetadatos(ReadOnlySpan<byte> prefijo, bool completo)
    {
        Guid? id = null;
        string nombre = "Publicación no legible", alcance = "";
        bool tieneId = false, tieneNombre = false, tieneAlcance = false;
        try
        {
            var lector = new Utf8JsonReader(prefijo, completo, default);
            if (!lector.Read() || lector.TokenType != JsonTokenType.StartObject) return (id, nombre, alcance, false);
            while (lector.Read())
            {
                if (lector.TokenType != JsonTokenType.PropertyName || lector.CurrentDepth != 1) continue;
                string? propiedad = lector.GetString();
                if (!lector.Read()) break;
                switch (propiedad)
                {
                    case "Id":
                        if (tieneId || lector.TokenType != JsonTokenType.String || !lector.TryGetGuid(out var valor) || valor == Guid.Empty)
                            return (id, nombre, alcance, false);
                        id = valor; tieneId = true;
                        break;
                    case "Nombre":
                        if (tieneNombre || lector.TokenType != JsonTokenType.String) return (id, nombre, alcance, false);
                        nombre = lector.GetString()!;
                        if (!NombreValido(nombre)) return (id, "Publicación no legible", alcance, false);
                        tieneNombre = true;
                        break;
                    case "Alcance":
                        if (tieneAlcance || lector.TokenType != JsonTokenType.String) return (id, nombre, alcance, false);
                        alcance = lector.GetString()!;
                        if (alcance is not ("obra" or "base")) return (id, nombre, alcance, false);
                        tieneAlcance = true;
                        break;
                    case "Contenido":
                        return (id, nombre, alcance, tieneId && tieneNombre && tieneAlcance && lector.TokenType == JsonTokenType.StartObject);
                }
            }
        }
        catch (Exception ex) when (ex is JsonException or InvalidOperationException or DecoderFallbackException) { }
        return (id, nombre, alcance, false);
    }

    private static bool NombreValido(string? nombre) => !string.IsNullOrWhiteSpace(nombre)
        && nombre.Length <= 200 && !nombre.Any(char.IsControl);

    private static void Validar(PublicacionPendienteNube publicacion)
    {
        bool objeto;
        try { objeto = publicacion.Contenido.ValueKind == JsonValueKind.Object; }
        catch (ObjectDisposedException ex) { throw new InvalidDataException("El contenido de la publicación pendiente ya no está disponible.", ex); }
        if (publicacion.Id == Guid.Empty || !NombreValido(publicacion.Nombre)
            || publicacion.Alcance is not ("obra" or "base") || !objeto)
            throw new InvalidDataException("La publicación pendiente necesita identidad, nombre, alcance y contenido JSON válidos.");
    }
}
