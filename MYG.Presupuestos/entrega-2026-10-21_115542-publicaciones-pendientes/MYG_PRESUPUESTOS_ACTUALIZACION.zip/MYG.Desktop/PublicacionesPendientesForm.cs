#nullable enable
using System;
using System.Threading.Tasks;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

/// <summary>Administra únicamente el intento local del servidor y cuenta actuales.</summary>
public sealed class PublicacionesPendientesForm : WinForms.Form
{
    private readonly ArchivoPublicacionPendienteNube almacen;
    private readonly Action comprobarCuenta;
    private readonly WinForms.DataGridView lista = MYGBibliotecaUI.Tabla();
    private readonly WinForms.TextBox detalle = new() { Dock = WinForms.DockStyle.Fill, Multiline = true,
        ReadOnly = true, ScrollBars = WinForms.ScrollBars.Vertical, BorderStyle = WinForms.BorderStyle.None };
    private readonly WinForms.Button actualizar, reintentar, retirar, nueva;
    private ResumenPublicacionPendienteNube? actual;
    private bool ocupado;
    private bool cargaValida;

    public ResumenPublicacionPendienteNube? ParaReintentar { get; private set; }

    public PublicacionesPendientesForm(ArchivoPublicacionPendienteNube almacen, Action comprobarCuenta)
    {
        this.almacen = almacen;
        this.comprobarCuenta = comprobarCuenta;
        Name = "publicacionesPendientesDialogo";
        MYGProyectoUI.Preparar(this, "Publicaciones pendientes", 1000, 490);
        MinimumSize = new(820, 440);
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, Padding = new(24),
            ColumnCount = 1, RowCount = 4 };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 70));
        raiz.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 78));
        raiz.Controls.Add(new WinForms.Label { Dock = WinForms.DockStyle.Fill, Text =
            "Intento sin confirmar de este equipo, para su cuenta y servidor actuales. " +
            "Se conserva un intento activo por cuenta. El tamaño mostrado corresponde al JSON guardado; " +
            "puede superar el tamaño del SQLite. Los adjuntos se preparan antes del envío." }, 0, 0);
        lista.Name = "listaPublicacionesPendientes";
        lista.ReadOnly = true; lista.MultiSelect = false;
        lista.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect;
        lista.AutoSizeColumnsMode = WinForms.DataGridViewAutoSizeColumnsMode.Fill;
        lista.Columns.Add("Nombre", "Publicación");
        lista.Columns.Add("Alcance", "Alcance");
        lista.Columns.Add("Fecha", "Fecha guardada");
        lista.Columns.Add("Tamano", "JSON guardado");
        lista.Columns[0].FillWeight = 160;
        raiz.Controls.Add(lista, 0, 1);
        detalle.Name = "detallePublicacionPendiente";
        raiz.Controls.Add(detalle, 0, 2);
        var botones = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = true };
        var cerrar = MYGProyectoUI.Boton("Cerrar"); cerrar.DialogResult = WinForms.DialogResult.Cancel;
        nueva = MYGProyectoUI.Boton("Crear nueva", 1); nueva.Name = "crearPublicacionNueva";
        nueva.Click += (_, _) =>
        {
            if (ocupado || actual is not null) return;
            try { comprobarCuenta(); DialogResult = WinForms.DialogResult.OK; }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        reintentar = MYGProyectoUI.Boton("Reintentar"); reintentar.Name = "reintentarPublicacionPendiente";
        reintentar.Click += (_, _) =>
        {
            if (ocupado || actual?.DatosLegibles != true) return;
            try { comprobarCuenta(); ParaReintentar = actual; DialogResult = WinForms.DialogResult.Retry; }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        retirar = MYGProyectoUI.Boton("Retirar y conservar copia"); retirar.AutoSize = true;
        retirar.Name = "retirarPublicacionPendiente";
        retirar.Click += async (_, _) => await RetirarAsync();
        actualizar = MYGProyectoUI.Boton("Actualizar"); actualizar.Name = "actualizarPublicacionesPendientes";
        actualizar.Click += async (_, _) => await CargarAsync();
        botones.Controls.AddRange(new WinForms.Control[] { cerrar, nueva, reintentar, retirar, actualizar });
        raiz.Controls.Add(botones, 0, 3);
        Controls.Add(raiz); CancelButton = cerrar;
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; };
        Shown += async (_, _) => await CargarAsync();
        ActualizarAcciones();
    }

    private void ActualizarAcciones()
    {
        actualizar.Enabled = !ocupado;
        reintentar.Enabled = !ocupado && cargaValida && actual?.DatosLegibles == true;
        retirar.Enabled = !ocupado && cargaValida && actual is not null;
        nueva.Enabled = !ocupado && cargaValida && actual is null;
    }

    private async Task CargarAsync()
    {
        if (ocupado) return;
        ocupado = true; ActualizarAcciones();
        Exception? error = null;
        try
        {
            comprobarCuenta();
            var resumen = await Task.Run(almacen.Consultar);
            comprobarCuenta();
            Mostrar(resumen);
            cargaValida = true;
        }
        catch (Exception ex) { error = ex; cargaValida = false; }
        finally { ocupado = false; ActualizarAcciones(); }
        if (error is not null) MYGProyectoUI.Error(this, error);
    }

    private void Mostrar(ResumenPublicacionPendienteNube? resumen)
    {
        actual = resumen; lista.Rows.Clear();
        if (resumen is null)
        {
            detalle.Text = "No hay publicaciones pendientes para esta cuenta y servidor. Puede crear una nueva.";
            return;
        }
        lista.Rows.Add(resumen.Nombre, resumen.Alcance == "base" ? "Base completa" : resumen.Alcance == "obra" ? "Una obra" : "No legible",
            resumen.FechaUtc.ToLocalTime().ToString("g"), $"{resumen.BytesArchivo / 1048576d:N1} MiB");
        detalle.Text = resumen.DatosLegibles
            ? "Reintentar reutiliza el contenido guardado y su identificador, sin volver a leer el SQLite."
            : "No se pudo leer el encabezado del intento. Puede retirarlo conservando sus bytes para recuperarlo.";
        detalle.Text += Environment.NewLine + "El estado remoto no se ha comprobado. Si una respuesta anterior se perdió, revise también Mis proyectos."
            + Environment.NewLine + "Identificador: " + (resumen.Id?.ToString("D") ?? "no legible");
    }

    private async Task RetirarAsync()
    {
        if (ocupado || actual is null) return;
        var elegido = actual;
        if (WinForms.MessageBox.Show(this,
            "¿Retirar este intento de pendientes y conservar una copia?" + Environment.NewLine + Environment.NewLine +
            "No se eliminará su archivo SQLite ni ningún proyecto que ya exista en la nube. " +
            "Si una respuesta anterior se perdió, el proyecto podría estar publicado: revise Mis proyectos antes de crear otro.",
            "Retirar intento local", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Question)
            != WinForms.DialogResult.OK) return;
        ocupado = true; ActualizarAcciones();
        Exception? error = null;
        try
        {
            comprobarCuenta();
            string respaldo = await Task.Run(() => almacen.Retirar(elegido));
            comprobarCuenta();
            Mostrar(null);
            cargaValida = true;
            detalle.Text = "Intento retirado de pendientes. Puede pulsar Crear nueva." + Environment.NewLine
                + "Copia conservada en:" + Environment.NewLine + respaldo;
        }
        catch (Exception ex) { error = ex; cargaValida = false; }
        finally { ocupado = false; ActualizarAcciones(); }
        if (error is not null) MYGProyectoUI.Error(this, error);
    }
}
