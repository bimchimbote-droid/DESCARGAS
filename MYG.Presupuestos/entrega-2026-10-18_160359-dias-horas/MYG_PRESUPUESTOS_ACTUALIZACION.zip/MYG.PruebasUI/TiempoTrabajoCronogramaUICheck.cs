using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class TiempoTrabajoCronogramaUICheck
{
    private const string Prefijo = "cronograma_tiempo_";

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        plan.Tareas.Add(new MYGTareaCronograma { Nombre = "Trabajo de prueba", DuracionDias = 2 });
        var calendarioOriginal = plan.Calendario;
        string calendarioAntes = JsonSerializer.Serialize(calendarioOriginal);
        int aplicaciones = 0;
        bool autorizado = true, copiaIndependiente = true;
        MYGTiempoTrabajoCronogramaControl control = null;
        control = new MYGTiempoTrabajoCronogramaControl(() => plan, nuevo =>
        {
            copiaIndependiente &= !ReferenceEquals(nuevo, plan) && !ReferenceEquals(nuevo.Calendario, plan.Calendario) &&
                nuevo.Tareas.All(t => plan.Tareas.All(a => !ReferenceEquals(a, t)));
            plan = nuevo;
            aplicaciones++;
            // El editor anfitrión refresca sus vistas desde el callback de historial.
            control.Refrescar();
        }, () => autorizado);
        using (control)
        using (var ventana = new Form { ClientSize = new Size(1800, 410) })
        {
            ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
            var horario = Campo<DataGridView>(control, "horario");
            var dias = Campo<MYGDiasTrabajoListBox>(control, "dias");
            var excepciones = Campo<DataGridView>(control, "excepciones");
            var nombres = Campo<ComboBox>(control, "calendarios");
            exige(control.Name == "cronograma_tiempo_trabajo" && !control.TieneCambios && aplicaciones == 0 &&
                dias.Items.Count == 7 && Campo<Control>(control, "meses").Visible && horario.Rows.Count == 2 &&
                Convert.ToString(horario.Rows[0].Cells["INICIO"].Value) == "08:00" &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "12:00" &&
                Convert.ToString(horario.Rows[1].Cells["INICIO"].Value) == "13:00" &&
                Convert.ToString(horario.Rows[1].Cells["FIN"].Value) == "17:00",
                "Tiempo de trabajo debe abrir los siete días y la jornada heredada de ocho horas con refrigerio sin modificar el proyecto.");

            horario.CurrentCell = horario.Rows[0].Cells["FIN"];
            horario.BeginEdit(true);
            horario.EditingControl.Text = "10:30";
            dias.SelectedIndex = (int)DayOfWeek.Tuesday;
            dias.SelectedIndex = (int)DayOfWeek.Monday;
            exige(Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "10:30" &&
                control.TieneCambios && aplicaciones == 0 && JsonSerializer.Serialize(calendarioOriginal) == calendarioAntes,
                "Cambiar de día con texto horario aún sin confirmar debe incorporarlo al borrador antes de cambiar las filas.");
            horario.Rows[0].Cells["FIN"].Value = "11:00";
            control.FinalizarEdicion(); control.Refrescar();
            exige(control.TieneCambios && aplicaciones == 0 && JsonSerializer.Serialize(calendarioOriginal) == calendarioAntes &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "11:00",
                "Editar y refrescar la jornada debe conservar el borrador sin tocar el calendario original ni el historial.");
            plan.Tareas[0].Nombre = "Tarea editada mientras se consulta el calendario";
            control.GuardarCambios();
            exige(aplicaciones == 1 && copiaIndependiente && !control.TieneCambios &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 5)) == 7 &&
                plan.Tareas[0].Nombre == "Tarea editada mientras se consulta el calendario" &&
                plan.Calendarios.Single(c => c.Nombre == plan.Calendario.Nombre).HorasDelDia(new DateTime(2026, 1, 5)) == 7 &&
                JsonSerializer.Serialize(calendarioOriginal) == calendarioAntes,
                "Guardar debe aplicar una sola copia, sincronizar el calendario activo y conservar las ediciones recientes de tareas.");
            control.GuardarCambios();
            exige(aplicaciones == 1, "Guardar el calendario sin cambios debe conservar el historial.");

            string antesInvalido = Huella(plan);
            horario.CurrentCell = horario.Rows[0].Cells["FIN"];
            horario.BeginEdit(true);
            horario.EditingControl.Text = "14:00";
            dias.SelectedIndex = (int)DayOfWeek.Tuesday;
            exige(dias.SelectedIndex == (int)DayOfWeek.Monday &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "14:00" && control.TieneCambios &&
                Huella(plan) == antesInvalido && aplicaciones == 1,
                "Un texto horario inválido debe impedir navegar a otro día y conservarse para corregirlo sin modificar el plan.");
            bool rechazado = false;
            try { control.GuardarCambios(); } catch (Exception) { rechazado = true; }
            exige(rechazado && aplicaciones == 1 && Huella(plan) == antesInvalido && control.TieneCambios,
                "Un horario que solapa el turno de tarde debe rechazarse de forma atómica y conservarse para corregirlo.");
            horario.Rows[0].Cells["FIN"].Value = "12:00";
            control.GuardarCambios();
            exige(aplicaciones == 2 && plan.Calendario.HorasDelDia(new DateTime(2026, 1, 5)) == 8,
                "Corregir el horario debe permitir guardarlo sin repetir una transacción rechazada.");

            string antesCerrar = Huella(plan);
            horario.CurrentCell = horario.Rows[0].Cells["FIN"];
            horario.BeginEdit(true);
            horario.EditingControl.Text = "10:30";
            exige(control.TieneCambios, "El texto horario aún sin confirmar debe contarse como edición pendiente al cerrar el panel.");
            bool cerrarCancelado = ResponderCierre(control, 2);
            exige(!cerrarCancelado && control.TieneCambios && Huella(plan) == antesCerrar && aplicaciones == 2,
                "Cancelar el cierre debe mantener el panel, su texto pendiente y el proyecto sin modificaciones.");
            bool descartar = ResponderCierre(control, 7);
            exige(descartar && !control.TieneCambios && Huella(plan) == antesCerrar && aplicaciones == 2 &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "12:00",
                "Descartar al cerrar debe recuperar el calendario guardado sin crear historial.");

            Boton(control, "excepcion_agregar").PerformClick();
            Campo<TextBox>(control, "excepcion_nombre").Text = "Día del trabajo reducido";
            Campo<ComboBox>(control, "excepcion_tipo").SelectedIndex = 4;
            Campo<DateTimePicker>(control, "excepcion_desde").Checked = false;
            Campo<DateTimePicker>(control, "excepcion_hasta").Checked = false;
            Campo<ComboBox>(control, "excepcion_mes").SelectedIndex = 4;
            Campo<NumericUpDown>(control, "excepcion_dia").Value = 1;
            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 1;
            Campo<RadioButton>(control, "excepcion_laborable").Checked = true;
            Boton(control, "excepcion_horario_agregar").PerformClick();
            Boton(control, "excepcion_horario_agregar").PerformClick();
            var horarioEspecial = Campo<DataGridView>(control, "excepcion_horario");
            exige(horarioEspecial.Rows.Count == 2 && excepciones.Rows.Count == 1 && aplicaciones == 2,
                "Una excepción laborable debe admitir varios turnos sin aplicar cambios antes de guardar.");
            horarioEspecial.Rows[0].Cells["FIN"].Value = "10:00";
            horarioEspecial.Rows[1].Cells["FIN"].Value = "15:00";
            control.GuardarCambios();
            exige(aplicaciones == 3 && plan.Calendario.HorasDelDia(new DateTime(2026, 5, 1)) == 4 &&
                plan.Calendario.HorasDelDia(new DateTime(2027, 5, 1)) == 4 &&
                plan.Calendario.Excepciones.Single().Nombre == "Día del trabajo reducido" &&
                plan.Calendario.Excepciones.Single().Anual,
                "Guardar una excepción anual debe repetir día y mes y aplicar sus turnos tanto en días habituales como en sábados.");

            Boton(control, "excepcion_agregar").PerformClick();
            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 0;
            Campo<TextBox>(control, "excepcion_nombre").Text = "Cierre de obra";
            Campo<DateTimePicker>(control, "excepcion_desde").Value = new DateTime(2026, 5, 1);
            Campo<DateTimePicker>(control, "excepcion_hasta").Value = new DateTime(2026, 5, 2);
            control.GuardarCambios();
            exige(aplicaciones == 4 && !plan.Calendario.EsLaborable(new DateTime(2026, 5, 1)) &&
                !plan.Calendario.EsLaborable(new DateTime(2026, 5, 2)) && plan.Calendario.HorasDelDia(new DateTime(2027, 5, 1)) == 4,
                "La excepción fechada debe cubrir ambos extremos y prevalecer sobre la excepción anual sin cambiar otros años.");

            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 1;
            Campo<RadioButton>(control, "excepcion_laborable").Checked = true;
            Boton(control, "excepcion_horario_agregar").PerformClick();
            horarioEspecial.CurrentCell = horarioEspecial.Rows[0].Cells["FIN"];
            horarioEspecial.BeginEdit(true);
            horarioEspecial.EditingControl.Text = "09:15";
            excepciones.CurrentCell = excepciones.Rows[0].Cells[0];
            excepciones.CurrentCell = excepciones.Rows[1].Cells[0];
            exige(Convert.ToString(horarioEspecial.Rows[0].Cells["FIN"].Value) == "09:15" && aplicaciones == 4 &&
                !plan.Calendario.Excepciones.Single(e => e.Nombre == "Cierre de obra").Laborable,
                "Cambiar la excepción seleccionada debe confirmar su celda pendiente en el borrador sin aplicar el calendario.");
            horarioEspecial.CurrentCell = horarioEspecial.Rows[0].Cells["FIN"];
            horarioEspecial.BeginEdit(true);
            horarioEspecial.EditingControl.Text = "07:00";
            excepciones.CurrentCell = excepciones.Rows[0].Cells[0];
            Application.DoEvents();
            exige(excepciones.CurrentRow?.Index == 1 &&
                Convert.ToString(horarioEspecial.Rows[0].Cells["FIN"].Value) == "07:00" && aplicaciones == 4,
                "Un horario inválido de excepción debe impedir abandonar su fila sin perder el texto que se debe corregir.");
            Boton(control, "excepcion_eliminar").PerformClick();
            control.GuardarCambios();
            exige(aplicaciones == 5 && plan.Calendario.Excepciones.Count == 1 &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 5, 1)) == 4,
                "Eliminar un intervalo debe recuperar la jornada anual mediante una sola transacción.");

            AceptarNombre(control, "calendario_agregar", "Turno de verano", exige);
            exige(nombres.Items.Count == 2 && plan.Calendarios.Count == 1 && control.TieneCambios,
                "Crear un calendario debe conservarlo en el borrador hasta guardar y mantener el calendario activo vigente.");
            AceptarNombre(control, "calendario_renombrar", "Turno reducido", exige);
            Boton(control, "calendario_activar").PerformClick();
            dias.SelectedIndex = (int)DayOfWeek.Monday;
            horario.Rows[0].Cells["FIN"].Value = "10:00";
            control.GuardarCambios();
            exige(aplicaciones == 6 && plan.Calendario.Nombre == "Turno reducido" && plan.Calendarios.Count == 2 &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 5)) == 6 &&
                plan.Calendarios.Single(c => c.Nombre == "Predeterminado").HorasDelDia(new DateTime(2026, 1, 5)) == 8,
                "Activar y editar una copia nombrada debe conservar el horario del calendario de origen.");
            string antesConsulta = Huella(plan);
            nombres.SelectedIndex = nombres.Items.IndexOf("Predeterminado");
            exige(!control.TieneCambios && Huella(plan) == antesConsulta && aplicaciones == 6,
                "Cambiar el calendario mostrado para consultarlo debe conservar el calendario activo y el historial.");
            Boton(control, "calendario_eliminar").PerformClick(); control.GuardarCambios();
            exige(aplicaciones == 7 && plan.Calendarios.Count == 1 && plan.Calendario.Nombre == "Turno reducido",
                "Eliminar un calendario secundario debe conservar y sincronizar el calendario activo.");

            autorizado = false; control.Refrescar();
            string sinPermiso = Huella(plan);
            bool lunesAntes = dias.TieneHorario((int)DayOfWeek.Monday);
            dias.SelectedIndex = (int)DayOfWeek.Tuesday;
            Tecla(dias, Keys.Space);
            bool consultaDiaSinPermiso = dias.SelectedIndex == (int)DayOfWeek.Tuesday && horario.Rows.Count > 0;
            Boton(control, "excepcion_agregar").PerformClick();
            Boton(control, "hoy").PerformClick();
            exige(horario.ReadOnly && dias.Enabled && consultaDiaSinPermiso &&
                dias.TieneHorario((int)DayOfWeek.Monday) == lunesAntes &&
                !Boton(control, "guardar").Enabled && Huella(plan) == sinPermiso && aplicaciones == 7 && !control.TieneCambios,
                "Sin permiso de edición debe poder consultarse el calendario y navegar por sus días sin cambiar datos.");
        }
        ComprobarMarcasDeDias(exige);
        ComprobarOpcionesYHoras(exige);
    }

    private static void ComprobarMarcasDeDias(Action<bool, string> exige)
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        int aplicaciones = 0;
        using var control = new MYGTiempoTrabajoCronogramaControl(() => plan, nuevo => { plan = nuevo; aplicaciones++; }, () => true);
        using var ventana = new Form { ClientSize = new Size(1800, 600) };
        ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
        var dias = Campo<MYGDiasTrabajoListBox>(control, "dias");
        var horario = Campo<DataGridView>(control, "horario");
        string original = Huella(plan);
        exige(!typeof(CheckedListBox).IsAssignableFrom(dias.GetType()) &&
            !dias.TieneHorario((int)DayOfWeek.Sunday) && !dias.TieneHorario((int)DayOfWeek.Saturday) &&
            Enumerable.Range(1, 5).All(dias.TieneHorario),
            "La lista semanal debe mostrar marcas informativas sólo en los cinco días con horario, sin casillas editables.");

        var domingo = dias.GetItemRectangle((int)DayOfWeek.Sunday);
        Click(dias, new Point(dias.ClientSize.Width - 10, domingo.Top + domingo.Height / 2));
        Tecla(dias, Keys.Space);
        exige(dias.SelectedIndex == (int)DayOfWeek.Sunday && horario.Rows.Count == 0 &&
            !dias.TieneHorario((int)DayOfWeek.Sunday) && !control.TieneCambios && Huella(plan) == original,
            "Pulsar la columna de marca o Espacio en un día sin turnos debe seleccionarlo sin crear una jornada.");

        Boton(control, "horario_agregar").PerformClick();
        exige(horario.Rows.Count == 1 && dias.TieneHorario((int)DayOfWeek.Sunday) && control.TieneCambios && aplicaciones == 0,
            "Agregar el primer turno debe mostrar inmediatamente la marca del día sin aplicar aún el borrador.");
        control.GuardarCambios();
        decimal horasDomingo = plan.Calendario.HorasDelDia(new DateTime(2026, 1, 11));
        string guardado = Huella(plan);
        Click(dias, new Point(dias.ClientSize.Width - 10, domingo.Top + domingo.Height / 2));
        Tecla(dias, Keys.Space);
        exige(dias.TieneHorario((int)DayOfWeek.Sunday) && horario.Rows.Count == 1 &&
            !control.TieneCambios && Huella(plan) == guardado && aplicaciones == 1 && horasDomingo > 0,
            "Pulsar la marca de un día con turnos o Espacio debe conservar sus horas sin crear cambios ni historial.");
        Boton(control, "horario_eliminar").PerformClick();
        exige(horario.Rows.Count == 0 && !dias.TieneHorario((int)DayOfWeek.Sunday) && control.TieneCambios &&
            plan.Calendario.HorasDelDia(new DateTime(2026, 1, 11)) == horasDomingo,
            "Eliminar el último turno debe retirar la marca inmediatamente y conservar el calendario guardado hasta confirmar.");
        control.GuardarCambios();
        exige(!plan.Calendario.EsLaborable(new DateTime(2026, 1, 11)) && aplicaciones == 2,
            "Guardar la eliminación del último turno debe dejar el día no laborable.");
        dias.SelectedIndex = (int)DayOfWeek.Sunday;
        Boton(control, "horario_agregar").PerformClick();
        exige(dias.TieneHorario((int)DayOfWeek.Sunday) && horario.Rows.Count == 1,
            "La marca debe reaparecer al volver a agregar un horario al día.");
        Boton(control, "horario_eliminar").PerformClick();
        dias.SelectedIndex = (int)DayOfWeek.Monday;
        horario.CurrentCell = horario.Rows[0].Cells[0];
        Boton(control, "horario_eliminar").PerformClick();
        exige(horario.Rows.Count == 1 && dias.TieneHorario((int)DayOfWeek.Monday),
            "Eliminar sólo uno de varios turnos debe conservar la marca del día mientras quede un horario.");
    }

    private static void ComprobarOpcionesYHoras(Action<bool, string> exige)
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 1), FechaEstado = new DateTime(2026, 1, 1) };
        int aplicaciones = 0;
        MYGTiempoTrabajoCronogramaControl Abrir() => new(() => plan, nuevo => { plan = nuevo; aplicaciones++; }, () => true);
        using (var control = Abrir())
        using (var ventana = new Form { ClientSize = new Size(1800, 600) })
        {
            ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
            Boton(control, "excepcion_agregar").PerformClick();
            var tipo = Campo<ComboBox>(control, "excepcion_tipo");
            var desde = Campo<DateTimePicker>(control, "excepcion_desde");
            var hasta = Campo<DateTimePicker>(control, "excepcion_hasta");
            string[] opciones = { "Fecha o rango de fechas", "Día de la semana", "Día del mes",
                "Día de la n-ésima semana del mes", "Día y mes del año", "Día de la n-ésima semana de un mes concreto" };
            exige(tipo.Items.Cast<string>().SequenceEqual(opciones),
                "Las seis reglas de excepción deben conservar el orden de fecha, semana, mes, semana del mes, anual y semana de mes concreto.");
            for (int indice = 0; indice < opciones.Length; indice++)
            {
                tipo.SelectedIndex = indice;
                bool semanal = indice is 1 or 3 or 5, enesima = indice is 3 or 5;
                bool diaMensual = indice is 2 or 4, mesAnual = indice is 4 or 5;
                var semana = Campo<ComboBox>(control, "excepcion_dia_semana");
                var numero = Campo<ComboBox>(control, "excepcion_numero_semana");
                var dia = Campo<NumericUpDown>(control, "excepcion_dia");
                var mes = Campo<ComboBox>(control, "excepcion_mes");
                exige(semana.Visible == semanal && semana.Enabled == semanal &&
                    numero.Visible == enesima && numero.Enabled == enesima &&
                    dia.Visible == diaMensual && dia.Enabled == diaMensual &&
                    mes.Visible == mesAnual && mes.Enabled == mesAnual &&
                    desde.Visible && hasta.Visible && desde.ShowCheckBox && hasta.ShowCheckBox,
                    "La regla «" + opciones[indice] + "» debe mostrar sólo sus campos y permitir límites de vigencia opcionales.");
            }
            tipo.SelectedIndex = 1;
            Campo<ComboBox>(control, "excepcion_dia_semana").SelectedIndex = (int)DayOfWeek.Saturday;
            desde.Checked = hasta.Checked = false;
            Campo<TextBox>(control, "excepcion_nombre").Text = "Sábados laborables";
            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 1;
            Campo<RadioButton>(control, "excepcion_laborable").Checked = true;
            control.GuardarCambios();
            var regla = plan.Calendario.Excepciones.Single();
            exige(aplicaciones == 1 && !control.TieneCambios && regla.TipoEfectivo == MYGTipoExcepcionCalendario.DiaSemana &&
                regla.DiaSemana == DayOfWeek.Saturday && !regla.Inicio.HasValue && !regla.Fin.HasValue &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 3)) == 8 &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 2, 7)) == 8,
                "Una repetición semanal sin límites debe guardarse como vigencia abierta y usar la jornada habitual en los sábados.");
        }
        using (var control = Abrir())
        using (var ventana = new Form { ClientSize = new Size(1800, 600) })
        {
            ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
            var desde = Campo<DateTimePicker>(control, "excepcion_desde");
            var hasta = Campo<DateTimePicker>(control, "excepcion_hasta");
            exige(!control.TieneCambios && Campo<ComboBox>(control, "excepcion_tipo").SelectedIndex == 1 &&
                Campo<ComboBox>(control, "excepcion_dia_semana").SelectedIndex == (int)DayOfWeek.Saturday &&
                !desde.Checked && !hasta.Checked,
                "Reabrir el editor debe recuperar el tipo, el día semanal y ambas vigencias desmarcadas sin crear cambios.");
            desde.Value = new DateTime(2026, 1, 1); desde.Checked = true;
            Campo<TextBox>(control, "excepcion_nombre").Text = "Sábados desde enero";
            control.GuardarCambios();
            exige(aplicaciones == 2 && plan.Calendario.Excepciones.Single().Inicio == new DateTime(2026, 1, 1) &&
                !plan.Calendario.Excepciones.Single().Fin.HasValue &&
                !plan.Calendario.EsLaborable(new DateTime(2025, 12, 27)) &&
                plan.Calendario.EsLaborable(new DateTime(2026, 2, 7)),
                "La vigencia inicial debe ser independiente del límite final y excluir las ocurrencias anteriores.");
            hasta.Value = new DateTime(2026, 1, 31); hasta.Checked = true;
            Campo<TextBox>(control, "excepcion_nombre").Text = "Sábados de enero";
            exige(control.TieneCambios && !plan.Calendario.Excepciones.Single().Fin.HasValue,
                "Cambiar la vigencia final debe permanecer en el borrador hasta guardar.");
            control.GuardarCambios();
            exige(aplicaciones == 3 && !control.TieneCambios &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 3)) == 8 &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 31)) == 8 &&
                !plan.Calendario.EsLaborable(new DateTime(2026, 2, 7)),
                "Guardar los sábados laborables del 1 al 31 de enero debe incluir el último sábado y no repetirse en febrero.");
        }
        using (var control = Abrir())
        using (var ventana = new Form { ClientSize = new Size(1800, 600) })
        {
            ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
            exige(!control.TieneCambios && Campo<DateTimePicker>(control, "excepcion_desde").Checked &&
                Campo<DateTimePicker>(control, "excepcion_desde").Value.Date == new DateTime(2026, 1, 1) &&
                Campo<DateTimePicker>(control, "excepcion_hasta").Checked &&
                Campo<DateTimePicker>(control, "excepcion_hasta").Value.Date == new DateTime(2026, 1, 31),
                "Reabrir el borrador guardado debe recuperar ambos límites inclusive sin modificaciones pendientes.");
            Boton(control, "excepcion_ubicar").PerformClick();
            var estado = Campo<Label>(control, "fecha_actual");
            string conExcepcion = estado.Text, antes = Huella(plan);
            var mostrarBase = Campo<CheckBox>(control, "mostrar_calendario_base");
            mostrarBase.Checked = true;
            exige(conExcepcion.Contains("Laborable") && estado.Text.Contains("No laborable") && estado.Text.EndsWith("(base)") &&
                !control.TieneCambios && Huella(plan) == antes && aplicaciones == 3,
                "Consultar el calendario base debe omitir la excepción semanal en la fecha localizada sin modificar el plan ni el historial.");
            mostrarBase.Checked = false;
            exige(estado.Text == conExcepcion && !control.TieneCambios && Huella(plan) == antes,
                "Salir de la consulta base debe recuperar la jornada excepcional sin crear un cambio pendiente.");
        }

        exige(MYGHoraTrabajoFormato.Minutos("12:00 a. m.", false) == 0 &&
            MYGHoraTrabajoFormato.Minutos("12:00 p. m.", false) == 720 &&
            MYGHoraTrabajoFormato.Minutos("01:35 p. m.", false) == 815 &&
            MYGHoraTrabajoFormato.Minutos("23:59", false) == 1439 &&
            MYGHoraTrabajoFormato.Mostrar(815) == "01:35 p. m.",
            "El editor horario debe interpretar medianoche, mediodía, formato de doce horas y formato de veinticuatro horas sin perder minutos.");
        exige(MYGHoraTrabajoFormato.Minutos("24:00", true) == 1440 &&
            MYGHoraTrabajoFormato.Minutos("24:00", false) == null &&
            MYGHoraTrabajoFormato.Minutos("24:01", true) == null &&
            MYGHoraTrabajoFormato.Minutos("13:00 p. m.", false) == null &&
            MYGHoraTrabajoFormato.Minutos("12:60", false) == null,
            "24:00 debe admitirse sólo como fin del día y los horarios fuera de rango deben conservarse para corregirlos.");
        ComprobarSegmentosHorarios(exige);
        ComprobarAperturaHoraria(exige);
    }

    private static void ComprobarSegmentosHorarios(Action<bool, string> exige)
    {
        using var ventana = new Form { ClientSize = new Size(320, 120) };
        using var editor = new MYGHoraTrabajoEditingControl { Location = new Point(20, 20), Width = 240 };
        ventana.Controls.Add(editor); ventana.Show(); Application.DoEvents();
        var entrada = editor.Controls.OfType<TextBox>().Single();
        var flechas = editor.Controls.Cast<Control>().Single(c => c is not TextBox);
        editor.Inicializar("08:30", false);
        editor.PrepareEditingControlForEdit(true);
        exige(editor.Text == "08:30 a. m." && !editor.EditingControlValueChanged &&
            entrada.SelectionStart == 0 && entrada.SelectionLength == 2,
            "La edición debe mostrar doce horas y seleccionar inicialmente sólo los dos dígitos de hora sin marcar el valor como modificado.");
        ClickCaracter(entrada, 0); Tecla(entrada, Keys.Up);
        exige(editor.Text == "09:30 a. m." && entrada.SelectionStart == 0 && entrada.SelectionLength == 2,
            "Pulsar el primer dígito de hora y subir con el teclado debe seleccionar y cambiar sólo la hora.");
        ClickCaracter(entrada, 1); Tecla(entrada, Keys.Down);
        exige(editor.Text == "08:30 a. m." && entrada.SelectionStart == 0 && entrada.SelectionLength == 2,
            "Pulsar el segundo dígito debe conservar la selección completa de hora y permitir disminuirla.");
        ClickCaracter(entrada, 3); Tecla(entrada, Keys.Up);
        exige(editor.Text == "08:31 a. m." && entrada.SelectionStart == 3 && entrada.SelectionLength == 2,
            "Pulsar el primer dígito de minuto y subir debe modificar sólo los minutos.");
        ClickCaracter(entrada, 4); Tecla(entrada, Keys.Down);
        exige(editor.Text == "08:30 a. m." && entrada.SelectionStart == 3 && entrada.SelectionLength == 2,
            "Pulsar el segundo dígito de minuto debe seleccionar ambos minutos y permitir disminuirlos.");
        ClickCaracter(entrada, 6); Tecla(entrada, Keys.Up);
        exige(editor.Text == "08:30 p. m." && entrada.SelectionStart == 6 && entrada.SelectionLength == 5,
            "Pulsar a. m. y subir debe seleccionar el período completo y cambiarlo a p. m. sin alterar los números.");
        ClickCaracter(entrada, 9); Tecla(entrada, Keys.Down);
        exige(editor.Text == "08:30 a. m." && entrada.SelectionStart == 6 && entrada.SelectionLength == 5,
            "Pulsar cualquier letra del período y bajar debe alternar a. m./p. m. conservando hora y minuto.");
        Click(flechas, new Point(flechas.ClientSize.Width / 2, flechas.ClientSize.Height / 4));
        exige(editor.Text == "08:30 p. m." && entrada.SelectionStart == 6 && entrada.SelectionLength == 5,
            "La flecha superior del control debe conservar el segmento seleccionado al alternar el período.");
        Click(flechas, new Point(flechas.ClientSize.Width / 2, flechas.ClientSize.Height * 3 / 4));
        exige(editor.Text == "08:30 a. m.",
            "La flecha inferior del control debe disminuir o alternar el mismo segmento seleccionado.");

        editor.Inicializar("11:59 p. m.", false);
        ClickCaracter(entrada, 4); Tecla(entrada, Keys.Up);
        exige(editor.Text == "11:00 p. m.",
            "Incrementar 59 minutos debe volver a 00 conservando hora y período.");
        Tecla(entrada, Keys.Down);
        exige(editor.Text == "11:59 p. m.",
            "Disminuir 00 minutos debe volver a 59 sin modificar otro segmento.");
        ClickCaracter(entrada, 0); Tecla(entrada, Keys.Up);
        exige(editor.Text == "12:59 p. m.",
            "Pasar de 11 a 12 horas debe conservar los minutos y el período seleccionado.");
        Tecla(entrada, Keys.Up);
        exige(editor.Text == "01:59 p. m.",
            "Incrementar la hora 12 debe volver a 01 sin cambiar minutos ni período.");
        Tecla(entrada, Keys.Down);
        exige(editor.Text == "12:59 p. m.",
            "Disminuir la hora 01 debe volver a 12 sin cambiar otro segmento.");
        editor.Inicializar("23:59", true);
        ClickCaracter(entrada, 3); Tecla(entrada, Keys.Up);
        exige(editor.Text == "11:00 p. m.",
            "Incluso en una celda de fin los minutos deben girar independientemente sin convertir 23:59 en 24:00.");
        editor.Inicializar("24:00", true);
        exige(editor.Text == "24:00" && MYGHoraTrabajoFormato.Minutos(editor.Text, true) == 1440 &&
            !editor.EditingControlValueChanged,
            "El fin de día 24:00 ingresado manualmente debe conservarse sin cambios al abrir el editor.");
    }

    private static void ComprobarAperturaHoraria(Action<bool, string> exige)
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        string original = Huella(plan);
        int aplicaciones = 0;
        using var control = new MYGTiempoTrabajoCronogramaControl(() => plan, _ => aplicaciones++, () => true);
        using var ventana = new Form { ClientSize = new Size(1800, 600) };
        ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
        var horario = Campo<DataGridView>(control, "horario");
        horario.CurrentCell = horario.Rows[1].Cells["INICIO"];
        horario.BeginEdit(true);
        var editor = (MYGHoraTrabajoEditingControl)horario.EditingControl;
        var entradaInicial = editor.Controls.OfType<TextBox>().Single();
        int[] segmentos = { 0, 3, 6 };
        Point[] posiciones = segmentos.Select(indice =>
            horario.PointToClient(entradaInicial.PointToScreen(PosicionCaracter(entradaInicial, indice)))).ToArray();
        exige(editor.Text == "01:00 p. m." && !editor.EditingControlValueChanged && !control.TieneCambios,
            "Abrir una hora guardada en veinticuatro horas debe mostrarla en doce horas sin crear un cambio pendiente.");
        horario.EndEdit();
        exige(Convert.ToString(horario.Rows[1].Cells["INICIO"].Value) == "13:00" &&
            !control.TieneCambios && Huella(plan) == original && aplicaciones == 0,
            "Confirmar una celda sin cambiar su hora debe conservar el almacenamiento de veinticuatro horas y el historial.");
        for (int indice = 0; indice < segmentos.Length; indice++)
        {
            horario.CancelEdit(); horario.CurrentCell = null;
            Click(horario, posiciones[indice]);
            var entradaPulsada = horario.EditingControl?.Controls.OfType<TextBox>().Single();
            exige(horario.CurrentCell == horario.Rows[1].Cells["INICIO"] && entradaPulsada != null &&
                entradaPulsada.SelectionStart == segmentos[indice] && entradaPulsada.SelectionLength == (indice == 2 ? 5 : 2) &&
                !control.TieneCambios,
                "El primer clic sobre una celda debe abrir la edición y seleccionar el segmento pulsado: " +
                (indice == 0 ? "hora." : indice == 1 ? "minuto." : "período a. m./p. m."));
            horario.EndEdit();
        }
        horario.BeginEdit(true);
        var entrada = horario.EditingControl.Controls.OfType<TextBox>().Single();
        ClickCaracter(entrada, 3); Tecla(entrada, Keys.Up);
        horario.CancelEdit();
        control.FinalizarEdicion();
        exige(Convert.ToString(horario.Rows[1].Cells["INICIO"].Value) == "13:00" &&
            !control.TieneCambios && Huella(plan) == original && aplicaciones == 0,
            "Cancelar una hora modificada en la celda debe recuperar su valor original sin registrar cambios en el calendario.");
    }

    private static void ClickCaracter(TextBox entrada, int indice)
        => Click(entrada, PosicionCaracter(entrada, indice));

    private static Point PosicionCaracter(TextBox entrada, int indice)
    {
        Point posicion = entrada.GetPositionFromCharIndex(indice);
        Point siguiente = entrada.GetPositionFromCharIndex(indice + 1);
        return new Point(posicion.X + Math.Max(1, (siguiente.X - posicion.X) / 2),
            posicion.Y + entrada.Font.Height / 2);
    }

    private static void Click(Control control, Point posicion)
    {
        control.Focus();
        IntPtr coordenadas = new((posicion.Y << 16) | (posicion.X & 0xffff));
        SendMessage(control.Handle, 0x0201, new IntPtr(1), coordenadas);
        SendMessage(control.Handle, 0x0202, IntPtr.Zero, coordenadas);
        Application.DoEvents();
    }

    private static void Tecla(Control control, Keys tecla)
    {
        control.Focus();
        SendMessage(control.Handle, 0x0100, new IntPtr((int)tecla), IntPtr.Zero);
        if (tecla == Keys.Space) SendMessage(control.Handle, 0x0102, new IntPtr(' '), IntPtr.Zero);
        SendMessage(control.Handle, 0x0101, new IntPtr((int)tecla), IntPtr.Zero);
        Application.DoEvents();
    }

    private static void AceptarNombre(Control control, string comando, string nombre, Action<bool, string> exige)
    {
        bool atendido = false;
        Exception fallo = null;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
        temporizador.Tick += (_, _) =>
        {
            var dialogo = Application.OpenForms.Cast<Form>().FirstOrDefault(f => f.Name == Prefijo + "nombre_dialogo");
            if (dialogo == null) return;
            temporizador.Stop();
            try
            {
                Campo<TextBox>(dialogo, "nombre_calendario").Text = nombre;
                Campo<Button>(dialogo, "nombre_aceptar").PerformClick();
                atendido = dialogo.DialogResult == DialogResult.OK;
                if (!atendido) dialogo.Close();
            }
            catch (Exception ex) { fallo = ex; dialogo.Close(); }
        };
        temporizador.Start(); Boton(control, comando).PerformClick(); temporizador.Stop();
        if (fallo != null) throw new InvalidOperationException("No se pudo completar el diálogo de calendario.", fallo);
        exige(atendido, "Agregar y renombrar calendarios debe usar el diálogo real de nombre y aceptar un nombre único.");
    }

    private static bool ResponderCierre(MYGTiempoTrabajoCronogramaControl control, int respuesta)
    {
        bool atendido = false;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
        temporizador.Tick += (_, _) =>
        {
            IntPtr dialogo = FindWindow("#32770", "Tiempo de trabajo");
            if (dialogo == IntPtr.Zero) return;
            temporizador.Stop(); atendido = true;
            SendMessage(dialogo, 0x0111, new IntPtr(respuesta), IntPtr.Zero);
        };
        temporizador.Start(); bool resultado = control.ConfirmarCierre(); temporizador.Stop();
        if (!atendido) throw new InvalidOperationException("El cierre con cambios debe preguntar guardar, descartar o cancelar.");
        return resultado;
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "FindWindowW")]
    private static extern IntPtr FindWindow(string clase, string titulo);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, uint mensaje, IntPtr wParam, IntPtr lParam);

    private static string Huella(MYGCronograma plan) => JsonSerializer.Serialize(plan);
    private static Button Boton(Control raiz, string nombre) => Campo<Button>(raiz, nombre);
    private static T Campo<T>(Control raiz, string nombre) where T : Control =>
        Controles(raiz).OfType<T>().Single(c => c.Name == Prefijo + nombre);
    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
    }
}
