using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Horas de la jornada; mantiene los valores de la tabla en formato HH:mm.</summary>
internal sealed class MYGHoraTrabajoColumn : DataGridViewTextBoxColumn
{
    [DefaultValue(false)]
    public bool PermitirFinDelDia { get; set; }

    public MYGHoraTrabajoColumn() => CellTemplate = new MYGHoraTrabajoCell();

    public override object Clone()
    {
        var copia = (MYGHoraTrabajoColumn)base.Clone();
        copia.PermitirFinDelDia = PermitirFinDelDia;
        return copia;
    }
}

internal enum MYGSegmentoHoraTrabajo { Hora, Minuto, Periodo }

internal static class MYGHoraTrabajoFormato
{
    private static readonly Regex Patron = new(
        @"^\s*(\d{1,2})\s*:\s*(\d{2})\s*(?:([ap])\s*\.?\s*m\s*\.?)?\s*$",
        RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);

    /// <summary>Acepta HH:mm y hh:mm a. m./p. m.; null conserva el error para validarlo en el formulario.</summary>
    internal static int? Minutos(string texto, bool permitirFinDelDia)
    {
        var coincidencia = Patron.Match(texto ?? "");
        if (!coincidencia.Success ||
            !int.TryParse(coincidencia.Groups[1].Value, NumberStyles.None, CultureInfo.InvariantCulture, out int hora) ||
            !int.TryParse(coincidencia.Groups[2].Value, NumberStyles.None, CultureInfo.InvariantCulture, out int minuto) ||
            minuto > 59) return null;

        string periodo = coincidencia.Groups[3].Value;
        if (periodo.Length != 0)
        {
            if (hora is < 1 or > 12) return null;
            hora = hora % 12 + (periodo.Equals("p", StringComparison.OrdinalIgnoreCase) ? 12 : 0);
        }
        else if (hora > 23 && !(permitirFinDelDia && hora == 24 && minuto == 0)) return null;
        return hora * 60 + minuto;
    }

    internal static string Mostrar(int minutos)
    {
        if (minutos is < 0 or > 1440) throw new ArgumentOutOfRangeException(nameof(minutos));
        if (minutos == 1440) return "24:00";
        int hora = minutos / 60;
        return (hora % 12 == 0 ? 12 : hora % 12).ToString("00", CultureInfo.InvariantCulture) + ":" +
            (minutos % 60).ToString("00", CultureInfo.InvariantCulture) + (hora < 12 ? " a. m." : " p. m.");
    }

    internal static string Guardar(int minutos) => (minutos / 60).ToString("00", CultureInfo.InvariantCulture) + ":" +
        (minutos % 60).ToString("00", CultureInfo.InvariantCulture);

    /// <summary>Cambia un único componente; ni los minutos ni las horas arrastran al siguiente.</summary>
    internal static int IncrementarSegmento(int minutos, MYGSegmentoHoraTrabajo segmento, int direccion)
    {
        if (minutos is < 0 or > 1440) throw new ArgumentOutOfRangeException(nameof(minutos));
        if (direccion == 0) return minutos;
        direccion = Math.Sign(direccion);
        // 24:00 es el límite especial que puede escribirse en FIN. Para editar sus números,
        // se toma como medianoche; nunca se genera un valor inválido como 24:01.
        int hora = minutos % 1440 / 60;
        int minuto = minutos % 60;
        return segmento switch
        {
            MYGSegmentoHoraTrabajo.Hora => (hora / 12 * 12 + (hora % 12 + direccion + 12) % 12) * 60 + minuto,
            MYGSegmentoHoraTrabajo.Minuto => hora * 60 + (minuto + direccion + 60) % 60,
            MYGSegmentoHoraTrabajo.Periodo => (minutos + 720) % 1440,
            _ => throw new ArgumentOutOfRangeException(nameof(segmento))
        };
    }
}

internal sealed class MYGHoraTrabajoCell : DataGridViewTextBoxCell
{
    public MYGHoraTrabajoCell() { }

    public override Type EditType => typeof(MYGHoraTrabajoEditingControl);

    protected override object GetFormattedValue(object value, int rowIndex, ref DataGridViewCellStyle cellStyle,
        TypeConverter valueTypeConverter, TypeConverter formattedValueTypeConverter, DataGridViewDataErrorContexts context)
    {
        string texto = Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
        return MYGHoraTrabajoFormato.Minutos(texto, true) is int minutos ? MYGHoraTrabajoFormato.Mostrar(minutos) : texto;
    }

    public override object ParseFormattedValue(object formattedValue, DataGridViewCellStyle cellStyle,
        TypeConverter formattedValueTypeConverter, TypeConverter valueTypeConverter)
    {
        string texto = Convert.ToString(formattedValue, CultureInfo.InvariantCulture) ?? "";
        // No sustituir entradas inválidas: el formulario debe conservarlas y permitir su corrección.
        bool permitirFin = (OwningColumn as MYGHoraTrabajoColumn)?.PermitirFinDelDia == true;
        return MYGHoraTrabajoFormato.Minutos(texto, permitirFin) is int minutos ? MYGHoraTrabajoFormato.Guardar(minutos) : texto;
    }

    public override void InitializeEditingControl(int rowIndex, object initialFormattedValue, DataGridViewCellStyle cellStyle)
    {
        base.InitializeEditingControl(rowIndex, initialFormattedValue, cellStyle);
        if (DataGridView?.EditingControl is MYGHoraTrabajoEditingControl editor)
            editor.Inicializar(Convert.ToString(Value, CultureInfo.InvariantCulture) ?? "",
                (OwningColumn as MYGHoraTrabajoColumn)?.PermitirFinDelDia == true);
    }

    protected override void OnMouseDown(DataGridViewCellMouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || DataGridView is not { } tabla ||
            e.RowIndex < 0 || e.ColumnIndex < 0 || !tabla.IsHandleCreated) return;
        var rectangulo = tabla.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
        var punto = tabla.PointToScreen(new Point(rectangulo.Left + e.X, rectangulo.Top + e.Y));
        // EditOnEnter crea el editor durante el primer clic. Reponer después su segmento
        // evita que PrepareEditingControlForEdit seleccione todo o desplace el cursor al final.
        tabla.BeginInvoke(new Action(() =>
        {
            if (!tabla.IsDisposed && ReferenceEquals(tabla.CurrentCell, this) &&
                tabla.EditingControl is MYGHoraTrabajoEditingControl editor)
                editor.SeleccionarDesdePantalla(punto);
        }));
    }
}

/// <summary>Editor por segmentos con flechas nativas y entrada libre validada al confirmar la jornada.</summary>
internal sealed class MYGHoraTrabajoEditingControl : UpDownBase, IDataGridViewEditingControl
{
    private bool inicializando;
    private bool permitirFinDelDia;
    private MYGSegmentoHoraTrabajo segmentoActual;
    private MYGSegmentoHoraTrabajo? segmentoPulsado;
    private TextBox Entrada => Controls.OfType<TextBox>().FirstOrDefault();

    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridView EditingControlDataGridView { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int EditingControlRowIndex { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool EditingControlValueChanged { get; set; }
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public object EditingControlFormattedValue
    {
        get => Text;
        set => Inicializar(Convert.ToString(value, CultureInfo.InvariantCulture) ?? "", permitirFinDelDia);
    }
    public Cursor EditingPanelCursor => Cursors.Default;
    public bool RepositionEditingControlOnValueChange => false;

    public MYGHoraTrabajoEditingControl()
    {
        BorderStyle = BorderStyle.None;
        InterceptArrowKeys = true;
        TabStop = false;
        AccessibleName = "Hora de trabajo. Seleccione la hora, los minutos o a. m./p. m. y use las flechas para cambiarlos. También puede escribir HH:mm.";
        if (Entrada is { } entrada) entrada.KeyDown += EntradaTecla;
    }

    internal void Inicializar(string texto, bool permitirFin)
    {
        inicializando = true;
        try
        {
            permitirFinDelDia = permitirFin;
            Text = MYGHoraTrabajoFormato.Minutos(texto, permitirFin) is int minutos ?
                MYGHoraTrabajoFormato.Mostrar(minutos) : texto;
            segmentoActual = MYGSegmentoHoraTrabajo.Hora;
            segmentoPulsado = null;
            EditingControlValueChanged = false;
        }
        finally { inicializando = false; }
    }

    public object GetEditingControlFormattedValue(DataGridViewDataErrorContexts context) => Text;

    public void ApplyCellStyleToEditingControl(DataGridViewCellStyle estilo)
    {
        Font = estilo.Font ?? Control.DefaultFont;
        ForeColor = estilo.ForeColor;
        BackColor = Color.FromArgb(255, estilo.BackColor);
        TextAlign = estilo.Alignment switch
        {
            DataGridViewContentAlignment.TopRight or DataGridViewContentAlignment.MiddleRight or DataGridViewContentAlignment.BottomRight => HorizontalAlignment.Right,
            DataGridViewContentAlignment.TopCenter or DataGridViewContentAlignment.MiddleCenter or DataGridViewContentAlignment.BottomCenter => HorizontalAlignment.Center,
            _ => HorizontalAlignment.Left
        };
    }

    public void PrepareEditingControlForEdit(bool selectAll)
    {
        if (Entrada is { } entrada && (Control.MouseButtons & MouseButtons.Left) != 0 &&
            entrada.RectangleToScreen(entrada.ClientRectangle).Contains(Control.MousePosition))
            SeleccionarDesdePantalla(Control.MousePosition);
        else SeleccionarSegmento(segmentoActual);
    }

    public bool EditingControlWantsInputKey(Keys keyData, bool dataGridViewWantsInputKey) => (keyData & Keys.KeyCode) switch
    {
        Keys.Up or Keys.Down or Keys.Left or Keys.Right or Keys.Home or Keys.End or Keys.Delete => true,
        Keys.Tab or Keys.Enter or Keys.Escape => false,
        _ => !dataGridViewWantsInputKey
    };

    public override void UpButton() => Incrementar(1);
    public override void DownButton() => Incrementar(-1);

    // UpDownEdit reenvía los eventos del ratón al padre sin emitir MouseDown/MouseUp
    // en el TextBox. Las coordenadas recibidas aquí ya pertenecen al UpDownBase.
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || Entrada is not { } entrada) return;
        var punto = entrada.PointToClient(PointToScreen(e.Location));
        segmentoPulsado = entrada.ClientRectangle.Contains(punto) ?
            SegmentoEnPosicion(entrada.GetCharIndexFromPosition(punto)) : null;
        if (segmentoPulsado.HasValue) SeleccionarSegmento(segmentoPulsado.Value);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button != MouseButtons.Left || Entrada is not { } entrada) return;
        var punto = entrada.PointToClient(PointToScreen(e.Location));
        if (entrada.ClientRectangle.Contains(punto))
            SeleccionarSegmento(segmentoPulsado ?? SegmentoEnPosicion(entrada.GetCharIndexFromPosition(punto)));
        segmentoPulsado = null;
    }

    private void Incrementar(int direccion)
    {
        if (ReadOnly || MYGHoraTrabajoFormato.Minutos(Text, permitirFinDelDia) is not int minutos) return;
        var segmento = SegmentoEnPosicion(Entrada?.SelectionStart ?? 0);
        int siguiente = MYGHoraTrabajoFormato.IncrementarSegmento(minutos, segmento, direccion);
        Text = MYGHoraTrabajoFormato.Mostrar(siguiente);
        Entrada?.Focus();
        SeleccionarSegmento(segmento);
    }

    internal void SeleccionarDesdePantalla(Point punto)
    {
        if (Entrada is not { } entrada || !entrada.RectangleToScreen(entrada.ClientRectangle).Contains(punto)) return;
        SeleccionarSegmento(SegmentoEnPosicion(entrada.GetCharIndexFromPosition(entrada.PointToClient(punto))));
    }

    internal void SeleccionarSegmento(MYGSegmentoHoraTrabajo segmento)
    {
        if (Entrada is not { } entrada) return;
        int separador = Text.IndexOf(':');
        int periodo = InicioPeriodo();
        if (segmento == MYGSegmentoHoraTrabajo.Periodo && periodo < 0) segmento = MYGSegmentoHoraTrabajo.Minuto;
        segmentoActual = segmento;
        int inicio = segmento switch
        {
            MYGSegmentoHoraTrabajo.Minuto => separador < 0 ? 0 : separador + 1,
            MYGSegmentoHoraTrabajo.Periodo => periodo,
            _ => 0
        };
        int longitud = segmento switch
        {
            MYGSegmentoHoraTrabajo.Hora => separador < 0 ? Math.Min(2, Text.Length) : separador,
            MYGSegmentoHoraTrabajo.Periodo => Text.TrimEnd().Length - periodo,
            _ => Math.Min(2, Math.Max(0, Text.Length - inicio))
        };
        entrada.Select(inicio, longitud);
    }

    private MYGSegmentoHoraTrabajo SegmentoEnPosicion(int posicion)
    {
        int separador = Text.IndexOf(':');
        int periodo = InicioPeriodo();
        if (periodo >= 0 && posicion >= periodo) return MYGSegmentoHoraTrabajo.Periodo;
        return separador >= 0 && posicion > separador ? MYGSegmentoHoraTrabajo.Minuto : MYGSegmentoHoraTrabajo.Hora;
    }

    private int InicioPeriodo()
    {
        int separador = Text.IndexOf(':');
        for (int i = Math.Max(0, separador + 1); i < Text.Length; i++)
            if (Text[i] is 'a' or 'A' or 'p' or 'P') return i;
        return -1;
    }

    private void EntradaTecla(object sender, KeyEventArgs e)
    {
        if (e.Alt || e.Control || e.Shift || e.KeyCode is not (Keys.Left or Keys.Right or Keys.Home or Keys.End)) return;
        var actual = SegmentoEnPosicion(Entrada?.SelectionStart ?? 0);
        int ultimo = InicioPeriodo() >= 0 ? 2 : 1;
        int siguiente = e.KeyCode switch
        {
            Keys.Home => 0,
            Keys.End => ultimo,
            Keys.Left => Math.Max(0, (int)actual - 1),
            _ => Math.Min(ultimo, (int)actual + 1)
        };
        SeleccionarSegmento((MYGSegmentoHoraTrabajo)siguiente);
        e.Handled = true;
        e.SuppressKeyPress = true;
    }

    protected override void OnTextChanged(EventArgs e)
    {
        base.OnTextChanged(e);
        if (inicializando) return;
        EditingControlValueChanged = true;
        EditingControlDataGridView?.NotifyCurrentCellDirty(true);
    }

    // UpDownBase debe conservar cualquier texto sin corregirlo antes de la validación del host.
    protected override void ValidateEditText() { }
    protected override void UpdateEditText() { }
}
