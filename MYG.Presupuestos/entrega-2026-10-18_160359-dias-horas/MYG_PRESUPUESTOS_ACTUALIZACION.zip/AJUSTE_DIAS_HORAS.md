# Ajuste de días y edición de horas

Esta entrega complementa la actualización de Tiempo de trabajo publicada en
`bimchimbote-droid/DESCARGAS`, commit
`ae29a12c3e4f7731d39c940cf224afe831fa7ca9`. Entrega anterior:

https://raw.githubusercontent.com/bimchimbote-droid/DESCARGAS/ae29a12c3e4f7731d39c940cf224afe831fa7ca9/MYG.Presupuestos/entrega-2026-10-18_155141-tiempo-trabajo/MYG_PRESUPUESTOS_ACTUALIZACION.zip

Base del código original: `main`, commit
`a84877a3a941c12574559aab73fb3f4a4b0b01d6`.

## Cambios

- La lista de días deja de usar casillas. Cada día muestra una marca verde
  a la derecha cuando tiene uno o más tramos de trabajo.
- Seleccionar un día, pulsar la marca o presionar Espacio no habilita ni
  deshabilita su jornada. Agregar el primer tramo hace aparecer la marca;
  eliminar el último la retira automáticamente.
- Las horas mantienen la presentación `08:00 a. m.` al comenzar la edición.
  Pulsar los dígitos de hora selecciona las horas; pulsar los minutos
  selecciona los minutos; pulsar el período selecciona a. m./p. m.
- Las flechas arriba/abajo del teclado y los botones de incremento actúan
  sobre la parte seleccionada. Las flechas izquierda/derecha permiten
  cambiar de parte.
- Cada segmento es independiente: minutos 59→00 no cambia la hora; horas
  12→01 no cambia el período; sobre a. m./p. m. ambas flechas alternan el
  período conservando hora y minutos.
- Se conserva la entrada manual en formato `HH:mm` o de doce horas. `24:00`
  es un valor especial admitido únicamente como fin de un tramo.
- Abrir o cancelar una celda sin modificar su hora no crea cambios
  pendientes por la diferencia entre los formatos de doce y veinticuatro
  horas. Los datos guardados siguen usando minutos y `HH:mm`.

## Archivos de esta revisión

| Ruta | Acción |
|---|---|
| `MYG.Desktop/TiempoTrabajoCronogramaControl.cs` | REEMPLAZAR |
| `MYG.Desktop/HoraTrabajoGrid.cs` | REEMPLAZAR |
| `MYG.PruebasUI/TiempoTrabajoCronogramaUICheck.cs` | REEMPLAZAR |
| `AJUSTE_DIAS_HORAS.md` | CREAR |

## Aplicación manual

1. Respalde o confirme sus cambios locales. Si sus archivos contienen
   modificaciones posteriores, compárelos antes de reemplazarlos.
2. Si aún no aplicó la entrega anterior de Tiempo de trabajo, aplíquela
   primero; incluye el modelo de calendarios y el selector de colores que
   requiere el panel. Este ZIP contiene únicamente los cuatro archivos que
   cambian en esta revisión.
3. Extraiga este ZIP y copie sus archivos sobre la raíz del proyecto,
   conservando las rutas relativas. No se requiere eliminar archivos ni
   aplicar parches adicionales.
4. Abra `MYG.Presupuestos.sln` en Visual Studio con el SDK .NET 10, restaure
   y compile:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

La propiedad `UseRevitReferencePackages=true` permite compilar sin Revit
instalado. Puede omitirla si utiliza las DLL de su instalación de Revit 2027
mediante su configuración habitual de `RevitInstallDir`.

En Windows, ejecute también:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

## Configuración y comprobación manual

No hay nuevos paquetes, cambios de esquema SQLite ni migraciones manuales.
Validación de esta revisión con SDK .NET 10.0.100: solución completa Release
con 0 errores y 0 advertencias; suite `MYG.Pruebas` con 542 comprobaciones
completadas y código de salida 0. La lógica de incremento se verificó aparte
con 43.245 comprobaciones, incluidos todos los minutos del día, los tres
segmentos y ambas direcciones. Se omitieron Named Pipes de Windows y la
muestra externa opcional LLACUSBAMBA.

Las pruebas WinForms actualizadas se compilaron, pero no se ejecutaron en
Linux; requieren Windows. La comprobación de la lógica numérica no sustituye
la prueba visual de los controles.

Compruebe en Windows las marcas de los siete días, la selección con el
ratón de los tres segmentos, ambas flechas y el spinner. Verifique que
guardar persiste la jornada y que cancelar conserva los valores anteriores.
Compruebe también el tema claro/oscuro y la escala de pantalla que utiliza.

## GitHub

La publicación del ZIP en `DESCARGAS` no actualiza su copia local ni el
repositorio del código. Después de aplicar y probar los archivos, revise
«Cambios de Git» en Visual Studio, confirme su rama `main`, haga Commit y
después Push. Verifique la rama y el commit en GitHub.
