# Corrección de compilación: arranque de MYG y referencias de Revit

## A. Qué corrige

La captura muestra CS5001 en MYG.Desktop, CS0006 en MYG.PruebasUI y una advertencia
MSB3277 en MYG.Revit2027.

En el código de esta sesión existe un Main válido. La captura no demuestra si
en el equipo del usuario Program.cs falta, tiene otro contenido o está excluido.
Esta entrega restaura el archivo completo de arranque, fija
`MYG.Externo.Program` como punto de entrada y lo incluye explícitamente como
código compilable. El flujo de inicio conserva DPI, tema, sesión, login e Inicio.
Si falta el archivo se muestra un mensaje específico antes de compilar.

CS0006 corresponde a la referencia que MYG.PruebasUI necesita de Desktop: al fallar
Desktop no se genera esa DLL. No se entrega ni se pide copiar una DLL de referencia.

La advertencia de Revit sí se reprodujo: una dependencia HTML del núcleo hacía
resolver Microsoft.Extensions.Logging.Abstractions 6.0.0, mientras Revit 2027
requiere 10.0.0. El conector fija explícitamente 10.0.0. No se oculta la advertencia
ni se modifica el núcleo o los permisos de Supabase.

## B. Archivos completos y acciones

Aplicar sobre la entrega anterior de 27 archivos, publicada en DESCARGAS, commit
`24a110740bf14063bef29300d8c0a937f5b29688`. Esta corrección contiene únicamente:

| N.º | Ruta exacta | Acción | Descripción |
| --- | --- | --- | --- |
| 1 | `MYG.Desktop/Program.cs` | REEMPLAZAR | Archivo de arranque completo. Es el Program de Desktop, no el de pruebas. |
| 2 | `MYG.Desktop/MYG.Desktop.csproj` | REEMPLAZAR | Punto de entrada explícito e inclusión de Program.cs. Conserva la conexión comercial integrada. |
| 3 | `MYG.Revit2027/MYG.Revit2027.csproj` | REEMPLAZAR | Unifica Logging.Abstractions con la versión 10 requerida por Revit. |
| 4 | `CORRECCION_COMPILACION.md` | CREAR | Estas instrucciones, diagnóstico y validación. |

## C. Descarga

La respuesta de entrega incluye el ZIP público en una nueva carpeta de
`bimchimbote-droid/DESCARGAS`, su SHA-256 y la verificación mediante descarga.
Los archivos anteriores de DESCARGAS no se sustituyen.

## D. Aplicar en Visual Studio

1. Cierre MYG, Revit y Visual Studio. Respalde o confirme sus cambios en Git antes
   de sustituir archivos; compare especialmente Program.cs si lo personalizó.
2. Extraiga el ZIP en la carpeta donde está `MYG.Presupuestos.sln`, por ejemplo
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, conservando las subcarpetas.
3. Compruebe que se sustituyeron los tres archivos de la tabla. Hay varios archivos
   Program.cs en la solución: este se copia únicamente dentro de MYG.Desktop.
4. Abra `MYG.Presupuestos.sln` de esa misma carpeta. En el Explorador de soluciones,
   haga clic derecho sobre la solución y seleccione Restaurar paquetes NuGet.
   Necesita acceso a la fuente NuGet habitual para obtener Logging.Abstractions 10.
5. Seleccione Release y x64. Ejecute Compilar > Limpiar solución y luego
   Compilar > Recompilar solución.
6. Si desea generar el instalador comercial, utilice el script existente:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1
   ```

## E. Configuración y datos

No hay SQL que ejecutar en esta entrega, ni cambios de JSON o del proyecto
Supabase. Se conservan las correcciones anteriores de colaboración y publicación.
Los dos archivos .csproj se copian completos en sus carpetas; no se convierten a
texto .txt ni se ejecutan por separado. Visual Studio utiliza su configuración al
restaurar y compilar.

## F. Verificación

Entorno de comprobación: SDK .NET 10.0.100, C#, proyectos Windows net10.0-windows
y referencias oficiales de Revit 2027. Proyectos corregidos: MYG.Desktop y
MYG.Revit2027; MYG.PruebasUI también compila al generarse la referencia de Desktop.

Comandos equivalentes desde la carpeta de la solución (opción de comprobación
con las referencias NuGet oficiales, sin necesitar Revit instalado):

```powershell
dotnet restore MYG.Presupuestos.sln -p:Platform=x64 -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:Platform=x64 -p:UseRevitReferencePackages=true --no-restore -m:1
```

En Visual Studio los pasos de la sección D utilizan las DLL de su instalación de
Revit 2027. No cambie las rutas habituales de Revit si ya son correctas.

Resultados comprobados:

- Solución completa Release/x64: cero errores y cero advertencias.
- Reproducción aislada de CS5001 con Program.cs existente pero excluido de
  Compilar: confirmada. Al aplicar los archivos corregidos: cero errores y cero
  advertencias, una sola inclusión de Program.cs y StartupObject correcto.
- Si falta Program.cs: mensaje específico indicando el archivo que debe copiar.
- Metadatos del ensamblado: entrada MYG.Externo.Program.Main, estática, sin
  parámetros, retorno void y atributo STAThread. No se ejecutó el programa Windows.
- Publicación comercial con una conexión pública sintética integrada: compila
  sin errores ni advertencias y el recurso integrado supera su validación.
- Revit: MSB3277 reproducida antes del ajuste y cero errores/advertencias después.
  Se comprobó la resolución por NuGet y por RevitInstallDir, utilizando las DLL
  oficiales de referencia de Revit 2027 en una carpeta de pruebas.

La comprobación del ZIP aplicado y la descarga pública se comunican en la
respuesta de entrega. Estas comprobaciones no ejecutan la interfaz Windows ni
Revit: son validaciones de compilación y metadatos.

## G. GitHub

Esta sesión publica solamente el ZIP autorizado en DESCARGAS. No hace Push al
repositorio del código. Después de comprobar la compilación en su PC, abra
Git > Cambios de Git en Visual Studio, compruebe que trabaja en su rama main,
revise los cuatro archivos, escriba un mensaje y haga Commit. Luego haga Push
cuando usted decida y compruebe en GitHub que main contiene ese commit.

## H. Límites

No se inspeccionaron los archivos locales del equipo de la captura. Si después de
aplicar exactamente estos archivos continúa CS5001, hará falta revisar el contenido
local de MYG.Desktop/Program.cs y la salida completa de compilación de ese equipo.
No se han eliminado ni sustituido bases de datos, licencias o configuraciones de
usuario. El inicio de la interfaz y la carga del conector requieren comprobación
en Windows con la instalación real de Revit.

Base del código utilizada: bimchimbote-droid/MYG.Presupuestos, main,
commit df8392a5d2910216a097349add3d20ba6103bdf5, más las entregas anteriores
conservadas en esta sesión. Compare antes de reemplazar si tiene cambios locales
posteriores en alguno de los tres archivos de código/proyecto.
