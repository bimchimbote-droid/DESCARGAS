using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private bool? permisoUnidadEstructuraAnterior;
    private void ActualizarUnidadEstructura(DataGridViewRow fila, ItemPresupuestoDelphin partida)
    {
        var celda = CeldaEstructura(fila, "UND");
        bool titulo = MYGProyectoStorage.EsTitulo(partida);
        celda.ReadOnly = titulo || !EdicionACUNubePermitida;
        PonerValor(celda, titulo ? null : partida.Unidad);
        celda.Style.Padding = new Padding(4, 4,
            !celda.ReadOnly ? (int)System.Math.Round(21 * DeviceDpi / 96F) : 4, 4);
        bool diferente = !titulo && registroAlertasPartidas?.UnidadDiferente(partida) == true;
        // Sólo se resalta una diferencia comprobada con un registro del catálogo.
        // Una partida nueva o una base no disponible conserva la paleta normal.
        Color color = diferente
            ? SystemInformation.HighContrast ? SystemColors.HotTrack
                : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(255, 170, 70) : Color.FromArgb(184, 82, 0)
            : Color.Empty;
        celda.Style.ForeColor = color;
        celda.Style.SelectionForeColor = diferente && SystemInformation.HighContrast ? SystemColors.HighlightText : color;
        string original = titulo ? null : registroAlertasPartidas?.UnidadCatalogo(partida);
        celda.ToolTipText = titulo ? "" : (diferente
            ? "Unidad modificada en este presupuesto. Unidad guardada en el catálogo: " + original + ". "
            : "") + (celda.ReadOnly ? "Unidad de la partida (solo lectura)."
                : "Seleccione la unidad de medida de la partida (F4 o Alt + flecha abajo).");
    }
}
