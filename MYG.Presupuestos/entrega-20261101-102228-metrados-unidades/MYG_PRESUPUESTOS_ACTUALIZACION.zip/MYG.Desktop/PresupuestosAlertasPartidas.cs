using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly Dictionary<DataGridViewRow, MYGDiagnosticoPartida> alertasPartidas = new();
    private MYGRegistroACUCatalogo registroAlertasPartidas;
    private (string Ruta, long Longitud, long Modificado, long WalLongitud, long WalModificado)? versionRegistroAlertas;
    private MYGTooltipPartida tooltipAlertasPartidas;
    private System.Windows.Forms.Timer esperaAlertasPartidas;
    private AvisoCeldaPartida avisoPendientePartida;
    private bool avisoPartidaVisible;

    private sealed record AvisoCeldaPartida(DataGridViewCell Celda, string Titulo, string Mensaje, MYGTipoIndicadorPartida Tipo);

    private void PrepararAlertasPartidas()
    {
        tooltipAlertasPartidas = new();
        esperaAlertasPartidas = new() { Interval = 300 };
        esperaAlertasPartidas.Tick += (_, _) => MostrarAvisoPartidaPendiente();
        estructura.CellPainting += PintarAlertaPartida;
        estructura.MouseMove += RatonAlertaPartida;
        estructura.MouseLeave += (_, _) => OcultarAvisoPartida();
        estructura.MouseDown += (_, _) => OcultarAvisoPartida();
        estructura.Scroll += (_, _) => OcultarAvisoPartida();
        estructura.ColumnWidthChanged += (_, _) => OcultarAvisoPartida();
        estructura.SelectionChanged += (_, _) => OcultarAvisoPartida();
        estructura.CellBeginEdit += (_, _) => OcultarAvisoPartida();
        estructura.RowsRemoved += (_, _) => { OcultarAvisoPartida(); if (!plegandoEstructura) alertasPartidas.Clear(); };
        estructura.VisibleChanged += (_, _) => { if (!estructura.Visible) OcultarAvisoPartida(); };
        estructura.DpiChangedAfterParent += (_, _) => { OcultarAvisoPartida(); estructura.Invalidate(); };
        Disposed += (_, _) =>
        {
            esperaAlertasPartidas.Dispose(); tooltipAlertasPartidas.Dispose(); alertasPartidas.Clear();
        };
    }

    private void PrepararActualizacionAlertasPartidas()
    {
        OcultarAvisoPartida();
        alertasPartidas.Clear();
        // Esta ruta no llama a RutaCatalogos: ese método puede guardar o crear
        // la base. La comprobación visual sólo usa el lector explícito.
        string ruta = null;
        try { ruta = obtenerRutaLecturaCatalogos?.Invoke(); }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or System.IO.IOException) { }
        // Editar una cantidad no cambia el catálogo. Reusar su instantánea evita
        // releer y deserializar todos los ACU en cada confirmación de celda.
        // Incluir el WAL detecta escrituras SQLite aún no trasladadas al archivo principal.
        var version = VersionRegistroAlertas(ruta);
        if (registroAlertasPartidas == null || !registroAlertasPartidas.Disponible ||
            version == null || version != versionRegistroAlertas)
        {
            registroAlertasPartidas = MYGRegistroACUCatalogo.Leer(ruta);
            var despues = VersionRegistroAlertas(ruta);
            versionRegistroAlertas = version == despues ? despues : null;
        }
    }

    private static (string Ruta, long Longitud, long Modificado, long WalLongitud, long WalModificado)? VersionRegistroAlertas(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta)) return null;
        try
        {
            var archivo = new FileInfo(Path.GetFullPath(ruta));
            if (!archivo.Exists) return null;
            var wal = new FileInfo(archivo.FullName + "-wal");
            return (archivo.FullName, archivo.Length, archivo.LastWriteTimeUtc.Ticks,
                wal.Exists ? wal.Length : 0, wal.Exists ? wal.LastWriteTimeUtc.Ticks : 0);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or System.Security.SecurityException)
        { return null; }
    }

    private void ActualizarAlertaPartida(DataGridViewRow fila, MYGPresupuestoDocumento presupuesto,
        ItemPresupuestoDelphin partida, MYGCalculoPresupuesto calculo)
    {
        ActualizarIndicadoresContenido(fila, partida);
        ActualizarUnidadEstructura(fila, partida);
        var diagnostico = MYGAlertasPartida.Evaluar(presupuesto, partida, calculo,
            registroAlertasPartidas.Estado(partida), registroAlertasPartidas.Detalle);
        if (!diagnostico.EsPartida) return;
        alertasPartidas[fila] = diagnostico;
        if (!diagnostico.Cantidad.HasValue &&
            (!estructura.IsCurrentCellInEditMode || estructura.CurrentCell != CeldaEstructura(fila, "CANT")))
            PonerValor(CeldaEstructura(fila, "CANT"), "#ERROR");
        if (!diagnostico.PrecioUnitario.HasValue) PonerValor(CeldaEstructura(fila, "PU"), "#ERROR");
        if (!diagnostico.Total.HasValue) PonerValor(CeldaEstructura(fila, "TOTAL"), "#ERROR");
        foreach (string columna in new[] { "DESC", "PU", "TOTAL" })
        {
            var celda = CeldaEstructura(fila, columna);
            var margen = MargenCeldaEstructura(celda);
            celda.Style.Padding = new(margen.Left, margen.Top,
                Math.Max(margen.Right, (int)Math.Ceiling(21 * estructura.DeviceDpi / 96d)), margen.Bottom);
        }
    }

    internal MYGDiagnosticoPartida DiagnosticoAlertasPartida(ItemPresupuestoDelphin partida) =>
        alertasPartidas.FirstOrDefault(x => ReferenceEquals(x.Key.Tag, partida)).Value;

    private AvisoCeldaPartida AvisoAlertaCelda(DataGridViewCell celda)
    {
        if (celda?.OwningRow == null || !alertasPartidas.TryGetValue(celda.OwningRow, out var diagnostico)) return null;
        IEnumerable<MYGAlertaPartida> consulta = celda.OwningColumn.Name switch
        {
            "DESC" => diagnostico.Alertas.Where(a => a.Zona == MYGZonaAlertaPartida.Catalogo),
            "PU" => diagnostico.Alertas.Where(a => a.Zona == MYGZonaAlertaPartida.Analisis),
            "TOTAL" => diagnostico.Alertas.Where(a => a.Zona is MYGZonaAlertaPartida.Total or MYGZonaAlertaPartida.Cantidad ||
                a.Tipo == MYGTipoAlertaPartida.ErrorAnalisis),
            _ => Enumerable.Empty<MYGAlertaPartida>()
        };
        var mensajes = consulta.OrderBy(a => a.Severidad == MYGSeveridadAlertaPartida.Error ? 0 :
            a.Tipo == MYGTipoAlertaPartida.TotalCero ? 1 :
            a.Tipo == MYGTipoAlertaPartida.SinAnalisis || a.Tipo == MYGTipoAlertaPartida.SinRegistroACU ? 2 : 3).ToArray();
        if (mensajes.Length == 0) return null;
        MYGTipoIndicadorPartida tipo = diagnostico.Completa ? MYGTipoIndicadorPartida.Completa :
            celda.OwningColumn.Name == "DESC" && mensajes.All(a => a.Severidad == MYGSeveridadAlertaPartida.Mensaje)
                ? MYGTipoIndicadorPartida.Catalogo :
            celda.OwningColumn.Name == "PU" && mensajes[0].Tipo == MYGTipoAlertaPartida.SinAnalisis
                ? MYGTipoIndicadorPartida.Analisis : MYGTipoIndicadorPartida.Advertencia;
        string Texto(MYGAlertaPartida a) => a.Severidad is MYGSeveridadAlertaPartida.Error or MYGSeveridadAlertaPartida.Correcto ||
            a.Tipo == MYGTipoAlertaPartida.RegistroACUSinVerificar
                ? a.Mensaje + (string.IsNullOrWhiteSpace(a.Detalle) ? "" : "\n" + a.Detalle) : a.Mensaje;
        // Los tres avisos habituales conservan el texto breve de la interfaz;
        // los errores de cálculo mantienen sus detalles y los demás diagnósticos.
        bool avisoBreve = mensajes[0].Tipo is MYGTipoAlertaPartida.TotalCero or
            MYGTipoAlertaPartida.SinAnalisis or MYGTipoAlertaPartida.SinRegistroACU;
        return new(celda, mensajes[0].Titulo, avisoBreve ? Texto(mensajes[0]) :
            string.Join("\n\n", mensajes.Select(Texto).Distinct()), tipo);
    }

    internal Rectangle LimitesIndicadorAlerta(DataGridViewCell celda)
    {
        if (celda == null || celda.DataGridView != estructura || celda.RowIndex < 0 || celda.ColumnIndex < 0)
            return Rectangle.Empty;
        if (AvisoAlertaCelda(celda) == null) return Rectangle.Empty;
        var limites = estructura.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, false);
        int tamano = Math.Max(10, (int)Math.Ceiling(13 * estructura.DeviceDpi / 96d));
        int margen = Math.Max(3, (int)Math.Ceiling(4 * estructura.DeviceDpi / 96d));
        int reservaContenido = celda.OwningColumn.Name == "DESC" ? EspacioIndicadorContenido : 0;
        if (limites.Width < tamano + margen * 2 + reservaContenido || limites.Height < tamano) return Rectangle.Empty;
        return new(limites.Right - margen - tamano - reservaContenido, limites.Top + (limites.Height - tamano) / 2, tamano, tamano);
    }

    private void PintarAlertaPartida(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
        var celda = estructura[e.ColumnIndex, e.RowIndex];
        var aviso = AvisoAlertaCelda(celda);
        if (aviso == null) return;
        var limites = LimitesIndicadorAlerta(celda);
        if (limites.IsEmpty) return;
        if (!e.Handled) e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
        var estado = e.Graphics.Save();
        try
        {
            e.Graphics.SetClip(Rectangle.Intersect(e.CellBounds, e.ClipBounds));
            MYGIndicadoresPartida.Pintar(e.Graphics, limites, aviso.Tipo,
                (e.State & DataGridViewElementStates.Selected) != 0);
            e.Handled = true;
        }
        finally { e.Graphics.Restore(estado); }
    }

    private void RatonAlertaPartida(object sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.None)
        { OcultarAvisoPartida(); return; }
        var hit = estructura.HitTest(e.X, e.Y);
        AvisoCeldaPartida siguiente = null;
        if (hit.RowIndex >= 0 && hit.ColumnIndex >= 0)
        {
            var celda = estructura[hit.ColumnIndex, hit.RowIndex];
            if (ZonaHoverAlerta(celda).Contains(e.Location)) siguiente = AvisoAlertaCelda(celda);
        }
        if (Equals(siguiente, avisoPendientePartida)) return;
        OcultarAvisoPartida();
        avisoPendientePartida = siguiente;
        if (siguiente != null) esperaAlertasPartidas.Start();
    }

    private void MostrarAvisoPartidaPendiente()
    {
        esperaAlertasPartidas.Stop();
        var aviso = avisoPendientePartida;
        if (aviso == null || estructura.IsDisposed || !estructura.Visible) return;
        var limites = LimitesIndicadorAlerta(aviso.Celda);
        if (!ZonaHoverAlerta(aviso.Celda).Contains(estructura.PointToClient(Cursor.Position))) { OcultarAvisoPartida(); return; }
        tooltipAlertasPartidas.Mostrar(estructura, new Point(limites.Left, limites.Bottom + 5), aviso.Titulo, aviso.Mensaje, aviso.Tipo);
        avisoPartidaVisible = true;
    }

    private Rectangle ZonaHoverAlerta(DataGridViewCell celda)
    {
        var limites = LimitesIndicadorAlerta(celda);
        if (limites.IsEmpty) return limites;
        int margen = Math.Max(3, (int)Math.Ceiling(4 * estructura.DeviceDpi / 96d));
        limites.Inflate(margen, margen);
        return Rectangle.Intersect(limites,
            estructura.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, true));
    }

    private void OcultarAvisoPartida()
    {
        esperaAlertasPartidas?.Stop();
        if (avisoPartidaVisible && !estructura.IsDisposed) tooltipAlertasPartidas.Ocultar(estructura);
        avisoPartidaVisible = false; avisoPendientePartida = null;
    }
}
