using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;
using MYG_2027;

static class EdicionPartidaCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (InvalidOperationException) { return; }
        catch (InvalidDataException) { return; }
        throw new Exception(mensaje);
    }
    private static MYGPresupuestoDocumento Crear(MYGFuenteMetrado fuente = MYGFuenteMetrado.Cantidad)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "EDICIÓN EN TABLA", Item = "01" };
        var i = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        i.Descripcion = "PARTIDA EDITABLE"; i.Unidad = "und";
        i.Costos.Cantidad = 2.5m; i.Costos.PrecioDirecto = 10;
        i.Costos.Metrados.Add(new() { Descripcion = "METRADO CONSERVADO", Elementos = 1, CantidadPorElemento = 7 });
        i.Costos.MetradosBIM.Add(new() { ActivoId = "ACTIVO-1", DocumentoId = "MODELO-1", Unidad = "und", Cantidad = 8 });
        i.Costos.Hoja.Poner("G16", "9.1256");
        i.Costos.FuenteMetrado = fuente;
        MYGProyectoStorage.ValidarPresupuesto(p);
        return p;
    }
    private static object SQL(string ruta, string consulta)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString()); c.Open();
        using var q = c.CreateCommand(); q.CommandText = consulta; return q.ExecuteScalar();
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        CantidadSinCopiarObraCompleta(pasa);
        HistorialMixtoCantidades(pasa);
        foreach (var fuente in Enum.GetValues<MYGFuenteMetrado>())
        {
            var p = Crear(fuente); var i = p.Items.Single(); var costos = i.Costos;
            var items = p.Items; var manual = costos.Metrados; var bim = costos.MetradosBIM; var hoja = costos.Hoja; var acu = costos.Analisis;
            string fuentes = Firma(new { manual, bim, hoja, acu });
            var instantanea = MYGProyectoStorage.Copia(p);
            MYGEdicionPartida.CambiarCantidad(p, i, 12.34m);
            Exige(i.Costos.Cantidad == 12.34m && i.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
                MYGMotorPresupuestos.Cantidad(p, i) == 12.34m && MYGMotorPresupuestos.TotalPartida(p, i) == 123.40m,
                "Editar la cantidad no activó el metrado directo o no recalculó el total.");
            Exige(ReferenceEquals(items, p.Items) && ReferenceEquals(i, p.Items.Single()) && ReferenceEquals(costos, i.Costos) &&
                ReferenceEquals(manual, i.Costos.Metrados) && ReferenceEquals(bim, i.Costos.MetradosBIM) &&
                ReferenceEquals(hoja, i.Costos.Hoja) && ReferenceEquals(acu, i.Costos.Analisis) &&
                Firma(new { manual, bim, hoja, acu }) == fuentes,
                "Editar cantidad perdió datos de fuentes o sustituyó instancias usadas por el editor.");
            Exige(instantanea.Items.Single().Costos.FuenteMetrado == fuente && instantanea.Items.Single().Costos.Cantidad == 2.5m,
                "La instantánea anterior a la edición se alteró.");
            i.Costos.FuenteMetrado = fuente;
            decimal esperado = fuente switch { MYGFuenteMetrado.Manual => 7m, MYGFuenteMetrado.BIM => 8m, MYGFuenteMetrado.Excel => 9.1256m, _ => 12.34m };
            Exige(MYGMotorPresupuestos.Cantidad(p, i) == esperado, "No se pudo recuperar el metrado anterior desde su fuente.");
        }
        pasa("Edición de cantidad activa el valor directo sin perder fuentes Manual/BIM/Excel, referencias ni instantáneas de historial");

        var limites = Crear(); var partida = limites.Items.Single();
        foreach (decimal cantidad in new[] { 0m, 0.01m, 12.34m, MYGEdicionPartida.CantidadMaxima })
        {
            MYGEdicionPartida.CambiarCantidad(limites, partida, cantidad);
            Exige(MYGMotorPresupuestos.Cantidad(limites, partida) == cantidad, "Se rechazó o redondeó una cantidad válida.");
        }
        foreach (decimal cantidad in new[] { -0.01m, 0.001m, 12.345m, MYGEdicionPartida.CantidadMaxima + 0.01m })
        {
            string antes = Firma(limites);
            Rechaza(() => MYGEdicionPartida.CambiarCantidad(limites, partida, cantidad), "Se aceptó cantidad negativa, excesiva o con más de dos decimales.");
            Exige(Firma(limites) == antes, "Rechazar una cantidad dejó cambios parciales.");
        }
        string firma = Firma(limites);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(limites, Crear().Items.Single(), 1), "Se editó una partida de otro presupuesto.");
        Exige(Firma(limites) == firma, "La referencia inválida cambió el presupuesto.");
        var titulo = MYGEstructuraPresupuestos.InsertarNodo(limites, true); firma = Firma(limites);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(limites, titulo, 1), "Se asignó cantidad a un título.");
        Rechaza(() => MYGEdicionPartida.CambiarUnidad(limites, titulo, "m"), "Se asignó unidad a un título.");
        Exige(Firma(limites) == firma, "Editar un título dejó cambios parciales.");
        var excesivo = Crear(); var enorme = excesivo.Items.Single(); enorme.Costos.Cantidad = 0; enorme.Costos.PrecioDirecto = decimal.MaxValue;
        firma = Firma(excesivo);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(excesivo, enorme, 10), "Se aceptó un importe que desborda decimal.");
        Exige(Firma(excesivo) == firma, "El desbordamiento mutó el presupuesto.");
        pasa("Cantidades admiten cero y dos decimales; límites, títulos, referencias inválidas y desbordamientos se rechazan atómicamente");

        var unidades = Crear(); var conBim = unidades.Items.Single();
        conBim.Unidad = "m2"; conBim.Costos.MetradosBIM.Single().Unidad = "m²";
        MYGEdicionPartida.CambiarUnidad(unidades, conBim, " m² ");
        Exige(conBim.Unidad == "m²" && conBim.Costos.MetradosBIM.Single().Cantidad == 8, "No se aceptó una unidad BIM equivalente.");
        foreach (string invalida in new[] { "m3", "", "   " })
        {
            firma = Firma(unidades);
            Rechaza(() => MYGEdicionPartida.CambiarUnidad(unidades, conBim, invalida), "Se aceptó una unidad vacía o incompatible con BIM.");
            Exige(Firma(unidades) == firma, "La unidad rechazada dejó cambios parciales.");
        }
        conBim.Costos.MetradosBIM.Clear();
        MYGEdicionPartida.CambiarUnidad(unidades, conBim, "m3");
        Exige(conBim.Unidad == "m3" && conBim.Costos.Metrados.Count == 1 && conBim.Costos.Hoja.Celdas["G16"].Contenido == "9.1256",
            "El cambio de unidad perdió los metrados que conserva el usuario.");
        conBim.IdInternoDelphin = "PARTIDA-OFICIAL";
        string identidadUnidad = Firma(new { conBim.Id, conBim.IdLocalMYG, conBim.IdInternoDelphin, conBim.Item, conBim.Descripcion });
        int recuerdosUnidad = 0;
        MYGEdicionPartida.CambiarUnidad(unidades, conBim, "m", () =>
        { Exige(conBim.Unidad == "m3", "La unidad se modificó antes de capturar el historial."); recuerdosUnidad++; });
        Exige(conBim.Unidad == "m" && recuerdosUnidad == 1 &&
            Firma(new { conBim.Id, conBim.IdLocalMYG, conBim.IdInternoDelphin, conBim.Item, conBim.Descripcion }) == identidadUnidad,
            "Cambiar la unidad de una partida oficial debe conservar identidad y capturar el historial antes de aplicar.");
        conBim.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = "ACTIVO-1", DocumentoId = "MODELO-1", Unidad = "m", Cantidad = 8 });
        firma = Firma(unidades);
        Rechaza(() => MYGEdicionPartida.CambiarUnidad(unidades, conBim, "lb"), "Se permitió un cambio incompatible con BIM en una partida oficial.");
        Exige(Firma(unidades) == firma, "Rechazar un cambio incompatible con BIM debe conservar también las partidas oficiales.");
        pasa("Unidades permiten editar partidas oficiales con historial e identidad intactos y protegen metrados BIM incluso con fuente directa");

        var nativo = Crear(); var oficial = nativo.Items.Single(); oficial.IdInternoDelphin = "NATIVA-ORIGINAL";
        oficial.Costos.Cantidad = 3; oficial.Costos.PrecioDirecto = 0.62m;
        MYGMotorPresupuestos.CapturarPrecioDelphin(nativo, oficial, 0.63m, 1.88m);
        string identidad = Firma(new { oficial.Id, oficial.IdLocalMYG, oficial.IdInternoDelphin, oficial.Item, oficial.Descripcion, oficial.Unidad });
        string firmaAnalisis = oficial.Costos.FirmaAnalisisImportadoDelphin;
        Exige(MYGMotorPresupuestos.TotalPartida(nativo, oficial) == 1.88m, "La partida no conserva el parcial inicial nativo.");
        MYGEdicionPartida.CambiarCantidad(nativo, oficial, 4.25m);
        Exige(MYGMotorPresupuestos.ConservaAnalisisDelphin(nativo, oficial) && MYGMotorPresupuestos.Analizar(nativo, oficial).PrecioUnitario == 0.63m &&
            MYGMotorPresupuestos.TotalPartida(nativo, oficial) == 2.68m && oficial.Costos.FirmaAnalisisImportadoDelphin == firmaAnalisis &&
            oficial.Costos.CantidadImportadaDelphin == 3 && oficial.Costos.ParcialImportadoDelphin == 1.88m &&
            Firma(new { oficial.Id, oficial.IdLocalMYG, oficial.IdInternoDelphin, oficial.Item, oficial.Descripcion, oficial.Unidad }) == identidad,
            "Editar cantidad oficial alteró identidad, precio/firma ACU o reutilizó el parcial importado.");
        var proyecto = new MYGProyectoDocumento { Nombre = "EDICIÓN PERSISTIDA", Datos = new MYGDatosProyecto { UsarUbicacion = false }, Presupuestos = new() { nativo } };
        string ruta = Path.Combine(carpeta, "Edición partida.sqlite"); MYGProyectoStorage.Guardar(ruta, proyecto);
        var leido = MYGBaseDatos.LeerProyecto(ruta, proyecto.Id).Presupuestos.Single(); var reabierta = leido.Items.Single();
        Exige(reabierta.Costos.Cantidad == 4.25m && reabierta.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
            reabierta.Costos.Metrados.Count == 1 && reabierta.Costos.MetradosBIM.Single().Cantidad == 8 &&
            MYGMotorPresupuestos.TotalPartida(leido, reabierta) == 2.68m &&
            Convert.ToDecimal(SQL(ruta, "SELECT cantidad FROM costo_unitario WHERE descripcion_costo='PARTIDA EDITABLE'")) == 4.25m &&
            Convert.ToDecimal(SQL(ruta, "SELECT parcial_costo FROM costo_unitario WHERE descripcion_costo='PARTIDA EDITABLE'")) == 2.68m,
            "SQLite no conservó la edición o difiere de las columnas nativas.");
        string rutaUnidad = Path.Combine(carpeta, "Edición unidad.sqlite");
        var unidadPropia = Crear(); var sinBim = unidadPropia.Items.Single(); sinBim.Costos.MetradosBIM.Clear();
        sinBim.IdInternoDelphin = "UNIDAD-OFICIAL";
        MYGEdicionPartida.CambiarUnidad(unidadPropia, sinBim, "m3");
        proyecto = new MYGProyectoDocumento { Nombre = "UNIDAD PERSISTIDA", Datos = new MYGDatosProyecto { UsarUbicacion = false }, Presupuestos = new() { unidadPropia } };
        MYGProyectoStorage.Guardar(rutaUnidad, proyecto);
        var unidadReabierta = MYGBaseDatos.LeerProyecto(rutaUnidad, proyecto.Id).Presupuestos.Single().Items.Single();
        Exige(unidadReabierta.Unidad == "m3" && unidadReabierta.IdInternoDelphin == "UNIDAD-OFICIAL",
            "SQLite no conservó la unidad editada de la partida oficial y su identidad.");
        pasa("Edición oficial conserva precio y firma ACU, recalcula el parcial y persiste cantidades/unidades en SQLite MYG y formato nativo");

        foreach (string nombreCultura in new[] { "en-US", "es-PE", "es-ES" })
        {
            var cultura = CultureInfo.GetCultureInfo(nombreCultura);
            foreach (string texto in new[] { "1234.56", "1234,56", "1,234.56", "1.234,56", " +1234.56 " })
                Exige(MYGFormatoPresupuesto.IntentarCantidad(texto, cultura, out var numero) && numero == 1234.56m,
                    "La cantidad no interpreta separadores explícitos en " + nombreCultura + ": " + texto);
            foreach (string texto in new[] { "1,234", "1.234", "12,34.56", "1,23,456.78", "1.234.56", "1234.567", "-1", "1e3", "NaN", "", "1000000000000.01" })
                Exige(!MYGFormatoPresupuesto.IntentarCantidad(texto, cultura, out _),
                    "La cantidad aceptó separadores ambiguos, precisión/rango inválido en " + nombreCultura + ": " + texto);
            Exige(MYGFormatoPresupuesto.IntentarCantidad("0", cultura, out var cero) && cero == 0 &&
                MYGFormatoPresupuesto.IntentarCantidad("1,234,567.89", cultura, out var miles) && miles == 1234567.89m,
                "La cantidad no admite cero o miles agrupados correctamente.");
        }
        Exige(MYGFormatoPresupuesto.Dinero(1234567.89m) == "1,234,567.89" && MYGFormatoPresupuesto.Cantidad(12.3m) == "12.30" &&
            MYGFormatoPresupuesto.Cantidad(9.1256m) == "9.13", "El formato visual no aplica dos decimales y miles invariantes.");
        pasa("Formato visual usa 1,234,567.89 y dos decimales; entrada en-US/es-PE/es-ES rechaza separadores ambiguos y agrupaciones inválidas");

        var exportacion = MYGExcelPresupuestos.Tabla("FORMATOS", new[] { "Cantidad", "Precio", "Total", "Coeficiente" },
            new[] { new object[] { 1234.5678m, 1234567.8912m, "=A2*B2", 0.1234m }, new object[] { 12.3456m, 33.3333m } });
        foreach (string direccion in new[] { "A2", "B2", "C2", "A3", "B3" }) exportacion.Celdas[direccion].FormatoNumero = "#,##0.00";
        exportacion.Celdas["A3"].Negrita = true; exportacion.Celdas["B3"].Cursiva = true;
        string excel = Path.Combine(carpeta, "Formatos presupuesto.xlsx"); MYGExcelPresupuestos.Guardar(excel, new[] { exportacion });
        using (var libro = ZipFile.OpenRead(excel))
        {
            XNamespace s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            XDocument Leer(string parte) { using var flujo = libro.GetEntry(parte).Open(); return XDocument.Load(flujo); }
            var estilos = Leer("xl/styles.xml"); var celdas = Leer("xl/worksheets/sheet1.xml").Descendants(s + "c")
                .ToDictionary(x => (string)x.Attribute("r"));
            var formatos = estilos.Descendants(s + "numFmt").ToDictionary(x => (int)x.Attribute("numFmtId"), x => (string)x.Attribute("formatCode"));
            var xfs = estilos.Root.Element(s + "cellXfs").Elements(s + "xf").ToArray();
            XElement Estilo(string direccion) => xfs[(int)celdas[direccion].Attribute("s")];
            string Formato(string direccion) => formatos[(int)Estilo(direccion).Attribute("numFmtId")];
            decimal Valor(string direccion) => decimal.Parse(celdas[direccion].Element(s + "v").Value, CultureInfo.InvariantCulture);
            Exige(new[] { "A2", "B2", "C2", "A3", "B3" }.All(d => Formato(d) == "#,##0.00") && Formato("D2") == "0.0000" &&
                Valor("A2") == 1234.5678m && Valor("B2") == 1234567.8912m && Valor("D2") == 0.1234m &&
                Valor("C2") == 1234.5678m * 1234567.8912m && celdas["C2"].Element(s + "f").Value == "A2*B2",
                "Excel no distingue importes/cantidades de dos decimales y coeficientes de cuatro, o redondeó valores/fórmulas.");
            Exige((int)Estilo("A3").Attribute("fontId") == 1 && (int)Estilo("B3").Attribute("fontId") == 2,
                "El nuevo formato numérico eliminó negrita o cursiva.");
        }
        pasa("Excel conserva valores y fórmulas sin redondear y aplica dos decimales con miles a presupuesto, cuatro a coeficientes y estilos de texto");
    }

    private static void CantidadSinCopiarObraCompleta(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "EDICIÓN LOCAL EN OBRA CON HOJAS" };
        var insumo = new MYGInsumo { Codigo = "INSUMO-EDICION", Descripcion = "Insumo de prueba", Precio = 5m,
            Unidad = "und", Grupo = MYGGrupoRecurso.Materiales };
        p.Costos.Insumos.Add(insumo);
        for (int n = 0; n < 160; n++)
        {
            var i = new ItemPresupuestoDelphin
            {
                Id = "EDITAR-" + n, IdLocalMYG = "LOCAL-" + n, TipoPropuesta = "PARTIDA",
                Descripcion = "Partida " + n, Unidad = "und"
            };
            i.Costos.Cantidad = 10m;
            i.Costos.EspecificacionTexto = new string('x', 2048);
            i.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = insumo.Id, Cantidad = 2m });
            for (int fila = 1; fila <= 100; fila++) i.Costos.Hoja.Poner("J" + fila, fila.ToString(CultureInfo.InvariantCulture));
            p.Items.Add(i);
        }
        MYGProyectoStorage.ValidarPresupuesto(p);
        var partida = p.Items[80];
        var contextos = p.Items.Select(i => i.Costos.Hoja.ContextoReferencias).ToArray();
        var hojas = p.Items.Select(i => i.Costos.Hoja).ToArray();
        MYGEdicionPartida.CambiarCantidad(p, partida, 11m); // Calentar serializador y cálculo.
        long inicial = GC.GetAllocatedBytesForCurrentThread();
        int recuerdos = 0;
        MYGEdicionPartida.CambiarCantidad(p, partida, 12m, () =>
        {
            Exige(partida.Costos.Cantidad == 11m, "Recordar recibió una partida ya modificada.");
            recuerdos++;
        });
        long asignados = GC.GetAllocatedBytesForCurrentThread() - inicial;
        Exige(asignados < 16 * 1024 * 1024,
            "Editar una sola cantidad volvió a copiar las hojas y especificaciones de toda la obra.");
        Exige(recuerdos == 1 && partida.Costos.Cantidad == 12m &&
            MYGMotorPresupuestos.Resumen(p).CostoDirecto == 16020m,
            "La edición local no recalculó el importe correcto o recordó más de una vez.");
        Exige(p.Items.Select((i, n) => ReferenceEquals(hojas[n], i.Costos.Hoja) &&
            ReferenceEquals(contextos[n], i.Costos.Hoja.ContextoReferencias)).All(x => x),
            "El cálculo candidato sustituyó o reasoció las hojas originales.");
        string anterior = Firma(p);
        Rechaza(() => MYGEdicionPartida.CambiarCantidad(p, partida, 13m,
            () => throw new InvalidOperationException("Historial rechazado")), "Se ignoró el rechazo del historial.");
        Exige(Firma(p) == anterior, "El fallo anterior a aplicar dejó un cambio parcial en el documento.");
        pasa("Cambiar cantidad en una obra con 160 ACU y 16.000 celdas evita copiar la obra, conserva vínculos y recuerda antes de aplicar");
    }

    private static void HistorialMixtoCantidades(Action<string> pasa)
    {
        var p = Crear(MYGFuenteMetrado.Excel);
        var documento = new MYGProyectoDocumento { Nombre = "HISTORIAL MIXTO", Presupuestos = new() { p } };
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        string presupuestoId = p.Id, partidaId = p.Items.Single().Id;
        ItemPresupuestoDelphin Partida() => documento.Presupuestos.Single(x => x.Id == presupuestoId).Items.Single(x => x.Id == partidaId);
        var deshacer = new System.Collections.Generic.Stack<MYGEntradaHistorialProyecto>();
        var rehacer = new System.Collections.Generic.Stack<MYGEntradaHistorialProyecto>();
        string inicial = Firma(documento);
        deshacer.Push(MYGEntradaHistorialProyecto.CapturarCantidad(documento, p, Partida()));
        MYGEdicionPartida.CambiarCantidad(p, Partida(), 12m);
        string primeraCantidad = Firma(documento);
        deshacer.Push(MYGEntradaHistorialProyecto.Capturar(documento));
        Partida().Descripcion = "CAMBIO COMPLETO";
        string descripcion = Firma(documento);
        deshacer.Push(MYGEntradaHistorialProyecto.CapturarCantidad(documento, p, Partida()));
        MYGEdicionPartida.CambiarCantidad(p, Partida(), 15m);
        string final = Firma(documento);
        void Mover(System.Collections.Generic.Stack<MYGEntradaHistorialProyecto> desde,
            System.Collections.Generic.Stack<MYGEntradaHistorialProyecto> hacia)
        {
            var entrada = desde.Peek();
            var inversa = entrada.CapturarInversa(documento);
            documento = entrada.Aplicar(documento);
            desde.Pop(); hacia.Push(inversa);
        }
        var mismaPartida = Partida(); var mismaHoja = mismaPartida.Costos.Hoja;
        var candidato = deshacer.Peek().CrearCandidato(documento);
        Exige(Firma(documento) == final && candidato.Presupuestos.Single().Items.Single().Costos.Cantidad == 12m,
            "Preparar la comprobación de permisos del historial cambió el documento o perdió el valor anterior.");
        Mover(deshacer, rehacer);
        Exige(Firma(documento) == descripcion && ReferenceEquals(mismaPartida, Partida()) &&
            ReferenceEquals(mismaHoja, Partida().Costos.Hoja), "Deshacer cantidad sustituyó instancias o perdió la edición completa anterior.");
        Mover(deshacer, rehacer);
        Exige(Firma(documento) == primeraCantidad, "Deshacer una edición completa perdió la cantidad anterior.");
        Mover(deshacer, rehacer);
        Exige(Firma(documento) == inicial && Partida().Costos.FuenteMetrado == MYGFuenteMetrado.Excel,
            "Deshacer la primera cantidad no restauró su fuente Excel ni el documento inicial.");
        foreach (string esperado in new[] { primeraCantidad, descripcion, final })
        {
            Mover(rehacer, deshacer);
            Exige(Firma(documento) == esperado, "Rehacer un historial mixto perdió el orden o el contenido del proyecto.");
        }
        long antes = GC.GetAllocatedBytesForCurrentThread();
        var partidas = documento.Presupuestos.Single();
        for (int n = 0; n < 1000; n++)
            _ = MYGEntradaHistorialProyecto.CapturarCantidad(documento, partidas, Partida());
        Exige(GC.GetAllocatedBytesForCurrentThread() - antes < 1024 * 1024,
            "El registro compacto de cantidades volvió a copiar el documento completo.");
        var huerfana = deshacer.Peek();
        documento.Presupuestos.Clear();
        string sinPartida = Firma(documento);
        Rechaza(() => huerfana.Aplicar(documento), "El historial aceptó una partida que ya no existe.");
        Exige(Firma(documento) == sinPartida, "El historial huérfano cambió parcialmente el proyecto.");
        pasa("Historial mixto de cantidades y ediciones completas conserva fuentes, orden undo/redo, permisos y referencias sin copiar el proyecto al registrar cada cantidad");
    }
}
