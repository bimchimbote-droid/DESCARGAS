using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class PreciosInicioCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Precios visibles al abrir", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        presupuesto.Item = "01";
        presupuesto.Costos.GastosGeneralesPorcentaje = 10m;
        presupuesto.Costos.UtilidadPorcentaje = 7m;
        presupuesto.Costos.ImpuestoPorcentaje = 18m;
        var operario = new MYGInsumo
        {
            Codigo = "I-000001", Descripcion = "OPERARIO", Unidad = "hh",
            Grupo = MYGGrupoRecurso.ManoObra, Precio = 18m
        };
        var cemento = new MYGInsumo
        {
            Codigo = "I-000002", Descripcion = "CEMENTO PORTLAND TIPO I", Unidad = "und",
            Grupo = MYGGrupoRecurso.Materiales, Precio = 26m
        };
        presupuesto.Costos.Insumos.AddRange(new[] { operario, cemento });
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Item = "01", Posicion = 1,
            TipoPropuesta = "PARTIDA", Descripcion = "PARTIDA CON ANÁLISIS EXISTENTE", Unidad = "m²",
            Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida
            {
                Cantidad = 2m, FuenteMetrado = MYGFuenteMetrado.Cantidad,
                EspecificacionTexto = "Especificación existente que debe conservarse."
            }
        };
        partida.Costos.Analisis.AddRange(new[]
        {
            new MYGRecursoACU { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = operario.Id, Cantidad = 2m },
            new MYGRecursoACU { Grupo = MYGGrupoRecurso.Materiales, InsumoId = cemento.Id, Cantidad = 1m }
        });
        presupuesto.Items.Add(partida);
        MYGProyectoStorage.Validar(proyecto);
        string firma = MYGProyectoStorage.Firma(proyecto);

        // Una sesión sin autorización debe permitir mostrar los importes ya
        // guardados. La prueba no inicia sesión ni consulta servicios externos.
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion, firma);
        editor.WindowState = FormWindowState.Normal;
        editor.ClientSize = new Size(1600, 900);
        var panel = Campo<MYGPanelPresupuesto>(editor, "panelPresupuesto");
        var estructura = Campo<DataGridView>(panel, "estructura");
        var tablaPie = Campo<DataGridView>(panel, "tablaPie");
        var grafico = Campo<MYGGraficoIncidencia>(panel, "graficoIncidencia");
        editor.Show();
        Application.DoEvents();
        VerificarImportes("al abrir el proyecto");

        exige(!sesion.Autorizado && sesion.Credencial == null && !panel.Enabled,
            "Los precios deben mostrarse con la sesión vencida, conservando el bloqueo de edición y sin pedir credenciales.");
        var barra = Campo<FlowLayoutPanel>(editor, "cintaPresupuestos");
        string[] botones =
        {
            "ir_inicio_button", "guardar_proyecto_button", "imprimir_proyecto_button", "info_proyecto_button", "exportar_proyecto_button",
            "formula_polinomica_button", "calendario_adquisiciones_button", "calendario_valorizado_button", "resumen_costos_button",
            "responsables_proyecto_button", "especificaciones_button", "valorizacion_button", "permisos_proyecto_button"
        };
        exige(barra.Controls.Cast<Button>().Select(b => b.Name).SequenceEqual(botones),
            "Restaurar los precios debe conservar únicamente los trece botones solicitados en la barra superior.");

        panel.Refrescar();
        Application.DoEvents();
        VerificarImportes("tras refrescar la estructura");
        editor.Hide();
        panel.Refrescar();
        editor.Show();
        Application.DoEvents();
        VerificarImportes("tras ocultar y volver a mostrar el editor");
        panel.Visible = false;
        panel.Refrescar();
        panel.Visible = true;
        Application.DoEvents();
        VerificarImportes("tras ocultar y volver a mostrar el panel");
        panel.SeleccionarEstructura(partida);
        Application.DoEvents();
        VerificarImportes("al seleccionar la partida con ACU");
        var acu = Campo<DataGridView>(panel, "acu");
        exige(acu.Rows.Cast<DataGridViewRow>().Where(r => r.Tag is MYGRecursoACU)
                .Select(r => Convert.ToDecimal(r.Cells["TOTAL"].Value)).SequenceEqual(new[] { 36m, 26m }),
            "El ACU existente debe mostrar 36 de mano de obra y 26 de materiales, coherentes con el precio unitario 62 de la estructura.");

        void VerificarImportes(string momento)
        {
            var fila = estructura.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is ItemPresupuestoDelphin i && i.Id == partida.Id);
            var raiz = estructura.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is MYGPresupuestoDocumento p && p.Id == presupuesto.Id);
            exige(fila.Cells["CANT"].Value is decimal cantidad && cantidad == 2m &&
                fila.Cells["PU"].Value is decimal precio && precio == 62m &&
                fila.Cells["TOTAL"].Value is decimal total && total == 124m &&
                raiz.Cells["TOTAL"].Value is decimal directo && directo == 124m,
                $"Cantidad, precio y totales deben estar visibles {momento}, sin pulsar Actualizar metrado Excel.");
            string[] conceptos = { "Costo directo", "Gastos generales", "Utilidad", "Parcial", "I.G.V.", "Otros impuestos", "Total" };
            decimal[] importes = { 124m, 12.40m, 8.68m, 145.08m, 26.11m, 0m, 171.19m };
            exige(tablaPie.Rows.Count == conceptos.Length && tablaPie.Rows.Cast<DataGridViewRow>()
                    .Select(r => Convert.ToString(r.Cells["CONCEPTO"].Value)).SequenceEqual(conceptos) &&
                tablaPie.Rows.Cast<DataGridViewRow>().Select(r => Convert.ToString(r.Cells["IMPORTE"].Value))
                    .SequenceEqual(importes.Select(MYGFormatoPresupuesto.Dinero)),
                $"El pie debe mostrar sus siete conceptos y el total 171.19 {momento}, sin una actualización manual de Excel.");
            var datos = Campo<List<MYGIncidenciaCosto>>(grafico, "datos");
            exige(Campo<string>(grafico, "error") == null && datos.Sum(d => d.Importe) == 124m &&
                datos.Single(d => d.Nombre == "MANO DE OBRA").Importe == 72m &&
                datos.Single(d => d.Nombre == "MATERIALES").Importe == 52m,
                $"La incidencia debe cargar 72 de mano de obra y 52 de materiales {momento}, en lugar de mostrar Sin costos.");
            exige(MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editor, "documento")) == firma &&
                Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "undo").Count == 0 &&
                Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "redo").Count == 0,
                $"Mostrar precios, pie e incidencia {momento} no debe modificar el modelo ni crear historial.");
        }
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
}
