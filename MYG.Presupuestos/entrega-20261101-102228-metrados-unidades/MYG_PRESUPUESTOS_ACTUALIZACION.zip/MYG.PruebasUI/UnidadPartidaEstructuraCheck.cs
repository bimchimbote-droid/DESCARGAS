using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class UnidadPartidaEstructuraCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-UnidadEstructura-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        bool oscuroOriginal = MYG2027_TemaComercial.Oscuro;
        try
        {
            string ruta = Path.Combine(carpeta, "Catalogo sintetico.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            var proyecto = MYGProyectoStorage.Nuevo("Unidades editables", "ESTRUCTURAS");
            var presupuesto = proyecto.Presupuestos.Single();
            var oficial = Partida("PARTIDA OFICIAL DELPHIN", "m2", 1);
            var nueva = Partida("PARTIDA SIN REGISTRO", "und", 2);
            presupuesto.Items.AddRange([oficial, nueva]);
            var entrada = MYGCatalogos.GuardarPartida(ruta, presupuesto, oficial,
                "OFICIAL-UNIDAD-01", oficial.Descripcion, oficial.Unidad);
            oficial.IdInternoDelphin = "OFICIAL-DEL-01";
            oficial.IdCatalogoDelphin = entrada.Id;
            oficial.Costos.CatalogoMYGId = entrada.Id;
            oficial.Costos.CatalogoMYGRuta = ruta;
            MYGProyectoStorage.Validar(proyecto);
            string hash = Huella(ruta);
            int anteriores = 0, cambios = 0, guardados = 0, rutasEscritura = 0;
            using var panel = new MYGPanelPresupuesto(() => presupuesto, () => anteriores++, () => cambios++,
                _ => { }, () => Task.CompletedTask, _ => { }, () => guardados++);
            panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (nodo, columna, texto) =>
            {
                if (columna != "UND" || nodo is not ItemPresupuestoDelphin partida)
                    throw new InvalidOperationException("La prueba sólo espera ediciones de unidad.");
                MYGEdicionPartida.CambiarUnidad(presupuesto, partida, texto, () => anteriores++);
                cambios++;
            }, () => MYGCatalogoUnidades.Listar(ruta).Concat(new[]
                { new MYGUnidadCatalogo { Simbolo = "m²", Descripcion = "Metro cuadrado" } }));
            panel.InicializarCatalogos(() => { rutasEscritura++; return ruta; }, () => true, () => { }, () => ruta);
            using var formulario = new Form { ClientSize = new Size(1600, 900) };
            formulario.Controls.Add(panel);
            formulario.Show(); panel.Refrescar(); panel.SeleccionarEstructura(oficial); Application.DoEvents();
            var tabla = Campo<DataGridView>(panel, "estructura");
            var registroInicial = Campo<MYGRegistroACUCatalogo>(panel, "registroAlertasPartidas");
            string sinEditar = JsonSerializer.Serialize(proyecto);
            panel.Refrescar(); panel.SeleccionarEstructura(oficial); Application.DoEvents();
            exige(ReferenceEquals(registroInicial, Campo<MYGRegistroACUCatalogo>(panel, "registroAlertasPartidas")),
                "Refrescar un catálogo SQLite intacto debe reutilizar su instantánea, sin deserializar de nuevo todos los ACU.");
            var cantidad = Fila(oficial).Cells["CANT"];
            tabla.CurrentCell = cantidad;
            tabla.Focus();
            InvocarEn(typeof(DataGridView), tabla, "OnCellMouseClick",
                new DataGridViewCellMouseEventArgs(cantidad.ColumnIndex, cantidad.RowIndex, 4, 4,
                    new MouseEventArgs(MouseButtons.Left, 1, 4, 4, 0)));
            exige(tabla.IsCurrentCellInEditMode, "La comprobación de caché debe entrar en el editor real de Cantidad.");
            panel.FinalizarEdicion(); Application.DoEvents();
            exige(ReferenceEquals(registroInicial, Campo<MYGRegistroACUCatalogo>(panel, "registroAlertasPartidas")) &&
                JsonSerializer.Serialize(proyecto) == sinEditar && anteriores == 0 && cambios == 0 && guardados == 0,
                "Confirmar Cantidad intacta debe conservar tanto la instantánea del catálogo como los datos e historial.");
            exige(!Fila(oficial).Cells["UND"].ReadOnly && !Fila(nueva).Cells["UND"].ReadOnly,
                "La unidad debe ser editable tanto en una partida oficial Delphin como en una nueva.");
            exige(Fila(oficial).Cells["UND"].Style.ForeColor.IsEmpty && Fila(nueva).Cells["UND"].Style.ForeColor.IsEmpty,
                "Las unidades iguales al registro y las partidas sin registro deben comenzar con el color normal.");

            Elegir(oficial, "kg");
            exige(oficial.Unidad == "kg" && anteriores == 1 && cambios == 1 && guardados == 0 &&
                MYGRegistroACUCatalogo.Leer(ruta).UnidadCatalogo(oficial) == entrada.Unidad && Huella(ruta) == hash,
                "Elegir otra unidad en la partida oficial debe cambiar una sola vez el presupuesto, conservando el catálogo SQLite.");
            ComprobarNaranja();
            string modificada = JsonSerializer.Serialize(proyecto);
            foreach (bool oscuro in new[] { false, true })
            {
                if (MYG2027_TemaComercial.Oscuro != oscuro) MYG2027_TemaComercial.Alternar(false);
                panel.AplicarTemaPresupuestos();
                panel.SeleccionarEstructura(nueva); Application.DoEvents();
                ComprobarNaranja();
                panel.SeleccionarEstructura(oficial); Application.DoEvents();
                ComprobarNaranja();
                exige(JsonSerializer.Serialize(proyecto) == modificada && Huella(ruta) == hash &&
                    anteriores == 1 && cambios == 1 && guardados == 0 && rutasEscritura == 0,
                    "Alternar el tema y cambiar la selección deben conservar el aviso de unidad sin editar ni guardar datos.");
            }
            Elegir(oficial, "m²");
            exige(MYGProyectoStorage.MismaUnidad(oficial.Unidad, "m2") && anteriores == 2 && cambios == 2 &&
                Fila(oficial).Cells["UND"].Style.ForeColor.IsEmpty &&
                Fila(oficial).Cells["UND"].Style.SelectionForeColor.IsEmpty,
                "Recuperar la unidad del catálogo mediante el alias m²/m2 debe quitar el naranja, también en selección.");
            Elegir(nueva, "kg");
            exige(nueva.Unidad == "kg" && anteriores == 3 && cambios == 3 &&
                Fila(nueva).Cells["UND"].Style.ForeColor.IsEmpty &&
                Fila(nueva).Cells["UND"].Style.SelectionForeColor.IsEmpty &&
                Huella(ruta) == hash && guardados == 0 && rutasEscritura == 0,
                "Cambiar la unidad de una partida sin registro debe conservar el color normal y no crear registros en el catálogo.");

            Elegir(oficial, "kg");
            ComprobarNaranja();
            var registroPrevio = Campo<MYGRegistroACUCatalogo>(panel, "registroAlertasPartidas");
            string presupuestoAntesDeRegistrar = JsonSerializer.Serialize(proyecto);
            // Mutación intencional de la SQLite sintética: el catálogo ahora
            // conserva la unidad que el usuario eligió para su presupuesto.
            MYGCatalogos.GuardarPartida(ruta, presupuesto, oficial, entrada.Codigo,
                oficial.Descripcion, "kg", entrada.Id, entrada.Revision);
            panel.Refrescar(); panel.SeleccionarEstructura(oficial); Application.DoEvents();
            var registroActualizado = Campo<MYGRegistroACUCatalogo>(panel, "registroAlertasPartidas");
            exige(!ReferenceEquals(registroPrevio, registroActualizado) &&
                registroPrevio.UnidadCatalogo(oficial) == entrada.Unidad && registroActualizado.UnidadCatalogo(oficial) == "kg" &&
                Fila(oficial).Cells["UND"].Style.ForeColor.IsEmpty &&
                Fila(oficial).Cells["UND"].Style.SelectionForeColor.IsEmpty &&
                JsonSerializer.Serialize(proyecto) == presupuestoAntesDeRegistrar && anteriores == 4 && cambios == 4 && guardados == 0,
                "Un cambio real del catálogo debe invalidar la caché y retirar el naranja cuando la unidad coincide, sin editar el presupuesto al refrescar.");

            foreach (bool soloACU in new[] { true, false })
            {
                panel.ConfigurarPermisoNube(() => soloACU, () => new MYGPermisosModulos { Acu = false });
                panel.SeleccionarEstructura(oficial); Application.DoEvents();
                var celdaBloqueada = Fila(oficial).Cells["UND"];
                exige(celdaBloqueada.ReadOnly && Fila(nueva).Cells["UND"].ReadOnly,
                    "Bloquear ACU o la edición global debe cerrar la edición de unidades oficiales y nuevas.");
                InvocarEn(typeof(DataGridView), tabla, "OnCellMouseClick",
                    new DataGridViewCellMouseEventArgs(celdaBloqueada.ColumnIndex, celdaBloqueada.RowIndex, 4, 4,
                        new MouseEventArgs(MouseButtons.Left, 1, 4, 4, 0)));
                exige(Campo<MYGSelectorUnidadPartida>(panel, "selectorUnidadEstructura") == null &&
                    JsonSerializer.Serialize(proyecto) == presupuestoAntesDeRegistrar && anteriores == 4 && cambios == 4,
                    "La unidad bloqueada debe ignorar el clic sin abrir el selector ni modificar datos o historial.");
            }
            formulario.Close();

            DataGridViewRow Fila(ItemPresupuestoDelphin partida) => tabla.Rows.Cast<DataGridViewRow>()
                .Single(f => ReferenceEquals(f.Tag, partida));

            void Elegir(ItemPresupuestoDelphin partida, string simbolo)
            {
                panel.SeleccionarEstructura(partida); Application.DoEvents();
                var fila = Fila(partida);
                tabla.CurrentCell = fila.Cells["UND"];
                tabla.Focus();
                InvocarEn(typeof(DataGridView), tabla, "OnCellMouseClick",
                    new DataGridViewCellMouseEventArgs(tabla.Columns["UND"].Index, fila.Index, 4, 4,
                        new MouseEventArgs(MouseButtons.Left, 1, 4, 4, 0)));
                var selector = Campo<MYGSelectorUnidadPartida>(panel, "selectorUnidadEstructura");
                exige(selector is { Visible: true }, "Un clic en UND debe abrir el selector real, incluso en una partida oficial Delphin.");
                var unidades = Campo<DataGridView>(selector, "tabla");
                var elegida = unidades.Rows.Cast<DataGridViewRow>().Single(f => Convert.ToString(f.Tag) == simbolo);
                unidades.CurrentCell = elegida.Cells[0];
                InvocarEn(typeof(Control), unidades, "OnKeyDown", new KeyEventArgs(Keys.Enter));
                Application.DoEvents(); Application.DoEvents();
                exige(Campo<MYGSelectorUnidadPartida>(panel, "selectorUnidadEstructura") == null &&
                    Convert.ToString(Fila(partida).Cells["UND"].Value) == MYGCatalogoUnidades.SimboloVisible(partida.Unidad),
                    "Enter debe cerrar el selector y actualizar la unidad visible sin dejar una edición pendiente.");
            }

            void ComprobarNaranja()
            {
                Color esperado = SystemInformation.HighContrast ? SystemColors.HotTrack
                    : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(255, 170, 70) : Color.FromArgb(184, 82, 0);
                Color seleccion = SystemInformation.HighContrast ? SystemColors.HighlightText : esperado;
                var celda = Fila(oficial).Cells["UND"];
                exige(celda.Style.ForeColor == esperado && celda.Style.SelectionForeColor == seleccion,
                    "Una unidad distinta del catálogo debe aparecer naranja tanto seleccionada como sin seleccionar, en cada tema.");
            }
        }
        finally
        {
            if (MYG2027_TemaComercial.Oscuro != oscuroOriginal) MYG2027_TemaComercial.Alternar(false);
            Directory.Delete(carpeta, true);
        }
    }

    private static ItemPresupuestoDelphin Partida(string descripcion, string unidad, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, Descripcion = descripcion, Unidad = unidad,
            Posicion = posicion, TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = 1, PrecioDirecto = 10 }
        };
    }

    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
    private static void InvocarEn(Type tipo, object objeto, string nombre, params object[] argumentos)
    {
        try { tipo.GetMethod(nombre, Privados).Invoke(objeto, argumentos); }
        catch (TargetInvocationException ex) when (ex.InnerException != null)
        { ExceptionDispatchInfo.Capture(ex.InnerException).Throw(); throw; }
    }
}
