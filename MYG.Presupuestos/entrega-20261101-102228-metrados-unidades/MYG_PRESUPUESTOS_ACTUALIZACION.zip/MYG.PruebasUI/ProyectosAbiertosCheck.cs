using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class ProyectosAbiertosCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-PruebasUI-ProyectosAbiertos-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var rutaIndice = typeof(MYGIndiceLocal).GetProperty("RutaAlternativaPruebas", BindingFlags.Static | BindingFlags.NonPublic);
        string indiceAnterior = (string)rutaIndice.GetValue(null);
        try
        {
            rutaIndice.SetValue(null, Path.Combine(carpeta, "indice_pruebas.json"));
            MYGIndiceLocal.RecordarBiblioteca(Path.Combine(carpeta, "biblioteca_pruebas.json"));
            string ruta = Path.Combine(carpeta, "obras.sqlite");
            string otraRuta = Path.Combine(carpeta, "copia.sqlite");
            var primera = MYGProyectoStorage.Nuevo("OBRA NORTE", "ESTRUCTURAS");
            primera.Presupuestos.Add(new MYGPresupuestoDocumento { Item = "02", Nombre = "ARQUITECTURA", Posicion = 2 });
            const string nombreLargo = "MEJORAMIENTO Y AMPLIACION DE LOS SERVICIOS DE AGUA POTABLE Y DESAGUE EN EL CENTRO POBLADO DE LLACUSBAMBA DEL DISTRITO DE LA PAMPA - PROVINCIA DE CORONGO - DEPARTAMENTO DE ANCASH";
            var segunda = MYGProyectoStorage.Nuevo(nombreLargo, "INSTALACIONES");
            MYGProyectoStorage.Guardar(ruta, primera);
            MYGProyectoStorage.Guardar(ruta, segunda);
            MYGProyectoStorage.Guardar(otraRuta, MYGProyectoStorage.Copia(primera));
            string firmaSegundaGuardada = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id));
            string firmaOtraBase = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(otraRuta, primera.Id));

            // Estos recorridos no inician sesión ni consultan el servicio de licencia.
            // Los documentos se cargan de SQLite para tener un estado inicial limpio.
            using var sesion = new SesionDesktop();
            using var inicio = new InicioForm(sesion);
            inicio.WindowState = FormWindowState.Normal;
            inicio.ClientSize = new Size(1600, 900);
            inicio.Show();
            Application.DoEvents();
            var pestañas = inicio.PestanasProyectos;
            exige(pestañas.TabPages.Count == 1 && pestañas.TabPages[0].Text == "Inicio" &&
                pestañas.Alignment == TabAlignment.Bottom && pestañas.SelectedIndex == 0,
                "La ventana debe comenzar en Inicio y reservar abajo una pestaña permanente para volver a crear y abrir proyectos.");
            exige(((MYGPestanasProyectos)pestañas).AreaCerrar(0).IsEmpty,
                "La pestaña permanente Inicio debe mantenerse sin botón de cierre.");
            int ventanasIniciales = VentanasSuperiores();
            // También comprueba la ruta predeterminada utilizada por los botones de Inicio.
            typeof(InicioForm).GetField("rutaBase", Privados).SetValue(inicio, ruta);
            var editorPrimero = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, primera.Id));
            var editorSegundo = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, segunda.Id), ruta);
            Application.DoEvents();
            var tabPrimera = Pestaña(pestañas, editorPrimero);
            var tabSegunda = Pestaña(pestañas, editorSegundo);
            exige(pestañas.TabPages.Count == 3 && VentanasSuperiores() == ventanasIniciales &&
                !editorPrimero.TopLevel && !editorSegundo.TopLevel &&
                editorPrimero.Parent == tabPrimera && editorSegundo.Parent == tabSegunda &&
                editorPrimero.FormBorderStyle == FormBorderStyle.None && editorPrimero.Dock == DockStyle.Fill,
                "Abrir dos proyectos debe alojarlos en la misma ventana, sin abrir ventanas independientes.");
            exige(tabPrimera.Text.Contains(primera.Nombre, StringComparison.Ordinal) &&
                tabSegunda.Text.Contains(segunda.Nombre, StringComparison.Ordinal) && pestañas.SelectedTab == tabSegunda &&
                editorPrimero.ProyectoId == primera.Id && editorPrimero.RutaProyecto == ruta,
                "Cada pestaña debe identificar su proyecto y la última apertura debe quedar activa.");
            VerificarAnchoPestañas((MYGPestanasProyectos)pestañas, tabPrimera, tabSegunda, nombreLargo, exige);
            int anchoNombreLargo = pestañas.GetTabRect(pestañas.TabPages.IndexOf(tabSegunda)).Width;

            var repetido = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, primera.Id), Path.Combine(carpeta, ".", "obras.sqlite"));
            Application.DoEvents();
            exige(ReferenceEquals(repetido, editorPrimero) && pestañas.TabPages.Count == 3 && pestañas.SelectedTab == tabPrimera,
                "Volver a abrir el mismo proyecto y la misma base, incluso con una ruta equivalente, debe activar su pestaña existente.");
            var editorOtraBase = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(otraRuta, primera.Id), otraRuta);
            Application.DoEvents();
            var tabOtraBase = Pestaña(pestañas, editorOtraBase);
            exige(!ReferenceEquals(editorOtraBase, editorPrimero) && pestañas.TabPages.Count == 4 && pestañas.SelectedTab == tabOtraBase,
                "Un proyecto con el mismo identificador en otra base SQLite debe mantener su propia pestaña y su propio estado.");

            pestañas.SelectedTab = tabPrimera;
            Application.DoEvents();
            var documentoPrimero = Campo<MYGProyectoDocumento>(editorPrimero, "documento");
            var selector = Campo<ComboBox>(editorPrimero, "presupuesto");
            selector.SelectedItem = documentoPrimero.Presupuestos[1];
            Invocar(editorPrimero, "Recordar");
            documentoPrimero.Nombre = "OBRA NORTE REVISADA";
            Invocar(editorPrimero, "Refrescar");
            var buscar = Campo<TextBox>(editorPrimero, "buscarPartida");
            buscar.Text = "búsqueda conservada";
            Application.DoEvents();
            string firmaPrimeraPendiente = MYGProyectoStorage.Firma(documentoPrimero);
            var historialPrimero = Campo<Stack<MYGEntradaHistorialProyecto>>(editorPrimero, "undo");
            var historialSegundo = Campo<Stack<MYGEntradaHistorialProyecto>>(editorSegundo, "undo");
            exige(tabPrimera.Text.Contains(documentoPrimero.Nombre, StringComparison.Ordinal) &&
                editorPrimero.NombreProyecto == documentoPrimero.Nombre,
                "Renombrar un proyecto y refrescarlo debe actualizar el nombre de su pestaña.");
            exige(ReferenceEquals(inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, primera.Id), ruta), editorPrimero) &&
                ReferenceEquals(Campo<MYGProyectoDocumento>(editorPrimero, "documento"), documentoPrimero) &&
                MYGProyectoStorage.Firma(documentoPrimero) == firmaPrimeraPendiente && historialPrimero.Count == 1,
                "Reabrir un proyecto con cambios pendientes debe activar la instancia existente sin reemplazarla con su versión guardada.");

            var botonInicio = Descendientes(editorPrimero).OfType<Button>().Single(b => b.Name == "ir_inicio_button");
            exige(botonInicio.Enabled && !sesion.Autorizado && sesion.Credencial == null,
                "Ir Inicio debe seguir disponible con la sesión vencida y sin solicitar credenciales.");
            botonInicio.PerformClick();
            Application.DoEvents();
            exige(pestañas.SelectedIndex == 0 && !editorPrimero.IsDisposed && pestañas.TabPages.Count == 4 &&
                MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editorPrimero, "documento")) == firmaPrimeraPendiente,
                "Ir Inicio debe mostrar la página inicial y conservar abierto el proyecto con sus cambios pendientes.");
            pestañas.SelectedTab = tabSegunda;
            Application.DoEvents();
            var documentoSegundo = Campo<MYGProyectoDocumento>(editorSegundo, "documento");
            Invocar(editorSegundo, "Recordar");
            documentoSegundo.Nombre = "OBRA SUR PENDIENTE";
            Invocar(editorSegundo, "Refrescar");
            Application.DoEvents();
            exige(pestañas.GetTabRect(pestañas.TabPages.IndexOf(tabSegunda)).Width < anchoNombreLargo &&
                tabSegunda.Text.Contains(documentoSegundo.Nombre, StringComparison.Ordinal),
                "Al acortar el nombre del proyecto, su pestaña debe recuperar el ancho natural sin conservar un tamaño fijo.");
            pestañas.SelectedTab = tabPrimera;
            Application.DoEvents();
            exige(ReferenceEquals(Campo<MYGProyectoDocumento>(editorPrimero, "documento"), documentoPrimero) &&
                documentoPrimero.PresupuestoActivoId == documentoPrimero.Presupuestos[1].Id &&
                buscar.Text == "búsqueda conservada" && historialPrimero.Count == 1 && historialSegundo.Count == 1 &&
                MYGProyectoStorage.Firma(documentoPrimero) == firmaPrimeraPendiente &&
                Campo<MYGProyectoDocumento>(editorOtraBase, "documento").Nombre == primera.Nombre,
                "Volver de Inicio y cambiar pestañas debe conservar el presupuesto, búsqueda, documento e historial propios de cada proyecto.");
            Invocar(editorPrimero, "Historial", false);
            exige(Campo<MYGProyectoDocumento>(editorPrimero, "documento").Nombre == "OBRA NORTE" &&
                Campo<MYGProyectoDocumento>(editorSegundo, "documento").Nombre == "OBRA SUR PENDIENTE",
                "Deshacer después de volver de Inicio debe actuar únicamente en el proyecto activo.");
            Invocar(editorPrimero, "Historial", true);
            exige(MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editorPrimero, "documento")) == firmaPrimeraPendiente,
                "Rehacer debe restaurar los cambios que existían antes de ir a Inicio y cambiar pestañas.");
            typeof(EditorForm).GetField("ocupado", Privados).SetValue(editorPrimero, true);
            try
            {
                bool cambioInicio = inicio.ActivarInicio(editorPrimero);
                pestañas.SelectedTab = tabSegunda;
                Application.DoEvents();
                exige(!cambioInicio && pestañas.SelectedTab == tabPrimera &&
                    MYGProyectoStorage.Firma(Campo<MYGProyectoDocumento>(editorPrimero, "documento")) == firmaPrimeraPendiente,
                    "Una operación en curso debe impedir volver a Inicio o cambiar de proyecto hasta que termine, conservando los cambios.");
            }
            finally { typeof(EditorForm).GetField("ocupado", Privados).SetValue(editorPrimero, false); }

            exige((bool)Invocar(editorPrimero, "Guardar", false), "El primer proyecto debe poder guardar sus cambios desde su pestaña.");
            exige(MYGBaseDatos.LeerProyecto(ruta, primera.Id).Nombre == "OBRA NORTE REVISADA" &&
                MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, segunda.Id)) == firmaSegundaGuardada &&
                MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(otraRuta, primera.Id)) == firmaOtraBase &&
                Campo<MYGProyectoDocumento>(editorSegundo, "documento").Nombre == "OBRA SUR PENDIENTE" && historialSegundo.Count == 1,
                "Guardar una pestaña debe persistir solo ese proyecto, conservando los cambios pendientes de las otras pestañas y de otra base.");
            exige((bool)Invocar(editorSegundo, "Guardar", false), "El segundo proyecto debe poder guardar independientemente.");

            FormClosingEventHandler cancelar = (_, e) => e.Cancel = true;
            editorPrimero.FormClosing += cancelar;
            exige(!inicio.CerrarProyecto(editorPrimero) && !editorPrimero.IsDisposed && pestañas.TabPages.Contains(tabPrimera),
                "Cancelar el cierre de un proyecto debe conservar su pestaña y su editor.");
            pestañas.SelectedTab = tabSegunda;
            Application.DoEvents();
            PulsarCerrar(pestañas, tabPrimera);
            exige(!editorPrimero.IsDisposed && pestañas.TabPages.Contains(tabPrimera) && pestañas.TabPages.Count == 4 &&
                pestañas.SelectedTab == tabSegunda,
                "El botón × de una pestaña inactiva debe respetar la cancelación del cierre y conservar activo el otro proyecto.");
            editorPrimero.FormClosing -= cancelar;

            editorSegundo.FormClosing += cancelar;
            inicio.Close();
            Application.DoEvents();
            exige(!inicio.IsDisposed && !editorPrimero.IsDisposed && !editorSegundo.IsDisposed && !editorOtraBase.IsDisposed &&
                pestañas.TabPages.Count == 4 && pestañas.TabPages.Contains(tabPrimera) && pestañas.TabPages.Contains(tabSegunda),
                "Cancelar el cierre de un proyecto al cerrar la aplicación debe conservar también las pestañas revisadas antes de la cancelación.");
            editorSegundo.FormClosing -= cancelar;
            pestañas.SelectedTab = tabSegunda;
            Application.DoEvents();
            PulsarCerrar(pestañas, tabPrimera);
            exige(editorPrimero.IsDisposed && !pestañas.TabPages.Contains(tabPrimera) &&
                !editorSegundo.IsDisposed && !editorOtraBase.IsDisposed && pestañas.TabPages.Count == 3 &&
                pestañas.SelectedTab == tabSegunda,
                "El botón × debe retirar solo la pestaña inactiva cuyo cierre se confirma y conservar el proyecto seleccionado.");
            exige(inicio.CerrarProyecto(editorSegundo) && inicio.CerrarProyecto(editorOtraBase) && pestañas.TabPages.Count == 1,
                "Cerrar el último proyecto debe conservar la pestaña Inicio.");
            exige(inicio.ActivarInicio() && pestañas.SelectedIndex == 0,
                "Inicio debe seguir accesible después de cerrar todos los proyectos.");
            inicio.Close();
            Application.DoEvents();
            exige(inicio.IsDisposed && !sesion.Autorizado && sesion.Credencial == null,
                "La aplicación debe cerrarse después de confirmar todos los proyectos sin consultar credenciales ni servicios de licencia.");
            VerificarRefrescoInicio(carpeta, exige);
        }
        finally
        {
            rutaIndice.SetValue(null, indiceAnterior);
            Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void VerificarRefrescoInicio(string carpeta, Action<bool, string> exige)
    {
        string ruta = Path.Combine(carpeta, "inicio_cache.sqlite");
        string otraRuta = Path.Combine(carpeta, "inicio_otra.sqlite");
        var documento = MYGProyectoStorage.Nuevo("OBRA EN CACHÉ", "ESTRUCTURAS");
        var secundario = MYGProyectoStorage.Nuevo("OBRA SECUNDARIA", "INSTALACIONES");
        var otro = MYGProyectoStorage.Nuevo("OTRA BASE", "ARQUITECTURA");
        MYGProyectoStorage.Guardar(ruta, documento); MYGProyectoStorage.Guardar(ruta, secundario);
        MYGProyectoStorage.Guardar(otraRuta, otro);
        // Sesión local exclusivamente para estos controles; no se consulta la licencia.
        using var sesion = new SesionDesktop();
        Campo<System.Windows.Forms.Timer>(sesion, "reloj").Stop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion,
            new CredencialMYG { Usuario = "Pruebas de navegación" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
        using var inicio = new InicioForm(sesion);
        inicio.Show(); Application.DoEvents();
        Esperar((Task)Invocar(inicio, "CargarBase", ruta));
        var tabla = Campo<DataGridView>(inicio, "proyectos");
        var buscar = Campo<TextBox>(inicio, "buscar");
        buscar.Text = "CACHÉ";
        var listaInicial = Campo<List<MYGProyectoResumen>>(inicio, "datos");
        var filaInicial = tabla.Rows[0];
        var editor = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, documento.Id));
        var paginaEditor = Pestaña(inicio.PestanasProyectos, editor);
        int sincronizacionesInicio = 0;
        Action alSincronizar = () => sincronizacionesInicio++;
        editor.ProyectoActualizado += alSincronizar;
        editor.IrInicio();
        editor.ProyectoActualizado -= alSincronizar;
        exige(sincronizacionesInicio == 1,
            "El botón Ir Inicio debe sincronizar y calcular la firma del editor una sola vez.");
        Application.DoEvents();
        Invocar(inicio, "EstadoSesion"); Application.DoEvents();
        inicio.PestanasProyectos.SelectedTab = paginaEditor;
        inicio.PestanasProyectos.SelectedIndex = 0; Application.DoEvents();
        exige(ReferenceEquals(listaInicial, Campo<List<MYGProyectoResumen>>(inicio, "datos")) &&
            ReferenceEquals(filaInicial, tabla.Rows[0]) && buscar.Text == "CACHÉ" &&
            Campo<string>(inicio, "refrescoPendiente") == null && !Campo<bool>(inicio, "ocupado"),
            "Volver a Inicio por botón o pestaña y renovar la sesión debe reutilizar la lista sin leer SQLite, reconstruir filas ni perder el filtro.");

        inicio.PestanasProyectos.SelectedTab = paginaEditor;
        var editado = Campo<MYGProyectoDocumento>(editor, "documento");
        editado.Nombre = "OBRA EN CACHÉ GUARDADA";
        editado.Presupuestos.Add(new MYGPresupuestoDocumento { Item = "02", Nombre = "NUEVO", Posicion = 2 });
        Invocar(editor, "Refrescar");
        exige((bool)Invocar(editor, "Guardar", false), "Guardar los cambios de la prueba de Inicio debe terminar sin diálogo.");
        exige(typeof(InicioForm).GetField("revisionProyectosCargados", Privados).GetValue(inicio) == null &&
            ReferenceEquals(listaInicial, Campo<List<MYGProyectoResumen>>(inicio, "datos")),
            "Un guardado propio debe invalidar explícitamente la caché, independientemente de las fechas del archivo, sin recargar antes de volver a Inicio.");
        inicio.ActivarInicio(editor); EsperarRefresco(inicio);
        var guardado = Campo<List<MYGProyectoResumen>>(inicio, "datos").Single(p => p.Id == documento.Id);
        exige(guardado.Nombre == editado.Nombre && guardado.CantidadPresupuestos == 2,
            "Inicio debe actualizar el nombre y la cantidad de presupuestos después de guardar un editor abierto.");
        var listaGuardada = Campo<List<MYGProyectoResumen>>(inicio, "datos");
        inicio.PestanasProyectos.SelectedTab = paginaEditor; inicio.ActivarInicio(editor); Application.DoEvents();
        exige(ReferenceEquals(listaGuardada, Campo<List<MYGProyectoResumen>>(inicio, "datos")) &&
            Campo<string>(inicio, "refrescoPendiente") == null,
            "Una segunda visita después de aplicar el guardado debe conservar la lista actualizada sin otra carga.");
        var editorSecundario = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(ruta, secundario.Id));
        inicio.CerrarProyecto(editorSecundario); Application.DoEvents();
        exige(ReferenceEquals(listaGuardada, Campo<List<MYGProyectoResumen>>(inicio, "datos")) && buscar.Text.Length == 0 &&
            ((MYGProyectoResumen)tabla.CurrentRow.Tag).Id == secundario.Id,
            "Cerrar un editor sin cambios debe seleccionar su proyecto desde la caché y quitar un filtro que lo oculte, sin consultar SQLite.");

        using (var externa = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            externa.Open();
            using (var cmd = externa.CreateCommand()) { cmd.CommandText = "PRAGMA journal_mode=WAL"; cmd.ExecuteScalar(); }
            inicio.PestanasProyectos.SelectedTab = paginaEditor; inicio.ActivarInicio(editor); EsperarRefresco(inicio);
            var listaAntesCambioExterno = Campo<List<MYGProyectoResumen>>(inicio, "datos");
            long fechaBase = File.GetLastWriteTimeUtc(ruta).Ticks, longitudBase = new FileInfo(ruta).Length;
            inicio.PestanasProyectos.SelectedTab = paginaEditor;
            var cambioExterno = MYGBaseDatos.LeerProyecto(ruta, documento.Id);
            cambioExterno.Nombre = "OBRA EN CACHÉ EXTERNA";
            MYGProyectoStorage.Guardar(ruta, cambioExterno);
            exige(File.Exists(ruta + "-wal") && File.GetLastWriteTimeUtc(ruta).Ticks == fechaBase && new FileInfo(ruta).Length == longitudBase,
                "La prueba externa debe guardar en el WAL sin cambiar los metadatos del archivo SQLite principal.");
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, false);
            inicio.ActivarInicio(editor); Application.DoEvents();
            exige(Campo<string>(inicio, "refrescoPendiente") != null &&
                ReferenceEquals(listaAntesCambioExterno, Campo<List<MYGProyectoResumen>>(inicio, "datos")),
                "Una base cambiada sin sesión debe conservar el refresco pendiente sin iniciar lecturas protegidas.");
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
            Invocar(inicio, "EstadoSesion"); EsperarRefresco(inicio);
            exige(Campo<List<MYGProyectoResumen>>(inicio, "datos").Single(p => p.Id == documento.Id).Nombre == cambioExterno.Nombre,
                "Al recuperar la sesión, Inicio debe reflejar también cambios externos presentes únicamente en el WAL.");
        }

        var editorOtraBase = inicio.AbrirEditor(MYGBaseDatos.LeerProyecto(otraRuta, otro.Id), otraRuta);
        inicio.ActivarInicio(editorOtraBase); EsperarRefresco(inicio);
        exige(Campo<List<MYGProyectoResumen>>(inicio, "datos").Single().Id == otro.Id &&
            Campo<Label>(inicio, "baseVisible").Text.Contains(otraRuta, StringComparison.Ordinal) &&
            tabla.Rows.Count == 1 && ((MYGProyectoResumen)tabla.Rows[0].Tag).Id == otro.Id && buscar.Text.Length == 0,
            "Volver desde un editor de otra base debe cargar sus propios proyectos y actualizar la ruta visible.");
        inicio.Close(); Application.DoEvents();
    }

    private static void Esperar(Task tarea)
    {
        var tiempo = Stopwatch.StartNew();
        while (!tarea.IsCompleted && tiempo.Elapsed < TimeSpan.FromSeconds(30))
        { Application.DoEvents(); Thread.Sleep(1); }
        if (!tarea.IsCompleted) throw new TimeoutException("No terminó la carga de proyectos de Inicio.");
        tarea.GetAwaiter().GetResult(); Application.DoEvents();
    }

    private static void EsperarRefresco(InicioForm inicio)
    {
        var tiempo = Stopwatch.StartNew();
        do
        {
            Application.DoEvents();
            if (!Campo<bool>(inicio, "ocupado") && !Campo<bool>(inicio, "refrescoInicioProgramado") &&
                Campo<string>(inicio, "refrescoPendiente") == null) return;
            Thread.Sleep(1);
        } while (tiempo.Elapsed < TimeSpan.FromSeconds(30));
        throw new TimeoutException("No terminó el refresco pendiente de Inicio.");
    }

    private static int VentanasSuperiores() => Application.OpenForms.Cast<Form>().Count(f => f.TopLevel);

    private static void VerificarAnchoPestañas(MYGPestanasProyectos pestañas, TabPage corta, TabPage larga,
        string nombreCompleto, Action<bool, string> exige)
    {
        int indice = pestañas.TabPages.IndexOf(larga);
        Rectangle limites = pestañas.GetTabRect(indice), cierre = pestañas.AreaCerrar(indice);
        exige(limites.Width <= pestañas.AnchoMaximoPestana &&
            pestañas.GetTabRect(pestañas.TabPages.IndexOf(corta)).Width < limites.Width &&
            pestañas.GetTabRect(0).Width < limites.Width,
            "Un nombre largo debe limitarse a 340 píxeles lógicos; los nombres cortos e Inicio deben conservar su ancho natural.");
        exige(larga.Text.Contains(nombreCompleto, StringComparison.Ordinal) &&
            larga.ToolTipText.StartsWith(nombreCompleto + Environment.NewLine, StringComparison.Ordinal) && pestañas.ShowToolTips &&
            limites.Contains(cierre) && cierre.Left > limites.Left + limites.Width / 2,
            "Recortar la etiqueta debe conservar el nombre completo y la ruta en la ayuda, con el botón × dentro de su área independiente.");
        Font fuenteAnterior = pestañas.Font;
        using var fuenteMayor = new Font(fuenteAnterior.FontFamily, fuenteAnterior.SizeInPoints + 2f, fuenteAnterior.Style);
        try
        {
            pestañas.Font = fuenteMayor;
            Application.DoEvents();
            limites = pestañas.GetTabRect(indice);
            exige(limites.Width <= pestañas.AnchoMaximoPestana && limites.Contains(pestañas.AreaCerrar(indice)) &&
                limites.Height >= pestañas.Font.Height && larga.Text.Contains(nombreCompleto, StringComparison.Ordinal),
                "Cambiar el tamaño de texto debe recalcular el límite y la altura sin ocultar el cierre ni alterar el nombre del proyecto.");
        }
        finally { pestañas.Font = fuenteAnterior; }
        // Esta propiedad recrea el HWND; su reconstrucción debe usar también el límite.
        pestañas.ShowToolTips = false;
        pestañas.ShowToolTips = true;
        Application.DoEvents();
        exige(pestañas.GetTabRect(indice).Width <= pestañas.AnchoMaximoPestana &&
            larga.Text.Contains(nombreCompleto, StringComparison.Ordinal) && pestañas.SelectedTab == larga,
            "Recrear el control de pestañas debe conservar el ancho máximo, la selección y el nombre completo.");
    }

    private static TabPage Pestaña(TabControl pestañas, EditorForm editor) =>
        pestañas.TabPages.Cast<TabPage>().Single(p => ReferenceEquals(p.Tag, editor));

    private static void PulsarCerrar(TabControl pestañas, TabPage pagina)
    {
        Rectangle area = ((MYGPestanasProyectos)pestañas).AreaCerrar(pestañas.TabPages.IndexOf(pagina));
        if (area.IsEmpty) throw new InvalidOperationException("La pestaña del proyecto no ofrece el botón × para cerrarlo.");
        int x = area.Left + area.Width / 2, y = area.Top + area.Height / 2;
        var coordenadas = new IntPtr((y << 16) | (x & 0xFFFF));
        SendMessage(pestañas.Handle, 0x0201, new IntPtr(1), coordenadas);
        SendMessage(pestañas.Handle, 0x0202, IntPtr.Zero, coordenadas);
        Application.DoEvents();
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);

    private static object Invocar(object objeto, string nombre, params object[] argumentos) =>
        objeto.GetType().GetMethod(nombre, Privados).Invoke(objeto, argumentos);

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
