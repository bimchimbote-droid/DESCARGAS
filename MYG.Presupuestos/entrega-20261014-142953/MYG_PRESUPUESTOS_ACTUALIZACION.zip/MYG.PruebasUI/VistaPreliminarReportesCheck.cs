using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class VistaPreliminarReportesCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarVistaSinImpresora(exige);
        VerificarBandasAcero(exige);
        VerificarFormulario(exige);
    }

    private static void VerificarVistaSinImpresora(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        var configuracion = new MYGConfiguracionVistaReporte(reportes);
        var vertical = MYGReportesImpresion.PrepararVista(configuracion.Reportes);
        exige(vertical.CantidadPaginas > 3,
            "La vista sin impresora debe paginar un reporte largo y conservar sus filas combinadas y ocultas.");
        SizeF papelVertical = vertical.TamanoPagina(0);
        exige(Cerca(papelVertical.Width, 8.27f) && Cerca(papelVertical.Height, 11.69f),
            "La vista lógica debe usar el tamaño A4 vertical sin consultar una impresora.");
        using var primera = Dibujar(vertical, 0);
        using var ultima = Dibujar(vertical, vertical.CantidadPaginas - 1);
        exige(TieneContenido(primera) && TieneContenido(ultima),
            "La primera y última página deben dibujar contenido real sobre el papel blanco.");
        exige(FirmaContenido(primera) != FirmaContenido(ultima),
            "La paginación debe cambiar el cuerpo dibujado entre la primera y la última página, además del número del pie.");
        for (int indice = 0; indice < vertical.CantidadPaginas; indice++)
        {
            using var imagen = Dibujar(vertical, indice);
            exige(!ContieneFilaOculta(imagen),
                "La vista preliminar debe omitir el relleno magenta de las filas ocultas en todas sus páginas.");
        }

        configuracion.ConfigurarPagina("A4", "Horizontal", .5m, .5m, .5m, .5m);
        var horizontal = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala, null);
        SizeF papelHorizontal = horizontal.TamanoPagina(0);
        exige(Cerca(papelHorizontal.Width, papelVertical.Height) && Cerca(papelHorizontal.Height, papelVertical.Width),
            "Cambiar a horizontal debe intercambiar el ancho y alto del papel de la vista preliminar.");
        exige(horizontal.CantidadPaginas > vertical.CantidadPaginas,
            "Un reporte angosto y largo debe necesitar más páginas cuando la orientación reduce el alto disponible.");

        configuracion.ConfigurarPagina("A3", "Vertical", .5m, .5m, .5m, .5m);
        var a3 = MYGReportesImpresion.PrepararVista(configuracion.Reportes);
        exige(Cerca(a3.TamanoPagina(0).Width, 11.69f) && Cerca(a3.TamanoPagina(0).Height, 16.54f) &&
            a3.CantidadPaginas < vertical.CantidadPaginas,
            "Elegir A3 debe recalcular el tamaño y reducir las páginas del reporte largo.");

        configuracion.ConfigurarPagina("A4", "Vertical", .5m, .5m, .5m, .5m);
        configuracion.Escala = .5f;
        var reducido = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala);
        exige(reducido.CantidadPaginas < vertical.CantidadPaginas,
            "Reducir la escala de impresión debe recalcular los saltos de página sin cambiar el tamaño del papel.");
        using var paginaReducida = Dibujar(reducido, 0);
        exige(TieneContenido(paginaReducida) && FirmaContenido(paginaReducida) != FirmaContenido(primera),
            "La escala elegida debe afectar el contenido dibujado y conservar una página visible.");
        configuracion.Restaurar();
        var restaurada = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala);
        using var paginaRestaurada = Dibujar(restaurada, 0);
        exige(restaurada.CantidadPaginas == vertical.CantidadPaginas && FirmaContenido(paginaRestaurada) == FirmaContenido(primera),
            "Restablecer debe recuperar los saltos y la representación original del reporte.");
        exige(Datos(reportes) == originales,
            "Preparar, dibujar, configurar y restablecer la vista debe conservar los datos, fórmulas y dimensiones de origen.");
    }

    private static void VerificarBandasAcero(Action<bool, string> exige)
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        hoja.AreaImpresion = "A1:AH16";
        hoja.Poner("A3", "Viga principal"); hoja.Poner("B3", "2"); hoja.Poner("C3", "4");
        hoja.Poner("D3", "3/8"); hoja.Poner("E3", "5");
        for (int columna = 31; columna <= 34; columna++)
        {
            string letra = MYGHojaCalculo.Columna(columna);
            hoja.Poner(letra + "2", letra, true);
            hoja.Poner(letra + "3", "Dato " + letra);
            hoja.Celdas[letra + "3"].ColorFondo = "D7EBC4";
        }
        var reportes = new[] { new MYGHojaReporteProyecto("Metrado de fierros y aceros", hoja) };
        string originales = Datos(reportes);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        exige(vista.CantidadPaginas > 1,
            "La vista preliminar de aceros debe generar bandas horizontales legibles para sus 34 columnas.");
        using var primera = Dibujar(vista, 0);
        using var ultima = Dibujar(vista, vista.CantidadPaginas - 1);
        exige(TieneContenido(primera) && TieneContenido(ultima) && FirmaContenido(primera) != FirmaContenido(ultima),
            "La última banda de acero debe dibujar sus propios datos y no repetir únicamente la primera página.");
        exige(ContieneColor(ultima, Color.FromArgb(215, 235, 196)),
            "Las columnas finales AE–AH deben permanecer visibles en la última banda de la hoja de aceros.");
        exige(Datos(reportes) == originales,
            "Segmentar y dibujar la plantilla de aceros debe conservar todas las fórmulas y anchos originales.");
    }

    private static void VerificarFormulario(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        using var formulario = new MYGVistaPreliminarReportesForm("Prueba de vista preliminar", reportes);
        exige(formulario.Name == "vista_preliminar_reportes" && formulario.Text.Contains("Prueba de vista preliminar"),
            "La ventana de vista preliminar debe identificar el documento que se configura.");
        var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        string[] nombres = { "vista_impresora", "vista_orientacion", "vista_papel", "vista_fuente", "vista_escala",
            "vista_margen_izquierdo", "vista_margen_derecho", "vista_margen_superior", "vista_margen_inferior",
            "vista_rango", "vista_desde", "vista_hasta", "vista_copias", "vista_imprimir", "vista_pdf", "vista_zoom" };
        exige(nombres.All(controles.ContainsKey),
            "La vista debe ofrecer impresora, papel, orientación, márgenes, fuente, escala, rango, copias, PDF, impresión y ampliación.");
        var barra = (ToolStrip)controles["vista_barra"];
        string[] acciones = { "vista_volver", "vista_imprimir_barra", "vista_pdf_barra", "vista_primera", "vista_anterior",
            "vista_siguiente", "vista_ultima", "vista_alejar", "vista_acercar", "vista_ajustar", "vista_restaurar" };
        exige(acciones.All(nombre => barra.Items.ContainsKey(nombre)),
            "La barra de vista preliminar debe incluir navegación, ampliación, impresión, PDF y restauración.");
        var impresora = (ComboBox)controles["vista_impresora"];
        exige(impresora.SelectedIndex < 0,
            "Construir la ventana sin mostrarla no debe seleccionar ni consultar una impresora.");
        formulario.ActualizarVista();
        var imagen = Controles(formulario).OfType<PictureBox>().Single();
        exige(formulario.CantidadPaginas > 3 && imagen.Image is Bitmap bitmap && TieneContenido(bitmap),
            "Actualizar la ventana sin impresora debe generar páginas y dibujar la primera vista real.");
        exige(!controles["vista_imprimir"].Enabled && controles["vista_pdf"].Enabled,
            "La vista lógica debe permitir preparar PDF y mantener la impresión desactivada hasta elegir una impresora.");
        exige(!barra.Items["vista_primera"].Enabled && !barra.Items["vista_anterior"].Enabled &&
            barra.Items["vista_siguiente"].Enabled && barra.Items["vista_ultima"].Enabled,
            "La primera página debe ofrecer avance sin permitir navegar antes del comienzo.");
        ulong primera = FirmaContenido((Bitmap)imagen.Image);
        barra.Items["vista_ultima"].PerformClick();
        exige(FirmaContenido((Bitmap)imagen.Image) != primera && barra.Items["vista_anterior"].Enabled &&
            !barra.Items["vista_siguiente"].Enabled,
            "Navegar a la última página debe cambiar el contenido y detener el avance al final.");
        barra.Items["vista_primera"].PerformClick();
        exige(FirmaContenido((Bitmap)imagen.Image) == primera,
            "Volver a la primera página debe recuperar su contenido sin cambiar los datos del reporte.");

        var rango = (CheckBox)controles["vista_rango"];
        var desde = (NumericUpDown)controles["vista_desde"];
        var hasta = (NumericUpDown)controles["vista_hasta"];
        rango.Checked = true; desde.Value = 2; hasta.Value = 3;
        formulario.Configuracion.ConfigurarPagina("A4", "Horizontal", .5m, .5m, .5m, .5m);
        formulario.ActualizarVista();
        exige(desde.Enabled && hasta.Enabled && desde.Value == 2 && hasta.Value == 3,
            "Actualizar la configuración debe conservar el rango de páginas elegido cuando continúa siendo válido.");
        exige(imagen.Image.Width > imagen.Image.Height && TieneContenido((Bitmap)imagen.Image),
            "Aplicar orientación horizontal debe reconstruir una página ancha con contenido visible.");

        formulario.Configuracion.ConfigurarPagina("A3", "Vertical", .5m, .5m, .5m, .5m);
        formulario.Configuracion.Escala = .5f;
        formulario.ActualizarVista();
        exige(formulario.CantidadPaginas > 0 && imagen.Image.Width < imagen.Image.Height &&
            desde.Maximum == formulario.CantidadPaginas && hasta.Maximum == formulario.CantidadPaginas,
            "Cambiar papel y escala debe actualizar la imagen y los límites del rango de impresión.");

        formulario.Configuracion.Reportes[0].Hoja.AreaImpresion = "A1:D999";
        Exception error = null;
        try { formulario.ActualizarVista(); }
        catch (InvalidOperationException ex) { error = ex; }
        exige(error != null && formulario.CantidadPaginas == 0 && imagen.Image == null,
            "Una configuración que no se puede renderizar debe invalidar la vista anterior y liberar su imagen.");
        exige(!controles["vista_imprimir"].Enabled && !controles["vista_pdf"].Enabled &&
            !barra.Items["vista_primera"].Enabled && !barra.Items["vista_ultima"].Enabled,
            "Una vista inválida debe desactivar impresión, PDF y navegación para impedir exportar páginas antiguas.");
        formulario.Configuracion.Restaurar();
        formulario.ActualizarVista();
        exige(formulario.CantidadPaginas > 3 && imagen.Image != null,
            "Restaurar después de un error debe permitir reconstruir la vista preliminar.");
        formulario.Close(); formulario.Dispose();
        exige(formulario.IsDisposed && Datos(reportes) == originales,
            "Configurar, navegar, recuperar un error y cerrar la vista preliminar debe dejar intactas las hojas originales.");
    }

    private static MYGHojaReporteProyecto[] ReporteLargo()
    {
        var hoja = new MYGHojaMetrado
        {
            Nombre = "Metrados", Filas = 182, Columnas = 3, CeldaTotal = "C182", AreaImpresion = "A1:C182",
            RepetirTitulos = true, FilasInmovilizadas = 2, ImprimirLineasDivision = true,
            AnchosColumnas = new() { [1] = 220, [2] = 120, [3] = 120 }
        };
        hoja.RangosCombinados.Add("A1:C1");
        hoja.Poner("A1", "METRADOS DEL PROYECTO", true);
        hoja.Poner("A2", "Descripción", true); hoja.Poner("B2", "Cantidad", true); hoja.Poner("C2", "Parcial", true);
        for (int fila = 3; fila < 182; fila++)
        {
            hoja.AltosFilas[fila] = 24;
            hoja.Poner("A" + fila, "Elemento " + fila);
            hoja.Poner("B" + fila, fila.ToString(System.Globalization.CultureInfo.InvariantCulture));
            hoja.Poner("C" + fila, "=B" + fila + "*2");
            hoja.Celdas["A" + fila].ColorFondo = fila < 80 ? "D8E9F8" : "E4EBD2";
        }
        hoja.Poner("A182", "TOTAL", true); hoja.Poner("C182", "=SUM(C3:C181)", true);
        hoja.FilasOcultas.AddRange(new[] { 10, 95 });
        // Si la fila oculta entra en el plan, su altura excede el área A4 y su
        // relleno permite detectar que fue dibujada en cualquier página.
        hoja.AltosFilas[10] = 1000;
        foreach (string columna in new[] { "A", "B", "C" }) hoja.Celdas[columna + "10"].ColorFondo = "FF00FF";
        foreach (var celda in hoja.Celdas.Values) celda.Fuente = "Arial";
        MYGHojaCalculo.Validar(hoja);
        return new[] { new MYGHojaReporteProyecto("Metrados de prueba", hoja) };
    }

    private static Bitmap Dibujar(MYGReportesImpresion.Vista vista, int indice)
    {
        SizeF medida = vista.TamanoPagina(indice);
        var imagen = new Bitmap((int)Math.Ceiling(medida.Width * 96), (int)Math.Ceiling(medida.Height * 96));
        imagen.SetResolution(96, 96);
        using var graphics = Graphics.FromImage(imagen);
        graphics.Clear(Color.White);
        vista.DibujarPagina(graphics, indice);
        return imagen;
    }

    private static bool TieneContenido(Bitmap imagen)
    {
        int tinta = 0;
        for (int y = 0; y < imagen.Height; y += 4)
            for (int x = 0; x < imagen.Width; x += 4)
                if (imagen.GetPixel(x, y).ToArgb() != Color.White.ToArgb() && ++tinta > 100) return true;
        return false;
    }

    private static ulong FirmaContenido(Bitmap imagen)
    {
        // Excluye el título y el pie: los números de página por sí solos no
        // demuestran que cambió el cuerpo del informe.
        ulong firma = 14695981039346656037;
        for (int y = 96; y < imagen.Height - 96; y += 4)
            for (int x = 48; x < imagen.Width - 48; x += 4)
                firma = unchecked((firma ^ (uint)imagen.GetPixel(x, y).ToArgb()) * 1099511628211);
        return firma;
    }

    private static bool ContieneFilaOculta(Bitmap imagen) => ContieneColor(imagen, Color.Magenta);
    private static bool ContieneColor(Bitmap imagen, Color color)
    {
        for (int y = 0; y < imagen.Height; y += 4)
            for (int x = 0; x < imagen.Width; x += 4)
                if (imagen.GetPixel(x, y).ToArgb() == color.ToArgb()) return true;
        return false;
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Controles(hijo)) yield return descendiente;
        }
    }

    private static bool Cerca(float a, float b) => Math.Abs(a - b) < .01f;
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
}
