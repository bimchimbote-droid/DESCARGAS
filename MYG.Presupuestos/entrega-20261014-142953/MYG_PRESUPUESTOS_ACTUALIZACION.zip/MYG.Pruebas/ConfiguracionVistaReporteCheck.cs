using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ConfiguracionVistaReporteCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (ArgumentException) { return; }
        throw new Exception(mensaje);
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        ConfiguracionAislada(pasa);
        ValidacionAtomica(pasa);
        ReferenciasEnInstantanea(pasa);
        TodosLosReportes(pasa);
    }

    private static void ConfiguracionAislada(Action<string> pasa)
    {
        var a = MYGHojaMetrado.Crear(); var b = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        a.Poner("B3", "2"); a.Poner("C3", "4");
        a.Celdas["B3"].Cursiva = true; a.Celdas["B3"].ColorTexto = "123456";
        a.Celdas["B3"].TamanoFuente = 13m;
        a.Celdas["C3"].TipoValidacion = "Lista"; a.Celdas["C3"].ListaValores.Add("4");
        var reportes = new[] { new MYGHojaReporteProyecto("Metrado estándar", a), new MYGHojaReporteProyecto("Acero", b) };
        string antes = Datos(reportes);
        var vista = new MYGConfiguracionVistaReporte(reportes);
        vista.ConfigurarPagina("A3", "Horizontal", .3m, .4m, .6m, .7m);
        vista.Fuente("  Calibri  "); vista.Escala = 1.5f;
        Exige(vista.Reportes.All(r => r.Hoja.TamanoPapel == "A3" && r.Hoja.OrientacionPagina == "Horizontal" &&
            r.Hoja.MargenIzquierdo == .3m && r.Hoja.MargenDerecho == .4m &&
            r.Hoja.MargenSuperior == .6m && r.Hoja.MargenInferior == .7m &&
            r.Hoja.Celdas.Values.All(c => c.Fuente == "Calibri")), "La configuración debe aplicarse a todas las hojas del reporte.");
        var celda = vista.Reportes[0].Hoja.Celdas["B3"];
        Exige(celda.TamanoFuente == 13m && celda.Cursiva && celda.ColorTexto == "123456" &&
            new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("G3") == 8m &&
            vista.Reportes[0].Hoja.Celdas["G3"].Contenido == a.Celdas["G3"].Contenido,
            "Cambiar fuente y escala debe conservar estilos, tamaños, fórmulas y resultados.");
        vista.Reportes[0].Hoja.Celdas["C3"].ListaValores.Add("8");
        vista.Reportes[0].Hoja.AnchosColumnas[1] = 400;
        vista.Reportes[0].Hoja.RangosCombinados.Clear();
        Exige(Datos(reportes) == antes && vista.Reportes is IList<MYGHojaReporteProyecto> lista && lista.IsReadOnly,
            "Las celdas, listas y dimensiones de la vista previa deben estar separadas del proyecto.");
        var anterior = vista.Reportes;
        a.Poner("B3", "99");
        vista.Restaurar();
        Exige(Datos(vista.Reportes) == antes && vista.Escala == 1f && !ReferenceEquals(anterior, vista.Reportes),
            "Restaurar debe recuperar la instantánea inicial, aun si cambia el documento de origen.");
        vista.Reportes[0].Hoja.Celdas["B3"].Contenido = "123";
        vista.Restaurar();
        Exige(Datos(vista.Reportes) == antes, "Editar tras restaurar debe conservar intacta la instantánea para la siguiente restauración.");
        pasa("Vista previa configura todas las hojas sin cambiar el proyecto y restaura datos, estilos y escala iniciales");
    }

    private static void ValidacionAtomica(Action<string> pasa)
    {
        Rechaza(() => new MYGConfiguracionVistaReporte(null), "Se aceptó un conjunto de reportes nulo.");
        Rechaza(() => new MYGConfiguracionVistaReporte(Array.Empty<MYGHojaReporteProyecto>()), "Se aceptó una vista previa vacía.");
        Rechaza(() => new MYGConfiguracionVistaReporte(new MYGHojaReporteProyecto[] { null }), "Se aceptó una hoja de reporte nula.");
        var vista = new MYGConfiguracionVistaReporte(new[]
        { new MYGHojaReporteProyecto("A", MYGHojaMetrado.Crear()), new MYGHojaReporteProyecto("B", MYGHojaMetrado.Crear()) });
        vista.ConfigurarPagina("Carta", "Horizontal", .4m, .5m, .6m, .7m);
        vista.Fuente("Arial"); vista.Escala = .75f;
        string antes = Datos(vista.Reportes);
        foreach (Action fallo in new Action[]
        {
            () => vista.ConfigurarPagina("A2", "Vertical", 0, 0, 0, 0),
            () => vista.ConfigurarPagina("A4", "Diagonal", 0, 0, 0, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", -.1m, 0, 0, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", 0, 3.01m, 0, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", 0, 0, decimal.MaxValue, 0),
            () => vista.ConfigurarPagina("A4", "Vertical", 0, 0, 0, -1),
            () => vista.Fuente(null), () => vista.Fuente(" "), () => vista.Fuente(new string('a', 101)),
            () => vista.Fuente("Arial\n"),
            () => vista.Escala = float.NaN, () => vista.Escala = float.PositiveInfinity,
            () => vista.Escala = .249f, () => vista.Escala = 2.001f
        })
        {
            Rechaza(fallo, "La vista previa aceptó una configuración inválida.");
            Exige(Datos(vista.Reportes) == antes && vista.Escala == .75f,
                "Una configuración rechazada no debe modificar parcialmente ninguna hoja ni la escala.");
        }
        vista.Escala = .25f; vista.Escala = 2f;
        foreach (string papel in new[] { "A4", "A3", "Carta", "Oficio" })
            foreach (string orientacion in new[] { "Vertical", "Horizontal" })
                vista.ConfigurarPagina(papel, orientacion, 0, 3, 0, 3);
        Exige(vista.Reportes.All(r => r.Hoja.TamanoPapel == "Oficio" && r.Hoja.OrientacionPagina == "Horizontal"),
            "Las opciones válidas de papel y orientación deben conservarse.");
        pasa("Vista previa rechaza configuraciones inválidas sin cambios parciales y admite los límites de escala y márgenes");
    }

    private static ItemPresupuestoDelphin Partida(string descripcion, int posicion)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
            Descripcion = descripcion, Unidad = "m²", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA", Posicion = posicion };
    }

    private static void ReferenciasEnInstantanea(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("OBRA", "ESTRUCTURAS"); var p = doc.Presupuestos[0];
        var a = Partida("Destino", 1); var b = Partida("Origen visible", 2); p.Items.AddRange(new[] { a, b });
        var externo = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 };
        var c = Partida("Dependencia oculta", 1); externo.Items.Add(c); doc.Presupuestos.Add(externo);
        MYGProyectoStorage.Renumerar(p); MYGProyectoStorage.Renumerar(externo);
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        c.Costos.Hoja.Poner("B3", "4");
        b.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(b.Costos.Hoja, externo, c, "B3") + "*3");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3") + "*2+" +
            MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, externo, c, "B3"));
        string antes = Datos(doc);
        var vista = new MYGConfiguracionVistaReporte(new[]
        { new MYGHojaReporteProyecto("Destino", MYGProyectoStorage.Copia(a.Costos.Hoja)),
            new MYGHojaReporteProyecto("Origen", MYGProyectoStorage.Copia(b.Costos.Hoja)) });
        vista.ConfigurarPagina("A4", "Vertical", .3m, .3m, .5m, .5m); vista.Fuente("Arial");
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 28m && Datos(doc) == antes,
            "Configurar la vista previa debe conservar cadenas entre reportes y dependencias de otros presupuestos.");
        c.Costos.Hoja.Poner("B3", "10");
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 28m,
            "La instantánea de la vista previa debe aislar también las dependencias que no se imprimen.");
        vista.Reportes[1].Hoja.Poner("B3", "7");
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 18m &&
            new MYGHojaCalculo(a.Costos.Hoja).Numero("B3") == 70m,
            "Las fórmulas entre reportes deben usar sus propias copias sin escribir en las hojas originales.");
        vista.Restaurar();
        Exige(new MYGHojaCalculo(vista.Reportes[0].Hoja).Numero("B3") == 28m,
            "Restaurar debe recuperar las dependencias iniciales y no las del documento modificado.");
        pasa("Vista previa mantiene fórmulas entre hojas y congela dependencias ocultas sin alterar el documento");
    }

    private static void TodosLosReportes(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("PROYECTO", "PRESUPUESTO"); var p = doc.Presupuestos[0];
        var a = Partida("Metrado estándar", 1); var b = Partida("Metrado de acero", 2);
        a.Costos.FuenteMetrado = b.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        a.Costos.PrecioDirecto = b.Costos.PrecioDirecto = 2m;
        b.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        p.Items.AddRange(new[] { a, b }); MYGProyectoStorage.Renumerar(p); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = Datos(doc);
        foreach (var tipo in Enum.GetValues<MYGTipoReporteProyecto>())
        {
            var reportes = MYGReportesProyecto.Crear(doc, p.Id, tipo);
            string originales = Datos(reportes);
            var vista = new MYGConfiguracionVistaReporte(reportes);
            vista.ConfigurarPagina("A3", "Horizontal", .25m, .25m, .5m, .5m); vista.Fuente("Arial Narrow"); vista.Escala = .5f;
            Exige(vista.Reportes.Count == reportes.Count && Datos(reportes) == originales && Datos(doc) == antes,
                "Configurar el reporte " + tipo + " debe conservar todas sus hojas y el documento original.");
            vista.Restaurar();
            Exige(Datos(vista.Reportes) == originales, "El reporte " + tipo + " no recuperó su formato inicial.");
        }
        pasa("Los siete destinos de impresión admiten configuración y restauración sin modificar datos ni reportes originales");
    }
}
