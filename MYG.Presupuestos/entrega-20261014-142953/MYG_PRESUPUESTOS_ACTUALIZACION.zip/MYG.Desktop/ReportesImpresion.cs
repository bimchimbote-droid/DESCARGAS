using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Impresión de reportes sin Office. Las hojas se leen sin modificar sus datos ni fórmulas.</summary>
internal static class MYGReportesImpresion
{
    // Las hojas anchas se dividen en bandas con su primera columna repetida:
    // un metrado de acero no se comprime hasta volver ilegibles sus 34 columnas.
    private const float EscalaMinima = .85f;
    private const float Separacion = .025f;

    internal static void Imprimir(IWin32Window owner, string nombreDocumento, IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        using var vista = new MYGVistaPreliminarReportesForm(nombreDocumento, reportes);
        vista.ShowDialog(owner);
    }

    // El mismo plan sirve para la vista, la impresora y Microsoft Print to PDF.
    // La vista usa el papel lógico y puede abrirse sin impresoras instaladas.
    internal sealed class Vista
    {
        private readonly List<PlanHoja> planes;
        private readonly List<(PlanHoja Plan, Pagina Pagina)> paginas;
        private Vista(List<PlanHoja> planes)
        {
            this.planes = planes;
            paginas = planes.SelectMany(p => p.Paginas.Select(x => (p, x))).ToList();
        }
        internal int CantidadPaginas => paginas.Count;
        internal SizeF TamanoPagina(int indice) => paginas[indice].Plan.TamanoPapel;
        internal void DibujarPagina(Graphics graphics, int indice)
        {
            var estado = graphics.Save();
            try
            {
                graphics.PageUnit = GraphicsUnit.Inch;
                var pagina = paginas[indice];
                Dibujar(graphics, pagina.Plan, pagina.Pagina, indice + 1);
            }
            finally { graphics.Restore(estado); }
        }
        internal PrintDocument Documento(string nombre, PrinterSettings impresora)
        {
            if (planes.Any(p => p.Configuracion == null)) throw new InvalidOperationException("Prepare el reporte para la impresora seleccionada.");
            var documento = new PrintDocument { DocumentName = nombre ?? "Reportes del proyecto", PrinterSettings = impresora };
            int primera = impresora.PrintRange == PrintRange.SomePages ? impresora.FromPage - 1 : 0;
            int ultima = impresora.PrintRange == PrintRange.SomePages ? impresora.ToPage - 1 : paginas.Count - 1;
            if (primera < 0 || ultima < primera || ultima >= paginas.Count)
            { documento.Dispose(); throw new InvalidOperationException("El rango de páginas no corresponde al reporte configurado."); }
            int indice = primera;
            documento.BeginPrint += (_, _) => indice = primera;
            documento.QueryPageSettings += (_, e) => e.PageSettings = (PageSettings)paginas[indice].Plan.Configuracion.Clone();
            documento.PrintPage += (_, e) =>
            {
                if (e.Graphics == null) throw new InvalidOperationException("La impresora no proporciona un contexto de dibujo.");
                var estado = e.Graphics.Save();
                try
                {
                    e.Graphics.PageUnit = GraphicsUnit.Inch;
                    e.Graphics.TranslateTransform(-e.PageSettings.HardMarginX / 100f, -e.PageSettings.HardMarginY / 100f);
                    DibujarPagina(e.Graphics, indice);
                }
                finally { e.Graphics.Restore(estado); }
                e.HasMorePages = ++indice <= ultima;
            };
            return documento;
        }
        internal static Vista Crear(IReadOnlyList<MYGHojaReporteProyecto> reportes, float escala, PrinterSettings impresora)
        {
            if (reportes == null || reportes.Count == 0 || reportes.Any(r => r?.Hoja == null))
                throw new InvalidOperationException("No hay reportes válidos para mostrar.");
            if (!float.IsFinite(escala) || escala < .25f || escala > 2f) throw new ArgumentOutOfRangeException(nameof(escala));
            var planes = new List<PlanHoja>();
            using var bitmap = new Bitmap(1, 1);
            bitmap.SetResolution(96, 96);
            using var graphics = Graphics.FromImage(bitmap);
            graphics.PageUnit = GraphicsUnit.Inch;
            foreach (var reporte in reportes)
            {
                try
                {
                    var h = reporte.Hoja;
                    var tamano = MedidaPapel(h);
                    var limites = new RectangleF((float)h.MargenIzquierdo, (float)h.MargenSuperior,
                        tamano.Width - (float)(h.MargenIzquierdo + h.MargenDerecho),
                        tamano.Height - (float)(h.MargenSuperior + h.MargenInferior));
                    PageSettings pagina = null;
                    if (impresora != null)
                    {
                        if (!impresora.IsValid) throw new InvalidOperationException("Seleccione una impresora disponible.");
                        pagina = new PageSettings(impresora);
                        ConfigurarPagina(pagina, h);
                        limites = RectangleF.Intersect(limites, EnPulgadas(pagina.PrintableArea));
                    }
                    var plan = Preparar(reporte, pagina, graphics, limites, escala);
                    plan.TamanoPapel = tamano;
                    planes.Add(plan);
                }
                catch (InvalidOperationException ex)
                { throw new InvalidOperationException("No se puede preparar «" + reporte.Titulo + "»: " + ex.Message, ex); }
            }
            return new Vista(planes);
        }
    }

    internal static Vista PrepararVista(IReadOnlyList<MYGHojaReporteProyecto> reportes, float escala = 1,
        PrinterSettings impresora = null) => Vista.Crear(reportes, escala, impresora);

    private static SizeF MedidaPapel(MYGHojaMetrado h)
    {
        var tamano = h.TamanoPapel switch
        { "A3" => new SizeF(11.69f, 16.54f), "Carta" => new SizeF(8.5f, 11), "Oficio" => new SizeF(8.5f, 14), _ => new SizeF(8.27f, 11.69f) };
        return h.OrientacionPagina == "Horizontal" ? new SizeF(tamano.Height, tamano.Width) : tamano;
    }

    /// <summary>Índices de columnas desde cero; cada banda conserva la columna identificadora inicial.</summary>
    internal static IReadOnlyList<int[]> SegmentarColumnas(IReadOnlyList<float> anchos, float anchoDisponible)
    {
        if (anchos == null || anchos.Count == 0 || !Positivo(anchoDisponible) || anchos.Any(a => !Positivo(a)))
            throw new ArgumentException("Los anchos y el espacio disponible deben ser números positivos y finitos.");
        double capacidad = (double)anchoDisponible / EscalaMinima;
        capacidad += Math.Max(1d, capacidad) * .000001d;
        if (anchos.Sum(a => (double)a) <= capacidad) return new[] { Enumerable.Range(0, anchos.Count).ToArray() };
        if (anchos.Count == 1) throw new InvalidOperationException("La columna identificadora no cabe con texto legible. Reduzca su ancho o utilice papel más grande.");
        var resultado = new List<int[]>();
        int siguiente = 1;
        while (siguiente < anchos.Count)
        {
            var banda = new List<int> { 0 };
            double ancho = anchos[0];
            while (siguiente < anchos.Count && ancho + anchos[siguiente] <= capacidad)
            { ancho += anchos[siguiente]; banda.Add(siguiente++); }
            if (banda.Count == 1)
                throw new InvalidOperationException("La columna identificadora y la columna " + MYGHojaCalculo.Columna(siguiente + 1) +
                    " no caben con texto legible. Reduzca sus anchos o utilice papel más grande.");
            resultado.Add(banda.ToArray());
        }
        return resultado;
    }

    /// <summary>Filas originales de cada página. Altos se indexa por posición en filas, omitiendo las ocultas.</summary>
    internal static IReadOnlyList<int[]> PaginarFilas(IReadOnlyList<int> filas, IReadOnlyList<float> altos,
        IReadOnlyList<(int Primera, int Ultima)> combinaciones, float altoDisponible, int filasTitulo)
    {
        if (filas == null || altos == null || combinaciones == null || filas.Count != altos.Count || !Positivo(altoDisponible) ||
            altos.Any(a => !Positivo(a)) || filasTitulo < 0 || filasTitulo > filas.Count ||
            filas.Where((f, i) => f < 1 || (i > 0 && f <= filas[i - 1])).Any() ||
            combinaciones.Any(c => c.Primera < 1 || c.Ultima < c.Primera))
            throw new ArgumentException("Las filas, alturas y combinaciones de impresión no son válidas.");
        if (filas.Count == 0) return Array.Empty<int[]>();
        if (altos.Sum() <= altoDisponible) return new[] { filas.ToArray() };

        int ultimaCabecera = filasTitulo == 0 ? 0 : filas[filasTitulo - 1];
        if (combinaciones.Any(c => c.Primera <= ultimaCabecera && c.Ultima > ultimaCabecera))
            throw new InvalidOperationException("Una combinación vertical atraviesa las cabeceras repetidas. Separe esa combinación para imprimir varias páginas.");
        float altoTitulos = altos.Take(filasTitulo).Sum();
        if (altoTitulos >= altoDisponible)
            throw new InvalidOperationException("Las cabeceras repetidas ocupan toda el área de impresión.");

        // Unir intervalos superpuestos evita separar combinaciones encadenadas.
        var intervalos = new List<(int Primera, int Ultima)>();
        foreach (var intervalo in combinaciones.Where(c => c.Ultima > c.Primera).OrderBy(c => c.Primera))
        {
            if (intervalos.Count > 0 && intervalo.Primera <= intervalos[^1].Ultima)
                intervalos[^1] = (intervalos[^1].Primera, Math.Max(intervalos[^1].Ultima, intervalo.Ultima));
            else intervalos.Add(intervalo);
        }
        var resultado = new List<int[]>();
        var pagina = new List<int>();
        float usado = 0;
        int posicion = 0, intervaloActual = 0;
        while (posicion < filas.Count)
        {
            int fin = posicion;
            while (intervaloActual < intervalos.Count && intervalos[intervaloActual].Ultima < filas[posicion]) intervaloActual++;
            if (intervaloActual < intervalos.Count && intervalos[intervaloActual].Primera <= filas[posicion])
                while (fin + 1 < filas.Count && filas[fin + 1] <= intervalos[intervaloActual].Ultima) fin++;
            float alto = 0;
            for (int i = posicion; i <= fin; i++) alto += altos[i];
            if (posicion >= filasTitulo && alto > altoDisponible - altoTitulos)
                throw new InvalidOperationException("La fila " + filas[posicion] + (fin == posicion ? "" : " y su bloque combinado") +
                    " no cabe en una página con las cabeceras. Reduzca su altura o utilice papel más grande.");
            if (alto > altoDisponible)
                throw new InvalidOperationException("La fila " + filas[posicion] + " y su bloque combinado exceden el alto imprimible.");
            if (usado + alto > altoDisponible)
            {
                if (pagina.Count == 0) throw new InvalidOperationException("No cabe una fila en el área de impresión.");
                resultado.Add(pagina.ToArray());
                pagina = filas.Take(filasTitulo).ToList();
                usado = altoTitulos;
            }
            for (int i = posicion; i <= fin; i++) pagina.Add(filas[i]);
            usado += alto;
            posicion = fin + 1;
        }
        if (pagina.Count > 0) resultado.Add(pagina.ToArray());
        return resultado;
    }

    private static bool Positivo(float valor) => float.IsFinite(valor) && valor > 0;
    private static string FuenteReporte(MYGHojaMetrado h) => h.Celdas.Values.FirstOrDefault()?.Fuente ?? MYGCeldaHoja.FuentePredeterminada;
    private static string Direccion(int fila, int columna) => MYGHojaCalculo.Columna(columna) + fila.ToString(CultureInfo.InvariantCulture);
    private static RectangleF EnPulgadas(RectangleF rectangulo) => new(rectangulo.X / 100f, rectangulo.Y / 100f, rectangulo.Width / 100f, rectangulo.Height / 100f);

    private static void ConfigurarPagina(PageSettings pagina, MYGHojaMetrado h)
    {
        pagina.Landscape = h.OrientacionPagina == "Horizontal";
        PaperKind clase = h.TamanoPapel switch { "A3" => PaperKind.A3, "Carta" => PaperKind.Letter, "Oficio" => PaperKind.Legal, _ => PaperKind.A4 };
        var medida = h.TamanoPapel switch { "A3" => (Ancho: 1169, Alto: 1654), "Carta" => (Ancho: 850, Alto: 1100), "Oficio" => (Ancho: 850, Alto: 1400), _ => (Ancho: 827, Alto: 1169) };
        var disponibles = pagina.PrinterSettings.PaperSizes.Cast<PaperSize>().ToArray();
        var papel = disponibles.FirstOrDefault(p => p.Kind == clase) ?? disponibles.FirstOrDefault(p =>
            Math.Abs(p.Width - medida.Ancho) <= 2 && Math.Abs(p.Height - medida.Alto) <= 2);
        if (papel == null) throw new InvalidOperationException("La impresora seleccionada no admite papel " + h.TamanoPapel + ". Seleccione otra impresora o cambie el papel de la hoja.");
        pagina.PaperSize = papel;
        pagina.Margins = new Margins((int)Math.Round(h.MargenIzquierdo * 100), (int)Math.Round(h.MargenDerecho * 100),
            (int)Math.Round(h.MargenSuperior * 100), (int)Math.Round(h.MargenInferior * 100));
    }

    private sealed class Region
    {
        internal int F1, C1, F2, C2;
        internal string Direccion => MYGReportesImpresion.Direccion(F1, C1);
    }
    private sealed class Celda
    {
        internal string Direccion, Texto;
        internal MYGCeldaHoja Estilo;
        internal int PrimeraColumna, UltimaColumna;
        internal int[] Filas;
    }
    private sealed class Banda
    {
        internal int[] Columnas;
        internal float[] Anchos;
        internal float Escala;
        internal List<Celda> Celdas = new();
    }
    private sealed class Pagina
    {
        internal int[] Filas;
        internal int Banda;
    }
    private sealed class PlanHoja
    {
        internal MYGHojaReporteProyecto Reporte;
        internal PageSettings Configuracion;
        internal RectangleF Limites;
        internal SizeF TamanoPapel;
        internal float AltoTitulo, AltoEncabezados;
        internal List<Banda> Bandas = new();
        internal Dictionary<int, float> Altos;
        internal List<Pagina> Paginas = new();
    }

    private static Region LeerRango(string rango)
    {
        var partes = MYGEdicionHoja.NormalizarRango(rango).Split(':');
        var a = MYGHojaCalculo.Coordenadas(partes[0]);
        var b = MYGHojaCalculo.Coordenadas(partes[^1]);
        return new Region { F1 = a.Fila, C1 = a.Columna, F2 = b.Fila, C2 = b.Columna };
    }

    private static PlanHoja Preparar(MYGHojaReporteProyecto reporte, PageSettings pagina, Graphics g, RectangleF limites, float escalaUsuario)
    {
        var h = reporte.Hoja;
        var todasCombinaciones = h.RangosCombinados.Select(LeerRango).ToArray();
        var coordenadas = h.Celdas.Keys.Select(MYGHojaCalculo.Coordenadas).ToArray();
        var area = string.IsNullOrWhiteSpace(h.AreaImpresion)
            ? new Region { F1 = 1, C1 = 1,
                F2 = Math.Max(coordenadas.Select(c => c.Fila).DefaultIfEmpty(1).Max(), todasCombinaciones.Select(c => c.F2).DefaultIfEmpty(1).Max()),
                C2 = Math.Max(coordenadas.Select(c => c.Columna).DefaultIfEmpty(1).Max(), todasCombinaciones.Select(c => c.C2).DefaultIfEmpty(1).Max()) }
            : LeerRango(h.AreaImpresion);
        if (area.F1 < 1 || area.C1 < 1 || area.F2 > h.Filas || area.C2 > h.Columnas)
            throw new InvalidOperationException("El área de impresión de " + reporte.Titulo + " está fuera de la hoja.");
        var combinaciones = todasCombinaciones.Where(c => c.F1 <= area.F2 && c.F2 >= area.F1 && c.C1 <= area.C2 && c.C2 >= area.C1).ToArray();
        var ocultas = h.FilasOcultas.ToHashSet();
        var filas = Enumerable.Range(area.F1, area.F2 - area.F1 + 1).Where(f => !ocultas.Contains(f)).ToArray();
        if (filas.Length == 0) throw new InvalidOperationException("El reporte " + reporte.Titulo + " no contiene filas visibles para imprimir.");
        if (limites.Width <= .4f || limites.Height <= .5f)
            throw new InvalidOperationException("Los márgenes de " + reporte.Titulo + " dejan un área de impresión demasiado pequeña.");
        using var titulo = new Font(FuenteReporte(h), 11, FontStyle.Bold);
        using var formatoTitulo = new StringFormat { Trimming = StringTrimming.None, Alignment = StringAlignment.Center };
        float altoTitulo = Math.Max(.22f, g.MeasureString(reporte.Titulo ?? h.Nombre, titulo, new SizeF(limites.Width, 10000), formatoTitulo).Height) + .12f;
        var plan = new PlanHoja { Reporte = reporte, Configuracion = pagina, Limites = limites, AltoTitulo = altoTitulo,
            AltoEncabezados = h.ImprimirEncabezados ? .24f : 0 };
        float anchoFilas = h.ImprimirEncabezados ? .3f : 0;
        float anchoDisponible = limites.Width - anchoFilas;
        var columnas = Enumerable.Range(area.C1, area.C2 - area.C1 + 1).ToArray();
        var anchos = columnas.Select(c => h.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : 68) / 96f * escalaUsuario).ToArray();
        var segmentos = SegmentarColumnas(anchos, anchoDisponible);
        var motor = new MYGHojaCalculo(h);
        var textos = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var mapa = new Dictionary<(int Fila, int Columna), Region>();
        foreach (var region in combinaciones)
            for (int f = Math.Max(area.F1, region.F1); f <= Math.Min(area.F2, region.F2); f++)
                for (int c = Math.Max(area.C1, region.C1); c <= Math.Min(area.C2, region.C2); c++) mapa.Add((f, c), region);
        foreach (var segmento in segmentos)
        {
            var banda = new Banda { Columnas = segmento.Select(c => columnas[c]).ToArray(),
                Escala = Math.Min(1f, anchoDisponible / segmento.Sum(c => anchos[c])) };
            banda.Anchos = segmento.Select(c => anchos[c] * banda.Escala).ToArray();
            var visitadas = new HashSet<Region>();
            foreach (int f in filas)
                for (int indice = 0; indice < banda.Columnas.Length; indice++)
                {
                    int c = banda.Columnas[indice];
                    mapa.TryGetValue((f, c), out var region);
                    if (region != null && !visitadas.Add(region)) continue;
                    string direccion = region?.Direccion ?? Direccion(f, c);
                    if (!textos.TryGetValue(direccion, out string texto)) textos[direccion] = texto = motor.Mostrar(direccion);
                    var estilo = h.Celdas.GetValueOrDefault(direccion) ?? new MYGCeldaHoja();
                    var celda = new Celda { Direccion = direccion, Texto = texto, Estilo = estilo,
                        PrimeraColumna = region == null ? indice : Array.FindIndex(banda.Columnas, col => col >= region.C1 && col <= region.C2),
                        UltimaColumna = region == null ? indice : Array.FindLastIndex(banda.Columnas, col => col >= region.C1 && col <= region.C2),
                        Filas = region == null ? new[] { f } : filas.Where(fila => fila >= region.F1 && fila <= region.F2).ToArray() };
                    banda.Celdas.Add(celda);
                }
            banda.Escala *= escalaUsuario;
            plan.Bandas.Add(banda);
        }
        // Mismas alturas y cortes verticales para todas las bandas, de modo
        // que una fila se puede seguir entre páginas de una hoja de acero.
        float escalaAlta = plan.Bandas.Max(b => b.Escala);
        plan.Altos = filas.ToDictionary(f => f, f => Math.Max(.12f, h.AltosFilas.GetValueOrDefault(f, f == 2 ? 28 : 20) / 96f * escalaAlta));
        foreach (var banda in plan.Bandas)
        {
            using var fuentes = new Fuentes();
            foreach (var celda in banda.Celdas)
            {
                if (string.IsNullOrEmpty(celda.Texto)) continue;
                float ancho = 0;
                for (int c = celda.PrimeraColumna; c <= celda.UltimaColumna; c++) ancho += banda.Anchos[c];
                if (ancho <= Separacion * 2) throw new InvalidOperationException("La celda " + celda.Direccion + " no tiene ancho suficiente para imprimir su texto.");
                using var formato = Formato(celda);
                float necesario = g.MeasureString(celda.Texto, fuentes.Obtener(celda.Estilo, banda.Escala),
                    new SizeF(ancho - Separacion * 2, 10000), formato).Height + Separacion * 2 + .01f;
                float existente = celda.Filas.Sum(f => plan.Altos[f]);
                if (necesario > existente) plan.Altos[celda.Filas[^1]] += necesario - existente;
            }
        }
        float altoDisponible = limites.Height - altoTitulo - plan.AltoEncabezados - .26f;
        if (!Positivo(altoDisponible)) throw new InvalidOperationException("El título y los márgenes de " + reporte.Titulo + " ocupan toda la página.");
        int titulos = h.RepetirTitulos && area.F1 == 1 ? Math.Max(1, Math.Min(2, h.FilasInmovilizadas)) : 0;
        int filasTitulo = filas.Count(f => f <= titulos);
        var paginasFilas = PaginarFilas(filas, filas.Select(f => plan.Altos[f]).ToArray(),
            combinaciones.Select(c => (c.F1, c.F2)).ToArray(), altoDisponible, filasTitulo);
        for (int banda = 0; banda < plan.Bandas.Count; banda++)
            foreach (var paginaFilas in paginasFilas) plan.Paginas.Add(new Pagina { Banda = banda, Filas = paginaFilas });
        return plan;
    }

    private static StringFormat Formato(Celda celda) => new()
    {
        Alignment = MYGEdicionHoja.AlineacionCelda(celda.Estilo, celda.Direccion) switch
        { "Centro" => StringAlignment.Center, "Derecha" => StringAlignment.Far, _ => StringAlignment.Near },
        LineAlignment = celda.Estilo.AlineacionVertical switch
        { "Arriba" => StringAlignment.Near, "Abajo" => StringAlignment.Far, _ => StringAlignment.Center },
        Trimming = StringTrimming.None
    };

    private static Color ColorCelda(string valor, Color predeterminado) => string.IsNullOrEmpty(valor)
        ? predeterminado : ColorTranslator.FromHtml("#" + valor.TrimStart('#'));

    private sealed class Fuentes : IDisposable
    {
        private readonly Dictionary<(string Nombre, float Tamano, FontStyle Estilo), Font> fuentes = new();
        internal Font Obtener(MYGCeldaHoja celda, float escala)
        {
            var estilo = (celda.Negrita ? FontStyle.Bold : 0) | (celda.Cursiva ? FontStyle.Italic : 0) |
                (celda.Subrayado ? FontStyle.Underline : 0) | (celda.Tachado ? FontStyle.Strikeout : 0);
            var clave = (Nombre: celda.Fuente, Tamano: (float)celda.TamanoFuente * escala, Estilo: estilo);
            if (!fuentes.TryGetValue(clave, out var fuente)) fuentes[clave] = fuente = new Font(clave.Nombre, clave.Tamano, clave.Estilo);
            return fuente;
        }
        public void Dispose() { foreach (var fuente in fuentes.Values) fuente.Dispose(); }
    }

    private static void Dibujar(Graphics g, PlanHoja plan, Pagina pagina, int numeroPagina)
    {
        var h = plan.Reporte.Hoja;
        var banda = plan.Bandas[pagina.Banda];
        using var titulo = new Font(FuenteReporte(h), 11, FontStyle.Bold);
        using var datos = new Font(FuenteReporte(h), 8);
        using var formatoTitulo = new StringFormat { Trimming = StringTrimming.None, Alignment = StringAlignment.Center };
        g.DrawString(plan.Reporte.Titulo ?? h.Nombre, titulo, Brushes.Black,
            new RectangleF(plan.Limites.Left, plan.Limites.Top, plan.Limites.Width, plan.AltoTitulo - .1f), formatoTitulo);
        float y = plan.Limites.Top + plan.AltoTitulo;
        float xInicial = plan.Limites.Left + (h.ImprimirEncabezados ? .3f : 0);
        var xs = new float[banda.Columnas.Length + 1];
        xs[0] = xInicial;
        for (int i = 0; i < banda.Columnas.Length; i++) xs[i + 1] = xs[i] + banda.Anchos[i];
        if (h.ImprimirEncabezados)
        {
            for (int c = 0; c < banda.Columnas.Length; c++)
                g.DrawString(MYGHojaCalculo.Columna(banda.Columnas[c]), datos, Brushes.DimGray,
                    new RectangleF(xs[c] + Separacion, y, banda.Anchos[c] - Separacion, plan.AltoEncabezados));
            y += plan.AltoEncabezados;
        }
        var posiciones = new Dictionary<int, float>();
        foreach (int f in pagina.Filas)
        {
            posiciones.Add(f, y);
            if (h.ImprimirEncabezados) g.DrawString(f.ToString(CultureInfo.InvariantCulture), datos, Brushes.DimGray, plan.Limites.Left, y);
            y += plan.Altos[f];
        }
        using var fuentes = new Fuentes();
        using var borde = new Pen(Color.Gray, .005f);
        using var division = new Pen(Color.LightGray, .003f);
        foreach (var celda in banda.Celdas)
        {
            var visibles = celda.Filas.Where(posiciones.ContainsKey).ToArray();
            if (visibles.Length == 0) continue;
            var rectangulo = new RectangleF(xs[celda.PrimeraColumna], posiciones[visibles[0]],
                xs[celda.UltimaColumna + 1] - xs[celda.PrimeraColumna], visibles.Sum(f => plan.Altos[f]));
            if (!string.IsNullOrEmpty(celda.Estilo.ColorFondo))
            { using var fondo = new SolidBrush(ColorCelda(celda.Estilo.ColorFondo, Color.White)); g.FillRectangle(fondo, rectangulo); }
            if (celda.Estilo.Bordes || h.ImprimirLineasDivision)
                g.DrawRectangle(celda.Estilo.Bordes ? borde : division, rectangulo.X, rectangulo.Y, rectangulo.Width, rectangulo.Height);
            using var tinta = new SolidBrush(ColorCelda(celda.Estilo.ColorTexto, Color.Black));
            using var formato = Formato(celda);
            rectangulo.Inflate(-Separacion, -Separacion);
            g.DrawString(celda.Texto, fuentes.Obtener(celda.Estilo, banda.Escala), tinta, rectangulo, formato);
        }
        string columnas = banda.Columnas.Length == 1 ? MYGHojaCalculo.Columna(banda.Columnas[0]) :
            MYGHojaCalculo.Columna(banda.Columnas[0]) + (banda.Columnas[1] != banda.Columnas[0] + 1 ? ", " + MYGHojaCalculo.Columna(banda.Columnas[1]) : "") +
            "–" + MYGHojaCalculo.Columna(banda.Columnas[^1]);
        string pie = "Página " + numeroPagina + (plan.Bandas.Count > 1 ? " · Segmento " + (pagina.Banda + 1) + "/" + plan.Bandas.Count + " · Columnas " + columnas : "");
        g.DrawString(pie, datos, Brushes.DimGray, plan.Limites.Left, plan.Limites.Bottom - .2f);
    }
}
