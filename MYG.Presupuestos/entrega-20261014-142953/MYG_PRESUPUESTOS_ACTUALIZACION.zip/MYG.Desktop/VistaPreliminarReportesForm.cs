using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Configura una copia del informe; el proyecto y su historial quedan intactos.</summary>
internal sealed class MYGVistaPreliminarReportesForm : Form
{
    private readonly MYGConfiguracionVistaReporte configuracion;
    private readonly string nombreDocumento;
    private readonly Panel superficie = new() { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.FromArgb(159, 183, 205) };
    private readonly PictureBox papel = new() { BackColor = Color.White, SizeMode = PictureBoxSizeMode.StretchImage, Location = new Point(24, 24) };
    private readonly Label estado = new() { Dock = DockStyle.Bottom, Height = 28, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0) };
    private readonly ComboBox impresoras = Lista("vista_impresora");
    private readonly ComboBox orientacion = Lista("vista_orientacion");
    private readonly ComboBox tamano = Lista("vista_papel");
    private readonly ComboBox fuentes = Lista("vista_fuente");
    private readonly ComboBox zoom = Lista("vista_zoom");
    private readonly NumericUpDown escala = Numero("vista_escala", 25, 200, 100);
    private readonly NumericUpDown izquierda = Margen("vista_margen_izquierdo"), derecha = Margen("vista_margen_derecho");
    private readonly NumericUpDown superior = Margen("vista_margen_superior"), inferior = Margen("vista_margen_inferior");
    private readonly NumericUpDown desde = Numero("vista_desde", 1, 100000, 1), hasta = Numero("vista_hasta", 1, 100000, 1);
    private readonly NumericUpDown copias = Numero("vista_copias", 1, 999, 1);
    private readonly CheckBox rango = new() { Text = "Solo páginas indicadas", AutoSize = true, Name = "vista_rango" };
    private readonly CheckBox lineas = new() { Text = "Líneas de división", AutoSize = true, Name = "vista_lineas" };
    private readonly CheckBox encabezados = new() { Text = "Letras y números de celdas", AutoSize = true, Name = "vista_encabezados" };
    private readonly CheckBox titulos = new() { Text = "Repetir filas de título", AutoSize = true, Name = "vista_titulos" };
    private readonly Button imprimir, pdf;
    private readonly ToolStripButton primera, anterior, siguiente, ultima;
    private MYGReportesImpresion.Vista vista;
    private int pagina;
    private bool cargando;
    private bool paginaInvalida;
    private float ampliacion = 1;

    internal MYGConfiguracionVistaReporte Configuracion => configuracion;
    internal int CantidadPaginas => vista?.CantidadPaginas ?? 0;

    internal MYGVistaPreliminarReportesForm(string nombre, IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        configuracion = new MYGConfiguracionVistaReporte(reportes);
        nombreDocumento = nombre ?? "Reportes del proyecto";
        Name = "vista_preliminar_reportes";
        Text = "Vista preliminar · " + nombreDocumento;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1280, 850); MinimumSize = new Size(960, 650);
        WindowState = FormWindowState.Maximized;
        Font = new Font("Segoe UI", 9);
        BackColor = Color.FromArgb(226, 236, 246);

        var barra = new ToolStrip { Name = "vista_barra", Dock = DockStyle.Top, GripStyle = ToolStripGripStyle.Hidden, AutoSize = false, Height = 54 };
        ToolStripButton Accion(string texto, string nombreControl, Action accion)
        {
            var boton = new ToolStripButton(texto) { Name = nombreControl, DisplayStyle = ToolStripItemDisplayStyle.Text, AutoSize = true, Padding = new Padding(8) };
            boton.Click += (_, _) => Intentar(accion); barra.Items.Add(boton); return boton;
        }
        Accion("Volver al proyecto", "vista_volver", Close);
        Accion("Imprimir", "vista_imprimir_barra", Imprimir);
        Accion("Exportar PDF…", "vista_pdf_barra", ExportarPdf);
        barra.Items.Add(new ToolStripSeparator());
        primera = Accion("|◀", "vista_primera", () => MostrarPagina(0));
        anterior = Accion("◀ Anterior", "vista_anterior", () => MostrarPagina(pagina - 1));
        siguiente = Accion("Siguiente ▶", "vista_siguiente", () => MostrarPagina(pagina + 1));
        ultima = Accion("▶|", "vista_ultima", () => MostrarPagina(CantidadPaginas - 1));
        barra.Items.Add(new ToolStripSeparator());
        Accion("Alejar", "vista_alejar", () => CambiarZoom(Math.Max(.25f, ampliacion - .25f)));
        Accion("Acercar", "vista_acercar", () => CambiarZoom(Math.Min(3, ampliacion + .25f)));
        Accion("Página completa", "vista_ajustar", AjustarPagina);
        Accion("Restablecer", "vista_restaurar", () => { configuracion.Restaurar(); paginaInvalida = false; CargarAjustes(); ActualizarVista(); });

        var opciones = new FlowLayoutPanel { Name = "vista_opciones", Dock = DockStyle.Left, Width = 280,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(10), BackColor = Color.FromArgb(213, 227, 241) };
        void Campo(string texto, Control control)
        {
            opciones.Controls.Add(new Label { Text = texto, AutoSize = true, Margin = new Padding(3, 8, 3, 3) });
            control.Width = 240; opciones.Controls.Add(control);
        }
        opciones.Controls.Add(new Label { Text = "Imprimir / exportar PDF", Font = new Font(Font, FontStyle.Bold), AutoSize = true });
        Campo("Impresora", impresoras);
        imprimir = new Button { Name = "vista_imprimir", Text = "Imprimir", Width = 240, Height = 32 };
        imprimir.Click += (_, _) => Intentar(Imprimir); opciones.Controls.Add(imprimir);
        pdf = new Button { Name = "vista_pdf", Text = "Exportar PDF…", Width = 240, Height = 32 };
        pdf.Click += (_, _) => Intentar(ExportarPdf); opciones.Controls.Add(pdf);
        opciones.Controls.Add(rango);
        Campo("Desde la página", desde); Campo("Hasta la página", hasta); Campo("Copias", copias);
        opciones.Controls.Add(new Label { Text = "Configuración de todas las hojas", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Margin = new Padding(3, 14, 3, 3) });
        orientacion.Items.AddRange(new object[] { "Vertical", "Horizontal" });
        tamano.Items.AddRange(new object[] { "A4", "A3", "Carta", "Oficio" });
        var familias = FontFamily.Families;
        try { fuentes.Items.AddRange(familias.Select(f => f.Name).OrderBy(n => n).Cast<object>().ToArray()); }
        finally { foreach (var familia in familias) familia.Dispose(); }
        Campo("Orientación", orientacion); Campo("Tamaño de papel", tamano);
        Campo("Margen izquierdo (cm)", izquierda); Campo("Margen derecho (cm)", derecha);
        Campo("Margen superior (cm)", superior); Campo("Margen inferior (cm)", inferior);
        Campo("Fuente", fuentes); Campo("Escala de impresión (%)", escala);
        opciones.Controls.Add(titulos); opciones.Controls.Add(lineas); opciones.Controls.Add(encabezados);
        zoom.Items.AddRange(new object[] { "25%", "50%", "75%", "100%", "125%", "150%", "200%", "300%" });
        zoom.SelectedItem = "100%";
        Campo("Ampliación de la vista", zoom);
        superficie.Controls.Add(papel);
        Controls.Add(superficie); Controls.Add(opciones); Controls.Add(estado); Controls.Add(barra);

        CargarAjustes();
        foreach (var control in new Control[] { orientacion, tamano, izquierda, derecha, superior, inferior })
        {
            if (control is ComboBox combo) combo.SelectedIndexChanged += (_, _) => CambiarPagina();
            else ((NumericUpDown)control).ValueChanged += (_, _) => CambiarPagina();
        }
        escala.ValueChanged += (_, _) => Cambiar(() => configuracion.Escala = (float)escala.Value / 100);
        fuentes.SelectedIndexChanged += (_, _) => Cambiar(() => configuracion.Fuente(fuentes.Text));
        lineas.CheckedChanged += (_, _) => Cambiar(() => { foreach (var r in configuracion.Reportes) r.Hoja.ImprimirLineasDivision = lineas.Checked; });
        encabezados.CheckedChanged += (_, _) => Cambiar(() => { foreach (var r in configuracion.Reportes) r.Hoja.ImprimirEncabezados = encabezados.Checked; });
        titulos.CheckedChanged += (_, _) => Cambiar(() => { foreach (var r in configuracion.Reportes) r.Hoja.RepetirTitulos = titulos.Checked; });
        zoom.SelectedIndexChanged += (_, _) => { if (!cargando) CambiarZoom(float.Parse(zoom.Text.TrimEnd('%')) / 100); };
        impresoras.SelectedIndexChanged += (_, _) => { if (!cargando) Intentar(ActualizarVista); };
        rango.CheckedChanged += (_, _) => desde.Enabled = hasta.Enabled = rango.Checked;
        desde.Enabled = hasta.Enabled = false;
        Shown += (_, _) => Intentar(() => { CargarImpresoras(); ActualizarVista(); AjustarPagina(); });
    }

    private static ComboBox Lista(string nombre) => new() { Name = nombre, DropDownStyle = ComboBoxStyle.DropDownList };
    private static NumericUpDown Numero(string nombre, decimal min, decimal max, decimal valor) => new() { Name = nombre, Minimum = min, Maximum = max, Value = valor };
    private static NumericUpDown Margen(string nombre) => new() { Name = nombre, DecimalPlaces = 2, Increment = .1m, Minimum = 0, Maximum = 7.62m };

    private void CargarAjustes()
    {
        cargando = true;
        try
        {
            var h = configuracion.Reportes[0].Hoja;
            orientacion.SelectedItem = h.OrientacionPagina; tamano.SelectedItem = h.TamanoPapel;
            izquierda.Value = Math.Clamp(h.MargenIzquierdo * 2.54m, izquierda.Minimum, izquierda.Maximum);
            derecha.Value = Math.Clamp(h.MargenDerecho * 2.54m, derecha.Minimum, derecha.Maximum);
            superior.Value = Math.Clamp(h.MargenSuperior * 2.54m, superior.Minimum, superior.Maximum);
            inferior.Value = Math.Clamp(h.MargenInferior * 2.54m, inferior.Minimum, inferior.Maximum);
            string fuente = h.Celdas.Values.FirstOrDefault()?.Fuente ?? MYGCeldaHoja.FuentePredeterminada;
            if (!fuentes.Items.Contains(fuente)) fuentes.Items.Add(fuente);
            fuentes.SelectedItem = fuente; escala.Value = (decimal)configuracion.Escala * 100;
            titulos.Checked = h.RepetirTitulos; lineas.Checked = h.ImprimirLineasDivision; encabezados.Checked = h.ImprimirEncabezados;
        }
        finally { cargando = false; }
    }
    private void CargarImpresoras()
    {
        cargando = true;
        try
        {
            impresoras.Items.Clear(); impresoras.Items.Add("Vista sin impresora");
            foreach (string nombre in PrinterSettings.InstalledPrinters) impresoras.Items.Add(nombre);
            var predeterminada = new PrinterSettings();
            impresoras.SelectedItem = predeterminada.IsValid && impresoras.Items.Contains(predeterminada.PrinterName)
                ? predeterminada.PrinterName : "Vista sin impresora";
        }
        finally { cargando = false; }
    }
    private PrinterSettings ImpresoraSeleccionada() => impresoras.SelectedIndex > 0
        ? new PrinterSettings { PrinterName = impresoras.Text } : null;
    private void CambiarPagina()
    {
        if (cargando) return;
        paginaInvalida = true;
        Cambiar(() =>
        {
            configuracion.ConfigurarPagina(tamano.Text, orientacion.Text,
                izquierda.Value / 2.54m, derecha.Value / 2.54m, superior.Value / 2.54m, inferior.Value / 2.54m);
            paginaInvalida = false;
        });
    }
    private void Cambiar(Action cambio)
    {
        if (cargando) return;
        // Una configuración inválida nunca debe dejar una vista antigua exportable.
        InvalidarVista();
        Intentar(() => { cambio(); ActualizarVista(); });
    }
    internal void ActualizarVista()
    {
        InvalidarVista();
        if (paginaInvalida) throw new InvalidOperationException("Corrija el papel, la orientación o los márgenes antes de continuar.");
        vista = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala, ImpresoraSeleccionada());
        hasta.Maximum = desde.Maximum = vista.CantidadPaginas;
        if (!rango.Checked) hasta.Value = vista.CantidadPaginas;
        MostrarPagina(Math.Min(pagina, vista.CantidadPaginas - 1));
        imprimir.Enabled = ImpresoraSeleccionada()?.IsValid == true;
        pdf.Enabled = true;
    }
    private void InvalidarVista()
    {
        vista = null; LiberarImagen();
        imprimir.Enabled = pdf.Enabled = false;
        primera.Enabled = anterior.Enabled = siguiente.Enabled = ultima.Enabled = false;
    }
    private void MostrarPagina(int indice)
    {
        if (vista == null || indice < 0 || indice >= vista.CantidadPaginas) return;
        pagina = indice;
        var medida = vista.TamanoPagina(indice);
        var imagen = new Bitmap((int)Math.Ceiling(medida.Width * 96), (int)Math.Ceiling(medida.Height * 96));
        try
        {
            imagen.SetResolution(96, 96);
            using var g = Graphics.FromImage(imagen);
            g.Clear(Color.White); vista.DibujarPagina(g, indice);
        }
        catch { imagen.Dispose(); throw; }
        LiberarImagen(); papel.Image = imagen; papel.Visible = true;
        CambiarZoom(ampliacion);
        primera.Enabled = anterior.Enabled = pagina > 0;
        siguiente.Enabled = ultima.Enabled = pagina + 1 < CantidadPaginas;
    }
    private void CambiarZoom(float valor)
    {
        ampliacion = valor;
        if (papel.Image != null)
        {
            papel.Size = new Size((int)(papel.Image.Width * valor), (int)(papel.Image.Height * valor));
            superficie.AutoScrollMinSize = new Size(papel.Width + 48, papel.Height + 48);
        }
        estado.Text = "Página " + (pagina + 1) + " de " + CantidadPaginas + "  ·  Ampliación " + (valor * 100).ToString("0") + "%";
    }
    private void AjustarPagina()
    {
        if (papel.Image == null) return;
        CambiarZoom(Math.Clamp(Math.Min((superficie.ClientSize.Width - 60f) / papel.Image.Width,
            (superficie.ClientSize.Height - 60f) / papel.Image.Height), .1f, 3));
    }
    private void Imprimir()
    {
        if (vista == null) throw new InvalidOperationException("Corrija la configuración y actualice la vista antes de imprimir.");
        var ajustes = ImpresoraSeleccionada();
        if (ajustes?.IsValid != true) throw new InvalidOperationException("Seleccione una impresora disponible.");
        ajustes.Copies = (short)copias.Value;
        ajustes.MinimumPage = 1; ajustes.MaximumPage = CantidadPaginas;
        ajustes.FromPage = (int)desde.Value; ajustes.ToPage = (int)hasta.Value;
        ajustes.PrintRange = rango.Checked ? PrintRange.SomePages : PrintRange.AllPages;
        // Usar el plan visible conserva exactamente los cortes y páginas revisados.
        // La impresora, el rango y las copias se eligen en el panel de esta vista.
        using var documento = vista.Documento(nombreDocumento, ajustes);
        documento.Print();
    }
    private void ExportarPdf()
    {
        if (vista == null) throw new InvalidOperationException("Corrija la configuración y actualice la vista antes de exportar.");
        const string nombre = "Microsoft Print to PDF";
        if (!PrinterSettings.InstalledPrinters.Cast<string>().Any(n => string.Equals(n, nombre, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Active Microsoft Print to PDF en las características de Windows para exportar el informe como PDF.");
        if (!string.Equals(impresoras.Text, nombre, StringComparison.OrdinalIgnoreCase))
        {
            // El cambio de driver puede cambiar los cortes. Revisarlos precede al guardado.
            cargando = true;
            try { impresoras.SelectedItem = nombre; }
            finally { cargando = false; }
            ActualizarVista();
            estado.Text = "Vista preparada para PDF. Revise las páginas y pulse Exportar PDF para guardar.";
            return;
        }
        var ajustes = new PrinterSettings { PrinterName = nombre };
        using var dialogo = new SaveFileDialog { Title = "Exportar informe a PDF", Filter = "Documento PDF (*.pdf)|*.pdf",
            DefaultExt = "pdf", AddExtension = true, FileName = "Informe.pdf", OverwritePrompt = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        ajustes.PrintToFile = true; ajustes.PrintFileName = dialogo.FileName;
        ajustes.PrintRange = rango.Checked ? PrintRange.SomePages : PrintRange.AllPages;
        ajustes.FromPage = (int)desde.Value; ajustes.ToPage = (int)hasta.Value;
        using var documento = vista.Documento(nombreDocumento, ajustes);
        documento.PrintController = new StandardPrintController();
        documento.Print();
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            estado.Text = ex.Message;
            MessageBox.Show(this, ex.Message, "Vista preliminar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
    private void LiberarImagen()
    {
        var anterior = papel.Image; papel.Image = null; papel.Visible = false; anterior?.Dispose();
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) LiberarImagen();
        base.Dispose(disposing);
    }
}
