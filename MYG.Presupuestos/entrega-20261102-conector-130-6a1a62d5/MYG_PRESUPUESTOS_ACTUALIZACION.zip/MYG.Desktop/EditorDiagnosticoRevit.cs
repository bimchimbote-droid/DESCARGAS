using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MYG.Externo;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private readonly Dictionary<int, EstadoConectorRevit> estadosConectorIds = new();

    private async Task ComprobarConectorIdsAsync(int pid, CancellationToken ct)
    {
        var respuesta = await cliente.EnviarAsync(pid, new SolicitudRevit
            { Accion = "ESTADO_CONECTOR", Credencial = sesion.Credencial }, ct);
        if (respuesta.Conector != null) estadosConectorIds[pid] = respuesta.Conector;
        CompatibilidadConectorRevit.ExigirIdentidad(respuesta.Conector, pid);
        if (!respuesta.Ok)
            throw new InvalidOperationException("El conector actualizado respondió, pero no autorizó la consulta. Vuelva a iniciar sesión en MYG.\n"
                + CompatibilidadConectorRevit.Resumen(respuesta.Conector));
    }

    private string ContextoConectorIds(int pid, EstadoConectorRevit estado = null)
    {
        if (estado == null) estadosConectorIds.TryGetValue(pid, out estado);
        return CompatibilidadConectorRevit.Resumen(estado);
    }
}
