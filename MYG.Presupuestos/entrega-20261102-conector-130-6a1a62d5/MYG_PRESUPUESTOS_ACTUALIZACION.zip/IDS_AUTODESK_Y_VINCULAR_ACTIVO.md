# Activos Revit: lectura de IDs y diagnóstico del conector 1.3.0

Actualización incremental sobre la entrega de IDs automáticos publicada en DESCARGAS, commit `68c3c401bb49af6669ebe0e34499ebc6115c0a41`. La referencia del código sigue en `a3130eca22fb423fbe7aae665a02dccdb379522c`; se conservan las modificaciones anteriores. Se entregan únicamente los archivos modificados en esta actualización, con sus rutas completas.

## Qué cambia

La captura muestra una excepción nativa sin identificar la llamada que falla. Las entregas anteriores conservaban el mismo número de versión del conector; esa captura no permite saber qué DLL respondió ni demostrar una causa concreta. Esta actualización separa ambas comprobaciones:

- Antes de consultar documentos, MYG verifica el conector que realmente está cargado en cada proceso Revit: versión mínima **1.3.0**, ruta, PID, capacidad y GUID de compilación. El estado se consulta autenticado, sin acceder a la API de documentos ni depender del ExternalEvent.
- Las respuestas del conector incluyen esos datos. Si responde una DLL anterior, se pide reinstalar antes de intentar traer IDs.
- La lectura valida por separado el documento y la ruta Autodesk o central antes de pedir sus GUID. Cada operación informa su etapa `ID01–ID18` o `CX01–CX08` y tipo de excepción, sin exponer mensajes nativos ni credenciales.
- Si falla, los datos escritos se conservan y aparece **Ver error**, que abre el informe completo seleccionable y con desplazamiento. No se inventan IDs ni se vincula parcialmente.
- Se conserva **Vincular** junto a **Documento Revit · ID**, sin botones Copiar. Un modelo abierto se consulta directamente; con varios modelos disponibles aparece el selector.
- Si Revit identifica un archivo local, se indica expresamente que carece de IDs Autodesk. Elegir Nube Autodesk en el formulario no convierte un RVT local en modelo Autodesk. En un modelo realmente alojado en Autodesk se rellenan ambos GUID desde Revit.

El instalador exige versión 1.3.0 o posterior y detecta registros duplicados por AddInId, clase o nombre de DLL, incluso si otro registro usa un identificador diferente. Informa sus rutas y conserva los archivos para su revisión.

## Instalar en Windows

**Es necesario actualizar escritorio y conector, y cerrar todas las instancias de Revit.** Revit mantiene la DLL ya cargada hasta que termina el proceso.

1. Cierre MYG y todas las ventanas de Revit. Respalde sus cambios locales.
2. Extraiga el ZIP temporalmente y copie sus archivos a la raíz del código, conservando las rutas. Es incremental sobre la entrega indicada arriba. Compare antes de sobrescribir si ha realizado cambios propios posteriores.
3. En PowerShell, desde la raíz del código, con SDK .NET 10 y Revit 2027 instalado:

```powershell
dotnet restore MYG.Presupuestos.sln
dotnet build MYG.Presupuestos.sln -c Release
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Actualizar-Conector.ps1
```

Si Revit se encuentra en otra carpeta, indique `-RevitInstallDir` al script existente. Actualizar-Conector utiliza el instalador incluido: recompila las fuentes actuales, instala también MYG.Core.dll y verifica las copias por SHA-256. No use una carpeta dist antigua. La salida debe informar **Version: 1.3.0.0**. Si se detectan manifiestos duplicados, revise las rutas informadas antes de reintentar.

4. Abra Revit de nuevo y el modelo deseado. Ejecute el escritorio recompilado.
5. Abra Activos Revit de la obra y pulse **Traer del modelo abierto**. Elija el modelo si hay varios. En un modelo Autodesk, compruebe ambos IDs; en uno local, compruebe el origen y la ruta detectados.
6. Guarde el activo si tiene cambios pendientes, use **Vincular** junto al documento y confirme con **Aplicar a la obra**. Guarde el proyecto para persistir los cambios.
7. Si vuelve a fallar, abra **Ver error**. El informe permitirá identificar la versión/ruta de la DLL y la etapa que falla, en lugar de repetir la misma excepción sin contexto.

No se requieren SQL, paquetes nuevos ni credenciales adicionales. Se conservan configuración, permisos y datos de las obras. El ZIP no contiene SQLite, ejecutables ni DLL.

## Validación efectuada

En Linux, con SDK .NET 10.0.100 y referencias NuGet Revit 2027:

- Solución completa Release: **0 errores y 0 advertencias**.
- Núcleo/protocolo/modeladores: **8 grupos aprobados**, incluyendo rechazo de DLL antigua, otro PID, capacidad insuficiente o compilación ausente.
- Activos Revit: **10 grupos aprobados**, incluyendo ambos GUID Autodesk, validación de modelos locales y persistencia JSON/SQLite.
- DLL compilada inspeccionada sin cargar Revit: versión PE **1.3.0.0** y MVID no vacío.
- Pruebas UI ampliadas y compiladas: fallo conserva el borrador y expone el diagnóstico mediante Ver error. **No ejecutadas**: requieren Windows.

```text
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --modeladores-bim
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --activos-revit
```

La API nativa y el modelo de la captura no están disponibles en este entorno: la lectura real de sus IDs queda pendiente de comprobar en Windows/Revit. No se afirma que el error concreto de su equipo haya sido reproducido. En Windows puede ejecutar `dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --activos-revit`. Compruebe además selección entre dos modelos y cancelación sin perder datos.

## GitHub del código

Se publica únicamente este ZIP en el repositorio DESCARGAS. No se hace Push al código. Después de aplicar y comprobar en Windows, revise los archivos en Cambios de Git de Visual Studio, seleccione los correspondientes a esta entrega, haga Commit y luego Push a su rama de trabajo. No incluya bases de datos ni archivos generados.

## Archivos de la actualización

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `IDS_AUTODESK_Y_VINCULAR_ACTIVO.md` | REEMPLAZAR | Instalación, uso y alcance de la validación |
| 2 | `MYG.Core/EstadoConectorRevit.cs` | CREAR | Identidad y compatibilidad del conector cargado |
| 3 | `MYG.Core/Protocolo.cs` | REEMPLAZAR | Consulta de estado autenticada y datos del conector |
| 4 | `MYG.Desktop/ActivosRevitForm.cs` | REEMPLAZAR | Ver error y aviso de origen local o Autodesk |
| 5 | `MYG.Desktop/EditorDiagnosticoRevit.cs` | CREAR | Comprobación de versión antes de consultar IDs |
| 6 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Verificación y diagnóstico en selección y lectura |
| 7 | `MYG.Desktop/PresupuestosActivosRevit.cs` | REEMPLAZAR | Exigir conector actualizado al traer IDs |
| 8 | `MYG.Pruebas/ModeladoresBimCoreCheck.cs` | REEMPLAZAR | Pruebas de estado y compatibilidad |
| 9 | `MYG.PruebasUI/ActivosRevitUICheck.cs` | REEMPLAZAR | Conservación de datos y exposición del error |
| 10 | `MYG.Revit2027/Aplicacion.cs` | REEMPLAZAR | Estado de DLL sin API nativa y errores por etapa |
| 11 | `MYG.Revit2027/IdentidadDocumentoRevit.cs` | REEMPLAZAR | Validar documento y ModelPath al leer GUIDs |
| 12 | `MYG.Revit2027/MYG.Revit2027.csproj` | REEMPLAZAR | Versión 1.3.0 y capacidad de lectura |
| 13 | `scripts/Instalar-Conector.ps1` | REEMPLAZAR | Exigir versión 1.3.0 y detectar registros duplicados |
