using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ModeladoresBimCoreCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza(Action accion)
    {
        bool rechazada = false;
        try { accion(); }
        catch (InvalidOperationException) { rechazada = true; }
        catch (InvalidDataException) { rechazada = true; }
        Exige(rechazada, "Una operación BIM inválida o sin permiso fue aceptada.");
    }

    private static FiltroPlanificacion Filtro(string valor = "N01") =>
        new() { Parametro = "Nivel", Regla = "igual", Valor = valor };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var permisos = new MYGPermisosModulos { Acu = false, Especificaciones = false,
            MetradosExcel = false, MetradosRevit = true };
        var denegado = permisos.Copiar(); denegado.MetradosRevit = false;
        var doc = MYGProyectoStorage.Nuevo("OBRA BIM");
        string presupuestoId = doc.Presupuestos[0].Id;
        string original = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGPartidasBim.CrearTexto(doc, presupuestoId, "Sin permiso", "m²", null, denegado, "editor"));
        Rechaza(() => MYGPartidasBim.CrearTexto(doc, presupuestoId, "Lector", "m²", null, permisos, "lector"));
        Exige(original == MYGProyectoStorage.Firma(doc), "La operación rechazada mutó la obra.");
        Exige(!JsonSerializer.Deserialize<MYGPermisosModulos>("{\"acu\":true}").MetradosRevit,
            "Un permiso ausente concedió escritura BIM.");
        Exige(permisos.Permite("editor", "metrados_revit") && !denegado.Permite("editor", "metrados_revit"),
            "El permiso BIM depende de módulos ajenos.");
        pasa("Metrados Revit exige su permiso independiente y rol de edición incluso en llamadas directas; permiso ausente se deniega");

        var primera = MYGPartidasBim.CrearTexto(doc, presupuestoId, "Concreto de coordinación", "m³", null, permisos, "editor");
        Exige(primera.CreadaParaBim && primera.Id == primera.IdLocalMYG && primera.Costos.Analisis.Count == 0 &&
            primera.Costos.PrecioDirecto == 0 && primera.Costos.EspecificacionTexto == "" &&
            primera.Costos.Hoja.Celdas.Count == new MYGDatosPartida().Hoja.Celdas.Count,
            "La creación BIM incorporó contenido de otro módulo.");
        var p = doc.Presupuestos[0];
        for (int n = 1; n <= 1000; n++)
        {
            string id = "BIM-" + n;
            p.Items.Add(new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdPropuesta = id,
                Descripcion = "Partida " + n, Unidad = "m²", CreadaParaBim = true, TipoPropuesta = "PARTIDA",
                Origen = "MODELO", Estado = "PROPUESTA", Posicion = n + 1 });
        }
        string[] ids = p.Items.Select(i => i.Id).ToArray();
        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Reemplazar,
            new[] { Filtro() }, "PLANTILLA BIM", true, permisos, "editor");
        Exige(p.Items.Count == 1001 && p.Items.All(i => i.Filtros.Count == 1 && i.Plantilla == "PLANTILLA BIM"),
            "El lote limitó arbitrariamente la selección.");
        p.Items[0].Filtros[0].Valor = "ÚNICA";
        Exige(p.Items[1].Filtros[0].Valor == "N01", "Dos partidas comparten la misma instancia de filtros.");
        pasa("La edición masiva aplica filtros y plantilla a 1001 partidas sin tope de selección ni referencias compartidas");

        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Reemplazar,
            Enumerable.Range(1, 8).Select(n => Filtro(n.ToString())), null, false, permisos, "editor");
        string ocho = MYGProyectoStorage.Firma(doc);
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Agregar,
            new[] { Filtro() }, null, false, permisos, "editor"));
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids.Append("AJENA"),
            MYGOperacionFiltrosBim.Limpiar, null, null, false, permisos, "editor"));
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids,
            MYGOperacionFiltrosBim.Reemplazar, new[] { new FiltroPlanificacion { Valor = "incompleto" } }, null, false, permisos, "editor"));
        Exige(ocho == MYGProyectoStorage.Firma(doc), "Un lote inválido dejó cambios parciales.");
        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Modificar,
            new[] { Filtro("MODIFICADO") }, null, false, permisos, "editor", 7);
        MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids, MYGOperacionFiltrosBim.Eliminar,
            null, null, false, permisos, "editor", 0);
        Exige(p.Items.All(i => i.Filtros.Count == 7 && i.Filtros[6].Valor == "MODIFICADO" && i.Parametro == "Nivel"),
            "Modificar/eliminar perdió orden o campos legados.");
        pasa("Lotes de filtros respetan ocho por tabla, modifican y eliminan por posición y rechazan fallos sin cambios parciales");

        var copia = MYGProyectoStorage.Copia(doc);
        void Protegido(Action<MYGProyectoDocumento> cambiar)
        {
            var candidato = MYGProyectoStorage.Copia(copia); cambiar(candidato);
            Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(copia, candidato, denegado));
        }
        Protegido(d => d.Presupuestos[0].Items.RemoveAt(0));
        Protegido(d => d.Presupuestos[0].Items[0].Descripcion = "Cambio sin permiso");
        Protegido(d => d.Presupuestos[0].Items[0].Filtros[0].Valor = "cambio");
        Protegido(d => d.Presupuestos[0].Items[0].IdLocalMYG = "OTRA");
        Protegido(d => d.Presupuestos[0].CantidadFiltros = 2);
        Protegido(d => d.Presupuestos[0].Items[0].Costos.FuenteMetrado = MYGFuenteMetrado.BIM);
        Protegido(d => d.Presupuestos[0].Items[0].Costos.MetradosBIM.Add(new MYGMetradoBIM()));
        var cambiaAcu = MYGProyectoStorage.Copia(copia); cambiaAcu.Presupuestos[0].Items[0].Costos.PrecioDirecto = 50;
        Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(copia, cambiaAcu, permisos));
        var permiteAcu = denegado.Copiar(); permiteAcu.Acu = true;
        MYGCambiosModulosNube.ExigirPermitidos(copia, cambiaAcu, permiteAcu);
        var heredada = MYGProyectoStorage.Copia(copia);
        heredada.Presupuestos[0].Items.ForEach(i => i.CreadaParaBim = false);
        var filtroHeredado = MYGProyectoStorage.Copia(heredada);
        filtroHeredado.Presupuestos[0].Items[0].Filtros[0].Valor = "Sin permiso en partida existente";
        Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(heredada, filtroHeredado, denegado));
        Rechaza(() => MYGEdicionMasivaFiltrosBim.Aplicar(doc, presupuestoId, ids,
            MYGOperacionFiltrosBim.Limpiar, null, null, false, denegado, "editor"));
        pasa("La guardia compuesta protege alta/baja, identidad, filtros, columnas y metrados BIM sin conceder ACU, Excel o especificaciones");

        string ruta = Path.Combine(carpeta, "modeladores-bim.sqlite");
        MYGProyectoStorage.Guardar(ruta, doc);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        Exige(reabierto.Presupuestos[0].Items.Count == 1001 && reabierto.Presupuestos[0].Items.All(i =>
            i.CreadaParaBim && i.Filtros.Count == 7 && i.Filtros[6].Valor == "MODIFICADO"),
            "Cerrar y reabrir SQLite perdió la configuración BIM.");
        pasa("SQLite conserva identidad BIM, plantilla y filtros de todas las partidas al guardar y reabrir");

        var fuente = MYGProyectoStorage.Nuevo("CATÁLOGO"); var pf = fuente.Presupuestos[0];
        var raiz = new ItemPresupuestoDelphin { Id = "RAIZ", IdLocalMYG = "RAIZ", Descripcion = "Entrada con costos",
            Unidad = "m³", TipoPropuesta = "PARTIDA", Costos = new() { PrecioDirecto = 123,
                EspecificacionTexto = "Especificación que no se debe copiar" } };
        pf.Items.Add(raiz);
        string catalogo = Path.Combine(carpeta, "catalogo-bim.sqlite"); MYGProyectoStorage.Guardar(catalogo, fuente);
        var entrada = MYGCatalogos.GuardarPartida(catalogo, pf, raiz, "CAT-001", raiz.Descripcion, raiz.Unidad);
        var destino = MYGProyectoStorage.Nuevo("OBRA DESTINO"); string destinoId = destino.Presupuestos[0].Id;
        var creada = MYGPartidasBim.CrearCatalogo(destino, destinoId, catalogo, entrada, null, permisos, "editor");
        Exige(creada.CatalogoBim?.Id == entrada.Id && creada.CatalogoBim.Revision == entrada.Revision &&
            creada.Costos.PrecioDirecto == 0 && creada.Costos.EspecificacionTexto == "" && creada.Costos.CatalogoMYGId == null,
            "El vínculo del catálogo BIM copió contenido de otros módulos.");
        MYGEdicionMasivaFiltrosBim.Aplicar(destino, destinoId, new[] { creada.Id }, MYGOperacionFiltrosBim.Reemplazar,
            new[] { Filtro("CATÁLOGO OBRA") }, "PLANTILLA CATÁLOGO", true, permisos, "editor");
        var otra = MYGPartidasBim.CrearCatalogo(destino, destinoId, catalogo, entrada, null, permisos, "editor");
        Exige(otra.Id != creada.Id && otra.Filtros.Single().Valor == "CATÁLOGO OBRA", "No se recuperó configuración de catálogo de la obra.");
        string destinoRuta = Path.Combine(carpeta, "obra-catalogo-bim.sqlite");
        MYGProyectoStorage.Guardar(destinoRuta, destino);
        var destinoReabierto = MYGProyectoStorage.Leer(destinoRuta);
        Exige(destinoReabierto.Presupuestos[0].Items.All(i => i.CatalogoBim?.Id == entrada.Id &&
            i.Filtros.Single().Valor == "CATÁLOGO OBRA"), "SQLite perdió el vínculo BIM con el catálogo.");
        var tercera = MYGPartidasBim.CrearCatalogo(destinoReabierto, destinoId, catalogo, entrada, null, permisos, "editor");
        Exige(tercera.Filtros.Single().Valor == "CATÁLOGO OBRA" && MYGCatalogos.LeerPartida(catalogo, entrada.Id)
            .Partidas.Single().Costos.PrecioDirecto == 123, "Reabrir no recuperó filtros o modificó el catálogo fuente.");
        string bibliotecaRuta = Path.Combine(carpeta, "modeladores-bim.biblioteca.json");
        MYGBibliotecaPartidas.GuardarConfiguraciones(bibliotecaRuta, MYGProyectoStorage.LeerBiblioteca(bibliotecaRuta),
            new[] { new MYGGuardarConfiguracionSolicitud { Partida = tercera, Nombre = "Filtros del catálogo" } });
        string copiaCatalogo = Path.Combine(carpeta, "catalogo-trasladado.sqlite"); File.Copy(catalogo, copiaCatalogo);
        var otraObra = MYGProyectoStorage.Nuevo("OTRA OBRA BIM");
        var nuevaInstancia = MYGPartidasBim.CrearCatalogo(otraObra, otraObra.Presupuestos[0].Id,
            copiaCatalogo, entrada, null, permisos, "editor");
        Exige(MYGBibliotecaPartidas.AplicarUnica(MYGProyectoStorage.LeerBiblioteca(bibliotecaRuta), nuevaInstancia) &&
            nuevaInstancia.Filtros.Single().Valor == "CATÁLOGO OBRA" && nuevaInstancia.Costos.PrecioDirecto == 0,
            "La biblioteca no recuperó los filtros del catálogo trasladado en otra obra.");
        var nativaA = new ItemPresupuestoDelphin { CatalogoBim = new() { Id = "AC-1", RutaSQLite = "D:/CatalogoA.sqlite" } };
        var nativaB = new ItemPresupuestoDelphin { CatalogoBim = new() { Id = "AC-1", RutaSQLite = "D:/CatalogoB.sqlite" } };
        Exige(!MYGBibliotecaPartidas.Coincide(MYGBibliotecaPartidas.Referencia(nativaA), nativaB),
            "Dos catálogos nativos con ID repetible compartieron configuración.");
        entrada.Revision++;
        Rechaza(() => MYGPartidasBim.CrearCatalogo(destino, destinoId, catalogo, entrada, null, permisos, "editor"));
        pasa("Selección de catálogo verifica revisión y conserva vínculo y configuración de obra sin importar ACU, especificaciones ni Excel");

        // Un conector antiguo no devuelve el catálogo de modelos abiertos.
        var legado = JsonSerializer.Deserialize<MYG.Externo.RespuestaRevit>(
            "{\"Ok\":true,\"Documento\":{\"Id\":\"modelo-activo\",\"Nombre\":\"ESTRUCTURAS\"}}",
            MYG.Externo.ProtocoloMYG.Json);
        Exige(legado.Documentos.Count == 0 && legado.Documento.Id == "modelo-activo",
            "El catálogo nuevo impidió reconocer un conector anterior con un único documento activo.");
        var primero = new MYG.Externo.DocumentoRevitInfo { Id = "apertura-A", Nombre = "ESTRUCTURAS" };
        var segundo = new MYG.Externo.DocumentoRevitInfo { Id = "apertura-B", Nombre = "ESTRUCTURAS",
            Plantillas = new() { "PLANTILLA B" }, Parametros = new() { ["PLANTILLA B"] = new() { "Nivel" } } };
        var consulta = new MYG.Externo.SolicitudRevit { Accion = "INFO", DocumentoId = segundo.Id };
        MYG.Externo.ProtocoloMYG.Validar(consulta);
        Exige(!JsonSerializer.SerializeToElement(consulta, MYG.Externo.ProtocoloMYG.Json)
            .TryGetProperty(nameof(MYG.Externo.SolicitudRevit.SoloListarDocumentos), out _),
            "La optimización de descubrimiento cambió el payload de las consultas anteriores.");
        var descubrimiento = new MYG.Externo.SolicitudRevit { Accion = "INFO", SoloListarDocumentos = true };
        MYG.Externo.ProtocoloMYG.Validar(descubrimiento);
        Exige(JsonSerializer.SerializeToElement(descubrimiento, MYG.Externo.ProtocoloMYG.Json)
            .GetProperty(nameof(MYG.Externo.SolicitudRevit.SoloListarDocumentos)).GetBoolean()
            && !JsonSerializer.Deserialize<MYG.Externo.SolicitudRevit>("{\"Accion\":\"INFO\"}", MYG.Externo.ProtocoloMYG.Json).SoloListarDocumentos,
            "La búsqueda ligera no se distingue de la consulta de plantillas o rompió una solicitud antigua.");
        var respuesta = new MYG.Externo.RespuestaRevit { Id = consulta.Id, Ok = true,
            Documento = segundo, Documentos = new() { primero, segundo } };
        var decodificada = JsonSerializer.Deserialize<MYG.Externo.RespuestaRevit>(
            JsonSerializer.Serialize(respuesta, MYG.Externo.ProtocoloMYG.Json), MYG.Externo.ProtocoloMYG.Json);
        MYG.Externo.ProtocoloMYG.ValidarRespuesta(consulta, decodificada);
        Exige(decodificada.Documentos.Count == 2 && decodificada.Documentos.Select(d => d.Id).Distinct().Count() == 2
            && decodificada.Documento.Id == consulta.DocumentoId && decodificada.Documento.Parametros["plantilla b"].Single() == "Nivel",
            "El protocolo mezcló dos modelos con el mismo nombre o perdió los parámetros del modelo elegido.");
        var valores = new MYG.Externo.SolicitudRevit { Accion = "VALORES", DocumentoId = segundo.Id,
            Plantilla = "PLANTILLA B", Parametro = "Nivel" };
        MYG.Externo.ProtocoloMYG.Validar(valores);
        valores.DocumentoId = null;
        Rechaza(() => MYG.Externo.ProtocoloMYG.Validar(valores));
        Exige(!JsonSerializer.SerializeToElement(consulta, MYG.Externo.ProtocoloMYG.Json)
            .TryGetProperty(nameof(MYG.Externo.SolicitudRevit.SoloIdentidad), out _),
            "La lectura de identidad cambió el contrato de las consultas anteriores por defecto.");
        var identidad = new MYG.Externo.SolicitudRevit { Accion = "INFO", DocumentoId = segundo.Id, SoloIdentidad = true };
        MYG.Externo.ProtocoloMYG.Validar(identidad);
        var identidadReabierta = JsonSerializer.Deserialize<MYG.Externo.SolicitudRevit>(
            JsonSerializer.Serialize(identidad, MYG.Externo.ProtocoloMYG.Json), MYG.Externo.ProtocoloMYG.Json);
        Exige(identidadReabierta.SoloIdentidad && !identidadReabierta.SoloListarDocumentos
            && identidadReabierta.DocumentoId == segundo.Id && identidadReabierta.Accion == "INFO"
            && !JsonSerializer.Deserialize<MYG.Externo.SolicitudRevit>("{\"Accion\":\"INFO\"}", MYG.Externo.ProtocoloMYG.Json).SoloIdentidad,
            "La consulta de identidad perdió el modelo elegido, pidió plantillas o dejó de aceptar clientes anteriores.");
        var identificada = new MYG.Externo.RespuestaRevit { Id = identidad.Id, Ok = true,
            Documento = new() { Id = segundo.Id, DocumentoRevitId = "local:identidad-persistente", Nombre = segundo.Nombre } };
        var identidadRespuesta = JsonSerializer.Deserialize<MYG.Externo.RespuestaRevit>(
            JsonSerializer.Serialize(identificada, MYG.Externo.ProtocoloMYG.Json), MYG.Externo.ProtocoloMYG.Json);
        MYG.Externo.ProtocoloMYG.ValidarRespuesta(identidad, identidadRespuesta);
        Exige(identidadRespuesta.Documento.DocumentoRevitId == "local:identidad-persistente"
            && identidadRespuesta.Documento.Plantillas.Count == 0 && identidadRespuesta.Documento.Parametros.Count == 0,
            "La respuesta ligera perdió la identidad persistente del modelo.");
        pasa("Protocolo de plantillas conserva conectores anteriores, dos documentos con nombre igual y consultas ligadas al modelo elegido");
        var estadoSolicitud = new MYG.Externo.SolicitudRevit { Accion = "ESTADO_CONECTOR" };
        MYG.Externo.ProtocoloMYG.Validar(estadoSolicitud);
        var estadoReal = new MYG.Externo.EstadoConectorRevit { Version = "1.3.0.0", Ruta = @"C:\MYG\Conector\MYG.Revit2027.dll",
            Pid = 123, CapacidadIdentidad = 2, CompilacionId = "11111111-2222-4333-8444-555555555555" };
        var estadoRespuesta = new MYG.Externo.RespuestaRevit { Id = estadoSolicitud.Id, Ok = true, Conector = estadoReal };
        var estadoLeido = JsonSerializer.Deserialize<MYG.Externo.RespuestaRevit>(JsonSerializer.Serialize(estadoRespuesta, MYG.Externo.ProtocoloMYG.Json), MYG.Externo.ProtocoloMYG.Json);
        MYG.Externo.ProtocoloMYG.ValidarRespuesta(estadoSolicitud, estadoLeido);
        MYG.Externo.CompatibilidadConectorRevit.ExigirIdentidad(estadoLeido.Conector, 123);
        Exige(estadoLeido.Documento == null && estadoLeido.Conector.CompilacionId == estadoReal.CompilacionId
            && estadoLeido.Conector.Ruta == estadoReal.Ruta, "La comprobación del ensamblado depende de un documento o perdió la DLL real.");
        Rechaza(() => MYG.Externo.CompatibilidadConectorRevit.ExigirIdentidad(null, 123));
        Rechaza(() => MYG.Externo.CompatibilidadConectorRevit.ExigirIdentidad(estadoReal, 999));
        foreach (var cambio in new Action<MYG.Externo.EstadoConectorRevit>[]
        {
            e => e.Version = "1.2.0.0", e => e.CapacidadIdentidad = 1,
            e => e.CompilacionId = "", e => e.Ruta = ""
        })
        {
            var incompatible = MYGProyectoStorage.Copia(estadoReal); cambio(incompatible);
            Rechaza(() => MYG.Externo.CompatibilidadConectorRevit.ExigirIdentidad(incompatible, 123));
        }
        Exige(!JsonSerializer.SerializeToElement(new MYG.Externo.RespuestaRevit(), MYG.Externo.ProtocoloMYG.Json).TryGetProperty("Conector", out _),
            "La metadata ausente cambió las respuestas del protocolo anterior.");
        pasa("El estado real del conector se verifica sin modelo y rechaza DLL anteriores, capacidades insuficientes, otro PID o compilación ausente");

    }
}
