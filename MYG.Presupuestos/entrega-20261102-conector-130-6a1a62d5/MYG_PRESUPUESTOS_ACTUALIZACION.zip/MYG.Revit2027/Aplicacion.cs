using System.Collections.Concurrent;
using System.IO.Pipes;
using System.IO;
using Autodesk.Revit.UI;
using MYG.Externo;
using MYG_2027;

namespace MYG.Conector;

public sealed class Aplicacion : IExternalApplication
{
    private ExternalEvent evento;
    private Receptor receptor;
    private CancellationTokenSource cierre;
    private readonly ConcurrentQueue<OperacionPendiente> cola = new();
    private readonly List<(Autodesk.Revit.DB.Document Documento, string Id)> documentos = new();
    public Result OnStartup(UIControlledApplication app)
    {
        cierre = new(); app.Idling += Inicializar;
        try { app.CreateRibbonTab("MYG"); } catch (ArgumentException) { }
        var panel = app.GetRibbonPanels("MYG").FirstOrDefault(p => p.Name == "Presupuestos") ?? app.CreateRibbonPanel("MYG", "Presupuestos");
        if (!panel.GetItems().Any(i => i.Name == "MYG_AbrirPresupuestos"))
            panel.AddItem(new PushButtonData("MYG_AbrirPresupuestos", "Presupuestos", typeof(Aplicacion).Assembly.Location,
                typeof(AbrirPresupuestos).FullName)
            { ToolTip = "Abrir MYG para editar presupuestos, ACU, especificaciones y metrados." });
        return Result.Succeeded;
    }
    private void Inicializar(object sender, Autodesk.Revit.UI.Events.IdlingEventArgs e)
    {
        if (evento != null || cierre.IsCancellationRequested) return;
        evento = ExternalEvent.Create(new Ejecutor(cola, documentos));
        receptor = new Receptor(cola, evento, cierre.Token); receptor.Iniciar();
    }
    public Result OnShutdown(UIControlledApplication app)
    {
        app.Idling -= Inicializar; cierre?.Cancel();
        while (cola.TryDequeue(out var p)) p.CancelarAntesDeIniciar();
        evento?.Dispose(); cierre?.Dispose(); return Result.Succeeded;
    }
}

internal sealed class Receptor
{
    private readonly ConcurrentQueue<OperacionPendiente> cola;
    private readonly ExternalEvent evento;
    private readonly CancellationToken cierre;
    private readonly LicenciaServicio licencia = AccesoWindows.Servicio();
    private readonly ConcurrentDictionary<string, Task<RespuestaRevit>> recibidas = new();
    private string identidadValidada;
    private long validadoTick;
    internal Receptor(ConcurrentQueue<OperacionPendiente> cola, ExternalEvent evento, CancellationToken cierre)
    { this.cola = cola; this.evento = evento; this.cierre = cierre; }
    internal void Iniciar() => _ = Task.Run(EscucharAsync);
    private static EstadoConectorRevit EstadoActual()
    {
        var ensamblado = typeof(Aplicacion).Assembly;
        return new EstadoConectorRevit
        {
            Version = ensamblado.GetName().Version?.ToString(),
            Ruta = ensamblado.Location,
            CompilacionId = ensamblado.ManifestModule.ModuleVersionId.ToString("D"),
            CapacidadIdentidad = 2,
            Pid = Environment.ProcessId
        };
    }

    private static Task EscribirRespuestaAsync(Stream destino, RespuestaRevit respuesta, CancellationToken ct)
    {
        respuesta.Conector = EstadoActual();
        return ProtocoloMYG.EscribirAsync(destino, respuesta, ct);
    }

    private async Task EscucharAsync()
    {
        while (!cierre.IsCancellationRequested)
        {
            try
            {
                using var pipe = new NamedPipeServerStream(ProtocoloMYG.Pipe(Environment.ProcessId), PipeDirection.InOut,
                    1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
                await pipe.WaitForConnectionAsync(cierre);
                using var limite = CancellationTokenSource.CreateLinkedTokenSource(cierre);
                limite.CancelAfter(TimeSpan.FromMinutes(10));
                SolicitudRevit s = null;
                try
                {
                    s = await ProtocoloMYG.LeerAsync<SolicitudRevit>(pipe, limite.Token);
                    ProtocoloMYG.Validar(s);
                    var credencial = s.Credencial;
                    if (credencial == null) throw new InvalidDataException("Inicie sesión en MYG.");
                    string identidad = credencial.Identidad();
                    if (identidad != identidadValidada || System.Diagnostics.Stopwatch.GetElapsedTime(validadoTick).TotalSeconds >= 45)
                    {
                        var acceso = await licencia.ValidarAsync(credencial, limite.Token);
                        if (!acceso.Ok)
                        { identidadValidada = null; await EscribirRespuestaAsync(pipe, RespuestaRevit.Error(s.Id, acceso.Mensaje), limite.Token); continue; }
                        if (credencial.RecordarIngreso && acceso.Token != null) AccesoWindows.GuardarAutomatico(credencial.Usuario, acceso.Token);
                        identidadValidada = identidad; validadoTick = System.Diagnostics.Stopwatch.GetTimestamp();
                    }
                    if (s.Accion == "ESTADO_CONECTOR")
                    {
                        // Autenticado, pero sin ExternalEvent ni acceso a una
                        // ventana/modelo/API nativa que pueda estar invalidado.
                        await EscribirRespuestaAsync(pipe, new() { Id = s.Id, Ok = true,
                            Mensaje = "Estado del conector disponible." }, limite.Token);
                        continue;
                    }
                    string clave = identidad + "|" + s.Id;
                    if (!recibidas.TryGetValue(clave, out var resultado))
                    {
                        var p = new OperacionPendiente(s);
                        resultado = p.Fin.Task; recibidas[clave] = resultado;
                        using var cancel = limite.Token.Register(() => p.CancelarAntesDeIniciar());
                        cola.Enqueue(p);
                        var aceptado = evento.Raise();
                        if (aceptado != ExternalEventRequest.Accepted && aceptado != ExternalEventRequest.Pending)
                            p.CancelarAntesDeIniciar();
                        var r = await resultado.WaitAsync(limite.Token);
                        await EscribirRespuestaAsync(pipe, r, limite.Token);
                    }
                    else await EscribirRespuestaAsync(pipe, await resultado.WaitAsync(limite.Token), limite.Token);
                    if (recibidas.Count > 200) foreach (var key in recibidas.Where(x => x.Value.IsCompleted).Take(100).Select(x => x.Key)) recibidas.TryRemove(key, out _);
                }
                catch (Exception ex) when (ex is InvalidDataException or System.Text.Json.JsonException)
                { await EscribirRespuestaAsync(pipe, RespuestaRevit.Error(s?.Id, "Solicitud no válida: " + ex.Message), limite.Token); }
            }
            catch (OperationCanceledException) { if (cierre.IsCancellationRequested) return; }
            catch (IOException) { }
            catch (Exception) { if (!cierre.IsCancellationRequested) await Task.Delay(500, cierre); }
        }
    }
}

internal sealed class Ejecutor : IExternalEventHandler
{
    private readonly ConcurrentQueue<OperacionPendiente> cola;
    private readonly List<(Autodesk.Revit.DB.Document Documento, string Id)> documentos;
    private readonly TablasAutomaticasExternalHandler motor = new();
    private string documentoCache;
    internal Ejecutor(ConcurrentQueue<OperacionPendiente> cola, List<(Autodesk.Revit.DB.Document Documento, string Id)> documentos)
    { this.cola = cola; this.documentos = documentos; }
    public string GetName() => "MYG Presupuestos | Conector Revit";
    public void Execute(UIApplication app)
    {
        while (cola.TryDequeue(out var p))
        {
            if (!p.Iniciar()) continue;
            try
            {
                var s = p.Solicitud;
                if ((DateTime.UtcNow - p.AutorizadoUtc).TotalSeconds > 45)
                    throw new InvalidOperationException("Revit estaba ocupado. Repita la operación para validar el acceso nuevamente.");
                // Document.GetHashCode/Equals pueden acceder al objeto nativo.
                // Quitar una clave de un Dictionary después de cerrar el modelo
                // volvía a invocar GetHashCode sobre un wrapper ya invalidado.
                // Una lista pequeña se limpia por índice, sin tocar esas claves.
                for (int n = documentos.Count - 1; n >= 0; n--)
                    if (!IdentidadDocumentoRevit.Leer("CX01 · limpieza de documentos cerrados",
                        () => DocumentoValido(documentos[n].Documento))) documentos.RemoveAt(n);
                var abiertos = IdentidadDocumentoRevit.Leer("CX02 · enumeración de modelos abiertos", () =>
                    app.Application.Documents.Cast<Autodesk.Revit.DB.Document>()
                        .Where(d => DocumentoValido(d) && !d.IsFamilyDocument && !d.IsLinked).ToList());
                string Identidad(Autodesk.Revit.DB.Document d)
                {
                    if (!DocumentoValido(d)) throw new InvalidOperationException("El modelo seleccionado ya no está disponible. Vuelva a traer la información de Revit.");
                    foreach (var registrada in documentos)
                        if (IdentidadDocumentoRevit.Leer("CX01 · comparación de documentos vivos",
                            () => MismoDocumento(registrada.Documento, d))) return registrada.Id;
                    string clave = Guid.NewGuid().ToString("N");
                    documentos.Add((d, clave)); return clave;
                }
                foreach (var abierto in abiertos) Identidad(abierto);
                if (s.Accion == "INFO" && s.SoloListarDocumentos)
                {
                    // El listado no depende de la ventana activa, que puede
                    // estar cerrándose mientras quedan otros modelos abiertos.
                    p.Completar(new() { Id = s.Id, Ok = true,
                        Documentos = abiertos.Select(d => new DocumentoRevitInfo
                        { Id = Identidad(d), Nombre = IdentidadDocumentoRevit.Leer("CX03 · título del modelo listado", () => d.Title),
                            Ruta = IdentidadDocumentoRevit.Leer("CX04 · ruta del modelo listado", () => d.PathName) }).ToList(),
                        Mensaje = "Modelos abiertos disponibles." });
                    continue;
                }
                bool consulta = s.Accion is "INFO" or "VALORES";
                // Una identidad explícita se resuelve directamente entre los
                // documentos vivos, sin leer un ActiveUIDocument potencialmente cerrado.
                var doc = consulta && !string.IsNullOrWhiteSpace(s.DocumentoId)
                    ? abiertos.SingleOrDefault(d => Identidad(d) == s.DocumentoId)
                    : IdentidadDocumentoRevit.Leer("CX05 · documento activo de Revit", () => app.ActiveUIDocument?.Document);
                if (consulta && string.IsNullOrWhiteSpace(s.DocumentoId)
                    && (ReferenceEquals(doc, null) || !abiertos.Any(d => MismoDocumento(d, doc))))
                    doc = abiertos.FirstOrDefault();
                if (ReferenceEquals(doc, null) || !DocumentoValido(doc)
                    || IdentidadDocumentoRevit.Leer("CX06 · tipo de documento seleccionado", () => doc.IsFamilyDocument))
                    throw new InvalidOperationException("El modelo seleccionado ya no está abierto. Actualice la lista y vuelva a elegirlo.");
                string id = Identidad(doc);
                if (!consulta && s.DocumentoId != id)
                    throw new InvalidOperationException("El modelo activo cambió. Active el modelo seleccionado y vuelva a conectar desde MYG.");
                if (s.Accion == "INFO")
                {
                    if (s.SoloIdentidad)
                    {
                        // Vincular un activo sólo lee sus identidades persistentes.
                        // No recorrer plantillas ni crear/copiar tablas temporales.
                        var identidad = IdentidadDocumentoRevit.Describir(doc, id);
                        if (string.IsNullOrWhiteSpace(identidad.DocumentoRevitId))
                            throw new InvalidOperationException("Revit no devolvió la identidad del modelo seleccionado. Guarde el modelo y vuelva a traer su información.");
                        p.Completar(new() { Id = s.Id, Ok = true, Documento = identidad,
                            Mensaje = "Identidad del modelo seleccionado disponible." });
                        continue;
                    }
                    IdentidadDocumentoRevit.Leer("CX07 · lectura de plantillas", () =>
                    { PlantillaParametrosRevitCache.Cargar(doc); return true; }); documentoCache = id;
                    var campos = PlantillaParametrosRevitCache.ObtenerCopia();
                    var info = IdentidadDocumentoRevit.Describir(doc, id);
                    info.Plantillas = campos.Keys.OrderBy(x => x).ToList();
                    info.Parametros = campos;
                    info.Reglas = campos.ToDictionary(x => x.Key, x => x.Value.ToDictionary(v => v, v => PlantillaParametrosRevitCache.ObtenerReglas(x.Key, v)));
                    p.Completar(new() { Id = s.Id, Ok = true, Documento = info,
                        Documentos = abiertos.Select(d => new DocumentoRevitInfo
                        { Id = Identidad(d), Nombre = IdentidadDocumentoRevit.Leer("CX03 · título del modelo listado", () => d.Title),
                            Ruta = IdentidadDocumentoRevit.Leer("CX04 · ruta del modelo listado", () => d.PathName) }).ToList(),
                        Mensaje = "Plantillas del modelo seleccionado disponibles." });
                }
                else if (s.Accion == "VALORES")
                {
                    // La caché es compartida por el conector: al alternar modelos
                    // invalidarla antes de consultar impide mezclar valores de dos archivos.
                    if (documentoCache != id) { PlantillaParametrosRevitCache.Cargar(doc); documentoCache = id; }
                    PlantillaParametrosRevitCache.CargarValores(doc, s.Plantilla, s.Parametro);
                    p.Completar(new() { Id = s.Id, Ok = true,
                        Valores = PlantillaParametrosRevitCache.ObtenerValores(s.Plantilla, s.Parametro) });
                }
                else
                {
                    if ((s.Accion is "CREAR" or "ACTUALIZAR" or "APLICAR_ACTIVO") && (doc.IsReadOnly || doc.IsModifiable))
                        throw new InvalidOperationException("El modelo no está disponible para modificar tablas en este momento.");
                    if (s.Accion == "APLICAR_ACTIVO" &&
                        !string.Equals(s.DocumentoRevitId, IdentidadDocumentoRevit.Describir(doc, id).DocumentoRevitId, StringComparison.Ordinal))
                        throw new InvalidOperationException("La identidad del modelo activo cambió. Vuelva a conectar y compruebe su vinculación con el activo.");
                    // El motor puede renovar su caché interna para el activo.
                    // No reutilizarla después como si aún perteneciera a la consulta anterior.
                    documentoCache = null;
                    p.Completar(motor.ProcesarExterno(app, s));
                }
            }
            catch (ErrorLecturaIdentidadRevit error)
            { p.Completar(RespuestaRevit.Error(p.Solicitud.Id, error.Message)); }
            catch (Autodesk.Revit.Exceptions.InvalidObjectException)
            { p.Completar(RespuestaRevit.Error(p.Solicitud.Id, "El modelo o un elemento consultado dejó de estar disponible en Revit. Actualice la lista y vuelva a elegir el modelo antes de reintentar.")); }
            catch (ObjectDisposedException)
            { p.Completar(RespuestaRevit.Error(p.Solicitud.Id, "El modelo seleccionado se cerró durante la consulta. Actualice la lista y vuelva a elegirlo.")); }
            catch (Exception ex) when (p.Solicitud.Accion == "INFO")
            { p.Completar(RespuestaRevit.Error(p.Solicitud.Id,
                new ErrorLecturaIdentidadRevit("CX08 · consulta de información del modelo", ex.GetType().FullName ?? ex.GetType().Name).Message)); }
            catch (Exception ex) { p.Completar(RespuestaRevit.Error(p.Solicitud.Id, ex.Message)); }
        }
    }

    private static bool DocumentoValido(Autodesk.Revit.DB.Document documento)
    {
        if (ReferenceEquals(documento, null)) return false;
        try { return documento.IsValidObject; }
        catch (Autodesk.Revit.Exceptions.InvalidObjectException) { return false; }
        catch (ObjectDisposedException) { return false; }
    }

    private static bool MismoDocumento(Autodesk.Revit.DB.Document primero, Autodesk.Revit.DB.Document segundo)
    {
        if (ReferenceEquals(primero, segundo)) return DocumentoValido(primero);
        if (!DocumentoValido(primero) || !DocumentoValido(segundo)) return false;
        try { return primero.Equals(segundo); }
        catch (Autodesk.Revit.Exceptions.InvalidObjectException) { return false; }
        catch (ObjectDisposedException) { return false; }
    }
}
