using Autodesk.Revit.DB;
using MYG.Externo;
using MYG_2027;

namespace MYG.Conector;

/// <summary>Identidad del modelo obtenida de Revit, independiente del nombre y de la caché local.</summary>
internal static class IdentidadDocumentoRevit
{
    internal static DocumentoRevitInfo Describir(Document documento, string sesionId)
    {
        if (ReferenceEquals(documento, null))
            throw new ErrorLecturaIdentidadRevit("ID01 · documento seleccionado", "DocumentoAusente");
        if (!Leer("ID01 · validez del documento", () => documento.IsValidObject))
            throw new ErrorLecturaIdentidadRevit("ID01 · validez del documento", "DocumentoInvalidado");
        if (string.IsNullOrWhiteSpace(sesionId))
            throw new ErrorLecturaIdentidadRevit("ID02 · apertura del documento", "SesionAusente");

        var info = new DocumentoRevitInfo
        {
            Id = sesionId,
            Nombre = Leer("ID03 · título del modelo", () => documento.Title),
            Ruta = Leer("ID04 · ruta del modelo", () => documento.PathName),
            EsColaborativo = Leer("ID05 · estado colaborativo", () => documento.IsWorkshared),
            EsModeloSeparado = Leer("ID06 · estado separado del central", () => documento.IsDetached),
            CapacidadVinculacionAutomatica = 1,
            CapacidadTablasActivos = 1,
            VersionConector = typeof(IdentidadDocumentoRevit).Assembly.GetName().Version?.ToString(),
            RutaConector = typeof(IdentidadDocumentoRevit).Assembly.Location,
            Origen = MYGOrigenActivoRevit.Local
        };
        if (Leer("ID07 · origen local o Autodesk", () => documento.IsModelInCloud))
        {
            var ruta = Leer("ID08 · ruta Autodesk", () => documento.GetCloudModelPath());
            ExigirRutaValida(ruta, "ID09 · validez de ruta Autodesk");
            var proyecto = Leer("ID10 · GUID del proyecto Autodesk", () => ruta.GetProjectGUID());
            var modelo = Leer("ID11 · GUID del modelo Autodesk", () => ruta.GetModelGUID());
            if (proyecto == Guid.Empty || modelo == Guid.Empty)
                throw new ErrorLecturaIdentidadRevit("ID12 · identidad Autodesk", "GuidAutodeskVacio");
            info.Origen = MYGOrigenActivoRevit.Autodesk;
            info.ProyectoAutodeskId = proyecto.ToString("D");
            info.ModeloAutodeskId = modelo.ToString("D");
            info.DocumentoRevitId = "autodesk:" + info.ProyectoAutodeskId + ":" + info.ModeloAutodeskId;
        }
        else
        {
            if (info.EsColaborativo && !info.EsModeloSeparado)
            {
                var rutaCentral = Leer("ID13 · ruta del modelo central", () => documento.GetWorksharingCentralModelPath());
                ExigirRutaValida(rutaCentral, "ID14 · validez de ruta central");
                info.RutaCentral = Leer("ID15 · representación de ruta central", () => ModelPathUtils.ConvertModelPathToUserVisiblePath(rutaCentral));
                if (Leer("ID16 · tipo de ruta central", () => rutaCentral.ServerPath))
                {
                    Guid central = Leer("ID17 · GUID del modelo central", () => documento.WorksharingCentralGUID);
                    if (central == Guid.Empty)
                        throw new ErrorLecturaIdentidadRevit("ID17 · GUID del modelo central", "GuidCentralVacio");
                    info.DocumentoRevitId = "local:central:" + central.ToString("D");
                    return info;
                }
            }
            Guid identificador = Leer("ID18 · GUID persistente del documento", () => documento.CreationGUID);
            if (identificador == Guid.Empty)
                throw new ErrorLecturaIdentidadRevit("ID18 · GUID persistente del documento", "GuidDocumentoVacio");
            info.DocumentoRevitId = "local:" + identificador.ToString("D");
        }
        return info;
    }

    private static void ExigirRutaValida(ModelPath ruta, string etapa)
    {
        // ReferenceEquals nunca invoca los operadores ni Equals de un wrapper nativo.
        if (ReferenceEquals(ruta, null)) throw new ErrorLecturaIdentidadRevit(etapa, "ModelPathAusente");
        if (!Leer(etapa, () => ruta.IsValidObject)) throw new ErrorLecturaIdentidadRevit(etapa, "ModelPathInvalidado");
    }

    internal static T Leer<T>(string etapa, Func<T> lectura)
    {
        try { return lectura(); }
        catch (ErrorLecturaIdentidadRevit) { throw; }
        catch (Exception error)
        {
            // Sólo etapa y tipo: el mensaje/stack original puede contener rutas,
            // información del modelo u otros datos que no necesita el usuario.
            throw new ErrorLecturaIdentidadRevit(etapa, error.GetType().FullName ?? error.GetType().Name, error);
        }
    }
}

internal sealed class ErrorLecturaIdentidadRevit : InvalidOperationException
{
    internal ErrorLecturaIdentidadRevit(string etapa, string tipo, Exception original = null)
        : base("No se pudo leer la identidad del modelo seleccionado. Etapa: " + etapa + ". Tipo: " + tipo
            + ". Mantenga abierto el modelo, actualice la lista y vuelva a seleccionarlo. Si falta su GUID, guarde el modelo antes de vincularlo.", original) { }
}
