param(
    [string]$Origen = '',
    [string]$RevitInstallDir = 'C:\Program Files\Autodesk\Revit 2027'
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'La instalacion del conector requiere Windows y Revit 2027.' }
if (Get-Process -Name Revit -ErrorAction SilentlyContinue) {
    throw 'Cierre todas las ventanas de Revit antes de actualizar el conector. Revit mantiene cargada la DLL anterior hasta reiniciar.'
}
$raiz = Split-Path -Parent $PSScriptRoot
$proyecto = Join-Path $raiz 'MYG.Revit2027\MYG.Revit2027.csproj'
$versionMinima = [Version]'1.3.0.0'
$addInId = 'F8045AE4-B3D5-49D5-9546-53024F94A289'

if ([string]::IsNullOrWhiteSpace($Origen)) {
    if (Test-Path -LiteralPath $proyecto -PathType Leaf) {
        # En el checkout siempre se compila el codigo actual. Una carpeta dist
        # o Conector antigua no debe ganar a una compilacion mas reciente.
        if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Instale el SDK .NET 10 antes de actualizar el conector.' }
        foreach ($api in @('RevitAPI.dll', 'RevitAPIUI.dll')) {
            if (!(Test-Path -LiteralPath (Join-Path $RevitInstallDir $api) -PathType Leaf)) {
                throw "Falta $api en $RevitInstallDir. Indique -RevitInstallDir con su instalacion de Revit 2027."
            }
        }
        & dotnet build $proyecto -c Release -t:Rebuild '-p:UseRevitReferencePackages=false' `
            "-p:RevitInstallDir=$RevitInstallDir" '-m:1' '-nr:false'
        if ($LASTEXITCODE -ne 0) { throw 'Fallo la compilacion. No se modifico el conector instalado.' }
        $Origen = Join-Path $raiz 'MYG.Revit2027\bin\Release\net10.0-windows'
    }
    else {
        # Conserva la instalacion desde distribuciones sin fuentes, sin decidir
        # silenciosamente entre dos carpetas de binarios diferentes.
        $candidatos = @(@((Join-Path $raiz 'Conector'), (Join-Path $raiz 'dist\Conector')) |
            Where-Object { Test-Path -LiteralPath (Join-Path $_ 'MYG.Revit2027.dll') -PathType Leaf })
        if ($candidatos.Count -ne 1) { throw 'Indique -Origen con una unica carpeta de distribucion actualizada del conector.' }
        $Origen = $candidatos[0]
    }
}
$Origen = (Resolve-Path -LiteralPath $Origen).Path
foreach ($dll in @('MYG.Revit2027.dll', 'MYG.Core.dll')) {
    if (!(Test-Path -LiteralPath (Join-Path $Origen $dll) -PathType Leaf)) { throw "Falta $dll en $Origen." }
}
# AssemblyName lee la identidad del PE sin cargar el ensamblado ni RevitAPI.
$version = [Reflection.AssemblyName]::GetAssemblyName((Join-Path $Origen 'MYG.Revit2027.dll')).Version
if ($version -lt $versionMinima) {
    throw "La carpeta indicada contiene el conector $version, anterior al contrato requerido $versionMinima. Desde las fuentes actualizadas ejecute .\scripts\Actualizar-Conector.ps1; no reinstale Conector o dist antiguos."
}

$addins = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2027'
$destino = Join-Path $addins 'MYG_Externo'
$archivo = Join-Path $addins 'MYG_Conector_Externo.addin'
if ([string]::Equals($Origen.TrimEnd('\'), $destino.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) {
    throw 'El origen es la instalacion actual. Use las fuentes actualizadas o una carpeta de distribucion distinta.'
}

# No desactivar otros complementos. Un AddInId MYG repetido puede hacer que
# Revit cargue otra DLL; se informa antes de tocar la instalacion existente.
$raicesManifiestos = @($addins)
if (![string]::IsNullOrWhiteSpace($env:PROGRAMDATA)) {
    $raicesManifiestos += Join-Path $env:PROGRAMDATA 'Autodesk\Revit\Addins\2027'
}
$duplicados = @()
foreach ($carpeta in $raicesManifiestos) {
    if (!(Test-Path -LiteralPath $carpeta -PathType Container)) { continue }
    foreach ($manifiesto in Get-ChildItem -LiteralPath $carpeta -Filter '*.addin' -File) {
        try { [xml]$xml = Get-Content -LiteralPath $manifiesto.FullName -Raw }
        catch {
            if ([string]::Equals($manifiesto.FullName, $archivo, [StringComparison]::OrdinalIgnoreCase)) {
                throw "El manifiesto existente no es XML valido y se conserva: $archivo"
            }
            continue
        }
        $entradas = @($xml.RevitAddIns.AddIn)
        $propias = @($entradas | Where-Object {
            $idRegistrado = [Guid]::Empty
            $mismoId = [Guid]::TryParse([string]$_.AddInId, [ref]$idRegistrado) -and $idRegistrado -eq [Guid]$addInId
            $mismaClase = [string]::Equals(([string]$_.FullClassName).Trim(), 'MYG.Conector.Aplicacion', [StringComparison]::Ordinal)
            $mismoEnsamblado = [string]::Equals([IO.Path]::GetFileName(([string]$_.Assembly).Trim()), 'MYG.Revit2027.dll', [StringComparison]::OrdinalIgnoreCase)
            $mismoId -or $mismaClase -or $mismoEnsamblado
        })
        if ([string]::Equals($manifiesto.FullName, $archivo, [StringComparison]::OrdinalIgnoreCase)) {
            if ($entradas.Count -ne 1 -or $propias.Count -ne 1) {
                throw "El archivo $archivo contiene registros distintos del conector MYG esperado. Se conserva sin cambios; revise su contenido antes de instalar."
            }
        }
        elseif ($propias.Count -gt 0) { $duplicados += $manifiesto.FullName }
    }
}
if ($duplicados.Count -gt 0) {
    throw ("Se encontraron otros registros del conector MYG (AddInId, clase o DLL), incluso con otro identificador. Se conservaron todos los archivos. Revise estos registros antes de instalar para evitar cargar una DLL antigua:`n" + ($duplicados -join "`n"))
}

New-Item -ItemType Directory -Force -Path $addins | Out-Null
$etapa = Join-Path $addins ('.MYG_Instalacion_' + [Guid]::NewGuid().ToString('N'))
$manifestTemporal = Join-Path $addins ('.MYG_Manifiesto_' + [Guid]::NewGuid().ToString('N') + '.tmp')
$respaldo = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) `
    ('MYG\RespaldosConector\' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
$anteriorMovido = $false
$nuevaMovida = $false
$manifestAnterior = Test-Path -LiteralPath $archivo -PathType Leaf
$manifestEscrito = $false
try {
    New-Item -ItemType Directory -Path $etapa | Out-Null
    Get-ChildItem -LiteralPath $Origen -File | Where-Object { $_.Name -notin @('RevitAPI.dll', 'RevitAPIUI.dll') } |
        Copy-Item -Destination $etapa
    if (Test-Path -LiteralPath (Join-Path $Origen 'runtimes') -PathType Container) {
        Copy-Item -LiteralPath (Join-Path $Origen 'runtimes') -Destination $etapa -Recurse
    }
    $copiados = @(Get-ChildItem -LiteralPath $etapa -File -Recurse)
    foreach ($copia in $copiados) {
        $relativa = $copia.FullName.Substring($etapa.Length).TrimStart('\')
        $original = Join-Path $Origen $relativa
        if ((Get-FileHash -LiteralPath $original -Algorithm SHA256).Hash -ne
            (Get-FileHash -LiteralPath $copia.FullName -Algorithm SHA256).Hash) {
            throw "No coincide la copia verificada de $relativa. Se conserva la instalacion anterior."
        }
    }
    New-Item -ItemType Directory -Force -Path $respaldo | Out-Null
    if ($manifestAnterior) { Copy-Item -LiteralPath $archivo -Destination (Join-Path $respaldo 'MYG_Conector_Externo.addin') }
    if (Test-Path -LiteralPath $destino -PathType Container) {
        Move-Item -LiteralPath $destino -Destination (Join-Path $respaldo 'MYG_Externo')
        $anteriorMovido = $true
    }
    Move-Item -LiteralPath $etapa -Destination $destino
    $nuevaMovida = $true
    foreach ($copia in $copiados) {
        $relativa = $copia.FullName.Substring($etapa.Length).TrimStart('\')
        if ((Get-FileHash -LiteralPath (Join-Path $Origen $relativa) -Algorithm SHA256).Hash -ne
            (Get-FileHash -LiteralPath (Join-Path $destino $relativa) -Algorithm SHA256).Hash) {
            throw "No coincide el archivo instalado $relativa."
        }
    }
    $assembly = [System.Security.SecurityElement]::Escape((Join-Path $destino 'MYG.Revit2027.dll'))
    $manifest = @"
<?xml version="1.0" encoding="utf-8"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>MYG Presupuestos - Conector Revit</Name>
    <Assembly>$assembly</Assembly>
    <AddInId>$addInId</AddInId>
    <FullClassName>MYG.Conector.Aplicacion</FullClassName>
    <VendorId>MYGB</VendorId>
    <VendorDescription>MYG Presupuestos</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
    [System.IO.File]::WriteAllText($manifestTemporal, $manifest, [System.Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $manifestTemporal -Destination $archivo -Force
    $manifestEscrito = $true
}
catch {
    # Recuperar solamente la instalacion MYG que este intento sustituyo.
    if ($nuevaMovida -and (Test-Path -LiteralPath $destino -PathType Container)) {
        Move-Item -LiteralPath $destino -Destination (Join-Path $respaldo 'InstalacionFallida')
    }
    if ($anteriorMovido) { Move-Item -LiteralPath (Join-Path $respaldo 'MYG_Externo') -Destination $destino }
    if ($manifestEscrito) {
        if ($manifestAnterior) { Copy-Item -LiteralPath (Join-Path $respaldo 'MYG_Conector_Externo.addin') -Destination $archivo -Force }
        else { Remove-Item -LiteralPath $archivo }
    }
    throw
}
finally {
    if (Test-Path -LiteralPath $etapa -PathType Container) { Remove-Item -LiteralPath $etapa -Recurse -Force }
    if (Test-Path -LiteralPath $manifestTemporal -PathType Leaf) { Remove-Item -LiteralPath $manifestTemporal -Force }
}
Write-Host "Conector instalado: $(Join-Path $destino 'MYG.Revit2027.dll')"
Write-Host "Version: $version; $($copiados.Count) archivos verificados por SHA-256."
if ($anteriorMovido -or $manifestAnterior) { Write-Host "Respaldo anterior: $respaldo" }
Write-Host 'Reinicie Revit 2027 y abra su modelo. En MYG use Tablas del modelo abierto.'
