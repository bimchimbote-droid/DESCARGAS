namespace MYG.Externo;

/// <summary>Información del ensamblado que responde al pipe, sin consultar documentos de Revit.</summary>
public sealed class EstadoConectorRevit
{
    public string Version { get; set; }
    public string Ruta { get; set; }
    public string CompilacionId { get; set; }
    public int CapacidadIdentidad { get; set; }
    public int Pid { get; set; }
}

public static class CompatibilidadConectorRevit
{
    public const string VersionMinimaIdentidad = "1.3.0";

    public static string Resumen(EstadoConectorRevit estado) => estado == null
        ? "El conector cargado no informó su versión ni su ruta."
        : $"Conector cargado: {estado.Version} · PID {estado.Pid}\nDLL: {estado.Ruta}\nCompilación: {estado.CompilacionId}";

    public static void ExigirIdentidad(EstadoConectorRevit estado, int pid)
    {
        if (estado == null || estado.Pid != pid || estado.CapacidadIdentidad < 2
            || !System.Version.TryParse(estado.Version, out var version) || version < new System.Version(1, 3, 0)
            || string.IsNullOrWhiteSpace(estado.Ruta) || !Guid.TryParse(estado.CompilacionId, out var compilacion)
            || compilacion == Guid.Empty)
            throw new InvalidDataException($"Revit (PID {pid}) no confirmó el conector {VersionMinimaIdentidad} o posterior para leer los IDs.\n"
                + Resumen(estado) + "\nCierre todas las instancias de Revit, ejecute scripts/Actualizar-Conector.ps1 desde las fuentes actualizadas y vuelva a abrir el modelo.");
    }
}
