using System;
using System.Drawing;
using MYG_2027;

internal static class FechaPaletaCheck
{
    private static readonly Color Fondo = Color.FromArgb(36, 45, 57), Texto = Color.FromArgb(231, 237, 245);
    private static readonly Color Seleccion = Color.FromArgb(119, 175, 229), TextoSeleccion = Color.FromArgb(18, 36, 59);
    private static readonly Color AzulNativo = Color.FromArgb(0, 120, 215), OtroAzulNativo = Color.FromArgb(0, 80, 180);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        const int ancho = 24, alto = 16;
        var imagen = Imagen(ancho, alto, Color.White);
        Escribir(imagen, ancho, 1, 2, Color.Black);
        Escribir(imagen, ancho, 2, 2, Color.FromArgb(127, 127, 127));
        // Estos bordes subpíxel pueden ser muy saturados. No son selecciones.
        Escribir(imagen, ancho, 3, 2, Color.FromArgb(30, 60, 170));
        Escribir(imagen, ancho, 4, 2, Color.FromArgb(170, 60, 30));
        Escribir(imagen, ancho, 6, 2, AzulNativo);
        Escribir(imagen, ancho, 8, 2, AzulNativo);
        var original = (byte[])imagen.Clone();
        Aplicar(imagen, ancho, alto);
        exige(Leer(imagen, ancho, 0, 0).ToArgb() == Fondo.ToArgb() &&
            Leer(imagen, ancho, 1, 2).ToArgb() == Texto.ToArgb(),
            "La fecha oscura debe convertir el papel y los glifos conservando sus posiciones.");
        var borde = Leer(imagen, ancho, 2, 2);
        exige(borde.R > Fondo.R && borde.R < Texto.R && borde.G > Fondo.G && borde.G < Texto.G &&
            borde.B > Fondo.B && borde.B < Texto.B,
            "Los tonos intermedios de las letras deben conservar cobertura suave entre el fondo y el texto.");
        foreach (int x in new[] { 3, 4, 6, 8 })
        {
            var color = Leer(imagen, ancho, x, 2);
            exige(color.ToArgb() != Seleccion.ToArgb() && color.B - color.R < 35,
                "Los bordes ClearType y los píxeles azules aislados deben quedar suavizados, sin motas del color de selección.");
        }
        exige(CuartosBytesIguales(original, imagen), "La traducción de colores debe conservar el cuarto byte de cada píxel.");

        imagen = Imagen(ancho, alto, Color.White);
        for (int y = 3; y < 12; y++)
            for (int x = 3; x < 13; x++) Escribir(imagen, ancho, x, y, AzulNativo);
        Escribir(imagen, ancho, 7, 6, Color.White);
        Escribir(imagen, ancho, 7, 7, Color.FromArgb(128, 188, 235));
        // Una segunda casilla usa otro color nativo, sin mezclar regiones.
        for (int y = 5; y < 11; y++)
            for (int x = 17; x < 22; x++) Escribir(imagen, ancho, x, y, OtroAzulNativo);
        Escribir(imagen, ancho, 19, 7, Color.White);
        original = (byte[])imagen.Clone();
        Aplicar(imagen, ancho, alto);
        exige(Leer(imagen, ancho, 3, 3).ToArgb() == Seleccion.ToArgb() &&
            Leer(imagen, ancho, 7, 6).ToArgb() == TextoSeleccion.ToArgb() &&
            Leer(imagen, ancho, 17, 5).ToArgb() == Seleccion.ToArgb() &&
            Leer(imagen, ancho, 19, 7).ToArgb() == TextoSeleccion.ToArgb(),
            "Los segmentos y casillas realmente rellenos deben conservar su geometría, con fondo de selección y glifos contrastados.");
        var suavizado = Leer(imagen, ancho, 7, 7);
        exige(suavizado.R > TextoSeleccion.R && suavizado.R < Seleccion.R &&
            suavizado.G > TextoSeleccion.G && suavizado.G < Seleccion.G &&
            suavizado.B > TextoSeleccion.B && suavizado.B < Seleccion.B &&
            Leer(imagen, ancho, 2, 3).ToArgb() == Fondo.ToArgb(),
            "El suavizado del segmento debe permanecer dentro de la selección, sin colorear el papel contiguo.");
        exige(CuartosBytesIguales(original, imagen), "Los segmentos seleccionados deben conservar los bytes ajenos al color.");

        var minimo = new byte[] { 255, 255, 255, 19, 11, 22, 33, 44 };
        Aplicar(minimo, 1, 1);
        exige(minimo[3] == 19 && minimo[4] == 11 && minimo[5] == 22 && minimo[6] == 33 && minimo[7] == 44,
            "La conversión de una imagen mínima debe respetar su cuarto byte y cualquier dato posterior al área declarada.");
        var vacia = Array.Empty<byte>();
        Aplicar(vacia, 0, 0);
        exige(vacia.Length == 0, "Una imagen vacía debe admitirse sin accesos fuera de límites.");
    }

    private static void Aplicar(byte[] imagen, int ancho, int alto) => MYGFechaPaletaOscura.Aplicar(imagen, ancho, alto,
        Fondo, Texto, Seleccion, TextoSeleccion, new[] { AzulNativo, OtroAzulNativo }, Color.White);

    private static byte[] Imagen(int ancho, int alto, Color color)
    {
        var imagen = new byte[ancho * alto * 4];
        for (int y = 0; y < alto; y++)
            for (int x = 0; x < ancho; x++)
            {
                Escribir(imagen, ancho, x, y, color);
                imagen[(y * ancho + x) * 4 + 3] = (byte)((y * ancho + x) % 251);
            }
        return imagen;
    }
    private static void Escribir(byte[] imagen, int ancho, int x, int y, Color color)
    {
        int i = (y * ancho + x) * 4;
        imagen[i] = color.B; imagen[i + 1] = color.G; imagen[i + 2] = color.R;
    }
    private static Color Leer(byte[] imagen, int ancho, int x, int y)
    {
        int i = (y * ancho + x) * 4;
        return Color.FromArgb(imagen[i + 2], imagen[i + 1], imagen[i]);
    }
    private static bool CuartosBytesIguales(byte[] antes, byte[] despues)
    {
        for (int i = 3; i < antes.Length; i += 4)
            if (antes[i] != despues[i]) return false;
        return true;
    }
}
