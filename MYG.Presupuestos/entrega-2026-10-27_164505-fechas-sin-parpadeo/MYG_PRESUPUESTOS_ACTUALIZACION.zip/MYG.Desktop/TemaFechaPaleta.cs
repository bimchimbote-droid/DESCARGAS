using System;
using System.Collections.Generic;
using System.Drawing;

namespace MYG_2027;

// Traduce únicamente la copia de pantalla. Los colores RGB de ClearType son
// cobertura de los glifos, no un resaltado: fuera de una selección real se
// convierten por luminancia para conservar el suavizado sin motas azules.
internal static class MYGFechaPaletaOscura
{
    private readonly record struct Seleccion(Rectangle Area, Color Fondo);

    internal static void Aplicar(byte[] pixeles, int ancho, int alto, Color fondo, Color texto,
        Color seleccion, Color textoSeleccion, Color[] fondosSeleccionNativos, Color textoSeleccionNativo)
    {
        ArgumentNullException.ThrowIfNull(pixeles);
        ArgumentNullException.ThrowIfNull(fondosSeleccionNativos);
        if (ancho < 0) throw new ArgumentOutOfRangeException(nameof(ancho));
        if (alto < 0) throw new ArgumentOutOfRangeException(nameof(alto));
        int cantidad = checked(ancho * alto);
        if (pixeles.Length < checked(cantidad * 4))
            throw new ArgumentException("La imagen no contiene todos sus píxeles.", nameof(pixeles));
        if (cantidad == 0) return;

        var regiones = BuscarSelecciones(pixeles, ancho, alto, fondosSeleccionNativos);
        for (int n = 0; n < cantidad; n++)
        {
            int i = n * 4, x = n % ancho, y = n / ancho;
            int r = pixeles[i + 2], g = pixeles[i + 1], b = pixeles[i];
            Color nuevo = Color.Empty;
            foreach (var region in regiones)
            {
                if (!region.Area.Contains(x, y)) continue;
                int dr = textoSeleccionNativo.R - region.Fondo.R;
                int dg = textoSeleccionNativo.G - region.Fondo.G;
                int db = textoSeleccionNativo.B - region.Fondo.B;
                int divisor = dr * dr + dg * dg + db * db;
                double cobertura = divisor == 0 ? 0 : Math.Clamp(
                    ((r - region.Fondo.R) * dr + (g - region.Fondo.G) * dg + (b - region.Fondo.B) * db) / (double)divisor, 0, 1);
                nuevo = Mezclar(seleccion, textoSeleccion, cobertura);
                break;
            }
            if (nuevo.IsEmpty)
            {
                double luz = (299 * r + 587 * g + 114 * b) / 255000d;
                nuevo = Mezclar(texto, fondo, luz);
            }
            pixeles[i] = nuevo.B; pixeles[i + 1] = nuevo.G; pixeles[i + 2] = nuevo.R;
            // El cuarto byte y los píxeles situados fuera de la imagen no cambian.
        }
    }

    private static Color Mezclar(Color desde, Color hasta, double proporcion) => Color.FromArgb(
        (int)Math.Round(desde.R + (hasta.R - desde.R) * proporcion),
        (int)Math.Round(desde.G + (hasta.G - desde.G) * proporcion),
        (int)Math.Round(desde.B + (hasta.B - desde.B) * proporcion));

    private static List<Seleccion> BuscarSelecciones(byte[] pixeles, int ancho, int alto, Color[] fondos)
    {
        var colores = new HashSet<int>();
        foreach (var color in fondos) colores.Add(color.ToArgb() & 0xffffff);
        var regiones = new List<Seleccion>();
        if (colores.Count == 0) return regiones;
        int cantidad = ancho * alto;
        var visitado = new bool[cantidad];
        var cola = new int[cantidad];
        int Rgb(int n) => pixeles[n * 4 + 2] << 16 | pixeles[n * 4 + 1] << 8 | pixeles[n * 4];

        for (int primero = 0; primero < cantidad; primero++)
        {
            if (visitado[primero]) continue;
            int rgb = Rgb(primero);
            if (!colores.Contains(rgb)) continue;
            int lectura = 0, escritura = 0;
            int izquierda = primero % ancho, derecha = izquierda, arriba = primero / ancho, abajo = arriba;
            visitado[primero] = true;
            cola[escritura++] = primero;
            while (lectura < escritura)
            {
                int n = cola[lectura++], x = n % ancho, y = n / ancho;
                izquierda = Math.Min(izquierda, x); derecha = Math.Max(derecha, x);
                arriba = Math.Min(arriba, y); abajo = Math.Max(abajo, y);
                void Agregar(int vecino)
                {
                    if (visitado[vecino] || Rgb(vecino) != rgb) return;
                    visitado[vecino] = true; cola[escritura++] = vecino;
                }
                if (x > 0) Agregar(n - 1);
                if (x + 1 < ancho) Agregar(n + 1);
                if (y > 0) Agregar(n - ancho);
                if (y + 1 < alto) Agregar(n + ancho);
            }
            var area = Rectangle.FromLTRB(izquierda, arriba, derecha + 1, abajo + 1);
            // Un borde RGB aislado de una letra puede coincidir con el color
            // del sistema. Exigir una superficie conectada evita confundirlo
            // con la caja rellena de un segmento o de la casilla nativa.
            if (area.Width >= 3 && area.Height >= 4 && escritura >= 6 && escritura * 5L >= (long)area.Width * area.Height)
                regiones.Add(new Seleccion(area, Color.FromArgb(255, rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255)));
        }
        return regiones;
    }
}
