using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace MYG_2027;

// Conserva los metaficheros vectoriales de impresión. La navegación cambia
// hojas completas, sin una superficie RichEdit desplazable ni bitmaps por página.
internal sealed class MYGEspecificacionesVistaPaginada : UserControl
{
    private readonly LienzoPaginas vista;
    private readonly VScrollBar desplazamiento = new()
    {
        Name = "espec_previa_desplazamiento_vertical", Dock = DockStyle.Right,
        Minimum = 1, Maximum = 1, SmallChange = 1, LargeChange = 1,
        AccessibleName = "Desplazarse por las páginas de especificaciones", Enabled = false
    };
    private readonly ToolStrip barra = new()
    {
        Name = "espec_previa_navegacion", Dock = DockStyle.Bottom,
        GripStyle = ToolStripGripStyle.Hidden, CanOverflow = true
    };
    private readonly ToolStripButton primera, anterior, siguiente, ultima, unaPagina, dosPaginas;
    private readonly ToolStripLabel contador = new()
    {
        Name = "espec_previa_contador", Text = "de 0",
        AccessibleName = "Cantidad de páginas"
    };
    private readonly ToolStripTextBox numeroPagina = new()
    {
        Name = "espec_previa_numero_pagina", Text = "0", AutoSize = false, Width = 48,
        AccessibleName = "Número de página",
        ToolTipText = "Escriba el número de página y pulse Entrar."
    };
    private readonly Label mensaje = new()
    {
        Name = "espec_previa_mensaje", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter,
        Padding = new Padding(24), Text = "No hay un documento para previsualizar.",
        AccessibleName = "Estado de la vista de páginas"
    };
    private PrintDocument documento;
    private Func<MYGEspecificacionesEntregaPaginada> prepararEntrega;
    private MYGEspecificacionesEntregaPaginada entrega;
    private PreviewPageInfo[] paginas = Array.Empty<PreviewPageInfo>();
    private int paginaActual, columnas = 1, revision;
    private long deltaRueda;
    private bool generando, programado, cerrando, actualizandoDesplazamiento;

    internal int PaginaActual => paginaActual;
    internal int CantidadPaginas => paginas.Length;
    internal Control Vista => vista;
    internal int Columnas => columnas;
    internal bool AjustarPagina => true;
    internal MYGEspecificacionesEntregaPaginada EntregaActual => entrega;

    internal MYGEspecificacionesVistaPaginada()
    {
        Name = "espec_vista_paginada";
        AccessibleName = "Vista paginada de especificaciones técnicas";
        Dock = DockStyle.Fill;
        AutoScroll = false;
        vista = new LienzoPaginas(this)
        {
            Name = "espec_previa_paginas", Dock = DockStyle.Fill, TabStop = true,
            AccessibleName = "Páginas de las especificaciones técnicas", Visible = false
        };
        primera = Boton("|◀", "primera", () => IrAPagina(1), "Primera página");
        anterior = Boton("◀ Anterior", "anterior", () => IrAPagina(paginaActual - 1), "Página anterior");
        siguiente = Boton("Siguiente ▶", "siguiente", () => IrAPagina(paginaActual + 1), "Página siguiente");
        ultima = Boton("▶|", "ultima", () => IrAPagina(paginas.Length), "Última página");
        unaPagina = Boton("Una página", "una_pagina", () => MostrarPaginas(1));
        dosPaginas = Boton("Dos páginas", "dos_paginas", () => MostrarPaginas(2));
        barra.Items.AddRange(new ToolStripItem[]
        {
            primera, anterior, new ToolStripLabel("Página"), numeroPagina, contador,
            siguiente, ultima, new ToolStripSeparator(), unaPagina, dosPaginas
        });
        numeroPagina.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { IrANumeroEscrito(); e.SuppressKeyPress = true; }
            else if (e.KeyCode == Keys.Escape) { ActualizarNavegacion(); e.SuppressKeyPress = true; }
        };
        numeroPagina.Leave += (_, _) => IrANumeroEscrito();
        desplazamiento.ValueChanged += (_, _) =>
        {
            if (!actualizandoDesplazamiento) IrAPagina(desplazamiento.Value);
        };
        var cuerpo = new Panel { Dock = DockStyle.Fill, Name = "espec_previa_superficie" };
        cuerpo.Controls.Add(vista);
        cuerpo.Controls.Add(mensaje);
        cuerpo.Controls.Add(desplazamiento);
        Controls.Add(cuerpo);
        Controls.Add(barra);
        HandleCreated += (_, _) => ProgramarGeneracion();
        VisibleChanged += (_, _) => ProgramarGeneracion();
        MYG2027_TemaComercial.CambioTema += CambioTema;
        AplicarTema();
        ActualizarNavegacion();
    }

    private static ToolStripButton Boton(string texto, string nombre, Action ejecutar, string nombreAccesible = null)
    {
        var boton = new ToolStripButton(texto)
        {
            Name = "espec_previa_" + nombre, DisplayStyle = ToolStripItemDisplayStyle.Text,
            AccessibleName = nombreAccesible ?? texto, ToolTipText = nombreAccesible ?? texto, AutoToolTip = false
        };
        boton.Click += (_, _) => ejecutar();
        return boton;
    }

    // El control toma propiedad del PrintDocument y de su copia de impresión.
    internal void Cargar(PrintDocument nuevo)
    {
        ArgumentNullException.ThrowIfNull(nuevo);
        if (IsDisposed || cerrando) throw new ObjectDisposedException(nameof(MYGEspecificacionesVistaPaginada));
        if (!ReferenceEquals(documento, nuevo))
        {
            LiberarDocumento();
            documento = nuevo;
        }
        else
        {
            revision++;
            programado = false;
            LiberarPaginas();
        }
        prepararEntrega = null;
        PrepararVisual();
    }

    internal void Cargar(Func<MYGEspecificacionesEntregaPaginada> preparar)
    {
        ArgumentNullException.ThrowIfNull(preparar);
        if (IsDisposed || cerrando) throw new ObjectDisposedException(nameof(MYGEspecificacionesVistaPaginada));
        LiberarDocumento();
        prepararEntrega = preparar;
        PrepararVisual();
    }

    private void PrepararVisual()
    {
        paginaActual = 0;
        deltaRueda = 0;
        vista.Visible = false;
        mensaje.Text = "Preparando documento…";
        mensaje.AccessibleDescription = mensaje.Text;
        mensaje.Visible = true;
        ActualizarNavegacion();
        ProgramarGeneracion();
    }

    private void ProgramarGeneracion()
    {
        if (cerrando || IsDisposed || Disposing || !IsHandleCreated || !Visible ||
            (documento == null && prepararEntrega == null) || paginas.Length > 0 || generando || programado) return;
        int version = revision;
        programado = true;
        try
        {
            BeginInvoke(new Action(() =>
            {
                if (cerrando || IsDisposed || Disposing || revision != version) return;
                programado = false;
                if (!Visible) return;
                if (prepararEntrega != null) GenerarEntrega(prepararEntrega, version);
                else if (documento != null) GenerarPaginas(documento, version);
            }));
        }
        catch (InvalidOperationException) when (IsDisposed || Disposing || !IsHandleCreated)
        { programado = false; }
    }

    // Guardar usa el mismo archivo que ya se paginó. Si su generación estaba
    // pendiente, completarla aquí invalida el callback previo, sin otro hilo STA.
    internal bool PrepararEntregaAhora()
    {
        if (cerrando || IsDisposed || Disposing || prepararEntrega == null || generando) return false;
        if (entrega != null) return true;
        revision++;
        programado = false;
        GenerarEntrega(prepararEntrega, revision);
        return entrega != null;
    }

    private void GenerarEntrega(Func<MYGEspecificacionesEntregaPaginada> preparar, int version)
    {
        if (generando || version != revision || !ReferenceEquals(preparar, prepararEntrega)) return;
        generando = true;
        MYGEspecificacionesEntregaPaginada generada = null;
        Exception fallo = null;
        try
        {
            generada = preparar();
            if (generada?.Paginas == null || generada.Paginas.Length == 0)
                throw new InvalidOperationException("El documento no contiene páginas para mostrar.");
        }
        catch (Exception ex) when (ex is not OutOfMemoryException) { fallo = ex; }
        finally { generando = false; }

        if (cerrando || IsDisposed || version != revision || !ReferenceEquals(preparar, prepararEntrega))
        {
            generada?.Dispose();
            ProgramarGeneracion();
            return;
        }
        if (fallo != null)
        {
            generada?.Dispose();
            MostrarError("No se pudo preparar el documento. " + fallo.Message);
            return;
        }
        entrega = generada;
        paginas = generada.Paginas;
        MostrarPaginasGeneradas();
    }

    private void GenerarPaginas(PrintDocument actual, int version)
    {
        if (generando || version != revision || !ReferenceEquals(actual, documento)) return;
        generando = true;
        var controlador = new PreviewPrintController { UseAntiAlias = true };
        PrintController anteriorControlador = actual.PrintController;
        PreviewPageInfo[] generadas = Array.Empty<PreviewPageInfo>();
        Exception fallo = null;
        try
        {
            if (!actual.PrinterSettings.IsValid) throw new InvalidPrinterException(actual.PrinterSettings);
            // Sólo genera EMF en memoria: nunca envía trabajos al dispositivo.
            actual.PrintController = controlador;
            actual.Print();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException) { fallo = ex; }
        finally
        {
            actual.PrintController = anteriorControlador;
            generadas = controlador.GetPreviewPageInfo();
            generando = false;
        }

        if (cerrando || IsDisposed || version != revision || !ReferenceEquals(actual, documento))
        {
            LiberarImagenes(generadas);
            ProgramarGeneracion();
            return;
        }
        if (fallo != null || generadas.Length == 0)
        {
            LiberarImagenes(generadas);
            MostrarError(fallo is InvalidPrinterException
                ? "No hay una impresora disponible para preparar las páginas. Configure una impresora en Windows, por ejemplo Microsoft Print to PDF."
                : fallo != null ? "No se pudo generar el documento paginado. " + fallo.Message
                : "El documento no contiene páginas para mostrar.");
            return;
        }
        paginas = generadas;
        MostrarPaginasGeneradas();
    }

    private void MostrarPaginasGeneradas()
    {
        paginaActual = 1;
        mensaje.Visible = false;
        vista.Visible = true;
        vista.Invalidate();
        ActualizarNavegacion();
    }

    internal void LiberarDocumento()
    {
        revision++;
        programado = false;
        var anteriorDocumento = documento;
        documento = null;
        prepararEntrega = null;
        LiberarPaginas();
        paginaActual = 0;
        deltaRueda = 0;
        anteriorDocumento?.Dispose();
        if (!cerrando)
        {
            vista.Visible = false;
            mensaje.Text = "No hay un documento para previsualizar.";
            mensaje.Visible = true;
            ActualizarNavegacion();
        }
    }

    private void LiberarPaginas()
    {
        var anteriores = paginas;
        paginas = Array.Empty<PreviewPageInfo>();
        var anteriorEntrega = entrega;
        entrega = null;
        if (anteriorEntrega != null) anteriorEntrega.Dispose();
        else LiberarImagenes(anteriores);
        vista.Invalidate();
    }

    private static void LiberarImagenes(PreviewPageInfo[] imagenes)
    {
        foreach (var pagina in imagenes) pagina.Image?.Dispose();
    }

    internal void MostrarError(string texto)
    {
        if (IsDisposed || cerrando) return;
        LiberarDocumento();
        mensaje.Text = string.IsNullOrWhiteSpace(texto) ? "No se pudo generar la vista de páginas." : texto;
        mensaje.AccessibleDescription = mensaje.Text;
        mensaje.Visible = true;
        mensaje.BringToFront();
    }

    internal void IrAPagina(int pagina)
    {
        if (paginas.Length == 0 || IsDisposed || cerrando) return;
        paginaActual = Math.Clamp(pagina, 1, paginas.Length);
        vista.Invalidate();
        ActualizarNavegacion();
    }

    internal void NavegarRueda(int delta)
    {
        if (delta == 0 || paginas.Length == 0) return;
        // Acumular fracciones evita saltos por cada evento de un trackpad.
        // El resto queda entre -119 y 119; long evita overflow en deltas extremos.
        deltaRueda += delta;
        long pasos = deltaRueda / 120;
        deltaRueda %= 120;
        if (pasos == 0) return;
        IrAPagina((int)Math.Clamp(paginaActual - pasos, 1, paginas.Length));
    }

    private void NavegarTecla(Keys tecla)
    {
        if (tecla == Keys.Home) IrAPagina(1);
        else if (tecla == Keys.End) IrAPagina(paginas.Length);
        else IrAPagina(paginaActual + (tecla is Keys.PageUp or Keys.Left or Keys.Up ? -1 : 1));
    }

    private static bool EsNavegacion(Keys tecla) => tecla is Keys.PageUp or Keys.PageDown or Keys.Home or Keys.End
        or Keys.Left or Keys.Right or Keys.Up or Keys.Down;

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (numeroPagina.TextBox.Focused) return base.ProcessCmdKey(ref msg, keyData);
        if (EsNavegacion(keyData)) { NavegarTecla(keyData); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }

    private void MostrarPaginas(int cantidad)
    {
        columnas = cantidad;
        vista.Invalidate();
        ActualizarNavegacion();
    }

    private void IrANumeroEscrito()
    {
        if (int.TryParse(numeroPagina.Text, out int pagina)) IrAPagina(pagina);
        ActualizarNavegacion();
    }

    private void ActualizarNavegacion()
    {
        numeroPagina.Text = paginaActual.ToString();
        numeroPagina.Enabled = paginas.Length > 0;
        contador.Text = "de " + paginas.Length;
        contador.AccessibleDescription = "Página " + paginaActual + " de " + paginas.Length;
        primera.Enabled = anterior.Enabled = paginaActual > 1;
        siguiente.Enabled = ultima.Enabled = paginaActual > 0 && paginaActual < paginas.Length;
        unaPagina.Enabled = dosPaginas.Enabled = paginas.Length > 0;
        actualizandoDesplazamiento = true;
        try
        {
            // Maximum incluye LargeChange - 1 para que el último valor
            // alcanzable con el pulgar sea exactamente la última página.
            int visibles = Math.Max(1, Math.Min(columnas, paginas.Length));
            desplazamiento.LargeChange = visibles;
            desplazamiento.Maximum = Math.Max(1, paginas.Length + visibles - 1);
            desplazamiento.Value = Math.Max(1, paginaActual);
            desplazamiento.Enabled = paginas.Length > 1;
            desplazamiento.AccessibleDescription = contador.AccessibleDescription;
        }
        finally { actualizandoDesplazamiento = false; }
    }

    internal RectangleF[] ObtenerRectangulosPaginas(Size tamano)
    {
        if (paginas.Length == 0 || paginaActual == 0) return Array.Empty<RectangleF>();
        int visibles = Math.Min(columnas, paginas.Length - paginaActual + 1);
        float margen = 24 * vista.DeviceDpi / 96f, separacion = 12 * vista.DeviceDpi / 96f;
        float anchoDisponible = Math.Max(1, tamano.Width - 2 * margen - separacion * (visibles - 1));
        float altoDisponible = Math.Max(1, tamano.Height - 2 * margen);
        float anchoPapel = 0, altoPapel = 1;
        for (int i = 0; i < visibles; i++)
        {
            var papel = paginas[paginaActual - 1 + i].PhysicalSize;
            anchoPapel += Math.Max(1, papel.Width);
            altoPapel = Math.Max(altoPapel, papel.Height);
        }
        float factor = Math.Min(anchoDisponible / anchoPapel, altoDisponible / altoPapel);
        float anchoGrupo = anchoPapel * factor + separacion * (visibles - 1);
        float x = (tamano.Width - anchoGrupo) / 2;
        var hojas = new RectangleF[visibles];
        for (int i = 0; i < visibles; i++)
        {
            var papel = paginas[paginaActual - 1 + i].PhysicalSize;
            float anchura = Math.Max(1, papel.Width) * factor;
            float altura = Math.Max(1, papel.Height) * factor;
            hojas[i] = new RectangleF(x, (tamano.Height - altura) / 2, anchura, altura);
            x += anchura + separacion;
        }
        return hojas;
    }

    private void DibujarPaginas(Graphics g, Size tamano)
    {
        var hojas = ObtenerRectangulosPaginas(tamano);
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        using var sombra = new SolidBrush(Color.FromArgb(48, Color.Black));
        using var borde = new Pen(MYG2027_TemaComercial.Borde);
        for (int i = 0; i < hojas.Length; i++)
        {
            var pagina = paginas[paginaActual - 1 + i];
            var hoja = hojas[i];
            g.FillRectangle(sombra, hoja.X + 3, hoja.Y + 3, hoja.Width, hoja.Height);
            g.FillRectangle(Brushes.White, hoja);
            g.DrawImage(pagina.Image, hoja);
            g.DrawRectangle(borde, hoja.X, hoja.Y, hoja.Width, hoja.Height);
        }
    }

    private void ErrorDibujo(Exception error)
    {
        int version = revision;
        if (!IsHandleCreated || cerrando || IsDisposed) return;
        try
        {
            BeginInvoke(new Action(() =>
            {
                if (!cerrando && !IsDisposed && version == revision)
                    MostrarError("No se pudo mostrar el documento paginado. " + error.Message);
            }));
        }
        catch (InvalidOperationException) when (IsDisposed || Disposing || !IsHandleCreated) { }
    }

    private void CambioTema(object sender, EventArgs e) => AplicarTema();

    private void AplicarTema()
    {
        BackColor = vista.BackColor = MYG2027_TemaComercial.Fondo;
        ForeColor = mensaje.ForeColor = barra.ForeColor = MYG2027_TemaComercial.Texto;
        mensaje.BackColor = barra.BackColor = MYG2027_TemaComercial.Superficie;
        vista.Invalidate();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && !cerrando)
        {
            cerrando = true;
            MYG2027_TemaComercial.CambioTema -= CambioTema;
            LiberarDocumento();
        }
        base.Dispose(disposing);
    }

    private sealed class LienzoPaginas : Control
    {
        private readonly MYGEspecificacionesVistaPaginada propietario;

        internal LienzoPaginas(MYGEspecificacionesVistaPaginada propietario)
        {
            this.propietario = propietario;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            ResizeRedraw = true;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        { Focus(); base.OnMouseDown(e); }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            if (CanFocus) Focus();
            propietario.NavegarRueda(e.Delta);
            if (e is HandledMouseEventArgs manejado) manejado.Handled = true;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (EsNavegacion(keyData)) { propietario.NavegarTecla(keyData); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            try { propietario.DibujarPaginas(e.Graphics, ClientSize); }
            catch (Exception ex) when (ex is not OutOfMemoryException) { propietario.ErrorDibujo(ex); }
        }
    }
}
