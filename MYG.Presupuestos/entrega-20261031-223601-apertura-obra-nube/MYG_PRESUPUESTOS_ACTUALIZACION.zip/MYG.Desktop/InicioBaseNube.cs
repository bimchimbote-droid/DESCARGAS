#nullable enable
using System.IO;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    // El índice es una instantánea privada. Cada editor trabaja con la copia
    // independiente de su obra y con sus propios permisos y revisiones.
    private sealed record IndiceBaseNube(Guid BaseId, string Servidor, string Usuario);
    private IReadOnlyList<ObraBaseNube> obrasBaseNube = Array.Empty<ObraBaseNube>();
    private string? rutaIndiceBaseNube;
    private static string RutaIndice(string ruta) => ruta + ".base-nube.json";
    private static bool EsIndiceBaseNube(string? ruta) => !string.IsNullOrWhiteSpace(ruta) && File.Exists(RutaIndice(ruta));

    private ArchivoPublicacionBasePendiente PublicacionesBaseDe(ClienteSupabase cliente) => new(
        Path.Combine(CarpetaNube, "publicaciones-bases"), cliente.UrlServidor, cliente.UsuarioId!);

    private async Task<bool> GestionarPublicacionBasePendienteAsync(ClienteSupabase cliente)
    {
        var almacen = PublicacionesBaseDe(cliente);
        var pendiente = await Task.Run(almacen.Consultar);
        ComprobarClienteActual(cliente);
        if (pendiente is null) return false;
        var opcion = WinForms.MessageBox.Show(ventanaNube,
            "Importación pendiente: " + pendiente.Nombre + " (" + pendiente.Obras + " obras).\n\n"
            + "Sí: continuar sin duplicar las obras confirmadas.\nNo: retirar el intento y conservar las copias.\nCancelar: mantenerlo pendiente.",
            "Importación de base", WinForms.MessageBoxButtons.YesNoCancel, WinForms.MessageBoxIcon.Information);
        ComprobarClienteActual(cliente);
        if (opcion == WinForms.DialogResult.Yes) await EnviarBasePendienteAsync(cliente, almacen);
        else if (opcion == WinForms.DialogResult.No)
        {
            string carpeta = await Task.Run(() => almacen.Retirar(pendiente));
            WinForms.MessageBox.Show(ventanaNube, "Copias conservadas en:\n" + carpeta, "Nube MYG");
        }
        return true;
    }

    private async Task<ProyectoSqliteNube?> ImportarBaseNubeAsync(ClienteSupabase cliente, string nombre,
        MYGProyectoDocumento principal, string ruta)
    {
        if (!await cliente.AdmiteBasesAsync())
            throw new NubeException("Instale 20261101_bases_obras.sql en Supabase antes de importar una base con permisos por obra.");
        ComprobarClienteActual(cliente);
        var almacen = PublicacionesBaseDe(cliente);
        await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Preparando la base y sus obras…",
            progreso => Task.Run(() => almacen.Crear(nombre, principal, ruta, progreso: progreso)));
        ComprobarClienteActual(cliente);
        return await EnviarBasePendienteAsync(cliente, almacen);
    }

    private async Task<ProyectoSqliteNube?> EnviarBasePendienteAsync(ClienteSupabase cliente, ArchivoPublicacionBasePendiente almacen)
    {
        var ventana = ventanaNube ?? throw new InvalidOperationException("Abra Nube MYG antes de importar.");
        var ct = ventana.ComenzarPublicacion();
        bool confirmada = false;
        try
        {
            var progreso = new Progress<string>(texto =>
            {
                if (!ventana.IsDisposed && !confirmada && !ct.IsCancellationRequested)
                    ventana.InformarProgresoPublicacion(texto);
            });
            var remoto = await Task.Run(() => almacen.EnviarAsync(cliente, ct, progreso), ct);
            confirmada = true;
            ventana.PublicacionConfirmada();
            ComprobarClienteActual(cliente);
            await ventana.MostrarPublicacionConfirmadaAsync(remoto.Proyecto);
            return remoto;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested && !confirmada)
        {
            ventana.InformarResultadoPublicacion("Se conserva el intento de base. Continúe desde Publicaciones pendientes; no se duplicarán las obras ya vinculadas.");
        }
        finally { ventana.TerminarPublicacion(); }
        return null;
    }

    private async Task AbrirBaseNubeAsync(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        if (remoto.Proyecto.Rol != "propietario")
            throw new InvalidOperationException("El respaldo completo es privado. Abra las obras compartidas con su cuenta.");
        var obras = await cliente.ListarObrasBaseAsync(remoto.Proyecto.Id);
        ComprobarClienteActual(cliente);
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Proyecto.Id);
        string ruta = Path.Combine(carpeta, "base-r" + remoto.Proyecto.Revision + ".sqlite");
        await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Abriendo todas las obras de la base…", async progreso =>
        {
            Directory.CreateDirectory(carpeta);
            if (!File.Exists(ruta))
                await cliente.DescargarSqliteAsync(remoto, ruta, progreso: progreso);
            // Validar el archivo antes de registrar el índice; no modifica el SQLite.
            await Task.Run(() => MYGBaseDatos.ListarProyectos(ruta));
            return true;
        });
        ComprobarClienteActual(cliente);
        string metadatos = RutaIndice(ruta);
        var indice = new IndiceBaseNube(remoto.Proyecto.Id, cliente.UrlServidor, cliente.UsuarioId!);
        string temporal = metadatos + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            await File.WriteAllTextAsync(temporal, JsonSerializer.Serialize(indice));
            File.Move(temporal, metadatos, true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
        obrasBaseNube = obras; rutaIndiceBaseNube = ruta;
        await CargarBase(ruta);
        ventanaNube?.Hide();
    }

    private async Task PrepararIndiceBaseNubeAsync(string ruta)
    {
        if (!EsIndiceBaseNube(ruta))
        {
            obrasBaseNube = Array.Empty<ObraBaseNube>(); rutaIndiceBaseNube = null;
            return;
        }
        var indice = JsonSerializer.Deserialize<IndiceBaseNube>(await File.ReadAllTextAsync(RutaIndice(ruta)))
            ?? throw new InvalidDataException("No se pudo leer el vínculo de la base. Se conserva su copia.");
        if (clienteNube?.SesionIniciada != true) await MostrarNubeAsync();
        var cliente = RequerirNube();
        if (indice.Usuario != cliente.UsuarioId || !string.Equals(indice.Servidor.TrimEnd('/'),
            cliente.UrlServidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Abra la base con la misma cuenta y servidor que la descargaron.");
        obrasBaseNube = await cliente.ListarObrasBaseAsync(indice.BaseId);
        ComprobarClienteActual(cliente);
        rutaIndiceBaseNube = Path.GetFullPath(ruta);
        ventanaNube?.Hide();
    }

    private async Task<EditorForm> AbrirObraBaseNubeAsync(string ruta, string documentoId)
    {
        if (!MismaRuta(ruta, rutaIndiceBaseNube)) await PrepararIndiceBaseNubeAsync(ruta);
        var obra = obrasBaseNube.SingleOrDefault(o => o.DocumentoId == documentoId)
            ?? throw new InvalidOperationException("Esta obra aún no está vinculada. Complete la importación desde Publicaciones pendientes. Para bases antiguas, vuelva a importar con la opción Base completa.");
        var cliente = RequerirNube();
        await AbrirProyectoNube(obra.Proyecto);
        ComprobarClienteActual(cliente);
        return EditoresAbiertos.First(e => e.NubeProyectoId == obra.Proyecto.Id
            && e.NubeUsuario == cliente.UsuarioId && string.Equals(e.NubeServidor?.TrimEnd('/'),
                cliente.UrlServidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase));
    }

    private void ExigirBaseLocalEditable()
    {
        if (EsIndiceBaseNube(rutaBase))
            throw new InvalidOperationException("La base mostrada es el índice privado de la importación. Abra una obra para editarla y sincronizarla. Para cambiar los catálogos globales o agregar obras, use la base local original e importe una nueva versión.");
    }

    private void MenuObraNube(object? sender, WinForms.DataGridViewCellEventArgs e)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        if (e.RowIndex < 0 || e.ColumnIndex < 0 || proyectos.Columns[e.ColumnIndex].Name != "NUBE_OBRA") return;
        proyectos.CurrentCell = proyectos.Rows[e.RowIndex].Cells[0];
        var obra = proyectos.Rows[e.RowIndex].Tag as MYGProyectoResumen;
        if (obra is null) return;
        string ruta = rutaBase;
        var menu = new WinForms.ContextMenuStrip { Name = "menuObraNube" };
        var abrirObra = menu.Items.Add("Abrir obra");
        abrirObra.Click += (_, _) => EjecutarDesdeMenuObraNube(async () => { await CargarYAbrirProyectoAsync(ruta, obra.Id); });
        var compartir = menu.Items.Add(EsIndiceBaseNube(ruta) ? "Colaboradores y permisos de esta obra…" : "Importar base y compartir esta obra…");
        compartir.Click += (_, _) => EjecutarDesdeMenuObraNube(() => ColaboracionObraBaseAsync(ruta, obra.Id));
        MostrarMenuObraNube(menu);
    }

    private void EjecutarDesdeMenuObraNube(Func<Task> accion)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        // Completar el clic antes de abrir cargas o diálogos que procesan mensajes.
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing) return;
            await IntentarAsync(accion);
        }));
    }

    private void MostrarMenuObraNube(WinForms.ContextMenuStrip menu)
    {
        componentesMenusInicio.Add(menu);
        menu.Closed += (_, _) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated || menu.IsDisposed) return;
            // Closed todavía pertenece al cierre interno de WinForms. Liberar
            // después desde Inicio, que también conserva los menús abiertos.
            BeginInvoke(new Action(() =>
            {
                if (!menu.IsDisposed && !menu.Disposing) menu.Dispose();
            }));
        };
        menu.Show(proyectos, proyectos.PointToClient(WinForms.Cursor.Position));
    }

    private async Task ColaboracionObraBaseAsync(string ruta, string documentoId)
    {
        await MostrarNubeAsync();
        var cliente = RequerirNube();
        if (!EsIndiceBaseNube(ruta))
        {
            if (WinForms.MessageBox.Show(ventanaNube,
                "Se importará una copia privada de TODA la base y una copia independiente de cada obra.\n"
                + "Después podrá dar acceso solo a las obras elegidas y configurar sus restricciones. El original se conserva.\n\n¿Continuar?",
                "Importar base completa", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Information) != WinForms.DialogResult.OK) return;
            if (await GestionarPublicacionBasePendienteAsync(cliente)) return;
            var principal = await Task.Run(() => MYGBaseDatos.LeerProyecto(ruta, documentoId));
            var remoto = await ImportarBaseNubeAsync(cliente, Path.GetFileNameWithoutExtension(ruta), principal, ruta);
            if (remoto is null) return;
            await AbrirBaseNubeAsync(cliente, remoto);
            var publicada = obrasBaseNube.Single(o => o.DocumentoId == documentoId);
            await MostrarColaboracionObraAsync(publicada.Proyecto.Id);
            return;
        }
        if (!MismaRuta(ruta, rutaIndiceBaseNube)) await PrepararIndiceBaseNubeAsync(ruta);
        var obra = obrasBaseNube.SingleOrDefault(o => o.DocumentoId == documentoId)
            ?? throw new InvalidOperationException("Complete primero la importación de esta obra en Publicaciones pendientes.");
        await MostrarColaboracionObraAsync(obra.Proyecto.Id);
    }

    private async Task MostrarColaboracionObraAsync(Guid id)
    {
        await MostrarNubeAsync();
        await ventanaNube!.SeleccionarProyectoAsync(id);
        ventanaNube.Show(this); ventanaNube.Activate();
    }
}
