#nullable enable
using System;
using System.Globalization;
using MYG.Colaboracion;

namespace MYG_2027;

internal static class ExploradorNubePresentacion
{
    internal static string TipoProyecto(ProyectoNube proyecto) => proyecto.Alcance == "base"
        ? "Base privada" : "Obra";

    internal static bool PuedeEliminarBase(ProyectoNube? proyecto) =>
        proyecto is { Alcance: "base", Rol: "propietario" };

    internal static bool ConfirmarNombreBase(string nombre, string confirmacion, bool entiendeAlcance) =>
        entiendeAlcance && !string.IsNullOrWhiteSpace(nombre)
        && string.Equals(nombre.Trim(), confirmacion.Trim(), StringComparison.Ordinal);

    internal static string FormatearSincronizacion(DateTimeOffset? actualizado,
        CultureInfo? cultura = null, TimeZoneInfo? zona = null) => actualizado.HasValue
        ? TimeZoneInfo.ConvertTime(actualizado.Value, zona ?? TimeZoneInfo.Local)
            .ToString("g", cultura ?? CultureInfo.CurrentCulture)
        : "No disponible";
}
