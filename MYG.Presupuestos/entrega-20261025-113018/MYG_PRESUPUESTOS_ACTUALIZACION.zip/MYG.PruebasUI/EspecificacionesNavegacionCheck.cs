using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using MYG_2027;

internal static class EspecificacionesNavegacionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        using var host = new Form { ClientSize = new Size(1600, 800), ShowInTaskbar = false };
        using var vista = new MYGEspecificacionesVistaPaginada { Dock = DockStyle.Fill };
        host.Controls.Add(vista);
        host.Show();
        var desplazamiento = Controles(vista).OfType<VScrollBar>().Single();
        exige(desplazamiento.Dock == DockStyle.Right && desplazamiento.Visible && !desplazamiento.Enabled,
            "La vista vacía debe mostrar la barra vertical a la derecha deshabilitada, sin depender de una impresora ni de Word.");

        int generaciones = 0;
        vista.Cargar(() => { generaciones++; return EntregaSintetica(5); });
        exige(vista.PrepararEntregaAhora(), "La entrega sintética debe cargarse sin llamar a Word ni imprimir.");
        Application.DoEvents();
        var entrega = vista.EntregaActual;
        var botones = Controles(vista).OfType<ToolStrip>().SelectMany(x => x.Items.OfType<ToolStripButton>())
            .ToDictionary(x => x.Name);
        exige(desplazamiento.Enabled && desplazamiento.Minimum == 1 && desplazamiento.Value == 1 &&
                desplazamiento.Maximum - desplazamiento.LargeChange + 1 == 5,
            "La barra debe abarcar desde la primera hasta la última página real.");

        botones["espec_previa_dos_paginas"].PerformClick();
        var hojas = vista.ObtenerRectangulosPaginas(new Size(1600, 800));
        float separacion = 12 * vista.Vista.DeviceDpi / 96f;
        exige(hojas.Length == 2 && Math.Abs(hojas[1].Left - hojas[0].Right - separacion) < .05f &&
                Math.Abs((hojas[0].Left + hojas[1].Right) / 2 - 800) < .05f &&
                Math.Abs(hojas[0].Width - hojas[1].Width) < .05f,
            "Las dos páginas A4 deben formar un grupo centrado con sólo 12 píxeles de separación ajustados al DPI.");
        exige(desplazamiento.LargeChange == 2 && desplazamiento.Maximum - desplazamiento.LargeChange + 1 == 5,
            "En dos páginas la barra debe conservar acceso a la última y representar dos hojas en su salto grande.");

        desplazamiento.Value = 4;
        exige(vista.PaginaActual == 4 && vista.Columnas == 2 && ReferenceEquals(vista.EntregaActual, entrega) && generaciones == 1,
            "Arrastrar la barra debe cambiar la página conservando las dos columnas y la misma entrega generada.");
        vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 5 && desplazamiento.Value == 5 && vista.ObtenerRectangulosPaginas(new Size(1600, 800)).Length == 1,
            "La rueda debe sincronizar la barra y permitir la última página sin pedir una hoja inexistente.");
        botones["espec_previa_anterior"].PerformClick();
        exige(vista.PaginaActual == 4 && desplazamiento.Value == 4,
            "Las flechas inferiores deben actualizar la misma barra de navegación.");
        vista.IrAPagina(int.MinValue);
        vista.NavegarRueda(SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 1 && desplazamiento.Value == 1,
            "La selección directa y la rueda deben respetar el límite inicial de la barra.");
        vista.IrAPagina(int.MaxValue);
        vista.NavegarRueda(-SystemInformation.MouseWheelScrollDelta);
        exige(vista.PaginaActual == 5 && desplazamiento.Value == 5 && generaciones == 1,
            "La selección directa y la rueda deben respetar el límite final sin regenerar páginas.");

        botones["espec_previa_una_pagina"].PerformClick();
        exige(desplazamiento.LargeChange == 1 && desplazamiento.Value == 5 &&
                desplazamiento.Maximum - desplazamiento.LargeChange + 1 == 5,
            "Volver a una página debe conservar la posición y ajustar el rango del pulgar.");
        host.ClientSize = new Size(700, 500);
        var unica = vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize).Single();
        exige(unica.Left >= 0 && unica.Top >= 0 && unica.Right <= vista.Vista.ClientSize.Width &&
                unica.Bottom <= vista.Vista.ClientSize.Height && generaciones == 1,
            "Redimensionar debe mantener la página dentro de la vista sin volver a generar la entrega.");

        VerificarZoom(vista, botones, exige);
        exige(vista.CantidadPaginas == 5 && ReferenceEquals(vista.EntregaActual, entrega) && generaciones == 1,
            "Acercar, alejar, recorrer la hoja ampliada y ajustar columnas deben reutilizar la misma entrega y conservar su paginación.");

        string temporal = entrega.RutaArchivo;
        vista.LiberarDocumento();
        exige(!desplazamiento.Enabled && desplazamiento.Value == 1 && desplazamiento.Maximum == 1 &&
                vista.PaginaActual == 0 && vista.CantidadPaginas == 0 && !File.Exists(temporal),
            "Liberar la entrega debe restablecer la barra y retirar sus páginas y temporal.");
        vista.Cargar(() => EntregaSintetica(1));
        exige(vista.PrepararEntregaAhora() && !desplazamiento.Enabled && desplazamiento.Value == 1,
            "Un documento de una sola página debe mostrarse sin habilitar desplazamientos inexistentes.");
        vista.CambiarZoomRueda(int.MinValue, Point.Empty);
        exige(vista.Columnas == 1 && vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize).Length == 1 &&
                Math.Abs(vista.Zoom - .1) < .0001,
            "Alejar un documento de una sola página debe respetar el mínimo del 10% sin crear una segunda hoja vacía.");
        vista.MostrarError("Error de prueba");
        exige(!desplazamiento.Enabled && vista.CantidadPaginas == 0 && vista.PaginaActual == 0,
            "Un error debe vaciar la vista y deshabilitar la barra, sin dejar páginas anteriores visibles.");
        host.Close();
    }

    private static void VerificarZoom(MYGEspecificacionesVistaPaginada vista,
        IReadOnlyDictionary<string, ToolStripButton> botones, Action<bool, string> exige)
    {
        vista.IrAPagina(3);
        var ancla = new Point(vista.Vista.ClientSize.Width / 2, vista.Vista.ClientSize.Height / 2);
        double zoomInicial = vista.Zoom;
        var hojaInicial = vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize).Single();
        for (int i = 0; i < 3; i++) vista.CambiarZoomRueda(30, ancla);
        exige(vista.AjustarPagina && Math.Abs(vista.Zoom - zoomInicial) < .0001 && vista.PaginaActual == 3,
            "Tres deltas parciales de Ctrl+rueda deben acumularse sin cambiar escala ni página antes de completar una muesca.");
        vista.CambiarZoomRueda(30, ancla);
        var ampliada = vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize).Single();
        exige(!vista.AjustarPagina && vista.Zoom > zoomInicial && ampliada.Width > hojaInicial.Width && vista.PaginaActual == 3,
            "Completar una muesca de Ctrl+rueda debe ampliar la hoja manteniendo la página actual.");
        var zoomLabel = Controles(vista).OfType<ToolStrip>().SelectMany(x => x.Items.OfType<ToolStripLabel>())
            .Single(x => x.Name == "espec_previa_zoom");
        exige(zoomLabel.Text.EndsWith('%') && zoomLabel.ToolTipText.Contains("Ctrl", StringComparison.Ordinal),
            "La navegación debe indicar el porcentaje de ampliación y permitir descubrir Ctrl+rueda.");

        vista.CambiarZoomRueda(int.MaxValue, ancla);
        var superficie = (ScrollableControl)vista.Vista;
        exige(Math.Abs(vista.Zoom - 5) < .0001 && vista.Columnas == 1 &&
                superficie.AutoScrollMinSize.Width > superficie.ClientSize.Width &&
                superficie.AutoScrollMinSize.Height > superficie.ClientSize.Height && vista.PaginaActual == 3,
            "El zoom debe limitarse al 500% y ofrecer desplazamiento horizontal y vertical para alcanzar toda la hoja ampliada.");
        var antesPan = vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize).Single();
        superficie.AutoScrollPosition = new Point(120, 160);
        var despuesPan = vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize).Single();
        exige(despuesPan.X != antesPan.X || despuesPan.Y != antesPan.Y,
            "Desplazar la superficie ampliada debe trasladar la hoja dibujada, sin navegar a otra página.");

        vista.CambiarZoomRueda(int.MinValue, ancla);
        var alejadas = vista.ObtenerRectangulosPaginas(vista.Vista.ClientSize);
        exige(Math.Abs(vista.Zoom - .1) < .0001 && vista.Columnas == 2 && alejadas.Length == 2 &&
                alejadas[0].Left >= 0 && alejadas[1].Right <= vista.Vista.ClientSize.Width &&
                superficie.AutoScrollPosition == Point.Empty && vista.PaginaActual == 3,
            "Al alejar hasta el 10% deben verse dos hojas completas y desaparecer el desplazamiento sobrante, conservando la página.");
        vista.CambiarZoomRueda(int.MaxValue, ancla);
        exige(vista.Columnas == 1 && vista.PaginaActual == 3,
            "Volver a acercar debe pasar automáticamente de dos hojas a una sin cambiar la selección.");
        botones["espec_previa_dos_paginas"].PerformClick();
        exige(vista.AjustarPagina && vista.Columnas == 2 && superficie.AutoScrollMinSize == Size.Empty &&
                superficie.AutoScrollPosition == Point.Empty,
            "Dos páginas debe restablecer el ajuste completo y retirar las barras del zoom manual.");
        botones["espec_previa_una_pagina"].PerformClick();
        exige(vista.AjustarPagina && vista.Columnas == 1 && botones["espec_previa_una_pagina"].Checked &&
                !botones["espec_previa_dos_paginas"].Checked && vista.PaginaActual == 3,
            "Una página debe restaurar el ajuste y señalar el modo seleccionado, conservando la navegación.");
    }

    private static MYGEspecificacionesEntregaPaginada EntregaSintetica(int cantidad)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Navegacion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        string archivo = Path.Combine(carpeta, "documento.rtf");
        File.WriteAllText(archivo, @"{\rtf1\ansi Documento sintético para comprobar navegación.}");
        var paginas = Enumerable.Range(0, cantidad)
            .Select(_ => new PreviewPageInfo(new Bitmap(40, 60), new Size(827, 1169))).ToArray();
        return new MYGEspecificacionesEntregaPaginada(carpeta, archivo, ".rtf", paginas, Array.Empty<MemoryStream>());
    }

    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (Control control in Controles(hijo)) yield return control;
    }
}
