# Actualización: zoom y paginación de especificaciones

Base: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`c95ab893faf6bcab97492a6ebe53b720b33229c7`.

## Comportamiento

- En la vista de exportación, Ctrl + rueda acerca o aleja la hoja. El porcentaje
  aparece en la barra inferior. El zoom mantiene la página y no recompone la entrega.
- Una hoja ampliada se puede recorrer con las barras internas; la rueda sin Ctrl
  desplaza su contenido si hay desbordamiento vertical. La navegación inferior y
  la barra exterior siguen permitiendo cambiar de página.
- Al alejar lo suficiente y si el documento tiene varias páginas, se muestran dos
  hojas contiguas. Los botones Una página y Dos páginas restauran el ajuste al área.
- Con Microsoft Word de escritorio instalado, la vista abre el archivo final en
  Word, obtiene sus páginas y muestra «Páginas de Word». Guardar copia ese mismo
  archivo, también en DOC, sin volver a convertirlo. Se comprueba que Word haya
  proporcionado tantas imágenes como páginas tiene el documento.
- Sin Word, DOCX y RTF siguen disponibles con una vista aproximada claramente
  identificada. RichEdit y Word pueden distribuir el texto de forma diferente;
  esa modalidad no garantiza el mismo número de páginas. DOC requiere Word.
- Si Word está instalado pero falla su automatización, se muestra el error; no se
  sustituye silenciosamente la paginación real por una estimación.

## Instalación manual

1. Respalde o confirme sus cambios locales antes de copiar archivos.
2. Extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip` y copie su contenido sobre la raíz
   del proyecto, conservando las carpetas. Los archivos existentes se entregan
   completos; compare primero si tienen cambios posteriores a la base indicada.
3. No hay eliminaciones, migraciones SQL ni cambios de bases de datos.
4. En Visual Studio 2026 (18 o posterior), abra `MYG.Presupuestos.sln` con SDK
   .NET 10.0.100 o una versión permitida por `global.json` y compile Release/x64.

Desde la raíz, para compilar fuera de una instalación de Revit:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2
```

`UseRevitReferencePackages` usa la opción existente de referencias Revit 2027;
no instala Revit. No se añadieron paquetes ni se cambiaron proyectos o lockfiles.

## Validación

La compilación en Linux comprueba el código de escritorio y de pruebas UI,
pero no ejecuta Windows Forms, RichEdit ni Microsoft Office. Para las pruebas
específicas, ejecute en Windows x64:

```powershell
# Navegación, zoom y exportación nativa. No requiere Word.
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --especificaciones-sin-word
# Paginación y reapertura de los archivos finales. Requiere Word de escritorio.
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --especificaciones-entrega-word
```

El segundo comando compara la cantidad real de páginas tras reabrir DOC, DOCX
y RTF con la cantidad de la vista; también prueba el guardado desde el editor,
el desbordamiento de texto, saltos, encabezado, pie y orientación horizontal.
Estas pruebas de Windows/Word no se pudieron ejecutar en el entorno Linux de
preparación. Consulte los resultados efectivos de compilación y pruebas en la
respuesta que acompaña la entrega.

Compruebe manualmente en su PC:

1. Abra Especificaciones de Proyecto o Presupuesto y pruebe Ctrl + rueda en ambos
   sentidos. Al acercar, recorra los extremos de la hoja; al alejar, compruebe dos
   páginas en un documento de varias hojas.
2. Cambie de página y vuelva a Una página/Dos páginas. Verifique que conserva el
   contenido, la cantidad de páginas y los formatos.
3. Con el indicador «Páginas de Word», exporte el formato seleccionado y ábralo
   en Word en el mismo equipo. Compare el recuento y los saltos, también en un
   documento largo con imágenes o tablas.

La coincidencia corresponde al archivo mostrado, en el mismo entorno de Word.
Editar el archivo después, sustituir fuentes, cambiar la impresora o abrirlo con
otro procesador de textos puede volver a distribuir sus páginas. No cambie su
documento de origen para aplicar esta actualización.

## Actualizar su repositorio

Después de validar, use Cambios de Git en Visual Studio para revisar únicamente
estos archivos, hacer Commit y hacer Push a su rama de trabajo. Compruebe el
commit en GitHub. Publicar el ZIP en DESCARGAS no modifica la rama main del código
ni aplica automáticamente los archivos en su PC.
