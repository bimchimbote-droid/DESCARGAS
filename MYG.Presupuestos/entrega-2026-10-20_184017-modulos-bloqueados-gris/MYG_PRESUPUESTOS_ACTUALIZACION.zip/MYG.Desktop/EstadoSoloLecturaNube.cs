using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

// Paleta de pantalla: nunca se escribe en las celdas del modelo ni en el RTF.
internal static class MYGEstadoSoloLecturaNube
{
    internal static Color Fondo => SystemInformation.HighContrast ? SystemColors.Control
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(53, 53, 53) : Color.FromArgb(236, 236, 236);
    internal static Color Texto => SystemInformation.HighContrast ? SystemColors.ControlText
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(185, 185, 185) : Color.FromArgb(100, 100, 100);
    internal static Color Seleccion => SystemInformation.HighContrast ? SystemColors.Highlight
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(76, 76, 76) : Color.FromArgb(211, 211, 211);
    internal static Color TextoSeleccion => SystemInformation.HighContrast ? SystemColors.HighlightText
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(240, 240, 240) : Color.FromArgb(65, 65, 65);
    internal static Color Borde => SystemInformation.HighContrast ? SystemColors.WindowFrame
        : MYG2027_TemaComercial.Oscuro ? Color.FromArgb(85, 85, 85) : Color.FromArgb(203, 203, 203);

    internal static void Colorear(DataGridViewCellStyle estilo)
    {
        estilo.BackColor = Fondo;
        estilo.ForeColor = Texto;
        estilo.SelectionBackColor = Seleccion;
        estilo.SelectionForeColor = TextoSeleccion;
    }

    internal static void Aplicar(DataGridView tabla, bool bloqueada)
    {
        if (tabla is MYG2027_TablaPresupuesto presupuesto) presupuesto.SoloLecturaNube = bloqueada;
        tabla.BackgroundColor = bloqueada ? Fondo : MYG2027_TemaComercial.Superficie;
        tabla.GridColor = bloqueada ? Borde : MYG2027_TemaComercial.Borde;
        if (bloqueada)
        {
            Colorear(tabla.ColumnHeadersDefaultCellStyle);
            Colorear(tabla.RowHeadersDefaultCellStyle);
        }
        else
        {
            var cabecera = tabla.ColumnHeadersDefaultCellStyle;
            cabecera.BackColor = cabecera.SelectionBackColor = MYG2027_TemaComercial.CabeceraTabla;
            cabecera.ForeColor = cabecera.SelectionForeColor = MYG2027_TemaComercial.TextoCabeceraTabla;
            var filas = tabla.RowHeadersDefaultCellStyle;
            filas.BackColor = MYG2027_TemaComercial.AzulSuave;
            filas.ForeColor = MYG2027_TemaComercial.Texto;
            filas.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
            filas.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
        }
        tabla.Invalidate();
    }
}

internal sealed partial class MYGPanelPresupuesto
{
    private void AplicarAspectoPermisosNube()
    {
        MYGEstadoSoloLecturaNube.Aplicar(estructura, !EdicionNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(tablaPie, !EdicionNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(acu, !EdicionACUNubePermitida);
        MYGEstadoSoloLecturaNube.Aplicar(hoja, !EdicionMetradosExcelNubePermitida);
        hoja.GridColor = ColorRejillaHoja;

        formula.SoloLecturaNube = !EdicionMetradosExcelNubePermitida;
        formula.AplicarTema();
        ActualizarColoresReferenciasHoja();
        celdaTotal.BackColor = EdicionMetradosExcelNubePermitida ? MYG2027_TemaComercial.Superficie : MYGEstadoSoloLecturaNube.Fondo;
        celdaTotal.ForeColor = EdicionMetradosExcelNubePermitida ? MYG2027_TemaComercial.Texto : MYGEstadoSoloLecturaNube.Texto;
        foreach (var boton in botonesFormulaHoja) boton.Enabled = EdicionMetradosExcelNubePermitida && HayPartida;

        AplicarTemaContextoACU();
        if (!EdicionACUNubePermitida)
        {
            totalPrecioACU.BackColor = MYGEstadoSoloLecturaNube.Fondo;
            totalPrecioACU.ForeColor = MYGEstadoSoloLecturaNube.Texto;
            if (barraRendimientoACU != null)
            {
                barraRendimientoACU.BackColor = MYGEstadoSoloLecturaNube.Fondo;
                foreach (Control grupo in barraRendimientoACU.Controls) grupo.BackColor = MYGEstadoSoloLecturaNube.Fondo;
            }
            foreach (Control control in new Control[] { porRendimientoACU, porAsignacionACU, unidadRendimientoACU })
            { control.BackColor = MYGEstadoSoloLecturaNube.Fondo; control.ForeColor = MYGEstadoSoloLecturaNube.Texto; }
        }
        foreach (var par in new[] { (herramientasEstructura, EdicionNubePermitida), (herramientasACU, EdicionACUNubePermitida) })
            if (par.Item1 != null)
            {
                par.Item1.BackColor = par.Item2 ? AzulClaro : MYGEstadoSoloLecturaNube.Fondo;
                par.Item1.ForeColor = par.Item2 ? MYG2027_TemaComercial.Texto : MYGEstadoSoloLecturaNube.Texto;
            }
    }
}
