using System;
using System.Linq;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;
namespace MYG_2027
{
    internal static partial class MYG2027_TemaComercial
    {
        // Superficies neutras y acento azul. Las propiedades se consultan al
        // dibujar para que las ventanas abiertas respondan al cambio de modo.
        private static Drawing.Color RGB(int rgb) => Drawing.Color.FromArgb(255, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
        internal static Drawing.Color Marino => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Control : RGB(Oscuro ? 0x1B2431 : 0x1F2F46);
        internal static Drawing.Color MarinoClaro => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Control : RGB(Oscuro ? 0x283547 : 0x2D405B);
        internal static Drawing.Color Azul => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Highlight : RGB(Oscuro ? 0x77AFE5 : 0x2B6CB0);
        internal static Drawing.Color AzulSuave => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Control : RGB(Oscuro ? 0x25374B : 0xEDF3FA);
        internal static Drawing.Color Fondo => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Control : RGB(Oscuro ? 0x191F28 : 0xF4F6F8);
        internal static Drawing.Color Superficie => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Window : RGB(Oscuro ? 0x242D39 : 0xFFFFFF);
        internal static Drawing.Color SuperficieAlterna => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Window : RGB(Oscuro ? 0x202834 : 0xFAFBFC);
        internal static Drawing.Color Borde => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.WindowFrame : RGB(Oscuro ? 0x3D4858 : 0xE0E5EB);
        internal static Drawing.Color Texto => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.WindowText : RGB(Oscuro ? 0xE7EDF5 : 0x263446);
        internal static Drawing.Color Secundario => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.GrayText : RGB(Oscuro ? 0xA9B7C8 : 0x647184);
        internal static Drawing.Color Seleccion => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Highlight : RGB(Oscuro ? 0x324E6D : 0xE6EFF9);
        internal static Drawing.Color TextoSeleccion => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.HighlightText : Texto;
        internal static Drawing.Color CabeceraTabla => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.Control : RGB(Oscuro ? 0x2A3645 : 0xF0F3F7);
        internal static Drawing.Color TextoCabeceraTabla => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.ControlText : Texto;
        internal static Drawing.Color TextoSobreAzul => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.HighlightText : Oscuro ? RGB(0x12243B) : Drawing.Color.White;
        internal static Drawing.Color TextoCabecera => WinForms.SystemInformation.HighContrast ? Drawing.SystemColors.ControlText : Drawing.Color.White;
        internal static Drawing.Color AccesoFondo => Fondo;
        internal static Drawing.Color AccesoCaja => Superficie;
        internal static Drawing.Color AccesoAzul => Azul;

        internal static void EstilizarTabla(WinForms.DataGridView tabla, int altoCabecera = 40)
        {
            tabla.EnableHeadersVisualStyles = false;
            tabla.BackgroundColor = Superficie;
            tabla.BorderStyle = WinForms.BorderStyle.None;
            tabla.GridColor = Borde;
            tabla.CellBorderStyle = WinForms.DataGridViewCellBorderStyle.SingleHorizontal;
            tabla.ColumnHeadersBorderStyle = WinForms.DataGridViewHeaderBorderStyle.None;
            tabla.ColumnHeadersHeightSizeMode = WinForms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            tabla.ColumnHeadersHeight = Math.Max(tabla.Font.Height + 12, (int)Math.Round(altoCabecera * tabla.DeviceDpi / 96F));
            tabla.ColumnHeadersDefaultCellStyle.BackColor = CabeceraTabla;
            tabla.ColumnHeadersDefaultCellStyle.ForeColor = TextoCabeceraTabla;
            tabla.ColumnHeadersDefaultCellStyle.SelectionBackColor = CabeceraTabla;
            tabla.ColumnHeadersDefaultCellStyle.SelectionForeColor = TextoCabeceraTabla;
            if (!MYGTamanoTextoUI.EsFuenteInterfaz(tabla.ColumnHeadersDefaultCellStyle.Font, 9F, Drawing.FontStyle.Bold))
            {
                var fuente = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold);
                tabla.ColumnHeadersDefaultCellStyle.Font = fuente;
                tabla.Disposed += (_, _) => fuente.Dispose();
            }
            if (!MYGTamanoTextoUI.EsFuenteInterfaz(tabla.DefaultCellStyle.Font, 9F, Drawing.FontStyle.Regular))
            {
                var fuente = new Drawing.Font("Segoe UI", 9F);
                tabla.DefaultCellStyle.Font = fuente;
                tabla.Disposed += (_, _) => fuente.Dispose();
            }
            tabla.DefaultCellStyle.BackColor = Superficie;
            tabla.DefaultCellStyle.ForeColor = Texto;
            tabla.DefaultCellStyle.SelectionBackColor = Seleccion;
            tabla.DefaultCellStyle.SelectionForeColor = TextoSeleccion;
            tabla.AlternatingRowsDefaultCellStyle.BackColor = FondoFilasAlternas(tabla);
            tabla.RowTemplate.Height = 34;
        }

        // Grilla compacta con los mismos tamaños y colores del editor del add-in.
        internal static void EstilizarTablaPresupuesto(WinForms.DataGridView tabla)
        {
            EstilizarTabla(tabla, 38);
            tabla.AutoGenerateColumns = false;
            tabla.AllowUserToAddRows = false;
            tabla.AllowUserToDeleteRows = false;
            tabla.AllowUserToResizeRows = false;
            tabla.AllowUserToOrderColumns = false;
            tabla.RowHeadersVisible = false;
            tabla.MultiSelect = true;
            tabla.SelectionMode = WinForms.DataGridViewSelectionMode.CellSelect;
            tabla.EditMode = WinForms.DataGridViewEditMode.EditOnEnter;
            tabla.AutoSizeRowsMode = WinForms.DataGridViewAutoSizeRowsMode.None;
            tabla.AutoSizeColumnsMode = WinForms.DataGridViewAutoSizeColumnsMode.None;
            tabla.ClipboardCopyMode = WinForms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            tabla.DefaultCellStyle.ForeColor = Texto;
            tabla.DefaultCellStyle.SelectionForeColor = TextoSeleccion;
            tabla.DefaultCellStyle.Padding = new WinForms.Padding(0);
            tabla.RowTemplate.Height = 25;
            tabla.DefaultCellStyle.WrapMode = WinForms.DataGridViewTriState.False;
            tabla.ColumnHeadersDefaultCellStyle.WrapMode = WinForms.DataGridViewTriState.False;
            tabla.ScrollBars = WinForms.ScrollBars.Both;
        }
        private static readonly int[] titulosClaros = { 0xBD353E, 0x2567B1, 0x137440, 0x8742AC, 0x965800, 0x006D7A, 0xA63C66, 0x56677B };
        private static readonly int[] titulosOscuros = { 0xFF979F, 0x8AC2FF, 0x82D6A0, 0xD0A2EC, 0xF6BE78, 0x7AD4DE, 0xF4A0C0, 0xB3C0D0 };
        private static readonly int[] filtrosClaros = { 0xEBF5FF, 0xEEFAEE, 0xFFF9E6, 0xF7F0FF, 0xFFF1E8, 0xE8FAFA, 0xFFEEF3, 0xEEF2F7 };
        private static readonly int[] filtrosOscuros = { 0x293B50, 0x2D4038, 0x443D2C, 0x3A334A, 0x44382F, 0x293F43, 0x45323C, 0x343D49 };
        private static readonly int[] cabecerasFiltroClaras = { 0xBFDBFE, 0xC6EFCE, 0xFFE599, 0xE0CCFF, 0xFFCCAA, 0xB7E8E8, 0xF9C4D3, 0xCBD5E1 };
        private static readonly int[] cabecerasFiltroOscuras = { 0x345574, 0x365948, 0x64552F, 0x54416E, 0x664A37, 0x315B60, 0x653C4E, 0x495564 };
        internal static Drawing.Color ColorTitulo(int nivel) => WinForms.SystemInformation.HighContrast ? Texto
            : MYGParametrosAplicacionUI.TryColorNivel(nivel, out var color) ? color
            : nivel >= 0 && nivel < titulosClaros.Length ? RGB((Oscuro ? titulosOscuros : titulosClaros)[nivel]) : Texto;
        // El papel permanece blanco aunque la aplicación use la apariencia oscura.
        // Conserva los colores de cada nivel con los tonos legibles de la paleta clara.
        internal static Drawing.Color ColorTituloImpresion(int nivel) =>
            MYGParametrosAplicacionUI.TryColorNivel(nivel, out var color) ? color
            : RGB(nivel >= 0 && nivel < titulosClaros.Length ? titulosClaros[nivel] : 0x263446);

        // Reutiliza la actualización de los editores para refrescar sus filas y
        // vistas previas cuando cambia la paleta de parámetros predeterminados.
        internal static void ActualizarColoresParametros()
        {
            revisionTema++;
            foreach (var form in WinForms.Application.OpenForms.Cast<WinForms.Form>().ToArray()) Aplicar(form);
            CambioTema?.Invoke(null, EventArgs.Empty);
        }
        internal static Drawing.Color ColorFiltro(int numero) => WinForms.SystemInformation.HighContrast ? Superficie : numero >= 1 && numero <= filtrosClaros.Length
            ? RGB((Oscuro ? filtrosOscuros : filtrosClaros)[numero - 1]) : Superficie;
        internal static Drawing.Color ColorCabeceraFiltro(int numero) => WinForms.SystemInformation.HighContrast ? Superficie : numero >= 1 && numero <= cabecerasFiltroClaras.Length
            ? RGB((Oscuro ? cabecerasFiltroOscuras : cabecerasFiltroClaras)[numero - 1]) : AzulSuave;

        internal static MYG2027_TarjetaComercial GrupoAcciones(string titulo, params WinForms.Control[] controles)
        {
            int ancho = 24 + controles.Sum(c => c.Width + 6) - (controles.Length > 0 ? 6 : 0);
            var grupo = new MYG2027_TarjetaComercial
            {
                Width = ancho,
                Height = 70,
                Radio = 9,
                Margin = new WinForms.Padding(0, 0, 10, 8)
            };
            grupo.Controls.Add(new WinForms.Label
            {
                Text = titulo,
                Left = 12,
                Top = 8,
                Width = ancho - 24,
                Height = 17,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                ForeColor = Secundario,
                BackColor = Superficie,
                AutoEllipsis = true,
                Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
            });
            int izquierda = 12;
            foreach (var control in controles)
            {
                control.SetBounds(izquierda, 29, control.Width, 30);
                control.Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Left;
                grupo.Controls.Add(control);
                izquierda += control.Width + 6;
            }
            return grupo;
        }

        internal static Drawing.Drawing2D.GraphicsPath Contorno(Drawing.RectangleF r, float radio)
        {
            var p = new Drawing.Drawing2D.GraphicsPath();
            float d = Math.Min(radio * 2F, Math.Min(r.Width, r.Height));
            if (d < 1F) { p.AddRectangle(r); return p; }
            p.AddArc(r.Left, r.Top, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        internal static void EstilizarBoton(WinForms.Button b, int estilo = 0)
        {
            if (b == null) return;
            b.FlatStyle = WinForms.FlatStyle.Flat;
            b.UseVisualStyleBackColor = false;
            MYGCursoresUI.Aplicar(b);
            b.FlatAppearance.BorderSize = estilo == 1 ? 0 : 1;
            b.FlatAppearance.BorderColor = Borde;
            estilosBoton.GetValue(b, _ => new EstiloBoton()).Estilo = estilo;
            b.BackColor = estilo == 1 ? Azul : estilo == 2 ? AzulSuave : estilo == 3 ? MarinoClaro : Superficie;
            b.ForeColor = estilo == 1 ? TextoSobreAzul : estilo == 3 ? TextoCabecera : Texto;
            var hacia = estilo == 1 ? (Oscuro ? Drawing.Color.White : Marino) : Azul;
            b.FlatAppearance.MouseOverBackColor = WinForms.SystemInformation.HighContrast
                ? b.BackColor : Mezclar(b.BackColor, hacia, .09F);
            b.FlatAppearance.MouseDownBackColor = WinForms.SystemInformation.HighContrast
                ? b.BackColor : Mezclar(b.BackColor, hacia, .17F);
            var fuenteOriginal = MYGTamanoTextoUI.FuenteOriginal(b.Font);
            var estiloFuente = fuenteOriginal.Size > 10F ? fuenteOriginal.Style
                : estilo == 1 ? Drawing.FontStyle.Bold : Drawing.FontStyle.Regular;
            if (b.Text.Length > 2 && (fuenteOriginal.Name != "Segoe UI" || fuenteOriginal.Size < 9F || fuenteOriginal.Style != estiloFuente))
            {
                var fuente = new Drawing.Font("Segoe UI", Math.Max(9F, fuenteOriginal.Size),
                    estiloFuente);
                b.Font = fuente;
                b.Disposed += (_, _) => fuente.Dispose();
            }
            MYGAnimacionUI.PrepararBoton(b);
            MYGAnimacionUI.ActualizarColores(b);
        }

        internal static int AlturaFlujo(WinForms.FlowLayoutPanel flujo)
        {
            int ancho = Math.Max(1, flujo.ClientSize.Width - flujo.Padding.Horizontal);
            int ocupado = 0, fila = 0, total = flujo.Padding.Vertical;
            foreach (WinForms.Control c in flujo.Controls)
            {
                int w = c.Width + c.Margin.Horizontal;
                int h = c.Height + c.Margin.Vertical;
                if (ocupado > 0 && ocupado + w > ancho)
                {
                    total += fila;
                    ocupado = 0;
                    fila = 0;
                }
                ocupado += w;
                fila = Math.Max(fila, h);
            }
            return total + fila;
        }

        internal static void AjustarAlAreaDeTrabajo(WinForms.Form form)
        {
            if (!form.TopLevel) return; // Los editores en pestañas usan el área de su contenedor.
            var area = WinForms.Screen.FromControl(form).WorkingArea;
            int ancho = Math.Min(form.Width, Math.Max(320, area.Width - 24));
            int alto = Math.Min(form.Height, Math.Max(300, area.Height - 24));
            form.MinimumSize = new Drawing.Size(
                Math.Min(form.MinimumSize.Width, ancho), Math.Min(form.MinimumSize.Height, alto));
            form.Size = new Drawing.Size(ancho, alto);
            form.Location = new Drawing.Point(
                area.Left + (area.Width - form.Width) / 2,
                area.Top + (area.Height - form.Height) / 2);
        }
    }
    internal sealed class MYG2027_BotonComercial : WinForms.Button
    {
        private bool _encima, _pulsado;
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(
            System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        internal bool MostrarFlecha { get; set; }
        internal MYG2027_BotonComercial()
        {
            SetStyle(WinForms.ControlStyles.UserPaint |
                WinForms.ControlStyles.AllPaintingInWmPaint |
                WinForms.ControlStyles.OptimizedDoubleBuffer |
                WinForms.ControlStyles.ResizeRedraw, true);
            FlatStyle = WinForms.FlatStyle.Flat;
            UseVisualStyleBackColor = false;
        }
        protected override void OnMouseEnter(EventArgs e) { _encima = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _encima = false; _pulsado = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(WinForms.MouseEventArgs e)
        { if (e.Button == WinForms.MouseButtons.Left) _pulsado = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(WinForms.MouseEventArgs e)
        { _pulsado = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnKeyDown(WinForms.KeyEventArgs e)
        { if (e.KeyCode == WinForms.Keys.Space) _pulsado = true; Invalidate(); base.OnKeyDown(e); }
        protected override void OnKeyUp(WinForms.KeyEventArgs e)
        { _pulsado = false; Invalidate(); base.OnKeyUp(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { _pulsado = false; Invalidate(); base.OnLostFocus(e); }
        protected override void OnEnabledChanged(EventArgs e) { _pulsado = false; Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnPaint(WinForms.PaintEventArgs e)
        {
            if (WinForms.SystemInformation.HighContrast) { base.OnPaint(e); return; }
            if (Width < 2 || Height < 2) return;
            e.Graphics.Clear(Parent == null ? BackColor : Parent.BackColor);
            e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.AntiAlias;
            float s = DeviceDpi / 96F;
            var alternativa = _pulsado ? FlatAppearance.MouseDownBackColor
                : _encima ? FlatAppearance.MouseOverBackColor : BackColor;
            var color = !Enabled ? MYG2027_TemaComercial.SuperficieAlterna
                : MYGAnimacionUI.ColorActual(this, alternativa);
            if (color.IsEmpty) color = BackColor;
            var texto = Enabled ? ForeColor : MYG2027_TemaComercial.Secundario;
            float trazo = Math.Max(1F, s), mitad = trazo * .5F;
            using (var p = MYG2027_TemaComercial.Contorno(
                new Drawing.RectangleF(mitad, mitad, Width - trazo, Height - trazo), 7F * s))
            using (var relleno = new Drawing.SolidBrush(color))
            using (var borde = new Drawing.Pen(Enabled ? FlatAppearance.BorderColor : MYG2027_TemaComercial.Borde, trazo))
            {
                e.Graphics.FillPath(relleno, p);
                if (FlatAppearance.BorderSize > 0 || !Enabled) e.Graphics.DrawPath(borde, p);
            }
            bool relacionVertical = TextImageRelation is WinForms.TextImageRelation.ImageAboveText
                or WinForms.TextImageRelation.TextAboveImage;
            bool variasLineas = relacionVertical || Text.Contains('\n') || Text.Contains('\r');
            var r = ClientRectangle;
            r.Inflate(-Math.Max(3, (int)Math.Round((relacionVertical ? 4F : 6F) * s)),
                -Math.Max(2, (int)Math.Round(2F * s)));
            if (MostrarFlecha) r.Width -= (int)(28 * s);
            if (Image != null && r.Width > 0 && r.Height > 0)
            {
                int separacion = (int)Math.Round((relacionVertical ? 3F : 6F) * s);
                int altoDisponible = r.Height;
                float limiteImagen = relacionVertical && Text.Length > 0 ? 24F * s : float.MaxValue;
                if (relacionVertical && Text.Length > 0)
                {
                    int altoLinea = WinForms.TextRenderer.MeasureText(e.Graphics, "Ag", Font,
                        Drawing.Size.Empty, WinForms.TextFormatFlags.SingleLine | WinForms.TextFormatFlags.NoPadding).Height;
                    int altoTexto = WinForms.TextRenderer.MeasureText(e.Graphics, Text, Font,
                        new Drawing.Size(r.Width, int.MaxValue), WinForms.TextFormatFlags.WordBreak |
                        WinForms.TextFormatFlags.NoPadding).Height;
                    // La cinta de 65 px necesita dos líneas sin que una imagen
                    // de 32 px las empuje fuera del botón. Se reserva primero
                    // el texto, y después se ajusta el icono sin deformarlo.
                    altoDisponible = Math.Max(1, r.Height - Math.Max(altoLinea * 2, altoTexto) - separacion);
                }
                float escalaImagen = Math.Min(1F, Math.Min(
                    Math.Min(r.Width, limiteImagen) / Image.Width,
                    Math.Min(altoDisponible, limiteImagen) / Image.Height));
                int anchoImagen = Math.Max(1, (int)Math.Round(Image.Width * escalaImagen));
                int altoImagen = Math.Max(1, (int)Math.Round(Image.Height * escalaImagen));
                var imagen = AlinearImagen(r, new Drawing.Size(anchoImagen, altoImagen),
                    ImageAlign);
                if (Text.Length > 0)
                {
                    if (TextImageRelation == WinForms.TextImageRelation.ImageBeforeText)
                    { imagen.X = r.Left; r.X += anchoImagen + separacion; r.Width -= anchoImagen + separacion; }
                    else if (TextImageRelation == WinForms.TextImageRelation.TextBeforeImage)
                    { imagen.X = r.Right - anchoImagen; r.Width -= anchoImagen + separacion; }
                    else if (TextImageRelation == WinForms.TextImageRelation.ImageAboveText)
                    { imagen.Y = r.Top; r.Y += altoImagen + separacion; r.Height -= altoImagen + separacion; }
                    else if (TextImageRelation == WinForms.TextImageRelation.TextAboveImage)
                    { imagen.Y = r.Bottom - altoImagen; r.Height -= altoImagen + separacion; }
                }
                if (Enabled) e.Graphics.DrawImage(Image, imagen);
                else
                {
                    using var atributos = new Drawing.Imaging.ImageAttributes();
                    var matriz = new Drawing.Imaging.ColorMatrix { Matrix33 = .4F };
                    atributos.SetColorMatrix(matriz);
                    e.Graphics.DrawImage(Image, imagen, 0, 0, Image.Width, Image.Height,
                        Drawing.GraphicsUnit.Pixel, atributos);
                }
            }
            r.Width = Math.Max(0, r.Width); r.Height = Math.Max(0, r.Height);
            var formato = AlineacionTexto(TextAlign) | WinForms.TextFormatFlags.NoPadding;
            formato |= variasLineas ? WinForms.TextFormatFlags.WordBreak
                : WinForms.TextFormatFlags.EndEllipsis | WinForms.TextFormatFlags.SingleLine;
            if (RightToLeft == WinForms.RightToLeft.Yes) formato |= WinForms.TextFormatFlags.RightToLeft;
            if (variasLineas && r.Width > 0 && r.Height > 0)
            {
                int altoTexto = WinForms.TextRenderer.MeasureText(e.Graphics, Text, Font,
                    new Drawing.Size(r.Width, int.MaxValue), formato).Height;
                int libre = Math.Max(0, r.Height - altoTexto);
                int desplazamiento = 0;
                if (TextAlign is Drawing.ContentAlignment.BottomLeft or Drawing.ContentAlignment.BottomCenter or Drawing.ContentAlignment.BottomRight)
                    desplazamiento = libre;
                else if (TextAlign is Drawing.ContentAlignment.MiddleLeft or Drawing.ContentAlignment.MiddleCenter or Drawing.ContentAlignment.MiddleRight)
                    desplazamiento = libre / 2;
                r.Y += desplazamiento;
                r.Height -= desplazamiento;
            }
            else if (!variasLineas)
                formato |= TextAlign is Drawing.ContentAlignment.BottomLeft or Drawing.ContentAlignment.BottomCenter or Drawing.ContentAlignment.BottomRight
                    ? WinForms.TextFormatFlags.Bottom : TextAlign is Drawing.ContentAlignment.MiddleLeft or Drawing.ContentAlignment.MiddleCenter or Drawing.ContentAlignment.MiddleRight
                    ? WinForms.TextFormatFlags.VerticalCenter : WinForms.TextFormatFlags.Top;
            WinForms.TextRenderer.DrawText(e.Graphics, Text, Font, r, texto,
                formato);
            if (MostrarFlecha)
            {
                float cx = Width - 26F * s, cy = Height * .5F;
                using (var flecha = new Drawing.Pen(texto, 1.8F * s))
                {
                    e.Graphics.DrawLine(flecha, cx - 7F * s, cy, cx + 6F * s, cy);
                    e.Graphics.DrawLines(flecha, new[] {
                        new Drawing.PointF(cx, cy - 6F * s), new Drawing.PointF(cx + 6F * s, cy),
                        new Drawing.PointF(cx, cy + 6F * s) });
                }
            }
            if (Focused && ShowFocusCues)
            {
                var foco = ClientRectangle;
                foco.Inflate(-(int)(5F * s), -(int)(5F * s));
                WinForms.ControlPaint.DrawFocusRectangle(e.Graphics, foco, texto, color);
            }
        }

        private static WinForms.TextFormatFlags AlineacionTexto(Drawing.ContentAlignment alineacion)
            => alineacion is Drawing.ContentAlignment.TopLeft or Drawing.ContentAlignment.MiddleLeft or Drawing.ContentAlignment.BottomLeft
                ? WinForms.TextFormatFlags.Left
                : alineacion is Drawing.ContentAlignment.TopRight or Drawing.ContentAlignment.MiddleRight or Drawing.ContentAlignment.BottomRight
                ? WinForms.TextFormatFlags.Right : WinForms.TextFormatFlags.HorizontalCenter;

        private static Drawing.Rectangle AlinearImagen(Drawing.Rectangle area, Drawing.Size tamano,
            Drawing.ContentAlignment alineacion)
        {
            int x = alineacion is Drawing.ContentAlignment.TopLeft or Drawing.ContentAlignment.MiddleLeft or Drawing.ContentAlignment.BottomLeft
                ? area.Left : alineacion is Drawing.ContentAlignment.TopRight or Drawing.ContentAlignment.MiddleRight or Drawing.ContentAlignment.BottomRight
                ? area.Right - tamano.Width : area.Left + (area.Width - tamano.Width) / 2;
            int y = alineacion is Drawing.ContentAlignment.TopLeft or Drawing.ContentAlignment.TopCenter or Drawing.ContentAlignment.TopRight
                ? area.Top : alineacion is Drawing.ContentAlignment.BottomLeft or Drawing.ContentAlignment.BottomCenter or Drawing.ContentAlignment.BottomRight
                ? area.Bottom - tamano.Height : area.Top + (area.Height - tamano.Height) / 2;
            return new Drawing.Rectangle(x, y, tamano.Width, tamano.Height);
        }
    }
    internal sealed class MYG2027_CabeceraComercial : WinForms.Panel
    {
        internal MYG2027_CabeceraComercial()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = MYG2027_TemaComercial.Marino;
        }
        protected override void OnPaintBackground(WinForms.PaintEventArgs e)
        {
            if (Width < 1 || Height < 1) return;
            using (var fondo = new Drawing.SolidBrush(MYG2027_TemaComercial.Marino))
                e.Graphics.FillRectangle(fondo, ClientRectangle);
            float s = DeviceDpi / 96F;
            float altoLinea = Math.Max(1F, s);
            using (var acento = new Drawing.SolidBrush(WinForms.SystemInformation.HighContrast
                ? Drawing.SystemColors.WindowFrame : MYG2027_TemaComercial.MarinoClaro))
                e.Graphics.FillRectangle(acento, 0, Height - altoLinea, Width, altoLinea);
        }
    }
    internal sealed class MYG2027_TarjetaComercial : WinForms.Panel
    {
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(
            System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        internal Drawing.Color ColorBorde { get; set; } = MYG2027_TemaComercial.Borde;
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(
            System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        internal int Radio { get; set; } = 12;
        internal MYG2027_TarjetaComercial()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = MYG2027_TemaComercial.Superficie;
        }
        protected override void OnPaintBackground(WinForms.PaintEventArgs e)
        {
            e.Graphics.Clear(Parent == null ? BackColor : Parent.BackColor);
            if (Width < 2 || Height < 2) return;
            e.Graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.AntiAlias;
            float s = DeviceDpi / 96F;
            float trazo = Math.Max(1F, s), mitad = trazo * .5F;
            using (var p = MYG2027_TemaComercial.Contorno(
                new Drawing.RectangleF(mitad, mitad, Width - trazo, Height - trazo),
                WinForms.SystemInformation.HighContrast ? 0F : Radio * s))
            using (var fondo = new Drawing.SolidBrush(BackColor))
            using (var borde = new Drawing.Pen(ColorBorde, trazo))
            {
                e.Graphics.FillPath(fondo, p);
                e.Graphics.DrawPath(borde, p);
            }
        }
    }
    internal sealed class MYG2027_TablaPresupuesto : WinForms.DataGridView
    {
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        internal bool SoloLecturaNube { get; set; }
        internal MYG2027_TablaPresupuesto() { DoubleBuffered = true; ResizeRedraw = true; }
        protected override void OnCellFormatting(WinForms.DataGridViewCellFormattingEventArgs e)
        {
            base.OnCellFormatting(e);
            // Última capa visual, después de los formatos de títulos y celdas.
            // Los estilos originales siguen disponibles al recuperar el permiso.
            if (SoloLecturaNube) MYGEstadoSoloLecturaNube.Colorear(e.CellStyle);
        }
    }
    // Se dibuja a partir de las posiciones reales de las columnas, incluyendo
    // anchos, columnas ocultas y desplazamiento horizontal del DataGridView.
    internal sealed class MYG2027_CabeceraFiltros : WinForms.Panel
    {
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        internal WinForms.DataGridView Tabla { get; set; }
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        internal int CantidadFiltros { get; set; } = 1;
        internal MYG2027_CabeceraFiltros()
        { DoubleBuffered = true; ResizeRedraw = true; BackColor = MYG2027_TemaComercial.Superficie; }
        protected override void OnPaint(WinForms.PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Tabla == null || Tabla.Columns.Count == 0) return;
            int ancho = Math.Min(ClientSize.Width, Tabla.ClientSize.Width);
            if (Tabla.Controls.OfType<WinForms.VScrollBar>().Any(v => v.Visible)) ancho -= WinForms.SystemInformation.VerticalScrollBarWidth;
            var viewport = new Drawing.Rectangle(0, 0, Math.Max(0, ancho), Math.Max(0, Height - 1));
            using var borde = new Drawing.Pen(MYG2027_TemaComercial.Borde);
            using var fuente = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold);
            for (int n = 1; n <= CantidadFiltros; n++)
            {
                var rectangulos = new System.Collections.Generic.List<Drawing.Rectangle>();
                foreach (string nombre in new[] { "P" + n, "R" + n, "V" + n })
                {
                    if (!Tabla.Columns.Contains(nombre) || !Tabla.Columns[nombre].Visible) continue;
                    var r = Tabla.GetColumnDisplayRectangle(Tabla.Columns[nombre].Index, false);
                    if (r.Width > 0) { r.Y = 0; r.Height = Height - 1; rectangulos.Add(r); }
                }
                if (rectangulos.Count == 0) continue;
                int izquierda = rectangulos.Min(r => r.Left), derecha = rectangulos.Max(r => r.Right);
                var grupo = Drawing.Rectangle.Intersect(new Drawing.Rectangle(izquierda, 0, derecha - izquierda, Height - 1), viewport);
                if (grupo.Width < 1 || grupo.Height < 1) continue;
                using var fondo = new Drawing.SolidBrush(MYG2027_TemaComercial.ColorCabeceraFiltro(n));
                e.Graphics.FillRectangle(fondo, grupo); e.Graphics.DrawRectangle(borde, grupo);
                WinForms.TextRenderer.DrawText(e.Graphics, "FILTRO " + n.ToString("00"), fuente, grupo, MYG2027_TemaComercial.Texto,
                    WinForms.TextFormatFlags.HorizontalCenter | WinForms.TextFormatFlags.VerticalCenter | WinForms.TextFormatFlags.SingleLine);
            }
        }
    }

}
