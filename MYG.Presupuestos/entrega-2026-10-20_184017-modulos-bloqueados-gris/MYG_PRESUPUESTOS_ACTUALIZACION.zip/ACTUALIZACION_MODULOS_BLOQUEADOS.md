# Módulos bloqueados en gris — MYG Presupuestos

## Resultado

ACU, Especificaciones y Metrados Excel se muestran en gris únicamente cuando
su permiso de edición está bloqueado. Recuperar el permiso restaura los colores
normales. Un usuario con rol global de solo lectura también ve bloqueados la
estructura y el pie del presupuesto. Los módulos editables conservan su aspecto.

Las tablas y el documento siguen habilitados para seleccionar, desplazarse y
consultar. Se deshabilitan las herramientas que editan; copiar, zoom y las
opciones de consulta/exportación disponibles se conservan. El cambio de tema
mantiene el bloqueo. Se respeta la paleta de accesibilidad de alto contraste.

La apariencia se aplica en pantalla, sin sustituir los colores guardados en las
celdas ni en el RTF. Esta entrega no requiere SQL ni cambios de Supabase.

## Archivos del ZIP

Las rutas parten de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
Cada archivo REEMPLAZAR se entrega completo.

| Ruta | Acción | Función |
|---|---|---|
| `MYG.Desktop/EstadoSoloLecturaNube.cs` | CREAR | Paleta gris y aplicación según los permisos de cada módulo. |
| `MYG.Desktop/PermisosVisualesEspecificaciones.cs` | CREAR | Bloqueo reversible de herramientas y superficies de Especificaciones. |
| `MYG.Desktop/EditorFormulaHoja.cs` | REEMPLAZAR | Barra de fórmulas gris conservando texto e historial. |
| `MYG.Desktop/EspecificacionesEditor.cs` | REEMPLAZAR | Clasificación de comandos de edición y actualización del aspecto. |
| `MYG.Desktop/EspecificacionesVistaOscura.cs` | REEMPLAZAR | Representación gris del documento sin alterar el RTF. |
| `MYG.Desktop/PermisosPanelNube.cs` | REEMPLAZAR | Actualización visual al cambiar los permisos. |
| `MYG.Desktop/PresupuestosExcelEditor.cs` | REEMPLAZAR | Celdas combinadas, cabeceras, bordes y botones de fórmula bloqueados. |
| `MYG.Desktop/PresupuestosExcelPanel.cs` | REEMPLAZAR | Conserva la rejilla gris al actualizar la hoja. |
| `MYG.Desktop/PresupuestosExcelReferencias.cs` | REEMPLAZAR | Evita decoraciones de edición a color en hojas bloqueadas. |
| `MYG.Desktop/PresupuestosExcelSeleccion.cs` | REEMPLAZAR | Contorno de selección gris durante el bloqueo. |
| `MYG.Desktop/PresupuestosPanel.cs` | REEMPLAZAR | Conserva el aspecto bloqueado al cambiar de tema. |
| `MYG.Desktop/Tema.cs` | REEMPLAZAR | Formato final gris de las tablas bloqueadas. |
| `MYG.PruebasUI/PermisosModulosUICheck.cs` | REEMPLAZAR | Comprobaciones de bloqueo, consulta y restauración. |
| `ACTUALIZACION_MODULOS_BLOQUEADOS.md` | CREAR | Estas instrucciones y resultados de validación. |

## Instalación

1. Cierre MYG y respalde o confirme sus cambios locales antes de reemplazar archivos.
2. Descargue y extraiga el ZIP en una carpeta temporal.
3. Copie las carpetas `MYG.Desktop` y `MYG.PruebasUI` y este documento dentro de
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`, combinando las carpetas existentes.
   Acepte reemplazar solamente los archivos de la tabla. No cree una carpeta
   adicional con el nombre del ZIP dentro del proyecto.
4. Los dos archivos nuevos `.cs` deben quedar dentro de `MYG.Desktop`, junto
   a los otros `.cs`. El proyecto SDK los incluye automáticamente.
5. Abra `MYG.Presupuestos.sln` en Visual Studio compatible con .NET 10,
   restaure NuGet y compile en Release. Ejecute la aplicación recién compilada.
   Copiar el código no actualiza por sí solo un ejecutable o instalador anterior.

No hay archivos que eliminar, dependencias nuevas, referencias que añadir ni
migraciones que ejecutar. Conserve las migraciones y archivos de las entregas
anteriores de Supabase.

## Compilación y pruebas

Base del código: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`5eff104c9b208c40857bdbecf42298605e9e1d93`. Preparación en rama local `work`.
Tecnologías: C#, .NET SDK 10.0.100, WinForms/WPF; pruebas de datos con SQLite.

Desde la carpeta del proyecto, en PowerShell o terminal de Visual Studio:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore -- --permisos-modulos
```

Resultados obtenidos en Linux el 20/10/2026:

- Solución completa y pruebas UI compiladas: 0 errores y 0 advertencias.
- Datos: 582 pruebas aprobadas.
- Nube: 26 grupos principales y 787 comprobaciones de contrato HTTP aprobadas,
  además de las integraciones SQLite y HTTP simulado indicadas por esa suite.
- `git diff --check`: aprobado.
- Las pruebas UI se compilaron, pero no se ejecutaron: necesitan Windows con
  escritorio y su runtime WinForms. La apariencia final y la ejecución dentro
  de Revit deben comprobarse en Windows.

Comprobación manual recomendada con un proyecto de prueba:

1. Bloquee únicamente ACU: su tabla y campos de edición quedan grises;
   Especificaciones y Excel siguen normales y editables.
2. Repita con únicamente Especificaciones y únicamente Metrados Excel.
   Consulte texto con colores y celdas con rellenos o combinaciones:
   deben verse grises sin perder sus formatos guardados.
3. Verifique selección, desplazamiento, copiar y zoom mientras está bloqueado.
   Las herramientas de edición deben aparecer deshabilitadas.
4. Cambie entre tema claro y oscuro, y pruebe alto contraste de Windows:
   el bloqueo debe continuar y la selección debe ser legible.
5. Restituya cada permiso: sólo ese módulo recupera colores y edición,
   sin recrear el proyecto ni modificar contenido o historial.
6. Compruebe un usuario lector global y vuelva después a una cuenta con edición.

## Publicar sus cambios en GitHub

En Visual Studio, revise `Cambios de Git`, confirme que la rama deseada sea
`main`, compruebe el diff, cree el Commit y pulse Push. Verifique los archivos
en `bimchimbote-droid/MYG.Presupuestos`, rama `main`.

Esta entrega publica sólo el ZIP en el repositorio independiente `DESCARGAS`;
no publica automáticamente cambios del repositorio del código.

## Precaución al reemplazar

Si modificó cualquiera de estos archivos después del commit base, compare y
combine sus cambios antes de sustituir el archivo completo. No sobrescriba
personalizaciones locales sin revisarlas. No se modificaron datos reales,
obras, usuarios ni vinculaciones de Supabase.
