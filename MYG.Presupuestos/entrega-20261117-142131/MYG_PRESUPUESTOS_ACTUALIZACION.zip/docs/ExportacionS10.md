# Exportar a S10 Presupuestos 2005

En el editor, abra **Exportar → Exportar a S10 Presupuestos 2005…**. Seleccione el
presupuesto, su ubicación real y la fecha de costos. El código de usuario S10 es
opcional: si queda vacío, el SQL identifica al usuario a partir de la sesión que
ejecuta la importación.

La exportación genera un archivo `.sql` para ejecutar completo en SQL Server
Management Studio sobre **una copia de la base S10**. Crea registros nuevos dentro
de una transacción y comprueba el esquema de destino. No genera un respaldo
`.S2K`; ese respaldo se obtiene después desde S10. Abra y procese el presupuesto
importado en S10 y compare sus importes antes de utilizarlo.

## Usuario de la importación

El nombre de acceso a S10 (por ejemplo, `sa`) y su código interno no son el mismo
dato. No escriba una contraseña en el campo **Código de usuario S10**.

- Con una sesión SQL que ya tiene el rol de servidor `sysadmin` y entra a la base
  como `dbo`, se reconoce al administrador reservado `0000000`, si esa fila
  existe, tiene `Administrador=1` y su `uid` coincide con la sesión. Este registro
  puede tener `Activo=0`; el exportador no lo activa ni cambia sus permisos.
- Para otras sesiones, se busca un usuario activo vinculado por SID o por el
  identificador de usuario de la base. Se excluyen el reservado y los códigos
  cortos de grupos. Si hay más de un candidato se pide un código explícito.
- Un código explícito normal debe identificar un usuario activo de siete
  caracteres. El código reservado `0000000` exige siempre las comprobaciones
  administrativas anteriores, incluso si figura activo. Un código inválido no
  provoca una sustitución por otro usuario.

Para el acceso administrativo descrito, puede dejar **Código de usuario S10**
vacío y generar de nuevo el SQL con esta versión. Se conserva la asignación del
presupuesto nuevo mediante `PresupuestoUsuario`; no se modifican usuarios,
contraseñas, roles ni permisos existentes. Las validaciones y restricciones de
la base siguen vigentes y un error revierte la importación.

## Ejecutar en SQL Server 2005

Las versiones recientes de SSMS pueden no conectarse a SQL Server 2005. Si la
instalación ya dispone de `sqlcmd`, puede ejecutar el archivo contra una copia
preparada de su base S10. Por ejemplo, desde la carpeta que contiene el SQL:

```bat
sqlcmd -S localhost -E -d S10_MYG_PRUEBA -b -f 65001 -i "presupuesto.sql"
```

`S10_MYG_PRUEBA` debe ser una copia válida de S10, con sus tablas y catálogos, no
una base vacía. `-E` usa la cuenta de Windows de esa consola; ejecutarla como
administrador sólo aprovecha los permisos que ya tenga asignados en SQL Server.
El archivo generado es UTF-8; `-f 65001` conserva sus caracteres. Compruebe el
resultado antes de repetir la importación, para no duplicar presupuestos.

## Precisión numérica

Los cálculos de MYG pueden producir más decimales que las columnas de S10. El
mensaje «PresupuestoInsumo.Precio1: El valor exige más de 9 decimales» se refiere a
un precio calculado, no a los datos que se escriben en el formulario.

Al exportar se redondea cada número a la escala de su columna, según el perfil
S10 incluido en el proyecto. Las mitades se redondean alejándose de cero.

| Destino | Decimales admitidos |
|---|---:|
| Precios de insumos (`PresupuestoInsumo`, `PrecioGeneral`) | 9 |
| Metrados (`SubpresupuestoDetalle`) | 9 |
| Precios de partidas y cantidades del análisis | 13 |
| Cuadrilla | 9 |
| Rendimiento de mano de obra y equipo | 4 |
| Jornada | 2 |

Por ejemplo, un precio `1.23456789155` se exporta como `1.234567892` en una columna
de nueve decimales. La cuadrilla se calcula con el consumo, rendimiento y jornada
que realmente recibirá S10, y después se ajusta a sus nueve decimales.

Cada cambio se informa en los avisos de la exportación. El SQL conserva además
un comentario JSON de una sola línea con el prefijo `MYG_PRECISION_NUMERICA`:
incluye contexto, tabla, columna, valor original, valor exportado, precisión y
escala. Los valores numéricos usan punto decimal independientemente del idioma
del equipo. Los ceros finales que no cambian el valor no generan avisos.

El proyecto, las opciones y la base SQLite de MYG conservan sus valores
originales. Los importes pueden variar al reprocesar los análisis en S10 por su
precisión de almacenamiento. Revise los avisos y compare precios, parciales y
totales en la copia. El pie conserva los importes calculados de MYG: si modifica
metrados o precios en S10, revise sus fórmulas antes de reprocesar.

Con parciales importados de más de trece decimales, la suma de los parciales
redondeados puede diferir del resumen original. El exportador informa ambas
cifras y valida el SQL contra la suma que realmente inserta; no recalcula ni
reescribe silenciosamente el resumen y el pie originales.

Se siguen rechazando los valores que exceden la parte entera admitida, incluido
un desbordamiento causado por el redondeo. Si el rendimiento o la jornada quedan
en cero a la precisión de S10, se indica la partida afectada y se detiene la
exportación para evitar un análisis inválido. Otros valores que se redondeen a
cero se señalan expresamente. Un fallo de validación conserva el archivo SQL
anterior sin escribir una exportación parcial.

## Descripciones

Se mantienen las correcciones anteriores: equivalentes compatibles con
Windows-1252 para símbolos conocidos, compactación de espacios y abreviación de
descripciones que excedan su columna. Los textos completos ajustados por
longitud quedan en comentarios `MYG_DESCRIPCION_COMPLETA`. Los códigos, unidades
y fórmulas siguen validados estrictamente; no se sustituyen por texto inventado.

## Validación del código

Requiere el SDK .NET 10 de `global.json`. Desde la raíz del repositorio:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore -- --exportacion-s10
```

La opción de referencias Revit permite comprobar la compilación sin instalar
Revit. Las pruebas de exportación usan datos sintéticos y no ejecutan SQL Server
ni S10. La interfaz y la importación real deben comprobarse en Windows.
