using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace MYG_2027;

public sealed class MYGOpcionesExportacionS10
{
    public string PresupuestoId { get; set; }
    public string Nombre { get; set; }
    public string CodigoLugar { get; set; }
    public string CodigoUsuario { get; set; }
    public DateTime FechaCosto { get; set; } = DateTime.Today;
}

public sealed record MYGUbicacionS10(string Codigo, string Nombre)
{
    public override string ToString() => Codigo + " · " + Nombre;
}

public sealed record MYGResultadoExportacionS10(int Presupuestos, int Partidas, int Insumos,
    IReadOnlyList<string> Advertencias);

public sealed record MYGDocumentoSqlS10(string Contenido, MYGResultadoExportacionS10 Resultado);

/// <summary>Genera un lote de inserción en una base S10 existente. El SQL usa
/// únicamente sintaxis SQL Server 2005, comprueba el esquema y crea registros
/// nuevos dentro de una transacción. No es un respaldo nativo S2K.</summary>
public static class MYGExportacionS10Sql
{
    private static readonly Lazy<IReadOnlyList<MYGUbicacionS10>> lugares = new(() =>
    {
        var a = typeof(MYGExportacionS10Sql).Assembly;
        using var s = a.GetManifestResourceStream(a.GetManifestResourceNames().Single(n => n.EndsWith("S10Ubicaciones.json", StringComparison.Ordinal)));
        return Array.AsReadOnly(JsonSerializer.Deserialize<MYGUbicacionS10[]>(s));
    });
    public static IReadOnlyList<MYGUbicacionS10> Ubicaciones => lugares.Value;

    public static MYGResultadoExportacionS10 Guardar(string ruta, MYGProyectoDocumento proyecto,
        MYGOpcionesExportacionS10 opciones, Action<string> progreso = null)
    {
        if (string.IsNullOrWhiteSpace(ruta) || !string.Equals(Path.GetExtension(ruta), ".sql", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Seleccione un archivo .sql. Esta exportación no genera un respaldo .S2K.");
        string destino = Path.GetFullPath(ruta);
        if (!Directory.Exists(Path.GetDirectoryName(destino))) throw new DirectoryNotFoundException("La carpeta de destino no existe.");
        var documento = CrearDocumento(proyecto, opciones, progreso);
        string temporal = destino + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            progreso?.Invoke("Escribiendo el archivo SQL de S10…");
            using (var f = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var w = new StreamWriter(f, new UTF8Encoding(true))) w.Write(documento.Contenido);
            File.Move(temporal, destino, overwrite: true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
        return documento.Resultado;
    }

    public static MYGDocumentoSqlS10 CrearDocumento(MYGProyectoDocumento proyecto,
        MYGOpcionesExportacionS10 opciones, Action<string> progreso = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto); ArgumentNullException.ThrowIfNull(opciones);
        if (!Ubicaciones.Any(x => x.Codigo == opciones.CodigoLugar))
            throw new InvalidDataException("Seleccione una ubicación del catálogo de S10.");
        string nombre = string.IsNullOrWhiteSpace(opciones.Nombre) ? proyecto.Nombre : opciones.Nombre.Trim();
        if (string.IsNullOrWhiteSpace(nombre)) throw new InvalidDataException("Indique el nombre del presupuesto de S10.");
        var ajustesTexto = new List<string>();
        var descripcionesIniciales = new List<MYGDescripcionLargaS10>();
        nombre = MYGSqlS10.AdaptarDescripcion("Presupuesto", nombre, ajustesTexto.Add, descripcionesIniciales.Add);
        MYGSqlS10.Literal("Usuario", "CodUsuario", opciones.CodigoUsuario ?? "");
        MYGSqlS10.Literal("Presupuesto", "Fecha", opciones.FechaCosto.Date);
        progreso?.Invoke("Calculando los metrados y análisis del proyecto…");
        var modelo = MYGPreparacionExportacionS10.Crear(proyecto, opciones.PresupuestoId);
        if (modelo.Presupuestos.Count > 999) throw new InvalidDataException("S10 permite hasta 999 subpresupuestos en esta exportación. Seleccione un presupuesto.");
        if (modelo.Presupuestos.Any(p => p.Nodos.Count > short.MaxValue))
            throw new InvalidDataException("Un subpresupuesto supera las 32767 filas admitidas por el secuencial de S10.");
        if (modelo.Presupuestos.Select(p => Moneda(p.Moneda)).Distinct(StringComparer.Ordinal).Count() != 1)
            throw new InvalidDataException("Los presupuestos tienen monedas distintas. Exporte cada moneda por separado.");
        var g = new Generador(modelo, opciones, nombre, ajustesTexto, descripcionesIniciales);
        progreso?.Invoke("Relacionando títulos, partidas y recursos con el esquema S10…");
        return g.Crear();
    }

    private static string Moneda(string s) => (s ?? "").Replace(".", "").Replace(" ", "").ToUpperInvariant() switch
    { "PEN" or "S/" or "SOLES" or "NUEVOSSOLES" => "S/", "USD" or "US$" or "U$" or "$" => "$", var x => x };

    private sealed record Recurso(string Variable, MYGPresupuestoExportacionS10 Presupuesto,
        MYGLineaAcuExportacionS10 Linea, string ClaveUnidad);

    private sealed class Generador
    {
        private readonly MYGModeloExportacionS10 modelo;
        private readonly MYGOpcionesExportacionS10 opciones;
        private readonly string nombre;
        private readonly StringBuilder cuerpo = new();
        private readonly HashSet<string> tablas = new(StringComparer.Ordinal);
        private readonly List<string> avisos;
        private readonly Dictionary<string, string> unidades = new(StringComparer.Ordinal);
        private readonly Dictionary<(string P, string I), string> partidas = new();
        private readonly Dictionary<(string P, string I), string> titulos = new();
        private readonly Dictionary<(string P, string I, string U, decimal Precio, MYGGrupoRecurso G), Recurso> recursos = new();
        private const string AdministradorVinculado = "CodUsuario=N'0000000' AND Administrador=1 AND uid=USER_ID() AND USER_NAME()=N'dbo' AND IS_SRVROLEMEMBER(N'sysadmin')=1";
        private const string UsuarioActivoVinculado = "CodUsuario<>N'0000000' AND LEN(CodUsuario)=7 AND Activo=1 AND (sid=SUSER_SID() OR uid=USER_ID())";
        private int numeroUnidad, numeroRecurso;
        private static string Q(string t, string c, object v) => MYGSqlS10.Literal(t, c, v);
        private static MYGVariableSqlS10 V(string nombre) => new(nombre);
        private static string D(decimal n) => n.ToString(CultureInfo.InvariantCulture);
        internal Generador(MYGModeloExportacionS10 modelo, MYGOpcionesExportacionS10 opciones, string nombre,
            IEnumerable<string> ajustesTexto, IEnumerable<MYGDescripcionLargaS10> descripcionesIniciales)
        {
            this.opciones = opciones; this.nombre = nombre; avisos = modelo.Advertencias.ToList();
            avisos.AddRange(ajustesTexto);
            foreach (var descripcion in descripcionesIniciales) ConservarDescripcion(descripcion, "Nombre de la exportación");
            // Una estimada sin detalle vuelve a cero cuando S10 la procesa.
            // Representar el precio directo mediante un único insumo permite reprocesarlo.
            bool equivalentes = false, unidadesLiterales = false;
            this.modelo = modelo with { Presupuestos = modelo.Presupuestos.Select(p => p with
            {
                Nodos = p.Nodos.Select(n =>
                {
                    if (n.EsTitulo) return n;
                    var lineas = n.Analisis;
                    if (lineas.Count == 0)
                    {
                        equivalentes = true;
                        lineas = Array.AsReadOnly(new[] { new MYGLineaAcuExportacionS10(1, MYGGrupoRecurso.Materiales,
                            "MYG-PRECIO-DIRECTO:" + n.Id, null, n.Codigo, "Precio directo de la partida " + n.Codigo,
                            n.Unidad, 1m, n.PrecioUnitario, n.PrecioUnitario, 1m, 0m, MYGModoCantidad.Directa, false) });
                    }
                    decimal baseMO = lineas.Where(l => l.Grupo == MYGGrupoRecurso.ManoObra).Sum(l => l.Parcial);
                    return n with { RendimientoDiario = n.PrecioDirectoSinAnalisis && n.RendimientoDiario <= 0 ? 1m : n.RendimientoDiario,
                        JornadaHoras = n.PrecioDirectoSinAnalisis && n.JornadaHoras <= 0 ? 8m : n.JornadaHoras,
                        Analisis = Array.AsReadOnly(lineas.Select(l =>
                    {
                        if (l.Modo == MYGModoCantidad.PorcentajeManoObra)
                            return l with { Unidad = "%MO", Cantidad = baseMO == 0 ? 0 : l.Cantidad / 100m * (l.Precio / baseMO) };
                        if (l.Grupo != MYGGrupoRecurso.Subpartidas && Unidad(l.Unidad).StartsWith('%'))
                        {
                            // En MYG una unidad con % también puede ser un coeficiente directo.
                            // S10 interpretaría esa unidad como una fórmula porcentual distinta.
                            unidadesLiterales = true;
                            return l with { Unidad = "coef" };
                        }
                        return l;
                    }).ToArray()) };
                }).ToArray()
            }).ToArray() };
            if (equivalentes) avisos.Add("Las partidas con precio directo se representan mediante un insumo equivalente, para conservar su precio al reprocesar en S10.");
            if (unidadesLiterales) avisos.Add("Los recursos con unidad porcentual usados como cantidad directa en MYG se exportan con unidad coef para conservar su cálculo.");
        }

        private void L(string sql) => cuerpo.AppendLine(sql);
        private void ConservarDescripcion(MYGDescripcionLargaS10 descripcion, string contexto)
        {
            // El JSON predeterminado escapa CR/LF y separadores Unicode: cada
            // original queda en una sola línea de comentario, nunca como SQL.
            L("-- MYG_DESCRIPCION_COMPLETA " + JsonSerializer.Serialize(new
            {
                Contexto = contexto, descripcion.Tabla, descripcion.Original,
                descripcion.AdaptadoCompleto, descripcion.TextoS10, descripcion.LimiteBytes
            }));
        }
        private static string ContextoFila((string C, object V)[] campos) =>
            string.Join(", ", campos.Where(c => c.C.StartsWith("Cod", StringComparison.Ordinal)
                || c.C is "Item" or "Linea" or "Descripcion")
                .Select(c => c.C + "=" + (c.V is MYGVariableSqlS10 variable ? variable.Nombre
                    : Convert.ToString(c.V, CultureInfo.InvariantCulture))));

        private decimal NumeroDestino(string tabla, string columna, decimal numero, string contexto)
        {
            decimal adaptado = MYGSqlS10.AdaptarNumero(tabla, columna, numero, ajuste =>
            {
                L("-- MYG_PRECISION_NUMERICA " + JsonSerializer.Serialize(new
                {
                    Contexto = contexto, ajuste.Tabla, ajuste.Columna, ajuste.Original,
                    ajuste.ValorS10, ajuste.Precision, ajuste.Escala
                }));
                avisos.Add("S10 " + tabla + "." + columna + ": " + D(ajuste.Original) + " → " + D(ajuste.ValorS10)
                    + " (" + ajuste.Escala + " decimales, redondeo de mitades alejándose de cero)."
                    + " El valor original se conserva en MYG y en MYG_PRECISION_NUMERICA del SQL."
                    + (ajuste.ValorS10 == 0 ? " El valor exportado queda en cero." : ""));
            });
            if (tabla == "Partida" && (columna is "RendimientoMO" or "RendimientoEQ" or "Jornada") && adaptado <= 0)
                throw new InvalidDataException("S10 " + tabla + "." + columna + ": el valor " + D(numero)
                    + " quedaría en cero con la precisión de destino. Revise el rendimiento o la jornada de la partida. " + contexto);
            return adaptado;
        }
        private void Fila(string tabla, params (string C, object V)[] campos)
        {
            tablas.Add(tabla);
            string descripcion = campos.FirstOrDefault(x => x.C == "Descripcion").V as string;
            try
            {
                string contexto = ContextoFila(campos);
                var valores = campos.ToDictionary(x => x.C,
                    x => x.C == "Descripcion" && x.V is string texto
                        ? (object)MYGSqlS10.AdaptarDescripcion(tabla, texto, avisos.Add, ajuste => ConservarDescripcion(ajuste,
                            contexto))
                        : x.V is decimal numero && MYGSqlS10.Tabla(tabla).Columna(x.C).Tipo is "numeric" or "decimal"
                        ? NumeroDestino(tabla, x.C, numero, contexto)
                        : x.V, StringComparer.Ordinal);
                L(MYGSqlS10.Insertar(tabla, valores));
            }
            catch (InvalidDataException ex) when (descripcion != null)
            {
                string detalle = descripcion.Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
                if (detalle.Length > 150) detalle = detalle[..150] + "…";
                throw new InvalidDataException(ex.Message + " Dato: «" + detalle + "».", ex);
            }
        }
        private void Necesita(params string[] nombres) { foreach (string n in nombres) tablas.Add(n); }
        private static string Unidad(string unidad) => (unidad ?? "").Trim().Replace("²", "2").Replace("³", "3").ToUpperInvariant();
        private string RegistrarUnidad(string simbolo)
        {
            string clave = Unidad(simbolo);
            if (clave.Length == 0) throw new InvalidDataException("Una partida o un recurso no tiene unidad de medida.");
            Q("Unidad", "Simbolo", clave);
            if (!unidades.TryGetValue(clave, out var variable)) unidades.Add(clave, variable = "@u" + (++numeroUnidad));
            return variable;
        }
        private Recurso RegistrarRecurso(MYGPresupuestoExportacionS10 p, MYGLineaAcuExportacionS10 l)
        {
            var clave = (p.Id, l.InsumoId, Unidad(l.Unidad), l.Precio, l.Grupo);
            if (!recursos.TryGetValue(clave, out var r))
            {
                RegistrarUnidad(l.Unidad);
                recursos.Add(clave, r = new Recurso("@r" + (++numeroRecurso), p, l, Unidad(l.Unidad)));
            }
            return r;
        }
        private Recurso BuscarRecurso(MYGPresupuestoExportacionS10 p, MYGLineaAcuExportacionS10 l)
            => recursos[(p.Id, l.InsumoId, Unidad(l.Unidad), l.Precio, l.Grupo)];

        internal MYGDocumentoSqlS10 Crear()
        {
            int nt = 0, np = 0;
            foreach (var p in modelo.Presupuestos)
            foreach (var n in p.Nodos)
            {
                if (n.EsTitulo) titulos.Add((p.Id, n.Id), "@t" + (++nt));
                else
                {
                    partidas.Add((p.Id, n.Id), "@p" + (++np)); RegistrarUnidad(n.Unidad);
                    if (n.Analisis.Count > 0 && (n.RendimientoDiario <= 0 || n.JornadaHoras <= 0))
                        throw new InvalidDataException("La partida «" + n.Codigo + " · " + n.Descripcion + "» necesita rendimiento y jornada positivos para S10.");
                    foreach (var l in n.Analisis.Where(x => x.Grupo != MYGGrupoRecurso.Subpartidas)) RegistrarRecurso(p, l);
                }
            }
            if (np == 0) throw new InvalidDataException("La selección no contiene partidas para exportar a S10.");
            if (nt > 999) throw new InvalidDataException("La selección contiene más de 999 títulos. Exporte los presupuestos por separado.");
            if (recursos.Values.GroupBy(r => r.Linea.Grupo).Any(g => g.Count() > 9999))
                throw new InvalidDataException("Un grupo de recursos supera los 9999 insumos de esta exportación.");
            Necesita("Presupuesto", "Titulo", "Partida", "Insumo", "Unidad", "Moneda", "Usuario", "PresupuestoUsuario", "UbicacionGeografica");
            CabeceraDatos(); CarpetasPresupuesto(); CrearUnidades(); CrearRecursos(); CrearPartidas();
            int sub = 0;
            foreach (var p in modelo.Presupuestos) CrearSubpresupuesto(p, (++sub).ToString("000", CultureInfo.InvariantCulture));
            L("COMMIT TRANSACTION;");
            L("SELECT @presupuesto AS CodigoPresupuestoS10, N'Importación MYG completada' AS Resultado;");
            var salida = new StringBuilder();
            salida.AppendLine("-- MYG Presupuestos -> S10 Presupuestos 2005 (SQL Server 2005 o posterior).");
            salida.AppendLine("-- Seleccione una COPIA de su base S10 en SQL Server Management Studio y ejecute este lote completo.");
            salida.AppendLine("-- Crea registros nuevos; no reemplaza ni elimina presupuestos, partidas o insumos existentes.");
            salida.AppendLine("-- Este archivo SQL no es un respaldo .S2K. El respaldo se genera posteriormente desde S10/SQL Server.");
            salida.AppendLine("-- Abra el presupuesto nuevo en S10 y procese sus análisis. Revise los importes y las fórmulas del pie en la copia antes de usarlo.");
            salida.AppendLine("SET NOCOUNT ON; SET XACT_ABORT ON;");
            salida.AppendLine("IF @@TRANCOUNT <> 0 BEGIN RAISERROR(N'Finalice la transacción actual antes de importar.',16,1); RETURN; END;");
            salida.AppendLine("BEGIN TRY");
            foreach (var t in tablas.OrderBy(x => x, StringComparer.Ordinal)) ComprobarEsquema(salida, t);
            salida.AppendLine("BEGIN TRANSACTION;");
            salida.AppendLine("DECLARE @bloqueo int; EXEC @bloqueo=sys.sp_getapplock @Resource=N'MYG_S10_EXPORTACION',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=15000;");
            salida.AppendLine("IF @bloqueo < 0 RAISERROR(N'No se pudo reservar la importación S10. Inténtelo de nuevo.',16,1);");
            salida.Append(cuerpo);
            salida.AppendLine("END TRY BEGIN CATCH IF XACT_STATE() <> 0 ROLLBACK TRANSACTION; DECLARE @mensaje nvarchar(4000); SET @mensaje=ERROR_MESSAGE(); RAISERROR(N'%s',16,1,@mensaje); END CATCH;");
            if (modelo.Presupuestos.Any(p => p.Pie.Count > 1)) avisos.Add("El pie se exporta con los importes calculados de MYG. Si modifica metrados o precios en S10, revise las fórmulas del pie antes de reprocesar.");
            avisos.Add("Abra y procese el presupuesto en S10 para generar sus resultados internos de análisis; compare los totales en la copia de la base.");
            if (modelo.Presupuestos.SelectMany(p => p.Nodos).Any(n => n.Analisis.Any(l => l.Grupo is MYGGrupoRecurso.ManoObra or MYGGrupoRecurso.Equipo)))
                avisos.Add("Las cuadrillas de S10 se calculan desde los coeficientes efectivos, el rendimiento y la jornada para conservar el consumo del análisis.");
            return new(salida.ToString(), new(modelo.Presupuestos.Count, np, recursos.Count, Array.AsReadOnly(avisos.Distinct().ToArray())));
        }

        private void CabeceraDatos()
        {
            L("DECLARE @n int, @raiz varchar(2), @grupo varchar(4), @presupuesto varchar(7), @raizT varchar(2), @grupoT varchar(4), @moneda varchar(2), @usuario varchar(7), @lugar varchar(6);");
            L("SET @lugar=" + Q("Presupuesto", "CodLugar", opciones.CodigoLugar) + ";");
            L("IF NOT EXISTS(SELECT 1 FROM dbo.UbicacionGeografica WHERE CodLugar=@lugar) RAISERROR(N'La ubicación seleccionada no existe en esta base S10.',16,1);");
            string moneda = Moneda(modelo.Presupuestos[0].Moneda);
            L("SELECT TOP 1 @moneda=CodMoneda FROM dbo.Moneda WHERE " +
                (moneda == "$" ? "LTRIM(RTRIM(Simbolo)) IN (N'$',N'U$',N'US$')" : "REPLACE(REPLACE(UPPER(LTRIM(RTRIM(Simbolo))),N'.',N''),N' ',N'')=" + Q("Moneda", "Simbolo", moneda)) + " ORDER BY CodMoneda;");
            L("IF @moneda IS NULL RAISERROR(N'La moneda del presupuesto no existe en el catálogo de S10.',16,1);");
            if (!string.IsNullOrWhiteSpace(opciones.CodigoUsuario))
            {
                string codigo = opciones.CodigoUsuario.Trim();
                L("SELECT @usuario=CodUsuario FROM dbo.Usuario WHERE " + (codigo == "0000000"
                    ? AdministradorVinculado
                    : "CodUsuario=" + Q("Usuario", "CodUsuario", codigo) + " AND CodUsuario<>N'0000000' AND LEN(CodUsuario)=7 AND Activo=1") + ";");
            }
            else
            {
                // El administrador reservado puede figurar inactivo en S10.
                // Sólo se reconoce para un sysadmin SQL que ya entra como dbo;
                // no se activan cuentas ni se concede ningún permiso nuevo.
                L("SELECT @usuario=CodUsuario FROM dbo.Usuario WHERE " + AdministradorVinculado + ";");
                L("IF @usuario IS NULL BEGIN");
                L("IF (SELECT COUNT(*) FROM dbo.Usuario WHERE " + UsuarioActivoVinculado + ")>1 RAISERROR(N'Hay varios usuarios S10 vinculados a esta sesión. Exporte de nuevo indicando el código de su usuario S10.',16,1);");
                L("SELECT @usuario=CodUsuario FROM dbo.Usuario WHERE " + UsuarioActivoVinculado + ";");
                L("END;");
            }
            L("IF @usuario IS NULL RAISERROR(N'No se identificó un usuario S10 válido para esta sesión. Indique su código de usuario activo; el administrador reservado exige acceso SQL sysadmin como dbo.',16,1);");
            L("IF NOT EXISTS(SELECT 1 FROM dbo.Presupuesto WHERE CodPresupuesto='9999999') OR NOT EXISTS(SELECT 1 FROM dbo.Titulo WHERE CodTitulo='9999999') OR NOT EXISTS(SELECT 1 FROM dbo.Insumo WHERE CodInsumo='9999999999') OR NOT EXISTS(SELECT 1 FROM dbo.Partida WHERE CodPartida='999999999999' AND CodPresupuesto='9999999' AND PropioPartida='99') RAISERROR(N'Faltan registros de sistema de S10. La base de destino no es compatible.',16,1);");
        }

        private void CodigoLibre(string variable, string tabla, string columna, string prefijo, int digitos, int maximo, string filtro = "")
        {
            Necesita(tabla);
            L("SET @n=1;");
            L("WHILE @n<=" + maximo + " BEGIN SET " + variable + "=" + prefijo + "+RIGHT(REPLICATE('0'," + digitos + ")+CONVERT(varchar(10),@n)," + digitos + "); IF NOT EXISTS(SELECT 1 FROM dbo." + MYGSqlS10.Identificador(tabla) + " WITH(UPDLOCK,HOLDLOCK) WHERE LEFT(" + MYGSqlS10.Identificador(columna) + ",LEN(" + variable + "))=" + variable + filtro + ") BREAK; SET @n=@n+1; END;");
            L("IF @n>" + maximo + " RAISERROR(N'No quedan códigos disponibles para la exportación MYG en " + tabla + ".',16,1);");
        }
        private void Carpeta(string tabla, string codigo, string raiz, string grupo, string descripcion)
        {
            L("SELECT TOP 1 " + raiz + "=" + MYGSqlS10.Identificador(codigo) + " FROM dbo." + MYGSqlS10.Identificador(tabla) + " WITH(UPDLOCK,HOLDLOCK) WHERE Nivel=1 AND LEN(" + MYGSqlS10.Identificador(codigo) + ")=2 AND Descripcion=N'MYG Presupuestos' ORDER BY " + MYGSqlS10.Identificador(codigo) + ";");
            L("IF " + raiz + " IS NULL BEGIN");
            CodigoLibre(raiz, tabla, codigo, "''", 2, 98);
            Fila(tabla, (codigo, V(raiz)), ("Nivel", 1), ("Descripcion", "MYG Presupuestos"));
            L("END;");
            CodigoLibre(grupo, tabla, codigo, raiz, 2, 99);
            Fila(tabla, (codigo, V(grupo)), ("Nivel", 2), ("Descripcion", descripcion));
        }
        private void CarpetasPresupuesto()
        {
            Carpeta("Presupuesto", "CodPresupuesto", "@raiz", "@grupo", nombre);
            L("SET @presupuesto=@grupo+'001';");
            var resumen = modelo.Presupuestos;
            Fila("Presupuesto", ("CodPresupuesto", V("@presupuesto")), ("Nivel", 3), ("Descripcion", nombre),
                ("Fecha", opciones.FechaCosto.Date), ("Jornada", 8m), ("CodMoneda1", V("@moneda")), ("CodLugar", V("@lugar")),
                ("DobleMoneda", false), ("PieGeneral", false), ("Concluido", false),
                ("CostoDirectoBase1", resumen.Sum(p => p.Resumen.CostoDirecto)), ("CostoIndirectoBase1", resumen.Sum(p => p.Resumen.Total - p.Resumen.CostoDirecto)), ("CostoBase1", resumen.Sum(p => p.Resumen.Total)),
                ("CostoDirectoOferta1", resumen.Sum(p => p.Resumen.CostoDirecto)), ("CostoIndirectoOferta1", resumen.Sum(p => p.Resumen.Total - p.Resumen.CostoDirecto)), ("CostoOferta1", resumen.Sum(p => p.Resumen.Total)),
                ("DecimalesPrecioInsumo", modelo.Presupuestos.Max(p => p.DecimalesPrecio)), ("DecimalesPrecioUnitario", modelo.Presupuestos.Max(p => p.DecimalesPrecio)),
                ("DecimalesMetrado", modelo.Presupuestos.Max(p => p.DecimalesCantidad)), ("DecimalesIncidencia", modelo.Presupuestos.Max(p => p.DecimalesCantidad)));
            Fila("PresupuestoUsuario", ("CodPresupuesto", V("@presupuesto")), ("CodUsuario", V("@usuario")));
            if (titulos.Count > 0) Carpeta("Titulo", "CodTitulo", "@raizT", "@grupoT", nombre);
        }
        private void CrearUnidades()
        {
            foreach (var u in unidades)
            {
                L("DECLARE " + u.Value + " varchar(3);");
                L("SELECT TOP 1 " + u.Value + "=CodUnidad FROM dbo.Unidad WITH(UPDLOCK,HOLDLOCK) WHERE Nivel=2 AND UPPER(REPLACE(REPLACE(LTRIM(RTRIM(Simbolo)),N'²',N'2'),N'³',N'3'))=" + Q("Unidad", "Simbolo", u.Key) + " ORDER BY CodUnidad;");
                L("IF " + u.Value + " IS NULL BEGIN");
                CodigoLibre(u.Value, "Unidad", "CodUnidad", "''", 3, 998);
                Fila("Unidad", ("CodUnidad", V(u.Value)), ("Nivel", 2), ("Simbolo", u.Key), ("Descripcion", u.Key));
                L("END;");
            }
        }
        private void CrearRecursos()
        {
            foreach (var grupo in recursos.Values.GroupBy(r => r.Linea.Grupo))
            {
                string prefijo = grupo.Key switch { MYGGrupoRecurso.ManoObra => "01", MYGGrupoRecurso.Materiales => "02", MYGGrupoRecurso.Equipo => "03", MYGGrupoRecurso.Subcontratos => "04", _ => throw new InvalidDataException("Grupo de recurso no admitido por S10.") };
                string f = "@f" + prefijo;
                L("IF NOT EXISTS(SELECT 1 FROM dbo.Insumo WHERE CodInsumo='" + prefijo + "' AND Nivel=0) RAISERROR(N'Falta una categoría de recursos de S10.',16,1);");
                L("IF EXISTS(SELECT 1 FROM dbo.Insumo WHERE CodInsumo='" + prefijo + "99' AND (Nivel IS NULL OR Nivel<>1)) RAISERROR(N'La familia de insumos MYG tiene un nivel incompatible.',16,1);");
                L("IF NOT EXISTS(SELECT 1 FROM dbo.Insumo WITH(UPDLOCK,HOLDLOCK) WHERE CodInsumo='" + prefijo + "99') BEGIN");
                Fila("Insumo", ("CodInsumo", prefijo + "99"), ("Nivel", 1), ("Descripcion", "MYG Presupuestos")); L("END;");
                L("DECLARE " + f + " varchar(6);"); CodigoLibre(f, "Insumo", "CodInsumo", "'" + prefijo + "99'", 2, 98);
                Fila("Insumo", ("CodInsumo", V(f)), ("Nivel", 2), ("Descripcion", "Exportación MYG"));
                int i = 0;
                foreach (var r in grupo)
                {
                    var l = r.Linea;
                    L("DECLARE " + r.Variable + " varchar(14); SET " + r.Variable + "=" + f + "+'" + (++i).ToString("0000", CultureInfo.InvariantCulture) + "';");
                    Fila("Insumo", ("CodInsumo", V(r.Variable)), ("Nivel", 3), ("Descripcion", l.Descripcion), ("CodInsumoAnterior", l.Codigo),
                        ("CodUnidad", V(unidades[r.ClaveUnidad])), ("Factor", 1d), ("AfectoIGV", false));
                    Fila("PresupuestoInsumo", ("CodPresupuesto", V("@presupuesto")), ("CodInsumo", V(r.Variable)), ("Precio1", l.Precio), ("Precio2", 0m));
                    Fila("PrecioGeneral", ("CodLugar", V("@lugar")), ("Ano", opciones.FechaCosto.Year.ToString("0000", CultureInfo.InvariantCulture)), ("Mes", opciones.FechaCosto.Month.ToString("00", CultureInfo.InvariantCulture)),
                        ("CodMoneda", V("@moneda")), ("CodInsumo", V(r.Variable)), ("Precio1", l.Precio), ("Precio2", 0m));
                }
            }
        }
        private void CrearPartidas()
        {
            var carpetas = new HashSet<string>(StringComparer.Ordinal);
            foreach (var p in modelo.Presupuestos)
            foreach (var n in p.Nodos)
            {
                if (n.EsTitulo)
                {
                    string v = titulos[(p.Id, n.Id)];
                    int ordinal = int.Parse(v.AsSpan(2), CultureInfo.InvariantCulture);
                    L("DECLARE " + v + " varchar(7); SET " + v + "=@grupoT+'" + ordinal.ToString("000", CultureInfo.InvariantCulture) + "';");
                    Fila("Titulo", ("CodTitulo", V(v)), ("Nivel", 3), ("Descripcion", n.Descripcion), ("CodigoAlterno", n.Codigo));
                    continue;
                }
                string variable = partidas[(p.Id, n.Id)]; int num = int.Parse(variable.AsSpan(2), CultureInfo.InvariantCulture);
                string codigo = "98" + num.ToString("0000000000", CultureInfo.InvariantCulture);
                for (int nivel = 1; nivel <= 5; nivel++)
                {
                    string carpeta = codigo[..(nivel * 2)];
                    if (carpetas.Add(carpeta)) Fila("Partida", ("CodPartida", carpeta), ("CodPresupuesto", V("@presupuesto")), ("PropioPartida", "01"), ("Nivel", nivel), ("Descripcion", "MYG Presupuestos"));
                }
                L("DECLARE " + variable + " varchar(12); SET " + variable + "='" + codigo + "';");
                Fila("Partida", ("CodPartida", V(variable)), ("CodPresupuesto", V("@presupuesto")), ("PropioPartida", "01"), ("Nivel", 6),
                    ("Descripcion", n.Descripcion), ("CodigoAlterno", n.Codigo), ("CodUnidad", V(unidades[Unidad(n.Unidad)])), ("Tipo", 0), ("Grupo", 1),
                    ("RendimientoMO", n.RendimientoDiario), ("RendimientoEQ", n.RendimientoDiario), ("Jornada", n.JornadaHoras), ("Precio1", n.PrecioUnitario),
                    ("FactorMO", 1m), ("FactorMT", 1m), ("FactorEQ", 1m), ("FactorSC", 1m), ("FactorSP", 1m), ("FactorRendimientoMO", 1m), ("FactorRendimientoEQ", 1m), ("Cuadrillas", 1));
            }
            // Todas las partidas existen antes de insertar referencias entre sus análisis.
            foreach (var p in modelo.Presupuestos)
            foreach (var n in p.Nodos.Where(n => !n.EsTitulo))
            foreach (var grupo in Agrupar(p, n))
            {
                var l = grupo.First(); decimal cantidad = grupo.Sum(x => x.Cantidad);
                bool sub = l.Grupo == MYGGrupoRecurso.Subpartidas;
                // S10 recalcula con estas cifras de destino. Evitar que la
                // cuadrilla use un rendimiento/jornada que no se importarán.
                decimal rendimiento = MYGSqlS10.AdaptarNumero("Partida", "RendimientoMO", n.RendimientoDiario);
                decimal jornada = MYGSqlS10.AdaptarNumero("Partida", "Jornada", n.JornadaHoras);
                decimal consumo = MYGSqlS10.AdaptarNumero("PartidaDetalle", "Cantidad", cantidad);
                decimal divisor = Unidad(l.Unidad).StartsWith('H') ? jornada : 1m;
                decimal cuadrilla = !sub && l.Grupo is MYGGrupoRecurso.ManoObra or MYGGrupoRecurso.Equipo
                    ? consumo * rendimiento / divisor : 0;
                Fila("PartidaDetalle", ("CodPartida", V(partidas[(p.Id, n.Id)])), ("CodPresupuesto", V("@presupuesto")), ("PropioPartida", "01"), ("Tipo", sub ? 2 : 1),
                    ("CodInsumo", sub ? "9999999999" : V(BuscarRecurso(p, l).Variable)), ("CodPartidaR", sub ? V(partidas[(p.Id, l.SubpartidaId)]) : "999999999999"),
                    ("CodPresupuestoR", sub ? V("@presupuesto") : "9999999"), ("PropioPartidaR", sub ? "01" : "99"), ("Cuadrilla", cuadrilla), ("Cantidad", cantidad));
            }
        }
        private IEnumerable<IGrouping<string, MYGLineaAcuExportacionS10>> Agrupar(MYGPresupuestoExportacionS10 p, MYGNodoExportacionS10 n)
            => n.Analisis.GroupBy(l => l.Grupo == MYGGrupoRecurso.Subpartidas ? "S:" + l.SubpartidaId : BuscarRecurso(p, l).Variable, StringComparer.Ordinal);

        private void CrearSubpresupuesto(MYGPresupuestoExportacionS10 p, string sub)
        {
            Fila("Subpresupuesto", ("CodPresupuesto", V("@presupuesto")), ("CodSubpresupuesto", sub), ("Descripcion", p.Nombre), ("Cantidad", 1m),
                ("CostoDirectoBase1", p.Resumen.CostoDirecto), ("CostoIndirectoBase1", p.Resumen.Total - p.Resumen.CostoDirecto), ("CostoBase1", p.Resumen.Total),
                ("CostoDirectoOferta1", p.Resumen.CostoDirecto), ("CostoIndirectoOferta1", p.Resumen.Total - p.Resumen.CostoDirecto), ("CostoOferta1", p.Resumen.Total),
                ("Concluido", false), ("CodAlterno", p.Codigo));
            int posicion = 0;
            foreach (var n in p.Nodos)
            {
                string item = (++posicion).ToString("000000000000000", CultureInfo.InvariantCulture);
                Fila("SubpresupuestoDetalle", ("CodPresupuesto", V("@presupuesto")), ("CodSubpresupuesto", sub), ("Item", item),
                    ("Orden", n.Codigo), ("ItemAlterno", n.Codigo), ("Secuencial", posicion), ("Descripcion", n.Descripcion), ("Unidad", n.EsTitulo ? "" : n.Unidad),
                    ("Tipo", n.EsTitulo ? 5 : 1), ("Nivel", n.EsTitulo ? 0 : 1), ("Metrado", n.Cantidad), ("MetradoBase", n.Cantidad),
                    ("Precio1", n.PrecioUnitario), ("PrecioBase1", n.PrecioUnitario), ("Parcial1", n.Parcial), ("ParcialBase1", n.Parcial),
                    ("CodTitulo", n.EsTitulo ? V(titulos[(p.Id, n.Id)]) : "9999999"), ("CodPartida", n.EsTitulo ? "999999999999" : V(partidas[(p.Id, n.Id)])),
                    ("CodPresupuestoPartida", n.EsTitulo ? "9999999" : V("@presupuesto")), ("PropioPartida", n.EsTitulo ? "99" : "01"));
                if (n.EsTitulo) continue;
                // Las cachés de análisis las genera el procesador nativo de S10.
                Fila("PresupuestoPartida", ("CodPresupuesto", V("@presupuesto")), ("CodSubpresupuesto", sub), ("CodPartida", V(partidas[(p.Id, n.Id)])),
                    ("CodPresupuestoPartida", V("@presupuesto")), ("PropioPartida", "01"), ("Precio1", n.PrecioUnitario), ("Precio2", 0m), ("PrecioDescompuesto1", n.PrecioUnitario));
            }
            int linea = 0;
            foreach (var f in p.Pie)
            {
                if (++linea > 99) throw new InvalidDataException("El pie del presupuesto supera las 99 líneas de S10.");
                string codigo = linea.ToString("00", CultureInfo.InvariantCulture);
                bool directo = linea == 1 && f.Concepto == null && f.Importe == p.Resumen.CostoDirecto;
                string variable = directo ? "nDirecto" : "myg" + codigo;
                string formula = directo ? "nDirecto" : D(f.Importe);
                Fila("PieSubpresupuesto", ("CodPresupuesto", V("@presupuesto")), ("CodSubpresupuesto", sub), ("Linea", codigo),
                    ("Descripcion", f.Nombre), ("Variable", variable), ("Formula", formula), ("Omitido", false));
                Fila("ResultadoPieSubpresupuesto", ("CodPresupuesto", V("@presupuesto")), ("CodSubpresupuesto", sub), ("Linea", codigo),
                    ("Descripcion", f.Nombre), ("Formula", formula), ("Valor1", f.Importe), ("Valor2", 0m), ("ValorConFactor", f.Importe));
            }
            L("IF (SELECT COUNT(*) FROM dbo.SubpresupuestoDetalle WHERE CodPresupuesto=@presupuesto AND CodSubpresupuesto='" + sub + "')<>" + p.Nodos.Count + " RAISERROR(N'No coincide el número de filas exportadas.',16,1);");
            // SUM(ROUND(parcial)) puede diferir de ROUND(SUM(parcial)), en
            // particular con importes importados que MYG conserva íntegros.
            decimal directoDestino = p.Nodos.Where(n => !n.EsTitulo)
                .Sum(n => MYGSqlS10.AdaptarNumero("SubpresupuestoDetalle", "Parcial1", n.Parcial));
            if (directoDestino != p.Resumen.CostoDirecto)
                avisos.Add("S10 subpresupuesto «" + p.Nombre + "»: la suma de parciales exportados es " + D(directoDestino)
                    + ", frente al costo directo original " + D(p.Resumen.CostoDirecto)
                    + ". El resumen y el pie conservan sus importes de MYG ajustados a cada columna; compare los totales al reprocesar en S10.");
            L("IF (SELECT COALESCE(SUM(Parcial1),0) FROM dbo.SubpresupuestoDetalle WHERE CodPresupuesto=@presupuesto AND CodSubpresupuesto='" + sub + "' AND Tipo IN(1,2))<>" + D(directoDestino) + " RAISERROR(N'No coincide el costo directo exportado.',16,1);");
        }

        private static void ComprobarEsquema(StringBuilder b, string nombre)
        {
            var t = MYGSqlS10.Tabla(nombre);
            b.AppendLine("IF OBJECT_ID(N'dbo." + nombre + "',N'U') IS NULL RAISERROR(N'La base seleccionada no contiene la tabla S10 " + nombre + ".',16,1);");
            foreach (var c in t.Columnas)
            {
                string longitud = c.Tipo is "varchar" or "char" or "nvarchar" or "nchar" or "binary" or "varbinary" && c.Longitud >= 0 ? " AND c.max_length>=" + c.Longitud : "";
                string numero = c.Tipo is "numeric" or "decimal" ? " AND c.precision>=" + c.Precision + " AND c.scale=" + c.Escala : "";
                string texto = c.Tipo is "varchar" or "char" ? " AND COLLATIONPROPERTY(c.collation_name,'CodePage')=1252" : "";
                b.AppendLine("IF NOT EXISTS(SELECT 1 FROM sys.columns c JOIN sys.types t ON t.user_type_id=c.user_type_id WHERE c.object_id=OBJECT_ID(N'dbo." + nombre + "') AND c.name=N'" + c.Nombre + "' AND t.name=N'" + c.Tipo + "'" + longitud + numero + texto + ") RAISERROR(N'Esquema S10 incompatible: " + nombre + "." + c.Nombre + ".',16,1);");
            }
        }
    }
}
