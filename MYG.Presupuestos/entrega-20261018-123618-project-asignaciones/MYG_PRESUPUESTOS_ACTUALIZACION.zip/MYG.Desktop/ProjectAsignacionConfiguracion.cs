using System;
using System.Globalization;
using System.IO;

namespace MYG_2027;

// Project puede recalcular las asignaciones al cambiar duración, avance o
// divisiones. Compartir estas operaciones permite comprobar el contrato sin COM.
internal static class MYGConfiguracionAsignacionProject
{
    internal static bool Restaurar(MYGAsignacionExportacionProject datos, int tipo,
        Func<string, object> leer, Action<string, object> escribir)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        ArgumentNullException.ThrowIfNull(escribir);
        var magnitud = Magnitud(datos, tipo);
        if (!magnitud.HasValue) return false;
        var (campo, esperado, tolerancia) = magnitud.Value;
        if (NumeroIgual(leer(campo), esperado, tolerancia)) return false;
        // No escribir Cost en trabajo/material: se calcula mediante la tarifa.
        // En duración fija, Work ajusta la dedicación conservando la duración.
        escribir(campo, (double)esperado);
        return true;
    }

    internal static void Verificar(MYGAsignacionExportacionProject datos, int tipo,
        string nombreRecurso, string nombreTarea, Func<string, object> leer)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        var magnitud = Magnitud(datos, tipo);
        if (!magnitud.HasValue) return;
        var (campo, esperado, tolerancia) = magnitud.Value;
        object recibido = leer(campo);
        if (!NumeroIgual(recibido, esperado, tolerancia))
            throw new InvalidOperationException("Microsoft Project cambió la asignación del recurso «" + nombreRecurso +
                "» en la tarea «" + nombreTarea + "». Campo: " + campo +
                (campo == "Work" ? " (minutos)" : "") + ". Esperado: " + esperado.ToString(CultureInfo.InvariantCulture) +
                "; recibido: " + (recibido == null || recibido == DBNull.Value ? "(sin valor)" : Convert.ToString(recibido, CultureInfo.InvariantCulture)) +
                ". No se reemplazó el archivo de destino.");
    }

    private static (string Campo, decimal Esperado, decimal Tolerancia)? Magnitud(
        MYGAsignacionExportacionProject datos, int tipo) => tipo switch
    {
        1 => datos.TrabajoHoras.HasValue ? ("Work", datos.TrabajoHoras.Value * 60m, 0.01m) : null,
        0 => datos.Unidades.HasValue ? ("Units", datos.Unidades.Value, 0.000001m) : null,
        2 => ("Cost", datos.Costo, 0.02m),
        _ => throw new InvalidDataException("Tipo de recurso de Microsoft Project desconocido.")
    };

    private static bool NumeroIgual(object valor, decimal esperado, decimal tolerancia)
    {
        if (valor == null) return false;
        try { return Math.Abs(Convert.ToDecimal(valor, CultureInfo.InvariantCulture) - esperado) <= tolerancia; }
        catch (FormatException) { return false; }
        catch (InvalidCastException) { return false; }
        catch (OverflowException) { return false; }
    }
}
