using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

// Presentación compartida por la estructura del presupuesto y sus desgloses.
// Plegar conserva las filas calculadas; sólo cambia cuáles están en la tabla.
internal static class MYGJerarquiaTablaPresupuesto
{
    internal static int Sangria(int nivel, int dpi) => (int)((nivel * 13 + 3) * dpi / 96F);

    internal static bool EsFlecha(int x, int nivel, int dpi) =>
        x >= Sangria(nivel, dpi) && x < Sangria(nivel, dpi) + (int)(20 * dpi / 96F);

    internal static void DibujarFlecha(Graphics grafico, Rectangle limites, int nivel, int dpi,
        bool plegado, Color color, float? angulo = null)
    {
        float escala = dpi / 96F, y = limites.Top + limites.Height / 2F;
        float centro = limites.Left + Sangria(nivel, dpi) + 8 * escala, radio = 4 * escala;
        var suavizado = grafico.SmoothingMode;
        var estado = grafico.Save();
        try
        {
            grafico.SmoothingMode = SmoothingMode.AntiAlias;
            grafico.TranslateTransform(centro, y);
            grafico.RotateTransform(angulo ?? (plegado ? 0 : 90));
            using var pincel = new SolidBrush(color);
            grafico.FillPolygon(pincel, new[]
            {
                new PointF(-radio / 2, -radio), new PointF(-radio / 2, radio), new PointF(radio, 0)
            });
        }
        finally { grafico.Restore(estado); grafico.SmoothingMode = suavizado; }
    }

    internal static List<T> Visibles<T>(IEnumerable<T> filas, Func<T, int> nivel,
        Func<T, bool> plegado, bool filtrando = false)
    {
        var visibles = new List<T>();
        int nivelPlegado = int.MaxValue;
        foreach (var fila in filas)
        {
            int actual = nivel(fila);
            if (actual <= nivelPlegado) nivelPlegado = int.MaxValue;
            if (!filtrando && actual > nivelPlegado) continue;
            visibles.Add(fila);
            if (!filtrando && plegado(fila)) nivelPlegado = actual;
        }
        return visibles;
    }

    internal static void AplicarFilas(DataGridView tabla, List<DataGridViewRow> todas,
        List<DataGridViewRow> visibles, bool restaurarSeleccion = true, string columnaPredeterminada = null)
    {
        var conjunto = visibles.ToHashSet();
        var seleccionada = tabla.CurrentRow;
        string columna = tabla.CurrentCell?.OwningColumn.Name ?? columnaPredeterminada ?? tabla.Columns[0].Name;
        var primera = tabla.FirstDisplayedScrollingRowIndex >= 0
            ? tabla.Rows[tabla.FirstDisplayedScrollingRowIndex] : null;
        int horizontal = tabla.HorizontalScrollingOffset;
        if (restaurarSeleccion && seleccionada != null && !conjunto.Contains(seleccionada))
        {
            // Si un plegado oculta la selección, conservar su antecesor visible.
            int indice = todas.IndexOf(seleccionada);
            seleccionada = todas.Take(indice).LastOrDefault(conjunto.Contains);
        }
        var ajusteFilas = tabla.AutoSizeRowsMode;
        tabla.SuspendLayout(); tabla.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        try
        {
            if (tabla.CurrentRow != null && !conjunto.Contains(tabla.CurrentRow))
            { tabla.ClearSelection(); tabla.CurrentCell = null; }
            for (int i = tabla.Rows.Count - 1; i >= 0; i--)
                if (!conjunto.Contains(tabla.Rows[i])) tabla.Rows.RemoveAt(i);
            int posicion = 0;
            while (posicion < visibles.Count)
            {
                if (posicion < tabla.Rows.Count && ReferenceEquals(tabla.Rows[posicion], visibles[posicion]))
                { posicion++; continue; }
                int inicio = posicion;
                while (posicion < visibles.Count && visibles[posicion].DataGridView == null) posicion++;
                tabla.Rows.InsertRange(inicio, visibles.GetRange(inicio, posicion - inicio).ToArray());
            }
            if (restaurarSeleccion && seleccionada?.DataGridView == tabla &&
                !ReferenceEquals(tabla.CurrentRow, seleccionada))
            {
                tabla.ClearSelection();
                tabla.CurrentCell = seleccionada.Cells[columna]; seleccionada.Selected = true;
            }
            else if (restaurarSeleccion && seleccionada == null)
            { tabla.ClearSelection(); tabla.CurrentCell = null; }
            if (primera?.DataGridView == tabla) tabla.FirstDisplayedScrollingRowIndex = primera.Index;
            tabla.HorizontalScrollingOffset = horizontal;
        }
        finally { tabla.AutoSizeRowsMode = ajusteFilas; tabla.ResumeLayout(); }
    }
}
