using System;
using System.Linq;

namespace MYG_2027;

/// <summary>Las ediciones locales de cantidad y configuración BIM conservan sólo sus valores anteriores.</summary>
public sealed class MYGEntradaHistorialProyecto
{
    private readonly MYGProyectoDocumento instantanea;
    private readonly string presupuestoId, partidaId;
    private readonly decimal cantidad;
    private readonly MYGFuenteMetrado fuente;
    private readonly ConfiguracionRevitAnterior configuracionRevit;

    private sealed class ConfiguracionRevitAnterior
    {
        internal string Plantilla, Parametro, Regla, Valor, Estado, Mensaje;
        internal System.Collections.Generic.List<FiltroPlanificacion> Filtros;
        internal int CantidadFiltros;
    }

    private MYGEntradaHistorialProyecto(MYGProyectoDocumento instantanea) => this.instantanea = instantanea;

    private MYGEntradaHistorialProyecto(string presupuestoId, string partidaId, decimal cantidad, MYGFuenteMetrado fuente)
    {
        this.presupuestoId = presupuestoId; this.partidaId = partidaId;
        this.cantidad = cantidad; this.fuente = fuente;
    }

    private MYGEntradaHistorialProyecto(string presupuestoId, string partidaId, ConfiguracionRevitAnterior configuracion)
    { this.presupuestoId = presupuestoId; this.partidaId = partidaId; configuracionRevit = configuracion; }

    public static MYGEntradaHistorialProyecto Capturar(MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        return new(MYGProyectoStorage.Copia(documento));
    }

    public static MYGEntradaHistorialProyecto CapturarCantidad(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        var original = Resolver(documento, presupuesto.Id, partida.Id);
        return new(presupuesto.Id, original.Id, original.Costos.Cantidad, original.Costos.FuenteMetrado);
    }

    public static MYGEntradaHistorialProyecto CapturarConfiguracionRevit(MYGProyectoDocumento documento,
        MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida)
    {
        ArgumentNullException.ThrowIfNull(presupuesto);
        ArgumentNullException.ThrowIfNull(partida);
        var original = Resolver(documento, presupuesto.Id, partida.Id);
        var actual = documento.Presupuestos.First(p => string.Equals(p.Id, presupuesto.Id, StringComparison.OrdinalIgnoreCase));
        return new(presupuesto.Id, original.Id, new ConfiguracionRevitAnterior
        {
            Plantilla = original.Plantilla, Filtros = MYGProyectoStorage.Copia(original.Filtros),
            Parametro = original.Parametro, Regla = original.Regla, Valor = original.Valor,
            Estado = original.EstadoRevit, Mensaje = original.MensajeRevit, CantidadFiltros = actual.CantidadFiltros
        });
    }

    /// <summary>Debe capturarse antes de aplicar para conservar el orden de deshacer/rehacer.</summary>
    public MYGEntradaHistorialProyecto CapturarInversa(MYGProyectoDocumento documento)
    {
        if (instantanea != null) return Capturar(documento);
        var original = Resolver(documento, presupuestoId, partidaId);
        if (configuracionRevit != null)
            return CapturarConfiguracionRevit(documento,
                documento.Presupuestos.First(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)), original);
        return new(presupuestoId, partidaId, original.Costos.Cantidad, original.Costos.FuenteMetrado);
    }

    /// <summary>Vista aislada para comprobar permisos antes de aplicar. No se necesita para una edición local.</summary>
    public MYGProyectoDocumento CrearCandidato(MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (instantanea != null) return MYGProyectoStorage.Copia(instantanea);
        var candidato = MYGProyectoStorage.Copia(documento);
        return Aplicar(candidato);
    }

    public MYGProyectoDocumento Aplicar(MYGProyectoDocumento documento)
    {
        ArgumentNullException.ThrowIfNull(documento);
        if (instantanea != null) return instantanea;
        // Resolver ambos IDs antes de modificar: una fila eliminada o una
        // entrada ajena al proyecto no debe dejar un cambio parcial.
        var original = Resolver(documento, presupuestoId, partidaId);
        if (configuracionRevit != null)
        {
            original.Plantilla = configuracionRevit.Plantilla;
            original.Filtros = MYGProyectoStorage.Copia(configuracionRevit.Filtros);
            original.Parametro = configuracionRevit.Parametro; original.Regla = configuracionRevit.Regla; original.Valor = configuracionRevit.Valor;
            original.EstadoRevit = configuracionRevit.Estado; original.MensajeRevit = configuracionRevit.Mensaje;
            documento.Presupuestos.First(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).CantidadFiltros = configuracionRevit.CantidadFiltros;
            return documento;
        }
        original.Costos.Cantidad = cantidad;
        original.Costos.FuenteMetrado = fuente;
        return documento;
    }

    private static ItemPresupuestoDelphin Resolver(MYGProyectoDocumento documento, string presupuestoId, string partidaId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var presupuesto = documento.Presupuestos?.FirstOrDefault(p => p != null &&
            string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase));
        var partida = presupuesto?.Items?.FirstOrDefault(i => i != null &&
            string.Equals(i.Id, partidaId, StringComparison.OrdinalIgnoreCase));
        if (partida?.Costos == null || MYGProyectoStorage.EsTitulo(partida))
            throw new InvalidOperationException("La partida del historial ya no pertenece a este proyecto.");
        return partida;
    }
}
