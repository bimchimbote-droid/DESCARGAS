using MYG.Externo;

namespace MYG_2027;

public sealed class ConectorRevitDesactualizadoException : InvalidOperationException
{
    public ConectorRevitDesactualizadoException(string mensaje) : base(mensaje) { }
}

/// <summary>Diagnóstico de capacidad sobre la respuesta real, no sobre el archivo del editor.</summary>
public static class MYGCompatibilidadConectorRevit
{
    public static void ExigirTablasActivos(DocumentoRevitInfo documento, int pid)
    {
        // El primer conector compatible ya devolvía esta identidad. Conservar
        // su compatibilidad aunque no incluya los nuevos datos de diagnóstico.
        if (!string.IsNullOrWhiteSpace(documento?.Id) && !string.IsNullOrWhiteSpace(documento.DocumentoRevitId)) return;
        string detalle = string.IsNullOrWhiteSpace(documento?.VersionConector) ? ""
            : "\nVersión cargada: " + documento.VersionConector;
        if (!string.IsNullOrWhiteSpace(documento?.RutaConector)) detalle += "\nDLL cargada: " + documento.RutaConector;
        throw new ConectorRevitDesactualizadoException(
            "Revit respondió (PID " + pid + "), pero el conector cargado no admite tablas por activo. "
            + "Actualizar MYG Presupuestos no reemplaza automáticamente el conector que ya está cargado en Revit.\n\n"
            + "1. Cierre Revit.\n"
            + "2. Desde la carpeta del código actualizado ejecute en PowerShell:\n"
            + ".\\scripts\\Actualizar-Conector.ps1\n"
            + "3. Abra Revit de nuevo y vuelva a pulsar «Tablas del modelo abierto»."
            + detalle);
    }
}
