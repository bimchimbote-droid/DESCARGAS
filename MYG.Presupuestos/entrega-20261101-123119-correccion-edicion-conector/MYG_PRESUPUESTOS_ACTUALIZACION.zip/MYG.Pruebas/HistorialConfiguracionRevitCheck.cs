using MYG_2027;

internal static class HistorialConfiguracionRevitCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Historial BIM", "Presupuesto");
        var p = documento.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Columnas", Unidad = "m³",
            Plantilla = "PLANTILLA_ANTERIOR", Parametro = "Tipo", Regla = "es igual a", Valor = "Anterior",
            EstadoRevit = "OK", MensajeRevit = "Revisada", Filtros = null
        };
        var ajena = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Ajena" };
        p.Items.AddRange(new[] { partida, ajena });
        var hoja = partida.Costos.Hoja;
        var anterior = MYGEntradaHistorialProyecto.CapturarConfiguracionRevit(documento, p, partida);
        partida.Plantilla = "PLANTILLA_NUEVA";
        partida.Filtros = new() { new() { Parametro = "Nivel", Regla = "es igual a", Valor = "01" } };
        partida.Parametro = "Nivel"; partida.Regla = "es igual a"; partida.Valor = "01";
        partida.EstadoRevit = partida.MensajeRevit = null;
        p.CantidadFiltros = 5;
        partida.Costos.Cantidad = 123m;
        ajena.Descripcion = "Ajena conservada";
        var inversa = anterior.CapturarInversa(documento);
        var candidato = anterior.CrearCandidato(documento);
        Exige(candidato.Presupuestos.Single().Items.First().Plantilla == "PLANTILLA_ANTERIOR" &&
            partida.Plantilla == "PLANTILLA_NUEVA", "El candidato para comprobar permisos cambió el documento original.");
        Exige(ReferenceEquals(anterior.Aplicar(documento), documento) && ReferenceEquals(hoja, partida.Costos.Hoja) &&
            partida.Plantilla == "PLANTILLA_ANTERIOR" && partida.Filtros == null && partida.Parametro == "Tipo" &&
            partida.Regla == "es igual a" && partida.Valor == "Anterior" && partida.EstadoRevit == "OK" && partida.MensajeRevit == "Revisada" &&
            p.CantidadFiltros == 1 && partida.Costos.Cantidad == 123m && ajena.Descripcion == "Ajena conservada",
            "Deshacer configuración perdió campos anteriores, referencias de costos o cambios ajenos.");
        inversa.Aplicar(documento);
        Exige(partida.Plantilla == "PLANTILLA_NUEVA" && partida.Filtros.Single().Valor == "01" &&
            partida.EstadoRevit == null && partida.MensajeRevit == null && p.CantidadFiltros == 5,
            "Rehacer no restauró la configuración nueva ni el número de filtros.");
        partida.Filtros[0].Valor = "Modificada después";
        inversa.Aplicar(documento);
        Exige(partida.Filtros[0].Valor == "01", "Aplicar historial expuso sus filtros a cambios posteriores.");
        pasa("Historial BIM compacto restaura plantilla, filtros legados, estado y número de columnas sin tocar costos ni partidas ajenas");

        // Una especificación grande no forma parte de esta operación. El umbral
        // comprueba asignaciones de memoria, no tiempos dependientes del equipo.
        ajena.Costos.EspecificacionRtf = new string('X', 4 * 1024 * 1024);
        _ = MYGEntradaHistorialProyecto.CapturarConfiguracionRevit(documento, p, partida);
        long bytes = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 100; n++)
            _ = MYGEntradaHistorialProyecto.CapturarConfiguracionRevit(documento, p, partida);
        long asignados = GC.GetAllocatedBytesForCurrentThread() - bytes;
        Exige(asignados < 1024 * 1024,
            "Capturar una configuración volvió a copiar las especificaciones o el proyecto completo.");
        p.Items.Remove(partida);
        string sinPartida = MYGProyectoStorage.Firma(documento);
        bool rechazado = false;
        try { anterior.Aplicar(documento); }
        catch (InvalidOperationException) { rechazado = true; }
        Exige(rechazado && MYGProyectoStorage.Firma(documento) == sinPartida,
            "El historial de una partida eliminada cambió parcialmente el proyecto.");
        pasa("Cien capturas BIM con especificación ajena de 4 MiB usan menos de 1 MiB y un historial huérfano se rechaza sin cambios");
    }
}
