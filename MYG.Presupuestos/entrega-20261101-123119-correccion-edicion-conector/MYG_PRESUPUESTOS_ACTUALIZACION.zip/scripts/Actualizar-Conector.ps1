param([string]$RevitInstallDir = 'C:\Program Files\Autodesk\Revit 2027')
$ErrorActionPreference = 'Stop'
$proyecto = Join-Path (Split-Path -Parent $PSScriptRoot) 'MYG.Revit2027\MYG.Revit2027.csproj'
if (!(Test-Path -LiteralPath $proyecto -PathType Leaf)) {
    throw 'Ejecute este script desde la carpeta de codigo fuente actualizada de MYG.Presupuestos.'
}
# Sin -Origen: el instalador reconstruye siempre las fuentes actuales y verifica
# la version/copia antes de reemplazar el registro del usuario de Revit.
& (Join-Path $PSScriptRoot 'Instalar-Conector.ps1') -RevitInstallDir $RevitInstallDir
