# Corrección: edición de plantilla/filtros y conector cargado en Revit

Esta actualización se aplica **sobre la entrega anterior de tablas por activo**:
ZIP publicado en `bimchimbote-droid/DESCARGAS`, commit
`3b96e030919c1d2bd55e939b66bd43b57477fae0`.
La base del código sigue siendo `main` de `bimchimbote-droid/MYG.Presupuestos`,
commit `14cc8c2cf78d7a60901c3cd175adbcfc761eac39`, más aquella entrega.
Se conservan el botón y el flujo por activo previamente implementados.

## Qué significa el mensaje de la captura

Revit sí está respondiendo, pero el conector que tiene cargado no devuelve la
identidad persistente necesaria para reconocer el activo. Compilar o actualizar
el ejecutable de MYG no reemplaza la DLL que Revit ya tiene cargada en memoria.
Hay que actualizar también el conector y reiniciar Revit.

La selección anterior del instalador podía priorizar `Conector/` o
`dist/Conector/` antiguos frente a la compilación del código actual. La corrección
evita esa selección, comprueba la versión instalada y compara los archivos
copiados por SHA-256. La nueva versión del conector es **1.1.0.0**.

## Aplicar la corrección

1. Respalde o confirme sus cambios locales. Cierre MYG y todas las sesiones de
   Revit. Copie los archivos del ZIP en la raíz del proyecto respetando sus rutas.
   Se entregan archivos completos; compare sus modificaciones locales antes de
   sustituirlos. No hay eliminaciones ni migraciones de bases de datos.
2. Desde PowerShell, en la raíz del código actualizado, con SDK .NET 10 y Revit
   2027 instalado:

   ```powershell
   dotnet build .\MYG.Presupuestos.sln -c Release -m:1 -nr:false
   if ($LASTEXITCODE -ne 0) { throw 'La compilación falló; no continúe con la instalación.' }
   .\scripts\Actualizar-Conector.ps1
   ```

3. Ejecute MYG recién compilado y vuelva a abrir Revit. Abra su modelo y pulse
   **Tablas del modelo abierto**. Mantenga la vinculación y asignaciones existentes;
   no necesita volver a registrar el activo si ya estaba vinculado correctamente.

El instalador muestra la ruta y versión de la DLL que acaba de instalar. Si
detecta otro manifiesto con el mismo identificador MYG, informa las rutas y
detiene la instalación para evitar que otra copia siga cargándose. No modifica
los manifiestos de otros complementos. No elimine archivos de otros addins.

Si Revit todavía informa un conector anterior después de la instalación, cierre
todos sus procesos, compruebe el manifiesto que señala el instalador y abra de
nuevo Revit. Una sesión que quedó abierta sigue usando sus DLL antiguas.

## Edición de plantilla y filtros

La edición se confirma al salir del campo o terminar la celda, conservando el
comportamiento habitual de edición y cancelación. La escritura es local y no
consulta Revit. No requiere guardar toda la obra para aplicar el cambio en
memoria; guarde normalmente para conservarlo en disco.

Se elimina de ese recorrido la copia completa del proyecto para cada cambio,
la reconstrucción de todas las filas y los recálculos de costos. El historial
conserva solamente los datos de configuración necesarios para Deshacer/Rehacer.
La fila BIM oculta se mantiene sincronizada para que guardar, cambiar de partida
o abrir las herramientas avanzadas no restaure valores anteriores.

## Comprobaciones en Windows

- Escriba una plantilla y termine la edición: debe quedar aplicada sin reconstruir
  la estructura ni los importes de la obra.
- Edite parámetro, regla y valor; cambie de partida y vuelva. Los valores deben
  conservarse, también al guardar y reabrir.
- Compruebe Deshacer/Rehacer de plantilla y filtros y que no cambien cantidades,
  precios, hojas ni resultados de metrados.
- Actualice el conector con Revit cerrado, compruebe versión 1.1.0.0, reinicie y
  repita el botón con su modelo activo.
- Repita una creación/actualización y compruebe que no se acumulan tablas.

La compilación y las pruebas automáticas se realizan en Linux. La respuesta
visual y la ejecución dentro de Revit necesitan Windows y no deben confundirse
con una prueba real ejecutada en su equipo. Los resultados exactos de esta
entrega se indican en el mensaje de entrega.

Resultados de esta corrección con SDK .NET 10.0.100: solución Release compilada
con cero errores y cero advertencias; 793 comprobaciones del núcleo aprobadas,
incluidos dos grupos focales de historial y ocho grupos de tablas por activo y
compatibilidad. Las nuevas pruebas de interfaz compilaron, pero no se ejecutaron
en Linux. Se omitieron las muestras externas no proporcionadas y Named Pipes
Windows. El fallo previo de la suite independiente de nube no forma parte de
esta corrección y no se presenta como resuelto.

El instalador pasó 14 comprobaciones controladas en PowerShell 7.5.4: versión
antigua, Revit abierto, prioridad a las fuentes, manifiestos duplicados,
integridad de copia y recuperación ante fallos. Se instaló la DLL real 1.1.0.0
en una carpeta temporal, con 38 archivos verificados por SHA-256. Estas pruebas
simulan el proceso de Revit y la compilación; no equivalen a instalar en un
equipo Windows real ni a ejecutar la API de Revit.

## GitHub

El ZIP se publica únicamente en el repositorio independiente `DESCARGAS` según
la autorización vigente. Tras validar localmente, revise **Cambios de Git** en
Visual Studio, haga Commit y Push a su rama y compruebe el resultado en GitHub.
La entrega del ZIP no publica los cambios del repositorio del código.
