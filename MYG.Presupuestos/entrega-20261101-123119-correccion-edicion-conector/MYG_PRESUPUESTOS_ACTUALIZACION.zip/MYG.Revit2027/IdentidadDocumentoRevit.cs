using Autodesk.Revit.DB;
using MYG.Externo;
using MYG_2027;

namespace MYG.Conector;

/// <summary>Identidad del modelo obtenida de Revit, independiente del nombre y de la caché local.</summary>
internal static class IdentidadDocumentoRevit
{
    internal static DocumentoRevitInfo Describir(Document documento, string sesionId)
    {
        var info = new DocumentoRevitInfo
        {
            Id = sesionId,
            Nombre = documento.Title,
            Ruta = documento.PathName,
            CapacidadTablasActivos = 1,
            VersionConector = typeof(IdentidadDocumentoRevit).Assembly.GetName().Version?.ToString(),
            RutaConector = typeof(IdentidadDocumentoRevit).Assembly.Location,
            Origen = MYGOrigenActivoRevit.Local
        };
        if (documento.IsModelInCloud)
        {
            var ruta = documento.GetCloudModelPath();
            var proyecto = ruta.GetProjectGUID();
            var modelo = ruta.GetModelGUID();
            if (proyecto == Guid.Empty || modelo == Guid.Empty)
                throw new InvalidOperationException("Revit no devolvió la identidad del modelo Autodesk. No se puede vincular el activo.");
            info.Origen = MYGOrigenActivoRevit.Autodesk;
            info.ProyectoAutodeskId = proyecto.ToString("D");
            info.ModeloAutodeskId = modelo.ToString("D");
            info.DocumentoRevitId = "autodesk:" + info.ProyectoAutodeskId + ":" + info.ModeloAutodeskId;
        }
        else
        {
            if (documento.IsWorkshared && documento.GetWorksharingCentralModelPath() is ServerPath)
            {
                Guid central = documento.WorksharingCentralGUID;
                if (central == Guid.Empty)
                    throw new InvalidOperationException("Revit no devolvió la identidad del modelo central. No se puede vincular el activo.");
                info.DocumentoRevitId = "local:central:" + central.ToString("D");
                return info;
            }
            Guid identificador = documento.CreationGUID;
            if (identificador == Guid.Empty)
                throw new InvalidOperationException("Revit no devolvió una identidad persistente del proyecto. Guarde el modelo antes de vincularlo.");
            info.DocumentoRevitId = "local:" + identificador.ToString("D");
        }
        return info;
    }
}
