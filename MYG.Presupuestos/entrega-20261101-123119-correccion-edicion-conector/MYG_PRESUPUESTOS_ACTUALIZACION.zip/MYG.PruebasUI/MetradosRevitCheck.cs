using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class MetradosRevitCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Interfaz Revit", "Estructuras");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Muros", Unidad = "m²" };
        var otra = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(),
            TipoPropuesta = "PARTIDA", Descripcion = "Losas", Unidad = "m³", Plantilla = "Otra plantilla" };
        presupuesto.Items.Add(partida); presupuesto.Items.Add(otra);
        int historial = 0, consultas = 0, calculos = 0, notificaciones = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => historial++, () => calculos++,
            _ => { }, () => { consultas++; return Task.CompletedTask; }, _ => { });
        panel.CambioConfiguracionMetradosRevit = _ => notificaciones++;
        panel.InicializarCatalogos(() => "no-usado", () => true, () => { });
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
        var tipo = typeof(MYGPanelPresupuesto);
        T Campo<T>(string nombre) => (T)tipo.GetField(nombre, flags)!.GetValue(panel)!;
        void Cargar(ItemPresupuestoDelphin item)
        {
            tipo.GetField("actual", flags)!.SetValue(panel, item);
            tipo.GetMethod("CargarConfiguracionMetradosRevit", flags)!.Invoke(panel, null);
        }
        Cargar(partida);
        var plantilla = Campo<TextBox>("plantillaMetradoRevit");
        var filtros = Campo<DataGridView>("filtrosMetradoRevit");
        var pestanas = Campo<TabControl>("detalle");
        exige(pestanas.TabPages.Cast<TabPage>().Any(p => p.Text == "Metrados Revit"), "Falta la pestaña Revit junto al metrado XLS.");
        exige(filtros.Rows.Count == 5 && !filtros.AllowUserToAddRows, "La interfaz debe limitarse a cinco filtros.");
        plantilla.Text = "Metrado de muros";
        filtros.Rows[4].Cells["PARAMETRO"].Value = "Nivel";
        filtros.Rows[4].Cells["REGLA"].Value = "Igual";
        filtros.Rows[4].Cells["VALOR"].Value = "01";
        panel.FinalizarEdicion();
        exige(partida.Plantilla == "Metrado de muros" && partida.Filtros.Count == 5 && partida.Filtros[4].Valor == "01",
            "No se conserva la plantilla y la posición del quinto filtro.");
        exige(historial == 1 && consultas == 0 && calculos == 0 && notificaciones == 1,
            "La edición debe registrar historial y notificar una vez sin consultar Revit ni recalcular costos.");
        panel.FinalizarEdicion();
        exige(historial == 1 && notificaciones == 1 && calculos == 0, "Finalizar sin cambios no debe duplicar historial ni solicitar cálculos.");
        Cargar(otra);
        exige(plantilla.Text == "Otra plantilla" && partida.Plantilla == "Metrado de muros", "Las partidas deben conservar configuraciones independientes.");
        Cargar(partida);
        exige(Convert.ToString(filtros.Rows[4].Cells["VALOR"].Value) == "01", "El filtro debe sobrevivir al cambio de partida.");
        partida.Filtros.Add(new FiltroPlanificacion { Parametro = "Legado", Regla = "Igual", Valor = "Conservar" });
        Cargar(partida);
        exige(filtros.ReadOnly && filtros.Rows.Count == 6, "Los filtros heredados adicionales deben conservarse y mostrarse para consulta.");
        EditorConservaFilas(exige);
    }

    private static void EditorConservaFilas(Action<bool, string> exige)
    {
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
        var proyecto = MYGProyectoStorage.Nuevo("Edición BIM local", "Estructuras");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin { Id = MYGProyectoStorage.NuevoId(), TipoPropuesta = "PARTIDA", Descripcion = "Columnas", Unidad = "m³" };
        presupuesto.Items.Add(partida);
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))!.SetValue(sesion,
            new MYG.Externo.CredencialMYG { Usuario = "prueba-local", Token = "token-sintetico-no-enviado" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, true);
        using var editor = new EditorForm(proyecto, null, sesion);
        var panel = (MYGPanelPresupuesto)typeof(EditorForm).GetField("panelPresupuesto", flags)!.GetValue(editor)!;
        var tabla = (DataGridView)typeof(EditorForm).GetField("grid", flags)!.GetValue(editor)!;
        var fila = tabla.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, partida));
        var estructura = (DataGridView)typeof(MYGPanelPresupuesto).GetField("estructura", flags)!.GetValue(panel)!;
        var filasEstructura = estructura.Rows.Cast<DataGridViewRow>().ToArray();
        typeof(MYGPanelPresupuesto).GetField("actual", flags)!.SetValue(panel, partida);
        typeof(MYGPanelPresupuesto).GetMethod("CargarConfiguracionMetradosRevit", flags)!.Invoke(panel, null);
        var plantilla = (TextBox)typeof(MYGPanelPresupuesto).GetField("plantillaMetradoRevit", flags)!.GetValue(panel)!;
        var filtros = (DataGridView)typeof(MYGPanelPresupuesto).GetField("filtrosMetradoRevit", flags)!.GetValue(panel)!;
        plantilla.Text = "PLANTILLA_COLUMNAS";
        filtros.Rows[4].Cells["PARAMETRO"].Value = "Tipo";
        filtros.Rows[4].Cells["REGLA"].Value = "es igual a";
        filtros.Rows[4].Cells["VALOR"].Value = "Placa";
        panel.FinalizarEdicion();
        exige(ReferenceEquals(fila, tabla.Rows.Cast<DataGridViewRow>().Single(r => ReferenceEquals(r.Tag, partida))) &&
            filasEstructura.SequenceEqual(estructura.Rows.Cast<DataGridViewRow>()),
            "Editar una configuración no debe reconstruir las filas del editor general ni la estructura del presupuesto.");
        exige(tabla.Columns.Contains("P5") && Convert.ToString(fila.Cells["PLANTILLA"].Value) == "PLANTILLA_COLUMNAS" &&
            Convert.ToString(fila.Cells["V5"].Value) == "Placa" && editor.CambiosPendientes,
            "La actualización local debe sincronizar la fila BIM, ampliar sólo sus columnas necesarias y marcar cambios pendientes.");
        typeof(EditorForm).GetMethod("Sincronizar", flags)!.Invoke(editor, null);
        exige(partida.Plantilla == "PLANTILLA_COLUMNAS" && partida.Filtros[4].Valor == "Placa",
            "Sincronizar después de la edición local restauró valores antiguos del editor BIM oculto.");
        typeof(EditorForm).GetMethod("Historial", flags)!.Invoke(editor, new object[] { false });
        exige(string.IsNullOrEmpty(partida.Plantilla) && presupuesto.CantidadFiltros == 1,
            "Deshacer debe restaurar la configuración y el número anterior de filtros.");
        typeof(EditorForm).GetMethod("Historial", flags)!.Invoke(editor, new object[] { true });
        exige(partida.Plantilla == "PLANTILLA_COLUMNAS" && partida.Filtros[4].Valor == "Placa" && presupuesto.CantidadFiltros == 5,
            "Rehacer debe recuperar íntegra la configuración local sin perder la posición del quinto filtro.");
    }
}
