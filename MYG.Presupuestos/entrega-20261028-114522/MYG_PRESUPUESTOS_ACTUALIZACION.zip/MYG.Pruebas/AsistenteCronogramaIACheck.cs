using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG_2027;

internal static class AsistenteCronogramaIACheck
{
    private static readonly DateTime Lunes = new(2026, 10, 5);
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private static string Firma(object valor) => JsonSerializer.Serialize(valor, Json);
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Asistente IA: " + mensaje); }
    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (ArgumentException) { return; }
        catch (JsonException) { return; }
        throw new Exception("Asistente IA aceptó " + detalle + ".");
    }
    private static string MensajeRechazo(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException ex) { return ex.Message; }
        throw new Exception("Asistente IA aceptó " + detalle + ".");
    }

    private sealed class Caso
    {
        internal MYGProyectoDocumento Doc;
        internal MYGCronograma Plan;
        internal MYGOpcionesCronogramaIA Opciones = new()
        { FechaInicio = Lunes, PlazoDiasCalendario = 30, Contexto = "Un frente; no inventar cuadrillas." };
        internal MYGPresupuestoDocumento Presupuesto => Doc.Presupuestos[0];
        internal ItemPresupuestoDelphin Partida(string id) => Presupuesto.Items.Single(i => i.Id == id);
        internal MYGTareaCronograma Tarea(string id) => Plan.Tareas.Single(t => t.PartidaId == id);
        internal MYGPaqueteCronogramaIA Paquete() => MYGAsistenteCronogramaIA.CrearPaquete(Doc, Plan, Opciones);
    }

    private static Caso Crear()
    {
        var doc = MYGProyectoStorage.Nuevo("Obra sintética IA", "ESTRUCTURAS");
        doc.Id = "DOC-IA";
        doc.Datos = new MYGDatosProyecto { FechaInicio = Lunes, FechaFin = Lunes.AddDays(29),
            Duracion = 30, UnidadDuracion = "DIAS" };
        var p = doc.Presupuestos[0]; p.Id = "PRES-IA"; doc.PresupuestoActivoId = p.Id;
        p.Costos.Insumos.Add(new MYGInsumo { Id = "INS-IA", Codigo = "MO-01", Descripcion = "Operario",
            Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 20 });
        for (int n = 1; n <= 3; n++)
        {
            string id = "P" + n;
            p.Items.Add(new ItemPresupuestoDelphin
            {
                Id = id, IdLocalMYG = id, IdPropuesta = id, TipoPropuesta = "PARTIDA", Origen = "MODELO",
                Estado = "PROPUESTA", Posicion = n, Descripcion = "Actividad " + n, Unidad = "m³",
                Costos = new MYGDatosPartida
                {
                    Cantidad = n == 1 ? 100 : 10, RendimientoDiario = 20, JornadaHoras = 8,
                    Analisis = new List<MYGRecursoACU> { new() { Id = "ACU-" + n, Grupo = MYGGrupoRecurso.ManoObra,
                        InsumoId = "INS-IA", Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 1 } }
                }
            });
        }
        MYGProyectoStorage.Renumerar(p);
        var plan = MYGMotorCronograma.CrearDesdePresupuestos(doc);
        foreach (var t in plan.Tareas.Where(t => !t.EsResumen)) t.DuracionDias = int.Parse(t.PartidaId[1..]) + 1;
        return new Caso { Doc = doc, Plan = plan };
    }

    private static MYGTareaPropuestaCronogramaIA Fila(string id, string pred = null, string tipo = "FC", int desfase = 0)
    {
        var fila = new MYGTareaPropuestaCronogramaIA { TareaId = id, Justificacion = "Secuencia constructiva revisable." };
        fila.Predecesoras = pred == null ? new() : new() { new MYGPredecesoraPropuestaCronogramaIA
            { PredecesoraId = pred, Tipo = tipo, DesfaseDias = desfase, Unidad = "laborables" } };
        return fila;
    }
    private static string Propuesta(MYGPaqueteCronogramaIA paquete, params MYGTareaPropuestaCronogramaIA[] tareas) =>
        Firma(new MYGPropuestaCronogramaIA { Firma = paquete.Firma, Tareas = tareas.ToList() });
    private static MYGTareaCronogramaIA Exportada(MYGPaqueteCronogramaIA paquete, string id) => paquete.Tareas.Single(t => t.TareaId == id);
    private static MYGResultadoTarea Resultado(MYGVistaPreviaCronogramaIA vista, string id) => vista.Resultado.Filas.Single(t => t.Tarea.Id == id);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        FlujoCompleto(carpeta, pasa);
        Duraciones(pasa);
        DatosIncompletos(pasa);
        Protecciones(pasa);
        ProteccionIndirecta(pasa);
        Relaciones(pasa);
        ValidacionEstructural(pasa);
        JsonEstricto(pasa);
        CambiosDeOrigen(pasa);
        Seleccion(pasa);
        Plazos(pasa);
        CuadrillasProductivas(carpeta, pasa);
        DuracionesEstimadas(pasa);
        AplicacionConFechasExactas(pasa);
        CalendarioYPlazoObligatorio(pasa);
        AjustesInvalidos(pasa);
        ProduccionFueraDeRango(pasa);
        FichaCompletaYPromptConservador(pasa);
        PaqueteReabierto(pasa);
        ReaperturaSinCambios(carpeta, pasa);
        SinTareasEditables(carpeta, pasa);
        DiagnosticosDeContrato(pasa);
    }

    private static void FlujoCompleto(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        c.Doc.FuenteCatalogo = new MYGFuenteDelphin { Id = "FUENTE", RutaSQLite = "/privado/SENTINELA_RUTA_IA.sqlite" };
        c.Presupuesto.Costos.Insumos[0].FichaTecnicaRuta = "/privado/SENTINELA_RUTA_IA.pdf";
        c.Partida("P1").FuenteCatalogoRuta = "/privado/SENTINELA_RUTA_IA.sqlite";
        string docAntes = Firma(c.Doc), planAntes = Firma(c.Plan);
        var paquete = c.Paquete();
        string exportacion = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(paquete);
        Exige(!exportacion.Contains("SENTINELA_RUTA_IA") && exportacion.Contains("Operario") && paquete.Acus.Count > 0,
            "exportar debe contener ACU legible y excluir rutas privadas del documento.");
        Exige(prompt.Contains(paquete.Firma) && prompt.Contains("MYG_CRONOGRAMA_IA_PROPUESTA") && prompt.Contains("PredecesoraId"),
            "el prompt debe ligar la respuesta al paquete y explicar identidades estables.");
        var abierta = MYGAsistenteCronogramaIA.LeerPaquete(exportacion);
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, abierta,
            Propuesta(abierta, Fila(a), Fila(b, a, "FC", 1)));
        Exige(vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 5 &&
            vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a,
            "la importación debe usar cinco jornadas calculadas por MYG y conectar los IDs recibidos.");
        Exige(Resultado(vista, b).Inicio == new DateTime(2026, 10, 13),
            "FC+1 debe saltar fin de semana y comenzar el martes 13 tras cinco jornadas del lunes 5 al viernes 9.");
        Exige(vista.Cambios.Count == 2 && !vista.CumplePlazo && Firma(c.Doc) == docAntes && Firma(c.Plan) == planAntes,
            "previsualizar no debe modificar el origen y terminar antes de la fecha del proyecto no debe certificar cumplimiento exacto.");
        var aplicado = MYGProyectoStorage.Copia(c.Doc); aplicado.Cronograma = vista.Plan;
        string ruta = Path.Combine(carpeta, "asistente_ia.sqlite");
        MYGProyectoStorage.Guardar(ruta, aplicado);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        Exige(reabierto.Cronograma.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a &&
            reabierto.Presupuestos[0].Items.Single(i => i.Id == "P1").Costos.Cantidad == 100,
            "guardar y reabrir debe conservar vínculos sin modificar el presupuesto.");
        pasa("Asistente IA: exportación con ACU sin rutas privadas, prompt vinculado, propuesta, cálculo y persistencia SQLite reales sin mutar origen");
    }

    private static void Duraciones(Action<string> pasa)
    {
        var c = Crear(); string id = c.Tarea("P1").Id;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 5, "100 m³ a 20 m³/jornada debe dar cinco jornadas.");
        c.Partida("P1").Costos.Cantidad = 101;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 6, "las jornadas fraccionarias deben redondearse hacia arriba.");
        c.Tarea("P1").NumeroCuadrillas = 2;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 3, "dos cuadrillas deben duplicar la producción sin alterar el ACU.");
        c.Partida("P1").Costos.Cantidad = 100;
        c.Tarea("P1").NumeroCuadrillas = 1;
        c.Plan.Calendario.HorasPorDia = 4;
        Exige(Exportada(c.Paquete(), id).DuracionPropuesta == 10, "cuatro horas de trabajo frente a ocho de ACU deben requerir diez jornadas.");
        c.Plan.Calendario.HorasPorDia = 8;
        c.Partida("P1").Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        c.Partida("P1").Costos.Metrados.Add(new MYGLineaMetrado { Elementos = 2, CantidadPorElemento = 60 });
        Exige(Exportada(c.Paquete(), id).Metrado == 120 && Exportada(c.Paquete(), id).DuracionPropuesta == 6,
            "debe usar el metrado efectivo del motor en lugar de la cantidad directa almacenada.");
        c.Opciones.RecalcularDuraciones = false;
        var paquete = c.Paquete();
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(id)));
        Exige(vista.Plan.Tareas.Single(t => t.Id == id).DuracionDias == c.Tarea("P1").DuracionDias,
            "desactivar el recálculo debe conservar la duración existente.");
        pasa("Asistente IA: duraciones por metrado efectivo, rendimiento, cuadrillas, jornada y redondeo superior; opción de conservar duración");
    }

    private static void DatosIncompletos(Action<string> pasa)
    {
        var c = Crear(); string id = c.Tarea("P1").Id;
        c.Partida("P1").Costos.Analisis.Clear();
        var paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "sin ACU no debe inventar una duración productiva.");
        c = Crear(); id = c.Tarea("P1").Id; c.Partida("P1").Costos.Cantidad = 0;
        paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "metrado cero debe requerir revisión en lugar de convertirse en un hito.");
        c = Crear(); id = c.Tarea("P1").Id;
        c.Plan.Calendario.HorariosSemanales = new List<MYGHorarioDiaTrabajo>
        {
            new() { Dia = DayOfWeek.Monday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } },
            new() { Dia = DayOfWeek.Tuesday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 960 } } }
        };
        paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "un calendario de cuatro y ocho horas no debe fingir una jornada uniforme.");
        c = Crear(); id = c.Tarea("P1").Id;
        c.Plan.Calendario.HorasPorDia = 8;
        c.Plan.Calendario.HorariosSemanales = new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
            DayOfWeek.Thursday, DayOfWeek.Friday }.Select(dia => new MYGHorarioDiaTrabajo
            { Dia = dia, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } }).ToList();
        c.Plan.Calendario.Excepciones.Add(new MYGExcepcionCalendario
        { Inicio = Lunes.AddDays(5), Fin = Lunes.AddDays(5), Laborable = true });
        Exige(c.Plan.Calendario.HorasDelDia(Lunes) == 4 && c.Plan.Calendario.HorasDelDia(Lunes.AddDays(5)) == 8,
            "la excepción laborable de sábado sin tramos debe heredar ocho horas del calendario, frente a cuatro semanales.");
        paquete = c.Paquete();
        Exige(Exportada(paquete, id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
            "debe detectar la jornada de ocho horas heredada por una excepción laborable sin tramos y preservar la duración.");
        c = Crear(); c.Partida("P1").Costos.RendimientoDiario = 0;
        string antes = Firma(c.Doc), antesPlan = Firma(c.Plan);
        try
        {
            paquete = c.Paquete();
            Exige(Exportada(paquete, c.Tarea("P1").Id).DuracionPropuesta == null && paquete.Advertencias.Count > 0,
                "un rendimiento inválido no debe producir duración.");
        }
        catch (InvalidDataException) { }
        Exige(Firma(c.Doc) == antes && Firma(c.Plan) == antesPlan, "rechazar datos incompletos debe conservar el documento.");
        c = Crear(); c.Doc.Datos.PorRendimientoCuadrilla = false; c.Doc.Datos.PorAsignacionRecursos = true;
        id = c.Tarea("P1").Id; paquete = c.Paquete();
        Exige(paquete.MetodoAnalisis.Contains("Asignación") && Exportada(paquete, id).DuracionPropuesta == null &&
            paquete.Advertencias.Any(a => a.Contains("asignación", StringComparison.OrdinalIgnoreCase)),
            "el modo por asignación de recursos debe identificarse y no usar rendimiento por cuadrilla para inventar duración.");
        var asignacion = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
            Propuesta(paquete, Fila(id, c.Tarea("P2").Id)));
        Exige(asignacion.Plan.Tareas.Single(t => t.Id == id).DuracionDias == c.Tarea("P1").DuracionDias &&
            asignacion.Plan.Tareas.Single(t => t.Id == id).Predecesoras.Count == 1,
            "el modo por asignación permite proponer vínculos conservando la duración revisada.");
        pasa("Asistente IA: ACU ausente, metrado cero, rendimiento inválido y jornadas variables conservan datos y requieren revisión");
    }

    private static void Protecciones(Action<string> pasa)
    {
        var c = Crear(); string id = c.Tarea("P1").Id;
        c.Tarea("P1").Modo = MYGModoTarea.Manual; c.Tarea("P1").InicioManual = Lunes;
        Exige(!Exportada(c.Paquete(), id).Editable, "la tarea manual debe estar protegida por defecto.");
        c.Opciones.ReprogramarManualesEImportadas = true;
        var paquete = c.Paquete();
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(id)));
        var tarea = vista.Plan.Tareas.Single(t => t.Id == id);
        Exige(tarea.Modo == MYGModoTarea.Automatica && tarea.FechasImportadasDelphin == null && c.Tarea("P1").Modo == MYGModoTarea.Manual,
            "la autorización debe reprogramar sólo la copia y retirar su instantánea manual.");
        c = Crear(); var importada = c.Tarea("P1"); id = importada.Id;
        importada.Modo = MYGModoTarea.Manual; importada.InicioManual = Lunes;
        importada.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        { Inicio = Lunes, Fin = Lunes.AddDays(1), DuracionDias = 2 };
        importada.InicioBase = Lunes; importada.FinBase = Lunes.AddDays(1); importada.DuracionBase = 2;
        importada.Notas = "Conservar control técnico";
        Exige(!Exportada(c.Paquete(), id).Editable, "las fechas importadas de Delphin deben protegerse por defecto.");
        c.Opciones.ReprogramarManualesEImportadas = true; paquete = c.Paquete();
        string presupuestoAntes = Firma(c.Presupuesto);
        vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(id)));
        tarea = vista.Plan.Tareas.Single(t => t.Id == id);
        Exige(tarea.Modo == MYGModoTarea.Automatica && tarea.FechasImportadasDelphin == null && tarea.DuracionDias == 5 &&
            tarea.InicioBase == Lunes && tarea.FinBase == Lunes.AddDays(1) && tarea.DuracionBase == 2 &&
            tarea.Notas == "Conservar control técnico" && c.Tarea("P1").FechasImportadasDelphin != null &&
            Firma(c.Presupuesto) == presupuestoAntes,
            "reprogramar Delphin debe retirar sólo la instantánea necesaria y conservar línea base, notas y presupuesto.");
        foreach (string caso in new[] { "avance", "hito", "restricción", "partes" })
        {
            c = Crear(); c.Opciones.ReprogramarManualesEImportadas = true; var protegida = c.Tarea("P1");
            if (caso == "avance") protegida.Avance = 10;
            if (caso == "hito") protegida.DuracionDias = 0;
            if (caso == "restricción") { protegida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; protegida.FechaRestriccion = Lunes; }
            if (caso == "partes") MYGInformacionTarea.Dividir(protegida, 2, 1, 100);
            paquete = c.Paquete();
            Exige(!Exportada(paquete, protegida.Id).Editable, "no debe permitir reprogramar " + caso + ".");
            string antes = Firma(c.Plan);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
                Propuesta(paquete, Fila(protegida.Id))), "cambios en tarea protegida por " + caso);
            Exige(Firma(c.Plan) == antes, "un rechazo debe ser atómico para " + caso + ".");
        }
        pasa("Asistente IA: manuales requieren permiso explícito; hitos, avance, restricciones y tareas divididas permanecen protegidos");
    }

    private static void Relaciones(Action<string> pasa)
    {
        foreach (string tipo in new[] { "FC", "CC", "FF", "CF" })
        {
            var c = Crear(); c.Opciones.RecalcularDuraciones = false; var paquete = c.Paquete();
            string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
                Propuesta(paquete, Fila(b, a, tipo, 1)));
            var vinculo = vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single();
            Exige(vinculo.PredecesoraId == a && vinculo.Tipo.ToString() == tipo && vinculo.DesfaseDias == 1 &&
                vista.Cambios.Single().PredecesorasDespues.Contains(tipo), "se perdió el vínculo " + tipo + "+1.");
        }
        var negativa = Crear(); negativa.Opciones.RecalcularDuraciones = false;
        var paqueteNegativo = negativa.Paquete();
        string aNegativo = negativa.Tarea("P1").Id, bNegativo = negativa.Tarea("P2").Id;
        var vistaNegativa = MYGAsistenteCronogramaIA.PrepararPropuesta(negativa.Doc, negativa.Plan, paqueteNegativo,
            Propuesta(paqueteNegativo, Fila(bNegativo, aNegativo, "FC", -1)));
        Exige(Resultado(vistaNegativa, bNegativo).Inicio == Lunes.AddDays(1) &&
            vistaNegativa.Plan.Tareas.Single(t => t.Id == bNegativo).Predecesoras.Single().DesfaseDias == -1,
            "FC-1 debe permitir un adelanto laborable y empezar el martes cuando la predecesora termina ese martes.");
        foreach (int desfase in new[] { -36501, 36501 })
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(negativa.Doc, negativa.Plan, paqueteNegativo,
                Propuesta(paqueteNegativo, Fila(bNegativo, aNegativo, "FC", desfase))), "desfase fuera de rango");
        var orden = Crear(); orden.Plan.Tareas.Reverse();
        var exportado = orden.Paquete();
        string origen = orden.Tarea("P1").Id, destino = orden.Tarea("P3").Id;
        var vistaOrden = MYGAsistenteCronogramaIA.PrepararPropuesta(orden.Doc, orden.Plan, exportado,
            Propuesta(exportado, Fila(destino, origen)));
        Exige(vistaOrden.Plan.Tareas.Single(t => t.Id == destino).Predecesoras.Single().PredecesoraId == origen,
            "reordenar filas no debe sustituir IDs por números de fila.");
        pasa("Asistente IA: FC, CC, FF, CF y desfases laborables conservan su tipo y enlazan por ID estable al reordenar filas");
    }

    private static void ProteccionIndirecta(Action<string> pasa)
    {
        foreach (string tipo in new[] { "avance", "partes", "restricción", "hito" })
        {
            var c = Crear(); var protegida = c.Tarea("P2"); string a = c.Tarea("P1").Id;
            protegida.Predecesoras.Add(new() { PredecesoraId = a });
            if (tipo == "avance") protegida.Avance = 50;
            if (tipo == "partes") MYGInformacionTarea.Dividir(protegida, 2, 1, 10);
            if (tipo == "restricción") { protegida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe; protegida.FechaRestriccion = Lunes; }
            if (tipo == "hito") protegida.DuracionDias = 0;
            var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
            string antes = Firma(c.Plan), antesDoc = Firma(c.Doc), antesPaquete = Firma(paquete);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json),
                "desplazamiento indirecto de tarea protegida por " + tipo + " al aumentar la duración de su predecesora");
            var vacia = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, Array.Empty<string>());
            Exige(Firma(c.Plan) == antes && Firma(c.Doc) == antesDoc && Firma(paquete) == antesPaquete &&
                Firma(vacia.Plan) == antes && vacia.Cambios.Count == 0,
                "rechazar un desplazamiento protegido o elegir cero cambios debe conservar todas las instantáneas.");
        }
        var importacion = Crear(); var importada = importacion.Tarea("P2");
        importada.Modo = MYGModoTarea.Automatica; importada.InicioManual = Lunes;
        importada.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        { Inicio = Lunes, Fin = Lunes.AddDays(2), DuracionDias = 3, ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = Lunes };
        importacion.Opciones.FechaInicio = Lunes.AddDays(7);
        var paqueteImportado = importacion.Paquete();
        string antesImportado = Firma(importacion.Plan);
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(importacion.Doc, importacion.Plan, paqueteImportado,
            Propuesta(paqueteImportado, Fila(importacion.Tarea("P1").Id))),
            "cambio del inicio global que desplaza fechas automáticas importadas sin autorización");
        Exige(Firma(importacion.Plan) == antesImportado && importada.FechasImportadasDelphin != null,
            "un inicio global incompatible no debe modificar las fechas importadas originales.");
        var normal = Crear(); string origen = normal.Tarea("P1").Id, destino = normal.Tarea("P2").Id;
        normal.Tarea("P2").Predecesoras.Add(new() { PredecesoraId = origen });
        var normalPaquete = normal.Paquete();
        var permitida = MYGAsistenteCronogramaIA.PrepararPropuesta(normal.Doc, normal.Plan, normalPaquete,
            Propuesta(normalPaquete, Fila(origen)));
        Exige(Resultado(permitida, destino).Inicio == Lunes.AddDays(7),
            "una sucesora automática editable puede recalcular sus fechas al cambiar la predecesora sin recibir cambios directos.");
        pasa("Asistente IA: protege fechas excluidas ante cambios indirectos de predecesoras o inicio global, sin bloquear sucesoras automáticas editables");
    }

    private static void ValidacionEstructural(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete();
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id, resumen = c.Plan.Tareas.Single(t => t.EsResumen).Id;
        var invalidas = new List<string>
        {
            Propuesta(paquete, Fila(a, a)), Propuesta(paquete, Fila(a, "NO-EXISTE")),
            Propuesta(paquete, Fila("NO-EXISTE")), Propuesta(paquete, Fila(resumen)),
            Propuesta(paquete, Fila(a, resumen)), Propuesta(paquete, Fila(a), Fila(a)),
            Propuesta(paquete, Fila(a, b), Fila(b, a))
        };
        var repetida = Fila(b, a); repetida.Predecesoras.Add(new() { PredecesoraId = a, Tipo = "CC", DesfaseDias = 0, Unidad = "laborables" });
        invalidas.Add(Propuesta(paquete, repetida));
        foreach (string json in invalidas)
        {
            string antes = Firma(c.Plan), antesDoc = Firma(c.Doc), antesPaquete = Firma(paquete);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json),
                "dependencias inexistentes, repetidas, de resumen o cíclicas");
            Exige(Firma(c.Plan) == antes && Firma(c.Doc) == antesDoc && Firma(paquete) == antesPaquete,
                "rechazar identidades o vínculos debe preservar el documento, el plan y el paquete de la vista anterior.");
        }
        pasa("Asistente IA: rechaza ciclos, autorreferencias, tareas desconocidas, resúmenes y tareas o predecesoras repetidas sin mutación");
    }

    private static void JsonEstricto(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        string valido = Propuesta(paquete, Fila(b, a));
        var invalidos = new List<string> { "null", "[]", "{}", "{", valido + " texto", "```json\n" + valido + "\n```" };
        foreach (string campo in new[] { "Formato", "Version", "Firma", "Tareas" })
        { var nodo = JsonNode.Parse(valido).AsObject(); nodo.Remove(campo); invalidos.Add(nodo.ToJsonString()); }
        foreach (string campo in new[] { "TareaId", "Predecesoras" })
        { var nodo = JsonNode.Parse(valido); nodo["Tareas"][0].AsObject().Remove(campo); invalidos.Add(nodo.ToJsonString()); }
        foreach (string campo in new[] { "PredecesoraId", "Tipo", "DesfaseDias", "Unidad" })
        { var nodo = JsonNode.Parse(valido); nodo["Tareas"][0]["Predecesoras"][0].AsObject().Remove(campo); invalidos.Add(nodo.ToJsonString()); }
        foreach (string campo in new[] { "Tareas", "Firma" })
        { var nodo = JsonNode.Parse(valido); nodo[campo] = null; invalidos.Add(nodo.ToJsonString()); }
        foreach (string tipo in new[] { "fc", "FIN-COMIENZO", "99" })
        { var nodo = JsonNode.Parse(valido); nodo["Tareas"][0]["Predecesoras"][0]["Tipo"] = tipo; invalidos.Add(nodo.ToJsonString()); }
        var extra = JsonNode.Parse(valido); extra["Tareas"][0]["RendimientoDiario"] = 999; invalidos.Add(extra.ToJsonString());
        extra = JsonNode.Parse(valido); extra["Sorpresa"] = true; invalidos.Add(extra.ToJsonString());
        extra = JsonNode.Parse(valido); extra["Tareas"][0]["Predecesoras"][0]["Unidad"] = "calendario"; invalidos.Add(extra.ToJsonString());
        invalidos.Add(valido.Insert(1, "\"Version\":1,"));
        invalidos.Add(valido.Replace("\"Tipo\":\"FC\"", "\"Tipo\":\"FC\",\"Tipo\":\"CC\""));
        foreach (string json in invalidos)
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json), "JSON ambiguo o fuera del contrato estricto");
        pasa("Asistente IA: contrato JSON estricto rechaza campos ausentes, nulos, desconocidos o duplicados; no acepta rendimientos alterados ni desfases calendario");
    }

    private static void CambiosDeOrigen(Action<string> pasa)
    {
        foreach (string tipo in new[] { "cantidad", "rendimiento", "acu", "calendario", "tarea", "opciones" })
        {
            var c = Crear(); var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(c.Tarea("P1").Id));
            switch (tipo)
            {
                case "cantidad": c.Partida("P1").Costos.Cantidad++; break;
                case "rendimiento": c.Partida("P1").Costos.RendimientoDiario++; break;
                case "acu": c.Presupuesto.Costos.Insumos[0].Precio++; break;
                case "calendario": c.Plan.Calendario.Feriados.Add(Lunes); break;
                case "tarea": c.Tarea("P1").DuracionDias++; break;
                case "opciones": paquete.Opciones.PlazoDiasCalendario++; break;
            }
            string antes = Firma(c.Doc), planAntes = Firma(c.Plan);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json), "propuesta obsoleta o alterada por " + tipo);
            Exige(Firma(c.Doc) == antes && Firma(c.Plan) == planAntes, "rechazar desactualización debe conservar cambios actuales.");
        }
        pasa("Asistente IA: detecta cambios desde la exportación en metrado, rendimiento, ACU, calendario, tarea y opciones sin pisar avances");
    }

    private static void Seleccion(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        string json = Propuesta(paquete, Fila(a), Fila(b, a));
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, new[] { b });
        Exige(vista.Cambios.Count == 1 && vista.Cambios[0].TareaId == b &&
            vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == c.Tarea("P1").DuracionDias,
            "la selección debe aplicar únicamente la tarea elegida con su duración propuesta.");
        var vacia = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, Array.Empty<string>());
        Exige(Firma(vacia.Plan) == Firma(c.Plan) && vacia.Cambios.Count == 0,
            "selección vacía no debe cambiar siquiera la fecha del plan.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, new[] { "NO-EXISTE" }),
            "selección que no pertenece a la propuesta");
        c = Crear(); a = c.Tarea("P1").Id; b = c.Tarea("P2").Id;
        c.Tarea("P1").Predecesoras.Add(new() { PredecesoraId = b });
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(a), Fila(b, a));
        // Toda la propuesta elimina B->A y añade A->B: válida. Seleccionar sólo B conserva B->A y forma un ciclo.
        var completa = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(completa.Plan.Tareas.Single(t => t.Id == a).Predecesoras.Count == 0, "la propuesta completa debe retirar la relación anterior.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json, new[] { b }),
            "ciclo que surge al combinar cambios seleccionados con vínculos originales");
        pasa("Asistente IA: selección parcial o vacía conserva lo no elegido y valida ciclos contra el grafo original combinado");
    }

    private static void Plazos(Action<string> pasa)
    {
        var c = Crear(); c.Opciones.PlazoDiasCalendario = 5;
        c.Plan.Calendario.Feriados.Add(Lunes.AddDays(2));
        var paquete = c.Paquete();
        Exige(paquete.FinObjetivo == Lunes.AddDays(4), "cinco días calendario desde lunes deben terminar viernes, contando el inicio.");
        string a = c.Tarea("P1").Id;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(a)));
        Exige(Resultado(vista, a).Fin == Lunes.AddDays(7) && !vista.CumplePlazo && vista.Advertencias.Count > 0,
            "el feriado debe desplazar la quinta jornada al lunes siguiente y advertir el exceso del plazo calendario.");
        Exige(vista.Plan.Tareas.Single(t => t.Id == a).NumeroCuadrillas == 1 && Resultado(vista, a).DuracionDias == 5,
            "un plazo insuficiente no debe comprimir duraciones ni inventar cuadrillas.");
        c.Opciones.PlazoDiasCalendario = 0;
        Rechaza(() => c.Paquete(), "plazo cero");
        pasa("Asistente IA: plazo calendario inclusivo, feriados y fines de semana; informa incumplimiento sin comprimir producción");
    }

    private static void FijarPlazo(Caso c, int dias)
    {
        c.Opciones.PlazoDiasCalendario = dias;
        c.Doc.Datos.FechaInicio = c.Opciones.FechaInicio;
        c.Doc.Datos.FechaFin = c.Opciones.FechaInicio.AddDays(dias - 1);
        c.Doc.Datos.Duracion = dias;
        c.Doc.Datos.UnidadDuracion = "DIAS";
    }

    private static void CuadrillasProductivas(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        c.Partida("P1").Costos.Cantidad = 20840;
        c.Tarea("P1").DuracionDias = 1042;
        FijarPlazo(c, 145); // 105 jornadas de lunes a viernes: 05/10/2026–26/02/2027.
        string a = c.Tarea("P1").Id;
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), presupuesto = Firma(c.Presupuesto);
        var paquete = c.Paquete();
        Exige(Exportada(paquete, a).DuracionPropuesta == 1042,
            "la regresión debe partir de 1.042 jornadas con una cuadrilla, como la excavación del caso informado.");
        var propuesta = Fila(a);
        propuesta.NumeroCuadrillas = 10;
        propuesta.Justificacion = "Diez frentes de excavación independientes; confirmar equipos y disponibilidad antes de ejecutar.";
        string json = Propuesta(paquete, propuesta);
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        var tarea = vista.Plan.Tareas.Single(t => t.Id == a);
        Exige(tarea.NumeroCuadrillas == 10 && tarea.DuracionDias == 105 &&
            Resultado(vista, a).Inicio == Lunes && Resultado(vista, a).Fin == new DateTime(2027, 2, 26) && vista.CumplePlazo,
            "diez cuadrillas deben reducir 1.042 jornadas a 105 y respetar las dos fechas exactas del proyecto con el calendario real.");
        Exige(vista.Cambios.Single().CuadrillasAntes == 1 && vista.Cambios.Single().CuadrillasDespues == 10,
            "la revisión debe exponer el aumento de cuadrillas, además de la reducción de duración.");
        var aplicable = MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json);
        Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(c.Presupuesto) == presupuesto,
            "calcular y preparar la aplicación deben conservar metrado, rendimiento, precios, ACU y cronograma de origen.");
        var copia = MYGProyectoStorage.Copia(c.Doc); copia.Cronograma = aplicable;
        string ruta = Path.Combine(carpeta, "asistente_ia_diez_cuadrillas.sqlite");
        MYGProyectoStorage.Guardar(ruta, copia);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        var conservada = reabierto.Cronograma.Tareas.Single(t => t.Id == a);
        var recalculado = MYGMotorCronograma.Calcular(reabierto.Cronograma);
        Exige(conservada.NumeroCuadrillas == 10 && conservada.DuracionDias == 105 &&
            recalculado.Inicio == Lunes && recalculado.Fin == new DateTime(2027, 2, 26) &&
            reabierto.Presupuestos.Single().Items.Single(i => i.Id == "P1").Costos.Cantidad == 20840,
            "guardar y reabrir SQLite debe conservar las cuadrillas, las fechas y el metrado completo de la excavación.");
        pasa("Asistente IA: reduce 1.042 jornadas mediante diez cuadrillas explícitas, cumple inicio/fin y persiste en SQLite sin cambiar el ACU");
    }

    private static void DuracionesEstimadas(Action<string> pasa)
    {
        foreach (string caso in new[] { "rendimiento predeterminado", "sin ACU", "asignación", "jornada variable" })
        {
            var c = Crear(); string a = c.Tarea("P1").Id;
            if (caso == "rendimiento predeterminado")
            {
                c.Partida("P1").Descripcion = c.Tarea("P1").Nombre = "Equipos de protección colectiva y control ambiental";
                c.Partida("P1").Costos.Cantidad = 720;
                c.Partida("P1").Costos.RendimientoDiario = 1;
                c.Tarea("P1").DuracionDias = 720;
            }
            if (caso == "sin ACU") c.Partida("P1").Costos.Analisis.Clear();
            if (caso == "asignación") { c.Doc.Datos.PorAsignacionRecursos = true; c.Doc.Datos.PorRendimientoCuadrilla = false; }
            if (caso == "jornada variable")
                c.Plan.Calendario.HorariosSemanales = new()
                {
                    new() { Dia = DayOfWeek.Monday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 } } },
                    new() { Dia = DayOfWeek.Tuesday, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 960 } } }
                };
            var paquete = c.Paquete();
            Exige(Exportada(paquete, a).DuracionPropuesta == null,
                "no debe convertir " + caso + " en una duración productiva aparentemente verificada.");
            string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
            var estimacion = Fila(a);
            estimacion.DuracionDias = 4;
            estimacion.Justificacion = "Cuatro jornadas para instalar protecciones; el metrado no representa una producción diaria confirmada. Revisar el mantenimiento transversal por separado.";
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, estimacion));
            Exige(vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 4 &&
                vista.Plan.Tareas.Single(t => t.Id == a).NumeroCuadrillas == 1 &&
                Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
                "una estimación de duración justificada debe poder revisarse para " + caso + " sin inventar productividad ni cambiar el origen.");
            var soloCuadrillas = Fila(a); soloCuadrillas.NumeroCuadrillas = 2;
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
                Propuesta(paquete, soloCuadrillas)), "cuadrillas sin duración/productividad verificable para " + caso);
        }
        pasa("Asistente IA: rendimiento 1, partidas globales, ACU ausente, asignación y jornada variable admiten estimaciones justificadas sin generar cientos de jornadas");
    }

    private static void AplicacionConFechasExactas(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 5);
        string a = c.Tarea("P1").Id;
        var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
        var exacta = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(exacta.CumplePlazo && MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json) != null,
            "una propuesta que empieza lunes y termina exactamente el viernes objetivo debe ser aplicable.");
        foreach (int dias in new[] { 4, 12 })
        {
            c = Crear(); FijarPlazo(c, dias); a = c.Tarea("P1").Id;
            paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
            var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
            string antes = Firma(c.Plan), antesDoc = Firma(c.Doc);
            Exige(!vista.CumplePlazo, "terminar antes o después de la fecha exacta debe marcar incumplimiento.");
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                "aplicación con fin " + (dias == 4 ? "posterior" : "anterior") + " al plazo obligatorio");
            Exige(Firma(c.Plan) == antes && Firma(c.Doc) == antesDoc,
                "rechazar el plazo debe preservar el cronograma y los datos del proyecto.");
        }
        c = Crear(); FijarPlazo(c, 12); a = c.Tarea("P1").Id;
        string b = c.Tarea("P2").Id;
        var sucesora = Fila(b, a); sucesora.DuracionDias = 5;
        sucesora.Justificacion = "Cinco jornadas para ejecutar el segundo frente después del primero, con controles y esperas técnicas incluidos.";
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(a), sucesora);
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo &&
            MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json) != null,
            "las diez jornadas consecutivas deben cerrar el viernes 16 de octubre.");
        foreach (string[] seleccion in new[] { new[] { a }, new[] { b }, Array.Empty<string>() })
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json, seleccion),
                "selección parcial o vacía que pierde el cumplimiento exacto de la propuesta completa");
        c = Crear(); c.Opciones.PlazoDiasCalendario = 5; a = c.Tarea("P1").Id;
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo,
            "el análisis puede revisar otro objetivo sin cambiar la ficha del proyecto.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
            "objetivo simulado que no coincide con el fin registrado en la ficha del proyecto");
        c = Crear(); c.Opciones.FechaInicio = Lunes.AddDays(7); c.Opciones.PlazoDiasCalendario = 5;
        c.Doc.Datos.FechaFin = Lunes.AddDays(11);
        a = c.Tarea("P1").Id; paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
        Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo,
            "el objetivo de simulación posterior debe ser calculable sin modificar la fecha inicial de la ficha.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
            "inicio simulado que no coincide con el inicio registrado aunque sí coincida el fin");
        pasa("Asistente IA: aplicación exige inicio y fin exactos de la ficha; bloquea fin temprano, tardío y selección parcial o vacía");
    }

    private static void CalendarioYPlazoObligatorio(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 8);
        c.Plan.Calendario.Feriados.Add(Lunes.AddDays(2));
        string a = c.Tarea("P1").Id;
        var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(vista.CumplePlazo && Resultado(vista, a).Fin == new DateTime(2026, 10, 12) &&
            MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json) != null,
            "cinco jornadas con un feriado deben cerrar el lunes 12 contando el fin de semana sin alterarlo.");
        foreach (bool inicioNoLaborable in new[] { false, true })
        {
            c = Crear();
            if (inicioNoLaborable)
            {
                c.Opciones.FechaInicio = Lunes.AddDays(-1);
                c.Plan.FechaInicio = c.Opciones.FechaInicio;
            }
            FijarPlazo(c, 6);
            a = c.Tarea("P1").Id; paquete = c.Paquete(); json = Propuesta(paquete, Fila(a));
            string calendario = Firma(c.Plan.Calendario);
            vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
            Exige(!vista.CumplePlazo && Firma(vista.Plan.Calendario) == calendario,
                "un extremo no laborable debe impedir el cumplimiento exacto, sin habilitar trabajo silenciosamente.");
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                inicioNoLaborable ? "inicio obligatorio en domingo con calendario lunes a viernes" : "fin obligatorio en sábado con calendario lunes a viernes");
            Exige(Firma(c.Plan.Calendario) == calendario, "rechazar un extremo no laborable debe conservar el calendario original.");
        }
        c = Crear(); FijarPlazo(c, 9);
        var fija = c.Tarea("P1");
        fija.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe;
        fija.FechaRestriccion = Lunes.AddDays(1);
        foreach (var tarea in c.Plan.Tareas.Where(t => !t.EsResumen && t.Id != fija.Id))
            tarea.Predecesoras.Add(new() { PredecesoraId = fija.Id });
        c.Plan.Tareas.Add(new MYGTareaCronograma { Id = "RESUMEN-VACIO-IA", Nombre = "Capítulo sin actividades", EsResumen = true });
        string b = c.Tarea("P2").Id;
        paquete = c.Paquete(); json = Propuesta(paquete, Fila(b, fija.Id));
        vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(vista.Resultado.Inicio == Lunes && vista.Resultado.Fin == Lunes.AddDays(8) && !vista.CumplePlazo &&
            vista.Resultado.Filas.Where(f => !f.Tarea.EsResumen).Min(f => f.Inicio) == Lunes.AddDays(1),
            "un capítulo vacío fechado al inicio no debe simular que la obra comenzó cuando todas las actividades empiezan después.");
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
            "inicio aparente aportado únicamente por un resumen vacío");
        pasa("Asistente IA: cumple fechas reales con feriados y fines de semana; bloquea extremos no laborables sin cambiar el calendario");
    }

    private static void AjustesInvalidos(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string a = c.Tarea("P1").Id;
        var invalidas = new List<MYGTareaPropuestaCronogramaIA>();
        foreach (decimal cuadrillas in new[] { 0m, -1m, 10001m, decimal.MaxValue })
        { var fila = Fila(a); fila.NumeroCuadrillas = cuadrillas; invalidas.Add(fila); }
        foreach (int duracion in new[] { 0, -1, 36501, int.MaxValue })
        { var fila = Fila(a); fila.DuracionDias = duracion; invalidas.Add(fila); }
        var sinMotivo = Fila(a); sinMotivo.NumeroCuadrillas = 2; sinMotivo.Justificacion = " "; invalidas.Add(sinMotivo);
        sinMotivo = Fila(a); sinMotivo.DuracionDias = 5; sinMotivo.Justificacion = null; invalidas.Add(sinMotivo);
        var produccionImposible = Fila(a); produccionImposible.NumeroCuadrillas = 2; produccionImposible.DuracionDias = 2;
        invalidas.Add(produccionImposible); // 100 m³ / 20 / 2 = 2,5: son como mínimo tres jornadas.
        foreach (var fila in invalidas)
        {
            string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), antesPaquete = Firma(paquete);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, fila)),
                "ajustes de recursos/duración inválidos, sin justificación o inferiores a la producción mínima");
            Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(paquete) == antesPaquete,
                "validar recursos o producción debe ser atómico y no alterar ninguna instantánea.");
        }
        c.Opciones.RecalcularDuraciones = false; paquete = c.Paquete();
        foreach (bool recursos in new[] { false, true })
        {
            var fila = Fila(a);
            if (recursos) fila.NumeroCuadrillas = 2; else fila.DuracionDias = 5;
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, fila)),
                "ajuste de duración o cuadrillas con recálculo expresamente desactivado");
        }
        pasa("Asistente IA: rechaza recursos y duraciones fuera de rango, cambios sin justificación y producción insuficiente sin mutar datos");
    }

    private static void ProduccionFueraDeRango(Action<string> pasa)
    {
        var c = Crear(); FijarPlazo(c, 1);
        c.Partida("P1").Costos.Cantidad = 730020;
        foreach (var tarea in c.Plan.Tareas.Where(t => !t.EsResumen)) tarea.DuracionDias = 1;
        string a = c.Tarea("P1").Id;
        var paquete = c.Paquete();
        Exige(Exportada(paquete, a).DuracionPropuesta == null && Exportada(paquete, a).DuracionActual == 1,
            "36.501 jornadas productivas exceden el rango y deben distinguirse de la duración actual de una jornada.");
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan), antesPaquete = Firma(paquete);
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, Fila(a))),
            "conservar una jornada cuando 730.020 m³ a rendimiento 20 requieren 36.501 jornadas productivas");
        Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan && Firma(paquete) == antesPaquete,
            "rechazar producción fuera del rango debe conservar todas las instantáneas y no fingir cumplimiento de un día.");
        var ajuste = Fila(a); ajuste.NumeroCuadrillas = 2;
        ajuste.Justificacion = "Dos frentes independientes duplican la producción; el plazo contractual todavía requiere revisión.";
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete, ajuste));
        var corregida = vista.Plan.Tareas.Single(t => t.Id == a);
        Exige(corregida.NumeroCuadrillas == 2 && corregida.DuracionDias == 18251 && !vista.CumplePlazo,
            "una cuadrilla adicional debe recuperar el cálculo válido de 18.251 jornadas, sin conservar la jornada original ni certificar el plazo de un día.");
        pasa("Asistente IA: producción superior a 36.500 jornadas nunca conserva una duración ficticia; cuadrillas explícitas recuperan el cálculo verificable");
    }

    private static void FichaCompletaYPromptConservador(Action<string> pasa)
    {
        foreach (bool faltaInicio in new[] { true, false })
        {
            var c = Crear(); FijarPlazo(c, 5);
            if (faltaInicio) c.Doc.Datos.FechaInicio = null; else c.Doc.Datos.FechaFin = null;
            string a = c.Tarea("P1").Id;
            var paquete = c.Paquete(); string json = Propuesta(paquete, Fila(a));
            Exige(MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json).CumplePlazo,
                "los objetivos de simulación pueden coincidir aunque falte una fecha contractual en la ficha.");
            string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
            Rechaza(() => MYGAsistenteCronogramaIA.PrepararAplicacion(c.Doc, c.Plan, paquete, json),
                "aplicación sin " + (faltaInicio ? "inicio" : "fin") + " registrado en los datos del proyecto");
            Exige(Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
                "la aplicación debe exigir las dos fechas de la ficha sin inventar una fecha faltante ni modificar datos.");
        }
        var conservador = Crear(); conservador.Opciones.RecalcularDuraciones = false;
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(conservador.Paquete());
        int marcador = prompt.IndexOf("Ejemplo de estructura", StringComparison.Ordinal);
        Exige(marcador >= 0, "el prompt debe proporcionar un ejemplo de respuesta utilizable por la IA.");
        int comienzo = prompt.IndexOf('{', marcador);
        int fin = prompt.IndexOf("Ejemplo de un vínculo", comienzo, StringComparison.Ordinal);
        Exige(comienzo >= 0 && fin > comienzo, "debe poder distinguirse el ejemplo completo de propuesta del ejemplo de vínculo.");
        using var ejemplo = JsonDocument.Parse(prompt.Substring(comienzo, fin - comienzo).Trim());
        var filas = ejemplo.RootElement.GetProperty("Tareas").EnumerateArray().ToArray();
        Exige(filas.Length > 0 && filas.All(f => !f.TryGetProperty("NumeroCuadrillas", out _) &&
            !f.TryGetProperty("DuracionDias", out _)),
            "conservar duraciones debe producir un ejemplo JSON que omita ajustes de cuadrillas/duración, en lugar de enseñar cambios que el importador rechazaría.");
        pasa("Asistente IA: exige ambas fechas contractuales y el ejemplo JSON conservador omite ajustes de duración y cuadrillas");
    }

    private static void PaqueteReabierto(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete();
        string exportado = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        var abierto = MYGAsistenteCronogramaIA.LeerPaquete(exportado);
        Exige(abierto.Firma == paquete.Firma && abierto.Tareas.Count == paquete.Tareas.Count,
            "reabrir el paquete debe conservar identidad para otra sesión.");
        var alterado = MYGAsistenteCronogramaIA.LeerPaquete(exportado);
        alterado.Tareas.Single(t => t.TareaId == c.Tarea("P1").Id).DuracionPropuesta = 1;
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, alterado,
            Propuesta(alterado, Fila(c.Tarea("P1").Id))), "paquete con duración calculada adulterada");
        var nodo = JsonNode.Parse(exportado); nodo["Firma"] = "FIRMA-AJENA";
        Rechaza(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan,
            MYGAsistenteCronogramaIA.LeerPaquete(nodo.ToJsonString()), Propuesta(paquete, Fila(c.Tarea("P1").Id))),
            "paquete ajeno");
        Rechaza(() => MYGAsistenteCronogramaIA.LeerPaquete("{}"), "paquete sin contrato");
        pasa("Asistente IA: reabre el paquete original entre sesiones y rechaza firmas ajenas o duraciones adulteradas");
    }

    private static void ReaperturaSinCambios(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        // Una obra abierta en la aplicación ya tiene identidades y valores heredados normalizados.
        MYGProyectoStorage.Validar(c.Doc);
        var paquete = c.Paquete();
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id;
        string json = Propuesta(paquete, Fila(a), Fila(b, a));
        string exportado = MYGAsistenteCronogramaIA.SerializarPaquete(paquete);
        c.Doc.ModificadoUtc = new DateTime(2026, 10, 28, 18, 15, 0, DateTimeKind.Utc);
        c.Doc.Cronograma = MYGProyectoStorage.Copia(c.Plan);
        c.Plan.OpcionesVista["mostrar_linea_base"] = "true";
        DateTime nuevoEstado = c.Plan.FechaEstado.AddDays(1);
        c.Plan.FechaEstado = nuevoEstado;
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, json);
        Exige(vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a,
            "guardar fecha de modificación, persistir cronograma temporal y cambiar su vista no deben invalidar la propuesta.");
        Exige(vista.Plan.FechaEstado == nuevoEstado,
            "reabrir un cronograma temporal al día siguiente debe conservar la fecha de estado actual sin invalidar el paquete original.");
        c.Doc.Cronograma = MYGProyectoStorage.Copia(c.Plan);
        string ruta = Path.Combine(carpeta, "asistente_ia_reapertura.sqlite");
        MYGProyectoStorage.Guardar(ruta, c.Doc);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        var original = MYGAsistenteCronogramaIA.LeerPaquete(reabierto, reabierto.Cronograma, exportado);
        var importada = MYGAsistenteCronogramaIA.PrepararPropuesta(reabierto, reabierto.Cronograma, original, json);
        Exige(original.Firma == paquete.Firma && importada.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 5 &&
            importada.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a,
            "cerrar y reabrir la misma obra SQLite debe admitir el paquete y la respuesta originales sin cambios de planificación.");
        pasa("Asistente IA: guardar, cerrar y reabrir SQLite conserva el intercambio; fecha de guardado y opciones de vista no invalidan la propuesta");
    }

    private static void SinTareasEditables(string carpeta, Action<string> pasa)
    {
        var c = Crear();
        foreach (var tarea in c.Plan.Tareas.Where(t => !t.EsResumen))
        {
            tarea.Modo = MYGModoTarea.Manual; tarea.InicioManual = Lunes;
            tarea.FechasImportadasDelphin = new MYGFechasImportadasDelphin
            {
                Inicio = Lunes, Fin = Lunes.AddDays(tarea.DuracionDias - 1), DuracionDias = tarea.DuracionDias,
                ModoOriginal = MYGModoTarea.Manual, InicioProyecto = Lunes
            };
        }
        string antesDoc = Firma(c.Doc), antesPlan = Firma(c.Plan);
        var original = c.Paquete();
        Exige(original.Tareas.Any(t => t.EsResumen) && original.Tareas.All(t => !t.Editable),
            "el caso sintético debe representar resúmenes y actividades manuales/importadas sin destinos editables.");
        string promptBloqueado = MensajeRechazo(() => MYGAsistenteCronogramaIA.CrearPrompt(original),
            "copiar un prompt que sólo podría devolver una lista vacía por falta de tareas editables");
        Exige(promptBloqueado.Contains("no tiene tareas editables", StringComparison.OrdinalIgnoreCase) &&
            promptBloqueado.Contains("manuales o importadas", StringComparison.OrdinalIgnoreCase) &&
            promptBloqueado.Contains("exporte un paquete nuevo", StringComparison.OrdinalIgnoreCase) &&
            promptBloqueado.Contains("prompt", StringComparison.OrdinalIgnoreCase),
            "sin tareas editables debe explicar activar la reprogramación explícita, revisar, exportar otra vez y copiar el nuevo prompt.");
        string vacia = Propuesta(original);
        string diagnostico = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, original, vacia),
            "propuesta vacía con encabezados y firma correctos");
        Exige(diagnostico.Contains("Tareas: []", StringComparison.Ordinal) &&
            diagnostico.Contains("no tiene tareas editables", StringComparison.OrdinalIgnoreCase) &&
            !diagnostico.Contains("Firma", StringComparison.Ordinal),
            "Tareas vacía con firma y versión correctas debe identificar la causa real sin culpar a la Firma.");
        c.Opciones.ReprogramarManualesEImportadas = true;
        var renovado = c.Paquete();
        string prompt = MYGAsistenteCronogramaIA.CrearPrompt(renovado);
        Exige(renovado.Tareas.Count(t => t.Editable) == 3 && renovado.Firma != original.Firma &&
            prompt.Contains(renovado.Firma) && prompt.Contains("PredecesoraId"),
            "activar la opción debe producir un paquete y un prompt nuevos con las actividades ahora editables.");
        string a = c.Tarea("P1").Id, b = c.Tarea("P2").Id, d = c.Tarea("P3").Id;
        string respuestaAnterior = Propuesta(original, Fila(a));
        string firmaAnterior = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, renovado, respuestaAnterior),
            "respuesta del paquete previo a autorizar reprogramación");
        Exige(firmaAnterior.Contains("Firma", StringComparison.Ordinal) && firmaAnterior.Contains("no coincide", StringComparison.OrdinalIgnoreCase),
            "el cambio de autorización requiere una respuesta nueva y debe detectar la firma del paquete anterior.");
        string respuesta = Propuesta(renovado, Fila(a), Fila(b, a), Fila(d, b));
        var vista = MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, renovado, respuesta);
        Exige(vista.Plan.Tareas.Where(t => !t.EsResumen).All(t => t.Modo == MYGModoTarea.Automatica && t.FechasImportadasDelphin == null) &&
            vista.Plan.Tareas.Single(t => t.Id == a).DuracionDias == 5 &&
            vista.Plan.Tareas.Single(t => t.Id == b).Predecesoras.Single().PredecesoraId == a &&
            Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
            "la propuesta nueva puede previsualizarse, pero no debe modificar las actividades originales antes de aplicar.");
        var aplicado = MYGProyectoStorage.Copia(c.Doc); aplicado.Cronograma = vista.Plan;
        string ruta = Path.Combine(carpeta, "asistente_ia_manuales_sinteticas.sqlite");
        MYGProyectoStorage.Guardar(ruta, aplicado);
        var reabierto = MYGProyectoStorage.Leer(ruta);
        Exige(reabierto.Cronograma.Tareas.Single(t => t.Id == d).Predecesoras.Single().PredecesoraId == b &&
            Firma(c.Doc) == antesDoc && Firma(c.Plan) == antesPlan,
            "guardar una copia aplicada debe conservar el encadenamiento sin tocar el origen sintético.");
        pasa("Asistente IA: detecta cero tareas editables y respuesta vacía con firma correcta; reprogramación explícita exige nuevo paquete y permite previsualizar y guardar la propuesta");
    }

    private static void DiagnosticosDeContrato(Action<string> pasa)
    {
        var c = Crear(); var paquete = c.Paquete(); string valido = Propuesta(paquete, Fila(c.Tarea("P1").Id));
        var nodo = JsonNode.Parse(valido); nodo["Formato"] = "MYG_CRONOGRAMA_IA_DATOS";
        string tipo = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "el paquete de exportación usado como respuesta");
        Exige(tipo.Contains("Abrir paquete exportado", StringComparison.OrdinalIgnoreCase),
            "usar un paquete de datos como propuesta debe indicar el botón correcto.");
        nodo = JsonNode.Parse(valido); nodo["Version"] = 2;
        string version = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "versión de respuesta no admitida");
        Exige(version.Contains("versión", StringComparison.OrdinalIgnoreCase) && !version.Contains("Firma", StringComparison.Ordinal),
            "el error de versión debe distinguirse del error de firma.");
        nodo = JsonNode.Parse(valido); nodo.AsObject().Remove("Firma");
        string sinFirma = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "respuesta que omitió Firma");
        Exige(sinFirma.Contains("no contiene la Firma", StringComparison.OrdinalIgnoreCase),
            "una firma ausente debe explicarse en español, sin ocultarse tras un fallo de deserialización genérico.");
        nodo = JsonNode.Parse(valido); nodo["Firma"] = "FIRMA-DE-OTRO-PAQUETE";
        string otraFirma = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
            "respuesta con firma distinta");
        Exige(otraFirma.Contains("no coincide", StringComparison.OrdinalIgnoreCase) && otraFirma != sinFirma,
            "una firma distinta debe distinguirse de una firma ausente.");
        string vacia = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, Propuesta(paquete)),
            "respuesta vacía pese a haber actividades editables");
        Exige(vacia.Contains("Tareas: []", StringComparison.Ordinal) && !vacia.Contains("Firma", StringComparison.Ordinal),
            "una respuesta vacía debe diagnosticar su lista de tareas aunque haya destinos editables.");
        foreach (bool omitir in new[] { false, true })
        {
            nodo = JsonNode.Parse(valido);
            if (omitir) nodo.AsObject().Remove("Tareas"); else nodo["Tareas"] = null;
            string sinLista = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete, nodo.ToJsonString()),
                "lista Tareas ausente o nula");
            Exige(sinLista.Contains("no contiene la lista Tareas", StringComparison.OrdinalIgnoreCase) &&
                !sinLista.Contains("Firma", StringComparison.Ordinal),
                "la lista ausente o nula debe distinguirse de la firma y de una lista válida pero vacía.");
        }
        var excesivas = Enumerable.Range(0, paquete.Tareas.Count + 1).Select(_ => Fila(c.Tarea("P1").Id)).ToArray();
        string demasiadas = MensajeRechazo(() => MYGAsistenteCronogramaIA.PrepararPropuesta(c.Doc, c.Plan, paquete,
            Propuesta(paquete, excesivas)), "respuesta con más tareas que el paquete");
        Exige(demasiadas.Contains("más tareas que el paquete", StringComparison.OrdinalIgnoreCase) &&
            !demasiadas.Contains("Firma", StringComparison.Ordinal),
            "un exceso de tareas debe explicar su cantidad antes de revisar las identidades repetidas.");
        pasa("Asistente IA: distingue paquete equivocado, versión, firma ausente o distinta, lista ausente, vacía y excesiva con mensajes específicos");
    }
}
