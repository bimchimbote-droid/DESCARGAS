using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class HistorialEdicionUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarMensaje(IntPtr ventana, int mensaje, IntPtr wParam, IntPtr lParam);

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Historial de edición", "Presupuesto");
        string id = MYGProyectoStorage.NuevoId();
        proyecto.Presupuestos.Single().Items.Add(new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, TipoPropuesta = "PARTIDA", Posicion = 1,
            Descripcion = "Partida original", Unidad = "und", Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = 1m, PrecioDirecto = 10m }
        });
        MYGProyectoStorage.Validar(proyecto);
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial))!.SetValue(sesion,
            new CredencialMYG { Usuario = "Prueba sintética de historial" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, true);
        using var editor = new EditorForm(proyecto, null, sesion) { ClientSize = new Size(1500, 900) };
        try
        {
            editor.Show(); Application.DoEvents();
            var panel = Campo<MYGPanelPresupuesto>(editor, "panelPresupuesto");
            var tabla = Campo<DataGridView>(panel, "estructura");
            var numero = Campo<NumericUpDown>(panel, "precioDirecto");
            var fuente = Campo<ComboBox>(panel, "fuente");
            var buscar = Campo<TextBox>(panel, "buscar");
            var undo = Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "undo");
            var redo = Campo<Stack<MYGEntradaHistorialProyecto>>(editor, "redo");

            Editar("DESC", "Partida modificada");
            Editar("UND", "kg");
            Editar("CANT", "3.25");
            exige(Actual().Descripcion == "Partida modificada" && Actual().Unidad == "kg" &&
                Actual().Costos.Cantidad == 3.25m && undo.Count == 3,
                "Nombre, unidad y cantidad deben registrar tres operaciones independientes en el editor real.");

            // Antes el mero foco en un NumericUpDown anulaba Ctrl+Z incluso
            // cuando no se estaba escribiendo nada en su editor de texto.
            Seleccionar(); numero.Focus(); Application.DoEvents();
            exige(numero.ContainsFocus && Tecla(Keys.Control | Keys.Z) && Actual().Costos.Cantidad == 1m &&
                Actual().Unidad == "kg" && Actual().Descripcion == "Partida modificada",
                "Ctrl+Z con foco en un número debe deshacer la última cantidad confirmada.");
            Seleccionar(); fuente.Focus(); Application.DoEvents();
            exige(fuente.ContainsFocus && Tecla(Keys.Control | Keys.Z) && Actual().Unidad == "und" &&
                Actual().Descripcion == "Partida modificada",
                "Ctrl+Z con foco en una lista debe restaurar la unidad anterior, sin modificar el nombre.");
            tabla.Focus();
            exige(Tecla(Keys.Control | Keys.Z) && Actual().Descripcion == "Partida original" && undo.Count == 0,
                "El tercer Ctrl+Z debe restaurar el nombre original en orden inverso.");
            exige(Tecla(Keys.Control | Keys.Y) && Tecla(Keys.Control | Keys.Y) && Tecla(Keys.Control | Keys.Y) &&
                Actual().Descripcion == "Partida modificada" && Actual().Unidad == "kg" &&
                Actual().Costos.Cantidad == 3.25m && redo.Count == 0,
                "Ctrl+Y debe rehacer los tres cambios sin perder sus valores ni invertir el orden.");

            Seleccionar(); numero.Focus(); numero.Value = 25m; Application.DoEvents();
            exige(Actual().Costos.PrecioDirecto == 25m && Tecla(Keys.Control | Keys.Z) &&
                Actual().Costos.PrecioDirecto == 10m,
                "Deshacer debe revertir también un valor numérico que ya actualizó el modelo manteniendo el foco.");
            exige(Tecla(Keys.Control | Keys.Y) && Actual().Costos.PrecioDirecto == 25m,
                "Rehacer debe recuperar el valor numérico confirmado.");

            // La confirmación pendiente se captura antes de seleccionar la
            // entrada, también cuando el usuario pulsa un botón Deshacer.
            Seleccionar();
            var fila = tabla.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is ItemPresupuestoDelphin p && p.Id == id);
            tabla.CurrentCell = fila.Cells["CANT"]; tabla.Focus(); tabla.BeginEdit(true);
            ((TextBoxBase)tabla.EditingControl).Text = "9.75";
            Invocar(editor, "Historial", false); Application.DoEvents();
            exige(!tabla.IsCurrentCellInEditMode && Actual().Costos.Cantidad == 3.25m &&
                Actual().Costos.PrecioDirecto == 25m,
                "Deshacer desde un botón debe confirmar y revertir la cantidad pendiente, conservando la edición anterior del precio.");
            exige(Tecla(Keys.Control | Keys.Y) && Actual().Costos.Cantidad == 9.75m,
                "La edición que estaba pendiente debe poder rehacerse después.");

            Seleccionar();
            fila = tabla.Rows.Cast<DataGridViewRow>().Single(r => r.Tag is ItemPresupuestoDelphin p && p.Id == id);
            tabla.CurrentCell = fila.Cells["DESC"]; tabla.Focus(); tabla.BeginEdit(true);
            var texto = (TextBoxBase)tabla.EditingControl;
            texto.Select(texto.TextLength, 0);
            EnviarMensaje(texto.Handle, 0x0102, new IntPtr('X'), IntPtr.Zero); // WM_CHAR: historial nativo real.
            int operaciones = undo.Count;
            exige(texto.CanUndo && !Tecla(Keys.Control | Keys.Z) && tabla.IsCurrentCellInEditMode &&
                undo.Count == operaciones && Actual().Descripcion == "Partida modificada",
                "Un carácter todavía no confirmado debe reservar Ctrl+Z para el editor de texto nativo.");
            tabla.CancelEdit(); Application.DoEvents();

            buscar.Focus(); buscar.Text = "consulta sin coincidencias"; Application.DoEvents();
            operaciones = undo.Count;
            exige(!Tecla(Keys.Control | Keys.Z) && undo.Count == operaciones,
                "La búsqueda debe conservar su atajo de texto y no deshacer cambios del presupuesto.");
            buscar.Text = ""; Application.DoEvents();

            tabla.Focus(); exige(Tecla(Keys.Control | Keys.Z), "Debe poder deshacerse la última cantidad.");
            Editar("DESC", "Otra descripción");
            exige(redo.Count == 0 && Actual().Descripcion == "Otra descripción",
                "Una edición nueva tras deshacer debe retirar la rama anterior de Rehacer.");
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.AvisoValidacion))!.SetValue(sesion,
                "Validación temporalmente pendiente de reconexión.");
            Invocar(editor, "EstadoSesion"); Application.DoEvents();
            exige(Campo<Label>(editor, "avisoSesionPresupuesto").Visible &&
                Campo<Label>(editor, "avisoSesionPresupuesto").Text.Contains("reconexión") && sesion.Autorizado,
                "La cabecera visible debe informar una validación pendiente sin deshabilitar el trabajo local autorizado.");
            typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado))!.SetValue(sesion, false);
            string antes = MYGProyectoStorage.Firma(Documento());
            exige(!Tecla(Keys.Control | Keys.Z) && MYGProyectoStorage.Firma(Documento()) == antes,
                "El atajo no debe modificar el documento cuando la autorización global está retirada.");

            void Seleccionar() { panel.Refrescar(); panel.SeleccionarEstructura(Actual()); Application.DoEvents(); }
            MYGProyectoDocumento Documento() => Campo<MYGProyectoDocumento>(editor, "documento");
            ItemPresupuestoDelphin Actual() => Documento().Presupuestos.Single().Items.Single(p => p.Id == id);
            void Editar(string columna, string valor) => Invocar(editor, "EditarCeldaEstructura", Actual(), columna, valor);
            bool Tecla(Keys teclas)
            {
                object[] argumentos = { Message.Create(editor.Handle, 0x0100, IntPtr.Zero, IntPtr.Zero), teclas };
                return (bool)Invocar(editor, "ProcessCmdKey", argumentos);
            }
        }
        finally { editor.CerrarConfirmado(); }
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados)!.GetValue(objeto)!;
    private static object Invocar(object objeto, string nombre, params object[] argumentos)
    {
        try { return objeto.GetType().GetMethod(nombre, Privados)!.Invoke(objeto, argumentos); }
        catch (TargetInvocationException error) when (error.InnerException != null)
        { ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
    }
}
