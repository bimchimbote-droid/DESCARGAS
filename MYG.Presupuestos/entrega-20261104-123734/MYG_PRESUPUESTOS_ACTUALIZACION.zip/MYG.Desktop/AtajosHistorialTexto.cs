using System.Windows.Forms;

namespace MYG_2027;

internal static class MYGAtajosHistorialTexto
{
    // Un editor de celda intacto no debe impedir deshacer una operación del
    // proyecto. Si existe texto pendiente con historial nativo, éste tiene
    // prioridad hasta que el usuario confirme o cancele la celda.
    internal static bool ConservarEditor(Control editor, bool rehacer) => editor switch
    {
        RichTextBox texto => rehacer ? texto.CanRedo : texto.CanUndo,
        TextBoxBase texto => texto.CanUndo,
        ComboBox lista => lista.DropDownStyle != ComboBoxStyle.DropDownList,
        _ => false
    };
}
