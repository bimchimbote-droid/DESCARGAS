using System.Drawing;
using System.Net.Http;
using System.Windows.Forms;
using MYG_2027;

namespace MYG.Externo;

public sealed class SesionDesktop : IDisposable
{
    private readonly HttpClient http = new() { Timeout = Timeout.InfiniteTimeSpan };
    private readonly LicenciaServicio licencia;
    private readonly SemaphoreSlim validacion = new(1, 1);
    private readonly EstadoSesionLicencia estadoLicencia = new();
    private readonly System.Windows.Forms.Timer reloj = new() { Interval = 60000 };
    private bool revisando;
    public CredencialMYG Credencial { get; private set; }
    public bool Autorizado
    {
        get => estadoLicencia.Autorizado;
        // Conserva el punto privado usado por las comprobaciones de interfaz
        // para preparar una sesión sin consultar un servicio de producción.
        private set
        {
            if (value) estadoLicencia.RegistrarIngreso(new(true, "Licencia validada."));
            else estadoLicencia.Revocar();
        }
    }
    public string AvisoValidacion { get; private set; } = "";
    public event Action Cambio;
    public SesionDesktop()
    {
        licencia = new(http, AccesoWindows.ObtenerMachineId());
        reloj.Tick += async (s, e) => { if (!revisando && Credencial != null) await VerificarAsync(true); };
        reloj.Start();
    }
    public async Task<ResultadoAcceso> EntrarAsync(CredencialMYG c)
    {
        await validacion.WaitAsync(); revisando = true;
        try
        {
            var r = await licencia.ValidarAsync(c);
            if (r.Ok)
            {
                Credencial = c; estadoLicencia.RegistrarIngreso(r); AvisoValidacion = "";
                if (c.RecordarIngreso && r.Token != null) AccesoWindows.GuardarAutomatico(c.Usuario, r.Token);
                Cambio?.Invoke();
            }
            return r;
        }
        finally { revisando = false; validacion.Release(); }
    }
    public async Task<bool> VerificarAsync(bool forzar = false)
    {
        if (!forzar && estadoLicencia.ValidacionReciente) return true;
        await validacion.WaitAsync();
        revisando = true;
        try
        {
            if (!forzar && estadoLicencia.ValidacionReciente) return true;
            if (Credencial?.Automatico == true)
            {
                var actual = AccesoWindows.LeerAutomatico();
                if (actual != null && actual.Usuario == Credencial.Usuario) Credencial = actual;
            }
            var r = await licencia.RevalidarAsync(Credencial);
            estadoLicencia.AplicarRevalidacion(r);
            AvisoValidacion = r.FalloTemporal
                ? Autorizado ? "Licencia pendiente de reconexión; puede continuar trabajando localmente hasta 24 horas desde la última validación."
                    : "No se pudo revalidar la licencia. Conecte a Internet e inicie sesión para continuar."
                : "";
            if (r.Ok)
            {
                if (Credencial.RecordarIngreso && r.Token != null) AccesoWindows.GuardarAutomatico(Credencial.Usuario, r.Token);
            }
            Cambio?.Invoke(); return Autorizado;
        }
        finally { revisando = false; validacion.Release(); }
    }
    public async Task<ResultadoTicketNube> ObtenerTicketNubeAsync(string audiencia)
    {
        await validacion.WaitAsync(); revisando = true;
        try
        {
            if (!Autorizado || Credencial == null)
                throw new InvalidOperationException("Inicie una sesión MYG autorizada para conectar la nube.");
            var resultado = await licencia.ObtenerTicketNubeAsync(Credencial, audiencia);
            if (resultado.LicenciaDenegada)
            {
                estadoLicencia.Revocar();
                AvisoValidacion = "";
                Cambio?.Invoke();
            }
            return resultado;
        }
        finally { revisando = false; validacion.Release(); }
    }
    public void Dispose() { reloj.Stop(); reloj.Dispose(); http.Dispose(); Credencial = null; estadoLicencia.Revocar(); }
}

public sealed class LoginForm : Form
{
    private readonly TextBox usuario = CajaAcceso(false);
    private readonly TextBox clave = CajaAcceso(true);
    private readonly CheckBox recordar = new()
    {
        Text = "Guardar ingreso automático en esta PC",
        Checked = true,
        AutoSize = true,
        ForeColor = MYG2027_TemaComercial.Secundario,
        Margin = new Padding(0, 5, 0, 0)
    };
    private readonly Label estado = new()
    {
        Dock = DockStyle.Fill,
        ForeColor = MYG2027_TemaComercial.Oscuro ? Color.FromArgb(255, 157, 157) : Color.Firebrick,
        Font = new Font("Segoe UI", 9F),
        Margin = new Padding(0, 6, 0, 0)
    };
    private readonly Button entrar, automatico, cancelar;
    private readonly SesionDesktop sesion;
    private bool trabajando;
    public LoginForm(SesionDesktop sesion)
    {
        this.sesion = sesion;
        Text = "MYG Presupuestos | Inicio de sesión";
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(470, 474);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Font = new Font("Segoe UI", 10F);
        BackColor = MYG2027_TemaComercial.AccesoFondo;
        ForeColor = MYG2027_TemaComercial.Texto;
        var barraTema = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48,
            FlowDirection = FlowDirection.RightToLeft, WrapContents = false, Padding = new(8, 4, 8, 4) };
        var tema = MYG2027_TemaComercial.CrearBotonAlternar(); tema.Width = 146; tema.Height = 36;
        barraTema.Controls.Add(tema);
        var cuerpo = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        var t = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Padding = new Padding(40, 18, 40, 18),
            ColumnCount = 1,
            RowCount = 10,
            Margin = new Padding(0)
        };
        foreach (int h in new[] { 43, 28, 25, 36, 25, 36, 32, 44, 44, 62 })
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, h));
        t.ColumnStyles.Add(new(SizeType.Percent, 100));
        t.Controls.Add(new Label
        {
            Text = "MYG Presupuestos",
            Font = new Font("Segoe UI", 17F, FontStyle.Bold),
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = MYG2027_TemaComercial.Texto,
            Margin = new Padding(0)
        }, 0, 0);
        t.Controls.Add(new Label
        {
            Text = "Inicie sesión con su licencia MYG.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = MYG2027_TemaComercial.Secundario,
            Margin = new Padding(0)
        }, 0, 1);
        t.Controls.Add(new Label { Text = "Usuario", Dock = DockStyle.Fill, Margin = new Padding(0) }, 0, 2);
        t.Controls.Add(usuario, 0, 3);
        t.Controls.Add(new Label { Text = "Contraseña", Dock = DockStyle.Fill, Margin = new Padding(0) }, 0, 4);
        t.Controls.Add(clave, 0, 5);
        t.Controls.Add(recordar, 0, 6);
        entrar = BotonAcceso("ACCEDER", true);
        entrar.Click += async (s, e) => await Entrar(false);
        cancelar = BotonAcceso("CANCELAR", false);
        cancelar.DialogResult = DialogResult.Cancel;
        var botones = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            Margin = new Padding(0)
        };
        botones.Controls.Add(cancelar);
        botones.Controls.Add(entrar);
        t.Controls.Add(botones, 0, 7);
        automatico = BotonAcceso("Usar ingreso automático MYG", false);
        automatico.Dock = DockStyle.Fill;
        automatico.Margin = new Padding(0, 3, 0, 3);
        automatico.Click += async (s, e) => await Entrar(true);
        t.Controls.Add(automatico, 0, 8);
        t.Controls.Add(estado, 0, 9);
        cuerpo.Controls.Add(t);
        Controls.Add(cuerpo);
        Controls.Add(barraTema);
        AcceptButton = entrar;
        CancelButton = cancelar;
        var anterior = AccesoWindows.LeerAutomatico(); automatico.Enabled = anterior != null; usuario.Text = anterior?.Usuario ?? "";
        Shown += (s, e) => MYG2027_TemaComercial.AjustarAlAreaDeTrabajo(this);
        FormClosing += (s, e) => { if (trabajando) e.Cancel = true; };
    }
    private static TextBox CajaAcceso(bool esClave) => new()
    {
        Dock = DockStyle.Top,
        BackColor = MYG2027_TemaComercial.AccesoCaja,
        ForeColor = MYG2027_TemaComercial.Texto,
        BorderStyle = BorderStyle.FixedSingle,
        UseSystemPasswordChar = esClave,
        Margin = new Padding(0),
        Font = new Font("Segoe UI", 10F)
    };
    private static Button BotonAcceso(string texto, bool principal)
    {
        var boton = new Button
        {
            Text = texto,
            Width = 120,
            Height = 32,
            FlatStyle = FlatStyle.Flat,
            UseVisualStyleBackColor = false,
            BackColor = principal ? MYG2027_TemaComercial.AccesoAzul : MYG2027_TemaComercial.AccesoCaja,
            ForeColor = Color.White,
            Cursor = Cursors.Hand,
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Margin = new Padding(6, 3, 0, 3)
        };
        MYG2027_TemaComercial.EstilizarBoton(boton, principal ? 1 : 0);
        return boton;
    }
    private async Task Entrar(bool usarAutomatico)
    {
        if (trabajando) return;
        trabajando = true; entrar.Enabled = automatico.Enabled = cancelar.Enabled = false;
        estado.ForeColor = MYG2027_TemaComercial.Secundario; estado.Text = "Validando licencia MYG...";
        try
        {
            var c = usarAutomatico ? AccesoWindows.LeerAutomatico() : new CredencialMYG { Usuario = usuario.Text.Trim(), Clave = clave.Text.Trim(), RecordarIngreso = recordar.Checked };
            var r = await sesion.EntrarAsync(c);
            if (r.Ok) { clave.Clear(); trabajando = false; DialogResult = DialogResult.OK; }
            else { estado.ForeColor = MYG2027_TemaComercial.Oscuro ? Color.FromArgb(255, 157, 157) : Color.Firebrick; estado.Text = r.Mensaje; }
        }
        finally { trabajando = false; entrar.Enabled = cancelar.Enabled = true; automatico.Enabled = AccesoWindows.LeerAutomatico() != null; }
    }
}
