using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private MYGPanelPresupuesto panelPresupuesto;
    private TabControl espacioPresupuestos;
    private FlowLayoutPanel cintaPresupuestos;
    private Label nombreProyectoPresupuesto;
    private Label avisoSesionPresupuesto;
    private Form ventanaHerramientasBim;
    private bool HerramientasBimVisibles => ventanaHerramientasBim?.Visible == true;
    private void InicializarPresupuestos()
    {
        Text = "MYG | Presupuestos y metrados BIM";
        var exterior = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Margin = new(0), Padding = new(0), BackColor = MYGPanelPresupuesto.AzulClaro };
        exterior.ColumnStyles.Add(new(SizeType.Percent, 100)); exterior.RowStyles.Add(new(SizeType.Absolute, 98));
        exterior.RowStyles.Add(new(SizeType.Absolute, 36)); exterior.RowStyles.Add(new(SizeType.Absolute, 0));
        exterior.RowStyles.Add(new(SizeType.Percent, 100));
        InicializarAvisoRecuperacionJerarquia(exterior);
        cintaPresupuestos = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, AutoScroll = true, Padding = new(4), Margin = new(0), BackColor = MYG2027_TemaComercial.Fondo };
        cintaPresupuestos.Name = "herramientas_proyecto";
        Button Accion(string icono, string titulo, Action accion, bool necesitaLicencia = true)
        {
            var b = CrearBotonCintaProyecto(icono, titulo, necesitaLicencia);
            b.Click += async (s, e) => await Ejecutar(() => { accion(); return System.Threading.Tasks.Task.CompletedTask; }, necesitaLicencia);
            cintaPresupuestos.Controls.Add(b); return b;
        }
        InicializarHerramientasProyecto(Accion);
        var seleccion = new Panel { Name = "cabecera_proyecto", Dock = DockStyle.Fill, Margin = new(0), Padding = new(8, 3, 4, 0), BackColor = MYG2027_TemaComercial.AzulSuave };
        // El presupuesto activo se elige desde la estructura; la cabecera
        // reserva todo el ancho para identificar el proyecto.
        nombreProyectoPresupuesto = new Label { Name = "nombre_proyecto_cabecera", Text = documento.Nombre, Dock = DockStyle.Fill,
            AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft, Font = new("Segoe UI", 9, FontStyle.Bold), Margin = new(0) };
        seleccion.Controls.Add(nombreProyectoPresupuesto);
        avisoSesionPresupuesto = new Label { Name = "aviso_validacion_licencia", Dock = DockStyle.Right,
            Width = 330, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleRight,
            ForeColor = MYG2027_TemaComercial.Secundario, Visible = false, Margin = new(0) };
        seleccion.Controls.Add(avisoSesionPresupuesto);
        seleccion.SizeChanged += (_, _) => avisoSesionPresupuesto.Width = Math.Min(350, seleccion.ClientSize.Width / 3);
        espacioPresupuestos = new MYGEspacioProyecto { Name = "espacio_proyecto", Dock = DockStyle.Fill, Margin = new(0) };
        var principal = new TabPage("Presupuesto") { Padding = new(0), BackColor = MYG2027_TemaComercial.Superficie };
        // El presupuesto es el único espacio principal. La tabla antigua se
        // conserva como herramienta modal para bibliotecas y edición en lote.
        Controls.Remove(raiz); raiz.Visible = false; espacioPresupuestos.TabPages.Add(principal);
        Disposed += (_, _) => raiz.Dispose();
        panelPresupuesto = new MYGPanelPresupuesto(() => P, Recordar, ActualizarResumen,
            id =>
            {
                var fila = grid.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin i && i.Id == id);
                if (fila == null) return; grid.ClearSelection();
                if (!fila.Visible) fila.Visible = true;
                grid.CurrentCell = fila.Cells["PARTIDA"]; fila.Selected = true;
            }, async () => await Ejecutar(ActualizarActivo), json =>
            { Recordar(); MYGMotorPresupuestos.ImportarMetradoBIM(documento, P, json); panelPresupuesto.Refrescar(); ActualizarResumen(); }, () => Guardar(false), () => Historial(false), () => Historial(true));
        principal.Controls.Add(panelPresupuesto);
        panelPresupuesto.InicializarActivosRevit(() => documento, GestionarActivosRevit);
        panelPresupuesto.AntesCambioConfiguracionMetradosRevit = (presupuestoEditado, partida) =>
        {
            ExigirPermisoEdicionProyecto();
            undo.Push(MYGEntradaHistorialProyecto.CapturarConfiguracionRevit(documento, presupuestoEditado, partida));
            redo.Clear();
            ActualizarDisponibilidad();
        };
        panelPresupuesto.CambioConfiguracionMetradosRevit = partida =>
        {
            ActualizarFilaConfiguracionMetradosRevit(partida);
            ActualizarResumen(true);
        };
        panelPresupuesto.InicializarCatalogos(RutaCatalogoPropio, () => PuedeModificarProyecto, Refrescar,
            () => string.IsNullOrWhiteSpace(archivo) ? null : MYGBaseDatos.RutaDeProyecto(archivo));
        panelPresupuesto.InicializarEstructura(() => documento, ActivarPresupuestoEstructura, MenuEstructura, EditarCeldaEstructura, UnidadesEstructura);
        panelPresupuesto.InicializarArrastreEstructura(() => !ocupado && PuedeModificarProyecto, Sincronizar, Refrescar);
        panelPresupuesto.InicializarHerramientas((nodo, sentido) => !ocupado && PuedeModificarProyecto && MYGOrdenPresupuestos.PuedeMover(documento, nodo, sentido), MoverFilaEstructura,
            () => { if (!ocupado) { Sincronizar(); panelPresupuesto.GuardarCostosMultiples(); } });
        panelPresupuesto.InicializarAccionesEstructura(() => !ocupado,
            () => copiaEstructura != null && (copiaEsPresupuesto || panelPresupuesto.SeleccionEstructura != null), EjecutarAccionBarraEstructura);
        InicializarCronograma(principal, exterior, seleccion);
        espacioPresupuestos.SelectedIndexChanged += (s, e) => { if (espacioPresupuestos.SelectedIndex == 0) panelPresupuesto.Refrescar(); };
        MYG2027_TemaComercial.Aplicar(cintaPresupuestos);
        exterior.Controls.Add(seleccion, 0, 1); exterior.Controls.Add(espacioPresupuestos, 0, 3); Controls.Add(exterior);
        // Guardar está disponible incluso con la sesión vencida. Las modificaciones mantienen la autorización existente.
        sesion.Cambio += EstadoCintaPresupuestos;
        Disposed += (s, e) => sesion.Cambio -= EstadoCintaPresupuestos;
        MYG2027_TemaComercial.CambioTema += ActualizarTemaEditor;
        Disposed += (s, e) => MYG2027_TemaComercial.CambioTema -= ActualizarTemaEditor;
        EstadoCintaPresupuestos();
        ActualizarAvisoRecuperacionJerarquia();
    }

    private void ActualizarAvisoSesionPresupuestos()
    {
        if (avisoSesionPresupuesto == null) return;
        avisoSesionPresupuesto.Visible = !string.IsNullOrWhiteSpace(sesion.AvisoValidacion);
        avisoSesionPresupuesto.Text = sesion.Autorizado
            ? "⚠ Licencia pendiente de reconexión" : "⚠ Reconecte para validar la licencia";
        ayudas.SetToolTip(avisoSesionPresupuesto, sesion.AvisoValidacion);
    }

    // El editor BIM avanzado comparte los objetos con el panel principal. Sólo
    // renovar las celdas de esta partida evita que Sincronizar las restaure sin
    // reconstruir la estructura, los cálculos, gráficos ni el cronograma.
    private void ActualizarFilaConfiguracionMetradosRevit(ItemPresupuestoDelphin partida)
    {
        bool anterior = cargando; cargando = true;
        grid.SuspendLayout();
        try
        {
            for (int n = 1; n <= P.CantidadFiltros; n++)
            {
                if (grid.Columns.Contains("P" + n)) continue;
                foreach (var campo in new[] { ("P", "PARÁMETRO", 155), ("R", "REGLA", 145), ("V", "VALOR", 160) })
                {
                    string nombre = campo.Item1 + n;
                    var columna = new DataGridViewTextBoxColumn
                    {
                        Name = nombre, HeaderText = campo.Item2, ReadOnly = false,
                        Width = (int)Math.Round((anchosColumnas.TryGetValue(nombre, out var ancho) ? ancho : campo.Item3) * DeviceDpi / 96F),
                        SortMode = DataGridViewColumnSortMode.NotSortable, Visible = !columnasOcultas.Contains(nombre)
                    };
                    columna.DefaultCellStyle.BackColor = MYG2027_TemaComercial.ColorFiltro(n);
                    columna.DefaultCellStyle.ForeColor = MYG2027_TemaComercial.Texto;
                    columna.DefaultCellStyle.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
                    columna.DefaultCellStyle.SelectionForeColor = MYG2027_TemaComercial.Texto;
                    columna.HeaderCell.Style.BackColor = MYG2027_TemaComercial.ColorCabeceraFiltro(n);
                    columna.HeaderCell.Style.ForeColor = MYG2027_TemaComercial.Texto;
                    grid.Columns.Add(columna);
                }
                foreach (DataGridViewRow filaNueva in grid.Rows)
                {
                    if (filaNueva.Tag is not ItemPresupuestoDelphin item || MYGProyectoStorage.EsTitulo(item)) continue;
                    var valores = MYGBibliotecaPartidas.FiltrosGuardables(item);
                    var filtro = n <= valores.Count ? valores[n - 1] : new FiltroPlanificacion();
                    filaNueva.Cells["P" + n].Value = filtro.Parametro;
                    filaNueva.Cells["R" + n].Value = filtro.Regla;
                    filaNueva.Cells["V" + n].Value = filtro.Valor;
                }
            }
            var fila = grid.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin item && item.Id == partida.Id);
            if (fila == null) return;
            fila.Cells["PLANTILLA"].Value = partida.Plantilla;
            var filtros = MYGBibliotecaPartidas.FiltrosGuardables(partida);
            for (int n = 1; n <= P.CantidadFiltros; n++)
            {
                var filtro = n <= filtros.Count ? filtros[n - 1] : new FiltroPlanificacion();
                fila.Cells["P" + n].Value = filtro.Parametro;
                fila.Cells["R" + n].Value = filtro.Regla;
                fila.Cells["V" + n].Value = filtro.Valor;
            }
            fila.Cells["BIBLIOTECA"].Value = biblioteca == null ? "Revisar biblioteca" : MYGBibliotecaPartidas.Estado(biblioteca, partida);
            OpcionesFila(fila);
            ActualizarCeldaRevit(fila);
        }
        finally { cargando = anterior; grid.ResumeLayout(false); AlinearCabecera(); }
    }

    private void AbrirHerramientasBimAvanzadas()
    {
        if (ocupado || ventanaHerramientasBim != null) return;
        Sincronizar();
        using var ventana = new Form();
        MYGProyectoUI.Preparar(ventana, "Herramientas BIM avanzadas · Modelo abierto en Revit", 1400, 780);
        ventana.Name = "herramientas_bim_avanzadas";
        ventana.MinimumSize = new Size(900, 540);
        ventana.StartPosition = FormStartPosition.CenterParent;
        ventanaHerramientasBim = ventana;
        ventana.Controls.Add(raiz);
        raiz.Visible = true;
        MYG2027_TemaComercial.Aplicar(raiz);
        ventana.Shown += (_, _) => AjustarBarras();
        ventana.ClientSizeChanged += (_, _) => AjustarBarras();
        ventana.FormClosing += (_, e) =>
        {
            if (ocupado) { e.Cancel = true; return; }
            try { Sincronizar(); }
            catch (Exception error) { e.Cancel = true; MYGProyectoUI.Error(ventana, error); }
        };
        try { ventana.ShowDialog(this); }
        finally
        {
            // El diálogo no es dueño de estos controles: deben sobrevivir para
            // futuras consultas y para la sincronización interna del editor.
            ventana.Controls.Remove(raiz);
            raiz.Visible = false;
            ventanaHerramientasBim = null;
            Refrescar();
        }
    }

    private void CerrarHerramientasBim()
    {
        if (ventanaHerramientasBim != null) ventanaHerramientasBim.Close();
    }
    private void EstadoCintaPresupuestos()
    {
        if (cintaPresupuestos == null || IsDisposed) return;
        foreach (Button b in cintaPresupuestos.Controls)
            b.Enabled = HerramientaEditorDisponible(b);
        panelPresupuesto?.ActualizarHerramientas();
        EstadoHerramientasCronograma();
    }
    internal static ContextMenuStrip CrearMenuEspecificaciones(Action<MYGAlcanceEspecificaciones> exportar, bool presupuestoDisponible)
    {
        var menu = new ContextMenuStrip
        {
            Name = "menu_especificaciones_proyecto", AccessibleName = "Exportar especificaciones técnicas",
            ImageScalingSize = new Size(20, 20), ShowImageMargin = true
        };
        void Opcion(MYGAlcanceEspecificaciones alcance, string nombre, string texto, string ayuda, string icono, bool disponible)
        {
            var imagen = MYGIconos.Obtener(icono);
            var item = new ToolStripMenuItem(texto, imagen, (_, _) => exportar(alcance))
            {
                Name = nombre, Tag = alcance, Enabled = disponible,
                AccessibleName = texto, AccessibleDescription = ayuda, ToolTipText = ayuda
            };
            item.Disposed += (_, _) => imagen.Dispose();
            menu.Items.Add(item);
        }
        Opcion(MYGAlcanceEspecificaciones.Proyecto, "exportar_especificaciones_proyecto", "Especificaciones de Proyecto",
            "Preparar las especificaciones técnicas de todos los presupuestos del proyecto.", "proyecto", true);
        Opcion(MYGAlcanceEspecificaciones.Presupuesto, "exportar_especificaciones_presupuesto", "Especificaciones de Presupuesto",
            "Preparar las especificaciones técnicas del presupuesto activo.", "especificacion", presupuestoDisponible);
        return menu;
    }
    private void MenuEspecificacionesProyecto(Button boton)
        => MostrarMenuProyecto(CrearMenuEspecificaciones(ExportarEspecificacionesDesdeMenu, P != null), boton);

    private void ExportarEspecificacionesDesdeMenu(MYGAlcanceEspecificaciones alcance)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        // Terminar el clic y cierre del menú antes de entrar en el bucle modal.
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing) return;
            await Ejecutar(async () =>
            {
                Sincronizar();
                if (alcance == MYGAlcanceEspecificaciones.Presupuesto && P == null)
                    throw new InvalidOperationException("Seleccione el presupuesto que desea exportar.");
                using var vista = await MYGEspecificacionesExportacionForm.CrearPreparadaAsync(this, documento, alcance, P?.Id, archivo);
                vista.ShowDialog(this);
            }, false);
        }));
    }
    private void EditarDatosPartida()
    {
        var i = Seleccionadas.FirstOrDefault(); if (i == null) return;
        if (P.Conexion != null && !string.IsNullOrWhiteSpace(i.IdInternoDelphin)) throw new InvalidOperationException("La descripción oficial se actualiza desde Delphin. Edite los datos de costo en MYG.");
        bool titulo = MYGProyectoStorage.EsTitulo(i);
        string id = i.Id;
        var unidades = titulo ? null : MYGCatalogoUnidades.Listar(RutaCatalogoPropio());
        i = P.Items.First(x => x.Id == id);
        using var d = new MYGCamposProyectoForm(titulo ? "Editar título" : "Editar partida", titulo ? new[] { "Descripción" } : new[] { "Descripción", "Unidad" },
            titulo ? new[] { i.Descripcion } : new[] { i.Descripcion, i.Unidad }, unidades: unidades);
        if (d.ShowDialog(this) != DialogResult.OK) return;
        if (!titulo && i.Costos.MetradosBIM.Count > 0 && !MYGProyectoStorage.MismaUnidad(i.Unidad, d.Valores[1]))
            throw new InvalidOperationException("Retire los metrados BIM de la partida antes de cambiar su unidad.");
        Recordar(); i.Descripcion = d.Valores[0]; if (!titulo) i.Unidad = d.Valores[1]; i.EstadoRevit = null; i.MensajeRevit = null; Refrescar();
    }
}
