namespace MYG.Externo;

// Mantiene la autorización de la sesión en memoria mientras se vuelve a
// consultar el servicio. No guarda credenciales ni concede acceso inicial.
public sealed class EstadoSesionLicencia
{
    private readonly TimeProvider reloj;
    private long? ultimaComprobacion;
    private long? ultimaValidacionCorrecta;
    private bool autorizacion;
    public static TimeSpan GraciaSinConexion => TimeSpan.FromHours(24);
    public EstadoSesionLicencia(TimeProvider reloj = null) => this.reloj = reloj ?? TimeProvider.System;
    public bool Autorizado => autorizacion && ultimaValidacionCorrecta is long tick &&
        reloj.GetElapsedTime(tick) < GraciaSinConexion;
    public bool ValidacionReciente => Autorizado && ultimaComprobacion is long tick &&
        reloj.GetElapsedTime(tick) < TimeSpan.FromSeconds(45);

    public void RegistrarIngreso(ResultadoAcceso resultado)
    {
        ArgumentNullException.ThrowIfNull(resultado);
        if (!resultado.Ok) return;
        autorizacion = true;
        ultimaComprobacion = ultimaValidacionCorrecta = reloj.GetTimestamp();
    }

    public bool AplicarRevalidacion(ResultadoAcceso resultado)
    {
        ArgumentNullException.ThrowIfNull(resultado);
        if (resultado.Ok)
            RegistrarIngreso(resultado);
        else if (!resultado.FalloTemporal || !Autorizado)
            Revocar();
        // Tras un fallo temporal se reintenta en el siguiente intervalo; no
        // se vuelve a bloquear cada acción local con otra espera de red.
        if (Autorizado) ultimaComprobacion = reloj.GetTimestamp();
        return Autorizado;
    }

    public void Revocar()
    {
        autorizacion = false;
        ultimaComprobacion = ultimaValidacionCorrecta = null;
    }
}
