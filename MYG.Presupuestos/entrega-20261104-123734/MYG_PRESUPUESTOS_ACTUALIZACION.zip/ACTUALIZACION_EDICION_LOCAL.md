# Actualización de edición local, avisos e historial

Entrega del 4 de noviembre de 2026 para `bimchimbote-droid/MYG.Presupuestos`, rama `main`, base `6e9dfdeee65603d287be5d596dc607826f7de19f`. Se comprobó que la rama remota seguía en ese commit. No se hizo commit ni push del código fuente.

## Cambios

- Una sesión MYG ya validada puede seguir trabajando ante errores temporales de conexión, timeout, HTTP 503 o respuestas inválidas del servicio de licencias. La gracia dura hasta 24 horas desde la última validación correcta, sólo en memoria; los reintentos fallidos no renuevan ese plazo. Se muestra un aviso discreto de reconexión. Iniciar una sesión nueva sigue necesitando autorización real. HTTP 401/403, licencia expirada/bloqueada y otras denegaciones explícitas revocan inmediatamente. No se cambian permisos de nube ni la validación real de Revit.
- Los nombres de títulos y partidas, incluidas las importadas de Delphin, se pueden editar en la columna Descripción con doble clic o F2. Se conservan los identificadores, vínculos y ACU. La numeración automática mantiene su comportamiento.
- Cuando nombre o unidad difieren del registro identificado en el catálogo de la base activa, se muestra un pequeño icono de advertencia en la fila, con explicación al pasar el cursor. No aparece una ventana por esa diferencia. Al volver a los datos originales desaparece ese aviso; otras alertas, como cantidad cero, pueden permanecer.
- Ctrl+Z y Ctrl+Y usan el historial del proyecto después de cambios confirmados, aunque un número o selector mantenga el foco. Deshacer mediante un botón confirma primero la celda pendiente. El texto todavía en edición y las búsquedas conservan sus atajos nativos. Una nueva edición después de deshacer elimina la rama anterior de Rehacer.

Las modificaciones del presupuesto no actualizan por sí solas el catálogo. Una actualización explícita posterior desde el origen o catálogo puede volver a aplicar sus datos, como antes de esta entrega.

## Instalación manual

1. Cierre MYG y Visual Studio. Respalde sus bases SQLite y los cambios locales del código, o confirme estos últimos en Git.
2. Extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip` fuera del proyecto. Contiene sólo los archivos nuevos o modificados de esta entrega, con sus rutas relativas originales.
3. Copie el contenido en la carpeta que contiene `MYG.Presupuestos.sln`, conservando las subcarpetas. Por ejemplo, si ésa es su ubicación habitual: `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`. Cree los archivos nuevos y reemplace los existentes. No se elimina ningún archivo.
4. Si modificó alguno de esos archivos después del commit base, compare y fusione sus cambios antes de reemplazarlo: una sustitución completa podría perderlos.
5. Abra la solución en Visual Studio 2026 con SDK .NET 10. Restaure y compile. No se necesitan nuevas dependencias, migraciones SQL ni cambios de configuración de la base.
6. Ejecute las comprobaciones indicadas abajo y pruebe una copia de su base antes de continuar con su trabajo habitual.

## Restaurar, compilar y probar

Desde la raíz del proyecto, para comprobar la solución sin requerir las DLL instaladas de Autodesk:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release --no-restore -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore -- --edicion-presupuesto
```

El último comando requiere Windows. Para compilar normalmente el conector con Revit 2027 instalado, utilice la configuración de `RevitInstallDir` ya documentada y omita `UseRevitReferencePackages=true`.

### Resultados reales de esta entrega

- SDK .NET 10.0.100 en Linux x64; solución completa Release: **0 errores y 0 advertencias**.
- Suite `MYG.Pruebas`: **844 comprobaciones aprobadas**, frente a 839 del commit base. Se verificó el archivo `resultado_qa.json` de esta ejecución.
- Ejecución focalizada `--edicion-presupuesto`: **17 comprobaciones aprobadas**.
- Ejecución focalizada `--sesion-local`: **2 grupos aprobados**, con reloj controlado y HTTP simulado para timeout, recuperación, caducidad, errores temporales y revocación.
- Las pruebas SQLite incluyen renombrar una partida nativa vinculada a `AC-EDICION`, guardar/reabrir/restaurar el nombre, conservar catálogo original, composiciones y otra obra; también prueban el orden deshacer/rehacer de nombres y unidades y la desaparición de la alerta.
- Se ampliaron y compilaron pruebas WinForms del icono, la edición y los atajos. **No se ejecutaron**: necesitan Windows. No se verificaron visualmente los formularios ni se abrió un modelo real de Revit.
- La suite principal conserva seis omisiones explícitas por muestras externas ausentes y Named Pipes de Windows.
- Durante la preparación del entorno, la suite Nube tenía dos incompatibilidades previas entre fixtures e implementación: la fase esperada después de renovar sesión en `PublicacionLigeraCheck.cs:399` y el permiso `metrados_revit` omitido por el mock de `PublicacionComprimidaCheck.cs:805`. No se cambiaron ni se ocultaron esos fallos. Diez grupos posteriores pasaron por ejecución independiente. No se declara aprobada la suite Nube completa.

### Comprobaciones manuales pendientes en Windows

1. Sobre una copia de una base, cambie el nombre de un título y de una partida importada; confirme con Enter o Tab. Cambie también una unidad compatible.
2. Compruebe el pequeño aviso de diferencia con el catálogo; restaure el nombre y la unidad originales y compruebe que desaparece ese aviso sin ventanas.
3. Ejecute Ctrl+Z varias veces: debe volver por unidad, nombre y cambios anteriores en orden inverso. Use Ctrl+Y para rehacer; repita dejando el foco en un selector o número. Mientras escribe texto sin confirmar, Ctrl+Z conserva el comportamiento de edición de texto.
4. Guarde y vuelva a abrir la copia; compruebe nombres, unidades, ACU y otras obras.
5. Con una sesión previamente validada, pruebe una interrupción de Internet durante la revalidación periódica: debe continuar la edición local y aparecer el aviso. Reconecte y compruebe la recuperación. No pruebe revocaciones sobre una licencia de producción sin un entorno autorizado.

## GitHub y entrega

El repositorio independiente `bimchimbote-droid/DESCARGAS` existe y es público. La entrega utiliza Git HTTPS con la autenticación ya disponible y una ruta nueva, sin reemplazar entregas anteriores. Esta vía no requiere acceso a la API de GitHub. El enlace de descarga se fija al commit de publicación y se comprueba descargando el ZIP y comparando su SHA-256 con el archivo original. El ZIP público contiene únicamente los archivos indicados; no contiene bases de datos ni credenciales.

Para publicar el código usted mismo después de validar: abra **Cambios de Git** en Visual Studio, revise la lista de archivos y el diff, compruebe la rama `main`, haga **Commit**, luego **Push**, y verifique el commit en GitHub. La publicación del ZIP en DESCARGAS no aplica los cambios al código ni autoriza un push a este repositorio.
