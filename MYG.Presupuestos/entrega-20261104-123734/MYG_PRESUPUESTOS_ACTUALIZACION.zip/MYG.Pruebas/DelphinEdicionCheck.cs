using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinEdicionCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Huella(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
    private static object Sql(string ruta, string sql, params object[] datos)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Pooling = false, ForeignKeys = true }.ToString());
        c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = sql;
        for (int n = 0; n < datos.Length; n++) cmd.Parameters.AddWithValue("$p" + n,
            datos[n] is decimal d ? d.ToString(CultureInfo.InvariantCulture) : datos[n] ?? DBNull.Value);
        return cmd.ExecuteScalar();
    }
    private static void Rechaza(Action accion)
    {
        try { accion(); } catch (InvalidOperationException) { return; }
        throw new Exception("Se permitió reemplazar una composición Delphin importada sin protección.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Edición protegida Delphin sintética.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var d = MYGProyectoStorage.Nuevo("EDICIÓN DELPHIN SINTÉTICA");
        d.Id = "PR-EDICION";
        var p = d.Presupuestos.Single(); p.Id = "PP-EDICION"; d.PresupuestoActivoId = p.Id;
        var i = new ItemPresupuestoDelphin
        {
            Id = "CU-EDICION", IdLocalMYG = "DELPHIN-LOCAL-CU-EDICION", IdInternoDelphin = "CU-EDICION",
            Descripcion = "PARTIDA SINTÉTICA", Unidad = "und", TipoPropuesta = "PARTIDA",
            Item = "01", Posicion = 1, Origen = "DELPHIN", Estado = "OFICIAL"
        };
        i.Costos.Cantidad = 3;
        var insumo = new MYGInsumo { Id = "LP-EDICION", Descripcion = "MATERIAL SINTÉTICO", Unidad = "kg", Precio = 1 };
        p.Costos.Insumos.Add(insumo); p.Items.Add(i);
        i.Costos.Analisis.Add(new MYGRecursoACU { Id = "CO-EDICION", InsumoId = insumo.Id, Cantidad = 1 });
        MYGProyectoStorage.Guardar(ruta, d);
        var vecina = MYGProyectoStorage.Nuevo("OBRA VECINA"); vecina.Id = "PR-VECINA";
        var presupuestoVecino = vecina.Presupuestos.Single(); presupuestoVecino.Id = "PP-VECINA";
        vecina.PresupuestoActivoId = presupuestoVecino.Id;
        presupuestoVecino.Items.Add(new ItemPresupuestoDelphin
        { Id = "CU-VECINA", IdLocalMYG = "CU-VECINA", Descripcion = "PARTIDA VECINA", Unidad = "und",
            TipoPropuesta = "PARTIDA", Costos = new MYGDatosPartida { Cantidad = 7, PrecioDirecto = 9 } });
        MYGProyectoStorage.Guardar(ruta, vecina);
        // Simula la primera lectura de una composición externa, incluyendo un
        // subárbol que no aparece en la representación plana editable de MYG.
        Sql(ruta, """
            INSERT INTO subtotal_costounitario(id_subtotal,id_costounitario,id_tipocosto,id_composicionpadre,subtotal)
                VALUES('SU-ANIDADO','CU-EDICION','TC0000000001','CO-EDICION',0);
            INSERT INTO composicion_costounitario(id_composicion,id_subtotal,descripcion_composicion,cantidad_composicion,costo_composicion)
                VALUES('CO-ANIDADO','SU-ANIDADO','HIJO NATIVO',0,0);
            UPDATE costo_unitario SET cantidad_metrado=71,Notas1='META NATIVA';
            DELETE FROM myg_delphin_fila;
            """);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, i, 1, 3);
        MYGMotorPresupuestos.CapturarDatosDelphin(p, i);
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(p);
        var editado = MYGProyectoStorage.Copia(d);
        editado.Presupuestos[0].Items[0].Costos.Analisis[0].Cantidad = 2;
        MYGProyectoStorage.Guardar(ruta, editado);
        Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM composicion_costounitario")) == 1 &&
            Convert.ToDecimal(Sql(ruta, "SELECT costo_unitario FROM costo_unitario WHERE id_costounitario='CU-EDICION'")) == 2 &&
            Convert.ToDecimal(Sql(ruta, "SELECT cantidad_metrado FROM costo_unitario WHERE id_costounitario='CU-EDICION'")) == 71 &&
            (string)Sql(ruta, "SELECT Notas1 FROM costo_unitario WHERE id_costounitario='CU-EDICION'") == "META NATIVA",
            "Editar el ACU registrado duplicó recursos o alteró metadatos nativos independientes.");
        Exige(Convert.ToDecimal(Sql(ruta, "SELECT costo_unitario FROM costo_unitario WHERE id_costounitario='CU-VECINA'")) == 9 &&
            Convert.ToDecimal(Sql(ruta, "SELECT parcial_costo FROM costo_unitario WHERE id_costounitario='CU-VECINA'")) == 63 &&
            Convert.ToDecimal(Sql(ruta, "SELECT total_presupuesto FROM presupuesto WHERE id_presupuesto='PP-VECINA'")) == 63,
            "La primera edición del ACU alteró el presupuesto o partida de otra obra.");
        pasa("Primera edición de ACU importado adopta sólo su árbol exclusivo, evita duplicados y conserva presupuestos vecinos");

        var siguiente = MYGBaseDatos.LeerProyecto(ruta, d.Id);
        siguiente.Presupuestos[0].Items[0].Costos.Analisis[0].Cantidad = 3;
        MYGProyectoStorage.Guardar(ruta, siguiente);
        Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM composicion_costounitario")) == 1 &&
            Convert.ToDecimal(Sql(ruta, "SELECT costo_unitario FROM costo_unitario WHERE id_costounitario='CU-EDICION'")) == 3,
            "Editar por segunda vez duplicó el análisis registrado.");
        pasa("Ediciones posteriores del ACU actualizan las mismas filas gestionadas");

        string unidad = (string)Sql(ruta, "SELECT id_unidad FROM unidad WHERE abreviatura_unidad='und'");
        Sql(ruta, """
            INSERT INTO analisis_costo(id_analisiscosto,descripcion_costo,id_unidad,costo_unitario,codigo_listaprecio)
                VALUES('AC-EDICION','CATÁLOGO SINTÉTICO',$p0,1,'CAT-ORIGINAL');
            INSERT INTO subtotal_analisiscosto(id_subtotal,id_analisiscosto,id_tipocosto,subtotal)
                VALUES('SU-CATALOGO','AC-EDICION','TC0000000002',1);
            INSERT INTO composicion_analisiscosto(id_composicion,id_subtotal,descripcion_composicion,id_listaprecio,cantidad_composicion,costo_composicion,parcial_composicion)
                VALUES('CO-CATALOGO','SU-CATALOGO','MATERIAL SINTÉTICO','LP-EDICION',1,1,1);
            """, unidad);
        var plantilla = MYGCatalogos.CrearPlantilla(p, i);
        Sql(ruta, """
            INSERT INTO catalogo_partida(id,codigo,descripcion,unidad,precio,json_plantilla,revision,modificado_utc)
                VALUES('AC-EDICION','CAT-ORIGINAL','CATÁLOGO SINTÉTICO','und','1',$p0,1,$p1)
            """, JsonSerializer.Serialize(plantilla), DateTime.UtcNow.ToString("O"));
        VerificarNombreOficialVinculado(ruta, d.Id, vecina.Id, pasa);
        var registro = MYGCatalogos.GuardarPartida(ruta, p, i, "CAT-ORIGINAL", "CATÁLOGO RENOMBRADO", "jgo", "AC-EDICION", 1);
        Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM composicion_analisiscosto")) == 1 &&
            (string)Sql(ruta, "SELECT id_composicion FROM composicion_analisiscosto") == "CO-CATALOGO" &&
            (string)Sql(ruta, "SELECT descripcion_costo FROM analisis_costo WHERE id_analisiscosto='AC-EDICION'") == registro.Descripcion,
            "Cambiar metadatos de catálogo duplicó o reemplazó su composición nativa.");
        var recargada = MYGCatalogos.LeerPartida(ruta, registro.Id);
        var pCatalogo = new MYGPresupuestoDocumento { Nombre = "CATÁLOGO RECARGADO", Items = recargada.Partidas,
            Costos = new MYGCostosPresupuesto { Insumos = recargada.Insumos } };
        var raizRecargada = pCatalogo.Items.Single(x => x.IdLocalMYG == recargada.RaizLocalId);
        registro = MYGCatalogos.GuardarPartida(ruta, pCatalogo, raizRecargada, registro.Codigo,
            "SEGUNDA EDICIÓN DE TEXTO", registro.Unidad, registro.Id, registro.Revision);
        Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM composicion_analisiscosto")) == 1,
            "Una edición posterior de metadatos perdió la firma del análisis nativo.");
        pasa("Cambiar descripción y unidad de un catálogo importado preserva su composición nativa");

        i.Costos.Analisis[0].Cantidad = 2;
        string antes = Huella(ruta);
        Rechaza(() => MYGCatalogos.GuardarPartida(ruta, p, i, registro.Codigo, "CAMBIO RECHAZADO", "und", registro.Id, registro.Revision));
        Exige(Huella(ruta) == antes, "El rechazo del catálogo dejó una revisión o composición parcial.");
        var copia = MYGCatalogos.GuardarPartida(ruta, p, i, "CAT-COPIA", "COPIA EDITABLE", "und");
        Exige(copia.Precio == 2 && Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM composicion_analisiscosto")) == 2 &&
            Convert.ToDecimal(Sql(ruta, "SELECT costo_unitario FROM analisis_costo WHERE id_analisiscosto='AC-EDICION'")) == 1,
            "La copia del catálogo alteró el análisis original o no exportó su precio nuevo.");
        antes = Huella(ruta);
        Rechaza(() => MYGCatalogos.Eliminar(ruta, true, registro));
        Exige(Huella(ruta) == antes, "Eliminar el catálogo original dejó filas nativas huérfanas.");
        MYGCatalogos.Eliminar(ruta, true, copia);
        Exige(Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM composicion_analisiscosto")) == 1 &&
            Convert.ToInt64(Sql(ruta, "SELECT COUNT(*) FROM analisis_costo WHERE id_analisiscosto='AC-EDICION'")) == 1,
            "Eliminar la copia MYG borró la entrada original o dejó su propio ACU huérfano.");
        pasa("Cambiar el ACU de un catálogo externo revierte la escritura; guardar una copia nueva permite editarlo y conserva el original");
    }

    private static void VerificarNombreOficialVinculado(string ruta, string proyectoId, string vecinoId, Action<string> pasa)
    {
        var doc = MYGBaseDatos.LeerProyecto(ruta, proyectoId);
        var p = doc.Presupuestos.Single(); var i = p.Items.Single();
        i.IdCatalogoDelphin = i.IdAnalisisDelphin = "AC-EDICION";
        i.CodigoCatalogoDelphin = "CAT-ORIGINAL";
        var registro = MYGRegistroACUCatalogo.Leer(ruta);
        Exige(registro.Estado(i) == MYGEstadoRegistroACU.Registrado && registro.DescripcionCatalogo(i) == "CATÁLOGO SINTÉTICO",
            "La partida nativa debe compararse con su análisis oficial existente, no con su propia fila de costos.");
        string vecino = JsonSerializer.Serialize(MYGBaseDatos.LeerProyecto(ruta, vecinoId));
        string acu = JsonSerializer.Serialize(i.Costos.Analisis);
        decimal precio = MYGMotorPresupuestos.Analizar(p, i).PrecioUnitario;
        MYGEdicionPartida.CambiarDescripcion(p, i, "NOMBRE PERSONALIZADO DE OBRA");
        MYGProyectoStorage.Guardar(ruta, doc);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, proyectoId); var fila = reabierto.Presupuestos.Single().Items.Single();
        Exige(fila.Descripcion == "NOMBRE PERSONALIZADO DE OBRA" && fila.IdInternoDelphin == "CU-EDICION" &&
            fila.IdAnalisisDelphin == "AC-EDICION" && fila.IdCatalogoDelphin == "AC-EDICION" &&
            (string)Sql(ruta, "SELECT descripcion_costo FROM costo_unitario WHERE id_costounitario='CU-EDICION'") == fila.Descripcion &&
            (string)Sql(ruta, "SELECT descripcion_costo FROM analisis_costo WHERE id_analisiscosto='AC-EDICION'") == "CATÁLOGO SINTÉTICO" &&
            (string)Sql(ruta, "SELECT descripcion FROM catalogo_partida WHERE id='AC-EDICION'") == "CATÁLOGO SINTÉTICO" &&
            JsonSerializer.Serialize(fila.Costos.Analisis) == acu &&
            MYGMotorPresupuestos.Analizar(reabierto.Presupuestos.Single(), fila).PrecioUnitario == precio &&
            JsonSerializer.Serialize(MYGBaseDatos.LeerProyecto(ruta, vecinoId)) == vecino &&
            MYGRegistroACUCatalogo.Leer(ruta).DescripcionDiferente(fila),
            "Renombrar una fila Delphin vinculada debe persistir en la obra conservando IDs, ACU, referencia nativa, catálogo compartido y obra vecina.");
        MYGEdicionPartida.CambiarDescripcion(reabierto.Presupuestos.Single(), fila, "CATÁLOGO SINTÉTICO");
        MYGProyectoStorage.Guardar(ruta, reabierto);
        var restaurada = MYGBaseDatos.LeerProyecto(ruta, proyectoId).Presupuestos.Single().Items.Single();
        Exige(!MYGRegistroACUCatalogo.Leer(ruta).DescripcionDiferente(restaurada) &&
            (string)Sql(ruta, "SELECT descripcion_costo FROM analisis_costo WHERE id_analisiscosto='AC-EDICION'") == "CATÁLOGO SINTÉTICO" &&
            JsonSerializer.Serialize(MYGBaseDatos.LeerProyecto(ruta, vecinoId)) == vecino,
            "Restaurar el nombre de catálogo debe quitar la diferencia después de guardar sin cambiar el análisis ni la obra vecina.");
        pasa("Renombrar una partida Delphin vinculada a análisis y catálogo nativos persiste sólo en la obra, conserva ACU y obra vecina y permite restaurar el nombre original");
    }
}
