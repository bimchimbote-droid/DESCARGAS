using System.Net;
using MYG.Externo;

internal static class SesionLocalLicenciaCheck
{
    private const string Url = "https://licencias.example.invalid/exec";
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }
    private static ResultadoAcceso Temporal() => new(false, "Conexión interrumpida.") { FalloTemporal = true };

    internal static async Task EjecutarAsync(Action<string> pasa)
    {
        var reloj = new Reloj();
        var estado = new EstadoSesionLicencia(reloj);
        estado.RegistrarIngreso(Temporal());
        Exige(!estado.Autorizado && !estado.AplicarRevalidacion(Temporal()) && !estado.ValidacionReciente,
            "Un fallo de conexión permitió iniciar una sesión local sin autorización.");
        estado.RegistrarIngreso(new(true, "OK"));
        reloj.Avanzar(TimeSpan.FromSeconds(44));
        Exige(estado.Autorizado && estado.ValidacionReciente, "No se conserva la validación reciente.");
        reloj.Avanzar(TimeSpan.FromSeconds(1));
        Exige(!estado.ValidacionReciente, "No se vuelve a comprobar la sesión tras 45 segundos.");
        Exige(estado.AplicarRevalidacion(Temporal()) && estado.ValidacionReciente,
            "Un corte de conexión bloqueó el trabajo local previamente autorizado.");
        reloj.Avanzar(TimeSpan.FromHours(23));
        Exige(estado.AplicarRevalidacion(Temporal()), "La sesión se bloqueó antes de vencer la gracia local.");
        reloj.Avanzar(TimeSpan.FromHours(1) - TimeSpan.FromSeconds(45));
        Exige(!estado.Autorizado && !estado.AplicarRevalidacion(Temporal()) && !estado.ValidacionReciente,
            "Los reintentos temporales extendieron la gracia más allá de 24 horas desde el último éxito.");
        Exige(estado.AplicarRevalidacion(new(true, "OK")) && estado.ValidacionReciente,
            "La sesión no se recuperó tras una revalidación real correcta.");
        reloj.Avanzar(TimeSpan.FromHours(23));
        Exige(estado.AplicarRevalidacion(new(true, "OK")), "No se pudo actualizar la última validación correcta.");
        reloj.Avanzar(TimeSpan.FromHours(2));
        Exige(estado.Autorizado, "La gracia no se renovó después de validar correctamente con el servidor.");
        Exige(!estado.AplicarRevalidacion(new(false, "Licencia bloqueada.")) && !estado.Autorizado,
            "Una denegación explícita no revocó inmediatamente el acceso local.");
        Exige(!estado.AplicarRevalidacion(Temporal()), "Un corte posterior reactivó una licencia denegada.");
        pasa("Sesión local: conserva el trabajo ante fallos temporales hasta 24 horas desde el último éxito, reintenta y respeta revocación inmediata");

        var credencial = new CredencialMYG { Usuario = "usuario-prueba", Clave = "clave-sintetica" };
        foreach (string codigo in new[] { "BLOQUEADO", "EXPIRADO", "OTRA_PC", "CLAVE_ERROR", "TOKEN_INVALIDO", "NO_EXISTE", "AUTO_DESACTIVADO", "FECHA_INVALIDA" })
        {
            using var http = new HttpClient(new Transporte((_, _) => Task.FromResult(Respuesta(codigo))));
            var resultado = await new LicenciaServicio(http, "PC-PRUEBA", Url).RevalidarAsync(credencial);
            estado.RegistrarIngreso(new(true, "OK"));
            Exige(!resultado.Ok && !resultado.FalloTemporal && !estado.AplicarRevalidacion(resultado),
                "La licencia denegada se confundió con un corte temporal: " + codigo);
        }
        foreach (var codigo in new[] { HttpStatusCode.Unauthorized, HttpStatusCode.Forbidden, HttpStatusCode.ServiceUnavailable, HttpStatusCode.BadGateway, HttpStatusCode.TooManyRequests })
        {
            using var http = new HttpClient(new Transporte((_, _) => Task.FromResult(Respuesta("respuesta privada", codigo))));
            var resultado = await new LicenciaServicio(http, "PC-PRUEBA", Url).RevalidarAsync(credencial);
            bool temporal = codigo is not (HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden);
            estado.RegistrarIngreso(new(true, "OK"));
            Exige(!resultado.Ok && resultado.FalloTemporal == temporal && estado.AplicarRevalidacion(resultado) == temporal,
                "La revalidación no distingue un fallo HTTP temporal de una denegación de acceso.");
            Exige(!resultado.Mensaje.Contains("respuesta privada"), "La revalidación expuso el cuerpo de un error HTTP.");
        }
        foreach (Exception error in new Exception[] { new HttpRequestException("red cortada"), new IOException("recepción cortada"), new OperationCanceledException() })
        {
            using var http = new HttpClient(new Transporte((_, _) => throw error));
            var resultado = await new LicenciaServicio(http, "PC-PRUEBA", Url).RevalidarAsync(credencial);
            Exige(!resultado.Ok && resultado.FalloTemporal, "Un timeout o fallo de recepción revocó la sesión en lugar de permitir reintento.");
        }
        foreach (string texto in new[] { "<html>puerta de enlace</html>", "OK|" + new string('T', 64), "DATOS_INCOMPLETOS" })
        {
            using var http = new HttpClient(new Transporte((_, _) => Task.FromResult(Respuesta(texto))));
            var resultado = await new LicenciaServicio(http, "PC-PRUEBA", Url).RevalidarAsync(credencial);
            Exige(!resultado.Ok && resultado.FalloTemporal && resultado.Token == null,
                "Un servicio anterior o una respuesta no reconocida se confundió con una autorización o revocación.");
        }
        using (var http = new HttpClient(new Transporte((_, _) => Task.FromResult(Respuesta("OK", HttpStatusCode.ServiceUnavailable)))))
        {
            var resultado = await new LicenciaServicio(http, "PC-PRUEBA", Url).ValidarAsync(credencial);
            var nueva = new EstadoSesionLicencia(reloj);
            nueva.RegistrarIngreso(resultado);
            Exige(!resultado.Ok && !nueva.Autorizado, "El modo local permitió un ingreso nuevo sin validar contra el servicio.");
        }
        pasa("Licencia: HTTP 401/403 y códigos de denegación bloquean; timeout, 503 y respuesta inválida conservan sólo una sesión ya validada");
    }

    private static HttpResponseMessage Respuesta(string texto, HttpStatusCode estado = HttpStatusCode.OK) =>
        new(estado) { Content = new StringContent(texto) };
    private sealed class Transporte(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> responder) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken cancelacion) => responder(solicitud, cancelacion);
    }
    private sealed class Reloj : TimeProvider
    {
        private long tick;
        public override long TimestampFrequency => TimeSpan.TicksPerSecond;
        public override long GetTimestamp() => tick;
        public void Avanzar(TimeSpan tiempo) => tick += tiempo.Ticks;
    }
}
