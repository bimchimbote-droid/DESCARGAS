using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class PaqueteNubeCheck
{
    public static Task RunAsync()
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-paquete-regresion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        int comprobaciones = 0;
        void Exige(bool condicion, string mensaje)
        {
            comprobaciones++;
            if (!condicion) throw new InvalidOperationException("Paquete de nube: " + mensaje);
        }
        try
        {
            var obraA = MYGProyectoStorage.Nuevo("Obra A");
            var obraB = MYGProyectoStorage.Nuevo("Obra B PRIVADA");
            string imagen = Path.Combine(carpeta, "foto.txt");
            File.WriteAllText(imagen, "adjunto sintético", Encoding.UTF8);
            obraA.Presupuestos[0].Costos.Insumos.Add(new MYGInsumo
            {
                Descripcion = "Material A", ImagenRuta = imagen, Precio = 12.12345678901234567890123456m
            });
            obraA.Presupuestos[0].Items.Add(Partida("PARTIDAA", "Partida A"));
            obraB.Presupuestos[0].Items.Add(Partida("PARTIDAB", "Partida B PRIVADA"));
            string origen = Path.Combine(carpeta, "origen.sqlite");
            MYGProyectoStorage.Guardar(origen, obraA);
            MYGProyectoStorage.Guardar(origen, obraB);
            Ejecutar(origen, """
                UPDATE costo_unitario SET archivo_pdf=X'010203',Notas1='nativo A' WHERE id_costounitario='PARTIDAA';
                INSERT INTO planoteca VALUES(1,'Plano A','a.pdf',X'AA',(SELECT id_proyecto FROM proyecto WHERE nombre_proyecto='Obra A'));
                INSERT INTO planoteca VALUES(2,'Plano PRIVADO B','b.pdf',X'BB',(SELECT id_proyecto FROM proyecto WHERE nombre_proyecto='Obra B PRIVADA'));
                CREATE TABLE secreto_extension(password TEXT);
                INSERT INTO secreto_extension VALUES('NUNCA-EXPORTAR');
                """);
            byte[] hashOrigen = SHA256.HashData(File.ReadAllBytes(origen));
            JsonElement paquete = PaqueteNube.CrearContenido(obraA, origen);
            Exige(!paquete.GetRawText().Contains("PRIVADA", StringComparison.Ordinal)
                && !paquete.GetRawText().Contains("NUNCA-EXPORTAR", StringComparison.Ordinal),
                "publicar una obra incluyó información de otra obra o una extensión desconocida.");
            Exige(paquete.GetProperty("tablas").EnumerateArray().All(t =>
                t.GetProperty("Nombre").GetString() is not ("usuario" or "usuario_map" or "parametro" or "perfil" or "myg_colaboracion_local")),
                "se incluyeron tablas privadas o de configuración.");

            string descarga = Path.Combine(carpeta, "descarga.sqlite");
            PaqueteNube.Descargar(paquete, descarga);
            var documento = MYGProyectoStorage.Leer(descarga);
            Exige(MYGBaseDatos.ListarProyectos(descarga).Count == 1 && documento.Id == obraA.Id,
                "la descarga de obra no conservó su identidad o incluyó más proyectos.");
            Exige(documento.Presupuestos[0].Costos.Insumos[0].Precio == obraA.Presupuestos[0].Costos.Insumos[0].Precio,
                "la descarga cambió la precisión decimal.");
            Exige(File.ReadAllText(documento.Presupuestos[0].Costos.Insumos[0].ImagenRuta, Encoding.UTF8) == "adjunto sintético",
                "no se recuperaron los bytes del adjunto en una ruta local.");
            Exige((string?)Consultar(descarga, "SELECT Notas1 FROM costo_unitario WHERE id_costounitario='PARTIDAA'") == "nativo A"
                && (long?)Consultar(descarga, "SELECT COUNT(*) FROM planoteca") == 1,
                "no se conservaron los metadatos y adjuntos nativos exclusivos de la obra.");
            Exige(((byte[]?)Consultar(descarga, "SELECT archivo_pdf FROM costo_unitario WHERE id_costounitario='PARTIDAA'"))?.SequenceEqual(new byte[] { 1, 2, 3 }) == true,
                "se modificaron los bytes de un adjunto nativo SQLite.");
            Exige((string?)Consultar(descarga, "PRAGMA integrity_check") == "ok", "la descarga produjo una base dañada.");
            string trabajo = Path.Combine(carpeta, "trabajo.sqlite");
            var materializado = PaqueteNube.MaterializarDocumento(paquete, trabajo);
            Exige(File.Exists(materializado.Presupuestos[0].Costos.Insumos[0].ImagenRuta) && !File.Exists(trabajo),
                "materializar adjuntos escribió la base de trabajo o no recuperó el archivo.");
            JsonElement vueltaObra = PaqueteNube.CrearContenido(documento, descarga);
            Exige(PaqueteNube.FirmaDatosCompartidos(paquete) == PaqueteNube.FirmaDatosCompartidos(vueltaObra),
                "descargar y reconstruir una obra introdujo cambios compartidos ficticios.");

            JsonElement completa = PaqueteNube.CrearContenido(obraA, origen, "base");
            string baseCompleta = Path.Combine(carpeta, "base.sqlite");
            PaqueteNube.Descargar(completa, baseCompleta);
            Exige(MYGBaseDatos.ListarProyectos(baseCompleta).Count == 2 && (long?)Consultar(baseCompleta, "SELECT COUNT(*) FROM planoteca") == 2,
                "la descarga de base completa no conservó ambas obras y sus datos nativos.");
            Exige(!completa.GetRawText().Contains("NUNCA-EXPORTAR", StringComparison.Ordinal),
                "la base completa incluyó una extensión desconocida.");
            JsonElement vueltaBase = PaqueteNube.CrearContenido(MYGBaseDatos.LeerProyecto(baseCompleta, obraA.Id), baseCompleta, "base");
            Exige(PaqueteNube.FirmaDatosCompartidos(completa) == PaqueteNube.FirmaDatosCompartidos(vueltaBase),
                "descargar y reconstruir una base introdujo cambios compartidos ficticios.");

            var editado = MYGProyectoStorage.Copia(obraA);
            editado.Nombre = "Obra A editada";
            JsonElement actualizado = PaqueteNube.ActualizarDocumento(completa, editado);
            Exige(actualizado.GetProperty("recursos").GetArrayLength() > 0
                && actualizado.GetProperty("tablas").GetArrayLength() == completa.GetProperty("tablas").GetArrayLength(),
                "actualizar el documento principal perdió recursos o datos nativos.");
            string copiaEditada = Path.Combine(carpeta, "editada.sqlite");
            PaqueteNube.Descargar(actualizado, copiaEditada);
            Exige(MYGBaseDatos.LeerProyecto(copiaEditada, obraA.Id).Nombre == "Obra A editada"
                && MYGBaseDatos.ListarProyectos(copiaEditada).Count == 2,
                "el documento actualizado no se aplicó sobre la base conservada.");

            string zip = Path.Combine(carpeta, "exportacion.zip");
            PaqueteNube.ExportarZip(paquete, zip);
            using (var archivo = ZipFile.OpenRead(zip))
                Exige(archivo.Entries.Any(e => e.Name == "contenido.json") && archivo.Entries.Any(e => e.Name == "proyecto.sqlite")
                    && archivo.Entries.Any(e => e.FullName.StartsWith("proyecto.recursos/", StringComparison.Ordinal)),
                    "el ZIP no contiene SQLite, manifiesto y adjuntos.");
            var alterado = JsonNode.Parse(paquete.GetRawText())!;
            alterado["recursos"]![0]!["Sha256"] = "00";
            string destinoAlterado = Path.Combine(carpeta, "alterada.sqlite");
            bool rechazado = false;
            try { PaqueteNube.Descargar(JsonSerializer.SerializeToElement(alterado), destinoAlterado); }
            catch (InvalidDataException) { rechazado = true; }
            Exige(rechazado && !File.Exists(destinoAlterado), "un adjunto alterado produjo una descarga aparentemente correcta.");
            Exige(SHA256.HashData(File.ReadAllBytes(origen)).SequenceEqual(hashOrigen), "la publicación o descarga modificó el origen.");

            var propietario = MYGCatalogosProyecto.Guardar(descarga, MYGCatalogoProyecto.Propietarios, "Propietario sintético compartido");
            documento.Datos = MYGDatosProyecto.Crear();
            documento.Datos.PropietarioId = propietario.Id;
            documento.Datos.Propietario = propietario.Nombre;
            MYGProyectoStorage.Guardar(descarga, documento);
            JsonElement catalogos = PaqueteNube.CrearContenido(documento, descarga);
            string dependencias = Path.Combine(carpeta, "dependencias.sqlite");
            MYGProyectoStorage.Guardar(dependencias, obraA);
            using (var conexion = Abrir(dependencias))
            using (var transaccion = conexion.BeginTransaction())
            {
                PaqueteNube.AplicarDependencias(catalogos, conexion, transaccion);
                transaccion.Rollback();
            }
            Exige((long?)Consultar(dependencias, "SELECT COUNT(*) FROM propietario WHERE id_propietario=$id", propietario.Id) == 0,
                "una importación de catálogos escapó del rollback de la transacción llamadora.");
            using (var conexion = Abrir(dependencias))
            using (var transaccion = conexion.BeginTransaction())
            {
                PaqueteNube.AplicarDependencias(catalogos, conexion, transaccion);
                transaccion.Commit();
            }
            Exige((long?)Consultar(dependencias, "SELECT COUNT(*) FROM propietario WHERE id_propietario=$id", propietario.Id) == 1,
                "el catálogo recibido no quedó disponible para guardar su documento.");
            string firma = PaqueteNube.FirmaDatosCompartidos(catalogos);
            Ejecutar(descarga, "UPDATE propietario SET nombre_propietario='Cambio solo catálogo' WHERE id_propietario=$id", propietario.Id);
            Exige(firma != PaqueteNube.FirmaDatosCompartidos(PaqueteNube.CrearContenido(documento, descarga)),
                "un cambio exclusivo de catálogo no alteró la firma compartida.");

            // Las rutas de otra computadora son datos sin autoridad sobre los archivos de este equipo.
            string privadoSintetico = Path.Combine(carpeta, "archivo-local-no-compartido.txt");
            File.WriteAllText(privadoSintetico, "MARCADOR_SINTETICO_LOCAL_NO_COMPARTIDO");
            var recibido = MYGProyectoStorage.Nuevo("Documento recibido");
            recibido.FuenteCatalogo = new MYGFuenteDelphin { Id = "fuente-remota", RutaSQLite = origen };
            recibido.Presupuestos[0].Conexion = new MYGConexionDelphin
            { FuenteId = "fuente-remota", ProyectoId = "ajeno", PresupuestoId = "ajeno", RutaSQLite = origen };
            recibido.Presupuestos[0].Costos.Insumos.Add(new MYGInsumo
            {
                Descripcion = "Recurso recibido", ImagenRuta = privadoSintetico, FichaTecnicaRuta = privadoSintetico,
                CatalogoMYGId = "no-incluido", CatalogoMYGRuta = origen
            });
            JsonElement sinAdjunto = JsonSerializer.SerializeToElement(new
            {
                formato = "MYG_COLABORACION", version = 1, alcance = "obra", documento = recibido,
                recursos = Array.Empty<PaqueteNube.Recurso>()
            });
            string copiaRecibida = Path.Combine(carpeta, "recibida.sqlite");
            var seguro = PaqueteNube.MaterializarDocumento(sinAdjunto, copiaRecibida);
            var insumoSeguro = seguro.Presupuestos[0].Costos.Insumos[0];
            Exige(string.IsNullOrEmpty(insumoSeguro.ImagenRuta) && string.IsNullOrEmpty(insumoSeguro.FichaTecnicaRuta),
                "se conservó una ruta remota de adjunto sin bytes verificados.");
            Exige(insumoSeguro.CatalogoMYGRuta == null && insumoSeguro.CatalogoMYGId == null
                && seguro.FuenteCatalogo == null && seguro.Presupuestos[0].Conexion == null,
                "se conservó una ruta SQLite remota sin dependencias recibidas.");
            MYGProyectoStorage.Guardar(copiaRecibida, seguro);
            JsonElement reenvio = PaqueteNube.CrearContenido(seguro, copiaRecibida);
            Exige(reenvio.GetProperty("recursos").GetArrayLength() == 0,
                "volver a compartir un documento recibido incorporó archivos locales no seleccionados.");
            string recibidaDescargada = Path.Combine(carpeta, "recibida-descargada.sqlite");
            PaqueteNube.Descargar(sinAdjunto, recibidaDescargada);
            var seguraDescargada = MYGBaseDatos.LeerProyecto(recibidaDescargada, recibido.Id).Presupuestos[0].Costos.Insumos[0];
            Exige(string.IsNullOrEmpty(seguraDescargada.ImagenRuta) && string.IsNullOrEmpty(seguraDescargada.FichaTecnicaRuta)
                && seguraDescargada.CatalogoMYGRuta == null,
                "la descarga SQLite conservó una ruta remota no materializada.");

            Console.WriteLine($"OK Paquetes de nube: {comprobaciones} comprobaciones de aislamiento, adjuntos, catálogos y portabilidad; SQLite real.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(carpeta, true); }
    }

    private static ItemPresupuestoDelphin Partida(string id, string descripcion) => new()
    {
        Id = id, IdLocalMYG = id, Descripcion = descripcion, Unidad = "m", TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA"
    };

    private static SqliteConnection Abrir(string ruta)
    {
        var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        conexion.Open();
        return conexion;
    }

    private static object? Consultar(string ruta, string sql, string? id = null)
    {
        using var conexion = Abrir(ruta);
        using var comando = conexion.CreateCommand();
        comando.CommandText = sql;
        if (id != null) comando.Parameters.AddWithValue("$id", id);
        return comando.ExecuteScalar();
    }

    private static void Ejecutar(string ruta, string sql, string? id = null)
    {
        using var conexion = Abrir(ruta);
        using var comando = conexion.CreateCommand();
        comando.CommandText = sql;
        if (id != null) comando.Parameters.AddWithValue("$id", id);
        comando.ExecuteNonQuery();
    }
}
