using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class SincronizacionCheck
{
    private const string Servidor = "https://sincronizacion.supabase.co";
    private static readonly Guid ProyectoId = Guid.Parse("55555555-5555-4555-8555-555555555555");
    private static readonly Guid UsuarioId = Guid.Parse("66666666-6666-4666-8666-666666666666");
    private static int _comprobaciones;

    internal static async Task RunAsync()
    {
        await DosRevisiones();
        await AckPerdido();
        await PullConPendiente();
        await Lector();
        await Revocado();
        await CatalogoAtomico();
        await CatalogoLocalSinCambioDocumento();
        await BaseCompletaDosObras();
        await IdentidadIncorrecta();
        Console.WriteLine($"OK Sincronización: 9 casos y {_comprobaciones} comprobaciones SQLite + HTTP simulado.");
    }

    private static void Exigir(bool condicion, string mensaje)
    {
        _comprobaciones++;
        if (!condicion) throw new InvalidOperationException(mensaje);
    }

    private static async Task DosRevisiones()
    {
        using var prueba = await Escenario.Crear();
        var remoto = MYGProyectoStorage.Copia(prueba.Documento);
        remoto.Nombre = "Revisión remota 2";
        prueba.Http.Avanzar(remoto);
        var resultado = await prueba.Sincronizar();
        Exigir(resultado.Documento.Nombre == remoto.Nombre && resultado.Vinculo.Revision == 2, "No se recibió la segunda revisión.");
        Exigir(prueba.LeerDocumento().Nombre == remoto.Nombre && prueba.LeerVinculo().Revision == 2, "La segunda revisión no quedó durable.");
        remoto.Nombre = "Revisión remota 3";
        prueba.Http.Avanzar(remoto);
        resultado = await prueba.Sincronizar();
        Exigir(resultado.Documento.Nombre == remoto.Nombre && resultado.Vinculo.Revision == 3, "No se recibió la tercera revisión.");
        Exigir(prueba.LeerDocumento().Nombre == remoto.Nombre && prueba.Http.Escrituras.Count == 0, "Una descarga provocó una escritura remota.");
    }

    private static async Task AckPerdido()
    {
        using var prueba = await Escenario.Crear();
        prueba.Editar("Cambio pendiente A");
        Guid operacion = prueba.LeerVinculo().Pendiente.Id;
        prueba.Http.PerderSiguienteAck = true;
        try { await prueba.Sincronizar(); throw new InvalidOperationException("Debía perderse el ACK."); }
        catch (NubeException ex) { Exigir(ex.EsErrorDeConexion, "El ACK perdido no se comunicó como desconexión."); }
        var durable = prueba.LeerVinculo();
        Exigir(durable.Pendiente.Id == operacion && durable.Pendiente.Enviada && durable.Revision == 1, "La pérdida del ACK eliminó o cambió la operación durable.");
        Exigir(prueba.Http.Revision == 2, "El servidor simulado no aplicó la operación antes de perder el ACK.");
        byte[] primerEnvio = prueba.Http.Escrituras.Single();
        string cuerpoPersistido = durable.Pendiente.JsonContenido;

        // Abrir de nuevo la SQLite representa otra ejecución; el siguiente cambio
        // debe convivir con el cuerpo inmutable del envío todavía no confirmado.
        prueba.Documento = prueba.LeerDocumento();
        prueba.Editar("Cambio posterior B");
        durable = prueba.LeerVinculo();
        Exigir(durable.Pendiente.Id == operacion && durable.Pendiente.JsonContenido == cuerpoPersistido, "El borrador posterior alteró la operación en vuelo.");
        var resultado = await prueba.Sincronizar();
        Exigir(prueba.Http.Escrituras.Count == 2 && primerEnvio.SequenceEqual(prueba.Http.Escrituras[1]), "Reabrir y reintentar cambió los bytes o el UUID del envío.");
        Exigir(resultado.Documento.Nombre == "Cambio posterior B" && resultado.Vinculo.Revision == 2, "El ACK antiguo reemplazó el borrador más reciente.");
        Exigir(resultado.Vinculo.Pendiente != null && resultado.Vinculo.Pendiente.Id != operacion && resultado.Vinculo.Pendiente.RevisionBase == 2, "El borrador posterior no generó una nueva operación contra la revisión confirmada.");
        resultado = await prueba.Sincronizar();
        Exigir(resultado.Vinculo.Revision == 3 && resultado.Vinculo.Pendiente == null, "La siguiente operación no quedó confirmada.");
        Exigir(PaqueteNube.LeerDocumento(prueba.Http.Paquete).Nombre == "Cambio posterior B", "El servidor perdió el segundo cambio.");
    }

    private static async Task PullConPendiente()
    {
        using var prueba = await Escenario.Crear();
        prueba.Editar("Trabajo local sin enviar");
        var antes = prueba.LeerVinculo().Pendiente;
        var remoto = MYGProyectoStorage.Copia(prueba.Documento);
        remoto.Nombre = "Otro usuario cambió el proyecto";
        prueba.Http.Avanzar(remoto);
        var resultado = await prueba.Sincronizar(soloLeer: true);
        var despues = prueba.LeerVinculo();
        Exigir(resultado.Documento.Nombre == "Trabajo local sin enviar" && prueba.LeerDocumento().Nombre == resultado.Documento.Nombre, "Pull reemplazó trabajo pendiente sin resolución explícita.");
        Exigir(despues.Pendiente.Id == antes.Id && despues.Pendiente.JsonContenido == antes.JsonContenido, "Pull borró o cambió la operación pendiente.");
        Exigir(despues.Revision == 1 && despues.RevisionRemotaConflicto == 2 && !string.IsNullOrWhiteSpace(despues.JsonRemotoConflicto), "No se registró el conflicto durable de la descarga.");
        Exigir(prueba.Http.Escrituras.Count == 0, "Pull envió una escritura remota.");
    }

    private static async Task Lector()
    {
        using var prueba = await Escenario.Crear();
        prueba.Editar("Pendiente anterior al cambio de rol");
        var pendiente = prueba.LeerVinculo().Pendiente;
        prueba.Http.Rol = "lector";
        var resultado = await prueba.Sincronizar();
        Exigir(resultado.Vinculo.Rol == "lector" && prueba.LeerVinculo().Rol == "lector", "No se persistió el rol efectivo del servidor.");
        Exigir(prueba.Http.Escrituras.Count == 0 && resultado.Vinculo.Pendiente.Id == pendiente.Id, "El lector envió o eliminó una operación previa.");
        var copia = MYGProyectoStorage.Copia(resultado.Documento);
        copia.Nombre = "Edición nueva no autorizada";
        bool rechazo = false;
        try { MYGColaboracionLocal.Guardar(prueba.Ruta, copia, resultado.Vinculo); }
        catch (InvalidOperationException) { rechazo = true; }
        Exigir(rechazo && prueba.LeerDocumento().Nombre == "Pendiente anterior al cambio de rol", "Se permitió una nueva edición local como lector.");
    }

    private static async Task Revocado()
    {
        using var prueba = await Escenario.Crear();
        prueba.Editar("Pendiente conservado al revocar");
        var pendiente = prueba.LeerVinculo().Pendiente;
        prueba.Http.Revocado = true;
        try { await prueba.Sincronizar(); throw new InvalidOperationException("Se esperaba denegación de acceso."); }
        catch (NubeException ex) { Exigir(ex.AccesoDenegado && ex.Codigo == "42501", "No se comunicó la revocación real del servidor."); }
        var vinculo = prueba.LeerVinculo();
        Exigir(vinculo.EstadoConexion == "acceso retirado", "La revocación no quedó registrada en EstadoConexion.");
        Exigir(vinculo.Pendiente.Id == pendiente.Id && vinculo.Pendiente.JsonContenido == pendiente.JsonContenido, "Revocar permisos eliminó el trabajo pendiente.");
        Exigir(prueba.Http.Escrituras.Count == 0 && prueba.Cliente.SesionIniciada, "Revocar el proyecto escribió datos o cerró la identidad global.");
        var copia = MYGProyectoStorage.Copia(prueba.Documento);
        copia.Nombre = "Cambio posterior a revocación";
        bool rechazo = false;
        try { MYGColaboracionLocal.Guardar(prueba.Ruta, copia, vinculo); }
        catch (InvalidOperationException) { rechazo = true; }
        Exigir(rechazo, "Se permitió editar una copia con acceso retirado.");
    }

    private static async Task CatalogoAtomico()
    {
        using var prueba = await Escenario.Crear();
        var remoto = MYGProyectoStorage.Copia(prueba.Documento);
        remoto.Nombre = "Proyecto con nueva unidad remota";
        prueba.Http.Avanzar(remoto);
        string unidad = "unidad-remota-" + Guid.NewGuid().ToString("N");
        var nodo = JsonNode.Parse(prueba.Http.Paquete.GetRawText())!.AsObject();
        nodo["tablas"] = JsonSerializer.SerializeToNode(new[]
        {
            new PaqueteNube.Tabla
            {
                Nombre = "catalogo_unidad", Columnas = new() { "id", "simbolo", "descripcion" },
                Filas = new() { new() { new() { Tipo = "texto", Valor = unidad }, new() { Tipo = "texto", Valor = "rem" }, new() { Tipo = "texto", Valor = "Unidad nueva en la nube" } } }
            }
        });
        prueba.Http.Paquete = JsonSerializer.SerializeToElement(nodo);
        prueba.Sql("CREATE TRIGGER prueba_abortar_vinculo BEFORE UPDATE ON myg_colaboracion_local BEGIN SELECT RAISE(ABORT,'fallo inyectado después de las dependencias'); END");
        bool rechazo = false;
        try { await prueba.Sincronizar(); }
        catch (SqliteException) { rechazo = true; }
        Exigir(rechazo, "La prueba no provocó el fallo transaccional esperado.");
        Exigir(prueba.LeerVinculo().Revision == 1 && prueba.LeerDocumento().Nombre == "Proyecto inicial", "Un fallo en metadatos confirmó parcialmente el documento.");
        Exigir(prueba.ContarUnidad(unidad) == 0, "El catálogo se escribió fuera de la transacción del documento y vínculo.");
        prueba.Sql("DROP TRIGGER prueba_abortar_vinculo");
        prueba.Documento = prueba.LeerDocumento();
        var resultado = await prueba.Sincronizar();
        Exigir(resultado.Vinculo.Revision == 2 && prueba.LeerDocumento().Nombre == remoto.Nombre, "No se recuperó la sincronización después del rollback.");
        Exigir(prueba.ContarUnidad(unidad) == 1, "La descarga no importó el catálogo nuevo en la misma transacción.");
    }

    private static async Task IdentidadIncorrecta()
    {
        using var prueba = await Escenario.Crear();
        using var otraCuenta = new ClienteSupabase(Servidor, "sb_publishable_pruebas_sync", new ServidorSimulado(prueba.Http.Paquete) { Usuario = Guid.NewGuid() });
        await otraCuenta.IniciarSesionAsync("otra@myg.example", "contraseña_prueba");
        int lecturas = prueba.Http.Lecturas;
        try { await SincronizadorProyectoNube.EjecutarAsync(otraCuenta, prueba.Ruta, prueba.Documento); throw new InvalidOperationException("Se aceptó otra identidad."); }
        catch (NubeException ex) { Exigir(ex.NecesitaIniciarSesion, "La copia no exigió su identidad original."); }
        Exigir(prueba.Http.Lecturas == lecturas && prueba.LeerVinculo().Revision == 1, "Una identidad incorrecta modificó la copia vinculada.");
    }

    private static async Task CatalogoLocalSinCambioDocumento()
    {
        using var prueba = await Escenario.Crear();
        var propietario = MYGCatalogosProyecto.Guardar(prueba.Ruta, MYGCatalogoProyecto.Propietarios, "Propietario inicial compartido");
        prueba.Documento.Datos = MYGDatosProyecto.Crear();
        prueba.Documento.Datos.PropietarioId = propietario.Id;
        prueba.Documento.Datos.Propietario = propietario.Nombre;
        MYGColaboracionLocal.Guardar(prueba.Ruta, prueba.Documento, prueba.LeerVinculo());
        await prueba.Sincronizar();
        Exigir(prueba.LeerVinculo().Pendiente is null && prueba.Http.Revision == 2, "No se confirmó el catálogo inicial.");
        string firmaDocumento = MYGProyectoStorage.Firma(prueba.Documento);
        prueba.Sql("UPDATE propietario SET nombre_propietario='Cambio exclusivo del catálogo' WHERE id_propietario='" + propietario.Id + "'");
        Exigir(MYGProyectoStorage.Firma(prueba.LeerDocumento()) == firmaDocumento && prueba.LeerVinculo().Pendiente is null,
            "La preparación de la prueba cambió el documento o creó una operación artificial.");
        var resultado = await prueba.Sincronizar();
        Exigir(resultado.Vinculo.Revision == 3 && resultado.Vinculo.Pendiente is null && prueba.Http.Escrituras.Count == 2,
            "Sincronizar no detectó y confirmó el cambio exclusivo del catálogo.");
        var tablas = prueba.Http.Paquete.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>()!;
        var tabla = tablas.Single(t => t.Nombre == "propietario");
        int columna = tabla.Columnas.IndexOf("nombre_propietario");
        Exigir(tabla.Filas.Any(fila => fila[columna].Valor == "Cambio exclusivo del catálogo"),
            "La operación confirmada perdió el dato nativo del catálogo.");
        await prueba.Sincronizar();
        Exigir(prueba.Http.Revision == 3 && prueba.Http.Escrituras.Count == 2,
            "Repetir una sincronización sin cambios generó una operación fantasma.");
    }

    private static async Task BaseCompletaDosObras()
    {
        using var prueba = await Escenario.Crear("base");
        var secundaria = MYGBaseDatos.ListarProyectos(prueba.Ruta).Single(p => p.Id != prueba.Documento.Id);
        var cambio = MYGBaseDatos.LeerProyecto(prueba.Ruta, secundaria.Id);
        cambio.Nombre = "Segunda obra modificada por otro equipo";
        prueba.Http.Avanzar(cambio);
        var resultado = await prueba.Sincronizar(soloLeer: true);
        Exigir(resultado.Vinculo.Revision == 2 && MYGBaseDatos.ListarProyectos(prueba.Ruta).Count == 2,
            "Pull de base no confirmó la revisión completa conservando las dos obras.");
        Exigir(MYGBaseDatos.LeerProyecto(prueba.Ruta, secundaria.Id).Nombre == cambio.Nombre,
            "Pull adoptó la revisión de base sin recuperar los cambios de la otra obra.");
        Exigir(prueba.Http.Escrituras.Count == 0 && MYGBaseDatos.LeerProyecto(prueba.Ruta, prueba.Documento.Id).Nombre == "Proyecto inicial",
            "Pull de base escribió en el servidor o cambió la obra principal.");
        resultado = await prueba.Sincronizar();
        Exigir(resultado.Vinculo.Revision == 2 && prueba.Http.Escrituras.Count == 0,
            "Sincronizar después del pull de base intentó reenviar una obra secundaria antigua.");
        cambio.Nombre = "Revisión siguiente que no debe guardarse parcialmente";
        prueba.Http.Avanzar(cambio);
        JsonElement valido = prueba.Http.Paquete.Clone();
        var invalido = JsonNode.Parse(valido.GetRawText())!.AsObject();
        var tabla = invalido["tablas"]!.AsArray().Single(t => t!["Nombre"]!.GetValue<string>() == "proyecto")!;
        tabla["Filas"]![0]![0]!["Tipo"] = "tipo_sqlite_no_admitido";
        prueba.Http.Paquete = JsonSerializer.SerializeToElement(invalido);
        bool rechazo = false;
        try { await prueba.Sincronizar(soloLeer: true); }
        catch (InvalidDataException) { rechazo = true; }
        Exigir(rechazo && prueba.LeerVinculo().Revision == 2
            && MYGBaseDatos.LeerProyecto(prueba.Ruta, secundaria.Id).Nombre == "Segunda obra modificada por otro equipo",
            "Un fallo al reconstruir el snapshot de base reemplazó datos o adoptó la revisión remota.");
        prueba.Http.Paquete = valido;
        resultado = await prueba.Sincronizar(soloLeer: true);
        Exigir(resultado.Vinculo.Revision == 3 && MYGBaseDatos.LeerProyecto(prueba.Ruta, secundaria.Id).Nombre == cambio.Nombre,
            "No se pudo recuperar el pull de base después de un snapshot rechazado.");
    }

    private sealed class Escenario : IDisposable
    {
        private readonly string _directorio;
        public string Ruta { get; }
        public MYGProyectoDocumento Documento { get; set; }
        public ClienteSupabase Cliente { get; }
        public ServidorSimulado Http { get; }

        private Escenario(string alcance)
        {
            _directorio = Path.Combine(Path.GetTempPath(), "myg_sync_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_directorio);
            Ruta = Path.Combine(_directorio, "copia.sqlite");
            Documento = MYGProyectoStorage.Nuevo("Proyecto inicial", "Estructuras");
            MYGProyectoStorage.Guardar(Ruta, Documento);
            if (alcance == "base") MYGProyectoStorage.Guardar(Ruta, MYGProyectoStorage.Nuevo("Segunda obra inicial", "Arquitectura"));
            JsonElement paquete = PaqueteNube.CrearContenido(Documento, Ruta, alcance);
            string remoto = Path.Combine(_directorio, "servidor.sqlite");
            PaqueteNube.Descargar(paquete, remoto);
            Http = new ServidorSimulado(paquete) { RutaFuente = remoto, Alcance = alcance };
            Cliente = new ClienteSupabase(Servidor, "sb_publishable_pruebas_sync", Http);
            MYGColaboracionLocal.Vincular(Ruta, Documento, new MYGVinculoNube
            {
                ProyectoId = ProyectoId, Servidor = Servidor, UsuarioId = UsuarioId.ToString("D"), Rol = "editor", Revision = 1,
                JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(Documento), JsonPaqueteConfirmado = paquete.GetRawText()
            });
        }

        public static async Task<Escenario> Crear(string alcance = "obra")
        {
            var escenario = new Escenario(alcance);
            try { await escenario.Cliente.IniciarSesionAsync("prueba@myg.example", "contraseña_prueba"); return escenario; }
            catch { escenario.Dispose(); throw; }
        }

        public void Editar(string nombre)
        {
            Documento.Nombre = nombre;
            MYGColaboracionLocal.Guardar(Ruta, Documento, LeerVinculo());
        }

        public async Task<ResultadoSincronizacion> Sincronizar(bool soloLeer = false)
        {
            var resultado = await SincronizadorProyectoNube.EjecutarAsync(Cliente, Ruta, Documento, soloLeer);
            Documento = resultado.Documento;
            return resultado;
        }

        public MYGVinculoNube LeerVinculo() => MYGColaboracionLocal.Leer(Ruta, Documento.Id);
        public MYGProyectoDocumento LeerDocumento() => MYGBaseDatos.LeerProyecto(Ruta, Documento.Id);
        public void Sql(string sql)
        {
            using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = Ruta, Pooling = false }.ToString());
            conexion.Open(); using var comando = conexion.CreateCommand(); comando.CommandText = sql; comando.ExecuteNonQuery();
        }

        public long ContarUnidad(string unidad)
        {
            using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = Ruta, Pooling = false }.ToString());
            conexion.Open(); using var comando = conexion.CreateCommand(); comando.CommandText = "SELECT COUNT(*) FROM catalogo_unidad WHERE id=$id"; comando.Parameters.AddWithValue("$id", unidad);
            return (long)comando.ExecuteScalar()!;
        }

        public void Dispose()
        {
            Cliente.Dispose();
            SqliteConnection.ClearAllPools();
            Directory.Delete(_directorio, true);
        }
    }

    private sealed class ServidorSimulado(JsonElement paquete) : HttpMessageHandler
    {
        public JsonElement Paquete { get; set; } = paquete.Clone();
        public long Revision { get; private set; } = 1;
        public string Rol { get; set; } = "editor";
        public Guid Usuario { get; set; } = UsuarioId;
        public bool PerderSiguienteAck { get; set; }
        public bool Revocado { get; set; }
        public string? RutaFuente { get; init; }
        public string Alcance { get; init; } = "obra";
        public int Lecturas { get; private set; }
        public List<byte[]> Escrituras { get; } = new();
        private readonly Dictionary<Guid, (long Revision, JsonElement Contenido)> _acks = new();

        public void Avanzar(MYGProyectoDocumento documento)
        {
            // Una revisión real contiene el documento y su representación
            // nativa SQLite coherentes, igual que al exportar desde otro equipo.
            string principalId = PaqueteNube.LeerDocumento(Paquete).Id;
            MYGProyectoStorage.Guardar(RutaFuente!, documento);
            var principal = MYGBaseDatos.LeerProyecto(RutaFuente!, principalId);
            Paquete = PaqueteNube.CrearContenido(principal, RutaFuente!, Alcance);
            Revision++;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Exigir(request.Headers.TryGetValues("apikey", out var claves) && claves.Single() == "sb_publishable_pruebas_sync", "Falta la clave publicable en la sincronización.");
            string ruta = request.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Respuesta(new { access_token = "token_sync", refresh_token = "refresh_sync", expires_in = 3600, user = new { id = Usuario } });
            Exigir(request.Headers.Authorization?.Scheme == "Bearer" && request.Headers.Authorization.Parameter == "token_sync", "La sincronización no usa la identidad autenticada.");
            if (Revocado) return Respuesta(new { code = "42501", message = "Acceso revocado" }, HttpStatusCode.Forbidden);
            if (ruta == "/rest/v1/rpc/myg_nube_abrir")
            {
                Lecturas++;
                return Respuesta(new { id = ProyectoId, codigo = "MYG-SYNC-001", nombre = "Proyecto sincronizado", rol = Rol, revision = Revision, alcance = Alcance, contenido = Paquete });
            }
            Exigir(ruta == "/rest/v1/rpc/myg_nube_guardar", "Endpoint inesperado de sincronización: " + ruta);
            byte[] cuerpo = await request.Content!.ReadAsByteArrayAsync(cancellationToken);
            Escrituras.Add(cuerpo);
            using var json = JsonDocument.Parse(cuerpo);
            Guid operacion = json.RootElement.GetProperty("p_operacion").GetGuid();
            long revision = json.RootElement.GetProperty("p_revision").GetInt64();
            if (_acks.TryGetValue(operacion, out var ack))
                return Respuesta(new { estado = "aplicada", revision = ack.Revision, contenido = ack.Contenido, operacion_id = operacion });
            if (revision != Revision)
                return Respuesta(new { estado = "conflicto", revision = Revision, contenido = Paquete, operacion_id = operacion });
            Paquete = json.RootElement.GetProperty("p_contenido").Clone();
            Revision++;
            _acks.Add(operacion, (Revision, Paquete));
            if (PerderSiguienteAck) { PerderSiguienteAck = false; throw new HttpRequestException("ACK perdido simulado después del commit remoto."); }
            return Respuesta(new { estado = "aplicada", revision = Revision, contenido = Paquete, operacion_id = operacion });
        }

        private static HttpResponseMessage Respuesta(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        {
            Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json")
        };
    }
}
