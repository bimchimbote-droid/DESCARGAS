using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Data.Sqlite;

namespace MYG_2027;

public sealed class MYGOperacionNube
{
    public Guid Id { get; set; }
    public long RevisionBase { get; set; }
    public string JsonContenido { get; set; }
    public bool Enviada { get; set; }
}

public sealed class MYGVinculoNube
{
    public Guid ProyectoId { get; set; }
    public string Servidor { get; set; }
    public string UsuarioId { get; set; }
    public string Rol { get; set; }
    public long Revision { get; set; }
    public string JsonConfirmado { get; set; }
    public string JsonPaqueteConfirmado { get; set; }
    public string JsonRemotoConflicto { get; set; }
    public string JsonPaqueteConflicto { get; set; }
    public long RevisionRemotaConflicto { get; set; }
    public MYGOperacionNube Pendiente { get; set; }
    // El borrador más reciente es distinto del cuerpo inmutable que puede estar
    // viajando por la red. Se convierte en la siguiente operación después del ACK.
    public string JsonBorrador { get; set; }
    public string Estado { get; set; }
    public string EstadoConexion { get; set; }
    [JsonIgnore] internal string FirmaLectura { get; set; }
}

/// <summary>Vínculo y cola duraderos dentro de la propia hoja SQLite, sin credenciales.</summary>
public static class MYGColaboracionLocal
{
    private const string Tabla = "myg_colaboracion_local";
    private const string Esquema = """
        CREATE TABLE IF NOT EXISTS myg_colaboracion_local(
            proyecto_local_id TEXT PRIMARY KEY COLLATE NOCASE REFERENCES myg_proyecto(id) ON DELETE CASCADE,
            servidor TEXT NOT NULL,proyecto_remoto_id TEXT NOT NULL,usuario_id TEXT NOT NULL,json_vinculo TEXT NOT NULL,
            UNIQUE(servidor,proyecto_remoto_id,usuario_id));
        """;

    public static string ExportarDocumento(MYGProyectoDocumento documento)
    {
        var copia = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(copia);
        return JsonSerializer.Serialize(copia, MYGProyectoStorage.Opciones);
    }

    public static MYGProyectoDocumento ImportarDocumento(string json)
    {
        if (string.IsNullOrWhiteSpace(json)) throw new InvalidDataException("El documento de nube está vacío.");
        try
        {
            using var estructura = JsonDocument.Parse(json, new JsonDocumentOptions { MaxDepth = 128 });
            var raiz = estructura.RootElement;
            if (raiz.ValueKind != JsonValueKind.Object ||
                !raiz.TryGetProperty("Formato", out var formato) || formato.ValueKind != JsonValueKind.String ||
                formato.GetString() != "MYG_BIM_PROYECTO" ||
                !raiz.TryGetProperty("Version", out var version) || version.ValueKind != JsonValueKind.Number ||
                !version.TryGetInt32(out int numeroVersion) || (numeroVersion != 2 && numeroVersion != 3) ||
                !raiz.TryGetProperty("Id", out var id) || id.ValueKind != JsonValueKind.String ||
                string.IsNullOrWhiteSpace(id.GetString()) ||
                !raiz.TryGetProperty("Presupuestos", out var presupuestos) || presupuestos.ValueKind != JsonValueKind.Array)
                throw new InvalidDataException("La nube debe contener un documento MYG completo con formato, identidad y presupuestos.");
            var documento = JsonSerializer.Deserialize<MYGProyectoDocumento>(json, MYGProyectoStorage.Opciones);
            MYGProyectoStorage.Validar(documento);
            return documento;
        }
        catch (JsonException ex) { throw new InvalidDataException("El documento de nube no es JSON válido.", ex); }
    }

    public static MYGVinculoNube Leer(string ruta, string proyectoLocalId)
    {
        ExigirIdLocal(proyectoLocalId);
        using var c = MYGBaseDatos.Abrir(ruta, false);
        return Leer(c, null, proyectoLocalId);
    }

    public static string BuscarProyectoLocal(string ruta, string servidor, Guid proyectoRemotoId, string usuarioId)
    {
        var identidad = new MYGVinculoNube { Servidor = servidor, ProyectoId = proyectoRemotoId, UsuarioId = usuarioId };
        Validar(identidad);
        using var c = MYGBaseDatos.Abrir(ruta, false);
        if (!MYGBaseDatos.TieneTabla(c, null, Tabla)) return null;
        using var cmd = MYGBaseDatos.Comando(c, null, """
            SELECT proyecto_local_id FROM myg_colaboracion_local
            WHERE servidor=$p0 AND proyecto_remoto_id=$p1 AND usuario_id=$p2
            """, identidad.Servidor, proyectoRemotoId.ToString("D"), usuarioId);
        return cmd.ExecuteScalar() as string;
    }

    public static void Vincular(string ruta, MYGProyectoDocumento documento, MYGVinculoNube vinculo,
        Action<SqliteConnection, SqliteTransaction> prepararDependencias = null)
        => Guardar(ruta, documento, vinculo, prepararDependencias);

    public static void Guardar(string ruta, MYGProyectoDocumento documento, MYGVinculoNube vinculo,
        Action<SqliteConnection, SqliteTransaction> prepararDependencias = null)
    {
        if (vinculo == null) throw new ArgumentNullException(nameof(vinculo));
        var copia = Copiar(vinculo);
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura, prepararDependencias: prepararDependencias);
        Aplicar(copia, vinculo);
    }

    // Devuelve siempre el mismo UUID y cuerpo mientras no llegue el ACK. Los
    // cambios siguientes quedan en JsonBorrador y en el documento local normal.
    public static MYGOperacionNube PrepararPendiente(MYGProyectoDocumento documento, MYGVinculoNube vinculo)
    {
        Validar(vinculo);
        string borrador = ExportarDocumento(documento);
        if (SoloLectura(vinculo) &&
            !MismoContenido(borrador, vinculo.JsonBorrador) && !MismoContenido(borrador, vinculo.JsonConfirmado))
            throw new InvalidOperationException("Esta cuenta tiene acceso de solo lectura. Se conservan los cambios pendientes anteriores.");
        vinculo.JsonBorrador = borrador;
        if (vinculo.Pendiente == null && !SoloLectura(vinculo) &&
            !MismoContenido(vinculo.JsonBorrador, vinculo.JsonConfirmado) &&
            string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto))
            vinculo.Pendiente = CrearOperacion(vinculo.Revision, vinculo.JsonBorrador);
        ActualizarEstado(vinculo);
        return vinculo.Pendiente;
    }

    // Cambios de catálogos, adjuntos o tablas nativas pueden dejar intacto el
    // JSON del documento. El cliente compara el paquete y los encola aquí.
    public static MYGOperacionNube PrepararCambioContenido(string ruta, MYGProyectoDocumento documento,
        MYGVinculoNube vinculo, string jsonContenido)
    {
        var copia = Copiar(vinculo);
        Validar(copia);
        if (SoloLectura(copia)) throw new InvalidOperationException("Esta cuenta no puede publicar cambios de contenido.");
        if (!string.IsNullOrWhiteSpace(copia.JsonRemotoConflicto))
            throw new InvalidOperationException("Resuelva el conflicto antes de publicar cambios de contenido.");
        if (copia.Pendiente == null)
        {
            var operacion = new MYGOperacionNube
            { Id = Guid.NewGuid(), RevisionBase = copia.Revision, JsonContenido = jsonContenido };
            if (!MismoContenido(DocumentoDeOperacion(operacion), ExportarDocumento(documento)))
                throw new InvalidDataException("El paquete debe contener el documento actual de esta obra.");
            copia.Pendiente = operacion;
        }
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura);
        Aplicar(copia, vinculo);
        return vinculo.Pendiente;
    }

    // El paquete (base nativa y recursos) se añade una sola vez antes de hacer
    // la petición. Al reintentar se usa exactamente el cuerpo ya persistido.
    public static MYGOperacionNube PrepararEnvio(string ruta, MYGProyectoDocumento documento,
        MYGVinculoNube vinculo, string jsonContenido)
    {
        var copia = Copiar(vinculo);
        Validar(copia);
        if (copia.Pendiente == null) throw new InvalidOperationException("La obra no tiene una operación pendiente de enviar.");
        if (copia.Pendiente.Enviada && !string.Equals(copia.Pendiente.JsonContenido, jsonContenido, StringComparison.Ordinal))
            throw new InvalidOperationException("El reintento debe conservar exactamente el cuerpo de la operación enviada.");
        var enriquecida = new MYGOperacionNube
        {
            Id = copia.Pendiente.Id, RevisionBase = copia.Pendiente.RevisionBase,
            JsonContenido = jsonContenido, Enviada = true
        };
        if (!MismoContenido(DocumentoDeOperacion(copia.Pendiente), DocumentoDeOperacion(enriquecida)))
            throw new InvalidDataException("El paquete de envío debe contener el documento de la operación pendiente.");
        copia.Pendiente = enriquecida;
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura, prepararEnvio: true);
        Aplicar(copia, vinculo);
        return vinculo.Pendiente;
    }

    public static void Confirmar(string ruta, MYGProyectoDocumento documento, MYGVinculoNube vinculo,
        Guid operacionId, long revision, string jsonConfirmado = null,
        Action<SqliteConnection, SqliteTransaction> prepararDependencias = null)
    {
        var copia = Copiar(vinculo);
        Validar(copia);
        if (copia.Pendiente == null || copia.Pendiente.Id != operacionId)
            throw new InvalidOperationException("La confirmación no corresponde a la operación pendiente de esta obra.");
        if (revision <= copia.Pendiente.RevisionBase || revision < copia.Revision)
            throw new InvalidDataException("La revisión confirmada de nube no avanza la operación pendiente.");
        string confirmado = string.IsNullOrWhiteSpace(jsonConfirmado)
            ? DocumentoDeOperacion(copia.Pendiente) : ExportarDocumento(ImportarDocumento(jsonConfirmado));
        if (!MismoContenido(confirmado, DocumentoDeOperacion(copia.Pendiente)))
            throw new InvalidDataException("La confirmación no contiene el documento enviado por esta operación.");
        copia.Revision = revision;
        copia.JsonConfirmado = confirmado;
        copia.Pendiente = null;
        copia.JsonRemotoConflicto = null;
        copia.JsonPaqueteConflicto = null;
        copia.RevisionRemotaConflicto = 0;
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura, operacionId,
            prepararDependencias: prepararDependencias);
        Aplicar(copia, vinculo);
    }

    public static void RegistrarConflicto(string ruta, MYGProyectoDocumento documento, MYGVinculoNube vinculo,
        long revisionRemota, string jsonRemoto)
    {
        var copia = Copiar(vinculo);
        Validar(copia);
        if (revisionRemota < copia.Revision) throw new InvalidDataException("La revisión remota es anterior a la conocida.");
        copia.JsonRemotoConflicto = ExportarDocumento(ImportarDocumento(jsonRemoto));
        copia.RevisionRemotaConflicto = revisionRemota;
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura);
        Aplicar(copia, vinculo);
    }

    public static void ResolverConflictoMantenerLocal(string ruta, MYGProyectoDocumento documento, MYGVinculoNube vinculo)
    {
        var copia = Copiar(vinculo);
        ExigirConflicto(copia);
        if (!string.IsNullOrWhiteSpace(copia.JsonPaqueteConflicto))
        {
            using var paquete = JsonDocument.Parse(copia.JsonPaqueteConflicto, new JsonDocumentOptions { MaxDepth = 128 });
            if (paquete.RootElement.TryGetProperty("alcance", out var alcance) && alcance.GetString() == "base"
                && paquete.RootElement.TryGetProperty("documentos", out var documentos)
                && documentos.ValueKind == JsonValueKind.Array && documentos.GetArrayLength() > 1)
                throw new InvalidOperationException("La base contiene varias obras. Guarde una copia local antes de usar la base remota; mantener la base antigua podría reemplazar cambios de otras obras. La conciliación de ambas bases debe ser explícita.");
        }
        if (SoloLectura(copia))
            throw new InvalidOperationException("La cuenta debe recuperar permiso de edición antes de resolver el conflicto con cambios locales.");
        Guid? descartada = copia.Pendiente?.Id;
        AdoptarBaseRemota(copia);
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura, descartada, resolverConflicto: true);
        Aplicar(copia, vinculo);
    }

    public static MYGProyectoDocumento ResolverConflictoUsarRemoto(string ruta, MYGVinculoNube vinculo,
        Action<SqliteConnection, SqliteTransaction> prepararDependencias = null)
    {
        var copia = Copiar(vinculo);
        ExigirConflicto(copia);
        var documento = ImportarDocumento(copia.JsonRemotoConflicto);
        Guid? descartada = copia.Pendiente?.Id;
        AdoptarBaseRemota(copia);
        PrepararPendiente(documento, copia);
        GuardarAtomico(ruta, documento, copia, vinculo.FirmaLectura, descartada, resolverConflicto: true,
            prepararDependencias: prepararDependencias);
        Aplicar(copia, vinculo);
        return documento;
    }

    public static void Desvincular(string ruta, string proyectoLocalId)
    {
        ExigirIdLocal(proyectoLocalId);
        using var c = MYGBaseDatos.Abrir(ruta, true);
        using var t = c.BeginTransaction();
        if (MYGBaseDatos.TieneTabla(c, t, Tabla))
            MYGBaseDatos.Ejecutar(c, t, "DELETE FROM myg_colaboracion_local WHERE proyecto_local_id=$p0", proyectoLocalId);
        t.Commit();
    }

    internal static void GuardarDocumentoVinculado(SqliteConnection c, SqliteTransaction t, MYGProyectoDocumento documento)
    {
        var vinculo = Leer(c, t, documento.Id);
        if (vinculo == null) return;
        PrepararPendiente(documento, vinculo);
        Escribir(c, t, documento.Id, vinculo, vinculo.FirmaLectura);
    }

    private static void GuardarAtomico(string ruta, MYGProyectoDocumento documento, MYGVinculoNube vinculo,
        string firmaEsperada, Guid? operacionConfirmada = null, bool resolverConflicto = false, bool prepararEnvio = false,
        Action<SqliteConnection, SqliteTransaction> prepararDependencias = null)
    {
        MYGBaseDatos.GuardarProyectoConMetadatos(ruta, documento, (c, t) =>
            Escribir(c, t, documento.Id, vinculo, firmaEsperada, operacionConfirmada, resolverConflicto, prepararEnvio),
            prepararDependencias: prepararDependencias);
    }

    private static MYGVinculoNube Leer(SqliteConnection c, SqliteTransaction t, string proyectoLocalId)
    {
        if (!MYGBaseDatos.TieneTabla(c, t, Tabla)) return null;
        using var cmd = MYGBaseDatos.Comando(c, t,
            "SELECT servidor,proyecto_remoto_id,usuario_id,json_vinculo FROM myg_colaboracion_local WHERE proyecto_local_id=$p0", proyectoLocalId);
        using var lector = cmd.ExecuteReader();
        if (!lector.Read()) return null;
        string json = lector.GetString(3);
        MYGVinculoNube vinculo;
        try { vinculo = JsonSerializer.Deserialize<MYGVinculoNube>(json, MYGProyectoStorage.Opciones); }
        catch (JsonException ex) { throw new InvalidDataException("Los datos de colaboración de la obra están dañados.", ex); }
        Validar(vinculo);
        ExigirDocumentoLocal(vinculo, proyectoLocalId);
        if (!string.Equals(vinculo.Servidor, lector.GetString(0), StringComparison.Ordinal) ||
            !string.Equals(vinculo.ProyectoId.ToString("D"), lector.GetString(1), StringComparison.Ordinal) ||
            !string.Equals(vinculo.UsuarioId, lector.GetString(2), StringComparison.Ordinal))
            throw new InvalidDataException("La identidad del vínculo de nube no coincide con la obra guardada.");
        vinculo.FirmaLectura = json;
        return vinculo;
    }

    private static void Escribir(SqliteConnection c, SqliteTransaction t, string proyectoLocalId,
        MYGVinculoNube vinculo, string firmaEsperada, Guid? operacionConfirmada = null, bool resolverConflicto = false,
        bool prepararEnvio = false)
    {
        Validar(vinculo);
        ExigirDocumentoLocal(vinculo, proyectoLocalId);
        var anterior = Leer(c, t, proyectoLocalId);
        if (anterior != null)
        {
            if (anterior.ProyectoId != vinculo.ProyectoId || !string.Equals(anterior.Servidor, vinculo.Servidor, StringComparison.Ordinal) ||
                !string.Equals(anterior.UsuarioId, vinculo.UsuarioId, StringComparison.Ordinal))
                throw new InvalidOperationException("Esta obra ya está vinculada a otro servidor, proyecto o usuario. Desvincúlela primero.");
            if (firmaEsperada == null || !string.Equals(firmaEsperada, anterior.FirmaLectura, StringComparison.Ordinal))
                throw new InvalidOperationException("La colaboración de esta obra cambió en otra ventana. Vuelva a abrirla antes de guardar.");
            if (vinculo.Revision < anterior.Revision)
                throw new InvalidDataException("No se puede retroceder la revisión confirmada de esta obra.");
            if (anterior.Pendiente != null)
            {
                if (operacionConfirmada.HasValue)
                {
                    if (operacionConfirmada.Value != anterior.Pendiente.Id)
                        throw new InvalidOperationException("Cambió la operación pendiente antes de recibir la confirmación.");
                    if (!resolverConflicto && (vinculo.Revision <= anterior.Pendiente.RevisionBase ||
                        !MismoContenido(vinculo.JsonConfirmado, DocumentoDeOperacion(anterior.Pendiente))))
                        throw new InvalidDataException("La confirmación no corresponde al documento de la operación guardada.");
                }
                else if (prepararEnvio && !anterior.Pendiente.Enviada && vinculo.Pendiente != null &&
                    vinculo.Pendiente.Enviada && anterior.Pendiente.Id == vinculo.Pendiente.Id &&
                    anterior.Pendiente.RevisionBase == vinculo.Pendiente.RevisionBase &&
                    MismoContenido(DocumentoDeOperacion(anterior.Pendiente), DocumentoDeOperacion(vinculo.Pendiente))) { }
                else if (!MismaOperacion(anterior.Pendiente, vinculo.Pendiente))
                    throw new InvalidOperationException("Una operación pendiente conserva su UUID, revisión y cuerpo hasta recibir confirmación.");
            }
            if (resolverConflicto && string.IsNullOrWhiteSpace(anterior.JsonRemotoConflicto))
                throw new InvalidOperationException("El conflicto ya fue resuelto en otra ventana.");
            if (resolverConflicto && (vinculo.Revision != anterior.RevisionRemotaConflicto ||
                !MismoContenido(vinculo.JsonConfirmado, anterior.JsonRemotoConflicto)))
                throw new InvalidDataException("La resolución debe usar la revisión y la versión remota del conflicto guardado.");
        }
        else if (firmaEsperada != null || operacionConfirmada.HasValue || resolverConflicto)
            throw new InvalidOperationException("La obra ya no tiene el vínculo de nube que originó esta operación.");

        MYGBaseDatos.Ejecutar(c, t, Esquema);
        string json = JsonSerializer.Serialize(vinculo, MYGProyectoStorage.Opciones);
        MYGBaseDatos.Ejecutar(c, t, """
            INSERT INTO myg_colaboracion_local(proyecto_local_id,servidor,proyecto_remoto_id,usuario_id,json_vinculo)
            VALUES($p0,$p1,$p2,$p3,$p4)
            ON CONFLICT(proyecto_local_id) DO UPDATE SET json_vinculo=excluded.json_vinculo
            """, proyectoLocalId, vinculo.Servidor, vinculo.ProyectoId.ToString("D"), vinculo.UsuarioId, json);
        vinculo.FirmaLectura = json;
    }

    private static MYGOperacionNube CrearOperacion(long revision, string jsonDocumento) => new MYGOperacionNube
    {
        Id = Guid.NewGuid(), RevisionBase = revision,
        JsonContenido = JsonSerializer.Serialize(new { documento = ImportarDocumento(jsonDocumento) }, MYGProyectoStorage.Opciones)
    };

    private static string DocumentoDeOperacion(MYGOperacionNube operacion)
    {
        try
        {
            using var json = JsonDocument.Parse(operacion.JsonContenido, new JsonDocumentOptions { MaxDepth = 128 });
            if (json.RootElement.ValueKind != JsonValueKind.Object ||
                !json.RootElement.TryGetProperty("documento", out var documento))
                throw new InvalidDataException("La operación pendiente no contiene el documento completo.");
            return ExportarDocumento(ImportarDocumento(documento.GetRawText()));
        }
        catch (JsonException ex) { throw new InvalidDataException("El cuerpo de la operación pendiente está dañado.", ex); }
    }

    private static bool MismoContenido(string primero, string segundo) =>
        !string.IsNullOrWhiteSpace(primero) && !string.IsNullOrWhiteSpace(segundo) &&
        string.Equals(MYGProyectoStorage.Firma(ImportarDocumento(primero)),
            MYGProyectoStorage.Firma(ImportarDocumento(segundo)), StringComparison.Ordinal);

    private static bool MismaOperacion(MYGOperacionNube a, MYGOperacionNube b) =>
        a != null && b != null && a.Id == b.Id && a.RevisionBase == b.RevisionBase &&
        a.Enviada == b.Enviada &&
        string.Equals(a.JsonContenido, b.JsonContenido, StringComparison.Ordinal);

    private static void Validar(MYGVinculoNube vinculo)
    {
        if (vinculo == null) throw new ArgumentNullException(nameof(vinculo));
        if (vinculo.ProyectoId == Guid.Empty || string.IsNullOrWhiteSpace(vinculo.UsuarioId) || vinculo.Revision < 0)
            throw new InvalidDataException("El vínculo de nube necesita proyecto, usuario y revisión válidos.");
        if (!Uri.TryCreate(vinculo.Servidor, UriKind.Absolute, out var servidor) ||
            (servidor.Scheme != Uri.UriSchemeHttps && servidor.Scheme != Uri.UriSchemeHttp) ||
            !string.IsNullOrEmpty(servidor.UserInfo) || !string.IsNullOrEmpty(servidor.Query) || !string.IsNullOrEmpty(servidor.Fragment))
            throw new InvalidDataException("Indique una dirección HTTP o HTTPS de servidor sin credenciales.");
        vinculo.Servidor = servidor.AbsoluteUri.TrimEnd('/');
        if (vinculo.Pendiente != null)
        {
            if (vinculo.Pendiente.Id == Guid.Empty || vinculo.Pendiente.RevisionBase < 0 ||
                vinculo.Pendiente.RevisionBase != vinculo.Revision)
                throw new InvalidDataException("La operación pendiente no corresponde a la revisión base de esta obra.");
            DocumentoDeOperacion(vinculo.Pendiente);
        }
        if (!string.IsNullOrWhiteSpace(vinculo.JsonConfirmado)) ImportarDocumento(vinculo.JsonConfirmado);
        if (!string.IsNullOrWhiteSpace(vinculo.JsonBorrador)) ImportarDocumento(vinculo.JsonBorrador);
        if (!string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto))
        {
            ImportarDocumento(vinculo.JsonRemotoConflicto);
            if (vinculo.RevisionRemotaConflicto < vinculo.Revision)
                throw new InvalidDataException("La revisión del conflicto es anterior a la conocida.");
        }
    }

    private static void ActualizarEstado(MYGVinculoNube vinculo) => vinculo.Estado =
        !string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto) ? "Conflicto" :
        vinculo.Pendiente != null ? "Pendiente" : "Sincronizado";

    private static bool SoloLectura(MYGVinculoNube vinculo) =>
        string.Equals(vinculo.Rol, "lector", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(vinculo.EstadoConexion, "acceso retirado", StringComparison.OrdinalIgnoreCase);

    private static void ExigirConflicto(MYGVinculoNube vinculo)
    {
        Validar(vinculo);
        if (string.IsNullOrWhiteSpace(vinculo.JsonRemotoConflicto))
            throw new InvalidOperationException("La obra no tiene un conflicto pendiente de resolver.");
    }

    private static void AdoptarBaseRemota(MYGVinculoNube vinculo)
    {
        vinculo.Revision = vinculo.RevisionRemotaConflicto;
        vinculo.JsonConfirmado = vinculo.JsonRemotoConflicto;
        vinculo.JsonPaqueteConfirmado = vinculo.JsonPaqueteConflicto;
        vinculo.JsonRemotoConflicto = null;
        vinculo.JsonPaqueteConflicto = null;
        vinculo.RevisionRemotaConflicto = 0;
        vinculo.Pendiente = null;
    }

    private static void ExigirIdLocal(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) throw new ArgumentException("Indique el proyecto local de la hoja.", nameof(id));
    }

    private static void ExigirDocumentoLocal(MYGVinculoNube vinculo, string proyectoLocalId)
    {
        foreach (string json in new[] { vinculo.JsonConfirmado, vinculo.JsonBorrador, vinculo.JsonRemotoConflicto,
            vinculo.Pendiente == null ? null : DocumentoDeOperacion(vinculo.Pendiente) })
            if (!string.IsNullOrWhiteSpace(json) &&
                !string.Equals(ImportarDocumento(json).Id, proyectoLocalId, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Los documentos de la cola de nube pertenecen a otra obra local.");
    }

    private static MYGVinculoNube Copiar(MYGVinculoNube vinculo)
    {
        if (vinculo == null) throw new ArgumentNullException(nameof(vinculo));
        var copia = MYGProyectoStorage.Copia(vinculo);
        copia.FirmaLectura = vinculo.FirmaLectura;
        return copia;
    }

    private static void Aplicar(MYGVinculoNube origen, MYGVinculoNube destino)
    {
        destino.ProyectoId = origen.ProyectoId;
        destino.Servidor = origen.Servidor;
        destino.UsuarioId = origen.UsuarioId;
        destino.Rol = origen.Rol;
        destino.Revision = origen.Revision;
        destino.JsonConfirmado = origen.JsonConfirmado;
        destino.JsonPaqueteConfirmado = origen.JsonPaqueteConfirmado;
        destino.JsonRemotoConflicto = origen.JsonRemotoConflicto;
        destino.JsonPaqueteConflicto = origen.JsonPaqueteConflicto;
        destino.RevisionRemotaConflicto = origen.RevisionRemotaConflicto;
        destino.Pendiente = origen.Pendiente;
        destino.JsonBorrador = origen.JsonBorrador;
        destino.Estado = origen.Estado;
        destino.EstadoConexion = origen.EstadoConexion;
        destino.FirmaLectura = origen.FirmaLectura;
    }
}
