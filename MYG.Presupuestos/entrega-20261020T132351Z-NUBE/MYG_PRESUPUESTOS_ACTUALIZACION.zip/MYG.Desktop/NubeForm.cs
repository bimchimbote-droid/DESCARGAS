#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MYG.Colaboracion;
using MYG.Externo;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace MYG_2027;

/// <summary>Explorador de proyectos reales. El propietario conserva la vida del cliente compartido.</summary>
public sealed class NubeForm : WinForms.Form
{
    private readonly SesionDesktop sesion;
    private ClienteSupabase? cliente;
    private readonly CancellationTokenSource vida = new();
    private readonly WinForms.Label estado = new() { Name = "estadoNube", Dock = WinForms.DockStyle.Fill,
        TextAlign = Drawing.ContentAlignment.MiddleLeft, AutoEllipsis = true };
    private readonly WinForms.Label detalle = new() { Dock = WinForms.DockStyle.Fill,
        Text = "Seleccione un proyecto para abrirlo o consultar su colaboración.", AutoEllipsis = true };
    private readonly WinForms.TextBox correo = new() { Name = "correoNube", Dock = WinForms.DockStyle.Fill,
        PlaceholderText = "Correo de la cuenta Supabase", MaxLength = 320 };
    private readonly WinForms.TextBox contrasena = new() { Name = "contrasenaNube", Dock = WinForms.DockStyle.Fill,
        PlaceholderText = "Contraseña de la cuenta Supabase", UseSystemPasswordChar = true, MaxLength = 4096 };
    private readonly WinForms.TextBox codigo = new() { Name = "codigoProyectoNube", Dock = WinForms.DockStyle.Fill,
        PlaceholderText = "Código del proyecto o myg://proyecto/CODIGO", MaxLength = 256 };
    private readonly WinForms.TabControl paginas = new() { Name = "proyectosNube", Dock = WinForms.DockStyle.Fill };
    private readonly WinForms.DataGridView propios = TablaProyectos("proyectosPropiosNube");
    private readonly WinForms.DataGridView compartidos = TablaProyectos("proyectosCompartidosNube");
    private readonly WinForms.DataGridView miembros = Tabla("miembrosNube");
    private readonly WinForms.DataGridView solicitudes = Tabla("solicitudesNube");
    private readonly WinForms.ComboBox rol = new() { Name = "rolColaboracionNube", Width = 135,
        DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly List<WinForms.Button> acciones = new();
    private readonly WinForms.Button conectar, desconectar, actualizar, abrir, publicar, descargar,
        colaboracion, aceptar, rechazar, cambiarRol, retirar, copiarCodigo;
    private bool ocupado;
    private Guid? proyectoColaboracion;

    public event Func<ProyectoNube, Task>? AbrirSolicitado;
    public event Func<ProyectoNube, Task>? DescargarSolicitado;
    public event Func<Task>? PublicarSolicitado;
    public event Action? ConfiguracionSolicitada;

    public NubeForm(SesionDesktop sesion, ClienteSupabase? cliente)
    {
        this.sesion = sesion ?? throw new ArgumentNullException(nameof(sesion));
        this.cliente = cliente;
        Name = "ventanaNubeMYG";
        MYGProyectoUI.Preparar(this, "Nube MYG", 1150, 820);
        MinimumSize = new(880, 680);
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, Padding = new(20),
            ColumnCount = 1, RowCount = 6 };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 54, 124, 0, 62, 52, 40 })
            raiz.RowStyles.Add(alto == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, alto));

        var titulo = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 3 };
        titulo.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 190));
        titulo.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        titulo.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 160));
        titulo.Controls.Add(new WinForms.Label { Text = "Nube MYG", Dock = WinForms.DockStyle.Fill,
            Font = new("Segoe UI", 21, Drawing.FontStyle.Bold) }, 0, 0);
        titulo.Controls.Add(estado, 1, 0);
        var configurar = MYGProyectoUI.Boton("Configurar conexión");
        configurar.Name = "configurarNube";
        configurar.Click += (_, _) =>
        {
            if (ocupado) return;
            try { ConfiguracionSolicitada?.Invoke(); }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        titulo.Controls.Add(configurar, 2, 0); raiz.Controls.Add(titulo, 0, 0);

        var cuenta = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 4, RowCount = 3 };
        cuenta.ColumnStyles.Add(new(WinForms.SizeType.Percent, 50));
        cuenta.ColumnStyles.Add(new(WinForms.SizeType.Percent, 50));
        cuenta.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 120));
        cuenta.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 130));
        cuenta.RowStyles.Add(new(WinForms.SizeType.Absolute, 27));
        cuenta.RowStyles.Add(new(WinForms.SizeType.Absolute, 43));
        cuenta.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        var identidad = new WinForms.Label { Text = "Cuenta de nube Supabase", Dock = WinForms.DockStyle.Fill,
            Font = new("Segoe UI", 10, Drawing.FontStyle.Bold) };
        cuenta.Controls.Add(identidad, 0, 0); cuenta.SetColumnSpan(identidad, 4);
        cuenta.Controls.Add(correo, 0, 1); cuenta.Controls.Add(contrasena, 1, 1);
        conectar = CrearBoton("Conectar", "conectarNube", ConectarAsync);
        desconectar = CrearBoton("Desconectar", "desconectarNube", DesconectarAsync);
        cuenta.Controls.Add(conectar, 2, 1); cuenta.Controls.Add(desconectar, 3, 1);
        var aviso = new WinForms.Label { Dock = WinForms.DockStyle.Fill, Text =
            "La cuenta de nube es independiente del ingreso MYG. El servidor exige una vinculación MYG verificada y aplica los roles. La contraseña y los tokens no se guardan en disco." };
        cuenta.Controls.Add(aviso, 0, 2); cuenta.SetColumnSpan(aviso, 4); raiz.Controls.Add(cuenta, 0, 1);

        var centro = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        centro.ColumnStyles.Add(new(WinForms.SizeType.Percent, 57));
        centro.ColumnStyles.Add(new(WinForms.SizeType.Percent, 43));
        var paginaPropios = new WinForms.TabPage("Mis proyectos"); paginaPropios.Controls.Add(propios);
        var paginaCompartidos = new WinForms.TabPage("Compartidos conmigo"); paginaCompartidos.Controls.Add(compartidos);
        paginas.TabPages.Add(paginaPropios); paginas.TabPages.Add(paginaCompartidos);
        centro.Controls.Add(paginas, 0, 0);

        var panelColaboracion = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 5,
            Padding = new(12, 0, 0, 0) };
        panelColaboracion.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 38, 48, 0, 44, 88 })
            panelColaboracion.RowStyles.Add(alto == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, alto));
        panelColaboracion.Controls.Add(new WinForms.Label { Text = "Colaboración del proyecto seleccionado",
            Dock = WinForms.DockStyle.Fill }, 0, 0);
        colaboracion = CrearBoton("Cargar colaboración", "cargarColaboracionNube", CargarColaboracionAsync);
        colaboracion.AutoSize = true; panelColaboracion.Controls.Add(colaboracion, 0, 1);
        miembros.Columns.Add("UsuarioId", "Usuario verificado"); miembros.Columns.Add("Rol", "Rol");
        solicitudes.Columns.Add("UsuarioId", "Solicitante"); solicitudes.Columns.Add("Estado", "Estado");
        var grupos = new WinForms.TabControl { Dock = WinForms.DockStyle.Fill };
        var paginaMiembros = new WinForms.TabPage("Miembros"); paginaMiembros.Controls.Add(miembros);
        var paginaSolicitudes = new WinForms.TabPage("Solicitudes del proyecto"); paginaSolicitudes.Controls.Add(solicitudes);
        grupos.TabPages.Add(paginaMiembros); grupos.TabPages.Add(paginaSolicitudes);
        panelColaboracion.Controls.Add(grupos, 0, 2);
        rol.Items.AddRange(new object[] { "lector", "editor", "administrador" }); rol.SelectedIndex = 0;
        var filaRol = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, WrapContents = false };
        filaRol.Controls.Add(new WinForms.Label { Text = "Rol a asignar", AutoSize = true, Margin = new(0, 8, 10, 0) });
        filaRol.Controls.Add(rol); panelColaboracion.Controls.Add(filaRol, 0, 3);
        var accionesColaboracion = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, AutoScroll = true };
        aceptar = CrearBoton("Aceptar solicitud", "aceptarSolicitudNube", () => ResolverAsync(true));
        rechazar = CrearBoton("Rechazar solicitud", "rechazarSolicitudNube", () => ResolverAsync(false));
        cambiarRol = CrearBoton("Cambiar rol", "cambiarRolNube", () => CambiarRolAsync(false));
        retirar = CrearBoton("Retirar acceso", "retirarAccesoNube", () => CambiarRolAsync(true));
        foreach (var boton in new[] { aceptar, rechazar, cambiarRol, retirar })
        { boton.AutoSize = true; boton.Height = 32; accionesColaboracion.Controls.Add(boton); }
        panelColaboracion.Controls.Add(accionesColaboracion, 0, 4);
        centro.Controls.Add(panelColaboracion, 1, 0); raiz.Controls.Add(centro, 0, 2);

        var acceso = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 2,
            Padding = new(0, 7, 0, 0) };
        acceso.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100)); acceso.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 170));
        acceso.RowStyles.Add(new(WinForms.SizeType.Absolute, 22)); acceso.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        acceso.Controls.Add(new WinForms.Label { Text = "Solicitar acceso por código o enlace", AutoSize = true }, 0, 0);
        acceso.Controls.Add(codigo, 0, 1);
        var solicitar = CrearBoton("Solicitar acceso", "solicitarAccesoNube", SolicitarAccesoAsync);
        acceso.Controls.Add(solicitar, 1, 1); raiz.Controls.Add(acceso, 0, 3);

        var barra = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, WrapContents = false, AutoScroll = true };
        actualizar = CrearBoton("Actualizar", "actualizarProyectosNube", RefrescarInternoAsync);
        abrir = CrearBoton("Abrir proyecto", "abrirProyectoNube", AbrirAsync);
        publicar = CrearBoton("Crear / publicar", "publicarProyectoNube", PublicarAsync);
        descargar = CrearBoton("Descargar copia", "descargarProyectoNube", DescargarAsync);
        copiarCodigo = CrearBoton("Copiar enlace", "copiarCodigoNube", CopiarEnlaceAsync);
        foreach (var boton in new[] { actualizar, abrir, publicar, descargar, copiarCodigo })
        { boton.AutoSize = true; barra.Controls.Add(boton); }
        raiz.Controls.Add(barra, 0, 4); raiz.Controls.Add(detalle, 0, 5); Controls.Add(raiz);

        propios.SelectionChanged += (_, _) => CambioSeleccion();
        compartidos.SelectionChanged += (_, _) => CambioSeleccion();
        paginas.SelectedIndexChanged += (_, _) => CambioSeleccion();
        miembros.SelectionChanged += (_, _) => ActualizarAcciones();
        solicitudes.SelectionChanged += (_, _) => ActualizarAcciones();
        sesion.Cambio += CambioSesion;
        Disposed += (_, _) => { sesion.Cambio -= CambioSesion; vida.Cancel(); vida.Dispose(); };
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; else contrasena.Clear(); };
        Shown += async (_, _) => { ActualizarAcciones(); if (cliente?.SesionIniciada == true && sesion.Autorizado) await RefrescarAsync(); };
        ActualizarAcciones();
    }

    public void ActualizarCliente(ClienteSupabase? nuevo)
    {
        if (ocupado) throw new InvalidOperationException("Espere a que termine la operación de nube.");
        cliente = nuevo;
        LimpiarProyectos(); contrasena.Clear(); ActualizarAcciones();
    }

    public Task RefrescarAsync() => EjecutarAsync(RefrescarInternoAsync);

    private static WinForms.DataGridView Tabla(string nombre)
    {
        var tabla = MYGBibliotecaUI.Tabla();
        tabla.Name = nombre; tabla.ReadOnly = true; tabla.MultiSelect = false;
        tabla.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect;
        tabla.AutoSizeColumnsMode = WinForms.DataGridViewAutoSizeColumnsMode.Fill;
        return tabla;
    }

    private static WinForms.DataGridView TablaProyectos(string nombre)
    {
        var tabla = Tabla(nombre);
        tabla.Columns.Add("Nombre", "Proyecto"); tabla.Columns.Add("Codigo", "Código");
        tabla.Columns.Add("Rol", "Mi rol"); tabla.Columns.Add("Revision", "Revisión");
        return tabla;
    }

    private WinForms.Button CrearBoton(string texto, string nombre, Func<Task> accion)
    {
        var boton = MYGProyectoUI.Boton(texto); boton.Name = nombre;
        boton.Height = 34; boton.Margin = new(3); MYGAnimacionUI.PrepararBoton(boton);
        boton.Click += async (_, _) => await EjecutarAsync(accion);
        acciones.Add(boton); return boton;
    }

    private ProyectoNube? Seleccionado => (paginas.SelectedIndex == 0 ? propios : compartidos)
        .CurrentRow?.Tag as ProyectoNube;
    private bool PuedeAdministrar => Seleccionado?.Rol is "propietario" or "administrador";

    private void CambioSesion()
    {
        if (IsDisposed || Disposing) return;
        if (InvokeRequired) { BeginInvoke((Action)CambioSesion); return; }
        if (!sesion.Autorizado) LimpiarProyectos();
        ActualizarAcciones();
    }

    private void CambioSeleccion()
    {
        proyectoColaboracion = null; miembros.Rows.Clear(); solicitudes.Rows.Clear();
        detalle.Text = Seleccionado is { } p ? $"{p.Nombre} · {p.Codigo} · {p.Rol} · revisión {p.Revision}"
            : "No hay proyecto seleccionado. Actualice la lista o publique un proyecto local.";
        ActualizarAcciones();
    }

    private void LimpiarProyectos()
    {
        propios.Rows.Clear(); compartidos.Rows.Clear(); miembros.Rows.Clear(); solicitudes.Rows.Clear();
        proyectoColaboracion = null;
    }

    private void ActualizarAcciones()
    {
        if (IsDisposed || Disposing) return;
        bool configurado = cliente is not null, conectada = cliente?.SesionIniciada == true;
        bool disponible = !ocupado && sesion.Autorizado;
        foreach (var boton in acciones) boton.Enabled = disponible && conectada;
        conectar.Enabled = disponible && configurado && !conectada;
        desconectar.Enabled = !ocupado && conectada;
        correo.Enabled = contrasena.Enabled = disponible && configurado && !conectada;
        bool seleccion = disponible && conectada && Seleccionado is not null;
        abrir.Enabled = seleccion && AbrirSolicitado is not null;
        descargar.Enabled = seleccion && DescargarSolicitado is not null;
        publicar.Enabled = disponible && conectada && PublicarSolicitado is not null;
        copiarCodigo.Enabled = seleccion; colaboracion.Enabled = seleccion;
        bool cargado = seleccion && proyectoColaboracion == Seleccionado?.Id && PuedeAdministrar;
        aceptar.Enabled = rechazar.Enabled = cargado && solicitudes.CurrentRow?.Tag is SolicitudNube s && s.Estado == "pendiente";
        bool miembroEditable = miembros.CurrentRow?.Tag is MiembroNube m && m.Rol != "propietario";
        cambiarRol.Enabled = retirar.Enabled = cargado && miembroEditable;
        rol.Enabled = cargado;
        estado.Text = !sesion.Autorizado ? "Se requiere una licencia MYG autorizada"
            : !configurado ? "Sin configurar" : ocupado ? "Procesando…"
            : conectada ? "Cuenta de nube conectada" : "Desconectado";
    }

    private void RequerirLicencia()
    {
        if (!sesion.Autorizado)
            throw new InvalidOperationException("Inicie una sesión MYG con licencia autorizada para usar la nube.");
    }

    private ClienteSupabase RequerirCliente(bool autenticado = true)
    {
        RequerirLicencia();
        var actual = cliente ?? throw new InvalidOperationException("Configure primero la conexión a Supabase.");
        if (autenticado && !actual.SesionIniciada)
            throw new InvalidOperationException("Conecte su cuenta de nube para continuar.");
        return actual;
    }

    private ProyectoNube RequerirProyecto() => Seleccionado
        ?? throw new InvalidOperationException("Seleccione un proyecto.");

    private async Task EjecutarAsync(Func<Task> accion)
    {
        if (ocupado || IsDisposed || Disposing) return;
        ocupado = true; ActualizarAcciones();
        try { await accion(); }
        catch (OperationCanceledException) when (vida.IsCancellationRequested) { }
        catch (Exception ex)
        {
            if (cliente?.SesionIniciada != true) LimpiarProyectos();
            if (!IsDisposed && !Disposing)
            { detalle.Text = ex.Message; MYGProyectoUI.Error(this, ex); }
        }
        finally { ocupado = false; ActualizarAcciones(); }
    }

    private async Task ConectarAsync()
    {
        try
        {
            await RequerirCliente(false).IniciarSesionAsync(correo.Text, contrasena.Text, vida.Token);
            RequerirLicencia(); await RefrescarInternoAsync();
        }
        finally { contrasena.Clear(); }
    }

    private async Task DesconectarAsync()
    {
        // Siempre se permite borrar la sesión, incluso si caducó la licencia MYG.
        try { if (cliente is not null) await cliente.CerrarSesionAsync(vida.Token); }
        finally { LimpiarProyectos(); contrasena.Clear(); detalle.Text = "Cuenta de nube desconectada."; }
    }

    private async Task RefrescarInternoAsync()
    {
        Guid? anterior = Seleccionado?.Id;
        var lista = await RequerirCliente().ListarProyectosAsync(vida.Token);
        RequerirLicencia(); LimpiarProyectos();
        foreach (var proyecto in lista)
        {
            var tabla = proyecto.Rol == "propietario" ? propios : compartidos;
            int indice = tabla.Rows.Add(proyecto.Nombre, proyecto.Codigo, proyecto.Rol, proyecto.Revision);
            tabla.Rows[indice].Tag = proyecto;
            if (proyecto.Id == anterior) tabla.CurrentCell = tabla.Rows[indice].Cells[0];
        }
        CambioSeleccion();
        if (lista.Count == 0) detalle.Text = "Su cuenta no tiene proyectos autorizados. Publique uno o solicite acceso por código.";
    }

    private async Task CargarColaboracionAsync()
    {
        var p = RequerirProyecto(); var actual = RequerirCliente();
        var listaMiembros = await actual.ListarMiembrosAsync(p.Id, vida.Token);
        RequerirLicencia();
        var listaSolicitudes = PuedeAdministrar ? await actual.ListarSolicitudesAsync(p.Id, vida.Token) : null;
        RequerirLicencia();
        if (Seleccionado?.Id != p.Id) return;
        miembros.Rows.Clear(); solicitudes.Rows.Clear();
        foreach (var miembro in listaMiembros)
        {
            int indice = miembros.Rows.Add(miembro.UsuarioId, miembro.Rol);
            miembros.Rows[indice].Tag = miembro;
        }
        if (listaSolicitudes is not null) foreach (var solicitud in listaSolicitudes)
        {
            int indice = solicitudes.Rows.Add(solicitud.UsuarioId, solicitud.Estado);
            solicitudes.Rows[indice].Tag = solicitud;
        }
        proyectoColaboracion = p.Id;
        detalle.Text = PuedeAdministrar ? "Solicitudes y miembros consultados en el servidor. Seleccione una fila para administrarla."
            : "Miembros consultados. Solo propietario o administrador pueden gestionar solicitudes y roles.";
    }

    private async Task ResolverAsync(bool permitir)
    {
        var p = RequerirProyecto();
        if (!PuedeAdministrar || proyectoColaboracion != p.Id
            || solicitudes.CurrentRow?.Tag is not SolicitudNube solicitud || solicitud.Estado != "pendiente")
            throw new InvalidOperationException("Seleccione una solicitud pendiente de un proyecto que administra.");
        string nuevoRol = rol.SelectedItem as string ?? "lector";
        await RequerirCliente().ResolverSolicitudAsync(p.Id, solicitud.UsuarioId, nuevoRol, permitir, vida.Token);
        RequerirLicencia(); await CargarColaboracionAsync();
    }

    private async Task CambiarRolAsync(bool eliminar)
    {
        var p = RequerirProyecto();
        if (!PuedeAdministrar || proyectoColaboracion != p.Id
            || miembros.CurrentRow?.Tag is not MiembroNube miembro || miembro.Rol == "propietario")
            throw new InvalidOperationException("Seleccione un miembro editable del proyecto que administra.");
        if (eliminar && WinForms.MessageBox.Show(this,
            "¿Retirar el acceso de este miembro al proyecto?", "Colaboración MYG",
            WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question) != WinForms.DialogResult.Yes) return;
        await RequerirCliente().CambiarRolAsync(p.Id, miembro.UsuarioId,
            eliminar ? null : rol.SelectedItem as string ?? "lector", vida.Token);
        RequerirLicencia(); await CargarColaboracionAsync();
    }

    private async Task SolicitarAccesoAsync()
    {
        string identificador = NormalizarCodigo(codigo.Text);
        await RequerirCliente().SolicitarAccesoAsync(identificador, vida.Token);
        RequerirLicencia(); codigo.Clear();
        detalle.Text = "Solicitud enviada al servidor. El propietario o administrador debe autorizarla; el código no concede acceso al contenido.";
    }

    private static string NormalizarCodigo(string entrada)
    {
        string valor = entrada.Trim();
        if (valor.StartsWith("myg:", StringComparison.OrdinalIgnoreCase))
        {
            if (!Uri.TryCreate(valor, UriKind.Absolute, out var enlace) || enlace.Scheme != "myg"
                || enlace.Host != "proyecto" || !enlace.IsDefaultPort || enlace.UserInfo.Length != 0 || enlace.Query.Length != 0
                || enlace.Fragment.Length != 0 || enlace.AbsolutePath.Trim('/').Contains('/'))
                throw new InvalidOperationException("Use un enlace myg://proyecto/CODIGO válido.");
            valor = Uri.UnescapeDataString(enlace.AbsolutePath.Trim('/'));
        }
        if (valor.Length is < 4 or > 64 || valor.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-'))
            throw new InvalidOperationException("Introduzca un código de proyecto válido.");
        return valor.ToUpperInvariant();
    }

    private async Task AbrirAsync()
    {
        var p = RequerirProyecto(); RequerirCliente();
        if (AbrirSolicitado is null) throw new InvalidOperationException("La apertura no está disponible.");
        await AbrirSolicitado(p);
        Hide();
    }

    private async Task DescargarAsync()
    {
        var p = RequerirProyecto(); RequerirCliente();
        if (DescargarSolicitado is null) throw new InvalidOperationException("La descarga no está disponible.");
        await DescargarSolicitado(p);
    }

    private async Task PublicarAsync()
    {
        RequerirCliente();
        if (PublicarSolicitado is null) throw new InvalidOperationException("La publicación no está disponible.");
        await PublicarSolicitado(); RequerirLicencia(); await RefrescarInternoAsync();
    }

    private Task CopiarEnlaceAsync()
    {
        RequerirCliente(); var p = RequerirProyecto();
        WinForms.Clipboard.SetText("myg://proyecto/" + p.Codigo);
        detalle.Text = "Enlace copiado. Compartirlo permite solicitar acceso; los permisos se comprueban en el servidor.";
        return Task.CompletedTask;
    }
}
