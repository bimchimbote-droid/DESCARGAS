using System;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Func<bool> permisoEdicionNube;
    internal bool EdicionNubePermitida => permisoEdicionNube?.Invoke() != false;

    internal void ConfigurarPermisoNube(Func<bool> permiso)
    {
        permisoEdicionNube = permiso;
        if (editorEspecificaciones != null)
            editorEspecificaciones.PermisoEdicionNube = () => EdicionNubePermitida;
        ActualizarPermisoNube();
    }

    internal void ActualizarPermisoNube()
    {
        if (IsDisposed || Disposing) return;
        bool permite = EdicionNubePermitida;
        bool previo = cargando;
        cargando = true;
        try
        {
            if (!permite)
            {
                // El editor guarda previamente los cambios autorizados.
                // Cancelar aquí evita confirmar un editor residual al bloquear.
                estructura.CancelEdit(); acu.CancelEdit(); hoja.CancelEdit(); tablaPie.CancelEdit();
                formulaPendienteHoja = false;
            }
            estructura.ReadOnly = acu.ReadOnly = tablaPie.ReadOnly = !permite;
            hoja.ReadOnly = formula.ReadOnly = !permite || EligiendoReferenciaPartidaHoja;
            celdaTotal.ReadOnly = !permite;
            especificacion.ReadOnly = !permite || !HayPartida;
            fuente.Enabled = rendimiento.Enabled = jornada.Enabled = permite && HayPartida;
            precioDirecto.Enabled = permite && HayPartida && PartidaActual?.Costos.Analisis.Count == 0;
            bool formaDisponible = permite && HayPartida && obtenerProyectoEstructura?.Invoke()?.Datos != null;
            porRendimientoACU.Enabled = porAsignacionACU.Enabled = formaDisponible;
            if (botonReferenciaPartidaHoja != null)
                botonReferenciaPartidaHoja.Enabled = permite && HayPartida;
            editorEspecificaciones?.ActualizarPermisoNube();
        }
        finally { cargando = previo; }
    }
}

internal sealed partial class MYGEspecificacionesEditor
{
    internal Func<bool> PermisoEdicionNube;
    private bool EdicionNubePermitida => PermisoEdicionNube?.Invoke() != false;

    internal void ActualizarPermisoNube()
    {
        if (IsDisposed || Disposing) return;
        bool permite = EdicionNubePermitida && !string.IsNullOrEmpty(identidad);
        if (!permite) CancelarArrastreMargenes();
        documento.ReadOnly = !permite;
        insertarTitulo.Enabled = permite;
        regla.EdicionHabilitada = reglaVertical.EdicionHabilitada = permite && !borrador;
    }
}
