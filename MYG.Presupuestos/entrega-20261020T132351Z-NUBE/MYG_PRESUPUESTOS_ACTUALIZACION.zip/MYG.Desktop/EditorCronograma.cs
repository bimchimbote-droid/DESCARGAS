using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private MYGPanelCronograma panelCronograma;
    private FlowLayoutPanel cintaCronograma;
    private Button botonVistaPresupuesto, botonVistaCronograma;
    private TableLayoutPanel exteriorPresupuestoCronograma;
    private Control selectorPresupuestoCronograma;
    private MYGProyectoDocumento documentoCronogramaTemporal;
    private MYGCronograma cronogramaTemporal;
    private bool cronogramaVisible, cambiandoVistaCronograma;

    private MYGCronograma CronogramaActual()
    {
        if (documento.Cronograma != null) return documento.Cronograma;
        if (!ReferenceEquals(documentoCronogramaTemporal, documento) || cronogramaTemporal == null)
        {
            documentoCronogramaTemporal = documento;
            cronogramaTemporal = MYGMotorCronograma.CrearDesdePresupuestos(documento);
        }
        return cronogramaTemporal;
    }

    private void AplicarCronograma(MYGCronograma nuevo)
    {
        ExigirPermisoEdicionProyecto();
        MYGMotorCronograma.Validar(nuevo);
        // La copia del panel ya está validada antes de capturar el historial.
        // No se cambia el presupuesto, ni se registra una entrada por navegar.
        var copia = MYGProyectoStorage.Copia(nuevo);
        if (documento.Cronograma != null && System.Text.Json.JsonSerializer.Serialize(documento.Cronograma) ==
            System.Text.Json.JsonSerializer.Serialize(copia)) return;
        Recordar();
        documento.Cronograma = copia;
        cronogramaTemporal = null;
        ActualizarResumen();
        EstadoHerramientasCronograma();
    }

    private void InicializarCronograma(TabPage principal, TableLayoutPanel exterior, Control seleccion)
    {
        exteriorPresupuestoCronograma = exterior;
        selectorPresupuestoCronograma = seleccion;
        exterior.DpiChangedAfterParent += (_, _) => AjustarAlturaCintas();
        panelCronograma = new MYGPanelCronograma(CronogramaActual, AplicarCronograma,
            () => !ocupado && PuedeModificarProyecto, () => Guardar(false),
            () => Historial(false), () => Historial(true), () => documento, () => archivo)
        { Name = "cronograma_panel", Dock = DockStyle.Fill, Visible = false };
        principal.Controls.Add(panelCronograma);

        cintaCronograma = new FlowLayoutPanel
        {
            Name = "herramientas_cronograma", Dock = DockStyle.Fill, WrapContents = false,
            AutoScroll = true, Padding = new(4), Margin = new(0),
            BackColor = MYG2027_TemaComercial.Fondo, Visible = false
        };
        Button Comun(string icono, string texto, string nombre, Action accion, bool requiereLicencia, bool desplegable = false)
        {
            var boton = CrearBotonCintaProyecto(icono, texto, requiereLicencia);
            boton.Name = nombre;
            ayudas.SetToolTip(boton, boton.AccessibleName);
            boton.Click += (_, _) =>
            {
                if (ocupado) return;
                try
                {
                    if (requiereLicencia && !sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para continuar.");
                    if (requiereLicencia) ExigirPermisoEdicionProyecto();
                    if (!desplegable) Sincronizar();
                    accion();
                }
                catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
            };
            cintaCronograma.Controls.Add(boton);
            return boton;
        }
        Comun("proyecto", "Ir inicio", "cronograma_inicio_button", IrInicio, false);
        Comun("guardar", "Guardar", "cronograma_guardar_button", () => Guardar(false), false);
        Button imprimir = null;
        Func<ContextMenuStrip> menuImprimir = () => CrearMenuImpresionActual(
            () => EjecutarDesdeMenuCronograma(panelCronograma.Imprimir), EjecutarDesdeMenuCronograma);
        imprimir = Comun("imprimir", "Imprimir ▾", "cronograma_imprimir_button", () => MostrarMenuCronograma(imprimir, menuImprimir), false, true);
        PrepararMenuCronograma(imprimir, menuImprimir);
        Comun("proyecto", "Info. proyecto", "cronograma_info_proyecto_button", EditarDatosProyecto, true);
        Button exportar = null;
        Func<ContextMenuStrip> menuExportar = () => MYGMenuExportacionCronograma.Crear(destino =>
            EjecutarDesdeMenuCronograma(() => panelCronograma.ExportarDestino(destino, archivo)));
        exportar = Comun("excel", "Exportar ▾", "cronograma_exportar_button", () => MostrarMenuCronograma(exportar, menuExportar), false, true);
        PrepararMenuCronograma(exportar, menuExportar);
        foreach (var boton in panelCronograma.BotonesCinta) cintaCronograma.Controls.Add(boton);

        var cabeceraVistas = new TableLayoutPanel
        {
            Name = "cabecera_vistas_proyecto", Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1,
            Margin = new(0), Padding = new(0), BackColor = MYG2027_TemaComercial.Fondo
        };
        cabeceraVistas.ColumnStyles.Add(new(SizeType.Percent, 100));
        cabeceraVistas.ColumnStyles.Add(new(SizeType.Absolute, 126));
        cabeceraVistas.RowStyles.Add(new(SizeType.Percent, 100));
        var cintas = new Panel { Dock = DockStyle.Fill, Margin = new(0) };
        exterior.Controls.Remove(cintaPresupuestos);
        cintas.Controls.Add(cintaPresupuestos); cintas.Controls.Add(cintaCronograma);
        cabeceraVistas.Controls.Add(cintas, 0, 0);
        var modos = new FlowLayoutPanel
        {
            Name = "selector_vistas_proyecto", Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false, Padding = new(3, 5, 0, 0), Margin = new(0),
            BackColor = MYG2027_TemaComercial.Fondo
        };
        Button Vista(string codigo, string descripcion, string nombre, string icono, bool mostrarCronograma)
        {
            var boton = CrearBotonCintaProyecto(icono, codigo, false);
            boton.Name = nombre; boton.Width = 55; boton.Height = 72;
            boton.AccessibleName = descripcion; ayudas.SetToolTip(boton, descripcion);
            boton.Click += (_, _) =>
            {
                try { MostrarVistaCronograma(mostrarCronograma); }
                catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
            };
            modos.Controls.Add(boton); return boton;
        }
        botonVistaPresupuesto = Vista("R", "Presupuesto", "vista_presupuesto_button", "catalogo", false);
        botonVistaCronograma = Vista("CPM", "Cronograma y diagrama de Gantt", "vista_cronograma_button", "resumen", true);
        cabeceraVistas.Controls.Add(modos, 1, 0);
        exterior.Controls.Add(cabeceraVistas, 0, 0);
        espacioPresupuestos.SelectedIndexChanged += (_, _) =>
        {
            if (espacioPresupuestos.SelectedIndex != 0 && cronogramaVisible)
            {
                MostrarVistaCronograma(false, false);
                if (cronogramaVisible) espacioPresupuestos.SelectedIndex = 0;
            }
        };
        EstadoHerramientasCronograma();
    }

    private void MostrarVistaCronograma(bool mostrar, bool cambiarPestana = true)
    {
        if (ocupado || cambiandoVistaCronograma) return;
        if (cronogramaVisible == mostrar && (!cambiarPestana || espacioPresupuestos.SelectedIndex == 0)) return;
        if (cronogramaVisible && !mostrar && !panelCronograma.ConfirmarSalidaTiempoTrabajo()) return;
        Sincronizar();
        cambiandoVistaCronograma = true;
        try
        {
            if (mostrar) panelCronograma.Refrescar();
            cronogramaVisible = mostrar;
            if (cambiarPestana) espacioPresupuestos.SelectedIndex = 0;
            espacioPresupuestos.TabPages[0].Text = mostrar ? "Cronograma" : "Presupuesto";
            panelCronograma.Visible = mostrar; panelPresupuesto.Visible = !mostrar;
            if (mostrar) panelCronograma.BringToFront();
            else { panelPresupuesto.BringToFront(); panelPresupuesto.Refrescar(); }
            cintaCronograma.Visible = mostrar; cintaPresupuestos.Visible = !mostrar;
            if (mostrar) cintaCronograma.BringToFront(); else cintaPresupuestos.BringToFront();
            selectorPresupuestoCronograma.Visible = !mostrar;
            // Ambas vistas comparten la altura de cinta. Sus botones reservan
            // zonas separadas para el icono y el texto; el flujo conserva sitio
            // para desplazarse horizontalmente en ventanas estrechas.
            AjustarAlturaCintas();
            EstadoHerramientasCronograma();
        }
        finally { cambiandoVistaCronograma = false; }
    }

    private void AjustarAlturaCintas()
    {
        float escala = exteriorPresupuestoCronograma.DeviceDpi / 96F;
        exteriorPresupuestoCronograma.RowStyles[0].Height = (float)Math.Ceiling(98F * escala);
        exteriorPresupuestoCronograma.RowStyles[1].Height = cronogramaVisible ? 0 : (float)Math.Ceiling(36F * escala);
    }

    private void EstadoHerramientasCronograma()
    {
        if (cintaCronograma == null || IsDisposed) return;
        foreach (var boton in cintaCronograma.Controls.OfType<Button>())
            boton.Enabled = HerramientaEditorDisponible(boton);
        panelCronograma.Enabled = !ocupado;
        botonVistaPresupuesto.Enabled = botonVistaCronograma.Enabled = !ocupado;
        void Estado(Button boton, bool activo)
        {
            MYG2027_TemaComercial.EstilizarBoton(boton, activo ? 2 : 0);
            boton.AccessibleDescription = activo ? "Vista seleccionada" : "Cambiar de vista";
        }
        Estado(botonVistaPresupuesto, !cronogramaVisible); Estado(botonVistaCronograma, cronogramaVisible);
    }

    private void RefrescarCronogramaEditor()
    {
        if (documento.Cronograma == null)
        { cronogramaTemporal = null; documentoCronogramaTemporal = null; }
        if (cronogramaVisible) panelCronograma?.Refrescar();
    }

    private void PrepararMenuCronograma(Button boton, Func<ContextMenuStrip> crear)
    {
        boton.ContextMenuStrip = crear();
        boton.Disposed += (_, _) => boton.ContextMenuStrip?.Dispose();
        boton.MouseDown += (_, e) =>
        {
            if (e.Button == MouseButtons.Right && !ocupado) ActualizarMenuCronograma(boton, crear);
        };
    }

    private void EjecutarDesdeMenuCronograma(Action accion)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        BeginInvoke((Action)(async () =>
        {
            if (IsDisposed || Disposing || ocupado) return;
            try
            {
                // Confirmar el borrador y la celda antes de bloquear el editor.
                // El control conserva sus guardas de sesión durante el guardado.
                if (!panelCronograma.ConfirmarSalidaTiempoTrabajo()) return;
                Sincronizar();
                await Ejecutar(() => { accion(); return System.Threading.Tasks.Task.CompletedTask; }, false);
            }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        }));
    }
    private static void ActualizarMenuCronograma(Button boton, Func<ContextMenuStrip> crear)
    {
        var anterior = boton.ContextMenuStrip;
        boton.ContextMenuStrip = crear();
        anterior?.Dispose();
    }
    private static void MostrarMenuCronograma(Button boton, Func<ContextMenuStrip> crear)
    {
        ActualizarMenuCronograma(boton, crear);
        boton.ContextMenuStrip.Show(boton, new Point(0, boton.Height));
    }
}
