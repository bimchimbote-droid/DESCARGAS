using System;
using System.Linq;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private void AbrirCatalogoUnidades()
    {
        using var f = new MYGUnidadesForm(RutaCatalogoPropio(), () => PuedeModificarProyecto);
        f.ShowDialog(this);
    }
    private void GuardarPartidaCatalogoSeleccionada()
    {
        Sincronizar();
        var i = Seleccionadas.FirstOrDefault(x => !MYGProyectoStorage.EsTitulo(x));
        if (i == null) throw new InvalidOperationException("Seleccione una partida del presupuesto.");
        panelPresupuesto.SeleccionarPartidaCatalogo(i.Id); panelPresupuesto.GuardarPartidaEnCatalogo();
    }
    private void AbrirCatalogoPartidasPropio()
    {
        Sincronizar(); var i = Seleccionadas.FirstOrDefault();
        if (i != null) panelPresupuesto.SeleccionarPartidaCatalogo(i.Id);
        panelPresupuesto.ElegirPartidaDelCatalogo();
    }
    private string RutaCatalogoPropio()
    {
        if (string.IsNullOrWhiteSpace(archivo) && !Guardar(false))
            throw new OperationCanceledException("Guarde el proyecto para crear su base de datos y usar los catálogos.");
        return MYGBaseDatos.AsegurarParaProyecto(archivo, documento);
    }
}
