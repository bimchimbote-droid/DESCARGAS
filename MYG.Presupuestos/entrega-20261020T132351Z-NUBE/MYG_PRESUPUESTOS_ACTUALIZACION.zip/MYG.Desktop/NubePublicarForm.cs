#nullable enable
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace MYG_2027;

/// <summary>Elige el alcance de una publicación nueva sin modificar su documento de origen.</summary>
public sealed class NubePublicarForm : WinForms.Form
{
    private readonly MYGProyectoDocumento? actual;
    private readonly string? rutaActual;
    private readonly WinForms.ComboBox modo = new() { Name = "modoPublicacionNube", Dock = WinForms.DockStyle.Fill,
        DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly WinForms.TextBox nombre = new() { Name = "nombrePublicacionNube", Dock = WinForms.DockStyle.Fill,
        MaxLength = 200, PlaceholderText = "Nombre del nuevo proyecto de nube" };
    private readonly WinForms.TextBox ruta = new() { Name = "archivoPublicacionNube", Dock = WinForms.DockStyle.Fill,
        ReadOnly = true, PlaceholderText = "Seleccione una base .sqlite" };
    private readonly WinForms.ComboBox proyectos = new() { Name = "obraPublicacionNube", Dock = WinForms.DockStyle.Fill,
        DisplayMember = nameof(MYGProyectoResumen.Nombre), DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly WinForms.Label explicacion = new() { Name = "alcancePublicacionNube", Dock = WinForms.DockStyle.Fill };
    private readonly WinForms.CheckBox confirmarBase = new() { Name = "confirmarBaseCompletaNube", Dock = WinForms.DockStyle.Fill,
        Text = "Autorizo compartir TODAS las obras y catálogos de esta base con los miembros del proyecto.", AutoSize = false };
    private readonly WinForms.Button elegir, publicar;
    private bool ocupado;
    private string? rutaCargada;

    public MYGProyectoDocumento? Documento { get; private set; }
    public string? RutaSQLite { get; private set; }
    public string Alcance { get; private set; } = "obra";
    public string Nombre { get; private set; } = "";
    public bool CrearVacia { get; private set; }

    public NubePublicarForm(MYGProyectoDocumento? actual, string? rutaActual)
    {
        this.actual = actual;
        this.rutaActual = rutaActual;
        Name = "publicarProyectoNubeDialogo";
        MYGProyectoUI.Preparar(this, "Crear o publicar en nube", 760, 604);
        MinimumSize = new(680, 590);
        MaximizeBox = false; MinimizeBox = false;
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, Padding = new(24),
            ColumnCount = 2, RowCount = 11 };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 145));
        foreach (int alto in new[] { 35, 40, 26, 38, 26, 40, 26, 38, 82, 58, 62 })
            raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, alto));
        var titulo = new WinForms.Label { Text = "Nuevo proyecto de nube", Dock = WinForms.DockStyle.Fill,
            Font = new("Segoe UI", 15, Drawing.FontStyle.Bold) };
        raiz.Controls.Add(titulo, 0, 0); raiz.SetColumnSpan(titulo, 2);
        modo.Items.AddRange(new object[] { "Proyecto abierto: publicar una obra", "Crear proyecto vacío",
            "Obra de una base SQLite", "Base completa: todas las obras y catálogos" });
        raiz.Controls.Add(modo, 0, 1); raiz.SetColumnSpan(modo, 2);
        raiz.Controls.Add(new WinForms.Label { Text = "Nombre del proyecto de nube", AutoSize = true }, 0, 2);
        nombre.Text = actual?.Nombre ?? "";
        raiz.Controls.Add(nombre, 0, 3); raiz.SetColumnSpan(nombre, 2);
        raiz.Controls.Add(new WinForms.Label { Text = "Base de datos de origen", AutoSize = true }, 0, 4);
        raiz.Controls.Add(ruta, 0, 5);
        elegir = MYGProyectoUI.Boton("Elegir .sqlite"); elegir.Name = "elegirArchivoPublicacionNube";
        elegir.Click += async (_, _) => await ElegirArchivoAsync();
        raiz.Controls.Add(elegir, 1, 5);
        raiz.Controls.Add(new WinForms.Label { Text = "Obra principal", AutoSize = true }, 0, 6);
        raiz.Controls.Add(proyectos, 0, 7); raiz.SetColumnSpan(proyectos, 2);
        raiz.Controls.Add(explicacion, 0, 8); raiz.SetColumnSpan(explicacion, 2);
        raiz.Controls.Add(confirmarBase, 0, 9); raiz.SetColumnSpan(confirmarBase, 2);
        var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = false };
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        publicar = MYGProyectoUI.Boton("Continuar", 1); publicar.Name = "continuarPublicacionNube";
        publicar.Click += async (_, _) => await AceptarAsync();
        pie.Controls.Add(cancelar); pie.Controls.Add(publicar);
        raiz.Controls.Add(pie, 0, 10); raiz.SetColumnSpan(pie, 2);
        Controls.Add(raiz); AcceptButton = publicar; CancelButton = cancelar;
        modo.SelectedIndexChanged += (_, _) => ActualizarModo();
        proyectos.SelectedIndexChanged += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(nombre.Text) && proyectos.SelectedItem is MYGProyectoResumen p)
                nombre.Text = p.Nombre;
        };
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; };
        modo.SelectedIndex = actual is not null && !string.IsNullOrWhiteSpace(rutaActual)
            && File.Exists(rutaActual) ? 0 : 1;
        ActualizarModo();
    }

    private void ActualizarModo()
    {
        bool sqlite = modo.SelectedIndex is 2 or 3;
        elegir.Enabled = !ocupado && sqlite;
        proyectos.Enabled = !ocupado && sqlite;
        confirmarBase.Visible = modo.SelectedIndex == 3;
        if (modo.SelectedIndex != 3) confirmarBase.Checked = false;
        if (modo.SelectedIndex == 0)
        {
            ruta.Text = rutaActual ?? "";
            explicacion.Text = "Publicará una copia de la obra abierta y sus presupuestos. El proyecto de nube tendrá una identidad nueva. El archivo original se conserva y no queda sincronizado automáticamente.";
        }
        else if (modo.SelectedIndex == 1)
        {
            ruta.Clear();
            explicacion.Text = "Creará una obra vacía con un presupuesto general. Después podrá abrirla y trabajar con las herramientas habituales de MYG.";
        }
        else
        {
            ruta.Text = rutaCargada ?? "";
            explicacion.Text = modo.SelectedIndex == 3
                ? "Compartirá TODAS las obras y catálogos reconocidos de la base. La obra principal se abrirá en el editor. No se incluyen cuentas, claves ni configuración local; las extensiones no reconocidas se informarán antes de publicar."
                : "Compartirá la obra elegida con sus presupuestos y dependencias reconocidas. Las demás obras se conservan en el archivo original. Los archivos relacionados deben estar disponibles; se informarán las exclusiones antes de publicar.";
        }
    }

    private async Task ElegirArchivoAsync()
    {
        if (ocupado) return;
        using var archivo = new WinForms.OpenFileDialog
        {
            Title = "Elegir una base MYG o Delphin para publicar",
            Filter = "Base de datos SQLite (*.sqlite)|*.sqlite", CheckFileExists = true, Multiselect = false
        };
        if (archivo.ShowDialog(this) != WinForms.DialogResult.OK) return;
        await EjecutarAsync(async () =>
        {
            string seleccionada = Path.GetFullPath(archivo.FileName);
            List<MYGProyectoResumen> lista = await Task.Run(() => MYGBaseDatos.ListarProyectos(seleccionada));
            if (lista.Count == 0) throw new InvalidOperationException(
                "La base no contiene obras. Cree un proyecto vacío o elija una base que contenga al menos una obra.");
            rutaCargada = seleccionada; ruta.Text = seleccionada;
            proyectos.DataSource = lista;
            if (string.IsNullOrWhiteSpace(nombre.Text) && proyectos.SelectedItem is MYGProyectoResumen p)
                nombre.Text = p.Nombre;
            confirmarBase.Checked = false;
        });
    }

    private async Task AceptarAsync()
    {
        if (ocupado) return;
        await EjecutarAsync(async () =>
        {
            string texto = nombre.Text.Trim();
            if (texto.Length == 0 || texto.Length > 200)
                throw new InvalidOperationException("Introduzca un nombre de proyecto de hasta 200 caracteres.");
            if (modo.SelectedIndex == 0)
            {
                if (actual is null || string.IsNullOrWhiteSpace(rutaActual) || !File.Exists(rutaActual))
                    throw new InvalidOperationException("Abra y guarde una obra local, o elija una base SQLite.");
                Documento = MYGProyectoStorage.Copia(actual); RutaSQLite = rutaActual;
            }
            else if (modo.SelectedIndex == 1)
            {
                Documento = MYGProyectoStorage.Nuevo(texto); RutaSQLite = null;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(rutaCargada) || proyectos.SelectedItem is not MYGProyectoResumen proyecto)
                    throw new InvalidOperationException("Elija una base SQLite y su obra principal.");
                if (modo.SelectedIndex == 3 && !confirmarBase.Checked)
                    throw new InvalidOperationException("Confirme que desea compartir todas las obras y catálogos de esta base.");
                string fuente = rutaCargada;
                Documento = await Task.Run(() => MYGBaseDatos.LeerProyecto(fuente, proyecto.Id));
                RutaSQLite = fuente;
            }
            Nombre = texto; Alcance = modo.SelectedIndex == 3 ? "base" : "obra";
            CrearVacia = modo.SelectedIndex == 1;
            // Se cierra después de liberar el estado ocupado para permitir FormClosing.
        });
        if (Documento is not null && Nombre.Length > 0)
            DialogResult = WinForms.DialogResult.OK;
    }

    private async Task EjecutarAsync(Func<Task> accion)
    {
        ocupado = true; modo.Enabled = nombre.Enabled = publicar.Enabled = false; ActualizarModo();
        try { await accion(); }
        catch (Exception ex) { Documento = null; Nombre = ""; MYGProyectoUI.Error(this, ex); }
        finally
        {
            ocupado = false; modo.Enabled = nombre.Enabled = publicar.Enabled = true; ActualizarModo();
        }
    }
}
