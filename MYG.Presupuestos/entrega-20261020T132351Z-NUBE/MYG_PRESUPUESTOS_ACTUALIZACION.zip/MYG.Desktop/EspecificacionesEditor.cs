using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

// Editor integrado: el documento sigue siendo RTF y pertenece a la partida activa.
internal sealed partial class MYGEspecificacionesEditor : UserControl
{
    private readonly RichTextBox documento;
    private readonly Font fuentePredeterminada;
    private readonly MYGEspecificacionesVistaOscura vistaOscura;
    private bool temaPreparado, aplicandoTema;
    private readonly Action antes, cambiado;
    private readonly Func<string> titulo, unidad, codigo;
    private readonly Action guardarProyecto;
    private readonly Action confirmarGuardado;
    private bool modoExportacion;
    private Action guardarExportacion;
    private readonly TabControl cinta = new() { Name = "espec_cinta", Dock = DockStyle.Fill };
    private readonly Panel zonaCinta = new() { Dock = DockStyle.Top, Height = 170 };
    private readonly MYGEspecificacionesLienzo lienzo = new() { Name = "espec_lienzo", Dock = DockStyle.Fill, AutoScroll = true };
    private readonly Panel papel = new() { Name = "espec_papel", BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
    private readonly MYGEspecificacionesRegla regla = new() { Name = "espec_regla_horizontal", Dock = DockStyle.Top, Height = 25 };
    private readonly MYGEspecificacionesRegla reglaVertical = new(true) { Name = "espec_regla_vertical", Dock = DockStyle.Left, Width = 25 };
    private readonly MYGEspecificacionesCabecera cabecera;
    private readonly Panel barraTitulo = new() { Name = "espec_barra_titulo", Dock = DockStyle.Bottom, Height = 36, BackColor = Color.White };
    private readonly Button insertarTitulo = new MYG2027_BotonComercial { Name = "espec_insertar_titulo", Text = "Insertar título", Width = 107, Height = 26, Anchor = AnchorStyles.Bottom | AnchorStyles.Right };
    private readonly Label estado = new() { Dock = DockStyle.Bottom, Height = 24, TextAlign = ContentAlignment.MiddleLeft, Padding = new(7, 0, 0, 0) };
    private readonly ToolStripComboBox fuentes = new() { Name = "espec_fuente", AutoSize = false, Width = 160, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ToolStripComboBox tamanos = new() { Name = "espec_tamano", AutoSize = false, Width = 62 };
    private readonly NumericUpDown zoom = new() { Name = "espec_zoom", Minimum = 25, Maximum = 300, Value = 100, Width = 68 };
    private readonly List<MYGEspecificacionesRueda> ruedas = new();
    private readonly MYGEspecificacionesZoom zoomSuave = new();
    private readonly System.Windows.Forms.Timer animacionZoom = new() { Interval = 15 };
    private readonly System.Diagnostics.Stopwatch relojZoom = System.Diagnostics.Stopwatch.StartNew();
    private Point anclaZoom;
    private PointF puntoHojaZoom;
    private bool sincronizandoZoom;
    private readonly CheckBox verRegla = new() { Name = "espec_regla", Text = "Regla horizontal", Checked = true, AutoSize = true };
    private readonly CheckBox ajustar = new() { Text = "Ajustar al ancho", Checked = true, AutoSize = true };
    private ToolStripButton negrita, cursiva, subrayado;
    private ToolStrip accesosRapidos;
    private bool mostrarMarcas;
    private MYGPaginaEspecificacion pagina = new();
    private MYGPaginaEspecificacion paginaAntesArrastre;
    private Point scrollAntesArrastre;
    private int inicioAntesArrastre, longitudAntesArrastre;
    private readonly Stack<MYGPaginaEspecificacion> paginasAntes = new(), paginasDespues = new();
    private bool cargando, ejecutando, actualizandoFuente, actualizandoVista, borrador;
    private string identidad;
    private string entradaRtf, entradaTexto, documentoCargado;
    private bool tituloInicialSinEditar;
    private string tituloInicialCargado;

    internal RichTextBox Documento => documento;
    internal bool TemaPreparado => temaPreparado;
    internal bool ZoomEnCurso => animacionZoom.Enabled;
    internal void ActualizarIdentificacion()
    {
        cabecera.Actualizar();
        if (!tituloInicialSinEditar || cargando || string.IsNullOrEmpty(identidad) || TextoTitulo() == tituloInicialCargado) return;
        cargando = true;
        try
        {
            // El encabezado provisional sigue los datos de la partida mientras
            // no se haya editado; actualizarlo no guarda una especificación.
            documento.Clear(); InsertarContenidoTitulo(); documento.ClearUndo();
            tituloInicialCargado = TextoTitulo(); documentoCargado = DocumentoRtf;
            ActualizarFuente(); ActualizarEstado();
        }
        finally { cargando = false; }
    }
    internal string DocumentoRtf => MYGEspecificacionesPagina.Guardar(anotaciones?.Guardar(documento.Rtf) ?? documento.Rtf, pagina);
    internal PageSettings PaginaImpresion => ConfiguracionImpresion();
    internal MYGPaginaEspecificacion PaginaDocumento => MYGEspecificacionesPagina.Leer(DocumentoRtf);
    internal string RtfParaArchivo => MYGEspecificacionesPagina.Guardar(anotaciones.Guardar(
        MYGEspecificacionesDocumento.RtfConPagina(documento, ConfiguracionImpresion(), pagina.Encabezado, pagina.Pie, pagina.NumerarPaginas)), pagina);

    internal MYGEspecificacionesEditor(RichTextBox documento, Action antes, Action cambiado,
        Func<string> titulo, Func<string> unidad, Func<string> codigo, Func<string> presupuesto = null, Action guardarProyecto = null,
        Func<string, IReadOnlyList<MYGErrorOrtografico>> comprobarOrtografia = null,
        Func<string, IReadOnlyList<string>> sugerirOrtografia = null, Action<string> agregarOrtografia = null,
        Action confirmarGuardado = null)
    {
        this.documento = documento; this.antes = antes; this.cambiado = cambiado;
        fuentePredeterminada = MYGEspecificacionesFormato.CrearFuenteReferencia();
        // Font sólo se asigna al control vacío: RichTextBox aplica el setter a
        // todo el contenido cuando ya existe texto con formato explícito.
        if (documento.TextLength == 0) documento.Font = fuentePredeterminada;
        vistaOscura = new MYGEspecificacionesVistaOscura(documento);
        this.titulo = titulo; this.unidad = unidad; this.codigo = codigo;
        this.guardarProyecto = guardarProyecto;
        this.confirmarGuardado = confirmarGuardado;
        cabecera = new MYGEspecificacionesCabecera(presupuesto ?? (() => "PRESUPUESTO"), codigo, titulo,
            () => Intentar(() => Guardar(true)), () => Intentar(() => Imprimir(false)));
        Dock = DockStyle.Fill; MinimumSize = new(320, 200);
        documento.Name = "espec_documento";
        documento.Dock = DockStyle.None; documento.BorderStyle = BorderStyle.None;
        documento.ScrollBars = RichTextBoxScrollBars.Vertical; documento.WordWrap = true;
        documento.HideSelection = false; documento.AcceptsTab = true;
        documento.ReadOnly = true;
        MYGEspecificacionesFormato.EstablecerFuentePredeterminada(documento, FuenteReferencia());
        if (documento.TextLength == 0)
            MYGEspecificacionesFormato.EstablecerFuente(documento, FuenteReferencia(), 11);
        papel.Controls.Add(documento); lienzo.Controls.Add(papel);
        // AutoScrollPosition mueve el papel incluso sin emitir Scroll. El
        // recorte visible de RichEdit cambia y necesita un cuadro nuevo completo.
        papel.LocationChanged += (_, _) => { ActualizarOrigenReglas(); documento.Invalidate(); };
        var superficie = new Panel { Dock = DockStyle.Fill, Padding = new(0), BackColor = MYG2027_TemaComercial.Fondo };
        superficie.Controls.Add(lienzo); superficie.Controls.Add(reglaVertical); superficie.Controls.Add(regla);
        zonaCinta.Controls.Add(cinta);
        barraTitulo.Controls.Add(insertarTitulo);
        barraTitulo.SizeChanged += (_, _) => insertarTitulo.Location = new(Math.Max(0, barraTitulo.ClientSize.Width - insertarTitulo.Width - 10), 6);
        insertarTitulo.Click += (_, _) => Intentar(InsertarTitulo);
        insertarTitulo.Enabled = false;
        MYG2027_TemaComercial.EstilizarBoton(insertarTitulo);
        MYGAnimacionUI.PrepararBoton(insertarTitulo);
        Controls.Add(superficie); Controls.Add(barraTitulo); Controls.Add(zonaCinta); Controls.Add(cabecera);

        PrepararCintaReferencia();
        PrepararArrastreMargenes(regla, true);
        PrepararArrastreMargenes(reglaVertical, false);
        cinta.SelectedIndex = 1;
        verRegla.CheckedChanged += (_, _) => { regla.Visible = verRegla.Checked; ActualizarVista(); };
        zoom.ValueChanged += (_, _) =>
        {
            if (actualizandoVista || sincronizandoZoom) return;
            CancelarArrastreMargenes();
            animacionZoom.Stop();
            zoomSuave.SetImmediate((double)zoom.Value);
            // Evitar un segundo layout por el CheckedChanged de Ajustar al ancho.
            actualizandoVista = true;
            try { ajustar.Checked = false; }
            finally { actualizandoVista = false; }
            ActualizarVista();
        };
        animacionZoom.Tick += (_, _) =>
        {
            if (!Visible || IsDisposed || documento.IsDisposed) { DetenerZoom(); return; }
            zoomSuave.Advance(relojZoom.Elapsed.TotalSeconds);
            ActualizarVista();
            if (!zoomSuave.Active) animacionZoom.Stop();
        };
        VisibleChanged += (_, _) => { if (!Visible && !Disposing && !IsDisposed) DetenerZoom(); };
        ajustar.CheckedChanged += (_, _) => ActualizarVista();
        lienzo.SizeChanged += (_, _) => ActualizarVista();
        lienzo.Scroll += (_, _) =>
        {
            if (!actualizandoVista) DetenerZoom();
            ActualizarOrigenReglas();
            lienzo.Invalidate();
            documento.Invalidate();
        };
        documento.SelectionChanged += (_, _) => { ActualizarFuente(); ActualizarEstado(); };
        documento.TextChanged += (_, _) => { if (!cargando && !ejecutando && EdicionNubePermitida) NotificarCambio(); ActualizarEstado(); };
        documento.KeyDown += DocumentoKeyDown;
        foreach (Control control in new Control[] { documento, papel, lienzo, regla, reglaVertical })
            ruedas.Add(new MYGEspecificacionesRueda(control, MoverRueda));
        documento.Enter += (_, _) => { if (!cargando && !ejecutando && dialogosEdicion == 0 && !documento.ReadOnly && EdicionNubePermitida) Intentar(antes); };
        PrepararEdicionContextual(comprobarOrtografia, sugerirOrtografia, agregarOrtografia);
        temaPreparado = true;
        MYG2027_TemaComercial.CambioTema += CambioTema;
        AplicarTema(); ActualizarVista();
    }

    internal void Cargar(string nuevaIdentidad, string rtf, string texto, bool insertarTituloInicial = false)
    {
        CancelarArrastreMargenes();
        cabecera.Actualizar(); insertarTitulo.Enabled = EdicionNubePermitida && !string.IsNullOrEmpty(nuevaIdentidad);
        if (!EdicionNubePermitida) documento.ReadOnly = true;
        rtf ??= ""; texto ??= "";
        bool generarTitulo = insertarTituloInicial && !string.IsNullOrEmpty(nuevaIdentidad) &&
            string.IsNullOrWhiteSpace(rtf) && string.IsNullOrWhiteSpace(texto);
        if (identidad == nuevaIdentidad &&
            (!generarTitulo || tituloInicialSinEditar && tituloInicialCargado == TextoTitulo()) &&
            ((rtf == entradaRtf && texto == entradaTexto && DocumentoRtf == documentoCargado) ||
                (rtf.Length > 0 ? DocumentoRtf == rtf : documento.Text == texto))) return;
        DetenerZoom();
        cargando = true;
        try
        {
            identidad = nuevaIdentidad;
            pagina = string.IsNullOrWhiteSpace(rtf) && string.IsNullOrWhiteSpace(texto)
                ? new MYGPaginaEspecificacion { MargenIzquierdoMm = 20, MargenDerechoMm = 20, MargenSuperiorMm = 20, MargenInferiorMm = 20 }
                : MYGEspecificacionesPagina.Leer(rtf);
            paginasAntes.Clear(); paginasDespues.Clear();
            if (rtf.Length > 0)
            {
                try { documento.Rtf = MYGEspecificacionesPagina.QuitarMetadatos(rtf); }
                catch (ArgumentException) { CargarTextoPredeterminado(documento, texto); }
            }
            else CargarTextoPredeterminado(documento, texto);
            tituloInicialSinEditar = generarTitulo;
            tituloInicialCargado = generarTitulo ? TextoTitulo() : null;
            if (generarTitulo) InsertarContenidoTitulo();
            MYGEspecificacionesFormato.EstablecerFuentePredeterminada(documento, FuenteReferencia());
            NormalizarParrafosVaciosHeredados();
            anotaciones.Leer(rtf);
            documento.ClearUndo(); documento.Select(generarTitulo ? documento.TextLength : 0, 0);
            documento.ReadOnly = !EdicionNubePermitida || string.IsNullOrEmpty(nuevaIdentidad);
            ortografia.ReiniciarDocumento();
            ActualizarFuente(); ActualizarVista();
            entradaRtf = rtf; entradaTexto = texto; documentoCargado = DocumentoRtf;
        }
        finally { cargando = false; }
    }

    private void CargarTextoPredeterminado(RichTextBox destino, string texto)
    {
        destino.Clear();
        MYGEspecificacionesFormato.EstablecerFuentePredeterminada(destino, FuenteReferencia());
        destino.Text = texto;
        destino.SelectAll();
        MYGEspecificacionesFormato.LimpiarFormato(destino);
        MYGEspecificacionesFormato.EstablecerFuente(destino, FuenteReferencia(), 11);
        destino.Select(0, 0);
    }

    private void NormalizarParrafosVaciosHeredados()
    {
        string texto = documento.Text;
        int inicio = 0;
        while (inicio <= texto.Length)
        {
            int salto = texto.IndexOf('\n', inicio), fin = salto < 0 ? texto.Length : salto;
            if (string.IsNullOrWhiteSpace(texto.Substring(inicio, fin - inicio)))
            {
                documento.Select(inicio, fin > inicio ? fin - inicio : salto >= 0 ? 1 : 0);
                using var fuente = documento.SelectionFont;
                // Corregir únicamente el default heredado de las versiones que
                // usaban Arial 11/HFONT; los formatos elegidos se conservan.
                if (fuente != null && fuente.Name.Equals("Arial", StringComparison.OrdinalIgnoreCase) &&
                    fuente.Style == FontStyle.Regular && fuente.SizeInPoints >= 10.99f && fuente.SizeInPoints <= 11.51f)
                {
                    MYGEspecificacionesFormato.EstablecerFuente(documento, FuenteReferencia(), 11);
                    if (salto < 0)
                        MYGEspecificacionesFormato.EstablecerFuenteParrafoFinal(documento, FuenteReferencia(), 11);
                }
            }
            if (salto < 0) break;
            inicio = salto + 1;
        }
    }

    // Vista de salida independiente; los cambios pertenecen a la copia exportable.
    internal void PrepararExportacion(Action volverAlProyecto, Action guardarComo)
    {
        modoExportacion = true; guardarExportacion = guardarComo;
        cabecera.Visible = false; barraTitulo.Visible = false; accesosRapidos.Visible = false;
        var fichero = (FlowLayoutPanel)cinta.TabPages[0].Controls[0];
        foreach (Control grupo in fichero.Controls.Cast<Control>().ToArray()) grupo.Dispose();
        var navegar = MYGEspecificacionesCinta.Grupo(fichero, "Navegar", 77);
        var volver = Icono("Volver al\nproyecto", volverAlProyecto, "deshacer", 36, true, "espec_volver_proyecto");
        var retorno = new Bitmap(36, 36);
        using (var g = Graphics.FromImage(retorno))
        using (var p = new Pen(Color.FromArgb(255, 152, 0), 3))
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.DrawEllipse(p, 3, 3, 30, 30); g.DrawLine(p, 10, 18, 26, 18);
            g.DrawLines(p, new[] { new Point(18, 10), new Point(10, 18), new Point(18, 26) });
        }
        volver.Image = retorno; volver.Disposed += (_, _) => retorno.Dispose();
        MYGEspecificacionesCinta.Fila(navegar, 8, volver);
        var comun = MYGEspecificacionesCinta.Grupo(fichero, "Común", 191);
        var guardar = Icono("Guardar\ncomo", guardarComo, "guardar_como", 32, true, "espec_exportacion_guardar");
        guardar.AccessibleName = "Guardar como";
        MYGEspecificacionesCinta.Fila(comun, 8, Icono("Abrir", Abrir, "abrir", 32, true), guardar,
            Icono("Imprimir", () => Imprimir(false), "imprimir", 32, true));
        var ortografia = MYGEspecificacionesCinta.Grupo(fichero, "Comprobar ortografía", 99);
        MYGEspecificacionesCinta.Fila(ortografia, 8, Icono("Comprobar\nortografía", ComprobarOrtografia, "ortografia", 32, true));
        ajustar.Checked = false; zoom.Value = 94;
        cinta.SelectedIndex = 0; ActualizarVista(); AplicarTema();
    }

    // También se guarda al cambiar sólo un formato: RichEdit no siempre emite TextChanged.
    internal void AplicarFormato(Action accion)
    {
        CancelarArrastreMargenes();
        if (cargando || documento.ReadOnly || !EdicionNubePermitida) return;
        ejecutando = true;
        try
        {
            documento.Focus(); antes(); accion(); NotificarCambio();
            ActualizarFuente(); ActualizarEstado();
            documento.Invalidate();
        }
        finally { ejecutando = false; }
    }
    private void NotificarCambio()
    {
        if (!EdicionNubePermitida) return;
        if (regla.Arrastrando || reglaVertical.Arrastrando)
        {
            // WM_CHAR también puede llegar sin KeyDown. Conservar el cursor
            // posterior a esa edición, pero descartar el margen provisional.
            int inicio = documento.SelectionStart, longitud = documento.SelectionLength;
            CancelarArrastreMargenes();
            documento.Select(inicio, longitud);
        }
        tituloInicialSinEditar = false;
        cambiado();
        entradaRtf = documentoCargado = DocumentoRtf; entradaTexto = documento.Text;
    }

    internal void AplicarTema()
    {
        if (!temaPreparado || aplicandoTema || IsDisposed || Disposing) return;
        aplicandoTema = true;
        try
        {
            BackColor = MYG2027_TemaComercial.Fondo;
            zonaCinta.BackColor = BackColor;
            zonaCinta.ForeColor = MYG2027_TemaComercial.Texto;
            MYGTemaNativo.Aplicar(lienzo);
            MYGTemaNativo.Aplicar(documento);
            MYGEspecificacionesCinta.AplicarTema(cinta);
            AplicarTemaMenuDocumento();
            cabecera.AplicarPaleta();
            lienzo.BackColor = MYG2027_TemaComercial.Fondo;
            if (lienzo.Parent != null) lienzo.Parent.BackColor = BackColor;
            regla.BackColor = reglaVertical.BackColor = MYG2027_TemaComercial.Fondo;
            regla.ForeColor = reglaVertical.ForeColor = MYG2027_TemaComercial.Secundario;
            barraTitulo.BackColor = MYG2027_TemaComercial.SuperficieAlterna;
            MYG2027_TemaComercial.EstilizarBoton(insertarTitulo);
            if (accesosRapidos != null)
            {
                MYGEspecificacionesCinta.AplicarTema(accesosRapidos);
                accesosRapidos.BackColor = MYG2027_TemaComercial.Superficie;
            }
            // El fondo nativo y el papel siguen la paleta; la tinta se adapta
            // exclusivamente al dibujar, conservando sus colores en el RTF.
            vistaOscura.AplicarTema();
            papel.BackColor = documento.BackColor;
            regla.Invalidate(); reglaVertical.Invalidate(); lienzo.Invalidate(true);
        }
        finally { aplicandoTema = false; }
    }

    private void CambioTema(object sender, EventArgs e)
    {
        if (!IsDisposed && !Disposing) AplicarTema();
    }

    private void PrepararCintaReferencia()
    {
        MYGEspecificacionesCinta.Preparar(cinta);
        var fichero = MYGEspecificacionesCinta.Pagina(cinta, "Fichero");
        var archivos = MYGEspecificacionesCinta.Grupo(fichero, "Archivo", 410);
        MYGEspecificacionesCinta.Fila(archivos, 10,
            Icono("Nuevo", Nuevo, "nuevo", 32, true), Icono("Abrir", Abrir, "abrir", 32, true),
            Icono("Guardar", GuardarProyecto, "guardar", 32, true), Icono("Guardar como", () => Guardar(false), "guardar_como", 32, true),
            Icono("Guardar en\nbase de datos", GuardarProyecto, "guardar_como", 32, true), Icono("Imprimir", () => Imprimir(false), "imprimir", 32, true));
        var ortografia = MYGEspecificacionesCinta.Grupo(fichero, "Comprobación", 92);
        MYGEspecificacionesCinta.Fila(ortografia, 10, Icono("Comprobar\nortografía", ComprobarOrtografia, "ortografia", 32, true));

        var inicio = MYGEspecificacionesCinta.Pagina(cinta, "Inicio");
        var portapapeles = MYGEspecificacionesCinta.Grupo(inicio, "Portapapeles", 99);
        var pegar = MYGEspecificacionesCinta.Fila(portapapeles, 6, Icono("Pegar", () => AplicarFormato(documento.Paste), "pegar", 36, true));
        pegar.Left = 6; pegar.Width = 49;
        var cortar = MYGEspecificacionesCinta.Fila(portapapeles, 6, Icono("Cortar", () => { if (documento.SelectionLength > 0) AplicarFormato(documento.Cut); }, "cortar"));
        cortar.Left = 60; cortar.Width = 30;
        var copiar = MYGEspecificacionesCinta.Fila(portapapeles, 31, Icono("Copiar", documento.Copy, "copiar"));
        copiar.Left = 60; copiar.Width = 30;
        var especial = MYGEspecificacionesCinta.Fila(portapapeles, 56, Icono("Pegado especial", PegarEspecial, "pegar"));
        especial.Left = 60; especial.Width = 30;
        var acciones = MYGEspecificacionesCinta.Grupo(inicio, "Acciones", 78);
        var deshacer = MYGEspecificacionesCinta.Fila(acciones, 10, Icono("Deshacer texto", () => { if (documento.CanUndo) AplicarFormato(documento.Undo); }, "deshacer"));
        deshacer.Left = 23; deshacer.Width = 33;
        var rehacer = MYGEspecificacionesCinta.Fila(acciones, 48, Icono("Rehacer texto", () => { if (documento.CanRedo) AplicarFormato(documento.Redo); }, "rehacer"));
        rehacer.Left = 23; rehacer.Width = 33;

        using (var instaladas = new System.Drawing.Text.InstalledFontCollection())
            fuentes.Items.AddRange(instaladas.Families.Select(f => (object)f.Name).OrderBy(x => x).ToArray());
        fuentes.SelectedItem = documento.Font.Name;
        tamanos.Items.AddRange(new object[] { "8", "9", "10", "11", "12", "14", "16", "18", "20", "24", "28", "36", "48", "72" });
        tamanos.Text = "11";
        fuentes.SelectedIndexChanged += (_, _) =>
        {
            if (!actualizandoFuente && fuentes.SelectedItem != null)
                Intentar(() => AplicarFormato(() => MYGEspecificacionesFormato.EstablecerFuente(documento, fuentes.Text, null)));
        };
        tamanos.ComboBox.SelectionChangeCommitted += (_, _) => AplicarTamano();
        tamanos.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { AplicarTamano(); e.SuppressKeyPress = true; } };
        var fuente = MYGEspecificacionesCinta.Grupo(inicio, "Fuente", 402);
        var mayusculas = new ToolStripDropDownButton("Aa") { ForeColor = MYG2027_TemaComercial.Secundario };
        mayusculas.Alignment = ToolStripItemAlignment.Right;
        foreach (string modo in new[] { "MAYÚSCULAS", "minúsculas", "Tipo título" })
            mayusculas.DropDownItems.Add(modo, null, (_, _) => Intentar(() => CambiarMayusculas(modo)));
        var primera = MYGEspecificacionesCinta.Fila(fuente, 10, fuentes, tamanos,
            Icono("Aumentar tamaño", () => CambiarTamano(1), "aumentar_fuente"),
            Icono("Reducir tamaño", () => CambiarTamano(-1), "reducir_fuente"), mayusculas);
        primera.Left = 12; primera.Width = 384;
        negrita = Boton("B", () => Estilo(FontStyle.Bold), "espec_negrita", "Negrita (Ctrl+B)");
        cursiva = Boton("I", () => Estilo(FontStyle.Italic), "espec_cursiva", "Cursiva (Ctrl+I)");
        subrayado = Boton("U", () => Estilo(FontStyle.Underline), "espec_subrayado", "Subrayado (Ctrl+U)");
        negrita.Font = new("Arial", 11, FontStyle.Bold); cursiva.Font = new("Arial", 11, FontStyle.Italic); subrayado.Font = new("Arial", 11, FontStyle.Underline);
        var doble = Boton("U̲", () => AplicarFormato(() => MYGEspecificacionesFormato.SubrayadoDoble(documento)), ayuda: "Subrayado doble");
        doble.Font = new("Arial", 11, FontStyle.Underline);
        var tachado = Boton("S", () => Estilo(FontStyle.Strikeout), ayuda: "Tachado"); tachado.Font = new("Arial", 11, FontStyle.Strikeout);
        var tachadoDoble = Boton("S̶", () => { }, ayuda: "Tachado doble: disponible al editar con Microsoft Word");
        tachadoDoble.Enabled = false;
        var segunda = MYGEspecificacionesCinta.Fila(fuente, 48, negrita, cursiva, subrayado, doble, tachado, tachadoDoble,
            Boton("X²", () => AplicarFormato(() => MYGEspecificacionesFormato.PosicionCaracter(documento, 1)), ayuda: "Superíndice"),
            Boton("X₂", () => AplicarFormato(() => MYGEspecificacionesFormato.PosicionCaracter(documento, -1)), ayuda: "Subíndice"),
            MenuColor(false), MenuColor(true), Icono("Limpiar formato", () => AplicarFormato(() => MYGEspecificacionesFormato.LimpiarFormato(documento)), "borrar_formato"));
        for (int i = 0; i < segunda.Items.Count; i++)
        {
            segunda.Items[i].AutoSize = false;
            segunda.Items[i].Size = new(i == 8 ? 42 : i == 9 ? 52 : 27, 28);
        }
        segunda.Height = 32;
        segunda.Left = 12; segunda.Width = 384;
        var parrafo = MYGEspecificacionesCinta.Grupo(inicio, "Párrafo", 220);
        MYGEspecificacionesCinta.Fila(parrafo, 4,
            Icono("Viñetas", () => AplicarFormato(() => MYGEspecificacionesFormato.Lista(documento, false)), "vinyetas"),
            Icono("Numeración", () => AplicarFormato(() => MYGEspecificacionesFormato.Lista(documento, true)), "numeracion"),
            Icono("Lista multinivel", () => AplicarFormato(() => { MYGEspecificacionesFormato.Lista(documento, true); MYGEspecificacionesFormato.Sangria(documento, 360); }), "multinivel"),
            Icono("Reducir sangría", () => AplicarFormato(() => MYGEspecificacionesFormato.Sangria(documento, -360)), "sangria_menos"),
            Icono("Aumentar sangría", () => AplicarFormato(() => MYGEspecificacionesFormato.Sangria(documento, 360)), "sangria_mas"),
            Icono("Mostrar marcas de formato", AlternarMarcas, "parrafo"));
        MYGEspecificacionesCinta.Fila(parrafo, 30,
            Icono("Izquierda", () => Alinear(1), "izquierda"), Icono("Centrar", () => Alinear(3), "centro"),
            Icono("Derecha", () => Alinear(2), "derecha"), Icono("Justificar", () => Alinear(4), "justificar"));
        var interlineado = MenuInterlineado(); MYGEspecificacionesCinta.Icono(interlineado, "interlineado");
        var fondo = MenuColor(true); MYGEspecificacionesCinta.Icono(fondo, "color_fondo");
        MYGEspecificacionesCinta.Fila(parrafo, 59, interlineado, fondo);
        var estilos = MYGEspecificacionesCinta.Grupo(inicio, "", 68); estilos.Name = "espec_grupo_Estilos";
        var menuEstilos = MenuEstilos(); MYGEspecificacionesCinta.Icono(menuEstilos, "estilos", 32, true);
        MYGEspecificacionesCinta.Fila(estilos, 7, menuEstilos);
        var edicion = MYGEspecificacionesCinta.Grupo(inicio, "Edición", 52);
        MYGEspecificacionesCinta.Fila(edicion, 12, Icono("Buscar", Buscar, "buscar"));
        MYGEspecificacionesCinta.Fila(edicion, 52, Icono("Reemplazar", Buscar, "reemplazar"));

        var insertar = MYGEspecificacionesCinta.Pagina(cinta, "Insertar");
        var paginas = MYGEspecificacionesCinta.Grupo(insertar, "Páginas", 77);
        MYGEspecificacionesCinta.Fila(paginas, 8, Icono("Salto de\npágina", () => AplicarFormato(() => MYGEspecificacionesDocumento.InsertarSaltoPagina(documento)), "salto", 30, true));
        var tablas = MYGEspecificacionesCinta.Grupo(insertar, "Tablas", 64);
        MYGEspecificacionesCinta.Fila(tablas, 8, Icono("Tabla", InsertarTabla, "tabla", 30, true));
        var ilustraciones = MYGEspecificacionesCinta.Grupo(insertar, "Ilustraciones", 196);
        MYGEspecificacionesCinta.Fila(ilustraciones, 8, Icono("Insertar\nimagen", InsertarImagenPortapapeles, "imagen", 30, true),
            Icono("Insertar imagen\ndesde fichero", InsertarImagen, "imagen", 30, true));
        var encabezados = MYGEspecificacionesCinta.Grupo(insertar, "Encabezados y pies", 250);
        MYGEspecificacionesCinta.Fila(encabezados, 8, Icono("Cabecera", EncabezadoPie, "encabezado", 30, true),
            Icono("Pie", EncabezadoPie, "pie", 30, true), Icono("Insertar número\nde página", () => CambiarPagina(() => pagina.NumerarPaginas = !pagina.NumerarPaginas), "lineas", 30, true, "espec_Número de página"));
        var simbolos = MYGEspecificacionesCinta.Grupo(insertar, "Símbolos", 185);
        MYGEspecificacionesCinta.Fila(simbolos, 8, Icono("Texto", InsertarPlantilla, "estilos", 30, true, "espec_plantilla"),
            Icono("Insertar\nsímbolo", InsertarSimbolo, "simbolo", 30, true));

        var diseno = MYGEspecificacionesCinta.Pagina(cinta, "Distribución de Página");
        var configurar = MYGEspecificacionesCinta.Grupo(diseno, "Configurar página", 490);
        var orientacion = new ToolStripDropDownButton("Orientación");
        orientacion.DropDownItems.Add(Elemento("Vertical", () => CambiarPagina(() => pagina.Horizontal = false)));
        orientacion.DropDownItems.Add(Elemento("Horizontal", () => CambiarPagina(() => pagina.Horizontal = true)));
        MYGEspecificacionesCinta.Icono(orientacion, "orientacion", 30, true);
        var tamano = new ToolStripDropDownButton("Tamaño");
        tamano.DropDownItems.Add(Elemento("A4", () => CambiarPagina(() => { pagina.AnchoMm = 210; pagina.AltoMm = 297; })));
        tamano.DropDownItems.Add(Elemento("Carta", () => CambiarPagina(() => { pagina.AnchoMm = 215.9m; pagina.AltoMm = 279.4m; })));
        tamano.DropDownItems.Add(Elemento("Oficio", () => CambiarPagina(() => { pagina.AnchoMm = 215.9m; pagina.AltoMm = 355.6m; })));
        MYGEspecificacionesCinta.Icono(tamano, "tamano", 30, true);
        var columnas = Icono("Columnas", () => { }, "columnas", 30, true); columnas.Enabled = false; columnas.ToolTipText = "El editor RTF trabaja en una columna. Para columnas avanzadas utilice Word.";
        MYGEspecificacionesCinta.Fila(configurar, 8, Icono("Márgenes", Margenes, "margenes", 30, true), orientacion, tamano, columnas,
            Icono("Saltos", () => AplicarFormato(() => MYGEspecificacionesDocumento.InsertarSaltoPagina(documento)), "salto", 30, true),
            Icono("Números\nde línea", AlternarNumerosLinea, "lineas", 30, true), Icono("Color de\npágina", ColorPapel, "color_pagina", 30, true));
        var historial = MYGEspecificacionesCinta.Grupo(diseno, "Diseño", 178);
        MYGEspecificacionesCinta.Fila(historial, 12, Icono("Deshacer diseño", () => HistorialPagina(false), "deshacer", 24, true),
            Icono("Rehacer diseño", () => HistorialPagina(true), "rehacer", 24, true));

        var vista = MYGEspecificacionesCinta.Pagina(cinta, "Vista");
        var vistas = MYGEspecificacionesCinta.Grupo(vista, "Vistas de documento", 247);
        MYGEspecificacionesCinta.Fila(vistas, 8, Icono("Vista\nsimple", () => { borrador = true; ActualizarVista(); }, "pagina", 30, true),
            Icono("Vista\nborrador", () => { borrador = true; ActualizarVista(); }, "pagina", 30, true),
            Icono("Distribución\nde impresión", () => { borrador = false; ActualizarVista(); }, "pagina", 30, true));
        var mostrar = MYGEspecificacionesCinta.Grupo(vista, "Mostrar", 140);
        var horizontal = Icono("Regla\nhorizontal", () => verRegla.Checked = !verRegla.Checked, "regla", 30, true);
        var vertical = Icono("Regla\nvertical", () => { reglaVertical.Visible = !reglaVertical.Visible; ActualizarVista(); }, "regla", 30, true);
        horizontal.Checked = vertical.Checked = true;
        verRegla.CheckedChanged += (_, _) => horizontal.Checked = verRegla.Checked;
        reglaVertical.VisibleChanged += (_, _) => vertical.Checked = reglaVertical.Visible;
        MYGEspecificacionesCinta.Fila(mostrar, 8, horizontal, vertical);
        verRegla.Visible = false; mostrar.Controls.Add(verRegla);
        var ampliacion = MYGEspecificacionesCinta.Grupo(vista, "Ampliación", 275);
        MYGEspecificacionesCinta.Fila(ampliacion, 8, Icono("Alejar", () => zoom.Value = Math.Max(zoom.Minimum, zoom.Value - 10), "zoom_menos", 24, true),
            Icono("Acercar", () => zoom.Value = Math.Min(zoom.Maximum, zoom.Value + 10), "zoom_mas", 24, true),
            Icono("Vista preliminar", () => Imprimir(true), "imprimir", 24, true));
        zoom.Location = new(191, 12); zoom.Width = 65; ampliacion.Controls.Add(zoom);
        ajustar.Location = new(180, 46); ajustar.Font = new("Segoe UI", 8); ajustar.Width = 90; ajustar.Text = "Ajustar ancho"; ampliacion.Controls.Add(ajustar);

        var rapidos = new ToolStrip { Name = "espec_acceso_rapido", AutoSize = false, Size = new(62, 23), GripStyle = ToolStripGripStyle.Hidden,
            Dock = DockStyle.None, Anchor = AnchorStyles.Top | AnchorStyles.Right, Renderer = primera.Renderer, BackColor = MYG2027_TemaComercial.Superficie };
        rapidos.Items.Add(Icono("Guardar", GuardarProyecto, "guardar")); rapidos.Items.Add(Icono("Guardar en base de datos", GuardarProyecto, "guardar_como"));
        zonaCinta.Controls.Add(rapidos); rapidos.BringToFront();
        accesosRapidos = rapidos;
        zonaCinta.SizeChanged += (_, _) => rapidos.Location = new(Math.Max(0, zonaCinta.ClientSize.Width - 66), 3);
    }

    private ToolStripButton Icono(string texto, Action accion, string imagen, int tamano = 18, bool mostrarTexto = false, string nombre = null)
    {
        var b = Boton(texto, accion, nombre);
        MYGEspecificacionesCinta.Icono(b, imagen, tamano, mostrarTexto); return b;
    }
    private ToolStripMenuItem Elemento(string texto, Action accion)
    {
        var e = new ToolStripMenuItem(texto) { Name = "espec_" + texto };
        e.Click += (_, _) => Intentar(accion); return e;
    }
    private ToolStripDropDownButton MenuColor(bool fondo)
    {
        var menu = new ToolStripDropDownButton(fondo ? "Resaltar" : "Color de fuente");
        MYGEspecificacionesCinta.Icono(menu, fondo ? "resaltar" : "color_fuente");
        foreach (var opcion in new[] { (Nombre: "Negro", Color: Color.Black), (Nombre: "Rojo", Color: Color.Red), (Nombre: "Azul", Color: Color.Blue),
            (Nombre: "Verde", Color: Color.DarkGreen), (Nombre: "Amarillo", Color: Color.Yellow), (Nombre: "Blanco", Color: Color.White) })
            menu.DropDownItems.Add(Elemento(opcion.Nombre, () => AplicarFormato(() => { if (fondo) documento.SelectionBackColor = opcion.Color; else documento.SelectionColor = opcion.Color; })));
        menu.DropDownItems.Add(Elemento("Más colores…", () => ElegirColor(fondo)));
        if (fondo) menu.DropDownItems.Add(Elemento("Sin resaltado", () => AplicarFormato(() => documento.SelectionBackColor = Color.White)));
        return menu;
    }
    private void GuardarProyecto()
    {
        if (modoExportacion) guardarExportacion?.Invoke();
        else if (guardarProyecto != null)
        {
            if (documento.ReadOnly) return;
            confirmarGuardado?.Invoke();
            tituloInicialSinEditar = false;
            guardarProyecto();
        }
        else Guardar(false);
    }
    private void CambiarTamano(int sentido) => AplicarFormato(() => MYGEspecificacionesFormato.EstablecerFuente(documento, null,
        Math.Clamp((documento.SelectionFont?.SizeInPoints ?? 11) + sentido, 1, 200)));
    private void CambiarMayusculas(string modo)
    {
        if (documento.SelectionLength == 0) return;
        AplicarFormato(() => documento.SelectedText = modo == "MAYÚSCULAS" ? documento.SelectedText.ToUpper(CultureInfo.CurrentCulture) :
            modo == "minúsculas" ? documento.SelectedText.ToLower(CultureInfo.CurrentCulture) : CultureInfo.CurrentCulture.TextInfo.ToTitleCase(documento.SelectedText.ToLower(CultureInfo.CurrentCulture)));
    }
    private void PegarEspecial()
    {
        if (documento.ReadOnly) return;
        var copia = MYGEspecificacionesPegado.Capturar(Clipboard.GetDataObject());
        MYGEspecificacionesContenidoPegado contenido = null;
        SinRegistroEntrada(() => contenido = MYGEspecificacionesPegado.Mostrar(this, copia));
        if (contenido != null) AplicarFormato(() => MYGEspecificacionesPegado.Aplicar(documento, contenido));
    }
    private void InsertarImagenPortapapeles()
    {
        if (!Clipboard.ContainsImage()) { InsertarImagen(); return; }
        using var imagen = Clipboard.GetImage();
        string ruta = Path.Combine(Path.GetTempPath(), "MYG-imagen-" + Guid.NewGuid().ToString("N") + ".png");
        try { imagen.Save(ruta, System.Drawing.Imaging.ImageFormat.Png); AplicarFormato(() => MYGEspecificacionesDocumento.InsertarImagen(documento, ruta, AnchoContenidoTwips())); }
        finally { if (File.Exists(ruta)) File.Delete(ruta); }
    }
    private MYGEspecificacionesMarcas marcas;
    private void AlternarMarcas()
    {
        marcas ??= new MYGEspecificacionesMarcas(documento);
        mostrarMarcas = !mostrarMarcas; marcas.MostrarParrafos = mostrarMarcas;
    }
    private void AlternarNumerosLinea()
    {
        marcas ??= new MYGEspecificacionesMarcas(documento);
        marcas.MostrarNumeros = !marcas.MostrarNumeros;
    }
    private void ColorPapel()
    {
        using var d = new ColorDialog { Color = vistaOscura.FondoDocumento, FullOpen = true };
        if (d.ShowDialog(this) == DialogResult.OK)
        {
            vistaOscura.FondoDocumento = d.Color;
            papel.BackColor = documento.BackColor;
            documento.Invalidate();
        }
    }

    private ToolStripButton Boton(string texto, Action accion, string nombre = null, string ayuda = null)
    {
        var boton = new ToolStripButton(texto) { Name = nombre ?? "espec_" + texto, DisplayStyle = ToolStripItemDisplayStyle.Text, ToolTipText = ayuda ?? texto, AutoToolTip = false };
        boton.Click += (_, _) => Intentar(accion); return boton;
    }
    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception e) when (e is not OutOfMemoryException)
        { MessageBox.Show(this, e.Message, "Especificaciones técnicas", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
    private ToolStripDropDownButton MenuInterlineado()
    {
        var menu = new ToolStripDropDownButton("Interlineado");
        foreach (float valor in new[] { 1f, 1.15f, 1.5f, 2f })
            menu.DropDownItems.Add(valor.ToString("0.##", CultureInfo.CurrentCulture), null,
                (_, _) => Intentar(() => AplicarFormato(() => MYGEspecificacionesFormato.Interlineado(documento, valor))));
        return menu;
    }
    private ToolStripDropDownButton MenuEstilos()
    {
        var menu = new ToolStripDropDownButton("Estilos");
        foreach (var estilo in new[] { (Nombre: "Normal", Tamano: 11f, Negrita: false),
            (Nombre: "Título", Tamano: 16f, Negrita: true), (Nombre: "Subtítulo", Tamano: 13f, Negrita: false),
            (Nombre: "Encabezado", Tamano: 12f, Negrita: true) })
            menu.DropDownItems.Add(estilo.Nombre, null, (_, _) => Intentar(() => AplicarFormato(() =>
            {
                MYGEspecificacionesFormato.LimpiarFormato(documento);
                MYGEspecificacionesFormato.EstablecerFuente(documento, FuenteReferencia(), estilo.Tamano);
                if (estilo.Negrita) MYGEspecificacionesFormato.AlternarEstilo(documento, FontStyle.Bold);
            })));
        return menu;
    }
    private void Estilo(FontStyle estilo) => AplicarFormato(() => MYGEspecificacionesFormato.AlternarEstilo(documento, estilo));
    private void Alinear(int alineacion) => AplicarFormato(() => MYGEspecificacionesFormato.Alinear(documento, alineacion));
    private void AplicarTamano()
    {
        Intentar(() =>
        {
            if (!float.TryParse(tamanos.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out float tamano) || tamano < 1 || tamano > 200)
                throw new ArgumentException("El tamaño de fuente debe estar entre 1 y 200 puntos.");
            AplicarFormato(() => MYGEspecificacionesFormato.EstablecerFuente(documento, null, tamano));
        });
    }
    private void ActualizarFuente()
    {
        if (actualizandoFuente || documento.IsDisposed) return;
        actualizandoFuente = true;
        try
        {
            var f = documento.SelectionFont;
            if (f != null)
            {
                fuentes.SelectedItem = f.Name; tamanos.Text = f.SizeInPoints.ToString("0.##", CultureInfo.CurrentCulture);
            }
            else { fuentes.SelectedIndex = -1; tamanos.Text = ""; }
            negrita.Checked = MYGEspecificacionesFormato.TieneEstilo(documento, FontStyle.Bold) == true;
            cursiva.Checked = MYGEspecificacionesFormato.TieneEstilo(documento, FontStyle.Italic) == true;
            subrayado.Checked = MYGEspecificacionesFormato.TieneEstilo(documento, FontStyle.Underline) == true;
        }
        finally { actualizandoFuente = false; }
    }
    private void ElegirColor(bool fondo)
    {
        using var dialogo = new ColorDialog { Color = fondo ? documento.SelectionBackColor : documento.SelectionColor, FullOpen = true };
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            AplicarFormato(() => { if (fondo) documento.SelectionBackColor = dialogo.Color; else documento.SelectionColor = dialogo.Color; });
    }
    private void Nuevo()
    {
        if (documento.TextLength > 0 && MessageBox.Show(this, "¿Vaciar la especificación de esta partida? Puede deshacer el cambio.",
            "Nueva especificación", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        AplicarFormato(() =>
        {
            documento.SelectAll(); documento.SelectedText = "";
            MYGEspecificacionesFormato.LimpiarFormato(documento);
            MYGEspecificacionesFormato.EstablecerFuentePredeterminada(documento, FuenteReferencia());
            MYGEspecificacionesFormato.EstablecerFuente(documento, FuenteReferencia(), 11);
        });
    }
    private void Abrir()
    {
        using var dialogo = new OpenFileDialog { Filter = "Documentos RTF, texto y Word|*.rtf;*.txt;*.doc;*.docx|RTF|*.rtf|Texto|*.txt|Word (requiere Word instalado)|*.doc;*.docx" };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        // Preparar y validar antes de reemplazar la especificación existente.
        using var temporal = new RichTextBox { Font = fuentePredeterminada };
        string extension = Path.GetExtension(dialogo.FileName).ToLowerInvariant();
        string rtf;
        if (extension is ".doc" or ".docx")
        { MYGEspecificacionesDocumento.AbrirWord(this, temporal, dialogo.FileName); rtf = temporal.Rtf; }
        else if (extension == ".rtf")
        {
            temporal.LoadFile(dialogo.FileName, RichTextBoxStreamType.RichText);
            // Los metadatos son ASCII; la carga nativa respeta ansicpg y los datos binarios RTF.
            rtf = File.ReadAllText(dialogo.FileName, System.Text.Encoding.Latin1);
        }
        else { CargarTextoPredeterminado(temporal, File.ReadAllText(dialogo.FileName)); rtf = temporal.Rtf; }
        if (documento.TextLength > 0 && MessageBox.Show(this, modoExportacion ? "¿Reemplazar el documento de exportación con el archivo seleccionado?" : "¿Reemplazar el contenido de la especificación de esta partida con el archivo seleccionado?",
            "Abrir especificación", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        AplicarFormato(() =>
        {
            paginasAntes.Push(MYGEspecificacionesPagina.Leer(DocumentoRtf)); paginasDespues.Clear();
            pagina = MYGEspecificacionesPagina.Leer(rtf);
            documento.SelectAll(); documento.SelectedRtf = temporal.Rtf; anotaciones.Leer(rtf); ortografia.ReiniciarDocumento(); ActualizarVista();
        });
    }
    private string NombreArchivo()
    {
        string nombre = "Especificacion_" + codigo();
        foreach (char c in Path.GetInvalidFileNameChars()) nombre = nombre.Replace(c, '_');
        return nombre;
    }
    private void Guardar(bool word)
    {
        using var dialogo = new SaveFileDialog { Filter = word ? "Documento Word (*.docx)|*.docx" : "Documento RTF (*.rtf)|*.rtf|Texto sin formato (*.txt)|*.txt",
            FileName = NombreArchivo() + (word ? ".docx" : ".rtf"), AddExtension = true };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        if (word) MYGEspecificacionesDocumento.GuardarWord(this, documento, dialogo.FileName, ConfiguracionImpresion(), pagina.Encabezado, pagina.Pie, pagina.NumerarPaginas);
        else if (Path.GetExtension(dialogo.FileName).Equals(".txt", StringComparison.OrdinalIgnoreCase)) File.WriteAllText(dialogo.FileName, documento.Text);
        else File.WriteAllText(dialogo.FileName,
            RtfParaArchivo, System.Text.Encoding.ASCII);
        if (!modoExportacion && !documento.ReadOnly)
        {
            confirmarGuardado?.Invoke();
            tituloInicialSinEditar = false;
        }
    }
    private void Imprimir(bool previa) => MYGEspecificacionesDocumento.Imprimir(this, documento, titulo(), previa,
        ConfiguracionImpresion(), pagina.Encabezado, pagina.Pie, pagina.NumerarPaginas);
    private PageSettings ConfiguracionImpresion() => new()
    {
        PaperSize = new PaperSize("MYG", CentesimasPulgada(pagina.AnchoMm), CentesimasPulgada(pagina.AltoMm)),
        Landscape = pagina.Horizontal,
        Margins = new Margins(CentesimasPulgada(pagina.MargenIzquierdoMm), CentesimasPulgada(pagina.MargenDerechoMm),
            CentesimasPulgada(pagina.MargenSuperiorMm), CentesimasPulgada(pagina.MargenInferiorMm))
    };
    private static int CentesimasPulgada(decimal mm) => (int)Math.Round(mm / 25.4m * 100);
    private int AnchoContenidoTwips() => (int)Math.Round(((pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm) - pagina.MargenIzquierdoMm - pagina.MargenDerechoMm) / 25.4m * 1440);
    private string TextoTitulo() => codigo() + "  " + titulo() + "   (unidad de medida: " + unidad() + ")\n\nDESCRIPCIÓN:\n\n";
    private void InsertarTitulo() => AplicarFormato(InsertarContenidoTitulo);
    private void InsertarContenidoTitulo()
    {
        int inicio = documento.SelectionStart;
        string nombre = codigo() + "  " + titulo();
        string texto = TextoTitulo();
        documento.SelectedText = texto;
        documento.Select(inicio, texto.Length);
        MYGEspecificacionesFormato.LimpiarFormato(documento);
        MYGEspecificacionesFormato.EstablecerFuente(documento, FuenteReferencia(), 11);
        documento.Select(inicio, nombre.Length); MYGEspecificacionesFormato.AlternarEstilo(documento, FontStyle.Bold);
        int descripcion = texto.IndexOf("DESCRIPCIÓN:", StringComparison.Ordinal);
        documento.Select(inicio + descripcion, "DESCRIPCIÓN:".Length); MYGEspecificacionesFormato.AlternarEstilo(documento, FontStyle.Bold);
        documento.Select(inicio + texto.Length, 0);
        MYGEspecificacionesFormato.PrepararInsercionNormal(documento, FuenteReferencia(), 11);
    }
    private string FuenteReferencia() => fuentePredeterminada.Name;
    private void InsertarPlantilla() => AplicarFormato(() =>
    {
        int inicio = documento.SelectionStart;
        string texto = codigo() + "  " + titulo() + "\nUnidad de medida: " + unidad() + "\n\n" +
            "A. DESCRIPCIÓN\n\nB. MATERIALES\n\nC. EQUIPOS Y HERRAMIENTAS\n\nD. MÉTODO DE EJECUCIÓN\n\n" +
            "E. CONTROL DE CALIDAD\n\nF. MÉTODO DE MEDICIÓN\n\nG. CONDICIONES DE PAGO\n\n";
        documento.SelectedText = texto;
        documento.Select(inicio, texto.Length); MYGEspecificacionesFormato.LimpiarFormato(documento);
        MYGEspecificacionesFormato.EstablecerFuente(documento, FuenteReferencia(), 11);
        int offset = 0;
        foreach (string linea in texto.Split('\n'))
        {
            if (offset == 0 || (linea.Length > 2 && linea[1] == '.' && linea[0] is >= 'A' and <= 'G'))
            {
                documento.Select(inicio + offset, linea.Length);
                MYGEspecificacionesFormato.AlternarEstilo(documento, FontStyle.Bold);
                if (offset == 0) MYGEspecificacionesFormato.EstablecerFuente(documento, null, 13);
            }
            offset += linea.Length + 1;
        }
        documento.Select(inicio + texto.Length, 0);
        MYGEspecificacionesFormato.PrepararInsercionNormal(documento, FuenteReferencia(), 11);
    });
    private void InsertarTabla()
    {
        using var dialogo = new Form { Text = "Insertar tabla", ClientSize = new(300, 160), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false };
        var filas = new NumericUpDown { Minimum = 1, Maximum = 50, Value = 3, Location = new(150, 20), Width = 95 };
        var columnas = new NumericUpDown { Minimum = 1, Maximum = 10, Value = 3, Location = new(150, 58), Width = 95 };
        dialogo.Controls.AddRange(new Control[] { new Label { Text = "Filas", Location = new(20, 23) }, filas, new Label { Text = "Columnas", Location = new(20, 61) }, columnas });
        BotonesDialogo(dialogo);
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            AplicarFormato(() => MYGEspecificacionesDocumento.InsertarTabla(documento, (int)filas.Value, (int)columnas.Value, AnchoContenidoTwips()));
    }
    private void InsertarImagen()
    {
        using var dialogo = new OpenFileDialog { Filter = "Imágenes|*.png;*.jpg;*.jpeg;*.bmp;*.gif" };
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            AplicarFormato(() => MYGEspecificacionesDocumento.InsertarImagen(documento, dialogo.FileName, AnchoContenidoTwips()));
    }
    private void InsertarSimbolo()
    {
        using var dialogo = new Form { Text = "Insertar símbolo", ClientSize = new(390, 145), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false };
        var simbolo = new ComboBox { Location = new(20, 20), Width = 345, DropDownStyle = ComboBoxStyle.DropDown };
        simbolo.Items.AddRange(new object[] { "m²", "m³", "Ø", "±", "≤", "≥", "°", "µ", "Ω", "→", "✓" }); simbolo.SelectedIndex = 0;
        dialogo.Controls.Add(simbolo); BotonesDialogo(dialogo);
        if (dialogo.ShowDialog(this) == DialogResult.OK) AplicarFormato(() => documento.SelectedText = simbolo.Text);
    }
    private void CambiarPagina(Action accion)
    {
        CancelarArrastreMargenes();
        var previa = MYGEspecificacionesPagina.Leer(DocumentoRtf);
        AplicarFormato(() =>
        {
            try
            {
                accion(); MYGEspecificacionesPagina.Validar(pagina);
                paginasAntes.Push(previa); paginasDespues.Clear(); ActualizarVista();
            }
            catch { pagina = previa; throw; }
        });
    }

    private void PrepararArrastreMargenes(MYGEspecificacionesRegla control, bool horizontal)
    {
        control.ArrastreIniciado += (_, _) =>
        {
            if (documento.ReadOnly || cargando || borrador)
            {
                control.CancelarArrastre();
                return;
            }
            DetenerZoom();
            paginaAntesArrastre = MYGEspecificacionesPagina.Leer(DocumentoRtf);
            scrollAntesArrastre = lienzo.AutoScrollPosition;
            inicioAntesArrastre = documento.SelectionStart;
            longitudAntesArrastre = documento.SelectionLength;
        };
        control.MargenesCambiados += (_, e) =>
        {
            if (paginaAntesArrastre == null) return;
            bool moverInicio = e.Margen == MYGEspecificacionesMargenRegla.Inicio;
            decimal longitud = horizontal
                ? (pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm)
                : (pagina.Horizontal ? pagina.AnchoMm : pagina.AltoMm);
            decimal inicioAnterior = horizontal ? paginaAntesArrastre.MargenIzquierdoMm : paginaAntesArrastre.MargenSuperiorMm;
            decimal finAnterior = horizontal ? paginaAntesArrastre.MargenDerechoMm : paginaAntesArrastre.MargenInferiorMm;
            decimal margenMovido = Math.Round((decimal)(moverInicio ? e.MargenInicioMm : e.MargenFinMm), 1);
            var margenes = MYGEspecificacionesMargenes.Arrastrar(longitud, inicioAnterior, finAnterior,
                moverInicio ? margenMovido : longitud - margenMovido, moverInicio, Math.Min(10m, longitud));
            if (horizontal)
            {
                pagina.MargenIzquierdoMm = margenes.InicioMm;
                pagina.MargenDerechoMm = margenes.FinMm;
            }
            else
            {
                pagina.MargenSuperiorMm = margenes.InicioMm;
                pagina.MargenInferiorMm = margenes.FinMm;
            }
            // El modelo conserva el estado anterior mientras el ratón muestra
            // la vista previa. Una sola modificación se registra al soltar.
            ActualizarVistaArrastre();
        };
        control.ArrastreCancelado += (_, _) =>
        {
            if (paginaAntesArrastre == null) return;
            pagina = paginaAntesArrastre;
            paginaAntesArrastre = null;
            ActualizarVistaArrastre();
        };
        control.ArrastreFinalizado += (_, _) =>
        {
            if (paginaAntesArrastre == null) return;
            var anterior = paginaAntesArrastre;
            var siguiente = MYGEspecificacionesPagina.Leer(DocumentoRtf);
            paginaAntesArrastre = null;
            pagina = anterior;
            if (documento.ReadOnly || cargando || borrador || IsDisposed || Disposing)
            { ActualizarVistaArrastre(); return; }
            bool cambio = anterior.MargenIzquierdoMm != siguiente.MargenIzquierdoMm ||
                anterior.MargenDerechoMm != siguiente.MargenDerechoMm ||
                anterior.MargenSuperiorMm != siguiente.MargenSuperiorMm ||
                anterior.MargenInferiorMm != siguiente.MargenInferiorMm;
            if (!cambio) { ActualizarVistaArrastre(); return; }
            Intentar(() =>
            {
                try { CambiarPagina(() => pagina = siguiente); }
                catch { pagina = anterior; ActualizarVistaArrastre(); throw; }
                RestaurarPosicionArrastre();
            });
        };
    }

    private void ActualizarVistaArrastre()
    {
        if (IsDisposed || Disposing || documento.IsDisposed) return;
        bool anterior = ejecutando;
        ejecutando = true;
        try { ActualizarVista(); RestaurarPosicionArrastre(); }
        finally { ejecutando = anterior; }
    }

    private void RestaurarPosicionArrastre()
    {
        if (IsDisposed || Disposing || documento.IsDisposed) return;
        if (documento.SelectionStart != inicioAntesArrastre || documento.SelectionLength != longitudAntesArrastre)
        {
            int inicio = Math.Min(inicioAntesArrastre, documento.TextLength);
            documento.Select(inicio, Math.Min(longitudAntesArrastre, documento.TextLength - inicio));
        }
        lienzo.AutoScrollPosition = new Point(-scrollAntesArrastre.X, -scrollAntesArrastre.Y);
        ActualizarOrigenReglas();
        documento.Invalidate();
    }

    private bool CancelarArrastreMargenes()
    {
        bool activo = regla.Arrastrando || reglaVertical.Arrastrando;
        regla.CancelarArrastre(); reglaVertical.CancelarArrastre();
        return activo;
    }

    private void ActualizarOrigenReglas()
    {
        regla.Desplazar((reglaVertical.Visible ? reglaVertical.Width : 0) + papel.Left);
        reglaVertical.Desplazar(papel.Top);
    }
    private void HistorialPagina(bool rehacer)
    {
        var origen = rehacer ? paginasDespues : paginasAntes;
        var destino = rehacer ? paginasAntes : paginasDespues;
        if (origen.Count == 0) return;
        AplicarFormato(() =>
        {
            destino.Push(MYGEspecificacionesPagina.Leer(DocumentoRtf));
            pagina = origen.Pop(); ActualizarVista();
        });
    }
    private void Margenes()
    {
        using var dialogo = new Form { Text = "Márgenes (milímetros)", ClientSize = new(325, 235), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false };
        decimal[] valores = { pagina.MargenIzquierdoMm, pagina.MargenDerechoMm, pagina.MargenSuperiorMm, pagina.MargenInferiorMm };
        string[] nombres = { "Izquierdo", "Derecho", "Superior", "Inferior" };
        var numeros = new NumericUpDown[4];
        for (int i = 0; i < 4; i++)
        {
            numeros[i] = new NumericUpDown { Minimum = 0, Maximum = 500, DecimalPlaces = 1, Value = Math.Min(valores[i], 500), Location = new(160, 17 + i * 36), Width = 125 };
            dialogo.Controls.Add(new Label { Text = nombres[i], Location = new(20, 20 + i * 36) }); dialogo.Controls.Add(numeros[i]);
        }
        BotonesDialogo(dialogo);
        if (dialogo.ShowDialog(this) == DialogResult.OK) CambiarPagina(() =>
        { pagina.MargenIzquierdoMm = numeros[0].Value; pagina.MargenDerechoMm = numeros[1].Value; pagina.MargenSuperiorMm = numeros[2].Value; pagina.MargenInferiorMm = numeros[3].Value; });
    }
    private void EncabezadoPie()
    {
        using var dialogo = new Form { Text = "Encabezado y pie de página", ClientSize = new(480, 265), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false };
        var encabezado = new TextBox { Text = pagina.Encabezado, Location = new(20, 44), Width = 440, MaxLength = 2000 };
        var pie = new TextBox { Text = pagina.Pie, Location = new(20, 113), Width = 440, MaxLength = 2000 };
        var numero = new CheckBox { Text = "Mostrar número de página", Checked = pagina.NumerarPaginas, Location = new(20, 161), AutoSize = true };
        dialogo.Controls.AddRange(new Control[] { new Label { Text = "Encabezado", Location = new(20, 19) }, encabezado, new Label { Text = "Pie", Location = new(20, 88) }, pie, numero });
        BotonesDialogo(dialogo);
        if (dialogo.ShowDialog(this) == DialogResult.OK) CambiarPagina(() => { pagina.Encabezado = encabezado.Text; pagina.Pie = pie.Text; pagina.NumerarPaginas = numero.Checked; });
    }
    private void ConfigurarSangria()
    {
        using var dialogo = new Form { Text = "Sangría de párrafo (milímetros)", ClientSize = new(340, 210), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false };
        string[] nombres = { "Primera línea", "Derecha", "Sangría francesa" };
        int[] valores = { documento.SelectionIndent, documento.SelectionRightIndent, documento.SelectionHangingIndent };
        var numeros = new NumericUpDown[3];
        for (int i = 0; i < 3; i++)
        {
            numeros[i] = new NumericUpDown { Minimum = i == 2 ? -50 : 0, Maximum = 100, DecimalPlaces = 1, Value = Math.Clamp((decimal)valores[i] / DeviceDpi * 25.4m, i == 2 ? -50 : 0, 100), Location = new(180, 20 + i * 36), Width = 115 };
            dialogo.Controls.Add(new Label { Text = nombres[i], Location = new(20, 23 + i * 36), Width = 150 }); dialogo.Controls.Add(numeros[i]);
        }
        BotonesDialogo(dialogo);
        if (dialogo.ShowDialog(this) == DialogResult.OK) AplicarFormato(() =>
        {
            documento.SelectionIndent = (int)(numeros[0].Value / 25.4m * DeviceDpi);
            documento.SelectionRightIndent = (int)(numeros[1].Value / 25.4m * DeviceDpi);
            documento.SelectionHangingIndent = (int)(numeros[2].Value / 25.4m * DeviceDpi);
        });
    }
    private static void BotonesDialogo(Form dialogo)
    {
        var aceptar = new Button { Text = "Aceptar", DialogResult = DialogResult.OK, Width = 100, Location = new(dialogo.ClientSize.Width - 230, dialogo.ClientSize.Height - 43) };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Width = 100, Location = new(dialogo.ClientSize.Width - 120, dialogo.ClientSize.Height - 43) };
        dialogo.Controls.AddRange(new Control[] { aceptar, cancelar }); dialogo.AcceptButton = aceptar; dialogo.CancelButton = cancelar;
    }
    private void Buscar()
    {
        using var dialogo = new Form { Text = "Buscar y reemplazar", ClientSize = new(465, 230), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MaximizeBox = false, MinimizeBox = false };
        var buscar = new TextBox { Location = new(115, 20), Width = 325 };
        var reemplazo = new TextBox { Location = new(115, 58), Width = 325 };
        var mayusculas = new CheckBox { Text = "Distinguir mayúsculas", Location = new(115, 98), AutoSize = true };
        var siguiente = new Button { Text = "Buscar siguiente", Location = new(20, 145), Width = 135 };
        var reemplazar = new Button { Text = "Reemplazar", Location = new(163, 145), Width = 115 };
        var todos = new Button { Text = "Reemplazar todos", Location = new(287, 145), Width = 155 };
        var cerrar = new Button { Text = "Cerrar", DialogResult = DialogResult.Cancel, Location = new(342, 188), Width = 100 };
        dialogo.Controls.AddRange(new Control[] { new Label { Text = "Buscar", Location = new(20, 23) }, buscar, new Label { Text = "Reemplazar", Location = new(20, 61) }, reemplazo, mayusculas, siguiente, reemplazar, todos, cerrar });
        dialogo.CancelButton = cerrar;
        StringComparison Comparacion() => mayusculas.Checked ? StringComparison.CurrentCulture : StringComparison.CurrentCultureIgnoreCase;
        void Siguiente()
        {
            if (buscar.Text.Length == 0) return;
            int desde = documento.SelectionStart + documento.SelectionLength;
            int indice = documento.Text.IndexOf(buscar.Text, desde, Comparacion());
            if (indice < 0) indice = documento.Text.IndexOf(buscar.Text, 0, Comparacion());
            if (indice >= 0) { documento.Select(indice, buscar.Text.Length); documento.ScrollToCaret(); }
            else MessageBox.Show(dialogo, "No se encontró el texto.", "Buscar");
        }
        siguiente.Click += (_, _) => Siguiente();
        reemplazar.Click += (_, _) => Intentar(() =>
        {
            if (buscar.Text.Length == 0) return;
            if (string.Equals(documento.SelectedText, buscar.Text, Comparacion())) AplicarFormato(() => documento.SelectedText = reemplazo.Text);
            Siguiente();
        });
        todos.Click += (_, _) => Intentar(() =>
        {
            if (buscar.Text.Length == 0) return;
            AplicarFormato(() =>
            {
                int desde = 0, indice;
                while ((indice = documento.Text.IndexOf(buscar.Text, desde, Comparacion())) >= 0)
                { documento.Select(indice, buscar.Text.Length); documento.SelectedText = reemplazo.Text; desde = indice + reemplazo.Text.Length; }
            });
        });
        dialogo.ShowDialog(this);
    }
    private void DocumentoKeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape && CancelarArrastreMargenes())
        { e.SuppressKeyPress = true; return; }
        CancelarArrastreMargenes();
        if (e.KeyCode == Keys.F7) { e.SuppressKeyPress = true; Intentar(ComprobarOrtografia); return; }
        if (e.Control && e.Shift && e.KeyCode == Keys.V)
        { e.SuppressKeyPress = true; Intentar(PegarEspecial); return; }
        if (!e.Control || e.Alt || documento.ReadOnly) return;
        if (modoExportacion && e.KeyCode == Keys.S) { e.SuppressKeyPress = true; Intentar(() => guardarExportacion?.Invoke()); return; }
        Action comando = e.KeyCode switch
        {
            Keys.B => () => Estilo(FontStyle.Bold), Keys.I => () => Estilo(FontStyle.Italic), Keys.U => () => Estilo(FontStyle.Underline),
            Keys.F => Buscar, Keys.P => () => Imprimir(false),
            Keys.S => GuardarProyecto,
            Keys.Z => () => { if (documento.CanUndo) AplicarFormato(documento.Undo); },
            Keys.Y => () => { if (documento.CanRedo) AplicarFormato(documento.Redo); }, _ => null
        };
        if (comando != null) { e.SuppressKeyPress = true; Intentar(comando); }
    }
    private bool MoverRueda(int delta, bool control, Point pantalla)
    {
        CancelarArrastreMargenes();
        if (control)
        {
            if (delta == 0) return true;
            anclaZoom = lienzo.PointToClient(pantalla);
            anclaZoom = new Point(Math.Clamp(anclaZoom.X, 0, Math.Max(0, lienzo.ClientSize.Width - 1)),
                Math.Clamp(anclaZoom.Y, 0, Math.Max(0, lienzo.ClientSize.Height - 1)));
            puntoHojaZoom = new PointF((float)(anclaZoom.X - papel.Left) / Math.Max(1, papel.Width),
                (float)(anclaZoom.Y - papel.Top) / Math.Max(1, papel.Height));
            actualizandoVista = true;
            try { ajustar.Checked = false; }
            finally { actualizandoVista = false; }
            zoomSuave.Retarget(delta, relojZoom.Elapsed.TotalSeconds);
            SincronizarZoom(zoomSuave.Target);
            if (zoomSuave.Active) animacionZoom.Start();
            return true; // También en los límites: nunca pasar Ctrl+rueda a RichEdit.
        }
        DetenerZoom();
        bool desplazado = lienzo.DesplazarRueda(delta);
        ActualizarOrigenReglas();
        documento.Invalidate();
        // Al llegar al extremo, RichEdit aún puede recorrer texto que desborde la página.
        return desplazado;
    }

    private void SincronizarZoom(double valor)
    {
        sincronizandoZoom = true;
        try { zoom.Value = Math.Clamp((decimal)Math.Round(valor), zoom.Minimum, zoom.Maximum); }
        finally { sincronizandoZoom = false; }
    }

    private void DetenerZoom()
    {
        animacionZoom.Stop();
        zoomSuave.SetImmediate(zoomSuave.Current);
        SincronizarZoom(zoomSuave.Current);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            CancelarArrastreMargenes();
            animacionZoom.Stop();
            animacionZoom.Dispose();
            MYG2027_TemaComercial.CambioTema -= CambioTema;
            LiberarEdicionContextual();
            vistaOscura.Dispose();
            foreach (var rueda in ruedas) rueda.Dispose();
            ruedas.Clear();
        }
        base.Dispose(disposing);
        if (disposing) fuentePredeterminada.Dispose();
    }

    private void ActualizarEstado()
    {
        if (documento.IsDisposed) return;
        estado.Text = $"{documento.TextLength:N0} caracteres · {zoom.Value:0} % · {(pagina.Horizontal ? "Horizontal" : "Vertical")}" +
            (pagina.NumerarPaginas ? " · Páginas numeradas" : "") + (modoExportacion ? " · Documento de exportación" : " · Especificación de la partida");
    }
    private void ActualizarVista()
    {
        if (!actualizandoVista && (documento.ReadOnly || borrador)) CancelarArrastreMargenes();
        if (actualizandoVista || IsDisposed || documento.IsDisposed || lienzo.Width < 20) return;
        actualizandoVista = true;
        try
        {
            decimal anchoMm = pagina.Horizontal ? pagina.AltoMm : pagina.AnchoMm;
            decimal altoMm = pagina.Horizontal ? pagina.AnchoMm : pagina.AltoMm;
            float dpi = DeviceDpi;
            int anchoBase = (int)(anchoMm / 25.4m * (decimal)dpi);
            float factor = (float)zoomSuave.Current / 100f;
            if (ajustar.Checked && !borrador)
            {
                factor = Math.Clamp((float)(lienzo.ClientSize.Width - 152) / Math.Max(1, anchoBase), .25f, 3f);
                animacionZoom.Stop();
                zoomSuave.SetImmediate(factor * 100);
                SincronizarZoom(zoomSuave.Current);
            }
            bool mantenerAncla = animacionZoom.Enabled && !borrador;
            int ancho = borrador ? Math.Max(150, lienzo.ClientSize.Width - 24) : Math.Max(150, (int)(anchoBase * factor));
            int alto = borrador ? Math.Max(160, lienzo.ClientSize.Height - 24) : Math.Max(160, (int)(altoMm / 25.4m * (decimal)dpi * (decimal)factor));
            int margenI = borrador ? 12 : (int)(pagina.MargenIzquierdoMm / 25.4m * (decimal)dpi * (decimal)factor);
            int margenD = borrador ? 12 : (int)(pagina.MargenDerechoMm / 25.4m * (decimal)dpi * (decimal)factor);
            int margenS = borrador ? 12 : (int)(pagina.MargenSuperiorMm / 25.4m * (decimal)dpi * (decimal)factor);
            int margenB = borrador ? 12 : (int)(pagina.MargenInferiorMm / 25.4m * (decimal)dpi * (decimal)factor);
            using (var repintado = new MYGEspecificacionesRepintado(documento))
            {
                lienzo.SuspendLayout();
                papel.SuspendLayout();
                try
                {
                    papel.Size = new(ancho, alto);
                    documento.Bounds = new(margenI, margenS, Math.Max(1, ancho - margenI - margenD - 2), Math.Max(1, alto - margenS - margenB - 2));
                    int margenTexto = borrador ? 0 : Math.Max(1, (int)((anchoMm - pagina.MargenIzquierdoMm - pagina.MargenDerechoMm) / 25.4m * (decimal)dpi));
                    if (documento.RightMargin != margenTexto) documento.RightMargin = margenTexto;
                    if (Math.Abs(documento.ZoomFactor - factor) > .0001f) documento.ZoomFactor = factor;
                    lienzo.AutoScrollMinSize = new(ancho + 32, alto + 64);
                    papel.Location = new(Math.Max(16, (lienzo.ClientSize.Width - ancho) / 2) + lienzo.AutoScrollPosition.X,
                        32 + lienzo.AutoScrollPosition.Y);
                }
                finally
                {
                    papel.ResumeLayout(false);
                    lienzo.ResumeLayout(true);
                }
                // Las barras pueden cambiar el ancho útil. Resolver el origen después
                // del layout y compensar el scroll para conservar el punto bajo el cursor.
                int origenX = Math.Max(16, (lienzo.ClientSize.Width - ancho) / 2);
                if (mantenerAncla)
                    lienzo.AutoScrollPosition = new Point(
                        Math.Max(0, (int)Math.Round(origenX + puntoHojaZoom.X * ancho - anclaZoom.X)),
                        Math.Max(0, (int)Math.Round(32 + puntoHojaZoom.Y * alto - anclaZoom.Y)));
                papel.Location = new(origenX + lienzo.AutoScrollPosition.X, 32 + lienzo.AutoScrollPosition.Y);
            }
            regla.Configurar((reglaVertical.Visible ? reglaVertical.Width : 0) + papel.Left, dpi * factor / 25.4f,
                (float)anchoMm, (float)pagina.MargenIzquierdoMm, (float)pagina.MargenDerechoMm);
            reglaVertical.Configurar(papel.Top, dpi * factor / 25.4f,
                (float)altoMm, (float)pagina.MargenSuperiorMm, (float)pagina.MargenInferiorMm);
            regla.EdicionHabilitada = reglaVertical.EdicionHabilitada = !documento.ReadOnly && !borrador;
            lienzo.Invalidate();
            ActualizarEstado();
        }
        finally { actualizandoVista = false; }
    }

}
