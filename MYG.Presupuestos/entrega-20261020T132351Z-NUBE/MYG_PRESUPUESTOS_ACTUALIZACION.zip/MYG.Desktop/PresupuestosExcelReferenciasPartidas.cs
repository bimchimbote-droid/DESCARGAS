using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private SesionReferenciaPartidaHoja sesionReferenciaPartidaHoja;
    private SesionReferenciaPartidaHoja destinoCapturadoBotonReferenciaHoja;
    private bool navegandoReferenciaPartidaHoja, restaurandoReferenciaPartidaHoja, preparandoBotonReferenciaPartidaHoja;
    private MYGHojaMetrado referenciasPartidasPendientesHoja;
    private string presupuestoReferenciasPendientesHoja, partidaReferenciasPendientesHoja, direccionReferenciasPendientesHoja;
    private Panel barraReferenciasPartidasHoja;
    private Button botonReferenciaPartidaHoja, cancelarReferenciaPartidaHoja;
    private Label indicacionReferenciaPartidaHoja;
    private bool estructuraHabilitadaReferenciaHoja, hojaSoloLecturaReferenciaHoja, formulaSoloLecturaReferenciaHoja;

    internal bool EligiendoReferenciaPartidaHoja => sesionReferenciaPartidaHoja != null;
    private bool BloqueandoEdicionReferenciaPartidaHoja => EligiendoReferenciaPartidaHoja || restaurandoReferenciaPartidaHoja || preparandoBotonReferenciaPartidaHoja;

    private sealed class SesionReferenciaPartidaHoja
    {
        internal string PresupuestoId, PartidaId, Direccion, Texto;
        internal int Cursor, LongitudSeleccion, PrimeraFilaVisible, PrimeraColumnaVisible;
        internal bool EditorCelda, FormulaPendiente;
        internal MYGTramoInsercionReferenciaHoja Tramo;
    }

    private Control PrepararBarraReferenciasPartidasHoja()
    {
        barraReferenciasPartidasHoja = new Panel { Name = "metrado_referencias_partidas", Dock = DockStyle.Top, Height = 34, Padding = new(3, 2, 3, 2) };
        botonReferenciaPartidaHoja = new Button
        {
            Name = "metrado_referenciar_partida", Text = "Referenciar otra partida", Dock = DockStyle.Left,
            Width = 174, CausesValidation = false, AccessibleDescription = "Elija una partida y señale una celda de su metrado para usarla en la fórmula actual."
        };
        indicacionReferenciaPartidaHoja = new Label
        {
            Name = "metrado_referencia_indicacion", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft,
            Padding = new(8, 0, 4, 0), AutoEllipsis = true, Text = "Seleccione la celda donde necesita el vínculo."
        };
        cancelarReferenciaPartidaHoja = new Button
        {
            Name = "metrado_referencia_cancelar", Text = "Cancelar (Esc)", Dock = DockStyle.Right, Width = 112,
            CausesValidation = false, Visible = false
        };
        botonReferenciaPartidaHoja.Click += (_, _) =>
        {
            try { Intentar(ElegirPartidaReferenciaHoja); }
            finally { destinoCapturadoBotonReferenciaHoja = null; preparandoBotonReferenciaPartidaHoja = false; }
        };
        cancelarReferenciaPartidaHoja.Click += (_, _) => Intentar(CancelarReferenciaPartidaHoja);
        barraReferenciasPartidasHoja.Controls.Add(indicacionReferenciaPartidaHoja);
        barraReferenciasPartidasHoja.Controls.Add(cancelarReferenciaPartidaHoja);
        barraReferenciasPartidasHoja.Controls.Add(botonReferenciaPartidaHoja);
        barraReferenciasPartidasHoja.Disposed += (_, _) => referenciasPartidasPendientesHoja = null;
        AplicarTemaReferenciasPartidasHoja();
        return barraReferenciasPartidasHoja;
    }

    private void AplicarTemaReferenciasPartidasHoja()
    {
        if (barraReferenciasPartidasHoja == null) return;
        barraReferenciasPartidasHoja.BackColor = MYG2027_TemaComercial.Superficie;
        barraReferenciasPartidasHoja.ForeColor = MYG2027_TemaComercial.Texto;
        foreach (Control control in barraReferenciasPartidasHoja.Controls)
        { control.BackColor = MYG2027_TemaComercial.Superficie; control.ForeColor = MYG2027_TemaComercial.Texto; }
    }

    private void ActualizarBarraReferenciasPartidasHoja()
    {
        if (botonReferenciaPartidaHoja == null || EligiendoReferenciaPartidaHoja) return;
        botonReferenciaPartidaHoja.Enabled = EdicionNubePermitida && HayPartida;
    }

    private SesionReferenciaPartidaHoja CapturarDestinoReferenciaPartidaHoja()
    {
        if (!EdicionNubePermitida) throw new InvalidOperationException("El proyecto está disponible solo para lectura.");
        RequerirPartida();
        if (hoja.CurrentCell == null) throw new InvalidOperationException("Seleccione primero la celda donde necesita la fórmula.");
        bool celda = hoja.IsCurrentCellInEditMode && hoja.EditingControl is TextBoxBase;
        var editor = celda ? (TextBoxBase)hoja.EditingControl : formula;
        string texto = editor.Text;
        int cursor = editor.SelectionStart, seleccion = editor.SelectionLength;
        // Al invocar el botón desde una celda sin editar, una referencia nueva
        // sustituye su contenido. Una fórmula activa conserva el cursor.
        if (!texto.TrimStart().StartsWith("=", StringComparison.Ordinal))
        { texto = "="; cursor = 1; seleccion = 0; }
        if (!MYGEleccionReferenciaFormulaHoja.IntentarPreparar(texto, cursor, seleccion, out var tramo))
            throw new InvalidOperationException("Coloque el cursor después de =, de un operador o dentro de los argumentos de una función para insertar la referencia.");
        return new()
        {
            PresupuestoId = P.Id, PartidaId = actual.Id,
            Direccion = DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex),
            Texto = editor.Text, Cursor = editor.SelectionStart, LongitudSeleccion = editor.SelectionLength,
            EditorCelda = celda, FormulaPendiente = formulaPendienteHoja, Tramo = tramo,
            PrimeraFilaVisible = hoja.FirstDisplayedScrollingRowIndex, PrimeraColumnaVisible = hoja.FirstDisplayedScrollingColumnIndex
        };
    }

    private void ElegirPartidaReferenciaHoja()
    {
        if (EligiendoReferenciaPartidaHoja) return;
        var sesion = destinoCapturadoBotonReferenciaHoja ?? CapturarDestinoReferenciaPartidaHoja();
        destinoCapturadoBotonReferenciaHoja = null; preparandoBotonReferenciaPartidaHoja = false;
        using var selector = new MYGElegirPartidaReferenciaHojaForm(PresupuestosEstructura, P.Id, actual.Id);
        // El selector no confirma la fórmula del destino; puede estar en '=' o
        // contener paréntesis incompletos mientras se señala el origen.
        bool previo = cargando; cargando = true;
        DialogResult resultado;
        try { resultado = selector.ShowDialog(this); }
        finally { cargando = previo; }
        if (resultado != DialogResult.OK)
        { RestaurarEditorDestinoReferenciaHoja(sesion, sesion.Texto, sesion.Cursor, sesion.LongitudSeleccion, sesion.EditorCelda, sesion.FormulaPendiente); return; }
        IniciarReferenciaPartidaHoja(selector.Presupuesto, selector.Partida, sesion);
    }

    private void PrepararPulsacionBotonReferenciaPartidaHoja()
    {
        if (EligiendoReferenciaPartidaHoja || !botonReferenciaPartidaHoja.Enabled) return;
        // Se ejecuta desde IMessageFilter antes de que Windows mueva el foco
        // al botón, de modo que ni siquiera el editor nativo confirme '='.
        try
        {
            destinoCapturadoBotonReferenciaHoja = CapturarDestinoReferenciaPartidaHoja();
            preparandoBotonReferenciaPartidaHoja = true;
        }
        catch (InvalidOperationException) { destinoCapturadoBotonReferenciaHoja = null; }
    }

    private void LiberarPulsacionBotonReferenciaPartidaHoja()
    {
        if (!preparandoBotonReferenciaPartidaHoja || destinoCapturadoBotonReferenciaHoja == null) return;
        var sesion = destinoCapturadoBotonReferenciaHoja;
        destinoCapturadoBotonReferenciaHoja = null; preparandoBotonReferenciaPartidaHoja = false;
        RestaurarEditorDestinoReferenciaHoja(sesion, sesion.Texto, sesion.Cursor, sesion.LongitudSeleccion, sesion.EditorCelda, sesion.FormulaPendiente);
    }

    internal void IniciarReferenciaPartidaHoja(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida) =>
        IniciarReferenciaPartidaHoja(presupuesto, partida, CapturarDestinoReferenciaPartidaHoja());

    private void IniciarReferenciaPartidaHoja(MYGPresupuestoDocumento presupuesto, ItemPresupuestoDelphin partida, SesionReferenciaPartidaHoja sesion)
    {
        if (!EdicionNubePermitida) throw new InvalidOperationException("El proyecto está disponible solo para lectura.");
        if (presupuesto == null || partida == null || MYGProyectoStorage.EsTitulo(partida) ||
            !PresupuestosEstructura.Any(p => p.Id == presupuesto.Id && p.Items.Any(i => i.Id == partida.Id)))
            throw new InvalidOperationException("Seleccione una partida de este proyecto.");
        if (presupuesto.Id == sesion.PresupuestoId && partida.Id == sesion.PartidaId)
            throw new InvalidOperationException("Para una celda de la misma partida, use la referencia directa de celda.");
        sesionReferenciaPartidaHoja = sesion;
        estructuraHabilitadaReferenciaHoja = estructura.Enabled;
        hojaSoloLecturaReferenciaHoja = hoja.ReadOnly;
        formulaSoloLecturaReferenciaHoja = formula.ReadOnly;
        TerminarEleccionReferenciasHoja(); CerrarAutocompletadoHoja();
        bool previo = cargando; cargando = true;
        try { hoja.CancelEdit(); formulaPendienteHoja = false; }
        finally { cargando = previo; }
        try
        {
            NavegarReferenciaPartidaHoja(partida);
            estructura.Enabled = false; hoja.ReadOnly = true; formula.ReadOnly = true;
            cintaHoja.Enabled = false; cabeceraExcel.Enabled = false;
            botonReferenciaPartidaHoja.Visible = false; cancelarReferenciaPartidaHoja.Visible = true;
            indicacionReferenciaPartidaHoja.Text = "Seleccione la celda de origen para " + CodigoDestinoReferenciaHoja(sesion) + " · " + sesion.Direccion;
            indicacionReferenciaPartidaHoja.AccessibleName = indicacionReferenciaPartidaHoja.Text;
            hoja.Focus();
        }
        catch { CancelarReferenciaPartidaHoja(); throw; }
    }

    private string CodigoDestinoReferenciaHoja(SesionReferenciaPartidaHoja sesion)
    {
        var p = PresupuestosEstructura.FirstOrDefault(x => x.Id == sesion.PresupuestoId);
        var i = p?.Items.FirstOrDefault(x => x.Id == sesion.PartidaId);
        return i == null ? "la partida destino" : CodigoEstructura(p, i);
    }

    private void NavegarReferenciaPartidaHoja(ItemPresupuestoDelphin partida)
    {
        bool previo = navegandoReferenciaPartidaHoja; navegandoReferenciaPartidaHoja = true;
        try
        {
            SeleccionarEstructura(partida);
            detalle.SelectedTab = paginaExcel;
            if (hojaPendiente) { CargarHoja(); hojaPendiente = false; }
        }
        finally { navegandoReferenciaPartidaHoja = previo; }
    }

    internal void SeleccionarCeldaReferenciaPartidaHoja(int fila, int columna)
    {
        if (!EligiendoReferenciaPartidaHoja || !HayPartida || fila < 0 || columna < 0 || fila >= hoja.RowCount || columna >= hoja.ColumnCount) return;
        var presupuestoOrigen = PresupuestosEstructura.FirstOrDefault(p => p.Id == P?.Id);
        var partidaOrigen = presupuestoOrigen?.Items.FirstOrDefault(i => i.Id == actual.Id && !MYGProyectoStorage.EsTitulo(i));
        if (partidaOrigen == null) throw new InvalidOperationException("La partida de origen ya no existe. Cancele y elija otra partida.");
        if (fila >= partidaOrigen.Costos.Hoja.Filas || columna >= partidaOrigen.Costos.Hoja.Columnas)
            throw new InvalidOperationException("La celda de origen ya no existe. Cancele y vuelva a seleccionar la partida.");
        actual = partidaOrigen;
        string direccionOrigen = DireccionAnclaHoja(fila, columna);
        var sesion = sesionReferenciaPartidaHoja;
        var presupuestoDestino = PresupuestosEstructura.FirstOrDefault(p => p.Id == sesion.PresupuestoId);
        var partidaDestino = presupuestoDestino?.Items.FirstOrDefault(i => i.Id == sesion.PartidaId);
        if (partidaDestino == null) throw new InvalidOperationException("La partida destino ya no existe. Cancele la selección.");
        MYGReferenciasMetrado.Vincular(PresupuestosEstructura);
        var borrador = MYGProyectoStorage.Copia(BorradorReferenciasPartidasHoja(sesion.Direccion, sesion.PresupuestoId, sesion.PartidaId) ?? partidaDestino.Costos.Hoja);
        string fragmento = MYGReferenciasMetrado.CrearReferencia(borrador, presupuestoOrigen, partidaOrigen, direccionOrigen);
        string texto = sesion.Texto.TrimStart().StartsWith("=", StringComparison.Ordinal) ? sesion.Texto : "=";
        string nuevo = texto[..sesion.Tramo.Inicio] + fragmento + texto[(sesion.Tramo.Inicio + sesion.Tramo.Longitud)..];
        if (nuevo.Length > MYGReferenciasFormulaHoja.MaximoCaracteresFormula)
            throw new InvalidOperationException("La celda supera los 32.767 caracteres.");
        referenciasPartidasPendientesHoja = borrador;
        presupuestoReferenciasPendientesHoja = sesion.PresupuestoId;
        partidaReferenciasPendientesHoja = sesion.PartidaId;
        direccionReferenciasPendientesHoja = sesion.Direccion;
        TerminarSeleccionReferenciaPartidaHoja();
        NavegarReferenciaPartidaHoja(partidaDestino);
        RestaurarEditorDestinoReferenciaHoja(sesion, nuevo, sesion.Tramo.Inicio + fragmento.Length, 0, false, true);
        indicacionReferenciaPartidaHoja.Text = "Referencia insertada. Complete la fórmula y pulse Enter o ✓.";
    }

    internal void CancelarReferenciaPartidaHoja()
    {
        var sesion = sesionReferenciaPartidaHoja;
        if (sesion == null) return;
        var presupuesto = PresupuestosEstructura.FirstOrDefault(p => p.Id == sesion.PresupuestoId);
        var partida = presupuesto?.Items.FirstOrDefault(i => i.Id == sesion.PartidaId);
        TerminarSeleccionReferenciaPartidaHoja();
        if (partida == null) return;
        NavegarReferenciaPartidaHoja(partida);
        RestaurarEditorDestinoReferenciaHoja(sesion, sesion.Texto, sesion.Cursor, sesion.LongitudSeleccion, sesion.EditorCelda, sesion.FormulaPendiente);
        indicacionReferenciaPartidaHoja.Text = "Selección cancelada. Se conserva la fórmula anterior.";
    }

    private void TerminarSeleccionReferenciaPartidaHoja()
    {
        sesionReferenciaPartidaHoja = null;
        estructura.Enabled = estructuraHabilitadaReferenciaHoja;
        hoja.ReadOnly = hojaSoloLecturaReferenciaHoja || !EdicionNubePermitida;
        formula.ReadOnly = formulaSoloLecturaReferenciaHoja || !EdicionNubePermitida;
        cintaHoja.Enabled = true; cabeceraExcel.Enabled = true;
        botonReferenciaPartidaHoja.Visible = true; cancelarReferenciaPartidaHoja.Visible = false;
    }

    private void RestaurarEditorDestinoReferenciaHoja(SesionReferenciaPartidaHoja sesion, string texto, int cursor, int longitud, bool editorCelda, bool pendiente)
    {
        bool previo = cargando; cargando = true; restaurandoReferenciaPartidaHoja = true;
        try
        {
            var coordenadas = MYGHojaCalculo.Coordenadas(sesion.Direccion);
            hoja.ClearSelection();
            hoja.CurrentCell = hoja[coordenadas.Columna - 1, coordenadas.Fila - 1]; hoja.CurrentCell.Selected = true;
            if (sesion.PrimeraFilaVisible >= 0 && sesion.PrimeraFilaVisible < hoja.RowCount && hoja.Rows[sesion.PrimeraFilaVisible].Visible && !hoja.Rows[sesion.PrimeraFilaVisible].Frozen)
                hoja.FirstDisplayedScrollingRowIndex = sesion.PrimeraFilaVisible;
            if (sesion.PrimeraColumnaVisible >= 0 && sesion.PrimeraColumnaVisible < hoja.ColumnCount && hoja.Columns[sesion.PrimeraColumnaVisible].Visible && !hoja.Columns[sesion.PrimeraColumnaVisible].Frozen)
                hoja.FirstDisplayedScrollingColumnIndex = sesion.PrimeraColumnaVisible;
            direccionFormulaHoja = sesion.Direccion; direccion.Text = sesion.Direccion;
            actualizandoFormulaHoja = true;
            try { formula.Text = texto; }
            finally { actualizandoFormulaHoja = false; }
            formulaPendienteHoja = pendiente;
        }
        finally { cargando = previo; restaurandoReferenciaPartidaHoja = false; }
        TextBoxBase editor = formula;
        if (editorCelda)
        {
            hoja.Focus();
            if (hoja.BeginEdit(false) && hoja.EditingControl is TextBoxBase celdaEditor) { editor = celdaEditor; editor.Text = texto; }
        }
        editor.Focus();
        editor.Select(Math.Min(cursor, editor.TextLength), Math.Min(longitud, Math.Max(0, editor.TextLength - cursor)));
        refrescoDiferidoEstructura?.Reintentar();
    }

    private MYGHojaMetrado BorradorReferenciasPartidasHoja(string direccionCelda, string presupuestoId = null, string partidaId = null) =>
        referenciasPartidasPendientesHoja != null && presupuestoReferenciasPendientesHoja == (presupuestoId ?? P?.Id) &&
        partidaReferenciasPendientesHoja == (partidaId ?? actual?.Id) && direccionReferenciasPendientesHoja == direccionCelda
            ? referenciasPartidasPendientesHoja : null;

    private void ValidarEntradaReferenciaPartidaHoja(string direccionCelda, string texto)
    {
        var borrador = BorradorReferenciasPartidasHoja(direccionCelda);
        MYGEdicionHoja.ValidarEntrada(borrador ?? actual.Costos.Hoja, direccionCelda, texto);
        if (borrador != null && texto.TrimStart().StartsWith("=", StringComparison.Ordinal))
        {
            var validacion = MYGProyectoStorage.Copia(borrador);
            MYGEdicionHoja.Celda(validacion, direccionCelda).Contenido = texto;
            // Evaluar con el destino provisional detecta ciclos y orígenes
            // eliminados antes de registrar una entrada en Deshacer.
            new MYGHojaCalculo(validacion).ValidarResultado(direccionCelda);
        }
    }

    private void DescartarReferenciasPartidasPendientesHoja()
    {
        referenciasPartidasPendientesHoja = null;
        presupuestoReferenciasPendientesHoja = partidaReferenciasPendientesHoja = direccionReferenciasPendientesHoja = null;
    }
}
