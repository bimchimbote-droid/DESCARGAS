#nullable enable
using System;
using System.IO;
using System.Text.Json;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

/// <summary>La configuración local contiene solo el destino y una clave pública; nunca una sesión.</summary>
public sealed record ConfiguracionNube(string Nombre, string Url, string ClavePublicable)
{
    public ClienteSupabase CrearCliente() => new(Url, ClavePublicable);
}

public static class NubeConfiguracion
{
    public static string Ruta => Path.Combine(Environment.GetFolderPath(
        Environment.SpecialFolder.LocalApplicationData), "MYG", "Nube", "config.json");

    public static ConfiguracionNube? Cargar()
    {
        if (!File.Exists(Ruta)) return null;
        if (new FileInfo(Ruta).Length > 64 * 1024)
            throw new InvalidDataException("La configuración de Nube MYG excede el tamaño permitido.");
        var configuracion = JsonSerializer.Deserialize<ConfiguracionNube>(File.ReadAllText(Ruta))
            ?? throw new InvalidDataException("La configuración de Nube MYG está vacía.");
        Validar(configuracion);
        return configuracion;
    }

    public static void Guardar(ConfiguracionNube configuracion)
    {
        Validar(configuracion);
        string destino = Ruta;
        Directory.CreateDirectory(Path.GetDirectoryName(destino)!);
        string temporal = destino + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(configuracion,
                new JsonSerializerOptions { WriteIndented = true });
            using (var archivo = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 4096, FileOptions.WriteThrough))
            {
                archivo.Write(bytes);
                archivo.Flush(flushToDisk: true);
            }
            // El temporal está en el mismo volumen: el reemplazo no expone JSON parcial.
            File.Move(temporal, destino, overwrite: true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    private static void Validar(ConfiguracionNube configuracion)
    {
        ArgumentNullException.ThrowIfNull(configuracion);
        if (string.IsNullOrWhiteSpace(configuracion.Nombre) || configuracion.Nombre.Length > 100)
            throw new InvalidDataException("Introduzca un nombre de conexión de hasta 100 caracteres.");
        // El cliente valida HTTPS, el destino Supabase y la clave publicable/anon.
        // Construirlo no realiza ninguna conexión ni permite claves secretas/service_role.
        using var cliente = configuracion.CrearCliente();
    }

    public static ConfiguracionNube? Editar(WinForms.IWin32Window propietario)
    {
        ConfiguracionNube? anterior = null;
        try { anterior = Cargar(); }
        catch (Exception ex) when (ex is IOException or JsonException or NubeException)
        { MYGProyectoUI.Error(propietario, ex); }

        using var dialogo = new WinForms.Form();
        MYGProyectoUI.Preparar(dialogo, "Configurar Nube MYG", 610, 390);
        dialogo.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
        dialogo.MaximizeBox = false;
        dialogo.MinimizeBox = false;
        var raiz = new WinForms.TableLayoutPanel
        {
            Dock = WinForms.DockStyle.Fill, Padding = new(22), ColumnCount = 1, RowCount = 8
        };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 26, 36, 26, 36, 26, 36, 70, 54 })
            raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, alto));
        var nombre = new WinForms.TextBox { Name = "nombreConexionNube", Dock = WinForms.DockStyle.Fill,
            Text = anterior?.Nombre ?? "Nube MYG", MaxLength = 100 };
        var url = new WinForms.TextBox { Name = "urlConexionNube", Dock = WinForms.DockStyle.Fill,
            Text = anterior?.Url ?? "", PlaceholderText = "https://proyecto.supabase.co", MaxLength = 2048 };
        var clave = new WinForms.TextBox { Name = "clavePublicableNube", Dock = WinForms.DockStyle.Fill,
            Text = anterior?.ClavePublicable ?? "", PlaceholderText = "sb_publishable_… o clave anon", MaxLength = 32768 };
        raiz.Controls.Add(new WinForms.Label { Text = "Nombre de conexión", AutoSize = true }, 0, 0);
        raiz.Controls.Add(nombre, 0, 1);
        raiz.Controls.Add(new WinForms.Label { Text = "URL del proyecto Supabase", AutoSize = true }, 0, 2);
        raiz.Controls.Add(url, 0, 3);
        raiz.Controls.Add(new WinForms.Label { Text = "Clave publicable", AutoSize = true }, 0, 4);
        raiz.Controls.Add(clave, 0, 5);
        raiz.Controls.Add(new WinForms.Label
        {
            Text = "Use la clave publicable o anon. La cuenta se conecta por separado y su sesión permanece solo en memoria. Los permisos y la vinculación MYG se verifican en el servidor.",
            Dock = WinForms.DockStyle.Fill, Padding = new(0, 6, 0, 0)
        }, 0, 6);
        var pie = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = false };
        var cancelar = MYGProyectoUI.Boton("Cancelar");
        cancelar.DialogResult = WinForms.DialogResult.Cancel;
        var guardar = MYGProyectoUI.Boton("Guardar", 1);
        ConfiguracionNube? resultado = null;
        guardar.Click += (_, _) =>
        {
            try
            {
                var candidata = new ConfiguracionNube(nombre.Text.Trim(), url.Text.Trim(), clave.Text.Trim());
                Guardar(candidata);
                resultado = candidata;
                dialogo.DialogResult = WinForms.DialogResult.OK;
            }
            catch (Exception ex) { MYGProyectoUI.Error(dialogo, ex); }
        };
        pie.Controls.Add(cancelar); pie.Controls.Add(guardar);
        raiz.Controls.Add(pie, 0, 7); dialogo.Controls.Add(raiz);
        dialogo.AcceptButton = guardar; dialogo.CancelButton = cancelar;
        return dialogo.ShowDialog(propietario) == WinForms.DialogResult.OK ? resultado : null;
    }
}
