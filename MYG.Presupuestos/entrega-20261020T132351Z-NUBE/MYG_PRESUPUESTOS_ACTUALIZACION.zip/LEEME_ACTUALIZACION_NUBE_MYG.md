# Actualización Nube MYG — entrega para aplicación manual

## A. Resumen

Nube MYG se incorpora al programa existente: ventana independiente, cuenta de nube,
proyectos propios/compartidos, solicitudes recibidas, roles, publicación, copias
vinculadas, sincronización manual, conflictos y descargas independientes.
Guardar conserva documento y cola en la misma transacción SQLite. Los reintentos
mantienen UUID y contenido, incluso después de cerrar/reabrir la hoja. El servidor
vuelve a comprobar los permisos antes de confirmar o devolver un reintento.
Los datos estructurados se guardan en PostgreSQL; los adjuntos se guardan en un bucket privado.

Repositorio: `bimchimbote-droid/MYG.Presupuestos`. Rama destino del usuario: `main`.
Base utilizada y contrastada con `origin/main`: **9ea48001e159a0120a86583d18b0dce89df7d787**.
Los cambios se prepararon en la rama local `work`; no se hizo Commit, Push ni merge del código.

## B. Archivos

El ZIP contiene únicamente los archivos de esta tabla, completos y con sus rutas relativas.
Los archivos existentes se entregan para REEMPLAZAR; los nuevos para CREAR.
No hay archivos que eliminar ni parches puntuales pendientes.

| N.º | Ruta exacta | Acción | Descripción |
|---|---|---|---|
| 1 | `LEEME_ACTUALIZACION_NUBE_MYG.md` | CREAR | Guía de aplicación, inventario y resultados de esta entrega. |
| 2 | `MYG.Colaboracion/ClienteNubeArchivos.cs` | CREAR | Cliente, paquetes portables y sincronización de nube. |
| 3 | `MYG.Colaboracion/ClienteNubeProyectos.cs` | CREAR | Cliente, paquetes portables y sincronización de nube. |
| 4 | `MYG.Colaboracion/ClienteSupabase.cs` | REEMPLAZAR | Cliente, paquetes portables y sincronización de nube. |
| 5 | `MYG.Colaboracion/ModelosColaboracion.cs` | REEMPLAZAR | Cliente, paquetes portables y sincronización de nube. |
| 6 | `MYG.Colaboracion/ModelosNubeProyectos.cs` | CREAR | Cliente, paquetes portables y sincronización de nube. |
| 7 | `MYG.Colaboracion/PaqueteNube.cs` | CREAR | Cliente, paquetes portables y sincronización de nube. |
| 8 | `MYG.Colaboracion/SincronizadorProyectoNube.cs` | CREAR | Cliente, paquetes portables y sincronización de nube. |
| 9 | `MYG.Core/BaseDatosMYG.cs` | REEMPLAZAR | Guardado atómico de documentos, vínculos y operaciones pendientes. |
| 10 | `MYG.Core/ColaboracionLocalMYG.cs` | CREAR | Guardado atómico de documentos, vínculos y operaciones pendientes. |
| 11 | `MYG.Desktop/EditorCatalogos.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 12 | `MYG.Desktop/EditorCronograma.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 13 | `MYG.Desktop/EditorEstructura.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 14 | `MYG.Desktop/EditorForm.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 15 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 16 | `MYG.Desktop/EditorNube.cs` | CREAR | Interfaz e integración de Nube MYG. |
| 17 | `MYG.Desktop/EditorPresupuestos.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 18 | `MYG.Desktop/EspecificacionesEditor.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 19 | `MYG.Desktop/InicioForm.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 20 | `MYG.Desktop/InicioNube.cs` | CREAR | Interfaz e integración de Nube MYG. |
| 21 | `MYG.Desktop/NubeConfiguracion.cs` | CREAR | Interfaz e integración de Nube MYG. |
| 22 | `MYG.Desktop/NubeForm.cs` | CREAR | Interfaz e integración de Nube MYG. |
| 23 | `MYG.Desktop/NubePublicarForm.cs` | CREAR | Interfaz e integración de Nube MYG. |
| 24 | `MYG.Desktop/PermisosPanelNube.cs` | CREAR | Interfaz e integración de Nube MYG. |
| 25 | `MYG.Desktop/PresupuestosContextoACU.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 26 | `MYG.Desktop/PresupuestosExcelEditor.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 27 | `MYG.Desktop/PresupuestosExcelPanel.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 28 | `MYG.Desktop/PresupuestosExcelReferenciasPartidas.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 29 | `MYG.Desktop/PresupuestosExcelZoom.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 30 | `MYG.Desktop/PresupuestosPanel.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 31 | `MYG.Desktop/ProyectosAbiertos.cs` | REEMPLAZAR | Integración de permisos de nube conservando el trabajo local. |
| 32 | `MYG.Pruebas/ColaboracionLocalCheck.cs` | CREAR | Pruebas de persistencia y ejecución de la suite existente. |
| 33 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Pruebas de persistencia y ejecución de la suite existente. |
| 34 | `MYG.PruebasNube/ArchivosNubeCheck.cs` | CREAR | Pruebas de protocolo, sincronización, adjuntos y portabilidad. |
| 35 | `MYG.PruebasNube/MYG.PruebasNube.csproj` | CREAR | Pruebas de protocolo, sincronización, adjuntos y portabilidad. |
| 36 | `MYG.PruebasNube/PaqueteNubeCheck.cs` | CREAR | Pruebas de protocolo, sincronización, adjuntos y portabilidad. |
| 37 | `MYG.PruebasNube/Program.cs` | CREAR | Pruebas de protocolo, sincronización, adjuntos y portabilidad. |
| 38 | `MYG.PruebasNube/SincronizacionCheck.cs` | CREAR | Pruebas de protocolo, sincronización, adjuntos y portabilidad. |
| 39 | `supabase/README-NUBE.md` | CREAR | Instalación administrativa y límites de las pruebas remotas. |
| 40 | `supabase/migrations/202610190001_nube_myg.sql` | CREAR | RPC, proyectos, roles, solicitudes, revisiones e identidad verificada. |
| 41 | `supabase/migrations/202610190002_archivos_nube.sql` | CREAR | Bucket privado y permisos de adjuntos; verificación de referencias. |
| 42 | `supabase/tests/archivos_nube_regresion.sql` | CREAR | Regresión local reproducible de PostgreSQL y Storage simulado. |
| 43 | `supabase/tests/ejecutar-pglite.mjs` | CREAR | Regresión local reproducible de PostgreSQL y Storage simulado. |
| 44 | `supabase/tests/nube_myg_regresion.sql` | CREAR | Regresión local reproducible de PostgreSQL y Storage simulado. |


## C. Descarga

Entrega: `bimchimbote-droid/DESCARGAS`, repositorio público ya autorizado.
Nombre: `MYG_PRESUPUESTOS_ACTUALIZACION.zip`.
Se publica en una ruta nueva dentro de `MYG.Presupuestos/entrega-.../` y se entrega
un enlace fijado al commit de publicación. El SHA-256 del ZIP y el resultado real
de su descarga se indican en la respuesta de entrega.
Este documento no contiene enlaces anticipados ni credenciales.

## D. Instalación manual

1. Cierre MYG y haga una copia de seguridad o un Commit de sus avances locales.
   Respalde también las bases SQLite; el ZIP no contiene ni sustituye sus bases.
2. En Visual Studio compruebe que tiene abierta la carpeta
   `D:\ADDIN\repos\MYG.Presupuestos_GITHUB` y la rama `main`.
3. Descargue y extraiga el ZIP en una carpeta temporal. Copie su contenido a la raíz
   del proyecto conservando las rutas. Cree las carpetas nuevas. Reemplace sólo los
   archivos indicados. Si alguno tiene cambios posteriores a 9ea48001e159a0120a86583d18b0dce89df7d787,
   concilie las diferencias antes de reemplazarlo completo.
4. Los proyectos SDK de .NET incluyen automáticamente los `.cs` nuevos de sus carpetas.
   `MYG.PruebasNube` es un proyecto de pruebas adicional; puede agregar su `.csproj`
   a la solución desde Visual Studio, o ejecutarlo directamente con el comando de F.
   No es necesario sustituir los `.csproj` existentes ni la solución.
5. Instale las migraciones y configure la identidad según E. Después restaure,
   compile y ejecute las pruebas indicadas en F.
6. En Windows abra MYG, mantenga su sesión/licencia habitual y pulse **Nube MYG**.
   Configure la URL HTTPS de su Supabase y su clave publicable/anon; inicie la sesión
   de nube de la cuenta verificada. Nunca introduzca una clave `service_role` en el programa.
7. Cree/publique una obra de prueba. Conceda acceso a una segunda cuenta, ábrala desde
   otro equipo y compruebe edición, conflicto, permiso de lector y descarga antes de
   utilizar datos de trabajo reales.

## E. Configuraciones adicionales

Requiere .NET SDK **10.0.100**, SQLite y las referencias ya declaradas por el repositorio.
No se añadieron paquetes NuGet al programa. La UI requiere Windows y .NET Desktop.
La API de Revit sólo se ejecuta en Revit 2027; sus paquetes de referencia permiten compilar en Linux.

Un administrador de Supabase debe revisar y ejecutar, una sola vez y en este orden:

1. `supabase/migrations/202610190001_nube_myg.sql`
2. `supabase/migrations/202610190002_archivos_nube.sql`

Consulte `supabase/README-NUBE.md` antes de ejecutarlas. El piloto DEMO anterior
queda separado. No ejecute las pruebas SQL en una base de producción ni cree allí
los fixtures simulados del ejecutor de pruebas.
Mantenga `myg_nube_privado` fuera de Exposed schemas; el bucket `myg-nube-archivos`
debe ser privado. Son necesarios Auth y Storage reales y conectividad a su dominio Supabase.

La autoridad administrativa debe verificar la relación entre ambas cuentas y
provisionar `myg_nube_privado.identidades_verificadas`. El repositorio no tiene un
puente automático que acredite esa relación; coincidir en correo no basta. Sin esa
provisión las RPC rechazan el acceso, incluso con login Supabase correcto.
Las claves de administración no se distribuyen, no se guardan en la UI ni se solicitan por chat.
No se aplicaron migraciones ni se configuró un Supabase remoto durante esta entrega.

## F. Compilación y validación

Desde la raíz del proyecto, con SDK .NET 10.0.100:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release
```

En una estación con Revit 2027 instalado puede compilar con sus DLL locales en vez
de `UseRevitReferencePackages=true`, siguiendo la configuración existente.

Resultados ejecutados en Linux:

- Solución completa Release: **0 errores, 0 advertencias**.
- Suite general: **566 comprobaciones correctas** (incluye 13 escenarios nuevos de persistencia).
- Cliente HTTP: **787 comprobaciones de contrato**, con HTTP simulado.
- Sincronización: **9 casos / 110 comprobaciones**, con SQLite real y HTTP simulado.
- Adjuntos privados: **8 casos / 61 comprobaciones** HTTP simuladas.
- Portabilidad: **25 comprobaciones** SQLite reales de aislamiento, rutas, adjuntos y catálogos.
- Ambas migraciones y regresiones SQL: correctas en **PGlite 0.3.14**, Auth/Storage simulados,
  con `ROLLBACK` y sin datos de prueba residuales.

Se comprobó pérdida de ACK, reintento con los mismos bytes/UUID, persistencia tras
reabrir SQLite, cambios de catálogo sin cambio del documento, conflicto sin perder
borradores, retirada de acceso, lectura sin escritura y rechazo de identidad ajena.
Las rutas recibidas no provocan lectura de archivos locales no incorporados como
adjuntos verificados. Compartir una obra no incluye las otras obras de su base.
Una recarga de base completa actualiza también sus obras secundarias: primero se
prepara la nueva hoja y su vínculo, después se reemplaza la copia de trabajo de
forma atómica conservando un respaldo `*.antes-r*.sqlite`. Un snapshot inválido no
avanza la revisión ni sustituye el trabajo anterior.

La UI Windows, Revit, licencia real, instalador, Supabase HTTP real y concurrencia
con dos cuentas reales no se ejecutaron en Linux. Las pruebas opcionales con bases
externas privadas y Named Pipes de Windows permanecen omitidas/no ejecutadas según
las condiciones de la suite existente. Compilar la UI no equivale a ejecutarla.

## G. Publicación del código por el usuario

1. En **Cambios de Git** de Visual Studio revise los archivos y sus diferencias.
2. Confirme que no añadió bases privadas, configuración personal, contraseñas ni salidas `bin/obj`.
3. Haga Commit de los cambios revisados y después Push a `main` cuando lo decida.
4. Compruebe el commit y la rama en `https://github.com/bimchimbote-droid/MYG.Presupuestos`.

La autorización de esta entrega sólo permite publicar el ZIP en DESCARGAS.
No se publicó ningún cambio en el repositorio del código. Descargar el ZIP tampoco
significa que ya se haya aplicado en su equipo.

## H. Límites y comprobaciones pendientes

- La colaboración manual usa revisión y conflicto del paquete completo; no fusiona
  celdas o APU automáticamente. En bases con varias obras, **Mantener local** no
  reemplaza silenciosamente las otras obras: conserve una copia independiente y
  concilie explícitamente; **Usar remoto** recupera la base completa con respaldo.
- La publicación de base completa incluye todas sus obras reconocidas; al abrir
  desde Nube se edita su obra principal. Para compartir otra obra por separado,
  publíquela con alcance obra. Las descargas completas conservan sus otras obras.
- Las tablas/columnas de extensiones no reconocidas y los datos administrativos,
  cuentas y credenciales se excluyen y permanecen en el original. Los avisos de
  alcance se muestran antes de publicar. No se garantiza compatibilidad con toda
  extensión externa de Delphin sin una prueba específica.
- Se incorporan las imágenes y fichas referidas por los campos que reconoce el
  paquete. Los archivos faltantes se informan; una ruta externa no resuelta no se
  ejecuta ni se consulta en el equipo receptor. Verifique sus documentos externos.
- Límite del cliente: 31 MiB de datos JSON estructurados y 20 MiB por adjunto.
  Se requiere una política administrativa de capacidad, historial y limpieza de
  objetos sin referencia para bases grandes.
- La ventana gestiona solicitudes recibidas del proyecto. Un panel independiente
  de solicitudes enviadas, un visor de actividad y un puente automático de identidad
  no forman parte de esta entrega; el historial sí se conserva en el servidor.
- Un permiso retirado no borra las copias previamente descargadas. La publicación
  real y las pruebas entre dos equipos requieren la configuración administrativa de E.
- Reemplazar archivos completos sobre cambios locales o posteriores sin conciliarlos
  puede perder esos cambios: respalde y revise antes de copiar.
