-- Prueba administrativa SOLO en base desechable/local; Auth simulado, no login real.
-- Requiere la migración v2 y un ejecutor administrador capaz de SET ROLE.
-- Termina con ROLLBACK. No ejecutar en producción ni con sesiones reales.
begin;
set local lock_timeout = '5s';

insert into auth.users(id) values
 ('10000000-0000-0000-0000-000000000001'),
 ('10000000-0000-0000-0000-000000000002'),
 ('10000000-0000-0000-0000-000000000003'),
 ('10000000-0000-0000-0000-000000000004');
insert into myg_nube_privado.identidades_verificadas(auth_usuario_id, usuario_myg, evidencia_verificacion) values
 ('10000000-0000-0000-0000-000000000001', 'prueba-propietario', 'fixture local, no identidad de producción'),
 ('10000000-0000-0000-0000-000000000002', 'prueba-editor', 'fixture local, no identidad de producción'),
 ('10000000-0000-0000-0000-000000000003', 'prueba-lector', 'fixture local, no identidad de producción');

create function pg_temp.comprobar(p_valor boolean, p_mensaje text) returns void
language plpgsql as $$ begin
 if p_valor is distinct from true then raise exception 'FALLO: %', p_mensaje; end if;
end; $$;
create function pg_temp.usuario(p_usuario uuid) returns void language plpgsql as $$ begin
 perform set_config('request.jwt.claim.sub', coalesce(p_usuario::text, ''), true);
 perform set_config('request.jwt.claims', jsonb_build_object('sub', p_usuario, 'role', 'authenticated')::text, true);
end; $$;
create function pg_temp.rechaza(p_sql text, p_estado text) returns void language plpgsql as $$
declare v_estado text;
begin
 begin execute p_sql;
 exception when others then get stacked diagnostics v_estado = returned_sqlstate;
 end;
 if v_estado is distinct from p_estado then
   raise exception 'FALLO: se esperaba %, llegó % para %', p_estado, v_estado, p_sql;
 end if;
end; $$;

do $$ declare v_tabla text; v_rpc regprocedure; begin
 foreach v_tabla in array array['myg_nube_proyectos','myg_nube_miembros','myg_nube_solicitudes','myg_nube_operaciones','myg_nube_historial'] loop
   perform pg_temp.comprobar((select relrowsecurity from pg_class where oid = ('public.' || v_tabla)::regclass), 'RLS ' || v_tabla);
   perform pg_temp.comprobar(not has_table_privilege('authenticated', 'public.' || v_tabla, 'SELECT,INSERT,UPDATE,DELETE'), 'tabla cerrada authenticated ' || v_tabla);
   perform pg_temp.comprobar(not has_table_privilege('anon', 'public.' || v_tabla, 'SELECT,INSERT,UPDATE,DELETE'), 'tabla cerrada anon ' || v_tabla);
 end loop;
 perform pg_temp.comprobar(not has_schema_privilege('authenticated', 'myg_nube_privado', 'USAGE'), 'esquema privado');
 for v_rpc in select p.oid::regprocedure from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' and p.proname like 'myg_nube_%' loop
   perform pg_temp.comprobar(has_function_privilege('authenticated', v_rpc, 'EXECUTE'), 'RPC disponible authenticated');
   perform pg_temp.comprobar(not has_function_privilege('anon', v_rpc, 'EXECUTE'), 'RPC cerrada anon');
 end loop;
end; $$;

set local role authenticated;
select pg_temp.usuario(null);
select pg_temp.rechaza('select public.myg_nube_listar()', '42501');
select pg_temp.usuario('10000000-0000-0000-0000-000000000004');
select pg_temp.rechaza('select public.myg_nube_listar()', '42501');
-- Ninguna RPC permite saltarse la vinculación verificada.
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000001','X','{}','obra')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_abrir('20000000-0000-0000-0000-000000000001')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,'{}')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_solicitar('MYG-DESCONOCIDO')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_miembros('20000000-0000-0000-0000-000000000001')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_solicitudes('20000000-0000-0000-0000-000000000001')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_resolver('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','editor',true)$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','editor')$q$, '42501');

select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
select pg_temp.comprobar(public.myg_nube_listar() = '[]'::jsonb, 'lista inicial vacía');
do $$ declare v_resultado jsonb; begin
 v_resultado := public.myg_nube_crear('20000000-0000-0000-0000-000000000001', 'Obra Uno', '{"datos":"inicial"}', 'obra');
 perform pg_temp.comprobar(v_resultado->>'rol' = 'propietario' and v_resultado->>'revision' = '1'
   and v_resultado->'contenido' = '{"datos":"inicial"}'::jsonb, 'creación y snapshot');
 perform pg_temp.comprobar(not ((public.myg_nube_listar()->0) ? 'contenido'), 'listado sin contenido');
end; $$;
select pg_temp.rechaza($q$select public.myg_nube_crear('00000000-0000-0000-0000-000000000000','X','{}','obra')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','X','[]','obra')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','X','{}','otro')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002',repeat('x',201),'{}','obra')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','X',jsonb_build_object('x',repeat('x',33554432)),'obra')$q$, '22023');
select pg_temp.rechaza($q$select * from public.myg_nube_proyectos$q$, '42501');
select pg_temp.rechaza($q$update public.myg_nube_proyectos set revision=99$q$, '42501');
select pg_temp.rechaza($q$insert into myg_nube_privado.identidades_verificadas values ('10000000-0000-0000-0000-000000000004','intruso',true,'autoenlace',now())$q$, '42501');

select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
select pg_temp.comprobar(public.myg_nube_listar() = '[]'::jsonb, 'cuenta distinta sin contenido');
select pg_temp.rechaza($q$select public.myg_nube_abrir('20000000-0000-0000-0000-000000000001')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Apropiación','{}','obra')$q$, '42501');
select pg_temp.comprobar(public.myg_nube_solicitar('MYG-20000000000000000000000000000001') = public.myg_nube_solicitar('DESCONOCIDO'), 'solicitud no enumera código');
select pg_temp.rechaza($q$select public.myg_nube_abrir('20000000-0000-0000-0000-000000000001')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_miembros('20000000-0000-0000-0000-000000000001')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_resolver('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','editor',true)$q$, '42501');

select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
select pg_temp.comprobar(jsonb_array_length(public.myg_nube_solicitudes('20000000-0000-0000-0000-000000000001')) = 1, 'solicitud visible propietario');
select pg_temp.comprobar(public.myg_nube_resolver('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','editor',true), 'aprobar editor');
select pg_temp.comprobar(public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000003','lector'), 'asignar lector');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001',null)$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','propietario')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000004','editor')$q$, '22023');

select pg_temp.usuario('10000000-0000-0000-0000-000000000003');
select pg_temp.comprobar(public.myg_nube_abrir('20000000-0000-0000-0000-000000000001')->>'rol' = 'lector', 'lector abre');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,'{}')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000003','editor')$q$, '42501');

select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
do $$ declare v_primera jsonb; v_reintento jsonb; v_conflicto jsonb; begin
 v_primera := public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,'{"datos":"editor"}');
 perform pg_temp.comprobar(v_primera->>'estado' = 'aplicada' and v_primera->>'revision' = '2', 'editor guarda');
 v_reintento := public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,'{"datos":"editor"}');
 perform pg_temp.comprobar(v_primera = v_reintento, 'reintento exacto');
 v_conflicto := public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002',1,'{"datos":"antiguo"}');
 perform pg_temp.comprobar(v_conflicto->>'estado' = 'conflicto' and v_conflicto->>'revision' = '2'
   and v_conflicto->'contenido' = '{"datos":"editor"}'::jsonb, 'conflicto conserva servidor');
 perform pg_temp.comprobar(v_conflicto = public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002',1,'{"datos":"antiguo"}'), 'conflicto idempotente');
end; $$;
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,'{"otro":true}')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000000',2,'{}')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000004',0,'{}')$q$, '22023');

select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
-- Reusar UUID de otra cuenta es otra operación (ámbito usuario+UUID).
select pg_temp.comprobar(public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',2,'{"datos":"propietario"}')->>'revision' = '3', 'UUID aislado por usuario');
select pg_temp.comprobar(public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Obra Uno','{"datos":"inicial"}','obra')->>'revision' = '3', 'reintento crear conserva revisión');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Otro nombre','{"datos":"inicial"}','obra')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Obra Uno','{"datos":"cambiado"}','obra')$q$, '22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Obra Uno','{"datos":"inicial"}','base')$q$, '22023');
select pg_temp.comprobar(public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','administrador'), 'ascender administrador');

select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000003','administrador')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','lector')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002',null)$q$, '42501');
select pg_temp.comprobar(public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000003','editor'), 'administrador cambia lector');

select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002',null);
select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',1,'{"datos":"editor"}')$q$, '42501');
select pg_temp.rechaza($q$select public.myg_nube_abrir('20000000-0000-0000-0000-000000000001')$q$, '42501');

set local role anon;
select pg_temp.rechaza('select public.myg_nube_listar()', '42501');
select pg_temp.rechaza('select * from public.myg_nube_proyectos', '42501');
reset role;
update myg_nube_privado.identidades_verificadas set activo=false where auth_usuario_id='10000000-0000-0000-0000-000000000001';
set local role authenticated;
select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',2,'{"datos":"propietario"}')$q$, '42501');
reset role;
select pg_temp.comprobar((select count(*) = 3 from public.myg_nube_historial), 'historial solo revisiones aplicadas');
select pg_temp.comprobar((select count(*) = 3 from public.myg_nube_operaciones), 'operaciones sin duplicados');
select pg_temp.comprobar((select revision = 3 and contenido = '{"datos":"propietario"}'::jsonb from public.myg_nube_proyectos), 'estado final consistente');
select pg_temp.comprobar((select count(*) = 1 from public.myg_nube_miembros where rol='propietario'), 'propietario permanece');
select 'PRUEBA_NUBE_MYG_CORRECTA' as resultado;
rollback;
