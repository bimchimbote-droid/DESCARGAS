// Solo PostgreSQL en memoria: no acepta conexiones ni claves de un servicio remoto.
// Instalar @electric-sql/pglite@0.3.14 junto a una copia de este ejecutor; ver README.
import { PGlite } from '@electric-sql/pglite';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const raiz = resolve(process.argv[2] || process.cwd());
const db = new PGlite();
try {
  await db.exec(`
    create role anon;
    create role authenticated;
    create role service_role bypassrls;
    create schema auth;
    create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
    $$;
    grant usage on schema auth to anon, authenticated, service_role;
    grant execute on function auth.uid() to anon, authenticated, service_role;
  `);
  await db.exec(await readFile(resolve(raiz, 'supabase/migrations/202610190001_nube_myg.sql'), 'utf8'));
  console.log('MIGRACION_NUBE_MYG_CORRECTA');
  const resultados = await db.exec(await readFile(resolve(raiz, 'supabase/tests/nube_myg_regresion.sql'), 'utf8'));
  if (!resultados.some(r => r.rows?.some(f => f.resultado === 'PRUEBA_NUBE_MYG_CORRECTA'))) {
    throw new Error('Falta la confirmación final de la regresión SQL.');
  }
  const verificacion = await db.query('select count(*)::int as cantidad from public.myg_nube_proyectos');
  if (verificacion.rows[0].cantidad !== 0) throw new Error('La prueba no revirtió sus datos.');
  console.log('PRUEBA_NUBE_MYG_CORRECTA; ROLLBACK_CORRECTO');
  // Fixture mínimo del catálogo Storage. No emula el servidor HTTP ni almacena bytes.
  await db.exec(`
    create schema storage;
    create table storage.buckets(id text primary key,name text not null,public boolean not null default false,file_size_limit bigint);
    create table storage.objects(bucket_id text not null references storage.buckets(id),name text not null,metadata jsonb default '{}',primary key(bucket_id,name));
    alter table storage.objects enable row level security;
    grant usage on schema storage to anon,authenticated;
    grant select,insert,update,delete on storage.objects to anon,authenticated;
    -- Simula políticas amplias de otra aplicación: las restrictivas MYG deben prevalecer.
    create policy fixture_storage_otra_aplicacion on storage.objects for all to authenticated,anon using(true) with check(true);
    insert into storage.buckets(id,name,public) values('otra-aplicacion','otra-aplicacion',false);
  `);
  await db.exec(await readFile(resolve(raiz, 'supabase/migrations/202610190002_archivos_nube.sql'), 'utf8'));
  console.log('MIGRACION_ARCHIVOS_NUBE_CORRECTA');
  const archivos = await db.exec(await readFile(resolve(raiz, 'supabase/tests/archivos_nube_regresion.sql'), 'utf8'));
  if (!archivos.some(r => r.rows?.some(f => f.resultado === 'PRUEBA_ARCHIVOS_NUBE_CORRECTA'))) {
    throw new Error('Falta la confirmación final de la regresión de archivos.');
  }
  const finales = await db.query('select (select count(*) from public.myg_nube_proyectos)::int as proyectos,(select count(*) from storage.objects)::int as archivos');
  if (finales.rows[0].proyectos !== 0 || finales.rows[0].archivos !== 0) throw new Error('La prueba de archivos no revirtió sus datos.');
  console.log('PRUEBA_ARCHIVOS_NUBE_CORRECTA; ROLLBACK_CORRECTO');
} catch (error) {
  console.error(error.message, error.code || '', error.where || '');
  process.exitCode = 1;
} finally {
  await db.close();
}
