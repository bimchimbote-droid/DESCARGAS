-- Catálogo Storage y Auth simulados. Ejecutar sólo en base desechable con ambas migraciones.
-- No crea archivos ni utiliza sesiones, claves o datos de producción.
begin;
set local lock_timeout='5s';
insert into auth.users(id) values
 ('10000000-0000-0000-0000-000000000001'),
 ('10000000-0000-0000-0000-000000000002'),
 ('10000000-0000-0000-0000-000000000003'),
 ('10000000-0000-0000-0000-000000000004');
insert into myg_nube_privado.identidades_verificadas(auth_usuario_id,usuario_myg,evidencia_verificacion) values
 ('10000000-0000-0000-0000-000000000001','archivos-propietario','fixture sintético local'),
 ('10000000-0000-0000-0000-000000000002','archivos-lector','fixture sintético local'),
 ('10000000-0000-0000-0000-000000000003','archivos-otra-cuenta','fixture sintético local');

create function pg_temp.comprobar(p_valor boolean,p_mensaje text) returns void language plpgsql as $$ begin
 if p_valor is distinct from true then raise exception 'FALLO ARCHIVOS: %',p_mensaje; end if;
end $$;
create function pg_temp.usuario(p_usuario uuid) returns void language plpgsql as $$ begin
 perform set_config('request.jwt.claim.sub',coalesce(p_usuario::text,''),true);
end $$;
create function pg_temp.rechaza(p_sql text,p_estado text) returns void language plpgsql as $$
declare v_estado text;
begin
 begin execute p_sql;
 exception when others then get stacked diagnostics v_estado=returned_sqlstate;
 end;
 if v_estado is distinct from p_estado then
   raise exception 'FALLO ARCHIVOS: se esperaba %, llegó % en %',p_estado,v_estado,p_sql;
 end if;
end $$;
create function pg_temp.ruta(p_usuario uuid,p_hash text default repeat('a',64)) returns text language sql immutable as $$
 select p_usuario::text || '/30000000000000000000000000000001/' || p_hash
$$;
create function pg_temp.paquete(p_ruta text,p_hash text default repeat('a',64)) returns jsonb language sql immutable as $$
 select jsonb_build_object('alcance','obra','documento',jsonb_build_object('Id','MYG-PRUEBA-ARCHIVOS'),
   'recursos',jsonb_build_array(jsonb_build_object('Almacen',p_ruta,'Sha256',p_hash,'Base64','')))
$$;

select pg_temp.comprobar((select not public and file_size_limit=20971520 from storage.buckets where id='myg-nube-archivos'),'bucket privado y límite20MiB');
select pg_temp.comprobar((select relrowsecurity from pg_class where oid='storage.objects'::regclass),'RLS Storage');
select pg_temp.comprobar(not has_table_privilege('authenticated','myg_nube_privado.identidades_verificadas','SELECT,INSERT,UPDATE,DELETE'),'vínculo no expuesto');

set local role authenticated;
select pg_temp.usuario('10000000-0000-0000-0000-000000000004');
select pg_temp.rechaza($q$insert into storage.objects(bucket_id,name) values('myg-nube-archivos',pg_temp.ruta('10000000-0000-0000-0000-000000000004'))$q$,'42501');
select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
insert into storage.objects(bucket_id,name,metadata) values
 ('myg-nube-archivos',pg_temp.ruta('10000000-0000-0000-0000-000000000001'),'{"size":8}');
select pg_temp.comprobar((select count(*)=1 from storage.objects where bucket_id='myg-nube-archivos'),'subida propia y lectura');
select pg_temp.rechaza($q$insert into storage.objects(bucket_id,name) values('myg-nube-archivos',pg_temp.ruta('10000000-0000-0000-0000-000000000002'))$q$,'42501');
select pg_temp.rechaza($q$insert into storage.objects(bucket_id,name) values('myg-nube-archivos','10000000-0000-0000-0000-000000000001/../otro')$q$,'42501');
select pg_temp.rechaza($q$insert into storage.objects(bucket_id,name) values('myg-nube-archivos',pg_temp.ruta('10000000-0000-0000-0000-000000000001'))$q$,'23505');
-- Las políticas restrictivas deben impedir cambios incluso con permiso permisivo global.
do $$ declare n integer; begin
 update storage.objects set metadata='{"size":9}' where bucket_id='myg-nube-archivos'; get diagnostics n=row_count;
 perform pg_temp.comprobar(n=0,'archivo inmutable: UPDATE sin filas');
 delete from storage.objects where bucket_id='myg-nube-archivos'; get diagnostics n=row_count;
 perform pg_temp.comprobar(n=0,'archivo retenido: DELETE sin filas');
end $$;
insert into storage.objects(bucket_id,name) values('otra-aplicacion','archivo-de-otra-aplicacion');
update storage.objects set metadata='{"otra":true}' where bucket_id='otra-aplicacion';
select pg_temp.comprobar((select metadata->>'otra'='true' from storage.objects where bucket_id='otra-aplicacion'),'políticas de otra aplicación conservadas');

select pg_temp.comprobar(public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Obra con adjunto',
 pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001')),'obra')->>'revision'='1','creación con referencia privada');
select pg_temp.comprobar(public.myg_nube_crear('20000000-0000-0000-0000-000000000001','Obra con adjunto',
 pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001')),'obra')->>'revision'='1','reintento de creación exacto');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','Alcance distinto','{"alcance":"base","recursos":[]}','obra')$q$,'22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','Inline',jsonb_set(pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001')),'{recursos,0,Base64}','"YQ=="'),'obra')$q$,'22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','Inexistente',pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001',repeat('b',64)),repeat('b',64)),'obra')$q$,'22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','Hash distinto',pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001'),repeat('b',64)),'obra')$q$,'22023');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000002','Recursos inválidos','{"alcance":"obra","recursos":{}}','obra')$q$,'22023');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000001',1,'{"alcance":"base","recursos":[]}')$q$,'22023');

select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
select pg_temp.comprobar((select count(*)=0 from storage.objects where bucket_id='myg-nube-archivos'),'cuenta sin miembro no lee');
select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','lector');
select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
select pg_temp.comprobar((select count(*)=1 from storage.objects where bucket_id='myg-nube-archivos'),'lector miembro lee adjunto');
select pg_temp.rechaza($q$select public.myg_nube_guardar('20000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000002',1,pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001')))$q$,'42501');

select pg_temp.usuario('10000000-0000-0000-0000-000000000003');
insert into storage.objects(bucket_id,name) values('myg-nube-archivos',pg_temp.ruta('10000000-0000-0000-0000-000000000003',repeat('c',64)));
select pg_temp.comprobar((select count(*)=1 from storage.objects where bucket_id='myg-nube-archivos'),'otra cuenta sólo lee su propia subida');
select pg_temp.rechaza($q$select public.myg_nube_crear('20000000-0000-0000-0000-000000000003','Referencia ajena',pg_temp.paquete(pg_temp.ruta('10000000-0000-0000-0000-000000000001')),'obra')$q$,'22023');

select pg_temp.usuario('10000000-0000-0000-0000-000000000001');
select public.myg_nube_rol('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002',null);
select pg_temp.usuario('10000000-0000-0000-0000-000000000002');
select pg_temp.comprobar((select count(*)=0 from storage.objects where bucket_id='myg-nube-archivos'),'retiro impide lectura antes autorizada');

reset role;
update myg_nube_privado.identidades_verificadas set activo=false where auth_usuario_id='10000000-0000-0000-0000-000000000003';
set local role authenticated;
select pg_temp.usuario('10000000-0000-0000-0000-000000000003');
select pg_temp.comprobar((select count(*)=0 from storage.objects where bucket_id='myg-nube-archivos'),'vínculo inactivo ni siquiera lee su propia subida');
set local role anon;
select pg_temp.usuario(null);
select pg_temp.comprobar((select count(*)=0 from storage.objects where bucket_id='myg-nube-archivos'),'anónimo no lee pese a política amplia ajena');
select pg_temp.rechaza($q$insert into storage.objects(bucket_id,name) values('myg-nube-archivos',pg_temp.ruta('10000000-0000-0000-0000-000000000001',repeat('d',64)))$q$,'42501');
reset role;
select pg_temp.comprobar((select count(*)=1 from public.myg_nube_proyectos),'errores de paquete no publicaron proyectos parciales');
select pg_temp.comprobar((select count(*)=1 from public.myg_nube_historial),'sin revisiones de intentos rechazados');
select 'PRUEBA_ARCHIVOS_NUBE_CORRECTA' as resultado;
rollback;
