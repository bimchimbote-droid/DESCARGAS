-- Adjuntos de Nube MYG. Aplicar después de 202610190001_nube_myg.sql.
begin;
do $$ begin
    if to_regclass('storage.objects') is null or to_regclass('storage.buckets') is null then
        raise exception 'Se necesita Supabase Storage antes de instalar los adjuntos MYG.';
    end if;
end $$;

insert into storage.buckets(id,name,public,file_size_limit)
values ('myg-nube-archivos','myg-nube-archivos',false,20971520)
on conflict(id) do nothing;
do $$ begin
    if exists(select 1 from storage.buckets where id='myg-nube-archivos' and public) then
        raise exception 'El bucket MYG existente es público; no se cambió su configuración. Use un bucket privado.';
    end if;
end $$;

create function myg_nube_privado.puede_leer_archivo(p_nombre text) returns boolean
language plpgsql stable security definer set search_path=pg_catalog,myg_nube_privado as $$
declare v_usuario uuid := auth.uid();
begin
    if v_usuario is null or not exists(select 1 from myg_nube_privado.identidades_verificadas
        where auth_usuario_id=v_usuario and activo) then return false; end if;
    if p_nombre !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}$' then
        return false;
    end if;
    return split_part(p_nombre,'/',1)=v_usuario::text or exists(
        select 1 from public.myg_nube_proyectos p
        join public.myg_nube_miembros m on m.proyecto_id=p.id and m.usuario_id=v_usuario
        where exists(select 1 from jsonb_array_elements(coalesce(p.contenido->'recursos','[]'::jsonb)) r
            where r->>'Almacen'=p_nombre));
end $$;

create function myg_nube_privado.puede_subir_archivo(p_nombre text) returns boolean
language plpgsql stable security definer set search_path=pg_catalog,myg_nube_privado as $$
declare v_usuario uuid := auth.uid();
begin
    return v_usuario is not null and exists(select 1 from myg_nube_privado.identidades_verificadas
        where auth_usuario_id=v_usuario and activo)
        and p_nombre ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}$'
        and split_part(p_nombre,'/',1)=v_usuario::text;
end $$;

-- Las funciones sólo consultan reglas; no permiten ejecutar SQL del cliente.
revoke all on function myg_nube_privado.puede_leer_archivo(text),myg_nube_privado.puede_subir_archivo(text)
    from public,anon,authenticated;
grant usage on schema myg_nube_privado to authenticated;
grant execute on function myg_nube_privado.puede_leer_archivo(text),myg_nube_privado.puede_subir_archivo(text)
    to authenticated;

create policy myg_nube_archivos_insertar on storage.objects for insert to authenticated
    with check(bucket_id='myg-nube-archivos' and myg_nube_privado.puede_subir_archivo(name));
create policy myg_nube_archivos_leer on storage.objects for select to authenticated
    using(bucket_id='myg-nube-archivos' and myg_nube_privado.puede_leer_archivo(name));
-- Restrictivas para impedir que políticas amplias preexistentes abran este bucket.
create policy myg_nube_archivos_cerrar_lectura on storage.objects as restrictive for select to authenticated
    using(bucket_id<>'myg-nube-archivos' or myg_nube_privado.puede_leer_archivo(name));
create policy myg_nube_archivos_cerrar_insercion on storage.objects as restrictive for insert to authenticated
    with check(bucket_id<>'myg-nube-archivos' or myg_nube_privado.puede_subir_archivo(name));
create policy myg_nube_archivos_inmutables on storage.objects as restrictive for update to authenticated
    using(bucket_id<>'myg-nube-archivos') with check(bucket_id<>'myg-nube-archivos');
create policy myg_nube_archivos_conservar on storage.objects as restrictive for delete to authenticated
    using(bucket_id<>'myg-nube-archivos');
create policy myg_nube_archivos_anon on storage.objects as restrictive for all to anon
    using(bucket_id<>'myg-nube-archivos') with check(bucket_id<>'myg-nube-archivos');

create function myg_nube_privado.validar_paquete_archivos() returns trigger
language plpgsql security definer set search_path=pg_catalog,myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_recurso jsonb; v_nombre text;
begin
    if new.contenido->>'alcance' is distinct from new.alcance then
        raise exception using errcode='22023',message='MYG_ALCANCE_NO_COINCIDE';
    end if;
    if new.contenido ? 'recursos' and jsonb_typeof(new.contenido->'recursos')<>'array' then
        raise exception using errcode='22023',message='MYG_RECURSOS_INVALIDOS';
    end if;
    for v_recurso in select value from jsonb_array_elements(coalesce(new.contenido->'recursos','[]'::jsonb)) loop
        v_nombre := v_recurso->>'Almacen';
        if coalesce(v_recurso->>'Base64','')<>'' or v_nombre is null
            or not myg_nube_privado.puede_leer_archivo(v_nombre)
            or lower(v_recurso->>'Sha256') is distinct from split_part(v_nombre,'/',3)
            or not exists(select 1 from storage.objects where bucket_id='myg-nube-archivos' and name=v_nombre) then
            raise exception using errcode='22023',message='MYG_ADJUNTO_NO_DISPONIBLE';
        end if;
    end loop;
    return new;
end $$;
revoke all on function myg_nube_privado.validar_paquete_archivos() from public,anon,authenticated;
create trigger myg_nube_validar_adjuntos before insert or update of contenido,alcance
    on public.myg_nube_proyectos for each row execute function myg_nube_privado.validar_paquete_archivos();

notify pgrst,'reload schema';
commit;
