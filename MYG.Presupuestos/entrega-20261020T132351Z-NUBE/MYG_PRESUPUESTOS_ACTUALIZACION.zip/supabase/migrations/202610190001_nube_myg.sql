-- Nube MYG v2. Independiente de las tablas/RPC del piloto myg_* existente.
-- Ejecutar como administrador de la base (no desde el cliente de escritorio).
begin;
set local lock_timeout = '5s';

do $$
begin
    if to_regclass('auth.users') is null or to_regprocedure('auth.uid()') is null
       or not exists (select 1 from pg_roles where rolname = 'authenticated')
       or not exists (select 1 from pg_roles where rolname = 'anon')
       or not exists (select 1 from pg_roles where rolname = 'service_role') then
        raise exception 'Nube MYG requiere Supabase Auth y sus roles de base de datos.';
    end if;
    if to_regnamespace('myg_nube_privado') is not null
       or to_regclass('public.myg_nube_proyectos') is not null
       or to_regclass('public.myg_nube_miembros') is not null
       or to_regclass('public.myg_nube_solicitudes') is not null
       or to_regclass('public.myg_nube_operaciones') is not null
       or to_regclass('public.myg_nube_historial') is not null then
        raise exception 'Ya existe parte de Nube MYG v2. No se sobrescribió; revise el historial de migraciones.';
    end if;
end;
$$;

create schema myg_nube_privado;
revoke all on schema myg_nube_privado from public, anon, authenticated;
comment on schema myg_nube_privado is 'Nube MYG v2: NO agregar este esquema a Exposed schemas de Data API.';

-- Una autoridad de identidad debe verificar ambas cuentas antes de insertar aquí.
-- La licencia MYG no es un rol del proyecto. No confiar en email ni user_metadata.
create table myg_nube_privado.identidades_verificadas (
    auth_usuario_id uuid primary key references auth.users(id) on delete cascade,
    usuario_myg text not null unique check (length(btrim(usuario_myg)) between 1 and 256),
    activo boolean not null default true,
    evidencia_verificacion text not null check (length(btrim(evidencia_verificacion)) between 1 and 1000),
    verificado_en timestamptz not null default now()
);
alter table myg_nube_privado.identidades_verificadas enable row level security;
revoke all on myg_nube_privado.identidades_verificadas from public, anon, authenticated;
grant usage on schema myg_nube_privado to service_role;
grant select, insert, update, delete on myg_nube_privado.identidades_verificadas to service_role;

create table public.myg_nube_proyectos (
    id uuid primary key check (id <> '00000000-0000-0000-0000-000000000000'::uuid),
    codigo text not null unique,
    nombre text not null check (length(btrim(nombre)) between 1 and 200),
    propietario uuid not null,
    revision bigint not null default 1 check (revision > 0),
    contenido jsonb not null check (jsonb_typeof(contenido) = 'object' and octet_length(contenido::text) <= 33554432),
    alcance text not null check (alcance in ('obra', 'base')),
    creado_en timestamptz not null default now(),
    actualizado_en timestamptz not null default now()
);
create table public.myg_nube_miembros (
    proyecto_id uuid not null references public.myg_nube_proyectos(id) on delete cascade,
    usuario_id uuid not null,
    rol text not null check (rol in ('propietario', 'administrador', 'editor', 'lector')),
    creado_en timestamptz not null default now(),
    primary key (proyecto_id, usuario_id)
);
create unique index myg_nube_un_propietario on public.myg_nube_miembros(proyecto_id) where rol = 'propietario';
create index myg_nube_miembros_usuario on public.myg_nube_miembros(usuario_id, proyecto_id);
create table public.myg_nube_solicitudes (
    proyecto_id uuid not null references public.myg_nube_proyectos(id) on delete cascade,
    usuario_id uuid not null,
    estado text not null default 'pendiente' check (estado in ('pendiente', 'aprobada', 'rechazada')),
    creado_en timestamptz not null default now(),
    actualizado_en timestamptz not null default now(),
    primary key (proyecto_id, usuario_id)
);
create table public.myg_nube_operaciones (
    usuario_id uuid not null,
    operacion_id uuid not null check (operacion_id <> '00000000-0000-0000-0000-000000000000'::uuid),
    proyecto_id uuid not null references public.myg_nube_proyectos(id) on delete cascade,
    solicitud jsonb not null,
    respuesta jsonb not null,
    creado_en timestamptz not null default now(),
    primary key (usuario_id, operacion_id)
);
create table public.myg_nube_historial (
    proyecto_id uuid not null references public.myg_nube_proyectos(id) on delete cascade,
    revision bigint not null,
    usuario_id uuid not null,
    operacion_id uuid,
    contenido jsonb not null,
    creado_en timestamptz not null default now(),
    primary key (proyecto_id, revision)
);

alter table public.myg_nube_proyectos enable row level security;
alter table public.myg_nube_miembros enable row level security;
alter table public.myg_nube_solicitudes enable row level security;
alter table public.myg_nube_operaciones enable row level security;
alter table public.myg_nube_historial enable row level security;
-- Sin políticas de cliente: toda lectura y escritura pasa por RPC autorizadas.
revoke all on public.myg_nube_proyectos, public.myg_nube_miembros,
    public.myg_nube_solicitudes, public.myg_nube_operaciones,
    public.myg_nube_historial from public, anon, authenticated;

create function myg_nube_privado.identidad() returns uuid
language plpgsql stable security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := auth.uid();
begin
    if v_usuario is null then
        raise exception using errcode = '42501', message = 'MYG_SESION_REQUERIDA';
    end if;
    if not exists (select 1 from myg_nube_privado.identidades_verificadas
                   where auth_usuario_id = v_usuario and activo) then
        raise exception using errcode = '42501', message = 'MYG_VINCULO_NO_VERIFICADO';
    end if;
    return v_usuario;
end;
$$;

create function myg_nube_privado.validar_contenido(p_contenido jsonb) returns void
language plpgsql immutable set search_path = pg_catalog as $$
begin
    if p_contenido is null or jsonb_typeof(p_contenido) <> 'object'
       or octet_length(p_contenido::text) > 33554432 then
        raise exception using errcode = '22023', message = 'MYG_CONTENIDO_INVALIDO_MAX_32_MIB';
    end if;
end;
$$;

create function myg_nube_privado.snapshot(p_id uuid, p_usuario uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog, myg_nube_privado as $$
    select jsonb_build_object('id', p.id, 'codigo', p.codigo, 'nombre', p.nombre,
        'rol', m.rol, 'revision', p.revision, 'alcance', p.alcance, 'contenido', p.contenido)
    from public.myg_nube_proyectos p join public.myg_nube_miembros m
      on m.proyecto_id = p.id and m.usuario_id = p_usuario where p.id = p_id;
$$;

create function public.myg_nube_listar() returns jsonb
language plpgsql stable security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_resultado jsonb;
begin
    select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'codigo', p.codigo,
        'nombre', p.nombre, 'rol', m.rol, 'revision', p.revision, 'alcance', p.alcance)
        order by p.actualizado_en desc, p.id), '[]'::jsonb) into v_resultado
    from public.myg_nube_proyectos p join public.myg_nube_miembros m
      on m.proyecto_id = p.id where m.usuario_id = v_usuario;
    return v_resultado;
end;
$$;

create function public.myg_nube_crear(p_id uuid, p_nombre text, p_contenido jsonb, p_alcance text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_propietario uuid;
begin
    if p_id is null or p_id = '00000000-0000-0000-0000-000000000000'::uuid
       or p_nombre is null or length(btrim(p_nombre)) not between 1 and 200
       or p_alcance is null or p_alcance not in ('obra', 'base') then
        raise exception using errcode = '22023', message = 'MYG_PROYECTO_INVALIDO';
    end if;
    perform myg_nube_privado.validar_contenido(p_contenido);
    -- Serializa reintentos de creación del mismo UUID, incluso antes de existir fila.
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-crear:' || p_id::text, 0));
    select propietario into v_propietario from public.myg_nube_proyectos where id = p_id for update;
    if found then
        if v_propietario <> v_usuario then
            raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
        end if;
        if not exists (select 1 from public.myg_nube_proyectos p
            join public.myg_nube_historial h on h.proyecto_id = p.id and h.revision = 1
            where p.id = p_id and p.nombre = btrim(p_nombre) and p.alcance = p_alcance
                and h.contenido = p_contenido) then
            raise exception using errcode = '22023', message = 'MYG_ID_REUTILIZADO_CON_OTRA_CREACION';
        end if;
        -- Un reintento recupera el proyecto; nunca sobrescribe contenido posterior.
        return myg_nube_privado.snapshot(p_id, v_usuario);
    end if;
    insert into public.myg_nube_proyectos(id, codigo, nombre, propietario, contenido, alcance)
    values (p_id, 'MYG-' || upper(replace(p_id::text, '-', '')), btrim(p_nombre), v_usuario, p_contenido, p_alcance);
    insert into public.myg_nube_miembros(proyecto_id, usuario_id, rol) values (p_id, v_usuario, 'propietario');
    insert into public.myg_nube_historial(proyecto_id, revision, usuario_id, contenido)
    values (p_id, 1, v_usuario, p_contenido);
    return myg_nube_privado.snapshot(p_id, v_usuario);
end;
$$;

create function public.myg_nube_abrir(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_resultado jsonb;
begin
    v_resultado := myg_nube_privado.snapshot(p_id, v_usuario);
    if v_resultado is null then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    return v_resultado;
end;
$$;

create function public.myg_nube_guardar(p_id uuid, p_operacion uuid, p_revision bigint, p_contenido jsonb) returns jsonb
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare
    v_usuario uuid := myg_nube_privado.identidad(); v_proyecto public.myg_nube_proyectos%rowtype;
    v_rol text; v_anterior public.myg_nube_operaciones%rowtype; v_solicitud jsonb; v_respuesta jsonb;
begin
    if p_operacion is null or p_operacion = '00000000-0000-0000-0000-000000000000'::uuid
       or p_revision is null or p_revision < 1 then
        raise exception using errcode = '22023', message = 'MYG_OPERACION_INVALIDA';
    end if;
    perform myg_nube_privado.validar_contenido(p_contenido);
    select * into v_proyecto from public.myg_nube_proyectos where id = p_id for update;
    select rol into v_rol from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = v_usuario;
    -- Revisar permiso actual ANTES de devolver una respuesta histórica/idempotente.
    if v_proyecto.id is null or v_rol is null or v_rol not in ('propietario', 'administrador', 'editor') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    perform pg_advisory_xact_lock(hashtextextended('myg-nube-op:' || v_usuario::text || ':' || p_operacion::text, 0));
    v_solicitud := jsonb_build_object('revision', p_revision, 'contenido', p_contenido);
    select * into v_anterior from public.myg_nube_operaciones where usuario_id = v_usuario and operacion_id = p_operacion;
    if found then
        if v_anterior.proyecto_id <> p_id or v_anterior.solicitud <> v_solicitud then
            raise exception using errcode = '22023', message = 'MYG_UUID_REUTILIZADO_CON_OTRO_CUERPO';
        end if;
        return v_anterior.respuesta;
    end if;
    if v_proyecto.revision <> p_revision then
        v_respuesta := jsonb_build_object('estado', 'conflicto', 'revision', v_proyecto.revision,
            'contenido', v_proyecto.contenido, 'operacion_id', p_operacion);
    else
        update public.myg_nube_proyectos set contenido = p_contenido, revision = revision + 1,
            actualizado_en = clock_timestamp() where id = p_id returning * into v_proyecto;
        insert into public.myg_nube_historial(proyecto_id, revision, usuario_id, operacion_id, contenido)
        values (p_id, v_proyecto.revision, v_usuario, p_operacion, p_contenido);
        v_respuesta := jsonb_build_object('estado', 'aplicada', 'revision', v_proyecto.revision,
            'contenido', v_proyecto.contenido, 'operacion_id', p_operacion);
    end if;
    insert into public.myg_nube_operaciones(usuario_id, operacion_id, proyecto_id, solicitud, respuesta)
    values (v_usuario, p_operacion, p_id, v_solicitud, v_respuesta);
    return v_respuesta;
end;
$$;

create function public.myg_nube_solicitar(p_codigo text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_id uuid;
begin
    if p_codigo is null or length(btrim(p_codigo)) not between 1 and 64 then
        raise exception using errcode = '22023', message = 'MYG_CODIGO_INVALIDO';
    end if;
    select id into v_id from public.myg_nube_proyectos where codigo = upper(btrim(p_codigo)) for update;
    if v_id is not null and not exists (select 1 from public.myg_nube_miembros
        where proyecto_id = v_id and usuario_id = v_usuario) then
        insert into public.myg_nube_solicitudes(proyecto_id, usuario_id) values (v_id, v_usuario)
        on conflict (proyecto_id, usuario_id) do update set estado = 'pendiente', actualizado_en = clock_timestamp();
    end if;
    -- Misma respuesta para código desconocido, miembro existente y solicitud nueva.
    return jsonb_build_object('estado', 'recibida');
end;
$$;

create function public.myg_nube_miembros(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_resultado jsonb;
begin
    if not exists (select 1 from public.myg_nube_miembros where proyecto_id = p_id
        and usuario_id = v_usuario and rol in ('propietario', 'administrador')) then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('usuario_id', usuario_id, 'rol', rol) order by usuario_id), '[]'::jsonb)
    into v_resultado from public.myg_nube_miembros where proyecto_id = p_id;
    return v_resultado;
end;
$$;

create function public.myg_nube_solicitudes(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_resultado jsonb;
begin
    if not exists (select 1 from public.myg_nube_miembros where proyecto_id = p_id
        and usuario_id = v_usuario and rol in ('propietario', 'administrador')) then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('usuario_id', usuario_id, 'estado', estado) order by usuario_id), '[]'::jsonb)
    into v_resultado from public.myg_nube_solicitudes where proyecto_id = p_id and estado = 'pendiente';
    return v_resultado;
end;
$$;

-- Rutina privada compartida. El bloqueo del proyecto serializa permisos y guardados.
create function myg_nube_privado.cambiar_rol(p_id uuid, p_actor uuid, p_usuario uuid, p_rol text) returns void
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_actor text; v_actual text; v_propietario uuid;
begin
    select propietario into v_propietario from public.myg_nube_proyectos where id = p_id for update;
    select rol into v_actor from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = p_actor;
    select rol into v_actual from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = p_usuario;
    if v_propietario is null or v_actor is null or v_actor not in ('propietario', 'administrador') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    if p_usuario is null or p_usuario = '00000000-0000-0000-0000-000000000000'::uuid
       or (p_rol is not null and p_rol not in ('administrador', 'editor', 'lector')) then
        raise exception using errcode = '22023', message = 'MYG_ROL_INVALIDO';
    end if;
    if p_usuario = v_propietario or v_actual = 'propietario'
       or (v_actor = 'administrador' and (v_actual = 'administrador' or p_rol = 'administrador')) then
        raise exception using errcode = '42501', message = 'MYG_JERARQUIA_PROTEGIDA';
    end if;
    if p_rol is null then
        delete from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = p_usuario;
    else
        if not exists (select 1 from myg_nube_privado.identidades_verificadas
            where auth_usuario_id = p_usuario and activo) then
            raise exception using errcode = '22023', message = 'MYG_DESTINATARIO_NO_VERIFICADO';
        end if;
        insert into public.myg_nube_miembros(proyecto_id, usuario_id, rol) values (p_id, p_usuario, p_rol)
        on conflict (proyecto_id, usuario_id) do update set rol = excluded.rol;
    end if;
end;
$$;

create function public.myg_nube_resolver(p_id uuid, p_usuario uuid, p_rol text, p_aprobar boolean) returns boolean
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad(); v_rol text;
begin
    perform 1 from public.myg_nube_proyectos where id = p_id for update;
    select rol into v_rol from public.myg_nube_miembros where proyecto_id = p_id and usuario_id = v_usuario;
    if v_rol is null or v_rol not in ('propietario', 'administrador') then
        raise exception using errcode = '42501', message = 'MYG_ACCESO_DENEGADO';
    end if;
    if p_aprobar is null or p_usuario is null then
        raise exception using errcode = '22023', message = 'MYG_SOLICITUD_INVALIDA';
    end if;
    if not exists (select 1 from public.myg_nube_solicitudes where proyecto_id = p_id
        and usuario_id = p_usuario and estado = 'pendiente') then
        raise exception using errcode = '22023', message = 'MYG_SOLICITUD_NO_PENDIENTE';
    end if;
    if p_aprobar then
        if p_rol is null then raise exception using errcode = '22023', message = 'MYG_ROL_INVALIDO'; end if;
        perform myg_nube_privado.cambiar_rol(p_id, v_usuario, p_usuario, p_rol);
    end if;
    update public.myg_nube_solicitudes set estado = case when p_aprobar then 'aprobada' else 'rechazada' end,
        actualizado_en = clock_timestamp() where proyecto_id = p_id and usuario_id = p_usuario;
    return true;
end;
$$;

create function public.myg_nube_rol(p_id uuid, p_usuario uuid, p_rol text) returns boolean
language plpgsql security definer set search_path = pg_catalog, myg_nube_privado as $$
declare v_usuario uuid := myg_nube_privado.identidad();
begin
    perform myg_nube_privado.cambiar_rol(p_id, v_usuario, p_usuario, p_rol);
    return true;
end;
$$;

-- PostgreSQL concede EXECUTE a PUBLIC por defecto: cerrar explícitamente cada RPC.
revoke all on function myg_nube_privado.identidad(), myg_nube_privado.validar_contenido(jsonb),
    myg_nube_privado.snapshot(uuid, uuid), myg_nube_privado.cambiar_rol(uuid, uuid, uuid, text)
    from public, anon, authenticated;
revoke all on function public.myg_nube_listar(), public.myg_nube_crear(uuid, text, jsonb, text),
    public.myg_nube_abrir(uuid), public.myg_nube_guardar(uuid, uuid, bigint, jsonb),
    public.myg_nube_solicitar(text), public.myg_nube_miembros(uuid), public.myg_nube_solicitudes(uuid),
    public.myg_nube_resolver(uuid, uuid, text, boolean), public.myg_nube_rol(uuid, uuid, text)
    from public, anon, authenticated;
grant execute on function public.myg_nube_listar(), public.myg_nube_crear(uuid, text, jsonb, text),
    public.myg_nube_abrir(uuid), public.myg_nube_guardar(uuid, uuid, bigint, jsonb),
    public.myg_nube_solicitar(text), public.myg_nube_miembros(uuid), public.myg_nube_solicitudes(uuid),
    public.myg_nube_resolver(uuid, uuid, text, boolean), public.myg_nube_rol(uuid, uuid, text)
    to authenticated;

notify pgrst, 'reload schema';
commit;
