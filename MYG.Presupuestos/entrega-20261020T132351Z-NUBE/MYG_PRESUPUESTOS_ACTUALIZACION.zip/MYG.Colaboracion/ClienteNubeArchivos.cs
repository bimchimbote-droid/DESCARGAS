#nullable enable
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private const int MaxArchivoNubeBytes = 20 * 1024 * 1024;
    private const string RutaBucketNube = "storage/v1/object/myg-nube-archivos/";
    private sealed record ArchivoPreparado(JsonObject Nodo, string Hash, byte[]? Bytes, string Almacen);

    /// <summary>Sube adjuntos inmutables al almacenamiento privado y devuelve solo referencias en JSON.</summary>
    public async Task<JsonElement> PrepararArchivosAsync(JsonElement contenido, Guid lote, CancellationToken ct = default)
    {
        if (lote == Guid.Empty) throw ErrorArchivoNube("El lote de adjuntos necesita un identificador válido.");
        JsonObject copia = CopiarContenidoArchivos(contenido);
        // Validar el conjunto antes de subir: una entrada inválida no deja una subida parcial.
        List<ArchivoPreparado> archivos = LeerArchivosNube(copia, paraSubir: true);
        string usuario = await IdentidadArchivosAsync(ct);
        foreach (ArchivoPreparado archivo in archivos)
        {
            ct.ThrowIfCancellationRequested();
            if (archivo.Bytes is null) continue; // Referencia existente: sus permisos los verifica el servidor.
            // Cada archivo tiene su propio plazo. Los lotes grandes no agotan un único plazo de 40 s.
            await EjecutarAsync(async token =>
            {
                await ComprobarIdentidadArchivosAsync(usuario, token);
                string destino = usuario.ToLowerInvariant() + "/" + lote.ToString("N") + "/" + archivo.Hash;
                using var respuesta = await EnviarArchivoNubeAsync(HttpMethod.Post, destino, archivo.Bytes,
                    permitirExistente: true, token);
                if (respuesta.StatusCode == HttpStatusCode.Conflict)
                {
                    // Reintentar el mismo lote nunca reemplaza un objeto. Se verifica el ya existente.
                    using var existente = await EnviarArchivoNubeAsync(HttpMethod.Get, destino, null,
                        permitirExistente: false, token);
                    byte[] bytes = await LeerArchivoNubeAsync(existente, archivo.Hash, token);
                    if (!bytes.AsSpan().SequenceEqual(archivo.Bytes))
                        throw ErrorArchivoNube("Un adjunto existente no coincide con el contenido que se intentó publicar.");
                }
                archivo.Nodo["Base64"] = "";
                archivo.Nodo["Almacen"] = destino;
                return true;
            }, ct);
        }
        await EjecutarAsync(async token => { await ComprobarIdentidadArchivosAsync(usuario, token); return true; }, ct);
        return JsonSerializer.SerializeToElement(copia, OpcionesNube);
    }

    /// <summary>Recupera adjuntos privados verificados en una copia; el contenido remoto original no cambia.</summary>
    public async Task<JsonElement> CargarArchivosAsync(JsonElement contenido, CancellationToken ct = default)
    {
        JsonObject copia = CopiarContenidoArchivos(contenido);
        List<ArchivoPreparado> archivos = LeerArchivosNube(copia, paraSubir: false);
        string usuario = await IdentidadArchivosAsync(ct);
        foreach (ArchivoPreparado archivo in archivos)
        {
            ct.ThrowIfCancellationRequested();
            if (archivo.Almacen.Length == 0) continue; // Paquete local anterior, ya validado.
            await EjecutarAsync(async token =>
            {
                await ComprobarIdentidadArchivosAsync(usuario, token);
                using var respuesta = await EnviarArchivoNubeAsync(HttpMethod.Get, archivo.Almacen, null,
                    permitirExistente: false, token);
                byte[] bytes = await LeerArchivoNubeAsync(respuesta, archivo.Hash, token);
                archivo.Nodo["Base64"] = Convert.ToBase64String(bytes);
                return true;
            }, ct);
        }
        await EjecutarAsync(async token => { await ComprobarIdentidadArchivosAsync(usuario, token); return true; }, ct);
        return JsonSerializer.SerializeToElement(copia, OpcionesNube);
    }

    private Task<string> IdentidadArchivosAsync(CancellationToken ct) => EjecutarAsync(async token =>
        (await AsegurarSesionAsync(forzarRefresco: false, token, nube: true)).Usuario, ct);

    private async Task ComprobarIdentidadArchivosAsync(string usuario, CancellationToken ct)
    {
        Sesion actual = await AsegurarSesionAsync(forzarRefresco: false, ct, nube: true);
        if (actual.Usuario != usuario)
            throw new NubeException("Cambió la identidad durante la transferencia. Vuelva a iniciar la operación con la cuenta correcta.",
                necesitaIniciarSesion: true);
    }

    private static JsonObject CopiarContenidoArchivos(JsonElement contenido)
    {
        if (contenido.ValueKind != JsonValueKind.Object)
            throw ErrorArchivoNube("El paquete de adjuntos necesita un contenido de proyecto válido.");
        try
        {
            return JsonNode.Parse(contenido.GetRawText(), documentOptions:
                new JsonDocumentOptions { MaxDepth = MaxProfundidadNube }) as JsonObject
                ?? throw ErrorArchivoNube("El contenido de adjuntos no es válido.");
        }
        catch (JsonException) { throw ErrorArchivoNube("El contenido de adjuntos supera la profundidad permitida."); }
    }

    private static List<ArchivoPreparado> LeerArchivosNube(JsonObject contenido, bool paraSubir)
    {
        var resultado = new List<ArchivoPreparado>();
        if (!contenido.TryGetPropertyValue("recursos", out JsonNode? nodo)) return resultado;
        if (nodo is not JsonArray recursos || recursos.Count > 4096)
            throw ErrorArchivoNube("La lista de adjuntos no es válida o excede el límite permitido.");
        foreach (JsonNode? recurso in recursos)
        {
            if (recurso is not JsonObject archivo) throw ErrorArchivoNube("Un adjunto no tiene el formato esperado.");
            TextoArchivoNube(archivo, "Referencia", 8192);
            TextoArchivoNube(archivo, "Nombre", 1024);
            string hash = TextoArchivoNube(archivo, "Sha256", 64).ToLowerInvariant();
            if (!HashArchivoNubeValido(hash)) throw ErrorArchivoNube("La huella SHA-256 de un adjunto no es válida.");
            string base64 = TextoArchivoNube(archivo, "Base64", ((MaxArchivoNubeBytes + 2) / 3) * 4,
                opcional: true);
            string almacen = TextoArchivoNube(archivo, "Almacen", 135, opcional: true);
            if (almacen.Length > 0 && !RutaArchivoNubeValida(almacen, hash))
                throw ErrorArchivoNube("La referencia privada de un adjunto no es válida.");
            byte[]? bytes = null;
            if (base64.Length > 0 || almacen.Length == 0)
            {
                try { bytes = Convert.FromBase64String(base64); }
                catch (FormatException) { throw ErrorArchivoNube("El contenido de un adjunto no tiene una codificación válida."); }
                if (bytes.Length > MaxArchivoNubeBytes)
                    throw ErrorArchivoNube("Un adjunto supera el límite de 20 MiB por archivo.");
                VerificarHashArchivoNube(bytes, hash);
                // El contenido descargado de un objeto inmutable no necesita volver a subirse.
                if (paraSubir && almacen.Length > 0) bytes = null;
            }
            resultado.Add(new ArchivoPreparado(archivo, hash, bytes, almacen));
            if (paraSubir && almacen.Length > 0) archivo["Base64"] = "";
        }
        return resultado;
    }

    private async Task<HttpResponseMessage> EnviarArchivoNubeAsync(HttpMethod metodo, string almacen,
        byte[]? bytes, bool permitirExistente, CancellationToken ct)
    {
        // Solo se construyen rutas canónicas validadas; nunca se siguen URL suministradas por el documento.
        if (!RutaArchivoNubeValida(almacen, almacen.Split('/').LastOrDefault() ?? ""))
            throw ErrorArchivoNube("La referencia privada del adjunto no es válida.");
        Sesion sesion = await AsegurarSesionAsync(forzarRefresco: false, ct, nube: true);
        HttpResponseMessage respuesta = await EnviarAsync(metodo, RutaBucketNube + almacen, bytes,
            sesion.Acceso, ct, tipoContenido: "application/octet-stream");
        if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
        {
            respuesta.Dispose();
            sesion = await AsegurarSesionAsync(forzarRefresco: true, ct, nube: true);
            respuesta = await EnviarAsync(metodo, RutaBucketNube + almacen, bytes,
                sesion.Acceso, ct, tipoContenido: "application/octet-stream");
        }
        if (respuesta.IsSuccessStatusCode || (permitirExistente && respuesta.StatusCode == HttpStatusCode.Conflict))
            return respuesta;
        try
        {
            if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
            {
                LimpiarSesion();
                throw new NubeException("La sesión ya no es válida. Inicie sesión de nuevo para recuperar los adjuntos.",
                    necesitaIniciarSesion: true);
            }
            await LanzarErrorAsync(respuesta, autenticacion: false, ct, nube: true);
            throw ErrorArchivoNube("No se pudo confirmar la operación del adjunto privado.");
        }
        finally { respuesta.Dispose(); }
    }

    private static async Task<byte[]> LeerArchivoNubeAsync(HttpResponseMessage respuesta, string hash,
        CancellationToken ct)
    {
        if (respuesta.Content.Headers.ContentLength is long longitud && longitud > MaxArchivoNubeBytes)
            throw ErrorArchivoNube("El adjunto remoto supera el límite de 20 MiB.");
        using Stream flujo = await respuesta.Content.ReadAsStreamAsync(ct);
        using var memoria = new MemoryStream();
        byte[] bloque = new byte[81920];
        while (true)
        {
            int leidos = await flujo.ReadAsync(bloque.AsMemory(), ct);
            if (leidos == 0) break;
            if (memoria.Length + leidos > MaxArchivoNubeBytes)
                throw ErrorArchivoNube("El adjunto remoto supera el límite de 20 MiB.");
            memoria.Write(bloque, 0, leidos);
        }
        byte[] bytes = memoria.ToArray();
        if (respuesta.Content.Headers.ContentLength is long esperada && esperada != bytes.Length)
            throw ErrorArchivoNube("El adjunto remoto está incompleto.");
        VerificarHashArchivoNube(bytes, hash);
        return bytes;
    }

    private static string TextoArchivoNube(JsonObject archivo, string campo, int maximo, bool opcional = false)
    {
        if (!archivo.TryGetPropertyValue(campo, out JsonNode? nodo))
        {
            if (opcional) return "";
            throw ErrorArchivoNube("Faltan metadatos de un adjunto.");
        }
        if (opcional && nodo is null) return "";
        if (nodo is not JsonValue valor || !valor.TryGetValue<string>(out string? texto)
            || texto is null || texto.Length > maximo || (!opcional && string.IsNullOrWhiteSpace(texto)))
            throw ErrorArchivoNube("Los metadatos de un adjunto no son válidos.");
        return texto;
    }

    private static bool RutaArchivoNubeValida(string ruta, string hash)
    {
        string[] partes = ruta.Split('/');
        return partes.Length == 3 && Guid.TryParseExact(partes[0], "D", out Guid usuario)
            && usuario != Guid.Empty && partes[0] == usuario.ToString("D")
            && Guid.TryParseExact(partes[1], "N", out Guid lote) && lote != Guid.Empty
            && partes[1] == lote.ToString("N") && HashArchivoNubeValido(partes[2])
            && partes[2] == hash;
    }

    private static bool HashArchivoNubeValido(string hash) => hash.Length == 64
        && hash.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');

    private static void VerificarHashArchivoNube(byte[] bytes, string hash)
    {
        if (Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant() != hash)
            throw ErrorArchivoNube("La integridad SHA-256 de un adjunto no coincide con su contenido.");
    }

    private static NubeException ErrorArchivoNube(string mensaje) => new(mensaje);
}
