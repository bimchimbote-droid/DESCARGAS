#nullable enable
using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MYG.Colaboracion;

/// <summary>Proyecto visible para la identidad autenticada. El listado no descarga su contenido.</summary>
public sealed record ProyectoNube(
    [property: JsonPropertyName("id")] Guid Id,
    [property: JsonPropertyName("codigo")] string Codigo,
    [property: JsonPropertyName("nombre")] string Nombre,
    [property: JsonPropertyName("rol")] string Rol,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("alcance")] string Alcance,
    [property: JsonPropertyName("contenido")] JsonElement Contenido);

public sealed record MiembroNube(
    [property: JsonPropertyName("usuario_id")] string UsuarioId,
    [property: JsonPropertyName("rol")] string Rol);

public sealed record SolicitudNube(
    [property: JsonPropertyName("usuario_id")] string UsuarioId,
    [property: JsonPropertyName("estado")] string Estado);

/// <summary>La revisión y el contenido siempre corresponden al estado confirmado por el servidor.</summary>
public sealed record RespuestaGuardarNube(
    [property: JsonPropertyName("estado")] string Estado,
    [property: JsonPropertyName("revision")] long Revision,
    [property: JsonPropertyName("contenido")] JsonElement Contenido,
    [property: JsonPropertyName("operacion_id")] Guid OperacionId);
