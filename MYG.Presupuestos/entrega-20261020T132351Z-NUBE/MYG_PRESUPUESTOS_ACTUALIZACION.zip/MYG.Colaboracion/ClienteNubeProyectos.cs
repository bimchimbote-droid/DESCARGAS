#nullable enable
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private const int MaxRespuestaNubeBytes = 32 * 1024 * 1024;
    // Reserva espacio para los metadatos del proyecto y el envoltorio de la RPC.
    private const int MaxContenidoNubeBytes = 31 * 1024 * 1024;
    private const int MaxProfundidadNube = 128;
    private static readonly JsonSerializerOptions OpcionesNube = new() { MaxDepth = MaxProfundidadNube };

    /// <summary>Identifica el servidor al que pertenece la sesión, sin incluir credenciales.</summary>
    public string UrlServidor => _http.BaseAddress!.GetLeftPart(UriPartial.Authority);

    public Task<IReadOnlyList<ProyectoNube>> ListarProyectosAsync(CancellationToken ct = default) =>
        EjecutarRpcNubeAsync("myg_nube_listar", new { }, raiz =>
        {
            ValidarArrayNube(raiz);
            var proyectos = new List<ProyectoNube>();
            var ids = new HashSet<Guid>();
            foreach (JsonElement elemento in raiz.EnumerateArray())
            {
                ProyectoNube proyecto = LeerProyectoNube(elemento, requiereContenido: false);
                if (!ids.Add(proyecto.Id)) throw RespuestaNubeInvalida();
                proyectos.Add(proyecto);
            }
            return (IReadOnlyList<ProyectoNube>)proyectos.AsReadOnly();
        }, ct);

    public Task<ProyectoNube> CrearProyectoAsync(Guid id, string nombre, JsonElement contenido,
        string alcance, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        nombre = ValidarNombreNube(nombre);
        ValidarAlcanceNube(alcance);
        JsonElement copia = ValidarContenidoNube(contenido);
        return EjecutarRpcNubeAsync("myg_nube_crear", new
        {
            p_id = id, p_nombre = nombre, p_contenido = copia, p_alcance = alcance
        }, raiz => LeerProyectoNube(raiz, requiereContenido: true, esperado: id), ct);
    }

    public Task<ProyectoNube> AbrirProyectoAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_abrir", new { p_id = id },
            raiz => LeerProyectoNube(raiz, requiereContenido: true, esperado: id), ct);
    }

    public Task<RespuestaGuardarNube> GuardarProyectoAsync(Guid id, Guid operacion, long revision,
        JsonElement contenido, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        ValidarIdNube(operacion);
        if (revision < 1) throw new NubeException("La operación necesita una revisión de nube válida.");
        JsonElement copia = ValidarContenidoNube(contenido);
        // El UUID y los bytes se crean una sola vez, incluso si hay que renovar la sesión.
        return EjecutarRpcNubeAsync("myg_nube_guardar", new
        {
            p_id = id, p_operacion = operacion, p_revision = revision, p_contenido = copia
        }, raiz =>
        {
            string estado = TextoNube(raiz, "estado", 32);
            if (estado is not ("aplicada" or "conflicto")) throw RespuestaNubeInvalida();
            Guid confirmado = GuidNube(raiz, "operacion_id");
            if (confirmado != operacion) throw RespuestaNubeInvalida();
            return new RespuestaGuardarNube(estado, RevisionNube(raiz), ContenidoNube(raiz), confirmado);
        }, ct);
    }

    public Task SolicitarAccesoAsync(string codigo, CancellationToken ct = default)
    {
        codigo = codigo?.Trim().ToUpperInvariant() ?? "";
        if (!TextoEntradaValido(codigo, 64))
            throw new NubeException("Introduzca un código de proyecto de hasta 64 caracteres.");
        return EjecutarRpcNubeAsync("myg_nube_solicitar", new { p_codigo = codigo }, raiz =>
        {
            if (TextoNube(raiz, "estado", 32) != "recibida") throw RespuestaNubeInvalida();
            return true;
        }, ct);
    }

    public Task<IReadOnlyList<MiembroNube>> ListarMiembrosAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_miembros", new { p_id = id }, raiz =>
        {
            ValidarArrayNube(raiz);
            var miembros = new List<MiembroNube>();
            var usuarios = new HashSet<Guid>();
            foreach (JsonElement elemento in raiz.EnumerateArray())
            {
                Guid usuario = GuidNube(elemento, "usuario_id");
                string rol = RolNube(elemento);
                if (!usuarios.Add(usuario)) throw RespuestaNubeInvalida();
                miembros.Add(new MiembroNube(usuario.ToString("D"), rol));
            }
            return (IReadOnlyList<MiembroNube>)miembros.AsReadOnly();
        }, ct);
    }

    public Task<IReadOnlyList<SolicitudNube>> ListarSolicitudesAsync(Guid id, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        return EjecutarRpcNubeAsync("myg_nube_solicitudes", new { p_id = id }, raiz =>
        {
            ValidarArrayNube(raiz);
            var solicitudes = new List<SolicitudNube>();
            var usuarios = new HashSet<Guid>();
            foreach (JsonElement elemento in raiz.EnumerateArray())
            {
                Guid usuario = GuidNube(elemento, "usuario_id");
                string estado = TextoNube(elemento, "estado", 32);
                if (estado is not ("pendiente" or "aprobada" or "rechazada") || !usuarios.Add(usuario))
                    throw RespuestaNubeInvalida();
                solicitudes.Add(new SolicitudNube(usuario.ToString("D"), estado));
            }
            return (IReadOnlyList<SolicitudNube>)solicitudes.AsReadOnly();
        }, ct);
    }

    public Task ResolverSolicitudAsync(Guid id, string usuario, string rol, bool aprobar,
        CancellationToken ct = default)
    {
        ValidarIdNube(id);
        usuario = ValidarUsuarioNube(usuario);
        ValidarRolAsignableNube(rol);
        return EjecutarRpcNubeAsync("myg_nube_resolver", new
        {
            p_id = id, p_usuario = usuario, p_rol = rol, p_aprobar = aprobar
        }, ValidarRespuestaAdministracionNube, ct);
    }

    public Task CambiarRolAsync(Guid id, string usuario, string? rol, CancellationToken ct = default)
    {
        ValidarIdNube(id);
        usuario = ValidarUsuarioNube(usuario);
        if (rol is not null) ValidarRolAsignableNube(rol);
        return EjecutarRpcNubeAsync("myg_nube_rol", new { p_id = id, p_usuario = usuario, p_rol = rol },
            ValidarRespuestaAdministracionNube, ct);
    }

    private Task<T> EjecutarRpcNubeAsync<T>(string funcion, object parametros,
        Func<JsonElement, T> leer, CancellationToken ct)
    {
        byte[] cuerpo;
        try { cuerpo = JsonSerializer.SerializeToUtf8Bytes(parametros, OpcionesNube); }
        catch (JsonException) { throw new NubeException("El contenido del proyecto supera la profundidad admitida de 128 niveles."); }
        if (cuerpo.Length > MaxRespuestaNubeBytes)
            throw new NubeException("El contenido del proyecto supera el tamaño admitido para la nube.");
        return EjecutarAsync(async token =>
        {
            using var respuesta = await EnviarConSesionAsync(HttpMethod.Post,
                "rest/v1/rpc/" + funcion, cuerpo, token, nube: true);
            using var json = await LeerJsonAsync(respuesta, token,
                MaxRespuestaNubeBytes, MaxProfundidadNube, nube: true);
            return leer(json.RootElement);
        }, ct);
    }

    private static ProyectoNube LeerProyectoNube(JsonElement raiz, bool requiereContenido, Guid? esperado = null)
    {
        Guid id = GuidNube(raiz, "id");
        if (esperado is Guid esperadoId && id != esperadoId) throw RespuestaNubeInvalida();
        string codigo = TextoNube(raiz, "codigo", 64);
        string nombre = TextoNube(raiz, "nombre", 200);
        string rol = RolNube(raiz);
        long revision = RevisionNube(raiz);
        string alcance = TextoNube(raiz, "alcance", 16);
        if (alcance is not ("obra" or "base")) throw RespuestaNubeInvalida();
        JsonElement contenido = default;
        if (requiereContenido || raiz.TryGetProperty("contenido", out _)) contenido = ContenidoNube(raiz);
        return new ProyectoNube(id, codigo, nombre, rol, revision, alcance, contenido);
    }

    private static string TextoNube(JsonElement raiz, string propiedad, int maximo)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty(propiedad, out var valor)
            || valor.ValueKind != JsonValueKind.String || valor.GetString() is not string texto
            || !TextoEntradaValido(texto, maximo)) throw RespuestaNubeInvalida();
        return texto;
    }

    private static Guid GuidNube(JsonElement raiz, string propiedad)
    {
        if (!Guid.TryParse(TextoNube(raiz, propiedad, 36), out Guid id) || id == Guid.Empty)
            throw RespuestaNubeInvalida();
        return id;
    }

    private static string RolNube(JsonElement raiz)
    {
        string rol = TextoNube(raiz, "rol", 32);
        if (rol is not ("propietario" or "administrador" or "editor" or "lector"))
            throw RespuestaNubeInvalida();
        return rol;
    }

    private static long RevisionNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty("revision", out var valor)
            || valor.ValueKind != JsonValueKind.Number || !valor.TryGetInt64(out long revision)
            || revision < 1) throw RespuestaNubeInvalida();
        return revision;
    }

    private static JsonElement ContenidoNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Object || !raiz.TryGetProperty("contenido", out var valor)
            || valor.ValueKind != JsonValueKind.Object
            || Encoding.UTF8.GetByteCount(valor.GetRawText()) > MaxContenidoNubeBytes)
            throw RespuestaNubeInvalida();
        return valor.Clone();
    }

    private static JsonElement ValidarContenidoNube(JsonElement contenido)
    {
        try
        {
            if (contenido.ValueKind != JsonValueKind.Object)
                throw new NubeException("El contenido del proyecto debe ser un objeto JSON.");
            string texto = contenido.GetRawText();
            if (Encoding.UTF8.GetByteCount(texto) > MaxContenidoNubeBytes)
                throw new NubeException("El contenido del proyecto supera el máximo de 31 MiB.");
            // La RPC añade un nivel al contenido; su respuesta añade otro.
            using var comprobado = JsonDocument.Parse(texto,
                new JsonDocumentOptions { MaxDepth = MaxProfundidadNube - 2 });
            return comprobado.RootElement.Clone();
        }
        catch (ObjectDisposedException) { throw new NubeException("El contenido del proyecto ya no está disponible."); }
        catch (JsonException) { throw new NubeException("El contenido del proyecto supera la profundidad admitida para la nube."); }
    }

    private static void ValidarArrayNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.Array || raiz.GetArrayLength() > 10000)
            throw RespuestaNubeInvalida();
    }

    private static bool TextoEntradaValido(string texto, int maximo)
    {
        if (string.IsNullOrWhiteSpace(texto) || texto.Length > maximo) return false;
        foreach (char caracter in texto) if (char.IsControl(caracter)) return false;
        return true;
    }

    private static void ValidarIdNube(Guid id)
    {
        if (id == Guid.Empty) throw new NubeException("El proyecto y la operación necesitan identificadores válidos.");
    }

    private static string ValidarNombreNube(string nombre)
    {
        nombre = nombre?.Trim() ?? "";
        if (!TextoEntradaValido(nombre, 200)) throw new NubeException("Introduzca un nombre de proyecto de hasta 200 caracteres.");
        return nombre;
    }

    private static void ValidarAlcanceNube(string alcance)
    {
        if (alcance is not ("obra" or "base")) throw new NubeException("El alcance del proyecto debe ser obra o base.");
    }

    private static string ValidarUsuarioNube(string usuario)
    {
        if (!Guid.TryParse(usuario, out Guid id) || id == Guid.Empty)
            throw new NubeException("El miembro necesita un identificador de usuario válido.");
        return id.ToString("D");
    }

    private static void ValidarRolAsignableNube(string rol)
    {
        if (rol is not ("administrador" or "editor" or "lector"))
            throw new NubeException("Seleccione un rol de administrador, editor o lector.");
    }

    private static bool ValidarRespuestaAdministracionNube(JsonElement raiz)
    {
        if (raiz.ValueKind != JsonValueKind.True) throw RespuestaNubeInvalida();
        return true;
    }

    private static NubeException RespuestaNubeInvalida() => new(
        "La respuesta de la nube no tiene el formato esperado. Conserve la operación pendiente y reinténtela.",
        esErrorDeConexion: true);

    private static async Task LanzarErrorNubeAsync(HttpResponseMessage respuesta, CancellationToken ct)
    {
        string? codigo = null;
        bool vinculoNoVerificado = false;
        try
        {
            using var json = await LeerJsonAsync(respuesta, ct, nube: true);
            JsonElement raiz = json.RootElement;
            if (raiz.ValueKind == JsonValueKind.Object)
            {
                if (raiz.TryGetProperty("code", out var valor) && valor.ValueKind == JsonValueKind.String)
                {
                    string? candidato = valor.GetString();
                    if (candidato is "40001" or "42501" or "22023" or "23505" or "PGRST202" or "42883" or "42P01")
                        codigo = candidato;
                }
                vinculoNoVerificado = codigo == "42501" && raiz.TryGetProperty("message", out var mensaje)
                    && mensaje.ValueKind == JsonValueKind.String && mensaje.GetString() == "MYG_VINCULO_NO_VERIFICADO";
            }
        }
        catch (NubeException) { }
        if (codigo == "40001")
            throw new NubeException("Otro cambio coincidió con la solicitud. Reintente la misma operación pendiente.",
                esErrorDeConexion: true, codigo: codigo);
        if (codigo == "42501" || respuesta.StatusCode == HttpStatusCode.Forbidden)
            throw new NubeException(vinculoNoVerificado
                    ? "La cuenta necesita un vínculo MYG verificado por el administrador del servidor."
                    : "La cuenta ya no tiene permiso para esta operación. Actualice el proyecto y compruebe su rol.",
                accesoDenegado: true, codigo: codigo, vinculoNoVerificado: vinculoNoVerificado);
        if (codigo == "22023")
            throw new NubeException("La nube rechazó los datos del proyecto, la revisión o la operación.", codigo: codigo);
        if (codigo == "23505")
            throw new NubeException("El identificador de la operación o del proyecto ya está en uso con otros datos.", codigo: codigo);
        if (codigo is "PGRST202" or "42883" or "42P01")
            throw new NubeException("Las funciones de proyectos en la nube todavía no están instaladas en este servidor.", codigo: codigo);
        throw new NubeException($"La nube rechazó la solicitud (HTTP {(int)respuesta.StatusCode}). Compruebe la configuración del servidor.",
            codigo: codigo);
    }
}
