#nullable enable
using System;
namespace MYG.Colaboracion;

public sealed record PartidaNube(string Descripcion, string Unidad, decimal Cantidad, long Revision);
public sealed record OperacionCantidad(Guid Id, decimal Cantidad, long RevisionBase);
public sealed record ResultadoCantidad(bool Conflicto, decimal CantidadConfirmada, long RevisionConfirmada);

public sealed class NubeException : Exception
{
    public bool EsErrorDeConexion { get; }
    public bool NecesitaIniciarSesion { get; }
    public bool AccesoDenegado { get; }
    public bool VinculoNoVerificado { get; }
    public string? Codigo { get; }

    public NubeException(string mensaje, bool esErrorDeConexion = false, bool necesitaIniciarSesion = false,
        bool accesoDenegado = false, string? codigo = null, bool vinculoNoVerificado = false)
        : base(mensaje)
    {
        EsErrorDeConexion = esErrorDeConexion;
        NecesitaIniciarSesion = necesitaIniciarSesion;
        AccesoDenegado = accesoDenegado;
        Codigo = codigo;
        VinculoNoVerificado = vinculoNoVerificado;
    }
}
