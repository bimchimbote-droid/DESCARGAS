using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace MYG_2027;

// Los cursores pertenecen a cada hoja y se liberan al cerrar su panel. El .cur
// se construye en memoria, sin archivos externos ni handles GDI prestados.
internal sealed class MYGCursoresMetrado : NativeWindow, IDisposable
{
    private readonly DataGridView hoja;
    private readonly Func<Point, Cursor> elegir;
    private readonly Func<int, Point, bool> raton;
    private const float EscalaSeleccion = 0.70f;
    private Cursor seleccion, relleno, columna, fila, movimiento, dimensionNativa;
    internal Cursor Seleccion => seleccion;
    internal Cursor Relleno => relleno;
    internal Cursor Columna => columna;
    internal Cursor Fila => fila;
    internal Cursor Movimiento => movimiento;

    internal MYGCursoresMetrado(DataGridView hoja, Func<Point, Cursor> elegir, Func<int, Point, bool> raton)
    {
        this.hoja = hoja; this.elegir = elegir; this.raton = raton;
        CrearCursores();
        hoja.HandleCreated += CrearHandle;
        hoja.HandleDestroyed += DestruirHandle;
        hoja.DpiChangedAfterParent += CambiarDpi;
        hoja.MouseLeave += Salir;
        if (hoja.IsHandleCreated) AssignHandle(hoja.Handle);
    }

    private void CrearHandle(object sender, EventArgs e) => AssignHandle(hoja.Handle);
    private void DestruirHandle(object sender, EventArgs e) { dimensionNativa = null; ReleaseHandle(); }
    private void Salir(object sender, EventArgs e) { if (!hoja.Capture) hoja.Cursor = Cursors.Default; }
    private void CambiarDpi(object sender, EventArgs e)
    {
        hoja.Cursor = Cursors.Default;
        LiberarCursores(); CrearCursores();
    }

    private void CrearCursores()
    {
        int tamano = Math.Clamp((int)Math.Ceiling(32 * hoja.DeviceDpi / 96d), 32, 128);
        seleccion = Crear(tamano, 16, 16, g =>
        {
            using var exterior = new GraphicsPath();
            exterior.AddPolygon(Cruz(16, 16, 11, 3));
            g.FillPath(Brushes.Black, exterior);
            using var interior = new GraphicsPath();
            interior.AddPolygon(Cruz(16, 16, 10, 2));
            g.FillPath(Brushes.White, interior);
        }, EscalaSeleccion, monocromo: true);
        relleno = Crear(tamano, 16, 16, g =>
        {
            using var contorno = new Pen(Color.White, 2) { LineJoin = LineJoin.Miter };
            var puntos = Cruz(16, 16, 7, 1);
            g.DrawPolygon(contorno, puntos); g.FillPolygon(Brushes.Black, puntos);
        });
        columna = Crear(tamano, 16, 26, g => DibujarFlecha(g, false), EscalaSeleccion);
        fila = Crear(tamano, 26, 16, g => DibujarFlecha(g, true), EscalaSeleccion);
        using var original = new Bitmap(32, 32);
        using (var g = Graphics.FromImage(original))
        {
            // GDI puede dibujar el cursor sin escribir el canal alfa. Un fondo
            // de contraste permite reconstruir la transparencia antes de escalar.
            g.Clear(Color.Magenta);
            Cursors.SizeAll.DrawStretched(g, new Rectangle(0, 0, 32, 32));
        }
        for (int y = 0; y < original.Height; y++) for (int x = 0; x < original.Width; x++)
        {
            Color pixel = original.GetPixel(x, y);
            original.SetPixel(x, y, pixel.R == 255 && pixel.G == 0 && pixel.B == 255
                ? Color.Transparent : Color.FromArgb(255, pixel.R, pixel.G, pixel.B));
        }
        var nativo = Cursors.SizeAll;
        int activoX = (int)Math.Round(nativo.HotSpot.X * 32d / nativo.Size.Width);
        int activoY = (int)Math.Round(nativo.HotSpot.Y * 32d / nativo.Size.Height);
        movimiento = Crear(tamano, activoX, activoY, g =>
        {
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = PixelOffsetMode.Half;
            g.DrawImage(original, new Rectangle(0, 0, 32, 32));
        }, EscalaSeleccion, monocromo: true);
    }

    private static PointF[] Cruz(float x, float y, float brazo, float grosor) =>
    [new(x - grosor, y - brazo), new(x + grosor, y - brazo), new(x + grosor, y - grosor),
     new(x + brazo, y - grosor), new(x + brazo, y + grosor), new(x + grosor, y + grosor),
     new(x + grosor, y + brazo), new(x - grosor, y + brazo), new(x - grosor, y + grosor),
     new(x - brazo, y + grosor), new(x - brazo, y - grosor), new(x - grosor, y - grosor)];

    private static void DibujarFlecha(Graphics g, bool horizontal)
    {
        PointF[] puntos = [new(13, 5), new(19, 5), new(19, 17), new(25, 17), new(16, 26), new(7, 17), new(13, 17)];
        if (horizontal) for (int i = 0; i < puntos.Length; i++) puntos[i] = new(puntos[i].Y, puntos[i].X);
        using var borde = new Pen(Color.White, 2) { LineJoin = LineJoin.Miter };
        g.DrawPolygon(borde, puntos); g.FillPolygon(Brushes.Black, puntos);
    }

    private static Cursor Crear(int tamano, int x, int y, Action<Graphics> pintar,
        float escalaFigura = 1f, bool monocromo = false)
    {
        using var imagen = new Bitmap(tamano, tamano);
        using (var g = Graphics.FromImage(imagen))
        {
            g.Clear(Color.Transparent); g.SmoothingMode = SmoothingMode.None;
            g.ScaleTransform(tamano / 32f, tamano / 32f);
            // Reducir el dibujo dentro del lienzo evita que Windows lo vuelva
            // a ampliar al cargarlo al tamaño estándar del cursor del sistema.
            g.TranslateTransform(16, 16); g.ScaleTransform(escalaFigura, escalaFigura); g.TranslateTransform(-16, -16);
            pintar(g);
        }
        int mascaraFila = ((tamano + 31) / 32) * 4;
        int bytesImagen = (monocromo ? mascaraFila : tamano * 4) * tamano, bytesMascara = mascaraFila * tamano;
        using var memoria = new MemoryStream();
        using (var escritor = new BinaryWriter(memoria, System.Text.Encoding.UTF8, true))
        {
            escritor.Write((ushort)0); escritor.Write((ushort)2); escritor.Write((ushort)1);
            escritor.Write((byte)tamano); escritor.Write((byte)tamano); escritor.Write((byte)(monocromo ? 2 : 0)); escritor.Write((byte)0);
            escritor.Write((ushort)Math.Round((16 + (x - 16) * escalaFigura) * tamano / 32));
            escritor.Write((ushort)Math.Round((16 + (y - 16) * escalaFigura) * tamano / 32));
            escritor.Write(40 + (monocromo ? 8 : 0) + bytesImagen + bytesMascara); escritor.Write(22);
            escritor.Write(40); escritor.Write(tamano); escritor.Write(tamano * 2);
            escritor.Write((ushort)1); escritor.Write((ushort)(monocromo ? 1 : 32)); escritor.Write(0); escritor.Write(bytesImagen);
            escritor.Write(0); escritor.Write(0); escritor.Write(monocromo ? 2 : 0); escritor.Write(0);
            if (monocromo)
            {
                escritor.Write(0); escritor.Write(0x00ffffff); // Paleta: negro y blanco.
                for (int f = tamano - 1; f >= 0; f--)
                {
                    var xor = new byte[mascaraFila];
                    for (int c = 0; c < tamano; c++)
                    {
                        var color = imagen.GetPixel(c, f);
                        // AND=0/XOR=1 pinta blanco; AND=0/XOR=0 pinta negro.
                        // La zona transparente conserva AND=1/XOR=0, sin invertir el fondo.
                        if (color.A != 0 && color.R >= 128 && color.G >= 128 && color.B >= 128)
                            xor[c / 8] |= (byte)(128 >> (c % 8));
                    }
                    escritor.Write(xor);
                }
            }
            else for (int f = tamano - 1; f >= 0; f--) for (int c = 0; c < tamano; c++)
            {
                var color = imagen.GetPixel(c, f);
                escritor.Write(color.B); escritor.Write(color.G); escritor.Write(color.R); escritor.Write(color.A);
            }
            for (int f = tamano - 1; f >= 0; f--)
            {
                var mascara = new byte[mascaraFila];
                for (int c = 0; c < tamano; c++) if (imagen.GetPixel(c, f).A == 0) mascara[c / 8] |= (byte)(128 >> (c % 8));
                escritor.Write(mascara);
            }
        }
        memoria.Position = 0;
        return new Cursor(memoria);
    }

    protected override void WndProc(ref Message mensaje)
    {
        const int Mover = 0x0200, Pulsar = 0x0201, Soltar = 0x0202, EstablecerCursor = 0x0020;
        if (mensaje.Msg is 0x0215 or 0x001f or 0x0008) dimensionNativa = null;
        if (mensaje.Msg == 0x0100 && mensaje.WParam.ToInt32() == (int)Keys.Escape) dimensionNativa = null;
        if (mensaje.Msg == 0x0100 && mensaje.WParam.ToInt32() == (int)Keys.Escape && raton(mensaje.Msg, new((int)Keys.Escape, 0)))
        { mensaje.Result = IntPtr.Zero; return; }
        if (mensaje.Msg is 0x0008 or 0x001f) raton(mensaje.Msg, Point.Empty);
        if (mensaje.Msg == 0x0204)
        {
            long posicion = mensaje.LParam.ToInt64();
            var punto = new Point((short)(posicion & 0xffff), (short)((posicion >> 16) & 0xffff));
            if (raton(mensaje.Msg, punto)) { mensaje.Result = IntPtr.Zero; return; }
        }
        if (mensaje.Msg == EstablecerCursor && mensaje.WParam == Handle && ((int)mensaje.LParam & 0xffff) == 1)
        {
            Cursor.Current = dimensionNativa ?? elegir(hoja.PointToClient(Cursor.Position));
            mensaje.Result = new IntPtr(1); return;
        }
        if (mensaje.Msg is Mover or Pulsar or Soltar)
        {
            long posicion = mensaje.LParam.ToInt64();
            var punto = new Point((short)(posicion & 0xffff), (short)((posicion >> 16) & 0xffff));
            if (dimensionNativa == null && raton(mensaje.Msg, punto)) { mensaje.Result = IntPtr.Zero; return; }
            if (mensaje.Msg == Pulsar)
            {
                var cursor = elegir(punto);
                if (cursor == Cursors.SizeWE || cursor == Cursors.SizeNS) dimensionNativa = cursor;
            }
            base.WndProc(ref mensaje);
            if (mensaje.Msg == Soltar) dimensionNativa = null;
            hoja.Cursor = dimensionNativa ?? elegir(punto);
            return;
        }
        base.WndProc(ref mensaje);
    }

    private void LiberarCursores()
    { seleccion?.Dispose(); relleno?.Dispose(); columna?.Dispose(); fila?.Dispose(); movimiento?.Dispose(); }

    public void Dispose()
    {
        hoja.HandleCreated -= CrearHandle; hoja.HandleDestroyed -= DestruirHandle;
        hoja.DpiChangedAfterParent -= CambiarDpi; hoja.MouseLeave -= Salir;
        ReleaseHandle();
        if (!hoja.IsDisposed) hoja.Cursor = Cursors.Default;
        LiberarCursores();
    }
}
