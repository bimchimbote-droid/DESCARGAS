using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private bool arrastrandoEncabezadosHoja, columnasSeleccionEncabezadosHoja;
    private int anclaSeleccionEncabezadosHoja, extremoSeleccionEncabezadosHoja;
    private Point puntoSeleccionEncabezadosHoja;
    private Point[] seleccionPreviaEncabezadosHoja = Array.Empty<Point>();
    private MYGHojaMetrado libroSeleccionEncabezadosHoja;
    private System.Windows.Forms.Timer relojSeleccionEncabezadosHoja;

    private Point[] CapturarSeleccionEncabezadosHoja() => hoja.SelectedCells.Cast<DataGridViewCell>()
        .Select(c => new Point(c.ColumnIndex, c.RowIndex)).ToArray();

    private void SeleccionarIntervaloEncabezadosHoja(bool columnas, int ancla, int extremo, Point[] conservar)
    {
        bool previo = cargando; cargando = true;
        try
        {
            var primeraFila = hoja.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Displayed)
                ?? hoja.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Visible);
            var primeraColumna = hoja.Columns.Cast<DataGridViewColumn>().FirstOrDefault(c => c.Displayed)
                ?? hoja.Columns.Cast<DataGridViewColumn>().FirstOrDefault(c => c.Visible);
            if (primeraFila == null || primeraColumna == null) return;
            // CurrentCell puede borrar la selección de DataGridView al cambiar
            // de fila: reconstruirla después también conserva Ctrl + clic.
            hoja.CurrentCell = columnas ? hoja[extremo, primeraFila.Index] : hoja[primeraColumna.Index, extremo];
            hoja.ClearSelection();
            foreach (var p in conservar)
                if (p.X < hoja.ColumnCount && p.Y < hoja.RowCount) hoja[p.X, p.Y].Selected = true;
            for (int n = Math.Min(ancla, extremo); n <= Math.Max(ancla, extremo); n++)
            {
                if (columnas) foreach (DataGridViewRow r in hoja.Rows) hoja[n, r.Index].Selected = true;
                else foreach (DataGridViewColumn c in hoja.Columns) hoja[c.Index, n].Selected = true;
            }
        }
        finally { cargando = previo; }
        ActualizarSeleccionCursorHoja(); ActualizarFormula(); hoja.Invalidate();
    }

    private bool ProcesarRatonSeleccionEncabezadosHoja(int mensaje, Point punto)
    {
        if (mensaje == 0x0201 && !arrastrandoEncabezadosHoja && origenArrastreHoja == null)
        {
            if (cargando || !HayPartida || !hoja.Enabled || hoja.ReadOnly || (ModifierKeys & Keys.Alt) != 0) return false;
            var hit = hoja.HitTest(punto.X, punto.Y);
            bool columnas = hit.Type == DataGridViewHitTestType.ColumnHeader && hit.ColumnIndex >= 0;
            bool filas = hit.Type == DataGridViewHitTestType.RowHeader && hit.RowIndex >= 0;
            if (!columnas && !filas) return false;
            var cursor = ElegirCursorHoja(punto);
            if (cursor == Cursors.SizeWE || cursor == Cursors.SizeNS) return false;
            Intentar(() =>
            {
                var conservar = (ModifierKeys & Keys.Control) != 0 ? CapturarSeleccionEncabezadosHoja() : Array.Empty<Point>();
                SeleccionarEncabezadoHoja(hit.RowIndex, hit.ColumnIndex, (ModifierKeys & Keys.Control) != 0,
                    (ModifierKeys & Keys.Shift) != 0);
                columnasSeleccionEncabezadosHoja = columnas;
                anclaSeleccionEncabezadosHoja = columnas ? anclaEncabezadoColumnaHoja : anclaEncabezadoFilaHoja;
                extremoSeleccionEncabezadosHoja = columnas ? hit.ColumnIndex : hit.RowIndex;
                seleccionPreviaEncabezadosHoja = conservar;
                libroSeleccionEncabezadosHoja = actual.Costos.Hoja;
                puntoSeleccionEncabezadosHoja = punto;
                arrastrandoEncabezadosHoja = true;
                hoja.Capture = true;
                relojSeleccionEncabezadosHoja.Start();
            });
            return true;
        }
        if (!arrastrandoEncabezadosHoja) return false;
        if (mensaje is not (0x0200 or 0x0202)) return false;
        puntoSeleccionEncabezadosHoja = punto;
        ActualizarExtremoSeleccionEncabezadosHoja();
        if (mensaje == 0x0202) CancelarArrastreHoja();
        else { hoja.Cursor = ElegirCursorHoja(punto); Cursor.Current = hoja.Cursor; }
        return true;
    }

    private void ActualizarExtremoSeleccionEncabezadosHoja()
    {
        if (!HayPartida || !ReferenceEquals(libroSeleccionEncabezadosHoja, actual.Costos.Hoja))
        { CancelarArrastreHoja(); return; }
        var area = AreaCeldasHoja();
        if (area.Width <= 0 || area.Height <= 0) return;
        // Sólo importa el eje del encabezado original: se puede mover el
        // ratón sobre las celdas sin convertir el arrastre en una selección parcial.
        int x = columnasSeleccionEncabezadosHoja ? Math.Clamp(puntoSeleccionEncabezadosHoja.X, area.Left, area.Right - 1) : hoja.RowHeadersWidth / 2;
        int y = columnasSeleccionEncabezadosHoja ? hoja.ColumnHeadersHeight / 2 : Math.Clamp(puntoSeleccionEncabezadosHoja.Y, area.Top, area.Bottom - 1);
        var hit = hoja.HitTest(x, y);
        int extremo = columnasSeleccionEncabezadosHoja ? hit.ColumnIndex : hit.RowIndex;
        if (extremo < 0 || extremo == extremoSeleccionEncabezadosHoja) return;
        extremoSeleccionEncabezadosHoja = extremo;
        SeleccionarIntervaloEncabezadosHoja(columnasSeleccionEncabezadosHoja, anclaSeleccionEncabezadosHoja,
            extremo, seleccionPreviaEncabezadosHoja);
    }

    private void DesplazarSeleccionEncabezadosHoja(object sender, EventArgs e)
    {
        if (!arrastrandoEncabezadosHoja) return;
        if (!hoja.Capture || !HayPartida || !ReferenceEquals(libroSeleccionEncabezadosHoja, actual.Costos.Hoja))
        { CancelarArrastreHoja(); return; }
        var area = AreaCeldasHoja();
        int posicion = columnasSeleccionEncabezadosHoja ? puntoSeleccionEncabezadosHoja.X : puntoSeleccionEncabezadosHoja.Y;
        int inicio = columnasSeleccionEncabezadosHoja ? area.Left : area.Top;
        int fin = columnasSeleccionEncabezadosHoja ? area.Right : area.Bottom;
        int paso = posicion < inicio ? -1 : posicion >= fin ? 1 : 0;
        if (paso == 0) return;
        if (columnasSeleccionEncabezadosHoja)
        {
            int siguiente = hoja.FirstDisplayedScrollingColumnIndex + paso;
            while (siguiente >= 0 && siguiente < hoja.ColumnCount && (!hoja.Columns[siguiente].Visible || hoja.Columns[siguiente].Frozen)) siguiente += paso;
            if (siguiente >= 0 && siguiente < hoja.ColumnCount) hoja.FirstDisplayedScrollingColumnIndex = siguiente;
        }
        else
        {
            int siguiente = hoja.FirstDisplayedScrollingRowIndex + paso;
            while (siguiente >= 0 && siguiente < hoja.RowCount && (!hoja.Rows[siguiente].Visible || hoja.Rows[siguiente].Frozen)) siguiente += paso;
            if (siguiente >= 0 && siguiente < hoja.RowCount) hoja.FirstDisplayedScrollingRowIndex = siguiente;
        }
        ActualizarExtremoSeleccionEncabezadosHoja();
    }

    private void CancelarSeleccionEncabezadosHoja()
    {
        arrastrandoEncabezadosHoja = false;
        seleccionPreviaEncabezadosHoja = Array.Empty<Point>();
        libroSeleccionEncabezadosHoja = null;
        relojSeleccionEncabezadosHoja?.Stop();
    }

    private void SeleccionarContextoHoja(Point punto)
    {
        if (cargando || !HayPartida || !hoja.Enabled) return;
        var hit = hoja.HitTest(punto.X, punto.Y);
        if (hit.Type == DataGridViewHitTestType.ColumnHeader && hit.ColumnIndex >= 0)
        {
            if (!hoja.Rows.Cast<DataGridViewRow>().All(r => hoja[hit.ColumnIndex, r.Index].Selected))
                SeleccionarEncabezadoHoja(-1, hit.ColumnIndex, false, false);
        }
        else if (hit.Type == DataGridViewHitTestType.RowHeader && hit.RowIndex >= 0)
        {
            if (!hoja.Columns.Cast<DataGridViewColumn>().All(c => hoja[c.Index, hit.RowIndex].Selected))
                SeleccionarEncabezadoHoja(hit.RowIndex, -1, false, false);
        }
        else if (hit.Type == DataGridViewHitTestType.TopLeftHeader) SeleccionarEncabezadoHoja(-1, -1, false, false);
        else if (hit.Type == DataGridViewHitTestType.Cell && !hoja[hit.ColumnIndex, hit.RowIndex].Selected)
        {
            FinalizarEdicion();
            hoja.CurrentCell = hoja[hit.ColumnIndex, hit.RowIndex];
            hoja.ClearSelection(); hoja.CurrentCell.Selected = true;
        }
        hoja.Focus();
    }

    private (int Inicio, int Cantidad) EjeSeleccionEstructuralHoja(bool filas)
    {
        var indices = hoja.SelectedCells.Cast<DataGridViewCell>().Select(c => filas ? c.RowIndex : c.ColumnIndex)
            .Distinct().OrderBy(n => n).ToArray();
        if (indices.Length == 0) throw new InvalidOperationException("Seleccione una celda o un rango.");
        if (indices[^1] - indices[0] + 1 != indices.Length)
            throw new InvalidOperationException(filas ? "Para insertar o eliminar filas, seleccione filas contiguas." :
                "Para insertar o eliminar columnas, seleccione columnas contiguas.");
        return (indices[0] + 1, indices.Length);
    }
}
