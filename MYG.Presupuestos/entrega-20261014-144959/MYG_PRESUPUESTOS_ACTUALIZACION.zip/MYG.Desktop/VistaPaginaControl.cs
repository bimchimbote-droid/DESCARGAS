using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Reproduce páginas vectoriales al tamaño y DPI actuales, sin ampliar una captura de pantalla.</summary>
internal sealed class MYGVistaPaginaControl : ScrollableControl
{
    private sealed class PaginaVector : IDisposable
    {
        internal SizeF Medida;
        internal MemoryStream Memoria;
        internal Metafile Imagen;
        public void Dispose()
        {
            Imagen?.Dispose();
            Memoria?.Dispose();
        }
    }

    private List<PaginaVector> paginas = new();
    private MYGReportesImpresion.Vista vista;
    private int pagina;
    private float ampliacion = 1;
    private bool variasPaginas, arrastrar, arrastrando, ajustando;
    private Point inicioArrastre, scrollArrastre;
    private SizeF tamanoGrupo;
    private Size ultimaArea;

    internal event EventHandler AmpliacionChanged;
    internal float Ampliacion => ampliacion;
    internal SizeF TamanoPapel => paginas.Count == 0 ? SizeF.Empty : paginas[0].Medida;
    internal RectangleF RectanguloPapel => RectangulosPapel.FirstOrDefault();
    internal IReadOnlyList<RectangleF> RectangulosPapel
    {
        get
        {
            if (paginas.Count == 0) return Array.Empty<RectangleF>();
            var grupo = CentrarPapel(tamanoGrupo, ClientSize, AutoScrollPosition, Separacion);
            var resultado = new RectangleF[paginas.Count];
            float x = grupo.Left;
            for (int i = 0; i < paginas.Count; i++)
            {
                var medida = Pixeles(paginas[i].Medida);
                resultado[i] = new RectangleF(x, grupo.Top + (grupo.Height - medida.Height) / 2, medida.Width, medida.Height);
                x += medida.Width + Separacion;
            }
            return resultado;
        }
    }
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal bool VariasPaginas
    {
        get => variasPaginas;
        set
        {
            if (variasPaginas == value) return;
            bool anterior = variasPaginas;
            variasPaginas = value;
            try
            {
                if (vista != null) Cargar(vista, pagina);
            }
            catch { variasPaginas = anterior; throw; }
        }
    }
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal bool Arrastrar
    {
        get => arrastrar;
        set
        {
            arrastrar = value;
            if (!value && arrastrando) Capture = false;
            Cursor = value ? Cursors.Hand : Cursors.Default;
        }
    }

    private float Separacion => 24f * DeviceDpi / 96f;
    private SizeF Pixeles(SizeF medida) => new(medida.Width * DeviceDpi * ampliacion, medida.Height * DeviceDpi * ampliacion);

    internal MYGVistaPaginaControl()
    {
        Name = "vista_superficie";
        Dock = DockStyle.Fill;
        AutoScroll = true;
        TabStop = true;
        BackColor = Color.FromArgb(159, 183, 205);
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
    }

    internal void Cargar(MYGReportesImpresion.Vista nuevaVista, int indice)
    {
        ArgumentNullException.ThrowIfNull(nuevaVista);
        if (indice < 0 || indice >= nuevaVista.CantidadPaginas) throw new ArgumentOutOfRangeException(nameof(indice));
        var nuevas = new List<PaginaVector>();
        try
        {
            int cantidad = variasPaginas ? Math.Min(2, nuevaVista.CantidadPaginas - indice) : 1;
            for (int i = 0; i < cantidad; i++) nuevas.Add(GrabarPagina(nuevaVista, indice + i));
        }
        catch
        {
            foreach (var imagen in nuevas) imagen.Dispose();
            throw;
        }
        var anteriores = paginas;
        paginas = nuevas;
        vista = nuevaVista;
        pagina = indice;
        foreach (var imagen in anteriores) imagen.Dispose();
        RecalcularExtension();
        // Al abrir una hoja grande se muestra su cabecera y se centra el ancho visible.
        AutoScrollPosition = new Point(Math.Max(0, (AutoScrollMinSize.Width - ClientSize.Width) / 2), 0);
        Invalidate();
    }

    private PaginaVector GrabarPagina(MYGReportesImpresion.Vista documento, int indice)
    {
        var resultado = new PaginaVector { Medida = documento.TamanoPagina(indice), Memoria = new MemoryStream() };
        try
        {
            using var referencia = CreateGraphics();
            IntPtr hdc = referencia.GetHdc();
            try
            {
                // El marco incluye el papel completo; los registros guardan texto y líneas vectoriales.
                resultado.Imagen = new Metafile(resultado.Memoria, hdc,
                    new RectangleF(PointF.Empty, resultado.Medida), MetafileFrameUnit.Inch, EmfType.EmfPlusOnly);
            }
            finally { referencia.ReleaseHdc(hdc); }
            using var dibujo = Graphics.FromImage(resultado.Imagen);
            Calidad(dibujo);
            dibujo.PageUnit = GraphicsUnit.Inch;
            documento.DibujarPagina(dibujo, indice);
            return resultado;
        }
        catch { resultado.Dispose(); throw; }
    }

    internal void Limpiar()
    {
        vista = null;
        foreach (var imagen in paginas) imagen.Dispose();
        paginas.Clear();
        tamanoGrupo = SizeF.Empty;
        AutoScrollMinSize = Size.Empty;
        AutoScrollPosition = Point.Empty;
        Invalidate();
    }

    internal void CambiarZoom(float valor, Point? ancla = null) => AplicarZoom(valor, .25f, ancla);

    private void AplicarZoom(float valor, float minimo, Point? ancla)
    {
        if (!float.IsFinite(valor)) throw new ArgumentOutOfRangeException(nameof(valor));
        valor = Math.Clamp(valor, minimo, 4);
        if (Math.Abs(valor - ampliacion) < .00001f) return;
        var punto = ancla ?? new Point(ClientSize.Width / 2, ClientSize.Height / 2);
        PointF relativo = PuntoRelativo(punto, ClientSize);
        ampliacion = valor;
        RecalcularExtension();
        if (paginas.Count > 0) AutoScrollPosition = DesplazamientoParaAncla(tamanoGrupo, ClientSize, Separacion, punto, relativo);
        Invalidate();
        AmpliacionChanged?.Invoke(this, EventArgs.Empty);
    }

    internal void AjustarPagina()
    {
        if (paginas.Count == 0 || ClientSize.Width < 1 || ClientSize.Height < 1) return;
        // Recuperar el espacio ocupado por las barras evita que el ajuste se reduzca por el zoom anterior.
        float anchoArea = ClientSize.Width + (VerticalScroll.Visible ? SystemInformation.VerticalScrollBarWidth : 0);
        float altoArea = ClientSize.Height + (HorizontalScroll.Visible ? SystemInformation.HorizontalScrollBarHeight : 0);
        float ancho = paginas.Sum(p => p.Medida.Width) * DeviceDpi;
        float alto = paginas.Max(p => p.Medida.Height) * DeviceDpi;
        float huecos = Separacion * (paginas.Count - 1);
        float factor = Math.Min((anchoArea - 2 * Separacion - huecos) / ancho,
            (altoArea - 2 * Separacion) / alto);
        AplicarZoom(Math.Max(.1f, factor), .1f, null);
        AutoScrollPosition = Point.Empty;
        Invalidate();
    }

    /// <summary>Los deltas parciales de ratones y paneles táctiles producen cambios proporcionales.</summary>
    internal bool ProcesarRueda(int delta, bool control, Point punto)
    {
        if (!control || paginas.Count == 0) return false;
        if (delta != 0)
        {
            float factor = (float)Math.Pow(1.12, delta / 120d);
            AplicarZoom(ampliacion * factor, Math.Min(.25f, ampliacion), punto);
        }
        return true;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        if (ProcesarRueda(e.Delta, (ModifierKeys & Keys.Control) != 0, e.Location))
        {
            if (e is HandledMouseEventArgs handled) handled.Handled = true;
            return;
        }
        base.OnMouseWheel(e);
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        base.OnMouseEnter(e);
        if (CanFocus) Focus();
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (!arrastrar || e.Button != MouseButtons.Left || paginas.Count == 0) return;
        inicioArrastre = e.Location;
        scrollArrastre = new Point(-AutoScrollPosition.X, -AutoScrollPosition.Y);
        arrastrando = true;
        Capture = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (!arrastrando) return;
        AutoScrollPosition = new Point(Math.Max(0, scrollArrastre.X + inicioArrastre.X - e.X),
            Math.Max(0, scrollArrastre.Y + inicioArrastre.Y - e.Y));
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button == MouseButtons.Left && arrastrando) Capture = false;
    }

    protected override void OnMouseCaptureChanged(EventArgs e)
    {
        if (!Capture) arrastrando = false;
        base.OnMouseCaptureChanged(e);
    }

    protected override void OnScroll(ScrollEventArgs se)
    {
        base.OnScroll(se);
        Invalidate();
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (ajustando) return;
        var anterior = ultimaArea.IsEmpty ? ClientSize : ultimaArea;
        var relativo = PuntoRelativo(new Point(anterior.Width / 2, anterior.Height / 2), anterior);
        RecalcularExtension();
        if (paginas.Count > 0)
            AutoScrollPosition = DesplazamientoParaAncla(tamanoGrupo, ClientSize, Separacion,
                new Point(ClientSize.Width / 2, ClientSize.Height / 2), relativo);
        Invalidate();
    }

    protected override void OnDpiChangedAfterParent(EventArgs e)
    {
        base.OnDpiChangedAfterParent(e);
        // El EMF conserva las medidas físicas; sólo cambia su reproducción sobre el nuevo monitor.
        RecalcularExtension();
        Invalidate();
    }

    private PointF PuntoRelativo(Point punto, Size area)
    {
        if (tamanoGrupo.IsEmpty) return new PointF(.5f, .5f);
        var rectangulo = CentrarPapel(tamanoGrupo, area, AutoScrollPosition, Separacion);
        return new PointF((punto.X - rectangulo.Left) / rectangulo.Width,
            (punto.Y - rectangulo.Top) / rectangulo.Height);
    }

    private void RecalcularExtension()
    {
        if (ajustando) return;
        ajustando = true;
        try
        {
            tamanoGrupo = paginas.Count == 0 ? SizeF.Empty : new SizeF(
                paginas.Sum(p => Pixeles(p.Medida).Width) + Separacion * (paginas.Count - 1),
                paginas.Max(p => Pixeles(p.Medida).Height));
            var extension = tamanoGrupo.IsEmpty ? Size.Empty : new Size(
                (int)Math.Ceiling(tamanoGrupo.Width + 2 * Separacion),
                (int)Math.Ceiling(tamanoGrupo.Height + 2 * Separacion));
            if (AutoScrollMinSize != extension) AutoScrollMinSize = extension;
            ultimaArea = ClientSize;
        }
        finally { ajustando = false; }
    }

    internal static RectangleF CentrarPapel(SizeF medida, Size area, Point scroll, float margen)
    {
        if (medida.IsEmpty) return RectangleF.Empty;
        return new RectangleF(Math.Max(margen, (area.Width - medida.Width) / 2f) + scroll.X,
            Math.Max(margen, (area.Height - medida.Height) / 2f) + scroll.Y, medida.Width, medida.Height);
    }

    internal static Point DesplazamientoParaAncla(SizeF medida, Size area, float margen, Point punto, PointF relativo)
    {
        var rectangulo = CentrarPapel(medida, area, Point.Empty, margen);
        int maximoX = Math.Max(0, (int)Math.Ceiling(medida.Width + 2 * margen) - area.Width);
        int maximoY = Math.Max(0, (int)Math.Ceiling(medida.Height + 2 * margen) - area.Height);
        return new Point(Math.Clamp((int)Math.Round(rectangulo.Left + medida.Width * relativo.X - punto.X), 0, maximoX),
            Math.Clamp((int)Math.Round(rectangulo.Top + medida.Height * relativo.Y - punto.Y), 0, maximoY));
    }

    private static void Calidad(Graphics dibujo)
    {
        dibujo.SmoothingMode = SmoothingMode.AntiAlias;
        dibujo.PixelOffsetMode = PixelOffsetMode.HighQuality;
        dibujo.CompositingQuality = CompositingQuality.HighQuality;
        dibujo.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (paginas.Count == 0) return;
        var estado = e.Graphics.Save();
        try
        {
            e.Graphics.PageUnit = GraphicsUnit.Pixel;
            Calidad(e.Graphics);
            var rectangulos = RectangulosPapel;
            using var sombra = new SolidBrush(Color.FromArgb(48, 52, 71, 88));
            using var borde = new Pen(Color.FromArgb(167, 147, 98), Math.Max(1, DeviceDpi / 96f));
            for (int i = 0; i < paginas.Count; i++)
            {
                var rectangulo = rectangulos[i];
                var marco = rectangulo;
                marco.Inflate(6 * DeviceDpi / 96f, 6 * DeviceDpi / 96f);
                if (!marco.IntersectsWith(e.ClipRectangle)) continue;
                e.Graphics.FillRectangle(sombra, rectangulo.X + 4, rectangulo.Y + 4, rectangulo.Width, rectangulo.Height);
                e.Graphics.FillRectangle(Brushes.White, rectangulo);
                var recorte = e.Graphics.Save();
                try
                {
                    e.Graphics.SetClip(rectangulo, CombineMode.Intersect);
                    // GDI+ reproduce los registros EMF+, incluidos los glifos, a la escala final.
                    e.Graphics.DrawImage(paginas[i].Imagen, rectangulo);
                }
                finally { e.Graphics.Restore(recorte); }
                e.Graphics.DrawRectangle(borde, rectangulo.X, rectangulo.Y, rectangulo.Width, rectangulo.Height);
            }
        }
        finally { e.Graphics.Restore(estado); }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            foreach (var imagen in paginas) imagen.Dispose();
            paginas.Clear();
            vista = null;
        }
        base.Dispose(disposing);
    }
}
