using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class VistaPreliminarReportesCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarVistaSinImpresora(exige);
        VerificarBandasAcero(exige);
        VerificarSuperficie(exige);
        VerificarFondoYBusqueda(exige);
        VerificarFormulario(exige);
    }

    private static void VerificarVistaSinImpresora(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        var configuracion = new MYGConfiguracionVistaReporte(reportes);
        var vertical = MYGReportesImpresion.PrepararVista(configuracion.Reportes);
        exige(vertical.CantidadPaginas > 3,
            "La vista sin impresora debe paginar un reporte largo y conservar sus filas combinadas y ocultas.");
        SizeF papelVertical = vertical.TamanoPagina(0);
        exige(Cerca(papelVertical.Width, 8.27f) && Cerca(papelVertical.Height, 11.69f),
            "La vista lógica debe usar el tamaño A4 vertical sin consultar una impresora.");
        using var primera = Dibujar(vertical, 0);
        using var ultima = Dibujar(vertical, vertical.CantidadPaginas - 1);
        exige(TieneContenido(primera) && TieneContenido(ultima),
            "La primera y última página deben dibujar contenido real sobre el papel blanco.");
        exige(FirmaContenido(primera) != FirmaContenido(ultima),
            "La paginación debe cambiar el cuerpo dibujado entre la primera y la última página, además del número del pie.");
        for (int indice = 0; indice < vertical.CantidadPaginas; indice++)
        {
            using var imagen = Dibujar(vertical, indice);
            exige(!ContieneFilaOculta(imagen),
                "La vista preliminar debe omitir el relleno magenta de las filas ocultas en todas sus páginas.");
        }

        configuracion.ConfigurarPagina("A4", "Horizontal", .5m, .5m, .5m, .5m);
        var horizontal = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala, null);
        SizeF papelHorizontal = horizontal.TamanoPagina(0);
        exige(Cerca(papelHorizontal.Width, papelVertical.Height) && Cerca(papelHorizontal.Height, papelVertical.Width),
            "Cambiar a horizontal debe intercambiar el ancho y alto del papel de la vista preliminar.");
        exige(horizontal.CantidadPaginas > vertical.CantidadPaginas,
            "Un reporte angosto y largo debe necesitar más páginas cuando la orientación reduce el alto disponible.");

        configuracion.ConfigurarPagina("A3", "Vertical", .5m, .5m, .5m, .5m);
        var a3 = MYGReportesImpresion.PrepararVista(configuracion.Reportes);
        exige(Cerca(a3.TamanoPagina(0).Width, 11.69f) && Cerca(a3.TamanoPagina(0).Height, 16.54f) &&
            a3.CantidadPaginas < vertical.CantidadPaginas,
            "Elegir A3 debe recalcular el tamaño y reducir las páginas del reporte largo.");

        configuracion.ConfigurarPagina("A4", "Vertical", .5m, .5m, .5m, .5m);
        configuracion.Escala = .5f;
        var reducido = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala);
        exige(reducido.CantidadPaginas < vertical.CantidadPaginas,
            "Reducir la escala de impresión debe recalcular los saltos de página sin cambiar el tamaño del papel.");
        using var paginaReducida = Dibujar(reducido, 0);
        exige(TieneContenido(paginaReducida) && FirmaContenido(paginaReducida) != FirmaContenido(primera),
            "La escala elegida debe afectar el contenido dibujado y conservar una página visible.");
        configuracion.Restaurar();
        var restaurada = MYGReportesImpresion.PrepararVista(configuracion.Reportes, configuracion.Escala);
        using var paginaRestaurada = Dibujar(restaurada, 0);
        exige(restaurada.CantidadPaginas == vertical.CantidadPaginas && FirmaContenido(paginaRestaurada) == FirmaContenido(primera),
            "Restablecer debe recuperar los saltos y la representación original del reporte.");
        exige(Datos(reportes) == originales,
            "Preparar, dibujar, configurar y restablecer la vista debe conservar los datos, fórmulas y dimensiones de origen.");
    }

    private static void VerificarBandasAcero(Action<bool, string> exige)
    {
        var hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        hoja.AreaImpresion = "A1:AH16";
        hoja.Poner("A3", "Viga principal"); hoja.Poner("B3", "2"); hoja.Poner("C3", "4");
        hoja.Poner("D3", "3/8"); hoja.Poner("E3", "5");
        for (int columna = 31; columna <= 34; columna++)
        {
            string letra = MYGHojaCalculo.Columna(columna);
            hoja.Poner(letra + "2", letra, true);
            hoja.Poner(letra + "3", "Dato " + letra);
            hoja.Celdas[letra + "3"].ColorFondo = "D7EBC4";
        }
        var reportes = new[] { new MYGHojaReporteProyecto("Metrado de fierros y aceros", hoja) };
        string originales = Datos(reportes);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        exige(vista.CantidadPaginas > 1,
            "La vista preliminar de aceros debe generar bandas horizontales legibles para sus 34 columnas.");
        using var primera = Dibujar(vista, 0);
        using var ultima = Dibujar(vista, vista.CantidadPaginas - 1);
        exige(TieneContenido(primera) && TieneContenido(ultima) && FirmaContenido(primera) != FirmaContenido(ultima),
            "La última banda de acero debe dibujar sus propios datos y no repetir únicamente la primera página.");
        exige(ContieneColor(ultima, Color.FromArgb(215, 235, 196)),
            "Las columnas finales AE–AH deben permanecer visibles en la última banda de la hoja de aceros.");
        exige(Datos(reportes) == originales,
            "Segmentar y dibujar la plantilla de aceros debe conservar todas las fórmulas y anchos originales.");
    }

    private static void VerificarSuperficie(Action<bool, string> exige)
    {
        var vista = MYGReportesImpresion.PrepararVista(ReporteLargo());
        using var superficie = new MYGVistaPaginaControl { Dock = DockStyle.None, Size = new Size(900, 700) };
        superficie.CreateControl();
        float dpi = superficie.DeviceDpi / 96f;
        superficie.Size = new Size((int)(900 * dpi), (int)(700 * dpi));
        superficie.Cargar(vista, 0);
        superficie.CambiarZoom(.4f);
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize),
            "Una hoja que cabe en la superficie debe quedar centrada horizontal y verticalmente.");
        superficie.Size = new Size((int)(1100 * dpi), (int)(820 * dpi));
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize),
            "Redimensionar la ventana debe conservar el papel centrado en el área disponible.");
        superficie.CambiarZoom(.55f);
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize),
            "Cambiar el zoom de una hoja que cabe debe recalcular su posición centrada.");

        superficie.CambiarZoom(1.5f);
        var ancla = new Point((int)(300 * dpi), (int)(300 * dpi));
        PointF antes = Relativo(superficie.RectanguloPapel, ancla);
        int cambiosZoom = 0;
        superficie.AmpliacionChanged += (_, _) => cambiosZoom++;
        superficie.ProcesarRueda(60, true, ancla);
        PointF despues = Relativo(superficie.RectanguloPapel, ancla);
        exige(Math.Abs(antes.X - despues.X) < .005f && Math.Abs(antes.Y - despues.Y) < .005f,
            "Ctrl y rueda deben conservar el punto del documento situado bajo el cursor al ampliar.");
        exige(superficie.Ampliacion > 1.5f && superficie.Ampliacion < 1.5f * 1.12f && cambiosZoom == 1,
            "Un delta parcial de la rueda debe producir un cambio proporcional y avisar a los controles de ampliación.");

        superficie.CambiarZoom(1);
        superficie.ProcesarRueda(60, true, ancla);
        superficie.ProcesarRueda(60, true, ancla);
        float dosMediosPasos = superficie.Ampliacion;
        superficie.CambiarZoom(1);
        superficie.ProcesarRueda(120, true, ancla);
        exige(Cerca(superficie.Ampliacion, dosMediosPasos),
            "Dos deltas parciales deben acumular el mismo zoom que un paso completo de la rueda.");
        superficie.ProcesarRueda(-120, true, ancla);
        exige(Cerca(superficie.Ampliacion, 1),
            "Alejar con Ctrl y rueda debe invertir la ampliación y mantener el movimiento continuo.");
        exige(!superficie.ProcesarRueda(120, false, ancla) && Cerca(superficie.Ampliacion, 1),
            "La rueda sin Ctrl debe conservar el zoom y quedar disponible para el desplazamiento normal.");
        superficie.CambiarZoom(100);
        exige(Cerca(superficie.Ampliacion, 4), "La ampliación debe limitarse al 400% sin crear una página rasterizada gigante.");
        superficie.CambiarZoom(.01f);
        exige(Cerca(superficie.Ampliacion, .25f), "El zoom manual debe limitarse al 25% para conservar una página utilizable.");

        superficie.AjustarPagina();
        exige(PapelCentrado(superficie.RectanguloPapel, superficie.ClientSize) &&
            superficie.RectanguloPapel.Width <= superficie.ClientSize.Width && superficie.RectanguloPapel.Height <= superficie.ClientSize.Height,
            "Página completa debe ajustar y centrar el papel dentro del área visible.");
        superficie.VariasPaginas = true;
        superficie.AjustarPagina();
        var papeles = superficie.RectangulosPapel;
        var grupo = papeles.Count == 2 ? RectangleF.Union(papeles[0], papeles[1]) : RectangleF.Empty;
        exige(papeles.Count == 2 && papeles[0].Right < papeles[1].Left && PapelCentrado(grupo, superficie.ClientSize),
            "Varias páginas debe mostrar dos hojas separadas y centrar el conjunto completo.");
        superficie.Arrastrar = true;
        exige(superficie.Arrastrar && superficie.Cursor == Cursors.Hand,
            "La herramienta mano debe activar el desplazamiento del papel con el cursor de arrastre.");
        superficie.Arrastrar = false;
        exige(!superficie.Arrastrar && superficie.Cursor == Cursors.Default,
            "La herramienta puntero debe salir del modo de arrastre.");
        superficie.Cargar(vista, vista.CantidadPaginas - 1);
        exige(superficie.RectangulosPapel.Count == 1,
            "Varias páginas en el final del reporte debe mostrar una sola hoja sin intentar leer una página inexistente.");
        superficie.VariasPaginas = false;
        superficie.Size = new Size(600, 600);
        superficie.Cargar(vista, 0);
        superficie.CambiarZoom(4, Point.Empty);
        // Se muestra el comienzo del contenido, también en monitores con DPI alto.
        int margen = (int)(.4f * superficie.DeviceDpi * superficie.Ampliacion);
        superficie.AutoScrollPosition = new Point(margen, margen);
        VerificarNitidez(superficie, vista, exige);
        superficie.Limpiar();
        exige(superficie.TamanoPapel.IsEmpty && superficie.RectangulosPapel.Count == 0 &&
            !superficie.ProcesarRueda(120, true, ancla),
            "Limpiar debe liberar las páginas y dejar inactivos el dibujo y el zoom con rueda.");
    }

    private static void VerificarNitidez(MYGVistaPaginaControl superficie, MYGReportesImpresion.Vista vista,
        Action<bool, string> exige)
    {
        // Sólo se dibuja el área visible de 600 px. La página completa al 400%
        // sigue guardada como vectores y no necesita una captura de varios miles de píxeles.
        using var ampliada = DibujarControl(superficie);
        using var directa = new Bitmap(superficie.Width, superficie.Height);
        directa.SetResolution(96, 96);
        RectangleF papel = superficie.RectanguloPapel;
        using (var g = Graphics.FromImage(directa))
        {
            g.Clear(superficie.BackColor);
            Calidad(g);
            g.SetClip(papel);
            g.PageUnit = GraphicsUnit.Inch;
            g.TranslateTransform(papel.X / g.DpiX, papel.Y / g.DpiY);
            SizeF medida = vista.TamanoPagina(0);
            g.ScaleTransform(papel.Width / (medida.Width * g.DpiX), papel.Height / (medida.Height * g.DpiY));
            vista.DibujarPagina(g, 0);
        }
        using var captura96 = Dibujar(vista, 0);
        using var estirada = new Bitmap(superficie.Width, superficie.Height);
        using (var g = Graphics.FromImage(estirada))
        {
            g.Clear(superficie.BackColor);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(captura96, papel);
        }
        var papelVisible = RectangleF.Intersect(papel, new RectangleF(PointF.Empty, superficie.ClientSize));
        var errores = ErrorDeTexto(ampliada, directa, estirada, papelVisible);
        exige(errores.Pixeles > 500 && errores.Vector < errores.Raster,
            "Al 400%, el texto vectorial debe aproximarse al dibujo directo mejor que una captura de 96 DPI estirada.");
    }

    private static void VerificarFondoYBusqueda(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        var vista = MYGReportesImpresion.PrepararVista(reportes);
        int encontrada = vista.BuscarPagina("Elemento 170", 0);
        exige(encontrada > 0 && encontrada < vista.CantidadPaginas && vista.BuscarPagina("Texto inexistente", 0) == -1,
            "Buscar debe encontrar el contenido en su página y distinguir un texto ausente.");
        exige(vista.BuscarPagina("Elemento 170", encontrada + 1) == encontrada,
            "La búsqueda debe recorrer el documento y volver al principio cuando el texto queda en una página anterior.");
        using var original = Dibujar(vista, 0);
        vista.ColorPagina = Color.AliceBlue;
        using var coloreada = Dibujar(vista, 0);
        exige(coloreada.GetPixel(8, 8).ToArgb() == Color.AliceBlue.ToArgb(),
            "El color de página debe aplicarse al papel real del mismo plan utilizado para imprimir y exportar.");
        vista.ColorPagina = Color.White;
        vista.Filigrana = "CONFIDENCIAL";
        using var marcada = Dibujar(vista, 0);
        exige(FirmaContenido(marcada) != FirmaContenido(original) && Datos(reportes) == originales,
            "La filigrana debe dibujarse en la página sin modificar las hojas del proyecto.");
    }

    private static void VerificarFormulario(Action<bool, string> exige)
    {
        var reportes = ReporteLargo();
        string originales = Datos(reportes);
        using var formulario = new MYGVistaPreliminarReportesForm("Prueba de vista preliminar", reportes);
        exige(formulario.Name == "vista_preliminar_reportes" && formulario.Text.Contains("Prueba de vista preliminar"),
            "La ventana de vista preliminar debe identificar el documento que se configura.");
        var controles = Controles(formulario).Where(c => !string.IsNullOrEmpty(c.Name)).ToDictionary(c => c.Name);
        string[] nombres = { "vista_impresora", "vista_orientacion", "vista_papel", "vista_fuente", "vista_escala",
            "vista_margen_izquierdo", "vista_margen_derecho", "vista_margen_superior", "vista_margen_inferior",
            "vista_rango", "vista_desde", "vista_hasta", "vista_copias", "vista_imprimir", "vista_pdf", "vista_zoom" };
        exige(nombres.All(controles.ContainsKey),
            "La vista debe ofrecer impresora, papel, orientación, márgenes, fuente, escala, rango, copias, PDF, impresión y ampliación.");
        exige(controles.TryGetValue("vista_cinta", out var cinta) && cinta is TabControl,
            "La vista debe presentar las herramientas en una cinta con grupos y pestaña de previsualización.");
        var accionesBarra = Controles(formulario).OfType<ToolStrip>().SelectMany(b => Acciones(b.Items))
            .Where(a => !string.IsNullOrEmpty(a.Name)).ToDictionary(a => a.Name);
        string[] acciones = { "vista_volver", "vista_imprimir_barra", "vista_pdf_barra", "vista_primera", "vista_anterior",
            "vista_siguiente", "vista_ultima", "vista_alejar", "vista_acercar", "vista_ajustar", "vista_restaurar" };
        string[] accionesImagen = { "vista_impresion_rapida", "vista_escala_barra", "vista_margenes_barra",
            "vista_orientacion_barra", "vista_tamano_barra", "vista_buscar", "vista_varias_paginas",
            "vista_puntero", "vista_mano", "vista_color_pagina", "vista_filigrana", "vista_email", "vista_guardar", "vista_abrir" };
        exige(acciones.Concat(accionesImagen).All(accionesBarra.ContainsKey),
            "La cinta debe incluir impresión, configuración, búsqueda, navegación, zoom, fondo, archivos y modos de puntero/mano.");
        exige(acciones.Concat(accionesImagen).All(nombre => accionesBarra[nombre].Image is { Width: >= 24, Height: >= 24 }),
            "Las herramientas de la cinta deben mostrar iconos de tamaño legible en lugar de botones solo de texto.");
        exige(acciones.Concat(accionesImagen).Except(new[] { "vista_puntero", "vista_mano", "vista_varias_paginas" })
            .All(nombre => accionesBarra[nombre].DisplayStyle == ToolStripItemDisplayStyle.ImageAndText),
            "Las herramientas principales deben acompañar sus iconos con sus nombres.");
        var impresora = (ComboBox)controles["vista_impresora"];
        exige(impresora.SelectedIndex < 0,
            "Construir la ventana sin mostrarla no debe seleccionar ni consultar una impresora.");
        formulario.ActualizarVista();
        var superficie = (MYGVistaPaginaControl)controles["vista_superficie"];
        using var primeraImagen = DibujarControl(superficie);
        exige(formulario.CantidadPaginas > 3 && !superficie.TamanoPapel.IsEmpty && TieneContenido(primeraImagen),
            "Actualizar la ventana sin impresora debe generar páginas y dibujar la primera vista real.");
        exige(!Controles(formulario).OfType<PictureBox>().Any(),
            "La vista preliminar debe usar una superficie vectorial y no estirar una captura de baja resolución.");
        exige(!controles["vista_imprimir"].Enabled && controles["vista_pdf"].Enabled,
            "La vista lógica debe permitir preparar PDF y mantener la impresión desactivada hasta elegir una impresora.");
        exige(!accionesBarra["vista_primera"].Enabled && !accionesBarra["vista_anterior"].Enabled &&
            accionesBarra["vista_siguiente"].Enabled && accionesBarra["vista_ultima"].Enabled,
            "La primera página debe ofrecer avance sin permitir navegar antes del comienzo.");
        ulong primera = FirmaContenido(primeraImagen);
        accionesBarra["vista_ultima"].PerformClick();
        using var ultimaImagen = DibujarControl(superficie);
        exige(FirmaContenido(ultimaImagen) != primera && accionesBarra["vista_anterior"].Enabled &&
            !accionesBarra["vista_siguiente"].Enabled,
            "Navegar a la última página debe cambiar el contenido y detener el avance al final.");
        accionesBarra["vista_primera"].PerformClick();
        using var primeraOtraVez = DibujarControl(superficie);
        exige(FirmaContenido(primeraOtraVez) == primera,
            "Volver a la primera página debe recuperar su contenido sin cambiar los datos del reporte.");

        var rango = (CheckBox)controles["vista_rango"];
        var desde = (NumericUpDown)controles["vista_desde"];
        var hasta = (NumericUpDown)controles["vista_hasta"];
        rango.Checked = true; desde.Value = 2; hasta.Value = 3;
        formulario.Configuracion.ConfigurarPagina("A4", "Horizontal", .5m, .5m, .5m, .5m);
        formulario.ActualizarVista();
        exige(desde.Enabled && hasta.Enabled && desde.Value == 2 && hasta.Value == 3,
            "Actualizar la configuración debe conservar el rango de páginas elegido cuando continúa siendo válido.");
        using var horizontal = DibujarControl(superficie);
        exige(superficie.TamanoPapel.Width > superficie.TamanoPapel.Height && TieneContenido(horizontal),
            "Aplicar orientación horizontal debe reconstruir una página ancha con contenido visible.");

        formulario.Configuracion.ConfigurarPagina("A3", "Vertical", .5m, .5m, .5m, .5m);
        formulario.Configuracion.Escala = .5f;
        formulario.ActualizarVista();
        exige(formulario.CantidadPaginas > 0 && superficie.TamanoPapel.Width < superficie.TamanoPapel.Height &&
            desde.Maximum == formulario.CantidadPaginas && hasta.Maximum == formulario.CantidadPaginas,
            "Cambiar papel y escala debe actualizar la imagen y los límites del rango de impresión.");

        formulario.Configuracion.Reportes[0].Hoja.AreaImpresion = "A1:D999";
        Exception error = null;
        try { formulario.ActualizarVista(); }
        catch (InvalidOperationException ex) { error = ex; }
        exige(error != null && formulario.CantidadPaginas == 0 && superficie.TamanoPapel.IsEmpty && superficie.RectangulosPapel.Count == 0,
            "Una configuración que no se puede renderizar debe invalidar la vista anterior y liberar sus páginas vectoriales.");
        exige(!controles["vista_imprimir"].Enabled && !controles["vista_pdf"].Enabled &&
            !accionesBarra["vista_primera"].Enabled && !accionesBarra["vista_ultima"].Enabled,
            "Una vista inválida debe desactivar impresión, PDF y navegación para impedir exportar páginas antiguas.");
        formulario.Configuracion.Restaurar();
        formulario.ActualizarVista();
        exige(formulario.CantidadPaginas > 3 && !superficie.TamanoPapel.IsEmpty,
            "Restaurar después de un error debe permitir reconstruir la vista preliminar.");
        formulario.Close(); formulario.Dispose();
        exige(formulario.IsDisposed && Datos(reportes) == originales,
            "Configurar, navegar, recuperar un error y cerrar la vista preliminar debe dejar intactas las hojas originales.");
    }

    private static MYGHojaReporteProyecto[] ReporteLargo()
    {
        var hoja = new MYGHojaMetrado
        {
            Nombre = "Metrados", Filas = 182, Columnas = 3, CeldaTotal = "C182", AreaImpresion = "A1:C182",
            RepetirTitulos = true, FilasInmovilizadas = 2, ImprimirLineasDivision = true,
            AnchosColumnas = new() { [1] = 220, [2] = 120, [3] = 120 }
        };
        hoja.RangosCombinados.Add("A1:C1");
        hoja.Poner("A1", "METRADOS DEL PROYECTO", true);
        hoja.Poner("A2", "Descripción", true); hoja.Poner("B2", "Cantidad", true); hoja.Poner("C2", "Parcial", true);
        for (int fila = 3; fila < 182; fila++)
        {
            hoja.AltosFilas[fila] = 24;
            hoja.Poner("A" + fila, "Elemento " + fila);
            hoja.Poner("B" + fila, fila.ToString(System.Globalization.CultureInfo.InvariantCulture));
            hoja.Poner("C" + fila, "=B" + fila + "*2");
            hoja.Celdas["A" + fila].ColorFondo = fila < 80 ? "D8E9F8" : "E4EBD2";
        }
        hoja.Poner("A182", "TOTAL", true); hoja.Poner("C182", "=SUM(C3:C181)", true);
        hoja.FilasOcultas.AddRange(new[] { 10, 95 });
        // Si la fila oculta entra en el plan, su altura excede el área A4 y su
        // relleno permite detectar que fue dibujada en cualquier página.
        hoja.AltosFilas[10] = 1000;
        foreach (string columna in new[] { "A", "B", "C" }) hoja.Celdas[columna + "10"].ColorFondo = "FF00FF";
        foreach (var celda in hoja.Celdas.Values) celda.Fuente = "Arial";
        MYGHojaCalculo.Validar(hoja);
        return new[] { new MYGHojaReporteProyecto("Metrados de prueba", hoja) };
    }

    private static Bitmap Dibujar(MYGReportesImpresion.Vista vista, int indice)
    {
        SizeF medida = vista.TamanoPagina(indice);
        var imagen = new Bitmap((int)Math.Ceiling(medida.Width * 96), (int)Math.Ceiling(medida.Height * 96));
        imagen.SetResolution(96, 96);
        using var graphics = Graphics.FromImage(imagen);
        graphics.Clear(Color.White);
        Calidad(graphics);
        vista.DibujarPagina(graphics, indice);
        return imagen;
    }

    private static Bitmap DibujarControl(Control control)
    {
        var imagen = new Bitmap(Math.Max(1, control.Width), Math.Max(1, control.Height));
        imagen.SetResolution(96, 96);
        control.DrawToBitmap(imagen, new Rectangle(Point.Empty, imagen.Size));
        return imagen;
    }

    private static void Calidad(Graphics graphics)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
        graphics.CompositingQuality = CompositingQuality.HighQuality;
        graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
    }

    private static bool PapelCentrado(RectangleF papel, Size area) => !papel.IsEmpty &&
        Math.Abs(papel.Left + papel.Width / 2 - area.Width / 2f) < 1.1f &&
        Math.Abs(papel.Top + papel.Height / 2 - area.Height / 2f) < 1.1f;

    private static PointF Relativo(RectangleF papel, Point punto) =>
        new((punto.X - papel.Left) / papel.Width, (punto.Y - papel.Top) / papel.Height);

    private static (double Vector, double Raster, int Pixeles) ErrorDeTexto(Bitmap vector, Bitmap directa,
        Bitmap raster, RectangleF papel)
    {
        double errorVector = 0, errorRaster = 0;
        int pixeles = 0;
        var area = Rectangle.Intersect(Rectangle.Ceiling(papel), new Rectangle(Point.Empty, directa.Size));
        area.Inflate(-3, -3);
        for (int y = area.Top; y < area.Bottom; y++)
            for (int x = area.Left; x < area.Right; x++)
            {
                Color esperado = directa.GetPixel(x, y), real = vector.GetPixel(x, y), antiguo = raster.GetPixel(x, y);
                // Compara contornos de texto y líneas; el papel en blanco no
                // puede ocultar una diferencia de nitidez en unos pocos glifos.
                if (esperado.R + esperado.G + esperado.B >= 540 && real.R + real.G + real.B >= 540 &&
                    antiguo.R + antiguo.G + antiguo.B >= 540) continue;
                errorVector += Math.Abs(real.R - esperado.R) + Math.Abs(real.G - esperado.G) + Math.Abs(real.B - esperado.B);
                errorRaster += Math.Abs(antiguo.R - esperado.R) + Math.Abs(antiguo.G - esperado.G) + Math.Abs(antiguo.B - esperado.B);
                pixeles++;
            }
        return (errorVector, errorRaster, pixeles);
    }

    private static bool TieneContenido(Bitmap imagen)
    {
        int tinta = 0;
        for (int y = 0; y < imagen.Height; y += 4)
            for (int x = 0; x < imagen.Width; x += 4)
                if (imagen.GetPixel(x, y).ToArgb() != Color.White.ToArgb() && ++tinta > 100) return true;
        return false;
    }

    private static ulong FirmaContenido(Bitmap imagen)
    {
        // Excluye el título y el pie: los números de página por sí solos no
        // demuestran que cambió el cuerpo del informe.
        ulong firma = 14695981039346656037;
        for (int y = 96; y < imagen.Height - 96; y += 4)
            for (int x = 48; x < imagen.Width - 48; x += 4)
                firma = unchecked((firma ^ (uint)imagen.GetPixel(x, y).ToArgb()) * 1099511628211);
        return firma;
    }

    private static bool ContieneFilaOculta(Bitmap imagen) => ContieneColor(imagen, Color.Magenta);
    private static bool ContieneColor(Bitmap imagen, Color color)
    {
        for (int y = 0; y < imagen.Height; y += 4)
            for (int x = 0; x < imagen.Width; x += 4)
                if (imagen.GetPixel(x, y).ToArgb() == color.ToArgb()) return true;
        return false;
    }

    private static IEnumerable<Control> Controles(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (Control descendiente in Controles(hijo)) yield return descendiente;
        }
    }

    private static IEnumerable<ToolStripItem> Acciones(ToolStripItemCollection items)
    {
        foreach (ToolStripItem item in items)
        {
            yield return item;
            if (item is ToolStripDropDownItem desplegable)
                foreach (var hijo in Acciones(desplegable.DropDownItems)) yield return hijo;
        }
    }

    private static bool Cerca(float a, float b) => Math.Abs(a - b) < .01f;
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
}
