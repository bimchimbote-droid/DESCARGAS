using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class TitulosNativosCheck
{
    private static int comprobaciones;
    internal static Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-titulos-nativos-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string origen = Path.Combine(carpeta, "origen.sqlite");
            var documento = MYGProyectoStorage.Nuevo("Obra título Delphin", "Presupuesto");
            const string idNativo = "TI_NATIVE01";
            string idItem = MYGProyectoStorage.NuevoId();
            documento.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            {
                Id = idItem, IdLocalMYG = idItem, IdInternoDelphin = idNativo, TipoPropuesta = "TITULO",
                Descripcion = "Título operativo importado", Item = "01", Posicion = 1
            });
            MYGBaseDatos.CrearBaseVacia(origen);
            Sql(origen, "INSERT INTO titulo(id_titulo,descripcion_titulo,nivel_titulo,nombre_fuente,duracion_new) VALUES('TI_NATIVE01','Inicial',3,'Fuente QA',12.5)");
            MYGProyectoStorage.Guardar(origen, documento);
            JsonElement paquete = BaseCentralNube.CrearContenidoEstricto(origen, documento.Id);
            string destino = Path.Combine(carpeta, "destino.sqlite");
            Vincular(destino, paquete);
            Exige(Sql(destino, "SELECT count(*) FROM titulo WHERE id_titulo='TI_NATIVE01'") == "1",
                "la descarga conserva el título importado como titulo, sin convertirlo a costo_unitario");
            Exige(Sql(destino, "SELECT count(*) FROM costo_unitario WHERE id_costounitario='TI_NATIVE01'") == "0",
                "el título no adquiere una representación nativa adicional");
            Exige(Sql(destino, "SELECT nombre_fuente FROM titulo WHERE id_titulo='TI_NATIVE01'") == "Fuente QA"
                && Sql(destino, "SELECT nivel_titulo FROM titulo WHERE id_titulo='TI_NATIVE01'") == "3",
                "los atributos nativos que Core no reconstruye se conservan");
            var recibido = MYGBaseDatos.LeerProyecto(destino, documento.Id);
            Exige(PaqueteNube.FirmaDatosCompartidos(paquete) == PaqueteNube.FirmaDatosCompartidos(
                BaseCentralNube.CrearContenidoEstricto(destino, recibido.Id)), "el paquete reconstruido mantiene su firma completa");

            RechazaPaquete("identidad-ajena", "id_titulo", "AJENO0000001");
            RechazaPaquete("presupuesto-ajeno", "id_presupuesto", "OTRO00000001");
            RechazaPaquete("padre-ajeno", "id_titulopadre", "AJENO0000001");
            void RechazaPaquete(string nombre, string columna, string valor)
            {
                var copia = JsonNode.Parse(paquete.GetRawText())!.AsObject();
                var tabla = copia["tablas"]!.AsArray().Single(t => t!["Nombre"]!.GetValue<string>() == "titulo")!;
                int posicion = tabla["Columnas"]!.AsArray().Select(x => x!.GetValue<string>()).ToList().IndexOf(columna);
                tabla["Filas"]![0]![posicion]!["Tipo"] = "texto";
                tabla["Filas"]![0]![posicion]!["Valor"] = valor;
                string salida = Path.Combine(carpeta, nombre + ".sqlite");
                Rechaza(() => Vincular(salida, JsonSerializer.SerializeToElement(copia)), "rechaza " + nombre);
                Exige(Sql(salida, "SELECT count(*) FROM titulo WHERE id_titulo IN('TI_NATIVE01','AJENO0000001')") == "0",
                    "el rechazo no deja un título parcialmente insertado");
            }

            string protegida = Path.Combine(carpeta, "otro-presupuesto.sqlite");
            MYGBaseDatos.CrearBaseVacia(protegida);
            Sql(protegida, "INSERT INTO titulo(id_titulo,descripcion_titulo,id_presupuesto) VALUES('TI_NATIVE01','Privado intacto','OTRO00000001')");
            Rechaza(() => Vincular(protegida, paquete), "no cambia el presupuesto de una fila nativa existente");
            Exige(Sql(protegida, "SELECT descripcion_titulo FROM titulo WHERE id_titulo='TI_NATIVE01'") == "Privado intacto"
                && Sql(protegida, "SELECT id_presupuesto FROM titulo WHERE id_titulo='TI_NATIVE01'") == "OTRO00000001",
                "el título de otro presupuesto mantiene todos sus datos");

            string registrada = Path.Combine(carpeta, "otra-obra.sqlite");
            MYGBaseDatos.CrearBaseVacia(registrada);
            Sql(registrada, "INSERT INTO titulo(id_titulo,descripcion_titulo) VALUES('TI_NATIVE01','Otra obra'); INSERT INTO myg_delphin_fila(propietario,tabla,id_nativo) VALUES('proyecto:otra','titulo','TI_NATIVE01')");
            Rechaza(() => Vincular(registrada, paquete), "respeta el registro de propiedad de otra obra");
            Exige(Sql(registrada, "SELECT descripcion_titulo FROM titulo WHERE id_titulo='TI_NATIVE01'") == "Otra obra",
                "una fila de otra obra no se modifica");

            string nueva = Path.Combine(carpeta, "nueva.sqlite");
            var documentoNuevo = MYGProyectoStorage.Nuevo("Título nuevo MYG", "Presupuesto");
            string idNuevo = MYGProyectoStorage.NuevoId();
            documentoNuevo.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            { Id = idNuevo, IdLocalMYG = idNuevo, TipoPropuesta = "TITULO", Descripcion = "Nuevo" });
            MYGProyectoStorage.Guardar(nueva, documentoNuevo);
            var paqueteNuevo = BaseCentralNube.CrearContenidoEstricto(nueva, documentoNuevo.Id);
            string nuevaDescarga = Path.Combine(carpeta, "nueva-descarga.sqlite");
            Vincular(nuevaDescarga, paqueteNuevo);
            Exige(Sql(nuevaDescarga, "SELECT count(*) FROM titulo") == "0",
                "los títulos nuevos MYG no se fuerzan a la representación importada");
            Exige(PaqueteNube.FirmaDatosCompartidos(paqueteNuevo) == PaqueteNube.FirmaDatosCompartidos(
                BaseCentralNube.CrearContenidoEstricto(nuevaDescarga, documentoNuevo.Id)),
                "la modalidad nueva de Core también conserva su firma");
            using (var conexion = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = nuevaDescarga, Mode = SqliteOpenMode.ReadWrite, Pooling = false }.ToString()))
            {
                conexion.Open(); using var transaccion = conexion.BeginTransaction();
                BaseCentralNube.PrepararTitulosNativos(JsonSerializer.SerializeToElement(new { Id = "legado-sin-tablas" }), conexion, transaccion);
                BaseCentralNube.PrepararTitulosNativos(JsonSerializer.SerializeToElement(new { tablas = Array.Empty<object>() }), conexion, transaccion);
                transaccion.Rollback();
            }
            Exige(Sql(nuevaDescarga, "SELECT count(*) FROM titulo") == "0",
                "la preparación no cambia el contrato de paquetes anteriores sin títulos nativos");
            Console.WriteLine($"OK Títulos nativos: {comprobaciones} comprobaciones de importación, representación, atributos, presupuesto, padre y aislamiento; SQLite real.");
            return Task.CompletedTask;
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static void Vincular(string ruta, JsonElement paquete)
    {
        if (!File.Exists(ruta)) MYGBaseDatos.CrearBaseVacia(ruta);
        var documento = PaqueteNube.MaterializarDocumento(paquete, ruta);
        MYGColaboracionLocal.Vincular(ruta, documento, new MYGVinculoNube
        {
            ProyectoId = Guid.Parse("dd220000-0000-0000-0000-000000000001"),
            UsuarioId = "dd220000-0000-0000-0000-000000000002", Servidor = "https://titulos-qa.supabase.co",
            Rol = "propietario", Revision = 1, JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(documento),
            JsonPaqueteConfirmado = paquete.GetRawText()
        }, (c, t) =>
        {
            PaqueteNube.AplicarDependencias(paquete, c, t);
            BaseCentralNube.PrepararTitulosNativos(paquete, c, t);
        });
    }

    private static string Sql(string ruta, string texto)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = ruta, Mode = SqliteOpenMode.ReadWrite, Pooling = false }.ToString());
        c.Open(); using var cmd = c.CreateCommand(); cmd.CommandText = texto;
        return Convert.ToString(cmd.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) ?? "";
    }
    private static void Rechaza(Action accion, string mensaje)
    {
        try { accion(); }
        catch (InvalidDataException) { comprobaciones++; return; }
        throw new InvalidOperationException("Títulos nativos: no rechazó " + mensaje);
    }
    private static void Exige(bool condicion, string mensaje)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Títulos nativos: " + mensaje); }
}
