using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Regresión de la base real con datos Delphin adicionales: cada una de
/// las 35 tablas del diagnóstico tiene filas, tipos y relaciones comprobables.</summary>
internal static partial class CentralIntegracionCheck
{
    private const string DatosPrivados = "QA-DATOS-RESIDUALES-PRIVADOS-5DD7";
    private static readonly string[] TablasAdicionales =
    [
        "cargo", "clase_gl", "concepto", "costo_partida", "cuenta", "cuenta_caja", "cuenta_gl", "cuenta_gl_temp",
        "detalle_planilla", "diccionario", "documento", "documento_identidad", "estado_civil", "formato_documento",
        "forma_pago", "hoja_planilla", "modalidad_map", "modalidad_pago", "motivo", "partida", "persona", "planilla",
        "plantilla_clasificador", "plantilla_gasto", "secuencia", "secuencia_documento", "sucursal", "tipo_afp",
        "tipo_asiento", "tipo_caja", "tipo_concepto", "tipo_persona", "titulo", "titulo_clasificador", "titulo_indice"
    ];

    internal static async Task RunPreservacionAsync(string contenedor)
    {
        if (!Regex.IsMatch(contenedor, "^[a-zA-Z0-9][a-zA-Z0-9_.-]{5,127}$"))
            throw new ArgumentException("Indique el PostgreSQL desechable de Probar-PreservacionCentral.sh.");
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-preservacion-integracion-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var sql = new PostgreSqlLocal(contenedor);
        using var red = new Puente(sql, Propietario);
        using var redColaborador = new Puente(sql, Colaborador);
        try
        {
            await sql.Ejecutar($"INSERT INTO myg_nube_privado.identidades_verificadas VALUES('{Propietario:D}','qa_preservacion_dueno',true),('{Colaborador:D}','qa_preservacion_colaborador',true);");
            using var propietario = await Conectar(red);
            using var colaborador = await Conectar(redColaborador);
            string origen = Path.Combine(carpeta, "base-con-datos-adicionales.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Obra norte autorizada preservación", "Presupuesto norte");
            var sur = MYGProyectoStorage.Nuevo(Privado, "Presupuesto sur");
            var insumo = new MYGInsumo { Codigo = "QA-PRESERVACION-INSUMO", Descripcion = "Insumo operativo", Unidad = "kg", Precio = 12.34m };
            norte.Presupuestos[0].Costos.Insumos.Add(insumo);
            string tituloId = "OWNED-5DD7", partidaId = MYGProyectoStorage.NuevoId();
            const string tituloOperativo = "Título operativo que se elimina en revisión dos";
            norte.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            { Id = tituloId, IdLocalMYG = tituloId, TipoPropuesta = "TITULO", Descripcion = tituloOperativo });
            norte.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            {
                Id = partidaId, IdLocalMYG = partidaId, ParentId = tituloId, TipoPropuesta = "PARTIDA", Descripcion = "Partida operativa", Unidad = "und",
                Costos = new MYGDatosPartida { Cantidad = 1, RendimientoDiario = 1,
                    Analisis = new() { new MYGRecursoACU { InsumoId = insumo.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 } } }
            });
            // Una importación Delphin conserva títulos nativos existentes; los
            // títulos nuevos sin fila previa se representan como costo_unitario.
            // Preparar la fila primero hace que el caso de borrado sea real.
            MYGBaseDatos.CrearBaseVacia(origen);
            Sqlite(origen, "INSERT INTO titulo(id_titulo,descripcion_titulo) VALUES('OWNED-5DD7','Título previo a importar')");
            MYGProyectoStorage.Guardar(origen, norte); MYGProyectoStorage.Guardar(origen, sur);
            Exige(Sqlite(origen, "SELECT count(*) FROM titulo WHERE id_titulo='OWNED-5DD7' AND descripcion_titulo='" + tituloOperativo + "'") == "1",
                "el título operativo que se eliminará debe existir realmente como fila nativa antes de publicar.");
            var semillas = SembrarDatosAdicionales(origen);
            Exige(semillas.Count == 35 && semillas.Select(s => s.Tabla).Distinct().Count() == 35,
                "el fixture debe poblar todas las 35 tablas del mensaje, no solo crear sus esquemas vacíos.");
            foreach (var semilla in semillas)
                Exige(LeerFila(origen, semilla) is not null, "la tabla " + semilla.Tabla + " debe contener su fila representativa.");
            var originales = semillas.ToDictionary(s => s.Tabla, s => LeerFila(origen, s)!);
            string hashOrigen = Hash(origen);
            var almacen = new ArchivoPublicacionSqlitePendiente(Path.Combine(carpeta, "publicaciones"), Servidor, Propietario.ToString("D"));
            var pendiente = almacen.Crear("Base preservada QA", "base", norte, origen);
            string fuentePublicacion = pendiente.RutaSQLite;
            foreach (var semilla in semillas)
                Exige(LeerFila(fuentePublicacion, semilla) == originales[semilla.Tabla],
                    "la preparación real de Crear/publicar debe conservar los datos adicionales de " + semilla.Tabla + ".");
            string contadoresIniciales = await sql.Ejecutar("SELECT jsonb_build_array((SELECT count(*) FROM public.myg_nube_proyectos),(SELECT count(*) FROM storage.objects),(SELECT count(*) FROM myg_nube_privado.central_bases))::text;");
            red.OcultarCapacidadPreservacion = true;
            try
            {
                await BaseCentralNube.PublicarAsync(propietario, fuentePublicacion, "Base preservada QA");
                throw new Exception("La publicación aceptó un servidor sin la actualización de preservación.");
            }
            catch (NubeException error) when (error.Message.Contains("20261107", StringComparison.Ordinal))
            {
                Exige(!red.Rutas.Any(u => u.AbsolutePath is "/rest/v1/rpc/myg_central_crear_base" or "/rest/v1/rpc/myg_central_iniciar"
                    or "/rest/v1/rpc/myg_central_preparar" or "/rest/v1/rpc/myg_central_preparar_catalogo" or "/rest/v1/rpc/myg_central_activar"),
                    "un servidor sin 07 debe rechazarse antes de crear o preparar datos remotos.");
                Exige(hashOrigen == Hash(origen) && contadoresIniciales == await sql.Ejecutar("SELECT jsonb_build_array((SELECT count(*) FROM public.myg_nube_proyectos),(SELECT count(*) FROM storage.objects),(SELECT count(*) FROM myg_nube_privado.central_bases))::text;"),
                    "el rechazo por capacidad debe conservar el original y los contadores remotos.");
            }
            red.OcultarCapacidadPreservacion = false;
            red.PerderPrimerAckCatalogo = true;
            try
            {
                await BaseCentralNube.PublicarAsync(propietario, fuentePublicacion, "Base preservada QA");
                throw new Exception("No se simuló la pérdida del ACK del catálogo privado.");
            }
            catch (NubeException error) when (error.EsErrorDeConexion)
            {
                Exige(hashOrigen == Hash(origen), "la preparación interrumpida debe conservar el SQLite original.");
            }
            string manifiesto = Path.Combine(fuentePublicacion + ".central-publicacion", "intento.json");
            byte[] manifiestoCongelado = File.ReadAllBytes(manifiesto);
            using var intento = JsonDocument.Parse(manifiestoCongelado);
            Guid baseId = intento.RootElement.GetProperty("BaseId").GetGuid();
            Exige(await propietario.ResolverCentralAsync(baseId) is null,
                "perder el ACK al preparar el catálogo no debe hacer visible una base incompleta.");
            var central = await BaseCentralNube.PublicarAsync(propietario, fuentePublicacion, "Base preservada QA");
            Exige(central.Id == baseId && File.ReadAllBytes(manifiesto).SequenceEqual(manifiestoCongelado)
                && hashOrigen == Hash(origen), "reintentar debe conservar el UUID, el manifiesto y todos los datos de origen.");
            var obras = await propietario.ListarObrasCentralAsync(baseId);
            Exige(obras.Count == 2, "se deben publicar dos obras en la misma base.");
            var norteNube = obras.Single(o => o.DocumentoId == norte.Id);
            var surNube = obras.Single(o => o.DocumentoId == sur.Id);
            var paqueteSur = await propietario.AbrirObraCentralAsync(surNube.Id);
            string firmaSur = PaqueteNube.FirmaDatosCompartidos(paqueteSur.Contenido);
            var catalogo = await propietario.ObtenerCatalogoCentralAsync(baseId);
            foreach (var semilla in semillas)
                Exige(CatalogoContieneFila(catalogo, semilla), "el payload privado debe conservar la tabla " + semilla.Tabla + ".");
            Exige(!CatalogoContieneValor(catalogo, "titulo", tituloOperativo),
                "las filas de una obra representadas en el paquete inicial no deben duplicarse como residuales del propietario.");
            await propietario.CompartirConUsuarioMygAsync(norteNube.Id, "qa_preservacion_colaborador", "editor", new()
            { Acu = true, Especificaciones = true, MetradosExcel = true, MetradosRevit = true, MetradosRevitDisponible = true });
            await Denegado(() => colaborador.ObtenerCatalogoCentralAsync(baseId),
                "el colaborador no puede obtener persona, cuentas o planillas conociendo el UUID de base.");
            var compartida = await colaborador.AbrirProyectoAsync(norteNube.Id);
            Exige(!compartida.Contenido.GetRawText().Contains(DatosPrivados, StringComparison.Ordinal)
                && !compartida.Contenido.GetRawText().Contains(Privado, StringComparison.Ordinal),
                "el paquete de la obra autorizada no debe contener los residuales privados ni la otra obra.");
            Exige((await colaborador.ListarProyectosAsync()).Count == 1,
                "el listado del colaborador debe seguir mostrando una sola obra.");
            string recuperada = Path.Combine(carpeta, "propietario-recuperada.sqlite");
            await BaseCentralNube.CrearCopiaAsync(propietario, baseId, recuperada);
            foreach (var semilla in semillas)
                Exige(LeerFila(recuperada, semilla) == originales[semilla.Tabla],
                    "la reconstrucción debe conservar columnas, tipos y valores de " + semilla.Tabla + ".");
            ComprobarRelaciones(recuperada, semillas);
            var imagen = semillas.Single(s => s.Tabla == "persona");
            Exige(LeerBlob(recuperada, imagen, "imagen").AsSpan().SequenceEqual(Encoding.UTF8.GetBytes(DatosPrivados + ":BLOB")),
                "el BLOB de persona debe conservar todos sus bytes.");
            var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(recuperada, norte.Id);
            documento.Presupuestos[0].Items.Clear();
            documento.Presupuestos[0].Costos.Insumos.Single(i => i.Id == insumo.Id).Precio = 98.76m;
            MYGProyectoStorage.Guardar(recuperada, documento);
            var sincronizada = await SincronizadorProyectoNube.EjecutarAsync(propietario, recuperada, documento);
            Exige(sincronizada.Vinculo.Revision == 2 && sincronizada.Vinculo.Pendiente is null,
                "una edición de presupuesto debe confirmar su revisión dos sin pendientes artificiales.");
            string revisionDos = Path.Combine(carpeta, "propietario-revision-dos.sqlite");
            await BaseCentralNube.CrearCopiaAsync(propietario, baseId, revisionDos);
            Exige(Sqlite(revisionDos, "SELECT count(*) FROM titulo WHERE descripcion_titulo='" + tituloOperativo.Replace("'", "''") + "'") == "0",
                "reconstruir la base no debe resucitar un título operativo eliminado de su obra.");
            foreach (var semilla in semillas)
                Exige(LeerFila(revisionDos, semilla) == originales[semilla.Tabla],
                    "editar una obra no debe eliminar ni modificar el residual privado de " + semilla.Tabla + ".");
            Exige(PaqueteNube.FirmaDatosCompartidos((await propietario.AbrirObraCentralAsync(surNube.Id)).Contenido) == firmaSur,
                "la revisión dos de norte debe conservar exactamente la otra obra.");
            VerificarPublicacionDeCopiaProtegida(revisionDos, semillas, originales, carpeta, red);
            Exige(hashOrigen == Hash(origen), "todos los pasos deben conservar el archivo original byte por byte.");
            await RechazarColisionConResidualPrivado(propietario, colaborador, origen, revisionDos, baseId, norteNube.Id,
                semillas.Single(s => s.Tabla == "titulo"), carpeta);
            Exige(red.Rutas.Concat(redColaborador.Rutas).All(u => u.Host == new Uri(Servidor).Host
                && (u.AbsolutePath.StartsWith("/auth/", StringComparison.Ordinal) || u.AbsolutePath.StartsWith("/rest/v1/rpc/", StringComparison.Ordinal))),
                "la preservación no debe subir SQLite a Storage ni utilizar otro servicio.");
            Console.WriteLine($"OK Preservación integración real: {comprobaciones} comprobaciones; 35 tablas pobladas + PostgreSQL real + cliente + privacidad + reconstrucción + revisión dos.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static void VerificarPublicacionDeCopiaProtegida(string ruta, IReadOnlyList<Semilla> semillas,
        IReadOnlyDictionary<string, string> originales, string carpeta, Puente red)
    {
        const string cuentaGuardas = "SELECT count(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'myg_preservar_%'";
        string guardasAntes = Sqlite(ruta, cuentaGuardas)!;
        Exige(guardasAntes == "105", "la nueva fuente debe tener las 105 guardas locales de las 35 tablas.");
        string hashAntes = Hash(ruta); int solicitudes = red.Rutas.Count;
        var principal = MYGBaseDatos.ListarProyectos(ruta)[0];
        var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, principal.Id);
        var almacen = new ArchivoPublicacionSqlitePendiente(Path.Combine(carpeta, "republicacion-protegida"), Servidor, Propietario.ToString("D"));
        var pendiente = almacen.Crear("Publicación desde base abierta protegida", "base", documento, ruta);
        Exige(Sqlite(pendiente.RutaSQLite, cuentaGuardas) == "0"
            && Sqlite(pendiente.RutaSQLite, "SELECT count(*) FROM sqlite_master WHERE type='table' AND name='myg_base_preservacion_local'") == "0"
            && Sqlite(pendiente.RutaSQLite, "SELECT count(*) FROM myg_base_central_local") == "0"
            && !BaseCentralNube.EsBase(pendiente.RutaSQLite),
            "la copia nueva debe retirar únicamente sus guardas y controles locales antes de publicar.");
        foreach (var semilla in semillas)
            Exige(LeerFila(pendiente.RutaSQLite, semilla) == originales[semilla.Tabla],
                "republicar una base abierta protegida debe conservar la fila privada de " + semilla.Tabla + ".");
        Exige(Hash(ruta) == hashAntes && Sqlite(ruta, cuentaGuardas) == guardasAntes,
            "preparar otra publicación no debe cambiar la fuente ni retirar sus protecciones.");
        Exige(red.Rutas.Count == solicitudes, "preparar una copia de la base abierta no debe iniciar automáticamente una subida.");
    }

    private static async Task RechazarColisionConResidualPrivado(ClienteSupabase propietario, ClienteSupabase colaborador,
        string original, string cachePropietario, Guid baseId, Guid obraId, Semilla tituloPrivado, string carpeta)
    {
        var anterior = await propietario.ObtenerCatalogoCentralAsync(baseId);
        string firmaCatalogo = anterior.GetRawText();
        string filaPrivada = LeerFila(original, tituloPrivado)!;
        var ultima = await colaborador.AbrirProyectoAsync(obraId);
        string cache = Path.Combine(carpeta, "obra-collision-residual.sqlite");
        PaqueteNube.Descargar(ultima.Contenido, cache);
        var doc = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(cache, ultima.DocumentoId!);
        MYGColaboracionLocal.Vincular(cache, doc, new MYGVinculoNube
        {
            ProyectoId = obraId, Servidor = Servidor, UsuarioId = Colaborador.ToString("D"), Revision = ultima.Revision,
            Rol = ultima.Rol, PermisosModulos = ultima.PermisosModulos!.Copiar(),
            JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(doc), JsonPaqueteConfirmado = ultima.Contenido.GetRawText()
        });
        string id = Convert.ToString(tituloPrivado.Valores[tituloPrivado.Claves[0]], CultureInfo.InvariantCulture)!;
        const string descripcion = "Título nuevo de obra con identidad residual incompatible";
        doc.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        { Id = id, IdLocalMYG = id, TipoPropuesta = "TITULO", Descripcion = descripcion });
        Sqlite(cache, "INSERT INTO titulo(id_titulo,descripcion_titulo) VALUES('" + id.Replace("'", "''") + "','Título de importación nuevo')");
        MYGProyectoStorage.Guardar(cache, doc);
        Exige(Sqlite(cache, "SELECT descripcion_titulo FROM titulo WHERE id_titulo='" + id.Replace("'", "''") + "'") == descripcion,
            "el fixture de colisión debe reutilizar realmente la PK del título residual en una caché sin datos privados.");
        var guardada = await SincronizadorProyectoNube.EjecutarAsync(colaborador, cache, doc);
        Exige(guardada.Vinculo.Revision == ultima.Revision + 1,
            "la colisión debe estar representada por una revisión actual real de la obra para comprobar la reconstrucción.");
        string destino = Path.Combine(carpeta, "no-exponer-base-collision.sqlite");
        bool rechazada = false;
        try { await BaseCentralNube.CrearCopiaAsync(propietario, baseId, destino); }
        catch (InvalidDataException error) when (error.Message.Contains("titulo", StringComparison.OrdinalIgnoreCase)
            || error.Message.Contains("residual", StringComparison.OrdinalIgnoreCase)
            || error.Message.Contains("identidad", StringComparison.OrdinalIgnoreCase)) { rechazada = true; }
        Exige(rechazada && !File.Exists(destino),
            "si una obra reutiliza una PK residual con valores distintos, no debe exponerse una reconstrucción que pierda datos privados.");
        Exige((await propietario.ObtenerCatalogoCentralAsync(baseId)).GetRawText() == firmaCatalogo
            && LeerFila(original, tituloPrivado) == filaPrivada,
            "rechazar la colisión debe conservar el catálogo remoto y la fila privada original.");
        string documentoAntes = MYGColaboracionLocal.ExportarDocumento(MYGBaseDatos.LeerProyecto(cachePropietario, ultima.DocumentoId!));
        bool cacheProtegida = false;
        try
        {
            var local = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(cachePropietario, ultima.DocumentoId!);
            await SincronizadorProyectoNube.EjecutarAsync(propietario, cachePropietario, local, soloLeer: true);
        }
        catch (SqliteException error) when (error.SqliteExtendedErrorCode == 1811) { cacheProtegida = true; }
        catch (InvalidDataException error) when (error.Message.Contains("privad", StringComparison.OrdinalIgnoreCase)
            || error.Message.Contains("proteg", StringComparison.OrdinalIgnoreCase)) { cacheProtegida = true; }
        Exige(cacheProtegida && LeerFila(cachePropietario, tituloPrivado) == filaPrivada,
            "recargar una caché existente debe rechazar la colisión y conservar su título privado.");
        Exige(MYGColaboracionLocal.ExportarDocumento(MYGBaseDatos.LeerProyecto(cachePropietario, ultima.DocumentoId!)) == documentoAntes,
            "el rechazo local debe revertir también el documento de la obra y no dejar una incorporación parcial.");
    }

    private sealed record Semilla(string Tabla, List<string> Claves, Dictionary<string, object?> Valores);
    private sealed record Columna(string Nombre, string Tipo, bool Obligatoria, string? Predeterminado, int Clave);

    private static List<Semilla> SembrarDatosAdicionales(string ruta)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using (var q = c.CreateCommand()) { q.CommandText = "PRAGMA foreign_keys=OFF"; q.ExecuteNonQuery(); }
        var semillas = new List<Semilla>();
        for (int n = 0; n < TablasAdicionales.Length; n++)
        {
            string tabla = TablasAdicionales[n];
            var columnas = Columnas(c, tabla);
            if (columnas.Count == 0) throw new InvalidOperationException("La plantilla Core no contiene " + tabla);
            var datos = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            foreach (var col in columnas.Where(x => x.Clave > 0 || x.Obligatoria && x.Predeterminado is null))
                datos[col.Nombre] = ValorSemilla(col, n);
            if (datos.Count == 0) datos[columnas[0].Nombre] = ValorSemilla(columnas[0], n);
            var texto = columnas.FirstOrDefault(x => x.Clave == 0 &&
                (x.Nombre.Contains("descripcion", StringComparison.OrdinalIgnoreCase) || x.Nombre.StartsWith("nombre", StringComparison.OrdinalIgnoreCase)
                    || x.Nombre.Contains("observacion", StringComparison.OrdinalIgnoreCase) || x.Nombre.Contains("formula", StringComparison.OrdinalIgnoreCase)));
            if (texto is not null) datos[texto.Nombre] = DatosPrivados + ":" + tabla;
            if (tabla == "persona") datos["imagen"] = Encoding.UTF8.GetBytes(DatosPrivados + ":BLOB");
            using var insert = c.CreateCommand();
            insert.CommandText = "INSERT INTO " + IdSqlite(tabla) + "(" + string.Join(',', datos.Keys.Select(IdSqlite)) + ") VALUES(" + string.Join(',', datos.Keys.Select((_, i) => "$p" + i)) + ")";
            int i = 0; foreach (var valor in datos.Values) insert.Parameters.AddWithValue("$p" + i++, valor ?? DBNull.Value);
            insert.ExecuteNonQuery();
            var claves = columnas.Where(x => x.Clave > 0).OrderBy(x => x.Clave).Select(x => x.Nombre).ToList();
            if (claves.Count == 0) claves = datos.Keys.ToList();
            semillas.Add(new(tabla, claves, datos));
        }
        // Población relacional comprobable, incluida una planilla ligada a su
        // persona/hoja y un formato ligado a documento/sucursal.
        Enlazar("persona", "id_tipopersona", "tipo_persona");
        Enlazar("cargo", "id_tipopersona", "tipo_persona");
        Enlazar("planilla", "id_hoja", "hoja_planilla");
        Enlazar("planilla", "id_persona", "persona");
        Enlazar("detalle_planilla", "id_planilla", "planilla");
        Enlazar("sucursal", "id_persona", "persona");
        Enlazar("formato_documento", "id_documento", "documento");
        Enlazar("formato_documento", "id_sucursal", "sucursal");
        Enlazar("titulo_clasificador", "id_plantilla", "plantilla_clasificador");
        Enlazar("costo_partida", "id_partida", "partida");
        Enlazar("modalidad_map", "id_concepto", "concepto");
        Enlazar("modalidad_map", "id_modalidadpago", "modalidad_pago");
        return semillas;

        void Enlazar(string tabla, string columna, string destino)
        {
            var de = semillas.Single(x => x.Tabla == tabla); var a = semillas.Single(x => x.Tabla == destino);
            if (!Columnas(c, tabla).Any(x => x.Nombre.Equals(columna, StringComparison.OrdinalIgnoreCase))) return;
            object? valor = a.Valores[a.Claves[0]];
            using var q = ConsultaFila(c, de, "UPDATE " + IdSqlite(tabla) + " SET " + IdSqlite(columna) + "=$nuevo WHERE ");
            q.Parameters.AddWithValue("$nuevo", valor ?? DBNull.Value); q.ExecuteNonQuery();
            de.Valores[columna] = valor;
        }
    }

    private static object ValorSemilla(Columna col, int n)
    {
        string tipo = col.Tipo.ToUpperInvariant();
        if (tipo.Contains("BLOB")) return Encoding.UTF8.GetBytes(DatosPrivados + ":" + n);
        if (tipo.Contains("INT") || tipo.Contains("NUM") || tipo.Contains("DEC") || tipo.Contains("REAL") || tipo.Contains("DOUBLE")) return 9087000L + n;
        return "QA5DD7-" + n.ToString("D2", CultureInfo.InvariantCulture);
    }

    private static List<Columna> Columnas(SqliteConnection c, string tabla)
    {
        using var q = c.CreateCommand(); q.CommandText = "PRAGMA table_info(" + IdSqlite(tabla) + ")";
        using var r = q.ExecuteReader(); var columnas = new List<Columna>();
        while (r.Read()) columnas.Add(new(r.GetString(1), r.GetString(2), r.GetInt32(3) != 0, r.IsDBNull(4) ? null : r.GetString(4), r.GetInt32(5)));
        return columnas;
    }

    private static string? LeerFila(string ruta, Semilla semilla)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString()); c.Open();
        using var q = ConsultaFila(c, semilla, "SELECT * FROM " + IdSqlite(semilla.Tabla) + " WHERE ");
        using var r = q.ExecuteReader(); if (!r.Read()) return null;
        var fila = new SortedDictionary<string, object?>(StringComparer.Ordinal);
        for (int i = 0; i < r.FieldCount; i++)
        {
            object valor = r.GetValue(i);
            fila[r.GetName(i)] = valor is DBNull ? null : valor is byte[] blob ? new object[] { "blob", Convert.ToBase64String(blob) }
                : new object[] { valor.GetType().Name, Convert.ToString(valor, CultureInfo.InvariantCulture)! };
        }
        return JsonSerializer.Serialize(fila);
    }

    private static byte[] LeerBlob(string ruta, Semilla semilla, string columna)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString()); c.Open();
        using var q = ConsultaFila(c, semilla, "SELECT " + IdSqlite(columna) + " FROM " + IdSqlite(semilla.Tabla) + " WHERE ");
        return (byte[])q.ExecuteScalar()!;
    }

    private static SqliteCommand ConsultaFila(SqliteConnection c, Semilla semilla, string inicio)
    {
        var q = c.CreateCommand();
        q.CommandText = inicio + string.Join(" AND ", semilla.Claves.Select((k, i) => IdSqlite(k) + " IS $p" + i));
        for (int i = 0; i < semilla.Claves.Count; i++) q.Parameters.AddWithValue("$p" + i, semilla.Valores[semilla.Claves[i]] ?? DBNull.Value);
        return q;
    }

    private static bool CatalogoContieneFila(JsonElement catalogo, Semilla semilla)
    {
        foreach (var tabla in catalogo.GetProperty("tablas").EnumerateArray())
        {
            if (tabla.GetProperty("Nombre").GetString() != semilla.Tabla) continue;
            var columnas = tabla.GetProperty("Columnas").EnumerateArray().Select(x => x.GetString()!).ToArray();
            foreach (var fila in tabla.GetProperty("Filas").EnumerateArray())
                if (semilla.Claves.All(k => fila[Array.IndexOf(columnas, k)].GetProperty("Valor").GetString()
                    == Convert.ToString(semilla.Valores[k], CultureInfo.InvariantCulture))) return true;
        }
        return false;
    }

    private static bool CatalogoContieneValor(JsonElement catalogo, string nombre, string valor) => catalogo.GetProperty("tablas")
        .EnumerateArray().Where(t => t.GetProperty("Nombre").GetString() == nombre)
        .Any(t => t.GetProperty("Filas").EnumerateArray().Any(f => f.EnumerateArray().Any(c => c.GetProperty("Valor").ValueKind == JsonValueKind.String && c.GetProperty("Valor").GetString() == valor)));

    private static void ComprobarRelaciones(string ruta, IReadOnlyList<Semilla> semillas)
    {
        string Clave(string tabla) => Convert.ToString(semillas.Single(s => s.Tabla == tabla).Valores[semillas.Single(s => s.Tabla == tabla).Claves[0]], CultureInfo.InvariantCulture)!;
        Exige(Sqlite(ruta, "SELECT count(*) FROM planilla p JOIN persona pe ON pe.id_persona=p.id_persona JOIN hoja_planilla h ON h.id_hoja=p.id_hoja WHERE p.id_planilla=" + Clave("planilla")) == "1",
            "planilla, persona y hoja deben conservar sus relaciones tras reconstruir.");
        Exige(Sqlite(ruta, "SELECT count(*) FROM detalle_planilla d JOIN planilla p ON p.id_planilla=d.id_planilla WHERE d.id_detalleplanilla=" + Clave("detalle_planilla")) == "1",
            "el detalle debe seguir apuntando a su planilla.");
        Exige(Sqlite(ruta, "SELECT count(*) FROM costo_partida c JOIN partida p ON p.id_partida=c.id_partida WHERE c.id_costopartida='" + Clave("costo_partida") + "'") == "1",
            "costo_partida debe conservar la identidad de su partida residual.");
    }

    private static string IdSqlite(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";
}
