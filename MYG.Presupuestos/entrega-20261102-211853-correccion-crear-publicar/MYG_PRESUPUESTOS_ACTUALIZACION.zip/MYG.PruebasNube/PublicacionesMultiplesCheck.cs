using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

internal static class PublicacionesMultiplesCheck
{
    internal static Task RunAsync()
    {
        string temporal = Path.Combine(Path.GetTempPath(), "myg-publicaciones-multiples-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temporal);
        int comprobaciones = 0;
        void Exige(bool condicion, string mensaje)
        { comprobaciones++; if (!condicion) throw new InvalidOperationException(mensaje); }
        try
        {
            const string servidor = "https://publicaciones-qa.supabase.co";
            const string usuario = "11111111-1111-4111-8111-111111111111";
            string carpeta = Path.Combine(temporal, "pendientes");
            var cola = new PublicacionesSqliteEnCola(carpeta, servidor, usuario);
            Exige(cola.Listar().Count == 0 && !Directory.Exists(carpeta), "Consultar una cola nueva no debe crear archivos.");
            _ = cola.Nuevo(); // Un diálogo de crear que se cierra con Cancelar.
            Exige(!Directory.Exists(carpeta), "Preparar la elección de nueva publicación no debe crear ni adoptar un intento.");
            string origen = Path.Combine(temporal, "origen.sqlite");
            var documento = MYGProyectoStorage.Nuevo("Origen intacto", "Presupuesto");
            MYGProyectoStorage.Guardar(origen, documento);
            string hashOrigen = Hash(origen);
            var antiguo = new ArchivoPublicacionSqlitePendiente(carpeta, servidor, usuario);
            var legado = antiguo.Crear("Intento anterior", "base", documento, origen);
            var primero = cola.Nuevo();
            var p1 = primero.Crear("Nueva publicación uno", "base", documento, origen);
            var segundo = cola.Nuevo();
            var p2 = segundo.Crear("Nueva publicación dos", "base", documento, origen);
            Exige(new[] { legado.Id, p1.Id, p2.Id }.Distinct().Count() == 3, "Las publicaciones nuevas deben tener identidades independientes.");
            Exige(new[] { legado.RutaSQLite, p1.RutaSQLite, p2.RutaSQLite }.Distinct().Count() == 3, "Una publicación no debe pisar el archivo congelado de otra.");
            Exige(antiguo.Consultar() == legado && primero.Consultar() == p1 && segundo.Consultar() == p2,
                "Crear otra publicación debe conservar los tres intentos activos.");
            var reiniciada = new PublicacionesSqliteEnCola(carpeta, servidor, usuario);
            var lista = reiniciada.Listar();
            Exige(lista.Count == 3 && lista.Select(x => x.Pendiente.Id).ToHashSet().SetEquals(new[] { legado.Id, p1.Id, p2.Id }),
                "Después de reiniciar deben aparecer el índice antiguo y todas las publicaciones nuevas.");
            Exige(lista.All(x => x.Almacen.Leer(x.Pendiente) == x.Pendiente), "Cada fila debe recuperar su mismo UUID, revisión y archivo para el reintento explícito.");
            Exige(new PublicacionesSqliteEnCola(carpeta, servidor, "22222222-2222-4222-8222-222222222222").Listar().Count == 0,
                "El listado no debe mostrar intentos de otra cuenta.");
            Exige(new PublicacionesSqliteEnCola(carpeta, "https://otra-qa.supabase.co", usuario).Listar().Count == 0,
                "El listado no debe mostrar intentos de otro servidor.");
            string h0 = Hash(legado.RutaSQLite), h1 = Hash(p1.RutaSQLite), h2 = Hash(p2.RutaSQLite);
            _ = reiniciada.Nuevo();
            Exige(reiniciada.Listar().Count == 3 && Hash(legado.RutaSQLite) == h0 && Hash(p1.RutaSQLite) == h1 && Hash(p2.RutaSQLite) == h2,
                "Cancelar una elección nueva debe conservar intentos y bytes de los anteriores.");
            var elegida = lista.Single(x => x.Pendiente.Id == p1.Id);
            elegida.Almacen.Confirmar(elegida.Pendiente);
            Exige(reiniciada.Listar().Select(x => x.Pendiente.Id).ToHashSet().SetEquals(new[] { legado.Id, p2.Id }),
                "Confirmar la selección explícita debe retirar únicamente esa fila.");
            Exige(File.Exists(p1.RutaSQLite) && Hash(p1.RutaSQLite) == h1,
                "Confirmar debe conservar el archivo recuperable local.");
            var retirar = reiniciada.Listar().Single(x => x.Pendiente.Id == legado.Id);
            string retirada = retirar.Almacen.Retirar(retirar.Pendiente);
            Exige(retirada == legado.RutaSQLite && File.Exists(retirada) && Hash(retirada) == h0,
                "Retirar explícitamente el pendiente antiguo debe conservar su copia exacta.");
            Exige(reiniciada.Listar().Count == 1 && reiniciada.Listar()[0].Pendiente == p2,
                "Retirar una fila no debe retirar otra publicación independiente.");
            Exige(Hash(origen) == hashOrigen && Hash(p2.RutaSQLite) == h2, "Ninguna operación de cola debe modificar el origen ni otra preparación.");
            Console.WriteLine($"OK Publicaciones múltiples: {comprobaciones} comprobaciones de creación independiente, cancelación sin IO, reintento explícito, reinicio e identidad; SQLite real y sin red.");
            return Task.CompletedTask;
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(temporal, true); }
    }

    private static string Hash(string ruta) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(ruta)));
}
