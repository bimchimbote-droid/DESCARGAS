using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Negociación aditiva y validación de la preservación privada. HTTP sintético.</summary>
internal static class PreservacionClienteCheck
{
    private static readonly Guid Usuario = Guid.Parse("ee170000-0000-0000-0000-000000000001");
    private static readonly Guid Base = Guid.Parse("ee170000-0000-0000-0000-000000000002");
    private static readonly string[] Adicionales = "cargo clase_gl concepto costo_partida cuenta cuenta_caja cuenta_gl cuenta_gl_temp detalle_planilla diccionario documento documento_identidad estado_civil formato_documento forma_pago hoja_planilla modalidad_map modalidad_pago motivo partida persona planilla plantilla_clasificador plantilla_gasto secuencia secuencia_documento sucursal tipo_afp tipo_asiento tipo_caja tipo_concepto tipo_persona titulo titulo_clasificador titulo_indice".Split(' ');
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "myg-preservacion-cliente-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string ruta = Path.Combine(carpeta, "esquema.sqlite");
            MYGBaseDatos.CrearBaseVacia(ruta);
            using var esquema = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
            esquema.Open();
            var tablas = Adicionales.Select(n => Tabla(esquema, n)).ToArray();
            using (var red = new Transporte())
            using (var cliente = await Conectar(red))
            {
                foreach (var tabla in tablas)
                {
                    var catalogo = Catalogo(tabla);
                    string original = catalogo.GetRawText();
                    await cliente.ComprobarPreservacionBaseAsync(catalogo);
                    await cliente.PrepararCatalogoCentralAsync(Guid.NewGuid(), catalogo);
                    var recuperado = await cliente.ObtenerCatalogoCentralAsync(Base);
                    Exige(recuperado.GetRawText() == original && catalogo.GetRawText() == original,
                        "el transporte debe conservar exactamente la tabla " + tabla.GetProperty("Nombre").GetString());
                }
                Exige(red.Capacidades == 1 && red.Preparados == 35,
                    "la capacidad se negocia una vez y cada tabla se prepara sin publicaciones auxiliares.");
                Exige(red.Rutas.All(r => r.Host == "preservacion-qa.supabase.co"
                    && !r.AbsolutePath.Contains("/storage/", StringComparison.Ordinal) && r.AbsolutePath != "/health"),
                    "la preservación no utiliza un servicio adicional ni Storage.");
            }
            foreach (string modo in new[] { "ausente", "version", "lista-incompleta", "duplicada", "invalida" })
            {
                using var red = new Transporte { ErrorCapacidad = modo };
                using var cliente = await Conectar(red);
                var error = await Rechaza(() => cliente.PrepararCatalogoCentralAsync(Guid.NewGuid(), Catalogo(tablas[0])));
                Exige(red.Preparados == 0 && red.Mutaciones == 0, "capacidad " + modo + " no debe enviar datos ni crear registros.");
                if (modo is "ausente" or "lista-incompleta")
                    Exige(error.Message.Contains("20261107_preservacion_base.sql", StringComparison.Ordinal),
                        "el servidor anterior debe indicar la actualización concreta sin dirección privada.");
            }
            using (var red = new Transporte { ErrorCapacidad = "ausente" })
            using (var cliente = await Conectar(red))
            {
                var anterior = Catalogo(JsonSerializer.SerializeToElement(new
                {
                    Nombre = "catalogo_unidad", Columnas = new[] { "codigo" },
                    Filas = new[] { new[] { new { Tipo = "texto", Valor = "NORMAL_ANTERIOR" } } }
                }));
                await cliente.ComprobarPreservacionBaseAsync(anterior);
                await cliente.PrepararCatalogoCentralAsync(Guid.NewGuid(), anterior);
                Exige(red.Capacidades == 0 && red.Preparados == 1,
                    "una base sin tablas adicionales sigue usando la instalación anterior sin negociar 07.");
            }
            foreach (string modo in new[] { "tabla", "columna", "sin-clave" })
            {
                using var red = new Transporte();
                using var cliente = await Conectar(red);
                JsonElement tabla = modo switch
                {
                    "tabla" => JsonSerializer.SerializeToElement(new { Nombre = "usuario", Columnas = new[] { "id" }, Filas = Array.Empty<object>() }),
                    "columna" => JsonSerializer.SerializeToElement(new { Nombre = "cargo", Columnas = new[] { "id_cargo", "password_privado" }, Filas = Array.Empty<object>() }),
                    _ => JsonSerializer.SerializeToElement(new { Nombre = "cargo", Columnas = new[] { "descripcion_cargo" }, Filas = Array.Empty<object>() })
                };
                await Rechaza(() => cliente.PrepararCatalogoCentralAsync(Guid.NewGuid(), Catalogo(tabla)));
                Exige(red.Capacidades == 0 && red.Preparados == 0,
                    "tabla o esquema desconocido deben rechazarse antes de enviar datos.");
            }
            using (var red = new Transporte { Denegado = true })
            using (var cliente = await Conectar(red))
            {
                var error = await Rechaza(() => cliente.ObtenerCatalogoCentralAsync(Base));
                Exige(error.AccesoDenegado && red.Capacidades == 0,
                    "rechazar lectura privada no debe intentar otra API ni entregar tablas adicionales.");
            }
            Console.WriteLine($"OK Preservación cliente: {comprobaciones} comprobaciones de las 35 tablas reconocidas, capacidad aditiva, compatibilidad y esquema privado; HTTP simulado.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static JsonElement Tabla(SqliteConnection c, string nombre)
    {
        using var q = c.CreateCommand(); q.CommandText = "PRAGMA table_info(\"" + nombre + "\")";
        var columnas = new List<string>(); var fila = new List<object>();
        using var r = q.ExecuteReader();
        while (r.Read())
        {
            columnas.Add(r.GetString(1));
            fila.Add(new { Tipo = r.GetInt32(5) > 0 ? "texto" : "nulo", Valor = r.GetInt32(5) > 0 ? "PRIVADO_" + nombre : null });
        }
        Exige(columnas.Count != 0, "la tabla de la captura debe existir en el esquema confiable: " + nombre);
        return JsonSerializer.SerializeToElement(new { Nombre = nombre, Columnas = columnas, Filas = new[] { fila } });
    }

    private static JsonElement Catalogo(JsonElement tabla) => JsonSerializer.SerializeToElement(new
    { formato = "MYG_CATALOGO_BASE", version = 1, tablas = new[] { tabla }, recursos = Array.Empty<object>() });

    private static async Task<ClienteSupabase> Conectar(Transporte red)
    {
        var cliente = new ClienteSupabase("https://preservacion-qa.supabase.co", "sb_publishable_preservacion_sintetica", red);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        return cliente;
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException e) { comprobaciones++; return e; }
        throw new InvalidOperationException("Preservación cliente: faltó el rechazo esperado.");
    }
    private static void Exige(bool condicion, string detalle)
    { comprobaciones++; if (!condicion) throw new InvalidOperationException("Preservación cliente: " + detalle); }

    private sealed class Transporte : HttpMessageHandler
    {
        internal string ErrorCapacidad = "";
        internal bool Denegado;
        internal int Capacidades, Preparados, Mutaciones;
        internal List<Uri> Rutas { get; } = new();
        private JsonElement catalogo;
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            var uri = request.RequestUri!; Rutas.Add(uri);
            Exige(uri.Host == "preservacion-qa.supabase.co", "el cliente no debe salir de su Supabase.");
            if (uri.AbsolutePath == "/auth/v1/token")
                return Respuesta(new { access_token = "acceso_sintetico_preservacion", refresh_token = "refresco_sintetico_preservacion", expires_in = 3600, user = new { id = Usuario } });
            Exige(request.Headers.Authorization?.Parameter == "acceso_sintetico_preservacion", "cada RPC debe usar su sesión.");
            string funcion = uri.AbsolutePath.Split('/').Last();
            using var cuerpo = JsonDocument.Parse(await request.Content!.ReadAsByteArrayAsync(ct));
            if (funcion == "myg_central_preservacion_capacidades")
            {
                Capacidades++;
                if (ErrorCapacidad == "ausente") return Respuesta(new { code = "PGRST202", message = "función no instalada QA" }, HttpStatusCode.NotFound);
                object lista = ErrorCapacidad switch
                {
                    "lista-incompleta" => Adicionales.Take(34).ToArray(),
                    "duplicada" => Adicionales.Concat(new[] { Adicionales[0] }).ToArray(),
                    "invalida" => new object[] { 1 },
                    _ => Adicionales
                };
                return Respuesta(new { version = ErrorCapacidad == "version" ? 2 : 1, tablas_adicionales = lista });
            }
            if (funcion == "myg_central_capacidades") return Respuesta(new { version = 1 });
            if (funcion == "myg_central_preparar_catalogo")
            {
                Preparados++; Mutaciones++; catalogo = cuerpo.RootElement.GetProperty("p_contenido").Clone();
                return Respuesta(new { estado = "preparado" });
            }
            if (funcion == "myg_central_catalogo")
            {
                if (Denegado) return Respuesta(new { code = "42501", message = "denegado QA" }, HttpStatusCode.Forbidden);
                return Respuesta(catalogo);
            }
            throw new InvalidOperationException("Preservación cliente: RPC no esperada: " + funcion);
        }
        private static HttpResponseMessage Respuesta(object contenido, HttpStatusCode estado = HttpStatusCode.OK) =>
            new(estado) { Content = new StringContent(JsonSerializer.Serialize(contenido), Encoding.UTF8, "application/json") };
    }
}
