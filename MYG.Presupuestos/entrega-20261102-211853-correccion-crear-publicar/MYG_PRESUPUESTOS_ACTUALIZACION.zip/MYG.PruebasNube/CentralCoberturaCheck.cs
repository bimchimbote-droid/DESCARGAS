using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Regresión independiente de catálogos que no pertenecen a ninguna
/// obra y de sus adjuntos/configuración, usando SQLite real y transporte local.</summary>
internal static class CentralCoberturaCheck
{
    private static readonly Guid Usuario = Guid.Parse("5cc148cf-bc76-457e-9070-bf96fd036d22");
    private static readonly Guid Base = Guid.Parse("e746359b-416c-45cc-bfac-3ac4fd6fd1c7");
    private const string Servidor = "https://central-cobertura-qa.supabase.co";
    private const string Privado = "QA-CATALOGO-PRIVADO-NO-USADO-7AB2";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Central-Cobertura-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string origen = Path.Combine(carpeta, "origen.sqlite");
            var norte = MYGProyectoStorage.Nuevo("Norte cobertura", "Presupuesto norte");
            var sur = MYGProyectoStorage.Nuevo("Sur cobertura", "Presupuesto sur");
            var usado = new MYGInsumo
            { Codigo = "QA-USADO-OBRA", Descripcion = "Insumo de la obra en revisión uno", Unidad = "kg", Precio = 12.34m };
            norte.Presupuestos[0].Costos.Insumos.Add(usado);
            string partidaObraId = MYGProyectoStorage.NuevoId();
            norte.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
            {
                Id = partidaObraId, IdLocalMYG = partidaObraId, Descripcion = "Partida con recurso nativo", Unidad = "und",
                Costos = new MYGDatosPartida
                {
                    Cantidad = 1, RendimientoDiario = 1,
                    Analisis = new() { new MYGRecursoACU { InsumoId = usado.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 } }
                }
            });
            MYGProyectoStorage.Guardar(origen, norte); MYGProyectoStorage.Guardar(origen, sur);
            string imagen = Path.Combine(carpeta, "imagen-catalogo.bin");
            byte[] bytesImagen = Encoding.UTF8.GetBytes("imagen sintetica de catalogo no usado");
            File.WriteAllBytes(imagen, bytesImagen);
            var insumo = MYGCatalogos.GuardarInsumo(origen, new MYGInsumo
            {
                Codigo = Privado, Descripcion = "Insumo que no participa en las obras", Unidad = "und",
                Grupo = MYGGrupoRecurso.Materiales, Precio = 123.45m, ImagenRuta = imagen
            });
            var modelo = MYGProyectoStorage.Nuevo("Plantilla temporal", "Plantilla").Presupuestos[0];
            string partidaId = MYGProyectoStorage.NuevoId();
            var partida = new ItemPresupuestoDelphin
            {
                Id = partidaId, IdLocalMYG = partidaId, Descripcion = "Partida reusable no utilizada",
                Unidad = "und", Costos = new MYGDatosPartida { PrecioDirecto = 45.67m, Cantidad = 1 }
            };
            modelo.Items.Add(partida);
            var entrada = MYGCatalogos.GuardarPartida(origen, modelo, partida,
                "QA-PARTIDA-NO-USADA", partida.Descripcion, partida.Unidad);
            var unidad = MYGCatalogoUnidades.Guardar(origen, new MYGUnidadCatalogo
            {
                Simbolo = "QA_COBERTURA", Descripcion = "Unidad sin uso con filtros propios", Tipo = "H",
                EsCostoUnitario = false, EsGastoGeneral = true, TiposCosto = new() { MYGGrupoRecurso.Equipo }
            });
            Sql(origen, "CREATE TABLE IF NOT EXISTS myg_indice_unificado(codigo TEXT PRIMARY KEY COLLATE NOCASE,descripcion TEXT NOT NULL,periodo_base TEXT NOT NULL,resolucion TEXT NOT NULL,orden INTEGER NOT NULL); INSERT INTO myg_indice_unificado VALUES('QA-UNUSED','Índice no usado','2026','QA',901)");

            JsonElement catalogo = BaseCentralNube.CrearCatalogoEstricto(origen);
            Exige(catalogo.GetProperty("formato").GetString() == "MYG_CATALOGO_BASE", "el catálogo tiene un formato propio");
            Exige(!catalogo.TryGetProperty("documento", out _) && !catalogo.TryGetProperty("documentos", out _),
                "el catálogo privado no transporta documentos de las obras");
            Exige(Contiene(catalogo, "catalogo_insumo", insumo.Id), "incluye el insumo sin referencias en presupuestos");
            Exige(Contiene(catalogo, "catalogo_partida", entrada.Id), "incluye la partida reusable sin referencias");
            Exige(Contiene(catalogo, "catalogo_unidad", unidad.Id), "incluye la unidad personalizada sin uso");
            Exige(Contiene(catalogo, "myg_indice_unificado", "QA-UNUSED"), "incluye los índices globales sin uso");
            var recursos = catalogo.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>()!;
            Exige(recursos.Count == 1 && Convert.FromBase64String(recursos[0].Base64).AsSpan().SequenceEqual(bytesImagen),
                "conserva el adjunto del catálogo no utilizado");

            var obras = new[] { norte, sur }.Select((d, i) => new ProyectoNube(
                Guid.Parse(i == 0 ? "2fe052cc-f7e7-44a5-a7b5-727de17a0a91" : "3fe052cc-f7e7-44a5-a7b5-727de17a0a91"),
                "VISTA-QA-" + i, d.Nombre, "propietario", 1, "obra", BaseCentralNube.CrearContenidoEstricto(origen, d.Id))
            { BaseId = Base, DocumentoId = d.Id, EsCentralNativa = true }).ToArray();
            foreach (var obra in obras)
                Exige(!obra.Contenido.GetRawText().Contains(Privado, StringComparison.Ordinal),
                    "el paquete de obra no entrega el catálogo ajeno no utilizado");
            ValidarCobertura(origen, obras.Select(x => x.Contenido).ToArray(), catalogo);
            Exige(true, "las filas de origen están cubiertas por obras, catálogo y valores iniciales de Core");
            using var transporte = new Transporte(obras, catalogo);
            using var cliente = new ClienteSupabase(Servidor, "sb_publishable_cobertura_sintetica", transporte);
            await cliente.IniciarSesionAsync("qa-cobertura@example.test", "clave_sintetica");
            string destino = Path.Combine(carpeta, "descarga.sqlite");
            await BaseCentralNube.CrearCopiaAsync(cliente, Base, destino);
            Exige(MYGBaseDatos.ListarProyectos(destino).Count == 2, "la base reconstruida conserva ambas obras");
            var recibido = MYGCatalogos.Listar(destino, partidas: false).Single(x => x.Id == insumo.Id);
            Exige(recibido.Codigo == Privado && recibido.Precio == 123.45m, "el catálogo mantiene datos y precio exacto del insumo");
            Exige(MYGCatalogos.Listar(destino, partidas: true).Single(x => x.Id == entrada.Id).Precio == entrada.Precio,
                "el catálogo mantiene la partida reusable");
            var unidadRecibida = MYGCatalogoUnidades.Listar(destino).Single(x => x.Id == unidad.Id);
            Exige(unidadRecibida.Simbolo == unidad.Simbolo && unidadRecibida.Descripcion == unidad.Descripcion,
                "la unidad recuperada mantiene su identidad y descripción");
            Exige(unidadRecibida.Tipo == unidad.Tipo && unidadRecibida.EsCostoUnitario == unidad.EsCostoUnitario
                && unidadRecibida.EsGastoGeneral == unidad.EsGastoGeneral && unidadRecibida.TiposCosto.SequenceEqual(unidad.TiposCosto),
                "la unidad mantiene tipo, alcance y filtros por grupo de recurso");
            var insumoRecibido = MYGCatalogos.LeerInsumo(destino, insumo.Id);
            Exige(File.Exists(insumoRecibido.ImagenRuta) && File.ReadAllBytes(insumoRecibido.ImagenRuta).AsSpan().SequenceEqual(bytesImagen),
                "el adjunto existe después de mover la base del temporal a su destino");
            Exige(Contiene(BaseCentralNube.CrearCatalogoEstricto(destino), "myg_indice_unificado", "QA-UNUSED"),
                "el índice global sigue en el catálogo tras reconstruir la base");
            Exige(transporte.Rutas.All(x => x.StartsWith("/auth/", StringComparison.Ordinal) || x.StartsWith("/rest/", StringComparison.Ordinal)),
                "la reconstrucción no necesita un servicio externo ni descargas del archivo completo");
            // El catálogo inicial es inmutable, pero los recursos de un presupuesto
            // evolucionan con su obra. Abrir otra caché debe usar esa revisión nueva.
            usado.Precio = 98.76m; usado.Descripcion = "Insumo de la obra actualizado en revisión dos";
            MYGProyectoStorage.Guardar(origen, norte);
            obras = obras.Select(o => o.DocumentoId == norte.Id ? o with
            { Revision = 2, Contenido = BaseCentralNube.CrearContenidoEstricto(origen, norte.Id) } : o).ToArray();
            using var transporteActualizado = new Transporte(obras, catalogo);
            using var clienteActualizado = new ClienteSupabase(Servidor, "sb_publishable_cobertura_sintetica", transporteActualizado);
            await clienteActualizado.IniciarSesionAsync("qa-cobertura@example.test", "clave_sintetica");
            string destinoActualizado = Path.Combine(carpeta, "descarga-revision-dos.sqlite");
            await BaseCentralNube.CrearCopiaAsync(clienteActualizado, Base, destinoActualizado);
            var norteActualizado = MYGBaseDatos.LeerProyecto(destinoActualizado, norte.Id);
            var recursoActualizado = norteActualizado.Presupuestos[0].Costos.Insumos.Single(i => i.Id == usado.Id);
            Exige(recursoActualizado.Precio == 98.76m && recursoActualizado.Descripcion == usado.Descripcion,
                "una descarga nueva usa precio y descripción de la revisión dos de la obra");
            Exige(MYGCatalogos.Listar(destinoActualizado, false).Any(i => i.Id == insumo.Id),
                "actualizar el recurso de una obra conserva el catálogo privado no utilizado");
            Exige(MYGBaseDatos.LeerProyecto(destinoActualizado, sur.Id).Nombre == sur.Nombre,
                "la descarga con una obra actualizada conserva la otra obra");
            Sql(origen, "INSERT INTO persona(id_persona,nombre_persona) VALUES(987654321,'Persona sintética fuera del modelo colaborativo')");
            bool rechazado = false;
            try { ValidarCobertura(origen, obras.Select(x => x.Contenido).ToArray(), catalogo); }
            catch (InvalidDataException error) when (error.Message.Contains("persona", StringComparison.Ordinal)) { rechazado = true; }
            Exige(rechazado, "una fila conocida sin destino central impide convertir la base y señala su tabla");
            Exige(Valor(origen, "SELECT count(*) FROM persona WHERE id_persona=987654321") == 1,
                "el rechazo conserva las filas no cubiertas en el archivo de origen");
            await PreservarDatosNativosAdicionales(carpeta);
            Console.WriteLine($"OK Cobertura central: {comprobaciones} comprobaciones de catálogos no utilizados, unidades, filtros, índices, adjuntos y privacidad de obra.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static async Task PreservarDatosNativosAdicionales(string carpeta)
    {
        string ruta = Path.Combine(carpeta, "datos-nativos-adicionales.sqlite");
        var norte = MYGProyectoStorage.Nuevo("Obra norte con datos adicionales", "Norte");
        var sur = MYGProyectoStorage.Nuevo("Obra sur privada con datos adicionales", "Sur");
        string tituloId = "OWNED-6A3F";
        norte.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        { Id = tituloId, IdLocalMYG = tituloId, Descripcion = "Título de la obra que después se elimina", TipoPropuesta = "TITULO" });
        MYGBaseDatos.CrearBaseVacia(ruta);
        string presupuestoNativo = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(norte.Presupuestos[0].Id)))[..12];
        Sql(ruta, "INSERT INTO titulo(id_titulo,id_presupuesto) VALUES('" + tituloId + "','" + presupuestoNativo + "')");
        MYGProyectoStorage.Guardar(ruta, norte); MYGProyectoStorage.Guardar(ruta, sur);
        Exige(Valor(ruta, "SELECT count(*) FROM titulo WHERE id_titulo='" + tituloId + "'") == 1,
            "la regresión utiliza un título nativo operativo real, distinto del costo unitario");
        var nombres = new[]
        {
            "cargo", "clase_gl", "concepto", "costo_partida", "cuenta", "cuenta_caja", "cuenta_gl", "cuenta_gl_temp",
            "detalle_planilla", "diccionario", "documento", "documento_identidad", "estado_civil", "formato_documento",
            "forma_pago", "hoja_planilla", "modalidad_map", "modalidad_pago", "motivo", "partida", "persona", "planilla",
            "plantilla_clasificador", "plantilla_gasto", "secuencia", "secuencia_documento", "sucursal", "tipo_afp",
            "tipo_asiento", "tipo_caja", "tipo_concepto", "tipo_persona", "titulo", "titulo_clasificador", "titulo_indice"
        };
        const string marca = "SOLO-PROPIETARIO-ADICIONALES-QA";
        var identidades = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        var claves = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString()))
        {
            c.Open();
            for (int i = 0; i < nombres.Length; i++)
            {
                using var q = c.CreateCommand(); q.CommandText = "PRAGMA table_info(" + Id(nombres[i]) + ")";
                using var r = q.ExecuteReader();
                while (r.Read()) if (r.GetInt32(5) == 1)
                {
                    string tipo = r.GetString(2).ToUpperInvariant();
                    claves[nombres[i]] = r.GetString(1);
                    identidades[nombres[i]] = tipo.Contains("INT") || tipo.Contains("NUMERIC") || tipo.Contains("DECIMAL")
                        ? 890000L + i : "QAX" + i.ToString("D6");
                    if (nombres[i] == "persona") identidades[nombres[i]] = 9007199254740993L;
                }
            }
            using var transaccion = c.BeginTransaction();
            using (var diferir = c.CreateCommand())
            { diferir.Transaction = transaccion; diferir.CommandText = "PRAGMA defer_foreign_keys=ON"; diferir.ExecuteNonQuery(); }
            foreach (string nombre in nombres)
            {
                var valores = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                using (var q = c.CreateCommand())
                {
                    q.Transaction = transaccion;
                    q.CommandText = "PRAGMA table_info(" + Id(nombre) + ")";
                    using var r = q.ExecuteReader();
                    bool marcada = false;
                    while (r.Read())
                    {
                        string columna = r.GetString(1), tipo = r.GetString(2).ToUpperInvariant();
                        if (columna == claves[nombre]) valores[columna] = identidades[nombre];
                        else if (tipo.Contains("BLOB")) valores[columna] = new byte[] { 0, 1, 2, 250, 255 };
                        else if (r.GetInt32(3) != 0)
                            valores[columna] = tipo.Contains("INT") || tipo.Contains("NUMERIC") || tipo.Contains("DECIMAL") ? 234L : "Dato QA";
                        else if (!marcada && (columna.Contains("descripcion", StringComparison.OrdinalIgnoreCase)
                            || columna.Contains("nombre", StringComparison.OrdinalIgnoreCase)))
                        { valores[columna] = marca + " " + nombre; marcada = true; }
                    }
                }
                using (var q = c.CreateCommand())
                {
                    q.Transaction = transaccion;
                    q.CommandText = "PRAGMA foreign_key_list(" + Id(nombre) + ")";
                    using var r = q.ExecuteReader();
                    while (r.Read()) if (identidades.TryGetValue(r.GetString(2), out var identidad)) valores[r.GetString(3)] = identidad;
                }
                using var insertar = c.CreateCommand();
                insertar.Transaction = transaccion;
                insertar.CommandText = "INSERT INTO " + Id(nombre) + "(" + string.Join(",", valores.Keys.Select(Id)) + ") VALUES("
                    + string.Join(",", Enumerable.Range(0, valores.Count).Select(i => "$p" + i)) + ")";
                int n = 0; foreach (var valor in valores.Values) insertar.Parameters.AddWithValue("$p" + n++, valor);
                insertar.ExecuteNonQuery();
            }
            transaccion.Commit();
        }
        string original = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(ruta)));
        var obras = new[] { norte, sur }.Select((d, i) => new ProyectoNube(
            Guid.Parse(i == 0 ? "7fe052cc-f7e7-44a5-a7b5-727de17a0a91" : "8fe052cc-f7e7-44a5-a7b5-727de17a0a91"),
            "VISTA-ADICIONAL-" + i, d.Nombre, "propietario", 1, "obra", BaseCentralNube.CrearContenidoEstricto(ruta, d.Id))
        { BaseId = Base, DocumentoId = d.Id, EsCentralNativa = true }).ToArray();
        var catalogo = BaseCentralNube.CrearCatalogoEstricto(ruta);
        var tablas = catalogo.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>()!;
        foreach (string nombre in nombres)
            Exige(Contiene(catalogo, nombre, identidades[nombre].ToString()!), "el propietario conserva las filas adicionales de " + nombre);
        Exige(obras.All(o => !o.Contenido.GetRawText().Contains(marca, StringComparison.Ordinal)),
            "ninguna obra comparte datos administrativos adicionales del propietario");
        Exige(!Contiene(catalogo, "titulo", tituloId), "una fila nativa ya representada en una obra no se congela en el catálogo privado");
        ValidarCobertura(ruta, obras.Select(x => x.Contenido).ToArray(), catalogo);
        using var transporte = new Transporte(obras, catalogo);
        using var cliente = new ClienteSupabase(Servidor, "sb_publishable_adicionales_sintetica", transporte);
        await cliente.IniciarSesionAsync("qa-adicionales@example.test", "clave_sintetica");
        string destino = Path.Combine(carpeta, "adicionales-descargados.sqlite");
        await BaseCentralNube.CrearCopiaAsync(cliente, Base, destino);
        Exige(Valor(destino, "SELECT count(*) FROM titulo WHERE id_titulo='" + tituloId + "'") == 1,
            "la reconstrucción prepara el título nativo antes de guardar el documento en Core");
        foreach (string nombre in nombres)
        {
            using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = destino, Pooling = false }.ToString()); c.Open();
            using var q = c.CreateCommand(); q.CommandText = "SELECT count(*) FROM " + Id(nombre) + " WHERE " + Id(claves[nombre]) + "=$id";
            q.Parameters.AddWithValue("$id", identidades[nombre]);
            Exige(Convert.ToInt64(q.ExecuteScalar()) == 1, "la descarga recupera una sola fila adicional de " + nombre);
        }
        using (var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = destino, Pooling = false }.ToString()))
        {
            c.Open(); using var q = c.CreateCommand(); q.CommandText = "SELECT imagen FROM persona WHERE id_persona=$id";
            q.Parameters.AddWithValue("$id", identidades["persona"]);
            Exige(((byte[])q.ExecuteScalar()!).AsSpan().SequenceEqual(new byte[] { 0, 1, 2, 250, 255 }), "conserva íntegramente los BLOB administrativos");
        }
        ProbarGuardasLocales(destino, norte.Id, identidades);
        norte.Presupuestos[0].Items.Clear();
        string actual = Path.Combine(carpeta, "datos-nativos-revision-dos.sqlite");
        MYGProyectoStorage.Guardar(actual, norte); MYGProyectoStorage.Guardar(actual, sur);
        obras[0] = obras[0] with { Revision = 2, Contenido = BaseCentralNube.CrearContenidoEstricto(actual, norte.Id) };
        string actualizado = Path.Combine(carpeta, "adicionales-revision-dos.sqlite");
        await BaseCentralNube.CrearCopiaAsync(cliente, Base, actualizado);
        Exige(Valor(actualizado, "SELECT count(*) FROM titulo WHERE id_titulo='" + tituloId + "'") == 0,
            "la reconstrucción no resucita un título eliminado de la revisión actual de la obra");
        var paquete = System.Text.Json.Nodes.JsonNode.Parse(FormatoPaqueteNube.Expandir(obras[0].Contenido).GetRawText())!.AsObject();
        var tablaResidual = tablas.Single(t => t.Nombre == "titulo");
        var filaResidual = tablaResidual.Filas.Single(f => f[tablaResidual.Columnas.IndexOf("id_titulo")].Valor == identidades["titulo"].ToString());
        var filaForjada = filaResidual.Select(c => new PaqueteNube.Celda { Tipo = c.Tipo, Valor = c.Valor }).ToList();
        filaForjada[tablaResidual.Columnas.IndexOf("descripcion_titulo")].Valor = "Una obra intenta ocultar el dato privado original";
        var tablaForjada = new PaqueteNube.Tabla { Nombre = "titulo", Columnas = tablaResidual.Columnas, Filas = [filaForjada] };
        var nuevasTablas = paquete["tablas"]!.AsArray();
        for (int i = nuevasTablas.Count - 1; i >= 0; i--)
            if (nuevasTablas[i]?["Nombre"]?.GetValue<string>() == "titulo") nuevasTablas.RemoveAt(i);
        nuevasTablas.Add(System.Text.Json.JsonSerializer.SerializeToNode(tablaForjada));
        obras[0] = obras[0] with { Revision = 3, Contenido = System.Text.Json.JsonSerializer.SerializeToElement(paquete) };
        string colision = Path.Combine(carpeta, "adicionales-colision-rechazada.sqlite");
        bool rechazado = false;
        try { await BaseCentralNube.CrearCopiaAsync(cliente, Base, colision); }
        catch (InvalidDataException error) when (error.Message.Contains("datos privados originales", StringComparison.Ordinal)) { rechazado = true; }
        Exige(rechazado && !File.Exists(colision), "una obra no puede ocultar una fila residual privada con la misma identidad y valores distintos");
        string duplicadas = Path.Combine(carpeta, "identidades-privadas-duplicadas.sqlite");
        File.Copy(ruta, duplicadas);
        Sql(duplicadas, "INSERT INTO documento_identidad(id_documento) VALUES(NULL),(NULL)");
        string hashDuplicadas = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(duplicadas)));
        int solicitudes = transporte.Rutas.Count;
        rechazado = false;
        try { await BaseCentralNube.PublicarAsync(cliente, duplicadas, "Fuente con claves privadas ambiguas"); }
        catch (InvalidDataException error) when (error.Message.Contains("identidad única", StringComparison.Ordinal)) { rechazado = true; }
        Exige(rechazado && transporte.Rutas.Count == solicitudes,
            "una clave privada duplicada, incluso NULL permitido por SQLite, se rechaza antes de cualquier RPC");
        Exige(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(duplicadas))) == hashDuplicadas,
            "rechazar la identidad privada ambigua conserva íntegra la fuente");
        Exige(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(ruta))) == original,
            "preparar y descargar los datos adicionales mantiene intacta la base original");
    }

    private static string Id(string nombre) => "\"" + nombre.Replace("\"", "\"\"") + "\"";

    private static void ProbarGuardasLocales(string ruta, string documentoId, IReadOnlyDictionary<string, object> ids)
    {
        long persona = (long)ids["persona"];
        string titulo = (string)ids["titulo"];
        string firma = MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, documentoId));
        string bytesIniciales = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(ruta)));
        var forjado = MYGBaseDatos.LeerProyecto(ruta, documentoId);
        string id = MYGProyectoStorage.NuevoId();
        forjado.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        { Id = id, IdLocalMYG = id, IdInternoDelphin = titulo, Descripcion = "No debe sobrescribir el título privado", TipoPropuesta = "TITULO" });
        bool coreRechaza = false;
        try { MYGProyectoStorage.Guardar(ruta, forjado); }
        catch (SqliteException error) when (error.SqliteExtendedErrorCode == 1811) { coreRechaza = true; }
        Exige(coreRechaza && MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(ruta, documentoId)) == firma,
            "Core revierte toda la edición que intenta utilizar la identidad nativa de una fila privada");
        Exige(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(ruta))) == bytesIniciales,
            "el guardado rechazado conserva los bytes completos de la copia propietaria existente");
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false, ForeignKeys = true }.ToString()); c.Open();
        void Ejecutar(string sql)
        { using var q = c.CreateCommand(); q.CommandText = sql; q.ExecuteNonQuery(); }
        bool Rechaza(string sql)
        {
            try { Ejecutar(sql); return false; }
            catch (SqliteException error) when (error.SqliteExtendedErrorCode == 1811) { return true; }
        }
        Ejecutar("PRAGMA recursive_triggers=OFF; CREATE TABLE qa_hijo_preservado(id INTEGER PRIMARY KEY,persona INTEGER REFERENCES persona(id_persona) ON DELETE CASCADE); INSERT INTO qa_hijo_preservado VALUES(1," + persona + ")");
        Exige(Rechaza("UPDATE persona SET nombre_persona='Sobrescritura' WHERE id_persona=" + persona), "UPDATE no cambia datos privados protegidos");
        Exige(Rechaza("DELETE FROM persona WHERE id_persona=" + persona), "DELETE no elimina la fila protegida ni sus dependencias");
        Exige(Rechaza("INSERT OR REPLACE INTO persona(id_persona,nombre_persona) VALUES(" + persona + ",'Sobrescritura')"),
            "INSERT OR REPLACE no evita la guarda con recursive_triggers deshabilitado");
        Ejecutar("INSERT OR REPLACE INTO persona SELECT * FROM persona WHERE id_persona=" + persona);
        using (var q = c.CreateCommand())
        { q.CommandText = "SELECT count(*) FROM qa_hijo_preservado"; Exige(Convert.ToInt64(q.ExecuteScalar()) == 1, "REPLACE idéntico conserva el padre físico y no dispara ON DELETE CASCADE"); }
        Ejecutar("UPDATE persona SET nombre_persona=nombre_persona WHERE id_persona=" + persona);
        Exige(Rechaza("UPDATE persona SET id_persona=345678 WHERE id_persona=" + persona), "una clave protegida no puede trasladarse para desactivar la preservación");
        Ejecutar("INSERT INTO persona(id_persona,nombre_persona) VALUES(456789,'Temporal QA')");
        Exige(Rechaza("UPDATE OR REPLACE persona SET id_persona=" + persona + " WHERE id_persona=456789"),
            "UPDATE OR REPLACE tampoco puede sustituir un destino protegido");
        Ejecutar("DELETE FROM persona WHERE id_persona=456789; DROP TABLE qa_hijo_preservado");
        string clave;
        using (var q = c.CreateCommand())
        { q.CommandText = "SELECT json_array(id_persona) FROM persona WHERE id_persona=" + persona; clave = (string)q.ExecuteScalar()!; }
        string tablaAnterior = "persona", claveAnterior = clave;
        void Clave(string tabla, string identidad)
        {
            using var q = c.CreateCommand(); q.CommandText = "UPDATE myg_base_preservacion_local SET tabla=$tabla,clave_json=$clave WHERE tabla=$anterior AND clave_json=$claveAnterior";
            q.Parameters.AddWithValue("$tabla", tabla); q.Parameters.AddWithValue("$clave", identidad);
            q.Parameters.AddWithValue("$anterior", tablaAnterior); q.Parameters.AddWithValue("$claveAnterior", claveAnterior);
            q.ExecuteNonQuery(); tablaAnterior = tabla; claveAnterior = identidad;
        }
        Clave("PERSONA", clave);
        bool invalida = false;
        try { BaseCentralNube.CrearContenidoEstricto(ruta, documentoId); }
        catch (InvalidDataException) { invalida = true; }
        Exige(invalida, "una identidad de tabla no canónica impide confiar en una guarda alterada");
        Clave("persona", "[{}]"); invalida = false;
        try { BaseCentralNube.CrearContenidoEstricto(ruta, documentoId); }
        catch (InvalidDataException) { invalida = true; }
        Exige(invalida, "una clave JSON no escalar en la preservación se rechaza");
        Clave("persona", "[ " + persona + " ]"); invalida = false;
        try { BaseCentralNube.CrearContenidoEstricto(ruta, documentoId); }
        catch (InvalidDataException) { invalida = true; }
        Exige(invalida, "una clave de preservación que no coincide con json_array de la fila real se rechaza");
        Clave("persona", clave);
        Exige(!BaseCentralNube.CrearContenidoEstricto(ruta, documentoId).GetProperty("tablas").EnumerateArray()
            .Any(t => t.GetProperty("Nombre").GetString() == "myg_base_preservacion_local"), "el paquete compartido nunca incluye las identidades de preservación privada");
        string snapshot = Path.Combine(Path.GetDirectoryName(ruta)!, "snapshot-sin-guardas.sqlite");
        CopiaSqliteNube.CrearSnapshot(ruta, snapshot);
        Exige(Valor(snapshot, "SELECT count(*) FROM sqlite_master WHERE name='myg_base_preservacion_local' OR type='trigger' AND name LIKE 'myg_preservar_%'") == 0,
            "la instantánea exportada retira las guardas y su control privado");
        Exige(Valor(ruta, "SELECT count(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'myg_preservar_%'") == 105,
            "exportar una instantánea conserva todas las guardas del original");
    }

    private static void ValidarCobertura(string ruta, IReadOnlyList<JsonElement> obras, JsonElement catalogo)
    {
        var tipo = typeof(BaseCentralNube).Assembly.GetType("MYG.Colaboracion.CoberturaCentralNube", throwOnError: true)!;
        var metodo = tipo.GetMethod("Validar", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)!;
        try { metodo.Invoke(null, new object[] { ruta, obras, catalogo }); }
        catch (System.Reflection.TargetInvocationException error) when (error.InnerException is not null)
        { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); }
    }

    private static bool Contiene(JsonElement catalogo, string nombre, string valor)
    {
        var tablas = catalogo.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>()!;
        return tablas.Any(t => t.Nombre == nombre && t.Filas.Any(f => f.Any(c => c.Valor == valor)));
    }

    private sealed class Transporte(ProyectoNube[] obras, JsonElement catalogo) : HttpMessageHandler
    {
        internal List<string> Rutas { get; } = new();
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath; Rutas.Add(ruta);
            if (ruta == "/auth/v1/token") return Respuesta(new
            { access_token = "acceso_qa_cobertura", refresh_token = "refresco_qa_cobertura", expires_in = 3600, user = new { id = Usuario } });
            if (ruta == "/rest/v1/rpc/myg_central_resolver") return Respuesta(new
            {
                id = Base, codigo = "MYG-BASE-COBERTURA", nombre = "Base cobertura", rol = "propietario",
                revision = 1, alcance = "base", central_nativa = true,
                permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            });
            if (ruta == "/rest/v1/rpc/myg_central_obras") return Respuesta(obras.Select(x => Descriptor(x, false)));
            if (ruta == "/rest/v1/rpc/myg_central_catalogo") return Respuesta(catalogo);
            if (ruta == "/rest/v1/rpc/myg_central_abrir")
            {
                using var cuerpo = JsonDocument.Parse(await solicitud.Content!.ReadAsStringAsync(ct));
                Guid id = cuerpo.RootElement.GetProperty("p_id").GetGuid();
                return Respuesta(Descriptor(obras.Single(x => x.Id == id), true));
            }
            throw new InvalidOperationException("Ruta no prevista en cobertura: " + ruta);
        }
        private static object Descriptor(ProyectoNube obra, bool contenido)
        {
            var salida = new Dictionary<string, object?>
            {
                ["id"] = obra.Id, ["codigo"] = obra.Codigo, ["nombre"] = obra.Nombre, ["rol"] = obra.Rol,
                ["revision"] = obra.Revision, ["alcance"] = obra.Alcance, ["base_id"] = obra.BaseId,
                ["documento_id"] = obra.DocumentoId, ["vista_base"] = true, ["central_nativa"] = true,
                ["permisos_modulos"] = new { acu = true, especificaciones = true, metrados_excel = true, metrados_revit = true }
            };
            if (contenido) salida["contenido"] = obra.Contenido;
            return salida;
        }
        private static HttpResponseMessage Respuesta(object datos) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(datos), Encoding.UTF8, "application/json") };
    }

    private static void Sql(string ruta, string sql)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = sql; q.ExecuteNonQuery();
    }
    private static long Valor(string ruta, string sql)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = sql; return Convert.ToInt64(q.ExecuteScalar());
    }
    private static void Exige(bool cumple, string mensaje)
    { comprobaciones++; if (!cumple) throw new InvalidOperationException("Cobertura central: " + mensaje); }
}
