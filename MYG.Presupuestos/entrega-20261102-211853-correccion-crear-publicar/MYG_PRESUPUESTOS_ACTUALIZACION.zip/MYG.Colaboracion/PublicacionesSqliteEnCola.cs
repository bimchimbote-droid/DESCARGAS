namespace MYG.Colaboracion;

/// <summary>Intento explícitamente elegido. El almacén conserva su identidad de
/// cuenta y servidor y verifica el cuerpo congelado antes de reenviarlo.</summary>
public sealed record PublicacionSqliteEnCola(ArchivoPublicacionSqlitePendiente Almacen,
    PublicacionSqlitePendiente Pendiente);

/// <summary>Varios intentos locales independientes, incluyendo el índice único
/// de versiones anteriores. Consultar o cancelar un diálogo no crea archivos.</summary>
public sealed class PublicacionesSqliteEnCola
{
    private readonly string carpeta, servidor, usuario;

    public PublicacionesSqliteEnCola(string carpeta, string servidor, string usuario)
    {
        // Validar la identidad sin tocar disco, igual que el almacén existente.
        _ = new ArchivoPublicacionSqlitePendiente(carpeta, servidor, usuario);
        this.carpeta = Path.GetFullPath(carpeta);
        this.servidor = servidor;
        this.usuario = usuario;
    }

    public ArchivoPublicacionSqlitePendiente Nuevo() => new(
        Path.Combine(carpeta, "intentos", Guid.NewGuid().ToString("N")), servidor, usuario);

    public IReadOnlyList<PublicacionSqliteEnCola> Listar()
    {
        var resultado = new List<PublicacionSqliteEnCola>();
        void Incorporar(string ruta)
        {
            var almacen = new ArchivoPublicacionSqlitePendiente(ruta, servidor, usuario);
            var pendiente = almacen.Consultar();
            if (pendiente is not null) resultado.Add(new(almacen, pendiente));
        }
        Incorporar(carpeta); // Índice anterior, sin mover sus archivos ni su UUID.
        string independientes = Path.Combine(carpeta, "intentos");
        if (Directory.Exists(independientes))
            foreach (string ruta in Directory.EnumerateDirectories(independientes))
            {
                // Sólo carpetas creadas por este protocolo, nunca recorrer otras
                // carpetas de la máquina ni aceptar rutas desde metadatos remotos.
                if (Guid.TryParseExact(Path.GetFileName(ruta), "N", out _)
                    && (File.GetAttributes(ruta) & FileAttributes.ReparsePoint) == 0)
                    Incorporar(ruta);
            }
        return resultado.OrderByDescending(x => x.Pendiente.FechaUtc).ToArray();
    }
}
