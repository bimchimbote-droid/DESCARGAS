using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

public static partial class BaseCentralNube
{
    // Columnas del DDL confiable de Core. Un paquete nunca aporta DDL ni puede
    // escoger otro nombre de tabla para preparar la representación del título.
    private static readonly HashSet<string> ColumnasTituloNativo = new(StringComparer.OrdinalIgnoreCase)
    {
        "id_titulo", "descripcion_titulo", "id_titulopadre", "posicion_titulo", "nivel_titulo", "id_presupuesto",
        "estado_expandido", "numeracion_titulo", "costo_titulo", "id_responsable", "numeracion_norma", "color_fuente",
        "nombre_fuente", "estilo_fuente", "tamano_fuente", "duracion", "fecha_inicio", "fecha_fin", "es_hito",
        "porcentaje_completado", "color_fondo", "duracion_new"
    };

    /// <summary>Conserva la representación de títulos importados de Delphin.
    /// Debe ejecutarse en la misma transacción antes de guardar el documento:
    /// Core decide entre titulo y costo_unitario según la fila nativa existente.</summary>
    public static void PrepararTitulosNativos(JsonElement contenido, SqliteConnection conexion, SqliteTransaction transaccion)
    {
        ArgumentNullException.ThrowIfNull(conexion);
        ArgumentNullException.ThrowIfNull(transaccion);
        if (!ReferenceEquals(transaccion.Connection, conexion))
            throw new ArgumentException("La preparación del título necesita la transacción de la misma copia.");
        contenido = FormatoPaqueteNube.Expandir(contenido);
        if (!contenido.TryGetProperty("tablas", out var tablasJson)) return;
        var tablas = tablasJson.Deserialize<List<PaqueteNube.Tabla>>(new JsonSerializerOptions { MaxDepth = 128 })
            ?? throw new InvalidDataException("Las tablas de la obra no tienen un formato válido.");
        var candidatas = tablas.Where(x => string.Equals(x.Nombre, "titulo", StringComparison.OrdinalIgnoreCase)).ToList();
        if (candidatas.Count == 0) return;
        if (candidatas.Count != 1) throw new InvalidDataException("El paquete repite la tabla de títulos.");
        var tabla = candidatas[0];
        // Los paquetes anteriores sin filas nativas de títulos no necesitan
        // esta preparación; mantienen su validación y guardado habituales.
        if (tabla.Filas.Count == 0) return;
        var documento = PaqueteNube.LeerDocumento(contenido);
        if (!contenido.TryGetProperty("alcance", out var alcance) || alcance.GetString() != "obra")
            throw new InvalidDataException("La preparación nativa necesita el paquete de una sola obra.");
        if (tabla.Columnas.Count == 0 || tabla.Columnas.Distinct(StringComparer.OrdinalIgnoreCase).Count() != tabla.Columnas.Count
            || tabla.Columnas.Any(c => !ColumnasTituloNativo.Contains(c))
            || tabla.Filas.Any(f => f.Count != tabla.Columnas.Count))
            throw new InvalidDataException("El esquema de títulos no corresponde al formato conocido de MYG.");
        int idColumna = tabla.Columnas.FindIndex(c => c.Equals("id_titulo", StringComparison.OrdinalIgnoreCase));
        int presupuestoColumna = tabla.Columnas.FindIndex(c => c.Equals("id_presupuesto", StringComparison.OrdinalIgnoreCase));
        int padreColumna = tabla.Columnas.FindIndex(c => c.Equals("id_titulopadre", StringComparison.OrdinalIgnoreCase));
        if (idColumna < 0 || presupuestoColumna < 0)
            throw new InvalidDataException("Un título nativo necesita su identidad y su presupuesto.");

        var permitidos = new Dictionary<string, (string Presupuesto, string? Padre)>(StringComparer.Ordinal);
        foreach (var presupuesto in documento.Presupuestos)
        {
            var nativos = presupuesto.Items.ToDictionary(i => i.Id,
                i => IdentidadTituloDelphin(string.IsNullOrWhiteSpace(i.IdInternoDelphin) ? i.Id : i.IdInternoDelphin),
                StringComparer.OrdinalIgnoreCase);
            foreach (var item in presupuesto.Items.Where(MYGProyectoStorage.EsTitulo))
            {
                string? padre = item.ParentId is not null && nativos.TryGetValue(item.ParentId, out string? nativoPadre)
                    ? nativoPadre : null;
                if (!permitidos.TryAdd(nativos[item.Id], (IdentidadTituloDelphin(presupuesto.Id), padre)))
                    throw new InvalidDataException("Dos títulos de esta obra utilizan la misma identidad nativa.");
            }
        }

        var filasVistas = new HashSet<string>(StringComparer.Ordinal);
        foreach (var fila in tabla.Filas)
        {
            string? id = TextoCeldaTitulo(fila[idColumna]);
            string? presupuesto = TextoCeldaTitulo(fila[presupuestoColumna]);
            if (id is null || !filasVistas.Add(id) || !permitidos.TryGetValue(id, out var esperado)
                || presupuesto != esperado.Presupuesto
                || padreColumna >= 0 && TextoCeldaTitulo(fila[padreColumna]) != esperado.Padre)
                throw new InvalidDataException("El título nativo no pertenece al documento y presupuesto autorizados.");
            using (var propietario = conexion.CreateCommand())
            {
                propietario.Transaction = transaccion;
                propietario.CommandText = "SELECT propietario FROM myg_delphin_fila WHERE tabla='titulo' AND id_nativo=$id";
                propietario.Parameters.AddWithValue("$id", id);
                string? registro = propietario.ExecuteScalar() as string;
                if (registro is not null && registro != "proyecto:" + documento.Id)
                    throw new InvalidDataException("El título ya está vinculado a otra obra o catálogo de esta copia.");
            }
            bool existente;
            using (var consultar = conexion.CreateCommand())
            {
                consultar.Transaction = transaccion;
                consultar.CommandText = "SELECT id_presupuesto FROM titulo WHERE id_titulo=$id";
                consultar.Parameters.AddWithValue("$id", id);
                using var lector = consultar.ExecuteReader();
                existente = lector.Read();
                if (existente && !lector.IsDBNull(0) && lector.GetString(0) != presupuesto)
                    throw new InvalidDataException("El título ya pertenece a otro presupuesto de esta copia.");
            }
            // Nunca UPSERT: cambiar primero el presupuesto eludiría las guardas
            // de propiedad de Core y podría sustituir datos privados existentes.
            if (existente) continue;
            using var insertar = conexion.CreateCommand();
            insertar.Transaction = transaccion;
            insertar.CommandText = "INSERT INTO titulo(" + string.Join(',', tabla.Columnas.Select(IdentificadorTitulo))
                + ") VALUES(" + string.Join(',', tabla.Columnas.Select((_, i) => "$v" + i)) + ")";
            for (int i = 0; i < fila.Count; i++) insertar.Parameters.AddWithValue("$v" + i, ValorCeldaTitulo(fila[i]));
            insertar.ExecuteNonQuery();
        }
    }

    // Es la regla de MYGDelphinFormato.IdNativo: conservar identidades Delphin
    // de hasta 12 caracteres y derivar las identidades MYG mediante SHA-256.
    private static string IdentidadTituloDelphin(string id) =>
        !string.IsNullOrWhiteSpace(id) && id.Length <= 12 && !id.StartsWith("MYG-", StringComparison.OrdinalIgnoreCase)
            ? id : Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(id ?? "")))[..12];

    private static string IdentificadorTitulo(string nombre) => '"' + nombre.Replace("\"", "\"\"") + '"';
    private static string? TextoCeldaTitulo(PaqueteNube.Celda celda) => celda.Tipo == "nulo"
        || string.IsNullOrWhiteSpace(celda.Valor) ? null : celda.Valor;
    private static object ValorCeldaTitulo(PaqueteNube.Celda celda) => celda.Tipo switch
    {
        "nulo" => DBNull.Value,
        "texto" => celda.Valor ?? "",
        "entero" => long.Parse(celda.Valor!, CultureInfo.InvariantCulture),
        "real" => double.TryParse(celda.Valor, NumberStyles.Float, CultureInfo.InvariantCulture, out double n) && double.IsFinite(n)
            ? n : throw new InvalidDataException("El título contiene un número SQLite no válido."),
        "blob" => Convert.FromBase64String(celda.Valor!),
        _ => throw new InvalidDataException("El título contiene un tipo de celda desconocido.")
    };
}
