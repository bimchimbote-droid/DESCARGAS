using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using MYG_2027;

namespace MYG.Colaboracion;

public sealed record VinculoBaseCentral(Guid BaseId, string Servidor, string Usuario);

/// <summary>SQLite local de una base central. La nube conserva una sola obra y
/// su ACL; este vínculo no publica otro archivo ni contiene credenciales.</summary>
public static partial class BaseCentralNube
{
    private const string Tabla = "myg_base_central_local";
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> Exclusiones = new(StringComparer.OrdinalIgnoreCase);
    private static readonly JsonSerializerOptions Json = new() { MaxDepth = 128 };
    private static readonly HashSet<string> Privadas = new(StringComparer.OrdinalIgnoreCase)
    {
        "usuario", "usuario_map", "perfil", "perfil_map", "roles_sucursal", "SESION_CAJA", "parametro",
        "log_objs_changes", "messages_app", "myg_info", "myg_delphin_fila", "myg_colaboracion_local", "myg_nube_sqlite_local", Tabla,
        "myg_base_preservacion_local"
    };
    private static readonly HashSet<string> Compartidas = new(StringComparer.OrdinalIgnoreCase)
    {
        "catalogo_unidad", "catalogo_insumo", "catalogo_partida", "catalogo_partida_nodo", "catalogo_partida_insumo", "catalogo_partida_recurso",
        "myg_indice_unificado", "unidad", "tipo_costo", "categoria", "producto", "lista_precio", "infraestructura", "propietario",
        "portafolio", "departamento", "provincia", "distrito", "localidad", "pais_info", "moneda", "clase", "subclase", "marca",
        "indice", "indice_precio", "region_precio", "responsable", "calendario",
        "unidad_map", "unidad_tipocosto", "unidad_tipocostonew", "horario", "horario_ex", "feriado", "excepcion",
        "plantilla_partida", "titulo_plantilla", "costo_unitarioplantilla", "precio_producto", "subclase_costo"
    };
    // Datos nativos de Delphin que no necesariamente participan en un presupuesto.
    // Su conservación es exclusiva del propietario. Las filas ya representadas
    // por las obras no se congelan aquí para no resucitarlas tras una eliminación.
    private static readonly HashSet<string> AdicionalesPropietario = new(StringComparer.OrdinalIgnoreCase)
    {
        "cargo", "clase_gl", "concepto", "costo_partida", "cuenta", "cuenta_caja", "cuenta_gl", "cuenta_gl_temp",
        "detalle_planilla", "diccionario", "documento", "documento_identidad", "estado_civil", "formato_documento",
        "forma_pago", "hoja_planilla", "modalidad_map", "modalidad_pago", "motivo", "partida", "persona", "planilla",
        "plantilla_clasificador", "plantilla_gasto", "secuencia", "secuencia_documento", "sucursal", "tipo_afp",
        "tipo_asiento", "tipo_caja", "tipo_concepto", "tipo_persona", "titulo", "titulo_clasificador", "titulo_indice"
    };
    static BaseCentralNube() => Compartidas.UnionWith(AdicionalesPropietario);
    private sealed record ArchivoPreparado(string Archivo, string Sha256);
    private sealed record DocumentoPreparado(string DocumentoId, string Nombre, string Archivo, string Sha256);
    private sealed record Intento(Guid Migracion, Guid BaseId, string Servidor, string Usuario, long Revision,
        string HashOrigen, List<DocumentoPreparado> Documentos, ArchivoPreparado Catalogo);
    private sealed record Publicacion(Guid Migracion, Guid BaseId, string Servidor, string Usuario, string Nombre,
        List<DocumentoPreparado> Documentos, ArchivoPreparado Catalogo);

    /// <summary>Publica una base nueva directamente en PostgreSQL. La base
    /// original no se modifica ni se sube como archivo a Storage.</summary>
    public static async Task<ProyectoNube> PublicarAsync(ClienteSupabase cliente, string ruta, string nombre,
        CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        if (!cliente.SesionIniciada || string.IsNullOrWhiteSpace(cliente.UsuarioId))
            throw new NubeException("Inicie sesión de MYG antes de publicar la base.", necesitaIniciarSesion: true);
        if (string.IsNullOrWhiteSpace(nombre) || nombre.Length > ClienteSupabase.MaxNombreProyectoNube || nombre.Any(char.IsControl))
            throw new ArgumentException("Indique un nombre válido para la base.", nameof(nombre));
        ruta = Path.GetFullPath(ruta);
        var cerrojo = Exclusiones.GetOrAdd(ruta, _ => new(1, 1)); await cerrojo.WaitAsync(ct);
        try
        {
            string carpeta = ruta + ".central-publicacion";
            Directory.CreateDirectory(carpeta);
            using var bloqueo = new FileStream(Path.Combine(carpeta, "intento.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            string manifiesto = Path.Combine(carpeta, "intento.json");
            Publicacion intento;
            if (File.Exists(manifiesto))
                intento = JsonSerializer.Deserialize<Publicacion>(File.ReadAllBytes(manifiesto), Json)
                    ?? throw new InvalidDataException("El intento de publicación está vacío. Conserve sus archivos.");
            else
            {
                ArchivarPreparacionNoEnviada(carpeta);
                ValidarOrigenPortable(ruta);
                // Una instantánea hermana conserva la carpeta de resolución de
                // los adjuntos relativos; los paquetes se congelan antes del HTTP.
                string instantanea = Path.Combine(Path.GetDirectoryName(ruta)!, "p-" + Guid.NewGuid().ToString("N") + ".sqlite");
                try
                {
                    using (var origen = Abrir(ruta, true))
                    using (var salida = new SqliteConnection(new SqliteConnectionStringBuilder
                    { DataSource = instantanea, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString()))
                    { salida.Open(); origen.BackupDatabase(salida); }
                    var documentos = new List<DocumentoPreparado>();
                    foreach (var resumen in MYGBaseDatos.ListarProyectos(instantanea))
                    {
                        ct.ThrowIfCancellationRequested(); progreso?.Report("Preparando la obra central: " + resumen.Nombre);
                        JsonElement contenido = CrearContenidoEstricto(instantanea, resumen.Id);
                        string archivo = "obra-" + documentos.Count.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".json";
                        string destino = Path.Combine(carpeta, archivo);
                        EscribirNuevo(destino, JsonSerializer.SerializeToUtf8Bytes(contenido, Json));
                        documentos.Add(new(resumen.Id, resumen.Nombre, archivo, Hash(destino)));
                    }
                    if (documentos.Count == 0) throw new InvalidDataException("La base no contiene obras para publicar.");
                    var contenidoCatalogo = CrearCatalogoEstricto(instantanea, LeerPaquetesPreparados(carpeta, documentos));
                    ValidarCoberturaPreparacion(instantanea, carpeta, documentos, contenidoCatalogo);
                    var catalogo = GuardarCatalogo(carpeta, contenidoCatalogo);
                    intento = new(Guid.NewGuid(), Guid.NewGuid(), cliente.UrlServidor, cliente.UsuarioId!, nombre.Trim(), documentos, catalogo);
                    EscribirNuevo(manifiesto, JsonSerializer.SerializeToUtf8Bytes(intento, Json));
                }
                finally { SqliteConnection.ClearAllPools(); if (File.Exists(instantanea)) File.Delete(instantanea); }
            }
            void ValidarCuenta()
            {
                if (!cliente.SesionIniciada || cliente.UsuarioId != intento.Usuario
                    || !string.Equals(cliente.UrlServidor, intento.Servidor, StringComparison.OrdinalIgnoreCase)
                    || intento.BaseId == Guid.Empty || intento.Migracion == Guid.Empty || intento.Documentos.Count == 0
                    || intento.Documentos.Select(x => x.DocumentoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != intento.Documentos.Count)
                    throw new InvalidOperationException("La publicación pertenece a otra cuenta o sus identidades no son válidas. Se conserva el intento original.");
            }
            ValidarCuenta();
            await cliente.ComprobarPreservacionBaseAsync(LeerArchivoPreparado(carpeta, intento.Catalogo), ct);
            await cliente.CrearBaseCentralAsync(intento.BaseId, intento.Nombre, intento.Migracion,
                intento.Documentos.Select(x => new DocumentoMigracionCentral(x.DocumentoId, x.Nombre)).ToArray(), ct);
            await cliente.PrepararCatalogoCentralAsync(intento.Migracion, LeerArchivoPreparado(carpeta, intento.Catalogo), ct);
            foreach (var documento in intento.Documentos)
            {
                ct.ThrowIfCancellationRequested(); ValidarCuenta();
                string archivo = RutaPaquete(carpeta, documento);
                if (!File.Exists(archivo) || !Hash(archivo).Equals(documento.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Un paquete de publicación cambió. No se reutilizará su identificador con otros datos.");
                using var contenido = JsonDocument.Parse(File.ReadAllBytes(archivo), new JsonDocumentOptions { MaxDepth = 128 });
                if (PaqueteNube.LeerDocumento(contenido.RootElement).Id != documento.DocumentoId)
                    throw new InvalidDataException("Un paquete de publicación no corresponde a su obra.");
                progreso?.Report("Publicando en la misma base central: " + documento.Nombre);
                await cliente.PrepararDocumentoCentralAsync(intento.Migracion, documento.DocumentoId, contenido.RootElement, ct);
            }
            ValidarCuenta(); progreso?.Report("Confirmando la base central y sus obras…");
            // El manifiesto se conserva también tras el ACK: repetir la acción
            // sobre el mismo origen confirma esa publicación, no crea otra base.
            return await cliente.ActivarMigracionCentralAsync(intento.Migracion, ct);
        }
        finally { cerrojo.Release(); }
    }

    public static bool EsBase(string ruta) => LeerBase(ruta) is not null;

    public static VinculoBaseCentral? LeerBase(string ruta)
    {
        if (!File.Exists(ruta)) return null;
        using var c = Abrir(ruta, true);
        if (!TieneTabla(c, Tabla)) return null;
        using var q = c.CreateCommand(); q.CommandText = "SELECT base_id,servidor,usuario FROM myg_base_central_local WHERE id=1";
        using var r = q.ExecuteReader();
        if (!r.Read()) return null;
        if (!Guid.TryParse(r.GetString(0), out var id) || id == Guid.Empty
            || !Guid.TryParse(r.GetString(2), out var usuario) || usuario == Guid.Empty
            || !Uri.TryCreate(r.GetString(1), UriKind.Absolute, out var uri) || uri.Scheme != "https"
            || uri.UserInfo.Length != 0 || uri.AbsolutePath != "/" || uri.Query.Length != 0 || uri.Fragment.Length != 0)
            throw new InvalidDataException("El vínculo de la base central no es válido. Conserve esta copia local.");
        return new(id, uri.GetLeftPart(UriPartial.Authority), usuario.ToString("D"));
    }

    public static void ValidarIdentidad(ClienteSupabase cliente, VinculoBaseCentral vinculo)
    {
        if (!cliente.SesionIniciada || cliente.UsuarioId != vinculo.Usuario
            || !string.Equals(cliente.UrlServidor.TrimEnd('/'), vinculo.Servidor.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            throw new NubeException("Inicie la cuenta MYG que está vinculada a esta base central.", necesitaIniciarSesion: true);
    }

    /// <summary>Valida el esquema y prepara una obra con sus dependencias. Una
    /// extensión desconocida o un adjunto ausente detienen la conversión.</summary>
    public static JsonElement CrearContenidoEstricto(string ruta, string documentoId)
    {
        ValidarOrigenPortable(ruta);
        var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, documentoId);
        var contenido = PaqueteNube.CrearContenido(documento, ruta, "obra", compacto: false);
        var expandido = FormatoPaqueteNube.Expandir(contenido);
        if (expandido.TryGetProperty("avisos", out var avisos))
            foreach (var aviso in avisos.EnumerateArray())
            {
                string texto = aviso.GetString() ?? "";
                if (texto.StartsWith("Adjunto no disponible:", StringComparison.Ordinal)
                    || texto.Contains("ruta de adjunto no es válida", StringComparison.Ordinal)
                    || texto.Contains("catálogo externo referenciado", StringComparison.Ordinal)
                    || texto.Contains("columnas de una versión distinta", StringComparison.Ordinal)
                    || texto.Contains("ruta de catálogo no es válida", StringComparison.Ordinal))
                    throw new InvalidDataException("No se puede activar la base central sin conservar sus archivos y catálogos. " + texto);
            }
        return NormalizarContenido(contenido);
    }

    /// <summary>Un catálogo privado por base conserva también entradas que aún
    /// no se usan en una obra. No contiene documentos ni tablas de proyectos.</summary>
    public static JsonElement CrearCatalogoEstricto(string ruta) => CrearCatalogoEstricto(ruta, null);

    private static JsonElement CrearCatalogoEstricto(string ruta, IEnumerable<JsonElement>? obras)
    {
        ValidarOrigenPortable(ruta);
        var principal = MYGBaseDatos.ListarProyectos(ruta).FirstOrDefault()
            ?? throw new InvalidDataException("La base no contiene obras.");
        var documento = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, principal.Id);
        var baseCompleta = FormatoPaqueteNube.Expandir(PaqueteNube.CrearContenido(documento, ruta, "base", compacto: false));
        var tablas = baseCompleta.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!
            .Where(x => Compartidas.Contains(x.Nombre)).ToList();
        if (tablas.Any(x => AdicionalesPropietario.Contains(x.Nombre) && x.Filas.Count > 0))
        {
            var claves = LeerClavesConfiables();
            var representadas = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
            obras ??= MYGBaseDatos.ListarProyectos(ruta).Select(x => CrearContenidoEstricto(ruta, x.Id));
            foreach (var obra in obras)
            {
                var paquete = FormatoPaqueteNube.Expandir(obra);
                foreach (var tabla in paquete.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!
                    .Where(x => AdicionalesPropietario.Contains(x.Nombre)))
                {
                    if (!representadas.TryGetValue(tabla.Nombre, out var filas))
                        representadas[tabla.Nombre] = filas = new(StringComparer.Ordinal);
                    foreach (var fila in tabla.Filas) filas.Add(ClaveFila(tabla, fila, claves));
                }
            }
            foreach (var tabla in tablas.Where(x => AdicionalesPropietario.Contains(x.Nombre)))
            {
                if (representadas.TryGetValue(tabla.Nombre, out var filas))
                    tabla.Filas.RemoveAll(fila => filas.Contains(ClaveFila(tabla, fila, claves)));
                var identidades = new HashSet<string>(StringComparer.Ordinal);
                if (tabla.Filas.Any(fila => !identidades.Add(ClaveFila(tabla, fila, claves))))
                    throw new InvalidDataException("La tabla '" + tabla.Nombre + "' contiene datos privados sin una identidad única. No se inició la publicación; conserve el archivo original.");
            }
        }
        // La tabla vacía ya la reconstruye el esquema de Core. No anunciarla
        // como extensión evita exigir la migración adicional a una base que
        // realmente no tiene ninguno de esos datos.
        tablas.RemoveAll(tabla => AdicionalesPropietario.Contains(tabla.Nombre) && tabla.Filas.Count == 0);
        var referencias = new HashSet<string>(StringComparer.Ordinal);
        void Referencias(JsonNode? nodo)
        {
            if (nodo is JsonValue valor && valor.TryGetValue<string>(out var texto))
            {
                referencias.Add(texto);
                if (!string.IsNullOrWhiteSpace(texto) && (texto.TrimStart().StartsWith('{') || texto.TrimStart().StartsWith('[')))
                    try { Referencias(JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 })); } catch (JsonException) { }
            }
            else if (nodo is JsonObject objeto) foreach (var campo in objeto) Referencias(campo.Value);
            else if (nodo is JsonArray lista) foreach (var hijo in lista) Referencias(hijo);
        }
        Referencias(JsonSerializer.SerializeToNode(tablas, Json));
        var recursos = baseCompleta.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>(Json)!
            .Where(x => referencias.Contains(x.Referencia)).ToList();
        foreach (var recurso in recursos) recurso.Almacen = null;
        return NormalizarContenido(JsonSerializer.SerializeToElement(new
        { formato = "MYG_CATALOGO_BASE", version = 1, tablas, recursos }, Json));
    }

    /// <summary>El UUID y todos los paquetes se congelan en disco antes de la
    /// primera petición. Un cierre o un ACK perdido reanudan el mismo intento.</summary>
    public static async Task<IReadOnlyList<ProyectoNube>> PrepararMigracionAsync(ClienteSupabase cliente,
        string ruta, ProyectoSqliteNube remoto, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ArgumentNullException.ThrowIfNull(cliente); ArgumentNullException.ThrowIfNull(remoto);
        ruta = Path.GetFullPath(ruta);
        var cerrojo = Exclusiones.GetOrAdd(ruta, _ => new(1, 1)); await cerrojo.WaitAsync(ct);
        try
        {
            ValidarPropietario(cliente, remoto.Proyecto);
            if (LeerBase(ruta) is { } vinculado)
            {
                ValidarIdentidad(cliente, vinculado);
                if (vinculado.BaseId != remoto.Proyecto.Id) throw new InvalidOperationException("La copia pertenece a otra base central.");
                return await cliente.ListarObrasCentralAsync(vinculado.BaseId, ct);
            }
            string carpeta = ruta + ".central";
            Directory.CreateDirectory(carpeta);
            using var bloqueo = new FileStream(Path.Combine(carpeta, "intento.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            string manifiesto = Path.Combine(carpeta, "intento.json");
            Intento? intento = null;
            if (File.Exists(manifiesto))
            {
                intento = JsonSerializer.Deserialize<Intento>(File.ReadAllBytes(manifiesto), Json)
                    ?? throw new InvalidDataException("El intento de activación está vacío. Conserve sus archivos.");
                if (intento.BaseId == remoto.Proyecto.Id && intento.Usuario == cliente.UsuarioId
                    && string.Equals(intento.Servidor, cliente.UrlServidor, StringComparison.OrdinalIgnoreCase)
                    && intento.Revision < remoto.Proyecto.Revision)
                {
                    progreso?.Report("Conservando la preparación anterior para activar la revisión ya sincronizada…");
                    // Cancelar primero bajo autorización/CAS del servidor. Si
                    // entretanto se activó, el rechazo conserva el manifiesto
                    // original para recuperar su ACK y su base de edición.
                    await cliente.CancelarMigracionCentralAsync(intento.Migracion, ct);
                    ArchivarIntentoCancelado(carpeta, intento);
                    intento = null;
                }
                else ValidarIntento(cliente, remoto, intento);
            }
            if (intento is null)
            {
                ExigirSinPendientes(ruta, remoto.Proyecto.Id, cliente);
                ArchivarPreparacionNoEnviada(carpeta);
                string instantanea = Path.Combine(carpeta, "origen.sqlite");
                progreso?.Report("Comprobando la última revisión de la base y sus obras…");
                CopiaSqliteNube.CrearSnapshot(ruta, instantanea, ct);
                string hash = Hash(instantanea);
                if (!hash.Equals(remoto.Archivo.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("La base local tiene cambios que todavía no están confirmados en la nube. Sincronice todas las obras antes de activar la base central.");
                ValidarOrigenPortable(instantanea);
                var documentos = new List<DocumentoPreparado>();
                foreach (var resumen in MYGBaseDatos.ListarProyectos(instantanea))
                {
                    ct.ThrowIfCancellationRequested(); progreso?.Report("Preparando la obra: " + resumen.Nombre);
                    JsonElement contenido = CrearContenidoEstricto(instantanea, resumen.Id);
                    string archivo = "obra-" + documentos.Count.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".json";
                    string destino = Path.Combine(carpeta, archivo);
                    EscribirNuevo(destino, JsonSerializer.SerializeToUtf8Bytes(contenido, Json));
                    documentos.Add(new(resumen.Id, resumen.Nombre, archivo, Hash(destino)));
                }
                if (documentos.Count == 0) throw new InvalidDataException("La base no contiene obras para activar.");
                var contenidoCatalogo = CrearCatalogoEstricto(instantanea, LeerPaquetesPreparados(carpeta, documentos));
                ValidarCoberturaPreparacion(instantanea, carpeta, documentos, contenidoCatalogo);
                var catalogo = GuardarCatalogo(carpeta, contenidoCatalogo);
                intento = new(Guid.NewGuid(), remoto.Proyecto.Id, cliente.UrlServidor, cliente.UsuarioId!, remoto.Proyecto.Revision, hash, documentos, catalogo);
                EscribirNuevo(manifiesto, JsonSerializer.SerializeToUtf8Bytes(intento, Json));
            }
            ValidarIntento(cliente, remoto, intento);
            await cliente.ComprobarPreservacionBaseAsync(LeerArchivoPreparado(carpeta, intento.Catalogo), ct);
            var estado = await cliente.IniciarMigracionCentralAsync(intento.BaseId, intento.Revision, intento.Migracion,
                intento.Documentos.Select(x => new DocumentoMigracionCentral(x.DocumentoId, x.Nombre)).ToArray(), ct);
            await cliente.PrepararCatalogoCentralAsync(intento.Migracion, LeerArchivoPreparado(carpeta, intento.Catalogo), ct);
            foreach (var documento in intento.Documentos)
            {
                ct.ThrowIfCancellationRequested(); ValidarIntento(cliente, remoto, intento);
                string archivo = RutaPaquete(carpeta, documento);
                if (!File.Exists(archivo) || !Hash(archivo).Equals(documento.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Un paquete de la activación cambió o falta. No se enviarán otros datos con el mismo identificador.");
                using var contenido = JsonDocument.Parse(File.ReadAllBytes(archivo), new JsonDocumentOptions { MaxDepth = 128 });
                if (PaqueteNube.LeerDocumento(contenido.RootElement).Id != documento.DocumentoId)
                    throw new InvalidDataException("Un paquete no corresponde a la obra del intento de activación.");
                progreso?.Report("Preparando en la base central: " + documento.Nombre);
                await cliente.PrepararDocumentoCentralAsync(intento.Migracion, documento.DocumentoId, contenido.RootElement, ct);
            }
            progreso?.Report("Confirmando la activación de todas las obras…");
            await cliente.ActivarMigracionCentralAsync(intento.Migracion, ct);
            var obras = await DescargarObras(cliente, intento.BaseId, ct, progreso);
            // Un colaborador puede guardar la revisión 2 después del ACK y
            // antes de esta descarga. La base local corresponde al paquete
            // congelado de revisión 1, nunca a esa edición posterior ajena.
            ActivarLocal(cliente, ruta, intento.BaseId, BasesCongeladas(carpeta, intento, obras), LeerArchivoPreparado(carpeta, intento.Catalogo));
            return obras;
        }
        finally { cerrojo.Release(); }
    }

    /// <summary>Repara únicamente el vínculo tras un cierre posterior al ACK de
    /// activación. Los borradores locales siguen siendo pendientes de su obra.</summary>
    public static async Task<IReadOnlyList<ProyectoNube>> RecuperarActivacionAsync(ClienteSupabase cliente,
        string ruta, Guid baseId, CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        var cabecera = await cliente.ResolverCentralAsync(baseId, ct)
            ?? throw new InvalidOperationException("La base todavía no está activada en Supabase.");
        ValidarPropietario(cliente, cabecera);
        if (LeerBase(ruta) is { } vinculo)
        {
            ValidarIdentidad(cliente, vinculo);
            if (vinculo.BaseId != baseId) throw new InvalidOperationException("La copia pertenece a otra base central.");
        }
        var obras = await DescargarObras(cliente, baseId, ct, progreso);
        if (LeerBase(ruta) is null)
        {
            string carpeta = Path.GetFullPath(ruta) + ".central";
            string manifiesto = Path.Combine(carpeta, "intento.json");
            if (!File.Exists(manifiesto))
                throw new InvalidOperationException("Esta copia no conserva el intento original de activación. Manténgala para recuperar sus borradores y abra la base central en una copia local nueva desde Nube MYG.");
            var intento = JsonSerializer.Deserialize<Intento>(File.ReadAllBytes(manifiesto), Json)
                ?? throw new InvalidDataException("El intento original de activación no es válido.");
            if (intento.BaseId != baseId || intento.Usuario != cliente.UsuarioId
                || !string.Equals(intento.Servidor, cliente.UrlServidor, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("El intento de activación pertenece a otra base o cuenta. Se conserva esta copia local.");
            ActivarLocal(cliente, ruta, baseId, BasesCongeladas(carpeta, intento, obras), LeerArchivoPreparado(carpeta, intento.Catalogo));
        }
        return obras;
    }

    private static IReadOnlyList<ProyectoNube> BasesCongeladas(string carpeta, Intento intento, IReadOnlyList<ProyectoNube> actuales)
    {
        var bases = new List<ProyectoNube>();
        foreach (var documento in intento.Documentos)
        {
            string archivo = RutaPaquete(carpeta, documento);
            if (!File.Exists(archivo) || !Hash(archivo).Equals(documento.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("La base de edición congelada de la activación cambió. No se adoptará una revisión posterior como si ya estuviera incorporada localmente.");
            using var contenido = JsonDocument.Parse(File.ReadAllBytes(archivo), new JsonDocumentOptions { MaxDepth = 128 });
            var actual = actuales.SingleOrDefault(x => x.DocumentoId == documento.DocumentoId && x.BaseId == intento.BaseId)
                ?? throw new InvalidOperationException("Una obra de la activación ya no está disponible. Se conserva su copia local.");
            if (PaqueteNube.LeerDocumento(contenido.RootElement).Id != documento.DocumentoId)
                throw new InvalidDataException("La base congelada no corresponde a su obra.");
            bases.Add(actual with { Revision = 1, Contenido = contenido.RootElement.Clone() });
        }
        return bases;
    }

    public static void ActivarLocal(ClienteSupabase cliente, string ruta, Guid baseId, IReadOnlyList<ProyectoNube> obras,
        JsonElement? catalogoOriginal = null)
    {
        if (!cliente.SesionIniciada || string.IsNullOrWhiteSpace(cliente.UsuarioId) || baseId == Guid.Empty)
            throw new NubeException("Inicie sesión de MYG para vincular la base central.", necesitaIniciarSesion: true);
        ValidarObras(baseId, obras);
        var identificadores = MYGBaseDatos.ListarProyectos(ruta).Select(x => x.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (!identificadores.SetEquals(obras.Select(x => x.DocumentoId!)))
            throw new InvalidOperationException("Las obras locales y las de la activación no coinciden. Se conservan todas las obras y sus borradores.");
        if (LeerBase(ruta) is { } actual)
        {
            ValidarIdentidad(cliente, actual);
            if (actual.BaseId != baseId) throw new InvalidOperationException("La copia pertenece a otra base central.");
        }
        // Comprobar todos los vínculos antes de escribir el primero.
        foreach (var obra in obras) ValidarVinculoAnterior(cliente, ruta, obra);
        InstalarPreservacionLocal(ruta, catalogoOriginal ?? CrearCatalogoEstricto(ruta));
        foreach (var obra in obras) VincularObraLocal(cliente, ruta, obra);
        MarcarBase(ruta, new(baseId, cliente.UrlServidor, cliente.UsuarioId!));
    }

    public static void VincularObraLocal(ClienteSupabase cliente, string ruta, ProyectoNube obra)
    {
        if (!obra.EsCentralNativa || !obra.EsObraMismaBase || obra.BaseId is null || obra.DocumentoId is null || obra.Rol != "propietario")
            throw new InvalidDataException("La respuesta no corresponde a una obra propia de la base central.");
        if (!cliente.SesionIniciada || string.IsNullOrWhiteSpace(cliente.UsuarioId))
            throw new NubeException("Inicie sesión de MYG antes de vincular la obra.", necesitaIniciarSesion: true);
        ValidarVinculoAnterior(cliente, ruta, obra);
        var existente = MYGColaboracionLocal.Leer(ruta, obra.DocumentoId);
        if (existente is not null) return; // Nunca sustituir una cola que ya se creó, ni siquiera tras un cierre.
        var confirmado = PaqueteNube.MaterializarDocumento(obra.Contenido, ruta);
        ArchivoPublicacionSqlitePendiente.ReubicarDocumentoPortable(confirmado, ruta);
        bool yaExiste = MYGBaseDatos.ListarProyectos(ruta).Any(x => x.Id == obra.DocumentoId);
        var local = yaExiste ? ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, obra.DocumentoId) : confirmado;
        MYGColaboracionLocal.Vincular(ruta, local, new MYGVinculoNube
        {
            ProyectoId = obra.Id, Servidor = cliente.UrlServidor, UsuarioId = cliente.UsuarioId!, Rol = obra.Rol,
            Revision = obra.Revision, PermisosModulos = obra.PermisosModulos?.Copiar(),
            JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(confirmado),
            JsonPaqueteConfirmado = obra.Contenido.GetRawText()
        }, yaExiste ? null : (c, t) =>
        {
            PaqueteNube.AplicarDependencias(obra.Contenido, c, t);
            PrepararTitulosNativos(obra.Contenido, c, t);
        });
    }

    /// <summary>Descarga la base del propietario en un destino nuevo. La creación
    /// se prepara aparte y solo se hace visible cuando todas las obras validan.</summary>
    public static async Task CrearCopiaAsync(ClienteSupabase cliente, Guid baseId, string rutaNueva,
        CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        rutaNueva = Path.GetFullPath(rutaNueva);
        if (File.Exists(rutaNueva)) throw new IOException("La descarga necesita una ruta nueva. No se sobrescribirá una copia de trabajo.");
        var cabecera = await cliente.ResolverCentralAsync(baseId, ct)
            ?? throw new InvalidOperationException("No se encontró la base central.");
        ValidarPropietario(cliente, cabecera);
        var obras = await DescargarObras(cliente, baseId, ct, progreso);
        ValidarObras(baseId, obras);
        var catalogo = await cliente.ObtenerCatalogoCentralAsync(baseId, ct);
        var catalogos = FusionarCatalogosActuales(catalogo, obras);
        Directory.CreateDirectory(Path.GetDirectoryName(rutaNueva)!);
        string preparacion = rutaNueva + "." + Guid.NewGuid().ToString("N") + ".tmp.sqlite";
        try
        {
            MYGBaseDatos.CrearBaseVacia(preparacion);
            // Los datos ya referidos por una obra proceden de su revisión
            // actual, no de la fotografía inicial del catálogo de la base.
            AplicarCatalogoInicial(preparacion, catalogos.SinFilasDeObras);
            InstalarPreservacionLocal(preparacion, catalogos.SinFilasDeObras);
            foreach (var obra in obras)
            {
                ct.ThrowIfCancellationRequested();
                var doc = PaqueteNube.MaterializarDocumento(obra.Contenido, preparacion);
                // PaqueteNube aplica catálogos por UPSERT y rechaza colisiones con
                // otra obra; no permite que una descarga modifique datos ajenos.
                MYGColaboracionLocal.Vincular(preparacion, doc, new MYGVinculoNube
                {
                    ProyectoId = obra.Id, Servidor = cliente.UrlServidor, UsuarioId = cliente.UsuarioId!, Rol = obra.Rol,
                    Revision = obra.Revision, PermisosModulos = obra.PermisosModulos?.Copiar(),
                    JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(doc), JsonPaqueteConfirmado = obra.Contenido.GetRawText()
                }, (c, t) =>
                {
                    PaqueteNube.AplicarDependencias(obra.Contenido, c, t);
                    PrepararTitulosNativos(obra.Contenido, c, t);
                });
            }
            foreach (var obra in obras)
            {
                ct.ThrowIfCancellationRequested();
                var reconstruido = CrearContenidoEstricto(preparacion, obra.DocumentoId!);
                if (PaqueteNube.FirmaDatosCompartidos(reconstruido) != PaqueteNube.FirmaDatosCompartidos(obra.Contenido))
                    throw new InvalidDataException("No se pudo reconstruir íntegramente la obra '" + obra.Nombre + "'. Se conserva la base central; no se sustituirá la copia de trabajo.");
            }
            var catalogoReconstruido = CrearCatalogoEstricto(preparacion);
            ExigirCatalogoConservado(catalogos.Esperado, catalogoReconstruido);
            MarcarBase(preparacion, new(baseId, cliente.UrlServidor, cliente.UsuarioId!));
            // Las rutas del temporal solo se reubican en los documentos; los
            // archivos materializados siguen en su ruta inmutable de recursos.
            foreach (var resumen in MYGBaseDatos.ListarProyectos(preparacion))
            {
                var documento = MYGBaseDatos.LeerProyecto(preparacion, resumen.Id);
                ReubicarRutas(documento, preparacion, rutaNueva);
                var vinculo = MYGColaboracionLocal.Leer(preparacion, resumen.Id)!;
                var confirmado = MYGColaboracionLocal.ImportarDocumento(vinculo.JsonConfirmado);
                ReubicarRutas(confirmado, preparacion, rutaNueva);
                vinculo.JsonConfirmado = MYGColaboracionLocal.ExportarDocumento(confirmado);
                vinculo.JsonBorrador = vinculo.JsonConfirmado;
                MYGColaboracionLocal.Guardar(preparacion, documento, vinculo);
            }
            ct.ThrowIfCancellationRequested(); File.Move(preparacion, rutaNueva);
        }
        finally
        {
            SqliteConnection.ClearAllPools();
            if (File.Exists(preparacion)) File.Delete(preparacion);
        }
    }

    public static void ValidarOrigenPortable(string ruta)
    {
        string patron = Path.Combine(Path.GetTempPath(), "myg-central-esquema-" + Guid.NewGuid().ToString("N") + ".sqlite");
        try
        {
            MYGBaseDatos.CrearBaseVacia(patron);
            using var origen = Abrir(ruta, true); using var referencia = Abrir(patron, true);
            ValidarPreservacionLocal(origen);
            var conocidas = LeerEsquema(referencia);
            conocidas["myg_indice_unificado"] = new(StringComparer.OrdinalIgnoreCase) { "codigo", "descripcion", "periodo_base", "resolucion", "orden" };
            foreach (var tabla in LeerEsquema(origen))
            {
                if (Privadas.Contains(tabla.Key) || tabla.Key.StartsWith("sqlite_", StringComparison.OrdinalIgnoreCase)) continue;
                using var q = origen.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM " + Identificador(tabla.Key) + " LIMIT 1)";
                bool contieneDatos = Convert.ToInt64(q.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) != 0;
                if (!contieneDatos) continue;
                if (!conocidas.TryGetValue(tabla.Key, out var columnas))
                    throw new InvalidDataException("La extensión '" + tabla.Key + "' contiene datos que no pueden migrarse automáticamente. Se conserva la base original.");
                var adicionales = tabla.Value.Where(x => !columnas.Contains(x)).ToList();
                if (adicionales.Count > 0)
                    throw new InvalidDataException("La tabla '" + tabla.Key + "' tiene columnas de una extensión no compatible: " + string.Join(", ", adicionales) + ". Se conserva la base original.");
            }
        }
        finally { SqliteConnection.ClearAllPools(); if (File.Exists(patron)) File.Delete(patron); }
    }

    private static async Task<IReadOnlyList<ProyectoNube>> DescargarObras(ClienteSupabase cliente, Guid baseId,
        CancellationToken ct, IProgress<string>? progreso)
    {
        var lista = await cliente.ListarObrasCentralAsync(baseId, ct);
        var resultado = new List<ProyectoNube>();
        foreach (var obra in lista)
        {
            progreso?.Report("Comprobando la obra central: " + obra.Nombre);
            var completa = await cliente.AbrirObraCentralAsync(obra.Id, ct);
            if (completa.BaseId != baseId || completa.DocumentoId != obra.DocumentoId)
                throw new InvalidDataException("La respuesta no corresponde a la obra solicitada.");
            resultado.Add(completa);
        }
        return resultado;
    }

    private static void ValidarObras(Guid baseId, IReadOnlyList<ProyectoNube> obras)
    {
        if (obras.Count == 0 || obras.Select(x => x.Id).Distinct().Count() != obras.Count
            || obras.Select(x => x.DocumentoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != obras.Count
            || obras.Any(x => !x.EsCentralNativa || x.BaseId != baseId || !x.EsObraMismaBase || x.Rol != "propietario"
                || string.IsNullOrWhiteSpace(x.DocumentoId) || PaqueteNube.LeerDocumento(x.Contenido).Id != x.DocumentoId))
            throw new InvalidDataException("La respuesta no contiene las obras propias completas de la base central.");
    }

    private static void ValidarVinculoAnterior(ClienteSupabase cliente, string ruta, ProyectoNube obra)
    {
        var anterior = MYGColaboracionLocal.Leer(ruta, obra.DocumentoId!);
        if (anterior is null) return;
        SincronizadorProyectoNube.ValidarIdentidad(cliente, anterior);
        if (anterior.ProyectoId != obra.Id)
            throw new InvalidOperationException("Una obra conserva un vínculo anterior. No se sustituirá su identidad ni su cola pendiente.");
    }

    private static void ValidarPropietario(ClienteSupabase cliente, ProyectoNube proyecto)
    {
        if (!cliente.SesionIniciada || string.IsNullOrWhiteSpace(cliente.UsuarioId))
            throw new NubeException("Inicie sesión de MYG antes de activar la base central.", necesitaIniciarSesion: true);
        if (proyecto.Alcance != "base" || proyecto.Rol != "propietario")
            throw new InvalidOperationException("Solo el propietario puede activar o descargar la base completa.");
    }

    private static void ValidarIntento(ClienteSupabase cliente, ProyectoSqliteNube remoto, Intento intento)
    {
        if (intento.Migracion == Guid.Empty || intento.BaseId != remoto.Proyecto.Id || intento.Revision != remoto.Proyecto.Revision
            || intento.Usuario != cliente.UsuarioId || !cliente.SesionIniciada
            || !string.Equals(intento.Servidor, cliente.UrlServidor, StringComparison.OrdinalIgnoreCase)
            || !intento.HashOrigen.Equals(remoto.Archivo.Sha256, StringComparison.OrdinalIgnoreCase)
            || intento.Catalogo is null || intento.Documentos.Count == 0 || intento.Documentos.Select(x => x.DocumentoId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != intento.Documentos.Count)
            throw new InvalidOperationException("El intento pertenece a otra cuenta o revisión. Conserve sus archivos y reanude la activación original.");
    }

    private static void ExigirSinPendientes(string ruta, Guid baseId, ClienteSupabase cliente)
    {
        if (!File.Exists(CopiaSqliteNube.RutaEstado(ruta)))
            throw new InvalidOperationException("Abra la base original desde Nube MYG antes de activarla.");
        using var c = Abrir(CopiaSqliteNube.RutaEstado(ruta), true);
        using var q = c.CreateCommand();
        q.CommandText = "SELECT COUNT(*) FROM vinculo WHERE alcance='base' AND proyecto=$p0 AND servidor=$p1 AND usuario=$p2 AND rol='propietario'";
        q.Parameters.AddWithValue("$p0", baseId.ToString("D")); q.Parameters.AddWithValue("$p1", cliente.UrlServidor); q.Parameters.AddWithValue("$p2", cliente.UsuarioId!);
        if (Convert.ToInt64(q.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) != 1)
            throw new InvalidOperationException("La base local no corresponde al propietario y al servidor de la activación.");
        q.Parameters.Clear(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM pendiente) OR EXISTS(SELECT 1 FROM vinculo WHERE conflicto_revision>0)";
        if (Convert.ToInt64(q.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) != 0)
            throw new InvalidOperationException("La base conserva una operación o un conflicto. Sincronícelo antes de activar la base central.");
        if (TieneTabla(c, "bim_local"))
        {
            q.CommandText = "SELECT EXISTS(SELECT 1 FROM bim_local WHERE operacion IS NOT NULL OR conflicto<>0)";
            if (Convert.ToInt64(q.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) != 0)
                throw new InvalidOperationException("Hay cambios BIM pendientes. Sincronícelos antes de activar la base central.");
        }
    }

    private static string RutaPaquete(string carpeta, DocumentoPreparado documento)
    {
        if (string.IsNullOrWhiteSpace(documento.Archivo) || Path.GetFileName(documento.Archivo) != documento.Archivo)
            throw new InvalidDataException("La ruta de un paquete de activación no es válida.");
        return Path.Combine(carpeta, documento.Archivo);
    }

    private static void ArchivarPreparacionNoEnviada(string carpeta)
    {
        if (File.Exists(Path.Combine(carpeta, "intento.json")))
            throw new InvalidOperationException("La activación ya tiene un intento durable y debe reanudarse con sus mismos paquetes.");
        var archivos = Directory.EnumerateFiles(carpeta, "obra-*.json", SearchOption.TopDirectoryOnly).ToList();
        string origen = Path.Combine(carpeta, "origen.sqlite");
        if (File.Exists(origen)) archivos.Add(origen);
        string catalogo = Path.Combine(carpeta, "catalogo.json");
        if (File.Exists(catalogo)) archivos.Add(catalogo);
        if (archivos.Count == 0) return;
        // Sin manifiesto no se ha enviado ninguna RPC. Guardar la preparación
        // incompleta permite corregir datos y reintentar sin cirugía manual.
        string respaldo = Path.Combine(carpeta, "preparacion-interrumpida-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(respaldo);
        foreach (string archivo in archivos) File.Move(archivo, Path.Combine(respaldo, Path.GetFileName(archivo)));
    }

    private static void ArchivarIntentoCancelado(string carpeta, Intento intento)
    {
        var archivos = intento.Documentos.Select(x => RutaPaquete(carpeta, x)).ToList();
        if (intento.Catalogo is { } catalogo)
        {
            if (Path.GetFileName(catalogo.Archivo) != catalogo.Archivo) throw new InvalidDataException("La ruta del catálogo de la preparación no es válida.");
            archivos.Add(Path.Combine(carpeta, catalogo.Archivo));
        }
        archivos.Add(Path.Combine(carpeta, "origen.sqlite"));
        string manifiesto = Path.Combine(carpeta, "intento.json");
        string respaldo = Path.Combine(carpeta, "intento-cancelado-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(respaldo);
        foreach (string archivo in archivos.Distinct(StringComparer.OrdinalIgnoreCase))
            if (File.Exists(archivo)) File.Move(archivo, Path.Combine(respaldo, Path.GetFileName(archivo)));
        // Mover el manifiesto al final permite repetir una cancelación cuyo
        // archivo se interrumpió a medio camino, sin reutilizar paquetes viejos.
        File.Move(manifiesto, Path.Combine(respaldo, "intento.json"));
    }

    private static ArchivoPreparado GuardarCatalogo(string carpeta, JsonElement catalogo)
    {
        string archivo = Path.Combine(carpeta, "catalogo.json");
        EscribirNuevo(archivo, JsonSerializer.SerializeToUtf8Bytes(catalogo, Json));
        return new("catalogo.json", Hash(archivo));
    }

    private static void ValidarCoberturaPreparacion(string ruta, string carpeta, IReadOnlyList<DocumentoPreparado> documentos, JsonElement catalogo)
    {
        var contenidos = new List<JsonElement>();
        foreach (var documento in documentos)
        {
            using var json = JsonDocument.Parse(File.ReadAllBytes(RutaPaquete(carpeta, documento)), new JsonDocumentOptions { MaxDepth = 128 });
            contenidos.Add(json.RootElement.Clone());
        }
        CoberturaCentralNube.Validar(ruta, contenidos, catalogo);
    }

    private static IEnumerable<JsonElement> LeerPaquetesPreparados(string carpeta, IReadOnlyList<DocumentoPreparado> documentos)
    {
        foreach (var documento in documentos)
        {
            string ruta = RutaPaquete(carpeta, documento);
            if (!File.Exists(ruta) || !Hash(ruta).Equals(documento.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Una obra congelada cambió antes de comprobar la conservación de la base.");
            using var json = JsonDocument.Parse(File.ReadAllBytes(ruta), new JsonDocumentOptions { MaxDepth = 128 });
            yield return json.RootElement.Clone();
        }
    }

    private static JsonElement LeerArchivoPreparado(string carpeta, ArchivoPreparado archivo)
    {
        if (archivo is null || string.IsNullOrWhiteSpace(archivo.Archivo) || Path.GetFileName(archivo.Archivo) != archivo.Archivo)
            throw new InvalidDataException("La identidad del catálogo congelado no es válida.");
        string ruta = Path.Combine(carpeta, archivo.Archivo);
        if (!File.Exists(ruta) || !Hash(ruta).Equals(archivo.Sha256, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("El catálogo congelado cambió o falta. No se sustituirá por otro contenido en el reintento.");
        using var json = JsonDocument.Parse(File.ReadAllBytes(ruta), new JsonDocumentOptions { MaxDepth = 128 });
        return json.RootElement.Clone();
    }

    private static JsonElement EnvolverCatalogo(JsonElement catalogo, JsonElement obra)
    {
        if (catalogo.ValueKind != JsonValueKind.Object || catalogo.GetProperty("formato").GetString() != "MYG_CATALOGO_BASE"
            || catalogo.GetProperty("version").GetInt32() != 1)
            throw new InvalidDataException("El catálogo central no tiene un formato compatible.");
        var objeto = JsonNode.Parse(FormatoPaqueteNube.Expandir(obra).GetRawText(), documentOptions: new JsonDocumentOptions { MaxDepth = 128 })!.AsObject();
        objeto["tablas"] = JsonNode.Parse(catalogo.GetProperty("tablas").GetRawText());
        objeto["recursos"] = JsonNode.Parse(catalogo.GetProperty("recursos").GetRawText());
        return JsonSerializer.SerializeToElement(objeto, Json);
    }

    private sealed record CatalogosActuales(JsonElement SinFilasDeObras, JsonElement Esperado);
    private sealed record FilaActual(List<PaqueteNube.Celda> Fila, string Firma);

    private static CatalogosActuales FusionarCatalogosActuales(JsonElement inicial, IReadOnlyList<ProyectoNube> obras)
    {
        var originales = inicial.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!;
        var recursosIniciales = inicial.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>(Json)!;
        var esquemas = originales.ToDictionary(x => x.Nombre, x => x.Columnas, StringComparer.OrdinalIgnoreCase);
        var claves = LeerClavesConfiables();
        var actuales = new Dictionary<string, Dictionary<string, FilaActual>>(StringComparer.OrdinalIgnoreCase);
        var recursosObras = new List<PaqueteNube.Recurso>();
        foreach (var obra in obras)
        {
            var contenido = FormatoPaqueteNube.Expandir(obra.Contenido);
            var recursos = contenido.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>(Json)!;
            var tablas = contenido.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!.Where(x => Compartidas.Contains(x.Nombre)).ToList();
            var referencias = ReferenciasTablas(tablas);
            recursosObras.AddRange(recursos.Where(x => referencias.Contains(x.Referencia)));
            foreach (var tabla in tablas)
            {
                if (!esquemas.TryGetValue(tabla.Nombre, out var columnas)) esquemas[tabla.Nombre] = columnas = tabla.Columnas;
                if (columnas.Count != tabla.Columnas.Count || !columnas.ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(tabla.Columnas))
                    throw new InvalidDataException("Las obras usan versiones distintas del catálogo '" + tabla.Nombre + "'. Se conservan sus datos centrales.");
                if (!actuales.TryGetValue(tabla.Nombre, out var filas)) actuales[tabla.Nombre] = filas = new(StringComparer.Ordinal);
                foreach (var fila in tabla.Filas)
                {
                    var alineada = columnas.Select(x => fila[tabla.Columnas.FindIndex(y => y.Equals(x, StringComparison.OrdinalIgnoreCase))]).ToList();
                    var canonica = new PaqueteNube.Tabla { Nombre = tabla.Nombre, Columnas = columnas };
                    string clave = ClaveFila(canonica, alineada, claves);
                    string firma = FirmarFilaCatalogo(canonica, alineada, recursos);
                    if (filas.TryGetValue(clave, out var previa) && previa.Firma != firma)
                        throw new InvalidDataException("Dos obras conservan versiones diferentes de una dependencia compartida del catálogo '" + tabla.Nombre
                            + "'. Se mantienen todas las revisiones; resuelva la diferencia antes de reconstruir la base completa.");
                    filas[clave] = new(alineada, firma);
                }
            }
        }
        var sinObras = new List<PaqueteNube.Tabla>(); var esperadas = new List<PaqueteNube.Tabla>();
        foreach (var nombre in esquemas.Keys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            var columnas = esquemas[nombre];
            var tabla = originales.SingleOrDefault(x => x.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))
                ?? new PaqueteNube.Tabla { Nombre = nombre, Columnas = columnas };
            actuales.TryGetValue(nombre, out var propias);
            if (AdicionalesPropietario.Contains(nombre) && propias is not null)
                foreach (var fila in tabla.Filas)
                    if (propias.TryGetValue(ClaveFila(tabla, fila, claves), out var actual)
                        && FirmarFilaCatalogo(tabla, fila, recursosIniciales) != actual.Firma)
                        throw new InvalidDataException("La obra y los datos privados originales contienen valores distintos para la misma identidad en '"
                            + nombre + "'. No se sobrescribirá ni ocultará ninguna de las dos versiones.");
            var sinFilas = new PaqueteNube.Tabla { Nombre = nombre, Columnas = columnas,
                Filas = tabla.Filas.Where(x => propias?.ContainsKey(ClaveFila(tabla, x, claves)) != true).ToList() };
            sinObras.Add(sinFilas);
            esperadas.Add(new PaqueteNube.Tabla { Nombre = nombre, Columnas = columnas,
                Filas = AdicionalesPropietario.Contains(nombre) ? sinFilas.Filas.ToList()
                    : sinFilas.Filas.Concat(propias?.Values.Select(x => x.Fila) ?? Enumerable.Empty<List<PaqueteNube.Celda>>()).ToList() });
        }
        var referenciasSinObras = ReferenciasTablas(sinObras);
        var recursosConservados = recursosIniciales.Where(x => referenciasSinObras.Contains(x.Referencia)).ToList();
        var fusionados = new Dictionary<string, PaqueteNube.Recurso>(StringComparer.Ordinal);
        foreach (var recurso in recursosConservados.Concat(recursosObras))
        {
            if (fusionados.TryGetValue(recurso.Referencia, out var previo)
                && !previo.Sha256.Equals(recurso.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("El catálogo y las obras conservan contenidos distintos del mismo adjunto. No se sobrescribirá ninguna versión.");
            fusionados[recurso.Referencia] = recurso;
        }
        return new(JsonSerializer.SerializeToElement(new { formato = "MYG_CATALOGO_BASE", version = 1, tablas = sinObras, recursos = recursosConservados }, Json),
            JsonSerializer.SerializeToElement(new { formato = "MYG_CATALOGO_BASE", version = 1, tablas = esperadas, recursos = fusionados.Values.ToList() }, Json));
    }

    private static Dictionary<string, List<string>> LeerClavesConfiables()
    {
        string ruta = Path.Combine(Path.GetTempPath(), "myg-central-claves-" + Guid.NewGuid().ToString("N") + ".sqlite");
        try
        {
            MYGBaseDatos.CrearBaseVacia(ruta); using var c = Abrir(ruta, true);
            var resultado = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            foreach (string tabla in Compartidas)
            {
                using var q = c.CreateCommand(); q.CommandText = "PRAGMA table_info(" + Identificador(tabla) + ")";
                using var r = q.ExecuteReader(); var partes = new SortedDictionary<int, string>();
                while (r.Read()) if (r.GetInt32(5) > 0) partes[r.GetInt32(5)] = r.GetString(1);
                resultado[tabla] = partes.Values.ToList();
            }
            resultado["myg_indice_unificado"] = ["codigo"];
            return resultado;
        }
        finally { SqliteConnection.ClearAllPools(); if (File.Exists(ruta)) File.Delete(ruta); }
    }

    private static string ClaveFila(PaqueteNube.Tabla tabla, List<PaqueteNube.Celda> fila, Dictionary<string, List<string>> claves)
    {
        var columnas = claves.TryGetValue(tabla.Nombre, out var conocidas) && conocidas.Count > 0 ? conocidas : tabla.Columnas;
        return JsonSerializer.Serialize(columnas.Select(x =>
        {
            int i = tabla.Columnas.FindIndex(y => y.Equals(x, StringComparison.OrdinalIgnoreCase));
            if (i < 0 || i >= fila.Count) throw new InvalidDataException("Una dependencia no contiene su identidad completa.");
            return new[] { fila[i].Tipo, fila[i].Valor };
        }).ToList(), Json);
    }

    private static HashSet<string> ReferenciasTablas(IReadOnlyList<PaqueteNube.Tabla> tablas)
    {
        var referencias = new HashSet<string>(StringComparer.Ordinal);
        void Recorrer(JsonNode? nodo)
        {
            if (nodo is JsonValue valor && valor.TryGetValue<string>(out var texto))
            {
                referencias.Add(texto);
                if (!string.IsNullOrWhiteSpace(texto) && (texto.TrimStart().StartsWith('{') || texto.TrimStart().StartsWith('[')))
                    try { Recorrer(JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 })); } catch (JsonException) { }
            }
            else if (nodo is JsonObject objeto) foreach (var campo in objeto) Recorrer(campo.Value);
            else if (nodo is JsonArray lista) foreach (var hijo in lista) Recorrer(hijo);
        }
        Recorrer(JsonSerializer.SerializeToNode(tablas, Json)); return referencias;
    }

    private static string FirmarFilaCatalogo(PaqueteNube.Tabla tabla, List<PaqueteNube.Celda> fila, IReadOnlyList<PaqueteNube.Recurso> recursos)
    {
        if (fila.Count != tabla.Columnas.Count) throw new InvalidDataException("Una dependencia tiene columnas incompletas.");
        var hashes = recursos.GroupBy(x => x.Referencia, StringComparer.Ordinal).ToDictionary(x => x.Key, x => x.Last().Sha256.ToUpperInvariant(), StringComparer.Ordinal);
        object? Canonizar(JsonNode? nodo)
        {
            if (nodo is JsonObject objeto)
            {
                var campos = new SortedDictionary<string, object?>(StringComparer.Ordinal);
                foreach (var campo in objeto)
                {
                    if (campo.Key.Equals("RutaSQLite", StringComparison.OrdinalIgnoreCase) || campo.Key.Equals("FuenteCatalogoRuta", StringComparison.OrdinalIgnoreCase)
                        || campo.Key.Equals("CatalogoMYGRuta", StringComparison.OrdinalIgnoreCase) || campo.Key.Equals("ModificadoUtc", StringComparison.OrdinalIgnoreCase)
                        || campo.Key.Equals("PresupuestoActivoId", StringComparison.OrdinalIgnoreCase)) continue;
                    campos[campo.Key] = Canonizar(campo.Value);
                }
                return campos;
            }
            if (nodo is JsonArray lista) return lista.Select(Canonizar).ToArray();
            if (nodo is JsonValue valor && valor.TryGetValue<string>(out var texto) && hashes.TryGetValue(texto, out var hash)) return "SHA256:" + hash;
            return nodo?.Deserialize<JsonElement>(Json);
        }
        var valores = new SortedDictionary<string, object?>(StringComparer.Ordinal);
        for (int i = 0; i < tabla.Columnas.Count; i++)
        {
            if (tabla.Columnas[i].Equals("modificado_utc", StringComparison.OrdinalIgnoreCase)) continue;
            object? valor = fila[i].Valor;
            if (fila[i].Tipo == "texto" && fila[i].Valor is { } texto)
            {
                if (hashes.TryGetValue(texto, out var hash)) valor = "SHA256:" + hash;
                else if (texto.TrimStart().StartsWith('{') || texto.TrimStart().StartsWith('['))
                    try { valor = Canonizar(JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 })); } catch (JsonException) { }
            }
            valores[tabla.Columnas[i].ToLowerInvariant()] = new object?[] { fila[i].Tipo, valor };
        }
        return JsonSerializer.Serialize(valores, Json);
    }

    private static void ExigirCatalogoConservado(JsonElement esperado, JsonElement actual)
    {
        var tablas = actual.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!.ToDictionary(x => x.Nombre, StringComparer.OrdinalIgnoreCase);
        var recursosActuales = actual.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>(Json)!;
        var recursosEsperados = esperado.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>(Json)!;
        foreach (var original in esperado.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!)
        {
            if (original.Filas.Count == 0) continue;
            if (!tablas.TryGetValue(original.Nombre, out var reconstruida)) throw new InvalidDataException("No se conservó la tabla del catálogo '" + original.Nombre + "'.");
            var firmas = reconstruida.Filas.Select(x => FirmarFilaCatalogo(reconstruida, x, recursosActuales)).ToHashSet(StringComparer.Ordinal);
            if (original.Filas.Any(x => !firmas.Contains(FirmarFilaCatalogo(original, x, recursosEsperados))))
                throw new InvalidDataException("El catálogo de la base no pudo reconstruirse íntegramente en la tabla '" + original.Nombre + "'. No se sustituirá la copia local.");
        }
    }

    private static void AplicarCatalogoInicial(string ruta, JsonElement catalogo)
    {
        if (MYGBaseDatos.ListarProyectos(ruta).Count != 0)
            throw new InvalidOperationException("Los catálogos completos solo se aplican durante una descarga nueva de la base del propietario.");
        var tablas = catalogo.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)
            ?? throw new InvalidDataException("El catálogo central no contiene tablas compatibles.");
        var recursos = catalogo.GetProperty("recursos").Deserialize<List<PaqueteNube.Recurso>>(Json)
            ?? throw new InvalidDataException("Los recursos del catálogo central no son válidos.");
        var reemplazos = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var recurso in recursos)
        {
            if (!string.IsNullOrWhiteSpace(recurso.Almacen)) throw new InvalidDataException("El catálogo no puede depender de un almacén externo.");
            byte[] bytes;
            try { bytes = Convert.FromBase64String(recurso.Base64); } catch (FormatException e) { throw new InvalidDataException("Un adjunto del catálogo no es válido.", e); }
            string hash = Convert.ToHexString(SHA256.HashData(bytes));
            if (!hash.Equals(recurso.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("La integridad de un adjunto del catálogo no coincide.");
            string extension = Path.GetExtension(recurso.Nombre);
            if (extension.Length is < 2 or > 11 || extension.Skip(1).Any(x => !char.IsAsciiLetterOrDigit(x))) extension = ".bin";
            string carpeta = Path.Combine(Path.GetDirectoryName(ruta)!, Path.GetFileNameWithoutExtension(ruta) + ".recursos");
            Directory.CreateDirectory(carpeta); string destino = Path.Combine(carpeta, hash + extension);
            if (File.Exists(destino))
            {
                if (!Hash(destino).Equals(hash, StringComparison.OrdinalIgnoreCase)) throw new IOException("Ya existe un adjunto diferente en el destino del catálogo.");
            }
            else EscribirNuevo(destino, bytes);
            if (!reemplazos.TryAdd(recurso.Referencia, destino)) throw new InvalidDataException("Un adjunto del catálogo tiene referencias duplicadas.");
        }
        void Reubicar(JsonNode? nodo)
        {
            if (nodo is JsonObject objeto)
                foreach (var campo in objeto.ToList())
                {
                    if (campo.Value is JsonValue valor && valor.TryGetValue<string>(out var texto))
                    {
                        if (reemplazos.TryGetValue(texto, out var adjunto)) objeto[campo.Key] = adjunto;
                        else if (texto == ArchivoPublicacionSqlitePendiente.ReferenciaPropia
                            && campo.Key is "RutaSQLite" or "FuenteCatalogoRuta" or "CatalogoMYGRuta") objeto[campo.Key] = ruta;
                    }
                    else Reubicar(campo.Value);
                }
            else if (nodo is JsonArray lista) foreach (var hijo in lista) Reubicar(hijo);
        }
        using var c = Abrir(ruta, false); using var t = c.BeginTransaction();
        // Todas las tablas se reconstruyen en una única transacción sobre un
        // esquema de Core. Diferir referencias evita depender del orden alfabético
        // cuando, por ejemplo, detalle_planilla aparece antes de planilla.
        using (var diferir = c.CreateCommand())
        { diferir.Transaction = t; diferir.CommandText = "PRAGMA defer_foreign_keys=ON"; diferir.ExecuteNonQuery(); }
        using (var opcional = c.CreateCommand())
        {
            opcional.Transaction = t;
            opcional.CommandText = "CREATE TABLE IF NOT EXISTS myg_indice_unificado(codigo TEXT PRIMARY KEY COLLATE NOCASE,descripcion TEXT NOT NULL,periodo_base TEXT NOT NULL,resolucion TEXT NOT NULL,orden INTEGER NOT NULL)";
            opcional.ExecuteNonQuery();
        }
        var esquema = LeerEsquema(c);
        var vistas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var tabla in tablas)
        {
            if (!Compartidas.Contains(tabla.Nombre) || !vistas.Add(tabla.Nombre) || !esquema.TryGetValue(tabla.Nombre, out var columnas)
                || tabla.Columnas.Count == 0 || tabla.Columnas.Distinct(StringComparer.OrdinalIgnoreCase).Count() != tabla.Columnas.Count
                || tabla.Columnas.Any(x => !columnas.Contains(x)) || tabla.Filas.Any(x => x.Count != tabla.Columnas.Count))
                throw new InvalidDataException("El catálogo central contiene una tabla o columna no compatible con el esquema instalado.");
            using var borrar = c.CreateCommand(); borrar.Transaction = t; borrar.CommandText = "DELETE FROM " + Identificador(tabla.Nombre); borrar.ExecuteNonQuery();
            using var insertar = c.CreateCommand(); insertar.Transaction = t;
            insertar.CommandText = "INSERT INTO " + Identificador(tabla.Nombre) + "(" + string.Join(",", tabla.Columnas.Select(Identificador))
                + ") VALUES(" + string.Join(",", Enumerable.Range(0, tabla.Columnas.Count).Select(x => "$p" + x)) + ")";
            for (int i = 0; i < tabla.Columnas.Count; i++) insertar.Parameters.AddWithValue("$p" + i, DBNull.Value);
            foreach (var fila in tabla.Filas)
            {
                for (int i = 0; i < fila.Count; i++)
                {
                    var celda = fila[i]; string? texto = celda.Valor;
                    if (celda.Tipo == "texto" && texto is not null)
                    {
                        if (reemplazos.TryGetValue(texto, out var adjunto)) texto = adjunto;
                        else if (tabla.Columnas[i].StartsWith("json_", StringComparison.OrdinalIgnoreCase))
                            try { var nodo = JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 }); Reubicar(nodo); texto = nodo?.ToJsonString(Json); } catch (JsonException) { }
                    }
                    insertar.Parameters[i].Value = celda.Tipo switch
                    {
                        "nulo" => DBNull.Value, "texto" => texto ?? "",
                        "entero" => long.Parse(texto!, System.Globalization.CultureInfo.InvariantCulture),
                        "real" => double.TryParse(texto, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double valor) && double.IsFinite(valor)
                            ? valor : throw new InvalidDataException("Un número del catálogo no es válido."),
                        "blob" => Convert.FromBase64String(texto!),
                        _ => throw new InvalidDataException("Un tipo de celda del catálogo no es compatible.")
                    };
                }
                insertar.ExecuteNonQuery();
            }
        }
        t.Commit();
    }

    private static void MarcarBase(string ruta, VinculoBaseCentral vinculo)
    {
        using var c = Abrir(ruta, false); using var t = c.BeginTransaction();
        using var q = c.CreateCommand(); q.Transaction = t;
        q.CommandText = "CREATE TABLE IF NOT EXISTS myg_base_central_local(id INTEGER PRIMARY KEY CHECK(id=1),base_id TEXT NOT NULL,servidor TEXT NOT NULL,usuario TEXT NOT NULL)"; q.ExecuteNonQuery();
        q.CommandText = "INSERT INTO myg_base_central_local VALUES(1,$p0,$p1,$p2) ON CONFLICT(id) DO UPDATE SET base_id=excluded.base_id,servidor=excluded.servidor,usuario=excluded.usuario";
        q.Parameters.AddWithValue("$p0", vinculo.BaseId.ToString("D")); q.Parameters.AddWithValue("$p1", vinculo.Servidor); q.Parameters.AddWithValue("$p2", vinculo.Usuario); q.ExecuteNonQuery();
        t.Commit();
    }

    private static JsonElement NormalizarContenido(JsonElement contenido)
    {
        var nodo = JsonNode.Parse(contenido.GetRawText(), documentOptions: new JsonDocumentOptions { MaxDepth = 128 })!;
        NormalizarNodo(nodo);
        return JsonSerializer.SerializeToElement(nodo, Json);
    }

    private static void NormalizarNodo(JsonNode? nodo)
    {
        if (nodo is JsonObject objeto)
        {
            foreach (var campo in objeto.ToList())
            {
                if (campo.Key is "RutaSQLite" or "FuenteCatalogoRuta" or "CatalogoMYGRuta"
                    && campo.Value is JsonValue valor && valor.TryGetValue<string>(out var ruta) && !string.IsNullOrWhiteSpace(ruta))
                    objeto[campo.Key] = ArchivoPublicacionSqlitePendiente.ReferenciaPropia;
                else NormalizarNodo(campo.Value);
            }
            // Las tablas portables guardan documentos JSON dentro de celdas.
            if (objeto["Tipo"] is JsonValue tipo && tipo.TryGetValue<string>(out var tipoTexto) && tipoTexto == "texto" && objeto["Valor"] is JsonValue celda
                && celda.TryGetValue<string>(out var texto) && !string.IsNullOrWhiteSpace(texto) && texto.TrimStart().StartsWith('{'))
            {
                try { var json = JsonNode.Parse(texto, documentOptions: new JsonDocumentOptions { MaxDepth = 128 }); NormalizarNodo(json); objeto["Valor"] = json?.ToJsonString(Json); }
                catch (JsonException) { }
            }
        }
        else if (nodo is JsonArray lista) foreach (var hijo in lista) NormalizarNodo(hijo);
    }

    private static void ReubicarRutas(MYGProyectoDocumento documento, string origen, string destino)
    {
        var nodo = JsonNode.Parse(MYGColaboracionLocal.ExportarDocumento(documento), documentOptions: new JsonDocumentOptions { MaxDepth = 128 })!;
        void Recorrer(JsonNode? actual)
        {
            if (actual is JsonObject objeto)
                foreach (var campo in objeto.ToList())
                {
                    if (campo.Key is "RutaSQLite" or "FuenteCatalogoRuta" or "CatalogoMYGRuta"
                        && campo.Value is JsonValue valor && valor.TryGetValue<string>(out var ruta) && ruta == origen)
                        objeto[campo.Key] = destino;
                    else Recorrer(campo.Value);
                }
            else if (actual is JsonArray lista) foreach (var hijo in lista) Recorrer(hijo);
        }
        Recorrer(nodo);
        var reubicado = MYGColaboracionLocal.ImportarDocumento(nodo.ToJsonString(Json));
        // La copia de un documento es profunda; conservar la identidad del objeto
        // mediante el serializador evita un catálogo completo de setters nuevos.
        documento.FuenteCatalogo = reubicado.FuenteCatalogo;
        documento.Presupuestos = reubicado.Presupuestos;
    }

    private static SqliteConnection Abrir(string ruta, bool lectura)
    {
        var c = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = Path.GetFullPath(ruta), Mode = lectura ? SqliteOpenMode.ReadOnly : SqliteOpenMode.ReadWrite, Pooling = false, ForeignKeys = false }.ToString());
        c.Open(); return c;
    }

    private static bool TieneTabla(SqliteConnection c, string tabla)
    {
        using var q = c.CreateCommand(); q.CommandText = "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name=$p0)"; q.Parameters.AddWithValue("$p0", tabla);
        return Convert.ToInt64(q.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) != 0;
    }

    private static Dictionary<string, HashSet<string>> LeerEsquema(SqliteConnection c)
    {
        var nombres = new List<string>();
        using (var q = c.CreateCommand())
        { q.CommandText = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"; using var r = q.ExecuteReader(); while (r.Read()) nombres.Add(r.GetString(0)); }
        var tablas = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
        foreach (string nombre in nombres)
        {
            using var q = c.CreateCommand(); q.CommandText = "PRAGMA table_info(" + Identificador(nombre) + ")"; using var r = q.ExecuteReader();
            var columnas = new HashSet<string>(StringComparer.OrdinalIgnoreCase); while (r.Read()) columnas.Add(r.GetString(1)); tablas[nombre] = columnas;
        }
        return tablas;
    }

    private static string Hash(string ruta) { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    private static string Identificador(string valor) => "\"" + valor.Replace("\"", "\"\"") + "\"";
    private static void EscribirNuevo(string ruta, byte[] contenido)
    {
        using var f = new FileStream(ruta, FileMode.CreateNew, FileAccess.Write, FileShare.Read); f.Write(contenido); f.Flush(true);
    }
}
