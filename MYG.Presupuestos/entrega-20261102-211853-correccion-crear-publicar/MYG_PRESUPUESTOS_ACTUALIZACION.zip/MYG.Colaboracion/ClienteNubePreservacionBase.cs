#nullable enable
using System.Text.Json;

namespace MYG.Colaboracion;

public sealed partial class ClienteSupabase
{
    private bool preservacionBaseComprobada;
    // Lista procedente del esquema confiable Delphin2024.sql de Core. Los
    // nombres y columnas recibidos nunca se convierten en DDL remoto.
    private static readonly IReadOnlyDictionary<string, string[]> ColumnasPreservacionBase =
        new Dictionary<string, string[]>(StringComparer.Ordinal)
        {
            ["cargo"] = ["id_cargo", "descripcion_cargo", "id_tipopersona"],
            ["clase_gl"] = ["id_clase", "codigo_clase", "nombre_clase"],
            ["concepto"] = ["id_concepto", "id_cuenta", "descripcion_concepto", "estado_concepto", "tipo_concepto", "codigo_cuenta", "id_cuentagl", "id_subcuenta", "info_concepto", "id_conceptoextorno", "es_extorno", "id_extension", "id_documentos", "tipo_afectar", "id_conceptocargo", "agrega_cuenta", "imprimir_logo", "formula", "permite_suma", "es_planilla", "orden", "clave_concepto", "es_afp"],
            ["costo_partida"] = ["id_costopartida", "descripcion_costo", "id_unidad", "id_partida", "numeracion_costo", "posicion_costo", "id_analisiscosto"],
            ["cuenta"] = ["id_cuenta", "descripcion_cuenta", "estado_cuenta", "orden"],
            ["cuenta_caja"] = ["id_caja", "descripcion_caja", "id_tipocaja", "id_cuenta", "id_subcuenta", "id_sucursal", "id_moneda", "id_documentofact", "formato_ticket", "id_documentovta", "serie_impresora", "formato_fact"],
            ["cuenta_gl"] = ["id_cuenta", "codigo_cuenta", "nombre_cuenta", "id_cuentapadre", "id_clase", "orden"],
            ["cuenta_gl_temp"] = ["id_cuenta", "codigo_cuenta", "nombre_cuenta", "id_cuentapadre", "id_clase", "orden"],
            ["detalle_planilla"] = ["id_detalleplanilla", "id_concepto", "total_detalle", "id_planilla", "estado_detalle", "formula", "estado_cargado", "id_documento", "numero_documento", "serie_documento", "fecha_documento", "tipo_concepto", "tiene_items"],
            ["diccionario"] = ["id_elemento", "descripcion_elemento", "codigo_clase", "nota"],
            ["documento"] = ["id_documento", "descripcion_documento", "modulo", "estado_documento", "genera_impuesto", "generar_numero", "codigo_documento", "omite_serie", "long_maxima", "id_documentosecuencia"],
            ["documento_identidad"] = ["id_documento", "descripcion_documento", "codigo_documento", "long_maxima", "long_minima"],
            ["estado_civil"] = ["id_estadocivil", "descripcion_estadocivil"],
            ["formato_documento"] = ["id_formato", "id_documento", "id_sucursal", "maximo_items", "cols_series"],
            ["forma_pago"] = ["id_formapago", "descripcion_formapago", "verifica_persona", "agrega_cuenta"],
            ["hoja_planilla"] = ["id_hoja", "mes_planilla", "anio_planilla", "numero_planilla", "fecha_inicio", "fecha_cierre", "observacion", "estado_hoja", "id_proyecto"],
            ["modalidad_map"] = ["id_modalidadmap", "id_modalidad", "id_concepto", "permitido"],
            ["modalidad_pago"] = ["id_modalidadpago", "descripcion_modalidadpago", "tipo_cuenta", "documentos_ingreso", "documentos_egreso", "orden"],
            ["motivo"] = ["id_motivo", "descripcion_motivo", "afecta_kardex", "solo_empresa", "verifica_destino", "permitir_proveedor", "estado_motivo", "requiere_persona", "permitir_empresa", "codigo_motivo", "requiere_responsable", "requiere_liquidacion", "afecta_fisico", "codigo_sunat", "tipo_motivo", "requiere_proyecto"],
            ["partida"] = ["id_partida", "descripcion_partida", "id_plantilla", "id_titulopadre", "posicion_titulo", "estado_bloqueado", "estado_expandido", "numeracion_titulo"],
            ["persona"] = ["id_persona", "clase_persona", "nombre_persona", "apellidos_persona", "fecha_nacimiento", "profesion", "estado_civil", "sexo", "id_supervisor", "direccion", "telefono", "lugar_trabajo", "direccion_trabajo", "telefono_trabajo", "movil", "dni", "ruc", "email", "email_alternativo", "sitio_web", "id_tipopersona", "id_institucion", "id_cargo", "descripcion_cargo", "estado_persona", "id_sucursal", "id_sucursallabora", "moneda_facturacion", "fecha_registro", "id_usuarioregistro", "fecha_modificacion", "id_usuariomodificacion", "fecha_anulacion", "id_usuarioanulacion", "id_supervisornegocios", "en_planilla", "fecha_planilla", "id_tipopersonacomision", "id_distrito", "id_localidad", "nombre_comercial", "tipo_afp", "imagen", "version", "cuenta_soles", "banco_soles", "moneda_soles", "cuenta_dolares", "banco_dolares", "moneda_dolares", "date_version", "telefono_anexo", "tipo_comision", "color_fuente", "nombre_fuente", "estilo_fuente", "tamano_fuente", "color_fondo", "check_mostrar", "imagen2"],
            ["planilla"] = ["id_planilla", "id_hoja", "id_persona", "id_documento", "serie_documento", "numero_documento", "fecha_documento", "observacion", "estado_registro", "fecha_registro", "id_usuario", "fecha_anulacion", "id_usuarioanulacion", "total_ingreso", "total_egreso", "total_aportacion", "monto_neto", "monto_pagado", "estado_pagado", "fecha_pago", "id_moneda", "estado_cargado", "fecha_cargo", "fecha_modificacion", "id_usuariomodificacion", "porcentaje_fondo", "porcentaje_seguro", "porcentaje_flujo", "porcentaje_mixta"],
            ["plantilla_clasificador"] = ["id_plantilla", "nombre_plantilla", "es_predeterminada", "anio"],
            ["plantilla_gasto"] = ["id_plantilla", "nombre_plantilla", "estado_expandido", "posicion_plantilla", "numeracion_plantilla", "id_unidadduracion", "modalidad_ejecucion"],
            ["secuencia"] = ["nombre_secuencia", "ultimo_numero"],
            ["secuencia_documento"] = ["id_secuencia", "id_documento", "id_ubicacion", "serie_actual", "ultimo_numero", "id_sucursal", "id_empresa"],
            ["sucursal"] = ["id_sucursal", "nombre_sucursal", "id_distrito", "direccion_sucursal", "telefono_sucursal", "telefono_alternativo", "es_oficinacentral", "es_domiciliofiscal", "id_persona", "id_sucursalcentral", "estado_sucursal", "codigo_sunat", "id_sucursalstock1", "id_sucursalstock2", "id_sucursalstock3", "id_documentosalida", "id_documentovta", "id_documentofact", "tipo_unidad", "id_proyecto", "id_template"],
            ["tipo_afp"] = ["tipo_afp", "descripcion_tipo", "estado_vigente", "porcentaje_fondo", "porcentaje_seguro", "porcentaje_flujo", "porcentaje_mixta"],
            ["tipo_asiento"] = ["id_tipo", "descripcion_tipo", "tipo_emisor", "orden"],
            ["tipo_caja"] = ["id_tipocaja", "descripcion_tipo", "id_modingreso", "id_modegreso", "es_xcobrar", "afecta_caja"],
            ["tipo_concepto"] = ["tipo_concepto", "descripcion_tipo", "estado_vigente", "orden"],
            ["tipo_persona"] = ["id_tipopersona", "descripcion_tipopersona", "clase_persona", "permitir_venta", "cuenta_predeterminada", "es_empleado", "permite_alias", "mismo_grupo", "date_version", "categorias", "es_sistema"],
            ["titulo"] = ["id_titulo", "descripcion_titulo", "id_titulopadre", "posicion_titulo", "nivel_titulo", "id_presupuesto", "estado_expandido", "numeracion_titulo", "costo_titulo", "id_responsable", "numeracion_norma", "color_fuente", "nombre_fuente", "estilo_fuente", "tamano_fuente", "duracion", "fecha_inicio", "fecha_fin", "es_hito", "porcentaje_completado", "color_fondo", "duracion_new"],
            ["titulo_clasificador"] = ["id_titulo", "descripcion_titulo", "id_plantilla", "id_titulopadre", "posicion_titulo", "estado_bloqueado", "estado_expandido", "numeracion_titulo", "informacion_titulo"],
            ["titulo_indice"] = ["id_titulo", "descripcion_titulo", "id_titulopadre", "posicion_titulo", "nivel_titulo", "id_presupuesto", "estado_expandido", "coeficiente", "porcentaje", "nomenclatura", "codigo_clase", "es_indice", "custom_control", "coeficientedefinido"],
        };

    private static readonly IReadOnlyDictionary<string, string[]> ClavesPreservacionBase =
        new Dictionary<string, string[]>(StringComparer.Ordinal)
        {
            ["cargo"] = ["id_cargo"],
            ["clase_gl"] = ["id_clase"],
            ["concepto"] = ["id_concepto"],
            ["costo_partida"] = ["id_costopartida"],
            ["cuenta"] = ["id_cuenta"],
            ["cuenta_caja"] = ["id_caja"],
            ["cuenta_gl"] = ["id_cuenta"],
            ["cuenta_gl_temp"] = ["id_cuenta"],
            ["detalle_planilla"] = ["id_detalleplanilla"],
            ["diccionario"] = ["id_elemento"],
            ["documento"] = ["id_documento"],
            ["documento_identidad"] = ["id_documento"],
            ["estado_civil"] = ["id_estadocivil"],
            ["formato_documento"] = ["id_formato"],
            ["forma_pago"] = ["id_formapago"],
            ["hoja_planilla"] = ["id_hoja"],
            ["modalidad_map"] = ["id_modalidadmap"],
            ["modalidad_pago"] = ["id_modalidadpago"],
            ["motivo"] = ["id_motivo"],
            ["partida"] = ["id_partida"],
            ["persona"] = ["id_persona"],
            ["planilla"] = ["id_planilla"],
            ["plantilla_clasificador"] = ["id_plantilla"],
            ["plantilla_gasto"] = ["id_plantilla"],
            ["secuencia"] = ["nombre_secuencia"],
            ["secuencia_documento"] = ["id_secuencia"],
            ["sucursal"] = ["id_sucursal"],
            ["tipo_afp"] = ["tipo_afp"],
            ["tipo_asiento"] = ["id_tipo"],
            ["tipo_caja"] = ["id_tipocaja"],
            ["tipo_concepto"] = ["tipo_concepto"],
            ["tipo_persona"] = ["id_tipopersona"],
            ["titulo"] = ["id_titulo"],
            ["titulo_clasificador"] = ["id_titulo"],
            ["titulo_indice"] = ["id_titulo"],
        };

    /// <summary>Comprueba antes de crear o preparar una base que el servidor
    /// puede conservar sus tablas adicionales reservadas al propietario.</summary>
    public async Task ComprobarPreservacionBaseAsync(JsonElement catalogo, CancellationToken ct = default)
    {
        ValidarCatalogoCentral(catalogo);
        if (!catalogo.GetProperty("tablas").EnumerateArray().Any(t =>
            ColumnasPreservacionBase.ContainsKey(t.GetProperty("Nombre").GetString()!))) return;
        if (preservacionBaseComprobada) return;
        try
        {
            string usuario = await IdentidadArchivosAsync(ct);
            await EjecutarRpcNubeAsync("myg_central_preservacion_capacidades", new { }, raiz =>
            {
                if (raiz.ValueKind != JsonValueKind.Object
                    || !raiz.TryGetProperty("version", out var v) || v.ValueKind != JsonValueKind.Number
                    || !v.TryGetInt32(out int version) || version != 1
                    || !raiz.TryGetProperty("tablas_adicionales", out var tablas)
                    || tablas.ValueKind != JsonValueKind.Array) throw RespuestaNubeInvalida();
                var nombres = new HashSet<string>(StringComparer.Ordinal);
                foreach (var tabla in tablas.EnumerateArray())
                    if (tabla.ValueKind != JsonValueKind.String || !TextoEntradaValido(tabla.GetString()!, 200)
                        || !nombres.Add(tabla.GetString()!)) throw RespuestaNubeInvalida();
                if (!ColumnasPreservacionBase.Keys.All(nombres.Contains))
                    throw new NubeException("El servidor todavía no admite todos los datos adicionales de esta base. Ejecute completa 20261107_preservacion_base.sql en Supabase y vuelva a intentar. La base original se conserva.",
                        codigo: "MYG_PRESERVACION_NO_INSTALADA");
                return true;
            }, ct, identidadEsperada: usuario);
            preservacionBaseComprobada = true;
        }
        catch (NubeException ex) when (ex.Codigo is "PGRST202" or "42883")
        {
            throw new NubeException("Ejecute completa 20261107_preservacion_base.sql en Supabase para conservar los datos adicionales de esta base. La base original se conserva; no se inició su publicación.",
                codigo: "MYG_PRESERVACION_NO_INSTALADA");
        }
    }
}
