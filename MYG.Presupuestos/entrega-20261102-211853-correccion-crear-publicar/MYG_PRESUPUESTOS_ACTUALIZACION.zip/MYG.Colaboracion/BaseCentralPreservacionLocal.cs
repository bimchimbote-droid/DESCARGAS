using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace MYG.Colaboracion;

public static partial class BaseCentralNube
{
    private const string TablaPreservacionLocal = "myg_base_preservacion_local";
    private const string PrefijoTriggerPreservacion = "myg_preservar_";
    private const string MensajePreservacionLocal = "La obra intenta cambiar datos privados originales de la base. Se conservan esos datos; use otra identidad para la nueva fila.";

    /// <summary>Protege únicamente las filas residuales del propietario. Las
    /// filas operativas representadas por los paquetes de obra quedan fuera.</summary>
    private static void InstalarPreservacionLocal(string ruta, JsonElement catalogo)
    {
        var tablas = catalogo.GetProperty("tablas").Deserialize<List<PaqueteNube.Tabla>>(Json)!
            .Where(x => AdicionalesPropietario.Contains(x.Nombre) && x.Filas.Count > 0).ToList();
        using var c = Abrir(ruta, false);
        bool existe = TieneTabla(c, TablaPreservacionLocal);
        if (!existe && tablas.Count == 0) return;
        ValidarPreservacionLocal(c);
        var claves = LeerClavesConfiables();
        using var t = c.BeginTransaction();
        using (var crear = c.CreateCommand())
        {
            crear.Transaction = t;
            crear.CommandText = "CREATE TABLE IF NOT EXISTS myg_base_preservacion_local(tabla TEXT NOT NULL,clave_json TEXT NOT NULL,PRIMARY KEY(tabla,clave_json))";
            crear.ExecuteNonQuery();
        }
        foreach (var tabla in tablas)
        {
            if (!claves.TryGetValue(tabla.Nombre, out var pk) || pk.Count == 0)
                throw new InvalidDataException("Los datos privados originales no tienen una identidad estable en '" + tabla.Nombre + "'.");
            var indices = pk.Select(nombre => tabla.Columnas.FindIndex(x => x.Equals(nombre, StringComparison.OrdinalIgnoreCase))).ToArray();
            if (indices.Any(i => i < 0)) throw new InvalidDataException("Una fila privada no conserva su clave completa.");
            using var buscar = c.CreateCommand(); buscar.Transaction = t;
            buscar.CommandText = "SELECT json_array(" + string.Join(",", pk.Select(Identificador)) + ") FROM " + Identificador(tabla.Nombre)
                + " WHERE " + string.Join(" AND ", pk.Select((nombre, i) => Identificador(nombre) + " IS $p" + i));
            for (int i = 0; i < indices.Length; i++) buscar.Parameters.AddWithValue("$p" + i, DBNull.Value);
            using var guardar = c.CreateCommand(); guardar.Transaction = t;
            guardar.CommandText = "INSERT OR IGNORE INTO myg_base_preservacion_local(tabla,clave_json) VALUES($tabla,$clave)";
            guardar.Parameters.AddWithValue("$tabla", tabla.Nombre.ToLowerInvariant()); guardar.Parameters.AddWithValue("$clave", "");
            foreach (var fila in tabla.Filas)
            {
                for (int i = 0; i < indices.Length; i++) buscar.Parameters[i].Value = ValorClavePreservacion(fila[indices[i]]);
                string identidad;
                using (var r = buscar.ExecuteReader())
                {
                    if (!r.Read()) throw new InvalidDataException("La fila privada no está presente en la base reconstruida: " + tabla.Nombre + ".");
                    identidad = r.GetString(0);
                    if (r.Read()) throw new InvalidDataException("Hay filas privadas sin una identidad única en '" + tabla.Nombre + "'.");
                }
                guardar.Parameters["$clave"].Value = identidad; guardar.ExecuteNonQuery();
            }
        }
        foreach (string nombre in AdicionalesPropietario.OrderBy(x => x, StringComparer.Ordinal))
        {
            var columnas = LeerColumnasPreservacion(c, t, nombre);
            foreach (var trigger in CrearTriggersPreservacion(nombre, claves[nombre], columnas))
            {
                using var q = c.CreateCommand(); q.Transaction = t; q.CommandText = trigger.Sql; q.ExecuteNonQuery();
            }
        }
        t.Commit();
    }

    private static object ValorClavePreservacion(PaqueteNube.Celda celda) => celda.Tipo switch
    {
        "nulo" => DBNull.Value,
        "texto" => celda.Valor ?? "",
        "entero" => long.Parse(celda.Valor!, System.Globalization.CultureInfo.InvariantCulture),
        "real" => double.TryParse(celda.Valor, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double numero)
            && double.IsFinite(numero) ? numero : throw new InvalidDataException("La clave privada contiene un número inválido."),
        _ => throw new InvalidDataException("El tipo de la clave privada no es compatible.")
    };

    private static List<string> LeerColumnasPreservacion(SqliteConnection c, SqliteTransaction? t, string nombre)
    {
        using var q = c.CreateCommand(); q.Transaction = t; q.CommandText = "PRAGMA table_info(" + Identificador(nombre) + ")";
        using var r = q.ExecuteReader(); var columnas = new List<string>(); while (r.Read()) columnas.Add(r.GetString(1));
        if (columnas.Count == 0) throw new InvalidDataException("No está instalado el esquema nativo de preservación: " + nombre + ".");
        return columnas;
    }

    private static IReadOnlyList<(string Nombre, string Sql)> CrearTriggersPreservacion(string tabla, List<string> pk, List<string> columnas)
    {
        string Tabla = Identificador(tabla);
        string Nombre(string accion) => PrefijoTriggerPreservacion + tabla.ToLowerInvariant() + "_" + accion;
        string Key(string alias) => "json_array(" + string.Join(",", pk.Select(p => alias + "." + Identificador(p))) + ")";
        string ActualProtegida(string alias) => "EXISTS(SELECT 1 FROM myg_base_preservacion_local AS m WHERE m.tabla='" + tabla.ToLowerInvariant()
            + "' AND m.clave_json=" + Key(alias) + ")";
        // Buscar el registro real con las comparaciones de su PK protege también
        // colaciones NOCASE; no se compara una clave NEW escrita por el llamador
        // con texto JSON sensible a mayúsculas que pudiera evitar la guarda.
        string DestinoProtegido = "EXISTS(SELECT 1 FROM " + Tabla + " AS p JOIN myg_base_preservacion_local AS m ON m.tabla='"
            + tabla.ToLowerInvariant() + "' AND m.clave_json=" + Key("p") + " WHERE "
            + string.Join(" AND ", pk.Select(p => "p." + Identificador(p) + " IS NEW." + Identificador(p))) + ")";
        string IgualActual = "EXISTS(SELECT 1 FROM " + Tabla + " AS p WHERE "
            + string.Join(" AND ", pk.Select(p => "p." + Identificador(p) + " IS NEW." + Identificador(p))) + " AND "
            + string.Join(" AND ", columnas.Select(p => "p." + Identificador(p) + " IS NEW." + Identificador(p) + " COLLATE BINARY")) + ")";
        string Cambia = string.Join(" OR ", columnas.Select(p => "OLD." + Identificador(p) + " IS NOT NEW." + Identificador(p) + " COLLATE BINARY"));
        return new[]
        {
            (Nombre("insertar"), "CREATE TRIGGER IF NOT EXISTS " + Identificador(Nombre("insertar")) + " BEFORE INSERT ON " + Tabla
                + " WHEN " + DestinoProtegido + " BEGIN SELECT CASE WHEN " + IgualActual
                + " THEN RAISE(IGNORE) ELSE RAISE(ABORT,'" + MensajePreservacionLocal + "') END; END"),
            (Nombre("actualizar"), "CREATE TRIGGER IF NOT EXISTS " + Identificador(Nombre("actualizar")) + " BEFORE UPDATE ON " + Tabla
                + " WHEN (" + ActualProtegida("OLD") + " OR " + DestinoProtegido + ") AND (" + Cambia
                + ") BEGIN SELECT RAISE(ABORT,'" + MensajePreservacionLocal + "'); END"),
            (Nombre("borrar"), "CREATE TRIGGER IF NOT EXISTS " + Identificador(Nombre("borrar")) + " BEFORE DELETE ON " + Tabla
                + " WHEN " + ActualProtegida("OLD") + " BEGIN SELECT RAISE(ABORT,'" + MensajePreservacionLocal + "'); END")
        };
    }

    private static void ValidarPreservacionLocal(SqliteConnection c)
    {
        var reservados = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using (var q = c.CreateCommand())
        {
            q.CommandText = "SELECT name,sql FROM sqlite_master WHERE type='trigger' AND name GLOB 'myg_preservar_*'";
            using var r = q.ExecuteReader(); while (r.Read()) reservados[r.GetString(0)] = r.GetString(1);
        }
        if (!TieneTabla(c, TablaPreservacionLocal))
        {
            if (reservados.Count != 0) throw new InvalidDataException("La base contiene una preservación local incompleta. Conserve esta copia.");
            return;
        }
        var columnas = LeerColumnasPreservacion(c, null, TablaPreservacionLocal);
        if (columnas.Count != 2 || columnas[0] != "tabla" || columnas[1] != "clave_json")
            throw new InvalidDataException("El nombre reservado de preservación pertenece a otro esquema. No se modificó esa tabla.");
        using (var q = c.CreateCommand())
        {
            q.CommandText = "PRAGMA table_info(myg_base_preservacion_local)"; using var r = q.ExecuteReader();
            while (r.Read()) if (r.GetString(2) != "TEXT" || r.GetInt32(3) != 1 || r.GetInt32(5) != r.GetInt32(0) + 1)
                throw new InvalidDataException("La tabla de preservación local no tiene su esquema instalado.");
        }
        var claves = LeerClavesConfiables();
        var esperados = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (string nombre in AdicionalesPropietario)
            foreach (var trigger in CrearTriggersPreservacion(nombre, claves[nombre], LeerColumnasPreservacion(c, null, nombre)))
                esperados[trigger.Nombre] = trigger.Sql;
        string Normalizar(string sql) => sql.Replace("IF NOT EXISTS ", "", StringComparison.OrdinalIgnoreCase).Trim().TrimEnd(';');
        if (reservados.Count != esperados.Count || esperados.Any(e => !reservados.TryGetValue(e.Key, out var sql)
            || Normalizar(sql) != Normalizar(e.Value)))
            throw new InvalidDataException("Las guardas de preservación local cambiaron o están incompletas. Conserve esta copia antes de continuar.");
        var registros = new List<(string Tabla, string Clave)>();
        using (var q = c.CreateCommand())
        {
            q.CommandText = "SELECT tabla,clave_json FROM myg_base_preservacion_local";
            using var r = q.ExecuteReader();
            while (r.Read()) registros.Add((r.GetString(0), r.GetString(1)));
        }
        foreach (var registro in registros)
        {
            if (registro.Tabla != registro.Tabla.ToLowerInvariant() || !AdicionalesPropietario.Contains(registro.Tabla))
                throw new InvalidDataException("La preservación contiene una tabla no autorizada.");
            using var json = JsonDocument.Parse(registro.Clave);
            var pk = claves[registro.Tabla];
            if (json.RootElement.ValueKind != JsonValueKind.Array || json.RootElement.GetArrayLength() != pk.Count)
                throw new InvalidDataException("La preservación contiene una identidad local inválida.");
            using var buscar = c.CreateCommand();
            buscar.CommandText = "SELECT json_array(" + string.Join(",", pk.Select(Identificador)) + ") FROM " + Identificador(registro.Tabla)
                + " WHERE " + string.Join(" AND ", pk.Select((columna, i) => Identificador(columna) + " IS $p" + i));
            int indice = 0;
            foreach (var valor in json.RootElement.EnumerateArray())
            {
                object contenido = valor.ValueKind switch
                {
                    JsonValueKind.Null => DBNull.Value,
                    JsonValueKind.String => valor.GetString()!,
                    JsonValueKind.Number => valor.TryGetInt64(out long entero) ? (object)entero
                        : valor.TryGetDouble(out double real) && double.IsFinite(real) ? real
                        : throw new InvalidDataException("La preservación contiene una clave numérica inválida."),
                    _ => throw new InvalidDataException("La preservación contiene una identidad no escalar.")
                };
                buscar.Parameters.AddWithValue("$p" + indice++, contenido);
            }
            using var fila = buscar.ExecuteReader();
            if (!fila.Read() || fila.GetString(0) != registro.Clave || fila.Read())
                throw new InvalidDataException("La preservación contiene una identidad que ya no corresponde a una fila local única.");
        }
    }

    /// <summary>Se usa únicamente en la copia creada para exportar/publicar.
    /// Nunca se llama sobre el archivo de trabajo del propietario.</summary>
    internal static void RetirarProteccionDeCopia(SqliteConnection copia)
    {
        ValidarPreservacionLocal(copia);
        if (!TieneTabla(copia, TablaPreservacionLocal)) return;
        using var t = copia.BeginTransaction();
        foreach (string nombre in AdicionalesPropietario)
            foreach (string accion in new[] { "insertar", "actualizar", "borrar" })
            {
                using var q = copia.CreateCommand(); q.Transaction = t;
                q.CommandText = "DROP TRIGGER IF EXISTS " + Identificador(PrefijoTriggerPreservacion + nombre.ToLowerInvariant() + "_" + accion);
                q.ExecuteNonQuery();
            }
        using (var q = copia.CreateCommand())
        { q.Transaction = t; q.CommandText = "DROP TABLE myg_base_preservacion_local"; q.ExecuteNonQuery(); }
        t.Commit();
    }
}
