#!/usr/bin/env bash
# PostgreSQL local desechable, sin cuentas ni datos de producción.
set -euo pipefail
repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test_workspace=$(mktemp -d -t myg-preservacion-base-XXXXXXXX)
test_container=""
test_lock_pid=""
cleanup() {
    result=$?
    trap - EXIT
    if [[ -n "$test_lock_pid" ]]; then kill "$test_lock_pid" 2>/dev/null || true; wait "$test_lock_pid" 2>/dev/null || true; fi
    if [[ -n "$test_container" ]]; then docker rm -f "$test_container" >/dev/null 2>&1 || true; fi
    rm -rf -- "$test_workspace"
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
export DOCKER_HOST=unix:///var/run/docker.sock
docker info --format '{{.ServerVersion}}'
postgres_test_image='postgres:17@sha256:a63c1ea3f6a3a5a1621f97d2aba3b30faecfab4224c1b0000cc85ced57bb1939'
if ! docker image inspect "$postgres_test_image" >/dev/null 2>&1; then docker pull "$postgres_test_image"; fi
dotnet run --project "$repo_root/supabase/pruebas/PaquetesPrueba/PaquetesPrueba.csproj" \
    -c Release -p:UseSharedCompilation=false -- "$test_workspace/paquetes"
test_container=$(docker run --detach --rm --network none --memory=2g --cpus=2 \
    --tmpfs /var/lib/postgresql/data:rw,size=1g \
    -e POSTGRES_HOST_AUTH_METHOD=trust "$postgres_test_image")
for attempt in {1..60}; do
    if docker exec "$test_container" pg_isready -U postgres >/dev/null 2>&1; then break; fi
    if [[ "$attempt" == 60 ]]; then docker logs "$test_container"; exit 1; fi
    sleep 1
done
docker exec -u root "$test_container" mkdir -p /pruebas
docker cp "$repo_root/supabase" "$test_container:/pruebas/supabase"
docker cp "$test_workspace/paquetes" "$test_container:/pruebas/paquetes"
docker exec -u root "$test_container" chmod -R a+rX /pruebas
docker exec -u postgres "$test_container" psql -X -d postgres \
    -v MYG_PRUEBAS_DESECHABLES=1 -v ON_ERROR_STOP=1 -f /pruebas/supabase/pruebas/preservacion_base.sql

# Una instalación personalizada no se reemplaza a ciegas. El preflight debe
# fallar sin tocar los datos o la función que el operador ya modificó.
docker exec -i -u postgres "$test_container" psql -X -v ON_ERROR_STOP=1 -d postgres <<'SQL'
DO $qa$
DECLARE definicion text;
BEGIN
    definicion:=pg_get_functiondef('myg_nube_privado.central_validar_catalogo(jsonb)'::regprocedure);
    definicion:=replace(definicion,E'begin\n',E'begin\n    -- QA personalización conservar\n');
    EXECUTE definicion;
END $qa$;
CREATE TABLE qa.preservacion_preflight_antes AS
SELECT md5(prosrc) huella FROM pg_proc WHERE oid='myg_nube_privado.central_validar_catalogo(jsonb)'::regprocedure;
SELECT qa.exige((SELECT prosrc LIKE '%QA personalización conservar%' FROM pg_proc
    WHERE oid='myg_nube_privado.central_validar_catalogo(jsonb)'::regprocedure),
    'Preservación: fixture de personalización contiene su marca privada');
SQL
if docker exec -u postgres "$test_container" psql -X -v ON_ERROR_STOP=1 -d postgres \
    -f /pruebas/supabase/migraciones/20261107_preservacion_base.sql > "$test_workspace/preflight-esperado.log" 2>&1; then
    echo 'La migración aceptó sobrescribir una personalización desconocida.' >&2
    exit 1
fi
grep -q 'personalización desconocida; se conserva intacta' "$test_workspace/preflight-esperado.log"
docker exec -u postgres "$test_container" psql -X -v ON_ERROR_STOP=1 -d postgres -c "
SELECT qa.exige((SELECT md5(prosrc)=(SELECT huella FROM qa.preservacion_preflight_antes)
    FROM pg_proc WHERE oid='myg_nube_privado.central_validar_catalogo(jsonb)'::regprocedure)
    AND (SELECT catalogo=(SELECT contenido FROM qa.preservacion_catalogo) FROM myg_nube_privado.central_bases
         WHERE base_id='d9a70000-0000-0000-0000-000000000001'),
    'Preservación: preflight conserva función personalizada y datos privados existentes');"

