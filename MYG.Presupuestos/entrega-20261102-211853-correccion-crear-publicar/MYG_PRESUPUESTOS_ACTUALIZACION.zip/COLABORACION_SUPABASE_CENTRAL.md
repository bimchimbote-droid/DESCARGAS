# Agregar colaborador con Supabase central

La corrección posterior de Crear / publicar y de las tablas adicionales de la
captura se aplica siguiendo [CORRECCION_CREAR_PUBLICAR.md](CORRECCION_CREAR_PUBLICAR.md).
Esa actualización añade `20261107_preservacion_base.sql` después de `20261106`.

## A. Cambio y estado real

La colaboración utiliza directamente Supabase. Agregar un colaborador modifica
permisos sobre la obra existente; no publica otra obra ni sube un archivo por
colaborador. Cada obra tiene su revisión y sus permisos, incluidos Metrados Revit.
No requiere dominio, alojamiento adicional, `MYG.ServidorColaboracion` ni
`ServicioBasesUrl`.

PostgreSQL conserva contenido estructurado por obra, identidades y permisos.
SQLite queda como copia local de trabajo. Esto cambia el almacenamiento central:
no es edición compartida del mismo archivo SQLite alojado en Storage. Los
catálogos no utilizados se conservan en un registro reservado al propietario.
Compartir una obra no da acceso a ese catálogo privado ni a otras obras.

Las nuevas bases se publican directamente en PostgreSQL. Una base antigua se
prepara por etapas y cambia de origen en una activación atómica. Conserva base_id,
identidades de vistas anteriores y permisos. Después se bloquean las escrituras
antiguas. Los intentos, UUID y cuerpos se conservan ante cierres y respuestas
perdidas; una revisión concurrente provoca conflicto, no sobrescritura silenciosa.

El instalador integra la conexión pública en el programa. El comprador instala,
inicia sesión con su cuenta MYG y trabaja con su licencia y permisos. No configura
JSON. El destino de producción se prepara una sola vez al generar la distribución.
Los perfiles locales válidos conservan su conexión anterior para no cambiar de
proyecto Supabase por accidente.

Base del trabajo: `bimchimbote-droid/MYG.Presupuestos`, commit
`df8392a5d2910216a097349add3d20ba6103bdf5`, con la entrega anterior de 31 archivos
publicada en DESCARGAS, commit `3d6fca4b1192984c466abf3c8aec12be8482b118`.
Este ZIP actualiza esa entrega que el usuario ya instaló. Se comparan sus archivos
contra dicha entrega aplicada sobre el commit indicado, excluyendo componentes
sin cambios. La solución vuelve a prescindir de los proyectos del servidor .NET.
Los archivos de ese servidor ya existentes no se borran.

No se modificaron Supabase de producción, Cloudflare ni el repositorio del código.
Para activar la función real se necesita ejecutar el SQL y distribuir el programa
actualizado. Las pruebas usaron PostgreSQL 17 desechable, SQLite real y el cliente
y sincronizador reales; la autenticación y el transporte HTTP se simularon.

## B. Archivos completos

La tabla completa está al final. CREAR agrega el archivo; si ya existe por una
aplicación parcial, compare y sustituya por la versión completa. REEMPLAZAR indica
un archivo del código o de la entrega anterior. No hay eliminaciones de archivos
de usuario. Aplique todos los archivos, conservando sus carpetas.

## C. Descarga

La respuesta de entrega proporciona el enlace público al ZIP en una carpeta nueva
de `bimchimbote-droid/DESCARGAS`, fijado al commit, junto con su SHA-256 y la
verificación de descarga. No se sustituyen entregas anteriores.

## D. Instalación y activación

1. Cierre MYG y Revit. Confirme o respalde sus cambios antes de reemplazar código.
   La carpeta de referencia es `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
2. Extraiga el ZIP en la raíz de ese proyecto manteniendo todas las carpetas.
   Esta actualización se aplica sobre la entrega anterior que ya copió.
3. Respalde Supabase y abra SQL Editor en el proyecto que ya usa MYG. Debe estar
   aplicada `20261105_colaboracion_misma_base.sql` de la entrega anterior, con sus
   prerrequisitos de SQLite, bases privadas y Metrados Revit. Si ya se ejecutó
   correctamente, no vuelva a reinstalarla después de la migración nueva.
4. Abra `supabase/migraciones/20261106_base_central.sql`, copie TODO el contenido en
   SQL Editor y ejecute desde BEGIN hasta COMMIT. Se hace una vez para el sistema,
   no por cliente ni por colaborador. Si falta una protección o prerrequisito,
   aborta sin activar parcialmente. No ejecute `supabase/pruebas` en producción.
5. En su Windows de desarrollo, con .NET 10, Revit 2027 e Inno Setup instalados,
   abra PowerShell en la raíz del proyecto y ejecute:

   ```powershell
   .\scripts\Generar-Instalador.ps1
   ```

   Reutiliza su conexión pública MYG existente para integrar el destino. El
   generador valida el recurso dentro del ensamblado antes de empaquetarlo. Copiar
   un JSON junto a un ejecutable anterior no activa esta compilación.
6. El resultado queda en `dist\Instalador`. Instale el programa actualizado en los
   equipos del propietario y los colaboradores. Para probar sin empaquetar, use
   `scripts\Publicar.ps1` y la carpeta completa `dist\MYG`; la compilación normal
   de desarrollo no incluye por sí sola la conexión comercial.

Si el equipo que genera el instalador nunca tuvo configurada Nube MYG, indique una
vez su perfil público de producción con `-ConfiguracionNube`. Es preparación del
fabricante, no activación del comprador. El recurso solo admite URL HTTPS y clave
publicable/anon. No incorpora `service_role` ni sesiones o datos de clientes.

## E. Uso y datos

1. Inicie sesión como propietario y abra su base desde Nube MYG.
2. Elija la obra y pulse Agregar colaborador. Para una base anterior se confirman
   primero las obras abiertas y se prepara la migración. Si hay conflicto,
   resuélvalo conservando sus cambios antes de continuar.
3. Indique usuario MYG, rol y permisos por módulo. Un lector no edita; Metrados
   Revit requiere permiso explícito. SQL vuelve a autorizar cada operación.
4. El colaborador entra con su propia cuenta. Compartidos conmigo muestra solo
   sus obras autorizadas; abrir una no descarga las demás. Conocer otro UUID
   no concede acceso a la otra obra ni a la base completa.
5. Sincronizar confirma esa obra. Dos personas que editan la misma revisión
   conservan sus cambios como conflicto. Editar otra obra no la sobrescribe.
   Retirar acceso impide nuevas operaciones, sin borrar archivos ya descargados.

Se comprueba cobertura de obras, catálogos, unidades y adjuntos antes de activar.
Las tablas, columnas o filas no representables detienen la transformación; no se
descartan silenciosamente. Un intento no activado se cancela y prepara de nuevo
cuando la revisión original cambió, conservando la preparación local anterior.

Los catálogos generales de la base central se ofrecen para consulta. Esta entrega
sincroniza presupuestos, metrados y dependencias utilizadas por obra; no incluye
edición global versionada de los catálogos entre equipos. Sus acciones explícitas
de administración quedan deshabilitadas en la base central. Las bases locales
conservan su administración y se pueden elegir entradas para el presupuesto.

Los SQLite y revisiones anteriores de Storage permanecen como respaldo privado:
una migración puede ocupar temporalmente más espacio. PostgreSQL también consume
espacio; no se promete coste cero ni ausencia de revisiones. No se crean copias por
colaborador. La eliminación explícita existente elimina datos centrales y objetos
del manifiesto de forma recuperable, conservando las copias locales.

## F. Validaciones

Los resultados finales se adjuntan en la respuesta de entrega. Se incluyen pruebas
de permisos, revocación, Revit, revisiones por obra, ACK perdido, migración parcial,
catálogos no usados, adjuntos, publicación directa y borrado recuperable.

Resultados verificados de esta entrega:

| Comprobación | Resultado |
| --- | --- |
| Solución completa Release y Desktop con conexión integrada | 0 errores y 0 advertencias |
| Cliente central / helper SQLite / cobertura | 207 / 25 / 23 comprobaciones aprobadas |
| Integración cliente C# + PostgreSQL + SQLite + sincronizador | 45 comprobaciones aprobadas |
| PostgreSQL y concurrencia con dos conexiones | 317 aprobadas: 76 centrales y 241 prerrequisitos |
| Exportador e inspección de recursos PE / arranque integrado | 65 / 23 aprobadas |
| Compatibilidad de colaboradores / cliente anterior / base SQLite anterior | 154 / 55 / 59 aprobadas |
| Configuración de conexiones / pruebas Core | 92 / 810 aprobadas |

La integración comprueba también la pérdida del ACK al crear una obra, conservar
su edición posterior, recuperar el vínculo sin duplicación y sincronizar a la
revisión siguiente. La inspección PE valida el programa sin ejecutar su código.

```text
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --central-cliente
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --central-sqlite
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --central-cobertura
python scripts/pruebas/Probar-PrepararNube.py
```

Con Docker y Bash, `scripts/pruebas/Probar-BaseCentral.sh` y
`scripts/pruebas/Probar-CentralIntegracion.sh` crean y eliminan su propio PostgreSQL.
No necesitan credenciales ni apuntan a producción.

La suite completa de nube tenía previamente un fallo en
`PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`, sobre la fase del
diagnóstico de un error. No se oculta ni se declara aprobada esa prueba; las
comprobaciones centrales se ejecutan también por separado.

## G. Publicar su código

Después de revisar y probar en su PC, abra los cambios de Git en Visual Studio,
haga Commit en su rama `main` y realice Push cuando usted decida publicar el código.
Esta sesión publica únicamente el ZIP autorizado en DESCARGAS.

## H. Límites

- Debe actualizar el programa y ejecutar el SQL en su proyecto real; no se ha
  activado producción desde esta sesión.
- El entorno no ejecuta Windows, Revit, PowerShell o Inno Setup. La compilación
  cruzada y la inspección del recurso no sustituyen la prueba manual del instalador.
- No se midió carga comercial con archivos reales de cientos de MB. El consumo y
  las cuotas dependen del plan Supabase.
- Las extensiones no representables conservan el original y detienen la migración.
  Dependencias de distintas obras con la misma identidad y valores incompatibles
  se rechazan al reconstruir, conservando los datos para resolverlos.
- Los catálogos generales son de consulta en esta modalidad; su edición global
  concurrente requiere una ampliación adicional.
- Los respaldos y publicaciones independientes de versiones anteriores no se
  eliminan automáticamente.

## Tabla completa de archivos

<!-- TABLA_ARCHIVOS -->

| N.º | Ruta exacta | Acción | Descripción |
| --- | --- | --- | --- |
| 1 | `COLABORACION_MISMA_BASE.md` | REEMPLAZAR | Remite a la guía vigente; retira los pasos del servidor anterior. |
| 2 | `COLABORACION_SUPABASE_CENTRAL.md` | CREAR | Instalación, activación, evidencia, límites y tabla de archivos. |
| 3 | `MYG.Colaboracion/BaseCentralNube.cs` | CREAR | Migración, publicación, recuperación y catálogo privado de la base. |
| 4 | `MYG.Colaboracion/BaseCentralNuevaObra.cs` | CREAR | Creación de obra recuperable sin duplicarla tras perder el ACK. |
| 5 | `MYG.Colaboracion/ClienteNubeCambios.cs` | REEMPLAZAR | Dirige revisiones y cambios al origen central. |
| 6 | `MYG.Colaboracion/ClienteNubeCentral.cs` | CREAR | RPC nativos, etapas, cancelación y permisos de Supabase. |
| 7 | `MYG.Colaboracion/ClienteNubeDiagnostico.cs` | REEMPLAZAR | Reconoce errores centrales sin revelar respuestas privadas. |
| 8 | `MYG.Colaboracion/ClienteNubeMismaBase.cs` | REEMPLAZAR | Reconoce las obras centrales sin servicio adicional. |
| 9 | `MYG.Colaboracion/ClienteNubeProyectos.cs` | REEMPLAZAR | Lista, abre, guarda y administra las obras centrales. |
| 10 | `MYG.Colaboracion/CoberturaCentralNube.cs` | CREAR | Detecta filas que no se conservarían en la transformación. |
| 11 | `MYG.Colaboracion/ConfiguracionServicioNube.cs` | REEMPLAZAR | Preserva perfiles y compatibilidad durante la actualización. |
| 12 | `MYG.Colaboracion/CopiaSqliteNube.cs` | REEMPLAZAR | Retira la ruta binaria de las bases activadas. |
| 13 | `MYG.Colaboracion/CopiaSqliteNubeBim.cs` | REEMPLAZAR | Dirige la base activada al sincronizador por obra. |
| 14 | `MYG.Colaboracion/ModelosNubeProyectos.cs` | REEMPLAZAR | Identifica la modalidad central en los metadatos. |
| 15 | `MYG.Desktop/CatalogosForm.cs` | REEMPLAZAR | Separa seleccionar entradas de administrar catálogos generales. |
| 16 | `MYG.Desktop/EditorCatalogos.cs` | REEMPLAZAR | Consulta de unidades generales en bases centrales. |
| 17 | `MYG.Desktop/EditorNube.cs` | REEMPLAZAR | Permite sincronizar las obras centrales desde su barra. |
| 18 | `MYG.Desktop/ExploradorNubePresentacion.cs` | REEMPLAZAR | Presenta el tipo Base central. |
| 19 | `MYG.Desktop/InicioBaseNube.cs` | REEMPLAZAR | Reconoce vínculos centrales y obras nuevas. |
| 20 | `MYG.Desktop/InicioCentralNube.cs` | CREAR | Publicación, apertura, migración y exportación desde la interfaz. |
| 21 | `MYG.Desktop/InicioColaboracionObraBase.cs` | REEMPLAZAR | Conecta Agregar colaborador con Supabase central. |
| 22 | `MYG.Desktop/InicioForm.cs` | REEMPLAZAR | Muestra las revisiones por obra y registra nuevas obras. |
| 23 | `MYG.Desktop/InicioNube.cs` | REEMPLAZAR | Abre y exporta la modalidad central. |
| 24 | `MYG.Desktop/InicioNubeSqlite.cs` | REEMPLAZAR | Utiliza publicación nativa cuando el servidor la admite. |
| 25 | `MYG.Desktop/InicioSincronizacionBase.cs` | REEMPLAZAR | Conserva borradores de las otras pestañas del archivo. |
| 26 | `MYG.Desktop/MYG.Desktop.csproj` | REEMPLAZAR | Integra y valida la conexión pública durante la compilación. |
| 27 | `MYG.Desktop/NubeConfiguracion.cs` | REEMPLAZAR | Arranca sin configuración manual en instalaciones limpias. |
| 28 | `MYG.Desktop/NubeForm.cs` | REEMPLAZAR | Explica los tipos y el alcance de la base central. |
| 29 | `MYG.Desktop/NubePublicarForm.cs` | REEMPLAZAR | Presenta publicación central conservando compatibilidad. |
| 30 | `MYG.Desktop/PresupuestosCatalogos.cs` | REEMPLAZAR | Protege la administración general y permite usar dependencias. |
| 31 | `MYG.Presupuestos.sln` | REEMPLAZAR | Retira las referencias al servidor adicional de la entrega anterior. |
| 32 | `MYG.PruebasNube/CentralClienteCheck.cs` | CREAR | Pruebas de contrato, permisos y transporte nativo. |
| 33 | `MYG.PruebasNube/CentralCoberturaCheck.cs` | CREAR | Catálogos, unidades, adjuntos e integridad de la reconstrucción. |
| 34 | `MYG.PruebasNube/CentralIntegracionCheck.cs` | CREAR | Cliente y sincronizador C# contra RPC PostgreSQL reales. |
| 35 | `MYG.PruebasNube/CentralSqliteCheck.cs` | CREAR | Activación, recuperación y colas por obra en SQLite real. |
| 36 | `MYG.PruebasNube/ConfiguracionNubeCheck.cs` | REEMPLAZAR | Comprueba actualización y privacidad de la conexión. |
| 37 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Enlaza las pruebas y sus selectores. |
| 38 | `instalador/MYG.Presupuestos.iss` | REEMPLAZAR | Excluye el JSON externo residual de la instalación. |
| 39 | `scripts/Generar-Instalador.ps1` | REEMPLAZAR | Valida la conexión del programa antes de empaquetarlo. |
| 40 | `scripts/Preparar-Nube/Program.cs` | REEMPLAZAR | Prepara conexión pública e inspecciona recursos sin ejecutar el programa. |
| 41 | `scripts/Publicar.ps1` | REEMPLAZAR | Publica con conexión integrada y prepara la distribución comercial. |
| 42 | `scripts/pruebas/ConfiguracionIntegrada/ConfiguracionIntegrada.csproj` | CREAR | Proyecto de pruebas del arranque comercial. |
| 43 | `scripts/pruebas/ConfiguracionIntegrada/Program.cs` | CREAR | Comprueba instalación limpia, actualización y recurso integrado. |
| 44 | `scripts/pruebas/ConfiguracionIntegrada/conexion-sintetica.json` | CREAR | Fixture de prueba; no es la conexión de producción ni se configura en clientes. |
| 45 | `scripts/pruebas/Probar-BaseCentral.sh` | CREAR | Ejecuta PostgreSQL desechable y concurrencia real. |
| 46 | `scripts/pruebas/Probar-CentralIntegracion.sh` | CREAR | Ejecuta la integración completa en PostgreSQL desechable. |
| 47 | `scripts/pruebas/Probar-PrepararNube.py` | REEMPLAZAR | Valida exportación y ensamblados reales con y sin recurso. |
| 48 | `supabase/migraciones/20261106_base_central.sql` | CREAR | Activación SQL, permisos, CAS, cancelación y borrado recuperable. |
| 49 | `supabase/pruebas/base_central.sql` | CREAR | Pruebas SQL; nunca ejecutar en producción. |
