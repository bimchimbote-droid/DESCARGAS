# Corrección de Crear / publicar y conservación de datos de la base

## A. Resultado

Crear / publicar abre directamente la ventana para elegir una base SQLite o crear
una base en blanco. No pregunta si desea retomar un intento ni retoma uno por su
cuenta. Los intentos anteriores permanecen disponibles únicamente en Publicaciones
pendientes; reintentar exige seleccionar una fila y pulsar su botón.

Se corrige el rechazo de las 35 tablas conocidas que aparecen en la captura,
incluyendo persona, planilla, cuentas y títulos. Se conserva su información para
el propietario y se mantiene el acceso del colaborador limitado a su obra. La
comprobación de cobertura permanece activa para no descartar datos silenciosamente.

Los títulos importados de Delphin conservan su representación nativa. Las filas
operativas que ya pertenecen a las obras no se archivan de nuevo como datos
residuales, evitando reintroducir filas eliminadas. Las colisiones se rechazan y
las copias locales del propietario protegen los datos preservados frente a cambios
accidentales durante la sincronización.

## B. Archivos

Esta entrega actualiza el ZIP de 49 archivos publicado en DESCARGAS, commit
`a20f1a46f57670955187787940af5fe2e2293d52`. Se entregan archivos completos y solamente
las diferencias respecto de esa versión instalada. La tabla completa está al final.
CREAR agrega un archivo; REEMPLAZAR sustituye el existente en la misma ruta.

## C. Descarga

La respuesta de entrega contiene un enlace público al ZIP en una carpeta nueva de
`bimchimbote-droid/DESCARGAS`, fijado al commit y verificado mediante descarga y
SHA-256. No sustituye entregas anteriores ni hace Push al repositorio del código.

## D. Aplicar la corrección

1. Cierre MYG y Revit y respalde o confirme sus cambios en Git.
2. Extraiga TODO el ZIP en la raíz de su proyecto, donde está
   `MYG.Presupuestos.sln`, conservando las carpetas. Se aplica sobre la entrega
   anterior de 49 archivos que ya copió.
3. En el mismo proyecto Supabase que utiliza MYG, abra SQL Editor. Abra en su PC
   `supabase/migraciones/20261107_preservacion_base.sql`, copie TODO su contenido y
   ejecútelo en una consulta nueva, desde BEGIN hasta COMMIT. Requiere la migración
   20261106 que ya habilitó la base central. No vuelva a ejecutar migraciones viejas
   después de la nueva: podrían restaurar validadores anteriores.
4. Desde PowerShell abierto en la raíz de su proyecto, genere el instalador:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Generar-Instalador.ps1
   ```

5. Instale el resultado de `dist\Instalador` en los equipos que utilizarán MYG.
   El generador necesita .NET SDK 10, Revit 2027 e Inno Setup en el equipo de
   desarrollo. Los clientes reciben el instalador, no los scripts ni archivos SQL.
6. Abra Nube MYG y pulse Crear / publicar: debe aparecer la ventana de elección.
   Elija Crear base vacía o el archivo `.sqlite` y confirme la opción elegida.
   Un archivo de migración `.sql` se ejecuta en Supabase; no es el archivo SQLite
   de presupuestos que se elige en esa ventana.

Los intentos que quedaron pendientes con versiones anteriores no se borran y no
se abren automáticamente. Puede consultarlos desde su botón cuando usted decida.
Cancelar la ventana de elección no crea otra preparación ni cambia esos intentos.

## E. Configuración

La conexión pública sigue integrada por el generador del instalador. Esta
corrección no requiere que el comprador edite JSON, configure un dominio o instale
un servicio .NET adicional. La migración 20261107 se aplica una vez en su Supabase,
no por cada comprador. Si todavía falta, el programa lo informa antes de crear o
preparar la publicación remota.

## F. Validación

Se verifican ambos problemas con pruebas de almacenamiento, cliente y PostgreSQL
real, usando bases sintéticas con las 35 tablas pobladas, relaciones, tipos y BLOB.
Se comprueba también la preparación local real de Crear / publicar, la apertura de
una copia nueva, el borrado de títulos operativos, la privacidad del colaborador y
la conservación del propietario durante la sincronización.

Los resultados finales están en la respuesta de entrega. Se incluyen los comandos:

| Comprobación | Resultado |
| --- | --- |
| Solución completa Release | 0 errores y 0 advertencias |
| Publicaciones independientes y selección explícita | 15 comprobaciones aprobadas |
| Cliente y soporte de preservación | 264 aprobadas |
| Títulos Delphin nativos | 17 aprobadas |
| Cobertura, relaciones y protección local de datos | 117 aprobadas |
| PostgreSQL, activación aditiva y permisos | 336 aprobadas, incluidas 21 nuevas |
| Recorrido real de publicación y preservación | 241 aprobadas; las 35 tablas pobladas |
| Regresión de colaboración central | 45 de integración, 207 de cliente y 25 del helper aprobadas |

Las pruebas de integración simulan Auth/HTTP, pero ejecutan RPC y transacciones
reales en PostgreSQL y trabajan con archivos SQLite reales. La prueba de ventana
comprueba la separación entre creación y reintento y su almacenamiento durable;
no ejecuta WinForms en Windows.

```text
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --publicaciones-multiples
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --preservacion-cliente
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --titulos-nativos
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release -- --central-cobertura
```

Los archivos `scripts/pruebas/Probar-PreservacionBase.sh` y
`scripts/pruebas/Probar-PreservacionCentral.sh` usan Bash, Docker y PostgreSQL
desechable. Son pruebas de desarrollo. No ejecute los SQL de `supabase/pruebas` en
su proyecto de producción.

## G. Código y GitHub

La rama del código continúa sin Push desde esta sesión. Después de probar la
actualización en su PC, revise los cambios en Visual Studio, haga Commit en `main`
y realice Push cuando decida publicar el código. El ZIP se publica únicamente en
el repositorio independiente DESCARGAS autorizado.

## H. Alcance y límites

No se modificaron Supabase de producción, Cloudflare ni los archivos de su PC
desde esta sesión. Es necesario aplicar el SQL y recompilar. La interfaz Windows,
Revit e Inno Setup requieren la comprobación manual en su equipo; aquí se realizó
compilación cruzada y las pruebas del recorrido de datos y permisos.

La base real de la captura no se recibió: la reproducción utiliza el esquema
confiable de Core y las 35 tablas señaladas, con datos sintéticos. Las extensiones
o columnas desconocidas siguen deteniendo la conversión en lugar de perderse.
Los respaldos anteriores permanecen y los catálogos generales centrales continúan
como consulta. La suite completa de nube conserva el fallo previo de diagnóstico
`PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`, ya documentado.

## Tabla de archivos y acciones

<!-- TABLA_ARCHIVOS -->

| N.º | Ruta exacta | Acción | Descripción |
| --- | --- | --- | --- |
| 1 | `COLABORACION_SUPABASE_CENTRAL.md` | REEMPLAZAR | Remite a esta corrección y a la migración posterior. |
| 2 | `CORRECCION_CREAR_PUBLICAR.md` | CREAR | Pasos, resultados y tabla de los archivos de esta corrección. |
| 3 | `MYG.Colaboracion/BaseCentralNube.cs` | REEMPLAZAR | Conserva las tablas adicionales y reconstruye la base del propietario. |
| 4 | `MYG.Colaboracion/BaseCentralPreservacionLocal.cs` | CREAR | Protege los datos originales durante las escrituras locales. |
| 5 | `MYG.Colaboracion/BaseCentralTitulosNativos.cs` | CREAR | Conserva títulos Delphin antes de guardar el documento. |
| 6 | `MYG.Colaboracion/ClienteNubeCentral.cs` | REEMPLAZAR | Valida el catálogo ampliado reservado al propietario. |
| 7 | `MYG.Colaboracion/ClienteNubePreservacionBase.cs` | CREAR | Comprueba SQL07 antes de crear datos remotos. |
| 8 | `MYG.Colaboracion/PaqueteNube.cs` | REEMPLAZAR | Excluye metadatos locales de las obras compartidas. |
| 9 | `MYG.Colaboracion/PublicacionSqlitePendiente.cs` | REEMPLAZAR | Retira guardas únicamente de la copia a publicar. |
| 10 | `MYG.Colaboracion/PublicacionesSqliteEnCola.cs` | CREAR | Mantiene intentos independientes sin retomar uno automáticamente. |
| 11 | `MYG.Colaboracion/SincronizadorProyectoNube.cs` | REEMPLAZAR | Incorpora títulos nativos de las revisiones recibidas. |
| 12 | `MYG.Desktop/EditorNube.cs` | REEMPLAZAR | Conserva títulos al resolver un conflicto con la revisión remota. |
| 13 | `MYG.Desktop/InicioCentralNube.cs` | REEMPLAZAR | Abre la elección nueva sin consultar intentos anteriores. |
| 14 | `MYG.Desktop/InicioNubeSqlite.cs` | REEMPLAZAR | Separa crear una publicación de reintentar la seleccionada. |
| 15 | `MYG.Desktop/PublicacionesSqlitePendientesForm.cs` | CREAR | Lista los intentos para selección explícita en su botón. |
| 16 | `MYG.PruebasNube/CentralCoberturaCheck.cs` | REEMPLAZAR | Comprueba las 35 tablas y la preservación al sincronizar. |
| 17 | `MYG.PruebasNube/CentralIntegracionCheck.cs` | REEMPLAZAR | Reutiliza el puente de RPC reales para las nuevas pruebas. |
| 18 | `MYG.PruebasNube/PreservacionClienteCheck.cs` | CREAR | Comprueba capacidad, esquema, claves y privacidad. |
| 19 | `MYG.PruebasNube/PreservacionIntegracionCheck.cs` | CREAR | Prueba publicación y restauración con las 35 tablas pobladas. |
| 20 | `MYG.PruebasNube/Program.cs` | REEMPLAZAR | Enlaza los nuevos selectores y comprobaciones. |
| 21 | `MYG.PruebasNube/PublicacionesMultiplesCheck.cs` | CREAR | Verifica conservación, reinicio y selección de pendientes. |
| 22 | `MYG.PruebasNube/TitulosNativosCheck.cs` | CREAR | Verifica representación, atributos y aislamiento de títulos. |
| 23 | `scripts/pruebas/Probar-CentralIntegracion.sh` | REEMPLAZAR | Ejecuta la regresión central con SQL07 aplicado. |
| 24 | `scripts/pruebas/Probar-PreservacionBase.sh` | CREAR | Ejecuta las pruebas SQL en PostgreSQL desechable. |
| 25 | `scripts/pruebas/Probar-PreservacionCentral.sh` | CREAR | Ejecuta el recorrido de datos completo en PostgreSQL desechable. |
| 26 | `supabase/migraciones/20261107_preservacion_base.sql` | CREAR | EJECUTAR completa en SQL Editor después de SQL06. |
| 27 | `supabase/pruebas/preservacion_base.sql` | CREAR | Pruebas de desarrollo; NO ejecutar en producción. |
