-- Conservación de tablas adicionales reconocidas de la base del propietario.
-- Ejecutar DESPUÉS de 20261106_base_central.sql. No copia obras ni concede
-- acceso al archivo completo. No cambia las ACL ni la proyección del colaborador.
begin;

do $preflight$
begin
    if to_regprocedure('myg_nube_privado.central_validar_catalogo(jsonb)') is null
       or to_regprocedure('public.myg_central_preparar_catalogo(uuid,jsonb)') is null
       or to_regprocedure('public.myg_central_catalogo(uuid)') is null
       or to_regprocedure('public.myg_central_capacidades()') is null
       or to_regclass('myg_nube_privado.central_bases') is null then
        raise exception 'Aplique primero completa 20261106_base_central.sql.';
    end if;
    if not exists(select 1 from pg_proc
        where oid='myg_nube_privado.central_validar_catalogo(jsonb)'::regprocedure
          and md5(replace(prosrc,E'\r\n',E'\n')) in ('c7a512231e33ae4a00e23a0db18ad804','cc5e0d41807921387d372ee1b0e73bc5')) then
        raise exception 'La validación del catálogo central contiene una personalización desconocida; se conserva intacta.';
    end if;
    if to_regprocedure('myg_nube_privado.central_preservacion_esquema(text)') is not null and not exists(select 1 from pg_proc
        where oid=to_regprocedure('myg_nube_privado.central_preservacion_esquema(text)') and md5(replace(prosrc,E'\r\n',E'\n'))='40a81b58dbaf1014e011975ab485498f') then
        raise exception 'La preservación central contiene una personalización desconocida; se conserva intacta.';
    end if;
    if to_regprocedure('public.myg_central_preservacion_capacidades()') is not null and not exists(select 1 from pg_proc
        where oid=to_regprocedure('public.myg_central_preservacion_capacidades()') and md5(replace(prosrc,E'\r\n',E'\n'))='859d466928828b817345190859458aee') then
        raise exception 'La preservación central contiene una personalización desconocida; se conserva intacta.';
    end if;
    if has_function_privilege('anon','public.myg_central_catalogo(uuid)','EXECUTE')
       or has_table_privilege('authenticated','myg_nube_privado.central_bases','SELECT') then
        raise exception 'La protección privada de la base central no coincide; se conserva la instalación.';
    end if;
end $preflight$;

create or replace function myg_nube_privado.central_preservacion_esquema(p_tabla text)
returns jsonb language sql immutable set search_path=pg_catalog as $fn$
    select '{"cargo":{"columnas":["id_cargo","descripcion_cargo","id_tipopersona"],"claves":["id_cargo"]},"clase_gl":{"columnas":["id_clase","codigo_clase","nombre_clase"],"claves":["id_clase"]},"concepto":{"columnas":["id_concepto","id_cuenta","descripcion_concepto","estado_concepto","tipo_concepto","codigo_cuenta","id_cuentagl","id_subcuenta","info_concepto","id_conceptoextorno","es_extorno","id_extension","id_documentos","tipo_afectar","id_conceptocargo","agrega_cuenta","imprimir_logo","formula","permite_suma","es_planilla","orden","clave_concepto","es_afp"],"claves":["id_concepto"]},"costo_partida":{"columnas":["id_costopartida","descripcion_costo","id_unidad","id_partida","numeracion_costo","posicion_costo","id_analisiscosto"],"claves":["id_costopartida"]},"cuenta":{"columnas":["id_cuenta","descripcion_cuenta","estado_cuenta","orden"],"claves":["id_cuenta"]},"cuenta_caja":{"columnas":["id_caja","descripcion_caja","id_tipocaja","id_cuenta","id_subcuenta","id_sucursal","id_moneda","id_documentofact","formato_ticket","id_documentovta","serie_impresora","formato_fact"],"claves":["id_caja"]},"cuenta_gl":{"columnas":["id_cuenta","codigo_cuenta","nombre_cuenta","id_cuentapadre","id_clase","orden"],"claves":["id_cuenta"]},"cuenta_gl_temp":{"columnas":["id_cuenta","codigo_cuenta","nombre_cuenta","id_cuentapadre","id_clase","orden"],"claves":["id_cuenta"]},"detalle_planilla":{"columnas":["id_detalleplanilla","id_concepto","total_detalle","id_planilla","estado_detalle","formula","estado_cargado","id_documento","numero_documento","serie_documento","fecha_documento","tipo_concepto","tiene_items"],"claves":["id_detalleplanilla"]},"diccionario":{"columnas":["id_elemento","descripcion_elemento","codigo_clase","nota"],"claves":["id_elemento"]},"documento":{"columnas":["id_documento","descripcion_documento","modulo","estado_documento","genera_impuesto","generar_numero","codigo_documento","omite_serie","long_maxima","id_documentosecuencia"],"claves":["id_documento"]},"documento_identidad":{"columnas":["id_documento","descripcion_documento","codigo_documento","long_maxima","long_minima"],"claves":["id_documento"]},"estado_civil":{"columnas":["id_estadocivil","descripcion_estadocivil"],"claves":["id_estadocivil"]},"formato_documento":{"columnas":["id_formato","id_documento","id_sucursal","maximo_items","cols_series"],"claves":["id_formato"]},"forma_pago":{"columnas":["id_formapago","descripcion_formapago","verifica_persona","agrega_cuenta"],"claves":["id_formapago"]},"hoja_planilla":{"columnas":["id_hoja","mes_planilla","anio_planilla","numero_planilla","fecha_inicio","fecha_cierre","observacion","estado_hoja","id_proyecto"],"claves":["id_hoja"]},"modalidad_map":{"columnas":["id_modalidadmap","id_modalidad","id_concepto","permitido"],"claves":["id_modalidadmap"]},"modalidad_pago":{"columnas":["id_modalidadpago","descripcion_modalidadpago","tipo_cuenta","documentos_ingreso","documentos_egreso","orden"],"claves":["id_modalidadpago"]},"motivo":{"columnas":["id_motivo","descripcion_motivo","afecta_kardex","solo_empresa","verifica_destino","permitir_proveedor","estado_motivo","requiere_persona","permitir_empresa","codigo_motivo","requiere_responsable","requiere_liquidacion","afecta_fisico","codigo_sunat","tipo_motivo","requiere_proyecto"],"claves":["id_motivo"]},"partida":{"columnas":["id_partida","descripcion_partida","id_plantilla","id_titulopadre","posicion_titulo","estado_bloqueado","estado_expandido","numeracion_titulo"],"claves":["id_partida"]},"persona":{"columnas":["id_persona","clase_persona","nombre_persona","apellidos_persona","fecha_nacimiento","profesion","estado_civil","sexo","id_supervisor","direccion","telefono","lugar_trabajo","direccion_trabajo","telefono_trabajo","movil","dni","ruc","email","email_alternativo","sitio_web","id_tipopersona","id_institucion","id_cargo","descripcion_cargo","estado_persona","id_sucursal","id_sucursallabora","moneda_facturacion","fecha_registro","id_usuarioregistro","fecha_modificacion","id_usuariomodificacion","fecha_anulacion","id_usuarioanulacion","id_supervisornegocios","en_planilla","fecha_planilla","id_tipopersonacomision","id_distrito","id_localidad","nombre_comercial","tipo_afp","imagen","version","cuenta_soles","banco_soles","moneda_soles","cuenta_dolares","banco_dolares","moneda_dolares","date_version","telefono_anexo","tipo_comision","color_fuente","nombre_fuente","estilo_fuente","tamano_fuente","color_fondo","check_mostrar","imagen2"],"claves":["id_persona"]},"planilla":{"columnas":["id_planilla","id_hoja","id_persona","id_documento","serie_documento","numero_documento","fecha_documento","observacion","estado_registro","fecha_registro","id_usuario","fecha_anulacion","id_usuarioanulacion","total_ingreso","total_egreso","total_aportacion","monto_neto","monto_pagado","estado_pagado","fecha_pago","id_moneda","estado_cargado","fecha_cargo","fecha_modificacion","id_usuariomodificacion","porcentaje_fondo","porcentaje_seguro","porcentaje_flujo","porcentaje_mixta"],"claves":["id_planilla"]},"plantilla_clasificador":{"columnas":["id_plantilla","nombre_plantilla","es_predeterminada","anio"],"claves":["id_plantilla"]},"plantilla_gasto":{"columnas":["id_plantilla","nombre_plantilla","estado_expandido","posicion_plantilla","numeracion_plantilla","id_unidadduracion","modalidad_ejecucion"],"claves":["id_plantilla"]},"secuencia":{"columnas":["nombre_secuencia","ultimo_numero"],"claves":["nombre_secuencia"]},"secuencia_documento":{"columnas":["id_secuencia","id_documento","id_ubicacion","serie_actual","ultimo_numero","id_sucursal","id_empresa"],"claves":["id_secuencia"]},"sucursal":{"columnas":["id_sucursal","nombre_sucursal","id_distrito","direccion_sucursal","telefono_sucursal","telefono_alternativo","es_oficinacentral","es_domiciliofiscal","id_persona","id_sucursalcentral","estado_sucursal","codigo_sunat","id_sucursalstock1","id_sucursalstock2","id_sucursalstock3","id_documentosalida","id_documentovta","id_documentofact","tipo_unidad","id_proyecto","id_template"],"claves":["id_sucursal"]},"tipo_afp":{"columnas":["tipo_afp","descripcion_tipo","estado_vigente","porcentaje_fondo","porcentaje_seguro","porcentaje_flujo","porcentaje_mixta"],"claves":["tipo_afp"]},"tipo_asiento":{"columnas":["id_tipo","descripcion_tipo","tipo_emisor","orden"],"claves":["id_tipo"]},"tipo_caja":{"columnas":["id_tipocaja","descripcion_tipo","id_modingreso","id_modegreso","es_xcobrar","afecta_caja"],"claves":["id_tipocaja"]},"tipo_concepto":{"columnas":["tipo_concepto","descripcion_tipo","estado_vigente","orden"],"claves":["tipo_concepto"]},"tipo_persona":{"columnas":["id_tipopersona","descripcion_tipopersona","clase_persona","permitir_venta","cuenta_predeterminada","es_empleado","permite_alias","mismo_grupo","date_version","categorias","es_sistema"],"claves":["id_tipopersona"]},"titulo":{"columnas":["id_titulo","descripcion_titulo","id_titulopadre","posicion_titulo","nivel_titulo","id_presupuesto","estado_expandido","numeracion_titulo","costo_titulo","id_responsable","numeracion_norma","color_fuente","nombre_fuente","estilo_fuente","tamano_fuente","duracion","fecha_inicio","fecha_fin","es_hito","porcentaje_completado","color_fondo","duracion_new"],"claves":["id_titulo"]},"titulo_clasificador":{"columnas":["id_titulo","descripcion_titulo","id_plantilla","id_titulopadre","posicion_titulo","estado_bloqueado","estado_expandido","numeracion_titulo","informacion_titulo"],"claves":["id_titulo"]},"titulo_indice":{"columnas":["id_titulo","descripcion_titulo","id_titulopadre","posicion_titulo","nivel_titulo","id_presupuesto","estado_expandido","coeficiente","porcentaje","nomenclatura","codigo_clase","es_indice","custom_control","coeficientedefinido"],"claves":["id_titulo"]}}'::jsonb->p_tabla;
$fn$;

create or replace function myg_nube_privado.central_validar_catalogo(p_contenido jsonb)
returns void language plpgsql immutable set search_path=pg_catalog as $fn$
declare t jsonb; recurso jsonb; fila jsonb; celda jsonb;
begin
    if jsonb_typeof(p_contenido) is distinct from 'object'
       or p_contenido-array['formato','version','tablas','recursos']<>'{}'::jsonb
       or p_contenido->>'formato' is distinct from 'MYG_CATALOGO_BASE'
       or p_contenido->'version' is distinct from '1'::jsonb
       or jsonb_typeof(p_contenido->'tablas') is distinct from 'array'
       or jsonb_typeof(p_contenido->'recursos') is distinct from 'array'
       or octet_length(p_contenido::text)>314572800 then
        raise exception using errcode='22023',message='MYG_CATALOGO_INVALIDO';
    end if;
    for t in select value from jsonb_array_elements(p_contenido->'tablas') loop
        if t->>'Nombre' is null or t->>'Nombre'<>all(array[
            'catalogo_unidad','catalogo_insumo','catalogo_partida','catalogo_partida_nodo','catalogo_partida_insumo','catalogo_partida_recurso',
            'myg_indice_unificado','unidad','tipo_costo','categoria','producto','lista_precio','infraestructura','propietario',
            'portafolio','departamento','provincia','distrito','localidad','pais_info','moneda','clase','subclase','marca',
            'indice','indice_precio','region_precio','responsable','calendario',
            'unidad_map','unidad_tipocosto','unidad_tipocostonew','horario','horario_ex','feriado','excepcion',
            'plantilla_partida','titulo_plantilla','costo_unitarioplantilla','precio_producto','subclase_costo',
            'cargo','clase_gl','concepto','costo_partida','cuenta','cuenta_caja','cuenta_gl','cuenta_gl_temp','detalle_planilla','diccionario','documento','documento_identidad','estado_civil','formato_documento','forma_pago','hoja_planilla','modalidad_map','modalidad_pago','motivo','partida','persona','planilla','plantilla_clasificador','plantilla_gasto','secuencia','secuencia_documento','sucursal','tipo_afp','tipo_asiento','tipo_caja','tipo_concepto','tipo_persona','titulo','titulo_clasificador','titulo_indice'])
           or jsonb_typeof(t->'Columnas') is distinct from 'array' or jsonb_typeof(t->'Filas') is distinct from 'array'
           or t-array['Nombre','Columnas','Filas']<>'{}'::jsonb then
            raise exception using errcode='22023',message='MYG_CATALOGO_TABLA_NO_ADMITIDA';
        end if;
        if exists(select 1 from jsonb_array_elements(t->'Columnas') where jsonb_typeof(value)<>'string' or length(value#>>'{}') not between 1 and 200)
           or (select count(distinct value) from jsonb_array_elements(t->'Columnas'))<>jsonb_array_length(t->'Columnas') then
            raise exception using errcode='22023',message='MYG_CATALOGO_COLUMNAS_INVALIDAS';
        end if;
        if myg_nube_privado.central_preservacion_esquema(t->>'Nombre') is not null then
            if exists(select 1 from jsonb_array_elements_text(t->'Columnas') columna
                where not (myg_nube_privado.central_preservacion_esquema(t->>'Nombre')->'columnas' ? columna))
               or exists(select 1 from jsonb_array_elements_text(myg_nube_privado.central_preservacion_esquema(t->>'Nombre')->'claves') clave
                   where not (t->'Columnas' ? clave)) then
                raise exception using errcode='22023',message='MYG_PRESERVACION_COLUMNAS_INVALIDAS';
            end if;
        end if;
        for fila in select value from jsonb_array_elements(t->'Filas') loop
            if jsonb_typeof(fila)<>'array' or jsonb_array_length(fila)<>jsonb_array_length(t->'Columnas') then
                raise exception using errcode='22023',message='MYG_CATALOGO_FILA_INVALIDA';
            end if;
            for celda in select value from jsonb_array_elements(fila) loop
                if jsonb_typeof(celda)<>'object' or celda-array['Tipo','Valor']<>'{}'::jsonb
                   or celda->>'Tipo' is null or celda->>'Tipo' not in ('nulo','texto','entero','real','blob')
                   or (celda->>'Tipo'<>'nulo' and jsonb_typeof(celda->'Valor') is distinct from 'string') then
                    raise exception using errcode='22023',message='MYG_CATALOGO_CELDA_INVALIDA';
                end if;
            end loop;
        end loop;
    end loop;
    if (select count(distinct value->>'Nombre') from jsonb_array_elements(p_contenido->'tablas'))<>jsonb_array_length(p_contenido->'tablas') then
        raise exception using errcode='22023',message='MYG_CATALOGO_TABLA_DUPLICADA';
    end if;
    for recurso in select value from jsonb_array_elements(p_contenido->'recursos') loop
        perform myg_nube_privado.central_validar_recurso(recurso);
    end loop;
end $fn$;

create or replace function public.myg_central_preservacion_capacidades()
returns jsonb language plpgsql stable security definer set search_path=pg_catalog as $fn$
begin
    perform myg_nube_privado.identidad();
    return jsonb_build_object('version',1,'tablas_adicionales',to_jsonb(array['cargo','clase_gl','concepto','costo_partida','cuenta','cuenta_caja','cuenta_gl','cuenta_gl_temp','detalle_planilla','diccionario','documento','documento_identidad','estado_civil','formato_documento','forma_pago','hoja_planilla','modalidad_map','modalidad_pago','motivo','partida','persona','planilla','plantilla_clasificador','plantilla_gasto','secuencia','secuencia_documento','sucursal','tipo_afp','tipo_asiento','tipo_caja','tipo_concepto','tipo_persona','titulo','titulo_clasificador','titulo_indice']::text[]));
end $fn$;

revoke all on function myg_nube_privado.central_preservacion_esquema(text),
    myg_nube_privado.central_validar_catalogo(jsonb) from public,anon,authenticated,service_role;
revoke all on function public.myg_central_preservacion_capacidades() from public,anon;
grant execute on function public.myg_central_preservacion_capacidades() to authenticated,service_role;
notify pgrst,'reload schema';
commit;
