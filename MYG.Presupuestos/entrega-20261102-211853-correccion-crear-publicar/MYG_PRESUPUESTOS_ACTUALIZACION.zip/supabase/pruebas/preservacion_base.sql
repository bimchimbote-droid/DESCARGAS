-- SOLO PostgreSQL DESECHABLE. Nunca ejecutar en Supabase real.
\set ON_ERROR_STOP on
\ir base_central.sql
reset role;
\ir ../migraciones/20261107_preservacion_base.sql
\ir ../migraciones/20261107_preservacion_base.sql
select qa.exige(not has_function_privilege('anon','public.myg_central_preservacion_capacidades()','execute')
    and not has_function_privilege('authenticated','myg_nube_privado.central_preservacion_esquema(text)','execute')
    and not has_function_privilege('authenticated','myg_nube_privado.central_validar_catalogo(jsonb)','execute')
    and not has_table_privilege('authenticated','myg_nube_privado.central_bases','select'),
    'Preservación: capacidad autenticada y auxiliares/tablas siguen privadas');
create table qa.preservacion_catalogo as
select jsonb_build_object('formato','MYG_CATALOGO_BASE','version',1,'tablas',jsonb_agg(
    jsonb_build_object('Nombre',nombre,'Columnas',esquema->'columnas','Filas',jsonb_build_array(
        (select jsonb_agg(jsonb_build_object('Tipo',case when esquema->'claves' ? columna then 'texto' else 'nulo' end,
            'Valor',case when esquema->'claves' ? columna then 'PRIVADO-EXTRA-'||nombre else null end) order by orden)
        from jsonb_array_elements_text(esquema->'columnas') with ordinality columnas(columna,orden)))) order by nombre),
    'recursos','[]'::jsonb) contenido
from (select nombre,myg_nube_privado.central_preservacion_esquema(nombre) esquema
    from unnest(array['cargo','clase_gl','concepto','costo_partida','cuenta','cuenta_caja','cuenta_gl','cuenta_gl_temp',
        'detalle_planilla','diccionario','documento','documento_identidad','estado_civil','formato_documento','forma_pago',
        'hoja_planilla','modalidad_map','modalidad_pago','motivo','partida','persona','planilla','plantilla_clasificador',
        'plantilla_gasto','secuencia','secuencia_documento','sucursal','tipo_afp','tipo_asiento','tipo_caja','tipo_concepto',
        'tipo_persona','titulo','titulo_clasificador','titulo_indice']) nombres(nombre)) tablas;
grant select on qa.preservacion_catalogo to authenticated;
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.exige(public.myg_central_preservacion_capacidades()->>'version'='1'
    and jsonb_array_length(public.myg_central_preservacion_capacidades()->'tablas_adicionales')=35,
    'Preservación: declara las 35 tablas de la captura sin cambiar el protocolo central');
select qa.exige(public.myg_central_capacidades()->>'version'='1',
    'Preservación: capacidad original conserva compatibilidad con clientes anteriores');
select public.myg_central_crear_base('d9a70000-0000-0000-0000-000000000001','Preservación privada QA',
    'c9a70000-0000-0000-0000-000000000001','[{"documento_id":"QA-DOCUMENTO","nombre":"Obra A"},{"documento_id":"QA-DOCUMENTO-B","nombre":"Obra B"}]');
select public.myg_central_preparar('c9a70000-0000-0000-0000-000000000001','QA-DOCUMENTO',contenido)
    from qa.central_payload where nombre='baseline';
select public.myg_central_preparar('c9a70000-0000-0000-0000-000000000001','QA-DOCUMENTO-B',contenido)
    from qa.central_payload where nombre='segunda';
select qa.exige((select public.myg_central_preparar_catalogo('c9a70000-0000-0000-0000-000000000001',contenido)->>'estado'='preparado'
    from qa.preservacion_catalogo),'Preservación: admite todas las tablas adicionales conocidas sin descartarlas');
select qa.exige((select public.myg_central_preparar_catalogo('c9a70000-0000-0000-0000-000000000001',contenido)->>'estado'='preparado'
    from qa.preservacion_catalogo),'Preservación: retransmisión del mismo catálogo es idempotente');
select qa.rechaza($$select public.myg_central_preparar_catalogo('c9a70000-0000-0000-0000-000000000001',
    jsonb_set(contenido,'{tablas,0,Filas,0,0,Valor}','"OTRO"')) from qa.preservacion_catalogo$$,'22023',
    'Preservación: UUID no permite reemplazar un catálogo ya preparado');
select public.myg_central_activar('c9a70000-0000-0000-0000-000000000001');
select qa.exige((select public.myg_central_catalogo('d9a70000-0000-0000-0000-000000000001')=contenido from qa.preservacion_catalogo),
    'Preservación: propietario recupera íntegramente las 35 tablas y sus valores');
create temporary table preservacion_vistas as
    select * from jsonb_array_elements(public.myg_central_obras('d9a70000-0000-0000-0000-000000000001'));
select public.myg_base_compartir_usuario((value->>'id')::uuid,'ajeno','editor',
    '{"acu":true,"especificaciones":true,"metrados_excel":true,"metrados_revit":true}')
    from preservacion_vistas where value->>'documento_id'='QA-DOCUMENTO';
reset role;
grant select on preservacion_vistas to authenticated;
select qa.exige(not exists(select 1 from myg_nube_privado.central_documentos
    where base_id='d9a70000-0000-0000-0000-000000000001' and contenido::text like '%PRIVADO-EXTRA-%')
    and (select count(*)=1 from myg_nube_privado.central_bases where base_id='d9a70000-0000-0000-0000-000000000001'),
    'Preservación: datos adicionales se guardan una vez en la base, no dentro de cada obra');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.exige(jsonb_array_length(public.myg_central_obras('d9a70000-0000-0000-0000-000000000001'))=1,
    'Preservación: ampliar respaldo propietario no amplía la membresía de obras');
select qa.rechaza($$select public.myg_central_catalogo('d9a70000-0000-0000-0000-000000000001')$$,'42501',
    'Preservación: colaborador no obtiene tablas de personas, cuentas ni obras ajenas');
select qa.exige((select public.myg_central_abrir((value->>'id')::uuid)::text not like '%PRIVADO-EXTRA-%'
    from preservacion_vistas where value->>'documento_id'='QA-DOCUMENTO'),
    'Preservación: abrir obra autorizada no entrega datos adicionales del propietario');
select qa.rechaza($$select public.myg_central_abrir((value->>'id')::uuid)
    from preservacion_vistas where value->>'documento_id'='QA-DOCUMENTO-B'$$,'42501',
    'Preservación: conocer UUID de otra obra no concede acceso');
select qa.rechaza($$select public.myg_central_preparar_catalogo('c9a70000-0000-0000-0000-000000000001',contenido)
    from qa.preservacion_catalogo$$,'42501','Preservación: colaborador no puede alterar preparación privada');
select qa.rechaza($$select catalogo from myg_nube_privado.central_bases$$,'42501',
    'Preservación: tablas privadas siguen sin acceso SQL directo');
reset role;
select qa.rechaza($$select myg_nube_privado.central_validar_catalogo(
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"usuario","Columnas":["id"],"Filas":[]}],"recursos":[]}')$$,
    '22023','Preservación: nunca admite tabla de credenciales');
select qa.rechaza($$select myg_nube_privado.central_validar_catalogo(
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"cargo","Columnas":["id_cargo","password_privado"],"Filas":[]}],"recursos":[]}')$$,
    '22023','Preservación: rechaza columnas fuera del esquema confiable');
select qa.rechaza($$select myg_nube_privado.central_validar_catalogo(
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"cargo","Columnas":["descripcion_cargo"],"Filas":[]}],"recursos":[]}')$$,
    '22023','Preservación: exige las claves originales para conservar las identidades');
select qa.rechaza($$select myg_nube_privado.central_validar_catalogo(
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"cargo","Columnas":["id_cargo"],"Filas":[[{"Tipo":"sql","Valor":"DROP TABLE usuario"}]]}],"recursos":[]}')$$,
    '22023','Preservación: contenido recibido es dato tipado y no SQL ejecutable');
select myg_nube_privado.central_validar_catalogo(
    '{"formato":"MYG_CATALOGO_BASE","version":1,"tablas":[{"Nombre":"catalogo_unidad","Columnas":["codigo"],"Filas":[]}],"recursos":[]}');
select qa.exige(true,
    'Preservación: catálogos anteriores siguen siendo válidos');
