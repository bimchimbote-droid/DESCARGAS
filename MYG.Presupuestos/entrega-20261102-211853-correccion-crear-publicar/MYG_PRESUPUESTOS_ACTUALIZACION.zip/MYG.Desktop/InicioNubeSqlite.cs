#nullable enable
using System.IO;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private PublicacionesSqliteEnCola ColaPublicacionesSqliteDe(ClienteSupabase cliente) => new(
        Path.Combine(CarpetaNube, "publicaciones-sqlite"), cliente.UrlServidor, cliente.UsuarioId!);

    private async Task<bool> GestionarPublicacionSqlitePendiente(ClienteSupabase cliente)
    {
        var cola = ColaPublicacionesSqliteDe(cliente);
        var pendientes = await Task.Run(cola.Listar);
        ComprobarClienteActual(cliente);
        if (pendientes.Count == 0) return false;
        using var dialogo = new PublicacionesSqlitePendientesForm(cola, () => ComprobarClienteActual(cliente));
        var opcion = dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this);
        ComprobarClienteActual(cliente);
        if (opcion == WinForms.DialogResult.Retry && dialogo.ParaReintentar is { } elegida)
            await PublicarProyectoSqliteNube(elegida);
        else if (opcion == WinForms.DialogResult.OK) await PublicarProyectoSqliteNube();
        return true;
    }

    private async Task PublicarProyectoSqliteNube(PublicacionSqliteEnCola? reintento = null)
    {
        var cliente = RequerirNube();
        var ventana = ventanaNube ?? throw new InvalidOperationException("Abra Nube MYG para publicar.");
        if (await cliente.AdmiteCentralAsync())
        {
            await PublicarBaseCentralAsync(cliente, ventana, reintento);
            return;
        }
        // Una creación nueva nunca adopta el intento de otra selección. Sólo
        // Publicaciones pendientes puede proporcionar un reintento explícito.
        var almacen = reintento?.Almacen ?? ColaPublicacionesSqliteDe(cliente).Nuevo();
        var pendiente = reintento?.Pendiente;
        ComprobarClienteActual(cliente);
        if (pendiente is not null && pendiente.Alcance != "base")
            throw new InvalidOperationException("El intento contiene una obra del formato anterior. Su copia se conserva; retírelo explícitamente en Publicaciones pendientes si desea crear una base nueva.");
        if (pendiente is not null && File.Exists(Path.Combine(pendiente.RutaSQLite + ".central-publicacion", "intento.json")))
            throw new InvalidOperationException("Esta publicación se preparó para Supabase central. Actualice la conexión antes de reintentar; no se enviará por otro formato.");
        var ct = ventana.ComenzarPublicacion();
        bool confirmado = false;
        try
        {
            ventana.InformarProgresoPublicacion("Comprobando el almacenamiento de archivos SQLite…");
            if (!await cliente.AdmiteSqliteAsync(ct))
                throw new NubeException("Instale 20261030_archivos_sqlite.sql en Supabase antes de publicar. La base local se conserva; no se enviará comprimida ni convertida a JSON.");
            ComprobarClienteActual(cliente);
            if (pendiente is null)
            {
                var activo = pestanasProyectos.SelectedTab?.Tag as EditorForm;
                string? rutaAbierta = activo?.RutaProyecto ?? rutaBase;
                using var dialogo = new NubePublicarForm(null, rutaAbierta);
                if (dialogo.ShowDialog(ventana) != WinForms.DialogResult.OK) return;
                ComprobarClienteActual(cliente); ct.ThrowIfCancellationRequested();
                string? origen = dialogo.RutaSQLite;
                if (dialogo.CrearVacia)
                {
                    var nueva = dialogo.Documento ?? throw new InvalidOperationException("No se preparó la base nueva.");
                    origen = Path.Combine(CarpetaNube, "bases-nuevas", Guid.NewGuid().ToString("N"), "base.sqlite");
                    string rutaNueva = origen;
                    await Task.Run(() => MYGProyectoStorage.Guardar(rutaNueva, nueva), ct);
                }
                string fuente = origen ?? throw new InvalidOperationException("Seleccione una base SQLite.");
                string idPrincipal = dialogo.DocumentoPrincipalId ?? throw new InvalidOperationException("La base no contiene obras.");
                ventana.InformarProgresoPublicacion("Preparando una sola base SQLite con todas sus obras…");
                pendiente = await MYGCargaAnimada.EjecutarConProgresoAsync(this,
                    "Preparando la base completa para publicar…", async progreso =>
                    {
                        await PrepararPublicacionBaseAsync(fuente);
                        return await Task.Run(() =>
                        {
                            var documento = MYGBaseDatos.LeerProyecto(fuente, idPrincipal);
                            return almacen.Crear(dialogo.Nombre, "base", documento, fuente, ct, progreso);
                        }, ct);
                    });
            }
            var envio = pendiente;
            ventana.InformarProgresoPublicacion("Verificando la copia local pendiente…");
            envio = await Task.Run(() => almacen.Leer(envio), ct);
            ComprobarClienteActual(cliente); ct.ThrowIfCancellationRequested();
            var progreso = new Progress<string>(texto =>
            {
                if (!ventana.IsDisposed && !confirmado && !ct.IsCancellationRequested)
                    ventana.InformarProgresoPublicacion(texto);
            });
            var remoto = await Task.Run(() => cliente.CrearSqliteAsync(envio.Id, envio.Nombre,
                envio.RutaSQLite, envio.Alcance, envio.DocumentoId, ct, progreso), ct);
            confirmado = true;
            ventana.PublicacionConfirmada();
            // Cerrar el intento solo después de recibir el ACK, sin rehacer la base.
            await Task.Run(() => almacen.Confirmar(envio));
            ComprobarClienteActual(cliente);
            await ventana.MostrarPublicacionConfirmadaAsync(remoto.Proyecto);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested && !confirmado)
        {
            ventana.InformarResultadoPublicacion("Se canceló la espera. La copia local y el identificador del intento se conservan para reintentar desde Publicaciones pendientes.");
        }
        finally { ventana.TerminarPublicacion(); }
    }

    private async Task AbrirProyectoSqliteNube(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        if (remoto.Proyecto.Alcance == "base")
        {
            await AbrirBaseNubeAsync(cliente, remoto);
            return;
        }
        var existente = EditoresAbiertos.FirstOrDefault(e => e.NubeProyectoId == remoto.Proyecto.Id
            && e.NubeServidor == cliente.UrlServidor && e.NubeUsuario == cliente.UsuarioId);
        if (existente is not null)
        {
            await existente.ActualizarNubeAsync(true);
            ComprobarClienteActual(cliente);
            SeleccionarEditor(existente); ventanaNube?.Hide(); return;
        }
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Proyecto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        var documento = await MYGCargaAnimada.EjecutarConProgresoAsync(this,
            "Abriendo el archivo SQLite de nube…", async progreso =>
        {
            return await Task.Run(async () =>
            {
                Directory.CreateDirectory(carpeta);
                if (File.Exists(ruta))
                {
                    var vinculo = CopiaSqliteNube.LeerVinculo(ruta, remoto.DocumentoId)
                        ?? throw new InvalidOperationException("La copia existente no tiene un vínculo SQLite válido. Consérvela antes de recuperar otra copia.");
                    SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
                    if (vinculo.ProyectoId != remoto.Proyecto.Id)
                        throw new InvalidOperationException("La copia corresponde a otro proyecto remoto.");
                    // Abrir nunca sustituye borradores locales. La recarga es explícita.
                    return ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, remoto.DocumentoId);
                }
                string temporal = Path.Combine(carpeta, "descarga-" + Guid.NewGuid().ToString("N") + ".sqlite");
                try
                {
                    await cliente.DescargarSqliteAsync(remoto, temporal, progreso: progreso);
                    var local = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(temporal, remoto.DocumentoId);
                    ComprobarClienteActual(cliente);
                    File.Move(temporal, ruta);
                    CopiaSqliteNube.Vincular(ruta, remoto, cliente);
                    return ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, local.Id);
                }
                finally { if (File.Exists(temporal)) File.Delete(temporal); }
            });
        });
        ComprobarClienteActual(cliente);
        var editor = AbrirEditor(documento, ruta);
        editor.ConfigurarNube(() => clienteNube,
            () => _ = IntentarAsync(() => ColaboracionObraBaseAsync(editor.RutaProyecto, editor.ProyectoId, agregar: false)),
            PrepararSincronizacionBaseAsync, ActualizarEditoresBaseAsync);
        ventanaNube?.Hide();
    }

    private async Task DescargarProyectoSqliteNube(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        using var dialogo = new WinForms.SaveFileDialog
        {
            Title = "Descargar archivo SQLite sin comprimir", Filter = "Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_NUBE.sqlite", DefaultExt = "sqlite", AddExtension = true
        };
        if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
        if (File.Exists(dialogo.FileName)) throw new IOException("Elija un archivo nuevo para conservar la copia existente.");
        string destino = dialogo.FileName;
        await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Descargando el archivo SQLite…", async progreso =>
        {
            await cliente.DescargarSqliteAsync(remoto, destino, progreso: progreso);
            return true;
        });
        ComprobarClienteActual(cliente);
        WinForms.MessageBox.Show(ventanaNube, "Archivo SQLite descargado desde la revisión " + remoto.Proyecto.Revision + ".",
            "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
    }
}
