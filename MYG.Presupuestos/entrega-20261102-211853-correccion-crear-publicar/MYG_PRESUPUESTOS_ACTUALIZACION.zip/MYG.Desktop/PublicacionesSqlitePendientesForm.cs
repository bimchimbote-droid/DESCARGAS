#nullable enable
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

/// <summary>Reintenta únicamente la fila elegida por el usuario.</summary>
public sealed class PublicacionesSqlitePendientesForm : WinForms.Form
{
    private readonly PublicacionesSqliteEnCola cola;
    private readonly Action comprobarCuenta;
    private readonly WinForms.DataGridView lista = MYGBibliotecaUI.Tabla();
    private readonly WinForms.Button reintentar, retirar;
    private readonly WinForms.Label detalle = new() { Dock = WinForms.DockStyle.Fill, AutoEllipsis = true };
    private bool ocupado;
    public PublicacionSqliteEnCola? ParaReintentar { get; private set; }

    public PublicacionesSqlitePendientesForm(PublicacionesSqliteEnCola cola, Action comprobarCuenta)
    {
        this.cola = cola; this.comprobarCuenta = comprobarCuenta;
        Name = "publicacionesSqlitePendientesDialogo";
        MYGProyectoUI.Preparar(this, "Publicaciones pendientes", 980, 530);
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, Padding = new(20), ColumnCount = 1, RowCount = 4 };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 65));
        raiz.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 60));
        raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, 54));
        raiz.Controls.Add(new WinForms.Label { Dock = WinForms.DockStyle.Fill, Text =
            "Seleccione la publicación que desea continuar. Crear / publicar permite elegir otra base o comenzar una nueva sin sustituir estos intentos. Retirar conserva el archivo local y no elimina datos de la nube." }, 0, 0);
        lista.Name = "listaPublicacionesSqlitePendientes";
        lista.ReadOnly = true; lista.MultiSelect = false;
        lista.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect;
        lista.AutoSizeColumnsMode = WinForms.DataGridViewAutoSizeColumnsMode.Fill;
        lista.Columns.Add("Nombre", "Publicación"); lista.Columns.Add("Fecha", "Preparada"); lista.Columns.Add("Tamano", "Archivo local");
        lista.SelectionChanged += (_, _) => ActualizarSeleccion();
        raiz.Controls.Add(lista, 0, 1); raiz.Controls.Add(detalle, 0, 2);
        var barra = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = false };
        var cerrar = MYGProyectoUI.Boton("Cerrar"); cerrar.DialogResult = WinForms.DialogResult.Cancel;
        var nueva = MYGProyectoUI.Boton("Crear nueva"); nueva.Name = "crearPublicacionSqliteNueva";
        nueva.Click += (_, _) =>
        {
            if (ocupado) return;
            try { comprobarCuenta(); DialogResult = WinForms.DialogResult.OK; }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        reintentar = MYGProyectoUI.Boton("Reintentar seleccionada", 1); reintentar.AutoSize = true; reintentar.Name = "reintentarPublicacionSqliteSeleccionada";
        reintentar.Click += (_, _) =>
        {
            if (ocupado || Actual is not { } entrada) return;
            try { comprobarCuenta(); ParaReintentar = entrada; DialogResult = WinForms.DialogResult.Retry; }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        retirar = MYGProyectoUI.Boton("Retirar y conservar copia"); retirar.AutoSize = true; retirar.Name = "retirarPublicacionSqliteSeleccionada";
        retirar.Click += async (_, _) =>
        {
            if (ocupado || Actual is not { } entrada) return;
            ocupado = true; ActualizarSeleccion();
            try { comprobarCuenta(); await Task.Run(() => entrada.Almacen.Retirar(entrada.Pendiente)); comprobarCuenta(); }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
            finally { ocupado = false; }
            await CargarAsync();
        };
        barra.Controls.AddRange(new WinForms.Control[] { cerrar, nueva, reintentar, retirar });
        raiz.Controls.Add(barra, 0, 3); Controls.Add(raiz); CancelButton = cerrar;
        Shown += async (_, _) => await CargarAsync();
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; };
        ActualizarSeleccion();
    }

    private PublicacionSqliteEnCola? Actual => lista.CurrentRow?.Tag as PublicacionSqliteEnCola;
    private void ActualizarSeleccion()
    {
        reintentar.Enabled = retirar.Enabled = !ocupado && Actual is not null;
        detalle.Text = Actual?.Pendiente.RutaSQLite ?? "No hay publicación seleccionada.";
    }
    private async Task CargarAsync()
    {
        if (ocupado) return;
        ocupado = true; ActualizarSeleccion();
        try
        {
            comprobarCuenta();
            var entradas = await Task.Run(cola.Listar);
            comprobarCuenta(); lista.Rows.Clear();
            foreach (var entrada in entradas)
            {
                var p = entrada.Pendiente;
                int i = lista.Rows.Add(p.Nombre, p.FechaUtc.ToLocalTime().ToString("g"), (p.BytesArchivo / 1024d).ToString("N1") + " KiB");
                lista.Rows[i].Tag = entrada;
            }
        }
        catch (Exception ex) { lista.Rows.Clear(); MYGProyectoUI.Error(this, ex); }
        finally { ocupado = false; ActualizarSeleccion(); }
    }
}
