using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly Dictionary<Control, MYGEspecificacionesRueda> ruedasHoja = new();
    private long ruedaPendienteHoja;
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal Action<MYGPresupuestoDocumento, ItemPresupuestoDelphin> AntesCambioZoomHoja { get; set; }
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal Action PresentacionHojaCambiada { get; set; }

    private void PrepararZoomRuedaHoja()
    {
        AsociarRuedaHoja(hoja);
        AsociarRuedaHoja(formula);
        hoja.EditingControlShowing += (_, e) => AsociarRuedaHoja(e.Control);
        Disposed += (_, _) =>
        {
            foreach (var rueda in ruedasHoja.Values) rueda.Dispose();
            ruedasHoja.Clear();
        };
    }
    private void AsociarRuedaHoja(Control control)
    {
        if (control == null || ruedasHoja.ContainsKey(control)) return;
        ruedasHoja.Add(control, new MYGEspecificacionesRueda(control, ZoomRuedaHoja));
    }

    // Intercept WM_MOUSEWHEEL before DataGridView/its edit control scrolls.
    // Layout changes never call EndEdit or replace the draft formula.
    private bool ZoomRuedaHoja(int delta, bool control, Point puntoPantalla)
    {
        if (!control) { ruedaPendienteHoja = 0; return false; }
        if (!HayPartida || !hoja.Visible || delta == 0 ||
            !(hoja.RectangleToScreen(hoja.ClientRectangle).Contains(puntoPantalla) ||
                formula.Visible && formula.RectangleToScreen(formula.ClientRectangle).Contains(puntoPantalla))) return false;
        // El zoom de esta hoja se persiste en el proyecto; el lector conserva
        // el desplazamiento normal sin producir una edición desde el filtro.
        if (!EdicionMetradosExcelNubePermitida) { ruedaPendienteHoja = 0; return true; }
        ruedaPendienteHoja += delta;
        long pasos = ruedaPendienteHoja / 120;
        ruedaPendienteHoja %= 120;
        if (pasos == 0) return true;
        int nuevo = (int)Math.Clamp(actual.Costos.Hoja.Zoom + pasos * 10, 25L, 300L);
        CambiarZoomHojaRapido(nuevo);
        return true;
    }

    private void CambiarZoomHojaRapido(int nuevo)
    {
        RequerirPartida();
        ExigirPermisoMetradosExcel();
        var h = actual.Costos.Hoja;
        nuevo = Math.Clamp(nuevo, 25, 300);
        if (nuevo == h.Zoom) return;
        // El editor principal captura únicamente el entero Zoom para deshacer;
        // no necesita clonar el proyecto entero ni calcular sus importes.
        if (AntesCambioZoomHoja != null) AntesCambioZoomHoja(P, actual);
        else antes();
        h.Zoom = nuevo;
        RefrescarPresentacionHoja();
        // Notificar la presentación por separado evita recalcular y firmar todo
        // el presupuesto en cada paso de la rueda. Conservar el callback antiguo
        // permite usar el panel en otros anfitriones sin cambiar su contrato.
        if (PresentacionHojaCambiada != null) PresentacionHojaCambiada();
        else despues();
    }

    internal void RefrescarPresentacionHoja()
    {
        if (!HayPartida || !hoja.Visible || hoja.RowCount == 0) return;
        var h = actual.Costos.Hoja;
        var editor = hoja.EditingControl as TextBoxBase;
        string texto = editor?.Text;
        int inicio = editor?.SelectionStart ?? 0, longitud = editor?.SelectionLength ?? 0;
        int primeraFila = hoja.FirstDisplayedScrollingRowIndex, desplazamiento = hoja.HorizontalScrollingOffset;
        bool previo = cargando; cargando = true;
        try
        {
            hoja.SuspendLayout();
            try
            {
                AplicarVistaHoja(true);
                foreach (DataGridViewRow fila in hoja.Rows)
                    foreach (DataGridViewCell celda in fila.Cells)
                        AplicarFormatoCeldaHoja(celda, h.Celdas.GetValueOrDefault(DireccionCelda(fila.Index, celda.ColumnIndex)));
            }
            finally { hoja.ResumeLayout(true); }
            // Restaurar el ancla después del único layout, cuando los límites
            // de las barras ya corresponden a las dimensiones nuevas.
            if (primeraFila >= 0 && primeraFila < hoja.RowCount && hoja.Rows[primeraFila].Visible && !hoja.Rows[primeraFila].Frozen)
                hoja.FirstDisplayedScrollingRowIndex = primeraFila;
            int ancho = hoja.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).Sum(c => c.Width);
            int visible = Math.Max(0, hoja.ClientSize.Width - (hoja.RowHeadersVisible ? hoja.RowHeadersWidth : 0) - SystemInformation.VerticalScrollBarWidth);
            hoja.HorizontalScrollingOffset = Math.Min(desplazamiento, Math.Max(0, ancho - visible));
            if (editor != null && !editor.IsDisposed && hoja.IsCurrentCellInEditMode)
            {
                var ancla = MYGHojaCalculo.Coordenadas(DireccionAnclaHoja(hoja.CurrentCell.RowIndex, hoja.CurrentCell.ColumnIndex));
                var fuenteEditor = hoja[ancla.Columna - 1, ancla.Fila - 1].InheritedStyle.Font;
                if (editor is MYGEditorTextoFormulaHoja editorFormula) editorFormula.CambiarFuenteSinHistorial(fuenteEditor);
                else editor.Font = fuenteEditor;
                // Reapplying the style must not discard a native editor's draft.
                if (editor.Text != texto) editor.Text = texto;
                editor.Select(Math.Min(inicio, editor.TextLength), Math.Min(longitud, Math.Max(0, editor.TextLength - inicio)));
            }
        }
        finally { cargando = previo; }
        var celdaActiva = hoja.CurrentCell;
        string direccionActiva = celdaActiva == null ? null : DireccionAnclaHoja(celdaActiva.RowIndex, celdaActiva.ColumnIndex);
        var estilo = direccionActiva == null ? null : MYGEdicionHoja.CopiarCelda(h.Celdas.GetValueOrDefault(direccionActiva));
        if (estilo != null) estilo.AlineacionHorizontal = MYGEdicionHoja.AlineacionCelda(h.Celdas.GetValueOrDefault(direccionActiva), direccionActiva);
        SincronizarCintaHoja(h, estilo);
        ActualizarColoresReferenciasHoja();
        hoja.Invalidate();
    }
}
