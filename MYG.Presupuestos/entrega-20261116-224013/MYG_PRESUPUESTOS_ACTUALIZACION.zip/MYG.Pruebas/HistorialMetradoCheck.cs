using System.Text.Json;
using MYG_2027;

internal static class HistorialMetradoCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Historial local de metrados", "Estructuras");
        var p = documento.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        var ajena = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        partida.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(partida.Costos.Hoja, p, ajena, "G16"));
        ajena.Costos.Hoja.Poner("G16", "7");
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        var costos = partida.Costos;
        var hojaAjena = ajena.Costos.Hoja;
        string formula = partida.Costos.Hoja.Celdas["B3"].Contenido;
        var anterior = MYGEntradaHistorialProyecto.CapturarHojaMetrado(documento, p, partida);
        Exige(anterior.EsHojaMetrado && !anterior.EsZoomMetrado && anterior.PresupuestoAfectadoId == p.Id &&
            anterior.PartidaAfectadaId == partida.Id, "La captura debe identificar únicamente la hoja editada.");
        partida.Costos.Hoja.Poner("B3", "99");
        partida.Costos.EspecificacionRtf = "Especificación editada después";
        partida.Costos.Cantidad = 88;
        partida.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        ajena.Costos.Hoja.Poner("G16", "12");
        ajena.Descripcion = "Partida ajena conservada";
        var inversa = anterior.CapturarInversa(documento);
        string estado = JsonSerializer.Serialize(documento);
        var candidato = anterior.CrearCandidato(documento);
        Exige(JsonSerializer.Serialize(documento) == estado &&
            candidato.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Hoja.Celdas["B3"].Contenido == formula,
            "Crear el candidato del historial no debe aplicar cambios al documento original.");
        Rechaza(() => MYGCambiosModulosNube.ExigirPermitidos(documento, candidato,
            new MYGPermisosModulos { MetradosExcel = false }));
        candidato.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Hoja.Poner("B3", "-900");
        Exige(ReferenceEquals(anterior.Aplicar(documento), documento) && ReferenceEquals(costos, partida.Costos) &&
            ReferenceEquals(hojaAjena, ajena.Costos.Hoja) && partida.Costos.Hoja.Celdas["B3"].Contenido == formula &&
            partida.Costos.EspecificacionRtf == "Especificación editada después" && partida.Costos.Cantidad == 88 &&
            partida.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad && ajena.Descripcion == "Partida ajena conservada",
            "Deshacer una hoja no debe restaurar otros módulos, cantidades, fuentes ni partidas ajenas.");
        Exige(new MYGHojaCalculo(partida.Costos.Hoja).Numero("B3") == 12,
            "La hoja restaurada debe vincular sus referencias con los valores actuales de otras partidas.");
        inversa.Aplicar(documento);
        Exige(partida.Costos.Hoja.Celdas["B3"].Contenido == "99", "Rehacer debe restaurar el contenido nuevo de la hoja.");
        partida.Costos.Hoja.Poner("B3", "123");
        anterior.Aplicar(documento);
        Exige(partida.Costos.Hoja.Celdas["B3"].Contenido == formula,
            "El candidato o una edición posterior no deben alterar la instantánea guardada de la hoja.");
        pasa("Historial local de hoja conserva fórmulas y referencias vigentes, aísla candidatos y no revierte otros módulos ni partidas");

        var zoom = MYGEntradaHistorialProyecto.CapturarZoomMetrado(documento, p, partida);
        var mismaHoja = partida.Costos.Hoja;
        partida.Costos.Hoja.Zoom = 150;
        partida.Costos.Hoja.Poner("A3", "Celda conservada al deshacer zoom");
        var rehacerZoom = zoom.CapturarInversa(documento);
        Exige(zoom.EsZoomMetrado && !zoom.EsHojaMetrado, "El zoom debe identificarse como una operación sólo de presentación.");
        zoom.Aplicar(documento);
        Exige(ReferenceEquals(mismaHoja, partida.Costos.Hoja) && partida.Costos.Hoja.Zoom == 100 &&
            partida.Costos.Hoja.Celdas["A3"].Contenido == "Celda conservada al deshacer zoom" &&
            partida.Costos.Cantidad == 88 && partida.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad,
            "Deshacer zoom debe cambiar sólo la ampliación, conservando la misma hoja y sus ediciones actuales.");
        rehacerZoom.Aplicar(documento);
        Exige(partida.Costos.Hoja.Zoom == 150, "Rehacer zoom debe recuperar su ampliación exacta.");
        var completa = MYGEntradaHistorialProyecto.Capturar(documento);
        documento = completa.Aplicar(MYGProyectoStorage.Copia(documento));
        p = documento.Presupuestos.Single();
        partida = p.Items.Single(i => i.Id == anterior.PartidaAfectadaId);
        zoom.Aplicar(documento);
        Exige(partida.Costos.Hoja.Zoom == 100,
            "Una instantánea completa intercalada no debe invalidar los IDs de una entrada de zoom.");
        pasa("Historial de zoom guarda un entero y mantiene deshacer/rehacer sin sustituir la hoja ni sus datos");

        var ajeno = MYGProyectoStorage.Copia(documento);
        ajeno.Id = MYGProyectoStorage.NuevoId();
        string ajenoAntes = JsonSerializer.Serialize(ajeno);
        Rechaza(() => anterior.Aplicar(ajeno));
        Rechaza(() => zoom.CrearCandidato(ajeno));
        Rechaza(() => zoom.CapturarInversa(ajeno));
        Exige(JsonSerializer.Serialize(ajeno) == ajenoAntes,
            "Una entrada ajena al proyecto no debe aplicar cambios parciales aunque coincidan los IDs de sus filas.");
        p.Items.Remove(partida);
        string sinPartida = JsonSerializer.Serialize(documento);
        Rechaza(() => anterior.Aplicar(documento));
        Rechaza(() => zoom.Aplicar(documento));
        Exige(JsonSerializer.Serialize(documento) == sinPartida,
            "Una entrada de metrado huérfana debe rechazarse sin modificar otras filas.");
        pasa("Historial de metrado rechaza proyectos ajenos y partidas eliminadas antes de alterar datos");

        var pesada = p.Items.Single();
        pesada.Costos.EspecificacionRtf = new string('X', 4 * 1024 * 1024);
        _ = MYGEntradaHistorialProyecto.CapturarHojaMetrado(documento, p, pesada);
        _ = MYGEntradaHistorialProyecto.CapturarZoomMetrado(documento, p, pesada);
        long inicio = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 10; n++) _ = MYGEntradaHistorialProyecto.CapturarHojaMetrado(documento, p, pesada);
        long memoriaHoja = GC.GetAllocatedBytesForCurrentThread() - inicio;
        inicio = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 100; n++) _ = MYGEntradaHistorialProyecto.CapturarZoomMetrado(documento, p, pesada);
        long memoriaZoom = GC.GetAllocatedBytesForCurrentThread() - inicio;
        Exige(memoriaHoja < 8 * 1024 * 1024 && memoriaZoom < 128 * 1024,
            "Capturar celdas o zoom volvió a copiar especificaciones o el documento completo.");
        pasa("Diez capturas de hoja y cien de zoom con una especificación de 4 MiB evitan copiar los datos ajenos al metrado");
    }

    private static void Rechaza(Action accion)
    {
        bool rechazado = false;
        try { accion(); }
        catch (InvalidOperationException) { rechazado = true; }
        Exige(rechazado, "Se aceptó una entrada de historial que no pertenece a la fila o al proyecto actual.");
    }
}
