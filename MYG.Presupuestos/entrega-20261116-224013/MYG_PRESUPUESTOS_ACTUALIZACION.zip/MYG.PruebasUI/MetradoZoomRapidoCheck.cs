using System;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG_2027;

internal static class MetradoZoomRapidoCheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Zoom de presentación", "ESTRUCTURAS");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(), Item = "01", TipoPropuesta = "PARTIDA", Posicion = 1,
            Descripcion = "Partida con hoja de metrado", Unidad = "m³",
            Costos = new MYGDatosPartida { Cantidad = 6m, PrecioDirecto = 25m }
        };
        presupuesto.Items.Add(partida);
        var modelo = partida.Costos.Hoja;
        modelo.Poner("A3", "Columna conservada");
        modelo.Poner("B3", "2"); modelo.Poner("C3", "3"); modelo.Poner("G3", "=B3*C3");
        modelo.Celdas["A3"].ColorFondo = "FFF2CC";
        int antesGenerico = 0, despuesGenerico = 0, capturasZoom = 0, cambiosVista = 0;
        using var panel = new MYGPanelPresupuesto(() => presupuesto, () => antesGenerico++, () => despuesGenerico++,
            _ => { }, () => Task.CompletedTask, _ => { });
        panel.InicializarEstructura(() => proyecto, _ => { }, _ => { }, (_, _, _) => { },
            () => Array.Empty<MYGUnidadCatalogo>());
        using var formulario = new Form { ClientSize = new Size(1600, 950), ShowInTaskbar = false };
        formulario.Controls.Add(panel); formulario.Show();
        panel.Refrescar(); panel.SeleccionarEstructura(partida);
        var pagina = Campo<TabPage>(panel, "paginaExcel");
        ((TabControl)pagina.Parent).SelectedTab = pagina;
        Application.DoEvents();
        var hoja = Campo<DataGridView>(panel, "hoja");
        hoja.CurrentCell = hoja[3, 6]; hoja.ClearSelection(); hoja.CurrentCell.Selected = true;
        hoja.FirstDisplayedScrollingRowIndex = 3;
        int primeraFila = hoja.FirstDisplayedScrollingRowIndex;
        var celdaActiva = hoja.CurrentCell;
        string original = JsonSerializer.Serialize(modelo);
        var genericos = (antesGenerico, despuesGenerico);
        int cambiosValor = 0, zoomAnterior = modelo.Zoom;
        hoja.CellValueChanged += (_, _) => cambiosValor++;
        panel.AntesCambioZoomHoja = (p, i) =>
        {
            exige(ReferenceEquals(p, presupuesto) && ReferenceEquals(i, partida),
                "El historial de zoom debe recibir únicamente el presupuesto y la partida activos.");
            zoomAnterior = i.Costos.Hoja.Zoom;
            capturasZoom++;
        };
        panel.PresentacionHojaCambiada = () =>
        {
            exige(modelo.Zoom != zoomAnterior,
                "La notificación de presentación debe llegar después de cambiar el zoom.");
            cambiosVista++;
        };
        var punto = hoja.PointToScreen(new Point(10, 10));
        exige(!Rueda(120, false) && modelo.Zoom == 100 && capturasZoom == 0,
            "La rueda sin Control debe conservar su desplazamiento normal, sin capturar historial de zoom.");
        for (int n = 0; n < 5; n++) { Rueda(120, true); Rueda(-120, true); }
        exige(modelo.Zoom == 100 && capturasZoom == 10 && cambiosVista == 10 && cambiosValor == 0 &&
            (antesGenerico, despuesGenerico) == genericos && ReferenceEquals(hoja.CurrentCell, celdaActiva) &&
            hoja.FirstDisplayedScrollingRowIndex == primeraFila && JsonSerializer.Serialize(modelo) == original,
            "Una ráfaga de zoom debe usar historial ligero, conservar selección y desplazamiento y no reescribir valores ni invocar copias o avisos generales del documento.");

        Invocar("EjecutarComandoHoja", "zoom_mas");
        Invocar("EjecutarComandoHoja", "zoom_100");
        exige(modelo.Zoom == 100 && capturasZoom == 12 && cambiosVista == 12 && cambiosValor == 0 &&
            (antesGenerico, despuesGenerico) == genericos,
            "Los botones de zoom deben utilizar la misma actualización de presentación, sin recalcular celdas ni el presupuesto.");

        hoja.Focus();
        exige(hoja.BeginEdit(true) && hoja.EditingControl is TextBoxBase,
            "La prueba debe mantener un borrador en el editor real de la celda.");
        var editor = (TextBoxBase)hoja.EditingControl;
        editor.Text = "=SUM(B3:C3)"; editor.Select(5, 2);
        Rueda(120, true);
        exige(modelo.Zoom == 110 && ReferenceEquals(hoja.EditingControl, editor) && editor.Text == "=SUM(B3:C3)" &&
            editor.SelectionStart == 5 && editor.SelectionLength == 2 && !modelo.Celdas.ContainsKey("D7") &&
            (antesGenerico, despuesGenerico) == genericos && cambiosValor == 0,
            "Control más rueda debe conservar el texto, el editor y su selección sin confirmar el borrador ni recalcular sus valores.");
        hoja.CancelEdit(); hoja.EndEdit(); Application.DoEvents();

        int capturasAntes = capturasZoom, avisosAntes = cambiosVista;
        modelo.Zoom = 150;
        panel.RefrescarPresentacionHoja();
        exige(capturasZoom == capturasAntes && cambiosVista == avisosAntes && modelo.Zoom == 150,
            "Refrescar la presentación al deshacer debe aplicar el zoom ya restaurado sin crear otra entrada de historial ni marcar una nueva edición.");
        panel.ConfigurarPermisoNube(() => false);
        int bloqueado = modelo.Zoom;
        exige(Rueda(120, true) && modelo.Zoom == bloqueado && capturasZoom == capturasAntes && cambiosVista == avisosAntes,
            "El zoom persistente de una hoja de solo lectura debe conservar las guardas y no generar cambios desde la rueda.");

        bool Rueda(int delta, bool control) => (bool)Invocar("ZoomRuedaHoja", delta, control, punto);
        object Invocar(string nombre, params object[] parametros) =>
            typeof(MYGPanelPresupuesto).GetMethod(nombre, Privados).Invoke(panel, parametros);
    }

    private static T Campo<T>(object objeto, string nombre) =>
        (T)objeto.GetType().GetField(nombre, Privados).GetValue(objeto);
}
