using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    // Insertar o quitar una rama no cambia los controles ni los cálculos de
    // los otros presupuestos. Mantener sus filas evita reconstruir el proyecto.
    internal void RefrescarEstructuraEditada(MYGPresupuestoDocumento presupuesto,
        object seleccion = null, bool editarNombre = false)
    {
        if (IsDisposed || presupuesto == null) return;
        FinalizarEdicion();
        var anteriores = filasEstructura.Where(f => propietariosEstructura.GetValueOrDefault(f)?.Id == presupuesto.Id).ToList();
        if (buscar.Text.Trim().Length > 0 || anteriores.Count == 0)
        {
            if (seleccion != null) SeleccionarEstructura(seleccion, editarNombre);
            else Refrescar();
            return;
        }
        string elegido = IdNodoEstructura(seleccion ?? nodoEstructura);
        string columna = editarNombre ? "DESC" : estructura.CurrentCell?.OwningColumn.Name ?? "DESC";
        var porId = anteriores.ToDictionary(f => IdNodoEstructura(f.Tag));
        var nuevas = new List<DataGridViewRow>();
        var hijos = presupuesto.Items.ToLookup(i => i.ParentId ?? "");
        var visitados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool previo = cargando;
        var ajuste = estructura.AutoSizeRowsMode;
        cargando = true; estructura.SuspendLayout();
        estructura.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        try
        {
            DataGridViewRow Fila(object nodo, int nivel)
            {
                bool nueva = !porId.TryGetValue(IdNodoEstructura(nodo), out var fila);
                if (nueva)
                {
                    fila = (DataGridViewRow)estructura.RowTemplate.Clone();
                    fila.CreateCells(estructura);
                }
                bool configurar = nueva || !ReferenceEquals(fila.Tag, nodo) || nivelesEstructura.GetValueOrDefault(fila) != nivel;
                fila.Tag = nodo;
                propietariosEstructura[fila] = presupuesto; nivelesEstructura[fila] = nivel;
                bool titulo = nodo is MYGPresupuestoDocumento || MYGProyectoStorage.EsTitulo((ItemPresupuestoDelphin)nodo);
                PonerValor(CeldaEstructura(fila, "ITEM"), nodo is ItemPresupuestoDelphin i ? CodigoEstructura(presupuesto, i) : presupuesto.Item);
                PonerValor(CeldaEstructura(fila, "DESC"), nodo is ItemPresupuestoDelphin item ? item.Descripcion : presupuesto.Nombre);
                if (configurar)
                {
                    CeldaEstructura(fila, "ITEM").ReadOnly = true;
                    CeldaEstructura(fila, "DESC").ReadOnly = false;
                    CeldaEstructura(fila, "CANT").ReadOnly = titulo;
                    CeldaEstructura(fila, "ITEM").Style.Padding = new(SangriaEstructura(fila) + (int)(20 * DeviceDpi / 96F), 4, 3, 4);
                    CeldaEstructura(fila, "DESC").Style.Padding = new((int)((nivel * 6 + 4) * DeviceDpi / 96F), 4, 4, 4);
                    fila.DefaultCellStyle.Font = titulo ? negrita : null;
                    fila.DefaultCellStyle.ForeColor = titulo ? MYG2027_TemaComercial.ColorTitulo(nivel) : MYG2027_TemaComercial.Texto;
                    fila.DefaultCellStyle.SelectionForeColor = SystemInformation.HighContrast ? SystemColors.HighlightText : fila.DefaultCellStyle.ForeColor;
                    if (nodo is ItemPresupuestoDelphin partida) ActualizarUnidadEstructura(fila, partida);
                    else CeldaEstructura(fila, "UND").ReadOnly = true;
                }
                if (nueva) PonerValor(CeldaEstructura(fila, "TOTAL"), 0m);
                nuevas.Add(fila);
                return fila;
            }
            Fila(presupuesto, 0);
            void Agregar(string padre, int nivel)
            {
                foreach (var item in hijos[padre].OrderBy(i => i.Posicion).ThenBy(i => i.Item))
                {
                    if (!visitados.Add(item.Id)) continue;
                    Fila(item, nivel); Agregar(item.Id, nivel + 1);
                }
            }
            Agregar("", 1);
            int inicio = filasEstructura.IndexOf(anteriores[0]);
            filasEstructura.RemoveRange(inicio, anteriores.Count);
            filasEstructura.InsertRange(inicio, nuevas);
            var conservadas = nuevas.ToHashSet();
            foreach (var fila in anteriores.Where(f => !conservadas.Contains(f)))
            {
                propietariosEstructura.Remove(fila); nivelesEstructura.Remove(fila); alertasPartidas.Remove(fila);
            }
            foreach (var fila in anteriores) expandiblesEstructura.Remove(IdNodoEstructura(fila.Tag));
            if (presupuesto.Items.Count > 0) expandiblesEstructura.Add(IdNodoEstructura(presupuesto));
            foreach (var grupo in hijos.Where(g => g.Key.Length > 0)) expandiblesEstructura.Add("I:" + grupo.Key);
            if (seleccion is ItemPresupuestoDelphin seleccionado)
            {
                contraidos.Remove(IdNodoEstructura(presupuesto));
                var items = presupuesto.Items.ToDictionary(i => i.Id);
                var padres = new HashSet<string>();
                string padre = seleccionado.ParentId;
                while (!string.IsNullOrWhiteSpace(padre) && padres.Add(padre))
                { contraidos.Remove("I:" + padre); padre = items.GetValueOrDefault(padre)?.ParentId; }
            }
            AplicarPlegadoEstructura(restaurarSeleccion: false);
            var elegida = nuevas.FirstOrDefault(f => IdNodoEstructura(f.Tag) == elegido && f.DataGridView == estructura)
                ?? nuevas.FirstOrDefault(f => f.DataGridView == estructura);
            estructura.ClearSelection(); estructura.CurrentCell = elegida == null ? null : CeldaEstructura(elegida, columna);
            if (elegida != null) elegida.Selected = true;
            // Sólo los códigos nuevos pueden exigir más ancho; la eliminación
            // conserva el ancho para evitar medir nuevamente todas las filas.
            foreach (var fila in nuevas.Where(f => !porId.ContainsKey(IdNodoEstructura(f.Tag))))
                estructura.Columns["ITEM"].Width = Math.Max(estructura.Columns["ITEM"].Width,
                    Math.Min(300, TextRenderer.MeasureText(Convert.ToString(CeldaEstructura(fila, "ITEM").Value), FuenteMedicionEstructura(fila)).Width + CeldaEstructura(fila, "ITEM").Style.Padding.Horizontal + 8));
        }
        finally
        { estructura.AutoSizeRowsMode = ajuste; estructura.ResumeLayout(); cargando = previo; }
        AplicarSeleccionEstructura(forzar: true, solicitarCalculos: false, recargarInsumos: false);
        ActualizarCalculosEstructura(presupuesto);
        CompletarRefrescoEstructura(presupuesto);
        if (seleccion != null) { MostrarVista(principal); estructura.Focus(); }
        if (editarNombre && estructura.CurrentRow != null)
        { estructura.CurrentCell = estructura.CurrentRow.Cells["DESC"]; estructura.BeginEdit(true); }
    }
}
