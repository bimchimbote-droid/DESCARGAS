using System;

namespace MYG_2027
{
    [Flags]
    internal enum MYGTipoRefresco
    {
        Ninguno = 0,
        Calculos = 1,
        Estructura = 2,
        Herramientas = 4
    }

    /// <summary>
    /// Agrupa solicitudes de refresco en el hilo de interfaz. Encolar debe publicar
    /// el trabajo para un mensaje posterior (por ejemplo, Control.BeginInvoke).
    /// </summary>
    internal sealed class MYGRefrescoDiferido
    {
        private readonly Action<Action> _encolar;
        private readonly Func<bool> _disponible;
        private readonly Action<MYGTipoRefresco> _aplicar;
        private MYGTipoRefresco _pendientes;
        private bool _programado;
        private bool _aplicando;
        private bool _cancelado;

        internal MYGRefrescoDiferido(Action<Action> encolar, Func<bool> disponible,
            Action<MYGTipoRefresco> aplicar)
        {
            _encolar = encolar ?? throw new ArgumentNullException(nameof(encolar));
            _disponible = disponible ?? throw new ArgumentNullException(nameof(disponible));
            _aplicar = aplicar ?? throw new ArgumentNullException(nameof(aplicar));
        }

        internal void Solicitar(MYGTipoRefresco tipo)
        {
            if (_cancelado || tipo == MYGTipoRefresco.Ninguno) return;
            _pendientes |= tipo;
            Programar();
        }

        internal void Reintentar()
        {
            Programar();
        }

        // El llamador ya aplicó este trabajo de forma síncrona. El mensaje
        // encolado permanece, pero no debe repetir lo que ya está actualizado.
        internal void Completar(MYGTipoRefresco tipo)
        {
            _pendientes &= ~tipo;
        }

        internal void Cancelar()
        {
            _cancelado = true;
            _pendientes = MYGTipoRefresco.Ninguno;
        }

        private void Programar()
        {
            if (_cancelado || _programado || _aplicando ||
                _pendientes == MYGTipoRefresco.Ninguno || !_disponible()) return;
            _programado = true;
            try { _encolar(Ejecutar); }
            catch
            {
                // Un handle perdido o una cola rechazada no debe bloquear las
                // solicitudes siguientes: el trabajo pendiente se conserva.
                _programado = false;
                throw;
            }
        }

        private void Ejecutar()
        {
            _programado = false;
            if (_cancelado || !_disponible()) return;
            MYGTipoRefresco tipo = _pendientes;
            _pendientes = MYGTipoRefresco.Ninguno;
            if (tipo == MYGTipoRefresco.Ninguno) return;
            _aplicando = true;
            try { _aplicar(tipo); }
            finally
            {
                _aplicando = false;
                // Las solicitudes hechas durante el refresco se procesan en
                // otro mensaje, después de terminar el refresco actual.
                Programar();
            }
        }
    }
}
