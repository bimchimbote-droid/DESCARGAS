using System.Linq;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private bool tablaBimEstructuraPendiente;

    // La tabla BIM es una herramienta modal. Mientras está cerrada no debe
    // reconstruir miles de celdas por cada inserción, eliminación o Ctrl+Z.
    private void RefrescarEstructuraRapida(MYGPresupuestoDocumento presupuestoEditado,
        object seleccion = null, bool editarNombre = false, bool pendiente = true)
    {
        MYGActivosRevit.LimpiarAsignacionesHuerfanas(documento);
        pendienteEstructuraRapidaConfirmado = ocupado ? pendiente : null;
        if (HerramientasBimVisibles)
        {
            Refrescar();
            if (seleccion != null) panelPresupuesto?.SeleccionarEstructura(seleccion, editarNombre);
            return;
        }

        tablaBimEstructuraPendiente = true;
        // Evitar que una fila antigua de la herramienta modal quede seleccionada
        // y se interprete como la partida activa después de borrar/deshacer.
        grid.ClearSelection();
        grid.CurrentCell = null;
        bool anterior = cargando;
        cargando = true;
        try
        {
            presupuesto.DataSource = documento.Presupuestos.ToList();
            presupuesto.SelectedItem = P;
        }
        finally { cargando = anterior; }
        panelPresupuesto?.RefrescarEstructuraEditada(presupuestoEditado, seleccion, editarNombre);
        ActualizarResumenConPendiente(pendiente);
        RefrescarCronogramaEditor();
    }
}
