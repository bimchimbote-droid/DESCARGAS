using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class EstructuraPresupuestosCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(MYGPresupuestoDocumento p) => JsonSerializer.Serialize(p);
    private static ItemPresupuestoDelphin Vigente(MYGPresupuestoDocumento p, ItemPresupuestoDelphin i) => p.Items.Single(x => x.Id == i.Id);
    private static void Rechaza(Action accion, string mensaje)
    {
        bool rechazo = false;
        try { accion(); } catch (InvalidOperationException) { rechazo = true; } catch (InvalidDataException) { rechazo = true; }
        Exige(rechazo, mensaje);
    }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var doc = new MYGProyectoDocumento { Nombre = "PROYECTO SIN PRESUPUESTOS" };
        string ruta = Path.Combine(carpeta, "Estructura proyecto vacío.sqlite");
        MYGProyectoStorage.Guardar(ruta, doc);
        Exige(MYGBaseDatos.LeerProyecto(ruta, doc.Id).Presupuestos.Count == 0, "SQLite no admite un proyecto sin presupuestos.");
        var primero = MYGEstructuraPresupuestos.AgregarPresupuesto(doc);
        var ultimo = MYGEstructuraPresupuestos.AgregarPresupuesto(doc);
        var intermedio = MYGEstructuraPresupuestos.AgregarPresupuesto(doc, ultimo);
        Exige(doc.Presupuestos.Select(x => x.Id).SequenceEqual(new[] { primero.Id, intermedio.Id, ultimo.Id }) &&
            doc.Presupuestos.Select(x => x.Item).SequenceEqual(new[] { "01", "02", "03" }) &&
            doc.PresupuestoActivoId == intermedio.Id, "Agregar sobre selección perdió el orden o la selección.");
        MYGProyectoStorage.Guardar(ruta, doc);
        var reabierto = MYGBaseDatos.LeerProyecto(ruta, doc.Id);
        Exige(reabierto.Presupuestos.Count == 3 && reabierto.Presupuestos.All(x => x.Items.Count == 0), "No se conservaron las raíces vacías.");
        pasa("Proyecto vacío y presupuestos agregados sobre selección/al final persisten en SQLite sin partidas artificiales");

        var titulo = MYGEstructuraPresupuestos.InsertarNodo(primero, true);
        var sub = MYGEstructuraPresupuestos.InsertarNodo(primero, true, titulo.Id);
        var partida = MYGEstructuraPresupuestos.InsertarNodo(primero, false, sub.Id);
        var encima = MYGEstructuraPresupuestos.InsertarNodo(primero, true, null, titulo.Id);
        Exige(Vigente(primero, encima).Item == "01" && Vigente(primero, partida).Item == "02.01.01" &&
            Vigente(primero, partida).IdLocalMYG == partida.Id, "Insertar alteró la jerarquía o identidades estables.");
        string antes = Firma(primero);
        Rechaza(() => MYGEstructuraPresupuestos.InsertarNodo(primero, false, partida.Id), "Una partida aceptó hijos.");
        Exige(Firma(primero) == antes, "La inserción inválida cambió el presupuesto.");
        var externa = MYGEstructuraPresupuestos.InsertarNodo(primero, false);
        Vigente(primero, externa).Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = partida.IdLocalMYG });
        antes = Firma(primero);
        Rechaza(() => MYGEstructuraPresupuestos.EliminarNodo(primero, titulo), "Se borró un subanálisis todavía usado.");
        Exige(Firma(primero) == antes, "Un borrado rechazado perdió datos.");
        Vigente(primero, externa).Costos.Analisis.Clear();
        Vigente(primero, partida).IdInternoDelphin = "OFICIAL";
        antes = Firma(primero);
        Rechaza(() => MYGEstructuraPresupuestos.EliminarNodo(primero, titulo), "Se eliminó una fila oficial descendiente.");
        Exige(Firma(primero) == antes, "Eliminar un título oficial cambió el presupuesto.");
        Vigente(primero, partida).IdInternoDelphin = null;
        MYGEstructuraPresupuestos.EliminarNodo(primero, titulo);
        Exige(primero.Items.Count == 2 && !primero.Items.Any(x => x.Id == sub.Id || x.Id == partida.Id), "Eliminar título no eliminó todos sus descendientes.");
        pasa("Inserción anidada y eliminación protegen filas oficiales, subanálisis externos y atomicidad");

        var conectado = new MYGPresupuestoDocumento
        {
            Nombre = "OFICIAL",
            Conexion = new MYGConexionDelphin
            { FuenteId = "BASE", ProyectoId = "OBRA", PresupuestoId = "PP", RutaSQLite = "origen.sqlite" }
        };
        var oficial = MYGEstructuraPresupuestos.InsertarNodo(conectado, true);
        oficial.Item = "05.09"; oficial.IdInternoDelphin = "OFICIAL";
        var propuesta = MYGEstructuraPresupuestos.InsertarNodo(conectado, false, oficial.Id);
        Exige(Vigente(conectado, oficial).Item == "05.09" && !string.IsNullOrWhiteSpace(propuesta.Item),
            "Insertar en un presupuesto conectado cambió la numeración oficial.");
        MYGEstructuraPresupuestos.EliminarNodo(conectado, propuesta);
        Exige(Vigente(conectado, oficial).Item == "05.09", "Eliminar una propuesta renumeró una fila oficial.");
        conectado.Conexion = null;
        MYGEstructuraPresupuestos.InsertarNodo(conectado, false, oficial.Id);
        Exige(Vigente(conectado, oficial).Item == "05.09", "La numeración oficial nativa cambió al no existir una conexión externa.");
        conectado.Item = "02";
        var docOficial = new MYGProyectoDocumento { Nombre = "CÓDIGOS OFICIALES" };
        docOficial.Presupuestos.Add(conectado);
        var localAntes = MYGEstructuraPresupuestos.AgregarPresupuesto(docOficial, conectado);
        var localDespues = MYGEstructuraPresupuestos.AgregarPresupuesto(docOficial);
        Exige(conectado.Item == "02" && localAntes.Item == "01" && localDespues.Item == "03",
            "Agregar presupuestos cambió el código oficial o duplicó su numeración.");
        pasa("Inserción y eliminación de propuestas mantienen la numeración oficial conectada y nativa sin conexión externa");

        var protegido = new MYGPresupuestoDocumento { Nombre = "CÓDIGOS SIN DUPLICADOS" };
        var raizProtegida = MYGEstructuraPresupuestos.InsertarNodo(protegido, true);
        raizProtegida.IdInternoDelphin = "TÍTULO-NATIVO"; raizProtegida.Item = "99";
        var quitarCodigo = MYGEstructuraPresupuestos.InsertarNodo(protegido, false);
        var conservarCodigo = MYGEstructuraPresupuestos.InsertarNodo(protegido, false);
        Vigente(protegido, quitarCodigo).Item = "P-002"; Vigente(protegido, conservarCodigo).Item = "P-003";
        MYGEstructuraPresupuestos.EliminarNodo(protegido, quitarCodigo);
        var reinsertada = MYGEstructuraPresupuestos.InsertarNodo(protegido, false);
        Exige(reinsertada.Item != "P-003" && Vigente(protegido, conservarCodigo).Item == "P-003",
            "Eliminar y reinsertar una propuesta produjo un código duplicado.");
        var hijoOficial = MYGEstructuraPresupuestos.InsertarNodo(protegido, false, raizProtegida.Id);
        hijoOficial.IdInternoDelphin = "PARTIDA-NATIVA"; hijoOficial.Item = "99.01";
        var copiaOficial = MYGEstructuraPresupuestos.CopiarRama(protegido, raizProtegida);
        MYGEstructuraPresupuestos.PegarRama(protegido, copiaOficial);
        Exige(protegido.Items.Select(x => x.Item).Distinct(StringComparer.OrdinalIgnoreCase).Count() == protegido.Items.Count &&
            Vigente(protegido, raizProtegida).Item == "99" && Vigente(protegido, hijoOficial).Item == "99.01" &&
            Vigente(protegido, conservarCodigo).Item == "P-003",
            "Pegar una rama oficial en el mismo presupuesto duplicó códigos o cambió los originales.");
        pasa("Eliminar/reinsertar propuestas y pegar ramas nativas usan códigos libres sin renumerar los originales");

        var fuente = FuenteConSubanalisis(out var principal, out var dependencia, out var raiz);
        MYGMotorPresupuestos.CapturarPrecioDelphin(fuente, principal, 12.01m, 72.06m);
        var fragmento = MYGEstructuraPresupuestos.CopiarRama(fuente, raiz);
        Exige(fragmento.Items.Count == 3 && fragmento.Costos.Insumos.Count == 1 && fragmento.Items.Any(x => x.Id == dependencia.Id),
            "La copia de un título omitió su dependencia externa.");
        var destino = new MYGPresupuestoDocumento { Nombre = "DESTINO" };
        var existente = MYGEstructuraPresupuestos.InsertarNodo(destino, true);
        var raices = MYGEstructuraPresupuestos.PegarRama(destino, fragmento, null, existente.Id);
        var copiada = destino.Items.Single(x => x.Descripcion == "PRINCIPAL");
        var depCopiada = destino.Items.Single(x => x.Descripcion == "SUBANÁLISIS");
        var recursoCopiado = depCopiada.Costos.Analisis.Single();
        Exige(raices.Count == 2 && raices[0].Descripcion == "RAMA" &&
            copiada.Id != principal.Id && copiada.IdLocalMYG == copiada.Id &&
            copiada.Costos.Analisis.Single().SubpartidaIdLocal == depCopiada.IdLocalMYG &&
            recursoCopiado.Id != dependencia.Costos.Analisis.Single().Id &&
            recursoCopiado.InsumoId == destino.Costos.Insumos.Single().Id &&
            destino.Costos.Insumos.Single().Id != fuente.Costos.Insumos.Single().Id &&
            destino.Items.All(x => x.IdInternoDelphin == null) &&
            copiada.Costos.Metrados.Count == 1 && copiada.Costos.MetradosBIM.Count == 1 &&
            MYGMotorPresupuestos.Cantidad(destino, copiada) == 6 &&
            MYGMotorPresupuestos.Analizar(destino, copiada).PrecioUnitario == 12.01m &&
            MYGMotorPresupuestos.TotalPartida(destino, copiada) == 72.06m &&
            MYGMotorPresupuestos.ConservaAnalisisDelphin(destino, copiada) &&
            copiada.Costos.FirmaAnalisisImportadoDelphin != principal.Costos.FirmaAnalisisImportadoDelphin,
            "El pegado perdió el ACU, las identidades, los metrados o el redondeo nativo.");
        copiada.Costos.Metrados[0].Descripcion = "COPIA EDITADA";
        Exige(principal.Costos.Metrados[0].Descripcion == "Original" && fragmento.Items.Single(x => x.Id == principal.Id).Costos.Metrados[0].Descripcion == "Original",
            "La copia comparte datos mutables con su origen.");
        pasa("Copiar y pegar título incluye subanálisis externos, remapea recursos/insumos y conserva metrados por copia");

        var sinMetrados = new MYGPresupuestoDocumento { Nombre = "SIN METRADOS" };
        MYGEstructuraPresupuestos.PegarRama(sinMetrados, fragmento, conMetrados: false);
        var limpia = sinMetrados.Items.Single(x => x.Descripcion == "PRINCIPAL");
        Exige(limpia.Costos.Cantidad == 0 && limpia.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad &&
            limpia.Costos.Metrados.Count == 0 && limpia.Costos.MetradosBIM.Count == 0 &&
            new MYGHojaCalculo(limpia.Costos.Hoja).Numero(limpia.Costos.Hoja.CeldaTotal) == 0 &&
            limpia.Costos.CantidadImportadaDelphin == null && limpia.Costos.ParcialImportadoDelphin == null &&
            MYGMotorPresupuestos.Analizar(sinMetrados, limpia).PrecioUnitario == 12.01m,
            "Pegado especial quitó el precio/redondeo o dejó metrados ocultos.");
        var otraPrecision = new MYGPresupuestoDocumento { Nombre = "OTRA PRECISIÓN" };
        otraPrecision.Costos.DecimalesPrecio = 3;
        MYGEstructuraPresupuestos.PegarRama(otraPrecision, fragmento);
        Exige(MYGMotorPresupuestos.Analizar(otraPrecision, otraPrecision.Items.Single(x => x.Descripcion == "PRINCIPAL")).PrecioUnitario == 12,
            "El pegado impuso el redondeo importado sobre otra precisión del destino.");
        MYGEstructuraPresupuestos.EliminarMetrados(destino, new[] { raices[0] });
        Exige(destino.Items.Single(x => x.Descripcion == "PRINCIPAL").Costos.MetradosBIM.Count == 0 &&
            MYGMotorPresupuestos.Cantidad(destino, destino.Items.Single(x => x.Descripcion == "PRINCIPAL")) == 0,
            "Eliminar metrados sobre título no limpió sus descendientes.");
        var todo = MYGEstructuraPresupuestos.CopiarRama(fuente, null);
        Exige(todo.Items.Count == fuente.Items.Count, "Copiar presupuesto completo omitió filas.");
        fuente.Costos.Insumos.Add(new MYGInsumo { Descripcion = "INSUMO SIN USO", Unidad = "und", Precio = 11 });
        todo = MYGEstructuraPresupuestos.CopiarRama(fuente);
        var destinoCompleto = new MYGPresupuestoDocumento { Nombre = "COPIA COMPLETA" };
        MYGEstructuraPresupuestos.PegarRama(destinoCompleto, todo);
        Exige(todo.Costos.Insumos.Count == 2 && destinoCompleto.Costos.Insumos.Count == 2 &&
            destinoCompleto.Costos.Insumos.All(x => !fuente.Costos.Insumos.Any(y => y.Id == x.Id)),
            "La copia completa eliminó los insumos sin uso o reutilizó sus identidades.");
        pasa("Pegado especial y eliminación de metrados limpian cantidad, BIM, Excel y cachés sin quitar el análisis");

        var convertir = new MYGProyectoDocumento { Nombre = "CONVERSIÓN" };
        convertir.Presupuestos.Add(fuente);
        principal.IdInternoDelphin = null;
        string proyectoAntes = MYGProyectoStorage.Firma(convertir);
        Rechaza(() => MYGEstructuraPresupuestos.ConvertirTitulo(convertir, fuente, raiz), "Se movió una rama con un subanálisis externo.");
        Exige(MYGProyectoStorage.Firma(convertir) == proyectoAntes, "Una conversión rechazada modificó el proyecto.");
        principal.ParentId = raiz.Id; dependencia.ParentId = raiz.Id;
        principal.IdInternoDelphin = "OFICIAL";
        proyectoAntes = MYGProyectoStorage.Firma(convertir);
        Rechaza(() => MYGEstructuraPresupuestos.ConvertirTitulo(convertir, fuente, raiz), "Se convirtió una rama oficial de Delphin.");
        Exige(MYGProyectoStorage.Firma(convertir) == proyectoAntes, "Una conversión oficial rechazada cambió el proyecto.");
        principal.IdInternoDelphin = null;
        raiz.Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "RESPONSABLE DE RAMA", Cargo = "Supervisor" });
        var nuevo = MYGEstructuraPresupuestos.ConvertirTitulo(convertir, fuente, raiz);
        Exige(nuevo.Nombre == "RAMA" && nuevo.Items.Count == 2 && nuevo.Items.All(x => x.ParentId == null) &&
            nuevo.Items.Any(x => x.Id == principal.Id && x.IdLocalMYG == principal.IdLocalMYG) &&
            nuevo.Costos.Insumos.Single().Id == fuente.Costos.Insumos.Single(x => x.Descripcion == "MATERIAL").Id &&
            fuente.Items.Count == 0 && convertir.PresupuestoActivoId == nuevo.Id &&
            nuevo.IdPresupuestoRevit != fuente.IdPresupuestoRevit, "La conversión perdió identidad o mezcló ámbitos Revit.");
        Exige(nuevo.Costos.Responsables.Single().Nombre == "RESPONSABLE DE RAMA", "Convertir un título perdió sus responsables.");
        nuevo.Costos.Insumos.Single().Precio = 7;
        Exige(fuente.Costos.Insumos.Single(x => x.Descripcion == "MATERIAL").Precio == 3, "Los presupuestos convertidos comparten un recurso mutable.");
        var vacio = MYGEstructuraPresupuestos.InsertarNodo(fuente, true);
        var presupuestoVacio = MYGEstructuraPresupuestos.ConvertirTitulo(convertir, fuente, vacio);
        Exige(presupuestoVacio.Items.Count == 0, "Un título vacío no se convirtió en presupuesto vacío.");
        MYGProyectoStorage.Guardar(Path.Combine(carpeta, "Estructura conversión.sqlite"), convertir);
        var guardado = MYGBaseDatos.LeerProyecto(Path.Combine(carpeta, "Estructura conversión.sqlite"), convertir.Id);
        Exige(guardado.Presupuestos.Single(x => x.Id == nuevo.Id).Items.Single(x => x.Id == principal.Id).Costos.MetradosBIM.Count == 1,
            "SQLite perdió los metrados de una rama convertida.");
        pasa("Convertir título conserva identidades, recursos y metrados y bloquea referencias cruzadas antes de mover datos");

        var responsables = MYGProyectoStorage.Nuevo("RESPONSABLES"); var conResponsables = responsables.Presupuestos.Single();
        var tituloResponsable = MYGEstructuraPresupuestos.InsertarNodo(conResponsables, true);
        var partidaResponsable = MYGEstructuraPresupuestos.InsertarNodo(conResponsables, false, tituloResponsable.Id);
        conResponsables.Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "ANA", Cargo = "Jefa de proyecto" });
        Vigente(conResponsables, tituloResponsable).Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "LUIS", Cargo = "Residente" });
        partidaResponsable.Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "ROSA", Cargo = "Metrados" });
        string rutaResponsables = Path.Combine(carpeta, "Estructura responsables.sqlite");
        MYGProyectoStorage.Guardar(rutaResponsables, responsables);
        var leidos = MYGBaseDatos.LeerProyecto(rutaResponsables, responsables.Id).Presupuestos.Single();
        Exige(leidos.Costos.Responsables.Single().Nombre == "ANA" &&
            Vigente(leidos, tituloResponsable).Costos.Responsables.Single().Nombre == "LUIS" &&
            Vigente(leidos, partidaResponsable).Costos.Responsables.Single().Cargo == "Metrados",
            "SQLite mezcló los responsables de presupuesto, título y partida.");
        var fragmentoResponsables = MYGEstructuraPresupuestos.CopiarRama(conResponsables, tituloResponsable);
        var copiadosResponsables = new MYGPresupuestoDocumento { Nombre = "RESPONSABLES COPIADOS" };
        MYGEstructuraPresupuestos.PegarRama(copiadosResponsables, fragmentoResponsables);
        copiadosResponsables.Items.First(x => MYGProyectoStorage.EsTitulo(x)).Costos.Responsables.Single().Nombre = "EDITADO";
        Exige(Vigente(conResponsables, tituloResponsable).Costos.Responsables.Single().Nombre == "LUIS",
            "Pegar comparte los responsables con el título original.");
        pasa("Responsables de presupuesto, título y partida persisten separados en SQLite y se copian sin compartir objetos");

        var presupuestoOficial = new MYGPresupuestoDocumento { Nombre = "VINCULAR METADATOS" };
        var filaOficial = MYGEstructuraPresupuestos.InsertarNodo(presupuestoOficial, false);
        filaOficial.IdInternoDelphin = "FILA-OFICIAL"; filaOficial.Costos.Cantidad = 7; filaOficial.Costos.PrecioDirecto = 4;
        var insumoOficial = new MYGInsumo { Descripcion = "INSUMO OFICIAL", Unidad = "und", Precio = 3 };
        presupuestoOficial.Costos.Insumos.Add(insumoOficial);
        filaOficial.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumoOficial.Id, Cantidad = 2 });
        var soloResponsable = new ItemPresupuestoDelphin
        {
            Id = MYGProyectoStorage.NuevoId(),
            Descripcion = "PROPUESTA",
            Unidad = "und",
            TipoPropuesta = "PARTIDA"
        };
        soloResponsable.Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "ROSA", Cargo = "Metrados" });
        MYGProyectoStorage.Vincular(soloResponsable, filaOficial);
        Exige(filaOficial.Costos.Cantidad == 7 && filaOficial.Costos.PrecioDirecto == 4 &&
            filaOficial.Costos.Analisis.Single().InsumoId == insumoOficial.Id &&
            MYGMotorPresupuestos.Analizar(presupuestoOficial, filaOficial).PrecioUnitario == 6 &&
            filaOficial.Costos.Responsables.Single().Nombre == "ROSA", "Vincular sólo responsables reemplazó el ACU oficial.");
        filaOficial.Costos.Responsables.Single().Nombre = "EDITADO";
        Exige(soloResponsable.Costos.Responsables.Single().Nombre == "ROSA", "Vincular responsables compartió objetos.");
        var metadatosRaiz = new MYGPresupuestoDocumento { Nombre = "RESPONSABLE DE PRESUPUESTO" };
        metadatosRaiz.Costos.Responsables.Add(new MYGResponsablePresupuesto { Nombre = "ANA" });
        var metadatosPartida = new MYGPresupuestoDocumento { Nombre = "RESPONSABLE DE PARTIDA" };
        metadatosPartida.Items.Add(soloResponsable);
        Exige(MYGMotorPresupuestos.TieneCostos(metadatosRaiz) && MYGMotorPresupuestos.TieneCostos(metadatosPartida) &&
            !MYGMotorPresupuestos.TieneDatosPropios(soloResponsable.Costos),
            "Responsables no protege la versión de biblioteca o se trata como un ACU propio.");
        pasa("Vincular sólo responsables conserva el ACU oficial y protege metadatos de biblioteca sin compartir objetos");

        ComprobarEstructuraRapida(pasa);
        ComprobarActualizaciones(carpeta, pasa);
    }

    private static void ComprobarEstructuraRapida(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "ESTRUCTURA INVÁLIDA" };
        var titulo = MYGEstructuraPresupuestos.InsertarNodo(p, true);
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        void RechazaSinCambiar(Action accion)
        {
            string firma = Firma(p);
            Rechaza(accion, "La edición aceptó una estructura inválida.");
            Exige(Firma(p) == firma, "La edición rechazada alteró la estructura o sus datos.");
        }
        partida.IdLocalMYG = titulo.IdLocalMYG;
        RechazaSinCambiar(() => MYGEstructuraPresupuestos.InsertarNodo(p, false));
        partida.IdLocalMYG = partida.Id;
        titulo.ParentId = partida.Id;
        RechazaSinCambiar(() => MYGEstructuraPresupuestos.EliminarNodo(p, partida));
        titulo.ParentId = null;
        partida.ParentId = "NO-EXISTE";
        RechazaSinCambiar(() => MYGEstructuraPresupuestos.InsertarNodo(p, true));
        partida.ParentId = titulo.Id;
        titulo.TipoPropuesta = "PARTIDA";
        RechazaSinCambiar(() => MYGEstructuraPresupuestos.InsertarNodo(p, true));
        titulo.TipoPropuesta = "TITULO";
        RechazaSinCambiar(() => MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id, titulo.Id));
        var profundo = new MYGPresupuestoDocumento { Nombre = "PROFUNDIDAD" };
        string padre = null;
        for (int n = 0; n < 65; n++)
        {
            var fila = new ItemPresupuestoDelphin { Id = "PROF-" + n, IdLocalMYG = "PROF-" + n,
                TipoPropuesta = "TITULO", ParentId = padre, Posicion = 1 };
            profundo.Items.Add(fila); padre = fila.Id;
        }
        string profundaAntes = Firma(profundo);
        Rechaza(() => MYGEstructuraPresupuestos.InsertarNodo(profundo, false, padre), "La inserción excedió la profundidad admitida.");
        Exige(Firma(profundo) == profundaAntes, "La inserción demasiado profunda modificó el presupuesto.");
        pasa("Edición estructural rechaza identidades duplicadas, ciclos, padres inválidos y profundidad excesiva sin cambios parciales");

        var origen = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        origen.Costos.Hoja.Poner("B3", "8");
        string referencia = MYGReferenciasMetrado.CrearReferencia(partida.Costos.Hoja, p, origen, "B3");
        partida.Costos.Hoja.Poner("B3", "=" + referencia);
        Exige(new MYGHojaCalculo(partida.Costos.Hoja).Numero("B3") == 8, "La referencia inicial no resolvió su origen.");
        MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        Exige(new MYGHojaCalculo(partida.Costos.Hoja).Numero("B3") == 8, "Insertar perdió el contexto de referencias de metrados.");
        MYGEstructuraPresupuestos.EliminarNodo(p, origen);
        Exige(new MYGHojaCalculo(partida.Costos.Hoja).Mostrar("B3") == "#REF!", "Eliminar dejó una referencia al objeto retirado de la estructura.");
        pasa("Inserción conserva vínculos entre hojas y eliminación muestra referencia ausente sin retener partidas retiradas");

        var sinNormalizar = new MYGPresupuestoDocumento { Nombre = "IDENTIDADES HEREDADAS" };
        var borrar = new ItemPresupuestoDelphin { Id = "RETIRAR", TipoPropuesta = "PARTIDA", Descripcion = "RETIRAR", Unidad = "und" };
        var conservar = new ItemPresupuestoDelphin { Id = "CONSERVAR", TipoPropuesta = "PARTIDA", Descripcion = "CONSERVAR", Unidad = "und" };
        sinNormalizar.Costos.Insumos.Add(new MYGInsumo { Id = "MATERIAL", Descripcion = "MATERIAL", Unidad = "und" });
        conservar.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = "MATERIAL" });
        sinNormalizar.Items.AddRange(new[] { borrar, conservar });
        MYGEstructuraPresupuestos.EliminarNodo(sinNormalizar, borrar);
        Exige(sinNormalizar.Items.Single() == conservar && !string.IsNullOrWhiteSpace(conservar.IdLocalMYG),
            "La eliminación confundió identidades heredadas ausentes con una referencia a subanálisis.");

        var grande = new MYGPresupuestoDocumento { Nombre = "ESTRUCTURA GRANDE" };
        var insumo = new MYGInsumo { Descripcion = "MATERIAL", Unidad = "und", Precio = 2 };
        grande.Costos.Insumos.Add(insumo);
        var raiz = new ItemPresupuestoDelphin { Id = "RAÍZ", IdLocalMYG = "RAÍZ", TipoPropuesta = "TITULO", Item = "01", Posicion = 1 };
        grande.Items.Add(raiz);
        for (int n = 0; n < 1200; n++)
        {
            string id = "GRANDE-" + n;
            var fila = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, TipoPropuesta = "PARTIDA", ParentId = raiz.Id,
                Item = "01." + (n + 1).ToString("D2"), Posicion = n + 1, Descripcion = id, Unidad = "und" };
            fila.Costos.EspecificacionTexto = new string((char)('A' + n % 26), 16384);
            for (int r = 0; r < 6; r++) fila.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 1 });
            for (int c = 3; c < 15; c++) fila.Costos.Hoja.Poner("B" + c, (n + c).ToString());
            grande.Items.Add(fila);
        }
        MYGProyectoStorage.ValidarPresupuesto(grande);
        var filas = grande.Items.ToArray();
        var costos = filas.Select(x => x.Costos).ToArray();
        var hojas = filas.Select(x => x.Costos.Hoja).ToArray();
        long asignadoAntes = GC.GetAllocatedBytesForCurrentThread();
        var reloj = Stopwatch.StartNew();
        var nuevo = MYGEstructuraPresupuestos.InsertarNodo(grande, false, raiz.Id, grande.Items[600].Id);
        MYGEstructuraPresupuestos.EliminarNodo(grande, nuevo);
        reloj.Stop();
        long asignado = GC.GetAllocatedBytesForCurrentThread() - asignadoAntes;
        Exige(grande.Items.SequenceEqual(filas) && grande.Items.Select(x => x.Costos).SequenceEqual(costos) &&
            grande.Items.Select(x => x.Costos.Hoja).SequenceEqual(hojas),
            "Insertar/eliminar copió o reemplazó datos de filas no editadas.");
        Exige(asignado < 12L * 1024 * 1024, "La edición estructural volvió a copiar el contenido pesado de las partidas.");
        Console.WriteLine($"ESTRUCTURA_RÁPIDA: 1.200 partidas con ACU, hojas y 19 MiB de especificaciones; insertar+eliminar {reloj.Elapsed.TotalMilliseconds:F1} ms, {asignado:N0} bytes asignados.");
        pasa("Insertar y eliminar sobre 1.200 partidas conserva objetos ACU/hojas y evita copiar el contenido pesado");
    }

    private static MYGPresupuestoDocumento FuenteConSubanalisis(out ItemPresupuestoDelphin principal,
        out ItemPresupuestoDelphin dependencia, out ItemPresupuestoDelphin titulo)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "ORIGEN" };
        titulo = MYGEstructuraPresupuestos.InsertarNodo(p, true); titulo.Descripcion = "RAMA";
        principal = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        dependencia = MYGEstructuraPresupuestos.InsertarNodo(p, false);
        titulo = Vigente(p, titulo); principal = Vigente(p, principal); dependencia = Vigente(p, dependencia);
        principal.Descripcion = "PRINCIPAL"; dependencia.Descripcion = "SUBANÁLISIS";
        principal.IdInternoDelphin = "CU-OFICIAL";
        var insumo = new MYGInsumo { Codigo = "MAT-01", Descripcion = "MATERIAL", Unidad = "und", Precio = 3 };
        p.Costos.Insumos.Add(insumo);
        dependencia.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Cantidad = 2 });
        principal.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = dependencia.IdLocalMYG, Cantidad = 2 });
        principal.Costos.Cantidad = 9; principal.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        principal.Costos.Metrados.Add(new MYGLineaMetrado { Descripcion = "Original", Elementos = 2, CantidadPorElemento = 3 });
        principal.Costos.MetradosBIM.Add(new MYGMetradoBIM { ActivoId = "ACTIVO", Cantidad = 4, Unidad = "und" });
        principal.Costos.Hoja.Poner("B3", "2"); principal.Costos.Hoja.Poner("C3", "3");
        MYGProyectoStorage.ValidarPresupuesto(p);
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, principal, 12, 72);
        return p;
    }

    private static void ComprobarActualizaciones(string carpeta, Action<string> pasa)
    {
        string ruta = Path.Combine(carpeta, "Estructura catálogos.sqlite");
        MYGBaseDatos.CrearBaseVacia(ruta);
        var baseCosto = new MYGPresupuestoDocumento { Nombre = "COSTO" };
        var original = MYGEstructuraPresupuestos.InsertarNodo(baseCosto, false);
        original.Descripcion = "CATÁLOGO";
        var material = new MYGInsumo { Codigo = "EST-INS", Descripcion = "MATERIAL ACTUAL", Unidad = "und", Precio = 2 };
        baseCosto.Costos.Insumos.Add(material);
        original.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = material.Id, Cantidad = 3 });
        var entradaInsumo = MYGCatalogos.GuardarInsumo(ruta, material);
        var entradaCosto = MYGCatalogos.GuardarPartida(ruta, baseCosto, original, "EST-ACU", original.Descripcion, original.Unidad);
        var destino = new MYGPresupuestoDocumento { Nombre = "ACTUALIZAR" };
        var vinculada = MYGCatalogos.InsertarPartida(destino, ruta, entradaCosto, null);
        var vinculoInsumo = MYGCatalogos.InsertarInsumo(destino, ruta, entradaInsumo);
        vinculada.Costos.Analisis.Single().InsumoId = vinculoInsumo.Id;
        vinculada.Descripcion = "NOMBRE PROPIO"; vinculada.Costos.Cantidad = 5;
        vinculada.Costos.EspecificacionTexto = "ESPECIFICACIÓN PROPIA";
        vinculada.Filtros.Add(new FiltroPlanificacion { Parametro = "Tipo", Regla = "igual", Valor = "Viga" });
        string identidad = vinculada.IdLocalMYG;
        material.Precio = 4;
        entradaInsumo = MYGCatalogos.GuardarInsumo(ruta, material, entradaInsumo.Id, entradaInsumo.Revision);
        byte[] catalogoAntes = File.ReadAllBytes(ruta);
        Exige(MYGEstructuraPresupuestos.ActualizarInsumos(destino, new[] { vinculada }, ruta) == 1 &&
            destino.Costos.Insumos.Single(x => x.Id == vinculoInsumo.Id).Precio == 4 &&
            MYGMotorPresupuestos.Analizar(destino, Vigente(destino, vinculada)).PrecioUnitario == 12 &&
            Vigente(destino, vinculada).Costos.Cantidad == 5 && File.ReadAllBytes(ruta).SequenceEqual(catalogoAntes),
            "Actualizar insumo cambió la identidad/cantidad o escribió el catálogo.");
        original.Costos.RendimientoDiario = 9; original.Costos.Analisis.Single().Cantidad = 7;
        entradaCosto = MYGCatalogos.GuardarPartida(ruta, baseCosto, original, "EST-ACU", original.Descripcion, original.Unidad,
            entradaCosto.Id, entradaCosto.Revision);
        catalogoAntes = File.ReadAllBytes(ruta);
        Exige(MYGEstructuraPresupuestos.ActualizarCostosUnitarios(destino, new[] { vinculada }, ruta) == 1, "No se actualizó el ACU vinculado.");
        var actualizada = Vigente(destino, vinculada);
        Exige(actualizada.IdLocalMYG == identidad && actualizada.Descripcion == "NOMBRE PROPIO" &&
            actualizada.Costos.Cantidad == 5 && actualizada.Costos.EspecificacionTexto == "ESPECIFICACIÓN PROPIA" &&
            actualizada.Filtros.Single().Valor == "Viga" && actualizada.Costos.RendimientoDiario == 9 &&
            MYGMotorPresupuestos.Analizar(destino, actualizada).PrecioUnitario == 28 &&
            destino.Items.Count == 1 && File.ReadAllBytes(ruta).SequenceEqual(catalogoAntes),
            "Actualizar ACU perdió metrado/especificación/filtros o dejó una raíz temporal.");
        pasa("Actualizar insumos y costos desde catálogo conserva identidad, metrado, especificación y filtros sin escribir el origen");

        var analisisConDependencia = FuenteConSubanalisis(out var raizCosto, out _, out _);
        var entradaConDependencia = MYGCatalogos.GuardarPartida(ruta, analisisConDependencia, raizCosto, "EST-DEP", "COSTO CON DEPENDENCIA", "und");
        var nativo = MYGProyectoStorage.Copia(destino);
        var vecino = MYGEstructuraPresupuestos.InsertarNodo(nativo, false);
        var nativa = Vigente(nativo, vinculada);
        nativa.IdInternoDelphin = "OFICIAL-NATIVO"; nativa.Item = "08.02"; nativa.Posicion = 12;
        nativa.Costos.CatalogoMYGId = entradaConDependencia.Id;
        vecino.Item = "P-001"; vecino.Posicion = 40;
        Exige(MYGEstructuraPresupuestos.ActualizarCostosUnitarios(nativo, new[] { nativa }, ruta) == 1,
            "No se actualizó el ACU de la fila nativa.");
        var importada = nativo.Items.Single(x => x.Id != nativa.Id && x.Id != vecino.Id);
        Exige(Vigente(nativo, nativa).Item == "08.02" && Vigente(nativo, nativa).Posicion == 12 &&
            Vigente(nativo, vecino).Item == "P-001" && Vigente(nativo, vecino).Posicion == 40 &&
            importada.Item.StartsWith("P-", StringComparison.Ordinal) && importada.Item != "P-001" && importada.Posicion > 40 &&
            Vigente(nativo, nativa).Costos.Analisis.Single().SubpartidaIdLocal == importada.IdLocalMYG,
            "Actualizar ACU nativo renumeró filas existentes o dejó una dependencia con código repetido.");
        pasa("Actualizar ACU nativo conserva códigos y posiciones oficiales/vecinas y asigna códigos libres a dependencias importadas");

        var otro = MYGEstructuraPresupuestos.InsertarNodo(destino, false);
        otro.Costos.CatalogoMYGId = "NO-EXISTE";
        string antes = Firma(destino);
        Rechaza(() => MYGEstructuraPresupuestos.ActualizarCostosUnitarios(destino, destino.Items.ToList(), ruta), "Se ignoró una referencia vinculada inexistente.");
        Exige(Firma(destino) == antes, "Actualizar varios costos dejó modificaciones parciales tras un fallo.");
        var falta = destino.Costos.Insumos.First(); falta.CatalogoMYGId = "NO-EXISTE";
        Vigente(destino, vinculada).Costos.Analisis.Single().InsumoId = falta.Id;
        antes = Firma(destino);
        Rechaza(() => MYGEstructuraPresupuestos.ActualizarInsumos(destino, new[] { vinculada }, ruta), "Se ignoró un insumo vinculado inexistente.");
        Exige(Firma(destino) == antes, "Actualizar insumos no fue atómico.");
        otro.Costos.CatalogoMYGId = null;
        Exige(MYGEstructuraPresupuestos.ActualizarCostosUnitarios(destino, new[] { otro }, ruta) == 0, "La partida sin vínculo se modificó.");
        pasa("Actualizaciones rechazan referencias rotas sin cambios parciales y omiten partidas sin vínculo");
    }
}
