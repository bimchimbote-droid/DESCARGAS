using MYG_2027;

internal static class HistorialEstructuraCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new InvalidOperationException(mensaje); }

    internal static void Ejecutar(Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("Historial de estructura", "Presupuesto");
        var p = documento.Presupuestos.Single();
        var titulo = MYGEstructuraPresupuestos.InsertarNodo(p, true);
        var partida = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        partida.Descripcion = "Nombre anterior";
        partida.Costos.Cantidad = 7;
        partida.Costos.Hoja.Poner("G16", "11.5");
        string original = MYGProyectoStorage.Firma(documento);
        var insertar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        var nueva = MYGEstructuraPresupuestos.InsertarNodo(p, false, titulo.Id);
        var editar = MYGEntradaHistorialProyecto.Capturar(documento);
        p.Items.Single(i => i.Id == partida.Id).Descripcion = "Nombre editado";
        var rehacerEdicion = editar.CapturarInversa(documento);
        documento = editar.Aplicar(documento); // Sustituye todas las referencias.
        p = documento.Presupuestos.Single();
        var filaVigente = p.Items.Single(i => i.Id == partida.Id);
        var rehacerInsercion = insertar.CapturarInversa(documento);
        documento = insertar.Aplicar(documento);
        Exige(MYGProyectoStorage.Firma(documento) == original &&
            ReferenceEquals(filaVigente, p.Items.Single(i => i.Id == partida.Id)),
            "Deshacer estructura tras una instantánea reintrodujo objetos o valores antiguos.");
        rehacerInsercion.Aplicar(documento);
        Exige(p.Items.Any(i => i.Id == nueva.Id) && p.Items.Single(i => i.Id == partida.Id).Descripcion == "Nombre anterior",
            "Rehacer inserción perdió la identidad de la fila o alteró una descripción.");
        documento = rehacerEdicion.Aplicar(documento);
        Exige(documento.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Descripcion == "Nombre editado",
            "Rehacer edición tras rehacer estructura perdió el orden del historial.");
        pasa("Deshacer y rehacer estructura intercalados con instantáneas completas conservan identidad, orden, numeración y ediciones");

        p = documento.Presupuestos.Single();
        documento.ActivosRevit = new()
        {
            Activos = new() { new() { Id = "ACTIVO", Nombre = "Modelo", RutaLocal = "C:/Modelo.rvt" } },
            Asignaciones = new() { new() { PresupuestoId = p.Id, PartidaId = partida.Id, ActivoId = "ACTIVO", IncluirEnTotal = false } }
        };
        var eliminar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        MYGEstructuraPresupuestos.EliminarNodo(p, p.Items.Single(i => i.Id == titulo.Id));
        MYGActivosRevit.LimpiarAsignacionesHuerfanas(documento);
        Exige(p.Items.Count == 0 && documento.ActivosRevit.Asignaciones.Count == 0,
            "La eliminación no quitó la rama completa o dejó asignaciones huérfanas.");
        var candidato = eliminar.CrearCandidato(documento);
        bool bloqueado = false;
        try { MYGCambiosModulosNube.ExigirPermitidos(documento, candidato, new MYGPermisosModulos { MetradosRevit = false }); }
        catch (InvalidOperationException) { bloqueado = true; }
        Exige(bloqueado, "El candidato de historial omitió la comprobación de permisos BIM.");
        candidato.Presupuestos.Single().Items.Single(i => i.Id == partida.Id).Costos.Cantidad = 999;
        candidato.ActivosRevit.Asignaciones.Single().IncluirEnTotal = true;
        var rehacerEliminacion = eliminar.CapturarInversa(documento);
        eliminar.Aplicar(documento);
        Exige(p.Items.Count == 3 && p.Items.Single(i => i.Id == partida.Id).Costos.Cantidad == 7 &&
            !documento.ActivosRevit.Asignaciones.Single().IncluirEnTotal,
            "Comprobar el candidato mutó la captura, o deshacer no restauró la rama y sus asignaciones.");
        rehacerEliminacion.Aplicar(documento);
        Exige(p.Items.Count == 0 && documento.ActivosRevit.Asignaciones.Count == 0,
            "Rehacer eliminación dejó filas o asignaciones restauradas.");
        eliminar.Aplicar(documento);
        pasa("Historial de eliminación restaura ramas y asignaciones Revit; sus candidatos están aislados y conservan la guardia de permisos");

        var ajeno = new MYGPresupuestoDocumento { Nombre = "Ajeno", Item = "02" };
        documento.Presupuestos.Add(ajeno);
        var pesada = MYGEstructuraPresupuestos.InsertarNodo(ajeno, false);
        pesada.Costos.EspecificacionRtf = new string('X', 4 * 1024 * 1024);
        _ = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        long inicio = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 100; n++)
            _ = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        long asignados = GC.GetAllocatedBytesForCurrentThread() - inicio;
        Exige(asignados < 1024 * 1024, "Capturar estructura volvió a copiar cargas de ACU o especificaciones de otras obras.");
        foreach (var fila in p.Items.Take(2)) // Título y partida.
        {
            string nombre = fila.Descripcion;
            fila.EstadoRevit = "OK"; fila.MensajeRevit = "Estado previo";
            var texto = MYGEntradaHistorialProyecto.CapturarDescripcion(documento, p, fila);
            MYGEdicionPartida.CambiarDescripcion(p, fila, "Nuevo nombre");
            fila.EstadoRevit = fila.MensajeRevit = null;
            var rehacerTexto = texto.CapturarInversa(documento);
            var hojaConservada = fila.Costos.Hoja;
            texto.Aplicar(documento);
            Exige(fila.Descripcion == nombre && fila.EstadoRevit == "OK" && fila.MensajeRevit == "Estado previo" &&
                ReferenceEquals(hojaConservada, fila.Costos.Hoja), "Deshacer nombre perdió texto, estado o referencias del metrado.");
            rehacerTexto.Aplicar(documento);
            Exige(fila.Descripcion == "Nuevo nombre" && fila.EstadoRevit == null && fila.MensajeRevit == null,
                "Rehacer nombre no restauró la edición.");
            var candidatoTexto = texto.CrearCandidato(documento);
            Exige(candidatoTexto.Presupuestos.Single(x => x.Id == p.Id).Items.Single(x => x.Id == fila.Id).Descripcion == nombre &&
                fila.Descripcion == "Nuevo nombre", "El candidato de texto cambió el original.");
        }
        inicio = GC.GetAllocatedBytesForCurrentThread();
        for (int n = 0; n < 100; n++)
            _ = MYGEntradaHistorialProyecto.CapturarDescripcion(documento, p, p.Items.First());
        Exige(GC.GetAllocatedBytesForCurrentThread() - inicio < 1024 * 1024,
            "Capturar el nombre de una fila copió cargas ajenas.");
        pasa("Historial de nombre para títulos y partidas conserva estado BIM, referencias y candidato aislado sin copiar cargas del proyecto");
        pesada.Costos.Hoja.Poner("B3", "13");
        MYGReferenciasMetrado.Vincular(documento.Presupuestos);
        var destino = p.Items.First(i => !MYGProyectoStorage.EsTitulo(i));
        string referencia = MYGReferenciasMetrado.CrearReferencia(destino.Costos.Hoja, ajeno, pesada, "B3");
        destino.Costos.Hoja.Poner("B3", "=" + referencia);
        var antesDeAgregar = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        MYGEstructuraPresupuestos.InsertarNodo(p, false);
        antesDeAgregar.Aplicar(documento);
        MYGEstructuraPresupuestos.InsertarNodo(p, false);
        Exige(new MYGHojaCalculo(destino.Costos.Hoja).Numero("B3") == 13,
            "Deshacer estructura y volver a insertar perdió la referencia al metrado de otro presupuesto.");
        pasa("Deshacer estructura y volver a insertar mantiene el contexto de metrados entre presupuestos");
        var captura = MYGEntradaHistorialProyecto.CapturarEstructura(documento, p);
        documento.Presupuestos.Remove(p);
        string sinPresupuesto = MYGProyectoStorage.Firma(documento);
        bool rechazado = false;
        try { captura.Aplicar(documento); }
        catch (InvalidOperationException) { rechazado = true; }
        Exige(rechazado && MYGProyectoStorage.Firma(documento) == sinPresupuesto,
            "El historial de un presupuesto ausente dejó cambios parciales.");
        pasa("Cien capturas estructurales con 4 MiB ajenos usan menos de 1 MiB y rechazan presupuestos ausentes sin modificar datos");
    }
}
