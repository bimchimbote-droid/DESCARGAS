-- Eliminación durable de una base y TODAS sus obras vinculadas.
-- Aplicar después de 20261101_bases_obras.sql y nombres2000, si se usa.
-- IMPORTANTE: este SQL NUNCA elimina storage.objects. El cliente usa Storage
-- API con su JWT normal; finalizar comprueba la ausencia de los objetos.
-- Se conservan adjuntos legacy: sus lotes pueden compartirse entre proyectos
-- y no existe un índice autoritativo completo en esta versión del protocolo.
begin;
set local lock_timeout='5s';

do $preflight$
begin
    if to_regclass('myg_nube_privado.base_obras') is null
        or to_regclass('myg_nube_privado.sqlite_revisiones') is null
        or to_regclass('myg_nube_privado.paquetes_objetos') is null
        or to_regprocedure('myg_nube_privado.identidad()') is null
        or not exists(select 1 from pg_class where oid=to_regclass('storage.objects') and relrowsecurity) then
        raise exception 'Instale bases/obras, SQLite y GZip con RLS antes de esta actualización.';
    end if;
end $preflight$;

-- Sin FK hacia proyectos: conservar tombstones impide resucitar UUID borrados.
create table if not exists myg_nube_privado.eliminacion_jobs (
    operacion_id uuid primary key,
    base_id uuid not null unique,
    propietario uuid not null,
    estado text not null check(estado in ('pendiente','eliminada')),
    creado_en timestamptz not null default clock_timestamp(),
    finalizado_en timestamptz
);
create table if not exists myg_nube_privado.eliminacion_proyectos (
    operacion_id uuid not null references myg_nube_privado.eliminacion_jobs(operacion_id),
    proyecto_id uuid primary key
);
create table if not exists myg_nube_privado.eliminacion_objetos (
    operacion_id uuid not null references myg_nube_privado.eliminacion_jobs(operacion_id),
    bucket text not null check(bucket in ('myg-nube-sqlite','myg-nube-paquetes')),
    ruta text not null,
    proyecto_id uuid not null,
    primary key(operacion_id,bucket,ruta)
);
create index if not exists myg_eliminacion_objeto_ruta on myg_nube_privado.eliminacion_objetos(bucket,ruta);
revoke all on myg_nube_privado.eliminacion_jobs,myg_nube_privado.eliminacion_proyectos,
    myg_nube_privado.eliminacion_objetos from public,anon,authenticated,service_role;
alter table myg_nube_privado.eliminacion_jobs enable row level security;
alter table myg_nube_privado.eliminacion_proyectos enable row level security;
alter table myg_nube_privado.eliminacion_objetos enable row level security;

create or replace function myg_nube_privado.eliminacion_proyecto_ruta(p_bucket text,p_ruta text)
returns uuid language plpgsql immutable set search_path=pg_catalog as $fn$
begin
    if p_bucket in ('myg-nube-sqlite','myg-nube-paquetes') and
        p_ruta ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{32}/[0-9a-f]{64}(\.sqlite)?$'
        and ((p_bucket='myg-nube-sqlite' and right(p_ruta,7)='.sqlite')
            or (p_bucket='myg-nube-paquetes' and right(p_ruta,7)<>'.sqlite')) then
        return split_part(p_ruta,'/',2)::uuid;
    end if;
    return null;
end $fn$;

-- Bloqueo de fila y consulta nueva DESPUÉS del bloqueo: un upload iniciado
-- antes de preparar el job debe terminar primero; uno posterior ve el marker.
create or replace function myg_nube_privado.eliminacion_exigir_activo(p_id uuid)
returns void language plpgsql volatile security definer set search_path=pg_catalog as $fn$
declare v_estado text;
begin
    if p_id is null then return; end if;
    perform 1 from public.myg_nube_proyectos where id=p_id for share;
    select j.estado into v_estado from myg_nube_privado.eliminacion_proyectos t
        join myg_nube_privado.eliminacion_jobs j using(operacion_id) where t.proyecto_id=p_id;
    if v_estado='pendiente' then
        raise exception using errcode='55006',message='MYG_ELIMINACION_EN_CURSO';
    elsif v_estado='eliminada' then
        raise exception using errcode='22023',message='MYG_PROYECTO_ELIMINADO';
    end if;
end $fn$;

create or replace function myg_nube_privado.eliminacion_guardar_mutacion()
returns trigger language plpgsql security definer set search_path=pg_catalog as $fn$
declare v_id uuid; v_ruta_id uuid; v_bucket text;
begin
    if tg_table_schema='storage' then
        v_id:=myg_nube_privado.eliminacion_proyecto_ruta(new.bucket_id,new.name);
    elsif tg_table_name='myg_nube_proyectos' then v_id:=new.id;
    elsif tg_table_name='base_obras' then
        for v_id in select x from unnest(array[new.base_id,new.obra_id]) x order by x loop
            perform myg_nube_privado.eliminacion_exigir_activo(v_id);
        end loop;
        return new;
    else v_id:=new.proyecto_id;
    end if;
    perform myg_nube_privado.eliminacion_exigir_activo(v_id);
    if tg_table_name in ('paquetes_objetos','sqlite_revisiones') then
        v_bucket:=case when tg_table_name='paquetes_objetos' then 'myg-nube-paquetes' else 'myg-nube-sqlite' end;
        v_ruta_id:=myg_nube_privado.eliminacion_proyecto_ruta(v_bucket,new.ruta);
        -- Esperar al preparador aunque el proyecto de la referencia sea otro.
        -- Solo las rutas INCLUIDAS en el manifiesto se congelan: una ruta
        -- compartida que fue excluida no se elimina y sus usuarios siguen editando.
        perform 1 from public.myg_nube_proyectos where id=v_ruta_id for share;
        if exists(select 1 from myg_nube_privado.eliminacion_objetos where bucket=v_bucket and ruta=new.ruta) then
            perform myg_nube_privado.eliminacion_exigir_activo(v_ruta_id);
        end if;
    end if;
    return new;
end $fn$;

do $guards$
declare v record;
begin
    for v in select * from (values
        ('public','myg_nube_proyectos'),('public','myg_nube_miembros'),
        ('myg_nube_privado','base_obras'),('myg_nube_privado','sqlite_proyectos'),
        ('myg_nube_privado','sqlite_revisiones'),('myg_nube_privado','sqlite_operaciones'),
        ('myg_nube_privado','paquetes_objetos'),('storage','objects')
    ) r(esquema,tabla) loop
        execute format('drop trigger if exists myg_eliminacion_congelar on %I.%I',v.esquema,v.tabla);
        execute format('create trigger myg_eliminacion_congelar before insert or update on %I.%I for each row execute function myg_nube_privado.eliminacion_guardar_mutacion()',v.esquema,v.tabla);
    end loop;
end $guards$;

create or replace function myg_nube_privado.eliminacion_puede_borrar(p_bucket text,p_ruta text)
returns boolean language sql stable security definer set search_path=pg_catalog as $fn$
    select exists(select 1 from myg_nube_privado.eliminacion_objetos o
        join myg_nube_privado.eliminacion_jobs j using(operacion_id)
        join myg_nube_privado.identidades_verificadas i on i.auth_usuario_id=j.propietario and i.activo
        where o.bucket=p_bucket and o.ruta=p_ruta and j.estado='pendiente'
            and j.propietario=auth.uid());
$fn$;

-- Adaptar exclusivamente las guardas oficiales. Una política personalizada
-- permanece intacta y aborta la instalación, nunca se retira para habilitar DELETE.
do $politicas$
declare v record; v_actual record; v_normal text; v_original text; v_ampliada text;
begin
    for v in select * from (values
        ('myg_sqlite_inmutable_delete','myg-nube-sqlite',null::text),
        ('myg_paquetes_inmutables_delete','myg-nube-paquetes',null::text),
        ('myg_sqlite_limitar_lectura','myg-nube-sqlite','sqlite_objeto_acceso'),
        ('myg_paquetes_limitar_lectura','myg-nube-paquetes','paquete_objeto_acceso')
    ) r(nombre,bucket,helper) loop
        select p.*,pg_get_expr(p.polqual,p.polrelid) expresion into v_actual from pg_policy p
            where p.polrelid='storage.objects'::regclass and p.polname=v.nombre;
        v_original:=format('bucket_id<>%L',v.bucket);
        if v.helper is not null then v_original:=v_original||'ormyg_nube_privado.'||v.helper||'name,false'; end if;
        if not found or v_actual.polpermissive or v_actual.polroles<>array[0::oid]
            or v_actual.polcmd::text<>(case when v.helper is null then 'd' else 'r' end)
            or v_actual.polwithcheck is not null then
            raise exception 'Falta la política restrictiva oficial %. Se conserva la instalación.',v.nombre;
        end if;
        v_normal:=replace(lower(regexp_replace(v_actual.expresion,'[[:space:]()]','','g')),'::text','');
        v_ampliada:=v_original||'ormyg_nube_privado.eliminacion_puede_borrarbucket_id,name';
        if v_normal=v_ampliada then continue;
        elsif v_normal<>v_original then raise exception 'La política % es personalizada; se conserva intacta.',v.nombre; end if;
        execute format('alter policy %I on storage.objects using ((%s) or myg_nube_privado.eliminacion_puede_borrar(bucket_id,name))',v.nombre,v_actual.expresion);
    end loop;
end $politicas$;
drop policy if exists myg_eliminacion_borrar on storage.objects;
create policy myg_eliminacion_borrar on storage.objects for delete to authenticated
using(myg_nube_privado.eliminacion_puede_borrar(bucket_id,name));
drop policy if exists myg_eliminacion_leer on storage.objects;
create policy myg_eliminacion_leer on storage.objects for select to authenticated
using(myg_nube_privado.eliminacion_puede_borrar(bucket_id,name));
drop policy if exists myg_eliminacion_limitar_delete on storage.objects;
create policy myg_eliminacion_limitar_delete on storage.objects as restrictive for delete to public
using(bucket_id not in ('myg-nube-sqlite','myg-nube-paquetes')
    or myg_nube_privado.eliminacion_puede_borrar(bucket_id,name));

-- Rechazar dependencias nuevas ANTES de autorizar borrar bytes. Nunca CASCADE
-- general sobre tablas ajenas. Las solicitudes anteriores se limpian únicamente
-- si usan la columna proyecto_id UUID del contrato conocido.
create or replace function myg_nube_privado.eliminacion_exigir_esquema()
returns void language plpgsql security definer set search_path=pg_catalog as $fn$
declare v_tablas oid[]; v_relacion text; v_fk record;
begin
    select array_agg(to_regclass(n)) into v_tablas from unnest(array[
        'public.myg_nube_proyectos','public.myg_nube_miembros','public.myg_nube_historial',
        'public.myg_nube_operaciones','public.myg_nube_solicitudes',
        'myg_nube_privado.base_obras','myg_nube_privado.sqlite_proyectos',
        'myg_nube_privado.sqlite_revisiones','myg_nube_privado.sqlite_operaciones',
        'myg_nube_privado.paquetes_objetos','myg_nube_privado.historial_cambios']) n;
    if exists(select 1 from pg_constraint where contype='f' and confrelid=any(v_tablas)
        and not conrelid=any(array_remove(v_tablas,null))) then
        raise exception using errcode='55000',message='MYG_ELIMINACION_DEPENDENCIAS_DESCONOCIDAS';
    end if;
    -- No basta reconocer las tablas: una FK personalizada entre dos tablas
    -- conocidas también puede bloquear el orden de eliminación. Validar cada
    -- par de columnas y acciones antes de autorizar la primera llamada Storage.
    for v_fk in select c.*,ns.nspname||'.'||r.relname relacion,
        nf.nspname||'.'||rf.relname referencia,
        array(select a.attname::text from unnest(c.conkey) with ordinality k(n,pos)
            join pg_attribute a on a.attrelid=c.conrelid and a.attnum=k.n order by k.pos) columnas,
        array(select a.attname::text from unnest(c.confkey) with ordinality k(n,pos)
            join pg_attribute a on a.attrelid=c.confrelid and a.attnum=k.n order by k.pos) referidas
      from pg_constraint c join pg_class r on r.oid=c.conrelid join pg_namespace ns on ns.oid=r.relnamespace
        join pg_class rf on rf.oid=c.confrelid join pg_namespace nf on nf.oid=rf.relnamespace
      where c.contype='f' and c.confrelid=any(v_tablas)
    loop
        if v_fk.confupdtype<>'a' or v_fk.confdeltype not in ('a','c','r') or v_fk.confmatchtype<>'s'
            or not (
                (v_fk.referencia='public.myg_nube_proyectos' and v_fk.referidas=array['id']::text[] and (
                    (v_fk.relacion in ('public.myg_nube_miembros','public.myg_nube_historial',
                        'public.myg_nube_operaciones','public.myg_nube_solicitudes',
                        'myg_nube_privado.sqlite_proyectos','myg_nube_privado.paquetes_objetos',
                        'myg_nube_privado.historial_cambios') and v_fk.columnas=array['proyecto_id']::text[])
                    or (v_fk.relacion='myg_nube_privado.base_obras' and v_fk.columnas in (array['base_id']::text[],array['obra_id']::text[]))))
                or (v_fk.referencia='myg_nube_privado.sqlite_proyectos' and v_fk.referidas=array['proyecto_id']::text[]
                    and v_fk.relacion in ('myg_nube_privado.sqlite_revisiones','myg_nube_privado.sqlite_operaciones')
                    and v_fk.columnas=array['proyecto_id']::text[])
            ) then
            raise exception using errcode='55000',message='MYG_ELIMINACION_DEPENDENCIAS_DESCONOCIDAS';
        end if;
    end loop;
    foreach v_relacion in array array['public.myg_nube_miembros','public.myg_nube_historial',
        'public.myg_nube_operaciones','public.myg_nube_solicitudes',
        'myg_nube_privado.sqlite_proyectos','myg_nube_privado.sqlite_revisiones',
        'myg_nube_privado.sqlite_operaciones','myg_nube_privado.paquetes_objetos','myg_nube_privado.historial_cambios'] loop
        if to_regclass(v_relacion) is not null and not exists(select 1 from pg_attribute
            where attrelid=to_regclass(v_relacion) and attname='proyecto_id' and atttypid='uuid'::regtype and not attisdropped) then
            raise exception using errcode='55000',message='MYG_ELIMINACION_ESQUEMA_DESCONOCIDO';
        end if;
    end loop;
end $fn$;

create or replace function myg_nube_privado.eliminacion_manifest(p_operacion uuid)
returns jsonb language sql stable security definer set search_path=pg_catalog as $fn$
    select jsonb_build_object('operacion_id',j.operacion_id,'base_id',j.base_id,'estado',j.estado,
        'proyectos',coalesce((select jsonb_agg(t.proyecto_id order by t.proyecto_id)
            from myg_nube_privado.eliminacion_proyectos t where t.operacion_id=j.operacion_id),'[]'::jsonb),
        'objetos',coalesce((select jsonb_agg(jsonb_build_object('bucket',o.bucket,'ruta',o.ruta,'proyecto_id',o.proyecto_id)
            order by o.bucket,o.ruta) from myg_nube_privado.eliminacion_objetos o where o.operacion_id=j.operacion_id),'[]'::jsonb),
        'adjuntos_anteriores_conservados',true)
    from myg_nube_privado.eliminacion_jobs j where j.operacion_id=p_operacion;
$fn$;

create or replace function public.myg_nube_base_eliminacion_iniciar(p_base uuid,p_operacion uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog set lock_timeout='5s' as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_job myg_nube_privado.eliminacion_jobs%rowtype;
    v_ids uuid[]; v_objetos jsonb; v_base public.myg_nube_proyectos%rowtype;
begin
    if p_base is null or p_operacion is null or p_base='00000000-0000-0000-0000-000000000000'::uuid
        or p_operacion='00000000-0000-0000-0000-000000000000'::uuid then
        raise exception using errcode='22023',message='MYG_ELIMINACION_INVALIDA';
    end if;
    select * into v_job from myg_nube_privado.eliminacion_jobs where base_id=p_base or operacion_id=p_operacion order by base_id=p_base desc limit 1;
    if found then
        if v_job.propietario<>v_usuario then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
        if v_job.base_id<>p_base then raise exception using errcode='22023',message='MYG_OPERACION_REUTILIZADA'; end if;
        return myg_nube_privado.eliminacion_manifest(v_job.operacion_id);
    end if;
    select * into v_base from public.myg_nube_proyectos where id=p_base for update;
    if not found or v_base.propietario<>v_usuario or v_base.alcance<>'base' then
        raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO';
    end if;
    -- Un segundo preparador que esperó el bloqueo recupera el mismo job.
    select * into v_job from myg_nube_privado.eliminacion_jobs where base_id=p_base;
    if found then return myg_nube_privado.eliminacion_manifest(v_job.operacion_id); end if;
    perform myg_nube_privado.eliminacion_exigir_esquema();
    select array_agg(x order by x) into v_ids from (
        select p_base x union select obra_id from myg_nube_privado.base_obras where base_id=p_base) s;
    if cardinality(v_ids)>10001 then raise exception using errcode='54000',message='MYG_ELIMINACION_DEMASIADOS_PROYECTOS'; end if;
    perform 1 from public.myg_nube_proyectos where id=any(v_ids) order by id for update;
    if exists(select 1 from public.myg_nube_proyectos where id=any(v_ids) and propietario<>v_usuario)
        or exists(select 1 from myg_nube_privado.eliminacion_proyectos where proyecto_id=any(v_ids)) then
        raise exception using errcode='42501',message='MYG_ELIMINACION_CONJUNTO_NO_AUTORIZADO';
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('bucket',s.bucket_id,'ruta',s.name,'proyecto_id',s.proyecto_id)
        order by s.bucket_id,s.name),'[]'::jsonb) into v_objetos from (
        select o.bucket_id,o.name,myg_nube_privado.eliminacion_proyecto_ruta(o.bucket_id,o.name) proyecto_id
        from storage.objects o where o.bucket_id in ('myg-nube-sqlite','myg-nube-paquetes')) s
    where s.proyecto_id=any(v_ids)
        and not exists(select 1 from myg_nube_privado.sqlite_revisiones r where s.bucket_id='myg-nube-sqlite'
            and r.ruta=s.name and not r.proyecto_id=any(v_ids))
        and not exists(select 1 from myg_nube_privado.paquetes_objetos r where s.bucket_id='myg-nube-paquetes'
            and r.ruta=s.name and not r.proyecto_id=any(v_ids));
    if jsonb_array_length(v_objetos)>10000 then raise exception using errcode='54000',message='MYG_ELIMINACION_DEMASIADOS_OBJETOS'; end if;
    insert into myg_nube_privado.eliminacion_jobs(operacion_id,base_id,propietario,estado) values(p_operacion,p_base,v_usuario,'pendiente');
    insert into myg_nube_privado.eliminacion_proyectos(operacion_id,proyecto_id) select p_operacion,unnest(v_ids);
    insert into myg_nube_privado.eliminacion_objetos(operacion_id,bucket,ruta,proyecto_id)
        select p_operacion,x->>'bucket',x->>'ruta',(x->>'proyecto_id')::uuid from jsonb_array_elements(v_objetos) x;
    return myg_nube_privado.eliminacion_manifest(p_operacion);
end $fn$;

create or replace function public.myg_nube_base_eliminacion_finalizar(p_operacion uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog set lock_timeout='5s' as $fn$
declare v_usuario uuid:=myg_nube_privado.identidad(); v_job myg_nube_privado.eliminacion_jobs%rowtype;
    v_ids uuid[]; v_relacion text;
begin
    select * into v_job from myg_nube_privado.eliminacion_jobs where operacion_id=p_operacion for update;
    if not found or v_job.propietario<>v_usuario then raise exception using errcode='42501',message='MYG_ACCESO_DENEGADO'; end if;
    if v_job.estado='eliminada' then return myg_nube_privado.eliminacion_manifest(p_operacion); end if;
    perform myg_nube_privado.eliminacion_exigir_esquema();
    select array_agg(proyecto_id) into v_ids from myg_nube_privado.eliminacion_proyectos where operacion_id=p_operacion;
    perform 1 from public.myg_nube_proyectos where id=any(v_ids) order by id for update;
    if exists(select 1 from myg_nube_privado.eliminacion_objetos o join storage.objects s on s.bucket_id=o.bucket and s.name=o.ruta where o.operacion_id=p_operacion) then
        raise exception using errcode='55000',message='MYG_ELIMINACION_STORAGE_PENDIENTE';
    end if;
    -- Jamás DELETE de storage.objects: la API ya eliminó sus bytes y metadatos.
    delete from myg_nube_privado.base_obras where base_id=any(v_ids) or obra_id=any(v_ids);
    foreach v_relacion in array array['myg_nube_privado.sqlite_operaciones','myg_nube_privado.sqlite_revisiones',
        'myg_nube_privado.sqlite_proyectos','myg_nube_privado.paquetes_objetos',
        'myg_nube_privado.historial_cambios','public.myg_nube_operaciones','public.myg_nube_historial',
        'public.myg_nube_solicitudes','public.myg_nube_miembros'] loop
        if to_regclass(v_relacion) is not null then
            execute format('delete from %s where proyecto_id=any($1)',v_relacion) using v_ids;
        end if;
    end loop;
    delete from public.myg_nube_proyectos where id=any(v_ids);
    update myg_nube_privado.eliminacion_jobs set estado='eliminada',finalizado_en=clock_timestamp() where operacion_id=p_operacion;
    return myg_nube_privado.eliminacion_manifest(p_operacion);
end $fn$;

-- Helpers privados no invocables por REST. La política solo expone un booleano.
revoke all on function myg_nube_privado.eliminacion_proyecto_ruta(text,text),
    myg_nube_privado.eliminacion_exigir_activo(uuid),myg_nube_privado.eliminacion_guardar_mutacion(),
    myg_nube_privado.eliminacion_puede_borrar(text,text),myg_nube_privado.eliminacion_exigir_esquema(),
    myg_nube_privado.eliminacion_manifest(uuid) from public,anon,authenticated,service_role;
grant execute on function myg_nube_privado.eliminacion_puede_borrar(text,text) to authenticated,anon;
revoke all on function public.myg_nube_base_eliminacion_iniciar(uuid,uuid),
    public.myg_nube_base_eliminacion_finalizar(uuid) from public,anon;
grant execute on function public.myg_nube_base_eliminacion_iniciar(uuid,uuid),
    public.myg_nube_base_eliminacion_finalizar(uuid) to authenticated,service_role;

-- Añadir metadatos sin sustituir cuerpos productivos personalizados.
do $metadatos$
declare v record; v_func record; v_fuente text; v_nueva text;
begin
    for v in select * from (values
        ('public.myg_nube_listar()'),('public.myg_nube_base_obras_listar(uuid)')
    ) r(firma) loop
        select p.*,pg_get_functiondef(p.oid) definicion into v_func from pg_proc p where p.oid=to_regprocedure(v.firma);
        if not found or not v_func.prosecdef or v_func.prorettype<>'jsonb'::regtype then raise exception 'Falta metadata compatible %.',v.firma; end if;
        if position('''eliminacion_pendiente''' in v_func.prosrc)>0 and position('''actualizado_en''' in v_func.prosrc)>0 then continue; end if;
        v_fuente:=v_func.prosrc;
        if (select count(*) from regexp_matches(v_fuente,'''alcance'',p.alcance,','g'))<>1 then
            raise exception 'No se reconoce la proyección metadata de %; se conserva intacta.',v.firma;
        end if;
        v_nueva:=replace(v_fuente,'''alcance'',p.alcance,',
            '''alcance'',p.alcance,''actualizado_en'',p.actualizado_en,''eliminacion_pendiente'',exists(select 1 from myg_nube_privado.eliminacion_proyectos ep join myg_nube_privado.eliminacion_jobs ej using(operacion_id) where ep.proyecto_id=p.id and ej.estado=''pendiente''),');
        execute replace(v_func.definicion,v_fuente,v_nueva);
        if not exists(select 1 from pg_proc p where p.oid=v_func.oid
            and to_jsonb(p)-'prosrc'=(to_jsonb(v_func)-array['prosrc','definicion'])) then
            raise exception 'Cambió un atributo protegido de %.',v.firma;
        end if;
    end loop;
end $metadatos$;
notify pgrst,'reload schema';
commit;
select 'ELIMINACION_BASES_STORAGE_INSTALADA' resultado;
