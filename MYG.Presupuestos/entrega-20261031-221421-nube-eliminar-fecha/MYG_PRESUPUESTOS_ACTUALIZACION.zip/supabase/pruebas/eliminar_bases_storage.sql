-- SOLO PostgreSQL DESECHABLE. No ejecutar en Supabase real.
-- Storage API se SIMULA únicamente aquí mediante DELETE sobre su tabla bajo
-- authenticated y sus políticas RLS reales. No prueba el servicio Storage ni
-- demuestra borrado de bytes remotos; el cliente usa la API para esa operación.
\set ON_ERROR_STOP on
\if :{?MYG_PRUEBAS_DESECHABLES}
\else
  do $$ begin raise exception 'Estas pruebas requieren PostgreSQL desechable.'; end $$;
\endif
\ir archivos_sqlite.sql
reset role;
-- El fixture SQLite anterior creó miembros para probar el protocolo antiguo.
-- Solo aquí se retiran para instalar el respaldo privado sin cambiar producción.
delete from public.myg_nube_miembros m using public.myg_nube_proyectos p
where m.proyecto_id=p.id and p.id='d9000000-0000-0000-0000-000000000001'
    and m.usuario_id<>p.propietario;
\ir ../migraciones/20261101_bases_obras.sql

create function qa.eliminacion_manifest(p_id uuid,p_usuario uuid,p_salt text)
returns jsonb language sql immutable as $$
select jsonb_build_object('formato','MYG_ARCHIVO_GZIP','version',1,
    'sha256_json',encode(sha256(convert_to(p_salt,'UTF8')),'hex'),'bytes_json',4096,
    'sha256_gzip',encode(sha256(convert_to(p_salt||'-gzip','UTF8')),'hex'),'bytes_gzip',100,
    'partes',jsonb_build_array(jsonb_build_object('ruta',p_usuario::text||'/'||replace(p_id::text,'-','')||'/'||encode(sha256(convert_to(p_salt||'-gzip','UTF8')),'hex'),
        'sha256',encode(sha256(convert_to(p_salt||'-gzip','UTF8')),'hex'),'bytes',100)));
$$;
create table qa.eliminacion_datos(nombre text primary key,id uuid,ruta text,manifest jsonb);
insert into qa.eliminacion_datos(nombre,id) values
    ('base','d9000000-0000-0000-0000-000000000001'),
    ('json','db000000-0000-0000-0000-000000000001'),
    ('gzip','db000000-0000-0000-0000-000000000002'),
    ('fuera_sqlite','db000000-0000-0000-0000-000000000003'),
    ('fuera_json','db000000-0000-0000-0000-000000000004');
insert into qa.eliminacion_datos(nombre,id,manifest)
select 'gzip_inicial',id,qa.eliminacion_manifest(id,'00000000-0000-0000-0000-000000000001','inicial')
from qa.eliminacion_datos where nombre='gzip';
insert into qa.eliminacion_datos(nombre,id,manifest)
select 'gzip_editor',id,qa.eliminacion_manifest(id,'00000000-0000-0000-0000-000000000003','editor')
from qa.eliminacion_datos where nombre='gzip';
update qa.eliminacion_datos set ruta=manifest#>>'{partes,0,ruta}' where manifest is not null;
update qa.eliminacion_datos set ruta='00000000-0000-0000-0000-000000000001/'||replace(id::text,'-','')||'/'||repeat('e',64)||'.sqlite'
where nombre='fuera_sqlite';
grant select on qa.eliminacion_datos to authenticated;

set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select public.myg_nube_crear_confirmacion(id,'Obra JSON para eliminar',
    (select contenido from qa.paquetes where nombre='baseline'),'obra')
from qa.eliminacion_datos where nombre='json';
select public.myg_nube_crear_confirmacion(id,'Obra JSON que se conserva',
    (select contenido from qa.paquetes where nombre='baseline'),'obra')
from qa.eliminacion_datos where nombre='fuera_json';
insert into storage.objects(bucket_id,name,metadata)
select 'myg-nube-paquetes',ruta,'{"size":100}'::jsonb from qa.eliminacion_datos where nombre='gzip_inicial';
select public.myg_nube_crear_comprimido(id,'Obra GZip para eliminar',manifest,'obra')
from qa.eliminacion_datos where nombre='gzip_inicial';
insert into storage.objects(bucket_id,name,metadata)
select 'myg-nube-sqlite',ruta,'{"size":4096}'::jsonb from qa.eliminacion_datos where nombre='fuera_sqlite';
select public.myg_nube_sqlite_crear(id,'SQLite que se conserva','obra','doc-externo',ruta,repeat('e',64),4096)
from qa.eliminacion_datos where nombre='fuera_sqlite';
select public.myg_nube_base_obra_vincular('d9000000-0000-0000-0000-000000000001',id,'doc-'||nombre)
from qa.eliminacion_datos where nombre in ('json','gzip') order by nombre;
select public.myg_nube_rol('db000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000003','editor');
select public.myg_nube_rol('db000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','administrador');
select public.myg_nube_rol('db000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','lector');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000003';
insert into storage.objects(bucket_id,name,metadata)
select 'myg-nube-paquetes',ruta,'{"size":100}'::jsonb from qa.eliminacion_datos where nombre='gzip_editor';
select public.myg_nube_guardar_comprimido(id,'dc000000-0000-0000-0000-000000000001',1,manifest)
from qa.eliminacion_datos where nombre='gzip_editor';
-- Huérfano legítimo subido por un editor antes de confirmar otra revisión.
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-paquetes',
    '00000000-0000-0000-0000-000000000003/db000000000000000000000000000002/'||repeat('f',64),'{"size":100}');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('d',64)||'.sqlite','{"size":4096}');
reset role;

-- Referencias externas preexistentes de laboratorio, incluidas rutas que el
-- contrato actual no crearía entre proyectos. La eliminación debe conservarlas.
insert into myg_nube_privado.sqlite_revisiones(proyecto_id,revision,usuario_id,ruta,sha256,bytes)
select 'db000000-0000-0000-0000-000000000003',2,'00000000-0000-0000-0000-000000000001',ruta,sha256,bytes
from qa.sqlite_casos where nombre='inicial';
insert into myg_nube_privado.paquetes_objetos(proyecto_id,ruta,sha256,bytes)
select 'db000000-0000-0000-0000-000000000004',ruta,manifest#>>'{partes,0,sha256}',100
from qa.eliminacion_datos where nombre='gzip_inicial';
insert into storage.buckets(id,name,public,file_size_limit)
values('myg-nube-archivos','myg-nube-archivos',false,20971520) on conflict do nothing;
insert into storage.objects(bucket_id,name,metadata) values('myg-nube-archivos',
    '00000000-0000-0000-0000-000000000001/eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee/'||repeat('a',64),'{"size":100}');
create table qa.eliminacion_preservar as select
    (select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p
        where id not in ('d9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000002')) proyectos,
    (select jsonb_agg(to_jsonb(o) order by o.bucket_id,o.name) from storage.objects o
        where bucket_id='myg-nube-archivos') legacy_objetos,
    (select to_jsonb(p) from pg_policies p where schemaname='storage' and tablename='objects'
        and policyname='qa_permisiva_global') legacy_politica;

\ir ../migraciones/20261103_eliminar_bases_storage.sql
\ir ../migraciones/20261103_eliminar_bases_storage.sql

select qa.exige(not has_table_privilege('authenticated','myg_nube_privado.eliminacion_jobs','SELECT')
    and not has_table_privilege('authenticated','myg_nube_privado.eliminacion_objetos','INSERT')
    and not has_function_privilege('anon','public.myg_nube_base_eliminacion_iniciar(uuid,uuid)','EXECUTE'),
    'EliminarBases: trabajos privados y RPC sin acceso anónimo');
set role anon;
select qa.rechaza($$select public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',gen_random_uuid())$$,
    '42501','EliminarBases: anónimo no inicia trabajos');
reset role;
set role authenticated;
do $roles$
declare v_usuario text;
begin
    foreach v_usuario in array array['00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000003',
        '00000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000007'] loop
        perform set_config('request.jwt.claim.sub',v_usuario,true);
        perform qa.rechaza($$select public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',gen_random_uuid())$$,
            '42501','EliminarBases: solo propietario inicia, actor '||v_usuario);
    end loop;
end $roles$;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
with borrados as(delete from storage.objects where bucket_id in ('myg-nube-sqlite','myg-nube-paquetes') returning *)
select qa.exige((select count(*)=0 from borrados),'EliminarBases: DELETE sin trabajo mantiene inmutabilidad anterior');
reset role;
select qa.exige((select count(*)=0 from myg_nube_privado.eliminacion_jobs),
    'EliminarBases: intentos sin permiso no crearon trabajos');

create table qa.eliminacion_fk_ajena(proyecto_id uuid references public.myg_nube_proyectos(id));
insert into qa.eliminacion_fk_ajena values('d9000000-0000-0000-0000-000000000001');
set role authenticated;
select qa.rechaza($$select public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',gen_random_uuid())$$,
    '55000','EliminarBases: FK desconocida impide preparar el borrado');
reset role;
select qa.exige((select count(*)=0 from myg_nube_privado.eliminacion_jobs)
    and (select count(*)=1 from qa.eliminacion_fk_ajena),
    'EliminarBases: rechazo de FK desconocida conserva datos y no deja trabajo parcial');
drop table qa.eliminacion_fk_ajena;
-- Una tabla conocida también puede contener una relación personalizada que
-- haría borrar filas ajenas. La whitelist de nombres no basta para autorizarla.
alter table public.myg_nube_miembros add column qa_extra_padre uuid
    references public.myg_nube_proyectos(id);
set role authenticated;
select qa.rechaza($$select public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',gen_random_uuid())$$,
    '55000','EliminarBases: FK personalizada en tabla conocida también impide preparar');
reset role;
select qa.exige((select count(*)=0 from myg_nube_privado.eliminacion_jobs),
    'EliminarBases: FK personalizada de miembros no deja un trabajo parcial');
alter table public.myg_nube_miembros drop column qa_extra_padre;

create table qa.eliminacion_respuesta(fase text primary key,valor jsonb);
grant select,insert on qa.eliminacion_respuesta to authenticated;

-- Concurrencia REAL: tres conexiones y transacciones independientes.
-- 1) Una subida anterior conserva FOR SHARE hasta COMMIT; iniciar debe esperar
--    y después incluirla. 2) Una subida posterior espera al job aún sin commit
--    y, tras confirmarlo, ve el marcador y es rechazada sin dejar un huérfano.
create table qa.eliminacion_conexiones(nombre text primary key,pid integer);
create function qa.eliminacion_esperar_lock(p_nombre text,p_descripcion text)
returns void language plpgsql as $$
declare v_intento integer; v_bloqueado boolean:=false;
begin
    for v_intento in 1..100 loop
        perform pg_stat_clear_snapshot();
        select a.wait_event_type='Lock' into v_bloqueado from pg_stat_activity a
            where a.pid=(select pid from qa.eliminacion_conexiones where nombre=p_nombre);
        exit when v_bloqueado;
        perform pg_sleep(0.02);
    end loop;
    perform qa.exige(coalesce(v_bloqueado,false) and dblink_is_busy(p_nombre)=1,p_descripcion);
end $$;
select dblink_connect('eliminar_upload_previo','dbname='||current_database());
select dblink_connect('eliminar_preparar','dbname='||current_database());
select dblink_connect('eliminar_upload_posterior','dbname='||current_database());
insert into qa.eliminacion_conexiones
select 'eliminar_preparar',pid from dblink('eliminar_preparar','select pg_backend_pid()') as t(pid integer);
insert into qa.eliminacion_conexiones
select 'eliminar_upload_posterior',pid from dblink('eliminar_upload_posterior','select pg_backend_pid()') as t(pid integer);
select dblink_exec(nombre,'set role authenticated') from unnest(array[
    'eliminar_upload_previo','eliminar_preparar','eliminar_upload_posterior']) nombre;
select dblink_exec(nombre,$$set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001'$$)
from unnest(array['eliminar_upload_previo','eliminar_preparar','eliminar_upload_posterior']) nombre;
select dblink_exec('eliminar_upload_previo','begin');
select dblink_exec('eliminar_upload_previo',$$insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('8',64)||'.sqlite','{"size":4096}')$$);
select dblink_exec('eliminar_preparar','begin');
select dblink_send_query('eliminar_preparar',$$select public.myg_nube_base_eliminacion_iniciar(
    'd9000000-0000-0000-0000-000000000001','dd000000-0000-0000-0000-000000000001')$$);
select qa.eliminacion_esperar_lock('eliminar_preparar',
    'EliminarBases: preparar espera el bloqueo compartido de una subida previa');
select dblink_exec('eliminar_upload_previo','commit');
insert into qa.eliminacion_respuesta select 'iniciar',valor
from dblink_get_result('eliminar_preparar') as t(valor jsonb);
-- Consumir también el fin de resultados antes de enviar COMMIT al mismo enlace.
select count(*) from dblink_get_result('eliminar_preparar') as t(valor jsonb);
select dblink_send_query('eliminar_upload_posterior',$$insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('7',64)||'.sqlite','{"size":4096}') returning name$$);
select qa.eliminacion_esperar_lock('eliminar_upload_posterior',
    'EliminarBases: una subida posterior espera el commit del trabajo de eliminación');
select dblink_exec('eliminar_preparar','commit');
select qa.rechaza($$select * from dblink_get_result('eliminar_upload_posterior') as t(nombre text)$$,
    '55006','EliminarBases: subida posterior ve el marcador confirmado y falla tras esperar');
select qa.exige(not exists(select 1 from storage.objects where bucket_id='myg-nube-sqlite' and name=
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('7',64)||'.sqlite'),
    'EliminarBases: la carrera posterior no deja un objeto fuera del manifiesto');
select dblink_disconnect(nombre) from unnest(array[
    'eliminar_upload_previo','eliminar_preparar','eliminar_upload_posterior']) nombre;

set role authenticated;
select qa.exige(public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',
    'dd000000-0000-0000-0000-000000000001')=(select valor from qa.eliminacion_respuesta where fase='iniciar'),
    'EliminarBases: propietario recupera el trabajo preparado desde otra conexión');
select qa.exige((select valor->>'estado'='pendiente' and valor->>'base_id'='d9000000-0000-0000-0000-000000000001'
    and valor->>'operacion_id'='dd000000-0000-0000-0000-000000000001'
    and valor->>'adjuntos_anteriores_conservados'='true'
    and jsonb_array_length(valor->'proyectos')=3
    and valor->'proyectos' @> '["d9000000-0000-0000-0000-000000000001","db000000-0000-0000-0000-000000000001","db000000-0000-0000-0000-000000000002"]'::jsonb
    from qa.eliminacion_respuesta where fase='iniciar'),
    'EliminarBases: preparación incluye base y las dos obras vinculadas sin borrar adjuntos antiguos');
select qa.exige((select jsonb_array_length(valor->'objetos')=6
    and exists(select 1 from jsonb_array_elements(valor->'objetos') o where o->>'ruta' like '00000000-0000-0000-0000-000000000003/%')
    and exists(select 1 from jsonb_array_elements(valor->'objetos') o where o->>'ruta' like '%'||repeat('f',64))
    and exists(select 1 from jsonb_array_elements(valor->'objetos') o where o->>'ruta' like '%'||repeat('d',64)||'.sqlite')
    and exists(select 1 from jsonb_array_elements(valor->'objetos') o where o->>'ruta' like '%'||repeat('8',64)||'.sqlite')
    from qa.eliminacion_respuesta where fase='iniciar'),
    'EliminarBases: manifiesto incluye historial del editor y objetos huérfanos de todos los uploaders');
select qa.exige((select not exists(select 1 from jsonb_array_elements(valor->'objetos') o
    where o->>'ruta'=(select ruta from qa.sqlite_casos where nombre='inicial')
        or o->>'ruta'=(select ruta from qa.eliminacion_datos where nombre='gzip_inicial')
        or o->>'bucket'='myg-nube-archivos') from qa.eliminacion_respuesta where fase='iniciar'),
    'EliminarBases: manifiesto excluye referencias externas y bucket de adjuntos antiguos');
select qa.exige(public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',
    'dd000000-0000-0000-0000-000000000001')=(select valor from qa.eliminacion_respuesta where fase='iniciar')
    and public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',
    'dd000000-0000-0000-0000-000000000002')=(select valor from qa.eliminacion_respuesta where fase='iniciar'),
    'EliminarBases: reintento con UUID igual o nuevo recupera el mismo trabajo durable');
select qa.rechaza($$select public.myg_nube_base_eliminacion_finalizar('dd000000-0000-0000-0000-000000000001')$$,
    '55000','EliminarBases: finalizar exige ausencia real de los objetos previstos');
select qa.exige((select count(*)=3 from jsonb_array_elements(public.myg_nube_listar()) e
    where e->>'id' in ('d9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000002')
    and e->>'eliminacion_pendiente'='true' and (e->>'actualizado_en')::timestamptz is not null),
    'EliminarBases: listado muestra pendiente y fecha válida en base y obras');
select qa.exige((select count(*)=2 from jsonb_array_elements(public.myg_nube_base_obras_listar('d9000000-0000-0000-0000-000000000001')) e
    where e->>'eliminacion_pendiente'='true' and (e->>'actualizado_en')::timestamptz is not null),
    'EliminarBases: listado de obras conserva metadatos mientras falta liberar Storage');
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000007';
select qa.rechaza($$select public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',gen_random_uuid())$$,
    '42501','EliminarBases: otra cuenta no recupera el manifiesto del trabajo existente');
select qa.rechaza($$select public.myg_nube_base_eliminacion_finalizar('dd000000-0000-0000-0000-000000000001')$$,
    '42501','EliminarBases: otra cuenta no finaliza un trabajo ajeno');
with borrados as(delete from storage.objects where bucket_id in ('myg-nube-sqlite','myg-nube-paquetes') returning *)
select qa.exige((select count(*)=0 from borrados),'EliminarBases: otra cuenta no borra objetos del trabajo');
reset role;

-- Se comprueban los triggers con el administrador del fixture: los RPC usan
-- SECURITY DEFINER y deben encontrar exactamente las mismas guardas de filas.
select qa.rechaza($$update public.myg_nube_proyectos set nombre='cambio pendiente'
    where id='db000000-0000-0000-0000-000000000001'$$,'55006',
    'EliminarBases: proyecto pendiente no acepta cambios concurrentes');
select qa.rechaza($$insert into public.myg_nube_miembros(proyecto_id,usuario_id,rol) values(
    'db000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000007','lector')$$,'55006',
    'EliminarBases: pendiente no admite nuevos miembros');
select qa.rechaza($$insert into myg_nube_privado.base_obras(base_id,obra_id,documento_id) values(
    'd9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000004','documento-nuevo')$$,'55006',
    'EliminarBases: pendiente no admite nuevas obras vinculadas');
select qa.rechaza($$insert into myg_nube_privado.paquetes_objetos(proyecto_id,ruta,sha256,bytes)
    select 'db000000-0000-0000-0000-000000000004',ruta,manifest#>>'{partes,0,sha256}',100
    from qa.eliminacion_datos where nombre='gzip_editor'$$,'55006',
    'EliminarBases: otro proyecto no toma nuevas referencias a un objeto pendiente');
with refs as(insert into myg_nube_privado.paquetes_objetos(proyecto_id,ruta,sha256,bytes)
    select 'db000000-0000-0000-0000-000000000004',ruta,manifest#>>'{partes,0,sha256}',100
    from qa.eliminacion_datos where nombre='gzip_inicial'
    on conflict(proyecto_id,ruta) do update set bytes=excluded.bytes returning *)
select qa.exige((select count(*)=1 from refs),
    'EliminarBases: GZip compartido excluido sigue aceptando UPSERT externo durante el trabajo');
with refs as(insert into myg_nube_privado.sqlite_revisiones(proyecto_id,revision,usuario_id,ruta,sha256,bytes)
    select 'db000000-0000-0000-0000-000000000003',2,'00000000-0000-0000-0000-000000000001',ruta,sha256,bytes
    from qa.sqlite_casos where nombre='inicial'
    on conflict(proyecto_id,revision) do update set bytes=excluded.bytes returning *)
select qa.exige((select count(*)=1 from refs),
    'EliminarBases: SQLite compartido excluido sigue aceptando UPSERT externo durante el trabajo');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('9',64)||'.sqlite','{"size":4096}')$$,'55006',
    'EliminarBases: Storage no acepta nuevas subidas al proyecto pendiente');

-- SIMULACIÓN del paso Storage API. En producción se usa DELETE HTTP; borrar
-- únicamente filas SQL no liberaría los bytes remotos y está prohibido allí.
-- Intento amplio deliberado: es RLS, y no un WHERE copiado del manifiesto,
-- quien debe impedir borrar objetos ajenos y referencias externas conservadas.
with borrados as(delete from storage.objects where bucket_id in ('myg-nube-sqlite','myg-nube-paquetes') returning *)
select qa.exige((select count(*)=6 from borrados),
    'EliminarBases: RLS autoriza exactamente los seis objetos del trabajo al propietario');
reset role;
select qa.exige((select count(*)=3 from public.myg_nube_proyectos where id in(
    'd9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000002')),
    'EliminarBases: eliminar objetos aún conserva metadatos hasta confirmar la finalización');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
insert into qa.eliminacion_respuesta values('finalizar',public.myg_nube_base_eliminacion_finalizar('dd000000-0000-0000-0000-000000000001'));
select qa.exige((select valor->>'estado'='eliminada' and valor->>'adjuntos_anteriores_conservados'='true'
    from qa.eliminacion_respuesta where fase='finalizar'),
    'EliminarBases: finalización confirma el trabajo después de retirar Storage');
select qa.exige(public.myg_nube_base_eliminacion_finalizar('dd000000-0000-0000-0000-000000000001')=
    (select valor from qa.eliminacion_respuesta where fase='finalizar')
    and public.myg_nube_base_eliminacion_iniciar('d9000000-0000-0000-0000-000000000001',gen_random_uuid())=
    (select valor from qa.eliminacion_respuesta where fase='finalizar'),
    'EliminarBases: pérdida de ACK y nuevo cliente recuperan el resultado final idempotente');
reset role;
select qa.exige(not exists(select 1 from public.myg_nube_proyectos where id in(
    'd9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000002'))
    and not exists(select 1 from myg_nube_privado.base_obras where base_id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from public.myg_nube_historial where proyecto_id='db000000-0000-0000-0000-000000000002')
    and not exists(select 1 from public.myg_nube_operaciones where proyecto_id='db000000-0000-0000-0000-000000000002')
    and not exists(select 1 from public.myg_nube_miembros where proyecto_id in(
    'd9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000002')),
    'EliminarBases: finalización retira base, obras, relaciones, miembros, historial y operaciones');
select qa.exige(not exists(select 1 from myg_nube_privado.sqlite_operaciones where proyecto_id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from myg_nube_privado.sqlite_revisiones where proyecto_id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from myg_nube_privado.sqlite_proyectos where proyecto_id='d9000000-0000-0000-0000-000000000001')
    and not exists(select 1 from myg_nube_privado.paquetes_objetos where proyecto_id='db000000-0000-0000-0000-000000000002'),
    'EliminarBases: limpia índices SQLite y GZip de todos los históricos eliminados');
select qa.exige((select proyectos=(select jsonb_agg(to_jsonb(p) order by id) from public.myg_nube_proyectos p)
    and legacy_objetos=(select jsonb_agg(to_jsonb(o) order by o.bucket_id,o.name) from storage.objects o where bucket_id='myg-nube-archivos')
    and legacy_politica=(select to_jsonb(p) from pg_policies p where schemaname='storage' and tablename='objects' and policyname='qa_permisiva_global')
    from qa.eliminacion_preservar),
    'EliminarBases: conserva obras ajenas, objetos antiguos y política heredada');
select qa.exige(exists(select 1 from storage.objects where bucket_id='myg-nube-sqlite' and name=(select ruta from qa.sqlite_casos where nombre='inicial'))
    and exists(select 1 from storage.objects where bucket_id='myg-nube-paquetes' and name=(select ruta from qa.eliminacion_datos where nombre='gzip_inicial'))
    and exists(select 1 from myg_nube_privado.sqlite_revisiones where proyecto_id='db000000-0000-0000-0000-000000000003' and revision=2)
    and exists(select 1 from myg_nube_privado.paquetes_objetos where proyecto_id='db000000-0000-0000-0000-000000000004'),
    'EliminarBases: objetos compartidos y sus referencias externas sobreviven');
select qa.exige((select count(*)=1 from myg_nube_privado.eliminacion_jobs)
    and (select count(*)=3 from myg_nube_privado.eliminacion_proyectos),
    'EliminarBases: conserva un solo trabajo y tres tombstones durables tras terminar');
with refs as(insert into myg_nube_privado.paquetes_objetos(proyecto_id,ruta,sha256,bytes)
    select 'db000000-0000-0000-0000-000000000004',ruta,manifest#>>'{partes,0,sha256}',100
    from qa.eliminacion_datos where nombre='gzip_inicial'
    on conflict(proyecto_id,ruta) do update set bytes=excluded.bytes returning *)
select qa.exige((select count(*)=1 from refs),
    'EliminarBases: GZip compartido conservado sigue editable después de borrar su proyecto original');
with refs as(insert into myg_nube_privado.sqlite_revisiones(proyecto_id,revision,usuario_id,ruta,sha256,bytes)
    select 'db000000-0000-0000-0000-000000000003',2,'00000000-0000-0000-0000-000000000001',ruta,sha256,bytes
    from qa.sqlite_casos where nombre='inicial'
    on conflict(proyecto_id,revision) do update set bytes=excluded.bytes returning *)
select qa.exige((select count(*)=1 from refs),
    'EliminarBases: SQLite compartido conservado sigue editable después de borrar su proyecto original');
select qa.rechaza($$insert into public.myg_nube_proyectos(id,propietario,nombre,contenido) values(
    'db000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','recrear','{}')$$,'22023',
    'EliminarBases: tombstone impide recrear un UUID eliminado');
select qa.rechaza($$insert into myg_nube_privado.paquetes_objetos(proyecto_id,ruta,sha256,bytes)
    select 'db000000-0000-0000-0000-000000000004',ruta,manifest#>>'{partes,0,sha256}',100
    from qa.eliminacion_datos where nombre='gzip_editor'$$,'22023',
    'EliminarBases: tombstone impide nuevas referencias a los objetos ya eliminados');
set role authenticated;
set request.jwt.claim.sub='00000000-0000-0000-0000-000000000001';
select qa.rechaza($$insert into storage.objects(bucket_id,name,metadata) values('myg-nube-sqlite',
    '00000000-0000-0000-0000-000000000001/d9000000000000000000000000000001/'||repeat('9',64)||'.sqlite','{"size":4096}')$$,'22023',
    'EliminarBases: Storage no admite subidas huérfanas a UUID eliminado');
select qa.exige(not exists(select 1 from jsonb_array_elements(public.myg_nube_listar()) e
    where e->>'id' in ('d9000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000001','db000000-0000-0000-0000-000000000002')),
    'EliminarBases: listado final ya no muestra base u obras borradas');
reset role;
select count(*) comprobaciones_eliminar_bases from qa.resultados where descripcion like 'EliminarBases:%';
select 'ELIMINAR_BASES_STORAGE_SQL_APROBADO' resultado;
