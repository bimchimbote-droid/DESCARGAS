# Eliminar bases de la nube y consultar su última sincronización

Esta actualización añade **Eliminar base** y **Última sincronización** a Nube MYG. La eliminación está disponible únicamente para el propietario de una base. A petición del usuario, incluye **la base y todas sus obras vinculadas**, sus revisiones y su colaboración. No se borran las copias locales, los borradores ni los vínculos de los archivos del PC.

## Uso

1. En **Nube MYG → Mis proyectos**, seleccionar la base y pulsar **Eliminar base**.
2. Revisar el nombre y el alcance del diálogo. Marcar la confirmación de todas las obras vinculadas y escribir o pegar el nombre de la base. Se puede copiar del cuadro de nombre del propio diálogo.
3. Confirmar **Eliminar de la nube**. El programa solicita al servidor el conjunto exacto autorizado y elimina sus archivos mediante la API de Storage con la sesión normal del propietario.
4. El mensaje de éxito aparece después de verificar que desaparecieron los objetos previstos y confirmar el borrado de sus registros. Las métricas de uso del panel de Supabase pueden actualizarse después de la operación.

La eliminación remota no puede deshacerse desde Nube MYG. Los colaboradores pierden el acceso a las obras eliminadas. Las demás bases permanecen disponibles. No se debe usar esta función si se quieren conservar en la nube las obras vinculadas.

## Espacio liberado y archivos conservados

Se procesan los archivos SQLite y los paquetes GZip de la base y sus obras vinculadas, incluidas sus revisiones anteriores y subidas sin confirmar cuya ruta pertenece a esos proyectos. Se excluyen los objetos todavía referenciados por otros proyectos.

Los **adjuntos del protocolo antiguo** pueden compartirse entre bases y usan rutas por lote, sin un índice completo que permita demostrar que nadie más los necesita. Se conservan expresamente: esta actualización no promete recuperar el espacio de esos adjuntos. El diálogo y el resultado lo indican. Las obras que no estén vinculadas a la base seleccionada tampoco forman parte de su eliminación.

El servidor no ejecuta `DELETE FROM storage.objects` para fingir que se liberaron bytes. La transferencia de borrado se hace mediante Storage API; el servidor verifica la ausencia de los objetos antes de completar la eliminación de metadatos, historial y permisos.

## Si se interrumpe

El servidor conserva un trabajo de eliminación. La base sigue apareciendo con eliminación pendiente mientras falta completar la limpieza. Durante ese estado se impiden nuevas escrituras y subidas sobre los proyectos afectados. El propietario puede pulsar **Reintentar eliminación** para continuar el mismo trabajo; no necesita recrear la base ni cambiar sus identificadores.

Si se pierde la respuesta final, el cliente consulta una vez el estado del mismo trabajo y confirma el resultado solo cuando el servidor lo devuelve como eliminado. Un fallo de red no se presenta como éxito. Una vez completado, se conservan los identificadores y el manifiesto del trabajo para impedir que un cliente antiguo o un pendiente retrasado vuelvan a publicar los UUID eliminados.

## Última sincronización

La nueva columna utiliza `actualizado_en`, es decir, el último cambio confirmado por el servidor para cada fila. No representa la última vez que se abrió o descargó el proyecto ni inventa una sincronización usando el reloj local.

Se muestra en la cultura y zona horaria del equipo; el tooltip incluye el instante UTC. En servidores anteriores que no envían la fecha se muestra **No disponible**. El respaldo privado y las obras independientes conservan sus fechas propias: editar una obra no equivale a volver a subir el respaldo completo.

## Instalación

Base de código: `bimchimbote-droid/MYG.Presupuestos`, rama remota `main`, commit `c19d6c589b196e41bd4ca300186f37da0a3d6bb4`, más las mejoras de esta conversación. La entrega es acumulativa respecto a ese commit e incluye las mejoras anteriores de nombres largos, sugerencia del nombre del archivo y diagnóstico Storage que aún no están en `main`.

1. Cerrar MYG y respaldar o confirmar los avances locales. Comparar cualquier archivo que tenga cambios posteriores: las versiones REEMPLAZAR se entregan completas.
2. Extraer el ZIP en una carpeta temporal y copiar los archivos conservando sus rutas. No reemplazar `.git`, el repositorio entero ni las bases de datos existentes. No hay archivos que eliminar manualmente.
3. Deben estar instaladas las migraciones de SQLite, paquetes y `20261101_bases_obras.sql`. Para nombres largos, aplicar también la nueva `20261102_nombres_proyectos_2000.sql` si aún no se aplicó. No volver a ejecutar migraciones históricas que ya estén instaladas.
4. Ejecutar completo **`supabase/migraciones/20261103_eliminar_bases_storage.sql`** en SQL Editor. La transacción conserva las guardas de los buckets y concede borrado solo sobre rutas exactas del trabajo de su propietario. No hay que hacer públicos los buckets ni instalar una clave administrativa en el cliente.
5. Si la migración encuentra una política o dependencia que no reconoce, se detiene: conservar el error para adaptar esa variante; no retirar las guardas. Si encuentra un bloqueo activo, esperar a que termine la operación y reintentar el archivo completo.
6. Compilar y actualizar la aplicación. No se ha ejecutado la migración contra el Supabase remoto del usuario ni se ha eliminado ninguna base real desde esta sesión.

Desde la raíz de la solución con SDK .NET 10.0.100:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --eliminar-base
dotnet run --project MYG.PruebasNube/MYG.PruebasNube.csproj -c Release --no-build --no-restore -- --explorador-nube
```

No se añaden paquetes NuGet ni se cambian versiones. Las pruebas SQL se ejecutan con `bash scripts/pruebas/Probar-EliminarBasesStorage.sh`, Docker y el SDK activado, en PostgreSQL 17 desechable; nunca contra el Supabase real. Los tests de cliente usan SQLite/HTTP simulado según el selector. El flujo visual de Windows, el portapapeles y el borrado contra Storage real requieren validación en el equipo/proyecto del usuario.

## GitHub

El ZIP se publica únicamente en el repositorio independiente `bimchimbote-droid/DESCARGAS`, en una ruta nueva; no hace push al repositorio del código. Tras aplicar y probar, revisar **Cambios de Git** en Visual Studio, confirmar la rama habitual `main`, hacer Commit y Push, y comprobar el commit en GitHub.

La suite Nube completa conserva un fallo previo de expectativa de fase RPC en `PublicacionLigeraCheck.RenovacionFallidaAntesDePublicar`. Las suites focales aprobadas se informan por separado y no equivalen a aprobar toda la suite ni a probar Supabase en producción.

## Resultados de esta entrega

La solución completa Release compiló con **0 errores y 0 advertencias**. Pasaron **661 comprobaciones de eliminación**, **24 del explorador y las fechas**, y **49 verificaciones en PostgreSQL 17**, incluidas carreras reales entre subidas y preparación del borrado. También pasaron las regresiones de nombres (57), bases/obras (105) y SQLite (506 + 21 + 29). Los tests del cliente verifican las solicitudes DELETE con HTTP simulado; los tests SQL simulan Storage en PostgreSQL. No se borraron archivos de un Supabase real desde esta sesión.
