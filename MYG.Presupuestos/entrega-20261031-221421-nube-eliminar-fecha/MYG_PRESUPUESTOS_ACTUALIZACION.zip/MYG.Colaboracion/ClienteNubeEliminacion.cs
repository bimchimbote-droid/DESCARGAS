#nullable enable
using System.Net;
using System.Text.Json;

namespace MYG.Colaboracion;

public sealed record ResultadoEliminacionBaseNube(Guid BaseId, Guid OperacionId,
    int ProyectosEliminados, int ObjetosEliminados, bool AdjuntosAnterioresConservados);

public sealed partial class ClienteSupabase
{
    private sealed record ObjetoEliminacionNube(string Bucket, string Ruta, Guid ProyectoId);
    private sealed record TrabajoEliminacionNube(Guid BaseId, Guid OperacionId, string Estado,
        IReadOnlyList<Guid> Proyectos, IReadOnlyList<ObjetoEliminacionNube> Objetos);

    /// <summary>Elimina la base remota y sus obras vinculadas mediante un trabajo
    /// durable del servidor. Los archivos locales y adjuntos antiguos compartibles
    /// no se borran. Repetir la llamada reanuda el mismo trabajo de esa base.</summary>
    public async Task<ResultadoEliminacionBaseNube> EliminarBaseAsync(Guid baseId,
        CancellationToken ct = default, IProgress<string>? progreso = null)
    {
        ValidarIdNube(baseId);
        ct.ThrowIfCancellationRequested();
        string usuario = await IdentidadArchivosAsync(ct);
        TrabajoEliminacionNube trabajo;
        try
        {
            progreso?.Report("Preparando la eliminación de la base y sus obras vinculadas…");
            trabajo = await EjecutarRpcNubeAsync("myg_nube_base_eliminacion_iniciar",
                new { p_base = baseId, p_operacion = Guid.NewGuid() },
                raiz => LeerTrabajoEliminacionNube(raiz, baseId), ct, identidadEsperada: usuario);
        }
        catch (NubeException error) when (error.Codigo is "PGRST202" or "42883")
        {
            throw new NubeException("El servidor todavía no dispone de la eliminación recuperable de bases. "
                + "Instale la actualización de eliminación de bases en Supabase; no se borraron archivos.", codigo: error.Codigo);
        }
        if (trabajo.Estado == "eliminada") return ResultadoEliminacion(trabajo);

        // Todo el manifiesto se valida antes del primer DELETE. Nunca enviar un
        // directorio o un prefijo inferido por el cliente: cada ruta es exacta.
        int procesados = 0;
        foreach (var grupo in trabajo.Objetos.GroupBy(o => o.Bucket, StringComparer.Ordinal))
        {
            foreach (var lote in grupo.Chunk(100))
            {
                ct.ThrowIfCancellationRequested();
                progreso?.Report($"Eliminando archivos remotos: {procesados} de {trabajo.Objetos.Count}…");
                await EliminarObjetosStorageNubeAsync(grupo.Key, lote.Select(o => o.Ruta).ToArray(), usuario, ct);
                procesados += lote.Length;
            }
        }
        ct.ThrowIfCancellationRequested();
        progreso?.Report("Verificando la eliminación de los archivos y sus registros de nube…");
        TrabajoEliminacionNube confirmado;
        try
        {
            confirmado = await EjecutarRpcNubeAsync("myg_nube_base_eliminacion_finalizar",
                new { p_operacion = trabajo.OperacionId }, raiz => LeerTrabajoEliminacionNube(raiz, baseId),
                ct, identidadEsperada: usuario);
        }
        catch (NubeException error) when (error.EsErrorDeConexion && !ct.IsCancellationRequested)
        {
            // El commit puede haber eliminado la fila antes de perder su ACK.
            // Consultar una vez el trabajo durable evita depender de que la base
            // siga visible en el listado. Nunca repetir DELETE en este sondeo.
            try
            {
                confirmado = await EjecutarRpcNubeAsync("myg_nube_base_eliminacion_iniciar",
                    new { p_base = baseId, p_operacion = trabajo.OperacionId },
                    raiz => LeerTrabajoEliminacionNube(raiz, baseId), ct, identidadEsperada: usuario);
                ExigirMismoTrabajoEliminacionNube(confirmado, trabajo);
            }
            catch (NubeException consulta)
            {
                throw new NubeException("No se pudo comprobar si la eliminación terminó en el servidor. "
                    + "El resultado sigue siendo incierto; no se volvió a borrar ningún archivo.\n" + consulta.Message,
                    esErrorDeConexion: consulta.EsErrorDeConexion, necesitaIniciarSesion: consulta.NecesitaIniciarSesion,
                    accesoDenegado: consulta.AccesoDenegado, codigo: consulta.Codigo,
                    vinculoNoVerificado: consulta.VinculoNoVerificado);
            }
            if (confirmado.Estado != "eliminada") throw;
        }
        ExigirMismoTrabajoEliminacionNube(confirmado, trabajo);
        if (confirmado.Estado != "eliminada")
            throw new NubeException("La eliminación todavía está pendiente en el servidor. "
                + "No se confirmó que todos los archivos remotos desaparecieran. Reintente Eliminar base para continuar el mismo trabajo.");
        return ResultadoEliminacion(confirmado);
    }

    private static void ExigirMismoTrabajoEliminacionNube(TrabajoEliminacionNube confirmado, TrabajoEliminacionNube original)
    {
        if (confirmado.OperacionId != original.OperacionId
            || !confirmado.Proyectos.ToHashSet().SetEquals(original.Proyectos)
            || !confirmado.Objetos.ToHashSet().SetEquals(original.Objetos)) throw RespuestaNubeInvalida();
    }

    private static ResultadoEliminacionBaseNube ResultadoEliminacion(TrabajoEliminacionNube trabajo) =>
        new(trabajo.BaseId, trabajo.OperacionId, trabajo.Proyectos.Count, trabajo.Objetos.Count,
            AdjuntosAnterioresConservados: true);

    private static TrabajoEliminacionNube LeerTrabajoEliminacionNube(JsonElement raiz, Guid baseId)
    {
        ExigirCamposEliminacionNube(raiz, "base_id", "operacion_id", "estado", "proyectos", "objetos", "adjuntos_anteriores_conservados");
        if (GuidNube(raiz, "base_id") != baseId || !raiz.TryGetProperty("adjuntos_anteriores_conservados", out var adjuntos)
            || adjuntos.ValueKind != JsonValueKind.True) throw RespuestaNubeInvalida();
        Guid operacion = GuidNube(raiz, "operacion_id");
        string estado = TextoNube(raiz, "estado", 16);
        if (estado is not ("pendiente" or "eliminada")) throw RespuestaNubeInvalida();
        var proyectosJson = raiz.GetProperty("proyectos");
        var objetosJson = raiz.GetProperty("objetos");
        if (proyectosJson.ValueKind != JsonValueKind.Array || proyectosJson.GetArrayLength() is < 1 or > 10001
            || objetosJson.ValueKind != JsonValueKind.Array || objetosJson.GetArrayLength() > 10000)
            throw RespuestaNubeInvalida();
        var proyectos = new HashSet<Guid>();
        foreach (var id in proyectosJson.EnumerateArray())
        {
            if (id.ValueKind != JsonValueKind.String || !Guid.TryParseExact(id.GetString(), "D", out Guid proyecto)
                || proyecto == Guid.Empty || id.GetString() != proyecto.ToString("D") || !proyectos.Add(proyecto))
                throw RespuestaNubeInvalida();
        }
        if (!proyectos.Contains(baseId)) throw RespuestaNubeInvalida();
        var objetos = new List<ObjetoEliminacionNube>();
        var rutas = new HashSet<(string Bucket, string Ruta)>();
        foreach (var objeto in objetosJson.EnumerateArray())
        {
            ExigirCamposEliminacionNube(objeto, "bucket", "ruta", "proyecto_id");
            string bucket = TextoNube(objeto, "bucket", 32), ruta = TextoNube(objeto, "ruta", 160);
            Guid proyecto = GuidNube(objeto, "proyecto_id");
            if (!proyectos.Contains(proyecto) || !rutas.Add((bucket, ruta))
                || !(bucket switch
                {
                    "myg-nube-sqlite" => RutaSqliteValida(ruta, proyecto),
                    "myg-nube-paquetes" => RutaParteComprimidaValida(ruta, proyecto),
                    _ => false
                })) throw RespuestaNubeInvalida();
            objetos.Add(new(bucket, ruta, proyecto));
        }
        return new(baseId, operacion, estado, proyectos.ToArray(), objetos.AsReadOnly());
    }

    private static void ExigirCamposEliminacionNube(JsonElement raiz, params string[] campos)
    {
        if (raiz.ValueKind != JsonValueKind.Object) throw RespuestaNubeInvalida();
        var nombres = raiz.EnumerateObject().Select(p => p.Name).ToArray();
        if (nombres.Length != campos.Length || nombres.Distinct(StringComparer.Ordinal).Count() != campos.Length
            || nombres.Any(n => !campos.Contains(n, StringComparer.Ordinal))) throw RespuestaNubeInvalida();
    }

    private Task EliminarObjetosStorageNubeAsync(string bucket, string[] rutas, string usuario, CancellationToken ct)
    {
        byte[] cuerpo = JsonSerializer.SerializeToUtf8Bytes(new { prefixes = rutas });
        var solicitadas = rutas.ToHashSet(StringComparer.Ordinal);
        return EjecutarAsync(async token =>
        {
            try
            {
                for (int intento = 0; intento < 2; intento++)
                {
                    await ComprobarIdentidadArchivosAsync(usuario, token);
                    var sesion = await AsegurarSesionAsync(forzarRefresco: intento > 0, token, nube: true);
                    await ComprobarIdentidadArchivosAsync(usuario, token);
                    using var respuesta = await EnviarAsync(HttpMethod.Delete,
                        "storage/v1/object/" + bucket, cuerpo, sesion.Acceso, token);
                    await ComprobarIdentidadArchivosAsync(usuario, token);
                    if (respuesta.StatusCode == HttpStatusCode.Unauthorized && intento == 0) continue;
                    if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        LimpiarSesion();
                        throw new NubeException("La sesión ya no es válida. Inicie sesión de nuevo para continuar la eliminación pendiente.", necesitaIniciarSesion: true);
                    }
                    if (!respuesta.IsSuccessStatusCode)
                    {
                        string? codigo = await LeerCodigoStorageSqliteAsync(respuesta, token);
                        if (codigo == "AccessDenied")
                            throw new NubeException("Storage rechazó el permiso de eliminación. Compruebe que la actualización del servidor "
                                + "autoriza al propietario únicamente sobre los archivos del trabajo pendiente."
                                + DiagnosticoHttpNube(respuesta), accesoDenegado: true, codigo: codigo);
                        await LanzarErrorAsync(respuesta, autenticacion: false, token, nube: true);
                    }
                    using var json = await LeerJsonAsync(respuesta, token, maxBytes: 4 * 1024 * 1024, maxDepth: 32, nube: true);
                    if (json.RootElement.ValueKind != JsonValueKind.Array || json.RootElement.GetArrayLength() > rutas.Length)
                        throw RespuestaNubeInvalida();
                    var recibidas = new HashSet<string>(StringComparer.Ordinal);
                    foreach (var objeto in json.RootElement.EnumerateArray())
                    {
                        string ruta = TextoNube(objeto, "name", 160);
                        if (!solicitadas.Contains(ruta) || !recibidas.Add(ruta)
                            || objeto.TryGetProperty("bucket_id", out var recibido)
                                && (recibido.ValueKind != JsonValueKind.String || recibido.GetString() != bucket))
                            throw RespuestaNubeInvalida();
                    }
                    // Un array vacío también puede indicar objetos ya borrados o
                    // filtrados por RLS. La RPC final verifica las ausencias reales.
                    await ComprobarIdentidadArchivosAsync(usuario, token);
                    return true;
                }
                throw new NubeException("No se pudo autenticar la eliminación pendiente.", necesitaIniciarSesion: true);
            }
            catch (NubeException error)
            {
                throw new NubeException(error.Message + "\nFase de la operación: eliminación de archivos de Storage. "
                    + "Reintente Eliminar base para continuar el mismo trabajo; los archivos locales se conservan.",
                    esErrorDeConexion: error.EsErrorDeConexion, necesitaIniciarSesion: error.NecesitaIniciarSesion,
                    accesoDenegado: error.AccesoDenegado, codigo: error.Codigo, vinculoNoVerificado: error.VinculoNoVerificado);
            }
        }, ct, plazo: TimeSpan.FromMinutes(2));
    }
}
