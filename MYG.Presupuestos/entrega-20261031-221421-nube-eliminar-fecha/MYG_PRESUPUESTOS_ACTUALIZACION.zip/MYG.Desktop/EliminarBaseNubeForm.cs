#nullable enable
using System;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

/// <summary>Confirmación explícita del conjunto remoto; no modifica archivos locales.</summary>
internal sealed class EliminarBaseNubeForm : WinForms.Form
{
    internal EliminarBaseNubeForm(string nombre, bool pendiente)
    {
        Name = "confirmarEliminacionBaseNube";
        MYGProyectoUI.Preparar(this, pendiente ? "Reintentar eliminación de base" : "Eliminar base de la nube", 650, 570);
        MinimumSize = new(610, 600);
        MaximizeBox = false; MinimizeBox = false;
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill,
            Padding = new(22), ColumnCount = 1, RowCount = 7, AutoScroll = true };
        foreach (int alto in new[] { 28, 72, 88, 52, 28, 40, 58 })
            raiz.RowStyles.Add(new(WinForms.SizeType.Absolute, alto));
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        raiz.Controls.Add(new WinForms.Label { Text = "Base seleccionada", AutoSize = true }, 0, 0);
        raiz.Controls.Add(new WinForms.TextBox { Name = "nombreBaseEliminarNube", Text = nombre,
            Dock = WinForms.DockStyle.Fill, ReadOnly = true, ShortcutsEnabled = true, Multiline = true,
            ScrollBars = WinForms.ScrollBars.Vertical }, 0, 1);
        raiz.Controls.Add(new WinForms.Label { Dock = WinForms.DockStyle.Fill, Text =
            "Se eliminarán de la nube esta base, todas sus obras vinculadas, sus revisiones, archivos SQLite y paquetes. "
            + "Los colaboradores perderán el acceso. Las copias locales se conservan. "
            + "Los adjuntos antiguos potencialmente compartidos se conservan. La eliminación no se puede deshacer desde Nube MYG." }, 0, 2);
        var alcance = new WinForms.CheckBox { Name = "aceptarAlcanceEliminarBaseNube", Dock = WinForms.DockStyle.Fill,
            Text = "Entiendo que también se eliminarán todas las obras vinculadas y su colaboración." };
        raiz.Controls.Add(alcance, 0, 3);
        raiz.Controls.Add(new WinForms.Label { Text = "Escriba o pegue el nombre de la base para confirmar", AutoSize = true }, 0, 4);
        var confirmacion = new WinForms.TextBox { Name = "confirmacionNombreEliminarBaseNube",
            Dock = WinForms.DockStyle.Fill, ShortcutsEnabled = true, MaxLength = ClienteSupabase.MaxNombreProyectoNube };
        raiz.Controls.Add(confirmacion, 0, 5);
        var botones = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill,
            FlowDirection = WinForms.FlowDirection.RightToLeft, WrapContents = false };
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = WinForms.DialogResult.Cancel;
        var eliminar = MYGProyectoUI.Boton(pendiente ? "Reintentar eliminación" : "Eliminar de la nube");
        eliminar.Name = "aceptarEliminarBaseNube"; eliminar.Enabled = false;
        eliminar.Click += (_, _) =>
        {
            if (ExploradorNubePresentacion.ConfirmarNombreBase(nombre, confirmacion.Text, alcance.Checked))
                DialogResult = WinForms.DialogResult.OK;
        };
        void Validar() => eliminar.Enabled = ExploradorNubePresentacion.ConfirmarNombreBase(nombre, confirmacion.Text, alcance.Checked);
        confirmacion.TextChanged += (_, _) => Validar(); alcance.CheckedChanged += (_, _) => Validar();
        botones.Controls.Add(cancelar); botones.Controls.Add(eliminar); raiz.Controls.Add(botones, 0, 6);
        Controls.Add(raiz); CancelButton = cancelar;
    }
}
