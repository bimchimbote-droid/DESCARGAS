using System.Globalization;
using System.Net;
using System.Text;
using System.Text.Json;
using MYG.Colaboracion;
using MYG_2027;

internal static class ExploradorNubeCheck
{
    internal static async Task RunAsync()
    {
        int comprobaciones = 0;
        void Exige(bool valor, string mensaje)
        { comprobaciones++; if (!valor) throw new InvalidOperationException(mensaje); }
        using var transporte = new Transporte();
        using var cliente = new ClienteSupabase("https://explorador.supabase.co", "sb_publishable_qa_explorador", transporte);
        await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
        var anterior = (await cliente.ListarProyectosAsync()).Single();
        Exige(anterior.ActualizadoEn is null && !anterior.EliminacionPendiente
            && ExploradorNubePresentacion.FormatearSincronizacion(anterior.ActualizadoEn) == "No disponible",
            "Un servidor anterior no debe inventar una fecha ni una eliminación pendiente.");
        transporte.Campos["actualizado_en"] = "2026-10-31T20:30:00-05:00";
        transporte.Campos["eliminacion_pendiente"] = true;
        var proyecto = (await cliente.ListarProyectosAsync()).Single();
        var fecha = new DateTimeOffset(2026, 11, 1, 1, 30, 0, TimeSpan.Zero);
        Exige(proyecto.ActualizadoEn == fecha && proyecto.ActualizadoEn.Value.Offset == TimeSpan.Zero
            && proyecto.EliminacionPendiente, "El listado debe conservar la fecha confirmada y el estado del servidor.");
        var cultura = (CultureInfo)CultureInfo.InvariantCulture.Clone();
        cultura.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy"; cultura.DateTimeFormat.ShortTimePattern = "HH:mm";
        var lima = TimeZoneInfo.CreateCustomTimeZone("QA Lima", TimeSpan.FromHours(-5), "QA Lima", "QA Lima");
        Exige(ExploradorNubePresentacion.FormatearSincronizacion(proyecto.ActualizadoEn, cultura, lima) == "31/10/2026 20:30",
            "La conversión local debe mostrar el día y la hora correctos, sin sustituirlos por la hora del equipo.");
        var culturaAnterior = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = cultura;
            Exige(ExploradorNubePresentacion.FormatearSincronizacion(fecha, zona: TimeZoneInfo.Utc) == "01/11/2026 01:30",
                "La fecha debe usar la cultura actual del usuario cuando no se especifica otra.");
        }
        finally { CultureInfo.CurrentCulture = culturaAnterior; }
        transporte.Campos["actualizado_en"] = null;
        transporte.Campos["eliminacion_pendiente"] = false;
        proyecto = (await cliente.ListarProyectosAsync()).Single();
        Exige(proyecto.ActualizadoEn is null && !proyecto.EliminacionPendiente,
            "Una fecha no disponible debe permanecer ausente; false no debe convertirse en pendiente.");

        async Task Rechaza()
        {
            bool rechazo = false;
            try { await cliente.ListarProyectosAsync(); }
            catch (NubeException) { rechazo = true; }
            Exige(rechazo, "El listado aceptó metadatos de fecha o estado inválidos.");
        }
        foreach (object invalida in new object[] { "2026-11-01T01:30:00", "fecha privada inválida", 1793496600, true })
        { transporte.Campos["actualizado_en"] = invalida; await Rechaza(); }
        transporte.Campos["actualizado_en"] = "2026-11-01T01:30:00Z";
        foreach (object? invalido in new object?[] { "true", 1, null })
        { transporte.Campos["eliminacion_pendiente"] = invalido; await Rechaza(); }

        foreach (string rol in new[] { "propietario", "administrador", "editor", "lector" })
        foreach (string alcance in new[] { "base", "obra" })
            Exige(ExploradorNubePresentacion.PuedeEliminarBase(anterior with { Rol = rol, Alcance = alcance })
                == (rol == "propietario" && alcance == "base"),
                "Solo el propietario de una base completa debe tener la acción de eliminación.");
        Exige(!ExploradorNubePresentacion.PuedeEliminarBase(null), "Sin selección no puede habilitarse Eliminar base.");
        Exige(ExploradorNubePresentacion.ConfirmarNombreBase("Mi base", "Mi base", true),
            "La confirmación exacta con aceptación del alcance debe habilitar la acción.");
        Exige(!ExploradorNubePresentacion.ConfirmarNombreBase("Mi base", "Otra base", true)
            && !ExploradorNubePresentacion.ConfirmarNombreBase("Mi base", "Mi base", false)
            && !ExploradorNubePresentacion.ConfirmarNombreBase("", "", true),
            "Una base distinta, sin nombre o sin aceptar todas sus obras no debe confirmarse.");
        string largo = new('N', ClienteSupabase.MaxNombreProyectoNube);
        Exige(ExploradorNubePresentacion.ConfirmarNombreBase(largo, largo, true),
            "La confirmación debe admitir el nombre completo de 2000 caracteres.");
        Console.WriteLine($"OK Explorador de nube: {comprobaciones} comprobaciones de fecha confirmada, zona/cultura, permisos y confirmación de eliminación; HTTP simulado, sin red ni GUI.");
    }

    private sealed class Transporte : HttpMessageHandler
    {
        internal readonly Dictionary<string, object?> Campos = new();
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            object respuesta;
            if (solicitud.RequestUri!.AbsolutePath == "/auth/v1/token") respuesta = new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600,
                user = new { id = "11111111-1111-4111-8111-111111111111" } };
            else if (solicitud.RequestUri.AbsolutePath == "/rest/v1/rpc/myg_nube_listar")
            {
                var fila = new Dictionary<string, object?>
                { ["id"] = "22222222-2222-4222-8222-222222222222", ["codigo"] = "MYG-EXPLORADOR", ["nombre"] = "Mi base",
                    ["rol"] = "propietario", ["revision"] = 1, ["alcance"] = "base" };
                foreach (var campo in Campos) fila[campo.Key] = campo.Value;
                respuesta = new[] { fila };
            }
            else throw new InvalidOperationException("Solicitud inesperada en pruebas del explorador.");
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            { Content = new StringContent(JsonSerializer.Serialize(respuesta), Encoding.UTF8, "application/json") });
        }
    }
}
