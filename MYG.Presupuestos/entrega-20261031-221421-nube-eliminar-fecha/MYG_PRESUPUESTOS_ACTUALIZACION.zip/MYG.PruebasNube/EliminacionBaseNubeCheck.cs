using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MYG.Colaboracion;

/// <summary>Elimina objetos mediante DELETE de Storage simulado, nunca mediante SQL directo.</summary>
internal static class EliminacionBaseNubeCheck
{
    private static readonly Guid Actor = Guid.Parse("44f5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid Editor = Guid.Parse("45f5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid Base = Guid.Parse("46f5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid Obra = Guid.Parse("47f5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid OtraBase = Guid.Parse("48f5a542-4126-48ec-9ec5-90864f0523f7");
    private static readonly Guid Trabajo = Guid.Parse("49f5a542-4126-48ec-9ec5-90864f0523f7");
    private const string Sqlite = "myg-nube-sqlite", Paquetes = "myg-nube-paquetes";
    private const string Secreto = "token_nombre_contenido_remoto_que_no_debe_mostrarse";
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        await BorradoStorageYAlcance();
        await ManifiestosHostiles();
        await LimitesYLotes();
        await ReanudacionYConfirmaciones();
        await AutenticacionCancelacionYErrores();
        Console.WriteLine($"OK Eliminación de bases: 5 grupos y {comprobaciones} comprobaciones de DELETE Storage, alcance, reanudación, ACK, sesión y cancelación; sin red.");
    }

    private static void Exige(bool condicion, string detalle)
    {
        comprobaciones++;
        if (!condicion) throw new InvalidOperationException("Eliminación de bases: " + detalle);
    }

    private static async Task<NubeException> Rechaza(Func<Task> accion)
    {
        try { await accion(); }
        catch (NubeException error) { comprobaciones++; return error; }
        throw new InvalidOperationException("Se esperaba un rechazo de eliminación de base.");
    }

    private static async Task<ClienteSupabase> Cliente(Transporte transporte)
    {
        var cliente = new ClienteSupabase("https://eliminacion-bases.supabase.co", "sb_publishable_eliminacion_sintetica", transporte);
        await cliente.IniciarSesionAsync("qa@example.test", "clave_sintetica");
        return cliente;
    }

    private static string Ruta(Guid proyecto, int indice, bool sqlite = false, Guid? uploader = null) =>
        (uploader ?? Actor).ToString("D") + "/" + proyecto.ToString("N") + "/" + indice.ToString("x64") + (sqlite ? ".sqlite" : "");

    private static JsonObject Objeto(string bucket, string ruta, Guid proyecto) => new()
    { ["bucket"] = bucket, ["ruta"] = ruta, ["proyecto_id"] = proyecto.ToString("D") };

    private static async Task BorradoStorageYAlcance()
    {
        using var http = new Transporte(); using var cliente = await Cliente(http);
        var progreso = new List<string>();
        var resultado = await cliente.EliminarBaseAsync(Base, progreso: new Progreso(progreso.Add));
        Exige(resultado.BaseId == Base && resultado.OperacionId == Trabajo && resultado.ProyectosEliminados == 2
            && resultado.ObjetosEliminados == 2 && resultado.AdjuntosAnterioresConservados,
            "el resultado no representa la base, las obras y el manifiesto confirmados.");
        Exige(http.DeleteCalls == 2 && http.Finalizaciones == 1 && http.Estado == "eliminada",
            "la base se dio por eliminada sin ambos DELETE y confirmación final.");
        Exige(http.Objetos.Count == 1 && http.Objetos.Contains((Sqlite, Ruta(OtraBase, 900, sqlite: true))),
            "el borrado afectó a un objeto de otra base o dejó un objeto del manifiesto.");
        Exige(http.PeticionesDelete.All(p => p.Bucket is Sqlite or Paquetes)
            && http.PeticionesDelete.SelectMany(p => p.Rutas).OrderBy(p => p).SequenceEqual(
                new[] { Ruta(Base, 1, sqlite: true), Ruta(Obra, 2, uploader: Editor) }.OrderBy(p => p)),
            "Storage recibió prefijos de directorio, archivos ajenos o un bucket no autorizado.");
        Exige(progreso.Count > 0 && !progreso.Any(p => p.Contains(Actor.ToString()) || p.Contains("https://")),
            "el progreso no se notificó o expuso referencias privadas.");
    }

    private static async Task ManifiestosHostiles()
    {
        foreach (var caso in new (string Nombre, Action<JsonObject> Cambiar)[]
        {
            ("base ajena", m => m["base_id"] = OtraBase.ToString()),
            ("operación vacía", m => m["operacion_id"] = Guid.Empty.ToString()),
            ("estado desconocido", m => m["estado"] = "completada"),
            ("sin base incluida", m => m["proyectos"] = new JsonArray(Obra.ToString())),
            ("proyectos repetidos", m => m["proyectos"]!.AsArray().Add(Base.ToString())),
            ("proyecto vacío", m => m["proyectos"]!.AsArray().Add(Guid.Empty.ToString())),
            ("sin proyectos", m => m["proyectos"] = new JsonArray()),
            ("sin objetos", m => m.Remove("objetos")),
            ("sin alcance de adjuntos", m => m.Remove("adjuntos_anteriores_conservados")),
            ("sin protección de adjuntos", m => m["adjuntos_anteriores_conservados"] = false),
            ("objeto repetido", m => m["objetos"]!.AsArray().Add(m["objetos"]![0]!.DeepClone())),
            ("objeto de otro proyecto", m => m["objetos"]![1]!["proyecto_id"] = OtraBase.ToString()),
            ("ruta de otra base", m => m["objetos"]![1]!["ruta"] = Ruta(OtraBase, 2)),
            ("bucket de adjuntos", m => m["objetos"]![1]!["bucket"] = "myg-nube-archivos"),
            ("bucket arbitrario", m => m["objetos"]![1]!["bucket"] = "otro-bucket"),
            ("URL remota", m => m["objetos"]![1]!["ruta"] = "https://" + Secreto + "/objeto"),
            ("ruta relativa", m => m["objetos"]![1]!["ruta"] = "../" + Ruta(Obra, 2)),
            ("directorio", m => m["objetos"]![1]!["ruta"] = Actor + "/" + Obra.ToString("N") + "/"),
            ("consulta", m => m["objetos"]![1]!["ruta"] = Ruta(Obra, 2) + "?token=" + Secreto),
            ("SQLite sin extensión", m => m["objetos"]![0]!["ruta"] = Ruta(Base, 1)),
            ("paquete con extensión", m => m["objetos"]![1]!["ruta"] = Ruta(Obra, 2, sqlite: true)),
            ("uploader vacío", m => m["objetos"]![1]!["ruta"] = Ruta(Obra, 2, uploader: Guid.Empty)),
            ("ruta extra desconocida", m => m["objetos"]![1]!["url"] = "https://" + Secreto)
        })
        {
            using var http = new Transporte { CambiarInicio = caso.Cambiar };
            using var cliente = await Cliente(http);
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(http.DeleteCalls == 0 && http.Finalizaciones == 0 && http.Objetos.Count == 3,
                "el manifiesto hostil produjo efectos antes de validarlo completo: " + caso.Nombre);
            Exige(!error.Message.Contains(Secreto) && !error.Message.Contains("https://"),
                "el rechazo de manifiesto expuso datos del servidor: " + caso.Nombre);
        }
        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            await Rechaza(() => cliente.EliminarBaseAsync(Guid.Empty));
            Exige(http.Inicios.Count == 0 && http.DeleteCalls == 0, "un UUID vacío llegó al servidor.");
        }
    }

    private static async Task LimitesYLotes()
    {
        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            http.ReemplazarObjetos(Enumerable.Range(0, 205).Select(i => Objeto(Sqlite, Ruta(Base, 1000 + i, sqlite: true), Base)));
            var resultado = await cliente.EliminarBaseAsync(Base);
            Exige(resultado.ObjetosEliminados == 205 && http.PeticionesDelete.Count == 3
                && http.PeticionesDelete.All(p => p.Rutas.Length is >= 1 and <= 100)
                && http.PeticionesDelete.SelectMany(p => p.Rutas).Distinct().Count() == 205,
                "no se limitaron los lotes de Storage a cien rutas exactas sin duplicarlas.");
            Exige(http.Objetos.Count == 1, "los lotes borraron objetos de otra base.");
        }
        using (var http = new Transporte())
        using (var cliente = await Cliente(http))
        {
            http.ReemplazarObjetos(Enumerable.Range(0, 10001).Select(i => Objeto(Sqlite, Ruta(Base, 2000 + i, sqlite: true), Base)));
            await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(http.DeleteCalls == 0 && http.Finalizaciones == 0,
                "un manifiesto con más de diez mil objetos empezó a borrar.");
        }
    }

    private static async Task ReanudacionYConfirmaciones()
    {
        using (var http = new Transporte { PerderAckDelete = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.EsErrorDeConexion && http.DeleteCalls == 1 && http.Finalizaciones == 0
                && http.Estado == "pendiente", "el ACK perdido de Storage confirmó o rehízo la operación automáticamente.");
            var resultado = await cliente.EliminarBaseAsync(Base);
            Exige(resultado.OperacionId == Trabajo && http.Inicios.Count == 2
                && http.Inicios[0] != http.Inicios[1] && http.Estado == "eliminada" && http.Objetos.Count == 1,
                "reanudar no recuperó el trabajo durable o borró fuera del manifiesto.");
            Exige(http.RespuestasDeleteVacias > 0, "el reintento no ejercitó un DELETE ya aplicado con respuesta vacía.");
        }
        using (var http = new Transporte { PerderAckFinal = true })
        using (var cliente = await Cliente(http))
        {
            var resultado = await cliente.EliminarBaseAsync(Base);
            Exige(resultado.OperacionId == Trabajo && http.Estado == "eliminada" && http.Finalizaciones == 1
                && http.Inicios.Count == 2 && http.Inicios[1] == Trabajo && http.DeleteCalls == 2,
                "el ACK final perdido no se confirmó en una llamada mediante un sondeo sin repetir DELETE.");
        }
        using (var http = new Transporte { PerderAckFinal = true, FallarSondeo = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.EsErrorDeConexion && error.Message.Contains("incierto") && !error.Message.Contains(Secreto)
                && http.Estado == "eliminada" && http.Finalizaciones == 1 && http.Inicios.Count == 2
                && http.DeleteCalls == 2, "fallar el único sondeo convirtió la incertidumbre en éxito o repitió borrados.");
        }
        using (var http = new Transporte { PerderAckFinalSinAplicar = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.EsErrorDeConexion && http.Estado == "pendiente" && http.Finalizaciones == 1
                && http.Inicios.Count == 2 && http.Inicios[1] == Trabajo && http.DeleteCalls == 2,
                "un sondeo pendiente ocultó el error final o repitió el borrado automáticamente.");
        }
        using (var http = new Transporte { PerderAckFinal = true, DenegarSondeo = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.AccesoDenegado && !error.EsErrorDeConexion && error.Message.Contains("incierto")
                && http.Inicios.Count == 2 && http.DeleteCalls == 2 && !error.Message.Contains(Secreto),
                "el sondeo ocultó un rechazo de permisos o reveló el cuerpo remoto.");
        }
        using (var http = new Transporte { DejarObjetos = true })
        using (var cliente = await Cliente(http))
        {
            await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(http.DeleteCalls == 2 && http.Finalizaciones == 1 && http.Estado == "pendiente" && http.Objetos.Count == 3,
                "se consideró DELETE HTTP200 con array vacío equivalente a eliminar la base.");
        }
        using (var http = new Transporte { AckDeleteInvalido = true })
        using (var cliente = await Cliente(http))
        {
            await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(http.DeleteCalls == 1 && http.Finalizaciones == 0 && http.Estado == "pendiente",
                "una respuesta de Storage malformada permitió la confirmación final.");
        }
        using (var http = new Transporte { CambiarFinal = m => m["objetos"]!.AsArray().RemoveAt(0) })
        using (var cliente = await Cliente(http))
        {
            await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(http.Finalizaciones == 1, "no se ejercitó un manifiesto final que cambió el conjunto congelado.");
        }
    }

    private static async Task AutenticacionCancelacionYErrores()
    {
        using (var http = new Transporte { RenovarDelete = true })
        using (var cliente = await Cliente(http))
        {
            await cliente.EliminarBaseAsync(Base);
            Exige(http.Refrescos == 1 && http.PeticionesDelete.Count == 3
                && http.PeticionesDelete[0].Cuerpo == http.PeticionesDelete[1].Cuerpo,
                "renovar una sesión cambió las rutas o bytes del DELETE pendiente.");
        }
        using (var http = new Transporte { RenovarDelete = true, CambiarIdentidad = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.NecesitaIniciarSesion && http.DeleteCalls == 1 && http.Finalizaciones == 0 && http.Objetos.Count == 3,
                "un cambio de identidad reenvió un DELETE o confirmó datos con otra cuenta.");
        }
        using (var http = new Transporte { RechazarInicio = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.AccesoDenegado && http.DeleteCalls == 0 && http.Finalizaciones == 0,
                "un rechazo de propietario en el inicio no detuvo la eliminación.");
            Exige(!error.Message.Contains(Secreto), "el rechazo de permisos mostró el cuerpo remoto.");
        }
        using (var http = new Transporte { DenegarFinal = true })
        using (var cliente = await Cliente(http))
        {
            var error = await Rechaza(() => cliente.EliminarBaseAsync(Base));
            Exige(error.AccesoDenegado && http.Inicios.Count == 1 && http.Finalizaciones == 1
                && http.Estado == "pendiente", "un rechazo de permisos final provocó un sondeo o se ocultó como éxito.");
        }
        using (var cancelacion = new CancellationTokenSource())
        using (var http = new Transporte { AntesFinal = cancelacion.Cancel })
        using (var cliente = await Cliente(http))
        {
            bool cancelado = false;
            try { await cliente.EliminarBaseAsync(Base, cancelacion.Token); }
            catch (OperationCanceledException) when (cancelacion.IsCancellationRequested) { cancelado = true; }
            Exige(cancelado && http.Inicios.Count == 1 && http.Finalizaciones == 1,
                "cancelar la confirmación final fue ocultado o provocó un sondeo automático.");
        }
        using (var cancelacion = new CancellationTokenSource())
        using (var http = new Transporte { AntesDelete = cancelacion.Cancel })
        using (var cliente = await Cliente(http))
        {
            bool cancelado = false;
            try { await cliente.EliminarBaseAsync(Base, cancelacion.Token); }
            catch (OperationCanceledException) when (cancelacion.IsCancellationRequested) { cancelado = true; }
            Exige(cancelado && http.Finalizaciones == 0 && http.Objetos.Count == 3 && http.Estado == "pendiente",
                "cancelar se ocultó como éxito o aplicó la confirmación final.");
        }
    }

    private sealed class Progreso(Action<string> informar) : IProgress<string>
    { public void Report(string value) => informar(value); }

    private sealed record PeticionDelete(string Bucket, string[] Rutas, string Cuerpo);

    private sealed class Transporte : HttpMessageHandler
    {
        internal readonly HashSet<(string Bucket, string Ruta)> Objetos = new();
        internal readonly List<Guid> Inicios = new();
        internal readonly List<PeticionDelete> PeticionesDelete = new();
        internal int DeleteCalls, Finalizaciones, Refrescos, RespuestasDeleteVacias;
        internal string Estado = "pendiente";
        internal bool PerderAckDelete, PerderAckFinal, PerderAckFinalSinAplicar, DejarObjetos, AckDeleteInvalido,
            RenovarDelete, CambiarIdentidad, RechazarInicio, FallarSondeo, DenegarSondeo, DenegarFinal;
        internal Action? AntesDelete, AntesFinal;
        internal Action<JsonObject>? CambiarInicio, CambiarFinal;
        private JsonArray manifiestoObjetos;

        internal Transporte()
        {
            manifiestoObjetos = new JsonArray(
                Objeto(Sqlite, Ruta(Base, 1, sqlite: true), Base),
                Objeto(Paquetes, Ruta(Obra, 2, uploader: Editor), Obra));
            Objetos.Add((Sqlite, Ruta(OtraBase, 900, sqlite: true)));
            AgregarObjetos();
        }

        internal void ReemplazarObjetos(IEnumerable<JsonObject> objetos)
        {
            manifiestoObjetos = new JsonArray(objetos.Select(p => (JsonNode)p).ToArray());
            Objetos.Clear(); Objetos.Add((Sqlite, Ruta(OtraBase, 900, sqlite: true)));
            AgregarObjetos();
        }

        private void AgregarObjetos()
        {
            foreach (var objeto in manifiestoObjetos)
                Objetos.Add((objeto!["bucket"]!.GetValue<string>(), objeto["ruta"]!.GetValue<string>()));
        }

        private JsonObject Manifiesto() => new()
        {
            ["base_id"] = Base.ToString("D"), ["operacion_id"] = Trabajo.ToString("D"), ["estado"] = Estado,
            ["proyectos"] = new JsonArray(Base.ToString("D"), Obra.ToString("D")),
            ["objetos"] = manifiestoObjetos.DeepClone(), ["adjuntos_anteriores_conservados"] = true
        };

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            Exige(solicitud.RequestUri!.Host == "eliminacion-bases.supabase.co", "una solicitud salió del servidor previsto.");
            string ruta = solicitud.RequestUri.AbsolutePath;
            Exige(solicitud.Headers.Contains("apikey"), "una solicitud perdió la clave publicable.");
            if (ruta == "/auth/v1/token")
            {
                bool refresco = solicitud.RequestUri.Query.Contains("refresh_token");
                if (refresco) Refrescos++;
                return Json(new { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600,
                    user = new { id = refresco && CambiarIdentidad ? Editor : Actor } });
            }
            Exige(solicitud.Headers.Authorization?.Scheme == "Bearer", "faltó la sesión autenticada.");
            string cuerpo = solicitud.Content is null ? "" : await solicitud.Content.ReadAsStringAsync(ct);
            using var documento = JsonDocument.Parse(cuerpo); var parametros = documento.RootElement;
            if (ruta == "/rest/v1/rpc/myg_nube_base_eliminacion_iniciar")
            {
                Exige(solicitud.Method == HttpMethod.Post && parametros.EnumerateObject().Count() == 2
                    && parametros.GetProperty("p_base").GetGuid() == Base
                    && parametros.GetProperty("p_operacion").GetGuid() != Guid.Empty,
                    "el inicio no fijó base y UUID de operación sin contenido ajeno.");
                Inicios.Add(parametros.GetProperty("p_operacion").GetGuid());
                if (Inicios.Count > 1 && FallarSondeo) throw new HttpRequestException(Secreto);
                if (Inicios.Count > 1 && DenegarSondeo)
                    return Json(new { code = "42501", message = Secreto }, HttpStatusCode.Forbidden);
                if (RechazarInicio) return Json(new { code = "42501", message = Secreto }, HttpStatusCode.Forbidden);
                var manifiesto = Manifiesto(); CambiarInicio?.Invoke(manifiesto);
                return Json(manifiesto);
            }
            if (ruta == "/rest/v1/rpc/myg_nube_base_eliminacion_finalizar")
            {
                Exige(solicitud.Method == HttpMethod.Post && parametros.EnumerateObject().Count() == 1
                    && parametros.GetProperty("p_operacion").GetGuid() == Trabajo,
                    "la confirmación cambió el UUID o envió rutas para borrar mediante SQL.");
                Finalizaciones++;
                AntesFinal?.Invoke(); ct.ThrowIfCancellationRequested();
                if (DenegarFinal) return Json(new { code = "42501", message = Secreto }, HttpStatusCode.Forbidden);
                if (PerderAckFinalSinAplicar)
                { PerderAckFinalSinAplicar = false; throw new HttpRequestException("ACK final perdido antes de aplicar"); }
                bool pendientes = manifiestoObjetos.Any(o => Objetos.Contains((o!["bucket"]!.GetValue<string>(), o["ruta"]!.GetValue<string>())));
                if (!pendientes) Estado = "eliminada";
                if (PerderAckFinal) { PerderAckFinal = false; throw new HttpRequestException("ACK final perdido simulado"); }
                var manifiesto = Manifiesto(); CambiarFinal?.Invoke(manifiesto);
                return Json(manifiesto);
            }
            const string prefijoStorage = "/storage/v1/object/";
            if (ruta.StartsWith(prefijoStorage, StringComparison.Ordinal))
            {
                string bucket = ruta[prefijoStorage.Length..];
                Exige(solicitud.Method == HttpMethod.Delete && bucket is Sqlite or Paquetes,
                    "se usó un método/bucket distinto de DELETE Storage autorizado.");
                Exige(parametros.ValueKind == JsonValueKind.Object && parametros.EnumerateObject().Count() == 1
                    && parametros.TryGetProperty("prefixes", out var rutasJson) && rutasJson.ValueKind == JsonValueKind.Array,
                    "Storage no recibió el formato oficial prefixes sin campos adicionales.");
                string[] rutas = parametros.GetProperty("prefixes").EnumerateArray().Select(p => p.GetString()!).ToArray();
                Exige(rutas.Length is >= 1 and <= 100 && rutas.Distinct(StringComparer.Ordinal).Count() == rutas.Length,
                    "un DELETE no respetó el límite de lote o repitió rutas.");
                Exige(rutas.All(p => manifiestoObjetos.Any(o => o!["bucket"]!.GetValue<string>() == bucket
                    && o["ruta"]!.GetValue<string>() == p)), "Storage recibió rutas ajenas al manifiesto congelado.");
                Exige(solicitud.Content!.Headers.ContentType?.MediaType == "application/json",
                    "DELETE no usó application/json.");
                DeleteCalls++; PeticionesDelete.Add(new(bucket, rutas, cuerpo));
                AntesDelete?.Invoke(); ct.ThrowIfCancellationRequested();
                if (RenovarDelete) { RenovarDelete = false; return Json(new { }, HttpStatusCode.Unauthorized); }
                var borrados = new List<object>();
                if (!DejarObjetos)
                    foreach (string nombre in rutas)
                        if (Objetos.Remove((bucket, nombre))) borrados.Add(new { name = nombre, bucket_id = bucket });
                if (PerderAckDelete) { PerderAckDelete = false; throw new HttpRequestException("ACK de Storage perdido simulado"); }
                if (AckDeleteInvalido) return Json(new { message = Secreto });
                if (borrados.Count == 0) RespuestasDeleteVacias++;
                return Json(borrados);
            }
            throw new InvalidOperationException("Solicitud inesperada de eliminación: " + ruta);
        }

        private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) =>
            new(estado) { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
