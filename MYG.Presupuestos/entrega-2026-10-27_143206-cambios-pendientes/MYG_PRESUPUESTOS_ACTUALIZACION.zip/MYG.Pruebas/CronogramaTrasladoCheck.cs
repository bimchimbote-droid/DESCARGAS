using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class CronogramaTrasladoCheck
{
    private static readonly DateTime Inicio = new(2026, 10, 5);
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Traslado del cronograma: " + detalle); }

    internal static void Ejecutar(Action<string> pasa)
    {
        RedDePredecesoras(pasa);
        ConfiguracionYLineaBase(pasa);
        JornadasYFeriados(pasa);
        InstantaneasImportadas(pasa);
        DiasNoLaborables(pasa);
        MismoInicioYPlanVacio(pasa);
        RechazoAtomico(pasa);
    }

    private static MYGCronograma Plan(bool todosLosDias = false)
    {
        var plan = new MYGCronograma { FechaInicio = Inicio, FechaEstado = Inicio.AddDays(2) };
        if (todosLosDias) plan.Calendario.DiasLaborables = Enum.GetValues<DayOfWeek>().ToList();
        return plan;
    }
    private static MYGTareaCronograma Tarea(MYGCronograma plan, string id, int dias = 1,
        MYGModoTarea modo = MYGModoTarea.Automatica, DateTime? fecha = null)
    {
        var t = new MYGTareaCronograma { Id = id, Nombre = id, DuracionDias = dias, Modo = modo, InicioManual = fecha };
        plan.Tareas.Add(t); return t;
    }
    private static void Depende(MYGTareaCronograma t, MYGTareaCronograma anterior, MYGTipoVinculo tipo, int lag = 0) =>
        t.Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = anterior.Id, Tipo = tipo, DesfaseDias = lag });
    private static Dictionary<string, MYGResultadoTarea> Filas(MYGCronograma plan) =>
        MYGMotorCronograma.Calcular(plan).Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
    private static int DiferenciaJornadas(MYGCalendarioTrabajo calendario, DateTime desde, DateTime hasta)
    {
        desde = calendario.SiguienteLaborable(desde); hasta = calendario.SiguienteLaborable(hasta);
        return hasta >= desde ? calendario.ContarDiasLaborables(desde, hasta) - 1 :
            -(calendario.ContarDiasLaborables(hasta, desde) - 1);
    }
    private static void VerificarTraslacion(MYGCronograma original, MYGCronograma trasladado, DateTime nuevoInicio)
    {
        int delta = DiferenciaJornadas(original.Calendario, original.FechaInicio, nuevoInicio);
        var antes = Filas(original); var despues = Filas(trasladado);
        Exige(trasladado.FechaInicio == nuevoInicio.Date && despues.Count == antes.Count,
            "el inicio o el número de tareas del bloque cambió incorrectamente.");
        foreach (var (id, fila) in antes)
        {
            var nueva = despues[id];
            Exige(nueva.Inicio == original.Calendario.SumarDiasLaborables(fila.Inicio, delta) &&
                nueva.Fin == original.Calendario.SumarDiasLaborables(fila.Fin, delta),
                "se perdió la separación laborable de «" + id + "» al trasladar todo el bloque.");
            Exige(nueva.DuracionDias == fila.DuracionDias && nueva.Avance == fila.Avance,
                "el traslado alteró duración o avance de «" + id + "».");
        }
    }

    private static void RedDePredecesoras(Action<string> pasa)
    {
        var plan = Plan(true);
        var raiz = Tarea(plan, "RAIZ", 4);
        var fc = Tarea(plan, "FC+2", 2); Depende(fc, raiz, MYGTipoVinculo.FC, 2);
        var cc = Tarea(plan, "CC-1", 2); Depende(cc, raiz, MYGTipoVinculo.CC, -1);
        var ff = Tarea(plan, "FF+1", 3); Depende(ff, raiz, MYGTipoVinculo.FF, 1);
        var cf = Tarea(plan, "CF+3", 2); Depende(cf, raiz, MYGTipoVinculo.CF, 3);
        var varias = Tarea(plan, "DOS PREDECESORAS", 2);
        Depende(varias, fc, MYGTipoVinculo.FC, -1); Depende(varias, ff, MYGTipoVinculo.CC, 1);
        var restringida = Tarea(plan, "RESTRICCIÓN", 2);
        restringida.TipoRestriccion = MYGTipoRestriccion.NoComenzarAntesDe;
        restringida.FechaRestriccion = Inicio.AddDays(12);
        var exacta = Tarea(plan, "FECHA FIJA", 2);
        exacta.TipoRestriccion = MYGTipoRestriccion.DebeComenzarEl;
        exacta.FechaRestriccion = Inicio.AddDays(15);
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddDays(21));
        VerificarTraslacion(plan, movido, Inicio.AddDays(21));
        Exige(Firma(plan) == original && !ReferenceEquals(movido, plan) &&
            Firma(movido.Tareas.Select(t => t.Predecesoras)) == Firma(plan.Tareas.Select(t => t.Predecesoras)),
            "se mutó el origen o se cambiaron tipos, desfases o identidades de las predecesoras.");
        Exige(movido.Tareas.Single(t => t.Id == exacta.Id).FechaRestriccion == exacta.FechaRestriccion.Value.AddDays(21) &&
            movido.Tareas.Single(t => t.Id == restringida.Id).TipoRestriccion == restringida.TipoRestriccion &&
            MYGMotorCronograma.Calcular(movido).Advertencias.Count == 0,
            "las restricciones no acompañaron al bloque o aparecieron conflictos nuevos.");
        pasa("Trasladar el inicio conserva la red FC/CC/FF/CF, desfases positivos y negativos, múltiples predecesoras y restricciones sin mutar el plan");
    }

    private static void ConfiguracionYLineaBase(Action<string> pasa)
    {
        var plan = Plan(true);
        plan.OpcionesVista["Presentacion"] = "{\"ColorCriticaArgb\":-65536,\"OcultarAvance\":false}";
        plan.Calendarios.Add(MYGProyectoStorage.Copia(plan.Calendario));
        var resumen = Tarea(plan, "TÍTULO"); resumen.EsResumen = true;
        var manual = Tarea(plan, "MANUAL", 2, MYGModoTarea.Manual, Inicio.AddDays(2)); manual.PadreId = resumen.Id;
        manual.Avance = 37.5m; manual.Responsables.Add("Residente"); manual.Codigo = "01.01";
        manual.InicioBase = new DateTime(2025, 11, 3); manual.FinBase = new DateTime(2025, 11, 4); manual.DuracionBase = 2;
        var dividida = Tarea(plan, "DIVIDIDA", 4); dividida.PadreId = resumen.Id;
        Depende(dividida, manual, MYGTipoVinculo.FC);
        dividida.Partes.Add(new MYGParteTarea { DesfaseInicioDias = 0, DuracionDias = 2, Cantidad = 4, Porcentaje = 50 });
        dividida.Partes.Add(new MYGParteTarea { DesfaseInicioDias = 4, DuracionDias = 2, Cantidad = 4, Porcentaje = 50 });
        var hito = Tarea(plan, "HITO", 0); hito.PadreId = resumen.Id; Depende(hito, dividida, MYGTipoVinculo.FC);
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddDays(14));
        VerificarTraslacion(plan, movido, Inicio.AddDays(14));
        Exige(Firma(plan) == original && movido.FechaEstado == plan.FechaEstado &&
            Firma(movido.Calendario) == Firma(plan.Calendario) && Firma(movido.Calendarios) == Firma(plan.Calendarios) &&
            Firma(movido.OpcionesVista) == Firma(plan.OpcionesVista),
            "se cambiaron fecha de estado, calendarios, presentación o documento original.");
        foreach (var t in plan.Tareas)
        {
            var m = movido.Tareas.Single(x => x.Id == t.Id);
            Exige(m.PadreId == t.PadreId && m.Modo == t.Modo && m.EsResumen == t.EsResumen &&
                m.InicioBase == t.InicioBase && m.FinBase == t.FinBase && m.DuracionBase == t.DuracionBase &&
                Firma(m.Partes) == Firma(t.Partes) && Firma(m.Responsables) == Firma(t.Responsables),
                "se alteraron jerarquía, modo, línea base, responsables o la distribución por partes.");
        }
        pasa("El traslado conserva resúmenes, hitos, manuales, partes, línea base, fecha de estado, calendarios y opciones del Gantt");
    }

    private static void JornadasYFeriados(Action<string> pasa)
    {
        var plan = Plan(); plan.Calendario.Feriados.Add(new DateTime(2026, 10, 12));
        var manual = Tarea(plan, "ANCLA", 2, MYGModoTarea.Manual, Inicio.AddDays(3));
        var sucesora = Tarea(plan, "DESPUÉS DEL FERIADO", 3); Depende(sucesora, manual, MYGTipoVinculo.FC, 1);
        string original = Firma(plan);
        foreach (var destino in new[] { new DateTime(2026, 10, 13), new DateTime(2026, 9, 28) })
        {
            var movido = MYGTrasladoCronograma.MoverAlInicio(plan, destino);
            VerificarTraslacion(plan, movido, destino);
            Exige(Firma(plan) == original && Firma(movido.Calendario.Feriados) == Firma(plan.Calendario.Feriados),
                "adelantar o atrasar el bloque movió los feriados o tocó el origen.");
            Exige(!MYGMotorCronograma.Calcular(movido).Advertencias.Any(a => a.Contains("antes de lo requerido", StringComparison.Ordinal)),
                "el fin de semana o feriado produjo un incumplimiento de predecesoras al mover el bloque.");
        }
        pasa("Mover hacia adelante o atrás usa jornadas laborables y conserva los desfases al cruzar fines de semana y feriados");
    }

    private static void InstantaneasImportadas(Action<string> pasa)
    {
        var plan = Plan(true); plan.AdvertenciasImportacion.Add("Restricción nativa no interpretada; se conserva como información importada.");
        var a = Tarea(plan, "IMPORTADA-A", 2, MYGModoTarea.Automatica, Inicio.AddDays(1));
        a.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = Inicio.AddDays(1).AddHours(8), Fin = Inicio.AddDays(3).AddHours(17), DuracionDias = 2,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = plan.FechaInicio, VersionLectura = 1,
            Tramos = new List<MYGTramoImportadoDelphin>
            {
                new() { Id = "PG-1", Inicio = Inicio.AddDays(1).AddHours(8), Fin = Inicio.AddDays(1).AddHours(17), Duracion = 1, Cantidad = 3, Porcentaje = 50 },
                new() { Id = "PG-2", Inicio = Inicio.AddDays(3).AddHours(8), Fin = Inicio.AddDays(3).AddHours(17), Duracion = 1, Cantidad = 3, Porcentaje = 50 }
            }
        };
        var b = Tarea(plan, "IMPORTADA-B", 1, MYGModoTarea.Automatica, Inicio.AddDays(4)); Depende(b, a, MYGTipoVinculo.FC);
        b.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = Inicio.AddDays(4), Fin = Inicio.AddDays(4), DuracionDias = 1,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = plan.FechaInicio
        };
        var obsoleta = Tarea(plan, "OBSOLETA", 2, MYGModoTarea.Automatica, Inicio.AddDays(20));
        obsoleta.FechasImportadasDelphin = new MYGFechasImportadasDelphin
        {
            Inicio = Inicio.AddDays(20), Fin = Inicio.AddDays(21), DuracionDias = 2,
            ModoOriginal = MYGModoTarea.Automatica, InicioProyecto = Inicio.AddDays(10)
        };
        var antes = Filas(plan);
        Exige(antes[a.Id].Tarea.FechasImportadasDelphin != null && antes[b.Id].Tarea.FechasImportadasDelphin != null &&
            antes[obsoleta.Id].Tarea.FechasImportadasDelphin == null, "la muestra de instantáneas activas y obsoletas no está correctamente diferenciada.");
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddDays(14));
        VerificarTraslacion(plan, movido, Inicio.AddDays(14));
        var despues = Filas(movido); var otraVez = Filas(MYGProyectoStorage.Copia(movido));
        Exige(despues[a.Id].Tarea.FechasImportadasDelphin != null && despues[b.Id].Tarea.FechasImportadasDelphin != null &&
            despues[obsoleta.Id].Tarea.FechasImportadasDelphin == null && Firma(plan) == original &&
            Firma(movido.AdvertenciasImportacion) == Firma(plan.AdvertenciasImportacion),
            "se perdieron instantáneas activas, se reactivó una obsoleta o se alteró el historial importado.");
        var importada = movido.Tareas.Single(t => t.Id == a.Id).FechasImportadasDelphin;
        Exige(importada.Tramos.Count == 2 && importada.Tramos[0].Inicio == a.FechasImportadasDelphin.Tramos[0].Inicio.AddDays(14) &&
            importada.Tramos[1].Fin == a.FechasImportadasDelphin.Tramos[1].Fin.AddDays(14) &&
            importada.Tramos[0].Cantidad == 3 && importada.Tramos[1].Porcentaje == 50 &&
            despues[a.Id].Inicio == otraVez[a.Id].Inicio && despues[b.Id].Inicio == otraVez[b.Id].Inicio &&
            despues[a.Id].Fin == otraVez[a.Id].Fin,
            "el traslado perdió pausas, horas, cantidades o estabilidad de las fechas tras copiar y recalcular.");
        pasa("Trasladar instantáneas Delphin conserva sus tramos y firmas, no reactiva fechas obsoletas y sigue estable al volver a calcular");
    }

    private static void DiasNoLaborables(Action<string> pasa)
    {
        var plan = Plan(); var hito = Tarea(plan, "HITO DEL SÁBADO", 0, MYGModoTarea.Manual, new DateTime(2026, 10, 10));
        string original = Firma(plan);
        var movido = MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 12));
        Exige(Filas(movido)[hito.Id].Inicio == new DateTime(2026, 10, 17) && Firma(plan) == original,
            "se normalizó silenciosamente un hito del sábado en vez de conservar su posición entre jornadas.");
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(plan, new DateTime(2026, 10, 6)),
            "un hueco de fin de semana que no existe en el calendario destino");
        Exige(Firma(plan) == original, "rechazar un traslado no laborable dejó fechas parciales en el original.");
        pasa("Los días no laborables conservan su posición si existe un hueco equivalente y rechazan un traslado incompatible sin cambios parciales");
    }

    private static void MismoInicioYPlanVacio(Action<string> pasa)
    {
        var plan = Plan(); Tarea(plan, "SIN CAMBIO", 2);
        string original = Firma(plan);
        var copia = MYGTrasladoCronograma.MoverAlInicio(plan, Inicio.AddHours(12));
        Exige(Firma(copia) == original && !ReferenceEquals(copia, plan) && Firma(plan) == original,
            "confirmar el mismo día debe devolver una copia sin reprogramar la configuración.");
        var vacio = Plan(); string vacioAntes = Firma(vacio);
        var actualizado = MYGTrasladoCronograma.MoverAlInicio(vacio, Inicio.AddDays(7));
        Exige(actualizado.Tareas.Count == 0 && actualizado.FechaInicio == Inicio.AddDays(7) &&
            actualizado.FechaEstado == vacio.FechaEstado && Firma(vacio) == vacioAntes,
            "un cronograma vacío debe poder cambiar su ancla sin crear tareas ni modificar el documento original.");
        pasa("Mismo inicio no reprograma y un plan vacío cambia su ancla sin crear tareas ni tocar el origen");
    }

    private static void RechazoAtomico(Action<string> pasa)
    {
        var ciclo = Plan(); var a = Tarea(ciclo, "A"); var b = Tarea(ciclo, "B");
        Depende(a, b, MYGTipoVinculo.FC); Depende(b, a, MYGTipoVinculo.FC);
        string antes = Firma(ciclo);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(ciclo, Inicio.AddDays(7)), "una red circular");
        Exige(Firma(ciclo) == antes, "el traslado rechazado de una red circular mutó el plan.");
        var extremo = Plan(true); Tarea(extremo, "SE SALE DEL CALENDARIO", 2);
        antes = Firma(extremo);
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(extremo, DateTime.MaxValue.Date), "fechas que desbordan el calendario");
        Exige(Firma(extremo) == antes, "el error de rango dejó el origen parcialmente movido.");
        Rechaza(() => MYGTrasladoCronograma.MoverAlInicio(extremo, default), "una fecha de inicio no válida");
        pasa("Los ciclos y fechas fuera del rango se rechazan antes de mutar el cronograma original");
    }

    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (ArgumentException) { return; }
        catch (InvalidOperationException) { return; }
        catch (OverflowException) { return; }
        throw new Exception("Traslado aceptó " + detalle + ".");
    }
}
