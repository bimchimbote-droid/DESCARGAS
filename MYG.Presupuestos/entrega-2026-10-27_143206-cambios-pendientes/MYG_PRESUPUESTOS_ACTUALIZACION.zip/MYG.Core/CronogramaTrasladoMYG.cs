using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

/// <summary>Traslada una copia del cronograma por jornadas laborables, sin
/// cambiar sus vínculos, modos, duraciones, línea base ni configuración.</summary>
public static class MYGTrasladoCronograma
{
    public static MYGCronograma MoverAlInicio(MYGCronograma original, DateTime nuevoInicio)
    {
        ArgumentNullException.ThrowIfNull(original);
        if (nuevoInicio == default) throw new InvalidDataException("Indique una fecha de inicio válida para trasladar el cronograma.");
        var antes = MYGMotorCronograma.Calcular(original);
        var copia = MYGProyectoStorage.Copia(original);
        if (nuevoInicio.Date == original.FechaInicio.Date) return copia;
        var calendario = new MYGCalendarioEntero(original.Calendario);
        long desfase = calendario.Primero(nuevoInicio) - calendario.Primero(original.FechaInicio);
        var activas = antes.Filas.Where(f => MYGMotorCronograma.ConservaFechasDelphin(f.Tarea))
            .Select(f => f.Tarea.Id).ToHashSet(StringComparer.Ordinal);

        DateTime MoverFecha(DateTime fecha, MYGTareaCronograma tarea, string campo)
        {
            if (desfase == 0) return fecha;
            try
            {
                DateTime destino;
                if (original.Calendario.EsLaborable(fecha))
                    destino = calendario.Fecha(calendario.Primero(fecha) + desfase);
                else
                {
                    // Conservar tanto Primero como AnteriorOIgual exige un
                    // hueco no laborable entre las mismas jornadas relativas.
                    // No normalizar una fecha manual o fija silenciosamente.
                    long anterior = calendario.AnteriorOIgual(fecha);
                    DateTime previoOriginal = calendario.Fecha(anterior);
                    DateTime previoNuevo = calendario.Fecha(anterior + desfase);
                    DateTime siguienteNuevo = calendario.Fecha(calendario.Primero(fecha) + desfase);
                    int posicion = (fecha.Date - previoOriginal).Days;
                    if (posicion >= (siguienteNuevo - previoNuevo).Days)
                        throw new InvalidDataException("El calendario de destino no contiene un día no laborable equivalente.");
                    destino = previoNuevo.AddDays(posicion);
                }
                return DateTime.SpecifyKind(destino.Add(fecha.TimeOfDay), fecha.Kind);
            }
            catch (Exception ex) when (ex is InvalidDataException or ArgumentOutOfRangeException or OverflowException)
            {
                throw new InvalidDataException("No se puede conservar " + campo + " de la tarea «" + tarea.Nombre +
                    "» (" + fecha.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + ") al trasladar el bloque: " + ex.Message, ex);
            }
        }

        copia.FechaInicio = nuevoInicio.Date;
        string firmaCalendario = MYGMotorCronograma.FirmaCalendarioDelphin(copia.Calendario);
        foreach (var tarea in copia.Tareas)
        {
            if (tarea.InicioManual.HasValue && (tarea.Modo == MYGModoTarea.Manual || activas.Contains(tarea.Id)))
                tarea.InicioManual = MoverFecha(tarea.InicioManual.Value, tarea, "el inicio guardado");
            if (tarea.FechaRestriccion.HasValue)
                tarea.FechaRestriccion = MoverFecha(tarea.FechaRestriccion.Value, tarea, "la fecha de restricción");
            if (tarea.FechasImportadasDelphin is not { } importadas) continue;
            if (!activas.Contains(tarea.Id))
            {
                // Los datos históricos que ya no programan esta tarea no
                // deben bloquear el traslado ni recuperar vigencia por azar.
                if (tarea.Modo == MYGModoTarea.Automatica)
                    importadas.FirmaAntecesoras = "MYG_TRASLADO_INSTANTANEA_OBSOLETA";
                continue;
            }
            importadas.Inicio = MoverFecha(importadas.Inicio, tarea, "el inicio importado");
            importadas.Fin = MoverFecha(importadas.Fin, tarea, "el fin importado");
            foreach (var tramo in importadas.Tramos)
            {
                tramo.Inicio = MoverFecha(tramo.Inicio, tarea, "el inicio del tramo importado");
                tramo.Fin = MoverFecha(tramo.Fin, tarea, "el fin del tramo importado");
            }
            if (activas.Contains(tarea.Id))
            {
                importadas.InicioProyecto = copia.FechaInicio;
                importadas.FirmaCalendario = firmaCalendario;
                importadas.FirmaPredecesoras = MYGMotorCronograma.FirmaPredecesorasDelphin(tarea);
                // Primera pasada: todas las instantáneas activas ya contienen
                // las fechas trasladadas. Después se sellan sus antecesoras.
                importadas.FirmaAntecesoras = null;
            }
        }
        var intermedio = MYGMotorCronograma.Calcular(copia);
        var tareas = copia.Tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        var filasIntermedias = intermedio.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var tarea in copia.Tareas.Where(t => activas.Contains(t.Id)))
            tarea.FechasImportadasDelphin.FirmaAntecesoras = MYGMotorCronograma.FirmaAntecesorasDelphin(tarea, tareas, filasIntermedias);
        var despues = MYGMotorCronograma.Calcular(copia);
        var filasAntes = antes.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var fila in despues.Filas)
        {
            var anterior = filasAntes[fila.Tarea.Id];
            bool activaDespues = MYGMotorCronograma.ConservaFechasDelphin(fila.Tarea);
            if (activaDespues != activas.Contains(fila.Tarea.Id) ||
                fila.DuracionDias != anterior.DuracionDias ||
                calendario.Primero(fila.Inicio) - calendario.Primero(anterior.Inicio) != desfase ||
                calendario.AnteriorOIgual(fila.Fin) - calendario.AnteriorOIgual(anterior.Fin) != desfase)
                throw new InvalidDataException("No se puede trasladar el bloque conservando las fechas relativas y la configuración de «" + fila.Tarea.Nombre + "». No se aplicó el cambio.");
        }
        var conflictosAntes = Conflictos(original, antes, calendario);
        foreach (var conflicto in Conflictos(copia, despues, calendario))
            if (conflicto.Value > conflictosAntes.GetValueOrDefault(conflicto.Key))
                throw new InvalidDataException("El traslado introduciría o empeoraría un conflicto de " + conflicto.Key.Tipo +
                    " en la tarea «" + tareas[conflicto.Key.Tarea].Nombre + "». No se aplicó el cambio; revise sus predecesoras y restricciones.");
        return copia;
    }

    private readonly record struct ClaveConflicto(string Tipo, string Tarea, string Predecesora = "");

    private static Dictionary<ClaveConflicto, long> Conflictos(MYGCronograma plan, MYGResultadoCronograma resultado,
        MYGCalendarioEntero calendario)
    {
        var conflictos = new Dictionary<ClaveConflicto, long>();
        var filas = resultado.Filas.ToDictionary(f => f.Tarea.Id, StringComparer.Ordinal);
        foreach (var tarea in plan.Tareas.Where(t => !t.EsResumen))
        {
            var fila = filas[tarea.Id];
            foreach (var vinculo in tarea.Predecesoras)
            {
                var anterior = filas[vinculo.PredecesoraId];
                long requerido = vinculo.Tipo switch
                {
                    MYGTipoVinculo.FC => calendario.Despues(anterior.Fin) + vinculo.DesfaseDias,
                    MYGTipoVinculo.CC => calendario.Primero(anterior.Inicio) + vinculo.DesfaseDias,
                    MYGTipoVinculo.FF => calendario.Primero(anterior.Fin) + vinculo.DesfaseDias,
                    _ => calendario.Primero(anterior.Inicio) + vinculo.DesfaseDias
                };
                DateTime actual = vinculo.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC ? fila.Inicio : fila.Fin;
                long incumplimiento = requerido - calendario.AnteriorOIgual(actual);
                if (incumplimiento > 0)
                    conflictos[new("vínculo " + vinculo.Tipo, tarea.Id, vinculo.PredecesoraId)] = incumplimiento;
            }
            if (MYGInformacionTarea.RequiereFecha(tarea.TipoRestriccion))
            {
                DateTime fecha = tarea.FechaRestriccion.Value.Date;
                bool incumple = tarea.TipoRestriccion switch
                {
                    MYGTipoRestriccion.NoComenzarAntesDe => fila.Inicio < fecha,
                    MYGTipoRestriccion.NoComenzarDespuesDe => fila.Inicio > fecha,
                    MYGTipoRestriccion.NoFinalizarAntesDe => fila.Fin < fecha,
                    MYGTipoRestriccion.NoFinalizarDespuesDe => fila.Fin > fecha,
                    MYGTipoRestriccion.DebeComenzarEl => fila.Inicio != fecha,
                    _ => fila.Fin != fecha
                };
                if (incumple) conflictos[new("restricción", tarea.Id)] = 1;
                if (tarea.TipoRestriccion is MYGTipoRestriccion.DebeComenzarEl or MYGTipoRestriccion.DebeFinalizarEl &&
                    !plan.Calendario.EsLaborable(fecha))
                    conflictos[new("restricción en día no laborable", tarea.Id)] = 1;
            }
            if (tarea.Modo == MYGModoTarea.Automatica && fila.HolguraDias < 0)
                conflictos[new("holgura negativa", tarea.Id)] = -(long)fila.HolguraDias;
        }
        return conflictos;
    }
}
