using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using MYG_2027;

// Contrato de las escrituras de recurso usadas por el adaptador COM.
// Se ejecuta también en Linux sin Office ni WinForms.
internal static class ProjectRecursoConfiguracionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarNombres(exige);
        VerificarLongitudDeNombres(exige);
        VerificarNombresUnicodeLargos(exige);
        VerificarIdentidadesDeNombresAbreviados(exige);
        VerificarSeparadorDeProject(exige);
        VerificarIdentidadesYAdvertencias(exige);
        VerificarErroresDeNombre(exige);
        VerificarErroresDeCampo(exige);
        VerificarUnidades(exige);
        VerificarTipos(exige);
        VerificarCampoLiteral(exige);
        VerificarUnidadVisibleAlternativa(exige);
        VerificarErrores(exige);
    }

    private static void VerificarNombres(Action<bool, string> exige)
    {
        const string captura = "UNIDAD EVAPORADORA TIPO FANCOIL / CN: 24,000 BTU/h - 91W - 220V; 1F+N; 50 Hz";
        var casos = new (string Nombre, string Separador, string Esperado)[]
        {
            (captura, ",", "UNIDAD EVAPORADORA TIPO FANCOIL / CN: 24 000 BTU/h - 91W - 220V; 1F+N; 50 Hz"),
            (captura, ";", "UNIDAD EVAPORADORA TIPO FANCOIL / CN: 24,000 BTU/h - 91W - 220V  1F+N  50 Hz"),
            ("Acero [ASTM A36]", ";", "Acero (ASTM A36)"),
            ("[Árido];m³", ";", "(Árido) m³"),
            ("Árido 日本語 m³ / p² + 1F+N", ";", "Árido 日本語 m³ / p² + 1F+N"),
            ("  Tubería (PVC)  ", ";", "  Tubería (PVC)  "),
            ("Arena|piedra", "|", "Arena piedra"),
            ("Arena||piedra|fina", "||", "Arena piedra|fina"),
            ("Arena fina", " ", "Arena_fina"),
            ("", ";", "Recurso MYG 27"),
            (" ; ", ";", "Recurso MYG 27")
        };
        foreach (var caso in casos)
        {
            var datos = Recurso("und") with { Nombre = caso.Nombre };
            var original = datos with { };
            var simulado = new RecursoSimulado { SeparadorListas = caso.Separador };
            string aviso = MYGConfiguracionRecursoProject.Crear(datos, caso.Separador,
                simulado.Crear, simulado.Leer, simulado.Escribir);
            bool adaptado = !string.Equals(caso.Nombre, caso.Esperado, StringComparison.Ordinal);
            exige((string)simulado.Valores["Name"] == caso.Esperado && datos == original &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "create:" + caso.Esperado, "get:Name" }),
                "El nombre compatible debe llegar a Resources.Add antes de cualquier lectura/escritura, conservando símbolos válidos, cultura y datos originales.");
            exige(adaptado
                    ? (string)simulado.Valores["Notes"] == caso.Nombre && aviso != null &&
                      aviso.Contains("Notas", StringComparison.Ordinal) && simulado.Operaciones.Contains("get:Notes")
                    : aviso == null && !simulado.Valores.ContainsKey("Notes"),
                "Un nombre adaptado debe conservar su original exacto y verificado en Notas; uno válido debe permanecer intacto y sin notas decorativas.");
            exige(simulado.Valores.Keys.All(k => k is "Name" or "Notes"),
                "La compatibilidad del nombre no debe alterar tipos, unidades, códigos, tarifas, cantidades ni costos.");
        }
    }

    private static void VerificarLongitudDeNombres(Action<bool, string> exige)
    {
        foreach (int longitud in new[] { 254, 255, 256, 1024 })
        {
            var datos = Recurso("kg") with { Nombre = new string('A', longitud), Codigo = "MAT-130001", Tarifa = 1234.56789m };
            var original = datos with { };
            var simulado = new RecursoSimulado();
            string aviso = MYGConfiguracionRecursoProject.Crear(datos, ";", simulado.Crear, simulado.Leer, simulado.Escribir);
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige((string)simulado.Valores["Name"] == new string('A', Math.Min(longitud, 255)) &&
                simulado.Operaciones.First() == "create:" + (string)simulado.Valores["Name"] && datos == original,
                "Resources.Add debe recibir como máximo 255 unidades UTF-16 y conservar literalmente los nombres que ya caben, sin modificar el modelo.");
            exige(longitud > 255
                    ? (string)simulado.Valores["Notes"] == original.Nombre && aviso != null && aviso.Contains("Notas", StringComparison.Ordinal)
                    : aviso == null && !simulado.Valores.ContainsKey("Notes"),
                "Al abreviar un nombre largo, Notas debe conservar su descripción completa, incluso más de 255 caracteres; los nombres cortos no necesitan notas alternativas.");
            exige((string)simulado.Valores["Code"] == original.Codigo &&
                simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)original.Tarifa &&
                (string)simulado.Valores["MaterialLabel"] == original.Unidad,
                "El límite del nombre no debe recortar ni alterar el código, la unidad o la tarifa del recurso.");
        }

        const string montacargas = "SC SUM. E INSTAL. DE MONTACARGAS DE BASURA SIN CUARTO DE MÁQUINAS (MRL), CAP. 150 kg, 0.30 m/s, 7 PARADAS, RECORRIDO 27.00m, 380 V, 3Ø, 60 Hz, ACCESO A 90° FRONTAL Y LATERAL DERECHO, C/ESTRUCTURA METÁLICA, GUÍAS, PUERTAS BATIENTES EI-60, TABLERO DE CONTROL, MONTAJE Y PUESTA EN OPERACIÓN";
        foreach (string separador in new[] { ",", ";" })
        {
            var datos = Recurso("und") with { Nombre = montacargas };
            var simulado = new RecursoSimulado { SeparadorListas = separador };
            string aviso = MYGConfiguracionRecursoProject.Crear(datos, separador, simulado.Crear, simulado.Leer, simulado.Escribir);
            string esperado = montacargas.Replace(separador, " ", StringComparison.Ordinal).Substring(0, 255);
            exige(montacargas.Length > 255 && (string)simulado.Valores["Name"] == esperado &&
                (string)simulado.Valores["Notes"] == montacargas && aviso != null && datos.Nombre == montacargas,
                "La descripción larga del montacargas debe adaptarse al separador y al límite antes de crear el recurso, conservándose íntegra en Notas y MYG.");
        }
    }

    private static void VerificarNombresUnicodeLargos(Action<bool, string> exige)
    {
        var casos = new (string Original, string Esperado)[]
        {
            (new string('A', 254) + "😀fin", new string('A', 254)),
            (new string('A', 253) + "😀fin", new string('A', 253) + "😀"),
            (new string('A', 254) + "e\u0301fin", new string('A', 254)),
            (new string('A', 253) + "e\u0301fin", new string('A', 253) + "e\u0301")
        };
        foreach (var caso in casos)
        {
            var datos = Recurso("und") with { Nombre = caso.Original };
            var simulado = new RecursoSimulado();
            string aviso = MYGConfiguracionRecursoProject.Crear(datos, ";", simulado.Crear, simulado.Leer, simulado.Escribir);
            exige((string)simulado.Valores["Name"] == caso.Esperado && caso.Esperado.Length <= 255 &&
                (string)simulado.Valores["Notes"] == caso.Original && aviso != null && datos.Nombre == caso.Original,
                "La abreviación debe respetar pares surrogate y grafemas con acento combinado en el borde de 255 unidades UTF-16; Notas conserva el Unicode completo.");
        }
    }

    private static void VerificarIdentidadesDeNombresAbreviados(Action<bool, string> exige)
    {
        string prefijo = new string('M', 255);
        var primero = Recurso("und") with { Nombre = prefijo + " montaje", Codigo = "MAT-130001", Tarifa = 5432.12345m };
        var segundo = primero with { Uid = 28, Nombre = prefijo + " instalación", Codigo = "MAT-130002", Tarifa = 9876.54321m };
        var simulados = new List<RecursoSimulado>();
        foreach (var datos in new[] { primero, segundo })
        {
            var original = datos with { };
            var simulado = new RecursoSimulado();
            string aviso = MYGConfiguracionRecursoProject.Crear(datos, ";", simulado.Crear, simulado.Leer, simulado.Escribir);
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige((string)simulado.Valores["Name"] == prefijo && (string)simulado.Valores["Notes"] == original.Nombre &&
                (string)simulado.Valores["Code"] == original.Codigo && aviso != null && datos == original &&
                simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)original.Tarifa,
                "Cada nombre abreviado debe conservar por separado su descripción completa, código, tarifa y DTO de origen.");
            simulados.Add(simulado);
        }
        exige(simulados.Count == 2 && simulados.All(s => s.Operaciones.Count(o => o.StartsWith("create:", StringComparison.Ordinal)) == 1) &&
            (string)simulados[0].Valores["Code"] != (string)simulados[1].Valores["Code"] && primero.Uid != segundo.Uid,
            "Dos descripciones largas con el mismo prefijo visible deben crear dos recursos independientes, sin fusionarlos al abreviar sus nombres.");
    }

    private static void VerificarSeparadorDeProject(Action<bool, string> exige)
    {
        var culturaOriginal = CultureInfo.CurrentCulture;
        try
        {
            foreach (string cultura in new[] { "es-PE", "es-ES", "en-US", "fr-FR" })
            {
                CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo(cultura);
                // El argumento proviene de Application.ListSeparator, incluso
                // cuando no coincide con la cultura del hilo ni el LCID COM.
                var datos = Recurso("m³") with { Nombre = "Arena,fina;seca|limpia" };
                var simulado = new RecursoSimulado { SeparadorListas = "|" };
                MYGConfiguracionRecursoProject.Crear(datos, "|", simulado.Crear, simulado.Leer, simulado.Escribir);
                exige((string)simulado.Valores["Name"] == "Arena,fina;seca limpia" &&
                    (string)simulado.Valores["Notes"] == datos.Nombre,
                    "La adaptación debe obedecer al separador real de Project y conservar las comas/puntos y coma válidos aunque cambie la cultura del hilo.");
            }
        }
        finally { CultureInfo.CurrentCulture = culturaOriginal; }

        foreach (string separador in new[] { "", null })
        {
            var simulado = new RecursoSimulado();
            Exception fallo = Capturar(() => MYGConfiguracionRecursoProject.Crear(Recurso("und"), separador,
                simulado.Crear, simulado.Leer, simulado.Escribir));
            exige(fallo is InvalidDataException && simulado.Operaciones.Count == 0,
                "Un separador desconocido debe detener la creación antes de enviar un nombre posiblemente inválido a Project.");
        }
    }

    private static void VerificarIdentidadesYAdvertencias(Action<bool, string> exige)
    {
        var primero = Recurso("mes") with { Nombre = "Arena;fina" };
        var segundo = primero with { Uid = 28, Codigo = "130002", Nombre = "Arena fina" };
        var simulados = new List<RecursoSimulado>();
        foreach (var datos in new[] { primero, segundo })
        {
            var simulado = new RecursoSimulado
            {
                SeparadorListas = ";",
                FalloEtiqueta = new COMException("Etiqueta rechazada", RecursoSimulado.Error1101),
                FalloCampo = new COMException("Campo rechazado", RecursoSimulado.Error1101)
            };
            string avisoNombre = MYGConfiguracionRecursoProject.Crear(datos, ";", simulado.Crear, simulado.Leer, simulado.Escribir);
            string avisoUnidad = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
            exige((string)simulado.Valores["Code"] == datos.Codigo && (string)simulado.Valores["Name"] == "Arena fina" &&
                (string)simulado.Valores["Text1"] == "mes" && avisoUnidad != null &&
                avisoUnidad.Contains("Texto1", StringComparison.Ordinal) &&
                (datos.Uid == primero.Uid ? avisoNombre != null && (string)simulado.Valores["Notes"] == primero.Nombre : avisoNombre == null),
                "Los avisos de nombre y unidad deben coexistir, con nombre original en Notas y unidad en Texto1, sin sustituir códigos ni datos del ACU.");
            simulados.Add(simulado);
        }
        exige(simulados.Count == 2 && simulados.All(s => s.Operaciones.Count(o => o.StartsWith("create:", StringComparison.Ordinal)) == 1) &&
            (string)simulados[0].Valores["Code"] != (string)simulados[1].Valores["Code"] && primero.Uid != segundo.Uid,
            "Dos recursos cuyo nombre visible coincide tras adaptarlo deben crearse por separado y conservar sus identidades, sin deduplicación por nombre.");
    }

    private static void VerificarErroresDeNombre(Action<bool, string> exige)
    {
        var datos = Recurso("und") with { Nombre = "Acero [A36];obra" };
        var error = new COMException("Error de automatización", unchecked((int)0x80004005));
        var creacion = new RecursoSimulado { FalloCreacion = error };
        Exception fallo = Capturar(() => MYGConfiguracionRecursoProject.Crear(datos, ";", creacion.Crear, creacion.Leer, creacion.Escribir));
        exige(ReferenceEquals(fallo, error) && creacion.Operaciones.Count == 1 && creacion.Valores.Count == 0,
            "Un error al crear el recurso debe propagarse sin reintentos ni escrituras sobre un recurso inexistente.");

        var lectura = new RecursoSimulado();
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Crear(datos, ";", lectura.Crear,
            _ => throw error, lectura.Escribir));
        exige(ReferenceEquals(fallo, error) && !lectura.Valores.ContainsKey("Notes"),
            "Un error al verificar el nombre creado debe propagarse antes de escribir Notas.");

        var nombreCambiado = new RecursoSimulado { ReemplazoNombre = "Otro nombre" };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Crear(datos, ";", nombreCambiado.Crear, nombreCambiado.Leer, nombreCambiado.Escribir));
        exige(fallo is InvalidOperationException && !nombreCambiado.Valores.ContainsKey("Notes"),
            "Un nombre cambiado o truncado por Project debe detectarse antes de anunciar conservación del recurso.");

        var notas = new RecursoSimulado { FalloNotas = error };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Crear(datos, ";", notas.Crear, notas.Leer, notas.Escribir));
        exige(ReferenceEquals(fallo, error) && !notas.Valores.ContainsKey("Notes"),
            "Un fallo al escribir el nombre original en Notas debe propagarse sin declarar la exportación conservada.");

        var notasCambiadas = new RecursoSimulado { ReemplazoNotas = "Nombre truncado" };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Crear(datos, ";", notasCambiadas.Crear, notasCambiadas.Leer, notasCambiadas.Escribir));
        exige(fallo is InvalidOperationException && notasCambiadas.Operaciones.Last() == "get:Notes",
            "La pérdida o alteración del nombre original en Notas debe detectarse al verificar su lectura.");
    }

    private static void VerificarErroresDeCampo(Action<bool, string> exige)
    {
        var datos = Recurso("und") with { Nombre = "DESCRIPCION PRIVADA " + new string('Z', 4096), Codigo = "MAT-130099", Uid = 1726 };
        foreach (string campo in new[] { "Name (Resources.Add)", "Notes (escritura)", "StandardRate (escritura)" })
        {
            foreach (int envolturas in new[] { 0, 1, 2 })
            {
                var causa = new COMException("There is a problem with the field.", RecursoSimulado.Error1101);
                Exception original = causa;
                for (int i = 0; i < envolturas; i++) original = new TargetInvocationException(original);
                InvalidOperationException fallo = MYGConfiguracionRecursoProject.ErrorDeCampo(datos, campo, original);
                exige(fallo.Message.Contains(campo, StringComparison.Ordinal) &&
                    fallo.Message.Contains(datos.Codigo, StringComparison.Ordinal) &&
                    fallo.Message.Contains("UID 1726", StringComparison.Ordinal) &&
                    fallo.Message.Contains("nombre de " + datos.Nombre.Length.ToString(CultureInfo.InvariantCulture) + " caracteres", StringComparison.Ordinal) &&
                    fallo.Message.Contains("HRESULT 0x" + causa.HResult.ToString("X8", CultureInfo.InvariantCulture), StringComparison.Ordinal) &&
                    fallo.Message.Contains(causa.Message, StringComparison.Ordinal),
                    "El diagnóstico debe identificar campo, recurso, longitud y HRESULT/causa COM real, incluso con varias envolturas de reflexión.");
                exige(ReferenceEquals(fallo.InnerException, original) && ReferenceEquals(fallo.GetBaseException(), causa) &&
                    fallo.GetBaseException().HResult == RecursoSimulado.Error1101 &&
                    !fallo.Message.Contains("DESCRIPCION PRIVADA", StringComparison.Ordinal) && fallo.Message.Length < 500,
                    "El contexto del campo debe mantener toda la cadena original y su HRESULT, sin volcar la descripción larga en el mensaje de error.");
            }
        }
    }

    private static void VerificarUnidades(Action<bool, string> exige)
    {
        // El setter simulado acepta unidades literales; no presupone que
        // Project necesite o permita prefijos inventados.
        foreach (string unidad in new[] { "mes", "kg", "m³", "p²", "kg/m³", "%mo", "und", "bol", "área", "日本語", "", null, " m³ " })
        {
            var datos = Recurso(unidad);
            var original = datos with { };
            var simulado = new RecursoSimulado();
            string aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
            exige((string)simulado.Valores["MaterialLabel"] == (unidad ?? "") &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                simulado.Operaciones.Count(o => o == "set:MaterialLabel") == 1 &&
                simulado.Operaciones.Contains("get:MaterialLabel") && datos == original && aviso == null &&
                !simulado.Operaciones.Any(o => o.StartsWith("setfield:", StringComparison.Ordinal)),
                "MaterialLabel debe conservar y verificar la unidad exacta de la base, incluidos Unicode, símbolos, espacios y vacío, sin modificar el DTO.");
            exige(simulado.Valores.Keys.All(p => p is "Type" or "Code" or "Group" or "MaterialLabel" or "StandardRate") &&
                (string)simulado.Valores["Code"] == datos.Codigo && (string)simulado.Valores["Group"] == datos.Grupo,
                "Exportar una unidad no debe añadir Text1/Notes decorativos ni alterar código, grupo o nombre del origen.");
        }

        var culturaOriginal = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
            var datos = Recurso("%mo") with { Tarifa = 1234.56789m };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige(simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                (string)simulado.Valores["MaterialLabel"] == "%mo",
                "El recurso porcentual material debe recibir %mo literal y una tarifa numérica independiente de la cultura.");
        }
        finally { CultureInfo.CurrentCulture = culturaOriginal; }
    }

    private static void VerificarTipos(Action<bool, string> exige)
    {
        foreach (int tipo in new[] { 1, 2 })
        {
            var datos = Recurso(tipo == 1 ? "hh" : "%mo") with { Tipo = tipo };
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Calendario específico", simulado.Leer, simulado.Escribir);
            exige(Convert.ToInt32(simulado.Valores["Type"], CultureInfo.InvariantCulture) == (tipo == 1 ? 0 : 2) &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                !simulado.Valores.ContainsKey("MaterialLabel") && datos == original,
                "Los recursos de trabajo y el tipo de costo explícito legado deben confirmar su tipo COM sin recibir una etiqueta material.");
            exige(tipo == 1
                    ? simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                      (string)simulado.Valores["BaseCalendar"] == "Calendario específico"
                    : !simulado.Valores.ContainsKey("StandardRate") && !simulado.Valores.ContainsKey("BaseCalendar"),
                "El trabajo conserva tarifa y calendario, y el costo explícito legado no debe convertirse en trabajo o material.");
        }
    }

    private static void VerificarCampoLiteral(Action<bool, string> exige)
    {
        foreach (int codigo in new[] { RecursoSimulado.Error1101, RecursoSimulado.ErrorArgumento })
        {
            var datos = Recurso("mes");
            var simulado = new RecursoSimulado
            {
                FalloEtiqueta = new TargetInvocationException(new COMException("Argumento rechazado", codigo))
            };
            string aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
            exige(aviso == null && (string)simulado.Valores["MaterialLabel"] == "mes" &&
                simulado.Operaciones.Count(o => o == "setfield:205521195") == 1 &&
                !simulado.Valores.ContainsKey("Text1") && !simulado.Valores.ContainsKey("Notes") &&
                simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                (int)simulado.Valores["Type"] == 1,
                "SetField(pjResourceMaterialLabel) debe recuperar mes literal tras 1101/E_INVALIDARG envuelto por reflexión, conservando tipo/tarifa y sin prefijos ni campo alternativo.");
        }
        var cambiado = new RecursoSimulado { ReemplazoEtiqueta = "meses" };
        string resultado = MYGConfiguracionRecursoProject.Configurar(Recurso("mes"), "Obra", cambiado.Leer, cambiado.Escribir, cambiado.EscribirCampo);
        exige(resultado == null && (string)cambiado.Valores["MaterialLabel"] == "mes" &&
            cambiado.Operaciones.Contains("setfield:205521195"),
            "Una etiqueta normalizada al escribir la propiedad debe recuperarse literalmente mediante la API de campo y verificarse.");
    }

    private static void VerificarUnidadVisibleAlternativa(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var original = datos with { };
        var simulado = new RecursoSimulado
        {
            FalloEtiqueta = new COMException("MaterialLabel temporal", RecursoSimulado.Error1101),
            FalloCampo = new TargetInvocationException(new COMException("SetField temporal", RecursoSimulado.ErrorArgumento))
        };
        string aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir, simulado.EscribirCampo);
        exige((string)simulado.Valores["MaterialLabel"] == "" && (string)simulado.Valores["Text1"] == "mes" &&
            (int)simulado.Valores["Type"] == 1 && simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
            aviso != null && aviso.Contains("mes", StringComparison.Ordinal) && aviso.Contains(datos.Nombre, StringComparison.Ordinal) &&
            aviso.Contains("Texto1", StringComparison.Ordinal) && aviso.Contains("cantidad, tarifa y costo conservados", StringComparison.Ordinal) &&
            datos == original && simulado.Operaciones.Count(o => o == "set:Type") == 1 &&
            simulado.Valores.Keys.All(p => p is "Type" or "Code" or "Group" or "MaterialLabel" or "Text1" or "StandardRate"),
            "Si Project rechaza mes por ambas APIs, debe mantener material y tarifa, dejar vacía la etiqueta, conservar mes en Texto1 y avisar claramente sin inventar unidades ni escribir cantidades/costos.");

        var normalizado = new RecursoSimulado { ReemplazoEtiqueta = "meses", ReemplazoCampo = "meses" };
        aviso = MYGConfiguracionRecursoProject.Configurar(datos, "Obra", normalizado.Leer, normalizado.Escribir, normalizado.EscribirCampo);
        exige(aviso != null && (string)normalizado.Valores["MaterialLabel"] == "" && (string)normalizado.Valores["Text1"] == "mes",
            "Si ambas APIs cambian la unidad en vez de rechazarla, la alternativa visible debe conservar la unidad exacta y explicarlo.");
    }

    private static void VerificarErrores(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var tipoRechazado = new RecursoSimulado { TipoLeido = 0 };
        Exception fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoRechazado.Leer, tipoRechazado.Escribir));
        exige(fallo is InvalidOperationException && tipoRechazado.Operaciones.SequenceEqual(new[] { "set:Type", "get:Type" }),
            "Si Project no conserva el tipo material, la configuración debe abortar antes de escribir etiquetas o tarifas.");

        var rechazoEtiqueta = new COMException("Fallo COM ajeno a validación", unchecked((int)0x80004005));
        var etiquetaConError = new RecursoSimulado { FalloEtiqueta = rechazoEtiqueta };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", etiquetaConError.Leer, etiquetaConError.Escribir, etiquetaConError.EscribirCampo));
        exige(ReferenceEquals(fallo, rechazoEtiqueta) &&
            etiquetaConError.Operaciones.Count(o => o == "set:MaterialLabel") == 1 &&
            etiquetaConError.Operaciones.Last() == "set:MaterialLabel" && !etiquetaConError.Valores.ContainsKey("StandardRate") &&
            !etiquetaConError.Operaciones.Any(o => o.StartsWith("setfield:", StringComparison.Ordinal)),
            "Un fallo COM ajeno a validación debe propagarse con HRESULT/causa, sin ocultarlo usando campos alternativos ni continuar con tarifas.");

        var campoConError = new RecursoSimulado { FalloEtiqueta = new COMException("Etiqueta inválida", RecursoSimulado.Error1101), FalloCampo = rechazoEtiqueta };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", campoConError.Leer, campoConError.Escribir, campoConError.EscribirCampo));
        exige(ReferenceEquals(fallo, rechazoEtiqueta) && !campoConError.Valores.ContainsKey("Text1"),
            "Un fallo COM real en SetField debe propagarse sin disfrazarlo como rechazo de etiqueta ni guardar una exportación incompleta.");

        var textoConError = new RecursoSimulado
        {
            FalloEtiqueta = new COMException("Etiqueta inválida", RecursoSimulado.Error1101),
            FalloCampo = new COMException("Campo inválido", RecursoSimulado.Error1101), FalloTexto = rechazoEtiqueta
        };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", textoConError.Leer, textoConError.Escribir, textoConError.EscribirCampo));
        exige(ReferenceEquals(fallo, rechazoEtiqueta) && !textoConError.Valores.ContainsKey("StandardRate"),
            "Un error al conservar la unidad en Texto1 debe propagarse y nunca producir un aviso de éxito falso.");

        var textoCambiado = new RecursoSimulado
        {
            FalloEtiqueta = new COMException("Etiqueta inválida", RecursoSimulado.Error1101),
            FalloCampo = new COMException("Campo inválido", RecursoSimulado.Error1101), ReemplazoTexto = "m"
        };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", textoCambiado.Leer, textoCambiado.Escribir, textoCambiado.EscribirCampo));
        exige(fallo is InvalidOperationException && fallo.Message.Contains("Texto1", StringComparison.Ordinal) && !textoCambiado.Valores.ContainsKey("StandardRate"),
            "La alternativa visible debe verificar la unidad exacta; una cadena cambiada o truncada no puede pasar como exportación conservada.");

        var errorTipo = new COMException("Fallo COM al asignar Type", unchecked((int)0x80020009));
        var tipoConError = new RecursoSimulado { FalloTipo = errorTipo };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoConError.Leer, tipoConError.Escribir));
        exige(ReferenceEquals(fallo, errorTipo) && tipoConError.Operaciones.SequenceEqual(new[] { "set:Type" }),
            "Un error COM al establecer el tipo debe propagarse sin continuar con otros datos.");

        var errorTarifa = new COMException("Error COM específico en StandardRate", unchecked((int)0x80020009));
        var tarifaConError = new RecursoSimulado { FalloTarifa = errorTarifa };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tarifaConError.Leer, tarifaConError.Escribir));
        exige(ReferenceEquals(fallo, errorTarifa) && tarifaConError.Operaciones.Count(o => o == "set:StandardRate") == 1 &&
            tarifaConError.Operaciones.Last() == "set:StandardRate" && (string)tarifaConError.Valores["MaterialLabel"] == "mes",
            "Un error de tarifa debe conservar su excepción sin reintentos que lo oculten como un problema de unidades.");

        var desconocido = new RecursoSimulado();
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos with { Tipo = 37 }, "Obra", desconocido.Leer, desconocido.Escribir));
        exige(fallo is InvalidDataException && desconocido.Operaciones.Count == 0,
            "Un tipo de recurso desconocido debe rechazarse antes de cualquier escritura COM.");
    }

    private static MYGRecursoExportacionProject Recurso(string unidad) =>
        new(27, 0, "Recurso de prueba", "130001", "Materiales", unidad, 22.07m);

    private static Exception Capturar(Action accion)
    {
        try { accion(); return null; }
        catch (Exception ex) { return ex; }
    }

    private sealed class RecursoSimulado
    {
        internal const int Error1101 = unchecked((int)0x800A044D), ErrorArgumento = unchecked((int)0x80070057);
        internal readonly Dictionary<string, object> Valores = new(StringComparer.Ordinal);
        internal readonly List<string> Operaciones = new();
        internal int? TipoLeido;
        internal string SeparadorListas = ";", ReemplazoNombre, ReemplazoNotas;
        internal Exception FalloCreacion, FalloNotas;
        internal string ReemplazoEtiqueta, ReemplazoCampo, ReemplazoTexto;
        internal Exception FalloTipo, FalloEtiqueta, FalloCampo, FalloTarifa, FalloTexto;
        private bool tipoConfirmado;

        internal void Crear(string nombre)
        {
            Operaciones.Add("create:" + nombre);
            if (FalloCreacion != null) throw FalloCreacion;
            if (nombre.Length > 255)
                throw new COMException("There is a problem with the field: Name supera 255 caracteres.", Error1101);
            if (nombre.Contains('[', StringComparison.Ordinal) || nombre.Contains(']', StringComparison.Ordinal) ||
                nombre.Contains(SeparadorListas, StringComparison.Ordinal))
                throw new COMException("Nombre con corchetes o separador de listas", Error1101);
            Valores["Name"] = ReemplazoNombre ?? nombre;
        }

        internal object Leer(string propiedad)
        {
            Operaciones.Add("get:" + propiedad);
            object valor = propiedad == "Type" && TipoLeido.HasValue ? TipoLeido.Value : Valores[propiedad];
            if (propiedad == "Type") tipoConfirmado = Convert.ToInt32(valor, CultureInfo.InvariantCulture) ==
                Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture);
            return valor;
        }

        internal void Escribir(string propiedad, object valor)
        {
            Operaciones.Add("set:" + propiedad);
            if (propiedad == "Notes" && FalloNotas != null) throw FalloNotas;
            if (propiedad == "Notes" && ReemplazoNotas != null) valor = ReemplazoNotas;
            if (propiedad == "Type")
            {
                tipoConfirmado = false;
                if (FalloTipo != null) throw FalloTipo;
            }
            if (propiedad == "MaterialLabel")
            {
                if (!tipoConfirmado || Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture) != 1)
                    throw new InvalidOperationException("MaterialLabel requiere Type material confirmado.");
                if ((string)valor != "" && FalloEtiqueta != null) throw FalloEtiqueta;
                if ((string)valor != "" && ReemplazoEtiqueta != null) valor = ReemplazoEtiqueta;
            }
            if (propiedad == "Text1" && FalloTexto != null) throw FalloTexto;
            if (propiedad == "Text1" && ReemplazoTexto != null) valor = ReemplazoTexto;
            if (propiedad == "StandardRate" && FalloTarifa != null) throw FalloTarifa;
            Valores[propiedad] = valor;
        }

        internal void EscribirCampo(int campo, string valor)
        {
            Operaciones.Add("setfield:" + campo.ToString(CultureInfo.InvariantCulture));
            if (campo != MYGConfiguracionRecursoProject.CampoEtiquetaMaterial) throw new Exception("Se intentó escribir un campo distinto de MaterialLabel.");
            if (FalloCampo != null) throw FalloCampo;
            Valores["MaterialLabel"] = ReemplazoCampo ?? valor;
        }
    }
}
