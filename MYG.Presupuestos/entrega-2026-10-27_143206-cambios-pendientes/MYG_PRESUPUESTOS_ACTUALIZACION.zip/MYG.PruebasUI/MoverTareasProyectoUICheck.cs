using System;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class MoverTareasProyectoUICheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        DateTime inicio = new(2026, 10, 5), nuevo = inicio.AddDays(7);
        var plan = new MYGCronograma { FechaInicio = inicio, FechaEstado = inicio.AddDays(2) };
        plan.Calendario.DiasLaborables = Enum.GetValues<DayOfWeek>().ToList();
        var a = new MYGTareaCronograma { Nombre = "Primera", DuracionDias = 3 };
        var b = new MYGTareaCronograma { Nombre = "Sucesora", DuracionDias = 2 };
        b.Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = a.Id, Tipo = MYGTipoVinculo.FC, DesfaseDias = 1 });
        plan.Tareas.Add(a); plan.Tareas.Add(b);
        var original = new MYGProyectoDocumento { Nombre = "Prueba de traslado", Datos = Datos(inicio), Cronograma = plan };
        string firma = JsonSerializer.Serialize(original);
        using var owner = new Form();
        owner.Show();

        using (var dialogo = new MYGMoverTareasProyectoDialog(inicio, nuevo))
        {
            exige(dialogo.MoverTareas && dialogo.CancelButton is Button cerrar && cerrar.DialogResult == DialogResult.Cancel,
                "El diálogo debe proponer Mover tareas y permitir cancelar sin aceptar cambios.");
            dialogo.Controls.Find("mover_tareas_no", true).OfType<RadioButton>().Single().Checked = true;
            exige(!dialogo.MoverTareas, "No mover tareas debe ser una elección exclusiva de Mover tareas.");
        }

        var movido = Preparar(true, Datos(nuevo));
        var filasAntes = MYGMotorCronograma.Calcular(plan).Filas;
        var filasDespues = MYGMotorCronograma.Calcular(movido.Candidato.Cronograma).Filas;
        exige(movido.Aceptado && movido.Modales == 1 && movido.Candidato.Datos.FechaInicio == nuevo &&
            filasAntes.All(f => filasDespues.Single(n => n.Tarea.Id == f.Tarea.Id).Inicio == f.Inicio.AddDays(7)) &&
            JsonSerializer.Serialize(original) == firma,
            "Aceptar Mover debe preparar metadatos y tareas vinculadas en una copia, sin modificar el original.");

        var quieto = Preparar(false, Datos(nuevo));
        exige(quieto.Aceptado && quieto.Modales == 1 && quieto.Candidato.Datos.FechaInicio == nuevo &&
            JsonSerializer.Serialize(quieto.Candidato.Cronograma) == JsonSerializer.Serialize(plan) &&
            JsonSerializer.Serialize(original) == firma,
            "No mover debe cambiar sólo los datos del proyecto y conservar íntegramente su cronograma previo.");

        var cancelado = Preparar(null, Datos(nuevo));
        exige(!cancelado.Aceptado && cancelado.Modales == 1 && cancelado.Candidato == null &&
            JsonSerializer.Serialize(original) == firma,
            "Cerrar el diálogo debe cancelar también los datos pendientes, sin una aplicación parcial.");

        var mismo = Preparar(null, Datos(inicio));
        exige(mismo.Aceptado && mismo.Modales == 0 &&
            JsonSerializer.Serialize(mismo.Candidato.Cronograma) == JsonSerializer.Serialize(plan) &&
            JsonSerializer.Serialize(original) == firma,
            "Editar otros datos sin cambiar el día de inicio no debe mostrar el diálogo ni reprogramar tareas.");
        owner.Close();

        (bool Aceptado, MYGProyectoDocumento Candidato, int Modales) Preparar(bool? mover, MYGDatosProyecto datos)
        {
            int modales = 0;
            Exception error = null;
            using var timer = new System.Windows.Forms.Timer { Interval = 30 };
            var reloj = Stopwatch.StartNew();
            timer.Tick += (_, _) =>
            {
                var formulario = Application.OpenForms.OfType<MYGMoverTareasProyectoDialog>().FirstOrDefault();
                if (formulario == null)
                {
                    if (reloj.ElapsedMilliseconds > 5000)
                    {
                        error = new TimeoutException("No se encontró el diálogo de traslado esperado.");
                        timer.Stop();
                        foreach (Form ventana in owner.OwnedForms) ventana.Close();
                    }
                    return;
                }
                timer.Stop(); modales++;
                if (mover.HasValue)
                    formulario.Controls.Find(mover.Value ? "mover_tareas_si" : "mover_tareas_no", true)
                        .OfType<RadioButton>().Single().Checked = true;
                formulario.Controls.Find(mover.HasValue ? "mover_tareas_aceptar" : "mover_tareas_cerrar", true)
                    .OfType<Button>().Single().PerformClick();
            };
            timer.Start();
            bool aceptado = MYGCambioInicioProyecto.Preparar(owner, original, "Nombre actualizado", datos, out var candidato);
            timer.Stop();
            if (error != null) throw error;
            return (aceptado, candidato, modales);
        }
        static MYGDatosProyecto Datos(DateTime fecha)
        {
            var datos = new MYGDatosProyecto { FechaInicio = fecha };
            datos.CalcularFin(); return datos;
        }
    }
}
