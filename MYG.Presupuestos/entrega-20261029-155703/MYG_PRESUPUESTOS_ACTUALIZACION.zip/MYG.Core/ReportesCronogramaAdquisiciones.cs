using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MYG_2027;

public static partial class MYGReportesCronograma
{
    private sealed record ClaveRecurso(string Moneda, MYGGrupoRecurso Grupo, string Codigo, string Descripcion,
        string Proveedor, string Unidad, decimal Precio);
    private sealed class RecursoProgramado
    {
        internal Dictionary<DateTime, decimal> Cantidades = new();
        internal Dictionary<DateTime, decimal> Costos = new();
    }

    /// <summary>Calendario continuo por moneda: cantidades y parciales mensuales,
    /// subtotales por tipo y total general. Los recursos se distribuyen con el
    /// mismo calendario y reparto temporal del valorizado, a partir del Gantt.</summary>
    public static IReadOnlyList<MYGHojaReporteProyecto> CrearAdquisiciones(
        MYGProyectoDocumento documento, MYGCronograma plan, string presupuestoId = null)
    {
        var partidas = PrepararPartidas(documento, plan, out _, presupuestoId);
        string titulo = "CALENDARIO DE ADQUISICIONES MATERIALES DEL " + (presupuestoId == null ? "PROYECTO" : "PRESUPUESTO");
        var datos = Datos(documento, plan).ToList();
        datos.Add(new("Presupuesto", presupuestoId == null ? "Todos los presupuestos" :
            documento.Presupuestos.Single(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).ToString()));
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        var recursos = new Dictionary<ClaveRecurso, RecursoProgramado>();
        foreach (var p in partidas)
        {
            var catalogo = p.Presupuesto.Costos.Insumos.ToDictionary(i => i.Id, StringComparer.Ordinal);
            var reales = p.Calculo.Consolidar(p.Partida).Where(i => catalogo.ContainsKey(i.Clave)).ToArray();
            var distribuidos = reales.Select(i => (Insumo: i,
                Cantidades: RepartirProgramado(p, calendario, i.Cantidad, p.Presupuesto.Costos.DecimalesCantidad),
                Costos: RepartirProgramado(p, calendario, i.Total, p.Presupuesto.Costos.DecimalesPrecio))).ToArray();
            // Redondear cada recurso por separado puede cambiar el total de un
            // mes en unos céntimos. Conciliar contra el subtotal real de esta
            // tarea conserva tanto sus meses como el total de cada recurso.
            if (distribuidos.Length > 0)
                ConciliarCostosRecursos(distribuidos.Select(r => r.Costos).ToArray(),
                    RepartirProgramado(p, calendario, reales.Sum(i => i.Total), p.Presupuesto.Costos.DecimalesPrecio));
            foreach (var distribuido in distribuidos)
            {
                var i = distribuido.Insumo;
                // No convertir precios directos, porcentajes ni ajustes
                // sintéticos en compras. Mantener proveedores distintos aun
                // cuando el formato impreso no incluya esa columna.
                if (!catalogo.TryGetValue(i.Clave, out var fuente)) continue;
                var clave = new ClaveRecurso(Moneda(p.Presupuesto), i.Grupo, i.Codigo ?? "", i.Descripcion ?? "",
                    string.IsNullOrWhiteSpace(fuente.Proveedor) ? "SIN CLASIFICAR" : fuente.Proveedor.Trim(), i.Unidad ?? "", i.Precio);
                if (!recursos.TryGetValue(clave, out var recurso)) recursos.Add(clave, recurso = new());
                foreach (var mes in distribuido.Cantidades)
                    recurso.Cantidades[mes.Key] = recurso.Cantidades.GetValueOrDefault(mes.Key) + mes.Value;
                foreach (var mes in distribuido.Costos)
                    recurso.Costos[mes.Key] = recurso.Costos.GetValueOrDefault(mes.Key) + mes.Value;
            }
        }
        if (recursos.Count == 0)
        {
            var vacio = SinDatos(documento, plan, titulo, "Sin recursos reales requeridos por las partidas programadas.");
            return new[] { new MYGHojaReporteProyecto(titulo, vacio.Hoja, datos) };
        }
        var reportes = new List<MYGHojaReporteProyecto>();
        foreach (var moneda in recursos.GroupBy(r => r.Key.Moneda, StringComparer.OrdinalIgnoreCase))
        {
            var filas = moneda.OrderBy(r => r.Key.Grupo).ThenBy(r => r.Key.Descripcion, StringComparer.OrdinalIgnoreCase)
                .ThenBy(r => r.Key.Codigo, StringComparer.OrdinalIgnoreCase).ThenBy(r => r.Key.Proveedor, StringComparer.OrdinalIgnoreCase).ToArray();
            var programadas = partidas.Where(p => string.Equals(Moneda(p.Presupuesto), moneda.Key, StringComparison.OrdinalIgnoreCase)).ToArray();
            var fechasCompras = filas.SelectMany(r => r.Value.Cantidades.Keys).ToArray();
            DateTime inicio = Menor(programadas.Min(p => p.Fila.Inicio), fechasCompras.Min());
            DateTime fin = Mayor(programadas.Max(p => p.Fila.Fin), fechasCompras.Max());
            if (documento.Datos?.FechaFin is DateTime finProyecto) fin = Mayor(fin, finProyecto.Date);
            var periodos = Periodos(inicio, fin, false);
            // El modelo de hojas permite 200 columnas y 200.000 celdas. No
            // fragmentar el total general en tramos que parezcan otros totales.
            if (periodos.Length > 97)
                throw new InvalidDataException("El calendario de adquisiciones admite hasta 97 meses por moneda. Reduzca el alcance de la programación.");
            int columnas = 6 + periodos.Length * 2;
            int ultimaFila = 10 + filas.Length + filas.Select(r => r.Key.Grupo).Distinct().Count();
            if (OpcionBool(LeerPresentacion(plan), "ImprimirInformacionPagina", false)) ultimaFila++;
            if (ultimaFila > 10000 || (long)ultimaFila * columnas > 200000)
                throw new InvalidDataException("El calendario de adquisiciones supera el límite de una hoja (10.000 filas y 200.000 celdas). Seleccione un presupuesto o reduzca el alcance.");
            var h = Hoja("Adquisiciones " + (reportes.Count + 1), new[] { 120, 480, 42, 70 }, columnas - 4, 84);
            h.AnchosColumnas[columnas - 1] = 88; h.AnchosColumnas[columnas] = 104;
            CabeceraAdquisiciones(h, documento, presupuestoId, titulo, moneda.Key, periodos);
            var nivelesTitulos = new Dictionary<int, int>();
            var divisibles = new List<string>();
            int fila = 10;
            foreach (var grupo in filas.GroupBy(r => r.Key.Grupo))
            {
                int primera = fila;
                foreach (var r in grupo)
                {
                    for (int c = 1; c <= columnas; c++) Texto(h, fila, c, "");
                    if (fila == primera) Texto(h, fila, 1, MYGMotorPresupuestos.Grupo(grupo.Key));
                    Texto(h, fila, 2, r.Key.Descripcion);
                    Texto(h, fila, 3, r.Key.Unidad, alineacion: "Centro");
                    Numero(h, fila, 4, r.Key.Precio, "#,##0.00");
                    for (int n = 0; n < periodos.Length; n++)
                    {
                        decimal cantidad = r.Value.Cantidades.GetValueOrDefault(periodos[n].Inicio);
                        decimal parcial = r.Value.Costos.GetValueOrDefault(periodos[n].Inicio);
                        if (cantidad != 0) Numero(h, fila, 5 + n * 2, cantidad);
                        if (parcial != 0) Numero(h, fila, 6 + n * 2, parcial);
                    }
                    Numero(h, fila, columnas - 1, r.Value.Cantidades.Values.Sum());
                    Numero(h, fila, columnas, r.Value.Costos.Values.Sum());
                    for (int c = columnas - 1; c <= columnas; c++) Celda(h, fila, c).ColorFondo = "ECEEF1";
                    h.AltosFilas[fila++] = 22;
                }
                if (fila - primera > 1)
                {
                    string rango = "A" + primera + ":A" + (fila - 1);
                    h.RangosCombinados.Add(rango); divisibles.Add(rango);
                }
                FilaTotalAdquisiciones(h, fila, "Total " + MYGMotorPresupuestos.Grupo(grupo.Key), grupo.ToArray(), periodos, false);
                nivelesTitulos.Add(fila++, 0);
            }
            FilaTotalAdquisiciones(h, fila, "Total General", filas, periodos, true);
            h.CeldaTotal = MYGHojaCalculo.Columna(columnas) + fila;
            Terminar(h, fila);
            AjustarTextoAdquisiciones(h);
            reportes.Add(new(titulo + " · " + moneda.Key, h, datos, nivelesTitulos: nivelesTitulos,
                cabeceraEnHoja: true, rangosDivisiblesEntrePaginas: divisibles, ajustarAUnaPaginaDeAncho: true));
        }
        return AplicarPresentacion(reportes, plan);
    }

    private static void ConciliarCostosRecursos(Dictionary<DateTime, decimal>[] recursos,
        Dictionary<DateTime, decimal> objetivo)
    {
        var diferencias = objetivo.OrderBy(m => m.Key).ToDictionary(m => m.Key,
            m => m.Value - recursos.Sum(r => r.GetValueOrDefault(m.Key)));
        var receptores = diferencias.Keys.Where(m => diferencias[m] > 0).ToArray();
        int receptor = 0;
        foreach (var donante in diferencias.Keys.Where(m => diferencias[m] < 0).ToArray())
        foreach (var recurso in recursos)
        {
            while (diferencias[donante] < 0 && recurso.GetValueOrDefault(donante) > 0 && receptor < receptores.Length)
            {
                DateTime mes = receptores[receptor];
                decimal ajuste = Math.Min(recurso[donante], Math.Min(-diferencias[donante], diferencias[mes]));
                recurso[donante] -= ajuste;
                recurso[mes] = recurso.GetValueOrDefault(mes) + ajuste;
                diferencias[donante] += ajuste; diferencias[mes] -= ajuste;
                if (diferencias[mes] == 0) receptor++;
            }
        }
        if (diferencias.Values.Any(d => d != 0))
            throw new InvalidDataException("No se pudo conciliar el reparto mensual de los recursos de una tarea.");
    }

    private static void CabeceraAdquisiciones(MYGHojaMetrado h, MYGProyectoDocumento d, string presupuestoId,
        string titulo, string moneda, Periodo[] periodos)
    {
        h.AltosFilas.Clear(); h.FilasInmovilizadas = 9; h.ColumnasInmovilizadas = 4;
        h.AjustarImpresionAUnaPaginaAncho = true;
        string ultima = MYGHojaCalculo.Columna(h.Columnas);
        var celdaTitulo = Texto(h, 1, 1, titulo, true, "Centro"); celdaTitulo.TamanoFuente = 12; celdaTitulo.Bordes = false;
        h.RangosCombinados.Add("A1:" + ultima + "1"); h.AltosFilas[1] = 30; h.AltosFilas[2] = 12;
        string ubicacion = "DPTO: " + (d.Datos?.Departamento ?? "") + "  PROV: " + (d.Datos?.Provincia ?? "") + "  DIST: " + (d.Datos?.Distrito ?? "");
        var cabecera = new[] { ("PROYECTO", d.Nombre ?? ""), ("PROPIETARIO", d.Datos?.Propietario ?? ""),
            ("UBICACIÓN", ubicacion), ("FECHA DE PROY.", d.Datos?.FechaElaboracion?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "No registrado") };
        for (int n = 0; n < cabecera.Length; n++)
        {
            int fila = n + 3;
            Texto(h, fila, 1, cabecera[n].Item1 + ":").Bordes = false;
            Texto(h, fila, 2, cabecera[n].Item2).Bordes = false;
            h.RangosCombinados.Add("B" + fila + ":" + ultima + fila);
            h.AltosFilas[fila] = n == 0 ? 36 : 22;
        }
        if (presupuestoId != null)
        {
            Texto(h, 7, 1, "PRESUPUESTO:").Bordes = false;
            Texto(h, 7, 2, d.Presupuestos.Single(p => string.Equals(p.Id, presupuestoId, StringComparison.OrdinalIgnoreCase)).ToString()).Bordes = false;
            h.RangosCombinados.Add("B7:" + ultima + "7");
        }
        h.AltosFilas[7] = presupuestoId == null ? 12 : 24;
        h.AltosFilas[8] = 32; h.AltosFilas[9] = 22;
        for (int c = 1; c <= h.Columnas; c++)
            for (int f = 8; f <= 9; f++) Texto(h, f, c, "", false, "Centro").ColorFondo = "ECEEF1";
        string[] titulos = { "Tipo", "Descripción", "Unidad", "Precio Unit." };
        for (int c = 1; c <= 4; c++)
        {
            Celda(h, 8, c).Contenido = titulos[c - 1];
            h.RangosCombinados.Add(MYGHojaCalculo.Columna(c) + "8:" + MYGHojaCalculo.Columna(c) + "9");
        }
        for (int n = 0; n < periodos.Length; n++)
        {
            int c = 5 + n * 2;
            var mes = Celda(h, 8, c); mes.Contenido = "Mes " + (n + 1); mes.Negrita = true;
            h.RangosCombinados.Add(MYGHojaCalculo.Columna(c) + "8:" + MYGHojaCalculo.Columna(c + 1) + "8");
            Celda(h, 9, c).Contenido = "Cantidad"; Celda(h, 9, c + 1).Contenido = "Parcial " + moneda;
        }
        Celda(h, 8, h.Columnas - 1).Contenido = "Total Cantidad";
        Celda(h, 8, h.Columnas).Contenido = "Total Parcial " + moneda;
        for (int c = h.Columnas - 1; c <= h.Columnas; c++)
            h.RangosCombinados.Add(MYGHojaCalculo.Columna(c) + "8:" + MYGHojaCalculo.Columna(c) + "9");
    }

    private static void FilaTotalAdquisiciones(MYGHojaMetrado h, int fila, string titulo,
        KeyValuePair<ClaveRecurso, RecursoProgramado>[] recursos, Periodo[] periodos, bool general)
    {
        for (int c = 1; c <= h.Columnas; c++) Texto(h, fila, c, "");
        Texto(h, fila, 1, titulo);
        h.RangosCombinados.Add("A" + fila + ":D" + fila);
        for (int n = 0; n < periodos.Length; n++)
            Numero(h, fila, 6 + n * 2, recursos.Sum(r => r.Value.Costos.GetValueOrDefault(periodos[n].Inicio)));
        // Nunca sumar cantidades de recursos con unidades distintas.
        Numero(h, fila, h.Columnas, recursos.Sum(r => r.Value.Costos.Values.Sum()), negrita: general);
        for (int c = 1; c <= h.Columnas; c++) Celda(h, fila, c).ColorFondo = "ECEEF1";
        h.AltosFilas[fila] = 23;
    }

    private static void AjustarTextoAdquisiciones(MYGHojaMetrado h)
    {
        var motor = new MYGHojaCalculo(h);
        // Compensar la conversión de anchos de Excel para Arial Narrow 9,
        // midiendo el número formateado (separadores y decimales incluidos).
        foreach (var entrada in h.Celdas)
        {
            var posicion = MYGHojaCalculo.Coordenadas(entrada.Key);
            if (posicion.Columna < 3 || posicion.Fila < 10) continue;
            double medida = AnchoLineaValorizado(motor.Mostrar(entrada.Key), entrada.Value);
            h.AnchosColumnas[posicion.Columna] = Math.Max(h.AnchosColumnas[posicion.Columna],
                (int)Math.Min(1790, Math.Ceiling(medida * 7d / 5d + 18)));
        }
        foreach (var entrada in h.Celdas)
        {
            var posicion = MYGHojaCalculo.Coordenadas(entrada.Key);
            var celda = entrada.Value;
            celda.ColorTexto = "000000"; celda.AlineacionVertical = "Centro";
            celda.AjustarTexto = posicion.Columna <= 2 || posicion.Fila <= 9;
            // La columna descriptiva crece en alto, no en ancho; las celdas
            // de cabecera combinadas conservan todo el ancho de la tabla.
            if (posicion.Fila < 10 || posicion.Columna != 2) continue;
            int lineas = LineasValorizado(motor.Mostrar(entrada.Key), (h.AnchosColumnas[2] - 18) * 5d / 7d, celda);
            h.AltosFilas[posicion.Fila] = Math.Min(546, Math.Max(22, (int)Math.Ceiling(lineas * 16d + 6)));
        }
        // Excel no autoajusta filas combinadas: dimensionar también los datos
        // generales, sin aumentar la primera fila de cada tipo vertical.
        foreach (string rango in h.RangosCombinados)
        {
            var extremos = rango.Split(':');
            var desde = MYGHojaCalculo.Coordenadas(extremos[0]);
            var hasta = MYGHojaCalculo.Coordenadas(extremos[^1]);
            if (desde.Fila != hasta.Fila || desde.Fila > 7) continue;
            string direccion = extremos[0];
            var celda = h.Celdas[direccion];
            double ancho = Enumerable.Range(desde.Columna, hasta.Columna - desde.Columna + 1).Sum(c => h.AnchosColumnas[c]);
            int lineas = LineasValorizado(motor.Mostrar(direccion), (ancho - 18) * 5d / 7d, celda);
            h.AltosFilas[desde.Fila] = Math.Max(h.AltosFilas.GetValueOrDefault(desde.Fila, 22),
                Math.Min(546, (int)Math.Ceiling(lineas * (double)celda.TamanoFuente * 1.8d + 6)));
        }
    }
}
