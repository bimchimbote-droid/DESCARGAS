using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class AdquisicionesMensualesCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Adquisiciones mensuales: " + detalle); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static int Fila(MYGHojaMetrado h, int columna, string texto) => h.Celdas
        .Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == columna && string.Equals(c.Value.Contenido, texto, StringComparison.OrdinalIgnoreCase))
        .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
    private static decimal Numero(MYGHojaMetrado h, int columna, int fila) =>
        new MYGHojaCalculo(h).Numero(MYGHojaCalculo.Columna(columna) + fila);
    private static decimal[] Cantidades(MYGHojaMetrado h, int fila) => Enumerable.Range(0, (h.Columnas - 6) / 2)
        .Select(n => Numero(h, 5 + n * 2, fila)).ToArray();
    private static decimal[] Parciales(MYGHojaMetrado h, int fila) => Enumerable.Range(0, (h.Columnas - 6) / 2)
        .Select(n => Numero(h, 6 + n * 2, fila)).ToArray();
    private static MYGCronograma Plan(DateTime inicio) => new()
    {
        FechaInicio = inicio, FechaEstado = inicio,
        Calendario = new()
        {
            DiasLaborables = new() { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
                DayOfWeek.Thursday, DayOfWeek.Friday },
            Feriados = new() { new DateTime(2026, 2, 2) }
        }
    };
    private static MYGInsumo Recurso(MYGPresupuestoDocumento p, string nombre, decimal precio)
    {
        var recurso = new MYGInsumo { Codigo = nombre, Descripcion = nombre, Unidad = "und", Precio = precio,
            Grupo = MYGGrupoRecurso.Materiales };
        p.Costos.Insumos.Add(recurso); return recurso;
    }
    private static ItemPresupuestoDelphin Partida(MYGPresupuestoDocumento p, string nombre, MYGInsumo recurso, decimal cantidad)
    {
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = (p.Items.Count + 1).ToString("00"),
            Descripcion = nombre, Unidad = "und", TipoPropuesta = "PARTIDA" };
        partida.Costos.Cantidad = 1;
        partida.Costos.Analisis.Add(new() { InsumoId = recurso.Id, Grupo = recurso.Grupo, Cantidad = cantidad });
        p.Items.Add(partida); return partida;
    }
    private static MYGTareaCronograma Tarea(MYGCronograma plan, MYGPresupuestoDocumento p,
        ItemPresupuestoDelphin partida, int dias)
    {
        var tarea = new MYGTareaCronograma { Id = partida.Id, Nombre = partida.Descripcion,
            PresupuestoId = p.Id, PartidaId = partida.Id, DuracionDias = dias };
        plan.Tareas.Add(tarea); return tarea;
    }
    private static void Conciliar(MYGHojaMetrado compras, MYGHojaMetrado valorizado, decimal[] esperado)
    {
        int totalCompras = MYGHojaCalculo.Coordenadas(compras.CeldaTotal).Fila;
        int directo = Fila(valorizado, 2, "Costo Directo");
        var adquisicionMes = Parciales(compras, totalCompras);
        var valorizadoMes = Enumerable.Range(0, valorizado.Columnas - 6).Select(n => Numero(valorizado, 7 + n, directo)).ToArray();
        Exige(adquisicionMes.SequenceEqual(esperado) && valorizadoMes.SequenceEqual(esperado),
            "los parciales mensuales de recursos no coinciden con el costo directo valorizado del mismo Gantt.");
        Exige(Numero(compras, compras.Columnas, totalCompras) == esperado.Sum() &&
            Numero(valorizado, 6, directo) == esperado.Sum(), "la conciliación mensual cambió el importe total.");
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        CruzarMeses(carpeta, pasa);
        Dependencias(pasa);
        PartesYPausas(pasa);
        UltimaParteSinPeso(pasa);
        Centavos(pasa);
        DiferenciasDeAlcance(pasa);
    }

    private static void CruzarMeses(string carpeta, Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("ADQUISICIONES SEGÚN GANTT QA"); var p = d.Presupuestos.Single();
        var material = Recurso(p, "RECURSO DOS MESES QA", 5);
        var partida = Partida(p, "ACTIVIDAD DOS MESES QA", material, 8);
        var gratuito = Recurso(p, "RECURSO SIN PRECIO QA", 0);
        partida.Costos.Analisis.Add(new() { InsumoId = gratuito.Id, Grupo = gratuito.Grupo, Cantidad = 4 });
        var plan = Plan(new DateTime(2026, 1, 29)); Tarea(plan, p, partida, 4);
        var tarea = MYGMotorCronograma.Calcular(plan).Filas.Single();
        Exige(tarea.Inicio == new DateTime(2026, 1, 29) && tarea.Fin == new DateTime(2026, 2, 4),
            "el caso no conserva las dos jornadas de enero y las dos de febrero, excluyendo el feriado del 2 de febrero.");
        string documentoAntes = Firma(d), planAntes = Firma(plan);
        var reporte = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single(); var compras = reporte.Hoja;
        var valorizado = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja;
        int fila = Fila(compras, 2, material.Descripcion), sinPrecio = Fila(compras, 2, gratuito.Descripcion);
        Exige(Cantidades(compras, fila).SequenceEqual(new[] { 4m, 4m }) &&
            Parciales(compras, fila).SequenceEqual(new[] { 20m, 20m }) &&
            Cantidades(compras, sinPrecio).SequenceEqual(new[] { 2m, 2m }) &&
            Parciales(compras, sinPrecio).All(n => n == 0),
            "una tarea que cruza mes cargó todo al inicio, contó un feriado o perdió cantidades de un recurso sin precio.");
        Conciliar(compras, valorizado, new[] { 20m, 20m });
        var solicitud = new MYGConfiguracionVistaReporte(new[] { reporte }).CapturarSolicitud();
        var copiaVista = solicitud.CrearReportes().Single().Hoja;
        Exige(Parciales(copiaVista, fila).SequenceEqual(new[] { 20m, 20m }),
            "la captura preliminar perdió el reparto mensual corregido.");
        string ruta = Path.Combine(carpeta, "Adquisiciones mensuales Gantt.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, solicitud.CrearReportes());
        var excel = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta).Single(), compras.CeldaTotal);
        Exige(new[] { Numero(excel, 5, fila), Numero(excel, 7, fila) }.SequenceEqual(new[] { 4m, 4m }) &&
            new[] { Numero(excel, 6, fila), Numero(excel, 8, fila) }.SequenceEqual(new[] { 20m, 20m }),
            "XLSX volvió a cargar compras al inicio en lugar de conservar las dos columnas mensuales calculadas.");
        Exige(Firma(d) == documentoAntes && Firma(plan) == planAntes,
            "generar/exportar el informe mutó el proyecto o las fechas.");
        pasa("Adquisiciones distribuye cantidades y parciales por jornadas Gantt entre meses, excluye feriados, conserva recursos sin precio y concilia con el valorizado en vista y XLSX");
    }

    private static void Dependencias(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("ADQUISICIONES DEPENDENCIAS QA"); var p = d.Presupuestos.Single();
        var a = Partida(p, "PREDECESORA QA", Recurso(p, "MATERIAL PREDECESORA QA", 3), 10);
        var b = Partida(p, "SUCESORA QA", Recurso(p, "MATERIAL SUCESORA QA", 5), 6);
        var plan = Plan(new DateTime(2026, 1, 29)); var tareaA = Tarea(plan, p, a, 2); var tareaB = Tarea(plan, p, b, 2);
        var simultaneo = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single().Hoja;
        Exige(simultaneo.Columnas == 8 && new MYGHojaCalculo(simultaneo).Numero(simultaneo.CeldaTotal) == 60,
            "el caso inicial no concentra ambas tareas simultáneas en enero.");
        tareaB.Predecesoras.Add(new() { PredecesoraId = tareaA.Id });
        var fecha = MYGMotorCronograma.Calcular(plan).Filas.Single(f => f.Tarea.Id == tareaB.Id);
        Exige(fecha.Inicio == new DateTime(2026, 2, 3) && fecha.Fin == new DateTime(2026, 2, 4),
            "la dependencia no desplazó la sucesora después del fin de enero y del feriado.");
        var compras = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single().Hoja;
        var valorizado = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja;
        int fila = Fila(compras, 2, "MATERIAL SUCESORA QA");
        Exige(Cantidades(compras, fila).SequenceEqual(new[] { 0m, 6m }) &&
            Parciales(compras, fila).SequenceEqual(new[] { 0m, 30m }),
            "recalcular una dependencia dejó las adquisiciones en las fechas anteriores del Gantt.");
        Conciliar(compras, valorizado, new[] { 30m, 30m });
        pasa("Las dependencias del Gantt desplazan las adquisiciones al mes calculado y conservan la concordancia mensual con el valorizado");
    }

    private static void PartesYPausas(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("ADQUISICIONES PARTES QA"); var p = d.Presupuestos.Single();
        var partida = Partida(p, "PARTIDA CON PAUSA QA", Recurso(p, "MATERIAL CON PAUSA QA", 2), 80);
        var plan = Plan(new DateTime(2026, 1, 29)); var tarea = Tarea(plan, p, partida, 8);
        tarea.Partes.AddRange(new[]
        {
            new MYGParteTarea { DesfaseInicioDias = 0, DuracionDias = 4, Cantidad = .25m, Porcentaje = 25 },
            new MYGParteTarea { DesfaseInicioDias = 44, DuracionDias = 4, Cantidad = .75m, Porcentaje = 75 }
        });
        var resultado = MYGMotorCronograma.Calcular(plan).Filas.Single();
        Exige(resultado.Inicio == new DateTime(2026, 1, 29) && resultado.Fin == new DateTime(2026, 4, 7),
            "los desfases de partes no se están midiendo sobre las jornadas del calendario de prueba.");
        var compras = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single().Hoja;
        var valorizado = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja;
        int fila = Fila(compras, 2, "MATERIAL CON PAUSA QA");
        Exige(Cantidades(compras, fila).SequenceEqual(new[] { 10m, 10m, 0m, 60m }) &&
            Parciales(compras, fila).SequenceEqual(new[] { 20m, 20m, 0m, 120m }) &&
            Numero(compras, compras.Columnas - 1, fila) == 80,
            "el reparto ignoró la proporción 25/75, colocó toda una parte al inicio o cargó adquisiciones durante la pausa de marzo.");
        Conciliar(compras, valorizado, new[] { 20m, 20m, 0m, 120m });
        pasa("Adquisiciones reparte cada parte por sus jornadas y porcentaje, deja vacíos los meses de pausa y concilia con el valorizado sin duplicar recursos");
    }

    private static void Centavos(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("ADQUISICIONES CENTAVOS QA"); var p = d.Presupuestos.Single();
        p.Costos.DecimalesCantidad = 4; p.Costos.DecimalesPrecio = 2;
        var partida = Partida(p, "TRES CENTAVOS QA", Recurso(p, "CENTAVO A QA", .01m), 1);
        foreach (string nombre in new[] { "CENTAVO B QA", "CENTAVO C QA" })
        {
            var recurso = Recurso(p, nombre, .01m);
            partida.Costos.Analisis.Add(new() { InsumoId = recurso.Id, Grupo = recurso.Grupo, Cantidad = 1 });
        }
        var plan = Plan(new DateTime(2026, 1, 30)); Tarea(plan, p, partida, 3);
        var compras = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single().Hoja;
        var valorizado = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja;
        foreach (string nombre in new[] { "CENTAVO A QA", "CENTAVO B QA", "CENTAVO C QA" })
        {
            int fila = Fila(compras, 2, nombre);
            Exige(Cantidades(compras, fila).SequenceEqual(new[] { .3333m, .6667m }) &&
                Parciales(compras, fila).All(n => n >= 0) && Parciales(compras, fila).Sum() == .01m &&
                Numero(compras, compras.Columnas, fila) == .01m,
                "conciliar centavos creó importes negativos o alteró el costo/cantidad total de un recurso.");
        }
        Conciliar(compras, valorizado, new[] { .01m, .02m });
        pasa("El reparto de centavos conserva cada recurso, evita negativos y concilia cada mes con el costo directo valorizado");
    }

    private static void UltimaParteSinPeso(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("ADQUISICIONES PARTE SIN PESO QA"); var p = d.Presupuestos.Single();
        p.Costos.DecimalesCantidad = 4;
        var partida = Partida(p, "PARTIDA ALTA PRECISIÓN QA", Recurso(p, "RECURSO ALTA PRECISIÓN QA", 0), .185m);
        partida.Costos.Cantidad = .185m;
        // Producto de dos cantidades válidas a cuatro decimales: el total
        // conserva seis decimales y no debe dejar un residuo en la parte 0%.
        decimal cantidadTotal = .185m * .185m;
        var plan = Plan(new DateTime(2026, 1, 5)); var tarea = Tarea(plan, p, partida, 2);
        tarea.Partes.AddRange(new[]
        {
            new MYGParteTarea { DesfaseInicioDias = 0, DuracionDias = 1, Cantidad = .185m, Porcentaje = 100 },
            new MYGParteTarea { DesfaseInicioDias = 40, DuracionDias = 1, Cantidad = 0, Porcentaje = 0 }
        });
        var compras = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single().Hoja;
        int fila = Fila(compras, 2, "RECURSO ALTA PRECISIÓN QA");
        Exige(Cantidades(compras, fila).SequenceEqual(new[] { cantidadTotal, 0m, 0m }) &&
            Numero(compras, compras.Columnas - 1, fila) == cantidadTotal &&
            Parciales(compras, fila).All(n => n == 0),
            "la última parte 0% recibió el residuo de cantidad de otra parte o cambió el total de alta precisión.");
        pasa("Una parte final 0% no recibe residuos de redondeo ni cantidades de alta precisión de las partes con trabajo real");
    }

    private static void DiferenciasDeAlcance(Action<string> pasa)
    {
        var d = MYGProyectoStorage.Nuevo("ADQUISICIONES ALCANCE ECONÓMICO QA"); var p = d.Presupuestos.Single();
        p.Costos.GastosGeneralesPorcentaje = 10;
        var recurso = Partida(p, "ACU REAL QA", Recurso(p, "MATERIAL REAL QA", 5), 8);
        var directo = new ItemPresupuestoDelphin { Id = "DIRECTA", IdLocalMYG = "DIRECTA", Item = "02",
            Descripcion = "PRECIO SIN RECURSOS QA", Unidad = "und", TipoPropuesta = "PARTIDA" };
        directo.Costos.Cantidad = 1; directo.Costos.PrecioDirecto = 30; p.Items.Add(directo);
        var plan = Plan(new DateTime(2026, 1, 29)); Tarea(plan, p, recurso, 4); Tarea(plan, p, directo, 1);
        var compras = MYGReportesCronograma.CrearAdquisiciones(d, plan).Single().Hoja;
        var valorizado = MYGReportesCronograma.CrearValorizado(d, plan).Single().Hoja;
        int filaDirecto = Fila(valorizado, 2, "Costo Directo"), filaTotal = MYGHojaCalculo.Coordenadas(valorizado.CeldaTotal).Fila;
        Exige(Parciales(compras, MYGHojaCalculo.Coordenadas(compras.CeldaTotal).Fila).SequenceEqual(new[] { 20m, 20m }) &&
            Numero(valorizado, 7, filaDirecto) == 50 && Numero(valorizado, 8, filaDirecto) == 20 &&
            Numero(valorizado, 7, filaTotal) == 55 && Numero(valorizado, 8, filaTotal) == 22 &&
            !compras.Celdas.Values.Any(c => c.Contenido == directo.Descripcion) &&
            Numero(compras, compras.Columnas, MYGHojaCalculo.Coordenadas(compras.CeldaTotal).Fila) == 40,
            "el calendario inventó compras para precios sin recursos o gastos generales al forzar una igualdad entre alcances económicos distintos.");
        pasa("Adquisiciones conserva el calendario del valorizado y distingue recursos reales de precios sin recursos y conceptos del pie sin inventar compras");
    }
}
