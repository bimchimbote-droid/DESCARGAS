using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace MYG_2027
{
    // Convierte los formatos admitidos por el editor al formato público de Excel.
    // No interpreta macros, relaciones externas ni fórmulas de validación.
    internal static class MYGFormatoExcelHoja
    {
        private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly CultureInfo Invariante = CultureInfo.InvariantCulture;

        public static (XElement Estilos, Dictionary<MYGCeldaHoja, int> Indices) CrearEstilos(IReadOnlyList<MYGHojaMetrado> hojas)
        {
            var normal = new MYGCeldaHoja { FormatoNumero = "General" };
            // Estos primeros tres índices conservan la compatibilidad de los informes existentes.
            var fuentes = new List<XElement> { Fuente(normal), Fuente(new MYGCeldaHoja { Negrita = true }), Fuente(new MYGCeldaHoja { Cursiva = true }) };
            var fondos = new List<XElement>
            {
                new(S + "fill", new XElement(S + "patternFill", new XAttribute("patternType", "none"))),
                new(S + "fill", new XElement(S + "patternFill", new XAttribute("patternType", "gray125")))
            };
            var bordes = new List<XElement> { Borde(false), Borde(true) };
            var indicesFuentes = fuentes.Select((valor, indice) => (valor, indice)).ToDictionary(x => x.valor.ToString(SaveOptions.DisableFormatting), x => x.indice, StringComparer.Ordinal);
            var indicesFondos = fondos.Select((valor, indice) => (valor, indice)).ToDictionary(x => x.valor.ToString(SaveOptions.DisableFormatting), x => x.indice, StringComparer.Ordinal);
            var formatos = new Dictionary<string, int>(StringComparer.Ordinal)
            { ["General"] = 0, ["0.0000"] = 164, ["#,##0.00"] = 165 };
            var xfs = new List<XElement>();
            var indices = new Dictionary<MYGCeldaHoja, int>();
            var estilos = new Dictionary<string, int>(StringComparer.Ordinal);

            int Agregar(MYGCeldaHoja celda, string horizontal = null)
            {
                string formato = string.IsNullOrWhiteSpace(celda.FormatoNumero) ? "General" : celda.FormatoNumero;
                if (!formatos.TryGetValue(formato, out int formatoId))
                {
                    formatoId = 166 + formatos.Count - 3;
                    formatos.Add(formato, formatoId);
                }
                int fuenteId = Indice(fuentes, indicesFuentes, Fuente(celda));
                int fondoId = 0;
                string fondo = Color(celda.ColorFondo);
                if (fondo.Length != 0)
                    fondoId = Indice(fondos, indicesFondos, new XElement(S + "fill", new XElement(S + "patternFill", new XAttribute("patternType", "solid"),
                        new XElement(S + "fgColor", new XAttribute("rgb", "FF" + fondo)), new XElement(S + "bgColor", new XAttribute("indexed", 64)))));
                var xf = new XElement(S + "xf", new XAttribute("numFmtId", formatoId), new XAttribute("fontId", fuenteId),
                    new XAttribute("fillId", fondoId), new XAttribute("borderId", celda.Bordes ? 1 : 0), new XAttribute("xfId", 0),
                    new XAttribute("applyNumberFormat", 1), new XAttribute("applyFont", 1), new XAttribute("applyFill", 1),
                    new XAttribute("applyBorder", 1), new XAttribute("applyAlignment", 1),
                    new XElement(S + "alignment", new XAttribute("horizontal", Horizontal(horizontal ?? celda.AlineacionHorizontal)),
                        new XAttribute("vertical", Vertical(celda.AlineacionVertical)), new XAttribute("wrapText", celda.AjustarTexto ? 1 : 0)));
                string clave = xf.ToString(SaveOptions.DisableFormatting);
                if (!estilos.TryGetValue(clave, out int indice))
                {
                    indice = xfs.Count;
                    estilos.Add(clave, indice);
                    xfs.Add(xf);
                }
                return indice;
            }
            Agregar(normal);
            foreach (var celda in hojas.SelectMany(h => h.Celdas)) indices[celda.Value] = Agregar(celda.Value, MYGEdicionHoja.AlineacionCelda(celda.Value, celda.Key));
            var raiz = new XElement(S + "styleSheet",
                new XElement(S + "numFmts", new XAttribute("count", formatos.Count - 1), formatos.Where(x => x.Value >= 164)
                    .Select(x => new XElement(S + "numFmt", new XAttribute("numFmtId", x.Value), new XAttribute("formatCode", x.Key)))),
                new XElement(S + "fonts", new XAttribute("count", fuentes.Count), fuentes),
                new XElement(S + "fills", new XAttribute("count", fondos.Count), fondos),
                new XElement(S + "borders", new XAttribute("count", bordes.Count), bordes),
                new XElement(S + "cellStyleXfs", new XAttribute("count", 1), new XElement(S + "xf", new XAttribute("numFmtId", 0),
                    new XAttribute("fontId", 0), new XAttribute("fillId", 0), new XAttribute("borderId", 0))),
                new XElement(S + "cellXfs", new XAttribute("count", xfs.Count), xfs),
                new XElement(S + "cellStyles", new XAttribute("count", 1), new XElement(S + "cellStyle", new XAttribute("name", "Normal"),
                    new XAttribute("xfId", 0), new XAttribute("builtinId", 0))));
            return (raiz, indices);
        }

        private static int Indice(List<XElement> elementos, Dictionary<string, int> indices, XElement valor)
        {
            string clave = valor.ToString(SaveOptions.DisableFormatting);
            if (indices.TryGetValue(clave, out int indice)) return indice;
            indice = elementos.Count;
            elementos.Add(valor);
            indices.Add(clave, indice);
            return indice;
        }
        private static XElement Fuente(MYGCeldaHoja celda) => new(S + "font",
            celda.Negrita ? new XElement(S + "b") : null,
            celda.Cursiva ? new XElement(S + "i") : null,
            celda.Subrayado ? new XElement(S + "u") : null,
            celda.Tachado ? new XElement(S + "strike") : null,
            new XElement(S + "sz", new XAttribute("val", celda.TamanoFuente.ToString("0.########", Invariante))),
            Color(celda.ColorTexto).Length == 0 ? null : new XElement(S + "color", new XAttribute("rgb", "FF" + Color(celda.ColorTexto))),
            new XElement(S + "name", new XAttribute("val", string.IsNullOrWhiteSpace(celda.Fuente) ? MYGCeldaHoja.FuentePredeterminada : celda.Fuente)));
        private static XElement Borde(bool mostrar) => new(S + "border",
            new[] { "left", "right", "top", "bottom" }.Select(x => new XElement(S + x, mostrar ? new XAttribute("style", "thin") : null,
                mostrar ? new XElement(S + "color", new XAttribute("rgb", "FFB2BECF")) : null)), new XElement(S + "diagonal"));
        private static string Color(string color)
        {
            color = (color ?? "").Trim().TrimStart('#').ToUpperInvariant();
            if (color.Length == 0) return "";
            if (!Regex.IsMatch(color, "^[0-9A-F]{6}$")) throw new InvalidDataException("El color debe contener seis dígitos hexadecimales RGB.");
            return color;
        }
        private static string Horizontal(string valor) => valor switch { "Centro" => "center", "Derecha" => "right", _ => "left" };
        private static string Vertical(string valor) => valor switch { "Arriba" => "top", "Abajo" => "bottom", _ => "center" };

        public static IReadOnlyList<MYGCeldaHoja> LeerEstilos(XDocument documento)
        {
            if (documento?.Root == null) return Array.Empty<MYGCeldaHoja>();
            var fuentes = documento.Root.Element(S + "fonts")?.Elements(S + "font").ToArray() ?? Array.Empty<XElement>();
            var fondos = documento.Root.Element(S + "fills")?.Elements(S + "fill").ToArray() ?? Array.Empty<XElement>();
            var bordes = documento.Root.Element(S + "borders")?.Elements(S + "border").ToArray() ?? Array.Empty<XElement>();
            var formatos = new Dictionary<int, string>
            {
                [0] = "General", [1] = "0", [2] = "0.00", [3] = "#,##0", [4] = "#,##0.00",
                [9] = "0%", [10] = "0.00%", [11] = "0.00E+00", [12] = "# ?/?", [13] = "# ??/??",
                [14] = "dd/mm/yyyy", [15] = "d-mmm-yy", [16] = "d-mmm", [17] = "mmm-yy",
                [18] = "h:mm AM/PM", [19] = "h:mm:ss AM/PM", [20] = "h:mm", [21] = "h:mm:ss",
                [22] = "dd/mm/yyyy h:mm", [37] = "#,##0 ;(#,##0)", [38] = "#,##0 ;[Red](#,##0)",
                [39] = "#,##0.00;(#,##0.00)", [40] = "#,##0.00;[Red](#,##0.00)", [45] = "mm:ss", [46] = "[h]:mm:ss", [47] = "mmss.0", [48] = "##0.0E+0", [49] = "@"
            };
            foreach (var f in documento.Root.Element(S + "numFmts")?.Elements(S + "numFmt") ?? Enumerable.Empty<XElement>())
                if (int.TryParse((string)f.Attribute("numFmtId"), NumberStyles.Integer, Invariante, out int id)) formatos[id] = (string)f.Attribute("formatCode") ?? "General";
            var resultado = new List<MYGCeldaHoja>();
            foreach (var xf in documento.Root.Element(S + "cellXfs")?.Elements(S + "xf") ?? Enumerable.Empty<XElement>())
            {
                var celda = new MYGCeldaHoja();
                int formato = Entero(xf.Attribute("numFmtId"), 0);
                celda.FormatoNumero = formatos.TryGetValue(formato, out string texto) ? texto : "General";
                int fuente = Entero(xf.Attribute("fontId"), 0);
                if (fuente >= 0 && fuente < fuentes.Length)
                {
                    var f = fuentes[fuente];
                    celda.Fuente = (string)f.Element(S + "name")?.Attribute("val") ?? MYGCeldaHoja.FuentePredeterminada;
                    if (decimal.TryParse((string)f.Element(S + "sz")?.Attribute("val"), NumberStyles.Float, Invariante, out decimal tamano) && tamano >= 1 && tamano <= 409)
                        celda.TamanoFuente = tamano;
                    celda.Negrita = Activo(f.Element(S + "b"));
                    celda.Cursiva = Activo(f.Element(S + "i"));
                    celda.Subrayado = Activo(f.Element(S + "u"));
                    celda.Tachado = Activo(f.Element(S + "strike"));
                    celda.ColorTexto = LeerColor(f.Element(S + "color"));
                }
                int fondo = Entero(xf.Attribute("fillId"), 0);
                if (fondo >= 0 && fondo < fondos.Length)
                {
                    var patron = fondos[fondo].Element(S + "patternFill");
                    if ((string)patron?.Attribute("patternType") == "solid") celda.ColorFondo = LeerColor(patron.Element(S + "fgColor"));
                }
                int borde = Entero(xf.Attribute("borderId"), 0);
                if (borde >= 0 && borde < bordes.Length)
                    celda.Bordes = new[] { "left", "right", "top", "bottom" }.Any(x => !string.IsNullOrEmpty((string)bordes[borde].Element(S + x)?.Attribute("style")));
                var alineacion = xf.Element(S + "alignment");
                celda.AlineacionHorizontal = (string)alineacion?.Attribute("horizontal") switch { "center" or "centerContinuous" => "Centro", "right" => "Derecha", _ => "Izquierda" };
                celda.AlineacionPersonalizada = alineacion?.Attribute("horizontal") != null;
                celda.AlineacionVertical = (string)alineacion?.Attribute("vertical") switch { "top" => "Arriba", "bottom" => "Abajo", _ => "Centro" };
                celda.AjustarTexto = Booleano(alineacion?.Attribute("wrapText"), false);
                resultado.Add(celda);
            }
            return resultado;
        }
        private static bool Activo(XElement elemento) => elemento != null && (string)elemento.Attribute("val") is not "0" and not "false" and not "none";
        private static string LeerColor(XElement elemento)
        {
            string rgb = (string)elemento?.Attribute("rgb") ?? "";
            if (Regex.IsMatch(rgb, "^[0-9a-fA-F]{8}$")) return rgb[2..].ToUpperInvariant();
            if (Regex.IsMatch(rgb, "^[0-9a-fA-F]{6}$")) return rgb.ToUpperInvariant();
            string[] indexados = { "000000", "FFFFFF", "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF", "000000", "FFFFFF", "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF" };
            int indice = Entero(elemento?.Attribute("indexed"), -1);
            return indice >= 0 && indice < indexados.Length ? indexados[indice] : "";
        }
        public static void AplicarEstilo(MYGCeldaHoja destino, MYGCeldaHoja estilo)
        {
            destino.Negrita = estilo.Negrita; destino.Cursiva = estilo.Cursiva;
            destino.Subrayado = estilo.Subrayado; destino.Tachado = estilo.Tachado;
            destino.Fuente = estilo.Fuente; destino.TamanoFuente = estilo.TamanoFuente;
            destino.ColorTexto = estilo.ColorTexto; destino.ColorFondo = estilo.ColorFondo;
            destino.FormatoNumero = estilo.FormatoNumero;
            destino.AlineacionHorizontal = estilo.AlineacionHorizontal; destino.AlineacionVertical = estilo.AlineacionVertical;
            destino.AlineacionPersonalizada = estilo.AlineacionPersonalizada;
            destino.AjustarTexto = estilo.AjustarTexto; destino.Bordes = estilo.Bordes;
        }

        public static XElement Vista(MYGHojaMetrado h)
        {
            var vista = new XElement(S + "sheetView", new XAttribute("workbookViewId", 0),
                new XAttribute("showGridLines", h.LineasDivision ? 1 : 0), new XAttribute("showRowColHeaders", h.Encabezados ? 1 : 0),
                new XAttribute("zoomScale", h.Zoom), new XAttribute("zoomScaleNormal", 100));
            if (h.FilasInmovilizadas > 0 || h.ColumnasInmovilizadas > 0)
            {
                string panel = h.FilasInmovilizadas > 0 ? h.ColumnasInmovilizadas > 0 ? "bottomRight" : "bottomLeft" : "topRight";
                string primera = MYGHojaCalculo.Columna(h.ColumnasInmovilizadas + 1) + (h.FilasInmovilizadas + 1).ToString(Invariante);
                vista.Add(new XElement(S + "pane", h.ColumnasInmovilizadas > 0 ? new XAttribute("xSplit", h.ColumnasInmovilizadas) : null,
                    h.FilasInmovilizadas > 0 ? new XAttribute("ySplit", h.FilasInmovilizadas) : null,
                    new XAttribute("topLeftCell", primera), new XAttribute("activePane", panel), new XAttribute("state", "frozen")),
                    new XElement(S + "selection", new XAttribute("pane", panel), new XAttribute("activeCell", primera), new XAttribute("sqref", primera)));
            }
            return new XElement(S + "sheetViews", vista);
        }

        public static XElement Columnas(MYGHojaMetrado h) => new(S + "cols", Enumerable.Range(1, h.Columnas).Select(c =>
        {
            decimal ancho = h.AnchosColumnas.TryGetValue(c, out int pixeles) ? pixeles <= 12 ? pixeles / 12m : (pixeles - 5m) / 7m : c == 1 ? 48m : 18m;
            return new XElement(S + "col", new XAttribute("min", c), new XAttribute("max", c),
                new XAttribute("width", ancho.ToString("0.########", Invariante)), new XAttribute("customWidth", 1));
        }));

        // Llamar después de sheetData: el orden forma parte del contrato OOXML.
        public static IEnumerable<XElement> Complementos(MYGHojaMetrado h)
        {
            if (h.RangosCombinados.Count != 0)
                yield return new XElement(S + "mergeCells", new XAttribute("count", h.RangosCombinados.Count),
                    h.RangosCombinados.Select(r => new XElement(S + "mergeCell", new XAttribute("ref", MYGHojaCalculo.Normalizar(r)))));
            var validaciones = h.Celdas.Where(x => x.Value.TipoValidacion != "Ninguna").Select(x => Validacion(x.Key, x.Value)).ToArray();
            if (validaciones.Length != 0) yield return new XElement(S + "dataValidations", new XAttribute("count", validaciones.Length), validaciones);
            yield return new XElement(S + "printOptions", new XAttribute("gridLines", h.ImprimirLineasDivision ? 1 : 0),
                new XAttribute("gridLinesSet", 1), new XAttribute("headings", h.ImprimirEncabezados ? 1 : 0));
            yield return new XElement(S + "pageMargins", new XAttribute("left", h.MargenIzquierdo.ToString(Invariante)),
                new XAttribute("right", h.MargenDerecho.ToString(Invariante)), new XAttribute("top", h.MargenSuperior.ToString(Invariante)),
                new XAttribute("bottom", h.MargenInferior.ToString(Invariante)), new XAttribute("header", "0.2"), new XAttribute("footer", "0.2"));
            yield return new XElement(S + "pageSetup", new XAttribute("paperSize", MYGPapelReporte.CodigoExcel(h.TamanoPapel)),
                new XAttribute("orientation", h.OrientacionPagina == "Horizontal" ? "landscape" : "portrait"),
                h.AjustarImpresionAUnaPaginaAncho ? new XAttribute("fitToWidth", 1) : null,
                h.AjustarImpresionAUnaPaginaAncho ? new XAttribute("fitToHeight", 0) : null);
        }
        private static XElement Validacion(string direccion, MYGCeldaHoja celda)
        {
            string tipo = celda.TipoValidacion switch { "Numero" => "decimal", "Entero" => "whole", "Lista" => "list", _ => throw new InvalidDataException("Tipo de validación no admitido.") };
            var regla = new XElement(S + "dataValidation", new XAttribute("type", tipo), new XAttribute("sqref", direccion),
                new XAttribute("allowBlank", 1), new XAttribute("showErrorMessage", 1), new XAttribute("errorStyle", "stop"),
                new XAttribute("errorTitle", "Valor no válido"), new XAttribute("error", "El valor no cumple la validación de esta celda."));
            if (tipo == "list")
            {
                if (celda.ListaValores == null || celda.ListaValores.Count == 0 || celda.ListaValores.Any(v => v == null || v.Contains(',') || v.Contains('"') || v.Contains('\r') || v.Contains('\n')))
                    throw new InvalidDataException("La lista de validación necesita opciones sin comas, comillas ni saltos de línea.");
                string lista = "\"" + string.Join(",", celda.ListaValores) + "\"";
                if (lista.Length > 255) throw new InvalidDataException("La lista de validación de Excel admite hasta 255 caracteres.");
                regla.Add(new XElement(S + "formula1", lista));
            }
            else
            {
                if (celda.Minimo.HasValue && celda.Maximo.HasValue)
                    regla.Add(new XAttribute("operator", "between"), new XElement(S + "formula1", celda.Minimo.Value.ToString(Invariante)),
                        new XElement(S + "formula2", celda.Maximo.Value.ToString(Invariante)));
                else if (celda.Minimo.HasValue)
                    regla.Add(new XAttribute("operator", "greaterThanOrEqual"), new XElement(S + "formula1", celda.Minimo.Value.ToString(Invariante)));
                else
                    regla.Add(new XAttribute("operator", "lessThanOrEqual"), new XElement(S + "formula1", (celda.Maximo ?? decimal.MaxValue).ToString(Invariante)));
            }
            return regla;
        }

        public static void LeerConfiguracion(MYGHojaMetrado h, XDocument documento)
        {
            if (documento?.Root == null) return;
            if (documento.Descendants().Any(x => x.Name.LocalName == "dataValidation" && x.Name.Namespace != S)) throw ValidacionNoAdmitida();
            h.AnchosColumnas.Clear(); h.AltosFilas.Clear(); h.FilasOcultas.Clear();
            foreach (var columna in documento.Root.Element(S + "cols")?.Elements(S + "col") ?? Enumerable.Empty<XElement>())
            {
                int inicio = Entero(columna.Attribute("min"), 0), final = Entero(columna.Attribute("max"), 0);
                if (inicio < 1 || final < inicio || final > 200) throw new InvalidDataException("El rango de columnas excede las dimensiones admitidas.");
                if (decimal.TryParse((string)columna.Attribute("width"), NumberStyles.Float, Invariante, out decimal ancho) && ancho > 0 && ancho <= 255)
                {
                    int pixeles = (int)decimal.Round(ancho < 1 ? ancho * 12m : ancho * 7m + 5m, 0, MidpointRounding.AwayFromZero);
                    for (int c = inicio; c <= final; c++) h.AnchosColumnas[c] = pixeles;
                }
                h.Columnas = Math.Max(h.Columnas, final);
            }
            int filaAnterior = 0;
            foreach (var fila in documento.Root.Element(S + "sheetData")?.Elements(S + "row") ?? Enumerable.Empty<XElement>())
            {
                int numero = Entero(fila.Attribute("r"), filaAnterior + 1);
                if (numero < 1 || numero > 10000) throw new InvalidDataException("La fila excede las dimensiones admitidas.");
                filaAnterior = numero;
                if (decimal.TryParse((string)fila.Attribute("ht"), NumberStyles.Float, Invariante, out decimal alto) && alto > 0 && alto <= 409)
                    h.AltosFilas[numero] = (int)decimal.Round(alto / 0.75m, 0, MidpointRounding.AwayFromZero);
                if (Booleano(fila.Attribute("hidden"), false)) h.FilasOcultas.Add(numero);
                h.Filas = Math.Max(h.Filas, numero);
            }
            var vista = documento.Root.Element(S + "sheetViews")?.Element(S + "sheetView");
            if (vista != null)
            {
                h.LineasDivision = Booleano(vista.Attribute("showGridLines"), true);
                h.Encabezados = Booleano(vista.Attribute("showRowColHeaders"), true);
                h.Zoom = Math.Clamp(Entero(vista.Attribute("zoomScale"), 100), 10, 400);
                var panel = vista.Element(S + "pane");
                bool fijo = (string)panel?.Attribute("state") is "frozen" or "frozenSplit";
                h.FilasInmovilizadas = fijo ? (int)Math.Clamp(Decimal(panel.Attribute("ySplit"), 0), 0m, h.Filas - 1) : 0;
                h.ColumnasInmovilizadas = fijo ? (int)Math.Clamp(Decimal(panel.Attribute("xSplit"), 0), 0m, h.Columnas - 1) : 0;
            }
            h.RangosCombinados.Clear();
            foreach (var combinacion in documento.Root.Element(S + "mergeCells")?.Elements(S + "mergeCell") ?? Enumerable.Empty<XElement>())
            {
                string referencia = MYGHojaCalculo.Normalizar((string)combinacion.Attribute("ref"));
                var limite = Limites(referencia);
                if (limite.Fila2 > 10000 || limite.Columna2 > 200) throw new InvalidDataException("La combinación de celdas excede las dimensiones admitidas.");
                h.Filas = Math.Max(h.Filas, limite.Fila2); h.Columnas = Math.Max(h.Columnas, limite.Columna2);
                if (limite.Fila1 != limite.Fila2 || limite.Columna1 != limite.Columna2) h.RangosCombinados.Add(referencia);
            }
            var opciones = documento.Root.Element(S + "printOptions");
            h.ImprimirLineasDivision = Booleano(opciones?.Attribute("gridLines"), false);
            h.ImprimirEncabezados = Booleano(opciones?.Attribute("headings"), false);
            var margenes = documento.Root.Element(S + "pageMargins");
            h.MargenIzquierdo = Decimal(margenes?.Attribute("left"), 0.5m);
            h.MargenDerecho = Decimal(margenes?.Attribute("right"), 0.5m);
            h.MargenSuperior = Decimal(margenes?.Attribute("top"), 0.5m);
            h.MargenInferior = Decimal(margenes?.Attribute("bottom"), 0.5m);
            var pagina = documento.Root.Element(S + "pageSetup");
            h.AjustarImpresionAUnaPaginaAncho = Booleano(documento.Root.Element(S + "sheetPr")?.Element(S + "pageSetUpPr")?.Attribute("fitToPage"), false) &&
                Entero(pagina?.Attribute("fitToWidth"), 1) == 1 && Entero(pagina?.Attribute("fitToHeight"), 1) == 0;
            h.OrientacionPagina = (string)pagina?.Attribute("orientation") == "landscape" ? "Horizontal" : "Vertical";
            h.TamanoPapel = MYGPapelReporte.DesdeCodigoExcel(Entero(pagina?.Attribute("paperSize"), 9));
            long celdasValidadas = 0;
            foreach (var regla in documento.Root.Element(S + "dataValidations")?.Elements(S + "dataValidation") ?? Enumerable.Empty<XElement>())
            {
                string tipo = (string)regla.Attribute("type");
                var plantilla = new MYGCeldaHoja();
                string primero = regla.Element(S + "formula1")?.Value ?? "";
                string segundo = regla.Element(S + "formula2")?.Value ?? "";
                if (tipo == "list")
                {
                    if (primero.Length < 2 || primero[0] != '"' || primero[^1] != '"') throw ValidacionNoAdmitida();
                    plantilla.TipoValidacion = "Lista";
                    plantilla.ListaValores = primero[1..^1].Split(',').ToList();
                    if (plantilla.ListaValores.Any(x => x.Contains('"'))) throw ValidacionNoAdmitida();
                }
                else if (tipo is "decimal" or "whole")
                {
                    if (!decimal.TryParse(primero, NumberStyles.Float, Invariante, out decimal uno)) throw ValidacionNoAdmitida();
                    string operador = (string)regla.Attribute("operator") ?? "between";
                    if (operador == "between" && decimal.TryParse(segundo, NumberStyles.Float, Invariante, out decimal dos))
                    { plantilla.Minimo = uno; plantilla.Maximo = dos; }
                    else if (operador == "greaterThanOrEqual") plantilla.Minimo = uno;
                    else if (operador == "lessThanOrEqual") plantilla.Maximo = uno == decimal.MaxValue ? null : uno;
                    else if (operador == "equal") plantilla.Minimo = plantilla.Maximo = uno;
                    else throw ValidacionNoAdmitida();
                    plantilla.TipoValidacion = tipo == "whole" ? "Entero" : "Numero";
                }
                else if (tipo is null or "none") continue;
                else throw ValidacionNoAdmitida();
                foreach (string referencia in ((string)regla.Attribute("sqref") ?? "").Split((char[])null, StringSplitOptions.RemoveEmptyEntries))
                {
                    var limite = Limites(referencia);
                    if (limite.Fila2 > 10000 || limite.Columna2 > 200 || (long)(limite.Fila2 - limite.Fila1 + 1) * (limite.Columna2 - limite.Columna1 + 1) > 200000)
                        throw new InvalidDataException("El rango de validación excede las dimensiones admitidas.");
                    celdasValidadas += (long)(limite.Fila2 - limite.Fila1 + 1) * (limite.Columna2 - limite.Columna1 + 1);
                    if (celdasValidadas > 200000) throw new InvalidDataException("Las reglas de validación abarcan más de 200.000 celdas.");
                    h.Filas = Math.Max(h.Filas, limite.Fila2); h.Columnas = Math.Max(h.Columnas, limite.Columna2);
                    for (int f = limite.Fila1; f <= limite.Fila2; f++) for (int c = limite.Columna1; c <= limite.Columna2; c++)
                    {
                        string direccion = MYGHojaCalculo.Columna(c) + f.ToString(Invariante);
                        if (!h.Celdas.TryGetValue(direccion, out var celda)) h.Celdas[direccion] = celda = new MYGCeldaHoja();
                        celda.TipoValidacion = plantilla.TipoValidacion; celda.Minimo = plantilla.Minimo; celda.Maximo = plantilla.Maximo;
                        celda.ListaValores = new List<string>(plantilla.ListaValores);
                    }
                }
            }
        }
        private static InvalidDataException ValidacionNoAdmitida() => new("La hoja contiene validaciones de datos no admitidas. Guarde una copia con listas directas o límites numéricos inclusivos para importarla sin perder reglas.");
        private static (int Fila1, int Columna1, int Fila2, int Columna2) Limites(string referencia)
        {
            string[] partes = MYGHojaCalculo.Normalizar(referencia).Split(':');
            if (partes.Length > 2) throw new InvalidDataException("Rango Excel no válido.");
            var a = MYGHojaCalculo.Coordenadas(partes[0]); var b = MYGHojaCalculo.Coordenadas(partes[^1]);
            if (a.Fila > b.Fila || a.Columna > b.Columna) throw new InvalidDataException("El rango Excel tiene extremos invertidos.");
            return (a.Fila, a.Columna, b.Fila, b.Columna);
        }
        private static int Entero(XAttribute atributo, int defecto) => int.TryParse((string)atributo, NumberStyles.Integer, Invariante, out int valor) ? valor : defecto;
        private static decimal Decimal(XAttribute atributo, decimal defecto) => decimal.TryParse((string)atributo, NumberStyles.Float, Invariante, out decimal valor) ? valor : defecto;
        private static bool Booleano(XAttribute atributo, bool defecto) => atributo == null ? defecto : (string)atributo is "1" or "true";
    }
}
