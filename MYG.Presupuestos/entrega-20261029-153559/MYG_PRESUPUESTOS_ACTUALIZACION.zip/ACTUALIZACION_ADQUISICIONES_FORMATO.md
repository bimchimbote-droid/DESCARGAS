# Calendario de adquisiciones: formato mensual

Base: `bimchimbote-droid/MYG.Presupuestos`, `main`, commit
`f8be2c3b1acc1f770dcb3810bf6d64b824298cb6`. El checkout de trabajo local
se llama `work`; esta entrega no publica cambios en el repositorio del código.

## Presentación

En Cronograma, abra **Calendario de adquisiciones** y elija el proyecto o el
presupuesto. La vista preliminar y los archivos exportados comparten estas filas:

- Título centrado y datos de proyecto, propietario, ubicación y fecha.
- Tipo, descripción, unidad y precio unitario.
- Cada mes agrupa dos columnas: Cantidad y Parcial en la moneda del presupuesto.
- Total Cantidad y Total Parcial a la derecha de cada recurso.
- Total por tipo y Total General, con fondo gris. Los subtotales y el total
  general suman importes; no suman cantidades de unidades diferentes.

Los tipos se muestran en una celda vertical por grupo. El visor permite continuar
un grupo largo entre páginas y repite su etiqueta y la cabecera. Se abre ajustado
a una página de ancho; el usuario puede cambiar ese ajuste en Escala.
El XLSX también guarda la impresión a una página de ancho y alto libre.
Las descripciones se ajustan en altura y los números en ancho.

Los meses son continuos, incluidos los meses sin compras y el fin contractual
registrado si es posterior a las tareas. Cada moneda tiene una hoja independiente.
La hoja admite hasta 97 meses, 10.000 filas y 200.000 celdas; un exceso muestra
un error explícito, sin recortar recursos ni repetir totales en tramos.

Se conserva el cálculo existente: cada recurso se requiere al inicio de la tarea
o al inicio de cada parte, con su proporción. Este cambio no reparte las compras
por todos los días de trabajo ni introduce inventarios o plazos de proveedores.
Se mantienen los recursos reales, subanálisis y proveedores distintos; los códigos
y proveedores no se imprimen como columnas. No se crean compras a partir de
precios directos sin recursos, porcentajes ni ajustes sintéticos.

XLSX, HTML, MHT y RTF conservan las combinaciones y estilos del informe. CSV y
texto conservan las filas y valores; esos formatos no admiten colores ni celdas
combinadas. La impresión/PDF utiliza el visor y una impresora disponible en Windows.

## Aplicación manual

1. Respalde sus archivos o confirme primero sus cambios locales en Visual Studio.
2. Descargue y extraiga `MYG_PRESUPUESTOS_ACTUALIZACION.zip` fuera del proyecto.
3. Copie su contenido a la raíz de `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`,
   conservando todas las rutas relativas. El ZIP contiene archivos completos:
   reemplace los existentes y cree los nuevos. Si tiene cambios propios en esos
   archivos, compare y combine antes de reemplazarlos.
4. No hay archivos que eliminar, paquetes nuevos ni migraciones SQLite/Supabase.
5. Abra la solución en Visual Studio 2026 con SDK .NET 10 y compile Release/x64.

No copie archivos de esta actualización sobre bases de datos. Los informes se
generan en copias y no modifican presupuestos ni fechas del proyecto.

## Compilación y comprobaciones

Desde la raíz del repositorio:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:2 -nr:false --no-restore
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

La opción `UseRevitReferencePackages` usa las referencias NuGet de Revit 2027
ya admitidas por el proyecto. En Windows con Revit 2027 instalado se puede omitir
esa opción para usar sus DLL locales.

Las pruebas de lógica comprueban cabecera, meses pareados, cantidades, parciales,
pausas, proveedores separados, subtotales, total general, alcance de presupuesto,
copias de vista y exportaciones XLSX/HTML/MHT/RTF/CSV/TXT. El XLSX se vuelve a abrir
y se comprueban las combinaciones, valores y ajuste de impresión.

En Windows ejecute también:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Se añadieron pruebas de visor para un grupo de 121 filas que continúa entre
páginas y un calendario de ocho meses ajustado a una página de ancho. La ejecución
gráfica, la impresión real/PDF y la apertura con Excel/Word requieren Windows y
revisión manual; compilar esas pruebas en Linux no equivale a ejecutarlas.

Compruebe con su proyecto que cada mes presenta Cantidad/Parcial, que los
subtotales por tipo concilian con Total General, que los textos largos se leen y
que el PDF/impresión conserva todos los meses y los totales. Revise también la
selección de proyecto frente a presupuesto. No se necesita abrir Revit para
generar este informe; la integración de modelos con Revit no cambia.

## GitHub del código

Después de validar, abra **Cambios de Git** en Visual Studio, revise el diff,
confirme que la rama elegida es `main` (o su rama habitual), escriba un mensaje de
commit y haga Commit. Haga Push cuando decida publicar el código y compruebe el
commit en GitHub. Publicar el ZIP en `bimchimbote-droid/DESCARGAS` no aplica esta
actualización a su carpeta local ni publica el código en `MYG.Presupuestos`.
