using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Impresión de reportes sin Office. Las hojas se leen sin modificar sus datos ni fórmulas.</summary>
internal static class MYGReportesImpresion
{
    // Las hojas anchas se dividen en bandas con su primera columna repetida:
    // un metrado de acero no se comprime hasta volver ilegibles sus 34 columnas.
    private const float EscalaMinima = .85f;
    private const float Separacion = .025f;

    internal static void Imprimir(IWin32Window owner, string nombreDocumento, IReadOnlyList<MYGHojaReporteProyecto> reportes,
        Func<MYGHojaReporteProyecto> crearMetradosExcel = null, Action<string, string> validarDestino = null)
    {
        using var vista = owner is Control control && control.FindForm() is Form propietario
            ? MYGVistaPreliminarReportesForm.CrearPreparada(propietario, nombreDocumento, reportes, crearMetradosExcel, validarDestino)
            : new MYGVistaPreliminarReportesForm(nombreDocumento, reportes, crearMetradosExcel, validarDestino);
        vista.ShowDialog(owner);
    }

    internal static void ImprimirPreparando(IWin32Window owner, string nombreDocumento,
        Func<Action<string>, IReadOnlyList<MYGHojaReporteProyecto>> prepararReportes,
        Func<MYGHojaReporteProyecto> crearMetradosExcel = null, Action<string, string> validarDestino = null)
    {
        ArgumentNullException.ThrowIfNull(prepararReportes);
        using var vista = owner is Control control && control.FindForm() is Form propietario
            ? MYGVistaPreliminarReportesForm.CrearPreparada(propietario, nombreDocumento, prepararReportes, crearMetradosExcel, validarDestino)
            : new MYGVistaPreliminarReportesForm(nombreDocumento, prepararReportes(_ => { }), crearMetradosExcel, validarDestino);
        vista.ShowDialog(owner);
    }

    // El mismo plan sirve para la vista, la impresora y Microsoft Print to PDF.
    // La vista usa el papel lógico y puede abrirse sin impresoras instaladas.
    internal sealed class Vista
    {
        private readonly List<PlanHoja> planes;
        private readonly List<(PlanHoja Plan, Pagina Pagina)> paginas;
        private Vista(List<PlanHoja> planes)
        {
            this.planes = planes;
            paginas = planes.SelectMany(p => p.Paginas.Select(x => (p, x))).ToList();
            foreach (var plan in planes)
            {
                if (plan.Reporte.NivelesTitulos.Count == 0) continue;
                foreach (var entrada in plan.Reporte.Hoja.Celdas)
                {
                    int fila = MYGHojaCalculo.Coordenadas(entrada.Key).Fila;
                    if (plan.Reporte.NivelesTitulos.TryGetValue(fila, out int nivel))
                        plan.Titulos.Add((entrada.Key, nivel, entrada.Value, entrada.Value.ColorTexto));
                }
            }
        }
        internal int CantidadPaginas => paginas.Count;
        internal Color ColorPagina { get; set; } = Color.White;
        internal string Filigrana { get; set; } = "";
        // Cambian sólo tintas y líneas del mismo plan. Las medidas, fórmulas,
        // filas y cortes ya preparados permanecen válidos.
        internal void AplicarApariencia(bool lineas, bool colorearTitulos,
            Func<int, string> colorNivel = null, Func<int, string, string> colorOriginal = null)
        {
            var colores = new Dictionary<int, string>();
            if (colorearTitulos)
            {
                ArgumentNullException.ThrowIfNull(colorNivel);
                foreach (int nivel in planes.SelectMany(p => p.Titulos.Select(t => t.Nivel)).Distinct())
                {
                    string color = colorNivel(nivel)?.Trim().TrimStart('#');
                    if (color == null || color.Length != 6 || !color.All(Uri.IsHexDigit))
                        throw new ArgumentException("Indique colores de títulos RGB de seis dígitos hexadecimales.", nameof(colorNivel));
                    colores.Add(nivel, color.ToUpperInvariant());
                }
            }
            for (int i = 0; i < planes.Count; i++)
            {
                var plan = planes[i];
                plan.Reporte.Hoja.ImprimirLineasDivision = lineas;
                foreach (var titulo in plan.Titulos)
                    titulo.Estilo.ColorTexto = colorearTitulos ? colores[titulo.Nivel]
                        : colorOriginal?.Invoke(i, titulo.Direccion) ?? titulo.Original;
            }
        }
        internal SizeF TamanoPagina(int indice) => paginas[indice].Plan.TamanoPapel;
        // Márgenes elegidos por el usuario, independientes del área física de
        // la impresora. Las guías se dibujan únicamente en la superficie de vista.
        internal RectangleF AreaMargenes(int indice)
        {
            var plan = paginas[indice].Plan;
            var hoja = plan.Reporte.Hoja;
            return new RectangleF((float)hoja.MargenIzquierdo, (float)hoja.MargenSuperior,
                plan.TamanoPapel.Width - (float)(hoja.MargenIzquierdo + hoja.MargenDerecho),
                plan.TamanoPapel.Height - (float)(hoja.MargenSuperior + hoja.MargenInferior));
        }
        internal RectangleF AreaCabecera(int indice)
        {
            var plan = paginas[indice].Plan;
            return new RectangleF(plan.Limites.Left, plan.Limites.Top, plan.Limites.Width, plan.AltoTitulo + plan.AltoDatos);
        }
        internal int BuscarPagina(string texto, int desde)
        {
            if (string.IsNullOrWhiteSpace(texto)) return -1;
            for (int n = 0; n < paginas.Count; n++)
            {
                int indice = ((desde + n) % paginas.Count + paginas.Count) % paginas.Count;
                var pagina = paginas[indice];
                var filas = pagina.Pagina.Filas.ToHashSet();
                if (TituloVisible(pagina.Plan.Reporte).Contains(texto, StringComparison.OrdinalIgnoreCase) ||
                    pagina.Plan.Reporte.CabeceraImpresion.Any(d => d.Key.Contains(texto, StringComparison.OrdinalIgnoreCase) || d.Value.Contains(texto, StringComparison.OrdinalIgnoreCase)) ||
                    pagina.Plan.Bandas[pagina.Pagina.Banda].Celdas.Any(c => c.Filas.Any(filas.Contains) &&
                        c.Texto.Contains(texto, StringComparison.OrdinalIgnoreCase))) return indice;
            }
            return -1;
        }
        internal void DibujarPagina(Graphics graphics, int indice)
        {
            var estado = graphics.Save();
            try
            {
                graphics.PageUnit = GraphicsUnit.Inch;
                var pagina = paginas[indice];
                using (var fondo = new SolidBrush(ColorPagina))
                    graphics.FillRectangle(fondo, 0, 0, pagina.Plan.TamanoPapel.Width, pagina.Plan.TamanoPapel.Height);
                if (!string.IsNullOrWhiteSpace(Filigrana))
                {
                    var marca = graphics.Save();
                    try
                    {
                        graphics.TranslateTransform(pagina.Plan.TamanoPapel.Width / 2, pagina.Plan.TamanoPapel.Height / 2);
                        graphics.RotateTransform(-30);
                        using var fuente = new Font(FuenteReporte(pagina.Plan.Reporte.Hoja), 36, FontStyle.Bold);
                        using var tinta = new SolidBrush(Color.FromArgb(45, Color.Gray));
                        using var formato = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                        graphics.DrawString(Filigrana, fuente, tinta, new RectangleF(-3.5f, -1, 7, 2), formato);
                    }
                    finally { graphics.Restore(marca); }
                }
                Dibujar(graphics, pagina.Plan, pagina.Pagina, indice + 1);
            }
            finally { graphics.Restore(estado); }
        }
        internal PrintDocument Documento(string nombre, PrinterSettings impresora)
        {
            if (planes.Any(p => p.Configuracion == null)) throw new InvalidOperationException("Prepare el reporte para la impresora seleccionada.");
            var documento = new PrintDocument { DocumentName = nombre ?? "Reportes del proyecto", PrinterSettings = impresora };
            int primera = impresora.PrintRange == PrintRange.SomePages ? impresora.FromPage - 1 : 0;
            int ultima = impresora.PrintRange == PrintRange.SomePages ? impresora.ToPage - 1 : paginas.Count - 1;
            if (primera < 0 || ultima < primera || ultima >= paginas.Count)
            { documento.Dispose(); throw new InvalidOperationException("El rango de páginas no corresponde al reporte configurado."); }
            int indice = primera;
            documento.BeginPrint += (_, _) => indice = primera;
            documento.QueryPageSettings += (_, e) => e.PageSettings = (PageSettings)paginas[indice].Plan.Configuracion.Clone();
            documento.PrintPage += (_, e) =>
            {
                if (e.Graphics == null) throw new InvalidOperationException("La impresora no proporciona un contexto de dibujo.");
                var estado = e.Graphics.Save();
                try
                {
                    e.Graphics.PageUnit = GraphicsUnit.Inch;
                    e.Graphics.TranslateTransform(-e.PageSettings.HardMarginX / 100f, -e.PageSettings.HardMarginY / 100f);
                    DibujarPagina(e.Graphics, indice);
                }
                finally { e.Graphics.Restore(estado); }
                e.HasMorePages = ++indice <= ultima;
            };
            return documento;
        }
        internal static Vista Crear(IReadOnlyList<MYGHojaReporteProyecto> reportes, float escala, PrinterSettings impresora,
            int paginasDeAncho, Action<string> progreso)
        {
            if (reportes == null || reportes.Count == 0 || reportes.Any(r => r?.Hoja == null))
                throw new InvalidOperationException("No hay reportes válidos para mostrar.");
            if (!float.IsFinite(escala) || escala < .25f || escala > 2f) throw new ArgumentOutOfRangeException(nameof(escala));
            if (paginasDeAncho < 0 || paginasDeAncho > 10) throw new ArgumentOutOfRangeException(nameof(paginasDeAncho));
            var planes = new List<PlanHoja>();
            using var bitmap = new Bitmap(1, 1);
            bitmap.SetResolution(96, 96);
            using var graphics = Graphics.FromImage(bitmap);
            graphics.PageUnit = GraphicsUnit.Inch;
            int numero = 0;
            foreach (var reporte in reportes)
            {
                numero++;
                progreso?.Invoke($"Preparando informe {numero} de {reportes.Count}: {reporte.Titulo}…");
                try
                {
                    var h = reporte.Hoja;
                    var tamano = MedidaPapel(h);
                    var limites = new RectangleF((float)h.MargenIzquierdo, (float)h.MargenSuperior,
                        tamano.Width - (float)(h.MargenIzquierdo + h.MargenDerecho),
                        tamano.Height - (float)(h.MargenSuperior + h.MargenInferior));
                    PageSettings pagina = null;
                    if (impresora != null)
                    {
                        if (!impresora.IsValid) throw new InvalidOperationException("Seleccione una impresora disponible.");
                        pagina = new PageSettings(impresora);
                        ConfigurarPagina(pagina, h);
                        limites = RectangleF.Intersect(limites, EnPulgadas(pagina.PrintableArea));
                    }
                    progreso?.Invoke($"Comprobando papel y márgenes del informe {numero} de {reportes.Count}…");
                    var plan = Preparar(reporte, pagina, graphics, limites, escala, paginasDeAncho,
                        detalle => progreso?.Invoke($"Informe {numero} de {reportes.Count} · {detalle}"));
                    plan.TamanoPapel = tamano;
                    planes.Add(plan);
                    progreso?.Invoke($"Informe {numero} de {reportes.Count} preparado: {plan.Paginas.Count} páginas.");
                }
                catch (InvalidOperationException ex)
                { throw new InvalidOperationException("No se puede preparar «" + reporte.Titulo + "»: " + ex.Message, ex); }
            }
            var resultado = new Vista(planes);
            progreso?.Invoke($"Paginación terminada: {resultado.CantidadPaginas} páginas en total.");
            return resultado;
        }
    }

    internal static Vista PrepararVista(IReadOnlyList<MYGHojaReporteProyecto> reportes, float escala = 1,
        PrinterSettings impresora = null, int paginasDeAncho = 0, Action<string> progreso = null)
        => Vista.Crear(reportes, escala, impresora, paginasDeAncho, progreso);

    private static SizeF MedidaPapel(MYGHojaMetrado h)
    {
        var medida = MYGPapelReporte.DimensionesPulgadas(h.TamanoPapel);
        var tamano = new SizeF((float)medida.Ancho, (float)medida.Alto);
        return h.OrientacionPagina == "Horizontal" ? new SizeF(tamano.Height, tamano.Width) : tamano;
    }

    /// <summary>Índices de columnas desde cero; cada banda conserva la columna identificadora inicial.</summary>
    internal static IReadOnlyList<int[]> SegmentarColumnas(IReadOnlyList<float> anchos, float anchoDisponible)
    {
        if (anchos == null || anchos.Count == 0 || !Positivo(anchoDisponible) || anchos.Any(a => !Positivo(a)))
            throw new ArgumentException("Los anchos y el espacio disponible deben ser números positivos y finitos.");
        double capacidad = (double)anchoDisponible / EscalaMinima;
        capacidad += Math.Max(1d, capacidad) * .000001d;
        if (anchos.Sum(a => (double)a) <= capacidad) return new[] { Enumerable.Range(0, anchos.Count).ToArray() };
        if (anchos.Count == 1) throw new InvalidOperationException("La columna identificadora no cabe con texto legible. Reduzca su ancho o utilice papel más grande.");
        var resultado = new List<int[]>();
        int siguiente = 1;
        while (siguiente < anchos.Count)
        {
            var banda = new List<int> { 0 };
            double ancho = anchos[0];
            while (siguiente < anchos.Count && ancho + anchos[siguiente] <= capacidad)
            { ancho += anchos[siguiente]; banda.Add(siguiente++); }
            if (banda.Count == 1)
                throw new InvalidOperationException("La columna identificadora y la columna " + MYGHojaCalculo.Columna(siguiente + 1) +
                    " no caben con texto legible. Reduzca sus anchos o utilice papel más grande.");
            resultado.Add(banda.ToArray());
        }
        return resultado;
    }

    /// <summary>Filas originales de cada página. Altos se indexa por posición en filas, omitiendo las ocultas.</summary>
    internal static IReadOnlyList<int[]> PaginarFilas(IReadOnlyList<int> filas, IReadOnlyList<float> altos,
        IReadOnlyList<(int Primera, int Ultima)> combinaciones, float altoDisponible, int filasTitulo)
    {
        if (filas == null || altos == null || combinaciones == null || filas.Count != altos.Count || !Positivo(altoDisponible) ||
            altos.Any(a => !Positivo(a)) || filasTitulo < 0 || filasTitulo > filas.Count ||
            filas.Where((f, i) => f < 1 || (i > 0 && f <= filas[i - 1])).Any() ||
            combinaciones.Any(c => c.Primera < 1 || c.Ultima < c.Primera))
            throw new ArgumentException("Las filas, alturas y combinaciones de impresión no son válidas.");
        if (filas.Count == 0) return Array.Empty<int[]>();
        if (altos.Sum() <= altoDisponible) return new[] { filas.ToArray() };

        int ultimaCabecera = filasTitulo == 0 ? 0 : filas[filasTitulo - 1];
        if (combinaciones.Any(c => c.Primera <= ultimaCabecera && c.Ultima > ultimaCabecera))
            throw new InvalidOperationException("Una combinación vertical atraviesa las cabeceras repetidas. Separe esa combinación para imprimir varias páginas.");
        float altoTitulos = altos.Take(filasTitulo).Sum();
        if (altoTitulos >= altoDisponible)
            throw new InvalidOperationException("Las cabeceras repetidas ocupan toda el área de impresión.");

        // Unir intervalos superpuestos evita separar combinaciones encadenadas.
        var intervalos = new List<(int Primera, int Ultima)>();
        foreach (var intervalo in combinaciones.Where(c => c.Ultima > c.Primera).OrderBy(c => c.Primera))
        {
            if (intervalos.Count > 0 && intervalo.Primera <= intervalos[^1].Ultima)
                intervalos[^1] = (intervalos[^1].Primera, Math.Max(intervalos[^1].Ultima, intervalo.Ultima));
            else intervalos.Add(intervalo);
        }
        var resultado = new List<int[]>();
        var pagina = new List<int>();
        float usado = 0;
        int posicion = 0, intervaloActual = 0;
        while (posicion < filas.Count)
        {
            int fin = posicion;
            while (intervaloActual < intervalos.Count && intervalos[intervaloActual].Ultima < filas[posicion]) intervaloActual++;
            if (intervaloActual < intervalos.Count && intervalos[intervaloActual].Primera <= filas[posicion])
                while (fin + 1 < filas.Count && filas[fin + 1] <= intervalos[intervaloActual].Ultima) fin++;
            float alto = 0;
            for (int i = posicion; i <= fin; i++) alto += altos[i];
            if (posicion >= filasTitulo && alto > altoDisponible - altoTitulos)
                throw new InvalidOperationException("La fila " + filas[posicion] + (fin == posicion ? "" : " y su bloque combinado") +
                    " no cabe en una página con las cabeceras. Reduzca su altura o utilice papel más grande.");
            if (alto > altoDisponible)
                throw new InvalidOperationException("La fila " + filas[posicion] + " y su bloque combinado exceden el alto imprimible.");
            if (usado + alto > altoDisponible)
            {
                if (pagina.Count == 0) throw new InvalidOperationException("No cabe una fila en el área de impresión.");
                resultado.Add(pagina.ToArray());
                pagina = filas.Take(filasTitulo).ToList();
                usado = altoTitulos;
            }
            for (int i = posicion; i <= fin; i++) pagina.Add(filas[i]);
            usado += alto;
            posicion = fin + 1;
        }
        if (pagina.Count > 0) resultado.Add(pagina.ToArray());
        return resultado;
    }

    private static bool Positivo(float valor) => float.IsFinite(valor) && valor > 0;
    private static string FuenteReporte(MYGHojaMetrado h) => h.Celdas.Values.FirstOrDefault()?.Fuente ?? MYGCeldaHoja.FuentePredeterminada;
    private static string Direccion(int fila, int columna) => MYGHojaCalculo.Columna(columna) + fila.ToString(CultureInfo.InvariantCulture);
    private static RectangleF EnPulgadas(RectangleF rectangulo) => new(rectangulo.X / 100f, rectangulo.Y / 100f, rectangulo.Width / 100f, rectangulo.Height / 100f);

    private static void ConfigurarPagina(PageSettings pagina, MYGHojaMetrado h)
    {
        pagina.Landscape = h.OrientacionPagina == "Horizontal";
        PaperKind clase = h.TamanoPapel switch
        {
            "A2" => PaperKind.A2, "A3" => PaperKind.A3, "A5" => PaperKind.A5, "A6" => PaperKind.A6,
            "B4" => PaperKind.B4, "B5" => PaperKind.B5,
            "Carta" => PaperKind.Letter, "Oficio" => PaperKind.Legal, _ => PaperKind.A4
        };
        var pulgadas = MYGPapelReporte.DimensionesPulgadas(h.TamanoPapel);
        var medida = (Ancho: (int)(pulgadas.Ancho * 100), Alto: (int)(pulgadas.Alto * 100));
        var disponibles = pagina.PrinterSettings.PaperSizes.Cast<PaperSize>().ToArray();
        var papel = disponibles.FirstOrDefault(p => p.Kind == clase) ?? disponibles.FirstOrDefault(p =>
            Math.Abs(p.Width - medida.Ancho) <= 2 && Math.Abs(p.Height - medida.Alto) <= 2);
        if (papel == null) throw new InvalidOperationException("La impresora seleccionada no admite papel " + h.TamanoPapel + ". Seleccione otra impresora o cambie el papel de la hoja.");
        pagina.PaperSize = papel;
        pagina.Margins = new Margins((int)Math.Round(h.MargenIzquierdo * 100), (int)Math.Round(h.MargenDerecho * 100),
            (int)Math.Round(h.MargenSuperior * 100), (int)Math.Round(h.MargenInferior * 100));
    }

    private sealed class Region
    {
        internal int F1, C1, F2, C2;
        internal string Direccion => MYGReportesImpresion.Direccion(F1, C1);
    }
    private sealed class Celda
    {
        internal string Direccion, Texto;
        internal MYGCeldaHoja Estilo;
        internal int PrimeraColumna, UltimaColumna;
        internal int[] Filas;
    }
    private sealed class Banda
    {
        internal int[] Columnas;
        internal float[] Anchos;
        internal float Escala;
        internal List<Celda> Celdas = new();
    }
    private sealed class Pagina
    {
        internal int[] Filas;
        internal int Banda;
    }
    private sealed class PlanHoja
    {
        internal readonly List<(string Direccion, int Nivel, MYGCeldaHoja Estilo, string Original)> Titulos = new();
        internal MYGHojaReporteProyecto Reporte;
        internal PageSettings Configuracion;
        internal RectangleF Limites;
        internal SizeF TamanoPapel;
        internal float AltoTitulo, AltoEncabezados, AltoDatos;
        internal List<(string Etiqueta, string Valor, RectangleF EtiquetaArea, RectangleF ValorArea)> Datos = new();
        internal List<Banda> Bandas = new();
        internal Dictionary<int, float> Altos;
        internal List<Pagina> Paginas = new();
    }

    private static Region LeerRango(string rango)
    {
        var partes = MYGEdicionHoja.NormalizarRango(rango).Split(':');
        var a = MYGHojaCalculo.Coordenadas(partes[0]);
        var b = MYGHojaCalculo.Coordenadas(partes[^1]);
        return new Region { F1 = a.Fila, C1 = a.Columna, F2 = b.Fila, C2 = b.Columna };
    }

    private static string TituloVisible(MYGHojaReporteProyecto reporte) => reporte.TituloImpresion;

    private static PlanHoja Preparar(MYGHojaReporteProyecto reporte, PageSettings pagina, Graphics g, RectangleF limites,
        float escalaUsuario, int paginasDeAncho, Action<string> progreso)
    {
        progreso?.Invoke("Leyendo el área de impresión, filas y celdas combinadas…");
        var h = reporte.Hoja;
        var todasCombinaciones = h.RangosCombinados.Select(LeerRango).ToArray();
        var coordenadas = h.Celdas.Keys.Select(MYGHojaCalculo.Coordenadas).ToArray();
        var area = string.IsNullOrWhiteSpace(h.AreaImpresion)
            ? new Region { F1 = 1, C1 = 1,
                F2 = Math.Max(coordenadas.Select(c => c.Fila).DefaultIfEmpty(1).Max(), todasCombinaciones.Select(c => c.F2).DefaultIfEmpty(1).Max()),
                C2 = Math.Max(coordenadas.Select(c => c.Columna).DefaultIfEmpty(1).Max(), todasCombinaciones.Select(c => c.C2).DefaultIfEmpty(1).Max()) }
            : LeerRango(h.AreaImpresion);
        if (area.F1 < 1 || area.C1 < 1 || area.F2 > h.Filas || area.C2 > h.Columnas)
            throw new InvalidOperationException("El área de impresión de " + reporte.Titulo + " está fuera de la hoja.");
        var combinaciones = todasCombinaciones.Where(c => c.F1 <= area.F2 && c.F2 >= area.F1 && c.C1 <= area.C2 && c.C2 >= area.C1).ToArray();
        var ocultas = h.FilasOcultas.ToHashSet();
        // El título de la tabla no se duplica debajo de la cabecera institucional.
        if (!reporte.CabeceraEnHoja && reporte.DatosProyecto.Count > 0 && area.F1 == 1 &&
            h.Celdas.TryGetValue("A1", out var a1) && (reporte.EsPresupuestoObra || string.Equals(a1.Contenido, reporte.Titulo.Split(" · ")[0], StringComparison.OrdinalIgnoreCase)) &&
            combinaciones.Any(c => c.F1 == 1 && c.F2 == 1 && c.C1 == area.C1 && c.C2 == area.C2)) ocultas.Add(1);
        var filas = Enumerable.Range(area.F1, area.F2 - area.F1 + 1).Where(f => !ocultas.Contains(f)).ToArray();
        if (filas.Length == 0) throw new InvalidOperationException("El reporte " + reporte.Titulo + " no contiene filas visibles para imprimir.");
        if (limites.Width <= .4f || limites.Height <= .5f)
            throw new InvalidOperationException("Los márgenes de " + reporte.Titulo + " dejan un área de impresión demasiado pequeña.");
        using var titulo = new Font(FuenteReporte(h), 11, FontStyle.Bold);
        using var formatoTitulo = new StringFormat { Trimming = StringTrimming.None, Alignment = StringAlignment.Center };
        float altoTitulo = reporte.CabeceraEnHoja ? 0 : Math.Max(.22f, g.MeasureString(TituloVisible(reporte) ?? h.Nombre, titulo, new SizeF(limites.Width, 10000), formatoTitulo).Height) + (reporte.UsaFormatoPresupuesto || reporte.EsAnalisisCostosUnitarios ? .18f : .12f);
        var plan = new PlanHoja { Reporte = reporte, Configuracion = pagina, Limites = limites, AltoTitulo = altoTitulo,
            AltoEncabezados = h.ImprimirEncabezados ? .24f : 0 };
        PrepararDatosProyecto(plan, g);
        float anchoFilas = h.ImprimirEncabezados ? .3f : 0;
        float anchoDisponible = limites.Width - anchoFilas;
        var columnas = Enumerable.Range(area.C1, area.C2 - area.C1 + 1).ToArray();
        var anchos = columnas.Select(c => h.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : 68) / 96f).ToArray();
        IReadOnlyList<int[]> segmentos;
        if (paginasDeAncho > 0)
        {
            var ajuste = MYGConfiguracionVistaReporte.AjustarAnchura(anchos, anchoDisponible, paginasDeAncho);
            escalaUsuario = ajuste.Escala;
            segmentos = ajuste.Segmentos;
        }
        else
        {
            segmentos = SegmentarColumnas(anchos.Select(a => a * escalaUsuario).ToArray(), anchoDisponible);
        }
        anchos = anchos.Select(a => a * escalaUsuario).ToArray();
        var motor = new MYGHojaCalculo(h);
        progreso?.Invoke("Calculando textos, fórmulas y distribución de columnas…");
        var textos = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var mapa = new Dictionary<(int Fila, int Columna), Region>();
        foreach (var region in combinaciones)
            for (int f = Math.Max(area.F1, region.F1); f <= Math.Min(area.F2, region.F2); f++)
                for (int c = Math.Max(area.C1, region.C1); c <= Math.Min(area.C2, region.C2); c++) mapa.Add((f, c), region);
        foreach (var segmento in segmentos)
        {
            var banda = new Banda { Columnas = segmento.Select(c => columnas[c]).ToArray(),
                Escala = Math.Min(1f, anchoDisponible / segmento.Sum(c => anchos[c])) };
            banda.Anchos = segmento.Select(c => anchos[c] * banda.Escala).ToArray();
            var visitadas = new HashSet<Region>();
            foreach (int f in filas)
                for (int indice = 0; indice < banda.Columnas.Length; indice++)
                {
                    int c = banda.Columnas[indice];
                    mapa.TryGetValue((f, c), out var region);
                    if (region != null && !visitadas.Add(region)) continue;
                    string direccion = region?.Direccion ?? Direccion(f, c);
                    if (!textos.TryGetValue(direccion, out string texto)) textos[direccion] = texto = motor.Mostrar(direccion);
                    var estilo = h.Celdas.GetValueOrDefault(direccion) ?? new MYGCeldaHoja();
                    var celda = new Celda { Direccion = direccion, Texto = texto, Estilo = estilo,
                        PrimeraColumna = region == null ? indice : Array.FindIndex(banda.Columnas, col => col >= region.C1 && col <= region.C2),
                        UltimaColumna = region == null ? indice : Array.FindLastIndex(banda.Columnas, col => col >= region.C1 && col <= region.C2),
                        Filas = region == null ? new[] { f } : filas.Where(fila => fila >= region.F1 && fila <= region.F2).ToArray() };
                    banda.Celdas.Add(celda);
                }
            banda.Escala *= escalaUsuario;
            plan.Bandas.Add(banda);
        }
        // Mismas alturas y cortes verticales para todas las bandas, de modo
        // que una fila se puede seguir entre páginas de una hoja de acero.
        float escalaAlta = plan.Bandas.Max(b => b.Escala);
        plan.Altos = filas.ToDictionary(f => f, f => Math.Max(.12f, h.AltosFilas.GetValueOrDefault(f, f == 2 ? 28 : 20) / 96f * escalaAlta));
        progreso?.Invoke("Midiendo los textos y ajustando las alturas de las filas…");
        foreach (var banda in plan.Bandas)
        {
            using var fuentes = new Fuentes();
            foreach (var celda in banda.Celdas)
            {
                if (string.IsNullOrEmpty(celda.Texto)) continue;
                float ancho = 0;
                for (int c = celda.PrimeraColumna; c <= celda.UltimaColumna; c++) ancho += banda.Anchos[c];
                if (ancho <= Separacion * 2) throw new InvalidOperationException("La celda " + celda.Direccion + " no tiene ancho suficiente para imprimir su texto.");
                using var formato = Formato(celda);
                float necesario = g.MeasureString(celda.Texto, fuentes.Obtener(celda.Estilo, banda.Escala),
                    new SizeF(ancho - Separacion * 2, 10000), formato).Height + Separacion * 2 + .01f;
                float existente = celda.Filas.Sum(f => plan.Altos[f]);
                if (necesario > existente) plan.Altos[celda.Filas[^1]] += necesario - existente;
            }
        }
        float altoDisponible = limites.Height - altoTitulo - plan.AltoDatos - plan.AltoEncabezados - .26f;
        if (!Positivo(altoDisponible)) throw new InvalidOperationException("El título y los márgenes de " + reporte.Titulo + " ocupan toda la página.");
        // Los informes que materializan su cabecera en celdas incluyen también
        // la fila de columnas después de los datos del proyecto.
        int maximoTitulos = reporte.CabeceraEnHoja ? Math.Max(1, h.Filas - 1) : 2;
        int titulos = h.RepetirTitulos && area.F1 == 1 ? Math.Max(1, Math.Min(maximoTitulos, h.FilasInmovilizadas)) : 0;
        int filasTitulo = filas.Count(f => f <= titulos);
        // Los rótulos verticales de grupos extensos pueden continuar en otra
        // página. Sólo los rangos declarados exactamente por el informe se
        // dividen; las demás combinaciones conservan su bloque indivisible.
        // La celda se dibuja sobre sus filas visibles y repite el rótulo en
        // cada página sin modificar el rango que se exporta a Excel.
        var divisibles = reporte.RangosDivisiblesEntrePaginas.Select(LeerRango)
            .Select(c => (c.F1, c.C1, c.F2, c.C2)).ToHashSet();
        var bloques = combinaciones.Where(c => !(c.F1 > titulos && c.F2 > c.F1 &&
                divisibles.Contains((c.F1, c.C1, c.F2, c.C2))))
            .Select(c => (c.F1, c.F2)).ToList();
        if (reporte.EsListaInsumos)
        {
            // Las bandas de grupo abarcan B:E. Se mantienen con el primer
            // insumo para no dejar un subtítulo huérfano al pie de la página.
            foreach (var grupo in combinaciones.Where(c => c.F1 == c.F2 && c.C1 == 2 && c.C2 == 5))
                if (grupo.F1 < area.F2) bloques.Add((grupo.F1, grupo.F1 + 1));
            int filaTotal = MYGHojaCalculo.Coordenadas(h.CeldaTotal).Fila;
            if (filaTotal > 2) bloques.Add((filaTotal - 1, filaTotal));
        }
        progreso?.Invoke($"Distribuyendo {filas.Length} filas en páginas…");
        var paginasFilas = PaginarFilas(filas, filas.Select(f => plan.Altos[f]).ToArray(),
            bloques, altoDisponible, filasTitulo);
        for (int banda = 0; banda < plan.Bandas.Count; banda++)
            foreach (var paginaFilas in paginasFilas) plan.Paginas.Add(new Pagina { Banda = banda, Filas = paginaFilas });
        return plan;
    }

    private static void PrepararDatosProyecto(PlanHoja plan, Graphics g)
    {
        var datos = plan.Reporte.CabeceraImpresion;
        if (plan.Reporte.CabeceraEnHoja || datos.Count == 0) return;
        if (plan.Reporte.UsaFormatoPresupuesto || plan.Reporte.EsAnalisisCostosUnitarios)
        {
            float etiquetaAncho = Math.Min(1.65f, plan.Limites.Width * .25f);
            float valorAncho = plan.Limites.Width - etiquetaAncho - .16f;
            if (valorAncho <= .1f) throw new InvalidOperationException("Los márgenes no dejan espacio para los datos generales del presupuesto.");
            using var fuente = new Font(FuenteReporte(plan.Reporte.Hoja), 9);
            using var formatoDato = new StringFormat { Trimming = StringTrimming.None };
            float filaY = plan.Limites.Top + plan.AltoTitulo + .04f;
            foreach (var dato in datos)
            {
                float alto = Math.Max(.24f, Math.Max(
                    g.MeasureString(dato.Key, fuente, new SizeF(etiquetaAncho, 10000), formatoDato).Height,
                    g.MeasureString(dato.Value, fuente, new SizeF(valorAncho, 10000), formatoDato).Height) + .08f);
                plan.Datos.Add((dato.Key, dato.Value, new RectangleF(plan.Limites.Left, filaY, etiquetaAncho, alto),
                    new RectangleF(plan.Limites.Left + etiquetaAncho + .16f, filaY, valorAncho, alto)));
                filaY += alto;
            }
            plan.AltoDatos = filaY - plan.Limites.Top - plan.AltoTitulo + .06f;
            return;
        }
        float separacion = .18f, ancho = (plan.Limites.Width - separacion) / 2;
        float anchoEtiqueta = Math.Min(1.35f, ancho * .42f), anchoValor = ancho - anchoEtiqueta - .04f;
        if (anchoValor <= .1f) throw new InvalidOperationException("El papel y los márgenes no dejan espacio para la cabecera del proyecto.");
        using var etiqueta = new Font(FuenteReporte(plan.Reporte.Hoja), 8.5f, FontStyle.Bold);
        using var valor = new Font(FuenteReporte(plan.Reporte.Hoja), 8.5f);
        using var formato = new StringFormat { Trimming = StringTrimming.None };
        float y = plan.Limites.Top + plan.AltoTitulo + .04f;
        for (int i = 0; i < datos.Count; i += 2)
        {
            float alto = .24f;
            for (int j = i; j < Math.Min(i + 2, datos.Count); j++)
            {
                alto = Math.Max(alto, g.MeasureString(datos[j].Key + ":", etiqueta, new SizeF(anchoEtiqueta, 10000), formato).Height + .04f);
                alto = Math.Max(alto, g.MeasureString(datos[j].Value, valor, new SizeF(anchoValor, 10000), formato).Height + .04f);
            }
            for (int j = i; j < Math.Min(i + 2, datos.Count); j++)
            {
                float x = plan.Limites.Left + (j - i) * (ancho + separacion);
                plan.Datos.Add((datos[j].Key + ":", datos[j].Value,
                    new RectangleF(x, y, anchoEtiqueta, alto), new RectangleF(x + anchoEtiqueta + .04f, y, anchoValor, alto)));
            }
            y += alto;
        }
        plan.AltoDatos = y - plan.Limites.Top - plan.AltoTitulo + .12f;
    }

    private static StringFormat Formato(Celda celda) => new()
    {
        Alignment = MYGEdicionHoja.AlineacionCelda(celda.Estilo, celda.Direccion) switch
        { "Centro" => StringAlignment.Center, "Derecha" => StringAlignment.Far, _ => StringAlignment.Near },
        LineAlignment = celda.Estilo.AlineacionVertical switch
        { "Arriba" => StringAlignment.Near, "Abajo" => StringAlignment.Far, _ => StringAlignment.Center },
        Trimming = StringTrimming.None
    };

    private static Color ColorCelda(string valor, Color predeterminado) => string.IsNullOrEmpty(valor)
        ? predeterminado : ColorTranslator.FromHtml("#" + valor.TrimStart('#'));

    private sealed class Fuentes : IDisposable
    {
        private readonly Dictionary<(string Nombre, float Tamano, FontStyle Estilo), Font> fuentes = new();
        internal Font Obtener(MYGCeldaHoja celda, float escala)
        {
            var estilo = (celda.Negrita ? FontStyle.Bold : 0) | (celda.Cursiva ? FontStyle.Italic : 0) |
                (celda.Subrayado ? FontStyle.Underline : 0) | (celda.Tachado ? FontStyle.Strikeout : 0);
            var clave = (Nombre: celda.Fuente, Tamano: (float)celda.TamanoFuente * escala, Estilo: estilo);
            if (!fuentes.TryGetValue(clave, out var fuente)) fuentes[clave] = fuente = new Font(clave.Nombre, clave.Tamano, clave.Estilo);
            return fuente;
        }
        public void Dispose() { foreach (var fuente in fuentes.Values) fuente.Dispose(); }
    }

    private static void Dibujar(Graphics g, PlanHoja plan, Pagina pagina, int numeroPagina)
    {
        var h = plan.Reporte.Hoja;
        var banda = plan.Bandas[pagina.Banda];
        using var titulo = new Font(FuenteReporte(h), 11, FontStyle.Bold);
        using var datos = new Font(FuenteReporte(h), 8);
        using var formatoTitulo = new StringFormat { Trimming = StringTrimming.None, Alignment = StringAlignment.Center };
        using var institucional = new SolidBrush(Color.FromArgb(24, 53, 79));
        if (plan.Reporte.EsListaInsumos)
        {
            using var reglaTitulo = new Pen(Color.Black, .005f);
            g.DrawLine(reglaTitulo, plan.Limites.Left, plan.Limites.Top - .035f, plan.Limites.Right, plan.Limites.Top - .035f);
            g.DrawLine(reglaTitulo, plan.Limites.Left, plan.Limites.Top - .015f, plan.Limites.Right, plan.Limites.Top - .015f);
        }
        if (!plan.Reporte.CabeceraEnHoja)
            g.DrawString(TituloVisible(plan.Reporte) ?? h.Nombre, titulo,
                plan.Reporte.UsaFormatoPresupuesto || plan.Reporte.EsAnalisisCostosUnitarios ? Brushes.Black : institucional,
                new RectangleF(plan.Limites.Left, plan.Limites.Top, plan.Limites.Width, plan.AltoTitulo - .1f), formatoTitulo);
        if (plan.Datos.Count > 0)
        {
            bool presupuesto = plan.Reporte.UsaFormatoPresupuesto || plan.Reporte.EsAnalisisCostosUnitarios;
            using var etiqueta = new Font(FuenteReporte(h), presupuesto ? 9 : 8.5f, presupuesto ? FontStyle.Regular : FontStyle.Bold);
            using var valor = new Font(FuenteReporte(h), presupuesto ? 9 : 8.5f);
            using var texto = new SolidBrush(presupuesto ? Color.Black : Color.FromArgb(36, 55, 70));
            using var formato = new StringFormat { Trimming = StringTrimming.None, Alignment = StringAlignment.Near };
            using var linea = new Pen(Color.FromArgb(24, 53, 79), .012f);
            if (!presupuesto) g.DrawLine(linea, plan.Limites.Left, plan.Limites.Top + plan.AltoTitulo - .02f, plan.Limites.Right, plan.Limites.Top + plan.AltoTitulo - .02f);
            foreach (var campo in plan.Datos)
            {
                g.DrawString(campo.Etiqueta, etiqueta, presupuesto ? Brushes.Black : institucional, campo.EtiquetaArea, formato);
                if (presupuesto) g.DrawString(":", valor, texto,
                    new RectangleF(campo.ValorArea.Left - .14f, campo.ValorArea.Top, .12f, campo.ValorArea.Height), formato);
                g.DrawString(campo.Valor, valor, texto, campo.ValorArea, formato);
            }
            if (!presupuesto) g.DrawLine(linea, plan.Limites.Left, plan.Limites.Top + plan.AltoTitulo + plan.AltoDatos - .06f,
                plan.Limites.Right, plan.Limites.Top + plan.AltoTitulo + plan.AltoDatos - .06f);
        }
        float y = plan.Limites.Top + plan.AltoTitulo + plan.AltoDatos;
        float xInicial = plan.Limites.Left + (h.ImprimirEncabezados ? .3f : 0);
        var xs = new float[banda.Columnas.Length + 1];
        xs[0] = xInicial;
        for (int i = 0; i < banda.Columnas.Length; i++) xs[i + 1] = xs[i] + banda.Anchos[i];
        if (h.ImprimirEncabezados)
        {
            for (int c = 0; c < banda.Columnas.Length; c++)
                g.DrawString(MYGHojaCalculo.Columna(banda.Columnas[c]), datos, Brushes.DimGray,
                    new RectangleF(xs[c] + Separacion, y, banda.Anchos[c] - Separacion, plan.AltoEncabezados));
            y += plan.AltoEncabezados;
        }
        var posiciones = new Dictionary<int, float>();
        foreach (int f in pagina.Filas)
        {
            posiciones.Add(f, y);
            if (h.ImprimirEncabezados) g.DrawString(f.ToString(CultureInfo.InvariantCulture), datos, Brushes.DimGray, plan.Limites.Left, y);
            y += plan.Altos[f];
        }
        using var fuentes = new Fuentes();
        using var borde = new Pen(Color.FromArgb(188, 199, 209), .005f);
        using var division = new Pen(Color.FromArgb(218, 225, 232), .003f);
        foreach (var celda in banda.Celdas)
        {
            var visibles = celda.Filas.Where(posiciones.ContainsKey).ToArray();
            if (visibles.Length == 0) continue;
            var rectangulo = new RectangleF(xs[celda.PrimeraColumna], posiciones[visibles[0]],
                xs[celda.UltimaColumna + 1] - xs[celda.PrimeraColumna], visibles.Sum(f => plan.Altos[f]));
            if (!string.IsNullOrEmpty(celda.Estilo.ColorFondo))
            { using var fondo = new SolidBrush(ColorCelda(celda.Estilo.ColorFondo, Color.White)); g.FillRectangle(fondo, rectangulo); }
            if (celda.Estilo.Bordes || h.ImprimirLineasDivision)
                g.DrawRectangle(celda.Estilo.Bordes ? borde : division, rectangulo.X, rectangulo.Y, rectangulo.Width, rectangulo.Height);
            using var tinta = new SolidBrush(ColorCelda(celda.Estilo.ColorTexto, Color.Black));
            using var formato = Formato(celda);
            rectangulo.Inflate(-Separacion, -Separacion);
            g.DrawString(celda.Texto, fuentes.Obtener(celda.Estilo, banda.Escala), tinta, rectangulo, formato);
        }
        if (plan.Reporte.EsAnalisisCostosUnitarios)
        {
            using var separador = new Pen(Color.FromArgb(145, 155, 170), .012f);
            foreach (var celda in banda.Celdas.Where(c => c.PrimeraColumna == 0 && c.Texto.StartsWith("Partida:", StringComparison.Ordinal)))
                if (posiciones.TryGetValue(celda.Filas[0], out float comienzo))
                    g.DrawLine(separador, xs[0], comienzo, xs[^1], comienzo);
        }
        if (plan.Reporte.UsaFormatoPresupuesto)
        {
            using var regla = new Pen(Color.FromArgb(174, 183, 194), .01f);
            float comienzo = posiciones[pagina.Filas[0]];
            g.DrawLine(regla, xs[0], comienzo, xs[^1], comienzo);
            int filaTotalInsumos = plan.Reporte.EsListaInsumos ? MYGHojaCalculo.Coordenadas(h.CeldaTotal).Fila : -1;
            foreach (int fila in pagina.Filas)
                if (fila != filaTotalInsumos)
                    g.DrawLine(regla, xs[0], posiciones[fila] + plan.Altos[fila], xs[^1], posiciones[fila] + plan.Altos[fila]);
            // El total de insumos sólo ocupa las dos columnas derechas; sus
            // propias celdas dibujan el recuadro sin prolongarlo hacia la izquierda.
            float finTabla = posiciones.GetValueOrDefault(filaTotalInsumos, y);
            g.DrawLine(regla, xs[0], comienzo, xs[0], finTabla);
            g.DrawLine(regla, xs[^1], comienzo, xs[^1], finTabla);
        }
        string columnas = banda.Columnas.Length == 1 ? MYGHojaCalculo.Columna(banda.Columnas[0]) :
            MYGHojaCalculo.Columna(banda.Columnas[0]) + (banda.Columnas[1] != banda.Columnas[0] + 1 ? ", " + MYGHojaCalculo.Columna(banda.Columnas[1]) : "") +
            "–" + MYGHojaCalculo.Columna(banda.Columnas[^1]);
        string pie = "Página " + numeroPagina + (plan.Bandas.Count > 1 ? " · Segmento " + (pagina.Banda + 1) + "/" + plan.Bandas.Count + " · Columnas " + columnas : "");
        g.DrawString(pie, datos, Brushes.DimGray, plan.Limites.Left, plan.Limites.Bottom - .2f);
    }
}
