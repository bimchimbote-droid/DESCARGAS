using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class AdquisicionesFormatoCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception(detalle); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);
    private static string Texto(MYGHojaMetrado hoja, string direccion) => hoja.Celdas.GetValueOrDefault(direccion)?.Contenido ?? "";
    private static int Fila(MYGHojaMetrado hoja, int columna, string texto) => hoja.Celdas
        .Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == columna && c.Value.Contenido == texto)
        .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("ADQUISICIONES FORMATO QA");
        documento.Datos = new() { Propietario = "PROPIETARIO QA", Departamento = "ÁNCASH", Provincia = "SANTA",
            Distrito = "NUEVO CHIMBOTE", FechaElaboracion = new DateTime(2026, 1, 2) };
        var presupuesto = documento.Presupuestos.Single(); presupuesto.Nombre = "PRESUPUESTO RECURSOS QA";
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        var datos = new[]
        {
            (Nombre: "OFICIAL QA", Grupo: MYGGrupoRecurso.ManoObra, Unidad: "hh", Precio: 20m, Cantidad: 2m),
            (Nombre: "ACERO QA", Grupo: MYGGrupoRecurso.Materiales, Unidad: "kg", Precio: 5m, Cantidad: 3m),
            (Nombre: "TUBO QA", Grupo: MYGGrupoRecurso.Materiales, Unidad: "und", Precio: 2m, Cantidad: 4m),
            (Nombre: "EQUIPO QA", Grupo: MYGGrupoRecurso.Equipo, Unidad: "hm", Precio: 10m, Cantidad: .5m),
            (Nombre: "INSTALACIÓN QA", Grupo: MYGGrupoRecurso.Subcontratos, Unidad: "und", Precio: 100m, Cantidad: 1m)
        };
        foreach (var dato in datos)
            presupuesto.Costos.Insumos.Add(new() { Codigo = dato.Nombre, Descripcion = dato.Nombre, Grupo = dato.Grupo,
                Unidad = dato.Unidad, Precio = dato.Precio, Proveedor = "PROVEEDOR QA" });
        for (int n = 0; n < 2; n++)
        {
            var item = new ItemPresupuestoDelphin { Id = "PARTIDA" + n, IdLocalMYG = "PARTIDA" + n,
                Item = "0" + (n + 1), Descripcion = "ACTIVIDAD QA " + n, TipoPropuesta = "PARTIDA", Unidad = "und" };
            item.Costos.Cantidad = n == 0 ? 1 : 3;
            foreach (var dato in datos)
                item.Costos.Analisis.Add(new() { Grupo = dato.Grupo, Cantidad = dato.Cantidad,
                    InsumoId = presupuesto.Costos.Insumos.Single(i => i.Descripcion == dato.Nombre).Id });
            presupuesto.Items.Add(item);
            plan.Tareas.Add(new() { Id = "T" + n, Nombre = item.Descripcion, PresupuestoId = presupuesto.Id,
                PartidaId = item.Id, DuracionDias = 1, Modo = MYGModoTarea.Manual,
                InicioManual = n == 0 ? new DateTime(2026, 1, 5) : new DateTime(2026, 3, 5) });
        }
        string origen = Firma(documento), programacion = Firma(plan);
        var reporte = MYGReportesCronograma.CrearAdquisiciones(documento, plan).Single();
        var hoja = reporte.Hoja; var motor = new MYGHojaCalculo(hoja);
        Exige(reporte.CabeceraEnHoja && hoja.Columnas == 12 && hoja.FilasInmovilizadas == 9 &&
            Texto(hoja, "A1").StartsWith("CALENDARIO DE ADQUISICIONES", StringComparison.Ordinal) &&
            hoja.Celdas.Values.Any(c => c.Contenido == documento.Nombre) &&
            hoja.Celdas.Values.Any(c => c.Contenido == documento.Datos.Propietario) &&
            hoja.Celdas.Values.Any(c => c.Contenido?.Contains("NUEVO CHIMBOTE", StringComparison.Ordinal) == true) &&
            hoja.Celdas.Values.Any(c => c.Contenido == "02/01/2026") &&
            Texto(hoja, "A8") == "Tipo" && Texto(hoja, "B8") == "Descripción" && Texto(hoja, "C8") == "Unidad" &&
            Texto(hoja, "D8").StartsWith("Precio", StringComparison.Ordinal) &&
            Texto(hoja, "E8") == "Mes 1" && Texto(hoja, "G8") == "Mes 2" && Texto(hoja, "I8") == "Mes 3" &&
            Texto(hoja, "E9") == "Cantidad" && Texto(hoja, "F9").StartsWith("Parcial", StringComparison.Ordinal) &&
            Texto(hoja, "K8") == "Total Cantidad" && Texto(hoja, "L8").StartsWith("Total Parcial", StringComparison.Ordinal) &&
            new[] { "A8:A9", "B8:B9", "C8:C9", "D8:D9", "E8:F8", "G8:H8", "I8:J8", "K8:K9", "L8:L9" }
                .All(hoja.RangosCombinados.Contains),
            "Adquisiciones perdió cabecera materializada, columnas del formato o encabezados mensuales de dos niveles.");
        foreach (var dato in datos)
        {
            int fila = Fila(hoja, 2, dato.Nombre);
            Exige(fila >= 10 && Texto(hoja, "C" + fila) == dato.Unidad && motor.Numero("D" + fila) == dato.Precio &&
                motor.Numero("E" + fila) == dato.Cantidad && motor.Numero("F" + fila) == dato.Cantidad * dato.Precio &&
                Texto(hoja, "G" + fila) == "" && Texto(hoja, "H" + fila) == "" &&
                motor.Numero("I" + fila) == dato.Cantidad * 3 && motor.Numero("J" + fila) == dato.Cantidad * dato.Precio * 3 &&
                motor.Numero("K" + fila) == dato.Cantidad * 4 && motor.Numero("L" + fila) == dato.Cantidad * dato.Precio * 4,
                "Adquisiciones perdió unidad, precio, cantidades/parciales mensuales, pausa o totales del recurso " + dato.Nombre);
        }
        int acero = Fila(hoja, 2, "ACERO QA"), tubo = Fila(hoja, 2, "TUBO QA");
        Exige(tubo == acero + 1 && Texto(hoja, "A" + acero) == "MATERIALES" &&
            hoja.RangosCombinados.Contains("A" + acero + ":A" + tubo),
            "El tipo de recurso no ocupa una celda vertical común al grupo de materiales.");
        foreach (var grupo in datos.GroupBy(d => d.Grupo))
        {
            int fila = Fila(hoja, 1, "Total " + MYGMotorPresupuestos.Grupo(grupo.Key));
            decimal parcial = grupo.Sum(d => d.Cantidad * d.Precio);
            Exige(hoja.RangosCombinados.Contains("A" + fila + ":D" + fila) &&
                Texto(hoja, "E" + fila) == "" && Texto(hoja, "G" + fila) == "" && Texto(hoja, "I" + fila) == "" &&
                Texto(hoja, "K" + fila) == "" && motor.Numero("F" + fila) == parcial &&
                motor.Numero("H" + fila) == 0 && motor.Numero("J" + fila) == parcial * 3 && motor.Numero("L" + fila) == parcial * 4,
                "Un subtotal de adquisiciones sumó unidades incompatibles o perdió los parciales de su grupo.");
        }
        int total = Fila(hoja, 1, "Total General");
        Exige(hoja.CeldaTotal == "L" + total && motor.Numero(hoja.CeldaTotal) == 672 &&
            motor.Numero("F" + total) == 168 && motor.Numero("H" + total) == 0 && motor.Numero("J" + total) == 504 &&
            Texto(hoja, "K" + total) == "" && hoja.Celdas[hoja.CeldaTotal].Negrita,
            "El total general de adquisiciones no concilia los grupos y los meses o volvió a sumar cantidades heterogéneas.");
        MYGHojaCalculo.Validar(hoja);
        pasa("Adquisiciones reproduce tipo agrupado, descripción, unidad, precio, cantidad/parcial por mes y subtotales/gran total sin sumar unidades distintas");

        var vista = new MYGConfiguracionVistaReporte(new[] { reporte });
        Exige(reporte.AjustarAUnaPaginaDeAncho && vista.PaginasDeAncho == 1 &&
            reporte.RangosDivisiblesEntrePaginas.Contains("A" + acero + ":A" + tubo),
            "Adquisiciones no inicia ajustado a una página de ancho o perdió la marca de grupos divisibles entre páginas.");
        var solicitud = vista.CapturarSolicitud();
        vista.PaginasDeAncho = 0;
        var porcentual = vista.CapturarSolicitud();
        Exige(porcentual.PaginasDeAncho == 0 && solicitud.PaginasDeAncho == 1,
            "Elegir escala porcentual cambió una captura previa o ignoró el ajuste explícito del usuario.");
        vista.Restaurar();
        Exige(vista.PaginasDeAncho == 1, "Restaurar no recuperó el ajuste inicial a una página de ancho.");
        vista.Fuente("Calibri"); vista.RepetirTitulos(false);
        var capturada = solicitud.CrearReportes().Single();
        Exige(Firma(capturada.Hoja) == Firma(hoja) && capturada.AjustarAUnaPaginaDeAncho &&
            capturada.RangosDivisiblesEntrePaginas.SequenceEqual(reporte.RangosDivisiblesEntrePaginas) &&
            new MYGHojaCalculo(vista.Reportes.Single().Hoja).Numero(hoja.CeldaTotal) == 672,
            "Cambiar la vista preliminar modificó una captura anterior o perdió los totales.");
        foreach (var formato in Enum.GetValues<MYGFormatoExportacionReporte>())
        {
            string ruta = Path.Combine(carpeta, "Adquisiciones formato." + formato.ToString().ToLowerInvariant());
            MYGReportesExportacion.Guardar(ruta, formato, solicitud.CrearReportes());
            Exige(new FileInfo(ruta).Length > 0, "No se exportó el calendario de adquisiciones en " + formato);
            if (formato == MYGFormatoExportacionReporte.Xlsx)
            {
                var excel = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta).Single(), hoja.CeldaTotal);
                Exige(excel.AjustarImpresionAUnaPaginaAncho && new MYGHojaCalculo(excel).Numero(hoja.CeldaTotal) == 672 &&
                    new[] { "E8:F8", "G8:H8", "I8:J8", "A" + acero + ":A" + tubo, "A" + total + ":D" + total }
                        .All(excel.RangosCombinados.Contains) && Texto(excel, "B" + tubo) == "TUBO QA" &&
                    Texto(excel, "G" + tubo) == "" && new MYGHojaCalculo(excel).Numero("L" + tubo) == 32,
                    "XLSX no conserva encabezados, grupo vertical, pausa, ajuste de impresión o totales al reabrir adquisiciones.");
                using var archivo = ZipFile.OpenRead(ruta);
                using var xmlHoja = archivo.GetEntry("xl/worksheets/sheet1.xml").Open();
                var contenido = XDocument.Load(xmlHoja);
                XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
                var pagina = contenido.Root.Element(ns + "pageSetup");
                Exige((string)contenido.Root.Element(ns + "sheetPr")?.Element(ns + "pageSetUpPr")?.Attribute("fitToPage") == "1" &&
                    (string)pagina?.Attribute("fitToWidth") == "1" && (string)pagina?.Attribute("fitToHeight") == "0",
                    "XLSX no guarda ajuste nativo a una página de ancho y todas las páginas de alto necesarias.");
            }
            else if (formato is MYGFormatoExportacionReporte.Html or MYGFormatoExportacionReporte.Mht)
            {
                string contenido = File.ReadAllText(ruta);
                if (formato == MYGFormatoExportacionReporte.Mht)
                {
                    const string marca = "Content-Location: informe.html\r\n\r\n";
                    int desde = contenido.IndexOf(marca, StringComparison.Ordinal) + marca.Length;
                    int hasta = contenido.IndexOf("\r\n------MYG_", desde, StringComparison.Ordinal);
                    Exige(desde >= marca.Length && hasta > desde, "MHT no contiene el HTML de adquisiciones.");
                    contenido = Encoding.UTF8.GetString(Convert.FromBase64String(contenido[desde..hasta]));
                }
                var xml = XDocument.Parse(contenido);
                Exige(!xml.Descendants("h1").Any() && xml.Descendants("td").Count(e => e.Value.StartsWith("CALENDARIO DE ADQUISICIONES", StringComparison.Ordinal)) == 1 &&
                    xml.Descendants("td").Any(e => e.Value == "Mes 1" && (string)e.Attribute("colspan") == "2") &&
                    xml.Descendants("td").Any(e => e.Value == "MATERIALES" && (string)e.Attribute("rowspan") == "2") &&
                    xml.Descendants("td").Any(e => e.Value == "Total General" && (string)e.Attribute("colspan") == "4"),
                    formato + " perdió la cabecera única, meses pareados, tipo vertical o total general.");
            }
            else if (formato == MYGFormatoExportacionReporte.Rtf)
            {
                string contenido = File.ReadAllText(ruta);
                Exige(contenido.Contains(@"\clmgf", StringComparison.Ordinal) && contenido.Contains(@"\clvmgf", StringComparison.Ordinal) &&
                    contenido.Contains("Mes 3", StringComparison.Ordinal) && contenido.Contains("Total General", StringComparison.Ordinal) &&
                    contenido.Contains("672.00", StringComparison.Ordinal), "RTF perdió combinaciones, meses o total de adquisiciones.");
            }
            else
            {
                string contenido = File.ReadAllText(ruta);
                Exige(contenido.Contains("Total General", StringComparison.Ordinal) && contenido.Contains("TUBO QA", StringComparison.Ordinal) &&
                    contenido.Contains("Mes 3", StringComparison.Ordinal) && contenido.Contains("672.00", StringComparison.Ordinal),
                    formato + " perdió filas, meses o importes de adquisiciones.");
            }
        }
        Exige(Firma(documento) == origen && Firma(plan) == programacion,
            "Crear, visualizar o exportar adquisiciones cambió los datos o las fechas del proyecto.");
        pasa("Vista preliminar y XLSX/HTML/MHT/RTF/CSV/TXT comparten el calendario de adquisiciones y conservan grupos, períodos y totales sin mutar el proyecto");
        ComprobarAlcanceYLimites(documento, plan, pasa);
    }

    private static void ComprobarAlcanceYLimites(MYGProyectoDocumento original, MYGCronograma planOriginal, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Copia(original);
        var plan = MYGProyectoStorage.Copia(planOriginal);
        documento.Datos.FechaFin = new DateTime(2026, 5, 20);
        var extendido = MYGReportesCronograma.CrearAdquisiciones(documento, plan).Single().Hoja;
        var motor = new MYGHojaCalculo(extendido);
        int recurso = Fila(extendido, 2, "TUBO QA");
        Exige(extendido.Columnas == 16 && Texto(extendido, "M8") == "Mes 5" &&
            new[] { "K", "L", "M", "N" }.All(c => Texto(extendido, c + recurso) == "") &&
            motor.Numero(extendido.CeldaTotal) == 672 && motor.Numero("L" + MYGHojaCalculo.Coordenadas(extendido.CeldaTotal).Fila) == 0 &&
            motor.Numero("N" + MYGHojaCalculo.Coordenadas(extendido.CeldaTotal).Fila) == 0,
            "El fin contractual eliminó meses sin compras, inventó adquisiciones o alteró el total.");
        pasa("Adquisiciones conserva los meses vacíos hasta el fin contractual sin inventar cantidades ni parciales");

        var usd = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO USD QA", Item = "02" };
        usd.Costos.Moneda = "USD";
        var insumo = new MYGInsumo { Descripcion = "MATERIAL USD QA", Codigo = "USD", Grupo = MYGGrupoRecurso.Materiales,
            Unidad = "und", Precio = 7 };
        usd.Costos.Insumos.Add(insumo);
        var item = new ItemPresupuestoDelphin { Id = "USD", IdLocalMYG = "USD", Item = "01", TipoPropuesta = "PARTIDA",
            Descripcion = "ACTIVIDAD USD QA", Unidad = "und" };
        item.Costos.Cantidad = 2;
        item.Costos.Analisis.Add(new() { InsumoId = insumo.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 1 });
        usd.Items.Add(item); documento.Presupuestos.Add(usd);
        plan.Tareas.Add(new() { Id = "USD", PresupuestoId = usd.Id, PartidaId = item.Id, Nombre = item.Descripcion,
            DuracionDias = 1 });
        string fuente = Firma(documento), fechas = Firma(plan);
        var monedas = MYGReportesCronograma.CrearAdquisiciones(documento, plan);
        Exige(monedas.Count == 2 && monedas.Select(r => new MYGHojaCalculo(r.Hoja).Numero(r.Hoja.CeldaTotal)).OrderBy(n => n)
            .SequenceEqual(new[] { 14m, 672m }) && monedas.Single(r => r.Titulo.EndsWith(" · USD", StringComparison.Ordinal)).Hoja.Celdas.Values
                .Count(c => c.Contenido == "MATERIAL USD QA") == 1 &&
            !monedas.Single(r => !r.Titulo.EndsWith(" · USD", StringComparison.Ordinal)).Hoja.Celdas.Values.Any(c => c.Contenido == "MATERIAL USD QA") &&
            Firma(documento) == fuente && Firma(plan) == fechas,
            "Adquisiciones mezcló monedas o recursos ajenos, o modificó el proyecto al separar importes.");
        pasa("Adquisiciones genera hojas y totales independientes por moneda sin mezclar recursos ni mutar la programación");

        documento.Datos.FechaFin = new DateTime(2034, 1, 31);
        var maximo = MYGReportesCronograma.CrearAdquisiciones(documento, plan);
        Exige(maximo.Count == 2 && maximo.All(r => r.Hoja.Columnas == 200 &&
            Texto(r.Hoja, "GO8") == "Mes 97") &&
            maximo.Select(r => new MYGHojaCalculo(r.Hoja).Numero(r.Hoja.CeldaTotal)).OrderBy(n => n).SequenceEqual(new[] { 14m, 672m }),
            "El calendario de 97 meses no conserva las 200 columnas y los importes de cada moneda.");
        documento.Datos.FechaFin = new DateTime(2034, 2, 1);
        bool rechazado = false;
        try { MYGReportesCronograma.CrearAdquisiciones(documento, plan); }
        catch (InvalidDataException) { rechazado = true; }
        Exige(rechazado, "Adquisiciones truncó o aceptó silenciosamente 98 meses que exceden las 200 columnas del modelo.");
        pasa("Adquisiciones admite 97 meses completos y rechaza explícitamente 98 sin truncar meses ni fragmentar el total general");
    }
}
