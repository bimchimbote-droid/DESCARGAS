using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ReportesExcelCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        CabeceraYFormato(pasa);
        AreaYTexto(pasa);
        CabeceraIncrustada(pasa);
        ReferenciasEntreInformes(carpeta, pasa);
    }

    private static void CabeceraYFormato(Action<string> pasa)
    {
        var h = new MYGHojaMetrado
        {
            Nombre = "Presupuesto", Filas = 7, Columnas = 4, AreaImpresion = "A1:D7", CeldaTotal = "D7",
            RangosCombinados = new() { "A1:D1", "A4:B4" }, FilasOcultas = new() { 5 },
            AnchosColumnas = new() { [1] = 85, [2] = 260, [3] = 75, [4] = 100 },
            AltosFilas = new() { [4] = 38 }, RangoCuerpoPlantilla = "A3:D6"
        };
        h.Poner("A1", "PRESUPUESTO DE OBRA"); h.Poner("A2", "Ítem");
        h.Poner("B3", "2"); h.Poner("C3", "3"); h.Poner("D3", "=B3*$C$3");
        h.Poner("A4", "Descripción combinada"); h.Poner("D7", "=SUM(D3:D6)");
        h.Celdas["D3"].ColorFondo = "ABCDEF"; h.Celdas["D3"].FormatoNumero = "0.00";
        var r = new MYGHojaReporteProyecto("Presupuesto · 01 QA", h, new[]
        {
            new KeyValuePair<string, string>("Proyecto", "Obra QA"), new("Presupuesto", "ARQUITECTURA"),
            new("Propietario", "Entidad QA"), new("Departamento", "ÁNCASH"), new("Provincia", "SANTA"),
            new("Distrito", "NUEVO CHIMBOTE"), new("Fecha de elaboración", "01/09/2026")
        }, presupuestoObra: true);
        string antes = JsonSerializer.Serialize(r);
        var copia = MYGReportesExcel.CrearHojas(new[] { r }).Single();
        int delta = r.CabeceraImpresion.Count + 3;
        var motor = new MYGHojaCalculo(copia);
        Exige(motor.Mostrar("A1") == "PRESUPUESTO DE OBRA" &&
            r.CabeceraImpresion.All(d => copia.Celdas.Values.Any(c => c.Contenido == d.Key + ":") &&
                copia.Celdas.Values.Any(c => c.Contenido == d.Value)), "Excel perdió el título o un dato visible de la cabecera institucional.");
        Exige(copia.Celdas["D" + (3 + delta)].Contenido == "=B" + (3 + delta) + "*$C$" + (3 + delta) &&
            motor.Numero("D" + (7 + delta)) == 6 && copia.CeldaTotal == "D" + (7 + delta),
            "Insertar cabecera debe ajustar también las referencias absolutas y la celda total.");
        Exige(copia.RangosCombinados.Contains("A" + (4 + delta) + ":B" + (4 + delta)) &&
            copia.RangoCuerpoPlantilla == "A" + (3 + delta) + ":D" + (6 + delta) &&
            copia.AreaImpresion == "A1:D" + (7 + delta) && copia.FilasOcultas.Contains(5 + delta) &&
            copia.FilasOcultas.Contains(1 + delta) && copia.AltosFilas[4 + delta] == 38 &&
            copia.AnchosColumnas.SequenceEqual(h.AnchosColumnas) && copia.Celdas["D" + (3 + delta)].ColorFondo == "ABCDEF" &&
            copia.Celdas["D" + (3 + delta)].FormatoNumero == "0.00", "Excel perdió dimensiones, combinaciones, área, ocultación del título duplicado o formato del cuerpo.");
        Exige(JsonSerializer.Serialize(r) == antes, "Materializar cabecera alteró el reporte original.");
        pasa("Excel incluye la cabecera institucional completa y conserva cálculos, referencias absolutas, rangos, dimensiones y formatos sin modificar el informe");
    }

    private static void AreaYTexto(Action<string> pasa)
    {
        var h = new MYGHojaMetrado { Filas = 6, Columnas = 4, CeldaTotal = "D6", AreaImpresion = "B2:D6", FilasInmovilizadas = 0 };
        h.Poner("D6", "4"); h.Poner("A1", "FUERA DEL ÁREA");
        var r = new MYGHojaReporteProyecto("Título QA", h, new[]
        {
            new KeyValuePair<string, string>("Proyecto", "=SUM(A1:A5)"), new("Presupuesto", "0012"),
            new("Propietario", "Primera línea\nSegunda línea")
        });
        var copia = MYGReportesExcel.CrearHojas(new[] { r }).Single();
        var motor = new MYGHojaCalculo(copia);
        Exige(copia.AreaImpresion == "B1:D12" && motor.Mostrar("C3") == "=SUM(A1:A5)" && motor.Mostrar("C4") == "0012" &&
            copia.Celdas["C3"].Contenido.StartsWith("=\"") && copia.AltosFilas[5] > 24 && copia.FilasInmovilizadas == 0,
            "La cabecera debe conservar el área por columnas, los metadatos literales, sus saltos de línea y la vista sin inmovilizar.");
        pasa("Excel conserva nombres que empiezan por =, códigos con ceros, metadatos multilínea y el área original por columnas");
    }

    private static void CabeceraIncrustada(Action<string> pasa)
    {
        var h = new MYGHojaMetrado { Filas = 2, Columnas = 2, CeldaTotal = "B2", FilasInmovilizadas = 0 };
        h.Poner("A1", "METRADOS"); h.Poner("B2", "7");
        var r = new MYGHojaReporteProyecto("METRADOS", h,
            new[] { new KeyValuePair<string, string>("Proyecto", "Obra") }, cabeceraEnHoja: true);
        var copia = MYGReportesExcel.CrearHojas(new[] { r }).Single();
        Exige(JsonSerializer.Serialize(copia) == JsonSerializer.Serialize(h) && !ReferenceEquals(copia, h),
            "Una hoja con cabecera materializada debe exportarse una sola vez y por copia.");
        copia.Celdas["A1"].Contenido = "Copia";
        Exige(h.Celdas["A1"].Contenido == "METRADOS", "La hoja incrustada debe quedar aislada del original.");
        pasa("Excel respeta las cabeceras ya materializadas y entrega una copia independiente sin duplicarlas");
    }

    private static void ReferenciasEntreInformes(string carpeta, Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Nombre = "Presupuesto QA", Item = "01" };
        ItemPresupuestoDelphin Partida(string codigo)
        {
            string id = MYGProyectoStorage.NuevoId();
            return new() { Id = id, IdLocalMYG = id, Item = codigo, TipoPropuesta = "PARTIDA", Descripcion = codigo, Unidad = "und" };
        }
        var a = Partida("01.01"); var b = Partida("01.02");
        p.Items.AddRange(new[] { a, b }); MYGReferenciasMetrado.Vincular(new[] { p });
        b.Costos.Hoja.Poner("B3", "7");
        a.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, p, b, "B3") + "*2");
        var reportes = new[]
        {
            new MYGHojaReporteProyecto("Destino", a.Costos.Hoja, new[] { new KeyValuePair<string, string>("Proyecto", "Obra") }),
            new MYGHojaReporteProyecto("Origen", b.Costos.Hoja, new[] { new KeyValuePair<string, string>("Proyecto", "Obra"), new("Presupuesto", "QA") })
        };
        string antes = JsonSerializer.Serialize(p);
        string ruta = Path.Combine(carpeta, "Reportes con cabeceras y vinculos.xlsx");
        MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Xlsx, reportes);
        using var zip = ZipFile.OpenRead(ruta);
        using var entrada = zip.GetEntry("xl/worksheets/sheet1.xml").Open();
        var xml = XDocument.Load(entrada); XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        var celda = xml.Descendants(ns + "c").Single(c => (string)c.Attribute("r") == "B7");
        Exige(celda.Element(ns + "f")?.Value.EndsWith("!B8*2", StringComparison.Ordinal) == true &&
            celda.Element(ns + "v")?.Value == "14" && JsonSerializer.Serialize(p) == antes,
            "Excel debe reubicar los vínculos METRADO según la cabecera de su origen y calcular las copias sin tocar el proyecto.");
        pasa("Excel reubica vínculos entre informes con cabeceras de distinta altura y conserva su fórmula nativa y valor calculado");
    }
}
