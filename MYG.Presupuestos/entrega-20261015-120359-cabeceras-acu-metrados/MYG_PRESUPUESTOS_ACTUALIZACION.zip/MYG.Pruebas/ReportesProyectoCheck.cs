using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using MYG_2027;

internal static class ReportesProyectoCheck
{
    private static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }
    private static string Datos(object valor) => JsonSerializer.Serialize(valor);
    private static string Normalizar(string valor) => new string((valor ?? "").Normalize(NormalizationForm.FormD)
        .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
        .Select(char.ToUpperInvariant).ToArray());
    private static ItemPresupuestoDelphin Nodo(string descripcion, string item, int posicion,
        string padre = null, bool titulo = false)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, IdInternoDelphin = id,
            Descripcion = descripcion, Item = item, ParentId = padre, Posicion = posicion,
            Origen = "DELPHIN", Estado = "OFICIAL", TipoPropuesta = titulo ? "TITULO" : "PARTIDA",
            Unidad = titulo ? "" : "und" };
    }
    private static MYGInsumo Insumo(MYGPresupuestoDocumento p, MYGGrupoRecurso grupo,
        string codigo, string descripcion, decimal precio)
    {
        var i = new MYGInsumo { Grupo = grupo, Codigo = codigo, Descripcion = descripcion,
            Unidad = "und", Precio = precio };
        p.Costos.Insumos.Add(i); return i;
    }
    private static void Recurso(ItemPresupuestoDelphin partida, MYGInsumo insumo, decimal cantidad) =>
        partida.Costos.Analisis.Add(new MYGRecursoACU { InsumoId = insumo.Id, Grupo = insumo.Grupo, Cantidad = cantidad });
    private static int Fila(MYGHojaMetrado hoja, string texto)
    {
        var calculo = new MYGHojaCalculo(hoja);
        return hoja.Celdas.Where(c => Normalizar(calculo.Mostrar(c.Key)) == Normalizar(texto))
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).DefaultIfEmpty(-1).First();
    }
    private static bool Contiene(MYGHojaMetrado hoja, string texto)
    {
        var calculo = new MYGHojaCalculo(hoja);
        return hoja.Celdas.Any(c => Normalizar(calculo.Mostrar(c.Key)).Contains(Normalizar(texto)));
    }
    private static List<decimal> NumerosFila(MYGHojaMetrado hoja, int fila)
    {
        var calculo = new MYGHojaCalculo(hoja);
        return hoja.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Fila == fila)
            .OrderBy(c => MYGHojaCalculo.Coordenadas(c.Key).Columna)
            .Select(c => calculo.Resultado(c.Key)).Where(r => r.EsNumero).Select(r => r.Numero()).ToList();
    }
    private static void FilaConNumeros(MYGHojaMetrado hoja, string descripcion, params decimal[] esperados)
    {
        var calculo = new MYGHojaCalculo(hoja);
        var filas = hoja.Celdas.Where(c => Normalizar(calculo.Mostrar(c.Key)) == Normalizar(descripcion))
            .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Distinct().ToArray();
        Exige(filas.Length > 0, "Falta la fila del informe: " + descripcion);
        Exige(filas.Any(f => esperados.All(NumerosFila(hoja, f).Contains)),
            "La fila " + descripcion + " perdió cantidades/importes: " + string.Join(", ", esperados) + ".");
    }
    private static MYGHojaMetrado HojaDe(IEnumerable<MYGHojaReporteProyecto> hojas, string descripcion) =>
        hojas.First(h => Normalizar(h.Titulo).Contains(Normalizar(descripcion)) || Contiene(h.Hoja, descripcion)).Hoja;
    private static XDocument Xml(string ruta, string parte)
    {
        using var zip = ZipFile.OpenRead(ruta);
        using var entrada = (zip.GetEntry(parte) ?? throw new Exception("Falta " + parte)).Open();
        return XDocument.Load(entrada);
    }
    private static XElement CeldaXml(string ruta, int hoja, string direccion) =>
        Xml(ruta, "xl/worksheets/sheet" + hoja + ".xml").Descendants(S + "c")
            .Single(c => (string)c.Attribute("r") == direccion);

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        VerificarPresupuestos(carpeta, pasa);
        VerificarACUYConsolidado(pasa);
        VerificarFormatoACU(pasa);
        VerificarRendimientoYMonedas(pasa);
        VerificarFuentes(pasa);
        VerificarFiltrosExcel(carpeta, pasa);
        VerificarDependencias(carpeta, pasa);
        VerificarCodigosYTextos(carpeta, pasa);
        VerificarPresentacionInstitucional(pasa);
        VerificarJerarquiaYPie(pasa);
        VerificarVacios(pasa);
    }

    private static void VerificarJerarquiaYPie(Action<string> pasa)
    {
        var (doc, p, otro, _) = ProyectoCostos();
        var titulo = p.Items.Single(i => i.Descripcion == "CAPITULO OFICIAL QA");
        var sub = p.Items.Single(i => i.Descripcion == "SUBCAPITULO OFICIAL QA");
        titulo.Item = "08.09.10.11";
        sub.Item = "40";
        sub.ParentId = titulo.Id.ToUpperInvariant();
        var profundo = Nodo("TITULO PROFUNDO QA", "99", 2, sub.Id.ToUpperInvariant(), true);
        p.Items.Add(profundo);
        var otroTitulo = Nodo("TITULO OTRO PRESUPUESTO QA", "88.77.66.55", 1, titulo: true);
        var otroSub = Nodo("SUBTITULO OTRO PRESUPUESTO QA", "12", 1, otroTitulo.Id, true);
        otro.Items[0].ParentId = otroSub.Id;
        otro.Items.AddRange(new[] { otroSub, otroTitulo });
        string antes = Datos(doc);
        var seleccionado = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);
        var todos = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.TodosPresupuestos);
        var resumen = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.HojaResumen);
        foreach (var reporte in new[] { seleccionado.Single(), todos.First() })
        {
            var niveles = reporte.NivelesTitulos;
            Exige(niveles.Count == p.Items.Count(MYGProyectoStorage.EsTitulo) + 1 && niveles[3] == 0 &&
                niveles[Fila(reporte.Hoja, titulo.Descripcion)] == 1 &&
                niveles[Fila(reporte.Hoja, sub.Descripcion)] == 2 &&
                niveles[Fila(reporte.Hoja, profundo.Descripcion)] == 3 &&
                niveles[Fila(reporte.Hoja, "SEGUNDO CAPITULO QA")] == 1,
                "El presupuesto debe mapear raíz y títulos por ParentId, aunque los códigos tengan más o menos puntos que su profundidad real.");
            Exige(p.Items.Where(i => !MYGProyectoStorage.EsTitulo(i))
                    .All(i => !niveles.ContainsKey(Fila(reporte.Hoja, i.Descripcion))) &&
                !niveles.ContainsKey(1) && !niveles.ContainsKey(2),
                "La metadata no debe confundir partidas, título del documento ni cabeceras de columnas con títulos de la estructura.");
        }
        var reporteOtro = todos.Last();
        Exige(reporteOtro.NivelesTitulos.Count == 3 && reporteOtro.NivelesTitulos[3] == 0 &&
            reporteOtro.NivelesTitulos[Fila(reporteOtro.Hoja, otroTitulo.Descripcion)] == 1 &&
            reporteOtro.NivelesTitulos[Fila(reporteOtro.Hoja, otroSub.Descripcion)] == 2 &&
            resumen.Single().NivelesTitulos.Count == 0,
            "Todos los presupuestos debe mantener una jerarquía independiente por hoja y la hoja de resumen debe conservarse sin títulos de estructura.");
        foreach (var reporte in seleccionado.Concat(todos).Concat(resumen))
        {
            var hoja = reporte.Hoja;
            int columnaConcepto = reporte.EsPresupuestoObra ? 2 : 1;
            var calculo = new MYGHojaCalculo(hoja);
            foreach (string concepto in new[] { "Costo directo", "Gastos generales", "Utilidad", "Parcial", "I.G.V.", "Otros impuestos", "Total" })
            {
                int fila = hoja.Celdas.Where(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == columnaConcepto &&
                        Normalizar(calculo.Mostrar(c.Key)) == Normalizar(concepto))
                    .Select(c => MYGHojaCalculo.Coordenadas(c.Key).Fila).Single();
                bool sombreada = concepto is "Costo directo" or "Parcial" or "Total";
                for (int columna = 1; columna <= hoja.Columnas; columna++)
                {
                    string direccion = MYGHojaCalculo.Columna(columna) + fila;
                    hoja.Celdas.TryGetValue(direccion, out var celda);
                    Exige(sombreada ? celda != null && celda.ColorFondo == "ECEEF0" : string.IsNullOrEmpty(celda?.ColorFondo),
                        "El pie debe sombrear toda la fila de Costo directo, Parcial y Total, incluidas sus celdas vacías, y dejar sin relleno los otros cuatro conceptos.");
                    if (sombreada && columna != columnaConcepto && columna != hoja.Columnas)
                        Exige(celda.Contenido == "", "Extender el sombreado del pie no debe introducir contenido en las columnas vacías.");
                }
                Exige(!reporte.NivelesTitulos.ContainsKey(fila),
                    "Los conceptos y totales del pie no deben participar en los colores por nivel de los títulos.");
            }
            if (reporte.EsPresupuestoObra)
                Exige(hoja.Columnas == 6 && reporte.NivelesTitulos.Keys.SelectMany(fila => new[] { "A", "B", "F" }
                        .Select(columna => hoja.Celdas[columna + fila])).All(c => c.ColorTexto == "000000"),
                    "Los títulos deben comenzar negros mientras no se active su opción de color, sin afectar el sombreado predeterminado del pie.");
        }
        Exige(Datos(doc) == antes, "Generar metadata jerárquica y sombreado del pie no debe modificar los presupuestos ni sus partidas.");
        string congelado = Datos(seleccionado);
        sub.ParentId = null; titulo.Descripcion = "TITULO EDITADO DESPUES QA";
        Exige(Datos(seleccionado) == congelado && seleccionado[0].NivelesTitulos[Fila(seleccionado[0].Hoja, sub.Descripcion)] == 2,
            "La jerarquía y el contenido del reporte deben quedar congelados aunque cambie después el árbol del proyecto.");
        pasa("Presupuestos seleccionado y completos conservan niveles reales por ParentId y pie gris completo, incluidos blancos; resumen comparte el pie sin metadata de títulos");
    }

    private static (MYGProyectoDocumento Documento, MYGPresupuestoDocumento P,
        MYGPresupuestoDocumento Otro, ItemPresupuestoDelphin Acu) ProyectoCostos()
    {
        var doc = MYGProyectoStorage.Nuevo("PROYECTO REPORTES QA", "ESTRUCTURAS QA");
        var p = doc.Presupuestos[0];
        p.Costos.GastosGeneralesPorcentaje = 10; p.Costos.UtilidadPorcentaje = 5;
        p.Costos.ImpuestoPorcentaje = 18; p.Costos.OtrosImpuestosPorcentaje = 2;
        var titulo = Nodo("CAPITULO OFICIAL QA", "07", 1, titulo: true);
        var sub = Nodo("SUBCAPITULO OFICIAL QA", "07.09", 1, titulo.Id, true);
        var acu = Nodo("PARTIDA ACU QA", "07.09.10", 1, sub.Id);
        var directo = Nodo("PARTIDA PRECIO DIRECTO QA", "07.09.20", 2, sub.Id);
        directo.Costos.Cantidad = 1.5m; directo.Costos.PrecioDirecto = 12.40m;
        var otroTitulo = Nodo("SEGUNDO CAPITULO QA", "20", 2, titulo: true);
        var nativo = Nodo("PARTIDA NATIVA QA", "20.01", 1, otroTitulo.Id);
        nativo.Costos.Cantidad = 3; nativo.Costos.PrecioDirecto = 1.234m;
        var subpartida = Nodo("SUBPARTIDA ACU QA", "20.02", 2, otroTitulo.Id);
        subpartida.Costos.PrecioDirecto = 5; acu.Costos.Cantidad = 2;
        Recurso(acu, Insumo(p, MYGGrupoRecurso.Materiales, "MAT-QA", "MATERIAL QA", 7.5m), 2);
        Recurso(acu, Insumo(p, MYGGrupoRecurso.ManoObra, "MO-QA", "MANO OBRA QA", 20), 0.5m);
        Recurso(acu, Insumo(p, MYGGrupoRecurso.Equipo, "EQ-QA", "EQUIPO QA", 3), 1);
        Recurso(acu, Insumo(p, MYGGrupoRecurso.Subcontratos, "SC-QA", "SUBCONTRATO QA", 4), 1);
        acu.Costos.Analisis.Add(new MYGRecursoACU { Grupo = MYGGrupoRecurso.Subpartidas,
            SubpartidaIdLocal = subpartida.IdLocalMYG, Cantidad = 2 });
        acu.Costos.OrdenGruposACU = new() { MYGGrupoRecurso.Subcontratos, MYGGrupoRecurso.Subpartidas,
            MYGGrupoRecurso.Materiales, MYGGrupoRecurso.Equipo, MYGGrupoRecurso.ManoObra };
        p.Items.AddRange(new[] { directo, otroTitulo, nativo, sub, subpartida, acu, titulo });
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, nativo, 1.23m, 3.70m);
        var otro = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA QA", Item = "02", Posicion = 2 };
        var partidaOtra = Nodo("PARTIDA OTRO PRESUPUESTO QA", "88.01", 1);
        partidaOtra.Costos.Cantidad = 1; partidaOtra.Costos.PrecioDirecto = 13;
        otro.Items.Add(partidaOtra); otro.Costos.GastosGeneralesPorcentaje = 20;
        doc.Presupuestos = new() { otro, p };
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        return (doc, p, otro, acu);
    }

    private static void VerificarPresupuestos(string carpeta, Action<string> pasa)
    {
        var (doc, p, otro, _) = ProyectoCostos();
        string antes = Datos(doc);
        var seleccionado = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);
        Exige(seleccionado.Count == 1 && !Contiene(seleccionado[0].Hoja, "PARTIDA OTRO PRESUPUESTO QA"),
            "El informe seleccionado debe incluir únicamente su presupuesto.");
        var hoja = seleccionado[0].Hoja;
        string[] orden = { "CAPITULO OFICIAL QA", "SUBCAPITULO OFICIAL QA", "PARTIDA ACU QA",
            "PARTIDA PRECIO DIRECTO QA", "SEGUNDO CAPITULO QA", "PARTIDA NATIVA QA", "SUBPARTIDA ACU QA" };
        var filas = orden.Select(t => Fila(hoja, t)).ToArray();
        Exige(filas.All(f => f > 0) && filas.SequenceEqual(filas.Order()),
            "El informe debe recorrer la jerarquía por posición sin depender del orden de la lista.");
        foreach (string codigo in new[] { "07", "07.09", "07.09.10", "07.09.20", "20", "20.01", "20.02" })
            Exige(Fila(hoja, p.Item + "." + codigo) > 0, "El informe no muestra el código completo del presupuesto y la partida " + codigo + ".");
        FilaConNumeros(hoja, "PARTIDA PRECIO DIRECTO QA", 1.5m, 12.4m, 18.6m);
        FilaConNumeros(hoja, "PARTIDA ACU QA", 2, 42, 84);
        FilaConNumeros(hoja, "PARTIDA NATIVA QA", 3, 1.23m, 3.70m);
        Exige(Datos(doc) == antes, "Imprimir un presupuesto modificó sus datos o precios nativos.");
        pasa("Informe seleccionado respeta jerarquía y códigos oficiales, precios directos, ACU y parciales nativos");

        var resumen = MYGMotorPresupuestos.Resumen(p);
        Exige(resumen.CostoDirecto == 106.30m && resumen.Total == 146.71m, "El caso de pie de informe perdió su importe esperado.");
        string[] etiquetas = { "Costo Directo", "Gastos Generales", "Utilidad", "Parcial", "I.G.V.", "Otros impuestos", "Total" };
        decimal[] valores = { resumen.CostoDirecto, resumen.GastosGenerales, resumen.Utilidad, resumen.Subtotal,
            resumen.Impuesto, resumen.OtrosImpuestos, resumen.Total };
        for (int i = 0; i < etiquetas.Length; i++) FilaConNumeros(hoja, etiquetas[i], valores[i]);
        pasa("Informe de presupuesto presenta los siete conceptos del pie con GG, utilidad e impuestos correctos");

        var todos = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.TodosPresupuestos);
        Exige(todos.Count == 2 && Contiene(todos[0].Hoja, p.Nombre) && Contiene(todos[1].Hoja, otro.Nombre) &&
            todos.All(h => h.EsPresupuestoObra && h.DatosProyecto.Single(d => d.Key == "Presupuesto").Value == "" &&
                h.CabeceraImpresion.Single(d => d.Key == "PRESUPUESTO").Value == ""),
            "El proyecto completo debe conservar su orden visual y dejar Presupuesto vacío en los datos generales.");
        var hojasResumen = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.HojaResumen);
        Exige(hojasResumen.Count == 1, "El resumen debe ser una hoja del presupuesto seleccionado.");
        for (int i = 0; i < etiquetas.Length; i++) FilaConNumeros(hojasResumen[0].Hoja, etiquetas[i], valores[i]);
        Exige(!Contiene(hojasResumen[0].Hoja, otro.Nombre) &&
            hojasResumen[0].DatosProyecto.Single(d => d.Key == "Presupuesto").Value == p.ToString() &&
            !hojasResumen[0].EsPresupuestoObra && ReferenceEquals(hojasResumen[0].CabeceraImpresion, hojasResumen[0].DatosProyecto),
            "La hoja de resumen mezcló presupuestos o adoptó la cabecera compacta del presupuesto de obra.");
        FilaConNumeros(todos[1].Hoja, "Total", 15.6m);
        Exige(Datos(doc) == antes, "Los informes del proyecto normalizaron tasas o seleccionaron otro presupuesto.");
        pasa("Todos los presupuestos respeta orden y tasas independientes; hoja de resumen presenta el pie del presupuesto seleccionado");

        string ruta = Path.Combine(carpeta, "Informe presupuesto completo.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, seleccionado.Select(h => h.Hoja).ToArray());
        var reabierta = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta)[0], hoja.CeldaTotal);
        FilaConNumeros(reabierta, "PARTIDA NATIVA QA", 1.23m, 3.70m);
        FilaConNumeros(reabierta, "Total", 146.71m);
        Exige(reabierta.AreaImpresion == hoja.AreaImpresion && reabierta.RangosCombinados.SequenceEqual(hoja.RangosCombinados) &&
            reabierta.Celdas.Values.Any(c => c.Negrita) && reabierta.Celdas.Values.Any(c => c.ColorFondo.Length > 0),
            "Guardar y reabrir el informe perdió área de impresión, títulos combinados o estilos.");
        pasa("Informes guardados en XLSX reabren cifras nativas, pie y formato de impresión");
    }

    private static void VerificarACUYConsolidado(Action<string> pasa)
    {
        var (doc, p, _, acu) = ProyectoCostos(); string antes = Datos(doc);
        var hojas = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.AnalisisCostosUnitarios);
        var hoja = HojaDe(hojas, "PARTIDA ACU QA");
        var filas = acu.Costos.OrdenGruposACU.Select(g => Fila(hoja, MYGMotorPresupuestos.Grupo(g))).ToArray();
        Exige(filas.All(f => f > 0) && filas.SequenceEqual(filas.Order()), "El ACU impreso perdió el orden personalizado de los grupos.");
        FilaConNumeros(hoja, "MATERIAL QA", 2m, 7.5m, 15m);
        FilaConNumeros(hoja, "MANO OBRA QA", 0.5m, 20m, 10m);
        FilaConNumeros(hoja, "SUBPARTIDA ACU QA", 2m, 5m, 10m);
        Exige(hoja.Celdas.Values.Any(c => MYGHojaCalculo.IntentarNumero(c.Contenido, out var n) && n == 42m),
            "El ACU no incluyó su precio unitario completo.");
        Exige(hojas.Any(h => Contiene(h.Hoja, "PARTIDA PRECIO DIRECTO QA")) &&
            hojas.Any(h => Contiene(h.Hoja, "PARTIDA NATIVA QA")), "El análisis omitió partidas con precio directo o nativo.");
        Exige(Datos(doc) == antes, "Generar análisis cambió el orden del ACU original.");
        pasa("Informe ACU conserva grupos personalizados, recursos, subpartidas y partidas con precio directo/nativo");

        var consolidado = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.ConsolidadoCostosUnitarios);
        Exige(consolidado.Count == 1, "El consolidado debe agrupar los recursos en una sola hoja.");
        hoja = consolidado[0].Hoja;
        FilaConNumeros(hoja, "MATERIAL QA", 4m, 7.5m, 30m);
        FilaConNumeros(hoja, "MANO OBRA QA", 1m, 20m, 20m);
        FilaConNumeros(hoja, "EQUIPO QA", 2m, 3m, 6m);
        FilaConNumeros(hoja, "SUBCONTRATO QA", 2m, 4m, 8m);
        Exige(!Contiene(hoja, "PARTIDA OTRO PRESUPUESTO QA") && Datos(doc) == antes,
            "El consolidado cruzó presupuestos o modificó los insumos del proyecto.");
        pasa("Consolidado calcula cantidades e importes de insumos por metrado, conserva grupos y alcance seleccionado");
    }

    private static void VerificarFormatoACU(Action<string> pasa)
    {
        var (doc, p, _, acu) = ProyectoCostos();
        doc.Datos = new MYGDatosProyecto { Propietario = "PROPIETARIO ACU QA", Departamento = "ANCASH",
            Provincia = "SANTA", Distrito = "CHIMBOTE", FechaElaboracion = new DateTime(2026, 10, 14) };
        p.Costos.Insumos.Single(i => i.Codigo == "MO-QA").CodigoAlterno = "0000101";
        acu.Costos.Analisis.Single(r => r.Grupo == MYGGrupoRecurso.Materiales).DesperdicioPorcentaje = 10;
        MYGMotorPresupuestos.CapturarPrecioDelphin(p, acu, 44m, 88m);
        string antes = Datos(doc);
        var reportes = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.AnalisisCostosUnitarios);
        Exige(reportes.Count == 1 && reportes[0].EsAnalisisCostosUnitarios && !reportes[0].EsPresupuestoObra,
            "Los análisis deben apilarse en un solo informe continuo por presupuesto, sin tomar el formato de presupuesto de obra.");
        var r = reportes[0]; var h = r.Hoja; var motor = new MYGHojaCalculo(h);
        Exige(h.Columnas == 7 && h.OrientacionPagina == "Vertical" && motor.Mostrar("A1") == "Análisis de Costos Unitarios" &&
            h.Celdas.Values.All(c => c.ColorTexto == "000000") && h.Celdas.Values.All(c => string.IsNullOrEmpty(c.ColorFondo) || c.ColorFondo == "ECEEF1"),
            "El ACU debe presentar siete columnas, orientación vertical, título centrado y fondos blancos con bandas grises.");
        Exige(r.CabeceraImpresion.Select(d => d.Key).SequenceEqual(new[] { "PROYECTO", "PRESUPUESTO", "PROPIETARIO", "UBICACIÓN", "FECHA DE PROY." }) &&
            r.CabeceraImpresion[0].Value == doc.Nombre && r.CabeceraImpresion[2].Value == "PROPIETARIO ACU QA" &&
            r.CabeceraImpresion[3].Value == "DPTO: ANCASH  PROV: SANTA  DIST: CHIMBOTE" && r.CabeceraImpresion[4].Value == "14/10/2026",
            "La cabecera compacta del ACU debe proceder de los datos actuales del proyecto.");
        var partidas = MYGOrdenPresupuestos.FilasOrdenadas(p).Where(i => !MYGProyectoStorage.EsTitulo(i)).ToArray();
        var inicios = partidas.Select(i => Fila(h, "Partida: " + p.Item + "." + i.Item)).ToArray();
        Exige(inicios.All(f => f > 0) && inicios.SequenceEqual(inicios.Order()),
            "Los bloques de análisis deben mantener el orden real de las partidas del presupuesto.");
        foreach (int inicio in inicios)
        {
            Exige(h.RangosCombinados.Contains("A" + inicio + ":E" + inicio) &&
                motor.Mostrar("F" + inicio) == "Rendimiento:" && motor.Mostrar("F" + (inicio + 1)).StartsWith("Costo unit. por ", StringComparison.Ordinal) &&
                new[] { "Código Alt.", "Descripción", "Unid.", "Recursos", "Cant.", "Precio", "Parcial" }
                    .Select((texto, indice) => motor.Mostrar(MYGHojaCalculo.Columna(indice + 1) + (inicio + 3)) == texto).All(v => v),
                "Cada partida debe tener código, rendimiento, descripción, costo unitario y sus siete cabeceras.");
        }
        FilaConNumeros(h, "MATERIALES", 16.5m); FilaConNumeros(h, "MANO DE OBRA", 10m);
        FilaConNumeros(h, "EQUIPO", 3m); FilaConNumeros(h, "SUB-CONTRATOS", 4m); FilaConNumeros(h, "SUB-PARTIDAS", 10m);
        FilaConNumeros(h, "Ajuste del precio unitario importado de Delphin", .5m);
        Exige(Fila(h, "0000101") > 0 && Contiene(h, "Desperdicio: 10 %") && Contiene(h, "Jornada: 8 h"),
            "El formato de referencia debe conservar código alterno literal, desperdicio y jornada.");
        int material = Fila(h, "MATERIAL QA");
        Exige(motor.Numero("E" + material) == 2.2m && motor.Mostrar("E" + material) == 2.2m.ToString("0.0000", CultureInfo.CurrentCulture) &&
            motor.Numero("G" + (inicios[0] + 1)) == 44m,
            "Cant. debe mostrar cuatro decimales y el costo unitario debe conservar el precio nativo y su ajuste.");
        var individual = MYGReportesProyecto.CrearAnalisis(doc, p.Id, acu.Id);
        Exige(individual.EsAnalisisCostosUnitarios && individual.CabeceraImpresion.SequenceEqual(r.CabeceraImpresion) &&
            Contiene(individual.Hoja, "MATERIAL QA") && !Contiene(individual.Hoja, "PARTIDA PRECIO DIRECTO QA") &&
            new MYGHojaCalculo(individual.Hoja).Numero(individual.Hoja.CeldaTotal) == 44m,
            "Exportar el ACU individual debe usar el mismo generador y conservar sólo la partida activa.");
        var config = new MYGConfiguracionVistaReporte(reportes);
        config.Fuente("Calibri"); config.Restaurar();
        Exige(config.Reportes.Single().EsAnalisisCostosUnitarios && !config.Reportes.Single().CabeceraEnHoja &&
            config.Reportes.Single().CabeceraImpresion.SequenceEqual(r.CabeceraImpresion) && Datos(doc) == antes,
            "Restaurar el informe no debe perder la marca del ACU ni alterar el proyecto.");
        pasa("ACU continuo e individual comparten cabecera compacta, siete columnas, grupos con subtotales, códigos alternos, cantidades efectivas y ajustes Delphin");
    }

    private static void VerificarFuentes(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("FUENTES QA"); var p = doc.Presupuestos[0];
        var cantidad = Nodo("FUENTE CANTIDAD QA", "01", 1); cantidad.Costos.Cantidad = 11;
        var manual = Nodo("FUENTE MANUAL QA", "02", 2); manual.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        manual.Costos.Metrados.Add(new() { Descripcion = "DETALLE MANUAL QA", Elementos = 2, CantidadPorElemento = 3, Largo = 4 });
        manual.Costos.Metrados.Add(new() { Descripcion = "DESCUENTO MANUAL QA", Elementos = 1, CantidadPorElemento = 1, Descuento = true });
        var bim = Nodo("FUENTE BIM QA", "03", 3); bim.Costos.FuenteMetrado = MYGFuenteMetrado.BIM;
        bim.Costos.MetradosBIM.Add(new() { ActivoId = "ELEMENTO BIM QA", Tabla = "TABLA BIM QA", Unidad = "und", Cantidad = 4.5m });
        bim.Costos.MetradosBIM.Add(new() { ActivoId = "SEGUNDO ELEMENTO BIM QA", Tabla = "TABLA BIM QA", Unidad = "und", Cantidad = 2 });
        var excel = Nodo("FUENTE EXCEL QA", "04", 4); excel.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        excel.Costos.Hoja.Poner("A3", "DETALLE EXCEL QA"); excel.Costos.Hoja.Poner("B3", "2"); excel.Costos.Hoja.Poner("C3", "3");
        p.Items.AddRange(new[] { cantidad, manual, bim, excel }); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = Datos(doc); var contexto = p.ContextoReferencias;
        var originales = p.Items.Select(i => i.Costos.Hoja).ToArray();
        var hojas = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.Metrados);
        Exige(hojas.Count == 4, "El informe de metrados debe incluir Cantidad, Manual, BIM y Excel.");
        foreach (var entrada in new[] { (Partida: cantidad, Total: 11m), (Partida: manual, Total: 23m), (Partida: bim, Total: 6.5m) })
        {
            var h = HojaDe(hojas, entrada.Partida.Descripcion);
            Exige(new MYGHojaCalculo(h).Numero(h.CeldaTotal) == entrada.Total,
                "El informe perdió la cantidad efectiva de " + entrada.Partida.Descripcion + ".");
        }
        var hojaExcel = HojaDe(hojas, excel.Descripcion);
        Exige(Contiene(hojaExcel, "DETALLE EXCEL QA") && NumerosFila(hojaExcel, Fila(hojaExcel, "DETALLE EXCEL QA")).Contains(6m),
            "El informe Excel perdió su detalle o el resultado de la fórmula.");
        Exige(Contiene(HojaDe(hojas, manual.Descripcion), "DETALLE MANUAL QA") &&
            Contiene(HojaDe(hojas, manual.Descripcion), "DESCUENTO MANUAL QA") &&
            Contiene(HojaDe(hojas, bim.Descripcion), "TABLA BIM QA"), "Los metrados manuales/BIM perdieron la trazabilidad de su detalle.");
        Exige(MYGReportesProyecto.CrearMetradosExcel(doc, p.Id).Count == 1,
            "Exportar hojas Excel activas incluyó fuentes manuales, BIM o cantidades sin referencias.");
        Exige(Datos(doc) == antes && ReferenceEquals(contexto, p.ContextoReferencias) &&
            p.Items.Select(i => i.Costos.Hoja).Zip(originales).All(par => ReferenceEquals(par.First, par.Second)),
            "Imprimir metrados sustituyó hojas, contextos o datos originales.");
        pasa("Metrados imprime detalles y totales efectivos de Cantidad, Manual, BIM y Excel; XLSX incluye solo fuentes activas");
    }

    private static void VerificarFiltrosExcel(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("FILTROS PLANTILLA QA"); var p = doc.Presupuestos[0];
        var estandar = Nodo("ESTANDAR QA", "01", 1);
        var acero = Nodo("ACEROS QA", "02", 2); acero.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        var importada = Nodo("IMPORTADA QA", "03", 3);
        importada.Costos.Hoja = new MYGHojaMetrado { Nombre = "Importada QA", CeldaTotal = "B4", IdPlantilla = "" };
        importada.Costos.Hoja.Poner("A3", "IMPORTADA SOLO QA"); importada.Costos.Hoja.Poner("B3", "9");
        importada.Costos.Hoja.Poner("B4", "=B3*2");
        var inactiva = Nodo("ACEROS INACTIVO QA", "04", 4);
        inactiva.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        var legado = Nodo("ESTANDAR LEGADO QA", "05", 5); legado.Costos.Hoja.IdPlantilla = "";
        legado.Costos.Hoja.Poner("A3", "ESTANDAR LEGADO SOLO QA");
        var personalizada = Nodo("PERSONALIZADA QA", "06", 6); personalizada.Costos.Hoja.IdPlantilla = "custom";
        personalizada.Costos.Hoja.Poner("A3", "PERSONALIZADA SOLO QA");
        foreach (var i in new[] { estandar, acero, importada, legado, personalizada }) i.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        estandar.Costos.Hoja.Poner("A3", "ESTANDAR SOLO QA"); estandar.Costos.Hoja.Poner("B3", "3");
        estandar.Costos.Hoja.AreaImpresion = "A1:L22"; estandar.Costos.Hoja.OrientacionPagina = "Vertical";
        estandar.Costos.Hoja.RepetirTitulos = false; estandar.Costos.Hoja.TamanoPapel = "A3";
        estandar.Costos.Hoja.MargenIzquierdo = 0.71m; estandar.Costos.Hoja.MargenDerecho = 1.09m;
        estandar.Costos.Hoja.ImprimirEncabezados = true; estandar.Costos.Hoja.ImprimirLineasDivision = true;
        acero.Costos.Hoja.Poner("A3", "ACEROS SOLO QA"); acero.Costos.Hoja.Poner("B3", "2");
        acero.Costos.Hoja.Poner("C3", "3"); acero.Costos.Hoja.Celdas["D3"].Contenido = "3/8"; acero.Costos.Hoja.Poner("E3", "4");
        acero.Costos.Hoja.Celdas["A3"].ColorTexto = "123456"; acero.Costos.Hoja.Celdas["A3"].Cursiva = true;
        p.Items.AddRange(new[] { estandar, acero, importada, inactiva, legado, personalizada }); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = Datos(doc);
        Exige(MYGReportesProyecto.CrearMetradosExcel(doc, p.Id).Count == 5, "La exportación general perdió una hoja Excel activa.");
        var soloEstandar = MYGReportesProyecto.CrearMetradosExcel(doc, p.Id, MYGPlantillasMetrado.Estandar);
        var soloAceros = MYGReportesProyecto.CrearMetradosExcel(doc, p.Id, MYGPlantillasMetrado.Aceros);
        var soloImportada = MYGReportesProyecto.CrearMetradosExcel(doc, p.Id, "");
        Exige(soloEstandar.Count == 2 && soloEstandar.Any(h => Contiene(h, "ESTANDAR SOLO QA")) &&
            soloEstandar.Any(h => Contiene(h, "ESTANDAR LEGADO SOLO QA")) &&
            soloAceros.Count == 1 && Contiene(soloAceros[0], "ACEROS SOLO QA") &&
            soloImportada.Count == 2 && soloImportada.Any(h => Contiene(h, "IMPORTADA SOLO QA")) &&
            soloImportada.Any(h => Contiene(h, "PERSONALIZADA SOLO QA")),
            "El filtro debe reconocer las plantillas, incluidos encabezados estándar legados, y agrupar las hojas importadas/personalizadas.");
        var reportesAceros = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.MetradosAceros);
        Exige(reportesAceros.Count == 1 && Contiene(reportesAceros[0].Hoja, "ACEROS SOLO QA") &&
            new MYGHojaCalculo(reportesAceros[0].Hoja).Numero(reportesAceros[0].Hoja.CeldaTotal) == 13.92m,
            "La impresión de aceros debe usar solo hojas activas de aceros y calcular su peso final.");
        Exige(Datos(doc) == antes, "Filtrar por plantilla modificó la identidad o las fuentes de metrado originales.");
        pasa("Exportación por plantilla distingue estándar, aceros e importadas; impresión de aceros calcula peso y excluye hojas inactivas");

        var hojaImpresion = HojaDe(MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.Metrados), estandar.Descripcion);
        Exige(hojaImpresion.AreaImpresion == "A1:L22" && hojaImpresion.OrientacionPagina == "Vertical" &&
            !hojaImpresion.RepetirTitulos && hojaImpresion.TamanoPapel == "A3" &&
            hojaImpresion.MargenIzquierdo == 0.71m && hojaImpresion.MargenDerecho == 1.09m &&
            hojaImpresion.ImprimirEncabezados && hojaImpresion.ImprimirLineasDivision && Datos(doc) == antes,
            "Imprimir una hoja Excel ancha debe conservar orientación, papel, márgenes y opciones de impresión personalizadas.");
        pasa("Impresión de metrados conserva configuración de página personalizada aunque la hoja tenga más de ocho columnas");

        string ruta = Path.Combine(carpeta, "Metrados acero con formato.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, soloAceros);
        var reabierta = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta)[0], soloAceros[0].CeldaTotal);
        Exige(new MYGHojaCalculo(reabierta).Numero(reabierta.CeldaTotal) == 13.92m, "El XLSX de aceros perdió el peso final.");
        Exige(reabierta.Celdas["A3"].ColorTexto == "123456" && reabierta.Celdas["A3"].Cursiva, "El XLSX de aceros perdió estilos personalizados.");
        Exige(reabierta.Celdas["AD16"].Contenido.StartsWith('='), "El XLSX de aceros perdió la fórmula del total.");
        Exige(reabierta.Celdas["D3"].TipoValidacion == "Lista", "El XLSX de aceros perdió la lista de diámetros.");
        Exige(reabierta.OrientacionPagina == "Horizontal", "El XLSX de aceros perdió la orientación de página.");
        Exige(reabierta.RangosCombinados.SequenceEqual(soloAceros[0].RangosCombinados), "El XLSX de aceros perdió celdas combinadas.");
        Exige(Datos(doc) == antes, "Guardar el XLSX cambió el original.");
        pasa("XLSX de aceros guarda y reabre fórmulas, peso final, estilos, validaciones, celdas combinadas y orientación");
    }

    private static void VerificarDependencias(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("DEPENDENCIAS REPORTES QA"); var p = doc.Presupuestos[0];
        var a = Nodo("DESTINO ACERO QA", "01.01", 1); a.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        a.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros); p.Items.Add(a);
        var otro = new MYGPresupuestoDocumento { Nombre = "ORIGEN OTRO PRESUPUESTO QA", Item = "02", Posicion = 2 };
        var b = Nodo("ORIGEN INTERMEDIO QA", "01.01", 1);
        var c = Nodo("ORIGEN FINAL QA", "01.02", 2); c.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        c.Costos.Hoja.Poner("B3", "7"); b.Costos.Hoja.IdPlantilla = MYGPlantillasMetrado.Estandar;
        otro.Items.AddRange(new[] { b, c }); doc.Presupuestos.Add(otro); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        b.Costos.Hoja.Poner("B3", "=" + MYGReferenciasMetrado.CrearReferencia(b.Costos.Hoja, otro, c, "B3") + "*2");
        a.Costos.Hoja.Poner("AD16", "=" + MYGReferenciasMetrado.CrearReferencia(a.Costos.Hoja, otro, b, "B3") + "+1");
        string antes = Datos(doc); var contexto = p.ContextoReferencias; var hojaContexto = a.Costos.Hoja.ContextoReferencias;
        var presupuesto = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);
        FilaConNumeros(presupuesto[0].Hoja, a.Descripcion, 15m);
        var hojas = MYGReportesProyecto.CrearMetradosExcel(doc, p.Id, MYGPlantillasMetrado.Aceros);
        Exige(hojas.Count == 3 && hojas.All(h => !ReferenceEquals(h, a.Costos.Hoja) &&
            !ReferenceEquals(h, b.Costos.Hoja) && !ReferenceEquals(h, c.Costos.Hoja)),
            "Filtrar por aceros debe añadir copias de todas las dependencias transitivas externas y fuentes inactivas.");
        Exige(hojas.Count(h => h.Nombre.StartsWith("Soporte ", StringComparison.Ordinal)) == 2,
            "Los orígenes añadidos fuera del filtro deben identificarse como hojas de soporte.");
        int ia = hojas.ToList().FindIndex(h => h.IdPlantilla == MYGPlantillasMetrado.Aceros);
        int ib = hojas.ToList().FindIndex(h => h.PartidaReferenciasId == b.IdLocalMYG);
        int ic = hojas.ToList().FindIndex(h => h.PartidaReferenciasId == c.IdLocalMYG);
        Exige(ia >= 0 && ib >= 0 && ic >= 0, "El cierre de dependencias perdió las identidades de partidas exportadas.");
        string ruta = Path.Combine(carpeta, "Metrados filtro con dependencias.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        string[] nombres = MYGExcelPresupuestos.Hojas(ruta);
        var destino = CeldaXml(ruta, ia + 1, "AD16"); var intermedio = CeldaXml(ruta, ib + 1, "B3");
        Exige((string)destino.Element(S + "f") == "'" + nombres[ib].Replace("'", "''") + "'!B3+1" &&
            (string)intermedio.Element(S + "f") == "'" + nombres[ic].Replace("'", "''") + "'!B3*2" &&
            (string)destino.Element(S + "v") == "15", "El XLSX filtrado perdió fórmulas nativas o el valor de la cadena entre presupuestos.");
        Exige(Datos(doc) == antes && ReferenceEquals(contexto, p.ContextoReferencias) &&
            ReferenceEquals(hojaContexto, a.Costos.Hoja.ContextoReferencias), "Los informes cruzados sustituyeron la sesión de referencias del editor.");
        pasa("Informes calculan METRADO entre presupuestos y XLSX filtrado conserva la cadena transitiva con fórmulas nativas y caché correcta");

        // Un documento recién deserializado no tiene el contexto de sesión. La
        // generación debe reconstruir una sesión privada, sin enlazar el original.
        var desconectado = JsonSerializer.Deserialize<MYGProyectoDocumento>(Datos(doc));
        string sinContextoAntes = Datos(desconectado);
        var copia = MYGReportesProyecto.Crear(desconectado, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado);
        FilaConNumeros(copia[0].Hoja, a.Descripcion, 15m);
        var hojasDesconectadas = MYGReportesProyecto.CrearMetradosExcel(desconectado, p.Id, MYGPlantillasMetrado.Aceros);
        MYGExcelPresupuestos.Guardar(ruta, hojasDesconectadas);
        Exige(hojasDesconectadas.Count == 3 && Datos(desconectado) == sinContextoAntes &&
            desconectado.Presupuestos.All(x => x.ContextoReferencias == null && x.Items.All(i => i.Costos.Hoja.ContextoReferencias == null)),
            "Generar informes de un documento sin sesión enlazó o modificó sus objetos originales.");
        pasa("Generar informes de documentos sin sesión reconstruye referencias privadas y conserva originales desconectados");

        foreach (MYGTipoReporteProyecto tipo in Enum.GetValues<MYGTipoReporteProyecto>())
            MYGReportesProyecto.Crear(doc, p.Id, tipo);
        Exige(Datos(doc) == antes && ReferenceEquals(contexto, p.ContextoReferencias),
            "Algún tipo de informe alteró los datos o el contexto del proyecto activo.");
        var exportada = hojas[ia]; exportada.Celdas["AD16"].Contenido = "999";
        Exige(Datos(doc) == antes && new MYGHojaCalculo(a.Costos.Hoja).Numero("AD16") == 15m,
            "Las hojas entregadas al impresor/exportador comparten celdas con el proyecto original.");
        pasa("Todos los tipos de informe son consultas sin cambios y entregan hojas independientes del proyecto y su sesión");
    }

    private static void VerificarVacios(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("REPORTES VACIOS QA"); var p = doc.Presupuestos[0]; string antes = Datos(doc);
        foreach (MYGTipoReporteProyecto tipo in Enum.GetValues<MYGTipoReporteProyecto>())
        {
            var hojas = MYGReportesProyecto.Crear(doc, p.Id, tipo);
            Exige(hojas != null && hojas.All(h => h.Hoja != null && !string.IsNullOrWhiteSpace(h.Titulo)),
                "El informe vacío debe retornar una colección válida: " + tipo);
        }
        Exige(MYGReportesProyecto.CrearMetradosExcel(doc, p.Id).Count == 0 &&
            MYGReportesProyecto.CrearMetradosExcel(doc, p.Id, MYGPlantillasMetrado.Aceros).Count == 0 && Datos(doc) == antes,
            "Un presupuesto vacío produjo hojas de metrado ficticias o cambió datos.");
        pasa("Presupuestos sin partidas generan informes válidos y exportaciones vacías sin datos ficticios ni cambios");
    }

    private static void VerificarCodigosYTextos(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("CODIGOS LITERALES QA"); var p = doc.Presupuestos[0];
        var i = Nodo("=SUM(1,2)", "000123", 1); i.Costos.Cantidad = 1; i.Costos.PrecioDirecto = 2;
        p.Items.Add(i); string antes = Datos(doc);
        var hoja = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado)[0].Hoja;
        Exige(Fila(hoja, p.Item + ".000123") > 0 && Fila(hoja, "=SUM(1,2)") > 0,
            "Los códigos deben conservar ceros iniciales y las descripciones que empiezan por '=' deben seguir siendo texto.");
        FilaConNumeros(hoja, "=SUM(1,2)", 1m, 2m);
        string ruta = Path.Combine(carpeta, "Informe codigos literales.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, new[] { hoja });
        var reabierta = MYGExcelPresupuestos.Importar(ruta, MYGExcelPresupuestos.Hojas(ruta)[0], hoja.CeldaTotal);
        Exige(Fila(reabierta, p.Item + ".000123") > 0 && Fila(reabierta, "=SUM(1,2)") > 0 && Datos(doc) == antes,
            "El XLSX convirtió un código o una descripción en un valor/fórmula y cambió su contenido.");
        pasa("Informes y XLSX conservan códigos con ceros iniciales y descripciones literales que comienzan por '='");
    }

    private static void VerificarPresentacionInstitucional(Action<string> pasa)
    {
        var (doc, p, _, acu) = ProyectoCostos();
        doc.Datos = new MYGDatosProyecto
        {
            Propietario = "ENTIDAD PROPIETARIA QA", Portafolio = "PORTAFOLIO QA", TipoObra = "OBRA PUBLICA QA",
            Departamento = "ANCASH", Provincia = "SANTA", Distrito = "CHIMBOTE", Localidad = "LOCALIDAD QA",
            FechaElaboracion = new DateTime(2026, 10, 14), FechaInicio = new DateTime(2026, 11, 1),
            FechaFin = new DateTime(2027, 1, 31), Duracion = 3.125m, UnidadDuracion = "MESES",
            Calendario = "CALENDARIO QA", Periodos = "PERIODOS QA", ModalidadEjecucion = "A",
            PorRendimientoCuadrilla = false, PorAsignacionRecursos = true, HechoPor = "PROFESIONAL QA"
        };
        acu.Costos.Cantidad = 2.1234m;
        var acero = Nodo("PRECISION METRADO QA", "20.03", 3, p.Items.Single(i => i.Item == "20").Id);
        acero.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        acero.Costos.Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros);
        acero.Costos.Hoja.Poner("A3", "DESCRIPCION METRADO QA");
        acero.Costos.Hoja.Poner("B3", "2.1234");
        acero.Costos.Hoja.Celdas["B3"].FormatoNumero = "0.0000";
        acero.Costos.Hoja.Poner("AD16", "=B3*3");
        p.Items.Add(acero); MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = Datos(doc);
        var esperados = new Dictionary<string, string>
        {
            ["Proyecto"] = doc.Nombre, ["Presupuesto"] = p.ToString(), ["Propietario"] = "ENTIDAD PROPIETARIA QA",
            ["Portafolio"] = "PORTAFOLIO QA", ["Tipo de obra"] = "OBRA PUBLICA QA", ["Departamento"] = "ANCASH",
            ["Provincia"] = "SANTA", ["Distrito"] = "CHIMBOTE", ["Localidad"] = "LOCALIDAD QA",
            ["Fecha de elaboración"] = "14/10/2026", ["Fecha de inicio"] = "01/11/2026", ["Fecha de término"] = "31/01/2027",
            ["Duración"] = 3.125m.ToString("0.00", CultureInfo.CurrentCulture) + " MESES", ["Calendario"] = "CALENDARIO QA",
            ["Periodos"] = "PERIODOS QA", ["Modalidad"] = "Administración directa", ["Análisis"] = "Asignación de recursos",
            ["Elaborado por"] = "PROFESIONAL QA", ["Moneda"] = p.Costos.Moneda
        };
        MYGHojaReporteProyecto presupuesto = null;
        foreach (var tipo in Enum.GetValues<MYGTipoReporteProyecto>())
        {
            var reportes = MYGReportesProyecto.Crear(doc, p.Id, tipo);
            Exige(reportes.Count > 0, "El caso institucional debe cubrir el informe " + tipo + ".");
            foreach (var reporte in reportes.Where(r => r.EsPresupuestoObra ? Contiene(r.Hoja, p.Nombre) :
                r.DatosProyecto.Single(d => d.Key == "Presupuesto").Value == p.ToString()))
            {
                Exige(reporte.DatosProyecto.Count == esperados.Count && esperados.All(e =>
                    reporte.DatosProyecto.Single(d => d.Key == e.Key).Value ==
                    (tipo == MYGTipoReporteProyecto.TodosPresupuestos && e.Key == "Presupuesto" ? "" : e.Value)),
                    "Faltan datos completos del proyecto en " + tipo + ".");
                var calculo = new MYGHojaCalculo(reporte.Hoja);
                foreach (var celda in reporte.Hoja.Celdas.Where(c => calculo.Resultado(c.Key).EsNumero))
                    Exige(celda.Value.FormatoNumero.StartsWith(reporte.EsPresupuestoObra ? "#,##0.00" : "0.00", StringComparison.Ordinal) &&
                        celda.Value.AlineacionHorizontal == (reporte.EsPresupuestoObra || reporte.EsAnalisisCostosUnitarios ? "Derecha" : "Centro"),
                        "La cifra " + celda.Key + " del informe " + tipo + " perdió su precisión o su alineación.");
            }
            if (tipo == MYGTipoReporteProyecto.PresupuestoSeleccionado) presupuesto = reportes[0];
        }
        Exige(Datos(doc) == antes, "El formato institucional modificó datos, tasas, códigos o precisión del proyecto.");
        pasa("Los siete tipos de informe conservan datos y dos decimales; presupuesto de obra alinea cifras a la derecha y proyecto deja Presupuesto vacío");

        var h = presupuesto.Hoja;
        Exige(presupuesto.CabeceraImpresion.SequenceEqual(new KeyValuePair<string, string>[]
        {
            new("PROYECTO", doc.Nombre), new("PRESUPUESTO", p.ToString()),
            new("PROPIETARIO", "ENTIDAD PROPIETARIA QA"),
            new("UBICACIÓN", "DPTO: ANCASH  PROV: SANTA  DIST: CHIMBOTE"), new("FECHA DE PROY.", "14/10/2026")
        }), "La cabecera del presupuesto debe mostrar los datos generales en filas y la ubicación unificada de la referencia.");
        int fila = Fila(h, acu.Descripcion);
        var motor = new MYGHojaCalculo(h);
        Exige(motor.Mostrar("A" + fila) == p.Item + ".07.09.10" && h.Celdas["A" + fila].AlineacionHorizontal == "Izquierda" &&
            h.Celdas["B" + fila].AlineacionHorizontal == "Izquierda" && h.Celdas["C" + fila].AlineacionHorizontal == "Centro" &&
            motor.Numero("D" + fila) == 2.1234m && motor.Mostrar("D" + fila) == 2.1234m.ToString("#,##0.00", CultureInfo.CurrentCulture),
            "El informe truncó el código, alteró la precisión del metrado o desalineó sus columnas.");
        Exige(presupuesto.EsPresupuestoObra && h.Celdas["A1"].Contenido == "PRESUPUESTO DE OBRA" &&
            h.Celdas["A2"].ColorFondo == "ECEEF1" && h.Celdas.Values.All(c => c.ColorTexto == "000000") &&
            h.Celdas.Values.All(c => c.Fuente == "Arial" && c.TamanoFuente >= 10),
            "El formato del presupuesto perdió su título, cabecera gris, texto negro o tipografía legible.");
        Exige(new[] { "Ítem", "Descripción", "Unid.", "Cant.", "Precio", "Total" }
            .Select((texto, indice) => motor.Mostrar(MYGHojaCalculo.Columna(indice + 1) + "2") == texto).All(v => v) &&
            motor.Mostrar("A3") == p.Item && motor.Mostrar("B3") == p.Nombre &&
            motor.Numero("F3") == MYGMotorPresupuestos.Resumen(p).CostoDirecto &&
            new[] { "A3", "B3", "F3" }.All(d => h.Celdas[d].Negrita && h.Celdas[d].Subrayado),
            "El presupuesto debe comenzar por su código, nombre y costo directo en negrita subrayada bajo las seis columnas de la referencia.");
        int gastos = Fila(h, "Gastos generales");
        Exige(motor.Numero("E" + gastos) == 10 && motor.Mostrar("E" + gastos) == 10m.ToString("#,##0.00", CultureInfo.CurrentCulture) + " %",
            "El porcentaje del pie no conserva su valor y sus dos decimales.");
        pasa("Presupuesto de obra muestra seis columnas, raíz subrayada con costo directo, cabecera gris y cifras a la derecha sin alterar precisión ni pie");

        var metrado = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.MetradosAceros).Single().Hoja;
        var seleccionado = MYGReportesProyecto.CrearMetrado(doc, p.Id, acero.Id);
        var excel = MYGReportesProyecto.CrearMetradosExcel(doc, p.Id, MYGPlantillasMetrado.Aceros).Single();
        Exige(metrado.Celdas["B3"].Contenido == "2.1234" && metrado.Celdas["AD16"].Contenido == "=B3*3" &&
            metrado.Celdas["B3"].FormatoNumero == "0.00" && new MYGHojaCalculo(metrado).Numero("AD16") == 6.3702m &&
            excel.Celdas["B3"].FormatoNumero == "0.0000" && excel.Celdas["AD16"].Contenido == "=B3*3" && Datos(doc) == antes,
            "La presentación de metrados modificó fórmulas, precisión o el formato de la exportación directa a Excel.");
        Exige(seleccionado.DatosProyecto.SequenceEqual(presupuesto.DatosProyecto) &&
            Datos(seleccionado.Hoja) == Datos(metrado) && seleccionado.Titulo.Contains(p.Item + ".20.03", StringComparison.Ordinal) &&
            !ReferenceEquals(seleccionado.Hoja, acero.Costos.Hoja) && Datos(doc) == antes,
            "Imprimir la partida activa no conserva la misma cabecera, código completo, precisión y aislamiento del informe de metrados.");
        pasa("Dos decimales en la impresión de metrados conserva fórmulas y precisión y deja intacta la exportación directa a Excel");

        var configuracion = new MYGConfiguracionVistaReporte(new[] { presupuesto });
        doc.Datos.Propietario = "EDITADO DESPUES QA";
        doc.Nombre = "EDITADO DESPUES QA";
        configuracion.Fuente("Segoe UI"); configuracion.Escala = 1.25f; configuracion.Restaurar();
        Exige(configuracion.Reportes[0].EsPresupuestoObra && configuracion.Reportes[0].DatosProyecto.SequenceEqual(presupuesto.DatosProyecto) &&
            configuracion.Reportes[0].DatosProyecto.Single(d => d.Key == "Proyecto").Value == esperados["Proyecto"] &&
            configuracion.Reportes[0].DatosProyecto.Single(d => d.Key == "Propietario").Value == esperados["Propietario"] &&
            configuracion.Reportes[0].Hoja.Celdas["A1"].Fuente == "Arial",
            "Restaurar la configuración perdió la cabecera congelada o tomó modificaciones posteriores del proyecto.");
        doc.Datos = null;
        var reporteFaltantes = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado)[0];
        var faltantes = reporteFaltantes.DatosProyecto;
        Exige(faltantes.Single(d => d.Key == "Propietario").Value == "No registrado" &&
            faltantes.Single(d => d.Key == "Fecha de elaboración").Value == "No registrado" &&
            faltantes.Single(d => d.Key == "Duración").Value == "No registrado" &&
            reporteFaltantes.CabeceraImpresion.Single(d => d.Key == "UBICACIÓN").Value ==
                "DPTO: No registrado  PROV: No registrado  DIST: No registrado",
            "El informe inventó datos de proyecto ausentes.");
        pasa("Cabecera queda congelada al crear y restaurar la vista; los datos ausentes se indican sin inventar valores");
    }

    private static void VerificarRendimientoYMonedas(Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("RENDIMIENTO REPORTE QA"); var p = doc.Presupuestos[0];
        var i = Nodo("RENDIMIENTO PARTIDA QA", "01", 1); p.Items.Add(i);
        i.Costos.Cantidad = 3; i.Costos.RendimientoDiario = 4; i.Costos.JornadaHoras = 8;
        var mo = Insumo(p, MYGGrupoRecurso.ManoObra, "MO-R", "CUADRILLA RENDIMIENTO QA", 10);
        var material = Insumo(p, MYGGrupoRecurso.Materiales, "MAT-R", "MATERIAL DESPERDICIO QA", 5);
        var equipo = Insumo(p, MYGGrupoRecurso.Equipo, "EQ-R", "EQUIPO PORCENTAJE MO QA", 1);
        i.Costos.Analisis.Add(new() { Grupo = mo.Grupo, InsumoId = mo.Id, Modo = MYGModoCantidad.Rendimiento,
            NumeroRecursos = 2, Cantidad = 999 });
        i.Costos.Analisis.Add(new() { Grupo = material.Grupo, InsumoId = material.Id, Cantidad = 2, DesperdicioPorcentaje = 10 });
        i.Costos.Analisis.Add(new() { Grupo = equipo.Grupo, InsumoId = equipo.Id, Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 5 });
        string antes = Datos(doc);
        var h = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.AnalisisCostosUnitarios).Single().Hoja;
        FilaConNumeros(h, "CUADRILLA RENDIMIENTO QA", 2m, 4m, 10m, 40m);
        FilaConNumeros(h, "MATERIAL DESPERDICIO QA", 2.2m, 5m, 11m);
        Exige(Contiene(h, "Desperdicio: 10 %"), "El informe debe explicar que la cantidad del material incluye su desperdicio.");
        FilaConNumeros(h, "EQUIPO PORCENTAJE MO QA", 5m, 40m, 2m);
        Exige(Contiene(h, "%mo") && new MYGHojaCalculo(h).Numero(h.CeldaTotal) == 53m && Datos(doc) == antes,
            "El ACU impreso perdió rendimiento/jornada, porcentaje de mano de obra o desperdicio.");
        pasa("ACU calcula cuadrilla por rendimiento/jornada, cantidad con desperdicio y equipo porcentual de mano de obra");

        var otro = new MYGPresupuestoDocumento { Nombre = "PRESUPUESTO DOLARES QA", Item = "02", Posicion = 2 };
        otro.Costos.Moneda = "USD"; var partidaOtra = Nodo("PARTIDA DOLARES QA", "01", 1);
        partidaOtra.Costos.Cantidad = 1; partidaOtra.Costos.PrecioDirecto = 7;
        otro.Items.Add(partidaOtra); doc.Presupuestos.Add(otro); antes = Datos(doc);
        var hojas = MYGReportesProyecto.Crear(doc, p.Id, MYGTipoReporteProyecto.TodosPresupuestos);
        Exige(hojas.Count == 2 && hojas[0].DatosProyecto.Single(d => d.Key == "Moneda").Value == "S/" &&
            hojas[1].DatosProyecto.Single(d => d.Key == "Moneda").Value == "USD",
            "Todos los presupuestos debe imprimir monedas distintas en informes separados con su unidad monetaria.");
        FilaConNumeros(hojas[0].Hoja, "Total", 159m); FilaConNumeros(hojas[1].Hoja, "Total", 7m);
        Exige(Datos(doc) == antes, "Imprimir todos los presupuestos convirtió sus monedas o mezcló los importes.");
        pasa("Imprimir todos los presupuestos conserva monedas distintas en hojas separadas y evita sumar importes incompatibles");
    }
}
