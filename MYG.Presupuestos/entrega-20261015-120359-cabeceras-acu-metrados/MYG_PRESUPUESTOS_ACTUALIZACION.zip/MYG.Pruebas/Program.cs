using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG_2027;

static class Program
{
    private static readonly List<string> Pruebas = new List<string>();
    private static void Igual(bool condicion, string detalle) { if (!condicion) throw new Exception(detalle); }
    private static void Pasa(string prueba) { Pruebas.Add(prueba); Console.WriteLine("OK " + prueba); }
    private static void Rechaza(Action accion, string detalle)
    { bool error = false; try { accion(); } catch (InvalidDataException) { error = true; } Igual(error, detalle); }
    private static ItemPresupuestoDelphin Nodo(string tipo, string nombre, string padre = null, string unidad = "")
    {
        string id = MYGProyectoStorage.NuevoId();
        return new ItemPresupuestoDelphin
        {
            Id = id,
            IdLocalMYG = id,
            IdPropuesta = id,
            ParentId = padre,
            Descripcion = nombre,
            Unidad = unidad,
            TipoPropuesta = tipo,
            Origen = "MODELO",
            Estado = "PROPUESTA",
            Posicion = 1
        };
    }
    private static string Hash(string archivo) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(archivo)));
    private static void SQL(string ruta, string consulta)
    {
        using var c = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta }.ToString());
        c.Open(); using var q = c.CreateCommand(); q.CommandText = consulta; q.ExecuteNonQuery();
    }
    public static void Main()
    {
        string temp = Path.Combine(Path.GetTempPath(), "myg_json_qa_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(temp);
        MYGIndiceLocal.RutaAlternativaPruebas = Path.Combine(temp, "indice_pruebas.json");
        try
        {
            string archivo = Path.Combine(temp, "PROYECTO ; obra.myg.json");
            var doc = MYGProyectoStorage.Nuevo("EDIFICIO A", "ESTRUCTURAS");
            var p = doc.Presupuestos[0];
            MYGProyectoStorage.Guardar(archivo, doc);
            Igual(File.Exists(MYGBaseDatos.RutaDeProyecto(archivo)), "La hoja en blanco no creó su base SQLite MYG.");
            Igual(MYGProyectoStorage.Leer(archivo).Presupuestos[0].Items.Count == 0, "El presupuesto no está vacío.");
            Pasa("Hoja en blanco crea SQLite MYG con catálogos vacíos");

            var titulo = Nodo("TITULO", "CIMENTACIONES");
            var sub = Nodo("TITULO", "ZAPATAS", titulo.Id);
            var concreto = Nodo("PARTIDA", "CONCRETO f'c=210", sub.Id, "m³");
            concreto.IdCatalogoDelphin = "AC-NUEVO"; concreto.FuenteCatalogoId = "BASE-A";
            concreto.FuenteCatalogoRuta = Path.Combine(temp, "delphin ; completo.sqlite");
            concreto.CodigoDelphin = concreto.CodigoCatalogoDelphin = "CON-210";
            concreto.Plantilla = "METRADO DE CONCRETO";
            concreto.Filtros = new List<FiltroPlanificacion>
            {
                new FiltroPlanificacion { Parametro = "STR_TipoDeElemento", Regla = "igual", Valor = "Zapata" },
                new FiltroPlanificacion { Parametro = "GEN_Nivel", Regla = "igual", Valor = "Cimentación" }
            };
            p.CantidadFiltros = 2; p.Items.AddRange(new[] { titulo, sub, concreto });
            var p2 = new MYGPresupuestoDocumento { Nombre = "ARQUITECTURA", Item = "02", Posicion = 2 };
            var muro = Nodo("PARTIDA", "MUROS", null, "m²");
            muro.Filtros.Add(new FiltroPlanificacion { Parametro = "Tipo", Regla = "igual", Valor = "Albañilería" });
            p2.Items.Add(muro); doc.Presupuestos.Add(p2);
            MYGProyectoStorage.Renumerar(p); MYGProyectoStorage.Guardar(archivo, doc);
            var leido = MYGProyectoStorage.Leer(archivo);
            Igual(leido.Presupuestos.Count == 2 && leido.Presupuestos[0].Items[2].Filtros[0].Valor == "Zapata" &&
                leido.Presupuestos[1].Items[0].Filtros[0].Valor == "Albañilería", "Filtros mezclados o incompletos.");
            Igual(leido.Presupuestos[0].Items[2].ParentId == sub.Id && leido.Presupuestos[0].Items[2].IdCatalogoDelphin == "AC-NUEVO",
                "Se perdió la jerarquía o la referencia al catálogo.");
            Pasa("Guardar y reabrir dos presupuestos con toda su jerarquía y filtros independientes");

            string firma = MYGProyectoStorage.Firma(doc);
            doc.PresupuestoActivoId = p2.Id;
            Igual(MYGProyectoStorage.Firma(doc) == firma, "Cambiar la selección produce cambios falsos.");
            concreto.EstadoRevit = "REVISADA"; concreto.MensajeRevit = "Temporal";
            Igual(MYGProyectoStorage.Firma(doc) == firma, "La revisión temporal de Revit se persiste.");
            concreto.Filtros[0].Valor = "Zapata combinada";
            Igual(MYGProyectoStorage.Firma(doc) != firma, "No detectó una edición de otro presupuesto.");
            concreto.Filtros[0].Valor = "Zapata";
            Pasa("Firma completa detecta contenido y omite selección y resultados temporales Revit");

            string local = concreto.IdLocalMYG;
            titulo.Descripcion = "CIMENTACIONES RENOMBRADAS"; concreto.Posicion = 5;
            MYGProyectoStorage.Renumerar(p);
            Igual(concreto.IdLocalMYG == local && concreto.Filtros.Count == 2 && concreto.Item == "01.01.01", "La renumeración perdió identidad.");
            Pasa("Renombrar y renumerar conserva identidades y filtros");

            string anterior = Hash(archivo); MYGProyectoStorage.Guardar(archivo, doc);
            Igual(File.Exists(archivo + ".bak") && Hash(archivo + ".bak") == anterior, "La copia de respaldo es incorrecta.");
            Igual(Directory.GetFiles(temp, "*.tmp").Length == 0, "Quedó un guardado temporal.");
            Pasa("Guardado completo con reemplazo y respaldo de la versión anterior");

            p.Conexion = new MYGConexionDelphin { FuenteId = "BASE-A", ProyectoId = "PR1", PresupuestoId = "PP1", RutaSQLite = concreto.FuenteCatalogoRuta };
            string biblioteca = Path.Combine(temp, "MYG.biblioteca.json");
            MYGProyectoStorage.AgregarPlantilla(biblioteca, "ESTRUCTURAS TÍPICAS", p);
            var copia = MYGProyectoStorage.CopiarComoPlantilla(MYGProyectoStorage.LeerBiblioteca(biblioteca).Plantillas[0].Presupuesto, "OTRA OBRA");
            Igual(copia.Conexion == null && copia.Id != p.Id && copia.IdPresupuestoRevit == copia.Id, "La plantilla conserva el presupuesto anterior.");
            Igual(copia.Items.All(i => i.IdInternoDelphin == null && i.IdAnalisisDelphin == null && i.IdPropuesta == i.Id), "Identidad oficial reutilizada.");
            var copiada = copia.Items.Single(i => i.TipoPropuesta == "PARTIDA");
            Igual(copiada.IdCatalogoDelphin == "AC-NUEVO" && copiada.Filtros.Count == 2 &&
                copia.Items.Any(i => i.Id == copiada.ParentId), "Plantilla perdió referencias o estructura.");
            copiada.Filtros[0].Valor = "Viga";
            Igual(concreto.Filtros[0].Valor == "Zapata", "La copia comparte filtros por referencia.");
            Pasa("Biblioteca reutiliza un presupuesto completo con IDs nuevos y filtros por copia");

            var invalido = MYGProyectoStorage.Copia(p);
            invalido.Items[0].ParentId = invalido.Items[1].Id;
            Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(invalido), "Se aceptó un ciclo.");
            invalido = MYGProyectoStorage.Copia(p); invalido.Items[1].ParentId = invalido.Items[2].Id;
            Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(invalido), "Una partida contiene un título.");
            invalido = MYGProyectoStorage.Copia(p); invalido.Items[2].ParentId = muro.Id;
            Rechaza(() => MYGProyectoStorage.ValidarPresupuesto(invalido), "Se aceptó un padre de otro presupuesto.");
            var futuro = MYGProyectoStorage.Copia(doc); futuro.Version = 99;
            Rechaza(() => MYGProyectoStorage.Validar(futuro), "Se aceptó una versión desconocida.");
            Pasa("Se rechazan ciclos, padres inválidos y versiones desconocidas");

            string db = concreto.FuenteCatalogoRuta;
            SQL(db, @"
                CREATE TABLE proyecto(id_proyecto TEXT PRIMARY KEY,nombre_proyecto TEXT);
                INSERT INTO proyecto VALUES('PR1','EDIFICIO A');
                CREATE TABLE presupuesto(id_presupuesto TEXT PRIMARY KEY,numeracion_presupuesto TEXT,nombre_presupuesto TEXT,
                    posicion_presupuesto INTEGER,id_proyecto TEXT);
                INSERT INTO presupuesto VALUES('PP1','01','ESTRUCTURAS',1,'PR1'),('PP2','02','OTRO PRESUPUESTO',2,'PR1');
                CREATE TABLE analisis_costo(id_analisiscosto TEXT PRIMARY KEY,descripcion_analisiscosto TEXT,
                    codigo_clase TEXT,codigo_subclase TEXT,codigo_listaprecio TEXT,unidad TEXT);
                INSERT INTO analisis_costo VALUES
                    ('AC-EXISTE','ENCOFRADO','01','01','ENC-01','m²'),
                    ('AC-NUEVO','CONCRETO f''c=210','01','02','CON-210','m³'),
                    ('AC-OTRO','ACERO EN OTRA OBRA','01','03','AC-01','kg');
                CREATE TABLE costo_unitario(id_costounitario TEXT PRIMARY KEY,id_costopadre TEXT,numeracion_costo TEXT,
                    descripcion_costo TEXT,posicion_costo INTEGER,id_analisiscosto TEXT,id_presupuesto TEXT);
                INSERT INTO costo_unitario VALUES
                    ('T-OFICIAL',NULL,'03','CONCRETO ARMADO',1,NULL,'PP1'),
                    ('CU-EXISTE','T-OFICIAL','03.01','ENCOFRADO',1,'AC-EXISTE','PP1'),
                    ('CU-OTRO',NULL,'01','ACERO EN OTRA OBRA',1,'AC-OTRO','PP2');
                ");
            string hashDb = Hash(db);
            var catalogo = LectorDelphin.LeerCatalogoPartidasSQLite(db);
            var oficiales = LectorDelphin.LeerItemsPresupuestoSQLite(db, "PP1");
            Igual(catalogo.Count == 3 && catalogo.Any(i => i.Id == "AC-NUEVO") && catalogo.Any(i => i.Id == "AC-OTRO"), "Catálogo limitado al presupuesto.");
            Igual(oficiales.Count == 2 && oficiales.Single(i => i.Id == "CU-EXISTE").IdAnalisisDelphin == "AC-EXISTE" &&
                oficiales.Single(i => i.Id == "CU-EXISTE").Unidad == "m²", "ID o unidad de la fila incorrectos.");
            Igual(Hash(db) == hashDb, "El lector modificó el SQL de Delphin.");
            Pasa("Lector SQL real consulta el catálogo fuera del presupuesto y conserva IDs distintos sin escribir");

            string acSolo = Path.Combine(temp, "solo catalogo.sqlite");
            SQL(acSolo, @"CREATE TABLE analisis_costo(id_analisiscosto TEXT,descripcion TEXT,codigo TEXT,unidad TEXT);
                INSERT INTO analisis_costo VALUES('A1','PARTIDA SIN USO','CAT-01','m');");
            Igual(LectorDelphin.LeerCatalogoPartidasSQLite(acSolo).Single().Unidad == "m", "Catálogo sin costo_unitario no funciona.");
            string acFallback = Path.Combine(temp, "descripcion en presupuesto.sqlite");
            SQL(acFallback, @"CREATE TABLE analisis_costo(id_analisiscosto TEXT,codigo_listaprecio TEXT,unidad TEXT);
                INSERT INTO analisis_costo VALUES('A1','CAT-01','m');
                CREATE TABLE costo_unitario(id_costounitario TEXT,id_analisiscosto TEXT,descripcion_costo TEXT);
                INSERT INTO costo_unitario VALUES('CU1','A1','PARTIDA DE RESPALDO');");
            Igual(LectorDelphin.LeerCatalogoPartidasSQLite(acFallback).Single().Descripcion == "PARTIDA DE RESPALDO",
                "No se recuperó la descripción disponible en costo_unitario.");
            Pasa("Catálogo adapta nombres de descripción y admite análisis sin costo_unitario");

            string ambitoProyecto = doc.IdProyectoRevit; string ambitoPresupuesto = p.IdPresupuestoRevit;
            var informe = MYGProyectoStorage.ActualizarDesdeDelphin(p, oficiales);
            Igual(p.Items.Any(i => i.Id == concreto.Id && i.Filtros.Count == 2) && informe.Nuevas == 2, "Conectar perdió propuestas.");
            Igual(doc.IdProyectoRevit == ambitoProyecto && p.IdPresupuestoRevit == ambitoPresupuesto, "El vínculo cambió el ámbito Revit.");
            Pasa("Conectar la hoja conserva propuestas, filtros y ámbitos Revit persistentes");
            var obras = new[] { "COPIA A", "COPIA B" }.Select(nombre =>
            {
                var obra = new MYGProyectoDocumento { Nombre = nombre };
                var presupuestoSql = new MYGPresupuestoDocumento { Nombre = "ESTRUCTURAS", Conexion = MYGProyectoStorage.Copia(p.Conexion) };
                MYGProyectoStorage.ActualizarDesdeDelphin(presupuestoSql, LectorDelphin.LeerItemsPresupuestoSQLite(db, "PP1"));
                obra.Presupuestos.Add(presupuestoSql); obra.PresupuestoActivoId = presupuestoSql.Id;
                MYGProyectoStorage.Validar(obra); return obra;
            }).ToArray();
            Igual(obras[0].IdProyectoRevit != obras[1].IdProyectoRevit &&
                obras[0].Presupuestos[0].IdPresupuestoRevit != obras[1].Presupuestos[0].IdPresupuestoRevit &&
                obras.All(o => o.Presupuestos[0].Conexion.PresupuestoId == "PP1" && o.Presupuestos[0].Items.Any(i => i.IdInternoDelphin == "CU-EXISTE")),
                "Se confunden los ámbitos de dos proyectos que usan los mismos IDs oficiales.");
            string archivoAmbito = Path.Combine(temp, "Otro proyecto mismo presupuesto.myg.json");
            MYGProyectoStorage.Guardar(archivoAmbito, obras[0]);
            Igual(MYGProyectoStorage.Leer(archivoAmbito).IdProyectoRevit == obras[0].IdProyectoRevit, "Al reabrir cambia el ámbito del proyecto.");
            Pasa("Dos proyectos con los mismos IDs Delphin conservan ámbitos MYG distintos y persistentes para sus tablas");

            SQL(db, "INSERT INTO costo_unitario VALUES('CU-NUEVO','T-OFICIAL','03.02','CONCRETO EN ZAPATAS',2,'AC-NUEVO','PP1');");
            MYGProyectoStorage.ActualizarDesdeDelphin(p, LectorDelphin.LeerItemsPresupuestoSQLite(db, "PP1"));
            var propuesta = p.Items.Single(i => i.Id == concreto.Id);
            var oficial = p.Items.Single(i => i.Id == "CU-NUEVO");
            Igual(MYGProyectoStorage.ReferenciaCatalogoExacta(propuesta, oficial, "BASE-A"), "No reconoce el mismo catálogo por ID.");
            Igual(!MYGProyectoStorage.ReferenciaCatalogoExacta(propuesta, oficial, "BASE-B"), "Cruza bases diferentes por un mismo ID.");
            var otraUnidad = MYGProyectoStorage.Copia(oficial); otraUnidad.Unidad = "m²";
            Igual(!MYGProyectoStorage.ReferenciaCatalogoExacta(propuesta, otraUnidad, "BASE-A"), "Vincula automáticamente unidades incompatibles.");
            MYGProyectoStorage.Vincular(propuesta, oficial); p.Items.Remove(propuesta);
            Igual(oficial.IdLocalMYG == local && oficial.IdInternoDelphin == "CU-NUEVO" && oficial.IdCatalogoDelphin == "AC-NUEVO" &&
                oficial.Filtros[0].Valor == "Zapata" && oficial.Plantilla == "METRADO DE CONCRETO", "Vincular perdió configuración.");
            Pasa("Reconciliación por origen e ID de análisis conserva identidad local, plantilla y filtros");

            var segundoUso = Nodo("PARTIDA", "CONCRETO EN VIGAS", titulo.Id, "m³");
            segundoUso.IdCatalogoDelphin = "AC-NUEVO"; segundoUso.FuenteCatalogoId = "BASE-A";
            segundoUso.Filtros.Add(new FiltroPlanificacion { Parametro = "STR_TipoDeElemento", Regla = "igual", Valor = "Viga" });
            p.Items.Add(segundoUso); MYGProyectoStorage.ValidarPresupuesto(p);
            Igual(oficial.Filtros[0].Valor == "Zapata" && segundoUso.Filtros[0].Valor == "Viga" && oficial.IdLocalMYG != segundoUso.IdLocalMYG,
                "Dos usos del catálogo comparten sus filtros.");
            Pasa("Una entrada del catálogo puede tener varios usos con filtros independientes");

            var otroOficial = MYGProyectoStorage.Copia(oficial); otroOficial.Id = "OTRA-FILA";
            Igual(MYGProyectoStorage.VinculoAutomatico(segundoUso, new[] { segundoUso }, new[] { oficial, otroOficial }, "BASE-A") == null,
                "Eligió arbitrariamente entre dos filas oficiales del mismo análisis.");
            Igual(MYGProyectoStorage.VinculoAutomatico(segundoUso, new[] { segundoUso, propuesta }, new[] { oficial }, "BASE-A") == null,
                "Eligió arbitrariamente entre dos usos propuestos del catálogo.");
            Igual(MYGProyectoStorage.VinculoAutomatico(segundoUso, new[] { segundoUso }, new[] { oficial }, "BASE-A") == oficial,
                "No acepta una correspondencia única.");
            Pasa("La reconciliación automática rechaza correspondencias ambiguas en ambas direcciones");

            var desvinculadas = MYGProyectoStorage.DesvincularComoPropuestas(p);
            Igual(desvinculadas.Any(i => i.IdLocalMYG == local && i.Id == local && i.Filtros[0].Valor == "Zapata") &&
                desvinculadas.All(i => i.IdInternoDelphin == null && i.IdAnalisisDelphin == null), "Cambiar de origen pierde identidad local.");
            string estadoPrevio = JsonSerializer.Serialize(p);
            var ciclicos = new List<ItemPresupuestoDelphin>
            {
                new ItemPresupuestoDelphin { Id = "CICLO-A", ParentId = "CICLO-B", TipoPropuesta = "TITULO" },
                new ItemPresupuestoDelphin { Id = "CICLO-B", ParentId = "CICLO-A", TipoPropuesta = "TITULO" }
            };
            Rechaza(() => MYGProyectoStorage.ActualizarDesdeDelphin(p, ciclicos), "Se aceptó un SQL circular.");
            Igual(JsonSerializer.Serialize(p) == estadoPrevio, "Una actualización fallida cambió la estructura anterior.");
            Pasa("Cambiar de origen conserva identidad local y una actualización inválida no sustituye el presupuesto");

            SQL(db, "UPDATE costo_unitario SET numeracion_costo='03.09',descripcion_costo='CONCRETO ACTUALIZADO' WHERE id_costounitario='CU-NUEVO';");
            MYGProyectoStorage.ActualizarDesdeDelphin(p, LectorDelphin.LeerItemsPresupuestoSQLite(db, "PP1"));
            oficial = p.Items.Single(i => i.Id == "CU-NUEVO");
            Igual(oficial.Item == "03.09" && oficial.IdLocalMYG == local && oficial.Filtros[0].Valor == "Zapata", "Actualizar perdió vínculo.");
            MYGProyectoStorage.Guardar(archivo, doc);
            Igual(MYGProyectoStorage.Leer(archivo).Presupuestos[0].Items.Single(i => i.Id == "CU-NUEVO").Filtros[0].Valor == "Zapata",
                "Reabrir el presupuesto reconciliado perdió los filtros.");
            Pasa("Actualizar y reabrir después de reconciliar mantiene filtros ante cambio de numeración");

            SQL(db, "UPDATE analisis_costo SET unidad='m²' WHERE id_analisiscosto='AC-NUEVO';");
            informe = MYGProyectoStorage.ActualizarDesdeDelphin(p, LectorDelphin.LeerItemsPresupuestoSQLite(db, "PP1"));
            Igual(informe.Avisos.Count == 1, "No informa un cambio de unidad oficial con filtros configurados.");
            SQL(db, "DELETE FROM costo_unitario WHERE id_presupuesto='PP1';");
            informe = MYGProyectoStorage.ActualizarDesdeDelphin(p, LectorDelphin.LeerItemsPresupuestoSQLite(db, "PP1"));
            Igual(informe.Ausentes == 3 && p.Items.Any(i => i.IdLocalMYG == local && i.Filtros[0].Valor == "Zapata" &&
                i.IdInternoDelphin == null), "Eliminar la partida oficial pierde el trabajo.");
            MYGProyectoStorage.ValidarPresupuesto(p);
            Pasa("Cambios de unidad se informan y filas desaparecidas conservan jerarquía y filtros como propuestas");

            MYGProyectoStorage.Guardar(archivo, doc); MYGIndiceLocal.Registrar(doc, archivo);
            Igual(MYGIndiceLocal.Asociados(db, "PR1").Contains(archivo) &&
                MYGIndiceLocal.Asociados(db, "PROYECTO_AJENO").Count == 0 && MYGIndiceLocal.Recientes().Contains(archivo),
                "La asociación automática no está limitada al proyecto.");
            Pasa("Índice recupera el JSON asociado al origen y proyecto y conserva accesos recientes");

            CatalogosCheck.Ejecutar(temp, Pasa);
            BaseProyectosCheck.Ejecutar(temp, Pasa);
            EstructuraPresupuestosCheck.Ejecutar(temp, Pasa);
            PiePresupuestoCheck.Ejecutar(temp, Pasa);
            EdicionPartidaCheck.Ejecutar(temp, Pasa);
            HojaMetradoCheck.Ejecutar(temp, Pasa);
            PlantillasMetradoCheck.Ejecutar(temp, Pasa);
            ActualizacionMetradoHojaCheck.Ejecutar(Pasa);
            AlertasPartidaCheck.Ejecutar(temp, Pasa);
            ArrastreHojaCheck.Ejecutar(temp, Pasa);
            ReferenciasFormulaHojaCheck.Ejecutar(Pasa);
            EleccionReferenciaFormulaHojaCheck.Ejecutar(Pasa);
            OrdenPresupuestosCheck.Ejecutar(temp, Pasa);
            ArrastrePresupuestosCheck.Ejecutar(temp, Pasa);
            InsumosEdicionCheck.Ejecutar(temp, Pasa);
            RefrescoDiferidoCheck.Ejecutar(Pasa);
            EspecificacionesZoomCheck.Ejecutar(Pasa);
            EspecificacionesPegadoCheck.Ejecutar(Pasa);
            RendimientoCalculoCheck.Ejecutar(temp, Pasa);
            DelphinSQLiteCheck.Ejecutar(temp, Pasa);
            DelphinEdicionCheck.Ejecutar(temp, Pasa);
            DatosProyectoCheck.Ejecutar(temp, Pasa);
            BibliotecaPartidasCheck.Ejecutar(temp, Pasa);
            EspecificacionesPaginaCheck.Ejecutar(temp, Pasa);
            EspecificacionesExportacionCheck.Ejecutar(Pasa);
            CargarDataCheck.Ejecutar(temp, Pasa);
            LicenciaProtocoloCheck.EjecutarAsync(Pasa).GetAwaiter().GetResult();
            ContenidoPartidaCheck.Ejecutar(temp, Pasa);
            EspecificacionBorradorPersistenciaCheck.Ejecutar(temp, Pasa);
            ReferenciasMetradoPartidasCheck.Ejecutar(temp, Pasa);
            ReferenciasCortasCheck.Ejecutar(temp, Pasa);
            ExportacionReferenciasExcelCheck.Ejecutar(temp, Pasa);
            ReportesProyectoCheck.Ejecutar(temp, Pasa);
            ReportesExportacionCheck.Ejecutar(temp, Pasa);
            ReportesExcelCheck.Ejecutar(temp, Pasa);
            ReporteMetradosExcelCheck.Ejecutar(temp, Pasa);
            LibroPresupuestoExcelCheck.Ejecutar(temp, Pasa);
            ConfiguracionVistaReporteCheck.Ejecutar(Pasa);
            File.WriteAllText(Path.Combine(AppContext.BaseDirectory, "resultado_qa.json"), JsonSerializer.Serialize(new
            {
                Pruebas = Pruebas,
                Total = Pruebas.Count,
                Ejecucion = "Código C# real de la entrega, .NET 10 y SQLite",
                JSONAntiguo = string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("MYG_QA_LEGACY_JSON")) ? "Datos sintéticos de compatibilidad" : "Archivo antiguo externo indicado por MYG_QA_LEGACY_JSON",
                Limite = "SQLite de prueba, filtros y respuestas de licencia simuladas; no ejecuta Windows, Revit ni el servicio de licencias en producción."
            }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine("PRUEBAS COMPLETADAS: " + Pruebas.Count);
        }
        finally { MYGIndiceLocal.RutaAlternativaPruebas = null; Directory.Delete(temp, true); }
    }
}

