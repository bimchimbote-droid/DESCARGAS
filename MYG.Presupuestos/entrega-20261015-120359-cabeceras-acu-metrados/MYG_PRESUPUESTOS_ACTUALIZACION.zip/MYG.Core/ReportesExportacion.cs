using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace MYG_2027;

public enum MYGFormatoExportacionReporte { Html, Mht, Rtf, Xlsx, Csv, Texto }

/// <summary>Exporta copias de los informes y sus valores visibles, sin cambiar
/// las hojas del proyecto. Cada archivo se sustituye sólo al terminar de escribir.</summary>
public static class MYGReportesExportacion
{
    public static void Guardar(string ruta, MYGFormatoExportacionReporte formato,
        IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique el archivo de destino.", nameof(ruta));
        if (!Enum.IsDefined(formato)) throw new ArgumentOutOfRangeException(nameof(formato));
        var copias = new MYGConfiguracionVistaReporte(reportes).Reportes;
        foreach (var reporte in copias) MYGHojaCalculo.Validar(reporte.Hoja);
        if (formato == MYGFormatoExportacionReporte.Xlsx)
        {
            MYGExcelPresupuestos.Guardar(ruta, MYGReportesExcel.CrearHojas(copias));
            return;
        }
        var tablas = copias.Select(r => new Tabla(r)).ToArray();
        string contenido = formato switch
        {
            MYGFormatoExportacionReporte.Html => Html(tablas),
            MYGFormatoExportacionReporte.Mht => Mht(Html(tablas)),
            MYGFormatoExportacionReporte.Rtf => Rtf(tablas),
            MYGFormatoExportacionReporte.Csv => Delimitado(tablas, true),
            MYGFormatoExportacionReporte.Texto => Delimitado(tablas, false),
            _ => throw new ArgumentOutOfRangeException(nameof(formato))
        };
        string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            File.WriteAllText(temporal, contenido, new UTF8Encoding(formato == MYGFormatoExportacionReporte.Csv));
            File.Move(temporal, ruta, true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    private sealed record Region(int F1, int C1, int F2, int C2)
    {
        internal static Region Leer(string rango)
        {
            var partes = MYGEdicionHoja.NormalizarRango(rango).Split(':');
            var a = MYGHojaCalculo.Coordenadas(partes[0]);
            var b = MYGHojaCalculo.Coordenadas(partes[^1]);
            return new(a.Fila, a.Columna, b.Fila, b.Columna);
        }
        internal string Direccion => MYGHojaCalculo.Columna(C1) + F1;
    }

    private sealed class Tabla
    {
        internal readonly MYGHojaReporteProyecto Reporte;
        internal MYGHojaMetrado Hoja => Reporte.Hoja;
        internal readonly int[] Filas, Columnas;
        internal readonly Dictionary<(int, int), Region> Combinaciones = new();
        private readonly MYGHojaCalculo motor;
        internal Tabla(MYGHojaReporteProyecto reporte)
        {
            Reporte = reporte; motor = new(reporte.Hoja);
            var coordenadas = Hoja.Celdas.Keys.Select(MYGHojaCalculo.Coordenadas).ToArray();
            var combinaciones = Hoja.RangosCombinados.Select(Region.Leer).ToArray();
            var area = string.IsNullOrWhiteSpace(Hoja.AreaImpresion)
                ? new Region(1, 1,
                    Math.Max(coordenadas.Select(c => c.Fila).DefaultIfEmpty(1).Max(), combinaciones.Select(c => c.F2).DefaultIfEmpty(1).Max()),
                    Math.Max(coordenadas.Select(c => c.Columna).DefaultIfEmpty(1).Max(), combinaciones.Select(c => c.C2).DefaultIfEmpty(1).Max()))
                : Region.Leer(Hoja.AreaImpresion);
            var ocultas = Hoja.FilasOcultas.ToHashSet();
            // La cabecera institucional ya contiene el título de la primera fila.
            if (!reporte.CabeceraEnHoja && reporte.DatosProyecto.Count > 0 && area.F1 == 1 &&
                Hoja.Celdas.TryGetValue("A1", out var a1) &&
                (reporte.EsPresupuestoObra || string.Equals(a1.Contenido, reporte.Titulo.Split(" · ")[0], StringComparison.OrdinalIgnoreCase)) &&
                combinaciones.Any(c => c.F1 == 1 && c.F2 == 1 && c.C1 == area.C1 && c.C2 == area.C2)) ocultas.Add(1);
            Filas = Enumerable.Range(area.F1, area.F2 - area.F1 + 1).Where(f => !ocultas.Contains(f)).ToArray();
            Columnas = Enumerable.Range(area.C1, area.C2 - area.C1 + 1).ToArray();
            foreach (var region in combinaciones)
                foreach (int f in Filas.Where(f => f >= region.F1 && f <= region.F2))
                    foreach (int c in Columnas.Where(c => c >= region.C1 && c <= region.C2))
                        Combinaciones.Add((f, c), region);
        }
        internal string Direccion(int f, int c) => Combinaciones.TryGetValue((f, c), out var region)
            ? region.Direccion : MYGHojaCalculo.Columna(c) + f;
        internal bool EsPrimera(int f, int c) => !Combinaciones.TryGetValue((f, c), out var region) ||
            f == Filas.First(x => x >= region.F1) && c == Columnas.First(x => x >= region.C1);
        internal string Texto(int f, int c) => motor.Mostrar(Direccion(f, c));
        internal MYGCeldaHoja Estilo(int f, int c) => Hoja.Celdas.GetValueOrDefault(Direccion(f, c)) ?? new MYGCeldaHoja();
        internal bool EsNumero(int f, int c)
        {
            try { return motor.Resultado(Direccion(f, c)).EsNumero; }
            catch (Exception ex) when (ex is FormatException || ex is InvalidDataException || ex is DivideByZeroException || ex is OverflowException)
            { return false; }
        }
        internal int Ancho(int c) => Hoja.AnchosColumnas.GetValueOrDefault(c, c == 1 ? 288 : c == 8 ? 110 : 68);
    }

    private static string Titulo(MYGHojaReporteProyecto r) => r.EsPresupuestoObra ? "PRESUPUESTO DE OBRA"
        : r.EsAnalisisCostosUnitarios ? "Análisis de Costos Unitarios" : r.Titulo;
    private static string HtmlTexto(string t) => WebUtility.HtmlEncode(t ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Replace("\n", "<br />");
    private static string Color(string color) => color?.Length == 6 && color.All(Uri.IsHexDigit) ? color.ToUpperInvariant() : "";
    private static string Decimal(decimal n) => n.ToString(CultureInfo.InvariantCulture);

    private static string Html(IReadOnlyList<Tabla> tablas)
    {
        var s = new StringBuilder("<!DOCTYPE html>\r\n<html lang=\"es\"><head><meta charset=\"utf-8\" /><title>Informes del proyecto</title><style>");
        s.Append("body{font-family:Arial,sans-serif;color:#000;background:#fff}section{margin:0 0 2em;break-after:page}section:last-child{break-after:auto}h1{text-align:center;font-size:16pt}dl{display:grid;grid-template-columns:max-content auto;gap:4px 12px}dt{font-weight:bold}dd{margin:0}table{border-collapse:collapse;table-layout:fixed}td,th{padding:4px;overflow-wrap:anywhere;white-space:pre-wrap}th{font-size:9pt;color:#555}@media print{body{margin:0}}");
        s.Append("</style></head><body>");
        foreach (var tabla in tablas)
        {
            s.Append("<section>");
            if (!tabla.Reporte.CabeceraEnHoja)
            {
                s.Append("<h1>").Append(HtmlTexto(Titulo(tabla.Reporte))).Append("</h1><dl>");
                foreach (var dato in tabla.Reporte.CabeceraImpresion)
                    s.Append("<dt>").Append(HtmlTexto(dato.Key)).Append("</dt><dd>").Append(HtmlTexto(dato.Value)).Append("</dd>");
                s.Append("</dl>");
            }
            s.Append("<table><colgroup>");
            if (tabla.Hoja.ImprimirEncabezados) s.Append("<col style=\"width:40px\" />");
            foreach (int c in tabla.Columnas) s.Append("<col style=\"width:").Append(tabla.Ancho(c)).Append("px\" />");
            s.Append("</colgroup><tbody>");
            if (tabla.Hoja.ImprimirEncabezados)
            {
                s.Append("<tr><th></th>");
                foreach (int c in tabla.Columnas) s.Append("<th>").Append(MYGHojaCalculo.Columna(c)).Append("</th>");
                s.Append("</tr>");
            }
            foreach (int f in tabla.Filas)
            {
                s.Append("<tr style=\"height:").Append(tabla.Hoja.AltosFilas.GetValueOrDefault(f, 24)).Append("px\">");
                if (tabla.Hoja.ImprimirEncabezados) s.Append("<th>").Append(f).Append("</th>");
                foreach (int c in tabla.Columnas)
                {
                    if (!tabla.EsPrimera(f, c)) continue;
                    s.Append("<td");
                    if (tabla.Combinaciones.TryGetValue((f, c), out var region))
                        s.Append(" rowspan=\"").Append(tabla.Filas.Count(x => x >= region.F1 && x <= region.F2))
                            .Append("\" colspan=\"").Append(tabla.Columnas.Count(x => x >= region.C1 && x <= region.C2)).Append('"');
                    var estilo = tabla.Estilo(f, c);
                    s.Append(" style=\"font-family:'").Append(WebUtility.HtmlEncode((estilo.Fuente ?? MYGCeldaHoja.FuentePredeterminada).Replace("\\", "\\\\").Replace("'", "\\'")))
                        .Append("';font-size:").Append(Decimal(estilo.TamanoFuente)).Append("pt;text-align:")
                        .Append(estilo.AlineacionHorizontal == "Derecha" ? "right" : estilo.AlineacionHorizontal == "Centro" ? "center" : "left")
                        .Append(";vertical-align:").Append(estilo.AlineacionVertical == "Arriba" ? "top" : estilo.AlineacionVertical == "Abajo" ? "bottom" : "middle");
                    if (estilo.Negrita) s.Append(";font-weight:bold");
                    if (estilo.Cursiva) s.Append(";font-style:italic");
                    if (estilo.Subrayado || estilo.Tachado) s.Append(";text-decoration:").Append(estilo.Subrayado ? "underline " : "").Append(estilo.Tachado ? "line-through" : "");
                    if (Color(estilo.ColorTexto) is { Length: 6 } tinta) s.Append(";color:#").Append(tinta);
                    if (Color(estilo.ColorFondo) is { Length: 6 } fondo) s.Append(";background-color:#").Append(fondo);
                    if (estilo.Bordes || tabla.Hoja.ImprimirLineasDivision) s.Append(";border:1px solid #bbb");
                    s.Append("\">").Append(HtmlTexto(tabla.Texto(f, c))).Append("</td>");
                }
                s.Append("</tr>");
            }
            s.Append("</tbody></table></section>");
        }
        return s.Append("</body></html>").ToString();
    }

    private static string Mht(string html)
    {
        string separador = "----MYG_" + Guid.NewGuid().ToString("N");
        string base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(html), Base64FormattingOptions.InsertLineBreaks);
        return "MIME-Version: 1.0\r\nContent-Type: multipart/related; type=\"text/html\"; boundary=\"" + separador +
            "\"\r\n\r\n--" + separador + "\r\nContent-Type: text/html; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\nContent-Location: informe.html\r\n\r\n" +
            base64 + "\r\n--" + separador + "--\r\n";
    }

    private static string Delimitado(IReadOnlyList<Tabla> tablas, bool csv)
    {
        var s = new StringBuilder();
        string Campo(string valor, bool numero = false)
        {
            valor ??= "";
            if (!csv) return valor.Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
            // El texto procede de datos de usuario: Excel no debe ejecutarlo
            // como fórmula al abrir un CSV. Los números calculados se conservan.
            string inicio = valor.TrimStart(' ', '\t', '\r', '\n');
            if (!numero && inicio.Length > 0 && "=+-@".Contains(inicio[0])) valor = "'" + valor;
            return "\"" + valor.Replace("\"", "\"\"") + "\"";
        }
        void Fila(IEnumerable<string> valores) => s.AppendJoin(csv ? ',' : '\t', valores).Append("\r\n");
        for (int i = 0; i < tablas.Count; i++)
        {
            var tabla = tablas[i];
            if (i > 0) s.Append("\r\n");
            if (!tabla.Reporte.CabeceraEnHoja)
            {
                Fila(new[] { Campo(Titulo(tabla.Reporte)) });
                foreach (var dato in tabla.Reporte.CabeceraImpresion) Fila(new[] { Campo(dato.Key), Campo(dato.Value) });
            }
            if (tabla.Hoja.ImprimirEncabezados) Fila(new[] { Campo("") }.Concat(tabla.Columnas.Select(c => Campo(MYGHojaCalculo.Columna(c)))));
            foreach (int f in tabla.Filas)
            {
                var valores = tabla.Columnas.Select(c => Campo(tabla.EsPrimera(f, c) ? tabla.Texto(f, c) : "", tabla.EsNumero(f, c)));
                if (tabla.Hoja.ImprimirEncabezados) valores = new[] { Campo(f.ToString(CultureInfo.InvariantCulture), true) }.Concat(valores);
                Fila(valores);
            }
        }
        return s.ToString();
    }

    private static string RtfTexto(string texto)
    {
        var s = new StringBuilder();
        foreach (char c in (texto ?? "").Replace("\r\n", "\n").Replace('\r', '\n'))
        {
            if (c is '\\' or '{' or '}') s.Append('\\').Append(c);
            else if (c == '\n') s.Append("\\line ");
            else if (c == '\t') s.Append("\\tab ");
            else if (c >= 32 && c < 127) s.Append(c);
            else s.Append("\\u").Append(unchecked((short)c).ToString(CultureInfo.InvariantCulture)).Append('?');
        }
        return s.ToString();
    }

    private static string Rtf(IReadOnlyList<Tabla> tablas)
    {
        var estilos = tablas.SelectMany(t => t.Hoja.Celdas.Values).ToArray();
        var fuentes = new[] { MYGCeldaHoja.FuentePredeterminada }.Concat(estilos.Select(e => e.Fuente ?? MYGCeldaHoja.FuentePredeterminada)).Distinct().ToArray();
        var colores = estilos.SelectMany(e => new[] { Color(e.ColorTexto), Color(e.ColorFondo) }).Where(c => c.Length == 6).Distinct().ToArray();
        var s = new StringBuilder("{\\rtf1\\ansi\\ansicpg1252\\deff0\\uc1{\\fonttbl");
        for (int i = 0; i < fuentes.Length; i++) s.Append("{\\f").Append(i).Append(' ').Append(RtfTexto(fuentes[i].Replace(';', ' '))).Append(";}");
        s.Append("}{\\colortbl;");
        foreach (string color in colores)
            s.Append("\\red").Append(Convert.ToInt32(color[..2], 16)).Append("\\green").Append(Convert.ToInt32(color.Substring(2, 2), 16))
                .Append("\\blue").Append(Convert.ToInt32(color.Substring(4, 2), 16)).Append(';');
        s.Append('}');
        int ColorIndice(string color) => Array.IndexOf(colores, Color(color)) + 1;
        for (int i = 0; i < tablas.Count; i++)
        {
            var tabla = tablas[i];
            // Cada informe conserva su papel, orientación y márgenes, aunque
            // el archivo contenga hojas con configuraciones diferentes.
            decimal papel = tabla.Hoja.TamanoPapel switch { "A3" => 11.69m, "Carta" or "Oficio" => 8.5m, _ => 8.27m };
            decimal alto = tabla.Hoja.TamanoPapel switch { "A3" => 16.54m, "Carta" => 11m, "Oficio" => 14m, _ => 11.69m };
            if (tabla.Hoja.OrientacionPagina == "Horizontal") (papel, alto) = (alto, papel);
            if (i > 0) s.Append("\\sect ");
            s.Append("\\sectd\\sbkpage\\pgwsxn").Append((int)(papel * 1440)).Append("\\pghsxn").Append((int)(alto * 1440))
                .Append("\\marglsxn").Append((int)(tabla.Hoja.MargenIzquierdo * 1440))
                .Append("\\margrsxn").Append((int)(tabla.Hoja.MargenDerecho * 1440))
                .Append("\\margtsxn").Append((int)(tabla.Hoja.MargenSuperior * 1440))
                .Append("\\margbsxn").Append((int)(tabla.Hoja.MargenInferior * 1440));
            if (tabla.Hoja.OrientacionPagina == "Horizontal") s.Append("\\lndscpsxn");
            if (!tabla.Reporte.CabeceraEnHoja)
            {
                s.Append("\\pard\\qc\\b\\fs28 ").Append(RtfTexto(Titulo(tabla.Reporte))).Append("\\par ");
                foreach (var dato in tabla.Reporte.CabeceraImpresion)
                    s.Append("\\pard\\ql\\fs18\\b ").Append(RtfTexto(dato.Key)).Append(": \\b0 ").Append(RtfTexto(dato.Value)).Append("\\par ");
            }
            // Las tablas se ajustan al ancho imprimible del papel elegido.
            int ancho = Math.Max(720, (int)((papel - tabla.Hoja.MargenIzquierdo - tabla.Hoja.MargenDerecho) * 1440));
            double suma = tabla.Columnas.Sum(c => (double)tabla.Ancho(c));
            foreach (int f in tabla.Filas)
            {
                s.Append("\\trowd\\trgaph60");
                double acumulado = 0;
                foreach (int c in tabla.Columnas)
                {
                    var estilo = tabla.Estilo(f, c);
                    if (tabla.Combinaciones.TryGetValue((f, c), out var region))
                    {
                        int primeroC = tabla.Columnas.First(x => x >= region.C1), primeroF = tabla.Filas.First(x => x >= region.F1);
                        if (region.C2 > primeroC) s.Append(c == primeroC ? "\\clmgf" : "\\clmrg");
                        if (tabla.Filas.Count(x => x >= region.F1 && x <= region.F2) > 1) s.Append(f == primeroF ? "\\clvmgf" : "\\clvmrg");
                    }
                    s.Append(estilo.AlineacionVertical == "Arriba" ? "\\clvertalt" : estilo.AlineacionVertical == "Abajo" ? "\\clvertalb" : "\\clvertalc");
                    if (ColorIndice(estilo.ColorFondo) > 0) s.Append("\\clcbpat").Append(ColorIndice(estilo.ColorFondo));
                    if (estilo.Bordes || tabla.Hoja.ImprimirLineasDivision)
                        s.Append("\\clbrdrt\\brdrs\\brdrw5\\clbrdrl\\brdrs\\brdrw5\\clbrdrb\\brdrs\\brdrw5\\clbrdrr\\brdrs\\brdrw5");
                    acumulado += tabla.Ancho(c);
                    s.Append("\\cellx").Append((int)Math.Round(acumulado / suma * ancho));
                }
                foreach (int c in tabla.Columnas)
                {
                    var estilo = tabla.Estilo(f, c);
                    s.Append("\\pard\\intbl\\f").Append(Array.IndexOf(fuentes, estilo.Fuente ?? MYGCeldaHoja.FuentePredeterminada))
                        .Append("\\fs").Append((int)(estilo.TamanoFuente * 2)).Append("\\b").Append(estilo.Negrita ? '1' : '0')
                        .Append("\\i").Append(estilo.Cursiva ? '1' : '0').Append(estilo.Subrayado ? "\\ul" : "\\ulnone")
                        .Append("\\strike").Append(estilo.Tachado ? '1' : '0').Append("\\cf").Append(ColorIndice(estilo.ColorTexto))
                        .Append(estilo.AlineacionHorizontal == "Derecha" ? "\\qr " : estilo.AlineacionHorizontal == "Centro" ? "\\qc " : "\\ql ");
                    if (tabla.EsPrimera(f, c)) s.Append(RtfTexto(tabla.Texto(f, c)));
                    s.Append("\\cell ");
                }
                s.Append("\\row\r\n");
            }
            s.Append("\\pard\\par ");
        }
        return s.Append('}').ToString();
    }
}
