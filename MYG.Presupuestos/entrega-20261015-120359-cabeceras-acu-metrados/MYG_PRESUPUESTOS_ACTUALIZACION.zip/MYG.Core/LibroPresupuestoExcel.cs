using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

/// <summary>Prepara el libro completo de un presupuesto con sus informes,
/// tablas auxiliares y metrados Excel consolidados, sin alterar el proyecto.</summary>
public static class MYGLibroPresupuestoExcel
{
    public static IReadOnlyList<MYGHojaMetrado> Crear(MYGProyectoDocumento documento, string presupuestoId)
    {
        ArgumentNullException.ThrowIfNull(documento);
        var proyecto = MYGProyectoStorage.Copia(documento);
        MYGProyectoStorage.Validar(proyecto);
        string id = string.IsNullOrWhiteSpace(presupuestoId) ? proyecto.PresupuestoActivoId : presupuestoId;
        var presupuesto = proyecto.Presupuestos.FirstOrDefault(p => string.Equals(p.Id, id, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("Seleccione un presupuesto del proyecto para exportar.");
        var reportes = new List<MYGHojaReporteProyecto>();
        reportes.AddRange(MYGReportesProyecto.Crear(proyecto, presupuesto.Id, MYGTipoReporteProyecto.PresupuestoSeleccionado));
        reportes.AddRange(MYGReportesProyecto.Crear(proyecto, presupuesto.Id, MYGTipoReporteProyecto.HojaResumen));
        reportes.AddRange(MYGReportesProyecto.Crear(proyecto, presupuesto.Id, MYGTipoReporteProyecto.AnalisisCostosUnitarios));
        var cabecera = reportes[0].CabeceraImpresion;
        var auxiliares = new[]
        {
            MYGExcelPresupuestos.Tabla("Insumos", new[] { "Grupo", "Código", "Descripción", "Unidad", "Precio" },
                presupuesto.Costos.Insumos.Select(i => new object[] { MYGMotorPresupuestos.Grupo(i.Grupo), i.Codigo, i.Descripcion, i.Unidad, i.Precio })),
            MYGExcelPresupuestos.Tabla("Consolidado", new[] { "Grupo", "Código", "Descripción", "Unidad", "Cantidad", "Precio", "Total" },
                MYGMotorPresupuestos.Consolidar(presupuesto).Select(i => new object[] { MYGMotorPresupuestos.Grupo(i.Grupo), i.Codigo, i.Descripcion, i.Unidad, i.Cantidad, i.Precio, i.Total })),
            MYGExcelPresupuestos.Tabla("Metrados manuales", new[] { "Ítem", "Partida", "Descripción", "Elementos", "Cant. x Elem.", "Largo", "Ancho", "Alto", "Descuento", "Parcial", "Referencia", "Imagen" },
                presupuesto.Items.SelectMany(i => i.Costos.Metrados.Select(m => new object[] { i.Item, i.Descripcion, m.Descripcion, m.Elementos, m.CantidadPorElemento, m.Largo, m.Ancho, m.Alto, m.Descuento, MYGMotorPresupuestos.Parcial(m), m.Referencia, m.ImagenRuta }))),
            MYGExcelPresupuestos.Tabla("Metrados BIM", new[] { "Ítem", "Partida", "Activo", "Tabla", "Unidad", "Cantidad", "Fecha UTC" },
                presupuesto.Items.SelectMany(i => i.Costos.MetradosBIM.Select(m => new object[] { i.Item, i.Descripcion, m.ActivoId, m.Tabla, m.Unidad, m.Cantidad, m.FechaUtc.ToString("O") })))
        };
        foreach (var hojaAuxiliar in auxiliares)
        {
            int[] monetarias = hojaAuxiliar.Nombre switch
            {
                "Insumos" => new[] { 5 }, "Consolidado" => new[] { 6, 7 }, _ => Array.Empty<int>()
            };
            foreach (var celda in hojaAuxiliar.Celdas)
            {
                var coordenada = MYGHojaCalculo.Coordenadas(celda.Key);
                if (coordenada.Fila > 1 && monetarias.Contains(coordenada.Columna)) celda.Value.FormatoNumero = "#,##0.00";
            }
            reportes.Add(new MYGHojaReporteProyecto(hojaAuxiliar.Nombre, hojaAuxiliar, cabecera));
        }
        if (presupuesto.Items.Any(i => !MYGProyectoStorage.EsTitulo(i) && i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel && i.Costos.Hoja != null))
            reportes.Add(MYGReporteMetradosExcel.Crear(proyecto, presupuesto.Id));
        return MYGReportesExcel.CrearHojas(reportes);
    }
}
