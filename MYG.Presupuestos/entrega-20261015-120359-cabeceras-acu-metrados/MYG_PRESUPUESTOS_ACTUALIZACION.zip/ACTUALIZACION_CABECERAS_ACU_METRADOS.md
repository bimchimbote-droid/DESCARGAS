# Actualización: cabeceras Excel, formato de ACU y metrados en una hoja

## Base de aplicación

Esta entrega es incremental y se aplica sobre la actualización anterior de exportación/fondos, publicada en DESCARGAS en el commit `1d9b6ece60d22259aec3b38df0aa4c3e76f76922`.
Repositorio del código: `bimchimbote-droid/MYG.Presupuestos`; rama de origen `main`, commit base `13c43d52c2ea227a0d773eaa417f3195ae98f93e`. Se comprobó que main seguía en ese commit al comenzar. La rama local del entorno es `work`; no se ha hecho commit ni push del código.

## Comportamiento

### Cabeceras de los libros Excel

XLSX y XLS incluyen título y los datos generales visibles en la vista preliminar: proyecto, presupuesto, propietario, ubicación y fecha según el informe. Se convierten en celdas combinadas con altura para textos largos. No se inventan datos de las imágenes; se usan los del proyecto y se indica «No registrado» cuando faltan.

La inserción reubica fórmulas, referencias absolutas, anclas, rangos, estilos y dimensiones sobre copias. Los informes que ya tienen cabecera en celdas no la duplican. Se conserva la configuración existente de impresión del libro; no se añadió una nueva regla de repetición de todas las filas de cabecera en cada página de Excel.

El libro completo conserva presupuesto, resumen, ACU, insumos, consolidado, metrados manuales y BIM, con sus datos generales. Si hay hojas Excel activas, agrega los metrados consolidados. Las tablas auxiliares siguen disponibles.

### Análisis de Costos Unitarios

Las partidas se muestran consecutivamente con la cabecera institucional, código y descripción, rendimiento, costo unitario y siete columnas: Código Alt., Descripción, Unid., Recursos, Cant., Precio y Parcial. Los grupos tienen subtotales y se conservan otros grupos y subpartidas. El desperdicio se aplica a la cantidad efectiva y se documenta debajo del recurso cuando corresponde. Se preservan jornada, moneda y diferencias por precios nativos de Delphin.

La exportación del ACU individual utiliza el mismo generador que el informe completo. Un conjunto que supera el límite de filas se distribuye en más de una hoja sin perder partidas.

### Vista de metrados tipo Excel

Antes de guardar se abre una ventana de consulta con cinta Archivo/Inicio/Vista, barra de dirección y fórmulas, encabezados de columnas y números de fila, selección/copia, búsqueda, zoom y una pestaña Metrados. Es una vista de solo lectura de una copia; no cambia el proyecto original.

La hoja contiene cabecera de proyecto, presupuesto, propietario, localidad, distrito, provincia, departamento y fecha. Debajo se agregan filas de presupuesto, títulos de la jerarquía y código/nombre de cada partida, seguidas por su metrado. Se incluyen las partidas cuya fuente activa es Excel. Las hojas guardadas pero inactivas no se añaden.

- Exportar metrados completos: reúne los presupuestos del proyecto.
- Metrados (Formato DE Excel): utiliza el presupuesto activo.
- Las opciones de acero y por plantilla mantienen su filtro.
- Guardar como de la hoja de una partida mantiene el alcance de esa partida.
- Exportar XLS/XLSX desde la vista preliminar de metrados abre la nueva vista antes de guardar; la impresión normal conserva sus reportes de metrados manuales y BIM.

Guardar como produce el libro mostrado, en una sola hoja. XLSX no requiere Excel; XLS utiliza Excel instalado. La vista puede abrir el diálogo de impresión/PDF existente. En E-Mail, después de guardar y volver, se prepara el correo con el archivo guardado.

Los anchos diferentes se representan con una rejilla común y celdas combinadas, aproximando los límites de columnas a una resolución de ocho píxeles. Se conservan estilos, filas ocultas, fórmulas locales y vínculos entre partidas incluidas. Las dependencias excluidas por selección o las fórmulas cuyo significado cambia al reunir hojas se materializan con el resultado calculado, para conservar las cifras del informe. Los errores se mantienen como errores; no se sustituyen por cero.

La hoja consolidada respeta los límites del motor: 10 000 filas, 200 columnas y 200 000 celdas. Si la selección los supera, se informa del límite sin truncar datos; utilice el presupuesto activo o un filtro de plantilla.

## Instalación manual

1. Cierre MYG y respalde o confirme sus cambios locales en Visual Studio.
2. Verifique que tiene aplicada la entrega anterior de exportación/fondos. Descargue y extraiga este ZIP en una carpeta temporal.
3. Copie los archivos a la raíz de su checkout conservando sus rutas. Cree los nuevos y reemplace los existentes indicados en la tabla de entrega. Compare primero los reemplazos si tiene modificaciones locales o posteriores a la base.
4. Los proyectos SDK incluyen automáticamente los archivos .cs nuevos; no modifique las referencias del .csproj. No hay eliminaciones ni parches que aplicar.
5. Restaure, compile y pruebe desde la raíz:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

La propiedad UseRevitReferencePackages permite compilar sin Revit instalado, con los paquetes de referencia ya admitidos por el proyecto. En Windows puede usar las DLL locales de Revit 2027 conforme a LEEME.md.

Para las pruebas de interfaz, en Windows:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

## Requisitos y comprobación manual

Se usa C#, SDK .NET 10.0.100, WinForms/WPF y SQLite. No se añaden paquetes NuGet ni cambios de esquema de bases de datos. No se modifican bases existentes.

- XLS requiere Microsoft Excel instalado; XLSX no lo requiere.
- PDF conserva el requisito de Microsoft Print to PDF.
- E-Mail conserva el requisito de cliente Simple MAPI x64.
- Linux permite compilar la interfaz, pero para ejecutarla se requiere Windows Desktop Runtime .NET 10. La sesión real de Revit 2027 requiere Windows y Revit instalado.

En Windows, revisar un proyecto con nombre largo: cabecera en cada hoja Excel, ACU individual y completo, rendimiento y precios, grupos/subtotales y desperdicios. Probar metrados de dos presupuestos con títulos anidados, hojas estándar/acero/importadas, vínculos, filas ocultas y nombres multilínea. Verificar selección, barra de fórmulas, copia, zoom y una sola pestaña; guardar XLSX/XLS y comparar sus datos con la vista. Comprobar impresión/PDF y correo con sus componentes instalados.

## Publicación del código por el usuario

En Visual Studio abra Cambios de Git, revise el diff y confirme la rama main. Haga Commit, luego Push y compruebe el commit en GitHub. La publicación del ZIP en el repositorio independiente DESCARGAS no aplica estos cambios al proyecto ni publica el código por usted.

## Validación realizada en esta entrega

- Los cinco proyectos de la solución compilaron en Release con SDK .NET 10.0.100: 0 errores y 0 advertencias.
- La suite MYG.Pruebas completó 350 pruebas aprobadas, incluidas cabeceras, ACU, metrados consolidados, referencias entre presupuestos, regresión de fórmulas dependientes y guardar/reabrir el libro completo.
- Named Pipes de Windows se omitió explícitamente. Las pruebas UI se compilaron, pero no se ejecutaron en Linux.
- Pendientes de ejecución en Windows: apariencia de la nueva ventana, selección/copia/zoom, diálogos, salida XLS con Excel, PDF con controlador y correo MAPI. La integración real con Revit no se ejecutó.

## Archivos de esta entrega

| N.º | Ruta | Acción |
|---|---|---|
| 1 | `ACTUALIZACION_CABECERAS_ACU_METRADOS.md` | CREAR |
| 2 | `MYG.Core/ConfiguracionVistaReporte.cs` | REEMPLAZAR |
| 3 | `MYG.Core/LibroPresupuestoExcel.cs` | CREAR |
| 4 | `MYG.Core/MYGReporteMetradosExcel.cs` | CREAR |
| 5 | `MYG.Core/ReportesExcel.cs` | CREAR |
| 6 | `MYG.Core/ReportesExportacion.cs` | REEMPLAZAR |
| 7 | `MYG.Core/ReportesProyectoMYG.cs` | REEMPLAZAR |
| 8 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR |
| 9 | `MYG.Desktop/PresupuestosExcelImpresion.cs` | REEMPLAZAR |
| 10 | `MYG.Desktop/PresupuestosExcelPanel.cs` | REEMPLAZAR |
| 11 | `MYG.Desktop/PresupuestosExportacionExcel.cs` | CREAR |
| 12 | `MYG.Desktop/PresupuestosHerramientasPanel.cs` | REEMPLAZAR |
| 13 | `MYG.Desktop/ReportesExportacionWindows.cs` | REEMPLAZAR |
| 14 | `MYG.Desktop/ReportesImpresion.cs` | REEMPLAZAR |
| 15 | `MYG.Desktop/VistaMetradosExcelForm.cs` | CREAR |
| 16 | `MYG.Desktop/VistaPreliminarReportesForm.cs` | REEMPLAZAR |
| 17 | `MYG.Pruebas/LibroPresupuestoExcelCheck.cs` | CREAR |
| 18 | `MYG.Pruebas/Program.cs` | REEMPLAZAR |
| 19 | `MYG.Pruebas/ReporteMetradosExcelCheck.cs` | CREAR |
| 20 | `MYG.Pruebas/ReportesExcelCheck.cs` | CREAR |
| 21 | `MYG.Pruebas/ReportesExportacionCheck.cs` | REEMPLAZAR |
| 22 | `MYG.Pruebas/ReportesProyectoCheck.cs` | REEMPLAZAR |
| 23 | `MYG.PruebasUI/Program.cs` | REEMPLAZAR |
| 24 | `MYG.PruebasUI/VistaMetradosExcelCheck.cs` | CREAR |
