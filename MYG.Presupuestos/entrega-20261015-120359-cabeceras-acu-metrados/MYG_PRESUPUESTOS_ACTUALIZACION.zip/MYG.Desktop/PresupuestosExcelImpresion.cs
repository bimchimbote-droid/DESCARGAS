using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private void MargenesHoja()
    {
        var h = actual.Costos.Hoja;
        using var d = new MYGCamposProyectoForm("Márgenes", new[] { "Izquierdo (pulgadas)", "Derecho (pulgadas)", "Superior (pulgadas)", "Inferior (pulgadas)" },
            new[] { h.MargenIzquierdo.ToString(CultureInfo.InvariantCulture), h.MargenDerecho.ToString(CultureInfo.InvariantCulture), h.MargenSuperior.ToString(CultureInfo.InvariantCulture), h.MargenInferior.ToString(CultureInfo.InvariantCulture) });
        if (d.ShowDialog(this) != DialogResult.OK) return;
        var valores = d.Valores.Select(x => MYGHojaCalculo.IntentarNumero(x, out var n) && n >= 0 && n <= 3 ? n : throw new InvalidOperationException("Indique márgenes entre 0 y 3 pulgadas.")).ToArray();
        EditarVistaHoja(x => { x.MargenIzquierdo = valores[0]; x.MargenDerecho = valores[1]; x.MargenSuperior = valores[2]; x.MargenInferior = valores[3]; });
    }
    private void ImprimirHoja(bool vistaPrevia, bool rapida = false)
    {
        RequerirPartida(); FinalizarEdicion();
        var proyecto = obtenerProyectoEstructura?.Invoke();
        if (proyecto != null && P != null)
        {
            var reporte = MYGReportesProyecto.CrearMetrado(proyecto, P.Id, actual.Id);
            MYGReportesImpresion.Imprimir(this, reporte.Titulo, new[] { reporte }, () => reporte);
            return;
        }
        var h = MYGProyectoStorage.Copia(actual.Costos.Hoja);
        string titulo = "Metrados · " + (P?.Nombre ?? "") + " · " + (P == null ? actual.Item : CodigoEstructura(P, actual)) + " " + actual.Descripcion;
        // También Imprimir y la acción rápida pasan por la configuración previa.
        var reporteLocal = new MYGHojaReporteProyecto(titulo, h);
        MYGReportesImpresion.Imprimir(this, titulo, new[] { reporteLocal }, () => reporteLocal);
    }
}
