using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Conversiones que requieren aplicaciones instaladas en Windows.</summary>
internal static class MYGReportesExportacionWindows
{
    private const string RequisitoExcel = "Para exportar un libro XLS (Excel 97-2003) se necesita Microsoft Excel instalado en Windows. También puede exportar XLSX sin Excel.";

    internal static void GuardarXls(string ruta, IReadOnlyList<MYGHojaReporteProyecto> reportes)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(ruta);
        ArgumentNullException.ThrowIfNull(reportes);
        if (!string.Equals(Path.GetExtension(ruta), ".xls", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("El libro Excel 97-2003 debe tener extensión .xls.", nameof(ruta));
        if (reportes.Count == 0) throw new InvalidOperationException("El informe no contiene hojas para exportar.");
        var hojas = MYGReportesExcel.CrearHojas(reportes);
        if (hojas.Any(h => h.Filas > 65536 || h.Columnas > 256))
            throw new InvalidOperationException("El formato XLS admite hasta 65 536 filas y 256 columnas por hoja. Exporte este informe como XLSX para conservar todos sus datos.");

        var tipo = Type.GetTypeFromProgID("Excel.Application");
        if (tipo == null) throw new InvalidOperationException(RequisitoExcel);
        var destino = Path.GetFullPath(ruta);
        var identificador = Guid.NewGuid().ToString("N");
        var origen = Path.Combine(Path.GetTempPath(), "MYG-Reporte-" + identificador + ".xlsx");
        var convertido = Path.Combine(Path.GetDirectoryName(destino)!, ".MYG-Reporte-" + identificador + ".xls");
        object aplicacion = null, libros = null, libro = null;
        try
        {
            MYGExcelPresupuestos.Guardar(origen, hojas);
            try { aplicacion = Activator.CreateInstance(tipo); }
            catch (COMException ex) when (ex.HResult == unchecked((int)0x80040154))
            {
                throw new InvalidOperationException(RequisitoExcel, ex);
            }
            dynamic excel = aplicacion;
            excel.Visible = false;
            excel.DisplayAlerts = false;
            excel.EnableEvents = false;
            excel.AutomationSecurity = 3; // msoAutomationSecurityForceDisable.
            libros = excel.Workbooks;
            libro = ((dynamic)libros).Open(Filename: origen, UpdateLinks: 0, ReadOnly: true,
                IgnoreReadOnlyRecommended: true, AddToMru: false);
            ((dynamic)libro).CheckCompatibility = false;
            ((dynamic)libro).SaveAs(Filename: convertido, FileFormat: 56, CreateBackup: false,
                AddToMru: false); // xlExcel8: BIFF8 real, nunca XLSX renombrado.
            CerrarExcel(ref libro, ref libros, ref aplicacion);
            ValidarLibroXls(convertido);
            File.Move(convertido, destino, overwrite: true);
        }
        finally
        {
            CerrarExcel(ref libro, ref libros, ref aplicacion);
            EliminarTemporal(origen);
            EliminarTemporal(convertido);
        }
    }

    /// <summary>Abre el editor del cliente de correo; el usuario decide enviar o cancelar.</summary>
    internal static void PrepararCorreo(IWin32Window owner, string asunto, IReadOnlyList<string> archivos)
    {
        ArgumentNullException.ThrowIfNull(archivos);
        var rutas = archivos.Select(Path.GetFullPath).ToArray();
        foreach (var ruta in rutas)
            if (!File.Exists(ruta)) throw new FileNotFoundException("No se encuentra el archivo que se adjuntará al correo.", ruta);

        IntPtr adjuntos = IntPtr.Zero;
        int inicializados = 0;
        int tamano = Marshal.SizeOf<ArchivoMapi>();
        try
        {
            if (rutas.Length > 0)
            {
                adjuntos = Marshal.AllocHGlobal(checked(tamano * rutas.Length));
                foreach (var ruta in rutas)
                {
                    var archivo = new ArchivoMapi
                    {
                        Posicion = uint.MaxValue, Ruta = ruta, Nombre = Path.GetFileName(ruta)
                    };
                    Marshal.StructureToPtr(archivo, IntPtr.Add(adjuntos, tamano * inicializados), false);
                    inicializados++;
                }
            }
            var mensaje = new MensajeMapi
            {
                Asunto = asunto ?? "Informe MYG Presupuestos",
                CantidadArchivos = checked((uint)rutas.Length), Archivos = adjuntos
            };
            uint resultado;
            try
            {
                const uint MapiLogonUi = 0x00000001, MapiDialog = 0x00000008;
                resultado = MAPISendMailW(IntPtr.Zero, owner?.Handle ?? IntPtr.Zero, ref mensaje,
                    MapiLogonUi | MapiDialog, 0);
            }
            catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException or BadImageFormatException)
            {
                throw new InvalidOperationException(RequisitoCorreo, ex);
            }
            // MAPI_USER_ABORT: cerrar el editor sin enviar es un resultado normal.
            if (resultado != 0 && resultado != 1)
                throw new InvalidOperationException(ErrorCorreo(resultado));
        }
        finally
        {
            if (adjuntos != IntPtr.Zero)
            {
                for (int n = 0; n < inicializados; n++)
                    Marshal.DestroyStructure<ArchivoMapi>(IntPtr.Add(adjuntos, tamano * n));
                Marshal.FreeHGlobal(adjuntos);
            }
        }
    }

    private const string RequisitoCorreo = "No se pudo abrir el cliente de correo. Configure en Windows un cliente predeterminado compatible con Simple MAPI y con la arquitectura de MYG (64 bits), como Outlook clásico de 64 bits. También puede exportar el informe y adjuntarlo manualmente.";

    private static string ErrorCorreo(uint codigo) => codigo switch
    {
        3 => "El cliente de correo no pudo iniciar sesión. Abra y configure su cuenta en el cliente predeterminado y vuelva a intentar.",
        6 => "El cliente de correo denegó el acceso. Revise sus permisos y vuelva a intentar; también puede adjuntar el informe exportado manualmente.",
        9 or 28 => "El cliente de correo no admite el número o tamaño de los archivos adjuntos. Exporte un informe más pequeño o adjúntelo manualmente.",
        11 or 12 or 13 => "El cliente de correo no pudo leer o adjuntar el informe. Exporte el archivo y adjúntelo manualmente.",
        23 => "El cliente de correo informó un problema de conexión. Revise su conexión y la configuración de su cuenta.",
        _ => RequisitoCorreo + " Código MAPI: " + codigo + "."
    };

    private static void ValidarLibroXls(string ruta)
    {
        byte[] firmaOle = { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 };
        using var archivo = File.OpenRead(ruta);
        Span<byte> firma = stackalloc byte[8];
        if (archivo.Read(firma) != firma.Length || !firma.SequenceEqual(firmaOle))
            throw new IOException("Microsoft Excel no generó un libro XLS válido. Exporte el informe como XLSX.");
    }

    private static void CerrarExcel(ref object libro, ref object libros, ref object aplicacion)
    {
        if (libro != null)
        {
            try { ((dynamic)libro).Close(SaveChanges: false); } catch (Exception) { }
            LiberarCom(ref libro);
        }
        LiberarCom(ref libros);
        if (aplicacion != null)
        {
            try { ((dynamic)aplicacion).Quit(); } catch (Exception) { }
            LiberarCom(ref aplicacion);
        }
    }

    private static void LiberarCom(ref object objeto)
    {
        try { if (objeto != null && Marshal.IsComObject(objeto)) Marshal.FinalReleaseComObject(objeto); }
        catch (InvalidComObjectException) { }
        finally { objeto = null; }
    }

    private static void EliminarTemporal(string ruta)
    {
        try { File.Delete(ruta); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct MensajeMapi
    {
        public uint Reservado;
        [MarshalAs(UnmanagedType.LPWStr)] public string Asunto;
        [MarshalAs(UnmanagedType.LPWStr)] public string Texto;
        [MarshalAs(UnmanagedType.LPWStr)] public string Tipo;
        [MarshalAs(UnmanagedType.LPWStr)] public string Fecha;
        [MarshalAs(UnmanagedType.LPWStr)] public string Conversacion;
        public uint Indicadores;
        public IntPtr Remitente;
        public uint CantidadDestinatarios;
        public IntPtr Destinatarios;
        public uint CantidadArchivos;
        public IntPtr Archivos;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct ArchivoMapi
    {
        public uint Reservado;
        public uint Indicadores;
        public uint Posicion;
        [MarshalAs(UnmanagedType.LPWStr)] public string Ruta;
        [MarshalAs(UnmanagedType.LPWStr)] public string Nombre;
        public IntPtr Tipo;
    }

    [DllImport("MAPI32.DLL", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern uint MAPISendMailW(IntPtr sesion, IntPtr ventana, ref MensajeMapi mensaje,
        uint indicadores, uint reservado);
}
