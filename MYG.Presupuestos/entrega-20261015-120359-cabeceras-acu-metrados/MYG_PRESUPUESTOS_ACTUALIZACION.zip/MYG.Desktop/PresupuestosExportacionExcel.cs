using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private MYGProyectoDocumento ProyectoParaExportacionExcel() => obtenerProyectoEstructura?.Invoke() ?? new MYGProyectoDocumento
    {
        Nombre = P?.Nombre ?? "Proyecto",
        PresupuestoActivoId = P?.Id,
        Presupuestos = PresupuestosEstructura.ToList()
    };

    // El libro completo conserva sus tablas auxiliares, usando el mismo presupuesto,
    // resumen y ACU que la vista preliminar. La preparación trabaja sobre copias.
    internal IReadOnlyList<MYGHojaMetrado> CrearLibroPresupuestoParaExportar()
    {
        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto para exportar.");
        return MYGLibroPresupuestoExcel.Crear(ProyectoParaExportacionExcel(), P.Id);
    }
}
