using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

/// <summary>Libro de consulta para revisar y guardar todos los metrados en una
/// sola hoja. La hoja visible es una instantánea; no edita el proyecto abierto.</summary>
internal sealed class MYGVistaMetradosExcelForm : Form
{
    private readonly string nombreDocumento;
    private readonly bool preferirXls;
    private readonly MYGHojaMetrado hoja;
    private readonly MYGHojaReporteProyecto reporteVisible;
    private readonly MYGHojaCalculo motor;
    private readonly DataGridView grilla = new()
    {
        Name = "vista_metrados_excel_hoja", Dock = DockStyle.Fill, ReadOnly = true,
        AllowUserToAddRows = false, AllowUserToDeleteRows = false, AllowUserToOrderColumns = false,
        AutoGenerateColumns = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
        SelectionMode = DataGridViewSelectionMode.CellSelect, MultiSelect = true,
        VirtualMode = true, ClipboardCopyMode = DataGridViewClipboardCopyMode.Disable,
        BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false,
        RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing,
        ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
    };
    private readonly TabControl cinta = new() { Name = "vista_metrados_excel_cinta", Dock = DockStyle.Top, Height = 145 };
    private readonly TextBox direccion = new() { Name = "vista_metrados_excel_direccion", Dock = DockStyle.Fill, AccessibleName = "Celda o rango de celdas" };
    private readonly TextBox formula = new() { Name = "vista_metrados_excel_formula", Dock = DockStyle.Fill, ReadOnly = true, AccessibleName = "Contenido o fórmula de la celda seleccionada" };
    private readonly Label estado = new() { Name = "vista_metrados_excel_estado", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0) };
    private readonly TrackBar deslizador = new() { Name = "vista_metrados_excel_zoom", Minimum = 25, Maximum = 300, Value = 100, TickStyle = TickStyle.None, AutoSize = false, Width = 150, Height = 26 };
    private readonly Label porcentaje = new() { Name = "vista_metrados_excel_porcentaje", TextAlign = ContentAlignment.MiddleRight, Width = 48, Height = 26 };
    private readonly Dictionary<string, Font> fuentes = new();
    private readonly Dictionary<string, DataGridViewCellStyle> estilos = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<(int Fila, int Columna), Rango> combinaciones = new();
    private readonly HashSet<Rango> combinacionesSeleccionadas = new();
    private readonly ContextMenuStrip menu = new();
    private bool mostrandoFormulas, cargando;

    private readonly record struct Rango(int Fila, int Columna, int FilaFinal, int ColumnaFinal);

    internal MYGHojaMetrado HojaVisible => hoja;
    internal MYGHojaReporteProyecto ReporteVisible => reporteVisible;
    internal string ArchivoGuardado { get; private set; }

    internal MYGVistaMetradosExcelForm(string nombre, MYGHojaReporteProyecto reporte, bool preferirXls = false)
    {
        ArgumentNullException.ThrowIfNull(reporte);
        nombreDocumento = string.IsNullOrWhiteSpace(nombre) ? "Metrados" : nombre;
        this.preferirXls = preferirXls;
        // El mismo materializador sirve al Excel de los demás informes. Incluso
        // si el informe ya lleva su cabecera, esta copia conserva el aislamiento.
        hoja = MYGReportesExcel.CrearHojas(new[] { reporte }).Single();
        hoja.Nombre = "Metrados";
        MYGHojaCalculo.Validar(hoja);
        motor = new MYGHojaCalculo(hoja);
        reporteVisible = new MYGHojaReporteProyecto(reporte.Titulo, hoja, reporte.DatosProyecto, cabeceraEnHoja: true);
        foreach (string combinado in hoja.RangosCombinados)
        {
            var r = LeerRango(combinado);
            for (int f = r.Fila; f <= r.FilaFinal; f++)
                for (int c = r.Columna; c <= r.ColumnaFinal; c++) combinaciones[(f, c)] = r;
        }

        Name = "vista_metrados_excel";
        Text = "Metrados · " + nombreDocumento;
        AutoScaleDimensions = new SizeF(96, 96);
        AutoScaleMode = AutoScaleMode.Dpi;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1280, 850); MinimumSize = new Size(860, 600);
        WindowState = FormWindowState.Maximized;
        Font = Fuente("Segoe UI", 9, FontStyle.Regular);
        BackColor = MYG2027_TemaComercial.Superficie;
        KeyPreview = true;

        PrepararCinta();
        PrepararGrilla();
        var pestanas = new TabControl { Name = "vista_metrados_excel_pestanas", Dock = DockStyle.Bottom, Height = 28 };
        pestanas.TabPages.Add(new TabPage("Metrados"));
        MYGTemaPestanas.Preparar(pestanas);
        var pie = new Panel { Name = "vista_metrados_excel_pie", Dock = DockStyle.Bottom, Height = 30 };
        var zoom = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 262, WrapContents = false, Padding = new Padding(0, 1, 0, 0) };
        var menos = new Button { Name = "vista_metrados_excel_alejar_pie", Text = "−", Width = 28, Height = 26, Margin = Padding.Empty };
        var mas = new Button { Name = "vista_metrados_excel_acercar_pie", Text = "+", Width = 28, Height = 26, Margin = Padding.Empty };
        menos.Click += (_, _) => CambiarZoom(hoja.Zoom - 10);
        mas.Click += (_, _) => CambiarZoom(hoja.Zoom + 10);
        deslizador.ValueChanged += (_, _) => { if (!cargando) CambiarZoom(deslizador.Value); };
        zoom.Controls.Add(porcentaje); zoom.Controls.Add(menos); zoom.Controls.Add(deslizador); zoom.Controls.Add(mas);
        pie.Controls.Add(estado); pie.Controls.Add(zoom);

        Controls.Add(grilla); Controls.Add(pestanas); Controls.Add(pie);
        Controls.Add(PrepararFormula()); Controls.Add(cinta);
        AplicarDimensiones();
        ActualizarFormula();
        KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Escape) { e.SuppressKeyPress = true; Close(); }
            else if (e.Control && e.KeyCode == Keys.S) { e.SuppressKeyPress = true; Intentar(GuardarComo); }
            else if (e.Control && e.KeyCode == Keys.P) { e.SuppressKeyPress = true; Intentar(VistaImpresion); }
            else if (e.Control && e.KeyCode == Keys.F) { e.SuppressKeyPress = true; Intentar(Buscar); }
        };
        DpiChanged += (_, _) => AplicarDimensiones();
    }

    private void PrepararCinta()
    {
        MYGEspecificacionesCinta.Preparar(cinta);
        var archivo = MYGEspecificacionesCinta.Pagina(cinta, "Archivo");
        Grupo(archivo, "Navegación", Boton("Volver al\nproyecto", "volver", "xls_volver", Close));
        Grupo(archivo, "Libro Excel", Boton("Guardar\ncomo", "guardar", "guardar", GuardarComo));
        Grupo(archivo, "Imprimir", Boton("Vista previa /\nimprimir / PDF", "imprimir", "xls_previa", VistaImpresion, 110));
        Grupo(archivo, "Portapapeles", Boton("Copiar", "copiar_archivo", "copiar", Copiar));
        var inicio = MYGEspecificacionesCinta.Pagina(cinta, "Inicio");
        Grupo(inicio, "Portapapeles", Boton("Copiar", "copiar", "copiar", Copiar),
            Boton("Seleccionar\ntodo", "seleccionar_todo", "xls_bordes", () => grilla.SelectAll(), 90));
        Grupo(inicio, "Buscar", Boton("Buscar", "buscar", "buscar", Buscar));
        var vista = MYGEspecificacionesCinta.Pagina(cinta, "Vista");
        Grupo(vista, "Zoom", Boton("Alejar", "alejar", "zoom_menos", () => CambiarZoom(hoja.Zoom - 10)),
            Boton("100 %", "zoom_100", "zoom", () => CambiarZoom(100)),
            Boton("Acercar", "acercar", "zoom_mas", () => CambiarZoom(hoja.Zoom + 10)));
        var formulas = Boton("Mostrar\nfórmulas", "formulas", "xls_formulas", () =>
        {
            mostrandoFormulas = !mostrandoFormulas;
            grilla.Invalidate();
        }, 90);
        formulas.CheckOnClick = true;
        Grupo(vista, "Fórmulas", formulas);
        MYGEspecificacionesCinta.AplicarTema(cinta);
    }

    private ToolStripButton Boton(string texto, string nombre, string icono, Action accion, int ancho = 76)
    {
        var boton = new ToolStripButton(texto)
        {
            Name = "vista_metrados_excel_" + nombre, AutoSize = false, Width = ancho, Height = 78,
            ToolTipText = texto.Replace('\n', ' '), AccessibleName = texto.Replace('\n', ' ')
        };
        MYGEspecificacionesCinta.Icono(boton, icono,
            icono.StartsWith("xls_", StringComparison.Ordinal) ? MYGExcelCintaIconos.Dibujar : MYGVistaPreliminarCintaIconos.Dibujar, 32, true);
        boton.Click += (_, _) => Intentar(accion);
        return boton;
    }

    private static void Grupo(FlowLayoutPanel padre, string titulo, params ToolStripItem[] botones)
    {
        var grupo = MYGEspecificacionesCinta.Grupo(padre, titulo, botones.Sum(b => b.Width + 2) + 10);
        MYGEspecificacionesCinta.Fila(grupo, 2, botones);
    }

    private Control PrepararFormula()
    {
        var barra = new TableLayoutPanel
        {
            Name = "vista_metrados_excel_barra_formula", Dock = DockStyle.Top, Height = 32,
            ColumnCount = 3, RowCount = 1, Padding = new Padding(2, 4, 2, 3), BackColor = MYG2027_TemaComercial.AzulSuave
        };
        barra.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
        barra.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
        barra.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        barra.Controls.Add(direccion, 0, 0);
        barra.Controls.Add(new Label { Text = "fx", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter }, 1, 0);
        barra.Controls.Add(formula, 2, 0);
        direccion.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Intentar(() => SeleccionarRango(direccion.Text)); }
        };
        return barra;
    }

    private void PrepararGrilla()
    {
        MYG2027_TemaComercial.ConservarColoresDocumento(grilla);
        MYG2027_TemaComercial.DesactivarFilasAlternas(grilla);
        grilla.BackgroundColor = Color.White;
        grilla.DefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Color.White, ForeColor = Color.Black, Font = Fuente(MYGCeldaHoja.FuentePredeterminada, 9, FontStyle.Regular),
            SelectionBackColor = MYG2027_TemaComercial.Seleccion, SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion
        };
        grilla.AlternatingRowsDefaultCellStyle.BackColor = Color.White;
        // El margen vacío permite reconocer la superficie de Excel sin añadir
        // celdas a la hoja que se guardará ni cambiar su área de impresión.
        for (int c = 1; c <= Math.Max(22, hoja.Columnas); c++)
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = MYGHojaCalculo.Columna(c), HeaderText = MYGHojaCalculo.Columna(c),
                SortMode = DataGridViewColumnSortMode.NotSortable, ReadOnly = true, MinimumWidth = 2
            });
        grilla.RowCount = Math.Max(30, hoja.Filas);
        grilla.CurrentCell = null;
        foreach (int f in hoja.FilasOcultas) grilla.Rows[f - 1].Visible = false;
        grilla.CellValueNeeded += (_, e) => e.Value = Valor(e.RowIndex, e.ColumnIndex);
        grilla.CellFormatting += (_, e) =>
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0) e.CellStyle = Estilo(e.RowIndex, e.ColumnIndex);
        };
        grilla.CellPainting += PintarCelda;
        grilla.Scroll += (_, _) => grilla.Invalidate();
        grilla.SelectionChanged += (_, _) => { if (!cargando) ActualizarFormula(); };
        grilla.CurrentCellChanged += (_, _) => { if (!cargando) ActualizarFormula(); };
        grilla.ColumnHeaderMouseClick += (_, e) =>
        {
            if (e.Button != MouseButtons.Left || e.ColumnIndex < 0) return;
            CambiarSeleccion(() =>
            {
                if ((ModifierKeys & Keys.Control) == 0) grilla.ClearSelection();
                foreach (DataGridViewRow fila in grilla.Rows) if (fila.Visible) fila.Cells[e.ColumnIndex].Selected = true;
            });
        };
        grilla.RowHeaderMouseClick += (_, e) =>
        {
            if (e.Button != MouseButtons.Left || e.RowIndex < 0) return;
            CambiarSeleccion(() =>
            {
                if ((ModifierKeys & Keys.Control) == 0) grilla.ClearSelection();
                foreach (DataGridViewCell celda in grilla.Rows[e.RowIndex].Cells) celda.Selected = true;
            });
        };
        grilla.CellMouseClick += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || e.Button != MouseButtons.Left || ModifierKeys != Keys.None ||
                !combinaciones.TryGetValue((e.RowIndex, e.ColumnIndex), out var r)) return;
            Seleccionar(r);
        };
        grilla.KeyDown += (_, e) =>
        {
            if (e.Control && e.KeyCode == Keys.C) { e.SuppressKeyPress = true; Intentar(Copiar); }
            else if (e.Control && e.KeyCode == Keys.A) { e.SuppressKeyPress = true; grilla.SelectAll(); }
        };
        grilla.MouseWheel += (_, e) =>
        {
            if ((ModifierKeys & Keys.Control) == 0) return;
            CambiarZoom(hoja.Zoom + Math.Sign(e.Delta) * 10);
            if (e is HandledMouseEventArgs handled) handled.Handled = true;
        };
        menu.Items.Add("Copiar", null, (_, _) => Intentar(Copiar));
        menu.Items.Add("Seleccionar todo", null, (_, _) => grilla.SelectAll());
        grilla.ContextMenuStrip = menu;
        var primera = grilla.Rows.Cast<DataGridViewRow>().FirstOrDefault(f => f.Visible);
        if (primera != null) grilla.CurrentCell = primera.Cells[0];
    }

    private string Valor(int fila, int columna)
    {
        if (fila >= hoja.Filas || columna >= hoja.Columnas) return "";
        string dir = Direccion(fila, columna);
        return mostrandoFormulas ? motor.Contenido(dir) : motor.Mostrar(dir);
    }

    private DataGridViewCellStyle Estilo(int fila, int columna)
    {
        string dir = Direccion(fila, columna);
        if (estilos.TryGetValue(dir, out var guardado)) return guardado;
        var celda = hoja.Celdas.GetValueOrDefault(dir) ?? new MYGCeldaHoja();
        var tipo = (celda.Negrita ? FontStyle.Bold : 0) | (celda.Cursiva ? FontStyle.Italic : 0) |
            (celda.Subrayado ? FontStyle.Underline : 0) | (celda.Tachado ? FontStyle.Strikeout : 0);
        string horizontal = MYGEdicionHoja.AlineacionCelda(celda, dir);
        var estilo = new DataGridViewCellStyle
        {
            Font = Fuente(celda.Fuente, (float)celda.TamanoFuente * hoja.Zoom / 100f, tipo),
            BackColor = ColorDocumento(celda.ColorFondo, Color.White), ForeColor = ColorDocumento(celda.ColorTexto, Color.Black),
            SelectionBackColor = MYG2027_TemaComercial.Seleccion, SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion,
            WrapMode = celda.AjustarTexto ? DataGridViewTriState.True : DataGridViewTriState.False,
            Alignment = celda.AlineacionVertical switch
            {
                "Arriba" => horizontal switch { "Centro" => DataGridViewContentAlignment.TopCenter, "Derecha" => DataGridViewContentAlignment.TopRight, _ => DataGridViewContentAlignment.TopLeft },
                "Abajo" => horizontal switch { "Centro" => DataGridViewContentAlignment.BottomCenter, "Derecha" => DataGridViewContentAlignment.BottomRight, _ => DataGridViewContentAlignment.BottomLeft },
                _ => horizontal switch { "Centro" => DataGridViewContentAlignment.MiddleCenter, "Derecha" => DataGridViewContentAlignment.MiddleRight, _ => DataGridViewContentAlignment.MiddleLeft }
            }
        };
        estilos[dir] = estilo;
        return estilo;
    }

    private void PintarCelda(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0)
        {
            using var fondo = new SolidBrush(MYG2027_TemaComercial.CabeceraTabla);
            e.Graphics.FillRectangle(fondo, e.CellBounds);
            string texto = e.RowIndex < 0 ? e.ColumnIndex < 0 ? "" : grilla.Columns[e.ColumnIndex].HeaderText
                : (e.RowIndex + 1).ToString(CultureInfo.InvariantCulture);
            TextRenderer.DrawText(e.Graphics, texto, Font, e.CellBounds, MYG2027_TemaComercial.Texto,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
            Borde(e.Graphics, e.CellBounds, grilla.GridColor);
            e.Handled = true; return;
        }
        var r = combinaciones.GetValueOrDefault((e.RowIndex, e.ColumnIndex), new(e.RowIndex, e.ColumnIndex, e.RowIndex, e.ColumnIndex));
        var visible = Enumerable.Range(r.Fila, r.FilaFinal - r.Fila + 1).Where(f => grilla.Rows[f].Visible).ToArray();
        if (visible.Length == 0) { e.Handled = true; return; }
        Rectangle inicio = grilla.GetCellDisplayRectangle(r.Columna, visible[0], false);
        Rectangle final = grilla.GetCellDisplayRectangle(r.ColumnaFinal, visible[^1], false);
        var union = Rectangle.FromLTRB(inicio.Left, inicio.Top, final.Right, final.Bottom);
        var estilo = Estilo(r.Fila, r.Columna);
        bool seleccionada = r.Fila == r.FilaFinal && r.Columna == r.ColumnaFinal ? grilla[e.ColumnIndex, e.RowIndex].Selected
            : combinacionesSeleccionadas.Contains(r);
        var guardado = e.Graphics.Save();
        try
        {
            // Cada miembro dibuja su fragmento. Así el título sigue visible
            // cuando su celda inicial queda fuera de la pantalla al desplazar.
            e.Graphics.SetClip(Rectangle.Intersect(e.CellBounds, e.ClipBounds));
            using var fondo = new SolidBrush(seleccionada ? estilo.SelectionBackColor : estilo.BackColor);
            e.Graphics.FillRectangle(fondo, union);
            TextRenderer.DrawText(e.Graphics, Valor(r.Fila, r.Columna), estilo.Font, Rectangle.Inflate(union, -2, -1),
                seleccionada ? estilo.SelectionForeColor : estilo.ForeColor, FormatoTexto(estilo));
            var celda = hoja.Celdas.GetValueOrDefault(Direccion(r.Fila, r.Columna));
            if (celda?.Bordes == true)
            {
                using var borde = new Pen(Color.FromArgb(141, 156, 174));
                e.Graphics.DrawRectangle(borde, union.X, union.Y, union.Width - 1, union.Height - 1);
            }
            else if (hoja.LineasDivision) Borde(e.Graphics, union, grilla.GridColor);
            if (grilla.CurrentCell is { } actual && actual.RowIndex >= r.Fila && actual.RowIndex <= r.FilaFinal &&
                actual.ColumnIndex >= r.Columna && actual.ColumnIndex <= r.ColumnaFinal)
            {
                using var activo = new Pen(MYG2027_TemaComercial.Azul, 2);
                e.Graphics.DrawRectangle(activo, union.X, union.Y, Math.Max(0, union.Width - 2), Math.Max(0, union.Height - 2));
            }
        }
        finally { e.Graphics.Restore(guardado); }
        e.Handled = true;
    }

    private static void Borde(Graphics graphics, Rectangle area, Color color)
    {
        using var borde = new Pen(color);
        graphics.DrawLine(borde, area.Right - 1, area.Top, area.Right - 1, area.Bottom - 1);
        graphics.DrawLine(borde, area.Left, area.Bottom - 1, area.Right - 1, area.Bottom - 1);
    }

    private static TextFormatFlags FormatoTexto(DataGridViewCellStyle estilo)
    {
        var formato = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.PreserveGraphicsClipping;
        formato |= estilo.WrapMode == DataGridViewTriState.True ? TextFormatFlags.WordBreak : TextFormatFlags.SingleLine;
        formato |= estilo.Alignment switch
        {
            DataGridViewContentAlignment.TopCenter or DataGridViewContentAlignment.MiddleCenter or DataGridViewContentAlignment.BottomCenter => TextFormatFlags.HorizontalCenter,
            DataGridViewContentAlignment.TopRight or DataGridViewContentAlignment.MiddleRight or DataGridViewContentAlignment.BottomRight => TextFormatFlags.Right,
            _ => TextFormatFlags.Left
        };
        if (estilo.Alignment is DataGridViewContentAlignment.MiddleLeft or DataGridViewContentAlignment.MiddleCenter or DataGridViewContentAlignment.MiddleRight)
            formato |= TextFormatFlags.VerticalCenter;
        else if (estilo.Alignment is DataGridViewContentAlignment.BottomLeft or DataGridViewContentAlignment.BottomCenter or DataGridViewContentAlignment.BottomRight)
            formato |= TextFormatFlags.Bottom;
        return formato;
    }

    private void AplicarDimensiones()
    {
        cargando = true;
        try
        {
            double factor = hoja.Zoom / 100d * DeviceDpi / 96d;
            grilla.GridColor = Color.FromArgb(202, 216, 234);
            grilla.CellBorderStyle = DataGridViewCellBorderStyle.None;
            grilla.RowHeadersWidth = Math.Max(36, TextRenderer.MeasureText(grilla.RowCount.ToString(CultureInfo.InvariantCulture), Font).Width + 12);
            grilla.ColumnHeadersHeight = Math.Max(22, Font.Height + 5);
            foreach (DataGridViewColumn c in grilla.Columns)
                c.Width = Math.Max(2, (int)Math.Round(hoja.AnchosColumnas.GetValueOrDefault(c.Index + 1,
                    c.Index == 0 ? 288 : c.Index == 7 ? 110 : 68) * factor));
            foreach (DataGridViewRow f in grilla.Rows)
                f.Height = Math.Max(12, (int)Math.Round(hoja.AltosFilas.GetValueOrDefault(f.Index + 1, 20) * factor));
            deslizador.Value = Math.Clamp(hoja.Zoom, deslizador.Minimum, deslizador.Maximum);
            porcentaje.Text = hoja.Zoom.ToString(CultureInfo.CurrentCulture) + " %";
            estilos.Clear();
            grilla.Invalidate();
        }
        finally { cargando = false; }
    }

    internal void CambiarZoom(int valor)
    {
        hoja.Zoom = Math.Clamp(valor, 25, 300);
        AplicarDimensiones();
    }

    private void ActualizarFormula()
    {
        combinacionesSeleccionadas.Clear();
        if (grilla.CurrentCell is not { } celda) { direccion.Text = formula.Text = ""; return; }
        var r = combinaciones.GetValueOrDefault((celda.RowIndex, celda.ColumnIndex), new(celda.RowIndex, celda.ColumnIndex, celda.RowIndex, celda.ColumnIndex));
        string activa = Direccion(r.Fila, r.Columna);
        var seleccion = grilla.SelectedCells.Cast<DataGridViewCell>().ToArray();
        foreach (var seleccionada in seleccion)
            if (combinaciones.TryGetValue((seleccionada.RowIndex, seleccionada.ColumnIndex), out var combinacion)) combinacionesSeleccionadas.Add(combinacion);
        direccion.Text = MYGHojaCalculo.ReferenciaSeleccion(seleccion.Select(c => Direccion(c.RowIndex, c.ColumnIndex)), activa);
        formula.Text = motor.Contenido(activa);
        estado.Text = "Metrados · " + hoja.Filas.ToString("N0", CultureInfo.CurrentCulture) + " filas · " +
            seleccion.Length.ToString("N0", CultureInfo.CurrentCulture) + " celdas seleccionadas · Solo lectura";
        grilla.Invalidate();
    }

    internal void SeleccionarRango(string rango)
    {
        var r = LeerRango(rango);
        if (r.FilaFinal >= grilla.RowCount || r.ColumnaFinal >= grilla.ColumnCount)
            throw new InvalidOperationException("El rango está fuera de la hoja visible.");
        Seleccionar(r);
    }

    private void Seleccionar(Rango r)
    {
        var visible = Enumerable.Range(r.Fila, r.FilaFinal - r.Fila + 1).FirstOrDefault(f => grilla.Rows[f].Visible, -1);
        if (visible < 0) throw new InvalidOperationException("El rango solo contiene filas ocultas.");
        CambiarSeleccion(() =>
        {
            grilla.ClearSelection();
            grilla.CurrentCell = grilla[r.Columna, visible];
            for (int f = r.Fila; f <= r.FilaFinal; f++)
                if (grilla.Rows[f].Visible) for (int c = r.Columna; c <= r.ColumnaFinal; c++) grilla[c, f].Selected = true;
        });
        grilla.FirstDisplayedScrollingRowIndex = visible;
        grilla.FirstDisplayedScrollingColumnIndex = r.Columna;
        ActualizarFormula();
        grilla.Focus();
    }

    private void CambiarSeleccion(Action accion)
    {
        bool previo = cargando;
        cargando = true;
        try { accion(); }
        finally { cargando = previo; }
        ActualizarFormula();
    }

    private static Rango LeerRango(string texto)
    {
        var partes = (texto ?? "").Trim().Split(':');
        if (partes.Length > 2) throw new FormatException("Indique una celda o un rango como A1:H20.");
        var a = MYGHojaCalculo.Coordenadas(partes[0]); var b = MYGHojaCalculo.Coordenadas(partes[^1]);
        return new(Math.Min(a.Fila, b.Fila) - 1, Math.Min(a.Columna, b.Columna) - 1,
            Math.Max(a.Fila, b.Fila) - 1, Math.Max(a.Columna, b.Columna) - 1);
    }

    internal string TextoSeleccion()
    {
        var seleccion = grilla.SelectedCells.Cast<DataGridViewCell>().Select(c => (Fila: c.RowIndex, Columna: c.ColumnIndex)).ToHashSet();
        if (seleccion.Count == 0) return "";
        int primera = seleccion.Min(c => c.Fila), ultima = seleccion.Max(c => c.Fila);
        int izquierda = seleccion.Min(c => c.Columna), derecha = seleccion.Max(c => c.Columna);
        var lineas = new List<string>();
        for (int f = primera; f <= ultima; f++)
        {
            if (!grilla.Rows[f].Visible) continue;
            var campos = new List<string>();
            for (int c = izquierda; c <= derecha; c++)
            {
                string texto = seleccion.Contains((f, c)) ? Valor(f, c) : "";
                campos.Add(texto.IndexOfAny(new[] { '\t', '\r', '\n', '"' }) >= 0 ? "\"" + texto.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"" : texto);
            }
            lineas.Add(string.Join('\t', campos));
        }
        return string.Join(Environment.NewLine, lineas);
    }

    private void Copiar()
    {
        string texto = TextoSeleccion();
        if (texto.Length > 0) Clipboard.SetText(texto);
    }

    private void Buscar()
    {
        using var pregunta = new MYGCamposProyectoForm("Buscar en metrados", new[] { "Texto o valor" }, new[] { "" });
        if (pregunta.ShowDialog(this) != DialogResult.OK || string.IsNullOrWhiteSpace(pregunta.Valores[0])) return;
        string texto = pregunta.Valores[0];
        int desde = grilla.CurrentCell == null ? -1 : grilla.CurrentCell.RowIndex * hoja.Columnas + grilla.CurrentCell.ColumnIndex;
        int cantidad = hoja.Filas * hoja.Columnas;
        for (int n = 1; n <= cantidad; n++)
        {
            int indice = (desde + n) % cantidad, f = indice / hoja.Columnas, c = indice % hoja.Columnas;
            if (!grilla.Rows[f].Visible || !Valor(f, c).Contains(texto, StringComparison.CurrentCultureIgnoreCase)) continue;
            Seleccionar(new(f, c, f, c)); return;
        }
        MessageBox.Show(this, "No se encontró el texto en los metrados.", "Buscar", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void GuardarComo()
    {
        string sugerido = new(nombreDocumento.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c).ToArray());
        using var dialogo = new SaveFileDialog
        {
            Title = "Guardar todos los metrados en Excel",
            Filter = "Libro de Excel (*.xlsx)|*.xlsx|Libro de Excel 97-2003 (*.xls)|*.xls", FilterIndex = preferirXls ? 2 : 1,
            DefaultExt = preferirXls ? "xls" : "xlsx", AddExtension = true,
            FileName = sugerido + " - Metrados", OverwritePrompt = true
        };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        GuardarEn(dialogo.FileName);
        estado.Text = "Libro guardado: " + dialogo.FileName;
    }

    internal void GuardarEn(string ruta)
    {
        string extension = Path.GetExtension(ruta);
        if (string.Equals(extension, ".xls", StringComparison.OrdinalIgnoreCase))
            MYGReportesExportacionWindows.GuardarXls(ruta, new[] { reporteVisible });
        else if (string.Equals(extension, ".xlsx", StringComparison.OrdinalIgnoreCase))
            MYGExcelPresupuestos.Guardar(ruta, new[] { hoja });
        else throw new InvalidOperationException("Guarde el libro con extensión .xlsx o .xls.");
        ArchivoGuardado = Path.GetFullPath(ruta);
    }

    private void VistaImpresion() => MYGReportesImpresion.Imprimir(this, nombreDocumento + " - Metrados", new[] { reporteVisible });

    private Font Fuente(string nombre, float puntos, FontStyle estilo)
    {
        string clave = nombre + "|" + puntos.ToString(CultureInfo.InvariantCulture) + "|" + estilo;
        if (!fuentes.TryGetValue(clave, out var fuente)) fuentes[clave] = fuente = new Font(nombre, Math.Max(2, puntos), estilo);
        return fuente;
    }

    private static string Direccion(int fila, int columna) => MYGHojaCalculo.Columna(columna + 1) + (fila + 1).ToString(CultureInfo.InvariantCulture);
    private static Color ColorDocumento(string texto, Color predeterminado) => string.IsNullOrWhiteSpace(texto) ? predeterminado
        : ColorTranslator.FromHtml(texto.StartsWith('#') ? texto : "#" + texto);

    private void Intentar(Action accion)
    {
        try { accion(); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Metrados en Excel", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (!disposing) return;
        menu.Dispose();
        foreach (var fuente in fuentes.Values) fuente.Dispose();
    }
}
