using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class BaseCompartidaUICheck
{
    private const BindingFlags Privados = BindingFlags.Instance | BindingFlags.NonPublic;

    internal static void Ejecutar(string carpeta, Action<bool, string> exige)
    {
        string ruta = Path.Combine(carpeta, "base-compartida-" + Guid.NewGuid().ToString("N") + ".sqlite");
        var primera = Obra("OBRA NORTE", 1m);
        var segunda = Obra("OBRA SUR", 2m);
        MYGProyectoStorage.Guardar(ruta, primera);
        MYGProyectoStorage.Guardar(ruta, segunda);
        using var sesion = new SesionDesktop();
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion,
            new CredencialMYG { Usuario = "Prueba local de base compartida" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
        using var host = new Form { ClientSize = new Size(1200, 760), Text = "Prueba de base compartida" };
        var pestañas = new TabControl { Dock = DockStyle.Fill };
        host.Controls.Add(pestañas);
        using var norte = Editor(MYGBaseDatos.LeerProyecto(ruta, primera.Id), ruta, sesion, pestañas);
        using var sur = Editor(MYGBaseDatos.LeerProyecto(ruta, segunda.Id), ruta, sesion, pestañas);
        ExceptionDispatchInfo fallo = null;
        host.Shown += async (_, _) =>
        {
            try { await Verificar(norte, sur, ruta, exige); }
            catch (Exception ex) { fallo = ExceptionDispatchInfo.Capture(ex); }
            finally { norte.CerrarConfirmado(); sur.CerrarConfirmado(); host.Close(); }
        };
        host.ShowDialog();
        fallo?.Throw();
    }

    private static async Task Verificar(EditorForm norte, EditorForm sur, string ruta, Action<bool, string> exige)
    {
        EditarCantidad(norte, 11m);
        EditarCantidad(sur, 22.5m);
        await norte.GuardarEdicionBaseNubeAsync();
        await sur.GuardarEdicionBaseNubeAsync();
        exige(MYGBaseDatos.ListarProyectos(ruta).Count == 2
            && Cantidad(MYGBaseDatos.LeerProyecto(ruta, norte.ProyectoId)) == 11m
            && Cantidad(MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId)) == 22.5m,
            "Preparar una base compartida debe guardar las cantidades de ambas pestañas sin perder ninguna obra.");
        exige(!norte.CambiosPendientes && !sur.CambiosPendientes,
            "Conservar las ediciones antes del envío debe confirmar el guardado de cada pestaña.");

        EditarCantidad(sur, 33m);
        var borrador = Documento(sur);
        await sur.ActualizarEdicionBaseNubeAsync(false);
        exige(ReferenceEquals(Documento(sur), borrador) && Cantidad(Documento(sur)) == 33m
            && Cantidad(MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId)) == 22.5m,
            "Actualizar solo la revisión tras subir otra obra no debe releer ni descartar el borrador de la pestaña vecina.");

        await sur.GuardarEdicionBaseNubeAsync();
        var anterior = Documento(sur);
        var remoto = MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId);
        remoto.Presupuestos[0].Items[0].Costos.Cantidad = 45m;
        MYGProyectoStorage.Guardar(ruta, remoto);
        await sur.ActualizarEdicionBaseNubeAsync(true);
        exige(!ReferenceEquals(Documento(sur), anterior) && Cantidad(Documento(sur)) == 45m
            && !sur.CambiosPendientes && Cantidad(Documento(norte)) == 11m,
            "Una sustitución remota debe renovar la obra limpia de la otra pestaña y conservar el documento de su vecina.");

        EditarCantidad(sur, 99m);
        var protegido = Documento(sur);
        remoto = MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId);
        remoto.Presupuestos[0].Items[0].Costos.Cantidad = 77m;
        MYGProyectoStorage.Guardar(ruta, remoto);
        bool rechazado = false;
        try { await sur.ActualizarEdicionBaseNubeAsync(true); }
        catch (InvalidOperationException ex) when (ex.Message.Contains("borrador local", StringComparison.Ordinal))
        { rechazado = true; }
        exige(rechazado && ReferenceEquals(Documento(sur), protegido) && Cantidad(Documento(sur)) == 99m
            && Cantidad(MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId)) == 77m,
            "Una recarga tardía no debe sustituir el borrador nuevo ni escribirlo sobre la revisión recibida.");
        exige(!sur.OperacionEnCurso
            && !(bool)typeof(EditorForm).GetField("actualizandoNube", Privados).GetValue(sur),
            "Rechazar una recarga debe retirar los bloqueos de la pestaña y permitir conservar su borrador.");

        EditarCantidad(norte, 13m);
        await norte.GuardarEdicionBaseNubeAsync();
        exige(Cantidad(MYGBaseDatos.LeerProyecto(ruta, norte.ProyectoId)) == 13m
            && Cantidad(MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId)) == 77m
            && Cantidad(Documento(sur)) == 99m,
            "Guardar una obra debe respetar la revisión SQL de las demás y su borrador independiente en memoria.");
        await sur.GuardarEdicionBaseNubeAsync();
        exige(Cantidad(MYGBaseDatos.LeerProyecto(ruta, norte.ProyectoId)) == 13m
            && Cantidad(MYGBaseDatos.LeerProyecto(ruta, sur.ProyectoId)) == 99m,
            "Volver a preparar la base debe incluir ambos cambios antes de crear la instantánea común.");

        string soloNorte = Path.Combine(Path.GetDirectoryName(ruta), "remoto-solo-norte.sqlite");
        MYGProyectoStorage.Guardar(soloNorte, MYGBaseDatos.LeerProyecto(ruta, norte.ProyectoId));
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        File.Copy(soloNorte, ruta, true);
        var obraRetirada = Documento(sur);
        await sur.ActualizarEdicionBaseNubeAsync(true);
        exige(ReferenceEquals(Documento(sur), obraRetirada) && Cantidad(Documento(sur)) == 99m,
            "Si una revisión remota ya no contiene una obra abierta, su documento debe quedar disponible para recuperación.");
        bool escrituraBloqueada = false;
        try { await sur.GuardarEdicionBaseNubeAsync(); }
        catch (InvalidOperationException ex) when (ex.Message.Contains("ya no está", StringComparison.Ordinal))
        { escrituraBloqueada = true; }
        bool guardarBloqueado = false;
        try { typeof(EditorForm).GetMethod("Guardar", Privados).Invoke(sur, new object[] { false }); }
        catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException error
            && error.Message.Contains("ya no está", StringComparison.Ordinal)) { guardarBloqueado = true; }
        exige(escrituraBloqueada && guardarBloqueado && MYGBaseDatos.ListarProyectos(ruta).Count == 1,
            "La pestaña de una obra retirada no debe reinsertar silenciosamente datos antiguos al guardar o sincronizar la base recibida.");
    }

    private static MYGProyectoDocumento Obra(string nombre, decimal cantidad)
    {
        var obra = MYGProyectoStorage.Nuevo(nombre, "Presupuesto");
        string id = MYGProyectoStorage.NuevoId();
        var partida = new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id,
            Item = "01", Posicion = 1, Descripcion = "Partida de prueba", Unidad = "m2",
            TipoPropuesta = "PARTIDA", Origen = "MODELO", Estado = "PROPUESTA"
        };
        partida.Costos.Cantidad = cantidad;
        partida.Costos.PrecioDirecto = 10m;
        obra.Presupuestos[0].Items.Add(partida);
        return obra;
    }

    private static EditorForm Editor(MYGProyectoDocumento documento, string ruta, SesionDesktop sesion, TabControl pestañas)
    {
        var editor = new EditorForm(documento, ruta, sesion)
        { TopLevel = false, Dock = DockStyle.Fill, FormBorderStyle = FormBorderStyle.None, MinimumSize = Size.Empty };
        var pagina = new TabPage(documento.Nombre);
        pagina.Controls.Add(editor); pestañas.TabPages.Add(pagina); editor.Show();
        return editor;
    }

    private static MYGProyectoDocumento Documento(EditorForm editor) =>
        (MYGProyectoDocumento)typeof(EditorForm).GetField("documento", Privados).GetValue(editor);
    private static decimal Cantidad(MYGProyectoDocumento documento) => documento.Presupuestos[0].Items[0].Costos.Cantidad;
    private static void EditarCantidad(EditorForm editor, decimal cantidad)
    {
        Documento(editor).Presupuestos[0].Items[0].Costos.Cantidad = cantidad;
        typeof(EditorForm).GetMethod("Refrescar", Privados).Invoke(editor, null);
    }
}
