using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG.Externo;
using MYG_2027;

internal static class EditorNubeProgresoCheck
{
    private const string Servidor = "https://progreso-ui.supabase.co";
    private static readonly Guid ProyectoId = Guid.Parse("11111111-aaaa-4111-8111-111111111111");
    private static readonly Guid UsuarioId = Guid.Parse("22222222-bbbb-4222-8222-222222222222");

    internal static void Ejecutar(Action<bool, string> exige)
    {
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Nube-Progreso-UI-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        var indice = typeof(MYGIndiceLocal).GetProperty("RutaAlternativaPruebas", BindingFlags.Static | BindingFlags.NonPublic);
        string anterior = (string)indice.GetValue(null);
        try
        {
            indice.SetValue(null, Path.Combine(carpeta, "indice.json"));
            MYGIndiceLocal.RecordarBiblioteca(Path.Combine(carpeta, "biblioteca.json"));
            Verificar(carpeta, soloLeer: false, falloRemoto: false, exige);
            Verificar(carpeta, soloLeer: true, falloRemoto: false, exige);
            Verificar(carpeta, soloLeer: false, falloRemoto: true, exige);
            BaseCompartidaUICheck.Ejecutar(carpeta, exige);
        }
        finally
        {
            indice.SetValue(null, anterior);
            SqliteConnection.ClearAllPools();
            Directory.Delete(carpeta, true);
        }
    }

    private static void Verificar(string carpeta, bool soloLeer, bool falloRemoto, Action<bool, string> exige)
    {
        string ruta = Path.Combine(carpeta, Guid.NewGuid().ToString("N") + ".sqlite");
        var documento = MYGProyectoStorage.Nuevo("Proyecto inicial de progreso", "Presupuesto");
        MYGProyectoStorage.Guardar(ruta, documento);
        using var http = new Transporte(documento.Id, documento.Nombre, falloRemoto);
        using var cliente = new ClienteSupabase(Servidor, "sb_publishable_pruebas_progreso_ui", http);
        Task.Run(async () =>
        {
            await cliente.IniciarSesionAsync("progreso@myg.example", "clave_sintetica");
            var publicado = await cliente.CrearSqliteAsync(ProyectoId, documento.Nombre, ruta, "base", documento.Id);
            CopiaSqliteNube.Vincular(ruta, publicado, cliente);
        }).GetAwaiter().GetResult();
        http.IniciarOperacion();
        using var sesion = new SesionDesktop();
        // Esta prueba no contacta al servicio de licencias ni guarda una sesión real.
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Credencial)).SetValue(sesion,
            new CredencialMYG { Usuario = "Prueba de progreso" });
        typeof(SesionDesktop).GetProperty(nameof(SesionDesktop.Autorizado)).SetValue(sesion, true);
        using var editor = new EditorForm(documento, ruta, sesion);
        editor.ConfigurarNube(() => cliente, () => { });
        documento.Nombre = "Edición local que debe conservarse";
        ExceptionDispatchInfo fallo = null;
        editor.Shown += async (_, _) =>
        {
            try { await VerificarOperacion(editor, ruta, documento, http, soloLeer, falloRemoto, exige); }
            catch (Exception ex) { fallo = ExceptionDispatchInfo.Capture(ex); }
            finally { editor.CerrarConfirmado(); }
        };
        editor.ShowDialog();
        fallo?.Throw();
    }

    private static async Task VerificarOperacion(EditorForm editor, string ruta, MYGProyectoDocumento original, Transporte http,
        bool soloLeer, bool falloRemoto, Action<bool, string> exige)
    {
        int hiloUi = Environment.CurrentManagedThreadId, pulsosGuardado = 0, pulsosRed = 0, guardados = 0;
        bool guardadoVisible = false, redVisible = false, reentradaRechazada = false;
        MYGDialogoCarga carga = null;
        ExceptionDispatchInfo falloReloj = null;
        using var conexion = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = ruta, Pooling = false }.ToString());
        conexion.Open();
        // El bloqueo de escritura hace que la comprobación falle si SQLite vuelve
        // al hilo UI: el reloj no puede liberar la transacción ni mostrar etapas.
        SqliteTransaction bloqueo = conexion.BeginTransaction();
        using (var comando = conexion.CreateCommand())
        {
            comando.Transaction = bloqueo;
            comando.CommandText = "UPDATE myg_proyecto SET id=id";
            comando.ExecuteNonQuery();
        }
        var limite = Stopwatch.StartNew();
        using var reloj = new System.Windows.Forms.Timer { Interval = 20 };
        void LiberarGuardado()
        {
            bloqueo?.Dispose();
            bloqueo = null;
        }
        editor.ProyectoGuardado += _ =>
        {
            guardados++;
            var dialogo = editor.OwnedForms.OfType<MYGDialogoCarga>().Single();
            exige(Environment.CurrentManagedThreadId == hiloUi && dialogo.Visible && !editor.Enabled,
                "La notificación de guardado debe volver al hilo UI con la carga todavía visible.");
        };
        reloj.Tick += (_, _) =>
        {
            try
            {
                carga = editor.OwnedForms.OfType<MYGDialogoCarga>().FirstOrDefault() ?? carga;
                if (carga?.EtapaActual == "Guardando la copia de trabajo local…" && bloqueo != null)
                {
                    guardadoVisible |= carga.Visible && !editor.Enabled && guardados == 0;
                    if (++pulsosGuardado >= 3) LiberarGuardado();
                }
                if (http.Esperando && !http.Continuar.Task.IsCompleted)
                {
                    redVisible |= carga?.Visible == true && !editor.Enabled &&
                        carga.EtapaActual == "Consultando la revisión y los permisos del archivo SQLite…";
                    if (++pulsosRed >= 3)
                    {
                        Task repetida = editor.ActualizarNubeAsync(!soloLeer);
                        reentradaRechazada = repetida.IsCompletedSuccessfully &&
                            editor.OwnedForms.OfType<MYGDialogoCarga>().Count() == 1 && guardados == 1;
                        http.Continuar.TrySetResult(true);
                    }
                }
                if (limite.Elapsed > TimeSpan.FromSeconds(10))
                    throw new TimeoutException("La operación de nube no informó las etapas esperadas.");
            }
            catch (Exception ex)
            {
                falloReloj ??= ExceptionDispatchInfo.Capture(ex);
                LiberarGuardado(); http.Continuar.TrySetResult(true); reloj.Stop();
            }
        };
        reloj.Start();
        bool errorRecibido = false;
        try
        {
            try { await editor.ActualizarNubeAsync(soloLeer); }
            catch (NubeException ex) when (falloRemoto && ex.AccesoDenegado) { errorRecibido = true; }
        }
        finally { reloj.Stop(); LiberarGuardado(); http.Continuar.TrySetResult(true); }
        falloReloj?.Throw();
        exige(guardadoVisible && pulsosGuardado >= 3 && guardados == 1,
            "Sincronizar y Recargar deben mostrar la carga antes de escribir SQLite y mantener activo el reloj UI mientras se guarda.");
        exige(redVisible && pulsosRed >= 3 && reentradaRechazada,
            "La carga debe mostrar la consulta real, procesar mensajes durante la red y rechazar una segunda actualización.");
        exige(carga?.IsDisposed == true && editor.Enabled && !editor.UseWaitCursor &&
            !editor.OwnedForms.OfType<MYGDialogoCarga>().Any(),
            "Terminar o fallar debe cerrar la carga, restaurar el cursor y habilitar el editor.");
        exige(errorRecibido == falloRemoto, "El error remoto debe propagarse después de retirar la ventana de progreso.");
        var vinculo = CopiaSqliteNube.LeerVinculo(ruta, original.Id);
        exige(MYGBaseDatos.LeerProyecto(ruta, original.Id).Nombre == "Edición local que debe conservarse",
            "La operación debe guardar la edición local antes de consultar el servidor, también si la red falla.");
        if (soloLeer || falloRemoto)
        {
            exige(vinculo.Pendiente != null && http.Escrituras == 0,
                "Recargar y el fallo de consulta deben conservar el pendiente local sin enviar una escritura remota.");
        }
        else
        {
            exige(vinculo.Pendiente == null && vinculo.Revision == 2 && http.Escrituras == 1,
                "Sincronizar debe confirmar la edición guardada una sola vez.");
        }
        if (falloRemoto)
            exige(ReferenceEquals(original, typeof(EditorForm).GetField("documento",
                BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor)),
                "Un error de red debe mantener el documento original al que siguen ligados los controles y sus filas.");
        if (!falloRemoto)
            exige(carga.EtapaActual == "Actualizando la pantalla del proyecto…",
                "La misma carga debe permanecer hasta la actualización final de la pantalla.");
        exige(MYGColaboracionLocal.Leer(ruta, original.Id) == null &&
            File.Exists(CopiaSqliteNube.RutaEstado(ruta)) &&
            http.Metadatos.All(cuerpo => cuerpo.Length < 2048 && !cuerpo.Contains("p_contenido") && !cuerpo.Contains("Base64")),
            "La UI nativa debe usar el sidecar y RPC pequeñas sin insertar una cola JSON en la obra ni subir tablas como JSON.");
        if (!soloLeer && !falloRemoto)
        {
            byte[] antes = File.ReadAllBytes(ruta);
            int envios = http.Subidas;
            await editor.ActualizarNubeAsync(false);
            exige(File.ReadAllBytes(ruta).SequenceEqual(antes) && http.Subidas == envios && http.Escrituras == 1,
                "Repetir Sincronizar sin editar debe conservar el SQLite y evitar reescritura o transferencia redundante.");
        }
    }

    private sealed class Transporte(string documento, string nombre, bool fallar) : HttpMessageHandler
    {
        private const string Bucket = "/storage/v1/object/myg-nube-sqlite/";
        private readonly Dictionary<string, byte[]> objetos = new(StringComparer.Ordinal);
        private ArchivoSqliteNube archivo;
        private int lecturas, escrituras, subidas;
        private bool enOperacion;
        private long revision = 1;
        internal bool Esperando => Volatile.Read(ref lecturas) > 0;
        internal int Escrituras => Volatile.Read(ref escrituras);
        internal int Subidas => Volatile.Read(ref subidas);
        internal List<string> Metadatos { get; } = new();
        internal TaskCompletionSource<bool> Continuar { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);

        internal void IniciarOperacion() { enOperacion = true; subidas = 0; Metadatos.Clear(); }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new
            { access_token = "token_ui", refresh_token = "refresh_ui", expires_in = 3600, user = new { id = UsuarioId } });
            if (solicitud.Headers.Authorization?.Scheme != "Bearer" || !solicitud.Headers.Contains("apikey"))
                throw new InvalidOperationException("Falta la sesión autenticada en la operación SQLite de UI.");
            if (ruta.StartsWith(Bucket, StringComparison.Ordinal))
            {
                string referencia = ruta[Bucket.Length..];
                if (solicitud.Method == HttpMethod.Post)
                {
                    if (solicitud.Content.Headers.ContentType?.MediaType != "application/vnd.sqlite3"
                        || solicitud.Content.Headers.ContentEncoding.Count != 0)
                        throw new InvalidOperationException("La UI debe enviar SQLite binario sin compresión.");
                    byte[] bytes = await solicitud.Content.ReadAsByteArrayAsync(ct);
                    string hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
                    if (!bytes.AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8)
                        || referencia != UsuarioId + "/" + ProyectoId.ToString("N") + "/" + hash + ".sqlite")
                        throw new InvalidOperationException("El stream SQLite o su referencia no son íntegros.");
                    if (!objetos.TryAdd(referencia, bytes)) return Json(new { }, HttpStatusCode.Conflict);
                    if (enOperacion) Interlocked.Increment(ref subidas);
                    return Json(new { Key = referencia });
                }
                return new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(objetos[referencia]) };
            }
            if (!ruta.StartsWith("/rest/v1/rpc/myg_nube_sqlite_", StringComparison.Ordinal))
                throw new InvalidOperationException("La prueba nativa recibió una RPC JSON/GZip inesperada: " + ruta);
            string texto = await solicitud.Content.ReadAsStringAsync(ct);
            Metadatos.Add(texto);
            using var cuerpo = JsonDocument.Parse(texto);
            var parametros = cuerpo.RootElement;
            if (ruta.EndsWith("myg_nube_sqlite_capacidades"))
                return Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
            if (ruta.EndsWith("myg_nube_sqlite_consultar")) return archivo == null ? Json(null) : Descriptor();
            if (ruta.EndsWith("myg_nube_sqlite_crear"))
            {
                archivo = LeerArchivo(parametros);
                return Descriptor();
            }
            if (ruta.EndsWith("myg_nube_sqlite_abrir"))
            {
                Interlocked.Increment(ref lecturas);
                await Continuar.Task.WaitAsync(TimeSpan.FromSeconds(10), ct);
                if (fallar) return Json(new { code = "42501", message = "Acceso retirado simulado" }, HttpStatusCode.Forbidden);
                return Descriptor();
            }
            if (ruta.EndsWith("myg_nube_sqlite_guardar"))
            {
                if (parametros.GetProperty("p_revision").GetInt64() != revision)
                    throw new InvalidOperationException("La UI envió una revisión base inesperada.");
                archivo = LeerArchivo(parametros);
                if (!objetos.ContainsKey(archivo.Ruta)) throw new InvalidOperationException("El archivo se confirmó antes de subir sus bytes.");
                Interlocked.Increment(ref escrituras);
                revision++;
                return Json(new { estado = "aplicada", revision,
                    operacion_id = parametros.GetProperty("p_operacion").GetGuid(),
                    archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes } });
            }
            throw new InvalidOperationException("La prueba de progreso recibió una solicitud inesperada: " + ruta);
        }

        private static ArchivoSqliteNube LeerArchivo(JsonElement parametros) => new(
            parametros.GetProperty("p_ruta").GetString(), parametros.GetProperty("p_sha256").GetString(),
            parametros.GetProperty("p_bytes").GetInt64());

        private HttpResponseMessage Descriptor() => Json(new
        {
            id = ProyectoId, codigo = "MYG-UI-001", nombre, rol = "propietario", revision, alcance = "base", documento_id = documento,
            permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true },
            archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes }
        });

        private static HttpResponseMessage Json(object valor, HttpStatusCode estado = HttpStatusCode.OK) => new(estado)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
