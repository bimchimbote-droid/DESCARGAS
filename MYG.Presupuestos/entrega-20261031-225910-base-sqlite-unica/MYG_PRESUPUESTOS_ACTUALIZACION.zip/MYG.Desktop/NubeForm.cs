#nullable enable
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MYG.Colaboracion;
using MYG.Externo;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace MYG_2027;

/// <summary>Explorador de proyectos reales. El propietario conserva la vida del cliente compartido.</summary>
public sealed class NubeForm : WinForms.Form
{
    private readonly SesionDesktop sesion;
    private ClienteSupabase? cliente;
    private readonly CancellationTokenSource vida = new();
    private readonly WinForms.Label estado = new() { Name = "estadoNube", Dock = WinForms.DockStyle.Fill,
        TextAlign = Drawing.ContentAlignment.MiddleLeft, AutoEllipsis = true };
    private readonly WinForms.Label detalle = new() { Dock = WinForms.DockStyle.Fill,
        Text = "Seleccione un proyecto para abrirlo o consultar su colaboración.", AutoEllipsis = true };
    private readonly WinForms.Label usuarioMyg = new() { Name = "usuarioMygNube", Dock = WinForms.DockStyle.Fill,
        TextAlign = Drawing.ContentAlignment.MiddleLeft, AutoEllipsis = true };
    private readonly WinForms.TextBox usuarioColaborador = new() { Name = "usuarioColaboradorMyg", Dock = WinForms.DockStyle.Fill,
        PlaceholderText = "Usuario MYG del colaborador", MaxLength = 256 };
    private readonly WinForms.TabControl paginas = new() { Name = "proyectosNube", Dock = WinForms.DockStyle.Fill };
    private readonly WinForms.DataGridView propios = TablaProyectos("proyectosPropiosNube");
    private readonly WinForms.DataGridView compartidos = TablaProyectos("proyectosCompartidosNube");
    private readonly WinForms.DataGridView miembros = Tabla("miembrosNube");
    private readonly WinForms.DataGridView solicitudes = Tabla("solicitudesNube");
    private readonly WinForms.ComboBox rol = new() { Name = "rolColaboracionNube", Width = 135,
        DropDownStyle = WinForms.ComboBoxStyle.DropDownList };
    private readonly List<WinForms.Button> acciones = new();
    private readonly WinForms.Button conectar, actualizar, abrir, publicar, pendientes, descargar,
        colaboracion, aceptar, rechazar, cambiarRol, retirar, compartirUsuario, permisosMiembro, eliminarBase;
    private readonly WinForms.Button cancelarPublicacion;
    private readonly WinForms.ColumnStyle espacioCancelarPublicacion = new(WinForms.SizeType.Absolute, 0);
    private readonly WinForms.Timer relojPublicacion = new() { Interval = 1000 };
    private readonly Stopwatch tiempoPublicacion = new();
    private CancellationTokenSource? cancelacionPublicacion;
    private string? fasePublicacion;
    private bool confirmacionPublicacionRecibida;
    private bool ocupado;
    private string? errorConfiguracion;
    private Guid? proyectoColaboracion;

    public event Func<ProyectoNube, Task>? AbrirSolicitado;
    public event Func<ProyectoNube, Task>? DescargarSolicitado;
    public event Func<Task>? PublicarSolicitado;
    public event Func<Task>? PendientesSolicitado;
    public event Func<Task>? ConectarMygSolicitado;

    public NubeForm(SesionDesktop sesion, ClienteSupabase? cliente)
    {
        this.sesion = sesion ?? throw new ArgumentNullException(nameof(sesion));
        this.cliente = cliente;
        Name = "ventanaNubeMYG";
        MYGProyectoUI.Preparar(this, "Nube MYG", 1150, 820);
        MinimumSize = new(880, 680);
        var raiz = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, Padding = new(20),
            ColumnCount = 1, RowCount = 6 };
        raiz.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 54, 110, 0, 62, 52, 40 })
            raiz.RowStyles.Add(alto == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, alto));

        var titulo = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 3 };
        titulo.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 190));
        titulo.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        titulo.ColumnStyles.Add(espacioCancelarPublicacion);
        titulo.Controls.Add(new WinForms.Label { Text = "Nube MYG", Dock = WinForms.DockStyle.Fill,
            Font = new("Segoe UI", 21, Drawing.FontStyle.Bold) }, 0, 0);
        titulo.Controls.Add(estado, 1, 0);
        raiz.Controls.Add(titulo, 0, 0);

        var cuenta = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 3 };
        cuenta.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        cuenta.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 200));
        cuenta.RowStyles.Add(new(WinForms.SizeType.Absolute, 27));
        cuenta.RowStyles.Add(new(WinForms.SizeType.Absolute, 43));
        cuenta.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        var identidad = new WinForms.Label { Text = "Ingreso con su cuenta MYG", Dock = WinForms.DockStyle.Fill,
            Font = new("Segoe UI", 10, Drawing.FontStyle.Bold) };
        cuenta.Controls.Add(identidad, 0, 0); cuenta.SetColumnSpan(identidad, 2);
        cuenta.Controls.Add(usuarioMyg, 0, 1);
        conectar = CrearBoton("Reintentar conexión", "reintentarConexionMyg", ConectarAsync);
        conectar.Dock = WinForms.DockStyle.Fill;
        cuenta.Controls.Add(conectar, 1, 1);
        var aviso = new WinForms.Label { Dock = WinForms.DockStyle.Fill, Text =
            "La nube se conecta con el usuario MYG que ya ingresó. El administrador debe haber verificado su vinculación. Se conservan los permisos de cada proyecto." };
        cuenta.Controls.Add(aviso, 0, 2); cuenta.SetColumnSpan(aviso, 2); raiz.Controls.Add(cuenta, 0, 1);

        var centro = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        centro.ColumnStyles.Add(new(WinForms.SizeType.Percent, 57));
        centro.ColumnStyles.Add(new(WinForms.SizeType.Percent, 43));
        var paginaPropios = new WinForms.TabPage("Mis proyectos"); paginaPropios.Controls.Add(propios);
        var paginaCompartidos = new WinForms.TabPage("Compartidos conmigo"); paginaCompartidos.Controls.Add(compartidos);
        paginas.TabPages.Add(paginaPropios); paginas.TabPages.Add(paginaCompartidos);
        centro.Controls.Add(paginas, 0, 0);

        var panelColaboracion = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 1, RowCount = 5,
            Padding = new(12, 0, 0, 0) };
        panelColaboracion.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100));
        foreach (int alto in new[] { 38, 48, 0, 44, 116 })
            panelColaboracion.RowStyles.Add(alto == 0 ? new(WinForms.SizeType.Percent, 100) : new(WinForms.SizeType.Absolute, alto));
        panelColaboracion.Controls.Add(new WinForms.Label { Text = "Colaboración del proyecto seleccionado",
            Dock = WinForms.DockStyle.Fill }, 0, 0);
        colaboracion = CrearBoton("Cargar colaboración", "cargarColaboracionNube", CargarColaboracionAsync);
        colaboracion.AutoSize = true; panelColaboracion.Controls.Add(colaboracion, 0, 1);
        miembros.Columns.Add("UsuarioMyg", "Usuario MYG"); miembros.Columns.Add("Rol", "Rol");
        miembros.Columns.Add("Modulos", "Módulos en solo lectura");
        solicitudes.Columns.Add("UsuarioId", "Solicitante"); solicitudes.Columns.Add("Estado", "Estado");
        var grupos = new WinForms.TabControl { Dock = WinForms.DockStyle.Fill };
        var paginaMiembros = new WinForms.TabPage("Miembros"); paginaMiembros.Controls.Add(miembros);
        var paginaSolicitudes = new WinForms.TabPage("Solicitudes anteriores"); paginaSolicitudes.Controls.Add(solicitudes);
        grupos.TabPages.Add(paginaMiembros); grupos.TabPages.Add(paginaSolicitudes);
        panelColaboracion.Controls.Add(grupos, 0, 2);
        rol.Items.AddRange(new object[] { "lector", "editor", "administrador" }); rol.SelectedIndex = 0;
        var filaRol = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, WrapContents = false };
        filaRol.Controls.Add(new WinForms.Label { Text = "Rol a asignar", AutoSize = true, Margin = new(0, 8, 10, 0) });
        filaRol.Controls.Add(rol); panelColaboracion.Controls.Add(filaRol, 0, 3);
        var accionesColaboracion = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, AutoScroll = true };
        aceptar = CrearBoton("Aceptar solicitud", "aceptarSolicitudNube", () => ResolverAsync(true));
        rechazar = CrearBoton("Rechazar solicitud", "rechazarSolicitudNube", () => ResolverAsync(false));
        cambiarRol = CrearBoton("Cambiar rol", "cambiarRolNube", () => CambiarRolAsync(false));
        retirar = CrearBoton("Retirar acceso", "retirarAccesoNube", () => CambiarRolAsync(true));
        permisosMiembro = CrearBoton("Permisos por módulo", "permisosModulosNube", CambiarPermisosAsync);
        foreach (var boton in new[] { aceptar, rechazar, cambiarRol, retirar, permisosMiembro })
        { boton.AutoSize = true; boton.Height = 32; accionesColaboracion.Controls.Add(boton); }
        panelColaboracion.Controls.Add(accionesColaboracion, 0, 4);
        centro.Controls.Add(panelColaboracion, 1, 0); raiz.Controls.Add(centro, 0, 2);

        var acceso = new WinForms.TableLayoutPanel { Dock = WinForms.DockStyle.Fill, ColumnCount = 2, RowCount = 2,
            Padding = new(0, 7, 0, 0) };
        acceso.ColumnStyles.Add(new(WinForms.SizeType.Percent, 100)); acceso.ColumnStyles.Add(new(WinForms.SizeType.Absolute, 170));
        acceso.RowStyles.Add(new(WinForms.SizeType.Absolute, 22)); acceso.RowStyles.Add(new(WinForms.SizeType.Percent, 100));
        acceso.Controls.Add(new WinForms.Label { Text = "Agregar colaborador por su usuario MYG (solo propietario o administrador)", AutoSize = true }, 0, 0);
        acceso.Controls.Add(usuarioColaborador, 0, 1);
        compartirUsuario = CrearBoton("Agregar colaborador", "compartirUsuarioMyg", CompartirUsuarioAsync);
        acceso.Controls.Add(compartirUsuario, 1, 1); raiz.Controls.Add(acceso, 0, 3);

        var barra = new WinForms.FlowLayoutPanel { Dock = WinForms.DockStyle.Fill, WrapContents = false, AutoScroll = true };
        actualizar = CrearBoton("Actualizar", "actualizarProyectosNube", RefrescarInternoAsync);
        abrir = CrearBoton("Abrir proyecto", "abrirProyectoNube", AbrirAsync);
        publicar = CrearBoton("Crear / publicar", "publicarProyectoNube", PublicarAsync);
        pendientes = CrearBoton("Publicaciones pendientes", "publicacionesPendientesNube", PendientesAsync);
        descargar = CrearBoton("Descargar copia", "descargarProyectoNube", DescargarAsync);
        eliminarBase = CrearBoton("Eliminar base", "eliminarBaseNube", EliminarBaseAsync);
        foreach (var boton in new[] { actualizar, abrir, publicar, pendientes, descargar, eliminarBase })
        { boton.AutoSize = true; barra.Controls.Add(boton); }
        cancelarPublicacion = MYGProyectoUI.Boton("Cancelar publicación");
        cancelarPublicacion.Name = "cancelarPublicacionNube";
        cancelarPublicacion.AutoSize = true;
        cancelarPublicacion.Dock = WinForms.DockStyle.Fill;
        cancelarPublicacion.Visible = false;
        cancelarPublicacion.Click += (_, _) =>
        {
            if (cancelacionPublicacion is null) return;
            cancelacionPublicacion.Cancel();
            cancelarPublicacion.Enabled = false;
            InformarProgresoPublicacion("Cancelando; se conservará el intento");
        };
        titulo.Controls.Add(cancelarPublicacion, 2, 0);
        raiz.Controls.Add(barra, 0, 4); raiz.Controls.Add(detalle, 0, 5); Controls.Add(raiz);

        propios.SelectionChanged += (_, _) => CambioSeleccion();
        compartidos.SelectionChanged += (_, _) => CambioSeleccion();
        paginas.SelectedIndexChanged += (_, _) => CambioSeleccion();
        miembros.SelectionChanged += (_, _) => ActualizarAcciones();
        solicitudes.SelectionChanged += (_, _) => ActualizarAcciones();
        sesion.Cambio += CambioSesion;
        relojPublicacion.Tick += (_, _) => ActualizarEstadoPublicacion();
        Disposed += (_, _) =>
        {
            sesion.Cambio -= CambioSesion;
            relojPublicacion.Stop(); relojPublicacion.Dispose();
            cancelacionPublicacion?.Cancel(); cancelacionPublicacion?.Dispose(); cancelacionPublicacion = null;
            vida.Cancel(); vida.Dispose();
        };
        FormClosing += (_, e) => { if (ocupado) e.Cancel = true; };
        ActualizarAcciones();
    }

    public void ActualizarCliente(ClienteSupabase? nuevo)
    {
        cliente = nuevo;
        if (IsDisposed || Disposing) return;
        LimpiarProyectos(); ActualizarAcciones();
    }

    internal void InformarErrorConfiguracion(string? mensaje) => errorConfiguracion = mensaje;
    internal bool OperacionEnCurso => ocupado;

    internal CancellationToken ComenzarPublicacion()
    {
        if (IsDisposed || Disposing) throw new ObjectDisposedException(nameof(NubeForm));
        if (cancelacionPublicacion is not null)
            throw new InvalidOperationException("Espere a que termine la publicación actual.");
        cancelacionPublicacion = CancellationTokenSource.CreateLinkedTokenSource(vida.Token);
        confirmacionPublicacionRecibida = false;
        cancelarPublicacion.Visible = cancelarPublicacion.Enabled = true;
        espacioCancelarPublicacion.Width = 190;
        tiempoPublicacion.Restart(); relojPublicacion.Start();
        InformarProgresoPublicacion("Preparando publicación");
        return cancelacionPublicacion.Token;
    }

    internal void InformarProgresoPublicacion(string fase)
    {
        if (IsDisposed || Disposing || cancelacionPublicacion is null) return;
        fasePublicacion = cancelacionPublicacion.IsCancellationRequested && !confirmacionPublicacionRecibida
            ? "Cancelando; se conservará el intento" : fase;
        ActualizarEstadoPublicacion();
    }

    internal void PublicacionConfirmada()
    {
        if (IsDisposed || Disposing) return;
        // Después del ACK hay que cerrar el pendiente local aunque el usuario
        // hubiera pulsado Cancelar cuando la respuesta ya estaba en camino.
        confirmacionPublicacionRecibida = true;
        cancelarPublicacion.Enabled = false;
        fasePublicacion = "Publicación confirmada; cerrando el intento local";
        ActualizarEstadoPublicacion();
    }

    internal void TerminarPublicacion()
    {
        if (IsDisposed || Disposing) return;
        relojPublicacion.Stop(); tiempoPublicacion.Stop(); fasePublicacion = null;
        cancelarPublicacion.Visible = cancelarPublicacion.Enabled = false;
        espacioCancelarPublicacion.Width = 0;
        cancelacionPublicacion?.Dispose(); cancelacionPublicacion = null;
        confirmacionPublicacionRecibida = false;
        ActualizarAcciones();
    }

    internal void InformarResultadoPublicacion(string mensaje)
    {
        if (!IsDisposed && !Disposing) detalle.Text = mensaje;
    }

    internal async Task MostrarPublicacionConfirmadaAsync(ProyectoNube proyecto)
    {
        await RefrescarInternoAsync();
        foreach (WinForms.DataGridViewRow fila in propios.Rows)
            if (fila.Tag is ProyectoNube p && p.Id == proyecto.Id)
            {
                paginas.SelectedIndex = 0;
                propios.CurrentCell = fila.Cells[0];
                break;
            }
        detalle.Text = $"Publicado: {proyecto.Nombre} · revisión {proyecto.Revision}. "
            + "Seleccione Abrir proyecto cuando quiera descargar y trabajar con la copia.";
    }

    private void ActualizarEstadoPublicacion()
    {
        if (!IsDisposed && !Disposing && fasePublicacion is not null)
            estado.Text = tiempoPublicacion.Elapsed.ToString(@"hh\:mm\:ss") + " · " + fasePublicacion;
    }

    public Task RefrescarAsync() => EjecutarAsync(RefrescarInternoAsync);

    /// <summary>Abre la administración de la obra elegida desde su menú de inicio.</summary>
    public async Task SeleccionarProyectoAsync(Guid id, bool cargarColaboracion = true)
    {
        if (id == Guid.Empty) throw new ArgumentException("Seleccione una obra válida.", nameof(id));
        if (IsDisposed || Disposing) throw new ObjectDisposedException(nameof(NubeForm));
        if (ocupado) throw new InvalidOperationException("Espere a que termine la operación de Nube MYG.");
        ocupado = true; ActualizarAcciones();
        try
        {
            await RefrescarInternoAsync();
            foreach (var tabla in new[] { propios, compartidos })
                foreach (WinForms.DataGridViewRow fila in tabla.Rows)
                    if (fila.Tag is ProyectoNube proyecto && proyecto.Id == id)
                    {
                        paginas.SelectedIndex = tabla == propios ? 0 : 1;
                        tabla.CurrentCell = fila.Cells[0];
                        CambioSeleccion();
                        if (cargarColaboracion) await CargarColaboracionAsync();
                        return;
                    }
            throw new InvalidOperationException("La obra no está disponible para su cuenta. Actualice sus permisos e inténtelo de nuevo.");
        }
        finally { ocupado = false; ActualizarAcciones(); }
    }

    // Se prepara oculta: el llamador muestra el explorador sólo si conexión y
    // listado terminan correctamente. Los errores deben llegar a Inicio.
    public async Task ConectarYRefrescarAsync()
    {
        if (IsDisposed || Disposing) throw new ObjectDisposedException(nameof(NubeForm));
        if (ocupado) throw new InvalidOperationException("Espere a que termine la operación de Nube MYG.");
        ocupado = true; ActualizarAcciones();
        try { await ConectarAsync(); }
        finally { ocupado = false; ActualizarAcciones(); }
    }

    private static WinForms.DataGridView Tabla(string nombre)
    {
        var tabla = MYGBibliotecaUI.Tabla();
        tabla.Name = nombre; tabla.ReadOnly = true; tabla.MultiSelect = false;
        tabla.SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect;
        tabla.AutoSizeColumnsMode = WinForms.DataGridViewAutoSizeColumnsMode.Fill;
        return tabla;
    }

    private static WinForms.DataGridView TablaProyectos(string nombre)
    {
        var tabla = Tabla(nombre);
        tabla.Columns.Add("Nombre", "Proyecto"); tabla.Columns.Add("Codigo", "Código");
        tabla.Columns.Add("Rol", "Mi rol"); tabla.Columns.Add("Revision", "Revisión");
        tabla.Columns.Add("Tamano", "Tamaño en nube");
        tabla.Columns.Add("Sincronizacion", "Última sincronización");
        tabla.Columns.Add("Tipo", "Tipo");
        tabla.Columns["Tipo"]!.DisplayIndex = 1;
        tabla.Columns["Nombre"]!.FillWeight = 150;
        tabla.Columns["Revision"]!.FillWeight = 65;
        tabla.Columns["Tamano"]!.FillWeight = 100;
        tabla.Columns["Sincronizacion"]!.FillWeight = 160;
        tabla.Columns["Tipo"]!.FillWeight = 110;
        return tabla;
    }

    private WinForms.Button CrearBoton(string texto, string nombre, Func<Task> accion)
    {
        var boton = MYGProyectoUI.Boton(texto); boton.Name = nombre;
        boton.Height = 34; boton.Margin = new(3); MYGAnimacionUI.PrepararBoton(boton);
        boton.Click += async (_, _) => await EjecutarAsync(accion);
        acciones.Add(boton); return boton;
    }

    private ProyectoNube? Seleccionado => (paginas.SelectedIndex == 0 ? propios : compartidos)
        .CurrentRow?.Tag as ProyectoNube;
    private bool EsBasePrivada => Seleccionado?.Alcance == "base";
    private bool PuedeAdministrar => !EsBasePrivada && (Seleccionado?.Rol is "propietario" or "administrador");
    private string UsuarioMygActual => (sesion.Credencial?.Usuario ?? "").Trim().ToLowerInvariant();
    private bool IdentidadValida => sesion.Autorizado && UsuarioMygActual.Length > 0
        && cliente?.SesionIniciada == true && cliente.UsuarioMygSesion == UsuarioMygActual;

    private readonly record struct CuentaNube(ClienteSupabase Cliente, string UsuarioMyg, string UsuarioId);

    private CuentaNube CapturarCuenta()
    {
        var actual = RequerirCliente();
        return new(actual, UsuarioMygActual, actual.UsuarioId!);
    }

    private void RevalidarCuenta(CuentaNube cuenta)
    {
        RequerirLicencia();
        if (!IdentidadValida || !ReferenceEquals(cliente, cuenta.Cliente)
            || UsuarioMygActual != cuenta.UsuarioMyg || cliente?.UsuarioId != cuenta.UsuarioId)
            throw new InvalidOperationException("La cuenta MYG cambió durante la operación. Vuelva a conectar la nube con el usuario actual.");
    }

    private void CambioSesion()
    {
        if (IsDisposed || Disposing) return;
        if (InvokeRequired) { BeginInvoke((Action)CambioSesion); return; }
        if (!IdentidadValida) LimpiarProyectos();
        ActualizarAcciones();
    }

    private void CambioSeleccion()
    {
        proyectoColaboracion = null; miembros.Rows.Clear(); solicitudes.Rows.Clear();
        detalle.Text = Seleccionado is { } p ? $"{p.Nombre} · {ExploradorNubePresentacion.TipoProyecto(p)} · {p.Rol} · revisión {p.Revision} · {FormatearTamano(p.TamanoBytes)}"
            + (p.EliminacionPendiente ? ". Eliminación pendiente: el propietario puede reintentar para completar la limpieza de la nube."
                : EsBasePrivada ? ". Abra la base para ver todas sus obras. Los cambios se sincronizan en el mismo archivo SQLite." : "")
            : "No hay proyecto seleccionado. Actualice la lista o publique un proyecto local.";
        ActualizarAcciones();
    }

    private void LimpiarProyectos()
    {
        propios.Rows.Clear(); compartidos.Rows.Clear(); miembros.Rows.Clear(); solicitudes.Rows.Clear();
        proyectoColaboracion = null;
    }

    private void ActualizarAcciones()
    {
        if (IsDisposed || Disposing) return;
        bool configurado = cliente is not null, conectada = IdentidadValida;
        bool disponible = !ocupado && sesion.Autorizado;
        foreach (var boton in acciones) boton.Enabled = disponible && conectada;
        conectar.Enabled = disponible && configurado && ConectarMygSolicitado is not null;
        usuarioMyg.Text = "Usuario MYG: " + (sesion.Credencial?.Usuario ?? "sin sesión");
        bool seleccion = disponible && conectada && Seleccionado is not null;
        bool enEliminacion = Seleccionado?.EliminacionPendiente == true;
        abrir.Enabled = seleccion && !enEliminacion && AbrirSolicitado is not null;
        descargar.Enabled = seleccion && !enEliminacion && DescargarSolicitado is not null;
        publicar.Enabled = disponible && conectada && PublicarSolicitado is not null;
        pendientes.Enabled = disponible && conectada && PendientesSolicitado is not null;
        eliminarBase.Enabled = seleccion && ExploradorNubePresentacion.PuedeEliminarBase(Seleccionado);
        eliminarBase.Text = enEliminacion ? "Reintentar eliminación" : "Eliminar base";
        colaboracion.Enabled = seleccion && !EsBasePrivada && !enEliminacion;
        compartirUsuario.Enabled = usuarioColaborador.Enabled = seleccion && PuedeAdministrar && !enEliminacion;
        bool cargado = seleccion && !enEliminacion && proyectoColaboracion == Seleccionado?.Id && PuedeAdministrar;
        aceptar.Enabled = rechazar.Enabled = cargado && solicitudes.CurrentRow?.Tag is SolicitudNube s && s.Estado == "pendiente";
        bool miembroEditable = miembros.CurrentRow?.Tag is MiembroNube m && m.Rol != "propietario";
        cambiarRol.Enabled = retirar.Enabled = permisosMiembro.Enabled = cargado && miembroEditable;
        rol.Enabled = cargado;
        estado.Text = !sesion.Autorizado ? "Se requiere una licencia MYG autorizada"
            : !configurado ? "Sin configurar" : ocupado ? "Procesando…"
            : conectada ? "Conectado con su usuario MYG" : "Pendiente de conexión MYG";
        ActualizarEstadoPublicacion();
    }

    private void RequerirLicencia()
    {
        if (!sesion.Autorizado)
            throw new InvalidOperationException("Inicie una sesión MYG con licencia autorizada para usar la nube.");
    }

    private ClienteSupabase RequerirCliente()
    {
        RequerirLicencia();
        var actual = cliente ?? throw new InvalidOperationException("No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
        if (!IdentidadValida)
            throw new InvalidOperationException("Conecte la nube con su usuario MYG para continuar.");
        return actual;
    }

    private ProyectoNube RequerirProyecto() => Seleccionado
        ?? throw new InvalidOperationException("Seleccione un proyecto.");

    private void ExigirProyectoDisponible()
    {
        if (Seleccionado?.EliminacionPendiente == true)
            throw new InvalidOperationException("La eliminación de este proyecto está pendiente. El propietario debe completarla desde Eliminar base; las copias locales se conservan.");
    }

    private async Task EjecutarAsync(Func<Task> accion)
    {
        if (ocupado || IsDisposed || Disposing) return;
        ocupado = true; ActualizarAcciones();
        Exception? error = null;
        try { await accion(); }
        catch (OperationCanceledException) when (vida.IsCancellationRequested) { }
        catch (Exception ex)
        {
            if (!IdentidadValida) LimpiarProyectos();
            error = ex;
        }
        finally { ocupado = false; ActualizarAcciones(); }
        if (error is not null && !IsDisposed && !Disposing)
        { detalle.Text = error.Message; MYGProyectoUI.Error(this, error); }
    }

    private async Task ConectarAsync()
    {
        RequerirLicencia();
        if (cliente is null) throw new InvalidOperationException(errorConfiguracion
            ?? "No se encontró la conexión de Nube MYG. Solicite a soporte que revise la instalación.");
        string usuario = UsuarioMygActual;
        if (ConectarMygSolicitado is null) throw new InvalidOperationException("El ingreso único MYG no está disponible.");
        await ConectarMygSolicitado();
        RequerirLicencia();
        if (UsuarioMygActual != usuario)
            throw new InvalidOperationException("La cuenta MYG cambió durante la conexión. Reintente con el usuario actual.");
        await RefrescarInternoAsync();
    }

    private async Task RefrescarInternoAsync()
    {
        Guid? anterior = Seleccionado?.Id;
        var cuenta = CapturarCuenta();
        var lista = await cuenta.Cliente.ListarProyectosAsync(vida.Token);
        RevalidarCuenta(cuenta); LimpiarProyectos();
        foreach (var proyecto in lista)
        {
            var tabla = proyecto.Rol == "propietario" ? propios : compartidos;
            int indice = tabla.Rows.Add(proyecto.Nombre, proyecto.Codigo, proyecto.Rol, proyecto.Revision,
                FormatearTamano(proyecto.TamanoBytes), ExploradorNubePresentacion.FormatearSincronizacion(proyecto.ActualizadoEn),
                ExploradorNubePresentacion.TipoProyecto(proyecto));
            tabla.Rows[indice].Tag = proyecto;
            tabla.Rows[indice].Cells["Nombre"].ToolTipText = proyecto.Nombre;
            tabla.Rows[indice].Cells["Tipo"].ToolTipText = proyecto.Alcance == "base"
                ? "Un único archivo SQLite con todas sus obras y una revisión compartida. Abra la base para ver su lista de obras."
                : "Obra independiente con sus presupuestos y permisos de colaboración.";
            tabla.Rows[indice].Cells["Sincronizacion"].ToolTipText = proyecto.ActualizadoEn.HasValue
                ? "Último cambio confirmado en la nube; se muestra en el huso horario del equipo. UTC: "
                    + proyecto.ActualizadoEn.Value.ToUniversalTime().ToString("u", CultureInfo.InvariantCulture)
                : "El servidor todavía no informa la fecha del último cambio confirmado.";
            tabla.Rows[indice].Cells["Tamano"].ToolTipText = proyecto.TamanoBytes is { } bytes
                ? bytes.ToString("N0", CultureInfo.CurrentCulture) + " bytes · " + (proyecto.TamanoFormato switch
                {
                    "sqlite" => "archivo SQLite almacenado, sin comprimir",
                    "gzip" => "paquete comprimido almacenado y transferido",
                    "json" => "tamaño lógico del contenido JSON en el servidor",
                    _ => "tamaño informado por el servidor"
                })
                : "El servidor aún no informa el tamaño. Instale la migración de bases y obras.";
            if (proyecto.Id == anterior) tabla.CurrentCell = tabla.Rows[indice].Cells[0];
        }
        CambioSeleccion();
        if (lista.Count == 0) detalle.Text = "Su cuenta no tiene proyectos autorizados. Publique uno o pida a su administrador que agregue su usuario MYG.";
    }

    private static string FormatearTamano(long? bytes)
    {
        if (bytes is null || bytes < 0) return "No disponible";
        if (bytes < 1024) return bytes.Value.ToString("N0", CultureInfo.CurrentCulture) + " B";
        if (bytes < 1024 * 1024) return (bytes.Value / 1024d).ToString("N1", CultureInfo.CurrentCulture) + " KiB";
        if (bytes < 1024L * 1024 * 1024) return (bytes.Value / (1024d * 1024)).ToString("N2", CultureInfo.CurrentCulture) + " MiB";
        return (bytes.Value / (1024d * 1024 * 1024)).ToString("N2", CultureInfo.CurrentCulture) + " GiB";
    }

    private async Task EliminarBaseAsync()
    {
        var proyecto = RequerirProyecto();
        if (!ExploradorNubePresentacion.PuedeEliminarBase(proyecto))
            throw new InvalidOperationException("Solo el propietario puede eliminar una base completa de la nube.");
        var cuenta = CapturarCuenta();
        using var confirmar = new EliminarBaseNubeForm(proyecto.Nombre, proyecto.EliminacionPendiente);
        if (confirmar.ShowDialog(this) != WinForms.DialogResult.OK) return;
        RevalidarCuenta(cuenta);
        if (Seleccionado?.Id != proyecto.Id)
            throw new InvalidOperationException("La selección cambió. Vuelva a elegir la base que desea eliminar.");
        bool terminado = false;
        var progreso = new Progress<string>(mensaje =>
        {
            if (!terminado && !IsDisposed && !Disposing)
            { estado.Text = "Eliminación en curso…"; detalle.Text = mensaje; }
        });
        ResultadoEliminacionBaseNube resultado;
        try
        {
            resultado = await cuenta.Cliente.EliminarBaseAsync(proyecto.Id, vida.Token, progreso);
            terminado = true;
            RevalidarCuenta(cuenta);
            if (resultado.BaseId != proyecto.Id)
                throw new InvalidOperationException("La confirmación de eliminación corresponde a otra base. Actualice la lista.");
        }
        catch (NubeException error)
        {
            terminado = true;
            RevalidarCuenta(cuenta);
            // Refrescar permite recuperar el trabajo durable si el fallo ocurrió
            // después de iniciarlo. No sustituir el error original si no hay red.
            try { await RefrescarInternoAsync(); }
            catch (Exception ex) when (ex is NubeException or System.IO.IOException) { }
            throw new NubeException(error.Message + "\nLa eliminación no quedó confirmada. Actualice la lista y reintente la misma base; las copias locales se conservan.",
                esErrorDeConexion: error.EsErrorDeConexion, necesitaIniciarSesion: error.NecesitaIniciarSesion,
                accesoDenegado: error.AccesoDenegado, codigo: error.Codigo, vinculoNoVerificado: error.VinculoNoVerificado);
        }
        finally { terminado = true; }
        try { await RefrescarInternoAsync(); }
        catch (NubeException error)
        {
            throw new InvalidOperationException("El servidor confirmó la eliminación, pero no se pudo actualizar la lista. Pulse Actualizar.\n" + error.Message, error);
        }
        detalle.Text = "Eliminación confirmada en la nube: " + resultado.ProyectosEliminados
            + " proyecto(s) y " + resultado.ObjetosEliminados + " objeto(s) asociados. Las copias locales se conservan."
            + (resultado.AdjuntosAnterioresConservados ? " Los adjuntos antiguos potencialmente compartidos se conservan." : "");
    }

    private async Task CargarColaboracionAsync()
    {
        ExigirProyectoDisponible();
        var p = RequerirProyecto();
        if (p.Alcance == "base") throw new InvalidOperationException(
            "La base completa es privada. Ábrala y use el menú ⋮ de cada obra para administrar sus colaboradores.");
        var cuenta = CapturarCuenta();
        var listaMiembros = await cuenta.Cliente.ListarMiembrosAsync(p.Id, vida.Token);
        RevalidarCuenta(cuenta);
        var listaSolicitudes = PuedeAdministrar ? await cuenta.Cliente.ListarSolicitudesAsync(p.Id, vida.Token) : null;
        RevalidarCuenta(cuenta);
        if (Seleccionado?.Id != p.Id) return;
        miembros.Rows.Clear(); solicitudes.Rows.Clear();
        int nombresPendientes = 0;
        foreach (var miembro in listaMiembros)
        {
            string? nombreMyg = miembro.ObtenerUsuarioMyg(cuenta.UsuarioId, cuenta.UsuarioMyg);
            if (nombreMyg is null) nombresPendientes++;
            int indice = miembros.Rows.Add(nombreMyg ?? "Usuario MYG no disponible", miembro.Rol, ResumenPermisos(miembro));
            var fila = miembros.Rows[indice];
            fila.Tag = miembro;
            fila.Cells["UsuarioMyg"].ToolTipText = nombreMyg is null
                ? "Falta recibir el nombre MYG de esta cuenta. Identificador interno: " + miembro.UsuarioId
                : "Usuario MYG: " + nombreMyg;
        }
        if (listaSolicitudes is not null) foreach (var solicitud in listaSolicitudes)
        {
            int indice = solicitudes.Rows.Add(solicitud.UsuarioId, solicitud.Estado);
            solicitudes.Rows[indice].Tag = solicitud;
        }
        proyectoColaboracion = p.Id;
        detalle.Text = PuedeAdministrar ? "Miembros y permisos consultados en el servidor. Agregue usuarios MYG o seleccione un miembro para administrarlo."
            : "Miembros consultados. Solo propietario o administrador pueden gestionar solicitudes y roles.";
        if (nombresPendientes > 0)
            detalle.Text = "Falta recibir el usuario MYG de " + nombresPendientes
                + " miembro(s). Revise la vinculación de estas cuentas en Supabase.";
    }

    private async Task ResolverAsync(bool permitir)
    {
        var p = RequerirProyecto();
        if (!PuedeAdministrar || proyectoColaboracion != p.Id
            || solicitudes.CurrentRow?.Tag is not SolicitudNube solicitud || solicitud.Estado != "pendiente")
            throw new InvalidOperationException("Seleccione una solicitud pendiente de un proyecto que administra.");
        string nuevoRol = rol.SelectedItem as string ?? "lector";
        var cuenta = CapturarCuenta();
        await cuenta.Cliente.ResolverSolicitudAsync(p.Id, solicitud.UsuarioId, nuevoRol, permitir, vida.Token);
        RevalidarCuenta(cuenta); await CargarColaboracionAsync();
    }

    private async Task CambiarRolAsync(bool eliminar)
    {
        var p = RequerirProyecto();
        if (!PuedeAdministrar || proyectoColaboracion != p.Id
            || miembros.CurrentRow?.Tag is not MiembroNube miembro || miembro.Rol == "propietario")
            throw new InvalidOperationException("Seleccione un miembro editable del proyecto que administra.");
        var cuenta = CapturarCuenta();
        if (eliminar && WinForms.MessageBox.Show(this,
            "¿Retirar el acceso de este miembro al proyecto?", "Colaboración MYG",
            WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question) != WinForms.DialogResult.Yes) return;
        RevalidarCuenta(cuenta);
        await cuenta.Cliente.CambiarRolAsync(p.Id, miembro.UsuarioId,
            eliminar ? null : rol.SelectedItem as string ?? "lector", vida.Token);
        RevalidarCuenta(cuenta); await CargarColaboracionAsync();
    }

    private static string ResumenPermisos(MiembroNube miembro)
    {
        if (miembro.Rol == "lector") return "Todos";
        if (miembro.PermisosModulos is not { } permisos) return "Sin restricciones por módulo (servidor anterior)";
        var lectura = new List<string>();
        if (!permisos.Acu) lectura.Add("ACU");
        if (!permisos.Especificaciones) lectura.Add("Especificaciones");
        if (!permisos.MetradosExcel) lectura.Add("Metrados Excel");
        return lectura.Count == 0 ? "Ninguno" : string.Join(", ", lectura);
    }

    private async Task CompartirUsuarioAsync()
    {
        var p = RequerirProyecto();
        if (!PuedeAdministrar) throw new InvalidOperationException("Solo el propietario o administrador puede agregar colaboradores.");
        string usuario = usuarioColaborador.Text.Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(usuario)) throw new InvalidOperationException("Introduzca el usuario MYG del colaborador.");
        var cuenta = CapturarCuenta();
        using var elegir = new PermisosModulosNubeForm(usuario, null, permitirRol: true);
        if (elegir.ShowDialog(this) != WinForms.DialogResult.OK) return;
        RevalidarCuenta(cuenta);
        await cuenta.Cliente.CompartirConUsuarioMygAsync(p.Id, usuario, elegir.Rol, elegir.Permisos, vida.Token);
        RevalidarCuenta(cuenta); usuarioColaborador.Clear();
        await CargarColaboracionAsync();
        detalle.Text = "Acceso confirmado por el servidor para el usuario MYG indicado. El colaborador puede actualizar Compartidos conmigo.";
    }

    private async Task CambiarPermisosAsync()
    {
        var p = RequerirProyecto();
        if (!PuedeAdministrar || proyectoColaboracion != p.Id
            || miembros.CurrentRow?.Tag is not MiembroNube miembro || miembro.Rol == "propietario")
            throw new InvalidOperationException("Seleccione un miembro editable del proyecto que administra.");
        var cuenta = CapturarCuenta();
        using var elegir = new PermisosModulosNubeForm(
            miembro.ObtenerUsuarioMyg(cuenta.UsuarioId, cuenta.UsuarioMyg) ?? "no disponible (vinculación pendiente)",
            miembro.PermisosModulos, permitirRol: false, miembro.Rol);
        if (elegir.ShowDialog(this) != WinForms.DialogResult.OK) return;
        RevalidarCuenta(cuenta);
        await cuenta.Cliente.CambiarPermisosMiembroAsync(p.Id, miembro.UsuarioId, elegir.Permisos, vida.Token);
        RevalidarCuenta(cuenta); await CargarColaboracionAsync();
        detalle.Text = "Permisos por módulo confirmados por el servidor. Los módulos bloqueados permanecen visibles en solo lectura.";
    }

    private async Task AbrirAsync()
    {
        ExigirProyectoDisponible();
        var p = RequerirProyecto(); var cuenta = CapturarCuenta();
        if (AbrirSolicitado is null) throw new InvalidOperationException("La apertura no está disponible.");
        await AbrirSolicitado(p);
        RevalidarCuenta(cuenta);
        Hide();
    }

    private async Task DescargarAsync()
    {
        ExigirProyectoDisponible();
        var p = RequerirProyecto(); var cuenta = CapturarCuenta();
        if (DescargarSolicitado is null) throw new InvalidOperationException("La descarga no está disponible.");
        await DescargarSolicitado(p);
        RevalidarCuenta(cuenta);
    }

    private async Task PublicarAsync()
    {
        var cuenta = CapturarCuenta();
        if (PublicarSolicitado is null) throw new InvalidOperationException("La publicación no está disponible.");
        await PublicarSolicitado(); RevalidarCuenta(cuenta);
    }

    private async Task PendientesAsync()
    {
        var cuenta = CapturarCuenta();
        if (PendientesSolicitado is null) throw new InvalidOperationException("La lista de publicaciones pendientes no está disponible.");
        await PendientesSolicitado(); RevalidarCuenta(cuenta);
    }

}
