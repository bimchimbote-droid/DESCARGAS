using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using MYG.Colaboracion;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private async Task PrepararSincronizacionBaseAsync(EditorForm origen)
    {
        if (!CopiaSqliteNube.EsBase(origen.RutaProyecto)) return;
        foreach (var editor in EditoresAbiertos.Where(e => e != origen && MismaRuta(e.RutaProyecto, origen.RutaProyecto)))
            await editor.GuardarEdicionBaseNubeAsync();
    }

    private async Task ActualizarEditoresBaseAsync(EditorForm origen, bool recargarDocumentos)
    {
        if (!CopiaSqliteNube.EsBase(origen.RutaProyecto)) return;
        foreach (var editor in EditoresAbiertos.Where(e => e != origen && MismaRuta(e.RutaProyecto, origen.RutaProyecto)))
            await editor.ActualizarEdicionBaseNubeAsync(recargarDocumentos);
    }

    // Publicar el archivo completo debe incluir también borradores de otras
    // pestañas, tanto si la base es local como si ya está vinculada a nube.
    private async Task PrepararPublicacionBaseAsync(string ruta)
    {
        foreach (var editor in EditoresAbiertos.Where(e => MismaRuta(e.RutaProyecto, ruta)))
            await editor.GuardarEdicionBaseNubeAsync();
    }
}

internal sealed partial class EditorForm
{
    private void ExigirObraPresenteEnBase()
    {
        if (obraAusenteEnBaseNube)
            throw new InvalidOperationException("La obra ya no está en la revisión recibida de la base. Su documento abierto se conserva; guarde una copia local independiente antes de cerrarlo.");
    }

    internal async Task GuardarEdicionBaseNubeAsync()
    {
        if (IsDisposed || Disposing) return;
        ExigirObraPresenteEnBase();
        if (ocupado || actualizandoNube)
            throw new InvalidOperationException("Otra obra de esta base tiene una operación en curso. Espere antes de sincronizar.");
        if (string.IsNullOrWhiteSpace(archivo) || !File.Exists(archivo))
            throw new InvalidOperationException("Guarde la obra en una base SQLite antes de publicar o sincronizar.");
        panelCronograma?.GuardarTiempoTrabajoPendiente();
        Sincronizar();
        ocupado = true; actualizandoNube = true;
        try
        {
            EstadoSesion();
            var origen = documento;
            string ruta = archivo, firmaAnterior = firmaGuardada;
            var guardado = await Task.Run(() =>
            {
                string firma = MYGProyectoStorage.Firma(origen);
                if (firma == firmaAnterior) return (Documento: origen, Firma: firma, Escrito: false);
                var copia = MYGProyectoStorage.Copia(origen);
                MYGProyectoStorage.Guardar(ruta, copia);
                CopiaSqliteNube.MarcarCambio(ruta, copia.Id);
                MYGIndiceLocal.Registrar(copia, ruta);
                return (Documento: copia, Firma: MYGProyectoStorage.Firma(copia), Escrito: true);
            });
            documento = guardado.Documento; firmaGuardada = guardado.Firma;
            if (guardado.Escrito)
            {
                ProyectoGuardado?.Invoke(archivo);
                Refrescar();
            }
            ActualizarIndicadorArchivo(false);
            RecargarVinculoNube();
        }
        finally
        {
            ocupado = false; actualizandoNube = false;
            ActualizarEstadoNube(); EstadoSesion();
        }
    }

    internal async Task ActualizarEdicionBaseNubeAsync(bool recargarDocumento)
    {
        if (IsDisposed || Disposing) return;
        if (ocupado || actualizandoNube)
            throw new InvalidOperationException("Otra obra de la base está ocupada. Se conserva su documento abierto.");
        ocupado = true; actualizandoNube = true;
        try
        {
            if (recargarDocumento)
            {
                var origen = documento;
                string ruta = archivo, firmaAnterior = firmaGuardada;
                var lectura = await Task.Run(() =>
                {
                    // Nunca sustituir un borrador que apareció después de la
                    // preparación; el coordinador conserva también esos casos.
                    if (MYGProyectoStorage.Firma(origen) != firmaAnterior)
                        throw new InvalidOperationException("La otra obra conserva un borrador local. Guarde una copia antes de recargar la base completa.");
                    if (!MYGBaseDatos.ListarProyectos(ruta).Any(p => p.Id == origen.Id))
                        return (Documento: (MYGProyectoDocumento)null, Firma: firmaAnterior);
                    var nuevo = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, origen.Id);
                    return (Documento: nuevo, Firma: MYGProyectoStorage.Firma(nuevo));
                });
                if (lectura.Documento is null)
                {
                    obraAusenteEnBaseNube = true;
                    estado.Text = "La obra ya no está en la base recibida. Se conserva su documento abierto para guardar una copia local.";
                    return;
                }
                obraAusenteEnBaseNube = false;
                documento = lectura.Documento; firmaGuardada = lectura.Firma;
                undo.Clear(); redo.Clear();
                Refrescar(); ActualizarIndicadorArchivo(false);
            }
            RecargarVinculoNube();
        }
        finally
        {
            ocupado = false; actualizandoNube = false;
            ActualizarEstadoNube(); EstadoSesion();
        }
    }
}
