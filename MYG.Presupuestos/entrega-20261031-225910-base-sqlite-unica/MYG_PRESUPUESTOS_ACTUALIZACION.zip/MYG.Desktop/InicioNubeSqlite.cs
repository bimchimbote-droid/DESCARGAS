#nullable enable
using System.IO;
using MYG.Colaboracion;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private ArchivoPublicacionSqlitePendiente PublicacionesSqliteDe(ClienteSupabase cliente) => new(
        Path.Combine(CarpetaNube, "publicaciones-sqlite"), cliente.UrlServidor, cliente.UsuarioId!);

    private async Task<bool> GestionarPublicacionSqlitePendiente(ClienteSupabase cliente)
    {
        var almacen = PublicacionesSqliteDe(cliente);
        var pendiente = await Task.Run(almacen.Consultar);
        ComprobarClienteActual(cliente);
        if (pendiente is null) return false;
        var opcion = WinForms.MessageBox.Show(ventanaNube,
            "Hay una publicación SQLite pendiente: " + pendiente.Nombre + ".\n\n"
            + "Sí: reintentar el mismo archivo.\nNo: retirar el intento y conservar su copia local.\nCancelar: mantenerlo pendiente.",
            "Publicación pendiente", WinForms.MessageBoxButtons.YesNoCancel, WinForms.MessageBoxIcon.Information);
        ComprobarClienteActual(cliente);
        if (opcion == WinForms.DialogResult.Yes) await PublicarProyectoSqliteNube();
        else if (opcion == WinForms.DialogResult.No)
        {
            string copia = await Task.Run(() => almacen.Retirar(pendiente));
            WinForms.MessageBox.Show(ventanaNube, "El intento se retiró. La copia se conserva en:\n" + copia,
                "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
        }
        return true;
    }

    private async Task PublicarProyectoSqliteNube()
    {
        var cliente = RequerirNube();
        var ventana = ventanaNube ?? throw new InvalidOperationException("Abra Nube MYG para publicar.");
        var almacen = PublicacionesSqliteDe(cliente);
        var pendiente = await Task.Run(almacen.Consultar);
        ComprobarClienteActual(cliente);
        if (pendiente is not null && pendiente.Alcance != "base")
        {
            var retirar = WinForms.MessageBox.Show(ventana,
                "El intento pendiente contiene una obra aislada. Ahora se publica la base SQLite completa. "
                + "¿Retirar ese intento conservando su copia para seleccionar la base completa?",
                "Publicación anterior", WinForms.MessageBoxButtons.OKCancel, WinForms.MessageBoxIcon.Information);
            ComprobarClienteActual(cliente);
            if (retirar != WinForms.DialogResult.OK) return;
            await Task.Run(() => almacen.Retirar(pendiente));
            pendiente = null;
        }
        if (pendiente is null && await GestionarPublicacionBasePendienteAsync(cliente)) return;
        var ct = ventana.ComenzarPublicacion();
        bool confirmado = false;
        try
        {
            ventana.InformarProgresoPublicacion("Comprobando el almacenamiento de archivos SQLite…");
            if (!await cliente.AdmiteSqliteAsync(ct))
                throw new NubeException("Instale 20261030_archivos_sqlite.sql en Supabase antes de publicar. La base local se conserva; no se enviará comprimida ni convertida a JSON.");
            ComprobarClienteActual(cliente);
            if (pendiente is null)
            {
                var legado = await Task.Run(() => PublicacionesDe(cliente).Consultar(), ct);
                if (legado is not null)
                    throw new InvalidOperationException("Hay un intento del formato anterior. Revíselo en Publicaciones pendientes y retírelo conservando su copia antes de iniciar otra publicación.");
                var activo = pestanasProyectos.SelectedTab?.Tag as EditorForm;
                string? rutaAbierta = activo?.RutaProyecto ?? rutaBase;
                using var dialogo = new NubePublicarForm(null, rutaAbierta);
                if (dialogo.ShowDialog(ventana) != WinForms.DialogResult.OK) return;
                ComprobarClienteActual(cliente); ct.ThrowIfCancellationRequested();
                string? origen = dialogo.RutaSQLite;
                if (dialogo.CrearVacia)
                {
                    var nueva = dialogo.Documento ?? throw new InvalidOperationException("No se preparó la base nueva.");
                    origen = Path.Combine(CarpetaNube, "bases-nuevas", Guid.NewGuid().ToString("N"), "base.sqlite");
                    string rutaNueva = origen;
                    await Task.Run(() => MYGProyectoStorage.Guardar(rutaNueva, nueva), ct);
                }
                string fuente = origen ?? throw new InvalidOperationException("Seleccione una base SQLite.");
                string idPrincipal = dialogo.DocumentoPrincipalId ?? throw new InvalidOperationException("La base no contiene obras.");
                ventana.InformarProgresoPublicacion("Preparando una sola base SQLite con todas sus obras…");
                pendiente = await MYGCargaAnimada.EjecutarConProgresoAsync(this,
                    "Preparando la base completa para publicar…", async progreso =>
                    {
                        await PrepararPublicacionBaseAsync(fuente);
                        return await Task.Run(() =>
                        {
                            var documento = MYGBaseDatos.LeerProyecto(fuente, idPrincipal);
                            return almacen.Crear(dialogo.Nombre, "base", documento, fuente, ct, progreso);
                        }, ct);
                    });
            }
            var envio = pendiente;
            ventana.InformarProgresoPublicacion("Verificando la copia local pendiente…");
            envio = await Task.Run(() => almacen.Leer(envio), ct);
            ComprobarClienteActual(cliente); ct.ThrowIfCancellationRequested();
            var progreso = new Progress<string>(texto =>
            {
                if (!ventana.IsDisposed && !confirmado && !ct.IsCancellationRequested)
                    ventana.InformarProgresoPublicacion(texto);
            });
            var remoto = await Task.Run(() => cliente.CrearSqliteAsync(envio.Id, envio.Nombre,
                envio.RutaSQLite, envio.Alcance, envio.DocumentoId, ct, progreso), ct);
            confirmado = true;
            ventana.PublicacionConfirmada();
            // Cerrar el intento solo después de recibir el ACK, sin rehacer la base.
            await Task.Run(() => almacen.Confirmar(envio));
            ComprobarClienteActual(cliente);
            await ventana.MostrarPublicacionConfirmadaAsync(remoto.Proyecto);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested && !confirmado)
        {
            ventana.InformarResultadoPublicacion("Se canceló la espera. La copia local y el identificador del intento se conservan para reintentar desde Publicaciones pendientes.");
        }
        finally { ventana.TerminarPublicacion(); }
    }

    private async Task AbrirProyectoSqliteNube(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        if (remoto.Proyecto.Alcance == "base")
        {
            await AbrirBaseNubeAsync(cliente, remoto);
            return;
        }
        var existente = EditoresAbiertos.FirstOrDefault(e => e.NubeProyectoId == remoto.Proyecto.Id
            && e.NubeServidor == cliente.UrlServidor && e.NubeUsuario == cliente.UsuarioId);
        if (existente is not null)
        {
            await existente.ActualizarNubeAsync(true);
            ComprobarClienteActual(cliente);
            SeleccionarEditor(existente); ventanaNube?.Hide(); return;
        }
        string carpeta = CarpetaDeProyectoNube(cliente, remoto.Proyecto.Id);
        string ruta = Path.Combine(carpeta, "trabajo.sqlite");
        var documento = await MYGCargaAnimada.EjecutarConProgresoAsync(this,
            "Abriendo el archivo SQLite de nube…", async progreso =>
        {
            return await Task.Run(async () =>
            {
                Directory.CreateDirectory(carpeta);
                if (File.Exists(ruta))
                {
                    var vinculo = CopiaSqliteNube.LeerVinculo(ruta, remoto.DocumentoId)
                        ?? throw new InvalidOperationException("La copia existente no tiene un vínculo SQLite válido. Consérvela antes de recuperar otra copia.");
                    SincronizadorProyectoNube.ValidarIdentidad(cliente, vinculo);
                    if (vinculo.ProyectoId != remoto.Proyecto.Id)
                        throw new InvalidOperationException("La copia corresponde a otro proyecto remoto.");
                    // Abrir nunca sustituye borradores locales. La recarga es explícita.
                    return ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, remoto.DocumentoId);
                }
                string temporal = Path.Combine(carpeta, "descarga-" + Guid.NewGuid().ToString("N") + ".sqlite");
                try
                {
                    await cliente.DescargarSqliteAsync(remoto, temporal, progreso: progreso);
                    var local = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(temporal, remoto.DocumentoId);
                    ComprobarClienteActual(cliente);
                    File.Move(temporal, ruta);
                    CopiaSqliteNube.Vincular(ruta, remoto, cliente);
                    return ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(ruta, local.Id);
                }
                finally { if (File.Exists(temporal)) File.Delete(temporal); }
            });
        });
        ComprobarClienteActual(cliente);
        var editor = AbrirEditor(documento, ruta);
        editor.ConfigurarNube(() => clienteNube, MostrarNube,
            PrepararSincronizacionBaseAsync, ActualizarEditoresBaseAsync);
        ventanaNube?.Hide();
    }

    private async Task DescargarProyectoSqliteNube(ClienteSupabase cliente, ProyectoSqliteNube remoto)
    {
        using var dialogo = new WinForms.SaveFileDialog
        {
            Title = "Descargar archivo SQLite sin comprimir", Filter = "Base SQLite (*.sqlite)|*.sqlite",
            FileName = "MYG_NUBE.sqlite", DefaultExt = "sqlite", AddExtension = true
        };
        if (dialogo.ShowDialog(ventanaNube ?? (WinForms.IWin32Window)this) != WinForms.DialogResult.OK) return;
        if (File.Exists(dialogo.FileName)) throw new IOException("Elija un archivo nuevo para conservar la copia existente.");
        string destino = dialogo.FileName;
        await MYGCargaAnimada.EjecutarConProgresoAsync(this, "Descargando el archivo SQLite…", async progreso =>
        {
            await cliente.DescargarSqliteAsync(remoto, destino, progreso: progreso);
            return true;
        });
        ComprobarClienteActual(cliente);
        WinForms.MessageBox.Show(ventanaNube, "Archivo SQLite descargado desde la revisión " + remoto.Proyecto.Revision + ".",
            "Nube MYG", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information);
    }
}
