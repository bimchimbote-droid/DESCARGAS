using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using MYG.Colaboracion;
using MYG_2027;

/// <summary>Publica y recupera dos obras como un solo SQLite real, sin RPC de bases/obras ni paquetes JSON.</summary>
internal static class BaseSqliteUnicaCheck
{
    private const string Servidor = "https://base-unica.supabase.co";
    private static readonly Guid Usuario = Guid.Parse("718a782e-6d01-4123-bfbc-7b98d47ee894");
    private static int comprobaciones;

    internal static async Task RunAsync()
    {
        comprobaciones = 0;
        string carpeta = Path.Combine(Path.GetTempPath(), "MYG-Base-Unica-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(carpeta);
        try
        {
            string origen = Path.Combine(carpeta, "dos-obras.sqlite");
            var norte = CrearObra("Obra Norte Áncash", "Estructuras", 12.5m, 27.35m);
            var sur = CrearObra("Obra Sur", "Arquitectura", 8.25m, 91.7m);
            MYGProyectoStorage.Guardar(origen, norte);
            MYGProyectoStorage.Guardar(origen, sur);
            var esperados = new[] { norte, sur }.ToDictionary(d => d.Id,
                d => MYGProyectoStorage.Firma(MYGBaseDatos.LeerProyecto(origen, d.Id)));
            string hashOriginal = Hash(origen);
            var almacen = new ArchivoPublicacionSqlitePendiente(Path.Combine(carpeta, "pendientes"), Servidor, Usuario.ToString("D"));
            var pendiente = almacen.Crear("Base única dos obras", "base", norte, origen);
            Exige(pendiente.Alcance == "base" && MYGBaseDatos.ListarProyectos(pendiente.RutaSQLite).Count == 2,
                "preparar la base debe conservar ambas obras dentro de la misma copia congelada.");
            Exige(Hash(origen) == hashOriginal, "preparar la copia cambió el archivo original.");

            using var http = new Transporte(pendiente);
            using var cliente = new ClienteSupabase(Servidor, "sb_publishable_base_unica_sintetica", http);
            await cliente.IniciarSesionAsync("qa@myg.example", "clave_sintetica");
            var publicada = await cliente.CrearSqliteAsync(pendiente.Id, pendiente.Nombre, pendiente.RutaSQLite,
                pendiente.Alcance, pendiente.DocumentoId);
            almacen.Confirmar(pendiente);
            var lista = await cliente.ListarProyectosAsync();
            Exige(lista.Count == 1 && lista[0].Id == pendiente.Id && lista[0].Alcance == "base",
                "la publicación de dos obras debe dejar una sola entrada remota de base.");
            Exige(http.Creaciones == 1 && http.Subidas == 1 && http.Objetos.Count == 1,
                "el flujo debe crear un proyecto remoto y subir un SQLite, sin crear proyectos hijos.");
            Exige(almacen.Consultar() is null && File.Exists(pendiente.RutaSQLite),
                "el ACK debe cerrar el intento y conservar su copia recuperable.");

            var abierta = await cliente.AbrirSqliteAsync(publicada.Proyecto.Id);
            string destino = Path.Combine(carpeta, "descargada.sqlite");
            await cliente.DescargarSqliteAsync(abierta, destino);
            Exige(File.ReadAllBytes(destino).SequenceEqual(File.ReadAllBytes(pendiente.RutaSQLite))
                && Hash(destino) == pendiente.Sha256.ToLowerInvariant() && http.Descargas == 1,
                "la descarga debe conservar exactamente el SQLite publicado y su SHA-256.");
            var recuperadas = MYGBaseDatos.ListarProyectos(destino);
            Exige(recuperadas.Count == 2 && recuperadas.Select(d => d.Id).ToHashSet().SetEquals(esperados.Keys),
                "abrir la descarga debe recuperar las dos identidades originales, sin duplicarlas ni separarlas.");
            foreach (var obra in recuperadas)
            {
                var documento = MYGBaseDatos.LeerProyecto(destino, obra.Id);
                Exige(MYGProyectoStorage.Firma(documento) == esperados[obra.Id],
                    "la descarga perdió presupuestos, partidas o costos de " + obra.Nombre + ".");
            }
            using (var c = new SqliteConnection(new SqliteConnectionStringBuilder
                { DataSource = destino, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString()))
            {
                c.Open(); using var q = c.CreateCommand(); q.CommandText = "PRAGMA integrity_check";
                Exige(Convert.ToString(q.ExecuteScalar()) == "ok", "el archivo descargado no supera integrity_check.");
            }
            CopiaSqliteNube.Vincular(destino, abierta, cliente);
            var editada = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(destino, norte.Id);
            editada.Presupuestos[0].Items[0].Costos.Cantidad = 123.5m;
            MYGProyectoStorage.Guardar(destino, editada);
            var vecina = ArchivoPublicacionSqlitePendiente.CargarDocumentoPortable(destino, sur.Id);
            vecina.Presupuestos[0].Items[0].Costos.Cantidad = 45.25m;
            MYGProyectoStorage.Guardar(destino, vecina);
            var sincronizada = await CopiaSqliteNube.EjecutarAsync(cliente, destino, editada);
            Exige(sincronizada.Vinculo.Revision == 2 && sincronizada.Vinculo.Pendiente is null
                && CopiaSqliteNube.LeerVinculo(destino, sur.Id)!.Revision == 2 && http.Guardados == 1,
                "editar ambas obras debe confirmar una única revisión de la base completa.");
            var reabierta = await cliente.AbrirSqliteAsync(publicada.Proyecto.Id);
            string segundaDescarga = Path.Combine(carpeta, "reabierta.sqlite");
            await cliente.DescargarSqliteAsync(reabierta, segundaDescarga);
            Exige(MYGBaseDatos.ListarProyectos(segundaDescarga).Count == 2
                && MYGBaseDatos.LeerProyecto(segundaDescarga, norte.Id).Presupuestos[0].Items[0].Costos.Cantidad == 123.5m
                && MYGBaseDatos.LeerProyecto(segundaDescarga, sur.Id).Presupuestos[0].Items[0].Costos.Cantidad == 45.25m,
                "volver a descargar la base debe conservar las cantidades editadas de ambas obras.");
            Exige(http.Creaciones == 1 && (await cliente.ListarProyectosAsync()).Count == 1,
                "sincronizar varias obras no debe crear proyectos ni bases adicionales.");
            Exige(Hash(origen) == hashOriginal, "publicar o descargar modificó la base original.");
            Exige(http.Rpc.All(r => r is "myg_nube_sqlite_capacidades" or "myg_nube_sqlite_consultar"
                    or "myg_nube_sqlite_crear" or "myg_nube_sqlite_abrir" or "myg_nube_sqlite_guardar" or "myg_nube_listar"),
                "el flujo pidió capacidades, relaciones de obras o publicación JSON ajenas al protocolo SQLite.");
            Console.WriteLine($"OK Base SQLite única: {comprobaciones} comprobaciones; publicar, descargar, editar cantidades de 2 obras, sincronizar y reabrir con 1 entrada y revisión compartida. Origen intacto, sin JSON ni red.");
        }
        finally { SqliteConnection.ClearAllPools(); Directory.Delete(carpeta, true); }
    }

    private static MYGProyectoDocumento CrearObra(string nombre, string presupuesto, decimal cantidad, decimal precio)
    {
        var documento = MYGProyectoStorage.Nuevo(nombre, presupuesto);
        string id = MYGProyectoStorage.NuevoId();
        documento.Presupuestos[0].Items.Add(new ItemPresupuestoDelphin
        {
            Id = id, IdLocalMYG = id, IdPropuesta = id, TipoPropuesta = "PARTIDA", Posicion = 1,
            Descripcion = "Partida " + nombre, Unidad = "m³", Origen = "MODELO", Estado = "PROPUESTA",
            Costos = new MYGDatosPartida { Cantidad = cantidad, PrecioDirecto = precio }
        });
        return documento;
    }

    private static string Hash(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)).ToLowerInvariant(); }
    private static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
    private static void Exige(bool valor, string detalle)
    { comprobaciones++; if (!valor) throw new InvalidOperationException("Base SQLite única: " + detalle); }

    // Este servidor simulado solo conoce el protocolo SQLite: no implementa
    // AdmiteBases, vínculos de obras ni creación/publicación de contenido JSON.
    private sealed class Transporte(PublicacionSqlitePendiente pendiente) : HttpMessageHandler
    {
        private const string Bucket = "/storage/v1/object/myg-nube-sqlite/";
        internal readonly Dictionary<string, byte[]> Objetos = new(StringComparer.Ordinal);
        internal readonly List<string> Rpc = new();
        internal int Creaciones, Subidas, Descargas, Guardados;
        private long revision = 1;
        private ArchivoSqliteNube? archivo;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage solicitud, CancellationToken ct)
        {
            string ruta = solicitud.RequestUri!.AbsolutePath;
            if (ruta == "/auth/v1/token") return Json(new
            { access_token = "acceso_sintetico", refresh_token = "refresco_sintetico", expires_in = 3600, user = new { id = Usuario } });
            Exige(solicitud.Headers.Authorization?.Scheme == "Bearer" && solicitud.Headers.Contains("apikey"),
                "una operación perdió la identidad autenticada.");
            if (ruta.StartsWith(Bucket, StringComparison.Ordinal))
            {
                string objeto = ruta[Bucket.Length..];
                if (solicitud.Method == HttpMethod.Post)
                {
                    byte[] bytes = await solicitud.Content!.ReadAsByteArrayAsync(ct);
                    Exige(solicitud.Content.Headers.ContentType?.MediaType == "application/vnd.sqlite3"
                        && !solicitud.Content.Headers.ContentEncoding.Any()
                        && bytes.AsSpan(0, 16).SequenceEqual("SQLite format 3\0"u8),
                        "Storage debe recibir SQLite binario sin compresión ni envoltorio JSON.");
                    Exige(objeto == Usuario + "/" + pendiente.Id.ToString("N") + "/" + Hash(bytes) + ".sqlite",
                        "la referencia de Storage no corresponde a la base única y sus bytes.");
                    Exige(Objetos.TryAdd(objeto, bytes), "la publicación intentó subir otro objeto con la misma referencia.");
                    Subidas++; return Json(new { Key = objeto });
                }
                Exige(solicitud.Method == HttpMethod.Get && Objetos.ContainsKey(objeto), "la descarga pidió otro objeto.");
                Descargas++; return new(HttpStatusCode.OK) { Content = new ByteArrayContent(Objetos[objeto]) };
            }
            const string prefijo = "/rest/v1/rpc/";
            if (!ruta.StartsWith(prefijo, StringComparison.Ordinal)) throw new InvalidOperationException("Destino inesperado: " + ruta);
            string funcion = ruta[prefijo.Length..]; Rpc.Add(funcion);
            string texto = await solicitud.Content!.ReadAsStringAsync(ct);
            using var cuerpo = JsonDocument.Parse(texto); var p = cuerpo.RootElement;
            Exige(texto.Length < 2048 && !p.TryGetProperty("p_contenido", out _),
                "una RPC transportó contenido de las obras en vez de metadatos.");
            switch (funcion)
            {
                case "myg_nube_sqlite_capacidades":
                    return Json(new { version = 1, max_bytes = ClienteSupabase.MaxSqliteNubeBytes });
                case "myg_nube_sqlite_consultar":
                    Exige(p.GetProperty("p_id").GetGuid() == pendiente.Id, "se consultó una identidad hija.");
                    return archivo is null ? Json(null) : Json(Descriptor());
                case "myg_nube_sqlite_crear":
                    Exige(++Creaciones == 1 && p.GetProperty("p_id").GetGuid() == pendiente.Id
                        && p.GetProperty("p_alcance").GetString() == "base"
                        && p.GetProperty("p_documento_id").GetString() == pendiente.DocumentoId
                        && p.GetProperty("p_nombre").GetString() == pendiente.Nombre,
                        "la creación debe confirmar una sola base con su identidad original.");
                    archivo = new(p.GetProperty("p_ruta").GetString()!, p.GetProperty("p_sha256").GetString()!, p.GetProperty("p_bytes").GetInt64());
                    Exige(Objetos.TryGetValue(archivo.Ruta, out var datos) && Hash(datos) == archivo.Sha256 && datos.LongLength == archivo.Bytes,
                        "la confirmación no describe el objeto SQLite subido.");
                    return Json(Descriptor());
                case "myg_nube_listar":
                    return Json(archivo is null ? Array.Empty<object>() : new[] { Descriptor() });
                case "myg_nube_sqlite_guardar":
                    Exige(p.GetProperty("p_id").GetGuid() == pendiente.Id && p.GetProperty("p_revision").GetInt64() == revision,
                        "el guardado debe usar la identidad y revisión de la única base.");
                    archivo = new(p.GetProperty("p_ruta").GetString()!, p.GetProperty("p_sha256").GetString()!, p.GetProperty("p_bytes").GetInt64());
                    Exige(Objetos.TryGetValue(archivo.Ruta, out var actualizados) && Hash(actualizados) == archivo.Sha256,
                        "el ACK no corresponde a los bytes de la base modificada.");
                    revision++; Guardados++;
                    return Json(new { estado = "aplicada", revision, operacion_id = p.GetProperty("p_operacion").GetGuid(),
                        archivo_sqlite = new { ruta = archivo.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes } });
                case "myg_nube_sqlite_abrir":
                    Exige(p.GetProperty("p_id").GetGuid() == pendiente.Id && archivo is not null, "se abrió otra base.");
                    return Json(Descriptor());
                default: throw new InvalidOperationException("RPC no disponible en servidor SQLite sin bases/obras: " + funcion);
            }
        }

        private object Descriptor() => new
        {
            id = pendiente.Id, codigo = "MYG-BASE-UNICA", nombre = pendiente.Nombre, rol = "propietario", revision,
            alcance = "base", documento_id = pendiente.DocumentoId,
            archivo_sqlite = new { ruta = archivo!.Ruta, sha256 = archivo.Sha256, bytes = archivo.Bytes },
            permisos_modulos = new { acu = true, especificaciones = true, metrados_excel = true }
        };
        private static HttpResponseMessage Json(object? valor) => new(HttpStatusCode.OK)
        { Content = new StringContent(JsonSerializer.Serialize(valor), Encoding.UTF8, "application/json") };
    }
}
