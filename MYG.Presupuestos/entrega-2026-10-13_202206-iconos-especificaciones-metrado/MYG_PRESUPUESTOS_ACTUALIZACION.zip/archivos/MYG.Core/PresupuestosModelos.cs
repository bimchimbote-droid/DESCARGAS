using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace MYG_2027
{
    // Datos de presupuesto propios de MYG. Los importadores no escriben la base de Delphin.
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MYGGrupoRecurso { ManoObra, Materiales, Equipo, Subcontratos, Subpartidas }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MYGModoCantidad { Directa, Rendimiento, PorcentajeManoObra }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MYGFuenteMetrado { Cantidad, Manual, BIM, Excel }

    public sealed class MYGResponsablePresupuesto
    {
        public string Nombre { get; set; } = "";
        public string Cargo { get; set; } = "";
        public override string ToString() => string.IsNullOrWhiteSpace(Cargo) ? Nombre : Nombre + " · " + Cargo;
    }

    public sealed class MYGCostosPresupuesto
    {
        public string FirmaDatosImportadosDelphin { get; set; }
        public string Moneda { get; set; } = "S/";
        public int DecimalesPrecio { get; set; } = 2;
        public int DecimalesCantidad { get; set; } = 4;
        public decimal GastosGeneralesPorcentaje { get; set; }
        public decimal UtilidadPorcentaje { get; set; }
        public decimal ImpuestoPorcentaje { get; set; }
        public decimal OtrosImpuestosPorcentaje { get; set; }
        public List<MYGInsumo> Insumos { get; set; } = new();
        public List<MYGResponsablePresupuesto> Responsables { get; set; } = new();
    }
    public sealed class MYGInsumo
    {
        // Referencia informativa al catálogo propio. Los datos del presupuesto son una copia.
        public string CatalogoMYGId { get; set; }
        public string CatalogoMYGRuta { get; set; }
        public string Id { get; set; } = MYGProyectoStorage.NuevoId();
        public string Codigo { get; set; } = "";
        // Metadatos opcionales: se conservan en el JSON MYG sin alterar bases nativas.
        public string CodigoAlterno { get; set; } = "";
        public bool UsarCodigoAlterno { get; set; }
        public string GrupoGenerico { get; set; } = "";
        public string Proveedor { get; set; } = "SIN CLASIFICAR";
        public string DescripcionBase { get; set; } = "";
        public decimal? PrecioBase { get; set; }
        public DateTime? FechaBase { get; set; }
        public string UnidadBase { get; set; } = "";
        public string Marca { get; set; } = "";
        public string Especificaciones { get; set; } = "";
        public string ImagenRuta { get; set; } = "";
        public decimal IGVPorcentaje { get; set; }
        public DateTime? FechaCompra { get; set; }
        public string FichaTecnicaRuta { get; set; } = "";
        public bool Habilitado { get; set; } = true;
        public string Descripcion { get; set; } = "";
        public string Unidad { get; set; } = "und";
        public MYGGrupoRecurso Grupo { get; set; } = MYGGrupoRecurso.Materiales;
        public decimal Precio { get; set; }
        public override string ToString() => Codigo + " · " + Descripcion + " (" + Unidad + ")";
    }
    public sealed class MYGDatosPartida
    {
        public string CatalogoMYGId { get; set; }
        public string CatalogoMYGRuta { get; set; }
        public decimal Cantidad { get; set; }
        public MYGFuenteMetrado FuenteMetrado { get; set; } = MYGFuenteMetrado.Cantidad;
        // Precio directo para partidas sin ACU. Se ignora cuando el ACU tiene recursos.
        public decimal PrecioDirecto { get; set; }
        // La importación conserva los redondeos del presupuesto nativo hasta editar su análisis.
        public decimal? PrecioImportadoDelphin { get; set; }
        public decimal? ParcialImportadoDelphin { get; set; }
        public decimal? CantidadImportadaDelphin { get; set; }
        public string FirmaAnalisisImportadoDelphin { get; set; }
        public string FirmaDatosImportadosDelphin { get; set; }
        public decimal RendimientoDiario { get; set; } = 1m;
        public decimal JornadaHoras { get; set; } = 8m;
        public string EspecificacionRtf { get; set; } = "";
        public string EspecificacionTexto { get; set; } = "";
        // El título inicial es un borrador hasta guardar la especificación.
        // Los documentos anteriores conservan sus especificaciones guardadas.
        public bool EspecificacionEsBorrador { get; set; }
        // Orden visual de los títulos del ACU; independiente del orden de sus
        // recursos para conservar los cálculos y firmas de precios importados.
        public List<MYGGrupoRecurso> OrdenGruposACU { get; set; } = new(Enum.GetValues<MYGGrupoRecurso>());
        public List<MYGRecursoACU> Analisis { get; set; } = new();
        public List<MYGLineaMetrado> Metrados { get; set; } = new();
        public List<MYGMetradoBIM> MetradosBIM { get; set; } = new();
        public MYGHojaMetrado Hoja { get; set; } = MYGHojaMetrado.Crear();
        public List<MYGResponsablePresupuesto> Responsables { get; set; } = new();
    }
    public sealed class MYGRecursoACU
    {
        public string Id { get; set; } = MYGProyectoStorage.NuevoId();
        public MYGGrupoRecurso Grupo { get; set; } = MYGGrupoRecurso.Materiales;
        public string InsumoId { get; set; }
        // Identidad local estable, distinta del código visible y del ID de Delphin.
        public string SubpartidaIdLocal { get; set; }
        public MYGModoCantidad Modo { get; set; } = MYGModoCantidad.Directa;
        public decimal NumeroRecursos { get; set; } = 1m;
        public decimal Cantidad { get; set; } = 1m;
        public decimal DesperdicioPorcentaje { get; set; }
    }
    public sealed class MYGLineaMetrado
    {
        public string Descripcion { get; set; } = "";
        public decimal Elementos { get; set; } = 1m;
        public decimal CantidadPorElemento { get; set; } = 1m;
        // Vacío equivale a dimensión no utilizada; cero equivale a dimensión cero.
        public decimal? Largo { get; set; }
        public decimal? Ancho { get; set; }
        public decimal? Alto { get; set; }
        public bool Descuento { get; set; }
        public string Referencia { get; set; } = "";
        public string ImagenRuta { get; set; } = "";
    }
    public sealed class MYGMetradoBIM
    {
        public string ActivoId { get; set; }
        public string DocumentoId { get; set; }
        public string Tabla { get; set; }
        public string Unidad { get; set; }
        public decimal Cantidad { get; set; }
        public DateTime FechaUtc { get; set; }
    }
    public sealed class MYGResultadoRecurso
    {
        public MYGRecursoACU Recurso { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Unidad { get; set; }
        public decimal Cantidad { get; set; }
        public decimal Precio { get; set; }
        public decimal Total { get; set; }
    }
    public sealed class MYGResultadoACU
    {
        public decimal PrecioUnitario { get; set; }
        public List<MYGResultadoRecurso> Recursos { get; set; } = new();
    }
    public sealed class MYGResumenCostos
    {
        public decimal CostoDirecto { get; set; }
        public decimal GastosGenerales { get; set; }
        public decimal Utilidad { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Impuesto { get; set; }
        public decimal OtrosImpuestos { get; set; }
        public decimal Total { get; set; }
    }
    public sealed class MYGInsumoConsolidado
    {
        public string Clave { get; set; }
        public MYGGrupoRecurso Grupo { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Unidad { get; set; }
        public decimal Cantidad { get; set; }
        public decimal Precio { get; set; }
        public decimal Total { get; set; }
    }
}
