using System;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class ContenidoPartidaCheck
{
    private static void Exige(bool condicion, string detalle) { if (!condicion) throw new Exception(detalle); }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var datos = new MYGDatosPartida();
        Exige(!MYGContenidoPartida.TieneEspecificacionGuardada(null) && !MYGContenidoPartida.TieneEspecificacionGuardada(datos),
            "Una partida sin especificación no debe activar su indicador.");
        foreach (string vacio in new[] { " ", @"{\rtf1\ansi{\fonttbl{\f0 Arial;}}{\colortbl;\red0\green0\blue0;}\f0\fs22\par}",
            @"{\rtf1{\info{\title Sólo metadatos}}{\*\generator MYG;}\uc1\u32?\par}",
            @"{\rtf1{\*\info {\pict\pngblip 89504E47}}\par}",
            MYGEspecificacionesPagina.Guardar(@"{\rtf1\ansi\par}", new MYGPaginaEspecificacion { Encabezado = "Sólo configuración" }) })
        {
            datos.EspecificacionRtf = vacio;
            Exige(!MYGContenidoPartida.TieneEspecificacionGuardada(datos), "RTF vacío, formato o metadatos activaron el indicador.");
        }
        foreach (string contenido in new[] { @"{\rtf1\ansi Especificación\par}", @"{\rtf1\uc1\u233?}",
            @"{\rtf1\'e9}", @"{\rtf1{\pict\pngblip 89504E47}}", @"{\rtf1{\*\shppict{\pict\pngblip 89504E47}}}", @"{\rtf1\bullet}" })
        {
            datos.EspecificacionRtf = contenido;
            Exige(MYGContenidoPartida.TieneEspecificacionGuardada(datos), "El texto o imagen guardados no activaron el indicador.");
        }
        datos.EspecificacionRtf = ""; datos.EspecificacionTexto = "Descripción";
        Exige(MYGContenidoPartida.TieneEspecificacionGuardada(datos), "La especificación de texto de documentos anteriores debe reconocerse.");
        datos.EspecificacionEsBorrador = true;
        Exige(!MYGContenidoPartida.TieneEspecificacionGuardada(datos), "El título inicial en borrador no debe activar el indicador.");
        Exige(MYGContenidoPartida.TieneEspecificacionGuardada(JsonSerializer.Deserialize<MYGDatosPartida>("{\"EspecificacionTexto\":\"Texto anterior\"}")),
            "La ausencia del flag en documentos anteriores no debe ocultar especificaciones guardadas.");
        pasa("Indicador de especificación reconoce texto e imágenes guardadas y omite borradores, RTF vacío y metadatos");

        foreach (string id in new[] { MYGPlantillasMetrado.Estandar, MYGPlantillasMetrado.Aceros })
        {
            datos = new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear(id), FuenteMetrado = MYGFuenteMetrado.Excel };
            string antes = JsonSerializer.Serialize(datos);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Seleccionar una plantilla vacía no debe activar el indicador XLS.");
            datos.Hoja.Celdas["A2"].ColorTexto = "FF0000";
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Cambiar formato no constituye un metrado.");
            foreach (string contenido in new[] { "Descripción", "0", "=1-1", "=SUM(B3:F3)" })
            {
                datos.Hoja.Poner("A3", contenido);
                Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Una entrada real, incluso cero o una fórmula, debe activar XLS.");
                datos.Hoja.Celdas.Remove("A3");
                Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Eliminar el último dato debe apagar XLS.");
            }
            datos.Hoja = MYGPlantillasMetrado.Crear(id);
            MYGEdicionHoja.InsertarFilas(datos.Hoja, 1, 2);
            MYGEdicionHoja.InsertarColumnas(datos.Hoja, 1, 2);
            MYGEdicionHoja.InsertarFilas(datos.Hoja, 7);
            MYGEdicionHoja.InsertarColumnas(datos.Hoja, 5);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Insertar filas y columnas en una plantilla vacía no debe inventar metrado.");
            datos.Hoja.Poner("C5", "Metrado registrado"); datos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
            Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "XLS debe conservarse aunque la cantidad use otra fuente.");
            datos.Hoja.Celdas.Remove("C5");
            MYGEdicionHoja.EliminarColumnas(datos.Hoja, 6);
            MYGEdicionHoja.EliminarFilas(datos.Hoja, 7);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Eliminar estructura vacía y sus referencias no debe activar XLS.");
            datos.Hoja = MYGPlantillasMetrado.Crear(id);
            MYGEdicionHoja.EliminarColumnas(datos.Hoja, id == MYGPlantillasMetrado.Estandar ? 2 : 4);
            Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Las referencias rotas por eliminar columnas automáticas no son datos ingresados.");
            datos = new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear(id), FuenteMetrado = MYGFuenteMetrado.Excel };
            Exige(JsonSerializer.Serialize(datos) == antes && !MYGContenidoPartida.TieneMetradoExcel(datos) && JsonSerializer.Serialize(datos) == antes,
                "Consultar presencia debe ser sólo lectura.");
        }
        pasa("Indicador XLS omite plantillas estándar/aceros vacías y cambios de formato o estructura; reconoce cero, texto y fórmulas sin calcularlos");

        datos = new MYGDatosPartida { Hoja = MYGPlantillasMetrado.Crear(MYGPlantillasMetrado.Aceros) };
        datos.Hoja.Poner("I15", "0.100");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Un peso por metro editado debe contar como metrado de usuario.");
        datos.Hoja = new MYGHojaMetrado();
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Una hoja importada sin contenido no debe activar XLS.");
        datos.Hoja.Poner("B3", "=1/0");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos), "Una hoja importada con fórmula debe activar XLS sin ejecutarla.");
        datos.Hoja = MYGHojaMetrado.Crear(); datos.Hoja.IdPlantilla = ""; datos.Hoja.RangoCuerpoPlantilla = null;
        Exige(!MYGContenidoPartida.TieneMetradoExcel(datos), "Una plantilla estándar anterior no debe confundirse con metrado ingresado.");
        datos.Hoja.Poner("B3", "2");
        Exige(MYGContenidoPartida.TieneMetradoExcel(datos) && !MYGContenidoPartida.TieneMetradoExcel(null),
            "Debe reconocer contenido de hojas anteriores y admitir datos ausentes.");
        pasa("Indicador XLS reconoce pesos editados, hojas importadas y documentos anteriores y es independiente de la fuente de cantidad");
    }
}
