using System;
using System.Drawing;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private Bitmap iconoEspecificacionFila, iconoExcelFila;
    private int EspacioIndicadorContenido => (int)Math.Ceiling(23 * estructura.DeviceDpi / 96d);

    private void PrepararIndicadoresContenido()
    {
        iconoEspecificacionFila = MYGIconos.Obtener("especificacion");
        iconoExcelFila = MYGIconos.Obtener("excel");
        // Se agrega al final de la colección para mantener el orden de los
        // valores de Rows.Add; visualmente queda después de cantidad/unidad.
        Columna(estructura, "METRADO_EXCEL", "", 26);
        var columna = estructura.Columns["METRADO_EXCEL"];
        columna.DisplayIndex = estructura.Columns["PU"].DisplayIndex;
        columna.Resizable = DataGridViewTriState.False;
        columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
        estructura.CellPainting += PintarIndicadorContenido;
        estructura.DpiChangedAfterParent += (_, _) =>
        {
            columna.Width = (int)Math.Ceiling(26 * estructura.DeviceDpi / 96d);
            SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        };
        Disposed += (_, _) => { iconoEspecificacionFila.Dispose(); iconoExcelFila.Dispose(); };
    }

    private void ActualizarIndicadoresContenido(DataGridViewRow fila, ItemPresupuestoDelphin partida)
    {
        if (MYGProyectoStorage.EsTitulo(partida)) return;
        var descripcion = fila.Cells["DESC"];
        var margen = descripcion.InheritedStyle.Padding;
        // Un espacio para la especificación y otro para el aviso de catálogo.
        descripcion.Style.Padding = new(margen.Left, margen.Top,
            EspacioIndicadorContenido * 2, margen.Bottom);
        fila.Cells["METRADO_EXCEL"].ToolTipText = MYGContenidoPartida.TieneMetradoExcel(partida.Costos)
            ? "La partida tiene metrado en Excel." : "";
    }

    internal Rectangle LimitesIndicadorContenido(DataGridViewCell celda)
    {
        if (celda?.DataGridView != estructura || celda.RowIndex < 0 || celda.ColumnIndex < 0 ||
            celda.OwningRow.Tag is not ItemPresupuestoDelphin partida || MYGProyectoStorage.EsTitulo(partida))
            return Rectangle.Empty;
        bool presente = celda.OwningColumn.Name switch
        {
            "DESC" => MYGContenidoPartida.TieneEspecificacionGuardada(partida.Costos),
            "METRADO_EXCEL" => MYGContenidoPartida.TieneMetradoExcel(partida.Costos),
            _ => false
        };
        if (!presente) return Rectangle.Empty;
        var limites = estructura.GetCellDisplayRectangle(celda.ColumnIndex, celda.RowIndex, false);
        int tamano = Math.Max(12, (int)Math.Ceiling(16 * estructura.DeviceDpi / 96d));
        int margen = Math.Max(3, (int)Math.Ceiling(4 * estructura.DeviceDpi / 96d));
        if (limites.Width < tamano + margen * 2 || limites.Height < tamano) return Rectangle.Empty;
        return new(limites.Right - margen - tamano, limites.Top + (limites.Height - tamano) / 2, tamano, tamano);
    }

    private void PintarIndicadorContenido(object sender, DataGridViewCellPaintingEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
        var celda = estructura[e.ColumnIndex, e.RowIndex];
        var limites = LimitesIndicadorContenido(celda);
        if (limites.IsEmpty) return;
        if (!e.Handled) e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
        var estado = e.Graphics.Save();
        try
        {
            e.Graphics.SetClip(Rectangle.Intersect(e.CellBounds, e.ClipBounds));
            e.Graphics.DrawImage(celda.OwningColumn.Name == "DESC" ? iconoEspecificacionFila : iconoExcelFila, limites);
            e.Handled = true;
        }
        finally { e.Graphics.Restore(estado); }
    }
}
