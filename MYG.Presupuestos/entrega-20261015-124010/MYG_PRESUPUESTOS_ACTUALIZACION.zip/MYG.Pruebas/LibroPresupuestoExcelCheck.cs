using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class LibroPresupuestoExcelCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static ItemPresupuestoDelphin Partida(string codigo, string descripcion, int posicion, string padre = null)
    {
        string id = MYGProyectoStorage.NuevoId();
        return new() { Id = id, IdLocalMYG = id, IdInternoDelphin = id, TipoPropuesta = "PARTIDA",
            Item = codigo, Descripcion = descripcion, Unidad = "und", Posicion = posicion, ParentId = padre };
    }

    private static bool Contiene(MYGHojaMetrado h, string texto)
    {
        var motor = new MYGHojaCalculo(h);
        return h.Celdas.Keys.Any(d => motor.Mostrar(d).Contains(texto, StringComparison.Ordinal));
    }

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        var doc = MYGProyectoStorage.Nuevo("PROYECTO LIBRO EXCEL QA", "ESTRUCTURAS LIBRO QA");
        doc.Datos = new MYGDatosProyecto { Propietario = "PROPIETARIO LIBRO QA", Departamento = "ÁNCASH",
            Provincia = "SANTA", Distrito = "NUEVO CHIMBOTE", FechaElaboracion = new DateTime(2026, 9, 1) };
        var p = doc.Presupuestos[0];
        var titulo = Partida("01", "CAPÍTULO LIBRO QA", 1); titulo.TipoPropuesta = "TITULO"; titulo.Unidad = "";
        var excelA = Partida("01.01", "PARTIDA EXCEL A QA", 1, titulo.Id);
        var excelB = Partida("01.02", "PARTIDA EXCEL B QA", 2, titulo.Id);
        excelA.Costos.FuenteMetrado = excelB.Costos.FuenteMetrado = MYGFuenteMetrado.Excel;
        excelA.Costos.Hoja.Poner("A3", "METRADO DETALLE A QA"); excelA.Costos.Hoja.Poner("B3", "2"); excelA.Costos.Hoja.Poner("C3", "3");
        excelB.Costos.Hoja.Poner("A3", "METRADO DETALLE B QA"); excelB.Costos.Hoja.Poner("B3", "5"); excelB.Costos.Hoja.Poner("C3", "2");
        excelA.Costos.PrecioDirecto = 10; excelB.Costos.PrecioDirecto = 5;
        var manual = Partida("01.03", "PARTIDA MANUAL QA", 3, titulo.Id);
        manual.Costos.FuenteMetrado = MYGFuenteMetrado.Manual;
        manual.Costos.Metrados.Add(new() { Descripcion = "METRADO MANUAL LIBRO QA", Elementos = 2, Largo = 4 });
        manual.Costos.RendimientoDiario = 9;
        var material = new MYGInsumo { Codigo = "MAT-LIBRO", Descripcion = "MATERIAL LIBRO QA", Grupo = MYGGrupoRecurso.Materiales, Unidad = "kg", Precio = 5.25m };
        var operario = new MYGInsumo { Codigo = "MO-LIBRO", Descripcion = "OPERARIO LIBRO QA", Grupo = MYGGrupoRecurso.ManoObra, Unidad = "hh", Precio = 20 };
        p.Costos.Insumos.AddRange(new[] { material, operario });
        manual.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Materiales, InsumoId = material.Id, Cantidad = .002m });
        manual.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.ManoObra, InsumoId = operario.Id, Modo = MYGModoCantidad.Rendimiento, NumeroRecursos = 1 });
        var bim = Partida("01.04", "PARTIDA BIM QA", 4, titulo.Id);
        bim.Costos.FuenteMetrado = MYGFuenteMetrado.BIM; bim.Costos.PrecioDirecto = 2;
        bim.Costos.MetradosBIM.Add(new() { ActivoId = "ACTIVO LIBRO QA", DocumentoId = "DOC LIBRO QA", Tabla = "TABLA LIBRO QA", Unidad = "und", Cantidad = 3, FechaUtc = new DateTime(2026, 9, 1, 12, 0, 0, DateTimeKind.Utc) });
        p.Items.AddRange(new[] { excelB, titulo, bim, manual, excelA });
        var otro = new MYGPresupuestoDocumento { Item = "02", Nombre = "OTRO PRESUPUESTO EXCLUIDO QA", Posicion = 2 };
        var otraPartida = Partida("02.01", "PARTIDA EXCLUIDA LIBRO QA", 1); otraPartida.Costos.Cantidad = 3; otraPartida.Costos.PrecioDirecto = 7;
        otro.Items.Add(otraPartida); doc.Presupuestos.Add(otro);
        MYGReferenciasMetrado.Vincular(doc.Presupuestos);
        string antes = JsonSerializer.Serialize(doc);
        var hojas = MYGLibroPresupuestoExcel.Crear(doc, p.Id);
        Exige(hojas.Count == 8 && hojas.Count(h => h.Nombre == "Metrados") == 1 &&
            new[] { "Insumos", "Consolidado", "Metrados manuales", "Metrados BIM" }.All(n => hojas.Count(h => h.Nombre == n) == 1),
            "El libro completo debe conservar presupuesto, resumen, ACU, cuatro tablas auxiliares y una única hoja de metrados Excel.");
        Exige(hojas.All(h => Contiene(h, doc.Nombre) && Contiene(h, doc.Datos.Propietario) && Contiene(h, p.ToString()) && Contiene(h, "01/09/2026")) &&
            hojas.All(h => !Contiene(h, otraPartida.Descripcion)),
            "Todas las hojas deben incluir los datos generales y pertenecer exclusivamente al presupuesto seleccionado.");
        var metrados = hojas.Single(h => h.Nombre == "Metrados");
        Exige(Contiene(metrados, "METRADO DETALLE A QA") && Contiene(metrados, "METRADO DETALLE B QA") &&
            Contiene(metrados, "PRESUPUESTO:") && Contiene(metrados, titulo.Descripcion) && Contiene(metrados, "PARTIDA:"),
            "El libro debe agrupar ambos metrados Excel en una hoja con presupuesto, capítulos y partidas.");
        var acu = hojas.Single(h => Contiene(h, "Análisis de Costos Unitarios"));
        Exige(acu.Columnas == 7 && Contiene(acu, "Rendimiento:") && Contiene(acu, "Costo unit. por und") &&
            Contiene(acu, "MANO DE OBRA") && Contiene(acu, "MATERIALES") && Contiene(acu, operario.Descripcion) && Contiene(acu, material.Descripcion) &&
            acu.Celdas.Any(c => MYGHojaCalculo.Coordenadas(c.Key).Columna == 5 && c.Value.Contenido == "0.002" && c.Value.FormatoNumero == "0.0000"),
            "El ACU del libro debe usar el mismo formato de siete columnas, bloques de partida y precisión de cantidades que la vista preliminar.");
        Exige(Contiene(hojas.Single(h => h.Nombre == "Metrados manuales"), "METRADO MANUAL LIBRO QA") &&
            Contiene(hojas.Single(h => h.Nombre == "Metrados BIM"), "ACTIVO LIBRO QA"),
            "Las tablas auxiliares deben conservar los metrados manuales y BIM.");
        string ruta = Path.Combine(carpeta, "Libro presupuesto con cabeceras completo.xlsx");
        MYGExcelPresupuestos.Guardar(ruta, hojas);
        var nombres = MYGExcelPresupuestos.Hojas(ruta);
        Exige(nombres.Length == hojas.Count && nombres.Distinct(StringComparer.OrdinalIgnoreCase).Count() == hojas.Count,
            "El XLSX debe contener todas las hojas con nombres únicos válidos para Excel.");
        for (int i = 0; i < hojas.Count; i++)
        {
            var abierta = MYGExcelPresupuestos.Importar(ruta, nombres[i], hojas[i].CeldaTotal);
            Exige(Contiene(abierta, doc.Nombre) && Contiene(abierta, doc.Datos.Propietario) && Contiene(abierta, "01/09/2026"),
                "Guardar y abrir el XLSX perdió datos de cabecera de " + nombres[i] + ".");
        }
        Exige(JsonSerializer.Serialize(doc) == antes, "Crear y guardar el libro completo modificó el proyecto original.");
        pasa("Libro completo conserva cabeceras en sus ocho hojas, ACU con formato, cuatro auxiliares y ambos metrados Excel en una hoja; guarda/abre XLSX sin modificar el proyecto");
        var monedasDistintas = MYGProyectoStorage.Copia(doc);
        monedasDistintas.Presupuestos[1].Costos.Moneda = "USD";
        string monedasAntes = JsonSerializer.Serialize(monedasDistintas);
        var hojasMonedas = MYGLibroPresupuestoExcel.Crear(monedasDistintas, p.Id);
        var resumenSeleccionado = hojasMonedas[1];
        Exige(hojasMonedas.Count == 8 && hojasMonedas.All(h => !Contiene(h, otro.Nombre) && !Contiene(h, otraPartida.Descripcion)) &&
            Contiene(resumenSeleccionado, "HOJA DE RESUMEN") && Contiene(resumenSeleccionado, "PRESUPUESTO:") &&
            Contiene(resumenSeleccionado, p.ToString()) &&
            new MYGHojaCalculo(resumenSeleccionado).Numero(resumenSeleccionado.CeldaTotal) == MYGMotorPresupuestos.Resumen(p).Total,
            "El libro del presupuesto seleccionado debe conservar su propio resumen y exportarse aunque existan presupuestos vecinos con otra moneda, sin sumarlos ni incluir sus partidas.");
        string rutaMonedas = Path.Combine(carpeta, "Libro presupuesto con vecino en dolares.xlsx");
        MYGExcelPresupuestos.Guardar(rutaMonedas, hojasMonedas);
        var resumenReabierto = MYGExcelPresupuestos.Importar(rutaMonedas, MYGExcelPresupuestos.Hojas(rutaMonedas)[1], resumenSeleccionado.CeldaTotal);
        Exige(new MYGHojaCalculo(resumenReabierto).Numero(resumenReabierto.CeldaTotal) == MYGMotorPresupuestos.Resumen(p).Total &&
            Contiene(resumenReabierto, p.ToString()) && !Contiene(resumenReabierto, otro.Nombre) &&
            JsonSerializer.Serialize(monedasDistintas) == monedasAntes && JsonSerializer.Serialize(doc) == antes,
            "Guardar y reabrir el libro seleccionado debe conservar importes y cabecera sin convertir monedas ni modificar el proyecto.");
        pasa("Libro seleccionado exporta y reabre su resumen propio aunque otro presupuesto use USD, sin mezclar importes ni alterar el proyecto");
        var sinExcel = MYGProyectoStorage.Copia(doc);
        foreach (var i in sinExcel.Presupuestos[0].Items.Where(i => i.Costos.FuenteMetrado == MYGFuenteMetrado.Excel)) i.Costos.FuenteMetrado = MYGFuenteMetrado.Cantidad;
        Exige(MYGLibroPresupuestoExcel.Crear(sinExcel, p.Id).Count == 7,
            "El libro sin partidas Excel debe omitir únicamente la hoja consolidada de metrados.");
        bool invalido = false;
        try { MYGLibroPresupuestoExcel.Crear(doc, "presupuesto inexistente"); }
        catch (InvalidOperationException) { invalido = true; }
        Exige(invalido && JsonSerializer.Serialize(doc) == antes, "El libro debe rechazar un presupuesto inexistente sin modificar el proyecto.");
        var proyectoInvalido = MYGProyectoStorage.Copia(doc);
        proyectoInvalido.Presupuestos[1].Costos.DecimalesPrecio = 7;
        string invalidoAntes = JsonSerializer.Serialize(proyectoInvalido);
        bool validacionCompleta = false;
        try { MYGLibroPresupuestoExcel.Crear(proyectoInvalido, p.Id); }
        catch (InvalidDataException) { validacionCompleta = true; }
        Exige(validacionCompleta && JsonSerializer.Serialize(proyectoInvalido) == invalidoAntes,
            "El libro debe validar el proyecto completo sobre una copia, incluidos los presupuestos ajenos al seleccionado.");
        pasa("Libro completo omite metrados cuando no hay partidas Excel y valida la selección y el proyecto completo sobre copias");
    }
}
