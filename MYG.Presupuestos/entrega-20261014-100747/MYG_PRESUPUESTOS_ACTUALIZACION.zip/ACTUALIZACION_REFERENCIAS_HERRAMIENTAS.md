# Referencias cortas, exportación de metrados y herramientas

Base de la entrega: `main`, commit `fc865f24a564dfed3730b7517c31f8567e46892a` de
`bimchimbote-droid/MYG.Presupuestos`. El checkout local de preparación usa la rama
`work`; no se publica ni modifica `main` automáticamente.

## Fórmulas de metrado

Las nuevas referencias muestran un código de presupuesto/ítem, por ejemplo
`=METRADO("01/05";"B3")*2`, sin incorporar la descripción de la partida.
El código guardado permanece estable aunque se renumere el ítem. El vínculo
resuelve por los identificadores de presupuesto, partida y celda, y sigue
las inserciones y movimientos de filas y columnas. Los códigos duplicados
reciben un sufijo para distinguirlos.

Las fórmulas de versiones anteriores siguen funcionando. Volver a insertar
una referencia antigua utiliza un código corto, conservando la referencia
original y la misma identidad de celda.

## Exportación de Excel

En la barra superior, **Exportar > Metrados completos del proyecto (.xlsx)**
genera un único libro con los metrados Excel de sus presupuestos y las hojas
de origen necesarias. Cada partida tiene una hoja, con nombres cortos y únicos.
Las funciones `METRADO` se convierten en referencias normales de Excel, por
ejemplo `='Metrado 01-05'!B3*2`; el nombre exacto depende de los códigos y de
la asignación de nombres únicos del libro. Al editar el origen en Excel,
sus fórmulas dependientes pueden recalcularse sin MYG ni macros.

La exportación del presupuesto activo también incluye las hojas necesarias
para resolver sus referencias, incluso si pertenecen a otro presupuesto.
Una exportación aislada que no incluye la hoja de origen conserva el valor
o error calculado: para mantener los vínculos editables use la exportación completa.

El libro exportado es para trabajar en Excel. Esta entrega no añade importación
de referencias entre hojas de Excel como vínculos `METRADO` de MYG.

## Barra superior

Se reutilizan las funciones existentes de Inicio, Guardar, Imprimir/PDF,
Información del proyecto, Exportar, Resumen de costos, Responsables,
Especificaciones y autorización de sesión. Los formularios y botones de
BIM/Revit conservan su flujo existente.

Por solicitud del usuario, Fórmula polinómica, Calendario de adquisiciones,
Calendario valorizado y Valorización están visibles como botones reservados:
todavía no ejecutan una operación. Permisos muestra la autorización de la
sesión; esta entrega no implementa administración de roles.

## Instalación manual

1. Respalde su carpeta o confirme los cambios locales en Visual Studio.
2. Descargue y extraiga el ZIP de actualización fuera del repositorio.
3. Copie los archivos de la entrega sobre la raíz de su checkout,
   conservando todas las rutas relativas. Los archivos existentes se entregan
   completos; compare antes de reemplazar si tiene cambios posteriores al commit base.
4. Abra `MYG.Presupuestos.sln` en Visual Studio con el SDK .NET 10.
5. Restaure, compile y ejecute las pruebas indicadas abajo.
6. Revise **Cambios de Git**, confirme los archivos y haga Push a `main`
   cuando usted decida publicar el código. Subir el ZIP a `DESCARGAS` no
   publica ni aplica estos cambios en el repositorio del código.

No se añaden paquetes, migraciones de base de datos ni cambios de credenciales.

## Validación

Desde la raíz del repositorio, para compilar también fuera de una instalación de Revit:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true --no-restore -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, ejecute también:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

Compruebe manualmente una partida con descripción larga, una referencia a
otra partida y la exportación del proyecto completo. Edite la celda de origen
en Excel y verifique que cambia el destino. Revise los botones superiores,
el guardado al volver a Inicio y los botones originales de BIM/Revit.
La ejecución visual, Named Pipes y la integración real con Revit requieren Windows.

Validación de esta entrega en Linux x64 con SDK .NET 10.0.100: compilación de
la solución Release sin errores ni advertencias y 302 comprobaciones de la
suite completadas. Named Pipes se omite en Linux; las pruebas de interfaz se
compilaron pero requieren ejecución en Windows. No se usaron muestras privadas
de Delphin ni credenciales de licencia reales.

Validación externa con LibreOfficeDev 26.8: una cadena de tres metrados
recalculó de 12/6/5 a 20/10/9 al cambiar solamente la celda de origen de 5 a 9.
Se comprobó que el libro conserva fórmulas normales y que la exportación no
modifica el documento MYG. Microsoft Excel en Windows queda pendiente de
comprobación manual.
