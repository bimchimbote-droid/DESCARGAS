using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    // Son accesos al trabajo del proyecto; los paneles y ejecutables de BIM
    // conservan sus botones y formularios originales.
    private void InicializarHerramientasProyecto(Func<string, string, Action, bool, Button> agregar)
    {
        Button Herramienta(string icono, string texto, string nombre, Action accion, bool licencia = true, int ancho = 91)
        {
            var boton = agregar(icono, texto, accion, licencia);
            boton.Name = nombre; boton.AccessibleName = texto.Replace("\n", " ").Replace(" ▾", "");
            boton.Width = ancho; ayudas.SetToolTip(boton, boton.AccessibleName); return boton;
        }
        void Pendiente(string icono, string texto, string nombre, int ancho)
        {
            // El usuario pidió colocar estas herramientas sin ejecutar nada
            // todavía: no hay validación de sesión, sincronización ni diálogo.
            var boton = CrearBotonCintaProyecto(icono, texto, false);
            boton.Name = nombre; boton.Width = ancho;
            boton.AccessibleDescription = "Pendiente de implementación.";
            ayudas.SetToolTip(boton, boton.AccessibleName + " — Pendiente de implementación.");
            cintaPresupuestos.Controls.Add(boton);
        }

        // Close debe ejecutarse fuera de Ejecutar: su estado ocupado impediría
        // cerrar y devolver el control al InicioForm que abrió este editor.
        var inicio = CrearBotonCintaProyecto("proyecto", "Ir inicio", false);
        inicio.Name = "ir_inicio_button";
        ayudas.SetToolTip(inicio, "Volver a mis proyectos; se preguntará si desea guardar los cambios pendientes.");
        inicio.Click += (_, _) => { if (!ocupado) Close(); };
        cintaPresupuestos.Controls.Add(inicio);

        Herramienta("guardar", "Guardar", "guardar_proyecto_button", () => Guardar(false), false);
        Herramienta("imprimir", "Imprimir / PDF", "imprimir_proyecto_button", () => panelPresupuesto.ImprimirPresupuesto(), ancho: 104);
        Herramienta("proyecto", "Info. proyecto", "info_proyecto_button", EditarDatosProyecto, ancho: 100);
        Button exportar = null;
        exportar = Herramienta("excel", "Exportar ▾", "exportar_proyecto_button", () => MenuExportarProyecto(exportar));
        Pendiente("acu", "Fórmula\npolinómica", "formula_polinomica_button", 100);
        Pendiente("insumos", "Calendario de\nadquisiciones", "calendario_adquisiciones_button", 112);
        Pendiente("resumen", "Calendario\nvalorizado", "calendario_valorizado_button", 104);
        Herramienta("resumen", "Resumen de\ncostos", "resumen_costos_button", () => panelPresupuesto.Resumen(), ancho: 104);
        Button responsables = null;
        responsables = Herramienta("sesion", "Responsables ▾", "responsables_proyecto_button", () => MenuResponsablesProyecto(responsables), false, 108);
        Herramienta("especificacion", "Especificaciones", "especificaciones_button", () => panelPresupuesto.MostrarEspecificacion(), ancho: 112);
        Pendiente("resumen", "Valorización", "valorizacion_button", 100);
        Button permisos = null;
        permisos = Herramienta("sesion", "Permisos /\nsesión ▾", "permisos_proyecto_button", () => MenuPermisosProyecto(permisos), false, 100);
        ayudas.SetToolTip(permisos, "Consultar la autorización actual e iniciar o cambiar de sesión.");
        Button especificaciones = null;
        especificaciones = Herramienta("especificacion", "Exportar espec.\ntécnicas ▾", "exportar_especificaciones_button",
            () => MenuExportarEspecificaciones(especificaciones), ancho: 108);
        especificaciones.AccessibleName = "Exportar especificaciones técnicas";
        ayudas.SetToolTip(especificaciones, "Exportar especificaciones técnicas del proyecto o presupuesto");
    }

    private static Button CrearBotonCintaProyecto(string icono, string texto, bool necesitaLicencia)
    {
        var boton = new MYG2027_BotonComercial
        {
            Text = texto, AccessibleName = texto.Replace("\n", " ").Replace(" ▾", ""),
            Image = MYGIconos.Obtener(icono), TextImageRelation = TextImageRelation.ImageAboveText,
            ImageAlign = ContentAlignment.TopCenter, TextAlign = ContentAlignment.BottomCenter,
            Width = 91, Height = 65, FlatStyle = FlatStyle.Flat, Font = new("Segoe UI", 9),
            BackColor = MYG2027_TemaComercial.MarinoClaro, ForeColor = Color.White, Margin = new(2), Tag = necesitaLicencia
        };
        boton.Disposed += (_, _) => boton.Image?.Dispose();
        MYG2027_TemaComercial.EstilizarBoton(boton, 3); MYGAnimacionUI.PrepararBoton(boton);
        return boton;
    }

    internal static bool HerramientaProyectoDisponible(bool necesitaLicencia, bool ocupado, bool autorizado)
        => !ocupado && (!necesitaLicencia || autorizado);

    internal static ContextMenuStrip CrearMenuExportarProyecto(Action presupuesto, Action metrados,
        bool presupuestoDisponible, bool metradosDisponibles)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Presupuesto activo (.xlsx)", null, (_, _) => presupuesto())
        { Name = "exportar_presupuesto_activo", Enabled = presupuestoDisponible });
        menu.Items.Add(new ToolStripMenuItem("Metrados completos del proyecto (.xlsx)", null, (_, _) => metrados())
        { Name = "exportar_metrados_completos", Enabled = metradosDisponibles });
        return menu;
    }

    private void MenuExportarProyecto(Button boton)
    {
        var menu = CrearMenuExportarProyecto(
            () => EjecutarDesdeMenuProyecto(() => panelPresupuesto.ExportarPresupuesto()),
            () => EjecutarDesdeMenuProyecto(() => panelPresupuesto.ExportarMetradosCompletos()),
            P != null, documento.Presupuestos.Any(p => p.Items.Any(i => !MYGProyectoStorage.EsTitulo(i) &&
                i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel && i.Costos.Hoja != null)));
        MostrarMenuProyecto(menu, boton);
    }

    internal static ContextMenuStrip CrearMenuResponsablesProyecto(Action asignar, Action ver, Action quitar,
        bool autorizado, bool hayResponsables)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Asignar responsable…", null, (_, _) => asignar())
        { Name = "asignar_responsable_proyecto", Enabled = autorizado });
        menu.Items.Add(new ToolStripMenuItem("Ver responsables…", null, (_, _) => ver())
        { Name = "ver_responsables_proyecto" });
        menu.Items.Add(new ToolStripMenuItem("Quitar responsable…", null, (_, _) => quitar())
        { Name = "quitar_responsable_proyecto", Enabled = autorizado && hayResponsables });
        return menu;
    }

    private void MenuResponsablesProyecto(Button boton)
    {
        object contexto = espacioPresupuestos.SelectedIndex == 0 ? panelPresupuesto.SeleccionEstructura : Seleccionadas.FirstOrDefault();
        var propietario = PropietarioEstructura(contexto) ?? P
            ?? throw new InvalidOperationException("Seleccione un presupuesto o una partida para consultar sus responsables.");
        string presupuestoId = propietario.Id, partidaId = NodoEstructura(contexto)?.Id;
        object Resolver()
        {
            var p = documento.Presupuestos.FirstOrDefault(p => p.Id == presupuestoId)
                ?? throw new InvalidOperationException("El presupuesto seleccionado ya no está en el proyecto.");
            return partidaId == null ? p : p.Items.FirstOrDefault(i => i.Id == partidaId)
                ?? throw new InvalidOperationException("La partida seleccionada ya no está en el presupuesto.");
        }
        // Resolver los IDs al hacer clic permite usar el historial mientras el
        // menú está cerrado sin conservar referencias a una versión anterior.
        var lista = partidaId == null ? propietario.Costos.Responsables : NodoEstructura(contexto)?.Costos.Responsables;
        var menu = CrearMenuResponsablesProyecto(
            () => EjecutarDesdeMenuProyecto(() => AsignarResponsable(Resolver())),
            () => EjecutarDesdeMenuProyecto(() => VerResponsables(Resolver()), false),
            () => EjecutarDesdeMenuProyecto(() => QuitarResponsable(Resolver())),
            sesion.Autorizado, lista?.Count > 0);
        MostrarMenuProyecto(menu, boton);
    }

    private void MenuPermisosProyecto(Button boton)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Ver autorización actual…", null, (_, _) => EjecutarDesdeMenuProyecto(() =>
        {
            string usuario = sesion.Credencial?.Usuario ?? "Sin sesión";
            string autorizacion = sesion.Autorizado ? "Autorizada para editar presupuestos y metrados." : "Inicie sesión para editar presupuestos y metrados.";
            MessageBox.Show(this, "Usuario: " + usuario + Environment.NewLine + autorizacion + Environment.NewLine +
                "Puede guardar el trabajo pendiente y volver a Inicio con la sesión vencida.", "Permisos de la sesión", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }, false)) { Name = "ver_autorizacion_actual" });
        menu.Items.Add(new ToolStripMenuItem("Iniciar o cambiar de sesión…", null, (_, _) => EjecutarDesdeMenuProyecto(() =>
        { using var f = new MYG.Externo.LoginForm(sesion); f.ShowDialog(this); }, false)) { Name = "iniciar_cambiar_sesion" });
        MostrarMenuProyecto(menu, boton);
    }

    private void EjecutarDesdeMenuProyecto(Action accion, bool necesitaLicencia = true)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing) return;
            await Ejecutar(() => { accion(); return Task.CompletedTask; }, necesitaLicencia);
        }));
    }

    private void MostrarMenuProyecto(ContextMenuStrip menu, Button boton)
    {
        componentesMenus.Add(menu);
        menu.Closed += (_, _) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated || menu.IsDisposed) return;
            BeginInvoke(new Action(() => { if (!menu.IsDisposed && !menu.Disposing) menu.Dispose(); }));
        };
        menu.Show(boton, new Point(0, boton.Height));
    }
}
