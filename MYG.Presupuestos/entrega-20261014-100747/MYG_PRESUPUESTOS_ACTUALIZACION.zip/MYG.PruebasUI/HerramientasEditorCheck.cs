using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MYG.Externo;
using MYG_2027;

internal static class HerramientasEditorCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        var exportaciones = new List<string>();
        using (var menu = EditorForm.CrearMenuExportarProyecto(
            () => exportaciones.Add("presupuesto"), () => exportaciones.Add("metrados"), true, true))
        {
            var opciones = menu.Items.Cast<ToolStripMenuItem>().ToArray();
            exige(opciones.Select(x => x.Name).SequenceEqual(new[] { "exportar_presupuesto_activo", "exportar_metrados_completos" }),
                "Exportar debe ofrecer el presupuesto activo y los metrados completos del proyecto como entregas distintas.");
            opciones[0].PerformClick(); opciones[1].PerformClick();
            exige(exportaciones.SequenceEqual(new[] { "presupuesto", "metrados" }),
                "Cada destino de Exportar debe ejecutar su propia exportación una sola vez.");
        }
        using (var menu = EditorForm.CrearMenuExportarProyecto(
            () => exportaciones.Add("vacío"), () => exportaciones.Add("vacío"), false, false))
        {
            exige(menu.Items.Cast<ToolStripItem>().All(x => !x.Enabled),
                "Una entrega sin presupuesto ni partidas no debe habilitar una exportación vacía.");
        }

        var responsables = new List<string>();
        using (var menu = EditorForm.CrearMenuResponsablesProyecto(
            () => responsables.Add("asignar"), () => responsables.Add("ver"), () => responsables.Add("quitar"), true, true))
        {
            foreach (ToolStripMenuItem opcion in menu.Items) opcion.PerformClick();
            exige(responsables.SequenceEqual(new[] { "asignar", "ver", "quitar" }),
                "Responsables debe reutilizar los comandos de asignación, consulta y retiro, sin acciones vacías.");
        }
        using (var menu = EditorForm.CrearMenuResponsablesProyecto(
            () => responsables.Add("sin-permiso"), () => responsables.Add("ver"), () => responsables.Add("sin-permiso"), false, true))
        {
            exige(!menu.Items[0].Enabled && menu.Items[1].Enabled && !menu.Items[2].Enabled,
                "La consulta de responsables debe conservarse y las modificaciones requieren autorización.");
        }
        using (var menu = EditorForm.CrearMenuResponsablesProyecto(() => { }, () => { }, () => { }, true, false))
        {
            exige(menu.Items[0].Enabled && !menu.Items[2].Enabled,
                "Se puede asignar el primer responsable y no se puede quitar uno inexistente.");
        }

        exige(EditorForm.HerramientaProyectoDisponible(false, false, false) &&
            !EditorForm.HerramientaProyectoDisponible(true, false, false) &&
            EditorForm.HerramientaProyectoDisponible(true, false, true),
            "Inicio, guardado y sesión deben seguir disponibles con sesión vencida; editar requiere autorización.");
        exige(!EditorForm.HerramientaProyectoDisponible(false, true, false) &&
            !EditorForm.HerramientaProyectoDisponible(true, true, true),
            "La barra debe bloquear sus comandos mientras una operación está en curso.");
        VerificarCintaSinCambiarPaneles(exige);
    }

    private static void VerificarCintaSinCambiarPaneles(Action<bool, string> exige)
    {
        var presupuesto = new MYGPresupuestoDocumento { Item = "01", Nombre = "PRESUPUESTO DE PRUEBA", Posicion = 1 };
        var proyecto = new MYGProyectoDocumento { Nombre = "PROYECTO DE PRUEBA", PresupuestoActivoId = presupuesto.Id };
        proyecto.Presupuestos.Add(presupuesto);
        using var sesion = new SesionDesktop();
        using var editor = new EditorForm(proyecto, null, sesion);
        editor.WindowState = FormWindowState.Normal; editor.ClientSize = new Size(1600, 900);
        editor.Show(); Application.DoEvents();
        var controles = Descendientes(editor).ToArray();
        var barra = controles.OfType<FlowLayoutPanel>().Single(x => x.Name == "herramientas_proyecto");
        var botones = barra.Controls.Cast<Button>().ToArray();
        string[] principales = {
            "ir_inicio_button", "guardar_proyecto_button", "imprimir_proyecto_button", "info_proyecto_button", "exportar_proyecto_button",
            "formula_polinomica_button", "calendario_adquisiciones_button", "calendario_valorizado_button", "resumen_costos_button",
            "responsables_proyecto_button", "especificaciones_button", "valorizacion_button", "permisos_proyecto_button"
        };
        exige(botones.Take(principales.Length).Select(b => b.Name).SequenceEqual(principales) && botones.All(b => b.Image != null),
            "La cinta superior debe presentar las herramientas de la referencia en orden y con sus iconos.");
        var navegacion = controles.OfType<TabControl>().Single(t => t.TabPages.Cast<TabPage>().Any(p => p.Text == "Configuración BIM / Revit"));
        var pie = controles.OfType<FlowLayoutPanel>().Single(f => f.Controls.OfType<GroupBox>().Any(g => g.Text == "Tablas de planificación"));
        Control[] controlesPie = pie.Controls.Cast<Control>().ToArray();
        exige(controles.OfType<Button>().Any(b => b.Text == "Actualizar activo") &&
            controles.OfType<Button>().Any(b => b.Text == "Federar metrados") &&
            controles.OfType<Button>().Any(b => b.Text == "Crear tablas"),
            "Agregar herramientas superiores debe conservar los botones originales de los ejecutables de BIM y metrados.");
        string firma = MYGProyectoStorage.Firma(proyecto);
        var historial = (Stack<MYGProyectoDocumento>)typeof(EditorForm).GetField("undo", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(editor);
        int registros = historial.Count, formularios = Application.OpenForms.Count, seleccion = navegacion.SelectedIndex;
        foreach (string nombre in new[] { "formula_polinomica_button", "calendario_adquisiciones_button", "calendario_valorizado_button", "valorizacion_button" })
        {
            var boton = botones.Single(b => b.Name == nombre);
            exige(boton.Enabled && boton.AccessibleDescription == "Pendiente de implementación.",
                "Las herramientas nuevas deben colocarse como accesos pendientes, según lo solicitado.");
            boton.PerformClick(); Application.DoEvents();
            exige(MYGProyectoStorage.Firma(proyecto) == firma && historial.Count == registros &&
                Application.OpenForms.Count == formularios && navegacion.SelectedIndex == seleccion &&
                pie.Controls.Cast<Control>().SequenceEqual(controlesPie),
                "Pulsar una herramienta pendiente no debe sincronizar, modificar el proyecto, agregar historial, abrir formularios ni alterar los controles inferiores.");
        }
        exige(botones.Single(b => b.Name == "ir_inicio_button").Enabled &&
            botones.Single(b => b.Name == "guardar_proyecto_button").Enabled &&
            botones.Single(b => b.Name == "responsables_proyecto_button").Enabled &&
            botones.Single(b => b.Name == "permisos_proyecto_button").Enabled &&
            !botones.Single(b => b.Name == "info_proyecto_button").Enabled,
            "La cinta real debe permitir volver, guardar e iniciar sesión sin autorización y bloquear la edición de los datos del proyecto.");
    }

    private static IEnumerable<Control> Descendientes(Control padre)
    {
        foreach (Control hijo in padre.Controls)
        {
            yield return hijo;
            foreach (var descendiente in Descendientes(hijo)) yield return descendiente;
        }
    }
}
