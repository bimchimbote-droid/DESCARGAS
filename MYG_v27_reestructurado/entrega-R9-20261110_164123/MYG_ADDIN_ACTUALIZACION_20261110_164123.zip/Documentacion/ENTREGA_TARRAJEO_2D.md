# Perfiles naturales y validación nativa — TARRAJEO-PLANO-R9

## Base y problemas del log

Esta entrega se aplica sobre R8, publicada en DESCARGAS con commit `0d2131ca15d207c22c4fc8f7bd1eb44d1d31e224`.

El nuevo log contiene dos fallos diferentes:

- Un contorno se recompone en **dos paños reales**, de aproximadamente 10.8276 y 2.59545 m². R8 los rechazaba porque exigía un único propietario. La reproducción privada confirma que ambos perfiles conservan exactamente el material disponible, sin retirar área ni crear divisiones por franjas.
- En otro intento se obtuvieron dos regiones, pero Revit confirmó un solo suelo. El segundo pasó la validación de frontera y falló durante `Commit`, con mensajes de voladizo excesivo, extrusión y boceto no válido. El registro anterior omitió las coordenadas de ese boceto porque no marcaba como rechazo de perfil el fallo del commit.

Ese segundo registro no permite atribuir todavía la causa a un voladizo heredado, al tipo de suelo o a una apertura demasiado fina. R9 añade comprobaciones nativas y el contexto que faltaba; no se afirma que la creación en ese modelo ya haya pasado dentro de Revit. Las coordenadas y el log privado quedan fuera de la entrega pública.

## Funcionamiento de R9

La nueva API `AjustarPerfiles` devuelve una lista de perfiles naturales. Cada perfil contiene **un exterior y sus huecos**, y el adaptador crea un suelo por cada exterior. No reúne varios paños como si fueran los anillos de un único suelo. Se comprueba la unión de todas las salidas respecto al dominio inicial `exterior - unión(vacíos)`, con subconjunto y áreas exactas. La API anterior se conserva para sus llamadores y regresiones.

Antes de aceptar cada perfil de suelo, el adaptador comprueba su frontera horizontal y crea una **extrusión temporal de geometría**, sin añadir elementos al documento. Así puede rechazar un perfil que sea válido en 2D pero no admita extrusión. Esta comprobación se ejecutará con el kernel de Revit cuando se use el comando en Revit.

Si el validador rechaza la primera apertura, se prueban hasta cuatro modos adicionales desde el mismo perfil original. Se conservan los límites anteriores: banda numérica de 0.003 mm, ajuste local de 1 mm, mínimo real de Revit, ausencia de material añadido y conservación de huecos independientes. No se amplían los límites ni se desplazan sucesivamente los anclajes. Los candidatos idénticos no se validan varias veces.

La preparación devuelve el conjunto únicamente si todos sus paños pasan. Si uno falla, no devuelve perfiles parciales: entrega una lista vacía, área retirada cero y factor de coordenadas 1. Esto se refiere a la preparación de un conjunto; la creación de elementos mantiene sus transacciones y su contador de suelos realmente confirmados.

## Creación, voladizos y diagnóstico

El flujo de creación vuelve a comprobar la extrusión del boceto horizontal antes de `Floor.Create`. En el suelo recién creado se revisa exclusivamente su propio boceto, comprobando la pertenencia al nuevo suelo. Los parámetros de voladizo de hormigón y acero se ponen a cero cuando existen, son de tipo longitud y son editables, y se verifica el valor aplicado. Un acabado que debe respetar la cara no necesita ampliar horizontalmente ese boceto.

No se modifican los tipos de suelo, los muros existentes ni bocetos de otros elementos. No se añade una llamada a `Document.Regenerate`. Si el boceto o un parámetro no está disponible, esa condición se registra; no se presenta como prueba de que existiera un voladizo. Un valor no nulo que no pueda corregirse impide confirmar ese intento.

Ante un rechazo, incluido un fallo durante el commit, se registra el boceto y su contexto: fase, tipo y espesor del suelo, nivel, desfase, cara, normal y mínimo de curva. Los fallos nativos incorporan identificador, severidad y elementos implicados. Los errores geométricos de voladizo, extrusión o boceto no se intentan resolver mediante separación de elementos.

Se conservan la reversión por `TransactionGroup`, la colocación exterior y la comprobación final de contacto. La validación temporal de extrusión no garantiza por sí sola el éxito del commit del suelo. Si Revit vuelve a rechazarlo, el nuevo log permitirá distinguir el perfil que falló y los valores nativos del intento.

## Archivos de esta entrega

| Acción | Ruta relativa | Cambio |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Lista de paños naturales y alternativas admitidas por un validador. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs` | Adaptador de varios perfiles y prueba nativa de extrusión. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Creación, voladizos, diagnóstico y marcador R9. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Regresiones de perfiles y selección de candidatos. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Comando, resultados y alcance de las pruebas. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP contiene esos seis archivos, el parche alternativo `PARCHES/VALIDAR_PERFILES_DESDE_R8.patch` y `MANIFIESTO_SHA256.txt`: **8 archivos**. No se requieren archivos nuevos de producción, inclusiones de proyecto, referencias, paquetes ni eliminaciones.

`Tarrajeo_MurosHandler.cs`, `MYG.csproj`, `Clipper.cs`, los auxiliares de alturas/validación y el proyecto de pruebas siguen iguales respecto a R8 y quedan fuera del ZIP. No se incluyen logs, modelos, coordenadas privadas, DLL, bin/obj, credenciales ni cachés.

## Instalación y comprobación

1. Partir de R8, respaldar los archivos y comparar cualquier cambio propio posterior.
2. Reemplazar **los tres archivos de producción juntos**, respetando sus rutas. Copiar aparte pruebas y documentación. No sustituir el `.csproj` ni añadir entradas Compile duplicadas.
3. Como alternativa a copiar los tres archivos, aplicar sobre R8 `git apply --check PARCHES/VALIDAR_PERFILES_DESDE_R8.patch` y después `git apply PARCHES/VALIDAR_PERFILES_DESDE_R8.patch`. No aplicar el parche después de copiarlos.
4. Compilar en la configuración real de Windows/Revit, actualizar la DLL, cerrar todas las instancias de Revit y abrir otra vez. El aviso o log debe mostrar `TARRAJEO-PLANO-R9`.
5. Probar en una copia sin los acabados generados por intentos anteriores, pues también cuentan como sólidos visibles. El comando no los borra automáticamente.
6. Revisar los perfiles preparados y el contador de suelos confirmados. Si hay un rechazo nativo, conservar el log nuevo de esa ejecución; ahora debe incluir el boceto y el contexto del fallo incluso si ocurre durante el commit.

## Validación y límites

La suite ejecuta el código real del motor: **R9 pasa 67/67 pruebas**. La misma suite contra el snapshot de R8 pasa 61 y falla las seis nuevas. Los 61 casos anteriores y `CheckLocalRepair` permanecen intactos. Las regresiones públicas usan coordenadas genéricas y comprueban paños naturales, huecos independientes, unión y subconjunto exactos, mínimos, selección de una alternativa admitida y fracaso sin salidas parciales.

El validador de las pruebas es una función de lectura geométrica. Comprueba el contrato de selección de candidatos, **no simula ni ejecuta el kernel de Revit**. El caso privado que producía dos paños se comprobó por separado con la nueva API, sin pérdida de área.

La compilación semántica pasó con C# 7.3 y 81 referencias de metadatos reales de Revit. Incluye los tres archivos completos del motor, los cuerpos reales de las fases de creación, los nuevos auxiliares y la clase completa del preprocesador de fallos, sin ejecutar la aplicación. Las seis reproducciones privadas anteriores también pasan por la nueva API con dos mínimos de creación. La compilación completa en Linux continúa bloqueada por MSB4803/ResolveComReference; no se produce una DLL aquí ni se migran las dependencias de la solución Windows. La extrusión nativa, los parámetros de voladizo, `Floor.Create`, el commit y el contacto final deben validarse dentro de Revit.

## Entrega

Se publica únicamente el ZIP en una carpeta nueva de `bimchimbote-droid/DESCARGAS`, conservando las entregas anteriores. Se verifica mediante un clon independiente, comparando bytes, SHA-256, integridad y manifiesto. No se generan ni se envían enlaces de descarga.

La publicación no actualiza la instalación local ni realiza Commit/Push al repositorio del código. Después de aplicar y validar en Revit se pueden incorporar los cambios revisados desde Visual Studio. El modelo y el log geométrico permanecen fuera de la entrega pública.
