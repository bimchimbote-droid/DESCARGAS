using Autodesk.Revit.DB;
using MYG_Addin.RecorteClipper;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    internal sealed class ResultadoPlanoExterior
    {
        internal readonly List<List<CurveLoop>> Perfiles = new List<List<CurveLoop>>();
        internal readonly List<string> Rechazados = new List<string>();
        internal int SolidosDescontados;
        internal string Diagnostico;
    }

    internal static class TarrajeoRecorteExterior
    {
        // Rejilla local de 0.001 mm. No es una expansión de obstáculos ni una
        // tolerancia de creación de Revit; el error máximo por eje es 0.0005 mm.
        private const double Escala = 304800.0;
        private const double TolPlano = 1e-9;

        private sealed class Marco
        {
            internal XYZ Origen, U, V, N;
            internal IntPoint Proyectar(XYZ p)
            {
                XYZ d = p - Origen;
                double x = d.DotProduct(U) * Escala, y = d.DotProduct(V) * Escala;
                if (double.IsNaN(x) || double.IsInfinity(x) || Math.Abs(x) > 1e14 ||
                    double.IsNaN(y) || double.IsInfinity(y) || Math.Abs(y) > 1e14)
                    throw new InvalidOperationException("Coordenadas fuera del rango de recorte.");
                return new IntPoint((long)Math.Round(x, MidpointRounding.AwayFromZero),
                    (long)Math.Round(y, MidpointRounding.AwayFromZero));
            }
            internal XYZ Modelo(IntPoint p)
            {
                return Origen + U.Multiply(p.X / Escala) + V.Multiply(p.Y / Escala);
            }
        }

        internal static ResultadoPlanoExterior Calcular(
            IList<CurveLoop> cara, XYZ origen, XYZ normal, double espesor,
            IList<Solid> candidatos, double curvaCorta,
            IDictionary<Solid, string> origenes = null)
        {
            if (cara == null || cara.Count == 0 || origen == null || normal == null ||
                normal.GetLength() <= TolPlano || espesor <= 0.0 || curvaCorta < 0.0)
                throw new InvalidOperationException("Datos incompletos para el recorte exterior.");
            XYZ n = normal.Normalize();
            XYZ referencia = Math.Abs(n.X) < 0.9 ? XYZ.BasisX : XYZ.BasisY;
            XYZ u = (referencia - n.Multiply(referencia.DotProduct(n))).Normalize();
            var marco = new Marco { Origen = origen, U = u, V = n.CrossProduct(u), N = n };
            var region = ProyectarContornos(cara, marco);
            var limites = region.SelectMany(x => x).ToList();
            if (limites.Count == 0)
                throw new InvalidOperationException("La cara no tiene un dominio proyectable.");
            var sombras = new List<List<List<IntPoint>>>();
            var resultado = new ResultadoPlanoExterior();
            foreach (Solid candidato in candidatos ?? new List<Solid>())
            {
                if (candidato == null || candidato.Volume <= 1e-12)
                    continue;
                try
                {
                    // La caja solo descarta candidatos lejanos. Nunca se usa
                    // como huella cortante ni sustituye la geometría del sólido.
                    BoundingBoxXYZ caja = candidato.GetBoundingBox();
                    if (caja == null)
                        throw new InvalidOperationException("No se pudo delimitar el sólido candidato.");
                    var cajaUV = new List<IntPoint>();
                    Transform transformacionCaja = caja.Transform ?? Transform.Identity;
                    foreach (double x in new[] { caja.Min.X, caja.Max.X })
                        foreach (double y in new[] { caja.Min.Y, caja.Max.Y })
                            foreach (double z in new[] { caja.Min.Z, caja.Max.Z })
                                cajaUV.Add(marco.Proyectar(transformacionCaja.OfPoint(new XYZ(x, y, z))));
                    if (cajaUV.Max(p => p.X) <= limites.Min(p => p.X) ||
                        cajaUV.Min(p => p.X) >= limites.Max(p => p.X) ||
                        cajaUV.Max(p => p.Y) <= limites.Min(p => p.Y) ||
                        cajaUV.Min(p => p.Y) >= limites.Max(p => p.Y))
                        continue;
                    Solid exterior = RecortarEntrePlanos(candidato, origen, n, espesor);
                    if (exterior == null || exterior.Volume <= 1e-12)
                        continue;
                    int antes = sombras.Count;
                    foreach (Face superficie in exterior.Faces)
                    {
                        PlanarFace plana = superficie as PlanarFace;
                        if (plana != null)
                        {
                            if (Math.Abs(plana.FaceNormal.DotProduct(n)) <= 1e-10)
                                continue; // Su proyección tiene área nula.
                            sombras.Add(ProyectarContornos(plana.GetEdgesAsCurveLoops(), marco));
                        }
                        else
                        {
                            Mesh malla = superficie.Triangulate();
                            if (malla == null)
                                throw new InvalidOperationException("No se pudo medir una superficie curva.");
                            for (int i = 0; i < malla.NumTriangles; i++)
                            {
                                MeshTriangle t = malla.get_Triangle(i);
                                var triangulo = new List<IntPoint>
                                {
                                    marco.Proyectar(t.get_Vertex(0)), marco.Proyectar(t.get_Vertex(1)),
                                    marco.Proyectar(t.get_Vertex(2))
                                };
                                // No se ensanchan triángulos delgados. Primero se
                                // une TODA la sombra; sus diagonales desaparecen.
                                if (Math.Abs(Clipper.Area(triangulo)) >= 0.5)
                                    sombras.Add(new List<List<IntPoint>> { triangulo });
                            }
                        }
                    }
                    if (sombras.Count > antes)
                        resultado.SolidosDescontados++;
                }
                catch (Exception ex)
                {
                    string origenCandidato;
                    string detalle = origenes != null && origenes.TryGetValue(candidato, out origenCandidato)
                        ? origenCandidato : "sólido visible";
                    throw new InvalidOperationException("No se pudo medir el espesor exterior de " +
                        detalle + ". No se sustituyó su forma por una caja o triángulo ampliado. " + ex.Message, ex);
                }
            }
            PolyTree recorte = RecortePlanoExterior.Restar(region, sombras);
            if (recorte.Childs.Count == 1 && RecortePlanoExterior.MismoDominio(region, Clipper.PolyTreeToPaths(recorte)))
            {
                // Sin descuento real: conservar también los arcos originales.
                resultado.Perfiles.Add(cara.ToList());
                resultado.SolidosDescontados = 0;
                resultado.Diagnostico = "La cara no tiene interferencias en el espesor exterior; se conserva su contorno original.";
                return resultado;
            }
            int indice = 0;
            for (PolyNode nodo = recorte.GetFirst(); nodo != null; nodo = nodo.GetNext())
            {
                if (nodo.IsHole)
                    continue;
                indice++;
                try
                {
                    var perfil = new List<CurveLoop> { CrearContorno(nodo.Contour, marco, curvaCorta) };
                    foreach (PolyNode hueco in nodo.Childs.Where(x => x.IsHole))
                        perfil.Add(CrearContorno(hueco.Contour, marco, curvaCorta));
                    resultado.Perfiles.Add(perfil);
                }
                catch (Exception ex)
                {
                    resultado.Rechazados.Add("Región " + indice + ": " + ex.Message);
                }
            }
            resultado.Diagnostico = "Recorte directo en el plano de la cara: " + resultado.Perfiles.Count +
                " regiones reales; " + resultado.SolidosDescontados + " sólidos en el espesor exterior. " +
                "Sin particiones por franjas ni ensanchamiento de huellas.";
            return resultado;
        }

        private static Solid RecortarEntrePlanos(Solid candidato, XYZ origen, XYZ n, double espesor)
        {
            BoundingBoxXYZ caja = candidato.GetBoundingBox();
            if (caja == null)
                throw new InvalidOperationException("El sólido no tiene una caja geométrica válida.");
            double min = double.PositiveInfinity, max = double.NegativeInfinity;
            Transform tr = caja.Transform ?? Transform.Identity;
            foreach (double x in new[] { caja.Min.X, caja.Max.X })
                foreach (double y in new[] { caja.Min.Y, caja.Max.Y })
                    foreach (double z in new[] { caja.Min.Z, caja.Max.Z })
                    {
                        double d = (tr.OfPoint(new XYZ(x, y, z)) - origen).DotProduct(n);
                        min = Math.Min(min, d); max = Math.Max(max, d);
                    }
            if (max <= TolPlano || min >= espesor - TolPlano)
                return null; // Detrás, tangente o separado del acabado.
            Solid solido = candidato;
            if (min < 0.0)
                solido = BooleanOperationsUtils.CutWithHalfSpace(solido,
                    Plane.CreateByNormalAndOrigin(n, origen));
            if (solido == null || solido.Volume <= 1e-12)
                return null;
            if (max > espesor)
                solido = BooleanOperationsUtils.CutWithHalfSpace(solido,
                    Plane.CreateByNormalAndOrigin(n.Negate(), origen + n.Multiply(espesor)));
            return solido;
        }

        private static List<List<IntPoint>> ProyectarContornos(IList<CurveLoop> loops, Marco marco)
        {
            var caminos = new List<List<IntPoint>>();
            foreach (CurveLoop loop in loops)
            {
                if (loop == null || loop.IsOpen())
                    throw new InvalidOperationException("Se recibió un contorno abierto.");
                var puntos = new List<IntPoint>();
                foreach (Curve curva in loop)
                {
                    // En caras rectangulares son exactamente sus extremos.
                    // Las curvas reales usan la teselación de Revit solo cuando
                    // hay que representar un recorte mediante polígonos.
                    foreach (XYZ p in curva.Tessellate())
                    {
                        IntPoint uv = marco.Proyectar(p);
                        if (puntos.Count == 0 || puntos[puntos.Count - 1] != uv)
                            puntos.Add(uv);
                    }
                }
                puntos = RecortePlanoExterior.QuitarColineales(puntos);
                if (puntos.Count >= 3 && Math.Abs(Clipper.Area(puntos)) >= 0.5)
                    caminos.Add(puntos);
            }
            return caminos;
        }

        private static CurveLoop CrearContorno(List<IntPoint> camino, Marco marco, double curvaCorta)
        {
            var puntos = RecortePlanoExterior.QuitarColineales(camino);
            if (puntos.Count < 3)
                throw new InvalidOperationException("El recorte dejó un contorno degenerado.");
            var loop = new CurveLoop();
            for (int i = 0; i < puntos.Count; i++)
            {
                XYZ a = marco.Modelo(puntos[i]), b = marco.Modelo(puntos[(i + 1) % puntos.Count]);
                if (a.DistanceTo(b) <= curvaCorta)
                    throw new InvalidOperationException("El boceto final conserva una arista de " +
                        (a.DistanceTo(b) * 304.8).ToString("0.######") +
                        " mm menor que ShortCurveTolerance. No se alteró ni dividió el paño.");
                loop.Append(Line.CreateBound(a, b));
            }
            return loop;
        }
    }
}
