﻿// =====================================
// HANDLER - TARRAJEO SUELOS V30 - ALTURAS INTERNAS Y CONTACTO EXTERIOR
// - Origen vinculado correctamente excluido del recorte.
// - Diagnóstico detallado por etapa.
// - Procesa todas las islas resultantes de los booleanos.
// - Compatible con SeleccionarLosasTarrajeoHandler V20.
// - Limpia segmentos menores que Application.ShortCurveTolerance.
// - Resuelve automáticamente "Separar elementos" cuando Revit lo permite.
// - Resuelve automáticamente "Separar elementos" y bloquea diálogos modales.
// - Revierte en silencio cada isla imposible sin interrumpir el lote.
// - V27: corrige extrudeProjCurveLoops con limpieza planar y triangulación.
// - V28: solo descuenta elementos realmente visibles en la vista activa; respeta
//        Hide in View, categorías, filtros, Hide/Isolate temporal y vista vinculada.
// - V29: añade CustomExporter/IExportContext en vistas 3D. Un elemento nativo o
//        vinculado que Revit NO exporta/dibuja en la vista activa NO puede descontar
//        el tarrajeo, aunque exista físicamente en el modelo.
// - V30: usa ProjectElevation y revierte suelos horizontales fuera de contacto.
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

public class Tarrajeo_SuelosHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoForm Form;
    public FloorType TipoSuelo;
    public bool ConsiderarVinculos;
    public Reference FaceRef;
    public ExternalEvent SeleccionarEvent;

    // V21 - Identidad real del elemento cuya cara se procesa.
    // En vínculos se conserva tanto el elemento del LinkDocument como la
    // instancia concreta del vínculo para que no se descuente a sí mismo.
    private Element _elementoOrigenRecorte;
    private RevitLinkInstance _vinculoOrigenRecorte;

    // V25: conjunto completo del anfitrión compuesto. En escaleras incluye
    // escalera raíz, tramos, descansos, soportes y dependientes. Así ninguno
    // de esos sólidos puede descontar otra cara de la misma escalera.
    private readonly HashSet<ElementId> _idsOrigenRecorte = new HashSet<ElementId>();

    // V29 - Caché de visibilidad REAL de la vista activa 3D.
    private readonly HashSet<string> _idsVisiblesHostExportador = new HashSet<string>();
    private readonly HashSet<string> _idsVisiblesVinculoExportador = new HashSet<string>();
    private readonly HashSet<string> _contextosVinculoExportador = new HashSet<string>();
    private bool _cacheVisibilidadExportadorValida = false;
    private ElementId _vistaCacheVisibilidadId = ElementId.InvalidElementId;

    // Identidad del origen de extracción de cada sólido del lote actual.
    // La misma instancia Solid llega al respaldo planar, también en vínculos.
    private readonly Dictionary<Solid, string> _origenesSolidosCandidatos =
        new Dictionary<Solid, string>();

    // Último diagnóstico de creación. Los handlers por cara y por elementos
    // pueden mostrarlo cuando una cara no genera un suelo.
    public string UltimoDiagnostico { get; private set; } = string.Empty;
    public string RutaUltimoDiagnostico { get; private set; } = string.Empty;
    // Resultado de la última cara: un fallo de una isla no revierte las demás.
    public string UltimoAvisoParcial { get; private set; } = string.Empty;
    public int UltimaCantidadSuelosCreados { get; private set; }
    public int UltimaCantidadPerfilesOmitidos { get; private set; }

    // =========================================================
    // V29 - CONTEXTO LIGERO PARA VISIBILIDAD REAL DE LA VISTA 3D
    // =========================================================
    private class ContextoVinculoVisible
    {
        public Document Documento;
        public Transform Transformacion;
    }

    private class VisibilidadVistaExportContext : IExportContext
    {
        private readonly Document _docHost;
        private readonly Action<ElementId> _registrarHost;
        private readonly Action<Document, Transform, ElementId> _registrarVinculo;
        private readonly Action<Document, Transform> _registrarContextoVinculo;
        private readonly Stack<ContextoVinculoVisible> _pilaVinculos =
            new Stack<ContextoVinculoVisible>();

        public VisibilidadVistaExportContext(
            Document docHost,
            Action<ElementId> registrarHost,
            Action<Document, Transform, ElementId> registrarVinculo,
            Action<Document, Transform> registrarContextoVinculo)
        {
            _docHost = docHost;
            _registrarHost = registrarHost;
            _registrarVinculo = registrarVinculo;
            _registrarContextoVinculo = registrarContextoVinculo;
        }

        public bool Start() { return true; }
        public void Finish() { }
        public bool IsCanceled() { return false; }

        public RenderNodeAction OnViewBegin(ViewNode node)
        {
            return RenderNodeAction.Proceed;
        }

        public void OnViewEnd(ElementId elementId) { }

        public RenderNodeAction OnElementBegin(ElementId elementId)
        {
            try
            {
                if (elementId == null || elementId == ElementId.InvalidElementId)
                    return RenderNodeAction.Skip;

                if (_pilaVinculos.Count > 0)
                {
                    ContextoVinculoVisible c = _pilaVinculos.Peek();

                    if (c != null && c.Documento != null)
                    {
                        _registrarVinculo?.Invoke(
                            c.Documento,
                            c.Transformacion ?? Transform.Identity,
                            elementId);

                        Element eVinculado = null;

                        try
                        {
                            eVinculado = c.Documento.GetElement(elementId);
                        }
                        catch
                        {
                            eVinculado = null;
                        }

                        return eVinculado is RevitLinkInstance
                            ? RenderNodeAction.Proceed
                            : RenderNodeAction.Skip;
                    }

                    return RenderNodeAction.Skip;
                }

                _registrarHost?.Invoke(elementId);

                Element eHost = null;

                try
                {
                    eHost = _docHost?.GetElement(elementId);
                }
                catch
                {
                    eHost = null;
                }

                return eHost is RevitLinkInstance
                    ? RenderNodeAction.Proceed
                    : RenderNodeAction.Skip;
            }
            catch
            {
                return RenderNodeAction.Skip;
            }
        }

        public void OnElementEnd(ElementId elementId) { }

        public RenderNodeAction OnInstanceBegin(InstanceNode node)
        {
            return RenderNodeAction.Skip;
        }

        public void OnInstanceEnd(InstanceNode node) { }

        public RenderNodeAction OnLinkBegin(LinkNode node)
        {
            try
            {
                Document docLink = node != null ? node.GetDocument() : null;
                Transform tr = node != null ? node.GetTransform() : Transform.Identity;

                ContextoVinculoVisible c = new ContextoVinculoVisible()
                {
                    Documento = docLink,
                    Transformacion = tr ?? Transform.Identity
                };

                _pilaVinculos.Push(c);

                if (docLink != null)
                    _registrarContextoVinculo?.Invoke(
                        docLink,
                        c.Transformacion);

                return RenderNodeAction.Proceed;
            }
            catch
            {
                _pilaVinculos.Push(new ContextoVinculoVisible()
                {
                    Documento = null,
                    Transformacion = Transform.Identity
                });

                return RenderNodeAction.Proceed;
            }
        }

        public void OnLinkEnd(LinkNode node)
        {
            if (_pilaVinculos.Count > 0)
                _pilaVinculos.Pop();
        }

        public RenderNodeAction OnFaceBegin(FaceNode node)
        {
            return RenderNodeAction.Skip;
        }

        public void OnFaceEnd(FaceNode node) { }
        public void OnMaterial(MaterialNode node) { }
        public void OnPolymesh(PolymeshTopology node) { }
        public void OnRPC(RPCNode node) { }
        public void OnLight(LightNode node) { }
    }

    public void PrepararNuevaEjecucion()
    {
        ConfigurarOrigenesDeRecorte(null, null);
        UltimoDiagnostico = string.Empty;
        RutaUltimoDiagnostico = string.Empty;
        UltimoAvisoParcial = string.Empty;
        UltimaCantidadSuelosCreados = 0;
        UltimaCantidadPerfilesOmitidos = 0;

        ConstruirCacheVisibilidadVistaActiva();
    }

    // =========================================================
    // V29 - CACHÉ DE LO QUE REVIT REALMENTE DIBUJA EN LA VISTA ACTIVA
    // =========================================================
    private void ConstruirCacheVisibilidadVistaActiva()
    {
        _idsVisiblesHostExportador.Clear();
        _idsVisiblesVinculoExportador.Clear();
        _contextosVinculoExportador.Clear();
        _cacheVisibilidadExportadorValida = false;
        _vistaCacheVisibilidadId = ElementId.InvalidElementId;

        try
        {
            UIDocument uidoc = UiDoc;

            if (uidoc == null)
                return;

            Document doc = uidoc.Document;
            View vista = uidoc.ActiveView;

            if (doc == null || vista == null || vista.IsTemplate || !(vista is View3D))
                return;

            VisibilidadVistaExportContext contexto =
                new VisibilidadVistaExportContext(
                    doc,
                    id =>
                    {
                        if (id != null && id != ElementId.InvalidElementId)
                            _idsVisiblesHostExportador.Add(id.ToString());
                    },
                    (docLink, tr, id) =>
                    {
                        if (docLink == null ||
                            id == null ||
                            id == ElementId.InvalidElementId)
                        {
                            return;
                        }

                        _idsVisiblesVinculoExportador.Add(
                            ClaveElementoVinculadoExportador(
                                docLink,
                                tr,
                                id));
                    },
                    (docLink, tr) =>
                    {
                        if (docLink == null)
                            return;

                        _contextosVinculoExportador.Add(
                            ClaveContextoVinculoExportador(
                                docLink,
                                tr));
                    });

            using (CustomExporter exporter =
                new CustomExporter(doc, contexto))
            {
                exporter.IncludeGeometricObjects = false;
                exporter.ShouldStopOnError = false;
                exporter.Export(vista);
            }

            _vistaCacheVisibilidadId = vista.Id;
            _cacheVisibilidadExportadorValida = true;
        }
        catch
        {
            _idsVisiblesHostExportador.Clear();
            _idsVisiblesVinculoExportador.Clear();
            _contextosVinculoExportador.Clear();
            _cacheVisibilidadExportadorValida = false;
            _vistaCacheVisibilidadId = ElementId.InvalidElementId;
        }
    }

    private string ClaveDocumentoExportador(Document doc)
    {
        if (doc == null)
            return "DOC_NULL";

        string ruta = string.Empty;
        string titulo = string.Empty;

        try { ruta = doc.PathName ?? string.Empty; } catch { }
        try { titulo = doc.Title ?? string.Empty; } catch { }

        return ruta + "||" + titulo;
    }

    private string ClaveTransformExportador(Transform tr)
    {
        try
        {
            Transform t = tr ?? Transform.Identity;
            XYZ o = t.Origin;
            XYZ x = t.BasisX;
            XYZ y = t.BasisY;
            XYZ z = t.BasisZ;

            return
                Math.Round(o.X, 5) + "," +
                Math.Round(o.Y, 5) + "," +
                Math.Round(o.Z, 5) + "|" +
                Math.Round(x.X, 5) + "," +
                Math.Round(x.Y, 5) + "," +
                Math.Round(x.Z, 5) + "|" +
                Math.Round(y.X, 5) + "," +
                Math.Round(y.Y, 5) + "," +
                Math.Round(y.Z, 5) + "|" +
                Math.Round(z.X, 5) + "," +
                Math.Round(z.Y, 5) + "," +
                Math.Round(z.Z, 5);
        }
        catch
        {
            return "TR_ID";
        }
    }

    private string ClaveContextoVinculoExportador(
        Document docLink,
        Transform tr)
    {
        return
            ClaveDocumentoExportador(docLink) +
            "||" +
            ClaveTransformExportador(tr);
    }

    private string ClaveElementoVinculadoExportador(
        Document docLink,
        Transform tr,
        ElementId id)
    {
        return
            ClaveContextoVinculoExportador(docLink, tr) +
            "||" +
            (id != null ? id.ToString() : "ID_NULL");
    }

    private bool VistaCoincideConCacheExportador(View vista)
    {
        try
        {
            return
                _cacheVisibilidadExportadorValida &&
                vista != null &&
                _vistaCacheVisibilidadId != null &&
                _vistaCacheVisibilidadId != ElementId.InvalidElementId &&
                vista.Id.Equals(_vistaCacheVisibilidadId);
        }
        catch
        {
            return false;
        }
    }

    private bool EsVisibleHostSegunExportador(
        ElementId id,
        View vista)
    {
        if (!VistaCoincideConCacheExportador(vista))
            return true;

        if (id == null || id == ElementId.InvalidElementId)
            return false;

        return _idsVisiblesHostExportador.Contains(id.ToString());
    }

    private bool EsVisibleVinculoSegunExportador(
        Document docLink,
        Transform tr,
        ElementId id,
        View vistaHost)
    {
        if (!VistaCoincideConCacheExportador(vistaHost))
            return true;

        if (docLink == null ||
            id == null ||
            id == ElementId.InvalidElementId)
        {
            return false;
        }

        string contexto = ClaveContextoVinculoExportador(
            docLink,
            tr);

        if (!_contextosVinculoExportador.Contains(contexto))
            return false;

        string clave = ClaveElementoVinculadoExportador(
            docLink,
            tr,
            id);

        return _idsVisiblesVinculoExportador.Contains(clave);
    }

    public void ConfigurarOrigenDeRecorte(
        Element elementoGeometrico,
        RevitLinkInstance vinculoOrigen)
    {
        List<Element> elementos = new List<Element>();

        if (elementoGeometrico != null)
            elementos.Add(elementoGeometrico);

        ConfigurarOrigenesDeRecorte(elementos, vinculoOrigen);
    }

    public void ConfigurarOrigenesDeRecorte(
        IEnumerable<Element> elementosGeometricos,
        RevitLinkInstance vinculoOrigen)
    {
        _elementoOrigenRecorte = null;
        _vinculoOrigenRecorte = vinculoOrigen;
        _idsOrigenRecorte.Clear();

        if (elementosGeometricos == null)
            return;

        HashSet<string> visitados = new HashSet<string>();

        foreach (Element elemento in elementosGeometricos)
        {
            if (elemento == null)
                continue;

            if (_elementoOrigenRecorte == null)
                _elementoOrigenRecorte = elemento;

            AgregarOrigenYDependientesRecursivo(
                elemento,
                visitados,
                0);
        }
    }

    private void AgregarOrigenYDependientesRecursivo(
        Element elemento,
        HashSet<string> visitados,
        int profundidad)
    {
        if (elemento == null || visitados == null || profundidad > 8)
            return;

        string clave;

        try
        {
            clave = elemento.Document.GetHashCode().ToString() + "|" + elemento.Id.ToString();
        }
        catch
        {
            clave = elemento.Id.ToString();
        }

        if (!visitados.Add(clave))
            return;

        _idsOrigenRecorte.Add(elemento.Id);

        try
        {
            ICollection<ElementId> dependientes =
                elemento.GetDependentElements(null);

            if (dependientes == null)
                return;

            foreach (ElementId id in dependientes)
            {
                if (id == null || id == ElementId.InvalidElementId)
                    continue;

                Element dependiente = elemento.Document.GetElement(id);

                if (dependiente != null)
                {
                    AgregarOrigenYDependientesRecursivo(
                        dependiente,
                        visitados,
                        profundidad + 1);
                }
            }
        }
        catch
        {
        }
    }

    private const string VERSION_RECORTE = "TARRAJEO-PLANO-R4";
    private const double TOL = 1e-6;
    private const double MIN_AREA_CARA = 0.0001;
    private const double SEARCH_MARGIN = 0.50;
    private const double BOOLEAN_DEPTH_MIN = 0.10;
    // V26: separación mínima de respaldo para caras exactamente coincidentes.
    // 0.8 mm en pies. Solo se usa si el primer Floor.Create falla.
    private const double SEPARACION_EXTERIOR_REINTENTO = 0.8 / 304.8;

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;
        bool relanzarSeleccion = false;

        // El flujo por cara empieza un lote nuevo. El flujo por elementos
        // configura el origen antes de llamar al método público de creación.
        PrepararNuevaEjecucion();

        try
        {
            if (FaceRef == null)
            {
                UltimoDiagnostico = "No se ha seleccionado ninguna cara para suelo.";
                RegistrarDiagnosticoEnArchivo("Tarrajeo por cara", UltimoDiagnostico);
                return;
            }

            if (Form != null)
                ConsiderarVinculos = Form.ConsiderarVinculos;

            FloorType floorType = TipoSuelo;

            if (floorType == null && Form != null)
                floorType = Form.TipoSueloSeleccionado;

            if (floorType == null)
            {
                UltimoDiagnostico = "Debe seleccionar un tipo de suelo.";
                RegistrarDiagnosticoEnArchivo("Tarrajeo por cara", UltimoDiagnostico);
                return;
            }

            // A partir de aquí los errores pertenecen solo a esta cara.
            // Cerrar su aviso permite continuar hasta que el usuario pulse Esc.
            relanzarSeleccion = true;

            Element hostElem;
            Transform transformCara;

            PlanarFace hostFace = ObtenerCaraPlanarDesdeReferencia(
                doc,
                FaceRef,
                out hostElem,
                out transformCara);

            if (hostElem == null)
            {
                UltimoDiagnostico = "No se pudo obtener el elemento de la cara seleccionada.";
                RegistrarDiagnosticoEnArchivo("Tarrajeo por cara", UltimoDiagnostico);
                TaskDialog.Show("MYG - Cara no válida para suelo", VERSION_RECORTE + "\n" + UltimoDiagnostico);
                return;
            }

            if (hostFace == null)
            {
                UltimoDiagnostico = "La cara seleccionada no es plana o no pudo resolverse desde el vínculo.";
                RegistrarDiagnosticoEnArchivo("Tarrajeo por cara", UltimoDiagnostico);
                TaskDialog.Show("MYG - Cara no válida para suelo", VERSION_RECORTE + "\n" + UltimoDiagnostico);
                return;
            }

            bool creado = CrearSueloDesdeCaraPlanarProcesada(
                doc,
                uidoc,
                hostElem,
                hostFace,
                transformCara ?? Transform.Identity,
                floorType);

            if (!creado)
            {
                string detalle = string.IsNullOrWhiteSpace(UltimoDiagnostico)
                    ? "No se recibió un diagnóstico interno."
                    : UltimoDiagnostico;

                RegistrarDiagnosticoEnArchivo("Tarrajeo por cara", detalle);

                // Mostrar el diagnóstico de esta cara sin terminar la sesión.
                // El proceso masivo por elementos conserva su propio flujo.
                TaskDialog.Show(
                    "MYG - No se pudo crear el suelo",
                    VERSION_RECORTE + "\n" + detalle +
                    (string.IsNullOrWhiteSpace(RutaUltimoDiagnostico)
                        ? string.Empty
                        : "\n\nDiagnóstico guardado en:\n" + RutaUltimoDiagnostico));

                return;
            }

            if (!string.IsNullOrWhiteSpace(UltimoAvisoParcial))
            {
                // Un solo resumen al terminar esta cara; nunca un diálogo por isla.
                TaskDialog.Show(
                    "MYG - Suelos creados con piezas omitidas",
                    VERSION_RECORTE + "\nSuelos creados: " + UltimaCantidadSuelosCreados +
                    ". Piezas omitidas: " + UltimaCantidadPerfilesOmitidos + ".\n" +
                    UltimoAvisoParcial +
                    (string.IsNullOrWhiteSpace(RutaUltimoDiagnostico)
                        ? string.Empty
                        : "\n\nDiagnóstico guardado en:\n" + RutaUltimoDiagnostico));
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            relanzarSeleccion = false;
        }
        catch (Exception ex)
        {
            UltimoDiagnostico =
                "Error no controlado en tarrajeo por cara: " +
                ex.GetType().Name + " - " + ex.Message;

            RegistrarDiagnosticoEnArchivo(
                "Tarrajeo por cara",
                UltimoDiagnostico);

            TaskDialog.Show(
                "MYG - Error al crear el suelo",
                VERSION_RECORTE + "\n" + UltimoDiagnostico);
        }
        finally
        {
            FaceRef = null;

            if (relanzarSeleccion && SeleccionarEvent != null)
                SeleccionarEvent.Raise();
            else
                MostrarFormulario();
        }
    }

    // =========================================================
    // MÉTODO PÚBLICO PARA TARRAJEO POR ELEMENTOS
    // =========================================================
    // Permite que los handlers por elementos usen el mismo motor de suelos.
    // No llamar dentro de una Transaction abierta.
    // =========================================================

    public bool CrearSueloDesdeCaraPlanarProcesada(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        PlanarFace cara,
        Transform transformCara,
        FloorType floorType)
    {
        UltimoDiagnostico = string.Empty;
        UltimoAvisoParcial = string.Empty;
        UltimaCantidadSuelosCreados = 0;
        UltimaCantidadPerfilesOmitidos = 0;
        RutaUltimoDiagnostico = string.Empty;

        int cantidadSolidosCandidatos = 0;
        int cantidadRecortesAplicados = 0;
        int cantidadCarasProcesadas = 0;

        try
        {
            if (doc == null)
                return Fallar("Validación", "El documento activo es nulo.");

            if (uidoc == null)
                return Fallar("Validación", "El UIDocument activo es nulo.");

            if (hostElem == null)
                return Fallar("Validación", "No se recibió el elemento anfitrión.");

            if (cara == null)
                return Fallar("Validación", "La referencia no devolvió una PlanarFace.");

            if (floorType == null)
                return Fallar("Validación", "No se recibió un tipo de suelo.");

            if (transformCara == null)
                transformCara = Transform.Identity;

            double toleranciaCurvaCorta = ObtenerToleranciaCurvaCorta(doc);

            //-------------------------------------------------
            // NORMAL Y ORIGEN EN COORDENADAS DEL PROYECTO
            //-------------------------------------------------
            XYZ normalModelo = transformCara.OfVector(cara.FaceNormal);

            if (normalModelo == null || normalModelo.GetLength() <= TOL)
                return Fallar("Geometría de la cara", "La normal transformada es nula o tiene longitud cero.");

            normalModelo = normalModelo.Normalize();
            XYZ originModelo = transformCara.OfPoint(cara.Origin);

            //-------------------------------------------------
            // Evitar que el flujo de suelos cree desde caras verticales.
            //-------------------------------------------------
            if (Math.Abs(normalModelo.Z) < 0.001)
            {
                return Fallar(
                    "Clasificación de la cara",
                    "La cara es vertical o casi vertical. |Normal.Z| = " +
                    Math.Abs(normalModelo.Z).ToString("0.000000") +
                    ". Esa cara corresponde al motor de muros.");
            }

            //-------------------------------------------------
            // Loops reales de la cara en coordenadas del proyecto.
            //-------------------------------------------------
            IList<CurveLoop> loopsOriginales = null;

            try
            {
                loopsOriginales = cara.GetEdgesAsCurveLoops();
            }
            catch (Exception ex)
            {
                return Fallar("Lectura de contorno", "Revit no devolvió los bordes de la cara.", ex);
            }

            if (loopsOriginales == null || loopsOriginales.Count == 0)
                return Fallar("Lectura de contorno", "La cara no contiene CurveLoops.");

            List<CurveLoop> loopsModelo = TransformCurveLoops(
                loopsOriginales,
                transformCara);

            if (loopsModelo == null || loopsModelo.Count == 0)
            {
                return Fallar(
                    "Transformación del contorno",
                    "Ningún loop permaneció cerrado después de transformar la cara al modelo anfitrión.");
            }

            double espesor = GetFloorThickness(floorType);
            if (double.IsNaN(espesor) || double.IsInfinity(espesor) || espesor <= TOL)
                return Fallar("Espesor", "El tipo de suelo no tiene un espesor físico válido.");

            Outline outline = CreateOutlineFromLoops(loopsModelo, normalModelo, espesor + SEARCH_MARGIN);
            if (outline == null)
                return Fallar("Contorno", "No se pudo delimitar la cara seleccionada.");
            List<Solid> candidatos = GetVisibleNativeAndLinkedSolids(
                doc, uidoc.ActiveView, outline, hostElem.Id);
            cantidadSolidosCandidatos = candidatos != null ? candidatos.Count : 0;

            // Único motor: cara original MENOS unión de las huellas reales
            // dentro de [cara, cara + normal * espesor]. No hay Difference 3D
            // sucesivas ni reconstrucción desde caras/triángulos incompletos.
            ResultadoPlanoExterior recorte = TarrajeoRecorteExterior.Calcular(
                loopsModelo, originModelo, normalModelo, espesor, candidatos,
                toleranciaCurvaCorta, _origenesSolidosCandidatos);
            cantidadRecortesAplicados = recorte.SolidosDescontados;
            cantidadCarasProcesadas = recorte.Perfiles.Count;
            foreach (string rechazo in recorte.Rechazados)
                RegistrarPerfilesOmitidos(1, rechazo);
            if (recorte.Perfiles.Count == 0)
                return Fallar("Recorte en el plano", recorte.Rechazados.Count > 0
                    ? string.Join(" | ", recorte.Rechazados)
                    : "Los sólidos visibles ocupan toda la cara dentro del espesor exterior.");

            Level nivel = GetBaseLevelForFloor(doc, hostElem, originModelo.Z);
            if (nivel == null)
                return Fallar("Nivel base", "No se encontró un nivel válido.");
            bool esInclinado = normalModelo.CrossProduct(XYZ.BasisZ).GetLength() > 1e-10;
            Plane planoCara = Plane.CreateByNormalAndOrigin(normalModelo, originModelo);
            int creados = 0, indiceBoceto = 0, puntosDiagnosticoRestantes = 10000;
            var erroresCreacion = new List<string>();
            foreach (List<CurveLoop> perfil in recorte.Perfiles)
            {
                indiceBoceto++;
                try
                {
                    List<CurveLoop> sketch = BocetoHorizontalSinCambiarContorno(
                        perfil, planoCara, nivel.ProjectElevation);
                    string detalleCreacion;
                    bool perfilRechazado;
                    if (IntentarCrearSuelo(doc, sketch, floorType, nivel, originModelo, normalModelo,
                        espesor, esInclinado, 0.0, out detalleCreacion, out perfilRechazado))
                    {
                        creados++;
                        UltimaCantidadSuelosCreados = creados;
                    }
                    else
                    {
                        if (perfilRechazado)
                            RegistrarBocetoRechazado(indiceBoceto, 0, sketch,
                                detalleCreacion, ref puntosDiagnosticoRestantes);
                        erroresCreacion.Add(detalleCreacion);
                        RegistrarPerfilesOmitidos(1, "Región " + indiceBoceto + ": " + detalleCreacion);
                    }
                }
                catch (Exception ex)
                {
                    string fallo = "Región " + indiceBoceto + ": " + ex.Message;
                    erroresCreacion.Add(fallo);
                    RegistrarPerfilesOmitidos(1, fallo);
                }
            }

            if (creados == 0)
            {
                return Fallar(
                    "Floor.Create",
                    "Revit rechazó todos los bocetos. " +
                    (erroresCreacion.Count > 0
                        ? string.Join(" | ", erroresCreacion.Take(4))
                        : "No se obtuvo una excepción detallada."));
            }

            UltimoDiagnostico =
                (UltimaCantidadPerfilesOmitidos > 0
                    ? "Creación parcial. Suelos creados: "
                    : "Creación correcta. Suelos creados: ") + creados +
                "; sólidos candidatos: " + cantidadSolidosCandidatos +
                "; recortes aplicados: " + cantidadRecortesAplicados +
                "; regiones naturales: " + cantidadCarasProcesadas +
                "; piezas omitidas: " + UltimaCantidadPerfilesOmitidos + ". " + recorte.Diagnostico;

            if (!string.IsNullOrWhiteSpace(UltimoAvisoParcial))
            {
                UltimoDiagnostico += "\n" + UltimoAvisoParcial;
            }
            // También registrar éxitos completos: permite comprobar qué DLL
            // cargó Revit sin añadir diálogos ni alterar la creación del suelo.
            RegistrarDiagnosticoEnArchivo(
                string.IsNullOrWhiteSpace(UltimoAvisoParcial)
                    ? "Tarrajeo de suelos: creación correcta"
                    : "Tarrajeo de suelos: creación parcial",
                UltimoDiagnostico);
            return true;
        }
        catch (Exception ex)
        {
            return Fallar(
                "Error no controlado",
                "La operación terminó en una excepción no prevista.",
                ex);
        }
    }

    private List<CurveLoop> BocetoHorizontalSinCambiarContorno(
        IList<CurveLoop> perfil, Plane plano, double zSketch)
    {
        var resultado = new List<CurveLoop>();
        bool horizontal = plano.Normal.CrossProduct(XYZ.BasisZ).GetLength() <= 1e-10;
        Transform traslado = Transform.CreateTranslation(new XYZ(0.0, 0.0, zSketch - plano.Origin.Z));
        foreach (CurveLoop contorno in perfil)
        {
            var loop = new CurveLoop();
            if (horizontal)
            {
                foreach (Curve curva in contorno)
                    loop.Append(curva.CreateTransformed(traslado));
            }
            else
            {
                // El editor de forma recupera después la Z del plano original.
                // La proyección XY no limpia ni descarta vértices del boceto.
                var puntos = new List<XYZ>();
                foreach (Curve curva in contorno)
                    foreach (XYZ p in curva.Tessellate())
                    {
                        var xy = new XYZ(p.X, p.Y, zSketch);
                        if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(xy) > 1e-9)
                            puntos.Add(xy);
                    }
                if (puntos.Count > 1 && puntos[0].DistanceTo(puntos[puntos.Count - 1]) <= 1e-9)
                    puntos.RemoveAt(puntos.Count - 1);
                for (int i = 0; i < puntos.Count; i++)
                    loop.Append(Line.CreateBound(puntos[i], puntos[(i + 1) % puntos.Count]));
            }
            if (loop.IsOpen())
                throw new InvalidOperationException("La proyección horizontal no conserva el cierre del contorno.");
            resultado.Add(loop);
        }
        if (resultado.Count != perfil.Count)
            throw new InvalidOperationException("Se perdió un contorno o hueco al proyectar.");
        return resultado;
    }

    private List<CurveLoop> ConstruirSketchHorizontalDesdeCara(
        PlanarFace processedFace,
        Plane hostPlane,
        double zSketch,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;

        if (processedFace == null)
        {
            detalle = "La cara procesada es nula.";
            return null;
        }

        IList<CurveLoop> loops = null;

        try
        {
            loops = processedFace.GetEdgesAsCurveLoops();
        }
        catch (Exception ex)
        {
            detalle = "No se pudieron leer los loops de una cara procesada: " + ex.Message;
            return null;
        }

        return ConstruirSketchHorizontalDesdeLoops(
            loops != null ? loops.ToList() : null,
            hostPlane,
            zSketch,
            toleranciaCurvaCorta,
            out detalle);
    }

    private List<CurveLoop> ConstruirSketchHorizontalDesdeLoops(
        IList<CurveLoop> loops,
        Plane hostPlane,
        double zSketch,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;
        List<CurveLoop> resultado = new List<CurveLoop>();
        List<string> errores = new List<string>();

        if (loops == null || loops.Count == 0)
        {
            detalle = "No existen loops para proyectar.";
            return resultado;
        }

        //-------------------------------------------------
        // V26 - CARAS HORIZONTALES:
        // Para una cara horizontal no se tessellan ni reconstruyen los bordes.
        // Se conservan las curvas originales (líneas, arcos, etc.) y solo se
        // trasladan al nivel del boceto. Esto evita picos, segmentos diminutos
        // y perfiles autointersectados en encuentros de tramo + descanso.
        //-------------------------------------------------
        if (hostPlane != null &&
            hostPlane.Normal != null &&
            Math.Abs(Math.Abs(hostPlane.Normal.Z) - 1.0) <= 0.0001)
        {
            string detalleExacto;
            List<CurveLoop> exactos =
                ConstruirLoopsHorizontalesExactos(
                    loops,
                    hostPlane,
                    zSketch,
                    toleranciaCurvaCorta,
                    out detalleExacto);

            if (exactos != null && exactos.Count > 0)
                return exactos;

            if (!string.IsNullOrWhiteSpace(detalleExacto))
                errores.Add("Intento exacto: " + detalleExacto);
        }

        //-------------------------------------------------
        // RESPALDO PARA CARAS INCLINADAS O CONTORNOS QUE NO
        // PUDIERON CONSERVARSE EXACTAMENTE.
        //-------------------------------------------------
        foreach (CurveLoop loop in loops)
        {
            string detalleLoop;

            CurveLoop flatLoop = ProyectarLoopANivel(
                loop,
                hostPlane,
                zSketch,
                toleranciaCurvaCorta,
                out detalleLoop);

            if (flatLoop == null || flatLoop.IsOpen())
            {
                if (!string.IsNullOrWhiteSpace(detalleLoop))
                    errores.Add(detalleLoop);

                continue;
            }

            double area = Math.Abs(AreaLoopXY(flatLoop));

            if (area <= MIN_AREA_CARA)
            {
                errores.Add("Loop descartado por área mínima: " + area.ToString("0.000000") + " ft².");
                continue;
            }

            resultado.Add(flatLoop);
        }

        resultado = resultado
            .OrderByDescending(lp => Math.Abs(AreaLoopXY(lp)))
            .ToList();

        if (resultado.Count == 0)
        {
            detalle =
                "Todos los loops quedaron abiertos, degenerados o con segmentos menores que " +
                toleranciaCurvaCorta.ToString("0.000000") + " ft.";

            if (errores.Count > 0)
                detalle += " " + string.Join(" | ", errores.Take(4));
        }

        return resultado;
    }

    private List<CurveLoop> ConstruirLoopsHorizontalesExactos(
        IList<CurveLoop> loops,
        Plane hostPlane,
        double zSketch,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;
        List<CurveLoop> resultado = new List<CurveLoop>();
        List<string> errores = new List<string>();

        if (loops == null || loops.Count == 0 || hostPlane == null)
        {
            detalle = "No existen loops o plano anfitrión para el traslado exacto.";
            return resultado;
        }

        double tol = Math.Max(toleranciaCurvaCorta * 1.01, 1e-6);
        double dz = zSketch - hostPlane.Origin.Z;
        Transform traslado = Transform.CreateTranslation(new XYZ(0.0, 0.0, dz));

        foreach (CurveLoop loop in loops)
        {
            if (loop == null)
                continue;

            CurveLoop nuevo = new CurveLoop();
            bool valido = true;
            int cantidadCurvas = 0;

            foreach (Curve curva in loop)
            {
                if (curva == null)
                    continue;

                try
                {
                    Curve trasladada = curva.CreateTransformed(traslado);

                    if (trasladada == null || trasladada.Length < tol)
                    {
                        valido = false;
                        errores.Add(
                            "El contorno exacto contiene una curva de " +
                            (trasladada != null
                                ? trasladada.Length.ToString("0.000000")
                                : "0") +
                            " ft, menor que ShortCurveTolerance.");
                        break;
                    }

                    nuevo.Append(trasladada);
                    cantidadCurvas++;
                }
                catch (Exception ex)
                {
                    valido = false;
                    errores.Add(
                        "No se pudo trasladar una curva exacta: " +
                        ex.GetType().Name + " - " + ex.Message);
                    break;
                }
            }

            if (!valido || cantidadCurvas < 3 || nuevo.IsOpen())
                continue;

            double area = Math.Abs(AreaLoopXY(nuevo));

            if (area <= MIN_AREA_CARA)
            {
                errores.Add(
                    "Loop exacto descartado por área mínima: " +
                    area.ToString("0.000000") + " ft².");
                continue;
            }

            resultado.Add(nuevo);
        }

        resultado = resultado
            .OrderByDescending(lp => Math.Abs(AreaLoopXY(lp)))
            .ToList();

        if (resultado.Count == 0)
        {
            detalle = errores.Count > 0
                ? string.Join(" | ", errores.Take(4))
                : "Ningún loop horizontal exacto permaneció cerrado y válido.";
        }

        return resultado;
    }


    private bool EsRechazoDePerfilSuelo(Exception ex)
    {
        if (ex == null || (!(ex is ArgumentException) &&
            ex.GetType().FullName != "Autodesk.Revit.Exceptions.ArgumentException"))
            return false;
        string parametro = null;
        var argumento = ex as ArgumentException;
        if (argumento != null)
            parametro = argumento.ParamName;
        else
        {
            try
            {
                PropertyInfo propiedad = ex.GetType().GetProperty("ParamName");
                if (propiedad != null)
                    parametro = propiedad.GetValue(ex, null) as string;
            }
            catch
            {
            }
        }
        if (string.Equals(parametro, "profile", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(parametro, "curveLoops", StringComparison.OrdinalIgnoreCase))
            return true;
        // Algunas versiones del wrapper nativo solo incluyen el nombre del
        // argumento en Message. No activar por un error de tipo, nivel o forma.
        return string.IsNullOrEmpty(parametro) &&
            (ex.Message.IndexOf("Parameter name: profile", StringComparison.OrdinalIgnoreCase) >= 0 ||
             ex.Message.IndexOf("Parameter name: curveLoops", StringComparison.OrdinalIgnoreCase) >= 0);
    }

    private double ObtenerAreaMaterialBoceto(IList<CurveLoop> boceto)
    {
        if (boceto == null || boceto.Count == 0)
            return 0.0;
        var areas = boceto.Select(lp => Math.Abs(AreaLoopXY(lp))).OrderByDescending(x => x).ToList();
        return (areas[0] - areas.Skip(1).Sum()) * 92903.04;
    }

    private string CoordenadasDiagnosticoSuelo(XYZ punto)
    {
        if (punto == null)
            return "null";
        var cultura = System.Globalization.CultureInfo.InvariantCulture;
        return "(" + punto.X.ToString("G17", cultura) + ", " +
            punto.Y.ToString("G17", cultura) + ", " + punto.Z.ToString("G17", cultura) + ")";
    }

    private void RegistrarBocetoRechazado(
        int isla, int profundidad, IList<CurveLoop> boceto,
        string motivo, ref int puntosRestantes)
    {
        // Solo diagnóstico local. El detalle geométrico no se concatena al
        // TaskDialog ni cambia los contadores de piezas omitidas.
        try
        {
            var texto = new System.Text.StringBuilder();
            texto.AppendLine("Isla " + isla + "; profundidad " + profundidad + "; " + motivo);
            texto.AppendLine("Coordenadas XYZ en pies internos, formato invariante G17.");
            texto.AppendLine("Área material estimada XY: " + ObtenerAreaMaterialBoceto(boceto)
                .ToString("G17", System.Globalization.CultureInfo.InvariantCulture) + " mm².");
            texto.AppendLine("Contornos: " + (boceto != null ? boceto.Count : 0));
            bool truncado = false;
            if (boceto != null)
            {
                for (int i = 0; i < boceto.Count && !truncado; i++)
                {
                    CurveLoop loop = boceto[i];
                    if (loop == null)
                    {
                        texto.AppendLine("Loop " + (i + 1) + ": null.");
                        continue;
                    }
                    texto.AppendLine("Loop " + (i + 1) + ": abierto=" + loop.IsOpen());
                    try
                    {
                        Plane plano = loop.GetPlane();
                        texto.AppendLine("  Plano: origen=" + CoordenadasDiagnosticoSuelo(plano.Origin) +
                            "; normal=" + CoordenadasDiagnosticoSuelo(plano.Normal));
                    }
                    catch (Exception ex)
                    {
                        texto.AppendLine("  Plano no disponible: " + ex.GetType().Name + ".");
                    }
                    int numeroCurva = 0;
                    foreach (Curve curva in loop)
                    {
                        numeroCurva++;
                        if (curva == null)
                        {
                            texto.AppendLine("  Curva " + numeroCurva + ": null.");
                            continue;
                        }
                        texto.AppendLine("  Curva " + numeroCurva + ": " + curva.GetType().FullName);
                        try
                        {
                            if (puntosRestantes < 2)
                            {
                                truncado = true;
                                break;
                            }
                            texto.AppendLine("    Inicio=" + CoordenadasDiagnosticoSuelo(curva.GetEndPoint(0)) +
                                "; fin=" + CoordenadasDiagnosticoSuelo(curva.GetEndPoint(1)));
                            puntosRestantes -= 2;
                            if (!(curva is Line))
                            {
                                // Tessellate solo se usa para registrar la curva,
                                // nunca para reemplazarla en el boceto de creación.
                                IList<XYZ> muestras = curva.Tessellate();
                                texto.AppendLine("    Muestras de diagnóstico: " + muestras.Count);
                                foreach (XYZ punto in muestras)
                                {
                                    if (puntosRestantes <= 0)
                                    {
                                        truncado = true;
                                        break;
                                    }
                                    texto.AppendLine("      " + CoordenadasDiagnosticoSuelo(punto));
                                    puntosRestantes--;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            texto.AppendLine("    GEOMETRÍA INCOMPLETA: " + ex.GetType().Name + " - " + ex.Message);
                        }
                        if (truncado)
                            break;
                    }
                }
            }
            if (truncado)
                texto.AppendLine("GEOMETRÍA TRUNCADA: se agotó el presupuesto de 10000 puntos de diagnóstico de esta cara.");
            else
                texto.AppendLine("Fin de la geometría del boceto rechazado.");
            RegistrarDiagnosticoEnArchivo("Tarrajeo R4: geometría del boceto rechazado", texto.ToString());
        }
        catch (Exception ex)
        {
            RegistrarDiagnosticoEnArchivo("Tarrajeo R4: geometría incompleta",
                "No se pudo registrar el boceto de isla " + isla + ": " + ex.GetType().Name + " - " + ex.Message);
        }
    }

    private bool IntentarCrearSuelo(
        Document doc,
        List<CurveLoop> horizontalSketch,
        FloorType floorType,
        Level nivel,
        XYZ originModelo,
        XYZ normalModelo,
        double espesor,
        bool esInclinado,
        double separacionExterior,
        out string detalle,
        out bool perfilRechazado)
    {
        detalle = string.Empty;
        perfilRechazado = false;
        if (horizontalSketch != null && horizontalSketch.Count > 0)
        {
            try
            {
                if (!BoundaryValidation.IsValidHorizontalBoundary(horizontalSketch))
                {
                    detalle = "BoundaryValidation rechazó la frontera horizontal antes de Floor.Create.";
                    perfilRechazado = true;
                    return false;
                }
            }
            catch (Exception ex)
            {
                detalle = "No se pudo validar la frontera horizontal: " + ex.GetType().Name + " - " + ex.Message;
                perfilRechazado = EsRechazoDePerfilSuelo(ex);
                return false;
            }
        }

        // Las fases existentes confirman varias transacciones. El grupo permite
        // revertirlas juntas si la geometría final no coincide con la cara.
        using (TransactionGroup grupo = new TransactionGroup(doc, "MYG Validar suelo por cara"))
        {
            try
            {
                grupo.Start();
                ElementId sueloCreadoId;
                bool creado = IntentarCrearSueloPorFases(
                    doc, horizontalSketch, floorType, nivel, originModelo,
                    normalModelo, espesor, esInclinado, separacionExterior,
                    out sueloCreadoId, out detalle, out perfilRechazado);

                if (!creado)
                {
                    grupo.RollBack();
                    return false;
                }

                if (!TarrajeoValidacionSuelo.ComprobarContactoHorizontal(
                    doc.GetElement(sueloCreadoId) as Floor, originModelo, normalModelo,
                    separacionExterior, out detalle))
                {
                    detalle += " Z de cara: " + originModelo.Z.ToString("G17") +
                        "; nivel interno: " + nivel.ProjectElevation.ToString("G17") +
                        "; elevación mostrada: " + nivel.Elevation.ToString("G17") +
                        ". Se revirtió el suelo creado.";
                    grupo.RollBack();
                    return false;
                }

                if (grupo.Assimilate() != TransactionStatus.Committed)
                {
                    detalle = "Revit no confirmó el grupo de creación del suelo.";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                if (grupo.GetStatus() == TransactionStatus.Started)
                    grupo.RollBack();

                detalle = "Creación o validación del suelo: " + ex.Message;
                return false;
            }
        }
    }

    private bool IntentarCrearSueloPorFases(
        Document doc,
        List<CurveLoop> horizontalSketch,
        FloorType floorType,
        Level nivel,
        XYZ originModelo,
        XYZ normalModelo,
        double espesor,
        bool esInclinado,
        double separacionExterior,
        out ElementId sueloCreadoId,
        out string detalle,
        out bool perfilRechazado)
    {
        sueloCreadoId = ElementId.InvalidElementId;
        detalle = string.Empty;
        perfilRechazado = false;

        if (doc == null ||
            horizontalSketch == null ||
            horizontalSketch.Count == 0 ||
            floorType == null ||
            nivel == null)
        {
            detalle = "Datos incompletos antes de Floor.Create.";
            return false;
        }

        Floor newFloor = null;
        ElementId newFloorId = ElementId.InvalidElementId;

        //---------------------------------------------------------
        // V28 - FASE 1: CREAR Y CONFIRMAR EL SUELO BASE.
        //
        // No se llama a doc.Regenerate() dentro de la transacción.
        // De esta manera los conflictos de unión llegan al Commit,
        // donde el IFailuresPreprocessor puede elegir automáticamente
        // la resolución equivalente a "Separar elementos".
        //---------------------------------------------------------
        Transaction tCrear = new Transaction(
            doc,
            separacionExterior > 0.0
                ? "MYG Tarrajeo Suelos - respaldo 0.8 mm"
                : "MYG Tarrajeo Suelos");

        MYG_TarrajeoSueloSilenciosoV24 preCrear =
            new MYG_TarrajeoSueloSilenciosoV24();

        bool creandoFrontera = false;
        try
        {
            tCrear.Start();
            ConfigurarTransaccionSilenciosa(tCrear, preCrear);

            creandoFrontera = true;
            newFloor = Floor.Create(
                doc,
                horizontalSketch,
                floorType.Id,
                nivel.Id);
            creandoFrontera = false;

            if (newFloor == null)
            {
                tCrear.RollBack();
                detalle = "Floor.Create devolvió null.";
                return false;
            }

            newFloorId = newFloor.Id;
            sueloCreadoId = newFloorId;

            if (!esInclinado)
            {
                // La cara y el nivel deben compartir el origen interno del proyecto.
                // Arriba: la cara inferior del acabado toca la cara seleccionada.
                // Abajo: su cara superior toca la cara seleccionada.
                double offset = TarrajeoAlturas.CalcularDesfase(
                    originModelo.Z, nivel.ProjectElevation, normalModelo.Z,
                    espesor, separacionExterior);

                Parameter pOffset =
                    newFloor.get_Parameter(
                        BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM);

                if (pOffset == null)
                    throw new InvalidOperationException("No se pudo aplicar el desfase del suelo.");

                if (!pOffset.IsReadOnly)
                    pOffset.Set(offset);

                // Set puede devolver false si el parámetro ya tenía ese valor.
                // Lo importante es comprobar el valor que realmente quedó.
                double offsetAplicado = pOffset.AsDouble();
                if (double.IsNaN(offsetAplicado) || double.IsInfinity(offsetAplicado) ||
                    Math.Abs(offsetAplicado - offset) > TarrajeoAlturas.ToleranciaContactoPies)
                {
                    throw new InvalidOperationException("El desfase del suelo no coincide con la altura solicitada.");
                }
            }

            GuardarIdEnParametro(
                newFloor,
                "GEN_ID Elemento");

            TransactionStatus estadoCrear = tCrear.Commit();

            if (estadoCrear != TransactionStatus.Committed)
            {
                detalle =
                    "La creación del suelo se revirtió silenciosamente.";

                if (!string.IsNullOrWhiteSpace(preCrear.UltimoMensaje))
                    detalle += " " + preCrear.UltimoMensaje;

                return false;
            }

            newFloor = doc.GetElement(newFloorId) as Floor;

            if (newFloor == null)
            {
                detalle =
                    "Revit resolvió el conflicto eliminando el suelo recién creado.";
                return false;
            }

            if (!esInclinado)
                return true;
        }
        catch (Exception ex)
        {
            perfilRechazado = creandoFrontera && EsRechazoDePerfilSuelo(ex);
            try
            {
                if (tCrear.GetStatus() == TransactionStatus.Started)
                    tCrear.RollBack();
            }
            catch
            {
            }

            detalle =
                "Creación base: " +
                ex.GetType().Name +
                " - " +
                ex.Message;

            if (!string.IsNullOrWhiteSpace(preCrear.UltimoMensaje))
                detalle += " | " + preCrear.UltimoMensaje;

            return false;
        }

        //---------------------------------------------------------
        // V28 - FASE 2: HABILITAR EL EDITOR DE FORMA Y CONFIRMAR.
        //
        // Se hace en una transacción independiente. El Commit de la
        // fase anterior ya resolvió cualquier unión automática, por lo
        // que no es necesario regenerar manualmente ni abrir diálogos.
        //---------------------------------------------------------
        Transaction tHabilitar = new Transaction(
            doc,
            "MYG Tarrajeo Suelos - habilitar forma");

        MYG_TarrajeoSueloSilenciosoV24 preHabilitar =
            new MYG_TarrajeoSueloSilenciosoV24();

        try
        {
            tHabilitar.Start();
            ConfigurarTransaccionSilenciosa(tHabilitar, preHabilitar);

            newFloor = doc.GetElement(newFloorId) as Floor;

            if (newFloor == null)
            {
                tHabilitar.RollBack();
                detalle = "El suelo dejó de existir antes de habilitar su forma.";
                return false;
            }

            SlabShapeEditor editorHabilitar =
                newFloor.GetSlabShapeEditor();

            if (editorHabilitar == null)
            {
                tHabilitar.RollBack();
                detalle = "El suelo inclinado no devolvió SlabShapeEditor.";
                EliminarElementoCreadoSilenciosamente(doc, newFloorId);
                return false;
            }

            editorHabilitar.Enable();

            TransactionStatus estadoHabilitar = tHabilitar.Commit();

            if (estadoHabilitar != TransactionStatus.Committed)
            {
                detalle = "No se pudo habilitar el editor de forma en silencio.";

                if (!string.IsNullOrWhiteSpace(preHabilitar.UltimoMensaje))
                    detalle += " " + preHabilitar.UltimoMensaje;

                EliminarElementoCreadoSilenciosamente(doc, newFloorId);
                return false;
            }
        }
        catch (Exception ex)
        {
            try
            {
                if (tHabilitar.GetStatus() == TransactionStatus.Started)
                    tHabilitar.RollBack();
            }
            catch
            {
            }

            detalle =
                "Habilitar forma: " +
                ex.GetType().Name +
                " - " +
                ex.Message;

            if (!string.IsNullOrWhiteSpace(preHabilitar.UltimoMensaje))
                detalle += " | " + preHabilitar.UltimoMensaje;

            EliminarElementoCreadoSilenciosamente(doc, newFloorId);
            return false;
        }

        //---------------------------------------------------------
        // V28 - FASE 3: MODIFICAR LOS VÉRTICES Y CONFIRMAR.
        //
        // Después de confirmar la habilitación, Revit ya expone los
        // SlabShapeVertices. Se evita nuevamente doc.Regenerate().
        //---------------------------------------------------------
        Transaction tForma = new Transaction(
            doc,
            "MYG Tarrajeo Suelos - aplicar inclinación");

        MYG_TarrajeoSueloSilenciosoV24 preForma =
            new MYG_TarrajeoSueloSilenciosoV24();

        try
        {
            tForma.Start();
            ConfigurarTransaccionSilenciosa(tForma, preForma);

            newFloor = doc.GetElement(newFloorId) as Floor;

            if (newFloor == null)
            {
                tForma.RollBack();
                detalle = "El suelo dejó de existir antes de aplicar la inclinación.";
                return false;
            }

            SlabShapeEditor shapeEditor =
                newFloor.GetSlabShapeEditor();

            if (shapeEditor == null)
            {
                tForma.RollBack();
                detalle = "No se recuperó SlabShapeEditor al aplicar la inclinación.";
                EliminarElementoCreadoSilenciosamente(doc, newFloorId);
                return false;
            }

            double D =
                -(normalModelo.X * originModelo.X +
                  normalModelo.Y * originModelo.Y +
                  normalModelo.Z * originModelo.Z);

            int verticesModificados = 0;

            foreach (SlabShapeVertex vertex
                in shapeEditor.SlabShapeVertices)
            {
                XYZ vPos = vertex.Position;

                if (Math.Abs(normalModelo.Z) <= 0.0001)
                    continue;

                double globalZ =
                    (-D -
                     normalModelo.X * vPos.X -
                     normalModelo.Y * vPos.Y) /
                    normalModelo.Z;

                // ModifySubElement recibe el offset respecto al plano base,
                // no un desplazamiento incremental desde vertex.Position.
                double elevationValue = TarrajeoAlturas.CalcularDesfase(
                    globalZ, nivel.ProjectElevation, normalModelo.Z, espesor, 0.0);

                shapeEditor.ModifySubElement(
                    vertex,
                    elevationValue);

                verticesModificados++;
            }

            if (verticesModificados == 0)
            {
                tForma.RollBack();
                detalle = "SlabShapeEditor no devolvió vértices modificables.";
                EliminarElementoCreadoSilenciosamente(doc, newFloorId);
                return false;
            }

            TransactionStatus estadoForma = tForma.Commit();

            if (estadoForma != TransactionStatus.Committed)
            {
                detalle = "La inclinación se revirtió silenciosamente.";

                if (!string.IsNullOrWhiteSpace(preForma.UltimoMensaje))
                    detalle += " " + preForma.UltimoMensaje;

                EliminarElementoCreadoSilenciosamente(doc, newFloorId);
                return false;
            }

            if (doc.GetElement(newFloorId) == null)
            {
                detalle = "Revit eliminó el suelo al resolver el conflicto de inclinación.";
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            try
            {
                if (tForma.GetStatus() == TransactionStatus.Started)
                    tForma.RollBack();
            }
            catch
            {
            }

            detalle =
                "Aplicar inclinación: " +
                ex.GetType().Name +
                " - " +
                ex.Message;

            if (!string.IsNullOrWhiteSpace(preForma.UltimoMensaje))
                detalle += " | " + preForma.UltimoMensaje;

            EliminarElementoCreadoSilenciosamente(doc, newFloorId);
            return false;
        }
    }

    private void ConfigurarTransaccionSilenciosa(
        Transaction transaccion,
        MYG_TarrajeoSueloSilenciosoV24 preprocesador)
    {
        if (transaccion == null || preprocesador == null)
            return;

        FailureHandlingOptions opciones =
            transaccion.GetFailureHandlingOptions();

        opciones = opciones
            .SetFailuresPreprocessor(preprocesador)
            .SetClearAfterRollback(true)
            .SetDelayedMiniWarnings(false);

        try
        {
            System.Reflection.MethodInfo metodoForzado =
                typeof(FailureHandlingOptions).GetMethod(
                    "SetForcedModalHandling",
                    new Type[] { typeof(bool) });

            if (metodoForzado != null)
            {
                object resultadoForzado = metodoForzado.Invoke(
                    opciones,
                    new object[] { false });

                if (resultadoForzado is FailureHandlingOptions)
                    opciones = (FailureHandlingOptions)resultadoForzado;
            }
        }
        catch
        {
        }

        transaccion.SetFailureHandlingOptions(opciones);
    }

    private void EliminarElementoCreadoSilenciosamente(
        Document doc,
        ElementId elementoId)
    {
        if (doc == null ||
            elementoId == null ||
            elementoId == ElementId.InvalidElementId ||
            doc.GetElement(elementoId) == null)
        {
            return;
        }

        Transaction t = new Transaction(
            doc,
            "MYG Limpiar suelo fallido");

        MYG_TarrajeoSueloSilenciosoV24 preprocesador =
            new MYG_TarrajeoSueloSilenciosoV24();

        try
        {
            t.Start();
            ConfigurarTransaccionSilenciosa(t, preprocesador);
            doc.Delete(elementoId);
            t.Commit();
        }
        catch
        {
            try
            {
                if (t.GetStatus() == TransactionStatus.Started)
                    t.RollBack();
            }
            catch
            {
            }
        }
    }

    private void RegistrarPerfilesOmitidos(int cantidad, string detalle)
    {
        if (cantidad <= 0)
            return;
        UltimaCantidadPerfilesOmitidos += cantidad;
        string aviso = string.IsNullOrWhiteSpace(detalle)
            ? "Se omitieron " + cantidad + " piezas no creables."
            : detalle;
        UltimoAvisoParcial += (string.IsNullOrWhiteSpace(UltimoAvisoParcial)
            ? string.Empty : "\n") + aviso;
    }

    private bool Fallar(
        string etapa,
        string detalle,
        Exception ex = null)
    {
        UltimoDiagnostico =
            "Etapa: " +
            (string.IsNullOrWhiteSpace(etapa)
                ? "desconocida"
                : etapa) +
            ". " +
            (string.IsNullOrWhiteSpace(detalle)
                ? string.Empty
                : detalle);

        if (ex != null)
        {
            UltimoDiagnostico +=
                "\nExcepción: " +
                ex.GetType().Name +
                " - " +
                ex.Message;
        }

        if (!string.IsNullOrWhiteSpace(UltimoAvisoParcial))
        {
            UltimoDiagnostico += "\n" + UltimoAvisoParcial;
            RegistrarDiagnosticoEnArchivo("Tarrajeo de suelos: piezas omitidas", UltimoDiagnostico);
        }
        return false;
    }

    // =========================================================
    // OBTENER CARA PLANAR NATIVA O DE VÍNCULO
    // =========================================================

    private PlanarFace ObtenerCaraPlanarDesdeReferencia(
        Document doc,
        Reference referencia,
        out Element hostElem,
        out Transform transformCara)
    {
        hostElem = null;
        transformCara = Transform.Identity;

        if (doc == null || referencia == null)
            return null;

        hostElem = doc.GetElement(referencia.ElementId);

        if (hostElem == null)
            return null;

        //-------------------------------------------------
        // Cara de vínculo
        //-------------------------------------------------
        RevitLinkInstance link = hostElem as RevitLinkInstance;

        if (link != null)
        {
            Document linkDoc = null;

            try
            {
                linkDoc = link.GetLinkDocument();
            }
            catch
            {
                linkDoc = null;
            }

            if (linkDoc == null)
                return null;

            ElementId linkedId = referencia.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return null;

            Element linkedElem = linkDoc.GetElement(linkedId);

            if (linkedElem == null)
                return null;

            ConfigurarOrigenesDeRecorte(
                ObtenerConjuntoEscaleraDesdeCualquierComponente(linkedElem),
                link);

            Transform trLink = Transform.Identity;

            try
            {
                trLink = link.GetTotalTransform();
            }
            catch
            {
                trLink = Transform.Identity;
            }

            transformCara = trLink;

            try
            {
                Reference refEnLink = referencia.CreateReferenceInLink();
                GeometryObject geoObj = linkedElem.GetGeometryObjectFromReference(refEnLink);

                PlanarFace pf = geoObj as PlanarFace;

                if (pf != null)
                    return pf;
            }
            catch
            {
            }

            return null;
        }

        //-------------------------------------------------
        // Cara nativa
        //-------------------------------------------------
        try
        {
            GeometryObject geoObj = hostElem.GetGeometryObjectFromReference(referencia);
            PlanarFace pf = geoObj as PlanarFace;

            if (pf != null)
            {
                ConfigurarOrigenesDeRecorte(
                    ObtenerConjuntoEscaleraDesdeCualquierComponente(hostElem),
                    null);
                transformCara = Transform.Identity;
                return pf;
            }
        }
        catch
        {
        }

        return null;
    }

    // =========================================================
    // GEOMETRÍA DEL SUELO
    // =========================================================

    // =========================================================
    // V27 - EXTRUSIÓN TEMPORAL ROBUSTA
    // =========================================================
    // Algunas caras inferiores de descansos/tramos son válidas como Face,
    // pero Revit devuelve sus CurveLoops con pequeñas desviaciones del plano,
    // segmentos casi nulos o curvas que el método de extrusión no consigue
    // proyectar internamente (extrudeProjCurveLoops failed).
    //
    // Secuencia:
    // 1) perfil transformado original;
    // 2) perfil lineal limpio y proyectado exactamente al plano de la cara;
    // 3) triangulación de la propia PlanarFace y unión de prismas triangulares.
    // =========================================================

    // Proyectar cada cara de la intersección por separado conserva su topología:
    // un hueco de una cara no puede perforar por error otra huella superpuesta.
    // Los prismas atraviesan TODO el espesor para que una interferencia exterior
    // también se refleje en el perfil que luego utiliza Floor.Create.
    private List<Solid> CrearPrismasDeHuellaDeInterseccion(
        Solid interseccion,
        XYZ origenCara,
        XYZ normal,
        double espesor,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;
        List<Solid> prismas = new List<Solid>();

        try
        {
            XYZ n = normal.Normalize();
            double sobrepaso = TarrajeoAlturas.ToleranciaContactoPies;
            Plane planoInicio = Plane.CreateByNormalAndOrigin(
                n, origenCara - n.Multiply(sobrepaso));
            double profundidad = espesor + sobrepaso * 2.0;

            foreach (Face cara in interseccion.Faces)
            {
                PlanarFace plana = cara as PlanarFace;
                if (plana != null)
                {
                    double dot = Math.Abs(plana.FaceNormal.Normalize().DotProduct(n));
                    if (dot <= 1e-9)
                        continue; // Proyección sin área, no es un cortante volumétrico.

                    IList<CurveLoop> originales = plana.GetEdgesAsCurveLoops();
                    if (originales == null || originales.Count == 0)
                        throw new InvalidOperationException("Una cara cortante no tiene contornos.");

                    List<CurveLoop> proyectados = new List<CurveLoop>();
                    foreach (CurveLoop loop in originales)
                    {
                        CurveLoop proyectado;
                        if (Math.Abs(dot - 1.0) <= 1e-9)
                        {
                            // Cara paralela: conservar líneas, arcos y huecos exactos.
                            double distancia = (plana.Origin - planoInicio.Origin).DotProduct(n);
                            Transform mover = Transform.CreateTranslation(n.Multiply(-distancia));
                            proyectado = new CurveLoop();
                            foreach (Curve curva in loop)
                                proyectado.Append(curva.CreateTransformed(mover));
                        }
                        else
                        {
                            proyectado = ProyectarContornoDeCortante(
                                loop, planoInicio, toleranciaCurvaCorta);
                        }

                        if (proyectado == null || proyectado.IsOpen())
                            throw new InvalidOperationException("No se conservó un contorno de la cara cortante.");
                        proyectados.Add(proyectado);
                    }

                    Solid prisma = GeometryCreationUtilities.CreateExtrusionGeometry(
                        proyectados, n, profundidad);
                    if (prisma == null || prisma.Volume <= 0.0)
                        throw new InvalidOperationException("La huella proyectada no produjo volumen.");
                    prismas.Add(prisma);
                    continue;
                }

                // Superficie curva: usar solamente sus triángulos reales,
                // proyectados individualmente; nunca una caja o envolvente convexa.
                Mesh malla = cara.Triangulate();
                if (malla == null || malla.NumTriangles == 0)
                    throw new InvalidOperationException("No se pudo triangular una cara cortante curva.");

                for (int i = 0; i < malla.NumTriangles; i++)
                {
                    MeshTriangle tri = malla.get_Triangle(i);
                    XYZ a = ProjectPointToPlane(tri.get_Vertex(0), planoInicio);
                    XYZ b = ProjectPointToPlane(tri.get_Vertex(1), planoInicio);
                    XYZ c = ProjectPointToPlane(tri.get_Vertex(2), planoInicio);
                    double area = Math.Abs((b - a).CrossProduct(c - a).DotProduct(n)) * 0.5;
                    if (area <= 1e-12)
                        continue;

                    if (a.DistanceTo(b) <= toleranciaCurvaCorta ||
                        b.DistanceTo(c) <= toleranciaCurvaCorta ||
                        c.DistanceTo(a) <= toleranciaCurvaCorta)
                    {
                        throw new InvalidOperationException(
                            "Una huella curva contiene segmentos menores que la tolerancia de Revit.");
                    }

                    CurveLoop loopTri = new CurveLoop();
                    loopTri.Append(Line.CreateBound(a, b));
                    loopTri.Append(Line.CreateBound(b, c));
                    loopTri.Append(Line.CreateBound(c, a));
                    Solid prisma = GeometryCreationUtilities.CreateExtrusionGeometry(
                        new List<CurveLoop>() { loopTri }, n, profundidad);
                    if (prisma == null || prisma.Volume <= 0.0)
                        throw new InvalidOperationException("Una huella curva no produjo volumen.");
                    prismas.Add(prisma);
                }
            }

            if (prismas.Count == 0)
                throw new InvalidOperationException("La intersección no tiene ninguna huella proyectable.");
            return prismas;
        }
        catch (Exception ex)
        {
            detalle = ex.GetType().Name + " - " + ex.Message;
            return null;
        }
    }

    private CurveLoop ProyectarContornoDeCortante(
        CurveLoop contorno,
        Plane plano,
        double toleranciaCurvaCorta)
    {
        List<XYZ> puntos = new List<XYZ>();
        foreach (Curve curva in contorno)
        {
            IList<XYZ> muestras = curva is Line
                ? new List<XYZ>() { curva.GetEndPoint(0), curva.GetEndPoint(1) }
                : curva.Tessellate();
            foreach (XYZ muestra in muestras)
            {
                XYZ p = ProjectPointToPlane(muestra, plano);
                if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(p) > 1e-9)
                    puntos.Add(p);
            }
        }
        if (puntos.Count > 1 && puntos[0].DistanceTo(puntos[puntos.Count - 1]) <= 1e-9)
            puntos.RemoveAt(puntos.Count - 1);

        // Solo quitar divisiones exactamente colineales: no cambiar siluetas ni huecos.
        bool cambio = true;
        while (cambio && puntos.Count > 3)
        {
            cambio = false;
            for (int i = 0; i < puntos.Count; i++)
            {
                XYZ anterior = puntos[(i + puntos.Count - 1) % puntos.Count];
                XYZ actual = puntos[i];
                XYZ siguiente = puntos[(i + 1) % puntos.Count];
                XYZ entrada = actual - anterior;
                XYZ salida = siguiente - actual;
                if (entrada.CrossProduct(salida).GetLength() <=
                    1e-9 * entrada.GetLength() * salida.GetLength() &&
                    entrada.DotProduct(salida) >= 0.0)
                {
                    puntos.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        if (puntos.Count < 3)
            throw new InvalidOperationException("Un contorno proyectado tiene menos de tres vértices.");
        CurveLoop resultado = new CurveLoop();
        for (int i = 0; i < puntos.Count; i++)
        {
            XYZ a = puntos[i];
            XYZ b = puntos[(i + 1) % puntos.Count];
            if (a.DistanceTo(b) <= toleranciaCurvaCorta)
                throw new InvalidOperationException("Un contorno proyectado tiene segmentos demasiado cortos.");
            resultado.Append(Line.CreateBound(a, b));
        }
        return resultado;
    }

    private Solid CrearSolidoTemporalRobusto(
        PlanarFace cara,
        IList<CurveLoop> loopsOriginales,
        List<CurveLoop> loopsModelo,
        Transform transformCara,
        XYZ normalModelo,
        XYZ originModelo,
        double profundidad,
        double toleranciaCurvaCorta,
        out List<CurveLoop> loopsUsados,
        out string detalle)
    {
        loopsUsados = null;
        detalle = string.Empty;
        List<string> errores = new List<string>();

        if (normalModelo == null || normalModelo.GetLength() <= TOL)
        {
            detalle = "La normal para la extrusión es nula.";
            return null;
        }

        normalModelo = normalModelo.Normalize();

        //-------------------------------------------------
        // INTENTO 1: loops transformados originales.
        //-------------------------------------------------
        if (loopsModelo != null && loopsModelo.Count > 0)
        {
            try
            {
                Solid directo = GeometryCreationUtilities.CreateExtrusionGeometry(
                    loopsModelo,
                    normalModelo,
                    profundidad);

                if (directo != null && directo.Volume > TOL)
                {
                    loopsUsados = loopsModelo;
                    detalle = "Extrusión directa correcta.";
                    return directo;
                }

                errores.Add("La extrusión directa devolvió un sólido sin volumen.");
            }
            catch (Exception ex)
            {
                errores.Add(
                    "Extrusión directa: " +
                    ex.GetType().Name + " - " + ex.Message);
            }
        }

        //-------------------------------------------------
        // INTENTO 2: reconstruir los loops como polígonos lineales,
        // proyectados exactamente al plano físico de la cara.
        //-------------------------------------------------
        string detalleLimpieza;
        List<CurveLoop> loopsLimpios = ConstruirLoopsParaExtrusionRobusta(
            loopsOriginales,
            transformCara,
            normalModelo,
            originModelo,
            toleranciaCurvaCorta,
            out detalleLimpieza);

        if (loopsLimpios != null && loopsLimpios.Count > 0)
        {
            try
            {
                Solid limpio = GeometryCreationUtilities.CreateExtrusionGeometry(
                    loopsLimpios,
                    normalModelo,
                    profundidad);

                if (limpio != null && limpio.Volume > TOL)
                {
                    loopsUsados = loopsLimpios;
                    detalle =
                        "Se utilizó el perfil lineal limpio proyectado al plano de la cara.";
                    return limpio;
                }

                errores.Add("El perfil lineal limpio produjo un sólido sin volumen.");
            }
            catch (Exception ex)
            {
                errores.Add(
                    "Perfil lineal limpio: " +
                    ex.GetType().Name + " - " + ex.Message);
            }
        }
        else if (!string.IsNullOrWhiteSpace(detalleLimpieza))
        {
            errores.Add("Limpieza del perfil: " + detalleLimpieza);
        }

        //-------------------------------------------------
        // INTENTO 3: usar la triangulación real de la cara.
        // No inventa una caja ni proyecta la geometría completa del elemento;
        // solamente extruye los triángulos que pertenecen a la PlanarFace.
        //-------------------------------------------------
        string detalleTriangulacion;
        Solid triangulado = CrearSolidoTemporalPorTriangulacion(
            cara,
            transformCara,
            normalModelo,
            originModelo,
            profundidad,
            toleranciaCurvaCorta,
            out detalleTriangulacion);

        if (triangulado != null && triangulado.Volume > TOL)
        {
            // Para el Outline se conserva el mejor perfil lineal disponible.
            // Si no existe, se usan los loops transformados originales.
            loopsUsados =
                loopsLimpios != null && loopsLimpios.Count > 0
                    ? loopsLimpios
                    : loopsModelo;

            detalle = "Se utilizó la triangulación de la cara como respaldo.";
            return triangulado;
        }

        if (!string.IsNullOrWhiteSpace(detalleTriangulacion))
            errores.Add("Triangulación: " + detalleTriangulacion);

        detalle = errores.Count > 0
            ? string.Join(" | ", errores.Take(6))
            : "No se obtuvo un sólido temporal válido.";

        return null;
    }

    private List<CurveLoop> ConstruirLoopsParaExtrusionRobusta(
        IList<CurveLoop> source,
        Transform transformCara,
        XYZ normalModelo,
        XYZ originModelo,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;
        List<CurveLoop> resultado = new List<CurveLoop>();
        List<string> errores = new List<string>();

        if (source == null || source.Count == 0)
        {
            detalle = "No se recibieron CurveLoops.";
            return resultado;
        }

        if (transformCara == null)
            transformCara = Transform.Identity;

        double tol = Math.Max(toleranciaCurvaCorta * 1.10, 1e-6);
        Plane plano = Plane.CreateByNormalAndOrigin(
            normalModelo.Normalize(),
            originModelo);

        foreach (CurveLoop loop in source)
        {
            if (loop == null)
                continue;

            List<XYZ> puntos = new List<XYZ>();

            foreach (Curve curva in loop)
            {
                if (curva == null)
                    continue;

                IList<XYZ> muestras = null;

                try
                {
                    if (curva is Line)
                    {
                        muestras = new List<XYZ>()
                        {
                            curva.GetEndPoint(0),
                            curva.GetEndPoint(1)
                        };
                    }
                    else
                    {
                        muestras = curva.Tessellate();
                    }
                }
                catch
                {
                    try
                    {
                        muestras = new List<XYZ>()
                        {
                            curva.GetEndPoint(0),
                            curva.GetEndPoint(1)
                        };
                    }
                    catch
                    {
                        muestras = null;
                    }
                }

                if (muestras == null)
                    continue;

                foreach (XYZ pLocal in muestras)
                {
                    if (pLocal == null)
                        continue;

                    XYZ pModelo = transformCara.OfPoint(pLocal);
                    XYZ pPlano = ProjectPointToPlane(pModelo, plano);

                    AgregarPuntoConsecutivoUnico(
                        puntos,
                        pPlano,
                        tol * 0.45);
                }
            }

            puntos = LimpiarPuntosParaCurvasRevit(
                puntos,
                tol);

            puntos = EliminarPicosYRetornosCortos(
                puntos,
                tol);

            if (puntos == null || puntos.Count < 3)
            {
                errores.Add("Un loop quedó con menos de tres puntos.");
                continue;
            }

            double area = AreaPoligono3D(puntos, normalModelo);

            if (area <= MIN_AREA_CARA)
            {
                errores.Add(
                    "Un loop limpio fue descartado por área mínima: " +
                    area.ToString("0.000000") + " ft².");
                continue;
            }

            CurveLoop nuevo = new CurveLoop();
            bool valido = true;

            try
            {
                for (int i = 0; i < puntos.Count; i++)
                {
                    XYZ a = puntos[i];
                    XYZ b = puntos[(i + 1) % puntos.Count];

                    if (a.DistanceTo(b) < tol)
                    {
                        valido = false;
                        break;
                    }

                    nuevo.Append(Line.CreateBound(a, b));
                }
            }
            catch (Exception ex)
            {
                valido = false;
                errores.Add(
                    "No se pudo reconstruir un loop limpio: " +
                    ex.GetType().Name + " - " + ex.Message);
            }

            if (!valido || nuevo.IsOpen())
            {
                errores.Add("Un loop reconstruido quedó abierto o inválido.");
                continue;
            }

            resultado.Add(nuevo);
        }

        resultado = resultado
            .OrderByDescending(lp => Math.Abs(AreaLoopEnPlano(lp, normalModelo)))
            .ToList();

        if (resultado.Count == 0)
        {
            detalle = errores.Count > 0
                ? string.Join(" | ", errores.Take(5))
                : "No quedó ningún loop limpio válido.";
        }

        return resultado;
    }

    private List<XYZ> EliminarPicosYRetornosCortos(
        List<XYZ> origen,
        double tolerancia)
    {
        List<XYZ> puntos = origen != null
            ? new List<XYZ>(origen)
            : new List<XYZ>();

        double tol = Math.Max(tolerancia, 1e-6);
        bool cambio = true;
        int guardia = 0;

        while (cambio && puntos.Count >= 3 && guardia < 5000)
        {
            cambio = false;
            guardia++;

            for (int i = 0; i < puntos.Count; i++)
            {
                int iAnt = (i - 1 + puntos.Count) % puntos.Count;
                int iSig = (i + 1) % puntos.Count;

                XYZ ant = puntos[iAnt];
                XYZ act = puntos[i];
                XYZ sig = puntos[iSig];

                double dAntSig = ant.DistanceTo(sig);
                double dAntAct = ant.DistanceTo(act);
                double dActSig = act.DistanceTo(sig);

                // Pico muy fino: se vuelve prácticamente al mismo punto.
                if (dAntSig < tol &&
                    (dAntAct < tol * 4.0 || dActSig < tol * 4.0))
                {
                    puntos.RemoveAt(i);
                    cambio = true;
                    break;
                }

                XYZ v1 = act - ant;
                XYZ v2 = sig - act;

                if (v1.GetLength() <= 1e-12 || v2.GetLength() <= 1e-12)
                {
                    puntos.RemoveAt(i);
                    cambio = true;
                    break;
                }

                double cos = v1.Normalize().DotProduct(v2.Normalize());

                // Retorno casi de 180 grados acompañado por un tramo corto.
                if (cos < -0.9995 &&
                    Math.Min(dAntAct, dActSig) < tol * 4.0)
                {
                    puntos.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        return LimpiarPuntosParaCurvasRevit(puntos, tol);
    }

    private double AreaPoligono3D(
        IList<XYZ> puntos,
        XYZ normal)
    {
        if (puntos == null || puntos.Count < 3 || normal == null)
            return 0.0;

        XYZ suma = XYZ.Zero;

        for (int i = 0; i < puntos.Count; i++)
        {
            XYZ a = puntos[i];
            XYZ b = puntos[(i + 1) % puntos.Count];
            suma = suma + a.CrossProduct(b);
        }

        return Math.Abs(suma.DotProduct(normal.Normalize())) * 0.5;
    }

    private double AreaLoopEnPlano(
        CurveLoop loop,
        XYZ normal)
    {
        if (loop == null)
            return 0.0;

        List<XYZ> puntos = new List<XYZ>();

        foreach (Curve c in loop)
        {
            if (c != null)
                AgregarPuntoConsecutivoUnico(
                    puntos,
                    c.GetEndPoint(0),
                    1e-9);
        }

        return AreaPoligono3D(puntos, normal);
    }

    private Solid CrearSolidoTemporalPorTriangulacion(
        PlanarFace cara,
        Transform transformCara,
        XYZ normalModelo,
        XYZ originModelo,
        double profundidad,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;

        if (cara == null)
        {
            detalle = "La PlanarFace es nula.";
            return null;
        }

        if (transformCara == null)
            transformCara = Transform.Identity;

        Mesh mesh = null;

        try
        {
            mesh = cara.Triangulate();
        }
        catch (Exception ex)
        {
            detalle =
                "No se pudo triangular la cara: " +
                ex.GetType().Name + " - " + ex.Message;
            return null;
        }

        if (mesh == null || mesh.NumTriangles <= 0)
        {
            detalle = "La triangulación no devolvió triángulos.";
            return null;
        }

        double tol = Math.Max(toleranciaCurvaCorta * 1.05, 1e-6);
        Plane plano = Plane.CreateByNormalAndOrigin(
            normalModelo.Normalize(),
            originModelo);

        Solid acumulado = null;
        int creados = 0;
        int omitidos = 0;
        int unionesFallidas = 0;

        for (int i = 0; i < mesh.NumTriangles; i++)
        {
            MeshTriangle tri = mesh.get_Triangle(i);

            if (tri == null)
                continue;

            XYZ p0 = ProjectPointToPlane(
                transformCara.OfPoint(tri.get_Vertex(0)),
                plano);
            XYZ p1 = ProjectPointToPlane(
                transformCara.OfPoint(tri.get_Vertex(1)),
                plano);
            XYZ p2 = ProjectPointToPlane(
                transformCara.OfPoint(tri.get_Vertex(2)),
                plano);

            if (p0.DistanceTo(p1) < tol ||
                p1.DistanceTo(p2) < tol ||
                p2.DistanceTo(p0) < tol)
            {
                omitidos++;
                continue;
            }

            double areaTri =
                (p1 - p0).CrossProduct(p2 - p0).GetLength() * 0.5;

            if (areaTri <= MIN_AREA_CARA)
            {
                omitidos++;
                continue;
            }

            CurveLoop loopTri = new CurveLoop();

            try
            {
                loopTri.Append(Line.CreateBound(p0, p1));
                loopTri.Append(Line.CreateBound(p1, p2));
                loopTri.Append(Line.CreateBound(p2, p0));

                Solid prisma = GeometryCreationUtilities.CreateExtrusionGeometry(
                    new List<CurveLoop>() { loopTri },
                    normalModelo,
                    profundidad);

                if (prisma == null || prisma.Volume <= TOL)
                {
                    omitidos++;
                    continue;
                }

                if (acumulado == null)
                {
                    acumulado = prisma;
                }
                else
                {
                    try
                    {
                        Solid unido = BooleanOperationsUtils.ExecuteBooleanOperation(
                            acumulado,
                            prisma,
                            BooleanOperationsType.Union);

                        if (unido != null && unido.Volume > TOL)
                            acumulado = unido;
                        else
                            unionesFallidas++;
                    }
                    catch
                    {
                        unionesFallidas++;
                    }
                }

                creados++;
            }
            catch
            {
                omitidos++;
            }
        }

        if (acumulado == null || acumulado.Volume <= TOL)
        {
            detalle =
                "No se pudo formar un sólido desde la triangulación. " +
                "Triángulos creados: " + creados +
                ", omitidos: " + omitidos +
                ", uniones fallidas: " + unionesFallidas + ".";
            return null;
        }

        detalle =
            "Triángulos creados: " + creados +
            ", omitidos: " + omitidos +
            ", uniones fallidas: " + unionesFallidas + ".";

        return acumulado;
    }

    private List<CurveLoop> TransformCurveLoops(IList<CurveLoop> source, Transform tr)
    {
        if (source == null || source.Count == 0)
            throw new InvalidOperationException("La cara no tiene contornos.");
        var result = new List<CurveLoop>();
        foreach (CurveLoop loop in source)
        {
            if (loop == null)
                throw new InvalidOperationException("La cara contiene un contorno nulo.");
            var nuevo = new CurveLoop();
            foreach (Curve curva in loop)
            {
                if (curva == null)
                    throw new InvalidOperationException("La cara contiene una curva nula.");
                nuevo.Append(curva.CreateTransformed(tr ?? Transform.Identity));
            }
            if (nuevo.IsOpen())
                throw new InvalidOperationException("La transformación dejó un contorno abierto; no se omitió el hueco.");
            result.Add(nuevo);
        }
        return result;
    }

    private CurveLoop ProyectarLoopANivel(
        CurveLoop loop,
        Plane hostPlane,
        double zSketch,
        double toleranciaCurvaCorta,
        out string detalle)
    {
        detalle = string.Empty;

        if (loop == null || hostPlane == null)
        {
            detalle = "Loop o plano anfitrión nulo.";
            return null;
        }

        double tol = Math.Max(
            toleranciaCurvaCorta * 1.05,
            1e-6);

        List<XYZ> puntos = new List<XYZ>();

        foreach (Curve curve in loop)
        {
            if (curve == null)
                continue;

            IList<XYZ> pts = null;

            try
            {
                // Para líneas se usan solo los extremos. Tessellate puede
                // producir puntos intermedios casi coincidentes.
                if (curve is Line)
                {
                    pts = new List<XYZ>()
                    {
                        curve.GetEndPoint(0),
                        curve.GetEndPoint(1)
                    };
                }
                else
                {
                    pts = curve.Tessellate();
                }
            }
            catch
            {
                try
                {
                    pts = new List<XYZ>()
                    {
                        curve.GetEndPoint(0),
                        curve.GetEndPoint(1)
                    };
                }
                catch
                {
                    pts = null;
                }
            }

            if (pts == null || pts.Count == 0)
                continue;

            foreach (XYZ p in pts)
            {
                XYZ pOnHostPlane = ProjectPointToPlane(p, hostPlane);

                XYZ pFinal = new XYZ(
                    pOnHostPlane.X,
                    pOnHostPlane.Y,
                    zSketch);

                AgregarPuntoConsecutivoUnico(
                    puntos,
                    pFinal,
                    tol * 0.50);
            }
        }

        puntos = LimpiarPuntosParaCurvasRevit(
            puntos,
            tol);

        if (puntos == null || puntos.Count < 3)
        {
            detalle =
                "El contorno quedó con menos de tres vértices después de eliminar " +
                "segmentos menores que ShortCurveTolerance.";
            return null;
        }

        CurveLoop flatLoop = new CurveLoop();

        try
        {
            for (int i = 0; i < puntos.Count; i++)
            {
                XYZ a = puntos[i];
                XYZ b = puntos[(i + 1) % puntos.Count];
                double longitud = a.DistanceTo(b);

                if (longitud < tol)
                {
                    detalle =
                        "Persistió un segmento corto de " +
                        longitud.ToString("0.000000") +
                        " ft; tolerancia requerida: " +
                        tol.ToString("0.000000") + " ft.";
                    return null;
                }

                flatLoop.Append(Line.CreateBound(a, b));
            }
        }
        catch (Exception ex)
        {
            detalle =
                "No se pudo construir el CurveLoop limpio: " +
                ex.GetType().Name + " - " + ex.Message;
            return null;
        }

        if (flatLoop.IsOpen())
        {
            detalle = "El CurveLoop proyectado quedó abierto.";
            return null;
        }

        return flatLoop;
    }

    private void AgregarPuntoConsecutivoUnico(
        List<XYZ> puntos,
        XYZ p,
        double tolerancia)
    {
        if (puntos == null || p == null)
            return;

        double tol = Math.Max(tolerancia, 1e-9);

        if (puntos.Count == 0)
        {
            puntos.Add(p);
            return;
        }

        if (puntos[puntos.Count - 1].DistanceTo(p) >= tol)
            puntos.Add(p);
    }

    private double ObtenerToleranciaCurvaCorta(Document doc)
    {
        try
        {
            if (doc != null &&
                doc.Application != null &&
                doc.Application.ShortCurveTolerance > 0)
            {
                return doc.Application.ShortCurveTolerance;
            }
        }
        catch
        {
        }

        // Respaldo aproximado de 0.8 mm en pies.
        return 0.00262467192;
    }

    private List<XYZ> LimpiarPuntosParaCurvasRevit(
        List<XYZ> origen,
        double tolerancia)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (origen == null)
            return puntos;

        double tol = Math.Max(tolerancia, 1e-6);

        foreach (XYZ p in origen)
            AgregarPuntoConsecutivoUnico(puntos, p, tol * 0.50);

        if (puntos.Count > 1 &&
            puntos[0].DistanceTo(puntos[puntos.Count - 1]) < tol)
        {
            puntos.RemoveAt(puntos.Count - 1);
        }

        bool cambio = true;
        int guardia = 0;

        while (cambio && puntos.Count >= 3 && guardia < 5000)
        {
            cambio = false;
            guardia++;

            for (int i = 0; i < puntos.Count; i++)
            {
                int j = (i + 1) % puntos.Count;

                if (puntos[i].DistanceTo(puntos[j]) < tol)
                {
                    // Se elimina el segundo vértice del tramo corto.
                    puntos.RemoveAt(j);
                    cambio = true;
                    break;
                }
            }
        }

        cambio = true;
        guardia = 0;

        while (cambio && puntos.Count >= 3 && guardia < 5000)
        {
            cambio = false;
            guardia++;

            for (int i = 0; i < puntos.Count; i++)
            {
                XYZ anterior = puntos[(i - 1 + puntos.Count) % puntos.Count];
                XYZ actual = puntos[i];
                XYZ siguiente = puntos[(i + 1) % puntos.Count];

                if (EsPuntoColinealPrescindible(
                    anterior,
                    actual,
                    siguiente,
                    tol * 0.20))
                {
                    puntos.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        // Última pasada por si eliminar colineales generó un tramo corto.
        cambio = true;
        guardia = 0;

        while (cambio && puntos.Count >= 3 && guardia < 5000)
        {
            cambio = false;
            guardia++;

            for (int i = 0; i < puntos.Count; i++)
            {
                int j = (i + 1) % puntos.Count;

                if (puntos[i].DistanceTo(puntos[j]) < tol)
                {
                    puntos.RemoveAt(j);
                    cambio = true;
                    break;
                }
            }
        }

        return puntos;
    }

    private bool EsPuntoColinealPrescindible(
        XYZ a,
        XYZ b,
        XYZ c,
        double tolerancia)
    {
        if (a == null || b == null || c == null)
            return false;

        XYZ ab = b - a;
        XYZ bc = c - b;
        XYZ ac = c - a;

        double lab = ab.GetLength();
        double lbc = bc.GetLength();
        double lac = ac.GetLength();

        if (lab <= 1e-12 || lbc <= 1e-12 || lac <= 1e-12)
            return true;

        double distanciaLinea =
            ab.CrossProduct(ac).GetLength() / lac;

        // Solo se elimina cuando B está entre A y C y prácticamente alineado.
        double avance = ab.DotProduct(ac);

        return distanciaLinea <= tolerancia &&
               avance >= 0 &&
               avance <= lac * lac;
    }

    private void RegistrarDiagnosticoEnArchivo(
        string contexto,
        string detalle)
    {
        try
        {
            string ruta = Path.Combine(
                Path.GetTempPath(),
                "MYG_Tarrajeo_Losas_Diagnostico.log");

            string texto =
                "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " +
                (string.IsNullOrWhiteSpace(contexto) ? "Tarrajeo" : contexto) +
                Environment.NewLine +
                ObtenerIdentidadMotorRecorte() +
                Environment.NewLine +
                (string.IsNullOrWhiteSpace(detalle) ? "Sin detalle." : detalle) +
                Environment.NewLine +
                new string('-', 80) +
                Environment.NewLine;

            File.AppendAllText(ruta, texto);
            RutaUltimoDiagnostico = ruta;
        }
        catch
        {
            RutaUltimoDiagnostico = string.Empty;
        }
    }

    private string ObtenerIdentidadMotorRecorte()
    {
        string identidad = VERSION_RECORTE + Environment.NewLine +
            "Motor planar: TarrajeoRecorteExterior" + Environment.NewLine +
            "Archivo: MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs";
        try
        {
            System.Reflection.Assembly ensamblado = typeof(TarrajeoRecorteExterior).Assembly;
            try
            {
                identidad += Environment.NewLine + "Ensamblado cargado: " + ensamblado.Location;
            }
            catch (Exception ex)
            {
                identidad += Environment.NewLine + "Ensamblado cargado: ubicación no disponible (" +
                    ex.GetType().Name + ").";
            }
            try
            {
                identidad += Environment.NewLine + "MVID: " +
                    ensamblado.ManifestModule.ModuleVersionId.ToString();
            }
            catch (Exception ex)
            {
                identidad += Environment.NewLine + "MVID no disponible (" + ex.GetType().Name + ").";
            }
        }
        catch (Exception ex)
        {
            identidad += Environment.NewLine + "Identidad de ensamblado no disponible (" +
                ex.GetType().Name + ").";
        }
        return identidad;
    }

    private XYZ ProjectPointToPlane(XYZ p, Plane plane)
    {
        XYZ v = p - plane.Origin;
        double d = v.DotProduct(plane.Normal);
        return p - plane.Normal.Multiply(d);
    }

    private double AreaLoopXY(CurveLoop loop)
    {
        if (loop == null)
            return 0.0;

        List<XYZ> pts = new List<XYZ>();

        foreach (Curve c in loop)
        {
            if (c == null)
                continue;

            AgregarPuntoConsecutivoUnico(pts, c.GetEndPoint(0), 1e-9);
        }

        if (pts.Count < 3)
            return 0.0;

        double area = 0.0;

        for (int i = 0; i < pts.Count; i++)
        {
            XYZ a = pts[i];
            XYZ b = pts[(i + 1) % pts.Count];

            area += (a.X * b.Y) - (b.X * a.Y);
        }

        return area / 2.0;
    }

    private bool AreParallel(XYZ a, XYZ b)
    {
        if (a == null || b == null)
            return false;

        try
        {
            XYZ na = a.Normalize();
            XYZ nb = b.Normalize();

            return na.CrossProduct(nb).GetLength() <= 0.001;
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // DESCUENTOS POR NATIVOS + VÍNCULOS VISIBLES
    // =========================================================

    // =========================================================
    // V28 - DESCUENTOS ESTRICTAMENTE SEGÚN VISTA ACTIVA
    // =========================================================
    // Solo se descuentan elementos que realmente estén visibles en la vista:
    // - Hide in View por elemento,
    // - categoría apagada,
    // - filtros con visibilidad desactivada,
    // - Hide/Isolate temporal,
    // - y, en vínculos, la vista vinculada cuando esté configurada.
    // =========================================================
    private List<Solid> GetVisibleNativeAndLinkedSolids(
        Document doc,
        View activeView,
        Outline outlineModel,
        ElementId hostId)
    {
        List<Solid> solids = new List<Solid>();
        _origenesSolidosCandidatos.Clear();

        if (doc == null || outlineModel == null)
            return solids;

        //-------------------------------------------------
        // 1. ELEMENTOS NATIVOS REALMENTE VISIBLES
        //-------------------------------------------------
        try
        {
            FilteredElementCollector collector =
                activeView != null && !activeView.IsTemplate
                    ? new FilteredElementCollector(doc, activeView.Id)
                    : new FilteredElementCollector(doc);

            collector = collector
                .WherePasses(new BoundingBoxIntersectsFilter(outlineModel))
                .WhereElementIsNotElementType();

            foreach (Element e in collector)
            {
                if (e == null)
                    continue;

                if (hostId != null &&
                    hostId != ElementId.InvalidElementId &&
                    e.Id == hostId)
                {
                    continue;
                }

                if (EsElementoOrigenNativo(e))
                    continue;

                if (e is RevitLinkInstance)
                    continue;

                if (!IsValidIntersectingElement(e))
                    continue;

                if (!EsElementoVisibleEnVista(e, activeView))
                    continue;

                // V29: en vista 3D, CustomExporter es la autoridad final.
                if (!EsVisibleHostSegunExportador(e.Id, activeView))
                    continue;

                List<Solid> elemSolids = GetElementSolids(
                    e,
                    Transform.Identity,
                    activeView);

                foreach (Solid s in elemSolids)
                {
                    AgregarSolidoCandidato(solids, s, e, null);
                }
            }
        }
        catch
        {
        }

        //-------------------------------------------------
        // 2. VÍNCULOS VISIBLES EN LA VISTA ACTIVA
        //-------------------------------------------------
        if (!ConsiderarVinculos)
            return solids;

        try
        {
            FilteredElementCollector linkCollector =
                activeView != null && !activeView.IsTemplate
                    ? new FilteredElementCollector(doc, activeView.Id)
                    : new FilteredElementCollector(doc);

            IList<Element> links = linkCollector
                .OfClass(typeof(RevitLinkInstance))
                .WhereElementIsNotElementType()
                .ToElements();

            foreach (Element le in links)
            {
                RevitLinkInstance link = le as RevitLinkInstance;

                if (link == null)
                    continue;

                if (!EsElementoVisibleEnVista(link, activeView))
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                Transform trLink = Transform.Identity;

                try
                {
                    trLink = link.GetTotalTransform();
                }
                catch
                {
                    trLink = Transform.Identity;
                }

                Transform inv = Transform.Identity;

                try
                {
                    inv = trLink.Inverse;
                }
                catch
                {
                    inv = Transform.Identity;
                }

                Outline outlineLink = TransformOutline(outlineModel, inv);

                if (outlineLink == null)
                    continue;

                View linkedView = ObtenerVistaVinculadaUsadaEnHost(
                    activeView,
                    link,
                    linkDoc);

                FilteredElementCollector linkedCollector =
                    linkedView != null && !linkedView.IsTemplate
                        ? new FilteredElementCollector(linkDoc, linkedView.Id)
                        : new FilteredElementCollector(linkDoc);

                linkedCollector = linkedCollector
                    .WherePasses(new BoundingBoxIntersectsFilter(outlineLink))
                    .WhereElementIsNotElementType();

                foreach (Element linkedElem in linkedCollector)
                {
                    if (linkedElem == null)
                        continue;

                    if (EsElementoOrigenVinculado(link, linkedElem))
                        continue;

                    if (!IsValidIntersectingElement(linkedElem))
                        continue;

                    if (linkedView != null)
                    {
                        if (!EsElementoVisibleEnVista(linkedElem, linkedView))
                            continue;
                    }
                    else
                    {
                        if (!CategoriaVinculadaVisibleEnVistaHost(activeView, linkedElem))
                            continue;
                    }

                    // V29: si ESA instancia del vínculo y ese elemento no
                    // fueron recorridos por Revit en la vista activa, no cortan.
                    if (!EsVisibleVinculoSegunExportador(
                            linkDoc,
                            trLink,
                            linkedElem.Id,
                            activeView))
                    {
                        continue;
                    }

                    List<Solid> elemSolids = GetElementSolids(
                        linkedElem,
                        trLink,
                        linkedView);

                    foreach (Solid s in elemSolids)
                    {
                        AgregarSolidoCandidato(solids, s, linkedElem, link);
                    }
                }
            }
        }
        catch
        {
        }

        return solids;
    }

    private void AgregarSolidoCandidato(
        List<Solid> destino, Solid solido, Element elemento, RevitLinkInstance vinculo)
    {
        if (destino == null || solido == null || !(solido.Volume > 0))
            return;

        // Registrar metadatos nunca debe eliminar una interferencia válida.
        destino.Add(solido);
        _origenesSolidosCandidatos[solido] = DescribirOrigenCandidato(elemento, vinculo);
    }

    private string DescribirOrigenCandidato(Element elemento, RevitLinkInstance vinculo)
    {
        string id = "no disponible";
        string categoria = "no disponible";
        try
        {
            if (elemento != null && elemento.Id != null)
                id = elemento.Id.ToString();
        }
        catch { }
        try
        {
            if (elemento != null && elemento.Category != null)
                categoria = elemento.Category.Name;
        }
        catch { }

        // Solo IDs y categoría; no se guardan rutas ni nombres de documentos.
        // GetElementSolids lee la geometría de este elemento; las instancias
        // geométricas anidadas se identifican mediante su origen de extracción.
        if (vinculo == null)
            return "Origen de extracción: elemento nativo ID " + id +
                "; categoría: " + categoria + ".";

        string idVinculo = "no disponible";
        try
        {
            if (vinculo.Id != null)
                idVinculo = vinculo.Id.ToString();
        }
        catch { }
        return "Origen de extracción: vínculo ID " + idVinculo +
            "; elemento vinculado ID " + id + "; categoría: " + categoria + ".";
    }

    private string DescribirSolidoCandidato(Solid solido, int indice)
    {
        string origen;
        return "Candidato de suelo nº " + indice + ". " +
            (solido != null && _origenesSolidosCandidatos.TryGetValue(solido, out origen)
                ? origen : "Origen de extracción no disponible.");
    }

    private bool EsElementoVisibleEnVista(Element e, View vista)
    {
        if (e == null)
            return false;

        if (vista == null || vista.IsTemplate)
            return true;

        try
        {
            if (!object.ReferenceEquals(e.Document, vista.Document))
                return true;
        }
        catch
        {
            return true;
        }

        try
        {
            if (e.IsHidden(vista))
                return false;
        }
        catch
        {
        }

        try
        {
            if (e.Category != null && vista.GetCategoryHidden(e.Category.Id))
                return false;
        }
        catch
        {
        }

        try
        {
            if (vista.IsTemporaryHideIsolateActive())
            {
                bool visibleTemporal = vista.IsElementVisibleInTemporaryViewMode(
                    TemporaryViewMode.TemporaryHideIsolate,
                    e.Id);

                if (!visibleTemporal)
                    return false;
            }
        }
        catch
        {
        }

        if (EstaOcultoPorFiltroDeVista(e, vista))
            return false;

        return true;
    }

    private bool EstaOcultoPorFiltroDeVista(Element e, View vista)
    {
        if (e == null || vista == null || vista.IsTemplate)
            return false;

        try
        {
            ICollection<ElementId> filtros = vista.GetFilters();

            if (filtros == null || filtros.Count == 0)
                return false;

            foreach (ElementId idFiltro in filtros)
            {
                if (idFiltro == null || idFiltro == ElementId.InvalidElementId)
                    continue;

                bool visible = true;

                try
                {
                    visible = vista.GetFilterVisibility(idFiltro);
                }
                catch
                {
                    visible = true;
                }

                if (visible)
                    continue;

                Element filtro = vista.Document.GetElement(idFiltro);
                ParameterFilterElement pfe = filtro as ParameterFilterElement;

                if (pfe != null)
                {
                    if (e.Category == null)
                        continue;

                    ICollection<ElementId> categorias = null;

                    try
                    {
                        categorias = pfe.GetCategories();
                    }
                    catch
                    {
                        categorias = null;
                    }

                    if (categorias != null &&
                        categorias.Count > 0 &&
                        !categorias.Any(x => x != null && x.Equals(e.Category.Id)))
                    {
                        continue;
                    }

                    try
                    {
                        ElementFilter filtroReglas = pfe.GetElementFilter();

                        if (filtroReglas != null &&
                            filtroReglas.PassesFilter(e.Document, e.Id))
                        {
                            return true;
                        }
                    }
                    catch
                    {
                    }

                    continue;
                }

                SelectionFilterElement sfe = filtro as SelectionFilterElement;

                if (sfe != null)
                {
                    try
                    {
                        ICollection<ElementId> ids = sfe.GetElementIds();

                        if (ids != null && ids.Any(x => x != null && x.Equals(e.Id)))
                            return true;
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch
        {
        }

        return false;
    }

    private bool CategoriaVinculadaVisibleEnVistaHost(View vistaHost, Element e)
    {
        if (vistaHost == null || e == null || e.Category == null)
            return true;

        try
        {
            long valorCategoria;

            if (long.TryParse(e.Category.Id.ToString(), out valorCategoria) && valorCategoria < 0)
            {
                if (vistaHost.GetCategoryHidden(e.Category.Id))
                    return false;
            }
        }
        catch
        {
        }

        return true;
    }

    private View ObtenerVistaVinculadaUsadaEnHost(
        View vistaHost,
        RevitLinkInstance link,
        Document linkDoc)
    {
        try
        {
            if (vistaHost == null || link == null || linkDoc == null)
                return null;

            MethodInfo metodo = vistaHost.GetType().GetMethod(
                "GetLinkOverrides",
                BindingFlags.Public | BindingFlags.Instance,
                null,
                new Type[] { typeof(ElementId) },
                null);

            if (metodo == null)
                return null;

            object ajustes = metodo.Invoke(
                vistaHost,
                new object[] { link.Id });

            if (ajustes == null)
                return null;

            string[] nombresPropiedad = new string[]
            {
                "LinkedViewId",
                "LinkViewId"
            };

            foreach (string nombre in nombresPropiedad)
            {
                PropertyInfo prop = ajustes.GetType().GetProperty(
                    nombre,
                    BindingFlags.Public | BindingFlags.Instance);

                if (prop == null)
                    continue;

                ElementId idVista = prop.GetValue(ajustes, null) as ElementId;

                if (idVista == null || idVista == ElementId.InvalidElementId)
                    continue;

                View v = linkDoc.GetElement(idVista) as View;

                if (v != null)
                    return v;
            }
        }
        catch
        {
        }

        return null;
    }

    private bool EsElementoOrigenVinculado(
        RevitLinkInstance link,
        Element elementoVinculado)
    {
        try
        {
            if (link == null ||
                elementoVinculado == null ||
                _vinculoOrigenRecorte == null)
            {
                return false;
            }

            if (!link.Id.Equals(_vinculoOrigenRecorte.Id))
                return false;

            return _idsOrigenRecorte.Contains(elementoVinculado.Id);
        }
        catch
        {
            return false;
        }
    }

    private bool EsElementoOrigenNativo(Element elemento)
    {
        try
        {
            if (elemento == null || _vinculoOrigenRecorte != null)
                return false;

            return _idsOrigenRecorte.Contains(elemento.Id);
        }
        catch
        {
            return false;
        }
    }

    // V25: si la cara picada pertenece a un tramo, descanso o soporte,
    // localiza la escalera raíz y devuelve el conjunto completo. Se usa
    // reflexión para no depender de una firma concreta entre versiones.
    private List<Element> ObtenerConjuntoEscaleraDesdeCualquierComponente(
        Element elemento)
    {
        List<Element> resultado = new List<Element>();

        if (elemento == null || elemento.Document == null)
            return resultado;

        Element raiz = BuscarEscaleraRaiz(elemento);

        if (raiz == null)
        {
            resultado.Add(elemento);
            return resultado;
        }

        resultado.Add(raiz);

        HashSet<ElementId> ids = new HashSet<ElementId>();
        AgregarIdsMetodoEscalera(raiz, "GetStairsRuns", ids);
        AgregarIdsMetodoEscalera(raiz, "GetStairsLandings", ids);
        AgregarIdsMetodoEscalera(raiz, "GetStairsSupports", ids);

        foreach (ElementId id in ids)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            Element componente = raiz.Document.GetElement(id);

            if (componente != null &&
                !resultado.Any(x => x != null && x.Id.Equals(componente.Id)))
            {
                resultado.Add(componente);
            }
        }

        if (!resultado.Any(x => x != null && x.Id.Equals(elemento.Id)))
            resultado.Add(elemento);

        return resultado;
    }

    private Element BuscarEscaleraRaiz(Element elemento)
    {
        if (elemento == null || elemento.Document == null)
            return null;

        if (TieneMetodosComponentesEscalera(elemento))
            return elemento;

        try
        {
            IEnumerable<Element> escaleras =
                new FilteredElementCollector(elemento.Document)
                    .OfCategory(BuiltInCategory.OST_Stairs)
                    .WhereElementIsNotElementType()
                    .ToElements();

            foreach (Element escalera in escaleras)
            {
                if (escalera == null)
                    continue;

                HashSet<ElementId> ids = new HashSet<ElementId>();
                AgregarIdsMetodoEscalera(escalera, "GetStairsRuns", ids);
                AgregarIdsMetodoEscalera(escalera, "GetStairsLandings", ids);
                AgregarIdsMetodoEscalera(escalera, "GetStairsSupports", ids);

                if (ids.Contains(elemento.Id))
                    return escalera;
            }
        }
        catch
        {
        }

        return null;
    }

    private bool TieneMetodosComponentesEscalera(Element elemento)
    {
        if (elemento == null)
            return false;

        try
        {
            Type tipo = elemento.GetType();

            return
                tipo.GetMethod("GetStairsRuns", Type.EmptyTypes) != null ||
                tipo.GetMethod("GetStairsLandings", Type.EmptyTypes) != null ||
                tipo.GetMethod("GetStairsSupports", Type.EmptyTypes) != null;
        }
        catch
        {
            return false;
        }
    }

    private void AgregarIdsMetodoEscalera(
        Element escalera,
        string nombreMetodo,
        HashSet<ElementId> ids)
    {
        if (escalera == null ||
            string.IsNullOrWhiteSpace(nombreMetodo) ||
            ids == null)
        {
            return;
        }

        try
        {
            System.Reflection.MethodInfo metodo =
                escalera.GetType().GetMethod(
                    nombreMetodo,
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.Public,
                    null,
                    Type.EmptyTypes,
                    null);

            if (metodo == null)
                return;

            object valor = metodo.Invoke(escalera, null);
            System.Collections.IEnumerable enumerable =
                valor as System.Collections.IEnumerable;

            if (enumerable == null)
                return;

            foreach (object obj in enumerable)
            {
                ElementId id = obj as ElementId;

                if (id != null && id != ElementId.InvalidElementId)
                    ids.Add(id);
            }
        }
        catch
        {
        }
    }

    private Outline CreateOutlineFromLoops(
        List<CurveLoop> loops,
        XYZ normal,
        double profundidad)
    {
        try
        {
            if (loops == null || loops.Count == 0)
                return null;

            if (normal == null)
                normal = XYZ.BasisZ;

            normal = normal.Normalize();

            List<XYZ> pts = new List<XYZ>();

            foreach (CurveLoop loop in loops)
            {
                foreach (Curve c in loop)
                {
                    if (c == null)
                        continue;

                    IList<XYZ> tess = null;

                    try
                    {
                        tess = c.Tessellate();
                    }
                    catch
                    {
                        tess = null;
                    }

                    if (tess == null || tess.Count == 0)
                    {
                        try
                        {
                            tess = new List<XYZ>() { c.GetEndPoint(0), c.GetEndPoint(1) };
                        }
                        catch
                        {
                            tess = null;
                        }
                    }

                    if (tess == null)
                        continue;

                    foreach (XYZ p in tess)
                    {
                        pts.Add(p);
                        pts.Add(p + normal.Multiply(profundidad));
                        pts.Add(p - normal.Multiply(profundidad));
                    }
                }
            }

            if (pts.Count == 0)
                return null;

            XYZ min = new XYZ(
                pts.Min(p => p.X) - SEARCH_MARGIN,
                pts.Min(p => p.Y) - SEARCH_MARGIN,
                pts.Min(p => p.Z) - SEARCH_MARGIN);

            XYZ max = new XYZ(
                pts.Max(p => p.X) + SEARCH_MARGIN,
                pts.Max(p => p.Y) + SEARCH_MARGIN,
                pts.Max(p => p.Z) + SEARCH_MARGIN);

            return new Outline(min, max);
        }
        catch
        {
            return null;
        }
    }

    private Outline TransformOutline(Outline outline, Transform tr)
    {
        try
        {
            if (outline == null)
                return null;

            if (tr == null)
                tr = Transform.Identity;

            XYZ min = outline.MinimumPoint;
            XYZ max = outline.MaximumPoint;

            List<XYZ> pts = new List<XYZ>()
            {
                tr.OfPoint(new XYZ(min.X, min.Y, min.Z)),
                tr.OfPoint(new XYZ(max.X, min.Y, min.Z)),
                tr.OfPoint(new XYZ(min.X, max.Y, min.Z)),
                tr.OfPoint(new XYZ(max.X, max.Y, min.Z)),
                tr.OfPoint(new XYZ(min.X, min.Y, max.Z)),
                tr.OfPoint(new XYZ(max.X, min.Y, max.Z)),
                tr.OfPoint(new XYZ(min.X, max.Y, max.Z)),
                tr.OfPoint(new XYZ(max.X, max.Y, max.Z))
            };

            XYZ newMin = new XYZ(
                pts.Min(p => p.X),
                pts.Min(p => p.Y),
                pts.Min(p => p.Z));

            XYZ newMax = new XYZ(
                pts.Max(p => p.X),
                pts.Max(p => p.Y),
                pts.Max(p => p.Z));

            return new Outline(newMin, newMax);
        }
        catch
        {
            return null;
        }
    }

    private bool IsValidIntersectingElement(Element e)
    {
        if (e == null)
            return false;

        if (e.Category == null)
            return false;

        if (e.Category.CategoryType != CategoryType.Model)
            return false;

        if (e.ViewSpecific)
            return false;

        return true;
    }

    private List<Solid> GetElementSolids(
        Element e,
        Transform baseTransform,
        View vista)
    {
        List<Solid> solids = new List<Solid>();

        if (e == null)
            return solids;

        if (baseTransform == null)
            baseTransform = Transform.Identity;

        //-------------------------------------------------
        // V28: primero la representación de la vista activa. Solo si no hay
        // sólidos se usa la geometría física completa como respaldo.
        //-------------------------------------------------
        List<Options> opciones = new List<Options>();

        if (vista != null && !vista.IsTemplate)
        {
            try
            {
                opciones.Add(new Options()
                {
                    ComputeReferences = false,
                    IncludeNonVisibleObjects = false,
                    View = vista
                });
            }
            catch
            {
            }
        }

        opciones.Add(new Options()
        {
            DetailLevel = ViewDetailLevel.Fine,
            ComputeReferences = false,
            IncludeNonVisibleObjects = false
        });

        foreach (Options opt in opciones)
        {
            GeometryElement geoElem = null;

            try
            {
                geoElem = e.get_Geometry(opt);
            }
            catch
            {
                geoElem = null;
            }

            if (geoElem == null)
                continue;

            int antes = solids.Count;

            CollectSolids(
                geoElem,
                baseTransform,
                solids);

            if (solids.Count > antes)
                break;
        }

        return solids;
    }

    private void CollectSolids(
        GeometryElement geo,
        Transform current,
        List<Solid> solids)
    {
        if (geo == null || solids == null)
            return;

        if (current == null)
            current = Transform.Identity;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                try
                {
                    Solid solidTx =
                        current != null && !current.IsIdentity
                            ? SolidUtils.CreateTransformed(solid, current)
                            : solid;

                    if (solidTx != null &&
                        solidTx.Faces.Size > 0 &&
                        solidTx.Edges.Size > 0 &&
                        solidTx.Volume > 0)
                    {
                        solids.Add(solidTx);
                    }
                }
                catch
                {
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symGeo = gi.GetSymbolGeometry();

                if (symGeo != null)
                {
                    CollectSolids(
                        symGeo,
                        current.Multiply(gi.Transform),
                        solids);
                }
            }
            catch
            {
                try
                {
                    GeometryElement instGeo = gi.GetInstanceGeometry();

                    if (instGeo != null)
                    {
                        CollectSolids(
                            instGeo,
                            current,
                            solids);
                    }
                }
                catch
                {
                }
            }
        }
    }

    // =========================================================
    // NIVELES / ESPESOR / PARÁMETROS
    // =========================================================

    private Level GetBaseLevelForFloor(
        Document doc,
        Element hostElem,
        double z)
    {
        List<Level> levels = new FilteredElementCollector(doc)
            .OfClass(typeof(Level))
            .Cast<Level>()
            .OrderBy(l => l.ProjectElevation)
            .ToList();

        if (levels.Count == 0)
            return null;

        Level hostLevel = null;

        try
        {
            if (hostElem != null &&
                hostElem.LevelId != ElementId.InvalidElementId)
            {
                hostLevel = doc.GetElement(hostElem.LevelId) as Level;
            }
        }
        catch
        {
            hostLevel = null;
        }

        return hostLevel
            ?? levels
                .Where(l => l.ProjectElevation <= z + 0.001)
                .OrderByDescending(l => l.ProjectElevation)
                .FirstOrDefault()
            ?? levels.FirstOrDefault();
    }

    private double GetFloorThickness(FloorType ft)
    {
        if (ft == null)
            return 0.0;

        try
        {
            CompoundStructure cs = ft.GetCompoundStructure();

            if (cs != null)
                return cs.GetWidth();
        }
        catch
        {
        }

        try
        {
            Parameter p = ft.get_Parameter(BuiltInParameter.FLOOR_ATTR_THICKNESS_PARAM);

            if (p != null)
                return p.AsDouble();
        }
        catch
        {
        }

        return 0.0;
    }

    private void GuardarIdEnParametro(Element elem, string nombreParametro)
    {
        if (elem == null || string.IsNullOrWhiteSpace(nombreParametro))
            return;

        Parameter p = elem.LookupParameter(nombreParametro);

        if (p == null || p.IsReadOnly)
            return;

        string idTexto = elem.Id.ToString();

        try
        {
            if (p.StorageType == StorageType.String)
            {
                p.Set(idTexto);
            }
            else if (p.StorageType == StorageType.Integer)
            {
                int idInt = 0;
                int.TryParse(idTexto, out idInt);
                p.Set(idInt);
            }
            else if (p.StorageType == StorageType.ElementId)
            {
                p.Set(elem.Id);
            }
        }
        catch
        {
        }
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                try
                {
                    Form.Show();
                    Form.BringToFront();
                    Form.Activate();
                }
                catch
                {
                    Form.Show();
                }
            }
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Tarrajeo Suelos Handler V24";
    }
}

public class MYG_TarrajeoSueloSilenciosoV24 : IFailuresPreprocessor
{
    private int _pasadas;

    public string UltimoMensaje { get; private set; } = string.Empty;

    public FailureProcessingResult PreprocessFailures(
        FailuresAccessor failuresAccessor)
    {
        _pasadas++;

        IList<FailureMessageAccessor> fallos =
            failuresAccessor.GetFailureMessages();

        if (fallos == null || fallos.Count == 0)
            return FailureProcessingResult.Continue;

        bool huboError = false;
        bool todosLosErroresResueltos = true;
        bool resolvioSeparacion = false;
        List<string> mensajes = new List<string>();

        foreach (FailureMessageAccessor fallo in fallos)
        {
            if (fallo == null)
                continue;

            string descripcion = string.Empty;

            try
            {
                descripcion = fallo.GetDescriptionText();

                if (!string.IsNullOrWhiteSpace(descripcion))
                    mensajes.Add(descripcion);
            }
            catch
            {
            }

            try
            {
                if (fallo.GetSeverity() == FailureSeverity.Warning)
                {
                    failuresAccessor.DeleteWarning(fallo);
                    continue;
                }
            }
            catch
            {
            }

            huboError = true;

            // Decisión automática equivalente al botón "Separar elementos".
            // Se intenta directamente porque algunos fallos de unión no informan
            // correctamente IsFailureResolutionPermitted en la primera pasada.
            bool resuelto = IntentarSepararElementos(
                failuresAccessor,
                fallo);

            if (resuelto)
            {
                resolvioSeparacion = true;
                continue;
            }

            // Nunca se elige "Suprimir elementos" automáticamente. Si Revit no
            // ofrece la separación, se revierte únicamente esta isla en silencio.
            todosLosErroresResueltos = false;
        }

        UltimoMensaje = mensajes.Count > 0
            ? string.Join(" | ", mensajes.Distinct().Take(4))
            : string.Empty;

        // Evita ciclos infinitos si Revit vuelve a generar el mismo fallo.
        if (_pasadas > 5)
            return FailureProcessingResult.ProceedWithRollBack;

        if (huboError && !todosLosErroresResueltos)
            return FailureProcessingResult.ProceedWithRollBack;

        if (resolvioSeparacion)
            return FailureProcessingResult.ProceedWithCommit;

        // Si solo había advertencias, ya fueron eliminadas.
        return FailureProcessingResult.ProceedWithCommit;
    }

    private bool IntentarSepararElementos(
        FailuresAccessor failuresAccessor,
        FailureMessageAccessor fallo)
    {
        if (failuresAccessor == null || fallo == null)
            return false;

        try
        {
            fallo.SetCurrentResolutionType(
                FailureResolutionType.DetachElements);

            failuresAccessor.ResolveFailure(fallo);
            return true;
        }
        catch
        {
        }

        // Segundo intento conservador usando la comprobación formal de Revit.
        try
        {
            if (fallo.HasResolutions() &&
                failuresAccessor.IsFailureResolutionPermitted(
                    fallo,
                    FailureResolutionType.DetachElements))
            {
                fallo.SetCurrentResolutionType(
                    FailureResolutionType.DetachElements);

                failuresAccessor.ResolveFailure(fallo);
                return true;
            }
        }
        catch
        {
        }

        return false;
    }
}
