using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin.RecorteClipper;

namespace MYG_Addin
{
    // Operaciones de conjuntos en UN plano. Los triángulos de una superficie
    // son datos de entrada, nunca piezas de acabado ni contornos de salida.
    internal static class RecortePlanoExterior
    {
        internal static List<List<IntPoint>> UnirRegion(IEnumerable<List<IntPoint>> contornos)
        {
            var caminos = contornos.Where(x => x != null && x.Count >= 3 &&
                Math.Abs(Clipper.Area(x)) >= 0.5).ToList();
            if (caminos.Count == 0)
                return new List<List<IntPoint>>();
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(caminos, PolyType.ptSubject, true))
                throw new InvalidOperationException("No se pudo registrar un contorno de la región.");
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo normalizar una región plana.");
            return Clipper.PolyTreeToPaths(arbol);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes)
        {
            var sujeto = UnirRegion(cara);
            if (sujeto.Count == 0)
                throw new InvalidOperationException("La cara seleccionada no contiene una región cerrada.");
            // Normalizar CADA superficie con sus huecos antes de unirlas.
            // Duplicados de tapas y triángulos nunca se cancelan entre sí.
            var cortes = new List<List<IntPoint>>();
            foreach (var superficie in superficiesCortantes)
                cortes.AddRange(UnirRegion(superficie));
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (cortes.Count > 0)
                motor.AddPaths(cortes, PolyType.ptClip, true);
            var resultado = new PolyTree();
            if (!motor.Execute(ClipType.ctDifference, resultado,
                PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo descontar la unión de interferencias.");
            double areaOriginal = sujeto.Sum(Clipper.Area);
            double areaFinal = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            double toleranciaNumerica = Math.Max(1.0, Math.Abs(areaOriginal) * 1e-12);
            if (areaFinal < -toleranciaNumerica || areaFinal > areaOriginal + toleranciaNumerica)
                throw new InvalidOperationException("El recorte no conserva el área de la cara.");
            return resultado;
        }

        internal static bool MismoDominio(List<List<IntPoint>> a, List<List<IntPoint>> b)
        {
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(UnirRegion(a), PolyType.ptSubject, true);
            motor.AddPaths(UnirRegion(b), PolyType.ptClip, true);
            var diferencia = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctXor, diferencia, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo comprobar el dominio de la cara.");
            return diferencia.All(x => Math.Abs(Clipper.Area(x)) < 0.5);
        }

        internal static List<IntPoint> QuitarColineales(List<IntPoint> original)
        {
            var puntos = new List<IntPoint>();
            foreach (var p in original)
                if (puntos.Count == 0 || puntos[puntos.Count - 1] != p)
                    puntos.Add(p);
            if (puntos.Count > 1 && puntos[0] == puntos[puntos.Count - 1])
                puntos.RemoveAt(puntos.Count - 1);
            bool cambio = true;
            while (cambio && puntos.Count > 3)
            {
                cambio = false;
                for (int i = 0; i < puntos.Count; i++)
                {
                    IntPoint a = puntos[(i + puntos.Count - 1) % puntos.Count];
                    IntPoint b = puntos[i], c = puntos[(i + 1) % puntos.Count];
                    System.Numerics.BigInteger ax = (System.Numerics.BigInteger)b.X - a.X;
                    System.Numerics.BigInteger ay = (System.Numerics.BigInteger)b.Y - a.Y;
                    System.Numerics.BigInteger bx = (System.Numerics.BigInteger)c.X - b.X;
                    System.Numerics.BigInteger by = (System.Numerics.BigInteger)c.Y - b.Y;
                    if (ax * by == ay * bx && ax * bx + ay * by >= 0)
                    {
                        puntos.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }
            return puntos;
        }
    }
}
