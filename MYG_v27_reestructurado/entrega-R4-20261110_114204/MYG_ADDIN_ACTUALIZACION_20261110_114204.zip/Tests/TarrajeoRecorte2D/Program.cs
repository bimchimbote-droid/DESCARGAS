using MYG_Addin;
using MYG_Addin.RecorteClipper;
using Path2D = System.Collections.Generic.List<MYG_Addin.RecorteClipper.IntPoint>;
using Region = System.Collections.Generic.List<System.Collections.Generic.List<MYG_Addin.RecorteClipper.IntPoint>>;

const double S = 304800.0;
int passed = 0, failed = 0;
Test("rectangle without obstacles remains one rectangle", () => Check(Cut(Rect(0,0,10,10)),100,1,0,4));
Test("internal obstacle creates its actual opening", () => Check(Cut(Rect(0,0,10,10), R(Rect(2,2,4,4))),96,1,1));
Test("partial obstacle creates a notch", () => Check(Cut(Rect(0,0,10,10), R(Rect(4,-1,6,3))),94,1,0,8));
Test("only a transverse obstacle separates two panels", () => Check(Cut(Rect(0,0,10,10),R(Rect(4,-1,6,11))),80,2,0));
Test("complete cover leaves no finish", () => Check(Cut(Rect(0,0,10,10),R(Rect(-1,-1,11,11))),0,0,0));
Test("external obstacle does not modify the face", () => Check(Cut(Rect(0,0,10,10),R(Rect(11,0,12,10))),100,1,0,4));
Test("duplicate faces never cancel an obstacle", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(Rect(2,2,4,4))),96,1,1));
Test("overlapping obstacles are subtracted once", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,6,6)),R(Rect(4,2,8,6))),76,1,1));
Test("triangulated rectangle has no diagonal in its final opening", () => {
    var tree=Cut(Rect(0,0,10,10),R(P(2,2,4,2,4,4)),R(P(2,2,4,4,2,4)));
    Check(tree,96,1,1); Assert(Contours(tree).All(p=>RecortePlanoExterior.QuitarColineales(p).Count==4),"A mesh diagonal survived.");
});
Test("thin triangles inside a footprint never enlarge the cut", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(P(3.999,2,4,3,3.999,4))),96,1,1));
Test("all triangles of a rectangular face unite into one panel", () => {
    var normalized=RecortePlanoExterior.UnirRegion(R(P(0,0,10,0,10,10),P(0,0,10,10,0,10)));
    Check(RecortePlanoExterior.Restar(normalized,Array.Empty<Region>()),100,1,0,4);
});
Test("original face openings are preserved", () => Check(RecortePlanoExterior.Restar(R(Rect(0,0,10,10),Rect(2,2,4,4)),new[]{R(Rect(11,0,12,10))}),96,1,1));
Test("obstacle opening retains a natural island", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,8,8),Rect(4,4,6,6))),68,2,1));
Test("another obstacle fills the opening in an obstacle", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,8,8),Rect(4,4,6,6)),R(Rect(4,4,6,6))),64,1,1));
Test("reversed contours preserve ownership", () => {
    var face=Rect(0,0,10,10);face.Reverse();var hole=Rect(2,2,4,4);hole.Reverse();
    Check(Cut(face,R(hole)),96,1,1);
});
Test("rotated rectangles keep rectangular boundaries", () => {
    Path2D Rotate(Path2D p)=>p.Select(v=>new IntPoint((3*v.X-4*v.Y)/5,(4*v.X+3*v.Y)/5)).ToList();
    var tree=Cut(Rotate(Rect(0,0,10,10)),R(Rotate(Rect(2,2,4,4))));
    Check(tree,96,1,1);Assert(Contours(tree).All(p=>RecortePlanoExterior.QuitarColineales(p).Count==4),"Unexpected diagonal/vertex.");
});
Test("two close obstacles keep the real material gap", () => {
    var tree=Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(Rect(4.01,2,6,4)));
    Check(tree,92.02,1,2);
});
Test("redundant collinear vertices do not become edges", () => {
    var p=P(0,0,5,0,10,0,10,10,0,10,0,0);Assert(RecortePlanoExterior.QuitarColineales(p).Count==4,"Collinear vertex remained.");
});
Test("same domain is independent of orientation and redundant vertices", () => {
    var a=R(Rect(0,0,10,10),Rect(2,2,4,4));var b=R(P(10,10,10,0,5,0,0,0,0,10),Rect(2,2,4,4));
    Assert(RecortePlanoExterior.MismoDominio(a,b),"Equal domain changed.");
});
Test("equal area with a moved opening is a different domain", () => Assert(!RecortePlanoExterior.MismoDominio(R(Rect(0,0,10,10),Rect(2,2,4,4)),R(Rect(0,0,10,10),Rect(6,6,8,8))),"Opening location was ignored."));
Test("upward finish is outside the solid", () => Near(TarrajeoAlturas.CalcularDesfase(100,90,1,.05,0),10.05));
Test("downward finish is outside the solid", () => Near(TarrajeoAlturas.CalcularDesfase(100,90,-1,.05,0),10));
Test("internal project level controls offset", () => Near(TarrajeoAlturas.CalcularDesfase(1100,1090,1,.05,0),10.05));
Test("contact check rejects a finish penetrating the host", () => Assert(!TarrajeoAlturas.ContactoExteriorValido(-.01,.04,0,.0003),"Penetration accepted."));
Test("contact check accepts an external finish touching the face", () => Assert(TarrajeoAlturas.ContactoExteriorValido(0,.05,0,.0003),"External contact rejected."));
Console.WriteLine($"Passed: {passed}; failed: {failed}; total: {passed+failed}");
Console.WriteLine("Production planar set operations and height rules only; no Revit runtime or model execution.");
return failed==0?0:1;

Path2D P(params double[] xy) { var p=new Path2D();for(int i=0;i<xy.Length;i+=2)p.Add(new IntPoint((long)Math.Round(xy[i]*S),(long)Math.Round(xy[i+1]*S)));return p; }
Path2D Rect(double x0,double y0,double x1,double y1)=>P(x0,y0,x1,y0,x1,y1,x0,y1);
Region R(params Path2D[] paths)=>paths.ToList();
PolyTree Cut(Path2D face,params Region[] obstacles)=>RecortePlanoExterior.Restar(R(face),obstacles);
IEnumerable<Path2D> Contours(PolyTree tree) { for(var n=tree.GetFirst();n!=null;n=n.GetNext())yield return n.Contour; }
void Check(PolyTree tree,double area,int regions,int holes,int? vertices=null) {
    var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Near(nodes.Sum(n=>Clipper.Area(n.Contour))/(S*S),area,1e-7);
    Assert(nodes.Count(n=>!n.IsHole)==regions,$"regions={nodes.Count(n=>!n.IsHole)} expected={regions}");
    Assert(nodes.Count(n=>n.IsHole)==holes,$"holes={nodes.Count(n=>n.IsHole)} expected={holes}");
    if(vertices.HasValue)Assert(nodes.Where(n=>!n.IsHole).All(n=>RecortePlanoExterior.QuitarColineales(n.Contour).Count==vertices),"Unexpected artificial edges.");
}
void Near(double actual,double expected,double tolerance=1e-9)=>Assert(Math.Abs(actual-expected)<=tolerance,$"actual={actual:G17}, expected={expected:G17}");
void Assert(bool condition,string message) { if(!condition)throw new InvalidOperationException(message); }
void Test(string name,Action test) { try{test();passed++;Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+": "+e.Message);} }
