# Motor de acabado exterior por boceto — TARRAJEO-PLANO-R4

## Base y alcance

Código seleccionado: `bimchimbote-droid/MYG_v27_reestructurado`, master, base Git `cb9d73137e06f55741862274e4ee839bb87e5d80`. Base inmediata de entrega: R2 publicada en DESCARGAS en el commit `cf8abe8e3ffbf6774f2911e649e44870d3bbcb04`. Los avances locales de esta conversación se conservaron. La R3 experimental no se publicó; esta revisión la sustituye, de acuerdo con la petición de rehacer la lógica para obtener contornos fieles.

Se reemplaza el flujo principal de suelos y el recorte de caras planas de muros. Se mantienen selección, filtros de visibilidad de la vista activa, transformaciones de vínculos, exclusión del anfitrión, ventanas, botones y tipos elegidos. No se migran dependencias ni el framework. El tratamiento de muros curvos conserva su flujo existente.

## Lógica final

1. Leer los bordes completos de la cara seleccionada, incluidos todos sus huecos, en coordenadas del modelo.
2. Usar la normal exterior y el espesor real del acabado. La zona ocupada es exclusivamente `[cara, cara + normal × espesor]`; un sólido detrás o tangente no es una interferencia volumétrica.
3. Filtrar los sólidos nativos/vinculados mediante las reglas de visibilidad existentes. Recortar cada candidato únicamente con los dos planos que delimitan el espesor exterior, sin intersectar/restar sucesivamente un sólido complejo de la cara.
4. Proyectar sus superficies en el plano de la cara y unir TODA su huella antes de descontarla. Las superficies planas conservan sus contornos con huecos; las curvas usan la triangulación de Revit. Esos triángulos son datos para construir la sombra, nunca piezas de acabado ni triángulos ensanchados.
5. Realizar una única diferencia 2D: región original MENOS unión de huellas. Crear una pieza por región exterior realmente separada, con sus huecos correspondientes.
6. Construir el boceto horizontal sin limpiar, borrar o mover sus vértices. Crear el suelo con el desplazamiento exterior y verificar su geometría final antes de confirmar el grupo de transacciones. Para inclinados se conserva el editor de forma y también se verifica el contacto exterior final.

Se retiran del flujo activo las franjas artificiales, los reintentos que reconstruyen el mismo perfil inválido, el desplazamiento arbitrario de 0.8 mm y el ensanchamiento de triángulos delgados. Una región rectangular no se convierte en varios paños porque el algoritmo la haya triangulado. Solo las interferencias reales cambian el contorno.

La rejilla 2D es local de 0.001 mm (error máximo de redondeo por eje 0.0005 mm). Solo se eliminan duplicados y puntos exactamente colineales. No se utilizan cajas envolventes como obstáculos, envolventes convexas ni limpieza con la tolerancia de creación de Revit. Si no hay descuento real y la cara tiene una sola región exterior, se conservan las curvas originales, incluidos arcos.

## Archivos e intervención

| Acción | Ruta relativa | Función |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Flujo directo de cara a boceto y creación exterior, validación y log R4. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs` | Recorte planar con el mismo motor exterior para muros. |
| CREAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Unión/diferencia 2D de regiones completas. |
| CREAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs` | Adaptación de geometría Revit al plano y al espesor físico exterior. |
| MODIFICAR | `MYG/MYG.csproj` | Registrar solo los dos nuevos Compile mediante parche. No se entrega el proyecto completo. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Casos del nuevo motor y alturas exteriores. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj` | Compilar directamente el código real del motor, sin extractor Roslyn. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Ejecución, resultados y límites. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |
| ELIMINAR | `Tests/TarrajeoRecorte2D/HarnessCases.cs` | Casos obsoletos del flujo por franjas retirado; no se incluye ese archivo en el ZIP. |

El ZIP añade dos parches y el manifiesto SHA-256: 11 archivos. Solo contiene fuentes nuevas/modificadas y material de esta entrega. Excluye .git/.vs, bin/obj, paquetes, DLL, modelo, capturas y logs del usuario. Clipper.cs, TarrajeoAlturas.cs y TarrajeoValidacionSuelo.cs permanecen SIN CAMBIOS y fuera del ZIP.

## Instalación

1. Respaldar la solución y comparar con la versión de trabajo indicada. Copiar un handler completo puede sobrescribir cambios locales o posteriores; integrar diferencias si tu archivo local ya cambió.
2. Copiar los dos handlers completos y los dos archivos nuevos conservando rutas relativas.
3. Sobre el proyecto con lista explícita de Compile, comprobar y aplicar SOLO el registro de nuevos archivos:

```bash
git apply --check PARCHES/REGISTRAR_MOTOR_PLANO.patch
git apply PARCHES/REGISTRAR_MOTOR_PLANO.patch
```

El parche cambia dos líneas de inclusión, sin reemplazar paquetes, referencias, framework o propiedades personales. También puedes usar Agregar → Elemento existente en Visual Studio. Si tu proyecto SDK incluye los .cs automáticamente, no agregues referencias Compile duplicadas. Verifica la inclusión de ambos archivos nuevos y conserva tus actualizaciones locales.

4. El parche `PARCHES/ACTUALIZAR_HANDLERS_DESDE_R2.patch` es una alternativa a reemplazar los dos handlers, únicamente sobre los archivos de R2. Primero usa `git apply --check`; no lo apliques después de copiarlos completos ni a otra versión sin revisar.
5. Las pruebas son independientes y no se añaden al add-in. Copiar sus tres archivos y eliminar el HarnessCases.cs obsoleto; el nuevo proyecto lo excluye si queda en disco.
6. Compilar para tu instalación real Windows/Revit, actualizar la DLL de prueba conservando .addin e iconos, cerrar completamente todas las instancias de Revit y volver a abrir. Copiar .cs no actualiza la DLL cargada por AddInManager.
7. Ejecutar con una copia del modelo sin los acabados de prueba de R1/R2, o deshacerlos antes: siguen siendo sólidos visibles y pueden interferir con la nueva ejecución. No se borran automáticamente elementos de tu modelo. El aviso/log debe identificar `TARRAJEO-PLANO-R4`. Comprobar rectángulo intacto sin interferencias, muesca parcial, hueco interior, corte transversal, sólido detrás de la cara y posición exterior tanto arriba como abajo. Si falla una frontera, el log local incluye sus coordenadas para poder reproducirla, no solo un índice de arista.

## Validación y límites reales

25/25 pruebas del nuevo motor 2D y reglas de altura exterior pasan. Incluyen caras/cortes rectangulares rotados, superficies trianguladas y duplicadas, uniones, huecos e islas: no quedan diagonales internas como bordes finales. El proyecto de pruebas compila el código de producción mediante enlaces; no mantiene una segunda implementación.

La compilación semántica contra 81 ensamblados de referencia reales de Revit incluidos pasó para los tres archivos completos del motor (Clipper y dos archivos nuevos), y para los cuerpos reales del nuevo flujo de suelos/proyección/validación. Los auxiliares antiguos ajenos a ese flujo se sustituyen solo por firmas en esa comprobación de contratos; no se ejecuta Revit. La revisión sintáctica verifica los 182 archivos activos y las rutas de recursos.

La compilación completa del add-in en Linux se intentó y sigue detenida por MSB4803 en ResolveComReference/COM. No se generó una nueva DLL. Persiste el conflicto de EPPlus.Interfaces y la configuración local del repositorio declara .NET Framework 4.8 mientras su RevitAPI incluida declara .NET 10; esta entrega evita sustituir el proyecto completo y conserva las actualizaciones que tengas en Windows. No añade paquetes ni referencias externas.

No se ejecutó el modelo del usuario, Floor.Create, la selección/visibilidad real, los planos de corte 3D ni la creación final dentro de Revit. Esas pruebas siguen pendientes. Una geometría nativa que Revit no permita cortar con planos se diagnostica; no se sustituye por una forma inventada ni se crea acabado sobre una interferencia no evaluada. Un borde real menor que ShortCurveTolerance también se reporta, sin convertir su paño en franjas. Cuando hay recortes sobre curvas, la poligonal procede de la teselación de Revit; no se garantiza exactitud analítica de arcos recortados. No se certifica funcionamiento del flujo de muros curvos, que no fue reescrito.

## GitHub y publicación

Se publica únicamente el ZIP en una ruta nueva de `bimchimbote-droid/DESCARGAS`, conservando entregas anteriores. Se verifica por Git HTTPS desde un clon independiente, SHA-256, integridad y manifiesto. Por petición del usuario no se generan ni se envían enlaces de descarga.

Esto no actualiza tu PC ni realiza Commit/Push a `MYG_v27` o `MYG_v27_reestructurado`. Revisa los archivos y el cambio puntual del proyecto en Git Changes de Visual Studio, ejecuta las comprobaciones y realiza Commit y Push cuando decidas incorporarlos. No publiques tu modelo ni el log geométrico.
