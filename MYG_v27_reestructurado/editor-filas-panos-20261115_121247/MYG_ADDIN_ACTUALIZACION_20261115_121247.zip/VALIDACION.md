# Validación: editor de filas y paños

## Ejecutado
-98 pruebas aprobadas,0 fallidas:56 de distribución/altura/alineación y42 nuevas del estado/geométrica del editor. Se prueba el mismo LadrillosEditor utilizado por la UI y por la validación final del comando.
- Nuevos casos:selección por fila/pieza/marco/malla, filas estables tras moverlas, desplazamientoUV de grupos, historial de inclusión/posiciones/restablecer, ramas de redo, agrupación/cancelación de ediciones, contornos/huecos/márgenes, solapamientos y excluidas, validación atómica y valores no finitos, hasta100 cambios,10.000 piezas dispersas y1.000 coincidentes.
- Compilación aislada C#7.3/net10.0-windows contra API Revit2027:0 errores/0 advertencias. No equivale a ejecutar la UI ni a compilar/cargar la solución original completa.
-188 fuentes Roslyn sin errores;188Compile,9EmbeddedResource y3None presentes/sin duplicados; gitdiffcheck correcto.
- Compilación completa intentada:falla MSB4803 por referencias COM con MSBuild .NET Core en Linux; advertencia EPPlus.Interfaces preexistente. No hay DLL nueva del complemento completo.

Con el proyecto de pruebas existente y los archivos actualizados:
```bash
dotnet restore Pruebas/LadrillosLosas/BrickLayout.Tests.csproj --configfile Pruebas/LadrillosLosas/NuGet.Config
dotnet run --no-restore --project Pruebas/LadrillosLosas/BrickLayout.Tests.csproj
```
Requiere SDK .NET10, sin paquetes adicionales. El runner devuelve código distinto de cero si falla algún caso. Los outputs de esta entrega están fuera del checkout.

## Pendiente en Windows/Revit
No se ejecutaron estos casos interactivos en el entorno Linux:

| Caso | Resultado esperado |
|---|---|
| Vista y DPI | Header, checkbox fijo, tarjetas/scroll y botones legibles; toolbar se adapta al ancho |
| Fila | Clic+arrastre mueve toda la fila real planificada, no el fondo; etiqueta de fila estable |
| Pieza | Mueve únicamente una pieza sin desplazar otras |
| Paño | Marco parcial selecciona por centros; arrastre posterior mueve exactamente ese grupo |
| Múltiple | Ctrl añade filas/marcos; malla completa y Ctrl+A seleccionan el conjunto |
| Precisión |7,5cm enU oV produce esa distancia en el modelo; flechas usan paso yMayús10veces |
| Gesto | Ghost no modifica estado; soltar registra un único Deshacer; Esc/captura perdida cancela |
| Navegación | Botón central/Espacio/fondo desplazan vista y no las piezas; zoom mantiene el ancla |
| Historial | Undo/redo/restablecer recuperan posiciones e inclusión; nueva edición invalida redo |
| Datos inválidos | Mover fuera del contorno, a hueco o sobre otra fila se marca rojo y bloquea Crear |
| Excluidas | Excluir una pieza inválida permite crear las demás si son válidas; no se omite sin aviso |
| Existentes | Mover sobre ladrillos ya colocados de la misma familia también se rechaza |
| Vecinos | Se actualizan cruces al mover y al deshacer; no quedan marcadores antiguos |
| Checkbox | MarcaUnir y modoefectivo coincide; desmarcar recupera opción avanzada anterior |
| Entradas | Enter/flechas en campos numéricos no crean o desplazan la malla accidentalmente |
| Confirmar | Se crean los centros editados; contornoBRep/existentes/mutuos se vuelven a comprobar |
| Unión/corte | Se mantienen prioridades, fallbackomitir, geometría fresca y verificación final anterior |
| Cancelación/Undo | No se guardan ediciones al cancelar; un solo DeshacerRevit revierte el lote creado |
| Rendimiento | Evaluar arrastre yrefresco en paños representativos; tests de10.000piezas no son una prueba de velocidad de UI |

La prueba automática de geometría/historial y la compilación no se presentan como prueba funcional de Revit aprobada.
