# MYG · Editor de filas y paños

## A. Resumen y base de trabajo
La previsualización se convierte en un editor de la distribución **antes de crear** los ladrillos: selección por fila/pieza/marco de paño, movimiento mediante arrastre o desplazamiento U/V en cm, paso y ajuste de arrastre, deshacer/rehacer y restablecer. Se añade el checkbox explícito **Unir elementos intersecantes**, fijo en la parte superior del editor y también presente en la configuración inicial.

Base real: `bimchimbote-droid/MYG_v27_reestructurado`, HEAD Git `2a8977e8032d0bd9d12d7302b897d5096b0cf064` más las entregas anteriores. Esta corrección se aplica sobre `MYG_ADDIN_ACTUALIZACION_20261115_114241.zip`, publicado en DESCARGAS en commit `9161f2e15b816d7ffdc7e9940c36e74ce0dcefc1`, SHA256 `38180e0bad3bcd8a215929ed3f32f31aea7f04dc1b9e077ee36d0540fa03a587`. Se conservan las correcciones de hospedaje, alineación, previsualización y encuentros previas. No se sustituyeron por otra rama ni se actualizaron dependencias.

## B. Archivos afectados
Todos son archivos existentes de la entrega anterior; se entregan completos:

| Ruta | Acción |
|---|---|
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosPreviewForm.cs | REEMPLAZAR: editor visual y controles de edición |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaCommand.cs | REEMPLAZAR: revalidación de posiciones editadas y creación en esos centros |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaForm.cs | REEMPLAZAR: checkbox de unión y jerarquía visual |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLayout.cs | REEMPLAZAR: mantiene distribución/altura/alineación y añade estado/historial del editor |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosInterferencias.cs | REEMPLAZAR: presupuesto independiente de cada evaluación interactiva/final |
| Pruebas/LadrillosLosas/Program.cs | REEMPLAZAR en el proyecto opcional de pruebas:98 casos |

ARCHIVOS.csv identifica hashes antes/después. No hay archivos nuevos del add-in, eliminaciones, parches ni cambios del `.csproj`, referencias, paquetes, manifiesto o Ribbon. Los archivos sin cambios no están incluidos. Tampoco se incluyen modelos, familias originales sin cambios, DLL, paquetes restaurables o credenciales.

## C. Descarga
Paquete: `MYG_ADDIN_ACTUALIZACION_20261115_121247.zip`; fecha/hora America/Lima. La publicación y la comprobación de descarga se confirman en el mensaje final una vez realizadas. Se publica únicamente este ZIP en una ruta nueva de DESCARGAS; las entregas anteriores se conservan.

## D. Instalación
1. Cierra Revit y respalda la solución y la DLL que utilizabas.
2. Reemplaza **los cinco archivos C# del complemento** en sus rutas relativas. No mezcles el formulario nuevo con el comando antiguo: el constructor ahora exige la integración que vuelve a comprobar cada edición. No pegues fragmentos dentro de clases existentes.
3. Si tienes cambios propios posteriores, compara/fusiona antes de reemplazar para no perderlos.
4. Si instalaste el proyecto de pruebas opcional, sustituye su Program.cs. No añadas ese archivo de pruebas al proyecto MYG del add-in. Su csproj y NuGet.Config anteriores se mantienen.
5. No modifiques el `.csproj` ni vuelvas a aplicar los parches de entregas anteriores: todas las clases nuevas están dentro de archivos ya incluidos.
6. Compila en Windows y sustituye MYG.dll en tu instalación habitual con Revit cerrado. Reinicia Revit antes de cargar la nueva DLL con AddInManager. Conserva .addin y MYG_Addin.App.

## E. Usar el editor
### Seleccionar y mover
1. Configura familia, separaciones y altura como antes, selecciona losa y dirección, y abre el editor.
2. En **Fila completa**, pulsa una pieza para seleccionar su fila de origen y arrastra cualquiera de las piezas seleccionadas. La fila conserva su identidad aunque se mueva cerca de otra.
3. En **Pieza**, selecciona y mueve solo un ladrillo.
4. En **Paño / grupo**, dibuja un marco sobre la zona que quieras ajustar. Se seleccionan las piezas cuyo centro queda dentro del marco. Después arrastra una de las seleccionadas para mover el grupo completo. Así puedes ajustar una parte del paño sin mover toda la malla.
5. **Ctrl** añade piezas/filas/marcos a la selección. Cambia de herramienta o pulsa sobre fondo para limpiar según el modo; Ctrl+A sobre el lienzo selecciona toda la malla. **Toda la malla** permite seleccionar el conjunto al pulsar una pieza.
6. Para precisión, introduce **Mover U** (dirección de filas) y **Mover V** (transversal), en cm, y pulsa Aplicar desplazamiento. Son desplazamientos relativos: volver a pulsar aplica otra vez esos valores.
7. Las flechas desplazan el **Paso** configurado (1cm inicial). Mayús multiplica por10. Ajustar arrastre al paso aproxima el arrastre a ese paso; los campos U/V permiten escribir desplazamientos como7,5cm.

Durante el arrastre se dibuja un movimiento provisional; al soltar se aplica una sola edición y se comprueba. Esc durante el gesto lo cancela. Arrastrar piezas mueve la distribución; para mover SOLO LA VISTA usa botón central, Espacio+arrastre o el fondo fuera de una selección por marco. Rueda para zoom, Ajustar vista/Home para encuadrar.

### Corregir y deshacer
- **Deshacer/Rehacer**, o Ctrl+Z/Ctrl+Y cuando no se está editando un campo de texto, recorren el historial de la previsualización. Un arrastre equivale a un cambio. Se conservan hasta100 cambios.
- Restablecer selección devuelve sus posiciones e inclusión originales; Restablecer toda la malla devuelve el conjunto al estado inicial. Ambos cambios pueden deshacerse.
- Incluir/Excluir selección controla qué piezas se crearán. Supr sobre el lienzo excluye las seleccionadas. No elimina piezas existentes del modelo.
- Terracota: incluida; azul: seleccionada; rojo: fuera de contorno/huecos/margen o solapada con otro ladrillo; ámbar: posible encuentro con vecino; gris: excluida. Una pieza seleccionada que tiene un encuentro conserva un indicador ámbar.
- Las posiciones inválidas se conservan visibles para corregirlas; **Crear distribución se bloquea** mientras haya piezas incluidas inválidas o no se puedan comprobar los encuentros. Deshaz, mueve de nuevo o excluye las piezas necesarias; no se borran silenciosamente.

Antes de crear se vuelven a comprobar independientemente las huellas completas contra los contornos y huecos, el sólido real original de la losa, las piezas entre sí y los ladrillos existentes de la misma familia. El comando usa los centros editados, no las posiciones originales de la malla.

### Unir elementos intersecantes
Marca el checkbox superior **Unir elementos intersecantes** para solicitar el modo Unir. Con él marcado, el selector avanzado queda deshabilitado. Al desmarcarlo se recupera la opción avanzada anterior (Omitir, Solo detectar o Cortar). La configuración inicial también sincroniza su checkbox con el modo.

Se conserva la detección sobre los vecinos incluidos por búsqueda automática o selección manual. El vecino tiene prioridad para recortar el ladrillo. Revit debe admitir la unión de esa pareja; si no la admite, queda volumen común o se consume toda la pieza, se revierte el intento y se omite ese ladrillo, como en la versión anterior. Solo detectar puede conservar interferencias y lo comunica.

El editor vuelve a calcular la previsión de encuentros después de los desplazamientos, exclusiones e historial; las posiciones que no cambiaron usan una caché válida para ese contexto. Cada evaluación tiene su propio límite de comprobaciones, separado del lote final, para que varias ediciones no agoten el presupuesto de creación.

## F. Validación
- **98 pruebas ejecutadas,0 fallidas**:56 anteriores y42 nuevas del modelo real de edición. Incluyen filas estables, paños, movimiento, inclusión, restablecer, historial/ramas, contornos/huecos/márgenes, solapamientos, valores inválidos,10.000 piezas y celdas congestionadas.
- Compilación aislada de fuentes actuales contra DLL reales disponibles de API Revit2027, C#7.3/net10.0-windows: **0 advertencias,0 errores**. Los adaptadores de integración del harness externo no forman parte del add-in ni del ZIP.
- Roslyn:188 fuentes activas sin errores;188Compile,9EmbeddedResource y3None existentes y sin duplicados. gitdiffcheck correcto.
- Compilación completa intentada: continúa MSB4803 en COM sobre Linux/MSBuild .NET Core, con MSB3277 de EPPlus.Interfaces preexistente.
- **No se ejecutó la interfaz, el arrastre ni Join/Cut dentro de Revit en este entorno Linux.** Las pruebas automatizadas verifican el modelo geométrico/estado; la interacción real, DPI y compatibilidad de operaciones deben comprobarse en Windows/Revit. VALIDACION.md contiene los pasos pendientes.

## G. GitHub
Solo se publica el ZIP en DESCARGAS; no se modifican ramas de MYG_v27/MYG_v27_reestructurado ni se actualiza tu PC. Después de instalar, compilar y probar, revisa los diffs en Cambios de Git de Visual Studio, crea tu Commit y haz Push desde tu equipo cuando decidas publicar el código.

## H. Límites
- Se editan los ladrillos **planificados en esta previsualización antes de crearlos**. No se mueven automáticamente ladrillos ya existentes del proyecto, ni se reconstruye una distribución guardada de ejecuciones anteriores.
- El paño es un grupo de piezas elegido por marco; no se crean nuevas losas ni se adivinan paños estructurales a partir de las vigas. El editor traslada piezas; no añade, duplica ni rota paños de forma independiente.
- Mover filas puede cambiar la separación local respecto a la vigueta/junta inicial. Por eso el resumen identifica esos valores como iniciales. Se impiden solapamientos, pero no se obliga a mantener una separación uniforme después de una edición manual.
- La visualización es esquemática2D. Los huecos dibujados en los ladrillos ayudan a leer la forma, sin representar exactamente la familia. Los recortes3D se verifican con geometría real al crear; la previsualización de encuentros es conservadora.
- Se conserva la altura nativa de familia hospedada por defecto y el ajuste al intradós opcional; el movimiento del editor es en U/V. La losa anfitriona y los vínculos siguen excluidos de la resolución de vecinos.
- Se mantienen límites de100.000 candidatos/10.000 piezas/2.000 vecinos/500.000 booleanas por evaluación. Un fallo de comprobación no se considera espacio libre. Si al confirmar falla una validación, se revierte el lote completo.
- No se migró el framework ni se cambiaron dependencias. La compatibilidad original de .NET Framework4.8/Revit2027 y los requisitos COM/Windows siguen pendientes de la configuración del proyecto.
