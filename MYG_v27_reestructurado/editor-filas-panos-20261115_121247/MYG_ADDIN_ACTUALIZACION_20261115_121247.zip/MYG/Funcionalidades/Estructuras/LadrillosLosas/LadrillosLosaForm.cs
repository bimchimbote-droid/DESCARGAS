using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Autodesk.Revit.DB;
using Forms = System.Windows.Forms;
using Media = System.Windows.Media;

namespace MYG_Addin
{
    internal sealed class LadrillosLosaOpciones
    {
        internal ElementId TipoId { get; set; }
        internal string ArchivoFamilia { get; set; }
        internal double ViguetaCm { get; set; } = 10;
        internal double JuntaCm { get; set; }
        internal double MargenCm { get; set; }
        internal double DesfaseBaseCm { get; set; }
        internal bool Girar90 { get; set; }
        internal bool AjustarBaseAlIntrados { get; set; }
        internal ModoEncuentroLadrillos ModoEncuentros { get; set; } = ModoEncuentroLadrillos.Omitir;
        internal bool SeleccionarVecinos { get; set; }
    }

    internal sealed class LadrillosLosaForm : Forms.Form
    {
        private readonly Forms.ComboBox tipos = new Forms.ComboBox();
        private readonly Forms.TextBox archivo = new Forms.TextBox();
        private readonly Forms.NumericUpDown vigueta = Numero(10, 1000);
        private readonly Forms.NumericUpDown junta = Numero(0, 1000);
        private readonly Forms.NumericUpDown margen = Numero(0, 1000);
        private readonly Forms.NumericUpDown desfase = Numero(0, 1000);
        private readonly Forms.CheckBox giro = new Forms.CheckBox();
        private readonly Forms.CheckBox ajustarBase = new Forms.CheckBox();
        private readonly Forms.CheckBox unirElementos = new Forms.CheckBox();
        private readonly Forms.ComboBox encuentros = new Forms.ComboBox();
        private readonly Forms.CheckBox seleccionarVecinos = new Forms.CheckBox();
        private bool sincronizandoEncuentros;
        private ModoEncuentroLadrillos ultimoModoSinUnion = ModoEncuentroLadrillos.Omitir;

        internal LadrillosLosaOpciones Opciones { get; private set; }

        internal LadrillosLosaForm(IList<FamilySymbol> simbolos)
        {
            Text = "MYG · Ladrillos en losa";
            Font = new Font("Segoe UI", 9F);
            StartPosition = Forms.FormStartPosition.CenterScreen;
            FormBorderStyle = Forms.FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = false;
            AutoScaleMode = Forms.AutoScaleMode.Font;
            ClientSize = new Size(760, 720);
            MinimumSize = new Size(700, 500);
            BackColor = System.Drawing.Color.White;
            ForeColor = System.Drawing.Color.FromArgb(35, 45, 58);

            var contenido = new Forms.Panel
            {
                Dock = Forms.DockStyle.Fill,
                AutoScroll = true,
                Padding = new Forms.Padding(12)
            };
            var botones = new Forms.FlowLayoutPanel
            {
                Dock = Forms.DockStyle.Bottom,
                FlowDirection = Forms.FlowDirection.RightToLeft,
                Height = 54,
                Padding = new Forms.Padding(12, 8, 12, 8)
            };
            Controls.Add(contenido);
            Controls.Add(botones);

            var tabla = new Forms.TableLayoutPanel
            {
                Dock = Forms.DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = Forms.AutoSizeMode.GrowAndShrink,
                Padding = new Forms.Padding(4),
                ColumnCount = 2,
                RowCount = 16
            };
            tabla.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Absolute, 280));
            tabla.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            for (int i = 0; i < 16; i++)
                tabla.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.AutoSize));
            contenido.Controls.Add(tabla);

            var encabezado = new Forms.Label
            {
                Text = "Ladrillos en losa",
                AutoSize = true,
                Dock = Forms.DockStyle.Fill,
                Font = new Font(Font.FontFamily, 15F, FontStyle.Bold),
                Margin = new Forms.Padding(3, 2, 3, 8)
            };
            tabla.Controls.Add(encabezado, 0, 0);
            tabla.SetColumnSpan(encabezado, 2);
            AgregarSeccion(tabla, 1, "1. Familia de ladrillo");

            tipos.DropDownStyle = Forms.ComboBoxStyle.DropDownList;
            tipos.DisplayMember = "Etiqueta";
            tipos.Items.Add(new OpcionTipo(null, "Cargar familia desde archivo .rfa…"));
            foreach (var simbolo in simbolos.OrderBy(x => x.Family.Name).ThenBy(x => x.Name))
                tipos.Items.Add(new OpcionTipo(simbolo.Id, simbolo.Family.Name + " : " + simbolo.Name,
                    simbolo.Family.FamilyPlacementType == FamilyPlacementType.OneLevelBasedHosted));
            tipos.SelectedIndex = 0;
            // Preferir ladrillos existentes; no elegir automáticamente otro modelo genérico.
            for (int i = 1; i < tipos.Items.Count; i++)
                if (((OpcionTipo)tipos.Items[i]).Etiqueta.IndexOf("ladrillo", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    tipos.SelectedIndex = i;
                    break;
                }
            Agregar(tabla, 2, "Tipo de ladrillo cargado", tipos);

            archivo.ReadOnly = true;
            archivo.Dock = Forms.DockStyle.Fill;
            var buscar = new Forms.Button { Text = "Examinar…", AutoSize = true };
            var filaArchivo = new Forms.TableLayoutPanel { Dock = Forms.DockStyle.Fill, ColumnCount = 2, Margin = Forms.Padding.Empty };
            filaArchivo.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            filaArchivo.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.AutoSize));
            filaArchivo.Controls.Add(archivo, 0, 0);
            filaArchivo.Controls.Add(buscar, 1, 0);
            Agregar(tabla, 3, "O cargar familia .rfa", filaArchivo);
            buscar.Click += delegate
            {
                using (var dialogo = new Forms.OpenFileDialog
                {
                    Filter = "Familia de Revit (*.rfa)|*.rfa",
                    Title = "Selecciona la familia de ladrillo",
                    CheckFileExists = true,
                    Multiselect = false
                })
                    if (dialogo.ShowDialog(this) == Forms.DialogResult.OK)
                    {
                        archivo.Text = dialogo.FileName;
                        tipos.SelectedIndex = 0;
                    }
            };
            tipos.SelectedIndexChanged += delegate { filaArchivo.Enabled = tipos.SelectedIndex == 0; };
            filaArchivo.Enabled = tipos.SelectedIndex == 0;

            AgregarSeccion(tabla, 4, "2. Distribución y altura");
            Agregar(tabla, 5, "Ancho libre de vigueta entre filas (cm)", vigueta);
            Agregar(tabla, 6, "Junta entre ladrillos de una fila (cm)", junta);
            Agregar(tabla, 7, "Margen libre a bordes y huecos (cm)", margen);
            ajustarBase.Text = "Ajustar la base al intradós de la losa";
            ajustarBase.AutoSize = true;
            ajustarBase.Checked = false;
            Agregar(tabla, 8, "Altura de familias hospedadas", ajustarBase);
            Agregar(tabla, 9, "Desfase sobre intradós (cm, con ajuste)", desfase);
            // Sin ajuste, una familia hospedada conserva su colocación vertical
            // propia, igual que al insertarla manualmente sobre el suelo.
            // Una familia sin anfitrión utiliza siempre el ajuste al intradós.
            Action actualizarDesfase = delegate
            {
                var opcion = tipos.SelectedItem as OpcionTipo;
                desfase.Enabled = ajustarBase.Checked || (opcion != null && !opcion.Hospedado && opcion.Id != null);
            };
            ajustarBase.CheckedChanged += delegate { actualizarDesfase(); };
            tipos.SelectedIndexChanged += delegate { actualizarDesfase(); };
            actualizarDesfase();
            giro.Text = "Girar familia 90° respecto a la fila";
            giro.AutoSize = true;
            Agregar(tabla, 10, "Orientación de la familia", giro);

            AgregarSeccion(tabla, 11, "3. Encuentros con otros elementos");
            unirElementos.Text = "Unir elementos intersecantes";
            unirElementos.AutoSize = true;
            unirElementos.Checked = false;
            unirElementos.Font = new Font(Font, FontStyle.Bold);
            unirElementos.ForeColor = System.Drawing.Color.FromArgb(18, 78, 120);
            unirElementos.BackColor = System.Drawing.Color.FromArgb(238, 246, 252);
            Agregar(tabla, 12, "Unión con elementos vecinos", unirElementos);

            encuentros.DropDownStyle = Forms.ComboBoxStyle.DropDownList;
            encuentros.DisplayMember = "Etiqueta";
            encuentros.Items.Add(new OpcionEncuentro(ModoEncuentroLadrillos.SoloDetectar,
                "Solo detectar (conserva conflictos)"));
            encuentros.Items.Add(new OpcionEncuentro(ModoEncuentroLadrillos.Omitir,
                "Omitir piezas en conflicto"));
            encuentros.Items.Add(new OpcionEncuentro(ModoEncuentroLadrillos.Unir,
                "Unir: vecino recorta ladrillo"));
            encuentros.Items.Add(new OpcionEncuentro(ModoEncuentroLadrillos.Cortar,
                "Cortar ladrillo con vecino"));
            encuentros.SelectedIndex = 1;
            Agregar(tabla, 13, "Modo de resolución (avanzado)", encuentros);
            encuentros.SelectedIndexChanged += delegate { SincronizarUnionDesdeModo(); };
            unirElementos.CheckedChanged += delegate
            {
                if (sincronizandoEncuentros) return;
                var actual = encuentros.SelectedItem as OpcionEncuentro;
                if (unirElementos.Checked)
                {
                    if (actual != null && actual.Modo != ModoEncuentroLadrillos.Unir)
                        ultimoModoSinUnion = actual.Modo;
                    SeleccionarModo(ModoEncuentroLadrillos.Unir);
                }
                else if (actual != null && actual.Modo == ModoEncuentroLadrillos.Unir)
                    SeleccionarModo(ultimoModoSinUnion);
            };
            SincronizarUnionDesdeModo();
            seleccionarVecinos.Text = "Seleccionar manualmente los elementos vecinos";
            seleccionarVecinos.AutoSize = true;
            seleccionarVecinos.Checked = false;
            Agregar(tabla, 14, "Elementos a comprobar", seleccionarVecinos);

            var nota = new Forms.Label
            {
                Dock = Forms.DockStyle.Top,
                AutoSize = true,
                Text = "Después, selecciona una losa horizontal en planta y marca dos puntos. " +
                    "El primero fija una esquina de la malla; el segundo indica la dirección de las filas/viguetas. " +
                    "Se abrirá una previsualización 2D donde puedes ampliar, mover filas o paños, excluir piezas " +
                    "y revisar el modo de encuentros antes de crear.\r\n\r\n" +
                    "Las familias hospedadas conservan por defecto su altura de colocación manual. " +
                    "Activa el ajuste solo si quieres llevar su base al intradós. " +
                    "Las familias sin anfitrión se ajustan siempre al intradós. " +
                    "Se distribuyen piezas dentro del contorno, sin cruzar huecos.\r\n\r\n" +
                    "Sin selección manual se comprueban vigas, columnas, muros, cimentaciones, otros suelos " +
                    "y modelos genéricos cercanos del documento actual. La losa anfitriona se excluye; " +
                    "los elementos de vínculos no se unen ni se cortan.\r\n\r\n" +
                    "Unir y cortar dependen de las operaciones que Revit admita para cada pareja. " +
                    "Si no se admite la operación o queda interferencia, se omite el ladrillo y se preserva " +
                    "el vecino. Solo detectar conserva los conflictos y no los resuelve.",
                Padding = new Forms.Padding(0, 8, 0, 0)
            };
            tabla.Controls.Add(nota, 0, 15);
            tabla.SetColumnSpan(nota, 2);
            Action ajustarNota = delegate
            {
                nota.MaximumSize = new Size(Math.Max(320, tabla.ClientSize.Width - tabla.Padding.Horizontal - 8), 0);
            };
            tabla.SizeChanged += delegate { ajustarNota(); };
            ajustarNota();
            var continuar = new Forms.Button { Text = "Previsualizar", AutoSize = true, MinimumSize = new Size(118, 30) };
            var cancelar = new Forms.Button { Text = "Cancelar", DialogResult = Forms.DialogResult.Cancel, AutoSize = true };
            botones.Controls.Add(cancelar);
            botones.Controls.Add(continuar);
            AcceptButton = continuar;
            CancelButton = cancelar;
            continuar.Click += delegate { Aceptar(); };
        }

        private void Aceptar()
        {
            var elegido = tipos.SelectedItem as OpcionTipo;
            if (elegido == null || (elegido.Id == null && !System.IO.File.Exists(archivo.Text)))
            {
                Forms.MessageBox.Show(this, "Selecciona un tipo cargado o un archivo .rfa válido.", Text,
                    Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Information);
                return;
            }
            Opciones = new LadrillosLosaOpciones
            {
                TipoId = elegido.Id,
                ArchivoFamilia = elegido.Id == null ? archivo.Text : null,
                ViguetaCm = (double)vigueta.Value,
                JuntaCm = (double)junta.Value,
                MargenCm = (double)margen.Value,
                DesfaseBaseCm = (double)desfase.Value,
                Girar90 = giro.Checked,
                AjustarBaseAlIntrados = ajustarBase.Checked,
                ModoEncuentros = ((OpcionEncuentro)encuentros.SelectedItem).Modo,
                SeleccionarVecinos = seleccionarVecinos.Checked
            };
            DialogResult = Forms.DialogResult.OK;
            Close();
        }

        private static Forms.NumericUpDown Numero(decimal inicial, decimal maximo)
        {
            return new Forms.NumericUpDown { Minimum = 0, Maximum = maximo, DecimalPlaces = 2, Increment = 0.5M, Value = inicial };
        }

        private void SeleccionarModo(ModoEncuentroLadrillos modo)
        {
            for (int i = 0; i < encuentros.Items.Count; i++)
                if (((OpcionEncuentro)encuentros.Items[i]).Modo == modo)
                {
                    encuentros.SelectedIndex = i;
                    return;
                }
        }

        private void SincronizarUnionDesdeModo()
        {
            if (sincronizandoEncuentros) return;
            var opcion = encuentros.SelectedItem as OpcionEncuentro;
            if (opcion == null) return;
            sincronizandoEncuentros = true;
            try
            {
                unirElementos.Checked = opcion.Modo == ModoEncuentroLadrillos.Unir;
                if (!unirElementos.Checked) ultimoModoSinUnion = opcion.Modo;
            }
            finally { sincronizandoEncuentros = false; }
        }

        private void AgregarSeccion(Forms.TableLayoutPanel tabla, int fila, string texto)
        {
            var seccion = new Forms.Label
            {
                Text = texto,
                AutoSize = true,
                Dock = Forms.DockStyle.Fill,
                Font = new Font(Font, FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(18, 78, 120),
                Margin = new Forms.Padding(3, 16, 3, 5)
            };
            tabla.Controls.Add(seccion, 0, fila);
            tabla.SetColumnSpan(seccion, 2);
        }

        private static void Agregar(Forms.TableLayoutPanel tabla, int fila, string etiqueta, Forms.Control control)
        {
            tabla.Controls.Add(new Forms.Label
            {
                Text = etiqueta,
                AutoSize = true,
                Dock = Forms.DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                MinimumSize = new Size(0, 32),
                Margin = new Forms.Padding(3, 4, 8, 4)
            }, 0, fila);
            control.Dock = Forms.DockStyle.Fill;
            control.Margin = new Forms.Padding(3, 6, 3, 6);
            tabla.Controls.Add(control, 1, fila);
        }

        private sealed class OpcionEncuentro
        {
            internal ModoEncuentroLadrillos Modo { get; private set; }
            public string Etiqueta { get; private set; }
            internal OpcionEncuentro(ModoEncuentroLadrillos modo, string etiqueta)
            { Modo = modo; Etiqueta = etiqueta; }
        }

        private sealed class OpcionTipo
        {
            internal ElementId Id { get; private set; }
            internal bool Hospedado { get; private set; }
            public string Etiqueta { get; private set; }
            internal OpcionTipo(ElementId id, string etiqueta, bool hospedado = true)
            { Id = id; Etiqueta = etiqueta; Hospedado = hospedado; }
        }

        internal static Media.ImageSource CrearIcono()
        {
            var dibujo = new Media.DrawingGroup();
            var borde = new Media.Pen(Media.Brushes.SaddleBrown, 0.8);
            for (int fila = 0; fila < 3; fila++)
                for (int col = 0; col < 2; col++)
                {
                    double x = 2 + col * 16, y = 2 + fila * 10;
                    dibujo.Children.Add(new Media.GeometryDrawing(Media.Brushes.SandyBrown, borde,
                        new Media.RectangleGeometry(new System.Windows.Rect(x, y, 12, 7), 1, 1)));
                    for (int hueco = 0; hueco < 3; hueco++)
                        dibujo.Children.Add(new Media.GeometryDrawing(Media.Brushes.SaddleBrown, null,
                            new Media.RectangleGeometry(new System.Windows.Rect(x + 2 + hueco * 3, y + 2, 1.5, 3))));
                }
            dibujo.Freeze();
            var imagen = new Media.DrawingImage(dibujo);
            imagen.Freeze();
            return imagen;
        }
    }
}
