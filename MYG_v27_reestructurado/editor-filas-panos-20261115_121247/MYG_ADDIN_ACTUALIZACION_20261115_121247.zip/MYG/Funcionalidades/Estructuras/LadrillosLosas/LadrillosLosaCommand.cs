using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Forms = System.Windows.Forms;

namespace MYG_Addin
{
    [Transaction(TransactionMode.Manual)]
    public class LadrillosLosaCommand : IExternalCommand
    {
        private const double Tolerancia = 1e-6; // pies; solo comparación, no desplaza el contorno.
        private const int MaxCandidatos = 100000;
        private const int MaxLadrillos = 10000;

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            if (!MYG_ControlAccesoComandos.Comprobar()) return Result.Cancelled;
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            if (uidoc == null || uidoc.Document.IsFamilyDocument || uidoc.Document.IsReadOnly)
            {
                TaskDialog.Show("MYG · Ladrillos en losa", "Abre un proyecto editable de Revit.");
                return Result.Cancelled;
            }
            Document doc = uidoc.Document;
            ViewPlan planta = doc.ActiveView as ViewPlan;
            if (planta == null || planta.IsTemplate || planta.GenLevel == null ||
                (planta.ViewType != ViewType.FloorPlan && planta.ViewType != ViewType.EngineeringPlan))
            {
                TaskDialog.Show("MYG · Ladrillos en losa",
                    "Ejecuta el comando desde una planta de piso o planta estructural con nivel. " +
                    "Los dos puntos se marcan en el plano de trabajo de esa vista.");
                return Result.Cancelled;
            }
            try
            {
                var tipos = new FilteredElementCollector(doc).OfClass(typeof(FamilySymbol))
                    .Cast<FamilySymbol>().Where(TipoAdmitido).OrderBy(x => x.FamilyName)
                    .ThenBy(x => x.Name).ToList();
                LadrillosLosaOpciones opciones;
                using (var form = new LadrillosLosaForm(tipos))
                {
                    if (form.ShowDialog() != Forms.DialogResult.OK) return Result.Cancelled;
                    opciones = form.Opciones;
                }
                ValidarOpciones(opciones);
                Reference referencia = uidoc.Selection.PickObject(ObjectType.Element, new FiltroSuelo(),
                    "Selecciona la losa (suelo) horizontal donde colocar los ladrillos");
                Floor suelo = (Floor)doc.GetElement(referencia.ElementId);
                var datosSuelo = LeerSuelo(suelo);
                IList<ElementId> vecinosElegidos = null;
                if (opciones.SeleccionarVecinos)
                {
                    vecinosElegidos = uidoc.Selection.PickObjects(ObjectType.Element,
                        new FiltroVecinos(suelo.Id), "Selecciona los elementos vecinos que deben respetar los ladrillos; pulsa Finalizar")
                        .Select(x => x.ElementId).Distinct().ToList();
                    if (vecinosElegidos.Count == 0)
                        throw new InvalidOperationException("Selecciona al menos un vecino o utiliza la búsqueda automática.");
                }
                XYZ primero = uidoc.Selection.PickPoint("Marca el origen de la malla (esquina del primer módulo)");
                XYZ segundo = uidoc.Selection.PickPoint("Marca otro punto en la dirección de las viguetas / filas");
                XYZ diferencia = new XYZ(segundo.X - primero.X, segundo.Y - primero.Y, 0);
                if (diferencia.GetLength() < 0.00328084)
                    throw new InvalidOperationException("Los puntos de dirección deben separarse al menos 1 mm en planta.");
                var marco = new Marco(primero, diferencia.Normalize());
                List<IList<LadrilloPunto>> contornos = Contornos(datosSuelo.CarasSuperiores, marco);
                Level nivel = doc.GetElement(suelo.LevelId) as Level;
                if (nivel == null) throw new InvalidOperationException("No se pudo obtener el nivel de la losa.");
                int creados = 0, omitidosSolido = 0, omitidosExistentes = 0;
                double largo = 0, ancho = 0, alto = 0;
                int excluidosVista = 0, omitidosEncuentros = 0, uniones = 0, cortes = 0, pendientes = 0;
                int vecinosRevisados = 0;
                var detallesEncuentros = new List<string>();
                ModoEncuentroLadrillos modoFinal = opciones.ModoEncuentros;
                using (var grupo = new TransactionGroup(doc, "MYG · Ladrillos en losa"))
                {
                    if (grupo.Start() != TransactionStatus.Started)
                        throw new InvalidOperationException("No se pudo iniciar el grupo de transacciones.");
                    try
                    {
                        FamilySymbol tipo = ResolverTipo(doc, opciones);
                        if (tipo == null) return Result.Cancelled;
                        if (!TipoAdmitido(tipo))
                            throw new InvalidOperationException("La familia debe ser un componente basado en nivel " +
                                "sin anfitrión o con anfitrión Suelo. No se admiten familias por cara, " +
                                "plano de trabajo, muro, techo, línea ni adaptativas.");
                        bool hospedado = tipo.Family.FamilyPlacementType == FamilyPlacementType.OneLevelBasedHosted;
                        bool ajustarBase = !hospedado || opciones.AjustarBaseAlIntrados;
                        using (var tx = new Transaction(doc, "Colocar ladrillos"))
                        {
                            if (tx.Start() != TransactionStatus.Started)
                                throw new InvalidOperationException("No se pudo iniciar la colocación.");
                            var fallos = new FallosColocacion();
                            tx.SetFailureHandlingOptions(tx.GetFailureHandlingOptions()
                                .SetClearAfterRollback(true).SetForcedModalHandling(true)
                                .SetFailuresPreprocessor(fallos));
                            if (!tipo.IsActive) tipo.Activate();
                            doc.Regenerate();
                            double baseDeseada = 0, desfaseU = 0, desfaseV = 0;
                            double angulo = Math.Atan2(marco.U.Y, marco.U.X) + (opciones.Girar90 ? Math.PI / 2 : 0);
                            // La pieza de medida se revierte por completo ANTES de tomar
                            // snapshots de vecinos: sus efectos de hospedaje no son baseline.
                            using (var sonda = new SubTransaction(doc))
                            {
                                if (sonda.Start() != TransactionStatus.Started)
                                    throw new InvalidOperationException("No se pudo iniciar la medición temporal.");
                                FamilyInstance plantilla = Crear(doc, tipo, suelo, nivel, datosSuelo.Semilla, hospedado);
                                doc.Regenerate();
                                Orientar(doc, plantilla, angulo);
                                doc.Regenerate();
                                Caja caja = Medir(plantilla, marco);
                                largo = caja.MaxU - caja.MinU;
                                ancho = caja.MaxV - caja.MinV;
                                alto = caja.MaxZ - caja.MinZ;
                                if (largo <= Tolerancia || ancho <= Tolerancia || alto <= Tolerancia)
                                    throw new InvalidOperationException("La familia no contiene un sólido tridimensional medible.");
                                // Una familia hospedada conserva por defecto la elevación que
                                // resuelve Revit al insertarla sobre el suelo, como al colocarla a mano.
                                baseDeseada = LadrillosAltura.CalcularBase(hospedado,
                                    opciones.AjustarBaseAlIntrados, caja.MinZ, datosSuelo.Inferior,
                                    datosSuelo.Superior, alto, Pies(opciones.DesfaseBaseCm));
                                if (ajustarBase)
                                {
                                    ElementTransformUtils.MoveElement(doc, plantilla.Id,
                                        XYZ.BasisZ.Multiply(baseDeseada - caja.MinZ));
                                    doc.Regenerate();
                                    caja = Medir(plantilla, marco);
                                    if (Math.Abs(caja.MinZ - baseDeseada) > Tolerancia)
                                        throw new InvalidOperationException("El anfitrión o las restricciones de la familia " +
                                            "impiden ajustar su base al intradós. No se ha colocado ningún ladrillo.");
                                    // La geometría puede responder al desfase sobre su anfitrión.
                                    // La malla y la validación deben usar las medidas posteriores
                                    // a ese ajuste, no las de la plantilla antes de moverla.
                                    largo = caja.MaxU - caja.MinU;
                                    ancho = caja.MaxV - caja.MinV;
                                    alto = caja.MaxZ - caja.MinZ;
                                    if (largo <= Tolerancia || ancho <= Tolerancia || alto <= Tolerancia)
                                        throw new InvalidOperationException("La familia no contiene un sólido tridimensional medible después del ajuste.");
                                    baseDeseada = LadrillosAltura.CalcularBase(hospedado,
                                        opciones.AjustarBaseAlIntrados, caja.MinZ, datosSuelo.Inferior,
                                        datosSuelo.Superior, alto, Pies(opciones.DesfaseBaseCm));
                                }
                                LocationPoint ubicacionPlantilla = plantilla.Location as LocationPoint;
                                if (ubicacionPlantilla == null)
                                    throw new InvalidOperationException("La familia no tiene un punto de inserción compatible.");
                                LadrilloPunto insercionPlantilla = marco.Proyectar(ubicacionPlantilla.Point);
                                desfaseU = (caja.MinU + caja.MaxU) / 2 - insercionPlantilla.X;
                                desfaseV = (caja.MinV + caja.MaxV) / 2 - insercionPlantilla.Y;
                                if (sonda.RollBack() != TransactionStatus.RolledBack)
                                    throw new InvalidOperationException("No se pudo retirar la pieza temporal de medición.");
                            }
                            doc.Regenerate();
                            var posiciones = LadrillosLayout.Generar(contornos, new LadrilloPunto(0, 0),
                                largo, ancho, Pies(opciones.JuntaCm), Pies(opciones.ViguetaCm),
                                Pies(opciones.MargenCm), MaxCandidatos, MaxLadrillos);
                            var existentes = LeerExistentes(doc, tipo, ElementId.InvalidElementId, marco, largo, ancho);
                            var aceptadas = new List<LadrilloPunto>();
                            IList<ElementId> objetivos = BuscarVecinos(doc, suelo, tipo, ElementId.InvalidElementId,
                                vecinosElegidos, baseDeseada, alto);
                            using (var interferencias = new LadrillosInterferencias(doc, suelo.Id, objetivos))
                            {
                                vecinosRevisados = interferencias.Objetivos.Count;
                                foreach (LadrilloPunto centro in posiciones)
                                {
                                    if (!HuellaDentroDelSuelo(datosSuelo.Solidos, marco, centro,
                                        largo + 2 * Pies(opciones.MargenCm), ancho + 2 * Pies(opciones.MargenCm),
                                        datosSuelo.Inferior, datosSuelo.Superior - datosSuelo.Inferior))
                                    {
                                        omitidosSolido++;
                                        continue;
                                    }
                                    var candidato = new Caja(centro.X - largo / 2, centro.X + largo / 2,
                                        centro.Y - ancho / 2, centro.Y + ancho / 2, baseDeseada, baseDeseada + alto);
                                    if (existentes.Intersecta(candidato))
                                    {
                                        omitidosExistentes++;
                                        continue;
                                    }
                                    aceptadas.Add(centro);
                                }
                                if (aceptadas.Count == 0)
                                {
                                    TaskDialog.Show("MYG · Ladrillos en losa",
                                        "No hay posiciones libres para ladrillos completos con esta configuración.\n\n" +
                                        "Omitidos por geometría real del suelo: " + omitidosSolido +
                                        ".\nOmitidos por superposición con la misma familia: " + omitidosExistentes +
                                        ".\nRevisa origen, tipo, giro, margen y separaciones.");
                                    return Result.Cancelled;
                                }
                                var piezasVista = aceptadas.Select(x => new LadrilloVista { Centro = x }).ToList();
                                var cacheVista = new Dictionary<int, ComprobacionVista>();
                                Action<IList<LadrilloEditable>> actualizarEncuentros = piezas =>
                                {
                                    // Cada edición es una evaluación independiente. Las posiciones
                                    // que no cambiaron reutilizan su comprobación de vecinos.
                                    interferencias.IniciarEvaluacion();
                                    foreach (LadrilloEditable pieza in piezas)
                                    {
                                        pieza.Interfiere = false;
                                        pieza.Obstaculos = 0;
                                        if (!pieza.Incluir) continue;
                                        ComprobacionVista dato;
                                        if (!cacheVista.TryGetValue(pieza.Id, out dato) ||
                                            dato.Centro.X != pieza.Centro.X || dato.Centro.Y != pieza.Centro.Y)
                                        {
                                            bool dentro = !pieza.FueraContorno && HuellaDentroDelSuelo(datosSuelo.Solidos,
                                                marco, pieza.Centro, largo + 2 * Pies(opciones.MargenCm),
                                                ancho + 2 * Pies(opciones.MargenCm), datosSuelo.Inferior,
                                                datosSuelo.Superior - datosSuelo.Inferior);
                                            var cajaEditada = new Caja(pieza.Centro.X - largo / 2, pieza.Centro.X + largo / 2,
                                                pieza.Centro.Y - ancho / 2, pieza.Centro.Y + ancho / 2,
                                                baseDeseada, baseDeseada + alto);
                                            int cruces = dentro ? interferencias.GetConflictosHuella(marco.Origen,
                                                marco.U, marco.V, pieza.Centro, largo, ancho, baseDeseada, alto).Count : 0;
                                            dato = new ComprobacionVista { Centro = pieza.Centro, Dentro = dentro,
                                                SolapaExistente = existentes.Intersecta(cajaEditada), Encuentros = cruces };
                                            cacheVista[pieza.Id] = dato;
                                        }
                                        pieza.FueraContorno |= !dato.Dentro;
                                        pieza.SeSolapa |= dato.SolapaExistente;
                                        pieza.Obstaculos = dato.Encuentros;
                                        pieza.Interfiere = dato.Encuentros > 0;
                                    }
                                };
                                string resumen = "Familia: " + tipo.FamilyName + " / " + tipo.Name +
                                    "\r\nHuella: " + Cm(largo) + " × " + Cm(ancho) + " cm; altura: " + Cm(alto) +
                                    " cm.\r\nVigueta inicial: " + opciones.ViguetaCm.ToString("0.###") +
                                    " cm; junta inicial: " + opciones.JuntaCm.ToString("0.###") +
                                    " cm.\r\n" + (ajustarBase ? "Base ajustada al intradós." : "Elevación propia de la familia hospedada.") +
                                    "\r\nVecinos con sólidos: " + vecinosRevisados + ".";
                                using (var vista = new LadrillosPreviewForm(contornos, piezasVista, largo, ancho,
                                    HuellasVecinos(doc, interferencias.Objetivos, marco), resumen, opciones.ModoEncuentros,
                                    Pies(opciones.MargenCm), Pies(opciones.JuntaCm), Pies(opciones.ViguetaCm), actualizarEncuentros))
                                {
                                    if (vista.ShowDialog() != Forms.DialogResult.OK) return Result.Cancelled;
                                    modoFinal = vista.ModoSeleccionado;
                                    List<LadrilloPunto> elegidas = vista.Seleccionadas;
                                    excluidosVista = aceptadas.Count - elegidas.Count;
                                    aceptadas = elegidas;
                                }
                                if (aceptadas.Count == 0) return Result.Cancelled;
                                // No confiar únicamente en el estado del formulario: las filas
                                // editadas vuelven a comprobarse antes de crear el lote real.
                                var comprobacionFinal = new LadrillosEditor(contornos, aceptadas, largo, ancho,
                                    Pies(opciones.MargenCm), Pies(opciones.JuntaCm), Pies(opciones.ViguetaCm));
                                if (!comprobacionFinal.PuedeCrear)
                                    throw new InvalidOperationException("La distribución editada contiene piezas fuera del contorno o solapadas. " +
                                        "Corrige los ajustes en la previsualización antes de crear.");
                                foreach (LadrilloPunto centro in aceptadas)
                                {
                                    if (!HuellaDentroDelSuelo(datosSuelo.Solidos, marco, centro,
                                        largo + 2 * Pies(opciones.MargenCm), ancho + 2 * Pies(opciones.MargenCm),
                                        datosSuelo.Inferior, datosSuelo.Superior - datosSuelo.Inferior))
                                        throw new InvalidOperationException("Una pieza editada sale del sólido real de la losa o invade un hueco.");
                                    if (existentes.Intersecta(new Caja(centro.X - largo / 2, centro.X + largo / 2,
                                        centro.Y - ancho / 2, centro.Y + ancho / 2, baseDeseada, baseDeseada + alto)))
                                        throw new InvalidOperationException("Una pieza editada se solapa con un ladrillo existente de la misma familia.");
                                }
                                interferencias.IniciarEvaluacion();
                                // Compensación física medida en la sonda ya revertida.
                                var colocaciones = new List<KeyValuePair<ElementId, LadrilloPunto>>();
                                foreach (LadrilloPunto centro in aceptadas)
                                {
                                    XYZ puntoInsercion = marco.Punto(centro.X - desfaseU,
                                        centro.Y - desfaseV, datosSuelo.Semilla.Z);
                                    // Crear cada pieza sobre el anfitrión: no copiar una instancia
                                    // ya hospedada ni imponer un nivel distinto al que resuelve Revit.
                                    FamilyInstance instancia = Crear(doc, tipo, suelo, nivel, puntoInsercion, hospedado);
                                    Orientar(doc, instancia, angulo);
                                    colocaciones.Add(new KeyValuePair<ElementId, LadrilloPunto>(instancia.Id, centro));
                                }
                                doc.Regenerate();
                                var correcciones = new Dictionary<ElementId, XYZ>();
                                foreach (var colocacion in colocaciones)
                                {
                                    FamilyInstance instancia = doc.GetElement(colocacion.Key) as FamilyInstance;
                                    if (instancia == null)
                                        throw new InvalidOperationException("Revit no conservó una instancia creada.");
                                    Caja real = Medir(instancia, marco);
                                    var correccion = LadrillosAlineacion.CalcularCorreccion(colocacion.Value,
                                        new LadrilloPunto((real.MinU + real.MaxU) / 2, (real.MinV + real.MaxV) / 2),
                                        real.MinZ, baseDeseada, ajustarBase);
                                    XYZ mover = marco.U.Multiply(correccion.U) + marco.V.Multiply(correccion.V) +
                                        XYZ.BasisZ.Multiply(correccion.Z);
                                    if (Math.Abs(correccion.U) > Tolerancia || Math.Abs(correccion.V) > Tolerancia ||
                                        Math.Abs(correccion.Z) > Tolerancia)
                                    {
                                        ElementTransformUtils.MoveElement(doc, instancia.Id, mover);
                                        correcciones.Add(colocacion.Key, mover);
                                    }
                                    else correcciones.Add(colocacion.Key, XYZ.Zero);
                                }
                                // Medir cada centro físico evita depender del desfase de una
                                // única plantilla. En modo nativo la corrección Z es siempre cero.
                                doc.Regenerate();
                                foreach (var colocacion in colocaciones)
                                {
                                    FamilyInstance instancia = doc.GetElement(colocacion.Key) as FamilyInstance;
                                    if (instancia == null || (hospedado &&
                                        (instancia.Host == null || !instancia.Host.Id.Equals(suelo.Id))))
                                        throw new InvalidOperationException("Una instancia perdió el anfitrión Suelo. Se revierte la colocación.");
                                    Caja real = Medir(instancia, marco);
                                    List<string> diferencias = DescribirDiferencias(real, colocacion.Value,
                                        baseDeseada, datosSuelo.Superior, largo, ancho, alto, ajustarBase);
                                    if (diferencias.Count > 0)
                                    {
                                        XYZ aplicada = correcciones[colocacion.Key];
                                        throw new InvalidOperationException("Verificación geométrica no coincidente.\n" +
                                            "Suelo ID: " + suelo.Id + "; instancia ID: " + instancia.Id + ".\n" +
                                            "Familia/tipo: " + tipo.FamilyName + " / " + tipo.Name + ".\n" +
                                            "Modo: " + (ajustarBase ? "ajuste al intradós" : "elevación nativa hospedada") + ".\n" +
                                            "Tolerancia: " + Mm(Tolerancia) + " mm.\n" +
                                            string.Join("\n", diferencias) + "\n" +
                                            "Corrección aplicada XYZ (mm): " + Mm(aplicada.X) + "; " +
                                            Mm(aplicada.Y) + "; " + Mm(aplicada.Z) + ".\n" +
                                            "Se revierte toda la operación; no se conserva esta colocación.");
                                    }
                                }
                                // Las comprobaciones de alineación anteriores se realizan ANTES
                                // del encuentro: un recorte admitido cambia deliberadamente la pieza.
                                var conservadas = new Dictionary<ElementId, ResultadoEncuentroLadrillos>();
                                foreach (var colocacion in colocaciones)
                                {
                                    FamilyInstance instancia = doc.GetElement(colocacion.Key) as FamilyInstance;
                                    if (instancia == null) throw new InvalidOperationException("No se encontró una pieza para verificar encuentros.");
                                    ResultadoEncuentroLadrillos resultado = interferencias.Resolver(instancia, modoFinal);
                                    if (!resultado.Conservar)
                                    {
                                        if (doc.GetElement(colocacion.Key) != null)
                                        {
                                            doc.Delete(colocacion.Key);
                                            doc.Regenerate();
                                        }
                                        omitidosEncuentros++;
                                        foreach (string detalle in resultado.Diagnosticos)
                                            if (detallesEncuentros.Count < 12) detallesEncuentros.Add("Ladrillo " + colocacion.Key + ": " + detalle);
                                    }
                                    else conservadas.Add(colocacion.Key, resultado);
                                }
                                doc.Regenerate();
                                // Una relación de unión/corte por sí sola no acredita resolución.
                                // Comprobar de nuevo el conjunto final contra los vecinos reales.
                                foreach (var par in conservadas)
                                {
                                    Element pieza = doc.GetElement(par.Key);
                                    if (pieza == null) throw new InvalidOperationException("Revit eliminó una pieza durante los encuentros.");
                                    List<ElementId> restantes = interferencias.DetectarFinal(pieza);
                                    if (modoFinal != ModoEncuentroLadrillos.SoloDetectar && restantes.Count > 0)
                                        throw new InvalidOperationException("Persisten interferencias en el ladrillo ID " + par.Key +
                                            " con los elementos " + string.Join(", ", restantes.Select(x => x.ToString())) +
                                            ". Se revierte la operación completa.");
                                    pendientes += restantes.Count;
                                    uniones += par.Value.Uniones;
                                    cortes += par.Value.Cortes;
                                }
                                interferencias.VerificarObjetivosSinCambios();
                                if (conservadas.Count == 0)
                                {
                                    TaskDialog.Show("MYG · Ladrillos en losa", "Todas las piezas seleccionadas se omitieron por encuentros. " +
                                        "No se conserva ninguna colocación.\n\n" + string.Join("\n", detallesEncuentros));
                                    return Result.Cancelled;
                                }
                                TransactionStatus estado = tx.Commit();
                                if (estado != TransactionStatus.Committed)
                                    throw new InvalidOperationException("Revit no confirmó la colocación. " + fallos.Descripcion);
                                creados = conservadas.Count;
                            }
                        }
                        if (grupo.Assimilate() != TransactionStatus.Committed)
                            throw new InvalidOperationException("Revit no confirmó el grupo de colocación.");
                    }
                    finally
                    {
                        if (grupo.GetStatus() == TransactionStatus.Started) grupo.RollBack();
                    }
                }
                var informe = new TaskDialog("MYG · Ladrillos en losa")
                {
                    MainInstruction = "Se crearon " + creados + " ladrillos",
                    MainContent = "Huella inicial: " + Cm(largo) + " × " + Cm(ancho) + " cm; altura: " + Cm(alto) +
                        " cm.\nOmitidos por contorno: " + omitidosSolido + "; por solapamiento con la misma familia: " +
                        omitidosExistentes + ".\nExcluidos en previsualización: " + excluidosVista +
                        "; omitidos por encuentros: " + omitidosEncuentros + ".\nVecinos revisados: " + vecinosRevisados +
                        "; uniones comprobadas: " + uniones + "; cortes comprobados: " + cortes + ".\n" +
                        (modoFinal == ModoEncuentroLadrillos.SoloDetectar
                            ? "Solo detectar: se conservan " + pendientes + " pares con interferencia."
                            : "Sin volumen común detectado con los vecinos incluidos en esta revisión.") +
                        "\nPuedes deshacer toda la operación en un solo paso.",
                    ExpandedContent = string.Join("\n", detallesEncuentros)
                };
                informe.Show();
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                // Result.Failed muestra este mensaje en Revit. No abrir antes otro
                // TaskDialog con el mismo error: produciría dos avisos para un fallo.
                return Result.Failed;
            }
        }

        private sealed class ComprobacionVista
        {
            internal LadrilloPunto Centro;
            internal bool Dentro;
            internal bool SolapaExistente;
            internal int Encuentros;
        }

        private static IList<ElementId> BuscarVecinos(Document doc, Floor suelo, FamilySymbol tipo,
            ElementId plantilla, IList<ElementId> elegidos, double baseZ, double alto)
        {
            IEnumerable<Element> elementos;
            if (elegidos != null) elementos = elegidos.Select(doc.GetElement);
            else
            {
                BoundingBoxXYZ caja = suelo.get_BoundingBox(null);
                if (caja == null) throw new InvalidOperationException("No se obtuvo la extensión de la losa para buscar vecinos.");
                double margen = 1.0 / 304.8; // 1 mm de descarte de cajas; no altera el modelo.
                var puntos = new List<XYZ>();
                for (int i = 0; i < 8; i++)
                    puntos.Add(caja.Transform.OfPoint(new XYZ((i & 1) == 0 ? caja.Min.X : caja.Max.X,
                        (i & 2) == 0 ? caja.Min.Y : caja.Max.Y, (i & 4) == 0 ? caja.Min.Z : caja.Max.Z)));
                var categorias = new List<BuiltInCategory> { BuiltInCategory.OST_Walls,
                    BuiltInCategory.OST_StructuralFraming, BuiltInCategory.OST_StructuralColumns,
                    BuiltInCategory.OST_Columns, BuiltInCategory.OST_StructuralFoundation,
                    BuiltInCategory.OST_Floors, BuiltInCategory.OST_Roofs, BuiltInCategory.OST_GenericModel };
                using (var contorno = new Outline(new XYZ(puntos.Min(x => x.X) - margen, puntos.Min(x => x.Y) - margen,
                    Math.Min(puntos.Min(x => x.Z), baseZ) - margen),
                    new XYZ(puntos.Max(x => x.X) + margen, puntos.Max(x => x.Y) + margen,
                    Math.Max(puntos.Max(x => x.Z), baseZ + alto) + margen)))
                {
                    elementos = new FilteredElementCollector(doc).WhereElementIsNotElementType()
                        .WherePasses(new ElementMulticategoryFilter(categorias))
                        .WherePasses(new BoundingBoxIntersectsFilter(contorno)).ToElements();
                }
            }
            return elementos.Where(x => x != null && !(x is ElementType) && !(x is RevitLinkInstance) &&
                !x.Id.Equals(suelo.Id) && !x.Id.Equals(plantilla) &&
                !(x is FamilyInstance && ((FamilyInstance)x).Symbol.Family.Id.Equals(tipo.Family.Id)))
                .Select(x => x.Id).Distinct().ToList();
        }

        private static IList<IList<LadrilloPunto>> HuellasVecinos(Document doc, IList<ElementId> ids, Marco marco)
        {
            var huellas = new List<IList<LadrilloPunto>>();
            foreach (ElementId id in ids)
            {
                Element elemento = doc.GetElement(id);
                BoundingBoxXYZ caja = elemento == null ? null : elemento.get_BoundingBox(null);
                if (caja == null) continue;
                var puntos = new List<LadrilloPunto>();
                for (int i = 0; i < 8; i++)
                    puntos.Add(marco.Proyectar(caja.Transform.OfPoint(new XYZ((i & 1) == 0 ? caja.Min.X : caja.Max.X,
                        (i & 2) == 0 ? caja.Min.Y : caja.Max.Y, (i & 4) == 0 ? caja.Min.Z : caja.Max.Z))));
                double minU = puntos.Min(x => x.X), maxU = puntos.Max(x => x.X);
                double minV = puntos.Min(x => x.Y), maxV = puntos.Max(x => x.Y);
                huellas.Add(new List<LadrilloPunto> { new LadrilloPunto(minU, minV), new LadrilloPunto(maxU, minV),
                    new LadrilloPunto(maxU, maxV), new LadrilloPunto(minU, maxV) });
            }
            return huellas;
        }

        private sealed class FiltroVecinos : ISelectionFilter
        {
            private readonly ElementId suelo;
            internal FiltroVecinos(ElementId suelo) { this.suelo = suelo; }
            public bool AllowElement(Element elemento)
            {
                return elemento != null && !(elemento is ElementType) && !(elemento is RevitLinkInstance) &&
                    !elemento.Id.Equals(suelo) && elemento.Category != null && elemento.Category.CategoryType == CategoryType.Model;
            }
            public bool AllowReference(Reference reference, XYZ position) { return false; }
        }

        private static bool TipoAdmitido(FamilySymbol tipo)
        {
            if (tipo == null || tipo.Family == null || tipo.Family.IsInPlace) return false;
            FamilyPlacementType colocacion = tipo.Family.FamilyPlacementType;
            if (colocacion == FamilyPlacementType.OneLevelBased) return true;
            if (colocacion != FamilyPlacementType.OneLevelBasedHosted) return false;
            Parameter anfitrion = tipo.Family.get_Parameter(BuiltInParameter.FAMILY_HOSTING_BEHAVIOR);
            return anfitrion != null && anfitrion.StorageType == StorageType.Integer && anfitrion.AsInteger() == 2;
        }

        private static FamilySymbol ResolverTipo(Document doc, LadrillosLosaOpciones opciones)
        {
            if (string.IsNullOrWhiteSpace(opciones.ArchivoFamilia))
                return doc.GetElement(opciones.TipoId) as FamilySymbol;
            string ruta = Path.GetFullPath(opciones.ArchivoFamilia);
            if (!File.Exists(ruta) || !string.Equals(Path.GetExtension(ruta), ".rfa", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Selecciona un archivo de familia .rfa existente.");
            Family familia;
            using (var tx = new Transaction(doc, "Cargar familia de ladrillo"))
            {
                if (tx.Start() != TransactionStatus.Started)
                    throw new InvalidOperationException("No se pudo iniciar la carga de la familia.");
                var fallos = new FallosColocacion();
                tx.SetFailureHandlingOptions(tx.GetFailureHandlingOptions()
                    .SetClearAfterRollback(true).SetForcedModalHandling(true)
                    .SetFailuresPreprocessor(fallos));
                // No sobrescribir una familia existente ni sus parámetros automáticamente.
                if (!doc.LoadFamily(ruta, out familia) || familia == null)
                    throw new InvalidOperationException("No se cargó la familia. Si ya existe en el proyecto, " +
                        "selecciona uno de sus tipos cargados en la ventana del comando.");
                if (tx.Commit() != TransactionStatus.Committed)
                    throw new InvalidOperationException("Revit no confirmó la carga de la familia. " + fallos.Descripcion);
            }
            var tipos = familia.GetFamilySymbolIds().Select(doc.GetElement).OfType<FamilySymbol>()
                .OrderBy(x => x.Name).ToList();
            if (tipos.Count == 0) throw new InvalidOperationException("La familia no contiene tipos.");
            if (tipos.Count == 1) return tipos[0];
            using (var elegir = new Forms.Form())
            using (var lista = new Forms.ComboBox())
            using (var aceptar = new Forms.Button())
            using (var cancelar = new Forms.Button())
            {
                elegir.Text = "MYG · Tipo de ladrillo";
                elegir.StartPosition = Forms.FormStartPosition.CenterScreen;
                elegir.FormBorderStyle = Forms.FormBorderStyle.FixedDialog;
                elegir.MinimizeBox = elegir.MaximizeBox = false;
                elegir.ClientSize = new System.Drawing.Size(500, 100);
                lista.DropDownStyle = Forms.ComboBoxStyle.DropDownList;
                lista.SetBounds(12, 12, 476, 25);
                foreach (FamilySymbol tipo in tipos) lista.Items.Add(tipo.Name);
                lista.SelectedIndex = 0;
                aceptar.Text = "Aceptar"; aceptar.DialogResult = Forms.DialogResult.OK;
                aceptar.SetBounds(302, 55, 90, 30);
                cancelar.Text = "Cancelar"; cancelar.DialogResult = Forms.DialogResult.Cancel;
                cancelar.SetBounds(398, 55, 90, 30);
                elegir.Controls.AddRange(new Forms.Control[] { lista, aceptar, cancelar });
                elegir.AcceptButton = aceptar; elegir.CancelButton = cancelar;
                return elegir.ShowDialog() == Forms.DialogResult.OK ? tipos[lista.SelectedIndex] : null;
            }
        }

        private static void ValidarOpciones(LadrillosLosaOpciones opciones)
        {
            if (opciones == null) throw new InvalidOperationException("No se recibieron opciones de colocación.");
            foreach (double valor in new[] { opciones.ViguetaCm, opciones.JuntaCm, opciones.MargenCm, opciones.DesfaseBaseCm })
                if (double.IsNaN(valor) || double.IsInfinity(valor) || valor < 0)
                    throw new InvalidOperationException("Las separaciones, margen y desfase deben ser números finitos no negativos.");
        }

        private static FamilyInstance Crear(Document doc, FamilySymbol tipo, Floor suelo, Level nivel,
            XYZ punto, bool hospedado)
        {
            FamilyInstance instancia = hospedado
                ? doc.Create.NewFamilyInstance(punto, tipo, suelo, StructuralType.NonStructural)
                : doc.Create.NewFamilyInstance(punto, tipo, nivel, StructuralType.NonStructural);
            if (instancia == null) throw new InvalidOperationException("Revit no pudo crear la familia seleccionada.");
            return instancia;
        }

        private static void Orientar(Document doc, FamilyInstance instancia, double angulo)
        {
            LocationPoint ubicacion = instancia.Location as LocationPoint;
            if (ubicacion == null)
                throw new InvalidOperationException("La familia no tiene un punto de inserción compatible.");
            double giro = angulo - ubicacion.Rotation;
            if (Math.Abs(giro) > 1e-10)
                ElementTransformUtils.RotateElement(doc, instancia.Id,
                    Line.CreateBound(ubicacion.Point, ubicacion.Point + XYZ.BasisZ), giro);
        }

        private static DatosSuelo LeerSuelo(Floor suelo)
        {
            CompoundStructure estructura = suelo.FloorType.GetCompoundStructure();
            if (estructura != null && estructura.VariableLayerIndex >= 0)
                throw new InvalidOperationException("Esta versión trabaja con losas de espesor constante. " +
                    "El tipo seleccionado tiene una capa de espesor variable.");
            var superiores = HostObjectUtils.GetTopFaces(suelo)
                .Select(x => suelo.GetGeometryObjectFromReference(x)).OfType<PlanarFace>().ToList();
            var inferiores = HostObjectUtils.GetBottomFaces(suelo)
                .Select(x => suelo.GetGeometryObjectFromReference(x)).OfType<PlanarFace>().ToList();
            if (superiores.Count == 0 || inferiores.Count == 0 ||
                superiores.Count != HostObjectUtils.GetTopFaces(suelo).Count ||
                inferiores.Count != HostObjectUtils.GetBottomFaces(suelo).Count ||
                superiores.Any(x => x.FaceNormal.Z < 1 - 1e-9) ||
                inferiores.Any(x => x.FaceNormal.Z > -1 + 1e-9))
                throw new InvalidOperationException("Selecciona una losa horizontal, con caras superior e inferior planas.");
            double arriba = superiores[0].Origin.Z, abajo = inferiores[0].Origin.Z;
            if (arriba <= abajo || superiores.Any(x => Math.Abs(x.Origin.Z - arriba) > Tolerancia) ||
                inferiores.Any(x => Math.Abs(x.Origin.Z - abajo) > Tolerancia))
                throw new InvalidOperationException("La losa tiene desniveles o espesor irregular; no se puede colocar una malla plana.");
            List<Solid> solidos = Solidos(suelo).Select(x => SolidUtils.CreateTransformed(x, Transform.Identity)).ToList();
            if (solidos.Count == 0) throw new InvalidOperationException("No se encontró el sólido del suelo.");
            Mesh malla = superiores[0].Triangulate();
            if (malla.NumTriangles == 0) throw new InvalidOperationException("No se pudo obtener un punto interior del suelo.");
            MeshTriangle triangulo = malla.get_Triangle(0);
            XYZ semilla = (triangulo.get_Vertex(0) + triangulo.get_Vertex(1) + triangulo.get_Vertex(2)) / 3;
            return new DatosSuelo { Superior = arriba, Inferior = abajo, CarasSuperiores = superiores,
                Solidos = solidos, Semilla = semilla };
        }

        private static List<IList<LadrilloPunto>> Contornos(IEnumerable<PlanarFace> caras, Marco marco)
        {
            var resultado = new List<IList<LadrilloPunto>>();
            foreach (PlanarFace cara in caras)
                foreach (CurveLoop loop in cara.GetEdgesAsCurveLoops())
                {
                    var puntos = new List<LadrilloPunto>();
                    foreach (Curve curva in loop)
                    {
                        IList<XYZ> muestra = curva.Tessellate();
                        for (int i = 0; i < muestra.Count - 1; i++)
                            puntos.Add(marco.Proyectar(muestra[i]));
                    }
                    if (puntos.Count < 3) throw new InvalidOperationException("Un contorno de la losa no tiene puntos suficientes.");
                    resultado.Add(puntos);
                }
            return resultado;
        }

        // Esta diferencia compara BRep temporales para validar únicamente la huella XY
        // contra una copia del suelo original. No utiliza Document ni modifica/corta
        // el anfitrión. La altura del prisma es el espesor de la losa, no la del ladrillo:
        // una familia hospedada puede quedar sobre su cara superior legítimamente.
        private static bool HuellaDentroDelSuelo(IList<Solid> suelo, Marco marco, LadrilloPunto centro,
            double largo, double ancho, double baseZ, double alto)
        {
            XYZ[] p = { marco.Punto(centro.X - largo / 2, centro.Y - ancho / 2, baseZ),
                marco.Punto(centro.X + largo / 2, centro.Y - ancho / 2, baseZ),
                marco.Punto(centro.X + largo / 2, centro.Y + ancho / 2, baseZ),
                marco.Punto(centro.X - largo / 2, centro.Y + ancho / 2, baseZ) };
            using (var contorno = new CurveLoop())
            {
                for (int i = 0; i < 4; i++) contorno.Append(Line.CreateBound(p[i], p[(i + 1) % 4]));
                Solid restante = GeometryCreationUtilities.CreateExtrusionGeometry(new List<CurveLoop> { contorno }, XYZ.BasisZ, alto);
                try
                {
                    double toleranciaVolumen = Math.Max(1e-8, restante.Volume * 1e-7);
                    foreach (Solid anfitrion in suelo)
                    {
                        Solid siguiente = BooleanOperationsUtils.ExecuteBooleanOperation(restante, anfitrion, BooleanOperationsType.Difference);
                        restante.Dispose();
                        restante = siguiente;
                        if (restante.Volume <= toleranciaVolumen) return true;
                    }
                    return restante.Volume <= toleranciaVolumen;
                }
                finally { restante.Dispose(); }
            }
        }

        private static List<Solid> Solidos(Element elemento)
        {
            var resultado = new List<Solid>();
            var opciones = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false };
            Recorrer(elemento.get_Geometry(opciones), Transform.Identity, (s, t) =>
                resultado.Add(t.IsIdentity ? s : SolidUtils.CreateTransformed(s, t)));
            return resultado;
        }

        private static void Recorrer(GeometryElement geometria, Transform transformacion, Action<Solid, Transform> recibir)
        {
            if (geometria == null) return;
            foreach (GeometryObject objeto in geometria)
            {
                Solid solido = objeto as Solid;
                if (solido != null && solido.Faces.Size > 0 && solido.Volume > 1e-12)
                    recibir(solido, transformacion);
                GeometryInstance instancia = objeto as GeometryInstance;
                if (instancia != null)
                    Recorrer(instancia.GetSymbolGeometry(), transformacion.Multiply(instancia.Transform), recibir);
            }
        }

        private static Caja Medir(Element elemento, Marco marco)
        {
            var caja = new Caja();
            var opciones = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false };
            Recorrer(elemento.get_Geometry(opciones), Transform.Identity, (s, t) =>
            {
                // Medir en ejes de las filas, también cuando Revit entrega un sólido
                // directo en coordenadas del modelo en lugar de GeometryInstance.
                // Proyectar su caja mundial inflaría la huella al girarla en planta.
                using (Solid local = SolidUtils.CreateTransformed(s, marco.ModeloALocal.Multiply(t)))
                using (BoundingBoxXYZ limite = local.GetBoundingBox())
                {
                    for (int i = 0; i < 8; i++)
                    {
                        XYZ p = limite.Transform.OfPoint(new XYZ((i & 1) == 0 ? limite.Min.X : limite.Max.X,
                            (i & 2) == 0 ? limite.Min.Y : limite.Max.Y, (i & 4) == 0 ? limite.Min.Z : limite.Max.Z));
                        caja.Incluir(p.X, p.Y, p.Z);
                    }
                }
            });
            if (double.IsInfinity(caja.MinU))
                throw new InvalidOperationException("La familia no contiene geometría sólida visible en detalle fino.");
            return caja;
        }

        private static IndiceCajas LeerExistentes(Document doc, FamilySymbol tipo, ElementId plantilla,
            Marco marco, double largo, double ancho)
        {
            var indice = new IndiceCajas(Math.Max(largo, ancho));
            foreach (FamilyInstance instancia in new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)))
            {
                if (instancia.Id.Equals(plantilla) || instancia.SuperComponent != null ||
                    !instancia.Symbol.Family.Id.Equals(tipo.Family.Id)) continue;
                indice.Agregar(Medir(instancia, marco));
            }
            return indice;
        }

        private static double Pies(double centimetros) { return centimetros / 30.48; }
        private static string Cm(double pies) { return (pies * 30.48).ToString("0.###", CultureInfo.CurrentCulture); }
        private static string Mm(double pies) { return (pies * 304.8).ToString("0.######", CultureInfo.CurrentCulture); }

        private static List<string> DescribirDiferencias(Caja real, LadrilloPunto centro,
            double baseDeseada, double superiorSuelo, double largo, double ancho, double alto, bool ajustarBase)
        {
            var diferencias = new List<string>();
            Action<string, double, double> comparar = (nombre, esperado, obtenido) =>
            {
                if (Math.Abs(obtenido - esperado) > Tolerancia)
                    diferencias.Add(nombre + ": esperado " + Mm(esperado) + " mm; real " + Mm(obtenido) +
                        " mm; diferencia " + Mm(obtenido - esperado) + " mm.");
            };
            comparar("Centro U", centro.X, (real.MinU + real.MaxU) / 2);
            comparar("Centro V", centro.Y, (real.MinV + real.MaxV) / 2);
            comparar("Base Z", baseDeseada, real.MinZ);
            if (ajustarBase && real.MaxZ > superiorSuelo + Tolerancia)
                diferencias.Add("Cima Z: máximo permitido " + Mm(superiorSuelo) + " mm; real " + Mm(real.MaxZ) +
                    " mm; exceso " + Mm(real.MaxZ - superiorSuelo) + " mm.");
            comparar("Altura", alto, real.MaxZ - real.MinZ);
            comparar("Largo U", largo, real.MaxU - real.MinU);
            comparar("Ancho V", ancho, real.MaxV - real.MinV);
            return diferencias;
        }

        private sealed class FiltroSuelo : ISelectionFilter
        {
            public bool AllowElement(Element element) { return element is Floor; }
            public bool AllowReference(Reference reference, XYZ position) { return false; }
        }

        private sealed class Marco
        {
            internal readonly XYZ Origen, U, V;
            internal readonly Transform ModeloALocal;
            internal Marco(XYZ origen, XYZ u)
            {
                Origen = origen; U = u; V = new XYZ(-u.Y, u.X, 0);
                Transform aModelo = Transform.Identity;
                aModelo.Origin = new XYZ(origen.X, origen.Y, 0);
                aModelo.BasisX = U; aModelo.BasisY = V; aModelo.BasisZ = XYZ.BasisZ;
                ModeloALocal = aModelo.Inverse;
            }
            internal LadrilloPunto Proyectar(XYZ p)
            {
                XYZ d = p - Origen;
                return new LadrilloPunto(d.DotProduct(U), d.DotProduct(V));
            }
            internal XYZ Punto(double u, double v, double z)
            { return new XYZ(Origen.X + U.X * u + V.X * v, Origen.Y + U.Y * u + V.Y * v, z); }
        }

        private sealed class DatosSuelo
        {
            internal double Superior, Inferior;
            internal List<PlanarFace> CarasSuperiores;
            internal List<Solid> Solidos;
            internal XYZ Semilla;
        }

        private sealed class Caja
        {
            internal double MinU = double.PositiveInfinity, MinV = double.PositiveInfinity, MinZ = double.PositiveInfinity;
            internal double MaxU = double.NegativeInfinity, MaxV = double.NegativeInfinity, MaxZ = double.NegativeInfinity;
            internal Caja() { }
            internal Caja(double minU, double maxU, double minV, double maxV, double minZ, double maxZ)
            { MinU = minU; MaxU = maxU; MinV = minV; MaxV = maxV; MinZ = minZ; MaxZ = maxZ; }
            internal void Incluir(double u, double v, double z)
            {
                MinU = Math.Min(MinU, u); MaxU = Math.Max(MaxU, u);
                MinV = Math.Min(MinV, v); MaxV = Math.Max(MaxV, v);
                MinZ = Math.Min(MinZ, z); MaxZ = Math.Max(MaxZ, z);
            }
            internal bool Intersecta(Caja otra)
            {
                return MinU < otra.MaxU - Tolerancia && MaxU > otra.MinU + Tolerancia &&
                    MinV < otra.MaxV - Tolerancia && MaxV > otra.MinV + Tolerancia &&
                    MinZ < otra.MaxZ - Tolerancia && MaxZ > otra.MinZ + Tolerancia;
            }
        }

        private sealed class IndiceCajas
        {
            private readonly double paso;
            private readonly Dictionary<string, List<Caja>> celdas = new Dictionary<string, List<Caja>>();
            private readonly List<Caja> grandes = new List<Caja>();
            internal IndiceCajas(double paso) { this.paso = paso; }
            private string Clave(long u, long v) { return u.ToString(CultureInfo.InvariantCulture) + ":" + v.ToString(CultureInfo.InvariantCulture); }
            internal void Agregar(Caja caja)
            {
                long u0 = (long)Math.Floor(caja.MinU / paso), u1 = (long)Math.Floor(caja.MaxU / paso);
                long v0 = (long)Math.Floor(caja.MinV / paso), v1 = (long)Math.Floor(caja.MaxV / paso);
                if ((double)(u1 - u0 + 1) * (v1 - v0 + 1) > 1000) { grandes.Add(caja); return; }
                for (long u = u0; u <= u1; u++) for (long v = v0; v <= v1; v++)
                {
                    string clave = Clave(u, v); List<Caja> lista;
                    if (!celdas.TryGetValue(clave, out lista)) celdas.Add(clave, lista = new List<Caja>());
                    lista.Add(caja);
                }
            }
            internal bool Intersecta(Caja caja)
            {
                if (grandes.Any(x => x.Intersecta(caja))) return true;
                long u0 = (long)Math.Floor(caja.MinU / paso), u1 = (long)Math.Floor(caja.MaxU / paso);
                long v0 = (long)Math.Floor(caja.MinV / paso), v1 = (long)Math.Floor(caja.MaxV / paso);
                for (long u = u0; u <= u1; u++) for (long v = v0; v <= v1; v++)
                {
                    List<Caja> lista;
                    if (celdas.TryGetValue(Clave(u, v), out lista) && lista.Any(x => x.Intersecta(caja))) return true;
                }
                return false;
            }
        }

        private sealed class FallosColocacion : IFailuresPreprocessor
        {
            internal string Descripcion = "";
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                var errores = failuresAccessor.GetFailureMessages()
                    .Where(x => x.GetSeverity() == FailureSeverity.Error).ToList();
                if (errores.Count == 0) return FailureProcessingResult.Continue;
                Descripcion = string.Join("\n", errores.Select(x => x.GetDescriptionText()));
                return FailureProcessingResult.ProceedWithRollBack;
            }
        }
    }
}
