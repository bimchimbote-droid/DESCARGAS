using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using Forms = System.Windows.Forms;

namespace MYG_Addin
{
    internal sealed class LadrilloVista
    {
        internal LadrilloPunto Centro = new LadrilloPunto(0, 0);
        internal bool Interfiere = false;
        internal bool Incluir = true;
        internal int Obstaculos = 0;
    }

    /// <summary>
    /// Editor de huellas UV. La edición se mantiene en memoria hasta confirmar;
    /// no mueve el documento Revit ni equipara la previsión con un corte real.
    /// </summary>
    internal sealed class LadrillosPreviewForm : Forms.Form
    {
        private static readonly Color Azul = Color.FromArgb(25, 91, 123);
        private static readonly Color Turquesa = Color.FromArgb(18, 120, 128);
        private static readonly Color Fondo = Color.FromArgb(238, 243, 246);
        private static readonly Color Texto = Color.FromArgb(35, 53, 66);
        private readonly IList<IList<LadrilloPunto>> contornos;
        private readonly IList<IList<LadrilloPunto>> huellasObstaculos;
        private readonly LadrillosEditor editor;
        private readonly double largo, ancho;
        private readonly Action<IList<LadrilloEditable>> actualizarEncuentros;
        private readonly Lienzo lienzo = new Lienzo();
        private readonly Forms.ComboBox herramienta = new Forms.ComboBox();
        private readonly Forms.ComboBox modo = new Forms.ComboBox();
        private readonly Forms.CheckBox unir = new Forms.CheckBox();
        private readonly Forms.CheckBox verVecinos = new Forms.CheckBox();
        private readonly Forms.CheckBox ajustarPaso = new Forms.CheckBox();
        private readonly Forms.NumericUpDown paso = Numero(1M, 0.1M, 1000M);
        private readonly Forms.NumericUpDown moverU = Numero(0, -10000, 10000);
        private readonly Forms.NumericUpDown moverV = Numero(0, -10000, 10000);
        private readonly Forms.Label conteo = new Forms.Label();
        private readonly Forms.Label seleccionTexto = new Forms.Label();
        private readonly Forms.Label estado = new Forms.Label();
        private readonly Forms.Label detalleModo = new Forms.Label();
        private readonly Forms.Label zoomTexto = new Forms.Label();
        private readonly Forms.Button crear = new Forms.Button();
        private readonly Forms.Button deshacer = new Forms.Button();
        private readonly Forms.Button rehacer = new Forms.Button();
        private readonly Forms.ToolTip ayuda = new Forms.ToolTip();
        private double escala = 1, offsetX, offsetY, arrastreU, arrastreV;
        private bool vistaAjustada, espacio;
        private Point ultimoRaton, inicioRaton;
        private LadrilloPunto inicioUV;
        private Size tamanoAnterior;
        private Gesto gesto;
        private bool marcoSumar;
        private string errorEncuentros = "";
        private ModoEncuentroLadrillos modoSinUnion = ModoEncuentroLadrillos.Omitir;
        private int ultimoHover = -2;

        private enum Gesto { Ninguno, DesplazarVista, MoverSeleccion, Marco }

        internal ModoEncuentroLadrillos ModoSeleccionado
        {
            get { var opcion = modo.SelectedItem as OpcionModo; return unir.Checked ? ModoEncuentroLadrillos.Unir : opcion == null ? ModoEncuentroLadrillos.Omitir : opcion.Valor; }
        }

        internal List<LadrilloPunto> Seleccionadas
        {
            get { return editor.Piezas.Where(x => x.Incluir).Select(x => x.Centro).ToList(); }
        }

        internal LadrillosPreviewForm(IList<IList<LadrilloPunto>> contornos, List<LadrilloVista> piezas,
            double largo, double ancho, IList<IList<LadrilloPunto>> huellasObstaculos, string resumen,
            ModoEncuentroLadrillos modoInicial, double margen, double juntaU, double viguetaV,
            Action<IList<LadrilloEditable>> actualizarEncuentros)
        {
            if (contornos == null || piezas == null || piezas.Any(x => x == null))
                throw new ArgumentException("La edición necesita contornos y piezas válidas.");
            if (actualizarEncuentros == null)
                throw new ArgumentNullException("actualizarEncuentros", "El editor necesita verificar las posiciones modificadas antes de crearlas.");
            this.contornos = contornos;
            this.huellasObstaculos = huellasObstaculos ?? new List<IList<LadrilloPunto>>();
            this.largo = largo; this.ancho = ancho;
            this.actualizarEncuentros = actualizarEncuentros;
            editor = new LadrillosEditor(contornos, piezas.Select(x => x.Centro).ToList(), largo, ancho, margen, juntaU, viguetaV);
            for (int i = 0; i < piezas.Count; i++)
            {
                editor.Piezas[i].Incluir = piezas[i].Incluir;
                editor.Piezas[i].Interfiere = piezas[i].Interfiere;
                editor.Piezas[i].Obstaculos = piezas[i].Obstaculos;
            }
            editor.Validar();
            Text = "MYG · Editor de filas y paños";
            Font = new Font("Segoe UI", 9F);
            ForeColor = Texto;
            BackColor = Fondo;
            StartPosition = Forms.FormStartPosition.CenterScreen;
            AutoScaleMode = Forms.AutoScaleMode.Font;
            ClientSize = new Size(1220, 820);
            MinimumSize = new Size(960, 680);
            MinimizeBox = false;
            KeyPreview = true;
            Construir(resumen, modoInicial);
            Refrescar(true);
            Shown += delegate { AjustarVista(); };
            KeyDown += delegate(object sender, Forms.KeyEventArgs e) { if (e.KeyCode == Forms.Keys.Space && lienzo.Focused) { espacio = true; lienzo.Cursor = Forms.Cursors.Hand; e.Handled = true; } };
            KeyUp += delegate(object sender, Forms.KeyEventArgs e) { if (e.KeyCode == Forms.Keys.Space) { espacio = false; if (gesto == Gesto.Ninguno) lienzo.Cursor = Forms.Cursors.Default; } };
            Deactivate += delegate { espacio = false; CancelarGesto(); };
        }

        private void Construir(string resumen, ModoEncuentroLadrillos modoInicial)
        {
            var raiz = new Forms.TableLayoutPanel { Dock = Forms.DockStyle.Fill, ColumnCount = 2, RowCount = 4, Padding = new Forms.Padding(16), BackColor = Fondo };
            raiz.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            raiz.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Absolute, 332));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 66));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.AutoSize));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Percent, 100));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 64));
            Controls.Add(raiz);
            var cabecera = new Forms.TableLayoutPanel { Dock = Forms.DockStyle.Fill, BackColor = Azul, ColumnCount = 2, Padding = new Forms.Padding(16, 8, 16, 8), Margin = new Forms.Padding(0, 0, 0, 10) };
            cabecera.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            cabecera.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Absolute, 160));
            var titulo = new Forms.Label { Text = "Distribución de ladrillos", Dock = Forms.DockStyle.Fill, ForeColor = Color.White, Font = new Font("Segoe UI Semibold", 15F), TextAlign = ContentAlignment.MiddleLeft };
            var insignia = new Forms.Label { Text = "EDITOR EN PLANTA", ForeColor = Color.FromArgb(192, 235, 239), Dock = Forms.DockStyle.Fill, TextAlign = ContentAlignment.MiddleRight };
            cabecera.Controls.Add(titulo, 0, 0); cabecera.Controls.Add(insignia, 1, 0);
            raiz.Controls.Add(cabecera, 0, 0); raiz.SetColumnSpan(cabecera, 2);

            var barra = new Forms.FlowLayoutPanel { Dock = Forms.DockStyle.Fill, AutoSize = true, AutoSizeMode = Forms.AutoSizeMode.GrowAndShrink, WrapContents = true, Margin = new Forms.Padding(0, 0, 12, 8) };
            barra.Controls.Add(new Forms.Label { Text = "Seleccionar", AutoSize = true, Padding = new Forms.Padding(0, 8, 7, 0) });
            herramienta.DropDownStyle = Forms.ComboBoxStyle.DropDownList; herramienta.Width = 136;
            herramienta.Items.AddRange(new object[] { "Fila completa", "Pieza", "Paño / grupo", "Toda la malla" }); herramienta.SelectedIndex = 0;
            barra.Controls.Add(herramienta);
            var ajustar = Boton("Ajustar vista", delegate { AjustarVista(); });
            barra.Controls.Add(ajustar);
            deshacer.Text = "↶ Deshacer"; deshacer.AutoSize = true; deshacer.Click += delegate { Editar(editor.Deshacer); };
            rehacer.Text = "↷ Rehacer"; rehacer.AutoSize = true; rehacer.Click += delegate { Editar(editor.Rehacer); };
            barra.Controls.Add(deshacer); barra.Controls.Add(rehacer);
            raiz.Controls.Add(barra, 0, 1);
            zoomTexto.AutoSize = true; zoomTexto.Padding = new Forms.Padding(8, 8, 0, 0);
            barra.Controls.Add(zoomTexto);
            var unionRapida = new Forms.Panel { Dock = Forms.DockStyle.Fill, BackColor = Color.White,
                MinimumSize = new Size(0, 40), Margin = new Forms.Padding(0, 0, 0, 8) };
            unir.Location = new Point(10, 9); unionRapida.Controls.Add(unir);
            raiz.Controls.Add(unionRapida, 1, 1);

            var zona = new Forms.Panel { Dock = Forms.DockStyle.Fill, BackColor = Color.White, Padding = new Forms.Padding(1), Margin = new Forms.Padding(0, 0, 12, 0) };
            lienzo.Dock = Forms.DockStyle.Fill; lienzo.BackColor = Color.FromArgb(250, 252, 253); lienzo.TabStop = true;
            zona.Controls.Add(lienzo); raiz.Controls.Add(zona, 0, 2);
            var scroll = new Forms.Panel { Dock = Forms.DockStyle.Fill, AutoScroll = true, Margin = Forms.Padding.Empty };
            var lateral = new Forms.TableLayoutPanel { AutoSize = true, AutoSizeMode = Forms.AutoSizeMode.GrowAndShrink, Dock = Forms.DockStyle.Top, ColumnCount = 1, Padding = new Forms.Padding(0, 0, 4, 0) };
            lateral.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            scroll.Controls.Add(lateral); raiz.Controls.Add(scroll, 1, 2);

            var seleccion = Tarjeta(lateral, "01  SELECCIÓN Y MOVIMIENTO");
            seleccionTexto.Dock = Forms.DockStyle.Top; seleccionTexto.AutoSize = true; seleccionTexto.MaximumSize = new Size(286, 0); seleccionTexto.Margin = new Forms.Padding(0, 3, 0, 9);
            seleccion.Controls.Add(seleccionTexto);
            seleccion.Controls.Add(TextoAyuda("Clic para seleccionar una fila. Arrastra la selección para moverla. Ctrl añade a la selección; Paño / grupo permite dibujar un marco."));
            var desplazamientos = new Forms.TableLayoutPanel { AutoSize = true, Dock = Forms.DockStyle.Top, ColumnCount = 2, Margin = new Forms.Padding(0, 8, 0, 6) };
            desplazamientos.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 50)); desplazamientos.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 50));
            desplazamientos.Controls.Add(new Forms.Label { Text = "Mover U · fila (cm)", AutoSize = true }, 0, 0);
            desplazamientos.Controls.Add(new Forms.Label { Text = "Mover V · transversal (cm)", AutoSize = true }, 1, 0);
            moverU.Dock = moverV.Dock = Forms.DockStyle.Fill;
            desplazamientos.Controls.Add(moverU, 0, 1); desplazamientos.Controls.Add(moverV, 1, 1);
            seleccion.Controls.Add(desplazamientos);
            seleccion.Controls.Add(Boton("Aplicar desplazamiento", delegate { Mover((double)moverU.Value / 30.48, (double)moverV.Value / 30.48); }));
            var pasoFila = new Forms.FlowLayoutPanel { AutoSize = true, Dock = Forms.DockStyle.Top, WrapContents = false, Margin = new Forms.Padding(0, 8, 0, 3) };
            pasoFila.Controls.Add(new Forms.Label { Text = "Paso (cm)", AutoSize = true, Padding = new Forms.Padding(0, 5, 8, 0) }); paso.Width = 80; pasoFila.Controls.Add(paso);
            seleccion.Controls.Add(pasoFila);
            ajustarPaso.Text = "Ajustar arrastre al paso"; ajustarPaso.Checked = true; ajustarPaso.AutoSize = true; seleccion.Controls.Add(ajustarPaso);
            var flechas = new Forms.FlowLayoutPanel { AutoSize = true, Dock = Forms.DockStyle.Top, WrapContents = false };
            flechas.Controls.Add(Boton("←", delegate { Nudge(-1, 0); })); flechas.Controls.Add(Boton("→", delegate { Nudge(1, 0); }));
            flechas.Controls.Add(Boton("↑", delegate { Nudge(0, 1); })); flechas.Controls.Add(Boton("↓", delegate { Nudge(0, -1); }));
            seleccion.Controls.Add(flechas);
            var inclusion = new Forms.FlowLayoutPanel { AutoSize = true, Dock = Forms.DockStyle.Top, WrapContents = false };
            inclusion.Controls.Add(Boton("Incluir selección", delegate { Editar(delegate { editor.SetInclusionSeleccion(true); }); }));
            inclusion.Controls.Add(Boton("Excluir selección", delegate { Editar(delegate { editor.SetInclusionSeleccion(false); }); })); seleccion.Controls.Add(inclusion);
            seleccion.Controls.Add(Boton("Restablecer selección", delegate { Editar(editor.RestablecerSeleccion); }));
            seleccion.Controls.Add(Boton("Restablecer toda la malla", delegate { Editar(editor.RestablecerTodo); }));

            var encuentros = Tarjeta(lateral, "02  ELEMENTOS INTERSECANTES");
            unir.Text = "Unir elementos intersecantes"; unir.Font = new Font("Segoe UI Semibold", 10F); unir.ForeColor = Turquesa; unir.AutoSize = true; unir.MaximumSize = new Size(304, 0);
            modo.DropDownStyle = Forms.ComboBoxStyle.DropDownList; modo.DisplayMember = "Texto"; modo.Width = 278;
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.Omitir, "Omitir piezas en conflicto"));
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.SoloDetectar, "Solo detectar (conserva conflictos)"));
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.Cortar, "Cortar ladrillo con vecino"));
            modo.SelectedIndex = 0;
            modoSinUnion = modoInicial == ModoEncuentroLadrillos.Unir ? ModoEncuentroLadrillos.Omitir : modoInicial;
            for (int i = 0; i < modo.Items.Count; i++) if (((OpcionModo)modo.Items[i]).Valor == modoSinUnion) modo.SelectedIndex = i;
            unir.Checked = modoInicial == ModoEncuentroLadrillos.Unir; modo.Enabled = !unir.Checked;
            encuentros.Controls.Add(TextoAyuda("Con el checkbox desmarcado:")); encuentros.Controls.Add(modo);
            detalleModo.AutoSize = true; detalleModo.MaximumSize = new Size(286, 0); detalleModo.Padding = new Forms.Padding(0, 8, 0, 0); encuentros.Controls.Add(detalleModo);
            unir.CheckedChanged += delegate { modo.Enabled = !unir.Checked; Refrescar(false); };
            modo.SelectedIndexChanged += delegate { if (modo.SelectedItem is OpcionModo) modoSinUnion = ((OpcionModo)modo.SelectedItem).Valor; Refrescar(false); };

            var revision = Tarjeta(lateral, "03  REVISIÓN DEL PAÑO");
            conteo.AutoSize = true; conteo.MaximumSize = new Size(286, 0); conteo.Font = new Font("Segoe UI", 9F); revision.Controls.Add(conteo);
            verVecinos.Text = "Mostrar envolventes de vecinos"; verVecinos.AutoSize = true; verVecinos.Checked = true; verVecinos.CheckedChanged += delegate { lienzo.Invalidate(); }; revision.Controls.Add(verVecinos);
            revision.Controls.Add(TextoAyuda("Terracota: pieza incluida · Azul: seleccionada\r\nRojo: fuera del contorno o solapada\r\nÁmbar: posible encuentro · Gris: excluida"));
            revision.Controls.Add(TextoAyuda("Las posiciones inválidas bloquean Crear. Corrige el desplazamiento, excluye esas piezas o utiliza Deshacer."));

            var informacion = Tarjeta(lateral, "DATOS DE LA DISTRIBUCIÓN");
            informacion.Controls.Add(new Forms.TextBox { Multiline = true, ReadOnly = true, ScrollBars = Forms.ScrollBars.Vertical, WordWrap = true, Text = resumen ?? "", Height = 112, Width = 278, BackColor = Color.White, BorderStyle = Forms.BorderStyle.FixedSingle });
            informacion.Controls.Add(TextoAyuda("Vista esquemática en planta. Los huecos dibujados orientan la lectura; no sustituyen la geometría real de la familia. Uniones y cortes se verifican en Revit; las piezas no resolubles se omiten."));

            var pie = new Forms.TableLayoutPanel { Dock = Forms.DockStyle.Fill, ColumnCount = 2, Margin = new Forms.Padding(0, 10, 0, 0), BackColor = Color.White, Padding = new Forms.Padding(12, 8, 10, 8) };
            pie.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100)); pie.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.AutoSize));
            estado.Dock = Forms.DockStyle.Fill; estado.AutoEllipsis = true; estado.TextAlign = ContentAlignment.MiddleLeft; pie.Controls.Add(estado, 0, 0);
            var acciones = new Forms.FlowLayoutPanel { AutoSize = true, Dock = Forms.DockStyle.Fill, FlowDirection = Forms.FlowDirection.RightToLeft, WrapContents = false };
            var cancelar = Boton("Cancelar", delegate { DialogResult = Forms.DialogResult.Cancel; Close(); });
            crear.Text = "Crear distribución"; crear.AutoSize = true; crear.BackColor = Turquesa; crear.ForeColor = Color.White; crear.FlatStyle = Forms.FlatStyle.Flat; crear.FlatAppearance.BorderSize = 0; crear.Padding = new Forms.Padding(10, 5, 10, 5);
            crear.Click += delegate { Refrescar(true); if (editor.PuedeCrear && string.IsNullOrEmpty(errorEncuentros)) { DialogResult = Forms.DialogResult.OK; Close(); } };
            acciones.Controls.Add(cancelar); acciones.Controls.Add(crear); pie.Controls.Add(acciones, 1, 0);
            raiz.Controls.Add(pie, 0, 3); raiz.SetColumnSpan(pie, 2);
            // Crear requiere una acción explícita: Enter al editar U/V o el paso
            // no debe confirmar la distribución sin aplicar esos valores.
            CancelButton = cancelar;

            lienzo.Paint += Pintar; lienzo.MouseDown += RatonAbajo; lienzo.MouseMove += MoverRaton; lienzo.MouseUp += RatonArriba; lienzo.MouseWheel += Rueda;
            lienzo.MouseEnter += delegate { lienzo.Focus(); };
            lienzo.MouseLeave += delegate { ayuda.Hide(lienzo); ultimoHover = -2; };
            lienzo.MouseCaptureChanged += delegate { if (!lienzo.Capture && gesto != Gesto.Ninguno) CancelarGesto(); };
            lienzo.KeyDown += TeclaLienzo;
            lienzo.Resize += delegate { if (!vistaAjustada) return; offsetX += (lienzo.Width - tamanoAnterior.Width) / 2.0; offsetY += (lienzo.Height - tamanoAnterior.Height) / 2.0; tamanoAnterior = lienzo.Size; lienzo.Invalidate(); };
            herramienta.SelectedIndexChanged += delegate { CancelarGesto(); editor.LimpiarSeleccion(); Refrescar(false); };
            ayuda.SetToolTip(herramienta, "Fila: grupo estable de origen. Paño: arrastra un marco; luego arrastra las piezas seleccionadas.");
            ayuda.SetToolTip(paso, "Las flechas mueven este paso. Mayús multiplica por diez.");
        }

        private Forms.FlowLayoutPanel Tarjeta(Forms.TableLayoutPanel lateral, string titulo)
        {
            var tarjeta = new Forms.FlowLayoutPanel { FlowDirection = Forms.FlowDirection.TopDown, WrapContents = false, AutoSize = true, AutoSizeMode = Forms.AutoSizeMode.GrowAndShrink, Dock = Forms.DockStyle.Top, BackColor = Color.White, Padding = new Forms.Padding(12), Margin = new Forms.Padding(0, 0, 0, 10), Width = 306 };
            tarjeta.Controls.Add(new Forms.Label { Text = titulo, ForeColor = Azul, AutoSize = true, Font = new Font("Segoe UI Semibold", 9F), Margin = new Forms.Padding(0, 0, 0, 9) });
            lateral.Controls.Add(tarjeta); return tarjeta;
        }

        private static Forms.Label TextoAyuda(string texto)
        { return new Forms.Label { Text = texto, AutoSize = true, MaximumSize = new Size(282, 0), ForeColor = Color.FromArgb(91, 108, 121), Margin = new Forms.Padding(0, 4, 0, 6) }; }

        private static Forms.Button Boton(string texto, Action accion)
        {
            var boton = new Forms.Button { Text = texto, AutoSize = true, AutoSizeMode = Forms.AutoSizeMode.GrowAndShrink, FlatStyle = Forms.FlatStyle.Flat, BackColor = Color.White, Padding = new Forms.Padding(3), Margin = new Forms.Padding(0, 4, 6, 4) };
            boton.FlatAppearance.BorderColor = Color.FromArgb(209, 219, 225); boton.Click += delegate { accion(); }; return boton;
        }

        private static Forms.NumericUpDown Numero(decimal valor, decimal min, decimal max)
        { return new Forms.NumericUpDown { DecimalPlaces = 1, Minimum = min, Maximum = max, Value = valor, Increment = 1M, Width = 120, ThousandsSeparator = true }; }

        private void Refrescar(bool recalcular)
        {
            if (recalcular)
            {
                try { editor.Validar(); actualizarEncuentros(editor.Piezas.ToList()); errorEncuentros = ""; }
                catch (Exception ex) { errorEncuentros = ex.Message; }
            }
            int incluidas = editor.Piezas.Count(x => x.Incluir), invalidas = editor.Piezas.Count(x => x.Incluir && (x.FueraContorno || x.SeSolapa));
            int cruces = editor.Piezas.Count(x => x.Incluir && x.Interfiere);
            seleccionTexto.Text = editor.Seleccion.Count + " piezas seleccionadas · " + editor.Piezas.Where(x => editor.EstaSeleccionada(x.Id)).Select(x => x.Fila).Distinct().Count() + " filas\r\n" +
                "Huella " + Cm(largo) + " × " + Cm(ancho) + " cm";
            conteo.Text = "Incluidas: " + incluidas + " / " + editor.Piezas.Count + "\r\nFuera del contorno o solapadas: " + invalidas + "\r\nCon posible encuentro: " + cruces;
            crear.Enabled = editor.PuedeCrear && string.IsNullOrEmpty(errorEncuentros) && gesto != Gesto.MoverSeleccion;
            deshacer.Enabled = editor.PuedeDeshacer; rehacer.Enabled = editor.PuedeRehacer;
            detalleModo.Text = ModoSeleccionado == ModoEncuentroLadrillos.Unir
                ? "El vecino tiene prioridad para recortar el ladrillo. Si Revit no admite la unión o queda conflicto, se omite esa pieza."
                : ModoSeleccionado == ModoEncuentroLadrillos.SoloDetectar
                    ? "Se informarán los encuentros y podrán conservarse interferencias."
                    : ModoSeleccionado == ModoEncuentroLadrillos.Cortar
                        ? "Corte sólido del ladrillo por el vecino, solo si Revit lo admite. Si no se resuelve, se omite la pieza."
                        : "Las piezas con interferencia real se omitirán al crear.";
            estado.ForeColor = !string.IsNullOrEmpty(errorEncuentros) || invalidas > 0 ? Color.Firebrick : Texto;
            estado.Text = !string.IsNullOrEmpty(errorEncuentros) ? "No se pudo comprobar los encuentros: " + errorEncuentros
                : invalidas > 0 ? invalidas + " piezas incluidas requieren ajuste. Corrige o excluye las marcadas en rojo."
                : incluidas == 0 ? "No hay piezas incluidas. Selecciona e incluye alguna pieza."
                : "Arrastra filas o paños para ajustar · Ctrl: selección múltiple · Flechas: paso · Ctrl+Z / Ctrl+Y: historial";
            ayuda.SetToolTip(estado, estado.Text);
            ultimoHover = -2; lienzo.Invalidate();
        }

        private void Editar(Action accion)
        {
            CancelarGesto();
            try { accion(); Refrescar(true); }
            catch (Exception ex) { estado.ForeColor = Color.Firebrick; estado.Text = ex.Message; }
            lienzo.Focus();
        }

        private void Mover(double du, double dv)
        {
            if (!editor.HaySeleccion) { estado.Text = "Selecciona primero una fila, una pieza o un paño."; return; }
            Editar(delegate { editor.MoverSeleccion(du, dv); });
        }

        private void Nudge(int u, int v)
        { double p = (double)paso.Value / 30.48; if ((ModifierKeys & Forms.Keys.Shift) != 0) p *= 10; Mover(u * p, v * p); }

        private void AjustarVista()
        {
            CancelarGesto();
            var puntos = contornos.Where(x => x != null).SelectMany(x => x).ToList();
            foreach (var p in editor.Piezas) { puntos.Add(new LadrilloPunto(p.Centro.X - largo / 2, p.Centro.Y - ancho / 2)); puntos.Add(new LadrilloPunto(p.Centro.X + largo / 2, p.Centro.Y + ancho / 2)); }
            if (puntos.Count == 0 || lienzo.Width <= 1 || lienzo.Height <= 1) return;
            double minX = puntos.Min(x => x.X), maxX = puntos.Max(x => x.X), minY = puntos.Min(x => x.Y), maxY = puntos.Max(x => x.Y);
            escala = Math.Max(0.00001, Math.Min(200000, Math.Min(Math.Max(1, lienzo.Width - 100) / Math.Max(0.1, maxX - minX), Math.Max(1, lienzo.Height - 100) / Math.Max(0.1, maxY - minY))));
            offsetX = lienzo.Width / 2.0 - (minX + maxX) / 2 * escala; offsetY = lienzo.Height / 2.0 + (minY + maxY) / 2 * escala;
            vistaAjustada = true; tamanoAnterior = lienzo.Size; ActualizarZoom(); lienzo.Invalidate();
        }

        private void Pintar(object sender, Forms.PaintEventArgs e)
        {
            if (!vistaAjustada) return;
            Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            PintarRejilla(g);
            using (var area = Camino(contornos))
            using (var relleno = new SolidBrush(Color.FromArgb(242, 235, 218)))
            using (var borde = new Pen(Color.FromArgb(133, 145, 151), 1.6F))
            { if (area.PointCount > 0) { g.FillPath(relleno, area); g.DrawPath(borde, area); } }
            if (verVecinos.Checked)
                using (var pen = new Pen(Color.FromArgb(115, 117, 136, 159), 1F) { DashStyle = DashStyle.Dash })
                    foreach (var huella in huellasObstaculos)
                        using (var camino = Camino(new List<IList<LadrilloPunto>> { huella })) if (camino.PointCount > 0) g.DrawPath(pen, camino);
            foreach (var pieza in editor.Piezas) PintarPieza(g, pieza, 0, 0, false);
            if (gesto == Gesto.MoverSeleccion)
                foreach (var pieza in editor.Piezas.Where(x => editor.EstaSeleccionada(x.Id))) PintarPieza(g, pieza, arrastreU, arrastreV, true);
            if (gesto == Gesto.Marco)
            {
                Rectangle r = Rectangle.FromLTRB(Math.Min(inicioRaton.X, ultimoRaton.X), Math.Min(inicioRaton.Y, ultimoRaton.Y), Math.Max(inicioRaton.X, ultimoRaton.X), Math.Max(inicioRaton.Y, ultimoRaton.Y));
                using (var fill = new SolidBrush(Color.FromArgb(30, 25, 132, 193))) using (var pen = new Pen(Color.FromArgb(25, 132, 193), 1.2F) { DashStyle = DashStyle.Dash }) { g.FillRectangle(fill, r); g.DrawRectangle(pen, r); }
            }
            using (var fondo = new SolidBrush(Color.FromArgb(230, Color.White)))
            using (var fuente = new Font("Segoe UI", 8F))
            {
                g.FillRectangle(fondo, 14, 14, 184, 38);
                g.DrawString("U → filas    V ↑ transversal\nEscala en centímetros · planta", fuente, Brushes.SlateGray, 22, 20);
            }
        }

        private void PintarPieza(Graphics g, LadrilloEditable pieza, double du, double dv, bool fantasma)
        {
            RectangleF r = Rectangulo(pieza.Centro, du, dv);
            if (!r.IntersectsWith(lienzo.ClientRectangle)) return;
            if (r.Width < 0.5F || r.Height < 0.5F)
            {
                using (var punto = new SolidBrush(Color.FromArgb(160, 120, 96)))
                    g.FillRectangle(punto, r.X, r.Y, Math.Max(0.5F, r.Width), Math.Max(0.5F, r.Height));
                return;
            }
            bool seleccionada = editor.EstaSeleccionada(pieza.Id);
            bool invalida = pieza.Incluir && (pieza.FueraContorno || pieza.SeSolapa);
            Color baseColor = !pieza.Incluir ? Color.FromArgb(222, 228, 232) : invalida ? Color.FromArgb(224, 104, 101) : seleccionada ? Color.FromArgb(95, 174, 206) : pieza.Interfiere ? Color.FromArgb(237, 178, 91) : Color.FromArgb(193, 135, 100);
            if (fantasma) baseColor = Color.FromArgb(135, 43, 159, 202);
            using (var fill = new LinearGradientBrush(r, Claro(baseColor, 17), baseColor, 90F))
            using (var borde = new Pen(fantasma || seleccionada ? Color.FromArgb(18, 103, 153) : invalida ? Color.Firebrick : Color.FromArgb(115, 84, 69), fantasma || seleccionada ? 2F : 0.8F))
            { g.FillRectangle(fill, r); g.DrawRectangle(borde, r.X, r.Y, r.Width, r.Height); }
            if (r.Width > 14 && r.Height > 9)
                using (var hueco = new SolidBrush(Color.FromArgb(fantasma ? 65 : 105, 86, 63, 50)))
                    for (int h = 1; h <= 4; h++) g.FillRectangle(hueco, r.X + r.Width * h / 5 - Math.Max(1, r.Width * 0.035F), r.Y + r.Height * 0.23F, Math.Max(1, r.Width * 0.07F), r.Height * 0.54F);
            if (!fantasma && seleccionada && pieza.Incluir && pieza.Interfiere && !invalida && r.Width > 12 && r.Height > 12)
                using (var aviso = new SolidBrush(Color.FromArgb(235, 150, 40)))
                    g.FillEllipse(aviso, r.Right - 10, r.Top + 3, 7, 7);
            if (seleccionada && r.Width > 38 && r.Height > 18)
                using (var fuente = new Font("Segoe UI Semibold", 7.5F)) g.DrawString("F" + (pieza.Fila + 1), fuente, Brushes.White, r.X + 3, r.Y + 2);
        }

        private void PintarRejilla(Graphics g)
        {
            double pasoCm = 10; while (pasoCm / 30.48 * escala < 42) pasoCm *= 2; while (pasoCm / 30.48 * escala > 160 && pasoCm > 0.1) pasoCm /= 2;
            double p = pasoCm / 30.48;
            var min = Modelo(new Point(0, lienzo.Height)); var max = Modelo(new Point(lienzo.Width, 0));
            using (var pen = new Pen(Color.FromArgb(226, 234, 239), 1F))
            using (var fuente = new Font("Segoe UI", 7F))
            {
                int n = 0;
                for (double x = Math.Floor(min.X / p) * p; x <= max.X && n++ < 250; x += p)
                { float sx = Pantalla(new LadrilloPunto(x, 0)).X; g.DrawLine(pen, sx, 0, sx, lienzo.Height); g.DrawString(Cm(x), fuente, Brushes.LightSlateGray, sx + 3, lienzo.Height - 14); }
                n = 0;
                for (double y = Math.Floor(min.Y / p) * p; y <= max.Y && n++ < 250; y += p)
                { float sy = Pantalla(new LadrilloPunto(0, y)).Y; g.DrawLine(pen, 0, sy, lienzo.Width, sy); g.DrawString(Cm(y), fuente, Brushes.LightSlateGray, 3, sy + 2); }
            }
        }

        private GraphicsPath Camino(IEnumerable<IList<LadrilloPunto>> anillos)
        {
            var path = new GraphicsPath(FillMode.Alternate);
            foreach (var anillo in anillos) if (anillo != null && anillo.Count >= 3) path.AddPolygon(anillo.Select(Pantalla).ToArray());
            return path;
        }
        private RectangleF Rectangulo(LadrilloPunto centro, double du = 0, double dv = 0)
        {
            PointF a = Pantalla(new LadrilloPunto(centro.X + du - largo / 2, centro.Y + dv + ancho / 2));
            PointF b = Pantalla(new LadrilloPunto(centro.X + du + largo / 2, centro.Y + dv - ancho / 2));
            return RectangleF.FromLTRB(a.X, a.Y, b.X, b.Y);
        }
        private PointF Pantalla(LadrilloPunto p) { return new PointF(Pixel(offsetX + p.X * escala), Pixel(offsetY - p.Y * escala)); }
        private LadrilloPunto Modelo(Point p) { return new LadrilloPunto((p.X - offsetX) / escala, (offsetY - p.Y) / escala); }
        private int Buscar(Point p)
        {
            LadrilloPunto uv = Modelo(p);
            for (int i = editor.Piezas.Count - 1; i >= 0; i--) if (Math.Abs(uv.X - editor.Piezas[i].Centro.X) <= largo / 2 && Math.Abs(uv.Y - editor.Piezas[i].Centro.Y) <= ancho / 2) return editor.Piezas[i].Id;
            return -1;
        }

        private void RatonAbajo(object sender, Forms.MouseEventArgs e)
        {
            if (!vistaAjustada) return;
            lienzo.Focus(); ayuda.Hide(lienzo); inicioRaton = ultimoRaton = e.Location; inicioUV = Modelo(e.Location); arrastreU = arrastreV = 0;
            if (e.Button == Forms.MouseButtons.Middle || (e.Button == Forms.MouseButtons.Left && espacio)) gesto = Gesto.DesplazarVista;
            else if (e.Button == Forms.MouseButtons.Left)
            {
                int id = Buscar(e.Location); bool sumar = (ModifierKeys & Forms.Keys.Control) != 0;
                if (herramienta.SelectedIndex == 2 && (id < 0 || !editor.EstaSeleccionada(id))) { gesto = Gesto.Marco; marcoSumar = sumar; }
                else if (id >= 0)
                {
                    if (sumar || !editor.EstaSeleccionada(id))
                    {
                        if (herramienta.SelectedIndex == 0) editor.SeleccionarFila(id, sumar);
                        else if (herramienta.SelectedIndex == 3) editor.SeleccionarTodo();
                        else editor.SeleccionarPieza(id, sumar);
                    }
                    gesto = editor.EstaSeleccionada(id) ? Gesto.MoverSeleccion : Gesto.Ninguno;
                }
                else { if (!sumar) editor.LimpiarSeleccion(); gesto = Gesto.DesplazarVista; }
            }
            if (gesto != Gesto.Ninguno) lienzo.Capture = true;
            Refrescar(false);
        }
        private void MoverRaton(object sender, Forms.MouseEventArgs e)
        {
            if (!vistaAjustada) return;
            if (gesto == Gesto.DesplazarVista) { offsetX += e.X - ultimoRaton.X; offsetY += e.Y - ultimoRaton.Y; ultimoRaton = e.Location; lienzo.Cursor = Forms.Cursors.Hand; lienzo.Invalidate(); return; }
            if (gesto == Gesto.MoverSeleccion)
            {
                LadrilloPunto actual = Modelo(e.Location); arrastreU = actual.X - inicioUV.X; arrastreV = actual.Y - inicioUV.Y;
                if (ajustarPaso.Checked) { double p = (double)paso.Value / 30.48; arrastreU = Math.Round(arrastreU / p) * p; arrastreV = Math.Round(arrastreV / p) * p; }
                estado.Text = "Desplazamiento provisional  U " + Cm(arrastreU) + " cm · V " + Cm(arrastreV) + " cm. Suelta para comprobar.";
                lienzo.Cursor = Forms.Cursors.SizeAll; lienzo.Invalidate(); return;
            }
            if (gesto == Gesto.Marco) { ultimoRaton = e.Location; lienzo.Cursor = Forms.Cursors.Cross; lienzo.Invalidate(); return; }
            int id = Buscar(e.Location); if (id == ultimoHover) return; ultimoHover = id;
            if (id < 0) { ayuda.Hide(lienzo); lienzo.Cursor = Forms.Cursors.Default; return; }
            var pieza = editor.Piezas.First(x => x.Id == id); lienzo.Cursor = Forms.Cursors.SizeAll;
            ayuda.SetToolTip(lienzo, "Fila " + (pieza.Fila + 1) + " · pieza " + (pieza.Id + 1) + " · " + (pieza.Incluir ? "incluida" : "excluida") +
                "\r\nCentro U/V: " + Cm(pieza.Centro.X) + " / " + Cm(pieza.Centro.Y) + " cm\r\n" +
                (pieza.FueraContorno ? "Fuera del contorno o margen. " : "") + (pieza.SeSolapa ? "Solapamiento con otra pieza. " : "") +
                "Vecinos previstos: " + pieza.Obstaculos + ".\r\nCtrl: añadir a la selección.");
        }
        private void RatonArriba(object sender, Forms.MouseEventArgs e)
        {
            if (e.Button != Forms.MouseButtons.Left && e.Button != Forms.MouseButtons.Middle) return;
            Gesto terminado = gesto; gesto = Gesto.Ninguno; lienzo.Capture = false; lienzo.Cursor = Forms.Cursors.Default;
            if (terminado == Gesto.MoverSeleccion && (Math.Abs(e.X - inicioRaton.X) > 3 || Math.Abs(e.Y - inicioRaton.Y) > 3)) Mover(arrastreU, arrastreV);
            else if (terminado == Gesto.Marco)
            {
                LadrilloPunto a = Modelo(inicioRaton), b = Modelo(e.Location);
                editor.SeleccionarMarco(new LadrilloPunto(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y)), new LadrilloPunto(Math.Max(a.X, b.X), Math.Max(a.Y, b.Y)), marcoSumar);
            }
            arrastreU = arrastreV = 0; Refrescar(false);
        }
        private void CancelarGesto()
        { gesto = Gesto.Ninguno; arrastreU = arrastreV = 0; if (lienzo.Capture) lienzo.Capture = false; lienzo.Cursor = Forms.Cursors.Default; if (vistaAjustada) Refrescar(false); else lienzo.Invalidate(); }
        private void Rueda(object sender, Forms.MouseEventArgs e)
        {
            if (!vistaAjustada || gesto != Gesto.Ninguno) return;
            LadrilloPunto ancla = Modelo(e.Location); double nueva = Math.Max(0.00001, Math.Min(200000, escala * Math.Pow(1.2, e.Delta / 120.0)));
            offsetX = e.X - ancla.X * nueva; offsetY = e.Y + ancla.Y * nueva; escala = nueva; ultimoHover = -2; ActualizarZoom(); lienzo.Invalidate();
        }
        private void ActualizarZoom() { zoomTexto.Text = (escala / 30.48).ToString("0.##", CultureInfo.CurrentCulture) + " px/cm · Inicio: ajustar"; }

        private void TeclaLienzo(object sender, Forms.KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Forms.Keys.Z) { Editar(editor.Deshacer); e.Handled = e.SuppressKeyPress = true; }
            else if (e.Control && e.KeyCode == Forms.Keys.Y) { Editar(editor.Rehacer); e.Handled = e.SuppressKeyPress = true; }
            else if (e.Control && e.KeyCode == Forms.Keys.A) { editor.SeleccionarTodo(); Refrescar(false); e.Handled = true; }
            else if (e.KeyCode == Forms.Keys.Left) { Nudge(-1, 0); e.Handled = true; }
            else if (e.KeyCode == Forms.Keys.Right) { Nudge(1, 0); e.Handled = true; }
            else if (e.KeyCode == Forms.Keys.Up) { Nudge(0, 1); e.Handled = true; }
            else if (e.KeyCode == Forms.Keys.Down) { Nudge(0, -1); e.Handled = true; }
            else if (e.KeyCode == Forms.Keys.Delete) { Editar(delegate { editor.SetInclusionSeleccion(false); }); e.Handled = true; }
            else if (e.KeyCode == Forms.Keys.Home) { AjustarVista(); e.Handled = true; }
        }
        protected override bool ProcessCmdKey(ref Forms.Message msg, Forms.Keys keyData)
        {
            if (keyData == Forms.Keys.Escape && gesto != Gesto.Ninguno) { CancelarGesto(); Refrescar(false); return true; }
            if (!EntradaTextoActiva(this))
            {
                if (keyData == (Forms.Keys.Control | Forms.Keys.Z)) { Editar(editor.Deshacer); return true; }
                if (keyData == (Forms.Keys.Control | Forms.Keys.Y)) { Editar(editor.Rehacer); return true; }
                if (keyData == (Forms.Keys.Control | Forms.Keys.A)) { editor.SeleccionarTodo(); Refrescar(false); return true; }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private static bool EntradaTextoActiva(Forms.Control control)
        {
            if (!control.ContainsFocus) return false;
            if (control is Forms.TextBoxBase || control is Forms.UpDownBase || control is Forms.ComboBox) return true;
            foreach (Forms.Control hijo in control.Controls) if (EntradaTextoActiva(hijo)) return true;
            return false;
        }
        protected override void Dispose(bool disposing) { if (disposing) ayuda.Dispose(); base.Dispose(disposing); }
        private static Color Claro(Color c, int suma) { return Color.FromArgb(c.A, Math.Min(255, c.R + suma), Math.Min(255, c.G + suma), Math.Min(255, c.B + suma)); }
        private static float Pixel(double p) { return (float)Math.Max(-1000000, Math.Min(1000000, p)); }
        private static string Cm(double pies) { return (pies * 30.48).ToString("0.##", CultureInfo.CurrentCulture); }
        private sealed class OpcionModo { internal ModoEncuentroLadrillos Valor; public string Texto { get; private set; } internal OpcionModo(ModoEncuentroLadrillos valor, string texto) { Valor = valor; Texto = texto; } }
        private sealed class Lienzo : Forms.Control
        {
            internal Lienzo() { SetStyle(Forms.ControlStyles.UserPaint | Forms.ControlStyles.AllPaintingInWmPaint | Forms.ControlStyles.OptimizedDoubleBuffer | Forms.ControlStyles.ResizeRedraw, true); UpdateStyles(); }
            protected override bool IsInputKey(Forms.Keys keyData) { var k = keyData & Forms.Keys.KeyCode; return k == Forms.Keys.Left || k == Forms.Keys.Right || k == Forms.Keys.Up || k == Forms.Keys.Down || k == Forms.Keys.Space || base.IsInputKey(keyData); }
        }
    }
}
