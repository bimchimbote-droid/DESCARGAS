using System;
using System.Collections.Generic;
using System.Numerics;
using System.Linq;
using MYG_Addin.RecorteClipper;

namespace MYG_Addin
{
    internal struct LadrilloPunto
    {
        public readonly double X;
        public readonly double Y;

        public LadrilloPunto(double x, double y)
        {
            X = x;
            Y = y;
        }
    }

    /// <summary>
    /// Distribución en el plano UV, en pies. Los anillos usan la regla par/impar:
    /// admite exteriores desconectados y huecos sin exigir un sentido de recorrido.
    /// Cada celda se comprueba completa por diferencia de polígonos, también cuando
    /// un hueco o entrante no contiene ninguna de sus cuatro esquinas.
    /// </summary>
    internal static class LadrillosLayout
    {
        private const double Escala = 10000000.0; // resolución de 0.0000001 pies
        private const double Resolucion = 1.0 / Escala;
        private const double LimiteCoordenada = 10000000.0;

        public static List<LadrilloPunto> Generar(
            IList<IList<LadrilloPunto>> contornos, LadrilloPunto origen,
            double largoU, double anchoV, double juntaU, double viguetaV,
            double margen, int maxCandidatos, int maxLadrillos)
        {
            Positivo(largoU, "largoU");
            Positivo(anchoV, "anchoV");
            NoNegativo(juntaU, "juntaU");
            NoNegativo(viguetaV, "viguetaV");
            NoNegativo(margen, "margen");
            ValidarPunto(origen);
            if (largoU < 2 * Resolucion || anchoV < 2 * Resolucion)
                throw new ArgumentException("Las dimensiones del ladrillo son menores que la precisión geométrica.");
            if (maxCandidatos <= 0 || maxLadrillos <= 0)
                throw new ArgumentOutOfRangeException("maxCandidatos", "Los límites de cantidad deben ser positivos.");
            double pasoU = largoU + juntaU, pasoV = anchoV + viguetaV;
            Positivo(pasoU, "pasoU");
            Positivo(pasoV, "pasoV");
            if (contornos == null || contornos.Count == 0)
                throw new ArgumentException("La losa no tiene contornos válidos.", "contornos");

            var anillos = new List<List<IntPoint>>();
            double minimoX = double.PositiveInfinity, minimoY = double.PositiveInfinity;
            double maximoX = double.NegativeInfinity, maximoY = double.NegativeInfinity;
            foreach (var contorno in contornos)
            {
                if (contorno == null || contorno.Count < 3)
                    throw new ArgumentException("Cada contorno debe tener al menos tres vértices.", "contornos");
                var anillo = new List<IntPoint>();
                foreach (var punto in contorno)
                {
                    ValidarPunto(punto);
                    double x = punto.X - origen.X, y = punto.Y - origen.Y;
                    var entero = Entero(x, y);
                    if (anillo.Count == 0 || anillo[anillo.Count - 1] != entero)
                        anillo.Add(entero);
                    minimoX = Math.Min(minimoX, x);
                    maximoX = Math.Max(maximoX, x);
                    minimoY = Math.Min(minimoY, y);
                    maximoY = Math.Max(maximoY, y);
                }
                if (anillo.Count > 1 && anillo[0] == anillo[anillo.Count - 1])
                    anillo.RemoveAt(anillo.Count - 1);
                if (anillo.Count < 3 || AreaDoble(anillo).IsZero)
                    throw new ArgumentException("Un contorno no tiene área suficiente o es degenerado.", "contornos");
                anillos.Add(anillo);
            }
            var normalizador = new Clipper { StrictlySimple = true };
            if (!normalizador.AddPaths(anillos, PolyType.ptSubject, true))
                throw new ArgumentException("No se pueden procesar los contornos de la losa.", "contornos");
            var dominio = new List<List<IntPoint>>();
            if (!normalizador.Execute(ClipType.ctUnion, dominio, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo resolver el área de la losa.");
            if (dominio.Count == 0)
                throw new ArgumentException("Los contornos no delimitan un área utilizable.", "contornos");

            // El origen corresponde a una ESQUINA de celda, no al centro.
            // Los índices negativos permiten que el punto elegido esté dentro
            // del paño y que la distribución continúe hacia ambos lados.
            long iMin = Indice(Math.Ceiling((minimoX + margen - Resolucion) / pasoU));
            long iMax = Indice(Math.Floor((maximoX - margen - largoU + Resolucion) / pasoU));
            long jMin = Indice(Math.Ceiling((minimoY + margen - Resolucion) / pasoV));
            long jMax = Indice(Math.Floor((maximoY - margen - anchoV + Resolucion) / pasoV));
            var centros = new List<LadrilloPunto>();
            if (iMax < iMin || jMax < jMin)
                return centros;
            // Se calcula antes de recorrer o reservar memoria. No truncar una
            // distribución grande ni aceptar silenciosamente un resultado parcial.
            double candidatos = ((double)iMax - iMin + 1) * ((double)jMax - jMin + 1);
            if (candidatos > maxCandidatos)
                throw new InvalidOperationException("La distribución supera el límite de " + maxCandidatos +
                    " posiciones candidatas. Aumente las dimensiones/separaciones o reduzca el paño.");

            for (long j = jMin; j <= jMax; j++)
            {
                for (long i = iMin; i <= iMax; i++)
                {
                    double x = i * pasoU, y = j * pasoV;
                    // Expandir la huella exige la separación de borde/huecos
                    // también a lo largo de sus cuatro lados. El margen es
                    // conservador en esquinas (distancia rectangular).
                    var rectangulo = new List<IntPoint>
                    {
                        Entero(x - margen, y - margen),
                        Entero(x + largoU + margen, y - margen),
                        Entero(x + largoU + margen, y + anchoV + margen),
                        Entero(x - margen, y + anchoV + margen)
                    };
                    var corte = new Clipper { StrictlySimple = true };
                    corte.AddPath(rectangulo, PolyType.ptSubject, true);
                    corte.AddPaths(dominio, PolyType.ptClip, true);
                    var fuera = new List<List<IntPoint>>();
                    if (!corte.Execute(ClipType.ctDifference, fuera, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                        throw new InvalidOperationException("No se pudo comprobar una huella de ladrillo.");
                    bool contieneFuera = false;
                    foreach (var poligono in fuera)
                    {
                        // Área entera exacta: no perder huecos estrechos por
                        // cancelación numérica de áreas con coordenadas grandes.
                        if (!AreaDoble(poligono).IsZero)
                        {
                            contieneFuera = true;
                            break;
                        }
                    }
                    if (contieneFuera)
                        continue;
                    if (centros.Count >= maxLadrillos)
                        throw new InvalidOperationException("La distribución supera el límite de " + maxLadrillos +
                            " ladrillos. No se ha creado ninguna colocación parcial.");
                    centros.Add(new LadrilloPunto(origen.X + x + largoU / 2.0,
                        origen.Y + y + anchoV / 2.0));
                }
            }
            return centros;
        }

        private static bool Finito(double numero)
        {
            return !double.IsNaN(numero) && !double.IsInfinity(numero);
        }

        private static void Positivo(double numero, string nombre)
        {
            if (!Finito(numero) || numero <= 0.0)
                throw new ArgumentOutOfRangeException(nombre, "El valor debe ser finito y mayor que cero.");
        }

        private static void NoNegativo(double numero, string nombre)
        {
            if (!Finito(numero) || numero < 0.0)
                throw new ArgumentOutOfRangeException(nombre, "El valor debe ser finito y no negativo.");
        }

        private static void ValidarPunto(LadrilloPunto punto)
        {
            if (!Finito(punto.X) || !Finito(punto.Y) || Math.Abs(punto.X) > LimiteCoordenada ||
                Math.Abs(punto.Y) > LimiteCoordenada)
                throw new ArgumentException("Las coordenadas UV deben ser finitas y próximas al origen de la losa.");
        }

        private static IntPoint Entero(double x, double y)
        {
            if (!Finito(x) || !Finito(y) || Math.Abs(x) > 2 * LimiteCoordenada || Math.Abs(y) > 2 * LimiteCoordenada)
                throw new ArgumentException("La extensión de los contornos supera el rango geométrico admitido.");
            return new IntPoint((long)Math.Round(x * Escala, MidpointRounding.AwayFromZero),
                (long)Math.Round(y * Escala, MidpointRounding.AwayFromZero));
        }

        private static long Indice(double numero)
        {
            if (!Finito(numero) || Math.Abs(numero) > 1000000000000000.0)
                throw new ArgumentException("La malla requiere índices fuera del rango admitido.");
            return (long)numero;
        }

        private static BigInteger AreaDoble(List<IntPoint> puntos)
        {
            BigInteger suma = BigInteger.Zero;
            for (int i = 0; i < puntos.Count; i++)
            {
                IntPoint a = puntos[i], b = puntos[(i + 1) % puntos.Count];
                suma += (BigInteger)a.X * b.Y - (BigInteger)a.Y * b.X;
            }
            return suma;
        }
    }

    /// <summary>
    /// Decide la cota de la base medida de la familia, en pies. Una familia
    /// hospedada conserva por defecto la misma altura que le asigna Revit al
    /// insertarla manualmente, aunque su geometría quede por encima o por
    /// debajo del espesor de la losa. El ajuste al intradós es una opción
    /// explícita; las familias sin anfitrión necesitan siempre ese ajuste.
    /// </summary>
    internal static class LadrillosAltura
    {
        private const double Tolerancia = 1e-6;

        internal static double CalcularBase(bool hospedado, bool ajustarBaseAlIntrados,
            double baseNativa, double inferior, double superior, double alto, double desfasePies)
        {
            ValidarFinito(baseNativa, "baseNativa");
            ValidarFinito(inferior, "inferior");
            ValidarFinito(superior, "superior");
            ValidarFinito(alto, "alto");
            ValidarFinito(desfasePies, "desfasePies");
            if (alto <= 0)
                throw new ArgumentOutOfRangeException("alto", "La familia debe tener una altura mayor que cero.");
            if (superior <= inferior)
                throw new ArgumentException("Las caras superior e inferior no delimitan un espesor de losa válido.");
            if (desfasePies < 0)
                throw new ArgumentOutOfRangeException("desfasePies", "El desfase desde el intradós no puede ser negativo.");

            if (hospedado && !ajustarBaseAlIntrados)
                return baseNativa;

            double baseAjustada = inferior + desfasePies;
            double cimaAjustada = baseAjustada + alto;
            ValidarFinito(baseAjustada, "baseAjustada");
            ValidarFinito(cimaAjustada, "cimaAjustada");
            if (baseAjustada < inferior - Tolerancia || cimaAjustada > superior + Tolerancia)
                throw new InvalidOperationException("El ladrillo no cabe dentro del espesor disponible " +
                    "con el ajuste al intradós y el desfase elegidos. Reduce el desfase, elige un tipo " +
                    "de menor altura o desactiva el ajuste al intradós para conservar la colocación " +
                    "nativa de una familia hospedada en suelo.");
            return baseAjustada;
        }

        private static void ValidarFinito(double valor, string nombre)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                throw new ArgumentOutOfRangeException(nombre, "La cota, altura o desfase debe ser un número finito.");
        }
    }

    internal struct LadrilloDesplazamiento
    {
        internal readonly double U;
        internal readonly double V;
        internal readonly double Z;

        internal LadrilloDesplazamiento(double u, double v, double z)
        {
            U = u;
            V = v;
            Z = z;
        }
    }

    /// <summary>
    /// Corrige cada instancia desde su centro físico recién medido. No supone
    /// que su origen de inserción coincida con el centro ni que varias copias
    /// hospedadas conserven el mismo desfase respecto a una plantilla.
    /// </summary>
    internal static class LadrillosAlineacion
    {
        internal static LadrilloDesplazamiento CalcularCorreccion(LadrilloPunto destino,
            LadrilloPunto centroReal, double baseReal, double baseDeseada, bool ajustarBase)
        {
            ValidarFinito(destino.X, "destino.X");
            ValidarFinito(destino.Y, "destino.Y");
            ValidarFinito(centroReal.X, "centroReal.X");
            ValidarFinito(centroReal.Y, "centroReal.Y");
            ValidarFinito(baseReal, "baseReal");
            ValidarFinito(baseDeseada, "baseDeseada");
            double u = destino.X - centroReal.X;
            double v = destino.Y - centroReal.Y;
            double z = ajustarBase ? baseDeseada - baseReal : 0.0;
            ValidarFinito(u, "correccion.U");
            ValidarFinito(v, "correccion.V");
            ValidarFinito(z, "correccion.Z");
            return new LadrilloDesplazamiento(u, v, z);
        }

        private static void ValidarFinito(double valor, string nombre)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                throw new ArgumentOutOfRangeException(nombre, "La posición medida y su corrección deben ser finitas.");
        }
    }

    /// <summary>Una pieza editable conserva su identidad y fila original al moverla.</summary>
    internal sealed class LadrilloEditable
    {
        internal readonly int Id;
        internal readonly int Fila;
        internal readonly LadrilloPunto Original;
        internal LadrilloPunto Centro;
        internal bool Incluir = true;
        internal bool FueraContorno;
        internal bool SeSolapa;
        internal bool Interfiere;
        internal int Obstaculos;

        internal LadrilloEditable(int id, int fila, LadrilloPunto centro)
        { Id = id; Fila = fila; Original = Centro = centro; }
    }

    /// <summary>
    /// Estado geométrico del editor en pies UV. Los cambios no modifican Revit.
    /// Permite conservar una edición inválida visible para corregirla; nunca la
    /// confunde con una selección que pueda crearse ni descarta piezas en silencio.
    /// </summary>
    internal sealed class LadrillosEditor
    {
        private const double Escala = 10000000.0;
        private const double Resolucion = 1.0 / Escala;
        private const double ToleranciaFila = 1e-6;
        private const double MaxCoordenada = 10000000.0;
        private const int MaxHistorial = 100;
        private readonly List<LadrilloEditable> piezas = new List<LadrilloEditable>();
        private readonly HashSet<int> seleccion = new HashSet<int>();
        private readonly List<List<IntPoint>> dominio;
        private readonly List<Estado> anteriores = new List<Estado>();
        private readonly List<Estado> siguientes = new List<Estado>();
        private readonly LadrilloPunto[] ultimaComprobacion;
        private readonly bool[] comprobada;
        private readonly bool[] fueraBase;
        private readonly double largo, ancho, margen;
        private Estado edicion;

        internal IReadOnlyList<LadrilloEditable> Piezas { get; private set; }
        internal IReadOnlyCollection<int> Seleccion { get { return seleccion.ToArray(); } }
        internal bool HaySeleccion { get { return seleccion.Count > 0; } }
        internal bool PuedeDeshacer { get { return edicion == null && anteriores.Count > 0; } }
        internal bool PuedeRehacer { get { return edicion == null && siguientes.Count > 0; } }
        internal int InvalidasIncluidas { get { return piezas.Count(x => x.Incluir && (x.FueraContorno || x.SeSolapa)); } }
        internal bool PuedeCrear { get { return piezas.Any(x => x.Incluir) && InvalidasIncluidas == 0; } }

        internal LadrillosEditor(IList<IList<LadrilloPunto>> contornos, IList<LadrilloPunto> centros,
            double largo, double ancho, double margen, double juntaU, double viguetaV)
        {
            Positivo(largo, "largo"); Positivo(ancho, "ancho");
            NoNegativo(margen, "margen"); NoNegativo(juntaU, "juntaU"); NoNegativo(viguetaV, "viguetaV");
            if (largo < 2 * Resolucion || ancho < 2 * Resolucion)
                throw new ArgumentOutOfRangeException("largo", "La pieza es menor que la precisión geométrica del editor.");
            if (centros == null || centros.Count > 10000)
                throw new ArgumentException("El editor admite hasta 10.000 piezas.", "centros");
            this.largo = largo; this.ancho = ancho; this.margen = margen;
            dominio = PrepararDominio(contornos);
            for (int i = 0; i < centros.Count; i++) ValidarPunto(centros[i]);
            var filas = new int[centros.Count];
            int fila = -1; double vFila = 0;
            foreach (int i in Enumerable.Range(0, centros.Count).OrderBy(i => centros[i].Y).ThenBy(i => centros[i].X))
            {
                if (fila < 0 || Math.Abs(centros[i].Y - vFila) > ToleranciaFila)
                { fila++; vFila = centros[i].Y; }
                filas[i] = fila;
            }
            for (int i = 0; i < centros.Count; i++) piezas.Add(new LadrilloEditable(i, filas[i], centros[i]));
            Piezas = piezas.AsReadOnly();
            ultimaComprobacion = new LadrilloPunto[centros.Count];
            comprobada = new bool[centros.Count];
            fueraBase = new bool[centros.Count];
            Validar();
        }

        internal bool EstaSeleccionada(int id) { Pieza(id); return seleccion.Contains(id); }
        internal void SeleccionarPieza(int id, bool sumar)
        { Pieza(id); if (!sumar) seleccion.Clear(); seleccion.Add(id); }
        internal void SeleccionarFila(int id, bool sumar)
        {
            int fila = Pieza(id).Fila;
            if (!sumar) seleccion.Clear();
            foreach (var pieza in piezas) if (pieza.Fila == fila) seleccion.Add(pieza.Id);
        }
        internal void SeleccionarMarco(LadrilloPunto minimo, LadrilloPunto maximo, bool sumar)
        {
            ValidarPunto(minimo); ValidarPunto(maximo);
            double minU = Math.Min(minimo.X, maximo.X), maxU = Math.Max(minimo.X, maximo.X);
            double minV = Math.Min(minimo.Y, maximo.Y), maxV = Math.Max(minimo.Y, maximo.Y);
            if (!sumar) seleccion.Clear();
            foreach (var pieza in piezas)
                if (pieza.Centro.X >= minU - Resolucion && pieza.Centro.X <= maxU + Resolucion &&
                    pieza.Centro.Y >= minV - Resolucion && pieza.Centro.Y <= maxV + Resolucion)
                    seleccion.Add(pieza.Id);
        }
        internal void SeleccionarTodo() { seleccion.Clear(); foreach (var pieza in piezas) seleccion.Add(pieza.Id); }
        internal void LimpiarSeleccion() { seleccion.Clear(); }

        internal void MoverSeleccion(double du, double dv, bool registrar = true)
        {
            Finito(du, "du"); Finito(dv, "dv");
            if (!registrar && edicion == null)
                throw new InvalidOperationException("Inicia una edición antes de agrupar movimientos sin historial individual.");
            if (registrar && edicion != null)
                throw new InvalidOperationException("La edición agrupada debe moverse con registrar=false.");
            var destinos = new Dictionary<int, LadrilloPunto>();
            foreach (int id in seleccion)
            {
                var destino = new LadrilloPunto(piezas[id].Centro.X + du, piezas[id].Centro.Y + dv);
                ValidarPunto(destino); destinos.Add(id, destino);
            }
            Ejecutar(() =>
            {
                foreach (var destino in destinos)
                {
                    piezas[destino.Key].Centro = destino.Value;
                    piezas[destino.Key].Interfiere = false; piezas[destino.Key].Obstaculos = 0;
                }
            }, registrar);
        }
        internal void SetInclusionSeleccion(bool incluir)
        { Ejecutar(() => { foreach (int id in seleccion) piezas[id].Incluir = incluir; }); }
        internal void IncluirTodo(bool incluir)
        { Ejecutar(() => { foreach (var pieza in piezas) pieza.Incluir = incluir; }); }
        internal void RestablecerSeleccion()
        { Ejecutar(() => { foreach (int id in seleccion) Restablecer(piezas[id]); }); }
        internal void RestablecerTodo()
        { Ejecutar(() => { foreach (var pieza in piezas) Restablecer(pieza); }); }
        private static void Restablecer(LadrilloEditable pieza)
        { pieza.Centro = pieza.Original; pieza.Incluir = true; pieza.Interfiere = false; pieza.Obstaculos = 0; }

        internal void IniciarEdicion()
        {
            if (edicion != null) throw new InvalidOperationException("Ya hay una edición agrupada en curso.");
            edicion = Capturar();
        }
        internal void ConfirmarEdicion()
        {
            if (edicion == null) throw new InvalidOperationException("No hay una edición agrupada en curso.");
            Estado antes = edicion; edicion = null; GuardarCambio(antes);
        }
        internal void CancelarEdicion()
        {
            if (edicion == null) return;
            Estado antes = edicion; edicion = null; Restaurar(antes);
        }
        internal void Deshacer()
        {
            ExigirEdicionCerrada();
            if (anteriores.Count == 0) return;
            siguientes.Add(Capturar());
            Estado antes = anteriores[anteriores.Count - 1]; anteriores.RemoveAt(anteriores.Count - 1); Restaurar(antes);
        }
        internal void Rehacer()
        {
            ExigirEdicionCerrada();
            if (siguientes.Count == 0) return;
            anteriores.Add(Capturar());
            Estado despues = siguientes[siguientes.Count - 1]; siguientes.RemoveAt(siguientes.Count - 1); Restaurar(despues);
        }
        private void ExigirEdicionCerrada()
        { if (edicion != null) throw new InvalidOperationException("Confirma o cancela la edición agrupada antes de deshacer/rehacer."); }
        private void Ejecutar(Action cambio, bool registrar = true)
        {
            Estado respaldo = Capturar();
            try { cambio(); Validar(); }
            catch { Restaurar(respaldo); throw; }
            if (registrar && edicion == null) GuardarCambio(respaldo);
        }
        private void GuardarCambio(Estado antes)
        {
            if (Igual(antes)) return;
            anteriores.Add(antes);
            if (anteriores.Count > MaxHistorial) anteriores.RemoveAt(0);
            siguientes.Clear();
        }
        private bool Igual(Estado estado)
        {
            for (int i = 0; i < piezas.Count; i++)
                if (piezas[i].Centro.X != estado.Centros[i].X || piezas[i].Centro.Y != estado.Centros[i].Y ||
                    piezas[i].Incluir != estado.Incluidas[i]) return false;
            return true;
        }
        private Estado Capturar()
        {
            return new Estado { Centros = piezas.Select(x => x.Centro).ToArray(),
                Incluidas = piezas.Select(x => x.Incluir).ToArray(), Seleccion = seleccion.ToArray() };
        }
        private void Restaurar(Estado estado)
        {
            for (int i = 0; i < piezas.Count; i++)
            {
                piezas[i].Centro = estado.Centros[i]; piezas[i].Incluir = estado.Incluidas[i];
                piezas[i].Interfiere = false; piezas[i].Obstaculos = 0;
            }
            seleccion.Clear(); foreach (int id in estado.Seleccion) seleccion.Add(id);
            Validar();
        }
        private sealed class Estado
        { internal LadrilloPunto[] Centros; internal bool[] Incluidas; internal int[] Seleccion; }

        internal void Validar()
        {
            foreach (var pieza in piezas)
            {
                ValidarPunto(pieza.Centro);
                if (!comprobada[pieza.Id] || ultimaComprobacion[pieza.Id].X != pieza.Centro.X ||
                    ultimaComprobacion[pieza.Id].Y != pieza.Centro.Y)
                {
                    fueraBase[pieza.Id] = !Contiene(pieza.Centro);
                    ultimaComprobacion[pieza.Id] = pieza.Centro; comprobada[pieza.Id] = true;
                }
                pieza.FueraContorno = fueraBase[pieza.Id];
                pieza.SeSolapa = false;
            }
            double paso = Math.Max(largo, ancho);
            var indice = new Dictionary<Celda, List<int>>();
            foreach (var pieza in piezas)
            {
                if (!pieza.Incluir) continue;
                long u0, u1, v0, v1; Limites(pieza.Centro, paso, out u0, out u1, out v0, out v1);
                for (long u = u0; u <= u1; u++) for (long v = v0; v <= v1; v++)
                {
                    var clave = new Celda(u, v); List<int> lista;
                    if (!indice.TryGetValue(clave, out lista)) indice.Add(clave, lista = new List<int>());
                    lista.Add(pieza.Id);
                }
            }
            // Buscar un vecino real por pieza, no enumerar todos los pares de
            // una celda congestionada. Esto mantiene útil el editor de 10k piezas.
            foreach (var pieza in piezas)
            {
                if (!pieza.Incluir) continue;
                long u0, u1, v0, v1; Limites(pieza.Centro, paso, out u0, out u1, out v0, out v1);
                var vistos = new HashSet<int>(); bool encontrado = false;
                for (long u = u0; u <= u1 && !encontrado; u++) for (long v = v0; v <= v1 && !encontrado; v++)
                {
                    List<int> lista;
                    if (!indice.TryGetValue(new Celda(u, v), out lista)) continue;
                    foreach (int id in lista)
                    {
                        if (id == pieza.Id || !vistos.Add(id)) continue;
                        var otra = piezas[id];
                        double comunU = largo - Math.Abs(pieza.Centro.X - otra.Centro.X);
                        double comunV = ancho - Math.Abs(pieza.Centro.Y - otra.Centro.Y);
                        if (comunU > Resolucion && comunV > Resolucion && comunU * comunV > Resolucion * Resolucion)
                        { pieza.SeSolapa = true; encontrado = true; break; }
                    }
                }
            }
        }
        private void Limites(LadrilloPunto centro, double paso, out long u0, out long u1, out long v0, out long v1)
        {
            u0 = (long)Math.Floor((centro.X - largo / 2) / paso); u1 = (long)Math.Floor((centro.X + largo / 2) / paso);
            v0 = (long)Math.Floor((centro.Y - ancho / 2) / paso); v1 = (long)Math.Floor((centro.Y + ancho / 2) / paso);
        }
        private struct Celda : IEquatable<Celda>
        {
            private readonly long u, v;
            internal Celda(long u, long v) { this.u = u; this.v = v; }
            public bool Equals(Celda otra) { return u == otra.u && v == otra.v; }
            public override bool Equals(object otra) { return otra is Celda && Equals((Celda)otra); }
            public override int GetHashCode() { unchecked { return u.GetHashCode() * 397 ^ v.GetHashCode(); } }
        }
        private bool Contiene(LadrilloPunto centro)
        {
            var huella = new List<IntPoint> { Entero(centro.X - largo / 2 - margen, centro.Y - ancho / 2 - margen),
                Entero(centro.X + largo / 2 + margen, centro.Y - ancho / 2 - margen),
                Entero(centro.X + largo / 2 + margen, centro.Y + ancho / 2 + margen),
                Entero(centro.X - largo / 2 - margen, centro.Y + ancho / 2 + margen) };
            var clipper = new Clipper { StrictlySimple = true };
            clipper.AddPath(huella, PolyType.ptSubject, true); clipper.AddPaths(dominio, PolyType.ptClip, true);
            var fuera = new List<List<IntPoint>>();
            if (!clipper.Execute(ClipType.ctDifference, fuera, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo comprobar una posición editada contra el contorno.");
            return fuera.All(x => AreaDoble(x).IsZero);
        }
        private static List<List<IntPoint>> PrepararDominio(IList<IList<LadrilloPunto>> contornos)
        {
            if (contornos == null || contornos.Count == 0) throw new ArgumentException("El editor necesita el contorno de la losa.");
            var entrada = new List<List<IntPoint>>();
            foreach (var anillo in contornos)
            {
                if (anillo == null || anillo.Count < 3) throw new ArgumentException("Un contorno tiene menos de tres puntos.");
                var enteros = new List<IntPoint>();
                foreach (var punto in anillo) { ValidarPunto(punto); var entero = Entero(punto.X, punto.Y); if (enteros.Count == 0 || enteros[enteros.Count - 1] != entero) enteros.Add(entero); }
                if (enteros.Count > 1 && enteros[0] == enteros[enteros.Count - 1]) enteros.RemoveAt(enteros.Count - 1);
                if (enteros.Count < 3 || AreaDoble(enteros).IsZero) throw new ArgumentException("Un contorno no tiene área válida.");
                entrada.Add(enteros);
            }
            var clipper = new Clipper { StrictlySimple = true }; clipper.AddPaths(entrada, PolyType.ptSubject, true);
            var salida = new List<List<IntPoint>>();
            if (!clipper.Execute(ClipType.ctUnion, salida, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd) || salida.Count == 0)
                throw new ArgumentException("Los contornos no delimitan una región válida.");
            return salida;
        }
        private static BigInteger AreaDoble(List<IntPoint> camino)
        {
            BigInteger area = BigInteger.Zero;
            for (int i = 0; i < camino.Count; i++)
            { var a = camino[i]; var b = camino[(i + 1) % camino.Count]; area += (BigInteger)a.X * b.Y - (BigInteger)a.Y * b.X; }
            return area;
        }
        private static IntPoint Entero(double u, double v)
        {
            if (Math.Abs(u) > 2 * MaxCoordenada || Math.Abs(v) > 2 * MaxCoordenada)
                throw new ArgumentException("La huella editada supera el rango geométrico admitido.");
            return new IntPoint((long)Math.Round(u * Escala, MidpointRounding.AwayFromZero),
                (long)Math.Round(v * Escala, MidpointRounding.AwayFromZero));
        }
        private LadrilloEditable Pieza(int id)
        { if (id < 0 || id >= piezas.Count) throw new ArgumentOutOfRangeException("id"); return piezas[id]; }
        private static void ValidarPunto(LadrilloPunto punto)
        {
            Finito(punto.X, "U"); Finito(punto.Y, "V");
            if (Math.Abs(punto.X) > MaxCoordenada || Math.Abs(punto.Y) > MaxCoordenada)
                throw new ArgumentOutOfRangeException("punto", "La posición debe estar próxima al origen de la losa.");
        }
        private static void Finito(double valor, string nombre)
        { if (double.IsNaN(valor) || double.IsInfinity(valor)) throw new ArgumentOutOfRangeException(nombre, "El valor debe ser finito."); }
        private static void Positivo(double valor, string nombre)
        { Finito(valor, nombre); if (valor <= 0) throw new ArgumentOutOfRangeException(nombre, "La dimensión debe ser positiva."); }
        private static void NoNegativo(double valor, string nombre)
        { Finito(valor, nombre); if (valor < 0) throw new ArgumentOutOfRangeException(nombre, "La separación no puede ser negativa."); }
    }

}
