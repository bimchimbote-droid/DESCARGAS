using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin;

internal static class Program
{
    private static int passed;
    private static int failed;

    private static void Main()
    {
        Run("simple rectangle, exact boundary contact", () => Count(Domain(Rect(0, 0, 10, 10)), 2, 2) == 25);
        Run("negative grid indices from an interior origin", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(4, 4), 2, 2);
            return centers.Count == 25 && centers.Any(p => Near(p.X, 1) && Near(p.Y, 1)) &&
                centers.Any(p => Near(p.X, 9) && Near(p.Y, 9));
        });
        Run("joist width is additional clear spacing", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 6, 5)), new LadrilloPunto(0, 0), 2, 1, 0, 1);
            return centers.Count == 9 && centers.Select(p => p.Y).Distinct().OrderBy(y => y).SequenceEqual(new[] { 0.5, 2.5, 4.5 });
        });
        Run("longitudinal joint adds to length", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 8, 2)), new LadrilloPunto(0, 0), 2, 2, 1);
            return centers.Count == 3 && centers.Select(p => p.X).SequenceEqual(new[] { 1.0, 4.0, 7.0 });
        });
        Run("small interior hole invisible to rectangle corners", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 6, 6), Rect(2.8, 2.8, 3.2, 3.2)), new LadrilloPunto(0, 0), 2, 2);
            return centers.Count == 8 && !centers.Any(p => Near(p.X, 3) && Near(p.Y, 3));
        });
        Run("concave notch crossing rectangle edge", () =>
        {
            var notch = Points(0, 0, 4, 0, 4, 4, 2.2, 4, 2.2, 1, 1.8, 1, 1.8, 4, 0, 4);
            return Count(Domain(notch), 4, 2) == 0;
        });
        Run("L shaped region", () =>
        {
            var outline = Points(0, 0, 6, 0, 6, 2, 2, 2, 2, 6, 0, 6);
            return Count(Domain(outline), 2, 2) == 5;
        });
        Run("hole edge contact without area overlap", () => Count(Domain(Rect(0, 0, 6, 6), Rect(2, 2, 4, 4)), 2, 2) == 8);
        Run("ring winding does not change holes", () =>
        {
            var outer = Rect(0, 0, 6, 6); var hole = Rect(2, 2, 4, 4);
            outer.Reverse(); hole.Reverse();
            return Count(Domain(outer, hole), 2, 2) == 8;
        });
        Run("separate floor islands do not bridge", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 2, 2), Rect(4, 0, 6, 2)), new LadrilloPunto(0, 0), 2, 2);
            return centers.Count == 2 && centers.All(p => !Near(p.X, 3));
        });
        Run("border margin excludes edge bricks", () => Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, 0, 0, 0.1).Count == 9);
        Run("margin protects opening edges", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 8, 8), Rect(3.9, 3.9, 4.1, 4.1)), new LadrilloPunto(0, 0), 2, 2, 0, 0, 0.2);
            return centers.Count == 0; // only four interior cells exist; each approaches the central opening
        });
        Run("origin shifted to margin retains intended first cell", () => Generate(Domain(Rect(0, 0, 6.2, 6.2)), new LadrilloPunto(0.1, 0.1), 2, 2, 0, 0, 0.1).Count == 9);
        Run("too small region returns an empty layout", () => Count(Domain(Rect(0, 0, 0.5, 1)), 2, 2) == 0);
        Run("invariant after projection of a rotated floor", () =>
        {
            double angle = 0.731, ux = Math.Cos(angle), uy = Math.Sin(angle), vx = -uy, vy = ux;
            var projected = new List<LadrilloPunto>();
            foreach (var p in Rect(0, 0, 6, 4))
            {
                double wx = 100 + p.X * ux + p.Y * vx, wy = -50 + p.X * uy + p.Y * vy;
                projected.Add(new LadrilloPunto((wx - 100) * ux + (wy + 50) * uy,
                    (wx - 100) * vx + (wy + 50) * vy));
            }
            return Count(Domain(projected), 2, 2) == 6;
        });
        Run("translation invariance at remote local coordinates", () =>
        {
            var centers = Generate(Domain(Rect(1000000, 1000000, 1000006, 1000004)), new LadrilloPunto(1000000, 1000000), 2, 2);
            return centers.Count == 6 && Near(centers[0].X, 1000001);
        });
        Run("narrow slot is never bridged", () =>
        {
            var outline = Rect(0, 0, 6, 6); var slot = Rect(2.99999, 0.5, 3.00001, 5.5);
            return Count(Domain(outline, slot), 2, 2) == 6;
        });
        Run("no artificial loss from an explicitly closed ring", () =>
        {
            var ring = Rect(0, 0, 4, 4); ring.Add(ring[0]);
            return Count(Domain(ring), 2, 2) == 4;
        });
        Run("candidate guard fails before enumerating massive grid", () => Throws<InvalidOperationException>(() => Generate(Domain(Rect(0, 0, 1000000, 1000000)), new LadrilloPunto(0, 0), 0.01, 0.01)));
        Run("accepted brick guard rejects whole result", () => Throws<InvalidOperationException>(() => LadrillosLayout.Generar(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, 0, 0, 0, 100, 5)));
        Run("negative spacing is rejected", () => Throws<ArgumentOutOfRangeException>(() => Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, -1)));
        Run("NaN dimension is rejected", () => Throws<ArgumentOutOfRangeException>(() => Count(Domain(Rect(0, 0, 10, 10)), double.NaN, 2)));
        Run("infinite margin is rejected", () => Throws<ArgumentOutOfRangeException>(() => Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, 0, 0, double.PositiveInfinity)));
        Run("zero joist and joint values are allowed", () => Count(Domain(Rect(0, 0, 4, 4)), 2, 2) == 4);
        Run("zero side is rejected", () => Throws<ArgumentOutOfRangeException>(() => Count(Domain(Rect(0, 0, 10, 10)), 0, 2)));
        Run("invalid contour is rejected", () => Throws<ArgumentException>(() => Count(Domain(Points(0, 0, 1, 1)), 2, 2)));
        Run("nonfinite contour coordinate is rejected", () => Throws<ArgumentException>(() => Count(Domain(Points(0, 0, 1, 0, double.NaN, 1)), 2, 2)));
        Run("hosted native insertion above floor is preserved", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 20, 10, 11, 0.5, 0), 20));
        Run("hosted native insertion below floor is preserved", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 5, 10, 11, 0.5, 0), 5));
        Run("oversized hosted native family is allowed", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 11, 10, 11, 2, 0), 11));
        Run("native placement ignores an unused positive intrados offset", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 11, 10, 11, 0.5, 100), 11));
        Run("explicit hosted adjustment uses intrados plus offset", () =>
            Near(LadrillosAltura.CalcularBase(true, true, 20, 10, 11, 0.5, 0.2), 10.2));
        Run("unhosted family requires adjustment even with option off", () =>
            Near(LadrillosAltura.CalcularBase(false, false, 20, 10, 11, 0.5, 0.2), 10.2));
        Run("unhosted family with explicit adjustment uses same base", () =>
            Near(LadrillosAltura.CalcularBase(false, true, 20, 10, 11, 0.5, 0.2), 10.2));
        Run("oversized explicitly adjusted family is rejected", () =>
            Throws<InvalidOperationException>(() => LadrillosAltura.CalcularBase(true, true, 11, 10, 11, 2, 0)));
        Run("oversized unhosted family is rejected", () =>
            Throws<InvalidOperationException>(() => LadrillosAltura.CalcularBase(false, false, 11, 10, 11, 2, 0)));
        Run("negative intrados offset is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, true, 11, 10, 11, 0.5, -0.1)));
        Run("negative offset is rejected even in native mode", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, 11, 10, 11, 0.5, -0.1)));
        Run("height at tolerance boundary remains accepted", () =>
            Near(LadrillosAltura.CalcularBase(true, true, 20, 10, 11, 1 + 0.5e-6, 0), 10));
        Run("height beyond tolerance is rejected", () =>
            Throws<InvalidOperationException>(() => LadrillosAltura.CalcularBase(true, true, 20, 10, 11, 1 + 2e-6, 0)));
        Run("nonfinite native elevation is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, double.NaN, 10, 11, 0.5, 0)));
        Run("nonfinite height is rejected in native mode", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, 20, 10, 11, double.PositiveInfinity, 0)));
        Run("zero height is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, 20, 10, 11, 0, 0)));
        Run("invalid floor thickness is rejected", () =>
            Throws<ArgumentException>(() => LadrillosAltura.CalcularBase(true, false, 20, 11, 10, 0.5, 0)));
        Run("each measured brick receives its own XY correction", () =>
        {
            var first = LadrillosAlineacion.CalcularCorreccion(new LadrilloPunto(10, 20),
                new LadrilloPunto(9.9, 20.1), 1, 1, false);
            var second = LadrillosAlineacion.CalcularCorreccion(new LadrilloPunto(15, 25),
                new LadrilloPunto(14.6, 25.3), 1, 1, false);
            return Near(first.U, 0.1) && Near(first.V, -0.1) &&
                Near(second.U, 0.4) && Near(second.V, -0.3) && !Near(first.U, second.U);
        });
        Run("applying individual correction reaches requested center", () =>
        {
            var destination = new LadrilloPunto(-25, 13);
            var actual = new LadrilloPunto(-22.5, 12.25);
            var correction = LadrillosAlineacion.CalcularCorreccion(destination, actual, 1, 1, false);
            return Near(actual.X + correction.U, destination.X) && Near(actual.Y + correction.V, destination.Y);
        });
        Run("explicit base adjustment adds independent Z correction", () =>
        {
            var correction = LadrillosAlineacion.CalcularCorreccion(new LadrilloPunto(3, 4),
                new LadrilloPunto(2, 6), 10.3, 10.1, true);
            return Near(correction.U, 1) && Near(correction.V, -2) && Near(correction.Z, -0.2);
        });
        Run("native placement does not change Z despite large elevation difference", () =>
        {
            var correction = LadrillosAlineacion.CalcularCorreccion(new LadrilloPunto(3, 4),
                new LadrilloPunto(2, 6), -1000000, 1000000, false);
            return Near(correction.U, 1) && Near(correction.V, -2) && correction.Z == 0;
        });
        Run("native placement does not compute an unused overflowing Z delta", () =>
            LadrillosAlineacion.CalcularCorreccion(new LadrilloPunto(0, 0), new LadrilloPunto(0, 0),
                -double.MaxValue, double.MaxValue, false).Z == 0);
        Run("already aligned instance requires zero displacement", () =>
        {
            var correction = LadrillosAlineacion.CalcularCorreccion(new LadrilloPunto(2, -5),
                new LadrilloPunto(2, -5), 10, 10, true);
            return correction.U == 0 && correction.V == 0 && correction.Z == 0;
        });
        Run("nonfinite target position is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAlineacion.CalcularCorreccion(
                new LadrilloPunto(double.NaN, 0), new LadrilloPunto(0, 0), 1, 1, false)));
        Run("nonfinite measured center is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAlineacion.CalcularCorreccion(
                new LadrilloPunto(0, 0), new LadrilloPunto(0, double.PositiveInfinity), 1, 1, false)));
        Run("nonfinite measured base is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAlineacion.CalcularCorreccion(
                new LadrilloPunto(0, 0), new LadrilloPunto(0, 0), double.NaN, 1, false)));
        Run("nonfinite requested base is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAlineacion.CalcularCorreccion(
                new LadrilloPunto(0, 0), new LadrilloPunto(0, 0), 1, double.PositiveInfinity, false)));
        Run("overflowing XY correction is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAlineacion.CalcularCorreccion(
                new LadrilloPunto(double.MaxValue, 0), new LadrilloPunto(-double.MaxValue, 0), 1, 1, false)));
        Run("overflowing requested Z correction is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAlineacion.CalcularCorreccion(
                new LadrilloPunto(0, 0), new LadrilloPunto(0, 0), -double.MaxValue, double.MaxValue, true)));

        Run("editor assigns stable rows independent of input order", () =>
        {
            var e = Editor(new[] { new LadrilloPunto(3, 3), new LadrilloPunto(1, 1), new LadrilloPunto(3, 1), new LadrilloPunto(1, 3) });
            return e.Piezas[0].Fila == 1 && e.Piezas[1].Fila == 0 && e.Piezas[2].Fila == 0 && e.Piezas[3].Fila == 1;
        });
        Run("editor row grouping tolerates initial numeric noise", () =>
        {
            var e = Editor(new[] { new LadrilloPunto(1, 1), new LadrilloPunto(3, 1 + 0.5e-6), new LadrilloPunto(5, 1 + 2e-6) });
            return e.Piezas[0].Fila == e.Piezas[1].Fila && e.Piezas[2].Fila != e.Piezas[0].Fila;
        });
        Run("editor selects and moves a whole row", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.MoverSeleccion(0.25, 0.5);
            return e.Seleccion.Count == 2 && Near(e.Piezas[0].Centro.X, 1.25) && Near(e.Piezas[1].Centro.X, 3.25) &&
                Near(e.Piezas[0].Centro.Y, 1.5) && Near(e.Piezas[2].Centro.Y, 3);
        });
        Run("editor row identity does not change after crossing another row", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.MoverSeleccion(0, 4); e.LimpiarSeleccion(); e.SeleccionarFila(1, false);
            return e.Seleccion.OrderBy(x => x).SequenceEqual(new[] { 0, 1 }) && e.Piezas[0].Fila == 0 && Near(e.Piezas[0].Centro.Y, 5);
        });
        Run("editor additive row selection moves multiple rows", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.SeleccionarFila(2, true); e.MoverSeleccion(0.2, 0.1);
            return e.Seleccion.Count == 4 && e.Piezas.All(x => Near(x.Centro.X - x.Original.X, 0.2) && Near(x.Centro.Y - x.Original.Y, 0.1));
        });
        Run("editor marquee accepts reversed drag corners", () =>
        {
            var e = Editor(); e.SeleccionarMarco(new LadrilloPunto(1.1, 3.1), new LadrilloPunto(0.9, 0.9), false);
            return e.Seleccion.OrderBy(x => x).SequenceEqual(new[] { 0, 2 });
        });
        Run("editor marquee selects by current moved positions", () =>
        {
            var e = Editor(); e.SeleccionarPieza(0, false); e.MoverSeleccion(4, 0);
            e.SeleccionarMarco(new LadrilloPunto(4.5, 0.5), new LadrilloPunto(5.5, 1.5), false);
            return e.Seleccion.Count == 1 && e.EstaSeleccionada(0);
        });
        Run("editor selected panel retains internal spacing", () =>
        {
            var e = Editor(); e.SeleccionarMarco(new LadrilloPunto(0, 0), new LadrilloPunto(4, 4), false); e.MoverSeleccion(0.3, 0.8);
            return Near(e.Piezas[1].Centro.X - e.Piezas[0].Centro.X, 2) && Near(e.Piezas[2].Centro.Y - e.Piezas[0].Centro.Y, 2);
        });
        Run("editor individual staggering does not move other bricks", () =>
        {
            var e = Editor(); e.SeleccionarPieza(1, false); e.MoverSeleccion(0.4, 0);
            return Near(e.Piezas[1].Centro.X, 3.4) && Near(e.Piezas[0].Centro.X, 1) && Near(e.Piezas[2].Centro.X, 1);
        });
        Run("editor out of slab edit stays visible and blocks creation", () =>
        {
            var e = Editor(); e.SeleccionarPieza(0, false); e.MoverSeleccion(-2, 0);
            return e.Piezas[0].Incluir && e.Piezas[0].FueraContorno && !e.PuedeCrear && e.InvalidasIncluidas == 1 && Near(e.Piezas[0].Centro.X, -1);
        });
        Run("editor excluding invalid brick restores ability to create", () =>
        {
            var e = Editor(); e.SeleccionarPieza(0, false); e.MoverSeleccion(-2, 0); e.SetInclusionSeleccion(false);
            return e.Piezas[0].FueraContorno && !e.Piezas[0].Incluir && e.PuedeCrear && e.InvalidasIncluidas == 0;
        });
        Run("editor complete rectangle detects a tiny interior hole", () =>
        {
            var e = new LadrillosEditor(Domain(Rect(0, 0, 10, 10), Rect(4.9, 4.9, 5.1, 5.1)),
                new[] { new LadrilloPunto(2, 2) }, 2, 2, 0, 0, 0);
            e.SeleccionarTodo(); e.MoverSeleccion(3, 3);
            return e.Piezas[0].FueraContorno && !e.PuedeCrear;
        });
        Run("editor complete rectangle detects concave notch crossing an edge", () =>
        {
            var outline = Points(0, 0, 10, 0, 10, 10, 5.1, 10, 5.1, 4, 4.9, 4, 4.9, 10, 0, 10);
            var e = new LadrillosEditor(Domain(outline), new[] { new LadrilloPunto(2, 5) }, 2, 2, 0, 0, 0);
            e.SeleccionarTodo(); e.MoverSeleccion(3, 0);
            return e.Piezas[0].FueraContorno;
        });
        Run("editor respects border margin when moved", () =>
        {
            var e = new LadrillosEditor(Domain(Rect(0, 0, 10, 10)), new[] { new LadrilloPunto(1, 1) }, 1, 1, 0.2, 0, 0);
            e.SeleccionarTodo(); e.MoverSeleccion(-0.4, 0);
            return e.Piezas[0].FueraContorno && !e.PuedeCrear;
        });
        Run("editor marks both pieces in moved row overlap", () =>
        {
            var e = Editor(); e.SeleccionarFila(2, false); e.MoverSeleccion(0, -1.5);
            return e.Piezas.All(x => x.SeSolapa) && e.InvalidasIncluidas == 4;
        });
        Run("editor touching edges are not overlaps", () =>
        {
            var e = Editor(new[] { new LadrilloPunto(1, 1), new LadrilloPunto(2, 1) });
            return e.PuedeCrear && e.Piezas.All(x => !x.SeSolapa);
        });
        Run("editor excludes removed bricks from collision checks", () =>
        {
            var e = Editor(new[] { new LadrilloPunto(1, 1), new LadrilloPunto(1.5, 1) });
            e.SeleccionarPieza(1, false); e.SetInclusionSeleccion(false);
            return e.PuedeCrear && e.Piezas.All(x => !x.SeSolapa);
        });
        Run("editor reducing joist gap is permitted without actual overlap", () =>
        {
            var e = Editor(); e.SeleccionarFila(2, false); e.MoverSeleccion(0, -0.5);
            return e.PuedeCrear && e.Piezas.All(x => !x.SeSolapa);
        });
        Run("editor undo restores row geometry and selection", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.MoverSeleccion(0.4, 0.2); e.SeleccionarPieza(3, false); e.Deshacer();
            return Near(e.Piezas[0].Centro.X, 1) && Near(e.Piezas[1].Centro.Y, 1) && e.Seleccion.OrderBy(x => x).SequenceEqual(new[] { 0, 1 }) && e.PuedeRehacer;
        });
        Run("editor redo restores translated geometry", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.MoverSeleccion(0.4, 0.2); e.Deshacer(); e.Rehacer();
            return Near(e.Piezas[0].Centro.X, 1.4) && Near(e.Piezas[1].Centro.Y, 1.2) && e.PuedeDeshacer && !e.PuedeRehacer;
        });
        Run("editor new operation after undo clears redo", () =>
        {
            var e = Editor(); e.SeleccionarTodo(); e.MoverSeleccion(0.2, 0); e.Deshacer(); e.MoverSeleccion(0, 0.3);
            return !e.PuedeRehacer && Near(e.Piezas[0].Centro.Y, 1.3);
        });
        Run("editor inclusion is undoable", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.SetInclusionSeleccion(false); e.Deshacer();
            return e.Piezas.All(x => x.Incluir);
        });
        Run("editor reset selection restores its positions and inclusion only", () =>
        {
            var e = Editor(); e.SeleccionarPieza(2, false); e.MoverSeleccion(0.3, 0); e.SeleccionarFila(0, false);
            e.MoverSeleccion(0.5, 0); e.SetInclusionSeleccion(false); e.RestablecerSeleccion();
            return Near(e.Piezas[0].Centro.X, 1) && e.Piezas[0].Incluir && Near(e.Piezas[2].Centro.X, 1.3);
        });
        Run("editor reset all is undoable", () =>
        {
            var e = Editor(); e.SeleccionarTodo(); e.MoverSeleccion(0.3, 0.2); e.IncluirTodo(false); e.RestablecerTodo();
            bool reset = e.Piezas.All(x => x.Incluir && Near(x.Centro.X, x.Original.X)); e.Deshacer();
            return reset && e.Piezas.All(x => !x.Incluir && Near(x.Centro.X - x.Original.X, 0.3));
        });
        Run("editor empty selection is a no-op without history", () =>
        {
            var e = Editor(); e.MoverSeleccion(1, 1); e.SetInclusionSeleccion(false);
            return !e.PuedeDeshacer && e.Piezas.All(x => x.Incluir);
        });
        Run("editor zero movement does not erase redo", () =>
        {
            var e = Editor(); e.SeleccionarTodo(); e.MoverSeleccion(0.3, 0); e.Deshacer(); e.MoverSeleccion(0, 0);
            return e.PuedeRehacer && !e.PuedeDeshacer;
        });
        Run("editor grouped movement is one undo step", () =>
        {
            var e = Editor(); e.SeleccionarFila(0, false); e.IniciarEdicion(); e.MoverSeleccion(0.2, 0, false); e.MoverSeleccion(0.3, 0.1, false); e.ConfirmarEdicion(); e.Deshacer();
            return Near(e.Piezas[0].Centro.X, 1) && Near(e.Piezas[0].Centro.Y, 1) && !e.PuedeDeshacer && e.PuedeRehacer;
        });
        Run("editor cancelling grouped movement restores state without history", () =>
        {
            var e = Editor(); e.SeleccionarTodo(); e.IniciarEdicion(); e.MoverSeleccion(0.2, 0.3, false); e.SetInclusionSeleccion(false); e.CancelarEdicion();
            return e.Piezas.All(x => x.Incluir && Near(x.Centro.X, x.Original.X)) && !e.PuedeDeshacer;
        });
        Run("editor ungrouped nonregistered movement is rejected", () =>
        {
            var e = Editor(); e.SeleccionarTodo();
            return Throws<InvalidOperationException>(() => e.MoverSeleccion(1, 0, false)) && Near(e.Piezas[0].Centro.X, 1);
        });
        Run("editor cannot undo an active grouped edit", () =>
        {
            var e = Editor(); e.IniciarEdicion(); return Throws<InvalidOperationException>(() => e.Deshacer());
        });
        Run("editor nonfinite movement is rejected atomically", () =>
        {
            var e = Editor(); e.SeleccionarTodo();
            return Throws<ArgumentOutOfRangeException>(() => e.MoverSeleccion(double.NaN, 1)) && e.Piezas.All(x => Near(x.Centro.X, x.Original.X)) && !e.PuedeDeshacer;
        });
        Run("editor excessive coordinate movement is rejected atomically", () =>
        {
            var e = Editor(); e.SeleccionarTodo();
            return Throws<ArgumentOutOfRangeException>(() => e.MoverSeleccion(10000000, 0)) && e.Piezas.All(x => Near(x.Centro.X, x.Original.X)) && !e.PuedeDeshacer;
        });
        Run("editor invalid ID does not clear valid selection", () =>
        {
            var e = Editor(); e.SeleccionarPieza(0, false);
            return Throws<ArgumentOutOfRangeException>(() => e.SeleccionarFila(99, false)) && e.EstaSeleccionada(0);
        });
        Run("editor revalidation resets externally reinforced geometry flags", () =>
        {
            var e = Editor(); e.Piezas[0].FueraContorno = true; e.Piezas[1].SeSolapa = true;
            bool observed = e.InvalidasIncluidas == 2 && !e.PuedeCrear; e.Validar();
            return observed && e.InvalidasIncluidas == 0 && e.PuedeCrear;
        });
        Run("editor clears stale interference flag after movement", () =>
        {
            var e = Editor(); e.Piezas[0].Interfiere = true; e.Piezas[0].Obstaculos = 4; e.SeleccionarPieza(0, false); e.MoverSeleccion(0.1, 0);
            return !e.Piezas[0].Interfiere && e.Piezas[0].Obstaculos == 0;
        });
        Run("editor makes a defensive contour copy", () =>
        {
            var outline = Rect(0, 0, 10, 10); var e = new LadrillosEditor(Domain(outline), new[] { new LadrilloPunto(2, 2) }, 1, 1, 0, 0, 0);
            outline[0] = new LadrilloPunto(100, 100); e.SeleccionarTodo(); e.MoverSeleccion(0.1, 0);
            return e.PuedeCrear;
        });
        Run("editor all excluded cannot create", () =>
        { var e = Editor(); e.IncluirTodo(false); return !e.PuedeCrear && e.InvalidasIncluidas == 0; });
        Run("editor empty layout cannot create", () =>
        { var e = Editor(new LadrilloPunto[0]); return !e.PuedeCrear && e.Piezas.Count == 0; });
        Run("editor rejects nonfinite source centers", () => Throws<ArgumentOutOfRangeException>(() => Editor(new[] { new LadrilloPunto(double.NaN, 0) })));
        Run("editor retains at most one hundred undo snapshots", () =>
        {
            var e = new LadrillosEditor(Domain(Rect(0, 0, 1000, 1000)), new[] { new LadrilloPunto(1, 1) }, 1, 1, 0, 0, 0); e.SeleccionarTodo();
            for (int i = 0; i < 101; i++) e.MoverSeleccion(1, 0);
            for (int i = 0; i < 100; i++) e.Deshacer();
            return Near(e.Piezas[0].Centro.X, 2) && !e.PuedeDeshacer;
        });
        Run("editor spatial index handles ten thousand nonoverlapping pieces", () =>
        {
            var centers = new List<LadrilloPunto>();
            for (int y = 0; y < 100; y++) for (int x = 0; x < 100; x++) centers.Add(new LadrilloPunto(1 + 2 * x, 1 + 2 * y));
            var e = new LadrillosEditor(Domain(Rect(0, 0, 201, 201)), centers, 1, 1, 0, 0, 0);
            e.SeleccionarTodo(); e.MoverSeleccion(0.1, 0.1);
            return e.Piezas.Count == 10000 && e.PuedeCrear && e.Piezas.All(x => !x.SeSolapa);
        });
        Run("editor congested cell marks every overlapping brick", () =>
        {
            var centers = Enumerable.Range(0, 1000).Select(x => new LadrilloPunto(2, 2)).ToArray(); var e = Editor(centers);
            return e.InvalidasIncluidas == 1000 && e.Piezas.All(x => x.SeSolapa);
        });

        Console.WriteLine("Passed: " + passed + "; Failed: " + failed);
        Environment.ExitCode = failed == 0 ? 0 : 1;
    }

    private static LadrillosEditor Editor(IList<LadrilloPunto> centers = null)
    {
        return new LadrillosEditor(Domain(Rect(0, 0, 10, 10)), centers ?? new[] {
            new LadrilloPunto(1, 1), new LadrilloPunto(3, 1), new LadrilloPunto(1, 3), new LadrilloPunto(3, 3) }, 1, 1, 0, 0, 1);
    }

    private static void Run(string name, Func<bool> test)
    {
        try
        {
            if (!test()) throw new Exception("Assertion failed");
            passed++;
            Console.WriteLine("PASS " + name);
        }
        catch (Exception ex)
        {
            failed++;
            Console.WriteLine("FAIL " + name + ": " + ex.GetType().Name + ": " + ex.Message);
        }
    }

    private static bool Near(double a, double b) { return Math.Abs(a - b) < 1e-7; }
    private static bool Throws<T>(Action action) where T : Exception
    {
        try { action(); return false; }
        catch (T) { return true; }
    }
    private static int Count(IList<IList<LadrilloPunto>> domain, double u, double v)
    {
        return Generate(domain, new LadrilloPunto(0, 0), u, v).Count;
    }
    private static List<LadrilloPunto> Generate(IList<IList<LadrilloPunto>> domain, LadrilloPunto origin,
        double u, double v, double joint = 0, double joist = 0, double margin = 0)
    {
        return LadrillosLayout.Generar(domain, origin, u, v, joint, joist, margin, 100000, 100000);
    }
    private static IList<IList<LadrilloPunto>> Domain(params List<LadrilloPunto>[] rings)
    {
        return rings.Cast<IList<LadrilloPunto>>().ToList();
    }
    private static List<LadrilloPunto> Rect(double minx, double miny, double maxx, double maxy)
    {
        return Points(minx, miny, maxx, miny, maxx, maxy, minx, maxy);
    }
    private static List<LadrilloPunto> Points(params double[] xy)
    {
        var result = new List<LadrilloPunto>();
        for (int i = 0; i < xy.Length; i += 2) result.Add(new LadrilloPunto(xy[i], xy[i + 1]));
        return result;
    }
}
