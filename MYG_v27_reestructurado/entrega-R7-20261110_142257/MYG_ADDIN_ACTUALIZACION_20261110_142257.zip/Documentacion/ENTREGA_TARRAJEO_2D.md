# Apertura local de contactos — TARRAJEO-PLANO-R7

## Problema corregido y base

Esta entrega se aplica sobre R6, publicada en DESCARGAS con commit `c83dd72cbe3df9af50df237c4b87e954a289dc64`.

R6 puede devolver «El propietario no conserva un exterior y todos sus huecos separados» cuando un hueco toca el contorno exterior en un único punto, o cuando dos huecos se tocan en un vértice. Se reprodujo el mensaje con geometrías sintéticas, incluso sin aristas cortas. Un contacto por un lado completo ya se convierte correctamente en muesca o unión mediante la resta habitual.

Las imágenes del modelo son compatibles con esta clase de encuentro, pero todavía falta el log de esa ejecución para confirmar sus coordenadas y su causa exacta. Las pruebas descritas aquí no ejecutan ese modelo dentro de Revit.

## Cómo actúa R7

Después de restar las interferencias visibles, el motor detecta contactos exactos entre anillos. Si existen, intenta abrirlos retirando material únicamente dentro de 1 mm de sus puntos originales. Prueba cortes romboidales orientados según los soportes del encuentro, con distintas proporciones para evitar conectores demasiado cortos.

Un hueco que toca el exterior puede pasar a ser una muesca; dos huecos tangentes pueden pasar a formar un hueco unido. El grafo de contactos originales fija cuántas uniones se permiten. Un hueco cercano que nunca tocaba los demás debe conservar su independencia. No se rellenan vacíos ni se desplazan o eliminan los sólidos existentes.

Cada candidato debe cumplir estas condiciones:

- Conservar un único propietario y ser subconjunto del material disponible anterior.
- Reducir los contactos pendientes sin crear otros ni trasladarlos.
- Crear conectores que superen `Application.ShortCurveTolerance` con el margen de R6: el mayor entre 1% y 0.002 mm.
- Mantener toda la retirada dentro de la unión fija de discos de 1 mm alrededor de los contactos originales y cápsulas de 1 mm alrededor de las aristas cortas originales.

Una vez abiertos los contactos, se ejecutan las comprobaciones y el ajuste de aristas de R6 sobre la nueva topología. Los anillos finales deben quedar simples, separados y con longitudes válidas. Si falla cualquier paso posterior, se devuelve el contorno original completo, área retirada cero y factor de coordenadas 1. No se confirman correcciones parciales.

La búsqueda admite hasta 64 contactos/pasos de apertura por región; el reparador de aristas conserva su límite de 128 pasos. La precisión refinada se conserva hasta crear las curvas. La opción continúa activándose únicamente desde el flujo de suelos; el recorte de muros y la colocación exterior del acabado mantienen su comportamiento de R6.

## Archivos de esta entrega

| Acción | Ruta relativa | Cambio |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Apertura conservadora de contactos y validaciones. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Identificador y registros R7. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Regresiones nuevas y conservación de las anteriores. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Comando, resultados y alcance de las pruebas. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP contiene esos cinco archivos, el parche alternativo `PARCHES/ABRIR_CONTACTOS_DESDE_R6.patch` y `MANIFIESTO_SHA256.txt`: **7 archivos**. No cambia la firma del método ni se requieren inclusiones de proyecto, referencias, paquetes o eliminaciones.

`TarrajeoRecorteExterior.cs`, `Tarrajeo_MurosHandler.cs`, `MYG.csproj`, `Clipper.cs`, los auxiliares de alturas/validación y el proyecto de pruebas siguen iguales respecto a R6 y quedan fuera del ZIP. Tampoco se incluyen logs, modelos, coordenadas privadas, DLL, bin/obj, credenciales ni cachés.

## Instalación y comprobación

1. Partir de R6, respaldar los archivos y comparar cualquier cambio propio posterior.
2. Reemplazar ambos archivos de producción, respetando sus rutas. Copiar aparte las pruebas y la documentación. No sustituir el `.csproj` ni añadir entradas Compile duplicadas.
3. Como alternativa a copiar los dos archivos de producción, aplicar sobre R6 `git apply --check PARCHES/ABRIR_CONTACTOS_DESDE_R6.patch` y después `git apply PARCHES/ABRIR_CONTACTOS_DESDE_R6.patch`. No aplicar el parche después de copiarlos.
4. Compilar en la configuración real de Windows/Revit, actualizar la DLL, cerrar todas las instancias de Revit y abrir otra vez. El aviso o log debe mostrar `TARRAJEO-PLANO-R7`.
5. Probar en una copia sin los acabados generados por intentos anteriores, pues también cuentan como sólidos visibles. El comando no los borra automáticamente.
6. Revisar los registros de apertura, la cantidad de huecos antes/después y el área retirada. Estos datos describen el boceto 2D aceptado; el contador de suelos confirmados indica los elementos realmente creados.

## Validación y límites

La suite ejecuta el código real de producción: **R7 pasa 52/52 pruebas**. La misma suite contra R6 pasa 45 y falla 7; sus 41 pruebas anteriores siguen aprobadas. Las nuevas regresiones cubren los contactos reproducidos, rotación de 17.03°, huecos independientes próximos y lejanos, contactos por segmento ya válidos, separaciones reales y devolución del original cuando la corrección no se admite. El README contiene el comando y las comprobaciones independientes de subconjunto, localidad y frontera.

La compilación semántica de los tres archivos completos del motor y de los métodos reales modificados del flujo de suelos pasó sin errores, con C# 7.3 y 81 referencias de metadatos reales de Revit. Esta comprobación no ejecuta Revit. La compilación completa en Linux continúa bloqueada por MSB4803/ResolveComReference; no se produce una DLL aquí ni se migran las dependencias de la solución Windows. La creación con `Floor.Create`, las transacciones y el contacto exterior final deben validarse en Revit.

Esta revisión trata contactos exactos entre anillos. No convierte automáticamente separaciones pequeñas en contactos ni aplica un offset global. Se rechaza una corrección si requiere más de 1 mm, produce cruces/solapes, une un hueco ajeno o exige dividir el propietario en varias regiones. Los encuentros múltiples y las casi tangencias que aparezcan por redondeo pueden requerir otro diagnóstico.

## Entrega

Se publica únicamente el ZIP en una carpeta nueva de `bimchimbote-droid/DESCARGAS`, conservando las entregas anteriores. Se verifica mediante un clon independiente, comparando bytes, SHA-256, integridad y manifiesto. No se generan ni se envían enlaces de descarga.

Esta publicación no actualiza la instalación local ni realiza Commit/Push al repositorio del código. Después de aplicar y validar en Revit, se pueden incorporar los cambios revisados desde Visual Studio. El modelo y el log geométrico deben permanecer fuera de la entrega pública.
