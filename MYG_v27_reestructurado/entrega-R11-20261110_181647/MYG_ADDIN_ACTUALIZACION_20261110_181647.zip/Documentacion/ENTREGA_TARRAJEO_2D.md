# Tolerancias nativas y residuos de precisión — TARRAJEO-PLANO-R11

## Estado y base

**R11 es una candidata para aceptación dentro de Revit. No acredita una liberación comercial aprobada.** Se aplica sobre la entrega R10 publicada en DESCARGAS con commit `1ba552b66e8d819df2973ab1ebab85a719ffd99e`.

El nuevo log contiene candidatos que Revit reconoce como cerrados y planos, con normal horizontal y sin intersecciones detectadas entre los bordes no adyacentes comprobados, pero que `BoundaryValidation` rechaza. Esas comprobaciones no equivalen a una frontera válida para el kernel. No hay evidencia que justifique atribuir el fallo a la orientación de todos los bucles ni a una deriva en Z.

Las tolerancias registradas son aproximadamente **0.780369 mm** para `ShortCurveTolerance`, **0.159527 mm** para `VertexTolerance` y **0.1 grados** para `AngleTolerance`. La limpieza de R10 quedaba limitada a 0.003 mm. También aparece un triángulo residual de unos 1.739 m de largo y solo 0.00314 mm de altura: su candidato puede cumplir la longitud mínima de arista y seguir siendo geométricamente degenerado a la precisión de Revit. El log sustenta corregir esa diferencia de precisión; **no revela la condición interna exacta que causó cada rechazo**.

El NWD privado contiene metadatos compatibles con el suelo `987412` y el tipo indicado en las capturas. Se conserva como referencia para probar su cara inferior; el log R10 no registra ese identificador y no permite una correlación concluyente. Inspeccionar metadatos del NWD no equivale a abrir un RVT, verificar su geometría nativa ni ejecutar `Floor.Create`.

## Política de precisión de R11

El adaptador entrega al motor las tolerancias reales de la aplicación. Se mantienen la recomposición `exterior - unión(vacíos)`, los paños naturales y el validador nativo. **Un candidato completo válido y admitido se conserva sin cambios**. La API anterior mantiene su comportamiento y sus 73 regresiones; el ajuste con tolerancias nativas tiene una entrada separada.

Después de obtener el dominio canónico se prueba primero su representación sin editar, si cada anillo es simple y tiene aristas nativamente construibles, aunque existan contactos entre el exterior y los huecos. Una arista RAW muy corta puede haberse cancelado en la operación booleana y no impide ese ensayo si ya no existe en el candidato. La construcción de cada anillo no acredita por sí sola la validez del conjunto.

Un rechazo nativo real de ese candidato permite evaluar el respaldo de precisión cuando también hay una inestabilidad compatible con la tolerancia de vértices o ángulos. Si el kernel acepta un conjunto que todavía falla las comprobaciones conservadoras de la frontera completa, se comunica el fallo; no se inventa un rechazo para autorizar modificaciones. Si el candidato aún conserva aristas imposibles de construir, necesita la recomposición previa: esa imposibilidad tampoco se hace pasar por un rechazo nativo ni permite retirar residuos.

La banda máxima de ese respaldo se calcula como `min(1 mm, max(0.003 mm, 1.25 × VertexTolerance))`: con los valores del log resulta aproximadamente 0.199409 mm. Además se limita la retirada conjunta de la recomposición previa y del respaldo a la banda original del propietario, de hasta 1 mm. Son presupuestos de conservación, no órdenes de separar puntos exactamente por `VertexTolerance` ni de fijar un ángulo a `AngleTolerance`. Esta última ayuda a detectar la inestabilidad; no impone un cambio angular a cada vértice retirado.

La búsqueda parte siempre del mismo contorno original. Prueba limpieza conservadora y márgenes físicos independientes de **0, 0.005, 0.01, 0.025, 0.05, 0.1, 0.2, 0.4 y 0.8 mm**, aceptados únicamente si toda la retirada queda dentro de la banda permitida. Cada alternativa debe satisfacer las comprobaciones exactas de subconjunto y banda; cualquier perfil que se vaya a crear debe pasar de nuevo el validador nativo. No se acumulan desplazamientos entre intentos ni se amplía el límite de 1 mm. Una excepción inesperada del validador no se trata como rechazo geométrico y no autoriza limpiar ni retirar residuos.

Un componente puede resolverse como **residuo de precisión**, sin crear un suelo, solo después del rechazo nativo y de probar que todo él queda dentro de la banda admisible. La salida lo distingue expresamente de un perfil creado y registra la retirada. No se usa un umbral de área para borrar paños: un triángulo muy largo y fino no se clasifica solo por sus milímetros cuadrados. Si no se demuestra esa condición y tampoco se obtiene un perfil nativo válido, la cara sigue fallando completa.

La corrección no añade material, no rellena huecos ni crea franjas artificiales. La limpieza puede separar contactos numéricos en varios paños naturales; deben conservarse y validarse todos los perfiles resultantes. Dos candidatos que describen el mismo dominio con distinta segmentación reciben su propia validación nativa; solo se reutiliza la respuesta para la misma representación de vértices. La conversión de caminos a bocetos horizontales se comparte entre el adaptador comercial y el comando de aceptación, para que ambos usen el mismo criterio de construcción.

## Una cara se confirma completa

Se conserva el grupo exterior de transacciones por cara. La preparación debe resolver todos sus paños como perfiles válidos o residuos demostrados antes de iniciar la creación. Si falla un perfil o el `Commit` de un suelo, se revierte el grupo de esa cara. El contador de suelos creados solo aumenta después de confirmar todos sus elementos; un residuo resuelto no cuenta como un suelo. Las caras completadas anteriormente pertenecen a operaciones distintas.

Esc sigue propagándose por el motor y las fases nativas, con reversión de las transacciones abiertas. Se mantienen la colocación exterior, el espesor elegido, la comprobación final de contacto y el comportamiento de muros. Si no hay descuento real, los arcos originales se conservan cuando su boceto pasa la validación nativa.

El diálogo presenta un mensaje breve y reserva versión, causa técnica y ruta del log para el contenido expandible. Una reversión no confirmada por Revit se comunica como tal.

## Diagnóstico y reproducción

Se conservan por separado el dominio **RAW** de origen y los **candidatos horizontales finales** rechazados. El registro nativo incluye factor, cierre y plano, resultados de intersección de bordes no adyacentes y tolerancias reales. R11 añade identificadores del propietario y de la referencia seleccionada, junto con normal y origen, para facilitar la correlación de casos futuros.

El comando de aceptación lee bloques RAW completos `Exterior/Hueco` de R9, R10 y R11. Los bloques de candidatos finales `Contorno N` siguen siendo diagnóstico; no se reinterpretan como dominios RAW. La reproducción usa el adaptador horizontal de la DLL de producción cargada, su validador estricto y las tolerancias de la aplicación. Requiere una única DLL R11 compatible. Conserva la posición y cota del log, pero no reproduce la selección ni toda la transformación original; el signo de la normal horizontal se infiere del sentido del exterior RAW.

En cada caso con perfiles, el comando ejecuta la validación nativa y el método real de creación, confirma suelos temporales y revierte tanto el caso como la ejecución completa. Un resultado vacío solo se informa como **RESIDUO RESUELTO** si la salida explícita lo acredita y hubo comprobación nativa; tiene cero commits y no acredita una creación. **PASS NATIVO** exige que pasen todos los casos, que haya al menos un caso real local con `Floor.Create` y `Commit`, que no falten contornos y que se confirmen las reversiones. Sin esos datos, el resultado es **INCOMPLETO**.

## Archivos del ZIP

| Acción | Ruta relativa | Finalidad |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Entrada con tolerancias, banda conservadora y resultado explícito de residuos. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs` | Tolerancias de la aplicación, conversión horizontal compartida y diagnóstico. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Integración de resultados, identificación de la cara y marcador R11. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Regresiones del motor y de la nueva política. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Comando, resultados y alcance de pruebas. |
| REEMPLAZAR | `Tests/RevitAceptacion/ComandoAceptacion.cs` | Reproducción con tolerancias y adaptador de producción. |
| REEMPLAZAR | `Tests/RevitAceptacion/README.md` | Ejecución en Windows y criterios de aceptación. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP añade `PARCHES/CALIBRAR_TOLERANCIAS_DESDE_R10.patch` y `MANIFIESTO_SHA256.txt`: **10 archivos**. El parche modifica los tres archivos de producción; pruebas y documentación se copian aparte.

`TarrajeoValidacionSuelo.cs`, `Tarrajeo_MurosHandler.cs`, `MYG.csproj`, `Clipper.cs`, los auxiliares de alturas y ambos proyectos de pruebas no cambian respecto de R10. El comando de aceptación sigue separado del add-in comercial: no se registra para los usuarios ni se añade a `MYG.csproj`. No se entregan DLL, paquetes, bin/obj, logs, modelos, coordenadas privadas, credenciales ni cachés.

## Instalación sobre R10

1. Respaldar y comparar cambios propios posteriores a R10.
2. Reemplazar **los tres archivos de producción juntos**, conservando sus rutas. Como alternativa, aplicar sobre R10 `git apply --check PARCHES/CALIBRAR_TOLERANCIAS_DESDE_R10.patch` y después `git apply PARCHES/CALIBRAR_TOLERANCIAS_DESDE_R10.patch`. No aplicar el parche después de copiar esos archivos.
3. Copiar pruebas y documentación. No sustituir el proyecto comercial ni duplicar entradas Compile.
4. Compilar en la configuración real de Windows/Revit, actualizar la DLL, cerrar todas las instancias de Revit y abrir una copia de prueba. Debe cargarse `TARRAJEO-PLANO-R11`.
5. Conservar el log de los fallos y ejecutar la aceptación nativa. Al probar el comando comercial, evitar que acabados de intentos anteriores cambien los obstáculos visibles; no se borran automáticamente elementos del modelo.

## Validación y criterio de liberación

**La suite de geometría R11 pasa 91/91 casos.** Conserva las 73 regresiones anteriores y añade 18 casos de tolerancias nativas, candidatos ya válidos, márgenes independientes, residuos, rechazo de cambios fuera de banda, cancelación, excepciones del validador y representaciones distintas del mismo dominio. Incluye el escalón rotado de 0.499673 mm, una simplificación que conserva el dominio pero cambia la respuesta del validador y el ensayo del conjunto canónico construible por anillos. Con el snapshot publicado de R10 pasan los 73 anteriores y fallan los 18 nuevos por ausencia de la nueva API. El comando y los resultados se documentan en `Tests/TarrajeoRecorte2D/README.md`. Sus callbacks geométricos no simulan Revit ni acreditan `Floor.Create` o `Commit`.

La reproducción privada de **15 dominios RAW** del log, 13 de R9 y dos de R10, pasa **15/15 comprobaciones métricas** usando la nueva API del motor. Se verificaron subconjunto y ausencia de solapes con operaciones exactas, sin presentar perfiles vacíos al callback. Esa reproducción permite comprobar la conservación geométrica y la preparación de los casos reportados; su validador métrico no ejecuta el kernel de Revit. Los datos y las coordenadas privadas quedan fuera del ZIP.

**La compilación semántica final pasa con cero errores, C# 7.3 y 81 referencias de metadatos reales de Revit.** Incluye el motor, el adaptador, el flujo completo de creación de suelos y el preprocesador de fallos. El comando completo de aceptación también pasa su compilación semántica sin errores. Esto verifica compatibilidad de código; no ejecuta la aplicación. La compilación completa en Linux mantiene el bloqueo MSB4803/ResolveComReference de la solución Windows. No se genera aquí una DLL comercial ni se migran esas dependencias.

Antes de liberar R11 deben pasar la aceptación nativa y la lista manual de atomicidad, cancelación, preservación de otras caras y conservación geométrica de `Tests/RevitAceptacion/README.md`. Debe repetirse el caso privado de referencia de la cara inferior del suelo `987412`, confirmar la selección mediante el nuevo log y revisar que se crean todos los paños útiles con el descuento de los sólidos correspondientes. También deben comprobarse selección, vistas, vínculos, tipos y versiones admitidos en el entorno de distribución.

**Las pruebas 2D, el NWD y la compilación no sustituyen esa aceptación. Revit no se ha ejecutado en este entorno Linux.**

## Entrega

Se publica únicamente el ZIP en una carpeta nueva de `bimchimbote-droid/DESCARGAS`, conservando las entregas anteriores. Su verificación compara bytes, SHA-256, integridad y manifiesto desde un clon independiente. No se generan ni se envían enlaces de descarga.

Esta publicación no actualiza la instalación local ni realiza Commit/Push al repositorio del código. Los modelos privados, los informes nativos, el log geométrico y las herramientas de inspección del NWD quedan fuera de la entrega pública.
