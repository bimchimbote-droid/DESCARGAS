using Autodesk.Revit.DB;
using MYG_Addin.RecorteClipper;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    internal sealed class ResultadoPlanoExterior
    {
        internal readonly List<List<CurveLoop>> Perfiles = new List<List<CurveLoop>>();
        internal readonly List<string> Rechazados = new List<string>();
        internal readonly List<string> GeometriaRechazada = new List<string>();
        internal readonly List<string> DiagnosticosNativos = new List<string>();
        internal readonly List<string> AjustesLocales = new List<string>();
        internal double AreaRetiradaLocal;
        internal int ResiduosSinInteriorNativo;
        internal int SolidosDescontados;
        internal string Diagnostico;
    }

    internal static class TarrajeoRecorteExterior
    {
        // Rejilla local de 0.001 mm. No es una expansión de obstáculos ni una
        // tolerancia de creación de Revit; el error máximo por eje es 0.0005 mm.
        private const double Escala = 304800.0;
        private const double TolPlano = 1e-9;

        private sealed class Marco
        {
            internal XYZ Origen, U, V, N;
            internal IntPoint Proyectar(XYZ p)
            {
                XYZ d = p - Origen;
                double x = d.DotProduct(U) * Escala, y = d.DotProduct(V) * Escala;
                if (double.IsNaN(x) || double.IsInfinity(x) || Math.Abs(x) > 1e14 ||
                    double.IsNaN(y) || double.IsInfinity(y) || Math.Abs(y) > 1e14)
                    throw new InvalidOperationException("Coordenadas fuera del rango de recorte.");
                return new IntPoint((long)Math.Round(x, MidpointRounding.AwayFromZero),
                    (long)Math.Round(y, MidpointRounding.AwayFromZero));
            }
            internal XYZ Modelo(IntPoint p, double factor = 1.0)
            {
                return Origen + U.Multiply(p.X / factor / Escala) + V.Multiply(p.Y / factor / Escala);
            }
        }

        internal static ResultadoPlanoExterior Calcular(
            IList<CurveLoop> cara, XYZ origen, XYZ normal, double espesor,
            IList<Solid> candidatos, double curvaCorta,
            IDictionary<Solid, string> origenes = null, bool ajustarEncuentrosSuelo = false,
            double toleranciaVertices = 0.0, double toleranciaAngular = 0.0)
        {
            if (cara == null || cara.Count == 0 || origen == null || normal == null ||
                normal.GetLength() <= TolPlano || espesor <= 0.0 || curvaCorta < 0.0)
                throw new InvalidOperationException("Datos incompletos para el recorte exterior.");
            XYZ n = normal.Normalize();
            XYZ referencia = Math.Abs(n.X) < 0.9 ? XYZ.BasisX : XYZ.BasisY;
            XYZ u = (referencia - n.Multiply(referencia.DotProduct(n))).Normalize();
            var marco = new Marco { Origen = origen, U = u, V = n.CrossProduct(u), N = n };
            var region = ProyectarContornos(cara, marco);
            var limites = region.SelectMany(x => x).ToList();
            if (limites.Count == 0)
                throw new InvalidOperationException("La cara no tiene un dominio proyectable.");
            var sombras = new List<List<List<IntPoint>>>();
            var resultado = new ResultadoPlanoExterior();
            foreach (Solid candidato in candidatos ?? new List<Solid>())
            {
                if (candidato == null || candidato.Volume <= 1e-12)
                    continue;
                try
                {
                    // La caja solo descarta candidatos lejanos. Nunca se usa
                    // como huella cortante ni sustituye la geometría del sólido.
                    BoundingBoxXYZ caja = candidato.GetBoundingBox();
                    if (caja == null)
                        throw new InvalidOperationException("No se pudo delimitar el sólido candidato.");
                    var cajaUV = new List<IntPoint>();
                    Transform transformacionCaja = caja.Transform ?? Transform.Identity;
                    foreach (double x in new[] { caja.Min.X, caja.Max.X })
                        foreach (double y in new[] { caja.Min.Y, caja.Max.Y })
                            foreach (double z in new[] { caja.Min.Z, caja.Max.Z })
                                cajaUV.Add(marco.Proyectar(transformacionCaja.OfPoint(new XYZ(x, y, z))));
                    if (cajaUV.Max(p => p.X) <= limites.Min(p => p.X) ||
                        cajaUV.Min(p => p.X) >= limites.Max(p => p.X) ||
                        cajaUV.Max(p => p.Y) <= limites.Min(p => p.Y) ||
                        cajaUV.Min(p => p.Y) >= limites.Max(p => p.Y))
                        continue;
                    Solid exterior = RecortarEntrePlanos(candidato, origen, n, espesor);
                    if (exterior == null || exterior.Volume <= 1e-12)
                        continue;
                    int antes = sombras.Count;
                    foreach (Face superficie in exterior.Faces)
                    {
                        PlanarFace plana = superficie as PlanarFace;
                        if (plana != null)
                        {
                            if (Math.Abs(plana.FaceNormal.DotProduct(n)) <= 1e-10)
                                continue; // Su proyección tiene área nula.
                            sombras.Add(ProyectarContornos(plana.GetEdgesAsCurveLoops(), marco));
                        }
                        else
                        {
                            Mesh malla = superficie.Triangulate();
                            if (malla == null)
                                throw new InvalidOperationException("No se pudo medir una superficie curva.");
                            for (int i = 0; i < malla.NumTriangles; i++)
                            {
                                MeshTriangle t = malla.get_Triangle(i);
                                var triangulo = new List<IntPoint>
                                {
                                    marco.Proyectar(t.get_Vertex(0)), marco.Proyectar(t.get_Vertex(1)),
                                    marco.Proyectar(t.get_Vertex(2))
                                };
                                // No se ensanchan triángulos delgados. Primero se
                                // une TODA la sombra; sus diagonales desaparecen.
                                if (Math.Abs(Clipper.Area(triangulo)) >= 0.5)
                                    sombras.Add(new List<List<IntPoint>> { triangulo });
                            }
                        }
                    }
                    if (sombras.Count > antes)
                        resultado.SolidosDescontados++;
                }
                catch (Exception ex)
                {
                    string origenCandidato;
                    string detalle = origenes != null && origenes.TryGetValue(candidato, out origenCandidato)
                        ? origenCandidato : "sólido visible";
                    throw new InvalidOperationException("No se pudo medir el espesor exterior de " +
                        detalle + ". No se sustituyó su forma por una caja o triángulo ampliado. " + ex.Message, ex);
                }
            }
            double areaAntesPrecision, areaDespuesPrecision;
            PolyTree recorte = RecortePlanoExterior.Restar(region, sombras,
                out areaAntesPrecision, out areaDespuesPrecision);
            if (recorte.Childs.Count == 1 && RecortePlanoExterior.MismoDominio(region, Clipper.PolyTreeToPaths(recorte)))
            {
                // Conservar los arcos si el boceto original también es nativo
                // admisible. Una cara derivada puede contener vueltas numéricas
                // aunque no se le haya descontado ningún obstáculo nuevo.
                bool conservar = !ajustarEncuentrosSuelo;
                if (ajustarEncuentrosSuelo)
                    try
                    {
                        string motivo;
                        conservar = ValidarExtrusionHorizontal(
                            ProyectarHorizontal(cara, origen.Z), espesor, out motivo);
                    }
                    catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
                    { throw new System.OperationCanceledException("Operación cancelada en Revit.", ex); }
                    catch (System.OperationCanceledException) { throw; }
                    catch { conservar = false; }
                if (conservar)
                {
                    resultado.Perfiles.Add(cara.ToList());
                    resultado.SolidosDescontados = 0;
                    resultado.Diagnostico = "La cara no tiene interferencias en el espesor exterior; se conserva su contorno original.";
                    return resultado;
                }
            }
            int indice = 0;
            for (PolyNode nodo = recorte.GetFirst(); nodo != null; nodo = nodo.GetNext())
            {
                if (nodo.IsHole)
                    continue;
                indice++;
                try
                {
                    var contornos = new List<List<IntPoint>> { nodo.Contour };
                    contornos.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => x.Contour));
                    var conjuntos = new List<List<List<IntPoint>>> { contornos };
                    string ajuste = null;
                    double areaRetirada = 0.0;
                    double factorCoordenadas = 1.0;
                    int residuos = 0;
                    if (ajustarEncuentrosSuelo)
                    {
                        // Una celda = 0.001 mm. Prioridad a las interferencias:
                        // solo el suelo puede perder material, localmente <=1mm.
                        string ultimoRechazoNativo = string.Empty;
                        int intentoNativo = 0, presupuestoPuntos = 10000;
                        // Validar sin crear elementos: cada candidato conserva
                        // su dominio, pero el kernel 3D puede rechazar una
                        // apertura demasiado fina aunque sus aristas sean largas.
                        Func<List<List<IntPoint>>, double, bool> validador = (caminos, factor) =>
                        {
                            intentoNativo++;
                            var horizontal = new Marco
                            {
                                Origen = marco.Origen,
                                U = new XYZ(marco.U.X, marco.U.Y, 0.0),
                                V = new XYZ(marco.V.X, marco.V.Y, 0.0),
                                N = XYZ.BasisZ
                            };
                            List<CurveLoop> curvas = null;
                            try
                            {
                                // Mismo XY que el boceto horizontal de Floor.
                                // La cota solo sitúa el sólido temporal.
                                curvas = CrearBocetoHorizontal(caminos, factor, marco.Origen,
                                    marco.U, marco.V, curvaCorta);
                                bool valido = ValidarExtrusionHorizontalEstricta(curvas, espesor, out ultimoRechazoNativo);
                                if (!valido && resultado.DiagnosticosNativos.Count < 32)
                                    resultado.DiagnosticosNativos.Add(DescribirCandidatoNativo(
                                        caminos, factor, horizontal, curvas, indice, intentoNativo,
                                        ultimoRechazoNativo, curvaCorta, toleranciaVertices,
                                        toleranciaAngular, ref presupuestoPuntos));
                                if (valido)
                                    ultimoRechazoNativo = string.Empty;
                                return valido;
                            }
                            catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
                            { throw new System.OperationCanceledException("Operación cancelada en Revit.", ex); }
                            catch (System.OperationCanceledException) { throw; }
                            catch (Exception ex)
                            {
                                ultimoRechazoNativo = ex.GetType().Name + " - " + ex.Message;
                                if (resultado.DiagnosticosNativos.Count < 32)
                                    resultado.DiagnosticosNativos.Add(DescribirCandidatoNativo(
                                        caminos, factor, horizontal, curvas, indice, intentoNativo,
                                        ultimoRechazoNativo, curvaCorta, toleranciaVertices,
                                        toleranciaAngular, ref presupuestoPuntos));
                                // Un fallo de ejecución no es un rechazo
                                // geométrico y nunca autoriza retirar residuos.
                                throw new InvalidOperationException(
                                    "No terminó la validación nativa del candidato. " + ultimoRechazoNativo, ex);
                            }
                        };
                        if (!RecortePlanoExterior.AjustarPerfilesConTolerancias(nodo,
                            curvaCorta * Escala, 1000.0, toleranciaVertices * Escala,
                            toleranciaAngular, out conjuntos, out areaRetirada, out ajuste,
                            out factorCoordenadas, out residuos, validador))
                            throw new InvalidOperationException(ajuste +
                                (string.IsNullOrWhiteSpace(ultimoRechazoNativo) ? string.Empty :
                                    " Validación nativa de extrusión: " + ultimoRechazoNativo));
                    }
                    var perfilesPreparados = new List<List<CurveLoop>>();
                    foreach (var conjunto in conjuntos)
                    {
                        var perfil = new List<CurveLoop>();
                        foreach (var contorno in conjunto)
                            perfil.Add(CrearContorno(contorno, marco, curvaCorta, factorCoordenadas));
                        perfilesPreparados.Add(perfil);
                    }
                    // Confirmar todos los propietarios naturales de este nodo
                    // juntos; nunca juntar varios exteriores en un solo suelo.
                    resultado.Perfiles.AddRange(perfilesPreparados);
                    resultado.ResiduosSinInteriorNativo += residuos;
                    if (!string.IsNullOrWhiteSpace(ajuste))
                    {
                        resultado.AreaRetiradaLocal += areaRetirada / 1000000.0;
                        resultado.AjustesLocales.Add("Región " + indice + ": " + ajuste);
                    }
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
                { throw new System.OperationCanceledException("Operación cancelada en Revit.", ex); }
                catch (System.OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    resultado.Rechazados.Add("Región " + indice + ": " + ex.Message);
                    resultado.GeometriaRechazada.Add(DescribirRegionRechazada(nodo, marco, indice, ex.Message));
                }
            }
            if (recorte.Childs.Count == 0 && areaAntesPrecision > 0.0)
                resultado.Rechazados.Add("El recorte solo dejó residuos de precisión no creables (" +
                    (areaAntesPrecision / 1000000.0).ToString("0.######") +
                    " mm²). No se confunde este resultado con cobertura total de la cara.");
            resultado.Diagnostico = "Recorte directo en el plano de la cara: " + resultado.Perfiles.Count +
                " regiones reales; " + resultado.SolidosDescontados + " sólidos en el espesor exterior. " +
                "Sin particiones por franjas ni ensanchamiento de huellas. " +
                "Ajuste numérico de área: " + ((areaDespuesPrecision - areaAntesPrecision) / 1000000.0)
                    .ToString("0.######", System.Globalization.CultureInfo.InvariantCulture) + " mm². " +
                "Encuentros locales corregidos: " + resultado.AjustesLocales.Count +
                "; residuos sin interior representable a resolución nativa: " + resultado.ResiduosSinInteriorNativo +
                "; área retirada de los bocetos ajustados: " + resultado.AreaRetiradaLocal
                    .ToString("0.######", System.Globalization.CultureInfo.InvariantCulture) + " mm².";
            return resultado;
        }

        // Construcción única para el validador de producción y la aceptación
        // nativa: mismas coordenadas XY, colineales y CurveLoop.Append.
        internal static List<CurveLoop> CrearBocetoHorizontal(
            List<List<IntPoint>> caminos, double factor, XYZ origen, XYZ u, XYZ v,
            double curvaCorta)
        {
            if (caminos == null || caminos.Count == 0 || origen == null || u == null || v == null ||
                double.IsNaN(factor) || double.IsInfinity(factor) || factor <= 0.0)
                throw new InvalidOperationException("Datos incompletos del boceto horizontal.");
            var horizontal = new Marco
            {
                Origen = origen,
                U = new XYZ(u.X, u.Y, 0.0),
                V = new XYZ(v.X, v.Y, 0.0),
                N = XYZ.BasisZ
            };
            return caminos.Select(p => CrearContorno(p, horizontal, curvaCorta, factor)).ToList();
        }

        private static List<CurveLoop> ProyectarHorizontal(IList<CurveLoop> perfil, double z)
        {
            var resultado = new List<CurveLoop>();
            foreach (CurveLoop contorno in perfil)
            {
                var curvas = contorno.ToList();
                // En una cara horizontal basta una traslación y se conservan arcos.
                if (contorno.HasPlane() &&
                    contorno.GetPlane().Normal.CrossProduct(XYZ.BasisZ).GetLength() <= 1e-10)
                {
                    double zActual = contorno.GetPlane().Origin.Z;
                    resultado.Add(CurveLoop.CreateViaTransform(contorno,
                        Transform.CreateTranslation(new XYZ(0.0, 0.0, z - zActual))));
                }
                else
                {
                    var puntos = new List<XYZ>();
                    foreach (Curve curva in curvas)
                        foreach (XYZ p in curva.Tessellate())
                        {
                            var xy = new XYZ(p.X, p.Y, z);
                            if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(xy) > 1e-9)
                                puntos.Add(xy);
                        }
                    if (puntos.Count > 1 && puntos[0].DistanceTo(puntos[puntos.Count - 1]) <= 1e-9)
                        puntos.RemoveAt(puntos.Count - 1);
                    var horizontal = new CurveLoop();
                    for (int i = 0; i < puntos.Count; i++)
                        horizontal.Append(Line.CreateBound(puntos[i], puntos[(i + 1) % puntos.Count]));
                    resultado.Add(horizontal);
                }
            }
            return resultado;
        }

        private static string DescribirCandidatoNativo(List<List<IntPoint>> caminos,
            double factor, Marco marco, IList<CurveLoop> bucles, int region, int intento,
            string motivo, double curvaCorta, double vertices, double angular, ref int presupuesto)
        {
            var texto = new System.Text.StringBuilder();
            var cultura = System.Globalization.CultureInfo.InvariantCulture;
            texto.AppendLine("CANDIDATO HORIZONTAL FINAL presentado a la validación nativa.");
            texto.AppendLine("Región " + region + "; intento " + intento + "; " + motivo);
            texto.AppendLine("Factor=" + factor.ToString("G17", cultura) +
                "; ShortCurveTolerance=" + curvaCorta.ToString("G17", cultura) +
                "; VertexTolerance=" + vertices.ToString("G17", cultura) +
                "; AngleTolerance=" + angular.ToString("G17", cultura) + ". XYZ en pies internos.");
            for (int r = 0; r < caminos.Count; r++)
            {
                texto.AppendLine("Contorno " + (r + 1) + ": " + caminos[r].Count + " vértices.");
                if (bucles != null && r < bucles.Count)
                    try
                    {
                        texto.AppendLine("IsOpen=" + bucles[r].IsOpen() + "; HasPlane=" + bucles[r].HasPlane());
                        if (bucles[r].HasPlane())
                            texto.AppendLine("Normal de plano=" + bucles[r].GetPlane().Normal);
                    }
                    catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
                    { throw new System.OperationCanceledException("Operación cancelada en Revit.", ex); }
                    catch (System.OperationCanceledException) { throw; }
                    catch (Exception ex) { texto.AppendLine("Estado de loop no disponible: " + ex.GetType().Name); }
                foreach (IntPoint punto in caminos[r])
                {
                    if (presupuesto-- <= 0)
                    {
                        texto.AppendLine("CANDIDATOS TRUNCADOS: presupuesto de 10000 puntos agotado.");
                        return texto.ToString();
                    }
                    XYZ p = marco.Modelo(punto, factor);
                    texto.AppendLine("  (" + p.X.ToString("G17", cultura) + ", " +
                        p.Y.ToString("G17", cultura) + ", " + p.Z.ToString("G17", cultura) + ")");
                }
            }
            if (bucles != null)
            {
                int pruebas = 0, encontrados = 0;
                for (int r = 0; r < bucles.Count; r++)
                    for (int s = r; s < bucles.Count; s++)
                    {
                        var a = bucles[r].ToList();
                        var b = bucles[s].ToList();
                        for (int i = 0; i < a.Count && pruebas < 4096; i++)
                            for (int j = 0; j < b.Count && pruebas < 4096; j++)
                            {
                                if (r == s && (j <= i || j == i + 1 || i == 0 && j == a.Count - 1)) continue;
                                pruebas++;
                                try
                                {
                                    SetComparisonResult estado;
                                    using (CurveIntersectResult interseccion = a[i].Intersect(
                                        b[j], CurveIntersectResultOption.Simple))
                                        estado = interseccion.Result;
                                    if (estado != SetComparisonResult.Disjoint && encontrados++ < 16)
                                        texto.AppendLine("Intersección nativa no adyacente: contornos " +
                                            (r + 1) + "/" + (s + 1) + ", aristas " + (i + 1) + "/" + (j + 1) +
                                            "; " + estado);
                                }
                                catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
                                { throw new System.OperationCanceledException("Operación cancelada en Revit.", ex); }
                                catch (System.OperationCanceledException) { throw; }
                                catch (Exception ex)
                                {
                                    if (encontrados++ < 16)
                                        texto.AppendLine("Prueba nativa de intersección no disponible: " + ex.GetType().Name);
                                }
                            }
                    }
                texto.AppendLine("Pares nativos comprobados=" + Math.Min(pruebas, 4096) +
                    "; resultados no disjuntos/errores=" + encontrados + ".");
            }
            return texto.ToString();
        }

        internal static bool ValidarExtrusionHorizontal(IList<CurveLoop> perfil,
            double espesor, out string detalle)
        {
            return ValidarExtrusionHorizontalInterna(perfil, espesor, false, out detalle);
        }

        internal static bool ValidarExtrusionHorizontalEstricta(IList<CurveLoop> perfil,
            double espesor, out string detalle)
        {
            return ValidarExtrusionHorizontalInterna(perfil, espesor, true, out detalle);
        }

        private static bool ValidarExtrusionHorizontalInterna(IList<CurveLoop> perfil,
            double espesor, bool propagarErrores, out string detalle)
        {
            detalle = string.Empty;
            try
            {
                if (perfil == null || perfil.Count == 0 || double.IsNaN(espesor) ||
                    double.IsInfinity(espesor) || espesor <= 0.0)
                {
                    detalle = "Perfil o espesor incompleto antes de probar la extrusión.";
                    return false;
                }
                if (!BoundaryValidation.IsValidHorizontalBoundary(perfil))
                {
                    detalle = "BoundaryValidation rechazó la frontera horizontal.";
                    return false;
                }
                var temporales = new List<CurveLoop>();
                foreach (CurveLoop contorno in perfil)
                {
                    var curvas = contorno.ToList();
                    // La utilidad de extrusión exige dividir un círculo de una
                    // sola curva. Se clona solo para esta prueba; el boceto que
                    // recibirá Floor.Create conserva sus arcos originales.
                    if (curvas.Count == 1 && curvas[0].IsCyclic)
                    {
                        Curve original = curvas[0];
                        double inicio = original.IsBound ? original.GetEndParameter(0) : 0.0;
                        double fin = original.IsBound ? original.GetEndParameter(1) : original.Period;
                        Curve primera = original.Clone(), segunda = original.Clone();
                        primera.MakeBound(inicio, (inicio + fin) / 2.0);
                        segunda.MakeBound((inicio + fin) / 2.0, fin);
                        var dividido = new CurveLoop();
                        dividido.Append(primera);
                        dividido.Append(segunda);
                        temporales.Add(dividido);
                    }
                    else
                    {
                        temporales.Add(contorno);
                    }
                }
                using (Solid temporal = GeometryCreationUtilities.CreateExtrusionGeometry(
                    temporales, XYZ.BasisZ, espesor))
                {
                    if (temporal == null || double.IsNaN(temporal.Volume) ||
                        double.IsInfinity(temporal.Volume) || temporal.Volume <= 0.0 ||
                        temporal.Faces == null || temporal.Faces.Size == 0)
                    {
                        detalle = "El kernel no produjo una extrusión con volumen positivo.";
                        return false;
                    }
                    detalle = "Extrusión temporal aprobada: contornos=" + perfil.Count +
                        "; caras=" + temporal.Faces.Size + "; volumen=" + temporal.Volume
                            .ToString("G17", System.Globalization.CultureInfo.InvariantCulture) + " ft³.";
                }
                return true;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
            { throw new System.OperationCanceledException("Operación cancelada en Revit.", ex); }
            catch (System.OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                detalle = "Extrusión preliminar: " + ex.GetType().Name + " - " + ex.Message;
                if (propagarErrores)
                    throw;
                return false;
            }
        }

        private static string DescribirRegionRechazada(PolyNode nodo, Marco marco, int indice, string motivo)
        {
            var texto = new System.Text.StringBuilder();
            var cultura = System.Globalization.CultureInfo.InvariantCulture;
            texto.AppendLine("Región " + indice + "; " + motivo);
            texto.AppendLine("DOMINIO RAW de origen; los candidatos horizontales finales se registran por separado.");
            texto.AppendLine("Contornos cerrados resultantes antes de crear CurveLoop. XYZ en pies internos.");
            var contornos = new List<PolyNode> { nodo };
            contornos.AddRange(nodo.Childs.Where(x => x.IsHole));
            int restantes = 10000;
            foreach (PolyNode contorno in contornos)
            {
                texto.AppendLine((contorno.IsHole ? "Hueco" : "Exterior") + ": " + contorno.Contour.Count + " vértices.");
                foreach (IntPoint p in contorno.Contour)
                {
                    if (restantes-- <= 0)
                    {
                        texto.AppendLine("GEOMETRÍA TRUNCADA: límite de 10000 vértices por región.");
                        return texto.ToString();
                    }
                    XYZ xyz = marco.Modelo(p);
                    texto.AppendLine("  (" + xyz.X.ToString("G17", cultura) + ", " +
                        xyz.Y.ToString("G17", cultura) + ", " + xyz.Z.ToString("G17", cultura) + ")");
                }
            }
            return texto.ToString();
        }

        private static Solid RecortarEntrePlanos(Solid candidato, XYZ origen, XYZ n, double espesor)
        {
            BoundingBoxXYZ caja = candidato.GetBoundingBox();
            if (caja == null)
                throw new InvalidOperationException("El sólido no tiene una caja geométrica válida.");
            double min = double.PositiveInfinity, max = double.NegativeInfinity;
            Transform tr = caja.Transform ?? Transform.Identity;
            foreach (double x in new[] { caja.Min.X, caja.Max.X })
                foreach (double y in new[] { caja.Min.Y, caja.Max.Y })
                    foreach (double z in new[] { caja.Min.Z, caja.Max.Z })
                    {
                        double d = (tr.OfPoint(new XYZ(x, y, z)) - origen).DotProduct(n);
                        min = Math.Min(min, d); max = Math.Max(max, d);
                    }
            if (max <= TolPlano || min >= espesor - TolPlano)
                return null; // Detrás, tangente o separado del acabado.
            Solid solido = candidato;
            if (min < 0.0)
                solido = BooleanOperationsUtils.CutWithHalfSpace(solido,
                    Plane.CreateByNormalAndOrigin(n, origen));
            if (solido == null || solido.Volume <= 1e-12)
                return null;
            if (max > espesor)
                solido = BooleanOperationsUtils.CutWithHalfSpace(solido,
                    Plane.CreateByNormalAndOrigin(n.Negate(), origen + n.Multiply(espesor)));
            return solido;
        }

        private static List<List<IntPoint>> ProyectarContornos(IList<CurveLoop> loops, Marco marco)
        {
            var caminos = new List<List<IntPoint>>();
            foreach (CurveLoop loop in loops)
            {
                if (loop == null || loop.IsOpen())
                    throw new InvalidOperationException("Se recibió un contorno abierto.");
                var puntos = new List<IntPoint>();
                foreach (Curve curva in loop)
                {
                    // En caras rectangulares son exactamente sus extremos.
                    // Las curvas reales usan la teselación de Revit solo cuando
                    // hay que representar un recorte mediante polígonos.
                    foreach (XYZ p in curva.Tessellate())
                    {
                        IntPoint uv = marco.Proyectar(p);
                        if (puntos.Count == 0 || puntos[puntos.Count - 1] != uv)
                            puntos.Add(uv);
                    }
                }
                puntos = RecortePlanoExterior.QuitarColineales(puntos);
                if (puntos.Count >= 3 && Math.Abs(Clipper.Area(puntos)) >= 0.5)
                    caminos.Add(puntos);
            }
            return caminos;
        }

        private static CurveLoop CrearContorno(List<IntPoint> camino, Marco marco, double curvaCorta,
            double factor = 1.0)
        {
            var puntos = RecortePlanoExterior.QuitarColineales(camino);
            if (puntos.Count < 3)
                throw new InvalidOperationException("El recorte dejó un contorno degenerado.");
            var loop = new CurveLoop();
            for (int i = 0; i < puntos.Count; i++)
            {
                XYZ a = marco.Modelo(puntos[i], factor), b = marco.Modelo(puntos[(i + 1) % puntos.Count], factor);
                if (a.DistanceTo(b) <= curvaCorta)
                    throw new InvalidOperationException("El boceto final conserva una arista de " +
                        (a.DistanceTo(b) * 304.8).ToString("0.######") +
                        " mm menor que ShortCurveTolerance. No se alteró ni dividió el paño.");
                loop.Append(Line.CreateBound(a, b));
            }
            return loop;
        }
    }
}
