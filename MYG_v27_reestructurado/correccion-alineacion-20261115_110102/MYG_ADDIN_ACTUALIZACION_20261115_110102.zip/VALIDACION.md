# Validación de alineación y diagnóstico

## Automatizado ejecutado
-56 pruebas aprobadas,0 fallidas. Distribución27, altura17, alineación12. Las nuevas ejercitan corrección de cada centro físico, diferencias propias de instancias, modo nativo que mantieneZ intacta, ajusteZ explícito, ceros, no finitos y overflow. Se usan los helpers reales del comando.
- Compilación aislada contra API Revit2027:0 errores/0 advertencias, C#7.3, referencias Windows. No sustituye compilar el complemento completo con su framework original ni ejecutar Revit.
-186 fuentes activas analizadas por Roslyn sin errores; rutas de proyecto completas/sin duplicados; git diff --check correcto.
- Compilación completa: MSB4803 (ResolveComReference no soportado por MSBuild .NET Core en Linux) y advertencia preexistente EPPlus.Interfaces. No hay DLL nueva del complemento completo.

Para repetir las pruebas con el proyecto opcional de la primera entrega y los archivos actualizados:
```bash
dotnet restore Pruebas/LadrillosLosas/BrickLayout.Tests.csproj --configfile Pruebas/LadrillosLosas/NuGet.Config
dotnet run --no-restore --project Pruebas/LadrillosLosas/BrickLayout.Tests.csproj
```
Requiere SDK .NET10; no añade paquetes. El ejecutable devuelve código no cero ante fallo. Durante esta entrega los outputs estuvieron fuera del checkout.

## Pendiente en Revit
El RVT adjunto excedió el límite de transferencia de32MiB y no se descargó; esta máquina no tiene Revit. No se ha accedido a su geometría ni reproducido el fallo sobre el ID indicado.

Repetir en una copia del modelo con el mismo suelo/origen/dirección y ajuste al intradós; repetir en modo nativo; verificar geometría, hospedaje, separaciones, no invadir huecos, cancelación y un solo Deshacer. Si se rechaza alguna instancia, recopilar el NUEVO texto con IDs y diferencias en mm. No reutilizar como diagnóstico el mensaje genérico de la versión anterior.

Los cuadros repetidos anteriores eran el mismo error mostrado dos veces, no dos fallos distintos. La confirmación de cantidad es normal.
