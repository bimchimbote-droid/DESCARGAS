using System;
using System.Collections.Generic;
using System.Numerics;
using MYG_Addin.RecorteClipper;

namespace MYG_Addin
{
    internal struct LadrilloPunto
    {
        public readonly double X;
        public readonly double Y;

        public LadrilloPunto(double x, double y)
        {
            X = x;
            Y = y;
        }
    }

    /// <summary>
    /// Distribución en el plano UV, en pies. Los anillos usan la regla par/impar:
    /// admite exteriores desconectados y huecos sin exigir un sentido de recorrido.
    /// Cada celda se comprueba completa por diferencia de polígonos, también cuando
    /// un hueco o entrante no contiene ninguna de sus cuatro esquinas.
    /// </summary>
    internal static class LadrillosLayout
    {
        private const double Escala = 10000000.0; // resolución de 0.0000001 pies
        private const double Resolucion = 1.0 / Escala;
        private const double LimiteCoordenada = 10000000.0;

        public static List<LadrilloPunto> Generar(
            IList<IList<LadrilloPunto>> contornos, LadrilloPunto origen,
            double largoU, double anchoV, double juntaU, double viguetaV,
            double margen, int maxCandidatos, int maxLadrillos)
        {
            Positivo(largoU, "largoU");
            Positivo(anchoV, "anchoV");
            NoNegativo(juntaU, "juntaU");
            NoNegativo(viguetaV, "viguetaV");
            NoNegativo(margen, "margen");
            ValidarPunto(origen);
            if (largoU < 2 * Resolucion || anchoV < 2 * Resolucion)
                throw new ArgumentException("Las dimensiones del ladrillo son menores que la precisión geométrica.");
            if (maxCandidatos <= 0 || maxLadrillos <= 0)
                throw new ArgumentOutOfRangeException("maxCandidatos", "Los límites de cantidad deben ser positivos.");
            double pasoU = largoU + juntaU, pasoV = anchoV + viguetaV;
            Positivo(pasoU, "pasoU");
            Positivo(pasoV, "pasoV");
            if (contornos == null || contornos.Count == 0)
                throw new ArgumentException("La losa no tiene contornos válidos.", "contornos");

            var anillos = new List<List<IntPoint>>();
            double minimoX = double.PositiveInfinity, minimoY = double.PositiveInfinity;
            double maximoX = double.NegativeInfinity, maximoY = double.NegativeInfinity;
            foreach (var contorno in contornos)
            {
                if (contorno == null || contorno.Count < 3)
                    throw new ArgumentException("Cada contorno debe tener al menos tres vértices.", "contornos");
                var anillo = new List<IntPoint>();
                foreach (var punto in contorno)
                {
                    ValidarPunto(punto);
                    double x = punto.X - origen.X, y = punto.Y - origen.Y;
                    var entero = Entero(x, y);
                    if (anillo.Count == 0 || anillo[anillo.Count - 1] != entero)
                        anillo.Add(entero);
                    minimoX = Math.Min(minimoX, x);
                    maximoX = Math.Max(maximoX, x);
                    minimoY = Math.Min(minimoY, y);
                    maximoY = Math.Max(maximoY, y);
                }
                if (anillo.Count > 1 && anillo[0] == anillo[anillo.Count - 1])
                    anillo.RemoveAt(anillo.Count - 1);
                if (anillo.Count < 3 || AreaDoble(anillo).IsZero)
                    throw new ArgumentException("Un contorno no tiene área suficiente o es degenerado.", "contornos");
                anillos.Add(anillo);
            }
            var normalizador = new Clipper { StrictlySimple = true };
            if (!normalizador.AddPaths(anillos, PolyType.ptSubject, true))
                throw new ArgumentException("No se pueden procesar los contornos de la losa.", "contornos");
            var dominio = new List<List<IntPoint>>();
            if (!normalizador.Execute(ClipType.ctUnion, dominio, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo resolver el área de la losa.");
            if (dominio.Count == 0)
                throw new ArgumentException("Los contornos no delimitan un área utilizable.", "contornos");

            // El origen corresponde a una ESQUINA de celda, no al centro.
            // Los índices negativos permiten que el punto elegido esté dentro
            // del paño y que la distribución continúe hacia ambos lados.
            long iMin = Indice(Math.Ceiling((minimoX + margen - Resolucion) / pasoU));
            long iMax = Indice(Math.Floor((maximoX - margen - largoU + Resolucion) / pasoU));
            long jMin = Indice(Math.Ceiling((minimoY + margen - Resolucion) / pasoV));
            long jMax = Indice(Math.Floor((maximoY - margen - anchoV + Resolucion) / pasoV));
            var centros = new List<LadrilloPunto>();
            if (iMax < iMin || jMax < jMin)
                return centros;
            // Se calcula antes de recorrer o reservar memoria. No truncar una
            // distribución grande ni aceptar silenciosamente un resultado parcial.
            double candidatos = ((double)iMax - iMin + 1) * ((double)jMax - jMin + 1);
            if (candidatos > maxCandidatos)
                throw new InvalidOperationException("La distribución supera el límite de " + maxCandidatos +
                    " posiciones candidatas. Aumente las dimensiones/separaciones o reduzca el paño.");

            for (long j = jMin; j <= jMax; j++)
            {
                for (long i = iMin; i <= iMax; i++)
                {
                    double x = i * pasoU, y = j * pasoV;
                    // Expandir la huella exige la separación de borde/huecos
                    // también a lo largo de sus cuatro lados. El margen es
                    // conservador en esquinas (distancia rectangular).
                    var rectangulo = new List<IntPoint>
                    {
                        Entero(x - margen, y - margen),
                        Entero(x + largoU + margen, y - margen),
                        Entero(x + largoU + margen, y + anchoV + margen),
                        Entero(x - margen, y + anchoV + margen)
                    };
                    var corte = new Clipper { StrictlySimple = true };
                    corte.AddPath(rectangulo, PolyType.ptSubject, true);
                    corte.AddPaths(dominio, PolyType.ptClip, true);
                    var fuera = new List<List<IntPoint>>();
                    if (!corte.Execute(ClipType.ctDifference, fuera, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                        throw new InvalidOperationException("No se pudo comprobar una huella de ladrillo.");
                    bool contieneFuera = false;
                    foreach (var poligono in fuera)
                    {
                        // Área entera exacta: no perder huecos estrechos por
                        // cancelación numérica de áreas con coordenadas grandes.
                        if (!AreaDoble(poligono).IsZero)
                        {
                            contieneFuera = true;
                            break;
                        }
                    }
                    if (contieneFuera)
                        continue;
                    if (centros.Count >= maxLadrillos)
                        throw new InvalidOperationException("La distribución supera el límite de " + maxLadrillos +
                            " ladrillos. No se ha creado ninguna colocación parcial.");
                    centros.Add(new LadrilloPunto(origen.X + x + largoU / 2.0,
                        origen.Y + y + anchoV / 2.0));
                }
            }
            return centros;
        }

        private static bool Finito(double numero)
        {
            return !double.IsNaN(numero) && !double.IsInfinity(numero);
        }

        private static void Positivo(double numero, string nombre)
        {
            if (!Finito(numero) || numero <= 0.0)
                throw new ArgumentOutOfRangeException(nombre, "El valor debe ser finito y mayor que cero.");
        }

        private static void NoNegativo(double numero, string nombre)
        {
            if (!Finito(numero) || numero < 0.0)
                throw new ArgumentOutOfRangeException(nombre, "El valor debe ser finito y no negativo.");
        }

        private static void ValidarPunto(LadrilloPunto punto)
        {
            if (!Finito(punto.X) || !Finito(punto.Y) || Math.Abs(punto.X) > LimiteCoordenada ||
                Math.Abs(punto.Y) > LimiteCoordenada)
                throw new ArgumentException("Las coordenadas UV deben ser finitas y próximas al origen de la losa.");
        }

        private static IntPoint Entero(double x, double y)
        {
            if (!Finito(x) || !Finito(y) || Math.Abs(x) > 2 * LimiteCoordenada || Math.Abs(y) > 2 * LimiteCoordenada)
                throw new ArgumentException("La extensión de los contornos supera el rango geométrico admitido.");
            return new IntPoint((long)Math.Round(x * Escala, MidpointRounding.AwayFromZero),
                (long)Math.Round(y * Escala, MidpointRounding.AwayFromZero));
        }

        private static long Indice(double numero)
        {
            if (!Finito(numero) || Math.Abs(numero) > 1000000000000000.0)
                throw new ArgumentException("La malla requiere índices fuera del rango admitido.");
            return (long)numero;
        }

        private static BigInteger AreaDoble(List<IntPoint> puntos)
        {
            BigInteger suma = BigInteger.Zero;
            for (int i = 0; i < puntos.Count; i++)
            {
                IntPoint a = puntos[i], b = puntos[(i + 1) % puntos.Count];
                suma += (BigInteger)a.X * b.Y - (BigInteger)a.Y * b.X;
            }
            return suma;
        }
    }

    /// <summary>
    /// Decide la cota de la base medida de la familia, en pies. Una familia
    /// hospedada conserva por defecto la misma altura que le asigna Revit al
    /// insertarla manualmente, aunque su geometría quede por encima o por
    /// debajo del espesor de la losa. El ajuste al intradós es una opción
    /// explícita; las familias sin anfitrión necesitan siempre ese ajuste.
    /// </summary>
    internal static class LadrillosAltura
    {
        private const double Tolerancia = 1e-6;

        internal static double CalcularBase(bool hospedado, bool ajustarBaseAlIntrados,
            double baseNativa, double inferior, double superior, double alto, double desfasePies)
        {
            ValidarFinito(baseNativa, "baseNativa");
            ValidarFinito(inferior, "inferior");
            ValidarFinito(superior, "superior");
            ValidarFinito(alto, "alto");
            ValidarFinito(desfasePies, "desfasePies");
            if (alto <= 0)
                throw new ArgumentOutOfRangeException("alto", "La familia debe tener una altura mayor que cero.");
            if (superior <= inferior)
                throw new ArgumentException("Las caras superior e inferior no delimitan un espesor de losa válido.");
            if (desfasePies < 0)
                throw new ArgumentOutOfRangeException("desfasePies", "El desfase desde el intradós no puede ser negativo.");

            if (hospedado && !ajustarBaseAlIntrados)
                return baseNativa;

            double baseAjustada = inferior + desfasePies;
            double cimaAjustada = baseAjustada + alto;
            ValidarFinito(baseAjustada, "baseAjustada");
            ValidarFinito(cimaAjustada, "cimaAjustada");
            if (baseAjustada < inferior - Tolerancia || cimaAjustada > superior + Tolerancia)
                throw new InvalidOperationException("El ladrillo no cabe dentro del espesor disponible " +
                    "con el ajuste al intradós y el desfase elegidos. Reduce el desfase, elige un tipo " +
                    "de menor altura o desactiva el ajuste al intradós para conservar la colocación " +
                    "nativa de una familia hospedada en suelo.");
            return baseAjustada;
        }

        private static void ValidarFinito(double valor, string nombre)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                throw new ArgumentOutOfRangeException(nombre, "La cota, altura o desfase debe ser un número finito.");
        }
    }

    internal struct LadrilloDesplazamiento
    {
        internal readonly double U;
        internal readonly double V;
        internal readonly double Z;

        internal LadrilloDesplazamiento(double u, double v, double z)
        {
            U = u;
            V = v;
            Z = z;
        }
    }

    /// <summary>
    /// Corrige cada instancia desde su centro físico recién medido. No supone
    /// que su origen de inserción coincida con el centro ni que varias copias
    /// hospedadas conserven el mismo desfase respecto a una plantilla.
    /// </summary>
    internal static class LadrillosAlineacion
    {
        internal static LadrilloDesplazamiento CalcularCorreccion(LadrilloPunto destino,
            LadrilloPunto centroReal, double baseReal, double baseDeseada, bool ajustarBase)
        {
            ValidarFinito(destino.X, "destino.X");
            ValidarFinito(destino.Y, "destino.Y");
            ValidarFinito(centroReal.X, "centroReal.X");
            ValidarFinito(centroReal.Y, "centroReal.Y");
            ValidarFinito(baseReal, "baseReal");
            ValidarFinito(baseDeseada, "baseDeseada");
            double u = destino.X - centroReal.X;
            double v = destino.Y - centroReal.Y;
            double z = ajustarBase ? baseDeseada - baseReal : 0.0;
            ValidarFinito(u, "correccion.U");
            ValidarFinito(v, "correccion.V");
            ValidarFinito(z, "correccion.Z");
            return new LadrilloDesplazamiento(u, v, z);
        }

        private static void ValidarFinito(double valor, string nombre)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                throw new ArgumentOutOfRangeException(nombre, "La posición medida y su corrección deben ser finitas.");
        }
    }
}
