# MYG: corrección de alineación y diagnóstico

## A. Resumen y base real
Actualización sobre `MYG_ADDIN_ACTUALIZACION_20261115_104712.zip` (SHA256 `fcec8f40633048a5f7c27bc39c9b9da09f513e9a898796760839cabc2b168cb9`), publicada en DESCARGAS en commit `426d07dbfe77d1c9b951e7c3a7f0f4a9ec1b6ace`. Se conserva el checkout actual `bimchimbote-droid/MYG_v27_reestructurado`, base Git `2a8977e8032d0bd9d12d7302b897d5096b0cf064` más las entregas anteriores. No se reemplazaron esos cambios ni dependencias por otra rama.

Esta actualización corrige problemas comprobados mediante revisión estática y añade mediciones para investigar el fallo restante, si lo hubiera. **No acredita una reproducción ni resolución verificada del caso dentro del modelo RVT del usuario.**

Las capturas muestran una confirmación normal de70 posiciones seguida del mismo error dos veces. El texto genérico anterior agrupaba siete condiciones y no identificaba cuál falló. Se encontraron estos problemas:
- Las dimensiones se calculaban antes de desplazar la plantilla al intradós; se volvía a medir su caja, pero no se actualizaban largo/ancho/alto.
- Cada instancia nueva recibía una compensación en planta estimada desde una única plantilla; después solo se corregía Z.
- El catch abría un TaskDialog y además devolvía Failed con el mismo mensaje, provocando los dos cuadros de error.

Ahora las dimensiones se actualizan después del ajuste; cada instancia se realinea según su centro físico recién medido, con corrección Z únicamente si el ajuste al intradós está activo. Se conservan las siete verificaciones finales y la tolerancia; no se desactivan para presentar un resultado como válido.

## B. Archivos afectados
| Ruta | Acción |
|---|---|
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaCommand.cs | REEMPLAZAR: corrección y diagnóstico completo |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLayout.cs | REEMPLAZAR: conserva motor/política de altura y añade helper de alineación usado por el comando |
| Pruebas/LadrillosLosas/Program.cs | REEMPLAZAR en proyecto de pruebas opcional:56 pruebas |

ARCHIVOS.csv contiene hashes antes/después. No hay nuevos archivos del complemento, eliminaciones, parches ni cambios del `.csproj`. Formulario, botón, referencias, paquetes y demás funcionalidades permanecen sin cambios y fuera de este ZIP. Se entregan solo archivos modificados desde la corrección anterior y documentos de esta actualización.

## C. Descarga y privacidad
La publicación y comprobación de descarga se informan en el mensaje de entrega una vez realizadas. **El modelo RVT y la familia RFA no están incluidos ni se publican.** Solo se publica el ZIP de código/pruebas/instrucciones autorizado.

El intento de descargar el RVT adjunto falló porque supera el límite de transferencia de32MiB de la herramienta. Esta máquina tampoco dispone de Revit para abrirlo. Por tanto no se leyó su geometría ni se inspeccionó el elemento solicitado en el archivo. No se presenta una suposición sobre la familia o el modelo como diagnóstico confirmado.

## D. Instalación
1. Cierra Revit y respalda tu solución y DLL de la corrección anterior.
2. Copia los dos archivos completos Command/Layout sobre sus rutas existentes. Si tienes cambios posteriores propios, compara/fusiona para no sobrescribirlos.
3. Si instalaste las pruebas opcionales, actualiza también su Program.cs. Conserva el csproj de pruebas y NuGet.Config de la entrega inicial. No añadas Program.cs al proyecto del add-in.
4. No modifiques el `.csproj` ni vuelvas a aplicar parches anteriores. Compila tu solución en Windows y sustituye MYG.dll en tu instalación habitual con Revit cerrado.
5. Reinicia Revit antes de volver a probar con AddInManager: una DLL ya cargada puede seguir activa aunque sustituyas su archivo.

## E. Prueba y diagnóstico del caso
Selecciona la losa de prueba indicada por el usuario y usa la misma dirección y opciones que producían el error. Las capturas anteriores dicen Base ajustada al intradós, por tanto esa prueba tenía el ajuste activado. Para comparar con la colocación manual de la familia hospedada, prueba también con Ajustar la base al intradós desmarcado; ese modo conserva la elevación nativa.

La primera ventana Crear N ladrillos completos es una **confirmación**, no un error. Si se completa la operación, verifica las instancias y un solo Deshacer. Si vuelve a rechazarse una colocación:
- Habrá un único aviso de error comunicado a Revit, sin el TaskDialog duplicado del comando.
- El nuevo mensaje Verificación geométrica no coincidente incluye ID del suelo, ID de instancia, familia/tipo, modo, tolerancia y SOLO las condiciones que incumplen: centro U/V, base/cimaZ o dimensiones.
- Para cada condición informa valor esperado, real y diferencia en mm; añade el desplazamiento XYZ aplicado.
- Expande/copia el texto completo del nuevo aviso para continuar el diagnóstico. El ID del suelo permite comprobar que se está operando sobre la losa deseada. El ID de instancia pertenece a una operación revertida y puede dejar de existir después del rollback.

El mensaje ya no atribuye una restricción a la familia sin datos. Si falla un requisito, se revierte toda la operación; no se conserva un lote parcial ni se afirma éxito.

## F. Validación
-56 pruebas ejecutadas:44 existentes y12 nuevas de alineación;0 fallos. El helper comprobado es el que usa el comando.
- Compilación aislada C#7.3/net10.0-windows contra las DLL reales disponibles de API Revit2027:0 advertencias y0 errores. Solo los adaptadores externos de integración del harness sustituyen la llamada de acceso/registro del botón; no se incluyen en el ZIP ni en el complemento.
- Análisis Roslyn de186 fuentes activas sin errores;186 Compile,9 EmbeddedResource y3 None existentes/sin duplicados; git diff --check correcto.
- Compilación completa intentada: vuelve a fallar MSB4803 por referencias COM en Linux/MSBuild .NET Core; conserva advertencia preexistente MSB3277 de EPPlus.Interfaces. No se entrega una DLL compilada completa.
- No se abrió el RVT ni se ejecutó Revit. El caso real queda pendiente de repetir con esta actualización y sus medidas.

## G. GitHub
Se publica únicamente el nuevo ZIP en una ruta nueva de DESCARGAS, conservando las entregas anteriores. No se publica el RVT, no se modifica la rama del repositorio de código ni tu PC. Tras instalar y comprobar, revisa Cambios de Git en Visual Studio, crea Commit y haz Push desde tu equipo cuando decidas publicar el código.

## H. Límites
Se mantienen el hospedaje de suelo, la elevación nativa por defecto, el ajuste al intradós opcional, las comprobaciones de contorno/huecos, dimensiones y anfitrión, y los límites de cantidad. No se amplió arbitrariamente la tolerancia ni se quitaron verificaciones finales. No hay llamadas para recortar el suelo del documento; Revit sigue aplicando el comportamiento propio de la familia hospedada. La compatibilidad pendiente del framework y los requisitos Windows/Revit del proyecto original no se modifican.

La revisión estática identifica defectos del algoritmo, pero no establece cuál de las siete condiciones disparó el error del modelo del usuario. Si persiste, el nuevo texto medido es el dato necesario para distinguir desalineación, altura, dimensiones o precisión numérica sin adivinar otra causa.
