# Pruebas del motor de bocetos exteriores R7 (base R6)

Desde la raíz del repositorio, con SDK .NET 10:

```bash
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj
```

El proyecto compila los archivos reales `RecortePlanoExterior.cs`, `Clipper.cs` y `TarrajeoAlturas.cs` mediante enlaces al código de producción. No copia algoritmos, no extrae métodos retirados y no simula el kernel de Revit. No necesita paquetes nuevos.

La suite anterior de recuperación por franjas se sustituye porque esa estrategia se retiró del flujo de suelos y del recorte planar de muros. `HarnessCases.cs` queda obsoleto y puede eliminarse; el proyecto lo excluye también si se conserva por error.

Los 25 casos base de R4 comprueban: rectángulo sin interferencias, muesca parcial, hueco interior, corte transversal con dos regiones reales, cobertura total, obstáculo externo, superficies duplicadas, obstáculos solapados, triangulación de rectángulos sin diagonales finales, triángulos finos sin ensanchamiento, huecos originales, huecos en un obstáculo, islas, orientación inversa, rectángulos rotados, separaciones reales, colineales redundantes, equivalencia de dominios y contacto/alturas exteriores arriba y abajo.

Resultado de la base R4 ejecutado con SDK 10.0.403: **25/25 pasan**, salida 0. Son pruebas del nuevo motor y no los 25 casos antiguos de franjas. La compilación semántica del motor completo contra los metadatos reales de Revit incluidos también pasó (C# 7.3); la proyección, recorte 3D con planos, visibilidad y creación de elementos requieren comprobarse dentro de Revit.

La compilación completa del add-in Linux sigue bloqueada por MSB4803/COM, antes de producir una DLL. Estas pruebas no acreditan que el modelo particular del usuario ya funcione ni ejecutan Floor.Create, Transaction, CustomExporter o SlabShapeEditor.

## Revisión R5: precisión del contorno

Se mantienen los 25 casos de R4 y se añaden seis regresiones: retroceso casi colineal, dos residuos triangulares largos de anchura inferior a una micra, conservación de un bisel real de 0.5 mm, separación real de 0.01 mm y hueco real pequeño. La regularización opera a 0.002 mm y verifica su banda de 0.003 mm; no usa ShortCurveTolerance para borrar geometría.

Resultados con la misma suite: motor R4, 28 pasan y 3 fallan (salida 1); motor R5, **31/31 pasan** (salida 0). El proyecto y sus dependencias no cambian. Los cinco contornos reales del log se reprodujeron por separado en un fixture local privado: no se incluyen sus coordenadas en este repositorio ni en la entrega pública. Tampoco se ejecutó la API de Revit sobre esos contornos: se comprobaron la regularización, las áreas y la topología 2D.


## Revisión R6: ajuste local conservador de aristas cortas

Se conservan los 31 casos anteriores y se añaden diez pruebas de la operación explícita `AjustarAristasCortas`. La operación de resta y limpieza de precisión de R5 sigue conservando los detalles reales pequeños; el ajuste nuevo se solicita aparte con el mínimo de creación y un límite de distancia.

Los casos controlados usan rejilla de 0.001 mm, mínimo de 800 unidades y límite de 1000 unidades (1 mm). Esos valores son parámetros de prueba; el adaptador utiliza la tolerancia real de Revit con su margen de creación.

- Escalón de 0.5 mm con soportes paralelos: mantener una región y retirar material únicamente junto al encuentro.
- Bisel convexo exterior de unos 0.495 mm: impedir la esquina que añadiría material y permitir un recorte conservador.
- Bisel equivalente en un hueco: ampliar el vacío sin rellenarlo.
- Perfil ya válido: devolver el mismo dominio y área retirada cero.
- Distancia insuficiente: devolver fallo, el dominio original y área cero, sin filtrar candidatos provisionales.
- Hueco independiente: conservar exactamente su geometría.
- Arista de cierre, distintos vértices iniciales y rotación: conservar el contrato del ajuste.
- Dos defectos independientes: aceptar solo cuando ambos queden reparados.
- Fallo después de una corrección provisional: un bisel de aproximadamente 792 unidades admite el límite de 100, pero junto a otro de 495 la operación debe fallar y restituir TODO el dominio original, con área retirada cero.
- Paño de un metro rotado 17.03°, con escalón de 0.499673 mm y coordenadas cuantizadas antes de ajustar: mantener los soportes y el dominio sin que el redondeo cree material exterior.

Las aserciones comprueban el código de producción mediante reflexión, sin una segunda implementación del reparador: entrada sin mutaciones, ausencia de material nuevo, cierre topológico, mínimos, ausencia de cruces/contactos, un propietario con el mismo número de huecos y área retirada firmada. La región retirada debe quedar dentro de cápsulas de 1 mm alrededor de las aristas cortas originales, sin ampliar ese límite físico. No basta estar cerca de cualquier borde del paño; eso permitiría un offset global.

Los contornos aceptados pueden devolver un factor de refinado de coordenadas de hasta 1000000. Las comparaciones escalan el dominio original, mínimos y límite por ese mismo factor; el área retirada se compara con aritmética exacta BigInteger y se convierte otra vez a unidades base². La tolerancia de arco de las cápsulas independientes también se escala para conservar su error físico. El refinado permite mover un punto sobre un soporte oblicuo sin volver a redondearlo a la rejilla de 0.001 mm; no amplía el ajuste permitido. El fallo y la entrada sin aristas cortas ni contactos puntuales deben devolver factor 1.

Resultados ejecutados con la misma suite: motor R5, **31 pasan y 10 fallan** (salida 1, operación explícita ausente); motor R6, **41/41 pasan** (salida 0). No se ejecutan Revit, sus transacciones ni la creación real del suelo. El resultado del modelo particular sigue necesitando una prueba dentro de Revit.


## Revisión R7: apertura local de contactos puntuales

Se conservan intactos los 41 casos de R6 y su verificador `CheckLocalRepair`. Se añaden once regresiones y un verificador independiente para los cambios topológicos explícitos: contacto hueco-exterior como muesca, contacto de dos huecos como un hueco unido, contactos de triángulos y rectángulos, una rotación de 17.03° en un paño de un metro, conservación de un hueco independiente y de otro situado dentro del disco local pero separado por una distancia real, límites insuficientes, rollback exacto, contacto por segmento ya normalizado y conservación de una separación real de 0.5 mm.

El verificador nuevo exige un único propietario, el número esperado de huecos, anillos simples separados, todas las aristas por encima del mínimo y ningún material añadido. Compara áreas con `BigInteger`; toda retirada debe caber en la unión de discos físicos de 1 mm alrededor de los puntos de contacto ORIGINALES y cápsulas alrededor de las aristas cortas ORIGINALES. La entrada no puede mutar y un fallo debe devolver sus contornos originales exactos, factor 1 y área cero. No se permiten cambios por estar cerca de cualquier borde ni se relaja el verificador R6.

Los contactos y sus coordenadas son sintéticos. Un borde compartido ya resuelto por la resta booleana no necesita apertura adicional; los solapes por segmento de una entrada manual no normalizada se usan solo para comprobar el rechazo completo. La prueba de contactos mixtos no admitidos exige devolver todos los contornos originales; no acredita que internamente se haya confirmado una edición provisional antes del rechazo.

Resultados ejecutados con la misma suite: motor R6, **45 pasan y 7 fallan** (salida 1; fallan los contactos que requieren apertura); motor R7, **52/52 pasan** (salida 0). Los 41 casos anteriores conservan sus controles. Las pruebas no ejecutan Revit ni demuestran que el modelo particular del usuario funcione.


## Revisión R8: composición de vacíos y precisión dirigida

Se mantienen los primeros 41 casos y `CheckLocalRepair` sin cambios. La prueba R7 que exigía rechazar una entrada manual con contacto por segmento se actualiza al nuevo contrato: componer el exterior menos la unión de todos los vacíos y resolver después el contacto puntual independiente. Esa entrada debe producir una muesca y un hueco unido, sin rellenar zonas descontadas.

Se añaden nueve regresiones públicas con coordenadas enteras genéricas: una franja de 15 mm con dos rayos casi coincidentes que llegan a un contacto original, dos vacíos con esa misma condición, lado largo compartido con el exterior, lados parcialmente compartidos entre vacíos, solape de vacíos, vacíos duplicados y separaciones reales de 0.01 mm y 0.001 mm sin contacto. Una regresión crítica sitúa además un hueco independiente a solo 0.001 mm del soporte de cierre perpendicular de la franja numérica: debe conservarlo intacto y separado. Los dos últimos casos deben permanecer intactos aunque su distancia sea pequeña. No se copian las coordenadas del modelo ni el log privado.

El verificador R8 construye el material inicial independientemente como `exterior - unión(vacíos)`, después de escalar sus coordenadas al factor devuelto. No utiliza paridad/XOR entre vacíos, no suma sus áreas solapadas y no llama al clasificador o normalizador de producción. Comprueba subconjunto exacto y área con `BigInteger`, un único propietario, huecos esperados, anillos simples separados y longitudes mínimas. Una composición pura debe conservar exactamente el dominio y declarar área retirada cero.

La retirada adicional solo puede quedar en bandas de 0.003 mm alrededor de ambos rayos completos de distintos anillos que llegan al mismo contacto ORIGINAL y son casi coincidentes, o en los discos de 1 mm de contactos puntuales originales y las cápsulas de aristas cortas originales. La clasificación independiente exige al menos un par de rayos que apunten al mismo lado y cuyo extremo menor quede a como máximo 0.003 mm del soporte del mayor. Una vez probado ese contacto numérico, la banda se ancla a todos los rayos originales incidentes de los dos anillos participantes en ese mismo punto. Incluye también el lado original siguiente en el extremo del rayo menor, únicamente si su soporte intersecta el rayo mayor a como máximo 0.003 mm de ese extremo: ese cierre puede necesitar limpiar una esquina numérica perpendicular. Todos los segmentos permitidos se fijan a la entrada, antes de editar; no se autorizan nuevos centros durante los ajustes. La distancia permitida sigue siendo 0.003 mm, sin añadir una tolerancia de área. No se admite una banda global del perímetro ni se transforma una separación sin contacto en coincidencia.

Resultados ejecutados con la misma suite de 61 casos: snapshot R7, **53 pasan y 8 fallan** (salida 1); motor R8, **61/61 pasan** (salida 0). Fallan en R7 las coincidencias numéricas, los lados compartidos/solapes/duplicados y la entrada mixta ahora reconstruida. R8 conserva el hueco independiente situado a 0.001 mm del soporte de cierre y las separaciones sin contacto. Los primeros 41 casos y el cuerpo de `CheckLocalRepair` se compararon byte por byte con la entrega R7 y permanecen intactos. Las pruebas ejecutan geometría 2D y no `Floor.Create`, transacciones ni el modelo dentro de Revit.
