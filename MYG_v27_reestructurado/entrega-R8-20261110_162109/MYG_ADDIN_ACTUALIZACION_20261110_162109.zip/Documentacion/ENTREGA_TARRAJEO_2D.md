# Recomposición de fronteras — TARRAJEO-PLANO-R8

## Problema y base de instalación

Esta entrega se aplica sobre R7, publicada en DESCARGAS con commit `52600a3051a183222824b15e6a3722278a687f0b`.

El log adjunto contiene tres contornos R7 distintos que se rechazan antes de crear `CurveLoop` o llamar a `Floor.Create`:

- Un hueco toca el exterior entre bordes casi colineales. Los desajustes medidos son de aproximadamente 0.00020–0.00068 mm durante tramos de metros; las aristas originales superan unos 15 mm. La apertura puntual de R7 genera nuevos segmentos cortos en ese encuentro.
- Varios huecos comparten lados y aparecen residuos de 1–3 micras. R7 rechaza esos lados compartidos antes de intentar ajustar el perfil.
- Un hueco comparte varios segmentos con el exterior y debe representarse como una muesca. Exigir que conserve la cuenta original de huecos impide esa recomposición.

Los contornos del log se utilizan únicamente en una reproducción privada. Sus coordenadas, el modelo y el log no forman parte de la entrega pública. La reproducción 2D no ejecuta el modelo dentro de Revit.

## Funcionamiento de R8

El material disponible se recompone como **exterior menos la unión de todos sus huecos**, trabajando con coordenadas refinadas y conservando ese factor hasta crear las curvas. De esta forma, los lados interiores compartidos desaparecen y un vacío unido al exterior puede convertirse en muesca. La suma firmada de anillos inválidos no se utiliza como medida del material inicial.

A continuación se identifican contactos probados cuyos bordes incidentes son casi coincidentes. Se reconstruyen sus encuentros mediante las rectas soporte, retirando las pequeñas cuñas numéricas que los mantienen separados. Esta operación debe quedar dentro de una banda de **0.003 mm**, fijada sobre los bordes originales implicados en el contacto y el lado original que cierra su esquina. La banda puede recorrer un borde largo; su anchura sigue limitada a la precisión indicada. No se aplica una expansión general de los obstáculos.

Los vértices residuales que impiden crear las aristas se tratan probando su eliminación. La longitud del tramo no basta para decidir: toda la cuña retirada debe caber en la banda original de 0.003 mm y la edición debe ser un subconjunto exacto del material anterior, conservar una frontera admisible y reducir el número de vértices. No se utiliza una limpieza global para rediseñar el paño.

Después se mantienen la apertura de contactos puntuales de R7 y el ajuste de aristas de R6, con el mínimo real de `Application.ShortCurveTolerance` y el límite local de 1 mm. Los conectores nuevos deben superar el mínimo con su margen de creación: el mayor entre 1% y 0.002 mm.

La comprobación final exige:

- Ningún material añadido dentro de los vacíos o interferencias.
- Un único propietario por región reparada, con anillos simples y separados y sin aristas cortas.
- Conservación de los huecos independientes; una separación pequeña por sí sola no autoriza unirlos.
- Toda la retirada dentro de la unión fija de la banda numérica de 0.003 mm, los discos de 1 mm de los contactos originales y las cápsulas de 1 mm de las aristas cortas originales.

Los límites se anclan a la geometría anterior al ajuste. No se amplían desplazando sucesivamente los puntos de referencia. Si falla la reparación completa, se devuelven los contornos originales, área retirada cero y factor de coordenadas 1; no se confirman correcciones parciales.

La opción continúa activándose únicamente desde el flujo de suelos. La colocación exterior, el espesor y el recorte de muros conservan el comportamiento de R7.

## Archivos de esta entrega

| Acción | Ruta relativa | Cambio |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Recomposición de vacíos, precisión dirigida y validaciones. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Identificador y registros R8. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Regresiones genéricas de las clases de fallo observadas. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Comando, resultados y alcance de las pruebas. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP contiene esos cinco archivos, el parche alternativo `PARCHES/RECOMPONER_FRONTERAS_DESDE_R7.patch` y `MANIFIESTO_SHA256.txt`: **7 archivos**. No cambia la firma del método ni se requieren inclusiones de proyecto, referencias, paquetes o eliminaciones.

`TarrajeoRecorteExterior.cs`, `Tarrajeo_MurosHandler.cs`, `MYG.csproj`, `Clipper.cs`, los auxiliares de alturas/validación y el proyecto de pruebas siguen iguales respecto a R7 y quedan fuera del ZIP. Tampoco se incluyen logs, modelos, coordenadas privadas, DLL, bin/obj, credenciales ni cachés.

## Instalación y comprobación

1. Partir de R7, respaldar los archivos y comparar cualquier cambio propio posterior.
2. Reemplazar ambos archivos de producción respetando sus rutas. Copiar aparte las pruebas y la documentación. No sustituir el `.csproj` ni añadir entradas Compile duplicadas.
3. Como alternativa a copiar los dos archivos de producción, aplicar sobre R7 `git apply --check PARCHES/RECOMPONER_FRONTERAS_DESDE_R7.patch` y después `git apply PARCHES/RECOMPONER_FRONTERAS_DESDE_R7.patch`. No aplicar el parche después de copiarlos.
4. Compilar en la configuración real de Windows/Revit, actualizar la DLL, cerrar todas las instancias de Revit y abrir otra vez. El aviso o log debe mostrar `TARRAJEO-PLANO-R8`.
5. Probar en una copia sin los acabados generados por intentos anteriores, pues también cuentan como sólidos visibles. El comando no los borra automáticamente.
6. Revisar los registros de recomposición, ajuste y área retirada. Describen el boceto 2D aceptado; el contador de suelos confirmados indica los elementos realmente creados.

## Validación y límites

La suite compila y ejecuta el código real del motor: **R8 pasa 61/61 pruebas**. La misma suite sobre R7 pasa 53 y falla 8. El README recoge el comando y el detalle. Las regresiones públicas usan geometrías genéricas y comprueban la recomposición de lados compartidos, el tratamiento dirigido de cuñas numéricas, la conservación del material disponible y de huecos independientes, los mínimos de creación y la devolución íntegra del original cuando falla una reparación.

La reproducción privada de los tres contornos del log pasó las seis comprobaciones con mínimos de creación de 0.79375 y 0.8 mm. Se verificaron subconjunto exacto, área retirada, entrada intacta, anillos simples y separados y todas las longitudes finales por encima del mínimo configurado. Sus resultados corresponden a operaciones 2D; la creación del suelo, sus transacciones y el contacto exterior deben validarse en Revit.

La compilación semántica de los tres archivos completos del motor y de los métodos reales del flujo modificado pasó con C# 7.3 y 81 referencias de metadatos reales de Revit, sin ejecutar la aplicación. La compilación completa en Linux continúa bloqueada por MSB4803/ResolveComReference; no se produce una DLL aquí ni se migran las dependencias de la solución Windows.

Se conserva el rechazo si la reparación exige salir de los límites, añade material, une un hueco ajeno o requiere dividir una región reparada en varios propietarios. Las regiones realmente separadas que produce la resta se procesan individualmente. Esta corrección no garantiza que cualquier geometría del modelo pueda convertirse en un suelo admisible por Revit.

## Entrega

Se publica únicamente el ZIP en una carpeta nueva de `bimchimbote-droid/DESCARGAS`, conservando las entregas anteriores. Se verifica mediante un clon independiente, comparando bytes, SHA-256, integridad y manifiesto. No se generan ni se envían enlaces de descarga.

Esta publicación no actualiza la instalación local ni realiza Commit/Push al repositorio del código. Después de aplicar y validar en Revit, se pueden incorporar los cambios revisados desde Visual Studio. El modelo y el log geométrico deben permanecer fuera de la entrega pública.
