using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin.RecorteClipper;

namespace MYG_Addin
{
    // Operaciones de conjuntos en UN plano. Los triángulos de una superficie
    // son datos de entrada, nunca piezas de acabado ni contornos de salida.
    internal static class RecortePlanoExterior
    {
        internal static List<List<IntPoint>> UnirRegion(IEnumerable<List<IntPoint>> contornos)
        {
            var caminos = contornos.Where(x => x != null && x.Count >= 3 &&
                Math.Abs(Clipper.Area(x)) >= 0.5).ToList();
            if (caminos.Count == 0)
                return new List<List<IntPoint>>();
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(caminos, PolyType.ptSubject, true))
                throw new InvalidOperationException("No se pudo registrar un contorno de la región.");
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo normalizar una región plana.");
            return Clipper.PolyTreeToPaths(arbol);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes)
        {
            double antes, despues;
            return Restar(cara, superficiesCortantes, out antes, out despues);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes,
            out double areaAntesPrecision, out double areaDespuesPrecision)
        {
            areaAntesPrecision = areaDespuesPrecision = 0.0;
            var sujeto = UnirRegion(cara);
            if (sujeto.Count == 0)
                throw new InvalidOperationException("La cara seleccionada no contiene una región cerrada.");
            // Normalizar CADA superficie con sus huecos antes de unirlas.
            // Duplicados de tapas y triángulos nunca se cancelan entre sí.
            var cortes = new List<List<IntPoint>>();
            foreach (var superficie in superficiesCortantes)
                cortes.AddRange(UnirRegion(superficie));
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (cortes.Count > 0)
                motor.AddPaths(cortes, PolyType.ptClip, true);
            var resultado = new PolyTree();
            if (!motor.Execute(ClipType.ctDifference, resultado,
                PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo descontar la unión de interferencias.");
            areaAntesPrecision = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            resultado = RegularizarPrecision(resultado);
            double areaOriginal = sujeto.Sum(Clipper.Area);
            double areaFinal = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            areaDespuesPrecision = areaFinal;
            double toleranciaNumerica = Math.Max(1.0, Math.Abs(areaOriginal) * 1e-12) +
                3.0 * sujeto.Sum(Perimetro) + 36.0 * sujeto.Count;
            if (areaFinal < -toleranciaNumerica || areaFinal > areaOriginal + toleranciaNumerica)
                throw new InvalidOperationException("El recorte no conserva el área de la cara.");
            return resultado;
        }

        // Una celda equivale a 0.001 mm en el adaptador Revit. El redondeo de
        // rectas oblicuas puede convertir un retroceso colineal en una aguja
        // de anchura inferior a una celda. Revit la considera solape aunque
        // sus dos aristas sean largas y el CurveLoop esté cerrado y horizontal.
        internal static PolyTree RegularizarPrecision(PolyTree original)
        {
            var antes = Clipper.PolyTreeToPaths(original);
            if (antes.Count == 0)
                return original;
            var limpios = Clipper.CleanPolygons(antes, 2.0).Where(x => x.Count >= 3).ToList();
            if (antes.Count == limpios.Count && antes.Zip(limpios, (a, b) => a.SequenceEqual(b)).All(x => x))
                return original;
            var despues = new PolyTree();
            if (limpios.Count > 0)
            {
                var union = new Clipper { StrictlySimple = true };
                union.AddPaths(limpios, PolyType.ptSubject, true);
                if (!union.Execute(ClipType.ctUnion, despues, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                    throw new InvalidOperationException("No se pudo regularizar la precisión del contorno.");
            }
            var nuevos = Clipper.PolyTreeToPaths(despues);
            // No confiar solo en el área: exigir que no aparezca material fuera
            // de una envolvente de 3 celdas y que se conserve todo el interior
            // situado a más de 3 celdas del borde original. Así no se rediseña
            // un paño ni se elimina un hueco fuera de esa banda de precisión.
            var offset = new ClipperOffset();
            offset.AddPaths(antes, JoinType.jtMiter, EndType.etClosedPolygon);
            var exterior = new List<List<IntPoint>>();
            var interior = new List<List<IntPoint>>();
            offset.Execute(ref exterior, 3.0);
            offset.Execute(ref interior, -3.0);
            if (HayDiferenciaConArea(nuevos, exterior) || HayDiferenciaConArea(interior, nuevos))
                throw new InvalidOperationException("La limpieza excedería 0.003 mm; se conservó el rechazo del contorno.");
            double delta = Math.Abs(nuevos.Sum(Clipper.Area) - antes.Sum(Clipper.Area));
            if (delta > 3.0 * antes.Sum(Perimetro) + 36.0 * antes.Count)
                throw new InvalidOperationException("La limpieza alteraría un área no atribuible a la precisión numérica.");
            return despues;
        }

        // Ajuste explícito de encuentros, posterior a la limpieza de precisión.
        // minimo/limite están en celdas de 0.001 mm; areaRetirada en celdas².
        // Las coordenadas de salida se dividen por factorCoordenadas antes de
        // convertirlas a Revit: no volver a redondear el encuentro oblicuo.
        // Nunca modificar nodo: si algún encuentro no admite solución, devolver
        // false con el propietario original, sin confirmar ediciones parciales.
        // Esta API conserva su contrato de un propietario. Para TODOS los
        // componentes naturales del dominio utilizar AjustarPerfiles.
        internal static bool AjustarAristasCortas(PolyNode nodo, double minimo, double limite,
            out List<List<IntPoint>> contornos, out double areaRetirada, out string diagnostico,
            out double factorCoordenadas)
        {
            var entrada = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            entrada.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            factorCoordenadas = 1.0;
            if (double.IsNaN(minimo) || double.IsInfinity(minimo) || minimo <= 0.0 ||
                double.IsNaN(limite) || double.IsInfinity(limite) || limite <= 2.0)
                return AjustarAristasEnRejilla(nodo, minimo, limite, out contornos,
                    out areaRetirada, out diagnostico, 1.0);
            List<IntPoint> contactos;
            int anillosEsperados;
            bool abrirContactos = ContactosEntreAnillos(entrada, out contactos, out anillosEsperados) &&
                contactos.Count > 0;
            List<List<IntPoint>> comprobacion;
            bool recomponer = !NormalizarPropietario(entrada, entrada.Count - 1, out comprobacion);
            if (!recomponer && !abrirContactos && AristasCortas(entrada, minimo).Count == 0)
                return AjustarAristasEnRejilla(nodo, minimo, limite, out contornos,
                    out areaRetirada, out diagnostico, 1.0);
            double maximo = entrada.SelectMany(x => x).Max(p => Math.Max(Math.Abs((double)p.X), Math.Abs((double)p.Y)));
            long factor = (long)Math.Max(1.0, Math.Min(1000000.0, Math.Floor(1e14 / (maximo + limite + 1.0))));
            var raiz = new PolyTree();
            var refinado = new PolyNode();
            raiz.AddChild(refinado);
            refinado.Contour.AddRange(entrada[0].Select(p => new IntPoint(p.X * factor, p.Y * factor)));
            foreach (var camino in entrada.Skip(1))
            {
                var hueco = new PolyNode();
                refinado.AddChild(hueco);
                hueco.Contour.AddRange(camino.Select(p => new IntPoint(p.X * factor, p.Y * factor)));
            }
            double areaRefinada;
            bool ajustado = recomponer
                ? RecomponerEncuentros(refinado, minimo * factor, limite * factor,
                    out contornos, out areaRefinada, out diagnostico, factor)
                : AjustarAristasEnRejilla(refinado, minimo * factor, limite * factor,
                    out contornos, out areaRefinada, out diagnostico, factor);
            if (!ajustado)
            {
                contornos = entrada;
                areaRetirada = 0.0;
                return false;
            }
            factorCoordenadas = factor;
            areaRetirada = areaRefinada / factor / factor;
            return true;
        }

        // Un nodo recibido del recorte puede contener vacíos que, al recomponer
        // sus lados compartidos con precisión, separan varios paños REALES.
        // No aplanar esos exteriores en un solo perfil ni elegir solo el mayor.
        // Todos comparten factor; solo publicar el conjunto si todos validan.
        // El callback no cambia el documento ni los contornos: permite comprobar
        // la extrusión nativa antes de elegir entre aperturas locales acotadas.
        internal static bool AjustarPerfiles(PolyNode nodo, double minimo, double limite,
            out List<List<List<IntPoint>>> perfiles, out double areaRetirada,
            out string diagnostico, out double factorCoordenadas,
            Func<List<List<IntPoint>>, double, bool> validador = null)
        {
            perfiles = new List<List<List<IntPoint>>>();
            areaRetirada = 0.0;
            factorCoordenadas = 1.0;
            diagnostico = "Datos no válidos para preparar todos los paños de la cara.";
            if (nodo == null || nodo.Contour.Count < 3 ||
                double.IsNaN(minimo) || double.IsInfinity(minimo) || minimo <= 0.0 ||
                double.IsNaN(limite) || double.IsInfinity(limite) || limite <= 2.0)
                return false;
            var raw = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            raw.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            double maximo = raw.SelectMany(x => x).Max(p =>
                Math.Max(Math.Abs((double)p.X), Math.Abs((double)p.Y)));
            long factor = (long)Math.Max(1.0, Math.Min(1000000.0,
                Math.Floor(1e14 / (maximo + limite + 1.0))));
            var refinados = raw.Select(p => p.Select(v =>
                new IntPoint(v.X * factor, v.Y * factor)).ToList()).ToList();
            PolyTree baseArbol = DominioConVaciosUnidos(refinados);
            var propietarios = new List<PolyNode>();
            for (var n = baseArbol.GetFirst(); n != null; n = n.GetNext())
                if (!n.IsHole) propietarios.Add(n);
            if (propietarios.Count == 0)
            {
                diagnostico = "La recomposición no deja material disponible para crear un paño.";
                return false;
            }
            var inicial = Clipper.PolyTreeToPaths(baseArbol);
            var preparados = new List<List<List<IntPoint>>>();
            var detalles = new List<string>();
            int rechazadosNativos = 0;
            for (int indice = 0; indice < propietarios.Count; indice++)
            {
                // En el caso de un solo dueño conservar también los soportes
                // RAW de R8, que pueden desaparecer al unir vacíos coincidentes.
                // Al separarse varios dueños, cada uno es ya una región natural.
                PolyNode original = propietarios.Count == 1
                    ? NodoDeContornos(refinados) : propietarios[indice];
                var ensayados = new List<List<List<IntPoint>>>();
                var nativosEnsayados = new List<List<List<IntPoint>>>();
                var respuestasNativas = new List<bool>();
                List<List<List<IntPoint>>> elegidos = null;
                string detalleElegido = string.Empty;
                string ultimoFallo = "No existe una frontera completa dentro de los límites locales.";
                Func<List<List<IntPoint>>, bool> probarNativo = caminos =>
                {
                    if (validador == null)
                        return true;
                    for (int i = 0; i < nativosEnsayados.Count; i++)
                        if (!HayDiferenciaExacta(caminos, nativosEnsayados[i]) &&
                            !HayDiferenciaExacta(nativosEnsayados[i], caminos))
                            return respuestasNativas[i];
                    bool aceptado;
                    try
                    {
                        aceptado = validador(CopiarContornos(caminos), factor);
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        aceptado = false;
                        ultimoFallo = "La validación nativa del paño no terminó: " +
                            ex.GetType().Name + " - " + ex.Message;
                    }
                    nativosEnsayados.Add(CopiarContornos(caminos));
                    respuestasNativas.Add(aceptado);
                    if (!aceptado)
                        rechazadosNativos++;
                    return aceptado;
                };
                int modos = validador == null ? 1 : 5;
                for (int modo = 0; modo < modos; modo++)
                {
                    List<List<IntPoint>> candidato;
                    double retiradaCandidato;
                    string detalle;
                    if (!RecomponerEncuentros(original, minimo * factor, limite * factor,
                        out candidato, out retiradaCandidato, out detalle, factor, modo))
                    {
                        ultimoFallo = detalle;
                        continue;
                    }
                    // No repetir pruebas de extrusión del mismo dominio aunque
                    // la búsqueda llegue a él con otro orden de vértices o modo.
                    if (ensayados.Any(p => !HayDiferenciaExacta(candidato, p) &&
                        !HayDiferenciaExacta(p, candidato)))
                        continue;
                    ensayados.Add(CopiarContornos(candidato));
                    if (probarNativo(candidato))
                    {
                        elegidos = new List<List<List<IntPoint>>> { CopiarContornos(candidato) };
                        detalleElegido = detalle;
                        break;
                    }
                    ultimoFallo = "La validación nativa rechazó los candidatos distintos del paño.";
                    // La precisión de las booleanas es mayor que la del kernel
                    // de Revit: puede quedar una vuelta o un cuello submicrométrico
                    // con aristas largas. Solo normalizar al probar ese defecto
                    // y después de un rechazo REAL del validador; no erosionar
                    // perfiles válidos ni hacerlo por un rechazo arbitrario.
                    if (validador != null && TieneInestabilidadFinal(candidato, 3.0 * factor))
                    {
                        foreach (double erosion in new[] { 0.0, 1.0, 1.25, 1.5 })
                        {
                            List<List<List<IntPoint>>> normalizados;
                            double retiradaFinal;
                            int verticesRetirados;
                            if (!NormalizarFinalConservador(candidato, minimo * factor, factor,
                                erosion, out normalizados, out retiradaFinal, out verticesRetirados))
                                continue;
                            bool todosValidos = true;
                            foreach (var perfil in normalizados)
                                if (!probarNativo(perfil))
                                {
                                    todosValidos = false;
                                    break;
                                }
                            if (!todosValidos)
                                continue;
                            elegidos = normalizados;
                            detalleElegido = detalle + " Normalización final conservadora: " +
                                normalizados.Count + " fragmentos naturales; erosión " +
                                (erosion / 1000.0).ToString("0.######",
                                    System.Globalization.CultureInfo.InvariantCulture) +
                                " mm; banda original máxima 0.003 mm; vértices retirados " +
                                verticesRetirados + "; área retirada adicional " +
                                (retiradaFinal / factor / factor / 1000000.0).ToString("0.######",
                                    System.Globalization.CultureInfo.InvariantCulture) + " mm².";
                            break;
                        }
                        if (elegidos != null)
                            break;
                    }
                }
                if (elegidos == null)
                {
                    diagnostico = "Paño natural " + (indice + 1) + " de " + propietarios.Count +
                        ": " + ultimoFallo + " No se confirmó ningún perfil de esta región.";
                    return false;
                }
                preparados.AddRange(elegidos.Select(CopiarContornos));
                detalles.Add("Paño natural " + (indice + 1) + ": " + detalleElegido);
            }
            var unionPreparada = preparados.SelectMany(p => p).ToList();
            var canonPreparado = Clipper.PolyTreeToPaths(OperarContornos(unionPreparada,
                new List<List<IntPoint>>(), ClipType.ctUnion));
            // Las piezas se procesan por separado, pero deben seguir siendo una
            // partición sin solapes del material canónico disponible de la cara.
            if (preparados.Count < propietarios.Count ||
                preparados.Any(p => !FronteraFinalValida(p, minimo * factor)) ||
                HayDiferenciaExacta(canonPreparado, inicial) ||
                AreaDobleExacta(unionPreparada) != AreaDobleExacta(canonPreparado))
            {
                diagnostico = "El conjunto final no conserva una partición válida de los paños naturales.";
                return false;
            }
            var areaDobleRetirada = AreaDobleExacta(inicial) - AreaDobleExacta(canonPreparado);
            if (areaDobleRetirada < 0)
            {
                diagnostico = "El conjunto final añadiría material a la región disponible.";
                return false;
            }
            perfiles = preparados;
            areaRetirada = (double)areaDobleRetirada / 2.0 / factor / factor;
            factorCoordenadas = factor;
            diagnostico = "Paños naturales conservados: " + perfiles.Count +
                "; candidatos rechazados por validación nativa: " + rechazadosNativos + ". " +
                string.Join(" ", detalles);
            return true;
        }

        private static bool TieneInestabilidadFinal(List<List<IntPoint>> caminos, double precision)
        {
            for (int r = 0; r < caminos.Count; r++)
            {
                var camino = caminos[r];
                for (int i = 0; i < camino.Count; i++)
                {
                    IntPoint a = camino[(i + camino.Count - 1) % camino.Count];
                    IntPoint b = camino[i], c = camino[(i + 1) % camino.Count];
                    double dot = ((double)b.X - a.X) * ((double)c.X - b.X) +
                        ((double)b.Y - a.Y) * ((double)c.Y - b.Y);
                    double ladoMayor = Math.Max(Distancia(a, b),
                        Math.Max(Distancia(b, c), Distancia(a, c)));
                    if (dot < 0.0 && AlturaTriangulo(a, b, c, ladoMayor) <= precision)
                        return true;
                    for (int s = r; s < caminos.Count; s++)
                        for (int j = s == r ? i + 1 : 0; j < caminos[s].Count; j++)
                        {
                            if (s == r && (j == i + 1 || i == 0 && j == camino.Count - 1))
                                continue;
                            IntPoint p = camino[i], q = camino[(i + 1) % camino.Count];
                            IntPoint u = caminos[s][j], v = caminos[s][(j + 1) % caminos[s].Count];
                            if (Math.Max(p.X, q.X) + precision < Math.Min(u.X, v.X) ||
                                Math.Max(u.X, v.X) + precision < Math.Min(p.X, q.X) ||
                                Math.Max(p.Y, q.Y) + precision < Math.Min(u.Y, v.Y) ||
                                Math.Max(u.Y, v.Y) + precision < Math.Min(p.Y, q.Y))
                                continue;
                            if (DistanciaSegmentos(p, q, u, v) <= precision)
                                return true;
                        }
                }
            }
            return false;
        }

        private static double AlturaTriangulo(IntPoint a, IntPoint b, IntPoint c, double baseTriangulo)
        {
            if (baseTriangulo <= 0.0)
                return 0.0;
            var cruz = ((System.Numerics.BigInteger)b.X - a.X) * (c.Y - a.Y) -
                ((System.Numerics.BigInteger)b.Y - a.Y) * (c.X - a.X);
            return (double)System.Numerics.BigInteger.Abs(cruz) / baseTriangulo;
        }

        private static double DistanciaPuntoSegmento(IntPoint p, IntPoint a, IntPoint b)
        {
            double x = (double)b.X - a.X, y = (double)b.Y - a.Y;
            double longitud2 = x * x + y * y;
            if (longitud2 == 0.0)
                return Distancia(p, a);
            double t = (((double)p.X - a.X) * x + ((double)p.Y - a.Y) * y) / longitud2;
            t = Math.Max(0.0, Math.Min(1.0, t));
            double dx = p.X - (a.X + t * x), dy = p.Y - (a.Y + t * y);
            return Math.Sqrt(dx * dx + dy * dy);
        }

        private static double DistanciaSegmentos(IntPoint a, IntPoint b, IntPoint c, IntPoint d)
        {
            int o1 = Orientacion(a, b, c), o2 = Orientacion(a, b, d);
            int o3 = Orientacion(c, d, a), o4 = Orientacion(c, d, b);
            if (o1 * o2 < 0 && o3 * o4 < 0 ||
                o1 == 0 && EnSegmento(c, a, b) || o2 == 0 && EnSegmento(d, a, b) ||
                o3 == 0 && EnSegmento(a, c, d) || o4 == 0 && EnSegmento(b, c, d))
                return 0.0;
            return Math.Min(Math.Min(DistanciaPuntoSegmento(a, c, d), DistanciaPuntoSegmento(b, c, d)),
                Math.Min(DistanciaPuntoSegmento(c, a, b), DistanciaPuntoSegmento(d, a, b)));
        }

        private static bool NormalizarFinalConservador(List<List<IntPoint>> original,
            double minimo, double factor, double erosionMicras,
            out List<List<List<IntPoint>>> perfiles, out double areaRetirada, out int pasos)
        {
            perfiles = new List<List<List<IntPoint>>>();
            areaRetirada = 0.0;
            pasos = 0;
            var ladosOriginales = new List<List<IntPoint>>();
            foreach (var camino in original)
                for (int i = 0; i < camino.Count; i++)
                    ladosOriginales.Add(new List<IntPoint> { camino[i], camino[(i + 1) % camino.Count] });
            var bandaOriginal = BandaDeEncuentros(ladosOriginales, 3.0 * factor, factor, true);
            var actual = CopiarContornos(original);
            if (erosionMicras > 0.0)
            {
                var offset = new ClipperOffset(2.0, 0.0025 * factor);
                offset.AddPaths(original, JoinType.jtMiter, EndType.etClosedPolygon);
                var erosionado = new List<List<IntPoint>>();
                offset.Execute(ref erosionado, -erosionMicras * factor);
                actual = Clipper.PolyTreeToPaths(OperarContornos(erosionado,
                    new List<List<IntPoint>>(), ClipType.ctUnion));
            }
            if (actual.Count == 0 || HayDiferenciaExacta(actual, original) ||
                HayDiferenciaExacta(Diferencia(original, actual), bandaOriginal))
                return false;
            // El límite se fija UNA vez al candidato anterior al rechazo.
            // Se pueden separar componentes naturales al quitar un cuello
            // numérico; no forzar que sigan siendo un solo propietario.
            for (; pasos < 128; pasos++)
            {
                List<List<IntPoint>> mejor = null;
                System.Numerics.BigInteger menorArea = 0;
                for (int r = 0; r < actual.Count; r++)
                    for (int i = 0; i < actual[r].Count; i++)
                    {
                        var camino = actual[r];
                        if (camino.Count <= 3)
                            continue;
                        IntPoint a = camino[(i + camino.Count - 1) % camino.Count];
                        IntPoint b = camino[i], c = camino[(i + 1) % camino.Count];
                        double ladoMayor = Math.Max(Distancia(a, b),
                            Math.Max(Distancia(b, c), Distancia(a, c)));
                        if (AlturaTriangulo(a, b, c, ladoMayor) > 3.0 * factor)
                            continue;
                        var candidato = CopiarContornos(actual);
                        candidato[r].RemoveAt(i);
                        var nuevo = Clipper.PolyTreeToPaths(OperarContornos(candidato,
                            new List<List<IntPoint>>(), ClipType.ctUnion));
                        if (nuevo.Count == 0 || nuevo.Sum(p => p.Count) >= actual.Sum(p => p.Count) ||
                            HayDiferenciaExacta(nuevo, actual) ||
                            HayDiferenciaExacta(Diferencia(original, nuevo), bandaOriginal))
                            continue;
                        var retirada = AreaDobleExacta(actual) - AreaDobleExacta(nuevo);
                        if (retirada < 0 || mejor != null && retirada >= menorArea)
                            continue;
                        mejor = nuevo;
                        menorArea = retirada;
                    }
                if (mejor == null)
                    break;
                actual = mejor;
            }
            PolyTree arbol = OperarContornos(actual, new List<List<IntPoint>>(), ClipType.ctUnion);
            var preparados = new List<List<List<IntPoint>>>();
            for (PolyNode nodo = arbol.GetFirst(); nodo != null; nodo = nodo.GetNext())
            {
                if (nodo.IsHole)
                    continue;
                var perfil = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
                perfil.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
                if (!FronteraFinalValida(perfil, minimo))
                    return false;
                preparados.Add(perfil);
            }
            var unidos = preparados.SelectMany(p => p).ToList();
            if (preparados.Count == 0 || HayDiferenciaExacta(unidos, original) ||
                HayDiferenciaExacta(Diferencia(original, unidos), bandaOriginal) ||
                AreaDobleExacta(unidos) != AreaDobleExacta(actual))
                return false;
            var retiradaTotal = AreaDobleExacta(original) - AreaDobleExacta(unidos);
            if (retiradaTotal < 0)
                return false;
            perfiles = preparados;
            areaRetirada = (double)retiradaTotal / 2.0;
            return true;
        }

        private static PolyTree DominioConVaciosUnidos(List<List<IntPoint>> raw)
        {
            var exterior = new List<IntPoint>(raw[0]);
            if (Clipper.Area(exterior) < 0.0) exterior.Reverse();
            var vacios = raw.Skip(1).Select(p =>
            {
                var copia = new List<IntPoint>(p);
                if (Clipper.Area(copia) < 0.0) copia.Reverse();
                return copia;
            }).ToList();
            PolyTree unionVacios = OperarContornos(vacios, new List<List<IntPoint>>(), ClipType.ctUnion);
            return OperarContornos(new List<List<IntPoint>> { exterior },
                Clipper.PolyTreeToPaths(unionVacios), ClipType.ctDifference);
        }

        // Recomponer la representación antes de exigir una cuenta de huecos.
        // Los huecos son VACÍOS unidos entre sí, no contornos con paridad que
        // puedan rellenarse al solaparse. Todas las operaciones usan la rejilla
        // refinada y el dominio canónico fija el material disponible inicial.
        private static bool RecomponerEncuentros(PolyNode nodo, double minimo, double limite,
            out List<List<IntPoint>> contornos, out double areaRetirada, out string diagnostico,
            double factor, int modoApertura = 0)
        {
            var raw = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            raw.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            contornos = CopiarContornos(raw);
            areaRetirada = 0.0;
            diagnostico = "Recomposición: no se obtuvo un único propietario con todos los vacíos conservados.";
            var exterior = new List<IntPoint>(raw[0]);
            if (Clipper.Area(exterior) < 0.0) exterior.Reverse();
            var vacios = raw.Skip(1).Select(p =>
            {
                var copia = new List<IntPoint>(p);
                if (Clipper.Area(copia) < 0.0) copia.Reverse();
                return copia;
            }).ToList();
            PolyTree unionVacios = OperarContornos(vacios, new List<List<IntPoint>>(), ClipType.ctUnion);
            PolyTree baseArbol = OperarContornos(new List<List<IntPoint>> { exterior },
                Clipper.PolyTreeToPaths(unionVacios), ClipType.ctDifference);
            List<List<IntPoint>> inicial;
            if (!LeerUnPropietario(baseArbol, out inicial))
                return false;
            List<IntPoint> contactos;
            int anillosEsperados;
            if (!ContactosEntreAnillos(inicial, out contactos, out anillosEsperados))
            {
                diagnostico = "Recomposición: persiste un cruce o un lado compartido después de unir los vacíos.";
                return false;
            }
            double precision = 3.0 * factor;
            List<List<IntPoint>> bandas, terminales;
            List<IntPoint> puntos;
            PuentesDePrecision(inicial, precision, out bandas, out terminales, out puntos);
            List<List<IntPoint>> bandasRaw, terminalesRaw;
            List<IntPoint> puntosRaw;
            PuentesDePrecision(raw, precision, out bandasRaw, out terminalesRaw, out puntosRaw);
            bandas.AddRange(bandasRaw);
            terminales.AddRange(terminalesRaw);
            puntos.AddRange(puntosRaw);
            puntos = puntos.Distinct().ToList();
            var precisionEstrecha = BandaDeEncuentros(bandas, precision, factor, true);
            var precisionCompleta = BandaDeEncuentros(bandas.Concat(terminales).ToList(),
                precision, factor, true);
            var anclajes = puntos.Select(p => new List<IntPoint> { p }).ToList();
            anclajes.AddRange(AristasCortas(inicial, minimo));
            anclajes.AddRange(AristasCortas(raw, minimo));
            var nativa = BandaDeEncuentros(anclajes, limite - factor, factor, false);
            var vecindadFinal = precisionCompleta.Concat(nativa).ToList();
            var actual = CopiarContornos(inicial);
            int pasosPuente = 0;
            for (; pasosPuente < 3; pasosPuente++)
            {
                List<List<IntPoint>> ignoradas, ignoradasTerminales;
                List<IntPoint> ignorados;
                var puentes = PuentesDePrecision(actual, precision,
                    out ignoradas, out ignoradasTerminales, out ignorados);
                if (puentes.Count == 0)
                    break;
                List<List<IntPoint>> siguiente;
                if (!LeerUnPropietario(OperarContornos(actual, puentes, ClipType.ctDifference), out siguiente) ||
                    siguiente.Count < anillosEsperados ||
                    HayDiferenciaExacta(siguiente, actual) ||
                    HayDiferenciaExacta(Diferencia(inicial, siguiente), precisionCompleta))
                {
                    diagnostico = "Precisión entre anillos: el puente excedería los soportes originales o alteraría un vacío independiente.";
                    return false;
                }
                if (siguiente.Count == actual.Count && siguiente.Zip(actual,
                    (a, b) => a.SequenceEqual(b)).All(x => x))
                    break;
                actual = siguiente;
            }
            string fallo = "No se obtuvo una frontera nativa completa dentro de las bandas originales de precisión y encuentro.";
            // Primero conservar los soportes terminales para el ajuste nativo.
            // Si esa búsqueda no termina, probar también su limpieza numérica;
            // cada intento parte del mismo dominio y se confirma entero o nada.
            for (int estrategia = 0; estrategia < 2; estrategia++)
            {
                int pasosNip;
                var limpio = LimpiarNipsDirigidos(actual,
                    estrategia == 0 ? precisionEstrecha : precisionCompleta,
                    minimo, anillosEsperados, out pasosNip);
                // La intersección confirma únicamente material ya disponible;
                // no adoptar la parte que una normalización pudiera añadir.
                PolyTree limpioArbol = OperarContornos(limpio, new List<List<IntPoint>>(), ClipType.ctUnion);
                PolyTree conservador = OperarContornos(actual,
                    Clipper.PolyTreeToPaths(limpioArbol), ClipType.ctIntersection);
                List<List<IntPoint>> preparado;
                if (!LeerUnPropietario(conservador, out preparado) || preparado.Count < anillosEsperados)
                    continue;
                var propietario = NodoDeContornos(preparado);
                List<IntPoint> contactosPendientes;
                int esperadosPendientes;
                if (!ContactosEntreAnillos(preparado, out contactosPendientes, out esperadosPendientes))
                    continue;
                List<List<IntPoint>> final;
                double retiradaNativa;
                string detalle;
                bool valido = contactosPendientes.Count > 0
                    ? AbrirContactosEnRejilla(propietario, minimo, limite,
                        out final, out retiradaNativa, out detalle, factor, modoApertura)
                    : AjustarAristasEnRejilla(propietario, minimo, limite,
                        out final, out retiradaNativa, out detalle, factor);
                if (!valido)
                {
                    fallo = detalle;
                    continue;
                }
                if (final.Count != anillosEsperados ||
                    HayDiferenciaExacta(final, inicial) ||
                    HayDiferenciaExacta(Diferencia(inicial, final), vecindadFinal) ||
                    !FronteraFinalValida(final, minimo))
                {
                    fallo = "La frontera final excede sus anclajes originales, conserva un contacto o uniría un vacío independiente.";
                    continue;
                }
                contornos = final;
                areaRetirada = (double)(AreaDobleExacta(inicial) - AreaDobleExacta(final)) / 2.0;
                diagnostico = "Recomposición conservadora: huecos " + (raw.Count - 1) + " -> " +
                    (inicial.Count - 1) + " -> " + (final.Count - 1) + "; puentes de precisión " +
                    pasosPuente + "; vértices numéricos retirados " + pasosNip +
                    "; banda entre soportes originales 0.003 mm; área retirada " +
                    (areaRetirada / factor / factor / 1000000.0).ToString("0.######",
                        System.Globalization.CultureInfo.InvariantCulture) + " mm². " + detalle;
                return true;
            }
            diagnostico = "Recomposición/precisión: " + fallo + " Se conserva el contorno original.";
            return false;
        }

        private static PolyTree OperarContornos(List<List<IntPoint>> sujeto,
            List<List<IntPoint>> corte, ClipType operacion)
        {
            var resultado = new PolyTree();
            if (sujeto.Count == 0 && corte.Count == 0)
                return resultado;
            var motor = new Clipper { StrictlySimple = true };
            if (sujeto.Count > 0) motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (corte.Count > 0) motor.AddPaths(corte, PolyType.ptClip, true);
            if (!motor.Execute(operacion, resultado, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo recomponer el dominio del boceto.");
            return resultado;
        }

        private static bool LeerUnPropietario(PolyTree arbol, out List<List<IntPoint>> caminos)
        {
            caminos = null;
            var exteriores = new List<PolyNode>();
            for (var n = arbol.GetFirst(); n != null; n = n.GetNext())
                if (!n.IsHole) exteriores.Add(n);
            if (exteriores.Count != 1)
                return false;
            caminos = new List<List<IntPoint>> { new List<IntPoint>(exteriores[0].Contour) };
            caminos.AddRange(exteriores[0].Childs.Where(x => x.IsHole)
                .Select(x => new List<IntPoint>(x.Contour)));
            return caminos.All(x => x.Count >= 3);
        }

        private static PolyNode NodoDeContornos(List<List<IntPoint>> caminos)
        {
            var raiz = new PolyTree();
            var nodo = new PolyNode();
            raiz.AddChild(nodo);
            nodo.Contour.AddRange(caminos[0]);
            foreach (var p in caminos.Skip(1))
            {
                var hueco = new PolyNode();
                nodo.AddChild(hueco);
                hueco.Contour.AddRange(p);
            }
            return nodo;
        }

        private static List<List<IntPoint>> BandaDeEncuentros(List<List<IntPoint>> anclajes,
            double radio, double factor, bool numerica)
        {
            var caminos = new List<List<IntPoint>>();
            if (anclajes.Count == 0 || radio <= 0.0)
                return caminos;
            var offset = new ClipperOffset(2.0, (numerica ? 0.0025 : 0.25) * factor);
            offset.AddPaths(anclajes, JoinType.jtRound, EndType.etOpenRound);
            offset.Execute(ref caminos, radio);
            return caminos;
        }

        private static List<IntPoint> RayosIncidentes(List<IntPoint> camino, IntPoint punto)
        {
            var rayos = new List<IntPoint>();
            for (int i = 0; i < camino.Count; i++)
            {
                IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                if (Orientacion(a, b, punto) != 0 || !EnSegmento(punto, a, b))
                    continue;
                if (a != punto && !rayos.Contains(a)) rayos.Add(a);
                if (b != punto && !rayos.Contains(b)) rayos.Add(b);
            }
            return rayos;
        }

        private static List<List<IntPoint>> PuentesDePrecision(List<List<IntPoint>> caminos,
            double precision, out List<List<IntPoint>> soportes,
            out List<List<IntPoint>> terminales, out List<IntPoint> puntos)
        {
            soportes = new List<List<IntPoint>>();
            terminales = new List<List<IntPoint>>();
            puntos = new List<IntPoint>();
            var puentes = new List<List<IntPoint>>();
            for (int r = 0; r < caminos.Count; r++)
                for (int s = r + 1; s < caminos.Count; s++)
                {
                    var comunes = new List<IntPoint>();
                    foreach (IntPoint p in caminos[r])
                        if (Enumerable.Range(0, caminos[s].Count).Any(j =>
                            Orientacion(caminos[s][j], caminos[s][(j + 1) % caminos[s].Count], p) == 0 &&
                            EnSegmento(p, caminos[s][j], caminos[s][(j + 1) % caminos[s].Count])))
                            comunes.Add(p);
                    foreach (IntPoint p in caminos[s])
                        if (Enumerable.Range(0, caminos[r].Count).Any(j =>
                            Orientacion(caminos[r][j], caminos[r][(j + 1) % caminos[r].Count], p) == 0 &&
                            EnSegmento(p, caminos[r][j], caminos[r][(j + 1) % caminos[r].Count])))
                            comunes.Add(p);
                    foreach (IntPoint centro in comunes.Distinct())
                    {
                        if (!puntos.Contains(centro)) puntos.Add(centro);
                        var rayosR = RayosIncidentes(caminos[r], centro);
                        var rayosS = RayosIncidentes(caminos[s], centro);
                        bool casiCoincidentes = false;
                        foreach (IntPoint a in rayosR)
                            foreach (IntPoint b in rayosS)
                            {
                                double ax = (double)a.X - centro.X, ay = (double)a.Y - centro.Y;
                                double bx = (double)b.X - centro.X, by = (double)b.Y - centro.Y;
                                double la = Distancia(centro, a), lb = Distancia(centro, b);
                                if (ax * bx + ay * by <= 0.0 ||
                                    Math.Abs(ax * by - ay * bx) / Math.Max(la, lb) > precision)
                                    continue;
                                casiCoincidentes = true;
                                IntPoint corto = la <= lb ? a : b, largo = la <= lb ? b : a;
                                var caminoCorto = la <= lb ? caminos[r] : caminos[s];
                                int k = caminoCorto.IndexOf(corto);
                                if (k < 0) continue;
                                foreach (int signo in new[] { -1, 1 })
                                {
                                    IntPoint siguiente = caminoCorto[(k + signo + caminoCorto.Count) % caminoCorto.Count];
                                    if (Orientacion(centro, corto, siguiente) == 0)
                                        continue;
                                    IntPoint esquina;
                                    if (!InterseccionSoportes(centro, largo, corto, siguiente, out esquina) ||
                                        Distancia(esquina, corto) > precision)
                                        continue;
                                    double dx = (double)largo.X - centro.X, dy = (double)largo.Y - centro.Y;
                                    double t = (((double)esquina.X - centro.X) * dx +
                                        ((double)esquina.Y - centro.Y) * dy) / (dx * dx + dy * dy);
                                    if (t < 0.0 || t > 1.0 + precision / Math.Max(la, lb))
                                        continue;
                                    terminales.Add(new List<IntPoint> { corto, siguiente });
                                    var triangulo = new List<IntPoint> { centro, corto, esquina };
                                    if (Math.Abs(Clipper.Area(triangulo)) >= 0.5)
                                        puentes.Add(triangulo);
                                }
                            }
                        if (casiCoincidentes)
                            foreach (IntPoint q in rayosR.Concat(rayosS))
                                soportes.Add(new List<IntPoint> { centro, q });
                    }
                }
            return puentes;
        }

        private static List<List<IntPoint>> LimpiarNipsDirigidos(List<List<IntPoint>> entrada,
            List<List<IntPoint>> vecindad, double minimo, int anillosMinimos, out int pasos)
        {
            var actual = CopiarContornos(entrada);
            pasos = 0;
            if (vecindad.Count == 0)
                return actual;
            for (; pasos < 128; pasos++)
            {
                List<List<IntPoint>> mejor = null;
                System.Numerics.BigInteger menorArea = 0;
                int cortasAntes = AristasCortas(actual, minimo).Count;
                for (int r = 0; r < actual.Count; r++)
                    for (int i = 0; i < actual[r].Count; i++)
                    {
                        var camino = actual[r];
                        if (camino.Count <= 3 || Distancia(camino[i], camino[(i + 1) % camino.Count]) > minimo)
                            continue;
                        foreach (int eliminar in new[] { i, (i + 1) % camino.Count })
                        {
                            var candidato = CopiarContornos(actual);
                            candidato[r].RemoveAt(eliminar);
                            List<List<IntPoint>> nuevo;
                            if (!LeerUnPropietario(OperarContornos(candidato,
                                new List<List<IntPoint>>(), ClipType.ctUnion), out nuevo) ||
                                nuevo.Count < anillosMinimos || nuevo.Count > actual.Count ||
                                nuevo.Sum(p => p.Count) >= actual.Sum(p => p.Count) ||
                                AristasCortas(nuevo, minimo).Count >= cortasAntes ||
                                HayDiferenciaExacta(nuevo, actual) ||
                                HayDiferenciaExacta(Diferencia(actual, nuevo), vecindad))
                                continue;
                            var area = AreaDobleExacta(actual) - AreaDobleExacta(nuevo);
                            if (area < 0 || mejor != null && area >= menorArea)
                                continue;
                            mejor = nuevo;
                            menorArea = area;
                        }
                    }
                if (mejor == null)
                    break;
                actual = mejor;
            }
            return actual;
        }

        private static bool FronteraFinalValida(List<List<IntPoint>> caminos, double minimo)
        {
            if (caminos.Count == 0 || AreaDobleExacta(new List<List<IntPoint>> { caminos[0] }) <= 0 ||
                caminos.Skip(1).Any(p => AreaDobleExacta(new List<List<IntPoint>> { p }) >= 0))
                return false;
            for (int i = 0; i < caminos.Count; i++)
            {
                if (!AnilloSimple(caminos[i]) || AristasCortas(new List<List<IntPoint>> { caminos[i] }, minimo).Count > 0)
                    return false;
                for (int j = i + 1; j < caminos.Count; j++)
                    if (AnillosSeTocan(caminos[i], caminos[j]) ||
                        i > 0 && Clipper.PointInPolygon(caminos[j][0], caminos[i]) != 0 ||
                        i > 0 && Clipper.PointInPolygon(caminos[i][0], caminos[j]) != 0)
                        return false;
                if (i > 0 && Clipper.PointInPolygon(caminos[i][0], caminos[0]) != 1)
                    return false;
            }
            return true;
        }

        // Un punto compartido entre huecos, o entre hueco y exterior, no forma
        // un boceto Revit válido aunque todas sus aristas sean largas. Abrir
        // únicamente ese contacto retirando material; nunca relajar la guardia
        // de separación de R6 ni engrosar globalmente las interferencias.
        private static bool AbrirContactosEnRejilla(PolyNode nodo, double minimo, double limite,
            out List<List<IntPoint>> contornos, out double areaRetirada, out string diagnostico,
            double factor, int modoApertura = 0)
        {
            var original = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            original.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            contornos = CopiarContornos(original);
            areaRetirada = 0.0;
            diagnostico = "No se pudo abrir completamente el contacto dentro del límite local sin " +
                "añadir material, unir huecos independientes o crear aristas menores que el mínimo de Revit. " +
                "Se conserva el contorno original.";
            List<IntPoint> contactosIniciales;
            int anillosEsperados;
            if (!ContactosEntreAnillos(original, out contactosIniciales, out anillosEsperados) ||
                contactosIniciales.Count == 0 || contactosIniciales.Count > 64)
                return false;
            // El grafo de contactos fija qué vacíos pueden unirse. La cuenta
            // final no puede disminuir además por un hueco cercano pero ajeno.
            var offset = new ClipperOffset(2.0, 0.25 * factor);
            foreach (IntPoint p in contactosIniciales)
                offset.AddPath(new List<IntPoint> { p }, JoinType.jtRound, EndType.etOpenRound);
            foreach (var corta in AristasCortas(original, minimo))
                offset.AddPath(corta, JoinType.jtRound, EndType.etOpenRound);
            var vecindad = new List<List<IntPoint>>();
            offset.Execute(ref vecindad, limite - factor);
            double radio = limite - 2.0 * factor;
            double objetivo = Math.Ceiling(minimo + Math.Max(2.0 * factor, minimo * 0.01));
            if (radio <= 0.0)
                return false;
            var actual = CopiarContornos(original);
            int pasos = 0;
            while (true)
            {
                List<IntPoint> contactosActuales;
                int esperadosActuales;
                if (!ContactosEntreAnillos(actual, out contactosActuales, out esperadosActuales))
                    return false;
                if (contactosActuales.Count == 0)
                    break;
                if (pasos >= 64)
                    return false;
                List<List<IntPoint>> mejor = null;
                double menorRetirada = double.PositiveInfinity;
                IntPoint centro = contactosActuales[0];
                // Todos los modos conservan el mismo radio y las mismas pruebas
                // de subconjunto, mínimos, huecos y localidad. Solo se evita una
                // apertura excesivamente fina si la extrusión nativa la rechaza.
                double proporcionMinima = new[] { 0.03, 0.1, 0.25, 0.5, 1.0 }[
                    Math.Max(0, Math.Min(4, modoApertura))];
                foreach (double angulo in EjesDelContacto(actual, centro))
                    foreach (double proporcion in new[] { 1.0, 0.5, 0.25, 0.1, 0.03 }
                        .Where(p => p >= proporcionMinima))
                    {
                        double ux = Math.Cos(angulo), uy = Math.Sin(angulo);
                        var rombo = new List<IntPoint>
                        {
                            PuntoRedondeado(centro.X + radio * ux, centro.Y + radio * uy),
                            PuntoRedondeado(centro.X - radio * proporcion * uy, centro.Y + radio * proporcion * ux),
                            PuntoRedondeado(centro.X - radio * ux, centro.Y - radio * uy),
                            PuntoRedondeado(centro.X + radio * proporcion * uy, centro.Y - radio * proporcion * ux)
                        };
                        List<List<IntPoint>> nuevo;
                        if (!LeerPropietarioConContactos(Diferencia(actual,
                            new List<List<IntPoint>> { rombo }), out nuevo) ||
                            nuevo.Count < anillosEsperados || nuevo.Count >= actual.Count)
                            continue;
                        List<IntPoint> restantes;
                        int esperadosNuevos;
                        if (!ContactosEntreAnillos(nuevo, out restantes, out esperadosNuevos) ||
                            restantes.Count >= contactosActuales.Count ||
                            restantes.Any(p => !contactosActuales.Contains(p)))
                            continue;
                        // Los conectores nuevos ya deben superar el mínimo con
                        // margen. R6 solo podrá ajustar aristas cortas anteriores.
                        if (HayAristaNuevaCorta(nuevo, actual, objetivo) ||
                            HayDiferenciaExacta(nuevo, actual) ||
                            HayDiferenciaExacta(Diferencia(original, nuevo), vecindad))
                            continue;
                        double retirada = (double)(AreaDobleExacta(actual) - AreaDobleExacta(nuevo));
                        if (retirada <= 0.0 || retirada >= menorRetirada)
                            continue;
                        mejor = nuevo;
                        menorRetirada = retirada;
                    }
                if (mejor == null)
                    return false;
                actual = mejor;
                pasos++;
            }
            List<List<IntPoint>> normal;
            if (actual.Count != anillosEsperados ||
                !NormalizarPropietario(actual, anillosEsperados - 1, out normal))
                return false;
            var raiz = new PolyTree();
            var propietario = new PolyNode();
            raiz.AddChild(propietario);
            propietario.Contour.AddRange(normal[0]);
            foreach (var camino in normal.Skip(1))
            {
                var hueco = new PolyNode();
                propietario.AddChild(hueco);
                hueco.Contour.AddRange(camino);
            }
            List<List<IntPoint>> final;
            double retiradaAristas;
            string detalleAristas;
            if (!AjustarAristasEnRejilla(propietario, minimo, limite, out final,
                out retiradaAristas, out detalleAristas, factor) ||
                HayDiferenciaExacta(final, original) ||
                HayDiferenciaExacta(Diferencia(original, final), vecindad))
                return false;
            contornos = final;
            areaRetirada = (double)(AreaDobleExacta(original) - AreaDobleExacta(final)) / 2.0;
            diagnostico = "Apertura local conservadora: " + pasos + " contactos; huecos " +
                (original.Count - 1) + " -> " + (final.Count - 1) + "; área retirada " +
                (areaRetirada / factor / factor / 1000000.0).ToString("0.######",
                    System.Globalization.CultureInfo.InvariantCulture) + " mm²; límite " +
                (limite / factor / 1000.0).ToString("0.###",
                    System.Globalization.CultureInfo.InvariantCulture) + " mm. " + detalleAristas;
            return true;
        }

        private static bool HayAristaNuevaCorta(List<List<IntPoint>> nuevos,
            List<List<IntPoint>> anteriores, double objetivo)
        {
            foreach (var camino in nuevos)
                for (int i = 0; i < camino.Count; i++)
                {
                    IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                    if (Distancia(a, b) >= objetivo)
                        continue;
                    if (!anteriores.Any(p => Enumerable.Range(0, p.Count).Any(j =>
                        p[j] == a && p[(j + 1) % p.Count] == b ||
                        p[j] == b && p[(j + 1) % p.Count] == a)))
                        return true;
                }
            return false;
        }

        private static IEnumerable<double> EjesDelContacto(List<List<IntPoint>> caminos, IntPoint p)
        {
            var ejes = new List<double>();
            foreach (var camino in caminos)
                for (int i = 0; i < camino.Count; i++)
                {
                    IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                    if (Orientacion(a, b, p) != 0 || !EnSegmento(p, a, b))
                        continue;
                    double angulo = Math.Atan2((double)b.Y - a.Y, (double)b.X - a.X);
                    if (angulo < 0.0) angulo += Math.PI;
                    if (!ejes.Any(x => Math.Abs(Math.Sin(x - angulo)) < 1e-10))
                        ejes.Add(angulo);
                }
            // Alternativas para ángulos agudos; siempre dentro del mismo disco.
            for (int i = 0; i < 8; i++)
                if (!ejes.Any(x => Math.Abs(Math.Sin(x - i * Math.PI / 8.0)) < 1e-10))
                    ejes.Add(i * Math.PI / 8.0);
            return ejes;
        }

        private static bool LeerPropietarioConContactos(List<List<IntPoint>> caminos,
            out List<List<IntPoint>> normalizados)
        {
            normalizados = null;
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(caminos, PolyType.ptSubject, true))
                return false;
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                return false;
            var exteriores = new List<PolyNode>();
            for (var n = arbol.GetFirst(); n != null; n = n.GetNext())
                if (!n.IsHole) exteriores.Add(n);
            if (exteriores.Count != 1)
                return false;
            normalizados = new List<List<IntPoint>> { QuitarColineales(exteriores[0].Contour) };
            normalizados.AddRange(exteriores[0].Childs.Where(x => x.IsHole)
                .Select(x => QuitarColineales(x.Contour)));
            return normalizados.All(x => x.Count >= 3 && AnilloSimple(x));
        }

        private static bool ContactosEntreAnillos(List<List<IntPoint>> caminos,
            out List<IntPoint> contactos, out int anillosEsperados)
        {
            contactos = new List<IntPoint>();
            var grupos = Enumerable.Range(0, caminos.Count).ToArray();
            anillosEsperados = caminos.Count;
            for (int r = 0; r < caminos.Count; r++)
                for (int s = r + 1; s < caminos.Count; s++)
                    for (int i = 0; i < caminos[r].Count; i++)
                        for (int j = 0; j < caminos[s].Count; j++)
                        {
                            IntPoint a = caminos[r][i], b = caminos[r][(i + 1) % caminos[r].Count];
                            IntPoint c = caminos[s][j], d = caminos[s][(j + 1) % caminos[s].Count];
                            if (CajasDisjuntas(a, b, c, d))
                                continue;
                            int o1 = Orientacion(a, b, c), o2 = Orientacion(a, b, d);
                            int o3 = Orientacion(c, d, a), o4 = Orientacion(c, d, b);
                            if (o1 * o2 < 0 && o3 * o4 < 0)
                                return false; // No convertir un cruce en tangencia.
                            var comunes = new List<IntPoint>();
                            if (o1 == 0 && EnSegmento(c, a, b)) comunes.Add(c);
                            if (o2 == 0 && EnSegmento(d, a, b)) comunes.Add(d);
                            if (o3 == 0 && EnSegmento(a, c, d)) comunes.Add(a);
                            if (o4 == 0 && EnSegmento(b, c, d)) comunes.Add(b);
                            comunes = comunes.Distinct().ToList();
                            if (comunes.Count > 1)
                                return false; // Un lado compartido requiere su unión normal.
                            if (comunes.Count == 0)
                                continue;
                            if (!contactos.Contains(comunes[0])) contactos.Add(comunes[0]);
                            int anterior = grupos[s], nuevo = grupos[r];
                            if (anterior == nuevo)
                                continue;
                            for (int k = 0; k < grupos.Length; k++)
                                if (grupos[k] == anterior) grupos[k] = nuevo;
                            anillosEsperados--;
                        }
            return true;
        }

        private static bool AjustarAristasEnRejilla(PolyNode nodo, double minimo, double limite,
            out List<List<IntPoint>> contornos, out double areaRetirada, out string diagnostico,
            double factor)
        {
            var original = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            original.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            contornos = CopiarContornos(original);
            areaRetirada = 0.0;
            diagnostico = string.Empty;
            if (double.IsNaN(minimo) || double.IsInfinity(minimo) || minimo <= 0.0 ||
                double.IsNaN(limite) || double.IsInfinity(limite) || limite <= 2.0)
            {
                diagnostico = "Tolerancias no válidas para el ajuste local.";
                return false;
            }
            List<List<IntPoint>> actual;
            if (!NormalizarPropietario(original, original.Count - 1, out actual))
            {
                diagnostico = "El propietario no conserva un exterior y todos sus huecos separados.";
                return false;
            }
            var entrada = original;
            original = CopiarContornos(actual);
            var cortasIniciales = AristasCortas(actual, minimo);
            if (cortasIniciales.Count == 0)
            {
                contornos = actual;
                return true;
            }
            // Anclar la localidad a las aristas cortas ORIGINALES, no a todo el
            // perímetro ni a una posición que pueda ir desplazándose por pasos.
            var offset = new ClipperOffset(2.0, 0.25 * factor);
            foreach (var arista in cortasIniciales)
                offset.AddPath(arista, JoinType.jtRound, EndType.etOpenRound);
            var vecindad = new List<List<IntPoint>>();
            // Una celda base de reserva mantiene incluso el redondeo del buffer
            // dentro del límite físico solicitado (1 mm en el adaptador).
            offset.Execute(ref vecindad, limite - factor);
            double objetivo = Math.Ceiling(minimo + Math.Max(2.0 * factor, minimo * 0.01));
            int pasos = 0;
            while (true)
            {
                var anteriores = AristasCortas(actual, minimo);
                if (anteriores.Count == 0)
                {
                    contornos = actual;
                    areaRetirada = (double)(AreaDobleExacta(original) - AreaDobleExacta(actual)) / 2.0;
                    diagnostico = "Ajuste local conservador: " + pasos + " encuentros; área retirada " +
                        (areaRetirada / factor / factor / 1000000.0).ToString("0.######", System.Globalization.CultureInfo.InvariantCulture) +
                        " mm²; límite " + (limite / factor / 1000.0).ToString("0.###",
                            System.Globalization.CultureInfo.InvariantCulture) + " mm.";
                    return true;
                }
                if (pasos >= 128)
                    break;
                List<List<IntPoint>> mejor = null;
                double menorRetirada = double.PositiveInfinity;
                // Prioridad a una esquina formada por los soportes existentes.
                // Solo si no hay solución válida se permite un bisel microlocal.
                for (int modo = 0; modo < 2 && mejor == null; modo++)
                    for (int r = 0; r < actual.Count; r++)
                        for (int i = 0; i < actual[r].Count; i++)
                        {
                            var anillo = actual[r];
                            int n = anillo.Count;
                            IntPoint a = anillo[(i + n - 1) % n], b = anillo[i];
                            IntPoint c = anillo[(i + 1) % n], d = anillo[(i + 2) % n];
                            if (Distancia(b, c) > minimo)
                                continue;
                            if (modo == 0)
                            {
                                IntPoint esquina;
                                if (InterseccionSoportes(a, b, c, d, out esquina) &&
                                    Distancia(esquina, b) <= limite && Distancia(esquina, c) <= limite &&
                                    DireccionesConservadas(a, b, c, d, esquina, esquina))
                                {
                                    var candidato = EditarEncuentro(actual, r, i, esquina, esquina, true);
                                    EvaluarEdicion(actual, original, candidato, vecindad, minimo,
                                        anteriores, ref mejor, ref menorRetirada);
                                }
                                continue;
                            }
                            double ab = Distancia(a, b), cd = Distancia(c, d);
                            if (ab == 0.0 || cd == 0.0)
                                continue;
                            double ux = ((double)b.X - a.X) / ab, uy = ((double)b.Y - a.Y) / ab;
                            double vx = ((double)d.X - c.X) / cd, vy = ((double)d.Y - c.Y) / cd;
                            for (int sb = -1; sb <= 1; sb++)
                                for (int sc = -1; sc <= 1; sc++)
                                {
                                    if (sb == 0 && sc == 0)
                                        continue;
                                    double wx = sc * vx - sb * ux, wy = sc * vy - sb * uy;
                                    double w2 = wx * wx + wy * wy;
                                    if (w2 <= 1e-20)
                                        continue;
                                    double qx = (double)c.X - b.X, qy = (double)c.Y - b.Y;
                                    double dot = qx * wx + qy * wy;
                                    double raiz = dot * dot + w2 * (objetivo * objetivo - qx * qx - qy * qy);
                                    if (raiz < 0.0)
                                        continue;
                                    double t = (-dot + Math.Sqrt(raiz)) / w2;
                                    if (t < 0.0 || t > limite)
                                        continue;
                                    // Pasos enteros del vector primitivo: el punto
                                    // permanece EXACTAMENTE sobre su soporte,
                                    // incluso en bordes largos y oblicuos. No
                                    // redondear X/Y por separado a 0.001 mm.
                                    IntPoint p = MoverEnSoporte(a, b, b, sb, t);
                                    IntPoint q = MoverEnSoporte(c, d, c, sc, t);
                                    if (Distancia(b, p) > limite || Distancia(c, q) > limite ||
                                        Distancia(p, q) < objetivo || !DireccionesConservadas(a, b, c, d, p, q))
                                        continue;
                                    // No sacrificar un borde vecino que ya era creable.
                                    if ((ab > minimo && Distancia(a, p) <= minimo) ||
                                        (cd > minimo && Distancia(q, d) <= minimo))
                                        continue;
                                    var candidato = EditarEncuentro(actual, r, i, p, q, false);
                                    EvaluarEdicion(actual, original, candidato, vecindad, minimo,
                                        anteriores, ref mejor, ref menorRetirada);
                                }
                        }
                if (mejor == null)
                    break;
                actual = mejor;
                pasos++;
            }
            // También preservar el original si una segunda arista falla tras
            // haber encontrado una solución provisional para la primera.
            contornos = CopiarContornos(entrada);
            areaRetirada = 0.0;
            diagnostico = "No hay un ajuste local completo dentro de " + (limite / factor / 1000.0)
                .ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
                " mm que respete el material disponible, los huecos y el mínimo de Revit (" +
                (minimo / factor / 1000.0).ToString("0.######", System.Globalization.CultureInfo.InvariantCulture) +
                " mm). Se conserva el contorno original.";
            return false;
        }

        private static void EvaluarEdicion(List<List<IntPoint>> actual, List<List<IntPoint>> original,
            List<List<IntPoint>> candidato, List<List<IntPoint>> vecindad, double minimo,
            List<List<IntPoint>> cortasAntes, ref List<List<IntPoint>> mejor, ref double menorRetirada)
        {
            List<List<IntPoint>> nuevo;
            if (!NormalizarPropietario(candidato, original.Count - 1, out nuevo))
                return;
            var cortasNuevas = AristasCortas(nuevo, minimo);
            if (cortasNuevas.Count >= cortasAntes.Count || cortasNuevas.Any(e =>
                !cortasAntes.Any(a => (e[0] == a[0] && e[1] == a[1]) || (e[0] == a[1] && e[1] == a[0]))))
                return;
            if (HayDiferenciaExacta(nuevo, actual))
                return; // Nunca rellenar parte de una huella cortante.
            var retirado = Diferencia(original, nuevo);
            if (HayDiferenciaExacta(retirado, vecindad))
                return; // No perder una banda del paño ni desplazar su perímetro.
            double perdida = (double)(AreaDobleExacta(actual) - AreaDobleExacta(nuevo)) / 2.0;
            if (perdida < 0.0 || perdida >= menorRetirada)
                return;
            mejor = nuevo;
            menorRetirada = perdida;
        }

        private static bool NormalizarPropietario(List<List<IntPoint>> contornos, int numeroHuecos,
            out List<List<IntPoint>> normalizados)
        {
            normalizados = null;
            if (contornos.Any(x => x.Count < 3))
                return false;
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(contornos, PolyType.ptSubject, true))
                return false;
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                return false;
            var exteriores = new List<PolyNode>();
            for (var nodo = arbol.GetFirst(); nodo != null; nodo = nodo.GetNext())
                if (!nodo.IsHole) exteriores.Add(nodo);
            if (exteriores.Count != 1 || exteriores[0].Childs.Count(x => x.IsHole) != numeroHuecos)
                return false;
            normalizados = new List<List<IntPoint>> { QuitarColineales(exteriores[0].Contour) };
            normalizados.AddRange(exteriores[0].Childs.Where(x => x.IsHole).Select(x => QuitarColineales(x.Contour)));
            for (int i = 0; i < normalizados.Count; i++)
                for (int j = i + 1; j < normalizados.Count; j++)
                    if (AnillosSeTocan(normalizados[i], normalizados[j]))
                        return false;
            return normalizados.All(x => x.Count >= 3 && Math.Abs(Clipper.Area(x)) >= 0.5 && AnilloSimple(x));
        }

        private static List<List<IntPoint>> EditarEncuentro(List<List<IntPoint>> original,
            int anillo, int indice, IntPoint p, IntPoint q, bool colapsar)
        {
            var copia = CopiarContornos(original);
            var puntos = original[anillo];
            // Rotar para tratar también la arista de cierre sin índices inválidos.
            var editado = new List<IntPoint> { p };
            if (!colapsar) editado.Add(q);
            for (int k = 2; k < puntos.Count; k++)
                editado.Add(puntos[(indice + k) % puntos.Count]);
            copia[anillo] = editado;
            return copia;
        }

        private static List<List<IntPoint>> CopiarContornos(List<List<IntPoint>> caminos)
        {
            return caminos.Select(x => new List<IntPoint>(x)).ToList();
        }

        private static List<List<IntPoint>> AristasCortas(List<List<IntPoint>> caminos, double minimo)
        {
            var cortas = new List<List<IntPoint>>();
            foreach (var camino in caminos)
                for (int i = 0; i < camino.Count; i++)
                    if (Distancia(camino[i], camino[(i + 1) % camino.Count]) <= minimo)
                        cortas.Add(new List<IntPoint> { camino[i], camino[(i + 1) % camino.Count] });
            return cortas;
        }

        private static bool InterseccionSoportes(IntPoint a, IntPoint b, IntPoint c, IntPoint d,
            out IntPoint punto)
        {
            punto = new IntPoint();
            double ux = (double)b.X - a.X, uy = (double)b.Y - a.Y;
            double vx = (double)d.X - c.X, vy = (double)d.Y - c.Y;
            double den = ux * vy - uy * vx;
            if (Math.Abs(den) <= 1e-12 * Distancia(a, b) * Distancia(c, d))
                return false;
            double t = (((double)c.X - b.X) * vy - ((double)c.Y - b.Y) * vx) / den;
            double x = b.X + t * ux, y = b.Y + t * uy;
            if (double.IsNaN(x) || double.IsInfinity(x) || double.IsNaN(y) || double.IsInfinity(y) ||
                Math.Abs(x) > 1e14 || Math.Abs(y) > 1e14)
                return false;
            punto = PuntoRedondeado(x, y);
            return true;
        }

        private static IntPoint PuntoRedondeado(double x, double y)
        {
            return new IntPoint((long)Math.Round(x, MidpointRounding.AwayFromZero),
                (long)Math.Round(y, MidpointRounding.AwayFromZero));
        }

        private static IntPoint MoverEnSoporte(IntPoint a, IntPoint b, IntPoint origen, int signo, double distancia)
        {
            if (signo == 0)
                return origen;
            long dx = b.X - a.X, dy = b.Y - a.Y;
            long m = Math.Abs(dx), n = Math.Abs(dy);
            while (n != 0) { long resto = m % n; m = n; n = resto; }
            if (m == 0)
                return origen;
            long x = dx / m, y = dy / m;
            double paso = Math.Sqrt((double)x * x + (double)y * y);
            long cantidad = (long)Math.Ceiling(distancia / paso);
            return new IntPoint(origen.X + signo * cantidad * x, origen.Y + signo * cantidad * y);
        }

        private static System.Numerics.BigInteger AreaDobleExacta(List<List<IntPoint>> caminos)
        {
            System.Numerics.BigInteger area = 0;
            foreach (var camino in caminos)
                for (int i = 0; i < camino.Count; i++)
                {
                    IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                    area += (System.Numerics.BigInteger)a.X * b.Y - (System.Numerics.BigInteger)a.Y * b.X;
                }
            return area;
        }

        private static bool HayDiferenciaExacta(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            if (sujeto.Count == 0)
                return false;
            return Diferencia(sujeto, corte).Any(p => AreaDobleExacta(new List<List<IntPoint>> { p }) != 0);
        }

        private static bool DireccionesConservadas(IntPoint a, IntPoint b, IntPoint c, IntPoint d,
            IntPoint p, IntPoint q)
        {
            return ((double)b.X - a.X) * ((double)p.X - a.X) +
                ((double)b.Y - a.Y) * ((double)p.Y - a.Y) > 0.0 &&
                ((double)d.X - c.X) * ((double)d.X - q.X) +
                ((double)d.Y - c.Y) * ((double)d.Y - q.Y) > 0.0;
        }

        private static double Distancia(IntPoint a, IntPoint b)
        {
            double x = (double)b.X - a.X, y = (double)b.Y - a.Y;
            return Math.Sqrt(x * x + y * y);
        }

        private static bool AnillosSeTocan(List<IntPoint> a, List<IntPoint> b)
        {
            for (int i = 0; i < a.Count; i++)
                for (int j = 0; j < b.Count; j++)
                {
                    IntPoint p = a[i], q = a[(i + 1) % a.Count], r = b[j], s = b[(j + 1) % b.Count];
                    if (CajasDisjuntas(p, q, r, s))
                        continue;
                    int o1 = Orientacion(p, q, r), o2 = Orientacion(p, q, s);
                    int o3 = Orientacion(r, s, p), o4 = Orientacion(r, s, q);
                    if (o1 * o2 < 0 && o3 * o4 < 0 ||
                        o1 == 0 && EnSegmento(r, p, q) || o2 == 0 && EnSegmento(s, p, q) ||
                        o3 == 0 && EnSegmento(p, r, s) || o4 == 0 && EnSegmento(q, r, s))
                        return true;
                }
            return false;
        }

        private static bool AnilloSimple(List<IntPoint> camino)
        {
            for (int i = 0; i < camino.Count; i++)
            {
                IntPoint p = camino[i], q = camino[(i + 1) % camino.Count];
                if (p == q)
                    return false;
                for (int j = i + 1; j < camino.Count; j++)
                {
                    if (j == i + 1 || i == 0 && j == camino.Count - 1)
                        continue;
                    IntPoint r = camino[j], s = camino[(j + 1) % camino.Count];
                    if (CajasDisjuntas(p, q, r, s))
                        continue;
                    int o1 = Orientacion(p, q, r), o2 = Orientacion(p, q, s);
                    int o3 = Orientacion(r, s, p), o4 = Orientacion(r, s, q);
                    if (o1 * o2 < 0 && o3 * o4 < 0 ||
                        o1 == 0 && EnSegmento(r, p, q) || o2 == 0 && EnSegmento(s, p, q) ||
                        o3 == 0 && EnSegmento(p, r, s) || o4 == 0 && EnSegmento(q, r, s))
                        return false;
                }
            }
            return true;
        }

        private static bool CajasDisjuntas(IntPoint a, IntPoint b, IntPoint c, IntPoint d)
        {
            // Solo descarte exacto de pares lejanos. Los contactos en el borde
            // se conservan para la misma prueba de orientación de enteros.
            return Math.Max(a.X, b.X) < Math.Min(c.X, d.X) ||
                Math.Max(c.X, d.X) < Math.Min(a.X, b.X) ||
                Math.Max(a.Y, b.Y) < Math.Min(c.Y, d.Y) ||
                Math.Max(c.Y, d.Y) < Math.Min(a.Y, b.Y);
        }

        private static int Orientacion(IntPoint a, IntPoint b, IntPoint c)
        {
            return (((System.Numerics.BigInteger)b.X - a.X) * ((System.Numerics.BigInteger)c.Y - a.Y) -
                ((System.Numerics.BigInteger)b.Y - a.Y) * ((System.Numerics.BigInteger)c.X - a.X)).Sign;
        }

        private static bool EnSegmento(IntPoint p, IntPoint a, IntPoint b)
        {
            return p.X >= Math.Min(a.X, b.X) && p.X <= Math.Max(a.X, b.X) &&
                p.Y >= Math.Min(a.Y, b.Y) && p.Y <= Math.Max(a.Y, b.Y);
        }

        private static List<List<IntPoint>> Diferencia(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            motor.AddPaths(corte, PolyType.ptClip, true);
            var resultado = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctDifference, resultado, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo verificar el ajuste local.");
            return resultado;
        }

        private static bool HayDiferenciaConArea(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            if (sujeto.Count == 0)
                return false;
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (corte.Count > 0)
                motor.AddPaths(corte, PolyType.ptClip, true);
            var resultado = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctDifference, resultado, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo verificar la envolvente de precisión.");
            return resultado.Any(x => Math.Abs(Clipper.Area(x)) >= 0.5);
        }

        private static double Perimetro(List<IntPoint> camino)
        {
            double longitud = 0.0;
            for (int i = 0; i < camino.Count; i++)
            {
                IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                double x = (double)b.X - a.X, y = (double)b.Y - a.Y;
                longitud += Math.Sqrt(x * x + y * y);
            }
            return longitud;
        }

        internal static bool MismoDominio(List<List<IntPoint>> a, List<List<IntPoint>> b)
        {
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(UnirRegion(a), PolyType.ptSubject, true);
            motor.AddPaths(UnirRegion(b), PolyType.ptClip, true);
            var diferencia = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctXor, diferencia, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo comprobar el dominio de la cara.");
            return diferencia.All(x => Math.Abs(Clipper.Area(x)) < 0.5);
        }

        internal static List<IntPoint> QuitarColineales(List<IntPoint> original)
        {
            var puntos = new List<IntPoint>();
            foreach (var p in original)
                if (puntos.Count == 0 || puntos[puntos.Count - 1] != p)
                    puntos.Add(p);
            if (puntos.Count > 1 && puntos[0] == puntos[puntos.Count - 1])
                puntos.RemoveAt(puntos.Count - 1);
            bool cambio = true;
            while (cambio && puntos.Count > 3)
            {
                cambio = false;
                for (int i = 0; i < puntos.Count; i++)
                {
                    IntPoint a = puntos[(i + puntos.Count - 1) % puntos.Count];
                    IntPoint b = puntos[i], c = puntos[(i + 1) % puntos.Count];
                    System.Numerics.BigInteger ax = (System.Numerics.BigInteger)b.X - a.X;
                    System.Numerics.BigInteger ay = (System.Numerics.BigInteger)b.Y - a.Y;
                    System.Numerics.BigInteger bx = (System.Numerics.BigInteger)c.X - b.X;
                    System.Numerics.BigInteger by = (System.Numerics.BigInteger)c.Y - b.Y;
                    if (ax * by == ay * bx && ax * bx + ay * by >= 0)
                    {
                        puntos.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }
            return puntos;
        }
    }
}
