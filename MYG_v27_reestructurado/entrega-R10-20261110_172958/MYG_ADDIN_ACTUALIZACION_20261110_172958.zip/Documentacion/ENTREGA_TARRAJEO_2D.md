# Frontera final y operación completa por cara — TARRAJEO-PLANO-R10

## Estado y base

**R10 es una candidata para aceptación dentro de Revit. No acredita todavía una liberación comercial aprobada.** Se aplica sobre R9, publicada en DESCARGAS con commit `f393b4c823c4ef3df0d3a32ac85980b4c1a17bf6`.

El nuevo log permite localizar el defecto: después de las últimas operaciones booleanas quedan retrocesos y bordes casi superpuestos dentro de un mismo anillo. Las anchuras medidas son inferiores a una micra, aunque las aristas midan cientos de milímetros. El cálculo entero considera esos perfiles simples; Revit puede interpretarlos como solapes. No se encontró deriva en Z. Otro suelo del mismo log se creó correctamente y sus voladizos ya eran cero, por lo que ese control no explica el rechazo actual.

La corrección actúa sobre la **frontera final**, antes de crear curvas y elementos nativos. Las coordenadas de los contornos privados y el log quedan fuera del ZIP.

## Normalización final de R10

Se mantienen la recomposición `exterior - unión(vacíos)`, los paños naturales de R9 y su validador nativo. Un perfil que ya sea admitido se conserva; tampoco se aplica esta normalización cuando no hay validador.

El respaldo nuevo requiere ambas condiciones: el kernel ha rechazado el candidato y el contorno presenta una inestabilidad geométrica de hasta **0.003 mm**: retroceso casi colineal o aproximación entre bordes no adyacentes. Un rechazo arbitrario del validador no autoriza modificar una geometría estable.

La búsqueda parte siempre del mismo candidato y prueba, de forma acotada:

1. Eliminar vértices conservadoramente, aceptando solo retiradas contenidas en la banda original de 0.003 mm y sin añadir material.
2. Si hace falta, una erosión numérica de 1, 1.25 o 1.5 micras, seguida de esa misma limpieza conservadora. Cada resultado debe superar de nuevo las pruebas exactas de subconjunto y banda.

La limpieza puede separar un contacto numérico en varios paños naturales. Se devuelven todos sus exteriores con sus huecos, y cada uno debe pasar la validación nativa. Si falla un fragmento, no se confirma ese conjunto. Los candidatos repetidos no se validan varias veces.

No se rellena un vacío para simplificarlo, no se crean franjas artificiales ni se amplía el límite local de 1 mm de los ajustes anteriores. La banda se fija antes de editar; no se desplaza por pasos sucesivos. La reproducción privada con un validador geométrico comprueba conservación y límites, pero **no ejecuta el kernel de Revit**.

## Una cara se confirma completa

La creación comercial utiliza un grupo exterior por cara. Un rechazo durante la preparación impide iniciar sus suelos. Si falla la creación de un paño, se revierte el grupo completo de esa cara y el contador queda en cero. El contador de éxito solo se publica después de confirmar todos los paños. Las caras completadas anteriormente pertenecen a operaciones distintas.

La cancelación con Esc se propaga por el motor y las fases nativas; las transacciones abiertas se revierten y se termina la selección. También se conserva la colocación exterior, el espesor elegido y la comprobación final de contacto.

El diálogo de error presenta un mensaje breve. La versión, la causa técnica y la ruta del log quedan en el contenido expandible. Ante una reversión que Revit no confirme, el diagnóstico indica esa condición; no declara una reversión exitosa.

## Diagnóstico del candidato que recibe Revit

R10 registra por separado el dominio RAW de origen y los **candidatos horizontales finales** rechazados por el validador. El registro nativo contiene coordenadas, factor, cierre y plano del bucle, resultados de intersección de bordes no adyacentes y las tolerancias `ShortCurveTolerance`, `VertexTolerance` y `AngleTolerance` de la aplicación.

La prueba temporal de extrusión continúa siendo de solo lectura. Los voladizos solo se revisan en el boceto perteneciente al suelo nuevo. Los fallos durante `Commit` conservan el registro de perfil, parámetros y errores nativos incorporado en R9. Si no hay descuento real, los arcos originales se conservan cuando su boceto pasa la validación nativa; el flujo de muros mantiene su comportamiento.

## Archivos del ZIP

| Acción | Ruta relativa | Finalidad |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Normalización final conservadora, fragmentos y cancelación. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs` | Validación y diagnóstico del candidato horizontal final. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Operación atómica por cara, diálogo y marcador R10. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoValidacionSuelo.cs` | Propagación de cancelación durante la comprobación de contacto. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Regresiones genéricas del motor. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Comando, resultados y alcance de pruebas. |
| AGREGAR | `Tests/RevitAceptacion/RevitAceptacion.csproj` | Proyecto separado del comando de aceptación para Revit 2027. |
| AGREGAR | `Tests/RevitAceptacion/ComandoAceptacion.cs` | Prueba con extrusiones, commits y reversiones nativas. |
| AGREGAR | `Tests/RevitAceptacion/README.md` | Ejecución en Windows y alcance de la aceptación. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP agrega `PARCHES/NORMALIZAR_FRONTERAS_DESDE_R9.patch` y `MANIFIESTO_SHA256.txt`: **12 archivos**. El parche modifica los cuatro archivos de producción; pruebas y documentación se copian aparte.

`MYG.csproj`, `Tarrajeo_MurosHandler.cs`, `Clipper.cs`, el auxiliar de alturas y el proyecto de pruebas puras no cambian. El proyecto de aceptación es independiente: no se registra en el add-in de los usuarios ni se añade a `MYG.csproj`. No se entregan DLL, paquetes, bin/obj, logs, modelos, coordenadas privadas, credenciales ni cachés.

## Instalación sobre R9

1. Respaldar y comparar cambios propios posteriores a R9.
2. Reemplazar **los cuatro archivos de producción juntos**, conservando sus rutas. Como alternativa, aplicar sobre R9 `git apply --check PARCHES/NORMALIZAR_FRONTERAS_DESDE_R9.patch` y después `git apply PARCHES/NORMALIZAR_FRONTERAS_DESDE_R9.patch`. No aplicar el parche después de copiar esos archivos.
3. Copiar pruebas y documentación. No sustituir el proyecto comercial ni duplicar entradas Compile.
4. Compilar en la configuración real de Windows/Revit, actualizar la DLL, cerrar todas las instancias de Revit y abrir una copia de prueba. Debe cargarse `TARRAJEO-PLANO-R10`.
5. Conservar el log de los casos fallidos y ejecutar la aceptación nativa descrita a continuación. Para probar el comando comercial, evitar que acabados de intentos anteriores alteren el conjunto de obstáculos visibles; no se borran automáticamente elementos del modelo.

## Validación y criterio de liberación

La suite de geometría pasa **73/73 casos** con R10. El snapshot de R9 pasa 68 y falla cinco de ellos; los 67 casos anteriores se conservan. El comando y el detalle figuran en `Tests/TarrajeoRecorte2D/README.md`. Las funciones de aceptación de esas pruebas no simulan Revit ni acreditan `Floor.Create` o `Commit`.

La compilación semántica pasó con C# 7.3 y 81 referencias de metadatos reales de Revit: motor, adaptador, fases de creación, grupo completo por cara, auxiliares, diálogo y preprocesador de fallos. El comando de aceptación completo también pasó su compilación semántica. Esto comprueba compatibilidad de código sin ejecutar la aplicación. La compilación completa en Linux mantiene el bloqueo de MSB4803/ResolveComReference; no se produce una DLL comercial aquí ni se migran las dependencias de la solución Windows.

La carpeta `Tests/RevitAceptacion` incorpora un comando de **desarrollo** para Revit 2027. Debe ejecutarse con MYG R10 cargado y el log local de los fallos. Usa la validación nativa y el método real de creación; confirma suelos temporales y revierte cada caso y la ejecución completa. Solo informa **PASS NATIVO** si pasan todos los casos, se incorporó al menos un caso real del log y se confirmaron los commits y las reversiones. Sin datos reales completos, el resultado es **INCOMPLETO**.

Ese comando no ejecuta por sí solo el flujo comercial completo de una cara. Antes de liberar R10 a los usuarios, deben pasar la aceptación nativa y la lista manual de atomicidad, cancelación y conservación de otras caras del README. La selección, las vistas, los vínculos y los tipos/versiones soportados también deben comprobarse en el entorno de distribución. **Las pruebas de geometría y la compilación no sustituyen esta aceptación.** Revit no se ha ejecutado en este entorno Linux.

## Entrega

Se publica únicamente el ZIP en una carpeta nueva de `bimchimbote-droid/DESCARGAS`, conservando las entregas anteriores. Su verificación compara bytes, SHA-256, integridad y manifiesto desde un clon independiente. No se generan ni se envían enlaces de descarga.

Esta publicación no actualiza la instalación local ni realiza Commit/Push al repositorio del código. El modelo, los informes nativos y el log geométrico permanecen fuera de la entrega pública.
