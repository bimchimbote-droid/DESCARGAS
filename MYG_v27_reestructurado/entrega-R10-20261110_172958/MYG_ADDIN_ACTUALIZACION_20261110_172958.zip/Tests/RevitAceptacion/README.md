# Aceptación nativa de tarrajeo R10 en Revit 2027

Este comando de **desarrollo** se ejecuta dentro de Revit. Usa el motor MYG R10 ya cargado, sus comprobaciones de frontera/extrusión y su método real de creación de suelos. No se registra en la interfaz del add-in comercial, no referencia una DLL MYG antigua y no sustituye pruebas de aceptación del producto completo.

No se ha ejecutado Revit en el entorno Linux de desarrollo. Compilar o revisar este proyecto no acredita un resultado nativo aprobado.

## Preparación en Windows

1. Compilar e instalar la versión R10 del add-in. Cerrar todas las instancias de Revit y abrir una copia del proyecto de prueba. Debe cargarse una única DLL MYG con marcador `TARRAJEO-PLANO-R10`.
2. Conservar el log local de la ejecución que falló en `%TEMP%\MYG_Tarrajeo_Losas_Diagnostico.log`. El comando lee los contornos R9/R10 únicos de ese archivo; sus coordenadas no se incorporan al código ni a la entrega pública.
3. Compilar este proyecto con SDK .NET 10 en Windows:

   ```powershell
   dotnet build Tests/RevitAceptacion/RevitAceptacion.csproj -c Release
   ```

   Las referencias predeterminadas corresponden a Revit 2027 incluidas en el repositorio. Para usar las API de la instalación local:

   ```powershell
   dotnet build Tests/RevitAceptacion/RevitAceptacion.csproj -c Release -p:RevitApiDirectory="C:\Program Files\Autodesk\Revit 2027"
   ```

4. En Revit, seleccionar un suelo del tipo que se quiere comprobar. Si no hay uno seleccionado, se utilizará el primer tipo de suelo del proyecto y el primer nivel disponible; el informe identifica ambos. El proyecto debe contener tipos de suelo y niveles.
5. Cargar `MYG.NativeAcceptance.dll` desde `bin\Release\net10.0-windows` con AddInManager en modo de comandos manuales y ejecutar `MYG.Quality.ComandoAceptacion`. No copiar las DLL de la API de Revit junto al comando ni registrar este comando en la distribución comercial.

## Qué se ejecuta

Se incluyen tres casos genéricos: un rectángulo, dos paños naturales separados por un vacío transversal y un contorno con un retroceso muy fino. Se añaden los contornos únicos del log local, incluidos sus segmentos originales demasiado cortos para construir directamente curvas nativas. Esos datos entran al motor por su rejilla y sus tipos cargados mediante reflexión, sin crear líneas imposibles antes de normalizarlos.

El validador llama realmente a `ValidarExtrusionHorizontal`. Cada perfil aceptado se entrega al método de producción `IntentarCrearSuelo`, que ejecuta `Floor.Create`, confirma sus transacciones y comprueba el contacto y los parámetros del nuevo suelo. Se comprueba que cada creación añada exactamente un suelo sin eliminar los anteriores.

Los casos genéricos usan una posición de prueba, con cara dos pies por encima del nivel predeterminado y normal superior. Los del log mantienen su XY y la Z original de cara; se elige el nivel de cota interna más cercana. Como el log RAW no registra explícitamente la normal de cara, se infiere su signo del sentido del exterior original antes de normalizar sus anillos (antihorario: +Z; horario: −Z). La creación utiliza la proyección horizontal y el desfase exterior del handler real. Esta inferencia se limita a los casos horizontales: la prueba no reproduce la selección de caras, la visibilidad, los vínculos ni todos los casos inclinados. Los enlaces automáticos con elementos del modelo pueden provocar un fallo real; no se ajustan ni ocultan para forzar una aprobación. Se puede repetir en una copia de proyecto vacía que contenga el mismo tipo de suelo para separar esos conflictos de la geometría del perfil.

Cada caso se revierte y un grupo externo vuelve a revertir la ejecución completa. No se conservan los suelos temporales. Un fallo de reversión es un fallo de la aceptación y se informa expresamente; por eso se trabaja sobre una copia de prueba. No se modifican tipos de suelo ni se suprimen elementos existentes.

## Resultado exigido

El informe se guarda en `%TEMP%\MYG_Aceptacion_Nativa_YYYYMMDD_HHMMSS.txt`. Contiene la versión de Revit, el marcador R10, el tipo/nivel elegidos, identificadores hash de casos locales, cantidad de perfiles, validaciones, commits y confirmación de rollback. No incluye coordenadas del log ni publica archivos automáticamente.

Solo se informa **PASS NATIVO** cuando todos los casos pasan, todos los commits esperados se han ejecutado y la reversión externa está confirmada. Además debe haberse incorporado al menos un caso del log local y no puede haber bloques RAW incompletos: se compara el número de puntos con cada cabecera y se exige un exterior seguido de sus huecos, coordenadas finitas y una cara horizontal. Un bloque truncado o inclinado se marca como no cubierto. Aprobar únicamente los tres casos genéricos produce **INCOMPLETO**, no aceptación del fallo reportado.

`Result.Succeeded` se devuelve únicamente para `PASS NATIVO`. Los casos fallidos o incompletos devuelven `Result.Cancelled` después de mostrar y guardar su informe; una reversión no confirmada devuelve `Result.Failed`. Una cancelación de la validación o de la creación, incluso envuelta por reflexión, detiene los casos restantes y produce `INCOMPLETO: ejecución cancelada`; nunca se convierte en una apertura alternativa ni en una aprobación. Los grupos abiertos se revierten antes de devolver `Result.Cancelled`.

Antes de una liberación comercial, ejecutar esta comprobación con las versiones de Revit y los tipos de suelo soportados, y comprobar también las operaciones completas por cara sobre una copia del modelo. El resultado de este comando no acredita por sí solo el comportamiento de selección, las vistas, los vínculos ni la atomicidad del flujo completo por cara.

## Comprobación nativa del comando completo por cara

Esta QA llama al método interno de creación y lo envuelve en su propio grupo de reversión. **No ejecuta el grupo comercial exterior de una cara completa**. La compilación de ese flujo contra la API acredita compatibilidad de código, pero su atomicidad requiere esta prueba adicional dentro de Revit:

- Una cara con dos perfiles válidos debe conservar exactamente dos suelos nuevos después de completar el comando comercial.
- Un fixture que falle durante la creación del segundo perfil debe dejar cero suelos nuevos de esa cara. Si no hay un fixture nativo reproducible, usar una inyección controlada de excepción en una compilación de pruebas; el comando QA de esta carpeta no introduce esa inyección ni acredita ese caso automáticamente.
- Los suelos y otras caras anteriores deben permanecer intactos al fallar esa cara.
- Cancelar la selección con Esc debe terminar la selección sin dejar elementos pendientes ni revertir caras que ya se completaron.

Registrar estos resultados por separado del informe de este comando. La creación por elementos, las vistas, los vínculos y la operación comercial completa no quedan aprobados automáticamente por `PASS NATIVO`.
