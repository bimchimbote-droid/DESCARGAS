using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace MYG.Quality
{
    // Comando de desarrollo independiente. No se registra en el add-in comercial.
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public sealed class ComandoAceptacion : IExternalCommand
    {
        private const string VersionEsperada = "TARRAJEO-PLANO-R10";
        private const double CeldasPorPie = 304800.0;
        private const BindingFlags Todos = BindingFlags.Public | BindingFlags.NonPublic |
            BindingFlags.Instance | BindingFlags.Static;

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIDocument uiDoc = commandData.Application.ActiveUIDocument;
            if (uiDoc == null)
                return Cancelar("Abra una copia del proyecto de prueba antes de ejecutar la aceptación.");
            Document doc = uiDoc.Document;
            PuenteProduccion produccion;
            try { produccion = PuenteProduccion.Cargar(); }
            catch (Exception ex) { return Cancelar(Describir(ex)); }

            Floor seleccionado = uiDoc.Selection.GetElementIds().Select(id => doc.GetElement(id))
                .OfType<Floor>().FirstOrDefault();
            FloorType tipo = seleccionado != null ? seleccionado.FloorType :
                new FilteredElementCollector(doc).OfClass(typeof(FloorType)).Cast<FloorType>().FirstOrDefault();
            var niveles = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>()
                .OrderBy(n => n.ProjectElevation).ToList();
            Level nivel = seleccionado != null ? doc.GetElement(seleccionado.LevelId) as Level : null;
            if (nivel == null) nivel = niveles.FirstOrDefault();
            if (tipo == null || nivel == null)
                return Cancelar("El proyecto necesita al menos un tipo de suelo y un nivel; no se crearon elementos.");

            double espesor;
            try { espesor = produccion.Espesor(tipo); }
            catch (Exception ex) { return Cancelar("No se obtuvo el espesor del tipo elegido: " + Describir(ex)); }
            if (double.IsNaN(espesor) || double.IsInfinity(espesor) || espesor <= 0.0)
                return Cancelar("El tipo elegido no proporciona un espesor positivo para esta prueba.");

            var informe = new StringBuilder();
            informe.AppendLine("Aceptación nativa MYG: " + VersionEsperada);
            informe.AppendLine("Revit: " + commandData.Application.Application.VersionName +
                "; compilación " + commandData.Application.Application.VersionBuild);
            informe.AppendLine("Tipo: " + tipo.Name + "; nivel: " + nivel.Name);
            informe.AppendLine("Espesor ft=" + espesor.ToString("G17", CultureInfo.InvariantCulture));
            informe.AppendLine("Se llama al motor instalado y a su creación real; cada grupo se revierte.");
            var casos = Genericos();
            string rutaLog = Path.Combine(Path.GetTempPath(), "MYG_Tarrajeo_Losas_Diagnostico.log");
            int privados = 0, incompletos = 0;
            try
            {
                var locales = LeerLog(rutaLog, out incompletos);
                privados = locales.Count;
                casos.AddRange(locales);
                informe.AppendLine("Casos locales únicos del log R9/R10: " + privados +
                    "; bloques incompletos=" + incompletos);
            }
            catch (Exception ex)
            {
                informe.AppendLine("No se incorporó el log local: " + Describir(ex));
            }
            int aprobados = 0, fallidos = 0;
            bool reversionFinal = false, cancelado = false;
            using (var ejecucion = new TransactionGroup(doc, "MYG QA - revertir todas las pruebas"))
            {
                try
                {
                    if (ejecucion.Start() != TransactionStatus.Started)
                        throw new InvalidOperationException("No se inició el grupo externo de QA.");
                    foreach (Caso caso in casos)
                    {
                        bool creado = false, revertido = false;
                        string detalle = string.Empty;
                        int perfiles = 0, confirmados = 0, validaciones = 0;
                        using (var ensayo = new TransactionGroup(doc, "MYG QA - " + caso.Nombre))
                        {
                            try
                            {
                                if (ensayo.Start() != TransactionStatus.Started)
                                    throw new InvalidOperationException("No se inició el grupo del caso.");
                                double zCara = caso.ZCara ?? (nivel.ProjectElevation + 2.0);
                                Level nivelCaso = niveles.OrderBy(n => Math.Abs(n.ProjectElevation - zCara)).First();
                                XYZ origen = new XYZ(caso.AnclaX, caso.AnclaY, zCara);
                                XYZ normal = new XYZ(0.0, 0.0, caso.NormalZ);
                                var contexto = new ContextoNativo(produccion, origen, espesor,
                                    doc.Application.ShortCurveTolerance);
                                List<List<CurveLoop>> bocetos = produccion.Preparar(caso, contexto);
                                validaciones = contexto.Validaciones;
                                perfiles = bocetos.Count;
                                if (perfiles == 0 || (caso.PerfilesEsperados > 0 &&
                                    perfiles != caso.PerfilesEsperados))
                                    throw new InvalidOperationException("Cantidad inesperada de perfiles: " + perfiles);
                                foreach (List<CurveLoop> boceto in bocetos)
                                {
                                    HashSet<string> antes = IdsSuelos(doc);
                                    string fallo;
                                    if (!produccion.Crear(doc, boceto, tipo, nivelCaso, origen, normal, espesor, out fallo))
                                        throw new InvalidOperationException("La creación real no confirmó el suelo: " + fallo);
                                    HashSet<string> despues = IdsSuelos(doc);
                                    if (!antes.IsSubsetOf(despues) || despues.Except(antes).Count() != 1)
                                        throw new InvalidOperationException("La creación no añadió exactamente un suelo conservando los anteriores.");
                                    confirmados++;
                                }
                                creado = confirmados == perfiles;
                            }
                            catch (Exception ex)
                            {
                                detalle = Describir(ex);
                                cancelado = EsCancelacion(ex);
                            }
                            finally
                            {
                                if (ensayo.GetStatus() == TransactionStatus.Started)
                                    revertido = ensayo.RollBack() == TransactionStatus.RolledBack;
                            }
                        }
                        if (!revertido)
                            throw new InvalidOperationException("No se confirmó la reversión del caso " + caso.Nombre + ". " + detalle);
                        bool aprobado = creado && revertido && !cancelado;
                        if (aprobado) aprobados++; else if (!cancelado) fallidos++;
                        informe.AppendLine((cancelado ? "INCOMPLETO " : aprobado ? "PASS " : "FAIL ") + caso.Nombre +
                            "; perfiles=" + perfiles + "; commits=" + confirmados +
                            "; validaciones nativas=" + validaciones + "; rollback=true" +
                            (string.IsNullOrWhiteSpace(detalle) ? string.Empty : "; " + detalle));
                        if (cancelado) break;
                    }
                }
                catch (Exception ex)
                {
                    if (EsCancelacion(ex)) cancelado = true;
                    else fallidos++;
                    informe.AppendLine((cancelado ? "INCOMPLETO ejecución cancelada: " : "FAIL ejecución: ") + Describir(ex));
                }
                finally
                {
                    if (ejecucion.GetStatus() == TransactionStatus.Started)
                        reversionFinal = ejecucion.RollBack() == TransactionStatus.RolledBack;
                }
            }
            informe.AppendLine("Reversión externa confirmada=" + reversionFinal);
            string estado = cancelado && reversionFinal ? "INCOMPLETO: ejecución cancelada" :
                fallidos == 0 && reversionFinal && privados > 0 && incompletos == 0 ? "PASS NATIVO" :
                fallidos == 0 && reversionFinal ? "INCOMPLETO: faltan casos locales o hay contornos incompletos" : "FAIL NATIVO";
            informe.AppendLine("Resultado: " + estado + "; aprobados=" + aprobados + "; fallidos=" + fallidos);
            string rutaInforme = Path.Combine(Path.GetTempPath(), "MYG_Aceptacion_Nativa_" +
                DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".txt");
            File.WriteAllText(rutaInforme, informe.ToString(), Encoding.UTF8);
            var dialogo = new TaskDialog("MYG - QA nativa (desarrollo)");
            dialogo.MainInstruction = estado;
            dialogo.MainContent = "Casos aprobados: " + aprobados + ". Fallidos: " + fallidos +
                ".\nReversión externa: " + (reversionFinal ? "confirmada" : "NO confirmada") +
                ".\nInforme local:\n" + rutaInforme;
            dialogo.ExpandedContent = informe.ToString();
            dialogo.Show();
            if (!reversionFinal)
            {
                message = "QA no confirmó la reversión externa. Revise la copia de prueba y el informe.";
                return Result.Failed;
            }
            return estado == "PASS NATIVO" ? Result.Succeeded : Result.Cancelled;
        }

        private static Result Cancelar(string mensaje)
        {
            TaskDialog.Show("MYG - QA nativa", mensaje);
            return Result.Cancelled;
        }

        private static HashSet<string> IdsSuelos(Document doc)
        {
            return new HashSet<string>(new FilteredElementCollector(doc).OfClass(typeof(Floor))
                .ToElementIds().Select(id => id.ToString()), StringComparer.Ordinal);
        }

        private static string Describir(Exception ex)
        {
            while (ex is TargetInvocationException && ex.InnerException != null) ex = ex.InnerException;
            return ex.GetType().Name + " - " + ex.Message;
        }

        private static bool EsCancelacion(Exception ex)
        {
            while (ex is TargetInvocationException && ex.InnerException != null) ex = ex.InnerException;
            return ex is OperationCanceledException ||
                ex is Autodesk.Revit.Exceptions.OperationCanceledException;
        }

        private sealed class Punto
        {
            internal long X, Y;
            internal Punto(long x, long y) { X = x; Y = y; }
        }

        private sealed class Caso
        {
            internal string Nombre;
            internal List<List<Punto>> Anillos;
            internal double AnclaX, AnclaY;
            internal double? ZCara;
            internal int NormalZ = 1;
            internal int PerfilesEsperados;
        }

        private static List<Punto> P(params long[] xy)
        {
            var p = new List<Punto>();
            for (int i = 0; i < xy.Length; i += 2) p.Add(new Punto(xy[i], xy[i + 1]));
            return p;
        }

        private static List<Caso> Genericos()
        {
            return new List<Caso>
            {
                new Caso { Nombre="generico-rectangulo", AnclaX=1000, AnclaY=1000,
                    PerfilesEsperados=1, Anillos=new List<List<Punto>> {P(0,0,1000000,0,1000000,1000000,0,1000000)} },
                new Caso { Nombre="generico-dos-panos", AnclaX=1020, AnclaY=1000,
                    PerfilesEsperados=2, Anillos=new List<List<Punto>> {P(0,0,1000000,0,1000000,1000000,0,1000000),
                        P(400000,-10000,600000,-10000,600000,1010000,400000,1010000)} },
                new Caso { Nombre="generico-retroceso-fino", AnclaX=1040, AnclaY=1000,
                    PerfilesEsperados=0, Anillos=new List<List<Punto>> {P(0,0,1000000,0,1000000,1000000,
                        2,1000000,1,1200000,0,1000000)} }
            };
        }

        private static List<Caso> LeerLog(string ruta, out int incompletos)
        {
            incompletos = 0;
            var resultado = new List<Caso>();
            if (!File.Exists(ruta)) return resultado;
            var vistos = new HashSet<string>(StringComparer.Ordinal);
            string[] bloques = Regex.Split(File.ReadAllText(ruta), @"(?=^\[)", RegexOptions.Multiline);
            const string numero = @"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)";
            var coordenada = new Regex(@"^\s*\(" + numero + @",\s*" + numero + @",\s*" + numero + @"\)");
            foreach (string bloque in bloques)
            {
                if (!bloque.Contains("TARRAJEO-PLANO-R9") && !bloque.Contains(VersionEsperada)) continue;
                if (!bloque.Contains("Exterior:"))
                {
                    if (bloque.Contains("Hueco:")) incompletos++;
                    continue;
                }
                var xyz = new List<List<double[]>>();
                var esperados = new List<int>();
                bool formatoValido = true;
                foreach (string linea in bloque.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    Match cabecera = Regex.Match(linea, @"^(Exterior|Hueco):\s*(\d+)\b");
                    if (cabecera.Success)
                    {
                        bool exterior = cabecera.Groups[1].Value == "Exterior";
                        if (exterior != (xyz.Count == 0)) formatoValido = false;
                        xyz.Add(new List<double[]>());
                        esperados.Add(int.Parse(cabecera.Groups[2].Value, CultureInfo.InvariantCulture));
                    }
                    else if (Regex.IsMatch(linea, @"^(Exterior|Hueco):")) formatoValido = false;
                    Match m = coordenada.Match(linea);
                    if (m.Success && xyz.Count > 0)
                        xyz[xyz.Count - 1].Add(new[] { double.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture),
                            double.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture),
                            double.Parse(m.Groups[3].Value, CultureInfo.InvariantCulture) });
                }
                if (!formatoValido || xyz.Count == 0 || xyz.Count != esperados.Count ||
                    xyz.Where((p, i) => p.Count < 3 || p.Count != esperados[i]).Any() ||
                    xyz.SelectMany(p => p).Any(p => p.Any(v => double.IsNaN(v) || double.IsInfinity(v))))
                { incompletos++; continue; }
                // Esta QA reproduce caras horizontales. No proyectar una cara
                // inclinada y declarar que su creación original quedó probada.
                double zMinima = xyz.SelectMany(p => p).Min(p => p[2]);
                double zMaxima = xyz.SelectMany(p => p).Max(p => p[2]);
                if (zMaxima - zMinima > 1e-8) { incompletos++; continue; }
                double ax = xyz[0][0][0], ay = xyz[0][0][1];
                var anillos = xyz.Select(r => r.Select(p => new Punto(
                    checked((long)Math.Round((p[0] - ax) * CeldasPorPie, MidpointRounding.AwayFromZero)),
                    checked((long)Math.Round((p[1] - ay) * CeldasPorPie, MidpointRounding.AwayFromZero)))).ToList()).ToList();
                string clave = ax.ToString("G17", CultureInfo.InvariantCulture) + "," +
                    ay.ToString("G17", CultureInfo.InvariantCulture) + "," +
                    xyz[0][0][2].ToString("G17", CultureInfo.InvariantCulture) + "|" +
                    string.Join("|", anillos.Select(r => string.Join(";", r.Select(p => p.X + "," + p.Y))));
                if (!vistos.Add(clave)) continue;
                string hash;
                using (SHA256 sha = SHA256.Create())
                    hash = BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(clave))).Replace("-", "").Substring(0, 12);
                double areaOriginal = 0.0;
                for (int i = 0; i < anillos[0].Count; i++)
                {
                    Punto a = anillos[0][i], b = anillos[0][(i + 1) % anillos[0].Count];
                    areaOriginal += (double)a.X * b.Y - (double)a.Y * b.X;
                }
                resultado.Add(new Caso { Nombre="log-" + (resultado.Count + 1) + "-" + hash,
                    AnclaX=ax, AnclaY=ay, ZCara=xyz[0][0][2], NormalZ=areaOriginal >= 0.0 ? 1 : -1,
                    Anillos=anillos });
            }
            return resultado;
        }

        private sealed class ContextoNativo
        {
            private readonly PuenteProduccion _produccion;
            private readonly XYZ _origen;
            private readonly double _espesor, _minimo;
            internal int Validaciones;
            internal double Minimo { get { return _minimo; } }
            internal ContextoNativo(PuenteProduccion produccion, XYZ origen, double espesor, double minimo)
            { _produccion=produccion; _origen=origen; _espesor=espesor; _minimo=minimo; }
            public bool Validar(object caminos, double factor)
            {
                Validaciones++;
                string detalle;
                try { return _produccion.Validar(Convertir(caminos, factor), _espesor, out detalle); }
                catch (Exception ex) when (EsCancelacion(ex))
                {
                    // El motor debe recibir la cancelación real del callback,
                    // no confundir su envoltura de reflexión con otro candidato.
                    throw new OperationCanceledException("Validación nativa cancelada.",
                        ex is TargetInvocationException ? ex.InnerException ?? ex : ex);
                }
            }
            internal List<CurveLoop> Convertir(object caminos, double factor)
            {
                if (factor < 1 || double.IsNaN(factor) || double.IsInfinity(factor))
                    throw new InvalidOperationException("Factor de coordenadas no válido.");
                var resultado = new List<CurveLoop>();
                foreach (object camino in (IEnumerable)caminos)
                {
                    var puntos = new List<XYZ>();
                    foreach (object p in (IEnumerable)camino)
                    {
                        Type t=p.GetType();
                        double x=Convert.ToDouble(t.GetField("X").GetValue(p), CultureInfo.InvariantCulture);
                        double y=Convert.ToDouble(t.GetField("Y").GetValue(p), CultureInfo.InvariantCulture);
                        puntos.Add(new XYZ(_origen.X+x/factor/CeldasPorPie,
                            _origen.Y+y/factor/CeldasPorPie, _origen.Z));
                    }
                    if (puntos.Count < 3) throw new InvalidOperationException("Anillo degenerado.");
                    var curvas = new List<Curve>();
                    for (int i=0;i<puntos.Count;i++)
                    {
                        XYZ a=puntos[i],b=puntos[(i+1)%puntos.Count];
                        if (a.DistanceTo(b)<=_minimo)
                            throw new InvalidOperationException("Una arista queda por debajo del mínimo nativo.");
                        curvas.Add(Line.CreateBound(a,b));
                    }
                    resultado.Add(CurveLoop.Create(curvas));
                }
                return resultado;
            }
        }

        private sealed class PuenteProduccion
        {
            private readonly Type _punto, _nodo, _raiz;
            private readonly MethodInfo _ajustar, _validar, _crear, _espesor, _proyectar;
            private readonly object _handler;
            private PuenteProduccion(Assembly assembly)
            {
                Type motor=assembly.GetType("MYG_Addin.RecortePlanoExterior",true);
                Type adaptador=assembly.GetType("MYG_Addin.TarrajeoRecorteExterior",true);
                Type handler=ObtenerHandler(assembly);
                _punto=assembly.GetType("MYG_Addin.RecorteClipper.IntPoint",true);
                _nodo=assembly.GetType("MYG_Addin.RecorteClipper.PolyNode",true);
                _raiz=assembly.GetType("MYG_Addin.RecorteClipper.PolyTree",true);
                _ajustar=motor.GetMethod("AjustarPerfiles",Todos);
                _validar=adaptador.GetMethod("ValidarExtrusionHorizontal",Todos);
                _crear=handler.GetMethod("IntentarCrearSuelo",Todos);
                _proyectar=handler.GetMethod("BocetoHorizontalSinCambiarContorno",Todos);
                _espesor=handler.GetMethod("GetFloorThickness",Todos);
                _handler=Activator.CreateInstance(handler);
                if (_ajustar==null || _ajustar.GetParameters().Length!=8 || _validar==null ||
                    _crear==null || _crear.GetParameters().Length!=11 || _espesor==null || _proyectar==null)
                    throw new InvalidOperationException("El contrato de QA no coincide con la DLL R10 cargada.");
            }
            internal static PuenteProduccion Cargar()
            {
                var compatibles = new List<Assembly>();
                foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    try
                    {
                        if (assembly.GetType("MYG_Addin.RecortePlanoExterior",false)==null) continue;
                        Type handler=ObtenerHandler(assembly);
                        FieldInfo marca=handler==null?null:handler.GetField("VERSION_RECORTE",Todos);
                        if (marca!=null && (string)marca.GetRawConstantValue()==VersionEsperada) compatibles.Add(assembly);
                    }
                    catch (ReflectionTypeLoadException) { }
                }
                if (compatibles.Count!=1)
                    throw new InvalidOperationException("Cargue una única DLL MYG R10 actual en Revit y vuelva a ejecutar QA; coincidencias="+compatibles.Count);
                return new PuenteProduccion(compatibles[0]);
            }
            private static Type ObtenerHandler(Assembly assembly)
            {
                Type directo=assembly.GetType("Tarrajeo_SuelosHandler",false) ??
                    assembly.GetType("MYG_Addin.Tarrajeo_SuelosHandler",false);
                if(directo!=null) return directo;
                try { return assembly.GetTypes().SingleOrDefault(t=>t.Name=="Tarrajeo_SuelosHandler"); }
                catch(ReflectionTypeLoadException ex)
                { return ex.Types.Where(t=>t!=null).SingleOrDefault(t=>t.Name=="Tarrajeo_SuelosHandler"); }
            }
            internal double Espesor(FloorType tipo) { return (double)_espesor.Invoke(_handler,new object[]{tipo}); }
            internal bool Validar(List<CurveLoop> perfil,double espesor,out string detalle)
            {
                object[] args={perfil,espesor,null};bool ok=(bool)_validar.Invoke(null,args);
                detalle=args[2] as string??string.Empty;return ok;
            }
            internal List<List<CurveLoop>> Preparar(Caso caso,ContextoNativo contexto)
            {
                object raiz=Activator.CreateInstance(_raiz), nodo=Activator.CreateInstance(_nodo);
                Agregar(raiz,nodo);
                for(int r=0;r<caso.Anillos.Count;r++)
                {
                    var anillo=caso.Anillos[r].Select(p=>new Punto(p.X,p.Y)).ToList();
                    double area=0;for(int i=0;i<anillo.Count;i++)
                    {Punto a=anillo[i],b=anillo[(i+1)%anillo.Count];area+=(double)a.X*b.Y-(double)a.Y*b.X;}
                    if ((area>0)!=(r==0)) anillo.Reverse();
                    object destino=r==0?nodo:Activator.CreateInstance(_nodo);
                    if(r>0) Agregar(nodo,destino);
                    var contorno=(IList)_nodo.GetProperty("Contour").GetValue(destino,null);
                    foreach(Punto p in anillo) contorno.Add(Activator.CreateInstance(_punto,new object[]{p.X,p.Y}));
                }
                Type delegado=_ajustar.GetParameters()[7].ParameterType;
                ParameterExpression caminos=Expression.Parameter(delegado.GetGenericArguments()[0],"caminos");
                ParameterExpression factor=Expression.Parameter(typeof(double),"factor");
                var llamada=Expression.Call(Expression.Constant(contexto),typeof(ContextoNativo).GetMethod("Validar"),
                    Expression.Convert(caminos,typeof(object)),factor);
                Delegate callback=Expression.Lambda(delegado,llamada,caminos,factor).Compile();
                object[] args={nodo,contexto.Minimo*CeldasPorPie,1000.0,null,0.0,null,1.0,callback};
                bool ok=(bool)_ajustar.Invoke(null,args);
                if(!ok)throw new InvalidOperationException(args[5] as string??"El motor no preparó todos los paños.");
                var resultado=new List<List<CurveLoop>>();
                foreach(object perfil in (IEnumerable)args[3])resultado.Add(contexto.Convertir(perfil,(double)args[6]));
                return resultado;
            }
            private void Agregar(object padre,object hijo) { _nodo.GetMethod("AddChild",Todos).Invoke(padre,new[]{hijo}); }
            internal bool Crear(Document doc,List<CurveLoop> perfil,FloorType tipo,Level nivel,
                XYZ origen,XYZ normal,double espesor,out string detalle)
            {
                var boceto = (List<CurveLoop>)_proyectar.Invoke(_handler,new object[]
                    {perfil,Plane.CreateByNormalAndOrigin(normal,origen),nivel.ProjectElevation});
                object[] args={doc,boceto,tipo,nivel,origen,normal,espesor,false,0.0,null,false};
                bool ok=(bool)_crear.Invoke(_handler,args);detalle=args[9] as string??string.Empty;return ok;
            }
        }
    }
}
