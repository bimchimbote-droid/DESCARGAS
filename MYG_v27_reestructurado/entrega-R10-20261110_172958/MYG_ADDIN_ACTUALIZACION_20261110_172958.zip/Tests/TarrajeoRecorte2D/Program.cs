using MYG_Addin;
using MYG_Addin.RecorteClipper;
using Path2D = System.Collections.Generic.List<MYG_Addin.RecorteClipper.IntPoint>;
using Region = System.Collections.Generic.List<System.Collections.Generic.List<MYG_Addin.RecorteClipper.IntPoint>>;

const double S = 304800.0;
int passed = 0, failed = 0;
Test("rectangle without obstacles remains one rectangle", () => Check(Cut(Rect(0,0,10,10)),100,1,0,4));
Test("internal obstacle creates its actual opening", () => Check(Cut(Rect(0,0,10,10), R(Rect(2,2,4,4))),96,1,1));
Test("partial obstacle creates a notch", () => Check(Cut(Rect(0,0,10,10), R(Rect(4,-1,6,3))),94,1,0,8));
Test("only a transverse obstacle separates two panels", () => Check(Cut(Rect(0,0,10,10),R(Rect(4,-1,6,11))),80,2,0));
Test("complete cover leaves no finish", () => Check(Cut(Rect(0,0,10,10),R(Rect(-1,-1,11,11))),0,0,0));
Test("external obstacle does not modify the face", () => Check(Cut(Rect(0,0,10,10),R(Rect(11,0,12,10))),100,1,0,4));
Test("duplicate faces never cancel an obstacle", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(Rect(2,2,4,4))),96,1,1));
Test("overlapping obstacles are subtracted once", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,6,6)),R(Rect(4,2,8,6))),76,1,1));
Test("triangulated rectangle has no diagonal in its final opening", () => {
    var tree=Cut(Rect(0,0,10,10),R(P(2,2,4,2,4,4)),R(P(2,2,4,4,2,4)));
    Check(tree,96,1,1); Assert(Contours(tree).All(p=>RecortePlanoExterior.QuitarColineales(p).Count==4),"A mesh diagonal survived.");
});
Test("thin triangles inside a footprint never enlarge the cut", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(P(3.999,2,4,3,3.999,4))),96,1,1));
Test("all triangles of a rectangular face unite into one panel", () => {
    var normalized=RecortePlanoExterior.UnirRegion(R(P(0,0,10,0,10,10),P(0,0,10,10,0,10)));
    Check(RecortePlanoExterior.Restar(normalized,Array.Empty<Region>()),100,1,0,4);
});
Test("original face openings are preserved", () => Check(RecortePlanoExterior.Restar(R(Rect(0,0,10,10),Rect(2,2,4,4)),new[]{R(Rect(11,0,12,10))}),96,1,1));
Test("obstacle opening retains a natural island", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,8,8),Rect(4,4,6,6))),68,2,1));
Test("another obstacle fills the opening in an obstacle", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,8,8),Rect(4,4,6,6)),R(Rect(4,4,6,6))),64,1,1));
Test("reversed contours preserve ownership", () => {
    var face=Rect(0,0,10,10);face.Reverse();var hole=Rect(2,2,4,4);hole.Reverse();
    Check(Cut(face,R(hole)),96,1,1);
});
Test("rotated rectangles keep rectangular boundaries", () => {
    Path2D Rotate(Path2D p)=>p.Select(v=>new IntPoint((3*v.X-4*v.Y)/5,(4*v.X+3*v.Y)/5)).ToList();
    var tree=Cut(Rotate(Rect(0,0,10,10)),R(Rotate(Rect(2,2,4,4))));
    Check(tree,96,1,1);Assert(Contours(tree).All(p=>RecortePlanoExterior.QuitarColineales(p).Count==4),"Unexpected diagonal/vertex.");
});
Test("two close obstacles keep the real material gap", () => {
    var tree=Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(Rect(4.01,2,6,4)));
    Check(tree,92.02,1,2);
});
Test("redundant collinear vertices do not become edges", () => {
    var p=P(0,0,5,0,10,0,10,10,0,10,0,0);Assert(RecortePlanoExterior.QuitarColineales(p).Count==4,"Collinear vertex remained.");
});
Test("same domain is independent of orientation and redundant vertices", () => {
    var a=R(Rect(0,0,10,10),Rect(2,2,4,4));var b=R(P(10,10,10,0,5,0,0,0,0,10),Rect(2,2,4,4));
    Assert(RecortePlanoExterior.MismoDominio(a,b),"Equal domain changed.");
});
Test("equal area with a moved opening is a different domain", () => Assert(!RecortePlanoExterior.MismoDominio(R(Rect(0,0,10,10),Rect(2,2,4,4)),R(Rect(0,0,10,10),Rect(6,6,8,8))),"Opening location was ignored."));
Test("upward finish is outside the solid", () => Near(TarrajeoAlturas.CalcularDesfase(100,90,1,.05,0),10.05));
Test("downward finish is outside the solid", () => Near(TarrajeoAlturas.CalcularDesfase(100,90,-1,.05,0),10));
Test("internal project level controls offset", () => Near(TarrajeoAlturas.CalcularDesfase(1100,1090,1,.05,0),10.05));
Test("contact check rejects a finish penetrating the host", () => Assert(!TarrajeoAlturas.ContactoExteriorValido(-.01,.04,0,.0003),"Penetration accepted."));
Test("contact check accepts an external finish touching the face", () => Assert(TarrajeoAlturas.ContactoExteriorValido(0,.05,0,.0003),"External contact rejected."));
Test("precision removes a long almost-collinear backtracking spike", () => {
    var p=new Path2D { new IntPoint(0,0),new IntPoint(1000000,0),new IntPoint(1000000,1000000),
        new IntPoint(0,1000000),new IntPoint(0,1015000),new IntPoint(1,1000000) };
    var tree=RecortePlanoExterior.Restar(R(p),Array.Empty<Region>());
    Assert(!HasNumericalBacktrack(tree),"The near-collinear reverse edge survived.");
    Assert(Contours(tree).All(q=>q.Count>=3 && q.Count<=4),"A precision spike remains in the boundary.");
    Assert(Math.Abs(Contours(tree).Sum(Clipper.Area)-1e12)<5000000,"The main panel was changed.");
});
Test("precision removes a long sub-micrometre triangular residue", () => {
    var p=new Path2D {new IntPoint(0,0),new IntPoint(337000,0),new IntPoint(15000,1)};
    var tree=RecortePlanoExterior.Restar(R(p),Array.Empty<Region>());
    Assert(!Contours(tree).Any(),"Degenerate long triangle was retained as a floor profile.");
});
Test("precision removes a second thin rotated numerical residue", () => {
    var p=new Path2D {new IntPoint(0,0),new IntPoint(120000,90000),new IntPoint(80001,60000)};
    Assert(!Contours(RecortePlanoExterior.Restar(R(p),Array.Empty<Region>())).Any(),"Thin rotated residue survived.");
});
Test("a real half-millimetre bevel is never silently removed", () => {
    var p=new Path2D {new IntPoint(0,0),new IntPoint(1000000,0),new IntPoint(1000000,999500),
        new IntPoint(999500,1000000),new IntPoint(0,1000000)};
    var tree=RecortePlanoExterior.Restar(R(p),Array.Empty<Region>());
    Assert(Contours(tree).Single().Count==5,"A real bevel was removed using a creation tolerance.");
    Assert(RecortePlanoExterior.MismoDominio(R(p),Contours(tree).ToList()),"The real bevel domain changed.");
});
Test("a ten-micrometre gap survives precision cleaning", () => {
    var a=new Path2D {new IntPoint(1000,1000),new IntPoint(2000,1000),new IntPoint(2000,2000),new IntPoint(1000,2000)};
    var b=a.Select(v=>new IntPoint(v.X+1010,v.Y)).ToList();
    var face=new Path2D {new IntPoint(0,0),new IntPoint(5000,0),new IntPoint(5000,5000),new IntPoint(0,5000)};
    var tree=RecortePlanoExterior.Restar(R(face),new[]{R(a),R(b)});
    var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Assert(nodes.Count(n=>n.IsHole)==2,"Precision cleaning merged genuinely separate openings.");
});
Test("a real small opening survives cleaning", () => {
    var face=new Path2D {new IntPoint(0,0),new IntPoint(10000,0),new IntPoint(10000,10000),new IntPoint(0,10000)};
    var hole=new Path2D {new IntPoint(4000,4000),new IntPoint(5000,4000),new IntPoint(5000,5000),new IntPoint(4000,5000)};
    var tree=RecortePlanoExterior.Restar(R(face,hole),Array.Empty<Region>());
    Assert(Contours(tree).Count()==2,"A real opening was filled.");
});
// R6 tests use the explicit local-repair operation. Restar retains the R5
// contract: real small details are not silently changed by precision cleaning.
Test("local repair handles a half-millimetre step without offsetting the panel", () => {
    var node=LocalNode(IP(0,0,10000,0,10000,10000,5000,10000,5000,9500,0,9500));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(Clipper.PointInPolygon(LocalScalePoint(new IntPoint(10,10),adjusted.Factor),LocalTree(adjusted.Paths).Childs.Single().Contour)==1,
        "Remote material was removed by a global offset.");
});
Test("a convex short bevel is repaired by removing material only", () => {
    var node=LocalNode(IP(0,0,10000,0,10000,9650,9650,10000,0,10000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Removed>0,"The forbidden support-line corner was filled instead of trimming the bevel.");
});
Test("short bevel in an opening expands the void conservatively", () => {
    var node=LocalNode(IRect(0,0,20000,20000),IP(5000,5000,15000,5000,15000,14650,14650,15000,5000,15000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Removed>0,"The opening was not repaired conservatively.");
});
Test("valid contours are returned unchanged by local repair", () => {
    var node=LocalNode(IRect(0,0,10000,10000),IRect(2000,2000,4000,4000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Factor==1.0,"A valid contour was unnecessarily rescaled.");
    Assert(LocalSame(LocalPaths(node),adjusted.Paths),"An already valid contour changed.");
    Near(adjusted.Removed,0,0.5);
});
Test("insufficient repair distance returns the original domain without partial changes", () => {
    var node=LocalNode(IP(0,0,10000,0,10000,9650,9650,10000,0,10000));
    var adjusted=LocalAdjust(node,800,100);
    Assert(!adjusted.Accepted,"A 0.495mm edge was repaired beyond the 0.1mm distance limit.");
    Assert(adjusted.Factor==1.0,"Failure did not return the original coordinate scale.");
    Assert(LocalSame(LocalPaths(node),adjusted.Paths),"Failure leaked a partially repaired region.");
    Near(adjusted.Removed,0,0.5);
});
Test("local corner repair preserves an independent opening exactly", () => {
    var opening=IRect(2000,2000,4000,4000);
    var node=LocalNode(IP(0,0,10000,0,10000,9650,9650,10000,0,10000),opening);
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    var hole=LocalTree(adjusted.Paths).Childs.Single().Childs.Single();
    Assert(LocalSame(LocalScalePaths(R(opening),adjusted.Factor),R(hole.Contour)),"An unrelated opening changed during a corner repair.");
});
Test("local repair works across the closing edge and after rotation", () => {
    Path2D TransformLocal(Path2D p)=>p.Select(v=>new IntPoint(300000+v.Y,-200000-v.X)).ToList();
    var node=LocalNode(TransformLocal(IP(0,0,10000,0,10000,10000,5000,10000,5000,9500,0,9500)));
    for(int shift=0;shift<node.Contour.Count;shift++) {
        var rotated=new Path2D(node.Contour.Skip(shift).Concat(node.Contour.Take(shift)));
        var testNode=LocalRawNode(rotated);
        CheckLocalRepair(testNode,LocalAdjust(testNode,800,1000),800,1000);
    }
});
Test("all independent short corners must be repaired before success", () => {
    var node=LocalNode(IP(0,350,350,0,10000,0,10000,9650,9650,10000,0,10000));
    CheckLocalRepair(node,LocalAdjust(node,800,1000),800,1000);
});
Test("failure after a provisional repair rolls the whole owner back", () => {
    var one=LocalNode(IP(0,0,10000,0,10000,9440,9440,10000,0,10000));
    CheckLocalRepair(one,LocalAdjust(one,800,100),800,100);
    var combined=LocalNode(IP(0,0,10000,0,10000,9440,9440,10000,350,10000,0,9650));
    var adjusted=LocalAdjust(combined,800,100);
    Assert(!adjusted.Accepted,"A second corner exceeded the distance limit but was accepted.");
    Assert(adjusted.Factor==1.0,"Failed multi-corner repair did not restore the original coordinate scale.");
    Assert(LocalSame(LocalPaths(combined),adjusted.Paths),"Failure leaked the first provisional corner repair.");
    Near(adjusted.Removed,0,0.5);
});
Test("rotated one-metre panel repairs a 0.499673mm step without rounding it outside its support", () => {
    double angle=17.03*Math.PI/180.0, cosine=Math.Cos(angle),sine=Math.Sin(angle);
    var raw=new[] {(0.0,0.0),(1000000.0,0.0),(1000000.0,1000000.0),
        (500000.0,1000000.0),(500000.0,999500.327),(0.0,999500.327)};
    var path=raw.Select(p=>new IntPoint(
        (long)Math.Round(p.Item1*cosine-p.Item2*sine,MidpointRounding.AwayFromZero),
        (long)Math.Round(p.Item1*sine+p.Item2*cosine,MidpointRounding.AwayFromZero))).ToList();
    var node=LocalNode(path);
    CheckLocalRepair(node,LocalAdjust(node,800,1000),800,1000);
});
// R7 contacts are genuine point contacts between distinct rings. Their local
// opening may merge voids or join one void to the exterior; R6's unchanged
// CheckLocalRepair still requires the original topology for all old tests.
Test("point contact from a triangular opening becomes a local notch", () => {
    var node=LocalNode(IRect(0,0,100000,100000),IP(20000,0,40000,20000,20000,40000));
    CheckContactRepair(node,LocalAdjust(node,800,1000),800,1000,0);
});
Test("point contact from a rotated rectangular opening becomes a local notch", () => {
    var node=LocalNode(IRect(0,0,100000,100000),IP(0,50000,20000,30000,40000,50000,20000,70000));
    CheckContactRepair(node,LocalAdjust(node,800,1000),800,1000,0);
});
Test("two rectangular openings touching at one corner become one local opening", () => {
    var node=LocalNode(IRect(0,0,100000,100000),IRect(20000,20000,40000,40000),IRect(40000,40000,60000,60000));
    CheckContactRepair(node,LocalAdjust(node,800,1000),800,1000,1);
});
Test("two triangular openings touching at one corner become one local opening", () => {
    var node=LocalNode(IRect(0,0,100000,100000),IP(20000,20000,40000,20000,40000,40000),IP(40000,40000,60000,40000,60000,60000));
    CheckContactRepair(node,LocalAdjust(node,800,1000),800,1000,1);
});
Test("a rectangle sharing an outer boundary segment stays an unchanged notch", () => {
    var tree=RecortePlanoExterior.Restar(R(IRect(0,0,100000,100000)),new[]{R(IRect(20000,0,40000,20000))});
    var node=tree.Childs.Single();var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Factor==1.0 && LocalSame(LocalPaths(node),adjusted.Paths),"An already valid segment-sharing notch changed.");
    Near(adjusted.Removed,0,0.5);
});
Test("opening one point contact preserves an independent genuine opening", () => {
    var independent=IRect(65000,65000,80000,80000);
    var node=LocalNode(IRect(0,0,100000,100000),IP(20000,0,40000,20000,20000,40000),independent);
    var adjusted=LocalAdjust(node,800,1000);
    CheckContactRepair(node,adjusted,800,1000,1);
    var hole=LocalTree(adjusted.Paths).Childs.Single().Childs.Single();
    Assert(LocalSame(LocalScalePaths(R(independent),adjusted.Factor),R(hole.Contour)),"A separate genuine opening moved or disappeared.");
});
Test("an unrelated nearby opening stays independent inside a contact relief disk", () => {
    // Its nearest corner is only sqrt(50²+50²) cells from the proven contact,
    // but a real50-cell gap separates it from both touching openings.
    var independent=IRect(39050,40050,39950,40950);
    var node=LocalNode(IRect(0,0,100000,100000),IRect(20000,20000,40000,40000),
        IRect(40000,40000,60000,60000),independent);
    var adjusted=LocalAdjust(node,800,1000);
    CheckContactRepair(node,adjusted,800,1000,2);
    var holes=LocalTree(adjusted.Paths).Childs.Single().Childs;
    Assert(holes.Any(h=>LocalSame(LocalScalePaths(R(independent),adjusted.Factor),R(h.Contour))),
        "A nearby non-contact opening merged or changed merely because it lies inside the relief disk.");
});
Test("point contacts work after non-rational rotation of a one-metre panel", () => {
    double angle=17.03*Math.PI/180.0,cosine=Math.Cos(angle),sine=Math.Sin(angle);
    Path2D RotateContact(Path2D path)=>path.Select(p=>new IntPoint(
        (long)Math.Round(p.X*cosine-p.Y*sine,MidpointRounding.AwayFromZero),
        (long)Math.Round(p.X*sine+p.Y*cosine,MidpointRounding.AwayFromZero))).ToList();
    var node=LocalNode(RotateContact(IRect(0,0,1000000,1000000)),
        RotateContact(IRect(200000,200000,400000,400000)),RotateContact(IRect(400000,400000,600000,600000)));
    CheckContactRepair(node,LocalAdjust(node,800,1000),800,1000,1);
});
Test("an insufficient contact relief limit returns the exact original region", () => {
    var node=LocalNode(IRect(0,0,100000,100000),IRect(20000,20000,40000,40000),IRect(40000,40000,60000,60000));
    CheckContactFailure(node,LocalAdjust(node,800,100));
});
Test("mixed point and segment contacts are reconstructed from the union of voids", () => {
    // Keep all raw void boundaries: R8 must compose the union explicitly
    // before opening the independent genuine point contact.
    var root=new PolyTree();var node=new PolyNode();root.AddChild(node);
    node.Contour.AddRange(IRect(0,0,100000,100000));
    foreach(var path in new[]{IP(0,20000,10000,10000,20000,20000,10000,30000),
        IRect(50000,50000,60000,60000),IRect(60000,50000,70000,60000)}) {
        var hole=new PolyNode();node.AddChild(hole);
        if(Clipper.Area(path)>0)path.Reverse();hole.Contour.AddRange(path);
    }
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,1,expectRemoval:true);
});
Test("genuinely separate openings are not joined by contact handling", () => {
    var node=LocalNode(IRect(0,0,100000,100000),IRect(20000,20000,40000,40000),IRect(40500,20000,60500,40000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Factor==1.0 && LocalSame(LocalPaths(node),adjusted.Paths),"A real0.5mm gap was treated as a point contact.");
    Near(adjusted.Removed,0,0.5);
});
// R8 keeps the first 41 cases and their verifier unchanged. These fixtures
// describe material as the outer domain MINUS the UNION of raw voids.
Test("a nearly coincident fifteen-millimetre strip becomes a directed numerical notch", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),
        IP(400000,1,500000,0,1500000,1,1500000,15001,400000,15001));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,0,expectRemoval:true);
});
Test("directed numerical closure preserves an unrelated opening only one micrometre from its next support", () => {
    var independent=IRect(1500001,1000,1530001,16000);
    var node=RawVoidNode(IRect(0,0,2000000,2000000),
        IP(400000,1,500000,0,1500000,1,1500000,15001,400000,15001),independent);
    var adjusted=LocalAdjust(node,800,1000);
    CheckR8Repair(node,adjusted,800,1000,1,expectRemoval:true);
    var hole=LocalTree(adjusted.Paths).Childs.Single().Childs.Single();
    Assert(LocalSame(LocalScalePaths(R(independent),adjusted.Factor),R(hole.Contour)),
        "Numerical closure merged or moved an independent opening across a real one-micrometre gap.");
});
Test("two nearly coincident voids join only along rays incident to their original contact", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,400000,1500000,415000),
        IP(400000,415001,500000,415000,1500000,415001,1500000,430001,400000,430001));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,1,expectRemoval:true);
});
Test("a long void side shared with the exterior becomes an exact zero-loss notch", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,0,1500000,15000));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,0,expectRemoval:false);
});
Test("partially shared void sides are united without changing available material", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,400000,1000000,600000),
        IRect(700000,600000,1500000,800000));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,1,expectRemoval:false);
});
Test("overlapping raw voids use union semantics instead of parity or signed cancellation", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,400000,1100000,700000),
        IRect(700000,500000,1500000,900000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckR8Repair(node,adjusted,800,1000,1,expectRemoval:false);
    Assert(Clipper.PointInPolygon(LocalScalePoint(new IntPoint(850000,600000),adjusted.Factor),adjusted.Paths.Skip(1).Single())==1,
        "The overlap of two voids was filled or canceled.");
});
Test("duplicate raw voids never cancel their opening", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,400000,1000000,700000),
        IRect(400000,400000,1000000,700000));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,1,expectRemoval:false);
});
Test("a real ten-micrometre gap without contact remains unchanged", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,10,1500000,15010));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,1,expectRemoval:false);
});
Test("a real one-micrometre gap without contact is not treated as numerical coincidence", () => {
    var node=RawVoidNode(IRect(0,0,2000000,2000000),IRect(400000,1,1500000,15001));
    CheckR8Repair(node,LocalAdjust(node,800,1000),800,1000,1,expectRemoval:false);
});
// R9 returns one complete profile per natural owner and accepts a read-only
// geometry validator. Existing61tests above retain their original contracts.
Test("all natural owners of a transverse void are returned as separate profiles", () => {
    var node=RawVoidNode(IRect(0,0,100000,100000),IRect(40000,-1000,60000,101000));
    CheckProfilesRepair(node,ProfilesAdjust(node,800,1000),800,2,0,expectRemoval:false);
});
Test("two transverse voids return three complete natural owners", () => {
    var node=RawVoidNode(IRect(0,0,100000,100000),IRect(25000,-1000,35000,101000),
        IRect(65000,-1000,75000,101000));
    CheckProfilesRepair(node,ProfilesAdjust(node,800,1000),800,3,0,expectRemoval:false);
});
Test("natural profiles retain the independent opening in its actual owner", () => {
    var independent=IRect(10000,20000,20000,40000);
    var node=RawVoidNode(IRect(0,0,100000,100000),IRect(40000,-1000,60000,101000),independent);
    var result=ProfilesAdjust(node,800,1000);
    CheckProfilesRepair(node,result,800,2,1,expectRemoval:false);
    Assert(result.Profiles.Any(profile=>profile.Skip(1).Any(hole=>
        LocalSame(R(hole),LocalScalePaths(R(independent),result.Factor)))),
        "The opening was lost, changed or assigned to a false independent profile.");
});
Test("a read-only validator can reject a thin opening and accept a wider bounded alternative", () => {
    var node=RawVoidNode(IRect(0,0,100000,100000),IRect(20000,20000,40000,40000),
        IRect(40000,40000,60000,60000));
    int rejected=0,accepted=0;
    bool Validate(Region candidate,double factor) {
        var initial=AvailableMaterial(LocalScalePaths(LocalPaths(node),factor));
        double removed=(double)(LocalArea2(initial)-LocalArea2(candidate))/(2.0*factor*factor);
        if(removed<50000.0) {rejected++;return false;}
        accepted++;return true;
    }
    var result=ProfilesAdjust(node,800,1000,Validate);
    Assert(rejected>0 && accepted>0,"The validator was ignored or no alternative geometry was offered.");
    Assert(result.Profiles.Count==1,"A point-opening alternative split the natural owner.");
    CheckR8Repair(node,(result.Accepted,result.Profiles.Single(),result.Removed,result.Detail,result.Factor),
        800,1000,1,expectRemoval:true);
    Assert(result.Removed>=50000.0,"The returned candidate was one rejected by the read-only validator.");
});
Test("rejecting every candidate returns no profiles or partial removed area", () => {
    var node=RawVoidNode(IRect(0,0,100000,100000),IRect(20000,20000,40000,40000),
        IRect(40000,40000,60000,60000));
    int calls=0;
    var result=ProfilesAdjust(node,800,1000,(candidate,factor)=> {calls++;return false;});
    CheckProfilesFailure(result);
    Assert(calls>0 && calls<=5,"The read-only rejection was skipped or the search was not bounded.");
});
Test("failure in a later natural owner discards all previously accepted profiles", () => {
    var node=RawVoidNode(IRect(0,0,100000,100000),IRect(40000,-1000,60000,101000));
    double? acceptedCentre=null;int acceptedCalls=0,rejectedCalls=0;
    bool Validate(Region candidate,double factor) {
        double centre=candidate[0].Average(p=>p.X/factor);
        if(!acceptedCentre.HasValue)acceptedCentre=centre;
        if(Math.Abs(centre-acceptedCentre.Value)<1.0) {acceptedCalls++;return true;}
        rejectedCalls++;return false;
    }
    var result=ProfilesAdjust(node,800,1000,Validate);
    CheckProfilesFailure(result);
    Assert(acceptedCalls>0 && rejectedCalls>0,"The fixture did not exercise acceptance before a later owner failed.");
});
// R10 tests model a read-only acceptance rule for subprecision geometry. The
// rule below is not Revit's kernel and does not certify native floor creation.
Test("a rejected long numerical hairpin is normalized inside its original precision band", () => {
    var node=RawVoidNode(IP(0,0,1000000,0,1000000,1000000,2,1000000,1,1200000,0,1000000));
    int rejected=0,accepted=0;
    bool Validate(Region candidate,double factor) {
        if(HasSubprecisionInstability(candidate,factor)) {rejected++;return false;}
        accepted++;return true;
    }
    var result=ProfilesAdjust(node,800,1000,Validate);
    CheckFinalPrecisionRepair(node,result,800,1);
    Assert(rejected>0 && accepted>0,"The final-normalization fixture did not reject the initial geometry and accept a distinct result.");
    Assert(result.Profiles.All(profile=>!HasSubprecisionInstability(profile,result.Factor)),
        "An unstable hairpin was returned after final normalization.");
});
Test("a rejected one-micrometre material neck becomes two complete natural profiles", () => {
    var node=RawVoidNode(ThinMaterialNeck());
    int rejected=0,accepted=0;
    bool Validate(Region candidate,double factor) {
        if(HasSubprecisionInstability(candidate,factor)) {rejected++;return false;}
        accepted++;return true;
    }
    var result=ProfilesAdjust(node,800,1000,Validate);
    CheckFinalPrecisionRepair(node,result,800,2);
    Assert(rejected>0 && accepted>=2,"The narrow neck was not rejected before both natural pieces were accepted.");
    Assert(result.Profiles.All(profile=>!HasSubprecisionInstability(profile,result.Factor)),
        "A returned natural piece still contains the rejected subprecision instability.");
});
Test("an accepted thin neck remains unchanged without unnecessary precision fallback", () => {
    var node=RawVoidNode(ThinMaterialNeck());int calls=0;
    var result=ProfilesAdjust(node,800,1000,(candidate,factor)=> {calls++;return true;});
    CheckProfilesRepair(node,result,800,1,0,expectRemoval:false);
    Assert(calls==1,"An already accepted domain was validated again or altered unnecessarily.");
});
Test("rejecting all unstable and normalized alternatives returns an empty bounded result", () => {
    var node=RawVoidNode(ThinMaterialNeck());int calls=0;
    var result=ProfilesAdjust(node,800,1000,(candidate,factor)=> {calls++;return false;});
    CheckProfilesFailure(result);
    Assert(calls>1 && calls<=64,"Final normalization was skipped or the rejected-candidate search was not bounded.");
});
Test("a rejected fragment discards other fragments accepted by final normalization", () => {
    var node=RawVoidNode(ThinMaterialNeck());
    double? firstCentre=null;int initialRejected=0,accepted=0,fragmentRejected=0;
    bool Validate(Region candidate,double factor) {
        if(HasSubprecisionInstability(candidate,factor)) {initialRejected++;return false;}
        double centre=candidate[0].Average(p=>p.X/factor);
        if(!firstCentre.HasValue)firstCentre=centre;
        if(Math.Abs(centre-firstCentre.Value)<100000.0) {accepted++;return true;}
        fragmentRejected++;return false;
    }
    var result=ProfilesAdjust(node,800,1000,Validate);
    CheckProfilesFailure(result);
    Assert(initialRejected>0 && accepted>0 && fragmentRejected>0,
        "The fixture did not exercise an initial rejection followed by one accepted and one rejected fragment.");
});
Test("cancellation from the read-only validator propagates without retrying geometry", () => {
    var node=RawVoidNode(ThinMaterialNeck());var before=LocalPaths(node);
    int calls=0;bool cancelled=false;
    Func<Region,double,bool> validator=(candidate,factor)=> {
        calls++;
        if(calls==1)return false;
        throw new OperationCanceledException("Requested test cancellation during final normalization.");
    };
    var method=typeof(RecortePlanoExterior).GetMethod("AjustarPerfiles",
        System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Public);
    Assert(method!=null,"Natural-profile preparation is not implemented in this production version.");
    object[] args={node,800.0,1000.0,null,0.0,null,1.0,validator};
    try {method.Invoke(null,args);}
    catch(System.Reflection.TargetInvocationException ex) when(ex.InnerException is OperationCanceledException) {
        cancelled=true;
    }
    Assert(cancelled,"Cancellation was converted into profile rejection instead of being propagated.");
    Assert(calls==2,"The geometry search skipped normalization or invoked its validator again after cancellation.");
    var after=LocalPaths(node);
    Assert(before.Count==after.Count && before.Zip(after,(a,b)=>a.SequenceEqual(b)).All(x=>x),
        "Cancellation mutated the original face or its openings.");
});
Console.WriteLine($"Passed: {passed}; failed: {failed}; total: {passed+failed}");
Console.WriteLine("Production planar set operations and height rules only; no Revit runtime or model execution.");
return failed==0?0:1;

Path2D P(params double[] xy) { var p=new Path2D();for(int i=0;i<xy.Length;i+=2)p.Add(new IntPoint((long)Math.Round(xy[i]*S),(long)Math.Round(xy[i+1]*S)));return p; }
Path2D Rect(double x0,double y0,double x1,double y1)=>P(x0,y0,x1,y0,x1,y1,x0,y1);
Region R(params Path2D[] paths)=>paths.ToList();
PolyTree Cut(Path2D face,params Region[] obstacles)=>RecortePlanoExterior.Restar(R(face),obstacles);
IEnumerable<Path2D> Contours(PolyTree tree) { for(var n=tree.GetFirst();n!=null;n=n.GetNext())yield return n.Contour; }
void Check(PolyTree tree,double area,int regions,int holes,int? vertices=null) {
    var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Near(nodes.Sum(n=>Clipper.Area(n.Contour))/(S*S),area,1e-7);
    Assert(nodes.Count(n=>!n.IsHole)==regions,$"regions={nodes.Count(n=>!n.IsHole)} expected={regions}");
    Assert(nodes.Count(n=>n.IsHole)==holes,$"holes={nodes.Count(n=>n.IsHole)} expected={holes}");
    if(vertices.HasValue)Assert(nodes.Where(n=>!n.IsHole).All(n=>RecortePlanoExterior.QuitarColineales(n.Contour).Count==vertices),"Unexpected artificial edges.");
}
void Near(double actual,double expected,double tolerance=1e-9)=>Assert(Math.Abs(actual-expected)<=tolerance,$"actual={actual:G17}, expected={expected:G17}");
void Assert(bool condition,string message) { if(!condition)throw new InvalidOperationException(message); }
void Test(string name,Action test) { try{test();passed++;Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+": "+e.Message);} }

bool HasNumericalBacktrack(PolyTree tree) {
    foreach(var p in Contours(tree)) for(int i=0;i<p.Count;i++) {
        var a=p[(i+p.Count-1)%p.Count];var b=p[i];var c=p[(i+1)%p.Count];
        double x=(double)c.X-a.X,y=(double)c.Y-a.Y;
        double cross=((double)b.X-a.X)*y-((double)b.Y-a.Y)*x;
        double dot=((double)b.X-a.X)*((double)c.X-b.X)+((double)b.Y-a.Y)*((double)c.Y-b.Y);
        if(dot<0 && Math.Abs(cross)/Math.Max(1,Math.Sqrt(x*x+y*y))<=2) return true;
    }
    return false;
}

// Integer-grid helpers below verify the production result with independent
// Clipper differences, topology checks and a local capsule around SHORT edges.
Path2D IP(params long[] xy) { var p=new Path2D();for(int i=0;i<xy.Length;i+=2)p.Add(new IntPoint(xy[i],xy[i+1]));return p; }
Path2D IRect(long x0,long y0,long x1,long y1)=>IP(x0,y0,x1,y0,x1,y1,x0,y1);
PolyNode LocalNode(Path2D outer,params Path2D[] holes) {
    var all=R(outer);all.AddRange(holes);
    var clipper=new Clipper {StrictlySimple=true};clipper.AddPaths(all,PolyType.ptSubject,true);
    var tree=new PolyTree();Assert(clipper.Execute(ClipType.ctUnion,tree,PolyFillType.pftEvenOdd,PolyFillType.pftEvenOdd),"Could not build test region.");
    Assert(tree.Childs.Count==1,"Test requires one owner.");return tree.Childs[0];
}
PolyNode LocalRawNode(Path2D outer) { var root=new PolyTree();var node=new PolyNode();root.AddChild(node);node.Contour.AddRange(outer);return node; }
Region LocalPaths(PolyNode node)=>new Region {new Path2D(node.Contour)}.Concat(node.Childs.Where(c=>c.IsHole).Select(c=>new Path2D(c.Contour))).ToList();
PolyTree LocalTree(Region paths) {
    var motor=new Clipper {StrictlySimple=true};motor.AddPaths(paths,PolyType.ptSubject,true);
    var tree=new PolyTree();Assert(motor.Execute(ClipType.ctUnion,tree,PolyFillType.pftNonZero,PolyFillType.pftNonZero),"Could not read adjusted domain.");return tree;
}
(bool Accepted,Region Paths,double Removed,string Detail,double Factor) LocalAdjust(PolyNode node,double minimum,double limit) {
    var method=typeof(RecortePlanoExterior).GetMethod("AjustarAristasCortas",
        System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Public);
    Assert(method!=null,"Conservative local adjustment is not implemented in this production version.");
    var before=LocalPaths(node);object[] args={node,minimum,limit,null,0.0,null,1.0};
    bool accepted;
    try { accepted=(bool)method.Invoke(null,args); }
    catch(System.Reflection.TargetInvocationException ex) when(ex.InnerException!=null) {
        throw new InvalidOperationException("Production repair threw: "+ex.InnerException.Message,ex.InnerException);
    }
    Assert(before.Count==LocalPaths(node).Count && before.Zip(LocalPaths(node),(a,b)=>a.SequenceEqual(b)).All(x=>x),
        "The repair operation mutated its input region.");
    var paths=args[3] as Region;Assert(paths!=null,"Repair did not return a domain.");
    return (accepted,paths,(double)args[4],args[5] as string??"",(double)args[6]);
}
void CheckLocalRepair(PolyNode original,(bool Accepted,Region Paths,double Removed,string Detail,double Factor) result,double minimum,double limit) {
    Assert(result.Accepted,"Repair failed: "+result.Detail);
    double factor=result.Factor;
    Assert(double.IsFinite(factor) && factor>=1.0 && factor<=1000000.0 && factor==Math.Floor(factor),
        "The repair returned an invalid coordinate refinement factor.");
    var before=LocalScalePaths(LocalPaths(original),factor);var after=result.Paths;
    double scaledMinimum=minimum*factor,scaledLimit=limit*factor;
    Assert(after.Count>0,"Repair erased the panel.");
    Assert(LocalArea2(R(after[0])).Sign>0 && after.Skip(1).All(p=>LocalArea2(R(p)).Sign<0),
        "Returned contours must list the positive outer ring first and negative openings afterwards.");
    Assert(!LocalDifferenceHasArea(after,before),"Repair added material inside an interference.");
    var tree=LocalTree(after);var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Assert(nodes.Count(n=>!n.IsHole)==1,"Repair split the owner into separate panels.");
    Assert(nodes.Count(n=>n.IsHole)==original.Childs.Count(n=>n.IsHole),"Repair changed the number of openings.");
    foreach(var path in after) {
        Assert(path.Count>=3,"An adjusted ring is degenerate.");
        for(int i=0;i<path.Count;i++) {
            var a=path[i];var b=path[(i+1)%path.Count];
            Assert(LocalLength(a,b)+1e-7*factor>=scaledMinimum,"A short edge survived in the accepted repair.");
            var c=path[(i+2)%path.Count];
            if(LocalOrientation(a,b,c)==0) {
                System.Numerics.BigInteger abx=(System.Numerics.BigInteger)b.X-a.X,aby=(System.Numerics.BigInteger)b.Y-a.Y;
                System.Numerics.BigInteger bcx=(System.Numerics.BigInteger)c.X-b.X,bcy=(System.Numerics.BigInteger)c.Y-b.Y;
                Assert(abx*bcx+aby*bcy>=0,"An adjacent overlapping reversal survived.");
            }
            for(int j=i+1;j<path.Count;j++) {
                if(j==i+1||i==0&&j==path.Count-1)continue;
                Assert(!LocalSegmentsTouch(a,b,path[j],path[(j+1)%path.Count]),"An adjusted ring crosses or touches itself.");
            }
        }
    }
    for(int i=0;i<after.Count;i++)for(int j=i+1;j<after.Count;j++)
        for(int a=0;a<after[i].Count;a++)for(int b=0;b<after[j].Count;b++)
            Assert(!LocalSegmentsTouch(after[i][a],after[i][(a+1)%after[i].Count],after[j][b],after[j][(b+1)%after[j].Count]),"Adjusted rings cross or touch.");
    var twiceRemoved=LocalArea2(before)-LocalArea2(after);
    Assert(twiceRemoved.Sign>=0,"The adjusted domain gained exact integer area.");
    double removedInBaseUnits=(double)twiceRemoved/(2.0*factor*factor);
    Assert(result.Removed>=-0.5,"Removed area was reported with the wrong sign.");
    Near(result.Removed,removedInBaseUnits,2.0);
    var shortEdges=new Region();
    foreach(var path in before)for(int i=0;i<path.Count;i++)
        if(LocalLength(path[i],path[(i+1)%path.Count])<scaledMinimum)
            shortEdges.Add(new Path2D {path[i],path[(i+1)%path.Count]});
    var removed=LocalDifference(before,after);
    if(shortEdges.Count==0) Assert(removed.Count==0,"A valid panel changed without a short edge.");
    else {
        // Keep the verifier's arc error fixed in physical units as coordinates
        // are refined; a default 0.25 at factor1e6 would create huge capsules.
        var buffer=new ClipperOffset(2.0,0.25*factor);
        buffer.AddPaths(shortEdges,JoinType.jtRound,EndType.etOpenRound);
        var allowed=new Region();buffer.Execute(ref allowed,scaledLimit);
        Assert(!LocalDifferenceHasArea(removed,allowed),"Repair removed material away from the short-edge encounter.");
    }
}
Region LocalDifference(Region subject,Region clip) {
    var paths=new Region();if(subject.Count==0)return paths;
    var motor=new Clipper {StrictlySimple=true};motor.AddPaths(subject,PolyType.ptSubject,true);
    if(clip.Count>0)motor.AddPaths(clip,PolyType.ptClip,true);
    Assert(motor.Execute(ClipType.ctDifference,paths,PolyFillType.pftNonZero,PolyFillType.pftNonZero),"Geometry comparison failed.");return paths;
}
bool LocalDifferenceHasArea(Region subject,Region clip)=>LocalDifference(subject,clip).Any(p=>!LocalArea2(R(p)).IsZero);
bool LocalSame(Region a,Region b)=>!LocalDifferenceHasArea(a,b)&&!LocalDifferenceHasArea(b,a);
double LocalLength(IntPoint a,IntPoint b)=>Math.Sqrt(Math.Pow((double)b.X-a.X,2)+Math.Pow((double)b.Y-a.Y,2));
int LocalOrientation(IntPoint a,IntPoint b,IntPoint c)=>(((System.Numerics.BigInteger)b.X-a.X)*((System.Numerics.BigInteger)c.Y-a.Y)-((System.Numerics.BigInteger)b.Y-a.Y)*((System.Numerics.BigInteger)c.X-a.X)).Sign;
bool LocalOnSegment(IntPoint p,IntPoint a,IntPoint b)=>p.X>=Math.Min(a.X,b.X)&&p.X<=Math.Max(a.X,b.X)&&p.Y>=Math.Min(a.Y,b.Y)&&p.Y<=Math.Max(a.Y,b.Y);
bool LocalSegmentsTouch(IntPoint a,IntPoint b,IntPoint c,IntPoint d) {
    int x=LocalOrientation(a,b,c),y=LocalOrientation(a,b,d),z=LocalOrientation(c,d,a),w=LocalOrientation(c,d,b);
    return x*y<0&&z*w<0 || x==0&&LocalOnSegment(c,a,b) || y==0&&LocalOnSegment(d,a,b) || z==0&&LocalOnSegment(a,c,d) || w==0&&LocalOnSegment(b,c,d);
}

IntPoint LocalScalePoint(IntPoint point,double factor)=>new IntPoint(checked(point.X*(long)factor),checked(point.Y*(long)factor));
Region LocalScalePaths(Region paths,double factor)=>paths.Select(path=>path.Select(p=>LocalScalePoint(p,factor)).ToList()).ToList();
System.Numerics.BigInteger LocalArea2(Region paths) {
    System.Numerics.BigInteger sum=0;
    foreach(var path in paths)for(int i=0;i<path.Count;i++) {
        var a=path[i];var b=path[(i+1)%path.Count];
        sum+=(System.Numerics.BigInteger)a.X*b.Y-(System.Numerics.BigInteger)b.X*a.Y;
    }
    return sum;
}


// This verifier is separate from CheckLocalRepair: only proven point contacts
// justify the expected topology change. It never relaxes R6's original checks.
void CheckContactRepair(PolyNode original,(bool Accepted,Region Paths,double Removed,string Detail,double Factor) result,
    double minimum,double limit,int expectedHoles) {
    Assert(result.Accepted,"Contact repair failed: "+result.Detail);
    double factor=result.Factor;
    Assert(double.IsFinite(factor) && factor>=1.0 && factor<=1000000.0 && factor==Math.Floor(factor),"Invalid contact refinement factor.");
    var originalPaths=LocalPaths(original);var contacts=ContactPoints(originalPaths);
    Assert(contacts.Count>0,"Contact fixture has no exact point contact.");
    var before=LocalScalePaths(originalPaths,factor);var after=result.Paths;
    Assert(after.Count>0,"Contact repair erased the owner.");
    Assert(LocalArea2(R(after[0])).Sign>0 && after.Skip(1).All(p=>LocalArea2(R(p)).Sign<0),"Contact output ring orientations or order are invalid.");
    Assert(!LocalDifferenceHasArea(after,before),"Contact repair added material inside an existing void.");
    var tree=LocalTree(after);var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Assert(nodes.Count(n=>!n.IsHole)==1,"Contact repair split the owner.");
    Assert(nodes.Count(n=>n.IsHole)==expectedHoles,"Contact repair changed unrelated topology.");
    foreach(var path in after) {
        Assert(path.Count>=3,"Contact repair produced a degenerate ring.");
        for(int i=0;i<path.Count;i++) {
            var a=path[i];var b=path[(i+1)%path.Count];var c=path[(i+2)%path.Count];
            Assert(LocalLength(a,b)>minimum*factor,"Contact repair left an edge at or below the creation minimum.");
            if(LocalOrientation(a,b,c)==0) {
                System.Numerics.BigInteger abx=(System.Numerics.BigInteger)b.X-a.X,aby=(System.Numerics.BigInteger)b.Y-a.Y;
                System.Numerics.BigInteger bcx=(System.Numerics.BigInteger)c.X-b.X,bcy=(System.Numerics.BigInteger)c.Y-b.Y;
                Assert(abx*bcx+aby*bcy>=0,"Contact repair left an adjacent overlap/reversal.");
            }
            for(int j=i+1;j<path.Count;j++) {
                if(j==i+1||i==0&&j==path.Count-1)continue;
                Assert(!LocalSegmentsTouch(a,b,path[j],path[(j+1)%path.Count]),"Contact output ring crosses or touches itself.");
            }
        }
    }
    for(int i=0;i<after.Count;i++)for(int j=i+1;j<after.Count;j++)
        for(int a=0;a<after[i].Count;a++)for(int b=0;b<after[j].Count;b++)
            Assert(!LocalSegmentsTouch(after[i][a],after[i][(a+1)%after[i].Count],after[j][b],after[j][(b+1)%after[j].Count]),"Contact output rings still touch or cross.");
    var area2=LocalArea2(before)-LocalArea2(after);
    Assert(area2.Sign>0 && result.Removed>0,"A proven point contact was accepted without removing any material.");
    Near(result.Removed,(double)area2/(2.0*factor*factor),2.0);
    var buffer=new ClipperOffset(2.0,0.25*factor);
    foreach(var point in contacts) buffer.AddPath(new Path2D{LocalScalePoint(point,factor)},JoinType.jtRound,EndType.etOpenRound);
    foreach(var path in before)for(int i=0;i<path.Count;i++)
        if(LocalLength(path[i],path[(i+1)%path.Count])<=minimum*factor)
            buffer.AddPath(new Path2D{path[i],path[(i+1)%path.Count]},JoinType.jtRound,EndType.etOpenRound);
    var allowed=new Region();buffer.Execute(ref allowed,limit*factor);
    Assert(!LocalDifferenceHasArea(LocalDifference(before,after),allowed),
        "Contact repair removed material outside original contact disks and original short-edge capsules.");
}
List<IntPoint> ContactPoints(Region paths) {
    var contacts=new List<IntPoint>();
    for(int i=0;i<paths.Count;i++)for(int j=i+1;j<paths.Count;j++) {
        void Collect(Path2D vertices,Path2D edges) {
            foreach(var p in vertices)for(int k=0;k<edges.Count;k++)
                if(LocalOrientation(edges[k],edges[(k+1)%edges.Count],p)==0 && LocalOnSegment(p,edges[k],edges[(k+1)%edges.Count]))
                    if(!contacts.Contains(p))contacts.Add(p);
        }
        Collect(paths[i],paths[j]);Collect(paths[j],paths[i]);
    }
    return contacts;
}
void CheckContactFailure(PolyNode original,(bool Accepted,Region Paths,double Removed,string Detail,double Factor) result) {
    Assert(!result.Accepted,"An unsupported contact was accepted.");
    Assert(result.Factor==1.0,"A failed contact repair kept a refined coordinate scale.");
    var before=LocalPaths(original);
    Assert(before.Count==result.Paths.Count && before.Zip(result.Paths,(a,b)=>a.SequenceEqual(b)).All(x=>x),"A failed contact repair leaked provisional contour edits.");
    Near(result.Removed,0,0.0);
}


// Independent R8 verifier. It does not call a production normalizer, contact
// classifier or precision helper, and leaves CheckLocalRepair unchanged.
PolyNode RawVoidNode(Path2D outer,params Path2D[] holes) {
    var root=new PolyTree();var owner=new PolyNode();root.AddChild(owner);
    var perimeter=new Path2D(outer);if(Clipper.Area(perimeter)<0)perimeter.Reverse();owner.Contour.AddRange(perimeter);
    foreach(var source in holes) {
        var hole=new PolyNode();owner.AddChild(hole);var ring=new Path2D(source);
        if(Clipper.Area(ring)>0)ring.Reverse();hole.Contour.AddRange(ring);
    }
    return owner;
}
Region AvailableMaterial(Region raw) {
    Assert(raw.Count>0,"Raw material fixture has no outer ring.");
    var outer=new Path2D(raw[0]);if(Clipper.Area(outer)<0)outer.Reverse();
    var voids=raw.Skip(1).Select(p=> {var q=new Path2D(p);if(Clipper.Area(q)<0)q.Reverse();return q;}).ToList();
    var united=new Region();
    if(voids.Count>0) {
        var union=new Clipper{StrictlySimple=true};union.AddPaths(voids,PolyType.ptSubject,true);
        Assert(union.Execute(ClipType.ctUnion,united,PolyFillType.pftNonZero,PolyFillType.pftNonZero),"Could not unite fixture voids.");
    }
    return LocalDifference(R(outer),united);
}
void CheckR8Repair(PolyNode original,(bool Accepted,Region Paths,double Removed,string Detail,double Factor) result,
    double minimum,double limit,int expectedHoles,bool expectRemoval) {
    Assert(result.Accepted,"R8 reconstruction failed: "+result.Detail);
    double factor=result.Factor;
    Assert(double.IsFinite(factor) && factor>=1 && factor<=1000000 && factor==Math.Floor(factor),"Invalid R8 refinement factor.");
    var raw=LocalPaths(original);var before=AvailableMaterial(LocalScalePaths(raw,factor));var after=result.Paths;
    Assert(after.Count>0,"R8 reconstruction erased the owner.");
    Assert(LocalArea2(R(after[0])).Sign>0 && after.Skip(1).All(p=>LocalArea2(R(p)).Sign<0),"R8 output orientation/order is invalid.");
    Assert(!LocalDifferenceHasArea(after,before),"R8 reconstruction added material inside an original void.");
    var tree=LocalTree(after);var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Assert(nodes.Count(n=>!n.IsHole)==1,"R8 reconstruction split the owner.");
    Assert(nodes.Count(n=>n.IsHole)==expectedHoles,"R8 reconstruction changed independent void topology.");
    foreach(var path in after) {
        Assert(path.Count>=3,"R8 output contains a degenerate ring.");
        for(int i=0;i<path.Count;i++) {
            var a=path[i];var b=path[(i+1)%path.Count];var c=path[(i+2)%path.Count];
            Assert(LocalLength(a,b)>minimum*factor,"R8 output retains an edge below the creation minimum.");
            if(LocalOrientation(a,b,c)==0) {
                System.Numerics.BigInteger x=(System.Numerics.BigInteger)b.X-a.X,y=(System.Numerics.BigInteger)b.Y-a.Y;
                Assert(x*((System.Numerics.BigInteger)c.X-b.X)+y*((System.Numerics.BigInteger)c.Y-b.Y)>=0,"R8 output retains adjacent overlap.");
            }
            for(int j=i+1;j<path.Count;j++) {
                if(j==i+1||i==0&&j==path.Count-1)continue;
                Assert(!LocalSegmentsTouch(a,b,path[j],path[(j+1)%path.Count]),"R8 output ring crosses or touches itself.");
            }
        }
    }
    for(int i=0;i<after.Count;i++)for(int j=i+1;j<after.Count;j++)
        for(int a=0;a<after[i].Count;a++)for(int b=0;b<after[j].Count;b++)
            Assert(!LocalSegmentsTouch(after[i][a],after[i][(a+1)%after[i].Count],after[j][b],after[j][(b+1)%after[j].Count]),"R8 output rings cross or touch.");
    var twiceRemoved=LocalArea2(before)-LocalArea2(after);
    Assert(twiceRemoved.Sign>=0,"R8 output gained exact integer area.");
    Near(result.Removed,(double)twiceRemoved/(2.0*factor*factor),2.0);
    if(expectRemoval) Assert(twiceRemoved.Sign>0 && result.Removed>0,"Expected a conservative contact repair with positive area removal.");
    else {
        Assert(LocalSame(before,after),"A pure reconstruction or real non-contact gap changed available material.");
        Near(result.Removed,0,0.0);
    }
    var allowed=new Region();var pointBuffer=new ClipperOffset(2.0,0.25*factor);
    foreach(var contact in ContactPoints(raw)) {
        var numerical=NumericalContactSupports(raw,contact,minimum);
        pointBuffer.AddPath(new Path2D{LocalScalePoint(contact,factor)},JoinType.jtRound,EndType.etOpenRound);
        if(numerical.Count>0) {
            var precisionBuffer=new ClipperOffset(2.0,0.25*factor);
            precisionBuffer.AddPaths(LocalScalePaths(numerical,factor),JoinType.jtRound,EndType.etOpenRound);
            var precisionAllowed=new Region();precisionBuffer.Execute(ref precisionAllowed,3.0*factor);allowed.AddRange(precisionAllowed);
        }
    }
    foreach(var path in raw)for(int i=0;i<path.Count;i++)
        if(LocalLength(path[i],path[(i+1)%path.Count])<=minimum)
            pointBuffer.AddPath(new Path2D{LocalScalePoint(path[i],factor),LocalScalePoint(path[(i+1)%path.Count],factor)},JoinType.jtRound,EndType.etOpenRound);
    var pointAllowed=new Region();pointBuffer.Execute(ref pointAllowed,limit*factor);allowed.AddRange(pointAllowed);
    Assert(!LocalDifferenceHasArea(LocalDifference(before,after),allowed),
        "R8 removal exceeds directed3micrometre incident-ray bands or original true-contact/short-edge neighbourhoods.");
}
Region NumericalContactSupports(Region paths,IntPoint contact,double minimum) {
    var rays=new List<(int Ring,IntPoint End)>();
    for(int r=0;r<paths.Count;r++)for(int i=0;i<paths[r].Count;i++) {
        var a=paths[r][i];var b=paths[r][(i+1)%paths[r].Count];
        if(LocalOrientation(a,b,contact)!=0 || !LocalOnSegment(contact,a,b))continue;
        if(a!=contact)rays.Add((r,a));if(b!=contact)rays.Add((r,b));
    }
    var numericalRings=new HashSet<int>();var closingSupports=new Region();
    for(int i=0;i<rays.Count;i++)for(int j=i+1;j<rays.Count;j++) {
        if(rays[i].Ring==rays[j].Ring)continue;
        var a=rays[i].End;var b=rays[j].End;
        double ax=(double)a.X-contact.X,ay=(double)a.Y-contact.Y,bx=(double)b.X-contact.X,by=(double)b.Y-contact.Y;
        double al=Math.Sqrt(ax*ax+ay*ay),bl=Math.Sqrt(bx*bx+by*by);
        if(Math.Min(al,bl)<=minimum || ax*bx+ay*by<=0)continue;
        double distance=Math.Abs(ax*by-ay*bx)/Math.Max(al,bl);
        if(distance>3.0)continue;
        numericalRings.Add(rays[i].Ring);numericalRings.Add(rays[j].Ring);
        var smaller=al<=bl?rays[i]:rays[j];var larger=al<=bl?rays[j]:rays[i];
        var ring=paths[smaller.Ring];var endpoint=smaller.End;
        for(int k=0;k<ring.Count;k++)if(ring[k]==endpoint) {
            foreach(var next in new[]{ring[(k+ring.Count-1)%ring.Count],ring[(k+1)%ring.Count]}) {
                if(LocalOrientation(endpoint,next,contact)==0 && LocalOnSegment(contact,endpoint,next))continue;
                double ux=(double)larger.End.X-contact.X,uy=(double)larger.End.Y-contact.Y;
                double vx=(double)next.X-endpoint.X,vy=(double)next.Y-endpoint.Y;
                double denominator=ux*vy-uy*vx;
                if(Math.Abs(denominator)<=1e-12*LocalLength(contact,larger.End)*LocalLength(endpoint,next))continue;
                double parameter=(((double)endpoint.X-contact.X)*vy-((double)endpoint.Y-contact.Y)*vx)/denominator;
                double qx=contact.X+parameter*ux,qy=contact.Y+parameter*uy;
                if(Math.Sqrt(Math.Pow(qx-endpoint.X,2)+Math.Pow(qy-endpoint.Y,2))<=3.0)
                    closingSupports.Add(new Path2D{endpoint,next});
            }
        }
    }
    // Every allowance stays anchored to an original segment. The next side at
    // the shorter endpoint qualifies only when its support closes within3µm;
    // no new or iteratively moved endpoint may authorize a larger neighbourhood.
    var supports=rays.Where(ray=>numericalRings.Contains(ray.Ring))
        .Select(ray=>new Path2D{contact,ray.End}).ToList();
    supports.AddRange(closingSupports);return supports;
}


// R9 API exercised through reflection so the same suite can demonstrate the
// missing operation against an unchanged R8 snapshot without copying its code.
(bool Accepted,List<Region> Profiles,double Removed,string Detail,double Factor) ProfilesAdjust(
    PolyNode node,double minimum,double limit,Func<Region,double,bool> validator=null) {
    var method=typeof(RecortePlanoExterior).GetMethod("AjustarPerfiles",
        System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Public);
    Assert(method!=null,"Natural-profile preparation with a read-only validator is not implemented in this production version.");
    var before=LocalPaths(node);object[] args={node,minimum,limit,null,0.0,null,1.0,validator};
    bool accepted;
    try {accepted=(bool)method.Invoke(null,args);}
    catch(System.Reflection.TargetInvocationException ex) when(ex.InnerException!=null) {
        throw new InvalidOperationException("Profile preparation threw: "+ex.InnerException.Message,ex.InnerException);
    }
    var unchanged=LocalPaths(node);
    Assert(before.Count==unchanged.Count && before.Zip(unchanged,(a,b)=>a.SequenceEqual(b)).All(x=>x),
        "Preparing natural profiles mutated the source face or voids.");
    var profiles=args[3] as List<Region>;Assert(profiles!=null,"Profile preparation did not return a result collection.");
    return (accepted,profiles,(double)args[4],args[5] as string??"",(double)args[6]);
}
void CheckProfilesFailure((bool Accepted,List<Region> Profiles,double Removed,string Detail,double Factor) result) {
    Assert(!result.Accepted,"A rejected natural profile was accepted.");
    Assert(result.Profiles.Count==0,"Failure leaked some previously accepted profiles.");
    Assert(result.Factor==1.0,"Failure leaked a refined coordinate scale.");
    Near(result.Removed,0,0.0);
}
void CheckProfilesRepair(PolyNode original,
    (bool Accepted,List<Region> Profiles,double Removed,string Detail,double Factor) result,
    double minimum,int expectedOwners,int expectedHoles,bool expectRemoval) {
    Assert(result.Accepted,"Natural-profile preparation failed: "+result.Detail);
    double factor=result.Factor;
    Assert(double.IsFinite(factor) && factor>=1 && factor<=1000000 && factor==Math.Floor(factor),
        "Natural profiles returned an invalid common coordinate factor.");
    Assert(result.Profiles.Count==expectedOwners,"Natural owners were lost or artificially subdivided.");
    var raw=LocalScalePaths(LocalPaths(original),factor);var before=AvailableMaterial(raw);
    var after=result.Profiles.SelectMany(profile=>profile).ToList();
    Assert(!LocalDifferenceHasArea(after,before),"Natural profiles added material inside a real interference.");
    int holes=0;
    for(int owner=0;owner<result.Profiles.Count;owner++) {
        var profile=result.Profiles[owner];
        Assert(profile.Count>0 && LocalArea2(R(profile[0])).Sign>0 &&
            profile.Skip(1).All(p=>LocalArea2(R(p)).Sign<0),"Profile boundaries have incorrect ownership or orientation.");
        var tree=LocalTree(profile);var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
        Assert(nodes.Count(n=>!n.IsHole)==1,"Multiple outer rings were flattened into one floor profile.");
        Assert(nodes.Count(n=>n.IsHole)==profile.Count-1,"A profile retained an unowned or incorrectly nested opening.");
        holes+=nodes.Count(n=>n.IsHole);
        foreach(var path in profile) {
            Assert(path.Count>=3,"A natural profile contains a degenerate boundary.");
            for(int i=0;i<path.Count;i++) {
                var a=path[i];var b=path[(i+1)%path.Count];var c=path[(i+2)%path.Count];
                Assert(LocalLength(a,b)>minimum*factor,"A natural profile retains an uncreatable short edge.");
                if(LocalOrientation(a,b,c)==0) {
                    System.Numerics.BigInteger x=(System.Numerics.BigInteger)b.X-a.X,y=(System.Numerics.BigInteger)b.Y-a.Y;
                    Assert(x*((System.Numerics.BigInteger)c.X-b.X)+y*((System.Numerics.BigInteger)c.Y-b.Y)>=0,
                        "A natural profile retains an overlapping reversal.");
                }
                for(int j=i+1;j<path.Count;j++) {
                    if(j==i+1||i==0&&j==path.Count-1)continue;
                    Assert(!LocalSegmentsTouch(a,b,path[j],path[(j+1)%path.Count]),"A natural boundary crosses or touches itself.");
                }
            }
        }
        for(int i=0;i<profile.Count;i++)for(int j=i+1;j<profile.Count;j++)
            for(int a=0;a<profile[i].Count;a++)for(int b=0;b<profile[j].Count;b++)
                Assert(!LocalSegmentsTouch(profile[i][a],profile[i][(a+1)%profile[i].Count],
                    profile[j][b],profile[j][(b+1)%profile[j].Count]),"Outer and inner boundaries still touch.");
        for(int other=owner+1;other<result.Profiles.Count;other++) {
            var intersection=new Region();var clipper=new Clipper{StrictlySimple=true};
            clipper.AddPaths(profile,PolyType.ptSubject,true);clipper.AddPaths(result.Profiles[other],PolyType.ptClip,true);
            Assert(clipper.Execute(ClipType.ctIntersection,intersection,PolyFillType.pftNonZero,PolyFillType.pftNonZero),
                "Could not compare the material in two returned profiles.");
            Assert(intersection.All(p=>LocalArea2(R(p)).IsZero),"Two natural floor profiles overlap and double-count area.");
        }
    }
    Assert(holes==expectedHoles,"An independent opening was lost or assigned to a false region.");
    var area2=LocalArea2(before)-LocalArea2(after);
    Assert(area2.Sign>=0,"Natural profile output gained exact integer area.");
    Near(result.Removed,(double)area2/(2.0*factor*factor),2.0);
    if(expectRemoval)Assert(area2.Sign>0,"An intended local repair did not remove its requested material.");
    else {
        Assert(LocalSame(before,after),"Recomposing natural regions changed the actual available material.");
        Near(result.Removed,0,0.0);
    }
}

// Two metre-scale rectangles linked by a one-cell (0.001mm) strip. Every
// original edge is long; the defect is separation between non-adjacent edges.
Path2D ThinMaterialNeck()=>IP(0,0,1000000,0,1000000,500000,2000000,500000,
    2000000,0,3000000,0,3000000,1000000,2000000,1000000,
    2000000,500001,1000000,500001,1000000,1000000,0,1000000);

bool HasSubprecisionInstability(Region paths,double factor) {
    double close=1.5*factor;
    foreach(var path in paths)for(int i=0;i<path.Count;i++) {
        var a=path[i];var b=path[(i+1)%path.Count];var c=path[(i+2)%path.Count];
        double abx=(double)b.X-a.X,aby=(double)b.Y-a.Y;
        double bcx=(double)c.X-b.X,bcy=(double)c.Y-b.Y;
        if(abx*bcx+aby*bcy<0.0) {
            double cross=Math.Abs(abx*bcy-aby*bcx);
            if(cross/Math.Max(LocalLength(a,b),LocalLength(b,c))<=3.0*factor)return true;
        }
    }
    for(int r=0;r<paths.Count;r++)for(int s=r;s<paths.Count;s++)
        for(int i=0;i<paths[r].Count;i++)for(int j=0;j<paths[s].Count;j++) {
            if(r==s && (j<=i || j==i+1 || i==0&&j==paths[r].Count-1))continue;
            var a=paths[r][i];var b=paths[r][(i+1)%paths[r].Count];
            var c=paths[s][j];var d=paths[s][(j+1)%paths[s].Count];
            if(LocalSegmentsTouch(a,b,c,d) ||
                Math.Min(Math.Min(PointSegmentDistance(a,c,d),PointSegmentDistance(b,c,d)),
                    Math.Min(PointSegmentDistance(c,a,b),PointSegmentDistance(d,a,b)))<=close)return true;
        }
    return false;
}
double PointSegmentDistance(IntPoint point,IntPoint a,IntPoint b) {
    double x=(double)b.X-a.X,y=(double)b.Y-a.Y;
    double length2=x*x+y*y;
    if(length2==0.0)return LocalLength(point,a);
    double t=(((double)point.X-a.X)*x+((double)point.Y-a.Y)*y)/length2;
    t=Math.Max(0.0,Math.Min(1.0,t));
    double dx=(double)point.X-a.X-t*x,dy=(double)point.Y-a.Y-t*y;
    return Math.Sqrt(dx*dx+dy*dy);
}
void CheckFinalPrecisionRepair(PolyNode original,
    (bool Accepted,List<Region> Profiles,double Removed,string Detail,double Factor) result,
    double minimum,int expectedOwners) {
    CheckProfilesRepair(original,result,minimum,expectedOwners,0,expectRemoval:true);
    double factor=result.Factor;
    var before=AvailableMaterial(LocalScalePaths(LocalPaths(original),factor));
    var after=result.Profiles.SelectMany(profile=>profile).ToList();
    var offset=new ClipperOffset(2.0,0.0025*factor);
    foreach(var path in before)for(int i=0;i<path.Count;i++)
        offset.AddPath(new Path2D{path[i],path[(i+1)%path.Count]},JoinType.jtRound,EndType.etOpenRound);
    var permitted=new Region();offset.Execute(ref permitted,3.0*factor);
    Assert(!LocalDifferenceHasArea(LocalDifference(before,after),permitted),
        "Final normalization removed material outside the fixed original3micrometre boundary band.");
}
