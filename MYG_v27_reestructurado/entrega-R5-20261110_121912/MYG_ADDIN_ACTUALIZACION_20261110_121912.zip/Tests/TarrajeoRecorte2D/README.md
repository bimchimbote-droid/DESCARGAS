# Pruebas del motor de bocetos exteriores R5 (base R4)

Desde la raíz del repositorio, con SDK .NET 10:

```bash
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj
```

El proyecto compila los archivos reales `RecortePlanoExterior.cs`, `Clipper.cs` y `TarrajeoAlturas.cs` mediante enlaces al código de producción. No copia algoritmos, no extrae métodos retirados y no simula el kernel de Revit. No necesita paquetes nuevos.

La suite anterior de recuperación por franjas se sustituye porque esa estrategia se retiró del flujo de suelos y del recorte planar de muros. `HarnessCases.cs` queda obsoleto y puede eliminarse; el proyecto lo excluye también si se conserva por error.

Los 25 casos base de R4 comprueban: rectángulo sin interferencias, muesca parcial, hueco interior, corte transversal con dos regiones reales, cobertura total, obstáculo externo, superficies duplicadas, obstáculos solapados, triangulación de rectángulos sin diagonales finales, triángulos finos sin ensanchamiento, huecos originales, huecos en un obstáculo, islas, orientación inversa, rectángulos rotados, separaciones reales, colineales redundantes, equivalencia de dominios y contacto/alturas exteriores arriba y abajo.

Resultado de la base R4 ejecutado con SDK 10.0.403: **25/25 pasan**, salida 0. Son pruebas del nuevo motor y no los 25 casos antiguos de franjas. La compilación semántica del motor completo contra los metadatos reales de Revit incluidos también pasó (C# 7.3); la proyección, recorte 3D con planos, visibilidad y creación de elementos requieren comprobarse dentro de Revit.

La compilación completa del add-in Linux sigue bloqueada por MSB4803/COM, antes de producir una DLL. Estas pruebas no acreditan que el modelo particular del usuario ya funcione ni ejecutan Floor.Create, Transaction, CustomExporter o SlabShapeEditor.

## Revisión R5: precisión del contorno

Se mantienen los 25 casos de R4 y se añaden seis regresiones: retroceso casi colineal, dos residuos triangulares largos de anchura inferior a una micra, conservación de un bisel real de 0.5 mm, separación real de 0.01 mm y hueco real pequeño. La regularización opera a 0.002 mm y verifica su banda de 0.003 mm; no usa ShortCurveTolerance para borrar geometría.

Resultados con la misma suite: motor R4, 28 pasan y 3 fallan (salida 1); motor R5, **31/31 pasan** (salida 0). El proyecto y sus dependencias no cambian. Los cinco contornos reales del log se reprodujeron por separado en un fixture local privado: no se incluyen sus coordenadas en este repositorio ni en la entrega pública. Tampoco se ejecutó la API de Revit sobre esos contornos: se comprobaron la regularización, las áreas y la topología 2D.
