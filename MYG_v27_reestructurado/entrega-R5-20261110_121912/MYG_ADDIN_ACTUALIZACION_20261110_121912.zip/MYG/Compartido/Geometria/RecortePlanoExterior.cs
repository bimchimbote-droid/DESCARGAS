using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin.RecorteClipper;

namespace MYG_Addin
{
    // Operaciones de conjuntos en UN plano. Los triángulos de una superficie
    // son datos de entrada, nunca piezas de acabado ni contornos de salida.
    internal static class RecortePlanoExterior
    {
        internal static List<List<IntPoint>> UnirRegion(IEnumerable<List<IntPoint>> contornos)
        {
            var caminos = contornos.Where(x => x != null && x.Count >= 3 &&
                Math.Abs(Clipper.Area(x)) >= 0.5).ToList();
            if (caminos.Count == 0)
                return new List<List<IntPoint>>();
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(caminos, PolyType.ptSubject, true))
                throw new InvalidOperationException("No se pudo registrar un contorno de la región.");
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo normalizar una región plana.");
            return Clipper.PolyTreeToPaths(arbol);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes)
        {
            double antes, despues;
            return Restar(cara, superficiesCortantes, out antes, out despues);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes,
            out double areaAntesPrecision, out double areaDespuesPrecision)
        {
            areaAntesPrecision = areaDespuesPrecision = 0.0;
            var sujeto = UnirRegion(cara);
            if (sujeto.Count == 0)
                throw new InvalidOperationException("La cara seleccionada no contiene una región cerrada.");
            // Normalizar CADA superficie con sus huecos antes de unirlas.
            // Duplicados de tapas y triángulos nunca se cancelan entre sí.
            var cortes = new List<List<IntPoint>>();
            foreach (var superficie in superficiesCortantes)
                cortes.AddRange(UnirRegion(superficie));
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (cortes.Count > 0)
                motor.AddPaths(cortes, PolyType.ptClip, true);
            var resultado = new PolyTree();
            if (!motor.Execute(ClipType.ctDifference, resultado,
                PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo descontar la unión de interferencias.");
            areaAntesPrecision = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            resultado = RegularizarPrecision(resultado);
            double areaOriginal = sujeto.Sum(Clipper.Area);
            double areaFinal = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            areaDespuesPrecision = areaFinal;
            double toleranciaNumerica = Math.Max(1.0, Math.Abs(areaOriginal) * 1e-12) +
                3.0 * sujeto.Sum(Perimetro) + 36.0 * sujeto.Count;
            if (areaFinal < -toleranciaNumerica || areaFinal > areaOriginal + toleranciaNumerica)
                throw new InvalidOperationException("El recorte no conserva el área de la cara.");
            return resultado;
        }

        // Una celda equivale a 0.001 mm en el adaptador Revit. El redondeo de
        // rectas oblicuas puede convertir un retroceso colineal en una aguja
        // de anchura inferior a una celda. Revit la considera solape aunque
        // sus dos aristas sean largas y el CurveLoop esté cerrado y horizontal.
        internal static PolyTree RegularizarPrecision(PolyTree original)
        {
            var antes = Clipper.PolyTreeToPaths(original);
            if (antes.Count == 0)
                return original;
            var limpios = Clipper.CleanPolygons(antes, 2.0).Where(x => x.Count >= 3).ToList();
            if (antes.Count == limpios.Count && antes.Zip(limpios, (a, b) => a.SequenceEqual(b)).All(x => x))
                return original;
            var despues = new PolyTree();
            if (limpios.Count > 0)
            {
                var union = new Clipper { StrictlySimple = true };
                union.AddPaths(limpios, PolyType.ptSubject, true);
                if (!union.Execute(ClipType.ctUnion, despues, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                    throw new InvalidOperationException("No se pudo regularizar la precisión del contorno.");
            }
            var nuevos = Clipper.PolyTreeToPaths(despues);
            // No confiar solo en el área: exigir que no aparezca material fuera
            // de una envolvente de 3 celdas y que se conserve todo el interior
            // situado a más de 3 celdas del borde original. Así no se rediseña
            // un paño ni se elimina un hueco fuera de esa banda de precisión.
            var offset = new ClipperOffset();
            offset.AddPaths(antes, JoinType.jtMiter, EndType.etClosedPolygon);
            var exterior = new List<List<IntPoint>>();
            var interior = new List<List<IntPoint>>();
            offset.Execute(ref exterior, 3.0);
            offset.Execute(ref interior, -3.0);
            if (HayDiferenciaConArea(nuevos, exterior) || HayDiferenciaConArea(interior, nuevos))
                throw new InvalidOperationException("La limpieza excedería 0.003 mm; se conservó el rechazo del contorno.");
            double delta = Math.Abs(nuevos.Sum(Clipper.Area) - antes.Sum(Clipper.Area));
            if (delta > 3.0 * antes.Sum(Perimetro) + 36.0 * antes.Count)
                throw new InvalidOperationException("La limpieza alteraría un área no atribuible a la precisión numérica.");
            return despues;
        }

        private static bool HayDiferenciaConArea(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            if (sujeto.Count == 0)
                return false;
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (corte.Count > 0)
                motor.AddPaths(corte, PolyType.ptClip, true);
            var resultado = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctDifference, resultado, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo verificar la envolvente de precisión.");
            return resultado.Any(x => Math.Abs(Clipper.Area(x)) >= 0.5);
        }

        private static double Perimetro(List<IntPoint> camino)
        {
            double longitud = 0.0;
            for (int i = 0; i < camino.Count; i++)
            {
                IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                double x = (double)b.X - a.X, y = (double)b.Y - a.Y;
                longitud += Math.Sqrt(x * x + y * y);
            }
            return longitud;
        }

        internal static bool MismoDominio(List<List<IntPoint>> a, List<List<IntPoint>> b)
        {
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(UnirRegion(a), PolyType.ptSubject, true);
            motor.AddPaths(UnirRegion(b), PolyType.ptClip, true);
            var diferencia = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctXor, diferencia, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo comprobar el dominio de la cara.");
            return diferencia.All(x => Math.Abs(Clipper.Area(x)) < 0.5);
        }

        internal static List<IntPoint> QuitarColineales(List<IntPoint> original)
        {
            var puntos = new List<IntPoint>();
            foreach (var p in original)
                if (puntos.Count == 0 || puntos[puntos.Count - 1] != p)
                    puntos.Add(p);
            if (puntos.Count > 1 && puntos[0] == puntos[puntos.Count - 1])
                puntos.RemoveAt(puntos.Count - 1);
            bool cambio = true;
            while (cambio && puntos.Count > 3)
            {
                cambio = false;
                for (int i = 0; i < puntos.Count; i++)
                {
                    IntPoint a = puntos[(i + puntos.Count - 1) % puntos.Count];
                    IntPoint b = puntos[i], c = puntos[(i + 1) % puntos.Count];
                    System.Numerics.BigInteger ax = (System.Numerics.BigInteger)b.X - a.X;
                    System.Numerics.BigInteger ay = (System.Numerics.BigInteger)b.Y - a.Y;
                    System.Numerics.BigInteger bx = (System.Numerics.BigInteger)c.X - b.X;
                    System.Numerics.BigInteger by = (System.Numerics.BigInteger)c.Y - b.Y;
                    if (ax * by == ay * bx && ax * bx + ay * by >= 0)
                    {
                        puntos.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }
            return puntos;
        }
    }
}
