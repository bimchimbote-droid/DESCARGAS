# Corrección de precisión del boceto — TARRAJEO-PLANO-R5

## Base de trabajo

Repositorio seleccionado: `bimchimbote-droid/MYG_v27_reestructurado`, master, base Git `cb9d73137e06f55741862274e4ee839bb87e5d80`. Se mantiene el motor de cara/espesor exterior de R4. Base inmediata para esta entrega: ZIP R4 publicado en DESCARGAS, commit `af2c7570f204e386fed398d81c3d0ab8c90cea80`. No se sustituyó la solución por otra rama ni se modificaron referencias, paquetes o framework.

## Evidencia del log y cambio

Las entradas nuevas del archivo recibido identifican la R4 cargada. Dos perfiles grandes tienen un único contorno cerrado, horizontal, con retrocesos casi colineales. Sus desviaciones transversales son inferiores a 0.001 mm: las aristas son largas pero vuelven casi sobre la misma recta. Otros contornos son triángulos extremadamente delgados, de 0.038509 y 0.026481 mm², sin un plano útil para el boceto. También se registran aristas de aproximadamente 0.5 mm menores que ShortCurveTolerance, pero sus coordenadas no estaban incluidas porque el rechazo ocurría antes de crear CurveLoop.

Estos datos NO demuestran que la causa sea que la superficie seleccionada tenga varias caras. El log permite verificar los perfiles resultantes y sus problemas geométricos, no establecer esa relación con el elemento original.

R5 añade una regularización de precisión DESPUÉS de la única diferencia 2D de R4. Usa dos celdas de la rejilla existente: 0.002 mm, no la tolerancia de creación de Revit. Se vuelve a normalizar la topología de los contornos y se comprueba que:

- No aparezca material fuera de la expansión de 0.003 mm de la región original.
- Se conserve todo el material situado a más de 0.003 mm del borde original.
- El cambio de área esté acotado por esa banda numérica.

La verificación incluye todos los huecos. No se crean franjas, no se amplían todos los obstáculos y no se rediseña el paño con una envolvente o rectángulo. Una aguja numérica puede ser larga pero de anchura inferior a una celda: retirarla no significa recortar una franja del paño. Los detalles reales de 0.5 mm NO se borran automáticamente para forzar un boceto.

Además se registra la geometría completa de una región rechazada ANTES de CurveLoop, con coordenadas XYZ invariantes, incluidos sus huecos. Esto permite analizar las aristas cortas si persisten. Ese detalle va al log local, no al TaskDialog; hay un límite explícito de 10000 vértices por región con aviso de truncación. Se distingue también entre cobertura total y un resultado compuesto solo por residuos numéricos.

## Archivos que requieren intervención

| Acción | Ruta relativa | Descripción |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Regularización acotada, verificación de dominio y métricas de área. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs` | Diagnóstico de regiones rechazadas antes de CurveLoop. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Log de esas regiones y marcador R5. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Seis regresiones nuevas; se conservan los 25 casos de R4. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Resultados y alcance de las pruebas. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP contiene además `PARCHES/ACTUALIZAR_MOTOR_DESDE_R4.patch` y `MANIFIESTO_SHA256.txt`: total 8 archivos. El parche es una alternativa a copiar los tres archivos de producción y parte de R4. No hay archivos nuevos de producción, inclusiones de proyecto ni eliminaciones nuevas.

`MYG.csproj`, `Tarrajeo_MurosHandler.cs`, `Clipper.cs`, `TarrajeoAlturas.cs`, `TarrajeoValidacionSuelo.cs` y el proyecto de pruebas permanecen SIN CAMBIOS respecto a R4 y quedan fuera del ZIP. No se incluyen log, coordenadas del modelo, imágenes, fixtures privados, DLL, paquetes, .git/.vs ni bin/obj.

## Instalación

1. Mantener R4 instalada como base y respaldar los archivos locales. Copiar archivos completos puede sobrescribir cambios locales o posteriores: comparar antes si tu versión difiere.
2. Copiar los tres archivos de producción sobre las mismas rutas. Ya están incluidos en el proyecto desde R4; no volver a añadir Compile duplicados ni sustituir el .csproj.
3. Como alternativa a copiarlos, desde la raíz ejecutar primero `git apply --check PARCHES/ACTUALIZAR_MOTOR_DESDE_R4.patch` y después `git apply PARCHES/ACTUALIZAR_MOTOR_DESDE_R4.patch`. No aplicar el parche después de reemplazarlos ni sobre otra versión sin revisar conflictos. Copiar aparte pruebas e instrucciones.
4. Compilar en tu configuración real Windows/Revit, actualizar la DLL de prueba, cerrar completamente todas las instancias de Revit y volver a abrir. El aviso/log debe mostrar `TARRAJEO-PLANO-R5`.
5. Probar una copia del modelo sin los acabados generados por las pruebas anteriores: siguen siendo sólidos visibles y pueden intervenir en la nueva ejecución. No se borran automáticamente elementos del modelo.
6. Si persiste una arista menor que ShortCurveTolerance, conservar la nueva entrada R5: contendrá el contorno que falta en el log R4. No eliminar a ciegas una arista real para obtener un boceto aparentemente válido.

## Validación ejecutada

- Suite actual: 31/31 pruebas pasan. Contra el motor R4, con los mismos casos, pasan 28 y fallan las tres regresiones de retroceso/residuos; salida 1. R5 termina con salida 0.
- Se mantienen los casos de huecos/islas, rectángulos rotados, triangulación sin diagonales, cortes parciales/totales y reglas de altura exterior. Se añaden pruebas que preservan un bisel real de medio milímetro, una separación de diez micras y un hueco real pequeño.
- Se reprodujeron localmente cinco contornos del log en la etapa de regularización: los dos grandes conservan una única región sin retrocesos; los tres residuos degenerados desaparecen. Los cambios de área de los dos grandes son aproximadamente -0.306243 y +0.241048 mm². Sus coordenadas no se publican. Esta es reproducción geométrica 2D, no ejecución de BoundaryValidation en Revit.
- Compilación semántica del motor y del cuerpo real del flujo nuevo de suelos contra las referencias reales de Revit: sin errores. C# 7.3 y 182 fuentes activas sin errores de sintaxis; rutas de recursos presentes.
- La compilación completa en Linux se intenta y sigue bloqueada por MSB4803/ResolveComReference, que requiere Windows/.NET Framework MSBuild. No se genera una DLL aquí. Se conservan las incompatibilidades preexistentes del proyecto local y sus dependencias; no se sobrescriben las actualizaciones de tu solución Windows.

## Límites

No se ejecutó el modelo, el kernel de Revit, las transacciones ni Floor.Create en este entorno. La regularización corrige un defecto demostrado en los contornos recibidos; no certifica que todas las demás regiones sean creables. Las aristas reales menores que ShortCurveTolerance siguen siendo una restricción de Revit. Para las aristas de 0.5 mm del log faltaban coordenadas: no se confirma su origen ni se modifica su forma por suposición. La R5 registra esos datos para distinguir una arista real de un residuo si vuelve a ocurrir.

## GitHub

Solo se publica el ZIP en una ruta nueva de `bimchimbote-droid/DESCARGAS`, conservando entregas anteriores. Se comprueba por Git HTTPS desde un clon independiente, SHA-256, integridad y manifiesto, sin generar ni enviar enlaces de descarga. Esto no actualiza tu PC ni hace Commit/Push al repositorio del código.

Después de aplicar y validar, revisar las diferencias en Git Changes de Visual Studio, seleccionar únicamente los archivos de esta corrección, hacer Commit y Push cuando decidas incorporarlos. No publicar el log ni el modelo.
