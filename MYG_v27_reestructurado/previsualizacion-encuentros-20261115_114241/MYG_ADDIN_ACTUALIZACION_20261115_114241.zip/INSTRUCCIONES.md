# MYG · Previsualización y encuentros de ladrillos

## A. Resumen y base
Se añade una **previsualización interactiva en planta** antes de crear ladrillos y cuatro acciones para los encuentros con elementos vecinos: detectar, omitir, unir o cortar. Conserva el comando existente de selección de losa/dirección, hospedaje, altura, distribución y alineación.

Base real: `bimchimbote-droid/MYG_v27_reestructurado`, HEAD Git `2a8977e8032d0bd9d12d7302b897d5096b0cf064` más las entregas anteriores. Esta actualización se aplica sobre `MYG_ADDIN_ACTUALIZACION_20261115_110102.zip`, publicado en DESCARGAS en commit `500c7b4303cffe01050610647c9b6003ec5fd465`, manteniendo las correcciones previas de hospedaje y alineación. No se sustituyeron archivos por otra rama ni se actualizaron dependencias.

## B. Archivos afectados
| Ruta | Acción |
|---|---|
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaCommand.cs | REEMPLAZAR: flujo integrado y resumen de resultados |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaForm.cs | REEMPLAZAR: opciones de vecinos/encuentros y botón Previsualizar |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosPreviewForm.cs | CREAR: ventana y lienzo interactivo |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosInterferencias.cs | CREAR: detección y resolución verificada |
| MYG/MYG.csproj | MODIFICAR con Parches/MYG.csproj.patch: dos entradas Compile |

ARCHIVOS.csv registra acciones/hashes antes y después. No se elimina ningún archivo. Layout, pruebas automatizadas, Ribbon, manifiesto, paquetes y demás funcionalidades no cambian y quedan fuera del ZIP. El proyecto completo, paquetes, DLL, RVT/RFA y archivos sin cambios no están incluidos.

## C. Paquete
Nombre: `MYG_ADDIN_ACTUALIZACION_20261115_114241.zip`, fecha/hora America/Lima. La publicación/descarga y su hash se confirman en el mensaje de entrega después de realizarlas. Se publica únicamente el ZIP de código e instrucciones en DESCARGAS, conservando entregas anteriores; ningún modelo del usuario forma parte de él.

## D. Instalación
1. Cierra Revit y respalda tu solución y DLL de la versión anterior.
2. Copia los dos archivos nuevos y reemplaza los dos archivos actualizados del complemento respetando las rutas. Se entregan archivos completos, no fragmentos. Si tienes cambios posteriores propios, compara/fusiona antes de reemplazar para no perderlos.
3. Añade al proyecto las dos fuentes nuevas. Con Parches extraído en la raíz de tu solución:
   ```bash
   git apply --check Parches/MYG.csproj.patch
   git apply Parches/MYG.csproj.patch
   ```
   El parche solo añade LadrillosPreviewForm.cs y LadrillosInterferencias.cs al ItemGroup de Compile, sobre el proyecto de las entregas anteriores. Si no coincide con tu archivo, usa Agregar → Elemento existente en Visual Studio para incorporar esos dos archivos y comprueba sus entradas. No dupliques las inclusiones ni vuelvas a aplicar parches anteriores.
4. Compila en Windows con las referencias reales de tu solución. Revisa OutputPath, reemplaza MYG.dll con Revit cerrado y reinicia Revit antes de probar con AddInManager. Conserva el manifiesto .addin y MYG_Addin.App.

## E. Uso y configuración
No se añaden paquetes ni referencias. La previsualización utiliza WinForms/System.Drawing ya presentes y las operaciones usan la API Revit existente.

1. En una planta de piso o estructural, pulsa MYG → ESTRUCTURAS → Ladrillos en losa.
2. Configura familia, vigueta (predeterminado10cm), junta, margen, giro y altura como antes. La altura nativa de familia hospedada continúa siendo la opción predeterminada; el ajuste al intradós sigue siendo opcional.
3. Selecciona el modo de encuentros. Por defecto es **Omitir piezas en conflicto**. Si quieres recortar las piezas que invadan una viga/muro, elige Unir o Cortar. También puedes cambiar el modo en la previsualización.
4. Por defecto se buscan vecinos cercanos en TODO el documento actual, incluidos los ocultos en la vista, de estas categorías: muros, vigas, columnas estructurales/arquitectónicas, cimentaciones, otros suelos, cubiertas y modelos genéricos. Se excluyen la losa anfitriona y la misma familia de ladrillos (su solapamiento ya se controla por el comando anterior). No se buscan elementos de vínculos.
5. Para controlar el alcance, activa Seleccionar manualmente los elementos vecinos. Después de seleccionar la losa, selecciona los elementos locales que quieras considerar y pulsa Finalizar. Puedes incluir otras categorías de modelo con sólidos (por ejemplo instalaciones), pero Revit puede no admitir unirlas o cortarlas. Los vínculos y la losa anfitriona no se admiten como objetivos.
6. Marca los dos puntos de origen/dirección. Se abre la previsualización2D con contorno, huecos, huellas de ladrillos, envolventes de vecinos y posibles cruces.
7. Rueda para zoom; botón central o arrastre sobre fondo para desplazar; Ajustar vista/Home para centrar la losa. Clic en un ladrillo para incluirlo/excluirlo, o utiliza los botones de selección global. El resumen permite desplazamiento/copia de su texto.
8. Cambia el modo si procede y pulsa Crear selección. Cancelar revierte también cualquier carga de familia y no deja piezas de prueba en el proyecto.

### Modos de encuentros
| Modo | Resultado |
|---|---|
| Solo detectar | Crea lo seleccionado y comunica los pares con volumen común; **puede conservar interferencias** |
| Omitir | Elimina del lote las piezas cuya geometría real tiene volumen común con los vecinos considerados |
| Unir | Intenta JoinGeometry dando al vecino prioridad como cortante; verifica que la pieza resultante ya no lo invada |
| Cortar | Intenta el corte sólido permitido por Revit con vecino como cortante y ladrillo como elemento recortado; comprueba el resultado |

**Unir/cortar no está admitido para todas las familias/categorías.** Un muro puede admitir unión pero no corte sólido; una familia genérica hospedada tampoco tiene compatibilidad garantizada. Si Revit rechaza la operación, queda volumen común o el corte consume todo el ladrillo, se revierte ese intento y se **omite la pieza**. No se cambia la familia ni se sustituye por DirectShape. El resumen separa creadas, excluidas manualmente, omitidas, uniones/cortes confirmados y pares pendientes en Solo detectar.

La previsualización utiliza una huella rectangular conservadora, sin representar el vacío interior del ladrillo ni simular el recorte3D final. Un posible cruce marcado puede no ser interferencia en la geometría real; la decisión final se toma con los sólidos reales. Las envolventes de vecinos son cajas proyectadas, no su forma exacta. Verde significa que no se detectó cruce en esa previsión y alcance; no certifica el modelo completo.

## F. Validación
- Compilación aislada de las fuentes contra DLL reales disponibles de API Revit2027, C#7.3/net10.0-windows: **0 errores,0 advertencias**. Adaptadores externos de integración solo para acceso/registro del botón; no se entregan ni se incorporan al complemento.
- **56 pruebas automatizadas existentes aprobadas,0 fallidas**: regresión de distribución/altura/alineación. No prueban la ventana WinForms ni las operaciones reales Join/Cut.
- Roslyn: **188 fuentes activas sin errores de sintaxis**;188 Compile,9 EmbeddedResource y3 None existentes y sin duplicados. git diff --check correcto.
- Parche de proyecto aplicado contra la versión previa y resultado comparado byte a byte con el proyecto actualizado.
- Compilación completa del proyecto: continúa bloqueada por MSB4803 (COM requiere MSBuild de .NET Framework sobre Windows), con advertencia EPPlus.Interfaces preexistente.
- **No se ejecutó Revit, la interacción de la ventana ni una unión/corte real en este entorno Linux.** Consulta VALIDACION.md para la matriz manual obligatoria antes de uso habitual.

## G. GitHub
Publicar el ZIP en DESCARGAS no actualiza tu PC ni hace Push/merge al repositorio de código. Tras instalar, compilar y probar, revisa cada diff en Cambios de Git de Visual Studio, crea tu Commit y haz Push desde tu equipo cuando decidas publicar el código. La modificación del csproj debe acompañar a los dos archivos nuevos.

## H. Límites y garantías de alcance
- La selección y la distribución siguen siendo para losas horizontales de espesor constante. La previsualización es una interfaz2D en planta; no es un visor3D navegable ni una vista temporal de Revit.
- Los encuentros se revisan contra los objetivos locales incluidos por la búsqueda/selección, no contra todo el modelo ni vínculos. Se ignoran contactos sin volumen común apreciable. La tolerancia volumétrica es1mm³ o la relativa definida por los sólidos; no se promete ausencia de todos los avisos de interferencias de cualquier herramienta externa.
- En Unir/Cortar, se da prioridad al vecino para recortar el ladrillo. Se vigila que su volumen no cambie; si un intento lo altera, se revierte y se omite la pieza. Un cambio indirecto detectado al final revierte el lote completo. Las uniones permanecen paramétricas y podrán responder a cambios posteriores del modelo; esta revisión describe el estado al confirmar la operación.
- La losa anfitriona está excluida de estas operaciones; Revit conserva los efectos propios del hospedaje de la familia. No se elimina la validación original de alineación antes de los recortes intencionados.
- La pieza temporal de medición se crea en una subtransacción y se revierte COMPLETAMENTE antes de capturar la geometría de los vecinos y mostrar la previsualización. No contamina el estado de referencia.
- Cada intento de resolución usa una subtransacción por pieza. Si un segundo vecino no admite la operación, se revierten también las operaciones previas de esa pieza. Antes de confirmar se vuelve a comprobar el lote contra cajas y sólidos actuales de los objetivos, sin confiar únicamente en la existencia de la relación de unión/corte.
- Límites:100.000 candidatos,10.000 ladrillos,2.000 vecinos y500.000 comprobaciones booleanas por ejecución. Superarlos aborta con diagnóstico; no se ignora una parte del alcance silenciosamente. Una comprobación booleana fallida no se considera espacio libre.
- No se migró el framework ni se resolvió la compatibilidad pendiente de .NET Framework4.8/Revit2027; se conservan las dependencias originales. La compatibilidad efectiva de tu familia con cada operación debe confirmarse en Revit.
