# Validación: previsualización y encuentros

## Ejecutado
- Compilación aislada de fuentes actuales con C#7.3/net10.0-windows contra APIRevit2027:0errores/0advertencias. No prueba carga de MYG.dll completa, UI ni ejecución de geometría en Revit.
-56pruebas de regresión existentes aprobadas: distribución, altura y alineación. No se incluyeron fuentes de pruebas sin cambios en este ZIP.
- Análisis Roslyn de188fuentes activas sin errores;188Compile,9EmbeddedResource y3None existentes y sin duplicados; gitdiffcheck correcto.
- Parche de2Compile probado sobre el proyecto anterior; resultado idéntico al proyecto actual.
- Compilación completa intentada: MSB4803 en referencias COM, más MSB3277 de EPPlus.Interfaces preexistente. No se generó una DLL nueva del complemento completo.
- Revisión de API/order: JoinGeometry+prioridad del vecino; CanElementCutElement(vecino,ladrillo), AddCutBetweenSolids(documento,ladrillo,vecino,false); geometría fresca y volumen común tras operaciones; rollback completo porpieza. No se confunde relación Join/Cut con resolución efectiva.

## Matriz pendiente dentro de Revit
Se requiere Windows y una copia de un modelo. No se ejecutó Revit en esta entrega.

| Caso | Comprobar |
|---|---|
| Previsualización | Contorno/huecos, direcciónoblicua, tipos/dimensiones, colores, conteos, leyenda y texto del resumen |
| Navegación | Zoom al cursor, arrastre central/fondo, Home/Ajustar, redimensionar/DPI y textos largos |
| Selección | Excluir/incluir con clic y botones globales; confirmar solo incluidas; cero selección no crea |
| Cancelar | En cada selección y enpreview; no quedan ladrillos temporales/carga de familia ajena al estado inicial |
| Alcance automático | Viga/muro/columnas ocultos en vista pero cercanos se detectan; anfitrión y misma familia se excluyen |
| Alcance manual | Solo objetivos elegidos; instalaciones locales si tienen sólidos; rechazar vínculos y anfitrión |
| Previsión conservadora | Cruce de prisma por un hueco interior del ladrillo puede marcarse, pero si los sólidos reales no chocan la pieza se conserva |
| Contacto | Vecino tangente sin volumen común no se trata como interferencia |
| Solo detectar | Se conservan piezas y se informan los pares pendientes; no se afirma ausencia de interferencias |
| Omitir | Los ladrillos con volumen común se omiten, los demás se conservan y conteo coincide |
| Unión admitida | Vecino corta ladrillo; neto sin volumen común y vecino conserva volumen; relación paramétrica y resultado verificables |
| Corte admitido | Corte con orden correcto; neto sin volumen común, dimensión inicial puede recortarse deliberadamente |
| Operación no admitida | No se cambian plantillas/familias; se revierte intento, se omitepieza y se comunica razón |
| Corte completo | Si la pieza queda sin sólido, se omite y no se cuenta como colocada |
| Dos vecinos | Primero admite y segundo no: rollback de todo intento de esa pieza, sin uniones previas sueltas |
| Cambio exterior | Si una operación cambia volumen del vecino, no se conserva; cambio indirecto final revierte lote |
| Comprobación final | Cajas/sólidos actuales de todos objetivos, no índice inicial como prueba definitiva; piezas sin sólidos no pasan |
| Hospedaje/altura | Familia adjunta con anfitriónsuelo, modo nativo y ajuste al intradós; base y alineación antesrecorte correctas |
| Deshacer | Una sola acción revierte piezas, uniones/cortes y carga de familia de la operación |
| Límites | Mensaje claro al superar2.000vecinos/500.000booleanas, sin omitir alcance silenciosamente |

La compatibilidad real Join/Cut con la familia genérica hospedada y cada categoría solo puede comprobarse ejecutando esta matriz en Revit. La ausencia de ejecución no se presenta como prueba funcional aprobada.
