using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace MYG_Addin
{
    internal enum ModoEncuentroLadrillos
    {
        SoloDetectar,
        Omitir,
        Unir,
        Cortar
    }

    internal sealed class ResultadoEncuentroLadrillos
    {
        internal bool Conservar { get; set; }
        internal bool Resuelto { get; set; }
        internal int Uniones { get; set; }
        internal int Cortes { get; set; }
        internal List<ElementId> NoResueltos { get; } = new List<ElementId>();
        internal List<string> Diagnosticos { get; } = new List<string>();
    }

    /// <summary>
    /// Detecta volumen común real, no solo cajas coincidentes. Los snapshots
    /// pertenecen exclusivamente a la previsión; después de unir/cortar se
    /// consulta otra vez la geometría neta actual de ambos elementos.
    /// El llamador mantiene abierta la transacción y elimina una instancia
    /// nueva cuando Conservar=false. Nunca se altera la familia ni se sustituye
    /// una instancia por DirectShape.
    /// </summary>
    internal sealed class LadrillosInterferencias : IDisposable
    {
        private const int MaxObjetivos = 2000;
        private const int MaxBooleanas = 500000;
        private const double PasoIndice = 6.0; // pies, solo descarte de cajas
        private const double ToleranciaCaja = 1e-7;
        private const double VolumenMinimo = 1.0 / (304.8 * 304.8 * 304.8); // 1 mm3
        private readonly Document documento;
        private readonly List<Objetivo> objetivos = new List<Objetivo>();
        private readonly Dictionary<string, List<Objetivo>> indice = new Dictionary<string, List<Objetivo>>();
        private readonly List<Objetivo> grandes = new List<Objetivo>();
        private int booleanas;
        private bool disposed;

        internal LadrillosInterferencias(Document doc, ElementId sueloId, IList<ElementId> elementosObjetivo)
        {
            if (doc == null || doc.IsFamilyDocument)
                throw new ArgumentException("Las interferencias se comprueban dentro de un proyecto de Revit.");
            documento = doc;
            if (elementosObjetivo == null)
                throw new ArgumentNullException(nameof(elementosObjetivo));
            var ids = elementosObjetivo.Where(x => x != null && !x.Equals(ElementId.InvalidElementId) &&
                (sueloId == null || !x.Equals(sueloId))).Distinct().ToList();
            if (ids.Count > MaxObjetivos)
                throw new InvalidOperationException("Se han seleccionado más de " + MaxObjetivos +
                    " elementos de encuentro. Reduce la selección; no se ignorarán elementos silenciosamente.");
            try
            {
                foreach (ElementId id in ids)
                {
                    Element elemento = doc.GetElement(id);
                    if (elemento == null)
                        throw new InvalidOperationException("Ya no existe el elemento de encuentro ID " + id + ".");
                    if (elemento is RevitLinkInstance)
                        throw new InvalidOperationException("El elemento ID " + id +
                            " es un vínculo. La unión/corte requiere elementos del documento actual.");
                    Geometria copia = LeerGeometria(elemento);
                    if (copia.Solidos.Count == 0) { copia.Dispose(); continue; }
                    var objetivo = new Objetivo { Id = id, Snapshot = copia };
                    objetivos.Add(objetivo);
                    Indexar(objetivo);
                }
            }
            catch { Dispose(); throw; }
        }

        internal IList<ElementId> Objetivos
        {
            get { ComprobarDisponible(); return objetivos.Select(x => x.Id).ToList(); }
        }

        /// <summary>
        /// Previsión conservadora mediante la caja completa de la pieza, no su
        /// hueco interior. Puede marcar candidatos que la geometría real resuelva.
        /// El eje Z es absoluto; origen solo aporta su posición XY.
        /// </summary>
        internal IList<ElementId> GetConflictosHuella(XYZ origen, XYZ u, XYZ v,
            LadrilloPunto centro, double largo, double ancho, double baseZ, double alto)
        {
            ComprobarDisponible();
            if (origen == null || u == null || v == null || !Finito(centro.X) || !Finito(centro.Y) ||
                !Finito(largo) || !Finito(ancho) || !Finito(baseZ) || !Finito(alto) ||
                largo <= 0 || ancho <= 0 || alto <= 0)
                throw new ArgumentException("La huella de previsualización debe tener posición y dimensiones válidas.");
            var puntos = new[] {
                Punto(origen, u, v, centro.X - largo / 2, centro.Y - ancho / 2, baseZ),
                Punto(origen, u, v, centro.X + largo / 2, centro.Y - ancho / 2, baseZ),
                Punto(origen, u, v, centro.X + largo / 2, centro.Y + ancho / 2, baseZ),
                Punto(origen, u, v, centro.X - largo / 2, centro.Y + ancho / 2, baseZ)
            };
            using (var loop = new CurveLoop())
            {
                for (int i = 0; i < 4; i++) loop.Append(Line.CreateBound(puntos[i], puntos[(i + 1) % 4]));
                using (Solid prisma = GeometryCreationUtilities.CreateExtrusionGeometry(
                    new List<CurveLoop> { loop }, XYZ.BasisZ, alto))
                {
                    Rango caja = CajaSolido(prisma);
                    var resultado = new List<ElementId>();
                    foreach (Objetivo objetivo in Candidatos(caja))
                        if (Intersectan(new[] { prisma }, objetivo.Snapshot.Solidos)) resultado.Add(objetivo.Id);
                    return resultado;
                }
            }
        }

        /// <summary>Obtiene geometría fresca del ladrillo y de los vecinos.</summary>
        internal List<ElementId> Detectar(Element ladrillo)
        {
            return DetectarInterno(ladrillo, false, false);
        }

        /// <summary>
        /// Comprobación definitiva después de todas las modificaciones. Recorre
        /// TODOS los objetivos con cajas y sólidos frescos: no utiliza el índice
        /// espacial anterior a las uniones/cortes. Una pieza sin sólido no puede
        /// presentarse como una colocación válida libre de interferencias.
        /// </summary>
        internal List<ElementId> DetectarFinal(Element ladrillo)
        {
            return DetectarInterno(ladrillo, true, true);
        }

        private List<ElementId> DetectarInterno(Element ladrillo, bool todos, bool exigirSolidos)
        {
            ComprobarDisponible();
            if (ladrillo == null || !ladrillo.Document.Equals(documento))
                throw new ArgumentException("El ladrillo debe pertenecer al documento actual.");
            using (Geometria pieza = LeerGeometria(ladrillo))
            {
                var resultado = new List<ElementId>();
                if (pieza.Solidos.Count == 0)
                {
                    if (exigirSolidos)
                        throw new InvalidOperationException("El ladrillo ID " + ladrillo.Id +
                            " no conserva geometría sólida; no puede considerarse una colocación válida.");
                    return resultado;
                }
                IEnumerable<Objetivo> revisar = todos ? CandidatosActuales(pieza.Caja) : Candidatos(pieza.Caja);
                foreach (Objetivo objetivo in revisar)
                {
                    if (objetivo.Id.Equals(ladrillo.Id)) continue;
                    Element vecino = documento.GetElement(objetivo.Id);
                    if (vecino == null)
                        throw new InvalidOperationException("Ya no existe el elemento de encuentro ID " + objetivo.Id + ".");
                    // Descarte barato con la caja ACTUAL del elemento. La caja
                    // puede incluir controles/referencias y ser conservadora;
                    // si no existe, se consulta igualmente el sólido para no
                    // declarar una ausencia de interferencia sin comprobarla.
                    Rango cajaActual = CajaElemento(vecino);
                    if (cajaActual != null && !pieza.Caja.Intersecta(cajaActual)) continue;
                    using (Geometria actual = LeerGeometria(vecino))
                        if (actual.Solidos.Count > 0 && pieza.Caja.Intersecta(actual.Caja) &&
                            Intersectan(pieza.Solidos, actual.Solidos)) resultado.Add(objetivo.Id);
                }
                return resultado;
            }
        }

        internal ResultadoEncuentroLadrillos Resolver(FamilyInstance ladrillo, ModoEncuentroLadrillos modo)
        {
            ComprobarDisponible();
            if (!Enum.IsDefined(typeof(ModoEncuentroLadrillos), modo))
                throw new ArgumentOutOfRangeException(nameof(modo));
            List<ElementId> conflictos = Detectar(ladrillo);
            ElementId idLadrillo = ladrillo.Id;
            var resultado = new ResultadoEncuentroLadrillos();
            using (Geometria inicial = LeerGeometria(ladrillo))
                if (inicial.Solidos.Count == 0)
                {
                    resultado.Conservar = resultado.Resuelto = false;
                    resultado.Diagnosticos.Add("Ladrillo ID " + ladrillo.Id +
                        ": no tiene geometría sólida. Se omite; no es una colocación resuelta.");
                    return resultado;
                }
            if (conflictos.Count == 0)
            {
                resultado.Conservar = resultado.Resuelto = true;
                return resultado;
            }
            if (modo == ModoEncuentroLadrillos.SoloDetectar || modo == ModoEncuentroLadrillos.Omitir)
            {
                resultado.Conservar = modo == ModoEncuentroLadrillos.SoloDetectar;
                resultado.NoResueltos.AddRange(conflictos);
                return resultado;
            }
            if (!documento.IsModifiable)
                throw new InvalidOperationException("La resolución de encuentros requiere una transacción abierta.");

            // Una única subtransacción para toda la pieza: si un segundo vecino
            // no admite la operación, tampoco quedan uniones previas sueltas.
            using (var intento = new SubTransaction(documento))
            {
                try
                {
                    if (intento.Start() != TransactionStatus.Started)
                        throw new InvalidOperationException("No se pudo iniciar la resolución del encuentro.");
                    var volumenesVecinos = conflictos.ToDictionary(x => x,
                        x => VolumenElemento(documento.GetElement(x)));
                    int uniones = 0, cortes = 0;
                    foreach (ElementId id in conflictos)
                    {
                        Element vecino = documento.GetElement(id);
                        if (vecino == null)
                            throw new InvalidOperationException("Ya no existe el elemento de encuentro ID " + id + ".");
                        if (!HaySolapamiento(ladrillo, vecino)) continue;
                        if (modo == ModoEncuentroLadrillos.Unir)
                        {
                            if (!JoinGeometryUtils.AreElementsJoined(documento, vecino, ladrillo))
                            {
                                JoinGeometryUtils.JoinGeometry(documento, vecino, ladrillo);
                                uniones++;
                            }
                            // Siempre conservar al vecino como elemento cortante.
                            if (!JoinGeometryUtils.IsCuttingElementInJoin(documento, vecino, ladrillo))
                                JoinGeometryUtils.SwitchJoinOrder(documento, vecino, ladrillo);
                        }
                        else
                        {
                            bool ladrilloCortaVecino;
                            bool existe = SolidSolidCutUtils.CutExistsBetweenElements(ladrillo, vecino, out ladrilloCortaVecino);
                            if (existe && ladrilloCortaVecino)
                                throw new InvalidOperationException("El corte existente tiene el orden opuesto al solicitado (vecino ID " + id + ").");
                            if (!existe)
                            {
                                if (!SolidSolidCutUtils.IsAllowedForSolidCut(vecino) ||
                                    !SolidSolidCutUtils.IsAllowedForSolidCut(ladrillo))
                                    throw new InvalidOperationException("Revit no admite un corte sólido entre esta familia y el elemento ID " + id + ".");
                                CutFailureReason motivo;
                                if (!SolidSolidCutUtils.CanElementCutElement(vecino, ladrillo, out motivo))
                                    throw new InvalidOperationException("El elemento ID " + id + " no puede cortar el ladrillo: " + motivo + ".");
                                SolidSolidCutUtils.AddCutBetweenSolids(documento, ladrillo, vecino, false);
                                cortes++;
                            }
                        }
                        documento.Regenerate();
                        if (HaySolapamiento(ladrillo, vecino))
                            throw new InvalidOperationException("La operación no eliminó el volumen común con el elemento ID " + id + ".");
                    }
                    using (Geometria neta = LeerGeometria(ladrillo))
                        if (neta.Solidos.Count == 0)
                            throw new InvalidOperationException("El encuentro consume toda la geometría del ladrillo; se omitirá esa pieza.");
                    List<ElementId> restantes = DetectarFinal(ladrillo);
                    if (restantes.Count > 0)
                        throw new InvalidOperationException("Persisten encuentros con los elementos ID " +
                            string.Join(", ", restantes.Select(x => x.ToString())) + ".");
                    foreach (var vecinoAntes in volumenesVecinos)
                        ComprobarVolumenVecino(vecinoAntes.Key, vecinoAntes.Value);
                    if (intento.Commit() != TransactionStatus.Committed)
                        throw new InvalidOperationException("Revit no confirmó la resolución del encuentro.");
                    resultado.Conservar = resultado.Resuelto = true;
                    resultado.Uniones = uniones;
                    resultado.Cortes = cortes;
                    return resultado;
                }
                catch (Autodesk.Revit.Exceptions.RegenerationFailedException) { throw; }
                catch (LimiteInterferenciasException) { throw; }
                catch (Exception ex)
                {
                    if (intento.GetStatus() == TransactionStatus.Started) intento.RollBack();
                    resultado.Conservar = false;
                    resultado.Resuelto = false;
                    resultado.NoResueltos.AddRange(conflictos);
                    resultado.Diagnosticos.Add("Ladrillo ID " + idLadrillo + ": " + ex.Message +
                        " Se revierte el intento y se omite la pieza; no se afirma una interferencia resuelta.");
                    return resultado;
                }
                finally
                {
                    if (intento.GetStatus() == TransactionStatus.Started) intento.RollBack();
                }
            }
        }

        /// <summary>
        /// Validación global al terminar el lote, antes de confirmar la
        /// transacción exterior. Incluye vecinos sin intersección inicial que
        /// podrían estar unidos entre sí. No depende de la copia de geometría
        /// utilizada por la previsualización.
        /// </summary>
        internal void VerificarObjetivosSinCambios()
        {
            ComprobarDisponible();
            foreach (Objetivo objetivo in objetivos)
                ComprobarVolumenVecino(objetivo.Id, objetivo.Snapshot.Solidos.Sum(x => x.Volume));
        }

        private void ComprobarVolumenVecino(ElementId id, double anterior)
        {
            double actual = VolumenElemento(documento.GetElement(id));
            double tolerancia = Math.Max(VolumenMinimo, Math.Abs(anterior) * 1e-10);
            if (Math.Abs(actual - anterior) > tolerancia)
                throw new InvalidOperationException("La operación cambió el volumen del elemento vecino ID " + id +
                    ". Diferencia: " + ((actual - anterior) * 304.8 * 304.8 * 304.8)
                        .ToString("0.######", System.Globalization.CultureInfo.CurrentCulture) +
                    " mm³; tolerancia: " + (tolerancia * 304.8 * 304.8 * 304.8)
                        .ToString("0.######", System.Globalization.CultureInfo.CurrentCulture) +
                    " mm³. Se revierte el intento para conservar el elemento existente como cortante.");
        }

        private static double VolumenElemento(Element elemento)
        {
            if (elemento == null)
                throw new InvalidOperationException("Un elemento vecino ya no existe durante la comprobación del encuentro.");
            using (Geometria geometria = LeerGeometria(elemento)) return geometria.Solidos.Sum(x => x.Volume);
        }

        private bool HaySolapamiento(Element a, Element b)
        {
            using (Geometria primera = LeerGeometria(a))
            using (Geometria segunda = LeerGeometria(b))
                return primera.Solidos.Count > 0 && segunda.Solidos.Count > 0 &&
                    primera.Caja.Intersecta(segunda.Caja) && Intersectan(primera.Solidos, segunda.Solidos);
        }

        private bool Intersectan(IEnumerable<Solid> primera, IEnumerable<Solid> segunda)
        {
            foreach (Solid a in primera)
                foreach (Solid b in segunda)
                {
                    if (!CajaSolido(a).Intersecta(CajaSolido(b))) continue;
                    if (++booleanas > MaxBooleanas)
                        throw new LimiteInterferenciasException("La comprobación de encuentros supera " + MaxBooleanas +
                            " comparaciones sólidas. Reduce el paño o los elementos de encuentro.");
                    double tolerancia = Math.Max(VolumenMinimo, Math.Min(a.Volume, b.Volume) * 1e-8);
                    using (Solid comun = BooleanOperationsUtils.ExecuteBooleanOperation(a, b, BooleanOperationsType.Intersect))
                        if (comun.Volume > tolerancia) return true;
                }
            return false;
        }

        private static Geometria LeerGeometria(Element elemento)
        {
            var resultado = new Geometria();
            try
            {
                using (var opciones = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false })
                    Recorrer(elemento.get_Geometry(opciones), Transform.Identity, resultado.Solidos);
                foreach (Solid solido in resultado.Solidos) resultado.Caja.Incluir(CajaSolido(solido));
                return resultado;
            }
            catch { resultado.Dispose(); throw; }
        }

        private static void Recorrer(GeometryElement geometria, Transform acumulada, List<Solid> resultado)
        {
            if (geometria == null) return;
            foreach (GeometryObject objeto in geometria)
            {
                Solid solido = objeto as Solid;
                if (solido != null && solido.Faces.Size > 0 && solido.Volume > 1e-12)
                    resultado.Add(SolidUtils.CreateTransformed(solido, acumulada));
                GeometryInstance instancia = objeto as GeometryInstance;
                if (instancia != null)
                    Recorrer(instancia.GetSymbolGeometry(), acumulada.Multiply(instancia.Transform), resultado);
            }
        }

        private static Rango CajaSolido(Solid solido)
        {
            var resultado = new Rango();
            using (BoundingBoxXYZ bb = solido.GetBoundingBox())
                for (int i = 0; i < 8; i++)
                    resultado.Incluir(bb.Transform.OfPoint(new XYZ((i & 1) == 0 ? bb.Min.X : bb.Max.X,
                        (i & 2) == 0 ? bb.Min.Y : bb.Max.Y, (i & 4) == 0 ? bb.Min.Z : bb.Max.Z)));
            return resultado;
        }

        private static Rango CajaElemento(Element elemento)
        {
            using (BoundingBoxXYZ bb = elemento.get_BoundingBox(null))
            {
                if (bb == null) return null;
                var resultado = new Rango();
                for (int i = 0; i < 8; i++)
                    resultado.Incluir(bb.Transform.OfPoint(new XYZ((i & 1) == 0 ? bb.Min.X : bb.Max.X,
                        (i & 2) == 0 ? bb.Min.Y : bb.Max.Y, (i & 4) == 0 ? bb.Min.Z : bb.Max.Z)));
                return resultado;
            }
        }

        private void Indexar(Objetivo objetivo)
        {
            long x0, x1, y0, y1;
            if (!Celdas(objetivo.Snapshot.Caja, out x0, out x1, out y0, out y1)) { grandes.Add(objetivo); return; }
            for (long x = x0; x <= x1; x++)
                for (long y = y0; y <= y1; y++)
                {
                    string clave = Clave(x, y);
                    List<Objetivo> lista;
                    if (!indice.TryGetValue(clave, out lista)) indice.Add(clave, lista = new List<Objetivo>());
                    lista.Add(objetivo);
                }
        }

        private IEnumerable<Objetivo> Candidatos(Rango caja)
        {
            long x0, x1, y0, y1;
            if (!Celdas(caja, out x0, out x1, out y0, out y1))
                return objetivos.Where(x => caja.Intersecta(x.Snapshot.Caja)).ToList();
            var encontrados = new HashSet<Objetivo>(grandes);
            for (long x = x0; x <= x1; x++)
                for (long y = y0; y <= y1; y++)
                {
                    List<Objetivo> lista;
                    if (indice.TryGetValue(Clave(x, y), out lista)) encontrados.UnionWith(lista);
                }
            return encontrados.Where(x => caja.Intersecta(x.Snapshot.Caja)).ToList();
        }

        private IEnumerable<Objetivo> CandidatosActuales(Rango caja)
        {
            if (objetivos.Count == 0) return new List<Objetivo>();
            // El filtro nativo evalúa las cajas ACTUALES de la lista completa
            // de objetivos, sin reutilizar el índice ni la caja del snapshot.
            // Solo descarta cajas separadas; después se comprueban sólidos netos.
            using (var contorno = new Outline(new XYZ(caja.MinX, caja.MinY, caja.MinZ),
                new XYZ(caja.MaxX, caja.MaxY, caja.MaxZ)))
            using (var filtro = new BoundingBoxIntersectsFilter(contorno, ToleranciaCaja))
            using (var collector = new FilteredElementCollector(documento, objetivos.Select(x => x.Id).ToList()))
            {
                var ids = new HashSet<ElementId>(collector.WherePasses(filtro).ToElementIds());
                return objetivos.Where(x => ids.Contains(x.Id)).ToList();
            }
        }

        private static bool Celdas(Rango caja, out long x0, out long x1, out long y0, out long y1)
        {
            x0 = (long)Math.Floor(caja.MinX / PasoIndice); x1 = (long)Math.Floor(caja.MaxX / PasoIndice);
            y0 = (long)Math.Floor(caja.MinY / PasoIndice); y1 = (long)Math.Floor(caja.MaxY / PasoIndice);
            return ((double)x1 - x0 + 1) * ((double)y1 - y0 + 1) <= 1000;
        }

        private static string Clave(long x, long y)
        {
            return x.ToString(System.Globalization.CultureInfo.InvariantCulture) + ":" +
                y.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        private static XYZ Punto(XYZ origen, XYZ u, XYZ v, double x, double y, double z)
        { return new XYZ(origen.X + u.X * x + v.X * y, origen.Y + u.Y * x + v.Y * y, z); }
        private static bool Finito(double x) { return !double.IsNaN(x) && !double.IsInfinity(x); }
        private void ComprobarDisponible()
        {
            if (disposed) throw new ObjectDisposedException(nameof(LadrillosInterferencias));
        }

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            foreach (Objetivo objetivo in objetivos) objetivo.Snapshot.Dispose();
            objetivos.Clear(); indice.Clear(); grandes.Clear();
        }

        private sealed class Objetivo
        {
            internal ElementId Id;
            internal Geometria Snapshot;
        }

        private sealed class LimiteInterferenciasException : InvalidOperationException
        {
            internal LimiteInterferenciasException(string mensaje) : base(mensaje) { }
        }

        private sealed class Geometria : IDisposable
        {
            internal readonly List<Solid> Solidos = new List<Solid>();
            internal readonly Rango Caja = new Rango();
            public void Dispose() { foreach (Solid solido in Solidos) solido.Dispose(); Solidos.Clear(); }
        }

        private sealed class Rango
        {
            internal double MinX = double.PositiveInfinity, MinY = double.PositiveInfinity, MinZ = double.PositiveInfinity;
            internal double MaxX = double.NegativeInfinity, MaxY = double.NegativeInfinity, MaxZ = double.NegativeInfinity;
            internal void Incluir(XYZ p)
            {
                MinX = Math.Min(MinX, p.X); MinY = Math.Min(MinY, p.Y); MinZ = Math.Min(MinZ, p.Z);
                MaxX = Math.Max(MaxX, p.X); MaxY = Math.Max(MaxY, p.Y); MaxZ = Math.Max(MaxZ, p.Z);
            }
            internal void Incluir(Rango b) { Incluir(new XYZ(b.MinX, b.MinY, b.MinZ)); Incluir(new XYZ(b.MaxX, b.MaxY, b.MaxZ)); }
            internal bool Intersecta(Rango b)
            {
                return MinX <= b.MaxX + ToleranciaCaja && MaxX >= b.MinX - ToleranciaCaja &&
                    MinY <= b.MaxY + ToleranciaCaja && MaxY >= b.MinY - ToleranciaCaja &&
                    MinZ <= b.MaxZ + ToleranciaCaja && MaxZ >= b.MinZ - ToleranciaCaja;
            }
        }
    }
}
