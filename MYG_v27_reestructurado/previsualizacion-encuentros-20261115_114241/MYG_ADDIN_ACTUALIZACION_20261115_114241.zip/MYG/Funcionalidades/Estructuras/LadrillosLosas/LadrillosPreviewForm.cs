using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using Forms = System.Windows.Forms;

namespace MYG_Addin
{
    internal sealed class LadrilloVista
    {
        internal LadrilloPunto Centro = new LadrilloPunto(0, 0);
        internal bool Interfiere = false;
        internal bool Incluir = true;
        internal int Obstaculos = 0;
    }

    /// <summary>
    /// Vista de huellas en el plano de las filas. No modifica el documento Revit:
    /// confirma la selección manual y la acción solicitada para los encuentros.
    /// Los cruces previstos se verifican después con la geometría real creada.
    /// </summary>
    internal sealed class LadrillosPreviewForm : Forms.Form
    {
        private readonly IList<IList<LadrilloPunto>> contornos;
        private readonly IList<IList<LadrilloPunto>> huellasObstaculos;
        private readonly List<LadrilloVista> piezas;
        private readonly double largo;
        private readonly double ancho;
        private readonly Lienzo lienzo = new Lienzo();
        private readonly Forms.ComboBox modo = new Forms.ComboBox();
        private readonly Forms.Label conteo = new Forms.Label();
        private readonly Forms.Label detalleModo = new Forms.Label();
        private readonly Forms.Label zoomTexto = new Forms.Label();
        private readonly Forms.Button crear = new Forms.Button();
        private readonly Forms.ToolTip ayuda = new Forms.ToolTip();
        private double escala = 1;
        private double offsetX;
        private double offsetY;
        private bool vistaAjustada;
        private bool arrastrando;
        private Point ultimoRaton;
        private Point inicioClic;
        private int piezaClic = -1;
        private int ultimoHover = -2;
        private Size tamanoAnterior;

        internal ModoEncuentroLadrillos ModoSeleccionado
        {
            get
            {
                var opcion = modo.SelectedItem as OpcionModo;
                return opcion == null ? ModoEncuentroLadrillos.Omitir : opcion.Valor;
            }
        }

        // No se quitan aquí las huellas marcadas como conflicto: la predicción
        // rectangular puede ser conservadora. El motor usa los sólidos reales.
        internal List<LadrilloPunto> Seleccionadas
        {
            get { return piezas.Where(x => x.Incluir).Select(x => x.Centro).ToList(); }
        }

        internal LadrillosPreviewForm(IList<IList<LadrilloPunto>> contornos,
            List<LadrilloVista> piezas, double largo, double ancho,
            IList<IList<LadrilloPunto>> huellasObstaculos, string resumen,
            ModoEncuentroLadrillos modoInicial)
        {
            if (contornos == null || piezas == null)
                throw new ArgumentNullException("contornos", "La previsualización necesita los contornos y las piezas.");
            if (!Finito(largo) || !Finito(ancho) || largo <= 0 || ancho <= 0)
                throw new ArgumentOutOfRangeException("largo", "La huella debe tener dimensiones positivas y finitas.");
            if (piezas.Any(x => x == null || !Finito(x.Centro.X) || !Finito(x.Centro.Y)))
                throw new ArgumentException("Las piezas deben tener centros finitos.", "piezas");
            this.contornos = contornos;
            this.piezas = piezas;
            this.largo = largo;
            this.ancho = ancho;
            this.huellasObstaculos = huellasObstaculos ?? new List<IList<LadrilloPunto>>();

            Text = "MYG · Previsualización de ladrillos";
            Font = new Font("Segoe UI", 9F);
            StartPosition = Forms.FormStartPosition.CenterScreen;
            AutoScaleMode = Forms.AutoScaleMode.Font;
            ClientSize = new Size(1060, 700);
            MinimumSize = new Size(900, 700);
            MinimizeBox = false;

            var raiz = new Forms.TableLayoutPanel
            {
                Dock = Forms.DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 3,
                Padding = new Forms.Padding(12)
            };
            raiz.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            raiz.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Absolute, 290));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 42));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Percent, 100));
            raiz.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 48));
            Controls.Add(raiz);

            var instrucciones = new Forms.Label
            {
                Dock = Forms.DockStyle.Fill,
                Text = "Revisa la distribución antes de crear. Clic en un ladrillo: incluir/excluir. " +
                    "Rueda: acercar. Arrastrar con botón central o sobre fondo vacío: desplazar.",
                TextAlign = ContentAlignment.MiddleLeft
            };
            raiz.Controls.Add(instrucciones, 0, 0);
            raiz.SetColumnSpan(instrucciones, 2);
            lienzo.Dock = Forms.DockStyle.Fill;
            lienzo.Margin = new Forms.Padding(0, 0, 12, 0);
            lienzo.BackColor = Color.FromArgb(247, 249, 251);
            lienzo.TabStop = true;
            raiz.Controls.Add(lienzo, 0, 1);

            var lateral = new Forms.TableLayoutPanel
            {
                Dock = Forms.DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 8,
                Margin = Forms.Padding.Empty
            };
            lateral.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 94));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 66));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 24));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 36));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 94));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 70));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Percent, 100));
            lateral.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 44));
            raiz.Controls.Add(lateral, 1, 1);
            lateral.Controls.Add(new Forms.TextBox
            {
                Dock = Forms.DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                WordWrap = true,
                ScrollBars = Forms.ScrollBars.Vertical,
                BackColor = SystemColors.Window,
                ForeColor = SystemColors.WindowText,
                Text = (resumen ?? "") + "\r\nHuella: " + Cm(largo) + " × " + Cm(ancho) + " cm.",
                Margin = new Forms.Padding(0, 0, 0, 6)
            }, 0, 0);
            conteo.Dock = Forms.DockStyle.Fill;
            conteo.ForeColor = Color.FromArgb(24, 73, 108);
            lateral.Controls.Add(conteo, 0, 1);
            lateral.Controls.Add(new Forms.Label
            {
                Text = "Encuentros con otros elementos",
                Dock = Forms.DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            }, 0, 2);
            modo.Dock = Forms.DockStyle.Fill;
            modo.DropDownStyle = Forms.ComboBoxStyle.DropDownList;
            modo.DisplayMember = "Texto";
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.SoloDetectar, "Solo detectar (mantiene interferencias)"));
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.Omitir, "Omitir ladrillos en conflicto"));
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.Unir, "Unir: vecino recorta ladrillo"));
            modo.Items.Add(new OpcionModo(ModoEncuentroLadrillos.Cortar, "Cortar ladrillo con vecino"));
            modo.SelectedIndex = 1;
            for (int i = 0; i < modo.Items.Count; i++)
                if (((OpcionModo)modo.Items[i]).Valor == modoInicial)
                    modo.SelectedIndex = i;
            lateral.Controls.Add(modo, 0, 3);
            detalleModo.Dock = Forms.DockStyle.Fill;
            detalleModo.Padding = new Forms.Padding(0, 4, 0, 0);
            lateral.Controls.Add(detalleModo, 0, 4);
            lateral.Controls.Add(new Forms.Label
            {
                Dock = Forms.DockStyle.Fill,
                Text = "Verde: sin cruce previsto.\r\nNaranja/rojo: posible interferencia.\r\nGris: excluido manualmente.\r\nVioleta: huella de elemento vecino."
            }, 0, 5);
            lateral.Controls.Add(new Forms.Label
            {
                Dock = Forms.DockStyle.Fill,
                Padding = new Forms.Padding(0, 8, 0, 0),
                Text = "Vista 2D de huellas, no una sección 3D. Los cruces marcados se verifican " +
                    "después con los sólidos reales. Revit puede no admitir unir o cortar esta familia; " +
                    "las piezas que no puedan resolverse se omiten."
            }, 0, 6);
            var seleccion = new Forms.FlowLayoutPanel { Dock = Forms.DockStyle.Fill, WrapContents = false };
            var todas = new Forms.Button { Text = "Incluir todas", AutoSize = true };
            var ninguna = new Forms.Button { Text = "Excluir todas", AutoSize = true };
            seleccion.Controls.Add(todas);
            seleccion.Controls.Add(ninguna);
            lateral.Controls.Add(seleccion, 0, 7);

            var barra = new Forms.FlowLayoutPanel
            {
                Dock = Forms.DockStyle.Fill,
                FlowDirection = Forms.FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Forms.Padding(0, 7, 0, 0)
            };
            var ajustar = new Forms.Button { Text = "Ajustar vista", AutoSize = true };
            zoomTexto.AutoSize = true;
            zoomTexto.Padding = new Forms.Padding(8, 7, 0, 0);
            barra.Controls.Add(ajustar);
            barra.Controls.Add(zoomTexto);
            raiz.Controls.Add(barra, 0, 2);
            var acciones = new Forms.FlowLayoutPanel
            {
                Dock = Forms.DockStyle.Fill,
                FlowDirection = Forms.FlowDirection.RightToLeft,
                WrapContents = false,
                Padding = new Forms.Padding(0, 7, 0, 0)
            };
            var cancelar = new Forms.Button { Text = "Cancelar", DialogResult = Forms.DialogResult.Cancel, AutoSize = true };
            crear.Text = "Crear selección";
            crear.AutoSize = true;
            acciones.Controls.Add(cancelar);
            acciones.Controls.Add(crear);
            raiz.Controls.Add(acciones, 1, 2);
            AcceptButton = crear;
            CancelButton = cancelar;
            crear.Click += delegate
            {
                if (piezas.Any(x => x.Incluir))
                {
                    DialogResult = Forms.DialogResult.OK;
                    Close();
                }
            };
            todas.Click += delegate { foreach (var pieza in piezas) pieza.Incluir = true; Actualizar(); };
            ninguna.Click += delegate { foreach (var pieza in piezas) pieza.Incluir = false; Actualizar(); };
            ajustar.Click += delegate { AjustarVista(); };
            modo.SelectedIndexChanged += delegate { Actualizar(); };
            lienzo.Paint += Pintar;
            lienzo.MouseDown += RatonAbajo;
            lienzo.MouseUp += RatonArriba;
            lienzo.MouseMove += MoverRaton;
            lienzo.MouseWheel += Rueda;
            lienzo.MouseEnter += delegate { lienzo.Focus(); };
            lienzo.MouseLeave += delegate { ayuda.Hide(lienzo); ultimoHover = -2; };
            lienzo.MouseCaptureChanged += delegate
            {
                if (!lienzo.Capture) { arrastrando = false; piezaClic = -1; lienzo.Cursor = Forms.Cursors.Default; }
            };
            lienzo.KeyDown += delegate(object sender, Forms.KeyEventArgs e)
            {
                if (e.KeyCode == Forms.Keys.Home) { AjustarVista(); e.Handled = true; }
            };
            lienzo.Resize += delegate
            {
                if (!vistaAjustada) return;
                offsetX += (lienzo.ClientSize.Width - tamanoAnterior.Width) / 2.0;
                offsetY += (lienzo.ClientSize.Height - tamanoAnterior.Height) / 2.0;
                tamanoAnterior = lienzo.ClientSize;
                lienzo.Invalidate();
            };
            Shown += delegate { AjustarVista(); };
            Actualizar();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) ayuda.Dispose();
            base.Dispose(disposing);
        }

        private void Actualizar()
        {
            ultimoHover = -2;
            int incluidas = piezas.Count(x => x.Incluir);
            int conflictos = piezas.Count(x => x.Incluir && x.Interfiere);
            conteo.Text = "Seleccionadas: " + incluidas + " de " + piezas.Count +
                "\r\nCon posible cruce: " + conflictos +
                "\r\nExcluidas manualmente: " + (piezas.Count - incluidas);
            crear.Enabled = incluidas > 0;
            switch (ModoSeleccionado)
            {
                case ModoEncuentroLadrillos.SoloDetectar:
                    detalleModo.Text = "Se crearán las piezas seleccionadas y se informarán los cruces. " +
                        "Este modo puede conservar interferencias.";
                    break;
                case ModoEncuentroLadrillos.Omitir:
                    detalleModo.Text = "No se crean ladrillos cuya geometría real interfiera con los elementos considerados.";
                    break;
                case ModoEncuentroLadrillos.Unir:
                    detalleModo.Text = "Intenta unir dando prioridad al vecino para recortar el ladrillo. " +
                        "Si Revit no lo admite o queda un cruce, se omite la pieza.";
                    break;
                default:
                    detalleModo.Text = "Intenta cortar el ladrillo con el elemento vecino. " +
                        "Si Revit no lo admite o queda un cruce, se omite la pieza.";
                    break;
            }
            lienzo.Invalidate();
        }

        private void AjustarVista()
        {
            // Ajustar a la losa, no a toda la extensión de una viga o muro
            // vecino que puede continuar muchos metros fuera del paño.
            var puntos = contornos.Where(x => x != null).SelectMany(x => x).ToList();
            foreach (var pieza in piezas)
            {
                puntos.Add(new LadrilloPunto(pieza.Centro.X - largo / 2, pieza.Centro.Y - ancho / 2));
                puntos.Add(new LadrilloPunto(pieza.Centro.X + largo / 2, pieza.Centro.Y + ancho / 2));
            }
            puntos = puntos.Where(x => Finito(x.X) && Finito(x.Y)).ToList();
            if (puntos.Count == 0 || lienzo.ClientSize.Width <= 0 || lienzo.ClientSize.Height <= 0) return;
            double minX = puntos.Min(x => x.X), maxX = puntos.Max(x => x.X);
            double minY = puntos.Min(x => x.Y), maxY = puntos.Max(x => x.Y);
            double margen = 48;
            escala = Math.Max(0.00001, Math.Min(200000,
                Math.Min(Math.Max(1, lienzo.ClientSize.Width - 2 * margen) / Math.Max(maxX - minX, 0.1),
                    Math.Max(1, lienzo.ClientSize.Height - 2 * margen) / Math.Max(maxY - minY, 0.1))));
            offsetX = lienzo.ClientSize.Width / 2.0 - (minX + maxX) / 2 * escala;
            offsetY = lienzo.ClientSize.Height / 2.0 + (minY + maxY) / 2 * escala;
            vistaAjustada = true;
            tamanoAnterior = lienzo.ClientSize;
            ActualizarZoom();
            lienzo.Invalidate();
        }

        private void Pintar(object sender, Forms.PaintEventArgs e)
        {
            if (!vistaAjustada) return;
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var rellenoSuelo = new SolidBrush(Color.FromArgb(229, 234, 239)))
            using (var bordeSuelo = new Pen(Color.FromArgb(107, 120, 132), 1.5F))
            using (var normal = new SolidBrush(Color.FromArgb(105, 196, 143)))
            using (var cruce = new SolidBrush(ModoSeleccionado == ModoEncuentroLadrillos.SoloDetectar ||
                ModoSeleccionado == ModoEncuentroLadrillos.Omitir ? Color.FromArgb(230, 139, 118) : Color.FromArgb(245, 186, 84)))
            using (var excluida = new SolidBrush(Color.FromArgb(211, 216, 221)))
            using (var borde = new Pen(Color.FromArgb(54, 105, 78), 0.8F))
            using (var bordeExcluida = new Pen(Color.FromArgb(132, 141, 150), 0.8F) { DashStyle = DashStyle.Dot })
            using (var vecino = new Pen(Color.FromArgb(139, 77, 172), 1.6F))
            using (var rellenoVecino = new SolidBrush(Color.FromArgb(28, 139, 77, 172)))
            {
                using (var area = Camino(contornos))
                {
                    if (area.PointCount > 0)
                    {
                        g.FillPath(rellenoSuelo, area);
                        g.DrawPath(bordeSuelo, area);
                    }
                }
                foreach (var pieza in piezas)
                {
                    RectangleF r = Rectangulo(pieza);
                    if (!r.IntersectsWith(lienzo.ClientRectangle)) continue;
                    g.FillRectangle(!pieza.Incluir ? excluida : pieza.Interfiere ? cruce : normal, r);
                    g.DrawRectangle(pieza.Incluir ? borde : bordeExcluida, r.X, r.Y, r.Width, r.Height);
                }
                foreach (var huella in huellasObstaculos)
                {
                    if (huella == null || huella.Count < 3) continue;
                    using (var camino = Camino(new List<IList<LadrilloPunto>> { huella }))
                    {
                        g.FillPath(rellenoVecino, camino);
                        g.DrawPath(vecino, camino);
                    }
                }
            }
            // Referencia fija de la dirección U; las filas horizontales del dibujo
            // corresponden a los dos puntos elegidos en el modelo.
            using (var flecha = new Pen(Color.FromArgb(30, 88, 135), 2F))
            using (var punta = new AdjustableArrowCap(4, 5, true))
            {
                flecha.CustomEndCap = punta;
                int y = Math.Max(35, lienzo.ClientSize.Height - 24);
                g.DrawLine(flecha, 18, y, 78, y);
                g.DrawString("U · filas / viguetas", Font, Brushes.DimGray, 88, y - 8);
            }
        }

        private GraphicsPath Camino(IEnumerable<IList<LadrilloPunto>> anillos)
        {
            var camino = new GraphicsPath(FillMode.Alternate);
            foreach (var anillo in anillos)
            {
                if (anillo == null || anillo.Count < 3) continue;
                PointF[] puntos = anillo.Where(x => Finito(x.X) && Finito(x.Y)).Select(Pantalla).ToArray();
                if (puntos.Length >= 3) camino.AddPolygon(puntos);
            }
            return camino;
        }

        private RectangleF Rectangulo(LadrilloVista pieza)
        {
            PointF arriba = Pantalla(new LadrilloPunto(pieza.Centro.X - largo / 2, pieza.Centro.Y + ancho / 2));
            PointF abajo = Pantalla(new LadrilloPunto(pieza.Centro.X + largo / 2, pieza.Centro.Y - ancho / 2));
            return RectangleF.FromLTRB(arriba.X, arriba.Y, abajo.X, abajo.Y);
        }

        private PointF Pantalla(LadrilloPunto punto)
        {
            return new PointF(Pixel(offsetX + punto.X * escala), Pixel(offsetY - punto.Y * escala));
        }

        private LadrilloPunto Modelo(Point punto)
        {
            return new LadrilloPunto((punto.X - offsetX) / escala, (offsetY - punto.Y) / escala);
        }

        private int Buscar(Point punto)
        {
            LadrilloPunto uv = Modelo(punto);
            for (int i = piezas.Count - 1; i >= 0; i--)
                if (Math.Abs(uv.X - piezas[i].Centro.X) <= largo / 2 &&
                    Math.Abs(uv.Y - piezas[i].Centro.Y) <= ancho / 2)
                    return i;
            return -1;
        }

        private void RatonAbajo(object sender, Forms.MouseEventArgs e)
        {
            if (!vistaAjustada) return;
            lienzo.Focus();
            ayuda.Hide(lienzo);
            inicioClic = ultimoRaton = e.Location;
            piezaClic = e.Button == Forms.MouseButtons.Left ? Buscar(e.Location) : -1;
            arrastrando = e.Button == Forms.MouseButtons.Middle ||
                (e.Button == Forms.MouseButtons.Left && piezaClic < 0);
            if (e.Button == Forms.MouseButtons.Left || e.Button == Forms.MouseButtons.Middle)
                lienzo.Capture = true;
            if (arrastrando) lienzo.Cursor = Forms.Cursors.Hand;
        }

        private void RatonArriba(object sender, Forms.MouseEventArgs e)
        {
            if (e.Button != Forms.MouseButtons.Left && e.Button != Forms.MouseButtons.Middle) return;
            if (!arrastrando && e.Button == Forms.MouseButtons.Left && piezaClic >= 0 &&
                Math.Abs(e.X - inicioClic.X) <= 4 && Math.Abs(e.Y - inicioClic.Y) <= 4 &&
                Buscar(e.Location) == piezaClic)
            {
                piezas[piezaClic].Incluir = !piezas[piezaClic].Incluir;
                Actualizar();
            }
            arrastrando = false;
            piezaClic = -1;
            lienzo.Capture = false;
            lienzo.Cursor = Forms.Cursors.Default;
        }

        private void MoverRaton(object sender, Forms.MouseEventArgs e)
        {
            if (!vistaAjustada) return;
            if (arrastrando)
            {
                offsetX += e.X - ultimoRaton.X;
                offsetY += e.Y - ultimoRaton.Y;
                ultimoRaton = e.Location;
                lienzo.Invalidate();
                return;
            }
            int indice = Buscar(e.Location);
            if (indice == ultimoHover) return;
            ultimoHover = indice;
            if (indice < 0) { ayuda.Hide(lienzo); lienzo.Cursor = Forms.Cursors.Default; return; }
            var pieza = piezas[indice];
            lienzo.Cursor = Forms.Cursors.Hand;
            ayuda.SetToolTip(lienzo, "Ladrillo " + (indice + 1) + " · " + (pieza.Incluir ? "incluido" : "excluido") +
                "\r\nCentro U/V: " + Cm(pieza.Centro.X) + " / " + Cm(pieza.Centro.Y) + " cm" +
                "\r\nElementos en posible cruce: " + pieza.Obstaculos + "\r\nClic para cambiar selección.");
        }

        private void Rueda(object sender, Forms.MouseEventArgs e)
        {
            if (!vistaAjustada) return;
            LadrilloPunto ancla = Modelo(e.Location);
            double nueva = Math.Max(0.00001, Math.Min(200000, escala * Math.Pow(1.2, e.Delta / 120.0)));
            offsetX = e.X - ancla.X * nueva;
            offsetY = e.Y + ancla.Y * nueva;
            escala = nueva;
            ayuda.Hide(lienzo);
            ultimoHover = -2;
            ActualizarZoom();
            lienzo.Invalidate();
        }

        private void ActualizarZoom()
        {
            zoomTexto.Text = "Escala: " + (escala / 30.48).ToString("0.###", CultureInfo.CurrentCulture) + " px/cm · Inicio: ajustar";
        }

        private static bool Finito(double valor) { return !double.IsNaN(valor) && !double.IsInfinity(valor); }
        private static float Pixel(double valor) { return (float)Math.Max(-1000000, Math.Min(1000000, valor)); }
        private static string Cm(double pies) { return (pies * 30.48).ToString("0.##", CultureInfo.CurrentCulture); }

        private sealed class OpcionModo
        {
            internal readonly ModoEncuentroLadrillos Valor;
            public string Texto { get; private set; }
            internal OpcionModo(ModoEncuentroLadrillos valor, string texto) { Valor = valor; Texto = texto; }
        }

        private sealed class Lienzo : Forms.Control
        {
            internal Lienzo()
            {
                SetStyle(Forms.ControlStyles.UserPaint | Forms.ControlStyles.AllPaintingInWmPaint |
                    Forms.ControlStyles.OptimizedDoubleBuffer | Forms.ControlStyles.ResizeRedraw, true);
                UpdateStyles();
            }
        }
    }
}
