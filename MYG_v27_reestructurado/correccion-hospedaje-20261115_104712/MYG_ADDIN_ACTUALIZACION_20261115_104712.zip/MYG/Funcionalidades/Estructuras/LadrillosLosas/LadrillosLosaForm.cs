using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Autodesk.Revit.DB;
using Forms = System.Windows.Forms;
using Media = System.Windows.Media;

namespace MYG_Addin
{
    internal sealed class LadrillosLosaOpciones
    {
        internal ElementId TipoId { get; set; }
        internal string ArchivoFamilia { get; set; }
        internal double ViguetaCm { get; set; } = 10;
        internal double JuntaCm { get; set; }
        internal double MargenCm { get; set; }
        internal double DesfaseBaseCm { get; set; }
        internal bool Girar90 { get; set; }
        internal bool AjustarBaseAlIntrados { get; set; }
    }

    internal sealed class LadrillosLosaForm : Forms.Form
    {
        private readonly Forms.ComboBox tipos = new Forms.ComboBox();
        private readonly Forms.TextBox archivo = new Forms.TextBox();
        private readonly Forms.NumericUpDown vigueta = Numero(10, 1000);
        private readonly Forms.NumericUpDown junta = Numero(0, 1000);
        private readonly Forms.NumericUpDown margen = Numero(0, 1000);
        private readonly Forms.NumericUpDown desfase = Numero(0, 1000);
        private readonly Forms.CheckBox giro = new Forms.CheckBox();
        private readonly Forms.CheckBox ajustarBase = new Forms.CheckBox();

        internal LadrillosLosaOpciones Opciones { get; private set; }

        internal LadrillosLosaForm(IList<FamilySymbol> simbolos)
        {
            Text = "MYG · Ladrillos en losa";
            Font = new Font("Segoe UI", 9F);
            StartPosition = Forms.FormStartPosition.CenterScreen;
            FormBorderStyle = Forms.FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            AutoScaleMode = Forms.AutoScaleMode.Font;
            ClientSize = new Size(700, 540);

            var tabla = new Forms.TableLayoutPanel
            {
                Dock = Forms.DockStyle.Fill,
                Padding = new Forms.Padding(16),
                ColumnCount = 2,
                RowCount = 10
            };
            tabla.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Absolute, 260));
            tabla.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            for (int i = 0; i < 8; i++)
                tabla.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 36));
            tabla.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Percent, 100));
            tabla.RowStyles.Add(new Forms.RowStyle(Forms.SizeType.Absolute, 40));
            Controls.Add(tabla);

            tipos.DropDownStyle = Forms.ComboBoxStyle.DropDownList;
            tipos.DisplayMember = "Etiqueta";
            tipos.Items.Add(new OpcionTipo(null, "Cargar familia desde archivo .rfa…"));
            foreach (var simbolo in simbolos.OrderBy(x => x.Family.Name).ThenBy(x => x.Name))
                tipos.Items.Add(new OpcionTipo(simbolo.Id, simbolo.Family.Name + " : " + simbolo.Name,
                    simbolo.Family.FamilyPlacementType == FamilyPlacementType.OneLevelBasedHosted));
            tipos.SelectedIndex = 0;
            // Preferir ladrillos existentes; no elegir automáticamente otro modelo genérico.
            for (int i = 1; i < tipos.Items.Count; i++)
                if (((OpcionTipo)tipos.Items[i]).Etiqueta.IndexOf("ladrillo", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    tipos.SelectedIndex = i;
                    break;
                }
            Agregar(tabla, 0, "Tipo de ladrillo cargado", tipos);

            archivo.ReadOnly = true;
            archivo.Dock = Forms.DockStyle.Fill;
            var buscar = new Forms.Button { Text = "Examinar…", AutoSize = true };
            var filaArchivo = new Forms.TableLayoutPanel { Dock = Forms.DockStyle.Fill, ColumnCount = 2, Margin = Forms.Padding.Empty };
            filaArchivo.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.Percent, 100));
            filaArchivo.ColumnStyles.Add(new Forms.ColumnStyle(Forms.SizeType.AutoSize));
            filaArchivo.Controls.Add(archivo, 0, 0);
            filaArchivo.Controls.Add(buscar, 1, 0);
            Agregar(tabla, 1, "O cargar familia .rfa", filaArchivo);
            buscar.Click += delegate
            {
                using (var dialogo = new Forms.OpenFileDialog
                {
                    Filter = "Familia de Revit (*.rfa)|*.rfa",
                    Title = "Selecciona la familia de ladrillo",
                    CheckFileExists = true,
                    Multiselect = false
                })
                    if (dialogo.ShowDialog(this) == Forms.DialogResult.OK)
                    {
                        archivo.Text = dialogo.FileName;
                        tipos.SelectedIndex = 0;
                    }
            };
            tipos.SelectedIndexChanged += delegate { filaArchivo.Enabled = tipos.SelectedIndex == 0; };
            filaArchivo.Enabled = tipos.SelectedIndex == 0;

            Agregar(tabla, 2, "Ancho libre de vigueta entre filas (cm)", vigueta);
            Agregar(tabla, 3, "Junta entre ladrillos de una fila (cm)", junta);
            Agregar(tabla, 4, "Margen libre a bordes y huecos (cm)", margen);
            ajustarBase.Text = "Ajustar la base al intradós de la losa";
            ajustarBase.AutoSize = true;
            ajustarBase.Checked = false;
            Agregar(tabla, 5, "Altura de familias hospedadas", ajustarBase);
            Agregar(tabla, 6, "Desfase sobre intradós (cm, con ajuste)", desfase);
            // Sin ajuste, una familia hospedada conserva su colocación vertical
            // propia, igual que al insertarla manualmente sobre el suelo.
            // Una familia sin anfitrión utiliza siempre el ajuste al intradós.
            Action actualizarDesfase = delegate
            {
                var opcion = tipos.SelectedItem as OpcionTipo;
                desfase.Enabled = ajustarBase.Checked || (opcion != null && !opcion.Hospedado && opcion.Id != null);
            };
            ajustarBase.CheckedChanged += delegate { actualizarDesfase(); };
            tipos.SelectedIndexChanged += delegate { actualizarDesfase(); };
            actualizarDesfase();
            giro.Text = "Girar familia 90° respecto a la fila";
            giro.AutoSize = true;
            Agregar(tabla, 7, "Orientación de la familia", giro);

            var nota = new Forms.Label
            {
                Dock = Forms.DockStyle.Fill,
                Text = "Después, selecciona una losa horizontal en planta y marca dos puntos. " +
                    "El primero fija una esquina de la malla; el segundo indica la dirección de las filas/viguetas.\r\n\r\n" +
                    "Las familias hospedadas conservan por defecto su altura de colocación manual. " +
                    "Activa el ajuste solo si quieres llevar su base al intradós. " +
                    "Las familias sin anfitrión se ajustan siempre al intradós. " +
                    "Se colocan piezas completas dentro del contorno, sin cruzar huecos.",
                Padding = new Forms.Padding(0, 8, 0, 0)
            };
            tabla.Controls.Add(nota, 0, 8);
            tabla.SetColumnSpan(nota, 2);
            var botones = new Forms.FlowLayoutPanel { Dock = Forms.DockStyle.Fill, FlowDirection = Forms.FlowDirection.RightToLeft };
            var continuar = new Forms.Button { Text = "Continuar", AutoSize = true };
            var cancelar = new Forms.Button { Text = "Cancelar", DialogResult = Forms.DialogResult.Cancel, AutoSize = true };
            botones.Controls.Add(cancelar);
            botones.Controls.Add(continuar);
            tabla.Controls.Add(botones, 0, 9);
            tabla.SetColumnSpan(botones, 2);
            AcceptButton = continuar;
            CancelButton = cancelar;
            continuar.Click += delegate { Aceptar(); };
        }

        private void Aceptar()
        {
            var elegido = tipos.SelectedItem as OpcionTipo;
            if (elegido == null || (elegido.Id == null && !System.IO.File.Exists(archivo.Text)))
            {
                Forms.MessageBox.Show(this, "Selecciona un tipo cargado o un archivo .rfa válido.", Text,
                    Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Information);
                return;
            }
            Opciones = new LadrillosLosaOpciones
            {
                TipoId = elegido.Id,
                ArchivoFamilia = elegido.Id == null ? archivo.Text : null,
                ViguetaCm = (double)vigueta.Value,
                JuntaCm = (double)junta.Value,
                MargenCm = (double)margen.Value,
                DesfaseBaseCm = (double)desfase.Value,
                Girar90 = giro.Checked,
                AjustarBaseAlIntrados = ajustarBase.Checked
            };
            DialogResult = Forms.DialogResult.OK;
            Close();
        }

        private static Forms.NumericUpDown Numero(decimal inicial, decimal maximo)
        {
            return new Forms.NumericUpDown { Minimum = 0, Maximum = maximo, DecimalPlaces = 2, Increment = 0.5M, Value = inicial };
        }

        private static void Agregar(Forms.TableLayoutPanel tabla, int fila, string etiqueta, Forms.Control control)
        {
            tabla.Controls.Add(new Forms.Label { Text = etiqueta, Dock = Forms.DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, fila);
            control.Dock = Forms.DockStyle.Fill;
            tabla.Controls.Add(control, 1, fila);
        }

        private sealed class OpcionTipo
        {
            internal ElementId Id { get; private set; }
            internal bool Hospedado { get; private set; }
            public string Etiqueta { get; private set; }
            internal OpcionTipo(ElementId id, string etiqueta, bool hospedado = true)
            { Id = id; Etiqueta = etiqueta; Hospedado = hospedado; }
        }

        internal static Media.ImageSource CrearIcono()
        {
            var dibujo = new Media.DrawingGroup();
            var borde = new Media.Pen(Media.Brushes.SaddleBrown, 0.8);
            for (int fila = 0; fila < 3; fila++)
                for (int col = 0; col < 2; col++)
                {
                    double x = 2 + col * 16, y = 2 + fila * 10;
                    dibujo.Children.Add(new Media.GeometryDrawing(Media.Brushes.SandyBrown, borde,
                        new Media.RectangleGeometry(new System.Windows.Rect(x, y, 12, 7), 1, 1)));
                    for (int hueco = 0; hueco < 3; hueco++)
                        dibujo.Children.Add(new Media.GeometryDrawing(Media.Brushes.SaddleBrown, null,
                            new Media.RectangleGeometry(new System.Windows.Rect(x + 2 + hueco * 3, y + 2, 1.5, 3))));
                }
            dibujo.Freeze();
            var imagen = new Media.DrawingImage(dibujo);
            imagen.Freeze();
            return imagen;
        }
    }
}
