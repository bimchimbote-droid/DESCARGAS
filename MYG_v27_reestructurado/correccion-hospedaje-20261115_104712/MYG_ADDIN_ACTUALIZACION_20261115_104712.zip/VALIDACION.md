# Validación de la corrección de hospedaje

## Ejecutado
- 44 pruebas de la lógica real:27 de distribución+17 de altura; cero fallos. El helper LadrillosAltura es el que invoca el comando. No se sustituyeron las pruebas geométricas existentes.
- Compilación aislada C#7.3 contra API Revit2027 y referencias Windows:0 errores/0 advertencias. No equivale a compilar el proyecto original completo ni a ejecutar Revit.
- Análisis Roslyn de186 fuentes sin errores; rutas del proyecto completas y sin duplicados.
- Compilación completa intentada: falla MSB4803 en ResolveComReference porque este entorno es Linux/MSBuild .NET Core. Permanece MSB3277 de EPPlus.Interfaces.
- Revisión estática: sin ComprobarVolumenSuelo ni CopyElement, creación hospedada directa sin nivel impuesto; no hay llamadas a API de corte del documento. Se mantienen comprobaciones de anfitrión, huella, alineación/dimensiones, solapamientos, límites y rollback.

## Repetir pruebas automatizadas
Usa el proyecto de pruebas de la entrega anterior con el nuevo Program.cs y el nuevo LadrillosLayout.cs, manteniendo las rutas:
```bash
dotnet restore Pruebas/LadrillosLosas/BrickLayout.Tests.csproj --configfile Pruebas/LadrillosLosas/NuGet.Config
dotnet run --no-restore --project Pruebas/LadrillosLosas/BrickLayout.Tests.csproj
```
Requiere SDK .NET10, sin nuevos paquetes. El ejecutable devuelve código no cero ante cualquier fallo.

## Pendiente en Revit
1. Sobre copia del modelo, coloca manualmente una instancia de la familia hospedada en suelo y registra su elevación/offset/host.
2. Ejecuta el nuevo comando con Ajustar la base al intradós DESMARCADO sobre esa losa. Confirma que el mensaje de volumen anterior no aparece y que las instancias mantienen el mismo hospedaje/elevación que el uso manual.
3. Comprueba dirección oblicua, giro90°, separación10cm, contorno/huecos y número de instancias.
4. Repite para comprobar omisión de solapamientos; verifica que la plantilla temporal no quede en el documento.
5. Prueba ajuste al intradós activado y familias sin anfitrión: altura/desfase dentro del espesor; comprueba rechazo claro si no caben.
6. Cancela en selección y confirmación; comprueba rollback de piezas/carga de familia y un solo Deshacer en ejecución completada.
7. Compara los efectos del anfitrión con los que produce la colocación manual. No se ha identificado/reproducido aquí la causa concreta de la variación de volumen del modelo del usuario.
