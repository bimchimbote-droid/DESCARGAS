using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin;

internal static class Program
{
    private static int passed;
    private static int failed;

    private static void Main()
    {
        Run("simple rectangle, exact boundary contact", () => Count(Domain(Rect(0, 0, 10, 10)), 2, 2) == 25);
        Run("negative grid indices from an interior origin", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(4, 4), 2, 2);
            return centers.Count == 25 && centers.Any(p => Near(p.X, 1) && Near(p.Y, 1)) &&
                centers.Any(p => Near(p.X, 9) && Near(p.Y, 9));
        });
        Run("joist width is additional clear spacing", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 6, 5)), new LadrilloPunto(0, 0), 2, 1, 0, 1);
            return centers.Count == 9 && centers.Select(p => p.Y).Distinct().OrderBy(y => y).SequenceEqual(new[] { 0.5, 2.5, 4.5 });
        });
        Run("longitudinal joint adds to length", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 8, 2)), new LadrilloPunto(0, 0), 2, 2, 1);
            return centers.Count == 3 && centers.Select(p => p.X).SequenceEqual(new[] { 1.0, 4.0, 7.0 });
        });
        Run("small interior hole invisible to rectangle corners", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 6, 6), Rect(2.8, 2.8, 3.2, 3.2)), new LadrilloPunto(0, 0), 2, 2);
            return centers.Count == 8 && !centers.Any(p => Near(p.X, 3) && Near(p.Y, 3));
        });
        Run("concave notch crossing rectangle edge", () =>
        {
            var notch = Points(0, 0, 4, 0, 4, 4, 2.2, 4, 2.2, 1, 1.8, 1, 1.8, 4, 0, 4);
            return Count(Domain(notch), 4, 2) == 0;
        });
        Run("L shaped region", () =>
        {
            var outline = Points(0, 0, 6, 0, 6, 2, 2, 2, 2, 6, 0, 6);
            return Count(Domain(outline), 2, 2) == 5;
        });
        Run("hole edge contact without area overlap", () => Count(Domain(Rect(0, 0, 6, 6), Rect(2, 2, 4, 4)), 2, 2) == 8);
        Run("ring winding does not change holes", () =>
        {
            var outer = Rect(0, 0, 6, 6); var hole = Rect(2, 2, 4, 4);
            outer.Reverse(); hole.Reverse();
            return Count(Domain(outer, hole), 2, 2) == 8;
        });
        Run("separate floor islands do not bridge", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 2, 2), Rect(4, 0, 6, 2)), new LadrilloPunto(0, 0), 2, 2);
            return centers.Count == 2 && centers.All(p => !Near(p.X, 3));
        });
        Run("border margin excludes edge bricks", () => Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, 0, 0, 0.1).Count == 9);
        Run("margin protects opening edges", () =>
        {
            var centers = Generate(Domain(Rect(0, 0, 8, 8), Rect(3.9, 3.9, 4.1, 4.1)), new LadrilloPunto(0, 0), 2, 2, 0, 0, 0.2);
            return centers.Count == 0; // only four interior cells exist; each approaches the central opening
        });
        Run("origin shifted to margin retains intended first cell", () => Generate(Domain(Rect(0, 0, 6.2, 6.2)), new LadrilloPunto(0.1, 0.1), 2, 2, 0, 0, 0.1).Count == 9);
        Run("too small region returns an empty layout", () => Count(Domain(Rect(0, 0, 0.5, 1)), 2, 2) == 0);
        Run("invariant after projection of a rotated floor", () =>
        {
            double angle = 0.731, ux = Math.Cos(angle), uy = Math.Sin(angle), vx = -uy, vy = ux;
            var projected = new List<LadrilloPunto>();
            foreach (var p in Rect(0, 0, 6, 4))
            {
                double wx = 100 + p.X * ux + p.Y * vx, wy = -50 + p.X * uy + p.Y * vy;
                projected.Add(new LadrilloPunto((wx - 100) * ux + (wy + 50) * uy,
                    (wx - 100) * vx + (wy + 50) * vy));
            }
            return Count(Domain(projected), 2, 2) == 6;
        });
        Run("translation invariance at remote local coordinates", () =>
        {
            var centers = Generate(Domain(Rect(1000000, 1000000, 1000006, 1000004)), new LadrilloPunto(1000000, 1000000), 2, 2);
            return centers.Count == 6 && Near(centers[0].X, 1000001);
        });
        Run("narrow slot is never bridged", () =>
        {
            var outline = Rect(0, 0, 6, 6); var slot = Rect(2.99999, 0.5, 3.00001, 5.5);
            return Count(Domain(outline, slot), 2, 2) == 6;
        });
        Run("no artificial loss from an explicitly closed ring", () =>
        {
            var ring = Rect(0, 0, 4, 4); ring.Add(ring[0]);
            return Count(Domain(ring), 2, 2) == 4;
        });
        Run("candidate guard fails before enumerating massive grid", () => Throws<InvalidOperationException>(() => Generate(Domain(Rect(0, 0, 1000000, 1000000)), new LadrilloPunto(0, 0), 0.01, 0.01)));
        Run("accepted brick guard rejects whole result", () => Throws<InvalidOperationException>(() => LadrillosLayout.Generar(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, 0, 0, 0, 100, 5)));
        Run("negative spacing is rejected", () => Throws<ArgumentOutOfRangeException>(() => Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, -1)));
        Run("NaN dimension is rejected", () => Throws<ArgumentOutOfRangeException>(() => Count(Domain(Rect(0, 0, 10, 10)), double.NaN, 2)));
        Run("infinite margin is rejected", () => Throws<ArgumentOutOfRangeException>(() => Generate(Domain(Rect(0, 0, 10, 10)), new LadrilloPunto(0, 0), 2, 2, 0, 0, double.PositiveInfinity)));
        Run("zero joist and joint values are allowed", () => Count(Domain(Rect(0, 0, 4, 4)), 2, 2) == 4);
        Run("zero side is rejected", () => Throws<ArgumentOutOfRangeException>(() => Count(Domain(Rect(0, 0, 10, 10)), 0, 2)));
        Run("invalid contour is rejected", () => Throws<ArgumentException>(() => Count(Domain(Points(0, 0, 1, 1)), 2, 2)));
        Run("nonfinite contour coordinate is rejected", () => Throws<ArgumentException>(() => Count(Domain(Points(0, 0, 1, 0, double.NaN, 1)), 2, 2)));
        Run("hosted native insertion above floor is preserved", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 20, 10, 11, 0.5, 0), 20));
        Run("hosted native insertion below floor is preserved", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 5, 10, 11, 0.5, 0), 5));
        Run("oversized hosted native family is allowed", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 11, 10, 11, 2, 0), 11));
        Run("native placement ignores an unused positive intrados offset", () =>
            Near(LadrillosAltura.CalcularBase(true, false, 11, 10, 11, 0.5, 100), 11));
        Run("explicit hosted adjustment uses intrados plus offset", () =>
            Near(LadrillosAltura.CalcularBase(true, true, 20, 10, 11, 0.5, 0.2), 10.2));
        Run("unhosted family requires adjustment even with option off", () =>
            Near(LadrillosAltura.CalcularBase(false, false, 20, 10, 11, 0.5, 0.2), 10.2));
        Run("unhosted family with explicit adjustment uses same base", () =>
            Near(LadrillosAltura.CalcularBase(false, true, 20, 10, 11, 0.5, 0.2), 10.2));
        Run("oversized explicitly adjusted family is rejected", () =>
            Throws<InvalidOperationException>(() => LadrillosAltura.CalcularBase(true, true, 11, 10, 11, 2, 0)));
        Run("oversized unhosted family is rejected", () =>
            Throws<InvalidOperationException>(() => LadrillosAltura.CalcularBase(false, false, 11, 10, 11, 2, 0)));
        Run("negative intrados offset is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, true, 11, 10, 11, 0.5, -0.1)));
        Run("negative offset is rejected even in native mode", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, 11, 10, 11, 0.5, -0.1)));
        Run("height at tolerance boundary remains accepted", () =>
            Near(LadrillosAltura.CalcularBase(true, true, 20, 10, 11, 1 + 0.5e-6, 0), 10));
        Run("height beyond tolerance is rejected", () =>
            Throws<InvalidOperationException>(() => LadrillosAltura.CalcularBase(true, true, 20, 10, 11, 1 + 2e-6, 0)));
        Run("nonfinite native elevation is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, double.NaN, 10, 11, 0.5, 0)));
        Run("nonfinite height is rejected in native mode", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, 20, 10, 11, double.PositiveInfinity, 0)));
        Run("zero height is rejected", () =>
            Throws<ArgumentOutOfRangeException>(() => LadrillosAltura.CalcularBase(true, false, 20, 10, 11, 0, 0)));
        Run("invalid floor thickness is rejected", () =>
            Throws<ArgumentException>(() => LadrillosAltura.CalcularBase(true, false, 20, 11, 10, 0.5, 0)));
        Console.WriteLine("Passed: " + passed + "; Failed: " + failed);
        Environment.ExitCode = failed == 0 ? 0 : 1;
    }

    private static void Run(string name, Func<bool> test)
    {
        try
        {
            if (!test()) throw new Exception("Assertion failed");
            passed++;
            Console.WriteLine("PASS " + name);
        }
        catch (Exception ex)
        {
            failed++;
            Console.WriteLine("FAIL " + name + ": " + ex.GetType().Name + ": " + ex.Message);
        }
    }

    private static bool Near(double a, double b) { return Math.Abs(a - b) < 1e-7; }
    private static bool Throws<T>(Action action) where T : Exception
    {
        try { action(); return false; }
        catch (T) { return true; }
    }
    private static int Count(IList<IList<LadrilloPunto>> domain, double u, double v)
    {
        return Generate(domain, new LadrilloPunto(0, 0), u, v).Count;
    }
    private static List<LadrilloPunto> Generate(IList<IList<LadrilloPunto>> domain, LadrilloPunto origin,
        double u, double v, double joint = 0, double joist = 0, double margin = 0)
    {
        return LadrillosLayout.Generar(domain, origin, u, v, joint, joist, margin, 100000, 100000);
    }
    private static IList<IList<LadrilloPunto>> Domain(params List<LadrilloPunto>[] rings)
    {
        return rings.Cast<IList<LadrilloPunto>>().ToList();
    }
    private static List<LadrilloPunto> Rect(double minx, double miny, double maxx, double maxy)
    {
        return Points(minx, miny, maxx, miny, maxx, maxy, minx, maxy);
    }
    private static List<LadrilloPunto> Points(params double[] xy)
    {
        var result = new List<LadrilloPunto>();
        for (int i = 0; i < xy.Length; i += 2) result.Add(new LadrilloPunto(xy[i], xy[i + 1]));
        return result;
    }
}
