# Corrección: ladrillo con anfitrión Suelo

## A. Resumen y versión de trabajo
Corrección sobre la entrega `MYG_ADDIN_ACTUALIZACION_20261115_102903.zip`, SHA256 `62e1974fd2dd1e2a7bd3d7502cc00ec8e4631a2edb5d372624def7f7f421cafd`, publicada en DESCARGAS en commit `46d2203acbbe00096ed78179ef8e3ab05f8afed9`.

El checkout real sigue siendo `bimchimbote-droid/MYG_v27_reestructurado`, base Git `2a8977e8032d0bd9d12d7302b897d5096b0cf064`, más los cambios de la entrega anterior que ya estaban presentes. Se conservaron esos cambios y sus dependencias. No se reemplazó la estructura por MYG_v27/main.

El mensaje mostrado por el usuario procedía del guard `ComprobarVolumenSuelo`: infería que cualquier cambio de volumen calculado significaba un corte y cancelaba la operación. Esa inferencia no permite diagnosticar la causa real sin el modelo y bloqueaba una familia hospedada que el usuario puede colocar manualmente.

Se elimina ese guard. Ahora se crea **cada instancia directamente con la losa como anfitrión**, sin copiar otra instancia hospedada y sin imponer un nivel a la familia con anfitrión. Por defecto se respeta la elevación propia de la familia como al hacer clic en el suelo. El ajuste al intradós es una opción desmarcada por defecto. Las familias sin anfitrión continúan ajustándose al intradós.

## B. Archivos afectados
| Ruta | Acción |
|---|---|
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaCommand.cs | REEMPLAZAR: comando completo corregido |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaForm.cs | REEMPLAZAR: opción explícita de ajuste al intradós |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLayout.cs | REEMPLAZAR: motor existente más política de altura comprobada |
| Pruebas/LadrillosLosas/Program.cs | REEMPLAZAR: 27 pruebas de distribución y 17 de altura; proyecto de pruebas opcional |
| MYG/Ribbon/Paneles/EstructurasPanel.cs | MODIFICAR con Parches/EstructurasPanel.cs.patch: corrige únicamente una frase del tooltip |

No se crean ni eliminan archivos del proyecto principal. El `.csproj`, las referencias, paquetes, manifiesto, icono y las demás funciones no cambian; quedan fuera del ZIP. El parche de tooltip es contra la entrega anterior. ARCHIVOS.csv registra los hashes antes/después para las intervenciones.

## C. Descarga y contenido
Este ZIP contiene únicamente los archivos modificados desde la entrega anterior y documentos/parche de esta corrección. No incluye la familia original sin cambios, binarios ni el proyecto completo. La verificación de la publicación/descarga se informa en el mensaje de entrega una vez realizada.

## D. Instalación
1. Cierra Revit y respalda la solución y la DLL que probaste.
2. Esta corrección requiere la entrega anterior ya incorporada. Copia los **tres archivos C#** de la carpeta LadrillosLosas sobre sus rutas existentes. No pegues fragmentos dentro de clases: se entregan archivos completos. Si tienes cambios posteriores propios, compara/fusiona antes de reemplazar para no perderlos.
3. Si instalaste el proyecto opcional de pruebas de la entrega anterior, reemplaza también su Program.cs. No añadas ese Program.cs al proyecto MYG. El csproj de pruebas y NuGet.Config anteriores se conservan sin cambios.
4. Opcionalmente, actualiza la frase informativa del botón. Desde la raíz de tu solución, con Parches extraído allí:
   ```bash
   git apply --check Parches/EstructurasPanel.cs.patch
   git apply Parches/EstructurasPanel.cs.patch
   ```
   Si tienes cambios locales incompatibles, edita únicamente la frase del tooltip indicada por el parche. No vuelvas a aplicar el parche del csproj de la entrega anterior: esta corrección no modifica las inclusiones Compile.
5. Compila en Windows. Con Revit cerrado, sustituye tu MYG.dll en la ubicación de instalación habitual. Si pruebas con AddInManager, reinicia Revit para evitar seguir usando la DLL anterior ya cargada. Conserva el manifiesto `.addin` y `MYG_Addin.App`.

## E. Uso y configuración
Utiliza la misma familia con anfitrión Suelo, sin editarla ni cambiar su plantilla. Selecciona su tipo cargado o su `.rfa` original.

Para reproducir la colocación manual: **deja desmarcado Ajustar la base al intradós de la losa**. El comando conserva la elevación que Revit resuelve para la familia hospedada y ajusta la posición/alineación en planta. Configura vigueta/junta/margen como antes; ancho libre de vigueta predeterminado10cm. Selecciona losa horizontal y dos puntos en planta para origen/dirección; confirma el conteo.

Activa el ajuste al intradós solo si quieres imponer una base desde la cara inferior. En ese modo sí se comprueba que la altura del ladrillo y el desfase caben en el espesor. El campo de desfase se habilita con ese ajuste, o al seleccionar un tipo sin anfitrión.

No se añaden referencias, paquetes ni requisitos de configuración. El código sigue usando las API de creación de familias y la autorización MYG existentes.

## F. Validación
- **44 pruebas aprobadas, 0 fallidas**: las27 de distribución anteriores más17 de política de altura que ejercitan la misma función usada por el comando. Incluyen familia hospedada por encima/debajo del espesor, altura mayor conservada en modo nativo y rechazo de encaje incorrecto solo al ajustar.
- Compilación aislada de los archivos actualizados contra las DLL reales disponibles de Revit2027, con C#7.3 y referencias net10.0-windows: **0 advertencias, 0 errores**. Adaptadores de integración solo en el harness externo, nunca en este ZIP ni en el add-in.
- Roslyn:186 fuentes activas sin errores de sintaxis;186 Compile,9 EmbeddedResource y3 None existentes y sin duplicados.
- Parche de tooltip aplicado contra la entrega anterior y comparado byte a byte con el archivo actual; git diff --check correcto.
- Compilación completa del complemento: vuelve a fallar con MSB4803 por referencias COM en Linux; continúa advertencia preexistente MSB3277 de EPPlus.Interfaces.
- **La colocación real de la familia en Revit no se ha ejecutado en este entorno.** Consulta VALIDACION.md para pruebas manuales pendientes.

## G. GitHub
Solo se publica el nuevo ZIP en una ruta nueva de DESCARGAS. La entrega anterior se conserva. Publicarlo no actualiza tu PC ni hace Push a MYG_v27/MYG_v27_reestructurado. Tras instalar y probar, revisa tus Cambios de Git en Visual Studio, crea tu Commit y ejecuta Push desde tu equipo cuando decidas publicar el código.

## H. Límites y comportamiento del anfitrión
No hay llamadas del comando para cortar el suelo del documento. La prueba de huella utiliza una diferencia booleana **entre sólidos temporales en memoria**, obtenidos antes de colocar familias; no solicita un recorte del elemento Revit. Sirve para comprobar contorno/huecos y es independiente de la altura nativa del ladrillo.

Revit conserva el comportamiento de hospedaje definido por tu familia, incluidos efectos automáticos que también puedan ocurrir en colocación manual. **No se garantiza que el volumen del suelo permanezca inalterado**, y ya no se rechaza una familia por ese solo motivo. La causa concreta de la variación que disparó el guard no se ha reproducido sin tu modelo.

Se mantienen los límites de la herramienta: losa horizontal de espesor constante, piezas completas, máximo100.000 candidatos/10.000 piezas y prevención de solapamientos con la misma familia. El comportamiento de hospedaje, visibilidad, colocación vertical, deshacer y los efectos del anfitrión requieren comprobarse en Revit. No se modifica el framework original ni se resuelve su compatibilidad pendiente con Revit2027 como parte de esta corrección.
