# Evidencia de validación

## Ejecutado
- Motor geométrico: **27 aprobadas, 0 fallidas**, C#7.3, .NET10. Casos: regiones rectangulares, concavidad, hueco sin esquinas fuera, ranuras estrechas, orientación de anillos, islas, giro/proyección, margen, junta y vigueta, origen interior con índices negativos y valores/límites inválidos.
- Pruebas portables en Pruebas/LadrillosLosas. Requieren SDK .NET10, sin paquetes adicionales. Desde la raíz de la solución:
  ```bash
  dotnet restore Pruebas/LadrillosLosas/BrickLayout.Tests.csproj --configfile Pruebas/LadrillosLosas/NuGet.Config
  dotnet run --no-restore --project Pruebas/LadrillosLosas/BrickLayout.Tests.csproj
  ```
  Es un ejecutable de pruebas con código de salida distinto de cero cuando falla una aserción; no usa dotnet test. Durante esta entrega las salidas se dirigieron fuera del checkout.
- Roslyn C#7.3 DEBUG/TRACE: **186 archivos activos sin errores de sintaxis**. Comprobación del XML: 186 Compile, 9 EmbeddedResource y 3 None, todas las rutas existentes, sin duplicados.
- Compilación **aislada** en net10.0-windows de los tres archivos nuevos, Clipper existente y el bloque nuevo del botón contra las DLL reales de API Revit2027 disponibles: **0 errores y 0 advertencias**. Se usaron adaptadores únicamente para la llamada de acceso y el registro del botón de la aplicación existente. Esos adaptadores no están en el código del add-in ni en el ZIP. Esta comprobación valida tipos/firmas de la nueva funcionalidad; no valida el ensamblado completo ni su carga en Revit ni la combinación del framework original.
- git diff --check: correcto. Sin cambios de paquetes, framework, lógica existente o versiones de dependencias.

## Compilación completa
Intento real Debug|x64 del MYG.csproj modificado: **falló**, código1, MSB4803: ResolveComReference no está soportado por MSBuild de .NET Core; requiere MSBuild de .NET Framework en Windows. Se mantuvo la advertencia preexistente MSB3277 por EPPlus.Interfaces. No se generó una nueva MYG.dll del complemento completo.

## Pendiente: Windows/Revit
La familia se inspeccionó mediante metadatos PartAtom; no se abrió en Revit en este entorno. No se ejecutaron operaciones de colocación, hospedaje, Copiar, deshacer, UI ni cancelación en un documento Revit.

En Windows, compilar con las dependencias reales del proyecto y probar sobre un modelo de copia:
1. Losas rectangulares y cóncavas, con huecos pequeños/curvos; comprobar que ninguna pieza los cruza.
2. Familia adjunta hospedada en suelo: cargar, comprobar medidas físicas y base de cada bloque al intradós; losa20cm/ladrillo15cm y dirección oblicua.
3. Junta0/vigueta10cm, otros valores, giro90°, origen interior/exterior y margen.
4. Repetir sobre la misma losa: comprobar omisión de solapamientos con la misma familia.
5. Cancelar en cada selección/confirmación, familia demasiado alta o incompatible y fallo de colocación: verificar que no queden piezas o una familia recién cargada por la operación cancelada.
6. Comprobar conteo final, un solo Deshacer, volumen de suelo conservado y botón sujeto a sesión MYG.
7. Probar paño grande dentro de límites y verificar tiempo/memoria antes de usar lotes de10.000.
