# MYG · Ladrillos en losa

## A. Resumen y base
Se añade el botón **MYG → ESTRUCTURAS → Ladrillos en losa**, manteniendo la comprobación de acceso MYG existente. Permite seleccionar una losa horizontal, indicar dirección con dos puntos y distribuir instancias de la familia de ladrillo. Se conservan las demás herramientas.

Base real: `bimchimbote-droid/MYG_v27_reestructurado`, rama `master`, commit `2a8977e8032d0bd9d12d7302b897d5096b0cf064`. El checkout estaba limpio al comenzar. Se utiliza esta versión actual reestructurada; la referencia `MYG_v27/main` del texto de entrega no se utilizó para sustituir archivos.

## B. Archivos
`ARCHIVOS.csv` identifica las intervenciones y los SHA256 del contenido. Solo se entregan archivos nuevos/modificados, parches e instrucciones. El proyecto completo, DLL, paquetes, credenciales, temporales y archivos sin cambios quedan fuera.

- REEMPLAZAR `MYG/Ribbon/Paneles/EstructurasPanel.cs` con el archivo completo incluido, o usar su parche alternativo si tienes cambios posteriores. **No aplicar ambos métodos**.
- CREAR los tres `.cs` de `MYG/Funcionalidades/Estructuras/LadrillosLosas/`.
- MODIFICAR `MYG/MYG.csproj` con `Parches/MYG.csproj.patch`: añade únicamente tres entradas Compile. No reemplaces tu proyecto completo.
- CREAR opcionalmente `Pruebas/LadrillosLosas/` para ejecutar las pruebas del motor. No incorpores sus archivos al proyecto MYG del complemento.
- No se elimina ningún archivo. Los demás archivos del add-in quedan SIN CAMBIOS y fuera del ZIP.

## C. Paquete
Nombre: `MYG_ADDIN_ACTUALIZACION_20261115_102903.zip`. La fecha/hora corresponde a America/Lima. La comprobación de la descarga publicada se informa en el mensaje de entrega, después de publicarla. Este documento no afirma por sí solo que el ZIP esté publicado.

## D. Instalación
1. Cierra Revit y respalda tu solución y DLL de uso habitual.
2. Extrae el ZIP en una carpeta temporal. Compara los archivos con tu versión; reemplazar el archivo completo del Ribbon podría sobrescribir cambios locales o posteriores.
3. Copia los tres archivos nuevos a sus rutas relativas bajo la raíz de la solución.
4. Sustituye el archivo del Ribbon entregado. Si tu archivo tiene otros avances, conserva tu versión y aplica/revisa únicamente el bloque nuevo con el parche alternativo.
5. Desde la raíz del repositorio, comprueba y aplica el parche de proyecto:
   ```bash
   git apply --check Parches/MYG.csproj.patch
   git apply Parches/MYG.csproj.patch
   ```
   Si descargaste los parches en otra carpeta, usa su ruta real. Si falla la comprobación, abre el `.csproj` y añade las tres entradas Compile que muestra el parche dentro del ItemGroup de fuentes. No sobrescribas actualizaciones propias ni dupliques las entradas. Visual Studio puede incorporar los archivos con Agregar → Elemento existente; comprueba sus entradas y omite el parche si ya están incluidas.
6. Parche alternativo del Ribbon, solo si NO copiaste el archivo completo:
   ```bash
   git apply --check Parches/EstructurasPanel.cs.patch
   git apply Parches/EstructurasPanel.cs.patch
   ```
7. Compila tu solución en Windows con sus referencias reales. Revisa la ruta OutputPath de la configuración utilizada. Actualiza `MYG.dll` en tu instalación existente con Revit cerrado y conserva tu manifiesto `.addin` y tipo de entrada `MYG_Addin.App`.

## E. Uso y configuración
No se añaden paquetes ni referencias al proyecto principal. Clipper, System.Numerics, WinForms y WPF ya forman parte del proyecto. El icono del botón es vectorial y no necesita imágenes externas.

En una **planta de piso o planta estructural**:
1. Abre Ladrillos en losa y selecciona un tipo ya cargado, o Examinar para elegir la familia `.rfa` original. Si ya está cargada, usa su tipo existente; no se sobrescriben familias automáticamente.
2. Configura el ancho libre de vigueta **entre filas** (10 cm por defecto), la junta **dentro de cada fila** (0 cm), margen a bordes/huecos y altura de base sobre el intradós (0 cm). Todo está expresado en cm. Usa Girar 90° para orientar los huecos de la familia respecto a la dirección de las filas.
3. Selecciona una losa horizontal del documento actual. Marca el origen de la malla (esquina de un módulo) y otro punto que indique el sentido de filas/viguetas. La malla se extiende en ambos sentidos desde ese origen; estos puntos no definen un área de recorte.
4. Revisa el número y las medidas detectadas, y confirma la creación. Esc/Cancelar revierte la operación y la carga de familia hecha por ese comando. Deshacer revierte el resultado en un solo paso.

Se mide la geometría sólida real de la familia para orientar, separar y ajustar su base; no se supone que el origen de la familia esté en el centro ni en su cara inferior. Con un ladrillo medido de 30 × 30 × 15 cm, junta 0 y vigueta 10 cm, el paso de la malla es 30 cm en filas y 40 cm entre filas. En una losa plana de 20 cm, con base a intradós, quedaría una diferencia de 5 cm sobre el ladrillo si la geometría real coincide con esos parámetros.

La familia adjunta original tiene metadatos de Modelos genéricos, anfitrión Suelo, tamaño 30 × 30 × 15 cm y fue guardada en **Revit 2027** pese a llamarse R2015. Se admite ese tipo de hospedaje. El `.rfa` no se vuelve a incluir porque no fue modificado; carga tu archivo original. Sus parámetros no sustituyen la medición real al ejecutar el comando.

## F. Validación
Consulta `VALIDACION.md`: 27 pruebas geométricas aprobadas, análisis de las 186 fuentes activas sin errores, compilación aislada de los nuevos archivos/bloque de botón contra API real de Revit 2027 sin errores. **La compilación completa del complemento sigue bloqueada por MSB4803 en Linux y la colocación funcional no fue ejecutada dentro de Revit**.

## G. GitHub
Publicar el ZIP en DESCARGAS no aplica cambios a tu PC ni actualiza las ramas del repositorio del código. No se hizo Push ni se fusionó código en MYG_v27 ni MYG_v27_reestructurado.

Después de copiar y probar: abre Git Changes/Cambios de Git en Visual Studio, revisa cada diff, incluye únicamente los archivos de la herramienta y sus pruebas, escribe un mensaje de commit y realiza Commit local. Haz Push desde tu equipo cuando decidas publicar esos cambios en tu repositorio. El `.csproj` modificado debe acompañar a los nuevos `.cs`.

## H. Límites
- Solo losas horizontales de espesor constante; se rechazan desniveles, capas variables y selección de vínculos. Familias admitidas: punto basado en nivel sin anfitrión, o hospedadas en Suelo. Familias por cara/plano, muro, techo, línea o adaptativas se rechazan con mensaje.
- Se colocan **piezas completas**. No se cortan ladrillos para cerrar bordes y no se rellenan franjas residuales. La huella rectangular y el margen son conservadores: pueden omitir piezas en bordes curvos o casos muy ajustados.
- **La losa conserva su geometría y volumen. No se vacía el concreto ni se descuentan metrados.** La familia no puede cortar el anfitrión; se revierte si se detecta alteración de volumen. Esto automatiza el modelado de ladrillos, no el cálculo estructural de una losa aligerada.
- Se omiten solapamientos con otras instancias de la misma familia, incluidos sus otros tipos. No se detectan interferencias con familias distintas, vigas u otras instalaciones.
- Máximo 100.000 posiciones candidatas y 10.000 ladrillos por ejecución. No se devuelve una creación parcial por alcanzar límites. La comprobación mediante sólidos reales puede tardar en paños grandes.
- El proyecto conserva .NET Framework 4.8 y referencias a Revit 2027; su compatibilidad pendiente y la advertencia preexistente EPPlus.Interfaces no se modifican como parte de este cambio.
- Antes de usarlo en producción, compila en Windows y ejecuta las comprobaciones manuales de VALIDACION.md con una copia de un modelo.
