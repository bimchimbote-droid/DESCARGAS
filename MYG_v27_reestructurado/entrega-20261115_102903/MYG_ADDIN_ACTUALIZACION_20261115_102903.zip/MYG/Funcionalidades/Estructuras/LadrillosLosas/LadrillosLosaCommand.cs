using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Forms = System.Windows.Forms;

namespace MYG_Addin
{
    [Transaction(TransactionMode.Manual)]
    public class LadrillosLosaCommand : IExternalCommand
    {
        private const double Tolerancia = 1e-6; // pies; solo comparación, no desplaza el contorno.
        private const int MaxCandidatos = 100000;
        private const int MaxLadrillos = 10000;

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            if (!MYG_ControlAccesoComandos.Comprobar()) return Result.Cancelled;
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            if (uidoc == null || uidoc.Document.IsFamilyDocument || uidoc.Document.IsReadOnly)
            {
                TaskDialog.Show("MYG · Ladrillos en losa", "Abre un proyecto editable de Revit.");
                return Result.Cancelled;
            }
            Document doc = uidoc.Document;
            ViewPlan planta = doc.ActiveView as ViewPlan;
            if (planta == null || planta.IsTemplate || planta.GenLevel == null ||
                (planta.ViewType != ViewType.FloorPlan && planta.ViewType != ViewType.EngineeringPlan))
            {
                TaskDialog.Show("MYG · Ladrillos en losa",
                    "Ejecuta el comando desde una planta de piso o planta estructural con nivel. " +
                    "Los dos puntos se marcan en el plano de trabajo de esa vista.");
                return Result.Cancelled;
            }
            try
            {
                var tipos = new FilteredElementCollector(doc).OfClass(typeof(FamilySymbol))
                    .Cast<FamilySymbol>().Where(TipoAdmitido).OrderBy(x => x.FamilyName)
                    .ThenBy(x => x.Name).ToList();
                LadrillosLosaOpciones opciones;
                using (var form = new LadrillosLosaForm(tipos))
                {
                    if (form.ShowDialog() != Forms.DialogResult.OK) return Result.Cancelled;
                    opciones = form.Opciones;
                }
                ValidarOpciones(opciones);
                Reference referencia = uidoc.Selection.PickObject(ObjectType.Element, new FiltroSuelo(),
                    "Selecciona la losa (suelo) horizontal donde colocar los ladrillos");
                Floor suelo = (Floor)doc.GetElement(referencia.ElementId);
                var datosSuelo = LeerSuelo(suelo);
                XYZ primero = uidoc.Selection.PickPoint("Marca el origen de la malla (esquina del primer módulo)");
                XYZ segundo = uidoc.Selection.PickPoint("Marca otro punto en la dirección de las viguetas / filas");
                XYZ diferencia = new XYZ(segundo.X - primero.X, segundo.Y - primero.Y, 0);
                if (diferencia.GetLength() < 0.00328084)
                    throw new InvalidOperationException("Los puntos de dirección deben separarse al menos 1 mm en planta.");
                var marco = new Marco(primero, diferencia.Normalize());
                List<IList<LadrilloPunto>> contornos = Contornos(datosSuelo.CarasSuperiores, marco);
                Level nivel = doc.GetElement(suelo.LevelId) as Level;
                if (nivel == null) throw new InvalidOperationException("No se pudo obtener el nivel de la losa.");
                int creados = 0, omitidosSolido = 0, omitidosExistentes = 0;
                double largo = 0, ancho = 0, alto = 0;
                using (var grupo = new TransactionGroup(doc, "MYG · Ladrillos en losa"))
                {
                    if (grupo.Start() != TransactionStatus.Started)
                        throw new InvalidOperationException("No se pudo iniciar el grupo de transacciones.");
                    try
                    {
                        FamilySymbol tipo = ResolverTipo(doc, opciones);
                        if (tipo == null) return Result.Cancelled;
                        if (!TipoAdmitido(tipo))
                            throw new InvalidOperationException("La familia debe ser un componente basado en nivel " +
                                "sin anfitrión o con anfitrión Suelo. No se admiten familias por cara, " +
                                "plano de trabajo, muro, techo, línea ni adaptativas.");
                        bool hospedado = tipo.Family.FamilyPlacementType == FamilyPlacementType.OneLevelBasedHosted;
                        using (var tx = new Transaction(doc, "Colocar ladrillos"))
                        {
                            if (tx.Start() != TransactionStatus.Started)
                                throw new InvalidOperationException("No se pudo iniciar la colocación.");
                            var fallos = new FallosColocacion();
                            tx.SetFailureHandlingOptions(tx.GetFailureHandlingOptions()
                                .SetClearAfterRollback(true).SetForcedModalHandling(true)
                                .SetFailuresPreprocessor(fallos));
                            if (!tipo.IsActive) tipo.Activate();
                            doc.Regenerate();
                            FamilyInstance plantilla = Crear(doc, tipo, suelo, nivel, datosSuelo.Semilla, hospedado);
                            doc.Regenerate();
                            LocationPoint ubicacion = plantilla.Location as LocationPoint;
                            if (ubicacion == null)
                                throw new InvalidOperationException("La familia no tiene un punto de inserción compatible.");
                            double angulo = Math.Atan2(marco.U.Y, marco.U.X) + (opciones.Girar90 ? Math.PI / 2 : 0);
                            double giro = angulo - ubicacion.Rotation;
                            ElementTransformUtils.RotateElement(doc, plantilla.Id,
                                Line.CreateBound(ubicacion.Point, ubicacion.Point + XYZ.BasisZ), giro);
                            doc.Regenerate();
                            Caja caja = Medir(plantilla, marco);
                            double baseDeseada = datosSuelo.Inferior + Pies(opciones.DesfaseBaseCm);
                            largo = caja.MaxU - caja.MinU;
                            ancho = caja.MaxV - caja.MinV;
                            alto = caja.MaxZ - caja.MinZ;
                            if (largo <= Tolerancia || ancho <= Tolerancia || alto <= Tolerancia)
                                throw new InvalidOperationException("La familia no contiene un sólido tridimensional medible.");
                            if (baseDeseada + alto > datosSuelo.Superior + Tolerancia)
                                throw new InvalidOperationException("El ladrillo mide " + Cm(alto) + " cm de alto y no cabe " +
                                    "dentro del espesor disponible (" + Cm(datosSuelo.Superior - baseDeseada) + " cm). " +
                                    "Elige otro tipo o reduce el desfase desde el intradós.");
                            ElementTransformUtils.MoveElement(doc, plantilla.Id,
                                XYZ.BasisZ.Multiply(baseDeseada - caja.MinZ));
                            doc.Regenerate();
                            caja = Medir(plantilla, marco);
                            if (Math.Abs(caja.MinZ - baseDeseada) > Tolerancia)
                                throw new InvalidOperationException("El anfitrión o las restricciones de la familia " +
                                    "impiden ajustar su base al intradós. No se ha colocado ningún ladrillo.");
                            ComprobarVolumenSuelo(suelo, datosSuelo.Volumen);
                            var posiciones = LadrillosLayout.Generar(contornos, new LadrilloPunto(0, 0),
                                largo, ancho, Pies(opciones.JuntaCm), Pies(opciones.ViguetaCm),
                                Pies(opciones.MargenCm), MaxCandidatos, MaxLadrillos);
                            var existentes = LeerExistentes(doc, tipo, plantilla.Id, marco, largo, ancho);
                            var aceptadas = new List<LadrilloPunto>();
                            foreach (LadrilloPunto centro in posiciones)
                            {
                                if (!CabeEnSolidos(datosSuelo.Solidos, marco, centro,
                                    largo + 2 * Pies(opciones.MargenCm), ancho + 2 * Pies(opciones.MargenCm),
                                    baseDeseada, alto))
                                {
                                    omitidosSolido++;
                                    continue;
                                }
                                var candidato = new Caja(centro.X - largo / 2, centro.X + largo / 2,
                                    centro.Y - ancho / 2, centro.Y + ancho / 2, baseDeseada, baseDeseada + alto);
                                if (existentes.Intersecta(candidato))
                                {
                                    omitidosExistentes++;
                                    continue;
                                }
                                aceptadas.Add(centro);
                            }
                            if (aceptadas.Count == 0)
                            {
                                TaskDialog.Show("MYG · Ladrillos en losa",
                                    "No hay posiciones libres para ladrillos completos con esta configuración.\n\n" +
                                    "Omitidos por geometría real del suelo: " + omitidosSolido +
                                    ".\nOmitidos por superposición con la misma familia: " + omitidosExistentes +
                                    ".\nRevisa origen, tipo, giro, margen y separaciones.");
                                return Result.Cancelled;
                            }
                            var confirmar = new TaskDialog("MYG · Ladrillos en losa")
                            {
                                MainInstruction = "Crear " + aceptadas.Count + " ladrillos completos",
                                MainContent = "Huella medida: " + Cm(largo) + " × " + Cm(ancho) +
                                    " cm. Altura: " + Cm(alto) + " cm.\n" +
                                    "Separación libre entre filas (vigueta): " + opciones.ViguetaCm.ToString("0.###") +
                                    " cm. Junta en la fila: " + opciones.JuntaCm.ToString("0.###") + " cm.\n" +
                                    "Se respeta el contorno y los huecos. Se omiten " + omitidosExistentes +
                                    " posiciones ocupadas por esta familia.\n\n" +
                                    "El suelo se conserva completo: no se vacía ni se modifica su volumen.",
                                CommonButtons = TaskDialogCommonButtons.Ok | TaskDialogCommonButtons.Cancel,
                                DefaultButton = TaskDialogResult.Cancel
                            };
                            if (confirmar.Show() != TaskDialogResult.Ok) return Result.Cancelled;
                            var copias = new List<KeyValuePair<ElementId, LadrilloPunto>>();
                            XYZ centroPlantilla = marco.Punto((caja.MinU + caja.MaxU) / 2,
                                (caja.MinV + caja.MaxV) / 2, baseDeseada);
                            foreach (LadrilloPunto centro in aceptadas)
                            {
                                XYZ mover = marco.Punto(centro.X, centro.Y, baseDeseada) - centroPlantilla;
                                ICollection<ElementId> ids = ElementTransformUtils.CopyElement(doc, plantilla.Id, mover);
                                var nuevas = ids.Select(doc.GetElement).OfType<FamilyInstance>()
                                    .Where(x => x.Symbol.Id.Equals(tipo.Id) && x.SuperComponent == null).ToList();
                                if (nuevas.Count != 1)
                                    throw new InvalidOperationException("No se pudo identificar la copia de la familia de ladrillo.");
                                copias.Add(new KeyValuePair<ElementId, LadrilloPunto>(nuevas[0].Id, centro));
                            }
                            doc.Delete(plantilla.Id);
                            doc.Regenerate();
                            foreach (var copia in copias)
                            {
                                FamilyInstance instancia = doc.GetElement(copia.Key) as FamilyInstance;
                                if (instancia == null || (hospedado &&
                                    (instancia.Host == null || !instancia.Host.Id.Equals(suelo.Id))))
                                    throw new InvalidOperationException("Una copia perdió el anfitrión Suelo. Se revierte la colocación.");
                                Caja real = Medir(instancia, marco);
                                if (Math.Abs((real.MinU + real.MaxU) / 2 - copia.Value.X) > Tolerancia ||
                                    Math.Abs((real.MinV + real.MaxV) / 2 - copia.Value.Y) > Tolerancia ||
                                    Math.Abs(real.MinZ - baseDeseada) > Tolerancia ||
                                    real.MaxZ > datosSuelo.Superior + Tolerancia ||
                                    Math.Abs(real.MaxU - real.MinU - largo) > Tolerancia ||
                                    Math.Abs(real.MaxV - real.MinV - ancho) > Tolerancia)
                                    throw new InvalidOperationException("Una restricción de la familia alteró una copia. " +
                                        "Se revierte toda la colocación para evitar ladrillos desalineados.");
                            }
                            ComprobarVolumenSuelo(suelo, datosSuelo.Volumen);
                            TransactionStatus estado = tx.Commit();
                            if (estado != TransactionStatus.Committed)
                                throw new InvalidOperationException("Revit no confirmó la colocación. " + fallos.Descripcion);
                            creados = copias.Count;
                        }
                        if (grupo.Assimilate() != TransactionStatus.Committed)
                            throw new InvalidOperationException("Revit no confirmó el grupo de colocación.");
                    }
                    finally
                    {
                        if (grupo.GetStatus() == TransactionStatus.Started) grupo.RollBack();
                    }
                }
                TaskDialog.Show("MYG · Ladrillos en losa", "Se crearon " + creados +
                    " ladrillos.\nHuella: " + Cm(largo) + " × " + Cm(ancho) + " cm; altura: " + Cm(alto) +
                    " cm.\nOmitidos por contorno real: " + omitidosSolido +
                    "; por superposición con la misma familia: " + omitidosExistentes +
                    ".\nPuedes deshacer toda la operación en un solo paso.");
                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { return Result.Cancelled; }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("MYG · Ladrillos en losa", ex.Message + "\n\nLa operación no se completó.");
                return Result.Failed;
            }
        }

        private static bool TipoAdmitido(FamilySymbol tipo)
        {
            if (tipo == null || tipo.Family == null || tipo.Family.IsInPlace) return false;
            FamilyPlacementType colocacion = tipo.Family.FamilyPlacementType;
            if (colocacion == FamilyPlacementType.OneLevelBased) return true;
            if (colocacion != FamilyPlacementType.OneLevelBasedHosted) return false;
            Parameter anfitrion = tipo.Family.get_Parameter(BuiltInParameter.FAMILY_HOSTING_BEHAVIOR);
            return anfitrion != null && anfitrion.StorageType == StorageType.Integer && anfitrion.AsInteger() == 2;
        }

        private static FamilySymbol ResolverTipo(Document doc, LadrillosLosaOpciones opciones)
        {
            if (string.IsNullOrWhiteSpace(opciones.ArchivoFamilia))
                return doc.GetElement(opciones.TipoId) as FamilySymbol;
            string ruta = Path.GetFullPath(opciones.ArchivoFamilia);
            if (!File.Exists(ruta) || !string.Equals(Path.GetExtension(ruta), ".rfa", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Selecciona un archivo de familia .rfa existente.");
            Family familia;
            using (var tx = new Transaction(doc, "Cargar familia de ladrillo"))
            {
                if (tx.Start() != TransactionStatus.Started)
                    throw new InvalidOperationException("No se pudo iniciar la carga de la familia.");
                var fallos = new FallosColocacion();
                tx.SetFailureHandlingOptions(tx.GetFailureHandlingOptions()
                    .SetClearAfterRollback(true).SetForcedModalHandling(true)
                    .SetFailuresPreprocessor(fallos));
                // No sobrescribir una familia existente ni sus parámetros automáticamente.
                if (!doc.LoadFamily(ruta, out familia) || familia == null)
                    throw new InvalidOperationException("No se cargó la familia. Si ya existe en el proyecto, " +
                        "selecciona uno de sus tipos cargados en la ventana del comando.");
                if (tx.Commit() != TransactionStatus.Committed)
                    throw new InvalidOperationException("Revit no confirmó la carga de la familia. " + fallos.Descripcion);
            }
            var tipos = familia.GetFamilySymbolIds().Select(doc.GetElement).OfType<FamilySymbol>()
                .OrderBy(x => x.Name).ToList();
            if (tipos.Count == 0) throw new InvalidOperationException("La familia no contiene tipos.");
            if (tipos.Count == 1) return tipos[0];
            using (var elegir = new Forms.Form())
            using (var lista = new Forms.ComboBox())
            using (var aceptar = new Forms.Button())
            using (var cancelar = new Forms.Button())
            {
                elegir.Text = "MYG · Tipo de ladrillo";
                elegir.StartPosition = Forms.FormStartPosition.CenterScreen;
                elegir.FormBorderStyle = Forms.FormBorderStyle.FixedDialog;
                elegir.MinimizeBox = elegir.MaximizeBox = false;
                elegir.ClientSize = new System.Drawing.Size(500, 100);
                lista.DropDownStyle = Forms.ComboBoxStyle.DropDownList;
                lista.SetBounds(12, 12, 476, 25);
                foreach (FamilySymbol tipo in tipos) lista.Items.Add(tipo.Name);
                lista.SelectedIndex = 0;
                aceptar.Text = "Aceptar"; aceptar.DialogResult = Forms.DialogResult.OK;
                aceptar.SetBounds(302, 55, 90, 30);
                cancelar.Text = "Cancelar"; cancelar.DialogResult = Forms.DialogResult.Cancel;
                cancelar.SetBounds(398, 55, 90, 30);
                elegir.Controls.AddRange(new Forms.Control[] { lista, aceptar, cancelar });
                elegir.AcceptButton = aceptar; elegir.CancelButton = cancelar;
                return elegir.ShowDialog() == Forms.DialogResult.OK ? tipos[lista.SelectedIndex] : null;
            }
        }

        private static void ValidarOpciones(LadrillosLosaOpciones opciones)
        {
            if (opciones == null) throw new InvalidOperationException("No se recibieron opciones de colocación.");
            foreach (double valor in new[] { opciones.ViguetaCm, opciones.JuntaCm, opciones.MargenCm, opciones.DesfaseBaseCm })
                if (double.IsNaN(valor) || double.IsInfinity(valor) || valor < 0)
                    throw new InvalidOperationException("Las separaciones, margen y desfase deben ser números finitos no negativos.");
        }

        private static FamilyInstance Crear(Document doc, FamilySymbol tipo, Floor suelo, Level nivel,
            XYZ punto, bool hospedado)
        {
            FamilyInstance instancia = hospedado
                ? doc.Create.NewFamilyInstance(punto, tipo, suelo, nivel, StructuralType.NonStructural)
                : doc.Create.NewFamilyInstance(punto, tipo, nivel, StructuralType.NonStructural);
            if (instancia == null) throw new InvalidOperationException("Revit no pudo crear la familia seleccionada.");
            return instancia;
        }

        private static DatosSuelo LeerSuelo(Floor suelo)
        {
            CompoundStructure estructura = suelo.FloorType.GetCompoundStructure();
            if (estructura != null && estructura.VariableLayerIndex >= 0)
                throw new InvalidOperationException("Esta versión trabaja con losas de espesor constante. " +
                    "El tipo seleccionado tiene una capa de espesor variable.");
            var superiores = HostObjectUtils.GetTopFaces(suelo)
                .Select(x => suelo.GetGeometryObjectFromReference(x)).OfType<PlanarFace>().ToList();
            var inferiores = HostObjectUtils.GetBottomFaces(suelo)
                .Select(x => suelo.GetGeometryObjectFromReference(x)).OfType<PlanarFace>().ToList();
            if (superiores.Count == 0 || inferiores.Count == 0 ||
                superiores.Count != HostObjectUtils.GetTopFaces(suelo).Count ||
                inferiores.Count != HostObjectUtils.GetBottomFaces(suelo).Count ||
                superiores.Any(x => x.FaceNormal.Z < 1 - 1e-9) ||
                inferiores.Any(x => x.FaceNormal.Z > -1 + 1e-9))
                throw new InvalidOperationException("Selecciona una losa horizontal, con caras superior e inferior planas.");
            double arriba = superiores[0].Origin.Z, abajo = inferiores[0].Origin.Z;
            if (arriba <= abajo || superiores.Any(x => Math.Abs(x.Origin.Z - arriba) > Tolerancia) ||
                inferiores.Any(x => Math.Abs(x.Origin.Z - abajo) > Tolerancia))
                throw new InvalidOperationException("La losa tiene desniveles o espesor irregular; no se puede colocar una malla plana.");
            List<Solid> solidos = Solidos(suelo).Select(x => SolidUtils.CreateTransformed(x, Transform.Identity)).ToList();
            if (solidos.Count == 0) throw new InvalidOperationException("No se encontró el sólido del suelo.");
            Mesh malla = superiores[0].Triangulate();
            if (malla.NumTriangles == 0) throw new InvalidOperationException("No se pudo obtener un punto interior del suelo.");
            MeshTriangle triangulo = malla.get_Triangle(0);
            XYZ semilla = (triangulo.get_Vertex(0) + triangulo.get_Vertex(1) + triangulo.get_Vertex(2)) / 3;
            return new DatosSuelo { Superior = arriba, Inferior = abajo, CarasSuperiores = superiores,
                Solidos = solidos, Volumen = solidos.Sum(x => x.Volume), Semilla = semilla };
        }

        private static List<IList<LadrilloPunto>> Contornos(IEnumerable<PlanarFace> caras, Marco marco)
        {
            var resultado = new List<IList<LadrilloPunto>>();
            foreach (PlanarFace cara in caras)
                foreach (CurveLoop loop in cara.GetEdgesAsCurveLoops())
                {
                    var puntos = new List<LadrilloPunto>();
                    foreach (Curve curva in loop)
                    {
                        IList<XYZ> muestra = curva.Tessellate();
                        for (int i = 0; i < muestra.Count - 1; i++)
                            puntos.Add(marco.Proyectar(muestra[i]));
                    }
                    if (puntos.Count < 3) throw new InvalidOperationException("Un contorno de la losa no tiene puntos suficientes.");
                    resultado.Add(puntos);
                }
            return resultado;
        }

        private static bool CabeEnSolidos(IList<Solid> suelo, Marco marco, LadrilloPunto centro,
            double largo, double ancho, double baseZ, double alto)
        {
            XYZ[] p = { marco.Punto(centro.X - largo / 2, centro.Y - ancho / 2, baseZ),
                marco.Punto(centro.X + largo / 2, centro.Y - ancho / 2, baseZ),
                marco.Punto(centro.X + largo / 2, centro.Y + ancho / 2, baseZ),
                marco.Punto(centro.X - largo / 2, centro.Y + ancho / 2, baseZ) };
            using (var contorno = new CurveLoop())
            {
                for (int i = 0; i < 4; i++) contorno.Append(Line.CreateBound(p[i], p[(i + 1) % 4]));
                Solid restante = GeometryCreationUtilities.CreateExtrusionGeometry(new List<CurveLoop> { contorno }, XYZ.BasisZ, alto);
                try
                {
                    double toleranciaVolumen = Math.Max(1e-8, restante.Volume * 1e-7);
                    foreach (Solid anfitrion in suelo)
                    {
                        Solid siguiente = BooleanOperationsUtils.ExecuteBooleanOperation(restante, anfitrion, BooleanOperationsType.Difference);
                        restante.Dispose();
                        restante = siguiente;
                        if (restante.Volume <= toleranciaVolumen) return true;
                    }
                    return restante.Volume <= toleranciaVolumen;
                }
                finally { restante.Dispose(); }
            }
        }

        private static void ComprobarVolumenSuelo(Floor suelo, double original)
        {
            double actual = Solidos(suelo).Sum(x => x.Volume);
            if (Math.Abs(actual - original) > Math.Max(1e-8, original * 1e-8))
                throw new InvalidOperationException("La familia está cortando o alterando el anfitrión. " +
                    "Utiliza una familia de ladrillo sin vacíos que corten el suelo. Se revierte la operación.");
        }

        private static List<Solid> Solidos(Element elemento)
        {
            var resultado = new List<Solid>();
            var opciones = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false };
            Recorrer(elemento.get_Geometry(opciones), Transform.Identity, (s, t) =>
                resultado.Add(t.IsIdentity ? s : SolidUtils.CreateTransformed(s, t)));
            return resultado;
        }

        private static void Recorrer(GeometryElement geometria, Transform transformacion, Action<Solid, Transform> recibir)
        {
            if (geometria == null) return;
            foreach (GeometryObject objeto in geometria)
            {
                Solid solido = objeto as Solid;
                if (solido != null && solido.Faces.Size > 0 && solido.Volume > 1e-12)
                    recibir(solido, transformacion);
                GeometryInstance instancia = objeto as GeometryInstance;
                if (instancia != null)
                    Recorrer(instancia.GetSymbolGeometry(), transformacion.Multiply(instancia.Transform), recibir);
            }
        }

        private static Caja Medir(Element elemento, Marco marco)
        {
            var caja = new Caja();
            var opciones = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false };
            Recorrer(elemento.get_Geometry(opciones), Transform.Identity, (s, t) =>
            {
                // Medir en ejes de las filas, también cuando Revit entrega un sólido
                // directo en coordenadas del modelo en lugar de GeometryInstance.
                // Proyectar su caja mundial inflaría la huella al girarla en planta.
                using (Solid local = SolidUtils.CreateTransformed(s, marco.ModeloALocal.Multiply(t)))
                using (BoundingBoxXYZ limite = local.GetBoundingBox())
                {
                    for (int i = 0; i < 8; i++)
                    {
                        XYZ p = limite.Transform.OfPoint(new XYZ((i & 1) == 0 ? limite.Min.X : limite.Max.X,
                            (i & 2) == 0 ? limite.Min.Y : limite.Max.Y, (i & 4) == 0 ? limite.Min.Z : limite.Max.Z));
                        caja.Incluir(p.X, p.Y, p.Z);
                    }
                }
            });
            if (double.IsInfinity(caja.MinU))
                throw new InvalidOperationException("La familia no contiene geometría sólida visible en detalle fino.");
            return caja;
        }

        private static IndiceCajas LeerExistentes(Document doc, FamilySymbol tipo, ElementId plantilla,
            Marco marco, double largo, double ancho)
        {
            var indice = new IndiceCajas(Math.Max(largo, ancho));
            foreach (FamilyInstance instancia in new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)))
            {
                if (instancia.Id.Equals(plantilla) || instancia.SuperComponent != null ||
                    !instancia.Symbol.Family.Id.Equals(tipo.Family.Id)) continue;
                indice.Agregar(Medir(instancia, marco));
            }
            return indice;
        }

        private static double Pies(double centimetros) { return centimetros / 30.48; }
        private static string Cm(double pies) { return (pies * 30.48).ToString("0.###", CultureInfo.CurrentCulture); }

        private sealed class FiltroSuelo : ISelectionFilter
        {
            public bool AllowElement(Element element) { return element is Floor; }
            public bool AllowReference(Reference reference, XYZ position) { return false; }
        }

        private sealed class Marco
        {
            internal readonly XYZ Origen, U, V;
            internal readonly Transform ModeloALocal;
            internal Marco(XYZ origen, XYZ u)
            {
                Origen = origen; U = u; V = new XYZ(-u.Y, u.X, 0);
                Transform aModelo = Transform.Identity;
                aModelo.Origin = new XYZ(origen.X, origen.Y, 0);
                aModelo.BasisX = U; aModelo.BasisY = V; aModelo.BasisZ = XYZ.BasisZ;
                ModeloALocal = aModelo.Inverse;
            }
            internal LadrilloPunto Proyectar(XYZ p)
            {
                XYZ d = p - Origen;
                return new LadrilloPunto(d.DotProduct(U), d.DotProduct(V));
            }
            internal XYZ Punto(double u, double v, double z)
            { return new XYZ(Origen.X + U.X * u + V.X * v, Origen.Y + U.Y * u + V.Y * v, z); }
        }

        private sealed class DatosSuelo
        {
            internal double Superior, Inferior, Volumen;
            internal List<PlanarFace> CarasSuperiores;
            internal List<Solid> Solidos;
            internal XYZ Semilla;
        }

        private sealed class Caja
        {
            internal double MinU = double.PositiveInfinity, MinV = double.PositiveInfinity, MinZ = double.PositiveInfinity;
            internal double MaxU = double.NegativeInfinity, MaxV = double.NegativeInfinity, MaxZ = double.NegativeInfinity;
            internal Caja() { }
            internal Caja(double minU, double maxU, double minV, double maxV, double minZ, double maxZ)
            { MinU = minU; MaxU = maxU; MinV = minV; MaxV = maxV; MinZ = minZ; MaxZ = maxZ; }
            internal void Incluir(double u, double v, double z)
            {
                MinU = Math.Min(MinU, u); MaxU = Math.Max(MaxU, u);
                MinV = Math.Min(MinV, v); MaxV = Math.Max(MaxV, v);
                MinZ = Math.Min(MinZ, z); MaxZ = Math.Max(MaxZ, z);
            }
            internal bool Intersecta(Caja otra)
            {
                return MinU < otra.MaxU - Tolerancia && MaxU > otra.MinU + Tolerancia &&
                    MinV < otra.MaxV - Tolerancia && MaxV > otra.MinV + Tolerancia &&
                    MinZ < otra.MaxZ - Tolerancia && MaxZ > otra.MinZ + Tolerancia;
            }
        }

        private sealed class IndiceCajas
        {
            private readonly double paso;
            private readonly Dictionary<string, List<Caja>> celdas = new Dictionary<string, List<Caja>>();
            private readonly List<Caja> grandes = new List<Caja>();
            internal IndiceCajas(double paso) { this.paso = paso; }
            private string Clave(long u, long v) { return u.ToString(CultureInfo.InvariantCulture) + ":" + v.ToString(CultureInfo.InvariantCulture); }
            internal void Agregar(Caja caja)
            {
                long u0 = (long)Math.Floor(caja.MinU / paso), u1 = (long)Math.Floor(caja.MaxU / paso);
                long v0 = (long)Math.Floor(caja.MinV / paso), v1 = (long)Math.Floor(caja.MaxV / paso);
                if ((double)(u1 - u0 + 1) * (v1 - v0 + 1) > 1000) { grandes.Add(caja); return; }
                for (long u = u0; u <= u1; u++) for (long v = v0; v <= v1; v++)
                {
                    string clave = Clave(u, v); List<Caja> lista;
                    if (!celdas.TryGetValue(clave, out lista)) celdas.Add(clave, lista = new List<Caja>());
                    lista.Add(caja);
                }
            }
            internal bool Intersecta(Caja caja)
            {
                if (grandes.Any(x => x.Intersecta(caja))) return true;
                long u0 = (long)Math.Floor(caja.MinU / paso), u1 = (long)Math.Floor(caja.MaxU / paso);
                long v0 = (long)Math.Floor(caja.MinV / paso), v1 = (long)Math.Floor(caja.MaxV / paso);
                for (long u = u0; u <= u1; u++) for (long v = v0; v <= v1; v++)
                {
                    List<Caja> lista;
                    if (celdas.TryGetValue(Clave(u, v), out lista) && lista.Any(x => x.Intersecta(caja))) return true;
                }
                return false;
            }
        }

        private sealed class FallosColocacion : IFailuresPreprocessor
        {
            internal string Descripcion = "";
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                var errores = failuresAccessor.GetFailureMessages()
                    .Where(x => x.GetSeverity() == FailureSeverity.Error).ToList();
                if (errores.Count == 0) return FailureProcessingResult.Continue;
                Descripcion = string.Join("\n", errores.Select(x => x.GetDescriptionText()));
                return FailureProcessingResult.ProceedWithRollBack;
            }
        }
    }
}
