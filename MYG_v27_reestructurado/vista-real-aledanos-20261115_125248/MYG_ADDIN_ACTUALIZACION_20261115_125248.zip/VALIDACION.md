# Validación: geometría real de aledaños y orientación

## Ejecutado
-133 pruebas aprobadas,0 fallidas. Se conservan98 anteriores y se añaden35 de proyección y transformación.
- Geometría:rectángulos, viga oblicua conservando ancho/largo en lugar de su caja, caras de arriba/abajo duplicadas con sentidos opuestos, huecos pasantes en anillo, L/entrantes, islas, caras verticales de área proyectada0, coordenadas finitas/límites y traslación remota. La unión normalizada elimina diagonales interiores falsas de triángulos oblicuos sin reemplazar el contorno por una caja.
- Vista:giros, reflejos, ida/vuelta del ratón, conservación de distancias, rechazo de escala/cizalla/singularidad/no finitos y overflow.
- Compilación aislada actual C#7.3/net10.0-windows contra API Revit2027:0 errores/0advertencias. No es carga del add-in completo ni ejecución Revit.
-188 fuentes Roslyn sin errores, rutas de proyecto completas/sin duplicados; gitdiffcheck correcto.
- Compilación completa: MSB4803 (COM en Linux) y advertencia EPPlus.Interfaces preexistente. No hay DLL nueva compilada del complemento completo.

Para repetir, con el proyecto de pruebas existente y los archivos actualizados:
```bash
dotnet restore Pruebas/LadrillosLosas/BrickLayout.Tests.csproj --configfile Pruebas/LadrillosLosas/NuGet.Config
dotnet run --no-restore --project Pruebas/LadrillosLosas/BrickLayout.Tests.csproj
```
Requiere SDK .NET10, sin paquetes nuevos. Código no cero si falla alguna prueba.

## Pendiente en Windows/Revit
No se ejecutó esta matriz en el entorno Linux:

| Caso | Comprobar |
|---|---|
| Perímetro del ejemplo | Vigas y columnas a escala con sus contornos reales, sin cuadrados envolventes ficticios |
| Dimensiones | Comparar cotas de vigas/columnas rectas con mediciones Revit; verificar largo/ancho de una viga oblicua |
| Orientación | Planta rotada o norte de proyecto/real; derecha/arriba coinciden con la vista activa al abrir |
| Edición orientada | Arrastre, zoom, marco de paño y flechas siguen la pantalla; números U/V siguen los ejes de filas |
| Alternar representación | Cambiar orientación no modifica posiciones del modelo ni historial; cancela gesto provisional |
| Inspección | Hover, Alt al superponer ladrillo y clic derecho para fijar ID/medidas; cotas legibles de vecinos visibles |
| Huecos y formas | Entrantes, elementos enL y huecos pasantes no se rellenan por convexhull/bbox |
| Instancias | Familias giradas/anidadas se dibujan en sus posiciones y tamaños físicos |
| Curvas | Aparecen teseladas y marcadas aproximadas; no acotar cada cuerda como longitud de curva exacta |
| Monitor | Ventana dentro del área útil, paneles con scroll y encabezados visibles |
| Compatibilidad anterior | Fila/pieza/paño, historial, inclusión, límites, checkboxUnir, fallbackomitir y unSoloDeshacerRevit |
| Densidad | Más de200.000triángulos informa límite sin falsas cajas; selección manual reduce alcance |

No se presenta una captura ficticia ni estas verificaciones pendientes como realizadas.
