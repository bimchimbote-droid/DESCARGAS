# MYG · Aledaños reales, orientación de Revit y cotas

## A. Cambio y base de trabajo
La vista anterior dibujaba los aledaños como rectángulos obtenidos de sus cajas envolventes y alineaba la pantalla con la dirección U de los ladrillos. Por eso no coincidían sus formas/orientación con el modelo.

Esta actualización sustituye esas cajas dibujadas por **siluetas físicas en planta extraídas de los sólidos reales de Revit**, conserva por defecto la orientación derecha/arriba de la vista activa y añade cotas de aristas rectas en centímetros. Mantiene el editor de filas/paños, los desplazamientos, historial y resolución de encuentros.

Base real: `bimchimbote-droid/MYG_v27_reestructurado`, HEAD Git `2a8977e8032d0bd9d12d7302b897d5096b0cf064` más las entregas anteriores. Se aplica sobre `MYG_ADDIN_ACTUALIZACION_20261115_121247.zip`, publicado en DESCARGAS en commit `16f4893ee1864fee784e434fce63a117dfbb8cef`, SHA256 `326cbbce0fa432e8619d5aeac803467b1de5aa8e5570e3e4794f2fb37b41619a`. Se conservan sus cambios, estructura y dependencias; no se sustituye por otra rama.

## B. Archivos afectados
| Ruta | Acción |
|---|---|
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLosaCommand.cs | REEMPLAZAR: conexión con geometría real y ejes de la vista activa |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosPreviewForm.cs | REEMPLAZAR: representación orientada, cotas e inspección de vecinos |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosLayout.cs | REEMPLAZAR: mantiene editor y añade unión de proyecciones/transformación de vista |
| MYG/Funcionalidades/Estructuras/LadrillosLosas/LadrillosInterferencias.cs | REEMPLAZAR: extrae las siluetas de los sólidos originales de cada aledaño |
| Pruebas/LadrillosLosas/Program.cs | REEMPLAZAR en proyecto opcional de pruebas:133 casos |

ARCHIVOS.csv identifica acciones y hashes antes/después. No hay archivos nuevos del complemento, eliminaciones, parches ni cambios de csproj/referencias/paquetes. LadrillosLosaForm.cs, Ribbon y archivos de pruebas sin cambios quedan fuera del ZIP. Tampoco se incluyen modelos, familias, DLL, paquetes ni credenciales.

## C. Paquete
`MYG_ADDIN_ACTUALIZACION_20261115_125248.zip`, fecha/hora America/Lima. Su publicación y comprobación de descarga se informan después de realizarlas. Se publica solo el ZIP de código/pruebas/instrucciones autorizado, sin modelos del usuario y conservando entregas anteriores.

## D. Instalación
1. Cierra Revit y respalda la solución y la DLL de la versión anterior.
2. Reemplaza los **cuatro archivos C# del complemento** conservando las rutas. Se entregan completos. Instálalos juntos: cambió el contrato interno de los datos que recibe el visor; no mezcles formulario nuevo con comando/motor anteriores.
3. Si tienes cambios propios posteriores, compara/fusiona antes de reemplazar para no perderlos.
4. Si utilizas las pruebas opcionales, sustituye su Program.cs; no lo añadas al proyecto del add-in. Conserva el csproj de pruebas y NuGet.Config existentes.
5. No cambies el csproj ni vuelvas a aplicar parches anteriores: todas las clases están dentro de archivos ya incluidos.
6. Compila en Windows, actualiza MYG.dll en su ubicación habitual con Revit cerrado y reinicia Revit antes de cargarla con AddInManager. Conserva el manifiesto .addin y MYG_Addin.App.

## E. Visualización y uso
Al abrir el editor quedan activadas:
- **Orientación de la vista de Revit:** usa los ejes derecha/arriba de la planta activa al iniciar el comando. La losa, aledaños y ladrillos aparecen con esa orientación, en lugar de enderezar todas las filas horizontalmente. Si la desmarcas, puedes volver a alinear las filas en pantalla; las posiciones del modelo no cambian.
- **Mostrar aledaños reales:** contornos rellenos grises y bordes físicos de los vecinos incluidos en la búsqueda/selección. Ya no se muestran como rectángulos envolventes ficticios.
- **Mostrar cotas en centímetros:** longitudes de aristas rectas obtenidas de los contornos proyectados. Se muestran cotas resumidas de hasta12 aledaños rectos visibles para evitar saturación; al inspeccionar uno se muestran más aristas.

Pasa el cursor sobre una viga, muro o columna para consultar **ID, nombre y medidas**. Si un ladrillo ocupa la misma zona gráfica, mantén Alt para priorizar al aledaño. Con clic derecho puedes fijar sus datos/cotas; otro clic sobre él los libera. El detalle permite leer medidas aunque no quepan todas las etiquetas en el dibujo. Usa zoom para cotas de aristas muy cortas.

Las medidas se calculan desde sus vértices geométricos y se convierten de pies internos a cm. Para una viga oblicua se mide la longitud de su arista, no el ancho/largo de una caja alineada a pantalla. Las cotas de la vista son gráficas del editor y no añaden anotaciones al proyecto Revit.

El encuadre inicial deja0,5–1m de contexto alrededor de la losa para ver elementos de perímetro y se ajusta al área disponible del monitor. No amplía toda la vista para abarcar un muro que continúe muy lejos; puedes alejar el zoom para inspeccionarlo completo.

### Mover filas con la nueva orientación
Se conservan fila/pieza/paño/malla, marco, arrastre, paso, deshacer/rehacer, exclusión y checkbox de unión.
- El ratón y el marco de selección se transforman inversamente a UV; se seleccionan/mueven las piezas que realmente ves bajo el cursor.
- Las **flechas siguen la dirección de pantalla**. Los campos numéricos **U/V mantienen la dirección de filas/transversal** elegida en Revit. Así puedes mover visualmente arriba/abajo sin confundir una fila oblicua con la horizontal de la pantalla.
- Girar la representación con el checkbox no gira ni escala los datos ni crea un cambio de historial. El editor sigue validando contornos, huecos, solapamientos y vecinos antes de crear.

## F. Validación ejecutada
- **133 pruebas aprobadas,0 fallidas:**98 anteriores y35 nuevas de proyección/orientación. Comprueban perfiles rectos y oblicuos, cancelación de caras duplicadas evitada, huecos/entrantes/islas conservados, eliminación de diagonales interiores falsas, giros/reflexiones e inversa sin deformar dimensiones.
- Compilación aislada C#7.3/net10.0-windows contra las DLL reales disponibles de API Revit2027: **0 errores y0 advertencias**. El harness usa adaptadores externos de integración para acceso/registro; no se incluyen en el complemento ni en el ZIP.
- Roslyn:188 fuentes activas sin errores;188 Compile,9 EmbeddedResource y3 None existentes y sin duplicados. gitdiffcheck correcto.
- Compilación completa intentada: sigue bloqueada por MSB4803 en COM bajo Linux/MSBuild .NET Core; permanece MSB3277 de EPPlus.Interfaces preexistente.
- **No se ejecutó esta interfaz ni la extracción sobre un modelo dentro de Revit en el entorno Linux.** Las pruebas de matemáticas y la compilación no equivalen a una comprobación visual/funcional. VALIDACION.md contiene la comparación manual pendiente.

## G. GitHub
Solo se publica el ZIP en DESCARGAS. No se modifican ramas del repositorio del código ni se actualiza tu PC. Tras instalar/compilar/probar, revisa los diffs en Cambios de Git de Visual Studio, crea tu Commit y haz Push desde tu equipo cuando decidas publicar el código.

## H. Precisión y alcance
- Es una **proyección física2D en planta**, no una captura/renderización nativa de Revit. No reproduce tramas de materiales, líneas simbólicas, ocultación o plano de corte de la vista. La orientación se toma de la planta activa al abrir el editor; no sincroniza en vivo su cámara.
- Los aledaños son los incluidos en el alcance automático o manual del comando, que puede incluir elementos ocultos en esa vista; no se dibujan vínculos ni se inventa geometría de elementos sin sólidos. Se conserva la posibilidad de elegir vecinos manualmente.
- Las caras planas/rectas usan sus vértices físicos. La unión de siluetas trabaja con resolución de1e-7pie (aprox0,00003048mm) y las cotas se presentan en cm con hasta2decimales. La escala de pantalla no cambia el valor medido.
- Las caras o aristas curvas usan la teselación nativa de Revit a nivel de detalle1. Se identifican como **curvas/proyección aproximada**; no se presentan las cuerdas de la malla como longitudes analíticas exactas de la curva. Su rangoZ y extensiones también se indican aproximados.
- Se proyectan las caras de sólidos y se unen sus triángulos, sin sustituirlos por una caja/convexhull ni rellenar huecos pasantes. Las transformaciones de instancias/anidadas ya están aplicadas a los sólidos. Las cajas siguen utilizándose solo como filtro de búsqueda/interferencia, no para la forma dibujada.
- La geometría de los vecinos se obtiene del estado original tras revertir la pieza de medición. No se alteran aledaños para dibujarlos. El límite es200.000 triángulos de vecinos por ejecución; si se supera o no puede obtenerse una silueta válida, se informa y no se sustituye silenciosamente por cajas. Reduce el alcance manual en geometrías muy densas.
- Los ladrillos mantienen su huella editable medida y huecos esquemáticos. La representación real de vecinos no transforma el editor en un visor3D ni simula visualmente el recorte3D final de cada ladrillo.
- Se conservan la resolución de encuentros y sus límites/compatibilidades previos: Revit debe admitir cada unión/corte; si no resuelve, la pieza se omite. No se migró el framework ni se cambiaron dependencias originales.
