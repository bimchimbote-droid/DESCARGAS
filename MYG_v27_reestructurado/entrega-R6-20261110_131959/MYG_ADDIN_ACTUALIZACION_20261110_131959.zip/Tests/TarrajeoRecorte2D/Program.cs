using MYG_Addin;
using MYG_Addin.RecorteClipper;
using Path2D = System.Collections.Generic.List<MYG_Addin.RecorteClipper.IntPoint>;
using Region = System.Collections.Generic.List<System.Collections.Generic.List<MYG_Addin.RecorteClipper.IntPoint>>;

const double S = 304800.0;
int passed = 0, failed = 0;
Test("rectangle without obstacles remains one rectangle", () => Check(Cut(Rect(0,0,10,10)),100,1,0,4));
Test("internal obstacle creates its actual opening", () => Check(Cut(Rect(0,0,10,10), R(Rect(2,2,4,4))),96,1,1));
Test("partial obstacle creates a notch", () => Check(Cut(Rect(0,0,10,10), R(Rect(4,-1,6,3))),94,1,0,8));
Test("only a transverse obstacle separates two panels", () => Check(Cut(Rect(0,0,10,10),R(Rect(4,-1,6,11))),80,2,0));
Test("complete cover leaves no finish", () => Check(Cut(Rect(0,0,10,10),R(Rect(-1,-1,11,11))),0,0,0));
Test("external obstacle does not modify the face", () => Check(Cut(Rect(0,0,10,10),R(Rect(11,0,12,10))),100,1,0,4));
Test("duplicate faces never cancel an obstacle", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(Rect(2,2,4,4))),96,1,1));
Test("overlapping obstacles are subtracted once", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,6,6)),R(Rect(4,2,8,6))),76,1,1));
Test("triangulated rectangle has no diagonal in its final opening", () => {
    var tree=Cut(Rect(0,0,10,10),R(P(2,2,4,2,4,4)),R(P(2,2,4,4,2,4)));
    Check(tree,96,1,1); Assert(Contours(tree).All(p=>RecortePlanoExterior.QuitarColineales(p).Count==4),"A mesh diagonal survived.");
});
Test("thin triangles inside a footprint never enlarge the cut", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(P(3.999,2,4,3,3.999,4))),96,1,1));
Test("all triangles of a rectangular face unite into one panel", () => {
    var normalized=RecortePlanoExterior.UnirRegion(R(P(0,0,10,0,10,10),P(0,0,10,10,0,10)));
    Check(RecortePlanoExterior.Restar(normalized,Array.Empty<Region>()),100,1,0,4);
});
Test("original face openings are preserved", () => Check(RecortePlanoExterior.Restar(R(Rect(0,0,10,10),Rect(2,2,4,4)),new[]{R(Rect(11,0,12,10))}),96,1,1));
Test("obstacle opening retains a natural island", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,8,8),Rect(4,4,6,6))),68,2,1));
Test("another obstacle fills the opening in an obstacle", () => Check(Cut(Rect(0,0,10,10),R(Rect(2,2,8,8),Rect(4,4,6,6)),R(Rect(4,4,6,6))),64,1,1));
Test("reversed contours preserve ownership", () => {
    var face=Rect(0,0,10,10);face.Reverse();var hole=Rect(2,2,4,4);hole.Reverse();
    Check(Cut(face,R(hole)),96,1,1);
});
Test("rotated rectangles keep rectangular boundaries", () => {
    Path2D Rotate(Path2D p)=>p.Select(v=>new IntPoint((3*v.X-4*v.Y)/5,(4*v.X+3*v.Y)/5)).ToList();
    var tree=Cut(Rotate(Rect(0,0,10,10)),R(Rotate(Rect(2,2,4,4))));
    Check(tree,96,1,1);Assert(Contours(tree).All(p=>RecortePlanoExterior.QuitarColineales(p).Count==4),"Unexpected diagonal/vertex.");
});
Test("two close obstacles keep the real material gap", () => {
    var tree=Cut(Rect(0,0,10,10),R(Rect(2,2,4,4)),R(Rect(4.01,2,6,4)));
    Check(tree,92.02,1,2);
});
Test("redundant collinear vertices do not become edges", () => {
    var p=P(0,0,5,0,10,0,10,10,0,10,0,0);Assert(RecortePlanoExterior.QuitarColineales(p).Count==4,"Collinear vertex remained.");
});
Test("same domain is independent of orientation and redundant vertices", () => {
    var a=R(Rect(0,0,10,10),Rect(2,2,4,4));var b=R(P(10,10,10,0,5,0,0,0,0,10),Rect(2,2,4,4));
    Assert(RecortePlanoExterior.MismoDominio(a,b),"Equal domain changed.");
});
Test("equal area with a moved opening is a different domain", () => Assert(!RecortePlanoExterior.MismoDominio(R(Rect(0,0,10,10),Rect(2,2,4,4)),R(Rect(0,0,10,10),Rect(6,6,8,8))),"Opening location was ignored."));
Test("upward finish is outside the solid", () => Near(TarrajeoAlturas.CalcularDesfase(100,90,1,.05,0),10.05));
Test("downward finish is outside the solid", () => Near(TarrajeoAlturas.CalcularDesfase(100,90,-1,.05,0),10));
Test("internal project level controls offset", () => Near(TarrajeoAlturas.CalcularDesfase(1100,1090,1,.05,0),10.05));
Test("contact check rejects a finish penetrating the host", () => Assert(!TarrajeoAlturas.ContactoExteriorValido(-.01,.04,0,.0003),"Penetration accepted."));
Test("contact check accepts an external finish touching the face", () => Assert(TarrajeoAlturas.ContactoExteriorValido(0,.05,0,.0003),"External contact rejected."));
Test("precision removes a long almost-collinear backtracking spike", () => {
    var p=new Path2D { new IntPoint(0,0),new IntPoint(1000000,0),new IntPoint(1000000,1000000),
        new IntPoint(0,1000000),new IntPoint(0,1015000),new IntPoint(1,1000000) };
    var tree=RecortePlanoExterior.Restar(R(p),Array.Empty<Region>());
    Assert(!HasNumericalBacktrack(tree),"The near-collinear reverse edge survived.");
    Assert(Contours(tree).All(q=>q.Count>=3 && q.Count<=4),"A precision spike remains in the boundary.");
    Assert(Math.Abs(Contours(tree).Sum(Clipper.Area)-1e12)<5000000,"The main panel was changed.");
});
Test("precision removes a long sub-micrometre triangular residue", () => {
    var p=new Path2D {new IntPoint(0,0),new IntPoint(337000,0),new IntPoint(15000,1)};
    var tree=RecortePlanoExterior.Restar(R(p),Array.Empty<Region>());
    Assert(!Contours(tree).Any(),"Degenerate long triangle was retained as a floor profile.");
});
Test("precision removes a second thin rotated numerical residue", () => {
    var p=new Path2D {new IntPoint(0,0),new IntPoint(120000,90000),new IntPoint(80001,60000)};
    Assert(!Contours(RecortePlanoExterior.Restar(R(p),Array.Empty<Region>())).Any(),"Thin rotated residue survived.");
});
Test("a real half-millimetre bevel is never silently removed", () => {
    var p=new Path2D {new IntPoint(0,0),new IntPoint(1000000,0),new IntPoint(1000000,999500),
        new IntPoint(999500,1000000),new IntPoint(0,1000000)};
    var tree=RecortePlanoExterior.Restar(R(p),Array.Empty<Region>());
    Assert(Contours(tree).Single().Count==5,"A real bevel was removed using a creation tolerance.");
    Assert(RecortePlanoExterior.MismoDominio(R(p),Contours(tree).ToList()),"The real bevel domain changed.");
});
Test("a ten-micrometre gap survives precision cleaning", () => {
    var a=new Path2D {new IntPoint(1000,1000),new IntPoint(2000,1000),new IntPoint(2000,2000),new IntPoint(1000,2000)};
    var b=a.Select(v=>new IntPoint(v.X+1010,v.Y)).ToList();
    var face=new Path2D {new IntPoint(0,0),new IntPoint(5000,0),new IntPoint(5000,5000),new IntPoint(0,5000)};
    var tree=RecortePlanoExterior.Restar(R(face),new[]{R(a),R(b)});
    var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Assert(nodes.Count(n=>n.IsHole)==2,"Precision cleaning merged genuinely separate openings.");
});
Test("a real small opening survives cleaning", () => {
    var face=new Path2D {new IntPoint(0,0),new IntPoint(10000,0),new IntPoint(10000,10000),new IntPoint(0,10000)};
    var hole=new Path2D {new IntPoint(4000,4000),new IntPoint(5000,4000),new IntPoint(5000,5000),new IntPoint(4000,5000)};
    var tree=RecortePlanoExterior.Restar(R(face,hole),Array.Empty<Region>());
    Assert(Contours(tree).Count()==2,"A real opening was filled.");
});
// R6 tests use the explicit local-repair operation. Restar retains the R5
// contract: real small details are not silently changed by precision cleaning.
Test("local repair handles a half-millimetre step without offsetting the panel", () => {
    var node=LocalNode(IP(0,0,10000,0,10000,10000,5000,10000,5000,9500,0,9500));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(Clipper.PointInPolygon(LocalScalePoint(new IntPoint(10,10),adjusted.Factor),LocalTree(adjusted.Paths).Childs.Single().Contour)==1,
        "Remote material was removed by a global offset.");
});
Test("a convex short bevel is repaired by removing material only", () => {
    var node=LocalNode(IP(0,0,10000,0,10000,9650,9650,10000,0,10000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Removed>0,"The forbidden support-line corner was filled instead of trimming the bevel.");
});
Test("short bevel in an opening expands the void conservatively", () => {
    var node=LocalNode(IRect(0,0,20000,20000),IP(5000,5000,15000,5000,15000,14650,14650,15000,5000,15000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Removed>0,"The opening was not repaired conservatively.");
});
Test("valid contours are returned unchanged by local repair", () => {
    var node=LocalNode(IRect(0,0,10000,10000),IRect(2000,2000,4000,4000));
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    Assert(adjusted.Factor==1.0,"A valid contour was unnecessarily rescaled.");
    Assert(LocalSame(LocalPaths(node),adjusted.Paths),"An already valid contour changed.");
    Near(adjusted.Removed,0,0.5);
});
Test("insufficient repair distance returns the original domain without partial changes", () => {
    var node=LocalNode(IP(0,0,10000,0,10000,9650,9650,10000,0,10000));
    var adjusted=LocalAdjust(node,800,100);
    Assert(!adjusted.Accepted,"A 0.495mm edge was repaired beyond the 0.1mm distance limit.");
    Assert(adjusted.Factor==1.0,"Failure did not return the original coordinate scale.");
    Assert(LocalSame(LocalPaths(node),adjusted.Paths),"Failure leaked a partially repaired region.");
    Near(adjusted.Removed,0,0.5);
});
Test("local corner repair preserves an independent opening exactly", () => {
    var opening=IRect(2000,2000,4000,4000);
    var node=LocalNode(IP(0,0,10000,0,10000,9650,9650,10000,0,10000),opening);
    var adjusted=LocalAdjust(node,800,1000);
    CheckLocalRepair(node,adjusted,800,1000);
    var hole=LocalTree(adjusted.Paths).Childs.Single().Childs.Single();
    Assert(LocalSame(LocalScalePaths(R(opening),adjusted.Factor),R(hole.Contour)),"An unrelated opening changed during a corner repair.");
});
Test("local repair works across the closing edge and after rotation", () => {
    Path2D TransformLocal(Path2D p)=>p.Select(v=>new IntPoint(300000+v.Y,-200000-v.X)).ToList();
    var node=LocalNode(TransformLocal(IP(0,0,10000,0,10000,10000,5000,10000,5000,9500,0,9500)));
    for(int shift=0;shift<node.Contour.Count;shift++) {
        var rotated=new Path2D(node.Contour.Skip(shift).Concat(node.Contour.Take(shift)));
        var testNode=LocalRawNode(rotated);
        CheckLocalRepair(testNode,LocalAdjust(testNode,800,1000),800,1000);
    }
});
Test("all independent short corners must be repaired before success", () => {
    var node=LocalNode(IP(0,350,350,0,10000,0,10000,9650,9650,10000,0,10000));
    CheckLocalRepair(node,LocalAdjust(node,800,1000),800,1000);
});
Test("failure after a provisional repair rolls the whole owner back", () => {
    var one=LocalNode(IP(0,0,10000,0,10000,9440,9440,10000,0,10000));
    CheckLocalRepair(one,LocalAdjust(one,800,100),800,100);
    var combined=LocalNode(IP(0,0,10000,0,10000,9440,9440,10000,350,10000,0,9650));
    var adjusted=LocalAdjust(combined,800,100);
    Assert(!adjusted.Accepted,"A second corner exceeded the distance limit but was accepted.");
    Assert(adjusted.Factor==1.0,"Failed multi-corner repair did not restore the original coordinate scale.");
    Assert(LocalSame(LocalPaths(combined),adjusted.Paths),"Failure leaked the first provisional corner repair.");
    Near(adjusted.Removed,0,0.5);
});
Test("rotated one-metre panel repairs a 0.499673mm step without rounding it outside its support", () => {
    double angle=17.03*Math.PI/180.0, cosine=Math.Cos(angle),sine=Math.Sin(angle);
    var raw=new[] {(0.0,0.0),(1000000.0,0.0),(1000000.0,1000000.0),
        (500000.0,1000000.0),(500000.0,999500.327),(0.0,999500.327)};
    var path=raw.Select(p=>new IntPoint(
        (long)Math.Round(p.Item1*cosine-p.Item2*sine,MidpointRounding.AwayFromZero),
        (long)Math.Round(p.Item1*sine+p.Item2*cosine,MidpointRounding.AwayFromZero))).ToList();
    var node=LocalNode(path);
    CheckLocalRepair(node,LocalAdjust(node,800,1000),800,1000);
});
Console.WriteLine($"Passed: {passed}; failed: {failed}; total: {passed+failed}");
Console.WriteLine("Production planar set operations and height rules only; no Revit runtime or model execution.");
return failed==0?0:1;

Path2D P(params double[] xy) { var p=new Path2D();for(int i=0;i<xy.Length;i+=2)p.Add(new IntPoint((long)Math.Round(xy[i]*S),(long)Math.Round(xy[i+1]*S)));return p; }
Path2D Rect(double x0,double y0,double x1,double y1)=>P(x0,y0,x1,y0,x1,y1,x0,y1);
Region R(params Path2D[] paths)=>paths.ToList();
PolyTree Cut(Path2D face,params Region[] obstacles)=>RecortePlanoExterior.Restar(R(face),obstacles);
IEnumerable<Path2D> Contours(PolyTree tree) { for(var n=tree.GetFirst();n!=null;n=n.GetNext())yield return n.Contour; }
void Check(PolyTree tree,double area,int regions,int holes,int? vertices=null) {
    var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Near(nodes.Sum(n=>Clipper.Area(n.Contour))/(S*S),area,1e-7);
    Assert(nodes.Count(n=>!n.IsHole)==regions,$"regions={nodes.Count(n=>!n.IsHole)} expected={regions}");
    Assert(nodes.Count(n=>n.IsHole)==holes,$"holes={nodes.Count(n=>n.IsHole)} expected={holes}");
    if(vertices.HasValue)Assert(nodes.Where(n=>!n.IsHole).All(n=>RecortePlanoExterior.QuitarColineales(n.Contour).Count==vertices),"Unexpected artificial edges.");
}
void Near(double actual,double expected,double tolerance=1e-9)=>Assert(Math.Abs(actual-expected)<=tolerance,$"actual={actual:G17}, expected={expected:G17}");
void Assert(bool condition,string message) { if(!condition)throw new InvalidOperationException(message); }
void Test(string name,Action test) { try{test();passed++;Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+": "+e.Message);} }

bool HasNumericalBacktrack(PolyTree tree) {
    foreach(var p in Contours(tree)) for(int i=0;i<p.Count;i++) {
        var a=p[(i+p.Count-1)%p.Count];var b=p[i];var c=p[(i+1)%p.Count];
        double x=(double)c.X-a.X,y=(double)c.Y-a.Y;
        double cross=((double)b.X-a.X)*y-((double)b.Y-a.Y)*x;
        double dot=((double)b.X-a.X)*((double)c.X-b.X)+((double)b.Y-a.Y)*((double)c.Y-b.Y);
        if(dot<0 && Math.Abs(cross)/Math.Max(1,Math.Sqrt(x*x+y*y))<=2) return true;
    }
    return false;
}

// Integer-grid helpers below verify the production result with independent
// Clipper differences, topology checks and a local capsule around SHORT edges.
Path2D IP(params long[] xy) { var p=new Path2D();for(int i=0;i<xy.Length;i+=2)p.Add(new IntPoint(xy[i],xy[i+1]));return p; }
Path2D IRect(long x0,long y0,long x1,long y1)=>IP(x0,y0,x1,y0,x1,y1,x0,y1);
PolyNode LocalNode(Path2D outer,params Path2D[] holes) {
    var all=R(outer);all.AddRange(holes);
    var clipper=new Clipper {StrictlySimple=true};clipper.AddPaths(all,PolyType.ptSubject,true);
    var tree=new PolyTree();Assert(clipper.Execute(ClipType.ctUnion,tree,PolyFillType.pftEvenOdd,PolyFillType.pftEvenOdd),"Could not build test region.");
    Assert(tree.Childs.Count==1,"Test requires one owner.");return tree.Childs[0];
}
PolyNode LocalRawNode(Path2D outer) { var root=new PolyTree();var node=new PolyNode();root.AddChild(node);node.Contour.AddRange(outer);return node; }
Region LocalPaths(PolyNode node)=>new Region {new Path2D(node.Contour)}.Concat(node.Childs.Where(c=>c.IsHole).Select(c=>new Path2D(c.Contour))).ToList();
PolyTree LocalTree(Region paths) {
    var motor=new Clipper {StrictlySimple=true};motor.AddPaths(paths,PolyType.ptSubject,true);
    var tree=new PolyTree();Assert(motor.Execute(ClipType.ctUnion,tree,PolyFillType.pftNonZero,PolyFillType.pftNonZero),"Could not read adjusted domain.");return tree;
}
(bool Accepted,Region Paths,double Removed,string Detail,double Factor) LocalAdjust(PolyNode node,double minimum,double limit) {
    var method=typeof(RecortePlanoExterior).GetMethod("AjustarAristasCortas",
        System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Public);
    Assert(method!=null,"Conservative local adjustment is not implemented in this production version.");
    var before=LocalPaths(node);object[] args={node,minimum,limit,null,0.0,null,1.0};
    bool accepted;
    try { accepted=(bool)method.Invoke(null,args); }
    catch(System.Reflection.TargetInvocationException ex) when(ex.InnerException!=null) {
        throw new InvalidOperationException("Production repair threw: "+ex.InnerException.Message,ex.InnerException);
    }
    Assert(before.Count==LocalPaths(node).Count && before.Zip(LocalPaths(node),(a,b)=>a.SequenceEqual(b)).All(x=>x),
        "The repair operation mutated its input region.");
    var paths=args[3] as Region;Assert(paths!=null,"Repair did not return a domain.");
    return (accepted,paths,(double)args[4],args[5] as string??"",(double)args[6]);
}
void CheckLocalRepair(PolyNode original,(bool Accepted,Region Paths,double Removed,string Detail,double Factor) result,double minimum,double limit) {
    Assert(result.Accepted,"Repair failed: "+result.Detail);
    double factor=result.Factor;
    Assert(double.IsFinite(factor) && factor>=1.0 && factor<=1000000.0 && factor==Math.Floor(factor),
        "The repair returned an invalid coordinate refinement factor.");
    var before=LocalScalePaths(LocalPaths(original),factor);var after=result.Paths;
    double scaledMinimum=minimum*factor,scaledLimit=limit*factor;
    Assert(after.Count>0,"Repair erased the panel.");
    Assert(LocalArea2(R(after[0])).Sign>0 && after.Skip(1).All(p=>LocalArea2(R(p)).Sign<0),
        "Returned contours must list the positive outer ring first and negative openings afterwards.");
    Assert(!LocalDifferenceHasArea(after,before),"Repair added material inside an interference.");
    var tree=LocalTree(after);var nodes=new List<PolyNode>();for(var n=tree.GetFirst();n!=null;n=n.GetNext())nodes.Add(n);
    Assert(nodes.Count(n=>!n.IsHole)==1,"Repair split the owner into separate panels.");
    Assert(nodes.Count(n=>n.IsHole)==original.Childs.Count(n=>n.IsHole),"Repair changed the number of openings.");
    foreach(var path in after) {
        Assert(path.Count>=3,"An adjusted ring is degenerate.");
        for(int i=0;i<path.Count;i++) {
            var a=path[i];var b=path[(i+1)%path.Count];
            Assert(LocalLength(a,b)+1e-7*factor>=scaledMinimum,"A short edge survived in the accepted repair.");
            var c=path[(i+2)%path.Count];
            if(LocalOrientation(a,b,c)==0) {
                System.Numerics.BigInteger abx=(System.Numerics.BigInteger)b.X-a.X,aby=(System.Numerics.BigInteger)b.Y-a.Y;
                System.Numerics.BigInteger bcx=(System.Numerics.BigInteger)c.X-b.X,bcy=(System.Numerics.BigInteger)c.Y-b.Y;
                Assert(abx*bcx+aby*bcy>=0,"An adjacent overlapping reversal survived.");
            }
            for(int j=i+1;j<path.Count;j++) {
                if(j==i+1||i==0&&j==path.Count-1)continue;
                Assert(!LocalSegmentsTouch(a,b,path[j],path[(j+1)%path.Count]),"An adjusted ring crosses or touches itself.");
            }
        }
    }
    for(int i=0;i<after.Count;i++)for(int j=i+1;j<after.Count;j++)
        for(int a=0;a<after[i].Count;a++)for(int b=0;b<after[j].Count;b++)
            Assert(!LocalSegmentsTouch(after[i][a],after[i][(a+1)%after[i].Count],after[j][b],after[j][(b+1)%after[j].Count]),"Adjusted rings cross or touch.");
    var twiceRemoved=LocalArea2(before)-LocalArea2(after);
    Assert(twiceRemoved.Sign>=0,"The adjusted domain gained exact integer area.");
    double removedInBaseUnits=(double)twiceRemoved/(2.0*factor*factor);
    Assert(result.Removed>=-0.5,"Removed area was reported with the wrong sign.");
    Near(result.Removed,removedInBaseUnits,2.0);
    var shortEdges=new Region();
    foreach(var path in before)for(int i=0;i<path.Count;i++)
        if(LocalLength(path[i],path[(i+1)%path.Count])<scaledMinimum)
            shortEdges.Add(new Path2D {path[i],path[(i+1)%path.Count]});
    var removed=LocalDifference(before,after);
    if(shortEdges.Count==0) Assert(removed.Count==0,"A valid panel changed without a short edge.");
    else {
        // Keep the verifier's arc error fixed in physical units as coordinates
        // are refined; a default 0.25 at factor1e6 would create huge capsules.
        var buffer=new ClipperOffset(2.0,0.25*factor);
        buffer.AddPaths(shortEdges,JoinType.jtRound,EndType.etOpenRound);
        var allowed=new Region();buffer.Execute(ref allowed,scaledLimit);
        Assert(!LocalDifferenceHasArea(removed,allowed),"Repair removed material away from the short-edge encounter.");
    }
}
Region LocalDifference(Region subject,Region clip) {
    var paths=new Region();if(subject.Count==0)return paths;
    var motor=new Clipper {StrictlySimple=true};motor.AddPaths(subject,PolyType.ptSubject,true);
    if(clip.Count>0)motor.AddPaths(clip,PolyType.ptClip,true);
    Assert(motor.Execute(ClipType.ctDifference,paths,PolyFillType.pftNonZero,PolyFillType.pftNonZero),"Geometry comparison failed.");return paths;
}
bool LocalDifferenceHasArea(Region subject,Region clip)=>LocalDifference(subject,clip).Any(p=>!LocalArea2(R(p)).IsZero);
bool LocalSame(Region a,Region b)=>!LocalDifferenceHasArea(a,b)&&!LocalDifferenceHasArea(b,a);
double LocalLength(IntPoint a,IntPoint b)=>Math.Sqrt(Math.Pow((double)b.X-a.X,2)+Math.Pow((double)b.Y-a.Y,2));
int LocalOrientation(IntPoint a,IntPoint b,IntPoint c)=>(((System.Numerics.BigInteger)b.X-a.X)*((System.Numerics.BigInteger)c.Y-a.Y)-((System.Numerics.BigInteger)b.Y-a.Y)*((System.Numerics.BigInteger)c.X-a.X)).Sign;
bool LocalOnSegment(IntPoint p,IntPoint a,IntPoint b)=>p.X>=Math.Min(a.X,b.X)&&p.X<=Math.Max(a.X,b.X)&&p.Y>=Math.Min(a.Y,b.Y)&&p.Y<=Math.Max(a.Y,b.Y);
bool LocalSegmentsTouch(IntPoint a,IntPoint b,IntPoint c,IntPoint d) {
    int x=LocalOrientation(a,b,c),y=LocalOrientation(a,b,d),z=LocalOrientation(c,d,a),w=LocalOrientation(c,d,b);
    return x*y<0&&z*w<0 || x==0&&LocalOnSegment(c,a,b) || y==0&&LocalOnSegment(d,a,b) || z==0&&LocalOnSegment(a,c,d) || w==0&&LocalOnSegment(b,c,d);
}

IntPoint LocalScalePoint(IntPoint point,double factor)=>new IntPoint(checked(point.X*(long)factor),checked(point.Y*(long)factor));
Region LocalScalePaths(Region paths,double factor)=>paths.Select(path=>path.Select(p=>LocalScalePoint(p,factor)).ToList()).ToList();
System.Numerics.BigInteger LocalArea2(Region paths) {
    System.Numerics.BigInteger sum=0;
    foreach(var path in paths)for(int i=0;i<path.Count;i++) {
        var a=path[i];var b=path[(i+1)%path.Count];
        sum+=(System.Numerics.BigInteger)a.X*b.Y-(System.Numerics.BigInteger)b.X*a.Y;
    }
    return sum;
}
