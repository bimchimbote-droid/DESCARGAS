using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin.RecorteClipper;

namespace MYG_Addin
{
    // Operaciones de conjuntos en UN plano. Los triángulos de una superficie
    // son datos de entrada, nunca piezas de acabado ni contornos de salida.
    internal static class RecortePlanoExterior
    {
        internal static List<List<IntPoint>> UnirRegion(IEnumerable<List<IntPoint>> contornos)
        {
            var caminos = contornos.Where(x => x != null && x.Count >= 3 &&
                Math.Abs(Clipper.Area(x)) >= 0.5).ToList();
            if (caminos.Count == 0)
                return new List<List<IntPoint>>();
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(caminos, PolyType.ptSubject, true))
                throw new InvalidOperationException("No se pudo registrar un contorno de la región.");
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd))
                throw new InvalidOperationException("No se pudo normalizar una región plana.");
            return Clipper.PolyTreeToPaths(arbol);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes)
        {
            double antes, despues;
            return Restar(cara, superficiesCortantes, out antes, out despues);
        }

        internal static PolyTree Restar(
            List<List<IntPoint>> cara, IEnumerable<List<List<IntPoint>>> superficiesCortantes,
            out double areaAntesPrecision, out double areaDespuesPrecision)
        {
            areaAntesPrecision = areaDespuesPrecision = 0.0;
            var sujeto = UnirRegion(cara);
            if (sujeto.Count == 0)
                throw new InvalidOperationException("La cara seleccionada no contiene una región cerrada.");
            // Normalizar CADA superficie con sus huecos antes de unirlas.
            // Duplicados de tapas y triángulos nunca se cancelan entre sí.
            var cortes = new List<List<IntPoint>>();
            foreach (var superficie in superficiesCortantes)
                cortes.AddRange(UnirRegion(superficie));
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (cortes.Count > 0)
                motor.AddPaths(cortes, PolyType.ptClip, true);
            var resultado = new PolyTree();
            if (!motor.Execute(ClipType.ctDifference, resultado,
                PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo descontar la unión de interferencias.");
            areaAntesPrecision = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            resultado = RegularizarPrecision(resultado);
            double areaOriginal = sujeto.Sum(Clipper.Area);
            double areaFinal = Clipper.PolyTreeToPaths(resultado).Sum(Clipper.Area);
            areaDespuesPrecision = areaFinal;
            double toleranciaNumerica = Math.Max(1.0, Math.Abs(areaOriginal) * 1e-12) +
                3.0 * sujeto.Sum(Perimetro) + 36.0 * sujeto.Count;
            if (areaFinal < -toleranciaNumerica || areaFinal > areaOriginal + toleranciaNumerica)
                throw new InvalidOperationException("El recorte no conserva el área de la cara.");
            return resultado;
        }

        // Una celda equivale a 0.001 mm en el adaptador Revit. El redondeo de
        // rectas oblicuas puede convertir un retroceso colineal en una aguja
        // de anchura inferior a una celda. Revit la considera solape aunque
        // sus dos aristas sean largas y el CurveLoop esté cerrado y horizontal.
        internal static PolyTree RegularizarPrecision(PolyTree original)
        {
            var antes = Clipper.PolyTreeToPaths(original);
            if (antes.Count == 0)
                return original;
            var limpios = Clipper.CleanPolygons(antes, 2.0).Where(x => x.Count >= 3).ToList();
            if (antes.Count == limpios.Count && antes.Zip(limpios, (a, b) => a.SequenceEqual(b)).All(x => x))
                return original;
            var despues = new PolyTree();
            if (limpios.Count > 0)
            {
                var union = new Clipper { StrictlySimple = true };
                union.AddPaths(limpios, PolyType.ptSubject, true);
                if (!union.Execute(ClipType.ctUnion, despues, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                    throw new InvalidOperationException("No se pudo regularizar la precisión del contorno.");
            }
            var nuevos = Clipper.PolyTreeToPaths(despues);
            // No confiar solo en el área: exigir que no aparezca material fuera
            // de una envolvente de 3 celdas y que se conserve todo el interior
            // situado a más de 3 celdas del borde original. Así no se rediseña
            // un paño ni se elimina un hueco fuera de esa banda de precisión.
            var offset = new ClipperOffset();
            offset.AddPaths(antes, JoinType.jtMiter, EndType.etClosedPolygon);
            var exterior = new List<List<IntPoint>>();
            var interior = new List<List<IntPoint>>();
            offset.Execute(ref exterior, 3.0);
            offset.Execute(ref interior, -3.0);
            if (HayDiferenciaConArea(nuevos, exterior) || HayDiferenciaConArea(interior, nuevos))
                throw new InvalidOperationException("La limpieza excedería 0.003 mm; se conservó el rechazo del contorno.");
            double delta = Math.Abs(nuevos.Sum(Clipper.Area) - antes.Sum(Clipper.Area));
            if (delta > 3.0 * antes.Sum(Perimetro) + 36.0 * antes.Count)
                throw new InvalidOperationException("La limpieza alteraría un área no atribuible a la precisión numérica.");
            return despues;
        }

        // Ajuste explícito de encuentros, posterior a la limpieza de precisión.
        // minimo/limite están en celdas de 0.001 mm; areaRetirada en celdas².
        // Las coordenadas de salida se dividen por factorCoordenadas antes de
        // convertirlas a Revit: no volver a redondear el encuentro oblicuo.
        // Nunca modificar nodo: si algún encuentro no admite solución, devolver
        // false con el propietario original, sin confirmar ediciones parciales.
        internal static bool AjustarAristasCortas(PolyNode nodo, double minimo, double limite,
            out List<List<IntPoint>> contornos, out double areaRetirada, out string diagnostico,
            out double factorCoordenadas)
        {
            var entrada = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            entrada.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            factorCoordenadas = 1.0;
            if (double.IsNaN(minimo) || double.IsInfinity(minimo) || minimo <= 0.0 ||
                double.IsNaN(limite) || double.IsInfinity(limite) || limite <= 2.0 ||
                AristasCortas(entrada, minimo).Count == 0)
                return AjustarAristasEnRejilla(nodo, minimo, limite, out contornos,
                    out areaRetirada, out diagnostico, 1.0);
            double maximo = entrada.SelectMany(x => x).Max(p => Math.Max(Math.Abs((double)p.X), Math.Abs((double)p.Y)));
            long factor = (long)Math.Max(1.0, Math.Min(1000000.0, Math.Floor(1e14 / (maximo + limite + 1.0))));
            var raiz = new PolyTree();
            var refinado = new PolyNode();
            raiz.AddChild(refinado);
            refinado.Contour.AddRange(entrada[0].Select(p => new IntPoint(p.X * factor, p.Y * factor)));
            foreach (var camino in entrada.Skip(1))
            {
                var hueco = new PolyNode();
                refinado.AddChild(hueco);
                hueco.Contour.AddRange(camino.Select(p => new IntPoint(p.X * factor, p.Y * factor)));
            }
            double areaRefinada;
            bool ajustado = AjustarAristasEnRejilla(refinado, minimo * factor, limite * factor,
                out contornos, out areaRefinada, out diagnostico, factor);
            if (!ajustado)
            {
                contornos = entrada;
                areaRetirada = 0.0;
                return false;
            }
            factorCoordenadas = factor;
            areaRetirada = areaRefinada / factor / factor;
            return true;
        }

        private static bool AjustarAristasEnRejilla(PolyNode nodo, double minimo, double limite,
            out List<List<IntPoint>> contornos, out double areaRetirada, out string diagnostico,
            double factor)
        {
            var original = new List<List<IntPoint>> { new List<IntPoint>(nodo.Contour) };
            original.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => new List<IntPoint>(x.Contour)));
            contornos = CopiarContornos(original);
            areaRetirada = 0.0;
            diagnostico = string.Empty;
            if (double.IsNaN(minimo) || double.IsInfinity(minimo) || minimo <= 0.0 ||
                double.IsNaN(limite) || double.IsInfinity(limite) || limite <= 2.0)
            {
                diagnostico = "Tolerancias no válidas para el ajuste local.";
                return false;
            }
            List<List<IntPoint>> actual;
            if (!NormalizarPropietario(original, original.Count - 1, out actual))
            {
                diagnostico = "El propietario no conserva un exterior y todos sus huecos separados.";
                return false;
            }
            var entrada = original;
            original = CopiarContornos(actual);
            var cortasIniciales = AristasCortas(actual, minimo);
            if (cortasIniciales.Count == 0)
            {
                contornos = actual;
                return true;
            }
            // Anclar la localidad a las aristas cortas ORIGINALES, no a todo el
            // perímetro ni a una posición que pueda ir desplazándose por pasos.
            var offset = new ClipperOffset(2.0, 0.25 * factor);
            foreach (var arista in cortasIniciales)
                offset.AddPath(arista, JoinType.jtRound, EndType.etOpenRound);
            var vecindad = new List<List<IntPoint>>();
            // Una celda base de reserva mantiene incluso el redondeo del buffer
            // dentro del límite físico solicitado (1 mm en el adaptador).
            offset.Execute(ref vecindad, limite - factor);
            double objetivo = Math.Ceiling(minimo + Math.Max(2.0 * factor, minimo * 0.01));
            int pasos = 0;
            while (true)
            {
                var anteriores = AristasCortas(actual, minimo);
                if (anteriores.Count == 0)
                {
                    contornos = actual;
                    areaRetirada = (double)(AreaDobleExacta(original) - AreaDobleExacta(actual)) / 2.0;
                    diagnostico = "Ajuste local conservador: " + pasos + " encuentros; área retirada " +
                        (areaRetirada / factor / factor / 1000000.0).ToString("0.######", System.Globalization.CultureInfo.InvariantCulture) +
                        " mm²; límite " + (limite / factor / 1000.0).ToString("0.###",
                            System.Globalization.CultureInfo.InvariantCulture) + " mm.";
                    return true;
                }
                if (pasos >= 128)
                    break;
                List<List<IntPoint>> mejor = null;
                double menorRetirada = double.PositiveInfinity;
                // Prioridad a una esquina formada por los soportes existentes.
                // Solo si no hay solución válida se permite un bisel microlocal.
                for (int modo = 0; modo < 2 && mejor == null; modo++)
                    for (int r = 0; r < actual.Count; r++)
                        for (int i = 0; i < actual[r].Count; i++)
                        {
                            var anillo = actual[r];
                            int n = anillo.Count;
                            IntPoint a = anillo[(i + n - 1) % n], b = anillo[i];
                            IntPoint c = anillo[(i + 1) % n], d = anillo[(i + 2) % n];
                            if (Distancia(b, c) > minimo)
                                continue;
                            if (modo == 0)
                            {
                                IntPoint esquina;
                                if (InterseccionSoportes(a, b, c, d, out esquina) &&
                                    Distancia(esquina, b) <= limite && Distancia(esquina, c) <= limite &&
                                    DireccionesConservadas(a, b, c, d, esquina, esquina))
                                {
                                    var candidato = EditarEncuentro(actual, r, i, esquina, esquina, true);
                                    EvaluarEdicion(actual, original, candidato, vecindad, minimo,
                                        anteriores, ref mejor, ref menorRetirada);
                                }
                                continue;
                            }
                            double ab = Distancia(a, b), cd = Distancia(c, d);
                            if (ab == 0.0 || cd == 0.0)
                                continue;
                            double ux = ((double)b.X - a.X) / ab, uy = ((double)b.Y - a.Y) / ab;
                            double vx = ((double)d.X - c.X) / cd, vy = ((double)d.Y - c.Y) / cd;
                            for (int sb = -1; sb <= 1; sb++)
                                for (int sc = -1; sc <= 1; sc++)
                                {
                                    if (sb == 0 && sc == 0)
                                        continue;
                                    double wx = sc * vx - sb * ux, wy = sc * vy - sb * uy;
                                    double w2 = wx * wx + wy * wy;
                                    if (w2 <= 1e-20)
                                        continue;
                                    double qx = (double)c.X - b.X, qy = (double)c.Y - b.Y;
                                    double dot = qx * wx + qy * wy;
                                    double raiz = dot * dot + w2 * (objetivo * objetivo - qx * qx - qy * qy);
                                    if (raiz < 0.0)
                                        continue;
                                    double t = (-dot + Math.Sqrt(raiz)) / w2;
                                    if (t < 0.0 || t > limite)
                                        continue;
                                    // Pasos enteros del vector primitivo: el punto
                                    // permanece EXACTAMENTE sobre su soporte,
                                    // incluso en bordes largos y oblicuos. No
                                    // redondear X/Y por separado a 0.001 mm.
                                    IntPoint p = MoverEnSoporte(a, b, b, sb, t);
                                    IntPoint q = MoverEnSoporte(c, d, c, sc, t);
                                    if (Distancia(b, p) > limite || Distancia(c, q) > limite ||
                                        Distancia(p, q) < objetivo || !DireccionesConservadas(a, b, c, d, p, q))
                                        continue;
                                    // No sacrificar un borde vecino que ya era creable.
                                    if ((ab > minimo && Distancia(a, p) <= minimo) ||
                                        (cd > minimo && Distancia(q, d) <= minimo))
                                        continue;
                                    var candidato = EditarEncuentro(actual, r, i, p, q, false);
                                    EvaluarEdicion(actual, original, candidato, vecindad, minimo,
                                        anteriores, ref mejor, ref menorRetirada);
                                }
                        }
                if (mejor == null)
                    break;
                actual = mejor;
                pasos++;
            }
            // También preservar el original si una segunda arista falla tras
            // haber encontrado una solución provisional para la primera.
            contornos = CopiarContornos(entrada);
            areaRetirada = 0.0;
            diagnostico = "No hay un ajuste local completo dentro de " + (limite / factor / 1000.0)
                .ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
                " mm que respete el material disponible, los huecos y el mínimo de Revit (" +
                (minimo / factor / 1000.0).ToString("0.######", System.Globalization.CultureInfo.InvariantCulture) +
                " mm). Se conserva el contorno original.";
            return false;
        }

        private static void EvaluarEdicion(List<List<IntPoint>> actual, List<List<IntPoint>> original,
            List<List<IntPoint>> candidato, List<List<IntPoint>> vecindad, double minimo,
            List<List<IntPoint>> cortasAntes, ref List<List<IntPoint>> mejor, ref double menorRetirada)
        {
            List<List<IntPoint>> nuevo;
            if (!NormalizarPropietario(candidato, original.Count - 1, out nuevo))
                return;
            var cortasNuevas = AristasCortas(nuevo, minimo);
            if (cortasNuevas.Count >= cortasAntes.Count || cortasNuevas.Any(e =>
                !cortasAntes.Any(a => (e[0] == a[0] && e[1] == a[1]) || (e[0] == a[1] && e[1] == a[0]))))
                return;
            if (HayDiferenciaExacta(nuevo, actual))
                return; // Nunca rellenar parte de una huella cortante.
            var retirado = Diferencia(original, nuevo);
            if (HayDiferenciaExacta(retirado, vecindad))
                return; // No perder una banda del paño ni desplazar su perímetro.
            double perdida = (double)(AreaDobleExacta(actual) - AreaDobleExacta(nuevo)) / 2.0;
            if (perdida < 0.0 || perdida >= menorRetirada)
                return;
            mejor = nuevo;
            menorRetirada = perdida;
        }

        private static bool NormalizarPropietario(List<List<IntPoint>> contornos, int numeroHuecos,
            out List<List<IntPoint>> normalizados)
        {
            normalizados = null;
            if (contornos.Any(x => x.Count < 3))
                return false;
            var motor = new Clipper { StrictlySimple = true };
            if (!motor.AddPaths(contornos, PolyType.ptSubject, true))
                return false;
            var arbol = new PolyTree();
            if (!motor.Execute(ClipType.ctUnion, arbol, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                return false;
            var exteriores = new List<PolyNode>();
            for (var nodo = arbol.GetFirst(); nodo != null; nodo = nodo.GetNext())
                if (!nodo.IsHole) exteriores.Add(nodo);
            if (exteriores.Count != 1 || exteriores[0].Childs.Count(x => x.IsHole) != numeroHuecos)
                return false;
            normalizados = new List<List<IntPoint>> { QuitarColineales(exteriores[0].Contour) };
            normalizados.AddRange(exteriores[0].Childs.Where(x => x.IsHole).Select(x => QuitarColineales(x.Contour)));
            for (int i = 0; i < normalizados.Count; i++)
                for (int j = i + 1; j < normalizados.Count; j++)
                    if (AnillosSeTocan(normalizados[i], normalizados[j]))
                        return false;
            return normalizados.All(x => x.Count >= 3 && Math.Abs(Clipper.Area(x)) >= 0.5 && AnilloSimple(x));
        }

        private static List<List<IntPoint>> EditarEncuentro(List<List<IntPoint>> original,
            int anillo, int indice, IntPoint p, IntPoint q, bool colapsar)
        {
            var copia = CopiarContornos(original);
            var puntos = original[anillo];
            // Rotar para tratar también la arista de cierre sin índices inválidos.
            var editado = new List<IntPoint> { p };
            if (!colapsar) editado.Add(q);
            for (int k = 2; k < puntos.Count; k++)
                editado.Add(puntos[(indice + k) % puntos.Count]);
            copia[anillo] = editado;
            return copia;
        }

        private static List<List<IntPoint>> CopiarContornos(List<List<IntPoint>> caminos)
        {
            return caminos.Select(x => new List<IntPoint>(x)).ToList();
        }

        private static List<List<IntPoint>> AristasCortas(List<List<IntPoint>> caminos, double minimo)
        {
            var cortas = new List<List<IntPoint>>();
            foreach (var camino in caminos)
                for (int i = 0; i < camino.Count; i++)
                    if (Distancia(camino[i], camino[(i + 1) % camino.Count]) <= minimo)
                        cortas.Add(new List<IntPoint> { camino[i], camino[(i + 1) % camino.Count] });
            return cortas;
        }

        private static bool InterseccionSoportes(IntPoint a, IntPoint b, IntPoint c, IntPoint d,
            out IntPoint punto)
        {
            punto = new IntPoint();
            double ux = (double)b.X - a.X, uy = (double)b.Y - a.Y;
            double vx = (double)d.X - c.X, vy = (double)d.Y - c.Y;
            double den = ux * vy - uy * vx;
            if (Math.Abs(den) <= 1e-12 * Distancia(a, b) * Distancia(c, d))
                return false;
            double t = (((double)c.X - b.X) * vy - ((double)c.Y - b.Y) * vx) / den;
            double x = b.X + t * ux, y = b.Y + t * uy;
            if (double.IsNaN(x) || double.IsInfinity(x) || double.IsNaN(y) || double.IsInfinity(y) ||
                Math.Abs(x) > 1e14 || Math.Abs(y) > 1e14)
                return false;
            punto = PuntoRedondeado(x, y);
            return true;
        }

        private static IntPoint PuntoRedondeado(double x, double y)
        {
            return new IntPoint((long)Math.Round(x, MidpointRounding.AwayFromZero),
                (long)Math.Round(y, MidpointRounding.AwayFromZero));
        }

        private static IntPoint MoverEnSoporte(IntPoint a, IntPoint b, IntPoint origen, int signo, double distancia)
        {
            if (signo == 0)
                return origen;
            long dx = b.X - a.X, dy = b.Y - a.Y;
            long m = Math.Abs(dx), n = Math.Abs(dy);
            while (n != 0) { long resto = m % n; m = n; n = resto; }
            if (m == 0)
                return origen;
            long x = dx / m, y = dy / m;
            double paso = Math.Sqrt((double)x * x + (double)y * y);
            long cantidad = (long)Math.Ceiling(distancia / paso);
            return new IntPoint(origen.X + signo * cantidad * x, origen.Y + signo * cantidad * y);
        }

        private static System.Numerics.BigInteger AreaDobleExacta(List<List<IntPoint>> caminos)
        {
            System.Numerics.BigInteger area = 0;
            foreach (var camino in caminos)
                for (int i = 0; i < camino.Count; i++)
                {
                    IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                    area += (System.Numerics.BigInteger)a.X * b.Y - (System.Numerics.BigInteger)a.Y * b.X;
                }
            return area;
        }

        private static bool HayDiferenciaExacta(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            if (sujeto.Count == 0)
                return false;
            return Diferencia(sujeto, corte).Any(p => AreaDobleExacta(new List<List<IntPoint>> { p }) != 0);
        }

        private static bool DireccionesConservadas(IntPoint a, IntPoint b, IntPoint c, IntPoint d,
            IntPoint p, IntPoint q)
        {
            return ((double)b.X - a.X) * ((double)p.X - a.X) +
                ((double)b.Y - a.Y) * ((double)p.Y - a.Y) > 0.0 &&
                ((double)d.X - c.X) * ((double)d.X - q.X) +
                ((double)d.Y - c.Y) * ((double)d.Y - q.Y) > 0.0;
        }

        private static double Distancia(IntPoint a, IntPoint b)
        {
            double x = (double)b.X - a.X, y = (double)b.Y - a.Y;
            return Math.Sqrt(x * x + y * y);
        }

        private static bool AnillosSeTocan(List<IntPoint> a, List<IntPoint> b)
        {
            for (int i = 0; i < a.Count; i++)
                for (int j = 0; j < b.Count; j++)
                {
                    IntPoint p = a[i], q = a[(i + 1) % a.Count], r = b[j], s = b[(j + 1) % b.Count];
                    int o1 = Orientacion(p, q, r), o2 = Orientacion(p, q, s);
                    int o3 = Orientacion(r, s, p), o4 = Orientacion(r, s, q);
                    if (o1 * o2 < 0 && o3 * o4 < 0 ||
                        o1 == 0 && EnSegmento(r, p, q) || o2 == 0 && EnSegmento(s, p, q) ||
                        o3 == 0 && EnSegmento(p, r, s) || o4 == 0 && EnSegmento(q, r, s))
                        return true;
                }
            return false;
        }

        private static bool AnilloSimple(List<IntPoint> camino)
        {
            for (int i = 0; i < camino.Count; i++)
            {
                IntPoint p = camino[i], q = camino[(i + 1) % camino.Count];
                if (p == q)
                    return false;
                for (int j = i + 1; j < camino.Count; j++)
                {
                    if (j == i + 1 || i == 0 && j == camino.Count - 1)
                        continue;
                    IntPoint r = camino[j], s = camino[(j + 1) % camino.Count];
                    int o1 = Orientacion(p, q, r), o2 = Orientacion(p, q, s);
                    int o3 = Orientacion(r, s, p), o4 = Orientacion(r, s, q);
                    if (o1 * o2 < 0 && o3 * o4 < 0 ||
                        o1 == 0 && EnSegmento(r, p, q) || o2 == 0 && EnSegmento(s, p, q) ||
                        o3 == 0 && EnSegmento(p, r, s) || o4 == 0 && EnSegmento(q, r, s))
                        return false;
                }
            }
            return true;
        }

        private static int Orientacion(IntPoint a, IntPoint b, IntPoint c)
        {
            return (((System.Numerics.BigInteger)b.X - a.X) * ((System.Numerics.BigInteger)c.Y - a.Y) -
                ((System.Numerics.BigInteger)b.Y - a.Y) * ((System.Numerics.BigInteger)c.X - a.X)).Sign;
        }

        private static bool EnSegmento(IntPoint p, IntPoint a, IntPoint b)
        {
            return p.X >= Math.Min(a.X, b.X) && p.X <= Math.Max(a.X, b.X) &&
                p.Y >= Math.Min(a.Y, b.Y) && p.Y <= Math.Max(a.Y, b.Y);
        }

        private static List<List<IntPoint>> Diferencia(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            motor.AddPaths(corte, PolyType.ptClip, true);
            var resultado = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctDifference, resultado, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo verificar el ajuste local.");
            return resultado;
        }

        private static bool HayDiferenciaConArea(List<List<IntPoint>> sujeto, List<List<IntPoint>> corte)
        {
            if (sujeto.Count == 0)
                return false;
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(sujeto, PolyType.ptSubject, true);
            if (corte.Count > 0)
                motor.AddPaths(corte, PolyType.ptClip, true);
            var resultado = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctDifference, resultado, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo verificar la envolvente de precisión.");
            return resultado.Any(x => Math.Abs(Clipper.Area(x)) >= 0.5);
        }

        private static double Perimetro(List<IntPoint> camino)
        {
            double longitud = 0.0;
            for (int i = 0; i < camino.Count; i++)
            {
                IntPoint a = camino[i], b = camino[(i + 1) % camino.Count];
                double x = (double)b.X - a.X, y = (double)b.Y - a.Y;
                longitud += Math.Sqrt(x * x + y * y);
            }
            return longitud;
        }

        internal static bool MismoDominio(List<List<IntPoint>> a, List<List<IntPoint>> b)
        {
            var motor = new Clipper { StrictlySimple = true };
            motor.AddPaths(UnirRegion(a), PolyType.ptSubject, true);
            motor.AddPaths(UnirRegion(b), PolyType.ptClip, true);
            var diferencia = new List<List<IntPoint>>();
            if (!motor.Execute(ClipType.ctXor, diferencia, PolyFillType.pftNonZero, PolyFillType.pftNonZero))
                throw new InvalidOperationException("No se pudo comprobar el dominio de la cara.");
            return diferencia.All(x => Math.Abs(Clipper.Area(x)) < 0.5);
        }

        internal static List<IntPoint> QuitarColineales(List<IntPoint> original)
        {
            var puntos = new List<IntPoint>();
            foreach (var p in original)
                if (puntos.Count == 0 || puntos[puntos.Count - 1] != p)
                    puntos.Add(p);
            if (puntos.Count > 1 && puntos[0] == puntos[puntos.Count - 1])
                puntos.RemoveAt(puntos.Count - 1);
            bool cambio = true;
            while (cambio && puntos.Count > 3)
            {
                cambio = false;
                for (int i = 0; i < puntos.Count; i++)
                {
                    IntPoint a = puntos[(i + puntos.Count - 1) % puntos.Count];
                    IntPoint b = puntos[i], c = puntos[(i + 1) % puntos.Count];
                    System.Numerics.BigInteger ax = (System.Numerics.BigInteger)b.X - a.X;
                    System.Numerics.BigInteger ay = (System.Numerics.BigInteger)b.Y - a.Y;
                    System.Numerics.BigInteger bx = (System.Numerics.BigInteger)c.X - b.X;
                    System.Numerics.BigInteger by = (System.Numerics.BigInteger)c.Y - b.Y;
                    if (ax * by == ay * bx && ax * bx + ay * by >= 0)
                    {
                        puntos.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }
            return puntos;
        }
    }
}
