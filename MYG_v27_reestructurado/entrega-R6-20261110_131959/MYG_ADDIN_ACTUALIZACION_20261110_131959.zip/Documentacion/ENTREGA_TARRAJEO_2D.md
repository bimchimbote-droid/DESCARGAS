# Ajuste local de encuentros de suelo — TARRAJEO-PLANO-R6

## Base y alcance autorizado

Se trabaja en `bimchimbote-droid/MYG_v27_reestructurado`, master, base Git `cb9d73137e06f55741862274e4ee839bb87e5d80`, conservando los cambios locales anteriores. La base inmediata de esta entrega es R5 publicada en DESCARGAS, commit `5c5be2e1b196f717e30bbf601e27762545d9edf4`.

Se implementa la regla acordada: conservar los sólidos visibles, incluidos los tarrajeos de las vigas, y adaptar únicamente el boceto del suelo en encuentros con aristas menores que el mínimo real de Revit. No se borran muros, no se ignoran obstáculos ni se modifica su geometría. El ajuste es explícito, local y limitado a 1 mm; el suelo solo puede perder material respecto al perfil disponible preparado por R5.

El motor de muros también utiliza el adaptador compartido. La nueva opción se activa únicamente desde `Tarrajeo_SuelosHandler`; para los demás llamadores queda desactivada por defecto. Se mantienen altura exterior, espesor, tipo, vista activa, visibilidad, selección, vínculos, ventanas y recursos.

## Funcionamiento

1. Calcular la cara menos la unión de interferencias, con la limpieza de precisión de R5.
2. Detectar aristas cuya longitud no supera `Application.ShortCurveTolerance`, sin asumir un valor fijo.
3. Intentar primero reconstruir la esquina con la intersección de las rectas soporte vecinas. Si eso añade material, cambia un hueco o excede el límite, se rechaza.
4. Si no hay una esquina válida con esos soportes, probar un microbisel local moviendo uno o ambos extremos sobre sus rectas. Este pequeño conector puede ser diagonal, pero queda junto al encuentro y dentro de 1 mm; no es una división del paño ni una diagonal de gran longitud.
5. Elegir una corrección conservadora de menor área retirada dentro de cada estrategia. Los bordes nuevos alcanzan el mínimo con margen del 1%, o al menos 0.002 mm.
6. Repetir solo mientras disminuya la cantidad de aristas cortas y no se creen otras nuevas. Confirmar la región únicamente cuando todas sus aristas sean creables.

Cada edición debe ser subconjunto del perfil anterior. El material retirado debe estar dentro de cápsulas locales de 1 mm alrededor de las aristas cortas ORIGINALES, no alrededor de todo el perímetro ni de posiciones que se desplacen sucesivamente. Se exige un único propietario, el mismo número de huecos, separación entre anillos y ausencia de cruces. No se ejecuta después la limpieza R5, que podría invalidar esa prueba conservadora.

Los bordes oblicuos se calculan con una rejilla interna refinada hasta un factor de un millón, manteniendo los puntos movidos sobre sus soportes mediante pasos enteros de su vector primitivo. El factor se conserva hasta crear las curvas Revit; no se redondea otra vez a 0.001 mm. Esto evita que un ajuste de esquina provoque una cuña artificial a lo largo de un borde de metros. La precisión efectiva queda acotada por el rango seguro de coordenadas del motor.

Si una segunda esquina no admite corrección completa, se devuelve la región original intacta y área retirada cero: no se aplican correcciones parciales. Hay un límite de 128 pasos por región. Un encuentro que requiera más de 1 mm o que obligue a cerrar huecos/dividir el propietario se informa como no resuelto.

## Archivos e intervención

| Acción | Ruta relativa | Finalidad |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Compartido/Geometria/RecortePlanoExterior.cs` | Ajuste local conservador, precisión de soportes y validaciones. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoRecorteExterior.cs` | Integrar el ajuste opcional, conservar precisión y registrar área. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Activar la regla solo para suelos y marcar R6. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/Program.cs` | Regresiones del nuevo ajuste y conservación de las anteriores. |
| REEMPLAZAR | `Tests/TarrajeoRecorte2D/README.md` | Comandos, resultados y alcance. |
| REEMPLAZAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP agrega un parche alternativo y el manifiesto SHA-256: 8 archivos. No se requieren nuevos archivos de producción, inclusiones de proyecto, referencias o paquetes. No hay eliminaciones.

`MYG.csproj`, `Tarrajeo_MurosHandler.cs`, `Clipper.cs`, `TarrajeoAlturas.cs`, `TarrajeoValidacionSuelo.cs` y el proyecto de pruebas permanecen SIN CAMBIOS respecto a R5 y fuera del ZIP. No se incluyen archivos sin cambios, logs, modelo, coordenadas privadas, DLL, bin/obj, paquetes, credenciales ni .git/.vs.

## Instalación

1. Mantener R5 como base, respaldar los archivos y comparar si tu solución tiene cambios posteriores. Reemplazar un archivo completo puede sobrescribirlos.
2. Copiar LOS TRES archivos de producción, conservando rutas. Deben actualizarse juntos porque cambia el contrato interno de precisión. Ya están incluidos en el proyecto: no agregar Compile duplicados ni sustituir el .csproj.
3. Como alternativa a copiarlos, aplicar sobre R5 `git apply --check PARCHES/ACTUALIZAR_ENCUENTROS_DESDE_R5.patch` y después `git apply PARCHES/ACTUALIZAR_ENCUENTROS_DESDE_R5.patch`. No aplicar ese parche después de copiarlos ni sobre otra versión sin revisar. Copiar aparte pruebas/documentación.
4. Compilar en tu configuración real Windows/Revit, actualizar la DLL de prueba, cerrar todas las instancias de Revit y abrir otra vez. El aviso/log debe mostrar `TARRAJEO-PLANO-R6`.
5. Probar en una copia sin los acabados generados por pruebas anteriores: también son sólidos visibles y podrían descontarse. No se borran automáticamente elementos del modelo.
6. Revisar en el log los encuentros ajustados y el área retirada de sus bocetos. Ese registro describe la geometría 2D aceptada; el contador de suelos confirmados indica qué elementos realmente se crearon. No se añaden diálogos de éxito ni solicitudes de confirmación por esquina.

## Pruebas y límites

La suite ejecuta el código real de producción: R6 pasa 41 de 41 casos. La misma suite sobre R5 conserva 31 casos aprobados y falla los 10 nuevos porque aún no dispone de la operación de ajuste. Incluye conservación de material disponible y huecos, localidad de 1 mm, mínimos, direcciones, entrada no mutada, fallo sin parciales y control de soportes oblicuos. El comando y el detalle figuran en el README.

Una revisión independiente y un replay externo verificaron seis casos con escalón constante de 0.499673 mm, lados de 1 y 10 metros y rotaciones de 26.37°, 17.03° y 40°: los seis pasan, retirando aproximadamente 0.15656–0.15723 mm² por encuentro. Son geometrías sintéticas de tamaño real, no una prueba del modelo del usuario. La creación nativa en Revit sigue pendiente.

Se comprueba por separado la compilación semántica del motor y del flujo modificado contra las referencias reales de Revit, y la sintaxis de los 182 archivos activos. La compilación completa en Linux continúa bloqueada por MSB4803/ResolveComReference; no se genera una DLL aquí. No se migran las dependencias ni el framework de tu solución Windows.

La corrección puede rechazarse si la geometría es demasiado aguda/estrecha para una solución dentro de 1 mm, o si exigiría cambiar su topología. Se conserva el diagnóstico y el contorno original. No se garantiza ausencia de errores en el modelo ni funcionamiento de todos los casos inclinados: la comprobación de Floor.Create, el contacto exterior final y las transacciones sigue realizándose en Revit. Se mantiene la geometría de los muros existentes usados como obstáculos.

## Entrega y GitHub

Publicación únicamente del ZIP en una ruta nueva de `bimchimbote-droid/DESCARGAS`, conservando las entregas anteriores. Se recupera el artefacto mediante Git HTTPS desde un clon independiente para comparar SHA-256, integridad y manifiesto. No se generan ni se envían enlaces de descarga.

Publicar el ZIP no actualiza tu PC ni hace Commit/Push al repositorio del código. Después de aplicar y validar: revisar las diferencias en Git Changes de Visual Studio, seleccionar solo los archivos de esta corrección, hacer Commit y Push cuando decidas incorporarlos. No publicar el modelo ni el log geométrico.
