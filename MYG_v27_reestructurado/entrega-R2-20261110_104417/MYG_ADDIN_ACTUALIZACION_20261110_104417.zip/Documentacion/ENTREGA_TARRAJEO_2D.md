# Tarrajeo/encofrado: recuperación de paños — revisión TARRAJEO-2D-R2

## Versión de trabajo

Repositorio abierto: `bimchimbote-droid/MYG_v27_reestructurado`, rama `master`, base `cb9d73137e06f55741862274e4ee839bb87e5d80`. Se conserva la primera corrección de esta conversación y se amplía sobre ella, sin sustituir archivos por `MYG_v27/main`, citado en la plantilla. El checkout estaba limpio antes de la primera entrega; los cambios locales de esa entrega se conservaron. La base inmediata es la primera entrega publicada en DESCARGAS, commit `95f6e7f3bbfdc6eb63ad6016e366f7a76ad03f0d`. No se cambiaron referencias, paquetes, framework, botones ni ventanas.

## Diagnóstico y comportamiento

El log facilitado confirma que una resta 3D de la huella de un muro falla en el kernel de Revit. El respaldo planar llega a los perfiles restantes, pero los rechaza por contactos/cruces entre aristas; también hay un residuo de 0.009248 mm². Antes se perdían regiones grandes completas cuando una parte de su contorno era no creable. Los dos suelos creados no demostraban que toda la cara seleccionada estuviera cubierta.

La primera corrección separó proximidad y cruce exacto; no bastaba para recuperar contactos reales o bordes residuales. Esta revisión conserva esa corrección y añade:

- Recuperación SOLO de la pieza rechazada, intersectándola con franjas disjuntas en sus coordenadas U/V. Se elige una de las dos particiones por mayor área válida; nunca se suman las alternativas.
- Conservación del exterior y TODOS los huecos de su propietario en cada intersección. Se detectan contactos entre anillos, además de autointersecciones.
- Unión conservadora de fragmentos vecinos cuando el perfil resultante es creable, conserva el área y todos sus huecos; no se reconstituye un contorno inválido para reducir el número de piezas.
- Contabilidad del área recuperada y residual omitida. No se amplían cortes ni se restaura el perfil original sobre obstáculos. Solo se descartan las regiones que siguen sin admitir un perfil válido; pueden incluir franjas residuales y no exclusivamente partículas originales.
- Marcador `TARRAJEO-2D-R2` en los avisos de fallo/parcial y en el log. El log registra ubicación y MVID del ensamblado cargado, también cuando toda la creación termina correctamente, sin añadir un diálogo de éxito.

El resultado puede necesitar varios suelos nativos para representar una región con contacto puntual o contorno no creable. Las piezas que ya eran válidas siguen su flujo habitual. El límite de seguridad del respaldo es 4096 franjas por eje, y la unión de fragmentos también tiene un presupuesto acotado para no bloquear Revit con casos patológicos.

## Relación de archivos

| Acción | Ruta relativa | Finalidad |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs` | Motor planar compartido: topología exacta, recuperación y conservación de huecos. |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | Identificador de revisión y diagnóstico de la DLL realmente cargada. |
| CREAR o REEMPLAZAR si instalaste la primera entrega | `Tests/TarrajeoRecorte2D/Program.cs` | Extracción y compilación de métodos reales para probarlos. |
| CREAR o REEMPLAZAR si instalaste la primera entrega | `Tests/TarrajeoRecorte2D/HarnessCases.cs` | Regresiones de paños, huecos y residuos. |
| CREAR o REEMPLAZAR si instalaste la primera entrega | `Tests/TarrajeoRecorte2D/README.md` | Comandos, resultados y alcance. |
| CREAR o REEMPLAZAR si instalaste la primera entrega | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP incluye además `PARCHES/TARRAJEO_2D.patch`, alternativa puntual para los dos handlers sobre la primera entrega R1, y `MANIFIESTO_SHA256.txt`. Total: 8 archivos. El proyecto de pruebas `Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj` no cambió respecto a R1: queda fuera del ZIP y debes conservarlo. Si no instalaste las pruebas anteriores, ese archivo ya está en la primera entrega de DESCARGAS. No hay eliminaciones. El proyecto del add-in, packages.config, Clipper.cs, recursos y demás código quedan SIN CAMBIOS y fuera del ZIP. No se incluyen DLL, bin/obj, cachés, log del usuario, capturas ni datos de su modelo.

## Instalación

1. Respalda tu solución y compara con la base indicada. Reemplazar archivos completos puede sobrescribir cambios locales o posteriores. Esta entrega contiene los handlers completos con todas las modificaciones de R1; no es necesario aplicar ambos parches. El proyecto de pruebas sin cambios se conserva de R1.
2. Copia los dos handlers sobre las mismas rutas de la solución reestructurada. Ya están incluidos explícitamente en `MYG.csproj`. Si tu versión local difiere, integra las diferencias en vez de reemplazar a ciegas.
3. Alternativamente, sobre los handlers de la primera entrega R1 ejecuta `git apply --check PARCHES/TARRAJEO_2D.patch` y luego `git apply PARCHES/TARRAJEO_2D.patch`. No apliques el parche después de copiar los handlers ni directamente sobre la base original sin R1. Si no instalaste R1, utiliza los archivos completos de esta entrega. Copia aparte pruebas/documentación.
4. Las pruebas son un proyecto independiente: no agregues `Tests/` al proyecto del complemento ni las distribuyas como parte de MYG.dll.
5. Compila tu configuración Windows/Revit y actualiza tu instalación de prueba. Mantén el manifiesto .addin, iconos y dependencias de tu instalación existente.
6. Cierra completamente TODAS las instancias de Revit y vuelve a abrir antes de probar, especialmente si usas AddInManager. Cambiar un .cs o una DLL en disco no descarga el ensamblado que ya está en memoria.
7. Ejecuta sobre una copia del modelo. Si aparece un aviso parcial/fallo de esta revisión, comenzará por `TARRAJEO-2D-R2`. Revisa la última entrada del log `MYG_Tarrajeo_Losas_Diagnostico.log` en la carpeta temporal: también contendrá la revisión, ubicación y MVID. La ausencia del marcador exige comprobar qué DLL se está ejecutando; el log antiguo por sí solo no permite identificarla.

## Configuración y pruebas

No se añaden paquetes ni referencias al complemento. System.Numerics ya estaba referenciado. Las pruebas independientes requieren SDK .NET 10 y usan Roslyn del SDK más el Clipper.cs existente del repositorio, sin copiarlo a la entrega.

Ejecuta desde la raíz: `dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj`. La suite compila los cuerpos de métodos reales extraídos del código; solo sustituye el contenedor XYZ para las operaciones de coordenadas. Comprueba áreas, conservación de huecos, ausencia de solapamientos e invasión de cortes. Los resultados ejecutados y la regresión frente a la primera entrega figuran en su README.

La revisión sintáctica de producción y las rutas de proyecto/recursos se verifican por separado. La compilación completa fue intentada y continúa bloqueada por `MSB4803`: ResolveComReference requiere MSBuild de .NET Framework/Windows. Persiste la advertencia preexistente de EPPlus.Interfaces. Se conserva sin migrar el target .NET Framework 4.8 del proyecto, mientras la API de Revit incluida declara .NET 10; esa compatibilidad necesita revisión aparte. No se produjo una DLL nueva en Linux.

## Límites y comprobación pendiente

El log permite ubicar el fallo, pero no contiene las coordenadas del perfil ni un identificador de la DLL ejecutada. No se ha reproducido exactamente el modelo del usuario ni se han ejecutado Floor.Create, transacciones, selección, vínculos o herramientas dentro de Revit. Un perfil matemáticamente válido con un cuello microscópico todavía puede ser rechazado por el kernel después de esta recuperación; la revisión no promete crear geometría que Revit no admita. El residuo de 0.009248 mm² puede seguir omitiéndose legítimamente.

Pendiente: probar la DLL recompilada en una copia del modelo original y comprobar todos los paños superiores, huecos y volumen de las interferencias. Si persiste, conservar la nueva entrada del log con marcador R2 y preparar un modelo mínimo de esos paños para reproducir la geometría exacta.

## Entrega y GitHub

Solo se publica el ZIP en una ruta NUEVA de `bimchimbote-droid/DESCARGAS`, conservando entregas anteriores. Por petición del usuario no se generan ni envían enlaces de descarga. La verificación se realiza recuperando el artefacto publicado mediante Git HTTPS desde un clon independiente y comparando SHA-256, integridad y contenido.

Publicar el ZIP no actualiza tu PC ni hace commit/push a los repositorios del código. Para incorporarlo: revisa las diferencias de los dos handlers y los archivos de pruebas/documentación en Git Changes de Visual Studio, ejecuta las comprobaciones disponibles y realiza Commit y Push cuando decidas publicarlas. No incluyas el log ni el modelo en ese commit.
