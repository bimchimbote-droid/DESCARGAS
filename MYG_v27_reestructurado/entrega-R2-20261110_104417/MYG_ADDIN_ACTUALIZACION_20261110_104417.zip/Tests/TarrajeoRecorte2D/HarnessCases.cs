using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using MYG_Addin.RecorteClipper;

public static class GeometryCases
{
    private const double Scale = 10000000.0;
    private static int passed, failed;
    private static readonly TarrajeoHarness Motor = new TarrajeoHarness();
    private static readonly MarcoMuro Frame = new MarcoMuro {
        Origen=new XYZ(0,0,0), U=new XYZ(1,0,0), V=new XYZ(0,1,0), Normal=new XYZ(0,0,1)
    };

    public static int Run()
    {
        Case("near-touch valid concavity: one grid", () => ValidateNearTouch(1));
        Case("near-touch valid concavity: five grids", () => ValidateNearTouch(5));
        Case("near-touch valid concavity: ten grids", () => ValidateNearTouch(10));
        Case("integer topology is independent of UV origin", () => ValidateNearTouch(1,100000));
        Case("difference preserves material between near-touching cuts", () => {
            var r=Difference(Component(Rect(0,0,10,10)),
                Component(Loop(-1,2.6, 5,5, -1,7.4)),
                Component(Loop(0,10, 5.0000005,5, 10,10)));
            Check(r,1,0,65);
        });
        Case("real crossing remains rejected", () => {
            var loop=Loop(0,0, 5,5, 0,5, 5,0, 8,0, 8,8, 0,8);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out var reason),"Self-crossing loop was accepted: "+reason);
        });
        Case("exact contact remains rejected", () => {
            var loop=Loop(0,0, 10,0, 10,10, 5,5, 0,10, 0,7, 5,5, 0,3);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out _),"Repeated non-adjacent vertex was accepted.");
        });
        Case("legitimate short edge remains rejected", () => {
            var loop=Loop(0,0, .001,0, .001,10, 0,10);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out var reason) && reason.Contains("arista"),reason);
        });
        Case("application short curve threshold remains honored", () => {
            var loop=Loop(0,0, .01,0, .01,10, 0,10);
            Assert(!Motor.ValidarLoopResultado2D(loop,.02,out var reason) && reason.Contains("arista"),reason);
        });
        Case("tiny residue remains rejected", () => {
            var loop=Loop(0,0, 1,0, 1,1e-7, 0,1e-7);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out var reason) && reason.Contains("área"),reason);
        });
        Case("difference preserves a hole", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(2,2,4,4)));
            Check(r,1,0,96); Assert(r.Components[0].Huecos.Count==1,"Hole ownership was lost.");
        });
        Case("transverse cut keeps both pieces", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(4,-1,6,11)));
            Check(r,2,0,80);
        });
        Case("full cover is not an omitted profile", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(-1,-1,11,11)));
            Check(r,0,0,0);
        });
        Case("external obstacle does not alter subject", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(11,0,12,10)));
            Check(r,1,0,100);
        });
        Case("input hole survives unrelated cut", () => {
            var r=Difference(Component(Rect(0,0,10,10),Rect(2,2,4,4)),Component(Rect(8,-1,11,11)));
            Check(r,1,0,76); Assert(r.Components[0].Huecos.Count==1,"Original opening was filled.");
        });
        Case("nested island keeps hole ownership", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(2,2,8,8),Rect(4,4,6,6)));
            Check(r,2,0,68); Assert(r.Components.Sum(c=>c.Huecos.Count)==1,"Nested topology was lost.");
        });
        Case("tangent cut never fills the obstacle", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Loop(0,5, 2,3, 4,5, 2,7)));
            CheckArea(r,0,92);
        });
        Case("tangent exterior opening is recovered as non-touching profiles", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Loop(0,5, 2,3, 4,5, 2,7)));
            CheckArea(r,0,92); AssertProfilesHaveSeparatedRings(r.Components);
            AssertDisjoint(r.Components);
        });
        Case("two tangent openings preserve both voids", () => {
            var r=Difference(Component(Rect(0,0,20,20)),
                Component(Rect(4,4,8,8)),Component(Rect(8,8,12,12)));
            CheckArea(r,0,368); AssertProfilesHaveSeparatedRings(r.Components);
            AssertDisjoint(r.Components);
        });
        Case("short residual edge does not erase a large panel", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(5,-1,11,9.9999)));
            var area=MaterialArea(r.Components);
            Assert(area>=50-1e-7 && area<=50.0005+1e-7,
                "Large valid rectangle lost; retained area="+area+". "+r.Diagnostic);
            Assert(r.Omitted>0,"Uncreable residue must remain explicitly accounted for.");
            AssertDisjoint(r.Components);
            AssertNoOverlapWithCut(r.Components,Rect(5,-1,11,9.9999));
        });
        Case("point-pinched polygon recovers both large panels", () => {
            var node=Node(Loop(0,0, 4,0, 4,4, 8,4, 8,8, 4,8, 4,4, 0,4));
            var r=Recover(node);
            Check(r,2,0,32); AssertDisjoint(r.Components);
        });
        Case("recovery preserves a separate opening beside a pinch", () => {
            var node=Node(Loop(0,0, 8,0, 8,8, 16,8, 16,16, 8,16, 8,8, 0,8));
            var hole=Node(Rect(2,2,4,4));
            if(Clipper.Orientation(hole.Contour)) hole.Contour.Reverse();
            node.AddChild(hole);
            var r=Recover(node);
            CheckArea(r,0,124); AssertProfilesHaveSeparatedRings(r.Components);
            AssertDisjoint(r.Components); AssertNoOverlapWithCut(r.Components,Rect(2,2,4,4));
        });
        Case("adjacent narrow artificial strip merges into a valid profile", () => {
            var parts=new List<PolyNode> { Node(Rect(0,0,5,10)),Node(Rect(5,0,5.001,10)) };
            MergeParts(parts);
            Assert(parts.Count==1,"Artificial narrow strip was left as a separate uncreable profile.");
            var exterior=Motor.LoopDesdeCaminoClipper(parts[0].Contour,Frame,0,0,Scale);
            Assert(Motor.ValidarLoopResultado2D(exterior,0,out var reason),reason);
            Assert(Math.Abs(exterior.AreaAbs-50.01)<1e-7,"Merge changed the material area.");
        });
        Case("point-adjacent squares remain separate during strip merging", () => {
            var parts=new List<PolyNode> { Node(Rect(0,0,4,4)),Node(Rect(4,4,8,8)) };
            MergeParts(parts);
            Assert(parts.Count==2,"Point-only adjacency was merged into a pinched profile.");
        });
        Case("artificial fine slabs do not lose material beside an opening", () => {
            var node=Node(Loop(0,0, 4,0, 4,4, 8,4, 8,8, 4,8, 4,4, 0,4));
            var hole=Node(Rect(1,1,3.999,3.999));
            if(Clipper.Orientation(hole.Contour)) hole.Contour.Reverse();
            node.AddChild(hole);
            var r=Recover(node);
            CheckArea(r,0,32-(2.999*2.999));
            AssertDisjoint(r.Components);AssertNoOverlapWithCut(r.Components,Rect(1,1,3.999,3.999));
        });
        Console.WriteLine("Passed: "+passed+"; failed: "+failed+"; total: "+(passed+failed));
        return failed==0 ? 0 : 1;
    }

    private static void ValidateNearTouch(long gap, double origin=0)
    {
        var loop=Loop(origin,origin, origin+10,origin, origin+10,origin+10,
            origin+5+gap/Scale,origin+5, origin,origin+10, origin,origin+7,
            origin+5,origin+5, origin,origin+3);
        Assert(Motor.ValidarLoopResultado2D(loop,0,out var reason),reason);
    }

    private sealed class Result {
        public List<ComponenteMuro> Components; public int Omitted; public string Diagnostic;
    }
    private static Result Difference(ComponenteMuro subject, params ComponenteMuro[] cuts)
    {
        Assert(Motor.CalcularRestaPoligonosEnPlano(subject,cuts.ToList(),out var loops,
            out var components,out var omitted,out var diagnostic),diagnostic);
        Assert(loops.Count==components.Sum(c=>1+c.Huecos.Count),"Loop/component ownership mismatch.");
        return new Result { Components=components,Omitted=omitted,Diagnostic=diagnostic };
    }
    private static void Check(Result r,int components,int omitted,double area)
    {
        Assert(r.Components.Count==components,"Components: "+r.Components.Count+". "+r.Diagnostic);
        Assert(r.Omitted==omitted,"Omitted: "+r.Omitted+". "+r.Diagnostic);
        var actual=r.Components.Sum(c=>c.Exterior.AreaAbs-c.Huecos.Sum(h=>h.AreaAbs));
        Assert(Math.Abs(actual-area)<1e-7,"Expected area "+area+", got "+actual);
    }
    private static double MaterialArea(List<ComponenteMuro> components)
        => components.Sum(c=>c.Exterior.AreaAbs-c.Huecos.Sum(h=>h.AreaAbs));
    private static void CheckArea(Result r,int omitted,double area)
    {
        Assert(r.Omitted==omitted,"Omitted: "+r.Omitted+". "+r.Diagnostic);
        Assert(r.Components.Count>0,"All material was discarded. "+r.Diagnostic);
        Assert(Math.Abs(MaterialArea(r.Components)-area)<1e-7,
            "Expected retained area "+area+", got "+MaterialArea(r.Components));
    }
    private static PolyNode Node(LoopMuro loop)
    {
        var node=new PolyNode();
        new PolyTree().AddChild(node);
        node.Contour.AddRange(loop.Puntos2D.Take(loop.Puntos2D.Count-1)
            .Select(p=>new IntPoint((long)Math.Round(p.U*Scale),(long)Math.Round(p.V*Scale))));
        if(!Clipper.Orientation(node.Contour)) node.Contour.Reverse();
        return node;
    }
    private static Result Recover(PolyNode node)
    {
        var method=typeof(TarrajeoHarness).GetMethod("RecuperarPiezaPorFranjas2D");
        Assert(method!=null,"The source does not implement recovery of an invalid polygon.");
        object[] arguments={node,Frame,0.0,0.0,Scale,0.0,null,null,null};
        Assert((bool)method.Invoke(Motor,arguments),"Recovery failed: "+arguments[8]);
        return new Result { Components=(List<ComponenteMuro>)arguments[6],
            Omitted=(int)arguments[7],Diagnostic=(string)arguments[8] };
    }
    private static void MergeParts(List<PolyNode> parts)
    {
        var method=typeof(TarrajeoHarness).GetMethod("RecuperarUnionesDeFranjas2D");
        Assert(method!=null,"The source does not merge artificial strips before discarding them.");
        method.Invoke(Motor,new object[] {parts,Frame,0.0,0.0,Scale,0.0,1e-8});
    }
    private static List<List<IntPoint>> Paths(ComponenteMuro component)
    {
        var result=new List<List<IntPoint>> { Node(component.Exterior).Contour };
        foreach(var hole in component.Huecos) {
            var path=Node(hole).Contour; path.Reverse(); result.Add(path);
        }
        return result;
    }
    private static double IntersectionArea(List<List<IntPoint>> a,List<List<IntPoint>> b)
    {
        var clipper=new Clipper();var result=new PolyTree();
        clipper.AddPaths(a,PolyType.ptSubject,true);clipper.AddPaths(b,PolyType.ptClip,true);
        Assert(clipper.Execute(ClipType.ctIntersection,result,PolyFillType.pftNonZero,
            PolyFillType.pftNonZero),"Intersection could not execute.");
        double area=0;
        for(var node=result.GetFirst();node!=null;node=node.GetNext())
            area+=Clipper.Area(node.Contour)/(Scale*Scale);
        return area;
    }
    private static void AssertDisjoint(List<ComponenteMuro> components)
    {
        for(var i=0;i<components.Count;i++)
            for(var j=i+1;j<components.Count;j++)
                Assert(Math.Abs(IntersectionArea(Paths(components[i]),Paths(components[j])))<1e-8,
                    "Recovered profiles overlap in area.");
    }
    private static void AssertNoOverlapWithCut(List<ComponenteMuro> components,LoopMuro cut)
    {
        foreach(var component in components)
            Assert(Math.Abs(IntersectionArea(Paths(component),Paths(Component(cut))))<1e-8,
                "Recovery filled an obstacle/opening.");
    }
    private static void AssertProfilesHaveSeparatedRings(List<ComponenteMuro> components)
    {
        foreach(var component in components) {
            var paths=Paths(component);
            for(var i=0;i<paths.Count;i++)for(var j=i+1;j<paths.Count;j++)
                Assert(!paths[i].Any(p=>Clipper.PointInPolygon(p,paths[j])==-1) &&
                    !paths[j].Any(p=>Clipper.PointInPolygon(p,paths[i])==-1),
                    "Returned profile still contains tangent rings.");
        }
    }
    private static ComponenteMuro Component(LoopMuro exterior,params LoopMuro[] holes)
        => new ComponenteMuro { Exterior=exterior,Huecos=holes.ToList() };
    private static LoopMuro Rect(double x0,double y0,double x1,double y1)
        => Loop(x0,y0,x1,y0,x1,y1,x0,y1);
    private static LoopMuro Loop(params double[] coordinates)
    {
        var path=new List<IntPoint>();
        var originU=coordinates[0]; var originV=coordinates[1];
        for(var i=0;i<coordinates.Length;i+=2)
            path.Add(new IntPoint((long)Math.Round((coordinates[i]-originU)*Scale),
                (long)Math.Round((coordinates[i+1]-originV)*Scale)));
        return Motor.LoopDesdeCaminoClipper(path,Frame,originU,originV,Scale);
    }
    private static void Case(string name,Action test)
    {
        try { test(); passed++; Console.WriteLine("PASS "+name); }
        catch(Exception e) { failed++; Console.WriteLine("FAIL "+name+": "+e.Message); }
    }
    private static void Assert(bool condition,string message)
    {
        if(!condition) throw new InvalidOperationException(message);
    }
}
