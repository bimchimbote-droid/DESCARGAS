# Regresión del recorte planar de tarrajeo

Ejecutar desde el checkout con SDK .NET 10:

```bash
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj
```

No requiere paquetes NuGet adicionales, Revit ni Windows. El proyecto usa Roslyn incluido en el SDK, extrae los métodos reales del handler y las cuatro clases de datos del código fuente actual, e incluye `Clipper.cs` directamente al compilar en memoria. Solo se sustituye `XYZ` por un contenedor mínimo de coordenadas: no se simulan transacciones ni el kernel geométrico de Revit.

Para comparar una entrega anterior, extrae su handler en una carpeta separada, sin sobrescribir el código actual, y pasa la ruta del archivo a `--source`. Por ejemplo, si esa entrega está extraída en `../entrega-anterior/`:

```bash
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj -- --source ../entrega-anterior/MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs
```

También se puede comparar con el commit base del checkout. Este ejemplo para Linux crea primero el archivo temporal:

```bash
git show HEAD:MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs > /tmp/Tarrajeo_MurosHandler-anterior.cs
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj -- --source /tmp/Tarrajeo_MurosHandler-anterior.cs
```

El proceso termina con código 1 si falla cualquier caso, 2 si no compila el código extraído y 0 cuando todos pasan. Los casos sintéticos demuestran el rechazo indebido de concavidades con bordes próximos, y comprueban cruces reales, contactos exactos, aristas cortas, residuos diminutos, diferencias, huecos e islas. No reproducen el modelo particular de la captura ni acreditan creación de suelos en Revit.

El caso de integración resta dos triángulos grandes a un perfil de 10×10 pies. Sus puntas quedan separadas 0.0000005 pies: la diferencia debe conservar una pieza de área 65 pies² sin omitirla. El perfil y ambos cortantes son entradas válidas; así se comprueba el recorrido completo de diferencia y validación, además de los casos directos del validador.

En la primera entrega se ejecutaron 17 casos con SDK 10.0.403: contra el commit base `cb9d73137e06f55741862274e4ee839bb87e5d80`, 12 pasaban y 5 fallaban (salida 1); con la corrección de cruces enteros, 17 de 17 pasaban. Antes, el caso de integración omitía la pieza completa por un supuesto cruce; después conserva una pieza y cero omisiones, con área 65 pies².

La segunda revisión añade cinco regresiones que la primera entrega no resolvía:

- Hueco tangente al contorno exterior: conservar los 92 pies² de material en perfiles sin anillos que se tocan.
- Dos huecos tangentes: conservar ambos vacíos y los 368 pies² de material.
- Recorte en L con una arista residual de 0.03048 mm: recuperar al menos el rectángulo válido de 50 pies², omitir explícitamente el residuo no creable y no invadir la interferencia.
- Contorno con dos paños unidos solo por un punto: recuperar ambos cuadrados, área total 32 pies².
- Contorno con contacto puntual y un hueco independiente: conservar los 124 pies² sin rellenar el hueco.

Las regresiones comprueban mediante intersecciones de Clipper que las piezas recuperadas no se solapan ni rellenan los cortes. Las comprobaciones directas de cruce/contacto y aristas pequeñas siguen rechazando esos bocetos: el respaldo debe dividir el material en perfiles creables, no permitir un boceto inválido.

Se añaden además tres casos para evitar pérdidas causadas por la propia partición: unir una franja artificial estrecha a su vecino cuando el resultado completo es creable, mantener separados los cuadrados que solo comparten un punto y recuperar el área completa alrededor de un hueco cercano a varios niveles de corte. Este último requiere unir un grupo de franjas adyacentes; permitir únicamente uniones de pares todavía descartaba 650.228377 mm² de material válido.

Resultados ejecutados con SDK 10.0.403:

| Fuente comprobada | Casos ejecutados | Pasan | Fallan | Salida |
| --- | --- | --- | --- | --- |
| Commit original `cb9d73137e06f55741862274e4ee839bb87e5d80`, primera suite | 17 | 12 | 5 | 1 |
| Primera entrega R1, suite con contactos reales y aristas residuales | 22 | 17 | 5 | 1 |
| R2 intermedia con franjas, antes de las uniones conservadoras | 25 | 22 | 3 | 1 |
| Corrección final con franjas y unión de grupos por segmento compartido | 25 | **25** | **0** | **0** |

Los resultados intermedios corresponden a copias conservadas durante esta tarea; no implican entregas públicas adicionales. Para repetir una comparación con una entrega publicada, usa `--source` sobre su handler extraído, como se indica arriba. Son pruebas de recorte 2D; falta validar la creación final en el modelo original dentro de Revit.
