using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

// Compile the production method bodies, not a second implementation of them.
// Only the unused Revit host and its XYZ data container are substituted.
var repo = FindRepo();
var source = Path.Combine(repo, "MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs");
for (var i = 0; i < args.Length; i++)
{
    if (args[i] == "--source" && i + 1 < args.Length) source = Path.GetFullPath(args[++i]);
    else throw new ArgumentException("Usage: [--source /path/to/handler.cs]");
}
var syntax = CSharpSyntaxTree.ParseText(File.ReadAllText(source));
var handler = syntax.GetRoot().DescendantNodes().OfType<ClassDeclarationSyntax>()
    .Single(c => c.Identifier.ValueText == "Tarrajeo_MurosHandler");
string[] required = {
    "CalcularRestaPoligonosEnPlano", "AgregarCaminosClipper", "CaminoClipperParaLoop",
    "LoopDesdeCaminoClipper", "QuitarVerticesRedundantes2D", "PerimetroCaminoClipper",
    "ValidarLoopResultado2D", "SegmentosResultado2DSeCruzan", "PuntoEnSegmentoResultado2D",
    "LoopSeguro", "TieneSegmentosCortos", "LoopTieneCruces", "LoopsSeTocanOCruzan",
    "SegmentosIntersectan2D", "PuntoEnSegmento2D", "EsToqueDeExtremo", "Dist2D",
    "Orient2D", "Area", "AreaAbs", "PuntoEnPoligono"
};
var methods = handler.Members.OfType<MethodDeclarationSyntax>().ToArray();
foreach (var name in required)
    if (methods.Count(m => m.Identifier.ValueText == name) != 1)
        throw new InvalidOperationException("Missing or ambiguous production method: " + name);
var selected = methods.Where(m => required.Contains(m.Identifier.ValueText) ||
    m.Identifier.ValueText == "OrientacionResultado2D" ||
    m.Identifier.ValueText == "CrearComponenteResultado2D" ||
    m.Identifier.ValueText == "LoopsResultado2DSeTocan" ||
    m.Identifier.ValueText.StartsWith("Recuperar", StringComparison.Ordinal) ||
    m.Identifier.ValueText == "AreaNodoResultado2D");
var extracted = selected.Select(m => m.WithModifiers(SyntaxFactory.TokenList(
    new[] { SyntaxFactory.Token(SyntaxKind.PublicKeyword).WithTrailingTrivia(SyntaxFactory.Space) }
        .Concat(m.Modifiers.Where(t => !t.IsKind(SyntaxKind.PrivateKeyword) &&
            !t.IsKind(SyntaxKind.ProtectedKeyword) && !t.IsKind(SyntaxKind.PublicKeyword))))).ToFullString());
var constants = handler.Members.OfType<FieldDeclarationSyntax>()
    .Where(f => f.Declaration.Variables.Any(v => v.Identifier.ValueText is "TOL" or "PTOL"))
    .Select(f => f.ToFullString());
string[] dataNames = { "MarcoMuro", "LoopMuro", "ComponenteMuro", "UV2" };
var data = syntax.GetRoot().DescendantNodes().OfType<ClassDeclarationSyntax>()
    .Where(c => dataNames.Contains(c.Identifier.ValueText)).ToArray();
if (data.Length != dataNames.Length) throw new InvalidOperationException("Missing production data classes.");
var production = "using System; using System.Collections.Generic; using System.Linq; using System.Numerics; " +
    "using Autodesk.Revit.DB; public class TarrajeoHarness {\n" +
    string.Join("\n", constants.Concat(extracted)) + "\n}\n" + string.Join("\n", data.Select(d => d.ToFullString()));
var stub = """
namespace Autodesk.Revit.DB {
  public sealed class XYZ {
    public double X, Y, Z;
    public XYZ(double x, double y, double z) { X=x; Y=y; Z=z; }
    public XYZ Multiply(double n) { return new XYZ(X*n,Y*n,Z*n); }
    public static XYZ operator +(XYZ a, XYZ b) { return new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z); }
  }
}
""";
var trees = new[] {
    CSharpSyntaxTree.ParseText(production, path: source + " (extracted methods)"),
    CSharpSyntaxTree.ParseText(stub, path: "XYZStub.cs"),
    CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(repo,"MYG/Compartido/Geometria/Clipper.cs")), path: "Clipper.cs"),
    CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"HarnessCases.cs")), path: "HarnessCases.cs")
};
var references = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator)
    .Select(path => MetadataReference.CreateFromFile(path));
var compilation = CSharpCompilation.Create("TarrajeoGeometry_" + Guid.NewGuid().ToString("N"), trees,
    references, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var output = new MemoryStream();
var result = compilation.Emit(output);
if (!result.Success)
{
    foreach (var error in result.Diagnostics.Where(d => d.Severity == DiagnosticSeverity.Error))
        Console.Error.WriteLine(error);
    return 2;
}
Console.WriteLine("Production source: " + source);
Console.WriteLine("Geometry tests only; no Revit API, transactions or model execution.");
var assembly = Assembly.Load(output.ToArray());
return (int)assembly.GetType("GeometryCases")!.GetMethod("Run")!.Invoke(null, null)!;

static string FindRepo()
{
    for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir is not null; dir = dir.Parent)
        if (File.Exists(Path.Combine(dir.FullName,"MYG/MYG.csproj"))) return dir.FullName;
    throw new DirectoryNotFoundException("Run this project from the MYG repository checkout.");
}
