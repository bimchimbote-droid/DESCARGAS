﻿// =====================================
// HANDLER - TARRAJEO MUROS V75 - VISTA ACTIVA REAL + CUSTOM EXPORTER + SONDA EXTERIOR
// Objetivo:
// - Mantener la misma lógica general, pero con flujo más corto y ordenado.
// - Cara plana vertical: rectangular normal o boceto si hay huecos/mordidas.
// - Cara cilíndrica vertical: muro curvo.
// - Por elementos: acepta Face genérica y puede crear varios muros si el perfil queda separado.
// - Recortes: considera SIEMPRE sólidos nativos + vínculos visibles en vista activa.
// - Evita entrar a SketchEditScope si el perfil no es seguro.
// - V30: configura ubicación como "Cara de acabado: Interior".
// - V31: corrige la geometría física: la curva/plano de creación se coloca
//        a medio espesor fuera de la cara seleccionada para que el tarrajeo
//        no invada el muro anfitrión. Luego se conserva WALL_KEY_REF_PARAM
//        como "Cara de acabado: Interior" para que la referencia quede en la cara.
// - V32: prueba de inversión de orientación.
// - V33: prueba con Cara de acabado: Exterior.
// - V34: corrección de disposición de capas sin mover el muro.
// - V35: mantiene la misma disposición física/capas de V34, pero deja
//        la línea de ubicación final como Cara de acabado: Exterior.
//        La orientación se hace ANTES de configurar WALL_KEY_REF_PARAM,
//        para que no se invierta ni se desplace el muro.
// - V36: limpia puntos duplicados/colineales y valida cruces 2D antes de
//        entrar al SketchEditScope. Esto evita errores de perfil inválido,
//        líneas demasiado cortas y líneas solapadas.
// - V37: antes de abrir el modo boceto valida también con una extrusión
//        temporal. Si un recorte queda pegado al borde y el perfil no es
//        aceptable para Revit, crea el paño sin ese hueco en vez de fallar.
// - V40: corrige el recorte que se iba al eje del elemento que intersecta.
//        Después del boolean, ya no se toma la cara paralela más cercana
//        al origen/eje. Se toma la cara del sólido del tarrajeo ubicada
//        en +/- medio espesor, que representa la superficie física real
//        del tarrajeo. Así el boceto se arma con la forma del sólido físico
//        y no con líneas casi superpuestas.
// - V42: optimización de rendimiento:
//        1) evita el boolean Intersect + Difference; usa solo Difference.
//        2) filtra sólidos por BoundingBox antes del boolean.
//        3) cachea geometría de sólidos por elemento durante la ejecución.
//        4) revisa dependientes solo en categorías compuestas como escaleras/rampas.
//        5) guarda GEN_ID en la misma transacción de creación/finalización.
// - V43: evita que el muro base del boceto se una automáticamente con muros/
//        elementos nativos que intersectan. Antes de CreateProfileSketch se
//        desune la geometría cercana visible en la vista activa. Esto evita
//        que las líneas del boceto se asocien a una cara unida y se vayan al
//        eje/centro del muro que intersecta.
// - V56: para recortes generados por Wall nativo/vinculado ya no usa la
//        geometría joined del muro. Crea un sólido cortante físico desde
//        LocationCurve + WallType.Width, evitando que el boolean produzca
//        líneas al eje del muro transversal. Además, si hay Wall nativo
//        cortante, fuerza sin unión solo para ese caso.
// - V57: respeta nuevamente el input Permitir Unión. Durante la creación
//        del boceto se bloquea/desune temporalmente para evitar que Revit
//        mueva líneas al eje del muro transversal, pero al final se aplica
//        el estado elegido por el usuario. Solo se evita JoinGeometry con
//        los muros cortantes, sin cambiar el allow/disallow de extremos.
// - V58: agrega creación desde loop planar sintético. Sirve para tapas
//        laterales de muros cuando Revit no devuelve una Face física en
//        el sólido por uniones/limpiezas. Usa el mismo motor de recortes
//        por sólidos visibles en la vista activa.
// - V59: distingue entre "sin recorte", "recorte parcial" y "eliminación total".
//        Si un sólido atraviesa todo el perfil, no conserva el muro original.
//        Si el resultado queda en dos o más islas, crea un muro por isla.
// - V60: toma como cortantes todos los elementos de modelo visibles en la
//        vista activa, nativos y de vínculos visibles. Respeta elementos y
//        categorías ocultas, y cuando el vínculo usa una vista vinculada,
//        usa esa vista para filtrar sus elementos. Excluye el elemento origen
//        y los tarrajeos creados durante el mismo lote.
// - V61: simplifica el criterio de recorte: cualquier sólido de modelo visible
//        puede cortar, sin filtrar por categoría. El sólido cortante se proyecta
//        al plano del tarrajeo cuando termina justo en la cara seleccionada.
// - V62: elimina la dependencia del boolean contra el sólido original. Cada
//        sólido cercano se convierte primero en una silueta 2D proyectada al
//        plano del tarrajeo y luego en un prisma cortante limpio. Esto evita que
//        el muro vuelva a aparecer dentro de vigas, zapatas, suelos o familias.
//        Los fallos de un cortante ya no eliminan toda la cara. Además, las caras
//        irregulares sin huecos se crean directamente desde su perfil, sin abrir
//        SketchEditScope, y la clasificación de loops usa un punto interior real.
// - V67: parte de la versión simple que siempre crea desde la cara. Para cada
//        componente genera una sonda exactamente con la forma de la cara.
// - V68: la sonda evalúa 2.00 mm a cada lado del plano físico de la cara. La
//        detección utiliza exclusivamente geometría Solid real, sin parámetros,
//        nombres de familia ni filtros por categoría. También fuerza los muros
//        creados por perfil a No conectado y a la altura exacta de la cara.
// - V72: las caras verticales de escaleras pueden llegar como snapshots XYZ.
//        El método de loop sintético ahora usa la misma sonda y los mismos
//        descuentos por sólidos visibles que una Face normal.
// - V73: recorta únicamente con elementos realmente visibles en la vista activa:
//        respeta Hide in View, categorías, filtros y Hide/Isolate temporal.
//        Los dependientes ocultos tampoco recortan y la geometría de vista se
//        consulta antes que la geometría física completa.
// - V70: corrige selección por cara en vínculos. La exclusión del elemento
//        origen ya no compara wrappers Document con ReferenceEquals; usa la
//        instancia de vínculo + ElementId, evitando que la cara se autorrecorte.
// - V74: la sonda de recorte ya NO revisa 2 mm detrás de la cara.
//        Revisa exclusivamente el espacio exterior/disponible de la cara activa.
//        Así un muro, panel o elemento pegado DETRÁS de una viga/columna no
//        elimina su tarrajeo; solo corta un sólido que realmente ocupa el lado
//        exterior de esa cara. Esto recupera las caras de vigas de confinamiento.
// - V75: la visibilidad de cortantes en vistas 3D se valida además con
//        CustomExporter/IExportContext. Este recorrido lo hace Revit con las
//        MISMAS reglas gráficas de la vista activa y por eso descarta también
//        elementos ocultos dentro de vínculos, filtros, Hide/Isolate temporal,
//        disciplina, fase y demás overrides que un collector normal no representa
//        con fidelidad. Si un elemento NO es exportado por la vista activa,
//        NO puede descontar el tarrajeo.
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using MYG_Addin;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public class Tarrajeo_MurosHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoForm Form;
    public WallType TipoMuro;
    public bool ConsiderarVinculos;
    public Reference FaceRef;
    public ExternalEvent SeleccionarEvent;

    // V69 - Datos ya resueltos por SeleccionarCarasHandler.
    // Evitan volver a interpretar una referencia vinculada y aplicar
    // transformaciones adicionales sobre la misma cara.
    public Face CaraProcesada;
    public Element HostProcesado;
    public Element ElementoGeometricoOrigen;
    public RevitLinkInstance VinculoOrigen;
    public Transform TransformProcesado;

    private const double TOL = 1e-6;
    // V36: tolerancia de punto/segmento alineada a la tolerancia real de bocetos de Revit.
    // Evita líneas extremadamente cortas generadas por boolean/tessellate.
    private const double PTOL = 0.003;
    private const double VTOL = 0.02;

    // V68 - Todas las distancias están en pies, unidad interna de Revit.
    // La sonda empieza 2.00 mm detrás del plano físico de la cara y termina
    // 2.00 mm delante de él. Así detecta sólidos situados en cualquiera de los
    // dos sentidos de la normal sin ampliar la búsqueda fuera de esa lámina.
    private const double SONDA_LADO_2MM = 0.00656167979;          // 2.00 mm
    private const double SONDA_TOTAL_4MM = 0.01312335958;         // 4.00 mm
    private const double SONDA_MARGEN_BBOX_01MM = 0.00032808399; // 0.10 mm
    private const double SONDA_TOL_PLANO_03MM = 0.00098425197;   // 0.30 mm
    private const double SONDA_EXPANSION_02MM = 0.00065616798;   // 0.20 mm
    // También debe cubrir los reintentos desplazados del boolean: el cortante
    // siempre atraviesa AMBAS caras del perfil, incluso después de moverlo.
    private const double SOBREPASO_PERFIL = 2.0 * BOOLEAN_RETRY_OFFSET + 0.00032808399;

    private const double SEARCH_MARGIN = 0.35;
    private const double SKETCH_CLEARANCE = 0.004; // aprox. 1.2 mm: margen mínimo para perfiles válidos
    private const double BOOLEAN_RETRY_OFFSET = 0.0005; // aprox. 0.15 mm: reintento ante caras coplanares

    // V62: sólido temporal del perfil. Se usa un espesor algo mayor para
    // evitar fallos numéricos cuando el cortante coincide con un borde.
    private const double BOOLEAN_PROFILE_HALF_DEPTH = 0.02; // 6.10 mm por lado

    // Crecimiento mínimo de la silueta proyectada. Evita dejar una lámina
    // residual cuando el sólido termina exactamente en el borde de la cara.
    private const double PROJECTED_CUT_MARGIN = 0.004; // 1.22 mm

    // Distancia máxima desde el plano del tarrajeo para proyectar un sólido
    // que termina exactamente en la cara seleccionada.
    private const double SOLID_PROJECTION_GAP = 0.15; // 45.7 mm

    // Pequeño sobrepaso para asegurar que el cortante atraviese ambas caras
    // de la lámina temporal usada por el boolean.
    private const double SOLID_PROJECTION_OVERTRAVEL = 0.002; // 0.61 mm

    // V56:
    // Margen pequeño para el sólido cortante físico de muros.
    // No se usa para desplazar el muro de tarrajeo; solo evita contactos
    // coplanares exactos en el boolean.
    private const double WALL_CUTTER_MARGIN = 0.005; // aprox. 1.5 mm

    // WALL_KEY_REF_PARAM:
    // 0 Wall Centerline, 1 Core Centerline, 2 Finish Face Exterior,
    // 3 Finish Face Interior, 4 Core Face Exterior, 5 Core Face Interior.
    // Se usa 2 para que la ubicación final quede como "Cara de acabado: Exterior".
    // La orientación de capas se corrige ANTES de asignar este parámetro.
    private const int LOC_FINISH_FACE_EXTERIOR = 2;

    // V42:
    // Cache local para no leer geometría del mismo elemento una y otra vez
    // cuando se crea por elementos y se procesan varias caras.
    private readonly Dictionary<string, List<Solid>> _solidCache = new Dictionary<string, List<Solid>>();

    // Identifica el origen del objeto Solid que realmente recibe el recorte.
    // No guarda rutas ni nombres de modelos. ExtraerSolidos también incluye
    // dependientes, por eso la etiqueta describe el origen de extracción.
    private readonly Dictionary<Solid, string> _origenesSolidosCortantes =
        new Dictionary<Solid, string>();

    // Evita que los muros de tarrajeo creados durante el mismo lote se usen
    // como cortantes de las caras siguientes.
    private readonly HashSet<ElementId> _idsCreadosDuranteLote = new HashSet<ElementId>();

    // Elemento del cual proviene la cara actualmente procesada. En elementos
    // vinculados se guarda además la instancia de vínculo para excluir solo
    // esa ocurrencia y no otra copia del mismo modelo.
    private Element _elementoOrigenRecorte;
    private RevitLinkInstance _vinculoOrigenRecorte;

    // V71: conjunto completo de elementos pertenecientes al anfitrión que se
    // está tarrajeando. En escaleras incluye la escalera raíz, tramos,
    // descansos, soportes y dependientes. Ninguno de ellos puede actuar como
    // cortante de otra cara del mismo conjunto.
    private readonly HashSet<ElementId> _idsOrigenRecorte = new HashSet<ElementId>();

    // V75 - Caché de visibilidad REAL de la vista activa 3D.
    // CustomExporter recorre únicamente lo que Revit considera dibujable/visible
    // en esa vista, incluyendo el contenido de vínculos con sus overrides.
    private readonly HashSet<string> _idsVisiblesHostExportador = new HashSet<string>();
    private readonly HashSet<string> _idsVisiblesVinculoExportador = new HashSet<string>();
    private readonly HashSet<string> _contextosVinculoExportador = new HashSet<string>();
    private bool _cacheVisibilidadExportadorValida = false;
    private ElementId _vistaCacheVisibilidadId = ElementId.InvalidElementId;

    // V73: en escaleras la sonda debe evaluar principalmente hacia afuera de
    // la cara. La sonda bidireccional podía interpretar el sólido situado
    // detrás de un contrapaso/lateral como una interferencia y eliminar toda
    // la cara. Se conserva una penetración de solo 0.10 mm hacia atrás para
    // resolver contactos coplanares.
    private bool _usarSondaUnilateralOrigen;
    private bool _avisoRecorteMostrado;

    // =========================================================
    // V75 - CONTEXTO LIGERO PARA VISIBILIDAD REAL DE LA VISTA 3D
    // =========================================================
    private class ContextoVinculoVisible
    {
        public Document Documento;
        public Transform Transformacion;
    }

    private class VisibilidadVistaExportContext : IExportContext
    {
        private readonly Document _docHost;
        private readonly Action<ElementId> _registrarHost;
        private readonly Action<Document, Transform, ElementId> _registrarVinculo;
        private readonly Action<Document, Transform> _registrarContextoVinculo;
        private readonly Stack<ContextoVinculoVisible> _pilaVinculos =
            new Stack<ContextoVinculoVisible>();

        public VisibilidadVistaExportContext(
            Document docHost,
            Action<ElementId> registrarHost,
            Action<Document, Transform, ElementId> registrarVinculo,
            Action<Document, Transform> registrarContextoVinculo)
        {
            _docHost = docHost;
            _registrarHost = registrarHost;
            _registrarVinculo = registrarVinculo;
            _registrarContextoVinculo = registrarContextoVinculo;
        }

        public bool Start() { return true; }
        public void Finish() { }
        public bool IsCanceled() { return false; }

        public RenderNodeAction OnViewBegin(ViewNode node)
        {
            return RenderNodeAction.Proceed;
        }

        public void OnViewEnd(ElementId elementId) { }

        public RenderNodeAction OnElementBegin(ElementId elementId)
        {
            try
            {
                if (elementId == null || elementId == ElementId.InvalidElementId)
                    return RenderNodeAction.Skip;

                if (_pilaVinculos.Count > 0)
                {
                    ContextoVinculoVisible c = _pilaVinculos.Peek();

                    if (c != null && c.Documento != null)
                    {
                        _registrarVinculo?.Invoke(
                            c.Documento,
                            c.Transformacion ?? Transform.Identity,
                            elementId);

                        Element eVinculado = null;

                        try
                        {
                            eVinculado = c.Documento.GetElement(elementId);
                        }
                        catch
                        {
                            eVinculado = null;
                        }

                        return eVinculado is RevitLinkInstance
                            ? RenderNodeAction.Proceed
                            : RenderNodeAction.Skip;
                    }

                    return RenderNodeAction.Skip;
                }

                _registrarHost?.Invoke(elementId);

                Element eHost = null;

                try
                {
                    eHost = _docHost?.GetElement(elementId);
                }
                catch
                {
                    eHost = null;
                }

                return eHost is RevitLinkInstance
                    ? RenderNodeAction.Proceed
                    : RenderNodeAction.Skip;
            }
            catch
            {
                return RenderNodeAction.Skip;
            }
        }

        public void OnElementEnd(ElementId elementId) { }

        public RenderNodeAction OnInstanceBegin(InstanceNode node)
        {
            return RenderNodeAction.Skip;
        }

        public void OnInstanceEnd(InstanceNode node) { }

        public RenderNodeAction OnLinkBegin(LinkNode node)
        {
            try
            {
                Document docLink = node != null ? node.GetDocument() : null;
                Transform tr = node != null ? node.GetTransform() : Transform.Identity;

                ContextoVinculoVisible c = new ContextoVinculoVisible()
                {
                    Documento = docLink,
                    Transformacion = tr ?? Transform.Identity
                };

                _pilaVinculos.Push(c);

                if (docLink != null)
                    _registrarContextoVinculo?.Invoke(
                        docLink,
                        c.Transformacion);

                return RenderNodeAction.Proceed;
            }
            catch
            {
                _pilaVinculos.Push(new ContextoVinculoVisible()
                {
                    Documento = null,
                    Transformacion = Transform.Identity
                });

                return RenderNodeAction.Proceed;
            }
        }

        public void OnLinkEnd(LinkNode node)
        {
            if (_pilaVinculos.Count > 0)
                _pilaVinculos.Pop();
        }

        public RenderNodeAction OnFaceBegin(FaceNode node)
        {
            return RenderNodeAction.Skip;
        }

        public void OnFaceEnd(FaceNode node) { }
        public void OnMaterial(MaterialNode node) { }
        public void OnPolymesh(PolymeshTopology node) { }
        public void OnRPC(RPCNode node) { }
        public void OnLight(LightNode node) { }
    }

    private class ResultadoRecorteSolidos
    {
        public bool HuboCambio;
        public bool EliminadoCompletamente;
        public bool FalloReconstruccion;
        public bool SinPerfilesCreables;
        public int CantidadPerfilesOmitidos;
        public string Diagnostico;
        public List<ComponenteMuro> Componentes2D;
        public List<LoopMuro> Loops = new List<LoopMuro>();
    }

    private class ResultadoRestaSolido
    {
        public Solid Solido;
        public bool HuboCambio;
        public bool EliminadoCompletamente;
        public bool FalloParcial;
    }

    public void PrepararNuevaEjecucion()
    {
        _avisoRecorteMostrado = false;
        _solidCache.Clear();
        _origenesSolidosCortantes.Clear();
        _idsCreadosDuranteLote.Clear();
        ConfigurarOrigenDeRecorte(null, null);

        // V75: construir una sola vez por lote el mapa de lo que Revit
        // realmente dibuja/exporta en la vista activa.
        ConstruirCacheVisibilidadVistaActiva();
    }


    // =========================================================
    // V75 - CONSTRUIR CACHÉ DE VISIBILIDAD REAL DE LA VISTA ACTIVA
    // =========================================================
    private void ConstruirCacheVisibilidadVistaActiva()
    {
        _idsVisiblesHostExportador.Clear();
        _idsVisiblesVinculoExportador.Clear();
        _contextosVinculoExportador.Clear();
        _cacheVisibilidadExportadorValida = false;
        _vistaCacheVisibilidadId = ElementId.InvalidElementId;

        try
        {
            UIDocument uidoc = UiDoc;

            if (uidoc == null)
                return;

            Document doc = uidoc.Document;
            View vista = uidoc.ActiveView;

            // El flujo que necesita máxima fidelidad aquí es el 3D, que es
            // precisamente donde el usuario decide visualmente qué elementos
            // deben existir o no como cortantes.
            if (doc == null || vista == null || vista.IsTemplate || !(vista is View3D))
                return;

            VisibilidadVistaExportContext contexto =
                new VisibilidadVistaExportContext(
                    doc,
                    id =>
                    {
                        if (id != null && id != ElementId.InvalidElementId)
                            _idsVisiblesHostExportador.Add(id.ToString());
                    },
                    (docLink, tr, id) =>
                    {
                        if (docLink == null ||
                            id == null ||
                            id == ElementId.InvalidElementId)
                        {
                            return;
                        }

                        _idsVisiblesVinculoExportador.Add(
                            ClaveElementoVinculadoExportador(
                                docLink,
                                tr,
                                id));
                    },
                    (docLink, tr) =>
                    {
                        if (docLink == null)
                            return;

                        _contextosVinculoExportador.Add(
                            ClaveContextoVinculoExportador(
                                docLink,
                                tr));
                    });

            using (CustomExporter exporter =
                new CustomExporter(doc, contexto))
            {
                // No necesitamos caras, mallas ni materiales; solo OnElementBegin
                // y OnLinkBegin. Esto hace el recorrido mucho más ligero.
                exporter.IncludeGeometricObjects = false;
                exporter.ShouldStopOnError = false;
                exporter.Export(vista);
            }

            _vistaCacheVisibilidadId = vista.Id;
            _cacheVisibilidadExportadorValida = true;
        }
        catch
        {
            // Si CustomExporter no está disponible por alguna condición de Revit,
            // se conserva el filtro anterior como respaldo.
            _idsVisiblesHostExportador.Clear();
            _idsVisiblesVinculoExportador.Clear();
            _contextosVinculoExportador.Clear();
            _cacheVisibilidadExportadorValida = false;
            _vistaCacheVisibilidadId = ElementId.InvalidElementId;
        }
    }

    private string ClaveDocumentoExportador(Document doc)
    {
        if (doc == null)
            return "DOC_NULL";

        string ruta = string.Empty;
        string titulo = string.Empty;

        try { ruta = doc.PathName ?? string.Empty; } catch { }
        try { titulo = doc.Title ?? string.Empty; } catch { }

        return ruta + "||" + titulo;
    }

    private string ClaveTransformExportador(Transform tr)
    {
        try
        {
            Transform t = tr ?? Transform.Identity;
            XYZ o = t.Origin;
            XYZ x = t.BasisX;
            XYZ y = t.BasisY;
            XYZ z = t.BasisZ;

            return
                Math.Round(o.X, 5) + "," +
                Math.Round(o.Y, 5) + "," +
                Math.Round(o.Z, 5) + "|" +
                Math.Round(x.X, 5) + "," +
                Math.Round(x.Y, 5) + "," +
                Math.Round(x.Z, 5) + "|" +
                Math.Round(y.X, 5) + "," +
                Math.Round(y.Y, 5) + "," +
                Math.Round(y.Z, 5) + "|" +
                Math.Round(z.X, 5) + "," +
                Math.Round(z.Y, 5) + "," +
                Math.Round(z.Z, 5);
        }
        catch
        {
            return "TR_ID";
        }
    }

    private string ClaveContextoVinculoExportador(
        Document docLink,
        Transform tr)
    {
        return
            ClaveDocumentoExportador(docLink) +
            "||" +
            ClaveTransformExportador(tr);
    }

    private string ClaveElementoVinculadoExportador(
        Document docLink,
        Transform tr,
        ElementId id)
    {
        return
            ClaveContextoVinculoExportador(docLink, tr) +
            "||" +
            (id != null ? id.ToString() : "ID_NULL");
    }

    private bool VistaCoincideConCacheExportador(View vista)
    {
        try
        {
            return
                _cacheVisibilidadExportadorValida &&
                vista != null &&
                _vistaCacheVisibilidadId != null &&
                _vistaCacheVisibilidadId != ElementId.InvalidElementId &&
                vista.Id.Equals(_vistaCacheVisibilidadId);
        }
        catch
        {
            return false;
        }
    }

    private bool EsVisibleHostSegunExportador(
        ElementId id,
        View vista)
    {
        if (!VistaCoincideConCacheExportador(vista))
            return true;

        if (id == null || id == ElementId.InvalidElementId)
            return false;

        return _idsVisiblesHostExportador.Contains(id.ToString());
    }

    private bool EsVisibleVinculoSegunExportador(
        Document docLink,
        Transform tr,
        ElementId id,
        View vistaHost)
    {
        if (!VistaCoincideConCacheExportador(vistaHost))
            return true;

        if (docLink == null ||
            id == null ||
            id == ElementId.InvalidElementId)
        {
            return false;
        }

        // Primero se exige que ESA instancia/transformación del vínculo haya
        // sido recorrida por Revit en la vista activa.
        string contexto = ClaveContextoVinculoExportador(
            docLink,
            tr);

        if (!_contextosVinculoExportador.Contains(contexto))
            return false;

        string clave = ClaveElementoVinculadoExportador(
            docLink,
            tr,
            id);

        return _idsVisiblesVinculoExportador.Contains(clave);
    }

    // Método público usado por el selector de muros para decidir si una unión
    // geométrica oculta debe ignorarse temporalmente al leer la cara del muro.
    public bool EsElementoVisibleEnVistaActivaParaTarrajeo(Element e)
    {
        try
        {
            if (e == null)
                return false;

            View vista = UiDoc != null
                ? UiDoc.ActiveView
                : null;

            if (!EsElementoVisibleEnVista(e, vista))
                return false;

            if (vista != null &&
                object.ReferenceEquals(e.Document, vista.Document))
            {
                return EsVisibleHostSegunExportador(
                    e.Id,
                    vista);
            }

            return true;
        }
        catch
        {
            return true;
        }
    }

    public void ConfigurarOrigenDeRecorte(
        Element elementoGeometrico,
        RevitLinkInstance vinculoOrigen)
    {
        List<Element> elementos = new List<Element>();

        if (elementoGeometrico != null)
            elementos.Add(elementoGeometrico);

        ConfigurarOrigenesDeRecorte(elementos, vinculoOrigen);
    }

    // V71: permite excluir un conjunto completo de elementos que forman un
    // mismo anfitrión compuesto. Está pensado especialmente para escaleras,
    // donde tramos, descansos y soportes son elementos distintos y antes se
    // recortaban entre sí.
    public void ConfigurarOrigenesDeRecorte(
        IEnumerable<Element> elementosGeometricos,
        RevitLinkInstance vinculoOrigen)
    {
        _elementoOrigenRecorte = null;
        _vinculoOrigenRecorte = vinculoOrigen;
        _idsOrigenRecorte.Clear();
        _usarSondaUnilateralOrigen = true;

        if (elementosGeometricos == null)
            return;

        HashSet<string> visitados = new HashSet<string>();

        foreach (Element e in elementosGeometricos)
        {
            if (e == null)
                continue;

            if (_elementoOrigenRecorte == null)
                _elementoOrigenRecorte = e;

            AgregarOrigenYDependientesRecursivo(e, visitados, 0);
        }
    }

    private void AgregarOrigenYDependientesRecursivo(
        Element elemento,
        HashSet<string> visitados,
        int profundidad)
    {
        if (elemento == null || visitados == null || profundidad > 6)
            return;

        string clave;

        try
        {
            clave = elemento.Document.GetHashCode().ToString() + "|" + elemento.Id.ToString();
        }
        catch
        {
            clave = elemento.Id.ToString();
        }

        if (!visitados.Add(clave))
            return;

        _idsOrigenRecorte.Add(elemento.Id);

        try
        {
            ICollection<ElementId> dependientes = elemento.GetDependentElements(null);

            if (dependientes == null)
                return;

            foreach (ElementId id in dependientes)
            {
                if (id == null || id == ElementId.InvalidElementId)
                    continue;

                Element dep = elemento.Document.GetElement(id);

                if (dep != null)
                    AgregarOrigenYDependientesRecursivo(
                        dep,
                        visitados,
                        profundidad + 1);
            }
        }
        catch
        {
        }
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;
        bool relanzarSeleccion = false;

        // En pick por cara se inicia un lote nuevo. En creación por elementos
        // el handler selector llama una sola vez a PrepararNuevaEjecucion().
        PrepararNuevaEjecucion();

        try
        {
            if (FaceRef == null && CaraProcesada == null)
            {
                TaskDialog.Show("MYG", "No se ha seleccionado ninguna cara.");
                return;
            }

            WallType wt = TipoMuro ?? (Form != null ? Form.TipoMuroSeleccionado : null);

            if (wt == null)
            {
                TaskDialog.Show("MYG", "Debe seleccionar un tipo de muro.");
                return;
            }

            // Un fallo de esta cara no termina la sesión de selección.
            relanzarSeleccion = true;
            bool permitirUnion = Form != null && Form.PermitirUnion;

            if (Form != null)
                ConsiderarVinculos = Form.ConsiderarVinculos;

            Element host = null;
            Transform tr = Transform.Identity;
            Face face = null;

            // Cuando SeleccionarCarasHandler ya resolvió la referencia, se usa
            // directamente esa Face. En caras vinculadas sus coordenadas siguen
            // perteneciendo al LinkDocument y TransformProcesado las lleva una
            // sola vez al documento anfitrión.
            if (CaraProcesada != null && HostProcesado != null)
            {
                face = CaraProcesada;
                host = HostProcesado;
                tr = TransformProcesado ?? Transform.Identity;

                ConfigurarOrigenDeRecorte(
                    ElementoGeometricoOrigen ?? host,
                    VinculoOrigen);
            }
            else
            {
                face = ObtenerFaceDesdeReferencia(doc, FaceRef, out host, out tr);
            }

            if (face == null || host == null)
            {
                TaskDialog.Show("MYG", "No se pudo obtener una cara válida.");
                return;
            }

            List<Wall> creados = CrearMurosDesdeFaceProcesada(
                doc,
                uidoc,
                host,
                face,
                tr,
                wt,
                permitirUnion);

            if (creados == null || creados.Count == 0)
            {
                if (!_avisoRecorteMostrado)
                    TaskDialog.Show(
                        "MYG",
                        "Esta cara no generó un muro: no tiene un perfil válido o quedó totalmente ocupada por otro sólido. " +
                        "Cierra este aviso para seleccionar otra cara; pulsa Esc para terminar.");
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            relanzarSeleccion = false;
        }
        catch (Exception ex)
        {
            TaskDialog.Show("MYG - Error", "Ocurrió un error al crear el muro de tarrajeo:\n\n" + ex.Message);
        }
        finally
        {
            FaceRef = null;
            CaraProcesada = null;
            HostProcesado = null;
            ElementoGeometricoOrigen = null;
            VinculoOrigen = null;
            TransformProcesado = null;

            if (relanzarSeleccion && SeleccionarEvent != null)
                SeleccionarEvent.Raise();
            else
                MostrarFormulario();
        }
    }

    // =========================================================
    // API PÚBLICA USADA POR LOS HANDLERS DE ELEMENTOS
    // =========================================================

    // Respaldo geométrico para suelos: reutiliza SOLO el motor de perfiles.
    // Los candidatos ya fueron filtrados y transformados por el handler de
    // suelos, que conserva sus exclusiones del anfitrión/escalera/vínculos.
    // No crea muros, transacciones ni elementos en el documento.
    public int UltimaCantidadPerfilesOmitidos { get; private set; }

    public bool IntentarRecortarPerfilPlanar(
        Document doc,
        View vista,
        Element hostElem,
        IList<CurveLoop> loopsCaraModelo,
        XYZ origenCara,
        XYZ normalCara,
        double espesor,
        List<Solid> candidatos,
        out List<List<CurveLoop>> perfiles,
        out bool huboRecorte,
        out string diagnostico,
        double toleranciaAristaProyectada = 0.0,
        IDictionary<Solid, string> origenesCandidatos = null)
    {
        perfiles = new List<List<CurveLoop>>();
        huboRecorte = false;
        diagnostico = string.Empty;
        UltimaCantidadPerfilesOmitidos = 0;
        List<string> avisos = new List<string>();
        try
        {
            if (doc == null || loopsCaraModelo == null || loopsCaraModelo.Count == 0 ||
                origenCara == null || normalCara == null || normalCara.GetLength() <= TOL ||
                double.IsNaN(espesor) || double.IsInfinity(espesor) || espesor <= TOL || candidatos == null ||
                double.IsNaN(toleranciaAristaProyectada) || double.IsInfinity(toleranciaAristaProyectada) ||
                toleranciaAristaProyectada < 0.0)
                throw new InvalidOperationException("Faltan datos válidos para recuperar el perfil planar del suelo.");

            MarcoMuro marco = CrearMarcoPlanarParaRecorte(origenCara, normalCara, espesor);
            // La proyección XY puede acortar una arista hasta |Normal.Z|.
            // Ajustar SOLO el mínimo de láminas del respaldo de suelos; no
            // modificar PTOL de muros ni el espesor físico de la sonda.
            double minimoArista = 0.0;
            if (toleranciaAristaProyectada > 0.0)
            {
                if (Math.Abs(marco.Normal.Z) <= TOL)
                    throw new InvalidOperationException("Una cara vertical no admite un boceto horizontal de suelo.");
                minimoArista = 1.1 * toleranciaAristaProyectada / Math.Abs(marco.Normal.Z);
            }
            List<LoopMuro> loops = new List<LoopMuro>();
            foreach (CurveLoop contorno in loopsCaraModelo)
            {
                LoopMuro loop = LoopDesdeCurveLoop(contorno, Transform.Identity, marco);
                if (loop == null || !LoopSeguro(loop))
                    throw new InvalidOperationException("Un contorno original no admite un perfil planar seguro.");
                loops.Add(loop);
            }

            List<ComponenteMuro> componentes = ClasificarComponentes(loops);
            if (componentes.Count == 0)
                throw new InvalidOperationException("No se encontraron islas exteriores en el perfil del suelo.");
            for (int i = 0; i < candidatos.Count; i++)
            {
                Solid candidato = candidatos[i];
                if (candidato == null)
                    continue;
                string origen;
                if (origenesCandidatos != null && origenesCandidatos.TryGetValue(candidato, out origen) &&
                    !string.IsNullOrWhiteSpace(origen))
                    _origenesSolidosCortantes[candidato] = "Candidato de suelo nº " + (i + 1) + ". " + origen;
                else if (!_origenesSolidosCortantes.ContainsKey(candidato))
                    _origenesSolidosCortantes[candidato] = "Candidato de suelo nº " + (i + 1) + ".";
            }

            Transform volverACara = Transform.CreateTranslation(marco.Normal.Multiply(-espesor / 2.0));
            foreach (ComponenteMuro componente in componentes)
            {
                try
                {
                    ResultadoRecorteSolidos recorte = RecortarComponentePorEspesorReal(
                        doc, vista, hostElem, componente, marco, marco.Normal, espesor, candidatos, minimoArista);
                    if (recorte == null || recorte.FalloReconstruccion)
                        throw new InvalidOperationException(recorte != null ? recorte.Diagnostico : "El recorte no devolvió resultado.");

                    huboRecorte |= recorte.HuboCambio;
                    UltimaCantidadPerfilesOmitidos += recorte.CantidadPerfilesOmitidos;
                    if (!string.IsNullOrWhiteSpace(recorte.Diagnostico))
                        avisos.Add(recorte.Diagnostico);
                    if (recorte.EliminadoCompletamente || recorte.SinPerfilesCreables)
                        continue;

                    // PolyTree ya conserva la relación exterior/huecos. No
                    // reclasificar por proximidad: podría perder un hueco.
                    List<ComponenteMuro> restos = recorte.Componentes2D ?? (recorte.HuboCambio
                        ? ClasificarComponentes(recorte.Loops)
                        : new List<ComponenteMuro> { componente });
                    if (restos.Count == 0)
                        throw new InvalidOperationException("Se perdió el contorno de un suelo parcialmente recortado.");

                    foreach (ComponenteMuro resto in restos)
                    {
                        try
                        {
                            List<LoopMuro> contornos = new List<LoopMuro> { resto.Exterior };
                            if (resto.Huecos != null)
                                contornos.AddRange(resto.Huecos);
                            List<CurveLoop> perfil = new List<CurveLoop>();
                            for (int i = 0; i < contornos.Count; i++)
                            {
                                string motivo;
                                bool seguro = recorte.Componentes2D != null
                                    ? ValidarLoopResultado2D(contornos[i], minimoArista, out motivo)
                                    : LoopSeguro(contornos[i]);
                                if (!seguro)
                                    throw new InvalidOperationException("No se conservó un contorno o hueco del suelo recortado.");
                                CurveLoop contorno = CurveLoopDesdeLoop(contornos[i], i == 0, volverACara);
                                if (contorno == null || contorno.IsOpen())
                                    throw new InvalidOperationException("Un contorno recuperado del suelo quedó abierto.");
                                perfil.Add(contorno);
                            }
                            // Agregar solo cuando TODOS sus huecos están listos.
                            perfiles.Add(perfil);
                        }
                        catch (Exception ex)
                        {
                            UltimaCantidadPerfilesOmitidos++;
                            huboRecorte = true;
                            avisos.Add("Se omitió una pieza de suelo, conservando las demás: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    UltimaCantidadPerfilesOmitidos++;
                    huboRecorte = true;
                    avisos.Add("Se omitió un componente de suelo sin crear su perfil original: " + ex.Message);
                }
            }
            // Una salida vacía con omitidos no significa ocupación total. El
            // llamador consulta el contador y conserva el diagnóstico parcial.
            diagnostico = string.Join("\n", avisos);
            // Compatibilidad: true + vacío conserva el significado de ocupación
            // total. Ninguna pieza creable se devuelve como omisión, no cobertura.
            return perfiles.Count > 0 || UltimaCantidadPerfilesOmitidos == 0;
        }
        catch (Exception ex)
        {
            perfiles.Clear();
            huboRecorte = false;
            diagnostico = "Respaldo de perfil planar: " + ex.Message;
            return false;
        }
    }

    private MarcoMuro CrearMarcoPlanarParaRecorte(XYZ origenCara, XYZ normalCara, double espesor)
    {
        XYZ n = normalCara.Normalize();
        XYZ referencia = Math.Abs(n.Z) < 0.9 ? XYZ.BasisZ : XYZ.BasisX;
        XYZ u = referencia.CrossProduct(n).Normalize();
        return new MarcoMuro
        {
            Origen = origenCara + n.Multiply(espesor / 2.0),
            U = u,
            V = n.CrossProduct(u).Normalize(),
            Normal = n
        };
    }

    public Wall CrearMuroDesdeFaceProcesada(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        Face cara,
        Transform transformCara,
        WallType wallType,
        bool permitirUnion)
    {
        List<Wall> creados = CrearMurosDesdeFaceProcesada(
            doc,
            uidoc,
            hostElem,
            cara,
            transformCara,
            wallType,
            permitirUnion);

        return creados.FirstOrDefault();
    }

    public List<Wall> CrearMurosDesdeFaceProcesada(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        Face cara,
        Transform transformCara,
        WallType wallType,
        bool permitirUnion)
    {
        if (cara is PlanarFace)
        {
            return CrearMurosDesdeCaraPlanarProcesada(
                doc,
                uidoc,
                hostElem,
                cara as PlanarFace,
                transformCara,
                wallType,
                permitirUnion);
        }

        if (cara is CylindricalFace)
        {
            Wall w = CrearMuroDesdeCaraCilindricaProcesada(
                doc,
                uidoc,
                hostElem,
                cara as CylindricalFace,
                transformCara,
                wallType,
                permitirUnion);

            return w != null ? new List<Wall>() { w } : new List<Wall>();
        }

        return new List<Wall>();
    }


    // =========================================================
    // V58 - CREACIÓN DESDE LOOP PLANAR SINTÉTICO
    // =========================================================
    // Pensado para tapas/retornos del espesor cuando el muro está unido y
    // Revit no entrega una Face física confiable. Se construye un loop planar
    // en coordenadas del modelo activo y se procesa con el mismo motor:
    // - recorte por sólidos visibles en vista activa,
    // - boceto si hay mordidas/huecos,
    // - control Permitir Unión,
    // - corrección de muros cortantes.
    // =========================================================

    public List<Wall> CrearMurosDesdeLoopPlanarProcesado(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        IList<XYZ> puntosPlano,
        XYZ normalCara,
        WallType wallType,
        bool permitirUnion)
    {
        List<Wall> creados = new List<Wall>();

        try
        {
            if (doc == null ||
                uidoc == null ||
                hostElem == null ||
                puntosPlano == null ||
                puntosPlano.Count < 3 ||
                normalCara == null ||
                wallType == null)
            {
                return creados;
            }

            XYZ normal = new XYZ(
                normalCara.X,
                normalCara.Y,
                0.0);

            if (normal.GetLength() <= TOL)
                return creados;

            normal = normal.Normalize();

            // Copia inmutable y cierre seguro del loop recibido.
            List<XYZ> snapshot = new List<XYZ>();

            foreach (XYZ p in puntosPlano)
            {
                if (p == null)
                    continue;

                if (snapshot.Count == 0 ||
                    snapshot[snapshot.Count - 1].DistanceTo(p) > PTOL)
                {
                    snapshot.Add(p);
                }
            }

            if (snapshot.Count > 2 &&
                snapshot[0].DistanceTo(snapshot[snapshot.Count - 1]) <= PTOL)
            {
                snapshot.RemoveAt(snapshot.Count - 1);
            }

            if (snapshot.Count < 3)
                return creados;

            snapshot.Add(snapshot[0]);

            MarcoMuro marco = CrearMarcoDesdeLoopPlanar(
                snapshot,
                normal,
                wallType.Width);

            if (marco == null)
                return creados;

            LoopMuro exterior = LoopDesdePuntosPlanos(
                snapshot,
                marco);

            if (exterior == null || !LoopSeguro(exterior))
                return creados;

            ComponenteMuro componenteBase = new ComponenteMuro
            {
                Exterior = exterior,
                Huecos = new List<LoopMuro>()
            };

            // V72: el snapshot NO pierde la lógica de descuentos. Se evalúa
            // el mismo volumen exterior de espesor completo de la cara; cualquier
            // Solid visible ajeno al origen puede generar una mordida/hueco.
            ResultadoRecorteSolidos recorte =
                RecortarComponentePorEspesorReal(
                    doc,
                    uidoc.ActiveView,
                    hostElem,
                    componenteBase,
                    marco,
                    normal,
                    wallType.Width);

            List<ComponenteMuro> componentes =
                new List<ComponenteMuro>();

            if (recorte != null && (recorte.EliminadoCompletamente || recorte.SinPerfilesCreables))
                return creados;

            if (recorte != null && recorte.FalloReconstruccion)
            {
                AvisarRecorteNoResuelto(recorte.Diagnostico);
                return creados;
            }

            if (recorte != null &&
                recorte.HuboCambio &&
                !recorte.FalloReconstruccion &&
                recorte.Loops != null &&
                recorte.Loops.Count > 0)
            {
                List<ComponenteMuro> recortados = recorte.Componentes2D ??
                    ClasificarComponentes(recorte.Loops);

                if (recortados != null && recortados.Count > 0)
                    componentes.AddRange(recortados);
            }

            // Sin intersección volumétrica se conserva el perfil original.
            if (componentes.Count == 0)
                componentes.Add(componenteBase);

            foreach (ComponenteMuro componente in componentes)
            {
                if (componente == null ||
                    componente.Exterior == null ||
                    !LoopSeguro(componente.Exterior))
                {
                    continue;
                }

                List<LoopMuro> huecos = SanitizarHuecos(
                    componente.Exterior,
                    componente.Huecos);

                // No convertir un hueco rechazado en material. Se omite solo
                // este propietario y se conserva el resto de los componentes.
                if (huecos.Count != (componente.Huecos != null ? componente.Huecos.Count : 0))
                    continue;

                double zMin = componente.Exterior.Puntos3D.Min(p => p.Z);
                Level nivel = ObtenerNivelBase(doc, zMin);

                if (nivel == null)
                    continue;

                Wall muro = null;

                if (huecos.Count == 0 &&
                    EsRectangulo(componente.Exterior))
                {
                    muro = CrearRectangular(
                        doc,
                        componente.Exterior,
                        wallType,
                        nivel,
                        normal,
                        permitirUnion);

                    // Fallback: algunos contrapasos cortos fallan con el
                    // overload de línea, pero aceptan el perfil cerrado.
                    if (muro == null)
                    {
                        muro = CrearDesdePerfilDirectoConHuecos(
                            doc,
                            componente.Exterior,
                            new List<LoopMuro>(),
                            wallType,
                            nivel,
                            normal,
                            permitirUnion);
                    }
                }
                else
                {
                    muro = CrearDesdePerfilDirectoConHuecos(
                        doc,
                        componente.Exterior,
                        huecos,
                        wallType,
                        nivel,
                        normal,
                        permitirUnion);
                }

                if (muro != null)
                    creados.Add(muro);
            }
        }
        catch
        {
            // El lote continúa con las demás caras.
        }

        return creados;
    }

    private MarcoMuro CrearMarcoDesdeLoopPlanar(IList<XYZ> puntosPlano, XYZ normal, double espesor)
    {
        try
        {
            if (puntosPlano == null || puntosPlano.Count < 3 || normal == null)
                return null;

            XYZ origenCara = puntosPlano[0];
            XYZ origen = origenCara + normal.Normalize().Multiply(espesor / 2.0);
            XYZ v = XYZ.BasisZ;
            XYZ u = v.CrossProduct(normal);

            if (u.GetLength() <= TOL)
                u = XYZ.BasisX;

            return new MarcoMuro()
            {
                Origen = origen,
                U = u.Normalize(),
                V = v,
                Normal = normal.Normalize()
            };
        }
        catch
        {
            return null;
        }
    }

    private LoopMuro LoopDesdePuntosPlanos(IList<XYZ> puntosPlano, MarcoMuro marco)
    {
        try
        {
            if (puntosPlano == null || puntosPlano.Count < 3 || marco == null)
                return null;

            List<UV2> pts2 = new List<UV2>();

            foreach (XYZ p in puntosPlano)
            {
                if (p == null)
                    continue;

                XYZ d = p - marco.Origen;

                pts2.Add(new UV2(
                    d.DotProduct(marco.U),
                    d.DotProduct(marco.V)));
            }

            if (pts2.Count < 3)
                return null;

            if (!Igual(pts2[0], pts2[pts2.Count - 1]))
                pts2.Add(new UV2(pts2[0].U, pts2[0].V));

            return LoopDesdeUV(pts2, marco);
        }
        catch
        {
            return null;
        }
    }

    public Wall CrearMuroDesdeCaraPlanarProcesada(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        PlanarFace cara,
        Transform transformCara,
        WallType wallType,
        bool permitirUnion)
    {
        return CrearMurosDesdeCaraPlanarProcesada(
            doc,
            uidoc,
            hostElem,
            cara,
            transformCara,
            wallType,
            permitirUnion).FirstOrDefault();
    }

    public List<Wall> CrearMurosDesdeCaraPlanarProcesada(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        PlanarFace cara,
        Transform transformCara,
        WallType wallType,
        bool permitirUnion)
    {
        List<Wall> creados = new List<Wall>();

        try
        {
            if (doc == null ||
                uidoc == null ||
                hostElem == null ||
                cara == null ||
                wallType == null)
            {
                return creados;
            }

            Transform tr = transformCara ?? Transform.Identity;
            XYZ normal = tr.OfVector(cara.FaceNormal);

            if (normal == null || normal.GetLength() <= TOL)
                return creados;

            normal = normal.Normalize();

            // Solo caras verticales. No se intenta corregir, prolongar ni
            // proyectar una cara inclinada u horizontal.
            if (Math.Abs(normal.Z) > VTOL)
                return creados;

            MarcoMuro marco = CrearMarco(
                cara,
                tr,
                normal,
                wallType.Width);

            if (marco == null)
                return creados;

            // El perfil base sale únicamente de la cara seleccionada. Después
            // se evalúa el volumen exterior de todo el espesor del revestimiento.
            List<LoopMuro> loopsCara = ObtenerLoopsDeFace(
                cara,
                marco,
                tr);

            if (loopsCara == null || loopsCara.Count == 0)
                return creados;

            List<ComponenteMuro> componentesBase = ClasificarComponentes(
                loopsCara);

            // V67:
            // Cada componente de la cara se conserva como base. Solo se reemplaza
            // por un perfil recortado cuando un sólido atraviesa realmente la
            // volumen exterior real de esa cara.
            List<ComponenteMuro> componentes = new List<ComponenteMuro>();

            foreach (ComponenteMuro componenteBase in componentesBase)
            {
                if (componenteBase == null ||
                    componenteBase.Exterior == null ||
                    !LoopSeguro(componenteBase.Exterior))
                {
                    continue;
                }

                ResultadoRecorteSolidos recorte = RecortarComponentePorEspesorReal(
                    doc,
                    uidoc.ActiveView,
                    hostElem,
                    componenteBase,
                    marco,
                    normal,
                    wallType.Width);

                if (recorte != null && (recorte.EliminadoCompletamente || recorte.SinPerfilesCreables))
                    continue;

                if (recorte != null && recorte.FalloReconstruccion)
                {
                    AvisarRecorteNoResuelto(recorte.Diagnostico);
                    continue;
                }

                if (recorte != null &&
                    recorte.HuboCambio &&
                    !recorte.FalloReconstruccion &&
                    recorte.Loops != null &&
                    recorte.Loops.Count > 0)
                {
                    List<ComponenteMuro> recortados = recorte.Componentes2D ?? ClasificarComponentes(
                        recorte.Loops);

                    if (recortados != null && recortados.Count > 0)
                    {
                        componentes.AddRange(recortados);
                        continue;
                    }
                }

                // Sin intersección volumétrica se conserva el perfil original.
                componentes.Add(componenteBase);
            }

            foreach (ComponenteMuro componente in componentes)
            {
                if (componente == null ||
                    componente.Exterior == null ||
                    !LoopSeguro(componente.Exterior))
                {
                    continue;
                }

                List<LoopMuro> huecos = SanitizarHuecos(
                    componente.Exterior,
                    componente.Huecos);

                // No convertir un hueco rechazado en material. Se omite solo
                // este propietario y se conserva el resto de los componentes.
                if (huecos.Count != (componente.Huecos != null ? componente.Huecos.Count : 0))
                    continue;

                double zMin = componente.Exterior.Puntos3D.Min(p => p.Z);
                Level nivel = ObtenerNivelBase(doc, zMin);

                if (nivel == null)
                    continue;

                Wall muro = null;

                // Un rectángulo sin huecos se crea con el método normal de
                // Revit: base inferior + altura exacta de la cara.
                if (huecos.Count == 0 && EsRectangulo(componente.Exterior))
                {
                    muro = CrearRectangular(
                        doc,
                        componente.Exterior,
                        wallType,
                        nivel,
                        normal,
                        permitirUnion);
                }
                else
                {
                    // El perfil resultante se crea directamente. No se usa un
                    // muro rectangular temporal ni SketchEditScope.
                    muro = CrearDesdePerfilDirectoConHuecos(
                        doc,
                        componente.Exterior,
                        huecos,
                        wallType,
                        nivel,
                        normal,
                        permitirUnion);
                }

                if (muro != null)
                    creados.Add(muro);
            }
        }
        catch
        {
            // No se muestran cuadros repetitivos. La cara que no sea válida
            // simplemente no genera un muro.
        }

        return creados;
    }

    // =========================================================
    // CARA CILÍNDRICA VERTICAL
    // =========================================================

    public Wall CrearMuroDesdeCaraCilindricaProcesada(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        CylindricalFace cara,
        Transform transformCara,
        WallType wallType,
        bool permitirUnion)
    {
        try
        {
            if (doc == null || uidoc == null || hostElem == null || cara == null || wallType == null)
                return null;

            Transform tr = transformCara ?? Transform.Identity;
            XYZ eje = tr.OfVector(cara.Axis).Normalize();

            if (Math.Abs(Math.Abs(eje.DotProduct(XYZ.BasisZ)) - 1.0) > VTOL)
                return null;

            if (eje.Z < 0)
                eje = eje.Multiply(-1.0);

            XYZ centroEje = tr.OfPoint(cara.Origin);
            List<XYZ> pts = TessFace(cara, tr);

            if (pts.Count < 4)
                return null;

            double minZ = pts.Min(p => p.Z);
            double maxZ = pts.Max(p => p.Z);
            double altura = maxZ - minZ;

            if (altura <= TOL)
                return null;

            XYZ r0 = null;

            foreach (XYZ p in pts)
            {
                XYZ v = p - centroEje;
                XYZ r = v - eje.Multiply(v.DotProduct(eje));

                if (r.GetLength() > TOL)
                {
                    r0 = r.Normalize();
                    break;
                }
            }

            if (r0 == null)
                return null;

            XYZ t0 = eje.CrossProduct(r0).Normalize();

            List<double> angs = new List<double>();
            List<double> radios = new List<double>();

            foreach (XYZ p in pts)
            {
                XYZ v = p - centroEje;
                XYZ r = v - eje.Multiply(v.DotProduct(eje));
                double rr = r.GetLength();

                if (rr <= TOL)
                    continue;

                radios.Add(rr);
                angs.Add(NormAng(Math.Atan2(r.DotProduct(t0), r.DotProduct(r0))));
            }

            if (angs.Count < 2 || radios.Count == 0)
                return null;

            double ai, af;

            if (!RangoAngMenor(angs, out ai, out af))
                return null;

            double am = (ai + af) / 2.0;
            double radioCara = radios.Average();

            XYZ normalMedia = r0.Multiply(Math.Cos(am)) + t0.Multiply(Math.Sin(am));
            normalMedia = normalMedia.Normalize();

            try
            {
                BoundingBoxUV bb = cara.GetBoundingBox();

                if (bb != null)
                {
                    XYZ nc = tr.OfVector(cara.ComputeNormal(new UV((bb.Min.U + bb.Max.U) / 2.0, (bb.Min.V + bb.Max.V) / 2.0))).Normalize();

                    if (nc.GetLength() > TOL)
                        normalMedia = nc;
                }
            }
            catch
            {
            }

            XYZ radialMedia = r0.Multiply(Math.Cos(am)) + t0.Multiply(Math.Sin(am));
            radialMedia = radialMedia.Normalize();

            // V31:
            // Igual que en caras planas, el eje físico de creación debe quedar
            // a medio espesor fuera de la cara cilíndrica para que el muro curvo
            // no invada el anfitrión.
            double sentidoOffset = normalMedia.DotProduct(radialMedia) >= 0.0 ? 1.0 : -1.0;
            // La orientación se comprueba en el punto medio del arco creado,
            // no en su inicio (Wall.Orientation). Conserva el sentido exterior
            // de la cara original también en superficies cilíndricas cóncavas.
            normalMedia = radialMedia.Multiply(sentidoOffset);
            double radioEje = radioCara + sentidoOffset * (wallType.Width / 2.0);

            if (radioEje <= TOL)
                return null;

            double tb = (minZ - centroEje.Z) / eje.Z;
            XYZ centroBase = centroEje + eje.Multiply(tb);

            Func<double, XYZ> P = a => centroBase + r0.Multiply(Math.Cos(a) * radioEje) + t0.Multiply(Math.Sin(a) * radioEje);

            XYZ p1 = P(ai);
            XYZ p2 = P(af);
            XYZ pm = P(am);

            if (p1.DistanceTo(p2) <= TOL || p1.DistanceTo(pm) <= TOL || p2.DistanceTo(pm) <= TOL)
                return null;

            Arc arc = Arc.Create(p1, p2, pm);
            Level nivel = ObtenerNivelBase(doc, minZ);

            if (arc == null || nivel == null)
                return null;

            Wall muro = null;

            using (Transaction tx = new Transaction(doc, "MYG Tarrajeo Muro Curvo"))
            {
                tx.Start();
                AplicarPreprocesador(tx);

                muro = Wall.Create(
                    doc,
                    arc,
                    wallType.Id,
                    nivel.Id,
                    altura,
                    TarrajeoAlturas.CalcularDesfaseMuro(minZ, nivel.ProjectElevation),
                    false,
                    false);

                if (muro != null)
                {
                    OrientarMuro(muro, normalMedia);
                    ConfigurarLineaUbicacionExterior(muro);
                    ConfigurarUnion(muro, permitirUnion);
                    doc.Regenerate();

                    // Un Wall curvo no admite un perfil arbitrario de recorte.
                    // Comprobar su volumen real evita dejar uno entero solapado.
                    if (!CurvoLibreDeInterferencias(doc, uidoc.ActiveView, hostElem, muro))
                    {
                        tx.RollBack();
                        if (!_avisoRecorteMostrado)
                        {
                            _avisoRecorteMostrado = true;
                            TaskDialog.Show("MYG - Recorte de tarrajeo curvo",
                                "Se omitió un paño curvo con interferencias o cuya geometría no pudo comprobarse. " +
                                "Revit no permite aplicar este recorte arbitrario conservando el tipo de muro curvo.");
                        }
                        return null;
                    }
                    GuardarIdEnParametro(muro, "GEN_ID Elemento");
                }

                TransactionStatus estado = tx.Commit();

                if (estado != TransactionStatus.Committed)
                    muro = null;
            }

            if (muro != null)
                _idsCreadosDuranteLote.Add(muro.Id);

            return muro;
        }
        catch
        {
            return null;
        }
    }

    // =========================================================
    // MARCO, LOOPS Y CLASIFICACIÓN
    // =========================================================

    private MarcoMuro CrearMarco(PlanarFace cara, Transform tr, XYZ normal, double espesor)
    {
        try
        {
            // V31:
            // La geometría del muro de Revit se genera alrededor de su plano/curva base.
            // Si usamos directamente la cara seleccionada como plano base, medio espesor
            // queda dentro del muro anfitrión.
            //
            // Por eso el plano real de creación se desplaza medio espesor hacia la normal
            // de la cara. Luego se configura WALL_KEY_REF_PARAM = Finish Face Interior,
            // para que la referencia/ubicación del muro quede asociada a la cara interior.
            XYZ origen = ObtenerPrimerPunto(cara, tr) + normal.Normalize().Multiply(espesor / 2.0);
            XYZ v = XYZ.BasisZ;
            XYZ u = v.CrossProduct(normal);

            if (u.GetLength() <= TOL)
                u = XYZ.BasisX;

            return new MarcoMuro()
            {
                Origen = origen,
                U = u.Normalize(),
                V = v,
                Normal = normal
            };
        }
        catch
        {
            return null;
        }
    }

    private List<LoopMuro> ObtenerLoopsDeFace(PlanarFace cara, MarcoMuro marco, Transform tr)
    {
        List<LoopMuro> loops = new List<LoopMuro>();

        try
        {
            if (tr == null)
                tr = Transform.Identity;

            foreach (CurveLoop cl in cara.GetEdgesAsCurveLoops())
            {
                LoopMuro lp = LoopDesdeCurveLoop(cl, tr, marco);

                if (lp != null && lp.AreaAbs > 1e-6)
                    loops.Add(lp);
            }
        }
        catch
        {
        }

        return loops;
    }

    private LoopMuro LoopDesdeCurveLoop(CurveLoop cl, Transform tr, MarcoMuro marco)
    {
        if (cl == null || marco == null)
            return null;

        List<UV2> pts2 = new List<UV2>();

        foreach (Curve c in cl)
        {
            IList<XYZ> pts = PuntosCurva(c);

            foreach (XYZ p0 in pts)
            {
                XYZ p = tr != null ? tr.OfPoint(p0) : p0;
                XYZ d = p - marco.Origen;
                UV2 uv = new UV2(d.DotProduct(marco.U), d.DotProduct(marco.V));

                if (pts2.Count == 0 || !Igual(pts2[pts2.Count - 1], uv))
                    pts2.Add(uv);
            }
        }

        return LoopDesdeUV(pts2, marco);
    }

    private LoopMuro LoopDesdeUV(List<UV2> pts2, MarcoMuro marco)
    {
        if (pts2 == null || pts2.Count < 3 || marco == null)
            return null;

        pts2 = Limpiar(pts2);

        if (pts2.Count < 3)
            return null;

        if (!Igual(pts2[0], pts2[pts2.Count - 1]))
            pts2.Add(new UV2(pts2[0].U, pts2[0].V));

        pts2 = Limpiar(pts2);

        if (pts2.Count < 4)
            return null;

        LoopMuro lp = new LoopMuro();
        lp.Puntos2D = pts2;
        lp.Marco = marco;
        lp.Area = Area(pts2);
        lp.AreaAbs = Math.Abs(lp.Area);
        lp.Puntos3D = pts2.Select(p => marco.Origen + marco.U.Multiply(p.U) + marco.V.Multiply(p.V)).ToList();
        lp.MinU = pts2.Min(p => p.U);
        lp.MaxU = pts2.Max(p => p.U);
        lp.MinV = pts2.Min(p => p.V);
        lp.MaxV = pts2.Max(p => p.V);

        return lp;
    }

    private List<ComponenteMuro> ClasificarComponentes(
        List<LoopMuro> loops)
    {
        List<ComponenteMuro> comps = new List<ComponenteMuro>();

        if (loops == null || loops.Count == 0)
            return comps;

        List<LoopMuro> orden = new List<LoopMuro>();
        foreach (LoopMuro loop in loops.Where(x => x != null && x.AreaAbs > 1e-6)
            .OrderByDescending(x => x.AreaAbs))
            if (!orden.Any(x => Similar(x, loop)))
                orden.Add(loop);

        Dictionary<LoopMuro, int> profundidades = new Dictionary<LoopMuro, int>();
        Dictionary<LoopMuro, ComponenteMuro> exteriores = new Dictionary<LoopMuro, ComponenteMuro>();
        foreach (LoopMuro lp in orden)
        {
            // El padre es el contorno de menor área que contiene este loop.
            // Ya se procesó porque el orden va de mayor a menor área. Se usa
            // un punto interior real para admitir también perfiles cóncavos.
            UV2 puntoPrueba = PuntoInteriorSeguro(lp);
            LoopMuro padre = orden
                .Where(x => x.AreaAbs > lp.AreaAbs && puntoPrueba != null &&
                    PuntoEnPoligono(puntoPrueba, x.Puntos2D))
                .OrderBy(x => x.AreaAbs)
                .FirstOrDefault();
            int profundidad = padre == null ? 0 : profundidades[padre] + 1;
            profundidades[lp] = profundidad;

            // Paridad: exterior, hueco, isla conservada, hueco de esa isla...
            // Una isla dentro de una interferencia anular no debe convertirse
            // en un segundo hueco del primer exterior.
            if (profundidad % 2 == 0)
            {
                ComponenteMuro componente = new ComponenteMuro
                {
                    Exterior = lp,
                    Huecos = new List<LoopMuro>()
                };
                comps.Add(componente);
                exteriores[lp] = componente;
            }
            else
            {
                exteriores[padre].Huecos.Add(lp);
            }
        }

        return comps;
    }

    private List<LoopMuro> SanitizarHuecos(
        LoopMuro exterior,
        List<LoopMuro> huecos)
    {
        List<LoopMuro> safe = new List<LoopMuro>();

        if (exterior == null || huecos == null)
            return safe;

        foreach (LoopMuro h in huecos)
        {
            if (h == null || h.AreaAbs <= 1e-6)
                continue;

            UV2 puntoPrueba = PuntoInteriorSeguro(h);

            if (puntoPrueba == null ||
                !PuntoEnPoligono(
                    puntoPrueba,
                    exterior.Puntos2D))
            {
                continue;
            }

            if (!safe.Any(x => Similar(x, h)))
                safe.Add(h);
        }

        return safe;
    }

    private UV2 PuntoInteriorSeguro(
        LoopMuro loop)
    {
        if (loop == null ||
            loop.Puntos2D == null ||
            loop.Puntos2D.Count < 4)
        {
            return null;
        }

        List<UV2> pts = loop.Puntos2D
            .Take(loop.Puntos2D.Count - 1)
            .Where(p => p != null)
            .ToList();

        if (pts.Count < 3)
            return null;

        //-------------------------------------------------
        // 1) Centroide de área del polígono.
        //-------------------------------------------------
        double area2 = 0.0;
        double cx = 0.0;
        double cy = 0.0;

        for (int i = 0; i < pts.Count; i++)
        {
            UV2 a = pts[i];
            UV2 b = pts[(i + 1) % pts.Count];
            double cross = a.U * b.V - b.U * a.V;

            area2 += cross;
            cx += (a.U + b.U) * cross;
            cy += (a.V + b.V) * cross;
        }

        if (Math.Abs(area2) > 1e-12)
        {
            UV2 centroide = new UV2(
                cx / (3.0 * area2),
                cy / (3.0 * area2));

            if (PuntoEnPoligono(
                centroide,
                loop.Puntos2D))
            {
                return centroide;
            }
        }

        //-------------------------------------------------
        // 2) Centro de la caja UV.
        //-------------------------------------------------
        UV2 centroCaja = new UV2(
            (loop.MinU + loop.MaxU) / 2.0,
            (loop.MinV + loop.MaxV) / 2.0);

        if (PuntoEnPoligono(
            centroCaja,
            loop.Puntos2D))
        {
            return centroCaja;
        }

        //-------------------------------------------------
        // 3) Promedio de vértices.
        //-------------------------------------------------
        UV2 promedio = new UV2(
            pts.Average(p => p.U),
            pts.Average(p => p.V));

        if (PuntoEnPoligono(
            promedio,
            loop.Puntos2D))
        {
            return promedio;
        }

        //-------------------------------------------------
        // 4) Centro de cualquier triángulo local que quede dentro.
        //-------------------------------------------------
        for (int i = 0; i < pts.Count; i++)
        {
            UV2 a = pts[(i - 1 + pts.Count) % pts.Count];
            UV2 b = pts[i];
            UV2 c = pts[(i + 1) % pts.Count];

            UV2 candidato = new UV2(
                (a.U + b.U + c.U) / 3.0,
                (a.V + b.V + c.V) / 3.0);

            if (PuntoEnPoligono(
                candidato,
                loop.Puntos2D))
            {
                return candidato;
            }
        }

        //-------------------------------------------------
        // 5) Punto cercano a un vértice, llevado ligeramente hacia el
        // centro de caja. Para probar contención dentro de otro loop basta
        // con evitar exactamente el borde.
        //-------------------------------------------------
        foreach (UV2 p in pts)
        {
            UV2 candidato = new UV2(
                p.U * 0.995 + centroCaja.U * 0.005,
                p.V * 0.995 + centroCaja.V * 0.005);

            if (PuntoEnPoligono(
                candidato,
                loop.Puntos2D))
            {
                return candidato;
            }
        }

        return pts[0];
    }

    // =========================================================
    // RECORTE POR INTERSECCIÓN EN TODO EL ESPESOR EXTERIOR
    // =========================================================

    private ResultadoRecorteSolidos RecortarComponentePorEspesorReal(
        Document doc,
        View vista,
        Element hostElem,
        ComponenteMuro componente,
        MarcoMuro marco,
        XYZ normal,
        double espesorMuro,
        List<Solid> candidatosProcesados = null,
        double minimoAristaRegularizada = 0.0)
    {
        ResultadoRecorteSolidos resultado = new ResultadoRecorteSolidos();
        List<ComponenteMuro> huellas = new List<ComponenteMuro>();
        Dictionary<ComponenteMuro, string> origenHuellas = new Dictionary<ComponenteMuro, string>();
        bool huellasCompletas = false;
        string etapa = "preparar el perfil y el volumen exterior";
        string origenCortante = null;

        try
        {
            if (doc == null ||
                componente == null ||
                componente.Exterior == null ||
                marco == null ||
                normal == null ||
                normal.GetLength() <= TOL ||
                espesorMuro <= TOL)
            {
                return resultado;
            }

            XYZ n = normal.Normalize();
            List<LoopMuro> huecos = SanitizarHuecos(
                componente.Exterior,
                componente.Huecos);

            // Sólido temporal del paño. Se usa solo para realizar la resta y
            // recuperar su perfil 2D final; no se crea ningún elemento Revit.
            double semiPerfil = BOOLEAN_PROFILE_HALF_DEPTH;

            Solid pañoTemporal = CrearSolidoPerfil(
                componente.Exterior,
                huecos,
                n,
                semiPerfil);

            if (pañoTemporal == null || pañoTemporal.Volume <= TOL)
                throw new InvalidOperationException("No se pudo preparar el perfil de recorte.");

            // Se examina todo el espesor físico exterior, sin entrar detrás
            // de la cara anfitriona ni limitarse a una franja de 2 mm.
            Solid sonda = CrearSondaNormalDesdeComponente(
                componente.Exterior,
                huecos,
                n,
                espesorMuro);

            if (sonda == null || sonda.Volume <= TOL)
                throw new InvalidOperationException("No se pudo preparar el volumen físico.");

            Outline cajaSonda = OutlineDesdeSolidConMargen(
                sonda,
                SONDA_MARGEN_BBOX_01MM);

            if (cajaSonda == null)
                throw new InvalidOperationException("No se pudo delimitar el volumen físico.");

            // El collector solo limita candidatos. Cada sólido se recorta entre
            // los dos planos físicos del espesor, sin cruzarlo primero con el
            // perímetro de la cara: esa intersección genera aristas coincidentes
            // y láminas diminutas cuando hay uniones o separaciones de mm.
            List<Solid> candidatos = candidatosProcesados ?? SolidosVisibles(
                doc,
                vista,
                cajaSonda,
                hostElem != null
                    ? hostElem.Id
                    : ElementId.InvalidElementId);

            if (candidatos == null || candidatos.Count == 0)
                return resultado;

            bool huboCambio = false;

            foreach (Solid candidato in candidatos)
            {
                if (candidato == null || candidato.Volume <= TOL)
                    continue;

                if (FueraDeCajaPerfil(candidato, componente.Exterior))
                    continue;

                origenCortante = DescribirSolidoCortante(candidato);
                etapa = "comprobar el sólido dentro del espesor exterior";
                Solid interseccion = RecortarSolidoAlEspesor(
                    candidato,
                    sonda,
                    marco,
                    n,
                    espesorMuro);

                if (interseccion == null || interseccion.Volume <= TOL)
                    continue;

                // Cada superficie se proyecta por separado: sus huellas se
                // UNEN mediante restas sucesivas, sin inventar un convex hull
                // ni interpretar superficies a distinta profundidad como huecos.
                etapa = "proyectar la huella del sólido";
                List<ComponenteMuro> secciones = ObtenerSeccionesProyectadasDeInterseccion(
                    interseccion, marco, n, componente, minimoAristaRegularizada);

                if (secciones.Count == 0)
                    continue;

                foreach (ComponenteMuro seccion in secciones)
                {
                    if (seccion == null || seccion.Exterior == null || !LoopSeguro(seccion.Exterior))
                        throw new InvalidOperationException("La interferencia no tiene una huella válida.");

                    // Un suelo separado en UV no corta aunque su BoundingBox
                    // alcance la caja de búsqueda. No cerrar esa separación.
                    if (seccion.Exterior.MaxU <= componente.Exterior.MinU + TOL ||
                        seccion.Exterior.MinU >= componente.Exterior.MaxU - TOL ||
                        seccion.Exterior.MaxV <= componente.Exterior.MinV + TOL ||
                        seccion.Exterior.MinV >= componente.Exterior.MaxV - TOL)
                        continue;

                    // Las caras anterior/posterior suelen proyectar la misma huella.
                    // Comparar contornos reales, no solo área y caja envolvente.
                    if (!huellas.Any(x => HuellasIguales(x, seccion)))
                    {
                        huellas.Add(seccion);
                        origenHuellas[seccion] = origenCortante;
                    }
                }
            }

            huellasCompletas = true;
            etapa = "descontar las huellas del perfil";
            origenCortante = null;
            foreach (ComponenteMuro seccion in huellas)
            {
                origenCortante = origenHuellas[seccion];
                List<LoopMuro> huecosSeccion = SanitizarHuecos(
                    seccion.Exterior,
                    seccion.Huecos);

                Solid cortante = CrearSolidoPerfil(
                    seccion.Exterior,
                    huecosSeccion,
                    n,
                    semiPerfil + SOBREPASO_PERFIL);

                if (cortante == null || cortante.Volume <= TOL)
                    throw new InvalidOperationException("No se pudo preparar una huella cortante.");

                ResultadoRestaSolido resta = RestarSolidoSeguro(
                    pañoTemporal,
                    cortante,
                    n);

                // Si el perfil toca exactamente el borde del paño, Revit
                // puede considerar las caras coincidentes. Se reintenta con
                // una expansión mínima de 0.20 mm, nunca con el sólido total.
                if (resta.FalloParcial && !resta.EliminadoCompletamente)
                {
                    LoopMuro exteriorExpandido = ExpandirLoopMinimoParaBoolean(
                        seccion.Exterior,
                        SONDA_EXPANSION_02MM);

                    if (exteriorExpandido != null && LoopSeguro(exteriorExpandido))
                    {
                        Solid cortanteExpandido = CrearSolidoPerfil(
                            exteriorExpandido,
                            huecosSeccion,
                            n,
                            semiPerfil + SOBREPASO_PERFIL);

                        if (cortanteExpandido != null && cortanteExpandido.Volume > TOL)
                        {
                            resta = RestarSolidoSeguro(
                                pañoTemporal,
                                cortanteExpandido,
                                n);
                        }
                    }
                }

                if (resta.FalloParcial)
                    throw new InvalidOperationException("No se pudo descontar una interferencia.");

                if (resta.EliminadoCompletamente)
                {
                    resultado.HuboCambio = true;
                    resultado.EliminadoCompletamente = true;
                    resultado.Loops.Clear();
                    return resultado;
                }

                if (resta.HuboCambio &&
                    !resta.FalloParcial &&
                    resta.Solido != null &&
                    resta.Solido.Volume > TOL)
                {
                    pañoTemporal = resta.Solido;
                    huboCambio = true;
                }
            }

            if (!huboCambio)
                return resultado;

            etapa = "reconstruir los contornos del perfil recortado";
            origenCortante = null;
            List<PlanarFace> carasResultado = CarasExtremasPerfil(
                pañoTemporal,
                n,
                marco.Origen,
                semiPerfil);

            foreach (PlanarFace pf in carasResultado)
            {
                if (pf == null)
                    continue;

                foreach (CurveLoop cl in pf.GetEdgesAsCurveLoops())
                {
                    LoopMuro lp = LoopDesdeCurveLoop(
                        cl,
                        Transform.Identity,
                        marco);

                    if (lp == null || !LoopSeguro(lp))
                        throw new InvalidOperationException("El perfil recortado contiene segmentos no creables.");

                    if (lp != null &&
                        lp.AreaAbs > 1e-6 &&
                        !resultado.Loops.Any(x => Similar(x, lp)))
                    {
                        resultado.Loops.Add(lp);
                    }
                }
            }

            resultado.HuboCambio = true;

            if (resultado.Loops.Count == 0 ||
                ClasificarComponentes(resultado.Loops).Count == 0)
            {
                throw new InvalidOperationException("No se pudo recuperar el perfil recortado.");
            }
        }
        catch (Exception ex)
        {
            // Si todas las huellas son rectangulares, la diferencia puede
            // resolverse en 2D sin el boolean 3D ni cortes parciales de espesor.
            // Nunca se recupera el rectángulo original encima de un obstáculo.
            List<LoopMuro> rectangulos;
            // Conservar los restos rectangulares válidos del recorrido previo.
            // Si no devuelve ninguno, PolyTree distingue cobertura total de
            // piezas pequeñas omitidas; vacío por sí solo no demuestra cobertura.
            if (huellasCompletas &&
                RestarRectangulosEnPlano(componente, huellas, out rectangulos) &&
                rectangulos.Count > 0)
            {
                resultado.HuboCambio = true;
                resultado.EliminadoCompletamente = rectangulos.Count == 0;
                resultado.FalloReconstruccion = false;
                resultado.Loops = rectangulos;
                return resultado;
            }

            // Para contornos generales/oblicuos o con huecos, el respaldo
            // trabaja completamente en 2D sobre el perfil ORIGINAL y TODAS las
            // huellas. No depende de otra Difference/Intersect del kernel 3D.
            string diagnostico2D = string.Empty;
            List<LoopMuro> poligonos;
            List<ComponenteMuro> componentes2D;
            int omitidos2D;
            if (huellasCompletas && CalcularRestaPoligonosEnPlano(componente, huellas,
                out poligonos, out componentes2D, out omitidos2D, out diagnostico2D, minimoAristaRegularizada))
            {
                resultado.HuboCambio = true;
                resultado.EliminadoCompletamente = poligonos.Count == 0 && omitidos2D == 0;
                resultado.SinPerfilesCreables = poligonos.Count == 0 && omitidos2D > 0;
                resultado.CantidadPerfilesOmitidos = omitidos2D;
                resultado.Componentes2D = componentes2D;
                resultado.Diagnostico = diagnostico2D;
                resultado.FalloReconstruccion = false;
                resultado.Loops = poligonos;
                return resultado;
            }

            resultado.HuboCambio = false;
            resultado.EliminadoCompletamente = false;
            resultado.FalloReconstruccion = true;
            resultado.Diagnostico = "Etapa: " + etapa + ".\n" +
                (string.IsNullOrEmpty(origenCortante) ? string.Empty : origenCortante + "\n") +
                "Espesor de revestimiento: " + (espesorMuro * 304.8).ToString("0.###") + " mm.\n" +
                "Detalle: " + ex.Message +
                (string.IsNullOrEmpty(diagnostico2D) ? string.Empty : "\n" + diagnostico2D);
            resultado.Loops.Clear();
        }

        return resultado;
    }

    private bool HuellasIguales(ComponenteMuro a, ComponenteMuro b)
    {
        return Similar(a.Exterior, b.Exterior) &&
            a.Huecos.Count == b.Huecos.Count &&
            a.Huecos.All(h => b.Huecos.Any(x => Similar(h, x)));
    }

    // Respaldo exacto para vigas/columnas rectangulares cuando Revit no logra
    // resolver caras coincidentes. Cada resto se crea como muro rectangular;
    // no se inventa un vaciado transversal ni se rellena la interferencia.
    private bool RestarRectangulosEnPlano(
        ComponenteMuro componente,
        List<ComponenteMuro> huellas,
        out List<LoopMuro> restos)
    {
        restos = new List<LoopMuro>();
        if (componente == null || !EsRectangulo(componente.Exterior) ||
            (componente.Huecos != null && componente.Huecos.Count > 0) ||
            huellas == null || huellas.Count == 0 ||
            huellas.Any(x => x == null || !EsRectangulo(x.Exterior) ||
                (x.Huecos != null && x.Huecos.Count > 0)))
            return false;

        restos.Add(componente.Exterior);
        foreach (ComponenteMuro huella in huellas)
        {
            List<LoopMuro> siguientes = new List<LoopMuro>();
            LoopMuro corte = huella.Exterior;
            foreach (LoopMuro resto in restos)
            {
                double u0 = Math.Max(resto.MinU, corte.MinU);
                double u1 = Math.Min(resto.MaxU, corte.MaxU);
                double v0 = Math.Max(resto.MinV, corte.MinV);
                double v1 = Math.Min(resto.MaxV, corte.MaxV);
                if (u1 <= u0 || v1 <= v0)
                {
                    siguientes.Add(resto);
                    continue;
                }

                // Cuatro bandas disjuntas. Una abertura puede separar el paño
                // en varios muros; se conservan solo piezas creables por Revit.
                AgregarRestoRectangular(siguientes, resto.Marco, resto.MinU, u0, resto.MinV, resto.MaxV);
                AgregarRestoRectangular(siguientes, resto.Marco, u1, resto.MaxU, resto.MinV, resto.MaxV);
                AgregarRestoRectangular(siguientes, resto.Marco, u0, u1, resto.MinV, v0);
                AgregarRestoRectangular(siguientes, resto.Marco, u0, u1, v1, resto.MaxV);
            }
            restos = siguientes;
        }
        return true;
    }

    // Respaldo general de diferencia planar. Se ejecuta únicamente cuando ya
    // se obtuvieron TODAS las huellas: vuelve al perfil original, no al sólido
    // parcialmente descontado por los intentos 3D. No usa booleanos de Revit.
    private bool RestarPoligonosEnPlano(
        ComponenteMuro componente,
        List<ComponenteMuro> huellas,
        out List<LoopMuro> restos,
        out string diagnostico,
        double minimoArista = 0.0)
    {
        List<ComponenteMuro> componentes;
        int omitidos;
        return CalcularRestaPoligonosEnPlano(componente, huellas, out restos,
            out componentes, out omitidos, out diagnostico, minimoArista);
    }

    private bool CalcularRestaPoligonosEnPlano(
        ComponenteMuro componente,
        List<ComponenteMuro> huellas,
        out List<LoopMuro> restos,
        out List<ComponenteMuro> componentes,
        out int omitidos,
        out string diagnostico,
        double minimoArista = 0.0)
    {
        restos = new List<LoopMuro>();
        componentes = new List<ComponenteMuro>();
        omitidos = 0;
        diagnostico = string.Empty;
        try
        {
            if (componente == null || componente.Exterior == null ||
                huellas == null || huellas.Count == 0)
                throw new InvalidOperationException("Faltan el perfil original o sus huellas completas.");

            // Rejilla de 0.00003048 mm, con origen local. No amplía los cortes.
            const double escala = 10000000.0;
            double origenU = componente.Exterior.MinU;
            double origenV = componente.Exterior.MinV;
            var sujeto = new List<List<MYG_Addin.RecorteClipper.IntPoint>>();
            var cortes = new List<List<MYG_Addin.RecorteClipper.IntPoint>>();
            AgregarCaminosClipper(componente, sujeto, origenU, origenV, escala);
            foreach (ComponenteMuro huella in huellas)
                AgregarCaminosClipper(huella, cortes, origenU, origenV, escala);

            var motor = new MYG_Addin.RecorteClipper.Clipper();
            motor.StrictlySimple = true;
            if (!motor.AddPaths(sujeto, MYG_Addin.RecorteClipper.PolyType.ptSubject, true) ||
                !motor.AddPaths(cortes, MYG_Addin.RecorteClipper.PolyType.ptClip, true))
                throw new InvalidOperationException("No se pudieron registrar los contornos cerrados.");
            var salida = new MYG_Addin.RecorteClipper.PolyTree();
            // Restar la unión completa, nunca un candidato aislado ni el sólido parcial.
            if (!motor.Execute(MYG_Addin.RecorteClipper.ClipType.ctDifference, salida,
                MYG_Addin.RecorteClipper.PolyFillType.pftNonZero,
                MYG_Addin.RecorteClipper.PolyFillType.pftNonZero))
                throw new InvalidOperationException("La diferencia de polígonos no se pudo resolver.");

            List<string> avisos = new List<string>();
            double areaSalida = 0.0;
            int numeroPieza = 0;
            for (var nodo = salida.GetFirst(); nodo != null; nodo = nodo.GetNext())
            {
                areaSalida += MYG_Addin.RecorteClipper.Clipper.Area(nodo.Contour) / (escala * escala);
                if (nodo.IsHole)
                    continue;
                numeroPieza++;
                try
                {
                    ComponenteMuro pieza = CrearComponenteResultado2D(nodo,
                        componente.Exterior.Marco, origenU, origenV, escala, minimoArista);
                    componentes.Add(pieza);
                    restos.Add(pieza.Exterior);
                    restos.AddRange(pieza.Huecos);
                }
                catch (Exception ex)
                {
                    // Una arista residual o un contacto puntual no debe eliminar
                    // todo el paño. Partir SU región, incluidos TODOS sus huecos,
                    // en perfiles disjuntos; nunca volver al perfil sin recortar.
                    List<ComponenteMuro> recuperados;
                    int residuosOmitidos;
                    string detalleRecuperacion;
                    if (RecuperarPiezaPorFranjas2D(nodo, componente.Exterior.Marco,
                        origenU, origenV, escala, minimoArista,
                        out recuperados, out residuosOmitidos, out detalleRecuperacion))
                    {
                        foreach (ComponenteMuro pieza in recuperados)
                        {
                            componentes.Add(pieza);
                            restos.Add(pieza.Exterior);
                            restos.AddRange(pieza.Huecos);
                        }
                        omitidos += residuosOmitidos;
                        avisos.Add("Pieza " + numeroPieza + " recuperada en " + recuperados.Count +
                            " perfiles disjuntos. " + detalleRecuperacion);
                    }
                    else
                    {
                        omitidos++;
                        avisos.Add("Pieza " + numeroPieza + " omitida: " + ex.Message + ". " +
                            detalleRecuperacion);
                    }
                }
                // GetNext recorre también las islas anidadas: son piezas propias
                // y pueden conservarse aunque un antecesor no fuera creable.
            }

            double areaOriginal = sujeto.Sum(MYG_Addin.RecorteClipper.Clipper.Area) / (escala * escala);
            double areaRetenida = componentes.Sum(x => x.Exterior.AreaAbs - x.Huecos.Sum(h => h.AreaAbs));
            double perimetro = sujeto.Sum(camino => PerimetroCaminoClipper(camino)) / escala;
            double toleranciaArea = Math.Max(1e-8, perimetro / escala);
            if (areaSalida < -toleranciaArea || areaSalida > areaOriginal + toleranciaArea ||
                areaRetenida < -toleranciaArea || areaRetenida > areaSalida + toleranciaArea)
                throw new InvalidOperationException("La diferencia planar no conserva el área del perfil original.");
            if (avisos.Count > 0)
                diagnostico = "Respaldo 2D R2: se omitieron " + omitidos +
                    " residuos no creables; se conservaron " + componentes.Count + ".\n" + string.Join("\n", avisos);
            return true;
        }
        catch (Exception ex)
        {
            restos.Clear();
            componentes.Clear();
            omitidos = 0;
            diagnostico = "Respaldo 2D de polígonos: " + ex.Message;
            return false;
        }
    }

    private ComponenteMuro CrearComponenteResultado2D(
        MYG_Addin.RecorteClipper.PolyNode nodo, MarcoMuro marco,
        double origenU, double origenV, double escala, double minimoArista)
    {
        LoopMuro exterior = LoopDesdeCaminoClipper(nodo.Contour, marco, origenU, origenV, escala);
        string motivo;
        if (!ValidarLoopResultado2D(exterior, minimoArista, out motivo))
            throw new InvalidOperationException("contorno exterior: " + motivo);
        List<LoopMuro> huecos = new List<LoopMuro>();
        foreach (var hijo in nodo.Childs.Where(x => x.IsHole))
        {
            LoopMuro hueco = LoopDesdeCaminoClipper(hijo.Contour, marco, origenU, origenV, escala);
            if (!ValidarLoopResultado2D(hueco, minimoArista, out motivo))
                throw new InvalidOperationException("hueco " + (huecos.Count + 1) + ": " + motivo);
            // Un anillo simple puede tocar a otro y seguir siendo un boceto
            // no creable. Dividir el propietario completo, nunca borrar el hueco.
            if (LoopsResultado2DSeTocan(exterior, hueco) ||
                huecos.Any(otro => LoopsResultado2DSeTocan(otro, hueco)))
                throw new InvalidOperationException("contacto entre contornos del mismo perfil");
            huecos.Add(hueco);
        }
        return new ComponenteMuro { Exterior = exterior, Huecos = huecos };
    }

    private bool LoopsResultado2DSeTocan(LoopMuro a, LoopMuro b)
    {
        var ca = a.CaminoRecorte2D;
        var cb = b.CaminoRecorte2D;
        for (int i = 0; i < ca.Count; i++)
            for (int j = 0; j < cb.Count; j++)
                if (SegmentosResultado2DSeCruzan(ca[i], ca[(i + 1) % ca.Count],
                    cb[j], cb[(j + 1) % cb.Count]))
                    return true;
        return false;
    }

    private double AreaNodoResultado2D(MYG_Addin.RecorteClipper.PolyNode nodo, double escala)
    {
        return (Math.Abs(MYG_Addin.RecorteClipper.Clipper.Area(nodo.Contour)) -
            nodo.Childs.Where(x => x.IsHole).Sum(x =>
                Math.Abs(MYG_Addin.RecorteClipper.Clipper.Area(x.Contour)))) / (escala * escala);
    }

    private bool RecuperarPiezaPorFranjas2D(
        MYG_Addin.RecorteClipper.PolyNode nodo, MarcoMuro marco,
        double origenU, double origenV, double escala, double minimoArista,
        out List<ComponenteMuro> recuperados, out int omitidos, out string diagnostico)
    {
        recuperados = new List<ComponenteMuro>();
        omitidos = 0;
        diagnostico = string.Empty;
        double mejorArea = 0.0;
        double areaResiduoElegida = 0.0;
        string ejeElegido = string.Empty;
        List<string> errores = new List<string>();
        // Son alternativas, NO se suman: hacerlo solaparía las dos particiones.
        foreach (bool ejeU in new[] { true, false })
        {
            List<ComponenteMuro> piezas;
            int descartados;
            double area, areaResiduo;
            string detalle;
            if (!RecuperarFranjasEnEje2D(nodo, marco, origenU, origenV, escala,
                minimoArista, ejeU, out piezas, out descartados, out area, out areaResiduo, out detalle))
            {
                errores.Add(detalle);
                continue;
            }
            if (area > mejorArea || (area == mejorArea && piezas.Count < recuperados.Count))
            {
                mejorArea = area;
                recuperados = piezas;
                omitidos = descartados;
                areaResiduoElegida = areaResiduo;
                ejeElegido = ejeU ? "U" : "V";
            }
        }
        if (recuperados.Count == 0)
        {
            diagnostico = "No se recuperaron perfiles creables por franjas. " + string.Join(" | ", errores);
            return false;
        }
        diagnostico = "Partición " + ejeElegido + ": área recuperada " +
            (mejorArea * 92903.04).ToString("0.######") + " mm²; área residual omitida " +
            (areaResiduoElegida * 92903.04).ToString("0.######") + " mm².";
        return true;
    }

    private bool RecuperarFranjasEnEje2D(
        MYG_Addin.RecorteClipper.PolyNode nodo, MarcoMuro marco,
        double origenU, double origenV, double escala, double minimoArista, bool ejeU,
        out List<ComponenteMuro> piezas, out int omitidos,
        out double areaRetenida, out double areaOmitida, out string diagnostico)
    {
        piezas = new List<ComponenteMuro>();
        omitidos = 0;
        areaRetenida = 0.0;
        areaOmitida = 0.0;
        diagnostico = string.Empty;
        try
        {
            var caminos = new List<List<MYG_Addin.RecorteClipper.IntPoint>> { nodo.Contour };
            caminos.AddRange(nodo.Childs.Where(x => x.IsHole).Select(x => x.Contour));
            var vertices = caminos.SelectMany(x => x).ToList();
            long minX = vertices.Min(p => p.X), maxX = vertices.Max(p => p.X);
            long minY = vertices.Min(p => p.Y), maxY = vertices.Max(p => p.Y);
            var niveles = vertices.Select(p => ejeU ? p.X : p.Y).Distinct().OrderBy(x => x).ToList();
            // Acotar únicamente el respaldo patológico, sin cambiar los perfiles
            // que ya se crean normalmente ni bloquear Revit con miles de cortes.
            if (niveles.Count < 2 || niveles.Count > 4097)
                throw new InvalidOperationException("La partición excede el límite de 4096 franjas.");
            double areaParticion = 0.0;
            var candidatas = new List<MYG_Addin.RecorteClipper.PolyNode>();
            for (int k = 0; k < niveles.Count - 1; k++)
            {
                long x0 = ejeU ? niveles[k] : minX, x1 = ejeU ? niveles[k + 1] : maxX;
                long y0 = ejeU ? minY : niveles[k], y1 = ejeU ? maxY : niveles[k + 1];
                var banda = new List<MYG_Addin.RecorteClipper.IntPoint>
                {
                    new MYG_Addin.RecorteClipper.IntPoint(x0, y0),
                    new MYG_Addin.RecorteClipper.IntPoint(x1, y0),
                    new MYG_Addin.RecorteClipper.IntPoint(x1, y1),
                    new MYG_Addin.RecorteClipper.IntPoint(x0, y1)
                };
                var motor = new MYG_Addin.RecorteClipper.Clipper();
                motor.StrictlySimple = true;
                if (!motor.AddPaths(caminos, MYG_Addin.RecorteClipper.PolyType.ptSubject, true) ||
                    !motor.AddPath(banda, MYG_Addin.RecorteClipper.PolyType.ptClip, true))
                    throw new InvalidOperationException("No se pudo registrar una franja de recuperación.");
                var salida = new MYG_Addin.RecorteClipper.PolyTree();
                if (!motor.Execute(MYG_Addin.RecorteClipper.ClipType.ctIntersection, salida,
                    MYG_Addin.RecorteClipper.PolyFillType.pftNonZero,
                    MYG_Addin.RecorteClipper.PolyFillType.pftNonZero))
                    throw new InvalidOperationException("No se pudo intersectar una franja de recuperación.");
                for (var parte = salida.GetFirst(); parte != null; parte = parte.GetNext())
                {
                    if (parte.IsHole)
                        continue;
                    double areaParte = AreaNodoResultado2D(parte, escala);
                    areaParticion += areaParte;
                    candidatas.Add(parte);
                }
            }
            double areaOriginal = AreaNodoResultado2D(nodo, escala);
            double toleranciaArea = Math.Max(1e-8,
                4.0 * caminos.Sum(PerimetroCaminoClipper) / (escala * escala));
            // Un nivel casi coincidente puede crear una banda artificial de
            // ancho menor que ShortCurveTolerance dentro de un paño grande.
            // Conservarla hasta intentar su unión exacta con una vecina.
            RecuperarUnionesDeFranjas2D(candidatas, marco, origenU, origenV,
                escala, minimoArista, toleranciaArea);
            foreach (var parte in candidatas)
            {
                double areaParte = AreaNodoResultado2D(parte, escala);
                try
                {
                    ComponenteMuro pieza = CrearComponenteResultado2D(parte, marco,
                        origenU, origenV, escala, minimoArista);
                    piezas.Add(pieza);
                    areaRetenida += areaParte;
                }
                catch (InvalidOperationException)
                {
                    // Descartar solo el residuo que tampoco admite una unión
                    // creable; siempre junto con todos sus huecos.
                    omitidos++;
                    areaOmitida += areaParte;
                }
            }
            if (areaOriginal <= 0.0 || areaRetenida < 0.0 || areaOmitida < 0.0 ||
                Math.Abs(areaParticion - areaOriginal) > toleranciaArea ||
                Math.Abs(areaRetenida + areaOmitida - areaOriginal) > toleranciaArea)
                throw new InvalidOperationException("La partición no conserva el área de la pieza y sus huecos.");
            return true;
        }
        catch (Exception ex)
        {
            piezas.Clear();
            omitidos = 0;
            areaRetenida = areaOmitida = 0.0;
            diagnostico = "Partición " + (ejeU ? "U" : "V") + ": " + ex.Message;
            return false;
        }
    }

    private void RecuperarUnionesDeFranjas2D(
        List<MYG_Addin.RecorteClipper.PolyNode> candidatas, MarcoMuro marco,
        double origenU, double origenV, double escala, double minimoArista,
        double toleranciaArea)
    {
        // Varias bandas pueden formar un paño válido aunque ninguna unión
        // intermedia por pares suprima todas sus aristas artificiales cortas.
        RecuperarGruposDeFranjas2D(candidatas, marco, origenU, origenV,
            escala, minimoArista, toleranciaArea);
        var cajas = candidatas.Select(RecuperarCajaFranja2D).ToList();
        var areas = candidatas.Select(x => AreaNodoResultado2D(x, escala)).ToList();
        int intentos = 0;
        bool cambio = true;
        while (cambio && intentos < 4096)
        {
            cambio = false;
            for (int i = 0; i < candidatas.Count && intentos < 4096; i++)
            {
                for (int j = i + 1; j < candidatas.Count && intentos < 4096; j++)
                {
                    // Acotar también las comprobaciones de adyacencia para que
                    // un respaldo patológico no bloquee la interfaz de Revit.
                    intentos++;
                    long[] a = cajas[i], b = cajas[j];
                    if (a[1] < b[0] || b[1] < a[0] || a[3] < b[2] || b[3] < a[2])
                        continue;
                    try
                    {
                        var union = RecuperarUnionCreableDeFranjas2D(
                            new List<MYG_Addin.RecorteClipper.PolyNode> { candidatas[i], candidatas[j] },
                            marco, origenU, origenV, escala, minimoArista,
                            areas[i] + areas[j], toleranciaArea);
                        if (union == null)
                            continue;
                        double areaUnion = AreaNodoResultado2D(union, escala);
                        candidatas[i] = union;
                        candidatas.RemoveAt(j);
                        cajas[i] = RecuperarCajaFranja2D(union);
                        cajas.RemoveAt(j);
                        areas[i] = areaUnion;
                        areas.RemoveAt(j);
                        cambio = true;
                        break;
                    }
                    catch (Exception)
                    {
                        // Una unión opcional fallida no invalida la partición.
                        // Mantener ambas regiones originales, incluidos sus
                        // huecos; otra vecina todavía puede ser compatible.
                    }
                }
                if (cambio)
                    break;
            }
        }
    }

    private void RecuperarGruposDeFranjas2D(
        List<MYG_Addin.RecorteClipper.PolyNode> candidatas, MarcoMuro marco,
        double origenU, double origenV, double escala, double minimoArista,
        double toleranciaArea)
    {
        var cajas = candidatas.Select(RecuperarCajaFranja2D).ToList();
        int[] padres = Enumerable.Range(0, candidatas.Count).ToArray();
        int pares = 0, comparacionesAristas = 0;
        for (int i = 0; i < candidatas.Count && pares < 4096 && comparacionesAristas < 65536; i++)
        {
            for (int j = i + 1; j < candidatas.Count && pares < 4096 && comparacionesAristas < 65536; j++)
            {
                pares++;
                long[] a = cajas[i], b = cajas[j];
                if (a[1] < b[0] || b[1] < a[0] || a[3] < b[2] || b[3] < a[2])
                    continue;
                int raizA = RecuperarRaizGrupo2D(padres, i);
                int raizB = RecuperarRaizGrupo2D(padres, j);
                if (raizA != raizB && RecuperarCompartenArista2D(candidatas[i], candidatas[j],
                    ref comparacionesAristas))
                    padres[raizB] = raizA;
            }
        }
        var resultado = new List<MYG_Addin.RecorteClipper.PolyNode>();
        foreach (var grupo in Enumerable.Range(0, candidatas.Count)
            .GroupBy(i => RecuperarRaizGrupo2D(padres, i)))
        {
            var regiones = grupo.Select(i => candidatas[i]).ToList();
            if (regiones.Count > 1)
            {
                try
                {
                    var union = RecuperarUnionCreableDeFranjas2D(regiones, marco, origenU, origenV,
                        escala, minimoArista, regiones.Sum(x => AreaNodoResultado2D(x, escala)), toleranciaArea);
                    if (union != null)
                    {
                        resultado.Add(union);
                        continue;
                    }
                }
                catch (Exception)
                {
                    // La agrupación es opcional. Si falla, conservar todas las
                    // regiones y sus huecos para el intento por pares.
                }
            }
            resultado.AddRange(regiones);
        }
        candidatas.Clear();
        candidatas.AddRange(resultado);
    }

    private int RecuperarRaizGrupo2D(int[] padres, int indice)
    {
        while (padres[indice] != indice)
        {
            padres[indice] = padres[padres[indice]];
            indice = padres[indice];
        }
        return indice;
    }

    private bool RecuperarCompartenArista2D(
        MYG_Addin.RecorteClipper.PolyNode a, MYG_Addin.RecorteClipper.PolyNode b,
        ref int comparaciones)
    {
        var caminosA = new List<List<MYG_Addin.RecorteClipper.IntPoint>> { a.Contour };
        caminosA.AddRange(a.Childs.Where(x => x.IsHole).Select(x => x.Contour));
        var caminosB = new List<List<MYG_Addin.RecorteClipper.IntPoint>> { b.Contour };
        caminosB.AddRange(b.Childs.Where(x => x.IsHole).Select(x => x.Contour));
        foreach (var caminoA in caminosA)
            foreach (var caminoB in caminosB)
                for (int i = 0; i < caminoA.Count; i++)
                    for (int j = 0; j < caminoB.Count; j++)
                    {
                        if (comparaciones++ >= 65536)
                            return false;
                        var p = caminoA[i];
                        var q = caminoA[(i + 1) % caminoA.Count];
                        var r = caminoB[j];
                        var s = caminoB[(j + 1) % caminoB.Count];
                        if (OrientacionResultado2D(p, q, r) != 0 || OrientacionResultado2D(p, q, s) != 0)
                            continue;
                        // Una longitud estrictamente positiva conecta regiones;
                        // un único punto no debe reunir los lados de un pinch.
                        if (p.X != q.X)
                        {
                            if (Math.Min(Math.Max(p.X, q.X), Math.Max(r.X, s.X)) >
                                Math.Max(Math.Min(p.X, q.X), Math.Min(r.X, s.X)))
                                return true;
                        }
                        else if (Math.Min(Math.Max(p.Y, q.Y), Math.Max(r.Y, s.Y)) >
                            Math.Max(Math.Min(p.Y, q.Y), Math.Min(r.Y, s.Y)))
                            return true;
                    }
        return false;
    }

    private MYG_Addin.RecorteClipper.PolyNode RecuperarUnionCreableDeFranjas2D(
        List<MYG_Addin.RecorteClipper.PolyNode> regiones, MarcoMuro marco,
        double origenU, double origenV, double escala, double minimoArista,
        double areaEsperada, double toleranciaArea)
    {
        var caminos = new List<List<MYG_Addin.RecorteClipper.IntPoint>>();
        foreach (var region in regiones)
        {
            caminos.Add(region.Contour);
            caminos.AddRange(region.Childs.Where(x => x.IsHole).Select(x => x.Contour));
        }
        var motor = new MYG_Addin.RecorteClipper.Clipper();
        motor.StrictlySimple = true;
        if (!motor.AddPaths(caminos, MYG_Addin.RecorteClipper.PolyType.ptSubject, true))
            return null;
        var salida = new MYG_Addin.RecorteClipper.PolyTree();
        if (!motor.Execute(MYG_Addin.RecorteClipper.ClipType.ctUnion, salida,
            MYG_Addin.RecorteClipper.PolyFillType.pftNonZero,
            MYG_Addin.RecorteClipper.PolyFillType.pftNonZero))
            return null;
        MYG_Addin.RecorteClipper.PolyNode union = null;
        int exteriores = 0;
        for (var parte = salida.GetFirst(); parte != null; parte = parte.GetNext())
        {
            if (parte.IsHole)
                continue;
            exteriores++;
            union = parte;
        }
        if (exteriores != 1 || union == null ||
            Math.Abs(AreaNodoResultado2D(union, escala) - areaEsperada) > toleranciaArea)
            return null;
        // No aceptar una unión que recree el contacto original, una arista corta
        // o un hueco no representable, aunque su área coincida.
        CrearComponenteResultado2D(union, marco, origenU, origenV, escala, minimoArista);
        return union;
    }

    private long[] RecuperarCajaFranja2D(MYG_Addin.RecorteClipper.PolyNode nodo)
    {
        return new[]
        {
            nodo.Contour.Min(p => p.X), nodo.Contour.Max(p => p.X),
            nodo.Contour.Min(p => p.Y), nodo.Contour.Max(p => p.Y)
        };
    }

    private bool ValidarLoopResultado2D(LoopMuro loop, double minimoArista, out string motivo)
    {
        motivo = string.Empty;
        if (loop == null || loop.Puntos2D == null || loop.Puntos2D.Count < 4)
        {
            motivo = "menos de tres vértices";
            return false;
        }
        if (loop.Puntos2D.Any(p => p == null || double.IsNaN(p.U) || double.IsInfinity(p.U) ||
            double.IsNaN(p.V) || double.IsInfinity(p.V)))
        {
            motivo = "coordenadas no finitas";
            return false;
        }
        if (Dist2D(loop.Puntos2D[0], loop.Puntos2D[loop.Puntos2D.Count - 1]) > TOL)
        {
            motivo = "contorno abierto";
            return false;
        }
        double area = AreaAbs(loop.Puntos2D);
        if (area <= 1e-6)
        {
            motivo = "área de " + (area * 92903.04).ToString("0.######") + " mm² demasiado pequeña";
            return false;
        }
        double minimo = Math.Max(PTOL, minimoArista);
        int segmentos = loop.Puntos2D.Count - 1;
        // Estos loops provienen de Clipper. Conservar sus enteros originales:
        // TOL (1e-6 pies) es diez veces su rejilla y convertía separaciones
        // reales en contactos, descartando una pieza completa por proximidad.
        // La tolerancia de creación sigue aplicándose a las longitudes.
        var camino = loop.CaminoRecorte2D;
        if (camino == null || camino.Count != segmentos)
        {
            motivo = "no se conservó el contorno entero del recorte 2D";
            return false;
        }
        for (int i = 0; i < segmentos; i++)
        {
            double longitud = Dist2D(loop.Puntos2D[i], loop.Puntos2D[i + 1]);
            if (longitud <= minimo)
            {
                motivo = "arista " + (i + 1) + " de " + (longitud * 304.8).ToString("0.######") +
                    " mm (mínimo " + (minimo * 304.8).ToString("0.######") + " mm)";
                return false;
            }
            for (int j = i + 1; j < segmentos; j++)
            {
                if (j == i + 1 || (i == 0 && j == segmentos - 1))
                    continue;
                if (SegmentosResultado2DSeCruzan(camino[i], camino[(i + 1) % segmentos],
                    camino[j], camino[(j + 1) % segmentos]))
                {
                    motivo = "las aristas " + (i + 1) + " y " + (j + 1) + " se cruzan o tocan";
                    return false;
                }
            }
        }
        return true;
    }

    private bool SegmentosResultado2DSeCruzan(
        MYG_Addin.RecorteClipper.IntPoint a, MYG_Addin.RecorteClipper.IntPoint b,
        MYG_Addin.RecorteClipper.IntPoint c, MYG_Addin.RecorteClipper.IntPoint d)
    {
        int o1 = OrientacionResultado2D(a, b, c), o2 = OrientacionResultado2D(a, b, d);
        int o3 = OrientacionResultado2D(c, d, a), o4 = OrientacionResultado2D(c, d, b);
        if (o1 * o2 < 0 && o3 * o4 < 0)
            return true;
        return (o1 == 0 && PuntoEnSegmentoResultado2D(c, a, b)) ||
            (o2 == 0 && PuntoEnSegmentoResultado2D(d, a, b)) ||
            (o3 == 0 && PuntoEnSegmentoResultado2D(a, c, d)) ||
            (o4 == 0 && PuntoEnSegmentoResultado2D(b, c, d));
    }

    private int OrientacionResultado2D(
        MYG_Addin.RecorteClipper.IntPoint a, MYG_Addin.RecorteClipper.IntPoint b,
        MYG_Addin.RecorteClipper.IntPoint c)
    {
        // Las coordenadas admitidas llegan a 1e14: multiplicar Int64 puede
        // desbordar y double pierde el signo en segmentos casi colineales.
        // System.Numerics ya es una referencia del proyecto.
        System.Numerics.BigInteger abx = (System.Numerics.BigInteger)b.X - a.X;
        System.Numerics.BigInteger aby = (System.Numerics.BigInteger)b.Y - a.Y;
        System.Numerics.BigInteger acx = (System.Numerics.BigInteger)c.X - a.X;
        System.Numerics.BigInteger acy = (System.Numerics.BigInteger)c.Y - a.Y;
        return (abx * acy - aby * acx).Sign;
    }

    private bool PuntoEnSegmentoResultado2D(
        MYG_Addin.RecorteClipper.IntPoint p, MYG_Addin.RecorteClipper.IntPoint a,
        MYG_Addin.RecorteClipper.IntPoint b)
    {
        // Solo se llama después de demostrar colinealidad exacta.
        return p.X >= Math.Min(a.X, b.X) && p.X <= Math.Max(a.X, b.X) &&
            p.Y >= Math.Min(a.Y, b.Y) && p.Y <= Math.Max(a.Y, b.Y);
    }

    private void AgregarCaminosClipper(
        ComponenteMuro componente,
        List<List<MYG_Addin.RecorteClipper.IntPoint>> caminos,
        double origenU, double origenV, double escala)
    {
        if (componente == null || !LoopSeguro(componente.Exterior))
            throw new InvalidOperationException("Un contorno original o de interferencia no es válido.");
        var exterior = CaminoClipperParaLoop(componente.Exterior, true, origenU, origenV, escala);
        caminos.Add(exterior);
        if (componente.Huecos == null)
            return;
        var huecosRegistrados = new List<LoopMuro>();
        foreach (LoopMuro hueco in componente.Huecos)
        {
            if (!LoopSeguro(hueco))
                throw new InvalidOperationException("Un hueco de entrada no es válido; no se puede omitir.");
            var interior = CaminoClipperParaLoop(hueco, false, origenU, origenV, escala);
            // Cada hueco debe pertenecer al exterior de su propio componente.
            if (interior.Any(p => MYG_Addin.RecorteClipper.Clipper.PointInPolygon(p, exterior) != 1))
                throw new InvalidOperationException("Un hueco toca o sale del contorno de entrada.");
            // Vértices interiores no bastan para un exterior cóncavo: una
            // arista puede cruzar su mordida. Tampoco se permiten huecos del
            // mismo componente solapados/anidados, que alterarían NonZero.
            if (LoopsSeTocanOCruzan(componente.Exterior, hueco, false) ||
                huecosRegistrados.Any(otro => LoopsSeTocanOCruzan(otro, hueco, false) ||
                    PuntoEnPoligono(hueco.Puntos2D[0], otro.Puntos2D) ||
                    PuntoEnPoligono(otro.Puntos2D[0], hueco.Puntos2D)))
                throw new InvalidOperationException("Los huecos de entrada se cruzan, se solapan o tocan su exterior.");
            caminos.Add(interior);
            huecosRegistrados.Add(hueco);
        }
    }

    private List<MYG_Addin.RecorteClipper.IntPoint> CaminoClipperParaLoop(
        LoopMuro loop, bool exterior, double origenU, double origenV, double escala)
    {
        if (loop.Puntos2D.Count < 4 ||
            Dist2D(loop.Puntos2D[0], loop.Puntos2D[loop.Puntos2D.Count - 1]) > TOL)
            throw new InvalidOperationException("Un contorno de entrada no está cerrado.");
        var camino = new List<MYG_Addin.RecorteClipper.IntPoint>();
        for (int i = 0; i < loop.Puntos2D.Count - 1; i++)
        {
            UV2 p = loop.Puntos2D[i];
            double x = (p.U - origenU) * escala;
            double y = (p.V - origenV) * escala;
            // Mantener lejos del límite de Int64 y de coordenadas donde la
            // intersección interna del motor pierde precisión significativa.
            if (double.IsNaN(x) || double.IsInfinity(x) || Math.Abs(x) > 1e14 ||
                double.IsNaN(y) || double.IsInfinity(y) || Math.Abs(y) > 1e14)
                throw new InvalidOperationException("Coordenadas fuera del rango seguro de recorte 2D.");
            var punto = new MYG_Addin.RecorteClipper.IntPoint(
                (long)Math.Round(x, MidpointRounding.AwayFromZero),
                (long)Math.Round(y, MidpointRounding.AwayFromZero));
            if (camino.Count > 0 && camino[camino.Count - 1] == punto)
                throw new InvalidOperationException("La cuantización colapsó una arista del contorno.");
            camino.Add(punto);
        }
        if (camino.Count < 3 || camino[0] == camino[camino.Count - 1] ||
            Math.Abs(MYG_Addin.RecorteClipper.Clipper.Area(camino)) < 1.0)
            throw new InvalidOperationException("El contorno no admite una representación entera cerrada.");
        if (MYG_Addin.RecorteClipper.Clipper.Orientation(camino) != exterior)
            camino.Reverse();
        return camino;
    }

    private LoopMuro LoopDesdeCaminoClipper(
        List<MYG_Addin.RecorteClipper.IntPoint> camino,
        MarcoMuro marco, double origenU, double origenV, double escala)
    {
        if (camino == null || camino.Count < 3 || marco == null)
            throw new InvalidOperationException("El recorte devolvió un contorno incompleto.");
        camino = QuitarVerticesRedundantes2D(camino);
        List<UV2> puntos = camino.Select(p => new UV2(
            origenU + p.X / escala, origenV + p.Y / escala)).ToList();
        puntos.Add(new UV2(puntos[0].U, puntos[0].V));
        // No usar Limpiar/LoopDesdeUV: eliminan aristas cortas y podrían
        // rellenar un hueco o cambiar una isla. Aquí se conserva o se rechaza.
        double area = Area(puntos);
        return new LoopMuro
        {
            Marco = marco,
            CaminoRecorte2D = camino,
            Puntos2D = puntos,
            Puntos3D = puntos.Select(p => marco.Origen + marco.U.Multiply(p.U) + marco.V.Multiply(p.V)).ToList(),
            Area = area,
            AreaAbs = Math.Abs(area),
            MinU = puntos.Min(p => p.U), MaxU = puntos.Max(p => p.U),
            MinV = puntos.Min(p => p.V), MaxV = puntos.Max(p => p.V)
        };
    }

    private List<MYG_Addin.RecorteClipper.IntPoint> QuitarVerticesRedundantes2D(
        List<MYG_Addin.RecorteClipper.IntPoint> original)
    {
        var puntos = new List<MYG_Addin.RecorteClipper.IntPoint>();
        foreach (var punto in original)
            if (puntos.Count == 0 || puntos[puntos.Count - 1] != punto)
                puntos.Add(punto);
        if (puntos.Count > 1 && puntos[0] == puntos[puntos.Count - 1])
            puntos.RemoveAt(puntos.Count - 1);
        bool cambio = true;
        while (cambio && puntos.Count > 3)
        {
            cambio = false;
            for (int i = 0; i < puntos.Count; i++)
            {
                var a = puntos[(i + puntos.Count - 1) % puntos.Count];
                var b = puntos[i];
                var c = puntos[(i + 1) % puntos.Count];
                try
                {
                    decimal abx = (decimal)b.X - a.X, aby = (decimal)b.Y - a.Y;
                    decimal bcx = (decimal)c.X - b.X, bcy = (decimal)c.Y - b.Y;
                    // Enteros + decimal: eliminar solo un punto exactamente
                    // colineal situado entre sus vecinos, nunca una mordida.
                    if (abx * bcy - aby * bcx == 0 && abx * bcx + aby * bcy >= 0)
                    {
                        puntos.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
                catch (OverflowException)
                {
                    // Si no se puede demostrar redundancia exacta, conservar.
                }
            }
        }
        return puntos;
    }

    private double PerimetroCaminoClipper(List<MYG_Addin.RecorteClipper.IntPoint> camino)
    {
        double longitud = 0.0;
        for (int i = 0; i < camino.Count; i++)
        {
            var a = camino[i];
            var b = camino[(i + 1) % camino.Count];
            double dx = (double)b.X - a.X, dy = (double)b.Y - a.Y;
            longitud += Math.Sqrt(dx * dx + dy * dy);
        }
        return longitud;
    }

    private void AgregarRestoRectangular(
        List<LoopMuro> restos, MarcoMuro marco,
        double minU, double maxU, double minV, double maxV)
    {
        if (maxU - minU <= PTOL || maxV - minV <= PTOL)
            return;

        LoopMuro rectangulo = LoopDesdeUV(new List<UV2>
        {
            new UV2(minU, minV), new UV2(maxU, minV),
            new UV2(maxU, maxV), new UV2(minU, maxV), new UV2(minU, minV)
        }, marco);
        if (rectangulo != null && LoopSeguro(rectangulo))
            restos.Add(rectangulo);
    }

    private List<PlanarFace> CarasExtremasPerfil(
        Solid solido, XYZ normal, XYZ origen, double semiPerfil)
    {
        XYZ n = normal.Normalize();
        List<PlanarFace> positivas = new List<PlanarFace>();
        List<PlanarFace> negativas = new List<PlanarFace>();
        foreach (Face cara in solido.Faces)
        {
            PlanarFace plana = cara as PlanarFace;
            if (plana == null || plana.Area <= 1e-8)
                continue;
            double alineacion = plana.FaceNormal.Normalize().DotProduct(n);
            double distancia = (plana.Origin - origen).DotProduct(n);
            if (alineacion > 1.0 - 1e-6 && Math.Abs(distancia - semiPerfil) <= TOL)
                positivas.Add(plana);
            else if (alineacion < -1.0 + 1e-6 && Math.Abs(distancia + semiPerfil) <= TOL)
                negativas.Add(plana);
        }
        // Un único extremo exacto incluye todas las islas y sus huecos. Mezclar
        // planos interiores o elegir el de mayor área puede devolver el paño sin cortar.
        return positivas.Count > 0 ? positivas : negativas;
    }

    private Solid CrearSondaNormalDesdeComponente(
        LoopMuro exterior,
        List<LoopMuro> huecos,
        XYZ normal,
        double espesorMuro)
    {
        try
        {
            if (exterior == null ||
                normal == null ||
                normal.GetLength() <= TOL ||
                espesorMuro <= TOL)
            {
                return null;
            }

            XYZ n = normal.Normalize();

            // El marco está a medio espesor fuera de la cara original.
            // El volumen de búsqueda ocupa exactamente [cara, cara + espesor].
            // Un sólido solamente detrás o tangente no tiene volumen común.
            double trasladoInicio = -(espesorMuro / 2.0);
            double profundidadSonda = espesorMuro;

            Transform moverInicio = Transform.CreateTranslation(
                n.Multiply(trasladoInicio));

            List<CurveLoop> perfiles = new List<CurveLoop>();

            CurveLoop exteriorSonda = CurveLoopDesdeLoop(
                exterior,
                true,
                moverInicio);

            if (exteriorSonda == null || exteriorSonda.IsOpen())
                return null;

            perfiles.Add(exteriorSonda);

            if (huecos != null)
            {
                foreach (LoopMuro hueco in huecos)
                {
                    if (hueco == null || !LoopSeguro(hueco))
                        continue;

                    CurveLoop loopHueco = CurveLoopDesdeLoop(
                        hueco,
                        false,
                        moverInicio);

                    if (loopHueco != null && !loopHueco.IsOpen())
                        perfiles.Add(loopHueco);
                }
            }

            return GeometryCreationUtilities.CreateExtrusionGeometry(
                perfiles,
                n,
                profundidadSonda);
        }
        catch
        {
            return null;
        }
    }

    private Outline OutlineDesdeSolidConMargen(
        Solid solid,
        double margen)
    {
        try
        {
            if (solid == null)
                return null;

            BoundingBoxXYZ bb = solid.GetBoundingBox();

            if (bb == null)
                return null;

            Transform tr = bb.Transform ?? Transform.Identity;
            XYZ mn = bb.Min;
            XYZ mx = bb.Max;

            List<XYZ> puntos = new List<XYZ>()
            {
                tr.OfPoint(new XYZ(mn.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mx.Z))
            };

            margen = Math.Max(0.0, margen);

            return new Outline(
                new XYZ(
                    puntos.Min(p => p.X) - margen,
                    puntos.Min(p => p.Y) - margen,
                    puntos.Min(p => p.Z) - margen),
                new XYZ(
                    puntos.Max(p => p.X) + margen,
                    puntos.Max(p => p.Y) + margen,
                    puntos.Max(p => p.Z) + margen));
        }
        catch
        {
            return null;
        }
    }

    private bool FueraDeCajaPerfil(Solid candidato, LoopMuro perfil)
    {
        double min, max;
        if (RangoSolidoRespectoPlano(candidato, perfil.Marco.Origen, perfil.Marco.U, out min, out max) &&
            (max <= perfil.MinU + TOL || min >= perfil.MaxU - TOL))
            return true;
        if (RangoSolidoRespectoPlano(candidato, perfil.Marco.Origen, perfil.Marco.V, out min, out max) &&
            (max <= perfil.MinV + TOL || min >= perfil.MaxV - TOL))
            return true;
        return false;
    }

    private Solid RecortarSolidoAlEspesor(
        Solid candidato, Solid sonda, MarcoMuro marco, XYZ normal, double espesor)
    {
        XYZ n = normal.Normalize();
        double inicio = -espesor / 2.0;
        double fin = espesor / 2.0;
        try
        {
            double min, max;
            if (!RangoSolidoRespectoPlano(candidato, marco.Origen, n, out min, out max))
                throw new InvalidOperationException("No se pudo delimitar el sólido cortante.");

            // No proyectar un sólido detrás, tangente o más allá del espesor.
            // TOL es numérica (0.0003 mm), no un margen que cierre huecos de mm.
            if (max <= inicio + TOL || min >= fin - TOL)
                return null;

            Solid recortado = candidato;
            if (min < inicio)
                recortado = BooleanOperationsUtils.CutWithHalfSpace(recortado,
                    Plane.CreateByNormalAndOrigin(n, marco.Origen + n.Multiply(inicio)));
            if (recortado == null || recortado.Volume <= TOL)
                return null;
            if (max > fin)
                recortado = BooleanOperationsUtils.CutWithHalfSpace(recortado,
                    Plane.CreateByNormalAndOrigin(n.Negate(), marco.Origen + n.Multiply(fin)));

            // CutWithHalfSpace devuelve una copia; no modificar los sólidos
            // cacheados ni desunir/mover los elementos del modelo para medirlos.
            return recortado != null && recortado.Volume > TOL ? recortado : null;
        }
        catch (Exception ex)
        {
            // Alternativa con el volumen exacto de la cara. Un fallo no se
            // interpreta como separación ni permite crear encima del sólido.
            bool fallo;
            Solid interseccion = InterseccionConSondaSegura(sonda, candidato, out fallo);
            if (fallo)
                throw new InvalidOperationException(
                    "Revit no pudo evaluar el sólido con planos ni con el volumen de la cara. " + ex.Message, ex);
            return interseccion;
        }
    }

    private Solid InterseccionConSondaSegura(
        Solid sonda,
        Solid candidato,
        out bool fallo)
    {
        fallo = false;
        try
        {
            if (sonda == null || candidato == null)
                return null;

            return BooleanOperationsUtils.ExecuteBooleanOperation(
                sonda,
                candidato,
                BooleanOperationsType.Intersect);
        }
        catch
        {
            fallo = true;
            return null;
        }
    }

    private List<ComponenteMuro> ObtenerSeccionesProyectadasDeInterseccion(
        Solid interseccion,
        MarcoMuro marco,
        XYZ normal,
        ComponenteMuro limitePerfil,
        double minimoAristaRegularizada = 0.0)
    {
        List<ComponenteMuro> secciones = new List<ComponenteMuro>();
        List<List<UV2>> laminas = new List<List<UV2>>();
        bool todasProyeccionesFuera = true;
        XYZ n = normal.Normalize();

        foreach (Face cara in interseccion.Faces)
        {
            PlanarFace plana = cara as PlanarFace;
            if (plana != null)
            {
                if (CaraPlanarFueraDePerfil(plana, marco, limitePerfil.Exterior))
                    continue;
                // Una superficie paralela a la dirección de proyección tiene
                // área proyectada nula y no aporta huella.
                if (Math.Abs(plana.FaceNormal.Normalize().DotProduct(n)) <= 1e-8)
                    continue;

                List<LoopMuro> loopsCara = new List<LoopMuro>();
                bool perfilValido = true;
                try
                {
                    foreach (CurveLoop contorno in plana.GetEdgesAsCurveLoops())
                    {
                        LoopMuro loop = LoopDesdeCurveLoop(contorno, Transform.Identity, marco);
                        if (loop == null || !LoopSeguro(loop))
                        {
                            perfilValido = false;
                            break;
                        }
                        loopsCara.Add(loop);
                    }
                }
                catch { perfilValido = false; }

                if (perfilValido && loopsCara.Count > 0)
                {
                    List<ComponenteMuro> componentes = ClasificarComponentes(loopsCara);
                    if (componentes.Count > 0)
                    {
                        todasProyeccionesFuera = false;
                        foreach (ComponenteMuro componente in componentes)
                            if (!secciones.Any(x => HuellasIguales(x, componente)))
                                secciones.Add(componente);
                        continue;
                    }
                }
            }

            // Para caras curvas (o contornos que no admiten un perfil seguro),
            // proyectar sus triángulos mantiene concavidades e islas separadas.
            // No se reemplaza el volumen por su caja o envolvente convexa.
            Mesh malla = cara.Triangulate();
            if (malla == null || malla.NumTriangles == 0)
                throw new InvalidOperationException("No se pudo triangular una cara del sólido cortante.");
            for (int i = 0; i < malla.NumTriangles; i++)
            {
                MeshTriangle triangulo = malla.get_Triangle(i);
                List<XYZ> puntos = new List<XYZ>();
                for (int j = 0; j < 3; j++)
                    puntos.Add(triangulo.get_Vertex(j));

                if (ProyeccionFueraDePerfil(puntos, marco, limitePerfil.Exterior))
                    continue;

                double areaProyectada = Math.Abs(
                    (puntos[1] - puntos[0]).CrossProduct(puntos[2] - puntos[0]).DotProduct(n)) / 2.0;
                if (areaProyectada <= 1e-8)
                    continue;

                // Una triangulación de geometría unida puede proyectar láminas
                // menores que la tolerancia. Se reúnen antes de comprobar si
                // otra huella las cubre o si necesitan regularización local.
                List<UV2> uv = puntos.Select(p => new UV2(
                    (p - marco.Origen).DotProduct(marco.U),
                    (p - marco.Origen).DotProduct(marco.V))).ToList();
                // Probar el triángulo ORIGINAL antes de regularizarlo. Una caja
                // ampliada no debe inventar un cortante al otro lado de un hueco.
                if (!LaminaAlcanzaPerfil(uv, limitePerfil))
                    continue;
                todasProyeccionesFuera = false;
                double ladoMayor = Math.Max(Dist2D(uv[0], uv[1]),
                    Math.Max(Dist2D(uv[1], uv[2]), Dist2D(uv[2], uv[0])));
                if (2.0 * areaProyectada <= PTOL * ladoMayor)
                {
                    laminas.Add(uv);
                    continue;
                }

                LoopMuro loop = LoopDesdePuntosPlanos(puntos, marco);
                if (loop == null || !LoopSeguro(loop))
                    throw new InvalidOperationException("La huella contiene segmentos no admitidos por Revit.");

                ComponenteMuro seccion = new ComponenteMuro
                {
                    Exterior = loop,
                    Huecos = new List<LoopMuro>()
                };
                if (!secciones.Any(x => HuellasIguales(x, seccion)))
                    secciones.Add(seccion);
            }
        }

        foreach (List<UV2> lamina in laminas)
        {
            // Usar el área real para perfiles cóncavos/con huecos; la prueba
            // rápida por vértices solo es válida para contornos convexos.
            if (secciones.Any(x => LaminaCubiertaPorSeccion(lamina, x)))
                continue;

            LoopMuro regularizada = CrearHuellaLaminaRepresentable(lamina, marco, minimoAristaRegularizada);
            if (regularizada == null || !LoopSeguro(regularizada))
                throw new InvalidOperationException("No se pudo regularizar una huella menor que la tolerancia de Revit.");

            // Solo se amplía la caja ORIENTADA de este triángulo, nunca la
            // envolvente de la viga completa. Se conserva todo el obstáculo a
            // costa de un pequeño recorte adicional del revestimiento.
            secciones.Add(new ComponenteMuro
            {
                Exterior = regularizada,
                Huecos = new List<LoopMuro>()
            });
        }
        if (secciones.Count == 0 && !todasProyeccionesFuera)
            throw new InvalidOperationException("No se pudo reconstruir la huella de la interferencia.");
        return secciones;
    }

    private bool LaminaAlcanzaPerfil(List<UV2> lamina, ComponenteMuro perfil)
    {
        return AreaPerfilDentroDeTriangulo(lamina, perfil) > TOL * TOL;
    }

    private bool LaminaCubiertaPorSeccion(List<UV2> lamina, ComponenteMuro seccion)
    {
        if (LaminaCubiertaPorSeccionConvexa(lamina, seccion))
            return true;
        double areaTriangulo = Math.Abs(Orient2D(lamina[0], lamina[1], lamina[2])) / 2.0;
        return areaTriangulo > TOL * TOL &&
            Math.Abs(AreaPerfilDentroDeTriangulo(lamina, seccion) - areaTriangulo) <= TOL * TOL;
    }

    private double AreaPerfilDentroDeTriangulo(List<UV2> lamina, ComponenteMuro perfil)
    {
        double area = AreaContornoDentroDeTriangulo(perfil.Exterior.Puntos2D, lamina);
        if (perfil.Huecos != null)
            foreach (LoopMuro hueco in perfil.Huecos)
                area -= AreaContornoDentroDeTriangulo(hueco.Puntos2D, lamina);
        return area;
    }

    private double AreaContornoDentroDeTriangulo(List<UV2> contorno, List<UV2> triangulo)
    {
        // Recorte puramente numérico por tres semiplanos (Sutherland-Hodgman).
        // No crea curvas Revit: admite aristas menores que ShortCurveTolerance.
        // Para contornos cóncavos la frontera puede volver sobre la línea de
        // corte; esas conexiones tienen área firmada nula. Restar los huecos
        // por separado evita confundir una cavidad con una interferencia real.
        UV2 origen = triangulo[0];
        List<UV2> salida = contorno.Take(contorno.Count - 1)
            .Select(p => new UV2(p.U - origen.U, p.V - origen.V)).ToList();
        List<UV2> t = triangulo.Select(p => new UV2(p.U - origen.U, p.V - origen.V)).ToList();
        double sentido = Math.Sign(Orient2D(t[0], t[1], t[2]));
        if (sentido == 0.0)
            return 0.0;
        for (int lado = 0; lado < 3 && salida.Count > 0; lado++)
        {
            UV2 a = t[lado], b = t[(lado + 1) % 3];
            double longitud = Dist2D(a, b);
            if (longitud <= 0.0)
                return 0.0;
            List<UV2> entrada = salida;
            salida = new List<UV2>();
            UV2 anterior = entrada[entrada.Count - 1];
            double dAnterior = sentido * Orient2D(a, b, anterior) / longitud;
            foreach (UV2 actual in entrada)
            {
                double dActual = sentido * Orient2D(a, b, actual) / longitud;
                if ((dActual >= 0.0) != (dAnterior >= 0.0))
                {
                    double fraccion = dAnterior / (dAnterior - dActual);
                    salida.Add(new UV2(anterior.U + (actual.U - anterior.U) * fraccion,
                        anterior.V + (actual.V - anterior.V) * fraccion));
                }
                if (dActual >= 0.0)
                    salida.Add(actual);
                anterior = actual;
                dAnterior = dActual;
            }
        }
        double area2 = 0.0;
        for (int i = 0; i < salida.Count; i++)
        {
            UV2 a = salida[i], b = salida[(i + 1) % salida.Count];
            area2 += a.U * b.V - b.U * a.V;
        }
        return Math.Abs(area2) / 2.0;
    }

    private bool LaminaCubiertaPorSeccionConvexa(List<UV2> lamina, ComponenteMuro seccion)
    {
        if (lamina == null || lamina.Count != 3 || seccion == null ||
            seccion.Exterior == null || seccion.Exterior.Puntos2D == null ||
            (seccion.Huecos != null && seccion.Huecos.Count > 0))
            return false;

        List<UV2> contorno = seccion.Exterior.Puntos2D;
        int cantidad = contorno.Count - 1;
        double sentido = Math.Sign(seccion.Exterior.Area);
        if (cantidad < 3 || sentido == 0.0)
            return false;

        for (int i = 0; i < cantidad; i++)
        {
            UV2 a = contorno[i];
            UV2 b = contorno[i + 1];
            double longitud = Dist2D(a, b);
            if (longitud <= TOL)
                return false;
            // Verificar convexidad y pertenencia en semiplanos, usando solo
            // tolerancia numérica; PTOL no debe ocultar una interferencia real.
            if (contorno.Take(cantidad).Any(p => sentido * Orient2D(a, b, p) / longitud < -TOL) ||
                lamina.Any(p => sentido * Orient2D(a, b, p) / longitud < -TOL))
                return false;
        }
        return true;
    }

    private LoopMuro CrearHuellaLaminaRepresentable(
        List<UV2> lamina, MarcoMuro marco, double minimoArista = 0.0)
    {
        if (lamina == null || lamina.Count != 3 || marco == null)
            return null;

        int inicio = 0, fin = 1;
        double longitud = Dist2D(lamina[0], lamina[1]);
        for (int i = 0; i < 3; i++)
            for (int j = i + 1; j < 3; j++)
                if (Dist2D(lamina[i], lamina[j]) > longitud)
                {
                    inicio = i;
                    fin = j;
                    longitud = Dist2D(lamina[i], lamina[j]);
                }
        if (longitud <= TOL)
            return null;

        UV2 origen = lamina[inicio];
        double tu = (lamina[fin].U - origen.U) / longitud;
        double tv = (lamina[fin].V - origen.V) / longitud;
        List<double> t = lamina.Select(p => (p.U - origen.U) * tu + (p.V - origen.V) * tv).ToList();
        List<double> q = lamina.Select(p => -(p.U - origen.U) * tv + (p.V - origen.V) * tu).ToList();
        double minT = t.Min(), maxT = t.Max(), minQ = q.Min(), maxQ = q.Max();
        double minimo = Math.Max(1.1 * PTOL, minimoArista);
        // Para pendientes extremas, no convertir una lámina en un recorte
        // grande para intentar hacerla creable: mantener el fallo explícito.
        if (double.IsNaN(minimo) || double.IsInfinity(minimo) || minimo > 2.0 * PTOL)
            throw new InvalidOperationException(
                "La inclinación exige ampliar una huella estrecha más allá del límite local de " +
                (2.0 * PTOL * 304.8).ToString("0.###") + " mm. No se aplica ese recorte excesivo.");
        double margenT = Math.Max(0.0, (minimo - (maxT - minT)) / 2.0);
        double margenQ = Math.Max(0.0, (minimo - (maxQ - minQ)) / 2.0);
        minT -= margenT; maxT += margenT;
        minQ -= margenQ; maxQ += margenQ;

        List<UV2> rectangulo = new List<UV2>();
        foreach (UV2 esquina in new[]
        {
            new UV2(minT, minQ), new UV2(maxT, minQ),
            new UV2(maxT, maxQ), new UV2(minT, maxQ), new UV2(minT, minQ)
        })
            rectangulo.Add(new UV2(origen.U + tu * esquina.U - tv * esquina.V,
                origen.V + tv * esquina.U + tu * esquina.V));
        return LoopDesdeUV(rectangulo, marco);
    }

    private bool CaraPlanarFueraDePerfil(PlanarFace cara, MarcoMuro marco, LoopMuro perfil)
    {
        try
        {
            BoundingBoxUV caja = cara.GetBoundingBox();
            // La parametrización de una cara plana es afín: las cuatro
            // esquinas de su caja UV acotan toda la cara, también con arcos.
            return ProyeccionFueraDePerfil(new List<XYZ>
            {
                cara.Evaluate(new UV(caja.Min.U, caja.Min.V)),
                cara.Evaluate(new UV(caja.Min.U, caja.Max.V)),
                cara.Evaluate(new UV(caja.Max.U, caja.Min.V)),
                cara.Evaluate(new UV(caja.Max.U, caja.Max.V))
            }, marco, perfil);
        }
        catch { return false; }
    }

    private bool ProyeccionFueraDePerfil(IEnumerable<XYZ> puntos, MarcoMuro marco, LoopMuro perfil)
    {
        List<UV2> uv = puntos.Select(p => new UV2(
            (p - marco.Origen).DotProduct(marco.U),
            (p - marco.Origen).DotProduct(marco.V))).ToList();
        return uv.Count > 0 &&
            (uv.Max(p => p.U) <= perfil.MinU + TOL || uv.Min(p => p.U) >= perfil.MaxU - TOL ||
             uv.Max(p => p.V) <= perfil.MinV + TOL || uv.Min(p => p.V) >= perfil.MaxV - TOL);
    }

    private bool CurvoLibreDeInterferencias(
        Document doc, View vista, Element hostElem, Wall muro)
    {
        bool agregado = _idsCreadosDuranteLote.Add(muro.Id);
        try
        {
            List<Solid> volumenes = SolidosElemento(muro, null, Transform.Identity);
            if (volumenes.Count == 0) return false;
            foreach (Solid volumen in volumenes)
            {
                Outline caja = OutlineDesdeSolidConMargen(volumen, SONDA_MARGEN_BBOX_01MM);
                if (caja == null) return false;
                foreach (Solid candidato in SolidosVisibles(doc, vista, caja,
                    hostElem != null ? hostElem.Id : ElementId.InvalidElementId))
                {
                    bool fallo;
                    Solid interseccion = InterseccionConSondaSegura(volumen, candidato, out fallo);
                    if (fallo || (interseccion != null && interseccion.Volume > TOL))
                        return false;
                }
            }
            return true;
        }
        catch { return false; }
        finally
        {
            // Excluir el muro en comprobación antes del Commit evita autocortarlo.
            if (agregado) _idsCreadosDuranteLote.Remove(muro.Id);
        }
    }

    private void AvisarRecorteNoResuelto(string diagnostico = null)
    {
        if (_avisoRecorteMostrado) return;
        _avisoRecorteMostrado = true;
        TaskDialog.Show("MYG - Recorte de tarrajeo",
            "Se omitió al menos un paño porque no fue posible descontar una interferencia visible. " +
            "Cierra este aviso para continuar seleccionando caras; pulsa Esc para terminar." +
            (string.IsNullOrEmpty(diagnostico) ? string.Empty : "\n\n" + diagnostico));
    }

    private LoopMuro ExpandirLoopMinimoParaBoolean(
        LoopMuro loop,
        double margen)
    {
        try
        {
            if (loop == null ||
                loop.Puntos2D == null ||
                loop.Puntos2D.Count < 4 ||
                loop.Marco == null)
            {
                return null;
            }

            List<UV2> abiertos = loop.Puntos2D
                .Take(loop.Puntos2D.Count - 1)
                .Select(p => new UV2(p.U, p.V))
                .ToList();

            List<UV2> expandidos = ExpandirContornoRadial(
                abiertos,
                margen);

            if (expandidos == null || expandidos.Count < 3)
                return null;

            expandidos.Add(new UV2(
                expandidos[0].U,
                expandidos[0].V));

            return LoopDesdeUV(
                expandidos,
                loop.Marco);
        }
        catch
        {
            return null;
        }
    }

    // =========================================================
    // RECORTES POR SÓLIDOS VISIBLES
    // =========================================================

    private ResultadoRecorteSolidos ObtenerLoopsRecortadosPorSolidos(
        Document doc,
        View vista,
        Element hostElem,
        List<LoopMuro> loopsOriginales,
        MarcoMuro marco,
        XYZ normal,
        double espesor)
    {
        ResultadoRecorteSolidos resultado = new ResultadoRecorteSolidos();

        try
        {
            if (doc == null ||
                loopsOriginales == null ||
                loopsOriginales.Count == 0 ||
                marco == null ||
                normal == null)
            {
                return resultado;
            }

            List<ComponenteMuro> comps = ClasificarComponentes(loopsOriginales);

            if (comps.Count == 0)
                return resultado;

            ComponenteMuro baseComp = comps[0];
            List<LoopMuro> holes = SanitizarHuecos(
                baseComp.Exterior,
                baseComp.Huecos);

            double semiEspesor = BOOLEAN_PROFILE_HALF_DEPTH;

            Solid tarrajeo = CrearSolidoPerfil(
                baseComp.Exterior,
                holes,
                normal,
                semiEspesor);

            //-------------------------------------------------
            // V62:
            // Si la cara original es irregular y Revit no permite crear el
            // sólido temporal, NO se descarta la cara. Se conserva su perfil
            // original y la creación directa del muro se encargará de ella.
            //-------------------------------------------------
            if (tarrajeo == null || tarrajeo.Volume <= TOL)
                return resultado;

            double distanciaProyeccion = Math.Max(
                SOLID_PROJECTION_GAP,
                espesor + SOLID_PROJECTION_GAP);

            Outline box = OutlineDesdeLoop(
                baseComp.Exterior,
                normal,
                distanciaProyeccion);

            if (box == null)
                return resultado;

            List<Solid> solidos = SolidosVisibles(
                doc,
                vista,
                box,
                hostElem != null
                    ? hostElem.Id
                    : ElementId.InvalidElementId);

            if (solidos.Count == 0)
                return resultado;

            bool cambio = false;

            foreach (Solid cortanteOriginal in solidos)
            {
                if (cortanteOriginal == null ||
                    cortanteOriginal.Volume <= TOL ||
                    !SolidTocaOutline(cortanteOriginal, box))
                {
                    continue;
                }

                //-------------------------------------------------
                // V62:
                // La categoría ya no interviene. Del sólido se obtiene una
                // silueta 2D proyectada al plano del tarrajeo y esa silueta se
                // extruye atravesando completamente la lámina temporal.
                //-------------------------------------------------
                Solid cortanteProyectado = CrearCortanteProyectado(
                    cortanteOriginal,
                    marco,
                    normal,
                    semiEspesor,
                    distanciaProyeccion,
                    false);

                if (cortanteProyectado == null ||
                    cortanteProyectado.Volume <= TOL)
                {
                    continue;
                }

                ResultadoRestaSolido resta = RestarSolidoSeguro(
                    tarrajeo,
                    cortanteProyectado,
                    normal);

                //-------------------------------------------------
                // Si el contorno convexo produce un boolean inestable, se usa
                // un rectángulo UV expandido. Es deliberadamente conservador:
                // es preferible retirar un poco más de acabado que dejarlo
                // ocupando el sólido estructural.
                //-------------------------------------------------
                if (resta.FalloParcial)
                {
                    Solid cortanteRectangular = CrearCortanteProyectado(
                        cortanteOriginal,
                        marco,
                        normal,
                        semiEspesor,
                        distanciaProyeccion,
                        true);

                    if (cortanteRectangular != null &&
                        cortanteRectangular.Volume > TOL)
                    {
                        resta = RestarSolidoSeguro(
                            tarrajeo,
                            cortanteRectangular,
                            normal);
                    }
                }

                if (resta.EliminadoCompletamente)
                {
                    resultado.HuboCambio = true;
                    resultado.EliminadoCompletamente = true;
                    resultado.Loops.Clear();
                    return resultado;
                }

                //-------------------------------------------------
                // Un cortante aislado que falla ya no elimina toda la cara.
                // Se continúa con los demás sólidos.
                //-------------------------------------------------
                if (resta.FalloParcial)
                    continue;

                if (resta.HuboCambio &&
                    resta.Solido != null &&
                    resta.Solido.Volume > TOL)
                {
                    tarrajeo = resta.Solido;
                    cambio = true;
                }
            }

            if (!cambio)
                return resultado;

            List<PlanarFace> caras = CarasPerfil(
                tarrajeo,
                normal,
                marco.Origen,
                semiEspesor);

            foreach (PlanarFace pf in caras)
            {
                if (pf == null)
                    continue;

                foreach (CurveLoop cl in pf.GetEdgesAsCurveLoops())
                {
                    LoopMuro lp = LoopDesdeCurveLoop(
                        cl,
                        Transform.Identity,
                        marco);

                    if (lp != null &&
                        lp.AreaAbs > 1e-6 &&
                        !resultado.Loops.Any(x => Similar(x, lp)))
                    {
                        resultado.Loops.Add(lp);
                    }
                }
            }

            resultado.HuboCambio = true;

            if (resultado.Loops.Count == 0 ||
                ClasificarComponentes(resultado.Loops).Count == 0)
            {
                //-------------------------------------------------
                // Aquí sí hubo una resta real pero no se pudo reconstruir el
                // perfil. No se vuelve al paño completo porque se superpondría
                // con el sólido que acaba de detectarse.
                //-------------------------------------------------
                resultado.FalloReconstruccion = true;
                resultado.Loops.Clear();
            }
        }
        catch
        {
            //-------------------------------------------------
            // No se invalida una cara irregular por un fallo previo al recorte.
            // Solo se marca fallo cuando ya se confirmó una modificación.
            //-------------------------------------------------
            if (resultado.HuboCambio)
            {
                resultado.FalloReconstruccion = true;
                resultado.Loops.Clear();
            }
        }

        return resultado;
    }

    // =========================================================
    // V62 - SÓLIDO CORTANTE DESDE SILUETA PROYECTADA
    // =========================================================

    private Solid CrearCortanteProyectado(
        Solid solid,
        MarcoMuro marco,
        XYZ normal,
        double semiEspesorPerfil,
        double distanciaMaxima,
        bool usarRectangulo)
    {
        try
        {
            if (solid == null ||
                marco == null ||
                marco.Origen == null ||
                marco.U == null ||
                marco.V == null ||
                normal == null ||
                normal.GetLength() <= TOL)
            {
                return null;
            }

            XYZ n = normal.Normalize();
            double minD;
            double maxD;

            if (!RangoSolidoRespectoPlano(
                solid,
                marco.Origen,
                n,
                out minD,
                out maxD))
            {
                return null;
            }

            double minObjetivo = -semiEspesorPerfil;
            double maxObjetivo = semiEspesorPerfil;

            bool cruzaPlano =
                maxD >= minObjetivo &&
                minD <= maxObjetivo;

            if (!cruzaPlano)
            {
                double separacion = minD > maxObjetivo
                    ? minD - maxObjetivo
                    : minObjetivo - maxD;

                if (separacion > distanciaMaxima)
                    return null;
            }

            List<UV2> proyectados = ObtenerPuntosProyectadosSolido(
                solid,
                marco);

            if (proyectados.Count < 3)
                return null;

            List<UV2> contorno;

            if (usarRectangulo)
            {
                contorno = CrearRectanguloUVExpandido(
                    proyectados,
                    PROJECTED_CUT_MARGIN);
            }
            else
            {
                contorno = ConvexHullUV(proyectados);

                if (contorno.Count >= 3)
                {
                    contorno = ExpandirContornoRadial(
                        contorno,
                        PROJECTED_CUT_MARGIN);
                }

                if (contorno.Count < 3)
                {
                    contorno = CrearRectanguloUVExpandido(
                        proyectados,
                        PROJECTED_CUT_MARGIN);
                }
            }

            if (contorno.Count < 3)
                return null;

            if (!Igual(contorno[0], contorno[contorno.Count - 1]))
            {
                contorno.Add(new UV2(
                    contorno[0].U,
                    contorno[0].V));
            }

            LoopMuro loop = LoopDesdeUV(
                contorno,
                marco);

            if (loop == null || loop.AreaAbs <= 1e-6)
                return null;

            return CrearSolidoPerfil(
                loop,
                new List<LoopMuro>(),
                n,
                semiEspesorPerfil +
                SOLID_PROJECTION_OVERTRAVEL +
                PROJECTED_CUT_MARGIN);
        }
        catch
        {
            return null;
        }
    }

    private List<UV2> ObtenerPuntosProyectadosSolido(
        Solid solid,
        MarcoMuro marco)
    {
        List<UV2> puntos = new List<UV2>();

        if (solid == null || marco == null)
            return puntos;

        try
        {
            foreach (Face face in solid.Faces)
            {
                if (face == null)
                    continue;

                try
                {
                    Mesh mesh = face.Triangulate();

                    if (mesh == null)
                        continue;

                    for (int iTriangulo = 0; iTriangulo < mesh.NumTriangles; iTriangulo++)
                    {
                        MeshTriangle triangulo = mesh.get_Triangle(iTriangulo);

                        if (triangulo == null)
                            continue;

                        for (int iVertice = 0; iVertice < 3; iVertice++)
                        {
                            XYZ p = triangulo.get_Vertex(iVertice);

                            if (p == null)
                                continue;

                            XYZ d = p - marco.Origen;

                            AgregarUVUnico(
                                puntos,
                                new UV2(
                                    d.DotProduct(marco.U),
                                    d.DotProduct(marco.V)));
                        }
                    }
                }
                catch
                {
                    try
                    {
                        foreach (CurveLoop cl in face.GetEdgesAsCurveLoops())
                        {
                            foreach (Curve c in cl)
                            {
                                foreach (XYZ p in PuntosCurva(c))
                                {
                                    XYZ d = p - marco.Origen;

                                    AgregarUVUnico(
                                        puntos,
                                        new UV2(
                                            d.DotProduct(marco.U),
                                            d.DotProduct(marco.V)));
                                }
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch
        {
        }

        return puntos;
    }

    private void AgregarUVUnico(
        List<UV2> puntos,
        UV2 nuevo)
    {
        if (puntos == null || nuevo == null)
            return;

        const double tolUv = 1e-5;

        foreach (UV2 p in puntos)
        {
            if (Math.Abs(p.U - nuevo.U) <= tolUv &&
                Math.Abs(p.V - nuevo.V) <= tolUv)
            {
                return;
            }
        }

        puntos.Add(nuevo);
    }

    private List<UV2> ConvexHullUV(
        List<UV2> puntos)
    {
        List<UV2> orden = puntos
            .Where(p => p != null)
            .OrderBy(p => p.U)
            .ThenBy(p => p.V)
            .Select(p => new UV2(p.U, p.V))
            .ToList();

        List<UV2> unicos = new List<UV2>();

        foreach (UV2 p in orden)
            AgregarUVUnico(unicos, p);

        if (unicos.Count <= 2)
            return unicos;

        List<UV2> inferior = new List<UV2>();

        foreach (UV2 p in unicos)
        {
            while (inferior.Count >= 2 &&
                   CrossHull(
                       inferior[inferior.Count - 2],
                       inferior[inferior.Count - 1],
                       p) <= 1e-10)
            {
                inferior.RemoveAt(inferior.Count - 1);
            }

            inferior.Add(p);
        }

        List<UV2> superior = new List<UV2>();

        for (int i = unicos.Count - 1; i >= 0; i--)
        {
            UV2 p = unicos[i];

            while (superior.Count >= 2 &&
                   CrossHull(
                       superior[superior.Count - 2],
                       superior[superior.Count - 1],
                       p) <= 1e-10)
            {
                superior.RemoveAt(superior.Count - 1);
            }

            superior.Add(p);
        }

        inferior.RemoveAt(inferior.Count - 1);
        superior.RemoveAt(superior.Count - 1);
        inferior.AddRange(superior);

        return inferior;
    }

    private double CrossHull(
        UV2 o,
        UV2 a,
        UV2 b)
    {
        return
            (a.U - o.U) * (b.V - o.V) -
            (a.V - o.V) * (b.U - o.U);
    }

    private List<UV2> ExpandirContornoRadial(
        List<UV2> contorno,
        double margen)
    {
        List<UV2> resultado = new List<UV2>();

        if (contorno == null || contorno.Count < 3)
            return resultado;

        double cu = contorno.Average(p => p.U);
        double cv = contorno.Average(p => p.V);

        foreach (UV2 p in contorno)
        {
            double du = p.U - cu;
            double dv = p.V - cv;
            double len = Math.Sqrt(du * du + dv * dv);

            if (len <= TOL)
            {
                resultado.Add(new UV2(p.U, p.V));
            }
            else
            {
                resultado.Add(new UV2(
                    p.U + margen * du / len,
                    p.V + margen * dv / len));
            }
        }

        return resultado;
    }

    private List<UV2> CrearRectanguloUVExpandido(
        List<UV2> puntos,
        double margen)
    {
        List<UV2> resultado = new List<UV2>();

        if (puntos == null || puntos.Count < 2)
            return resultado;

        double minU = puntos.Min(p => p.U) - margen;
        double maxU = puntos.Max(p => p.U) + margen;
        double minV = puntos.Min(p => p.V) - margen;
        double maxV = puntos.Max(p => p.V) + margen;

        if (maxU - minU <= PTOL ||
            maxV - minV <= PTOL)
        {
            return resultado;
        }

        resultado.Add(new UV2(minU, minV));
        resultado.Add(new UV2(maxU, minV));
        resultado.Add(new UV2(maxU, maxV));
        resultado.Add(new UV2(minU, maxV));

        return resultado;
    }

    private ResultadoRestaSolido RestarSolidoSeguro(
        Solid solidoBase,
        Solid cortante,
        XYZ normal)
    {
        ResultadoRestaSolido resultado = new ResultadoRestaSolido();

        if (solidoBase == null || cortante == null)
            return resultado;

        double volumenBase = solidoBase.Volume;
        double toleranciaVolumen = Math.Max(1e-8, volumenBase * 1e-8);

        try
        {
            Solid diff = BooleanOperationsUtils.ExecuteBooleanOperation(
                solidoBase,
                cortante,
                BooleanOperationsType.Difference);

            if (diff != null)
            {
                if (diff.Volume <= TOL)
                {
                    resultado.HuboCambio = true;
                    resultado.EliminadoCompletamente = true;
                    return resultado;
                }

                if (diff.Volume < volumenBase - toleranciaVolumen)
                {
                    resultado.Solido = diff;
                    resultado.HuboCambio = true;
                    return resultado;
                }

                // Difference válido sin reducción: no existe intersección volumétrica.
                return resultado;
            }
        }
        catch
        {
        }

        //-------------------------------------------------
        // Si Difference falló, se usa Intersect únicamente como diagnóstico.
        // Esto permite distinguir un simple contacto de una eliminación total.
        //-------------------------------------------------
        Solid interseccion = null;

        try
        {
            interseccion = BooleanOperationsUtils.ExecuteBooleanOperation(
                solidoBase,
                cortante,
                BooleanOperationsType.Intersect);
        }
        catch
        {
            interseccion = null;
        }

        if (interseccion == null)
        {
            resultado.FalloParcial = true;
            return resultado;
        }
        if (interseccion.Volume <= toleranciaVolumen)
            return resultado;

        if (interseccion.Volume >= volumenBase - toleranciaVolumen)
        {
            resultado.HuboCambio = true;
            resultado.EliminadoCompletamente = true;
            return resultado;
        }

        //-------------------------------------------------
        // Reintento para contactos coplanares: se desplaza el cortante una
        // fracción de milímetro hacia ambos lados del espesor del tarrajeo.
        //-------------------------------------------------
        XYZ n = normal != null && normal.GetLength() > TOL
            ? normal.Normalize()
            : XYZ.BasisX;

        double[] desplazamientos = new double[]
        {
            BOOLEAN_RETRY_OFFSET,
            -BOOLEAN_RETRY_OFFSET
        };

        foreach (double d in desplazamientos)
        {
            try
            {
                Solid cortanteMovido = SolidUtils.CreateTransformed(
                    cortante,
                    Transform.CreateTranslation(n.Multiply(d)));

                Solid diff = BooleanOperationsUtils.ExecuteBooleanOperation(
                    solidoBase,
                    cortanteMovido,
                    BooleanOperationsType.Difference);

                if (diff == null)
                    continue;

                if (diff.Volume <= TOL)
                {
                    resultado.HuboCambio = true;
                    resultado.EliminadoCompletamente = true;
                    return resultado;
                }

                if (diff.Volume < volumenBase - toleranciaVolumen)
                {
                    resultado.Solido = diff;
                    resultado.HuboCambio = true;
                    return resultado;
                }
            }
            catch
            {
            }
        }

        resultado.HuboCambio = true;
        resultado.FalloParcial = true;
        return resultado;
    }

    // =========================================================
    // V61 - PROYECCIÓN GEOMÉTRICA DE CUALQUIER SÓLIDO AL PLANO
    // =========================================================

    // V62: la antigua traslación múltiple del sólido fue retirada.
    // El recorte usa únicamente la silueta proyectada creada arriba.

    private bool RangoSolidoRespectoPlano(
        Solid solid,
        XYZ origenPlano,
        XYZ normal,
        out double minD,
        out double maxD)
    {
        minD = double.MaxValue;
        maxD = double.MinValue;

        try
        {
            if (solid == null || origenPlano == null || normal == null)
                return false;

            BoundingBoxXYZ bb = solid.GetBoundingBox();

            if (bb == null)
                return false;

            Transform tr = bb.Transform ?? Transform.Identity;
            XYZ mn = bb.Min;
            XYZ mx = bb.Max;

            XYZ[] puntos = new XYZ[]
            {
                tr.OfPoint(new XYZ(mn.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mx.Z))
            };

            foreach (XYZ p in puntos)
            {
                double d = (p - origenPlano).DotProduct(normal);

                if (d < minD) minD = d;
                if (d > maxD) maxD = d;
            }

            return minD != double.MaxValue && maxD != double.MinValue;
        }
        catch
        {
            minD = 0.0;
            maxD = 0.0;
            return false;
        }
    }

    private Solid CrearSolidoPerfil(LoopMuro ext, List<LoopMuro> holes, XYZ normal, double semi)
    {
        try
        {
            List<CurveLoop> cls = new List<CurveLoop>();

            Transform mov = Transform.CreateTranslation(normal.Normalize().Multiply(-semi));

            CurveLoop e = CurveLoopDesdeLoop(ext, true, mov);

            if (e == null || e.IsOpen())
                return null;

            cls.Add(e);

            foreach (LoopMuro h in holes)
            {
                CurveLoop c = CurveLoopDesdeLoop(h, false, mov);

                if (c != null && !c.IsOpen())
                    cls.Add(c);
            }

            return GeometryCreationUtilities.CreateExtrusionGeometry(cls, normal.Normalize(), Math.Max(semi * 2.0, 0.01));
        }
        catch
        {
            return null;
        }
    }

    private List<Solid> SolidosVisibles(Document doc, View vista, Outline box, ElementId hostId)
    {
        List<Solid> res = new List<Solid>();

        if (doc == null || box == null)
            return res;

        //-------------------------------------------------
        // ELEMENTOS NATIVOS: el collector por View.Id ya respeta recorte,
        // fase, disciplina, filtros y visibilidad general de la vista.
        //-------------------------------------------------
        try
        {
            FilteredElementCollector col = vista != null && !vista.IsTemplate
                ? new FilteredElementCollector(doc, vista.Id)
                : new FilteredElementCollector(doc);

            foreach (Element e in col
                .WherePasses(new BoundingBoxIntersectsFilter(box))
                .WhereElementIsNotElementType())
            {
                if (e == null ||
                    e.Id == hostId ||
                    EsElementoOrigenNativo(e) ||
                    e is RevitLinkInstance ||
                    _idsCreadosDuranteLote.Contains(e.Id) ||
                    IgnorarParaRecorte(e) ||
                    !EsElementoVisibleEnVista(e, vista) ||
                    !EsVisibleHostSegunExportador(e.Id, vista))
                {
                    continue;
                }

                int inicioSolidos = res.Count;
                ExtraerSolidos(
                    e,
                    vista,
                    Transform.Identity,
                    res,
                    true);

                string origen = "Origen: elemento ID " + e.Id +
                    "; categoría " + (e.Category != null ? e.Category.Name : "sin categoría") +
                    " (incluye geometría de dependientes).";
                for (int i = inicioSolidos; i < res.Count; i++)
                {
                    string previo;
                    _origenesSolidosCortantes[res[i]] =
                        _origenesSolidosCortantes.TryGetValue(res[i], out previo)
                            ? (previo.Contains(origen) ? previo : previo + " / " + origen)
                            : origen;
                }
            }
        }
        catch
        {
        }

        if (!ConsiderarVinculos)
            return res;

        //-------------------------------------------------
        // VÍNCULOS: solo se procesan instancias de vínculo visibles en la
        // vista activa. Si el vínculo está configurado "Por vista vinculada",
        // se obtiene esa vista por reflexión y se usa para su collector.
        //-------------------------------------------------
        try
        {
            FilteredElementCollector links = vista != null && !vista.IsTemplate
                ? new FilteredElementCollector(doc, vista.Id)
                : new FilteredElementCollector(doc);

            foreach (RevitLinkInstance li in links
                .OfClass(typeof(RevitLinkInstance))
                .Cast<RevitLinkInstance>())
            {
                if (li == null ||
                    !EsElementoVisibleEnVista(li, vista))
                {
                    continue;
                }

                Document ld = li.GetLinkDocument();

                if (ld == null)
                    continue;

                Transform tr = li.GetTotalTransform();
                Outline linkBox = TransformarOutline(box, tr.Inverse);

                if (linkBox == null)
                    continue;

                View vistaVinculada = ObtenerVistaVinculadaUsadaEnHost(
                    vista,
                    li,
                    ld);

                FilteredElementCollector colL =
                    vistaVinculada != null && !vistaVinculada.IsTemplate
                        ? new FilteredElementCollector(ld, vistaVinculada.Id)
                        : new FilteredElementCollector(ld);

                foreach (Element e in colL
                    .WherePasses(new BoundingBoxIntersectsFilter(linkBox))
                    .WhereElementIsNotElementType())
                {
                    if (e == null ||
                        IgnorarParaRecorte(e) ||
                        EsElementoOrigenVinculado(li, e))
                    {
                        continue;
                    }

                    // V75: esta es la comprobación decisiva. No importa que el
                    // elemento exista físicamente dentro del RVT vinculado:
                    // si Revit NO lo recorrió al exportar la vista activa,
                    // queda completamente fuera de los cortantes.
                    bool visibleEnExportador =
                        EsVisibleVinculoSegunExportador(
                            ld,
                            tr,
                            e.Id,
                            vista);

                    // LinkNode.GetTransform() normalmente coincide con
                    // RevitLinkInstance.GetTransform(). El motor usa
                    // GetTotalTransform() para llevar sólidos al host, por eso
                    // se prueba también la transformación simple antes de
                    // descartar el elemento.
                    if (!visibleEnExportador)
                    {
                        try
                        {
                            Transform trInstancia = li.GetTransform();

                            visibleEnExportador =
                                EsVisibleVinculoSegunExportador(
                                    ld,
                                    trInstancia,
                                    e.Id,
                                    vista);
                        }
                        catch
                        {
                        }
                    }

                    if (!visibleEnExportador)
                        continue;

                    if (vistaVinculada != null)
                    {
                        if (!EsElementoVisibleEnVista(e, vistaVinculada))
                            continue;
                    }
                    else
                    {
                        // En modo "Por vista anfitriona" no existe una View del
                        // documento vinculado. Se respeta al menos la visibilidad
                        // de categorías de modelo incorporadas en la vista host.
                        if (!CategoriaVinculadaVisibleEnVistaHost(vista, e))
                            continue;
                    }

                    int inicioSolidos = res.Count;
                    ExtraerSolidos(
                        e,
                        vistaVinculada,
                        tr,
                        res,
                        true);

                    string origen = "Origen: vínculo ID " + li.Id +
                        "; elemento ID " + e.Id +
                        "; categoría " + (e.Category != null ? e.Category.Name : "sin categoría") +
                        " (incluye geometría de dependientes).";
                    for (int i = inicioSolidos; i < res.Count; i++)
                    {
                        string previo;
                        _origenesSolidosCortantes[res[i]] =
                            _origenesSolidosCortantes.TryGetValue(res[i], out previo)
                                ? (previo.Contains(origen) ? previo : previo + " / " + origen)
                                : origen;
                    }
                }
            }
        }
        catch
        {
        }

        return res;
    }

    private string DescribirSolidoCortante(Solid solido)
    {
        string origen;
        return solido != null &&
            _origenesSolidosCortantes.TryGetValue(solido, out origen)
                ? origen
                : "Origen del sólido no identificado.";
    }

    // =========================================================
    // V73 - VISIBILIDAD REAL EN LA VISTA ACTIVA
    // =========================================================
    // No basta con usar FilteredElementCollector(doc, view.Id): Revit puede
    // seguir devolviendo elementos ocultos por Hide in View, filtros o por el
    // modo temporal Hide/Isolate. Para los recortes se exige que el elemento
    // sea realmente visible en ESA vista.
    // =========================================================
    private bool EsElementoVisibleEnVista(Element e, View vista)
    {
        if (e == null)
            return false;

        if (vista == null || vista.IsTemplate)
            return true;

        try
        {
            if (!object.ReferenceEquals(e.Document, vista.Document))
                return true;
        }
        catch
        {
            return true;
        }

        // 1) Ocultación permanente por elemento.
        try
        {
            if (e.IsHidden(vista))
                return false;
        }
        catch
        {
        }

        // 2) Categoría apagada en VG / plantilla de vista.
        try
        {
            if (e.Category != null && vista.GetCategoryHidden(e.Category.Id))
                return false;
        }
        catch
        {
        }

        // 3) Hide/Isolate temporal.
        try
        {
            if (vista.IsTemporaryHideIsolateActive())
            {
                bool visibleTemporal = vista.IsElementVisibleInTemporaryViewMode(
                    TemporaryViewMode.TemporaryHideIsolate,
                    e.Id);

                if (!visibleTemporal)
                    return false;
            }
        }
        catch
        {
            // Si una vista concreta no soporta este modo, no se fuerza ocultación.
        }

        // 4) Filtros de vista cuya visibilidad está desactivada.
        if (EstaOcultoPorFiltroDeVista(e, vista))
            return false;

        // 5) V75 - comprobación final contra lo que Revit realmente recorrió
        // para dibujar/exportar la vista 3D activa.
        //
        // Para RevitLinkInstance la comprobación exacta se hace después con
        // OnLinkBegin + transformación de la instancia. No se exige aquí que
        // exista OnElementBegin para la propia instancia de vínculo.
        if (!(e is RevitLinkInstance) &&
            !EsVisibleHostSegunExportador(e.Id, vista))
        {
            return false;
        }

        return true;
    }

    private bool EstaOcultoPorFiltroDeVista(Element e, View vista)
    {
        if (e == null || vista == null || vista.IsTemplate)
            return false;

        try
        {
            ICollection<ElementId> filtros = vista.GetFilters();

            if (filtros == null || filtros.Count == 0)
                return false;

            foreach (ElementId idFiltro in filtros)
            {
                if (idFiltro == null || idFiltro == ElementId.InvalidElementId)
                    continue;

                bool visible = true;

                try
                {
                    visible = vista.GetFilterVisibility(idFiltro);
                }
                catch
                {
                    visible = true;
                }

                if (visible)
                    continue;

                Element filtro = vista.Document.GetElement(idFiltro);

                ParameterFilterElement pfe = filtro as ParameterFilterElement;

                if (pfe != null)
                {
                    if (e.Category == null)
                        continue;

                    ICollection<ElementId> categorias = null;

                    try
                    {
                        categorias = pfe.GetCategories();
                    }
                    catch
                    {
                        categorias = null;
                    }

                    if (categorias != null &&
                        categorias.Count > 0 &&
                        !categorias.Any(x => x != null && x.Equals(e.Category.Id)))
                    {
                        continue;
                    }

                    try
                    {
                        ElementFilter filtroReglas = pfe.GetElementFilter();

                        if (filtroReglas != null &&
                            filtroReglas.PassesFilter(e.Document, e.Id))
                        {
                            return true;
                        }
                    }
                    catch
                    {
                    }

                    continue;
                }

                SelectionFilterElement sfe = filtro as SelectionFilterElement;

                if (sfe != null)
                {
                    try
                    {
                        ICollection<ElementId> ids = sfe.GetElementIds();

                        if (ids != null && ids.Any(x => x != null && x.Equals(e.Id)))
                            return true;
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch
        {
        }

        return false;
    }

    private bool CategoriaVinculadaVisibleEnVistaHost(View vistaHost, Element e)
    {
        if (vistaHost == null || e == null || e.Category == null)
            return true;

        try
        {
            // Los BuiltInCategory conservan su Id negativo entre documentos.
            // Para subcategorías o categorías personalizadas con Id positivo no
            // se fuerza una equivalencia que podría corresponder a otra categoría.
            long valorCategoria;

            if (long.TryParse(e.Category.Id.ToString(), out valorCategoria) && valorCategoria < 0)
            {
                if (vistaHost.GetCategoryHidden(e.Category.Id))
                    return false;
            }
        }
        catch
        {
        }

        return true;
    }

    private View ObtenerVistaVinculadaUsadaEnHost(
        View vistaHost,
        RevitLinkInstance link,
        Document linkDoc)
    {
        try
        {
            if (vistaHost == null || link == null || linkDoc == null)
                return null;

            MethodInfo metodo = vistaHost.GetType().GetMethod(
                "GetLinkOverrides",
                BindingFlags.Public | BindingFlags.Instance,
                null,
                new Type[] { typeof(ElementId) },
                null);

            if (metodo == null)
                return null;

            object ajustes = metodo.Invoke(
                vistaHost,
                new object[] { link.Id });

            if (ajustes == null)
                return null;

            string[] nombresPropiedad = new string[]
            {
                "LinkedViewId",
                "LinkViewId"
            };

            foreach (string nombre in nombresPropiedad)
            {
                PropertyInfo prop = ajustes.GetType().GetProperty(
                    nombre,
                    BindingFlags.Public | BindingFlags.Instance);

                if (prop == null)
                    continue;

                ElementId idVista = prop.GetValue(ajustes, null) as ElementId;

                if (idVista == null || idVista == ElementId.InvalidElementId)
                    continue;

                View v = linkDoc.GetElement(idVista) as View;

                if (v != null)
                    return v;
            }
        }
        catch
        {
        }

        return null;
    }

    private bool EsElementoOrigenVinculado(RevitLinkInstance link, Element e)
    {
        try
        {
            if (link == null ||
                e == null ||
                _vinculoOrigenRecorte == null)
            {
                return false;
            }

            if (!link.Id.Equals(_vinculoOrigenRecorte.Id))
                return false;

            // V71: dentro de la instancia concreta del vínculo, cualquier ID
            // registrado como parte del anfitrión compuesto se excluye.
            return _idsOrigenRecorte.Contains(e.Id);
        }
        catch
        {
            return false;
        }
    }

    private bool EsElementoOrigenNativo(Element e)
    {
        try
        {
            if (e == null || _vinculoOrigenRecorte != null)
                return false;

            return _idsOrigenRecorte.Contains(e.Id);
        }
        catch
        {
            return false;
        }
    }

    private bool EsMismoElementoODependiente(
        Element origen,
        Element candidato)
    {
        try
        {
            if (origen == null || candidato == null)
                return false;

            if (_idsOrigenRecorte.Contains(candidato.Id))
                return true;

            if (origen.Id.Equals(candidato.Id))
                return true;

            ICollection<ElementId> dependientes =
                origen.GetDependentElements(null);

            if (dependientes == null)
                return false;

            foreach (ElementId id in dependientes)
            {
                if (id != null && id.Equals(candidato.Id))
                    return true;
            }
        }
        catch
        {
        }

        return false;
    }

    private void ExtraerSolidos(
        Element e,
        View vista,
        Transform tr,
        List<Solid> res,
        bool conDependientes)
    {
        if (e == null || res == null)
            return;

        //-------------------------------------------------
        // V68:
        // No se consulta categoría, nombre, familia, ancho, altura ni ningún
        // parámetro del elemento. Se usa exclusivamente la geometría Solid real
        // que Revit entrega para el elemento y sus GeometryInstance.
        //-------------------------------------------------
        foreach (Solid s in SolidosElementoCache(e, vista, tr))
        {
            if (s != null && s.Volume > TOL)
                res.Add(s);
        }

        //-------------------------------------------------
        // Algunos elementos compuestos guardan parte de su geometría en
        // elementos dependientes. Se revisan de forma genérica, sin decidirlo
        // por el nombre de una categoría concreta. La sonda booleana será la
        // que descarte cualquier sólido que no la interseque.
        //-------------------------------------------------
        if (!conDependientes)
            return;

        try
        {
            foreach (ElementId id in e.GetDependentElements(null))
            {
                Element dep = e.Document.GetElement(id);

                if (dep == null || dep.Id == e.Id || IgnorarParaRecorte(dep))
                    continue;

                // V73: un dependiente oculto NO puede recortar aunque su padre
                // permanezca visible en la vista.
                if (vista != null && !EsElementoVisibleEnVista(dep, vista))
                    continue;

                foreach (Solid s in SolidosElementoCache(dep, vista, tr))
                {
                    if (s != null && s.Volume > TOL)
                        res.Add(s);
                }
            }
        }
        catch
        {
        }
    }

    private List<Solid> SolidosElementoCache(Element e, View vista, Transform tr)
    {
        if (e == null)
            return new List<Solid>();

        string key = ClaveSolido(e, vista, tr);

        List<Solid> existentes;

        if (_solidCache.TryGetValue(key, out existentes))
            return existentes;

        List<Solid> nuevos = SolidosElemento(e, vista, tr);

        _solidCache[key] = nuevos ?? new List<Solid>();

        return _solidCache[key];
    }

    private string ClaveSolido(Element e, View vista, Transform tr)
    {
        try
        {
            XYZ o = tr != null ? tr.Origin : XYZ.Zero;
            XYZ bx = tr != null ? tr.BasisX : XYZ.BasisX;
            XYZ by = tr != null ? tr.BasisY : XYZ.BasisY;
            XYZ bz = tr != null ? tr.BasisZ : XYZ.BasisZ;

            return e.Document.GetHashCode().ToString() + "|" +
                   e.Id.ToString() + "|" +
                   (vista != null ? vista.Id.ToString() : "MODEL") + "|" +
                   Math.Round(o.X, 6) + "," + Math.Round(o.Y, 6) + "," + Math.Round(o.Z, 6) + "|" +
                   Math.Round(bx.X, 6) + "," + Math.Round(bx.Y, 6) + "," + Math.Round(bx.Z, 6) + "|" +
                   Math.Round(by.X, 6) + "," + Math.Round(by.Y, 6) + "," + Math.Round(by.Z, 6) + "|" +
                   Math.Round(bz.X, 6) + "," + Math.Round(bz.Y, 6) + "," + Math.Round(bz.Z, 6);
        }
        catch
        {
            return e.Id.ToString();
        }
    }

    private bool RequiereDependientes(Element e)
    {
        try
        {
            if (e == null || e.Category == null)
                return false;

            string n = (e.Category.Name ?? "").ToLowerInvariant();

            if (n.Contains("escaler") || n.Contains("stair"))
                return true;

            if (n.Contains("rampa") || n.Contains("ramp"))
                return true;
        }
        catch
        {
        }

        return false;
    }

    private List<Solid> SolidosElemento(Element e, View vista, Transform tr)
    {
        List<Solid> res = new List<Solid>();

        if (e == null)
            return res;

        //-------------------------------------------------
        // V73 - GEOMETRÍA DE LA VISTA ACTIVA PRIMERO
        //-------------------------------------------------
        // El recorte debe representar exactamente lo que el usuario ve. Por eso
        // primero se pide la geometría dependiente de la vista con
        // IncludeNonVisibleObjects = false. Solo si Revit no devuelve ningún
        // sólido se usa la geometría física completa como respaldo.
        //-------------------------------------------------
        List<Options> opciones = new List<Options>();

        if (vista != null && !vista.IsTemplate)
        {
            try
            {
                opciones.Add(new Options()
                {
                    ComputeReferences = false,
                    IncludeNonVisibleObjects = false,
                    View = vista
                });
            }
            catch
            {
            }
        }

        opciones.Add(new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = false,
            DetailLevel = ViewDetailLevel.Fine
        });

        foreach (Options op in opciones)
        {
            try
            {
                GeometryElement geo = e.get_Geometry(op);

                if (geo == null)
                    continue;

                int antes = res.Count;

                ExtraerDeGeo(
                    geo,
                    tr ?? Transform.Identity,
                    res);

                if (res.Count > antes)
                    break;
            }
            catch
            {
            }
        }

        return res;
    }

    private void ExtraerDeGeo(GeometryElement geo, Transform tr, List<Solid> res)
    {
        foreach (GeometryObject obj in geo)
        {
            if (obj is Solid)
            {
                Solid s = obj as Solid;

                try
                {
                    Solid st = tr != null && !tr.IsIdentity ? SolidUtils.CreateTransformed(s, tr) : s;

                    if (st != null && st.Volume > TOL && st.Faces.Size > 0 && st.Edges.Size > 0)
                        res.Add(st);
                }
                catch
                {
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement sym = gi.GetSymbolGeometry();

                if (sym != null)
                    ExtraerDeGeo(sym, tr.Multiply(gi.Transform), res);
            }
            catch
            {
                try
                {
                    GeometryElement inst = gi.GetInstanceGeometry();

                    if (inst != null)
                        ExtraerDeGeo(inst, tr, res);
                }
                catch
                {
                }
            }
        }
    }

    private bool IgnorarParaRecorte(Element e)
    {
        if (e == null)
            return true;

        // Los elementos propios de una vista no representan sólidos físicos
        // del modelo. Fuera de esto no se filtra por categoría ni por familia.
        if (e.ViewSpecific)
            return true;

        return false;
    }



    // =========================================================
    // V56 - WALL CUTTER FÍSICO Y SIN UNIÓN CON MUROS CORTANTES
    // =========================================================

    private Solid CrearSolidoCortanteFisicoDesdeWall(Wall wall, Transform tr)
    {
        try
        {
            if (wall == null)
                return null;

            LocationCurve lc = wall.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return null;

            Curve curva = lc.Curve;

            //-------------------------------------------------
            // Versión segura para muros rectos.
            // Para muros curvos se deja fallback a geometría normal.
            //-------------------------------------------------
            Line linea = curva as Line;

            if (linea == null)
                return null;

            XYZ p0 = linea.GetEndPoint(0);
            XYZ p1 = linea.GetEndPoint(1);

            XYZ dir = p1 - p0;
            dir = new XYZ(dir.X, dir.Y, 0.0);

            if (dir.GetLength() <= TOL)
                return null;

            dir = dir.Normalize();

            XYZ orient = null;

            try
            {
                orient = wall.Orientation;
                orient = new XYZ(orient.X, orient.Y, 0.0);

                if (orient.GetLength() > TOL)
                    orient = orient.Normalize();
            }
            catch
            {
                orient = null;
            }

            XYZ normalWall = new XYZ(-dir.Y, dir.X, 0.0).Normalize();

            if (orient != null && orient.GetLength() > TOL && normalWall.DotProduct(orient) < 0.0)
                normalWall = normalWall.Negate();

            double ancho = ObtenerAnchoWall(wall);

            if (ancho <= TOL)
                return null;

            XYZ offsetCentro = OffsetCentroSegunLineaUbicacion(wall, normalWall, ancho);

            p0 = p0 + offsetCentro;
            p1 = p1 + offsetCentro;

            BoundingBoxXYZ bb = null;

            try
            {
                bb = wall.get_BoundingBox(null);
            }
            catch
            {
                bb = null;
            }

            if (bb == null)
                return null;

            double zMin = bb.Min.Z - WALL_CUTTER_MARGIN;
            double zMax = bb.Max.Z + WALL_CUTTER_MARGIN;
            double altura = zMax - zMin;

            if (altura <= TOL)
                return null;

            XYZ base0 = new XYZ(p0.X, p0.Y, zMin);
            XYZ base1 = new XYZ(p1.X, p1.Y, zMin);

            XYZ side = normalWall.Multiply((ancho / 2.0) + WALL_CUTTER_MARGIN);
            XYZ ext = dir.Multiply(WALL_CUTTER_MARGIN);

            XYZ a = base0 - ext - side;
            XYZ b = base1 + ext - side;
            XYZ c = base1 + ext + side;
            XYZ d = base0 - ext + side;

            CurveLoop loop = new CurveLoop();
            loop.Append(Line.CreateBound(a, b));
            loop.Append(Line.CreateBound(b, c));
            loop.Append(Line.CreateBound(c, d));
            loop.Append(Line.CreateBound(d, a));

            Solid s = GeometryCreationUtilities.CreateExtrusionGeometry(
                new List<CurveLoop>() { loop },
                XYZ.BasisZ,
                altura);

            if (s == null || s.Volume <= TOL)
                return null;

            if (tr != null && !tr.IsIdentity)
                s = SolidUtils.CreateTransformed(s, tr);

            return s;
        }
        catch
        {
            return null;
        }
    }

    private double ObtenerAnchoWall(Wall wall)
    {
        try
        {
            if (wall == null || wall.WallType == null)
                return 0.0;

            return wall.WallType.Width;
        }
        catch
        {
            return 0.0;
        }
    }

    private XYZ OffsetCentroSegunLineaUbicacion(Wall wall, XYZ normalWall, double ancho)
    {
        try
        {
            if (wall == null || normalWall == null || ancho <= TOL)
                return XYZ.Zero;

            Parameter p = wall.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);

            int key = p != null ? p.AsInteger() : 0;

            //-------------------------------------------------
            // Aproximación:
            // 0 Wall Centerline / 1 Core Centerline: ya está al centro.
            // 2 Finish Face Exterior / 4 Core Face Exterior:
            //    la línea está hacia la cara exterior, centro hacia adentro.
            // 3 Finish Face Interior / 5 Core Face Interior:
            //    la línea está hacia la cara interior, centro hacia afuera.
            //-------------------------------------------------
            if (key == 2 || key == 4)
                return normalWall.Multiply(-ancho / 2.0);

            if (key == 3 || key == 5)
                return normalWall.Multiply(ancho / 2.0);
        }
        catch
        {
        }

        return XYZ.Zero;
    }

    private HashSet<ElementId> ObtenerMurosNativosCortantes(
        Document doc,
        View vista,
        Element hostElem,
        LoopMuro perfil,
        XYZ normal,
        double espesor)
    {
        HashSet<ElementId> ids = new HashSet<ElementId>();

        try
        {
            if (doc == null || perfil == null || normal == null)
                return ids;

            Outline box = OutlineDesdeLoop(
                perfil,
                normal,
                Math.Max(espesor + 0.05, 0.15));

            if (box == null)
                return ids;

            ElementId hostId = hostElem != null ? hostElem.Id : ElementId.InvalidElementId;

            FilteredElementCollector col =
                vista != null && !vista.IsTemplate
                    ? new FilteredElementCollector(doc, vista.Id)
                    : new FilteredElementCollector(doc);

            IList<Element> muros = col
                .OfClass(typeof(Wall))
                .WherePasses(new BoundingBoxIntersectsFilter(box))
                .WhereElementIsNotElementType()
                .ToElements();

            foreach (Element e in muros)
            {
                if (e == null)
                    continue;

                if (hostId != ElementId.InvalidElementId && e.Id == hostId)
                    continue;

                if (e.ViewSpecific)
                    continue;

                if (IgnorarParaRecorte(e))
                    continue;

                BoundingBoxXYZ bb = null;

                try
                {
                    bb = e.get_BoundingBox(vista);
                }
                catch
                {
                    bb = null;
                }

                if (bb == null)
                {
                    try { bb = e.get_BoundingBox(null); } catch { bb = null; }
                }

                if (bb == null)
                {
                    ids.Add(e.Id);
                    continue;
                }

                Outline wb = new Outline(bb.Min, bb.Max);

                if (OutlinesIntersectan(box, wb))
                    ids.Add(e.Id);
            }
        }
        catch
        {
        }

        return ids;
    }

    private bool OutlinesIntersectan(Outline a, Outline b)
    {
        try
        {
            if (a == null || b == null)
                return false;

            XYZ aMin = a.MinimumPoint;
            XYZ aMax = a.MaximumPoint;
            XYZ bMin = b.MinimumPoint;
            XYZ bMax = b.MaximumPoint;

            return !(aMax.X < bMin.X || aMin.X > bMax.X ||
                     aMax.Y < bMin.Y || aMin.Y > bMax.Y ||
                     aMax.Z < bMin.Z || aMin.Z > bMax.Z);
        }
        catch
        {
            return false;
        }
    }

    private void DesunirMurosCortantes(
        Document doc,
        Wall baseWall,
        HashSet<ElementId> murosCortantes,
        bool bloquearExtremos)
    {
        try
        {
            if (doc == null || baseWall == null)
                return;

            using (Transaction tx = new Transaction(doc, "MYG Sin Unión con Muros Cortantes"))
            {
                tx.Start();
                AplicarPreprocesador(tx);

                //-------------------------------------------------
                // V57:
                // bloquearExtremos = true solo durante la creación del boceto.
                // bloquearExtremos = false al final, para respetar el input
                // Permitir Unión del usuario.
                //-------------------------------------------------
                if (bloquearExtremos)
                    ConfigurarUnion(baseWall, false);

                if (murosCortantes != null)
                {
                    foreach (ElementId id in murosCortantes)
                    {
                        try
                        {
                            Element e = doc.GetElement(id);

                            if (e == null || e.Id == baseWall.Id)
                                continue;

                            if (JoinGeometryUtils.AreElementsJoined(doc, baseWall, e))
                                JoinGeometryUtils.UnjoinGeometry(doc, baseWall, e);
                        }
                        catch
                        {
                        }
                    }
                }

                tx.Commit();
            }
        }
        catch
        {
        }
    }

    // =========================================================
    // V43 - DESUNIR GEOMETRÍA ANTES DE EDITAR BOCETO
    // =========================================================

    private void DesunirGeometriaCercanaAntesDelBoceto(
        Document doc,
        View vista,
        Wall baseWall,
        LoopMuro ext,
        XYZ normal,
        double espesor)
    {
        try
        {
            if (doc == null || baseWall == null || ext == null)
                return;

            Outline box = OutlineDesdeLoop(
                RectanguloContenedor(ext),
                normal,
                Math.Max(espesor + SEARCH_MARGIN, 0.25));

            if (box == null)
                return;

            List<Element> candidatos = new List<Element>();

            try
            {
                FilteredElementCollector col =
                    vista != null && !vista.IsTemplate
                        ? new FilteredElementCollector(doc, vista.Id)
                        : new FilteredElementCollector(doc);

                candidatos = col
                    .WherePasses(new BoundingBoxIntersectsFilter(box))
                    .WhereElementIsNotElementType()
                    .Where(e => e != null && e.Id != baseWall.Id && !(e is RevitLinkInstance) && !IgnorarParaRecorte(e))
                    .ToList();
            }
            catch
            {
                candidatos = new List<Element>();
            }

            if (candidatos.Count == 0)
                return;

            using (Transaction tx = new Transaction(doc, "MYG Desunir Tarrajeo Antes de Boceto"))
            {
                tx.Start();
                AplicarPreprocesador(tx);

                //-------------------------------------------------
                // Asegurar que el muro base no tenga uniones de extremos
                // antes de crear el ProfileSketch.
                //-------------------------------------------------
                ConfigurarUnion(baseWall, false);

                foreach (Element e in candidatos)
                {
                    try
                    {
                        if (JoinGeometryUtils.AreElementsJoined(doc, baseWall, e))
                            JoinGeometryUtils.UnjoinGeometry(doc, baseWall, e);
                    }
                    catch
                    {
                    }
                }

                tx.Commit();
            }
        }
        catch
        {
        }
    }

    // =========================================================
    // CREACIÓN DE MUROS
    // =========================================================

    private Wall CrearRectangular(
        Document doc,
        LoopMuro ext,
        WallType wallType,
        Level nivel,
        XYZ normal,
        bool permitirUnion)
    {
        try
        {
            XYZ p1 = Punto(ext, ext.MinU, ext.MinV);
            XYZ p2 = Punto(ext, ext.MaxU, ext.MinV);
            double h = ext.MaxV - ext.MinV;

            if (p1.DistanceTo(p2) <= TOL || h <= TOL)
                return null;

            Wall w = null;

            using (Transaction tx = new Transaction(doc, "MYG Tarrajeo Muro"))
            {
                tx.Start();
                AplicarPreprocesador(tx);

                // Los puntos de la cara están en coordenadas internas del proyecto.
                // Elevation puede referirse al punto topográfico y desplazar el muro.
                double desfaseBase = TarrajeoAlturas.CalcularDesfaseMuro(
                    p1.Z, nivel.ProjectElevation);
                w = Wall.Create(doc, Line.CreateBound(p1, p2), wallType.Id, nivel.Id, h, desfaseBase, false, false);

                if (w != null)
                {
                    OrientarMuro(w, normal);
                    ConfigurarLineaUbicacionExterior(w);
                    ConfigurarUnion(w, permitirUnion);
                    GuardarIdEnParametro(w, "GEN_ID Elemento");
                }

                TransactionStatus estado = tx.Commit();

                if (estado != TransactionStatus.Committed)
                    w = null;
            }

            if (w != null)
                _idsCreadosDuranteLote.Add(w.Id);

            return w;
        }
        catch
        {
            return null;
        }
    }

    // =========================================================
    // V62 - MURO IRREGULAR DIRECTO DESDE PERFIL
    // =========================================================

    private Wall CrearDesdePerfilDirecto(
        Document doc,
        LoopMuro ext,
        WallType wallType,
        Level nivel,
        XYZ normal,
        bool permitirUnion)
    {
        return CrearDesdePerfilDirectoConHuecos(
            doc,
            ext,
            new List<LoopMuro>(),
            wallType,
            nivel,
            normal,
            permitirUnion);
    }

    // =========================================================
    // V64 SIMPLE - PERFIL DIRECTO DE LA CARA, SIN BOCETO TEMPORAL
    // =========================================================

    private Wall CrearDesdePerfilDirectoConHuecos(
        Document doc,
        LoopMuro exterior,
        List<LoopMuro> huecos,
        WallType wallType,
        Level nivel,
        XYZ normal,
        bool permitirUnion)
    {
        if (doc == null ||
            exterior == null ||
            wallType == null ||
            nivel == null ||
            normal == null ||
            normal.GetLength() <= TOL ||
            !LoopSeguro(exterior))
        {
            return null;
        }

        List<Curve> perfil = new List<Curve>();
        perfil.AddRange(CurvasLoop(exterior, true));

        if (huecos != null)
        {
            foreach (LoopMuro hueco in huecos)
            {
                if (hueco == null || !LoopSeguro(hueco))
                    continue;

                perfil.AddRange(CurvasLoop(hueco, false));
            }
        }

        if (perfil.Count < 3)
            return null;

        MethodInfo metodoConNormal = typeof(Wall)
            .GetMethods(BindingFlags.Public | BindingFlags.Static)
            .Where(m => m.Name == "Create")
            .FirstOrDefault(m =>
            {
                ParameterInfo[] ps = m.GetParameters();

                return
                    ps.Length == 6 &&
                    ps[0].ParameterType == typeof(Document) &&
                    ps[1].ParameterType.IsAssignableFrom(typeof(List<Curve>)) &&
                    ps[2].ParameterType == typeof(ElementId) &&
                    ps[3].ParameterType == typeof(ElementId) &&
                    ps[4].ParameterType == typeof(bool) &&
                    ps[5].ParameterType == typeof(XYZ);
            });

        MethodInfo metodoSinNormal = typeof(Wall)
            .GetMethods(BindingFlags.Public | BindingFlags.Static)
            .Where(m => m.Name == "Create")
            .FirstOrDefault(m =>
            {
                ParameterInfo[] ps = m.GetParameters();

                return
                    ps.Length == 5 &&
                    ps[0].ParameterType == typeof(Document) &&
                    ps[1].ParameterType.IsAssignableFrom(typeof(List<Curve>)) &&
                    ps[2].ParameterType == typeof(ElementId) &&
                    ps[3].ParameterType == typeof(ElementId) &&
                    ps[4].ParameterType == typeof(bool);
            });

        if (metodoConNormal == null && metodoSinNormal == null)
            return null;

        Wall wall = null;

        try
        {
            using (Transaction tx = new Transaction(
                doc,
                "MYG Tarrajeo Cara Vertical"))
            {
                tx.Start();
                AplicarPreprocesadorSilencioso(tx);

                if (metodoConNormal != null)
                {
                    wall = metodoConNormal.Invoke(
                        null,
                        new object[]
                        {
                            doc,
                            perfil,
                            wallType.Id,
                            nivel.Id,
                            false,
                            normal.Normalize()
                        }) as Wall;
                }
                else
                {
                    wall = metodoSinNormal.Invoke(
                        null,
                        new object[]
                        {
                            doc,
                            perfil,
                            wallType.Id,
                            nivel.Id,
                            false
                        }) as Wall;
                }

                if (wall == null)
                {
                    tx.RollBack();
                    return null;
                }

                double zMinPerfil = exterior.Puntos3D.Min(p => p.Z);
                double zMaxPerfil = exterior.Puntos3D.Max(p => p.Z);

                // El overload de Wall.Create basado en perfil puede heredar una
                // restricción superior de otro nivel. Se fuerza No conectado y
                // la altura exacta del perfil antes de confirmar la transacción.
                ForzarRestriccionesExactas(
                    wall,
                    nivel,
                    zMinPerfil,
                    zMaxPerfil);

                doc.Regenerate();

                OrientarMuro(wall, normal);
                ConfigurarLineaUbicacionExterior(wall);
                ConfigurarUnion(wall, permitirUnion);
                GuardarIdEnParametro(wall, "GEN_ID Elemento");

                TransactionStatus estado = tx.Commit();

                if (estado != TransactionStatus.Committed)
                {
                    wall = null;
                    return null;
                }
            }

            if (wall != null)
                _idsCreadosDuranteLote.Add(wall.Id);

            return wall;
        }
        catch
        {
            // No se crea muro alternativo ni se entra a edición de boceto.
            return null;
        }
    }

    private Wall CrearConBoceto(
        Document doc,
        View vistaActiva,
        LoopMuro ext,
        List<LoopMuro> holes,
        WallType wallType,
        Level nivel,
        XYZ normal,
        bool permitirUnion,
        bool forzarSinUnionPorMuroCortante,
        HashSet<ElementId> murosCortantes)
    {
        Wall baseWall = CrearRectangular(doc, RectanguloContenedor(ext), wallType, nivel, normal, false);

        if (baseWall == null)
            return null;

        try
        {
            //-------------------------------------------------
            // V43:
            // El problema de las líneas que "se van al eje" aparece cuando
            // el muro base queda unido automáticamente con otro muro nativo.
            // Entonces el ProfileSketch queda asociado a una cara unida.
            // Se desune antes de crear/editar el boceto.
            //-------------------------------------------------
            DesunirGeometriaCercanaAntesDelBoceto(
                doc,
                vistaActiva,
                baseWall,
                ext,
                normal,
                wallType.Width);

            //-------------------------------------------------
            // V56:
            // Si hay Wall nativo cortante, desunir explícitamente antes
            // del ProfileSketch para evitar asociación con el eje del muro.
            //-------------------------------------------------
            if (forzarSinUnionPorMuroCortante)
                DesunirMurosCortantes(doc, baseWall, murosCortantes, true);

            using (Transaction tx = new Transaction(doc, "MYG Crear Boceto Muro"))
            {
                tx.Start();
                AplicarPreprocesador(tx);

                if (!CrearProfileSketch(baseWall))
                {
                    tx.RollBack();
                    BorrarSeguro(doc, baseWall);
                    return null;
                }

                tx.Commit();
            }

            ElementId sketchId = GetSketchId(baseWall);

            if (sketchId == ElementId.InvalidElementId)
            {
                BorrarSeguro(doc, baseWall);
                return null;
            }

            if (!ReemplazarSketch(doc, sketchId, ext, holes))
            {
                BorrarSeguro(doc, baseWall);
                return null;
            }

            //-------------------------------------------------
            // V56:
            // Revit puede recalcular uniones al aceptar el SketchEditScope.
            // Por eso se desune otra vez antes y después de la unión final.
            //-------------------------------------------------
            if (forzarSinUnionPorMuroCortante)
                DesunirMurosCortantes(doc, baseWall, murosCortantes, true);

            //-------------------------------------------------
            // V57:
            // El estado final de unión de extremos SÍ respeta el input.
            // Luego solo se desune la geometría con los muros cortantes,
            // sin volver a bloquear los extremos.
            //-------------------------------------------------
            AplicarUnionFinal(
                doc,
                baseWall,
                permitirUnion);

            if (forzarSinUnionPorMuroCortante)
                DesunirMurosCortantes(doc, baseWall, murosCortantes, false);

            return baseWall;
        }
        catch
        {
            BorrarSeguro(doc, baseWall);
            return null;
        }
    }

    private bool ReemplazarSketch(Document doc, ElementId sketchId, LoopMuro ext, List<LoopMuro> holes)
    {
        try
        {
            Sketch sketch = doc.GetElement(sketchId) as Sketch;

            if (sketch == null || sketch.SketchPlane == null)
                return false;

            // V36:
            // Validación final antes de entrar al SketchEditScope.
            // Si el perfil no es seguro, se cancela ANTES de que Revit abra
            // el modo boceto y muestre errores no ignorables.
            if (!PerfilSeguro(ext, holes))
                return false;

            SketchEditScope scope = new SketchEditScope(doc, "MYG Editar Perfil Tarrajeo");
            scope.Start(sketchId);

            using (Transaction tx = new Transaction(doc, "MYG Perfil Tarrajeo"))
            {
                tx.Start();
                AplicarPreprocesador(tx);

                sketch = doc.GetElement(sketchId) as Sketch;

                if (sketch == null || sketch.SketchPlane == null)
                {
                    tx.RollBack();
                    scope.Cancel();
                    return false;
                }

                List<ElementId> old = CurvasSketch(doc, sketch);

                if (old.Count > 0)
                    doc.Delete(old);

                foreach (Curve c in CurvasLoop(ext, true))
                    doc.Create.NewModelCurve(c, sketch.SketchPlane);

                foreach (LoopMuro h in holes)
                {
                    foreach (Curve c in CurvasLoop(h, false))
                        doc.Create.NewModelCurve(c, sketch.SketchPlane);
                }

                TransactionStatus estado = tx.Commit();

                if (estado != TransactionStatus.Committed)
                {
                    try { scope.Cancel(); } catch { }
                    return false;
                }
            }

            scope.Commit(new MYG_TarrajeoWarningsV29());
            return true;
        }
        catch
        {
            try { } catch { }
            return false;
        }
    }

    private LoopMuro RectanguloContenedor(LoopMuro src)
    {
        return LoopDesdeUV(new List<UV2>()
        {
            new UV2(src.MinU, src.MinV),
            new UV2(src.MaxU, src.MinV),
            new UV2(src.MaxU, src.MaxV),
            new UV2(src.MinU, src.MaxV),
            new UV2(src.MinU, src.MinV)
        }, src.Marco);
    }

    // =========================================================
    // SEGURIDAD DE PERFIL
    // =========================================================

    private bool PerfilSeguro(LoopMuro ext, List<LoopMuro> holes)
    {
        //-------------------------------------------------
        // V36:
        // No basta con que el boceto "se vea cerrado".
        // Revit rechaza el perfil si tiene:
        // - segmentos menores que ShortCurveTolerance,
        // - puntos colineales repetidos por boolean,
        // - loops interiores que tocan el exterior,
        // - líneas solapadas o cruzadas.
        //-------------------------------------------------

        if (!LoopSeguro(ext))
            return false;

        if (holes == null || holes.Count == 0)
            return true;

        List<LoopMuro> validos = new List<LoopMuro>();

        foreach (LoopMuro h in holes)
        {
            if (!LoopSeguro(h))
                return false;

            if (h.MinU <= ext.MinU + SKETCH_CLEARANCE ||
                h.MaxU >= ext.MaxU - SKETCH_CLEARANCE ||
                h.MinV <= ext.MinV + SKETCH_CLEARANCE ||
                h.MaxV >= ext.MaxV - SKETCH_CLEARANCE)
                return false;

            // El hueco debe estar completamente dentro; no puede tocar el exterior.
            for (int i = 0; i < h.Puntos2D.Count - 1; i++)
            {
                if (!PuntoEnPoligono(h.Puntos2D[i], ext.Puntos2D))
                    return false;
            }

            if (LoopsSeTocanOCruzan(ext, h, false))
                return false;

            foreach (LoopMuro otro in validos)
            {
                if (LoopsSeTocanOCruzan(otro, h, false))
                    return false;
            }

            validos.Add(h);
        }

        //-------------------------------------------------
        // V37:
        // Validación equivalente a lo que Revit intentará hacer.
        // Si esta extrusión temporal falla, NO se entra al modo boceto.
        //-------------------------------------------------
        if (!PerfilPuedeCrearExtrusion(ext, holes))
            return false;

        return true;
    }

    private bool PerfilPuedeCrearExtrusion(LoopMuro ext, List<LoopMuro> holes)
    {
        try
        {
            if (ext == null || ext.Marco == null || ext.Marco.Normal == null)
                return false;

            List<CurveLoop> loops = new List<CurveLoop>();

            CurveLoop clExt = CurveLoopDesdeLoop(ext, true, null);

            if (clExt == null || clExt.IsOpen())
                return false;

            loops.Add(clExt);

            if (holes != null)
            {
                foreach (LoopMuro h in holes)
                {
                    if (h == null)
                        continue;

                    CurveLoop clH = CurveLoopDesdeLoop(h, false, null);

                    if (clH == null || clH.IsOpen())
                        return false;

                    loops.Add(clH);
                }
            }

            Solid s = GeometryCreationUtilities.CreateExtrusionGeometry(
                loops,
                ext.Marco.Normal.Normalize(),
                0.05);

            return s != null && s.Volume > TOL;
        }
        catch
        {
            return false;
        }
    }

    private bool LoopSeguro(LoopMuro lp)
    {
        if (lp == null || lp.Puntos2D == null || lp.Puntos2D.Count < 4)
            return false;

        if (AreaAbs(lp.Puntos2D) <= 1e-6)
            return false;

        if (TieneSegmentosCortos(lp.Puntos2D))
            return false;

        if (LoopTieneCruces(lp.Puntos2D))
            return false;

        return true;
    }

    private bool TieneSegmentosCortos(List<UV2> pts)
    {
        if (pts == null || pts.Count < 4)
            return true;

        for (int i = 0; i < pts.Count - 1; i++)
        {
            if (Dist2D(pts[i], pts[i + 1]) <= PTOL)
                return true;
        }

        return false;
    }

    private bool LoopTieneCruces(List<UV2> pts)
    {
        if (pts == null || pts.Count < 4)
            return true;

        int n = pts.Count - 1;

        for (int i = 0; i < n; i++)
        {
            UV2 a1 = pts[i];
            UV2 a2 = pts[(i + 1) % n];

            for (int j = i + 1; j < n; j++)
            {
                bool adyacente =
                    j == i ||
                    j == i + 1 ||
                    (i == 0 && j == n - 1);

                if (adyacente)
                    continue;

                UV2 b1 = pts[j];
                UV2 b2 = pts[(j + 1) % n];

                if (SegmentosIntersectan2D(a1, a2, b1, b2, true))
                    return true;
            }
        }

        return false;
    }

    private bool LoopsSeTocanOCruzan(LoopMuro a, LoopMuro b, bool permitirToqueEnExtremos)
    {
        if (a == null || b == null || a.Puntos2D == null || b.Puntos2D == null)
            return true;

        int na = a.Puntos2D.Count - 1;
        int nb = b.Puntos2D.Count - 1;

        for (int i = 0; i < na; i++)
        {
            UV2 a1 = a.Puntos2D[i];
            UV2 a2 = a.Puntos2D[(i + 1) % na];

            for (int j = 0; j < nb; j++)
            {
                UV2 b1 = b.Puntos2D[j];
                UV2 b2 = b.Puntos2D[(j + 1) % nb];

                if (SegmentosIntersectan2D(a1, a2, b1, b2, permitirToqueEnExtremos))
                    return true;
            }
        }

        return false;
    }

    private bool SegmentosIntersectan2D(
        UV2 a,
        UV2 b,
        UV2 c,
        UV2 d,
        bool permitirSoloToqueExtremo)
    {
        // Orient2D tiene unidades de área. Dividir por la longitud convierte
        // el resultado en distancia a la recta, comparable con PTOL (pies).
        // Sin normalizar, segmentos cortos separados más de PTOL pueden
        // confundirse con líneas coincidentes al validar perfiles pequeños.
        double ab = Math.Max(Dist2D(a, b), TOL);
        double cd = Math.Max(Dist2D(c, d), TOL);
        double o1 = Orient2D(a, b, c) / ab;
        double o2 = Orient2D(a, b, d) / ab;
        double o3 = Orient2D(c, d, a) / cd;
        double o4 = Orient2D(c, d, b) / cd;

        bool col1 = Math.Abs(o1) <= PTOL;
        bool col2 = Math.Abs(o2) <= PTOL;
        bool col3 = Math.Abs(o3) <= PTOL;
        bool col4 = Math.Abs(o4) <= PTOL;

        if (col1 && col2 && col3 && col4)
        {
            double posicionC = ((c.U - a.U) * (b.U - a.U) +
                (c.V - a.V) * (b.V - a.V)) / ab;
            double posicionD = ((d.U - a.U) * (b.U - a.U) +
                (d.V - a.V) * (b.V - a.V)) / ab;
            double solape = Math.Min(ab, Math.Max(posicionC, posicionD)) -
                Math.Max(0.0, Math.Min(posicionC, posicionD));
            if (solape > PTOL)
                return true;
        }

        // Un extremo compartido puede estar permitido, pero no debe ocultar
        // otro extremo situado dentro del segmento (solape colineal).
        if (col1 && PuntoEnSegmento2D(c, a, b) &&
            (!permitirSoloToqueExtremo || !EsToqueDeExtremo(c, a, b)))
            return true;
        if (col2 && PuntoEnSegmento2D(d, a, b) &&
            (!permitirSoloToqueExtremo || !EsToqueDeExtremo(d, a, b)))
            return true;
        if (col3 && PuntoEnSegmento2D(a, c, d) &&
            (!permitirSoloToqueExtremo || !EsToqueDeExtremo(a, c, d)))
            return true;
        if (col4 && PuntoEnSegmento2D(b, c, d) &&
            (!permitirSoloToqueExtremo || !EsToqueDeExtremo(b, c, d)))
            return true;

        bool cruza =
            ((o1 > PTOL && o2 < -PTOL) || (o1 < -PTOL && o2 > PTOL)) &&
            ((o3 > PTOL && o4 < -PTOL) || (o3 < -PTOL && o4 > PTOL));

        return cruza;
    }

    private double Orient2D(UV2 a, UV2 b, UV2 c)
    {
        return ((b.U - a.U) * (c.V - a.V)) -
               ((b.V - a.V) * (c.U - a.U));
    }

    private bool PuntoEnSegmento2D(UV2 p, UV2 a, UV2 b)
    {
        if (p == null || a == null || b == null)
            return false;

        double longitud = Dist2D(a, b);
        if (longitud <= TOL)
            return Dist2D(p, a) <= PTOL;

        if (Math.Abs(Orient2D(a, b, p)) / longitud > PTOL)
            return false;

        double distanciaLongitudinal = ((p.U - a.U) * (b.U - a.U) +
            (p.V - a.V) * (b.V - a.V)) / longitud;
        return distanciaLongitudinal >= -PTOL &&
               distanciaLongitudinal <= longitud + PTOL;
    }

    private bool EsToqueDeExtremo(UV2 p, UV2 a, UV2 b)
    {
        return Dist2D(p, a) <= PTOL || Dist2D(p, b) <= PTOL;
    }

    private double Dist2D(UV2 a, UV2 b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        double du = a.U - b.U;
        double dv = a.V - b.V;

        return Math.Sqrt((du * du) + (dv * dv));
    }

    // =========================================================
    // UTILIDADES CURVAS / UV
    // =========================================================

    private List<Curve> CurvasLoop(LoopMuro lp, bool exterior)
    {
        List<XYZ> pts = lp.Puntos3D.ToList();

        if (pts.Count < 4)
            return new List<Curve>();

        if (pts[0].DistanceTo(pts[pts.Count - 1]) > PTOL)
            pts.Add(pts[0]);

        bool ccw = lp.Area > 0.0;

        if (exterior && !ccw)
            pts.Reverse();

        if (!exterior && ccw)
            pts.Reverse();

        List<Curve> curvas = new List<Curve>();

        for (int i = 0; i < pts.Count - 1; i++)
        {
            if (pts[i].DistanceTo(pts[i + 1]) > PTOL)
                curvas.Add(Line.CreateBound(pts[i], pts[i + 1]));
        }

        return curvas;
    }

    private CurveLoop CurveLoopDesdeLoop(LoopMuro lp, bool exterior, Transform tr)
    {
        CurveLoop cl = new CurveLoop();

        foreach (Curve c in CurvasLoop(lp, exterior))
        {
            Curve cc = tr != null ? c.CreateTransformed(tr) : c;

            if (cc != null && cc.Length > TOL)
                cl.Append(cc);
        }

        return cl;
    }

    private List<XYZ> TessFace(Face face, Transform tr)
    {
        List<XYZ> res = new List<XYZ>();

        try
        {
            foreach (CurveLoop cl in face.GetEdgesAsCurveLoops())
            {
                foreach (Curve c in cl)
                {
                    foreach (XYZ p0 in PuntosCurva(c))
                    {
                        XYZ p = tr != null ? tr.OfPoint(p0) : p0;

                        if (!res.Any(x => x.DistanceTo(p) <= PTOL))
                            res.Add(p);
                    }
                }
            }
        }
        catch
        {
        }

        return res;
    }

    private IList<XYZ> PuntosCurva(Curve c)
    {
        try
        {
            IList<XYZ> pts = c.Tessellate();

            if (pts != null && pts.Count > 0)
                return pts;
        }
        catch
        {
        }

        return new List<XYZ>() { c.GetEndPoint(0), c.GetEndPoint(1) };
    }

    private List<UV2> Limpiar(List<UV2> pts)
    {
        //-------------------------------------------------
        // V36:
        // Limpieza fuerte antes de dibujar el Profile Sketch.
        // Esto evita líneas demasiado cortas o solapadas por puntos
        // casi iguales/colineales que salen de boolean o tessellate.
        //-------------------------------------------------
        List<UV2> res = new List<UV2>();

        if (pts == null || pts.Count == 0)
            return res;

        bool cerrado = pts.Count > 2 && Igual(pts[0], pts[pts.Count - 1]);

        List<UV2> work = new List<UV2>();

        foreach (UV2 p in pts)
        {
            if (p == null)
                continue;

            if (work.Count == 0 || !Igual(work[work.Count - 1], p))
                work.Add(p);
        }

        if (work.Count > 2 && Igual(work[0], work[work.Count - 1]))
        {
            cerrado = true;
            work.RemoveAt(work.Count - 1);
        }

        bool cambio = true;
        int guard = 0;

        while (cambio && guard < 50)
        {
            guard++;
            cambio = false;

            //-------------------------------------------------
            // Quitar segmentos cortos.
            //-------------------------------------------------
            for (int i = 0; i < work.Count && work.Count > 2; i++)
            {
                int j = (i + 1) % work.Count;

                if (Dist2D(work[i], work[j]) <= PTOL)
                {
                    work.RemoveAt(j == 0 ? i : j);
                    cambio = true;
                    break;
                }
            }

            if (cambio)
                continue;

            //-------------------------------------------------
            // Quitar puntos colineales en la misma dirección.
            //-------------------------------------------------
            for (int i = 0; i < work.Count && work.Count > 2; i++)
            {
                UV2 a = work[(i - 1 + work.Count) % work.Count];
                UV2 b = work[i];
                UV2 c = work[(i + 1) % work.Count];

                if (EsPuntoColinealIntermedio(a, b, c))
                {
                    work.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        res.AddRange(work);

        if (cerrado && res.Count > 0 && !Igual(res[0], res[res.Count - 1]))
            res.Add(new UV2(res[0].U, res[0].V));

        return res;
    }

    private bool EsPuntoColinealIntermedio(UV2 a, UV2 b, UV2 c)
    {
        if (a == null || b == null || c == null)
            return false;

        double ab = Dist2D(a, b);
        double bc = Dist2D(b, c);

        if (ab <= PTOL || bc <= PTOL)
            return true;

        double cross = Math.Abs(Orient2D(a, b, c));

        if (cross > PTOL * Math.Max(ab, bc))
            return false;

        double du1 = b.U - a.U;
        double dv1 = b.V - a.V;
        double du2 = c.U - b.U;
        double dv2 = c.V - b.V;

        double dot = (du1 * du2) + (dv1 * dv2);

        return dot >= -PTOL;
    }

    private bool Igual(UV2 a, UV2 b)
    {
        // La tolerancia es radial; comparar ejes por separado fusionaba
        // extremos diagonales separados hasta sqrt(2) * PTOL.
        return a != null && b != null && Dist2D(a, b) <= PTOL;
    }

    private double Area(List<UV2> pts)
    {
        if (pts == null || pts.Count < 4)
            return 0.0;

        double a = 0.0;

        for (int i = 0; i < pts.Count - 1; i++)
            a += pts[i].U * pts[i + 1].V - pts[i + 1].U * pts[i].V;

        return a / 2.0;
    }

    private double AreaAbs(List<UV2> pts)
    {
        return Math.Abs(Area(pts));
    }

    private UV2 Centro(LoopMuro lp)
    {
        double u = 0.0;
        double v = 0.0;
        int n = 0;

        for (int i = 0; i < lp.Puntos2D.Count - 1; i++)
        {
            u += lp.Puntos2D[i].U;
            v += lp.Puntos2D[i].V;
            n++;
        }

        return new UV2(u / Math.Max(n, 1), v / Math.Max(n, 1));
    }

    private bool PuntoEnPoligono(UV2 p, List<UV2> poly)
    {
        bool inside = false;

        for (int i = 0, j = poly.Count - 2; i < poly.Count - 1; j = i++)
        {
            UV2 pi = poly[i];
            UV2 pj = poly[j];

            bool intersect = ((pi.V > p.V) != (pj.V > p.V)) &&
                             (p.U < (pj.U - pi.U) * (p.V - pi.V) / ((pj.V - pi.V) + 1e-12) + pi.U);

            if (intersect)
                inside = !inside;
        }

        return inside;
    }

    private bool Similar(LoopMuro a, LoopMuro b)
    {
        if (a == null || b == null || a.Puntos2D == null || b.Puntos2D == null ||
            a.Puntos2D.Count != b.Puntos2D.Count)
            return false;

        int n = a.Puntos2D.Count - 1;
        if (n < 3)
            return false;
        for (int inicio = 0; inicio < n; inicio++)
        {
            bool directo = true;
            bool inverso = true;
            for (int i = 0; i < n; i++)
            {
                directo &= Igual(a.Puntos2D[i], b.Puntos2D[(inicio + i) % n]);
                inverso &= Igual(a.Puntos2D[i], b.Puntos2D[(inicio - i + n) % n]);
            }
            if (directo || inverso)
                return true;
        }
        return false;
    }

    private bool EsRectangulo(LoopMuro lp)
    {
        if (lp == null || lp.Puntos2D == null ||
            lp.MaxU - lp.MinU <= PTOL || lp.MaxV - lp.MinV <= PTOL)
            return false;

        List<UV2> unicos = new List<UV2>();

        foreach (UV2 p in lp.Puntos2D)
        {
            if (!unicos.Any(x => Igual(x, p)))
                unicos.Add(p);
        }

        if (unicos.Count != 4)
            return false;

        List<UV2> esquinas = new List<UV2>
        {
            new UV2(lp.MinU, lp.MinV), new UV2(lp.MaxU, lp.MinV),
            new UV2(lp.MaxU, lp.MaxV), new UV2(lp.MinU, lp.MaxV)
        };
        double ancho = lp.MaxU - lp.MinU;
        double alto = lp.MaxV - lp.MinV;
        return esquinas.All(e => unicos.Any(p => Igual(e, p))) &&
            Math.Abs(lp.AreaAbs - ancho * alto) <= PTOL * (ancho + alto);
    }

    private XYZ Punto(LoopMuro lp, double u, double v)
    {
        return lp.Marco.Origen + lp.Marco.U.Multiply(u) + lp.Marco.V.Multiply(v);
    }

    // =========================================================
    // OUTLINE / CARAS RESULTANTES
    // =========================================================


    private bool SolidTocaOutline(Solid solid, Outline outline)
    {
        try
        {
            if (solid == null || outline == null)
                return false;

            BoundingBoxXYZ bb = solid.GetBoundingBox();

            if (bb == null)
                return true;

            Transform tr = bb.Transform ?? Transform.Identity;
            XYZ mn = bb.Min;
            XYZ mx = bb.Max;

            List<XYZ> pts = new List<XYZ>()
            {
                tr.OfPoint(new XYZ(mn.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mx.Z))
            };

            XYZ sMin = new XYZ(pts.Min(p => p.X), pts.Min(p => p.Y), pts.Min(p => p.Z));
            XYZ sMax = new XYZ(pts.Max(p => p.X), pts.Max(p => p.Y), pts.Max(p => p.Z));

            XYZ oMin = outline.MinimumPoint;
            XYZ oMax = outline.MaximumPoint;

            return !(sMax.X < oMin.X || sMin.X > oMax.X ||
                     sMax.Y < oMin.Y || sMin.Y > oMax.Y ||
                     sMax.Z < oMin.Z || sMin.Z > oMax.Z);
        }
        catch
        {
            return true;
        }
    }

    private Outline OutlineDesdeLoop(LoopMuro lp, XYZ normal, double d)
    {
        try
        {
            List<XYZ> pts = new List<XYZ>();

            foreach (XYZ p in lp.Puntos3D)
            {
                pts.Add(p);
                pts.Add(p + normal.Multiply(d));
                pts.Add(p - normal.Multiply(d));
            }

            return new Outline(
                new XYZ(pts.Min(p => p.X) - SEARCH_MARGIN, pts.Min(p => p.Y) - SEARCH_MARGIN, pts.Min(p => p.Z) - SEARCH_MARGIN),
                new XYZ(pts.Max(p => p.X) + SEARCH_MARGIN, pts.Max(p => p.Y) + SEARCH_MARGIN, pts.Max(p => p.Z) + SEARCH_MARGIN));
        }
        catch
        {
            return null;
        }
    }

    private Outline TransformarOutline(Outline o, Transform tr)
    {
        try
        {
            XYZ mn = o.MinimumPoint;
            XYZ mx = o.MaximumPoint;

            List<XYZ> pts = new List<XYZ>()
            {
                tr.OfPoint(new XYZ(mn.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mn.Z)),
                tr.OfPoint(new XYZ(mn.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mn.Y, mx.Z)),
                tr.OfPoint(new XYZ(mn.X, mx.Y, mx.Z)),
                tr.OfPoint(new XYZ(mx.X, mx.Y, mx.Z))
            };

            return new Outline(
                new XYZ(pts.Min(p => p.X), pts.Min(p => p.Y), pts.Min(p => p.Z)),
                new XYZ(pts.Max(p => p.X), pts.Max(p => p.Y), pts.Max(p => p.Z)));
        }
        catch
        {
            return null;
        }
    }

    private List<PlanarFace> CarasPerfil(Solid s, XYZ normal, XYZ origen, double semiEspesor)
    {
        List<PlanarFace> cand = new List<PlanarFace>();

        try
        {
            if (s == null || normal == null || origen == null)
                return cand;

            normal = normal.Normalize();
            semiEspesor = Math.Max(semiEspesor, 0.005);

            foreach (Face f in s.Faces)
            {
                PlanarFace pf = f as PlanarFace;

                if (pf == null)
                    continue;

                XYZ n = pf.FaceNormal.Normalize();

                if (Math.Abs(n.DotProduct(normal)) < 0.98)
                    continue;

                if (pf.Area <= 1e-8)
                    continue;

                cand.Add(pf);
            }

            if (cand.Count == 0)
                return cand;

            //-------------------------------------------------
            // V40:
            // El sólido temporal del tarrajeo se crea desde -semiEspesor
            // hasta +semiEspesor respecto al plano de creación.
            //
            // Si después del boolean se toma la cara paralela más cercana
            // al origen, se puede agarrar una cara generada por el eje/centro
            // del elemento que intersecta. Eso produce dos líneas casi
            // superpuestas y segmentos de 0 m.
            //
            // Por eso se priorizan las caras paralelas que están realmente
            // sobre las superficies físicas del tarrajeo: distancia cercana
            // a +/- semiEspesor.
            //-------------------------------------------------
            double toleranciaPlano = Math.Max(0.02, semiEspesor * 0.75);

            var carasDelTarrajeo = cand
                .Select(pf => new
                {
                    Face = pf,
                    D = (pf.Origin - origen).DotProduct(normal)
                })
                .Where(x => Math.Abs(Math.Abs(x.D) - semiEspesor) <= toleranciaPlano)
                .ToList();

            if (carasDelTarrajeo.Count > 0)
            {
                //-------------------------------------------------
                // Agrupar por plano y tomar el grupo con mayor área.
                // Si hay dos caras del tarrajeo, ambas proyectan al
                // mismo plano UV; tomar la mayor evita piezas pequeñas
                // internas del sólido que corta.
                //-------------------------------------------------
                double agrupacion = 0.01;

                var grupo = carasDelTarrajeo
                    .GroupBy(x => Math.Round(x.D / agrupacion) * agrupacion)
                    .Select(g => new
                    {
                        Key = g.Key,
                        AreaTotal = g.Sum(x => x.Face.Area),
                        Faces = g.Select(x => x.Face).ToList()
                    })
                    .OrderByDescending(g => g.AreaTotal)
                    .FirstOrDefault();

                if (grupo != null && grupo.Faces != null && grupo.Faces.Count > 0)
                {
                    return grupo.Faces
                        .OrderByDescending(pf => pf.Area)
                        .ToList();
                }
            }

            //-------------------------------------------------
            // Fallback más seguro que el antiguo:
            // tomar la cara paralela de mayor área, no la más cercana
            // al origen/eje.
            //-------------------------------------------------
            return cand
                .OrderByDescending(pf => pf.Area)
                .ToList();
        }
        catch
        {
            return new List<PlanarFace>();
        }
    }

    // =========================================================
    // REFERENCIAS / TRANSFORMS
    // =========================================================

    private Face ObtenerFaceDesdeReferencia(Document doc, Reference r, out Element host, out Transform tr)
    {
        host = null;
        tr = Transform.Identity;
        ConfigurarOrigenDeRecorte(null, null);

        if (doc == null || r == null)
            return null;

        host = doc.GetElement(r.ElementId);

        if (host == null)
            return null;

        RevitLinkInstance link = host as RevitLinkInstance;

        if (link != null)
        {
            Document ld = link.GetLinkDocument();

            if (ld == null || r.LinkedElementId == ElementId.InvalidElementId)
                return null;

            Element le = ld.GetElement(r.LinkedElementId);

            if (le == null)
                return null;

            ConfigurarOrigenesDeRecorte(
                ObtenerConjuntoEscaleraDesdeCualquierComponente(le),
                link);
            tr = link.GetTotalTransform().Multiply(TransformInSitu(le));

            try
            {
                Face f = le.GetGeometryObjectFromReference(r.CreateReferenceInLink()) as Face;

                if (f != null)
                    return f;
            }
            catch
            {
            }

            return null;
        }

        ConfigurarOrigenesDeRecorte(
            ObtenerConjuntoEscaleraDesdeCualquierComponente(host),
            null);

        try
        {
            Face f = host.GetGeometryObjectFromReference(r) as Face;

            if (f != null)
            {
                tr = TransformInSitu(host);
                return f;
            }
        }
        catch
        {
        }

        return null;
    }

    // =========================================================
    // V73 - CONJUNTO COMPLETO DE ESCALERA PARA PICK POR CARA
    // =========================================================

    private List<Element> ObtenerConjuntoEscaleraDesdeCualquierComponente(
        Element elemento)
    {
        List<Element> resultado = new List<Element>();

        if (elemento == null || elemento.Document == null)
            return resultado;

        Element raiz = BuscarEscaleraRaiz(elemento);

        if (raiz == null)
        {
            resultado.Add(elemento);
            return resultado;
        }

        resultado.Add(raiz);

        HashSet<ElementId> ids = new HashSet<ElementId>();
        AgregarIdsMetodoEscalera(raiz, "GetStairsRuns", ids);
        AgregarIdsMetodoEscalera(raiz, "GetStairsLandings", ids);
        AgregarIdsMetodoEscalera(raiz, "GetStairsSupports", ids);

        foreach (ElementId id in ids)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            Element componente = raiz.Document.GetElement(id);

            if (componente != null &&
                !resultado.Any(x => x != null && x.Id.Equals(componente.Id)))
            {
                resultado.Add(componente);
            }
        }

        if (!resultado.Any(x => x != null && x.Id.Equals(elemento.Id)))
            resultado.Add(elemento);

        return resultado;
    }

    private Element BuscarEscaleraRaiz(Element elemento)
    {
        if (elemento == null || elemento.Document == null)
            return null;

        if (TieneMetodosComponentesEscalera(elemento))
            return elemento;

        try
        {
            IList<Element> escaleras =
                new FilteredElementCollector(elemento.Document)
                    .OfCategory(BuiltInCategory.OST_Stairs)
                    .WhereElementIsNotElementType()
                    .ToElements();

            foreach (Element escalera in escaleras)
            {
                if (escalera == null)
                    continue;

                HashSet<ElementId> ids = new HashSet<ElementId>();
                AgregarIdsMetodoEscalera(escalera, "GetStairsRuns", ids);
                AgregarIdsMetodoEscalera(escalera, "GetStairsLandings", ids);
                AgregarIdsMetodoEscalera(escalera, "GetStairsSupports", ids);

                if (ids.Contains(elemento.Id))
                    return escalera;
            }
        }
        catch
        {
        }

        return null;
    }

    private bool TieneMetodosComponentesEscalera(Element elemento)
    {
        if (elemento == null)
            return false;

        try
        {
            Type tipo = elemento.GetType();

            return
                tipo.GetMethod("GetStairsRuns", Type.EmptyTypes) != null ||
                tipo.GetMethod("GetStairsLandings", Type.EmptyTypes) != null ||
                tipo.GetMethod("GetStairsSupports", Type.EmptyTypes) != null;
        }
        catch
        {
            return false;
        }
    }

    private bool EsElementoDeConjuntoEscalera(Element elemento)
    {
        if (elemento == null)
            return false;

        try
        {
            if (TieneMetodosComponentesEscalera(elemento))
                return true;

            string nombreTipo = elemento.GetType().Name ?? string.Empty;

            if (nombreTipo.IndexOf("Stairs", StringComparison.OrdinalIgnoreCase) >= 0 ||
                nombreTipo.IndexOf("Stair", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }

            if (elemento.Category != null)
            {
                string nombreCategoria = elemento.Category.Name ?? string.Empty;

                if (nombreCategoria.IndexOf("escaler", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    nombreCategoria.IndexOf("stair", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }
        }
        catch
        {
        }

        return false;
    }

    private void AgregarIdsMetodoEscalera(
        Element escalera,
        string nombreMetodo,
        HashSet<ElementId> ids)
    {
        if (escalera == null ||
            string.IsNullOrWhiteSpace(nombreMetodo) ||
            ids == null)
        {
            return;
        }

        try
        {
            MethodInfo metodo = escalera.GetType().GetMethod(
                nombreMetodo,
                BindingFlags.Instance | BindingFlags.Public,
                null,
                Type.EmptyTypes,
                null);

            if (metodo == null)
                return;

            object valor = metodo.Invoke(escalera, null);
            IEnumerable enumerable = valor as IEnumerable;

            if (enumerable == null)
                return;

            foreach (object obj in enumerable)
            {
                ElementId id = obj as ElementId;

                if (id != null && id != ElementId.InvalidElementId)
                    ids.Add(id);
            }
        }
        catch
        {
        }
    }

    private Transform TransformInSitu(Element e)
    {
        try
        {
            FamilyInstance fi = e as FamilyInstance;

            if (fi != null && fi.Symbol != null && fi.Symbol.Family != null && fi.Symbol.Family.IsInPlace)
                return fi.GetTransform();
        }
        catch
        {
        }

        return Transform.Identity;
    }

    private XYZ ObtenerPrimerPunto(PlanarFace cara, Transform tr)
    {
        try
        {
            foreach (CurveLoop cl in cara.GetEdgesAsCurveLoops())
            {
                foreach (Curve c in cl)
                    return tr.OfPoint(c.GetEndPoint(0));
            }
        }
        catch
        {
        }

        return tr.OfPoint(cara.Origin);
    }

    // =========================================================
    // SKETCH API
    // =========================================================

    private bool CrearProfileSketch(Wall wall)
    {
        try
        {
            MethodInfo can = typeof(Wall).GetMethod("CanHaveProfileSketch", BindingFlags.Public | BindingFlags.Instance);

            if (can != null)
            {
                object r = can.Invoke(wall, null);

                if (r is bool && !(bool)r)
                    return false;
            }

            MethodInfo mi = typeof(Wall).GetMethod(
                "CreateProfileSketch",
                BindingFlags.Public | BindingFlags.Instance,
                null,
                Type.EmptyTypes,
                null);

            if (mi == null)
                return false;

            mi.Invoke(wall, null);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private ElementId GetSketchId(Wall wall)
    {
        try
        {
            PropertyInfo pi = typeof(Wall).GetProperty("SketchId", BindingFlags.Public | BindingFlags.Instance);

            if (pi != null)
            {
                ElementId id = pi.GetValue(wall, null) as ElementId;

                if (id != null)
                    return id;
            }
        }
        catch
        {
        }

        return ElementId.InvalidElementId;
    }

    private List<ElementId> CurvasSketch(Document doc, Sketch sketch)
    {
        List<ElementId> ids = new List<ElementId>();

        try
        {
            MethodInfo mi = typeof(Sketch).GetMethod("GetAllElements", BindingFlags.Public | BindingFlags.Instance);

            if (mi != null)
            {
                IEnumerable en = mi.Invoke(sketch, null) as IEnumerable;

                if (en != null)
                {
                    foreach (object o in en)
                    {
                        ElementId id = o as ElementId;

                        if (id != null && doc.GetElement(id) is CurveElement)
                            ids.Add(id);
                    }
                }
            }
        }
        catch
        {
        }

        if (ids.Count > 0)
            return ids;

        try
        {
            foreach (ElementId id in sketch.GetDependentElements(null))
            {
                if (doc.GetElement(id) is CurveElement)
                    ids.Add(id);
            }
        }
        catch
        {
        }

        return ids;
    }

    // =========================================================
    // NIVELES / UNIONES / PARÁMETROS
    // =========================================================

    private Level ObtenerNivelBase(Document doc, double z)
    {
        List<Level> niveles = new FilteredElementCollector(doc)
            .OfClass(typeof(Level))
            .Cast<Level>()
            .OrderBy(x => x.ProjectElevation)
            .ToList();

        return niveles
            .Where(x => x.ProjectElevation <= z + 0.10)
            .OrderByDescending(x => x.ProjectElevation)
            .FirstOrDefault()
            ?? niveles.FirstOrDefault();
    }

    private void ForzarRestriccionesExactas(
        Wall wall,
        Level nivel,
        double zMin,
        double zMax)
    {
        if (wall == null || nivel == null)
            return;

        double altura = zMax - zMin;

        if (altura <= TOL)
            return;

        try
        {
            Parameter pBase = wall.get_Parameter(
                BuiltInParameter.WALL_BASE_CONSTRAINT);

            if (pBase != null &&
                !pBase.IsReadOnly &&
                pBase.StorageType == StorageType.ElementId)
            {
                pBase.Set(nivel.Id);
            }
        }
        catch
        {
        }

        try
        {
            Parameter pBaseOffset = wall.get_Parameter(
                BuiltInParameter.WALL_BASE_OFFSET);

            if (pBaseOffset != null &&
                !pBaseOffset.IsReadOnly &&
                pBaseOffset.StorageType == StorageType.Double)
            {
                pBaseOffset.Set(TarrajeoAlturas.CalcularDesfaseMuro(
                    zMin, nivel.ProjectElevation));
            }
        }
        catch
        {
        }

        try
        {
            Parameter pTop = wall.get_Parameter(
                BuiltInParameter.WALL_HEIGHT_TYPE);

            if (pTop != null &&
                !pTop.IsReadOnly &&
                pTop.StorageType == StorageType.ElementId)
            {
                pTop.Set(ElementId.InvalidElementId);
            }
        }
        catch
        {
        }

        try
        {
            Parameter pTopOffset = wall.get_Parameter(
                BuiltInParameter.WALL_TOP_OFFSET);

            if (pTopOffset != null &&
                !pTopOffset.IsReadOnly &&
                pTopOffset.StorageType == StorageType.Double)
            {
                pTopOffset.Set(0.0);
            }
        }
        catch
        {
        }

        try
        {
            Parameter pAltura = wall.get_Parameter(
                BuiltInParameter.WALL_USER_HEIGHT_PARAM);

            if (pAltura != null &&
                !pAltura.IsReadOnly &&
                pAltura.StorageType == StorageType.Double)
            {
                pAltura.Set(altura);
            }
        }
        catch
        {
        }
    }

    private void OrientarMuro(Wall wall, XYZ normal)
    {
        if (wall == null || normal == null || normal.GetLength() <= TOL)
            throw new InvalidOperationException("No se pudo determinar el exterior del tarrajeo.");

        Document doc = wall.Document;
        XYZ exteriorObjetivo = normal.Normalize();

        // El tipo conserva su estructura: su primera capa exterior (por ejemplo
        // Acabado 2 / pintura) debe mirar fuera de la cara del elemento revestido.
        // Voltear respecto al eje evita desplazar físicamente el revestimiento
        // cuando Revit hereda otra línea de ubicación al crear el muro.
        Parameter ubicacion = wall.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);
        if (ubicacion == null || ubicacion.IsReadOnly ||
            ubicacion.StorageType != StorageType.Integer)
        {
            throw new InvalidOperationException("No se pudo fijar el eje del muro de tarrajeo.");
        }

        ubicacion.Set(0); // Wall Centerline; después se restaura Cara de acabado: Exterior.
        doc.Regenerate();

        // Se usa la cara exterior física regenerada. Wall.Orientation devuelve
        // la normal en el INICIO del muro y no sirve para comparar con la normal
        // central de un arco. Tampoco se ignoran los errores de un Flip fallido.
        double alineacion = ObtenerNormalExteriorMuro(wall).DotProduct(exteriorObjetivo);
        if (alineacion < -TOL)
        {
            wall.Flip();
            doc.Regenerate();
            alineacion = ObtenerNormalExteriorMuro(wall).DotProduct(exteriorObjetivo);
        }

        if (alineacion <= TOL)
        {
            // El llamador revierte la transacción en vez de conservar un muro
            // cuya pintura no se ha podido orientar al exterior.
            throw new InvalidOperationException("La cara exterior del tarrajeo no quedó orientada hacia fuera.");
        }
    }

    private XYZ ObtenerNormalExteriorMuro(Wall wall)
    {
        LocationCurve ubicacion = wall.Location as LocationCurve;
        XYZ puntoMedio = ubicacion != null && ubicacion.Curve != null
            ? ubicacion.Curve.Evaluate(0.5, true)
            : null;

        Face caraExterior = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Exterior)
            .Select(referencia => wall.GetGeometryObjectFromReference(referencia) as Face)
            .Where(cara => cara != null)
            .OrderByDescending(cara => cara.Area)
            .FirstOrDefault();

        if (caraExterior == null)
            throw new InvalidOperationException("No se encontró la cara exterior del muro de tarrajeo.");

        PlanarFace plana = caraExterior as PlanarFace;
        if (plana != null)
            return plana.FaceNormal.Normalize();

        if (puntoMedio == null)
            throw new InvalidOperationException("No se encontró el eje del muro curvo de tarrajeo.");

        // Proyectar el punto medio del eje sobre la superficie exterior permite
        // comparar normales en la misma sección del arco, sea convexa o cóncava.
        IntersectionResult proyeccion = caraExterior.Project(puntoMedio);
        if (proyeccion == null)
            throw new InvalidOperationException("No se pudo comprobar la cara exterior del muro curvo.");

        XYZ normalExterior = caraExterior.ComputeNormal(proyeccion.UVPoint);
        if (normalExterior == null || normalExterior.GetLength() <= TOL)
            throw new InvalidOperationException("La cara exterior del muro no tiene una normal válida.");

        return normalExterior.Normalize();
    }

    private void ConfigurarLineaUbicacionExterior(Wall wall)
    {
        if (wall == null)
            return;

        try
        {
            Parameter p = wall.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);

            if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Integer)
                p.Set(LOC_FINISH_FACE_EXTERIOR);
        }
        catch
        {
        }
    }

    private void ConfigurarUnion(Wall wall, bool permitir)
    {
        if (wall == null)
            return;

        try
        {
            if (permitir)
            {
                WallUtils.AllowWallJoinAtEnd(wall, 0);
                WallUtils.AllowWallJoinAtEnd(wall, 1);
            }
            else
            {
                WallUtils.DisallowWallJoinAtEnd(wall, 0);
                WallUtils.DisallowWallJoinAtEnd(wall, 1);
            }
        }
        catch
        {
        }
    }

    private void AplicarUnionFinal(Document doc, Wall wall, bool permitir)
    {
        try
        {
            using (Transaction tx = new Transaction(doc, "MYG Unión Final Tarrajeo"))
            {
                tx.Start();
                AplicarPreprocesador(tx);
                ConfigurarUnion(wall, permitir);
                GuardarIdEnParametro(wall, "GEN_ID Elemento");
                tx.Commit();
            }
        }
        catch
        {
        }
    }

    private void GuardarId(Document doc, Element e)
    {
        try
        {
            using (Transaction tx = new Transaction(doc, "MYG Guardar ID Tarrajeo"))
            {
                tx.Start();
                AplicarPreprocesador(tx);
                GuardarIdEnParametro(e, "GEN_ID Elemento");
                tx.Commit();
            }
        }
        catch
        {
        }
    }

    private void GuardarIdEnParametro(Element e, string nombre)
    {
        try
        {
            Parameter p = e.LookupParameter(nombre);

            if (p == null || p.IsReadOnly)
                return;

            string id = e.Id.ToString();

            if (p.StorageType == StorageType.String)
                p.Set(id);
            else if (p.StorageType == StorageType.Integer)
            {
                int v;
                if (int.TryParse(id, out v))
                    p.Set(v);
            }
            else if (p.StorageType == StorageType.ElementId)
                p.Set(e.Id);
        }
        catch
        {
        }
    }

    private void BorrarSeguro(Document doc, Element e)
    {
        try
        {
            if (doc == null || e == null)
                return;

            ElementId id = e.Id;

            using (Transaction tx = new Transaction(doc, "MYG Limpiar Tarrajeo Fallido"))
            {
                tx.Start();
                MYG_TarrajeoFallosSilenciosos.Configurar(tx);
                doc.Delete(id);
                tx.Commit();
            }

            _idsCreadosDuranteLote.Remove(id);
        }
        catch
        {
        }
    }

    private void AplicarPreprocesadorSilencioso(Transaction tx)
    {
        MYG_TarrajeoFallosSilenciosos.Configurar(tx);
    }

    private void AplicarPreprocesador(Transaction tx)
    {
        MYG_TarrajeoFallosSilenciosos.Configurar(tx);
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
                Form.Show();
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Tarrajeo Muros Handler V64 Simple Caras Verticales";
    }

    private double NormAng(double a)
    {
        double d = 2.0 * Math.PI;

        while (a < 0)
            a += d;

        while (a >= d)
            a -= d;

        return a;
    }

    private bool RangoAngMenor(List<double> angs, out double ini, out double fin)
    {
        ini = 0;
        fin = 0;

        List<double> a = angs.Select(NormAng).OrderBy(x => x).Distinct().ToList();

        if (a.Count < 2)
            return false;

        double d = 2.0 * Math.PI;
        double gap = -1;
        int idx = 0;

        for (int i = 0; i < a.Count; i++)
        {
            double next = i == a.Count - 1 ? a[0] + d : a[i + 1];
            double g = next - a[i];

            if (g > gap)
            {
                gap = g;
                idx = i;
            }
        }

        ini = a[(idx + 1) % a.Count];
        fin = a[idx];

        if (fin <= ini)
            fin += d;

        return fin - ini < d - 0.001;
    }
}

// =========================================================
// CLASES AUXILIARES
// =========================================================

public class MarcoMuro
{
    public XYZ Origen;
    public XYZ U;
    public XYZ V;
    public XYZ Normal;
}

public class LoopMuro
{
    public MarcoMuro Marco;
    // Solo para resultados del respaldo Clipper. No se reconstruye desde XYZ
    // ni se vuelve a cuantizar antes de comprobar cruces y contactos.
    internal List<MYG_Addin.RecorteClipper.IntPoint> CaminoRecorte2D;
    public List<UV2> Puntos2D;
    public List<XYZ> Puntos3D;
    public double Area;
    public double AreaAbs;
    public double MinU;
    public double MaxU;
    public double MinV;
    public double MaxV;
}

public class ComponenteMuro
{
    public LoopMuro Exterior;
    public List<LoopMuro> Huecos;
}

public class UV2
{
    public double U;
    public double V;

    public UV2(double u, double v)
    {
        U = u;
        V = v;
    }
}

public class MYG_TarrajeoSilenciosoV64 : IFailuresPreprocessor
{
    private readonly MYG_TarrajeoPreprocesadorMasivo _interno =
        new MYG_TarrajeoPreprocesadorMasivo();

    public FailureProcessingResult PreprocessFailures(
        FailuresAccessor failuresAccessor)
    {
        return _interno.PreprocessFailures(failuresAccessor);
    }
}

public class MYG_TarrajeoWarningsV29 : IFailuresPreprocessor
{
    private readonly MYG_TarrajeoPreprocesadorMasivo _interno =
        new MYG_TarrajeoPreprocesadorMasivo();

    public FailureProcessingResult PreprocessFailures(
        FailuresAccessor failuresAccessor)
    {
        return _interno.PreprocessFailures(failuresAccessor);
    }
}
