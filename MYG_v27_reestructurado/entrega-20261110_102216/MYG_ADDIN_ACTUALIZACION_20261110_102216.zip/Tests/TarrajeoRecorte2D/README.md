# Regresión del recorte planar de tarrajeo

Ejecutar desde el checkout con SDK .NET 10:

```bash
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj
```

No requiere paquetes NuGet adicionales, Revit ni Windows. El proyecto usa Roslyn incluido en el SDK, extrae los métodos reales del handler y las cuatro clases de datos del código fuente actual, e incluye `Clipper.cs` directamente al compilar en memoria. Solo se sustituye `XYZ` por un contenedor mínimo de coordenadas: no se simulan transacciones ni el kernel geométrico de Revit.

Para comprobar la regresión contra una versión anterior del archivo:

```bash
git show HEAD:MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs > /tmp/Tarrajeo_MurosHandler-anterior.cs
dotnet run --project Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj -- --source /tmp/Tarrajeo_MurosHandler-anterior.cs
```

El proceso termina con código 1 si falla cualquier caso, 2 si no compila el código extraído y 0 cuando todos pasan. Los casos sintéticos demuestran el rechazo indebido de concavidades con bordes próximos, y comprueban cruces reales, contactos exactos, aristas cortas, residuos diminutos, diferencias, huecos e islas. No reproducen el modelo particular de la captura ni acreditan creación de suelos en Revit.

El caso de integración resta dos triángulos grandes a un perfil de 10×10 pies. Sus puntas quedan separadas 0.0000005 pies: la diferencia debe conservar una pieza de área 65 pies² sin omitirla. El perfil y ambos cortantes son entradas válidas; así se comprueba el recorrido completo de diferencia y validación, además de los casos directos del validador.

Resultados ejecutados con SDK 10.0.403: contra el commit base `cb9d73137e06f55741862274e4ee839bb87e5d80`, 12 casos pasan y 5 fallan (salida 1); contra el handler corregido, 17 de 17 pasan (salida 0). Antes, el caso de integración omitía la pieza completa por un supuesto cruce; después conserva una pieza y cero omisiones, con área 65 pies².
