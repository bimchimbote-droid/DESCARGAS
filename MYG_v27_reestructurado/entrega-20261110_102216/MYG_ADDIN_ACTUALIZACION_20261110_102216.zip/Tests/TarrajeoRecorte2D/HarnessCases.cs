using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using MYG_Addin.RecorteClipper;

public static class GeometryCases
{
    private const double Scale = 10000000.0;
    private static int passed, failed;
    private static readonly TarrajeoHarness Motor = new TarrajeoHarness();
    private static readonly MarcoMuro Frame = new MarcoMuro {
        Origen=new XYZ(0,0,0), U=new XYZ(1,0,0), V=new XYZ(0,1,0), Normal=new XYZ(0,0,1)
    };

    public static int Run()
    {
        Case("near-touch valid concavity: one grid", () => ValidateNearTouch(1));
        Case("near-touch valid concavity: five grids", () => ValidateNearTouch(5));
        Case("near-touch valid concavity: ten grids", () => ValidateNearTouch(10));
        Case("integer topology is independent of UV origin", () => ValidateNearTouch(1,100000));
        Case("difference preserves material between near-touching cuts", () => {
            var r=Difference(Component(Rect(0,0,10,10)),
                Component(Loop(-1,2.6, 5,5, -1,7.4)),
                Component(Loop(0,10, 5.0000005,5, 10,10)));
            Check(r,1,0,65);
        });
        Case("real crossing remains rejected", () => {
            var loop=Loop(0,0, 5,5, 0,5, 5,0, 8,0, 8,8, 0,8);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out var reason),"Self-crossing loop was accepted: "+reason);
        });
        Case("exact contact remains rejected", () => {
            var loop=Loop(0,0, 10,0, 10,10, 5,5, 0,10, 0,7, 5,5, 0,3);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out _),"Repeated non-adjacent vertex was accepted.");
        });
        Case("legitimate short edge remains rejected", () => {
            var loop=Loop(0,0, .001,0, .001,10, 0,10);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out var reason) && reason.Contains("arista"),reason);
        });
        Case("application short curve threshold remains honored", () => {
            var loop=Loop(0,0, .01,0, .01,10, 0,10);
            Assert(!Motor.ValidarLoopResultado2D(loop,.02,out var reason) && reason.Contains("arista"),reason);
        });
        Case("tiny residue remains rejected", () => {
            var loop=Loop(0,0, 1,0, 1,1e-7, 0,1e-7);
            Assert(!Motor.ValidarLoopResultado2D(loop,0,out var reason) && reason.Contains("área"),reason);
        });
        Case("difference preserves a hole", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(2,2,4,4)));
            Check(r,1,0,96); Assert(r.Components[0].Huecos.Count==1,"Hole ownership was lost.");
        });
        Case("transverse cut keeps both pieces", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(4,-1,6,11)));
            Check(r,2,0,80);
        });
        Case("full cover is not an omitted profile", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(-1,-1,11,11)));
            Check(r,0,0,0);
        });
        Case("external obstacle does not alter subject", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(11,0,12,10)));
            Check(r,1,0,100);
        });
        Case("input hole survives unrelated cut", () => {
            var r=Difference(Component(Rect(0,0,10,10),Rect(2,2,4,4)),Component(Rect(8,-1,11,11)));
            Check(r,1,0,76); Assert(r.Components[0].Huecos.Count==1,"Original opening was filled.");
        });
        Case("nested island keeps hole ownership", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Rect(2,2,8,8),Rect(4,4,6,6)));
            Check(r,2,0,68); Assert(r.Components.Sum(c=>c.Huecos.Count)==1,"Nested topology was lost.");
        });
        Case("tangent cut never fills the obstacle", () => {
            var r=Difference(Component(Rect(0,0,10,10)),Component(Loop(0,5, 2,3, 4,5, 2,7)));
            Check(r,1,0,92);
        });
        Console.WriteLine("Passed: "+passed+"; failed: "+failed+"; total: "+(passed+failed));
        return failed==0 ? 0 : 1;
    }

    private static void ValidateNearTouch(long gap, double origin=0)
    {
        var loop=Loop(origin,origin, origin+10,origin, origin+10,origin+10,
            origin+5+gap/Scale,origin+5, origin,origin+10, origin,origin+7,
            origin+5,origin+5, origin,origin+3);
        Assert(Motor.ValidarLoopResultado2D(loop,0,out var reason),reason);
    }

    private sealed class Result {
        public List<ComponenteMuro> Components; public int Omitted; public string Diagnostic;
    }
    private static Result Difference(ComponenteMuro subject, params ComponenteMuro[] cuts)
    {
        Assert(Motor.CalcularRestaPoligonosEnPlano(subject,cuts.ToList(),out var loops,
            out var components,out var omitted,out var diagnostic),diagnostic);
        Assert(loops.Count==components.Sum(c=>1+c.Huecos.Count),"Loop/component ownership mismatch.");
        return new Result { Components=components,Omitted=omitted,Diagnostic=diagnostic };
    }
    private static void Check(Result r,int components,int omitted,double area)
    {
        Assert(r.Components.Count==components,"Components: "+r.Components.Count+". "+r.Diagnostic);
        Assert(r.Omitted==omitted,"Omitted: "+r.Omitted+". "+r.Diagnostic);
        var actual=r.Components.Sum(c=>c.Exterior.AreaAbs-c.Huecos.Sum(h=>h.AreaAbs));
        Assert(Math.Abs(actual-area)<1e-7,"Expected area "+area+", got "+actual);
    }
    private static ComponenteMuro Component(LoopMuro exterior,params LoopMuro[] holes)
        => new ComponenteMuro { Exterior=exterior,Huecos=holes.ToList() };
    private static LoopMuro Rect(double x0,double y0,double x1,double y1)
        => Loop(x0,y0,x1,y0,x1,y1,x0,y1);
    private static LoopMuro Loop(params double[] coordinates)
    {
        var path=new List<IntPoint>();
        var originU=coordinates[0]; var originV=coordinates[1];
        for(var i=0;i<coordinates.Length;i+=2)
            path.Add(new IntPoint((long)Math.Round((coordinates[i]-originU)*Scale),
                (long)Math.Round((coordinates[i+1]-originV)*Scale)));
        return Motor.LoopDesdeCaminoClipper(path,Frame,originU,originV,Scale);
    }
    private static void Case(string name,Action test)
    {
        try { test(); passed++; Console.WriteLine("PASS "+name); }
        catch(Exception e) { failed++; Console.WriteLine("FAIL "+name+": "+e.Message); }
    }
    private static void Assert(bool condition,string message)
    {
        if(!condition) throw new InvalidOperationException(message);
    }
}
