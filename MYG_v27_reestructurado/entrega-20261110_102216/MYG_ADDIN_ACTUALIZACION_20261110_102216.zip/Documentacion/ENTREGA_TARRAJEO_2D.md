# Corrección de falsos cruces en tarrajeo/encofrado

## Base utilizada

Repositorio de trabajo: `bimchimbote-droid/MYG_v27_reestructurado`, rama `master`, commit base `cb9d73137e06f55741862274e4ee839bb87e5d80`. El checkout estaba limpio al comenzar. Se utilizó esta versión abierta en el entorno, conservando su estructura y dependencias; no se sustituyó por `MYG_v27/main`, citado en la plantilla de instrucciones.

## Problema y cambio

El mensaje de la captura corresponde al respaldo de recorte planar usado por el motor de suelos. Después de la diferencia de polígonos, el validador utilizaba una tolerancia de `1e-6` pies para decidir si dos bordes se cruzaban o tocaban, aunque Clipper conserva separaciones de `1e-7` pies. Eso podía convertir una separación real en un falso contacto y descartar todo el paño, no solo una partícula pequeña.

Se conserva el camino entero original de Clipper en cada resultado y se comprueban cruces/contactos exactamente, con orientación `BigInteger` para evitar desbordamientos. No se vuelve a cuantizar el perfil desde coordenadas del modelo. Las comprobaciones de área mínima, longitud mínima y tolerancia de curva corta siguen activas. Se mantienen las islas y la propiedad de sus huecos; no se amplían cortes, no se rellenan interferencias y no se recupera el perfil original sobre obstáculos.

El residuo de `0.009248 mm²` de la captura está por debajo del área mínima existente y puede seguir omitiéndose correctamente. Un contacto real o un perfil que Revit no pueda crear también seguirá rechazándose. El cambio corrige un defecto reproducido con geometría sintética; sin el modelo y el log completo no acredita que todas las piezas de esa captura sean recuperables.

## Archivos que requieren intervención

| Acción | Ruta relativa | Motivo |
| --- | --- | --- |
| REEMPLAZAR | `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs` | Archivo completo actualizado; es el motor planar compartido por los suelos. |
| CREAR | `Tests/TarrajeoRecorte2D/TarrajeoRecorte2D.csproj` | Proyecto de regresión geométrica independiente. |
| CREAR | `Tests/TarrajeoRecorte2D/Program.cs` | Extrae y compila los métodos reales para las pruebas. |
| CREAR | `Tests/TarrajeoRecorte2D/HarnessCases.cs` | Casos de regresión. |
| CREAR | `Tests/TarrajeoRecorte2D/README.md` | Comandos y alcance de las pruebas. |
| CREAR | `Documentacion/ENTREGA_TARRAJEO_2D.md` | Estas instrucciones. |

El ZIP añade además `PARCHES/TARRAJEO_2D.patch` como alternativa para aplicar solo el cambio al handler, y `MANIFIESTO_SHA256.txt` con la relación y hashes del contenido. No contiene archivos sin cambios, bibliotecas, DLL, paquetes restaurables, salidas de compilación ni el proyecto completo. No hay eliminaciones. `MYG.csproj`, `packages.config`, `Clipper.cs`, `Tarrajeo_SuelosHandler.cs`, ventanas, botones y recursos permanecen SIN CAMBIOS y quedan fuera del ZIP.

## Instalación

1. Respalda tu versión local y compara el handler con la base indicada. Reemplazarlo completo puede sobrescribir cambios locales o posteriores; si difiere, utiliza el parche puntual y revisa el resultado.
2. Con Revit cerrado, extrae el ZIP en una carpeta temporal y copia las rutas indicadas sobre la raíz de la solución reestructurada. El handler ya está incluido explícitamente en `MYG.csproj`; no hay que añadirlo otra vez.
3. Como alternativa al reemplazo del handler, desde la raíz de la solución ejecuta primero `git apply --check PARCHES/TARRAJEO_2D.patch` y después `git apply PARCHES/TARRAJEO_2D.patch`. El parche solo contiene el cambio de producción; copia aparte los archivos nuevos de pruebas/documentación. No apliques el parche después de reemplazar el handler.
4. No agregues `Tests/` al proyecto del complemento. Es un proyecto independiente y no se distribuye con la DLL del add-in.
5. Compila con las herramientas adecuadas para tu configuración real de Windows/Revit, actualiza tu instalación de prueba conservando el manifiesto `.addin` e iconos existentes y comprueba el comando en una copia del modelo. Los `.cs` por sí solos no actualizan una DLL cargada.

## Configuración y validación

No se añaden paquetes ni referencias al complemento: `System.Numerics` ya está referenciado. Solo las pruebas independientes requieren SDK .NET 10; usan Roslyn incluido en el SDK y el `Clipper.cs` existente en la solución.

Pruebas geométricas ejecutadas sobre los métodos reales extraídos del handler: la versión base rechaza contornos válidos con puntas próximas; la versión corregida los conserva. También se comprueban huecos, islas, cortes completos/parciales, obstáculos externos, contactos/cruces reales y rechazo de partículas/aristas demasiado pequeñas. Los resultados y comandos están en el README de pruebas. No se simula la creación de suelos en Revit.

Revisión estática de producción: 180 archivos C# sin errores sintácticos; todas las rutas de 9 recursos y 3 auxiliares presentes, sin duplicados. Revisión independiente del cambio completada.

La compilación completa se intentó y continúa detenida en `MSB4803`: `ResolveComReference` requiere MSBuild de .NET Framework/Windows. Persiste la advertencia preexistente `MSB3277` de EPPlus.Interfaces. También se mantiene sin migrar el target .NET Framework 4.8 del proyecto, mientras los metadatos de la API de Revit incluida declaran .NET 10; esa compatibilidad necesita revisión aparte. No se generó una nueva DLL ni se ejecutó Revit en Linux.

Pendiente en Revit: confirmar las caras recuperadas en el modelo original, huecos/interferencias, perfiles inclinados y creación final de suelos. Un contorno matemáticamente válido con un cuello microscópico todavía puede ser rechazado por el kernel de Revit. Si persiste el fallo, el log completo `MYG_Tarrajeo_Losas_Diagnostico.log` y un modelo mínimo permitirán distinguir ese caso de un falso cruce; no se deben rellenar huecos para ocultarlo.

## GitHub

La entrega se publica únicamente como ZIP nuevo en `bimchimbote-droid/DESCARGAS`, sin sobrescribir entregas anteriores. Por petición del usuario no se generan ni se envían enlaces de descarga. Se verifica el archivo publicado recuperándolo mediante Git HTTPS y comparando su SHA-256 y contenido, sin crear una URL de descarga.

Publicar el ZIP no modifica tu PC ni hace commit/push a `MYG_v27` o `MYG_v27_reestructurado`. Para aplicar los cambios al repositorio del código: revisa las diferencias en **Git Changes** de Visual Studio, selecciona solo los archivos de esta corrección, ejecuta las comprobaciones, realiza el commit y después Push cuando decidas publicarlos.
