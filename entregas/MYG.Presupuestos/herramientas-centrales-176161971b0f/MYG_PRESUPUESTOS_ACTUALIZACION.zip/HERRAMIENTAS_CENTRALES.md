# Actualización: herramientas centrales del presupuesto

Repositorio de código: `bimchimbote-droid/MYG.Presupuestos`, rama de referencia `main`.
Base de esta entrega: `dd3fb0ce4e4d684fa50b57a364fb64b03a5ef7c6`.

## Funciones incluidas

La franja vertical se sitúa entre la estructura del presupuesto y el detalle, y abarca también la altura del gráfico y del resumen. Sus once botones siguen el orden de la imagen y el video:

1. Mostrar u ocultar el detalle, recuperando la proporción anterior al restaurarlo.
2. Subir la fila seleccionada, con sus descendientes.
3. Bajar la fila seleccionada, con sus descendientes.
4. Eliminar presupuesto, título o partida, con la confirmación existente.
5. Copiar presupuesto, título o partida en el portapapeles interno del editor.
6. Pegar la copia con sus datos y metrados, utilizando las identidades nuevas del comando existente.
7. Recalcular y actualizar los importes del proyecto.
8. Elegir fuente, tamaño, estilo, tachado, subrayado, tinta y fondo de la vista del presupuesto. Los títulos conservan la negrita. Este formato corresponde a la vista abierta; no modifica el formato impreso ni se escribe en el proyecto.
9. Abrir la Lupa de Windows; `Win + Esc` permite cerrarla. La modalidad de lupa depende de la configuración de accesibilidad de Windows.
10. Abrir la Calculadora de Windows.
11. Grabar data de costos múltiples mediante el formulario existente, con selección de partidas y grupo del catálogo.

El último botón de tabla con flechas verdes, situado debajo del recuadro rojo en la referencia, queda excluido. Los iconos son dibujos originales incluidos en C#, sin descargas de imágenes ni archivos PNG adicionales. Las acciones de edición conservan la autorización de sesión y los comandos e historial existentes.

## Archivos completos de la entrega

Las rutas son relativas a la carpeta que contiene `MYG.Presupuestos.sln`.

| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | MYG.Desktop/EditorEstructura.cs | REEMPLAZAR | Actualiza la disponibilidad de Pegar al copiar desde el menú. |
| 2 | MYG.Desktop/EditorPresupuestos.cs | REEMPLAZAR | Conecta los comandos centrales al editor y a su estado de operación. |
| 3 | MYG.Desktop/PresupuestosEstructuraPanel.cs | REEMPLAZAR | Mide los códigos con la fuente de vista elegida. |
| 4 | MYG.Desktop/PresupuestosHerramientasPanel.cs | REEMPLAZAR | Once herramientas centrales, disponibilidad y control del detalle. |
| 5 | MYG.Desktop/PresupuestosPanel.cs | REEMPLAZAR | Coloca la barra a toda altura e inicializa el formato de vista. |
| 6 | MYG.Desktop/EditorHerramientasEstructura.cs | CREAR | Despacha los comandos sobre las identidades vigentes y respeta la sesión. |
| 7 | MYG.Desktop/HerramientasSistemaPresupuesto.cs | CREAR | Abre Lupa y Calculadora desde el directorio de Windows. |
| 8 | MYG.Desktop/IconosHerramientasPresupuesto.cs | CREAR | Dibuja los once iconos de la barra. |
| 9 | MYG.Desktop/PresupuestosFormatoVista.cs | CREAR | Aplica fuente y colores con escala, selección y alto contraste. |
| 10 | MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra las comprobaciones y el selector --herramientas-centrales. |
| 11 | MYG.PruebasUI/HerramientasCentralesUICheck.cs | CREAR | Pruebas de disposición, comandos, permisos, formato y utilidades. |
| 12 | HERRAMIENTAS_CENTRALES.md | CREAR | Esta guía de aplicación y validación. |

## Aplicar sin perder cambios locales

1. Cierra MYG y conserva una copia de tu carpeta de trabajo antes de aplicar. Mantén su carpeta `.git` y las bases de datos en sus ubicaciones actuales.
2. Extrae el ZIP fuera de la carpeta del proyecto. El paquete solo contiene las fuentes indicadas y las instrucciones; no incluye `.git`, datos SQLite, dependencias ni resultados de compilación.
3. Desde la raíz de tu repositorio revisa `git status --short`. Si ya modificaste alguno de los archivos de la tabla, compara y combina esos cambios antes de reemplazarlo.
4. Puedes aplicar el parche incluido para conservar cambios compatibles. En PowerShell, sustituye la ruta del ejemplo por la ubicación donde extrajiste la entrega:

   ```powershell
   $parche = 'C:\TuCarpeta\Entrega\herramientas-centrales.patch'
   git apply --check $parche
   # Solo si la comprobación anterior terminó sin errores:
   git apply $parche
   ```

   Si `--check` informa un conflicto, combina los archivos manualmente; no fuerces el parche. Como alternativa, copia los archivos completos de la tabla, respetando sus rutas y comparando primero tus modificaciones. No apliques ambas alternativas sobre los mismos archivos.
5. Abre tu solución habitual en Visual Studio 2026 con .NET 10. Los proyectos SDK incluyen los nuevos `.cs` automáticamente; no es necesario modificar el `.csproj`.

Esta entrega no hace push, commits ni cambios de rama en el repositorio del código. Un ZIP publicado en `bimchimbote-droid/DESCARGAS` es independiente del repositorio del proyecto.

## Compilación y comprobaciones

Verificado en Linux con SDK .NET 10.0.100:

```text
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true --no-restore -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

Resultado: solución completa con **0 errores y 0 advertencias**; **462 comprobaciones funcionales correctas**. Las pruebas de datos emplean SQLite y archivos sintéticos. Named Pipes de Windows y las muestras privadas opcionales no se validaron aquí.

Las pruebas de interfaz nuevas se incluyen y compilan, pero su ejecución requiere Windows. Desde la raíz del proyecto en Windows:

```powershell
dotnet build MYG.Desktop/MYG.Desktop.csproj -c Release
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --herramientas-centrales
dotnet run --project MYG.Desktop/MYG.Desktop.csproj -c Release
```

En una copia de un proyecto, verifica visualmente la franja central, ocultar/restaurar detalle, mover/copiar/pegar filas y cancelar la confirmación de eliminación. Cambia fuente y colores, selecciona otra partida y recalcula para comprobar que el formato permanece en la vista. Abre Lupa y Calculadora. En Grabar data, comprueba la selección y el grupo de destino antes de aceptar. La validación visual, los lanzadores Windows y una sesión real de licencia no se ejecutaron en este entorno Linux.
