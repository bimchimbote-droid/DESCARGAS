using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using MYG_2027;

// Contrato de las mismas escrituras de recurso usadas por el adaptador COM.
// Estas comprobaciones también pueden ejecutarse en Linux sin Office ni WinForms.
internal static class ProjectRecursoConfiguracionCheck
{
    internal static void Ejecutar(Action<bool, string> exige)
    {
        VerificarMesQueProjectRechaza(exige);
        VerificarUnidades(exige);
        VerificarTipos(exige);
        VerificarErrores(exige);
    }

    private static void VerificarMesQueProjectRechaza(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var original = datos with { };
        var simulado = new RecursoSimulado();
        simulado.Escribir("Type", 1);
        simulado.Leer("Type");
        COMException rechazoOriginal = null;
        try { simulado.Escribir("MaterialLabel", "mes"); }
        catch (COMException ex) { rechazoOriginal = ex; }
        exige(rechazoOriginal?.ErrorCode == RecursoSimulado.Error1101,
            "El contrato debe simular el rechazo de una etiqueta temporal literal como mes antes de comprobar su alternativa compatible.");
        simulado.Operaciones.Clear();
        MYGConfiguracionRecursoProject.Configurar(datos, "Calendario de obra", simulado.Leer, simulado.Escribir);
        exige((string)simulado.Valores["MaterialLabel"] == "MYGmes" &&
            (string)simulado.Valores["Text1"] == "mes" &&
            (string)simulado.Valores["Notes"] == "Unidad original MYG: mes" &&
            simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }),
            "El mismo setter que rechaza mes debe aceptar MYGmes después de confirmar el tipo material, conservando la unidad original.");
        exige(datos == original && datos.Unidad == "mes" && datos.Tarifa == 22.07m &&
            simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
            simulado.Valores.Keys.All(p => p is "Type" or "Code" or "Group" or "MaterialLabel" or "Text1" or "Notes" or "StandardRate"),
            "Adaptar la etiqueta de mes debe conservar el DTO y la tarifa numérica, sin convertir cantidades, trabajo ni costos en el recurso.");
    }

    private static void VerificarUnidades(Action<bool, string> exige)
    {
        var casos = new (string Unidad, string Etiqueta, string Visible)[]
        {
            ("kg", "MYGkg", "kg"),
            ("m³", "MYGm3", "m³"),
            ("kg/m³", "MYGkgm3", "kg/m³"),
            ("%mo", "MYGmo", "%mo"),
            ("área", "MYGarea", "área"),
            ("日本語", "MYGunidad", "日本語"),
            ("", "MYGunidad", ""),
            (null, "MYGunidad", ""),
            ("\tme\ns\0", "MYGmes", "\\u0009me\\u000As\\u0000"),
            ("\uD800X\uDC00", "MYGX", "\\uD800X\\uDC00")
        };
        foreach (var caso in casos)
        {
            var datos = Recurso(caso.Unidad);
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            string etiqueta = (string)simulado.Valores["MaterialLabel"];
            string texto = (string)simulado.Valores["Text1"], notas = (string)simulado.Valores["Notes"];
            exige(etiqueta == caso.Etiqueta && EsEtiquetaSegura(etiqueta) && texto == caso.Visible &&
                notas == "Unidad original MYG: " + (caso.Visible.Length == 0 ? "(vacía)" : caso.Visible) &&
                !texto.Any(char.IsControl) && !notas.Any(char.IsControl) && datos == original,
                "La unidad «" + (caso.Etiqueta ?? "vacía") + "» debe usar una etiqueta ASCII estable y conservar su original legible sin controles ni cambios en el DTO.");
        }

        foreach (string unidad in new[] { new string('m', 500), new string('a', 239) + "🧱" + string.Concat(Enumerable.Repeat("áñ㎥", 40)) })
        {
            var datos = Recurso(unidad);
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            string etiqueta = (string)simulado.Valores["MaterialLabel"];
            string texto = (string)simulado.Valores["Text1"];
            exige(EsEtiquetaSegura(etiqueta) && etiqueta.Length == 24 && texto.Length <= 255 &&
                texto.EndsWith(" (ver Notas)", StringComparison.Ordinal) && Utf16Valido(texto) &&
                (string)simulado.Valores["Notes"] == "Unidad original MYG: " + unidad && datos == original,
                "Una unidad larga debe limitar MaterialLabel a 24 ASCII y Text1 a 255 caracteres sin cortar pares Unicode; Notas debe conservar el original completo.");
        }

        var culturaOriginal = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
            var datos = Recurso("kg") with { Tarifa = 1234.56789m };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Obra", simulado.Leer, simulado.Escribir);
            exige(simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                (string)simulado.Valores["MaterialLabel"] == "MYGkg" && (string)simulado.Valores["Text1"] == "kg",
                "Las tarifas deben enviarse como número independiente del separador decimal y kg debe conservarse como unidad original de MYGkg.");
        }
        finally { CultureInfo.CurrentCulture = culturaOriginal; }
    }

    private static void VerificarTipos(Action<bool, string> exige)
    {
        foreach (int tipo in new[] { 1, 2 })
        {
            var datos = Recurso(tipo == 1 ? "hh" : "%mo") with { Tipo = tipo };
            var original = datos with { };
            var simulado = new RecursoSimulado();
            MYGConfiguracionRecursoProject.Configurar(datos, "Calendario específico", simulado.Leer, simulado.Escribir);
            exige(Convert.ToInt32(simulado.Valores["Type"], CultureInfo.InvariantCulture) == (tipo == 1 ? 0 : 2) &&
                simulado.Operaciones.Take(2).SequenceEqual(new[] { "set:Type", "get:Type" }) &&
                !simulado.Valores.ContainsKey("MaterialLabel") && !simulado.Valores.ContainsKey("Text1") &&
                !simulado.Valores.ContainsKey("Notes") && datos == original,
                "Los recursos de " + (tipo == 1 ? "trabajo" : "costo") + " deben confirmar su tipo COM sin intentar asignar una etiqueta de material.");
            exige(tipo == 1
                    ? simulado.Valores["StandardRate"] is double tarifa && tarifa == (double)datos.Tarifa &&
                      (string)simulado.Valores["BaseCalendar"] == "Calendario específico"
                    : !simulado.Valores.ContainsKey("StandardRate") && !simulado.Valores.ContainsKey("BaseCalendar"),
                "Sólo el recurso de trabajo debe recibir tarifa y calendario; el costo porcentual debe conservar su naturaleza de costo.");
        }
    }

    private static void VerificarErrores(Action<bool, string> exige)
    {
        var datos = Recurso("mes");
        var original = datos with { };
        var tipoRechazado = new RecursoSimulado { TipoLeido = 0 };
        Exception fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoRechazado.Leer, tipoRechazado.Escribir));
        exige(fallo is InvalidOperationException &&
            tipoRechazado.Operaciones.SequenceEqual(new[] { "set:Type", "get:Type" }) && datos == original,
            "Si Project no conserva el tipo material solicitado, la configuración debe abortar antes de escribir códigos, etiquetas o tarifas.");

        var errorTipo = new COMException("Fallo COM al asignar Type", unchecked((int)0x80020009));
        var tipoConError = new RecursoSimulado { FalloTipo = errorTipo };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tipoConError.Leer, tipoConError.Escribir));
        exige(ReferenceEquals(fallo, errorTipo) && tipoConError.Operaciones.SequenceEqual(new[] { "set:Type" }),
            "Un error COM al establecer el tipo debe propagarse sin continuar con MaterialLabel ni otros datos.");

        var errorTarifa = new COMException("Error COM específico en StandardRate", unchecked((int)0x80020009));
        var tarifaConError = new RecursoSimulado { FalloTarifa = errorTarifa };
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos, "Obra", tarifaConError.Leer, tarifaConError.Escribir));
        exige(ReferenceEquals(fallo, errorTarifa) && tarifaConError.Operaciones.Count(o => o == "set:StandardRate") == 1 &&
            tarifaConError.Operaciones.Last() == "set:StandardRate" &&
            (string)tarifaConError.Valores["MaterialLabel"] == "MYGmes" && datos == original,
            "Un error COM arbitrario de tarifa debe conservar su excepción y abortar sin reintentos que oculten el fallo como un problema de unidades.");

        var desconocido = new RecursoSimulado();
        fallo = Capturar(() => MYGConfiguracionRecursoProject.Configurar(datos with { Tipo = 37 }, "Obra", desconocido.Leer, desconocido.Escribir));
        exige(fallo is InvalidDataException && desconocido.Operaciones.Count == 0,
            "Un tipo de recurso desconocido debe rechazarse antes de cualquier escritura COM.");
    }

    private static MYGRecursoExportacionProject Recurso(string unidad) =>
        new(27, 0, "Recurso de prueba", "130001", "Materiales", unidad, 22.07m);

    private static bool EsEtiquetaSegura(string etiqueta) => etiqueta != null &&
        etiqueta.StartsWith("MYG", StringComparison.Ordinal) && etiqueta.Length is > 3 and <= 24 &&
        etiqueta.All(char.IsAsciiLetterOrDigit);

    private static bool Utf16Valido(string texto)
    {
        for (int i = 0; i < texto.Length; i++)
        {
            if (char.IsHighSurrogate(texto[i]))
            {
                if (i + 1 >= texto.Length || !char.IsLowSurrogate(texto[i + 1])) return false;
                i++;
            }
            else if (char.IsLowSurrogate(texto[i])) return false;
        }
        return true;
    }

    private static Exception Capturar(Action accion)
    {
        try { accion(); return null; }
        catch (Exception ex) { return ex; }
    }

    private sealed class RecursoSimulado
    {
        internal const int Error1101 = unchecked((int)0x800A044D);
        internal readonly Dictionary<string, object> Valores = new(StringComparer.Ordinal);
        internal readonly List<string> Operaciones = new();
        internal int? TipoLeido;
        internal COMException FalloTipo, FalloTarifa;
        private bool tipoConfirmado;

        internal object Leer(string propiedad)
        {
            Operaciones.Add("get:" + propiedad);
            object valor = propiedad == "Type" && TipoLeido.HasValue ? TipoLeido.Value : Valores[propiedad];
            if (propiedad == "Type") tipoConfirmado = Convert.ToInt32(valor, CultureInfo.InvariantCulture) ==
                Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture);
            return valor;
        }

        internal void Escribir(string propiedad, object valor)
        {
            Operaciones.Add("set:" + propiedad);
            if (propiedad == "Type")
            {
                tipoConfirmado = false;
                if (FalloTipo != null) throw FalloTipo;
            }
            if (propiedad == "MaterialLabel")
            {
                if (!tipoConfirmado || Convert.ToInt32(Valores["Type"], CultureInfo.InvariantCulture) != 1)
                    throw new InvalidOperationException("MaterialLabel requiere Type material confirmado.");
                if (valor is not string etiqueta || !EsEtiquetaSegura(etiqueta))
                    throw new COMException("El argumento no es válido: MaterialLabel", Error1101);
            }
            if (propiedad == "StandardRate" && FalloTarifa != null) throw FalloTarifa;
            Valores[propiedad] = valor;
        }
    }
}
