using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace MYG_2027;

// Se comparte con las comprobaciones de contrato para ejercitar las mismas
// escrituras que utiliza el adaptador COM, sin necesitar una instalación Office.
internal static class MYGConfiguracionRecursoProject
{
    internal static void Configurar(MYGRecursoExportacionProject datos, string calendario,
        Func<string, object> leer, Action<string, object> escribir)
    {
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(leer);
        ArgumentNullException.ThrowIfNull(escribir);
        // Tipo del modelo: material=0, trabajo=1. Tipo COM: trabajo=0, material=1.
        int tipo = datos.Tipo switch { 0 => 1, 1 => 0, 2 => 2,
            _ => throw new InvalidDataException("Tipo de recurso desconocido.") };
        escribir("Type", tipo);
        if (Convert.ToInt32(leer("Type"), CultureInfo.InvariantCulture) != tipo)
            throw new InvalidOperationException("Microsoft Project no aceptó el tipo del recurso «" + datos.Nombre + "».");
        escribir("Code", datos.Codigo ?? "");
        escribir("Group", datos.Grupo ?? "");
        if (datos.Tipo == 0)
        {
            // Project interpreta algunas unidades como etiquetas temporales
            // según el idioma instalado. Evitar alias y símbolos con una etiqueta
            // ASCII prefijada; la unidad original sigue disponible en Text1/Notes.
            escribir("MaterialLabel", Etiqueta(datos.Unidad));
            string unidad = UnidadVisible(datos.Unidad);
            int limite = 240;
            if (unidad.Length > 255 && char.IsHighSurrogate(unidad[limite - 1])) limite--;
            escribir("Text1", unidad.Length <= 255 ? unidad : unidad[..limite] + " (ver Notas)");
            escribir("Notes", "Unidad original MYG: " + (unidad.Length == 0 ? "(vacía)" : unidad));
        }
        if (datos.Tipo != 2) escribir("StandardRate", (double)datos.Tarifa);
        if (datos.Tipo == 1) escribir("BaseCalendar", calendario);
    }

    internal static string Etiqueta(string unidad)
    {
        // EnumerateRunes sustituye los pares UTF-16 inválidos antes de Normalize.
        var texto = new StringBuilder();
        foreach (var rune in (unidad ?? "").EnumerateRunes()) texto.Append(rune.ToString());
        string normalizada = texto.ToString().Normalize(NormalizationForm.FormKD);
        var etiqueta = new StringBuilder("MYG");
        foreach (char c in normalizada)
        {
            if (char.IsAsciiLetterOrDigit(c)) etiqueta.Append(c);
            if (etiqueta.Length == 24) break;
        }
        return etiqueta.Length == 3 ? "MYGunidad" : etiqueta.ToString();
    }

    private static string UnidadVisible(string unidad)
    {
        var texto = new StringBuilder();
        string valor = unidad ?? "";
        for (int i = 0; i < valor.Length; i++)
        {
            char c = valor[i];
            if (char.IsHighSurrogate(c) && i + 1 < valor.Length && char.IsLowSurrogate(valor[i + 1]))
            { texto.Append(c).Append(valor[++i]); continue; }
            if (char.IsControl(c) || char.IsSurrogate(c))
                texto.Append("\\u").Append(((int)c).ToString("X4", CultureInfo.InvariantCulture));
            else texto.Append(c);
        }
        return texto.ToString();
    }
}
