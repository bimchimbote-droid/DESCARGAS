# Corrección de unidades y vínculos de Microsoft Project

Aplica este ZIP después del correctivo MS Project anterior, cuyo SHA256 es `c5411cbc0df404ca071433b1c8cf93e2ac1367e3312793d36320bedbcfccfd49`. Proyecto: `bimchimbote-droid/MYG.Presupuestos`; entrega pública independiente en `bimchimbote-droid/DESCARGAS`.

## Cambios

La primera captura muestra que Project rechaza la etiqueta del primer recurso material. Antes se enviaba la unidad del presupuesto literalmente como `MaterialLabel`. La corrección genera etiquetas alfanuméricas ASCII con prefijo `MYG` y hasta 24 caracteres, sin reutilizar la unidad literal. Por ejemplo, `mes` pasa a `MYGmes` y `m³` a `MYGm3`. La captura no muestra la unidad concreta rechazada; interpretar `mes` como un alias temporal es una hipótesis, no una causa comprobada en esa instalación.

La unidad original permanece en el campo **Texto1** de cada recurso material y en **Notas**. Puedes agregar Texto1 a la hoja de recursos para consultarla. Si la unidad es demasiado larga, Texto1 muestra una abreviación y Notas conserva el contenido completo. Los caracteres de control se representan mediante escapes visibles como `\u0009`. Una etiqueta vacía se exporta como `MYGunidad`.

Se conserva el tipo material, el código, la tarifa y la cantidad de las asignaciones. No se convierten alquileres en recursos de trabajo o de costo para evitar el error. Los recursos de trabajo y de costo no reciben una etiqueta material.

La segunda captura muestra que las tareas se crean y la primera dependencia falla. La llamada ahora envía el objeto de la tarea predecesora explícitamente como `IDispatch`, utiliza argumentos posicionales con enlace de opcionales y omite el desfase cuando es cero. Mantiene los cuatro tipos FC/CC/FF/CF y el signo y valor de los desfases. No omite vínculos ni cambia tareas manuales a automáticas para continuar. Si Project rechaza un vínculo, el mensaje incluye las identidades de las dos tareas, el tipo y el desfase.

La documentación de Project admite desfases numéricos en minutos. Sin ejecutar la instalación de Project del usuario no se ha demostrado qué parte de la llamada anterior provocó ese segundo rechazo; esta actualización refuerza la transmisión COM conservando la relación original.

## Comprobación

Se incluyen pruebas que reproducen el rechazo de una etiqueta literal como `mes` mediante un adaptador de propiedades estricto y comprueban que la configuración real del exportador utiliza una etiqueta compatible. También comprueban unidades con símbolos, controles y textos largos, la conservación del modelo y la propagación de errores ajenos.

Las pruebas de dependencias verifican el objeto predecesor, tipos, desfases cero/positivos/negativos y la propagación de fallos sin borrar relaciones. Se ejecutan en Linux junto con las comprobaciones existentes del flujo y de SQLite. Los resultados concretos se incluyen en `VALIDACION.json`.

La solución WinForms se compila en Linux. **La exportación real MPP y la nueva configuración de etiquetas y vínculos aún requieren comprobarse en Windows con Microsoft Project instalado.** Las pruebas simuladas no sustituyen esa comprobación.

En Windows, cierra Microsoft Project antes de iniciar la exportación. Prueba ambos modos en una copia del proyecto y con archivos MPP de destino diferentes. Con recursos, revisa el recurso de alquiler, su Texto1 y sus asignaciones. En ambos modos, comprueba que se creen las dependencias y se abra el MPP al finalizar.

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --cronograma
```

## Aplicación

Cierra MYG y conserva una copia de tus avances. Extrae el ZIP fuera del proyecto. Revisa `git status --short` y compara los archivos de la tabla antes de reemplazar. Conserva `.git` y tus bases de datos.

Elige copiar los archivos completos respetando sus rutas o aplicar el parche incluido:

```powershell
$parche = 'C:\TuCarpeta\Entrega\project-unidades-vinculos.patch'
git apply --check $parche
# Sólo si la comprobación termina sin errores:
git apply $parche
```

No apliques ambos métodos sobre los mismos archivos. Si hay conflictos, combina manualmente sin forzar el parche. La entrega no hace commits, push ni cambios de rama en el repositorio del código.


## Archivos de esta corrección

Acciones respecto al correctivo MS Project anterior.

| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | CORRECCION_PROJECT_UNIDADES_VINCULOS.md | CREAR | Instrucciones de aplicación y alcance de validación. |
| 2 | EXPORTACION_MS_PROJECT.md | REEMPLAZAR | Enlaza las instrucciones del nuevo correctivo. |
| 3 | MYG.Desktop/ProjectAdaptadorCom.cs | REEMPLAZAR | Conecta etiquetas materiales y llamada explícita de vínculos. |
| 4 | MYG.Desktop/ProjectDependenciaConfiguracion.cs | CREAR | Prepara predecesora, tipo y desfase sin cambiar la relación. |
| 5 | MYG.Desktop/ProjectRecursoConfiguracion.cs | CREAR | Etiquetas compatibles y conservación de la unidad original. |
| 6 | MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra las nuevas comprobaciones de contrato. |
| 7 | MYG.PruebasUI/ProjectDependenciaConfiguracionCheck.cs | CREAR | Comprueba los argumentos y errores de las dependencias. |
| 8 | MYG.PruebasUI/ProjectRecursoConfiguracionCheck.cs | CREAR | Reproduce el rechazo de etiquetas y comprueba unidades y tarifas. |
