using System;
using System.Linq;

namespace MYG_2027;

internal enum MYGEtapaExportacionProject
{ Preparando, Recursos, Tareas, Asignaciones, Dependencias, Guardando, Abriendo, Completado }

internal sealed record MYGProgresoExportacionProject(MYGEtapaExportacionProject Etapa,
    int Actual, int Total, string Detalle);

// El adaptador contiene exclusivamente las operaciones contra Project. Separar el
// recorrido permite comprobar el orden con un sustituto sin Office ni Windows.
internal interface IMYGAdaptadorProject : IDisposable
{
    void Iniciar(MYGModeloExportacionProject modelo);
    void CrearRecurso(MYGRecursoExportacionProject recurso);
    void CrearTarea(MYGTareaExportacionProject tarea);
    void AsignarRecurso(MYGAsignacionExportacionProject asignacion);
    void CrearDependencia(MYGDependenciaExportacionProject dependencia);
    void FinalizarDatos(MYGModeloExportacionProject modelo);
    void GuardarResultado(string destino);
    void MostrarResultado();
    void ConfirmarResultado();
}

internal static class MYGFlujoExportacionProject
{
    internal static void Ejecutar(MYGModeloExportacionProject modelo, bool incluirRecursos,
        string destino, IMYGAdaptadorProject adaptador, Action<MYGProgresoExportacionProject> notificar = null)
    {
        ArgumentNullException.ThrowIfNull(modelo);
        ArgumentNullException.ThrowIfNull(adaptador);
        // Rechazar un modelo incoherente antes de activar Project. El indicador de
        // sólo tareas nunca puede crear recursos ni asignaciones por accidente.
        if (!incluirRecursos && (modelo.Recursos.Count != 0 || modelo.Asignaciones.Count != 0))
            throw new InvalidOperationException("La exportación de sólo tareas contiene recursos o asignaciones.");
        if (modelo.Tareas.Select(t => t.Uid).Distinct().Count() != modelo.Tareas.Count ||
            modelo.Recursos.Select(r => r.Uid).Distinct().Count() != modelo.Recursos.Count)
            throw new InvalidOperationException("El cronograma contiene identificadores duplicados.");
        var tareas = modelo.Tareas.Select(t => t.Uid).ToHashSet();
        var recursos = modelo.Recursos.Select(r => r.Uid).ToHashSet();
        if (modelo.Asignaciones.Any(a => !tareas.Contains(a.TareaUid) || !recursos.Contains(a.RecursoUid)) ||
            modelo.Dependencias.Any(d => !tareas.Contains(d.TareaUid) || !tareas.Contains(d.PredecesoraUid)))
            throw new InvalidOperationException("El cronograma contiene una asignación o dependencia sin destino.");

        void Avance(MYGEtapaExportacionProject etapa, int actual, int total, string detalle) =>
            notificar?.Invoke(new(etapa, actual, total, detalle));
        using (adaptador)
        {
            Avance(MYGEtapaExportacionProject.Preparando, 0, 1, "Preparando Microsoft Project");
            adaptador.Iniciar(modelo);
            if (incluirRecursos)
            {
                Avance(MYGEtapaExportacionProject.Recursos, 0, modelo.Recursos.Count, "LISTA DE RECURSOS");
                for (int i = 0; i < modelo.Recursos.Count; i++)
                {
                    var recurso = modelo.Recursos[i];
                    Avance(MYGEtapaExportacionProject.Recursos, i, modelo.Recursos.Count,
                        "Creando recurso " + recurso.Nombre);
                    adaptador.CrearRecurso(recurso);
                    Avance(MYGEtapaExportacionProject.Recursos, i + 1, modelo.Recursos.Count, recurso.Nombre);
                }
            }
            var asignaciones = modelo.Asignaciones.ToLookup(a => a.TareaUid);
            var nombresRecursos = modelo.Recursos.ToDictionary(r => r.Uid, r => r.Nombre);
            for (int i = 0; i < modelo.Tareas.Count; i++)
            {
                var tarea = modelo.Tareas[i];
                Avance(MYGEtapaExportacionProject.Tareas, i, modelo.Tareas.Count, "Creando tarea " + tarea.Nombre);
                adaptador.CrearTarea(tarea);
                if (incluirRecursos)
                    foreach (var asignacion in asignaciones[tarea.Uid])
                    {
                        Avance(MYGEtapaExportacionProject.Asignaciones, i + 1, modelo.Tareas.Count,
                            "Asignando recurso " + nombresRecursos[asignacion.RecursoUid] + " a tarea " + tarea.Nombre);
                        adaptador.AsignarRecurso(asignacion);
                    }
                Avance(MYGEtapaExportacionProject.Tareas, i + 1, modelo.Tareas.Count, tarea.Nombre);
            }
            var nombresTareas = modelo.Tareas.ToDictionary(t => t.Uid, t => t.Nombre);
            Avance(MYGEtapaExportacionProject.Dependencias, 0, modelo.Dependencias.Count, "Creando dependencias");
            for (int i = 0; i < modelo.Dependencias.Count; i++)
            {
                var dependencia = modelo.Dependencias[i];
                Avance(MYGEtapaExportacionProject.Dependencias, i, modelo.Dependencias.Count,
                    "Creando dependencias de tarea " + nombresTareas[dependencia.TareaUid]);
                adaptador.CrearDependencia(dependencia);
                Avance(MYGEtapaExportacionProject.Dependencias, i + 1, modelo.Dependencias.Count,
                    nombresTareas[dependencia.TareaUid]);
            }
            // Las asignaciones y los vínculos pueden recalcular trabajo y fechas.
            // El adaptador termina los valores de las tareas antes del guardado.
            adaptador.FinalizarDatos(modelo);
            Avance(MYGEtapaExportacionProject.Guardando, 0, 1, "Guardando archivo de Microsoft Project");
            adaptador.GuardarResultado(destino);
            Avance(MYGEtapaExportacionProject.Guardando, 1, 1, "Archivo MPP guardado");
            Avance(MYGEtapaExportacionProject.Abriendo, 0, 1, "Abriendo el resultado en Microsoft Project");
            adaptador.MostrarResultado();
            adaptador.ConfirmarResultado();
            Avance(MYGEtapaExportacionProject.Completado, 1, 1, "Exportación completada");
        }
    }
}
