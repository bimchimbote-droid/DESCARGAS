# Corrección de la exportación a Microsoft Project

Actualización para `bimchimbote-droid/MYG.Presupuestos` sobre la entrega Gantt anterior (ZIP SHA256 `af7f9686ed920f29562ae0794d796f4779fa305834288fc4c23f0afcccabb0c3`). Aplica esta corrección después de aquella entrega. Mantiene las herramientas centrales, calendarios y rutas críticas.

## Comportamiento

La captura del error corresponde al paso anterior que intentaba importar un XML en Microsoft Project. La exportación MPP ahora crea el proyecto directamente mediante su API de automatización; no utiliza un archivo XML intermedio.

1. En CPM, elige **Exportar → MS-Project (tareas y recursos)** o **MS-Project (sólo tareas)**.
2. La ventana muestra **Archivo de destino**, **Examinar**, **Exportar sólo tareas**, **Exportar** y **Cerrar**. La casilla se inicia según la opción elegida y puede cambiarse antes de exportar.
3. Con recursos, crea los recursos reales del presupuesto; después crea las tareas y sus asignaciones; finalmente crea las dependencias. La ventana informa etapa, elemento y contador. Con sólo tareas omite la creación de recursos y asignaciones, manteniendo tareas, jerarquía y dependencias.
4. Guarda un MPP binario y abre el resultado en Microsoft Project al finalizar. La ventana de MYG informa el resultado. No hace falta abrir el archivo manualmente.

La exportación corre en un hilo STA dedicado. La ventana permanece disponible para mostrar progreso. Durante el trabajo no permite cambiar el destino, volver a exportar ni cerrar a mitad de una operación de Project. Si ocurre un error, informa la etapa y permite revisar el destino y reintentar. El progreso procede del procesamiento real de los elementos.

El cronograma y el presupuesto de MYG se leen como una copia: exportar no cambia su historial. Se mantienen los tipos de recurso, tareas manuales/automáticas, jerarquía, hitos, calendario, línea base y vínculos que MYG puede representar. Los vínculos importados de Delphin que MYG ya marca como no resolubles no se convierten en dependencias inventadas.

Antes de guardar se comprueban las fechas y duración de las tareas manuales y el trabajo/cantidad/costo de sus asignaciones. Si Project modifica esos valores, la exportación informa la tarea afectada y no reemplaza el destino. Esto debe revisarse especialmente con duraciones importadas cortas cuyos extremos están muy separados; no se convierten a otro modo ni se inventan intervalos divididos.

## Requisitos y validación en Windows

Necesitas Microsoft Project de escritorio instalado y registrado en Windows. Antes de exportar, cierra sus ventanas para que MYG cree una sesión aislada. Al terminar, Project queda abierto con el resultado; ciérralo antes de iniciar otra exportación. MYG no toma una sesión ajena ni cierra documentos del usuario.

La solución se compila desde Linux y las comprobaciones automáticas verifican el modelo de datos y la secuencia de operaciones mediante un adaptador simulado, además del guardado SQLite existente. **La automatización real de Project y la nueva ventana WinForms requieren ejecución en Windows; no se ejecutaron en este entorno Linux.** Las comprobaciones simuladas no prueban la compatibilidad con una instalación concreta de Project.

Desde la raíz del proyecto, con .NET 10:

```powershell
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true --disable-parallel
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true --no-restore -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --cronograma
```

En una copia de tu proyecto, exporta primero sólo tareas y comprueba jerarquía, fechas y predecesoras. Después exporta tareas y recursos a otro destino y revisa la hoja de recursos y las asignaciones de varias partidas. Comprueba que ambos resultados se abran automáticamente. Revisa especialmente las fechas manuales importadas y los recursos de trabajo, materiales y porcentuales.

## Aplicación conservando tus cambios

El ZIP correctivo contiene los archivos completos modificados desde la entrega Gantt anterior y `exportacion-project-desde-gantt.patch`. Sus rutas son relativas a la carpeta que contiene `MYG.Presupuestos.sln`.

1. Cierra MYG y guarda una copia de tus avances locales. Extrae el ZIP fuera de la carpeta del proyecto.
2. Comprueba `git status --short`. Si tienes cambios en los archivos de la tabla, compáralos y combínalos antes de reemplazar.
3. Elige copiar los archivos completos respetando sus rutas, o aplicar el parche comprobándolo primero:

```powershell
$parche = 'C:\TuCarpeta\Entrega\exportacion-project-desde-gantt.patch'
git apply --check $parche
# Sólo si la comprobación termina sin errores:
git apply $parche
```

No apliques los dos métodos sobre los mismos archivos. Si el parche detecta conflictos, combina manualmente sin forzarlo. Conserva `.git` y las bases de datos existentes. Los proyectos SDK incluyen los nuevos `.cs` automáticamente.

La publicación se realiza únicamente en el repositorio independiente y público `bimchimbote-droid/DESCARGAS`. No se hacen commits, push ni cambios de rama en el repositorio del código. Los archivos y resultados concretos de comprobación se detallan en `VALIDACION.json` y en la tabla de esta guía.


## Archivos de este correctivo

Acciones respecto a la entrega Gantt anterior.

| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | EXPORTACION_MS_PROJECT.md | CREAR | Guía de aplicación y validación del correctivo. |
| 2 | FUNCIONES_GANTT.md | REEMPLAZAR | Actualiza las instrucciones de exportación MPP. |
| 3 | MYG.Core/ExportacionCronogramaMYG.cs | REEMPLAZAR | Comparte los datos de calendario sin importar XML en MPP. |
| 4 | MYG.Core/ModeloExportacionProjectMYG.cs | CREAR | Instantánea tipada de tareas, recursos, asignaciones y vínculos. |
| 5 | MYG.Desktop/CronogramaFuncionesVideo.cs | REEMPLAZAR | Abre la ventana MPP para ambas opciones del menú. |
| 6 | MYG.Desktop/ExportacionCronogramaWindows.cs | REEMPLAZAR | Crea MPP mediante automatización directa de Project. |
| 7 | MYG.Desktop/ExportarProjectForm.cs | CREAR | Destino, sólo tareas, progreso y ejecución STA. |
| 8 | MYG.Desktop/ProjectAdaptadorCom.cs | CREAR | Crea los elementos mediante la API COM de Project. |
| 9 | MYG.Desktop/ProjectFlujoExportacion.cs | CREAR | Ordena las etapas y comunica su progreso real. |
| 10 | MYG.Pruebas/ModeloExportacionProjectCheck.cs | CREAR | Comprueba instantáneas, recursos, fechas y dependencias. |
| 11 | MYG.Pruebas/Program.cs | REEMPLAZAR | Registra las comprobaciones del modelo directo. |
| 12 | MYG.PruebasUI/ExportacionProjectEtapasCheck.cs | CREAR | Comprueba secuencia, opciones y fallos con adaptador simulado. |
| 13 | MYG.PruebasUI/ExportarProjectFormCheck.cs | CREAR | Comprueba ventana, hilo STA, progreso y reintento en Windows. |
| 14 | MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra las nuevas comprobaciones de flujo y ventana. |
