using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

static class ModeloExportacionProjectCheck
{
    private static void Exige(bool condicion, string mensaje) { if (!condicion) throw new Exception(mensaje); }
    private static string Firma(object valor) => JsonSerializer.Serialize(valor);

    internal static void Ejecutar(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        string documentoAntes = Firma(proyecto), planAntes = Firma(plan);
        var solo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, true);
        Exige(solo.Recursos.Count == 0 && solo.Asignaciones.Count == 0 &&
            modelo.Tareas.Count == 7 && modelo.Tareas.Select(t => t.Uid).SequenceEqual(Enumerable.Range(1, 7)) &&
            solo.Tareas.SequenceEqual(modelo.Tareas) && solo.Dependencias.SequenceEqual(modelo.Dependencias) &&
            modelo.Tareas[0].Resumen && modelo.Tareas[1].PadreUid == modelo.Tareas[0].Uid &&
            modelo.Tareas[1].Nivel == 2 && modelo.Tareas[1].Esquema == "1.1" && modelo.Tareas[1].Codigo == "0001" &&
            modelo.Tareas[1].DuracionMinutos == 1170 && modelo.Tareas[1].Avance == 37.5m &&
            modelo.Tareas.Single(t => t.IdMYG == "H").Hito && modelo.Tareas.Single(t => t.IdMYG == "H").DuracionMinutos == 0,
            "El modelo Project perdió tareas, jerarquía, duración real, avance o hitos; sólo tareas debe conservar todo excepto los recursos.");
        var manual = modelo.Tareas.Single(t => t.IdMYG == "E");
        Exige(manual.Manual && manual.Inicio == new DateTime(2026, 2, 1, 8, 0, 0) &&
            manual.Fin == new DateTime(2026, 2, 7, 15, 30, 0) && manual.DuracionMinutos == 780 &&
            manual.InicioBase == new DateTime(2025, 12, 30, 8, 0, 0) && manual.FinBase == new DateTime(2026, 1, 2, 15, 30, 0) &&
            manual.DuracionBaseMinutos == 1170 && manual.Notas == "Fechas importadas" &&
            modelo.MinutosPorDia == 390 && modelo.MinutosPorSemana == 1950,
            "El modelo Project recalculó las fechas manuales importadas o perdió línea base, notas o minutos de trabajo.");
        pasa("Modelo directo de Project mantiene jerarquía, duración horaria, hitos, avance fraccionario, fechas manuales y línea base; sólo tareas excluye recursos y asignaciones");

        var material = modelo.Recursos.Single(r => r.Nombre == "Arena QA");
        var trabajador = modelo.Recursos.Single(r => r.Nombre == "Operario QA");
        var porcentaje = modelo.Recursos.Single(r => r.Nombre == "Herramientas QA");
        var aMaterial = modelo.Asignaciones.Single(a => a.RecursoUid == material.Uid);
        var aTrabajo = modelo.Asignaciones.Single(a => a.RecursoUid == trabajador.Uid);
        var aPorcentaje = modelo.Asignaciones.Single(a => a.RecursoUid == porcentaje.Uid);
        Exige(modelo.Recursos.Count == 3 && modelo.Asignaciones.Count == 3 &&
            material.Tipo == 0 && material.Unidad == "m3" && material.Tarifa == 10 && material.Codigo == "0007" &&
            aMaterial.Cantidad == 8 && aMaterial.Unidades == 8 && aMaterial.TrabajoHoras == null && aMaterial.Costo == 80 &&
            trabajador.Tipo == 1 && trabajador.Tarifa == 20 && aTrabajo.TrabajoHoras == 8 &&
            aTrabajo.Costo == 160 && Math.Abs(aTrabajo.Unidades.Value - 8m / 19.5m) < .000001m &&
            porcentaje.Tipo == 2 && aPorcentaje.Costo == 8 && aPorcentaje.TrabajoHoras == null && aPorcentaje.Unidades == null &&
            modelo.Asignaciones.All(a => modelo.Tareas.Any(t => t.Uid == a.TareaUid && !t.Resumen)) &&
            modelo.Recursos.All(r => r.Nombre != "Sin uso" && r.Nombre != "Precio directo"),
            "La exportación directa no extrajo los insumos/asignaciones reales del ACU o confundió trabajo, material y costo porcentual.");
        Exige(modelo.Dependencias.Count == 4 && modelo.Dependencias.Select(d => d.Tipo).Distinct().Count() == 4 &&
            modelo.Dependencias.Single(d => d.Tipo == MYGTipoVinculo.FC).DesfaseMinutos == 780 &&
            modelo.Dependencias.Single(d => d.Tipo == MYGTipoVinculo.CC).DesfaseMinutos == -390 &&
            modelo.Dependencias.All(d => modelo.Tareas.Any(t => t.Uid == d.TareaUid) && modelo.Tareas.Any(t => t.Uid == d.PredecesoraUid)),
            "La exportación directa perdió vínculos FC/CC/FF/CF, sus extremos o los desfases en minutos.");
        pasa("Modelo directo de Project extrae recursos reales y subanálisis del ACU, asigna cantidades/trabajo/costos correctos y mantiene las cuatro dependencias con desfases");

        Exige(Firma(proyecto) == documentoAntes && Firma(plan) == planAntes &&
            Firma(MYGExportacionCronograma.PrepararProject(proyecto, plan, true)) == Firma(modelo),
            "Preparar Project modificó documentos o no produjo identidades deterministas.");
        bool bloqueada = false;
        try { ((IList<MYGTareaExportacionProject>)modelo.Tareas)[0] = modelo.Tareas[1]; }
        catch (NotSupportedException) { bloqueada = true; }
        plan.Tareas[1].Nombre = "Modificada después";
        plan.Calendario.HorasPorDia = 2;
        proyecto.Presupuestos[0].Costos.Insumos[0].Precio = 999;
        Exige(bloqueada && modelo.Tareas[1].Nombre == "Excavación QA" && modelo.MinutosPorDia == 390 && material.Tarifa == 10,
            "La instantánea directa retiene referencias editables al documento o permite reemplazar sus listas.");
        pasa("Preparar Project es determinista, conserva el origen y entrega una instantánea independiente con listas de sólo lectura");

        proyecto = Datos(out plan);
        proyecto.Presupuestos[0].Costos.Insumos.Clear();
        bool rechazada = false;
        var tareasSinAnalisis = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        try { MYGExportacionCronograma.PrepararProject(proyecto, plan, true); }
        catch (InvalidDataException) { rechazada = true; }
        Exige(tareasSinAnalisis.Tareas.Count == plan.Tareas.Count && tareasSinAnalisis.Recursos.Count == 0 && rechazada,
            "Sólo tareas validó recursos que no debe exportar, o con recursos aceptó un análisis con insumos inexistentes.");
        plan.Tareas.Single(t => t.Id == "B").Predecesoras[0].PredecesoraId = "NO EXISTE";
        rechazada = false;
        try { MYGExportacionCronograma.PrepararProject(proyecto, plan, false); }
        catch (InvalidDataException) { rechazada = true; }
        Exige(rechazada, "Sólo tareas omitió validar las dependencias del cronograma.");
        pasa("Sólo tareas omite el cálculo de recursos incluso con ACU inválido, pero sigue validando las tareas y dependencias");

        ComprobarCalendario(pasa);
    }

    private static void ComprobarCalendario(Action<string> pasa)
    {
        var proyecto = Datos(out var plan);
        plan.Tareas = new()
        {
            new() { Id = "A", Nombre = "Turnos", DuracionDias = 5, InicioBase = new DateTime(2026, 12, 24),
                FinBase = new DateTime(2026, 12, 30), DuracionBase = 5 }
        };
        plan.FechaInicio = new DateTime(2026, 12, 24); plan.FechaEstado = new DateTime(2027, 1, 1);
        var calendario = new MYGCalendarioTrabajo { Nombre = "Obra y guardias", HorasPorDia = 8 };
        foreach (var dia in new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday })
            calendario.HorariosSemanales.Add(new() { Dia = dia, Tramos = new() { new() { InicioMinuto = 480, FinMinuto = 720 }, new() { InicioMinuto = 780, FinMinuto = 1020 } } });
        calendario.HorariosSemanales.Add(new() { Dia = DayOfWeek.Saturday, Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 780 } } });
        calendario.FeriadosAnuales.Add(new() { Mes = 12, Dia = 25 });
        calendario.Excepciones.Add(new() { Id = "NAVIDAD", Nombre = "Navidad", Anual = true, Mes = 12, Dia = 25, Laborable = false });
        calendario.Excepciones.Add(new() { Id = "GUARDIA", Nombre = "Guardia", Inicio = new DateTime(2026, 12, 25), Fin = new DateTime(2026, 12, 25), Laborable = true,
            Tramos = new() { new() { InicioMinuto = 600, FinMinuto = 720 } } });
        calendario.Excepciones.Add(new() { Id = "CIERRE", Inicio = new DateTime(2026, 12, 26), Fin = new DateTime(2026, 12, 27), Laborable = false });
        calendario.Excepciones.Add(new() { Id = "CORTA", Inicio = new DateTime(2026, 12, 28), Fin = new DateTime(2026, 12, 29), Laborable = true,
            Tramos = new() { new() { InicioMinuto = 540, FinMinuto = 720 } } });
        plan.Calendario = calendario;
        var modelo = MYGExportacionCronograma.PrepararProject(proyecto, plan, false);
        var guardia = modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2026, 12, 25));
        Exige(modelo.Calendario.Dias.Count == 7 && modelo.MinutosPorSemana == 2640 &&
            modelo.Calendario.Dias.Single(d => d.Dia == DayOfWeek.Monday).Tramos.SequenceEqual(new[] { new MYGTramoExportacionProject(480, 720), new MYGTramoExportacionProject(780, 1020) }) &&
            modelo.Calendario.Dias.Single(d => d.Dia == DayOfWeek.Saturday).Tramos.Single() == new MYGTramoExportacionProject(540, 780) &&
            guardia.Fin == guardia.Inicio && guardia.Tramos.Single() == new MYGTramoExportacionProject(600, 720) &&
            modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2026, 12, 26)).Tramos.Count == 0 &&
            modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2026, 12, 28)).Fin == new DateTime(2026, 12, 29) &&
            modelo.Calendario.Excepciones.Single(e => e.Inicio == new DateTime(2027, 12, 25)).Tramos.Count == 0 &&
            modelo.Tareas[0].DuracionMinutos == 1440 && modelo.Tareas[0].DuracionBaseMinutos == 1440 &&
            modelo.Tareas[0].Fin == new DateTime(2026, 12, 30, 17, 0, 0),
            "La instantánea directa perdió turnos partidos, sábado, guardias, prioridad de excepciones, fechas inclusivas u horas reales de tarea/línea base.");
        var orden = modelo.Calendario.Excepciones.OrderBy(e => e.Inicio).ToArray();
        Exige(orden.Zip(orden.Skip(1), (a, b) => a.Fin < b.Inicio).All(x => x), "El calendario directo contiene excepciones solapadas.");
        pasa("Calendario directo de Project conserva turnos partidos, sábados, excepciones por rango y prioridad de guardias sobre feriados anuales, con duración y línea base en minutos reales");
    }

    private static MYGProyectoDocumento Datos(out MYGCronograma plan)
    {
        var proyecto = MYGProyectoStorage.Nuevo("Proyecto directo QA"); var p = proyecto.Presupuestos.Single();
        var material = new MYGInsumo { Id = "ARENA", Codigo = "0007", Descripcion = "Arena QA", Unidad = "m3", Precio = 10 };
        var trabajo = new MYGInsumo { Id = "OPERARIO", Codigo = "0008", Descripcion = "Operario QA", Unidad = "hh", Grupo = MYGGrupoRecurso.ManoObra, Precio = 20 };
        var porcentaje = new MYGInsumo { Id = "HERRAMIENTAS", Codigo = "0009", Descripcion = "Herramientas QA", Unidad = "%mo", Grupo = MYGGrupoRecurso.Equipo };
        p.Costos.Insumos.AddRange(new[] { material, trabajo, porcentaje, new MYGInsumo { Id = "SINUSO", Codigo = "99", Descripcion = "Sin uso", Precio = 123 } });
        ItemPresupuestoDelphin Partida(string id, decimal cantidad)
        {
            var i = new ItemPresupuestoDelphin { Id = id, IdLocalMYG = id, Item = id, Descripcion = id, TipoPropuesta = "PARTIDA", Unidad = "und" };
            i.Costos.Cantidad = cantidad; p.Items.Add(i); return i;
        }
        var partida = Partida("PARTIDA", 2); var sub = Partida("SUB", 0); var directa = Partida("DIRECTA", 1); directa.Costos.PrecioDirecto = 45;
        sub.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 2 });
        partida.Costos.Analisis.Add(new() { InsumoId = material.Id, Grupo = MYGGrupoRecurso.Materiales, Cantidad = 3 });
        partida.Costos.Analisis.Add(new() { InsumoId = trabajo.Id, Grupo = MYGGrupoRecurso.ManoObra, Cantidad = 4 });
        partida.Costos.Analisis.Add(new() { Grupo = MYGGrupoRecurso.Subpartidas, SubpartidaIdLocal = sub.IdLocalMYG, Cantidad = .5m });
        partida.Costos.Analisis.Add(new() { InsumoId = porcentaje.Id, Grupo = MYGGrupoRecurso.Equipo, Modo = MYGModoCantidad.PorcentajeManoObra, Cantidad = 5 });
        plan = new MYGCronograma
        {
            FechaInicio = new DateTime(2026, 1, 30), FechaEstado = new DateTime(2026, 2, 4),
            Calendario = new() { HorasPorDia = 6.5m, Feriados = new() { new DateTime(2026, 2, 2) }, FeriadosAnuales = new() { new() { Mes = 2, Dia = 3 } } },
            Tareas = new()
            {
                new() { Id = "R", Nombre = "Resumen", EsResumen = true },
                new() { Id = "A", PadreId = "R", Codigo = "0001", Nombre = "Excavación QA", DuracionDias = 3, Avance = 37.5m, PresupuestoId = p.Id, PartidaId = partida.Id },
                new() { Id = "B", PadreId = "R", Nombre = "Precio directo", DuracionDias = 2, PresupuestoId = p.Id, PartidaId = directa.Id,
                    Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.FC, DesfaseDias = 2 } } },
                new() { Id = "C", PadreId = "R", Nombre = "Comienzo comienzo", Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.CC, DesfaseDias = -1 } } },
                new() { Id = "D", PadreId = "R", Nombre = "Fin fin", Predecesoras = new() { new() { PredecesoraId = "A", Tipo = MYGTipoVinculo.FF, DesfaseDias = 1 } } },
                new() { Id = "E", PadreId = "R", Nombre = "Manual importada", Modo = MYGModoTarea.Manual, InicioManual = new DateTime(2026, 2, 1), DuracionDias = 2, Notas = "Fechas importadas",
                    FechasImportadasDelphin = new() { Inicio = new DateTime(2026, 2, 1), Fin = new DateTime(2026, 2, 7), DuracionDias = 2 },
                    InicioBase = new DateTime(2025, 12, 30), FinBase = new DateTime(2026, 1, 2), DuracionBase = 3,
                    Predecesoras = new() { new() { PredecesoraId = "D", Tipo = MYGTipoVinculo.CF, DesfaseDias = -1 } } },
                new() { Id = "H", Nombre = "Hito", DuracionDias = 0 }
            }
        };
        return proyecto;
    }
}
