using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace MYG_2027;

/// <summary>Instantánea independiente de los datos que se crearán en Project.
/// No contiene objetos COM ni requiere un archivo de intercambio.</summary>
public sealed record MYGModeloExportacionProject(
    string Nombre, DateTime Inicio, DateTime Fin, DateTime FechaEstado,
    int MinutosPorDia, int MinutosPorSemana, string Moneda,
    MYGCalendarioExportacionProject Calendario,
    IReadOnlyList<MYGTareaExportacionProject> Tareas,
    IReadOnlyList<MYGRecursoExportacionProject> Recursos,
    IReadOnlyList<MYGAsignacionExportacionProject> Asignaciones,
    IReadOnlyList<MYGDependenciaExportacionProject> Dependencias,
    IReadOnlyList<string> Advertencias);

public sealed record MYGTareaExportacionProject(
    int Uid, string IdMYG, int PadreUid, int Nivel, string Esquema, string Codigo, string Nombre,
    bool Manual, bool Resumen, bool Hito, bool Critica,
    DateTime Inicio, DateTime Fin, decimal DuracionMinutos, decimal Avance,
    DateTime? InicioBase, DateTime? FinBase, decimal? DuracionBaseMinutos, string Notas);

/// <summary>Tipo: 0 material, 1 trabajo horario, 2 costo porcentual.</summary>
public sealed record MYGRecursoExportacionProject(
    int Uid, int Tipo, string Nombre, string Codigo, string Grupo, string Unidad, decimal Tarifa);

/// <summary>TrabajoHoras se usa para trabajo; Unidades expresa cantidad fija
/// en materiales y dedicación (trabajo/duración) en recursos de trabajo.</summary>
public sealed record MYGAsignacionExportacionProject(
    int TareaUid, int RecursoUid, decimal Cantidad, decimal? TrabajoHoras,
    decimal? Unidades, decimal Costo, DateTime Inicio, DateTime Fin);

public sealed record MYGDependenciaExportacionProject(
    int TareaUid, int PredecesoraUid, MYGTipoVinculo Tipo, decimal DesfaseMinutos);

public sealed record MYGCalendarioExportacionProject(
    string Nombre, IReadOnlyList<MYGDiaExportacionProject> Dias,
    IReadOnlyList<MYGExcepcionExportacionProject> Excepciones);

public sealed record MYGDiaExportacionProject(
    DayOfWeek Dia, IReadOnlyList<MYGTramoExportacionProject> Tramos);

/// <summary>Intervalo inclusivo de fechas. Los tramos vacíos indican descanso.
/// Las excepciones ya resuelven las prioridades, sin intervalos solapados.</summary>
public sealed record MYGExcepcionExportacionProject(
    DateTime Inicio, DateTime Fin, IReadOnlyList<MYGTramoExportacionProject> Tramos);

public sealed record MYGTramoExportacionProject(int InicioMinuto, int FinMinuto);

public static partial class MYGExportacionCronograma
{
    private static ReadOnlyCollection<T> SoloLectura<T>(IEnumerable<T> elementos) => Array.AsReadOnly(elementos.ToArray());

    /// <summary>Calcula tareas, calendario, recursos reales y vínculos para la
    /// automatización directa de Microsoft Project. Nunca modifica el origen.
    /// Sólo tareas omite completamente el cálculo y la validación de recursos.</summary>
    public static MYGModeloExportacionProject PrepararProject(
        MYGProyectoDocumento proyecto, MYGCronograma plan, bool incluirRecursos)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(plan);
        var copia = MYGProyectoStorage.Copia(proyecto);
        var planCopia = MYGProyectoStorage.Copia(plan);
        var resultado = MYGMotorCronograma.Calcular(planCopia);
        var calendario = planCopia.Calendario;
        var horas = new HorasCalendario(calendario);
        bool horariosExplicitos = calendario.HorariosSemanales?.Count > 0 || calendario.Excepciones?.Any(e => e.Laborable) == true;
        decimal HorasFila(MYGResultadoTarea f) => f.DuracionDias == 0 ? 0 :
            MYGMotorCronograma.ConservaFechasDelphin(f.Tarea) && !horariosExplicitos
                ? f.DuracionDias * calendario.HorasPorDia : horas.Entre(f.Inicio, f.Fin);
        DateTime Desde(DateTime fecha) => fecha.Date.AddMinutes(HorarioFecha(fecha, calendario)[0].InicioMinuto);
        DateTime Hasta(DateTime fecha, bool hito) => fecha.Date.AddMinutes(hito
            ? HorarioFecha(fecha, calendario)[0].InicioMinuto : HorarioFecha(fecha, calendario)[^1].FinMinuto);

        var recursos = new List<Recurso>();
        var asignaciones = new List<Asignacion>();
        string moneda = null;
        if (incluirRecursos) PrepararRecursos(copia, resultado, recursos, asignaciones, out moneda);
        var uids = resultado.Filas.ToDictionary(f => f.Tarea.Id, f => f.Numero, StringComparer.Ordinal);
        var contadores = new Dictionary<string, int>(StringComparer.Ordinal);
        var esquemas = new Dictionary<string, string>(StringComparer.Ordinal);
        var tareas = new List<MYGTareaExportacionProject>();
        var dependencias = new List<MYGDependenciaExportacionProject>();
        foreach (var f in resultado.Filas)
        {
            var t = f.Tarea;
            string padre = t.PadreId ?? "";
            int ordinal = contadores.GetValueOrDefault(padre) + 1;
            contadores[padre] = ordinal;
            string esquema = (padre.Length == 0 ? "" : esquemas[padre] + ".") + ordinal.ToString(System.Globalization.CultureInfo.InvariantCulture);
            esquemas[t.Id] = esquema;
            decimal? duracionBase = t.DuracionBase.HasValue
                ? t.DuracionBase == 0 ? 0 : (horariosExplicitos
                    ? horas.Entre(t.InicioBase.Value, t.FinBase.Value) : t.DuracionBase.Value * calendario.HorasPorDia) * 60m
                : null;
            tareas.Add(new MYGTareaExportacionProject(
                f.Numero, t.Id, padre.Length == 0 ? 0 : uids[padre], f.Nivel + 1, esquema,
                string.IsNullOrWhiteSpace(t.Codigo) ? esquema : t.Codigo, t.Nombre,
                t.Modo == MYGModoTarea.Manual, t.EsResumen, !t.EsResumen && f.DuracionDias == 0, f.EsCritica,
                Desde(f.Inicio), Hasta(f.Fin, f.DuracionDias == 0), HorasFila(f) * 60m, f.Avance,
                t.InicioBase.HasValue ? Desde(t.InicioBase.Value) : null,
                t.FinBase.HasValue ? Hasta(t.FinBase.Value, t.DuracionBase == 0) : null,
                duracionBase, t.Notas));
            foreach (var dependencia in t.Predecesoras)
                dependencias.Add(new MYGDependenciaExportacionProject(
                    f.Numero, uids[dependencia.PredecesoraId], dependencia.Tipo,
                    dependencia.DesfaseDias * calendario.HorasPorDia * 60m));
        }
        var recursosProject = recursos.Select(r => new MYGRecursoExportacionProject(
            r.Uid, r.Tipo, r.Insumo.Descripcion, r.Insumo.Codigo ?? "",
            MYGMotorPresupuestos.Grupo(r.Insumo.Grupo), r.Insumo.Unidad ?? "", r.Precio));
        var asignacionesProject = asignaciones.Select(a => new MYGAsignacionExportacionProject(
            a.TareaUid, a.Recurso.Uid, a.Cantidad, a.Recurso.Tipo == 1 ? a.Cantidad : null,
            a.Recurso.Tipo == 0 ? a.Cantidad : a.Recurso.Tipo == 1 && HorasFila(a.Fila) > 0
                ? a.Cantidad / HorasFila(a.Fila) : null,
            a.Costo, Desde(a.Fila.Inicio), Hasta(a.Fila.Fin, a.Fila.DuracionDias == 0)));
        return new MYGModeloExportacionProject(
            copia.Nombre ?? "Cronograma MYG", Desde(resultado.Inicio),
            Hasta(resultado.Fin, resultado.Filas.Count > 0 && resultado.Filas.All(f => f.DuracionDias == 0)),
            planCopia.FechaEstado.Date,
            decimal.ToInt32(decimal.Round(calendario.HorasPorDia * 60m, MidpointRounding.AwayFromZero)),
            Enum.GetValues<DayOfWeek>().Sum(d => calendario.HorarioSemanal(d).Sum(t => t.FinMinuto - t.InicioMinuto)),
            moneda, PrepararCalendarioProject(planCopia, resultado),
            SoloLectura(tareas), SoloLectura(recursosProject), SoloLectura(asignacionesProject),
            SoloLectura(dependencias), SoloLectura(resultado.Advertencias));
    }

    private static MYGCalendarioExportacionProject PrepararCalendarioProject(MYGCronograma plan, MYGResultadoCronograma resultado)
    {
        var calendario = plan.Calendario;
        IReadOnlyList<MYGTramoExportacionProject> Tramos(IReadOnlyList<MYGTramoHorario> horario) =>
            SoloLectura(horario.Select(t => new MYGTramoExportacionProject(t.InicioMinuto, t.FinMinuto)));
        var dias = Enum.GetValues<DayOfWeek>().Select(d => new MYGDiaExportacionProject(d, Tramos(calendario.HorarioSemanal(d))));
        var excepciones = new List<MYGExcepcionExportacionProject>();
        int primerAnio = Math.Min(plan.FechaInicio.Year, resultado.Inicio.Year);
        int ultimoAnio = Math.Max(plan.FechaEstado.Year, resultado.Fin.Year);
        foreach (var fila in resultado.Filas)
        {
            if (fila.Tarea.InicioBase.HasValue) primerAnio = Math.Min(primerAnio, fila.Tarea.InicioBase.Value.Year);
            if (fila.Tarea.FinBase.HasValue) ultimoAnio = Math.Max(ultimoAnio, fila.Tarea.FinBase.Value.Year);
        }
        var feriados = calendario.Feriados.Select(f => f.Date).ToHashSet();
        void AgregarAnual(int mes, int dia)
        {
            for (int anio = primerAnio; anio <= ultimoAnio; anio++)
                if (dia <= DateTime.DaysInMonth(anio, mes)) feriados.Add(new DateTime(anio, mes, dia));
        }
        foreach (var anual in calendario.FeriadosAnuales ?? new()) AgregarAnual(anual.Mes, anual.Dia);
        foreach (var anual in (calendario.Excepciones ?? new()).Where(e => e.Anual)) AgregarAnual(anual.Mes, anual.Dia);
        void Agregar(DateTime desde, DateTime hasta, IReadOnlyList<MYGTramoHorario> horario) =>
            excepciones.Add(new MYGExcepcionExportacionProject(desde.Date, hasta.Date, Tramos(horario)));
        var rangos = (calendario.Excepciones ?? new()).Where(e => !e.Anual).OrderBy(e => e.Inicio.Value.Date).ToArray();
        foreach (var fecha in feriados.Order().Where(f => !rangos.Any(r => r.Contiene(f))))
            Agregar(fecha, fecha, calendario.ObtenerHorario(fecha));
        foreach (var rango in rangos)
        {
            if (!rango.Laborable || rango.Tramos?.Count > 0)
            {
                Agregar(rango.Inicio.Value, rango.Fin.Value, calendario.ObtenerHorario(rango.Inicio.Value));
                continue;
            }
            // Las guardias sin tramos heredan el horario del día. Un fin de
            // semana puede tener tramos distintos de un día habitual de obra.
            DateTime desde = rango.Inicio.Value.Date > new DateTime(primerAnio, 1, 1) ? rango.Inicio.Value.Date : new DateTime(primerAnio, 1, 1);
            DateTime hasta = rango.Fin.Value.Date < new DateTime(ultimoAnio, 12, 31) ? rango.Fin.Value.Date : new DateTime(ultimoAnio, 12, 31);
            if (desde > hasta) continue;
            var tramos = calendario.ObtenerHorario(desde);
            DateTime grupo = desde, actual = desde;
            while (actual < hasta)
            {
                DateTime siguiente = actual.AddDays(1);
                var nuevos = calendario.ObtenerHorario(siguiente);
                if (!tramos.Select(t => (t.InicioMinuto, t.FinMinuto)).SequenceEqual(nuevos.Select(t => (t.InicioMinuto, t.FinMinuto))))
                { Agregar(grupo, actual, tramos); grupo = siguiente; tramos = nuevos; }
                actual = siguiente;
            }
            Agregar(grupo, hasta, tramos);
        }
        return new MYGCalendarioExportacionProject(calendario.Nombre, SoloLectura(dias), SoloLectura(excepciones));
    }
}
