using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace MYG_2027;

public enum MYGFormatoExportacionCronograma { XmlTareas, XmlTareasRecursos, Texto, Mht }

/// <summary>Exporta instantáneas del cronograma. El XML usa el formato de
/// intercambio de Microsoft Project; no representa un archivo binario MPP.</summary>
public static partial class MYGExportacionCronograma
{
    private static readonly XNamespace Ns = "http://schemas.microsoft.com/project";
    private sealed record Recurso(int Uid, MYGInsumo Insumo, int Tipo, decimal Precio);
    private sealed record Asignacion(int TareaUid, Recurso Recurso, MYGResultadoTarea Fila,
        decimal Cantidad, decimal Costo);

    public static void Guardar(string ruta, MYGProyectoDocumento proyecto, MYGCronograma plan,
        MYGFormatoExportacionCronograma formato)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique el archivo de destino.", nameof(ruta));
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(plan);
        if (!Enum.IsDefined(formato)) throw new ArgumentOutOfRangeException(nameof(formato));
        // Algunos validadores de presupuesto completan datos antiguos. Trabajar
        // siempre en copias evita convertir la exportación en una edición.
        var copia = MYGProyectoStorage.Copia(proyecto);
        var planCopia = MYGProyectoStorage.Copia(plan);
        var resultado = MYGMotorCronograma.Calcular(planCopia);
        if (formato == MYGFormatoExportacionCronograma.Mht)
        {
            MYGReportesExportacion.Guardar(ruta, MYGFormatoExportacionReporte.Mht,
                MYGReportesCronograma.Crear(copia, planCopia));
            return;
        }
        if (formato == MYGFormatoExportacionCronograma.Texto)
        {
            string texto = Texto(resultado);
            Escribir(ruta, temporal => File.WriteAllText(temporal, texto, new UTF8Encoding(true)));
            return;
        }
        var xml = Xml(copia, planCopia, resultado, formato == MYGFormatoExportacionCronograma.XmlTareasRecursos);
        Escribir(ruta, temporal =>
        {
            using var escritor = XmlWriter.Create(temporal, new XmlWriterSettings
            { Encoding = new UTF8Encoding(false), Indent = true, NewLineChars = "\r\n", CheckCharacters = true });
            xml.Save(escritor);
        });
    }

    private static void Escribir(string ruta, Action<string> escribir)
    {
        string temporal = ruta + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { escribir(temporal); File.Move(temporal, ruta, true); }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    private static XElement E(string nombre, object valor) => new(Ns + nombre, valor);
    private static string Num(decimal valor) => valor.ToString(CultureInfo.InvariantCulture);
    private static TimeSpan Horas(decimal horas) => TimeSpan.FromTicks(checked((long)decimal.Round(horas * TimeSpan.TicksPerHour)));
    private static string Duracion(decimal horas) => XmlConvert.ToString(Horas(horas));
    private static IReadOnlyList<MYGTramoHorario> HorarioPredeterminado(MYGCalendarioTrabajo c) =>
        Enum.GetValues<DayOfWeek>().Select(c.HorarioSemanal).FirstOrDefault(h => h.Count > 0) ??
        new[] { new MYGTramoHorario { InicioMinuto = 0, FinMinuto = (int)decimal.Round(c.HorasPorDia * 60) } };
    private static IReadOnlyList<MYGTramoHorario> HorarioFecha(DateTime fecha, MYGCalendarioTrabajo c)
    {
        var horario = c.ObtenerHorario(fecha);
        // Una tarea manual importada puede fijarse en un día no laborable.
        // Conservar su fecha y usar las horas semanales para sus extremos.
        if (horario.Count == 0) horario = c.HorarioSemanal(fecha.DayOfWeek);
        return horario.Count > 0 ? horario : HorarioPredeterminado(c);
    }
    private static TimeSpan InicioJornada(MYGCalendarioTrabajo c) => TimeSpan.FromMinutes(HorarioPredeterminado(c)[0].InicioMinuto);
    private static TimeSpan FinJornada(MYGCalendarioTrabajo c) => TimeSpan.FromMinutes(HorarioPredeterminado(c)[^1].FinMinuto);
    private static string Hora(TimeSpan hora) => hora == TimeSpan.FromDays(1) ? "24:00:00" :
        new DateTime(hora.Ticks).ToString("HH:mm:ss.fffffff", CultureInfo.InvariantCulture).TrimEnd('0').TrimEnd('.');
    private static string Fecha(DateTime fecha, TimeSpan hora) => fecha.Date.Add(hora).ToString("yyyy-MM-ddTHH:mm:ss.fffffff", CultureInfo.InvariantCulture).TrimEnd('0').TrimEnd('.');
    private static string Inicio(MYGResultadoTarea fila, MYGCalendarioTrabajo calendario) => Fecha(fila.Inicio,
        TimeSpan.FromMinutes(HorarioFecha(fila.Inicio, calendario)[0].InicioMinuto));
    private static string Fin(MYGResultadoTarea fila, MYGCalendarioTrabajo calendario) => Fecha(fila.Fin,
        TimeSpan.FromMinutes(fila.DuracionDias == 0 ? HorarioFecha(fila.Fin, calendario)[0].InicioMinuto : HorarioFecha(fila.Fin, calendario)[^1].FinMinuto));

    private static XDocument Xml(MYGProyectoDocumento proyecto, MYGCronograma plan, MYGResultadoCronograma resultado, bool conRecursos)
    {
        var calendario = plan.Calendario;
        var horasCalendario = new HorasCalendario(calendario);
        bool horariosExplicitos = calendario.HorariosSemanales?.Count > 0 || calendario.Excepciones?.Any(e => e.Laborable) == true;
        decimal HorasFila(MYGResultadoTarea f) => f.DuracionDias == 0 ? 0 :
            MYGMotorCronograma.ConservaFechasDelphin(f.Tarea) && !horariosExplicitos ? f.DuracionDias * calendario.HorasPorDia : horasCalendario.Entre(f.Inicio, f.Fin);
        var recursos = new List<Recurso>(); var asignaciones = new List<Asignacion>();
        string moneda = null;
        if (conRecursos) PrepararRecursos(proyecto, resultado, recursos, asignaciones, out moneda);
        var raiz = E("Project", new object[]
        {
            E("SaveVersion", 14), E("Name", proyecto.Nombre ?? "Cronograma MYG"),
            E("Title", proyecto.Nombre ?? "Cronograma MYG"), E("ScheduleFromStart", 1),
            E("StartDate", Fecha(resultado.Inicio, TimeSpan.FromMinutes(HorarioFecha(resultado.Inicio, calendario)[0].InicioMinuto))),
            E("FinishDate", Fecha(resultado.Fin, resultado.Filas.Count > 0 && resultado.Filas.All(f => f.DuracionDias == 0)
                ? TimeSpan.FromMinutes(HorarioFecha(resultado.Fin, calendario)[0].InicioMinuto) : TimeSpan.FromMinutes(HorarioFecha(resultado.Fin, calendario)[^1].FinMinuto)))
        });
        if (moneda != null) raiz.Add(E("CurrencySymbol", moneda));
        raiz.Add(E("CalendarUID", 1), E("DefaultStartTime", Hora(InicioJornada(calendario))),
            E("DefaultFinishTime", Hora(FinJornada(calendario))),
            E("MinutesPerDay", decimal.ToInt32(decimal.Round(calendario.HorasPorDia * 60, MidpointRounding.AwayFromZero))),
            E("MinutesPerWeek", decimal.ToInt32(decimal.Round(Enum.GetValues<DayOfWeek>().Sum(d => calendario.HorarioSemanal(d).Sum(t => t.FinMinuto - t.InicioMinuto)), MidpointRounding.AwayFromZero))),
            E("DefaultTaskType", 1), E("DurationFormat", 7), E("WorkFormat", 2),
            E("StatusDate", Fecha(plan.FechaEstado, TimeSpan.Zero)), E("NewTasksAreManual", 0),
            E("Calendars", Calendario(plan, resultado)));
        var uids = resultado.Filas.ToDictionary(f => f.Tarea.Id, f => f.Numero, StringComparer.Ordinal);
        var contadores = new Dictionary<string, int>(StringComparer.Ordinal);
        var esquemas = new Dictionary<string, string>(StringComparer.Ordinal);
        var tareas = E("Tasks", null);
        foreach (var f in resultado.Filas)
        {
            var t = f.Tarea;
            string padre = t.PadreId ?? "";
            int ordinal = contadores.GetValueOrDefault(padre) + 1; contadores[padre] = ordinal;
            string esquema = (padre.Length == 0 ? "" : esquemas[padre] + ".") + ordinal.ToString(CultureInfo.InvariantCulture);
            esquemas[t.Id] = esquema;
            var nodo = E("Task", new object[]
            {
                E("UID", f.Numero), E("ID", f.Numero), E("Name", t.Nombre), E("Type", 1), E("IsNull", 0),
                E("WBS", string.IsNullOrWhiteSpace(t.Codigo) ? esquema : t.Codigo),
                E("OutlineNumber", esquema), E("OutlineLevel", f.Nivel + 1),
                E("Start", Inicio(f, calendario)), E("Finish", Fin(f, calendario)),
                E("Duration", Duracion(HorasFila(f))), E("DurationFormat", 7),
                E("EffortDriven", 0), E("Estimated", 0), E("Milestone", !t.EsResumen && f.DuracionDias == 0 ? 1 : 0),
                E("Summary", t.EsResumen ? 1 : 0), E("Critical", f.EsCritica ? 1 : 0),
                E("PercentComplete", decimal.ToInt32(decimal.Round(f.Avance, MidpointRounding.AwayFromZero))),
                E("CalendarUID", 1)
            });
            if (!string.IsNullOrWhiteSpace(t.Notas)) nodo.Add(E("Notes", t.Notas));
            foreach (var d in t.Predecesoras)
                nodo.Add(E("PredecessorLink", new object[]
                {
                    E("PredecessorUID", uids[d.PredecesoraId]),
                    E("Type", d.Tipo switch { MYGTipoVinculo.FF => 0, MYGTipoVinculo.FC => 1, MYGTipoVinculo.CF => 2, _ => 3 }),
                    E("CrossProject", 0),
                    // Project expresa el desfase en décimas de minuto.
                    E("LinkLag", checked((int)decimal.Round(d.DesfaseDias * calendario.HorasPorDia * 600, MidpointRounding.AwayFromZero))),
                    E("LagFormat", 7)
                }));
            if (t.InicioBase.HasValue)
                nodo.Add(E("Baseline", new object[]
                {
                    E("Number", 0), E("Start", Fecha(t.InicioBase.Value, TimeSpan.FromMinutes(HorarioFecha(t.InicioBase.Value, calendario)[0].InicioMinuto))),
                    E("Finish", Fecha(t.FinBase.Value, TimeSpan.FromMinutes(t.DuracionBase == 0 ? HorarioFecha(t.FinBase.Value, calendario)[0].InicioMinuto : HorarioFecha(t.FinBase.Value, calendario)[^1].FinMinuto))),
                    E("Duration", Duracion(t.DuracionBase == 0 ? 0 : horariosExplicitos ? horasCalendario.Entre(t.InicioBase.Value, t.FinBase.Value) : t.DuracionBase.Value * calendario.HorasPorDia))
                }));
            nodo.Add(E("Active", 1), E("Manual", t.Modo == MYGModoTarea.Manual ? 1 : 0));
            if (t.Modo == MYGModoTarea.Manual)
                nodo.Add(E("ManualStart", Inicio(f, calendario)), E("ManualFinish", Fin(f, calendario)),
                    E("ManualDuration", Duracion(HorasFila(f))));
            tareas.Add(nodo);
        }
        raiz.Add(tareas);
        if (conRecursos)
        {
            raiz.Add(E("Resources", recursos.Select(r =>
            {
                var nodo = E("Resource", new object[] { E("UID", r.Uid), E("ID", r.Uid), E("Name", r.Insumo.Descripcion), E("Type", r.Tipo), E("IsNull", 0) });
                if (r.Tipo == 0) nodo.Add(E("MaterialLabel", r.Insumo.Unidad));
                nodo.Add(E("Code", r.Insumo.Codigo ?? ""), E("Group", MYGMotorPresupuestos.Grupo(r.Insumo.Grupo)));
                if (r.Tipo != 2) nodo.Add(E("StandardRate", Num(r.Precio)), E("StandardRateFormat", 2));
                if (r.Tipo == 1) nodo.Add(E("CalendarUID", 1));
                return nodo;
            })));
            int numero = 0;
            raiz.Add(E("Assignments", asignaciones.Select(a =>
            {
                var nodo = E("Assignment", new object[]
                {
                    E("UID", ++numero), E("TaskUID", a.TareaUid), E("ResourceUID", a.Recurso.Uid),
                    E("Cost", Num(a.Costo)), E("Finish", Fin(a.Fila, calendario)), E("Start", Inicio(a.Fila, calendario))
                });
                if (a.Recurso.Tipo != 2)
                {
                    decimal horas = HorasFila(a.Fila);
                    // Un material tiene cantidad fija; el trabajo horario tiene
                    // una dedicación igual a trabajo/duración, sin asumir cuadrillas.
                    if (a.Recurso.Tipo == 0 || horas > 0) nodo.Add(E("Units", Num(a.Recurso.Tipo == 0 ? a.Cantidad : a.Cantidad / horas)));
                    if (a.Recurso.Tipo == 1) nodo.Add(E("Work", Duracion(a.Cantidad)));
                }
                return nodo;
            })));
        }
        return new XDocument(new XDeclaration("1.0", "utf-8", null), raiz);
    }

    private static XElement Calendario(MYGCronograma plan, MYGResultadoCronograma resultado)
    {
        var calendario = PrepararCalendarioProject(plan, resultado);
        var dias = E("WeekDays", null);
        XElement Horarios(IReadOnlyList<MYGTramoExportacionProject> tramos) => E("WorkingTimes", tramos.Select(t =>
            E("WorkingTime", new object[] { E("FromTime", Hora(TimeSpan.FromMinutes(t.InicioMinuto))), E("ToTime", Hora(TimeSpan.FromMinutes(t.FinMinuto))) })));
        foreach (var semanal in calendario.Dias)
        {
            var dia = E("WeekDay", new object[] { E("DayType", (int)semanal.Dia + 1), E("DayWorking", semanal.Tramos.Count > 0 ? 1 : 0) });
            if (semanal.Tramos.Count > 0) dia.Add(Horarios(semanal.Tramos));
            dias.Add(dia);
        }
        foreach (var excepcion in calendario.Excepciones)
        {
            var dia = E("WeekDay", new object[]
            {
                E("DayType", 0), E("DayWorking", excepcion.Tramos.Count > 0 ? 1 : 0),
                E("TimePeriod", new object[] { E("FromDate", Fecha(excepcion.Inicio, TimeSpan.Zero)), E("ToDate", Fecha(excepcion.Fin, new TimeSpan(23, 59, 59))) })
            });
            if (excepcion.Tramos.Count > 0) dia.Add(Horarios(excepcion.Tramos));
            dias.Add(dia);
        }
        return E("Calendar", new object[] { E("UID", 1), E("Name", calendario.Nombre), E("IsBaseCalendar", 1), E("BaseCalendarUID", -1), dias });
    }

    // Integra horas semanales mediante semanas completas; las excepciones
    // fechadas se integran por rangos y las anuales por puntos indexados. La
    // duración de una tarea extensa nunca recorre cada día del intervalo.
    private sealed class HorasCalendario
    {
        private readonly MYGCalendarioTrabajo calendario;
        private readonly decimal[] semana;
        private readonly MYGExcepcionCalendario[] rangos;
        private readonly int[] puntos;
        private readonly decimal[] prefijos;
        internal HorasCalendario(MYGCalendarioTrabajo c)
        {
            calendario = c;
            semana = Enum.GetValues<DayOfWeek>().Select(d => c.HorarioSemanal(d).Sum(t => t.FinMinuto - t.InicioMinuto) / 60m).ToArray();
            rangos = (c.Excepciones ?? new()).Where(e => !e.Anual).ToArray();
            var fechas = c.Feriados.Select(f => f.Date).ToHashSet();
            foreach (var f in c.FeriadosAnuales ?? new()) AgregarAnual(f.Mes, f.Dia);
            foreach (var e in (c.Excepciones ?? new()).Where(e => e.Anual)) AgregarAnual(e.Mes, e.Dia);
            var ajustes = fechas.Where(f => !rangos.Any(r => r.Contiene(f)))
                .Select(f => (Dia: Dia(f), Delta: c.HorasDelDia(f) - semana[(int)f.DayOfWeek])).Where(a => a.Delta != 0).OrderBy(a => a.Dia).ToArray();
            puntos = ajustes.Select(a => a.Dia).ToArray(); prefijos = new decimal[ajustes.Length + 1];
            for (int i = 0; i < ajustes.Length; i++) prefijos[i + 1] = prefijos[i] + ajustes[i].Delta;
            void AgregarAnual(int mes, int dia)
            {
                for (int anio = 1; anio <= 9999; anio++)
                    if (dia <= DateTime.DaysInMonth(anio, mes)) fechas.Add(new DateTime(anio, mes, dia));
            }
        }
        private static int Dia(DateTime fecha) => (int)(fecha.Date.Ticks / TimeSpan.TicksPerDay);
        private decimal SemanalHasta(int dia)
        {
            if (dia < 0) return 0;
            int dias = dia + 1; decimal horas = dias / 7 * semana.Sum();
            for (int n = 0; n < dias % 7; n++) horas += semana[(n + 1) % 7];
            return horas;
        }
        private decimal AjustesHasta(int dia)
        {
            int inferior = 0, superior = puntos.Length;
            while (inferior < superior)
            { int medio = inferior + (superior - inferior) / 2; if (puntos[medio] <= dia) inferior = medio + 1; else superior = medio; }
            return prefijos[inferior];
        }
        internal decimal Entre(DateTime inicio, DateTime fin)
        {
            int desde = Dia(inicio), hasta = Dia(fin);
            if (hasta < desde) return 0;
            decimal horas = SemanalHasta(hasta) - SemanalHasta(desde - 1) + AjustesHasta(hasta) - AjustesHasta(desde - 1);
            foreach (var r in rangos)
            {
                int a = Math.Max(desde, Dia(r.Inicio.Value)), b = Math.Min(hasta, Dia(r.Fin.Value));
                if (b < a) continue;
                decimal baseHoras = SemanalHasta(b) - SemanalHasta(a - 1);
                decimal reales = 0;
                if (r.Laborable && r.Tramos?.Count > 0) reales = (b - a + 1m) * r.Tramos.Sum(t => t.FinMinuto - t.InicioMinuto) / 60m;
                else if (r.Laborable)
                {
                    reales = baseHoras;
                    for (int dia = 0; dia < 7; dia++)
                        if (semana[dia] == 0)
                        {
                            int primero = a + ((dia - (a + 1) % 7 + 7) % 7);
                            if (primero <= b) reales += ((b - primero) / 7 + 1m) *
                                Math.Clamp((int)decimal.Round(calendario.HorasPorDia * 60, MidpointRounding.AwayFromZero), 1, 1440) / 60m;
                        }
                }
                horas += reales - baseHoras;
            }
            return horas;
        }
    }

    private static void PrepararRecursos(MYGProyectoDocumento proyecto, MYGResultadoCronograma resultado,
        List<Recurso> recursos, List<Asignacion> asignaciones, out string moneda)
    {
        var presupuestos = (proyecto.Presupuestos ?? new()).ToDictionary(p => p.Id, StringComparer.OrdinalIgnoreCase);
        var calculos = new Dictionary<string, MYGCalculoPresupuesto>(StringComparer.OrdinalIgnoreCase);
        var vistas = new HashSet<(string Presupuesto, string Partida)>();
        var porClave = new Dictionary<(string Presupuesto, string Insumo, bool Porcentaje), Recurso>();
        var monedas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in resultado.Filas.Where(f => !f.Tarea.EsResumen && !string.IsNullOrWhiteSpace(f.Tarea.PartidaId)))
        {
            var t = f.Tarea;
            if (string.IsNullOrWhiteSpace(t.PresupuestoId) || !presupuestos.TryGetValue(t.PresupuestoId, out var p))
                throw new InvalidDataException("La tarea «" + t.Nombre + "» refiere a un presupuesto inexistente. Sincronice el cronograma.");
            if (!calculos.TryGetValue(p.Id, out var calculo))
            {
                MYGProyectoStorage.ValidarPresupuesto(p);
                calculos.Add(p.Id, calculo = MYGMotorPresupuestos.CrearCalculo(p));
            }
            var partida = p.Items.FirstOrDefault(i => string.Equals(i.Id, t.PartidaId, StringComparison.OrdinalIgnoreCase));
            if (partida == null || MYGProyectoStorage.EsTitulo(partida))
                throw new InvalidDataException("La tarea «" + t.Nombre + "» no refiere a una partida vigente. Sincronice el cronograma.");
            if (!vistas.Add((p.Id.ToUpperInvariant(), partida.Id.ToUpperInvariant())))
                throw new InvalidDataException("Una partida está vinculada a varias tareas. Sincronice el cronograma para no duplicar recursos.");
            var insumos = p.Costos.Insumos.ToDictionary(i => i.Id, StringComparer.Ordinal);
            foreach (var r in calculo.Consolidar(partida))
            {
                string clave = r.Clave;
                bool porcentaje = clave.StartsWith("PORCENTAJE:", StringComparison.Ordinal) || clave.StartsWith("PORCENTAJE_NATIVO:", StringComparison.Ordinal);
                if (porcentaje) clave = clave[(clave.IndexOf(':') + 1)..];
                // Consolidar también representa precios directos y ajustes de
                // redondeo. Esas filas no son insumos ni recursos inventables.
                if (!insumos.TryGetValue(clave, out var insumo)) continue;
                monedas.Add(p.Costos.Moneda.Trim());
                var llave = (p.Id, insumo.Id, porcentaje);
                if (!porClave.TryGetValue(llave, out var recurso))
                {
                    string unidad = (insumo.Unidad ?? "").Trim().ToLowerInvariant();
                    bool horario = (insumo.Grupo is MYGGrupoRecurso.ManoObra or MYGGrupoRecurso.Equipo) &&
                        unidad is "h" or "hh" or "hm" or "h-h" or "h-m" or "hora" or "horas";
                    int tipo = porcentaje ? 2 : horario ? 1 : 0;
                    recurso = new Recurso(recursos.Count + 1, insumo, tipo, r.Precio);
                    porClave.Add(llave, recurso); recursos.Add(recurso);
                }
                asignaciones.Add(new(f.Numero, recurso, f, r.Cantidad, r.Total));
            }
        }
        if (monedas.Count > 1)
            throw new InvalidDataException("Microsoft Project usa una sola moneda. Exporte por separado los presupuestos de monedas distintas.");
        moneda = monedas.SingleOrDefault();
    }

    private static string Texto(MYGResultadoCronograma resultado)
    {
        var texto = new StringBuilder();
        void Fila(IEnumerable<string> valores) => texto.AppendJoin('\t', valores.Select(Campo)).Append("\r\n");
        Fila(new[] { "ID", "Identidad MYG", "Padre", "Nivel", "Código", "Descripción", "Modo", "Resumen", "Hito", "Duración (días laborables)",
            "Inicio", "Fin", "Predecesoras", "% avance", "Inicio base", "Fin base", "Duración base", "Responsables", "Notas" });
        foreach (var f in resultado.Filas)
        {
            var t = f.Tarea;
            Fila(new[] { f.Numero.ToString(CultureInfo.InvariantCulture), t.Id, t.PadreId, (f.Nivel + 1).ToString(CultureInfo.InvariantCulture),
                t.Codigo, t.Nombre, t.Modo == MYGModoTarea.Manual ? "Manual" : "Automática", t.EsResumen ? "Sí" : "No",
                !t.EsResumen && f.DuracionDias == 0 ? "Sí" : "No", f.DuracionDias.ToString(CultureInfo.InvariantCulture),
                f.Inicio.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), f.Fin.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                MYGMotorCronograma.FormatoPredecesoras(t, resultado.Filas), Num(f.Avance),
                t.InicioBase?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), t.FinBase?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                t.DuracionBase?.ToString(CultureInfo.InvariantCulture), string.Join("; ", t.Responsables), t.Notas });
        }
        return texto.ToString();
    }

    private static string Campo(string valor)
    {
        valor = (valor ?? "").Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
        string comienzo = valor.TrimStart(' ', '\t', '\r', '\n', '\uFEFF');
        return comienzo.Length > 0 && "=+-@".Contains(comienzo[0]) ? "'" + valor : valor;
    }
}
