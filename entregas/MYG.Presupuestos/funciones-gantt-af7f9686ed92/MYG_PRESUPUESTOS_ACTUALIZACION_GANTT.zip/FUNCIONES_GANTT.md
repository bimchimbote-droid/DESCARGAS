# Funciones de Gantt mostradas en el video

Entrega acumulativa para `bimchimbote-droid/MYG.Presupuestos`, sobre la base
`dd3fb0ce4e4d684fa50b57a364fb64b03a5ef7c6`.
Conserva la franja central de once herramientas de la entrega anterior.
La base exacta comprobada se indica también en VALIDACION.json.

## Funciones implementadas

- **Imprimir** despliega los informes de presupuesto y añade **Programación Gantt**, que abre la vista previa existente con impresora, configuración de página y exportación.
- **Exportar** despliega archivo nativo MYG, MS Project con sólo tareas o con tareas y recursos, XML con las mismas dos opciones, PDF, XLSX, texto y MHT. Se conserva además el CSV anterior.
- **Tiempo de trabajo** muestra y oculta el editor debajo del Gantt. Permite elegir días laborables, editar varios turnos por día, consultar horas diarias/semanales/mensuales, crear/renombrar/eliminar/activar calendarios, navegar por tres meses y agregar excepciones anuales o por intervalo inclusivo de fechas. Cada excepción admite color, día laborable/no laborable y turnos propios.
- **Guardar cambios** valida y aplica el calendario con una sola entrada de historial. Al salir, cambiar de vista/proyecto o exportar, el borrador pendiente ofrece guardar, descartar o cancelar. El botón general Guardar incorpora el calendario pendiente. El texto de una celda se conserva al cambiar de día o excepción.
- **Ruta crítica → Simple / Múltiple** colorea las tareas críticas. Simple usa el fin del proyecto; Múltiple calcula una ruta por cada red independiente de dependencias. Repetir la opción activa oculta el resaltado. Los informes y Excel respetan el modo elegido.
- Las fechas de inicio y de estado del proyecto siguen disponibles en **Otros → Fechas del proyecto**.

El cálculo existente conserva duraciones en días laborables enteros. Los turnos determinan los días disponibles y las horas de los calendarios/exportaciones; esta entrega no convierte el motor en programación de tareas por minutos.

## Formatos y requisitos

El archivo nativo compatible es **MYG SQLite (.sqlite)**, que MYG puede volver a abrir. Si el proyecto procede de una hoja SQLite, la exportación copia la hoja y conserva otros proyectos y tablas. El cronograma MYG se guarda en el documento interno. **No se genera el contenedor propietario .DelphinExpress ni se sincronizan las tablas CPM propietarias de Delphin.** El menú usa el nombre real del formato.

La salida **.mpp** se obtiene mediante la automatización oficial de Microsoft Project de escritorio, que debe estar instalado en Windows. Cierra Project antes de exportar; si falta o está abierto, MYG lo informa y ofrece usar XML. No se renombra un XML a MPP. La apertura del XML en Project y la automatización MPP necesitan validación en Windows.

El **XML MSPDI** se genera sin instalar Project y distingue tareas solas de tareas con recursos reales del presupuesto. El **PDF** utiliza la vista previa y Microsoft Print to PDF; debe estar disponible esa impresora en Windows. Si la vista previa solicita seleccionarla, hazlo y pulsa nuevamente PDF. XLSX, texto, MHT y CSV no requieren Microsoft Project.

## Aplicación manual conservando los avances locales

Repositorio del código: `bimchimbote-droid/MYG.Presupuestos`, rama de referencia `main`.
Carpeta local indicada: `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`.
La publicación del ZIP se hace sólo en el repositorio independiente y público `bimchimbote-droid/DESCARGAS`.

1. Cierra MYG. Conserva una copia de tus cambios locales y extrae el ZIP fuera de la carpeta del proyecto.
2. En la raíz que contiene `MYG.Presupuestos.sln`, ejecuta `git status --short`. Compara tus cambios antes de reemplazar archivos. Conserva `.git` y tus bases de datos en sus ubicaciones.
3. Elige **un único método**:
   - **Archivos completos:** copia los archivos de la tabla respetando las rutas, después de combinar cualquier avance local en esos mismos archivos.
   - **Parche sobre la base original:** usa `gantt-desde-base.patch` si aún no aplicaste la primera entrega.
   - **Parche sobre la entrega de herramientas centrales:** usa `gantt-desde-herramientas-centrales.patch` si ya aplicaste la entrega anterior (SHA256 del ZIP: `176161971b0f0eaf80a597bfbb73dc788495f6490f5437782797207e70015413`). Este parche incorpora sólo la diferencia restante y conserva los doce archivos de aquella entrega.

```powershell
$parche = 'C:\TuCarpeta\Entrega\gantt-desde-herramientas-centrales.patch'
git apply --check $parche
# Sólo si la comprobación termina sin errores:
git apply $parche
```

Si la comprobación indica conflictos, combina manualmente; no fuerces el parche ni apliques ambos parches. Los proyectos SDK incluyen los nuevos `.cs` automáticamente. El ZIP no incluye `.git`, bases privadas, binarios, dependencias ni credenciales.

## Validación de esta entrega

- Compilación Release de los cinco proyectos con .NET SDK 10.0.100: **0 errores y 0 advertencias**.
- Ejecución de MYG.Pruebas: **480 comprobaciones aprobadas**. Incluye calendarios detallados, rutas críticas, XML y recursos. Named Pipes y las muestras privadas opcionales no se ejecutaron en Linux.
- Ejecución aislada de las comprobaciones reales de copia SQLite: **23 comprobaciones aprobadas**. Incluye reapertura, hoja de origen intacta, conservación de otros proyectos/tablas, destino bloqueado, extensión incorrecta y limpieza de temporales. No ejecuta COM.
- Ambos parches se aplicaron a copias temporales de sus bases y los archivos resultantes se compararon byte a byte con los archivos completos. ZIP y SHA256 verificados.
- Las pruebas de interfaz se incluyen y compilan. **No se ejecutaron WinForms, impresión/PDF, automatización MPP ni Revit en Linux.** La coincidencia visual y los flujos de Windows quedan por comprobar allí.

Comandos de compilación y datos (desde la raíz, después de restaurar):

```text
dotnet restore MYG.Presupuestos.sln -p:UseRevitReferencePackages=true --disable-parallel
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true --no-restore -m:2 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, con .NET 10 y una copia de un proyecto:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --cronograma
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --herramientas-centrales
dotnet run --project MYG.Desktop/MYG.Desktop.csproj -c Release
```

Revisa CPM: impresión Gantt; cada destino de exportación; reapertura del SQLite exportado; XML en Project; MPP con Project cerrado; PDF con su impresora; panel inferior con turnos y excepciones; cambio entre calendarios; guardar/descartar/cancelar; y alternancia Simple/Múltiple. Las pruebas UI automatizadas no sustituyen la comprobación real de Project o de la impresora PDF.

## Archivos completos

Acciones respecto a la base original del código. Si ya aplicaste la entrega anterior, sus archivos CREAR ya existen: consérvalos o compara antes de reemplazarlos. El parche incremental incorpora esa situación.

| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | MYG.Core/CalendarioCronogramaMYG.cs | REEMPLAZAR | Horarios semanales, excepciones y conteo de días laborables. |
| 2 | MYG.Core/CronogramaMYG.cs | REEMPLAZAR | Guarda y copia los calendarios nombrados del proyecto. |
| 3 | MYG.Core/ReportesCronogramaMYG.cs | REEMPLAZAR | Respeta el modo de ruta crítica en informes y Excel. |
| 4 | MYG.Core/ExportacionCronogramaMYG.cs | CREAR | Exporta XML Project con tareas o recursos, texto y MHT. |
| 5 | MYG.Core/RutasCriticasCronogramaMYG.cs | CREAR | Calcula rutas críticas simple y múltiple. |
| 6 | MYG.Desktop/CronogramaGanttControl.cs | REEMPLAZAR | Colorea las tareas críticas seleccionadas. |
| 7 | MYG.Desktop/CronogramaPanel.cs | REEMPLAZAR | Integra el panel de calendario y los menús del Gantt. |
| 8 | MYG.Desktop/EditorCronograma.cs | REEMPLAZAR | Conecta impresión y exportación, conservando ediciones pendientes. |
| 9 | MYG.Desktop/EditorEstructura.cs | REEMPLAZAR | Actualiza Pegar al copiar desde el menú de estructura. |
| 10 | MYG.Desktop/EditorForm.cs | REEMPLAZAR | Conserva el calendario pendiente al guardar y cerrar. |
| 11 | MYG.Desktop/EditorHerramientas.cs | REEMPLAZAR | Añade Programación Gantt al menú de impresión. |
| 12 | MYG.Desktop/EditorPresupuestos.cs | REEMPLAZAR | Conecta las herramientas de la franja central. |
| 13 | MYG.Desktop/PresupuestosEstructuraPanel.cs | REEMPLAZAR | Mide los códigos con la fuente elegida. |
| 14 | MYG.Desktop/PresupuestosHerramientasPanel.cs | REEMPLAZAR | Once herramientas centrales y sus estados. |
| 15 | MYG.Desktop/PresupuestosPanel.cs | REEMPLAZAR | Coloca la barra central y configura el formato de vista. |
| 16 | MYG.Desktop/ProyectosAbiertos.cs | REEMPLAZAR | Confirma el calendario pendiente al cambiar de proyecto. |
| 17 | MYG.Desktop/ReportesImpresion.cs | REEMPLAZAR | Transmite la validación del destino a la vista previa. |
| 18 | MYG.Desktop/VistaPreliminarReportesForm.cs | REEMPLAZAR | Exporta desde la vista previa y protege el SQLite abierto. |
| 19 | MYG.Desktop/CronogramaExportacionMenu.cs | CREAR | Menú con los destinos de exportación del video. |
| 20 | MYG.Desktop/CronogramaFuncionesVideo.cs | CREAR | Panel inferior, rutas críticas y acciones de exportación. |
| 21 | MYG.Desktop/EditorHerramientasEstructura.cs | CREAR | Ejecuta los comandos centrales con control de sesión. |
| 22 | MYG.Desktop/ExportacionCronogramaWindows.cs | CREAR | Copia nativa SQLite y MPP mediante Microsoft Project. |
| 23 | MYG.Desktop/HerramientasSistemaPresupuesto.cs | CREAR | Abre Lupa y Calculadora de Windows. |
| 24 | MYG.Desktop/IconosHerramientasPresupuesto.cs | CREAR | Dibuja los once iconos centrales. |
| 25 | MYG.Desktop/PresupuestosFormatoVista.cs | CREAR | Aplica fuente y colores a la vista del presupuesto. |
| 26 | MYG.Desktop/TiempoTrabajoCronogramaControl.cs | CREAR | Editor de calendarios, turnos, meses y excepciones. |
| 27 | MYG.Pruebas/Program.cs | REEMPLAZAR | Registra las nuevas comprobaciones del motor y XML. |
| 28 | MYG.Pruebas/CalendarioTrabajoDetalladoCheck.cs | CREAR | Comprueba horarios, excepciones y persistencia. |
| 29 | MYG.Pruebas/ExportacionCronogramaCheck.cs | CREAR | Comprueba XML, recursos y exportaciones de texto. |
| 30 | MYG.Pruebas/RutasCriticasCronogramaCheck.cs | CREAR | Comprueba rutas simples y redes independientes. |
| 31 | MYG.PruebasUI/CronogramaUICheck.cs | REEMPLAZAR | Comprueba botones, estados y panel inferior. |
| 32 | MYG.PruebasUI/Program.cs | REEMPLAZAR | Registra los selectores --cronograma y --herramientas-centrales. |
| 33 | MYG.PruebasUI/CronogramaMenusUICheck.cs | CREAR | Comprueba los destinos de impresión y exportación. |
| 34 | MYG.PruebasUI/ExportacionCronogramaWindowsCheck.cs | CREAR | Comprueba copia SQLite y protección de destinos. |
| 35 | MYG.PruebasUI/HerramientasCentralesUICheck.cs | CREAR | Comprueba las once herramientas centrales. |
| 36 | MYG.PruebasUI/TiempoTrabajoCronogramaUICheck.cs | CREAR | Comprueba edición, navegación y guardado del calendario. |
| 37 | HERRAMIENTAS_CENTRALES.md | CREAR | Guía de la entrega anterior incluida en el acumulado. |
| 38 | FUNCIONES_GANTT.md | CREAR | Guía de esta entrega, archivos y comprobaciones. |
