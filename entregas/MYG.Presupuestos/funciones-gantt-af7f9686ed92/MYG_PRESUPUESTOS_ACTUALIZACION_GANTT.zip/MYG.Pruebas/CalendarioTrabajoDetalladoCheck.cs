using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class CalendarioTrabajoDetalladoCheck
{
    private static void Exige(bool condicion, string detalle)
    { if (!condicion) throw new Exception("Calendario detallado: " + detalle); }
    private static void Rechaza(Action accion, string detalle)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        throw new Exception("Calendario detallado aceptó " + detalle);
    }
    private static MYGTramoHorario Tramo(int inicio, int fin) => new() { InicioMinuto = inicio, FinMinuto = fin };
    private static MYGHorarioDiaTrabajo Dia(DayOfWeek dia, params MYGTramoHorario[] tramos) =>
        new() { Dia = dia, Tramos = tramos.ToList() };
    private static MYGCalendarioTrabajo Ejemplo() => new()
    {
        Nombre = "Jornadas de obra",
        HorariosSemanales = new()
        {
            Dia(DayOfWeek.Monday, Tramo(480, 720), Tramo(780, 1020)),
            Dia(DayOfWeek.Tuesday, Tramo(420, 660)),
            Dia(DayOfWeek.Thursday, Tramo(480, 720)),
            Dia(DayOfWeek.Friday, Tramo(480, 720))
        },
        Excepciones = new()
        {
            new() { Nombre = "Día del Trabajo", Anual = true, Mes = 5, Dia = 1, Color = "#FFDD88" },
            new() { Nombre = "Navidad", Anual = true, Mes = 12, Dia = 25, Color = "#FFD6D6" },
            new() { Nombre = "Sábado de recuperación", Inicio = new(2026, 12, 26), Fin = new(2026, 12, 26),
                Laborable = true, Tramos = new() { Tramo(540, 780) }, Color = "#CCEECC" },
            new() { Nombre = "Cierre de obra", Inicio = new(2026, 12, 27), Fin = new(2026, 12, 28) }
        }
    };

    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Horarios(pasa);
        ExcepcionesYOrdinales(pasa);
        Validacion(pasa);
        Persistencia(carpeta, pasa);
    }

    private static void Horarios(Action<string> pasa)
    {
        var legado = new MYGCalendarioTrabajo();
        Exige(legado.Nombre == "Predeterminado" && legado.HorariosSemanales.Count == 0 && legado.Excepciones.Count == 0,
            "los valores iniciales no conservan el calendario heredado");
        Exige(legado.HorasDelDia(new(2026, 10, 5)) == 8 && !legado.EsLaborable(new(2026, 10, 10)),
            "el calendario heredado perdió su jornada o el sábado inhábil");
        var c = Ejemplo(); c.Validar();
        string antes = JsonSerializer.Serialize(c);
        Exige(c.HorasDelDia(new(2026, 10, 5)) == 8 && c.HorasDelDia(new(2026, 10, 6)) == 4 &&
            c.HorasDelDia(new(2026, 10, 7)) == 0 && c.HorasDelDia(new(2026, 10, 8)) == 4,
            "no se respetan turnos partidos, duraciones variables o días semanales ausentes");
        Exige(c.ObtenerHorario(new(2026, 10, 5)).Select(t => (t.InicioMinuto, t.FinMinuto))
            .SequenceEqual(new[] { (480, 720), (780, 1020) }) && JsonSerializer.Serialize(c) == antes,
            "consultar un horario cambió los turnos o el modelo original");
        pasa("Calendario conserva compatibilidad L–V/8 h y admite semanas con turnos partidos, horas variables y días inhábiles");
    }

    private static void ExcepcionesYOrdinales(Action<string> pasa)
    {
        var c = Ejemplo();
        Exige(!c.EsLaborable(new(2026, 5, 1)) && !c.EsLaborable(new(2026, 12, 25)) &&
            !c.EsLaborable(new(2027, 12, 25)), "los feriados anuales no se repiten en años distintos");
        Exige(c.HorasDelDia(new(2026, 12, 26)) == 4 && !c.EsLaborable(new(2026, 12, 28)),
            "no aplica el sábado laborable ni el cierre fechado inclusivo");
        Exige(c.SumarDiasLaborables(new(2026, 12, 24), 1) == new DateTime(2026, 12, 26) &&
            c.SumarDiasLaborables(new(2026, 12, 24), 2) == new DateTime(2026, 12, 29) &&
            c.SumarDiasLaborables(new(2026, 12, 29), -1) == new DateTime(2026, 12, 26) &&
            c.ContarDiasLaborables(new(2026, 12, 24), new(2026, 12, 30)) == 3,
            "los ordinales no consideran las excepciones al avanzar, retroceder o contar");
        c.Excepciones.Add(new() { Nombre = "Guardia de Navidad", Inicio = new(2026, 12, 25), Fin = new(2026, 12, 25),
            Laborable = true, Tramos = new() { Tramo(600, 720) } });
        c.Feriados.Add(new(2026, 12, 25));
        c.Excepciones.Add(new() { Nombre = "Día bisiesto", Anual = true, Mes = 2, Dia = 29 });
        c.Excepciones.Add(new() { Nombre = "Guardia anual", Anual = true, Mes = 1, Dia = 1, Laborable = true });
        c.Feriados.Add(new(2028, 1, 1));
        c.Validar();
        Exige(c.HorasDelDia(new(2026, 12, 25)) == 2 && !c.EsLaborable(new(2024, 2, 29)) &&
            c.HorasDelDia(new(2028, 1, 1)) == 8,
            "las guardias explícitas no prevalecen sobre feriados/fin de semana o no se admite 29 de febrero");
        var inicio = new DateTime(2024, 1, 1); var fin = new DateTime(2028, 1, 1);
        int esperado = 0;
        for (var fecha = inicio; fecha <= fin; fecha = fecha.AddDays(1)) if (c.EsLaborable(fecha)) esperado++;
        Exige(c.ContarDiasLaborables(inicio, fin) == esperado,
            "el conteo indexado difiere del horario diario al combinar reglas anuales, rangos y guardias");
        var plan = new MYGCronograma { Calendario = c, FechaInicio = new(2026, 12, 24),
            Tareas = new() { new() { Nombre = "Cuatro jornadas", DuracionDias = 4 } } };
        var fila = MYGMotorCronograma.Calcular(plan).Filas.Single();
        Exige(fila.Inicio == new DateTime(2026, 12, 24) && fila.Fin == new DateTime(2026, 12, 29),
            "el motor del Gantt no consume las mismas excepciones que el calendario");
        pasa("Feriados anuales, año bisiesto, cierres inclusivos y guardias específicas se aplican también al cálculo del Gantt y sus ordinales");

        // Un cierre de casi 10 000 años debe manejarse como intervalo, sin expandir sus días.
        var extenso = new MYGCalendarioTrabajo
        {
            DiasLaborables = Enum.GetValues<DayOfWeek>().ToList(),
            Excepciones = new() { new() { Nombre = "Cierre extenso", Inicio = DateTime.MinValue,
                Fin = new(9999, 12, 30) } }
        };
        Exige(extenso.ContarDiasLaborables(DateTime.MinValue, DateTime.MaxValue) == 1 &&
            extenso.SiguienteLaborable(DateTime.MinValue) == new DateTime(9999, 12, 31),
            "un intervalo extenso perdió su límite o la búsqueda ordinal");
        Rechaza(() => extenso.SumarDiasLaborables(DateTime.MinValue, int.MaxValue), "un desfase fuera del rango DateTime");
        pasa("Intervalos de casi 10 000 años usan conteo ordinal y rechazan desfases fuera de rango sin recorrer sus días");
    }

    private static void Validacion(Action<string> pasa)
    {
        var c = Ejemplo();
        c.HorariosSemanales[0].Tramos.Add(Tramo(700, 800));
        Rechaza(c.Validar, "turnos semanales solapados");
        c = Ejemplo(); c.HorariosSemanales[0].Tramos[0].InicioMinuto = -1;
        Rechaza(c.Validar, "un minuto de inicio negativo");
        c = Ejemplo(); c.HorariosSemanales[0].Tramos[0].FinMinuto = 1441;
        Rechaza(c.Validar, "un minuto de fin posterior a las 24:00");
        c = Ejemplo(); c.HorariosSemanales.Add(Dia(DayOfWeek.Monday, Tramo(480, 720)));
        Rechaza(c.Validar, "un día semanal duplicado");
        c = Ejemplo(); c.Excepciones.Add(new() { Nombre = "Superposición", Inicio = new(2026, 12, 28), Fin = new(2026, 12, 29) });
        Rechaza(c.Validar, "excepciones fechadas superpuestas");
        c = Ejemplo(); c.Excepciones.Add(new() { Anual = true, Mes = 12, Dia = 25 });
        Rechaza(c.Validar, "dos excepciones anuales en la misma fecha");
        c = Ejemplo(); c.Excepciones.Add(new() { Anual = true, Mes = 2, Dia = 30 });
        Rechaza(c.Validar, "una fecha anual inexistente");
        c = Ejemplo(); c.Excepciones.Add(new() { Inicio = new(2026, 5, 2), Fin = new(2026, 5, 1) });
        Rechaza(c.Validar, "un rango invertido");
        c = Ejemplo(); c.Excepciones[2].Tramos.Add(Tramo(700, 800));
        Rechaza(c.Validar, "turnos de excepción solapados");
        pasa("Validación rechaza turnos solapados, minutos inválidos, días duplicados, fechas imposibles y excepciones ambiguas");
    }

    private static void Persistencia(string carpeta, Action<string> pasa)
    {
        var documento = MYGProyectoStorage.Nuevo("CALENDARIOS NOMBRADOS");
        documento.Cronograma = new() { Calendario = Ejemplo(), FechaInicio = new(2026, 12, 24),
            Tareas = new() { new() { Nombre = "Obra con turnos", DuracionDias = 3 } } };
        var alternativo = MYGProyectoStorage.Copia(documento.Cronograma.Calendario);
        alternativo.Nombre = "Segundo calendario";
        alternativo.HorariosSemanales[0].Tramos = new() { Tramo(360, 720) };
        documento.Cronograma.Calendarios.Add(MYGProyectoStorage.Copia(documento.Cronograma.Calendario));
        documento.Cronograma.Calendarios.Add(alternativo);
        string esperado = JsonSerializer.Serialize(documento.Cronograma.Calendario);
        string listaEsperada = JsonSerializer.Serialize(documento.Cronograma.Calendarios);
        var copia = MYGProyectoStorage.Copia(documento);
        Exige(JsonSerializer.Serialize(copia.Cronograma.Calendario) == esperado &&
            JsonSerializer.Serialize(copia.Cronograma.Calendarios) == listaEsperada,
            "la copia JSON perdió nombre, horarios o excepciones");
        copia.Cronograma.Calendario.HorariosSemanales[0].Tramos[0].InicioMinuto = 500;
        copia.Cronograma.Calendario.Excepciones[0].Nombre = "CAMBIO EN COPIA";
        copia.Cronograma.Calendarios[1].Nombre = "CAMBIO EN SEGUNDO CALENDARIO";
        Exige(JsonSerializer.Serialize(documento.Cronograma.Calendario) == esperado &&
            JsonSerializer.Serialize(documento.Cronograma.Calendarios) == listaEsperada,
            "los tramos o excepciones comparten referencias después de copiar");
        // AgregarTarea utiliza la copia manual del motor, distinta de la copia JSON.
        MYGMotorCronograma.AgregarTarea(documento.Cronograma, null, "Nueva tarea");
        Exige(JsonSerializer.Serialize(documento.Cronograma.Calendario) == esperado &&
            JsonSerializer.Serialize(documento.Cronograma.Calendarios) == listaEsperada,
            "la edición mediante copia manual perdió los nuevos campos del calendario");
        foreach (string extension in new[] { ".sqlite", ".myg.json" })
        {
            string ruta = Path.Combine(carpeta, "Calendario detallado" + extension);
            MYGProyectoStorage.Guardar(ruta, documento);
            var reabierto = MYGProyectoStorage.Leer(ruta);
            Exige(JsonSerializer.Serialize(reabierto.Cronograma.Calendario) == esperado &&
                JsonSerializer.Serialize(reabierto.Cronograma.Calendarios) == listaEsperada &&
                reabierto.Cronograma.Calendario.SumarDiasLaborables(new(2026, 12, 24), 2) == new DateTime(2026, 12, 29),
                "guardar/reabrir " + extension + " perdió los horarios, excepciones o sus fechas resultantes");
        }
        pasa("Copia independiente, edición del motor y guardado/reapertura SQLite y JSON conservan nombre, turnos, excepciones y resultados");
    }
}
