using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace MYG_2027;

public enum MYGModoTarea { Automatica, Manual }
public enum MYGTipoVinculo { FC, CC, FF, CF }

public sealed class MYGCronograma
{
    public DateTime FechaInicio { get; set; } = DateTime.Today;
    public DateTime FechaEstado { get; set; } = DateTime.Today;
    public MYGCalendarioTrabajo Calendario { get; set; } = new();
    public List<MYGCalendarioTrabajo> Calendarios { get; set; } = new();
    public List<MYGTareaCronograma> Tareas { get; set; } = new();
    public List<MYGVinculoImportadoDelphin> VinculosImportadosDelphin { get; set; } = new();
    public List<string> AdvertenciasImportacion { get; set; } = new();
}

public sealed class MYGTramoImportadoDelphin
{
    public string Id { get; set; }
    public DateTime Inicio { get; set; }
    public DateTime Fin { get; set; }
    public decimal Duracion { get; set; }
    public decimal Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}

public sealed class MYGFechasImportadasDelphin
{
    public DateTime Inicio { get; set; }
    public DateTime Fin { get; set; }
    public int DuracionDias { get; set; }
    public List<MYGTramoImportadoDelphin> Tramos { get; set; } = new();
}

public sealed class MYGVinculoImportadoDelphin
{
    public string Id { get; set; }
    public string OrigenId { get; set; }
    public string DestinoId { get; set; }
    public string ProgramacionDestinoId { get; set; }
    public int Tipo { get; set; }
    public decimal Desfase { get; set; }
}

public sealed class MYGTareaCronograma
{
    public string Id { get; set; } = MYGProyectoStorage.NuevoId();
    public string PadreId { get; set; }
    public string PresupuestoId { get; set; }
    public string PartidaId { get; set; }
    public string Codigo { get; set; }
    public string Nombre { get; set; } = "Nueva tarea";
    public bool EsResumen { get; set; }
    public MYGModoTarea Modo { get; set; } = MYGModoTarea.Automatica;
    public DateTime? InicioManual { get; set; }
    public MYGFechasImportadasDelphin FechasImportadasDelphin { get; set; }
    public int DuracionDias { get; set; } = 1;
    public decimal Avance { get; set; }
    public string Notas { get; set; }
    public List<string> Responsables { get; set; } = new();
    public List<MYGDependenciaCronograma> Predecesoras { get; set; } = new();
    public DateTime? InicioBase { get; set; }
    public DateTime? FinBase { get; set; }
    public int? DuracionBase { get; set; }
}

public sealed class MYGDependenciaCronograma
{
    public string PredecesoraId { get; set; }
    public MYGTipoVinculo Tipo { get; set; } = MYGTipoVinculo.FC;
    public int DesfaseDias { get; set; }
}

public sealed class MYGResultadoTarea
{
    public MYGTareaCronograma Tarea { get; internal set; }
    public DateTime Inicio { get; internal set; }
    public DateTime Fin { get; internal set; }
    public int Numero { get; internal set; }
    public int Nivel { get; internal set; }
    public int DuracionDias { get; internal set; }
    public int DiasCalendario { get; internal set; }
    public int HolguraDias { get; internal set; }
    public bool EsCritica { get; internal set; }
    public decimal Avance { get; internal set; }
    public IReadOnlyList<string> Advertencias { get; internal set; } = Array.Empty<string>();
}

public sealed class MYGResultadoCronograma
{
    public IReadOnlyList<MYGResultadoTarea> Filas { get; internal set; } = Array.Empty<MYGResultadoTarea>();
    public DateTime Inicio { get; internal set; }
    public DateTime Fin { get; internal set; }
    public IReadOnlyList<string> Advertencias { get; internal set; } = Array.Empty<string>();
}

/// <summary>CPM en días laborables enteros. El cálculo y sus resultados son
/// instantáneas: nunca modifican el cronograma ni el presupuesto de origen.</summary>
public static class MYGMotorCronograma
{
    private static InvalidDataException Error(string texto) => new(texto);
    private static bool Vacio(string texto) => string.IsNullOrWhiteSpace(texto);
    private static int Extent(int duracion) => Math.Max(0, duracion - 1);

    // Al abrir una planificación existente sus fechas son una instantánea. Una
    // edición de modo, inicio o duración vuelve a usar el cálculo habitual.
    public static bool ConservaFechasDelphin(MYGTareaCronograma tarea) => tarea?.FechasImportadasDelphin is { } f &&
        tarea.Modo == MYGModoTarea.Manual && tarea.InicioManual?.Date == f.Inicio.Date && tarea.DuracionDias == f.DuracionDias;

    public static MYGResultadoCronograma Calcular(MYGCronograma plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        if (plan.Calendarios != null)
        {
            var nombresCalendarios = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var calendarioGuardado in plan.Calendarios)
            {
                if (calendarioGuardado == null || !nombresCalendarios.Add(calendarioGuardado.Nombre?.Trim() ?? ""))
                    throw Error("Los calendarios del proyecto requieren nombres únicos y datos válidos.");
                calendarioGuardado.Validar();
            }
        }
        var calendario = new MYGCalendarioEntero(plan.Calendario);
        if (plan.FechaInicio == default || plan.FechaEstado == default || plan.Tareas == null)
            throw Error("Indique las fechas de inicio y estado y una lista válida de tareas.");
        var tareas = new Dictionary<string, MYGTareaCronograma>(StringComparer.Ordinal);
        foreach (var t in plan.Tareas)
        {
            if (t == null || Vacio(t.Id) || !tareas.TryAdd(t.Id, t) || Vacio(t.Nombre) ||
                !Enum.IsDefined(t.Modo) || t.DuracionDias < 0 || t.DuracionDias > 36500 || t.Avance < 0 || t.Avance > 100 ||
                t.Responsables == null || t.Responsables.Any(Vacio) || t.Predecesoras == null)
                throw Error("Cada tarea requiere identidad única, nombre, duración de 0 a 36.500 días y avance de 0 a 100 %.");
            if (!t.EsResumen && t.Modo == MYGModoTarea.Manual && (!t.InicioManual.HasValue || t.InicioManual.Value == default))
                throw Error("Indique la fecha de inicio de la tarea manual «" + t.Nombre + "».");
            if (t.FechasImportadasDelphin is { } importadas && (importadas.Fin.Date < importadas.Inicio.Date || importadas.Tramos == null ||
                importadas.Tramos.Any(s => s == null || s.Fin.Date < s.Inicio.Date || s.Porcentaje < 0)))
                throw Error("Las fechas o tramos importados de la tarea no son válidos: " + t.Nombre);
            bool algunaBase = t.InicioBase.HasValue || t.FinBase.HasValue || t.DuracionBase.HasValue;
            if (algunaBase && (!t.InicioBase.HasValue || !t.FinBase.HasValue || !t.DuracionBase.HasValue ||
                t.DuracionBase.Value < 0 || t.FinBase.Value.Date < t.InicioBase.Value.Date))
                throw Error("La línea base debe contener inicio, fin y duración válidos: " + t.Nombre);
        }
        var hijos = tareas.Values.Where(t => !Vacio(t.PadreId)).GroupBy(t => t.PadreId, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
        foreach (var t in tareas.Values)
            if (!Vacio(t.PadreId) && (!tareas.TryGetValue(t.PadreId, out var padre) || !padre.EsResumen))
                throw Error("La tarea «" + t.Nombre + "» debe pertenecer a un resumen existente.");
        var estados = new Dictionary<string, int>(StringComparer.Ordinal);
        void ValidarPadre(MYGTareaCronograma t)
        {
            if (estados.TryGetValue(t.Id, out int estado))
            { if (estado == 1) throw Error("La jerarquía del cronograma contiene una referencia circular."); return; }
            estados[t.Id] = 1;
            if (!Vacio(t.PadreId)) ValidarPadre(tareas[t.PadreId]);
            estados[t.Id] = 2;
        }
        foreach (var t in tareas.Values) ValidarPadre(t);
        var hojas = tareas.Values.Where(t => !t.EsResumen).ToList();
        var sucesoras = hojas.ToDictionary(t => t.Id, _ => new List<(MYGTareaCronograma Tarea, MYGDependenciaCronograma Vinculo)>(), StringComparer.Ordinal);
        var pendientes = hojas.ToDictionary(t => t.Id, t => t.Predecesoras.Count, StringComparer.Ordinal);
        foreach (var t in tareas.Values)
        {
            if (t.EsResumen && t.Predecesoras.Count != 0) throw Error("Los vínculos se asignan a tareas o hitos, no a resúmenes.");
            var vistas = new HashSet<string>(StringComparer.Ordinal);
            foreach (var d in t.Predecesoras)
            {
                if (d == null || Vacio(d.PredecesoraId) || !Enum.IsDefined(d.Tipo) || !vistas.Add(d.PredecesoraId) ||
                    d.PredecesoraId == t.Id || !tareas.TryGetValue(d.PredecesoraId, out var origen) || origen.EsResumen)
                    throw Error("Predecesora inexistente, repetida, circular o de resumen en «" + t.Nombre + "».");
                sucesoras[origen.Id].Add((t, d));
            }
        }
        var orden = new List<MYGTareaCronograma>();
        var disponibles = new Queue<MYGTareaCronograma>(hojas.Where(t => pendientes[t.Id] == 0));
        while (disponibles.TryDequeue(out var t))
        {
            orden.Add(t);
            foreach (var s in sucesoras[t.Id]) if (--pendientes[s.Tarea.Id] == 0) disponibles.Enqueue(s.Tarea);
        }
        if (orden.Count != hojas.Count) throw Error("Las dependencias del cronograma contienen un ciclo, incluidas las tareas manuales.");

        long inicioProyecto = calendario.Primero(plan.FechaInicio);
        var inicio = new Dictionary<string, long>(StringComparer.Ordinal);
        var resultado = new Dictionary<string, MYGResultadoTarea>(StringComparer.Ordinal);
        foreach (var t in orden)
        {
            long s = t.Modo == MYGModoTarea.Manual ? calendario.Primero(t.InicioManual.Value) : inicioProyecto;
            if (t.Modo == MYGModoTarea.Automatica)
                foreach (var d in t.Predecesoras)
                {
                    var anterior = resultado[d.PredecesoraId];
                    long restriccion = d.Tipo switch
                    {
                        MYGTipoVinculo.FC => calendario.Despues(anterior.Fin) + d.DesfaseDias,
                        MYGTipoVinculo.CC => calendario.Primero(anterior.Inicio) + d.DesfaseDias,
                        MYGTipoVinculo.FF => calendario.Primero(anterior.Fin) + d.DesfaseDias - Extent(t.DuracionDias),
                        _ => calendario.Primero(anterior.Inicio) + d.DesfaseDias - Extent(t.DuracionDias)
                    };
                    s = Math.Max(s, restriccion);
                }
            var comienzo = t.Modo == MYGModoTarea.Manual ? t.InicioManual.Value.Date : calendario.Fecha(s);
            var fin = ConservaFechasDelphin(t) ? t.FechasImportadasDelphin.Fin.Date :
                t.DuracionDias == 0 ? comienzo : calendario.Fecha(s + Extent(t.DuracionDias));
            inicio.Add(t.Id, s);
            resultado.Add(t.Id, new MYGResultadoTarea { Tarea = Copiar(t), Inicio = comienzo, Fin = fin,
                DuracionDias = t.DuracionDias, DiasCalendario = t.DuracionDias == 0 ? 0 : (fin - comienzo).Days + 1,
                Avance = t.Avance });
        }
        foreach (var t in orden.Where(t => t.Modo == MYGModoTarea.Manual))
        {
            var advertencias = new List<string>();
            foreach (var d in t.Predecesoras)
            {
                var anterior = resultado[d.PredecesoraId];
                long requerido = d.Tipo switch
                {
                    MYGTipoVinculo.FC => calendario.Despues(anterior.Fin) + d.DesfaseDias,
                    MYGTipoVinculo.CC => calendario.Primero(anterior.Inicio) + d.DesfaseDias,
                    MYGTipoVinculo.FF => calendario.Primero(anterior.Fin) + d.DesfaseDias,
                    _ => calendario.Primero(anterior.Inicio) + d.DesfaseDias
                };
                bool comienzo = d.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC;
                var actual = comienzo ? resultado[t.Id].Inicio : resultado[t.Id].Fin;
                if (calendario.AnteriorOIgual(actual) < requerido)
                    advertencias.Add("La tarea manual «" + t.Nombre + "» " + (comienzo ? "comienza" : "termina") +
                        " antes de lo requerido por «" + anterior.Tarea.Nombre + "» (" + d.Tipo +
                        (d.DesfaseDias == 0 ? "" : (d.DesfaseDias > 0 ? "+" : "") + d.DesfaseDias.ToString(CultureInfo.InvariantCulture)) + ").");
            }
            resultado[t.Id].Advertencias = advertencias.AsReadOnly();
        }
        // Los manuales fijan la fecha para el recorrido inverso; un compromiso
        // manual incompatible puede dar holgura negativa sin moverlo ni bloquearlo.
        long horizonte = resultado.Count == 0 ? inicioProyecto : resultado.Values.Max(r => calendario.Primero(r.Fin));
        var tardio = orden.ToDictionary(t => t.Id,
            t => t.Modo == MYGModoTarea.Manual ? inicio[t.Id] : horizonte - Extent(t.DuracionDias), StringComparer.Ordinal);
        foreach (var t in orden.AsEnumerable().Reverse())
        {
            if (t.Modo == MYGModoTarea.Manual) continue;
            foreach (var s in sucesoras[t.Id])
            {
                long peso = s.Vinculo.Tipo switch
                {
                    MYGTipoVinculo.FC => Extent(t.DuracionDias) + 1L + s.Vinculo.DesfaseDias,
                    MYGTipoVinculo.CC => s.Vinculo.DesfaseDias,
                    MYGTipoVinculo.FF => (long)Extent(t.DuracionDias) - Extent(s.Tarea.DuracionDias) + s.Vinculo.DesfaseDias,
                    _ => -(long)Extent(s.Tarea.DuracionDias) + s.Vinculo.DesfaseDias
                };
                long limiteSucesora = tardio[s.Tarea.Id];
                if (s.Tarea.Modo == MYGModoTarea.Manual)
                {
                    var fija = resultado[s.Tarea.Id];
                    limiteSucesora = s.Vinculo.Tipo is MYGTipoVinculo.FC or MYGTipoVinculo.CC
                        ? calendario.AnteriorOIgual(fija.Inicio)
                        : calendario.AnteriorOIgual(fija.Fin) - Extent(s.Tarea.DuracionDias);
                }
                tardio[t.Id] = Math.Min(tardio[t.Id], limiteSucesora - peso);
            }
            long holgura = tardio[t.Id] - inicio[t.Id];
            if (holgura < int.MinValue || holgura > int.MaxValue) throw Error("El desfase produce una holgura fuera del rango admitido.");
            resultado[t.Id].HolguraDias = (int)holgura;
            resultado[t.Id].EsCritica = holgura <= 0;
        }

        (decimal Peso, decimal Avance) Resumir(MYGTareaCronograma t)
        {
            if (!t.EsResumen) return (Math.Max(1, t.DuracionDias), Math.Max(1, t.DuracionDias) * t.Avance);
            var descendientes = hijos.GetValueOrDefault(t.Id) ?? new();
            decimal peso = 0, avance = 0;
            foreach (var hijo in descendientes)
            { var agregado = Resumir(hijo); peso += agregado.Peso; avance += agregado.Avance; }
            var valores = descendientes.Select(h => resultado[h.Id]).ToArray();
            var comienzo = valores.Length == 0 ? calendario.Fecha(inicioProyecto) : valores.Min(r => r.Inicio);
            var fin = valores.Length == 0 ? comienzo : valores.Max(r => r.Fin);
            int duracion = valores.Length == 0 || valores.All(v => v.DuracionDias == 0) && comienzo == fin ? 0 : calendario.Contar(comienzo, fin);
            var copia = Copiar(t); copia.Avance = peso == 0 ? 0 : avance / peso;
            resultado[t.Id] = new MYGResultadoTarea { Tarea = copia, Inicio = comienzo, Fin = fin,
                DuracionDias = duracion, DiasCalendario = valores.Length == 0 || duracion == 0 && comienzo == fin ? 0 : (fin - comienzo).Days + 1,
                Avance = copia.Avance, HolguraDias = valores.Select(v => v.HolguraDias).DefaultIfEmpty(0).Min(),
                EsCritica = valores.Any(v => v.EsCritica) };
            return (peso, avance);
        }
        var raices = tareas.Values.Where(t => Vacio(t.PadreId)).ToList();
        foreach (var t in raices) Resumir(t);
        var filas = new List<MYGResultadoTarea>();
        void AgregarFila(MYGTareaCronograma t, int nivel)
        {
            var fila = resultado[t.Id]; fila.Numero = filas.Count + 1; fila.Nivel = nivel; filas.Add(fila);
            if (hijos.TryGetValue(t.Id, out var lista)) foreach (var hijo in lista) AgregarFila(hijo, nivel + 1);
        }
        foreach (var t in raices) AgregarFila(t, 0);
        return new MYGResultadoCronograma { Filas = filas.AsReadOnly(),
            Inicio = filas.Count == 0 ? calendario.Fecha(inicioProyecto) : filas.Min(f => f.Inicio),
            Fin = filas.Count == 0 ? calendario.Fecha(inicioProyecto) : filas.Max(f => f.Fin),
            Advertencias = (plan.AdvertenciasImportacion ?? new()).Concat(filas.SelectMany(f => f.Advertencias)).ToList().AsReadOnly() };
    }

    public static void Validar(MYGCronograma plan) => Calcular(plan);

    private static MYGTareaCronograma Copiar(MYGTareaCronograma t) => new()
    {
        Id = t.Id, PadreId = t.PadreId, PresupuestoId = t.PresupuestoId, PartidaId = t.PartidaId,
        Codigo = t.Codigo, Nombre = t.Nombre, EsResumen = t.EsResumen, Modo = t.Modo, InicioManual = t.InicioManual,
        FechasImportadasDelphin = MYGProyectoStorage.Copia(t.FechasImportadasDelphin),
        DuracionDias = t.DuracionDias, Avance = t.Avance, Notas = t.Notas,
        Responsables = t.Responsables?.ToList(), Predecesoras = t.Predecesoras?.Select(d => d == null ? null :
            new MYGDependenciaCronograma { PredecesoraId = d.PredecesoraId, Tipo = d.Tipo, DesfaseDias = d.DesfaseDias }).ToList(),
        InicioBase = t.InicioBase, FinBase = t.FinBase, DuracionBase = t.DuracionBase
    };
    private static MYGCronograma Copiar(MYGCronograma p) => new()
    {
        FechaInicio = p.FechaInicio, FechaEstado = p.FechaEstado,
        Calendario = MYGProyectoStorage.Copia(p.Calendario),
        Calendarios = MYGProyectoStorage.Copia(p.Calendarios),
        VinculosImportadosDelphin = MYGProyectoStorage.Copia(p.VinculosImportadosDelphin),
        AdvertenciasImportacion = p.AdvertenciasImportacion?.ToList(),
        Tareas = p.Tareas?.Select(t => t == null ? null : Copiar(t)).ToList()
    };
    private static void Aplicar(MYGCronograma destino, MYGCronograma copia)
    {
        destino.FechaInicio = copia.FechaInicio; destino.FechaEstado = copia.FechaEstado;
        destino.Calendario = copia.Calendario;
        destino.Calendarios = copia.Calendarios;
        destino.VinculosImportadosDelphin = copia.VinculosImportadosDelphin;
        destino.AdvertenciasImportacion = copia.AdvertenciasImportacion;
        var existentes = destino.Tareas.ToDictionary(t => t.Id, StringComparer.Ordinal);
        destino.Tareas = copia.Tareas.Select(t =>
        {
            if (!existentes.TryGetValue(t.Id, out var anterior)) return t;
            anterior.PadreId = t.PadreId; anterior.PresupuestoId = t.PresupuestoId; anterior.PartidaId = t.PartidaId;
            anterior.Codigo = t.Codigo; anterior.Nombre = t.Nombre; anterior.EsResumen = t.EsResumen;
            anterior.Modo = t.Modo; anterior.InicioManual = t.InicioManual; anterior.DuracionDias = t.DuracionDias;
            anterior.FechasImportadasDelphin = t.FechasImportadasDelphin;
            anterior.Avance = t.Avance; anterior.Notas = t.Notas; anterior.Responsables = t.Responsables;
            anterior.Predecesoras = t.Predecesoras; anterior.InicioBase = t.InicioBase;
            anterior.FinBase = t.FinBase; anterior.DuracionBase = t.DuracionBase;
            return anterior;
        }).ToList();
    }
    private static MYGCronograma Editar(MYGCronograma plan, Action<MYGCronograma> accion)
    {
        ArgumentNullException.ThrowIfNull(plan); Validar(plan);
        var copia = Copiar(plan); accion(copia); Validar(copia); Aplicar(plan, copia); return plan;
    }

    private static string IdOrigen(string presupuestoId, string partidaId) => partidaId == null
        ? "PRES:" + presupuestoId : "ITEM:" + presupuestoId.Length.ToString(CultureInfo.InvariantCulture) + ":" + presupuestoId + ":" + partidaId;

    private static List<MYGTareaCronograma> Origen(MYGProyectoDocumento doc)
    {
        ArgumentNullException.ThrowIfNull(doc);
        if (doc.Presupuestos == null || doc.Presupuestos.Any(p => p == null || Vacio(p.Id)) ||
            doc.Presupuestos.Select(p => p.Id).Distinct(StringComparer.Ordinal).Count() != doc.Presupuestos.Count)
            throw Error("El proyecto contiene presupuestos incompletos o repetidos.");
        var filas = new List<MYGTareaCronograma>();
        foreach (var p in doc.Presupuestos.OrderBy(p => p.Posicion).ThenBy(p => p.Item, StringComparer.Ordinal))
        {
            var raiz = new MYGTareaCronograma { Id = IdOrigen(p.Id, null), PresupuestoId = p.Id,
                Codigo = p.Item, Nombre = Vacio(p.Nombre) ? "Presupuesto" : p.Nombre, EsResumen = true, DuracionDias = 0 };
            filas.Add(raiz);
            if (p.Items == null || p.Items.Any(i => i == null || Vacio(i.Id)) || p.Items.Select(i => i.Id).Distinct(StringComparer.Ordinal).Count() != p.Items.Count)
                throw Error("El presupuesto contiene partidas incompletas o repetidas.");
            foreach (var i in MYGOrdenPresupuestos.FilasOrdenadas(p))
                filas.Add(new MYGTareaCronograma { Id = IdOrigen(p.Id, i.Id), PresupuestoId = p.Id, PartidaId = i.Id,
                    PadreId = Vacio(i.ParentId) ? raiz.Id : IdOrigen(p.Id, i.ParentId), Codigo = i.Item,
                    Nombre = Vacio(i.Descripcion) ? "Partida" : i.Descripcion, EsResumen = MYGProyectoStorage.EsTitulo(i),
                    DuracionDias = MYGProyectoStorage.EsTitulo(i) ? 0 : 1 });
        }
        return filas;
    }

    public static MYGCronograma CrearDesdePresupuestos(MYGProyectoDocumento doc)
    {
        ArgumentNullException.ThrowIfNull(doc);
        var p = new MYGCronograma { FechaInicio = (doc.Datos?.FechaInicio ?? doc.Datos?.FechaElaboracion ?? DateTime.Today).Date,
            Tareas = Origen(doc) };
        Validar(p); return p;
    }

    /// <summary>Las tareas cuyo origen desaparece se conservan como personalizadas,
    /// con avance, notas, vínculos y línea base. Los vínculos incompatibles con un
    /// nodo convertido en resumen se retiran, sin modificar el presupuesto.</summary>
    public static void SincronizarPresupuestos(MYGProyectoDocumento doc, MYGCronograma plan)
    {
        var origen = Origen(doc);
        Editar(plan, copia =>
        {
            var anteriores = new Dictionary<(string Presupuesto, string Partida), MYGTareaCronograma>();
            foreach (var t in copia.Tareas.Where(t => !Vacio(t.PresupuestoId)))
                if (!anteriores.TryAdd((t.PresupuestoId, t.PartidaId ?? ""), t))
                    throw Error("Hay tareas repetidas para el mismo origen del presupuesto.");
            var vigentes = new HashSet<string>(StringComparer.Ordinal);
            var equivalencias = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var o in origen)
            {
                if (!anteriores.TryGetValue((o.PresupuestoId, o.PartidaId ?? ""), out var t))
                { t = Copiar(o); if (copia.Tareas.Any(x => x.Id == t.Id)) t.Id = MYGProyectoStorage.NuevoId(); copia.Tareas.Add(t); }
                t.Nombre = o.Nombre; t.Codigo = o.Codigo;
                t.EsResumen = o.EsResumen || copia.Tareas.Any(x => x.PadreId == t.Id);
                vigentes.Add(t.Id); equivalencias.Add(o.Id, t.Id);
            }
            foreach (var o in origen)
            {
                var t = copia.Tareas.First(t => t.Id == equivalencias[o.Id]);
                t.PadreId = o.PadreId == null ? null : equivalencias.GetValueOrDefault(o.PadreId)
                    ?? throw Error("La jerarquía de origen del presupuesto contiene un padre inexistente.");
            }
            foreach (var t in copia.Tareas.Where(t => !Vacio(t.PresupuestoId) && !vigentes.Contains(t.Id)))
            { t.PresupuestoId = null; t.PartidaId = null; }
            var resumenes = copia.Tareas.Where(t => t.EsResumen).Select(t => t.Id).ToHashSet(StringComparer.Ordinal);
            foreach (var t in copia.Tareas)
            { if (t.EsResumen) t.Predecesoras.Clear(); else t.Predecesoras.RemoveAll(d => resumenes.Contains(d.PredecesoraId)); }
        });
    }

    public static MYGTareaCronograma AgregarTarea(MYGCronograma plan, string padreId, string nombre, bool hito = false)
    {
        if (Vacio(nombre)) throw Error("Indique el nombre de la tarea.");
        var nueva = new MYGTareaCronograma { PadreId = Vacio(padreId) ? null : padreId, Nombre = nombre.Trim(), DuracionDias = hito ? 0 : 1 };
        Editar(plan, copia =>
        {
            if (nueva.PadreId != null)
            { var padre = copia.Tareas.FirstOrDefault(t => t.Id == nueva.PadreId) ?? throw Error("El resumen seleccionado ya no existe."); padre.EsResumen = true; }
            copia.Tareas.Add(nueva);
        });
        return plan.Tareas.Single(t => t.Id == nueva.Id);
    }

    public static void EliminarTarea(MYGCronograma plan, string id) => Editar(plan, copia =>
    {
        if (!copia.Tareas.Any(t => t.Id == id)) throw Error("La tarea seleccionada ya no existe.");
        var borrar = new HashSet<string>(StringComparer.Ordinal) { id };
        bool cambio;
        do { cambio = false; foreach (var t in copia.Tareas) if (!Vacio(t.PadreId) && borrar.Contains(t.PadreId)) cambio |= borrar.Add(t.Id); } while (cambio);
        copia.Tareas.RemoveAll(t => borrar.Contains(t.Id));
        foreach (var t in copia.Tareas) t.Predecesoras.RemoveAll(d => borrar.Contains(d.PredecesoraId));
    });

    public static void EstablecerLineaBase(MYGCronograma plan)
    {
        var calculo = Calcular(plan).Filas.ToDictionary(r => r.Tarea.Id, StringComparer.Ordinal);
        Editar(plan, copia => { foreach (var t in copia.Tareas)
            { var r = calculo[t.Id]; t.InicioBase = r.Inicio; t.FinBase = r.Fin; t.DuracionBase = r.DuracionDias; } });
    }
    public static void QuitarLineaBase(MYGCronograma plan) => Editar(plan, copia =>
    { foreach (var t in copia.Tareas) { t.InicioBase = null; t.FinBase = null; t.DuracionBase = null; } });

    public static List<MYGDependenciaCronograma> LeerPredecesoras(string texto,
        IReadOnlyList<MYGResultadoTarea> filas, string tareaId)
    {
        ArgumentNullException.ThrowIfNull(filas);
        var actual = filas.FirstOrDefault(f => f.Tarea.Id == tareaId) ?? throw Error("La tarea seleccionada ya no existe.");
        if (actual.Tarea.EsResumen) throw Error("Las predecesoras se asignan a tareas o hitos, no a resúmenes.");
        var resultado = new List<MYGDependenciaCronograma>();
        if (Vacio(texto)) return resultado;
        var vistas = new HashSet<string>(StringComparer.Ordinal);
        foreach (var token in texto.Split(';', ','))
        {
            var coincidencia = Regex.Match(token, @"^\s*(\d+)\s*(FC|CC|FF|CF)?\s*([+-]\s*\d+)?\s*$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            if (!coincidencia.Success || !int.TryParse(coincidencia.Groups[1].Value, NumberStyles.None, CultureInfo.InvariantCulture, out int numero))
                throw Error("Predecesora no válida. Use, por ejemplo: 3FC+2;5CC-1.");
            var fila = filas.FirstOrDefault(f => f.Numero == numero);
            if (fila == null || fila.Tarea.EsResumen || fila.Tarea.Id == tareaId || !vistas.Add(fila.Tarea.Id))
                throw Error("La fila predecesora no existe, es un resumen, se repite o referencia la misma tarea.");
            var tipo = coincidencia.Groups[2].Success ? Enum.Parse<MYGTipoVinculo>(coincidencia.Groups[2].Value.ToUpperInvariant()) : MYGTipoVinculo.FC;
            int desfase = 0;
            if (coincidencia.Groups[3].Success && !int.TryParse(Regex.Replace(coincidencia.Groups[3].Value, @"\s", ""), NumberStyles.AllowLeadingSign,
                CultureInfo.InvariantCulture, out desfase)) throw Error("El desfase está fuera del rango permitido.");
            resultado.Add(new MYGDependenciaCronograma { PredecesoraId = fila.Tarea.Id, Tipo = tipo, DesfaseDias = desfase });
        }
        return resultado;
    }

    public static string FormatoPredecesoras(MYGTareaCronograma tarea, IReadOnlyList<MYGResultadoTarea> filas)
    {
        ArgumentNullException.ThrowIfNull(tarea); ArgumentNullException.ThrowIfNull(filas);
        return string.Join(";", tarea.Predecesoras.Select(d =>
        {
            var fila = filas.FirstOrDefault(f => f.Tarea.Id == d.PredecesoraId) ?? throw Error("La predecesora ya no pertenece al cronograma.");
            return fila.Numero.ToString(CultureInfo.InvariantCulture) + d.Tipo + (d.DesfaseDias == 0 ? "" :
                (d.DesfaseDias > 0 ? "+" : "") + d.DesfaseDias.ToString(CultureInfo.InvariantCulture));
        }));
    }

    private static List<string> Seleccion(MYGCronograma copia, IEnumerable<string> ids)
    {
        if (ids == null) throw new ArgumentNullException(nameof(ids));
        var valores = ids.ToList();
        if (valores.Count == 0 || valores.Any(Vacio) || valores.Distinct(StringComparer.Ordinal).Count() != valores.Count ||
            valores.Any(id => !copia.Tareas.Any(t => t.Id == id && !t.EsResumen)))
            throw Error("Seleccione tareas o hitos existentes, sin resúmenes ni filas repetidas.");
        return valores;
    }
    public static void Vincular(MYGCronograma plan, IEnumerable<string> ids, MYGTipoVinculo tipo = MYGTipoVinculo.FC)
    {
        if (!Enum.IsDefined(tipo)) throw Error("El tipo de vínculo no es válido.");
        var seleccion = ids?.ToList() ?? throw new ArgumentNullException(nameof(ids));
        Editar(plan, copia =>
        {
            var valores = Seleccion(copia, seleccion);
            if (valores.Count < 2) throw Error("Seleccione al menos dos tareas para vincularlas.");
            for (int n = 1; n < valores.Count; n++)
            {
                var t = copia.Tareas.Single(t => t.Id == valores[n]);
                var vinculo = t.Predecesoras.FirstOrDefault(d => d.PredecesoraId == valores[n - 1]);
                if (vinculo == null) t.Predecesoras.Add(new MYGDependenciaCronograma { PredecesoraId = valores[n - 1], Tipo = tipo });
                else vinculo.Tipo = tipo;
            }
        });
    }
    /// <summary>Con varias tareas elimina los vínculos entre ellas; con una sola,
    /// retira sus vínculos entrantes y salientes.</summary>
    public static void Desvincular(MYGCronograma plan, IEnumerable<string> ids)
    {
        var seleccion = ids?.ToList() ?? throw new ArgumentNullException(nameof(ids));
        Editar(plan, copia =>
        {
            var valores = Seleccion(copia, seleccion).ToHashSet(StringComparer.Ordinal);
            foreach (var t in copia.Tareas)
                t.Predecesoras.RemoveAll(d => valores.Count == 1 ? valores.Contains(t.Id) || valores.Contains(d.PredecesoraId)
                    : valores.Contains(t.Id) && valores.Contains(d.PredecesoraId));
        });
    }
}
