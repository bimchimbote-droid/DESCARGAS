using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public sealed class MYGFeriadoAnual
{
    public int Mes { get; set; }
    public int Dia { get; set; }
}

public sealed class MYGTramoHorario
{
    public int InicioMinuto { get; set; }
    public int FinMinuto { get; set; }
}

public sealed class MYGHorarioDiaTrabajo
{
    public DayOfWeek Dia { get; set; }
    public List<MYGTramoHorario> Tramos { get; set; } = new();
}

public sealed class MYGExcepcionCalendario
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Nombre { get; set; } = "";
    public bool Anual { get; set; }
    public int Mes { get; set; }
    public int Dia { get; set; }
    public DateTime? Inicio { get; set; }
    public DateTime? Fin { get; set; }
    public bool Laborable { get; set; }
    public string Color { get; set; } = "#FDE9D9";
    public List<MYGTramoHorario> Tramos { get; set; } = new();

    internal bool Contiene(DateTime fecha) => Anual ? Mes == fecha.Month && Dia == fecha.Day :
        Inicio.HasValue && Fin.HasValue && fecha.Date >= Inicio.Value.Date && fecha.Date <= Fin.Value.Date;
}

public sealed class MYGCalendarioTrabajo
{
    public string Nombre { get; set; } = "Predeterminado";
    public List<DayOfWeek> DiasLaborables { get; set; } = new()
    { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday };
    public List<DateTime> Feriados { get; set; } = new();
    public List<MYGFeriadoAnual> FeriadosAnuales { get; set; } = new();
    public decimal HorasPorDia { get; set; } = 8;
    // Una lista vacía conserva los calendarios guardados antes del editor de horarios.
    public List<MYGHorarioDiaTrabajo> HorariosSemanales { get; set; } = new();
    public List<MYGExcepcionCalendario> Excepciones { get; set; } = new();

    public IReadOnlyList<MYGTramoHorario> ObtenerHorario(DateTime fecha)
    {
        // Una excepción fechada permite, por ejemplo, trabajar una Navidad concreta.
        var excepcion = Excepciones?.FirstOrDefault(e => e != null && !e.Anual && e.Contiene(fecha)) ??
            Excepciones?.FirstOrDefault(e => e != null && e.Anual && e.Contiene(fecha));
        if (excepcion != null)
        {
            if (!excepcion.Laborable) return Array.Empty<MYGTramoHorario>();
            if (excepcion.Tramos?.Count > 0) return Ordenar(excepcion.Tramos);
            var semanal = HorarioSemanal(fecha.DayOfWeek);
            return semanal.Count > 0 ? semanal : JornadaPredeterminada();
        }
        if ((Feriados?.Any(f => f.Date == fecha.Date) ?? false) ||
            (FeriadosAnuales?.Any(f => f != null && f.Mes == fecha.Month && f.Dia == fecha.Day) ?? false))
            return Array.Empty<MYGTramoHorario>();
        return HorarioSemanal(fecha.DayOfWeek);
    }

    public decimal HorasDelDia(DateTime fecha) => ObtenerHorario(fecha).Sum(t => t.FinMinuto - t.InicioMinuto) / 60m;
    public bool EsLaborable(DateTime fecha) => ObtenerHorario(fecha).Count > 0;

    internal IReadOnlyList<MYGTramoHorario> HorarioSemanal(DayOfWeek dia)
    {
        if (HorariosSemanales?.Count > 0)
            return Ordenar(HorariosSemanales.FirstOrDefault(h => h != null && h.Dia == dia)?.Tramos);
        return DiasLaborables?.Contains(dia) == true ? JornadaPredeterminada() : Array.Empty<MYGTramoHorario>();
    }

    private static IReadOnlyList<MYGTramoHorario> Ordenar(List<MYGTramoHorario> tramos) =>
        tramos == null ? Array.Empty<MYGTramoHorario>() : tramos.OrderBy(t => t.InicioMinuto).ToArray();

    private IReadOnlyList<MYGTramoHorario> JornadaPredeterminada()
    {
        int minutos = Math.Clamp((int)Math.Round(HorasPorDia * 60, MidpointRounding.AwayFromZero), 1, 1440);
        // Horario habitual de obra, con refrigerio, para las jornadas heredadas.
        if (minutos <= 240) return new[] { new MYGTramoHorario { InicioMinuto = 480, FinMinuto = 480 + minutos } };
        if (minutos <= 900) return new[] { new MYGTramoHorario { InicioMinuto = 480, FinMinuto = 720 },
            new MYGTramoHorario { InicioMinuto = 780, FinMinuto = 780 + minutos - 240 } };
        return new[] { new MYGTramoHorario { InicioMinuto = 0, FinMinuto = minutos } };
    }

    public void Validar()
    {
        if (string.IsNullOrWhiteSpace(Nombre)) throw new InvalidDataException("El calendario requiere un nombre.");
        if (HorasPorDia <= 0 || HorasPorDia > 24 || Feriados == null)
            throw new InvalidDataException("El calendario requiere una jornada mayor que cero y de hasta 24 horas y una lista de feriados.");
        if (HorariosSemanales?.Count > 0)
        {
            if (HorariosSemanales.Any(h => h == null || !Enum.IsDefined(h.Dia)) ||
                HorariosSemanales.Select(h => h.Dia).Distinct().Count() != HorariosSemanales.Count)
                throw new InvalidDataException("El horario semanal requiere días válidos y sin duplicados.");
            foreach (var horario in HorariosSemanales) ValidarTramos(horario.Tramos);
        }
        else if (DiasLaborables == null || DiasLaborables.Count == 0 ||
            DiasLaborables.Any(d => !Enum.IsDefined(d)) || DiasLaborables.Distinct().Count() != DiasLaborables.Count)
            throw new InvalidDataException("El calendario requiere días laborables válidos y sin duplicados.");
        if ((FeriadosAnuales ?? new()).Any(f => f == null || !FechaAnualValida(f.Mes, f.Dia)))
            throw new InvalidDataException("El calendario contiene un feriado anual no válido.");
        var excepciones = Excepciones ?? new();
        if (excepciones.Any(e => e == null || string.IsNullOrWhiteSpace(e.Id)) ||
            excepciones.Select(e => e.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != excepciones.Count)
            throw new InvalidDataException("Las excepciones requieren identificadores únicos.");
        foreach (var e in excepciones)
        {
            if (e.Anual ? !FechaAnualValida(e.Mes, e.Dia) :
                !e.Inicio.HasValue || !e.Fin.HasValue || e.Fin.Value.Date < e.Inicio.Value.Date)
                throw new InvalidDataException("La excepción «" + e.Nombre + "» contiene una fecha o intervalo no válido.");
            ValidarTramos(e.Tramos);
            if (!string.IsNullOrEmpty(e.Color) && ((e.Color.Length != 7 && e.Color.Length != 9) || e.Color[0] != '#' ||
                e.Color.Skip(1).Any(c => !Uri.IsHexDigit(c))))
                throw new InvalidDataException("El color de una excepción debe usar #RRGGBB o #AARRGGBB.");
        }
        if (excepciones.Where(e => e.Anual).GroupBy(e => (e.Mes, e.Dia)).Any(g => g.Count() > 1))
            throw new InvalidDataException("Dos excepciones anuales no pueden usar el mismo mes y día.");
        var periodos = excepciones.Where(e => !e.Anual).OrderBy(e => e.Inicio.Value.Date).ToArray();
        for (int i = 1; i < periodos.Length; i++)
            if (periodos[i].Inicio.Value.Date <= periodos[i - 1].Fin.Value.Date)
                throw new InvalidDataException("Las excepciones con fechas no pueden solaparse; edite o divida el intervalo existente.");
    }

    private static bool FechaAnualValida(int mes, int dia) => mes >= 1 && mes <= 12 &&
        dia >= 1 && dia <= DateTime.DaysInMonth(2000, mes);
    private static void ValidarTramos(List<MYGTramoHorario> tramos)
    {
        if (tramos == null) return;
        if (tramos.Any(t => t == null || t.InicioMinuto < 0 || t.FinMinuto > 1440 || t.InicioMinuto >= t.FinMinuto))
            throw new InvalidDataException("Cada tramo debe tener inicio anterior al fin, entre 00:00 y 24:00.");
        var ordenados = tramos.OrderBy(t => t.InicioMinuto).ToArray();
        for (int i = 1; i < ordenados.Length; i++)
            if (ordenados[i].InicioMinuto < ordenados[i - 1].FinMinuto)
                throw new InvalidDataException("Los tramos de una jornada no pueden solaparse.");
    }
    public DateTime SiguienteLaborable(DateTime fecha)
    { var c = new MYGCalendarioEntero(this); return c.Fecha(c.Primero(fecha)); }
    public DateTime SumarDiasLaborables(DateTime fecha, int dias)
    { var c = new MYGCalendarioEntero(this); return c.Fecha(c.Primero(fecha) + dias); }
    public int ContarDiasLaborables(DateTime inicio, DateTime fin)
    { var c = new MYGCalendarioEntero(this); return c.Contar(inicio, fin); }
}

// Ordinal absoluto de día laborable, independiente del inicio del proyecto.
// Conteo por semanas + intervalos y ajustes puntuales indexados. Los intervalos
// extensos y los desfases enormes no recorren el calendario día por día.
internal sealed class MYGCalendarioEntero
{
    private const int UltimoDia = 3652058;
    private readonly HashSet<DayOfWeek> semana;
    private readonly int[] puntos;
    private readonly int[] acumuladosPuntos;
    private readonly Periodo[] periodos;
    private readonly int total;
    internal MYGCalendarioEntero(MYGCalendarioTrabajo calendario)
    {
        if (calendario == null) throw new InvalidDataException("El cronograma requiere un calendario.");
        calendario.Validar();
        semana = Enum.GetValues<DayOfWeek>().Where(d => calendario.HorarioSemanal(d).Count > 0).ToHashSet();
        periodos = (calendario.Excepciones ?? new()).Where(e => !e.Anual).OrderBy(e => e.Inicio.Value.Date)
            .Select(e => new Periodo { Inicio = Dia(e.Inicio.Value), Fin = Dia(e.Fin.Value), Laborable = e.Laborable }).ToArray();
        int acumulado = 0;
        foreach (var p in periodos)
        {
            p.AcumuladoAnterior = acumulado;
            acumulado += DeltaPeriodo(p, p.Fin);
        }
        var fechas = calendario.Feriados.Select(Dia).Distinct().ToDictionary(d => d, _ => false);
        foreach (var f in calendario.FeriadosAnuales ?? new()) AgregarAnual(f.Mes, f.Dia, false);
        foreach (var e in (calendario.Excepciones ?? new()).Where(e => e.Anual)) AgregarAnual(e.Mes, e.Dia, e.Laborable);
        var ajustes = fechas.Where(f => !EnPeriodo(f.Key)).Select(f => new { Dia = f.Key,
            Delta = (f.Value ? 1 : 0) - (semana.Contains((DayOfWeek)((f.Key + 1) % 7)) ? 1 : 0) })
            .Where(f => f.Delta != 0).OrderBy(f => f.Dia).ToArray();
        puntos = ajustes.Select(f => f.Dia).ToArray();
        acumuladosPuntos = new int[ajustes.Length + 1];
        for (int i = 0; i < ajustes.Length; i++) acumuladosPuntos[i + 1] = acumuladosPuntos[i] + ajustes[i].Delta;
        total = Hasta(UltimoDia);
        if (total == 0) throw new InvalidDataException("El calendario no contiene ningún día laborable disponible.");

        void AgregarAnual(int mes, int dia, bool laborable)
        {
            for (int anio = 1; anio <= 9999; anio++)
                if (dia <= DateTime.DaysInMonth(anio, mes)) fechas[Dia(new DateTime(anio, mes, dia))] = laborable;
        }
    }
    private static int Dia(DateTime fecha) => (int)(fecha.Date.Ticks / TimeSpan.TicksPerDay);
    private int SemanalHasta(int dia)
    {
        if (dia < 0) return 0;
        int dias = dia + 1, cantidad = dias / 7 * semana.Count;
        for (int n = 0; n < dias % 7; n++)
            if (semana.Contains((DayOfWeek)((n + 1) % 7))) cantidad++;
        return cantidad;
    }
    private int Hasta(int dia)
    {
        if (dia < 0) return 0;
        int inferior = 0, superior = puntos.Length;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (puntos[medio] <= dia) inferior = medio + 1; else superior = medio; }
        int cantidad = SemanalHasta(dia) + acumuladosPuntos[inferior];
        int indice = IndicePeriodo(dia);
        if (indice >= 0) cantidad += periodos[indice].AcumuladoAnterior + DeltaPeriodo(periodos[indice], dia);
        return cantidad;
    }
    private int DeltaPeriodo(Periodo p, int hasta) => (p.Laborable ? Math.Min(hasta, p.Fin) - p.Inicio + 1 : 0) -
        (SemanalHasta(Math.Min(hasta, p.Fin)) - SemanalHasta(p.Inicio - 1));
    private bool EnPeriodo(int dia)
    { int indice = IndicePeriodo(dia); return indice >= 0 && dia <= periodos[indice].Fin; }
    private int IndicePeriodo(int dia)
    {
        int inferior = 0, superior = periodos.Length;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (periodos[medio].Inicio <= dia) inferior = medio + 1; else superior = medio; }
        return inferior - 1;
    }
    private sealed class Periodo
    {
        internal int Inicio, Fin, AcumuladoAnterior;
        internal bool Laborable;
    }
    internal long Primero(DateTime fecha) => Hasta(Dia(fecha) - 1) + 1L;
    internal long Despues(DateTime fecha) => Hasta(Dia(fecha)) + 1L;
    internal long AnteriorOIgual(DateTime fecha) => Hasta(Dia(fecha));
    internal int Contar(DateTime inicio, DateTime fin) => fin.Date < inicio.Date ? 0 : Hasta(Dia(fin)) - Hasta(Dia(inicio) - 1);
    internal DateTime Fecha(long ordinal)
    {
        if (ordinal < 1 || ordinal > total)
            throw new InvalidDataException("Las fechas del cronograma exceden el rango permitido. Revise duraciones y desfases.");
        int inferior = 0, superior = UltimoDia;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (Hasta(medio) < ordinal) inferior = medio + 1; else superior = medio; }
        return new DateTime((long)inferior * TimeSpan.TicksPerDay);
    }
}
