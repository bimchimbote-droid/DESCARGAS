using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using MYG_2027;

internal static class TiempoTrabajoCronogramaUICheck
{
    private const string Prefijo = "cronograma_tiempo_";

    internal static void Ejecutar(Action<bool, string> exige)
    {
        var plan = new MYGCronograma { FechaInicio = new DateTime(2026, 1, 5), FechaEstado = new DateTime(2026, 1, 5) };
        plan.Tareas.Add(new MYGTareaCronograma { Nombre = "Trabajo de prueba", DuracionDias = 2 });
        var calendarioOriginal = plan.Calendario;
        string calendarioAntes = JsonSerializer.Serialize(calendarioOriginal);
        int aplicaciones = 0;
        bool autorizado = true, copiaIndependiente = true;
        MYGTiempoTrabajoCronogramaControl control = null;
        control = new MYGTiempoTrabajoCronogramaControl(() => plan, nuevo =>
        {
            copiaIndependiente &= !ReferenceEquals(nuevo, plan) && !ReferenceEquals(nuevo.Calendario, plan.Calendario) &&
                nuevo.Tareas.All(t => plan.Tareas.All(a => !ReferenceEquals(a, t)));
            plan = nuevo;
            aplicaciones++;
            // El editor anfitrión refresca sus vistas desde el callback de historial.
            control.Refrescar();
        }, () => autorizado);
        using (control)
        using (var ventana = new Form { ClientSize = new Size(1800, 410) })
        {
            ventana.Controls.Add(control); ventana.Show(); Application.DoEvents();
            var horario = Campo<DataGridView>(control, "horario");
            var dias = Campo<CheckedListBox>(control, "dias");
            var excepciones = Campo<DataGridView>(control, "excepciones");
            var nombres = Campo<ComboBox>(control, "calendarios");
            exige(control.Name == "cronograma_tiempo_trabajo" && !control.TieneCambios && aplicaciones == 0 &&
                dias.Items.Count == 7 && Campo<Control>(control, "meses").Visible && horario.Rows.Count == 2 &&
                Convert.ToString(horario.Rows[0].Cells["INICIO"].Value) == "08:00" &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "12:00" &&
                Convert.ToString(horario.Rows[1].Cells["INICIO"].Value) == "13:00" &&
                Convert.ToString(horario.Rows[1].Cells["FIN"].Value) == "17:00",
                "Tiempo de trabajo debe abrir los siete días y la jornada heredada de ocho horas con refrigerio sin modificar el proyecto.");

            horario.CurrentCell = horario.Rows[0].Cells["FIN"];
            horario.BeginEdit(true);
            ((TextBox)horario.EditingControl).Text = "10:30";
            dias.SelectedIndex = (int)DayOfWeek.Tuesday;
            dias.SelectedIndex = (int)DayOfWeek.Monday;
            exige(Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "10:30" &&
                control.TieneCambios && aplicaciones == 0 && JsonSerializer.Serialize(calendarioOriginal) == calendarioAntes,
                "Cambiar de día con texto horario aún sin confirmar debe incorporarlo al borrador antes de cambiar las filas.");
            horario.Rows[0].Cells["FIN"].Value = "11:00";
            control.FinalizarEdicion(); control.Refrescar();
            exige(control.TieneCambios && aplicaciones == 0 && JsonSerializer.Serialize(calendarioOriginal) == calendarioAntes &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "11:00",
                "Editar y refrescar la jornada debe conservar el borrador sin tocar el calendario original ni el historial.");
            plan.Tareas[0].Nombre = "Tarea editada mientras se consulta el calendario";
            control.GuardarCambios();
            exige(aplicaciones == 1 && copiaIndependiente && !control.TieneCambios &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 5)) == 7 &&
                plan.Tareas[0].Nombre == "Tarea editada mientras se consulta el calendario" &&
                plan.Calendarios.Single(c => c.Nombre == plan.Calendario.Nombre).HorasDelDia(new DateTime(2026, 1, 5)) == 7 &&
                JsonSerializer.Serialize(calendarioOriginal) == calendarioAntes,
                "Guardar debe aplicar una sola copia, sincronizar el calendario activo y conservar las ediciones recientes de tareas.");
            control.GuardarCambios();
            exige(aplicaciones == 1, "Guardar el calendario sin cambios debe conservar el historial.");

            string antesInvalido = Huella(plan);
            horario.CurrentCell = horario.Rows[0].Cells["FIN"];
            horario.BeginEdit(true);
            ((TextBox)horario.EditingControl).Text = "14:00";
            dias.SelectedIndex = (int)DayOfWeek.Tuesday;
            exige(dias.SelectedIndex == (int)DayOfWeek.Monday &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "14:00" && control.TieneCambios &&
                Huella(plan) == antesInvalido && aplicaciones == 1,
                "Un texto horario inválido debe impedir navegar a otro día y conservarse para corregirlo sin modificar el plan.");
            bool rechazado = false;
            try { control.GuardarCambios(); } catch (Exception) { rechazado = true; }
            exige(rechazado && aplicaciones == 1 && Huella(plan) == antesInvalido && control.TieneCambios,
                "Un horario que solapa el turno de tarde debe rechazarse de forma atómica y conservarse para corregirlo.");
            horario.Rows[0].Cells["FIN"].Value = "12:00";
            control.GuardarCambios();
            exige(aplicaciones == 2 && plan.Calendario.HorasDelDia(new DateTime(2026, 1, 5)) == 8,
                "Corregir el horario debe permitir guardarlo sin repetir una transacción rechazada.");

            string antesCerrar = Huella(plan);
            horario.CurrentCell = horario.Rows[0].Cells["FIN"];
            horario.BeginEdit(true);
            ((TextBox)horario.EditingControl).Text = "10:30";
            exige(control.TieneCambios, "El texto horario aún sin confirmar debe contarse como edición pendiente al cerrar el panel.");
            bool cerrarCancelado = ResponderCierre(control, 2);
            exige(!cerrarCancelado && control.TieneCambios && Huella(plan) == antesCerrar && aplicaciones == 2,
                "Cancelar el cierre debe mantener el panel, su texto pendiente y el proyecto sin modificaciones.");
            bool descartar = ResponderCierre(control, 7);
            exige(descartar && !control.TieneCambios && Huella(plan) == antesCerrar && aplicaciones == 2 &&
                Convert.ToString(horario.Rows[0].Cells["FIN"].Value) == "12:00",
                "Descartar al cerrar debe recuperar el calendario guardado sin crear historial.");

            Boton(control, "excepcion_agregar").PerformClick();
            Campo<TextBox>(control, "excepcion_nombre").Text = "Día del trabajo reducido";
            Campo<ComboBox>(control, "excepcion_tipo").SelectedIndex = 0;
            Campo<ComboBox>(control, "excepcion_mes").SelectedIndex = 4;
            Campo<NumericUpDown>(control, "excepcion_dia").Value = 1;
            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 1;
            Campo<RadioButton>(control, "excepcion_laborable").Checked = true;
            Boton(control, "excepcion_horario_agregar").PerformClick();
            Boton(control, "excepcion_horario_agregar").PerformClick();
            var horarioEspecial = Campo<DataGridView>(control, "excepcion_horario");
            exige(horarioEspecial.Rows.Count == 2 && excepciones.Rows.Count == 1 && aplicaciones == 2,
                "Una excepción laborable debe admitir varios turnos sin aplicar cambios antes de guardar.");
            horarioEspecial.Rows[0].Cells["FIN"].Value = "10:00";
            horarioEspecial.Rows[1].Cells["FIN"].Value = "15:00";
            control.GuardarCambios();
            exige(aplicaciones == 3 && plan.Calendario.HorasDelDia(new DateTime(2026, 5, 1)) == 4 &&
                plan.Calendario.HorasDelDia(new DateTime(2027, 5, 1)) == 4 &&
                plan.Calendario.Excepciones.Single().Nombre == "Día del trabajo reducido" &&
                plan.Calendario.Excepciones.Single().Anual,
                "Guardar una excepción anual debe repetir día y mes y aplicar sus turnos tanto en días habituales como en sábados.");

            Boton(control, "excepcion_agregar").PerformClick();
            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 0;
            Campo<TextBox>(control, "excepcion_nombre").Text = "Cierre de obra";
            Campo<DateTimePicker>(control, "excepcion_desde").Value = new DateTime(2026, 5, 1);
            Campo<DateTimePicker>(control, "excepcion_hasta").Value = new DateTime(2026, 5, 2);
            control.GuardarCambios();
            exige(aplicaciones == 4 && !plan.Calendario.EsLaborable(new DateTime(2026, 5, 1)) &&
                !plan.Calendario.EsLaborable(new DateTime(2026, 5, 2)) && plan.Calendario.HorasDelDia(new DateTime(2027, 5, 1)) == 4,
                "La excepción fechada debe cubrir ambos extremos y prevalecer sobre la excepción anual sin cambiar otros años.");

            Campo<TabControl>(control, "excepcion_pestanas").SelectedIndex = 1;
            Campo<RadioButton>(control, "excepcion_laborable").Checked = true;
            Boton(control, "excepcion_horario_agregar").PerformClick();
            horarioEspecial.CurrentCell = horarioEspecial.Rows[0].Cells["FIN"];
            horarioEspecial.BeginEdit(true);
            ((TextBox)horarioEspecial.EditingControl).Text = "09:15";
            excepciones.CurrentCell = excepciones.Rows[0].Cells[0];
            excepciones.CurrentCell = excepciones.Rows[1].Cells[0];
            exige(Convert.ToString(horarioEspecial.Rows[0].Cells["FIN"].Value) == "09:15" && aplicaciones == 4 &&
                !plan.Calendario.Excepciones.Single(e => e.Nombre == "Cierre de obra").Laborable,
                "Cambiar la excepción seleccionada debe confirmar su celda pendiente en el borrador sin aplicar el calendario.");
            horarioEspecial.CurrentCell = horarioEspecial.Rows[0].Cells["FIN"];
            horarioEspecial.BeginEdit(true);
            ((TextBox)horarioEspecial.EditingControl).Text = "07:00";
            excepciones.CurrentCell = excepciones.Rows[0].Cells[0];
            Application.DoEvents();
            exige(excepciones.CurrentRow?.Index == 1 &&
                Convert.ToString(horarioEspecial.Rows[0].Cells["FIN"].Value) == "07:00" && aplicaciones == 4,
                "Un horario inválido de excepción debe impedir abandonar su fila sin perder el texto que se debe corregir.");
            Boton(control, "excepcion_eliminar").PerformClick();
            control.GuardarCambios();
            exige(aplicaciones == 5 && plan.Calendario.Excepciones.Count == 1 &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 5, 1)) == 4,
                "Eliminar un intervalo debe recuperar la jornada anual mediante una sola transacción.");

            AceptarNombre(control, "calendario_agregar", "Turno de verano", exige);
            exige(nombres.Items.Count == 2 && plan.Calendarios.Count == 1 && control.TieneCambios,
                "Crear un calendario debe conservarlo en el borrador hasta guardar y mantener el calendario activo vigente.");
            AceptarNombre(control, "calendario_renombrar", "Turno reducido", exige);
            Boton(control, "calendario_activar").PerformClick();
            dias.SelectedIndex = (int)DayOfWeek.Monday;
            horario.Rows[0].Cells["FIN"].Value = "10:00";
            control.GuardarCambios();
            exige(aplicaciones == 6 && plan.Calendario.Nombre == "Turno reducido" && plan.Calendarios.Count == 2 &&
                plan.Calendario.HorasDelDia(new DateTime(2026, 1, 5)) == 6 &&
                plan.Calendarios.Single(c => c.Nombre == "Predeterminado").HorasDelDia(new DateTime(2026, 1, 5)) == 8,
                "Activar y editar una copia nombrada debe conservar el horario del calendario de origen.");
            string antesConsulta = Huella(plan);
            nombres.SelectedIndex = nombres.Items.IndexOf("Predeterminado");
            exige(!control.TieneCambios && Huella(plan) == antesConsulta && aplicaciones == 6,
                "Cambiar el calendario mostrado para consultarlo debe conservar el calendario activo y el historial.");
            Boton(control, "calendario_eliminar").PerformClick(); control.GuardarCambios();
            exige(aplicaciones == 7 && plan.Calendarios.Count == 1 && plan.Calendario.Nombre == "Turno reducido",
                "Eliminar un calendario secundario debe conservar y sincronizar el calendario activo.");

            autorizado = false; control.Refrescar();
            string sinPermiso = Huella(plan);
            bool lunesAntes = dias.GetItemChecked((int)DayOfWeek.Monday);
            dias.SetItemChecked((int)DayOfWeek.Monday, !lunesAntes);
            Boton(control, "excepcion_agregar").PerformClick();
            Boton(control, "hoy").PerformClick();
            exige(horario.ReadOnly && dias.Enabled && dias.GetItemChecked((int)DayOfWeek.Monday) == lunesAntes &&
                !Boton(control, "guardar").Enabled && Huella(plan) == sinPermiso && aplicaciones == 7 && !control.TieneCambios,
                "Sin permiso de edición debe poder consultarse el calendario y navegar por sus días sin cambiar datos.");
        }
    }

    private static void AceptarNombre(Control control, string comando, string nombre, Action<bool, string> exige)
    {
        bool atendido = false;
        Exception fallo = null;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
        temporizador.Tick += (_, _) =>
        {
            var dialogo = Application.OpenForms.Cast<Form>().FirstOrDefault(f => f.Name == Prefijo + "nombre_dialogo");
            if (dialogo == null) return;
            temporizador.Stop();
            try
            {
                Campo<TextBox>(dialogo, "nombre_calendario").Text = nombre;
                Campo<Button>(dialogo, "nombre_aceptar").PerformClick();
                atendido = dialogo.DialogResult == DialogResult.OK;
                if (!atendido) dialogo.Close();
            }
            catch (Exception ex) { fallo = ex; dialogo.Close(); }
        };
        temporizador.Start(); Boton(control, comando).PerformClick(); temporizador.Stop();
        if (fallo != null) throw new InvalidOperationException("No se pudo completar el diálogo de calendario.", fallo);
        exige(atendido, "Agregar y renombrar calendarios debe usar el diálogo real de nombre y aceptar un nombre único.");
    }

    private static bool ResponderCierre(MYGTiempoTrabajoCronogramaControl control, int respuesta)
    {
        bool atendido = false;
        using var temporizador = new System.Windows.Forms.Timer { Interval = 30 };
        temporizador.Tick += (_, _) =>
        {
            IntPtr dialogo = FindWindow("#32770", "Tiempo de trabajo");
            if (dialogo == IntPtr.Zero) return;
            temporizador.Stop(); atendido = true;
            SendMessage(dialogo, 0x0111, new IntPtr(respuesta), IntPtr.Zero);
        };
        temporizador.Start(); bool resultado = control.ConfirmarCierre(); temporizador.Stop();
        if (!atendido) throw new InvalidOperationException("El cierre con cambios debe preguntar guardar, descartar o cancelar.");
        return resultado;
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "FindWindowW")]
    private static extern IntPtr FindWindow(string clase, string titulo);
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr SendMessage(IntPtr ventana, uint mensaje, IntPtr wParam, IntPtr lParam);

    private static string Huella(MYGCronograma plan) => JsonSerializer.Serialize(plan);
    private static Button Boton(Control raiz, string nombre) => Campo<Button>(raiz, nombre);
    private static T Campo<T>(Control raiz, string nombre) where T : Control =>
        Controles(raiz).OfType<T>().Single(c => c.Name == Prefijo + nombre);
    private static IEnumerable<Control> Controles(Control raiz)
    {
        yield return raiz;
        foreach (Control hijo in raiz.Controls)
            foreach (var descendiente in Controles(hijo)) yield return descendiente;
    }
}
