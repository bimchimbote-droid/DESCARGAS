using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

namespace MYG_2027;

internal static class MYGExportacionCronogramaWindows
{
    private const string AlternativaXml = "Puede exportar XML de Microsoft Project y abrirlo en una aplicación compatible.";

    // Es el archivo SQLite que MYG sabe volver a abrir. El cronograma completo se
    // conserva en myg_proyecto.json_documento mediante el almacenamiento existente.
    // Esto no convierte el archivo en un contenedor propietario .DelphinExpress,
    // ni sincroniza el CPM con programacion_costo/dependencia_tarea de Delphin.
    internal static void GuardarNativo(string ruta, MYGProyectoDocumento proyecto, MYGCronograma plan,
        string origenSQLite = null)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(plan);
        string destino = RutaConExtension(ruta, ".sqlite", "El archivo nativo de MYG debe tener extensión .sqlite.");
        string origen = string.IsNullOrWhiteSpace(origenSQLite) ? null : Path.GetFullPath(origenSQLite);
        if (origen != null && MismaRuta(destino, origen))
            throw new InvalidOperationException("Elija un archivo nuevo: exportar no debe reemplazar la hoja de trabajo abierta.");
        if (origen != null && !File.Exists(origen))
            throw new FileNotFoundException("No existe la hoja SQLite de origen que se desea conservar.", origen);

        // Validar una copia evita que el guardado normalice o selle el documento
        // del editor, y permite exportar un cronograma aún no guardado en él.
        var copia = MYGProyectoStorage.Copia(proyecto);
        copia.Cronograma = MYGProyectoStorage.Copia(plan);
        MYGProyectoStorage.Validar(copia);
        MYGMotorCronograma.Validar(copia.Cronograma);
        ComprobarDestinoLibre(destino, sqlite: true);
        Directory.CreateDirectory(Path.GetDirectoryName(destino));
        string temporal = TemporalJuntoA(destino, ".sqlite");
        try
        {
            MYGBaseDatos.GuardarProyecto(temporal, copia, origen);
            // Volver a leer comprueba que el almacenamiento soportado acepta el
            // documento exportado antes de reemplazar un archivo del usuario.
            var reabierto = MYGBaseDatos.LeerProyecto(temporal, copia.Id);
            if (reabierto.Cronograma == null)
                throw new InvalidDataException("El archivo nativo no conservó el cronograma; no se reemplazó el destino.");
            Publicar(temporal, destino, sqlite: true);
        }
        finally { LimpiarTemporal(temporal, sqlite: true); }
    }

    internal static void GuardarProject(string ruta, MYGProyectoDocumento proyecto, MYGCronograma plan,
        bool incluirRecursos)
    {
        ArgumentNullException.ThrowIfNull(proyecto);
        ArgumentNullException.ThrowIfNull(plan);
        string destino = RutaConExtension(ruta, ".mpp", "El archivo de Microsoft Project debe tener extensión .mpp.");
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("La exportación MPP requiere Microsoft Project instalado en Windows. " + AlternativaXml);
        Type tipo = Type.GetTypeFromProgID("MSProject.Application", throwOnError: false);
        if (tipo == null)
            throw new InvalidOperationException("Microsoft Project de escritorio no está instalado o no tiene su automatización registrada. " + AlternativaXml);
        if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
            throw new InvalidOperationException("La exportación MPP debe ejecutarse desde el hilo de la interfaz de Windows. " + AlternativaXml);
        ComprobarDestinoLibre(destino, sqlite: false);
        // No se toma una sesión existente: Project puede compartir instancia.
        // Pedir otra ruta/formato es preferible a modificar o cerrar su sesión.
        if (ProcesosProject().Length != 0)
            throw new InvalidOperationException("Microsoft Project está abierto. Cierre sus ventanas antes de exportar MPP. " + AlternativaXml);

        Directory.CreateDirectory(Path.GetDirectoryName(destino));
        string xml = TemporalJuntoA(destino, ".xml");
        string mpp = TemporalJuntoA(destino, ".mpp");
        object aplicacion = null, proyectoImportado = null;
        bool instanciaPropia = false;
        try
        {
            // XML estándar primero; nunca se cambia la extensión de un XML para
            // aparentar que es un archivo binario de Microsoft Project.
            MYGExportacionCronograma.Guardar(xml, proyecto, plan, incluirRecursos
                ? MYGFormatoExportacionCronograma.XmlTareasRecursos : MYGFormatoExportacionCronograma.XmlTareas);
            aplicacion = Activator.CreateInstance(tipo);
            if (aplicacion == null)
                throw new InvalidOperationException("Microsoft Project no creó una instancia de automatización.");
            // Una instancia privada debe estar oculta, sin documentos y ser el
            // único WINPROJ aparecido desde la comprobación previa. No se usa
            // GetActiveObject, no se mata ningún proceso y no se altera Visible.
            instanciaPropia = ProcesosProject().Length == 1 &&
                !Convert.ToBoolean(Propiedad(aplicacion, "Visible"), CultureInfo.InvariantCulture) &&
                ContarProyectos(aplicacion) == 0;
            if (!instanciaPropia)
                throw new InvalidOperationException("No se pudo aislar una instancia privada de Microsoft Project. No se modificó ni cerró ninguna sesión existente.");

            Establecer(aplicacion, "DisplayAlerts", false);
            // API oficial: FileOpenEx(Name, ReadOnly, Merge, ..., NoAuto,
            // FormatID, ..., DoNotLoadFromEnterprise); pjDoNotMerge = 0.
            // https://learn.microsoft.com/office/vba/api/project.application.fileopenex
            ExigirExito(Invocar(aplicacion, "FileOpenEx",
                new[] { "Name", "ReadOnly", "Merge", "NoAuto", "FormatID", "DoNotLoadFromEnterprise" },
                xml, false, 0, true, "MSProject.xml", true), "Microsoft Project no pudo abrir el XML del cronograma.");
            proyectoImportado = Propiedad(aplicacion, "ActiveProject");
            if (proyectoImportado == null || ContarProyectos(aplicacion) != 1)
                throw new InvalidOperationException("Microsoft Project no abrió el cronograma como un proyecto independiente.");

            // Los nombres evitan depender de posiciones de parámetros opcionales.
            // pjMPP = 0 y FormatID = "MSProject.mpp", según la API de Project.
            // https://learn.microsoft.com/office/vba/api/project.application.filesaveas
            // https://learn.microsoft.com/office/vba/api/project.pjfileformat
            ExigirExito(Invocar(aplicacion, "FileSaveAs",
                new[] { "Name", "Format", "FormatID", "Backup", "ReadOnly" },
                mpp, 0, "MSProject.mpp", false, false), "Microsoft Project no pudo guardar el archivo MPP.");
            CerrarProyectoPropio(aplicacion, proyectoImportado);
            VerificarContenedorMpp(mpp);
            Publicar(mpp, destino, sqlite: false);
        }
        catch (Exception ex) when (ex is COMException || ex is TargetInvocationException)
        {
            Exception causa = ex is TargetInvocationException { InnerException: not null } invocacion
                ? invocacion.InnerException : ex;
            throw new InvalidOperationException("Microsoft Project no completó la exportación MPP: " + causa.Message + " " + AlternativaXml, causa);
        }
        finally
        {
            if (aplicacion != null && instanciaPropia)
            {
                // FileCloseEx sólo se invoca si el proyecto activo sigue siendo
                // exactamente el objeto importado. Quit sólo si no queda ninguno.
                try { CerrarProyectoPropio(aplicacion, proyectoImportado); } catch { }
                try
                {
                    if (ContarProyectos(aplicacion) == 0)
                        Invocar(aplicacion, "Quit", new[] { "SaveChanges" }, 0); // pjDoNotSave
                }
                catch { }
            }
            Liberar(proyectoImportado);
            Liberar(aplicacion);
            LimpiarTemporal(xml, sqlite: false);
            LimpiarTemporal(mpp, sqlite: false);
        }
    }

    internal static void ValidarDestino(string ruta, string extension, string origenSQLite = null)
    {
        if (string.IsNullOrWhiteSpace(extension) || extension.Any(c => !char.IsAsciiLetterOrDigit(c)))
            throw new ArgumentException("Indique una extensión de archivo válida.", nameof(extension));
        string destino = RutaConExtension(ruta, "." + extension, "El destino debe tener extensión ." + extension + ".");
        if (!string.IsNullOrWhiteSpace(origenSQLite) && MismaRuta(destino, Path.GetFullPath(origenSQLite)))
            throw new InvalidOperationException("Exportar no puede reemplazar la hoja de trabajo abierta. Elija otro archivo.");
    }

    private static string RutaConExtension(string ruta, string extension, string mensaje)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("Indique una ruta de destino.", nameof(ruta));
        if (!string.Equals(Path.GetExtension(ruta), extension, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException(mensaje, nameof(ruta));
        return Path.GetFullPath(ruta);
    }

    private static bool MismaRuta(string a, string b) => string.Equals(a, b,
        OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);

    private static string TemporalJuntoA(string destino, string extension) =>
        Path.Combine(Path.GetDirectoryName(destino), ".myg-cronograma-" + Guid.NewGuid().ToString("N") + extension);

    private static void ComprobarDestinoLibre(string destino, bool sqlite)
    {
        if (Directory.Exists(destino)) throw new IOException("El destino elegido es una carpeta.");
        if (sqlite && new[] { "-wal", "-shm", "-journal" }.Any(s => File.Exists(destino + s)))
            throw new IOException("La base de destino conserva una sesión o transacción SQLite. Cierre esa hoja o elija un archivo nuevo.");
        if (!File.Exists(destino)) return;
        try
        {
            using var archivo = new FileStream(destino, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        }
        catch (IOException ex)
        { throw new IOException("El archivo de destino está abierto o bloqueado. Ciérrelo o elija otro nombre.", ex); }
    }

    private static void Publicar(string temporal, string destino, bool sqlite)
    {
        ComprobarDestinoLibre(destino, sqlite);
        if (File.Exists(destino)) File.Replace(temporal, destino, null);
        else File.Move(temporal, destino);
    }

    private static void LimpiarTemporal(string ruta, bool sqlite)
    {
        foreach (string sufijo in sqlite ? new[] { "", "-wal", "-shm", "-journal" } : new[] { "" })
        {
            try { if (File.Exists(ruta + sufijo)) File.Delete(ruta + sufijo); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private static int[] ProcesosProject()
    {
        var procesos = Process.GetProcessesByName("WINPROJ");
        try { return procesos.Select(p => p.Id).ToArray(); }
        finally { foreach (var p in procesos) p.Dispose(); }
    }

    private static object Propiedad(object objeto, string nombre) => objeto.GetType().InvokeMember(nombre,
        BindingFlags.GetProperty | BindingFlags.Instance | BindingFlags.Public, null, objeto, null,
        CultureInfo.InvariantCulture);

    private static void Establecer(object objeto, string nombre, object valor) => objeto.GetType().InvokeMember(nombre,
        BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.Public, null, objeto, new[] { valor },
        CultureInfo.InvariantCulture);

    private static object Invocar(object objeto, string nombre, string[] nombres, params object[] valores) =>
        objeto.GetType().InvokeMember(nombre, BindingFlags.InvokeMethod | BindingFlags.Instance | BindingFlags.Public,
            null, objeto, valores, null, CultureInfo.InvariantCulture, nombres);

    private static int ContarProyectos(object aplicacion)
    {
        object proyectos = null;
        try
        {
            proyectos = Propiedad(aplicacion, "Projects");
            return Convert.ToInt32(Propiedad(proyectos, "Count"), CultureInfo.InvariantCulture);
        }
        finally { Liberar(proyectos); }
    }

    private static void ExigirExito(object resultado, string mensaje)
    {
        if (resultado is not bool correcto || !correcto) throw new InvalidOperationException(mensaje);
    }

    private static void CerrarProyectoPropio(object aplicacion, object proyectoImportado)
    {
        if (proyectoImportado == null || ContarProyectos(aplicacion) == 0) return;
        object activo = null;
        IntPtr identidadImportado = IntPtr.Zero, identidadActivo = IntPtr.Zero;
        try
        {
            activo = Propiedad(aplicacion, "ActiveProject");
            if (activo == null) return;
            identidadImportado = Marshal.GetIUnknownForObject(proyectoImportado);
            identidadActivo = Marshal.GetIUnknownForObject(activo);
            if (identidadImportado == identidadActivo)
                ExigirExito(Invocar(aplicacion, "FileCloseEx", new[] { "Save", "NoAuto" }, 0, true),
                    "Microsoft Project no pudo cerrar el cronograma exportado.");
        }
        finally
        {
            if (identidadImportado != IntPtr.Zero) Marshal.Release(identidadImportado);
            if (identidadActivo != IntPtr.Zero) Marshal.Release(identidadActivo);
            Liberar(activo);
        }
    }

    private static void Liberar(object objeto)
    {
        if (objeto == null || !Marshal.IsComObject(objeto)) return;
        try { Marshal.ReleaseComObject(objeto); } catch (InvalidComObjectException) { }
    }

    private static void VerificarContenedorMpp(string ruta)
    {
        // Los MPP modernos producidos por FileSaveAs son documentos compuestos
        // OLE. Esta comprobación impide publicar XML/texto con extensión .mpp.
        byte[] firma = { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 };
        using var archivo = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.Read);
        Span<byte> cabecera = stackalloc byte[8];
        if (archivo.Length <= 8 || archivo.Read(cabecera) != 8 || !cabecera.SequenceEqual(firma))
            throw new InvalidDataException("Microsoft Project no produjo un contenedor MPP binario válido; no se reemplazó el destino.");
    }
}
