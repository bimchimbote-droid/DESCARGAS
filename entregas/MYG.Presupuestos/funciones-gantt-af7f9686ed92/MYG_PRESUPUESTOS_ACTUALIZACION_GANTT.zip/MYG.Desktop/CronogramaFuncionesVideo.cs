using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelCronograma
{
    private MYGTiempoTrabajoCronogramaControl tiempoTrabajo;
    private Button botonTiempoTrabajo;
    private MYGModoRutaCritica modoRutaCritica = MYGModoRutaCritica.Ninguna;

    private void InicializarFuncionesVideo()
    {
        tiempoTrabajo = new MYGTiempoTrabajoCronogramaControl(obtener, plan => AplicarCopia(plan), () => Editable)
        { Dock = DockStyle.Bottom, Visible = false, Height = 380 };
        Controls.Add(tiempoTrabajo);
        // Estado queda debajo del editor; tabla y Gantt comparten el espacio superior.
        Controls.SetChildIndex(tiempoTrabajo, 1);
        SizeChanged += (_, _) => DimensionarTiempoTrabajo();
        DpiChangedAfterParent += (_, _) => DimensionarTiempoTrabajo();
    }

    private void DimensionarTiempoTrabajo()
    {
        if (!tiempoTrabajo.Visible) return;
        int preferido = (int)Math.Round(380 * DeviceDpi / 96F);
        tiempoTrabajo.Height = Math.Min(preferido, Math.Max(120, ClientSize.Height - 180));
    }

    private void AlternarTiempoTrabajo()
    {
        if (tiempoTrabajo.Visible)
        {
            if (!tiempoTrabajo.ConfirmarCierre()) return;
            tiempoTrabajo.Visible = false;
        }
        else
        {
            FinalizarEdicion(); tiempoTrabajo.Refrescar(); tiempoTrabajo.Visible = true;
            DimensionarTiempoTrabajo();
        }
        AplicarTema();
    }

    internal bool ConfirmarSalidaTiempoTrabajo() => !tiempoTrabajo.Visible || tiempoTrabajo.ConfirmarCierre();
    internal void GuardarTiempoTrabajoPendiente()
    {
        if (tiempoTrabajo.Visible)
        {
            tiempoTrabajo.FinalizarEdicion();
            if (tiempoTrabajo.TieneCambios) tiempoTrabajo.GuardarCambios();
        }
    }

    private void PrepararMenuRutaCritica()
    {
        var menu = Menu();
        void Agregar(string texto, string id, MYGModoRutaCritica modo)
        {
            Opcion(menu, texto, id, () => SeleccionarRutaCritica(modoRutaCritica == modo ? MYGModoRutaCritica.Ninguna : modo));
            var item = (ToolStripMenuItem)menu.Items[^1];
            item.ToolTipText = modo == MYGModoRutaCritica.Simple
                ? "Ruta al fin de todo el proyecto. Seleccione otra vez para ocultarla."
                : "Ruta al fin de cada red independiente. Seleccione otra vez para ocultarlas.";
            menu.Opening += (_, _) => item.Checked = modoRutaCritica == modo;
        }
        Agregar("Simple", "cronograma_critica_simple", MYGModoRutaCritica.Simple);
        Agregar("Múltiple", "cronograma_critica_multiple", MYGModoRutaCritica.Multiple);
        AsociarMenu(botonCritica, menu);
    }

    internal void SeleccionarRutaCritica(MYGModoRutaCritica modo)
    {
        if (!Enum.IsDefined(modo)) throw new ArgumentOutOfRangeException(nameof(modo));
        FinalizarEdicion(); modoRutaCritica = modo;
        if (resultado == null) Refrescar(); else ActualizarRutaCritica(obtener());
        foreach (var item in botonCritica.ContextMenuStrip.Items.OfType<ToolStripMenuItem>())
            item.Checked = modo == MYGModoRutaCritica.Simple && item.Name == "cronograma_critica_simple" ||
                modo == MYGModoRutaCritica.Multiple && item.Name == "cronograma_critica_multiple";
        AplicarTema(); tabla.Invalidate(); ActualizarEstado();
    }

    private void ActualizarRutaCritica(MYGCronograma plan)
    {
        gantt.DefinirCriticas(MYGRutasCriticasCronograma.Calcular(plan, resultado, modoRutaCritica));
        gantt.MostrarCritica = modoRutaCritica != MYGModoRutaCritica.Ninguna;
    }

    private void FechasProyecto()
    {
        FinalizarEdicion(); RequerirEdicion();
        var plan = obtener();
        using var dialogo = new Form();
        MYGCronogramaDialogoUI.Preparar(dialogo, "cronograma_fechas_dialogo", "Fechas del proyecto", new Size(500, 235));
        var inicio = MYGCronogramaDialogoUI.Fecha("cronograma_fecha_inicio", plan.FechaInicio);
        var fechaEstado = MYGCronogramaDialogoUI.Fecha("cronograma_fecha_estado", plan.FechaEstado);
        var campos = MYGCronogramaDialogoUI.Tabla();
        MYGCronogramaDialogoUI.Campo(campos, "Inicio del proyecto", inicio);
        MYGCronogramaDialogoUI.Campo(campos, "Fecha de estado", fechaEstado);
        dialogo.Controls.Add(campos);
        var error = MYGCronogramaDialogoUI.Error("cronograma_fechas");
        MYGCronogramaDialogoUI.Botones(dialogo, "cronograma_fechas", error, () => { });
        MYGCronogramaDialogoUI.Tema(dialogo);
        if (dialogo.ShowDialog(this) == DialogResult.OK)
            AplicarCambio(copia => { copia.FechaInicio = inicio.Value.Date; copia.FechaEstado = fechaEstado.Value.Date; });
    }

    internal void ExportarDestino(MYGDestinoExportacionCronograma destino, string origenSQLite = null)
    {
        if (!Enum.IsDefined(destino)) throw new ArgumentOutOfRangeException(nameof(destino));
        if (!ConfirmarSalidaTiempoTrabajo()) return;
        FinalizarEdicion();
        var plan = obtener(); var proyecto = obtenerProyecto();
        if (destino == MYGDestinoExportacionCronograma.Pdf)
        {
            using var vista = new MYGVistaPreliminarReportesForm("Programación Gantt", MYGReportesCronograma.Crear(proyecto, plan, modoRutaCritica),
                validarDestino: (ruta, extension) => MYGExportacionCronogramaWindows.ValidarDestino(ruta, extension, origenSQLite ?? obtenerRuta?.Invoke()));
            vista.Shown += (_, _) => vista.BeginInvoke((Action)(() => vista.ExportarComo(MYGFormatoVistaReporte.Pdf)));
            vista.ShowDialog(this); return;
        }
        (string extension, string descripcion) = destino switch
        {
            MYGDestinoExportacionCronograma.Nativo => ("sqlite", "Proyecto nativo MYG"),
            MYGDestinoExportacionCronograma.ProjectTareas or MYGDestinoExportacionCronograma.ProjectRecursos => ("mpp", "Microsoft Project"),
            MYGDestinoExportacionCronograma.XmlTareas or MYGDestinoExportacionCronograma.XmlRecursos => ("xml", "XML Microsoft Project"),
            MYGDestinoExportacionCronograma.Xlsx => ("xlsx", "Libro Excel"),
            MYGDestinoExportacionCronograma.Texto => ("txt", "Texto de tareas"),
            MYGDestinoExportacionCronograma.Mht => ("mht", "Página web de archivo único"),
            _ => ("csv", "Lista estructurada de tareas")
        };
        using var dialogo = new SaveFileDialog
        {
            Title = "Exportar cronograma · " + descripcion, AddExtension = true, DefaultExt = extension,
            Filter = descripcion + " (*." + extension + ")|*." + extension, FileName = "Cronograma." + extension
        };
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        string archivo = dialogo.FileName;
        MYGExportacionCronogramaWindows.ValidarDestino(archivo, extension, origenSQLite ?? obtenerRuta?.Invoke());
        if (destino == MYGDestinoExportacionCronograma.Nativo)
        {
            // Un destino nuevo protege también otras pestañas con hojas abiertas.
            if (File.Exists(archivo)) throw new InvalidOperationException("Para exportar el proyecto elija un archivo SQLite nuevo.");
            MYGExportacionCronogramaWindows.GuardarNativo(archivo, proyecto, plan, origenSQLite);
        }
        else if (destino is MYGDestinoExportacionCronograma.ProjectTareas or MYGDestinoExportacionCronograma.ProjectRecursos)
            MYGExportacionCronogramaWindows.GuardarProject(archivo, proyecto, plan, destino == MYGDestinoExportacionCronograma.ProjectRecursos);
        else if (destino == MYGDestinoExportacionCronograma.Xlsx)
            MYGReportesCronograma.GuardarExcel(archivo, proyecto, plan, modoRutaCritica);
        else if (destino == MYGDestinoExportacionCronograma.Csv) MYGReportesCronograma.GuardarCsv(archivo, plan);
        else if (destino == MYGDestinoExportacionCronograma.Mht)
            MYGReportesExportacion.Guardar(archivo, MYGFormatoExportacionReporte.Mht, MYGReportesCronograma.Crear(proyecto, plan, modoRutaCritica));
        else MYGExportacionCronograma.Guardar(archivo, proyecto, plan, destino switch
        {
            MYGDestinoExportacionCronograma.XmlTareas => MYGFormatoExportacionCronograma.XmlTareas,
            MYGDestinoExportacionCronograma.XmlRecursos => MYGFormatoExportacionCronograma.XmlTareasRecursos,
            _ => MYGFormatoExportacionCronograma.Texto
        });
        estado.Text = "Cronograma exportado: " + archivo;
    }
}
