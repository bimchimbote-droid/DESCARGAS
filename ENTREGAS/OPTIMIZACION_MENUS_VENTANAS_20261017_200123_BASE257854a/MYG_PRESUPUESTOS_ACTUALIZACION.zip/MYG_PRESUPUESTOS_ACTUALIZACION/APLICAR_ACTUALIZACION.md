# Actualización de rendimiento de MYG Presupuestos

Código: bimchimbote-droid/MYG.Presupuestos, rama main.
Base exacta revisada: `257854a00820c07fe9806862cbedaf52bb92bc81`.
Tecnologías: Visual Studio, C#, .NET 10, SQLite y conector Revit 2027.

## Aplicación manual sin perder avances

1. Cierra MYG y Visual Studio antes de sustituir los archivos. Conserva una copia de tus cambios locales fuera de la carpeta del proyecto. No sustituyas archivos completos si contienen avances posteriores a esta base: compara e integra esos cambios primero.
2. Abre tu checkout habitual (por ejemplo `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`). Copia el contenido de `ARCHIVOS` a su raíz, manteniendo las carpetas `MYG.Desktop` y `MYG.PruebasUI`. Sustituye únicamente los siete archivos indicados y crea los dos nuevos.
3. La entrega no contiene `.git`, bases de obras, credenciales, manifiestos ni lockfiles. Conserva tu carpeta `.git` y los demás archivos. No necesitas volver a clonar el proyecto.
4. Abre `MYG.Presupuestos.sln` en Visual Studio con SDK .NET 10 y compila Release/x64. Los archivos nuevos de pruebas se incluyen automáticamente por el SDK del proyecto.
5. Si prefieres un parche en vez de copiar los archivos completos, desde la raíz ejecuta primero `git apply --check RUTA\CAMBIOS.patch` y después `git apply RUTA\CAMBIOS.patch`. Usa un solo método. Si la comprobación falla, revisa las diferencias de versión; no fuerces la aplicación.
6. En tu Windows, ejecuta las regresiones de interfaz y comprueba la apertura de menús con una copia de tu obra real, con y sin ediciones pendientes. Alterna el tema y el tamaño de texto, y confirma que imprimir/exportar usa los últimos datos. El apartado de validación distingue las pruebas ejecutadas de las pendientes.

## Archivos del proyecto

Las rutas se interpretan desde la raíz de tu repositorio. Cada archivo de `ARCHIVOS` se entrega completo.

| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR | Abre los cuatro desplegables sin sincronizar ni firmar todo el proyecto; conserva las validaciones al ejecutar cada destino. |
| 2 | `MYG.Desktop/InsumosForm.cs` | REEMPLAZAR | Reutiliza un cálculo por filtrado de subpartidas, sin mantener resultados entre ediciones. |
| 3 | `MYG.Desktop/PresupuestosExcelPanel.cs` | REEMPLAZAR | Comparte el cálculo del resumen y sus filas dentro de la misma actualización. |
| 4 | `MYG.Desktop/Tema.cs` | REEMPLAZAR | Permite actualizar también los menús ocultos después de cambiar los colores predeterminados. |
| 5 | `MYG.Desktop/TemaAplicacion.cs` | REEMPLAZAR | Evita reaplicar el tema completo en aperturas y repintados sin cambios; conserva actualización de tema, DPI y contenido dinámico. |
| 6 | `MYG.PruebasUI/ImprimirProyectoCheck.cs` | REEMPLAZAR | Comprueba apertura ligera de los cuatro menús y conservación de sincronización y licencia con HTTP simulado. |
| 7 | `MYG.PruebasUI/Program.cs` | REEMPLAZAR | Registra las regresiones nuevas y añade la selección --rendimiento-apertura. |
| 8 | `MYG.PruebasUI/ResumenCalculoUICheck.cs` | CREAR | Verifica importes tras editar porcentajes y moneda, sin modificar el presupuesto original. |
| 9 | `MYG.PruebasUI/TemaAperturaRendimientoCheck.cs` | CREAR | Comprueba preparación reutilizable y preservación de RTF, selección, historial y callbacks. |

## Comandos comprobados

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

Las referencias Nice3point permiten compilar el conector sin una instalación local de Revit. La prueba real del conector requiere Autodesk Revit 2027 en Windows.

## Comando de interfaz pendiente de ejecución en Windows

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release -- --rendimiento-apertura
```

Esta selección ejecuta las regresiones de tema, menús y resumen. Para la suite UI completa, omite `-- --rendimiento-apertura`. Aquí estas pruebas solo se compilaron: no se ejecutaron en Linux.

## Evidencia y entrega

`INFORME_REVISION.md` explica las causas y el alcance de la revisión. `VALIDACION` contiene los registros y el informe QA de esta ejecución. `SHA256_ARCHIVOS.json` permite verificar los archivos de la entrega. El código queda disponible para aplicación manual: no se publicaron cambios en la rama main del repositorio del código. El ZIP se entrega en el repositorio independiente público `bimchimbote-droid/DESCARGAS`, dentro de una carpeta nueva para conservar entregas anteriores.
