# Revisión de rendimiento

Base: `257854a00820c07fe9806862cbedaf52bb92bc81`. Entorno de validación: Debian Linux x64, .NET SDK 10.0.100.

## Causas corregidas

- Los cuatro menús de la cinta (Imprimir/PDF, Exportar, Responsables y Permisos) usaban el mismo ejecutor que una operación de edición. Antes de enseñar las opciones, recorrían la cuadrícula BIM y, en proyectos guardados, copiaban/serializaban el documento para comprobar su firma. Los menús que requerían licencia también podían esperar su renovación. Ahora la apertura solo prepara las opciones; cada destino efectivo conserva su ejecutor, licencia, sincronización, actualización y manejo de errores.
- El filtro de tema aplicaba de nuevo la paleta al mostrar una ventana/desplegable, incluyendo recorrer cuadrículas enteras. Los desplegables del editor de especificaciones no quedaban registrados como genéricos y podían repetir el recorrido especializado al recibir mensajes de pintura. La preparación se reutiliza mientras tema, contraste, DPI, revisión de colores y contexto permanezcan vigentes. Las llamadas explícitas para aplicar tema siguen funcionando. Los controles y opciones añadidos reciben estilos mediante sus eventos existentes. RTF, colores del documento y selección conservan su tratamiento especializado.
- El selector de subpartidas creaba un cálculo independiente por fila y reconstruía los índices de insumos. Ahora usa una sesión local por filtrado. Una nueva operación crea otra sesión; no se guarda una caché global.
- El resumen de costos calculaba su total y sus filas con sesiones independientes en el mismo evento. Ahora comparten la misma sesión. Se conserva una copia nueva del presupuesto en cada edición para evitar resultados antiguos o cambios en el documento original.

No se cambiaron las fórmulas, el motor de costos, los formatos de guardado ni el protocolo de Revit. Se revisaron llamadas de apertura, temas, cursores, animaciones, catálogos, firma/copias del documento y los cálculos relacionados. La revisión estática no demuestra la ausencia de todos los problemas de rendimiento.

## Validación de esta entrega

- Compilación completa Release de los cinco proyectos, incluidos escritorio Windows, conector y pruebas UI: 0 errores, 0 advertencias.
- Suite real del núcleo: 462 comprobaciones completadas, con SQLite real y datos sintéticos. Se verificó que `resultado_qa.json` fuera de la ejecución actual y que su Total coincidiera con el número de resultados.
- `RendimientoCalculoCheck` aislado: 5 grupos aprobados, incluida equivalencia de 400 partidas/4800 insumos, 63 combinaciones de precisión, ciclos, Delphin y sesiones nuevas tras editar.
- `git diff --check`: correcto.
- Las nuevas regresiones UI se compilaron, pero su ejecución requiere Windows. No se validó aquí la fluidez visual, el cambio real entre monitores/DPI, la licencia de producción, Named Pipes, la apertura en Delphin ni la operación de Revit.
- Las comprobaciones que requieren muestras externas opcionales de Delphin/LLACUSBAMBA no se ejecutaron; esas muestras no están presentes.

## Medición sintética

El registro `VALIDACION/medicion-sintetica.txt` compara el tramo de cálculo de 400 partidas y 4800 insumos. Se hace un calentamiento por escenario y tres muestras con Stopwatch y asignaciones del hilo actual. El escenario anterior llama Analizar una vez por partida; el nuevo usa una sesión por operación. Se comprueba la igualdad de la suma de precios. También se mide el coste de Firma en ese documento sintético, que ayuda a explicar la demora eliminada al abrir los menús de proyectos guardados.

Estos tiempos son del cálculo en Linux y del equipo disponible; no representan la apertura real de un formulario en Windows ni permiten prometer el mismo factor de mejora en una obra concreta.

## Criterio de seguridad de los cambios

Se mantuvieron las validaciones de licencia en los destinos efectivos, el cierre diferido de menús, el historial, los cálculos decimales y la actualización del tema cuando cambia el contexto. No se introdujo trabajo en segundo plano sobre documentos mutables ni se modificaron las bases del usuario. Las verificaciones de interfaz deben completarse en Windows antes de usar esta versión en producción.
