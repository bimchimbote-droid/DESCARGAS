using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private readonly MYGPestanasProyectos pestanasProyectos = new()
    {
        Name = "proyectos_abiertos", Dock = DockStyle.Fill, Alignment = TabAlignment.Bottom,
        ShowToolTips = true, Margin = new(0)
    };
    private readonly TabPage paginaInicio = new("Inicio") { Name = "inicio_proyectos", Padding = new(0) };
    private bool cambiandoPagina;
    internal TabControl PestanasProyectos => pestanasProyectos;

    private void InicializarProyectosAbiertos(Control cabeceraInicio)
    {
        paginaInicio.Controls.Add(contenido);
        paginaInicio.Controls.Add(baseVisible);
        paginaInicio.Controls.Add(MYGParametrosAplicacionUI.CrearIdentidadEmpresa());
        paginaInicio.Controls.Add(cabeceraInicio);
        pestanasProyectos.TabPages.Add(paginaInicio);
        Controls.Add(pestanasProyectos);
        pestanasProyectos.CerrarSolicitado += pagina => CerrarProyecto((EditorForm)pagina.Tag);
        pestanasProyectos.Selecting += (_, e) =>
        {
            if (cambiandoPagina || cerrandoInicio) return;
            if (ocupado || pestanasProyectos.SelectedTab?.Tag is EditorForm actual && !actual.PrepararCambioVista())
                e.Cancel = true;
        };
        pestanasProyectos.SelectedIndexChanged += (_, _) =>
        {
            if (pestanasProyectos.SelectedTab == paginaInicio) SolicitarRefrescoInicio();
        };
    }

    private EditorForm[] EditoresAbiertos => pestanasProyectos.TabPages.Cast<TabPage>()
        .Select(p => p.Tag).OfType<EditorForm>().Where(e => !e.IsDisposed).ToArray();

    private static bool MismaRuta(string a, string b) =>
        string.Equals(string.IsNullOrWhiteSpace(a) ? "" : Path.GetFullPath(a),
            string.IsNullOrWhiteSpace(b) ? "" : Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase);

    private EditorForm BuscarEditor(string ruta, string id) => EditoresAbiertos.FirstOrDefault(e =>
        e.ProyectoId == id && MismaRuta(e.RutaProyecto, ruta));

    private void SeleccionarPagina(TabPage pagina)
    {
        // Las operaciones de apertura seleccionan su resultado al terminar la carga.
        // El usuario no puede cambiar de proyecto mientras hay una operación en curso.
        cambiandoPagina = true;
        try { pestanasProyectos.SelectedTab = pagina; }
        finally { cambiandoPagina = false; }
    }

    private void SeleccionarEditor(EditorForm editor)
    {
        var pagina = pestanasProyectos.TabPages.Cast<TabPage>().First(p => p.Tag == editor);
        SeleccionarPagina(pagina); editor.Focus();
    }

    internal EditorForm AbrirEditor(MYGProyectoDocumento doc, string ruta = null)
    {
        ruta ??= rutaBase;
        var existente = BuscarEditor(ruta, doc.Id);
        if (existente != null) { SeleccionarEditor(existente); return existente; }
        if (!string.IsNullOrWhiteSpace(ruta)) MYGIndiceLocal.Registrar(doc, ruta);
        var editor = new EditorForm(doc, ruta, sesion)
        {
            TopLevel = false, FormBorderStyle = FormBorderStyle.None,
            ShowInTaskbar = false, Dock = DockStyle.Fill, MinimumSize = Size.Empty
        };
        var pagina = new TabPage { Padding = new(0), Tag = editor };
        void ActualizarPagina()
        {
            pagina.Text = editor.NombreProyecto + (editor.CambiosPendientes ? " *" : "");
            pagina.ToolTipText = editor.NombreProyecto + Environment.NewLine + editor.RutaProyecto;
            pestanasProyectos.Invalidate();
        }
        editor.RegresarInicio = () => ActivarInicio(editor);
        editor.AbrirEnPestana = (archivo, documento) => AbrirEditor(documento, archivo);
        editor.ProyectoActualizado += ActualizarPagina;
        editor.Disposed += (_, _) =>
        {
            editor.ProyectoActualizado -= ActualizarPagina;
            pestanasProyectos.TabPages.Remove(pagina); pagina.Dispose();
            if (!cerrandoInicio && !IsDisposed && !Disposing && MismaRuta(editor.RutaProyecto, rutaBase))
                SolicitarRefrescoInicio(editor.ProyectoId);
        };
        ActualizarPagina();
        pagina.Controls.Add(editor); pestanasProyectos.TabPages.Add(pagina);
        SeleccionarPagina(pagina); editor.Show(); editor.Focus();
        return editor;
    }

    internal bool ActivarInicio(EditorForm editor = null)
    {
        editor ??= pestanasProyectos.SelectedTab?.Tag as EditorForm;
        if (ocupado || editor != null && !editor.PrepararCambioVista()) return false;
        if (editor != null && !string.IsNullOrWhiteSpace(editor.RutaProyecto))
            rutaBase = Path.GetFullPath(editor.RutaProyecto);
        SeleccionarPagina(paginaInicio);
        return true;
    }

    private void SolicitarRefrescoInicio(string seleccionar = null)
    {
        if (IsDisposed || Disposing || cerrandoInicio || string.IsNullOrWhiteSpace(rutaBase)) return;
        refrescoPendiente = seleccionar ?? "";
        // La navegación sigue disponible con la sesión vencida. La lectura de la
        // base se reanuda cuando la sesión esté autorizada y el inicio esté libre.
        if (ocupado || !sesion.Autorizado || !IsHandleCreated || pestanasProyectos.SelectedTab != paginaInicio) return;
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing || cerrandoInicio || ocupado || !sesion.Autorizado ||
                pestanasProyectos.SelectedTab != paginaInicio || refrescoPendiente == null) return;
            string id = refrescoPendiente; refrescoPendiente = null;
            await IntentarAsync(() => RefrescarProyectosAsync(id));
        }));
    }

    internal bool CerrarProyecto(EditorForm editor)
    {
        if (ocupado || editor == null) return false;
        editor.Close();
        return editor.IsDisposed;
    }

    private bool CerrarProyectos()
    {
        var abiertos = EditoresAbiertos;
        if (abiertos.Any(e => e.OperacionEnCurso)) return false;
        // Comprobar todos antes de retirar cualquiera: Cancelar conserva las pestañas.
        foreach (var editor in abiertos)
            if (!editor.ConfirmarCierreProyecto()) return false;
        foreach (var editor in abiertos)
            if (!editor.CerrarConfirmado()) return false;
        return true;
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (keyData == (Keys.Control | Keys.W) && pestanasProyectos.SelectedTab?.Tag is EditorForm editor)
        { CerrarProyecto(editor); return true; }
        return base.ProcessCmdKey(ref msg, keyData);
    }
}

// Mantiene la navegación nativa y reserva un área de cierre independiente del texto.
internal sealed class MYGPestanasProyectos : TabControl
{
    private const int EstablecerElemento = 0x133D, InsertarElemento = 0x133E;
    private const uint TextoElemento = 1;
    private bool ajustandoAnchos;
    internal event Action<TabPage> CerrarSolicitado;
    private bool cierrePulsado;
    internal int AnchoMaximoPestana => (int)Math.Round(340 * DeviceDpi / 96f);

    [StructLayout(LayoutKind.Sequential)]
    private struct ElementoPestana
    {
        internal uint Mascara, Estado, MascaraEstado;
        internal IntPtr Texto;
        internal int CapacidadTexto, Imagen;
        internal IntPtr Datos;
    }
    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    private static extern IntPtr EnviarElemento(IntPtr ventana, int mensaje, IntPtr indice, ref ElementoPestana elemento);

    // El control nativo no permite fijar un máximo por pestaña. Limitar solo su
    // etiqueta de medición conserva anchos naturales para los nombres cortos y
    // deja intactos TabPage.Text, la ayuda completa y el nombre del documento.
    private string TextoParaMedir(string texto)
    {
        int disponible = Math.Max(1, AnchoMaximoPestana - 2 * Padding.X - (int)Math.Round(10 * DeviceDpi / 96f));
        const TextFormatFlags formato = TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix;
        Font fuente = MYGTamanoTextoUI.Fuente(Font);
        int Ancho(string valor) => TextRenderer.MeasureText(valor, fuente, Size.Empty, formato).Width;
        if (Ancho(texto) <= disponible) return texto;
        int menor = 0, mayor = texto.Length;
        while (menor < mayor)
        {
            int medio = (menor + mayor + 1) / 2;
            if (Ancho(texto[..medio] + "…") <= disponible) menor = medio;
            else mayor = medio - 1;
        }
        if (menor > 0 && char.IsHighSurrogate(texto[menor - 1])) menor--;
        return texto[..menor] + "…";
    }

    internal void AjustarAnchos()
    {
        if (ajustandoAnchos || !IsHandleCreated || IsDisposed || Disposing) return;
        ajustandoAnchos = true;
        try
        {
            for (int i = 0; i < TabCount; i++)
            {
                IntPtr texto = Marshal.StringToHGlobalUni(TabPages[i].Text);
                try
                {
                    var elemento = new ElementoPestana { Mascara = TextoElemento, Texto = texto };
                    EnviarElemento(Handle, EstablecerElemento, new IntPtr(i), ref elemento);
                }
                finally { Marshal.FreeHGlobal(texto); }
            }
            Invalidate();
        }
        finally { ajustandoAnchos = false; }
    }

    protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); AjustarAnchos(); }
    protected override void OnFontChanged(EventArgs e) { base.OnFontChanged(e); AjustarAnchos(); }
    protected override void OnDpiChangedAfterParent(EventArgs e) { base.OnDpiChangedAfterParent(e); AjustarAnchos(); }

    internal Rectangle AreaCerrar(int indice)
    {
        if (indice < 0 || indice >= TabCount || TabPages[indice].Tag is not EditorForm) return Rectangle.Empty;
        var limites = GetTabRect(indice);
        int lado = (int)Math.Round(20 * DeviceDpi / 96f);
        int margen = (int)Math.Round(6 * DeviceDpi / 96f);
        return new Rectangle(limites.Right - lado - margen, limites.Top + (limites.Height - lado) / 2, lado, lado);
    }
    internal void DibujarCierre(Graphics grafico, int indice, Color color)
    {
        var area = AreaCerrar(indice);
        if (area.IsEmpty) return;
        area.Inflate(-(int)Math.Round(6 * DeviceDpi / 96f), -(int)Math.Round(6 * DeviceDpi / 96f));
        using var trazo = new Pen(color, Math.Max(1, DeviceDpi / 96f));
        grafico.DrawLine(trazo, area.Left, area.Top, area.Right, area.Bottom);
        grafico.DrawLine(trazo, area.Left, area.Bottom, area.Right, area.Top);
    }
    protected override void WndProc(ref Message m)
    {
        const int pulsarIzquierdo = 0x0201, soltarIzquierdo = 0x0202;
        if ((m.Msg == EstablecerElemento || m.Msg == InsertarElemento) && m.LParam != IntPtr.Zero)
        {
            var elemento = Marshal.PtrToStructure<ElementoPestana>(m.LParam);
            if ((elemento.Mascara & TextoElemento) != 0 && elemento.Texto != IntPtr.Zero && elemento.Texto != new IntPtr(-1))
            {
                string original = Marshal.PtrToStringUni(elemento.Texto) ?? "";
                string medido = TextoParaMedir(original);
                if (medido != original)
                {
                    IntPtr datosOriginales = m.LParam;
                    IntPtr texto = Marshal.StringToHGlobalUni(medido);
                    IntPtr datos = Marshal.AllocHGlobal(Marshal.SizeOf<ElementoPestana>());
                    try
                    {
                        elemento.Texto = texto;
                        Marshal.StructureToPtr(elemento, datos, false);
                        m.LParam = datos;
                        base.WndProc(ref m);
                    }
                    finally
                    {
                        m.LParam = datosOriginales;
                        Marshal.FreeHGlobal(datos); Marshal.FreeHGlobal(texto);
                    }
                    return;
                }
            }
        }
        if (m.Msg == pulsarIzquierdo)
        {
            cierrePulsado = false;
            long coordenadas = m.LParam.ToInt64();
            var punto = new Point(unchecked((short)coordenadas), unchecked((short)(coordenadas >> 16)));
            for (int i = 0; i < TabCount; i++)
                if (AreaCerrar(i).Contains(punto))
                {
                    var pagina = TabPages[i]; cierrePulsado = true;
                    // Capturar antes de la selección nativa conserva la pestaña
                    // exacta pulsada, incluso si cambia el desplazamiento de la barra.
                    BeginInvoke(new Action(() =>
                    {
                        if (!IsDisposed && !pagina.IsDisposed && TabPages.Contains(pagina))
                            CerrarSolicitado?.Invoke(pagina);
                    }));
                    m.Result = IntPtr.Zero; return;
                }
        }
        else if (m.Msg == soltarIzquierdo && cierrePulsado)
        { cierrePulsado = false; m.Result = IntPtr.Zero; return; }
        base.WndProc(ref m);
        if (m.Msg == 0x132B) AjustarAnchos(); // TCM_SETPADDING: el tema reserva el espacio para ×.
    }
}

internal sealed partial class EditorForm
{
    internal string ProyectoId => documento.Id;
    internal string RutaProyecto => archivo;
    internal string NombreProyecto => string.IsNullOrWhiteSpace(documento.Nombre) ? "Proyecto" : documento.Nombre;
    internal bool OperacionEnCurso => ocupado;
    internal bool CambiosPendientes { get; private set; }
    internal event Action ProyectoActualizado;
    internal Action RegresarInicio;
    internal Action<string, MYGProyectoDocumento> AbrirEnPestana;
    private bool cierreConfirmado;

    internal bool PrepararCambioVista()
    {
        if (ocupado || IsDisposed || Disposing) return false;
        try { Sincronizar(); ActualizarIndicadorArchivo(); return true; }
        catch (Exception ex) { MYGProyectoUI.Error(this, ex); return false; }
    }
    internal void IrInicio()
    {
        if (!PrepararCambioVista()) return;
        if (RegresarInicio != null) RegresarInicio(); else Close();
    }
    internal void EditarDatosProyectoAbierto()
    {
        if (PrepararCambioVista()) EditarDatosProyecto();
    }
    internal bool ConfirmarCierreProyecto()
    {
        var argumentos = new FormClosingEventArgs(CloseReason.UserClosing, false);
        OnFormClosing(argumentos);
        return !argumentos.Cancel;
    }
    internal bool CerrarConfirmado()
    {
        cierreConfirmado = true;
        try { Close(); return IsDisposed; }
        finally { cierreConfirmado = false; }
    }
}
