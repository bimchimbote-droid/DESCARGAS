using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using MYG_2027;

internal static class GraficoIncidenciaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception(mensaje); }

    private static void Rechaza(Action accion, string caso)
    {
        try { accion(); }
        catch (InvalidDataException) { return; }
        catch (JsonException) { return; }
        throw new Exception("La plantilla del gráfico aceptó " + caso + ".");
    }

    internal static void Ejecutar(Action<string> pasa)
    {
        CatalogoYPlantillas(pasa);
        CopiasIndependientes(pasa);
        DatosDelProyecto(pasa);
        PlantillasInvalidas(pasa);
    }

    private static MYGConfiguracionGraficoIncidencia Ejemplo() => new()
    {
        Tipo = "tarta3d", Titulo = "Incidencia de Costos · Ñ / <obra>", Subtitulo = "Presupuesto S/ 2027",
        MostrarTitulo = true, MostrarEjes = false, MostrarCuadricula = false, MostrarEtiquetas = true,
        MostrarLeyenda = true, EtiquetaNombre = true, EtiquetaPorcentaje = true, EtiquetaImporte = true,
        Paleta = "Multicolor", Apariencia = 4, TamanoFuente = 13.5f, Angulo = 359, Inclinacion = 65,
        Separacion = 35, Horizontal = true, MinimoEje = -12.5m, MaximoEje = 1000.25m,
        Titulos = new[] { "Mano de obra", "Materiales", "Equipo", "Subcontratos" },
        Anotaciones = new() { new() { Texto = "Mayor incidencia: materiales", X = 12.5f, Y = 83.25f } },
        BotonesOcultos = new[] { "exportar", "paleta" }, BarraVisible = false, IconosGrandes = true,
        MostrarAyudas = false, MostrarTextos = true, MenusCompletos = true, ExpandirMenus = false,
        MostrarAtajos = false, EfectosMenus = "Desvanecer",
        UsosComandos = new() { ["exportar-pdf"] = 8, ["imprimir"] = 3 },
        BarrasPersonalizadas = new()
        {
            new() { Nombre = "Entrega de informes", Comandos = new[] { "previsualizar", "exportar-pdf", "imprimir" } },
            new() { Nombre = "Edición del gráfico", Comandos = new[] { "titulos", "anotaciones" }, Visible = false }
        }
    };

    private static void CatalogoYPlantillas(Action<string> pasa)
    {
        var tipos = MYGCatalogoGraficosIncidencia.Tipos;
        Exige(tipos.Count > 0 && tipos.Select(t => t.Id).Distinct(StringComparer.Ordinal).Count() == tipos.Count &&
            tipos.All(t => !string.IsNullOrWhiteSpace(t.Nombre) && !string.IsNullOrWhiteSpace(t.Grupo) &&
                !string.IsNullOrWhiteSpace(t.Familia)), "El catálogo del gráfico contiene identidades duplicadas o tipos sin nombre y familia.");
        Exige(MYGCatalogoGraficosIncidencia.Paletas.Count >= 7 &&
            MYGCatalogoGraficosIncidencia.Paletas.All(p => p.Value.Length >= 4 && p.Value.All(c =>
                c.Length == 7 && c[0] == '#' && c.Skip(1).All(Uri.IsHexDigit))),
            "Las paletas deben definir colores RGB válidos para los cuatro grupos del costo.");

        int combinaciones = 0;
        foreach (var tipo in tipos)
            foreach (string paleta in MYGCatalogoGraficosIncidencia.Paletas.Keys)
                for (int apariencia = 0; apariencia < 5; apariencia++)
                {
                    var configuracion = Ejemplo(); configuracion.Tipo = tipo.Id;
                    configuracion.Paleta = paleta; configuracion.Apariencia = apariencia;
                    string plantilla = configuracion.AJson();
                    var reabierta = MYGConfiguracionGraficoIncidencia.DesdeJson(plantilla);
                    Exige(reabierta.AJson() == plantilla && reabierta.Tipo == tipo.Id && reabierta.Paleta == paleta &&
                        reabierta.Apariencia == apariencia && !ReferenceEquals(reabierta, configuracion),
                        "Guardar y cargar perdió opciones del gráfico " + tipo.Id + ", " + paleta + ", " + apariencia + ".");
                    combinaciones++;
                }

        // Una plantilla completa también conserva los estados desactivados y los límites válidos.
        var limites = Ejemplo(); limites.MostrarTitulo = false; limites.MostrarEtiquetas = false;
        limites.MostrarLeyenda = false; limites.EtiquetaNombre = false; limites.EtiquetaPorcentaje = false;
        limites.EtiquetaImporte = false; limites.Angulo = 360; limites.Inclinacion = 75; limites.Separacion = 40;
        limites.TamanoFuente = 32; limites.MinimoEje = 10; limites.MaximoEje = 0;
        limites.MenusCompletos = false; limites.ExpandirMenus = true; limites.MostrarAtajos = true;
        Exige(MYGConfiguracionGraficoIncidencia.DesdeJson(limites.AJson()).AJson() == limites.AJson(),
            "La plantilla perdió los indicadores desactivados o los límites permitidos de sus dimensiones.");
        limites.TamanoFuente = 6; limites.Angulo = 0; limites.Inclinacion = 0; limites.Separacion = 0;
        limites.Validar();
        foreach (string efecto in new[] { "Predeterminado", "Sin animación", "Desvanecer" })
        {
            limites.EfectosMenus = efecto;
            Exige(MYGConfiguracionGraficoIncidencia.DesdeJson(limites.AJson()).EfectosMenus == efecto,
                "La plantilla perdió el efecto elegido para los menús.");
        }
        pasa("Gráfico conserva todos los campos al guardar y cargar " + combinaciones +
            " combinaciones de tipos, cinco apariencias y todas las paletas, incluidas las 35 muestras de la galería");
    }

    private static void CopiasIndependientes(Action<string> pasa)
    {
        var original = Ejemplo(); string antes = original.AJson(); var copia = original.Copia();
        Exige(copia.AJson() == antes && !ReferenceEquals(original.Titulos, copia.Titulos) &&
            !ReferenceEquals(original.Anotaciones, copia.Anotaciones) &&
            !ReferenceEquals(original.Anotaciones[0], copia.Anotaciones[0]) &&
            !ReferenceEquals(original.BotonesOcultos, copia.BotonesOcultos) &&
            !ReferenceEquals(original.UsosComandos, copia.UsosComandos) &&
            !ReferenceEquals(original.BarrasPersonalizadas, copia.BarrasPersonalizadas) &&
            !ReferenceEquals(original.BarrasPersonalizadas[0], copia.BarrasPersonalizadas[0]) &&
            !ReferenceEquals(original.BarrasPersonalizadas[0].Comandos, copia.BarrasPersonalizadas[0].Comandos),
            "Copiar debe separar títulos, anotaciones, botones, datos de empleo y barras personalizadas del original.");
        copia.Titulos[0] = "Título de copia"; copia.Anotaciones[0].Texto = "Anotación de copia";
        copia.Anotaciones[0].X = 5; copia.Anotaciones.Add(new() { Texto = "Nueva", X = 100, Y = 0 });
        copia.BotonesOcultos[0] = "imprimir"; copia.Tipo = "columnas-0"; copia.BarraVisible = true;
        copia.UsosComandos["exportar-pdf"]++; copia.UsosComandos["titulos"] = 1;
        copia.BarrasPersonalizadas[0].Nombre = "Entrega de la copia";
        copia.BarrasPersonalizadas[0].Comandos[0] = "guardar";
        copia.BarrasPersonalizadas[1].Visible = true;
        copia.BarrasPersonalizadas.Add(new() { Nombre = "Nueva barra", Comandos = new[] { "cargar" } });
        Exige(original.AJson() == antes, "Editar una copia modificó el gráfico original o sus objetos anidados.");
        string estadoCopia = copia.AJson();
        original.Titulos[1] = "Edición del origen"; original.Anotaciones.Clear();
        original.BotonesOcultos = Array.Empty<string>();
        original.UsosComandos.Clear(); original.BarrasPersonalizadas[0].Comandos[0] = "restaurar";
        original.BarrasPersonalizadas.RemoveAt(1);
        Exige(copia.AJson() == estadoCopia,
            "Editar el gráfico original cambió títulos, anotaciones, botones, datos de empleo o barras de su copia.");
        var nueva = new MYGConfiguracionGraficoIncidencia();
        Exige(nueva.Anotaciones.Count == 0 && nueva.BotonesOcultos.Length == 0 && nueva.Titulos.Length == 0 &&
            nueva.UsosComandos.Count == 0 && nueva.BarrasPersonalizadas.Count == 0,
            "Una configuración nueva heredó anotaciones, títulos, botones, datos de empleo o barras de otra instancia.");
        pasa("Copias del gráfico aíslan títulos, anotaciones, botones, datos de empleo y barras personalizadas en ambos sentidos, sin contaminar instancias nuevas");
    }

    private static void DatosDelProyecto(Action<string> pasa)
    {
        var proyecto = MYGProyectoStorage.Nuevo("GRÁFICO QA CON DATOS REALES DEL MOTOR");
        var presupuesto = proyecto.Presupuestos.Single();
        var partida = MYGEstructuraPresupuestos.InsertarNodo(presupuesto, false); partida.Costos.Cantidad = 2;
        var grupos = new[] { MYGGrupoRecurso.ManoObra, MYGGrupoRecurso.Materiales,
            MYGGrupoRecurso.Equipo, MYGGrupoRecurso.Subcontratos };
        for (int n = 0; n < grupos.Length; n++)
        {
            var insumo = new MYGInsumo { Grupo = grupos[n], Codigo = "GRAF-" + n,
                Descripcion = "Recurso " + grupos[n], Precio = (n + 1) * 10m };
            presupuesto.Costos.Insumos.Add(insumo);
            partida.Costos.Analisis.Add(new MYGRecursoACU { Grupo = grupos[n], InsumoId = insumo.Id, Cantidad = 1 });
        }
        MYGProyectoStorage.Validar(proyecto);
        MYGMotorPresupuestos.CapturarPrecioDelphin(presupuesto, partida, 100.01m, 200.03m);
        MYGMotorPresupuestos.CapturarDatosDelphin(presupuesto, partida);
        MYGMotorPresupuestos.CapturarPresupuestoDelphin(presupuesto);
        string datos = JsonSerializer.Serialize(proyecto), firma = MYGProyectoStorage.Firma(proyecto);
        string analisis = MYGMotorPresupuestos.FirmaAnalisis(presupuesto, partida);
        string incidencia = JsonSerializer.Serialize(MYGPiePresupuesto.Incidencia(new[] { presupuesto }));
        string resumen = JsonSerializer.Serialize(MYGMotorPresupuestos.Resumen(presupuesto));
        Exige(MYGPiePresupuesto.Incidencia(new[] { presupuesto }).Count == 4 &&
            MYGMotorPresupuestos.Resumen(presupuesto).CostoDirecto == 200.03m,
            "El escenario debe incluir los cuatro grupos e importes nativos con redondeo importado.");

        foreach (var tipo in MYGCatalogoGraficosIncidencia.Tipos)
        {
            var configuracion = Ejemplo(); configuracion.Tipo = tipo.Id;
            foreach (string paleta in MYGCatalogoGraficosIncidencia.Paletas.Keys)
                for (int apariencia = 0; apariencia < 5; apariencia++)
                {
                    configuracion.Paleta = paleta; configuracion.Apariencia = apariencia;
                    configuracion = MYGConfiguracionGraficoIncidencia.DesdeJson(configuracion.AJson()).Copia();
                }
            Exige(JsonSerializer.Serialize(proyecto) == datos && MYGProyectoStorage.Firma(proyecto) == firma &&
                MYGMotorPresupuestos.FirmaAnalisis(presupuesto, partida) == analisis &&
                JsonSerializer.Serialize(MYGPiePresupuesto.Incidencia(new[] { presupuesto })) == incidencia &&
                JsonSerializer.Serialize(MYGMotorPresupuestos.Resumen(presupuesto)) == resumen &&
                MYGMotorPresupuestos.ConservaAnalisisDelphin(presupuesto, partida) &&
                MYGMotorPresupuestos.ConservaDatosDelphin(presupuesto, partida) &&
                MYGMotorPresupuestos.ConservaPresupuestoDelphin(presupuesto),
                "Cambiar o cargar presentación del gráfico alteró datos, incidencia, firma o redondeos del proyecto: " + tipo.Id + ".");
        }
        pasa("Todos los tipos y apariencias del gráfico conservan los cuatro grupos, firmas reales, datos y redondeos importados del presupuesto");
    }

    private static void PlantillasInvalidas(Action<string> pasa)
    {
        foreach (string json in new[] { null, "", "  ", "null", "[]", "17", "{", "\"gráfico\"",
            new string('x', 1_000_001), "{\"Tipo\":\"desconocido\"}", "{\"Tipo\":null}",
            "{\"Paleta\":\"desconocida\"}", "{\"Paleta\":null}", "{\"Apariencia\":\"azul\"}",
            "{\"MostrarEjes\":1}", "{\"TamanoFuente\":\"NaN\"}", "{\"TamanoFuente\":1e9999}",
            "{\"MinimoEje\":1e9999}", "{\"Anotaciones\":[{\"X\":\"NaN\"}]}",
            "{\"BotonesOcultos\":{\"paleta\":true}}", "{\"Titulos\":[false]}",
            "{\"UsosComandos\":{\"imprimir\":\"tres\"}}", "{\"BarrasPersonalizadas\":[false]}",
            "{\"BarrasPersonalizadas\":[{\"Nombre\":\"Entrega\",\"Comandos\":\"imprimir\"}]}" })
            Rechaza(() => MYGConfiguracionGraficoIncidencia.DesdeJson(json), "JSON vacío, excesivo, mal formado o con campos incompatibles");

        var invalidas = new List<Action<MYGConfiguracionGraficoIncidencia>>
        {
            c => c.Tipo = "", c => c.Paleta = "", c => c.Apariencia = -1, c => c.Apariencia = 5,
            c => c.TamanoFuente = float.NaN, c => c.TamanoFuente = float.PositiveInfinity,
            c => c.TamanoFuente = float.NegativeInfinity, c => c.TamanoFuente = 5.99f, c => c.TamanoFuente = 32.01f,
            c => c.Angulo = -1, c => c.Angulo = 361, c => c.Inclinacion = -1, c => c.Inclinacion = 76,
            c => c.Separacion = -1, c => c.Separacion = 41,
            c => { c.MinimoEje = 2; c.MaximoEje = 2; }, c => { c.MinimoEje = 3; c.MaximoEje = 2; },
            c => c.Titulo = new string('a', 301), c => c.Subtitulo = new string('a', 501),
            c => c.Titulos = null, c => c.Titulos = new string[] { null },
            c => c.Titulos = new[] { new string('a', 301) }, c => c.Titulos = Enumerable.Repeat("a", 21).ToArray(),
            c => c.Anotaciones = null, c => c.Anotaciones = new() { null },
            c => c.Anotaciones[0].Texto = null, c => c.Anotaciones[0].Texto = new string('a', 501),
            c => c.Anotaciones = Enumerable.Range(0, 51).Select(_ => new MYGAnotacionGrafico()).ToList(),
            c => c.Anotaciones[0].X = float.NaN, c => c.Anotaciones[0].Y = float.PositiveInfinity,
            c => c.Anotaciones[0].X = -.1f, c => c.Anotaciones[0].X = 100.1f,
            c => c.Anotaciones[0].Y = -.1f, c => c.Anotaciones[0].Y = 100.1f,
            c => c.BotonesOcultos = null, c => c.BotonesOcultos = new string[] { null },
            c => c.BotonesOcultos = new[] { new string('a', 81) },
            c => c.BotonesOcultos = Enumerable.Repeat("a", 31).ToArray(),
            c => c.EfectosMenus = null, c => c.EfectosMenus = "No existe",
            c => c.UsosComandos = null, c => c.UsosComandos["imprimir"] = -1,
            c => c.UsosComandos["imprimir"] = 1_000_001, c => c.UsosComandos[" "] = 1,
            c => c.UsosComandos[new string('a', 81)] = 1,
            c => c.UsosComandos = Enumerable.Range(0, 81).ToDictionary(n => "comando-" + n, _ => 1),
            c => c.BarrasPersonalizadas = null, c => c.BarrasPersonalizadas.Add(null),
            c => c.BarrasPersonalizadas = Enumerable.Range(0, 9).Select(n => new MYGBarraGraficoIncidencia
                { Nombre = "Barra " + n, Comandos = new[] { "imprimir" } }).ToList(),
            c => c.BarrasPersonalizadas[0].Nombre = " ",
            c => c.BarrasPersonalizadas[0].Nombre = new string('a', 81),
            c => c.BarrasPersonalizadas[0].Nombre = "tipo de gráfico",
            c => c.BarrasPersonalizadas[1].Nombre = c.BarrasPersonalizadas[0].Nombre.ToUpperInvariant(),
            c => c.BarrasPersonalizadas[0].Comandos = null,
            c => c.BarrasPersonalizadas[0].Comandos = Array.Empty<string>(),
            c => c.BarrasPersonalizadas[0].Comandos = Enumerable.Repeat("imprimir", 41).ToArray(),
            c => c.BarrasPersonalizadas[0].Comandos = new string[] { null },
            c => c.BarrasPersonalizadas[0].Comandos = new[] { " " },
            c => c.BarrasPersonalizadas[0].Comandos = new[] { new string('a', 81) }
        };
        foreach (var invalidar in invalidas)
        {
            var configuracion = Ejemplo(); invalidar(configuracion);
            Rechaza(configuracion.Validar, "valores fuera de rango o colecciones inválidas");
            Rechaza(() => configuracion.AJson(), "la exportación de una configuración inválida");
            Rechaza(() => configuracion.Copia(), "la copia de una configuración inválida");
        }
        pasa("Plantillas rechazan JSON mal formado, sobredimensionado, tipos incorrectos, NaN/infinito y dimensiones, ejes, anotaciones, botones, menús o barras inválidos");
    }
}
