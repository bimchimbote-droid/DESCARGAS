using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace MYG_2027;

public sealed record MYGTipoGraficoIncidencia(string Id, string Nombre, string Grupo,
    string Familia, string Forma, bool TresDimensiones, int Variante);

/// <summary>Presentación del gráfico; nunca modifica los importes del presupuesto.</summary>
public sealed class MYGConfiguracionGraficoIncidencia
{
    public string Tipo { get; set; } = "columnas-0";
    public string Titulo { get; set; } = "Incidencia de Costos";
    public string Subtitulo { get; set; } = "";
    public bool MostrarTitulo { get; set; } = true;
    public bool MostrarEjes { get; set; } = true;
    public bool MostrarCuadricula { get; set; } = true;
    public bool MostrarEtiquetas { get; set; } = true;
    public bool MostrarLeyenda { get; set; }
    public bool EtiquetaNombre { get; set; }
    public bool EtiquetaPorcentaje { get; set; } = true;
    public bool EtiquetaImporte { get; set; }
    public string Paleta { get; set; } = "Clasica";
    public int Apariencia { get; set; }
    public float TamanoFuente { get; set; } = 9;
    public int Angulo { get; set; } = 25;
    public int Inclinacion { get; set; } = 20;
    public int Separacion { get; set; } = 8;
    public bool Horizontal { get; set; }
    public decimal MinimoEje { get; set; }
    public decimal MaximoEje { get; set; }
    public string[] Titulos { get; set; } = Array.Empty<string>();
    public List<MYGAnotacionGrafico> Anotaciones { get; set; } = new();
    public string[] BotonesOcultos { get; set; } = Array.Empty<string>();
    public bool BarraVisible { get; set; } = true;
    public bool IconosGrandes { get; set; }
    public bool MostrarAyudas { get; set; } = true;
    public bool MostrarTextos { get; set; }
    public bool MenusCompletos { get; set; }
    public bool ExpandirMenus { get; set; } = true;
    public bool MostrarAtajos { get; set; } = true;
    public string EfectosMenus { get; set; } = "Predeterminado";
    public Dictionary<string, int> UsosComandos { get; set; } = new();

    public MYGConfiguracionGraficoIncidencia Copia() => DesdeJson(AJson());
    public string AJson()
    {
        Validar();
        return JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
    }
    public static MYGConfiguracionGraficoIncidencia DesdeJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json) || json.Length > 1_000_000)
            throw new InvalidDataException("La plantilla de gráfico está vacía o excede el tamaño permitido.");
        var valor = JsonSerializer.Deserialize<MYGConfiguracionGraficoIncidencia>(json)
            ?? throw new InvalidDataException("La plantilla de gráfico no es válida.");
        valor.Validar(); return valor;
    }
    public void Validar()
    {
        if (EfectosMenus is not ("Predeterminado" or "Sin animación" or "Desvanecer") || UsosComandos == null || UsosComandos.Count > 80 ||
            UsosComandos.Any(p => string.IsNullOrWhiteSpace(p.Key) || p.Key.Length > 80 || p.Value < 0 || p.Value > 1_000_000))
            throw new InvalidDataException("Las opciones de menú o los datos de empleo no son válidos.");
        if (!MYGCatalogoGraficosIncidencia.Tipos.Any(t => t.Id == Tipo)) throw new InvalidDataException("Tipo de gráfico desconocido.");
        if (!MYGCatalogoGraficosIncidencia.Paletas.ContainsKey(Paleta ?? "")) throw new InvalidDataException("Paleta de gráfico desconocida.");
        if (Apariencia < 0 || Apariencia > 4 || !float.IsFinite(TamanoFuente) || TamanoFuente < 6 || TamanoFuente > 32 ||
            Angulo < 0 || Angulo > 360 || Inclinacion < 0 || Inclinacion > 75 || Separacion < 0 || Separacion > 40)
            throw new InvalidDataException("La apariencia o las dimensiones del gráfico no son válidas.");
        if (MaximoEje != 0 && MaximoEje <= MinimoEje) throw new InvalidDataException("El máximo del eje debe superar al mínimo (cero indica automático).");
        if ((Titulo?.Length ?? 0) > 300 || (Subtitulo?.Length ?? 0) > 500 || Titulos == null || Titulos.Length > 20 ||
            Titulos.Any(t => t == null || t.Length > 300) || Anotaciones == null || Anotaciones.Count > 50 ||
            Anotaciones.Any(a => a == null || a.Texto == null || a.Texto.Length > 500 || !float.IsFinite(a.X) || !float.IsFinite(a.Y) || a.X < 0 || a.X > 100 || a.Y < 0 || a.Y > 100) ||
            BotonesOcultos == null || BotonesOcultos.Length > 30 || BotonesOcultos.Any(b => b == null || b.Length > 80))
            throw new InvalidDataException("Los títulos, anotaciones o botones de la plantilla no son válidos.");
        ValidarBarrasPersonalizadas();
    }

    public List<MYGBarraGraficoIncidencia> BarrasPersonalizadas { get; set; } = new();

    private void ValidarBarrasPersonalizadas()
    {
        if (BarrasPersonalizadas == null || BarrasPersonalizadas.Count > 8 ||
            BarrasPersonalizadas.Any(b => b == null || string.IsNullOrWhiteSpace(b.Nombre) || b.Nombre.Length > 80 ||
                string.Equals(b.Nombre, "Tipo de gráfico", StringComparison.OrdinalIgnoreCase) ||
                b.Comandos == null || b.Comandos.Length is < 1 or > 40 ||
                b.Comandos.Any(id => string.IsNullOrWhiteSpace(id) || id.Length > 80)))
            throw new InvalidDataException("Las barras personalizadas deben tener un nombre y entre 1 y 40 comandos; se admiten hasta 8 barras.");
        if (BarrasPersonalizadas.Any(b => b.Comandos.Any(id => !ComandoBarraGraficoValido(id)) ||
            b.Comandos.Distinct(StringComparer.Ordinal).Count() != b.Comandos.Length))
            throw new InvalidDataException("Los comandos de las barras personalizadas deben corresponder a herramientas disponibles y no pueden repetirse.");
        if (BarrasPersonalizadas.Select(b => b.Nombre).Distinct(StringComparer.OrdinalIgnoreCase).Count() != BarrasPersonalizadas.Count)
            throw new InvalidDataException("Los nombres de las barras personalizadas deben ser únicos.");
    }

    private static bool ComandoBarraGraficoValido(string id) => id is
        "restaurar" or "cargar" or "guardar" or "exportar" or "asistente" or "columnas" or "lineas" or
        "circular" or "otros" or "paleta" or "previsualizar" or "imprimir" or "apariencia" or
        "barras" or "area" or "propiedades" or "titulos" or "anotaciones" or
        "exportar-pdf" or "exportar-html" or "exportar-mht" or "exportar-xls" or "exportar-xlsx" or
        "exportar-rtf" or "exportar-bmp" or "exportar-gif" or "exportar-jpeg" or "exportar-png" or "exportar-tiff";
}

public sealed class MYGAnotacionGrafico
{
    public string Texto { get; set; } = "Anotación";
    public float X { get; set; } = 50;
    public float Y { get; set; } = 50;
}

public static class MYGCatalogoGraficosIncidencia
{
    public static IReadOnlyList<MYGTipoGraficoIncidencia> Tipos { get; } = CrearTipos().AsReadOnly();
    public static IReadOnlyDictionary<string, string[]> Paletas { get; } = new Dictionary<string, string[]>
    {
        ["Clasica"] = new[] { "#2998E6", "#ED0000", "#008000", "#87CEEB", "#A777C6" },
        ["Azul"] = new[] { "#396791", "#5283AE", "#709FC7", "#92B9DC", "#BDDAEF" },
        ["Roja"] = new[] { "#A02E40", "#BD4656", "#D56470", "#E58D95", "#F0B7BC" },
        ["Verde"] = new[] { "#678B31", "#81A63D", "#A0C35C", "#BFDB82", "#DCEBB7" },
        ["Violeta"] = new[] { "#69498A", "#8963A5", "#A684BF", "#C4A9D7", "#DED0E9" },
        ["Turquesa"] = new[] { "#207F8D", "#3C9AA8", "#65B4BF", "#93D1D8", "#C1E6E9" },
        ["Naranja"] = new[] { "#D07423", "#E7943C", "#EEAD61", "#F5C58D", "#FADDB9" },
        ["Multicolor"] = new[] { "#507EAB", "#B34E61", "#78A04B", "#76558E", "#4F9EAA" }
    };

    private static List<MYGTipoGraficoIncidencia> CrearTipos()
    {
        var lista = new List<MYGTipoGraficoIncidencia>();
        string[] variantes = { "simple", "apilada", "al 100 %", "agrupada", "agrupada apilada", "agrupada al 100 %" };
        void Columnas(string id, string grupo, string forma, bool tresD)
        {
            for (int n = 0; n < 6; n++) lista.Add(new(id + "-" + n, grupo + " · " + (id == "columnas" && n == 5 ? "cascada" : variantes[n]), grupo, "columnas", forma, tresD, n));
        }
        Columnas("columnas", "Columnas 2D", "rectangulo", false);
        Columnas("columnas3d", "Columnas 3D", "rectangulo", true);
        Columnas("cilindro", "Cilindro", "cilindro", true);
        Columnas("cono", "Cono", "cono", true);
        Columnas("piramide", "Pirámide", "piramide", true);
        string[] lineas = { "Línea", "Línea apilada", "Dispersión", "Curva suavizada", "Línea al 100 %", "Línea escalonada" };
        for (int n = 0; n < 6; n++) lista.Add(new("linea-" + n, lineas[n], "Líneas 2D", "lineas", n == 3 ? "curva" : n == 5 ? "escalon" : "linea", false, n));
        string[] lineas3d = { "Línea", "Línea apilada", "Curva suavizada", "Línea al 100 %", "Línea escalonada" };
        for (int n = 0; n < 5; n++) lista.Add(new("linea3d-" + n, lineas3d[n] + " 3D", "Líneas 3D", "lineas", n == 2 ? "curva" : n == 4 ? "escalon" : "linea", true, n));
        foreach (bool d in new[] { false, true })
            for (int n = 0; n < 3; n++) lista.Add(new("area" + (d ? "3d" : "") + "-" + n, "Área " + variantes[n] + (d ? " 3D" : ""), d ? "Áreas 3D" : "Áreas 2D", "area", "area", d, n));
        foreach (bool d in new[] { false, true })
        {
            foreach (string forma in new[] { "tarta", "dona" })
                lista.Add(new(forma + (d ? "3d" : ""), (forma == "dona" ? "Dona" : "Tarta") + (d ? " 3D" : " 2D"), d ? "Tarta 3D" : "Tarta 2D", "circular", forma, d, 0));
            if (!d) lista.Add(new("dona-anidada", "Dona anidada", "Tarta 2D", "circular", "dona-anidada", false, 0));
        }
        foreach (bool d in new[] { false, true })
            lista.Add(new("explosionada" + (d ? "3d" : ""), "Tarta explosionada" + (d ? " 3D" : " 2D"), "Tartas explosionadas", "circular", "explosionada", d, 0));
        lista.Add(new("radar", "Radar", "Otros gráficos", "radar", "linea", false, 0));
        lista.Add(new("radar-area", "Radar de área", "Otros gráficos", "radar", "area", false, 1));
        lista.Add(new("polar", "Polar", "Otros gráficos", "radar", "polar", false, 2));
        return lista;
    }
}

public sealed class MYGBarraGraficoIncidencia
{
    public string Nombre { get; set; } = "";
    public string[] Comandos { get; set; } = Array.Empty<string>();
    public bool Visible { get; set; } = true;
}
