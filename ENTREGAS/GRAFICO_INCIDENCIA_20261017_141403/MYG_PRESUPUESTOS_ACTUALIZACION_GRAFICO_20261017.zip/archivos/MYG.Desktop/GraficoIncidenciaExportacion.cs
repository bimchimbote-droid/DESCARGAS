using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;

namespace MYG_2027;

/// <summary>Exporta la imagen visible y los valores originales; no adquiere la propiedad del bitmap.</summary>
internal static class MYGGraficoIncidenciaExportacion
{
    private static readonly CultureInfo Invariante = CultureInfo.InvariantCulture;
    private static readonly UTF8Encoding Utf8 = new(false);

    internal static void Guardar(string ruta, IReadOnlyList<MYGIncidenciaCosto> datos, string moneda, string titulo, Bitmap imagen)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(ruta);
        ArgumentNullException.ThrowIfNull(datos);
        ArgumentNullException.ThrowIfNull(imagen);
        foreach (var dato in datos) ArgumentNullException.ThrowIfNull(dato);
        string extension = Path.GetExtension(ruta).ToLowerInvariant();
        if (extension is not (".pdf" or ".html" or ".htm" or ".mht" or ".mhtml" or ".xls" or ".xlsx" or ".rtf"
            or ".bmp" or ".gif" or ".jpg" or ".jpeg" or ".png" or ".tif" or ".tiff"))
            throw new ArgumentException("Seleccione PDF, HTML, MHT, XLS, XLSX, RTF, BMP, GIF, JPEG, PNG o TIFF.", nameof(ruta));
        string destino = Path.GetFullPath(ruta);
        string temporal = Path.Combine(Path.GetDirectoryName(destino)!, ".MYG-Incidencia-" + Guid.NewGuid().ToString("N") + extension);
        moneda ??= "";
        titulo = string.IsNullOrWhiteSpace(titulo) ? "Incidencia de costos" : titulo;
        try
        {
            if (extension == ".xls")
                GuardarXls(temporal, datos, moneda, titulo, imagen);
            else
            {
                using var salida = new FileStream(temporal, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                switch (extension)
                {
                    case ".pdf": EscribirPdf(salida, imagen, titulo); break;
                    case ".html": case ".htm":
                        EscribirTexto(salida, Html(datos, moneda, titulo, "data:image/png;base64," + Convert.ToBase64String(Imagen(imagen, ImageFormat.Png)))); break;
                    case ".mht": case ".mhtml": EscribirMht(salida, datos, moneda, titulo, imagen); break;
                    case ".xlsx": EscribirXlsx(salida, datos, moneda, titulo, imagen); break;
                    case ".rtf": EscribirRtf(salida, datos, moneda, titulo, imagen); break;
                    default:
                        imagen.Save(salida, extension switch
                        {
                            ".bmp" => ImageFormat.Bmp,
                            ".gif" => ImageFormat.Gif,
                            ".jpg" or ".jpeg" => ImageFormat.Jpeg,
                            ".tif" or ".tiff" => ImageFormat.Tiff,
                            _ => ImageFormat.Png
                        });
                        break;
                }
            }
            File.Move(temporal, destino, overwrite: true);
        }
        finally { if (File.Exists(temporal)) File.Delete(temporal); }
    }

    private static byte[] Imagen(Bitmap imagen, ImageFormat formato)
    {
        using var contenido = new MemoryStream();
        imagen.Save(contenido, formato);
        return contenido.ToArray();
    }

    private static void EscribirTexto(Stream destino, string contenido)
    {
        byte[] bytes = Utf8.GetBytes(contenido);
        destino.Write(bytes);
    }

    private static string Html(IReadOnlyList<MYGIncidenciaCosto> datos, string moneda, string titulo, string origenImagen)
    {
        var html = new StringBuilder("<!doctype html><html lang=\"es\"><head><meta charset=\"utf-8\"><title>")
            .Append(WebUtility.HtmlEncode(titulo)).Append("</title><style>body{font:14px Arial,sans-serif;margin:24px;color:#172b42}img{max-width:100%;height:auto}table{border-collapse:collapse;margin-top:20px}th,td{border:1px solid #bcc8d4;padding:7px 12px}th{background:#edf2f7}.numero{text-align:right}</style></head><body><h1>")
            .Append(WebUtility.HtmlEncode(titulo)).Append("</h1><img alt=\"Gráfico de incidencia de costos\" src=\"")
            .Append(WebUtility.HtmlEncode(origenImagen)).Append("\"><table><thead><tr><th>Concepto</th><th>Importe</th><th>Incidencia (%)</th><th>Moneda</th></tr></thead><tbody>");
        foreach (var dato in datos)
            html.Append("<tr><td>").Append(WebUtility.HtmlEncode(dato.Nombre ?? ""))
                .Append("</td><td class=\"numero\">").Append(dato.Importe.ToString(Invariante))
                .Append("</td><td class=\"numero\">").Append(dato.Porcentaje.ToString(Invariante))
                .Append("</td><td>").Append(WebUtility.HtmlEncode(moneda)).Append("</td></tr>");
        return html.Append("</tbody></table></body></html>").ToString();
    }

    private static void EscribirMht(Stream destino, IReadOnlyList<MYGIncidenciaCosto> datos, string moneda, string titulo, Bitmap imagen)
    {
        string limite = "MYG_" + Guid.NewGuid().ToString("N");
        const string ubicacion = "http://myg.invalid/incidencia.png";
        // Las dos partes se codifican en base64: conserva Unicode y evita líneas MIME demasiado largas.
        string html = Convert.ToBase64String(Utf8.GetBytes(Html(datos, moneda, titulo, ubicacion)), Base64FormattingOptions.InsertLineBreaks);
        string png = Convert.ToBase64String(Imagen(imagen, ImageFormat.Png), Base64FormattingOptions.InsertLineBreaks);
        EscribirTexto(destino, "MIME-Version: 1.0\r\nContent-Type: multipart/related; type=\"text/html\"; boundary=\"" + limite + "\"\r\n\r\n"
            + "--" + limite + "\r\nContent-Type: text/html; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\nContent-Location: http://myg.invalid/incidencia.html\r\n\r\n" + html + "\r\n"
            + "--" + limite + "\r\nContent-Type: image/png\r\nContent-Transfer-Encoding: base64\r\nContent-Location: " + ubicacion + "\r\n\r\n" + png + "\r\n"
            + "--" + limite + "--\r\n");
    }

    private static void EscribirRtf(Stream destino, IReadOnlyList<MYGIncidenciaCosto> datos, string moneda, string titulo, Bitmap imagen)
    {
        // RTF utiliza escapes UTF-16 (también para los pares suplentes), sin depender de la página de códigos de Windows.
        static string Texto(string texto)
        {
            var r = new StringBuilder();
            foreach (char c in texto ?? "")
            {
                if (c is '\\' or '{' or '}') r.Append('\\').Append(c);
                else if (c == '\n') r.Append("\\line ");
                else if (c == '\r') { }
                else if (c == '\t') r.Append("\\tab ");
                else if (c < 32 || c > 126) r.Append("\\u").Append(unchecked((short)c).ToString(Invariante)).Append('?');
                else r.Append(c);
            }
            return r.ToString();
        }
        var rtf = new StringBuilder("{\\rtf1\\ansi\\deff0\\uc1{\\fonttbl{\\f0 Arial;}}\\paperw16838\\paperh11906\\margl720\\margr720\\margt720\\margb720\\f0\\fs28\\b ")
            .Append(Texto(titulo)).Append("\\b0\\par\\fs20 ");
        double escala = Math.Min(1d, 15000d / (imagen.Width * 15d));
        rtf.Append("{\\pict\\pngblip\\picw").Append(imagen.Width).Append("\\pich").Append(imagen.Height)
            .Append("\\picwgoal").Append((int)Math.Round(imagen.Width * 15 * escala))
            .Append("\\pichgoal").Append((int)Math.Round(imagen.Height * 15 * escala)).Append('\n')
            .Append(Convert.ToHexString(Imagen(imagen, ImageFormat.Png))).Append("}\\par\n");
        void Fila(string concepto, string importe, string porcentaje, string divisa, bool encabezado)
        {
            rtf.Append("\\trowd\\trgaph108\\cellx6500\\cellx10000\\cellx12500\\cellx15000 ");
            foreach (var texto in new[] { concepto, importe, porcentaje, divisa })
                rtf.Append("\\intbl ").Append(encabezado ? "\\b " : "\\b0 ").Append(Texto(texto)).Append("\\cell ");
            rtf.Append("\\row\n");
        }
        Fila("Concepto", "Importe", "Incidencia (%)", "Moneda", true);
        foreach (var dato in datos) Fila(dato.Nombre ?? "", dato.Importe.ToString(Invariante), dato.Porcentaje.ToString(Invariante), moneda, false);
        rtf.Append("\\pard\\b0\\par}");
        EscribirTexto(destino, rtf.ToString());
    }

    private static void EscribirPdf(Stream destino, Bitmap imagen, string titulo)
    {
        byte[] jpeg = Imagen(imagen, ImageFormat.Jpeg);
        // Una página de ancho A4 apaisado o vertical; el gráfico completo cabe manteniendo su proporción.
        double anchoPagina = imagen.Width > imagen.Height ? 842 : 595;
        double altoPagina = imagen.Width > imagen.Height ? 595 : 842;
        double escala = Math.Min((anchoPagina - 48) / imagen.Width, (altoPagina - 48) / imagen.Height);
        double ancho = imagen.Width * escala, alto = imagen.Height * escala;
        string N(double n) => n.ToString("0.###", Invariante);
        string comandos = "q " + N(ancho) + " 0 0 " + N(alto) + " " + N((anchoPagina - ancho) / 2) + " " + N((altoPagina - alto) / 2) + " cm /Im0 Do Q\n";
        var offsets = new List<long> { 0 };
        void Texto(string texto) => destino.Write(Encoding.ASCII.GetBytes(texto));
        void Objeto(int numero, string cuerpo)
        {
            offsets.Add(destino.Position); Texto(numero + " 0 obj\n" + cuerpo + "\nendobj\n");
        }
        Texto("%PDF-1.4\n%MYG\n");
        Objeto(1, "<< /Type /Catalog /Pages 2 0 R >>");
        Objeto(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        Objeto(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + N(anchoPagina) + " " + N(altoPagina) + "] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>");
        offsets.Add(destino.Position);
        Texto("4 0 obj\n<< /Type /XObject /Subtype /Image /Width " + imagen.Width + " /Height " + imagen.Height
            + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + jpeg.Length + " >>\nstream\n");
        destino.Write(jpeg); Texto("\nendstream\nendobj\n");
        Objeto(5, "<< /Length " + Encoding.ASCII.GetByteCount(comandos) + " >>\nstream\n" + comandos + "endstream");
        Objeto(6, "<< /Title <FEFF" + Convert.ToHexString(Encoding.BigEndianUnicode.GetBytes(titulo)) + "> /Producer (MYG Presupuestos) >>");
        long xref = destino.Position;
        Texto("xref\n0 " + offsets.Count + "\n0000000000 65535 f \n");
        for (int n = 1; n < offsets.Count; n++) Texto(offsets[n].ToString("0000000000", Invariante) + " 00000 n \n");
        Texto("trailer\n<< /Size " + offsets.Count + " /Root 1 0 R /Info 6 0 R >>\nstartxref\n" + xref.ToString(Invariante) + "\n%%EOF\n");
    }

    private static void EscribirXlsx(Stream destino, IReadOnlyList<MYGIncidenciaCosto> datos, string moneda, string titulo, Bitmap imagen)
    {
        const string s = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        const string r = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        const string a = "http://schemas.openxmlformats.org/drawingml/2006/main";
        const string xdr = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
        using var zip = new ZipArchive(destino, ZipArchiveMode.Create, leaveOpen: true);
        void Xml(string ruta, Action<XmlWriter> escribir)
        {
            using var archivo = zip.CreateEntry(ruta, CompressionLevel.Optimal).Open();
            using var xml = XmlWriter.Create(archivo, new XmlWriterSettings { Encoding = Utf8, CloseOutput = false });
            xml.WriteStartDocument(); escribir(xml); xml.WriteEndDocument();
        }
        void Parte(string ruta, string contenido)
        {
            using var archivo = zip.CreateEntry(ruta, CompressionLevel.Optimal).Open();
            EscribirTexto(archivo, "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + contenido);
        }
        Parte("[Content_Types].xml", "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"png\" ContentType=\"image/png\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/><Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/></Types>");
        Parte("_rels/.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + r + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        Parte("xl/workbook.xml", "<workbook xmlns=\"" + s + "\" xmlns:r=\"" + r + "\"><sheets><sheet name=\"Incidencia de costos\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
        Parte("xl/_rels/workbook.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + r + "/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"" + r + "/styles\" Target=\"styles.xml\"/></Relationships>");
        Parte("xl/styles.xml", "<styleSheet xmlns=\"" + s + "\"><numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00##############\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><name val=\"Arial\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"4\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"10\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        Xml("xl/worksheets/sheet1.xml", x =>
        {
            x.WriteStartElement("worksheet", s); x.WriteAttributeString("xmlns", "r", null, r);
            x.WriteStartElement("cols", s);
            foreach (var columna in new[] { (1, 48), (2, 25), (3, 20), (4, 15) })
            {
                x.WriteStartElement("col", s); x.WriteAttributeString("min", columna.Item1.ToString(Invariante)); x.WriteAttributeString("max", columna.Item1.ToString(Invariante));
                x.WriteAttributeString("width", columna.Item2.ToString(Invariante)); x.WriteAttributeString("customWidth", "1"); x.WriteEndElement();
            }
            x.WriteEndElement(); x.WriteStartElement("sheetData", s);
            void Celda(string referencia, string valor, int estilo, bool numero = false)
            {
                x.WriteStartElement("c", s); x.WriteAttributeString("r", referencia); x.WriteAttributeString("s", estilo.ToString(Invariante));
                if (numero) x.WriteElementString("v", s, valor);
                else
                {
                    x.WriteAttributeString("t", "inlineStr"); x.WriteStartElement("is", s); x.WriteStartElement("t", s);
                    x.WriteAttributeString("xml", "space", "http://www.w3.org/XML/1998/namespace", "preserve");
                    x.WriteString(valor); x.WriteEndElement(); x.WriteEndElement();
                }
                x.WriteEndElement();
            }
            x.WriteStartElement("row", s); x.WriteAttributeString("r", "1"); Celda("A1", titulo, 3); x.WriteEndElement();
            x.WriteStartElement("row", s); x.WriteAttributeString("r", "3");
            Celda("A3", "Concepto", 3); Celda("B3", "Importe", 3); Celda("C3", "Incidencia (%)", 3); Celda("D3", "Moneda", 3); x.WriteEndElement();
            for (int i = 0; i < datos.Count; i++)
            {
                string fila = (i + 4).ToString(Invariante); var dato = datos[i];
                x.WriteStartElement("row", s); x.WriteAttributeString("r", fila);
                Celda("A" + fila, dato.Nombre ?? "", 0); Celda("B" + fila, dato.Importe.ToString(Invariante), 1, true);
                Celda("C" + fila, (dato.Porcentaje / 100m).ToString(Invariante), 2, true); Celda("D" + fila, moneda, 0);
                x.WriteEndElement();
            }
            x.WriteEndElement();
            x.WriteStartElement("drawing", s); x.WriteAttributeString("r", "id", r, "rId1"); x.WriteEndElement(); x.WriteEndElement();
        });
        Parte("xl/worksheets/_rels/sheet1.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + r + "/drawing\" Target=\"../drawings/drawing1.xml\"/></Relationships>");
        double escala = Math.Min(1d, 1100d / imagen.Width);
        long anchoEmu = (long)Math.Round(imagen.Width * escala * 9525), altoEmu = (long)Math.Round(imagen.Height * escala * 9525);
        Xml("xl/drawings/drawing1.xml", x =>
        {
            x.WriteStartElement("xdr", "wsDr", xdr); x.WriteAttributeString("xmlns", "a", null, a);
            x.WriteStartElement("xdr", "oneCellAnchor", xdr);
            x.WriteStartElement("xdr", "from", xdr);
            x.WriteElementString("xdr", "col", xdr, "0"); x.WriteElementString("xdr", "colOff", xdr, "0");
            x.WriteElementString("xdr", "row", xdr, (datos.Count + 5).ToString(Invariante)); x.WriteElementString("xdr", "rowOff", xdr, "0"); x.WriteEndElement();
            x.WriteStartElement("xdr", "ext", xdr); x.WriteAttributeString("cx", anchoEmu.ToString(Invariante)); x.WriteAttributeString("cy", altoEmu.ToString(Invariante)); x.WriteEndElement();
            x.WriteStartElement("xdr", "pic", xdr);
            x.WriteStartElement("xdr", "nvPicPr", xdr);
            x.WriteStartElement("xdr", "cNvPr", xdr); x.WriteAttributeString("id", "1"); x.WriteAttributeString("name", "Gráfico de incidencia de costos"); x.WriteAttributeString("descr", titulo); x.WriteEndElement();
            x.WriteStartElement("xdr", "cNvPicPr", xdr); x.WriteEndElement(); x.WriteEndElement();
            x.WriteStartElement("xdr", "blipFill", xdr);
            x.WriteStartElement("a", "blip", a); x.WriteAttributeString("r", "embed", r, "rId1"); x.WriteEndElement();
            x.WriteStartElement("a", "stretch", a); x.WriteStartElement("a", "fillRect", a); x.WriteEndElement(); x.WriteEndElement(); x.WriteEndElement();
            x.WriteStartElement("xdr", "spPr", xdr);
            x.WriteStartElement("a", "xfrm", a);
            x.WriteStartElement("a", "off", a); x.WriteAttributeString("x", "0"); x.WriteAttributeString("y", "0"); x.WriteEndElement();
            x.WriteStartElement("a", "ext", a); x.WriteAttributeString("cx", anchoEmu.ToString(Invariante)); x.WriteAttributeString("cy", altoEmu.ToString(Invariante)); x.WriteEndElement(); x.WriteEndElement();
            x.WriteStartElement("a", "prstGeom", a); x.WriteAttributeString("prst", "rect"); x.WriteStartElement("a", "avLst", a); x.WriteEndElement(); x.WriteEndElement();
            x.WriteEndElement(); x.WriteEndElement();
            x.WriteStartElement("xdr", "clientData", xdr); x.WriteEndElement(); x.WriteEndElement(); x.WriteEndElement();
        });
        Parte("xl/drawings/_rels/drawing1.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + r + "/image\" Target=\"../media/incidencia.png\"/></Relationships>");
        using var png = zip.CreateEntry("xl/media/incidencia.png", CompressionLevel.Optimal).Open();
        imagen.Save(png, ImageFormat.Png);
    }

    private static void GuardarXls(string destino, IReadOnlyList<MYGIncidenciaCosto> datos, string moneda, string titulo, Bitmap imagen)
    {
        const string requisito = "Para exportar XLS (Excel 97-2003) se necesita Microsoft Excel instalado en Windows. Exporte XLSX para guardar el gráfico y sus datos sin instalar Excel.";
        if (datos.Count > 65530) throw new InvalidOperationException("XLS admite hasta 65 536 filas por hoja. Exporte XLSX para conservar todos los datos.");
        if (!OperatingSystem.IsWindows()) throw new InvalidOperationException(requisito);
        Type tipo = Type.GetTypeFromProgID("Excel.Application");
        if (tipo == null) throw new InvalidOperationException(requisito);
        string origen = Path.Combine(Path.GetTempPath(), "MYG-Incidencia-" + Guid.NewGuid().ToString("N") + ".xlsx");
        object aplicacion = null, libros = null, libro = null;
        void Liberar(ref object objeto)
        {
            if (objeto != null && Marshal.IsComObject(objeto))
                try { Marshal.FinalReleaseComObject(objeto); } catch (InvalidComObjectException) { }
            objeto = null;
        }
        void Cerrar()
        {
            if (libro != null) try { ((dynamic)libro).Close(SaveChanges: false); } catch (Exception) { }
            Liberar(ref libro); Liberar(ref libros);
            if (aplicacion != null) try { ((dynamic)aplicacion).Quit(); } catch (Exception) { }
            Liberar(ref aplicacion);
        }
        try
        {
            using (var salida = File.Create(origen)) EscribirXlsx(salida, datos, moneda, titulo, imagen);
            try { aplicacion = Activator.CreateInstance(tipo); }
            catch (COMException ex) when (ex.HResult == unchecked((int)0x80040154)) { throw new InvalidOperationException(requisito, ex); }
            dynamic excel = aplicacion;
            excel.Visible = false; excel.DisplayAlerts = false; excel.EnableEvents = false; excel.AutomationSecurity = 3;
            libros = excel.Workbooks;
            libro = ((dynamic)libros).Open(Filename: origen, UpdateLinks: 0, ReadOnly: true, IgnoreReadOnlyRecommended: true, AddToMru: false);
            ((dynamic)libro).CheckCompatibility = false;
            ((dynamic)libro).SaveAs(Filename: destino, FileFormat: 56, CreateBackup: false, AddToMru: false);
            Cerrar();
            using var convertido = File.OpenRead(destino);
            Span<byte> firma = stackalloc byte[8];
            if (convertido.Read(firma) != 8 || !firma.SequenceEqual(new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 }))
                throw new IOException("Excel no generó un libro XLS válido. Exporte el gráfico como XLSX.");
        }
        finally
        {
            Cerrar();
            if (File.Exists(origen)) File.Delete(origen);
        }
    }
}
