using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;

namespace MYG_2027;

/// <summary>Imágenes propias de la barra y sus galerías. El llamador libera cada bitmap devuelto.</summary>
internal static class MYGIconosGraficoIncidencia
{
    private static readonly Color Azul = Color.FromArgb(65, 126, 185);
    private static readonly Color AzulOscuro = Color.FromArgb(62, 91, 139);
    private static readonly Color Naranja = Color.FromArgb(239, 169, 40);
    private static readonly Color Rojo = Color.FromArgb(201, 61, 83);
    private static readonly Color Verde = Color.FromArgb(73, 164, 78);
    private static readonly Color Borde = Color.FromArgb(111, 125, 141);
    private static readonly Color[] Colores = { Azul, Rojo, Color.FromArgb(132, 171, 70), Color.FromArgb(75, 172, 183), Color.FromArgb(144, 110, 171) };

    internal static Bitmap Crear(string clave, int lado = 24)
    {
        if (lado <= 0) throw new ArgumentOutOfRangeException(nameof(lado));
        var imagen = new Bitmap(lado, lado, PixelFormat.Format32bppPArgb);
        using var g = Graphics.FromImage(imagen);
        Preparar(g);
        g.Clear(Color.Transparent);
        g.ScaleTransform(lado / 24f, lado / 24f);
        switch ((clave ?? "").ToLowerInvariant())
        {
            case "restaurar":
                using (var p = new Pen(Verde, 2.6f)) g.DrawArc(p, 4.3f, 4.5f, 14.5f, 14.5f, 215, 295);
                Poligono(g, Verde, new(2, 5), new(9, 5), new(3.6f, 10));
                break;
            case "cargar":
                Poligono(g, Color.FromArgb(227, 161, 35), new(2, 6), new(9, 6), new(11, 8), new(21, 8), new(20, 19), new(2, 19));
                Poligono(g, Color.FromArgb(255, 214, 103), new(2, 10), new(22, 10), new(19, 19), new(2, 19));
                Linea(g, Color.FromArgb(199, 140, 36), 1, new(2, 19), new(19, 19), new(22, 10));
                break;
            case "guardar": Disquete(g, 3, 3); break;
            case "exportar":
                Disquete(g, 2, 5, .87f);
                Rectangulo(g, Color.White, 12, 2, 11, 9);
                Linea(g, Verde, 2.4f, new(13, 6), new(20, 6));
                Poligono(g, Verde, new(18, 2), new(23, 6), new(18, 10));
                break;
            case "asistente":
                ColumnasIcono(g);
                Poligono(g, Naranja, new(10, 21), new(22, 9), new(22, 21));
                Poligono(g, Color.FromArgb(255, 240, 171), new(16, 19), new(20, 15), new(20, 19));
                Linea(g, Color.FromArgb(193, 128, 21), .7f, new(13, 20), new(13, 19));
                Linea(g, Color.FromArgb(193, 128, 21), .7f, new(16, 17), new(16, 16));
                break;
            case "columnas": ColumnasIcono(g); break;
            case "lineas":
                Linea(g, Azul, 1.4f, new(3, 15), new(9, 7), new(15, 13), new(21, 5));
                Linea(g, Rojo, 1.4f, new(3, 5), new(9, 10), new(15, 8), new(21, 11));
                Linea(g, Naranja, 1.4f, new(3, 19), new(9, 16), new(15, 19), new(21, 15));
                foreach (var punto in new[] { new PointF(3, 15), new PointF(9, 7), new PointF(15, 13), new PointF(21, 5) }) Nodo(g, punto, Azul);
                foreach (var punto in new[] { new PointF(3, 5), new PointF(9, 10), new PointF(15, 8), new PointF(21, 11) }) Nodo(g, punto, Rojo);
                foreach (var punto in new[] { new PointF(3, 19), new PointF(9, 16), new PointF(15, 19), new PointF(21, 15) }) Nodo(g, punto, Naranja);
                break;
            case "circular":
                Sector(g, Rojo, new(2, 2, 19, 19), 105, 205);
                Sector(g, Azul, new(2, 2, 19, 19), 310, 100);
                Sector(g, Naranja, new(3, 3, 19, 19), 50, 55);
                break;
            case "otros":
                Sector(g, Rojo, new(2, 2, 20, 20), 110, 185);
                Sector(g, Azul, new(2, 2, 20, 20), 295, 100);
                Sector(g, Naranja, new(2, 2, 20, 20), 35, 75);
                Elipse(g, Color.White, 8, 8, 8, 8);
                break;
            case "paleta":
                Color[] rueda = { Azul, Color.FromArgb(89, 174, 196), Color.FromArgb(137, 184, 72), Naranja, Rojo, Color.FromArgb(158, 111, 181) };
                for (int n = 0; n < rueda.Length; n++) Sector(g, rueda[n], new(3, 3, 18, 18), n * 60 - 90, 60);
                using (var p = new Pen(Borde, 1)) g.DrawEllipse(p, 2, 2, 20, 20);
                Elipse(g, Color.White, 9.5f, 9.5f, 5, 5);
                break;
            case "previsualizar":
                Hoja(g, 3, 2, 15, 19);
                Rectangulo(g, Azul, 6, 10, 2.5f, 7);
                Rectangulo(g, Naranja, 9.5f, 6, 2.5f, 11);
                Rectangulo(g, Verde, 13, 8, 2, 9);
                Elipse(g, Color.FromArgb(225, 246, 229), 13.5f, 11.5f, 6, 6);
                using (var p = new Pen(Verde, 1.5f)) g.DrawEllipse(p, 13.5f, 11.5f, 6, 6);
                Linea(g, Verde, 2, new(18.8f, 17), new(22, 21));
                break;
            case "imprimir":
                Hoja(g, 6, 2, 11, 9);
                Rectangulo(g, Color.FromArgb(192, 203, 216), 3, 9, 18, 10);
                Marco(g, Borde, 3, 9, 18, 10);
                Rectangulo(g, Color.FromArgb(242, 245, 249), 7, 14, 10, 8);
                Marco(g, AzulOscuro, 7, 14, 10, 8);
                Linea(g, Borde, 1, new(9, 17), new(15, 17));
                Linea(g, Borde, 1, new(9, 19), new(15, 19));
                Elipse(g, Color.White, 16, 1, 7, 7);
                using (var p = new Pen(Verde, 1)) g.DrawEllipse(p, 16, 1, 7, 7);
                Linea(g, Verde, 1.1f, new(17.5f, 4.5f), new(19, 6), new(21, 3));
                break;
            case "apariencia":
                Poligono(g, AzulOscuro, new(4, 12), new(11, 5), new(14, 8), new(7, 15));
                Poligono(g, Color.FromArgb(112, 156, 200), new(9, 17), new(17, 9), new(20, 12), new(12, 20));
                Linea(g, Azul, 2.3f, new(13, 7), new(16, 4), new(19, 7));
                Poligono(g, Color.FromArgb(181, 203, 224), new(4, 12), new(7, 15), new(3, 16));
                break;
            case "barras":
                Rectangulo(g, Naranja, 4, 4, 16, 5);
                Rectangulo(g, Rojo, 4, 11, 11, 5);
                Rectangulo(g, Azul, 4, 18, 7, 3);
                Linea(g, Borde, .8f, new(2, 3), new(2, 22), new(22, 22));
                break;
            case "area":
                Poligono(g, Naranja, new(3, 20), new(3, 14), new(8, 7), new(14, 10), new(21, 3), new(21, 20));
                Poligono(g, Color.FromArgb(103, 175, 215), new(3, 20), new(3, 17), new(9, 10), new(14, 15), new(21, 9), new(21, 20));
                Linea(g, AzulOscuro, .8f, new(3, 17), new(9, 10), new(14, 15), new(21, 9));
                Linea(g, Borde, .8f, new(2, 2), new(2, 21), new(22, 21));
                break;
            case "propiedades":
                Hoja(g, 3, 2, 17, 20);
                for (int n = 0; n < 3; n++)
                {
                    Rectangulo(g, n == 1 ? Naranja : Azul, 6, 6 + n * 5, 3, 3);
                    Linea(g, Borde, 1, new(11, 7.5f + n * 5), new(17, 7.5f + n * 5));
                }
                break;
            case "anotaciones":
                Rectangulo(g, Color.FromArgb(255, 245, 191), 2, 3, 20, 14);
                Marco(g, Color.FromArgb(196, 158, 59), 2, 3, 20, 14);
                Poligono(g, Color.FromArgb(255, 245, 191), new(6, 16), new(6, 22), new(12, 16));
                Linea(g, Color.FromArgb(196, 158, 59), 1, new(6, 17), new(6, 22), new(12, 17));
                Linea(g, Borde, 1, new(6, 7), new(18, 7));
                Linea(g, Borde, 1, new(6, 11), new(16, 11));
                break;
            case "titulos":
                Rectangulo(g, Color.FromArgb(236, 242, 250), 2, 3, 20, 18);
                Marco(g, Borde, 2, 3, 20, 18);
                Rectangulo(g, AzulOscuro, 6, 6, 12, 2);
                Rectangulo(g, AzulOscuro, 11, 6, 2, 11);
                Rectangulo(g, AzulOscuro, 8, 16, 8, 1.5f);
                break;
            case "personalizar":
                Rectangulo(g, Color.FromArgb(230, 236, 244), 2, 3, 20, 8);
                Marco(g, Borde, 2, 3, 20, 8);
                Rectangulo(g, Azul, 5, 5, 3, 4);
                Rectangulo(g, Naranja, 10, 5, 3, 4);
                Rectangulo(g, Verde, 15, 5, 3, 4);
                Linea(g, Borde, 3.5f, new(7, 21), new(17, 11));
                using (var p = new Pen(Borde, 2.6f)) g.DrawArc(p, 15, 8, 7, 7, 35, 270);
                Elipse(g, Color.White, 5.5f, 19.5f, 2, 2);
                break;
            default:
                if (clave?.StartsWith("exportar-", StringComparison.OrdinalIgnoreCase) == true)
                    Formato(g, clave[9..]);
                else ColumnasIcono(g);
                break;
        }
        return imagen;
    }

    internal static Bitmap Miniatura(MYGTipoGraficoIncidencia tipo, int ancho = 90, int alto = 60)
    {
        ArgumentNullException.ThrowIfNull(tipo);
        if (ancho <= 0) throw new ArgumentOutOfRangeException(nameof(ancho));
        if (alto <= 0) throw new ArgumentOutOfRangeException(nameof(alto));
        var imagen = new Bitmap(ancho, alto, PixelFormat.Format32bppPArgb);
        using var g = Graphics.FromImage(imagen);
        Preparar(g);
        g.Clear(Color.White);
        g.ScaleTransform(ancho / 90f, alto / 60f);
        switch (tipo.Familia)
        {
            case "circular": Circular(g, tipo); break;
            case "radar": Radar(g, tipo); break;
            case "lineas": Ejes(g, tipo.TresDimensiones); Lineas(g, tipo); break;
            case "area": Ejes(g, tipo.TresDimensiones); Area(g, tipo); break;
            default: Ejes(g, tipo.TresDimensiones); Columnas(g, tipo); break;
        }
        return imagen;
    }

    internal static Bitmap Estilo(string paleta, int apariencia, int ancho = 78, int alto = 54)
    {
        if (ancho <= 0) throw new ArgumentOutOfRangeException(nameof(ancho));
        if (alto <= 0) throw new ArgumentOutOfRangeException(nameof(alto));
        if (!MYGCatalogoGraficosIncidencia.Paletas.TryGetValue(paleta ?? "", out var colores))
            colores = MYGCatalogoGraficosIncidencia.Paletas["Clasica"];
        var imagen = new Bitmap(ancho, alto, PixelFormat.Format32bppPArgb);
        using var g = Graphics.FromImage(imagen);
        Preparar(g);
        g.ScaleTransform(ancho / 78f, alto / 54f);
        bool oscuro = apariencia is 2 or 3;
        g.Clear(oscuro ? Color.Black : Color.White);
        var marco = new RectangleF(.7f, .7f, 76.6f, 52.6f);
        using (var p = new Pen(oscuro ? Color.Black : Color.FromArgb(166, 166, 166), 1)) g.DrawRectangle(p, marco.X, marco.Y, marco.Width, marco.Height);
        // La muestra conserva un círculo incluso en la galería de paletas, que usa botones más anchos.
        float escala = Math.Min(ancho / 78f, alto / 54f);
        float diametroX = 44 * escala / (ancho / 78f), diametroY = 44 * escala / (alto / 54f);
        var rect = new RectangleF(39 - diametroX / 2, 27 - diametroY / 2, diametroX, diametroY);
        float inicio = -90;
        float[] porciones = { 55, 18, 13, 8, 6 };
        for (int n = 0; n < porciones.Length; n++)
        {
            float barrido = porciones[n] * 3.6f;
            Color color = ColorTranslator.FromHtml(colores[n % colores.Length]);
            using Brush relleno = apariencia is 0 or 1
                ? new LinearGradientBrush(rect, Mezclar(color, Color.White, apariencia == 0 ? .12f : .18f), Mezclar(color, Color.Black, .18f), apariencia == 0 ? 45f : 90f)
                : new SolidBrush(color);
            g.FillPie(relleno, rect.X, rect.Y, rect.Width, rect.Height, inicio, barrido);
            if (apariencia is 2 or 3 or 4)
            {
                using var p = new Pen(apariencia == 2 ? Color.Black : apariencia == 3 ? Color.White : Color.FromArgb(220, 230, 238), .9f);
                g.DrawPie(p, rect.X, rect.Y, rect.Width, rect.Height, inicio, barrido);
            }
            inicio += barrido;
        }
        return imagen;
    }

    private static void Columnas(Graphics g, MYGTipoGraficoIncidencia tipo)
    {
        if (tipo.Id == "columnas-5")
        {
            float[] valores = { 18, 12, -9, 15, -6 };
            float acumulado = 0;
            for (int n = 0; n < valores.Length; n++)
            {
                float siguiente = acumulado + valores[n];
                float y = 49 - Math.Max(acumulado, siguiente);
                Columna(g, tipo, 13 + n * 13, y, 9, Math.Abs(valores[n]), valores[n] > 0 ? Azul : Rojo);
                if (n < valores.Length - 1)
                {
                    using var p = new Pen(Borde, .6f) { DashStyle = DashStyle.Dot };
                    g.DrawLine(p, 22 + n * 13, 49 - siguiente, 26 + n * 13, 49 - siguiente);
                }
                acumulado = siguiente;
            }
            return;
        }
        bool apilado = tipo.Variante is 1 or 2 or 4 or 5;
        bool porcentaje = tipo.Variante is 2 or 5;
        bool agrupado = tipo.Variante is 3 or 4 or 5;
        if (apilado)
        {
            int cantidad = agrupado ? 6 : 4;
            for (int n = 0; n < cantidad; n++)
            {
                float x = 12 + n * (agrupado ? 11 : 17);
                float[] partes = { 9 + n % 3 * 2, 6 + (n + 1) % 3 * 2, 7 + n % 2 * 5 };
                float factor = porcentaje ? 36 / partes.Sum() : 1;
                float y = 49;
                for (int c = 0; c < partes.Length; c++)
                {
                    float h = partes[c] * factor;
                    y -= h;
                    Columna(g, tipo, x, y, agrupado ? 7 : 11, h, Colores[c]);
                }
            }
        }
        else if (agrupado)
        {
            for (int grupo = 0; grupo < 3; grupo++)
                for (int n = 0; n < 3; n++)
                {
                    float h = 15 + (grupo * 7 + n * 11) % 24;
                    Columna(g, tipo, 11 + grupo * 24 + n * 6, 49 - h, 4.6f, h, Colores[n]);
                }
        }
        else
        {
            float[] alturas = { 25, 37, 17, 30 };
            for (int n = 0; n < alturas.Length; n++)
                Columna(g, tipo, 13 + n * 17, 49 - alturas[n], 10, alturas[n], Colores[n]);
        }
    }

    private static void Columna(Graphics g, MYGTipoGraficoIncidencia tipo, float x, float y, float w, float h, Color color)
    {
        var frente = new RectangleF(x, y, w, Math.Max(.5f, h));
        switch (tipo.Forma)
        {
            case "cilindro":
                using (var b = new LinearGradientBrush(frente, Mezclar(color, Color.White, .35f), Mezclar(color, Color.Black, .2f), 0f))
                    g.FillRectangle(b, frente);
                Elipse(g, Mezclar(color, Color.Black, .12f), x, y + h - 2, w, 4);
                Elipse(g, Mezclar(color, Color.White, .3f), x, y - 2, w, 4);
                break;
            case "cono":
                Poligono(g, color, new(x + w / 2, y), new(x, y + h), new(x + w, y + h));
                Poligono(g, Mezclar(color, Color.Black, .2f), new(x + w / 2, y), new(x + w / 2, y + h), new(x + w, y + h));
                Elipse(g, color, x, y + h - 2, w, 4);
                break;
            case "piramide":
                Poligono(g, color, new(x + w / 2, y), new(x - 1, y + h - 1), new(x + w / 2, y + h + 2));
                Poligono(g, Mezclar(color, Color.Black, .25f), new(x + w / 2, y), new(x + w / 2, y + h + 2), new(x + w + 2, y + h - 1));
                break;
            default:
                if (tipo.TresDimensiones)
                {
                    Poligono(g, Mezclar(color, Color.Black, .22f), new(x + w, y), new(x + w + 3, y - 3), new(x + w + 3, y + h - 3), new(x + w, y + h));
                    Poligono(g, Mezclar(color, Color.White, .28f), new(x, y), new(x + 3, y - 3), new(x + w + 3, y - 3), new(x + w, y));
                }
                Rectangulo(g, color, x, y, w, h);
                break;
        }
    }

    private static void Lineas(Graphics g, MYGTipoGraficoIncidencia tipo)
    {
        bool porcentaje = tipo.Id is "linea-4" or "linea3d-3";
        float[][] valores = Enumerable.Range(0, 3).Select(s => Enumerable.Range(0, 6).Select(n => (float)(6 + (n * 7 + s * 11) % 15)).ToArray()).ToArray();
        float[] totales = Enumerable.Range(0, 6).Select(n => valores.Sum(v => v[n])).ToArray();
        for (int serie = 0; serie < 3; serie++)
        {
            var puntos = Enumerable.Range(0, 6).Select(n => new PointF(11 + n * 13, 43 - ((n * 11 + serie * 17) % 29) - serie * 2)).ToArray();
            if (tipo.Variante == 1 || porcentaje)
                for (int n = 0; n < puntos.Length; n++)
                    puntos[n].Y = 49 - 36 * valores.Take(serie + 1).Sum(v => v[n]) / (porcentaje ? totales[n] : totales.Max());
            Color color = Colores[serie];
            using var p = new Pen(color, tipo.TresDimensiones ? 2.4f : 1.5f) { LineJoin = LineJoin.Round };
            if (tipo.Forma == "curva") g.DrawCurve(p, puntos, .45f);
            else if (tipo.Forma == "escalon")
            {
                for (int n = 1; n < puntos.Length; n++)
                    g.DrawLines(p, new[] { puntos[n - 1], new PointF(puntos[n].X, puntos[n - 1].Y), puntos[n] });
            }
            else if (tipo.Id != "linea-2") g.DrawLines(p, puntos);
            foreach (var punto in puntos) Elipse(g, color, punto.X - 1.6f, punto.Y - 1.6f, 3.2f, 3.2f);
        }
    }

    private static void Area(Graphics g, MYGTipoGraficoIncidencia tipo)
    {
        if (tipo.Variante is 1 or 2)
        {
            float[][] valores = Enumerable.Range(0, 3)
                .Select(s => Enumerable.Range(0, 6).Select(n => (float)(6 + (n * 3 + s * 7) % 9)).ToArray()).ToArray();
            float[] totales = Enumerable.Range(0, 6).Select(n => valores.Sum(v => v[n])).ToArray();
            float maximo = totales.Max();
            float[] acumulado = new float[6];
            for (int serie = 0; serie < 3; serie++)
            {
                var superiores = new PointF[6];
                var inferiores = new PointF[6];
                for (int n = 0; n < 6; n++)
                {
                    float factor = 36 / (tipo.Variante == 2 ? totales[n] : maximo);
                    inferiores[n] = new(11 + n * 13, 49 - acumulado[n]);
                    acumulado[n] += valores[serie][n] * factor;
                    superiores[n] = new(11 + n * 13, 49 - acumulado[n]);
                }
                Poligono(g, Colores[serie], superiores.Concat(inferiores.Reverse()).ToArray());
                using var p = new Pen(Mezclar(Colores[serie], Color.Black, .2f), tipo.TresDimensiones ? 1.8f : .8f);
                g.DrawLines(p, superiores);
            }
            return;
        }
        for (int serie = 2; serie >= 0; serie--)
        {
            float baseY = 49;
            var puntos = new PointF[8];
            puntos[0] = new(11, baseY);
            for (int n = 0; n < 6; n++)
            {
                float altura = 8 + serie * 7 + (n * 9 + serie * 4) % 15;
                puntos[n + 1] = new(11 + n * 13, baseY - altura);
            }
            puntos[^1] = new(76, baseY);
            Color color = Mezclar(Colores[serie], Color.White, .12f);
            Poligono(g, color, puntos);
            using var p = new Pen(Mezclar(color, Color.Black, .2f), tipo.TresDimensiones ? 1.8f : .8f);
            g.DrawLines(p, puntos.Skip(1).Take(6).ToArray());
        }
    }

    private static void Circular(Graphics g, MYGTipoGraficoIncidencia tipo)
    {
        if (tipo.Forma == "dona-anidada")
        {
            float[] incidencias = { 44, 29, 17, 10 };
            for (int n = 0; n < incidencias.Length; n++)
            {
                float radio = 23 - n * 5;
                var anillo = new RectangleF(45 - radio, 30 - radio, 2 * radio, 2 * radio);
                using var baseAnillo = new Pen(Color.FromArgb(225, 230, 235), 3.6f);
                using var porcion = new Pen(Colores[n], 3.6f);
                g.DrawEllipse(baseAnillo, anillo);
                g.DrawArc(porcion, anillo, -90, incidencias[n] * 3.6f);
            }
            return;
        }
        float alto = tipo.TresDimensiones ? 32 : 43;
        var rect = new RectangleF(20, tipo.TresDimensiones ? 11 : 8, 50, alto);
        float inicio = -90;
        float[] porciones = { 44, 29, 17, 10 };
        if (tipo.TresDimensiones)
        {
            for (int n = 0; n < porciones.Length; n++)
            {
                var parte = Desplazar(rect, inicio, porciones[n] * 3.6f, tipo.Forma == "explosionada" ? 4 : 0);
                parte.Y += 6;
                Sector(g, Mezclar(Colores[n], Color.Black, .28f), parte, inicio, porciones[n] * 3.6f, false);
                inicio += porciones[n] * 3.6f;
            }
        }
        inicio = -90;
        for (int n = 0; n < porciones.Length; n++)
        {
            float barrido = porciones[n] * 3.6f;
            var parte = Desplazar(rect, inicio, barrido, tipo.Forma == "explosionada" ? 4 : 0);
            Sector(g, Colores[n], parte, inicio, barrido);
            inicio += barrido;
        }
        if (tipo.Forma == "dona")
        {
            Elipse(g, tipo.TresDimensiones ? Color.FromArgb(218, 225, 232) : Color.White, 34, rect.Y + alto * .3f, 22, alto * .4f);
            if (tipo.TresDimensiones) Elipse(g, Color.White, 34, rect.Y + alto * .3f, 22, alto * .31f);
        }
    }

    private static RectangleF Desplazar(RectangleF rect, float inicio, float barrido, float distancia)
    {
        double angulo = (inicio + barrido / 2) * Math.PI / 180;
        rect.Offset((float)Math.Cos(angulo) * distancia, (float)Math.Sin(angulo) * distancia);
        return rect;
    }

    private static void Radar(Graphics g, MYGTipoGraficoIncidencia tipo)
    {
        PointF centro = new(45, 30);
        PointF[] Anillo(float radio) => Enumerable.Range(0, 6).Select(n => Polar(centro, radio, n * 60 - 90)).ToArray();
        using var rejilla = new Pen(Color.FromArgb(210, 217, 225), .7f);
        foreach (float r in new[] { 9f, 17f, 25f })
            if (tipo.Forma == "polar") g.DrawEllipse(rejilla, centro.X - r, centro.Y - r, r * 2, r * 2);
            else g.DrawPolygon(rejilla, Anillo(r));
        foreach (var punto in Anillo(25)) g.DrawLine(rejilla, centro, punto);
        for (int serie = 0; serie < 2; serie++)
        {
            var puntos = Enumerable.Range(0, 6).Select(n => Polar(centro, 11 + (n * 7 + serie * 11) % 14, n * 60 - 90)).ToArray();
            if (tipo.Forma == "area")
            {
                using var b = new SolidBrush(Color.FromArgb(110, Colores[serie]));
                g.FillPolygon(b, puntos);
            }
            using var p = new Pen(Colores[serie], 1.4f);
            if (tipo.Forma == "polar") g.DrawClosedCurve(p, puntos, .35f, FillMode.Alternate);
            else g.DrawPolygon(p, puntos);
            foreach (var punto in puntos) Elipse(g, Colores[serie], punto.X - 1.3f, punto.Y - 1.3f, 2.6f, 2.6f);
        }
    }

    private static PointF Polar(PointF centro, float radio, float grados)
    {
        double radianes = grados * Math.PI / 180;
        return new(centro.X + (float)Math.Cos(radianes) * radio, centro.Y + (float)Math.Sin(radianes) * radio);
    }

    private static void Ejes(Graphics g, bool tresD)
    {
        using var p = new Pen(Color.FromArgb(220, 226, 232), .6f);
        for (int n = 0; n < 4; n++) g.DrawLine(p, 8, 10 + n * 13, 83, 10 + n * 13);
        Linea(g, Borde, .8f, new(8, 6), new(8, 50), new(84, 50));
        if (tresD)
        {
            Linea(g, Color.FromArgb(177, 191, 203), .7f, new(8, 50), new(13, 45), new(84, 45), new(84, 50));
            Linea(g, Color.FromArgb(177, 191, 203), .7f, new(13, 45), new(13, 5));
        }
    }

    private static void ColumnasIcono(Graphics g)
    {
        Rectangulo(g, Naranja, 3, 11, 4, 10);
        Rectangulo(g, Azul, 10, 5, 4, 16);
        Rectangulo(g, Color.FromArgb(105, 163, 213), 17, 8, 4, 13);
        Rectangulo(g, Color.FromArgb(255, 224, 115), 3, 10, 4, 2);
        Rectangulo(g, Color.FromArgb(157, 193, 223), 10, 4, 4, 2);
    }

    private static void Disquete(Graphics g, float x, float y, float escala = 1)
    {
        var estado = g.Save();
        g.TranslateTransform(x, y);
        g.ScaleTransform(escala, escala);
        Poligono(g, AzulOscuro, new(0, 0), new(15, 0), new(18, 3), new(18, 18), new(0, 18));
        Rectangulo(g, Color.FromArgb(200, 213, 227), 3, 0, 10, 7);
        Rectangulo(g, Color.FromArgb(84, 113, 147), 9, 1, 2, 5);
        Rectangulo(g, Color.FromArgb(248, 250, 252), 3, 10, 12, 6);
        Linea(g, Color.FromArgb(178, 194, 209), .8f, new(5, 12), new(13, 12));
        Linea(g, Color.FromArgb(178, 194, 209), .8f, new(5, 14), new(13, 14));
        g.Restore(estado);
    }

    private static void Hoja(Graphics g, float x, float y, float w, float h)
    {
        Rectangulo(g, Color.White, x, y, w, h);
        Marco(g, Borde, x, y, w, h);
        Linea(g, Color.FromArgb(193, 207, 222), .8f, new(x + 2, y + 3), new(x + w - 2, y + 3));
    }

    private static void Formato(Graphics g, string formato)
    {
        Hoja(g, 4, 2, 16, 20);
        Color color = formato.ToLowerInvariant() switch
        {
            "pdf" => Color.FromArgb(204, 86, 127),
            "html" => Color.FromArgb(206, 163, 33),
            "mht" => Color.FromArgb(222, 138, 37),
            "xls" or "xlsx" => Color.FromArgb(73, 151, 89),
            _ => Azul
        };
        Rectangulo(g, color, 1, 10, 22, 9);
        using var fuente = new Font("Arial", formato.Length > 3 ? 5.7f : 7, FontStyle.Bold, GraphicsUnit.Pixel);
        using var b = new SolidBrush(Color.White);
        using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        g.DrawString(formato.ToUpperInvariant(), fuente, b, new RectangleF(1, 10, 22, 9), sf);
    }

    private static void Nodo(Graphics g, PointF punto, Color color)
    {
        Elipse(g, Color.White, punto.X - 1.7f, punto.Y - 1.7f, 3.4f, 3.4f);
        using var p = new Pen(color, 1);
        g.DrawEllipse(p, punto.X - 1.7f, punto.Y - 1.7f, 3.4f, 3.4f);
    }

    private static void Preparar(Graphics g)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.CompositingQuality = CompositingQuality.HighQuality;
    }

    private static void Rectangulo(Graphics g, Color color, float x, float y, float w, float h)
    {
        using var b = new SolidBrush(color);
        g.FillRectangle(b, x, y, w, h);
    }

    private static void Marco(Graphics g, Color color, float x, float y, float w, float h)
    {
        using var p = new Pen(color, .8f);
        g.DrawRectangle(p, x, y, w, h);
    }

    private static void Elipse(Graphics g, Color color, float x, float y, float w, float h)
    {
        using var b = new SolidBrush(color);
        g.FillEllipse(b, x, y, w, h);
    }

    private static void Poligono(Graphics g, Color color, params PointF[] puntos)
    {
        using var b = new SolidBrush(color);
        g.FillPolygon(b, puntos);
    }

    private static void Linea(Graphics g, Color color, float ancho, params PointF[] puntos)
    {
        using var p = new Pen(color, ancho) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round };
        g.DrawLines(p, puntos);
    }

    private static void Sector(Graphics g, Color color, RectangleF rect, float inicio, float barrido, bool borde = true)
    {
        using var b = new SolidBrush(color);
        g.FillPie(b, rect.X, rect.Y, rect.Width, rect.Height, inicio, barrido);
        if (!borde) return;
        using var p = new Pen(Color.White, .65f);
        g.DrawPie(p, rect.X, rect.Y, rect.Width, rect.Height, inicio, barrido);
    }

    private static Color Mezclar(Color color, Color otro, float cantidad) => Color.FromArgb(
        (int)(color.R + (otro.R - color.R) * cantidad),
        (int)(color.G + (otro.G - color.G) * cantidad),
        (int)(color.B + (otro.B - color.B) * cantidad));
}
