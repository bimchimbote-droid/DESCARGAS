using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class MYGPanelPresupuesto
{
    private readonly DataGridView tablaPie = Tabla();
    private readonly ComboBox alcancePie = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 130 };
    private readonly Label tituloPie = new() { Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly MYGGraficoIncidencia graficoIncidencia = new() { Dock = DockStyle.Fill };
    private bool actualizandoPie;
    private string proyectoPieDelphinInicializado;
    private int alcancePieAnterior;
    private List<MYGPresupuestoDocumento> presupuestosPieEnEdicion;
    private string valorPieAntes;
    private List<MYGPresupuestoDocumento> AlcancePie() => alcancePie.SelectedIndex == 1
        ? PresupuestosEstructura.ToList() : P == null ? new() : new() { P };

    private static void AplicarSombreadoResumenPie(DataGridViewCellStyle estilo)
    {
        estilo.BackColor = SystemInformation.HighContrast ? SystemColors.Control : MYG2027_TemaComercial.Oscuro
            ? Color.FromArgb(52, 61, 73) : Color.FromArgb(236, 238, 240);
        estilo.ForeColor = SystemInformation.HighContrast ? SystemColors.ControlText : MYG2027_TemaComercial.Texto;
        estilo.SelectionBackColor = MYG2027_TemaComercial.Seleccion;
        estilo.SelectionForeColor = MYG2027_TemaComercial.TextoSeleccion;
    }

    private Control PrepararPiePresupuesto()
    {
        var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, Margin = new(0), BackColor = AzulClaro };
        panel.ColumnStyles.Add(new(SizeType.Percent, 43)); panel.ColumnStyles.Add(new(SizeType.Percent, 57));
        panel.RowStyles.Add(new(SizeType.Absolute, 31)); panel.RowStyles.Add(new(SizeType.Percent, 100));
        var cabeceraPie = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new(0), Padding = new(3) };
        cabeceraPie.ColumnStyles.Add(new(SizeType.Absolute, 138)); cabeceraPie.ColumnStyles.Add(new(SizeType.Percent, 100));
        alcancePie.Items.AddRange(new object[] { "Por presupuesto", "Por proyecto" }); alcancePie.SelectedIndex = 0;
        cabeceraPie.Controls.Add(PrepararOpcionesResumen(), 0, 0); cabeceraPie.Controls.Add(tituloPie, 1, 0);
        panel.Controls.Add(cabeceraPie, 0, 0); panel.SetColumnSpan(cabeceraPie, 2);
        panel.Controls.Add(graficoIncidencia, 0, 1); panel.Controls.Add(tablaPie, 1, 1);
        tablaPie.ReadOnly = false; tablaPie.EditMode = DataGridViewEditMode.EditOnEnter;
        tablaPie.RowTemplate.Height = 23; tablaPie.ColumnHeadersHeight = 25;
        tablaPie.DefaultCellStyle.Font = new Font("Segoe UI", 8.25F);
        Columna(tablaPie, "CONCEPTO", "Concepto", 108);
        Columna(tablaPie, "PORC", "%", 61, true); Columna(tablaPie, "IMPORTE", "Importe", 98); Columna(tablaPie, "COEF", "Coef.", 49);
        tablaPie.Columns["CONCEPTO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        tablaPie.Columns["CONCEPTO"].MinimumWidth = 140;
        tablaPie.Columns["CONCEPTO"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        tablaPie.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
        // El ancho se mide con los importes y su fuente efectiva, incluido el total
        // en negrita. Los nombres largos se ajustan sin recortar las cifras.
        tablaPie.Columns["IMPORTE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        tablaPie.Columns["IMPORTE"].MinimumWidth = 115;
        tablaPie.Columns["COEF"].MinimumWidth = 49;
        foreach (string c in new[] { "PORC", "IMPORTE", "COEF" }) tablaPie.Columns[c].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        tablaPie.Columns["PORC"].ToolTipText = "Edite el porcentaje. En Por proyecto se aplica este concepto a todos sus presupuestos. GG y utilidad usan el costo directo; IGV y otros impuestos usan el parcial.";
        MYG2027_TemaComercial.DesactivarFilasAlternas(tablaPie);
        // El gris del resumen tiene significado propio: la paleta general no
        // debe convertirlo en blanco ni sustituirlo por el color de una fila alterna.
        MYG2027_TemaComercial.ConservarColoresDocumento(tablaPie);
        tablaPie.CellFormatting += (_, e) =>
        {
            if (e.RowIndex >= 0)
            {
                var fila = tablaPie.Rows[e.RowIndex];
                if (!EsConceptoEditablePie(fila.Tag)) AplicarSombreadoResumenPie(e.CellStyle);
                AplicarFormatoFilaResumen(fila, e.CellStyle);
            }
        };
        void ActualizarSombreado(object sender, EventArgs e)
        {
            foreach (DataGridViewRow fila in tablaPie.Rows)
                foreach (DataGridViewCell celda in fila.Cells)
                {
                    if (!EsConceptoEditablePie(fila.Tag)) AplicarSombreadoResumenPie(celda.Style);
                    AplicarFormatoFilaResumen(fila, celda.Style);
                }
            tablaPie.Invalidate();
        }
        MYG2027_TemaComercial.CambioTema += ActualizarSombreado;
        tablaPie.Disposed += (_, _) => MYG2027_TemaComercial.CambioTema -= ActualizarSombreado;
        alcancePie.SelectedIndexChanged += (s, e) =>
        {
            if (actualizandoPie) return;
            try { FinalizarEdicion(); alcancePieAnterior = alcancePie.SelectedIndex; RefrescarPiePresupuesto(); }
            catch (Exception ex)
            {
                actualizandoPie = true; alcancePie.SelectedIndex = alcancePieAnterior; actualizandoPie = false;
                MessageBox.Show(this, ex.Message, "Pie de presupuesto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        };
        tablaPie.CellBeginEdit += (s, e) =>
        {
            if (actualizandoPie || e.ColumnIndex != tablaPie.Columns["PORC"].Index ||
                tablaPie.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly || !EsConceptoEditablePie(tablaPie.Rows[e.RowIndex].Tag) || !PiesCompatibles(AlcancePie())) { e.Cancel = true; return; }
            presupuestosPieEnEdicion = AlcancePie(); valorPieAntes = Convert.ToString(tablaPie.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);
        };
        tablaPie.CellValidating += (s, e) =>
        {
            if (actualizandoPie || presupuestosPieEnEdicion == null || e.ColumnIndex != tablaPie.Columns["PORC"].Index ||
                tablaPie.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly || !EsConceptoEditablePie(tablaPie.Rows[e.RowIndex].Tag)) return;
            string texto = Convert.ToString(e.FormattedValue)?.Trim().TrimEnd('%').Trim();
            if (texto == valorPieAntes) return;
            try
            {
                RequerirPermisoCatalogos();
                if (!MYGHojaCalculo.IntentarNumero(texto, out decimal porcentaje)) throw new InvalidOperationException("Escriba un porcentaje válido.");
                var destino = presupuestosPieEnEdicion ?? AlcancePie();
                // Validar una copia también evita registrar una edición inválida en el historial.
                object concepto = tablaPie.Rows[e.RowIndex].Tag;
                AplicarPorcentajeFilaPie(destino.Select(MYGProyectoStorage.Copia).ToList(), concepto, porcentaje);
                antes(); AplicarPorcentajeFilaPie(destino, concepto, porcentaje);
                valorPieAntes = texto; tablaPie.Rows[e.RowIndex].ErrorText = ""; despues();
            }
            catch (Exception ex) { e.Cancel = true; tablaPie.Rows[e.RowIndex].ErrorText = ex.Message; }
        };
        tablaPie.CellEndEdit += (s, e) =>
        {
            presupuestosPieEnEdicion = null; valorPieAntes = null;
            if (actualizandoPie || IsDisposed || !IsHandleCreated) return;
            SolicitarRefrescoEstructura(MYGTipoRefresco.Calculos);
        };
        PrepararMenuResumen();
        return panel;
    }

    private void RefrescarPiePresupuesto(Func<MYGPresupuestoDocumento, MYGCalculoPresupuesto> calcular = null)
    {
        if (actualizandoPie || tablaPie.IsCurrentCellInEditMode || tablaPie.Columns.Count == 0) return;
        actualizandoPie = true;
        try
        {
            var proyecto = PresupuestosEstructura.ToList();
            string proyectoDelphin = P?.Costos.PieDelphin?.ProyectoId;
            if (proyectoDelphin != null && proyectoDelphin != proyectoPieDelphinInicializado &&
                proyecto.Count > 1 && MYGPiePresupuesto.EsPieUnicoDelphin(proyecto))
            {
                alcancePie.SelectedIndex = alcancePieAnterior = 1;
                proyectoPieDelphinInicializado = proyectoDelphin;
            }
            string seleccion = IdFilaResumen(tablaPie.CurrentRow);
            var presupuestos = AlcancePie(); tablaPie.Rows.Clear();
            PrepararFormatosFilasResumen(presupuestos);
            if (presupuestos.Count == 0)
            { tituloPie.Text = "PIE DE PRESUPUESTO · Sin presupuesto"; graficoIncidencia.Actualizar(new(), "S/"); return; }
            var calculos = presupuestos.Select(p => calcular?.Invoke(p) ?? MYGMotorPresupuestos.CrearCalculo(p)).ToList();
            var r = MYGPiePresupuesto.Resumen(calculos); string moneda = MYGPiePresupuesto.Moneda(presupuestos);
            tituloPie.Text = alcancePie.SelectedIndex == 1 ? "PIE RESUMEN ÚNICO POR PROYECTO · " + moneda : "PIE DE " + P.Nombre + " · " + moneda;
            bool compatibles = PiesCompatibles(presupuestos);
            var filas = MYGPiePresupuesto.Filas(calculos);
            foreach (var dato in filas)
            {
                bool formulaDelphin = presupuestos.Any(p => MYGPiePresupuesto.EsPieDelphin(p) &&
                    p.Costos.PieDelphin.Filas.Any(f => f.Tipo == "F" && "delphin:" + f.Clave == dato.Id));
                bool concepto = !formulaDelphin && (dato.Concepto.HasValue || dato.Id != MYGPiePresupuesto.IdCostoDirecto && dato.Id != MYGPiePresupuesto.IdTotal && dato.Id != "parcial");
                bool porcentual = dato.Concepto.HasValue || dato.Editable && presupuestos.Any(MYGPiePresupuesto.EsPieDelphin) ||
                    presupuestos.Any(p => p.Costos.PiePersonalizado?.Any(f => f.Id == dato.Id && MYGPiePresupuesto.EsPorcentual(f)) == true);
                string porcentaje = dato.Porcentaje?.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture) ?? (porcentual ? "Varios" : "");
                var fila = tablaPie.Rows[tablaPie.Rows.Add(dato.Nombre, porcentaje, MYGFormatoPresupuesto.Dinero(dato.Importe), r.CostoDirecto == 0 ? "0.00" : (dato.Importe / r.CostoDirecto).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture))];
                fila.HeaderCell.Tag = dato.Id;
                fila.Tag = dato.Concepto.HasValue ? dato.Concepto.Value : concepto ? dato : null;
                fila.Cells["CONCEPTO"].ToolTipText = dato.Nombre;
                fila.Cells["IMPORTE"].ToolTipText = moneda + " " + MYGFormatoPresupuesto.Dinero(dato.Importe);
                fila.Cells["PORC"].ReadOnly = !dato.Editable || !compatibles;
                if (!concepto)
                    foreach (DataGridViewCell celda in fila.Cells) AplicarSombreadoResumenPie(celda.Style);
                if (dato.Id == MYGPiePresupuesto.IdTotal || formulaDelphin) fila.DefaultCellStyle.Font = negrita;
                AplicarFormatoFilaResumen(fila, fila.DefaultCellStyle);
                foreach (DataGridViewCell celda in fila.Cells) AplicarFormatoFilaResumen(fila, celda.Style);
                fila.Height = Math.Max(23, (fila.DefaultCellStyle.Font ?? tablaPie.DefaultCellStyle.Font).Height + 8);
                if (porcentual && !dato.Porcentaje.HasValue) fila.Cells["PORC"].ToolTipText = "Los presupuestos usan porcentajes distintos. Escribir uno aquí lo aplicará a todos para este concepto.";
                else if (dato.Porcentaje.HasValue && presupuestos.Any(MYGPiePresupuesto.EsPieDelphin))
                    fila.Cells["PORC"].ToolTipText = dato.Porcentaje.Value.ToString(System.Globalization.CultureInfo.InvariantCulture) + " %. Se conserva la precisión original de Delphin hasta editar el porcentaje.";
                else if (concepto && !porcentual) fila.Cells["PORC"].ToolTipText = "Valor manual o fórmula. Use Editar fila para modificarlo.";
                if (!compatibles) fila.Cells["PORC"].ToolTipText = "Los presupuestos tienen pies distintos. Edítelos por presupuesto o copie y pegue un resumen común.";
                if (seleccion != null && IdFilaResumen(fila) == seleccion) tablaPie.CurrentCell = fila.Cells["CONCEPTO"];
            }
            tablaPie.AutoResizeColumn(tablaPie.Columns["IMPORTE"].Index, DataGridViewAutoSizeColumnMode.AllCells);
            ActualizarMenuResumen();
            graficoIncidencia.Actualizar(MYGPiePresupuesto.Incidencia(calculos), moneda);
        }
        catch (Exception ex) { tablaPie.Rows.Clear(); tituloPie.Text = ex.Message; graficoIncidencia.Actualizar(new(), "", ex.Message); }
        finally { actualizandoPie = false; }
    }
}
