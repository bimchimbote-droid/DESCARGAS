﻿[CmdletBinding(SupportsShouldProcess=$true)]
param([string]$Proyecto = 'D:\ADDIN\repos\MYG.Presupuestos_GITHUB')
$ErrorActionPreference = 'Stop'
$Proyecto = (Resolve-Path -LiteralPath $Proyecto).Path
if (-not (Test-Path -LiteralPath (Join-Path $Proyecto 'MYG.Presupuestos.sln'))) { throw 'No se encuentra MYG.Presupuestos.sln en la carpeta indicada.' }
$manifest = @(Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'MANIFIESTO.json') | ConvertFrom-Json)
$pendientes = @()
foreach ($f in $manifest) {
    if ($f.Ruta -notmatch '^MYG\.(Core|Desktop|Pruebas|PruebasUI)/[^/\\]+\.cs$' -or $f.Accion -notin @('CREAR','REEMPLAZAR')) { throw 'El manifiesto contiene una ruta o acción no permitida.' }
    $origen = Join-Path (Join-Path $PSScriptRoot 'archivos') $f.Ruta
    $destino = Join-Path $Proyecto $f.Ruta
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $origen).Hash -ne $f.Despues) { throw "El paquete no coincide con su manifiesto: $($f.Ruta)" }
    $existe = Test-Path -LiteralPath $destino
    $hash = if ($existe) { (Get-FileHash -Algorithm SHA256 -LiteralPath $destino).Hash } else { '' }
    if ($hash -eq $f.Despues) { continue }
    if (($f.Accion -eq 'REEMPLAZAR' -and $hash -ne $f.Antes -and $hash -ne $f.AntesCRLF) -or ($f.Accion -eq 'CREAR' -and $existe)) {
        throw "Se detectaron cambios locales en $($f.Ruta). No se ha sustituido ningún archivo. Integre CAMBIOS.patch manualmente para conservar sus avances."
    }
    $f | Add-Member -NotePropertyName Original -NotePropertyValue $hash
    $pendientes += $f
}
if ($pendientes.Count -eq 0) { Write-Host 'Esta actualización ya está aplicada.'; return }
if (-not $PSCmdlet.ShouldProcess($Proyecto, "Aplicar $($pendientes.Count) archivos con respaldo independiente")) { return }
$nombre = 'MYG_respaldo_grafico_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [Guid]::NewGuid().ToString('N').Substring(0,8)
$respaldo = Join-Path (Split-Path -Parent $Proyecto) $nombre
New-Item -ItemType Directory -Path $respaldo | Out-Null
foreach ($f in $pendientes) {
    if ($f.Accion -eq 'REEMPLAZAR') {
        $copia = Join-Path (Join-Path $respaldo 'originales') $f.Ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $copia) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $Proyecto $f.Ruta) -Destination $copia
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $copia).Hash -ne $f.Original) { throw "Fallo al verificar respaldo: $($f.Ruta). No se ha aplicado la actualización." }
    }
}
[pscustomobject]@{ Proyecto = $Proyecto; Archivos = @($pendientes) } | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $respaldo 'RESPALDO.json')
Write-Host "Respaldo verificado: $respaldo"
$temporales = @()
$aplicados = @()
try {
    # Se preparan y verifican todas las copias antes de sustituir originales.
    foreach ($f in $pendientes) {
        $destino = Join-Path $Proyecto $f.Ruta
        New-Item -ItemType Directory -Path (Split-Path -Parent $destino) -Force | Out-Null
        $temporal = Join-Path (Split-Path -Parent $destino) ('.MYG-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $temporales += $temporal
        Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'archivos') $f.Ruta) -Destination $temporal
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temporal).Hash -ne $f.Despues) { throw "No se pudo verificar la copia: $($f.Ruta)" }
        $f | Add-Member -NotePropertyName Temporal -NotePropertyValue $temporal
    }
    foreach ($f in $pendientes) {
        $destino = Join-Path $Proyecto $f.Ruta
        if ($f.Accion -eq 'REEMPLAZAR') {
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $destino).Hash -ne $f.Original) { throw "El archivo cambió durante la actualización: $($f.Ruta)" }
            [System.IO.File]::Replace($f.Temporal, $destino, $null)
        }
        else { [System.IO.File]::Move($f.Temporal, $destino) }
        $aplicados += $f
    }
}
catch {
    $fallo = $_
    foreach ($f in $aplicados) {
        $destino = Join-Path $Proyecto $f.Ruta
        if ((Test-Path -LiteralPath $destino) -and (Get-FileHash -Algorithm SHA256 -LiteralPath $destino).Hash -eq $f.Despues) {
            if ($f.Accion -eq 'CREAR') { Remove-Item -LiteralPath $destino }
            else {
                $temporal = Join-Path (Split-Path -Parent $destino) ('.MYG-revertir-' + [Guid]::NewGuid().ToString('N') + '.tmp')
                $temporales += $temporal
                Copy-Item -LiteralPath (Join-Path (Join-Path $respaldo 'originales') $f.Ruta) -Destination $temporal
                [System.IO.File]::Replace($temporal, $destino, $null)
            }
        }
    }
    Write-Warning "La actualización no terminó. Respaldo disponible: $respaldo"
    throw $fallo
}
finally { foreach ($temporal in $temporales) { if (Test-Path -LiteralPath $temporal) { Remove-Item -LiteralPath $temporal } } }
Write-Host 'Actualización aplicada. Abra la solución y compile según LEER_PRIMERO.md.'
