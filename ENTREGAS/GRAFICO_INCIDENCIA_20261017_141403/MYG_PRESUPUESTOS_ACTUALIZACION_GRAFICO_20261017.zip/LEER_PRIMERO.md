﻿# MYG Presupuestos — gráfico de incidencia de costos

Entrega del 17/10/2026 para bimchimbote-droid/MYG.Presupuestos.
Rama de referencia: main. Commit base: 96eb1811a1adf7f2dfef47558354cd1ecd1b8f06.
Contiene código fuente completo de los archivos modificados/nuevos, un parche y aplicadores con respaldo. No es un instalador ni un ejecutable de Windows.

## Aplicar desde PowerShell

1. Extraiga este ZIP en una carpeta independiente y cierre Visual Studio y MYG Presupuestos.
2. Abra PowerShell en la carpeta extraída y ejecute (ajuste su carpeta real):

```powershell
.\APLICAR_ACTUALIZACION.ps1 -Proyecto 'D:\ADDIN\repos\MYG.Presupuestos_GITHUB' -WhatIf
.\APLICAR_ACTUALIZACION.ps1 -Proyecto 'D:\ADDIN\repos\MYG.Presupuestos_GITHUB'
```

El aplicador comprueba los SHA-256 de todos los archivos antes de escribir; si detecta avances diferentes, se detiene sin sustituirlos. Guarda un respaldo independiente junto al proyecto y conserva .git, ramas, archivos de datos y archivos ajenos a esta entrega. Puede repetirlo: omite archivos que ya coinciden con la entrega. Si su copia tiene cambios propios, use ARCHIVOS.md y CAMBIOS.patch para integrar cada diferencia; no fuerce la sustitución.

Alternativa para una copia compatible: desde la raíz del repositorio, `git apply --check RUTA\CAMBIOS.patch` y después `git apply RUTA\CAMBIOS.patch`. El parche y el aplicador son alternativas: no los aplique ambos sobre la misma copia.

## Compilar y comprobar

Abra MYG.Presupuestos.sln en Visual Studio con el SDK .NET 10.0.100. También puede ejecutar desde la raíz:

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
dotnet run --project MYG.Desktop/MYG.Desktop.csproj -c Release --no-build --no-restore
```

La ejecución de la interfaz requiere Windows; el conector real requiere Revit 2027. Las referencias Nice3point permiten compilar el conector sin tener Revit instalado. Para compilar con Revit local use UseRevitReferencePackages=false y RevitInstallDir según LEEME.md del repositorio.

## Herramientas del gráfico

Barra vertical: R, Cargar Plantilla, Mostrar como Plantilla, Exportar, Asistente de Gráficos, Columna, Línea, Tarta, Otros Gráficos, Paleta, Imprimir Previsualización, Imprimir y Apariencia. El botón de desbordamiento conserva el acceso a los comandos que no caben. Agregar o quitar botones y Personalización permiten ajustar la barra y sus opciones. Barras y Área están disponibles entre los comandos.

Se incluyen columnas 2D/3D, cilindros, conos, pirámides, líneas, curvas, dispersión, escalones, áreas, tartas, donas, dona anidada y vistas adicionales. Apariencia ofrece las 35 muestras de cinco estilos por siete paletas del video. La rotación 3D se puede modificar en el asistente o arrastrando sobre el gráfico. Las etiquetas pueden mostrar nombre, porcentaje e importe; hay títulos, anotaciones, cuadrícula y leyenda.

El dibujo consume la incidencia calculada del alcance Por presupuesto/Por proyecto. Plantillas y preferencias cambian la presentación, sin sustituir los importes ni modificar el proyecto. Las preferencias se guardan localmente en %LOCALAPPDATA%\MYG\grafico-incidencia.json. Las plantillas son JSON de MYG; no son archivos propietarios del programa mostrado en el video.

Exportaciones: PDF (imagen del gráfico), HTML, MHT, XLS, XLSX, RTF, BMP, GIF, JPEG, PNG y TIFF. HTML/MHT/RTF/XLSX incluyen también la tabla de valores. XLS es Excel 97-2003 auténtico y necesita Microsoft Excel instalado en Windows; XLSX no necesita Excel. La impresión utiliza las impresoras configuradas en Windows.

## Validación y alcance

Consulte VALIDACION.md para los resultados ejecutados y las comprobaciones pendientes. Las herramientas e iconos fueron implementados con controles y dibujos propios de MYG a partir del video; no se utiliza el componente propietario del programa de referencia. La comparación visual final debe realizarse en Windows. Consulte ARCHIVOS.md para la tabla exacta de archivos.

## Restaurar

El aplicador muestra la carpeta de respaldo. Para restaurar desde la carpeta extraída de esta entrega:

```powershell
.\RESTAURAR_RESPALDO.ps1 -Respaldo 'RUTA_DE_RESPALDO'
```

La restauración también verifica que no haya ediciones posteriores antes de copiar originales o retirar los archivos creados. No se ha hecho commit, push ni cambios de ramas en el repositorio del código. La entrega se publica solo en el repositorio independiente DESCARGAS.
