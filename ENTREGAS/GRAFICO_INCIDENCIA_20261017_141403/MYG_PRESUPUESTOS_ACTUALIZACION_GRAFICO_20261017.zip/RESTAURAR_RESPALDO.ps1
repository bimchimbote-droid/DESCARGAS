﻿[CmdletBinding(SupportsShouldProcess=$true)]
param([Parameter(Mandatory=$true)][string]$Respaldo)
$ErrorActionPreference = 'Stop'
$registro = Get-Content -Raw -LiteralPath (Join-Path $Respaldo 'RESPALDO.json') | ConvertFrom-Json
$Proyecto = $registro.Proyecto
foreach ($f in $registro.Archivos) {
    if ($f.Ruta -notmatch '^MYG\.(Core|Desktop|Pruebas|PruebasUI)/[^/\\]+\.cs$' -or $f.Accion -notin @('CREAR','REEMPLAZAR')) { throw 'El respaldo contiene una ruta o acción no permitida.' }
    $destino = Join-Path $Proyecto $f.Ruta
    if (Test-Path -LiteralPath $destino) {
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $destino).Hash
        if ($hash -ne $f.Despues -and $hash -ne $f.Original) { throw "Hay cambios posteriores en $($f.Ruta). No se ha restaurado ningún archivo." }
    }
    if ($f.Accion -eq 'REEMPLAZAR') {
        $origen = Join-Path (Join-Path $Respaldo 'originales') $f.Ruta
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $origen).Hash -ne $f.Original) { throw "Respaldo inválido: $($f.Ruta)" }
    }
}
if (-not $PSCmdlet.ShouldProcess($Proyecto, 'Restaurar archivos respaldados y retirar los archivos de esta actualización')) { return }
foreach ($f in $registro.Archivos) {
    $destino = Join-Path $Proyecto $f.Ruta
    if ($f.Accion -eq 'REEMPLAZAR') {
        $temporal = Join-Path (Split-Path -Parent $destino) ('.MYG-restaurar-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        try {
            Copy-Item -LiteralPath (Join-Path (Join-Path $Respaldo 'originales') $f.Ruta) -Destination $temporal
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temporal).Hash -ne $f.Original) { throw "Copia de restauración inválida: $($f.Ruta)" }
            if (Test-Path -LiteralPath $destino) { [System.IO.File]::Replace($temporal, $destino, $null) }
            else { [System.IO.File]::Move($temporal, $destino) }
        }
        finally { if (Test-Path -LiteralPath $temporal) { Remove-Item -LiteralPath $temporal } }
    }
    elseif (Test-Path -LiteralPath $destino) { Remove-Item -LiteralPath $destino }
}
Write-Host 'Respaldo restaurado. La carpeta .git y los archivos ajenos a esta actualización se conservan.'
