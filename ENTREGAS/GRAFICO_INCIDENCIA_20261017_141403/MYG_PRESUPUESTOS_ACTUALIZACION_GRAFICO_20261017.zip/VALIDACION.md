# Validación de la entrega — 17/10/2026

## Ejecutado en Linux x64 con SDK .NET 10.0.100

- Solución completa Release, referencias Revit Nice3point: compilación aprobada, cero advertencias y cero errores. Incluye MYG.Core, MYG.Desktop, MYG.Revit2027, MYG.Pruebas y MYG.PruebasUI.
- Suite funcional MYG.Pruebas: 451 comprobaciones aprobadas, código de salida 0. Entre ellas, 2280 combinaciones de tipos/apariencias/paletas con plantillas completas, copias independientes, opciones y barras personalizadas; validación de entradas erróneas; conservación de firmas e importes importados reales del motor.
- Dos comprobaciones omitidas por el runner: Named Pipes de Windows y muestra externa LLACUSBAMBA (MYG_QA_LLACUSBAMBA_SQLITE no definida). El JSON antiguo externo es opcional; se usaron datos sintéticos de compatibilidad.
- Comprobaciones de documentos del exportador en una prueba aislada de serialización, con imágenes codificadas: PDF válido con pdfinfo; XLSX con imagen y valores leído con openpyxl; MIME/Unicode/decimales y limpieza de archivos temporales. No equivale a ejecutar GDI en Windows.
- git diff --check sin errores.
- CAMBIOS.patch aplicado a una extracción limpia del commit base: los 11 archivos resultantes coinciden byte por byte y por SHA-256 con MANIFIESTO.json y los archivos completos. Hashes de la base LF y CRLF comprobados.

## Incluido y compilado, sin ejecución Windows

MYG.PruebasUI/GraficoIncidenciaUICheck.cs incluye dibujo de los 57 tipos en cinco apariencias y dos tamaños, comparación de geometrías y estilos, barra de herramientas, 35 muestras, plantillas y preferencias, firmas de imágenes y contenido de PDF/XLSX. La interfaz requiere el runtime Windows Desktop y no puede ejecutarse en este entorno Linux.

Pendiente en Windows: abrir el programa y revisar el resultado visual frente al video, ejecutar las pruebas UI, comprobar las impresoras y la conversión XLS mediante Microsoft Excel. También quedan fuera de esta modificación la sesión real de Revit y el servicio de licencia.

Los iconos, galerías y diálogos son una implementación propia de MYG basada en las herramientas observadas; no se afirma identidad píxel a píxel con el componente propietario del video. Las plantillas JSON de MYG no importan plantillas propietarias de terceros.

## Comandos reproducibles

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
# En Windows:
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release --no-build --no-restore
```

El aplicador PowerShell fue revisado estáticamente; no se ejecutó en Windows. Incluye vista previa -WhatIf, validación LF/CRLF, respaldo verificado, reemplazo atómico y restauración que rechaza ediciones posteriores.
