﻿| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | `MYG.Core/GraficoIncidenciaConfiguracion.cs` | CREAR | Catálogo de tipos, paletas, plantillas y configuración validada. |
| 2 | `MYG.Desktop/GraficoIncidencia.cs` | CREAR | Dibujo 2D/3D, etiquetas, rotación, leyenda y preferencias locales. |
| 3 | `MYG.Desktop/GraficoIncidenciaBarras.cs` | CREAR | Creación, edición y eliminación de barras personalizadas. |
| 4 | `MYG.Desktop/GraficoIncidenciaExportacion.cs` | CREAR | PDF, HTML, MHT, XLS/XLSX, RTF e imágenes con valores reales. |
| 5 | `MYG.Desktop/GraficoIncidenciaHerramientas.cs` | CREAR | Barra, galerías, asistente, plantillas, impresión y personalización. |
| 6 | `MYG.Desktop/GraficoIncidenciaIconos.cs` | CREAR | Iconos propios y miniaturas de las galerías. |
| 7 | `MYG.Desktop/PresupuestosPiePanel.cs` | REEMPLAZAR | Integra el nuevo gráfico con los importes existentes del presupuesto/proyecto. |
| 8 | `MYG.Pruebas/GraficoIncidenciaCheck.cs` | CREAR | Validación de plantillas y conservación de importes y firmas. |
| 9 | `MYG.Pruebas/Program.cs` | REEMPLAZAR | Registra las comprobaciones de configuración. |
| 10 | `MYG.PruebasUI/GraficoIncidenciaUICheck.cs` | CREAR | Comprobaciones de dibujo, herramientas y exportación en Windows. |
| 11 | `MYG.PruebasUI/Program.cs` | REEMPLAZAR | Registra las comprobaciones nuevas de interfaz. |
