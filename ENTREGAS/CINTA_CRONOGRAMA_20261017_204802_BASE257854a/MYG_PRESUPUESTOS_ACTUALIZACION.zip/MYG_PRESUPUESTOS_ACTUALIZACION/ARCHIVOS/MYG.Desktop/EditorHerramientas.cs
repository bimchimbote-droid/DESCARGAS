using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    // Son accesos al trabajo del proyecto; los paneles y ejecutables de BIM
    // conservan sus botones y formularios originales.
    private void InicializarHerramientasProyecto(Func<string, string, Action, bool, Button> agregar)
    {
        Button Herramienta(string icono, string texto, string nombre, Action accion, bool licencia = true, int ancho = 91, bool desplegable = false)
        {
            var boton = desplegable ? CrearBotonCintaProyecto(icono, texto, licencia) : agregar(icono, texto, accion, licencia);
            if (desplegable)
            {
                // Abrir las opciones sólo consulta el contexto. Cada destino
                // conserva EjecutarDesdeMenuProyecto para confirmar la edición,
                // verificar la licencia y actualizar el proyecto al ejecutarse.
                boton.Click += (_, _) =>
                {
                    if (ocupado) return;
                    try { accion(); }
                    catch (Exception ex) { estado.Text = ex.Message; MYGProyectoUI.Error(this, ex); }
                };
                cintaPresupuestos.Controls.Add(boton);
            }
            boton.Name = nombre; boton.AccessibleName = texto.Replace("\n", " ").Replace(" ▾", "");
            boton.Width = ancho; ayudas.SetToolTip(boton, boton.AccessibleName); return boton;
        }
        void Pendiente(string icono, string texto, string nombre, int ancho)
        {
            // El usuario pidió colocar estas herramientas sin ejecutar nada
            // todavía: no hay validación de sesión, sincronización ni diálogo.
            var boton = CrearBotonCintaProyecto(icono, texto, false);
            boton.Name = nombre; boton.Width = ancho;
            boton.AccessibleDescription = "Pendiente de implementación.";
            ayudas.SetToolTip(boton, boton.AccessibleName + " — Pendiente de implementación.");
            cintaPresupuestos.Controls.Add(boton);
        }

        // La navegación conserva el editor y su historial dentro de la pestaña.
        var inicio = CrearBotonCintaProyecto("proyecto", "Ir inicio", false);
        inicio.Name = "ir_inicio_button";
        ayudas.SetToolTip(inicio, "Volver a Inicio conservando los proyectos abiertos y sus cambios pendientes.");
        inicio.Click += (_, _) => IrInicio();
        cintaPresupuestos.Controls.Add(inicio);

        Herramienta("guardar", "Guardar", "guardar_proyecto_button", () => Guardar(false), false);
        Button imprimir = null;
        imprimir = Herramienta("imprimir", "Imprimir / PDF ▾", "imprimir_proyecto_button", () => MenuImprimirProyecto(imprimir), ancho: 110, desplegable: true);
        Herramienta("proyecto", "Info. proyecto", "info_proyecto_button", EditarDatosProyecto, ancho: 100);
        Button exportar = null;
        exportar = Herramienta("excel", "Exportar ▾", "exportar_proyecto_button", () => MenuExportarProyecto(exportar), desplegable: true);
        Pendiente("acu", "Fórmula\npolinómica", "formula_polinomica_button", 100);
        Pendiente("insumos", "Calendario de\nadquisiciones", "calendario_adquisiciones_button", 112);
        Pendiente("resumen", "Calendario\nvalorizado", "calendario_valorizado_button", 104);
        Herramienta("resumen", "Resumen de\ncostos", "resumen_costos_button", () => panelPresupuesto.Resumen(), ancho: 104);
        Button responsables = null;
        responsables = Herramienta("sesion", "Responsables ▾", "responsables_proyecto_button", () => MenuResponsablesProyecto(responsables), false, 108, desplegable: true);
        Herramienta("especificacion", "Especificaciones", "especificaciones_button", () => panelPresupuesto.MostrarEspecificacion(), ancho: 112);
        Pendiente("resumen", "Valorización", "valorizacion_button", 100);
        Button permisos = null;
        permisos = Herramienta("sesion", "Permisos ▾", "permisos_proyecto_button", () => MenuPermisosProyecto(permisos), false, 100, desplegable: true);
        ayudas.SetToolTip(permisos, "Consultar la autorización actual e iniciar o cambiar de sesión.");
        var tamanoTexto = MYGTamanoTextoUI.CrearBoton();
        tamanoTexto.Width = 110; tamanoTexto.Height = 65; tamanoTexto.Margin = new(2);
        tamanoTexto.Tag = false; // Ajustar la lectura no requiere una licencia activa.
        tamanoTexto.Image = MYGIconos.Obtener("editar");
        tamanoTexto.TextImageRelation = TextImageRelation.ImageAboveText;
        tamanoTexto.ImageAlign = ContentAlignment.TopCenter;
        tamanoTexto.TextAlign = ContentAlignment.BottomCenter;
        tamanoTexto.Disposed += (_, _) => tamanoTexto.Image?.Dispose();
        MYG2027_TemaComercial.EstilizarBoton(tamanoTexto, 3);
        ayudas.SetToolTip(tamanoTexto, "Tamaño del texto: 85 %, 100 % o 115 %. Se guarda solo en este equipo; no cambia los documentos impresos.");
        cintaPresupuestos.Controls.Add(tamanoTexto);
    }

    internal static Button CrearBotonCintaProyecto(string icono, string texto, bool necesitaLicencia)
    {
        var boton = new MYG2027_BotonComercial
        {
            Text = texto, AccessibleName = texto.Replace("\n", " ").Replace(" ▾", ""),
            Image = MYGIconos.Obtener(icono), TextImageRelation = TextImageRelation.ImageAboveText,
            ImageAlign = ContentAlignment.TopCenter, TextAlign = ContentAlignment.BottomCenter,
            Width = 91, Height = 65, FlatStyle = FlatStyle.Flat, Font = new("Segoe UI", 9),
            BackColor = MYG2027_TemaComercial.Superficie, ForeColor = MYG2027_TemaComercial.Texto, Margin = new(2), Tag = necesitaLicencia
        };
        boton.Disposed += (_, _) => boton.Image?.Dispose();
        MYG2027_TemaComercial.EstilizarBoton(boton); MYGAnimacionUI.PrepararBoton(boton);
        return boton;
    }

    internal static bool HerramientaProyectoDisponible(bool necesitaLicencia, bool ocupado, bool autorizado)
        => !ocupado && (!necesitaLicencia || autorizado);

    internal static ContextMenuStrip CrearMenuImprimirProyecto(Action<MYGTipoReporteProyecto> imprimir,
        Action<string> exportarMetrados, Action exportarPorPlantilla,
        bool presupuestoDisponible, bool proyectoDisponible, bool partidasDisponibles, bool excelDisponible, bool acerosDisponible)
    {
        var menu = new ContextMenuStrip { Name = "menu_imprimir_proyecto", ShowImageMargin = true };
        void Opcion(string nombre, string texto, string icono, Action ejecutar, bool disponible)
        {
            var imagen = MYGIconos.Obtener(icono);
            var item = new ToolStripMenuItem(texto, imagen, (_, _) => ejecutar())
            { Name = nombre, Enabled = disponible };
            item.Disposed += (_, _) => imagen.Dispose();
            menu.Items.Add(item);
        }
        Opcion("imprimir_presupuesto_seleccionado", "Presupuesto seleccionado", "imprimir",
            () => imprimir(MYGTipoReporteProyecto.PresupuestoSeleccionado), presupuestoDisponible);
        Opcion("imprimir_todos_presupuestos", "Todos los presupuestos", "catalogo",
            () => imprimir(MYGTipoReporteProyecto.TodosPresupuestos), proyectoDisponible);
        Opcion("imprimir_hoja_resumen", "Hoja de resumen", "resumen",
            () => imprimir(MYGTipoReporteProyecto.HojaResumen), presupuestoDisponible);
        Opcion("imprimir_analisis_costos_unitarios", "Análisis de costos unitarios", "imprimir",
            () => imprimir(MYGTipoReporteProyecto.AnalisisCostosUnitarios), partidasDisponibles);
        Opcion("imprimir_consolidado_costos_unitarios", "Consolidado de costos unitarios", "acu",
            () => imprimir(MYGTipoReporteProyecto.ConsolidadoCostosUnitarios), partidasDisponibles);
        menu.Items.Add(new ToolStripSeparator());
        Opcion("imprimir_metrados", "Metrados", "editar",
            () => imprimir(MYGTipoReporteProyecto.Metrados), partidasDisponibles);
        Opcion("exportar_metrados_excel", "Metrados (Formato DE Excel)", "excel",
            () => exportarMetrados(null), excelDisponible);
        Opcion("imprimir_metrados_aceros", "Metrados de fierros y aceros", "editar",
            () => imprimir(MYGTipoReporteProyecto.MetradosAceros), acerosDisponible);
        menu.Items.Add(new ToolStripSeparator());
        Opcion("exportar_metrados_aceros_excel", "Metrados de fierros y aceros (Formato DE Excel)", "excel",
            () => exportarMetrados(MYGPlantillasMetrado.Aceros), acerosDisponible);
        Opcion("exportar_metrados_por_plantilla_excel", "Metrados por tipo de plantilla (Formato DE Excel)", "excel",
            exportarPorPlantilla, excelDisponible);
        return menu;
    }

    private void MenuImprimirProyecto(Button boton)
    {
        bool Partida(ItemPresupuestoDelphin i) => !MYGProyectoStorage.EsTitulo(i);
        bool Excel(ItemPresupuestoDelphin i) => Partida(i) && i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel && i.Costos.Hoja != null;
        var items = P?.Items ?? new();
        // Resolver el presupuesto al ejecutar conserva el contexto de la pestaña activa.
        var menu = CrearMenuImprimirProyecto(
            tipo => EjecutarDesdeMenuProyecto(() => ImprimirReporteProyecto(tipo)),
            plantilla => EjecutarDesdeMenuProyecto(() => ExportarMetradosImpresion(plantilla)),
            () => EjecutarDesdeMenuProyecto(ExportarMetradosPorPlantilla),
            P != null, documento.Presupuestos.Count > 0, items.Any(Partida), items.Any(Excel),
            items.Any(i => Excel(i) && MYGPlantillasMetrado.Identificar(i.Costos.Hoja) == MYGPlantillasMetrado.Aceros));
        MostrarMenuProyecto(menu, boton);
    }

    private void ImprimirReporteProyecto(MYGTipoReporteProyecto tipo)
    {
        var reportes = MYGReportesProyecto.Crear(documento, P?.Id, tipo);
        if (reportes.Count == 0) throw new InvalidOperationException("El presupuesto no contiene datos para este reporte.");
        Func<MYGHojaReporteProyecto> crearMetradosExcel = null;
        if (tipo is MYGTipoReporteProyecto.Metrados or MYGTipoReporteProyecto.MetradosAceros)
        {
            string plantilla = tipo == MYGTipoReporteProyecto.MetradosAceros ? MYGPlantillasMetrado.Aceros : null;
            if (P?.Items.Any(i => !MYGProyectoStorage.EsTitulo(i) && i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel &&
                i.Costos.Hoja != null && (plantilla == null || MYGPlantillasMetrado.Identificar(i.Costos.Hoja) == plantilla)) == true)
            {
                var instantanea = MYGProyectoStorage.Copia(documento);
                string presupuestoId = P.Id;
                crearMetradosExcel = () => MYGReporteMetradosExcel.Crear(instantanea, presupuestoId, plantilla);
            }
        }
        MYGReportesImpresion.Imprimir(this, NombreProyecto, reportes, crearMetradosExcel);
    }

    private void ExportarMetradosImpresion(string plantilla)
    {
        var reporte = MYGReporteMetradosExcel.Crear(documento, P?.Id, plantilla);
        using var vista = new MYGVistaMetradosExcelForm(NombreProyecto, reporte);
        vista.ShowDialog(this);
    }

    private void ExportarMetradosPorPlantilla()
    {
        if (P == null) throw new InvalidOperationException("Seleccione un presupuesto.");
        var tipos = P.Items.Where(i => !MYGProyectoStorage.EsTitulo(i) &&
                i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel && i.Costos.Hoja != null)
            .Select(i => MYGPlantillasMetrado.Identificar(i.Costos.Hoja)).Distinct().ToArray();
        if (tipos.Length == 0) throw new InvalidOperationException("El presupuesto no contiene metrados Excel para exportar.");
        using var dialogo = new Form();
        MYGProyectoUI.Preparar(dialogo, "Exportar metrados por tipo de plantilla", 560, 210);
        var etiqueta = new Label { Text = "Tipo de plantilla del presupuesto activo:", Dock = DockStyle.Top, Height = 36 };
        var selector = new ComboBox { Name = "plantilla_metrados_exportar", Dock = DockStyle.Top,
            DropDownStyle = ComboBoxStyle.DropDownList, DisplayMember = "Nombre" };
        selector.Items.AddRange(tipos.Select(id => new MYGPlantillaImpresion(id,
            id == MYGPlantillasMetrado.Aceros ? "Fierros y aceros" : id == MYGPlantillasMetrado.Estandar ? "Estándar" : "Otras hojas / importadas")).Cast<object>().ToArray());
        selector.SelectedIndex = 0;
        var exportar = MYGProyectoUI.Boton("Exportar", 1); exportar.DialogResult = DialogResult.OK;
        var cancelar = MYGProyectoUI.Boton("Cancelar"); cancelar.DialogResult = DialogResult.Cancel;
        dialogo.Padding = new(18); dialogo.Controls.Add(selector); dialogo.Controls.Add(etiqueta);
        dialogo.Controls.Add(MYGBibliotecaUI.Pie(exportar, cancelar));
        dialogo.AcceptButton = exportar; dialogo.CancelButton = cancelar;
        if (dialogo.ShowDialog(this) == DialogResult.OK && selector.SelectedItem is MYGPlantillaImpresion tipo)
            ExportarMetradosImpresion(tipo.Id);
    }

    private sealed record MYGPlantillaImpresion(string Id, string Nombre);

    internal static ContextMenuStrip CrearMenuExportarProyecto(Action presupuesto, Action metrados,
        bool presupuestoDisponible, bool metradosDisponibles,
        Action<MYGAlcanceEspecificaciones> especificaciones = null)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Presupuesto activo (.xlsx)", null, (_, _) => presupuesto())
        { Name = "exportar_presupuesto_activo", Enabled = presupuestoDisponible });
        menu.Items.Add(new ToolStripMenuItem("Metrados completos del proyecto (.xlsx)", null, (_, _) => metrados())
        { Name = "exportar_metrados_completos", Enabled = metradosDisponibles });
        if (especificaciones != null)
        {
            var opciones = new ToolStripMenuItem("Especificaciones técnicas") { Name = "exportar_especificaciones" };
            using var menuEspecificaciones = CrearMenuEspecificaciones(especificaciones, presupuestoDisponible);
            foreach (var opcion in menuEspecificaciones.Items.Cast<ToolStripItem>().ToArray())
                opciones.DropDownItems.Add(opcion);
            menu.Items.Add(opciones);
        }
        return menu;
    }

    private void MenuExportarProyecto(Button boton)
    {
        var menu = CrearMenuExportarProyecto(
            () => EjecutarDesdeMenuProyecto(() => panelPresupuesto.ExportarPresupuesto()),
            () => EjecutarDesdeMenuProyecto(() => panelPresupuesto.ExportarMetradosCompletos()),
            P != null, documento.Presupuestos.Any(p => p.Items.Any(i => !MYGProyectoStorage.EsTitulo(i) &&
                i.Costos?.FuenteMetrado == MYGFuenteMetrado.Excel && i.Costos.Hoja != null)), ExportarEspecificacionesDesdeMenu);
        MostrarMenuProyecto(menu, boton);
    }

    internal static ContextMenuStrip CrearMenuResponsablesProyecto(Action asignar, Action ver, Action quitar,
        bool autorizado, bool hayResponsables)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Asignar responsable…", null, (_, _) => asignar())
        { Name = "asignar_responsable_proyecto", Enabled = autorizado });
        menu.Items.Add(new ToolStripMenuItem("Ver responsables…", null, (_, _) => ver())
        { Name = "ver_responsables_proyecto" });
        menu.Items.Add(new ToolStripMenuItem("Quitar responsable…", null, (_, _) => quitar())
        { Name = "quitar_responsable_proyecto", Enabled = autorizado && hayResponsables });
        return menu;
    }

    private void MenuResponsablesProyecto(Button boton)
    {
        object contexto = espacioPresupuestos.SelectedIndex == 0 ? panelPresupuesto.SeleccionEstructura : Seleccionadas.FirstOrDefault();
        var propietario = PropietarioEstructura(contexto) ?? P
            ?? throw new InvalidOperationException("Seleccione un presupuesto o una partida para consultar sus responsables.");
        string presupuestoId = propietario.Id, partidaId = NodoEstructura(contexto)?.Id;
        object Resolver()
        {
            var p = documento.Presupuestos.FirstOrDefault(p => p.Id == presupuestoId)
                ?? throw new InvalidOperationException("El presupuesto seleccionado ya no está en el proyecto.");
            return partidaId == null ? p : p.Items.FirstOrDefault(i => i.Id == partidaId)
                ?? throw new InvalidOperationException("La partida seleccionada ya no está en el presupuesto.");
        }
        // Resolver los IDs al hacer clic permite usar el historial mientras el
        // menú está cerrado sin conservar referencias a una versión anterior.
        var lista = partidaId == null ? propietario.Costos.Responsables : NodoEstructura(contexto)?.Costos.Responsables;
        var menu = CrearMenuResponsablesProyecto(
            () => EjecutarDesdeMenuProyecto(() => AsignarResponsable(Resolver())),
            () => EjecutarDesdeMenuProyecto(() => VerResponsables(Resolver()), false),
            () => EjecutarDesdeMenuProyecto(() => QuitarResponsable(Resolver())),
            sesion.Autorizado, lista?.Count > 0);
        MostrarMenuProyecto(menu, boton);
    }

    private void MenuPermisosProyecto(Button boton)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Ver autorización actual…", null, (_, _) => EjecutarDesdeMenuProyecto(() =>
        {
            string usuario = sesion.Credencial?.Usuario ?? "Sin sesión";
            string autorizacion = sesion.Autorizado ? "Autorizada para editar presupuestos y metrados." : "Inicie sesión para editar presupuestos y metrados.";
            MessageBox.Show(this, "Usuario: " + usuario + Environment.NewLine + autorizacion + Environment.NewLine +
                "Puede guardar el trabajo pendiente y volver a Inicio con la sesión vencida.", "Permisos de la sesión", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }, false)) { Name = "ver_autorizacion_actual" });
        menu.Items.Add(new ToolStripMenuItem("Iniciar o cambiar de sesión…", null, (_, _) => EjecutarDesdeMenuProyecto(() =>
        { using var f = new MYG.Externo.LoginForm(sesion); f.ShowDialog(this); }, false)) { Name = "iniciar_cambiar_sesion" });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(new ToolStripMenuItem(MYG2027_TemaComercial.Oscuro ? "Modo normal" : "Modo oscuro", null,
            (_, _) => EjecutarDesdeMenuProyecto(() => MYG2027_TemaComercial.Alternar(), false)) { Name = "alternar_tema_proyecto" });
        MostrarMenuProyecto(menu, boton);
    }

    private void EjecutarDesdeMenuProyecto(Action accion, bool necesitaLicencia = true)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing) return;
            await Ejecutar(() => { accion(); return Task.CompletedTask; }, necesitaLicencia);
        }));
    }

    private void MostrarMenuProyecto(ContextMenuStrip menu, Button boton)
    {
        componentesMenus.Add(menu);
        menu.Closed += (_, _) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated || menu.IsDisposed) return;
            BeginInvoke(new Action(() => { if (!menu.IsDisposed && !menu.Disposing) menu.Dispose(); }));
        };
        menu.Show(boton, new Point(0, boton.Height));
    }
}
