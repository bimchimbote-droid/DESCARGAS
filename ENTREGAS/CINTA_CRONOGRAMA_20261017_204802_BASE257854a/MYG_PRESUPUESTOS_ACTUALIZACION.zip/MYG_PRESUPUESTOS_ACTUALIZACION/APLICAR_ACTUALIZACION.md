# Barra superior del cronograma

Proyecto: `bimchimbote-droid/MYG.Presupuestos`, rama de referencia `main`.
Base: `257854a00820c07fe9806862cbedaf52bb92bc81`.
Tecnologías: Visual Studio, C#, .NET 10, SQLite y Revit 2027.

## Resultado

La franja del Cronograma utiliza los mismos botones comerciales que Presupuesto: bordes redondeados, fuente Segoe UI, doble búfer e icono encima del texto. Se conservan los 18 botones, su orden, iconos, etiquetas, menús, permisos y acciones. Los textos largos ajustan el ancho del botón cuando cambia la fuente o el DPI; no se mide el ancho en cada repintado.

Ambas cintas utilizan una altura lógica de 98 px con botones de 65 px. Las medidas se escalan al cambiar de monitor y al alternar R/CPM. En ventanas estrechas se conserva el desplazamiento horizontal, con R/CPM fuera de la zona desplazable.

## Aplicación manual

1. Cierra MYG y Visual Studio. Guarda una copia externa de tus cambios locales antes de sustituir archivos.
2. En tu checkout habitual (por ejemplo `D:\ADDIN\repos\MYG.Presupuestos_GITHUB`), copia el contenido de `ARCHIVOS` a la raíz, conservando las carpetas. Reemplaza únicamente los cuatro archivos de la tabla. Si tienes avances posteriores en ellos, compara e integra esos avances antes de reemplazarlos.
3. Mantén tu carpeta `.git`, las bases de obras y los demás archivos. No necesitas volver a clonar. Este paquete no altera los otros archivos de la optimización anterior; el archivo completo EditorHerramientas conserva su apertura ligera de desplegables.
4. Abre `MYG.Presupuestos.sln` y compila Release/x64 con .NET 10. No necesitas cambiar proyectos, dependencias ni lockfiles.

| N.º | Ruta exacta del archivo | Acción requerida | Descripción |
|---|---|---|---|
| 1 | `MYG.Desktop/EditorHerramientas.cs` | REEMPLAZAR | Comparte la fábrica de botones de Presupuesto con Cronograma; conserva la optimización anterior de los desplegables. |
| 2 | `MYG.Desktop/CronogramaPanel.cs` | REEMPLAZAR | Usa botones comerciales con icono arriba y texto abajo; adapta el ancho a fuente y DPI, sin modificar comandos ni menús. |
| 3 | `MYG.Desktop/EditorCronograma.cs` | REEMPLAZAR | Iguala la altura de las cintas y adapta las filas al DPI, conservando los accesos R/CPM. |
| 4 | `MYG.PruebasUI/CronogramaUICheck.cs` | REEMPLAZAR | Amplía la regresión de los 18 botones, menús, textos al 85/100/115 %, desplazamiento y navegación. |

## Parche opcional

`CAMBIOS.patch` reproduce estos cuatro archivos sobre la base main `257854a`. Desde la raíz de una copia de esa base, ejecuta primero `git apply --check RUTA\CAMBIOS.patch` y luego `git apply RUTA\CAMBIOS.patch`. Usa el parche o los archivos completos, no ambos. Si ya aplicaste la entrega anterior o tienes cambios propios, compara los archivos completos: el parche puede detectar diferencias de contexto y no debe forzarse.

## Validación

- Solución completa, incluidos escritorio Windows, conector Revit y pruebas UI: compilación Release sin errores ni advertencias.
- Segunda compilación en una exportación limpia de main con únicamente estos cuatro archivos: sin errores ni advertencias. Así se comprobó que el paquete no necesita otros archivos nuevos de la entrega anterior.
- Suite del núcleo ejecutada de nuevo: 462 comprobaciones aprobadas. Se confirmó un informe QA de la ejecución actual.
- Pruebas de interfaz ampliadas: compiladas; ejecución pendiente en Windows. No se produjo una captura ni se ejecutó WinForms en Linux.

Comandos de compilación y núcleo:

```powershell
dotnet build MYG.Presupuestos.sln -c Release -p:UseRevitReferencePackages=true -m:1 -nr:false
dotnet run --project MYG.Pruebas/MYG.Pruebas.csproj -c Release --no-build --no-restore
```

En Windows, para ejecutar las pruebas de interfaz existentes y la regresión ampliada:

```powershell
dotnet run --project MYG.PruebasUI/MYG.PruebasUI.csproj -c Release
```

Comprueba también la vista CPM de tu obra, los textos al 85/100/115 %, el desplazamiento en una ventana estrecha y, si dispones de ellos, monitores con distinto escalado. Confirma el acceso a los dos desplegables y el cambio R/CPM. La entrega cambia la presentación de la barra; no modifica el motor del cronograma ni los cálculos de presupuesto.

## Entrega

ZIP publicado únicamente en una carpeta nueva del repositorio independiente público `bimchimbote-droid/DESCARGAS`, con descarga verificada. Se conservan las entregas anteriores y no se hizo push al repositorio del código. `VALIDACION` contiene los registros de esta entrega y `SHA256_ARCHIVOS.json` los hashes del contenido.
