using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using MYG_2027;

internal static class DelphinCronogramaCheck
{
    private static void Exige(bool condicion, string mensaje)
    { if (!condicion) throw new Exception("Cronograma Delphin: " + mensaje); }
    private static string Huella(string ruta)
    { using var f = File.OpenRead(ruta); return Convert.ToHexString(SHA256.HashData(f)); }
    internal static void Ejecutar(string carpeta, Action<string> pasa)
    {
        Sintetica(pasa);
        string ruta = Environment.GetEnvironmentVariable("MYG_QA_LLACUSBAMBA_SQLITE");
        if (!string.IsNullOrWhiteSpace(ruta) && File.Exists(ruta)) Real(ruta, pasa);
    }
    private static ItemPresupuestoDelphin Item(string id, string nombre, string unidad, decimal precio = 0) => new()
    {
        Id = id, IdLocalMYG = id, IdInternoDelphin = id, Descripcion = nombre, Unidad = unidad,
        ParentId = id == "CU-R" ? null : "CU-R", TipoPropuesta = id == "CU-R" ? "TITULO" : "PARTIDA",
        Item = id, Costos = new() { Cantidad = id == "CU-R" ? 0 : 1, PrecioDirecto = precio }
    };
    private static void Sintetica(Action<string> pasa)
    {
        var p = new MYGPresupuestoDocumento { Id = "PP-QA", Nombre = "QA", Item = "1" };
        p.Items.AddRange(new[] { Item("CU-R", "Resumen", ""), Item("CU-A", "Movilización por tramos", "glb", 100), Item("CU-B", "Trabajo en sábado", "und") });
        p.Costos.Insumos.Add(new() { Id = "I-QA", Codigo = "I-QA", Descripcion = "Recurso QA", Precio = 100 });
        p.Items.Single(i => i.Id == "CU-A").Costos.Analisis.Add(new() { InsumoId = "I-QA", Cantidad = 1 });
        var doc = new MYGProyectoDocumento { Id = "PR-QA", Nombre = "QA", Presupuestos = new() { p }, PresupuestoActivoId = p.Id,
            Datos = new() { FechaInicio = new DateTime(2024, 12, 2), CalendarioId = 3 } };
        SQLiteDependencyBootstrapper.Initialize();
        using var c = new SqliteConnection("Data Source=:memory:"); c.Open();
        using (var cmd = c.CreateCommand())
        {
            cmd.CommandText = """
            CREATE TABLE costo_unitario(id_costounitario TEXT,duracion INTEGER,fecha_inicio TEXT,fecha_fin TEXT,porcentaje_completado NUMERIC);
            INSERT INTO costo_unitario VALUES('CU-A',2,'2024-12-03 08:00:00','2025-08-28 17:00:00',25),('CU-B',0,'2024-12-07 08:00:00','2024-12-07 17:00:00',0);
            CREATE TABLE programacion_costo(id_programacion TEXT,id_costounitario TEXT,start_date TEXT,end_date TEXT,duracion INTEGER,cantidad NUMERIC,porcentaje NUMERIC);
            INSERT INTO programacion_costo VALUES('PG-A1','CU-A','2024-12-03 00:00:00','2024-12-03 00:00:00',1,.5,50),('PG-A2','CU-A','2025-08-28 00:00:00','2025-08-28 00:00:00',1,.5,50),('PG-B','CU-B','2024-12-07 00:00:00','2024-12-07 00:00:00',0,1,100);
            CREATE TABLE dependencia_tarea(id_dependencia TEXT,id_costounitarioorigen TEXT,id_costounitariodestino TEXT,id_proyecto TEXT,tipo INTEGER,lag_size INTEGER);
            INSERT INTO dependencia_tarea VALUES('DP-1','CU-A','CU-B','PR-QA',1,-5),('DP-2','CU-R','CU-B','PR-QA',0,0);
            CREATE TABLE horario(id_calendario INTEGER,dia_semana INTEGER,hora_inicio TEXT,hora_fin TEXT,es_laborable TEXT);
            INSERT INTO horario VALUES(3,1,'1900-01-01 08:00:00','1900-01-01 12:00:00',NULL),(3,1,'1900-01-01 13:00:00','1900-01-01 17:00:00',NULL),(3,2,'1900-01-01 08:00:00','1900-01-01 17:00:00','S'),(3,3,'1900-01-01 08:00:00','1900-01-01 17:00:00','S'),(3,4,'1900-01-01 08:00:00','1900-01-01 17:00:00','S'),(3,5,'1900-01-01 08:00:00','1900-01-01 17:00:00','S');
            CREATE TABLE excepcion(id_calendario INTEGER,nombre_excepcion TEXT,tipo_excepcion INTEGER,dia_mes INTEGER,numero_mes INTEGER);
            INSERT INTO excepcion VALUES(3,'Navidad',4,25,12),(3,'Día del Trabajo',4,1,5);
            """;
            cmd.ExecuteNonQuery();
        }
        var plan = DelphinCronogramaMYG.Leer(c, doc); doc.Cronograma = plan;
        var r = MYGMotorCronograma.Calcular(plan);
        var a = r.Filas.Single(f => f.Tarea.PartidaId == "CU-A");
        var b = r.Filas.Single(f => f.Tarea.PartidaId == "CU-B");
        Exige(a.Inicio == new DateTime(2024, 12, 3) && a.Fin == new DateTime(2025, 8, 28) && a.DuracionDias == 2 &&
            a.Tarea.FechasImportadasDelphin.Tramos.Count == 2, "se unieron o desplazaron los dos tramos separados de una partida.");
        Exige(b.Inicio == new DateTime(2024, 12, 7) && b.Fin == b.Inicio, "se desplazó un trabajo manual nativo del sábado al lunes.");
        Exige(plan.VinculosImportadosDelphin.Count == 2 && plan.Tareas.Sum(t => t.Predecesoras.Count) == 1 &&
            r.Advertencias.Any(x => x.Contains("DP-2")), "no se conservó o explicó el vínculo nativo a un resumen.");
        Exige(plan.Calendario.HorasPorDia == 9 && !plan.Calendario.EsLaborable(new DateTime(2030, 12, 25)) &&
            !plan.Calendario.EsLaborable(new DateTime(2030, 5, 1)) && plan.Calendario.EsLaborable(new DateTime(2030, 5, 2)),
            "se perdieron la jornada o los feriados anuales al importar el calendario.");
        MYGMotorCronograma.EstablecerLineaBase(plan);
        var copia = MYGProyectoStorage.Copia(plan);
        Exige(copia.Tareas.Sum(t => t.FechasImportadasDelphin?.Tramos.Count ?? 0) == 3 && copia.VinculosImportadosDelphin.Count == 2 && copia.Calendario.FeriadosAnuales.Count == 2,
            "editar o copiar el cronograma perdió sus tramos, vínculos o feriados nativos.");
        var tareaA = plan.Tareas.Single(t => t.PartidaId == "CU-A"); tareaA.DuracionDias = 3;
        Exige(!MYGMotorCronograma.ConservaFechasDelphin(tareaA) && MYGMotorCronograma.Calcular(plan).Filas.Single(f => f.Tarea.Id == tareaA.Id).Fin == new DateTime(2024, 12, 5),
            "editar la duración siguió imponiendo las fechas importadas anteriores.");
        tareaA.DuracionDias = 2;
        var valorados = MYGReportesCronograma.CrearValorizado(doc, plan);
        var filaA = valorados.SelectMany(h => h.Hoja.Celdas.Where(kv => kv.Value.Contenido == "Movilización por tramos").Select(kv => (h.Hoja, Fila: MYGHojaCalculo.Coordenadas(kv.Key).Fila))).ToList();
        decimal total = 0; int mesesConCosto = 0;
        foreach (var (hoja, fila) in filaA)
        {
            for (int col = 5; col <= hoja.Columnas; col++)
                if (decimal.TryParse(hoja.Celdas.GetValueOrDefault(MYGHojaCalculo.Columna(col) + fila)?.Contenido, NumberStyles.Any, CultureInfo.InvariantCulture, out var importe) && importe != 0)
                { Exige(importe == 50, "el reparto de un tramo no respetó su 50 %."); total += importe; mesesConCosto++; }
        }
        Exige(total == 100 && mesesConCosto == 2, "se cargó costo en los meses sin trabajo de la partida segmentada.");
        decimal cantidad = 0; int mesesConRecurso = 0;
        foreach (var reporte in MYGReportesCronograma.CrearAdquisiciones(doc, plan))
        {
            var hoja = reporte.Hoja;
            foreach (int fila in hoja.Celdas.Where(kv => kv.Value.Contenido == "Recurso QA").Select(kv => MYGHojaCalculo.Coordenadas(kv.Key).Fila))
                for (int col = 9; col <= hoja.Columnas; col++)
                    if (decimal.TryParse(hoja.Celdas.GetValueOrDefault(MYGHojaCalculo.Columna(col) + fila)?.Contenido, NumberStyles.Any, CultureInfo.InvariantCulture, out var unidades) && unidades != 0)
                    { Exige(unidades == .5m, "se programó todo el recurso en uno de los dos tramos al 50 %."); cantidad += unidades; mesesConRecurso++; }
        }
        Exige(cantidad == 1 && mesesConRecurso == 2, "se perdieron o duplicaron recursos al programar las adquisiciones por tramos.");
        pasa("Cronograma Delphin conserva fechas manuales, tramos separados y vínculos originales, señala vínculos a resúmenes y reparte cada tramo sin cargar el intervalo vacío");
    }
    private static void Real(string ruta, Action<string> pasa)
    {
        string antes = Huella(ruta);
        var doc = MYGBaseDatos.LeerProyecto(ruta); var plan = doc.Cronograma;
        Exige(plan != null && plan.Tareas.Count(t => !t.EsResumen) == 658, "faltan partidas programadas de LLACUSBAMBA.");
        Exige(plan.Tareas.Sum(t => t.FechasImportadasDelphin?.Tramos.Count ?? 0) == 659 && plan.VinculosImportadosDelphin.Count == 641 &&
            plan.Tareas.Sum(t => t.Predecesoras.Count) == 640, "no se conservaron los 659 tramos y 641 vínculos reales (640 calculables entre hojas).");
        var resultado = MYGMotorCronograma.Calcular(plan);
        Exige(resultado.Inicio == new DateTime(2024, 12, 2) && resultado.Fin == new DateTime(2025, 8, 28), "cambió el rango de programación original.");
        var partida = resultado.Filas.Single(f => f.Tarea.PartidaId == "CU0000000024");
        Exige(partida.Inicio == new DateTime(2024, 12, 3) && partida.Fin == new DateTime(2025, 8, 28) && partida.DuracionDias == 2 &&
            partida.Tarea.FechasImportadasDelphin.Tramos.All(t => t.Porcentaje == 50), "se perdió la movilización en dos tramos al 50 %.");
        Exige(plan.Calendario.HorasPorDia == 8 && plan.Calendario.FeriadosAnuales.Count == 2 && resultado.Advertencias.Any(x => x.Contains("DP0000000252")),
            "faltan el calendario o la advertencia del vínculo nativo a resumen.");
        Exige(Huella(ruta) == antes, "la consulta del cronograma modificó la base del usuario.");
        pasa("LLACUSBAMBA: 658 partidas, 659 tramos, 641 vínculos originales, 640 calculables, fechas 02/12/2024–28/08/2025 y calendario anual conservados sin modificar el SQLite");
    }
}
