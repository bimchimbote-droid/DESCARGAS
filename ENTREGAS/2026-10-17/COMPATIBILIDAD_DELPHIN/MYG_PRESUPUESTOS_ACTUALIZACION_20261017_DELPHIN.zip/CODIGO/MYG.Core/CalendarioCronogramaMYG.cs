using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MYG_2027;

public sealed class MYGFeriadoAnual
{
    public int Mes { get; set; }
    public int Dia { get; set; }
}

public sealed class MYGCalendarioTrabajo
{
    public List<DayOfWeek> DiasLaborables { get; set; } = new()
    { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday };
    public List<DateTime> Feriados { get; set; } = new();
    public List<MYGFeriadoAnual> FeriadosAnuales { get; set; } = new();
    public decimal HorasPorDia { get; set; } = 8;

    public bool EsLaborable(DateTime fecha) => DiasLaborables != null && Feriados != null &&
        DiasLaborables.Contains(fecha.DayOfWeek) && !Feriados.Any(f => f.Date == fecha.Date) &&
        !(FeriadosAnuales?.Any(f => f.Mes == fecha.Month && f.Dia == fecha.Day) ?? false);
    public DateTime SiguienteLaborable(DateTime fecha)
    { var c = new MYGCalendarioEntero(this); return c.Fecha(c.Primero(fecha)); }
    public DateTime SumarDiasLaborables(DateTime fecha, int dias)
    { var c = new MYGCalendarioEntero(this); return c.Fecha(c.Primero(fecha) + dias); }
    public int ContarDiasLaborables(DateTime inicio, DateTime fin)
    { var c = new MYGCalendarioEntero(this); return c.Contar(inicio, fin); }
}

// Ordinal absoluto de día laborable, independiente del inicio del proyecto.
// Conteo por semanas + búsqueda binaria de feriados/fechas: un desfase enorme
// se rechaza por rango sin recorrer miles de millones de días.
internal sealed class MYGCalendarioEntero
{
    private const int UltimoDia = 3652058;
    private readonly HashSet<DayOfWeek> semana;
    private readonly int[] feriados;
    private readonly int total;
    internal MYGCalendarioEntero(MYGCalendarioTrabajo calendario)
    {
        if (calendario == null || calendario.DiasLaborables == null || calendario.Feriados == null ||
            calendario.DiasLaborables.Count == 0 || calendario.DiasLaborables.Any(d => !Enum.IsDefined(d)) ||
            calendario.DiasLaborables.Distinct().Count() != calendario.DiasLaborables.Count ||
            calendario.HorasPorDia <= 0 || calendario.HorasPorDia > 24)
            throw new InvalidDataException("El calendario requiere días laborables únicos y una jornada mayor que cero y de hasta 24 horas.");
        semana = calendario.DiasLaborables.ToHashSet();
        var anuales = calendario.FeriadosAnuales ?? new();
        if (anuales.Any(f => f == null || f.Mes < 1 || f.Mes > 12 || f.Dia < 1 || f.Dia > DateTime.DaysInMonth(2000, f.Mes)))
            throw new InvalidDataException("El calendario contiene un feriado anual no válido.");
        var fechas = calendario.Feriados.ToList();
        foreach (var f in anuales)
            for (int anio = 1; anio <= 9999; anio++)
                if (f.Dia <= DateTime.DaysInMonth(anio, f.Mes)) fechas.Add(new DateTime(anio, f.Mes, f.Dia));
        feriados = fechas.Where(f => semana.Contains(f.DayOfWeek)).Select(Dia).Distinct().Order().ToArray();
        total = Hasta(UltimoDia);
        if (total == 0) throw new InvalidDataException("El calendario no contiene ningún día laborable disponible.");
    }
    private static int Dia(DateTime fecha) => (int)(fecha.Date.Ticks / TimeSpan.TicksPerDay);
    private int Hasta(int dia)
    {
        if (dia < 0) return 0;
        int dias = dia + 1, cantidad = dias / 7 * semana.Count;
        for (int n = 0; n < dias % 7; n++)
            if (semana.Contains((DayOfWeek)((n + 1) % 7))) cantidad++;
        int inferior = 0, superior = feriados.Length;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (feriados[medio] <= dia) inferior = medio + 1; else superior = medio; }
        return cantidad - inferior;
    }
    internal long Primero(DateTime fecha) => Hasta(Dia(fecha) - 1) + 1L;
    internal long Despues(DateTime fecha) => Hasta(Dia(fecha)) + 1L;
    internal long AnteriorOIgual(DateTime fecha) => Hasta(Dia(fecha));
    internal int Contar(DateTime inicio, DateTime fin) => fin.Date < inicio.Date ? 0 : Hasta(Dia(fin)) - Hasta(Dia(inicio) - 1);
    internal DateTime Fecha(long ordinal)
    {
        if (ordinal < 1 || ordinal > total)
            throw new InvalidDataException("Las fechas del cronograma exceden el rango permitido. Revise duraciones y desfases.");
        int inferior = 0, superior = UltimoDia;
        while (inferior < superior)
        { int medio = inferior + (superior - inferior) / 2; if (Hasta(medio) < ordinal) inferior = medio + 1; else superior = medio; }
        return new DateTime((long)inferior * TimeSpan.TicksPerDay);
    }
}
