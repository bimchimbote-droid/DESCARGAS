using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private bool cambiandoPresupuestoEstructura;
    // Copias internas independientes del documento: no contienen credenciales de sesión.
    private static MYGPresupuestoDocumento copiaEstructura;
    private static bool copiaEsPresupuesto;

    private MYGPresupuestoDocumento PropietarioEstructura(object nodo) => nodo is MYGPresupuestoDocumento p
        ? documento.Presupuestos.FirstOrDefault(x => x.Id == p.Id)
        : nodo is ItemPresupuestoDelphin i ? documento.Presupuestos.FirstOrDefault(x => x.Items.Any(h => ReferenceEquals(h, i)))
            ?? documento.Presupuestos.FirstOrDefault(x => x.Items.Any(h => h.Id == i.Id)) : null;
    private ItemPresupuestoDelphin NodoEstructura(object nodo) => nodo is ItemPresupuestoDelphin i
        ? PropietarioEstructura(i)?.Items.FirstOrDefault(x => x.Id == i.Id) : null;

    private void ActivarPresupuestoEstructura(string id)
    {
        if (id != null && documento.PresupuestoActivoId != id)
        {
            Sincronizar(); documento.PresupuestoActivoId = id;
            cambiandoPresupuestoEstructura = true;
            try { Refrescar(); }
            finally { cambiandoPresupuestoEstructura = false; }
        }
        grid.ClearSelection(); grid.CurrentCell = null;
    }

    internal void AgregarPresupuestoEnTabla(MYGPresupuestoDocumento antesDe = null)
    {
        if (!sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para agregar un presupuesto.");
        var parametros = MYGParametrosUsuario.Leer();
        Sincronizar(); Recordar();
        var nuevo = MYGEstructuraPresupuestos.AgregarPresupuesto(documento, antesDe);
        parametros.Aplicar(nuevo);
        Refrescar(); espacioPresupuestos.SelectedIndex = 0;
        panelPresupuesto.SeleccionarEstructura(nuevo, editarNombre: true);
    }

    private void InsertarEnEstructura(bool titulo, int modo = 0)
    {
        var contexto = panelPresupuesto.SeleccionEstructura;
        var p = PropietarioEstructura(contexto) ?? P;
        if (p == null) throw new InvalidOperationException("Agregue primero un presupuesto con clic derecho en el espacio vacío.");
        var i = NodoEstructura(contexto);
        string padre = modo == 0 && MYGProyectoStorage.EsTitulo(i) ? i.Id : i?.ParentId;
        var parametros = titulo ? null : MYGParametrosUsuario.Leer();
        Recordar(); var nuevo = MYGEstructuraPresupuestos.InsertarNodo(p, titulo, padre, modo == 1 ? i?.Id : null);
        if (!titulo) parametros.Aplicar(nuevo);
        documento.PresupuestoActivoId = p.Id; Refrescar(); panelPresupuesto.SeleccionarEstructura(nuevo, editarNombre: true);
    }

    private void MoverFilaEstructura(object contexto, int sentido)
    {
        if (ocupado) return;
        if (!sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para mover filas del presupuesto.");
        Sincronizar();
        if (!MYGOrdenPresupuestos.PuedeMover(documento, contexto, sentido)) return;
        var prueba = MYGProyectoStorage.Copia(documento);
        object copia = contexto is MYGPresupuestoDocumento presupuestoNodo
            ? prueba.Presupuestos.Single(p => p.Id == presupuestoNodo.Id)
            : prueba.Presupuestos.Single(p => p.Id == PropietarioEstructura(contexto).Id).Items.Single(i => i.Id == ((ItemPresupuestoDelphin)contexto).Id);
        MYGOrdenPresupuestos.Mover(prueba, copia, sentido);
        Recordar(); MYGOrdenPresupuestos.Mover(documento, contexto, sentido);
        Refrescar(); panelPresupuesto.SeleccionarEstructura(contexto);
        estado.Text = "Fila movida. Se conservan códigos, jerarquía y datos. Use Guardar para conservar el orden en la base de datos.";
    }

    private void EditarCeldaEstructura(object contexto, string columna, string valor)
    {
        if (!sesion.Autorizado) throw new InvalidOperationException("Inicie sesión para editar el presupuesto.");
        valor = valor?.Trim();
        if (string.IsNullOrWhiteSpace(valor)) throw new InvalidOperationException("El código y la descripción no pueden estar vacíos.");
        var p = PropietarioEstructura(contexto) ?? throw new InvalidOperationException("La fila ya no existe.");
        var i = NodoEstructura(contexto);
        if (columna is "CANT" or "UND")
        {
            if (i == null) throw new InvalidOperationException("Seleccione una partida.");
            decimal cantidad = 0;
            if (columna == "CANT")
            {
                if (!MYGFormatoPresupuesto.IntentarCantidad(valor, out cantidad)) throw new InvalidOperationException("Escriba una cantidad entre 0 y 1,000,000,000,000, con hasta dos decimales. Ejemplo: 1,234.56.");
                if (i.Costos.FuenteMetrado == MYGFuenteMetrado.Cantidad && i.Costos.Cantidad == cantidad) return;
                MYGEdicionPartida.CambiarCantidad(p, i, cantidad, Recordar);
            }
            else
            {
                if (string.Equals(i.Unidad, valor, StringComparison.Ordinal)) return;
                MYGEdicionPartida.CambiarUnidad(p, i, valor, Recordar);
                i.EstadoRevit = null; i.MensajeRevit = null;
                var filaUnidad = grid.Rows.Cast<WinForms.DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin n && n.Id == i.Id);
                if (filaUnidad != null) filaUnidad.Cells["UNIDAD"].Value = i.Unidad;
            }
            estado.Text = columna == "CANT" ? "Cantidad directa actualizada. Se conservan los metrados de origen en sus pestañas." : "Unidad de la partida actualizada.";
            ActualizarResumen(); return;
        }
        if (i != null && !string.IsNullOrWhiteSpace(i.IdInternoDelphin))
            throw new InvalidOperationException("Esta fila es oficial de Delphin. Sus datos se actualizan desde la base de origen.");
        if (columna == "ITEM")
        {
            bool repetido = i == null ? documento.Presupuestos.Any(x => x.Id != p.Id && string.Equals(x.Item, valor, StringComparison.OrdinalIgnoreCase))
                : p.Items.Any(x => x.Id != i.Id && string.Equals(x.Item, valor, StringComparison.OrdinalIgnoreCase));
            if (repetido) throw new InvalidOperationException("Ese código ya está en uso.");
        }
        string anterior = i == null ? columna == "ITEM" ? p.Item : p.Nombre : columna == "ITEM" ? i.Item : i.Descripcion;
        if (anterior == valor) return;
        Recordar();
        if (i == null) { if (columna == "ITEM") p.Item = valor; else p.Nombre = valor; presupuesto.Refresh(); }
        else
        {
            if (columna == "ITEM") i.Item = valor; else i.Descripcion = valor;
            i.EstadoRevit = null; i.MensajeRevit = null;
            // Mantener la tabla BIM sincronizada sin reconstruirla durante CellValidating.
            var fila = grid.Rows.Cast<WinForms.DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin n && n.Id == i.Id);
            if (fila != null) fila.Cells[columna == "ITEM" ? "ITEM" : "PARTIDA"].Value = valor;
        }
        ActualizarResumen();
    }

    // Consultar la lista nunca guarda el proyecto ni abre un diálogo durante la edición de una celda.
    private IEnumerable<MYGUnidadCatalogo> UnidadesEstructura()
    {
        string ruta = string.IsNullOrWhiteSpace(archivo) ? null : MYGBaseDatos.RutaDeProyecto(archivo);
        if (ruta != null && File.Exists(ruta))
        {
            try { return MYGCatalogoUnidades.Listar(ruta); }
            catch (Exception ex) { estado.Text = "No se pudo consultar el catálogo de unidades: " + ex.Message; }
        }
        return new[] { ("und", "Unidad"), ("m", "Metro lineal"), ("m2", "Metro cuadrado"), ("m3", "Metro cúbico"),
            ("kg", "Kilogramo"), ("t", "Tonelada"), ("l", "Litro"), ("glb", "Global"), ("hh", "Hora hombre"), ("hm", "Hora máquina"), ("día", "Día"), ("mes", "Mes") }
            .Select(u => new MYGUnidadCatalogo { Simbolo = u.Item1, Descripcion = u.Item2 });
    }

    private void MenuEstructura(object contexto)
    {
        var m = CrearMenuContextual(); var p = PropietarioEstructura(contexto); var i = NodoEstructura(contexto);
        if (contexto == null)
        {
            ItemMenu(m, "Agregar presupuesto", () => AgregarPresupuestoEnTabla());
            ItemMenu(m, "Editar numeración", () => EditarNumeracionEstructura(null));
            m.Items[^1].Enabled = documento.Presupuestos.Count > 0;
            ItemMenu(m, "Restablecer numeración", () => RestablecerNumeracion(null));
            m.Items[^1].Enabled = documento.Presupuestos.Count > 0;
            if (copiaEstructura != null && copiaEsPresupuesto) ItemMenu(m, "Pegar presupuesto", () => PegarEstructura(null, true));
            MostrarMenu(m); return;
        }
        if (i == null)
        {
            ItemMenu(m, "Insertar título", () => InsertarEnEstructura(true));
            ItemMenu(m, "Agregar presupuesto sobre la selección", () => AgregarPresupuestoEnTabla(PropietarioEstructura(contexto)));
            ItemMenu(m, "Agregar presupuesto al final", () => AgregarPresupuestoEnTabla());
            ItemMenu(m, "Insertar costo unitario", () => InsertarEnEstructura(false));
        }
        else
        {
            bool titulo = MYGProyectoStorage.EsTitulo(i);
            if (titulo) ItemMenu(m, "Insertar subtítulo", () => InsertarEnEstructura(true));
            ItemMenu(m, "Agregar título sobre la selección", () => InsertarEnEstructura(true, 1));
            ItemMenu(m, "Agregar título al final", () => InsertarEnEstructura(true, 2));
            ItemMenu(m, "Insertar costo unitario", () => InsertarEnEstructura(false));
            ItemMenu(m, "Agregar costo unitario sobre la selección", () => InsertarEnEstructura(false, 1));
            ItemMenu(m, "Agregar costo unitario al final", () => InsertarEnEstructura(false, 2));
        }
        m.Items.Add(new WinForms.ToolStripSeparator());
        ItemMenu(m, "Copiar", () => CopiarEstructura(contexto));
        ItemMenu(m, "Pegar", () => PegarEstructura(contexto, true)); m.Items[^1].Enabled = copiaEstructura != null;
        var especial = new WinForms.ToolStripMenuItem("Pegado especial");
        ItemSubmenu(especial, "Sin metrados", () => PegarEstructura(contexto, false));
        especial.Enabled = copiaEstructura != null; m.Items.Add(especial);
        ItemMenu(m, "Eliminar", () => EliminarEstructura(contexto));
        ItemMenu(m, "Eliminar metrados", () => EliminarMetradosEstructura(contexto));
        var ins = new WinForms.ToolStripMenuItem("Actualizar insumos");
        ItemSubmenu(ins, "De la selección desde catálogo MYG", () => ActualizarCatalogosEstructura(contexto, false));
        ItemSubmenu(ins, "De todo el presupuesto desde catálogo MYG", () => ActualizarCatalogosEstructura(p, false)); m.Items.Add(ins);
        var costos = new WinForms.ToolStripMenuItem("Actualizar costos unitarios");
        ItemSubmenu(costos, "De la selección desde catálogo MYG", () => ActualizarCatalogosEstructura(contexto, true));
        ItemSubmenu(costos, "De todo el presupuesto desde catálogo MYG", () => ActualizarCatalogosEstructura(p, true)); m.Items.Add(costos);
        ItemMenu(m, "Recalcular", () => { MYGProyectoStorage.ValidarPresupuesto(PropietarioEstructura(contexto)); Refrescar(); });
        if (MYGProyectoStorage.EsTitulo(i)) ItemMenu(m, "Convertir título a presupuesto", () => ConvertirTituloEstructura(contexto));
        ItemMenu(m, "Editar numeración", () => EditarNumeracionEstructura(contexto));
        if (i != null) ItemMenu(m, "Continuar numeración", () => ContinuarNumeracionEstructura(contexto));
        ItemMenu(m, "Restablecer numeración", () => RestablecerNumeracion(contexto));
        var responsables = new WinForms.ToolStripMenuItem("Responsables");
        ItemSubmenu(responsables, "Asignar responsable…", () => AsignarResponsable(contexto));
        ItemSubmenu(responsables, "Ver responsables…", () => VerResponsables(contexto));
        ItemSubmenu(responsables, "Quitar responsable…", () => QuitarResponsable(contexto)); m.Items.Add(responsables);
        MostrarMenu(m);
    }

    private void ItemSubmenu(WinForms.ToolStripMenuItem padre, string titulo, Action accion)
    {
        var item = new WinForms.ToolStripMenuItem(titulo);
        item.Click += (s, e) =>
        {
            if (IsDisposed || Disposing || !IsHandleCreated) return;
            BeginInvoke(new Action(async () => { if (!IsDisposed && !Disposing) await Ejecutar(() => { accion(); return Task.CompletedTask; }); }));
        };
        padre.DropDownItems.Add(item);
    }

    private List<ItemPresupuestoDelphin> AlcanceEstructura(object contexto)
    {
        var p = PropietarioEstructura(contexto) ?? throw new InvalidOperationException("Seleccione un presupuesto.");
        var i = NodoEstructura(contexto); return i == null ? p.Items.ToList() : MYGEstructuraPresupuestos.Rama(p, i);
    }
    private void CopiarEstructura(object contexto)
    {
        var p = PropietarioEstructura(contexto);
        copiaEstructura = MYGEstructuraPresupuestos.CopiarRama(p, NodoEstructura(contexto));
        copiaEsPresupuesto = contexto is MYGPresupuestoDocumento;
        estado.Text = "Copiado. Use Pegar o Pegado especial en la tabla de presupuestos.";
    }
    private void PegarEstructura(object contexto, bool conMetrados)
    {
        if (copiaEstructura == null) return;
        var p = PropietarioEstructura(contexto); var i = NodoEstructura(contexto);
        if (!copiaEsPresupuesto && p == null) throw new InvalidOperationException("Seleccione el presupuesto de destino.");
        Recordar();
        if (copiaEsPresupuesto)
        {
            var trabajo = MYGProyectoStorage.Copia(documento);
            var anterior = p == null ? null : trabajo.Presupuestos.First(x => x.Id == p.Id);
            var nuevo = MYGEstructuraPresupuestos.AgregarPresupuesto(trabajo, anterior);
            nuevo.Nombre = copiaEstructura.Nombre + " (copia)";
            nuevo.Costos = MYGProyectoStorage.Copia(copiaEstructura.Costos); nuevo.Costos.Insumos.Clear();
            MYGEstructuraPresupuestos.PegarRama(nuevo, copiaEstructura, conMetrados: conMetrados);
            MYGProyectoStorage.Validar(trabajo); documento = trabajo;
            Refrescar(); panelPresupuesto.SeleccionarEstructura(nuevo); return;
        }
        var nuevos = MYGEstructuraPresupuestos.PegarRama(p, copiaEstructura,
            MYGProyectoStorage.EsTitulo(i) ? i.Id : i?.ParentId, conMetrados: conMetrados);
        Refrescar(); if (nuevos.Count > 0) panelPresupuesto.SeleccionarEstructura(nuevos[0]);
    }
    private void EliminarEstructura(object contexto)
    {
        var p = PropietarioEstructura(contexto); var i = NodoEstructura(contexto);
        if (p == null) return;
        if (WinForms.MessageBox.Show(this, i == null ? "¿Eliminar este presupuesto y todas sus filas?" : "¿Eliminar esta fila y sus descendientes?",
            "Eliminar", WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question) != WinForms.DialogResult.Yes) return;
        Recordar();
        if (i == null)
        {
            documento.Presupuestos.Remove(p);
            documento.PresupuestoActivoId = documento.Presupuestos.OrderBy(x => x.Posicion).FirstOrDefault()?.Id;
            MYGEstructuraPresupuestos.RenumerarPresupuestos(documento);
        }
        else MYGEstructuraPresupuestos.EliminarNodo(p, i);
        Refrescar();
    }
    private void EliminarMetradosEstructura(object contexto)
    {
        if (WinForms.MessageBox.Show(this, "¿Eliminar las cantidades y los metrados manuales, BIM y Excel de la selección? Se conservarán sus costos unitarios.",
            "Eliminar metrados", WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question) != WinForms.DialogResult.Yes) return;
        Recordar(); MYGEstructuraPresupuestos.EliminarMetrados(PropietarioEstructura(contexto), AlcanceEstructura(contexto)); Refrescar();
    }
    private void ConvertirTituloEstructura(object contexto)
    {
        Recordar(); var nuevo = MYGEstructuraPresupuestos.ConvertirTitulo(documento, PropietarioEstructura(contexto), NodoEstructura(contexto));
        Refrescar(); panelPresupuesto.SeleccionarEstructura(nuevo);
    }
    private void ActualizarCatalogosEstructura(object contexto, bool costos)
    {
        var p = PropietarioEstructura(contexto); var alcance = AlcanceEstructura(contexto); string ruta = RutaCatalogoPropio();
        // El primer guardado puede reemplazar los objetos del documento; resolver de nuevo.
        p = documento.Presupuestos.First(x => x.Id == p.Id);
        var ids = alcance.Select(x => x.Id).ToHashSet(); alcance = p.Items.Where(x => ids.Contains(x.Id)).ToList();
        Recordar(); int n = costos ? MYGEstructuraPresupuestos.ActualizarCostosUnitarios(p, alcance, ruta)
            : MYGEstructuraPresupuestos.ActualizarInsumos(p, alcance, ruta);
        Refrescar(); WinForms.MessageBox.Show(this, n == 0 ? "La selección no contiene referencias actualizables del catálogo MYG de esta base."
            : n + (costos ? " costo(s) unitario(s) actualizado(s)." : " insumo(s) actualizado(s)."), "Actualizar desde catálogo MYG");
    }
    private void EditarNumeracionEstructura(object contexto)
    {
        if (contexto != null)
        {
            var p = PropietarioEstructura(contexto); var i = NodoEstructura(contexto);
            using var d = new MYGCamposProyectoForm("Editar numeración", new[] { "Código" }, new[] { i?.Item ?? p.Item });
            if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
            EditarCeldaEstructura(contexto, "ITEM", d.Valores[0]); Refrescar(); return;
        }
        var presupuestos = documento.Presupuestos.OrderBy(x => x.Posicion).ToList();
        using var dialogo = new MYGCamposProyectoForm("Editar numeración de presupuestos", presupuestos.Select(x => x.Nombre).ToArray(), presupuestos.Select(x => x.Item).ToArray());
        if (dialogo.ShowDialog(this) != WinForms.DialogResult.OK) return;
        if (dialogo.Valores.Distinct(StringComparer.OrdinalIgnoreCase).Count() != presupuestos.Count)
            throw new InvalidOperationException("Los códigos de presupuesto deben ser distintos.");
        Recordar(); for (int n = 0; n < presupuestos.Count; n++) presupuestos[n].Item = dialogo.Valores[n]; Refrescar();
    }
    private void RestablecerNumeracion(object contexto)
    {
        var p = PropietarioEstructura(contexto);
        var presupuestos = p == null ? documento.Presupuestos.ToList() : new List<MYGPresupuestoDocumento> { p };
        if (presupuestos.Any(x => x.Conexion != null || x.Items.Any(i => !string.IsNullOrWhiteSpace(i.IdInternoDelphin))))
            throw new InvalidOperationException("Se conserva la numeración oficial de Delphin. Renumere únicamente presupuestos MYG sin conexión oficial.");
        Recordar(); if (p == null) MYGEstructuraPresupuestos.RenumerarPresupuestos(documento);
        foreach (var presupuesto in presupuestos) MYGProyectoStorage.Renumerar(presupuesto); Refrescar();
    }
    private void ContinuarNumeracionEstructura(object contexto)
    {
        var p = PropietarioEstructura(contexto); var i = NodoEstructura(contexto);
        if (i == null) return;
        if (p.Conexion != null || p.Items.Any(x => !string.IsNullOrWhiteSpace(x.IdInternoDelphin)))
            throw new InvalidOperationException("Se conserva la numeración oficial de Delphin.");
        var hermanos = p.Items.Where(x => x.ParentId == i.ParentId).OrderBy(x => x.Posicion).ThenBy(x => x.Item).ToList();
        int desde = hermanos.IndexOf(i); var anterior = desde > 0 ? hermanos[desde - 1].Item : null;
        string prefijo = !string.IsNullOrWhiteSpace(i.ParentId) ? p.Items.First(x => x.Id == i.ParentId).Item + "." : "";
        int numero = 0;
        if (anterior != null)
        {
            int punto = anterior.LastIndexOf('.'); prefijo = punto >= 0 ? anterior[..(punto + 1)] : "";
            if (!int.TryParse(anterior[(punto + 1)..], NumberStyles.None, CultureInfo.InvariantCulture, out numero))
                throw new InvalidOperationException("La numeración anterior debe terminar en un número.");
        }
        var copia = MYGProyectoStorage.Copia(p);
        void NumerarHijos(ItemPresupuestoDelphin padre)
        {
            int n = 0;
            foreach (var hijo in copia.Items.Where(x => x.ParentId == padre.Id).OrderBy(x => x.Posicion).ThenBy(x => x.Item))
            { hijo.Item = padre.Item + "." + (++n).ToString("D2"); NumerarHijos(hijo); }
        }
        foreach (var hermano in hermanos.Skip(desde))
        { var nodo = copia.Items.First(x => x.Id == hermano.Id); nodo.Item = prefijo + (++numero).ToString("D2"); NumerarHijos(nodo); }
        if (copia.Items.Select(x => x.Item).Distinct(StringComparer.OrdinalIgnoreCase).Count() != copia.Items.Count)
            throw new InvalidOperationException("Continuar desde ese código produce números repetidos. Edite el código anterior o restablezca la numeración.");
        Recordar(); p.Items = copia.Items; Refrescar();
    }
    private List<MYGResponsablePresupuesto> ResponsablesEstructura(object contexto)
    {
        var i = NodoEstructura(contexto); var p = PropietarioEstructura(contexto);
        return i != null ? i.Costos.Responsables ??= new() : p.Costos.Responsables ??= new();
    }
    private void AsignarResponsable(object contexto)
    {
        using var d = new MYGCamposProyectoForm("Asignar responsable", new[] { "Nombre", "Cargo o función" }, new[] { "", "Responsable" });
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        Recordar(); ResponsablesEstructura(contexto).Add(new() { Nombre = d.Valores[0], Cargo = d.Valores[1] }); Refrescar();
    }
    private void VerResponsables(object contexto)
    {
        var lista = ResponsablesEstructura(contexto);
        WinForms.MessageBox.Show(this, lista.Count == 0 ? "No hay responsables asignados a esta fila." : string.Join(Environment.NewLine, lista), "Responsables");
    }
    private void QuitarResponsable(object contexto)
    {
        var lista = ResponsablesEstructura(contexto); if (lista.Count == 0) return;
        using var d = new MYGElegirCostoForm("Quitar responsable", lista.Cast<object>().ToArray());
        if (d.ShowDialog(this) != WinForms.DialogResult.OK) return;
        Recordar(); lista.Remove((MYGResponsablePresupuesto)d.Elegido); Refrescar();
    }
}
