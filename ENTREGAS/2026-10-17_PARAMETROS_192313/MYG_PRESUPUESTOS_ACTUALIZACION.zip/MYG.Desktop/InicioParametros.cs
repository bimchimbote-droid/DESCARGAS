using System;
using System.Windows.Forms;

namespace MYG_2027;

public sealed partial class InicioForm
{
    private Control CrearBarraParametrosInicio()
    {
        var barra = new Panel
        {
            Name = "barraParametrosInicio", Dock = DockStyle.Top, Height = 54,
            Padding = new Padding(22, 4, 24, 4), BackColor = MYG2027_TemaComercial.Superficie
        };
        var identidad = MYGParametrosAplicacionUI.CrearIdentidadEmpresa();
        identidad.Dock = DockStyle.Fill;
        var boton = MYGProyectoUI.Boton("Parámetros predeterminados");
        boton.Name = "parametrosPredeterminadosInicio";
        boton.AccessibleName = "Configurar parámetros predeterminados";
        boton.AccessibleDescription = "Configura presupuestos, costos, ubicación, aceros, colores y empresa.";
        boton.Dock = DockStyle.Right; boton.Width = 255;
        MYGAnimacionUI.PrepararBoton(boton);
        boton.Click += (_, _) =>
        {
            if (ocupado || IsDisposed) return;
            try
            {
                using var ventana = new MYGParametrosPredeterminadosForm(rutaBase);
                if (ventana.ShowDialog(this) == DialogResult.OK) MYGParametrosAplicacionUI.Actualizar();
            }
            catch (Exception ex) { MYGProyectoUI.Error(this, ex); }
        };
        barra.Controls.Add(identidad); barra.Controls.Add(boton);
        return barra;
    }
}
