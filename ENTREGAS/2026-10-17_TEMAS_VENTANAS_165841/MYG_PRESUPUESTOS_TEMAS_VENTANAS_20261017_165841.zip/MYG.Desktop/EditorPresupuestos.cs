using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MYG_2027;

internal sealed partial class EditorForm
{
    private MYGPanelPresupuesto panelPresupuesto;
    private TabControl espacioPresupuestos;
    private FlowLayoutPanel cintaPresupuestos;
    private Label nombreProyectoPresupuesto;
    private void InicializarPresupuestos()
    {
        Text = "MYG | Presupuestos y metrados BIM";
        var exterior = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Margin = new(0), Padding = new(0), BackColor = MYGPanelPresupuesto.AzulClaro };
        exterior.ColumnStyles.Add(new(SizeType.Percent, 100)); exterior.RowStyles.Add(new(SizeType.Absolute, 98));
        exterior.RowStyles.Add(new(SizeType.Absolute, 36)); exterior.RowStyles.Add(new(SizeType.Percent, 100));
        cintaPresupuestos = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, AutoScroll = true, Padding = new(4), Margin = new(0), BackColor = MYG2027_TemaComercial.Fondo };
        cintaPresupuestos.Name = "herramientas_proyecto";
        Button Accion(string icono, string titulo, Action accion, bool necesitaLicencia = true)
        {
            var b = CrearBotonCintaProyecto(icono, titulo, necesitaLicencia);
            b.Click += async (s, e) => await Ejecutar(() => { accion(); return System.Threading.Tasks.Task.CompletedTask; }, necesitaLicencia);
            cintaPresupuestos.Controls.Add(b); return b;
        }
        InicializarHerramientasProyecto(Accion);
        var seleccion = new Panel { Name = "cabecera_proyecto", Dock = DockStyle.Fill, Margin = new(0), Padding = new(8, 3, 4, 0), BackColor = MYG2027_TemaComercial.AzulSuave };
        // El presupuesto activo se elige desde la estructura; la cabecera
        // reserva todo el ancho para identificar el proyecto.
        nombreProyectoPresupuesto = new Label { Name = "nombre_proyecto_cabecera", Text = documento.Nombre, Dock = DockStyle.Fill,
            AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft, Font = new("Segoe UI", 9, FontStyle.Bold), Margin = new(0) };
        seleccion.Controls.Add(nombreProyectoPresupuesto);
        espacioPresupuestos = new TabControl { Dock = DockStyle.Fill, Alignment = TabAlignment.Bottom, Margin = new(0) };
        var principal = new TabPage("Presupuesto") { Padding = new(0), BackColor = MYG2027_TemaComercial.Superficie };
        var bim = new TabPage("Configuración BIM / Revit") { Padding = new(0), BackColor = MYG2027_TemaComercial.Superficie };
        Controls.Remove(raiz); bim.Controls.Add(raiz); espacioPresupuestos.TabPages.AddRange(new[] { principal, bim });
        panelPresupuesto = new MYGPanelPresupuesto(() => P, Recordar, ActualizarResumen,
            id =>
            {
                var fila = grid.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is ItemPresupuestoDelphin i && i.Id == id);
                if (fila == null) return; grid.ClearSelection();
                if (!fila.Visible) fila.Visible = true;
                grid.CurrentCell = fila.Cells["PARTIDA"]; fila.Selected = true;
            }, async () => await Ejecutar(ActualizarActivo), json =>
            { Recordar(); MYGMotorPresupuestos.ImportarMetradoBIM(documento, P, json); panelPresupuesto.Refrescar(); ActualizarResumen(); }, () => Guardar(false), () => Historial(false), () => Historial(true));
        principal.Controls.Add(panelPresupuesto);
        panelPresupuesto.InicializarCatalogos(RutaCatalogoPropio, () => sesion.Autorizado, Refrescar,
            () => string.IsNullOrWhiteSpace(archivo) ? null : MYGBaseDatos.RutaDeProyecto(archivo));
        panelPresupuesto.InicializarEstructura(() => documento, ActivarPresupuestoEstructura, MenuEstructura, EditarCeldaEstructura, UnidadesEstructura);
        panelPresupuesto.InicializarArrastreEstructura(() => !ocupado && sesion.Autorizado, Sincronizar, Refrescar);
        panelPresupuesto.InicializarHerramientas((nodo, sentido) => !ocupado && MYGOrdenPresupuestos.PuedeMover(documento, nodo, sentido), MoverFilaEstructura,
            () => { if (!ocupado) { Sincronizar(); panelPresupuesto.GuardarCostosMultiples(); } });
        InicializarCronograma(principal, exterior, seleccion);
        espacioPresupuestos.SelectedIndexChanged += (s, e) => { if (espacioPresupuestos.SelectedIndex == 0) panelPresupuesto.Refrescar(); };
        MYG2027_TemaComercial.Aplicar(cintaPresupuestos);
        exterior.Controls.Add(seleccion, 0, 1); exterior.Controls.Add(espacioPresupuestos, 0, 2); Controls.Add(exterior);
        // Guardar está disponible incluso con la sesión vencida. Las modificaciones mantienen la autorización existente.
        sesion.Cambio += EstadoCintaPresupuestos;
        Disposed += (s, e) => sesion.Cambio -= EstadoCintaPresupuestos;
        MYG2027_TemaComercial.CambioTema += ActualizarTemaEditor;
        Disposed += (s, e) => MYG2027_TemaComercial.CambioTema -= ActualizarTemaEditor;
        EstadoCintaPresupuestos();
    }
    private void EstadoCintaPresupuestos()
    {
        if (cintaPresupuestos == null || IsDisposed) return;
        foreach (Button b in cintaPresupuestos.Controls)
            b.Enabled = HerramientaProyectoDisponible(b.Tag is not false, ocupado, sesion.Autorizado);
        panelPresupuesto?.ActualizarHerramientas();
        EstadoHerramientasCronograma();
    }
    internal static ContextMenuStrip CrearMenuEspecificaciones(Action<MYGAlcanceEspecificaciones> exportar, bool presupuestoDisponible)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("Especificaciones de Proyecto", null, (_, _) => exportar(MYGAlcanceEspecificaciones.Proyecto))
        { Name = "exportar_especificaciones_proyecto" });
        menu.Items.Add(new ToolStripMenuItem("Especificaciones de Presupuesto", null, (_, _) => exportar(MYGAlcanceEspecificaciones.Presupuesto))
        { Name = "exportar_especificaciones_presupuesto", Enabled = presupuestoDisponible });
        return menu;
    }
    private void ExportarEspecificacionesDesdeMenu(MYGAlcanceEspecificaciones alcance)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        // Terminar el clic y cierre del menú antes de entrar en el bucle modal.
        BeginInvoke(new Action(async () =>
        {
            if (IsDisposed || Disposing) return;
            await Ejecutar(() =>
            {
                Sincronizar();
                if (alcance == MYGAlcanceEspecificaciones.Presupuesto && P == null)
                    throw new InvalidOperationException("Seleccione el presupuesto que desea exportar.");
                using var vista = new MYGEspecificacionesExportacionForm(documento, alcance, P?.Id, archivo);
                vista.ShowDialog(this);
                return System.Threading.Tasks.Task.CompletedTask;
            }, false);
        }));
    }
    private void EditarDatosPartida()
    {
        var i = Seleccionadas.FirstOrDefault(); if (i == null) return;
        if (P.Conexion != null && !string.IsNullOrWhiteSpace(i.IdInternoDelphin)) throw new InvalidOperationException("La descripción oficial se actualiza desde Delphin. Edite los datos de costo en MYG.");
        bool titulo = MYGProyectoStorage.EsTitulo(i);
        string id = i.Id;
        var unidades = titulo ? null : MYGCatalogoUnidades.Listar(RutaCatalogoPropio());
        i = P.Items.First(x => x.Id == id);
        using var d = new MYGCamposProyectoForm(titulo ? "Editar título" : "Editar partida", titulo ? new[] { "Descripción" } : new[] { "Descripción", "Unidad" },
            titulo ? new[] { i.Descripcion } : new[] { i.Descripcion, i.Unidad }, unidades: unidades);
        if (d.ShowDialog(this) != DialogResult.OK) return;
        if (!titulo && i.Costos.MetradosBIM.Count > 0 && !MYGProyectoStorage.MismaUnidad(i.Unidad, d.Valores[1]))
            throw new InvalidOperationException("Retire los metrados BIM de la partida antes de cambiar su unidad.");
        Recordar(); i.Descripcion = d.Valores[0]; if (!titulo) i.Unidad = d.Valores[1]; i.EstadoRevit = null; i.MensajeRevit = null; Refrescar();
    }
}
