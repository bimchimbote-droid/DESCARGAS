using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_2027;

// Windows conserva el dibujo y el comportamiento de la barra de título:
// arrastrar, teclado, menú del sistema, minimizar y maximizar/restaurar.
internal static class MYGTemaVentanas
{
    private sealed class Estado
    {
        internal bool Aplicando;
    }

    private static readonly ConditionalWeakTable<WinForms.Form, Estado> ventanas = new();
    private static readonly ProcedimientoHook procedimiento = AntesDeMensaje;
    private static IntPtr hook;
    private static bool inicializado;

    internal static bool EsVentanaConTitulo(WinForms.Form ventana) =>
        ventana != null && !ventana.IsDisposed && !ventana.Disposing && ventana.TopLevel
        && ventana.FormBorderStyle is WinForms.FormBorderStyle.FixedSingle
            or WinForms.FormBorderStyle.Fixed3D or WinForms.FormBorderStyle.FixedDialog
            or WinForms.FormBorderStyle.Sizable;

    internal static void Inicializar()
    {
        if (inicializado || !OperatingSystem.IsWindows()) return;
        inicializado = true;
        // IMessageFilter no ve los mensajes enviados directamente por ShowDialog.
        // Este observador del hilo prepara también esos diálogos antes de que
        // aparezcan. Sólo acepta HWND de nuestros formularios administrados.
        hook = SetWindowsHookEx(4 /* WH_CALLWNDPROC */, procedimiento, IntPtr.Zero, GetCurrentThreadId());
        WinForms.Application.ThreadExit += (_, _) =>
        {
            if (hook == IntPtr.Zero) return;
            UnhookWindowsHookEx(hook);
            hook = IntPtr.Zero;
        };
    }

    internal static void Preparar(WinForms.Form ventana)
    {
        if (!EsVentanaConTitulo(ventana)) return;
        var estado = Registrar(ventana);
        if (estado.Aplicando) return;
        estado.Aplicando = true;
        try { HabilitarBotones(ventana); }
        finally { estado.Aplicando = false; }
    }

    internal static void Aplicar(WinForms.Form ventana)
    {
        if (!EsVentanaConTitulo(ventana)) return;
        var estado = Registrar(ventana);
        if (estado.Aplicando) return;
        estado.Aplicando = true;
        try
        {
            HabilitarBotones(ventana);
            if (!OperatingSystem.IsWindows() || !ventana.IsHandleCreated) return;
            bool altoContraste = WinForms.SystemInformation.HighContrast;
            int oscuro = MYG2027_TemaComercial.Oscuro && !altoContraste ? 1 : 0;
            // El atributo 19 cubre las primeras versiones de Windows 10 que
            // admiten el marco oscuro. Los colores explícitos son de Windows 11;
            // versiones anteriores los rechazan y conservan su marco nativo.
            if (CambiarAtributo(ventana.Handle, 20, oscuro) < 0)
                CambiarAtributo(ventana.Handle, 19, oscuro);
            CambiarAtributo(ventana.Handle, 35, altoContraste ? -1 : ColorNativo(MYG2027_TemaComercial.Fondo));
            CambiarAtributo(ventana.Handle, 36, altoContraste ? -1 : ColorNativo(MYG2027_TemaComercial.Texto));
            CambiarAtributo(ventana.Handle, 34, altoContraste ? -1 : ColorNativo(MYG2027_TemaComercial.Borde));
        }
        finally { estado.Aplicando = false; }
    }

    private static Estado Registrar(WinForms.Form ventana) => ventanas.GetValue(ventana, form =>
    {
        // La aplicación puede recrear el HWND al cambiar estilos, DPI o dueño.
        // El tema se vuelve a aplicar al nuevo marco, sin forzar su creación.
        form.HandleCreated += (_, _) => Aplicar(form);
        return new Estado();
    });

    private static void HabilitarBotones(WinForms.Form ventana)
    {
        // Se conserva FixedDialog en los diálogos de tamaño fijo. Windows
        // permite maximizarlos y restaurarlos sin habilitar el arrastre del borde.
        if (!ventana.ControlBox) ventana.ControlBox = true;
        if (!ventana.MinimizeBox) ventana.MinimizeBox = true;
        if (!ventana.MaximizeBox) ventana.MaximizeBox = true;
    }

    private static int ColorNativo(Drawing.Color color) => color.R | color.G << 8 | color.B << 16;

    private static int CambiarAtributo(IntPtr ventana, int atributo, int valor)
    {
        try { return DwmSetWindowAttribute(ventana, atributo, ref valor, sizeof(int)); }
        catch (Exception e) when (e is DllNotFoundException or EntryPointNotFoundException) { return -1; }
    }

    private static IntPtr AntesDeMensaje(int codigo, IntPtr wParam, IntPtr lParam)
    {
        if (codigo >= 0 && lParam != IntPtr.Zero)
        {
            try
            {
                var mensaje = Marshal.PtrToStructure<MensajeEnviado>(lParam);
                bool mostrar = mensaje.Mensaje == 0x0018 && mensaje.WParam != IntPtr.Zero;
                // WM_WINDOWPOSCHANGING precede también a ShowWindow de ventanas
                // ya creadas y a las que se muestran sin activar.
                if (!mostrar && mensaje.Mensaje == 0x0046 && mensaje.LParam != IntPtr.Zero)
                    mostrar = (Marshal.PtrToStructure<PosicionVentana>(mensaje.LParam).Flags & 0x0040) != 0;
                bool cambioSistema = mensaje.Mensaje is 0x001A or 0x031A;
                if ((mostrar || cambioSistema) && WinForms.Control.FromHandle(mensaje.Ventana) is WinForms.Form form
                    && WinForms.Application.OpenForms.Cast<WinForms.Form>().Contains(form)
                    && (form.GetType() == typeof(WinForms.Form) || form.GetType().Assembly == typeof(MYGTemaVentanas).Assembly))
                    Aplicar(form);
            }
            // Un formulario puede cerrarse mientras se procesa otro mensaje.
            // No se propagan excepciones administradas al callback de Windows.
            catch (Exception e) when (e is ObjectDisposedException or InvalidOperationException
                or System.ComponentModel.Win32Exception) { }
        }
        return CallNextHookEx(hook, codigo, wParam, lParam);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MensajeEnviado
    {
        internal IntPtr LParam, WParam;
        internal uint Mensaje;
        internal IntPtr Ventana;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct PosicionVentana
    {
        internal IntPtr Ventana, InsertarDespues;
        internal int X, Y, Ancho, Alto;
        internal uint Flags;
    }

    private delegate IntPtr ProcedimientoHook(int codigo, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int tipo, ProcedimientoHook procedimiento, IntPtr modulo, uint hilo);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hook);
    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hook, int codigo, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr ventana, int atributo, ref int valor, int tamano);
}
