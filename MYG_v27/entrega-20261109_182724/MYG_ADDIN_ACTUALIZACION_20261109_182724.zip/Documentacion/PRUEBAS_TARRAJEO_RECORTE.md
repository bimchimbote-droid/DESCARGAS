# Recorte y selección continua de Tarrajeo / Encofrado

El descuento se calcula a partir de los sólidos visibles que ocupan el espesor
exterior del revestimiento. Su huella se resta del perfil completo: no se intenta
crear un vaciado parcial a través del espesor de un muro de Revit. Un resultado
rectangular usa la creación normal de muro; los demás perfiles conservan sus
mordidas y huecos.

El cortante temporal sobrepasa ambos extremos incluso en los reintentos del
boolean. El perfil se recupera de un único plano extremo, incluyendo todas sus
islas. Se comparan los contornos proyectados para no descontar dos veces la misma
huella ni confundir figuras distintas con la misma área y caja.

Si el boolean falla y tanto la cara como todas las huellas son rectángulos sin
huecos, se usa una resta en 2D y se crean los restos rectangulares por separado.
No se repone el paño original encima de una interferencia. Las bandas menores que
la tolerancia de líneas se omiten. Una proyección estrecha solo se puede omitir
si otra huella rectangular cubre todo ese triángulo; los recortes no resueltos
siguen avisando y permiten seleccionar otra cara.

Los errores de una cara no finalizan la sesión. Tras cerrar el aviso se puede
seleccionar otra cara para muro o suelo. Esc vuelve al formulario. La falta de
tipo o de handler también vuelve al formulario para corregir la configuración.

## Pruebas aisladas

Los scripts de `Pruebas/` extraen los métodos actuales de los handlers y los
ejecutan con un SDK .NET local, sin descargar paquetes. Utilizan sustitutos mínimos
de la API de Revit; no cargan Revit ni validan su motor geométrico, las uniones,
las transacciones reales o el comportamiento de `ExternalEvent` en la aplicación.
Consultar los argumentos de cada script con `--help`.

## Comprobación funcional pendiente en Revit sobre Windows

Compilar con el entorno Windows y las referencias reales del proyecto. Probar
sobre una copia de un modelo, con un tipo de revestimiento de espesor conocido:

| Caso | Resultado esperado |
| --- | --- |
| Cara rectangular de viga sin interferencias | Muro rectangular con la altura y longitud de la cara. |
| Sólido que invade solo una parte del espesor exterior | Su huella se descuenta en todo el espesor; no queda una lámina residual ni aparece el perfil original sin cortar. |
| Interferencia rectangular en un borde | Paño rectangular reducido o perfil con mordida, según la huella. |
| Interferencia interior o que divide toda la altura | Hueco o paños separados, sin rellenar la interferencia. |
| Varias interferencias rectangulares que se solapan | Se descuenta su unión; no se duplican los descuentos. |
| Boolean no resuelto con cara y huellas rectangulares | Se crean los restos rectangulares libres; pueden ser varios muros. |
| Sólido tangente o únicamente detrás de la cara anfitriona | No elimina el revestimiento exterior. |
| Vínculo visible, movido y girado | Se aplica su transformación una sola vez; la cara anfitriona no se autorrecorta. |
| Sólido oculto o vínculo excluido por la configuración | No recorta el revestimiento. |
| Cara totalmente ocupada o recorte no resoluble | No se crea el paño; un aviso, sin el segundo aviso genérico repetido, y luego otra selección. |
| Cara inválida o fallo de creación de muro/suelo | Cerrar el aviso permite seleccionar después una cara válida sin volver a pulsar el botón del comando. |
| Esc en la siguiente selección | Termina la sesión y restaura el formulario; conserva lo ya creado. |

Las capturas del problema deben repetirse con el modelo original para confirmar
el resultado visual y dimensional. Las pruebas aisladas y el análisis de sintaxis
no sustituyen esta comprobación.
