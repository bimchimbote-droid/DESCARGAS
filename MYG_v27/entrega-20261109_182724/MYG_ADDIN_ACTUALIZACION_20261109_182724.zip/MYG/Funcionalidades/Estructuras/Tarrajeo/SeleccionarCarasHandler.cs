﻿// =====================================
// HANDLER V18 - SELECCIONAR CARAS PARA TARRAJEO
// Soporta caras nativas y de vínculos sin resolver dos veces
// la referencia ni duplicar transformaciones.
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;

public class SeleccionarCarasHandler : IExternalEventHandler
{
    public TarrajeoForm Form;

    public Tarrajeo_SuelosHandler HandlerSuelo;
    public Tarrajeo_MurosHandler HandlerMuro;

    public ExternalEvent EventoSuelo;
    public ExternalEvent EventoMuro;

    public FloorType TipoSuelo;
    public WallType TipoMuro;
    public bool ConsiderarVinculos;

    private const double TOL_NORMAL_VERTICAL = 0.02;

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;

        try
        {
            if (Form != null)
            {
                TipoSuelo = Form.TipoSueloSeleccionado;
                TipoMuro = Form.TipoMuroSeleccionado;
                ConsiderarVinculos = Form.ConsiderarVinculos;
            }

            // Cada intento de selección es independiente. Una referencia o
            // cara defectuosa no termina la sesión; Esc sí vuelve al formulario.
            while (true)
            {
                bool referenciaSeleccionada = false;

                try
                {
                    ObjectType tipoSeleccion = ConsiderarVinculos
                        ? ObjectType.PointOnElement
                        : ObjectType.Face;

                    Reference faceRef = uidoc.Selection.PickObject(
                        tipoSeleccion,
                        new TarrajeoCarasSelectionFilter(ConsiderarVinculos),
                        ConsiderarVinculos
                            ? "Seleccione una cara nativa o de un vínculo (Esc para terminar)"
                            : "Seleccione una cara (Esc para terminar)");

                    if (faceRef == null)
                    {
                        MostrarFormulario();
                        return;
                    }

                    referenciaSeleccionada = true;

                    Transform transformCara;
                    Element hostElem;
                    Element elementoGeometrico;
                    RevitLinkInstance vinculoOrigen;

                    Face cara = ObtenerCaraDesdeReferencia(
                        doc,
                        faceRef,
                        out transformCara,
                        out hostElem,
                        out elementoGeometrico,
                        out vinculoOrigen);

                    if (cara == null || hostElem == null || elementoGeometrico == null)
                    {
                        TaskDialog.Show("MYG", "No se pudo obtener una cara válida. Puede seleccionar otra cara o pulsar Esc para terminar.");
                        continue;
                    }

                    bool esCaraVerticalParaMuro = EsCaraVerticalParaMuro(
                        cara,
                        transformCara);

                    //-------------------------------------------------
                    // CARA VERTICAL PLANA O CURVA CILÍNDRICA -> MURO
                    //-------------------------------------------------
                    if (esCaraVerticalParaMuro)
                    {
                        if (TipoMuro == null)
                        {
                            TaskDialog.Show("MYG", "Debe seleccionar un tipo de muro.");
                            MostrarFormulario();
                            return;
                        }

                        if (HandlerMuro == null || EventoMuro == null)
                        {
                            TaskDialog.Show("MYG", "No se encontró el handler de muros.");
                            MostrarFormulario();
                            return;
                        }

                        HandlerMuro.Form = Form;
                        HandlerMuro.TipoMuro = TipoMuro;
                        HandlerMuro.FaceRef = faceRef;
                        HandlerMuro.ConsiderarVinculos = ConsiderarVinculos;

                        // La cara y su origen ya quedaron resueltos aquí. El handler de
                        // muros los utilizará directamente y no volverá a transformar
                        // una referencia de vínculo.
                        HandlerMuro.CaraProcesada = cara;
                        HandlerMuro.HostProcesado = hostElem;
                        HandlerMuro.ElementoGeometricoOrigen = elementoGeometrico;
                        HandlerMuro.VinculoOrigen = vinculoOrigen;
                        HandlerMuro.TransformProcesado = transformCara ?? Transform.Identity;

                        EventoMuro.Raise();
                        return;
                    }

                    //-------------------------------------------------
                    // CARA HORIZONTAL / INCLINADA -> SUELO
                    //-------------------------------------------------
                    if (TipoSuelo == null)
                    {
                        TaskDialog.Show("MYG", "Debe seleccionar un tipo de suelo.");
                        MostrarFormulario();
                        return;
                    }

                    if (HandlerSuelo == null || EventoSuelo == null)
                    {
                        TaskDialog.Show("MYG", "No se encontró el handler de suelos.");
                        MostrarFormulario();
                        return;
                    }

                    HandlerSuelo.Form = Form;
                    HandlerSuelo.TipoSuelo = TipoSuelo;
                    HandlerSuelo.FaceRef = faceRef;
                    HandlerSuelo.ConsiderarVinculos = ConsiderarVinculos;

                    EventoSuelo.Raise();
                    return;
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException)
                {
                    MostrarFormulario();
                    return;
                }
                catch (Exception ex)
                {
                    // Un error al resolver la cara permite otro clic. Si falla
                    // PickObject o cambia el documento, volver a configuración
                    // evita repetir avisos sin que el usuario pueda cancelar.
                    bool puedeContinuar = referenciaSeleccionada &&
                        doc.IsValidObject && app.ActiveUIDocument != null &&
                        doc.Equals(app.ActiveUIDocument.Document);

                    TaskDialog.Show(
                        "MYG - Error",
                        "Error al seleccionar cara:\n\n" + ex.Message +
                        (puedeContinuar
                            ? "\n\nPuede seleccionar otra cara o pulsar Esc para terminar."
                            : string.Empty));

                    if (!puedeContinuar)
                    {
                        MostrarFormulario();
                        return;
                    }
                }
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarFormulario();
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG - Error",
                "Error al seleccionar cara:\n\n" + ex.Message);

            MostrarFormulario();
        }
    }

    private Face ObtenerCaraDesdeReferencia(
        Document doc,
        Reference referencia,
        out Transform transformCara,
        out Element elementoHost,
        out Element elementoGeometrico,
        out RevitLinkInstance vinculoOrigen)
    {
        transformCara = Transform.Identity;
        elementoHost = null;
        elementoGeometrico = null;
        vinculoOrigen = null;

        if (doc == null || referencia == null)
            return null;

        elementoHost = doc.GetElement(referencia.ElementId);

        if (elementoHost == null)
            return null;

        RevitLinkInstance link = elementoHost as RevitLinkInstance;

        if (link != null)
        {
            if (!ConsiderarVinculos)
                return null;

            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                return null;

            ElementId linkedId = referencia.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return null;

            Element linkedElem = linkDoc.GetElement(linkedId);

            if (linkedElem == null)
                return null;

            elementoGeometrico = linkedElem;
            vinculoOrigen = link;
            transformCara = link.GetTotalTransform();

            try
            {
                Reference refEnLink = referencia.CreateReferenceInLink();
                GeometryObject geoObj = linkedElem.GetGeometryObjectFromReference(refEnLink);
                Face face = geoObj as Face;

                if (face != null)
                    return face;
            }
            catch
            {
            }

            // Fallback de Revit: si devuelve una Face ya transformada al host,
            // se utiliza Identity para no aplicar dos veces el vínculo.
            try
            {
                GeometryObject geoObj = link.GetGeometryObjectFromReference(referencia);
                Face face = geoObj as Face;

                if (face != null)
                {
                    transformCara = Transform.Identity;
                    return face;
                }
            }
            catch
            {
            }

            return null;
        }

        elementoGeometrico = elementoHost;

        try
        {
            GeometryObject geoObj = elementoHost.GetGeometryObjectFromReference(referencia);
            Face face = geoObj as Face;

            if (face != null)
                return face;
        }
        catch
        {
        }

        return null;
    }

    private bool EsCaraVerticalParaMuro(Face cara, Transform transformCara)
    {
        if (cara == null)
            return false;

        if (transformCara == null)
            transformCara = Transform.Identity;

        PlanarFace pf = cara as PlanarFace;

        if (pf != null)
        {
            XYZ normal = transformCara.OfVector(pf.FaceNormal).Normalize();
            return Math.Abs(normal.Z) <= TOL_NORMAL_VERTICAL;
        }

        CylindricalFace cf = cara as CylindricalFace;

        if (cf != null)
        {
            XYZ eje = transformCara.OfVector(cf.Axis).Normalize();

            return Math.Abs(
                Math.Abs(eje.DotProduct(XYZ.BasisZ)) - 1.0)
                <= TOL_NORMAL_VERTICAL;
        }

        return false;
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
                Form.RestaurarVentana();
        }
        catch
        {
            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Show();
            }
            catch
            {
            }
        }
    }

    public string GetName()
    {
        return "MYG - Seleccionar Caras Tarrajeo V18";
    }
}

public class TarrajeoCarasSelectionFilter : ISelectionFilter
{
    private readonly bool _considerarVinculos;

    public TarrajeoCarasSelectionFilter(bool considerarVinculos)
    {
        _considerarVinculos = considerarVinculos;
    }

    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        if (_considerarVinculos && elem is RevitLinkInstance)
            return true;

        Category cat = elem.Category;

        if (cat == null)
            return false;

        try
        {
            return cat.CategoryType == CategoryType.Model;
        }
        catch
        {
            return true;
        }
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        return true;
    }
}
