#!/usr/bin/env python3
"""Exercise the real selector, wall and floor Execute methods against small Revit API substitutes.

Requires a .NET 8 SDK (DOTNET_ROOT or --dotnet); no restore/download is performed.
This checks selection/session control, not Revit transactions or geometry.
"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import tempfile

REPO = Path(__file__).resolve().parents[1]
SOURCE = REPO / 'MYG/Funcionalidades/Estructuras/Tarrajeo'


def execute(name):
    text = (SOURCE / name).read_text(encoding='utf-8-sig')
    start = text.index('    public void Execute(UIApplication app)')
    # This method is followed by a different class member, not a local function.
    end = text.index('\n    private Face ObtenerCaraDesdeReferencia', start) if name.startswith('Seleccionar') else text.index('\n    // =========================================================\n    // ' + ('API PÚBLICA' if name.startswith('Tarrajeo_Muros') else 'MÉTODO PÚBLICO'), start)
    return text[start:end]


STUBS = r'''
using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
namespace Autodesk.Revit.Exceptions {
    public class OperationCanceledException : Exception { }
}
namespace Autodesk.Revit.DB {
    public class Document {
        public int Key = 1; public bool IsValidObject = true;
        public override bool Equals(object other) { return other is Document d && Key == d.Key; }
        public override int GetHashCode() { return Key; }
    }
    public class Element { }
    public class RevitLinkInstance : Element { }
    public class WallType { }
    public class Wall { }
    public class FloorType { }
    public class Transform { public static Transform Identity = new Transform(); }
    public class Face { public bool Vertical; }
    public class PlanarFace : Face { }
    public class Reference { public Face Face; public Exception ResolveException; }
}
namespace Autodesk.Revit.UI.Selection {
    public enum ObjectType { Face, PointOnElement }
    public class Selection {
        public Queue<object> Steps = new Queue<object>();
        public int Picks; public ObjectType LastObjectType;
        public Reference PickObject(ObjectType kind, object filter, string prompt) {
            Picks++; LastObjectType = kind;
            if (Steps.Count == 0) return null;
            object step = Steps.Dequeue();
            if (step is Exception ex) throw ex;
            return (Reference)step;
        }
    }
}
namespace Autodesk.Revit.UI {
    public class UIDocument {
        public Document CurrentDocument = new Document(); public bool FreshWrapper;
        public Document Document { get { return FreshWrapper
            ? new Document { Key = CurrentDocument.Key, IsValidObject = CurrentDocument.IsValidObject }
            : CurrentDocument; } }
        public Autodesk.Revit.UI.Selection.Selection Selection = new Autodesk.Revit.UI.Selection.Selection();
    }
    public class UIApplication { public UIDocument ActiveUIDocument; }
    public class ExternalEvent { public int Raises; public void Raise() { Raises++; } }
    public static class TaskDialog {
        public static List<string> Messages = new List<string>();
        public static void Show(string title, string text) { Messages.Add(text); }
    }
}
class TarrajeoCarasSelectionFilter { public TarrajeoCarasSelectionFilter(bool links) { } }
class TarrajeoForm {
    public FloorType TipoSueloSeleccionado;
    public WallType TipoMuroSeleccionado;
    public bool ConsiderarVinculos, PermitirUnion;
}
class WallHarness {
    public TarrajeoForm Form; public WallType TipoMuro; public Reference FaceRef;
    public bool ConsiderarVinculos; public Face CaraProcesada; public Element HostProcesado;
    public Element ElementoGeometricoOrigen; public RevitLinkInstance VinculoOrigen;
    public Transform TransformProcesado;
    public UIDocument UiDoc; public int Restores, Creates, ConfigureOrigins;
    public ExternalEvent SeleccionarEvent = new ExternalEvent();
    public bool Result = true, WarnDuringCreation, MissingHost;
    public Exception CreationException;
    bool _avisoRecorteMostrado;
    void MostrarFormulario() { Restores++; }
    void PrepararNuevaEjecucion() { _avisoRecorteMostrado = false; }
    void ConfigurarOrigenDeRecorte(Element e, RevitLinkInstance l) { ConfigureOrigins++; }
    Face ObtenerFaceDesdeReferencia(Document d, Reference r, out Element e, out Transform t) {
        e = MissingHost ? null : new Element(); t = Transform.Identity; return r.Face;
    }
    List<Wall> CrearMurosDesdeFaceProcesada(Document d, UIDocument u, Element e, Face f, Transform t, WallType wt, bool union) {
        Creates++;
        if (CreationException != null) throw CreationException;
        if (WarnDuringCreation) { TaskDialog.Show("cutting", "cutting diagnostic"); _avisoRecorteMostrado = true; }
        return Result ? new List<Wall> { new Wall() } : new List<Wall>();
    }
__WALL__
}
class SelectorHarness {
    public TarrajeoForm Form;
    public FloorHarness HandlerSuelo = new FloorHarness();
    public WallHarness HandlerMuro = new WallHarness();
    public ExternalEvent EventoSuelo = new ExternalEvent(), EventoMuro = new ExternalEvent();
    public FloorType TipoSuelo = new FloorType(); public WallType TipoMuro = new WallType();
    public bool ConsiderarVinculos; public int Restores;
    void MostrarFormulario() { Restores++; }
    Face ObtenerCaraDesdeReferencia(Document d, Reference r, out Transform t,
        out Element host, out Element element, out RevitLinkInstance link) {
        t = Transform.Identity; host = new Element(); element = host; link = null;
        if (r.ResolveException != null) throw r.ResolveException;
        return r.Face;
    }
    bool EsCaraVerticalParaMuro(Face f, Transform t) { return f.Vertical; }
__SELECTOR__
}
class FloorHarness {
    public UIDocument UiDoc; public TarrajeoForm Form; public FloorType TipoSuelo = new FloorType();
    public Reference FaceRef; public bool ConsiderarVinculos;
    public string UltimoDiagnostico, RutaUltimoDiagnostico;
    public ExternalEvent SeleccionarEvent = new ExternalEvent();
    public int Restores, Creates, Logs; public bool Result = true;
    public Exception CreationException; public bool MissingHost;
    void MostrarFormulario() { Restores++; }
    void PrepararNuevaEjecucion() { }
    void RegistrarDiagnosticoEnArchivo(string title, string text) { Logs++; }
    PlanarFace ObtenerCaraPlanarDesdeReferencia(Document doc, Reference r, out Element host, out Transform t) {
        host = MissingHost ? null : new Element(); t = Transform.Identity;
        return r.Face as PlanarFace;
    }
    bool CrearSueloDesdeCaraPlanarProcesada(Document d, UIDocument u, Element e, PlanarFace f, Transform t, FloorType type) {
        Creates++;
        if (CreationException != null) throw CreationException;
        UltimoDiagnostico = "test diagnostic";
        return Result;
    }
__FLOOR__
}
static class Program {
    static int Checks;
    static void Check(bool ok, string message) {
        if (!ok) throw new Exception(message);
        Checks++; Console.WriteLine("PASS " + message);
    }
    static Reference Ref(bool wall = false) { return new Reference { Face = new PlanarFace { Vertical = wall } }; }
    static UIApplication App() { return new UIApplication { ActiveUIDocument = new UIDocument() }; }
    static void Reset() { TaskDialog.Messages.Clear(); }
    static void SelectionTests() {
        Reset(); var app = App(); var s = new SelectorHarness();
        app.ActiveUIDocument.Selection.Steps.Enqueue(new Reference());
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref(true));
        s.Execute(app);
        Check(app.ActiveUIDocument.Selection.Picks == 2, "invalid face -> close warning -> pick again");
        Check(s.EventoMuro.Raises == 1 && s.Restores == 0 && TaskDialog.Messages.Count == 1,
            "second valid wall dispatched without restoring configuration");

        Reset(); app = App(); s = new SelectorHarness();
        app.ActiveUIDocument.Selection.Steps.Enqueue(new Reference { ResolveException = new InvalidOperationException("bad face") });
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref()); s.Execute(app);
        Check(app.ActiveUIDocument.Selection.Picks == 2 && s.EventoSuelo.Raises == 1,
            "face resolution exception -> close warning -> create floor");
        Check(TaskDialog.Messages.Count == 1 && s.Restores == 0, "exception warning does not end selection");

        Reset(); app = App(); app.ActiveUIDocument.FreshWrapper = true; s = new SelectorHarness();
        app.ActiveUIDocument.Selection.Steps.Enqueue(new Reference { ResolveException = new InvalidOperationException("bad reference") });
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref()); s.Execute(app);
        Check(s.EventoSuelo.Raises == 1 && s.Restores == 0,
            "same active document in different API wrapper permits retry");

        Reset(); app = App(); s = new SelectorHarness();
        app.ActiveUIDocument.Selection.Steps.Enqueue(new InvalidOperationException("selection unavailable"));
        s.Execute(app);
        Check(s.Restores == 1 && app.ActiveUIDocument.Selection.Picks == 1 && s.EventoSuelo.Raises == 0,
            "PickObject failure returns configuration without repeated warning loop");

        Reset(); app = App(); s = new SelectorHarness();
        app.ActiveUIDocument.Selection.Steps.Enqueue(new Reference());
        app.ActiveUIDocument.Selection.Steps.Enqueue(new Autodesk.Revit.Exceptions.OperationCanceledException());
        s.Execute(app);
        Check(app.ActiveUIDocument.Selection.Picks == 2 && s.Restores == 1,
            "Esc after invalid face returns configuration");
        Check(s.EventoSuelo.Raises + s.EventoMuro.Raises == 0, "Esc does not dispatch creation");

        Reset(); app = App(); s = new SelectorHarness();
        app.ActiveUIDocument.Selection.Steps.Enqueue(new Autodesk.Revit.Exceptions.OperationCanceledException());
        s.Execute(app);
        Check(s.Restores == 1 && TaskDialog.Messages.Count == 0, "Esc has no error warning");

        Reset(); app = App(); s = new SelectorHarness { TipoMuro = null };
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref(true)); s.Execute(app);
        Check(s.Restores == 1 && s.EventoMuro.Raises == 0 && app.ActiveUIDocument.Selection.Picks == 1,
            "missing wall type returns configuration");

        Reset(); app = App(); s = new SelectorHarness { TipoSuelo = null };
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref()); s.Execute(app);
        Check(s.Restores == 1 && s.EventoSuelo.Raises == 0, "missing floor type returns configuration");

        Reset(); app = App(); s = new SelectorHarness { HandlerMuro = null };
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref(true)); s.Execute(app);
        Check(s.Restores == 1 && s.EventoMuro.Raises == 0, "missing creation handler returns configuration");

        Reset(); app = App(); s = new SelectorHarness { ConsiderarVinculos = true };
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref()); s.Execute(app);
        Check(app.ActiveUIDocument.Selection.LastObjectType == ObjectType.PointOnElement && s.HandlerSuelo.ConsiderarVinculos,
            "linked selection retains object type and link flag");
    }
    static void FloorTests() {
        Reset(); var app = App(); var f = new FloorHarness { FaceRef = Ref(), Result = false };
        f.Execute(app);
        Check(f.SeleccionarEvent.Raises == 1 && f.Restores == 0 && TaskDialog.Messages.Count == 1,
            "floor creation failure -> close diagnostic -> request another face");
        Check(f.FaceRef == null && f.Creates == 1, "failed floor reference cleared exactly once");
        // Simulate execution of the requeued selector and its next floor event.
        var selector = new SelectorHarness { HandlerSuelo = f };
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref()); selector.Execute(app);
        f.Result = true; f.Execute(app);
        Check(selector.EventoSuelo.Raises == 1 && f.Creates == 2 && f.SeleccionarEvent.Raises == 2,
            "failed floor -> next pick -> successful floor continues session");

        Reset(); f = new FloorHarness { FaceRef = Ref(), CreationException = new InvalidOperationException("geometry") };
        f.Execute(App());
        Check(f.SeleccionarEvent.Raises == 1 && f.Restores == 0 && TaskDialog.Messages.Count == 1 && f.FaceRef == null,
            "floor geometry exception shows diagnostic and requeues selection");

        Reset(); f = new FloorHarness { FaceRef = Ref(), CreationException = new Autodesk.Revit.Exceptions.OperationCanceledException() };
        f.Execute(App());
        Check(f.SeleccionarEvent.Raises == 0 && f.Restores == 1 && TaskDialog.Messages.Count == 0,
            "floor cancellation ends session without an error");

        Reset(); f = new FloorHarness { FaceRef = new Reference { Face = new Face() } };
        f.Execute(App());
        Check(f.SeleccionarEvent.Raises == 1 && f.Creates == 0 && TaskDialog.Messages.Count == 1,
            "nonplanar floor face shows warning and requeues selection");

        Reset(); f = new FloorHarness { FaceRef = Ref(), MissingHost = true };
        f.Execute(App());
        Check(f.SeleccionarEvent.Raises == 1 && f.Creates == 0 && TaskDialog.Messages.Count == 1,
            "missing face host shows warning and requeues selection");

        Reset(); f = new FloorHarness { FaceRef = Ref(), TipoSuelo = null };
        f.Execute(App());
        Check(f.SeleccionarEvent.Raises == 0 && f.Restores == 1 && f.Creates == 0,
            "floor missing type returns configuration without retry");

        Reset(); f = new FloorHarness(); f.Execute(App());
        Check(f.SeleccionarEvent.Raises == 0 && f.Restores == 1, "floor missing reference returns configuration");

        Reset(); f = new FloorHarness { FaceRef = Ref() }; f.Execute(new UIApplication());
        Check(f.SeleccionarEvent.Raises == 0 && f.Restores == 1, "missing active document returns configuration");
    }
    static void WallTests() {
        Reset(); var app = App(); var w = new WallHarness { FaceRef = Ref(true), TipoMuro = new WallType(), Result = false };
        w.Execute(app);
        Check(w.SeleccionarEvent.Raises == 1 && w.Restores == 0 && TaskDialog.Messages.Count == 1,
            "wall no profile -> close diagnostic -> request another face");
        Check(w.FaceRef == null && w.CaraProcesada == null && w.HostProcesado == null,
            "wall failed reference and resolved geometry cleared");
        var selector = new SelectorHarness { HandlerMuro = w };
        app.ActiveUIDocument.Selection.Steps.Enqueue(Ref(true)); selector.Execute(app);
        w.Result = true; w.Execute(app);
        Check(w.Creates == 2 && w.SeleccionarEvent.Raises == 2 && selector.EventoMuro.Raises == 1,
            "failed wall -> next pick -> successful wall continues session");
        Check(w.ConfigureOrigins == 1 && w.ElementoGeometricoOrigen == null && w.TransformProcesado == null,
            "resolved wall origin used and discarded after creation");

        Reset(); w = new WallHarness { FaceRef = Ref(true), TipoMuro = new WallType(),
            Result = false, WarnDuringCreation = true };
        w.Execute(App());
        Check(w.SeleccionarEvent.Raises == 1 && TaskDialog.Messages.Count == 1
                && TaskDialog.Messages[0] == "cutting diagnostic",
            "cutting diagnostic suppresses duplicate generic no-profile warning");

        Reset(); w = new WallHarness { FaceRef = new Reference(), TipoMuro = new WallType() };
        w.Execute(App());
        Check(w.SeleccionarEvent.Raises == 1 && w.Creates == 0 && TaskDialog.Messages.Count == 1,
            "invalid wall face warns and requeues selection");

        Reset(); w = new WallHarness { FaceRef = Ref(true), TipoMuro = new WallType(),
            CreationException = new InvalidOperationException("wall creation") };
        w.Execute(App());
        Check(w.SeleccionarEvent.Raises == 1 && TaskDialog.Messages.Count == 1 && w.Restores == 0,
            "wall creation exception warns and requeues selection");

        Reset(); w = new WallHarness { FaceRef = Ref(true), TipoMuro = new WallType(),
            CreationException = new Autodesk.Revit.Exceptions.OperationCanceledException() };
        w.Execute(App());
        Check(w.SeleccionarEvent.Raises == 0 && TaskDialog.Messages.Count == 0 && w.Restores == 1,
            "wall cancellation ends session without warning");

        Reset(); w = new WallHarness { FaceRef = Ref(true) }; w.Execute(App());
        Check(w.SeleccionarEvent.Raises == 0 && w.Creates == 0 && w.Restores == 1,
            "wall missing type returns configuration");

        Reset(); w = new WallHarness { TipoMuro = new WallType() }; w.Execute(App());
        Check(w.SeleccionarEvent.Raises == 0 && w.Creates == 0 && w.Restores == 1,
            "wall missing reference returns configuration");
    }
    static int Main() {
        try { SelectionTests(); FloorTests(); WallTests(); Console.WriteLine("Total assertions passed: " + Checks); return 0; }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dotnet', default=os.environ.get('DOTNET_ROOT') or shutil.which('dotnet'))
    args = parser.parse_args()
    if not args.dotnet:
        parser.error('Set DOTNET_ROOT or pass --dotnet /path/to/dotnet')
    dotnet = Path(args.dotnet).resolve()
    if dotnet.is_dir():
        dotnet /= 'dotnet'
    sdk = dotnet.parent
    compiler = sorted(sdk.glob('sdk/*/Roslyn/bincore/csc.dll'))[-1]
    refs = sorted(sdk.glob('packs/Microsoft.NETCore.App.Ref/8.*/ref/net8.0'))[-1]
    code = STUBS.replace('__SELECTOR__', execute('SeleccionarCarasHandler.cs')).replace('__FLOOR__', execute('Tarrajeo_SuelosHandler.cs')).replace('__WALL__', execute('Tarrajeo_MurosHandler.cs'))
    with tempfile.TemporaryDirectory(prefix='myg-selection-') as tmp:
        work = Path(tmp)
        (work / 'Program.cs').write_text(code, encoding='utf-8')
        (work / 'test.runtimeconfig.json').write_text(json.dumps({'runtimeOptions': {'tfm': 'net8.0', 'framework': {'name': 'Microsoft.NETCore.App', 'version': '8.0.0'}}}))
        rsp = ['-nologo', '-target:exe', '-out:test.dll', '-langversion:7.3']
        rsp += ['-r:"' + str(dll) + '"' for dll in refs.glob('*.dll')]
        rsp += ['Program.cs']
        (work / 'compile.rsp').write_text('\n'.join(rsp))
        subprocess.run([str(dotnet), str(compiler), '@compile.rsp'], cwd=work, check=True)
        subprocess.run([str(dotnet), 'test.dll'], cwd=work, check=True, timeout=30)


if __name__ == '__main__':
    main()
