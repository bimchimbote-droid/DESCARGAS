#!/usr/bin/env python3
"""Regresiones de geometría UV sin dependencias NuGet ni instalación automática.

Extrae los helpers del código de producción y los compila como C# 7.3. XYZ solo
aporta suma y multiplicación para construir puntos; no simula sólidos, booleanos
ni creación de elementos de Revit. Estos casos no sustituyen las pruebas en Revit.
Los archivos generados se guardan en un directorio temporal que se elimina al salir.
"""
from pathlib import Path
import argparse
import atexit
import json
import re
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description='Ejecuta regresiones UV extraídas del código real, sin Revit ni NuGet.')
parser.add_argument('--dotnet', default=shutil.which('dotnet'), help='Ruta al ejecutable de un SDK .NET 8 o posterior')
args = parser.parse_args()
if not args.dotnet:
    parser.error('Instala un SDK .NET o indica --dotnet /ruta/dotnet')
DOTNET = Path(args.dotnet).resolve()
SDK_ROOT = DOTNET.parent
compilers = sorted((SDK_ROOT / 'sdk').glob('*/Roslyn/bincore/csc.dll'))
refdirs = sorted((SDK_ROOT / 'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net*'))
runtimes = sorted((SDK_ROOT / 'shared/Microsoft.NETCore.App').glob('*'))
if not compilers or not refdirs or not runtimes:
    parser.error('La ruta debe contener un SDK completo con compilador y reference pack')
BASE = Path(tempfile.mkdtemp(prefix='myg-geometria-'))
atexit.register(shutil.rmtree, BASE)
REPO = Path(__file__).resolve().parents[1]
SOURCE = REPO / 'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs'
text = SOURCE.read_text(encoding='utf-8-sig')

def block(pattern):
    match = re.search(pattern, text)
    if not match:
        raise ValueError(pattern)
    start = text.index('{', match.start())
    depth = 1
    end = start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]

names = ['RestarRectangulosEnPlano', 'AgregarRestoRectangular', 'EsRectangulo', 'Similar',
         'HuellasIguales', 'LoopDesdeUV', 'Limpiar', 'EsPuntoColinealIntermedio', 'Igual',
         'Area', 'AreaAbs', 'LoopSeguro', 'TieneSegmentosCortos', 'LoopTieneCruces',
         'SegmentosIntersectan2D', 'Orient2D', 'PuntoEnSegmento2D', 'EsToqueDeExtremo', 'Dist2D']
methods = [block(r'    private [^\n]+\b' + n + r'\s*\(') for n in names]
constants = re.findall(r'    private const double (?:TOL|PTOL|BOOLEAN_RETRY_OFFSET|SOBREPASO_PERFIL)\s*=.*?;', text)
classes = [block(r'public class ' + n + r'\b') for n in ['MarcoMuro', 'LoopMuro', 'ComponenteMuro', 'UV2']]
tests = r'''
    static int passed;
    static void Check(bool ok, string name) { if (!ok) throw new Exception(name); passed++; }
    static void Near(double actual, double expected, string name) { Check(Math.Abs(actual - expected) < 1e-7, name + " (" + actual + ")"); }
    MarcoMuro frame = new MarcoMuro { Origen = new XYZ(0,0,0), U = new XYZ(1,0,0), V = new XYZ(0,1,0), Normal = new XYZ(0,0,1) };
    LoopMuro Poly(params double[] xy) {
        var pts = new List<UV2>();
        for (int i=0;i<xy.Length;i+=2) pts.Add(new UV2(xy[i],xy[i+1]));
        return LoopDesdeUV(pts,frame);
    }
    LoopMuro Rect(double a, double b, double c, double d) { return Poly(a,c,b,c,b,d,a,d,a,c); }
    ComponenteMuro C(LoopMuro lp) { return new ComponenteMuro { Exterior=lp, Huecos=new List<LoopMuro>() }; }
    List<LoopMuro> Cut(ComponenteMuro basis, params ComponenteMuro[] cutters) {
        List<LoopMuro> result;
        Check(RestarRectangulosEnPlano(basis,cutters.ToList(),out result), "accepted rectangular subtraction");
        for (int i=0;i<result.Count;i++) {
            Check(EsRectangulo(result[i]) && LoopSeguro(result[i]),"safe rectangular remainder");
            foreach (var cutter in cutters) {
                double du=Math.Min(result[i].MaxU,cutter.Exterior.MaxU)-Math.Max(result[i].MinU,cutter.Exterior.MinU);
                double dv=Math.Min(result[i].MaxV,cutter.Exterior.MaxV)-Math.Max(result[i].MinV,cutter.Exterior.MinV);
                Check(du<=1e-10 || dv<=1e-10,"remainder never overlaps a cutter");
            }
            for (int j=i+1;j<result.Count;j++) {
                double du=Math.Min(result[i].MaxU,result[j].MaxU)-Math.Max(result[i].MinU,result[j].MinU);
                double dv=Math.Min(result[i].MaxV,result[j].MaxV)-Math.Max(result[i].MinV,result[j].MinV);
                Check(du<=0 || dv<=0,"remainders disjoint");
            }
        }
        return result;
    }
    public void Run() {
        var basis=C(Rect(0,10,0,10));
        Near(Cut(basis,C(Rect(20,30,20,30))).Sum(x=>x.AreaAbs),100,"no overlap preserves area");
        Near(Cut(basis,C(Rect(10,20,0,10))).Sum(x=>x.AreaAbs),100,"edge tangent preserves area");
        Near(Cut(basis,C(Rect(10,20,10,20))).Sum(x=>x.AreaAbs),100,"corner tangent preserves area");
        Check(Cut(basis,C(Rect(-1,11,-1,11))).Count==0,"full cover removes all");
        var top=Cut(basis,C(Rect(-1,11,7,11)));
        Check(top.Count==1,"top strip leaves one rectangle"); Near(top.Sum(x=>x.AreaAbs),70,"top strip area");
        var right=Cut(basis,C(Rect(7,11,-1,11)));
        Check(right.Count==1,"right strip leaves one rectangle"); Near(right.Sum(x=>x.AreaAbs),70,"right strip area");
        var hole=Cut(basis,C(Rect(3,7,3,7)));
        Check(hole.Count==4,"internal opening leaves four pieces"); Near(hole.Sum(x=>x.AreaAbs),84,"internal opening area");
        var split=Cut(basis,C(Rect(4,6,-1,11)));
        Check(split.Count==2,"middle divider leaves two walls");Near(split.Sum(x=>x.AreaAbs),80,"middle divider area");
        var union=Cut(basis,C(Rect(2,6,2,6)),C(Rect(4,8,4,8)));
        Near(union.Sum(x=>x.AreaAbs),72,"overlapping cuts remove union once");
        var repeated=Cut(basis,C(Rect(2,6,2,6)),C(Rect(2,6,2,6)));
        Near(repeated.Sum(x=>x.AreaAbs),84,"duplicate cuts remove once");
        List<LoopMuro> ignored;
        Check(!RestarRectangulosEnPlano(basis,new List<ComponenteMuro>{C(Poly(0,0,5,0,0,5,0,0))},out ignored),"nonrectangle cutter rejected");
        var cutterWithHole=C(Rect(2,8,2,8)); cutterWithHole.Huecos.Add(Rect(3,7,3,7));
        Check(!RestarRectangulosEnPlano(basis,new List<ComponenteMuro>{cutterWithHole},out ignored),"cutter with hole rejected");
        var baseWithHole=C(Rect(0,10,0,10));baseWithHole.Huecos.Add(Rect(3,7,3,7));
        Check(!RestarRectangulosEnPlano(baseWithHole,new List<ComponenteMuro>{C(Rect(2,8,2,8))},out ignored),"base with hole rejected");
        Check(!RestarRectangulosEnPlano(basis,new List<ComponenteMuro>(),out ignored),"empty cutter list rejected");
        var a=Rect(0,10,0,10);
        var cyclic=Poly(10,0,10,10,0,10,0,0,10,0);
        var reversed=Poly(0,0,0,10,10,10,10,0,0,0);
        Check(Similar(a,cyclic),"cyclic footprint equal"); Check(Similar(a,reversed),"reversed footprint equal");
        var rotatedFrame=new MarcoMuro {Origen=new XYZ(100,40,2),U=new XYZ(0,1,0),V=new XYZ(0,0,1),Normal=new XYZ(1,0,0)};
        var axisBefore=frame;frame=rotatedFrame;var rotated=Rect(0,10,0,10);frame=axisBefore;
        Check(Similar(a,rotated),"same UV footprint in rotated frame");
        var triangle1=Poly(0,0,10,0,0,10,0,0);var triangle2=Poly(0,0,10,10,0,10,0,0);
        Near(triangle1.AreaAbs,triangle2.AreaAbs,"diagonal triangles same area");
        Check(!Similar(triangle1,triangle2),"diagonal triangles with same bbox distinguished");
        var ca=C(a);ca.Huecos.Add(Rect(2,3,2,3));ca.Huecos.Add(Rect(6,8,6,8));
        var cb=C(reversed);cb.Huecos.Add(Rect(6,8,6,8));cb.Huecos.Add(Rect(2,3,2,3));
        Check(HuellasIguales(ca,cb),"same holes in different order equal");cb.Huecos[0]=Rect(5,8,6,8);
        Check(!HuellasIguales(ca,cb),"different holes distinguished");
        Check(EsRectangulo(Poly(0,0,10,0.001,9.999,10,0.001,9.999,0,0)),"jittered corners rectangle");
        Check(!EsRectangulo(Poly(0,5,5,0,10,5,5,10,0,5)),"diagonal diamond rejected");
        Near(Cut(basis,C(Rect(9.999,11,0,10))).Sum(x=>x.AreaAbs),99.99,"thin real edge intersection trimmed");
        Check(Cut(basis,C(Rect(0.001,11,-1,11))).Count==0,"uncreatable sub-tolerance sliver omitted");
        var random=new Random(35207);
        for (int test=0;test<100;test++) {
            var cuts=new List<ComponenteMuro>();
            for(int k=0;k<5;k++) {
                int x0=random.Next(-3,13),x1=random.Next(-3,13),y0=random.Next(-3,13),y1=random.Next(-3,13);
                cuts.Add(C(Rect(Math.Min(x0,x1),Math.Max(x0,x1)+1,Math.Min(y0,y1),Math.Max(y0,y1)+1)));
            }
            double expected=0;
            for(int x=0;x<10;x++) for(int y=0;y<10;y++)
                if(!cuts.Any(c=>x+0.5>c.Exterior.MinU&&x+0.5<c.Exterior.MaxU&&y+0.5>c.Exterior.MinV&&y+0.5<c.Exterior.MaxV)) expected++;
            Near(Cut(basis,cuts.ToArray()).Sum(x=>x.AreaAbs),expected,"seeded integer grid area "+test);
        }
        Check(SOBREPASO_PERFIL>BOOLEAN_RETRY_OFFSET,"cutter overtravel exceeds boolean translation");
        Console.WriteLine("Total assertions passed: " + passed);
    }
    static int Main() { try { new Harness().Run(); return 0; } catch(Exception e) { Console.Error.WriteLine(e);return 1;} }
'''
stub = r'''
public class XYZ {
    public double X,Y,Z;
    public XYZ(double x,double y,double z) {X=x;Y=y;Z=z;}
    public XYZ Multiply(double a) {return new XYZ(X*a,Y*a,Z*a);}
    public static XYZ operator +(XYZ a,XYZ b) {return new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}
}
'''
src = '\n'.join(['using System;using System.Collections.Generic;using System.Linq;', stub, *classes,
                 'class Harness {', *constants, *methods, tests, '}'])
out = BASE / 'geometry'
out.mkdir(exist_ok=True)
(out/'Geometry.cs').write_text(src)
refs=list(refdirs[-1].glob('*.dll'))
rsp=out/'compile.rsp'
rsp.write_text('\n'.join(['-nologo','-langversion:7.3','-nostdlib+','-target:exe','-out:'+str(out/'Geometry.dll')]+['-r:'+str(p) for p in refs]+[str(out/'Geometry.cs')]))
subprocess.run([str(DOTNET),str(compilers[-1]),'@'+str(rsp)],check=True)
(out/'Geometry.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'framework':{'name':'Microsoft.NETCore.App','version':runtimes[-1].name}}}))
subprocess.run([str(DOTNET),str(out/'Geometry.dll')],check=True)
