# Actualización de Tarrajeo / Encofrado

## Base exacta y alcance

- Repositorio realmente seleccionado y utilizado: bimchimbote-droid/MYG_v27_reestructurado.
- Commit base: 56682a0299f9cb62dacecce6ef269a13c864c4b3; rama local: work.
- Antes de esta intervención no había modificaciones locales en el checkout. Los únicos cambios locales entregados son los tres handlers y los tres archivos nuevos de pruebas/documentación enumerados en ARCHIVOS.json.
- El texto de entrega menciona MYG_v27/main, cuyo ref remoto consultado es a41d354e8206e401a881aacfff3f5da7dfe74d00. NO se ha sustituido la copia actual por esa versión. Las rutas de esta actualización corresponden a la solución reestructurada; no aplicar a otra estructura sin adaptar y comparar primero.
- No se han cambiado .csproj, .slnx, paquetes, recursos, nombres de clases o namespaces. No se han eliminado archivos.

## Comportamiento

Las interferencias visibles dentro del espesor exterior se proyectan y descuentan del perfil completo del revestimiento. El cortante sobrepasa ambos extremos aun después del reintento booleano. El resultado rectangular usa creación normal; los demás resultados se crean desde el perfil. Si falla el boolean y la cara y todas las huellas son rectangulares sin huecos, se generan los restos rectangulares libres, posiblemente como varios muros. No se restaura el paño original encima del obstáculo. Los restos inferiores a la tolerancia de líneas se omiten.

Un error recuperable de la cara permite cerrar el aviso y seguir seleccionando caras y creando muros o suelos. Se evita el segundo aviso genérico si ya se informó el fallo de recorte. Esc termina la selección y vuelve al formulario. Si falla la propia selección de Revit o falta un tipo/handler/documento, se vuelve al formulario.

## Instalación

1. Cerrar Revit y respaldar la solución y la DLL usada habitualmente.
2. Comparar los tres .cs de la entrega con tus archivos actuales. REEMPLAZAR un archivo completo puede sobrescribir modificaciones locales o posteriores al commit base. Si hay diferencias propias, integrar solo este cambio mediante comparación/merge; no reemplazar a ciegas.
3. Extraer el ZIP en una carpeta temporal. Copiar los tres .cs sobre las mismas rutas de la solución reestructurada. Ya están incluidos en MYG/MYG.csproj; no volver a agregarlos ni activar otros archivos.
4. Copiar Documentacion/ y Pruebas/ solo si se desea conservar la guía y las comprobaciones. Los scripts Python son pruebas externas: NO se agregan a la compilación del add-in y no contienen otro proyecto Revit.
5. Alternativa a copiar los tres .cs: desde la raíz de una copia compatible, ejecutar `git apply --check RUTA/ENTREGA/ACTUALIZACION.patch` y luego `git apply RUTA/ENTREGA/ACTUALIZACION.patch`. No aplicar además el parche después de reemplazar los archivos. El parche solo modifica los tres .cs; copiar por separado las pruebas y documentación nuevas. Se comprobó contra el commit base y reproduce los tres archivos finales byte por byte.
6. Compilar en Visual Studio sobre Windows con las referencias reales. Cerrar Revit, actualizar la DLL y sus dependencias en una instalación de prueba y abrir un modelo de prueba. Mantener el manifiesto .addin e iconos externos existentes. El ZIP contiene fuentes; NO contiene una DLL nueva.

## Configuración

No se necesitan paquetes, referencias ni variables nuevas. Se conservan los requisitos actuales del proyecto: .NET Framework 4.8, las referencias a Revit 2027 y COM de Office/Excel. Su compatibilidad real sigue pendiente de comprobación en el equipo Windows; no se migró el proyecto ni se certificó esa combinación.

## Validación realizada

- Análisis de sintaxis Roslyn C# 7.3: 179 archivos activos, cero errores sintácticos. No es una compilación completa.
- `Pruebas/probar_geometria_tarrajeo.py`: 2437 aserciones aprobadas, sobre los helpers actuales de geometría UV. Incluye área de restos, tangencias, cobertura total, huecos, división, unión de obstáculos y ausencia de solapamientos.
- `Pruebas/test_tarrajeo_selection.py`: 33 aserciones aprobadas sobre los Execute actuales con sustitutos mínimos de API. Incluye errores, siguiente selección, Esc, limpieza de referencias y aviso duplicado.
- `git diff --check`: sin problemas.
- Parche aplicado en una carpeta temporal con los originales del commit base: tres archivos finales idénticos.

Para repetir con un SDK .NET 8 o posterior ya instalado:

```sh
python Pruebas/probar_geometria_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
python Pruebas/test_tarrajeo_selection.py --dotnet RUTA_A_LA_CARPETA_DEL_SDK_DOTNET
```

Ambos admiten `--help` y no restauran ni descargan dependencias. Requieren Python 3 y un SDK completo con compilador y reference packs. Los casos aislados no validan booleanos, transacciones ni ExternalEvent de Revit reales. Los scripts se verificaron en Linux; su ejecución desde Windows puede requerir WSL o adaptar las rutas del SDK.

## Pendiente y limitaciones

No se compiló el add-in completo ni se generó una DLL nueva: este entorno es Linux y no tiene Revit, MSBuild de .NET Framework ni registro COM de Office. Se requiere compilar y probar en Windows/Revit con el modelo de las capturas. Seguir los casos de Documentacion/PRUEBAS_TARRAJEO_RECORTE.md, incluyendo vínculos, visibilidad, huecos y sólidos tangentes. Los recortes no representables por la tolerancia o por el motor de Revit siguen pudiendo omitirse con aviso; después se puede continuar seleccionando.

## GitHub y aplicación local

La publicación del ZIP en DESCARGAS no instala nada en tu PC ni actualiza MYG_v27 o MYG_v27_reestructurado. No se hizo Push de código a esos repositorios.

En Visual Studio: abrir Cambios de Git, revisar el diff y las pruebas, seleccionar solo los archivos de esta actualización y hacer Commit local. Cuando quieras sincronizar tu propio código, revisar repositorio/rama de destino y usar Push desde Visual Studio con tu autorización. La entrega no ejecuta ese Push.

El ZIP solo contiene los archivos de ARCHIVOS.json. El manifiesto incluye hashes SHA-256 de todos salvo sí mismo. La verificación externa del ZIP y su enlace fijado al commit se informa en la respuesta de entrega.
