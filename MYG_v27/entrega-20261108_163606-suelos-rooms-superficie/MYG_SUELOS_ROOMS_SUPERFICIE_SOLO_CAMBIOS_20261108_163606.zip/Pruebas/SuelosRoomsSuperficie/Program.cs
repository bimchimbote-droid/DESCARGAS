using System.Globalization;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

// No se copian las fórmulas: Roslyn extrae las declaraciones originales,
// conservando íntegros sus cuerpos, y las compila sin referencias a Revit/UI.
var pruebas = new List<(string Grupo, string Nombre, Action Ejecutar)>();
SyntaxNode form = LeerFuente("CrearSueloDesdeRoomForm.cs");
SyntaxNode handler = LeerFuente("SUELOSDESDEROOM_EJECUCION_HANDLER.cs");
var originales = new[]
{
    Metodo(form, "CalcularDesfaseAltura"),
    Metodo(handler, "CalcularOffsetSuperiorCapa"),
    Metodo(handler, "CotaSuperiorCoincide"),
    Metodo(handler, "EsNumeroFinitoSuelo")
};
string codigo = "using System;\npublic static class MetodosReales\n{\n" +
    string.Join("\n", originales.Select(m => m.ToFullString())) + "\n}";
string? plataforma = AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") as string;
if (string.IsNullOrEmpty(plataforma))
    throw new InvalidOperationException("Faltan los ensamblados de la plataforma .NET.");
var referencias = plataforma.Split(Path.PathSeparator).Select(p => MetadataReference.CreateFromFile(p));
var compilacion = CSharpCompilation.Create("SuelosRoomsMetodosReales", [CSharpSyntaxTree.ParseText(codigo)],
    referencias, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var memoria = new MemoryStream();
var emision = compilacion.Emit(memoria);
if (!emision.Success)
    throw new InvalidOperationException(string.Join(Environment.NewLine, emision.Diagnostics));
Type clase = Assembly.Load(memoria.ToArray()).GetType("MetodosReales", throwOnError: true)!;
var desfase = Obtener<Func<bool, bool, double, double, double, double>>("CalcularDesfaseAltura");
var capa = Obtener<Func<double, double, double, bool, double>>("CalcularOffsetSuperiorCapa");
var coincide = Obtener<Func<double, double, double, bool>>("CotaSuperiorCoincide");
var finito = Obtener<Func<double, bool>>("EsNumeroFinitoSuelo");
double mm = Metros(.001);
double inferior = Metros(.05);
double superior = Metros(.01);
double[] noFinitos = [double.NaN, double.PositiveInfinity, double.NegativeInfinity];

(string Nombre, bool Superficie, bool TieneCota, double Z, double Nivel, double Manual, double Esperado)[] modos =
[
    ("manual cero", false, false, double.NaN, 0, 0, 0),
    ("manual positivo", false, false, double.NaN, 0, .25, Metros(.25)),
    ("manual negativo", false, false, double.NaN, 0, -.25, Metros(-.25)),
    ("manual con nivel positivo", false, false, double.NaN, Metros(10), -.05, Metros(-.05)),
    ("manual con nivel negativo", false, false, double.NaN, Metros(-10), .05, Metros(.05)),
    ("manual ignora pick existente", false, true, Metros(100), Metros(10), -.05, Metros(-.05)),
    ("superficie 0.25 m con nivel interno cero", true, true, Metros(.25), 0, 999, Metros(.25)),
    ("superficie con nivel positivo bajo base", true, true, Metros(10.25), Metros(10), -999, Metros(.25)),
    ("superficie con nivel positivo sobre base", true, true, Metros(9.75), Metros(10), 999, Metros(-.25)),
    ("superficie con nivel negativo bajo base", true, true, Metros(-9.75), Metros(-10), -999, Metros(.25)),
    ("superficie con nivel negativo sobre base", true, true, Metros(-10.25), Metros(-10), 999, Metros(-.25)),
    ("superficie coincide con nivel", true, true, 12, 12, 999, 0),
    ("superficie y nivel de signos opuestos", true, true, 8, -12, 999, 20)
];
foreach (var caso in modos)
    Agregar("modos de altura", caso.Nombre, () => Cerca(
        desfase(caso.Superficie, caso.TieneCota, caso.Z, caso.Nivel, caso.Manual), caso.Esperado));
Agregar("modos de altura", "cambiar manual-superficie-manual conserva cálculos separados", () =>
{
    Cerca(desfase(false, true, Metros(.25), 0, -.07), Metros(-.07));
    Cerca(desfase(true, true, Metros(.25), 0, -.07), Metros(.25));
    Cerca(desfase(false, true, Metros(.25), 0, -.07), Metros(-.07));
});
foreach (double valor in noFinitos)
{
    Agregar("modos de altura", $"superficie ignora manual {Etiqueta(valor)}", () =>
        Cerca(desfase(true, true, Metros(.25), 0, valor), Metros(.25)));
    Agregar("modos de altura", $"manual ignora superficie {Etiqueta(valor)}", () =>
        Cerca(desfase(false, true, valor, 0, -.05), Metros(-.05)));
}

foreach (double nivel in new[] { Metros(-10), 0, Metros(10) })
    Agregar("alturas inválidas", $"superficie sin pick, nivel {Etiqueta(nivel)}", () =>
        Lanza<InvalidOperationException>(() => desfase(true, false, Metros(.25), nivel, 0)));
foreach (double valor in noFinitos)
{
    Agregar("alturas inválidas", $"cota superficial {Etiqueta(valor)}", () =>
        Lanza<ArgumentException>(() => desfase(true, true, valor, 0, 0)));
    Agregar("alturas inválidas", $"desfase manual {Etiqueta(valor)}", () =>
        Lanza<ArgumentException>(() => desfase(false, false, 0, 0, valor)));
    foreach (bool superficie in new[] { false, true })
        Agregar("alturas inválidas", $"nivel {Etiqueta(valor)}, superficie={superficie}", () =>
            Lanza<ArgumentException>(() => desfase(superficie, true, 0, valor, 0)));
}
Agregar("alturas inválidas", "desbordamiento manual metros a pies", () =>
    Lanza<ArgumentException>(() => desfase(false, false, 0, 0, double.MaxValue)));
Agregar("alturas inválidas", "desbordamiento superficial positivo", () =>
    Lanza<ArgumentException>(() => desfase(true, true, double.MaxValue, -double.MaxValue, 0)));
Agregar("alturas inválidas", "desbordamiento superficial negativo", () =>
    Lanza<ArgumentException>(() => desfase(true, true, -double.MaxValue, double.MaxValue, 0)));

Agregar("capas sobre la base", "una capa 50 mm encima de superficie 0.25 m", () =>
{
    double baseFeet = desfase(true, true, Metros(.25), 0, 0);
    double top = capa(baseFeet, inferior, 0, false);
    Cerca(top, Metros(.30));
    Cerca(top - inferior, Metros(.25));
});
Agregar("capas sobre la base", "dos capas 50 y 10 mm, contacto sin penetración", () =>
{
    double baseFeet = desfase(true, true, Metros(.25), 0, 0);
    double topInferior = capa(baseFeet, inferior, superior, false);
    double topSuperior = capa(baseFeet, inferior, superior, true);
    Cerca(topInferior, Metros(.30));
    Cerca(topSuperior, Metros(.31));
    Cerca(topInferior - inferior, Metros(.25));
    Cerca(topSuperior - superior, topInferior);
    Verdadero(topSuperior > topInferior);
});
foreach (double nivel in new[] { Metros(-10), Metros(10) })
    Agregar("capas sobre la base", $"nivel no cero {Etiqueta(nivel)}, base 0.25 m", () =>
    {
        double baseFeet = desfase(true, true, Metros(.25), nivel, 0);
        double topInferior = nivel + capa(baseFeet, inferior, superior, false);
        double topSuperior = nivel + capa(baseFeet, inferior, superior, true);
        Cerca(topInferior, Metros(.30));
        Cerca(topSuperior, Metros(.31));
        Cerca(topInferior - inferior, Metros(.25));
        Cerca(topSuperior - superior, topInferior);
    });
Agregar("capas sobre la base", "manual negativo conserva base inferior negativa", () =>
{
    double baseFeet = desfase(false, false, double.NaN, 0, -.10);
    Cerca(capa(baseFeet, inferior, superior, false), Metros(-.05));
    Cerca(capa(baseFeet, inferior, superior, true), Metros(-.04));
});
Agregar("capas sobre la base", "manual positivo conserva base inferior positiva", () =>
    Cerca(capa(desfase(false, false, double.NaN, 0, .10), inferior, superior, true), Metros(.16)));
foreach (double ignorado in new[] { 0, -1, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
    Agregar("capas sobre la base", $"capa única ignora espesor superior {Etiqueta(ignorado)}", () =>
        Cerca(capa(Metros(.25), inferior, ignorado, false), Metros(.30)));

foreach (double valor in noFinitos)
{
    foreach (bool esSuperior in new[] { false, true })
    {
        Agregar("capas inválidas", $"desfase {Etiqueta(valor)}, superior={esSuperior}", () =>
            Lanza<ArgumentException>(() => capa(valor, inferior, superior, esSuperior)));
        Agregar("capas inválidas", $"inferior {Etiqueta(valor)}, superior={esSuperior}", () =>
            Lanza<ArgumentException>(() => capa(0, valor, superior, esSuperior)));
    }
    Agregar("capas inválidas", $"superior {Etiqueta(valor)}", () =>
        Lanza<ArgumentException>(() => capa(0, inferior, valor, true)));
}
foreach (double valor in new[] { 0.0, -1.0 })
{
    foreach (bool esSuperior in new[] { false, true })
        Agregar("capas inválidas", $"inferior no positivo {Etiqueta(valor)}, superior={esSuperior}", () =>
            Lanza<ArgumentException>(() => capa(0, valor, superior, esSuperior)));
    Agregar("capas inválidas", $"superior no positivo {Etiqueta(valor)}", () =>
        Lanza<ArgumentException>(() => capa(0, inferior, valor, true)));
}
Agregar("capas inválidas", "desbordamiento cota superior de capa única", () =>
    Lanza<ArgumentException>(() => capa(double.MaxValue, double.MaxValue, 0, false)));
Agregar("capas inválidas", "desbordamiento al apilar capa superior", () =>
    Lanza<ArgumentException>(() => capa(0, double.MaxValue, double.MaxValue, true)));

Agregar("cota superior real", "acepta cota exacta", () => Verdadero(coincide(Metros(.30), Metros(.30), mm)));
Agregar("cota superior real", "acepta diferencia +1 mm", () => Verdadero(coincide(mm, 0, mm)));
Agregar("cota superior real", "acepta diferencia -1 mm", () => Verdadero(coincide(-mm, 0, mm)));
Agregar("cota superior real", "acepta diferencia 0.999 mm", () => Verdadero(coincide(Metros(.000999), 0, mm)));
Agregar("cota superior real", "rechaza diferencia +1.001 mm", () => Falso(coincide(Metros(.001001), 0, mm)));
Agregar("cota superior real", "rechaza diferencia -1.001 mm", () => Falso(coincide(-Metros(.001001), 0, mm)));
Agregar("cota superior real", "rechaza offset de la cara inferior usado como superior", () =>
    Falso(coincide(Metros(.25), Metros(.30), mm)));
Agregar("cota superior real", "rechaza capa superior en la misma cota que la inferior", () =>
    Falso(coincide(Metros(.30), Metros(.31), mm)));
Agregar("cota superior real", "rechaza desfase compartido antiguo -1299.441 m", () =>
    Falso(coincide(Metros(-1299.441), Metros(.30), mm)));
Agregar("cota superior real", "rechaza desfase remoto hacia arriba", () =>
    Falso(coincide(Metros(1300.30), Metros(.30), mm)));
Agregar("cota superior real", "rechaza tolerancia cero", () => Falso(coincide(0, 0, 0)));
Agregar("cota superior real", "rechaza tolerancia negativa", () => Falso(coincide(0, 0, -mm)));
for (int posicion = 0; posicion < 3; posicion++)
{
    foreach (double invalido in noFinitos)
    {
        int indice = posicion;
        Agregar("cota superior real", $"argumento {indice + 1} {Etiqueta(invalido)}", () =>
        {
            double[] argumentos = [0, 0, mm];
            argumentos[indice] = invalido;
            Falso(coincide(argumentos[0], argumentos[1], argumentos[2]));
        });
    }
}
foreach (double valor in new[] { 0, -1, 1, double.Epsilon, double.MaxValue, -double.MaxValue })
    Agregar("finitud", $"acepta {Etiqueta(valor)}", () => Verdadero(finito(valor)));
foreach (double valor in noFinitos)
    Agregar("finitud", $"rechaza {Etiqueta(valor)}", () => Falso(finito(valor)));

Agregar("auditoría de fuente", "conserva acciones 0, 1 y 2; agrega pick 3", () =>
{
    var enumeracion = handler.DescendantNodes().OfType<EnumDeclarationSyntax>().Single(e => e.Identifier.ValueText == "RoomSueloAccion");
    var esperados = new Dictionary<string, int> { ["Ninguna"] = 0, ["SeleccionarRoom"] = 1, ["CrearSuelo"] = 2, ["PicarSuperficieBase"] = 3 };
    foreach (var par in esperados)
    {
        var miembro = enumeracion.Members.Single(m => m.Identifier.ValueText == par.Key);
        Verdadero(miembro.EqualsValue!.Value is LiteralExpressionSyntax numero && Convert.ToInt32(numero.Token.Value) == par.Value);
    }
});
Agregar("auditoría de fuente", "ExternalEvent enruta pick y restablece acción", () =>
{
    var ejecutar = Metodo(handler, "Execute");
    var rama = ejecutar.DescendantNodes().OfType<IfStatementSyntax>().Single(i => i.Condition.ToString() == "Accion == RoomSueloAccion.PicarSuperficieBase");
    Verdadero(Invocaciones(rama, "PicarSuperficieBase").Length == 1);
    Verdadero(ejecutar.DescendantNodes().OfType<FinallyClauseSyntax>().Any(f =>
        f.DescendantNodes().OfType<AssignmentExpressionSyntax>().Any(a => a.Left.ToString() == "Accion" && a.Right.ToString() == "RoomSueloAccion.Ninguna")));
});
Agregar("auditoría de fuente", "pick oculta y restaura formulario en finally", () =>
{
    var pick = Metodo(handler, "PicarSuperficieBase");
    var ocultar = Invocaciones(pick, "OcultarTemporalmenteParaSeleccion").Single();
    var seleccionar = Invocaciones(pick, "PickObject").Single();
    Verdadero(ocultar.SpanStart < seleccionar.SpanStart);
    Verdadero(pick.DescendantNodes().OfType<FinallyClauseSyntax>().Any(f => Invocaciones(f, "MostrarLuegoDeSeleccion").Length == 1));
    Verdadero(Invocaciones(Metodo(form, "OcultarTemporalmenteParaSeleccion"), "Hide").Length == 1);
    Verdadero(Invocaciones(Metodo(form, "MostrarLuegoDeSeleccion"), "Show").Length == 1);
});
Agregar("auditoría de fuente", "pick usa GlobalPoint directamente sin transformar otra vez", () =>
{
    var pick = Metodo(handler, "PicarSuperficieBase");
    var punto = pick.DescendantNodes().OfType<VariableDeclaratorSyntax>().Single(v => v.Identifier.ValueText == "punto");
    Verdadero(punto.Initializer!.Value.ToString() == "referencia.GlobalPoint");
    Falso(pick.DescendantNodes().OfType<MemberAccessExpressionSyntax>().Any(a => a.Name.Identifier.ValueText is "OfPoint" or "GetTransform" or "GetTotalTransform"));
    var aplicar = Invocaciones(pick, "AplicarCotaBaseDesdeSuperficie").Single();
    Verdadero(aplicar.ArgumentList.Arguments[0].Expression.ToString() == "punto");
});
Agregar("auditoría de fuente", "selector del pick usa ProjectElevation", () =>
    Verdadero(Metodo(handler, "ObtenerNivelMasCercanoParaSuperficie").DescendantNodes().OfType<MemberAccessExpressionSyntax>()
        .Count(a => a.Name.Identifier.ValueText == "ProjectElevation") >= 2));
Agregar("auditoría de fuente", "comando conserva contenido anterior a esta modificación", () =>
{
    // Baseline del snapshot before-files.json creado antes de esta modificación.
    // Se normalizan BOM y finales de línea para permitir checkouts de Windows.
    string comando = File.ReadAllText(Ruta("CrearSueloDesdeRoomCommand.cs")).TrimStart('\uFEFF').Replace("\r\n", "\n").Replace("\r", "\n");
    string hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(comando))).ToLowerInvariant();
    Verdadero(hash == "9028d169e74a7311c0821b699e4f7053801433a2ac8e7f1d40e2ddb4b9cc5ec5");
});
Agregar("auditoría de fuente", "dos radios de altura comparten GroupBox propio", () =>
{
    foreach (string radio in new[] { "rdbPorNivel", "rdbPorSuperficie" })
    {
        var asignacion = form.DescendantNodes().OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == radio && a.Right is ObjectCreationExpressionSyntax);
        Verdadero(((ObjectCreationExpressionSyntax)asignacion.Right).Type.ToString() == "WinForms.RadioButton");
        Verdadero(form.DescendantNodes().OfType<InvocationExpressionSyntax>().Any(i => i.Expression.ToString() == "grpModoAltura.Controls.Add" &&
            i.ArgumentList.Arguments.Single().Expression.ToString() == radio));
    }
    var grupo = form.DescendantNodes().OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == "grpModoAltura" && a.Right is ObjectCreationExpressionSyntax);
    Verdadero(((ObjectCreationExpressionSyntax)grupo.Right).Type.ToString() == "WinForms.GroupBox");
});
Agregar("auditoría de fuente", "pick mantiene campos propios sin sobrescribir modo manual", () =>
{
    var aplicar = Metodo(form, "AplicarCotaBaseDesdeSuperficie");
    var asignaciones = aplicar.DescendantNodes().OfType<AssignmentExpressionSyntax>().ToArray();
    foreach (string campo in new[] { "_cotaBaseSuperficieFeet", "_nivelBaseSuperficieId", "_tieneCotaBaseDesdeSuperficie" })
        Verdadero(asignaciones.Any(a => a.Left.ToString() == campo));
    Falso(asignaciones.Any(a => a.Left.ToString().StartsWith("txtDesfaseMetros.") || a.Left.ToString().StartsWith("cmbNivel.")));
    Falso(Invocaciones(aplicar, "SeleccionarNivelPorId").Any());
});
Agregar("auditoría de fuente", "limpiar borra solo datos de superficie", () =>
{
    var limpiar = Metodo(form, "LimpiarCotaBaseDesdeSuperficie");
    var asignaciones = limpiar.DescendantNodes().OfType<AssignmentExpressionSyntax>().ToDictionary(a => a.Left.ToString(), a => a.Right.ToString());
    Verdadero(asignaciones["_tieneCotaBaseDesdeSuperficie"] == "false");
    Verdadero(asignaciones["_cotaBaseSuperficieFeet"] == "double.NaN");
    Verdadero(asignaciones["_nivelBaseSuperficieId"] == "ElementId.InvalidElementId");
    Falso(asignaciones.Keys.Any(a => a.StartsWith("txtDesfaseMetros.") || a.StartsWith("cmbNivel.")));
});
Agregar("auditoría de fuente", "seleccionar Rooms no sobrescribe nivel de superficie", () =>
{
    var seleccionar = Invocaciones(Metodo(form, "ActualizarRoomsSeleccionados"), "SeleccionarNivelPorId").Single();
    Verdadero(seleccionar.Ancestors().OfType<IfStatementSyntax>().Any(i => i.Condition.ToString().Contains("!UsarCotaBaseDesdeSuperficie")));
});
Agregar("auditoría de fuente", "superficie sin pick impide lanzar ejecución", () =>
{
    var asignarCrear = form.DescendantNodes().OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == "Handler.Accion" && a.Right.ToString() == "RoomSueloAccion.CrearSuelo");
    var bloque = asignarCrear.Ancestors().OfType<LambdaExpressionSyntax>().Single();
    var guard = bloque.DescendantNodes().OfType<IfStatementSyntax>().Single(i =>
        i.Condition.ToString() == "UsarCotaBaseDesdeSuperficie && !TieneCotaBaseDesdeSuperficie");
    Verdadero(guard.SpanStart < asignarCrear.SpanStart && guard.Statement.DescendantNodesAndSelf().OfType<ReturnStatementSyntax>().Any());
});
Agregar("auditoría de fuente", "cambiar modo actualiza visibilidad sin limpiar datos", () =>
{
    foreach (string radio in new[] { "rdbPorNivel", "rdbPorSuperficie" })
    {
        var evento = form.DescendantNodes().OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == radio + ".CheckedChanged");
        Verdadero(Invocaciones(evento, "ActualizarVisibilidadCapas").Length == 1);
        Falso(Invocaciones(evento, "LimpiarCotaBaseDesdeSuperficie").Any());
    }
    var visibilidad = Metodo(form, "ActualizarVisibilidadCapas");
    foreach (string control in new[] { "cmbNivel", "txtDesfaseMetros" })
        Verdadero(visibilidad.DescendantNodes().OfType<AssignmentExpressionSyntax>().Any(a => a.Left.ToString() == control + ".Visible" && a.Right.ToString() == "!porSuperficie"));
    Verdadero(visibilidad.DescendantNodes().OfType<AssignmentExpressionSyntax>().Any(a => a.Left.ToString() == "btnPicarSuperficie.Visible" && a.Right.ToString() == "porSuperficie"));
});
Agregar("auditoría de fuente", "formulario usa ProjectElevation en el cálculo real", () =>
{
    var calcular = Invocaciones(Metodo(form, "ObtenerDesfaseBaseFeet"), "CalcularDesfaseAltura").Single();
    Verdadero(calcular.ArgumentList.Arguments[3].Expression.ToString() == "nivel.ProjectElevation");
    Verdadero(calcular.ArgumentList.Arguments[4].Expression.ToString() == "DesfaseMetros");
});
Agregar("auditoría de fuente", "handler calcula desfase mediante formulario", () =>
{
    var obtener = Invocaciones(Metodo(handler, "CrearSuelosDesdeRooms"), "ObtenerDesfaseBaseFeet").Single();
    Verdadero(obtener.Expression.ToString() == "Form.ObtenerDesfaseBaseFeet");
    Verdadero(obtener.ArgumentList.Arguments.Single().Expression.ToString() == "nivel");
});
Agregar("auditoría de fuente", "ambas capas usan helper y offsets respectivos", () =>
{
    var crear = Metodo(handler, "CrearSuelosDesdeRooms");
    var helpers = Invocaciones(crear, "CalcularOffsetSuperiorCapa");
    Verdadero(helpers.Length == 2);
    Verdadero(helpers.All(i => i.ArgumentList.Arguments[0].Expression.ToString() == "desfaseFeet"));
    Verdadero(helpers.Any(i => i.ArgumentList.Arguments[3].Expression.IsKind(SyntaxKind.FalseLiteralExpression)));
    Verdadero(helpers.Any(i => i.ArgumentList.Arguments[3].Expression.IsKind(SyntaxKind.TrueLiteralExpression)));
    var creaciones = Invocaciones(crear, "CrearSueloConOffsetSuperior");
    Verdadero(creaciones.Length == 2);
    Verdadero(creaciones.Select(i => i.ArgumentList.Arguments[6].Expression.ToString()).OrderBy(s => s)
        .SequenceEqual(new[] { "offsetSuperiorInferior", "offsetSuperiorSuperior" }));
});
Agregar("auditoría de fuente", "Set se verifica leyendo la restricción real tras regenerar", () =>
{
    var crear = Metodo(handler, "CrearSueloConOffsetSuperior");
    var set = Invocaciones(crear, "Set").Single(i => i.Expression.ToString() == "offsetParam.Set");
    Verdadero(set.ArgumentList.Arguments.Single().Expression.ToString() == "offsetSuperiorFeet");
    var regenerar = Invocaciones(crear, "Regenerate").Single();
    var verificar = Invocaciones(crear, "CotaSuperiorCoincide").Single();
    var confirmar = Invocaciones(crear, "Commit").Single();
    Verdadero(set.SpanStart < regenerar.SpanStart && regenerar.SpanStart < verificar.SpanStart && verificar.SpanStart < confirmar.SpanStart);
    Verdadero(verificar.ArgumentList.Arguments[0].Expression.ToString() == "nivelReal.ProjectElevation + offsetParam.AsDouble()");
    Verdadero(verificar.ArgumentList.Arguments[1].Expression.ToString() == "nivel.ProjectElevation + offsetSuperiorFeet");
});
Agregar("auditoría de fuente", "fallo de intento revierte SubTransaction", () =>
{
    var crear = Metodo(handler, "CrearSueloConOffsetSuperior");
    Verdadero(crear.DescendantNodes().OfType<ObjectCreationExpressionSyntax>().Any(c => c.Type.ToString() == "SubTransaction"));
    var capturas = crear.DescendantNodes().OfType<CatchClauseSyntax>().ToArray();
    Verdadero(capturas.Length >= 2 && capturas.All(c => Invocaciones(c, "RollBack").Length == 1));
});
Agregar("auditoría de fuente", "fallo fatal de regeneración se propaga en intento y Room", () =>
{
    foreach (string nombre in new[] { "CrearSueloConOffsetSuperior", "CrearSuelosDesdeRooms" })
    {
        var fatal = Metodo(handler, nombre).DescendantNodes().OfType<CatchClauseSyntax>().Single(c =>
            c.Declaration?.Type.ToString() == "Autodesk.Revit.Exceptions.RegenerationFailedException");
        Verdadero(fatal.Block.Statements.OfType<ThrowStatementSyntax>().Any(t => t.Expression is null));
        var capturas = ((TryStatementSyntax)fatal.Parent!).Catches;
        Verdadero(capturas.IndexOf(fatal) < capturas.IndexOf(capturas.Single(c => c.Declaration?.Type.ToString() == "Exception")));
    }
});

int correctas = 0;
int fallidas = 0;
foreach (var prueba in pruebas)
{
    try
    {
        prueba.Ejecutar();
        correctas++;
        Console.WriteLine($"OK [{prueba.Grupo}] {prueba.Nombre}");
    }
    catch (Exception ex)
    {
        fallidas++;
        Console.Error.WriteLine($"FALLO [{prueba.Grupo}] {prueba.Nombre}: {ex.Message}");
    }
}
Console.WriteLine();
foreach (var grupo in pruebas.GroupBy(p => p.Grupo))
    Console.WriteLine($"{grupo.Key}: {grupo.Count()} casos");
Console.WriteLine($"TOTAL: {pruebas.Count}; CORRECTAS: {correctas}; FALLIDAS: {fallidas}");
Console.WriteLine("Alcance: cuatro métodos reales y auditoría de fuente; no ejecuta Revit/WinForms ni compila el addin.");
return fallidas == 0 ? 0 : 1;

T Obtener<T>(string nombre) where T : Delegate =>
    (T)clase.GetMethod(nombre, BindingFlags.NonPublic | BindingFlags.Static)!.CreateDelegate(typeof(T));
void Agregar(string grupo, string nombre, Action ejecutar) => pruebas.Add((grupo, nombre, ejecutar));
static string Ruta(string nombre) => Path.Combine(AppContext.BaseDirectory, "CodigoFuente", nombre);
static SyntaxNode LeerFuente(string nombre) => CSharpSyntaxTree.ParseText(File.ReadAllText(Ruta(nombre))).GetRoot();
static MethodDeclarationSyntax Metodo(SyntaxNode fuente, string nombre) => fuente.DescendantNodes().OfType<MethodDeclarationSyntax>()
    .Single(m => m.Identifier.ValueText == nombre);
static InvocationExpressionSyntax[] Invocaciones(SyntaxNode nodo, string nombre) =>
    nodo.DescendantNodes().OfType<InvocationExpressionSyntax>().Where(i => i.Expression switch
    {
        IdentifierNameSyntax identificador => identificador.Identifier.ValueText == nombre,
        MemberAccessExpressionSyntax miembro => miembro.Name.Identifier.ValueText == nombre,
        _ => false
    }).ToArray();
static double Metros(double metros) => metros / .3048;
static string Etiqueta(double valor) => valor.ToString("G17", CultureInfo.InvariantCulture);
static void Verdadero(bool valor)
{
    if (!valor) throw new InvalidOperationException("Se esperaba verdadero.");
}
static void Falso(bool valor)
{
    if (valor) throw new InvalidOperationException("Se esperaba falso.");
}
static void Cerca(double real, double esperado)
{
    if (double.IsNaN(real) || double.IsInfinity(real) || Math.Abs(real - esperado) > 1e-8)
        throw new InvalidOperationException($"Se esperaba {Etiqueta(esperado)}, obtenido {Etiqueta(real)} pies.");
}
static void Lanza<T>(Action accion) where T : Exception
{
    try { accion(); }
    catch (T) { return; }
    throw new InvalidOperationException($"Se esperaba {typeof(T).Name}.");
}
