# Pruebas de Suelos desde Rooms: nivel o superficie

Este proyecto verifica cuatro métodos **reales** extraídos con Roslyn de las fuentes de `MYG/Funcionalidades/Arquitectura/Habitaciones/`: `CalcularDesfaseAltura` del formulario, y `CalcularOffsetSuperiorCapa`, `CotaSuperiorCoincide` y `EsNumeroFinitoSuelo` del handler. Las declaraciones se compilan en memoria sin cambiar sus cuerpos. No hay copias de sus fórmulas, sustitutos de Revit ni ejecución de WinForms.

Las pruebas comprueban las dos formas de elegir la altura: nivel más desfase manual o superficie picada. La altura elegida representa la **cara inferior del suelo único o de la capa inferior**. Los espesores quedan encima de esa base. Con 50 mm de capa inferior y 10 mm de superior, la cara inferior de la superior coincide con la cara superior de la inferior. Se prueban nivel interno cero y niveles positivos/negativos, base de superficie a 0.25 m, modo manual con desfases negativos, cambio de modo, datos del otro modo ignorados, selección de superficie ausente, valores no finitos, espesores no positivos y desbordamientos.

La comparación de cota superior se prueba contra errores de referencia remotos y contra tolerancia de 1 mm. La cota compartida mostrada de 1299.691 m no forma parte del método matemático: una auditoría de fuente comprueba que se pasa `nivel.ProjectElevation`, y la regresión de cota superior rechaza el antiguo valor remoto de -1299.441 m.

Las auditorías de código comprueban numeración estable de acciones, ruta del ExternalEvent para picar, ocultar/restaurar en `finally`, uso directo de `Reference.GlobalPoint`, controles de modo en su propio GroupBox, estado de superficie separado de los controles manuales, limpieza de selección, selección de Rooms sin sobrescribir el nivel de superficie, bloqueo cuando falta el pick y visibilidad según modo. También verifican que el handler utiliza el cálculo del formulario y los offsets de ambas capas, lee el resultado real después de `Set`/regeneración y antes de confirmar, revierte intentos fallidos y propaga la excepción fatal de regeneración.

La comprobación de comando intacto compara `CrearSueloDesdeRoomCommand.cs` con el SHA256 `9028d169e74a7311c0821b699e4f7053801433a2ac8e7f1d40e2ddb4b9cc5ec5`, registrado antes de esta modificación en el snapshot de entrega `before-files.json`. Normaliza BOM y finales de línea para permitir checkouts de Windows. El comando se lee del proyecto existente y no se entrega como archivo modificado. Si se decide modificar ese comando en el futuro, deberá revisarse ese baseline.

## Ejecutar

Requiere .NET SDK 10. Roslyn se referencia desde `$(MSBuildSDKsPath)/../Roslyn/bincore`, incluido en el SDK. No usa paquetes NuGet externos.

Desde la raíz del repositorio:

```bash
dotnet run --project Pruebas/SuelosRoomsSuperficie/SuelosRoomsSuperficie.Tests.csproj --configuration Release
```

En el entorno en la nube puede activarse el SDK instalado con:

```bash
source /workspace/.onboarding/MYG_v27/activate.sh
```

La consola informa los totales por grupo. Cualquier fallo de prueba, extracción o compilación termina con código de salida distinto de cero. Los métodos usan pies internos; los valores expresados en metros se convierten con 1 pie = 0.3048 m.

## Alcance

Estas pruebas no compilan el addin ni ejecutan Revit o WinForms. Comprueban matemáticas reales y sintaxis presente; no comprueban la ejecución de UI, selección, `Floor.Create`, `Parameter.Set`, geometría ni transacciones de Revit. La integración con modelos representativos, distintos tipos de suelo y superficies debe verificarse dentro de Revit con la solución completa. El modo superficie utiliza la altura del punto picado para crear un suelo horizontal; no reproduce pendientes de la cara.
