# Crear suelo desde Rooms: por nivel o picando superficie

Actualización parcial para la estructura reorganizada de `bimchimbote-droid/MYG_v27` utilizada en esta conversación. Se conservan las correcciones anteriores de tarrajeo, muros por contorno y muros desde Rooms. El ZIP contiene únicamente las fuentes modificadas, pruebas nuevas y documentación de esta entrega.

## Archivos del add-in

| Ruta relativa a la raíz de tu solución | Acción |
| --- | --- |
| `MYG/Funcionalidades/Arquitectura/Habitaciones/CrearSueloDesdeRoomForm.cs` | REEMPLAZAR completo |
| `MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs` | REEMPLAZAR completo |

No debes agregar fuentes al proyecto del add-in ni modificar el comando, el Ribbon, `.csproj`, recursos, paquetes o manifiesto. La acción nueva usa el mismo `ExternalEvent`. Los valores anteriores del enum permanecen y se añade `PicarSuperficieBase = 3`.

## Uso

### Por nivel y desfase

Es el modo inicial. Selecciona Rooms, tipos de suelo y nivel; introduce el desfase de la base del suelo inferior o único respecto al nivel. La cota interna del nivel se usa en los cálculos, evitando mezclarla con una elevación mostrada en coordenadas compartidas.

### Picar superficie

1. Selecciona los Rooms y los tipos de suelo.
2. Activa **Picar superficie**. Los controles manuales de nivel y desfase se ocultan.
3. Pulsa **PICAR SUPERFICIE** y selecciona una cara del documento actual. La ventana se oculta temporalmente y se restaura al terminar o cancelar.
4. Se toma la altura interna del punto picado y se asocia automáticamente un nivel cercano. La ventana muestra esa cota y el nivel asociado.
5. Pulsa **EJECUTAR**.

La selección establece una altura: los suelos siguen siendo horizontales y no copian la pendiente de la cara. Este selector usa `ObjectType.Face`, como la herramienta de muros desde Rooms; no añade una selección específica de elementos vinculados.

Si presionas Escape, se conserva la última selección válida. **LIMPIAR** invalida la cota de superficie: debes picar otra o volver al modo por nivel; no se crea silenciosamente a cota cero. Cambiar de modo no borra el nivel ni el desfase manuales. Seleccionar otros Rooms en modo superficie no cambia su nivel automático.

## Una o dos capas: base inferior y ambas encima

La referencia elegida es la **cara inferior del conjunto**, tal como confirmó el usuario. No es el encuentro entre capas ni la cara superior del acabado.

- Una capa: base = cota elegida; cara superior = base + espesor del suelo único.
- Dos capas: base del inferior = cota elegida; encuentro = base + espesor inferior; cara superior del acabado = base + espesor inferior + espesor superior.

Por ejemplo, una base a 0,25 m con suelo inferior de 0,05 m y superior de 0,01 m produce encuentro a 0,30 m y acabado superior a 0,31 m. Ambos quedan encima de la base y las capas se tocan sin solaparse entre sí según sus espesores.

Estas son las fórmulas que ya usaba realmente el modo manual. Se corrige el texto anterior que decía "encuentro" pese a calcular la base inferior. No se modifica el diseño de los perfiles de Rooms, puertas, quiebres, huecos ni parámetros automáticos.

Cada intento de crear un suelo tiene ahora una `SubTransaction`. Si falla aplicar su desfase o verificar la cota superior resultante de las restricciones, se revierte ese intento antes del siguiente respaldo, evitando dejar suelos fallidos duplicados. Un error de regeneración aborta el lote en lugar de continuar.

El formulario incluye desplazamiento vertical cuando el contenido no cabe en la pantalla. Debe verificarse visualmente en Windows con la escala de pantalla del usuario.

## Instalar

1. Respalda tu solución y DLL actuales. Si cambiaste alguno de estos archivos después de la versión reorganizada, compara tus cambios antes de reemplazarlos.
2. Extrae el ZIP y copia solamente los dos `.cs` de la tabla conservando las rutas. Ya pertenecen al proyecto; no agregues copias duplicadas.
3. Recompila con Visual Studio/MSBuild de .NET Framework en Windows y tus referencias reales de Revit y Office/Excel. Restaura NuGet si faltan paquetes. Después de restaurar, el comando equivalente es `MSBuild.exe MYG\MYG.csproj /t:Build /p:Configuration=Release /p:Platform=x64`.
4. Cierra Revit antes de sustituir la DLL compilada. Conserva `.addin`, iconos y dependencias existentes.
5. Prueba en una copia del modelo las cuatro combinaciones: una/dos capas con nivel/superficie. Comprueba un desfase manual positivo y negativo, superficie a cota interna no nula, niveles con cotas compartidas, Escape, LIMPIAR, cambio de modo y puertas con quiebre.

No se mueven ni eliminan suelos creados antes de instalar esta entrega. El comportamiento parcial preexistente se conserva: si una capa no puede crearse después de sus respaldos, puede quedar la otra capa válida y se informa el error parcial.

## Validación y límites

`VERIFICACION.json` registra los resultados reales de las pruebas y el análisis de código de esta entrega. Las pruebas extraen métodos reales mediante Roslyn; no ejecutan Revit ni el formulario WinForms.

Se analizaron los 179 archivos activos con sintaxis C# 7.3. La compilación completa en Linux sigue bloqueada por `MSB4803` debido a las referencias COM; no se generó una DLL aquí. Compilar, abrir el formulario y verificar la geometría en tu modelo siguen pendientes en Windows/Revit.

La comprobación de cota superior usa las restricciones del suelo, no certifica toda su geometría ni ausencia de interferencias con cualquier elemento. Las opciones y limitaciones preexistentes de recorte, uniones y solapes permanecen.

`Pruebas/SuelosRoomsSuperficie/` es opcional para desarrollo. No agregues sus archivos al proyecto del add-in. Requiere SDK .NET 10 para ejecutar `dotnet run --project Pruebas/SuelosRoomsSuperficie/SuelosRoomsSuperficie.Tests.csproj` desde la solución actualizada. No instala paquetes externos ni cambia el framework del add-in.

La base Git es `a41d354e8206e401a881aacfff3f5da7dfe74d00`, más la reorganización y correcciones anteriores de la sesión. Solo se publica el ZIP en `bimchimbote-droid/DESCARGAS`; no se hace Push a `MYG_v27`. Tras instalar y validar, revisa Cambios de Git en Visual Studio y realiza Commit/Push a tu rama cuando corresponda.
