﻿// =====================================
// HANDLER EXTERNO 2.6
// CREAR SUELO DESDE ROOMS
// REVIT 2027
// SELECCIÓN MÚLTIPLE + PUERTAS + DESFASE
// DESCUENTO OPCIONAL DE INTERSECCIONES + DESCUENTO DE SOLAPES ENTRE SUELOS
// 1 CAPA O 2 CAPAS: SUELO ÚNICO / INFERIOR + SUPERIOR | UNIÓN GEOMÉTRICA CON MUROS ANFITRIONES DE PUERTAS
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.IO;
using System.Text;

namespace MYG_Addin
{
    public class EjecutarCrearSueloDesdeRoomHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        public CrearSueloDesdeRoomForm Form { get; set; }

        public RoomSueloAccion Accion { get; set; } = RoomSueloAccion.Ninguna;

        // Cache liviano por ejecución para no recolectar puertas por cada segmento del Room.
        private List<FamilyInstance> _cachePuertasDocumento = null;

        public string GetName()
        {
            return "MYG - Crear suelo desde Rooms";
        }

        public void Execute(UIApplication app)
        {
            if (UiDoc == null || UiDoc.Document == null)
                return;

            if (Form == null || Form.IsDisposed)
                return;

            try
            {
                if (Accion == RoomSueloAccion.SeleccionarRoom)
                {
                    SeleccionarRooms();
                    return;
                }

                if (Accion == RoomSueloAccion.PicarSuperficieBase)
                {
                    PicarSuperficieBase();
                    return;
                }

                if (Accion == RoomSueloAccion.CrearSuelo)
                {
                    CrearSuelosDesdeRooms();
                    return;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                MostrarEnVentana("Selección cancelada por el usuario.");
            }
            catch (Exception ex)
            {
                MostrarEnVentana("ERROR:\r\n" + ex.Message);
            }
            finally
            {
                Accion = RoomSueloAccion.Ninguna;
            }
        }

        // =========================================================
        // SELECCIONAR VARIOS ROOMS
        // =========================================================

        private void SeleccionarRooms()
        {
            Document doc = UiDoc.Document;

            try
            {
                Form.OcultarTemporalmenteParaSeleccion();

                IList<Reference> referencias = UiDoc.Selection.PickObjects(
                    ObjectType.Element,
                    new FiltroSeleccionRoomMYG(),
                    "Seleccione una o más habitaciones / Rooms");

                if (referencias == null || referencias.Count == 0)
                    return;

                List<Room> rooms = new List<Room>();

                foreach (Reference referencia in referencias)
                {
                    if (referencia == null)
                        continue;

                    Room room = doc.GetElement(referencia.ElementId) as Room;

                    if (room == null)
                        continue;

                    if (room.Area <= 0)
                        continue;

                    if (!rooms.Any(x => x.Id.Value == room.Id.Value))
                        rooms.Add(room);
                }

                if (rooms.Count == 0)
                {
                    MostrarEnVentana(
                        "No se seleccionó ningún Room válido.\r\n\r\n" +
                        "Verifique que las habitaciones estén colocadas y cerradas correctamente.");
                    return;
                }

                Form.ActualizarRoomsSeleccionados(rooms);
            }
            finally
            {
                Form.MostrarLuegoDeSeleccion();
            }
        }

        private void PicarSuperficieBase()
        {
            try
            {
                Form.OcultarTemporalmenteParaSeleccion();
                Reference referencia = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    "Pique una superficie: se usará la altura del punto como base del suelo");

                if (referencia == null)
                    return;

                // GlobalPoint ya pertenece al documento anfitrión. La selección
                // fija una altura horizontal, no copia la pendiente de la cara.
                XYZ punto = referencia.GlobalPoint;
                if (punto == null || !EsNumeroFinitoSuelo(punto.Z))
                {
                    MostrarEnVentana("No se pudo obtener una cota válida. Vuelva a picar la superficie.");
                    return;
                }

                Level nivel = ObtenerNivelMasCercanoParaSuperficie(UiDoc.Document, punto.Z);
                if (nivel == null)
                {
                    MostrarEnVentana("No se encontró un nivel para asociar el suelo a la superficie.");
                    return;
                }

                // Solo se sustituye la selección anterior después de un pick
                // válido. Escape conserva la cota y el nivel que ya existían.
                Form.AplicarCotaBaseDesdeSuperficie(punto, nivel);
            }
            finally
            {
                Form.MostrarLuegoDeSeleccion();
            }
        }

        private Level ObtenerNivelMasCercanoParaSuperficie(Document doc, double z)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .Where(nivel => EsNumeroFinitoSuelo(nivel.ProjectElevation))
                .OrderBy(nivel => Math.Abs(nivel.ProjectElevation - z))
                .FirstOrDefault();
        }

        // =========================================================
        // CREAR SUELOS DESDE VARIOS ROOMS
        // Modo 1 capa:
        //    Crea solo el tipo seleccionado como suelo inferior/único.
        // Modo 2 capas:
        //    Crea suelo inferior + suelo superior apilados.
        // =========================================================

        private void CrearSuelosDesdeRooms()
        {
            Document doc = UiDoc.Document;

            // Se reinicia en cada ejecución.
            _cachePuertasDocumento = null;

            List<ElementId> roomIds = Form.RoomsSeleccionadosIds;
            ElementId floorTypeInferiorId = Form.TipoSueloInferiorSeleccionadoId;
            ElementId floorTypeSuperiorId = Form.TipoSueloSuperiorSeleccionadoId;
            ElementId levelId = Form.NivelSeleccionadoId;

            bool usarDosCapas = Form.UsarDosCapas;
            bool incluirPuertas = Form.IncluirPuertas;
            bool descontarIntersecciones = Form.DescontarIntersecciones;

            if (Form.UsarCotaBaseDesdeSuperficie && !Form.TieneCotaBaseDesdeSuperficie)
            {
                MostrarEnVentana("Pique una superficie antes de ejecutar en modo superficie.");
                return;
            }

            double desfaseMetros = 0.0;
            double desfaseFeet = 0.0;

            // Profundidad manual del quiebre en puertas.
            // 0.00 = usa el cálculo automático original.
            // > 0.00 = fuerza esa profundidad en metros desde el borde del Room hacia la puerta.
            double profundidadQuiebrePuertasMetros = 0.0;

            try
            {
                profundidadQuiebrePuertasMetros = Form.ProfundidadQuiebrePuertasMetros;
            }
            catch
            {
                profundidadQuiebrePuertasMetros = 0.0;
            }

            if (profundidadQuiebrePuertasMetros < 0.0)
                profundidadQuiebrePuertasMetros = 0.0;

            double profundidadQuiebrePuertasFeet = profundidadQuiebrePuertasMetros > 0.000001
                ? MetrosAPies(profundidadQuiebrePuertasMetros)
                : 0.0;

            if (roomIds == null || roomIds.Count == 0)
            {
                MostrarEnVentana("Debe seleccionar una o más habitaciones / Rooms.");
                return;
            }

            if (floorTypeInferiorId == ElementId.InvalidElementId)
            {
                MostrarEnVentana(usarDosCapas
                    ? "Debe seleccionar el tipo de suelo inferior."
                    : "Debe seleccionar el tipo de suelo.");
                return;
            }

            if (usarDosCapas && floorTypeSuperiorId == ElementId.InvalidElementId)
            {
                MostrarEnVentana("Debe seleccionar el tipo de suelo superior.");
                return;
            }

            if (levelId == ElementId.InvalidElementId)
            {
                MostrarEnVentana("Debe seleccionar un nivel de referencia.");
                return;
            }

            FloorType floorTypeInferior = doc.GetElement(floorTypeInferiorId) as FloorType;
            FloorType floorTypeSuperior = usarDosCapas ? doc.GetElement(floorTypeSuperiorId) as FloorType : null;
            Level nivel = doc.GetElement(levelId) as Level;

            if (floorTypeInferior == null)
            {
                MostrarEnVentana("No se encontró el tipo de suelo inferior seleccionado.");
                return;
            }

            if (usarDosCapas && floorTypeSuperior == null)
            {
                MostrarEnVentana("No se encontró el tipo de suelo superior seleccionado.");
                return;
            }

            if (nivel == null)
            {
                MostrarEnVentana("No se encontró el nivel seleccionado.");
                return;
            }

            // Mismo cálculo que la vista previa. Nunca se resta la cota
            // mostrada/compartida de un nivel a un punto de geometría interna.
            desfaseFeet = Form.ObtenerDesfaseBaseFeet(nivel);
            desfaseMetros = desfaseFeet * 0.3048;

            double espesorSueloInferior = ObtenerEspesorTipoSuelo(floorTypeInferior);
            double espesorSueloSuperior = usarDosCapas && floorTypeSuperior != null
                ? ObtenerEspesorTipoSuelo(floorTypeSuperior)
                : 0.0;

            if (!EsNumeroFinitoSuelo(espesorSueloInferior) || espesorSueloInferior <= 0.0 ||
                (usarDosCapas && (!EsNumeroFinitoSuelo(espesorSueloSuperior) || espesorSueloSuperior <= 0.0)))
            {
                MostrarEnVentana("Los tipos de suelo deben tener un espesor positivo para colocarlos sobre la base elegida.");
                return;
            }

            double offsetSuperiorInferior = CalcularOffsetSuperiorCapa(
                desfaseFeet, espesorSueloInferior, espesorSueloSuperior, false);
            double offsetSuperiorSuperior = usarDosCapas
                ? CalcularOffsetSuperiorCapa(desfaseFeet, espesorSueloInferior, espesorSueloSuperior, true)
                : 0.0;

            int roomsConAlMenosUnSuelo = 0;
            int suelosInferioresCreados = 0;
            int suelosSuperioresCreados = 0;
            int suelosCreadosTotal = 0;
            int omitidos = 0;
            int errores = 0;
            int totalPuertas = 0;
            int totalDescuentos = 0;
            int totalSolapesEntreSuelos = 0;
            int totalMurosAnfitrionesUnidos = 0;

            List<ElementId> suelosCreados = new List<ElementId>();
            List<string> reporte = new List<string>();
            List<string> diagnostico = new List<string>();

            diagnostico.Add("============================================================");
            diagnostico.Add("MYG - DIAGNÓSTICO PROFUNDO CREAR SUELO DESDE ROOMS");
            diagnostico.Add("Fecha: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            diagnostico.Add("Documento: " + (doc != null ? doc.Title : ""));
            diagnostico.Add("Rooms seleccionados: " + roomIds.Count.ToString());
            diagnostico.Add("Modo: " + (usarDosCapas ? "2 capas" : "1 capa"));
            diagnostico.Add("Tipo inferior/único: " + floorTypeInferior.Name + " | Id: " + floorTypeInferior.Id.Value.ToString());
            diagnostico.Add("Tipo superior: " + (usarDosCapas && floorTypeSuperior != null ? floorTypeSuperior.Name + " | Id: " + floorTypeSuperior.Id.Value.ToString() : "No aplica"));
            diagnostico.Add("Nivel: " + nivel.Name + " | Cota interna(ft): " + nivel.ProjectElevation.ToString("0.#####", CultureInfo.InvariantCulture));
            diagnostico.Add("Modo de altura: " + (Form.UsarCotaBaseDesdeSuperficie ? "Superficie picada" : "Nivel y desfase"));
            diagnostico.Add("Desfase(m): " + desfaseMetros.ToString("0.###", CultureInfo.InvariantCulture));
            diagnostico.Add("Profundidad quiebre puertas(m): " + profundidadQuiebrePuertasMetros.ToString("0.###", CultureInfo.InvariantCulture));
            diagnostico.Add("Incluir puertas: " + incluirPuertas.ToString());
            diagnostico.Add("Descontar intersecciones: " + descontarIntersecciones.ToString());
            diagnostico.Add("============================================================");

            // Huellas temporales de suelos creados en esta misma ejecución.
            // El Room que se crea después descuenta la huella del Room anterior.
            // Se guarda una sola huella por Room, porque el suelo inferior y superior
            // comparten el mismo boceto en planta.
            List<Solid> solidosSuelosCreadosEnEjecucion = new List<Solid>();

            using (Transaction tx = new Transaction(doc, usarDosCapas ? "MYG - Crear suelos dobles desde Rooms" : "MYG - Crear suelo desde Rooms"))
            {
                tx.Start();

                foreach (ElementId roomId in roomIds)
                {
                    try
                    {
                        Room room = doc.GetElement(roomId) as Room;

                        if (room == null)
                        {
                            omitidos++;
                            reporte.Add("OMITIDO: Room no encontrado.");
                            continue;
                        }

                        diagnostico.Add("------------------------------------------------------------");
                        diagnostico.Add("ROOM ID: " + room.Id.Value.ToString());
                        diagnostico.Add("Nombre: " + ObtenerNombreRoom(room));
                        diagnostico.Add("Area interna Revit: " + room.Area.ToString("0.#####", CultureInfo.InvariantCulture));
                        diagnostico.Add("LevelId Room: " + room.LevelId.Value.ToString());
                        diagnostico.Add(ResumirBoundarySegmentsRoom(room));

                        int puertasIncluidas = 0;
                        List<ElementId> murosAnfitrionesPuertasRoom = new List<ElementId>();

                        // Perfil limpio del Room SIN puertas.
                        // Este respaldo es clave: si algún chinchón de puerta rompe el boceto,
                        // el ambiente igual debe poder crear su suelo normal.
                        IList<CurveLoop> perfilesSinPuertas = ObtenerPerfilesDesdeRoomSinPuertas(
                            doc,
                            room,
                            nivel);

                        diagnostico.Add(ResumirPerfilesParaDiagnostico("Perfiles limpios SIN puertas", perfilesSinPuertas));
                        diagnostico.Add("Prueba temporal perfiles limpios SIN puertas: " + ProbarExtrusionTemporalParaDiagnostico(perfilesSinPuertas));

                        IList<CurveLoop> perfilesBase = ObtenerPerfilesDesdeRoom(
                            doc,
                            room,
                            nivel,
                            incluirPuertas,
                            profundidadQuiebrePuertasFeet,
                            out puertasIncluidas,
                            out murosAnfitrionesPuertasRoom);

                        totalPuertas += puertasIncluidas;

                        diagnostico.Add("Puertas incluidas en boceto: " + puertasIncluidas.ToString());
                        diagnostico.Add("Muros anfitriones detectados: " + (murosAnfitrionesPuertasRoom != null ? murosAnfitrionesPuertasRoom.Count.ToString() : "0"));
                        diagnostico.Add(ResumirPerfilesParaDiagnostico("Perfiles con puertas/chinchón", perfilesBase));
                        diagnostico.Add("Prueba temporal perfiles con puertas/chinchón: " + ProbarExtrusionTemporalParaDiagnostico(perfilesBase));

                        if ((perfilesBase == null || perfilesBase.Count == 0) &&
                            perfilesSinPuertas != null && perfilesSinPuertas.Count > 0)
                        {
                            perfilesBase = perfilesSinPuertas;
                            diagnostico.Add("AVISO: el perfil con puertas/chinchón no fue utilizable. Se usó boundary limpio sin puertas.");

                            reporte.Add(
                                "AVISO: " + ObtenerNombreRoom(room) +
                                " | El perfil con puertas/chinchones no fue utilizable. Se usó boundary limpio sin puertas.");
                        }

                        if (perfilesBase == null || perfilesBase.Count == 0)
                        {
                            omitidos++;
                            reporte.Add(
                                "OMITIDO: " + ObtenerNombreRoom(room) +
                                " sin boundary válido incluso sin puertas. Revisar Room no cerrado, separadores o contorno con segmentos no conectados.");
                            diagnostico.Add("RESULTADO: OMITIDO");
                            diagnostico.Add("MOTIVO: ObtenerPerfilesDesdeRoom devolvió 0 perfiles incluso usando boundary limpio sin puertas.");
                            continue;
                        }

                        IList<CurveLoop> perfilesFinales = perfilesBase;
                        diagnostico.Add("PerfilesFinales iniciales = perfilesBase.");

                        // Descuenta muros, columnas y elementos físicos.
                        // Queda desactivado por defecto en la ventana para evitar crasheos en modelos pesados.
                        if (descontarIntersecciones)
                        {
                            int descuentosRoom = 0;

                            IList<CurveLoop> perfilesDescontados = DescontarInterseccionesEnPlanta(
                                doc,
                                room,
                                nivel,
                                perfilesBase,
                                out descuentosRoom);

                            diagnostico.Add("Descuento de intersecciones ejecutado. Elementos descontados: " + descuentosRoom.ToString());
                            diagnostico.Add(ResumirPerfilesParaDiagnostico("Perfiles luego de intersecciones", perfilesDescontados));
                            diagnostico.Add("Prueba temporal luego de intersecciones: " + ProbarExtrusionTemporalParaDiagnostico(perfilesDescontados));

                            if (perfilesDescontados != null && perfilesDescontados.Count > 0)
                            {
                                perfilesFinales = perfilesDescontados;
                                totalDescuentos += descuentosRoom;
                            }
                        }
                        else
                        {
                            diagnostico.Add("Descuento de intersecciones: NO ejecutado por opción de ventana.");
                        }

                        // Descuenta solapes con suelos creados previamente en esta ejecución.
                        if (solidosSuelosCreadosEnEjecucion.Count > 0)
                        {
                            int solapesRoom = 0;
                            diagnostico.Add("Solapes: existen " + solidosSuelosCreadosEnEjecucion.Count.ToString() + " huellas previas para comparar.");

                            IList<CurveLoop> perfilesSinSolape = DescontarSolapesConSuelosPrevios(
                                nivel,
                                perfilesFinales,
                                solidosSuelosCreadosEnEjecucion,
                                out solapesRoom);

                            diagnostico.Add("Solapes detectados/descontados: " + solapesRoom.ToString());
                            diagnostico.Add(ResumirPerfilesParaDiagnostico("Perfiles luego de solapes", perfilesSinSolape));
                            diagnostico.Add("Prueba temporal luego de solapes: " + ProbarExtrusionTemporalParaDiagnostico(perfilesSinSolape));

                            if (perfilesSinSolape != null && perfilesSinSolape.Count > 0)
                            {
                                perfilesFinales = perfilesSinSolape;
                                totalSolapesEntreSuelos += solapesRoom;
                            }
                        }
                        else
                        {
                            diagnostico.Add("Solapes: no se ejecuta porque todavía no hay huellas previas.");
                        }

                        diagnostico.Add(ResumirPerfilesParaDiagnostico("PerfilesFinales antes de Floor.Create", perfilesFinales));
                        diagnostico.Add("Prueba temporal PerfilesFinales: " + ProbarExtrusionTemporalParaDiagnostico(perfilesFinales));

                        IList<CurveLoop> perfilesUsadosInferior = perfilesFinales;
                        IList<CurveLoop> perfilesUsadosSuperior = perfilesFinales;

                        // SUELO INFERIOR / SUELO ÚNICO:
                        // Revit controla el suelo desde su cara superior.
                        // Offset superior = Espesor del suelo inferior + Desfase.
                        // Así, la cara inferior queda en Nivel + Desfase.
                        string detalleCreacionInferior = "";

                        Floor sueloInferior = CrearSueloConOffsetSuperior(
                            doc,
                            perfilesFinales,
                            perfilesBase,
                            perfilesSinPuertas,
                            floorTypeInferior,
                            nivel,
                            offsetSuperiorInferior,
                            out perfilesUsadosInferior,
                            out detalleCreacionInferior);

                        diagnostico.Add("Crear suelo inferior/único:\r\n" + detalleCreacionInferior);

                        Floor sueloSuperior = null;

                        if (usarDosCapas)
                        {
                            // SUELO SUPERIOR:
                            // Se apila por encima del suelo inferior.
                            // Offset superior = Espesor inferior + Espesor superior + Desfase.
                            string detalleCreacionSuperior = "";

                            sueloSuperior = CrearSueloConOffsetSuperior(
                                doc,
                                perfilesFinales,
                                perfilesBase,
                                perfilesSinPuertas,
                                floorTypeSuperior,
                                nivel,
                                offsetSuperiorSuperior,
                                out perfilesUsadosSuperior,
                                out detalleCreacionSuperior);

                            diagnostico.Add("Crear suelo superior:\r\n" + detalleCreacionSuperior);
                        }

                        if (sueloInferior == null && (!usarDosCapas || sueloSuperior == null))
                        {
                            omitidos++;
                            reporte.Add("OMITIDO: " + ObtenerNombreRoom(room) + " no pudo crear el suelo.");
                            diagnostico.Add("RESULTADO: OMITIDO");
                            diagnostico.Add("MOTIVO: Floor.Create devolvió null en todos los intentos disponibles.");
                            continue;
                        }

                        roomsConAlMenosUnSuelo++;

                        // =========================================================
                        // LLENADO AUTOMÁTICO DE PARÁMETROS INTERNOS
                        // =========================================================

                        string nombreHabitacionFormatoOracion = ObtenerNombreHabitacionFormatoOracion(room);

                        if (sueloInferior != null)
                        {
                            LlenarParametrosSueloCreado(
                                sueloInferior,
                                nombreHabitacionFormatoOracion);
                        }

                        if (sueloSuperior != null)
                        {
                            LlenarParametrosSueloCreado(
                                sueloSuperior,
                                nombreHabitacionFormatoOracion);
                        }

                        string descripcionAcabadoSuelo = ObtenerDescripcionTipoSueloParaAcabado(
                            usarDosCapas && sueloSuperior != null ? floorTypeSuperior : floorTypeInferior);

                        LlenarAcabadoSueloRoom(
                            room,
                            descripcionAcabadoSuelo);

                        if (sueloInferior != null)
                        {
                            suelosCreados.Add(sueloInferior.Id);
                            suelosInferioresCreados++;
                            suelosCreadosTotal++;
                        }
                        else
                        {
                            errores++;
                        }

                        if (usarDosCapas)
                        {
                            if (sueloSuperior != null)
                            {
                                suelosCreados.Add(sueloSuperior.Id);
                                suelosSuperioresCreados++;
                                suelosCreadosTotal++;
                            }
                            else
                            {
                                errores++;
                            }
                        }

                        int murosUnidosRoom = 0;

                        if (murosAnfitrionesPuertasRoom != null &&
                            murosAnfitrionesPuertasRoom.Count > 0 &&
                            (sueloInferior != null || sueloSuperior != null))
                        {
                            // Se regenera para que Revit actualice la geometría de ambos suelos
                            // antes de intentar JoinGeometry.
                            doc.Regenerate();

                            if (sueloInferior != null)
                            {
                                murosUnidosRoom += UnirSueloConMurosAnfitrionesPuerta(
                                    doc,
                                    sueloInferior,
                                    murosAnfitrionesPuertasRoom);
                            }

                            if (sueloSuperior != null)
                            {
                                murosUnidosRoom += UnirSueloConMurosAnfitrionesPuerta(
                                    doc,
                                    sueloSuperior,
                                    murosAnfitrionesPuertasRoom);
                            }

                            totalMurosAnfitrionesUnidos += murosUnidosRoom;
                        }

                        IList<CurveLoop> perfilesParaHuella = perfilesUsadosSuperior;

                        if ((perfilesParaHuella == null || perfilesParaHuella.Count == 0) &&
                            perfilesUsadosInferior != null && perfilesUsadosInferior.Count > 0)
                        {
                            perfilesParaHuella = perfilesUsadosInferior;
                        }

                        Solid solidoNuevoSuelo = CrearSolidoTemporalDesdePerfiles(perfilesParaHuella);

                        if (solidoNuevoSuelo != null && solidoNuevoSuelo.Volume > 0)
                        {
                            solidosSuelosCreadosEnEjecucion.Add(solidoNuevoSuelo);
                        }

                        string estadoInferior = sueloInferior != null
                            ? (usarDosCapas ? "Inferior OK" : "Suelo OK")
                            : (usarDosCapas ? "Inferior NO" : "Suelo NO");

                        string estadoSuperior = usarDosCapas
                            ? (sueloSuperior != null ? "Superior OK" : "Superior NO")
                            : "1 capa";

                        if (murosUnidosRoom > 0)
                        {
                            reporte.Add(
                                "CREADO: " + ObtenerNombreRoom(room) +
                                " | " + estadoInferior +
                                " | " + estadoSuperior +
                                " | Muros unidos: " + murosUnidosRoom.ToString());
                        }
                        else
                        {
                            reporte.Add(
                                "CREADO: " + ObtenerNombreRoom(room) +
                                " | " + estadoInferior +
                                " | " + estadoSuperior);
                        }

                        diagnostico.Add("RESULTADO: CREADO");
                        diagnostico.Add("Estado: " + estadoInferior + " | " + estadoSuperior + " | Muros unidos: " + murosUnidosRoom.ToString());
                    }
                    catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
                    {
                        throw;
                    }
                    catch (Exception exRoom)
                    {
                        errores++;
                        reporte.Add("ERROR ROOM: " + exRoom.Message);
                        diagnostico.Add("RESULTADO: ERROR ROOM");
                        diagnostico.Add("ERROR: " + exRoom.GetType().Name + " | " + exRoom.Message);
                    }
                }

                if (tx.Commit() != TransactionStatus.Committed)
                    throw new InvalidOperationException("Revit no confirmó el lote de suelos desde Rooms.");
            }

            if (suelosCreados.Count > 0)
                UiDoc.Selection.SetElementIds(suelosCreados);

            diagnostico.Add("============================================================");
            diagnostico.Add("RESUMEN FINAL");
            diagnostico.Add("Rooms seleccionados: " + roomIds.Count.ToString());
            diagnostico.Add("Rooms con suelos creados: " + roomsConAlMenosUnSuelo.ToString());
            diagnostico.Add("Suelos creados total: " + suelosCreadosTotal.ToString());
            diagnostico.Add("Omitidos: " + omitidos.ToString());
            diagnostico.Add("Errores parciales: " + errores.ToString());
            diagnostico.Add("Puertas procesadas: " + totalPuertas.ToString());
            diagnostico.Add("Solapes entre Rooms descontados: " + totalSolapesEntreSuelos.ToString());
            diagnostico.Add("============================================================");

            string rutaReporteDiagnostico = GuardarReporteDiagnostico(doc, diagnostico);

            MostrarEnVentana(
                "PROCESO TERMINADO\r\n" +
                "----------------------------------------\r\n" +
                "Rooms seleccionados: " + roomIds.Count.ToString() + "\r\n" +
                "Modo de creación: " + (usarDosCapas ? "2 capas" : "1 capa") + "\r\n" +
                "Rooms con suelos creados: " + roomsConAlMenosUnSuelo.ToString() + "\r\n" +
                "Suelos creados total: " + suelosCreadosTotal.ToString() + "\r\n" +
                "Suelos inferiores creados: " + suelosInferioresCreados.ToString() + "\r\n" +
                "Suelos superiores creados: " + suelosSuperioresCreados.ToString() + "\r\n" +
                "Omitidos: " + omitidos.ToString() + "\r\n" +
                "Errores parciales: " + errores.ToString() + "\r\n" +
                "Altura definida por: " + (Form.UsarCotaBaseDesdeSuperficie ? "superficie picada" : "nivel y desfase") + "\r\n" +
                "Desfase aplicado: " + desfaseMetros.ToString("0.###") + " m\r\n" +
                "Profundidad quiebre puertas: " + profundidadQuiebrePuertasMetros.ToString("0.###") + " m\r\n" +
                "Puertas procesadas: " + totalPuertas.ToString() + "\r\n" +
                "Elementos descontados en planta: " + totalDescuentos.ToString() + "\r\n" +
                "Solapes entre Rooms descontados: " + totalSolapesEntreSuelos.ToString() + "\r\n" +
                "Uniones suelo-muro anfitrión: " + totalMurosAnfitrionesUnidos.ToString() + "\r\n\r\n" +
                string.Join("\r\n", reporte));
        }

        private Floor CrearSueloConOffsetSuperior(
            Document doc,
            IList<CurveLoop> perfilesFinales,
            IList<CurveLoop> perfilesBase,
            IList<CurveLoop> perfilesSinPuertas,
            FloorType floorType,
            Level nivel,
            double offsetSuperiorFeet,
            out IList<CurveLoop> perfilesUsadosParaCrear,
            out string detalleCreacion)
        {
            perfilesUsadosParaCrear = perfilesFinales;
            List<string> log = new List<string>();
            detalleCreacion = "";

            if (doc == null || floorType == null || nivel == null)
            {
                detalleCreacion = "Datos nulos: doc/tipo/nivel.";
                return null;
            }

            log.Add("Tipo: " + floorType.Name + " | Id: " + floorType.Id.Value.ToString());
            log.Add("OffsetSuperior(ft): " + offsetSuperiorFeet.ToString("0.#####", CultureInfo.InvariantCulture));

            // Orden de intentos:
            // 1. Perfil final normal.
            // 2. Perfil base.
            // 3. Perfil limpio sin puertas.
            // 4. Versiones reconstruidas como polilínea limpia.
            // Esto evita que un chinchón, microsegmento o curva problemática haga perder el Room completo.
            List<IList<CurveLoop>> intentos = new List<IList<CurveLoop>>();

            AgregarIntentoPerfiles(intentos, perfilesFinales);
            AgregarIntentoPerfiles(intentos, perfilesBase);
            AgregarIntentoPerfiles(intentos, perfilesSinPuertas);

            AgregarIntentoPerfiles(intentos, ReconstruirPerfilesComoPolilineasLimpias(perfilesFinales, nivel));
            AgregarIntentoPerfiles(intentos, ReconstruirPerfilesComoPolilineasLimpias(perfilesBase, nivel));
            AgregarIntentoPerfiles(intentos, ReconstruirPerfilesComoPolilineasLimpias(perfilesSinPuertas, nivel));

            int numeroIntento = 0;

            foreach (IList<CurveLoop> perfilesIntento in intentos)
            {
                numeroIntento++;

                if (perfilesIntento == null || perfilesIntento.Count == 0)
                {
                    log.Add("Intento " + numeroIntento.ToString() + ": omitido porque no tiene perfiles.");
                    continue;
                }

                log.Add("Intento " + numeroIntento.ToString() + ": " + ResumirPerfilesParaDiagnostico("perfil", perfilesIntento));
                log.Add("Intento " + numeroIntento.ToString() + " prueba temporal: " + ProbarExtrusionTemporalParaDiagnostico(perfilesIntento));

                using (SubTransaction intento = new SubTransaction(doc))
                {
                    try
                    {
                        intento.Start();
                        perfilesUsadosParaCrear = perfilesIntento;
                        Floor suelo = Floor.Create(
                            doc, perfilesIntento, floorType.Id, nivel.Id);

                        if (suelo == null)
                            throw new InvalidOperationException("Floor.Create devolvió null.");

                        Parameter offsetParam = suelo.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM);
                        if (offsetParam == null)
                            throw new InvalidOperationException("El suelo no tiene parámetro de desfase.");

                        if (!offsetParam.IsReadOnly)
                            offsetParam.Set(offsetSuperiorFeet);

                        // Set puede devolver false si el valor ya era correcto.
                        // Se verifica el resultado y no solo el retorno de Set.
                        doc.Regenerate();
                        Level nivelReal = doc.GetElement(suelo.LevelId) as Level;
                        if (nivelReal == null || !CotaSuperiorCoincide(
                            nivelReal.ProjectElevation + offsetParam.AsDouble(),
                            nivel.ProjectElevation + offsetSuperiorFeet,
                            0.001 / 0.3048))
                        {
                            throw new InvalidOperationException("El suelo no quedó a la cota superior solicitada.");
                        }

                        if (intento.Commit() != TransactionStatus.Committed)
                            throw new InvalidOperationException("Revit no confirmó el intento de creación.");

                        log.Add("Intento " + numeroIntento.ToString() + ": OK. Cota superior verificada.");
                        detalleCreacion = string.Join("\r\n", log);
                        return suelo;
                    }
                    catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
                    {
                        if (intento.GetStatus() == TransactionStatus.Started)
                            intento.RollBack();
                        throw;
                    }
                    catch (Exception ex)
                    {
                        if (intento.GetStatus() == TransactionStatus.Started)
                            intento.RollBack();
                        log.Add("Intento " + numeroIntento.ToString() + ": FALLÓ | " + ex.GetType().Name + " | " + ex.Message);
                    }
                }
            }

            perfilesUsadosParaCrear = perfilesFinales;
            log.Add("Resultado final: ningún intento de Floor.Create funcionó.");
            detalleCreacion = string.Join("\r\n", log);
            return null;
        }

        private static double CalcularOffsetSuperiorCapa(
            double desfaseBaseFeet,
            double espesorInferiorFeet,
            double espesorSuperiorFeet,
            bool esCapaSuperior)
        {
            if (!EsNumeroFinitoSuelo(desfaseBaseFeet) || !EsNumeroFinitoSuelo(espesorInferiorFeet) ||
                espesorInferiorFeet <= 0.0 ||
                (esCapaSuperior && (!EsNumeroFinitoSuelo(espesorSuperiorFeet) || espesorSuperiorFeet <= 0.0)))
            {
                throw new ArgumentException("Desfase o espesores de suelo no válidos.");
            }

            double resultado = desfaseBaseFeet + espesorInferiorFeet +
                (esCapaSuperior ? espesorSuperiorFeet : 0.0);
            if (!EsNumeroFinitoSuelo(resultado))
                throw new ArgumentException("La cota superior calculada no es finita.");
            return resultado;
        }

        private static bool CotaSuperiorCoincide(double zReal, double zEsperada, double tolerancia)
        {
            return EsNumeroFinitoSuelo(zReal) && EsNumeroFinitoSuelo(zEsperada) &&
                EsNumeroFinitoSuelo(tolerancia) && tolerancia > 0.0 &&
                Math.Abs(zReal - zEsperada) <= tolerancia;
        }

        private static bool EsNumeroFinitoSuelo(double valor)
        {
            return !double.IsNaN(valor) && !double.IsInfinity(valor);
        }

        private void AgregarIntentoPerfiles(
            List<IList<CurveLoop>> intentos,
            IList<CurveLoop> perfiles)
        {
            if (intentos == null || perfiles == null || perfiles.Count == 0)
                return;

            intentos.Add(perfiles);
        }

        // =========================================================
        // OBTENER BOUNDARY DEL ROOM
        // =========================================================

        private IList<CurveLoop> ObtenerPerfilesDesdeRoomSinPuertas(
            Document doc,
            Room room,
            Level nivel)
        {
            int puertasDummy = 0;
            List<ElementId> murosDummy = new List<ElementId>();

            return ObtenerPerfilesDesdeRoom(
                doc,
                room,
                nivel,
                false,
                0.0,
                out puertasDummy,
                out murosDummy);
        }

        private IList<CurveLoop> ObtenerPerfilesDesdeRoom(
            Document doc,
            Room room,
            Level nivel,
            bool incluirPuertas,
            double profundidadQuiebrePuertasFeet,
            out int puertasIncluidas,
            out List<ElementId> murosAnfitrionesPuertas)
        {
            puertasIncluidas = 0;
            murosAnfitrionesPuertas = new List<ElementId>();

            List<CurveLoop> perfiles = new List<CurveLoop>();

            if (doc == null || room == null || nivel == null)
                return perfiles;

            SpatialElementBoundaryOptions opciones = new SpatialElementBoundaryOptions();
            opciones.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish;

            IList<IList<BoundarySegment>> boundaries = room.GetBoundarySegments(opciones);

            if (boundaries == null || boundaries.Count == 0)
                return perfiles;

            double z = nivel.ProjectElevation;

            foreach (IList<BoundarySegment> boundary in boundaries)
            {
                if (boundary == null || boundary.Count == 0)
                    continue;

                List<CurvaBoundaryMYG> curvasBoundary = new List<CurvaBoundaryMYG>();

                foreach (BoundarySegment segmento in boundary)
                {
                    if (segmento == null)
                        continue;

                    Curve curvaOriginal = segmento.GetCurve();

                    if (curvaOriginal == null)
                        continue;

                    List<Curve> curvasProyectadas = ProyectarCurvaAElevacion(curvaOriginal, z);

                    foreach (Curve c in curvasProyectadas)
                    {
                        if (c == null)
                            continue;

                        if (c.Length < MetrosAPies(0.001))
                            continue;

                        curvasBoundary.Add(new CurvaBoundaryMYG()
                        {
                            Curva = c,
                            ElementoBoundaryId = segmento.ElementId
                        });
                    }
                }

                List<Curve> curvasOriginalesSinPuertas = curvasBoundary
                    .Select(x => x.Curva)
                    .Where(x => x != null && x.Length > MetrosAPies(0.001))
                    .ToList();

                if (curvasOriginalesSinPuertas.Count < 3)
                    continue;

                List<Curve> curvasFinales = curvasOriginalesSinPuertas;

                if (incluirPuertas)
                {
                    int puertasLoop = 0;

                    curvasFinales = IncluirVaciosDePuertasPorAnfitrion(
                        doc,
                        room,
                        nivel,
                        curvasBoundary,
                        profundidadQuiebrePuertasFeet,
                        out puertasLoop,
                        murosAnfitrionesPuertas);

                    puertasIncluidas += puertasLoop;

                    if (curvasFinales == null || curvasFinales.Count < 3)
                        curvasFinales = curvasOriginalesSinPuertas;
                }

                // Primero intenta conservar curvas originales/chinchones.
                CurveLoop loop = CrearCurveLoopSeguro(curvasFinales);

                // Si queda abierto, reconstruye como polilínea limpia.
                if (loop == null || loop.IsOpen())
                    loop = CrearCurveLoopPolilineaLimpiaDesdeCurvas(curvasFinales, z);

                // Si el perfil con puertas falló, usa el boundary original limpio sin puertas.
                if (loop == null || loop.IsOpen())
                    loop = CrearCurveLoopSeguro(curvasOriginalesSinPuertas);

                if (loop == null || loop.IsOpen())
                    loop = CrearCurveLoopPolilineaLimpiaDesdeCurvas(curvasOriginalesSinPuertas, z);

                if (loop != null && !loop.IsOpen())
                {
                    perfiles.Add(loop);
                }
            }

            return perfiles;
        }

        // =========================================================
        // INCLUIR PUERTAS / CHINCHÓN MANUAL
        // =========================================================
        // CRITERIO FINAL:
        // - No se buscan puertas globales por cercanía.
        // - Solo se procesan puertas insertadas en el muro que corresponde al tramo del boundary.
        // - El ancho del chinchón se obtiene de los SÓLIDOS reales de la puerta proyectados sobre el boundary.
        // - La profundidad del chinchón es EXACTAMENTE el valor escrito en la ventana.
        // - Si algo sale inválido, el tramo queda como boundary original para que el suelo no deje de crearse.

        private List<Curve> IncluirVaciosDePuertasPorAnfitrion(
            Document doc,
            Room room,
            Level nivel,
            List<CurvaBoundaryMYG> curvasBoundary,
            double profundidadQuiebrePuertasFeet,
            out int puertasIncluidas,
            List<ElementId> murosAnfitrionesPuertas)
        {
            puertasIncluidas = 0;

            List<Curve> resultado = new List<Curve>();

            if (doc == null || nivel == null || curvasBoundary == null || curvasBoundary.Count == 0)
                return resultado;

            HashSet<long> puertasYaUsadasEnLoop = new HashSet<long>();

            foreach (CurvaBoundaryMYG item in curvasBoundary)
            {
                if (item == null || item.Curva == null)
                    continue;

                Line lineaBoundary = item.Curva as Line;

                if (lineaBoundary == null)
                {
                    resultado.Add(item.Curva);
                    continue;
                }

                Wall muro = ObtenerMuroDelBoundaryOCercano(doc, item, lineaBoundary);

                if (muro == null)
                {
                    resultado.Add(item.Curva);
                    continue;
                }

                List<FamilyInstance> puertasDelMuro = ObtenerPuertasInsertadasEnMuro(doc, muro);

                if (puertasDelMuro == null || puertasDelMuro.Count == 0)
                {
                    resultado.Add(item.Curva);
                    continue;
                }

                List<VacioPuertaEnSegmento> vaciosValidos = new List<VacioPuertaEnSegmento>();

                foreach (FamilyInstance puerta in puertasDelMuro)
                {
                    if (puerta == null)
                        continue;

                    if (puertasYaUsadasEnLoop.Contains(puerta.Id.Value))
                        continue;

                    VacioPuertaEnSegmento vacio = ObtenerVacioPuertaChinchonSobreBoundary(
                        doc,
                        room,
                        puerta,
                        muro,
                        lineaBoundary,
                        nivel,
                        profundidadQuiebrePuertasFeet);

                    if (vacio == null)
                        continue;

                    AgregarElementIdUnico(murosAnfitrionesPuertas, muro.Id);

                    vaciosValidos.Add(vacio);
                    puertasYaUsadasEnLoop.Add(puerta.Id.Value);
                    puertasIncluidas++;
                }

                if (vaciosValidos.Count == 0)
                {
                    resultado.Add(item.Curva);
                    continue;
                }

                List<Curve> curvasConVacios = CrearLineaConVaciosDePuerta(
                    lineaBoundary,
                    vaciosValidos);

                if (curvasConVacios == null || curvasConVacios.Count == 0)
                {
                    resultado.Add(item.Curva);
                    continue;
                }

                foreach (Curve c in curvasConVacios)
                {
                    if (c == null)
                        continue;

                    if (c.Length < 0.0001)
                        continue;

                    resultado.Add(c);
                }
            }

            return resultado;
        }

        private VacioPuertaEnSegmento ObtenerVacioPuertaChinchonSobreBoundary(
            Document doc,
            Room room,
            FamilyInstance puerta,
            Wall muro,
            Line lineaBoundary,
            Level nivel,
            double profundidadQuiebrePuertasFeet)
        {
            if (doc == null || puerta == null || muro == null || lineaBoundary == null || nivel == null)
                return null;

            XYZ b0 = lineaBoundary.GetEndPoint(0);
            XYZ b1 = lineaBoundary.GetEndPoint(1);

            double longitudBoundary = DistanciaXY(b0, b1);

            if (longitudBoundary < MetrosAPies(0.10))
                return null;

            XYZ dirBoundary = DireccionXY(b0, b1);

            if (dirBoundary == null)
                return null;

            if (!PuertaEsCompatibleConSegmento(puerta, dirBoundary))
                return null;

            InfoPuertaBoundaryManualMYG info = ObtenerInfoPuertaSobreBoundaryManual(
                puerta,
                nivel,
                lineaBoundary);

            if (info == null)
                return null;

            double inicio = info.Inicio;
            double fin = info.Fin;

            double margenCruce = Math.Max(info.Ancho * 0.08, MetrosAPies(0.02));

            if (fin < -margenCruce)
                return null;

            if (inicio > longitudBoundary + margenCruce)
                return null;

            inicio = Math.Max(0.0, inicio);
            fin = Math.Min(longitudBoundary, fin);

            if (fin - inicio < MetrosAPies(0.05))
                return null;

            XYZ pCentroBoundary = b0 + dirBoundary.Multiply((inicio + fin) / 2.0);

            double toleranciaAsignacion = Math.Max(
                muro.Width + MetrosAPies(0.35),
                MetrosAPies(0.75));

            if (info.DistanciaPerpendicular > toleranciaAsignacion)
                return null;

            XYZ direccionSalida = ObtenerDireccionSalidaPerpendicularAlBoundary(
                room,
                nivel,
                lineaBoundary,
                pCentroBoundary,
                dirBoundary,
                info.CentroPuerta);

            if (direccionSalida == null)
                return null;

            double profundidadAutomatica = ObtenerProfundidadAutomaticaOriginal(
                muro,
                lineaBoundary,
                inicio,
                fin,
                dirBoundary);

            double profundidad = profundidadQuiebrePuertasFeet > 0.0001
                ? profundidadQuiebrePuertasFeet
                : profundidadAutomatica;

            if (profundidad <= 0.0001)
                return null;

            VacioPuertaEnSegmento vacio = new VacioPuertaEnSegmento();
            vacio.IdPuerta = puerta.Id;
            vacio.Inicio = inicio;
            vacio.Fin = fin;
            vacio.DireccionProyeccion = direccionSalida;
            vacio.Profundidad = profundidad;

            return vacio;
        }

        private double ObtenerProfundidadAutomaticaOriginal(
            Wall muro,
            Line lineaBoundary,
            double inicio,
            double fin,
            XYZ dirBoundary)
        {
            if (muro == null || lineaBoundary == null || dirBoundary == null)
                return 0.0;

            try
            {
                LocationCurve locMuro = muro.Location as LocationCurve;

                if (locMuro == null || locMuro.Curve == null)
                    return muro.Width;

                Line lineaMuro = locMuro.Curve as Line;

                if (lineaMuro == null)
                    return muro.Width;

                XYZ b0 = lineaBoundary.GetEndPoint(0);
                XYZ m0 = lineaMuro.GetEndPoint(0);
                XYZ m1 = lineaMuro.GetEndPoint(1);

                XYZ dirMuro = DireccionXY(m0, m1);

                if (dirMuro == null)
                    return muro.Width;

                double tMedio = (inicio + fin) / 2.0;
                XYZ puntoMedioBoundary = b0 + dirBoundary.Multiply(tMedio);

                double tMuro = 0.0;

                XYZ puntoEjeMuro = ProyectarPuntoSobreLineaXY(
                    puntoMedioBoundary,
                    m0,
                    dirMuro,
                    out tMuro);

                double distanciaBoundaryAEje = DistanciaXY(
                    puntoMedioBoundary,
                    puntoEjeMuro);

                return distanciaBoundaryAEje + (muro.Width / 2.0);
            }
            catch
            {
                return muro.Width;
            }
        }

        private InfoPuertaBoundaryManualMYG ObtenerInfoPuertaSobreBoundaryManual(
            FamilyInstance puerta,
            Level nivel,
            Line lineaBoundary)
        {
            if (puerta == null || nivel == null || lineaBoundary == null)
                return null;

            XYZ b0 = lineaBoundary.GetEndPoint(0);
            XYZ b1 = lineaBoundary.GetEndPoint(1);

            double longitudBoundary = DistanciaXY(b0, b1);

            if (longitudBoundary < 0.0001)
                return null;

            XYZ dirBoundary = DireccionXY(b0, b1);

            if (dirBoundary == null)
                return null;

            double minT = double.MaxValue;
            double maxT = double.MinValue;
            XYZ centroPuerta = ObtenerCentroPuertaEnNivel(puerta, nivel);

            bool obtuvoIntervaloSolido = ObtenerIntervaloPuertaDesdeSolidos(
                puerta,
                nivel,
                b0,
                dirBoundary,
                out minT,
                out maxT);

            if (!obtuvoIntervaloSolido)
            {
                obtuvoIntervaloSolido = ObtenerIntervaloPuertaDesdeBoundingBox(
                    puerta,
                    nivel,
                    b0,
                    dirBoundary,
                    out minT,
                    out maxT);
            }

            if (!obtuvoIntervaloSolido)
                return null;

            double ancho = Math.Abs(maxT - minT);

            // Si la familia devuelve sólidos raros o demasiado pequeños, no se crea chinchón falso.
            if (ancho < MetrosAPies(0.25))
                return null;

            if (ancho > MetrosAPies(3.50))
                return null;

            double centroT = (minT + maxT) / 2.0;

            if (centroPuerta == null)
                centroPuerta = b0 + dirBoundary.Multiply(centroT);

            XYZ puntoBoundary = b0 + dirBoundary.Multiply(centroT);

            double distanciaPerpendicular = DistanciaXY(
                centroPuerta,
                puntoBoundary);

            InfoPuertaBoundaryManualMYG info = new InfoPuertaBoundaryManualMYG();
            info.Inicio = minT;
            info.Fin = maxT;
            info.CentroT = centroT;
            info.Ancho = ancho;
            info.AnchoParametro = 0.0;
            info.AnchoBBox = ancho;
            info.CentroPuerta = centroPuerta;
            info.PuntoBoundary = puntoBoundary;
            info.DistanciaPerpendicular = distanciaPerpendicular;

            return info;
        }

        private bool ObtenerIntervaloPuertaDesdeSolidos(
            FamilyInstance puerta,
            Level nivel,
            XYZ origenBoundary,
            XYZ dirBoundary,
            out double minT,
            out double maxT)
        {
            minT = double.MaxValue;
            maxT = double.MinValue;

            if (puerta == null || nivel == null || origenBoundary == null || dirBoundary == null)
                return false;

            try
            {
                List<Solid> solidos = ObtenerSolidosElemento(puerta);

                if (solidos == null || solidos.Count == 0)
                    return false;

                int puntosValidos = 0;

                foreach (Solid s in solidos)
                {
                    if (s == null || s.Volume <= 0.0000001)
                        continue;

                    foreach (Edge edge in s.Edges)
                    {
                        if (edge == null)
                            continue;

                        IList<XYZ> puntos = edge.Tessellate();

                        if (puntos == null)
                            continue;

                        foreach (XYZ p in puntos)
                        {
                            if (p == null)
                                continue;

                            XYZ pp = new XYZ(p.X, p.Y, nivel.ProjectElevation);

                            double t = ProductoPuntoXY(pp - origenBoundary, dirBoundary);

                            if (t < minT)
                                minT = t;

                            if (t > maxT)
                                maxT = t;

                            puntosValidos++;
                        }
                    }
                }

                if (puntosValidos < 2)
                    return false;

                return maxT > minT;
            }
            catch
            {
                minT = double.MaxValue;
                maxT = double.MinValue;
                return false;
            }
        }

        private bool ObtenerIntervaloPuertaDesdeBoundingBox(
            FamilyInstance puerta,
            Level nivel,
            XYZ origenBoundary,
            XYZ dirBoundary,
            out double minT,
            out double maxT)
        {
            minT = double.MaxValue;
            maxT = double.MinValue;

            if (puerta == null || nivel == null || origenBoundary == null || dirBoundary == null)
                return false;

            try
            {
                BoundingBoxXYZ bb = puerta.get_BoundingBox(null);

                if (bb == null)
                    return false;

                XYZ[] puntos =
                {
                    new XYZ(bb.Min.X, bb.Min.Y, nivel.ProjectElevation),
                    new XYZ(bb.Min.X, bb.Max.Y, nivel.ProjectElevation),
                    new XYZ(bb.Max.X, bb.Min.Y, nivel.ProjectElevation),
                    new XYZ(bb.Max.X, bb.Max.Y, nivel.ProjectElevation)
                };

                foreach (XYZ p in puntos)
                {
                    double t = ProductoPuntoXY(p - origenBoundary, dirBoundary);

                    if (t < minT)
                        minT = t;

                    if (t > maxT)
                        maxT = t;
                }

                return maxT > minT;
            }
            catch
            {
                minT = double.MaxValue;
                maxT = double.MinValue;
                return false;
            }
        }

        private XYZ ObtenerDireccionSalidaPerpendicularAlBoundary(
            Room room,
            Level nivel,
            Line lineaBoundary,
            XYZ puntoBoundary,
            XYZ dirBoundary,
            XYZ centroPuerta)
        {
            if (lineaBoundary == null || puntoBoundary == null || dirBoundary == null)
                return null;

            XYZ normal1 = NormalizarXY(new XYZ(-dirBoundary.Y, dirBoundary.X, 0.0));

            if (normal1 == null)
                return null;

            XYZ normal2 = new XYZ(-normal1.X, -normal1.Y, 0.0);

            try
            {
                if (room != null && nivel != null)
                {
                    double prueba = MetrosAPies(0.08);

                    XYZ p1 = new XYZ(
                        puntoBoundary.X + normal1.X * prueba,
                        puntoBoundary.Y + normal1.Y * prueba,
                        nivel.ProjectElevation + MetrosAPies(0.10));

                    XYZ p2 = new XYZ(
                        puntoBoundary.X + normal2.X * prueba,
                        puntoBoundary.Y + normal2.Y * prueba,
                        nivel.ProjectElevation + MetrosAPies(0.10));

                    bool p1Dentro = false;
                    bool p2Dentro = false;

                    try { p1Dentro = room.IsPointInRoom(p1); } catch { p1Dentro = false; }
                    try { p2Dentro = room.IsPointInRoom(p2); } catch { p2Dentro = false; }

                    if (p1Dentro && !p2Dentro)
                        return normal2;

                    if (p2Dentro && !p1Dentro)
                        return normal1;
                }
            }
            catch
            {
            }

            if (centroPuerta != null)
            {
                XYZ haciaPuerta = DireccionXY(puntoBoundary, centroPuerta);

                if (haciaPuerta != null)
                {
                    double d1 = haciaPuerta.DotProduct(normal1);
                    double d2 = haciaPuerta.DotProduct(normal2);

                    return d1 >= d2 ? normal1 : normal2;
                }
            }

            return normal1;
        }

        private bool PuertaEsCompatibleConSegmento(
            FamilyInstance puerta,
            XYZ dirBoundary)
        {
            if (puerta == null || dirBoundary == null)
                return false;

            try
            {
                Wall muroHost = puerta.Host as Wall;

                if (muroHost == null)
                    return false;

                LocationCurve lc = muroHost.Location as LocationCurve;

                if (lc == null || lc.Curve == null)
                    return true;

                XYZ h0 = lc.Curve.GetEndPoint(0);
                XYZ h1 = lc.Curve.GetEndPoint(1);
                XYZ dirHost = DireccionXY(h0, h1);

                if (dirHost == null)
                    return true;

                double paralelo = Math.Abs(dirHost.DotProduct(dirBoundary));

                return paralelo >= 0.65;
            }
            catch
            {
                return false;
            }
        }

        private XYZ ObtenerCentroPuertaEnNivel(
            FamilyInstance puerta,
            Level nivel)
        {
            if (puerta == null || nivel == null)
                return null;

            try
            {
                LocationPoint lp = puerta.Location as LocationPoint;

                if (lp != null)
                {
                    return new XYZ(
                        lp.Point.X,
                        lp.Point.Y,
                        nivel.ProjectElevation);
                }
            }
            catch
            {
            }

            try
            {
                BoundingBoxXYZ bb = puerta.get_BoundingBox(null);

                if (bb != null)
                {
                    return new XYZ(
                        (bb.Min.X + bb.Max.X) / 2.0,
                        (bb.Min.Y + bb.Max.Y) / 2.0,
                        nivel.ProjectElevation);
                }
            }
            catch
            {
            }

            return null;
        }

        // =========================================================
        // DESCONTAR INTERSECCIONES EN PLANTA
        // =========================================================

        private IList<CurveLoop> DescontarInterseccionesEnPlanta(
            Document doc,
            Room room,
            Level nivel,
            IList<CurveLoop> perfilesBase,
            out int elementosDescontados)
        {
            elementosDescontados = 0;

            if (doc == null || room == null || nivel == null)
                return perfilesBase;

            if (perfilesBase == null || perfilesBase.Count == 0)
                return perfilesBase;

            try
            {
                Solid solidoBase = CrearSolidoTemporalDesdePerfiles(perfilesBase);

                if (solidoBase == null || solidoBase.Volume <= 0)
                    return perfilesBase;

                Outline outline = ObtenerOutlineDesdePerfiles(perfilesBase, MetrosAPies(0.50));

                if (outline == null)
                    return perfilesBase;

                BoundingBoxIntersectsFilter filtroBBox =
                    new BoundingBoxIntersectsFilter(outline);

                List<Element> candidatos = new FilteredElementCollector(doc)
                    .WherePasses(filtroBBox)
                    .WhereElementIsNotElementType()
                    .Where(x => EsElementoDescontable(x))
                    .ToList();

                Solid resultado = solidoBase;

                foreach (Element candidato in candidatos)
                {
                    if (candidato == null)
                        continue;

                    if (candidato.Id.Value == room.Id.Value)
                        continue;

                    List<Solid> solidos = ObtenerSolidosElemento(candidato);

                    if (solidos.Count == 0)
                        continue;

                    bool descontoEsteElemento = false;

                    foreach (Solid s in solidos)
                    {
                        if (s == null || s.Volume <= 0)
                            continue;

                        try
                        {
                            Solid interseccion = BooleanOperationsUtils.ExecuteBooleanOperation(
                                resultado,
                                s,
                                BooleanOperationsType.Intersect);

                            if (interseccion == null || interseccion.Volume <= 0.0000001)
                                continue;

                            Solid nuevo = BooleanOperationsUtils.ExecuteBooleanOperation(
                                resultado,
                                s,
                                BooleanOperationsType.Difference);

                            if (nuevo != null && nuevo.Volume > 0)
                            {
                                resultado = nuevo;
                                descontoEsteElemento = true;
                            }
                        }
                        catch
                        {
                        }
                    }

                    if (descontoEsteElemento)
                        elementosDescontados++;
                }

                IList<CurveLoop> perfilesExtraidos = ExtraerPerfilesSuperioresDesdeSolido(
                    resultado,
                    nivel);

                if (perfilesExtraidos != null && perfilesExtraidos.Count > 0)
                    return perfilesExtraidos;
            }
            catch
            {
            }

            return perfilesBase;
        }

        private bool EsElementoDescontable(Element e)
        {
            if (e == null || e.Category == null)
                return false;

            BuiltInCategory[] categorias =
            {
                BuiltInCategory.OST_Walls,
                BuiltInCategory.OST_Columns,
                BuiltInCategory.OST_StructuralColumns,
                BuiltInCategory.OST_StructuralFraming,
                BuiltInCategory.OST_GenericModel,
                BuiltInCategory.OST_CurtainWallPanels
            };

            long catId = e.Category.Id.Value;

            foreach (BuiltInCategory bic in categorias)
            {
                ElementId idCat = new ElementId(bic);

                if (catId == idCat.Value)
                    return true;
            }

            return false;
        }

        private Outline ObtenerOutlineDesdePerfiles(
            IList<CurveLoop> perfiles,
            double margen)
        {
            if (perfiles == null || perfiles.Count == 0)
                return null;

            bool iniciado = false;

            double minX = 0;
            double minY = 0;
            double minZ = 0;
            double maxX = 0;
            double maxY = 0;
            double maxZ = 0;

            foreach (CurveLoop loop in perfiles)
            {
                if (loop == null)
                    continue;

                foreach (Curve c in loop)
                {
                    if (c == null)
                        continue;

                    XYZ p0 = c.GetEndPoint(0);
                    XYZ p1 = c.GetEndPoint(1);

                    XYZ[] puntos = { p0, p1 };

                    foreach (XYZ p in puntos)
                    {
                        if (p == null)
                            continue;

                        if (!iniciado)
                        {
                            minX = maxX = p.X;
                            minY = maxY = p.Y;
                            minZ = maxZ = p.Z;
                            iniciado = true;
                        }
                        else
                        {
                            minX = Math.Min(minX, p.X);
                            minY = Math.Min(minY, p.Y);
                            minZ = Math.Min(minZ, p.Z);

                            maxX = Math.Max(maxX, p.X);
                            maxY = Math.Max(maxY, p.Y);
                            maxZ = Math.Max(maxZ, p.Z);
                        }
                    }
                }
            }

            if (!iniciado)
                return null;

            XYZ min = new XYZ(
                minX - margen,
                minY - margen,
                minZ - margen);

            XYZ max = new XYZ(
                maxX + margen,
                maxY + margen,
                maxZ + MetrosAPies(4.00));

            return new Outline(min, max);
        }

        private IList<CurveLoop> DescontarSolapesConSuelosPrevios(
            Level nivel,
            IList<CurveLoop> perfilesActuales,
            List<Solid> solidosSuelosPrevios,
            out int solapesDescontados)
        {
            solapesDescontados = 0;

            if (nivel == null)
                return perfilesActuales;

            if (perfilesActuales == null || perfilesActuales.Count == 0)
                return perfilesActuales;

            if (solidosSuelosPrevios == null || solidosSuelosPrevios.Count == 0)
                return perfilesActuales;

            try
            {
                Solid solidoActual = CrearSolidoTemporalDesdePerfiles(perfilesActuales);

                if (solidoActual == null || solidoActual.Volume <= 0)
                    return perfilesActuales;

                Solid resultado = solidoActual;

                foreach (Solid solidoPrevio in solidosSuelosPrevios)
                {
                    if (solidoPrevio == null || solidoPrevio.Volume <= 0)
                        continue;

                    try
                    {
                        Solid interseccion = BooleanOperationsUtils.ExecuteBooleanOperation(
                            resultado,
                            solidoPrevio,
                            BooleanOperationsType.Intersect);

                        if (interseccion == null || interseccion.Volume <= 0.0000001)
                            continue;

                        Solid nuevo = BooleanOperationsUtils.ExecuteBooleanOperation(
                            resultado,
                            solidoPrevio,
                            BooleanOperationsType.Difference);

                        if (nuevo != null && nuevo.Volume > 0)
                        {
                            resultado = nuevo;
                            solapesDescontados++;
                        }
                    }
                    catch
                    {
                    }
                }

                if (solapesDescontados == 0)
                    return perfilesActuales;

                IList<CurveLoop> perfilesExtraidos = ExtraerPerfilesSuperioresDesdeSolido(
                    resultado,
                    nivel);

                if (perfilesExtraidos != null && perfilesExtraidos.Count > 0)
                    return perfilesExtraidos;
            }
            catch
            {
            }

            return perfilesActuales;
        }

        private Solid CrearSolidoTemporalDesdePerfiles(
            IList<CurveLoop> perfiles)
        {
            if (perfiles == null || perfiles.Count == 0)
                return null;

            try
            {
                double alturaSolido = MetrosAPies(0.20);

                Solid solido = GeometryCreationUtilities.CreateExtrusionGeometry(
                    perfiles,
                    XYZ.BasisZ,
                    alturaSolido);

                if (solido != null && solido.Volume > 0)
                    return solido;
            }
            catch
            {
            }

            return null;
        }

        private IList<CurveLoop> ExtraerPerfilesSuperioresDesdeSolido(
            Solid solido,
            Level nivel)
        {
            List<CurveLoop> perfiles = new List<CurveLoop>();

            if (solido == null || solido.Volume <= 0 || nivel == null)
                return perfiles;

            List<PlanarFace> carasSuperiores = new List<PlanarFace>();

            double zMax = double.MinValue;

            foreach (Face f in solido.Faces)
            {
                PlanarFace pf = f as PlanarFace;

                if (pf == null)
                    continue;

                XYZ normal = pf.FaceNormal;

                if (normal == null)
                    continue;

                if (normal.Z < 0.95)
                    continue;

                if (pf.Area <= 0.0001)
                    continue;

                double z = pf.Origin.Z;

                if (z > zMax)
                    zMax = z;

                carasSuperiores.Add(pf);
            }

            if (carasSuperiores.Count == 0)
                return perfiles;

            double tolZ = MetrosAPies(0.01);

            foreach (PlanarFace pf in carasSuperiores)
            {
                if (Math.Abs(pf.Origin.Z - zMax) > tolZ)
                    continue;

                IList<CurveLoop> loopsCara = pf.GetEdgesAsCurveLoops();

                if (loopsCara == null)
                    continue;

                foreach (CurveLoop loopCara in loopsCara)
                {
                    CurveLoop loopProyectado = ProyectarCurveLoopAElevacion(
                        loopCara,
                        nivel.ProjectElevation);

                    if (loopProyectado != null && !loopProyectado.IsOpen())
                        perfiles.Add(loopProyectado);
                }
            }

            return perfiles;
        }

        // =========================================================
        // MUROS Y PUERTAS
        // =========================================================

        private int UnirSueloConMurosAnfitrionesPuerta(
            Document doc,
            Floor suelo,
            List<ElementId> murosAnfitrionesPuertas)
        {
            int murosUnidos = 0;

            if (doc == null || suelo == null)
                return murosUnidos;

            if (murosAnfitrionesPuertas == null || murosAnfitrionesPuertas.Count == 0)
                return murosUnidos;

            HashSet<long> murosProcesados = new HashSet<long>();

            foreach (ElementId idMuro in murosAnfitrionesPuertas)
            {
                if (idMuro == null || idMuro == ElementId.InvalidElementId)
                    continue;

                if (murosProcesados.Contains(idMuro.Value))
                    continue;

                murosProcesados.Add(idMuro.Value);

                Wall muro = doc.GetElement(idMuro) as Wall;

                if (muro == null)
                    continue;

                try
                {
                    bool yaEstanUnidos = false;

                    try
                    {
                        yaEstanUnidos = JoinGeometryUtils.AreElementsJoined(
                            doc,
                            suelo,
                            muro);
                    }
                    catch
                    {
                        yaEstanUnidos = false;
                    }

                    if (!yaEstanUnidos)
                    {
                        JoinGeometryUtils.JoinGeometry(
                            doc,
                            suelo,
                            muro);

                        murosUnidos++;
                    }

                    // Forzar orden de corte:
                    // el SUELO debe ser el elemento cortante del MURO.
                    try
                    {
                        bool sueloCortaMuro = JoinGeometryUtils.IsCuttingElementInJoin(
                            doc,
                            suelo,
                            muro);

                        if (!sueloCortaMuro)
                        {
                            JoinGeometryUtils.SwitchJoinOrder(
                                doc,
                                suelo,
                                muro);
                        }
                    }
                    catch
                    {
                        // Si el orden no puede consultarse o cambiarse,
                        // se deja la unión creada para no detener el proceso.
                    }
                }
                catch
                {
                    // Si algún muro no permite unirse, se omite
                    // y se continúa con los demás.
                }
            }

            return murosUnidos;
        }

        private Wall ObtenerMuroDelBoundaryOCercano(
            Document doc,
            CurvaBoundaryMYG item,
            Line lineaBoundary)
        {
            if (doc == null || lineaBoundary == null)
                return null;

            Wall muro = null;

            if (item != null &&
                item.ElementoBoundaryId != null &&
                item.ElementoBoundaryId != ElementId.InvalidElementId)
            {
                muro = doc.GetElement(item.ElementoBoundaryId) as Wall;

                if (muro != null)
                    return muro;
            }

            try
            {
                XYZ b0 = lineaBoundary.GetEndPoint(0);
                XYZ b1 = lineaBoundary.GetEndPoint(1);

                XYZ dirBoundary = DireccionXY(b0, b1);

                if (dirBoundary == null)
                    return null;

                XYZ medioBoundary = new XYZ(
                    (b0.X + b1.X) / 2.0,
                    (b0.Y + b1.Y) / 2.0,
                    (b0.Z + b1.Z) / 2.0);

                double mejorDistancia = double.MaxValue;
                Wall mejorMuro = null;

                List<Wall> muros = new FilteredElementCollector(doc)
                    .OfClass(typeof(Wall))
                    .WhereElementIsNotElementType()
                    .Cast<Wall>()
                    .ToList();

                foreach (Wall w in muros)
                {
                    LocationCurve lc = w.Location as LocationCurve;

                    if (lc == null)
                        continue;

                    Line lineaMuro = lc.Curve as Line;

                    if (lineaMuro == null)
                        continue;

                    XYZ m0 = lineaMuro.GetEndPoint(0);
                    XYZ m1 = lineaMuro.GetEndPoint(1);

                    XYZ dirMuro = DireccionXY(m0, m1);

                    if (dirMuro == null)
                        continue;

                    double paralelo = Math.Abs(dirBoundary.DotProduct(dirMuro));

                    if (paralelo < 0.90)
                        continue;

                    double tSobreMuro = 0.0;

                    XYZ puntoEnMuro = ProyectarPuntoSobreLineaXY(
                        medioBoundary,
                        m0,
                        dirMuro,
                        out tSobreMuro);

                    double distancia = DistanciaXY(medioBoundary, puntoEnMuro);

                    double tolerancia = Math.Max(
                        w.Width + MetrosAPies(0.20),
                        MetrosAPies(0.50));

                    if (distancia > tolerancia)
                        continue;

                    if (distancia < mejorDistancia)
                    {
                        mejorDistancia = distancia;
                        mejorMuro = w;
                    }
                }

                return mejorMuro;
            }
            catch
            {
                return null;
            }
        }

        private List<FamilyInstance> ObtenerPuertasInsertadasEnMuro(
            Document doc,
            Wall muro)
        {
            List<FamilyInstance> puertas = new List<FamilyInstance>();

            if (doc == null || muro == null)
                return puertas;

            try
            {
                ICollection<ElementId> inserts = muro.FindInserts(
                    true,
                    false,
                    false,
                    false);

                foreach (ElementId id in inserts)
                {
                    FamilyInstance fi = doc.GetElement(id) as FamilyInstance;

                    if (fi == null)
                        continue;

                    if (fi.Category == null)
                        continue;

                    if (fi.Category.Id.Value != new ElementId(BuiltInCategory.OST_Doors).Value)
                        continue;

                    puertas.Add(fi);
                }
            }
            catch
            {
            }

            if (puertas.Count > 0)
                return puertas;

            try
            {
                puertas = new FilteredElementCollector(doc)
                    .OfCategory(BuiltInCategory.OST_Doors)
                    .WhereElementIsNotElementType()
                    .OfType<FamilyInstance>()
                    .Where(x => x.Host != null && x.Host.Id.Value == muro.Id.Value)
                    .ToList();
            }
            catch
            {
            }

            return puertas;
        }

        private double ObtenerAnchoPuerta(FamilyInstance puerta)
        {
            if (puerta == null)
                return 0.0;

            try
            {
                Parameter p = null;

                if (puerta.Symbol != null)
                    p = puerta.Symbol.get_Parameter(BuiltInParameter.FAMILY_WIDTH_PARAM);

                if (p == null)
                    p = puerta.get_Parameter(BuiltInParameter.FAMILY_WIDTH_PARAM);

                if (p != null && p.StorageType == StorageType.Double)
                {
                    double valor = p.AsDouble();

                    if (valor > 0.0001)
                        return valor;
                }
            }
            catch
            {
            }

            try
            {
                string[] nombres =
                {
                    "Ancho",
                    "Width",
                    "ANCHO",
                    "WIDTH",
                    "Anchura",
                    "Rough Width",
                    "Ancho de hueco"
                };

                foreach (string nombre in nombres)
                {
                    Parameter pInstancia = puerta.LookupParameter(nombre);

                    if (pInstancia != null && pInstancia.StorageType == StorageType.Double)
                    {
                        double valor = pInstancia.AsDouble();

                        if (valor > 0.0001)
                            return valor;
                    }

                    if (puerta.Symbol != null)
                    {
                        Parameter pTipo = puerta.Symbol.LookupParameter(nombre);

                        if (pTipo != null && pTipo.StorageType == StorageType.Double)
                        {
                            double valor = pTipo.AsDouble();

                            if (valor > 0.0001)
                                return valor;
                        }
                    }
                }
            }
            catch
            {
            }

            return MetrosAPies(0.90);
        }

        // =========================================================
        // SOLIDOS
        // =========================================================

        private List<Solid> ObtenerSolidosElemento(Element elemento)
        {
            List<Solid> solidos = new List<Solid>();

            if (elemento == null)
                return solidos;

            try
            {
                Options opt = new Options();
                opt.ComputeReferences = false;
                opt.IncludeNonVisibleObjects = false;
                opt.DetailLevel = ViewDetailLevel.Fine;

                GeometryElement geo = elemento.get_Geometry(opt);

                if (geo == null)
                    return solidos;

                ExtraerSolidosDeGeometryElement(geo, solidos);
            }
            catch
            {
            }

            return solidos;
        }

        private void ExtraerSolidosDeGeometryElement(
            GeometryElement geo,
            List<Solid> solidos)
        {
            if (geo == null || solidos == null)
                return;

            foreach (GeometryObject obj in geo)
            {
                Solid s = obj as Solid;

                if (s != null && s.Volume > 0)
                {
                    solidos.Add(s);
                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    GeometryElement geoInst = gi.GetInstanceGeometry();

                    if (geoInst != null)
                        ExtraerSolidosDeGeometryElement(geoInst, solidos);
                }
            }
        }

        // =========================================================
        // CURVELOOP
        // =========================================================

        private CurveLoop CrearCurveLoopSeguro(List<Curve> curvas)
        {
            if (curvas == null || curvas.Count < 3)
                return null;

            CurveLoop loop = new CurveLoop();

            try
            {
                foreach (Curve c in curvas)
                {
                    if (c == null)
                        continue;

                    if (c.Length < MetrosAPies(0.001))
                        continue;

                    loop.Append(c);
                }

                if (loop.IsOpen())
                    return CrearCurveLoopComoLineas(curvas);

                return loop;
            }
            catch
            {
                return CrearCurveLoopComoLineas(curvas);
            }
        }

        private CurveLoop CrearCurveLoopComoLineas(List<Curve> curvas)
        {
            if (curvas == null || curvas.Count < 3)
                return null;

            return CrearCurveLoopPolilineaLimpiaDesdeCurvas(
                curvas,
                curvas[0].GetEndPoint(0).Z);
        }

        private CurveLoop CrearCurveLoopPolilineaLimpiaDesdeCurvas(
            IList<Curve> curvas,
            double z)
        {
            if (curvas == null || curvas.Count < 3)
                return null;

            List<XYZ> puntos = ObtenerPuntosSecuencialesDesdeCurvas(curvas, z);

            return CrearCurveLoopDesdePuntosLimpios(puntos);
        }

        private IList<CurveLoop> ReconstruirPerfilesComoPolilineasLimpias(
            IList<CurveLoop> perfiles,
            Level nivel)
        {
            List<CurveLoop> resultado = new List<CurveLoop>();

            if (perfiles == null || perfiles.Count == 0 || nivel == null)
                return resultado;

            foreach (CurveLoop perfil in perfiles)
            {
                if (perfil == null)
                    continue;

                List<Curve> curvas = new List<Curve>();

                try
                {
                    foreach (Curve c in perfil)
                    {
                        if (c != null)
                            curvas.Add(c);
                    }
                }
                catch
                {
                    continue;
                }

                CurveLoop limpio = CrearCurveLoopPolilineaLimpiaDesdeCurvas(
                    curvas,
                    nivel.ProjectElevation);

                if (limpio != null && !limpio.IsOpen())
                    resultado.Add(limpio);
            }

            return resultado;
        }

        private List<XYZ> ObtenerPuntosSecuencialesDesdeCurvas(
            IList<Curve> curvas,
            double z)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (curvas == null)
                return puntos;

            double tol = MetrosAPies(0.002);

            foreach (Curve c in curvas)
            {
                if (c == null)
                    continue;

                IList<XYZ> tess = null;

                try
                {
                    tess = c.Tessellate();
                }
                catch
                {
                    tess = null;
                }

                if (tess == null || tess.Count < 2)
                {
                    try
                    {
                        tess = new List<XYZ>()
                        {
                            c.GetEndPoint(0),
                            c.GetEndPoint(1)
                        };
                    }
                    catch
                    {
                        continue;
                    }
                }

                List<XYZ> ptsCurva = tess
                    .Where(p => p != null)
                    .Select(p => new XYZ(p.X, p.Y, z))
                    .ToList();

                if (ptsCurva.Count < 2)
                    continue;

                // Si la curva viene invertida respecto al último punto, se invierte.
                if (puntos.Count > 0)
                {
                    XYZ ultimo = puntos[puntos.Count - 1];

                    double dInicio = DistanciaXY(ultimo, ptsCurva[0]);
                    double dFin = DistanciaXY(ultimo, ptsCurva[ptsCurva.Count - 1]);

                    if (dFin < dInicio)
                        ptsCurva.Reverse();

                    if (DistanciaXY(ultimo, ptsCurva[0]) <= tol)
                    {
                        ptsCurva[0] = ultimo;
                    }
                }

                foreach (XYZ p in ptsCurva)
                {
                    AgregarPuntoLimpio(puntos, p, tol);
                }
            }

            return LimpiarPuntosPoligono(puntos, z);
        }

        private void AgregarPuntoLimpio(
            List<XYZ> puntos,
            XYZ punto,
            double tolerancia)
        {
            if (puntos == null || punto == null)
                return;

            if (puntos.Count == 0)
            {
                puntos.Add(punto);
                return;
            }

            XYZ ultimo = puntos[puntos.Count - 1];

            if (DistanciaXY(ultimo, punto) <= tolerancia)
                return;

            puntos.Add(punto);
        }

        private List<XYZ> LimpiarPuntosPoligono(
            List<XYZ> puntos,
            double z)
        {
            List<XYZ> limpio = new List<XYZ>();

            if (puntos == null || puntos.Count == 0)
                return limpio;

            double tolCierre = MetrosAPies(0.005);
            double tolCorto = MetrosAPies(0.002);
            double tolColinear = MetrosAPies(0.001);

            foreach (XYZ p in puntos)
            {
                if (p == null)
                    continue;

                XYZ pp = new XYZ(p.X, p.Y, z);

                if (limpio.Count == 0 || DistanciaXY(limpio[limpio.Count - 1], pp) > tolCorto)
                    limpio.Add(pp);
            }

            if (limpio.Count < 3)
                return limpio;

            if (DistanciaXY(limpio[0], limpio[limpio.Count - 1]) <= tolCierre)
            {
                limpio[limpio.Count - 1] = limpio[0];
            }
            else
            {
                limpio.Add(limpio[0]);
            }

            bool cambio = true;

            while (cambio && limpio.Count > 4)
            {
                cambio = false;

                for (int i = 1; i < limpio.Count - 1; i++)
                {
                    XYZ a = limpio[i - 1];
                    XYZ b = limpio[i];
                    XYZ c = limpio[i + 1];

                    if (DistanciaXY(a, b) < tolCorto || DistanciaXY(b, c) < tolCorto)
                    {
                        limpio.RemoveAt(i);
                        cambio = true;
                        break;
                    }

                    if (PuntoIntermedioColinearXY(a, b, c, tolColinear))
                    {
                        limpio.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }

                if (limpio.Count > 2 && DistanciaXY(limpio[0], limpio[limpio.Count - 1]) > tolCierre)
                    limpio.Add(limpio[0]);
            }

            if (limpio.Count > 2)
                limpio[limpio.Count - 1] = limpio[0];

            return limpio;
        }

        private bool PuntoIntermedioColinearXY(
            XYZ a,
            XYZ b,
            XYZ c,
            double tolerancia)
        {
            if (a == null || b == null || c == null)
                return false;

            XYZ ab = new XYZ(b.X - a.X, b.Y - a.Y, 0.0);
            XYZ ac = new XYZ(c.X - a.X, c.Y - a.Y, 0.0);

            double area2 = Math.Abs(ab.X * ac.Y - ab.Y * ac.X);
            double baseLen = Math.Sqrt(ac.X * ac.X + ac.Y * ac.Y);

            if (baseLen < 0.0000001)
                return true;

            double distancia = area2 / baseLen;

            return distancia <= tolerancia;
        }

        private CurveLoop CrearCurveLoopDesdePuntosLimpios(
            List<XYZ> puntos)
        {
            if (puntos == null || puntos.Count < 4)
                return null;

            try
            {
                CurveLoop loop = new CurveLoop();

                for (int i = 0; i < puntos.Count - 1; i++)
                {
                    XYZ p0 = puntos[i];
                    XYZ p1 = puntos[i + 1];

                    if (p0 == null || p1 == null)
                        continue;

                    if (DistanciaXY(p0, p1) < MetrosAPies(0.001))
                        continue;

                    loop.Append(Line.CreateBound(p0, p1));
                }

                if (loop.IsOpen())
                    return null;

                return loop;
            }
            catch
            {
                return null;
            }
        }

        private CurveLoop ProyectarCurveLoopAElevacion(
            CurveLoop loop,
            double z)
        {
            if (loop == null)
                return null;

            CurveLoop nuevo = new CurveLoop();

            try
            {
                foreach (Curve c in loop)
                {
                    if (c == null)
                        continue;

                    List<Curve> proyectadas = ProyectarCurvaAElevacion(c, z);

                    foreach (Curve cp in proyectadas)
                    {
                        if (cp == null)
                            continue;

                        if (cp.Length < 0.0001)
                            continue;

                        nuevo.Append(cp);
                    }
                }

                return nuevo;
            }
            catch
            {
                return null;
            }
        }


        private List<Curve> CrearLineaConVaciosDePuerta(
            Line lineaBoundary,
            List<VacioPuertaEnSegmento> vacios)
        {
            List<Curve> resultado = new List<Curve>();

            if (lineaBoundary == null)
                return resultado;

            if (vacios == null || vacios.Count == 0)
            {
                resultado.Add(lineaBoundary);
                return resultado;
            }

            XYZ p0 = lineaBoundary.GetEndPoint(0);
            XYZ p1 = lineaBoundary.GetEndPoint(1);

            double longitud = DistanciaXY(p0, p1);

            if (longitud < 0.0001)
                return resultado;

            XYZ dir = DireccionXY(p0, p1);

            if (dir == null)
                return resultado;

            List<VacioPuertaEnSegmento> vaciosOrdenados = vacios
                .OrderBy(x => x.Inicio)
                .ToList();

            vaciosOrdenados = UnirVaciosSolapados(vaciosOrdenados);

            double posicionActual = 0.0;
            XYZ puntoActual = p0;

            foreach (VacioPuertaEnSegmento vacio in vaciosOrdenados)
            {
                double inicio = Math.Max(0.0, vacio.Inicio);
                double fin = Math.Min(longitud, vacio.Fin);

                if (fin <= posicionActual + 0.0001)
                    continue;

                XYZ pInicio = p0 + dir.Multiply(inicio);
                XYZ pFin = p0 + dir.Multiply(fin);

                if (DistanciaXY(puntoActual, pInicio) > 0.0001)
                    resultado.Add(Line.CreateBound(puntoActual, pInicio));

                XYZ pInicioProyectado = pInicio + vacio.DireccionProyeccion.Multiply(vacio.Profundidad);
                XYZ pFinProyectado = pFin + vacio.DireccionProyeccion.Multiply(vacio.Profundidad);

                if (DistanciaXY(pInicio, pInicioProyectado) > 0.0001)
                    resultado.Add(Line.CreateBound(pInicio, pInicioProyectado));

                if (DistanciaXY(pInicioProyectado, pFinProyectado) > 0.0001)
                    resultado.Add(Line.CreateBound(pInicioProyectado, pFinProyectado));

                if (DistanciaXY(pFinProyectado, pFin) > 0.0001)
                    resultado.Add(Line.CreateBound(pFinProyectado, pFin));

                puntoActual = pFin;
                posicionActual = fin;
            }

            if (DistanciaXY(puntoActual, p1) > 0.0001)
                resultado.Add(Line.CreateBound(puntoActual, p1));

            return resultado;
        }

        private List<VacioPuertaEnSegmento> UnirVaciosSolapados(
            List<VacioPuertaEnSegmento> vacios)
        {
            List<VacioPuertaEnSegmento> resultado = new List<VacioPuertaEnSegmento>();

            if (vacios == null || vacios.Count == 0)
                return resultado;

            List<VacioPuertaEnSegmento> ordenados = vacios
                .OrderBy(x => x.Inicio)
                .ToList();

            VacioPuertaEnSegmento actual = ordenados[0];

            for (int i = 1; i < ordenados.Count; i++)
            {
                VacioPuertaEnSegmento v = ordenados[i];

                if (v.Inicio <= actual.Fin + MetrosAPies(0.01))
                {
                    actual.Fin = Math.Max(actual.Fin, v.Fin);

                    if (v.Profundidad > actual.Profundidad)
                        actual.Profundidad = v.Profundidad;
                }
                else
                {
                    resultado.Add(actual);
                    actual = v;
                }
            }

            resultado.Add(actual);

            return resultado;
        }

        // =========================================================
        // PROYECTAR CURVAS AL NIVEL
        // =========================================================

        private List<Curve> ProyectarCurvaAElevacion(Curve curva, double z)
        {
            List<Curve> resultado = new List<Curve>();

            Line linea = curva as Line;

            if (linea != null)
            {
                XYZ p0 = ProyectarPuntoAElevacion(linea.GetEndPoint(0), z);
                XYZ p1 = ProyectarPuntoAElevacion(linea.GetEndPoint(1), z);

                if (DistanciaXY(p0, p1) > 0.0001)
                    resultado.Add(Line.CreateBound(p0, p1));

                return resultado;
            }

            Arc arco = curva as Arc;

            if (arco != null)
            {
                XYZ p0 = ProyectarPuntoAElevacion(arco.GetEndPoint(0), z);
                XYZ p1 = ProyectarPuntoAElevacion(arco.GetEndPoint(1), z);

                double parametroMedio = (arco.GetEndParameter(0) + arco.GetEndParameter(1)) / 2.0;
                XYZ pm = ProyectarPuntoAElevacion(arco.Evaluate(parametroMedio, false), z);

                if (DistanciaXY(p0, p1) > 0.0001)
                    resultado.Add(Arc.Create(p0, p1, pm));

                return resultado;
            }

            IList<XYZ> puntos = curva.Tessellate();

            if (puntos == null || puntos.Count < 2)
                return resultado;

            for (int i = 0; i < puntos.Count - 1; i++)
            {
                XYZ p0 = ProyectarPuntoAElevacion(puntos[i], z);
                XYZ p1 = ProyectarPuntoAElevacion(puntos[i + 1], z);

                if (DistanciaXY(p0, p1) > 0.0001)
                    resultado.Add(Line.CreateBound(p0, p1));
            }

            return resultado;
        }

        private XYZ ProyectarPuntoAElevacion(XYZ punto, double z)
        {
            return new XYZ(punto.X, punto.Y, z);
        }

        // =========================================================
        // ESPESOR DEL SUELO
        // =========================================================

        private double ObtenerEspesorTipoSuelo(FloorType floorType)
        {
            if (floorType == null)
                return 0.0;

            try
            {
                CompoundStructure estructura = floorType.GetCompoundStructure();

                if (estructura != null)
                {
                    double espesor = estructura.GetWidth();

                    if (espesor > 0.0001)
                        return espesor;
                }
            }
            catch
            {
            }

            try
            {
                Parameter pEspesor = floorType.get_Parameter(BuiltInParameter.FLOOR_ATTR_THICKNESS_PARAM);

                if (pEspesor != null && pEspesor.StorageType == StorageType.Double)
                {
                    double espesor = pEspesor.AsDouble();

                    if (espesor > 0.0001)
                        return espesor;
                }
            }
            catch
            {
            }

            return 0.0;
        }

        // =========================================================
        // UTILIDADES GEOMÉTRICAS
        // =========================================================

        private XYZ ProyectarPuntoSobreLineaXY(
            XYZ punto,
            XYZ origen,
            XYZ direccionNormalizada,
            out double distanciaSobreLinea)
        {
            XYZ v = new XYZ(
                punto.X - origen.X,
                punto.Y - origen.Y,
                0.0);

            distanciaSobreLinea = v.DotProduct(direccionNormalizada);

            XYZ proyectado = origen + direccionNormalizada.Multiply(distanciaSobreLinea);

            return new XYZ(
                proyectado.X,
                proyectado.Y,
                origen.Z);
        }

        private XYZ DireccionXY(XYZ p0, XYZ p1)
        {
            XYZ v = new XYZ(
                p1.X - p0.X,
                p1.Y - p0.Y,
                0.0);

            return NormalizarXY(v);
        }

        private XYZ NormalizarXY(XYZ v)
        {
            if (v == null)
                return null;

            double longitud = Math.Sqrt(v.X * v.X + v.Y * v.Y);

            if (longitud < 0.0000001)
                return null;

            return new XYZ(
                v.X / longitud,
                v.Y / longitud,
                0.0);
        }

        private double DistanciaXY(XYZ p0, XYZ p1)
        {
            if (p0 == null || p1 == null)
                return 0.0;

            double dx = p1.X - p0.X;
            double dy = p1.Y - p0.Y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        private double ProductoPuntoXY(XYZ a, XYZ b)
        {
            if (a == null || b == null)
                return 0.0;

            return (a.X * b.X) + (a.Y * b.Y);
        }

        private double MetrosAPies(double metros)
        {
            return metros / 0.3048;
        }

        private double PiesAMetros(double pies)
        {
            return pies * 0.3048;
        }

        // =========================================================
        // LLENADO DE PARÁMETROS MYG
        // =========================================================

        private void LlenarParametrosSueloCreado(
            Floor suelo,
            string nombreHabitacionFormatoOracion)
        {
            if (suelo == null)
                return;

            SetearParametroTextoSeguro(
                suelo,
                "ARQ_Ubicación",
                nombreHabitacionFormatoOracion);

            SetearParametroTextoSeguro(
                suelo,
                "GEN_ID Elemento",
                suelo.Id.Value.ToString());
        }

        private void LlenarAcabadoSueloRoom(
            Room room,
            string descripcionAcabadoSuelo)
        {
            if (room == null)
                return;

            if (string.IsNullOrWhiteSpace(descripcionAcabadoSuelo))
                return;

            Parameter pAcabado = ObtenerParametroPorNombres(
                room,
                new string[]
                {
                    "Acabado del suelo",
                    "Acabado de suelo",
                    "Floor Finish",
                    "Floor finish"
                });

            SetearParametroTextoSeguro(
                pAcabado,
                descripcionAcabadoSuelo);
        }

        private string ObtenerNombreHabitacionFormatoOracion(Room room)
        {
            if (room == null)
                return "";

            string nombre = "";

            try
            {
                Parameter pNombre = room.get_Parameter(BuiltInParameter.ROOM_NAME);

                if (pNombre != null)
                    nombre = pNombre.AsString();
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(nombre))
                nombre = ObtenerNombreRoom(room);

            return ConvertirTextoATipoOracion(nombre);
        }

        private string ObtenerDescripcionTipoSueloParaAcabado(FloorType floorType)
        {
            if (floorType == null)
                return "";

            string descripcion = "";

            try
            {
                Parameter pDescripcion = floorType.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION);

                if (pDescripcion != null)
                {
                    descripcion = ObtenerTextoParametro(pDescripcion);

                    if (!string.IsNullOrWhiteSpace(descripcion))
                        return descripcion.Trim();
                }
            }
            catch
            {
            }

            try
            {
                Parameter pDescripcionPorNombre = ObtenerParametroPorNombres(
                    floorType,
                    new string[]
                    {
                        "Descripción",
                        "Descripcion",
                        "Description"
                    });

                descripcion = ObtenerTextoParametro(pDescripcionPorNombre);

                if (!string.IsNullOrWhiteSpace(descripcion))
                    return descripcion.Trim();
            }
            catch
            {
            }

            // Respaldo: si el tipo no tiene descripción, se usa el nombre del tipo
            // para no dejar vacío el parámetro "Acabado del suelo" del Room.
            return floorType.Name;
        }

        private string ConvertirTextoATipoOracion(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string limpio = texto.Trim();

            try
            {
                CultureInfo cultura = new CultureInfo("es-PE");
                TextInfo textInfo = cultura.TextInfo;

                limpio = textInfo.ToLower(limpio);

                if (limpio.Length == 1)
                    return textInfo.ToUpper(limpio);

                return char.ToUpper(limpio[0], cultura) + limpio.Substring(1);
            }
            catch
            {
                limpio = limpio.ToLower();

                if (limpio.Length == 1)
                    return limpio.ToUpper();

                return limpio.Substring(0, 1).ToUpper() + limpio.Substring(1);
            }
        }

        private Parameter ObtenerParametroPorNombres(
            Element elemento,
            string[] nombres)
        {
            if (elemento == null || nombres == null || nombres.Length == 0)
                return null;

            foreach (string nombre in nombres)
            {
                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                try
                {
                    Parameter p = elemento.LookupParameter(nombre);

                    if (p != null)
                        return p;
                }
                catch
                {
                }
            }

            return null;
        }

        private string ObtenerTextoParametro(Parameter parametro)
        {
            if (parametro == null)
                return "";

            try
            {
                if (parametro.StorageType == StorageType.String)
                    return parametro.AsString() ?? "";

                string valorComoTexto = parametro.AsValueString();

                if (!string.IsNullOrWhiteSpace(valorComoTexto))
                    return valorComoTexto;
            }
            catch
            {
            }

            return "";
        }

        private void SetearParametroTextoSeguro(
            Element elemento,
            string nombreParametro,
            string valor)
        {
            if (elemento == null)
                return;

            if (string.IsNullOrWhiteSpace(nombreParametro))
                return;

            Parameter parametro = null;

            try
            {
                parametro = elemento.LookupParameter(nombreParametro);
            }
            catch
            {
                parametro = null;
            }

            SetearParametroTextoSeguro(
                parametro,
                valor);
        }

        private void SetearParametroTextoSeguro(
            Parameter parametro,
            string valor)
        {
            if (parametro == null)
                return;

            if (parametro.IsReadOnly)
                return;

            string texto = valor ?? "";

            try
            {
                if (parametro.StorageType == StorageType.String)
                {
                    parametro.Set(texto);
                    return;
                }

                if (parametro.StorageType == StorageType.Integer)
                {
                    int valorEntero = 0;

                    if (int.TryParse(texto, out valorEntero))
                        parametro.Set(valorEntero);

                    return;
                }

                if (parametro.StorageType == StorageType.Double)
                {
                    double valorDouble = 0.0;
                    string textoNumerico = texto.Replace(",", ".");

                    if (double.TryParse(
                        textoNumerico,
                        NumberStyles.Any,
                        CultureInfo.InvariantCulture,
                        out valorDouble))
                    {
                        parametro.Set(valorDouble);
                    }

                    return;
                }

                if (parametro.StorageType == StorageType.ElementId)
                {
                    int valorEntero = 0;

                    if (int.TryParse(texto, out valorEntero))
                        parametro.Set(new ElementId(valorEntero));

                    return;
                }
            }
            catch
            {
                // Si el parámetro no acepta el valor, se omite para no detener el proceso.
            }
        }

        // =========================================================
        // UTILIDADES GENERALES
        // =========================================================

        private void AgregarElementIdUnico(
            List<ElementId> lista,
            ElementId id)
        {
            if (lista == null)
                return;

            if (id == null || id == ElementId.InvalidElementId)
                return;

            foreach (ElementId item in lista)
            {
                if (item == null)
                    continue;

                if (item.Value == id.Value)
                    return;
            }

            lista.Add(id);
        }


        // =========================================================
        // DIAGNÓSTICO PROFUNDO
        // =========================================================

        private string GuardarReporteDiagnostico(
            Document doc,
            List<string> lineas)
        {
            try
            {
                string carpeta = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

                if (string.IsNullOrWhiteSpace(carpeta) || !Directory.Exists(carpeta))
                    carpeta = Path.GetTempPath();

                string nombreDoc = doc != null ? doc.Title : "Documento";
                string nombreArchivo = "MYG_Diagnostico_Profundo_CrearSuelosRooms_" +
                    LimpiarNombreArchivo(nombreDoc) + "_" +
                    DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";

                string ruta = Path.Combine(carpeta, nombreArchivo);

                File.WriteAllLines(ruta, lineas ?? new List<string>(), Encoding.UTF8);

                return ruta;
            }
            catch
            {
                try
                {
                    string ruta = Path.Combine(
                        Path.GetTempPath(),
                        "MYG_Diagnostico_Profundo_CrearSuelosRooms_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt");

                    File.WriteAllLines(ruta, lineas ?? new List<string>(), Encoding.UTF8);
                    return ruta;
                }
                catch
                {
                    return "No se pudo guardar el reporte diagnóstico.";
                }
            }
        }

        private string LimpiarNombreArchivo(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                return "Documento";

            string limpio = nombre;

            foreach (char c in Path.GetInvalidFileNameChars())
                limpio = limpio.Replace(c, '_');

            return limpio;
        }

        private string ResumirBoundarySegmentsRoom(Room room)
        {
            if (room == null)
                return "BoundarySegments: Room nulo";

            List<string> partes = new List<string>();

            SpatialElementBoundaryLocation[] ubicaciones =
            {
                SpatialElementBoundaryLocation.Finish,
                SpatialElementBoundaryLocation.Center,
                SpatialElementBoundaryLocation.CoreBoundary,
                SpatialElementBoundaryLocation.CoreCenter
            };

            foreach (SpatialElementBoundaryLocation ubicacion in ubicaciones)
            {
                try
                {
                    SpatialElementBoundaryOptions opt = new SpatialElementBoundaryOptions();
                    opt.SpatialElementBoundaryLocation = ubicacion;

                    IList<IList<BoundarySegment>> boundaries = room.GetBoundarySegments(opt);

                    if (boundaries == null)
                    {
                        partes.Add(ubicacion.ToString() + ": null");
                        continue;
                    }

                    int loops = boundaries.Count;
                    int segmentos = 0;
                    double minLen = double.MaxValue;
                    double maxLen = 0.0;
                    double total = 0.0;

                    foreach (IList<BoundarySegment> loop in boundaries)
                    {
                        if (loop == null)
                            continue;

                        foreach (BoundarySegment seg in loop)
                        {
                            if (seg == null)
                                continue;

                            Curve c = seg.GetCurve();

                            if (c == null)
                                continue;

                            segmentos++;
                            double len = c.Length;
                            minLen = Math.Min(minLen, len);
                            maxLen = Math.Max(maxLen, len);
                            total += len;
                        }
                    }

                    string minTexto = minLen < double.MaxValue ? PiesAMetros(minLen).ToString("0.####", CultureInfo.InvariantCulture) : "-";
                    string maxTexto = PiesAMetros(maxLen).ToString("0.####", CultureInfo.InvariantCulture);
                    string totalTexto = PiesAMetros(total).ToString("0.###", CultureInfo.InvariantCulture);

                    partes.Add(
                        ubicacion.ToString() +
                        ": loops=" + loops.ToString() +
                        ", segmentos=" + segmentos.ToString() +
                        ", total(m)=" + totalTexto +
                        ", min(m)=" + minTexto +
                        ", max(m)=" + maxTexto);
                }
                catch (Exception ex)
                {
                    partes.Add(ubicacion.ToString() + ": ERROR " + ex.Message);
                }
            }

            return "BoundarySegments por ubicación: " + string.Join(" || ", partes);
        }

        private string ResumirPerfilesParaDiagnostico(
            string titulo,
            IList<CurveLoop> perfiles)
        {
            if (perfiles == null)
                return titulo + ": null";

            if (perfiles.Count == 0)
                return titulo + ": 0 perfiles";

            List<string> partes = new List<string>();
            int idx = 0;

            foreach (CurveLoop loop in perfiles)
            {
                if (loop == null)
                {
                    partes.Add("Loop " + idx.ToString() + ": null");
                    idx++;
                    continue;
                }

                int curvas = 0;
                int cortas1mm = 0;
                int cortas5mm = 0;
                int lineas = 0;
                int arcos = 0;
                int otras = 0;
                double min = double.MaxValue;
                double max = 0.0;
                double total = 0.0;
                bool abierto = true;

                try
                {
                    abierto = loop.IsOpen();
                }
                catch
                {
                    abierto = true;
                }

                foreach (Curve c in loop)
                {
                    if (c == null)
                        continue;

                    curvas++;
                    double len = c.Length;
                    min = Math.Min(min, len);
                    max = Math.Max(max, len);
                    total += len;

                    if (len < MetrosAPies(0.001))
                        cortas1mm++;

                    if (len < MetrosAPies(0.005))
                        cortas5mm++;

                    if (c is Line)
                        lineas++;
                    else if (c is Arc)
                        arcos++;
                    else
                        otras++;
                }

                partes.Add(
                    "Loop " + idx.ToString() +
                    ": curvas=" + curvas.ToString() +
                    ", abierto=" + abierto.ToString() +
                    ", lineas=" + lineas.ToString() +
                    ", arcos=" + arcos.ToString() +
                    ", otras=" + otras.ToString() +
                    ", cortas<1mm=" + cortas1mm.ToString() +
                    ", cortas<5mm=" + cortas5mm.ToString() +
                    ", longTotal(m)=" + PiesAMetros(total).ToString("0.###", CultureInfo.InvariantCulture) +
                    ", min(m)=" + (min < double.MaxValue ? PiesAMetros(min).ToString("0.####", CultureInfo.InvariantCulture) : "-") +
                    ", max(m)=" + PiesAMetros(max).ToString("0.###", CultureInfo.InvariantCulture));

                idx++;
            }

            return titulo + ": Cantidad=" + perfiles.Count.ToString() + " | " + string.Join(" || ", partes);
        }

        private string ProbarExtrusionTemporalParaDiagnostico(IList<CurveLoop> perfiles)
        {
            if (perfiles == null || perfiles.Count == 0)
                return "NO OK: 0 perfiles";

            try
            {
                Solid s = GeometryCreationUtilities.CreateExtrusionGeometry(
                    perfiles,
                    XYZ.BasisZ,
                    MetrosAPies(0.05));

                if (s != null && s.Volume > 0.0000001)
                    return "OK: extrusión temporal válida | Vol=" + s.Volume.ToString("0.#####", CultureInfo.InvariantCulture);

                return "NO OK: extrusión temporal nula o sin volumen";
            }
            catch (Exception ex)
            {
                return "NO OK: " + ex.GetType().Name + " | " + ex.Message;
            }
        }

        private void MostrarEnVentana(string texto)
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(texto);
        }

        private string ObtenerNombreRoom(Room room)
        {
            if (room == null)
                return "";

            string numero = "";
            string nombre = "";

            Parameter pNumero = room.get_Parameter(BuiltInParameter.ROOM_NUMBER);
            if (pNumero != null)
                numero = pNumero.AsString();

            Parameter pNombre = room.get_Parameter(BuiltInParameter.ROOM_NAME);
            if (pNombre != null)
                nombre = pNombre.AsString();

            string texto = "";

            if (!string.IsNullOrWhiteSpace(numero))
                texto += numero;

            if (!string.IsNullOrWhiteSpace(nombre))
            {
                if (!string.IsNullOrWhiteSpace(texto))
                    texto += " - ";

                texto += nombre;
            }

            if (string.IsNullOrWhiteSpace(texto))
                texto = "Room Id " + room.Id.Value.ToString();

            return texto;
        }
    }

    public enum RoomSueloAccion
    {
        Ninguna = 0,
        SeleccionarRoom = 1,
        CrearSuelo = 2,
        PicarSuperficieBase = 3
    }

    public class FiltroSeleccionRoomMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            return elem is Room;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return false;
        }
    }

    public class CurvaBoundaryMYG
    {
        public Curve Curva { get; set; }
        public ElementId ElementoBoundaryId { get; set; }
    }

    public class SegmentoBoundaryPuertaMYG
    {
        public int Indice { get; set; }
        public CurvaBoundaryMYG Item { get; set; }
        public Line Linea { get; set; }
        public List<VacioPuertaEnSegmento> Vacios { get; set; }
    }

    public class InfoPuertaBoundaryManualMYG
    {
        public double Inicio { get; set; }
        public double Fin { get; set; }
        public double CentroT { get; set; }
        public double Ancho { get; set; }
        public double AnchoParametro { get; set; }
        public double AnchoBBox { get; set; }
        public XYZ CentroPuerta { get; set; }
        public XYZ PuntoBoundary { get; set; }
        public double DistanciaPerpendicular { get; set; }
    }

    public class VacioPuertaEnSegmento
    {
        public ElementId IdPuerta { get; set; }
        public double Inicio { get; set; }
        public double Fin { get; set; }
        public XYZ DireccionProyeccion { get; set; }
        public double Profundidad { get; set; }
    }
}
