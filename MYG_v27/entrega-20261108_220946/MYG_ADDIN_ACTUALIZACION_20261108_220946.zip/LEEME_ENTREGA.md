# Zócalos: selección directa, fase del Room y colocación exterior

## A. Cambios

Se corrige el error `The id does not represent a valid phase. Parameter name: phaseId`. El código anterior utilizaba el CreatedPhaseId genérico del Room, que puede ser inválido para un elemento espacial. Ahora se resuelve Room.Phase, se confirma que su ID representa una Phase existente en el documento y solo después se consulta el estado de los muros. La fase se valida una vez por Room; no se repite el mismo error por cada borde.

Se elimina el selector del TIPO del tarrajeo existente. Con el checkbox activado aparece el botón **SELECCIONAR MUROS A RECORTAR**: el usuario pica directamente los muros de acabado del modelo actual, confirma con Finalizar y ve el contador. Se pueden elegir acabados de distintos tipos. Solo se consideran esos IDs y sus fragmentos derivados dentro de la ejecución; no hay búsqueda global por tipo.

El tipo que aún debe elegirse es el del **ZÓCALO NUEVO**, necesario para crear el elemento. El título lo distingue al activar el modo de reemplazo. Se conserva el flujo normal anterior cuando el checkbox está desmarcado.

Para zócalos, el acabado nuevo ocupa el lado exterior del contorno del Room, hacia la cara de apoyo del acabado seleccionado que da al ladrillo. No se añade una segunda capa hacia dentro del Room. Se ancla su cara posterior al mismo apoyo del acabado anterior y se exige que el frente quepa fuera del contorno.

Ejemplo: tarrajeo anterior de 15 mm con frente en el Room; zócalo de 10 mm. El apoyo se conserva a -15 mm respecto al contorno, el centro nuevo queda a -10 mm y su frente a -5 mm: queda fuera del Room y contra el apoyo. Con 15 mm de espesor nuevo, el frente coincide con el contorno. Si el espesor nuevo invade el Room más de la tolerancia de 1 mm, el tramo se rechaza sin cortar el ladrillo ni colocar otra capa interior. Tampoco se adivina una cara de ladrillo distinta: el apoyo se toma del acabado seleccionado.

La dirección interior se determina con sondas locales IsPointInRoom a alturas interiores del volumen del Room; se rechaza un lado ambiguo en vez de suponerlo desde la ubicación del Room. Se comprueban los vértices sólidos del zócalo al crearlo y OTRA VEZ después de la limpieza/unión de extremos, antes de confirmar el lote.

Se conserva el recorte parcial por altura: arriba permanece el tarrajeo de cada tipo original, y también los laterales o la franja inferior cuando corresponda. Si no se puede conservar un tramo, se revierte conjuntamente el recorte y la creación. Los bordes no seleccionados del Room se ignoran sin contabilizarlos como errores; si ningún muro elegido coincide, se informa una sola vez.

## Base comprobada

Checkout bimchimbote-droid/MYG_v27_reestructurado, HEAD da11b13a3f5ce35b9565bf4d5bd27cb761091102, conservando las actualizaciones locales anteriores. Las dos fuentes al comenzar coinciden byte por byte con DESCARGAS commit 595bbb1ba1a23054d610fb7f8f5c1a8de5b9c119, ZIP MYG_ADDIN_ACTUALIZACION_20261108_215113.zip. No se sustituyeron por main de MYG_v27.

La herramienta de suelos permanece igual a la entrega 625fa1943c214ed773ecb0a77a517f6c98e6a841 y queda fuera del ZIP. MANIFIESTO.json incluye hashes de entrada y salida de estas dos fuentes.

## B. Archivos

| Ruta exacta | Acción | Uso |
| --- | --- | --- |
| MYG/Funcionalidades/Arquitectura/Habitaciones/CrearMuroDesdeRoomForm.cs | REEMPLAZAR | Selección directa, contador y validación sin tipo de acabado anterior. |
| MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs | REEMPLAZAR | Selección API, fase válida, recorte por IDs y posición exterior verificada. |
| CAMBIOS_SELECCION_ZOCALOS.patch | CREAR, alternativa | Parche puntual de las mismas dos fuentes; no usar además del reemplazo completo. |
| tests/SeleccionMurosZocalos/Regression.csproj | CREAR, prueba opcional | Proyecto .NET 8 independiente. |
| tests/SeleccionMurosZocalos/RevitDoubles.cs | CREAR, prueba opcional | Dobles de fase, Room, geometría y etiqueta. |
| tests/SeleccionMurosZocalos/Program.cs | CREAR, prueba opcional | 21 casos de regresión. |
| tests/SeleccionMurosZocalos/extract_methods.py | CREAR, prueba opcional | Extrae seis métodos reales de las fuentes finales. |
| tests/SeleccionMurosZocalos/run.sh | CREAR, prueba opcional | Ejecutor de pruebas. |
| tests/SeleccionMurosZocalos/README.md | CREAR, documentación | Alcance de pruebas. |
| LEEME_ENTREGA.md | CREAR, documentación | Este archivo. |
| MANIFIESTO.json | CREAR, documentación | Relación y hashes. |

SIN CAMBIOS y fuera del ZIP: comando, proyecto, dependencias, recursos, código de suelos y pruebas anteriores. No hay eliminación de archivos fuente ni DLL.

## C/D. Instalación y uso

1. Respalde las dos fuentes actuales y su DLL funcional. Compare antes de reemplazar: los archivos completos pueden sobrescribir modificaciones locales o posteriores.
2. Elija UN procedimiento: copiar las dos fuentes completas sobre las mismas rutas relativas, O ejecutar desde la raíz `git apply --check CAMBIOS_SELECCION_ZOCALOS.patch` y después `git apply CAMBIOS_SELECCION_ZOCALOS.patch`. Si no aplica limpiamente, integre mediante comparación de archivos, sin forzar ni perder sus avances. No combine ambos procedimientos.
3. Las fuentes ya figuran en el csproj. No agregue los dobles ni el proyecto de pruebas al add-in. Compile en Windows con las referencias y COM originales. Cierre Revit al sustituir la DLL y pruebe sobre una copia del modelo.
4. En Crear Muro desde Rooms: seleccione los Rooms, el tipo del zócalo NUEVO, altura y base/nivel. Active Reemplazar tarrajeo hasta la altura indicada. Pulse SELECCIONAR MUROS A RECORTAR, pique los acabados que quiere sustituir y confirme con Finalizar. Ya no se ingresa el tipo del acabado anterior.
5. Ejecute. Revise los paños sustituidos y los rechazos. Si un muro de la selección desapareció por un reemplazo completo anterior, selecciónelo nuevamente según los elementos actuales antes de otra ejecución.

## E. Configuración

Sin paquetes, referencias ni cambios de proyecto adicionales. Se conserva el framework original y el uso de los eventos externos de Revit para seleccionar elementos. La selección admite muros básicos no marcados como estructurales del documento actual. Elija únicamente los acabados que desea recortar; no se modifica automáticamente otro muro por compartir tipo.

Se admiten muros existentes o nuevos en la fase válida del Room, aunque la fase de creación del acabado sea anterior. Los zócalos nuevos reciben la fase específica del Room. Las opciones de diseño deben ser compatibles con el Room y con la creación en la vista activa. No se configura un proceso de demolición por fases: recortar un elemento anterior modifica su geometría original en las fases donde ese elemento exista.

## F. Validación real

- 21 escenarios aprobados, 0 fallidos, ejecutando seis métodos extraídos de las fuentes finales con dobles y cálculos puros. Incluyen 20 pares de espesores.
- Regresión principal: Room.Phase válida con CreatedPhaseId genérico inválido; la propiedad genérica no se lee para resolver la fase. Se rechazan fases inexistentes o IDs que no representan Phase.
- Posición: zócalo más delgado, mismo espesor, exceso de espesor y falta de franja exterior. Orientación: cotas no nulas, tramo invertido y rotado, ambos lados dentro/fuera, cambios de lado y datos inválidos. Selección: copia y eliminación de IDs repetidos o inválidos, contador y lista vacía.
- Roslyn C# 7.3: 179 fuentes activas completas analizadas, 0 errores de sintaxis. Las dos fuentes siguen incluidas una sola vez; existen todos los 179 Compile, 9 EmbeddedResource y 3 None. git diff --check correcto.
- Compilación completa intentada en Linux con MSBuild .NET 8: FALLÓ en MSB4803, ResolveComReference necesita MSBuild de .NET Framework. Faltan además las referencias Windows/Revit; el conflicto EPPlus previo continúa. No se generó una DLL validada.
- Los dobles NO ejecutan Revit/WinForms, selección interactiva, GetPhaseStatus real, copia/borrado de elementos, recorte, transacciones ni sólidos reales. No se presenta el análisis de sintaxis como compilación ni estas pruebas como validación funcional del modelo.

Para repetir pruebas independientes, con .NET SDK 8 y Python 3, desde la raíz extraída:

```bash
bash tests/SeleccionMurosZocalos/run.sh
```

### Pendiente dentro de Revit

- Repetir el Room de la captura: confirmar ausencia del error phaseId y que solo se recorten los muros picados.
- Seleccionar acabados de distintos tipos y otros iguales NO seleccionados; comprobar que estos últimos permanecen intactos.
- Comprobar zócalos fuera del Room y contra la cara de apoyo seleccionada con espesores iguales y menores al anterior; el mayor debe rechazarse cuando no quepa.
- Revisar esquina, tramo invertido, Room estrecho y base picada elevada. Medir el zócalo y el tarrajeo superior y revisar posición después de uniones de extremos.
- Probar cancelación de selección, selección vacía, paredes de otra fase/opción y muros eliminados desde la selección previa.
- Mantener el checkbox desactivado y verificar el flujo normal de creación hacia dentro, que no fue cambiado.

## G. GitHub

Publicar el ZIP en bimchimbote-droid/DESCARGAS no instala archivos en su PC ni actualiza los repositorios de código. No se hizo commit ni push de MYG_v27/MYG_v27_reestructurado. Después de instalar y probar, revise Git Changes en Visual Studio, haga Commit y luego Push cuando decida conservarlo.

## H. Límites

El recorte mantiene el soporte anterior para acabados independientes rectos, verticales y rectangulares. Se conservan sin modificar los tramos curvos, perfiles editados, grupos, fijados, elementos alojados o geometrías que no puedan dividirse conservando sus restos. Cuando copiar restos de una fuente con uniones existentes pudiera perder cortes, se rechaza el tramo. No se borran dependencias para forzar la operación.

La colocación exterior requiere espacio real entre el contorno del Room y el apoyo del acabado elegido. Si el contorno está ya en la cara del ladrillo y no hay franja exterior disponible, no se introduce el zócalo en el ladrillo para aparentar contacto: se informa el rechazo. El apoyo se infiere de la cara posterior del muro de acabado seleccionado; el contacto físico y su ajuste con el ladrillo real deben comprobarse en el modelo. Los casos de orientación ambigua no se resuelven mediante suposiciones.
