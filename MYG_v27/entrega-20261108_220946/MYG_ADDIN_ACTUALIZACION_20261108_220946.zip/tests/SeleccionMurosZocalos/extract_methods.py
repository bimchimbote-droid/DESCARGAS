#!/usr/bin/env python3
"""Extract production methods rather than keeping manual implementation copies."""
from pathlib import Path
import hashlib,re,sys
handler=Path(sys.argv[1]).resolve();form=Path(sys.argv[2]).resolve()
parts=[]
for path,names in [(handler,['ObtenerFaseValidaRoom','CalcularCentroZocaloExterior','ObtenerInteriorVerificadoParaZocalo','NormalizarXY','MetrosAPies']),(form,['ActualizarMurosAReemplazar'])]:
 source=path.read_text(encoding='utf-8-sig')
 for name in names:
  match=re.search(r'^\s*(?:private|public)[^\n]*\b'+name+r'\s*\(',source,re.M)
  if not match:raise SystemExit('Production declaration missing: '+name)
  start=match.start();opening=source.index('{',match.end());depth=1;end=opening+1
  while depth and end<len(source):
   if source[end]=='{':depth+=1
   elif source[end]=='}':depth-=1
   end+=1
  if depth:raise SystemExit('Unterminated declaration: '+name)
  parts.append(source[start:end])
header='// Generated from actual delivered production files; do not edit.\n'
for path in [handler,form]:header+='// '+path.name+' SHA256: '+hashlib.sha256(path.read_bytes()).hexdigest()+'\n'
(Path(__file__).parent/'GeneratedMethods.cs').write_text(header+'using Autodesk.Revit.DB;\nusing Autodesk.Revit.DB.Architecture;\npartial class Harness\n{\n'+'\n\n'.join(parts)+'\n}\n')
print('Extracted 6 actual phase/placement/orientation/selection methods')
