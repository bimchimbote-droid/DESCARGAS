// Contract doubles only: no Revit document, UI or geometric engine is loaded.
namespace Autodesk.Revit.DB
{
    public class ElementId
    {
        public long Value {get;}
        public ElementId(long value){Value=value;}
        public static readonly ElementId InvalidElementId=new(-1);
        public override bool Equals(object other)=>other is ElementId id && Value==id.Value;
        public override int GetHashCode()=>Value.GetHashCode();
        public static bool operator==(ElementId a,ElementId b)=>ReferenceEquals(a,b)||(a is not null&&b is not null&&a.Value==b.Value);
        public static bool operator!=(ElementId a,ElementId b)=>!(a==b);
    }
    public class XYZ
    {
        public double X {get;} public double Y {get;} public double Z {get;}
        public XYZ(double x,double y,double z){X=x;Y=y;Z=z;}
        public XYZ Multiply(double factor)=>new(X*factor,Y*factor,Z*factor);
        public double GetLength()=>Math.Sqrt(X*X+Y*Y+Z*Z);
        public XYZ Normalize(){double length=GetLength();return new(X/length,Y/length,Z/length);}
        public static XYZ operator+(XYZ a,XYZ b)=>new(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static XYZ operator-(XYZ a,XYZ b)=>new(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
    }
    public class BoundingBoxXYZ {public XYZ Min {get;set;} public XYZ Max {get;set;} }
    public class Line
    {
        readonly XYZ start,end;
        public Line(XYZ a,XYZ b){start=a;end=b;}
        public XYZ GetEndPoint(int index)=>index==0?start:end;
    }
    public class Element {public ElementId Id {get;set;} }
    public class Phase:Element { }
    public class Document
    {
        public readonly Dictionary<long,Element> Elements=new();
        public Element GetElement(ElementId id)=>id!=null&&Elements.TryGetValue(id.Value,out var element)?element:null;
    }
}
namespace Autodesk.Revit.DB.Architecture
{
    public class Room:Autodesk.Revit.DB.Element
    {
        public Autodesk.Revit.DB.Phase Phase {get;set;}
        public Autodesk.Revit.DB.BoundingBoxXYZ Box {get;set;}
        public Func<Autodesk.Revit.DB.XYZ,bool> Membership {get;set;}
        public List<Autodesk.Revit.DB.XYZ> Queries=new();
        public Autodesk.Revit.DB.BoundingBoxXYZ get_BoundingBox(object view)=>Box;
        public bool IsPointInRoom(Autodesk.Revit.DB.XYZ point){Queries.Add(point);return Membership!=null&&Membership(point);}
        public int GenericCreatedPhaseReads {get;private set;}
        // Spatial Rooms may not supply a generic CreatedPhaseId. Production
        // resolution must use Room.Phase rather than this intentionally invalid ID.
        public Autodesk.Revit.DB.ElementId CreatedPhaseId
        {
            get{GenericCreatedPhaseReads++;return Autodesk.Revit.DB.ElementId.InvalidElementId;}
        }
    }
}
class LabelDouble {public string Text {get;set;} }
