#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
handler_path=${1:-../../MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs}
form_path=${2:-../../MYG/Funcionalidades/Arquitectura/Habitaciones/CrearMuroDesdeRoomForm.cs}
python3 extract_methods.py "$handler_path" "$form_path"
"${DOTNET_CMD:-dotnet}" run --project Regression.csproj --configuration Release
