using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System.Reflection;
partial class Harness
{
    public List<ElementId> MurosAReemplazarIds {get;private set;}=new();
    LabelDouble lblMurosAReemplazar=new();
    static double F(double metres)=>metres/.3048;
    object Call(string name,params object[] args)
    {
        var method=typeof(Harness).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static);
        if(method==null)throw new Exception("Missing extracted production method "+name);
        try{return method.Invoke(method.IsStatic?null:this,args);}
        catch(TargetInvocationException ex){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex.InnerException).Throw();throw;}
    }
    static void True(bool condition,string name){if(!condition)throw new Exception(name);}
    static void Near(double actual,double expected,string name,double tolerance=1e-10)
    {if(double.IsNaN(actual)||Math.Abs(actual-expected)>tolerance)throw new Exception(name+": expected "+expected+", actual "+actual);}
    void MustReject(Action action,string name)
    {bool rejected=false;try{action();}catch(ArgumentException){rejected=true;}catch(InvalidOperationException){rejected=true;}True(rejected,name);}
    ElementId PhaseId(Document doc,Room room)=>(ElementId)Call("ObtenerFaseValidaRoom",doc,room);
    double Center(double sourceCenter,double oldWidth,double newWidth,double tolerance=0.000001)=>(double)Call("CalcularCentroZocaloExterior",sourceCenter,oldWidth,newWidth,tolerance);
    static (Document doc,Room room,Phase phase) PhaseModel()
    {var phase=new Phase{Id=new ElementId(12)};var doc=new Document();doc.Elements.Add(12,phase);return(doc,new Room{Phase=phase},phase);}
    void DedicatedRoomPhase()
    {
        var(doc,room,phase)=PhaseModel();True(PhaseId(doc,room)==phase.Id,"dedicated Room.Phase ID returned");
        True(room.GenericCreatedPhaseReads==0,"generic Room.CreatedPhaseId never read");
    }
    void MissingRoomPhase()
    {var(doc,room,phase)=PhaseModel();room.Phase=null;MustReject(()=>PhaseId(doc,room),"missing Room.Phase fails before use");}
    void InvalidRoomPhaseId()
    {var(doc,room,phase)=PhaseModel();phase.Id=ElementId.InvalidElementId;MustReject(()=>PhaseId(doc,room),"invalid phase ID rejected");}
    void StaleRoomPhaseId()
    {var(doc,room,phase)=PhaseModel();doc.Elements.Clear();MustReject(()=>PhaseId(doc,room),"phase missing from document rejected");}
    void NonPhaseId()
    {var(doc,room,phase)=PhaseModel();doc.Elements[12]=new Element{Id=phase.Id};MustReject(()=>PhaseId(doc,room),"ID resolved to non-Phase rejected");}
    void ThinZocaloOutside()
    {
        double oldWidth=F(.015),newWidth=F(.010),back=-oldWidth;
        double center=Center(-oldWidth*.5,oldWidth,newWidth);
        Near(center,F(-.010),"1cm zocalo center");Near(center-newWidth*.5,back,"back touches old brick support plane");
        Near(center+newWidth*.5,F(-.005),"new front remains 5mm outside Room boundary");
    }
    void SameThicknessFlush()
    {
        double width=F(.015),center=Center(-width*.5,width,width);
        Near(center+width*.5,0,"equal-thickness front flush with Room boundary");
        Near(center-width*.5,-width,"equal-thickness back touches support");
    }
    void ThickZocaloRejected()
    {MustReject(()=>Center(F(-.0075),F(.015),F(.020)),"too-thick new zocalo cannot silently protrude into Room");}
    void NoOutsideStripRejected()
    {MustReject(()=>Center(F(.0075),F(.015),F(.010)),"support on Room boundary cannot fit positive thickness outside it");}
    void InvalidDimensionsRejected()
    {
        foreach(double value in new[]{double.NaN,double.PositiveInfinity,double.NegativeInfinity})
        {
            MustReject(()=>Center(value,F(.015),F(.01)),"invalid source-center rejected");
            MustReject(()=>Center(F(-.0075),value,F(.01)),"invalid old width rejected");
            MustReject(()=>Center(F(-.0075),F(.015),value),"invalid new width rejected");
        }
        MustReject(()=>Center(F(-.0075),0,F(.01)),"zero old width rejected");
        MustReject(()=>Center(F(-.0075),F(.015),0),"zero new width rejected");
        MustReject(()=>Center(F(-.0075),F(.015),F(-.01)),"negative new width rejected");
    }
    void SeveralThicknessPairs()
    {
        int count=0;
        foreach(double old in new[]{.01,.015,.02,.03,.05})
        foreach(double ratio in new[]{.25,.5,.75,1.0})
        {
            double oldW=F(old),newW=oldW*ratio,center=Center(-oldW*.5,oldW,newW);
            Near(center-newW*.5,-oldW,"support invariant");True(center+newW*.5<=1e-10,"full section outside invariant");count++;
        }
        True(count==20,"20 physical thickness pairs verified");
    }
    void DirectSelectionDedup()
    {
        ActualizarMurosAReemplazar(new(){new ElementId(7),new ElementId(8),new ElementId(7),null,ElementId.InvalidElementId});
        True(MurosAReemplazarIds.Count==2&&MurosAReemplazarIds[0].Value==7&&MurosAReemplazarIds[1].Value==8,"only explicit distinct valid IDs retained");
        True(lblMurosAReemplazar.Text.Contains("2"),"selection count label updated");
    }
    void DirectSelectionCopiesInput()
    {
        var ids=new List<ElementId>{new(15),new(99)};ActualizarMurosAReemplazar(ids);ids.Clear();
        True(MurosAReemplazarIds.Count==2,"caller list mutation cannot alter stored picked IDs");
    }
    void EmptySelectionAndNoLabel()
    {
        ActualizarMurosAReemplazar(new(){new ElementId(5)});ActualizarMurosAReemplazar(null);
        True(MurosAReemplazarIds.Count==0,"null input clears previous picked IDs");
        lblMurosAReemplazar=null;ActualizarMurosAReemplazar(new(){new ElementId(17)});
        True(MurosAReemplazarIds.Count==1,"selection can update with unavailable label");
    }
    XYZ Interior(Room room,Line boundary)=>(XYZ)Call("ObtenerInteriorVerificadoParaZocalo",room,boundary);
    static XYZ P(double x,double y,double z=0)=>new(F(x),F(y),F(z));
    static Room OrientationRoom()=>new(){Box=new(){Min=P(-1,-1,17.5),Max=P(5,5,20.5)}};
    void InteriorFromLocalRoomVolume()
    {
        var room=OrientationRoom();room.Membership=p=>p.Y>0&&p.Y<F(3)&&p.X>0&&p.X<F(4)&&p.Z>F(17.5)&&p.Z<F(20.5);
        var normal=Interior(room,new Line(P(0,0),P(4,0)));
        Near(normal.X,0,"local inside normal X");Near(normal.Y,1,"local inside normal Y");Near(normal.Z,0,"normal stays horizontal");
        True(room.Queries.Count>0&&room.Queries.All(p=>p.Z>F(17.5)&&p.Z<F(20.5)),"probes use interior Room heights, not boundary input Z");
    }
    void ReversedBoundarySameInterior()
    {
        var room=OrientationRoom();room.Membership=p=>p.Y>0&&p.X>0&&p.X<F(4);
        var normal=Interior(room,new Line(P(4,0),P(0,0)));
        Near(normal.X,0,"reversed boundary X");Near(normal.Y,1,"reversed boundary resolves same actual inside");
    }
    void RotatedBoundaryNormal()
    {
        var room=OrientationRoom();room.Membership=p=>p.Y>p.X;
        var normal=Interior(room,new Line(P(0,0),P(4,4)));
        Near(normal.X,-1/Math.Sqrt(2),"rotated normal X");Near(normal.Y,1/Math.Sqrt(2),"rotated normal Y");
    }
    void BothSidesAmbiguousRejected()
    {var room=OrientationRoom();room.Membership=p=>true;MustReject(()=>Interior(room,new Line(P(0,0),P(4,0))),"both sides inside cannot define outside");}
    void NeitherSideAmbiguousRejected()
    {var room=OrientationRoom();room.Membership=p=>false;MustReject(()=>Interior(room,new Line(P(0,0),P(4,0))),"neither side inside cannot guess toward Room center");}
    void InteriorChangesAlongBoundaryRejected()
    {
        var room=OrientationRoom();room.Membership=p=>p.X<F(2)?p.Y>0:p.Y<0;
        MustReject(()=>Interior(room,new Line(P(0,0),P(4,0))),"opposite local interior signs along one span rejected");
    }
    void InvalidRoomOrDirectionRejected()
    {
        var room=OrientationRoom();room.Membership=p=>p.Y>0;
        MustReject(()=>Interior(null,new Line(P(0,0),P(4,0))),"no room volume rejected");
        MustReject(()=>Interior(room,new Line(P(0,0,0),P(0,0,3))),"no horizontal direction rejected");
        room.Box.Max=P(5,5,17.5);MustReject(()=>Interior(room,new Line(P(0,0),P(4,0))),"zero height room box rejected");
    }
    static void Main()
    {
        var h=new Harness();var cases=new (string,Action)[]{
            ("dedicated Room phase, generic CreatedPhaseId invalid",h.DedicatedRoomPhase),
            ("missing Room phase rejected",h.MissingRoomPhase),
            ("invalid phase ID rejected",h.InvalidRoomPhaseId),
            ("stale phase ID rejected",h.StaleRoomPhaseId),
            ("non-Phase document element rejected",h.NonPhaseId),
            ("thinner zocalo outside Room and at brick plane",h.ThinZocaloOutside),
            ("equal thickness flush with boundary",h.SameThicknessFlush),
            ("excess thickness rejected",h.ThickZocaloRejected),
            ("no exterior strip rejected",h.NoOutsideStripRejected),
            ("invalid dimensions rejected",h.InvalidDimensionsRejected),
            ("20 support/outside thickness pairs",h.SeveralThicknessPairs),
            ("direct selected IDs deduplicated",h.DirectSelectionDedup),
            ("direct selection input copied",h.DirectSelectionCopiesInput),
            ("empty selection and unavailable label",h.EmptySelectionAndNoLabel),
            ("local Room probes at nonzero heights",h.InteriorFromLocalRoomVolume),
            ("reversed boundary has same verified inside",h.ReversedBoundarySameInterior),
            ("rotated boundary verified inside",h.RotatedBoundaryNormal),
            ("both sides ambiguous rejected",h.BothSidesAmbiguousRejected),
            ("neither side ambiguous rejected",h.NeitherSideAmbiguousRejected),
            ("interior side changes along span rejected",h.InteriorChangesAlongBoundaryRejected),
            ("invalid volume or horizontal direction rejected",h.InvalidRoomOrDirectionRejected)};
        foreach(var c in cases){c.Item2();Console.WriteLine("PASS "+c.Item1);}Console.WriteLine($"{cases.Length} passed; 0 failed. Contract doubles/pure placement only; no Revit integration executed.");
    }
}
