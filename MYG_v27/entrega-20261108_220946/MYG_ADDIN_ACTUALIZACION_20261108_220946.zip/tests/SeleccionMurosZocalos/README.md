# Regresión de fase, selección directa y zócalo exterior

Estas pruebas extraen seis métodos de los archivos finales entregados:

- `ObtenerFaseValidaRoom`: resuelve la fase específica de `Room.Phase` y confirma que el ID representa una `Phase` existente en el documento.
- `CalcularCentroZocaloExterior`: calcula el centro del zócalo desde la cara de apoyo del acabado seleccionado y comprueba que la sección cabe fuera del Room.
- `ObtenerInteriorVerificadoParaZocalo`, con `NormalizarXY` y `MetrosAPies`: resuelve la normal interior con sondas locales a alturas interiores del Room; no adivina el lado desde la ubicación del Room.
- `ActualizarMurosAReemplazar`: copia y depura los IDs elegidos y actualiza el contador de selección.

No se mantienen copias manuales de las implementaciones. `extract_methods.py` genera `GeneratedMethods.cs` y registra los hashes SHA-256 de las dos fuentes que ha leído.

Requisitos: .NET SDK 8 y Python 3. Si esta carpeta se encuentra dentro de `tests/`, ejecute desde la raíz extraída:

```bash
bash tests/SeleccionMurosZocalos/run.sh
```

El nombre de carpeta puede ser diferente; utilice la ruta real del ZIP. También puede indicar los archivos explícitamente:

```bash
bash run.sh /ruta/MUROSDEROOM_EJECUTAR_HANDLER.cs /ruta/CrearMuroDesdeRoomForm.cs
```

Para un SDK fuera de PATH, anteponga `DOTNET_CMD=/ruta/dotnet`.

Casos ejecutados: **21 escenarios**, incluidos 20 pares de espesores. La regresión principal usa un Room cuya fase específica es válida y cuyo `CreatedPhaseId` genérico sería inválido; comprueba que el código no lee este último. Se rechazan fases inexistentes, IDs inválidos o que no representen una Phase. En colocación, un acabado anterior de 15 mm y un zócalo de 10 mm conservan el apoyo a -15 mm y dejan su frente a -5 mm del contorno; igual espesor queda alineado al contorno. Se rechaza el espesor que invade el Room más allá de la tolerancia indicada o la ausencia de franja exterior. La orientación cubre cotas interiores no nulas, tramo invertido y rotado, ambos lados dentro, ninguno dentro, cambios de lado interior y volúmenes/direcciones inválidos. La selección comprueba copia de IDs, eliminación de duplicados/inválidos, actualización del contador y vaciado de la lista mediante entrada nula.

**Límites:** los documentos, fases y etiqueta son dobles deterministas. Estas pruebas no cargan Autodesk Revit ni WinForms, no ejecutan la selección interactiva, `GetPhaseStatus`, geometría sólida, transacciones ni el recorte de muros. La posición física, el apoyo al ladrillo y los controles de la ventana deben verificarse en Windows/Revit con el modelo real.

Para la entrega se incluyen únicamente `Regression.csproj`, `RevitDoubles.cs`, `Program.cs`, `extract_methods.py`, `run.sh` y este README. Se excluyen `GeneratedMethods.cs`, `bin/` y `obj/`, que se regeneran al ejecutar. No agregue este proyecto de pruebas ni sus dobles al proyecto del add-in.
