﻿// =====================================
// HANDLER EXTERNO 4.2
// CREAR MURO DESDE ROOMS
// REVIT 2027
// SELECCIÓN MÚLTIPLE + BOUNDARY DE ROOM + COTA BASE POR SUPERFICIE
// =====================================


using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Globalization;

public class EjecutarCrearMuroDesdeRoomHandler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public CrearMuroDesdeRoomForm Form { get; set; }

    public CrearMuroDesdeRoomForm.RoomMuroAccion Accion { get; set; } =
        CrearMuroDesdeRoomForm.RoomMuroAccion.Ninguna;

    public string GetName()
    {
        return "MYG - Crear muro desde Rooms";
    }

    public void Execute(UIApplication app)
    {
        if (UiDoc == null || UiDoc.Document == null)
            return;

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            if (Accion == CrearMuroDesdeRoomForm.RoomMuroAccion.SeleccionarRoom)
            {
                SeleccionarRooms();
                return;
            }

            if (Accion == CrearMuroDesdeRoomForm.RoomMuroAccion.SeleccionarMurosAReemplazar)
            {
                SeleccionarMurosAReemplazar();
                return;
            }

            if (Accion == CrearMuroDesdeRoomForm.RoomMuroAccion.PicarSuperficieBase)
            {
                PicarSuperficieBase();
                return;
            }

            if (Accion == CrearMuroDesdeRoomForm.RoomMuroAccion.CrearMuro)
            {
                CrearMurosDesdeRooms();
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarEnVentana("Selección cancelada.");
        }
        catch (Exception ex)
        {
            MostrarEnVentana("ERROR:\r\n" + ex.Message);
        }
        finally
        {
            Accion = CrearMuroDesdeRoomForm.RoomMuroAccion.Ninguna;
        }
    }

    // =========================================================
    // SELECCIONAR ROOMS
    // =========================================================

    private void SeleccionarRooms()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            IList<Reference> referencias = UiDoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroSeleccionRoomMYG(),
                "Seleccione una o más habitaciones / Rooms");

            if (referencias == null || referencias.Count == 0)
                return;

            List<Room> rooms = new List<Room>();

            foreach (Reference referencia in referencias)
            {
                if (referencia == null)
                    continue;

                Room room = doc.GetElement(referencia.ElementId) as Room;

                if (room == null)
                    continue;

                if (room.Area <= 0)
                    continue;

                bool yaExiste = false;

                foreach (Room roomExistente in rooms)
                {
                    if (roomExistente == null)
                        continue;

                    if (roomExistente.Id.Value == room.Id.Value)
                    {
                        yaExiste = true;
                        break;
                    }
                }

                if (!yaExiste)
                    rooms.Add(room);
            }

            if (rooms.Count == 0)
            {
                MostrarEnVentana("No se seleccionó ningún Room válido.");
                return;
            }

            Form.ActualizarRoomsSeleccionados(rooms);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    // =========================================================
    // PICAR SUPERFICIE PARA TOMAR COTA BASE
    // =========================================================

    private void PicarSuperficieBase()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            Reference referencia = UiDoc.Selection.PickObject(
                ObjectType.Face,
                "Pique una superficie para tomar la cota base del muro");

            if (referencia == null)
                return;

            XYZ puntoGlobal = referencia.GlobalPoint;

            if (puntoGlobal == null)
            {
                Element elemento = doc.GetElement(referencia.ElementId);
                GeometryObject geoObj = null;

                try
                {
                    geoObj = elemento.GetGeometryObjectFromReference(referencia);
                }
                catch
                {
                    geoObj = null;
                }

                Face face = geoObj as Face;

                if (face != null)
                {
                    BoundingBoxUV bb = face.GetBoundingBox();

                    if (bb != null)
                    {
                        UV uv = new UV(
                            (bb.Min.U + bb.Max.U) / 2.0,
                            (bb.Min.V + bb.Max.V) / 2.0);

                        puntoGlobal = face.Evaluate(uv);
                    }
                }
            }

            if (puntoGlobal == null)
            {
                MostrarEnVentana("No se pudo obtener la cota de la superficie seleccionada.");
                return;
            }

            Level nivelCercano = ObtenerNivelMasCercano(doc, puntoGlobal.Z);

            Form.AplicarCotaBaseDesdeSuperficie(puntoGlobal, nivelCercano);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    private void SeleccionarMurosAReemplazar()
    {
        try
        {
            Form.OcultarTemporalmenteParaSeleccion();
            IList<Reference> referencias = UiDoc.Selection.PickObjects(
                ObjectType.Element, new FiltroSeleccionAcabadoARecortarMYG(),
                "Seleccione los muros de acabado que quiere recortar y pulse Finalizar");
            List<ElementId> ids = new List<ElementId>();
            HashSet<long> vistos = new HashSet<long>();
            if (referencias != null)
            {
                foreach (Reference referencia in referencias)
                {
                    Wall muro = referencia != null ? UiDoc.Document.GetElement(referencia.ElementId) as Wall : null;
                    if (muro != null && vistos.Add(muro.Id.Value))
                        ids.Add(muro.Id);
                }
            }
            Form.ActualizarMurosAReemplazar(ids);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    private class FiltroSeleccionAcabadoARecortarMYG : ISelectionFilter
    {
        public bool AllowElement(Element elemento)
        {
            Wall muro = elemento as Wall;
            if (muro == null || muro.WallType.Kind != WallKind.Basic)
                return false;
            Parameter estructural = muro.get_Parameter(BuiltInParameter.WALL_STRUCTURAL_SIGNIFICANT);
            return estructural != null && estructural.AsInteger() == 0;
        }

        public bool AllowReference(Reference referencia, XYZ punto)
        {
            return true;
        }
    }

    // =========================================================
    // CREAR MUROS DESDE ROOMS
    // =========================================================

    private void CrearMurosDesdeRooms()
    {
        Document doc = UiDoc.Document;

        List<ElementId> roomIds = Form.RoomsSeleccionadosIds;
        ElementId wallTypeId = Form.TipoMuroSeleccionadoId;
        ElementId levelId = Form.NivelSeleccionadoId;

        bool reemplazarTarrajeo = Form.ReemplazarTarrajeoExistente;
        double alturaMetros = Form.AlturaMetros;
        double alturaFeet = MetrosAPies(alturaMetros);

        if (roomIds == null || roomIds.Count == 0)
        {
            MostrarEnVentana("Debe seleccionar una o más habitaciones / Rooms.");
            return;
        }

        if (wallTypeId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar el tipo de muro.");
            return;
        }

        if (levelId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar un nivel de referencia.");
            return;
        }

        if (double.IsNaN(alturaFeet) || double.IsInfinity(alturaFeet) || alturaFeet <= 0.0)
        {
            MostrarEnVentana("Debe ingresar una altura de muro válida.");
            return;
        }

        WallType wallType = doc.GetElement(wallTypeId) as WallType;
        Level nivel = doc.GetElement(levelId) as Level;

        if (wallType == null)
        {
            MostrarEnVentana("No se encontró el tipo de muro seleccionado.");
            return;
        }

        if (nivel == null)
        {
            MostrarEnVentana("No se encontró el nivel seleccionado.");
            return;
        }

        if (reemplazarTarrajeo && wallType.Kind != WallKind.Basic)
        {
            MostrarEnVentana("El zócalo nuevo debe ser un tipo de muro básico.");
            return;
        }

        double baseOffsetFeet = Form.ObtenerDesfaseBaseFeet(nivel);
        List<ElementId> tarrajeosActivos = new List<ElementId>();
        Dictionary<long, EstadoRestoTarrajeoMYG> restosVerificables = new Dictionary<long, EstadoRestoTarrajeoMYG>();
        Dictionary<long, EstadoZocaloExteriorMYG> zocalosVerificables = new Dictionary<long, EstadoZocaloExteriorMYG>();
        if (reemplazarTarrajeo)
        {
            HashSet<long> seleccionados = new HashSet<long>();
            foreach (ElementId id in Form.MurosAReemplazarIds)
            {
                if (id != null && doc.GetElement(id) is Wall && seleccionados.Add(id.Value))
                    tarrajeosActivos.Add(id);
            }
            if (tarrajeosActivos.Count == 0)
            {
                MostrarEnVentana("Debe seleccionar muros de acabado existentes con SELECCIONAR MUROS A RECORTAR.");
                return;
            }
        }
        int pañosTarrajeoReemplazados = 0;
        int tramosReemplazoOmitidos = 0;

        int roomsProcesados = 0;
        int murosCreados = 0;
        int omitidos = 0;
        int errores = 0;
        int huecosIntegradosTotal = 0;

        List<ElementId> murosCreadosIds = new List<ElementId>();
        List<Wall> murosCreadosElementos = new List<Wall>();
        List<string> reporte = new List<string>();

        // Evita crear dos veces el mismo tramo si dos Rooms comparten boundary.
        HashSet<string> clavesBoundaryProcesadas = new HashSet<string>();

        using (Transaction tx = new Transaction(doc, "MYG - Crear muros desde Rooms"))
        {
            tx.Start();

            foreach (ElementId roomId in roomIds)
            {
                Room room = doc.GetElement(roomId) as Room;

                if (room == null)
                {
                    omitidos++;
                    reporte.Add("OMITIDO: Room no encontrado.");
                    continue;
                }

                try
                {
                    ElementId faseRoomId = reemplazarTarrajeo
                        ? ObtenerFaseValidaRoom(doc, room) : ElementId.InvalidElementId;
                    int huecosDetectadosRoom = 0;
                    int huecosIntegradosRoom = 0;

                    List<TramoBoundaryMuroMYG> tramosBoundary = ObtenerTramosBoundaryRoom(
                        doc,
                        room,
                        nivel.ProjectElevation + baseOffsetFeet,
                        out huecosDetectadosRoom);

                    if (tramosBoundary == null || tramosBoundary.Count == 0)
                    {
                        omitidos++;
                        reporte.Add("OMITIDO: " + ObtenerNombreRoom(room) + " sin boundary válido.");
                        continue;
                    }

                    int murosRoom = 0;

                    foreach (TramoBoundaryMuroMYG tramo in tramosBoundary)
                    {
                        if (tramo == null)
                            continue;

                        Curve curvaBoundary = tramo.CurvaBoundary;

                        if (curvaBoundary == null)
                            continue;

                        if (curvaBoundary.Length < 0.0001)
                            continue;

                        string clave = ObtenerClaveCurvaXY(curvaBoundary);

                        if (!string.IsNullOrWhiteSpace(clave))
                        {
                            if (clavesBoundaryProcesadas.Contains(clave))
                                continue;

                            clavesBoundaryProcesadas.Add(clave);
                        }

                        int huecosIntegradosMuro = 0;

                        List<Wall> murosTramo;
                        if (reemplazarTarrajeo)
                        {
                            try
                            {
                                int pañosReemplazados;
                                murosTramo = ReemplazarTarrajeoEnBoundary(
                                    doc, tramo, wallType, faseRoomId, nivel,
                                    alturaFeet, baseOffsetFeet, room,
                                    tarrajeosActivos, restosVerificables, zocalosVerificables,
                                    out huecosIntegradosMuro, out pañosReemplazados);
                                pañosTarrajeoReemplazados += pañosReemplazados;
                            }
                            catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
                            {
                                throw;
                            }
                            catch (Exception exReemplazo)
                            {
                                tramosReemplazoOmitidos++;
                                reporte.Add("SIN REEMPLAZAR: " + ObtenerNombreRoom(room) + " | " + exReemplazo.Message);
                                continue;
                            }
                        }
                        else
                        {
                            murosTramo = CrearMurosDesdeBoundaryHaciaAdentro(
                                doc, curvaBoundary, wallType, nivel, alturaFeet,
                                baseOffsetFeet, room, tramo.Huecos, out huecosIntegradosMuro);
                        }

                        if (murosTramo == null || murosTramo.Count == 0)
                        {
                            if (!reemplazarTarrajeo)
                                errores++;
                            continue;
                        }

                        huecosIntegradosRoom += huecosIntegradosMuro;

                        foreach (Wall muroCreado in murosTramo)
                        {
                            if (muroCreado == null)
                                continue;

                            murosCreadosIds.Add(muroCreado.Id);
                            murosCreadosElementos.Add(muroCreado);
                            murosCreados++;
                            murosRoom++;
                        }
                    }

                    huecosIntegradosTotal += huecosIntegradosRoom;

                    roomsProcesados++;

                    reporte.Add(
                        "ROOM: " + ObtenerNombreRoom(room) +
                        " | Muros creados: " + murosRoom.ToString() +
                        " | Huecos/Puertas detectados: " + huecosDetectadosRoom.ToString() +
                        " | Huecos integrados en boceto: " + huecosIntegradosRoom.ToString());
                }
                catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
                {
                    throw;
                }
                catch (Exception exRoom)
                {
                    errores++;
                    reporte.Add("ERROR ROOM: " + ObtenerNombreRoom(room) + " | " + exRoom.Message);
                }
            }

            // Si falla la regeneración o la verificación, salir de la
            // Transaction sin confirmar revierte el lote completo.
            doc.Regenerate();

            CorregirUnionesSoloEntreMurosCreados(
                doc,
                murosCreadosElementos);

            doc.Regenerate();
            VerificarAlturasMurosDesdeRooms(
                doc, murosCreadosElementos,
                nivel.ProjectElevation + baseOffsetFeet, alturaFeet);

            foreach (EstadoRestoTarrajeoMYG estado in restosVerificables.Values)
                VerificarRestoTarrajeo(doc, estado);
            // Las uniones de extremos pueden alterar la planta; comprobar la
            // posición real otra vez después de toda la limpieza de encuentros.
            foreach (EstadoZocaloExteriorMYG estado in zocalosVerificables.Values)
                VerificarZocaloExterior(doc, doc.GetElement(estado.Id) as Wall, estado.Boundary, estado.Interior);

            if (tx.Commit() != TransactionStatus.Committed)
                throw new InvalidOperationException("Revit no confirmó el lote de muros desde Rooms.");
        }

        if (murosCreadosIds.Count > 0)
            UiDoc.Selection.SetElementIds(murosCreadosIds);

        if (reemplazarTarrajeo && pañosTarrajeoReemplazados == 0 && tramosReemplazoOmitidos == 0)
            reporte.Add("No se encontró coincidencia entre los muros seleccionados y los Rooms, altura, fase u opción indicados. No se modificaron otros muros.");

        MostrarEnVentana(
            "PROCESO TERMINADO | Muros creados: " + murosCreados.ToString() +
            " | Rooms procesados: " + roomsProcesados.ToString() +
            " | Omitidos: " + omitidos.ToString() +
            " | Huecos integrados en boceto: " + huecosIntegradosTotal.ToString() +
            " | Errores: " + errores.ToString() +
            (reemplazarTarrajeo ? "\r\nPaños de tarrajeo sustituidos: " + pañosTarrajeoReemplazados.ToString() +
                " | Tramos sin reemplazar: " + tramosReemplazoOmitidos.ToString() + "\r\n" +
                string.Join("\r\n", reporte) : ""));
    }

    private ElementId ObtenerFaseValidaRoom(Document doc, Room room)
    {
        Phase fase = room != null ? room.Phase : null;
        if (doc == null || fase == null || fase.Id == ElementId.InvalidElementId ||
            !(doc.GetElement(fase.Id) is Phase))
            throw new InvalidOperationException("No se pudo determinar una fase válida del Room; no se modificaron los muros.");
        return fase.Id;
    }

    // Distancias firmadas: positivo hacia dentro del Room, negativo hacia
    // el ladrillo. Se conserva el apoyo y se exige que toda la sección quede fuera.
    private static double CalcularCentroZocaloExterior(
        double centroTarrajeoDesdeBoundary, double espesorTarrajeo,
        double espesorNuevo, double tolerancia)
    {
        double[] valores = { centroTarrajeoDesdeBoundary, espesorTarrajeo, espesorNuevo, tolerancia };
        foreach (double valor in valores)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                throw new ArgumentException("Las medidas del zócalo deben ser finitas.");
        }
        if (espesorTarrajeo <= 0.0 || espesorNuevo <= 0.0 || tolerancia < 0.0)
            throw new ArgumentException("Los espesores del zócalo y del acabado deben ser positivos.");
        double apoyo = centroTarrajeoDesdeBoundary - espesorTarrajeo * 0.5;
        double frente = apoyo + espesorNuevo;
        if (frente > tolerancia)
            throw new InvalidOperationException("El espesor del zócalo no cabe fuera del Room entre su contorno y el apoyo del acabado seleccionado. Revise el espesor o el contorno; no se cortó el ladrillo ni se añadió una capa hacia dentro.");
        return apoyo + espesorNuevo * 0.5;
    }

    private XYZ ObtenerInteriorVerificadoParaZocalo(Room room, Line boundary)
    {
        BoundingBoxXYZ caja = room != null ? room.get_BoundingBox(null) : null;
        if (caja == null || caja.Max.Z <= caja.Min.Z || boundary == null)
            throw new InvalidOperationException("No se pudo comprobar el volumen del Room para orientar el zócalo.");
        XYZ inicio = boundary.GetEndPoint(0);
        XYZ fin = boundary.GetEndPoint(1);
        XYZ direccion = NormalizarXY(fin - inicio);
        if (direccion == null)
            throw new InvalidOperationException("El tramo del zócalo no tiene una dirección válida.");
        XYZ izquierda = new XYZ(-direccion.Y, direccion.X, 0.0);
        double alturaRoom = caja.Max.Z - caja.Min.Z;
        double[] cotas = { (caja.Min.Z + caja.Max.Z) * 0.5,
            caja.Min.Z + alturaRoom * 0.25, caja.Min.Z + alturaRoom * 0.75 };
        double[] distancias = { MetrosAPies(0.005), MetrosAPies(0.02), MetrosAPies(0.05) };
        double[] posiciones = { 0.5, 0.25, 0.75 };
        int signoInterior = 0;
        foreach (double z in cotas)
        {
            foreach (double posicion in posiciones)
            {
                XYZ punto = inicio + (fin - inicio).Multiply(posicion);
                foreach (double distancia in distancias)
                {
                    XYZ a = new XYZ(punto.X + izquierda.X * distancia, punto.Y + izquierda.Y * distancia, z);
                    XYZ b = new XYZ(punto.X - izquierda.X * distancia, punto.Y - izquierda.Y * distancia, z);
                    bool dentroA = room.IsPointInRoom(a);
                    bool dentroB = room.IsPointInRoom(b);
                    if (dentroA == dentroB)
                        continue;
                    int signo = dentroA ? 1 : -1;
                    if (signoInterior != 0 && signoInterior != signo)
                        throw new InvalidOperationException("El lado interior del Room cambia en este tramo. Se conservó el acabado sin recortar.");
                    signoInterior = signo;
                }
            }
        }
        if (signoInterior == 0)
            throw new InvalidOperationException("No se pudo distinguir dentro/fuera del Room en este tramo. No se colocó el zócalo por una dirección supuesta.");
        return izquierda.Multiply(signoInterior);
    }

    private class EstadoZocaloExteriorMYG
    {
        public ElementId Id;
        public Line Boundary;
        public XYZ Interior;
    }

    private void VerificarZocaloExterior(Document doc, Wall muro, Line boundary, XYZ interior)
    {
        if (muro == null || !muro.IsValidObject)
            throw new InvalidOperationException("No se encontró el zócalo que debe permanecer fuera del Room.");
        doc.Regenerate();
        List<XYZ> puntos = ObtenerPuntosDeSolidosElemento(muro);
        if (puntos == null || puntos.Count == 0)
            throw new InvalidOperationException("No se pudo comprobar la posición exterior del zócalo.");
        XYZ origen = boundary.GetEndPoint(0);
        foreach (XYZ punto in puntos)
        {
            if (ProductoPuntoXY(punto - origen, interior) > MetrosAPies(0.001))
                throw new InvalidOperationException("El zócalo invade el interior del Room. Se revirtió el tramo.");
        }
    }

    private class EstadoRestoTarrajeoMYG
    {
        public ElementId Id;
        public Line Eje;
        public double ZBase;
        public double ZSuperior;
        public ElementId Tipo;
    }

    private List<Wall> ReemplazarTarrajeoEnBoundary(
        Document doc, TramoBoundaryMuroMYG tramo, WallType tipoNuevo, ElementId faseRoomId,
        Level nivel, double altura, double desfase, Room room,
        List<ElementId> tarrajeosActivos, Dictionary<long, EstadoRestoTarrajeoMYG> restosVerificables,
        Dictionary<long, EstadoZocaloExteriorMYG> zocalosVerificables,
        out int huecosIntegrados, out int pañosReemplazados)
    {
        huecosIntegrados = 0;
        pañosReemplazados = 0;
        Line boundary = tramo.CurvaBoundary as Line;
        if (boundary == null)
        {
            if (tramo.MuroBoundary != null && tarrajeosActivos.Contains(tramo.MuroBoundary.Id))
                throw new InvalidOperationException("El acabado seleccionado tiene un tramo curvo; el reemplazo requiere un tramo recto.");
            return new List<Wall>();
        }
        double zBase = nivel.ProjectElevation + desfase;
        double zTop = zBase + altura;
        XYZ interior = null;
        XYZ b0 = boundary.GetEndPoint(0);
        XYZ b1 = boundary.GetEndPoint(1);
        XYZ dirBoundary = NormalizarXY(b1 - b0);
        XYZ normalPreliminar = new XYZ(-dirBoundary.Y, dirBoundary.X, 0.0);
        double longitudBoundary = DistanciaXY(b0, b1);
        double tol = MetrosAPies(0.002);
        List<Wall> candidatos = new List<Wall>();
        List<double[]> intervalos = new List<double[]>();
        foreach (ElementId id in tarrajeosActivos)
        {
            Wall viejo = doc.GetElement(id) as Wall;
            if (viejo == null)
                continue;
            ElementOnPhaseStatus estadoFase = viejo.GetPhaseStatus(faseRoomId);
            if (estadoFase != ElementOnPhaseStatus.Existing && estadoFase != ElementOnPhaseStatus.New)
                continue;
            DesignOption opcionVieja = viejo.DesignOption;
            DesignOption opcionRoom = room.DesignOption;
            if ((opcionVieja == null) != (opcionRoom == null) ||
                (opcionVieja != null && opcionVieja.Id != opcionRoom.Id))
                continue;
            LocationCurve ubicacion = viejo.Location as LocationCurve;
            Line eje = ubicacion != null ? ubicacion.Curve as Line : null;
            if (eje == null)
            {
                if (tramo.MuroBoundary != null && tramo.MuroBoundary.Id == id)
                    throw new InvalidOperationException("El tarrajeo del boundary es curvo; no se modificó.");
                continue;
            }
            XYZ dirViejo = NormalizarXY(eje.GetEndPoint(1) - eje.GetEndPoint(0));
            if (dirViejo == null || Math.Abs(dirViejo.DotProduct(dirBoundary)) < 0.999999)
                continue;
            double t0 = ProductoPuntoXY(eje.GetEndPoint(0) - b0, dirBoundary);
            double t1 = ProductoPuntoXY(eje.GetEndPoint(1) - b0, dirBoundary);
            double inicio = Math.Max(0.0, Math.Min(t0, t1));
            double fin = Math.Min(longitudBoundary, Math.Max(t0, t1));
            if (fin - inicio <= tol)
                continue;
            XYZ punto = eje.GetEndPoint(0);
            double distanciaAbsoluta = Math.Abs(ProductoPuntoXY(punto - b0, normalPreliminar));
            // Boundary en cara de acabado o en cara del soporte cuando el
            // tarrajeo existente no delimita habitaciones. No buscar otro muro lejano.
            if (distanciaAbsoluta > viejo.Width * 0.5 + tol)
                continue;
            BoundingBoxXYZ caja = viejo.get_BoundingBox(null);
            if (caja == null || caja.Max.Z <= zBase || caja.Min.Z >= zTop)
                continue;
            // Resolver el lado solo después de encontrar una pared seleccionada
            // que coincida; los demás bordes del Room no generan errores de orientación.
            if (interior == null)
                interior = ObtenerInteriorVerificadoParaZocalo(room, boundary);
            double distanciaNormal = ProductoPuntoXY(punto - b0, interior);
            double baseCandidata, topCandidato;
            ObtenerRangoVerticalTarrajeo(doc, viejo, out baseCandidata, out topCandidato);
            foreach (double[] previo in intervalos)
            {
                if (Math.Min(fin, previo[1]) - Math.Max(inicio, previo[0]) > tol)
                {
                    bool solapeVertical = Math.Min(Math.Min(zTop, topCandidato), previo[3]) -
                        Math.Max(Math.Max(zBase, baseCandidata), previo[2]) > tol;
                    if (solapeVertical)
                        throw new InvalidOperationException("Hay varios muros seleccionados superpuestos en el mismo tramo. Resuelva esa duplicidad antes de reemplazar.");
                    if (Math.Abs(inicio - previo[0]) > 1e-7 || Math.Abs(fin - previo[1]) > 1e-7 ||
                        Math.Abs((distanciaNormal - viejo.Width * 0.5) - previo[4]) > 1e-7)
                        throw new InvalidOperationException("Hay paños a distintas alturas con recorridos diferentes. Este tramo necesita un recorte por perfiles y se conservó sin modificar.");
                }
            }
            ValidarTarrajeoRectangularReemplazable(doc, viejo);
            candidatos.Add(viejo);
            intervalos.Add(new double[] { inicio, fin, Math.Max(zBase, baseCandidata), Math.Min(zTop, topCandidato), distanciaNormal - viejo.Width * 0.5 });
        }
        // Los demás bordes del Room no forman parte de la selección manual.
        if (candidatos.Count == 0)
            return new List<Wall>();

        List<Wall> nuevos = new List<Wall>();
        List<EstadoZocaloExteriorMYG> estadosZocalos = new List<EstadoZocaloExteriorMYG>();
        HashSet<string> pañosNuevosYaCreados = new HashSet<string>();
        List<ElementId> originalesModificados = new List<ElementId>();
        List<EstadoRestoTarrajeoMYG> estadosNuevos = new List<EstadoRestoTarrajeoMYG>();
        using (SubTransaction reemplazo = new SubTransaction(doc))
        {
            reemplazo.Start();
            try
            {
                foreach (Wall viejo in candidatos)
                {
                    ElementId idOriginal = viejo.Id;
                    ElementId tipoOriginal = viejo.GetTypeId();
                    Line eje = ((LocationCurve)viejo.Location).Curve as Line;
                    XYZ a = eje.GetEndPoint(0);
                    XYZ dir = NormalizarXY(eje.GetEndPoint(1) - a);
                    double longitud = DistanciaXY(a, eje.GetEndPoint(1));
                    double inicio = Math.Max(0.0, Math.Min(
                        ProductoPuntoXY(b0 - a, dir), ProductoPuntoXY(b1 - a, dir)));
                    double fin = Math.Min(longitud, Math.Max(
                        ProductoPuntoXY(b0 - a, dir), ProductoPuntoXY(b1 - a, dir)));
                    double zOriginalBase, zOriginalTop;
                    ObtenerRangoVerticalTarrajeo(doc, viejo, out zOriginalBase, out zOriginalTop);
                    List<FragmentoTarrajeoMYG> restos = PlanificarRestosTarrajeo(
                        longitud, zOriginalBase, zOriginalTop, inicio, fin, zBase, zTop,
                        1e-7, doc.Application.ShortCurveTolerance * 1.01);

                    // Mantener el ID original en la parte superior cuando existe.
                    restos.Sort((x, y) =>
                    {
                        int porSuperior = y.ZSuperior.CompareTo(x.ZSuperior);
                        return porSuperior != 0 ? porSuperior : y.ZBase.CompareTo(x.ZBase);
                    });
                    if (restos.Count > 1 && JoinGeometryUtils.GetJoinedElements(doc, viejo).Count > 0)
                        throw new InvalidOperationException("Este recorte necesita copiar un tarrajeo con uniones geométricas existentes. Se conservó el paño para no perder sus cortes.");

                    // Conservar el soporte: la cara posterior del nuevo acabado
                    // ocupa la misma cara posterior del tarrajeo anterior.
                    XYZ inicioEje = a + dir.Multiply(inicio);
                    XYZ finEje = a + dir.Multiply(fin);
                    if (dir.DotProduct(dirBoundary) < 0.0)
                    {
                        XYZ intercambio = inicioEje; inicioEje = finEje; finEje = intercambio;
                    }
                    double centroDesdeBoundary = ProductoPuntoXY(a - b0, interior);
                    double centroNuevo = CalcularCentroZocaloExterior(
                        centroDesdeBoundary, viejo.Width, tipoNuevo.Width, MetrosAPies(0.001));
                    // El frente del zócalo queda fuera del Room; su cara posterior
                    // apoya en la cara del tarrajeo seleccionado que da al ladrillo.
                    double desplazamientoApoyo = centroNuevo - tipoNuevo.Width * 0.5 - centroDesdeBoundary;
                    XYZ caraApoyo = interior.Multiply(desplazamientoApoyo);
                    Line boundaryApoyo = Line.CreateBound(
                        new XYZ(inicioEje.X + caraApoyo.X, inicioEje.Y + caraApoyo.Y, zBase),
                        new XYZ(finEje.X + caraApoyo.X, finEje.Y + caraApoyo.Y, zBase));
                    // Los paños sobre/bajo un vano pueden compartir el mismo
                    // recorrido. Crear el acabado nuevo una sola vez, con sus vanos.
                    if (pañosNuevosYaCreados.Add(ObtenerClaveCurvaXY(boundaryApoyo)))
                    {
                        Wall anfitrionBoundary = tramo.MuroBoundary != null && tramo.MuroBoundary.IsValidObject
                            ? tramo.MuroBoundary : null;
                        List<HuecoMuroRoomMYG> huecos = ObtenerHuecosPuertasYHuecosEnBoundary(
                            doc, anfitrionBoundary, boundaryApoyo, zBase);
                        int integrados;
                        List<Wall> creados = CrearMurosDesdeBoundaryHaciaAdentro(
                            doc, boundaryApoyo, tipoNuevo, nivel, altura, desfase, room,
                            huecos, out integrados, interior);
                        if (creados == null || creados.Count == 0 ||
                            (huecos != null && huecos.Count > 0 && integrados == 0))
                            throw new InvalidOperationException("No se pudo crear el acabado nuevo conservando los vanos. Se revirtió el tramo.");
                        DesignOption opcionOriginal = viejo.DesignOption;
                        foreach (Wall creado in creados)
                        {
                            DesignOption opcionNueva = creado.DesignOption;
                            if ((opcionOriginal == null) != (opcionNueva == null) ||
                                (opcionOriginal != null && opcionOriginal.Id != opcionNueva.Id))
                                throw new InvalidOperationException("La vista activa no permite crear el zócalo en la misma opción del Room. Se revirtió el reemplazo.");
                            if (creado.CreatedPhaseId != faseRoomId)
                                creado.CreatedPhaseId = faseRoomId;
                            if (creado.CreatedPhaseId != faseRoomId)
                                throw new InvalidOperationException("No se pudo asignar al zócalo la fase válida del Room.");
                            VerificarZocaloExterior(doc, creado, boundary, interior);
                            estadosZocalos.Add(new EstadoZocaloExteriorMYG()
                            {
                                Id = creado.Id, Boundary = boundary, Interior = interior
                            });
                        }
                        nuevos.AddRange(creados);
                        huecosIntegrados += integrados;

                    }

                    // Copiar antes de recortar el original para conservar tipo y
                    // parámetros de los restos. El original retiene un resto si existe.
                    List<Wall> murosRestantes = new List<Wall>();
                    for (int i = 0; i < restos.Count; i++)
                    {
                        if (i == 0)
                            murosRestantes.Add(viejo);
                        else
                        {
                            Wall copia = null;
                            foreach (ElementId idCopia in ElementTransformUtils.CopyElement(doc, viejo.Id, XYZ.Zero))
                            {
                                Wall candidata = doc.GetElement(idCopia) as Wall;
                                if (candidata != null)
                                {
                                    if (copia != null)
                                        throw new InvalidOperationException("La copia del tarrajeo devolvió más de un muro.");
                                    copia = candidata;
                                }
                            }
                            if (copia == null)
                                throw new InvalidOperationException("No se pudo conservar un resto del tarrajeo.");
                            if (copia.CreatedPhaseId != viejo.CreatedPhaseId || copia.DemolishedPhaseId != viejo.DemolishedPhaseId)
                                throw new InvalidOperationException("La copia no conservó las fases del tarrajeo original.");
                            SetearParametroInstancia(copia, "GEN_ID Elemento", copia.Id.Value.ToString());
                            murosRestantes.Add(copia);
                        }
                    }
                    for (int i = 0; i < restos.Count; i++)
                    {
                        FragmentoTarrajeoMYG f = restos[i];
                        Line ejeResto = Line.CreateBound(a + dir.Multiply(f.Inicio), a + dir.Multiply(f.Fin));
                        AjustarRestoTarrajeo(doc, murosRestantes[i], ejeResto, f.ZBase, f.ZSuperior);
                        EstadoRestoTarrajeoMYG estado = new EstadoRestoTarrajeoMYG()
                        {
                            Id = murosRestantes[i].Id, Eje = ejeResto,
                            ZBase = f.ZBase, ZSuperior = f.ZSuperior, Tipo = tipoOriginal
                        };
                        VerificarRestoTarrajeo(doc, estado);
                        estadosNuevos.Add(estado);
                    }
                    if (restos.Count == 0)
                    {
                        // Evitar borrar anotaciones u otros elementos dependientes
                        // cuando desaparece todo el paño del acabado original.
                        foreach (ElementId dependiente in viejo.GetDependentElements(null))
                        {
                            if (dependiente != viejo.Id)
                                throw new InvalidOperationException("El paño completo tiene elementos dependientes. No se eliminó; retire o gestione sus dependencias antes de reemplazar.");
                        }
                        ICollection<ElementId> eliminados = doc.Delete(idOriginal);
                        foreach (ElementId eliminado in eliminados)
                        {
                            if (eliminado != idOriginal)
                                throw new InvalidOperationException("Eliminar el tarrajeo afectaría otros elementos. Se revirtió el tramo.");
                        }
                    }
                    originalesModificados.Add(idOriginal);
                    pañosReemplazados++;
                }
                doc.Regenerate();
                VerificarAlturasMurosDesdeRooms(doc, nuevos, zBase, altura);
                if (reemplazo.Commit() != TransactionStatus.Committed)
                    throw new InvalidOperationException("Revit no confirmó el reemplazo del tarrajeo.");
            }
            catch
            {
                if (reemplazo.GetStatus() == TransactionStatus.Started)
                    reemplazo.RollBack();
                throw;
            }
        }
        // Actualizar el seguimiento únicamente después de confirmar el tramo.
        foreach (ElementId id in originalesModificados)
        {
            tarrajeosActivos.Remove(id);
            restosVerificables.Remove(id.Value);
        }
        foreach (EstadoRestoTarrajeoMYG estado in estadosNuevos)
        {
            tarrajeosActivos.Add(estado.Id);
            restosVerificables[estado.Id.Value] = estado;
        }
        foreach (EstadoZocaloExteriorMYG estado in estadosZocalos)
            zocalosVerificables[estado.Id.Value] = estado;
        return nuevos;
    }

    private void ValidarTarrajeoRectangularReemplazable(Document doc, Wall muro)
    {
        WallType tipo = doc.GetElement(muro.GetTypeId()) as WallType;
        Parameter estructural = muro.get_Parameter(BuiltInParameter.WALL_STRUCTURAL_SIGNIFICANT);
        if (tipo == null || tipo.Kind != WallKind.Basic || estructural == null || estructural.AsInteger() != 0)
            throw new InvalidOperationException("El muro seleccionado debe ser un muro básico de acabado no estructural.");
        if (muro.Pinned || muro.GroupId != ElementId.InvalidElementId || muro.IsStackedWallMember)
            throw new InvalidOperationException("El tarrajeo está fijado, agrupado o pertenece a un muro apilado; no se modificó.");
        if (muro.SketchId != ElementId.InvalidElementId)
            throw new InvalidOperationException("El tarrajeo tiene un perfil editado. No se recortó para evitar perder su boceto.");
        if (muro.FindInserts(true, true, true, true).Count > 0 ||
            muro.GetDependentElements(new ElementClassFilter(typeof(FamilyInstance))).Count > 0)
            throw new InvalidOperationException("El tarrajeo aloja puertas, ventanas, huecos u otros insertos. Se conservó completo.");
        Line eje = ((LocationCurve)muro.Location).Curve as Line;
        if (eje == null || Math.Abs(eje.GetEndPoint(1).Z - eje.GetEndPoint(0).Z) > 1e-7)
            throw new InvalidOperationException("El tarrajeo debe ser recto y horizontal en planta.");
        double zBase, zTop;
        ObtenerRangoVerticalTarrajeo(doc, muro, out zBase, out zTop);
        BoundingBoxXYZ caja = muro.get_BoundingBox(null);
        double tolerancia = MetrosAPies(0.001);
        if (caja == null || Math.Abs(caja.Min.Z - zBase) > tolerancia || Math.Abs(caja.Max.Z - zTop) > tolerancia)
            throw new InvalidOperationException("El tarrajeo está adjunto o tiene geometría vertical especial; se conservó sin recortar.");
        // Un muro inclinado puede tener el mismo rango Z. Sus vértices deben
        // permanecer dentro del espesor vertical esperado alrededor de su eje.
        XYZ direccion = NormalizarXY(eje.GetEndPoint(1) - eje.GetEndPoint(0));
        XYZ normal = new XYZ(-direccion.Y, direccion.X, 0.0);
        List<XYZ> puntos = ObtenerPuntosDeSolidosElemento(muro);
        if (puntos == null || puntos.Count < 8)
            throw new InvalidOperationException("No se pudo verificar la geometría del tarrajeo.");
        foreach (XYZ p in puntos)
        {
            if (Math.Abs(ProductoPuntoXY(p - eje.GetEndPoint(0), normal)) > muro.Width * 0.5 + tolerancia)
                throw new InvalidOperationException("El tarrajeo tiene inclinación, barridos o una sección especial; no se modificó.");
        }
        if (JoinGeometryUtils.GetJoinedElements(doc, muro).Count == 0)
        {
            Options opciones = new Options() { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false };
            double volumenReal = VolumenGeometriaTarrajeo(muro.get_Geometry(opciones));
            double volumenEsperado = eje.Length * muro.Width * (zTop - zBase);
            if (Math.Abs(volumenReal - volumenEsperado) > Math.Max(1e-7, volumenEsperado * 0.0001))
                throw new InvalidOperationException("La geometría del tarrajeo no es un paño rectangular completo. Se conservó sin recortar.");
        }
    }

    private double VolumenGeometriaTarrajeo(GeometryElement geometria)
    {
        double volumen = 0.0;
        if (geometria == null)
            return volumen;
        foreach (GeometryObject objeto in geometria)
        {
            Solid solido = objeto as Solid;
            if (solido != null && solido.Volume > 0.0)
                volumen += solido.Volume;
            GeometryInstance instancia = objeto as GeometryInstance;
            if (instancia != null)
                volumen += VolumenGeometriaTarrajeo(instancia.GetInstanceGeometry());
        }
        return volumen;
    }

    private void ObtenerRangoVerticalTarrajeo(Document doc, Wall muro, out double zBase, out double zTop)
    {
        Parameter baseNivel = muro.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT);
        Parameter baseOffset = muro.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET);
        Parameter superiorNivel = muro.get_Parameter(BuiltInParameter.WALL_HEIGHT_TYPE);
        Parameter superiorOffset = muro.get_Parameter(BuiltInParameter.WALL_TOP_OFFSET);
        Parameter altura = muro.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM);
        Level nivelBase = baseNivel != null ? doc.GetElement(baseNivel.AsElementId()) as Level : null;
        Level nivelTop = superiorNivel != null ? doc.GetElement(superiorNivel.AsElementId()) as Level : null;
        if (nivelBase == null || baseOffset == null || altura == null ||
            (nivelTop != null && superiorOffset == null))
            throw new InvalidOperationException("No se pudieron leer las restricciones del tarrajeo.");
        zBase = nivelBase.ProjectElevation + baseOffset.AsDouble();
        zTop = nivelTop != null ? nivelTop.ProjectElevation + superiorOffset.AsDouble() : zBase + altura.AsDouble();
        if (double.IsNaN(zBase) || double.IsInfinity(zBase) || double.IsNaN(zTop) || double.IsInfinity(zTop) || zTop <= zBase)
            throw new InvalidOperationException("El tarrajeo tiene alturas inválidas.");
    }

    private void AjustarRestoTarrajeo(Document doc, Wall muro, Line eje, double zBase, double zTop)
    {
        BloquearUnionAutomaticaExtremos(muro);
        Parameter baseNivel = muro.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT);
        Level nivel = baseNivel != null ? doc.GetElement(baseNivel.AsElementId()) as Level : null;
        Parameter topNivel = muro.get_Parameter(BuiltInParameter.WALL_HEIGHT_TYPE);
        Parameter offset = muro.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET);
        Parameter altura = muro.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM);
        if (nivel == null || topNivel == null || offset == null || altura == null ||
            topNivel.IsReadOnly || offset.IsReadOnly)
            throw new InvalidOperationException("Las restricciones del tarrajeo no permiten conservar sus restos.");
        topNivel.Set(ElementId.InvalidElementId);
        if (altura.IsReadOnly)
            throw new InvalidOperationException("No se puede ajustar la altura del tarrajeo restante.");
        ((LocationCurve)muro.Location).Curve = eje;
        offset.Set(zBase - nivel.ProjectElevation);
        altura.Set(zTop - zBase);
        doc.Regenerate();
    }

    private void VerificarRestoTarrajeo(Document doc, EstadoRestoTarrajeoMYG estado)
    {
        Wall muro = doc.GetElement(estado.Id) as Wall;
        if (muro == null || !muro.IsValidObject || muro.GetTypeId() != estado.Tipo)
            throw new InvalidOperationException("No se conservó el tipo del tarrajeo restante.");
        double zBase, zTop;
        ObtenerRangoVerticalTarrajeo(doc, muro, out zBase, out zTop);
        double tolerancia = MetrosAPies(0.001);
        if (Math.Abs(zBase - estado.ZBase) > tolerancia || Math.Abs(zTop - estado.ZSuperior) > tolerancia)
            throw new InvalidOperationException("Un resto del tarrajeo cambió de altura. No se guardó el lote.");
        BoundingBoxXYZ caja = muro.get_BoundingBox(null);
        if (caja == null || Math.Abs(caja.Min.Z - estado.ZBase) > tolerancia ||
            Math.Abs(caja.Max.Z - estado.ZSuperior) > tolerancia)
            throw new InvalidOperationException("La geometría real de un resto no coincide con la altura que debe conservarse. No se guardó el lote.");
        Line eje = ((LocationCurve)muro.Location).Curve as Line;
        if (eje == null || DistanciaXY(eje.GetEndPoint(0), estado.Eje.GetEndPoint(0)) > tolerancia ||
            DistanciaXY(eje.GetEndPoint(1), estado.Eje.GetEndPoint(1)) > tolerancia)
            throw new InvalidOperationException("Un resto del tarrajeo cambió de recorrido. No se guardó el lote.");
    }

    private static double ProductoPuntoXY(XYZ a, XYZ b)
    {
        return a.X * b.X + a.Y * b.Y;
    }

    // Resta una franja rectangular del alzado de un tarrajeo recto.
    // Los cuatro restos posibles no se solapan: laterales completos y, entre
    // ellos, la parte inferior y superior. No se descartan restos modelables.
    private static List<FragmentoTarrajeoMYG> PlanificarRestosTarrajeo(
        double longitud,
        double baseOriginal,
        double superiorOriginal,
        double inicioReemplazo,
        double finReemplazo,
        double baseReemplazo,
        double superiorReemplazo,
        double toleranciaNumerica,
        double minimoModelable)
    {
        double[] valores = { longitud, baseOriginal, superiorOriginal,
            inicioReemplazo, finReemplazo, baseReemplazo, superiorReemplazo,
            toleranciaNumerica, minimoModelable,
            superiorOriginal - baseOriginal, finReemplazo - inicioReemplazo,
            superiorReemplazo - baseReemplazo };
        foreach (double valor in valores)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                throw new ArgumentException("Las medidas del reemplazo deben ser finitas.");
        }
        if (toleranciaNumerica <= 0.0 || minimoModelable <= toleranciaNumerica)
            throw new ArgumentException("Las tolerancias del reemplazo no son válidas.");
        if (longitud <= toleranciaNumerica ||
            superiorOriginal - baseOriginal <= toleranciaNumerica)
            throw new ArgumentException("El tarrajeo original debe tener longitud y altura positivas.");
        if (finReemplazo - inicioReemplazo <= toleranciaNumerica ||
            superiorReemplazo - baseReemplazo <= toleranciaNumerica)
            throw new ArgumentException("El intervalo de reemplazo debe tener longitud y altura positivas.");

        double inicio = Math.Max(0.0, inicioReemplazo);
        double fin = Math.Min(longitud, finReemplazo);
        double inferior = Math.Max(baseOriginal, baseReemplazo);
        double superior = Math.Min(superiorOriginal, superiorReemplazo);
        if (fin - inicio <= toleranciaNumerica || superior - inferior <= toleranciaNumerica)
            throw new InvalidOperationException("La franja solicitada no intersecta el tarrajeo existente.");

        // Sólo se consideran coincidentes las diferencias dentro de la
        // tolerancia numérica. Una franja real mayor que ella no se elimina.
        if (inicio <= toleranciaNumerica) inicio = 0.0;
        if (longitud - fin <= toleranciaNumerica) fin = longitud;
        if (inferior - baseOriginal <= toleranciaNumerica) inferior = baseOriginal;
        if (superiorOriginal - superior <= toleranciaNumerica) superior = superiorOriginal;

        List<FragmentoTarrajeoMYG> restos = new List<FragmentoTarrajeoMYG>();
        Action<double, double, double, double> agregar = (t0, t1, z0, z1) =>
        {
            double ancho = t1 - t0;
            double alto = z1 - z0;
            if (ancho <= toleranciaNumerica || alto <= toleranciaNumerica)
                return;
            if (ancho < minimoModelable || alto < minimoModelable)
                throw new InvalidOperationException(
                    "El reemplazo dejaría un resto de tarrajeo demasiado pequeño para modelar. No se recortó el muro original.");
            restos.Add(new FragmentoTarrajeoMYG()
            {
                Inicio = t0,
                Fin = t1,
                ZBase = z0,
                ZSuperior = z1
            });
        };

        agregar(0.0, inicio, baseOriginal, superiorOriginal);
        agregar(fin, longitud, baseOriginal, superiorOriginal);
        agregar(inicio, fin, baseOriginal, inferior);
        agregar(inicio, fin, superior, superiorOriginal);
        return restos;
    }

    private class FragmentoTarrajeoMYG
    {
        public double Inicio { get; set; }
        public double Fin { get; set; }
        public double ZBase { get; set; }
        public double ZSuperior { get; set; }
    }

    private void VerificarAlturasMurosDesdeRooms(
        Document doc,
        List<Wall> muros,
        double zBaseSolicitada,
        double alturaSolicitada)
    {
        double zTopSolicitada = zBaseSolicitada + alturaSolicitada;
        double tolerancia = MetrosAPies(0.001);

        foreach (Wall muro in muros)
        {
            if (muro == null)
                throw new InvalidOperationException("No se pudo verificar un muro creado desde Rooms.");

            Parameter parametroNivel = muro.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT);
            Parameter parametroDesfase = muro.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET);
            Parameter parametroAltura = muro.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM);
            Level nivelReal = parametroNivel != null
                ? doc.GetElement(parametroNivel.AsElementId()) as Level
                : null;

            if (nivelReal == null || parametroDesfase == null || parametroAltura == null)
                throw new InvalidOperationException("No se pudieron leer las restricciones de un muro creado.");

            double zBaseReal = nivelReal.ProjectElevation + parametroDesfase.AsDouble();
            double zTopReal = zBaseReal + parametroAltura.AsDouble();

            // Los vanos generan piezas de menor altura o con base elevada.
            // Cada pieza debe quedar dentro del intervalo solicitado, no
            // tener a la fuerza la misma base/altura que el muro completo.
            if (!RangoMuroDentroDeAlturasSolicitadas(
                zBaseReal, zTopReal, zBaseSolicitada, zTopSolicitada, tolerancia))
            {
                throw new InvalidOperationException(
                    "Un muro quedó fuera de la altura solicitada. " +
                    "Rango solicitado (pies): " + zBaseSolicitada.ToString("G17") +
                    " a " + zTopSolicitada.ToString("G17") +
                    "; rango real: " + zBaseReal.ToString("G17") +
                    " a " + zTopReal.ToString("G17") +
                    ". El lote no se guardó.");
            }
        }
    }

    private static bool RangoMuroDentroDeAlturasSolicitadas(
        double zBaseReal,
        double zTopReal,
        double zBaseSolicitada,
        double zTopSolicitada,
        double tolerancia)
    {
        foreach (double valor in new double[]
        {
            zBaseReal, zTopReal, zBaseSolicitada, zTopSolicitada, tolerancia
        })
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                return false;
        }

        return tolerancia > 0.0 && zTopReal > zBaseReal &&
            zTopSolicitada > zBaseSolicitada &&
            zBaseReal >= zBaseSolicitada - tolerancia &&
            zTopReal <= zTopSolicitada + tolerancia;
    }

    // =========================================================
    // CREAR MURO
    // =========================================================

    private List<Wall> CrearMurosDesdeBoundaryHaciaAdentro(
        Document doc,
        Curve curvaBoundary,
        WallType wallType,
        Level nivel,
        double alturaFeet,
        double baseOffsetFeet,
        Room room,
        List<HuecoMuroRoomMYG> huecos,
        out int huecosIntegradosEnBoceto,
        XYZ direccionInteriorForzada = null)
    {
        huecosIntegradosEnBoceto = 0;

        List<Wall> murosResultado = new List<Wall>();

        if (doc == null || curvaBoundary == null || wallType == null || nivel == null || room == null)
            return murosResultado;

        double anchoMuro = wallType.Width;

        if (anchoMuro <= 0.0001)
            anchoMuro = MetrosAPies(0.10);

        XYZ direccionInteriorRoom = direccionInteriorForzada ?? ObtenerDireccionHaciaInteriorRoom(
            room,
            curvaBoundary,
            nivel.ProjectElevation + baseOffsetFeet);

        if (direccionInteriorRoom == null || direccionInteriorRoom.GetLength() < 0.0001)
            return murosResultado;

        direccionInteriorRoom = NormalizarXY(direccionInteriorRoom);

        if (direccionInteriorRoom == null)
            return murosResultado;

        // CLAVE:
        // La curva de creación de Revit sigue siendo el eje físico del muro.
        // Por eso el eje se desplaza 1/2 espesor hacia ADENTRO del Room.
        // Resultado: la cara del muro queda sobre el boundary del Room.
        double medioEspesor = anchoMuro / 2.0;

        XYZ desplazamientoCentro = new XYZ(
            direccionInteriorRoom.X * medioEspesor,
            direccionInteriorRoom.Y * medioEspesor,
            0.0);

        Curve curvaCentroMuro = CrearCurvaDesplazada(
            curvaBoundary,
            desplazamientoCentro);

        if (curvaCentroMuro == null)
            return murosResultado;

        Line lineaCentroMuro = curvaCentroMuro as Line;

        // =========================================================
        // PUERTAS / HUECOS: MORDIDA VERTICAL REAL
        // =========================================================
        // Flujo:
        // 1) Se calcula primero el muro a la altura indicada.
        // 2) Si el tramo tiene puertas/huecos, se descuenta el vano en
        //    elevación: no se crea muro dentro del ancho de la puerta cuando
        //    el hueco atraviesa toda la altura del tarrajeo.
        // 3) No se crea ningún elemento Opening / Hueco de muro.
        //
        // Nota técnica:
        // Cuando la mordida toca la base y también supera la altura del
        // tarrajeo, el resultado geométrico queda en dos regiones separadas.
        // Revit no acepta eso como un único perfil cerrado de un solo muro,
        // por eso la API lo resuelve como paños de muro separados, pero el
        // resultado visual es la mordida correcta del boceto.
        // =========================================================

        if (lineaCentroMuro != null && huecos != null && huecos.Count > 0)
        {
            int huecosProcesados = 0;

            List<Wall> murosConMordida = CrearMurosSegmentadosPorHuecos(
                doc,
                lineaCentroMuro,
                wallType,
                nivel,
                alturaFeet,
                baseOffsetFeet,
                room,
                direccionInteriorRoom,
                huecos,
                out huecosProcesados);

            if (murosConMordida != null && murosConMordida.Count > 0)
            {
                huecosIntegradosEnBoceto = huecosProcesados;
                return murosConMordida;
            }
        }

        Wall muro = CrearMuroRectangularDesdeCurvaCentro(
            doc,
            curvaCentroMuro,
            wallType,
            nivel,
            alturaFeet,
            baseOffsetFeet,
            room,
            direccionInteriorRoom);

        if (muro != null)
            murosResultado.Add(muro);

        return murosResultado;
    }

    private Wall CrearMuroRectangularDesdeCurvaCentro(
        Document doc,
        Curve curvaCentroMuro,
        WallType wallType,
        Level nivel,
        double alturaFeet,
        double baseOffsetFeet,
        Room room,
        XYZ direccionInteriorRoom)
    {
        if (doc == null || curvaCentroMuro == null || wallType == null || nivel == null)
            return null;

        if (curvaCentroMuro.Length < MetrosAPies(0.01))
            return null;

        Wall muro = null;

        try
        {
            muro = Wall.Create(
                doc,
                curvaCentroMuro,
                wallType.Id,
                nivel.Id,
                alturaFeet,
                baseOffsetFeet,
                false,
                false);
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
            muro = null;
        }

        if (muro == null)
            return null;

        try
        {
            doc.Regenerate();
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }

        AplicarLineaUbicacionCaraAcabadoInterior(muro);

        try
        {
            doc.Regenerate();
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }

        CorregirOrientacionParaCaraInteriorEnBoundary(
            doc,
            muro,
            direccionInteriorRoom);

        AplicarLineaUbicacionCaraAcabadoInterior(muro);

        AplicarParametrosMuro(
            muro,
            alturaFeet,
            baseOffsetFeet,
            room);

        // Se bloquea para que no se proyecte ni se enganche con muros existentes.
        BloquearUnionAutomaticaExtremos(muro);

        return muro;
    }

    private Wall CrearMuroDesdePerfilBoceto(
        Document doc,
        IList<Curve> perfilBoceto,
        WallType wallType,
        Level nivel,
        double alturaFeet,
        double baseOffsetFeet,
        Room room,
        XYZ direccionInteriorRoom)
    {
        if (doc == null || perfilBoceto == null || perfilBoceto.Count < 4 || wallType == null || nivel == null)
            return null;

        XYZ normalPerfil = direccionInteriorRoom;

        if (normalPerfil != null)
        {
            normalPerfil = new XYZ(
                -normalPerfil.X,
                -normalPerfil.Y,
                0.0);
        }

        Wall muro = null;

        try
        {
            muro = Wall.Create(
                doc,
                perfilBoceto,
                wallType.Id,
                nivel.Id,
                false,
                normalPerfil);
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
            muro = null;
        }

        if (muro == null)
            return null;

        try
        {
            doc.Regenerate();
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }

        // En muros creados por perfil, si luego hacemos Flip() el boceto puede quedar
        // invertido respecto al vano detectado. Por eso aquí se invierte la normal del perfil
        // al crear el muro y YA NO se vuelve a corregir con Flip.
        AplicarLineaUbicacionCaraAcabadoInterior(muro);

        AplicarParametrosBasicosMuroPerfil(
            muro,
            alturaFeet,
            baseOffsetFeet,
            room);

        BloquearUnionAutomaticaExtremos(muro);

        return muro;
    }

    private void AplicarParametrosBasicosMuroPerfil(
        Wall muro,
        double alturaFeet,
        double baseOffsetFeet,
        Room room)
    {
        if (muro == null)
            return;

        try
        {
            Parameter pRoomBounding = muro.get_Parameter(BuiltInParameter.WALL_ATTR_ROOM_BOUNDING);

            if (pRoomBounding != null && !pRoomBounding.IsReadOnly)
                pRoomBounding.Set(1);
        }
        catch
        {
        }

        try
        {
            Parameter pComentarios = muro.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

            if (pComentarios != null && !pComentarios.IsReadOnly)
                pComentarios.Set("Creado desde Room: " + ObtenerNombreRoom(room));
        }
        catch
        {
        }

        try
        {
            Parameter pBaseOffset = muro.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET);

            if (pBaseOffset != null && !pBaseOffset.IsReadOnly)
                pBaseOffset.Set(baseOffsetFeet);
        }
        catch
        {
        }

        try
        {
            Parameter pAltura = muro.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM);

            if (pAltura != null && !pAltura.IsReadOnly)
                pAltura.Set(alturaFeet);
        }
        catch
        {
        }

        AplicarParametrosGestionElemento(
            muro,
            room);
    }

    private List<Wall> CrearMurosSegmentadosPorHuecos(
        Document doc,
        Line lineaCentroMuro,
        WallType wallType,
        Level nivel,
        double alturaFeet,
        double baseOffsetFeet,
        Room room,
        XYZ direccionInteriorRoom,
        List<HuecoMuroRoomMYG> huecosOriginales,
        out int huecosProcesados)
    {
        huecosProcesados = 0;

        List<Wall> muros = new List<Wall>();

        if (doc == null || lineaCentroMuro == null || wallType == null || nivel == null)
            return muros;

        if (huecosOriginales == null || huecosOriginales.Count == 0)
            return muros;

        XYZ p0 = lineaCentroMuro.GetEndPoint(0);
        XYZ p1 = lineaCentroMuro.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return muros;

        dir = dir.Normalize();

        double longitud = DistanciaXY(p0, p1);

        if (longitud < MetrosAPies(0.05))
            return muros;

        double zBaseMuro = nivel.ProjectElevation + baseOffsetFeet;
        double zSuperiorMuro = zBaseMuro + alturaFeet;

        List<HuecoMuroRoomMYG> huecos = PrepararHuecosParaSegmentacion(
            huecosOriginales,
            longitud,
            zBaseMuro,
            zSuperiorMuro);

        if (huecos == null || huecos.Count == 0)
            return muros;

        huecos = UnirHuecosSolapadosParaSegmentacion(
            huecos,
            longitud,
            zBaseMuro,
            zSuperiorMuro);

        if (huecos == null || huecos.Count == 0)
            return muros;

        huecos.Sort(delegate (HuecoMuroRoomMYG a, HuecoMuroRoomMYG b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            return a.Inicio.CompareTo(b.Inicio);
        });

        double tol = MetrosAPies(0.002);
        double largoMinimo = MetrosAPies(0.02);
        double altoMinimo = MetrosAPies(0.02);
        double posicionActual = 0.0;

        foreach (HuecoMuroRoomMYG hueco in huecos)
        {
            if (hueco == null)
                continue;

            double inicio = Math.Max(0.0, hueco.Inicio);
            double fin = Math.Min(longitud, hueco.Fin);

            if (fin - inicio < largoMinimo)
                continue;

            double zInfHueco = Math.Max(zBaseMuro, hueco.ZInferior);
            double zSupHueco = Math.Min(zSuperiorMuro, hueco.ZSuperior);

            if (zSupHueco - zInfHueco < altoMinimo)
                continue;

            // 1) Paño completo antes del hueco.
            if (inicio > posicionActual + largoMinimo)
            {
                Wall muroAntes = CrearMuroRectangularDesdeIntervalo(
                    doc,
                    p0,
                    dir,
                    posicionActual,
                    inicio,
                    zBaseMuro,
                    zSuperiorMuro,
                    wallType,
                    nivel,
                    room,
                    direccionInteriorRoom);

                if (muroAntes != null)
                    muros.Add(muroAntes);
            }

            // 2) Paño bajo el hueco, solo para ventanas o huecos con antepecho.
            // Para puertas, zInfHueco queda igual a zBaseMuro y esta pieza no se crea.
            if (zInfHueco > zBaseMuro + altoMinimo)
            {
                Wall muroBajo = CrearMuroRectangularDesdeIntervalo(
                    doc,
                    p0,
                    dir,
                    inicio,
                    fin,
                    zBaseMuro,
                    zInfHueco,
                    wallType,
                    nivel,
                    room,
                    direccionInteriorRoom);

                if (muroBajo != null)
                    muros.Add(muroBajo);
            }

            // 3) Paño sobre el hueco, solo si realmente queda altura.
            // Si el tarrajeo mide 1.00 m y la puerta llega a 2.10 m, NO se crea franja falsa.
            if (zSuperiorMuro > zSupHueco + altoMinimo)
            {
                Wall muroSobre = CrearMuroRectangularDesdeIntervalo(
                    doc,
                    p0,
                    dir,
                    inicio,
                    fin,
                    zSupHueco,
                    zSuperiorMuro,
                    wallType,
                    nivel,
                    room,
                    direccionInteriorRoom);

                if (muroSobre != null)
                    muros.Add(muroSobre);
            }

            posicionActual = fin;
            huecosProcesados++;
        }

        // 4) Paño completo después del último hueco.
        if (posicionActual < longitud - largoMinimo)
        {
            Wall muroDespues = CrearMuroRectangularDesdeIntervalo(
                doc,
                p0,
                dir,
                posicionActual,
                longitud,
                zBaseMuro,
                zSuperiorMuro,
                wallType,
                nivel,
                room,
                direccionInteriorRoom);

            if (muroDespues != null)
                muros.Add(muroDespues);
        }

        return muros;
    }

    private Wall CrearMuroRectangularDesdeIntervalo(
        Document doc,
        XYZ p0,
        XYZ dir,
        double inicio,
        double fin,
        double zInferior,
        double zSuperior,
        WallType wallType,
        Level nivel,
        Room room,
        XYZ direccionInteriorRoom)
    {
        if (doc == null || p0 == null || dir == null || wallType == null || nivel == null)
            return null;

        if (fin <= inicio + MetrosAPies(0.01))
            return null;

        double altura = zSuperior - zInferior;

        if (altura <= MetrosAPies(0.01))
            return null;

        XYZ a = new XYZ(
            p0.X + dir.X * inicio,
            p0.Y + dir.Y * inicio,
            zInferior);

        XYZ b = new XYZ(
            p0.X + dir.X * fin,
            p0.Y + dir.Y * fin,
            zInferior);

        if (a.DistanceTo(b) < MetrosAPies(0.01))
            return null;

        Line linea = null;

        try
        {
            linea = Line.CreateBound(a, b);
        }
        catch
        {
            linea = null;
        }

        if (linea == null)
            return null;

        double offsetBase = zInferior - nivel.ProjectElevation;

        return CrearMuroRectangularDesdeCurvaCentro(
            doc,
            linea,
            wallType,
            nivel,
            altura,
            offsetBase,
            room,
            direccionInteriorRoom);
    }

    private List<HuecoMuroRoomMYG> PrepararHuecosParaSegmentacion(
        List<HuecoMuroRoomMYG> huecosOriginales,
        double longitud,
        double zBaseMuro,
        double zSuperiorMuro)
    {
        List<HuecoMuroRoomMYG> preparados = new List<HuecoMuroRoomMYG>();

        if (huecosOriginales == null)
            return preparados;

        double toleranciaBase = MetrosAPies(0.01);

        foreach (HuecoMuroRoomMYG h in huecosOriginales)
        {
            if (h == null)
                continue;

            double inicio = Math.Max(0.0, h.Inicio);
            double fin = Math.Min(longitud, h.Fin);

            if (fin - inicio < MetrosAPies(0.03))
                continue;

            double zInf = Math.Max(zBaseMuro, h.ZInferior);
            double zSup = Math.Min(zSuperiorMuro, h.ZSuperior);

            // Solo si el arranque del hueco está prácticamente pegado a la base se colapsa hasta el piso.
            // Si existe una franja inferior real (umbral/zócalo), esta debe mantenerse como muro.
            if (zInf <= zBaseMuro + toleranciaBase)
                zInf = zBaseMuro;

            if (zSup - zInf < MetrosAPies(0.03))
                continue;

            HuecoMuroRoomMYG nuevo = new HuecoMuroRoomMYG();
            nuevo.Inicio = inicio;
            nuevo.Fin = fin;
            nuevo.ZInferior = zInf;
            nuevo.ZSuperior = zSup;
            nuevo.ElementoHuecoId = h.ElementoHuecoId;

            preparados.Add(nuevo);
        }

        return preparados;
    }

    private List<HuecoMuroRoomMYG> UnirHuecosSolapadosParaSegmentacion(
        List<HuecoMuroRoomMYG> huecos,
        double longitud,
        double zBaseMuro,
        double zSuperiorMuro)
    {
        List<HuecoMuroRoomMYG> resultado = new List<HuecoMuroRoomMYG>();

        if (huecos == null || huecos.Count == 0)
            return resultado;

        huecos.Sort(delegate (HuecoMuroRoomMYG a, HuecoMuroRoomMYG b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            return a.Inicio.CompareTo(b.Inicio);
        });

        double tol = MetrosAPies(0.005);

        foreach (HuecoMuroRoomMYG h in huecos)
        {
            if (h == null)
                continue;

            double inicio = Math.Max(0.0, h.Inicio);
            double fin = Math.Min(longitud, h.Fin);

            if (fin - inicio < MetrosAPies(0.03))
                continue;

            if (resultado.Count == 0)
            {
                HuecoMuroRoomMYG nuevo = new HuecoMuroRoomMYG();
                nuevo.Inicio = inicio;
                nuevo.Fin = fin;
                nuevo.ZInferior = Math.Max(zBaseMuro, h.ZInferior);
                nuevo.ZSuperior = Math.Min(zSuperiorMuro, h.ZSuperior);
                nuevo.ElementoHuecoId = h.ElementoHuecoId;
                resultado.Add(nuevo);
                continue;
            }

            HuecoMuroRoomMYG ultimo = resultado[resultado.Count - 1];

            if (inicio <= ultimo.Fin + tol)
            {
                if (fin > ultimo.Fin)
                    ultimo.Fin = fin;

                if (h.ZInferior < ultimo.ZInferior)
                    ultimo.ZInferior = h.ZInferior;

                if (h.ZSuperior > ultimo.ZSuperior)
                    ultimo.ZSuperior = h.ZSuperior;
            }
            else
            {
                HuecoMuroRoomMYG nuevo = new HuecoMuroRoomMYG();
                nuevo.Inicio = inicio;
                nuevo.Fin = fin;
                nuevo.ZInferior = Math.Max(zBaseMuro, h.ZInferior);
                nuevo.ZSuperior = Math.Min(zSuperiorMuro, h.ZSuperior);
                nuevo.ElementoHuecoId = h.ElementoHuecoId;
                resultado.Add(nuevo);
            }
        }

        return resultado;
    }


    // =========================================================
    // PERFIL / BOCETO DEL MURO CON PUERTAS Y HUECOS
    // =========================================================

    private IList<Curve> CrearPerfilBocetoMuroConHuecos(
        Line lineaCentroMuro,
        List<HuecoMuroRoomMYG> huecosOriginales,
        double zBaseMuro,
        double alturaMuro,
        out int huecosIntegrados)
    {
        huecosIntegrados = 0;

        List<Curve> perfil = new List<Curve>();

        if (lineaCentroMuro == null)
            return perfil;

        if (huecosOriginales == null || huecosOriginales.Count == 0)
            return perfil;

        XYZ p0 = lineaCentroMuro.GetEndPoint(0);
        XYZ p1 = lineaCentroMuro.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return perfil;

        dir = dir.Normalize();

        double longitud = DistanciaXY(p0, p1);

        if (longitud < MetrosAPies(0.05))
            return perfil;

        double zSuperiorMuro = zBaseMuro + alturaMuro;

        List<HuecoMuroRoomMYG> huecosBase = new List<HuecoMuroRoomMYG>();
        List<HuecoMuroRoomMYG> huecosInteriores = new List<HuecoMuroRoomMYG>();

        PrepararHuecosParaPerfilBoceto(
            huecosOriginales,
            longitud,
            zBaseMuro,
            zSuperiorMuro,
            huecosBase,
            huecosInteriores);

        huecosBase = UnirHuecosSolapados(huecosBase, longitud);
        huecosInteriores = UnirHuecosSolapados(huecosInteriores, longitud);

        if (huecosBase != null)
        {
            huecosBase.Sort(delegate (HuecoMuroRoomMYG a, HuecoMuroRoomMYG b)
            {
                if (a == null && b == null) return 0;
                if (a == null) return -1;
                if (b == null) return 1;
                return a.Inicio.CompareTo(b.Inicio);
            });
        }

        if (huecosInteriores != null)
        {
            huecosInteriores.Sort(delegate (HuecoMuroRoomMYG a, HuecoMuroRoomMYG b)
            {
                if (a == null && b == null) return 0;
                if (a == null) return -1;
                if (b == null) return 1;
                return a.Inicio.CompareTo(b.Inicio);
            });
        }

        if ((huecosBase == null || huecosBase.Count == 0) &&
            (huecosInteriores == null || huecosInteriores.Count == 0))
        {
            return perfil;
        }

        List<XYZ> puntosContorno = new List<XYZ>();

        double tol = MetrosAPies(0.001);
        double alturaMinimaDintel = MetrosAPies(0.02);
        double posicionActual = 0.0;
        bool inicioContornoAgregado = false;

        // =========================================================
        // CONTORNO EXTERIOR
        // =========================================================
        // La versión anterior fallaba cuando el hueco tocaba el inicio o el final
        // del tramo. En ese caso se generaba una línea vertical duplicada y Revit
        // rechazaba el perfil, por eso no se creaba el muro.
        //
        // Esta versión construye la silueta inferior del muro como una polilínea
        // continua. Si el hueco empieza exactamente en el borde del tramo, arranca
        // el contorno en la parte superior del hueco, NO en la base. Así no hay
        // solapes de curvas en el mismo boceto.
        // =========================================================

        if (huecosBase != null && huecosBase.Count > 0)
        {
            foreach (HuecoMuroRoomMYG hueco in huecosBase)
            {
                if (hueco == null)
                    continue;

                double inicio = Math.Max(0.0, hueco.Inicio);
                double fin = Math.Min(longitud, hueco.Fin);
                double zSupHueco = Math.Min(zSuperiorMuro - alturaMinimaDintel, hueco.ZSuperior);

                if (fin - inicio < MetrosAPies(0.03))
                    continue;

                if (zSupHueco - zBaseMuro < MetrosAPies(0.05))
                    continue;

                if (!inicioContornoAgregado)
                {
                    if (inicio <= tol)
                    {
                        // Hueco pegado al inicio del tramo:
                        // se empieza en la cabeza del hueco para evitar duplicar
                        // la arista vertical izquierda.
                        AgregarPuntoPerfil(
                            puntosContorno,
                            PuntoSobreLineaConZ(p0, dir, 0.0, zSupHueco));
                    }
                    else
                    {
                        AgregarPuntoPerfil(
                            puntosContorno,
                            PuntoSobreLineaConZ(p0, dir, 0.0, zBaseMuro));

                        AgregarPuntoPerfil(
                            puntosContorno,
                            PuntoSobreLineaConZ(p0, dir, inicio, zBaseMuro));

                        AgregarPuntoPerfil(
                            puntosContorno,
                            PuntoSobreLineaConZ(p0, dir, inicio, zSupHueco));
                    }

                    inicioContornoAgregado = true;
                }
                else
                {
                    if (inicio > posicionActual + tol)
                    {
                        AgregarPuntoPerfil(
                            puntosContorno,
                            PuntoSobreLineaConZ(p0, dir, inicio, zBaseMuro));
                    }

                    AgregarPuntoPerfil(
                        puntosContorno,
                        PuntoSobreLineaConZ(p0, dir, inicio, zSupHueco));
                }

                AgregarPuntoPerfil(
                    puntosContorno,
                    PuntoSobreLineaConZ(p0, dir, fin, zSupHueco));

                if (fin < longitud - tol)
                {
                    AgregarPuntoPerfil(
                        puntosContorno,
                        PuntoSobreLineaConZ(p0, dir, fin, zBaseMuro));
                }

                posicionActual = fin;
                huecosIntegrados++;
            }
        }

        // Si no hubo huecos desde base, se crea el contorno rectangular normal.
        if (!inicioContornoAgregado)
        {
            AgregarPuntoPerfil(
                puntosContorno,
                PuntoSobreLineaConZ(p0, dir, 0.0, zBaseMuro));

            AgregarPuntoPerfil(
                puntosContorno,
                PuntoSobreLineaConZ(p0, dir, longitud, zBaseMuro));
        }
        else
        {
            // Si el último hueco no llega al final del tramo, se continúa por la base.
            // Si llega al final, NO se baja hasta la base para no duplicar la arista derecha.
            if (posicionActual < longitud - tol)
            {
                AgregarPuntoPerfil(
                    puntosContorno,
                    PuntoSobreLineaConZ(p0, dir, longitud, zBaseMuro));
            }
        }

        AgregarPuntoPerfil(
            puntosContorno,
            PuntoSobreLineaConZ(p0, dir, longitud, zSuperiorMuro));

        AgregarPuntoPerfil(
            puntosContorno,
            PuntoSobreLineaConZ(p0, dir, 0.0, zSuperiorMuro));

        // Cierre del contorno exterior contra el primer punto real.
        if (puntosContorno.Count > 0)
        {
            AgregarPuntoPerfil(
                puntosContorno,
                puntosContorno[0]);
        }

        AgregarCurvasDesdePuntosPerfil(perfil, puntosContorno);

        // =========================================================
        // HUECOS INTERIORES
        // =========================================================
        // Revit suele rechazar perfiles con loops internos en este overload.
        // Para evitar que falle todo el muro, por ahora se integran solo las
        // mordidas que nacen desde la base, que son las puertas.
        // Los huecos interiores no se convierten en elementos Opening; simplemente
        // se omiten para no crear una ventana emergente ni romper el perfil.
        // =========================================================

        return perfil;
    }


    private void PrepararHuecosParaPerfilBoceto(
        List<HuecoMuroRoomMYG> huecosOriginales,
        double longitud,
        double zBaseMuro,
        double zSuperiorMuro,
        List<HuecoMuroRoomMYG> huecosBase,
        List<HuecoMuroRoomMYG> huecosInteriores)
    {
        if (huecosOriginales == null)
            return;

        if (huecosBase == null || huecosInteriores == null)
            return;

        double toleranciaBase = MetrosAPies(0.60);

        foreach (HuecoMuroRoomMYG h in huecosOriginales)
        {
            if (h == null)
                continue;

            double inicio = Math.Max(0.0, h.Inicio);
            double fin = Math.Min(longitud, h.Fin);

            if (fin - inicio < MetrosAPies(0.03))
                continue;

            double zInf = Math.Max(zBaseMuro, h.ZInferior);
            double zSup = Math.Min(zSuperiorMuro, h.ZSuperior);

            if (zSup - zInf < MetrosAPies(0.05))
                continue;

            HuecoMuroRoomMYG nuevo = new HuecoMuroRoomMYG();
            nuevo.Inicio = inicio;
            nuevo.Fin = fin;
            nuevo.ZInferior = zInf;
            nuevo.ZSuperior = zSup;
            nuevo.ElementoHuecoId = h.ElementoHuecoId;

            // Si el hueco está prácticamente desde la base, se vuelve mordida del contorno exterior.
            // Esto sirve para puertas y evita crear "Opening".
            if (zInf <= zBaseMuro + toleranciaBase)
            {
                nuevo.ZInferior = zBaseMuro;
                huecosBase.Add(nuevo);
            }
            else
            {
                // Si el hueco tiene antepecho, queda como loop interno del mismo boceto.
                huecosInteriores.Add(nuevo);
            }
        }
    }

    private XYZ PuntoSobreLineaConZ(
        XYZ p0,
        XYZ dir,
        double distancia,
        double z)
    {
        return new XYZ(
            p0.X + dir.X * distancia,
            p0.Y + dir.Y * distancia,
            z);
    }

    private void AgregarPuntoPerfil(
        List<XYZ> puntos,
        XYZ punto)
    {
        if (puntos == null || punto == null)
            return;

        if (puntos.Count > 0)
        {
            XYZ ultimo = puntos[puntos.Count - 1];

            if (ultimo != null && ultimo.DistanceTo(punto) < 0.0001)
                return;
        }

        puntos.Add(punto);
    }

    private void AgregarCurvasDesdePuntosPerfil(
        List<Curve> perfil,
        List<XYZ> puntos)
    {
        if (perfil == null || puntos == null)
            return;

        if (puntos.Count < 2)
            return;

        for (int i = 0; i < puntos.Count - 1; i++)
        {
            XYZ a = puntos[i];
            XYZ b = puntos[i + 1];

            if (a == null || b == null)
                continue;

            if (a.DistanceTo(b) < 0.0001)
                continue;

            try
            {
                perfil.Add(Line.CreateBound(a, b));
            }
            catch
            {
            }
        }
    }

    private void AplicarLineaUbicacionCaraAcabadoInterior(Wall muro)
    {
        if (muro == null)
            return;

        try
        {
            Parameter pLocationLine = muro.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);

            if (pLocationLine != null && !pLocationLine.IsReadOnly)
                pLocationLine.Set((int)WallLocationLine.FinishFaceInterior);
        }
        catch
        {
        }
    }

    private void AlinearLineaUbicacionConBoundary(
        Document doc,
        Wall muro,
        Curve curvaBoundary)
    {
        if (doc == null || muro == null || curvaBoundary == null)
            return;

        try
        {
            LocationCurve lc = muro.Location as LocationCurve;

            if (lc == null)
                return;

            lc.Curve = curvaBoundary;

            try
            {
                doc.Regenerate();
            }
            catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
            {
                throw;
            }
            catch
            {
            }
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }
    }

    private void CorregirOrientacionParaCaraInteriorEnBoundary(
        Document doc,
        Wall muro,
        XYZ direccionInteriorRoom)
    {
        if (doc == null || muro == null || direccionInteriorRoom == null)
            return;

        try
        {
            XYZ normalExterior = muro.Orientation;

            if (normalExterior == null)
                return;

            normalExterior = NormalizarXY(normalExterior);

            if (normalExterior == null)
                return;

            double dot = normalExterior.DotProduct(direccionInteriorRoom);

            // Necesitamos que la cara exterior mire hacia el interior del Room,
            // para que la cara de acabado interior quede en el boundary.
            if (dot < 0.0)
            {
                muro.Flip();

                try
                {
                    doc.Regenerate();
                }
                catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
                {
                    throw;
                }
                catch
                {
                }
            }
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }
    }

    private void AplicarParametrosMuro(
        Wall muro,
        double alturaFeet,
        double baseOffsetFeet,
        Room room)
    {
        if (muro == null)
            return;

        try
        {
            Parameter pAltura = muro.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM);

            if (pAltura != null && !pAltura.IsReadOnly)
                pAltura.Set(alturaFeet);
        }
        catch
        {
        }

        try
        {
            Parameter pBaseOffset = muro.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET);

            if (pBaseOffset != null && !pBaseOffset.IsReadOnly)
                pBaseOffset.Set(baseOffsetFeet);
        }
        catch
        {
        }

        try
        {
            Parameter pRoomBounding = muro.get_Parameter(BuiltInParameter.WALL_ATTR_ROOM_BOUNDING);

            if (pRoomBounding != null && !pRoomBounding.IsReadOnly)
                pRoomBounding.Set(1);
        }
        catch
        {
        }

        try
        {
            Parameter pComentarios = muro.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

            if (pComentarios != null && !pComentarios.IsReadOnly)
                pComentarios.Set("Creado desde Room: " + ObtenerNombreRoom(room));
        }
        catch
        {
        }

        AplicarParametrosGestionElemento(
            muro,
            room);
    }

    // =========================================================
    // PARÁMETROS DE GESTIÓN DE ELEMENTOS CREADOS
    // =========================================================

    private void AplicarParametrosGestionElemento(
        Element elementoCreado,
        Room room)
    {
        if (elementoCreado == null)
            return;

        string ubicacion = ObtenerUbicacionDesdeRoom(room);

        if (!string.IsNullOrWhiteSpace(ubicacion))
        {
            SetearParametroInstancia(
                elementoCreado,
                "ARQ_Ubicación",
                ubicacion);
        }

        try
        {
            SetearParametroInstancia(
                elementoCreado,
                "GEN_ID Elemento",
                elementoCreado.Id.Value.ToString());
        }
        catch
        {
        }

        SetearParametroInstancia(
            elementoCreado,
            "GEN_Disciplina",
            "Arquitectura");
    }

    private string ObtenerUbicacionDesdeRoom(Room room)
    {
        if (room == null)
            return "";

        string codigoElemento = ObtenerTextoParametroRoom(
            room,
            "ITEM_CódigoElemento");

        string nombreRoom = "";

        try
        {
            nombreRoom = room.Name;
        }
        catch
        {
            nombreRoom = "";
        }

        if (string.IsNullOrWhiteSpace(nombreRoom))
        {
            nombreRoom = ObtenerTextoParametroRoom(
                room,
                "Nombre");
        }

        nombreRoom = FormatoOracion(nombreRoom);

        if (!string.IsNullOrWhiteSpace(codigoElemento) &&
            !string.IsNullOrWhiteSpace(nombreRoom))
        {
            return codigoElemento.Trim() + " - " + nombreRoom.Trim();
        }

        if (!string.IsNullOrWhiteSpace(codigoElemento))
            return codigoElemento.Trim();

        if (!string.IsNullOrWhiteSpace(nombreRoom))
            return nombreRoom.Trim();

        return "";
    }

    private string ObtenerTextoParametroRoom(
        Room room,
        string nombreParametro)
    {
        if (room == null || string.IsNullOrWhiteSpace(nombreParametro))
            return "";

        try
        {
            Parameter p = room.LookupParameter(nombreParametro);

            if (p == null)
                return "";

            return ObtenerTextoParametroSeguro(p);
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerTextoParametroSeguro(Parameter p)
    {
        if (p == null)
            return "";

        try
        {
            if (p.StorageType == StorageType.String)
            {
                string valor = p.AsString();

                if (!string.IsNullOrWhiteSpace(valor))
                    return valor.Trim();

                valor = p.AsValueString();

                if (!string.IsNullOrWhiteSpace(valor))
                    return valor.Trim();

                return "";
            }

            if (p.StorageType == StorageType.Integer)
                return p.AsInteger().ToString();

            if (p.StorageType == StorageType.Double)
            {
                string valor = p.AsValueString();

                if (!string.IsNullOrWhiteSpace(valor))
                    return valor.Trim();

                return p.AsDouble().ToString(CultureInfo.InvariantCulture);
            }

            if (p.StorageType == StorageType.ElementId)
            {
                ElementId id = p.AsElementId();

                if (id != null && id != ElementId.InvalidElementId)
                    return id.Value.ToString();
            }
        }
        catch
        {
        }

        return "";
    }

    private string FormatoOracion(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        texto = texto.Trim();

        string minusculas = texto.ToLower(CultureInfo.CurrentCulture);

        if (minusculas.Length == 1)
            return minusculas.ToUpper(CultureInfo.CurrentCulture);

        string primera = minusculas.Substring(0, 1).ToUpper(CultureInfo.CurrentCulture);
        string resto = minusculas.Substring(1);

        return primera + resto;
    }

    private bool SetearParametroInstancia(
        Element elemento,
        string nombreParametro,
        string valor)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
            return false;

        if (valor == null)
            valor = "";

        Parameter p = null;

        try
        {
            p = elemento.LookupParameter(nombreParametro);
        }
        catch
        {
            p = null;
        }

        if (p == null || p.IsReadOnly)
            return false;

        try
        {
            if (p.StorageType == StorageType.String)
            {
                p.Set(valor);
                return true;
            }

            if (p.StorageType == StorageType.Integer)
            {
                int numero = 0;

                if (int.TryParse(valor, out numero))
                {
                    p.Set(numero);
                    return true;
                }

                return false;
            }

            if (p.StorageType == StorageType.Double)
            {
                double numero = 0.0;

                string textoNumero = valor.Trim().Replace(",", ".");

                if (double.TryParse(
                    textoNumero,
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out numero))
                {
                    p.Set(numero);
                    return true;
                }

                return false;
            }
        }
        catch
        {
        }

        return false;
    }

    private void BloquearUnionAutomaticaExtremos(Wall muro)
    {
        if (muro == null)
            return;

        try
        {
            WallUtils.DisallowWallJoinAtEnd(muro, 0);
        }
        catch
        {
        }

        try
        {
            WallUtils.DisallowWallJoinAtEnd(muro, 1);
        }
        catch
        {
        }
    }

    private void CorregirUnionesSoloEntreMurosCreados(
        Document doc,
        List<Wall> murosCreados)
    {
        if (doc == null || murosCreados == null || murosCreados.Count == 0)
            return;

        // 1) Durante la creación se mantienen bloqueados los extremos para que Revit
        // no estire/proyecte los muros hacia muros existentes mientras todavía se
        // están generando todos los tramos.
        foreach (Wall muro in murosCreados)
        {
            BloquearUnionAutomaticaExtremos(muro);
        }

        try
        {
            doc.Regenerate();
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }

        // 2) Unimos geometría SOLO entre los muros creados en esta ejecución.
        // Esto ayuda a limpiar encuentros entre tramos nuevos sin forzar uniones
        // con muros antiguos del modelo durante el proceso de creación.
        for (int i = 0; i < murosCreados.Count; i++)
        {
            Wall muroA = murosCreados[i];

            if (muroA == null)
                continue;

            for (int j = i + 1; j < murosCreados.Count; j++)
            {
                Wall muroB = murosCreados[j];

                if (muroB == null)
                    continue;

                if (!MurosCreadosCercanosParaUnion(muroA, muroB))
                    continue;

                try
                {
                    bool yaUnidos = false;

                    try
                    {
                        yaUnidos = JoinGeometryUtils.AreElementsJoined(doc, muroA, muroB);
                    }
                    catch
                    {
                        yaUnidos = false;
                    }

                    if (!yaUnidos)
                        JoinGeometryUtils.JoinGeometry(doc, muroA, muroB);
                }
                catch
                {
                    // Si Revit no permite JoinGeometry en algún par, se deja sin detener el proceso.
                }
            }
        }

        try
        {
            doc.Regenerate();
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }

        // 3) AL FINAL, cuando ya están creados todos los muros, se vuelve a activar
        // "Permitir unión" en ambos extremos. Esto equivale a la opción del menú
        // contextual que mostraste, pero aplicado automáticamente a todos los muros
        // creados por el comando.
        foreach (Wall muro in murosCreados)
        {
            PermitirUnionAutomaticaExtremos(muro);
        }

        try
        {
            doc.Regenerate();
        }
        catch (Autodesk.Revit.Exceptions.RegenerationFailedException)
        {
            throw;
        }
        catch
        {
        }
    }

    private void PermitirUnionAutomaticaExtremos(Wall muro)
    {
        if (muro == null)
            return;

        try
        {
            WallUtils.AllowWallJoinAtEnd(muro, 0);
        }
        catch
        {
        }

        try
        {
            WallUtils.AllowWallJoinAtEnd(muro, 1);
        }
        catch
        {
        }
    }

    private bool MurosCreadosCercanosParaUnion(
        Wall muroA,
        Wall muroB)
    {
        if (muroA == null || muroB == null)
            return false;

        Curve curvaA = ObtenerCurvaUbicacionMuro(muroA);
        Curve curvaB = ObtenerCurvaUbicacionMuro(muroB);

        if (curvaA == null || curvaB == null)
            return false;

        XYZ a0 = null;
        XYZ a1 = null;
        XYZ b0 = null;
        XYZ b1 = null;

        try
        {
            a0 = curvaA.GetEndPoint(0);
            a1 = curvaA.GetEndPoint(1);
            b0 = curvaB.GetEndPoint(0);
            b1 = curvaB.GetEndPoint(1);
        }
        catch
        {
            return false;
        }

        double tolerancia = MetrosAPies(0.15);

        if (DistanciaXY(a0, b0) <= tolerancia) return true;
        if (DistanciaXY(a0, b1) <= tolerancia) return true;
        if (DistanciaXY(a1, b0) <= tolerancia) return true;
        if (DistanciaXY(a1, b1) <= tolerancia) return true;

        return false;
    }

    private Curve ObtenerCurvaUbicacionMuro(Wall muro)
    {
        if (muro == null)
            return null;

        try
        {
            LocationCurve lc = muro.Location as LocationCurve;

            if (lc != null)
                return lc.Curve;
        }
        catch
        {
        }

        return null;
    }

    private double DistanciaXY(
        XYZ a,
        XYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        double dx = a.X - b.X;
        double dy = a.Y - b.Y;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    // =========================================================
    // BOUNDARY DEL ROOM
    // =========================================================


    private List<TramoBoundaryMuroMYG> ObtenerTramosBoundaryRoom(
        Document doc,
        Room room,
        double zBase,
        out int huecosDetectados)
    {
        huecosDetectados = 0;

        List<TramoBoundaryMuroMYG> tramos = new List<TramoBoundaryMuroMYG>();

        if (doc == null || room == null)
            return tramos;

        SpatialElementBoundaryOptions opciones = new SpatialElementBoundaryOptions();
        opciones.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish;

        IList<IList<BoundarySegment>> boundaries = room.GetBoundarySegments(opciones);

        if (boundaries == null || boundaries.Count == 0)
            return tramos;

        foreach (IList<BoundarySegment> boundary in boundaries)
        {
            if (boundary == null || boundary.Count == 0)
                continue;

            foreach (BoundarySegment segmento in boundary)
            {
                if (segmento == null)
                    continue;

                Curve curvaOriginal = segmento.GetCurve();

                if (curvaOriginal == null)
                    continue;

                Curve curvaProyectada = ProyectarCurvaAElevacion(curvaOriginal, zBase);

                if (curvaProyectada == null)
                    continue;

                if (curvaProyectada.Length < 0.0001)
                    continue;

                Wall muroBoundary = null;

                try
                {
                    if (segmento.ElementId != null &&
                        segmento.ElementId != ElementId.InvalidElementId)
                    {
                        muroBoundary = doc.GetElement(segmento.ElementId) as Wall;
                    }
                }
                catch
                {
                    muroBoundary = null;
                }

                TramoBoundaryMuroMYG tramo = new TramoBoundaryMuroMYG();
                tramo.CurvaBoundary = curvaProyectada;
                tramo.MuroBoundary = muroBoundary;
                tramo.Huecos = new List<HuecoMuroRoomMYG>();

                Line linea = curvaProyectada as Line;

                if (linea != null)
                {
                    // IMPORTANTE:
                    // Se buscan puertas/huecos aunque el BoundarySegment no devuelva el muro anfitrión.
                    // En algunos modelos el boundary del Room devuelve ElementId inválido o un elemento distinto,
                    // pero la puerta igual debe generar la mordida del tarrajeo.
                    tramo.Huecos = ObtenerHuecosPuertasYHuecosEnBoundary(
                        doc,
                        muroBoundary,
                        linea,
                        zBase);

                    if (tramo.Huecos != null)
                        huecosDetectados += tramo.Huecos.Count;
                }

                tramos.Add(tramo);
            }
        }

        return tramos;
    }

    private List<HuecoMuroRoomMYG> ObtenerHuecosPuertasYHuecosEnBoundary(
        Document doc,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        List<HuecoMuroRoomMYG> huecos = new List<HuecoMuroRoomMYG>();

        if (doc == null || lineaBoundary == null)
            return huecos;

        HashSet<long> idsProcesados = new HashSet<long>();

        // =========================================================
        // 1) PRIMERO: insertos reales del muro boundary, si Revit los devuelve.
        // =========================================================
        if (muroBoundary != null)
        {
            ICollection<ElementId> idsInsertos = null;

            try
            {
                idsInsertos = muroBoundary.FindInserts(
                    true,
                    false,
                    false,
                    false);
            }
            catch
            {
                idsInsertos = null;
            }

            if (idsInsertos != null)
            {
                foreach (ElementId id in idsInsertos)
                {
                    ProcesarElementoComoHuecoDeBoundary(
                        doc,
                        id,
                        muroBoundary,
                        lineaBoundary,
                        zBase,
                        huecos,
                        idsProcesados);
                }
            }
        }

        // =========================================================
        // 2) RESPALDO: puertas cercanas a la línea del boundary.
        // =========================================================
        // Esto corrige el caso donde el Room devuelve el boundary correcto,
        // pero el BoundarySegment no permite llegar al muro anfitrión o FindInserts
        // no devuelve la puerta. Si la puerta está a la distancia del muro, igual
        // genera la mordida.
        AgregarPuertasCercanasAlBoundary(
            doc,
            muroBoundary,
            lineaBoundary,
            zBase,
            huecos,
            idsProcesados);

        // =========================================================
        // 3) RESPALDO: huecos Opening cercanos al boundary.
        // =========================================================
        // No crea huecos nuevos; solo usa los existentes para calcular la mordida.
        AgregarOpeningsCercanosAlBoundary(
            doc,
            muroBoundary,
            lineaBoundary,
            zBase,
            huecos,
            idsProcesados);

        return UnirHuecosSolapados(huecos, lineaBoundary.Length);
    }

    private void ProcesarElementoComoHuecoDeBoundary(
        Document doc,
        ElementId id,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase,
        List<HuecoMuroRoomMYG> huecos,
        HashSet<long> idsProcesados)
    {
        if (doc == null || id == null || id == ElementId.InvalidElementId)
            return;

        if (huecos == null || idsProcesados == null)
            return;

        if (idsProcesados.Contains(id.Value))
            return;

        Element inserto = null;

        try
        {
            inserto = doc.GetElement(id);
        }
        catch
        {
            inserto = null;
        }

        if (inserto == null)
            return;

        HuecoMuroRoomMYG hueco = null;

        FamilyInstance fi = inserto as FamilyInstance;

        if (fi != null)
        {
            if (!EsPuerta(fi))
                return;

            hueco = ObtenerHuecoDesdePuertaFlexible(
                fi,
                muroBoundary,
                lineaBoundary,
                zBase);
        }
        else
        {
            Opening opening = inserto as Opening;

            if (opening != null)
            {
                hueco = ObtenerHuecoDesdeOpeningFlexible(
                    opening,
                    muroBoundary,
                    lineaBoundary,
                    zBase);
            }
        }

        if (!HuecoValidoParaLinea(hueco, lineaBoundary))
            return;

        idsProcesados.Add(id.Value);
        huecos.Add(hueco);
    }

    private void AgregarPuertasCercanasAlBoundary(
        Document doc,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase,
        List<HuecoMuroRoomMYG> huecos,
        HashSet<long> idsProcesados)
    {
        if (doc == null || lineaBoundary == null || huecos == null || idsProcesados == null)
            return;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfCategory(BuiltInCategory.OST_Doors);
        collector.WhereElementIsNotElementType();

        foreach (Element elemento in collector)
        {
            FamilyInstance puerta = elemento as FamilyInstance;

            if (puerta == null)
                continue;

            if (!EsPuerta(puerta))
                continue;

            if (idsProcesados.Contains(puerta.Id.Value))
                continue;

            // CORRECCIÓN:
            // Antes cualquier puerta cercana al boundary podía cortar el muro nuevo.
            // Eso hacía que una puerta de un muro ADYACENTE o perpendicular afecte otra cara
            // donde realmente no hay puerta. Ahora la puerta solo se acepta si pertenece
            // al mismo muro anfitrión del boundary, o si el boundary no devuelve muro,
            // si su muro host es paralelo y coincide con esa línea de boundary.
            if (!PuertaPerteneceAlBoundary(
                puerta,
                muroBoundary,
                lineaBoundary,
                zBase))
            {
                continue;
            }

            HuecoMuroRoomMYG hueco = ObtenerHuecoDesdePuertaFlexible(
                puerta,
                muroBoundary,
                lineaBoundary,
                zBase);

            if (!HuecoValidoParaLinea(hueco, lineaBoundary))
                continue;

            idsProcesados.Add(puerta.Id.Value);
            huecos.Add(hueco);
        }
    }

    private bool PuertaPerteneceAlBoundary(
        FamilyInstance puerta,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || lineaBoundary == null)
            return false;

        Wall muroHostPuerta = null;

        try
        {
            muroHostPuerta = puerta.Host as Wall;
        }
        catch
        {
            muroHostPuerta = null;
        }

        // Si el BoundarySegment sí devolvió un muro, primero se acepta la puerta
        // cuando pertenece a ese mismo muro anfitrión.
        //
        // Pero también puede ocurrir que una puerta de un muro perpendicular o adyacente
        // tenga marco/tapajunta invadiendo físicamente este acabado. En ese caso también
        // debe descontarse, pero SOLO si el sólido real de la puerta cruza este boundary.
        if (muroBoundary != null)
        {
            if (muroHostPuerta != null)
            {
                try
                {
                    if (muroHostPuerta.Id.Value == muroBoundary.Id.Value)
                        return true;
                }
                catch
                {
                }
            }

            return PuertaSolidoCruzaBoundary(
                puerta,
                lineaBoundary,
                zBase,
                muroBoundary);
        }

        // Si el Room no devolvió muro en el boundary, usamos el host de la puerta
        // como respaldo, pero validando que ese host sea realmente el mismo tramo.
        if (muroHostPuerta == null)
            return false;

        LocationCurve lcHost = null;

        try
        {
            lcHost = muroHostPuerta.Location as LocationCurve;
        }
        catch
        {
            lcHost = null;
        }

        if (lcHost == null || lcHost.Curve == null)
            return false;

        XYZ b0 = lineaBoundary.GetEndPoint(0);
        XYZ b1 = lineaBoundary.GetEndPoint(1);

        XYZ dirBoundary = new XYZ(
            b1.X - b0.X,
            b1.Y - b0.Y,
            0.0);

        if (dirBoundary.GetLength() < 0.0001)
            return false;

        dirBoundary = dirBoundary.Normalize();

        XYZ h0 = null;
        XYZ h1 = null;

        try
        {
            h0 = lcHost.Curve.GetEndPoint(0);
            h1 = lcHost.Curve.GetEndPoint(1);
        }
        catch
        {
            return false;
        }

        if (h0 == null || h1 == null)
            return false;

        XYZ dirHost = new XYZ(
            h1.X - h0.X,
            h1.Y - h0.Y,
            0.0);

        if (dirHost.GetLength() < 0.0001)
            return false;

        dirHost = dirHost.Normalize();

        double paralelismo = Math.Abs(dirBoundary.DotProduct(dirHost));

        // Si el host de la puerta no es paralelo al boundary, es una puerta de otro muro.
        if (paralelismo < 0.92)
            return false;

        double distancia = DistanciaPuertaALineaBoundary(
            puerta,
            lineaBoundary,
            zBase);

        double tolerancia = MetrosAPies(0.12);

        try
        {
            tolerancia = Math.Max(
                muroHostPuerta.Width / 2.0 + MetrosAPies(0.06),
                MetrosAPies(0.12));
        }
        catch
        {
            tolerancia = MetrosAPies(0.12);
        }

        if (distancia > tolerancia)
            return false;

        XYZ puntoPuerta = ObtenerPuntoCentroPuertaParaValidacion(
            puerta,
            zBase);

        if (puntoPuerta == null)
            return false;

        double t = 0.0;

        ProyectarPuntoSobreLineaXY(
            puntoPuerta,
            b0,
            dirBoundary,
            out t);

        double anchoPuerta = ObtenerAnchoPuerta(puerta);

        if (anchoPuerta <= 0.0001)
            anchoPuerta = MetrosAPies(0.90);

        double margen = (anchoPuerta / 2.0) + MetrosAPies(0.10);
        double longitudBoundary = lineaBoundary.Length;

        if (t < -margen)
            return false;

        if (t > longitudBoundary + margen)
            return false;

        return true;
    }

    private XYZ ObtenerPuntoCentroPuertaParaValidacion(
        FamilyInstance puerta,
        double zBase)
    {
        if (puerta == null)
            return null;

        try
        {
            LocationPoint lp = puerta.Location as LocationPoint;

            if (lp != null && lp.Point != null)
            {
                return new XYZ(
                    lp.Point.X,
                    lp.Point.Y,
                    zBase);
            }
        }
        catch
        {
        }

        try
        {
            BoundingBoxXYZ bb = puerta.get_BoundingBox(null);

            if (bb != null)
            {
                return new XYZ(
                    (bb.Min.X + bb.Max.X) / 2.0,
                    (bb.Min.Y + bb.Max.Y) / 2.0,
                    zBase);
            }
        }
        catch
        {
        }

        return null;
    }


    private bool PuertaSolidoCruzaBoundary(
        FamilyInstance puerta,
        Line lineaBoundary,
        double zBase,
        Wall muroBoundary)
    {
        if (puerta == null || lineaBoundary == null)
            return false;

        List<XYZ> puntosSolidos = ObtenerPuntosDeSolidosElemento(puerta);

        if (puntosSolidos == null || puntosSolidos.Count == 0)
            return false;

        XYZ b0 = lineaBoundary.GetEndPoint(0);
        XYZ b1 = lineaBoundary.GetEndPoint(1);

        XYZ dirBoundary = new XYZ(
            b1.X - b0.X,
            b1.Y - b0.Y,
            0.0);

        if (dirBoundary.GetLength() < 0.0001)
            return false;

        dirBoundary = dirBoundary.Normalize();

        double longitudBoundary = lineaBoundary.Length;

        double minT = double.MaxValue;
        double maxT = double.MinValue;
        double minDist = double.MaxValue;
        double maxDistValido = double.MinValue;
        int puntosCercanos = 0;
        int puntosDentroIntervalo = 0;

        double toleranciaDistancia = MetrosAPies(0.08);

        if (muroBoundary != null)
        {
            try
            {
                // Tolerancia pequeña: suficiente para captar marcos/tapajuntas que sí cruzan
                // la cara del acabado, pero evita puertas lejanas de otros ambientes.
                toleranciaDistancia = Math.Max(
                    (muroBoundary.Width / 2.0) + MetrosAPies(0.08),
                    MetrosAPies(0.10));
            }
            catch
            {
                toleranciaDistancia = MetrosAPies(0.10);
            }
        }

        for (int i = 0; i < puntosSolidos.Count; i++)
        {
            XYZ p = puntosSolidos[i];

            if (p == null)
                continue;

            XYZ pXY = new XYZ(
                p.X,
                p.Y,
                zBase);

            double t = 0.0;

            XYZ proyectado = ProyectarPuntoSobreLineaXY(
                pXY,
                b0,
                dirBoundary,
                out t);

            double dist = DistanciaXY(
                pXY,
                proyectado);

            if (dist < minDist)
                minDist = dist;

            if (dist > toleranciaDistancia)
                continue;

            puntosCercanos++;

            if (dist > maxDistValido)
                maxDistValido = dist;

            if (t < minT) minT = t;
            if (t > maxT) maxT = t;

            if (t >= -MetrosAPies(0.05) && t <= longitudBoundary + MetrosAPies(0.05))
                puntosDentroIntervalo++;
        }

        if (puntosCercanos < 4)
            return false;

        if (puntosDentroIntervalo < 2)
            return false;

        double inicio = Math.Max(0.0, minT);
        double fin = Math.Min(longitudBoundary, maxT);

        // Debe haber una franja real de solape sobre este tramo.
        if (fin - inicio < MetrosAPies(0.03))
            return false;

        // Seguridad adicional: si todos los puntos están prácticamente lejos de la línea,
        // no se considera cruce real.
        if (minDist > toleranciaDistancia)
            return false;

        return true;
    }

    private void AgregarOpeningsCercanosAlBoundary(
        Document doc,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase,
        List<HuecoMuroRoomMYG> huecos,
        HashSet<long> idsProcesados)
    {
        if (doc == null || lineaBoundary == null || huecos == null || idsProcesados == null)
            return;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(Opening));
        collector.WhereElementIsNotElementType();

        foreach (Element elemento in collector)
        {
            Opening opening = elemento as Opening;

            if (opening == null)
                continue;

            if (idsProcesados.Contains(opening.Id.Value))
                continue;

            HuecoMuroRoomMYG hueco = ObtenerHuecoDesdeOpeningFlexible(
                opening,
                muroBoundary,
                lineaBoundary,
                zBase);

            if (!HuecoValidoParaLinea(hueco, lineaBoundary))
                continue;

            idsProcesados.Add(opening.Id.Value);
            huecos.Add(hueco);
        }
    }

    private HuecoMuroRoomMYG ObtenerHuecoDesdePuertaFlexible(
        FamilyInstance puerta,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || lineaBoundary == null)
            return null;

        // 1) PRIORIDAD: tomar el ancho real desde la geometría sólida de la puerta.
        // Esto incluye marcos, jambas, tapajuntas u otros sólidos que sí estén modelados
        // dentro de la familia de puerta.
        HuecoMuroRoomMYG huecoPorSolidos = ObtenerHuecoDesdeSolidosPuerta(
            puerta,
            muroBoundary,
            lineaBoundary,
            zBase);

        if (HuecoValidoParaLinea(huecoPorSolidos, lineaBoundary))
            return huecoPorSolidos;

        // 2) RESPALDO: lógica anterior por host, ubicación, parámetros y BoundingBox.
        IntervaloHuecoMuroMYG intervalo = null;

        if (muroBoundary != null)
        {
            intervalo = ObtenerIntervaloDesdePuerta(
                puerta,
                muroBoundary,
                lineaBoundary,
                zBase);
        }

        if (intervalo == null)
        {
            intervalo = ObtenerIntervaloDesdePuertaPorUbicacion(
                puerta,
                lineaBoundary,
                zBase);
        }

        if (intervalo == null)
            return null;

        double zInferior = zBase;
        double zSuperior = zBase + MetrosAPies(2.10);
        double toleranciaInferior = MetrosAPies(0.01);
        double zInferiorMaximoRazonable = zBase + MetrosAPies(0.40);

        BoundingBoxXYZ bb = null;

        try
        {
            bb = puerta.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb != null)
        {
            if (bb.Min.Z > zBase + toleranciaInferior && bb.Min.Z < zInferiorMaximoRazonable)
                zInferior = bb.Min.Z;

            if (bb.Max.Z > zSuperior)
                zSuperior = bb.Max.Z;
        }

        double altoHueco = ObtenerAltoPuerta(puerta);

        if (altoHueco > 0.0001)
        {
            double zSuperiorParametro = zInferior + altoHueco;

            if (zSuperiorParametro > zSuperior)
                zSuperior = zSuperiorParametro;
        }

        HuecoMuroRoomMYG hueco = new HuecoMuroRoomMYG();
        hueco.Inicio = intervalo.Inicio;
        hueco.Fin = intervalo.Fin;
        hueco.ZInferior = zInferior;
        hueco.ZSuperior = zSuperior;
        hueco.ElementoHuecoId = puerta.Id;

        return hueco;
    }

    private HuecoMuroRoomMYG ObtenerHuecoDesdeSolidosPuerta(
        FamilyInstance puerta,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || lineaBoundary == null)
            return null;

        List<XYZ> puntosSolidos = ObtenerPuntosDeSolidosElemento(puerta);

        if (puntosSolidos == null || puntosSolidos.Count == 0)
            return null;

        XYZ p0 = lineaBoundary.GetEndPoint(0);
        XYZ p1 = lineaBoundary.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return null;

        dir = dir.Normalize();

        double longitud = lineaBoundary.Length;
        double minT = double.MaxValue;
        double maxT = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;
        int puntosValidos = 0;

        double toleranciaDistancia = MetrosAPies(0.70);

        if (muroBoundary != null)
        {
            try
            {
                toleranciaDistancia = Math.Max(
                    muroBoundary.Width + MetrosAPies(0.45),
                    MetrosAPies(0.70));
            }
            catch
            {
                toleranciaDistancia = MetrosAPies(0.70);
            }
        }

        for (int i = 0; i < puntosSolidos.Count; i++)
        {
            XYZ p = puntosSolidos[i];

            if (p == null)
                continue;

            XYZ pXY = new XYZ(p.X, p.Y, zBase);
            double t = 0.0;

            XYZ proyectado = ProyectarPuntoSobreLineaXY(
                pXY,
                p0,
                dir,
                out t);

            double distancia = DistanciaXY(pXY, proyectado);

            if (distancia > toleranciaDistancia)
                continue;

            if (t < -MetrosAPies(0.30))
                continue;

            if (t > longitud + MetrosAPies(0.30))
                continue;

            if (t < minT) minT = t;
            if (t > maxT) maxT = t;

            if (p.Z < minZ) minZ = p.Z;
            if (p.Z > maxZ) maxZ = p.Z;

            puntosValidos++;
        }

        if (puntosValidos < 4)
            return null;

        IntervaloHuecoMuroMYG intervalo = CrearIntervaloClampeado(
            minT,
            maxT,
            longitud);

        if (intervalo == null)
            return null;

        double anchoSolido = intervalo.Fin - intervalo.Inicio;

        if (anchoSolido < MetrosAPies(0.20))
            return null;

        // Control de seguridad: si la geometría sólida trae una hoja abierta o un sólido
        // proyectado demasiado lejos, se limita al ancho de hueco/parámetro con una tolerancia.
        double anchoParametro = ObtenerAnchoPuerta(puerta);

        if (anchoParametro > 0.0001)
        {
            double anchoMaximoAceptable = Math.Max(
                anchoParametro + MetrosAPies(0.35),
                MetrosAPies(1.20));

            if (anchoSolido > anchoMaximoAceptable)
            {
                IntervaloHuecoMuroMYG intervaloUbicacion = ObtenerIntervaloDesdePuertaPorUbicacion(
                    puerta,
                    lineaBoundary,
                    zBase);

                if (intervaloUbicacion != null)
                    intervalo = intervaloUbicacion;
            }
        }

        double zInferior = zBase;
        double zSuperior = zBase + MetrosAPies(2.10);
        double toleranciaInferior = MetrosAPies(0.01);
        double zInferiorMaximoRazonable = zBase + MetrosAPies(0.40);

        // Si la geometría sólida de la puerta revela un arranque del hueco por encima
        // de la base (por ejemplo un pequeño umbral o un vacío que no llega al piso),
        // se respeta para que el muro inferior también se modele.
        if (minZ > zBase + toleranciaInferior && minZ < zInferiorMaximoRazonable)
            zInferior = minZ;

        // La parte superior del hueco sí puede venir del sólido real si supera un valor útil.
        if (maxZ > zSuperior)
            zSuperior = maxZ;

        double altoHueco = ObtenerAltoPuerta(puerta);

        if (altoHueco > 0.0001)
        {
            double zSuperiorParametro = zInferior + altoHueco;

            // Se toma el mayor entre parámetro y sólido para no cortar de menos cuando
            // el marco o la jamba sobresalen verticalmente.
            if (zSuperiorParametro > zSuperior)
                zSuperior = zSuperiorParametro;
        }

        HuecoMuroRoomMYG hueco = new HuecoMuroRoomMYG();
        hueco.Inicio = intervalo.Inicio;
        hueco.Fin = intervalo.Fin;
        hueco.ZInferior = zInferior;
        hueco.ZSuperior = zSuperior;
        hueco.ElementoHuecoId = puerta.Id;

        return hueco;
    }

    private List<XYZ> ObtenerPuntosDeSolidosElemento(Element elemento)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elemento == null)
            return puntos;

        Options opciones = new Options();
        opciones.DetailLevel = ViewDetailLevel.Fine;
        opciones.IncludeNonVisibleObjects = true;
        opciones.ComputeReferences = false;

        GeometryElement geo = null;

        try
        {
            geo = elemento.get_Geometry(opciones);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return puntos;

        AgregarPuntosDesdeGeometryElement(geo, puntos);

        return puntos;
    }

    private void AgregarPuntosDesdeGeometryElement(
        GeometryElement geo,
        List<XYZ> puntos)
    {
        if (geo == null || puntos == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                AgregarPuntosDesdeSolid(solid, puntos);
                continue;
            }

            GeometryInstance instancia = obj as GeometryInstance;

            if (instancia != null)
            {
                GeometryElement geoInstancia = null;

                try
                {
                    geoInstancia = instancia.GetInstanceGeometry();
                }
                catch
                {
                    geoInstancia = null;
                }

                if (geoInstancia != null)
                    AgregarPuntosDesdeGeometryElement(geoInstancia, puntos);
            }
        }
    }

    private void AgregarPuntosDesdeSolid(
        Solid solid,
        List<XYZ> puntos)
    {
        if (solid == null || puntos == null)
            return;

        try
        {
            if (solid.Volume <= 0.0000001)
                return;
        }
        catch
        {
        }

        foreach (Face face in solid.Faces)
        {
            if (face == null)
                continue;

            Mesh mesh = null;

            try
            {
                mesh = face.Triangulate();
            }
            catch
            {
                mesh = null;
            }

            if (mesh == null)
                continue;

            try
            {
                // REVIT 2027:
                // Mesh ya no expone NumVertices ni get_Vertex(i).
                // Se debe leer la colección Vertices directamente.
                IList<XYZ> vertices = mesh.Vertices;

                if (vertices != null)
                {
                    foreach (XYZ p in vertices)
                    {
                        if (p != null)
                            puntos.Add(p);
                    }
                }
            }
            catch
            {
            }
        }
    }

    private HuecoMuroRoomMYG ObtenerHuecoDesdeOpeningFlexible(
        Opening opening,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (opening == null || lineaBoundary == null)
            return null;

        IntervaloHuecoMuroMYG intervalo = null;

        if (muroBoundary != null)
        {
            intervalo = ObtenerIntervaloDesdeBoundingBox(
                opening,
                muroBoundary,
                lineaBoundary,
                zBase,
                true);
        }

        if (intervalo == null)
        {
            intervalo = ObtenerIntervaloDesdeBoundingBoxFlexible(
                opening,
                lineaBoundary,
                zBase);
        }

        if (intervalo == null)
            return null;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = opening.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return null;

        HuecoMuroRoomMYG hueco = new HuecoMuroRoomMYG();
        hueco.Inicio = intervalo.Inicio;
        hueco.Fin = intervalo.Fin;
        hueco.ZInferior = bb.Min.Z;
        hueco.ZSuperior = bb.Max.Z;
        hueco.ElementoHuecoId = opening.Id;

        return hueco;
    }

    private IntervaloHuecoMuroMYG ObtenerIntervaloDesdePuertaPorUbicacion(
        FamilyInstance puerta,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || lineaBoundary == null)
            return null;

        LocationPoint lp = null;

        try
        {
            lp = puerta.Location as LocationPoint;
        }
        catch
        {
            lp = null;
        }

        if (lp == null || lp.Point == null)
            return ObtenerIntervaloDesdeBoundingBoxFlexible(
                puerta,
                lineaBoundary,
                zBase);

        XYZ p0 = lineaBoundary.GetEndPoint(0);
        XYZ p1 = lineaBoundary.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return null;

        dir = dir.Normalize();

        XYZ puntoPuerta = new XYZ(
            lp.Point.X,
            lp.Point.Y,
            zBase);

        double t = 0.0;
        XYZ proyectado = ProyectarPuntoSobreLineaXY(
            puntoPuerta,
            p0,
            dir,
            out t);

        double distancia = DistanciaXY(puntoPuerta, proyectado);
        double ancho = ObtenerAnchoPuerta(puerta);

        if (ancho <= 0.0001)
            ancho = MetrosAPies(0.90);

        double tolerancia = Math.Max(
            (ancho / 2.0) + MetrosAPies(0.30),
            MetrosAPies(0.60));

        if (distancia > tolerancia)
            return null;

        return CrearIntervaloClampeado(
            t - (ancho / 2.0),
            t + (ancho / 2.0),
            lineaBoundary.Length);
    }

    private IntervaloHuecoMuroMYG ObtenerIntervaloDesdeBoundingBoxFlexible(
        Element elemento,
        Line lineaBoundary,
        double zBase)
    {
        if (elemento == null || lineaBoundary == null)
            return null;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = elemento.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return null;

        XYZ p0 = lineaBoundary.GetEndPoint(0);
        XYZ p1 = lineaBoundary.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return null;

        dir = dir.Normalize();

        double minT = double.MaxValue;
        double maxT = double.MinValue;
        double minDist = double.MaxValue;

        XYZ[] puntos = new XYZ[]
        {
            new XYZ(bb.Min.X, bb.Min.Y, zBase),
            new XYZ(bb.Min.X, bb.Max.Y, zBase),
            new XYZ(bb.Max.X, bb.Min.Y, zBase),
            new XYZ(bb.Max.X, bb.Max.Y, zBase)
        };

        for (int i = 0; i < puntos.Length; i++)
        {
            double t = 0.0;
            XYZ proyectado = ProyectarPuntoSobreLineaXY(
                puntos[i],
                p0,
                dir,
                out t);

            double distancia = DistanciaXY(puntos[i], proyectado);

            if (distancia < minDist)
                minDist = distancia;

            if (t < minT) minT = t;
            if (t > maxT) maxT = t;
        }

        if (minDist > MetrosAPies(0.60))
            return null;

        return CrearIntervaloClampeado(
            minT,
            maxT,
            lineaBoundary.Length);
    }

    private bool HuecoValidoParaLinea(
        HuecoMuroRoomMYG hueco,
        Line lineaBoundary)
    {
        if (hueco == null || lineaBoundary == null)
            return false;

        if (hueco.Fin - hueco.Inicio < MetrosAPies(0.05))
            return false;

        if (hueco.ZSuperior - hueco.ZInferior < MetrosAPies(0.05))
            return false;

        if (hueco.Fin <= 0.0)
            return false;

        if (hueco.Inicio >= lineaBoundary.Length)
            return false;

        return true;
    }

    private double DistanciaPuertaALineaBoundary(
        FamilyInstance puerta,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || lineaBoundary == null)
            return double.MaxValue;

        LocationPoint lp = null;

        try
        {
            lp = puerta.Location as LocationPoint;
        }
        catch
        {
            lp = null;
        }

        XYZ punto = null;

        if (lp != null && lp.Point != null)
        {
            punto = new XYZ(lp.Point.X, lp.Point.Y, zBase);
        }
        else
        {
            BoundingBoxXYZ bb = null;

            try
            {
                bb = puerta.get_BoundingBox(null);
            }
            catch
            {
                bb = null;
            }

            if (bb != null)
            {
                punto = new XYZ(
                    (bb.Min.X + bb.Max.X) / 2.0,
                    (bb.Min.Y + bb.Max.Y) / 2.0,
                    zBase);
            }
        }

        if (punto == null)
            return double.MaxValue;

        XYZ p0 = lineaBoundary.GetEndPoint(0);
        XYZ p1 = lineaBoundary.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return double.MaxValue;

        dir = dir.Normalize();

        double t = 0.0;
        XYZ proyectado = ProyectarPuntoSobreLineaXY(
            punto,
            p0,
            dir,
            out t);

        return DistanciaXY(punto, proyectado);
    }

    private HuecoMuroRoomMYG ObtenerHuecoDesdePuerta(
        FamilyInstance puerta,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || muroBoundary == null || lineaBoundary == null)
            return null;

        IntervaloHuecoMuroMYG intervalo = ObtenerIntervaloDesdePuerta(
            puerta,
            muroBoundary,
            lineaBoundary,
            zBase);

        if (intervalo == null)
            return null;

        // IMPORTANTE:
        // Para puertas NO se toma bb.Min.Z como arranque del hueco.
        // Muchas familias tienen marco/hoja con BoundingBox empezando 0.10 m, 0.15 m o 0.20 m
        // sobre la base; si usamos ese valor, Revit interpreta el hueco como ventana interna
        // y el perfil del muro no hace la mordida desde abajo.
        // Para una puerta, el boceto correcto es una mordida que nace en la base del muro creado.
        double zInferior = zBase;
        double zSuperior = zBase + MetrosAPies(2.10);

        BoundingBoxXYZ bb = null;

        try
        {
            bb = puerta.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb != null)
        {
            // Solo usamos la parte superior del BoundingBox como respaldo.
            // La parte inferior se fuerza a la base del muro.
            if (bb.Max.Z > zInferior + MetrosAPies(0.20))
                zSuperior = bb.Max.Z;
        }

        double altoHueco = ObtenerAltoPuerta(puerta);

        if (altoHueco > 0.0001)
        {
            // El alto de puerta/hueco se mide desde la base del muro nuevo.
            zSuperior = zInferior + altoHueco;
        }

        HuecoMuroRoomMYG hueco = new HuecoMuroRoomMYG();
        hueco.Inicio = intervalo.Inicio;
        hueco.Fin = intervalo.Fin;
        hueco.ZInferior = zInferior;
        hueco.ZSuperior = zSuperior;
        hueco.ElementoHuecoId = puerta.Id;

        return hueco;
    }

    private HuecoMuroRoomMYG ObtenerHuecoDesdeBoundingBoxConAltura(
        Element elemento,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (elemento == null || muroBoundary == null || lineaBoundary == null)
            return null;

        IntervaloHuecoMuroMYG intervalo = ObtenerIntervaloDesdeBoundingBox(
            elemento,
            muroBoundary,
            lineaBoundary,
            zBase,
            true);

        if (intervalo == null)
            return null;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = elemento.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return null;

        HuecoMuroRoomMYG hueco = new HuecoMuroRoomMYG();
        hueco.Inicio = intervalo.Inicio;
        hueco.Fin = intervalo.Fin;
        hueco.ZInferior = bb.Min.Z;
        hueco.ZSuperior = bb.Max.Z;
        hueco.ElementoHuecoId = elemento.Id;

        return hueco;
    }

    private int CrearAberturasEnMuroCreado(
        Document doc,
        Wall muroCreado,
        TramoBoundaryMuroMYG tramo,
        double zBaseMuro,
        double alturaMuro)
    {
        // YA NO SE USA.
        // Se deja como método inactivo para compatibilidad interna del archivo,
        // pero ya NO crea elementos Opening / Hueco de muro.
        // Los cortes de puertas y huecos se integran en el mismo perfil/boceto
        // mediante CrearPerfilBocetoMuroConHuecos().
        return 0;
    }

    private double ObtenerAltoPuerta(FamilyInstance puerta)
    {
        if (puerta == null)
            return 0.0;

        string[] nombresAltoHueco = new string[]
        {
            "Rough Height",
            "Rough height",
            "Opening Height",
            "Opening height",
            "Altura de hueco",
            "Altura hueco",
            "Altura de vano",
            "Altura vano",
            "Altura de abertura",
            "Altura abertura",
            "Altura de apertura",
            "Altura apertura",
            "Height",
            "Altura",
            "Alto"
        };

        double valor = ObtenerParametroDoublePorNombres(puerta, nombresAltoHueco);

        if (valor > 0.0001)
            return valor;

        Parameter p = null;

        try
        {
            if (puerta.Symbol != null)
                p = puerta.Symbol.get_Parameter(BuiltInParameter.FAMILY_HEIGHT_PARAM);
        }
        catch
        {
            p = null;
        }

        if (p == null)
        {
            try
            {
                p = puerta.get_Parameter(BuiltInParameter.FAMILY_HEIGHT_PARAM);
            }
            catch
            {
                p = null;
            }
        }

        return ObtenerDoubleSeguro(p);
    }

    private List<HuecoMuroRoomMYG> UnirHuecosSolapados(
        List<HuecoMuroRoomMYG> huecos,
        double longitud)
    {
        List<HuecoMuroRoomMYG> resultado = new List<HuecoMuroRoomMYG>();

        if (huecos == null || huecos.Count == 0)
            return resultado;

        huecos.Sort(delegate (HuecoMuroRoomMYG a, HuecoMuroRoomMYG b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;

            return a.Inicio.CompareTo(b.Inicio);
        });

        foreach (HuecoMuroRoomMYG hueco in huecos)
        {
            if (hueco == null)
                continue;

            double i = Math.Max(0.0, hueco.Inicio);
            double f = Math.Min(longitud, hueco.Fin);

            if (f <= i)
                continue;

            if (resultado.Count == 0)
            {
                HuecoMuroRoomMYG nuevo = new HuecoMuroRoomMYG();
                nuevo.Inicio = i;
                nuevo.Fin = f;
                nuevo.ZInferior = hueco.ZInferior;
                nuevo.ZSuperior = hueco.ZSuperior;
                nuevo.ElementoHuecoId = hueco.ElementoHuecoId;
                resultado.Add(nuevo);
                continue;
            }

            HuecoMuroRoomMYG ultimo = resultado[resultado.Count - 1];
            double toleranciaUnion = MetrosAPies(0.02);

            // Solo une si se solapan en planta Y también son compatibles en altura.
            bool alturaCompatible =
                Math.Abs(ultimo.ZInferior - hueco.ZInferior) <= MetrosAPies(0.05) &&
                Math.Abs(ultimo.ZSuperior - hueco.ZSuperior) <= MetrosAPies(0.05);

            if (alturaCompatible && i <= ultimo.Fin + toleranciaUnion)
            {
                if (f > ultimo.Fin)
                    ultimo.Fin = f;

                if (hueco.ZInferior < ultimo.ZInferior)
                    ultimo.ZInferior = hueco.ZInferior;

                if (hueco.ZSuperior > ultimo.ZSuperior)
                    ultimo.ZSuperior = hueco.ZSuperior;
            }
            else
            {
                HuecoMuroRoomMYG nuevo = new HuecoMuroRoomMYG();
                nuevo.Inicio = i;
                nuevo.Fin = f;
                nuevo.ZInferior = hueco.ZInferior;
                nuevo.ZSuperior = hueco.ZSuperior;
                nuevo.ElementoHuecoId = hueco.ElementoHuecoId;
                resultado.Add(nuevo);
            }
        }

        return resultado;
    }

    private List<Curve> ObtenerCurvasBoundaryRoom(
        Document doc,
        Room room,
        double zBase,
        out int huecosCortados)
    {
        huecosCortados = 0;

        List<Curve> curvas = new List<Curve>();

        if (doc == null || room == null)
            return curvas;

        SpatialElementBoundaryOptions opciones = new SpatialElementBoundaryOptions();
        opciones.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish;

        IList<IList<BoundarySegment>> boundaries = room.GetBoundarySegments(opciones);

        if (boundaries == null || boundaries.Count == 0)
            return curvas;

        foreach (IList<BoundarySegment> boundary in boundaries)
        {
            if (boundary == null || boundary.Count == 0)
                continue;

            foreach (BoundarySegment segmento in boundary)
            {
                if (segmento == null)
                    continue;

                Curve curvaOriginal = segmento.GetCurve();

                if (curvaOriginal == null)
                    continue;

                Curve curvaProyectada = ProyectarCurvaAElevacion(curvaOriginal, zBase);

                if (curvaProyectada == null)
                    continue;

                if (curvaProyectada.Length < 0.0001)
                    continue;

                Wall muroBoundary = null;

                try
                {
                    if (segmento.ElementId != null &&
                        segmento.ElementId != ElementId.InvalidElementId)
                    {
                        muroBoundary = doc.GetElement(segmento.ElementId) as Wall;
                    }
                }
                catch
                {
                    muroBoundary = null;
                }

                if (muroBoundary == null)
                {
                    curvas.Add(curvaProyectada);
                    continue;
                }

                int huecosSegmento = 0;

                List<Curve> curvasCortadas = CortarCurvaBoundaryPorPuertasYHuecos(
                    doc,
                    muroBoundary,
                    curvaProyectada,
                    zBase,
                    out huecosSegmento);

                huecosCortados += huecosSegmento;

                if (curvasCortadas == null || curvasCortadas.Count == 0)
                    continue;

                foreach (Curve c in curvasCortadas)
                {
                    if (c == null)
                        continue;

                    if (c.Length < 0.0001)
                        continue;

                    curvas.Add(c);
                }
            }
        }

        return curvas;
    }

    // =========================================================
    // CORTAR PUERTAS Y HUECOS EN EL BOUNDARY
    // =========================================================

    private List<Curve> CortarCurvaBoundaryPorPuertasYHuecos(
        Document doc,
        Wall muroBoundary,
        Curve curvaBoundary,
        double zBase,
        out int huecosCortados)
    {
        huecosCortados = 0;

        List<Curve> resultado = new List<Curve>();

        if (doc == null || muroBoundary == null || curvaBoundary == null)
            return resultado;

        Line linea = curvaBoundary as Line;

        if (linea == null)
        {
            resultado.Add(curvaBoundary);
            return resultado;
        }

        List<IntervaloHuecoMuroMYG> intervalos = ObtenerIntervalosPuertasYHuecosEnBoundary(
            doc,
            muroBoundary,
            linea,
            zBase);

        if (intervalos == null || intervalos.Count == 0)
        {
            resultado.Add(curvaBoundary);
            return resultado;
        }

        intervalos = UnirIntervalosHuecos(intervalos, linea.Length);

        if (intervalos == null || intervalos.Count == 0)
        {
            resultado.Add(curvaBoundary);
            return resultado;
        }

        XYZ p0 = linea.GetEndPoint(0);
        XYZ p1 = linea.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
        {
            resultado.Add(curvaBoundary);
            return resultado;
        }

        dir = dir.Normalize();

        double longitud = linea.Length;
        double posicionActual = 0.0;
        double longitudMinima = MetrosAPies(0.03);

        foreach (IntervaloHuecoMuroMYG intervalo in intervalos)
        {
            if (intervalo == null)
                continue;

            double inicio = Math.Max(0.0, intervalo.Inicio);
            double fin = Math.Min(longitud, intervalo.Fin);

            if (fin <= posicionActual)
                continue;

            if (inicio - posicionActual > longitudMinima)
            {
                XYZ a = p0 + dir.Multiply(posicionActual);
                XYZ b = p0 + dir.Multiply(inicio);

                try
                {
                    resultado.Add(Line.CreateBound(a, b));
                }
                catch
                {
                }
            }

            if (fin > posicionActual)
                posicionActual = fin;

            huecosCortados++;
        }

        if (longitud - posicionActual > longitudMinima)
        {
            XYZ a = p0 + dir.Multiply(posicionActual);
            XYZ b = p0 + dir.Multiply(longitud);

            try
            {
                resultado.Add(Line.CreateBound(a, b));
            }
            catch
            {
            }
        }

        return resultado;
    }

    private List<IntervaloHuecoMuroMYG> ObtenerIntervalosPuertasYHuecosEnBoundary(
        Document doc,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        List<IntervaloHuecoMuroMYG> intervalos = new List<IntervaloHuecoMuroMYG>();

        if (doc == null || muroBoundary == null || lineaBoundary == null)
            return intervalos;

        ICollection<ElementId> idsInsertos = null;

        try
        {
            // addRectOpenings = true: incluye huecos rectangulares creados con Opening.
            // Los FamilyInstance se filtran para puertas, y los Opening se toman como huecos de muro.
            idsInsertos = muroBoundary.FindInserts(
                true,
                false,
                false,
                false);
        }
        catch
        {
            idsInsertos = null;
        }

        if (idsInsertos == null || idsInsertos.Count == 0)
            return intervalos;

        foreach (ElementId id in idsInsertos)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            Element inserto = null;

            try
            {
                inserto = doc.GetElement(id);
            }
            catch
            {
                inserto = null;
            }

            if (inserto == null)
                continue;

            IntervaloHuecoMuroMYG intervalo = null;

            FamilyInstance fi = inserto as FamilyInstance;

            if (fi != null)
            {
                if (!EsPuerta(fi))
                    continue;

                intervalo = ObtenerIntervaloDesdePuerta(
                    fi,
                    muroBoundary,
                    lineaBoundary,
                    zBase);
            }
            else
            {
                Opening opening = inserto as Opening;

                if (opening != null)
                {
                    intervalo = ObtenerIntervaloDesdeBoundingBox(
                        opening,
                        muroBoundary,
                        lineaBoundary,
                        zBase,
                        true);
                }
            }

            if (intervalo == null)
                continue;

            if (intervalo.Fin - intervalo.Inicio < MetrosAPies(0.05))
                continue;

            intervalos.Add(intervalo);
        }

        return intervalos;
    }

    private bool EsPuerta(FamilyInstance fi)
    {
        if (fi == null || fi.Category == null)
            return false;

        try
        {
            return fi.Category.Id.Value == new ElementId(BuiltInCategory.OST_Doors).Value;
        }
        catch
        {
            return false;
        }
    }

    private IntervaloHuecoMuroMYG ObtenerIntervaloDesdePuerta(
        FamilyInstance puerta,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase)
    {
        if (puerta == null || muroBoundary == null || lineaBoundary == null)
            return null;

        LocationPoint lp = null;

        try
        {
            lp = puerta.Location as LocationPoint;
        }
        catch
        {
            lp = null;
        }

        if (lp != null && lp.Point != null)
        {
            XYZ puntoPuerta = new XYZ(
                lp.Point.X,
                lp.Point.Y,
                zBase);

            XYZ p0 = lineaBoundary.GetEndPoint(0);
            XYZ p1 = lineaBoundary.GetEndPoint(1);

            XYZ dir = new XYZ(
                p1.X - p0.X,
                p1.Y - p0.Y,
                0.0);

            if (dir.GetLength() > 0.0001)
            {
                dir = dir.Normalize();

                double t = 0.0;
                XYZ puntoProyectado = ProyectarPuntoSobreLineaXY(
                    puntoPuerta,
                    p0,
                    dir,
                    out t);

                double distancia = DistanciaXY(puntoPuerta, puntoProyectado);
                double tolerancia = Math.Max(
                    muroBoundary.Width + MetrosAPies(0.80),
                    MetrosAPies(1.00));

                if (distancia <= tolerancia)
                {
                    double anchoPuerta = ObtenerAnchoPuerta(puerta);

                    if (anchoPuerta <= 0.0001)
                    {
                        IntervaloHuecoMuroMYG intervaloBBox = ObtenerIntervaloDesdeBoundingBox(
                            puerta,
                            muroBoundary,
                            lineaBoundary,
                            zBase,
                            true);

                        if (intervaloBBox != null)
                            return intervaloBBox;

                        anchoPuerta = MetrosAPies(0.90);
                    }

                    double margen = 0.0;
                    double inicio = t - (anchoPuerta / 2.0) - margen;
                    double fin = t + (anchoPuerta / 2.0) + margen;

                    return CrearIntervaloClampeado(
                        inicio,
                        fin,
                        lineaBoundary.Length);
                }
            }
        }

        return ObtenerIntervaloDesdeBoundingBox(
            puerta,
            muroBoundary,
            lineaBoundary,
            zBase,
            true);
    }

    private double ObtenerAnchoPuerta(FamilyInstance puerta)
    {
        if (puerta == null)
            return 0.0;

        // IMPORTANTE:
        // Para cortar el tarrajeo NO se debe usar con prioridad el ancho nominal de la hoja.
        // En varias familias el ancho de puerta puede ser 0.80 m, pero el hueco real del muro
        // puede ser 0.86 m. Por eso primero se busca el ancho de hueco / rough width.

        string[] nombresHueco = new string[]
        {
            "Rough Width",
            "Rough width",
            "rough width",
            "Opening Width",
            "Opening width",
            "Ancho de hueco",
            "Ancho hueco",
            "Anchura de hueco",
            "Ancho de vano",
            "Ancho vano",
            "Ancho de abertura",
            "Ancho abertura",
            "Ancho de apertura",
            "Ancho apertura"
        };

        double valorHueco = ObtenerParametroDoublePorNombres(puerta, nombresHueco);

        if (valorHueco > 0.0001)
            return valorHueco;

        valorHueco = BuscarParametroAnchoHuecoFlexible(puerta);

        if (valorHueco > 0.0001)
            return valorHueco;

        string[] nombresAnchoNormal = new string[]
        {
            "Width",
            "Ancho",
            "Anchura",
            "Ancho de puerta"
        };

        double valorAncho = ObtenerParametroDoublePorNombres(puerta, nombresAnchoNormal);

        if (valorAncho > 0.0001)
            return valorAncho;

        Parameter p = null;

        try
        {
            if (puerta.Symbol != null)
                p = puerta.Symbol.get_Parameter(BuiltInParameter.FAMILY_WIDTH_PARAM);
        }
        catch
        {
            p = null;
        }

        if (p == null)
        {
            try
            {
                p = puerta.get_Parameter(BuiltInParameter.FAMILY_WIDTH_PARAM);
            }
            catch
            {
                p = null;
            }
        }

        if (p != null && p.StorageType == StorageType.Double)
        {
            try
            {
                double valor = p.AsDouble();

                if (valor > 0.0001)
                    return valor;
            }
            catch
            {
            }
        }

        return 0.0;
    }

    private double ObtenerParametroDoublePorNombres(
        FamilyInstance instancia,
        string[] nombres)
    {
        if (instancia == null || nombres == null || nombres.Length == 0)
            return 0.0;

        // Primero tipo, porque casi siempre el ancho/hueco está en el tipo de puerta.
        try
        {
            if (instancia.Symbol != null)
            {
                for (int i = 0; i < nombres.Length; i++)
                {
                    Parameter p = instancia.Symbol.LookupParameter(nombres[i]);
                    double valor = ObtenerDoubleSeguro(p);

                    if (valor > 0.0001)
                        return valor;
                }
            }
        }
        catch
        {
        }

        try
        {
            for (int i = 0; i < nombres.Length; i++)
            {
                Parameter p = instancia.LookupParameter(nombres[i]);
                double valor = ObtenerDoubleSeguro(p);

                if (valor > 0.0001)
                    return valor;
            }
        }
        catch
        {
        }

        return 0.0;
    }

    private double BuscarParametroAnchoHuecoFlexible(FamilyInstance instancia)
    {
        if (instancia == null)
            return 0.0;

        double valor = 0.0;

        try
        {
            if (instancia.Symbol != null)
            {
                valor = BuscarParametroAnchoHuecoEnElemento(instancia.Symbol);

                if (valor > 0.0001)
                    return valor;
            }
        }
        catch
        {
        }

        try
        {
            valor = BuscarParametroAnchoHuecoEnElemento(instancia);

            if (valor > 0.0001)
                return valor;
        }
        catch
        {
        }

        return 0.0;
    }

    private double BuscarParametroAnchoHuecoEnElemento(Element elemento)
    {
        if (elemento == null)
            return 0.0;

        try
        {
            foreach (Parameter p in elemento.Parameters)
            {
                if (p == null || p.Definition == null)
                    continue;

                if (p.StorageType != StorageType.Double)
                    continue;

                string nombre = "";

                try
                {
                    nombre = p.Definition.Name;
                }
                catch
                {
                    nombre = "";
                }

                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                string n = nombre.ToUpperInvariant();

                bool pareceAncho =
                    n.Contains("WIDTH") ||
                    n.Contains("ANCHO") ||
                    n.Contains("ANCHURA");

                bool pareceHueco =
                    n.Contains("ROUGH") ||
                    n.Contains("HUECO") ||
                    n.Contains("VANO") ||
                    n.Contains("OPENING") ||
                    n.Contains("APERTURA") ||
                    n.Contains("ABERTURA");

                if (!pareceAncho || !pareceHueco)
                    continue;

                double valor = ObtenerDoubleSeguro(p);

                if (valor > 0.0001)
                    return valor;
            }
        }
        catch
        {
        }

        return 0.0;
    }

    private double ObtenerDoubleSeguro(Parameter p)
    {
        if (p == null)
            return 0.0;

        if (p.StorageType != StorageType.Double)
            return 0.0;

        try
        {
            double valor = p.AsDouble();

            if (valor > 0.0001)
                return valor;
        }
        catch
        {
        }

        return 0.0;
    }

    private IntervaloHuecoMuroMYG ObtenerIntervaloDesdeBoundingBox(
        Element elemento,
        Wall muroBoundary,
        Line lineaBoundary,
        double zBase,
        bool aplicarMargen)
    {
        if (elemento == null || muroBoundary == null || lineaBoundary == null)
            return null;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = elemento.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return null;

        XYZ p0 = lineaBoundary.GetEndPoint(0);
        XYZ p1 = lineaBoundary.GetEndPoint(1);

        XYZ dir = new XYZ(
            p1.X - p0.X,
            p1.Y - p0.Y,
            0.0);

        if (dir.GetLength() < 0.0001)
            return null;

        dir = dir.Normalize();

        double minT = double.MaxValue;
        double maxT = double.MinValue;
        double minDist = double.MaxValue;

        XYZ[] puntos = new XYZ[]
        {
            new XYZ(bb.Min.X, bb.Min.Y, zBase),
            new XYZ(bb.Min.X, bb.Max.Y, zBase),
            new XYZ(bb.Max.X, bb.Min.Y, zBase),
            new XYZ(bb.Max.X, bb.Max.Y, zBase)
        };

        for (int i = 0; i < puntos.Length; i++)
        {
            double t = 0.0;
            XYZ proyectado = ProyectarPuntoSobreLineaXY(
                puntos[i],
                p0,
                dir,
                out t);

            double distancia = DistanciaXY(puntos[i], proyectado);

            if (distancia < minDist)
                minDist = distancia;

            if (t < minT) minT = t;
            if (t > maxT) maxT = t;
        }

        double tolerancia = Math.Max(
            muroBoundary.Width + MetrosAPies(0.80),
            MetrosAPies(1.00));

        if (minDist > tolerancia)
            return null;

        double margen = 0.0;

        return CrearIntervaloClampeado(
            minT - margen,
            maxT + margen,
            lineaBoundary.Length);
    }

    private IntervaloHuecoMuroMYG CrearIntervaloClampeado(
        double inicio,
        double fin,
        double longitud)
    {
        if (longitud <= 0.0001)
            return null;

        double i = Math.Max(0.0, inicio);
        double f = Math.Min(longitud, fin);

        if (f <= i)
            return null;

        IntervaloHuecoMuroMYG intervalo = new IntervaloHuecoMuroMYG();
        intervalo.Inicio = i;
        intervalo.Fin = f;

        return intervalo;
    }

    private List<IntervaloHuecoMuroMYG> UnirIntervalosHuecos(
        List<IntervaloHuecoMuroMYG> intervalos,
        double longitud)
    {
        List<IntervaloHuecoMuroMYG> resultado = new List<IntervaloHuecoMuroMYG>();

        if (intervalos == null || intervalos.Count == 0)
            return resultado;

        intervalos.Sort(delegate (IntervaloHuecoMuroMYG a, IntervaloHuecoMuroMYG b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;

            return a.Inicio.CompareTo(b.Inicio);
        });

        foreach (IntervaloHuecoMuroMYG intervalo in intervalos)
        {
            if (intervalo == null)
                continue;

            IntervaloHuecoMuroMYG actual = CrearIntervaloClampeado(
                intervalo.Inicio,
                intervalo.Fin,
                longitud);

            if (actual == null)
                continue;

            if (resultado.Count == 0)
            {
                resultado.Add(actual);
                continue;
            }

            IntervaloHuecoMuroMYG ultimo = resultado[resultado.Count - 1];
            double toleranciaUnion = MetrosAPies(0.02);

            if (actual.Inicio <= ultimo.Fin + toleranciaUnion)
            {
                if (actual.Fin > ultimo.Fin)
                    ultimo.Fin = actual.Fin;
            }
            else
            {
                resultado.Add(actual);
            }
        }

        return resultado;
    }

    private XYZ ProyectarPuntoSobreLineaXY(
        XYZ punto,
        XYZ origen,
        XYZ direccion,
        out double parametro)
    {
        parametro = 0.0;

        if (punto == null || origen == null || direccion == null)
            return null;

        XYZ v = new XYZ(
            punto.X - origen.X,
            punto.Y - origen.Y,
            0.0);

        XYZ d = new XYZ(
            direccion.X,
            direccion.Y,
            0.0);

        if (d.GetLength() < 0.0001)
            return origen;

        d = d.Normalize();
        parametro = v.DotProduct(d);

        return new XYZ(
            origen.X + d.X * parametro,
            origen.Y + d.Y * parametro,
            punto.Z);
    }

    private class IntervaloHuecoMuroMYG
    {
        public double Inicio { get; set; }
        public double Fin { get; set; }
    }

    private class HuecoMuroRoomMYG
    {
        public double Inicio { get; set; }
        public double Fin { get; set; }
        public double ZInferior { get; set; }
        public double ZSuperior { get; set; }
        public ElementId ElementoHuecoId { get; set; }
    }

    private class TramoBoundaryMuroMYG
    {
        public Curve CurvaBoundary { get; set; }
        public Wall MuroBoundary { get; set; }
        public List<HuecoMuroRoomMYG> Huecos { get; set; }
    }

    private Curve ProyectarCurvaAElevacion(
        Curve curva,
        double z)
    {
        if (curva == null)
            return null;

        try
        {
            Line linea = curva as Line;

            if (linea != null)
            {
                XYZ p0 = linea.GetEndPoint(0);
                XYZ p1 = linea.GetEndPoint(1);

                XYZ q0 = new XYZ(p0.X, p0.Y, z);
                XYZ q1 = new XYZ(p1.X, p1.Y, z);

                if (q0.DistanceTo(q1) < 0.0001)
                    return null;

                return Line.CreateBound(q0, q1);
            }

            Arc arco = curva as Arc;

            if (arco != null)
            {
                XYZ p0 = arco.GetEndPoint(0);
                XYZ p1 = arco.GetEndPoint(1);
                XYZ pm = arco.Evaluate(0.5, true);

                XYZ q0 = new XYZ(p0.X, p0.Y, z);
                XYZ q1 = new XYZ(p1.X, p1.Y, z);
                XYZ qm = new XYZ(pm.X, pm.Y, z);

                if (q0.DistanceTo(q1) < 0.0001)
                    return null;

                try
                {
                    return Arc.Create(q0, q1, qm);
                }
                catch
                {
                    return Line.CreateBound(q0, q1);
                }
            }

            XYZ a = curva.GetEndPoint(0);
            XYZ b = curva.GetEndPoint(1);

            XYZ qa = new XYZ(a.X, a.Y, z);
            XYZ qb = new XYZ(b.X, b.Y, z);

            if (qa.DistanceTo(qb) < 0.0001)
                return null;

            return Line.CreateBound(qa, qb);
        }
        catch
        {
            return null;
        }
    }

    private Curve CrearCurvaDesplazada(
        Curve curva,
        XYZ desplazamiento)
    {
        if (curva == null || desplazamiento == null)
            return null;

        try
        {
            Transform t = Transform.CreateTranslation(desplazamiento);
            return curva.CreateTransformed(t);
        }
        catch
        {
            return null;
        }
    }

    // =========================================================
    // DIRECCIÓN HACIA EL INTERIOR DEL ROOM
    // =========================================================

    private XYZ ObtenerDireccionHaciaInteriorRoom(
        Room room,
        Curve curvaBoundary,
        double zBase)
    {
        if (room == null || curvaBoundary == null)
            return null;

        XYZ puntoMedio = ObtenerPuntoMedioCurva(curvaBoundary);

        if (puntoMedio == null)
            return null;

        puntoMedio = new XYZ(puntoMedio.X, puntoMedio.Y, zBase + MetrosAPies(0.10));

        XYZ tangente = ObtenerTangenteXY(curvaBoundary);

        if (tangente != null && tangente.GetLength() > 0.0001)
        {
            tangente = NormalizarXY(tangente);

            if (tangente != null)
            {
                XYZ normalA = new XYZ(-tangente.Y, tangente.X, 0.0);
                XYZ normalB = new XYZ(tangente.Y, -tangente.X, 0.0);

                double prueba = MetrosAPies(0.20);

                XYZ puntoA = puntoMedio + normalA.Multiply(prueba);
                XYZ puntoB = puntoMedio + normalB.Multiply(prueba);

                bool aDentro = EsPuntoDentroRoom(room, puntoA);
                bool bDentro = EsPuntoDentroRoom(room, puntoB);

                if (aDentro && !bDentro)
                    return normalA;

                if (bDentro && !aDentro)
                    return normalB;

                // Si ambos resultan dentro por tolerancias, usar el vector al punto de ubicación del Room.
                XYZ puntoInterior = ObtenerPuntoInteriorRoom(room, zBase);

                if (puntoInterior != null)
                {
                    XYZ vector = new XYZ(
                        puntoInterior.X - puntoMedio.X,
                        puntoInterior.Y - puntoMedio.Y,
                        0.0);

                    if (vector.GetLength() > 0.0001)
                    {
                        double dotA = normalA.DotProduct(vector);
                        double dotB = normalB.DotProduct(vector);

                        if (dotA >= dotB)
                            return normalA;

                        return normalB;
                    }
                }

                return normalA;
            }
        }

        XYZ puntoRoom = ObtenerPuntoInteriorRoom(room, zBase);

        if (puntoRoom != null)
        {
            XYZ vector = new XYZ(
                puntoRoom.X - puntoMedio.X,
                puntoRoom.Y - puntoMedio.Y,
                0.0);

            if (vector.GetLength() > 0.0001)
                return vector.Normalize();
        }

        return null;
    }

    private bool EsPuntoDentroRoom(
        Room room,
        XYZ punto)
    {
        if (room == null || punto == null)
            return false;

        try
        {
            return room.IsPointInRoom(punto);
        }
        catch
        {
            return false;
        }
    }

    private XYZ ObtenerPuntoInteriorRoom(
        Room room,
        double zBase)
    {
        if (room == null)
            return null;

        try
        {
            LocationPoint lp = room.Location as LocationPoint;

            if (lp != null && lp.Point != null)
                return new XYZ(lp.Point.X, lp.Point.Y, zBase + MetrosAPies(0.10));
        }
        catch
        {
        }

        try
        {
            BoundingBoxXYZ bb = room.get_BoundingBox(null);

            if (bb != null)
            {
                return new XYZ(
                    (bb.Min.X + bb.Max.X) / 2.0,
                    (bb.Min.Y + bb.Max.Y) / 2.0,
                    zBase + MetrosAPies(0.10));
            }
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerPuntoMedioCurva(Curve curva)
    {
        if (curva == null)
            return null;

        try
        {
            return curva.Evaluate(0.5, true);
        }
        catch
        {
        }

        try
        {
            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);

            return new XYZ(
                (p0.X + p1.X) / 2.0,
                (p0.Y + p1.Y) / 2.0,
                (p0.Z + p1.Z) / 2.0);
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerTangenteXY(Curve curva)
    {
        if (curva == null)
            return null;

        try
        {
            Transform derivadas = curva.ComputeDerivatives(0.5, true);

            if (derivadas != null && derivadas.BasisX != null)
            {
                XYZ t = new XYZ(
                    derivadas.BasisX.X,
                    derivadas.BasisX.Y,
                    0.0);

                if (t.GetLength() > 0.0001)
                    return t.Normalize();
            }
        }
        catch
        {
        }

        try
        {
            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);

            XYZ t = new XYZ(
                p1.X - p0.X,
                p1.Y - p0.Y,
                0.0);

            if (t.GetLength() > 0.0001)
                return t.Normalize();
        }
        catch
        {
        }

        return null;
    }

    private XYZ NormalizarXY(XYZ vector)
    {
        if (vector == null)
            return null;

        XYZ v = new XYZ(vector.X, vector.Y, 0.0);

        if (v.GetLength() < 0.0001)
            return null;

        return v.Normalize();
    }

    // =========================================================
    // NIVELES
    // =========================================================

    private Level ObtenerNivelMasCercano(
        Document doc,
        double zFeet)
    {
        if (doc == null)
            return null;

        Level mejorNivel = null;
        double mejorDistancia = double.MaxValue;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(Level));

        foreach (Element elemento in collector)
        {
            Level nivel = elemento as Level;

            if (nivel == null)
                continue;

            double distancia = Math.Abs(nivel.ProjectElevation - zFeet);

            if (distancia < mejorDistancia)
            {
                mejorDistancia = distancia;
                mejorNivel = nivel;
            }
        }

        return mejorNivel;
    }

    // =========================================================
    // CLAVES PARA EVITAR DUPLICADOS
    // =========================================================

    private string ObtenerClaveCurvaXY(Curve curva)
    {
        if (curva == null)
            return "";

        try
        {
            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);

            string a = PuntoClaveXY(p0);
            string b = PuntoClaveXY(p1);

            if (string.Compare(a, b, StringComparison.OrdinalIgnoreCase) <= 0)
                return a + "|" + b;

            return b + "|" + a;
        }
        catch
        {
            return "";
        }
    }

    private string PuntoClaveXY(XYZ p)
    {
        if (p == null)
            return "";

        double x = Math.Round(p.X, 4);
        double y = Math.Round(p.Y, 4);

        return x.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture) +
            "," +
            y.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture);
    }

    // =========================================================
    // UTILIDADES
    // =========================================================

    private void MostrarEnVentana(string texto)
    {
        if (Form == null || Form.IsDisposed)
            return;

        Form.MostrarResultado(texto);
    }

    private string ObtenerNombreRoom(Room room)
    {
        if (room == null)
            return "Room";

        string numero = "";
        string nombre = "";

        try
        {
            numero = room.Number;
        }
        catch
        {
        }

        try
        {
            nombre = room.Name;
        }
        catch
        {
        }

        if (!string.IsNullOrWhiteSpace(numero) && !string.IsNullOrWhiteSpace(nombre))
            return numero + " - " + nombre;

        if (!string.IsNullOrWhiteSpace(nombre))
            return nombre;

        if (!string.IsNullOrWhiteSpace(numero))
            return numero;

        return "Room " + room.Id.Value.ToString();
    }

    private double MetrosAPies(double metros)
    {
        return metros / 0.3048;
    }

    // =========================================================
    // FILTROS DE SELECCIÓN
    // =========================================================

    private class FiltroSeleccionRoomMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            Room room = elem as Room;

            if (room == null)
                return false;

            try
            {
                return room.Area > 0;
            }
            catch
            {
                return true;
            }
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }
}
