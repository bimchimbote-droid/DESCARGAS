# Corrección de Tarrajeo: separaciones de milímetros y sólidos unidos

## Base y cambios locales

Esta actualización continúa sobre la copia actual de bimchimbote-droid/MYG_v27_reestructurado, commit fuente 56682a0299f9cb62dacecce6ef269a13c864c4b3, rama local work. Conserva los cambios locales de la entrega anterior MYG_ADDIN_ACTUALIZACION_20261109_182724.zip, publicada en DESCARGAS commit 9bd583210f8ac7c71e6ab736ce74a29ee00ff64c, SHA-256 071cc58dbfc0ba134cbd246c71efe53767c5472423e13897141151b1244d783a. Solo los cuatro archivos de aplicación/pruebas/documentación enumerados cambian desde aquella entrega. No se revirtió ni reemplazó la copia por MYG_v27/main (ref consultado anteriormente a41d354e8206e401a881aacfff3f5da7dfe74d00).

El ZIP es incremental respecto de esa entrega: no incluye SeleccionarCarasHandler.cs, Tarrajeo_SuelosHandler.cs ni test_tarrajeo_selection.py porque no cambiaron. Conservar sus versiones anteriores. El archivo completo de muros sí incluye las correcciones anteriores de ese handler. No se modificaron proyecto, solución, paquetes, recursos, comandos, botones ni namespaces. No hay eliminaciones.

## Qué cambia

- Se descartan cajas y proyecciones demostrablemente fuera del perfil antes de intentar operaciones geométricas sobre ellas.
- Se recorta cada sólido entre los dos planos físicos del espesor exterior. No se hace primero la intersección con todo el perímetro de la cara, que puede producir aristas coincidentes y láminas en uniones o contactos próximos.
- CutWithHalfSpace usa sólidos temporales; no se mueven ni desunen elementos ni se modifican los sólidos cacheados. Si los planos fallan, se intenta la intersección exacta anterior. Si ambos fallan, se informa; un fallo no se interpreta como espacio libre.
- Las tolerancias de cruces ahora comparan distancias con distancias, y la igualdad de puntos usa distancia radial. Se distinguen extremos y separaciones de milímetros sin aumentar PTOL.
- Los avisos muestran etapa, espesor y origen de extracción: ID, categoría y vínculo cuando corresponde. Puede incluir geometría de dependientes; no se afirma que el ID sea el subelemento exacto. No se registran nombres ni rutas de modelos.
- Se conservan la alternativa de paños rectangulares libres, los huecos del perfil y la selección continua hasta Esc.

Una separación normal de 2 mm NO excluye al suelo si el tarrajeo tiene 15 mm y lo alcanza: ese volumen sí debe descontarse. Si el sólido está fuera del espesor o del área UV real, no debe recortar ni cerrarse artificialmente el hueco. La captura no permite concluir cuál elemento concreto causaba el fallo anterior; no se ha reproducido el modelo original dentro de Revit.

## Archivos e instalación

Consultar ENTREGA/ARCHIVOS.json para las rutas, acciones y SHA-256 individuales.

1. Cerrar Revit y respaldar la solución y DLL actuales.
2. Comparar tus modificaciones locales o posteriores. Reemplazar el .cs completo puede sobrescribirlas; integrar con comparación/merge si existen diferencias propias.
3. Reemplazar únicamente MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs conservando su ruta. Ya está incluido en MYG/MYG.csproj; no volver a incorporarlo. Conservar selector y handler de suelos de la entrega anterior.
4. Alternativa al reemplazo del .cs: desde la raíz de la solución compatible con el ZIP anterior, ejecutar `git apply --check RUTA/ENTREGA/ACTUALIZACION.patch` y luego `git apply RUTA/ENTREGA/ACTUALIZACION.patch`. El parche solo modifica el handler de muros y se validó contra su versión anterior; reproduce el archivo final byte por byte. No aplicar además el parche después de copiar el .cs. Si falla la comprobación, comparar/integrar sin forzar.
5. Reemplazar la guía y el script UV, y crear el nuevo script de espesor si se desean conservar las comprobaciones. Son pruebas externas; NO agregarlas a la compilación del add-in. No hay proyecto de pruebas Revit ni dependencias nuevas.
6. Compilar la solución sobre Windows con sus referencias reales. Cerrar Revit para actualizar la DLL de una instalación de prueba y comprobar una copia del modelo de la captura. Conservar el manifiesto .addin, iconos y dependencias existentes. No se entrega una DLL nueva.

## Configuración

No se necesitan referencias ni paquetes nuevos. Se conservan .NET Framework 4.8, referencias Revit 2027 y COM Office/Excel del proyecto actual, cuya compatibilidad debe verificarse con la instalación Windows. CutWithHalfSpace y Plane.CreateByNormalAndOrigin están presentes en la API referenciada; no se migró el proyecto.

## Validación realizada

- Análisis Roslyn C# 7.3: los 179 archivos activos pasan sin errores sintácticos; no equivale a compilar el add-in.
- Pruebas UV: 2467 comprobaciones aprobadas, incluidos 1/2/3 mm, perfiles girados, tangencias, divisiones, huecos y ausencia de solapamiento.
- Pruebas de espesor: 112 comprobaciones aprobadas. Verifican planos, cajas, separaciones, proyecciones, fuente inmutable y alternativas ante fallos con sustitutos de API; no ejecutan el kernel de Revit.
- Regresión de selección anterior: 33 comprobaciones aprobadas, sin modificar ese script ni los handlers de selector/suelo.
- git diff --check: limpio. Parche incremental aplicado en una carpeta temporal y comparado con el archivo final: idéntico.

Para repetir con Python 3 y un SDK .NET 8 o posterior ya instalado (sin restaurar/descargar paquetes):

```sh
python Pruebas/probar_geometria_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
python Pruebas/probar_espesor_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
```

Ambos scripts admiten --help. Fueron ejecutados en Linux; usar rutas compatibles, WSL o adaptar las rutas del SDK para otros sistemas.

## Pendiente en Revit y limitaciones

No se compiló el add-in completo ni se generó una DLL: la máquina es Linux, sin Revit, MSBuild de .NET Framework ni registro COM Office. Las pruebas usan sustitutos de API. Falta probar los booleanos, perfiles, uniones, transacciones y ExternalEvent reales con el modelo de la captura.

Repetir los casos de Documentacion/PRUEBAS_TARRAJEO_RECORTE.md: separaciones en U/V y normal de 1/2/3 mm, sólidos realmente dentro del espesor, vínculos movidos/girados, ocultación y copia del modelo con unión y sin unión. Si aún aparece el aviso, sus nuevos ID/categoría/etapa permiten localizar el cortante. Geometrías no representables por Revit pueden seguir omitiéndose con aviso; cerrar permite continuar.

## GitHub

Solo se publica este ZIP en una ruta nueva de bimchimbote-droid/DESCARGAS. No se actualizan ramas de MYG_v27 ni MYG_v27_reestructurado, ni se instalan cambios en tu PC. Conservar entregas anteriores.

En Visual Studio revisar Cambios de Git, comparar los archivos y hacer Commit local. Si decides sincronizar tu código, verificar repositorio/rama y usar Push bajo tu autorización. Esta entrega no ejecuta ese Push. El enlace fijado al commit y la verificación de descarga/SHA-256 se informan en la respuesta.
