#!/usr/bin/env python3
"""Regresiones del espesor físico con helpers extraídos del código real.

Los sustitutos de XYZ, Plane y Solid representan cajas ortogonales/orientadas.
Comprueban signos, límites, exclusiones y reintentos; no reproducen la tolerancia
ni los fallos del kernel de Revit. No descargan SDK, paquetes ni dependencias.
"""
from pathlib import Path
import argparse
import atexit
import json
import re
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dotnet', default=shutil.which('dotnet'), help='Ejecutable de un SDK .NET completo')
args = parser.parse_args()
if not args.dotnet:
    parser.error('Indica --dotnet /ruta/al/sdk/dotnet')
dotnet = Path(args.dotnet).resolve()
sdk_root = dotnet.parent
compilers = sorted((sdk_root / 'sdk').glob('*/Roslyn/bincore/csc.dll'))
refdirs = sorted((sdk_root / 'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net*'))
runtimes = sorted((sdk_root / 'shared/Microsoft.NETCore.App').glob('*'))
if not compilers or not refdirs or not runtimes:
    parser.error('Se requiere el compilador y el reference pack de un SDK completo')
work = Path(tempfile.mkdtemp(prefix='myg-espesor-'))
atexit.register(shutil.rmtree, work)
source = Path(__file__).resolve().parents[1] / 'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs'
text = source.read_text(encoding='utf-8-sig')


def block(pattern):
    match = re.search(pattern, text)
    if not match:
        raise ValueError(pattern)
    start = text.index('{', match.start())
    depth = 1
    end = start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]


names = ['FueraDeCajaPerfil', 'RecortarSolidoAlEspesor', 'RangoSolidoRespectoPlano', 'InterseccionConSondaSegura', 'ProyeccionFueraDePerfil']
methods = [block(r'    private [^\n]+\b' + name + r'\s*\(') for name in names]
constants = re.findall(r'    private const double TOL\s*=.*?;', text)
classes = [block(r'public class ' + name + r'\b') for name in ['MarcoMuro', 'LoopMuro', 'UV2']]
stubs = r'''
public class XYZ {
    public double X, Y, Z;
    public XYZ(double x,double y,double z) {X=x;Y=y;Z=z;}
    public XYZ Multiply(double a) {return new XYZ(X*a,Y*a,Z*a);}
    public XYZ Negate() {return Multiply(-1);}
    public double DotProduct(XYZ b) {return X*b.X+Y*b.Y+Z*b.Z;}
    public double GetLength() {return Math.Sqrt(DotProduct(this));}
    public XYZ Normalize() {return Multiply(1/GetLength());}
    public static XYZ operator +(XYZ a,XYZ b) {return new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}
    public static XYZ operator -(XYZ a,XYZ b) {return new XYZ(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}
}
public class Transform {
    public XYZ Origin, X, Y, Z;
    public Transform(XYZ origin,XYZ x,XYZ y,XYZ z) {Origin=origin;X=x;Y=y;Z=z;}
    public static Transform Identity {get {return new Transform(new XYZ(0,0,0),new XYZ(1,0,0),new XYZ(0,1,0),new XYZ(0,0,1));}}
    public XYZ OfPoint(XYZ p) {return Origin+X.Multiply(p.X)+Y.Multiply(p.Y)+Z.Multiply(p.Z);}
    public XYZ ToLocal(XYZ p) {p=p-Origin;return new XYZ(p.DotProduct(X),p.DotProduct(Y),p.DotProduct(Z));}
}
public class BoundingBoxXYZ {public XYZ Min,Max;public Transform Transform;}
public class Solid {
    public XYZ Min,Max;
    public Transform Tr;
    public bool FailBounds;
    public Solid(double x0,double x1,double y0,double y1,double z0,double z1,Transform tr=null) {
        Min=new XYZ(x0,y0,z0);Max=new XYZ(x1,y1,z1);Tr=tr??Transform.Identity;
    }
    public double Volume {get {return Math.Max(0,Max.X-Min.X)*Math.Max(0,Max.Y-Min.Y)*Math.Max(0,Max.Z-Min.Z);}}
    public BoundingBoxXYZ GetBoundingBox() {
        if(FailBounds) throw new Exception("injected bounding failure");
        return new BoundingBoxXYZ {Min=Min,Max=Max,Transform=Tr};
    }
    public IEnumerable<XYZ> Corners() {
        foreach(double x in new[]{Min.X,Max.X}) foreach(double y in new[]{Min.Y,Max.Y}) foreach(double z in new[]{Min.Z,Max.Z}) yield return Tr.OfPoint(new XYZ(x,y,z));
    }
}
public class Plane {
    public XYZ Normal,Origin;
    public static Plane CreateByNormalAndOrigin(XYZ n,XYZ o) {return new Plane {Normal=n,Origin=o};}
}
public enum BooleanOperationsType {Intersect}
public static class BooleanOperationsUtils {
    public static int CutCalls,IntersectCalls,FailCutAt;
    public static bool FailIntersect;
    public static Solid LastIntersectCandidate;
    public static List<Plane> Planes=new List<Plane>();
    public static void Reset() {CutCalls=0;IntersectCalls=0;FailCutAt=0;FailIntersect=false;LastIntersectCandidate=null;Planes.Clear();}
    public static Solid CutWithHalfSpace(Solid s,Plane p) {
        CutCalls++;Planes.Add(p);
        if(CutCalls==FailCutAt) throw new Exception("injected halfspace failure");
        double[] n={p.Normal.DotProduct(s.Tr.X),p.Normal.DotProduct(s.Tr.Y),p.Normal.DotProduct(s.Tr.Z)};
        int axis=Enumerable.Range(0,3).OrderByDescending(i=>Math.Abs(n[i])).First();
        if(Enumerable.Range(0,3).Any(i=>i!=axis&&Math.Abs(n[i])>1e-8)) throw new Exception("stub accepts only box-axis aligned halfspaces");
        double bound=p.Normal.DotProduct(p.Origin-s.Tr.Origin)/n[axis];
        double[] lo={s.Min.X,s.Min.Y,s.Min.Z},hi={s.Max.X,s.Max.Y,s.Max.Z};
        if(n[axis]>0)lo[axis]=Math.Max(lo[axis],bound);else hi[axis]=Math.Min(hi[axis],bound);
        return new Solid(lo[0],hi[0],lo[1],hi[1],lo[2],hi[2],s.Tr);
    }
    public static Solid ExecuteBooleanOperation(Solid a,Solid b,BooleanOperationsType op) {
        IntersectCalls++;LastIntersectCandidate=b;
        if(FailIntersect)throw new Exception("injected intersection failure");
        var corners=b.Corners().Select(a.Tr.ToLocal).ToArray();
        return new Solid(Math.Max(a.Min.X,corners.Min(p=>p.X)),Math.Min(a.Max.X,corners.Max(p=>p.X)),
            Math.Max(a.Min.Y,corners.Min(p=>p.Y)),Math.Min(a.Max.Y,corners.Max(p=>p.Y)),
            Math.Max(a.Min.Z,corners.Min(p=>p.Z)),Math.Min(a.Max.Z,corners.Max(p=>p.Z)),a.Tr);
    }
}
'''
tests = r'''
    static int passed;
    static void Check(bool ok,string name) {if(!ok)throw new Exception(name);passed++;}
    static void Near(double x,double y,string name) {Check(Math.Abs(x-y)<1e-9,name+" actual="+x+" expected="+y);}
    static void Vector(XYZ x,XYZ y,string name) {Near(x.X,y.X,name+" X");Near(x.Y,y.Y,name+" Y");Near(x.Z,y.Z,name+" Z");}
    MarcoMuro frame=new MarcoMuro {Origen=new XYZ(0,0,0),U=new XYZ(1,0,0),V=new XYZ(0,1,0),Normal=new XYZ(0,0,1)};
    LoopMuro Profile(MarcoMuro f=null) {return new LoopMuro {Marco=f??frame,MinU=0,MaxU=10,MinV=0,MaxV=10};}
    Solid Probe(Transform tr=null) {return new Solid(0,10,0,10,-0.05,0.05,tr);}
    Solid Clip(Solid s,Solid probe=null,MarcoMuro f=null) {f=f??frame;return RecortarSolidoAlEspesor(s,probe??Probe(),f,f.Normal,0.1);}
    void NoCut(Solid s,string name) {
        BooleanOperationsUtils.Reset();Check(Clip(s)==null,name);
        Check(BooleanOperationsUtils.CutCalls==0&&BooleanOperationsUtils.IntersectCalls==0,name+" no API calls");
    }
    public void Run() {
        double lo,hi;
        var s=new Solid(2,7,3,9,-1,1);
        Check(RangoSolidoRespectoPlano(s,frame.Origen,frame.Normal,out lo,out hi),"range available");Near(lo,-1,"range low");Near(hi,1,"range high");
        Check(RangoSolidoRespectoPlano(s,frame.Origen,frame.Normal.Negate(),out lo,out hi),"negative normal range");Near(lo,-1,"negative low");Near(hi,1,"negative high");
        BooleanOperationsUtils.Reset();var c=Clip(s);
        Near(c.Min.Z,-0.05,"keeps positive side of back plane");Near(c.Max.Z,0.05,"keeps negative side of front plane");Near(c.Volume,3,"only physical slab remains");
        Check(BooleanOperationsUtils.CutCalls==2,"both physical planes used");
        Vector(BooleanOperationsUtils.Planes[0].Normal,frame.Normal,"first plane inward normal");
        Vector(BooleanOperationsUtils.Planes[0].Origin,new XYZ(0,0,-0.05),"first plane at back");
        Vector(BooleanOperationsUtils.Planes[1].Normal,frame.Normal.Negate(),"second plane inward normal");
        Vector(BooleanOperationsUtils.Planes[1].Origin,new XYZ(0,0,0.05),"second plane at front");
        Near(s.Min.Z,-1,"original solid low unchanged");Near(s.Max.Z,1,"original solid high unchanged");Near(s.Volume,60,"original volume unchanged");Check(!Object.ReferenceEquals(s,c),"cut produces copy");
        BooleanOperationsUtils.Reset();var inside=new Solid(2,7,3,9,-0.01,0.02);Check(Object.ReferenceEquals(inside,Clip(inside)),"already inside retained");Check(BooleanOperationsUtils.CutCalls==0,"inside does not invoke cut");
        BooleanOperationsUtils.Reset();var front=Clip(new Solid(2,7,3,9,0,1));Near(front.Min.Z,0,"front-only overlap low");Near(front.Max.Z,0.05,"front-only overlap high");Check(BooleanOperationsUtils.CutCalls==1,"front-only one plane");
        BooleanOperationsUtils.Reset();var back=Clip(new Solid(2,7,3,9,-1,0));Near(back.Min.Z,-0.05,"back-only overlap low");Near(back.Max.Z,0,"back-only overlap high");Check(BooleanOperationsUtils.CutCalls==1,"back-only one plane");
        NoCut(new Solid(2,7,3,9,-1,-0.05),"back tangent skipped");NoCut(new Solid(2,7,3,9,0.05,1),"front tangent skipped");
        for(int mm=1;mm<=3;mm++) {
            double gap=mm/304.8;
            NoCut(new Solid(2,7,3,9,-1,-0.05-gap),"behind "+mm+"mm skipped");
            NoCut(new Solid(2,7,3,9,0.05+gap,1),"beyond "+mm+"mm skipped");
            Check(FueraDeCajaPerfil(new Solid(10+gap,11,2,7,-1,1),Profile()),"U positive gap "+mm);
            Check(FueraDeCajaPerfil(new Solid(-1,-gap,2,7,-1,1),Profile()),"U negative gap "+mm);
            Check(FueraDeCajaPerfil(new Solid(2,7,10+gap,11,-1,1),Profile()),"V positive gap "+mm);
            Check(FueraDeCajaPerfil(new Solid(2,7,-1,-gap,-1,1),Profile()),"V negative gap "+mm);
            Check(!FueraDeCajaPerfil(new Solid(10-gap,11,2,7,-1,1),Profile()),"real U overlap "+mm+"mm retained");
            Check(!FueraDeCajaPerfil(new Solid(2,7,10-gap,11,-1,1),Profile()),"real V overlap "+mm+"mm retained");
            BooleanOperationsUtils.Reset();Check(Clip(new Solid(2,7,3,9,0.05-gap,1))!=null,"real normal overlap "+mm+"mm retained");
        }
        Check(FueraDeCajaPerfil(new Solid(10,11,2,7,-1,1),Profile()),"U tangent skipped");
        Check(FueraDeCajaPerfil(new Solid(2,7,10,11,-1,1),Profile()),"V tangent skipped");
        // Translated 45-degree box verifies all eight transformed bbox corners.
        double a=Math.Sqrt(0.5);var tr=new Transform(new XYZ(100,40,2),new XYZ(a,a,0),new XYZ(-a,a,0),new XYZ(0,0,1));
        var rotated=new Solid(-2,3,-4,5,-1,1,tr);
        Check(RangoSolidoRespectoPlano(rotated,tr.Origin,new XYZ(1,0,0),out lo,out hi),"rotated range available");Near(lo,-7*a,"rotated world X low");Near(hi,7*a,"rotated world X high");
        Check(RangoSolidoRespectoPlano(rotated,tr.Origin,tr.X,out lo,out hi),"rotated local U available");Near(lo,-2,"rotated local U low");Near(hi,3,"rotated local U high");
        var rf=new MarcoMuro {Origen=tr.Origin,U=tr.X,V=tr.Z,Normal=tr.Y};
        var orientedCandidate=new Solid(2,7,-1,1,3,9,tr);var orientedProbe=new Solid(0,10,-0.05,0.05,0,10,tr);
        BooleanOperationsUtils.Reset();var rc=Clip(orientedCandidate,orientedProbe,rf);Near(rc.Min.Y,-0.05,"rotated normal slab low");Near(rc.Max.Y,0.05,"rotated normal slab high");Near(orientedCandidate.Min.Y,-1,"rotated source unchanged");
        Check(FueraDeCajaPerfil(new Solid(10+1/304.8,11,-1,1,2,7,tr),Profile(rf)),"rotated U gap skipped");
        Check(!FueraDeCajaPerfil(new Solid(10-1/304.8,11,-1,1,2,7,tr),Profile(rf)),"rotated U overlap retained");
        // If either halfspace fails, the fallback must use the original solid.
        foreach(int failAt in new[]{1,2}) {
            BooleanOperationsUtils.Reset();BooleanOperationsUtils.FailCutAt=failAt;var fallback=Clip(s);
            Near(fallback.Min.Z,-0.05,"fallback slab low "+failAt);Near(fallback.Max.Z,0.05,"fallback slab high "+failAt);
            Check(BooleanOperationsUtils.IntersectCalls==1,"fallback intersection called "+failAt);
            Check(Object.ReferenceEquals(BooleanOperationsUtils.LastIntersectCandidate,s),"fallback uses original candidate "+failAt);
            Near(s.Volume,60,"fallback original volume unchanged "+failAt);
            BooleanOperationsUtils.Reset();BooleanOperationsUtils.FailCutAt=failAt;BooleanOperationsUtils.FailIntersect=true;bool threw=false;
            try{Clip(s);}catch(InvalidOperationException ex){threw=ex.Message.Contains("planos")&&ex.InnerException!=null;}
            Check(threw,"both algorithms failing must report error "+failAt);
        }
        var boundsFail=new Solid(2,7,3,9,-1,1){FailBounds=true};BooleanOperationsUtils.Reset();
        Near(Clip(boundsFail).Volume,3,"bounding failure still tries exact probe");Check(BooleanOperationsUtils.IntersectCalls==1,"bounding failure intersection called");
        Check(!FueraDeCajaPerfil(boundsFail,Profile()),"unavailable range cannot pretend separation");
        Check(ProyeccionFueraDePerfil(new[]{new XYZ(10.001,2,0),new XYZ(11,2,0),new XYZ(10.001,5,0)},frame,Profile()),"remote triangle bbox skipped");
        Check(!ProyeccionFueraDePerfil(new[]{new XYZ(9.999,2,0),new XYZ(11,2,0),new XYZ(9.999,5,0)},frame,Profile()),"overlapping triangle retained");
        Check(ProyeccionFueraDePerfil(new[]{new XYZ(10,2,0),new XYZ(10,4,0),new XYZ(10,5,0)},frame,Profile()),"tangent triangle skipped");
        Check(!ProyeccionFueraDePerfil(new XYZ[0],frame,Profile()),"empty projection cannot prove separation");
        for(int mm=1;mm<=3;mm++) {
            double gap=mm/304.8;
            Check(ProyeccionFueraDePerfil(new[]{new XYZ(2,10+gap,0),new XYZ(4,10+gap,0),new XYZ(2,11,0)},frame,Profile()),"triangle V gap "+mm+"mm skipped");
            Check(!ProyeccionFueraDePerfil(new[]{new XYZ(2,10-gap,0),new XYZ(4,10-gap,0),new XYZ(2,11,0)},frame,Profile()),"triangle V overlap "+mm+"mm retained");
            var pts=new[]{tr.OfPoint(new XYZ(10+gap,0,2)),tr.OfPoint(new XYZ(11,0,2)),tr.OfPoint(new XYZ(10+gap,0,5))};
            Check(ProyeccionFueraDePerfil(pts,rf,Profile(rf)),"rotated triangle gap "+mm+"mm skipped");
        }
        Console.WriteLine("Espesor: "+passed+" assertions passed (API substitutes, not Revit kernel)");
    }
    static int Main() {try{new Harness().Run();return 0;}catch(Exception ex){Console.Error.WriteLine(ex);return 1;}}
'''
code = '\n'.join(['using System;using System.Collections.Generic;using System.Linq;', stubs, *classes,
                  'class Harness {', *constants, *methods, tests, '}'])
(work / 'Thickness.cs').write_text(code)
refs = list(refdirs[-1].glob('*.dll'))
rsp = work / 'compile.rsp'
rsp.write_text('\n'.join(['-nologo', '-langversion:7.3', '-nostdlib+', '-target:exe', '-out:' + str(work / 'Thickness.dll')]
                         + ['-r:' + str(ref) for ref in refs] + [str(work / 'Thickness.cs')]))
subprocess.run([str(dotnet), str(compilers[-1]), '@' + str(rsp)], check=True)
(work / 'Thickness.runtimeconfig.json').write_text(json.dumps({'runtimeOptions': {'framework': {
    'name': 'Microsoft.NETCore.App', 'version': runtimes[-1].name}}}))
subprocess.run([str(dotnet), str(work / 'Thickness.dll')], check=True)
