# Corrección CS1061: IntentarRecortarPerfilPlanar

## Causa y versión de trabajo
La entrega MYG_ADDIN_ACTUALIZACION_20261109_191524.zip partió del commit fuente56682a0299f9cb62dacecce6ef269a13c864c4b3 de bimchimbote-droid/MYG_v27_reestructurado/master, omitiendo avances publicados posteriormente como ZIP. Al sustituir el handler de muros eliminó el método público que Tarrajeo_SuelosHandler.cs de la entrega190311 invoca en línea922.
Se recuperó el handler completo de MYG_ADDIN_ACTUALIZACION_20261109_190311.zip, publicado en DESCARGAS commit83915c8d0db803d26815342ff7a2d02a4eb1c468, SHA2564e21aab7d00d13c4760f7415799ac2eab38518d46de93e88e5831ee8339e209e, y se fusionó la orientación exterior anterior. No se añadió un método vacío ni se anuló el respaldo planar. Fuera de las dos zonas de orientación, el archivo final es byte por byte igual al handler190311.

## Archivos afectados
| Acción | Ruta | Descripción |
|---|---|---|
| REEMPLAZAR | MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs | Recupera método público, motor completo y avances acumulados, manteniendo orientación exterior de pintura. |
| MODIFICAR, alternativa al reemplazo | Misma ruta, mediante CAMBIOS.patch | Parche comprobado sobre el archivo del ZIP191524. No aplicar ambas opciones. |
| CREAR, opcional | Tests/ContratoRecortePlanar/ | Proyecto independiente de comprobación del contrato entre handlers; ver README y RELACION_ARCHIVOS.json. No incorporar al add-in. |

TarrajeoForm.cs y Tarrajeo_SuelosHandler.cs: SIN CAMBIOS y fuera del ZIP. Conserva el formulario del ZIP191524 y el archivo actual de suelos de la entrega190311. El archivo de suelos incluido en el commit fuente antiguo no contiene esa llamada y no es la base utilizada para verificar el contrato. Proyecto, paquetes, referencias, recursos y demás código SIN CAMBIOS. No hay eliminaciones.

## Instalación
1. Cierra Revit y respalda el handler y la solución actuales.
2. Extrae el ZIP temporalmente y sustituye SOLAMENTE Tarrajeo_MurosHandler.cs en su ruta indicada. Ya está incluido en el proyecto. No reemplaces el archivo de suelos ni el formulario.
3. Como alternativa al paso2: desde la raíz del código ejecuta git apply --check RUTA/CAMBIOS.patch y después git apply RUTA/CAMBIOS.patch. Está probado contra el archivo del ZIP191524; si no coincide, combina los cambios sin forzar. Reemplazar archivos completos puede sobrescribir modificaciones locales/posteriores; compáralas antes.
4. En Visual Studio usa Limpiar solución y Recompilar solución. No se requieren paquetes ni referencias nuevos. No copies Tests/ al proyecto MYG.
5. La compilación completa y las pruebas funcionales siguen requiriendo Windows, MSBuild de .NET Framework, COM y Revit con las referencias de tu instalación. Con Revit cerrado actualiza la DLL compilada en tu instalación de prueba; conserva manifiesto.addin, iconos y dependencias. No se entrega DLL nueva.

## Verificación
Ver VALIDACION.md. La comprobación del contrato utiliza la llamada real de suelos190311. El aviso visible de conflicto System.Text.Encoding.CodePages es distinto del error CS1061; esta corrección no actualiza dependencias ni asegura que desaparezcan las advertencias restantes.
Prueba en una copia del modelo el respaldo de suelos inclinados ante recortes fallidos, huecos/islas y selección continua, además de los buscadores y orientación de pintura en muros rectos/curvos, con y sin unión y vínculos. Los muros existentes no se reorientan automáticamente.

## GitHub
Se publica solo este ZIP en una ruta nueva de bimchimbote-droid/DESCARGAS por autorización vigente. Se conservan las entregas anteriores. No se hace commit ni push al repositorio del código. Publicar el ZIP no instala cambios en tu PC ni actualiza MYG_v27/MYG_v27_reestructurado. En Visual Studio revisa Cambios de Git y el diff; después de compilar/probar puedes hacer Commit y Push cuando decidas sincronizar tu código.
