# Validación de la corrección CS1061

## Reproducción y corrección enfocada
El análisis semántico Roslyn de los archivos reales con metadatos reales RevitAPI/RevitAPIUI reproduce CS1061 en la invocación de la línea922 del suelo190311 al usar el muro incompatible191524. Con el muro acumulado corregido se verifica firma pública bool, doce parámetros, tres out, tolerancia opcional y resolución de la llamada al método declarado: cero fallos en esa comprobación. Se excluyen expresamente los diagnósticos ajenos a la llamada; no es compilación completa.

## Preservación y regresiones
- Revisión independiente del diff: respecto del muro190311 solo cambian las dos zonas previstas de orientación. Fuera de ellas el archivo es idéntico byte por byte; el método planar y su motor se conservan íntegros.
- 10656 aserciones de geometría UV aprobadas, usando el script anterior y los métodos extraídos del muro final.
- 575 aserciones del adaptador planar inclinado aprobadas, usando el script anterior con motor programado.
- 15/15 pruebas de orientación aprobadas con helper real y dobles API.
- Roslyn C#7.3:179 fuentes activas sin errores sintácticos;9recursos y3None presentes sin duplicados en el checkout. El contrato se valida aparte con el suelo190311 del usuario.
- git diff --check correcto. El parche sobre el archivo191524 reconstruye el archivo final byte por byte.

Las pruebas anteriores de geometría y orientación se ejecutaron sin modificarlas y no se repiten en el ZIP. Sus archivos corresponden a las entregas190311 y191524. La nueva prueba de contrato sí se incluye. No se ejecutó en este intento la prueba anterior de integración de suelos fijada a .NET8; no se atribuyen a este intento sus resultados históricos.

## Compilación y pruebas pendientes
Compilación completa intentada en Linux: bloqueada por MSB4803 ResolveComReference, que exige MSBuild de .NET Framework/Windows. Advertencia preexistente EPPlus.Interfaces reproducida. No se produjo DLL nueva ni se certifica compilación completa. La advertencia System.Text.Encoding.CodePages visible en la captura es independiente del CS1061 corregido.
No se ejecutó Windows/WinForms nativo ni Revit. Los tests con dobles no prueban el kernel, transacciones, uniones, recortes de modelos ni materiales reales. Compilar en Visual Studio y probar en Revit el respaldo planar, huecos/islas, selección continua, buscadores y orientación en modelos de prueba.
