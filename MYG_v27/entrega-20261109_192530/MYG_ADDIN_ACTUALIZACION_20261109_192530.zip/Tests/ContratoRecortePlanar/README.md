# Contrato semántico entre los handlers de suelos y muros

Prueba enfocada del error CS1061 comunicado. Requiere SDK .NET 10 y las DLL reales de la API de Revit. No añade paquetes NuGet y no debe incorporarse al proyecto del add-in.

Desde la raíz del código:

```sh
dotnet run --project Tests/ContratoRecortePlanar -- .
```

Por defecto lee los dos handlers en `MYG/Funcionalidades/Estructuras/Tarrajeo/` y las referencias del repositorio en `MYG/%APPDATA%/Autodesk/Revit/Addins/2027/MYG/`. Si las DLL están en una instalación local, añade `--api-dir "C:\Program Files\Autodesk\Revit 2027"`. Se necesitan `RevitAPI.dll` y `RevitAPIUI.dll` de esa misma instalación.

Para contrastar versiones sin reemplazar archivos, se admiten `--wall /ruta/al/archivo.cs` y `--floor /ruta/al/archivo.cs`. La prueba no escribe archivos de producción.

Roslyn analiza los dos archivos completos, obtiene la declaración real de `IntentarRecortarPerfilPlanar` y resuelve semánticamente cada invocación real desde suelos mediante `SemanticModel.GetSymbolInfo`. Comprueba que sea pública, devuelva bool, conserve los doce parámetros, sus tipos, las tres salidas `out` y la tolerancia opcional. También exige que no haya errores semánticos en la invocación. No sustituye el método por una copia ni usa dobles de los tipos de API.

Un método ausente o una llamada incompatible provoca salida distinta de cero y muestra el diagnóstico. La versión incompatible de la entrega anterior falla con CS1061; la versión acumulada corregida debe terminar con `0 failure(s)`.

**Alcance:** se verifican la firma y el enlace entre esos archivos con metadatos reales. Los diagnósticos ajenos a la invocación se excluyen deliberadamente; esta prueba no compila el add-in completo, no valida el motor geométrico ni ejecuta Windows o Revit. Sigue siendo necesaria la compilación de la solución en Visual Studio y la prueba funcional.
