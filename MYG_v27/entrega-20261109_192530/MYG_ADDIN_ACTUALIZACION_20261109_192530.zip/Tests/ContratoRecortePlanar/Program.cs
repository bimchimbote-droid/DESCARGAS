using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

// A focused semantic check of the real cross-file API. This does not build
// the complete add-in or execute Autodesk Revit.
if (args.Length == 0)
{
    Console.Error.WriteLine("Usage: Contract <repository> [--wall <file>] [--floor <file>] [--api-dir <directory>]");
    return 2;
}

try
{
    string root = Path.GetFullPath(args[0]);
    string wallFile = Path.Combine(root, "MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs");
    string floorFile = Path.Combine(root, "MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs");
    string apiDirectory = Path.Combine(root, "MYG/%APPDATA%/Autodesk/Revit/Addins/2027/MYG");
    for (int i = 1; i < args.Length; i += 2)
    {
        if (i + 1 >= args.Length) throw new ArgumentException("Missing option value.");
        switch (args[i])
        {
            case "--wall": wallFile = Path.GetFullPath(args[i + 1]); break;
            case "--floor": floorFile = Path.GetFullPath(args[i + 1]); break;
            case "--api-dir": apiDirectory = Path.GetFullPath(args[i + 1]); break;
            default: throw new ArgumentException("Unknown option: " + args[i]);
        }
    }

    var parseOptions = new CSharpParseOptions(LanguageVersion.CSharp7_3,
        preprocessorSymbols: new[] { "DEBUG", "TRACE" });
    var wallTree = CSharpSyntaxTree.ParseText(File.ReadAllText(wallFile), parseOptions, wallFile);
    var floorTree = CSharpSyntaxTree.ParseText(File.ReadAllText(floorFile), parseOptions, floorFile);
    var referencePaths = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!)
        .Split(Path.PathSeparator).ToList();
    foreach (string file in new[] { "RevitAPI.dll", "RevitAPIUI.dll" })
    {
        string path = Path.Combine(apiDirectory, file);
        if (!File.Exists(path)) throw new FileNotFoundException("Required API metadata not found. Use --api-dir.", path);
        referencePaths.Add(path);
    }
    var references = referencePaths.Distinct(StringComparer.OrdinalIgnoreCase)
        .Select(path => MetadataReference.CreateFromFile(path));
    var compilation = CSharpCompilation.Create("PlanarContractCheck",
        new[] { wallTree, floorTree }, references,
        new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
    var wallModel = compilation.GetSemanticModel(wallTree);
    var floorModel = compilation.GetSemanticModel(floorTree);
    int failures = 0;

    var declarations = wallTree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()
        .Where(node => node.Identifier.ValueText == "IntentarRecortarPerfilPlanar").ToArray();
    IMethodSymbol? declarationSymbol = declarations.Length == 1
        ? wallModel.GetDeclaredSymbol(declarations[0]) : null;
    if (declarationSymbol == null)
    {
        Console.Error.WriteLine("FAIL: expected exactly one declared IntentarRecortarPerfilPlanar method.");
        failures++;
    }
    else
    {
        string[] types = {
            "Autodesk.Revit.DB.Document", "Autodesk.Revit.DB.View", "Autodesk.Revit.DB.Element",
            "System.Collections.Generic.IList<Autodesk.Revit.DB.CurveLoop>",
            "Autodesk.Revit.DB.XYZ", "Autodesk.Revit.DB.XYZ", "double",
            "System.Collections.Generic.List<Autodesk.Revit.DB.Solid>",
            "System.Collections.Generic.List<System.Collections.Generic.List<Autodesk.Revit.DB.CurveLoop>>",
            "bool", "string", "double"
        };
        bool signatureMatches = declarationSymbol.ContainingType.Name == "Tarrajeo_MurosHandler"
            && declarationSymbol.DeclaredAccessibility == Accessibility.Public
            && !declarationSymbol.IsStatic
            && declarationSymbol.ReturnType.SpecialType == SpecialType.System_Boolean
            && declarationSymbol.Parameters.Length == types.Length;
        for (int i = 0; i < declarationSymbol.Parameters.Length && i < types.Length; i++)
        {
            var parameter = declarationSymbol.Parameters[i];
            signatureMatches &= parameter.Type.ToDisplayString() == types[i];
            signatureMatches &= parameter.RefKind == (i >= 8 && i <= 10 ? RefKind.Out : RefKind.None);
        }
        if (declarationSymbol.Parameters.Length == types.Length)
        {
            var tolerance = declarationSymbol.Parameters[11];
            signatureMatches &= tolerance.IsOptional && tolerance.HasExplicitDefaultValue
                && tolerance.ExplicitDefaultValue is double d && d == 0.0;
        }
        if (!signatureMatches)
        {
            Console.Error.WriteLine("FAIL: public planar API signature mismatch: " + declarationSymbol.ToDisplayString());
            failures++;
        }
        else Console.WriteLine("PASS: real public planar API signature (12 parameters; out results; optional tolerance).");
    }

    var calls = floorTree.GetRoot().DescendantNodes().OfType<InvocationExpressionSyntax>()
        .Where(node => node.Expression is MemberAccessExpressionSyntax member
            && member.Name.Identifier.ValueText == "IntentarRecortarPerfilPlanar").ToArray();
    if (calls.Length == 0)
    {
        Console.Error.WriteLine("FAIL: no real floor call to IntentarRecortarPerfilPlanar was found.");
        failures++;
    }
    foreach (var call in calls)
    {
        var info = floorModel.GetSymbolInfo(call);
        bool binds = info.Symbol is IMethodSymbol called
            && declarationSymbol != null
            && SymbolEqualityComparer.Default.Equals(called.OriginalDefinition, declarationSymbol.OriginalDefinition)
            && info.CandidateReason == CandidateReason.None;
        int line = floorTree.GetLineSpan(call.Span).StartLinePosition.Line + 1;
        if (!binds)
        {
            Console.Error.WriteLine($"FAIL: floor invocation at line {line} does not bind to the real wall method ({info.CandidateReason}).");
            failures++;
        }
        else Console.WriteLine($"PASS: real floor invocation at line {line} binds to the wall declaration.");

        // Restrict diagnostics to the actual invocation: unrelated dependencies
        // elsewhere in these two full files are outside this contract test.
        var callErrors = floorModel.GetDiagnostics(call.Span)
            .Where(item => item.Severity == DiagnosticSeverity.Error).ToArray();
        foreach (var error in callErrors)
        {
            Console.Error.WriteLine("FAIL: call-site diagnostic " + error);
            failures++;
        }
        if (callErrors.Length == 0) Console.WriteLine($"PASS: no semantic errors at floor invocation line {line}.");
    }

    Console.WriteLine($"Planar cross-file contract: {calls.Length} real invocation(s); {failures} failure(s).");
    Console.WriteLine("Scope: real source signature and call binding with actual API metadata; not a full add-in build or a Revit runtime test.");
    return failures == 0 ? 0 : 1;
}
catch (Exception exception)
{
    Console.Error.WriteLine("Contract check could not run: " + exception.Message);
    return 2;
}
