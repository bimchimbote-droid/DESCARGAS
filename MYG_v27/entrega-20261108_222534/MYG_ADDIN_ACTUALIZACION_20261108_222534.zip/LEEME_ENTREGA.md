# Corrección de compilación CS1061: fase del Room

## A. Problema y corrección

La entrega anterior introdujo `room.Phase`, una propiedad que NO existe en la API de Revit. Las pruebas anteriores simulaban esa propiedad y no detectaron la incompatibilidad. El error de Visual Studio es correcto.

La corrección cambia exclusivamente ObtenerFaseValidaRoom: lee primero `BuiltInParameter.ROOM_PHASE_ID`; si ese parámetro falta o no es ElementId, consulta `ROOM_PHASE` solo si realmente almacena ElementId. Antes de devolver el ID, comprueba que no sea inválido y que `doc.GetElement(id)` sea una Phase existente. No utiliza Room.Phase, Room.CreatedPhaseId ni supone la última fase o la fase de la vista.

Se conservan la selección directa de muros, el tipo del zócalo nuevo, la colocación exterior hacia el apoyo del ladrillo, el recorte por altura y la conservación de los paños superiores. La ventana no cambia y no se incluye de nuevo.

## Base utilizada

Checkout bimchimbote-droid/MYG_v27_reestructurado HEAD da11b13a3f5ce35b9565bf4d5bd27cb761091102, con todas las modificaciones locales anteriores. El handler de partida coincide byte por byte con el ZIP de DESCARGAS en commit b73b24819ac63379733b07781a7ba454a9ef8ce5, MYG_v27/entrega-20261108_220946/MYG_ADDIN_ACTUALIZACION_20261108_220946.zip. No se reemplazó por main de MYG_v27.

SHA-256 handler anterior: c91de29a48da574527f72b596d05bb0440ecc642120ef25de4f63cf90c833727
SHA-256 handler corregido: 46f539460173c2ef98e1cdd2a7742d3202890bb49c58a4f8345c94b84ac208d0

## B. Intervenciones

| Ruta exacta | Acción | Uso |
| --- | --- | --- |
| MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs | REEMPLAZAR | Archivo completo con el único método corregido. |
| CORREGIR_FASE_ROOM.patch | CREAR, alternativa | Parche puntual del mismo método. No aplicar además del reemplazo completo. |
| tests/FaseRoom/Regression.csproj | CREAR, prueba opcional | Proyecto .NET 8 independiente. |
| tests/FaseRoom/PhaseDoubles.cs | CREAR, prueba opcional | Dobles sin propiedad Room.Phase. |
| tests/FaseRoom/Program.cs | CREAR, prueba opcional | 13 regresiones de lectura/validación de fase. |
| tests/FaseRoom/extract_phase.py | CREAR, prueba opcional | Extrae el método real del handler final. |
| tests/FaseRoom/run.sh | CREAR, prueba opcional | Ejecutor. |
| tests/FaseRoom/README.md | CREAR, documentación | Alcance de pruebas. |
| tests/CompatibilidadApi/Check.csproj | CREAR, prueba opcional | Verificador Roslyn contra DLL reales de Revit. |
| tests/CompatibilidadApi/Program.cs | CREAR, prueba opcional | Compila el handler o solamente el método de fase. |
| tests/CompatibilidadApi/FormStub.txt | CREAR, prueba opcional | Adaptador de ventana solo para el chequeo aislado; no reemplaza la ventana del add-in. |
| tests/CompatibilidadApi/README.md | CREAR, documentación | Referencias y ejecución del verificador. |
| LEEME_ENTREGA.md | CREAR, documentación | Este documento. |
| MANIFIESTO.json | CREAR, documentación | Archivos y hashes. |

SIN CAMBIOS y fuera del ZIP: CrearMuroDesdeRoomForm.cs, comando, proyecto, recursos, dependencias, suelos y todas las demás fuentes. No se entrega DLL ni se elimina un archivo del proyecto.

## C/D. Instalación

1. Respalde su handler actual y compare sus cambios locales. Reemplazar el archivo completo puede sobrescribir modificaciones posteriores.
2. Elija UN procedimiento: copiar el handler completo respetando la ruta, O desde la raíz de su solución ejecutar `git apply --check CORREGIR_FASE_ROOM.patch` y después `git apply CORREGIR_FASE_ROOM.patch`. Si el parche no aplica, integre el bloque con comparación de archivos; no fuerce ni pierda sus avances.
3. Mantenga la ventana de selección directa de la entrega anterior. Este ZIP es una corrección incremental de esa entrega. El handler ya figura en MYG.csproj.
4. En Visual Studio, limpie y recompile la solución. Verifique que desapareció CS1061 de Room.Phase. Cierre Revit antes de sustituir su DLL y pruebe en una copia del modelo.
5. No agregue los proyectos de pruebas ni FormStub.txt al add-in.

## E. Configuración

No hay nuevas referencias, paquetes ni cambios de proyecto. Se verificó en los metadatos de RevitAPI 23.0.0.0 y 27.0.4.0 que existen ROOM_PHASE_ID, ROOM_PHASE y el acceso a parámetros usado. La comprobación semántica utiliza referencias externas solo en un proyecto de prueba aislado; no retargetea ni modifica su proyecto original.

## F. Validación ejecutada

- Se reprodujo el CS1061 de la captura compilando el HANDLER ANTERIOR COMPLETO contra las DLL reales de referencia de Revit 2027.
- El HANDLER CORREGIDO COMPLETO compiló en el comprobador aislado contra esa misma API 2027, con 0 errores semánticos y emisión correcta. Solo la ventana se sustituyó por un adaptador de prueba; los tipos y miembros de Revit se comprobaron contra las DLL reales, no contra dobles.
- El método corregido compiló además contra RevitAPI 2023 con referencias de .NET Framework 4.8: 0 errores semánticos.
- 13 regresiones aprobadas, 0 fallidas. Los dobles NO poseen Room.Phase y prohíben leer Room.CreatedPhaseId. Cubren prioridad del parámetro ID, respaldo válido, tipos de almacenamiento incorrectos, ID inválido y elementos que no son fases.
- El parche puntual fue aplicado al archivo anterior y produjo exactamente los mismos bytes del handler completo final. git diff --check sin errores.
- La compilación aislada NO equivale a compilar MYG.csproj con todas sus dependencias/COM en Windows; tampoco ejecuta Revit ni valida la colocación/recorte en el modelo. La solución completa y la prueba funcional siguen pendientes en su equipo.

Las DLL de referencia se obtuvieron de paquetes públicos NuGet Revit_All_Main_Versions_API_x64 2023.0.0 y 2027.0.0 mediante HTTPS. No se ejecutó código Autodesk y no se distribuyen esas DLL en este ZIP.

Para ejecutar las regresiones con SDK .NET 8 y Python 3, desde la raíz extraída:

```bash
bash tests/FaseRoom/run.sh
```

Para repetir la compilación con API real, consulte tests/CompatibilidadApi/README.md y use las referencias correspondientes a su versión de Revit. No cambie el framework del proyecto del add-in solo para ejecutar ese comprobador.

## G. GitHub

La publicación del ZIP en bimchimbote-droid/DESCARGAS no instala cambios en su PC ni actualiza MYG_v27/MYG_v27_reestructurado. No se hizo commit ni push de los repositorios del código. Después de compilar y probar en Visual Studio, revise Git Changes, haga Commit y luego Push cuando decida conservar la corrección.

## H. Límites

Esta entrega corrige únicamente la obtención de fase que impedía compilar. No modifica restricciones o capacidades del recorte de tarrajeos y zócalos. Si el Room no contiene un parámetro de fase ElementId válido, se informa el problema y no se adivina una fase. La selección interactiva, las uniones y el resultado físico deben validarse dentro de Revit.
