using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
partial class Handler
{
    static Parameter IdParameter(long id)=>new(){StorageType=StorageType.ElementId,Value=new ElementId(id)};
    static Parameter TextParameter()=>new(){StorageType=StorageType.String};
    static (Document doc,Room room) Model()
    {
        var doc=new Document();doc.Elements[42]=new Phase{Id=new ElementId(42)};
        return(doc,new Room{Id=new ElementId(100)});
    }
    static void True(bool condition,string label){if(!condition)throw new Exception(label);}
    static void Reject(Action action,string label)
    {
        try{action();}catch(InvalidOperationException){return;}
        throw new Exception("Expected safe rejection: "+label);
    }
    void PrimaryValid()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=IdParameter(42);
        var id=ObtenerFaseValidaRoom(doc,room);
        True(id.Value==42,"primary phase ID returned");
        True(room.GenericCreatedPhaseReads==0,"generic invalid CreatedPhaseId was never read");
        True(room.RequestedParameters.SequenceEqual(new[]{BuiltInParameter.ROOM_PHASE_ID}),"dedicated ID parameter prioritized");
    }
    void PrimaryWins()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=IdParameter(42);
        room.Parameters[BuiltInParameter.ROOM_PHASE]=TextParameter();
        True(ObtenerFaseValidaRoom(doc,room).Value==42,"primary valid despite formatted phase name fallback");
        True(room.Parameters[BuiltInParameter.ROOM_PHASE].AsElementIdCalls==0,"formatted phase parameter not read as ID");
    }
    void FallbackMissingPrimary()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE]=IdParameter(42);
        True(ObtenerFaseValidaRoom(doc,room).Value==42,"ElementId fallback used when primary missing");
    }
    void FallbackWrongStorage()
    {
        var(doc,room)=Model();var primary=TextParameter();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=primary;
        room.Parameters[BuiltInParameter.ROOM_PHASE]=IdParameter(42);
        True(ObtenerFaseValidaRoom(doc,room).Value==42,"ElementId fallback used when primary is wrong storage");
        True(primary.AsElementIdCalls==0,"primary string never interpreted as ID");
    }
    void InvalidPrimaryDoesNotInferFallback()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=IdParameter(-1);
        room.Parameters[BuiltInParameter.ROOM_PHASE]=IdParameter(42);
        Reject(()=>ObtenerFaseValidaRoom(doc,room),"invalid primary phase must not be guessed from another parameter");
        True(room.Parameters[BuiltInParameter.ROOM_PHASE].AsElementIdCalls==0,"invalid primary not replaced with arbitrary fallback");
    }
    void TextRejected()
    {
        var(doc,room)=Model();var text=TextParameter();room.Parameters[BuiltInParameter.ROOM_PHASE]=text;
        Reject(()=>ObtenerFaseValidaRoom(doc,room),"phase name string");
        True(text.AsElementIdCalls==0,"never AsElementId on phase name");
    }
    void WrongStorageRejected()
    {
        foreach(var type in new[]{StorageType.None,StorageType.String,StorageType.Double,StorageType.Integer})
        {
            var(doc,room)=Model();var parameter=new Parameter{StorageType=type};room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=parameter;
            Reject(()=>ObtenerFaseValidaRoom(doc,room),"non-ID parameter "+type);
            True(parameter.AsElementIdCalls==0,"non-ID storage never decoded as ID");
        }
    }
    void MissingParameters()
    {
        var(doc,room)=Model();Reject(()=>ObtenerFaseValidaRoom(doc,room),"no phase parameter");
    }
    void MissingPhaseElement()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=IdParameter(999);
        Reject(()=>ObtenerFaseValidaRoom(doc,room),"phase ID absent from document");
    }
    void NonPhaseElement()
    {
        var(doc,room)=Model();doc.Elements[42]=new Element{Id=new ElementId(42)};
        room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=IdParameter(42);
        Reject(()=>ObtenerFaseValidaRoom(doc,room),"ID points at non-Phase element");
    }
    void NullPhaseId()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=new Parameter{StorageType=StorageType.ElementId,Value=null};
        Reject(()=>ObtenerFaseValidaRoom(doc,room),"null phase ID");
    }
    void NullRoom()
    {
        var(doc,room)=Model();Reject(()=>ObtenerFaseValidaRoom(doc,null),"null Room");
    }
    void NullDocument()
    {
        var(doc,room)=Model();room.Parameters[BuiltInParameter.ROOM_PHASE_ID]=IdParameter(42);
        Reject(()=>ObtenerFaseValidaRoom(null,room),"null Document");
    }
    public static void Main()
    {
        var h=new Handler();var cases=new (string,Action)[]{
            ("ROOM_PHASE_ID valid; generic CreatedPhaseId never used",h.PrimaryValid),
            ("dedicated ID wins over formatted phase name",h.PrimaryWins),
            ("ElementId fallback when primary missing",h.FallbackMissingPrimary),
            ("ElementId fallback when primary storage unsupported",h.FallbackWrongStorage),
            ("invalid primary ID not replaced by guessed fallback",h.InvalidPrimaryDoesNotInferFallback),
            ("phase name string rejected without AsElementId",h.TextRejected),
            ("all non-ElementId storage types rejected",h.WrongStorageRejected),
            ("missing phase parameters rejected",h.MissingParameters),
            ("missing Phase element rejected",h.MissingPhaseElement),
            ("non-Phase element ID rejected",h.NonPhaseElement),
            ("null ElementId rejected",h.NullPhaseId),
            ("null Room rejected",h.NullRoom),
            ("null Document rejected",h.NullDocument)};
        foreach(var c in cases){c.Item2();Console.WriteLine("PASS "+c.Item1);}Console.WriteLine($"{cases.Length} passed; 0 failed. Contract doubles only; no Revit integration executed.");
    }
}
