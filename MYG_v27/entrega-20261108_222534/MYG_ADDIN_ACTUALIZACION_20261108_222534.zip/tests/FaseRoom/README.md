# Regresión de lectura de fase del Room

Estas pruebas extraen `ObtenerFaseValidaRoom` desde el handler entregado, sin mantener una copia manual de su implementación. Los dobles de `Room` **no contienen una propiedad `Phase`**: ese miembro inexistente no puede volver a quedar legitimado por una simulación conveniente. El extractor también rechaza explícitamente esa llamada.

Se verifican 13 escenarios: parámetro `ROOM_PHASE_ID` con almacenamiento `ElementId`, prioridad sobre la representación de texto, respaldo `ROOM_PHASE` solamente cuando almacena `ElementId`, rechazo de ID primario inválido sin deducir otra fase, almacenamiento de texto o numérico sin llamada indebida a `AsElementId`, falta de parámetros, fase ausente o de clase incorrecta, ID nulo y entradas nulas. El `CreatedPhaseId` genérico del Room se simula como inválido y su lectura provoca fallo: el método no debe consultarlo.

Requisitos: .NET SDK 8 y Python 3. Si esta carpeta se instala como `tests/FaseRoom`, desde la raíz extraída:

```bash
bash tests/FaseRoom/run.sh
```

También puede indicar el handler de su solución:

```bash
DOTNET_CMD=/ruta/dotnet bash run.sh /ruta/MUROSDEROOM_EJECUTAR_HANDLER.cs
```

`GeneratedPhase.cs`, `bin/` y `obj/` se regeneran; no se incluyen en la entrega. No agregue este proyecto ni sus dobles al add-in.

**Límite:** estas pruebas verifican decisiones del método mediante dobles deterministas; no cargan Autodesk Revit, no crean habitaciones/fases reales ni validan el recorte o la interfaz. La comprobación contra metadatos/referencias reales de Revit se informa por separado; no se presenta esta prueba como compilación completa o integración con el modelo.
