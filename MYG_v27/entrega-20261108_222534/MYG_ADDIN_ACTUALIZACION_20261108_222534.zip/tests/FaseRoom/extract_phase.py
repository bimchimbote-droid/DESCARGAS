#!/usr/bin/env python3
"""Extract the exact private resolver from the delivered production handler."""
from pathlib import Path
import hashlib,re,sys
source_path=Path(sys.argv[1]).resolve()
source=source_path.read_text(encoding='utf-8-sig')
match=re.search(r'^    private ElementId ObtenerFaseValidaRoom\(',source,re.M)
if not match: raise SystemExit('Production phase resolver not found')
end=re.search(r'^    }\s*$',source[match.start():],re.M)
if not end: raise SystemExit('Production phase resolver is not closed')
method=source[match.start():match.start()+end.end()]
if re.search(r'\broom\.Phase\b',method):
    raise SystemExit('Regression detected: Room.Phase is not a supported production API property')
output=Path(__file__).parent/'GeneratedPhase.cs'
output.write_text('// Generated from production source; do not edit.\n// SHA256: '+hashlib.sha256(source_path.read_bytes()).hexdigest()+'\nusing System;\nusing Autodesk.Revit.DB;\nusing Autodesk.Revit.DB.Architecture;\npartial class Handler\n{\n'+method+'\n}\n',encoding='utf-8')
print('Extracted actual phase resolver from',source_path.name)
