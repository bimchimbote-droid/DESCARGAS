// Contract doubles only. These types are NOT Autodesk Revit implementations.
// Room intentionally has NO Phase property: the incorrect production call must
// fail at compilation rather than be legitimized by a convenient test double.
namespace Autodesk.Revit.DB
{
    public enum BuiltInParameter { ROOM_PHASE_ID=-1012112, ROOM_PHASE=-1012113 }
    public enum StorageType { None, Integer, Double, String, ElementId }
    public class ElementId
    {
        public long Value { get; }
        public ElementId(long value) { Value=value; }
        public static readonly ElementId InvalidElementId=new(-1);
        public override bool Equals(object other)=>other is ElementId id&&id.Value==Value;
        public override int GetHashCode()=>Value.GetHashCode();
        public static bool operator ==(ElementId a,ElementId b)=>ReferenceEquals(a,b)||(a is not null&&b is not null&&a.Value==b.Value);
        public static bool operator !=(ElementId a,ElementId b)=>!(a==b);
    }
    public class Element { public ElementId Id { get; set; } }
    public class Phase:Element { }
    public class Parameter
    {
        public StorageType StorageType { get; set; }
        public bool HasValue { get; set; }=true;
        public ElementId Value { get; set; }
        public int AsElementIdCalls { get; private set; }
        public ElementId AsElementId()
        {
            AsElementIdCalls++;
            if(StorageType!=StorageType.ElementId)throw new InvalidOperationException("AsElementId called for non-ElementId parameter");
            return Value;
        }
    }
    public class Document
    {
        public readonly Dictionary<long,Element> Elements=new();
        public readonly List<long> RequestedIds=new();
        public Element GetElement(ElementId id)
        {
            if(id==null)throw new ArgumentNullException(nameof(id));
            RequestedIds.Add(id.Value);
            return Elements.TryGetValue(id.Value,out var element)?element:null;
        }
    }
}
namespace Autodesk.Revit.DB.Architecture
{
    public class Room:Autodesk.Revit.DB.Element
    {
        public readonly Dictionary<Autodesk.Revit.DB.BuiltInParameter,Autodesk.Revit.DB.Parameter> Parameters=new();
        public readonly List<Autodesk.Revit.DB.BuiltInParameter> RequestedParameters=new();
        public int GenericCreatedPhaseReads { get; private set; }
        public Autodesk.Revit.DB.ElementId CreatedPhaseId
        {
            get { GenericCreatedPhaseReads++; throw new InvalidOperationException("Room.CreatedPhaseId must not be used for phase resolution"); }
        }
        public Autodesk.Revit.DB.Parameter get_Parameter(Autodesk.Revit.DB.BuiltInParameter parameter)
        {
            RequestedParameters.Add(parameter);
            return Parameters.TryGetValue(parameter,out var value)?value:null;
        }
    }
}
