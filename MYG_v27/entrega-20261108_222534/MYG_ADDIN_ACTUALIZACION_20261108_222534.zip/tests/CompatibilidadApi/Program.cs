using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text.RegularExpressions;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
class Program
{
 static int Main(string[] args)
 {
  string source=File.ReadAllText(args[0]); string api=args[1];
  bool phaseOnly=args.Contains("--phase-only");
  var refs=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  foreach(string folder in args.Skip(2).Where(x=>!x.StartsWith("--")))
   foreach(string f in Directory.GetFiles(folder,"*.dll"))
   {
    using var stream=File.OpenRead(f);
    using var pe=new PEReader(stream);
    if(pe.HasMetadata && pe.GetMetadataReader().IsAssembly) refs[Path.GetFileName(f)]=f;
   }
  foreach(string name in new[]{"RevitAPI.dll","RevitAPIUI.dll","AdWindows.dll","UIFramework.dll"})
   if(File.Exists(Path.Combine(api,name)))refs[name]=Path.Combine(api,name);
  var trees=new List<SyntaxTree>();
  if(phaseOnly)
  {
   var m=Regex.Match(source,@"^    private ElementId ObtenerFaseValidaRoom\([\s\S]*?^    }",RegexOptions.Multiline);
   if(!m.Success)throw new Exception("Phase helper missing");
   source="using System; using Autodesk.Revit.DB; using Autodesk.Revit.DB.Architecture; class Probe {\n"+m.Value+"\n}";
  }
  else trees.Add(CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"FormStub.txt")),new CSharpParseOptions(LanguageVersion.CSharp7_3)));
  trees.Add(CSharpSyntaxTree.ParseText(source,new CSharpParseOptions(LanguageVersion.CSharp7_3),path:args[0]));
  var compilation=CSharpCompilation.Create("RevitApiCompatibility",trees,refs.Values.Select(p=>MetadataReference.CreateFromFile(p)),new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
  using var output=new MemoryStream(); var result=compilation.Emit(output);
  var errors=result.Diagnostics.Where(d=>d.Severity==DiagnosticSeverity.Error).ToArray();
  foreach(var d in errors)Console.WriteLine(d);
  Console.WriteLine((phaseOnly?"PHASE HELPER":"FULL HANDLER (Form stub only)")+": "+errors.Length+" semantic errors; emit="+result.Success+"; RevitAPI="+api);
  Console.WriteLine("Compilation only against actual API metadata; no Autodesk code executed.");
  return result.Success?0:1;
 }
}
