# Comprobación semántica con la API real

Este proyecto utiliza Roslyn del SDK .NET para compilar el handler completo contra **DLL reales de referencia de Revit**, que no se distribuyen en este ZIP. No ejecuta código Autodesk.

`FormStub.txt` es únicamente un adaptador de la interfaz para esta prueba. Las clases, parámetros, métodos y propiedades Revit NO se simulan aquí: se resuelven contra las DLL que se pasan como argumento. El proyecto de prueba no se agrega al add-in.

Requisitos: SDK .NET 8 o posterior, directorio de RevitAPI.dll/RevitAPIUI.dll y referencias de plataforma correspondientes a esa API. Para el chequeo ejecutado de Revit 2027 se usaron los paquetes públicos Revit_All_Main_Versions_API_x64 2027.0.0 (RevitAPI 27.0.4.0), Microsoft.NETCore.App.Ref 10.0.0 y Microsoft.WindowsDesktop.App.Ref 10.0.0, descargados mediante NuGet con verificación TLS activa. Para el helper de fase se comprobaron también RevitAPI 23.0.0.0 y referencias de .NET Framework 4.8.

Desde esta carpeta, indique rutas reales:

```bash
dotnet run --project Check.csproj --configuration Release -- /ruta/MUROSDEROOM_EJECUTAR_HANDLER.cs /ruta/api-revit /ruta/referencias-net /ruta/referencias-windows
```

Para comprobar únicamente el método de fase (sin adaptador de ventana), añada `--phase-only`. Los directorios de referencias deben contener las DLL de referencia adecuadas; no mezcle runtimes de distintas versiones. En .NET Framework puede necesitar además el subdirectorio Facades. El comprobador omite archivos nativos sin metadatos administrados, no errores del código.

Resultado observado: el handler anterior reproduce CS1061 para Room.Phase con Revit 2027; el handler corregido completo compila sin errores en este proyecto aislado con esa API. El método de fase corregido compila también con Revit 2023. Esto NO es la compilación de MYG.csproj, no prueba Office/COM ni la interfaz real y no ejecuta el complemento dentro de Revit.

No se incluye ninguna DLL compilada, dependencia restaurable ni ensamblado Autodesk.
