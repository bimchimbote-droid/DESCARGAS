# Suelos desde Rooms: picar una superficie de un vínculo Revit

Esta actualización parcial añade **PICAR EN VÍNCULO** al modo de superficie de Crear suelo desde Rooms. Se conserva el botón **PICAR SUPERFICIE** para el documento anfitrión y el modo **Por nivel y desfase**.

## Archivos del add-in

| Ruta relativa a la raíz de tu solución | Acción |
| --- | --- |
| `MYG/Funcionalidades/Arquitectura/Habitaciones/CrearSueloDesdeRoomForm.cs` | REEMPLAZAR completo |
| `MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs` | REEMPLAZAR completo |

No se agregan archivos al proyecto del add-in ni cambian `.csproj`, comando, Ribbon, recursos, paquetes o manifiesto. La nueva acción usa el `ExternalEvent` existente. Los valores previos del enum se conservan y se añade `PicarSuperficieVinculada = 4`.

El ZIP contiene solo los dos `.cs` modificados, las pruebas nuevas y documentación de esta entrega. No incluye otros `.cs` de aplicación sin cambios.

## Cómo utilizarlo

1. Selecciona los Rooms del documento anfitrión y los tipos de suelo, con una o dos capas.
2. Activa **Picar superficie** en Ubicación en altura.
3. Para una cara del modelo actual, usa **PICAR SUPERFICIE**. Para una cara de un vínculo Revit cargado, usa **PICAR EN VÍNCULO**.
4. Selecciona la cara. La ventana se oculta durante el pick y vuelve a mostrarse al terminar o cancelar.
5. Comprueba la cota interna y el nivel anfitrión asociado automáticamente; después pulsa **EJECUTAR**.

La superficie continúa marcando la base del suelo inferior o único. Las capas se crean hacia arriba, como confirmó el usuario. No se cambia el apilamiento: inferiorTop = base + espesorInferior; superiorTop = base + espesorInferior + espesorSuperior.

Los Rooms y los nuevos suelos siguen perteneciendo al documento anfitrión. Del vínculo solo se toma la altura del punto seleccionado. Los suelos permanecen horizontales; no copian la pendiente de la cara.

**LIMPIAR** invalida la última cota, proceda del modelo actual o de un vínculo. Escape, una referencia inválida o un vínculo no disponible conservan la última cota válida. Cambiar de modo sigue conservando los valores manuales.

## Selección y coordenadas

El botón nuevo usa `ObjectType.PointOnElement` con un filtro que admite únicamente caras de instancias de vínculo Revit cargadas. Se resuelven el elemento y su cara en el documento vinculado mediante `LinkedElementId` y `CreateReferenceInLink()`. La referencia se comprueba de nuevo después del pick.

La altura se toma directamente de `Reference.GlobalPoint.Z` en coordenadas del anfitrión. No se aplica de nuevo `GetTotalTransform` al punto seleccionado, evitando duplicar el desplazamiento o rotación del vínculo. El nivel asociado se busca en el anfitrión usando `ProjectElevation`, no en el documento vinculado.

No se utilizan el origen de la cara, cajas envolventes ni una cota cero como sustitutos de una selección inválida. Si no hay vínculos Revit cargados, se informa sin sustituir la cota anterior.

Se admite la selección en vínculos Revit de primer nivel cargados. No se garantiza resolución recursiva de vínculos anidados; una referencia que no pueda resolverse a una cara se rechaza. No es un selector de importaciones CAD ni permite seleccionar Rooms de un vínculo.

## Instalación

1. Respalda tu solución y DLL actuales. Compara antes cualquier modificación local posterior que hayas hecho en estos dos archivos.
2. Extrae el ZIP y copia los dos `.cs` de la tabla a esas mismas rutas de tu solución reorganizada. Ya pertenecen al proyecto; no agregues copias duplicadas.
3. Recompila en Visual Studio/MSBuild de .NET Framework sobre Windows con las referencias reales de tu instalación de Revit y Office/Excel. Restaura NuGet si faltan paquetes. Después de restaurar, el comando equivalente es `MSBuild.exe MYG\MYG.csproj /t:Build /p:Configuration=Release /p:Platform=x64`.
4. Cierra Revit antes de actualizar la DLL compilada. Conserva `.addin`, iconos y dependencias.
5. Prueba en una copia del modelo: vínculo cargado, vínculo desplazado verticalmente, vínculo rotado, niveles con cotas compartidas, Escape y LIMPIAR. Confirma que la base de ambos modos de superficie coincide con el punto elegido y que las dos capas quedan encima.

Los archivos incluyen la mejora anterior de selección de superficie del suelo. Las demás correcciones previas se conservan; no debes sustituir otros archivos por versiones antiguas. Los suelos existentes no se mueven ni eliminan automáticamente.

## Verificación y límites

`VERIFICACION.json` registra los resultados reales. La suite nueva ejecuta código de selección extraído con tipos y callbacks de prueba; estos no son la API de Revit ni su interfaz de selección. La suite anterior de superficies sigue disponible y sus 120 comprobaciones de regresión pasan.

Los 179 archivos activos pasan el análisis de sintaxis C# 7.3. La compilación completa en Linux sigue bloqueada por `MSB4803` debido a las referencias COM. No se generó una DLL aquí ni se ejecutó Revit/WinForms. La selección y geometría con tus vínculos reales deben comprobarse en Windows/Revit.

`Pruebas/SuelosRoomsVinculos/` es opcional para desarrollo. No agregues sus archivos al proyecto del add-in. Requiere SDK .NET 10 y se ejecuta desde la solución actualizada con `dotnet run --project Pruebas/SuelosRoomsVinculos/SuelosRoomsVinculos.Tests.csproj`. No añade paquetes externos ni cambia el framework del add-in.

La referencia Git es `a41d354e8206e401a881aacfff3f5da7dfe74d00`, más la reorganización y correcciones de la sesión. Se publica únicamente el ZIP en `bimchimbote-droid/DESCARGAS`, sin Push a `MYG_v27`. Tras validar, revisa Cambios de Git en Visual Studio y realiza Commit/Push a tu rama cuando corresponda.
