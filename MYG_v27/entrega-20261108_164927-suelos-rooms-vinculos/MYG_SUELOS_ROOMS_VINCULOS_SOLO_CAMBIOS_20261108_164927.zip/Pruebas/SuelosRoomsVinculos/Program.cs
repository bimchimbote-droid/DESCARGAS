using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using MYG_Addin;

var pruebas = new List<(string Grupo, string Nombre, Action Ejecutar)>();
SyntaxNode formFuente = Leer("CrearSueloDesdeRoomForm.cs");
SyntaxNode handlerFuente = Leer("SUELOSDESDEROOM_EJECUCION_HANDLER.cs");
string[] nombres = ["PicarSuperficieVinculada", "VinculoRevitCargado", "EsCaraVinculadaSeleccionable", "ObtenerNivelMasCercanoParaSuperficie", "EsNumeroFinitoSuelo"];
var metodos = nombres.Select(n => Metodo(handlerFuente, n)).ToArray();
var filtroFuente = handlerFuente.DescendantNodes().OfType<ClassDeclarationSyntax>()
    .Single(c => c.Identifier.ValueText == "FiltroCaraVinculadaSueloRooms");
// Los métodos y la clase de filtro se extraen sin cambiar sus cuerpos.
// Los tipos Autodesk.* del ensamblado de pruebas son stubs explícitos de datos
// y callbacks, no las bibliotecas ni el comportamiento geométrico de Revit.
string codigo = """
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using Autodesk.Revit.DB;
    using Autodesk.Revit.UI;
    using Autodesk.Revit.UI.Selection;
    using MYG_Addin;
    public class HandlerReal
    {
        public UIDocument UiDoc;
        public CrearSueloDesdeRoomForm Form;
        public List<string> Mensajes = new List<string>();
        private void MostrarEnVentana(string texto) { Mensajes.Add(texto); }
    """ + string.Join("\n", metodos.Select(m => m.ToFullString())) + "\n" + filtroFuente.ToFullString() + "\n}";
string? plataforma = AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") as string;
if (string.IsNullOrEmpty(plataforma)) throw new InvalidOperationException("Faltan referencias de plataforma .NET.");
var referencias = plataforma.Split(Path.PathSeparator).Append(Assembly.GetExecutingAssembly().Location)
    .Distinct().Select(p => MetadataReference.CreateFromFile(p));
var compilacion = CSharpCompilation.Create("SuelosVinculosMetodosReales", [CSharpSyntaxTree.ParseText(codigo)], referencias,
    new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var memoria = new MemoryStream();
var emision = compilacion.Emit(memoria);
if (!emision.Success) throw new InvalidOperationException(string.Join(Environment.NewLine, emision.Diagnostics));
Type clase = Assembly.Load(memoria.ToArray()).GetType("HandlerReal", throwOnError: true)!;
var cargado = (Func<RevitLinkInstance, bool>)clase.GetMethod("VinculoRevitCargado", BindingFlags.NonPublic | BindingFlags.Static)!
    .CreateDelegate(typeof(Func<RevitLinkInstance, bool>));
var esCara = (Func<Document, Reference, bool>)clase.GetMethod("EsCaraVinculadaSeleccionable", BindingFlags.NonPublic | BindingFlags.Static)!
    .CreateDelegate(typeof(Func<Document, Reference, bool>));

Agregar("vínculos cargados", "null rechazado", () => Falso(cargado(null!)));
Agregar("vínculos cargados", "documento vinculado disponible", () => Verdadero(cargado(Preparar().Vinculo)));
Agregar("vínculos cargados", "documento vinculado descargado", () => Falso(cargado(Preparar(cargado: false).Vinculo)));
Agregar("vínculos cargados", "excepción al resolver documento", () =>
{
    var e = Preparar(); e.Vinculo.LanzarAlLeerDocumento = true; Falso(cargado(e.Vinculo));
});
Agregar("referencias reales", "cara de vínculo cargado aceptada tras conversión", () =>
{
    var e = Preparar();
    Verdadero(esCara(e.Doc, e.Referencia));
    Verdadero(e.Referencia.Conversiones == 1 && e.Elemento.UltimaReferencia!.ConvertidaEnVinculo);
});
Agregar("referencias reales", "referencia sin convertir no resuelve geometría del stub", () =>
{
    var e = Preparar();
    Lanza<InvalidOperationException>(() => e.Elemento.GetGeometryObjectFromReference(e.Referencia));
    Verdadero(esCara(e.Doc, e.Referencia));
});
Agregar("referencias reales", "documento null rechazado", () => Falso(esCara(null!, Preparar().Referencia)));
Agregar("referencias reales", "referencia null rechazada", () => Falso(esCara(Preparar().Doc, null!)));
foreach (bool idVinculado in new[] { false, true })
{
    foreach (bool nulo in new[] { false, true })
        Agregar("referencias reales", $"id {(idVinculado ? "vinculado" : "anfitrión")} {(nulo ? "null" : "inválido")}", () =>
        {
            var e = Preparar();
            ElementId valor = nulo ? null! : new ElementId(-1);
            if (idVinculado) e.Referencia.LinkedElementId = valor; else e.Referencia.ElementId = valor;
            Falso(esCara(e.Doc, e.Referencia));
        });
}
(string Nombre, Action<Escenario> Preparar)[] casosRechazo =
[
    ("vínculo descargado", e => e.Vinculo.DocumentoVinculado = null),
    ("vínculo que lanza excepción", e => e.Vinculo.LanzarAlLeerDocumento = true),
    ("id de vínculo inexistente", e => e.Referencia.ElementId = new ElementId(9999)),
    ("elemento anfitrión nativo", e => { e.Doc.Agregar(new Element { Id = new ElementId(301) }); e.Referencia.ElementId = new ElementId(301); }),
    ("elemento vinculado inexistente", e => e.Referencia.LinkedElementId = new ElementId(9999)),
    ("geometría Edge", e => e.Elemento.Geometria = new Edge()),
    ("geometría null", e => e.Elemento.Geometria = null),
    ("error al resolver geometría", e => e.Elemento.LanzarAlLeerGeometria = true),
    ("conversión de referencia lanza excepción", e => e.Referencia.LanzarAlConvertir = true),
    ("conversión devuelve null", e => e.Referencia.ConvertirANull = true)
];
foreach (var caso in casosRechazo)
    Agregar("referencias reales", caso.Nombre, () =>
    {
        var e = Preparar(); caso.Preparar(e); Falso(esCara(e.Doc, e.Referencia));
    });

Agregar("filtro real", "AllowElement acepta vínculo cargado", () =>
{
    var e = Preparar(); Verdadero(Filtro(e.Doc).AllowElement(e.Vinculo));
});
Agregar("filtro real", "AllowElement rechaza vínculo descargado", () =>
{
    var e = Preparar(cargado: false); Falso(Filtro(e.Doc).AllowElement(e.Vinculo));
});
Agregar("filtro real", "AllowElement rechaza elemento nativo", () => Falso(Filtro(Preparar().Doc).AllowElement(new Element())));
Agregar("filtro real", "AllowElement rechaza null", () => Falso(Filtro(Preparar().Doc).AllowElement(null!)));
Agregar("filtro real", "AllowReference acepta cara", () =>
{
    var e = Preparar(); Verdadero(Filtro(e.Doc).AllowReference(e.Referencia, new XYZ(0, 0, 0)));
});
Agregar("filtro real", "AllowReference rechaza arista", () =>
{
    var e = Preparar(); e.Elemento.Geometria = new Edge(); Falso(Filtro(e.Doc).AllowReference(e.Referencia, new XYZ(0, 0, 0)));
});
Agregar("filtro real", "AllowReference rechaza selección nativa", () =>
{
    var e = Preparar(); e.Referencia.LinkedElementId = ElementId.InvalidElementId;
    Falso(Filtro(e.Doc).AllowReference(e.Referencia, new XYZ(0, 0, 0)));
});

Agregar("picker real con callbacks", "PointOnElement, filtro real y aplicación de punto global", () =>
{
    var e = Preparar();
    e.Seleccion.AlPicar = (tipo, filtro, texto) =>
    {
        Verdadero(tipo == ObjectType.PointOnElement && filtro is not null);
        Verdadero(!e.Form.Visible && e.Form.Ocultaciones == 1);
        Verdadero(filtro!.AllowElement(e.Vinculo) && filtro.AllowReference(e.Referencia, e.Referencia.GlobalPoint!));
        return e.Referencia;
    };
    e.Ejecutar();
    Verdadero(e.Form.Aplicaciones == 1 && ReferenceEquals(e.Form.PuntoAplicado, e.Referencia.GlobalPoint));
    Verdadero(e.Form.Muestras == 1 && e.Form.Visible);
});
Agregar("picker real con callbacks", "sin vínculos devuelve y restaura sin ocultar", () =>
{
    var e = Preparar(); e.Doc.Elementos.Remove(e.Vinculo); e.Ejecutar();
    Conservado(e); Verdadero(e.Seleccion.Picks == 0 && e.Form.Ocultaciones == 0 && e.Mensajes.Count == 1);
});
Agregar("picker real con callbacks", "solo vínculos descargados no inicia selección", () =>
{
    var e = Preparar(cargado: false); e.Ejecutar(); Conservado(e); Verdadero(e.Seleccion.Picks == 0);
});
Agregar("picker real con callbacks", "ignora vínculo defectuoso si otro cargado sirve", () =>
{
    var e = Preparar(); e.Doc.Elementos.Insert(0, new RevitLinkInstance { Id = new ElementId(401), LanzarAlLeerDocumento = true });
    e.Ejecutar(); Verdadero(e.Form.Aplicaciones == 1);
});
Agregar("picker real con callbacks", "Escape conserva selección y restaura formulario", () =>
{
    var e = Preparar(); e.Seleccion.AlPicar = (_, _, _) => throw new Autodesk.Revit.Exceptions.OperationCanceledException();
    Lanza<Autodesk.Revit.Exceptions.OperationCanceledException>(e.Ejecutar); Conservado(e);
});
Agregar("picker real con callbacks", "error de selección también restaura formulario", () =>
{
    var e = Preparar(); e.Seleccion.AlPicar = (_, _, _) => throw new InvalidOperationException("fallo de callback");
    Lanza<InvalidOperationException>(e.Ejecutar); Conservado(e);
});
Agregar("picker real con callbacks", "referencia null preserva estado", () =>
{
    var e = Preparar(); e.Seleccion.AlPicar = (_, _, _) => null!; e.Ejecutar(); Conservado(e);
});
Agregar("picker real con callbacks", "revalida vínculo descargado después del pick", () =>
{
    var e = Preparar(); e.Seleccion.AlPicar = (_, filtro, _) =>
    {
        Verdadero(filtro!.AllowReference(e.Referencia, e.Referencia.GlobalPoint!));
        e.Vinculo.DocumentoVinculado = null; return e.Referencia;
    };
    e.Ejecutar(); Conservado(e);
});
Agregar("picker real con callbacks", "revalida arista aunque callback devuelva referencia", () =>
{
    var e = Preparar(); e.Elemento.Geometria = new Edge(); e.Ejecutar(); Conservado(e);
});
Agregar("picker real con callbacks", "GlobalPoint null conserva estado", () =>
{
    var e = Preparar(); e.Referencia.GlobalPoint = null; e.Ejecutar(); Conservado(e);
});
foreach (double z in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity })
    Agregar("picker real con callbacks", $"GlobalPoint Z {z} conserva estado", () =>
    {
        var e = Preparar(); e.Referencia.GlobalPoint = new XYZ(10, 20, z); e.Ejecutar(); Conservado(e);
    });
Agregar("picker real con callbacks", "sin niveles anfitriones no usa niveles vinculados", () =>
{
    var e = Preparar(conNivel: false); e.DocVinculado.Agregar(new Level { Id = new ElementId(601), ProjectElevation = 0 });
    e.Ejecutar(); Conservado(e);
});
Agregar("picker real con callbacks", "elige nivel anfitrión por ProjectElevation", () =>
{
    var e = Preparar();
    var correcto = new Level { Id = new ElementId(2), ProjectElevation = 0, Elevation = Metros(1299.691) };
    e.Doc.Elementos.RemoveAll(x => x is Level);
    e.Doc.Agregar(new Level { Id = new ElementId(1), ProjectElevation = Metros(10), Elevation = Metros(.25) });
    e.Doc.Agregar(correcto);
    e.DocVinculado.Agregar(new Level { Id = new ElementId(602), ProjectElevation = Metros(.25), Elevation = Metros(.25) });
    e.Ejecutar(); Verdadero(ReferenceEquals(e.Form.NivelAplicado, correcto));
});
Agregar("picker real con callbacks", "omite nivel anfitrión con cota no finita", () =>
{
    var e = Preparar(); var correcto = e.Doc.Elementos.OfType<Level>().Single();
    e.Doc.Elementos.Insert(0, new Level { Id = new ElementId(3), ProjectElevation = double.NaN });
    e.Ejecutar(); Verdadero(ReferenceEquals(e.Form.NivelAplicado, correcto));
});
foreach (var punto in new[] { new XYZ(1234, -5678, Metros(.25)), new XYZ(-91, 43, Metros(12.5)) })
    Agregar("picker real con callbacks", $"punto global desplazado/rotado ya resuelto ({punto.X}, {punto.Y})", () =>
    {
        var e = Preparar(); e.Referencia.GlobalPoint = punto; e.Ejecutar();
        Verdadero(ReferenceEquals(e.Form.PuntoAplicado, punto));
        Cerca(e.Form.PuntoAplicado!.X, punto.X); Cerca(e.Form.PuntoAplicado.Y, punto.Y); Cerca(e.Form.PuntoAplicado.Z, punto.Z);
    });

Agregar("auditoría de fuente", "acciones anteriores intactas; nueva acción 4", () =>
{
    var e = handlerFuente.DescendantNodes().OfType<EnumDeclarationSyntax>().Single(n => n.Identifier.ValueText == "RoomSueloAccion");
    string[] acciones = ["Ninguna", "SeleccionarRoom", "CrearSuelo", "PicarSuperficieBase", "PicarSuperficieVinculada"];
    for (int i = 0; i < acciones.Length; i++)
        Verdadero(e.Members.Single(m => m.Identifier.ValueText == acciones[i]).EqualsValue!.Value is LiteralExpressionSyntax l && Convert.ToInt32(l.Token.Value) == i);
});
Agregar("auditoría de fuente", "Execute enruta acción vinculada", () =>
{
    var rama = Metodo(handlerFuente, "Execute").DescendantNodes().OfType<IfStatementSyntax>()
        .Single(i => i.Condition.ToString() == "Accion == RoomSueloAccion.PicarSuperficieVinculada");
    Verdadero(Invocaciones(rama, "PicarSuperficieVinculada").Length == 1);
});
Agregar("auditoría de fuente", "botón enlazado a acción y ExternalEvent solo en modo superficie", () =>
{
    var click = formFuente.DescendantNodes().OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == "btnPicarSuperficieVinculada.Click");
    var guard = click.DescendantNodes().OfType<IfStatementSyntax>().Single();
    Verdadero(guard.Condition.ToString() == "Handler == null || !UsarCotaBaseDesdeSuperficie");
    Verdadero(guard.Statement.DescendantNodesAndSelf().OfType<ReturnStatementSyntax>().Any());
    Verdadero(click.DescendantNodes().OfType<AssignmentExpressionSyntax>().Any(a => a.Left.ToString() == "Handler.Accion" && a.Right.ToString() == "RoomSueloAccion.PicarSuperficieVinculada"));
    Verdadero(click.DescendantNodes().OfType<InvocationExpressionSyntax>().Any(i => i.Expression is MemberBindingExpressionSyntax m && m.Name.Identifier.ValueText == "Raise"));
});
Agregar("auditoría de fuente", "botón se muestra y habilita solo en superficie", () =>
{
    var actualizar = Metodo(formFuente, "ActualizarVisibilidadCapas");
    foreach (string propiedad in new[] { "Visible", "Enabled" })
        Verdadero(actualizar.DescendantNodes().OfType<AssignmentExpressionSyntax>().Any(a => a.Left.ToString() == "btnPicarSuperficieVinculada." + propiedad && a.Right.ToString() == "porSuperficie"));
    var objeto = Inicializador("btnPicarSuperficieVinculada");
    Verdadero(objeto.Initializer!.Expressions.OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == "Text").Right is LiteralExpressionSyntax texto && texto.Token.ValueText == "PICAR EN VÍNCULO");
});
Agregar("auditoría de fuente", "tres botones caben sin solapar en la misma fila", () =>
{
    string[] botones = ["btnPicarSuperficie", "btnPicarSuperficieVinculada", "btnLimpiarSuperficie"];
    int bordeDerecho = 20;
    foreach (string boton in botones)
    {
        var objeto = Inicializador(boton);
        int left = Entero(objeto, "Left"), width = Entero(objeto, "Width");
        Verdadero(left >= bordeDerecho && width > 0 && left + width <= 500);
        Verdadero(Entero(objeto, "Height") == 32);
        bordeDerecho = left + width;
        Verdadero(Metodo(formFuente, "ActualizarVisibilidadCapas").DescendantNodes().OfType<AssignmentExpressionSyntax>()
            .Any(a => a.Left.ToString() == boton + ".Top" && a.Right.ToString() == "yNivel + 27"));
    }
});
Agregar("auditoría de fuente", "GlobalPoint se entrega directo sin llamadas de transformación", () =>
{
    var pick = Metodo(handlerFuente, "PicarSuperficieVinculada");
    var punto = pick.DescendantNodes().OfType<VariableDeclaratorSyntax>().Single(v => v.Identifier.ValueText == "punto");
    Verdadero(punto.Initializer!.Value.ToString() == "referencia.GlobalPoint");
    foreach (string nombre in new[] { "GetTotalTransform", "GetTransform", "OfPoint" }) Falso(Invocaciones(pick, nombre).Any());
});
Agregar("auditoría de fuente", "pick usa filtro de vínculo y revalida antes de aplicar", () =>
{
    var pick = Metodo(handlerFuente, "PicarSuperficieVinculada");
    var seleccionar = Invocaciones(pick, "PickObject").Single();
    var validar = Invocaciones(pick, "EsCaraVinculadaSeleccionable").Single();
    var aplicar = Invocaciones(pick, "AplicarCotaBaseDesdeSuperficie").Single();
    Verdadero(seleccionar.ArgumentList.Arguments[0].Expression.ToString() == "ObjectType.PointOnElement");
    Verdadero(seleccionar.ArgumentList.Arguments[1].Expression is ObjectCreationExpressionSyntax filtro && filtro.Type.ToString() == "FiltroCaraVinculadaSueloRooms");
    Verdadero(seleccionar.SpanStart < validar.SpanStart && validar.SpanStart < aplicar.SpanStart);
});
Agregar("auditoría de fuente", "native Face sigue intacto", () => HashIgual("PicarSuperficieBase", handlerFuente,
    "694cc74c03236acfb341da1df864b166ee3b6cb3015621bf365377f218dcd82b"));
Agregar("auditoría de fuente", "cálculo de altura mantiene ambos modos", () => HashIgual("CalcularDesfaseAltura", formFuente,
    "080f77822eef488c44f894993efd45306a1a3876525e50d5ed329b403145739d"));
Agregar("auditoría de fuente", "apilado de ambas capas se conserva", () => HashIgual("CalcularOffsetSuperiorCapa", handlerFuente,
    "c5738fb9a2d4333be869d6307213729957b7d2ecab7cf71e3656a3022fa01102"));
Agregar("auditoría de fuente", "verificación de cota superior se conserva", () => HashIgual("CotaSuperiorCoincide", handlerFuente,
    "8cf25a6beda6113204dfbe9c83b01157d86e486a93eaa0a29e8835e05ef5e25e"));

int correctas = 0, fallidas = 0;
foreach (var prueba in pruebas)
{
    try { prueba.Ejecutar(); correctas++; Console.WriteLine($"OK [{prueba.Grupo}] {prueba.Nombre}"); }
    catch (Exception ex) { fallidas++; Console.Error.WriteLine($"FALLO [{prueba.Grupo}] {prueba.Nombre}: {ex.Message}"); }
}
Console.WriteLine();
foreach (var grupo in pruebas.GroupBy(p => p.Grupo)) Console.WriteLine($"{grupo.Key}: {grupo.Count()} casos");
Console.WriteLine($"TOTAL: {pruebas.Count}; CORRECTAS: {correctas}; FALLIDAS: {fallidas}");
Console.WriteLine("Alcance: métodos/filtro reales con stubs de datos y callbacks; no ejecuta Revit/WinForms ni valida geometría real.");
return fallidas == 0 ? 0 : 1;

void Agregar(string grupo, string nombre, Action ejecutar) => pruebas.Add((grupo, nombre, ejecutar));
ISelectionFilter Filtro(Document doc) => (ISelectionFilter)Activator.CreateInstance(clase.GetNestedType("FiltroCaraVinculadaSueloRooms", BindingFlags.NonPublic)!, [doc])!;
Escenario Preparar(bool cargado = true, bool conNivel = true)
{
    var doc = new Document(); var vinculado = new Document();
    var elemento = new Element { Id = new ElementId(201), Geometria = new Face(), ExigirReferenciaConvertida = true }; vinculado.Agregar(elemento);
    var vinculo = new RevitLinkInstance { Id = new ElementId(101), DocumentoVinculado = cargado ? vinculado : null }; doc.Agregar(vinculo);
    if (conNivel) doc.Agregar(new Level { Id = new ElementId(1), ProjectElevation = 0, Elevation = Metros(1299.691) });
    var referencia = new Reference { ElementId = vinculo.Id, LinkedElementId = elemento.Id, GlobalPoint = new XYZ(10, 20, Metros(.25)) };
    var seleccion = new Selection { AlPicar = (_, _, _) => referencia };
    var formulario = new CrearSueloDesdeRoomForm { PuntoAplicado = new XYZ(-1, -2, -3), NivelAplicado = new Level { Id = new ElementId(-9) } };
    object instancia = Activator.CreateInstance(clase)!;
    clase.GetField("UiDoc")!.SetValue(instancia, new UIDocument(doc, seleccion)); clase.GetField("Form")!.SetValue(instancia, formulario);
    var ejecutar = (Action)clase.GetMethod("PicarSuperficieVinculada", BindingFlags.NonPublic | BindingFlags.Instance)!.CreateDelegate(typeof(Action), instancia);
    var mensajes = (List<string>)clase.GetField("Mensajes")!.GetValue(instancia)!;
    return new Escenario(doc, vinculado, vinculo, elemento, referencia, seleccion, formulario, ejecutar, mensajes, formulario.PuntoAplicado, formulario.NivelAplicado);
}
ObjectCreationExpressionSyntax Inicializador(string control) => (ObjectCreationExpressionSyntax)formFuente.DescendantNodes().OfType<AssignmentExpressionSyntax>()
    .Single(a => a.Left.ToString() == control && a.Right is ObjectCreationExpressionSyntax).Right;
static int Entero(ObjectCreationExpressionSyntax objeto, string propiedad) => Convert.ToInt32(((LiteralExpressionSyntax)objeto.Initializer!.Expressions
    .OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == propiedad).Right).Token.Value);
static void Conservado(Escenario e)
{
    Verdadero(e.Form.Aplicaciones == 0 && ReferenceEquals(e.Form.PuntoAplicado, e.PuntoAnterior) && ReferenceEquals(e.Form.NivelAplicado, e.NivelAnterior));
    Verdadero(e.Form.Visible && e.Form.Muestras == 1);
}
static SyntaxNode Leer(string nombre) => CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "CodigoFuente", nombre))).GetRoot();
static MethodDeclarationSyntax Metodo(SyntaxNode fuente, string nombre) => fuente.DescendantNodes().OfType<MethodDeclarationSyntax>().Single(m => m.Identifier.ValueText == nombre);
static InvocationExpressionSyntax[] Invocaciones(SyntaxNode nodo, string nombre) => nodo.DescendantNodes().OfType<InvocationExpressionSyntax>().Where(i => i.Expression switch
{
    IdentifierNameSyntax n => n.Identifier.ValueText == nombre,
    MemberAccessExpressionSyntax m => m.Name.Identifier.ValueText == nombre,
    _ => false
}).ToArray();
static void HashIgual(string nombre, SyntaxNode fuente, string esperado)
{
    string codigo = Metodo(fuente, nombre).ToString().Replace("\r\n", "\n").Replace("\r", "\n");
    string actual = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(codigo))).ToLowerInvariant();
    Verdadero(actual == esperado);
}
static double Metros(double metros) => metros / .3048;
static void Verdadero(bool valor) { if (!valor) throw new InvalidOperationException("Se esperaba verdadero."); }
static void Falso(bool valor) { if (valor) throw new InvalidOperationException("Se esperaba falso."); }
static void Cerca(double real, double esperado) { if (!double.IsFinite(real) || Math.Abs(real - esperado) > 1e-8) throw new InvalidOperationException($"Se esperaba {esperado}, obtenido {real}."); }
static void Lanza<T>(Action accion) where T : Exception
{
    try { accion(); } catch (T) { return; }
    throw new InvalidOperationException($"Se esperaba {typeof(T).Name}.");
}

public record Escenario(Document Doc, Document DocVinculado, RevitLinkInstance Vinculo, Element Elemento, Reference Referencia,
    Selection Seleccion, CrearSueloDesdeRoomForm Form, Action Ejecutar, List<string> Mensajes, XYZ? PuntoAnterior, Level? NivelAnterior);

// Stubs mínimos: implementan almacenamiento y callbacks controlados por los
// casos. No calculan transformaciones, caras, selección interactiva ni niveles.
namespace Autodesk.Revit.DB
{
    public class ElementId(long valor)
    {
        public long Value { get; } = valor;
        public static ElementId InvalidElementId { get; } = new(-1);
        public static bool operator ==(ElementId? a, ElementId? b) => a?.Value == b?.Value;
        public static bool operator !=(ElementId? a, ElementId? b) => !(a == b);
        public override bool Equals(object? obj) => obj is ElementId id && Value == id.Value;
        public override int GetHashCode() => Value.GetHashCode();
    }
    public class XYZ(double x, double y, double z) { public double X { get; } = x; public double Y { get; } = y; public double Z { get; } = z; }
    public class GeometryObject;
    public class Face : GeometryObject;
    public class Edge : GeometryObject;
    public class Element
    {
        public ElementId Id { get; set; } = ElementId.InvalidElementId;
        public GeometryObject? Geometria { get; set; }
        public bool ExigirReferenciaConvertida { get; set; }
        public bool LanzarAlLeerGeometria { get; set; }
        public Reference? UltimaReferencia { get; private set; }
        public GeometryObject? GetGeometryObjectFromReference(Reference referencia)
        {
            UltimaReferencia = referencia;
            if (LanzarAlLeerGeometria || (ExigirReferenciaConvertida && !referencia.ConvertidaEnVinculo)) throw new InvalidOperationException("La referencia requiere conversión o falló el callback.");
            return Geometria;
        }
    }
    public class RevitLinkInstance : Element
    {
        public Document? DocumentoVinculado { get; set; }
        public bool LanzarAlLeerDocumento { get; set; }
        public Document? GetLinkDocument() => LanzarAlLeerDocumento ? throw new InvalidOperationException("Vínculo inaccesible.") : DocumentoVinculado;
    }
    public class Level : Element { public double ProjectElevation { get; set; } public double Elevation { get; set; } }
    public class Document
    {
        public List<Element> Elementos { get; } = [];
        public void Agregar(Element elemento) => Elementos.Add(elemento);
        public Element? GetElement(ElementId id) => Elementos.FirstOrDefault(e => e.Id == id);
    }
    public class Reference
    {
        public ElementId ElementId { get; set; } = ElementId.InvalidElementId;
        public ElementId LinkedElementId { get; set; } = ElementId.InvalidElementId;
        public XYZ? GlobalPoint { get; set; }
        public bool ConvertidaEnVinculo { get; set; }
        public bool LanzarAlConvertir { get; set; }
        public bool ConvertirANull { get; set; }
        public int Conversiones { get; private set; }
        public Reference? CreateReferenceInLink()
        {
            Conversiones++;
            if (LanzarAlConvertir) throw new InvalidOperationException("Conversión inaccesible.");
            return ConvertirANull ? null : new Reference { ElementId = LinkedElementId, GlobalPoint = GlobalPoint, ConvertidaEnVinculo = true };
        }
    }
    public class FilteredElementCollector(Document doc) : IEnumerable<Element>
    {
        private Type _tipo = typeof(Element);
        public FilteredElementCollector OfClass(Type tipo) { _tipo = tipo; return this; }
        public IEnumerator<Element> GetEnumerator() => doc.Elementos.Where(e => _tipo.IsInstanceOfType(e)).GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
namespace Autodesk.Revit.UI.Selection
{
    public enum ObjectType { Element, Face, PointOnElement }
    public interface ISelectionFilter { bool AllowElement(Element elemento); bool AllowReference(Reference referencia, XYZ posicion); }
    public class Selection
    {
        public Func<ObjectType, ISelectionFilter?, string, Reference>? AlPicar { get; set; }
        public int Picks { get; private set; }
        public Reference PickObject(ObjectType tipo, ISelectionFilter filtro, string texto) { Picks++; return AlPicar!(tipo, filtro, texto); }
    }
}
namespace Autodesk.Revit.UI
{
    public class UIDocument(Document doc, Selection.Selection seleccion) { public Document Document { get; } = doc; public Selection.Selection Selection { get; } = seleccion; }
}
namespace Autodesk.Revit.Exceptions { public class OperationCanceledException : Exception; }
namespace MYG_Addin
{
    public class CrearSueloDesdeRoomForm
    {
        public XYZ? PuntoAplicado { get; set; }
        public Level? NivelAplicado { get; set; }
        public bool Visible { get; private set; } = true;
        public int Ocultaciones { get; private set; }
        public int Muestras { get; private set; }
        public int Aplicaciones { get; private set; }
        public void OcultarTemporalmenteParaSeleccion() { Ocultaciones++; Visible = false; }
        public void MostrarLuegoDeSeleccion() { Muestras++; Visible = true; }
        public void AplicarCotaBaseDesdeSuperficie(XYZ punto, Level nivel) { Aplicaciones++; PuntoAplicado = punto; NivelAplicado = nivel; }
    }
}
