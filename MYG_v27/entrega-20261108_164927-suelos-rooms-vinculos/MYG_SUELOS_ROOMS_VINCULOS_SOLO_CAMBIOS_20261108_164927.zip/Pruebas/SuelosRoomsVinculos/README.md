# Pruebas de selección de superficies vinculadas para Suelos desde Rooms

Este proyecto extrae con Roslyn cinco métodos **reales** del handler (`PicarSuperficieVinculada`, `VinculoRevitCargado`, `EsCaraVinculadaSeleccionable`, `ObtenerNivelMasCercanoParaSuperficie` y `EsNumeroFinitoSuelo`) y su clase privada `FiltroCaraVinculadaSueloRooms`. Las declaraciones se compilan en memoria sin cambiar sus cuerpos; no se copia su lógica en una implementación alternativa.

Los tipos con nombres `Autodesk.Revit.*` definidos únicamente en `Program.cs` son **stubs de prueba**, no las bibliotecas de Revit. Contienen listas, propiedades y callbacks para suministrar datos y errores controlados. El stub de elemento puede exigir una referencia convertida para devolver la geometría suministrada. Las clases `Face` y `Edge` son etiquetas vacías: no calculan ni resuelven geometría. El formulario de prueba registra llamadas y estado, sin WinForms. La envoltura temporal solo aporta las dependencias y recoge mensajes.

Se ejecuta el código original con vínculos cargados/descargados, referencias inválidas o nativas, caras/aristas, conversiones fallidas, selección cancelada, punto global ausente o Z no finita, cambios de disponibilidad tras el pick y ausencia de niveles anfitriones. Se comprueba que el nivel elegido procede del documento anfitrión y de `ProjectElevation`, que los errores conservan la selección previa y restauran el formulario, y que puntos globales previamente resueltos llegan sin cambios de coordenadas. **No se simula una transformación de vínculo ni se demuestra que Revit resuelva un punto real de un vínculo rotado:** ese comportamiento de la API queda pendiente de integración.

Las auditorías de fuente comprueban la nueva acción 4 preservando las anteriores, ruta por `ExternalEvent`, botón limitado al modo superficie, tres botones en una fila sin solapamiento según sus posiciones declaradas, tipo de selección, filtro y revalidación. La comprobación de transformaciones inspecciona invocaciones AST; los comentarios explicativos no cuentan como llamadas. Hashes de métodos normalizados a LF, tomados antes de esta modificación, comprueban que la selección nativa, ambos modos de altura, apilado de capas y verificación de cota superior permanecen intactos. Si esos métodos cambian en el futuro de forma intencionada, se deberá revisar su baseline.

## Ejecutar

Requiere .NET SDK 10. No usa paquetes NuGet externos; Roslyn procede de `$(MSBuildSDKsPath)/../Roslyn/bincore` del SDK.

Desde la raíz del repositorio:

```bash
dotnet run --project Pruebas/SuelosRoomsVinculos/SuelosRoomsVinculos.Tests.csproj --configuration Release
```

En este entorno se puede activar primero el SDK con:

```bash
source /workspace/.onboarding/MYG_v27/activate.sh
```

La consola informa los casos por grupo y el total. Un fallo de pruebas, extracción o compilación termina con código distinto de cero.

## Alcance

Las pruebas ejecutan lógica real contra stubs y auditan sintaxis. No compilan el addin, no abren Revit/WinForms, no validan firmas contra las DLL de Revit y no certifican selección interactiva ni geometría. La resolución real de referencias vinculadas, caras de familias, vínculos movidos/rotados, cancelación interactiva y creación de suelos deben probarse en Revit con modelos representativos.
