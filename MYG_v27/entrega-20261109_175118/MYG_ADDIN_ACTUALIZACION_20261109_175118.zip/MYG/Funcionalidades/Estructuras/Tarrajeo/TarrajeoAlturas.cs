using System;

namespace MYG_Addin
{
    // Todas las distancias se reciben en las unidades internas de Revit (pies).
    // La elevación del nivel debe ser ProjectElevation, igual que la geometría.
    internal static class TarrajeoAlturas
    {
        internal const double ToleranciaContactoPies = 0.1 / 304.8;

        internal static double CalcularDesfaseMuro(
            double zBaseCara,
            double elevacionNivelProyecto)
        {
            if (!EsFinito(zBaseCara) || !EsFinito(elevacionNivelProyecto))
                throw new ArgumentException("Alturas de muro no válidas.");

            // Las caras se expresan en coordenadas internas del modelo.
            // Level.Elevation puede referirse al punto topográfico y no sirve
            // para calcular WALL_BASE_OFFSET respecto de esa geometría.
            double desfase = zBaseCara - elevacionNivelProyecto;

            if (!EsFinito(desfase))
                throw new ArgumentException("El desfase de muro calculado no es finito.");

            return desfase;
        }

        internal static double CalcularDesfase(
            double zCara,
            double elevacionNivelProyecto,
            double normalZ,
            double espesor,
            double separacionExterior)
        {
            if (!EsFinito(zCara) || !EsFinito(elevacionNivelProyecto) ||
                !EsFinito(normalZ) || !EsFinito(espesor) ||
                !EsFinito(separacionExterior) || espesor <= 0.0 ||
                separacionExterior < 0.0 || Math.Abs(normalZ) < 0.0001)
            {
                throw new ArgumentException("Alturas, normal o espesor de suelo no válidos.");
            }

            double desfase = zCara - elevacionNivelProyecto;
            desfase += normalZ > 0.0
                ? espesor + separacionExterior
                : -separacionExterior;

            if (!EsFinito(desfase))
                throw new ArgumentException("El desfase calculado no es finito.");

            return desfase;
        }

        internal static bool ContactoExteriorValido(
            double distanciaMinima,
            double distanciaMaxima,
            double separacionExterior,
            double tolerancia)
        {
            return EsFinito(distanciaMinima) && EsFinito(distanciaMaxima) &&
                EsFinito(separacionExterior) && EsFinito(tolerancia) &&
                tolerancia > 0.0 && separacionExterior >= 0.0 &&
                distanciaMaxima >= distanciaMinima &&
                distanciaMinima >= -tolerancia &&
                Math.Abs(distanciaMinima - separacionExterior) <= tolerancia;
        }

        private static bool EsFinito(double valor)
        {
            return !double.IsNaN(valor) && !double.IsInfinity(valor);
        }
    }
}
