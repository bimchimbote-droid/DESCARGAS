﻿// =====================================
// TARRAJEO CORE
// Archivo recomendado: TarrajeoCore.cs
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;

public static class TarrajeoCore
{
    private const double Tol = 1e-6;
    private const double ShortTol = 0.003;
    private const double PlaneTol = 0.01;

    // 0.10 ft ≈ 3 cm
    private const double BooleanDepthMin = 0.10;

    // Margen para buscar elementos cercanos
    private const double SearchMargin = 0.50;

    // Tolerancias para evitar caras internas y muros duplicados
    private const double DuplicateWallTol = 0.03;
    private const double WallFaceOffsetTol = 0.06;
    private const double WallEndFaceTol = 0.08;

    // Ajustes para descuento de interferencias en muros
    private const double MordidaOffset = 0.005;
    private const double MordidaVolumeTol = 1e-7;
    private const double MordidaPlaneTol = 0.02;
    private const double MordidaMinArea = 0.0001;

    // Ajustes para corregir la normal hacia afuera en elementos irregulares
    // creados por boceto, cimentaciones, losas, formas en L, etc.
    private const double NormalProbeDepth = 0.08;
    private const double NormalProbeOffset = 0.003;
    private const double NormalProbeVolumeTol = 1e-8;
    private const double NormalProbePatchSize = 0.05;
    private const int NormalProbeGrid = 5;
    private const int NormalProbeMaxPoints = 16;

    private class FaceModelCandidate
    {
        public XYZ Origin;
        public XYZ Normal;
        public List<CurveLoop> Loops;
        public double Area;
    }

    private class ProfileData
    {
        public List<Curve> Curves;
        public List<XYZ> Points;
    }

    // =========================================================
    // CREAR MURO DESDE REFERENCIA DE CARA
    // Usado por: Tarrajeo por caras
    // =========================================================
    public static bool CrearMuroDesdeReferencia(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        Reference faceRef,
        WallType tipoMuro,
        bool permitirUnion)
    {
        try
        {
            if (doc == null) return false;
            if (uidoc == null) return false;
            if (hostElem == null) return false;
            if (faceRef == null) return false;
            if (tipoMuro == null) return false;

            PlanarFace hostFace;
            XYZ originModelo;
            XYZ normalModelo;
            List<CurveLoop> loopsModelo;

            if (!TryGetFaceModelData(
                    hostElem,
                    faceRef,
                    true,
                    out hostFace,
                    out originModelo,
                    out normalModelo,
                    out loopsModelo))
            {
                return false;
            }

            return CrearMuroDesdeDatosDeCara(
                doc,
                uidoc,
                hostElem,
                originModelo,
                normalModelo,
                loopsModelo,
                tipoMuro,
                permitirUnion);
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // CREAR MURO DESDE PLANARFACE
    // Usado por: Tarrajeo por elementos
    // =========================================================
    public static bool CrearMuroDesdeCara(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        PlanarFace hostFace,
        WallType tipoMuro,
        bool permitirUnion)
    {
        try
        {
            if (doc == null) return false;
            if (uidoc == null) return false;
            if (hostElem == null) return false;
            if (hostFace == null) return false;
            if (tipoMuro == null) return false;

            XYZ originModelo = hostFace.Origin;
            XYZ normalModelo = hostFace.FaceNormal.Normalize();

            List<CurveLoop> loopsModelo = TransformCurveLoops(
                hostFace.GetEdgesAsCurveLoops(),
                Transform.Identity);

            return CrearMuroDesdeDatosDeCara(
                doc,
                uidoc,
                hostElem,
                originModelo,
                normalModelo,
                loopsModelo,
                tipoMuro,
                permitirUnion);
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // LÓGICA ÚNICA REAL DE CREACIÓN DE MURO
    // =========================================================
    private static bool CrearMuroDesdeDatosDeCara(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        XYZ originModelo,
        XYZ normalModelo,
        List<CurveLoop> loopsModelo,
        WallType tipoMuro,
        bool permitirUnion)
    {
        try
        {
            if (doc == null) return false;
            if (uidoc == null) return false;
            if (hostElem == null) return false;
            if (tipoMuro == null) return false;
            if (loopsModelo == null || loopsModelo.Count == 0) return false;

            normalModelo = normalModelo.Normalize();

            //-------------------------------------------------
            // CASO ESPECIAL: ESCALERAS
            // En contrapasos de escaleras, la corrección por centro
            // del elemento puede invertir mal la normal y crear el
            // tarrajeo hacia dentro del sólido.
            //
            // Por eso:
            // - En escaleras se respeta la normal real de la cara.
            // - En los demás elementos se mantiene la corrección normal.
            //-------------------------------------------------
            if (!EsElementoDeEscalera(hostElem))
            {
                CorrectNormalToOutside(
                    doc,
                    hostElem,
                    originModelo,
                    ref normalModelo,
                    loopsModelo);
            }

            // Solo caras verticales para muro.
            // Con esto se omite la cara superior e inferior.
            if (Math.Abs(normalModelo.Z) > 0.001)
                return false;

            double espesor = tipoMuro.Width;

            Plane hostPlane = Plane.CreateByNormalAndOrigin(
                normalModelo,
                originModelo);

            CurveLoop outerLoop = GetLargestLoop(
                loopsModelo,
                hostPlane,
                normalModelo);

            if (outerLoop == null)
                return false;

            //-------------------------------------------------
            // CORRECCIÓN ROBUSTA DE NORMAL HACIA AFUERA
            // Para elementos irregulares o creados por boceto,
            // el método por centro puede fallar.
            // Esta lógica toma varios puntos internos de la cara,
            // prueba ambos lados y usa como exterior el lado que
            // menos intersecta con el sólido del host.
            //-------------------------------------------------
            if (!EsElementoDeEscalera(hostElem))
            {
                bool normalCambiada = CorrectNormalByHostSolidProbe(
                    hostElem,
                    outerLoop,
                    ref normalModelo);

                if (normalCambiada)
                {
                    hostPlane = Plane.CreateByNormalAndOrigin(
                        normalModelo,
                        originModelo);

                    outerLoop = GetLargestLoop(
                        loopsModelo,
                        hostPlane,
                        normalModelo);

                    if (outerLoop == null)
                        return false;
                }
            }

            //-------------------------------------------------
            // FILTRO DE CARAS:
            // Solo evita caras claramente ubicadas en el eje del muro.
            // Ya no bloquea caras válidas en extremos, encuentros,
            // uniones ni muros cortados.
            //-------------------------------------------------
            if (!IsValidWallFaceForCreation(
                    hostElem,
                    outerLoop,
                    originModelo,
                    normalModelo))
            {
                return false;
            }

            List<XYZ> ptsPerfil = BuildTranslatedProfilePoints(
                outerLoop,
                hostPlane,
                normalModelo,
                espesor / 2.0);

            if (ptsPerfil == null || ptsPerfil.Count < 3)
                return false;

            List<Curve> profile = BuildProfileCurves(ptsPerfil);

            if (profile == null || profile.Count < 3)
                return false;

            // =========================================================
            // DESCUENTO DE MORDIDAS / INTERSECCIONES
            // =========================================================
            ProfileData booleanProfile = TryBuildBooleanWallProfile(
                doc,
                uidoc,
                hostElem,
                outerLoop,
                hostPlane,
                originModelo,
                normalModelo,
                espesor);

            if (booleanProfile != null)
            {
                //-------------------------------------------------
                // Si hubo intersección real, pero ya no queda
                // perfil útil, la cara estaba totalmente tapada.
                // En ese caso NO se crea muro.
                //-------------------------------------------------
                if (booleanProfile.Curves == null ||
                    booleanProfile.Curves.Count < 3 ||
                    booleanProfile.Points == null ||
                    booleanProfile.Points.Count < 3)
                {
                    return false;
                }

                //-------------------------------------------------
                // Si queda perfil válido, se crea solo la parte libre.
                //-------------------------------------------------
                profile = booleanProfile.Curves;
                ptsPerfil = booleanProfile.Points;
            }

            double minZObjetivo = ptsPerfil.Min(p => p.Z);

            //-------------------------------------------------
            // Si el recorrido por elemento devuelve la misma cara
            // más de una vez, evita crear otro muro encima.
            // Se excluye el host para no confundirlo con el tarrajeo.
            //-------------------------------------------------
            if (ExistsDuplicateWallInSamePosition(
                    doc,
                    hostElem.Id,
                    tipoMuro,
                    normalModelo,
                    ptsPerfil))
            {
                return true;
            }

            Level nivelBase = GetBaseLevelForWall(
                doc,
                hostElem,
                minZObjetivo);

            if (nivelBase == null)
                return false;

            Wall newWall = Wall.Create(
                doc,
                profile,
                tipoMuro.Id,
                nivelBase.Id,
                false,
                normalModelo);

            if (newWall == null)
                return false;

            doc.Regenerate();

            TrySetParameter(
                newWall,
                BuiltInParameter.WALL_BASE_CONSTRAINT,
                nivelBase.Id);

            TrySetParameter(
                newWall,
                BuiltInParameter.WALL_BASE_OFFSET,
                global::MYG_Addin.TarrajeoAlturas.CalcularDesfaseMuro(
                    minZObjetivo,
                    nivelBase.ProjectElevation));

            doc.Regenerate();

            Safe(() =>
            {
                if (newWall.Orientation.DotProduct(normalModelo) < 0)
                {
                    newWall.Flip();
                    doc.Regenerate();
                }
            });

            Safe(() =>
            {
                XYZ targetMidOrigin = originModelo + normalModelo * (espesor / 2.0);

                double dMid = GetLocationCurveMidDistanceToPlane(
                    newWall,
                    targetMidOrigin,
                    normalModelo);

                if (Math.Abs(dMid) > 1e-6)
                {
                    ElementTransformUtils.MoveElement(
                        doc,
                        newWall.Id,
                        -normalModelo * dMid);

                    doc.Regenerate();
                }
            });

            if (permitirUnion)
            {
                Safe(() => WallUtils.AllowWallJoinAtEnd(newWall, 0));
                Safe(() => WallUtils.AllowWallJoinAtEnd(newWall, 1));
            }
            else
            {
                Safe(() => WallUtils.DisallowWallJoinAtEnd(newWall, 0));
                Safe(() => WallUtils.DisallowWallJoinAtEnd(newWall, 1));
            }

            doc.Regenerate();

            return true;
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // CREAR SUELO DESDE REFERENCIA DE CARA
    // Usado por: Tarrajeo por caras
    // =========================================================
    public static bool CrearSueloDesdeReferencia(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        Reference faceRef,
        FloorType tipoSuelo)
    {
        try
        {
            if (doc == null) return false;
            if (uidoc == null) return false;
            if (hostElem == null) return false;
            if (faceRef == null) return false;
            if (tipoSuelo == null) return false;

            //-------------------------------------------------
            // IMPORTANTE:
            // Ahora los suelos por cara también usan la misma
            // lógica que los muros para obtener la cara real en
            // coordenadas de modelo.
            //
            // Esto corrige el problema en modelos in situ donde
            // el suelo se creaba en la posición original/local
            // del modelo y no donde se picó la cara.
            //-------------------------------------------------
            PlanarFace hostFace;
            XYZ originModelo;
            XYZ normalModelo;
            List<CurveLoop> loopsModelo;

            if (!TryGetFaceModelData(
                    hostElem,
                    faceRef,
                    false,
                    out hostFace,
                    out originModelo,
                    out normalModelo,
                    out loopsModelo))
            {
                return false;
            }

            return CrearSueloDesdeDatosDeCara(
                doc,
                uidoc,
                hostElem,
                originModelo,
                normalModelo,
                loopsModelo,
                tipoSuelo);
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // CREAR SUELO DESDE PLANARFACE
    // Usado por: Tarrajeo por elementos
    // =========================================================
    public static bool CrearSueloDesdeCara(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        PlanarFace hostFace,
        FloorType tipoSuelo)
    {
        try
        {
            if (doc == null) return false;
            if (uidoc == null) return false;
            if (hostElem == null) return false;
            if (hostFace == null) return false;
            if (tipoSuelo == null) return false;

            XYZ normalModelo = hostFace.FaceNormal.Normalize();
            XYZ originModelo = hostFace.Origin;

            List<CurveLoop> loopsModelo = TransformCurveLoops(
                hostFace.GetEdgesAsCurveLoops(),
                Transform.Identity);

            return CrearSueloDesdeDatosDeCara(
                doc,
                uidoc,
                hostElem,
                originModelo,
                normalModelo,
                loopsModelo,
                tipoSuelo);
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // LÓGICA ÚNICA REAL DE CREACIÓN DE SUELO
    // =========================================================
    private static bool CrearSueloDesdeDatosDeCara(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        XYZ originModelo,
        XYZ normalModelo,
        List<CurveLoop> loopsModelo,
        FloorType tipoSuelo)
    {
        try
        {
            if (doc == null) return false;
            if (uidoc == null) return false;
            if (hostElem == null) return false;
            if (tipoSuelo == null) return false;
            if (loopsModelo == null || loopsModelo.Count == 0) return false;

            normalModelo = normalModelo.Normalize();

            // Evita que el flujo de suelos cree desde caras verticales
            if (Math.Abs(normalModelo.Z) < 0.001)
                return false;

            double espesor = GetFloorThickness(tipoSuelo);

            List<CurveLoop> loops3D = loopsModelo;

            if (loops3D == null || loops3D.Count == 0)
                return false;

            Solid baseSolid = null;

            try
            {
                baseSolid = GeometryCreationUtilities.CreateExtrusionGeometry(
                    loops3D,
                    normalModelo,
                    0.1);
            }
            catch
            {
                return false;
            }

            if (baseSolid == null || baseSolid.Volume <= 0)
                return false;

            Outline outline = CreateOutlineForElement(
                hostElem,
                SearchMargin);

            if (outline == null)
                return false;

            List<Element> intersectores = GetIntersectingElements(
                doc,
                uidoc,
                outline,
                hostElem.Id);

            foreach (Element e in intersectores)
            {
                foreach (Solid solidE in GetElementSolids(e))
                {
                    try
                    {
                        if (solidE == null || solidE.Volume <= 0)
                            continue;

                        Solid resultSolid =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                baseSolid,
                                solidE,
                                BooleanOperationsType.Difference);

                        if (resultSolid != null && resultSolid.Volume > 0)
                            baseSolid = resultSolid;
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

            Level nivel = GetBaseLevelForFloor(
                doc,
                hostElem,
                originModelo.Z);

            if (nivel == null)
                return false;

            List<CurveLoop> horizontalSketch = new List<CurveLoop>();

            PlanarFace processedFace = baseSolid.Faces
                .Cast<Face>()
                .OfType<PlanarFace>()
                .Where(pf => AreParallel(pf.FaceNormal, normalModelo))
                .OrderBy(pf => Math.Abs((pf.Origin - originModelo).DotProduct(normalModelo)))
                .FirstOrDefault();

            if (processedFace == null)
                return false;

            double zSketch = nivel.ProjectElevation;

            Plane hostPlane = Plane.CreateByNormalAndOrigin(
                normalModelo,
                originModelo);

            foreach (CurveLoop loop in processedFace.GetEdgesAsCurveLoops())
            {
                CurveLoop flatLoop = new CurveLoop();

                foreach (Curve curve in loop)
                {
                    XYZ p1 = curve.GetEndPoint(0);
                    XYZ p2 = curve.GetEndPoint(1);

                    XYZ p1OnHostPlane = ProjectPointToPlane(p1, hostPlane);
                    XYZ p2OnHostPlane = ProjectPointToPlane(p2, hostPlane);

                    XYZ pFinal1 = new XYZ(
                        p1OnHostPlane.X,
                        p1OnHostPlane.Y,
                        zSketch);

                    XYZ pFinal2 = new XYZ(
                        p2OnHostPlane.X,
                        p2OnHostPlane.Y,
                        zSketch);

                    if (pFinal1.DistanceTo(pFinal2) > 0.0001)
                    {
                        flatLoop.Append(Line.CreateBound(pFinal1, pFinal2));
                    }
                }

                if (!flatLoop.IsOpen())
                {
                    horizontalSketch.Add(flatLoop);
                }
            }

            if (horizontalSketch.Count == 0)
                return false;

            bool esInclinado =
                Math.Abs(Math.Abs(normalModelo.Z) - 1.0) > 0.001;

            Floor newFloor = Floor.Create(
                doc,
                horizontalSketch,
                tipoSuelo.Id,
                nivel.Id);

            if (newFloor == null)
                return false;

            doc.Regenerate();

            //-------------------------------------------------
            // IMPORTANTE:
            // Ya NO se suma el parámetro "Elevación desde el nivel"
            // del modelo in situ.
            //
            // La geometría real ya viene con su ubicación correcta.
            // Sumarlo nuevamente hacía que el suelo se baje/suba dos veces.
            //-------------------------------------------------

            if (!esInclinado)
            {
                double offset = global::MYG_Addin.TarrajeoAlturas.CalcularDesfase(
                    originModelo.Z, nivel.ProjectElevation, normalModelo.Z, espesor, 0.0);

                Parameter pOffset =
                    newFloor.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM);

                if (pOffset != null && !pOffset.IsReadOnly)
                    pOffset.Set(offset);
            }
            else
            {
                SlabShapeEditor shapeEditor = newFloor.GetSlabShapeEditor();

                if (shapeEditor != null)
                {
                    shapeEditor.Enable();
                    doc.Regenerate();

                    double D =
                        -(normalModelo.X * originModelo.X +
                          normalModelo.Y * originModelo.Y +
                          normalModelo.Z * originModelo.Z);

                    foreach (SlabShapeVertex vertex in shapeEditor.SlabShapeVertices)
                    {
                        XYZ vPos = vertex.Position;

                        if (Math.Abs(normalModelo.Z) > 0.0001)
                        {
                            double globalZ =
                                (-D -
                                 (normalModelo.X * vPos.X) -
                                 (normalModelo.Y * vPos.Y)) /
                                normalModelo.Z;

                            double elevationValue = global::MYG_Addin.TarrajeoAlturas.CalcularDesfase(
                                globalZ, nivel.ProjectElevation, normalModelo.Z, espesor, 0.0);

                            shapeEditor.ModifySubElement(
                                vertex,
                                elevationValue);
                        }
                    }
                }
            }

            doc.Regenerate();

            return true;
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // PERFIL BOOLEAN PARA MUROS
    // Descuenta elementos que interfieren con la cara.
    // Si la cara queda totalmente cubierta, devuelve perfil vacío.
    // Si no hay interferencia real, devuelve null para usar perfil original.
    // =========================================================
    private static ProfileData TryBuildBooleanWallProfile(
        Document doc,
        UIDocument uidoc,
        Element hostElem,
        CurveLoop outerLoop,
        Plane hostPlane,
        XYZ originModelo,
        XYZ normalModelo,
        double espesor)
    {
        try
        {
            if (doc == null)
                return null;

            if (hostElem == null)
                return null;

            if (outerLoop == null)
                return null;

            normalModelo = normalModelo.Normalize();

            double profundidad = Math.Max(
                espesor + MordidaOffset,
                BooleanDepthMin);

            //-------------------------------------------------
            // Crear sólido base del tarrajeo.
            // Se empuja ligeramente hacia afuera para evitar
            // falsos negativos por caras coincidentes.
            //-------------------------------------------------
            Solid baseSolid = GeometryCreationUtilities.CreateExtrusionGeometry(
                new List<CurveLoop> { outerLoop },
                normalModelo,
                profundidad);

            if (baseSolid == null || baseSolid.Volume <= MordidaVolumeTol)
                return null;

            baseSolid = SolidUtils.CreateTransformed(
                baseSolid,
                Transform.CreateTranslation(normalModelo * MordidaOffset));

            if (baseSolid == null || baseSolid.Volume <= MordidaVolumeTol)
                return null;

            Outline outline = CreateOutlineFromLoop(
                outerLoop,
                normalModelo,
                profundidad + MordidaOffset);

            if (outline == null)
                return null;

            //-------------------------------------------------
            // Buscar elementos que realmente interfieran.
            //-------------------------------------------------
            List<Element> intersectores = GetIntersectingElements(
                doc,
                uidoc,
                outline,
                hostElem.Id);

            if (intersectores == null || intersectores.Count == 0)
                return null;

            bool huboInterseccionReal = false;

            foreach (Element e in intersectores)
            {
                if (!IsValidIntersectingElement(e))
                    continue;

                foreach (Solid solidE in GetElementSolids(e))
                {
                    try
                    {
                        if (solidE == null || solidE.Volume <= MordidaVolumeTol)
                            continue;

                        //-------------------------------------------------
                        // Primero verificamos si realmente intersecta.
                        //-------------------------------------------------
                        Solid interSolid =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                baseSolid,
                                solidE,
                                BooleanOperationsType.Intersect);

                        if (interSolid == null ||
                            interSolid.Volume <= MordidaVolumeTol)
                        {
                            continue;
                        }

                        huboInterseccionReal = true;

                        //-------------------------------------------------
                        // Descontar el sólido intersector.
                        //-------------------------------------------------
                        Solid resultSolid =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                baseSolid,
                                solidE,
                                BooleanOperationsType.Difference);

                        //-------------------------------------------------
                        // Si el resultado se queda sin volumen,
                        // significa que la cara estaba completamente tapada.
                        //-------------------------------------------------
                        if (resultSolid == null ||
                            resultSolid.Volume <= MordidaVolumeTol)
                        {
                            return new ProfileData
                            {
                                Curves = new List<Curve>(),
                                Points = new List<XYZ>()
                            };
                        }

                        baseSolid = resultSolid;
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

            //-------------------------------------------------
            // Si no hubo intersección real, no tocar el perfil original.
            //-------------------------------------------------
            if (!huboInterseccionReal)
                return null;

            //-------------------------------------------------
            // Buscar caras paralelas a la cara original, tomando como
            // referencia el plano ligeramente desplazado hacia afuera.
            //-------------------------------------------------
            XYZ planoReferencia = originModelo + normalModelo * MordidaOffset;

            List<PlanarFace> carasParalelas = baseSolid.Faces
                .Cast<Face>()
                .OfType<PlanarFace>()
                .Where(pf => AreParallel(pf.FaceNormal, normalModelo))
                .ToList();

            if (carasParalelas.Count == 0)
            {
                return new ProfileData
                {
                    Curves = new List<Curve>(),
                    Points = new List<XYZ>()
                };
            }

            double minDist = carasParalelas
                .Min(pf => Math.Abs((pf.Origin - planoReferencia).DotProduct(normalModelo)));

            List<PlanarFace> carasSketch = carasParalelas
                .Where(pf =>
                    Math.Abs(
                        Math.Abs((pf.Origin - planoReferencia).DotProduct(normalModelo)) -
                        minDist) < MordidaPlaneTol)
                .ToList();

            if (carasSketch.Count == 0)
            {
                return new ProfileData
                {
                    Curves = new List<Curve>(),
                    Points = new List<XYZ>()
                };
            }

            XYZ xAxis = GetHorizontalAxis(normalModelo);
            XYZ yAxis = XYZ.BasisZ;
            XYZ originPerfil = hostPlane.Origin + normalModelo * (espesor / 2.0);

            List<List<XYZ>> loopsPerfil = new List<List<XYZ>>();

            foreach (PlanarFace pf in carasSketch)
            {
                foreach (CurveLoop loop in pf.GetEdgesAsCurveLoops())
                {
                    List<XYZ> ptsLoop = new List<XYZ>();

                    foreach (Curve curve in loop)
                    {
                        XYZ p1 = curve.GetEndPoint(0);

                        //-------------------------------------------------
                        // Se proyecta al plano real de la cara original,
                        // y luego se lleva al eje medio del muro de tarrajeo.
                        //-------------------------------------------------
                        XYZ p1OnPlane = ProjectPointToPlane(
                            p1,
                            hostPlane);

                        XYZ pFinal =
                            p1OnPlane + normalModelo * (espesor / 2.0);

                        AddPointIfValid(
                            ptsLoop,
                            pFinal);
                    }

                    RemoveClosingPoint(ptsLoop);

                    if (ptsLoop.Count < 3)
                        continue;

                    ptsLoop = CleanPointLoop(
                        ptsLoop,
                        originPerfil,
                        xAxis,
                        yAxis);

                    if (ptsLoop == null || ptsLoop.Count < 3)
                        continue;

                    double area = Math.Abs(
                        GetSignedArea2D(
                            ptsLoop,
                            originPerfil,
                            xAxis,
                            yAxis));

                    if (area <= MordidaMinArea)
                        continue;

                    loopsPerfil.Add(ptsLoop);
                }
            }

            if (loopsPerfil.Count == 0)
            {
                return new ProfileData
                {
                    Curves = new List<Curve>(),
                    Points = new List<XYZ>()
                };
            }

            loopsPerfil = loopsPerfil
                .OrderByDescending(l =>
                    Math.Abs(GetSignedArea2D(l, originPerfil, xAxis, yAxis)))
                .ToList();

            List<Curve> curvas = BuildProfileCurves(loopsPerfil);

            if (curvas == null || curvas.Count < 3)
            {
                return new ProfileData
                {
                    Curves = new List<Curve>(),
                    Points = new List<XYZ>()
                };
            }

            List<XYZ> puntos = loopsPerfil
                .SelectMany(l => l)
                .ToList();

            return new ProfileData
            {
                Curves = curvas,
                Points = puntos
            };
        }
        catch
        {
            return null;
        }
    }

    // =========================================================
    // CORREGIR NORMAL HACIA AFUERA POR MUESTREO CONTRA SÓLIDO HOST
    // =========================================================
    private static bool CorrectNormalByHostSolidProbe(
        Element hostElem,
        CurveLoop outerLoop,
        ref XYZ normalModelo)
    {
        try
        {
            if (hostElem == null)
                return false;

            if (outerLoop == null)
                return false;

            if (normalModelo == null)
                return false;

            normalModelo = normalModelo.Normalize();

            double volPlus = GetHostIntersectionVolumeForDirection(
                hostElem,
                outerLoop,
                normalModelo);

            double volMinus = GetHostIntersectionVolumeForDirection(
                hostElem,
                outerLoop,
                normalModelo.Negate());

            //-------------------------------------------------
            // Si el lado + normal intersecta más con el host,
            // significa que esa normal entra al sólido.
            // Entonces se invierte para que el tarrajeo salga afuera.
            //-------------------------------------------------
            if (volPlus > volMinus + NormalProbeVolumeTol)
            {
                normalModelo = normalModelo.Negate();
                return true;
            }

            return false;
        }
        catch
        {
            return false;
        }
    }

    private static double GetHostIntersectionVolumeForDirection(
        Element hostElem,
        CurveLoop outerLoop,
        XYZ direction)
    {
        try
        {
            if (hostElem == null)
                return 0.0;

            if (outerLoop == null)
                return 0.0;

            if (direction == null)
                return 0.0;

            direction = direction.Normalize();

            List<XYZ> puntosMuestra = GetNormalProbeSamplePoints(
                outerLoop,
                direction);

            if (puntosMuestra == null || puntosMuestra.Count == 0)
                return 0.0;

            List<Solid> hostSolids = GetElementSolids(hostElem);

            if (hostSolids == null || hostSolids.Count == 0)
                return 0.0;

            double totalVolume = 0.0;

            foreach (XYZ punto in puntosMuestra)
            {
                Solid probeSolid = CreateNormalProbePatchSolid(
                    punto,
                    direction);

                if (probeSolid == null ||
                    probeSolid.Volume <= NormalProbeVolumeTol)
                {
                    continue;
                }

                foreach (Solid hostSolid in hostSolids)
                {
                    try
                    {
                        if (hostSolid == null ||
                            hostSolid.Volume <= NormalProbeVolumeTol)
                        {
                            continue;
                        }

                        Solid interSolid =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                probeSolid,
                                hostSolid,
                                BooleanOperationsType.Intersect);

                        if (interSolid != null &&
                            interSolid.Volume > NormalProbeVolumeTol)
                        {
                            totalVolume += interSolid.Volume;
                        }
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

            return totalVolume;
        }
        catch
        {
            return 0.0;
        }
    }

    private static List<XYZ> GetNormalProbeSamplePoints(
        CurveLoop outerLoop,
        XYZ normalModelo)
    {
        List<XYZ> muestras = new List<XYZ>();

        try
        {
            if (outerLoop == null)
                return muestras;

            if (normalModelo == null)
                return muestras;

            normalModelo = normalModelo.Normalize();

            List<XYZ> vertices = new List<XYZ>();

            foreach (Curve c in outerLoop)
            {
                if (c == null)
                    continue;

                AddPointIfValid(
                    vertices,
                    c.GetEndPoint(0));
            }

            RemoveClosingPoint(vertices);

            if (vertices.Count < 3)
                return muestras;

            Plane plane = Plane.CreateByNormalAndOrigin(
                normalModelo,
                vertices[0]);

            XYZ xAxis;
            XYZ yAxis;

            GetPlaneAxes(
                normalModelo,
                out xAxis,
                out yAxis);

            List<XYZ> ptsPlane = new List<XYZ>();

            foreach (XYZ p in vertices)
            {
                ptsPlane.Add(
                    ProjectPointToPlane(
                        p,
                        plane));
            }

            List<UV> poly2D = ptsPlane
                .Select(p => To2D(
                    p,
                    plane.Origin,
                    xAxis,
                    yAxis))
                .ToList();

            if (poly2D.Count < 3)
                return muestras;

            double minU = poly2D.Min(p => p.U);
            double maxU = poly2D.Max(p => p.U);
            double minV = poly2D.Min(p => p.V);
            double maxV = poly2D.Max(p => p.V);

            double rangoU = maxU - minU;
            double rangoV = maxV - minV;

            if (rangoU < Tol || rangoV < Tol)
                return muestras;

            //-------------------------------------------------
            // Muestras internas en una grilla 2D.
            // Esto funciona mejor que usar solo el centro,
            // sobre todo en caras cóncavas o irregulares.
            //-------------------------------------------------
            for (int i = 0; i < NormalProbeGrid; i++)
            {
                for (int j = 0; j < NormalProbeGrid; j++)
                {
                    double u = minU + rangoU * ((i + 0.5) / NormalProbeGrid);
                    double v = minV + rangoV * ((j + 0.5) / NormalProbeGrid);

                    UV uv = new UV(u, v);

                    if (!PointInPolygon2D(uv, poly2D))
                        continue;

                    XYZ p3d =
                        plane.Origin +
                        xAxis * uv.U +
                        yAxis * uv.V;

                    AddPointIfValid(
                        muestras,
                        p3d);

                    if (muestras.Count >= NormalProbeMaxPoints)
                        return muestras;
                }
            }

            //-------------------------------------------------
            // Fallback: centro promedio, solo si cae dentro.
            //-------------------------------------------------
            if (muestras.Count == 0)
            {
                XYZ centro = XYZ.Zero;

                foreach (XYZ p in ptsPlane)
                    centro += p;

                centro = centro / ptsPlane.Count;

                UV centro2D = To2D(
                    centro,
                    plane.Origin,
                    xAxis,
                    yAxis);

                if (PointInPolygon2D(centro2D, poly2D))
                {
                    AddPointIfValid(
                        muestras,
                        centro);
                }
            }

            return muestras;
        }
        catch
        {
            return muestras;
        }
    }

    private static Solid CreateNormalProbePatchSolid(
        XYZ punto,
        XYZ direction)
    {
        try
        {
            if (punto == null)
                return null;

            if (direction == null)
                return null;

            direction = direction.Normalize();

            XYZ xAxis;
            XYZ yAxis;

            GetPlaneAxes(
                direction,
                out xAxis,
                out yAxis);

            double h = NormalProbePatchSize / 2.0;

            //-------------------------------------------------
            // Se desplaza ligeramente hacia el lado probado.
            // Así evitamos que el contacto coplanar con la cara
            // genere falsos positivos.
            //-------------------------------------------------
            XYZ centro = punto + direction * NormalProbeOffset;

            XYZ p1 = centro - xAxis * h - yAxis * h;
            XYZ p2 = centro + xAxis * h - yAxis * h;
            XYZ p3 = centro + xAxis * h + yAxis * h;
            XYZ p4 = centro - xAxis * h + yAxis * h;

            CurveLoop loop = new CurveLoop();

            loop.Append(Line.CreateBound(p1, p2));
            loop.Append(Line.CreateBound(p2, p3));
            loop.Append(Line.CreateBound(p3, p4));
            loop.Append(Line.CreateBound(p4, p1));

            Solid solid = GeometryCreationUtilities.CreateExtrusionGeometry(
                new List<CurveLoop> { loop },
                direction,
                NormalProbeDepth);

            return solid;
        }
        catch
        {
            return null;
        }
    }

    // =========================================================
    // FILTROS PARA EVITAR CARAS INTERNAS Y MUROS DUPLICADOS
    // =========================================================
    private static bool IsValidWallFaceForCreation(
        Element hostElem,
        CurveLoop outerLoop,
        XYZ originModelo,
        XYZ normalModelo)
    {
        try
        {
            if (hostElem == null)
                return true;

            Wall hostWall = hostElem as Wall;

            // Para familias in situ, escaleras, masas u otros elementos,
            // se mantiene la lógica original: se permiten las caras verticales.
            if (hostWall == null)
                return true;

            LocationCurve lc = hostWall.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return true;

            Curve curve = lc.Curve;

            if (outerLoop == null)
                return true;

            normalModelo = normalModelo.Normalize();

            Plane plane = Plane.CreateByNormalAndOrigin(
                normalModelo,
                originModelo);

            List<XYZ> pts = GetLoopVertexPoints(
                outerLoop,
                plane);

            if (pts == null || pts.Count == 0)
                return true;

            XYZ faceCenter = XYZ.Zero;

            foreach (XYZ p in pts)
                faceCenter += p;

            faceCenter = faceCenter / pts.Count;

            XYZ p0 = curve.GetEndPoint(0);
            XYZ p1 = curve.GetEndPoint(1);

            XYZ p0h = new XYZ(p0.X, p0.Y, 0.0);
            XYZ p1h = new XYZ(p1.X, p1.Y, 0.0);
            XYZ ph = new XYZ(faceCenter.X, faceCenter.Y, 0.0);

            XYZ wallDir = p1h - p0h;
            double wallLength = wallDir.GetLength();

            if (wallLength < Tol)
                return true;

            wallDir = wallDir.Normalize();

            XYZ wallSide = XYZ.BasisZ.CrossProduct(wallDir);

            if (wallSide.GetLength() < Tol)
                return true;

            wallSide = wallSide.Normalize();

            XYZ normalH = new XYZ(
                normalModelo.X,
                normalModelo.Y,
                0.0);

            if (normalH.GetLength() < Tol)
                return false;

            normalH = normalH.Normalize();

            XYZ v = ph - p0h;

            double sideDist = Math.Abs(v.DotProduct(wallSide));

            //-------------------------------------------------
            // NUEVA LÓGICA:
            // Antes se omitían caras si no estaban cerca de ± ancho/2.
            // Eso causaba que se pierdan caras reales en encuentros,
            // extremos, uniones y muros cortados.
            //
            // Ahora SOLO se omiten caras claramente ubicadas en el eje
            // del muro, porque esas son las que generaban tarrajeo
            // en el centro/eje.
            //-------------------------------------------------

            bool normalEsLateral =
                Math.Abs(normalH.DotProduct(wallSide)) > 0.70;

            if (normalEsLateral)
            {
                // Si está prácticamente en el eje del muro, se omite.
                // Esto evita el muro superpuesto en el eje.
                if (sideDist < WallFaceOffsetTol)
                    return false;

                // Cualquier otra cara lateral se permite.
                return true;
            }

            //-------------------------------------------------
            // Caras de extremos del muro:
            // se permiten siempre, porque en encuentros y muros cortados
            // Revit puede devolver caras de extremo válidas que no están
            // exactamente en el inicio o fin geométrico del LocationCurve.
            //-------------------------------------------------
            bool normalEsExtremo =
                Math.Abs(normalH.DotProduct(wallDir)) > 0.70;

            if (normalEsExtremo)
                return true;

            //-------------------------------------------------
            // Para cualquier cara vertical no clasificada claramente,
            // se permite crear tarrajeo.
            //-------------------------------------------------
            return true;
        }
        catch
        {
            return true;
        }
    }

    private static bool ExistsDuplicateWallInSamePosition(
        Document doc,
        ElementId hostId,
        WallType tipoMuro,
        XYZ normalModelo,
        List<XYZ> ptsPerfil)
    {
        try
        {
            if (doc == null)
                return false;

            if (tipoMuro == null)
                return false;

            if (ptsPerfil == null || ptsPerfil.Count < 3)
                return false;

            normalModelo = normalModelo.Normalize();

            XYZ xAxis = GetHorizontalAxis(normalModelo);
            XYZ planeOrigin = ptsPerfil[0];

            double minU = ptsPerfil
                .Min(p => (p - planeOrigin).DotProduct(xAxis));

            double maxU = ptsPerfil
                .Max(p => (p - planeOrigin).DotProduct(xAxis));

            double minZ = ptsPerfil.Min(p => p.Z);
            double maxZ = ptsPerfil.Max(p => p.Z);

            Outline outline = CreateOutlineFromPoints(
                ptsPerfil,
                Math.Max(DuplicateWallTol, tipoMuro.Width + DuplicateWallTol));

            if (outline == null)
                return false;

            List<ElementId> excluir = new List<ElementId>();

            if (hostId != null && hostId != ElementId.InvalidElementId)
                excluir.Add(hostId);

            FilteredElementCollector collector =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(Wall))
                    .WhereElementIsNotElementType()
                    .WherePasses(new BoundingBoxIntersectsFilter(outline));

            if (excluir.Count > 0)
                collector = collector.Excluding(excluir);

            List<Wall> walls = collector
                .Cast<Wall>()
                .Where(w => w != null &&
                            w.GetTypeId().Equals(tipoMuro.Id))
                .ToList();

            foreach (Wall wall in walls)
            {
                LocationCurve lc = wall.Location as LocationCurve;

                if (lc == null || lc.Curve == null)
                    continue;

                XYZ p0 = lc.Curve.GetEndPoint(0);
                XYZ p1 = lc.Curve.GetEndPoint(1);

                double d0 = Math.Abs((p0 - planeOrigin).DotProduct(normalModelo));
                double d1 = Math.Abs((p1 - planeOrigin).DotProduct(normalModelo));

                if (d0 > DuplicateWallTol || d1 > DuplicateWallTol)
                    continue;

                double u0 = (p0 - planeOrigin).DotProduct(xAxis);
                double u1 = (p1 - planeOrigin).DotProduct(xAxis);

                double wallMinU = Math.Min(u0, u1);
                double wallMaxU = Math.Max(u0, u1);
                double wallBaseZ = Math.Min(p0.Z, p1.Z);

                BoundingBoxXYZ bb = wall.get_BoundingBox(null);

                double wallMinZ = wallBaseZ;
                double wallMaxZ = wallBaseZ;

                if (bb != null)
                {
                    List<XYZ> bbPts = GetBoundingBoxPoints(bb);

                    if (bbPts.Count > 0)
                    {
                        wallMinZ = bbPts.Min(p => p.Z);
                        wallMaxZ = bbPts.Max(p => p.Z);
                    }
                }

                bool mismoTramo =
                    Math.Abs(wallMinU - minU) <= DuplicateWallTol &&
                    Math.Abs(wallMaxU - maxU) <= DuplicateWallTol;

                bool mismaBase =
                    Math.Abs(wallMinZ - minZ) <= DuplicateWallTol ||
                    Math.Abs(wallBaseZ - minZ) <= DuplicateWallTol;

                bool mismaAltura =
                    Math.Abs(wallMaxZ - maxZ) <= Math.Max(0.10, DuplicateWallTol);

                if (mismoTramo && mismaBase && mismaAltura)
                    return true;
            }

            return false;
        }
        catch
        {
            return false;
        }
    }

    private static Outline CreateOutlineFromPoints(
        List<XYZ> pts,
        double margin)
    {
        try
        {
            if (pts == null || pts.Count == 0)
                return null;

            double minX = pts.Min(p => p.X) - margin;
            double minY = pts.Min(p => p.Y) - margin;
            double minZ = pts.Min(p => p.Z) - margin;

            double maxX = pts.Max(p => p.X) + margin;
            double maxY = pts.Max(p => p.Y) + margin;
            double maxZ = pts.Max(p => p.Z) + margin;

            return new Outline(
                new XYZ(minX, minY, minZ),
                new XYZ(maxX, maxY, maxZ));
        }
        catch
        {
            return null;
        }
    }

    private static List<XYZ> GetBoundingBoxPoints(
        BoundingBoxXYZ bb)
    {
        List<XYZ> pts = new List<XYZ>();

        if (bb == null)
            return pts;

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        pts.Add(new XYZ(min.X, min.Y, min.Z));
        pts.Add(new XYZ(max.X, min.Y, min.Z));
        pts.Add(new XYZ(min.X, max.Y, min.Z));
        pts.Add(new XYZ(max.X, max.Y, min.Z));
        pts.Add(new XYZ(min.X, min.Y, max.Z));
        pts.Add(new XYZ(max.X, min.Y, max.Z));
        pts.Add(new XYZ(min.X, max.Y, max.Z));
        pts.Add(new XYZ(max.X, max.Y, max.Z));

        if (bb.Transform != null && !bb.Transform.IsIdentity)
        {
            pts = pts
                .Select(p => bb.Transform.OfPoint(p))
                .ToList();
        }

        return pts;
    }

    // =========================================================
    // OBTENER DATA DE CARA DESDE REFERENCIA
    // =========================================================
    private static bool TryGetFaceModelData(
        Element hostElem,
        Reference faceRef,
        bool soloCarasVerticales,
        out PlanarFace hostFace,
        out XYZ originModelo,
        out XYZ normalModelo,
        out List<CurveLoop> loopsModelo)
    {
        hostFace = hostElem.GetGeometryObjectFromReference(faceRef) as PlanarFace;
        originModelo = XYZ.Zero;
        normalModelo = XYZ.BasisX;
        loopsModelo = null;

        if (hostFace == null)
            return false;

        XYZ gp = faceRef.GlobalPoint;

        List<FaceModelCandidate> candidates =
            new List<FaceModelCandidate>();

        Options opt = new Options
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = hostElem.get_Geometry(opt);

        if (geo != null)
            CollectPlanarFaceCandidates(
                geo,
                Transform.Identity,
                candidates);

        FaceModelCandidate best = GetBestCandidate(
            candidates,
            gp,
            soloCarasVerticales);

        if (best != null)
        {
            originModelo = best.Origin;
            normalModelo = best.Normal;
            loopsModelo = TransformCurveLoops(
                best.Loops,
                Transform.Identity);

            return true;
        }

        XYZ rawNormal = hostFace.FaceNormal.Normalize();
        XYZ originRaw = hostFace.Origin;

        List<CurveLoop> loopsRaw = TransformCurveLoops(
            hostFace.GetEdgesAsCurveLoops(),
            Transform.Identity);

        double bestDist = gp != null
            ? Math.Abs((gp - originRaw).DotProduct(rawNormal))
            : double.MaxValue;

        originModelo = originRaw;
        normalModelo = rawNormal;
        loopsModelo = loopsRaw;

        Instance inst = hostElem as Instance;

        if (inst != null)
        {
            try
            {
                Transform tf = inst.GetTransform();

                if (tf != null && !tf.IsIdentity)
                {
                    XYZ originTx = tf.OfPoint(originRaw);
                    XYZ normalTx = tf.OfVector(rawNormal).Normalize();

                    List<CurveLoop> loopsTx = TransformCurveLoops(
                        loopsRaw,
                        tf);

                    double txDist = gp != null
                        ? Math.Abs((gp - originTx).DotProduct(normalTx))
                        : double.MaxValue;

                    if (txDist + Tol < bestDist)
                    {
                        originModelo = originTx;
                        normalModelo = normalTx;
                        loopsModelo = loopsTx;
                    }
                }
            }
            catch
            {
            }
        }

        return true;
    }

    private static FaceModelCandidate GetBestCandidate(
        List<FaceModelCandidate> candidates,
        XYZ gp,
        bool soloCarasVerticales)
    {
        if (candidates == null || candidates.Count == 0)
            return null;

        IEnumerable<FaceModelCandidate> filtered = candidates;

        if (soloCarasVerticales)
        {
            filtered = filtered.Where(c =>
                Math.Abs(c.Normal.Z) < 0.001);
        }

        List<FaceModelCandidate> lista = filtered.ToList();

        if (lista.Count == 0)
            return null;

        if (gp == null)
        {
            return lista
                .OrderByDescending(c => c.Area)
                .FirstOrDefault();
        }

        FaceModelCandidate best = lista
            .Where(c => Math.Abs((gp - c.Origin).DotProduct(c.Normal)) < PlaneTol)
            .Where(c => IsPointInsideCandidate(gp, c))
            .OrderBy(c => Math.Abs((gp - c.Origin).DotProduct(c.Normal)))
            .ThenBy(c => GetDistancePointToFaceCenter(gp, c))
            .ThenByDescending(c => c.Area)
            .FirstOrDefault();

        if (best != null)
            return best;

        return lista
            .OrderBy(c => Math.Abs((gp - c.Origin).DotProduct(c.Normal)))
            .ThenBy(c => GetDistancePointToFaceCenter(gp, c))
            .ThenByDescending(c => c.Area)
            .FirstOrDefault();
    }

    private static void CollectPlanarFaceCandidates(
        GeometryElement geo,
        Transform current,
        List<FaceModelCandidate> candidates)
    {
        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null && solid.Faces.Size > 0)
            {
                foreach (Face face in solid.Faces)
                {
                    PlanarFace pf = face as PlanarFace;

                    if (pf == null)
                        continue;

                    XYZ origin = current.OfPoint(pf.Origin);
                    XYZ normal = current.OfVector(pf.FaceNormal).Normalize();

                    List<CurveLoop> loops = TransformCurveLoops(
                        pf.GetEdgesAsCurveLoops(),
                        current);

                    candidates.Add(new FaceModelCandidate
                    {
                        Origin = origin,
                        Normal = normal,
                        Loops = loops,
                        Area = GetLargestLoopArea(
                            loops,
                            origin,
                            normal)
                    });
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symGeo = gi.GetSymbolGeometry();

                if (symGeo != null)
                {
                    CollectPlanarFaceCandidates(
                        symGeo,
                        current.Multiply(gi.Transform),
                        candidates);
                }
            }
            catch
            {
                Safe(() =>
                {
                    GeometryElement instGeo = gi.GetInstanceGeometry();

                    if (instGeo != null)
                    {
                        CollectPlanarFaceCandidates(
                            instGeo,
                            current,
                            candidates);
                    }
                });
            }
        }
    }

    // =========================================================
    // NIVELES
    // =========================================================
    private static Level GetBaseLevelForWall(
        Document doc,
        Element hostElem,
        double z)
    {
        List<Level> levels = new FilteredElementCollector(doc)
            .OfClass(typeof(Level))
            .Cast<Level>()
            .OrderBy(l => l.ProjectElevation)
            .ToList();

        if (levels.Count == 0)
            return null;

        Level hostLevel = null;

        Safe(() =>
        {
            if (hostElem != null &&
                hostElem.LevelId != ElementId.InvalidElementId)
            {
                hostLevel = doc.GetElement(hostElem.LevelId) as Level;
            }
        });

        return levels
            .Where(l => l.ProjectElevation <= z + 0.001)
            .OrderByDescending(l => l.ProjectElevation)
            .FirstOrDefault()
            ?? hostLevel
            ?? levels.FirstOrDefault();
    }

    private static Level GetBaseLevelForFloor(
        Document doc,
        Element hostElem,
        double z)
    {
        List<Level> levels = new FilteredElementCollector(doc)
            .OfClass(typeof(Level))
            .Cast<Level>()
            .OrderBy(l => l.ProjectElevation)
            .ToList();

        if (levels.Count == 0)
            return null;

        Level hostLevel = null;

        Safe(() =>
        {
            if (hostElem != null &&
                hostElem.LevelId != ElementId.InvalidElementId)
            {
                hostLevel = doc.GetElement(hostElem.LevelId) as Level;
            }
        });

        return hostLevel
            ?? levels
                .Where(l => l.ProjectElevation <= z + 0.001)
                .OrderByDescending(l => l.ProjectElevation)
                .FirstOrDefault()
            ?? levels.FirstOrDefault();
    }

    // =========================================================
    // GEOMETRÍA / INTERSECCIONES
    // =========================================================
    private static List<Element> GetIntersectingElements(
    Document doc,
    UIDocument uidoc,
    Outline outline,
    ElementId hostId)
    {
        try
        {
            if (doc == null)
                return new List<Element>();

            if (outline == null)
                return new List<Element>();

            FilteredElementCollector collector;

            //-------------------------------------------------
            // IMPORTANTE:
            // Descontar SOLO elementos de la vista activa.
            //
            // Si estás en vista 3D con elementos aislados,
            // solo se tomarán en cuenta los elementos visibles
            // dentro de esa vista activa.
            //-------------------------------------------------
            if (uidoc != null && uidoc.ActiveView != null)
            {
                collector = new FilteredElementCollector(
                    doc,
                    uidoc.ActiveView.Id);
            }
            else
            {
                collector = new FilteredElementCollector(doc);
            }

            List<ElementId> excluir = new List<ElementId>();

            if (hostId != null && hostId != ElementId.InvalidElementId)
                excluir.Add(hostId);

            collector = collector
                .WherePasses(new BoundingBoxIntersectsFilter(outline))
                .WhereElementIsNotElementType();

            if (excluir.Count > 0)
                collector = collector.Excluding(excluir);

            return collector
                .Where(e => IsValidIntersectingElement(e))
                .ToList();
        }
        catch
        {
            return new List<Element>();
        }
    }

    private static Outline CreateOutlineForElement(
        Element elem,
        double margin)
    {
        try
        {
            BoundingBoxXYZ bbox = elem.get_BoundingBox(null);

            if (bbox == null)
                return null;

            XYZ min = bbox.Min;
            XYZ max = bbox.Max;

            if (bbox.Transform != null && !bbox.Transform.IsIdentity)
            {
                List<XYZ> pts = new List<XYZ>
                {
                    bbox.Transform.OfPoint(new XYZ(min.X, min.Y, min.Z)),
                    bbox.Transform.OfPoint(new XYZ(max.X, min.Y, min.Z)),
                    bbox.Transform.OfPoint(new XYZ(min.X, max.Y, min.Z)),
                    bbox.Transform.OfPoint(new XYZ(max.X, max.Y, min.Z)),
                    bbox.Transform.OfPoint(new XYZ(min.X, min.Y, max.Z)),
                    bbox.Transform.OfPoint(new XYZ(max.X, min.Y, max.Z)),
                    bbox.Transform.OfPoint(new XYZ(min.X, max.Y, max.Z)),
                    bbox.Transform.OfPoint(new XYZ(max.X, max.Y, max.Z))
                };

                min = new XYZ(
                    pts.Min(p => p.X),
                    pts.Min(p => p.Y),
                    pts.Min(p => p.Z));

                max = new XYZ(
                    pts.Max(p => p.X),
                    pts.Max(p => p.Y),
                    pts.Max(p => p.Z));
            }

            return new Outline(
                min - new XYZ(margin, margin, margin),
                max + new XYZ(margin, margin, margin));
        }
        catch
        {
            return null;
        }
    }

    private static Outline CreateOutlineFromLoop(
        CurveLoop loop,
        XYZ normalModelo,
        double profundidad)
    {
        try
        {
            if (loop == null)
                return null;

            normalModelo = normalModelo.Normalize();

            List<XYZ> pts = new List<XYZ>();

            foreach (Curve c in loop)
            {
                XYZ p0 = c.GetEndPoint(0);
                XYZ p1 = c.GetEndPoint(1);

                pts.Add(p0);
                pts.Add(p1);

                pts.Add(p0 + normalModelo * profundidad);
                pts.Add(p1 + normalModelo * profundidad);

                pts.Add(p0 - normalModelo * SearchMargin);
                pts.Add(p1 - normalModelo * SearchMargin);
            }

            if (pts.Count == 0)
                return null;

            double minX = pts.Min(p => p.X) - SearchMargin;
            double minY = pts.Min(p => p.Y) - SearchMargin;
            double minZ = pts.Min(p => p.Z) - SearchMargin;

            double maxX = pts.Max(p => p.X) + SearchMargin;
            double maxY = pts.Max(p => p.Y) + SearchMargin;
            double maxZ = pts.Max(p => p.Z) + SearchMargin;

            return new Outline(
                new XYZ(minX, minY, minZ),
                new XYZ(maxX, maxY, maxZ));
        }
        catch
        {
            return null;
        }
    }

    private static bool IsValidIntersectingElement(Element e)
    {
        if (e == null)
            return false;

        if (e.Category == null)
            return false;

        if (e.Category.CategoryType != CategoryType.Model)
            return false;

        if (e.ViewSpecific)
            return false;

        return true;
    }

    private static List<Solid> GetElementSolids(Element e)
    {
        List<Solid> solids = new List<Solid>();

        if (e == null)
            return solids;

        Options opt = new Options
        {
            DetailLevel = ViewDetailLevel.Fine,
            ComputeReferences = false,
            IncludeNonVisibleObjects = true
        };

        GeometryElement geoElem = null;

        Safe(() => geoElem = e.get_Geometry(opt));

        if (geoElem == null)
            return solids;

        CollectSolids(
            geoElem,
            Transform.Identity,
            solids);

        return solids;
    }

    private static void CollectSolids(
        GeometryElement geo,
        Transform current,
        List<Solid> solids)
    {
        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                try
                {
                    Solid solidTx =
                        current != null && !current.IsIdentity
                            ? SolidUtils.CreateTransformed(solid, current)
                            : solid;

                    if (solidTx != null &&
                        solidTx.Faces.Size > 0 &&
                        solidTx.Edges.Size > 0 &&
                        solidTx.Volume > 0)
                    {
                        solids.Add(solidTx);
                    }
                }
                catch
                {
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symGeo = gi.GetSymbolGeometry();

                if (symGeo != null)
                {
                    CollectSolids(
                        symGeo,
                        current.Multiply(gi.Transform),
                        solids);
                }
            }
            catch
            {
                Safe(() =>
                {
                    GeometryElement instGeo = gi.GetInstanceGeometry();

                    if (instGeo != null)
                    {
                        CollectSolids(
                            instGeo,
                            current,
                            solids);
                    }
                });
            }
        }
    }

    private static void CollectGeometryPoints(
        GeometryElement geo,
        Transform current,
        List<XYZ> points)
    {
        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null && solid.Edges.Size > 0)
            {
                foreach (Edge edge in solid.Edges)
                {
                    IList<XYZ> pts = edge.Tessellate();

                    foreach (XYZ p in pts)
                        points.Add(current.OfPoint(p));
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symGeo = gi.GetSymbolGeometry();

                if (symGeo != null)
                {
                    CollectGeometryPoints(
                        symGeo,
                        current.Multiply(gi.Transform),
                        points);
                }
            }
            catch
            {
                Safe(() =>
                {
                    GeometryElement instGeo = gi.GetInstanceGeometry();

                    if (instGeo != null)
                    {
                        CollectGeometryPoints(
                            instGeo,
                            current,
                            points);
                    }
                });
            }
        }
    }

    // =========================================================
    // ORIENTACIÓN / CENTROS
    // =========================================================
    private static void CorrectNormalToOutside(
        Document doc,
        Element hostElem,
        XYZ originModelo,
        ref XYZ normalModelo,
        List<CurveLoop> loopsModelo)
    {
        try
        {
            XYZ hostCenter;

            if (!TryGetHostCenter(doc, hostElem, out hostCenter))
                return;

            XYZ faceCenter;

            if (!TryGetFaceCenter(
                    loopsModelo,
                    originModelo,
                    normalModelo,
                    out faceCenter))
            {
                return;
            }

            XYZ centerToFace = faceCenter - hostCenter;

            if (centerToFace.GetLength() < Tol)
                return;

            if (centerToFace.DotProduct(normalModelo) < 0)
                normalModelo = normalModelo.Negate();
        }
        catch
        {
        }
    }

    private static bool TryGetHostCenter(
        Document doc,
        Element hostElem,
        out XYZ center)
    {
        center = XYZ.Zero;

        List<XYZ> points = new List<XYZ>();

        Options opt = new Options
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = hostElem.get_Geometry(opt);

        if (geo != null)
            CollectGeometryPoints(
                geo,
                Transform.Identity,
                points);

        if (points.Count > 0)
        {
            double minX = points.Min(p => p.X);
            double minY = points.Min(p => p.Y);
            double minZ = points.Min(p => p.Z);

            double maxX = points.Max(p => p.X);
            double maxY = points.Max(p => p.Y);
            double maxZ = points.Max(p => p.Z);

            center = new XYZ(
                (minX + maxX) / 2.0,
                (minY + maxY) / 2.0,
                (minZ + maxZ) / 2.0);

            return true;
        }

        BoundingBoxXYZ bb = null;

        Safe(() => bb = hostElem.get_BoundingBox(doc.ActiveView));

        if (bb == null)
            Safe(() => bb = hostElem.get_BoundingBox(null));

        if (bb == null)
            return false;

        XYZ localCenter = (bb.Min + bb.Max) / 2.0;

        center = bb.Transform != null
            ? bb.Transform.OfPoint(localCenter)
            : localCenter;

        return true;
    }

    private static bool TryGetFaceCenter(
        List<CurveLoop> loops,
        XYZ origin,
        XYZ normal,
        out XYZ center)
    {
        center = XYZ.Zero;

        if (loops == null || loops.Count == 0)
            return false;

        Plane plane = Plane.CreateByNormalAndOrigin(
            normal,
            origin);

        CurveLoop outer = GetLargestLoop(
            loops,
            plane,
            normal);

        if (outer == null)
            return false;

        List<XYZ> pts = GetLoopVertexPoints(
            outer,
            plane);

        if (pts == null || pts.Count == 0)
            return false;

        foreach (XYZ p in pts)
            center += p;

        center = center / pts.Count;

        return true;
    }

    private static double GetDistancePointToFaceCenter(
        XYZ point,
        FaceModelCandidate candidate)
    {
        Plane plane = Plane.CreateByNormalAndOrigin(
            candidate.Normal,
            candidate.Origin);

        CurveLoop outer = GetLargestLoop(
            candidate.Loops,
            plane,
            candidate.Normal);

        if (outer == null)
            return double.MaxValue;

        List<XYZ> pts = GetLoopVertexPoints(
            outer,
            plane);

        if (pts == null || pts.Count == 0)
            return double.MaxValue;

        XYZ center = XYZ.Zero;

        foreach (XYZ p in pts)
            center += p;

        center = center / pts.Count;

        return point.DistanceTo(center);
    }

    // =========================================================
    // LOOPS / PERFILES
    // =========================================================
    private static CurveLoop GetLargestLoop(
        List<CurveLoop> loops,
        Plane hostPlane,
        XYZ normalModelo)
    {
        if (loops == null || loops.Count == 0)
            return null;

        XYZ xAxis;
        XYZ yAxis;
        GetPlaneAxes(normalModelo, out xAxis, out yAxis);

        XYZ origin2D = hostPlane.Origin;

        return loops
            .Select(l => new
            {
                Loop = l,
                Points = CleanPointLoop(
                    GetLoopVertexPoints(l, hostPlane),
                    origin2D,
                    xAxis,
                    yAxis)
            })
            .Where(x => x.Points != null && x.Points.Count >= 3)
            .OrderByDescending(x =>
                Math.Abs(GetSignedArea2D(
                    x.Points,
                    origin2D,
                    xAxis,
                    yAxis)))
            .Select(x => x.Loop)
            .FirstOrDefault();
    }

    private static double GetLargestLoopArea(
        List<CurveLoop> loops,
        XYZ origin,
        XYZ normal)
    {
        if (loops == null || loops.Count == 0)
            return 0.0;

        Plane plane = Plane.CreateByNormalAndOrigin(
            normal,
            origin);

        XYZ xAxis;
        XYZ yAxis;
        GetPlaneAxes(normal, out xAxis, out yAxis);

        return loops
            .Select(l => GetLoopVertexPoints(l, plane))
            .Where(p => p != null && p.Count >= 3)
            .Select(p =>
                Math.Abs(GetSignedArea2D(
                    p,
                    plane.Origin,
                    xAxis,
                    yAxis)))
            .DefaultIfEmpty(0.0)
            .Max();
    }

    private static List<XYZ> GetLoopVertexPoints(
        CurveLoop loop,
        Plane plane)
    {
        if (loop == null)
            return null;

        List<XYZ> pts = new List<XYZ>();

        foreach (Curve c in loop)
        {
            XYZ p = ProjectPointToPlane(
                c.GetEndPoint(0),
                plane);

            AddPointIfValid(pts, p);
        }

        RemoveClosingPoint(pts);

        return pts.Count >= 3 ? pts : null;
    }

    private static List<XYZ> BuildTranslatedProfilePoints(
        CurveLoop loop,
        Plane hostPlane,
        XYZ normalModelo,
        double offsetHalfThickness)
    {
        if (loop == null)
            return null;

        List<XYZ> pts = new List<XYZ>();

        foreach (Curve c in loop)
        {
            XYZ pOnPlane = ProjectPointToPlane(
                c.GetEndPoint(0),
                hostPlane);

            XYZ pFinal =
                pOnPlane + normalModelo * offsetHalfThickness;

            AddPointIfValid(pts, pFinal);
        }

        RemoveClosingPoint(pts);

        if (pts.Count < 3)
            return null;

        XYZ origin2D =
            hostPlane.Origin + normalModelo * offsetHalfThickness;

        XYZ xAxis;
        XYZ yAxis;
        GetPlaneAxes(normalModelo, out xAxis, out yAxis);

        return CleanPointLoop(
            pts,
            origin2D,
            xAxis,
            yAxis);
    }

    private static List<Curve> BuildProfileCurves(
        List<XYZ> pts)
    {
        if (pts == null || pts.Count < 3)
            return null;

        List<Curve> curves = new List<Curve>();

        for (int i = 0; i < pts.Count; i++)
        {
            XYZ a = pts[i];
            XYZ b = pts[(i + 1) % pts.Count];

            if (a.DistanceTo(b) > ShortTol)
                curves.Add(Line.CreateBound(a, b));
        }

        return curves.Count >= 3 ? curves : null;
    }

    private static List<Curve> BuildProfileCurves(
        List<List<XYZ>> loops)
    {
        if (loops == null || loops.Count == 0)
            return null;

        List<Curve> result = new List<Curve>();

        foreach (List<XYZ> loop in loops)
        {
            List<Curve> curvas = BuildProfileCurves(loop);

            if (curvas != null && curvas.Count >= 3)
                result.AddRange(curvas);
        }

        return result.Count >= 3 ? result : null;
    }

    private static List<XYZ> CleanPointLoop(
        List<XYZ> pts,
        XYZ origin,
        XYZ xAxis,
        XYZ yAxis)
    {
        if (pts == null || pts.Count < 3)
            return null;

        List<XYZ> clean = new List<XYZ>();

        foreach (XYZ p in pts)
            AddPointIfValid(clean, p);

        RemoveClosingPoint(clean);

        if (clean.Count < 3)
            return null;

        bool changed = true;

        while (changed && clean.Count >= 3)
        {
            changed = false;

            List<XYZ> next = new List<XYZ>();

            for (int i = 0; i < clean.Count; i++)
            {
                XYZ prev = clean[(i - 1 + clean.Count) % clean.Count];
                XYZ curr = clean[i];
                XYZ foll = clean[(i + 1) % clean.Count];

                bool duplicado =
                    curr.DistanceTo(prev) < ShortTol ||
                    curr.DistanceTo(foll) < ShortTol;

                bool colineal =
                    Math.Abs(Cross2D(
                        prev,
                        curr,
                        foll,
                        origin,
                        xAxis,
                        yAxis)) < 1e-8;

                if (duplicado || colineal)
                {
                    changed = true;
                    continue;
                }

                next.Add(curr);
            }

            clean = next;
        }

        return clean.Count >= 3 ? clean : null;
    }

    private static List<CurveLoop> TransformCurveLoops(
        IEnumerable<CurveLoop> source,
        Transform tf)
    {
        List<CurveLoop> result = new List<CurveLoop>();

        if (source == null)
            return result;

        foreach (CurveLoop loop in source)
        {
            CurveLoop newLoop = new CurveLoop();

            foreach (Curve c in loop)
                newLoop.Append(c.CreateTransformed(tf));

            result.Add(newLoop);
        }

        return result;
    }

    // =========================================================
    // 2D / MATEMÁTICAS
    // =========================================================
    private static bool IsPointInsideCandidate(
        XYZ point,
        FaceModelCandidate candidate)
    {
        if (candidate == null ||
            candidate.Loops == null ||
            candidate.Loops.Count == 0)
        {
            return false;
        }

        Plane plane = Plane.CreateByNormalAndOrigin(
            candidate.Normal,
            candidate.Origin);

        CurveLoop outer = GetLargestLoop(
            candidate.Loops,
            plane,
            candidate.Normal);

        if (outer == null)
            return false;

        List<XYZ> polyPts =
            GetLoopVertexPoints(outer, plane);

        if (polyPts == null || polyPts.Count < 3)
            return false;

        XYZ xAxis;
        XYZ yAxis;
        GetPlaneAxes(candidate.Normal, out xAxis, out yAxis);

        UV p2 = To2D(
            ProjectPointToPlane(point, plane),
            plane.Origin,
            xAxis,
            yAxis);

        List<UV> poly2 = polyPts
            .Select(p => To2D(
                p,
                plane.Origin,
                xAxis,
                yAxis))
            .ToList();

        return PointInPolygon2D(p2, poly2);
    }

    private static bool PointInPolygon2D(
        UV p,
        List<UV> poly)
    {
        bool inside = false;

        for (int i = 0, j = poly.Count - 1;
             i < poly.Count;
             j = i++)
        {
            UV pi = poly[i];
            UV pj = poly[j];

            bool intersect =
                ((pi.V > p.V) != (pj.V > p.V)) &&
                p.U <
                (pj.U - pi.U) *
                (p.V - pi.V) /
                ((pj.V - pi.V) + Tol) +
                pi.U;

            if (intersect)
                inside = !inside;
        }

        return inside;
    }

    private static XYZ ProjectPointToPlane(
        XYZ point,
        Plane plane)
    {
        double dist =
            (point - plane.Origin).DotProduct(plane.Normal);

        return point - dist * plane.Normal;
    }

    private static void GetPlaneAxes(
        XYZ normal,
        out XYZ xAxis,
        out XYZ yAxis)
    {
        normal = normal.Normalize();

        XYZ refAxis = Math.Abs(normal.Z) < 0.90
            ? XYZ.BasisZ
            : XYZ.BasisX;

        xAxis = refAxis.CrossProduct(normal);

        if (xAxis.GetLength() < Tol)
            xAxis = XYZ.BasisY.CrossProduct(normal);

        xAxis = xAxis.Normalize();
        yAxis = normal.CrossProduct(xAxis).Normalize();
    }

    private static XYZ GetHorizontalAxis(
        XYZ normalModelo)
    {
        XYZ h = XYZ.BasisZ.CrossProduct(normalModelo);

        if (h.GetLength() < Tol)
            h = XYZ.BasisX;

        return h.Normalize();
    }

    private static UV To2D(
        XYZ p,
        XYZ origin,
        XYZ xAxis,
        XYZ yAxis)
    {
        XYZ v = p - origin;

        return new UV(
            v.DotProduct(xAxis),
            v.DotProduct(yAxis));
    }

    private static double Cross2D(
        XYZ a,
        XYZ b,
        XYZ c,
        XYZ origin,
        XYZ xAxis,
        XYZ yAxis)
    {
        UV pa = To2D(a, origin, xAxis, yAxis);
        UV pb = To2D(b, origin, xAxis, yAxis);
        UV pc = To2D(c, origin, xAxis, yAxis);

        double abx = pb.U - pa.U;
        double aby = pb.V - pa.V;

        double bcx = pc.U - pb.U;
        double bcy = pc.V - pb.V;

        return abx * bcy - aby * bcx;
    }

    private static double GetSignedArea2D(
        List<XYZ> pts,
        XYZ origin,
        XYZ xAxis,
        XYZ yAxis)
    {
        if (pts == null || pts.Count < 3)
            return 0.0;

        double area = 0.0;

        for (int i = 0; i < pts.Count; i++)
        {
            UV p1 = To2D(
                pts[i],
                origin,
                xAxis,
                yAxis);

            UV p2 = To2D(
                pts[(i + 1) % pts.Count],
                origin,
                xAxis,
                yAxis);

            area += p1.U * p2.V - p2.U * p1.V;
        }

        return area * 0.5;
    }

    private static bool AreParallel(
        XYZ v1,
        XYZ v2)
    {
        XYZ a = v1.Normalize();
        XYZ b = v2.Normalize();

        return Math.Abs(Math.Abs(a.DotProduct(b)) - 1.0) < 0.0001;
    }

    // =========================================================
    // PARÁMETROS / UTILIDADES
    // =========================================================
    private static double GetFloorThickness(
        FloorType floorType)
    {
        try
        {
            CompoundStructure cs = floorType.GetCompoundStructure();

            if (cs != null)
                return cs.GetWidth();
        }
        catch
        {
        }

        return 0.0;
    }

    private static void TrySetParameter(
        Element e,
        BuiltInParameter bip,
        ElementId value)
    {
        Safe(() =>
        {
            Parameter p = e.get_Parameter(bip);

            if (p != null && !p.IsReadOnly)
                p.Set(value);
        });
    }

    private static void TrySetParameter(
        Element e,
        BuiltInParameter bip,
        double value)
    {
        Safe(() =>
        {
            Parameter p = e.get_Parameter(bip);

            if (p != null && !p.IsReadOnly)
                p.Set(value);
        });
    }

    private static double GetLocationCurveMidDistanceToPlane(
        Wall wall,
        XYZ planeOrigin,
        XYZ planeNormal)
    {
        LocationCurve lc = wall.Location as LocationCurve;

        if (lc == null || lc.Curve == null)
            return 0.0;

        XYZ p0 = lc.Curve.GetEndPoint(0);
        XYZ p1 = lc.Curve.GetEndPoint(1);

        double d0 = (p0 - planeOrigin).DotProduct(planeNormal);
        double d1 = (p1 - planeOrigin).DotProduct(planeNormal);

        return (d0 + d1) / 2.0;
    }

    private static void AddPointIfValid(
        List<XYZ> pts,
        XYZ p)
    {
        if (pts.Count == 0 ||
            pts.Last().DistanceTo(p) > ShortTol)
        {
            pts.Add(p);
        }
    }

    private static void RemoveClosingPoint(
        List<XYZ> pts)
    {
        if (pts.Count >= 2 &&
            pts.First().DistanceTo(pts.Last()) < ShortTol)
        {
            pts.RemoveAt(pts.Count - 1);
        }
    }

    private static bool EsElementoDeEscalera(Element elem)
    {
        if (elem == null)
            return false;

        if (elem.Category == null)
            return false;

        ElementId catId = elem.Category.Id;

        // Escalera principal
        if (catId.Equals(new ElementId(BuiltInCategory.OST_Stairs)))
            return true;

        // Tramos de escalera
        if (catId.Equals(new ElementId(BuiltInCategory.OST_StairsRuns)))
            return true;

        // Descansos de escalera
        if (catId.Equals(new ElementId(BuiltInCategory.OST_StairsLandings)))
            return true;

        // Soportes de escalera
        if (catId.Equals(new ElementId(BuiltInCategory.OST_StairsSupports)))
            return true;

        return false;
    }

    private static void Safe(Action action)
    {
        try
        {
            action();
        }
        catch
        {
        }
    }
}