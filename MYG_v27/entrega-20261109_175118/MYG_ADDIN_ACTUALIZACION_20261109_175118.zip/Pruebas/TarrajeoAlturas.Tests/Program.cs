using MYG_Addin;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

int passed = 0;
void Equal(string name, double actual, double expected)
{
    if (Math.Abs(actual - expected) > 1e-9)
        throw new Exception($"{name}: expected {expected:R}, actual {actual:R}");
    Console.WriteLine("PASS " + name);
    passed++;
}
void Reject(string name, double zFace, double zLevel)
{
    try { TarrajeoAlturas.CalcularDesfaseMuro(zFace, zLevel); }
    catch (ArgumentException) { Console.WriteLine("PASS " + name); passed++; return; }
    throw new Exception(name + ": invalid input was accepted");
}

// Regression: a level whose displayed survey elevation is ~1296 m must not
// pull a face at project Z=6.5 ft down by that survey displacement.
const double surveyDisplacement = 1296.4110 / 0.3048;
const double faceZ = 6.5;
const double projectLevelZ = 0.0;
Equal("Survey origin does not displace the wall", TarrajeoAlturas.CalcularDesfaseMuro(faceZ, projectLevelZ), 6.5);
if (Math.Abs((faceZ - surveyDisplacement) - 6.5) < 1000)
    throw new Exception("Regression fixture must differ substantially from survey-based subtraction");
Equal("Face base above elevated project level", TarrajeoAlturas.CalcularDesfaseMuro(1003.75, 1000.0), 3.75);
Equal("Face base and project level below zero", TarrajeoAlturas.CalcularDesfaseMuro(-39.0, -45.0), 6.0);
Equal("Face below the only available level", TarrajeoAlturas.CalcularDesfaseMuro(-4.5, 2.0), -6.5);
Equal("Face exactly on level", TarrajeoAlturas.CalcularDesfaseMuro(15.0, 15.0), 0.0);
Equal("Large project translation preserves relative height", TarrajeoAlturas.CalcularDesfaseMuro(8003.25, 8000.0), 3.25);
Equal("Untranslated relative height matches", TarrajeoAlturas.CalcularDesfaseMuro(3.25, 0.0), 3.25);
Equal("Linked geometry translated into host model Z", TarrajeoAlturas.CalcularDesfaseMuro(7.0 + 120.0, 125.0), 2.0);
var offset = TarrajeoAlturas.CalcularDesfaseMuro(27.4, 21.0);
Equal("Reconstructed absolute base equals selected face", 21.0 + offset, 27.4);
Reject("Reject NaN face base", double.NaN, 0.0);
Reject("Reject infinite face base", double.PositiveInfinity, 0.0);
Reject("Reject infinite project elevation", 2.0, double.NegativeInfinity);
Reject("Reject NaN project elevation", 2.0, double.NaN);
Reject("Reject arithmetic overflow", double.MaxValue, -double.MaxValue);
// Keep floor placement invariant while extending the shared height helper.
Equal("Floor below a downward face", TarrajeoAlturas.CalcularDesfase(10, 3, -1, 0.05, 0), 7);
Equal("Floor above an upward face", TarrajeoAlturas.CalcularDesfase(10, 3, 1, 0.05, 0), 7.05);
Equal("Floor below with exterior clearance", TarrajeoAlturas.CalcularDesfase(10, 3, -1, 0.05, 0.01), 6.99);
Equal("Floor above with exterior clearance", TarrajeoAlturas.CalcularDesfase(10, 3, 1, 0.05, 0.01), 7.06);

void Check(string name, bool condition)
{
    if (!condition) throw new Exception(name);
    Console.WriteLine("PASS " + name);
    passed++;
}
string FindRoot(string start)
{
    var folder = new DirectoryInfo(start);
    while (folder != null)
    {
        if (File.Exists(Path.Combine(folder.FullName, "MYG", "MYG.csproj")))
            return folder.FullName;
        folder = folder.Parent;
    }
    throw new Exception("Run these checks from the installed repository, which must contain MYG/MYG.csproj.");
}
var root = FindRoot(AppContext.BaseDirectory);
var sources = Path.Combine(root, "MYG", "Funcionalidades", "Estructuras", "Tarrajeo");
int wallOffsetCallCount = 0;
foreach (var file in new[] { "Tarrajeo_MurosHandler.cs", "TarrajeoCore.cs" })
{
    var tree = CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(sources, file)));
    var syntax = tree.GetRoot();
    Check(file + " does not read survey-based Elevation", !syntax.DescendantNodes()
        .OfType<MemberAccessExpressionSyntax>().Any(m => m.Name.Identifier.ValueText == "Elevation"));
    foreach (var call in syntax.DescendantNodes().OfType<InvocationExpressionSyntax>()
        .Where(c => c.Expression is MemberAccessExpressionSyntax m && m.Name.Identifier.ValueText == "CalcularDesfaseMuro"))
    {
        Check(file + " passes ProjectElevation into wall offset", call.ArgumentList.Arguments.Count == 2 &&
            call.ArgumentList.Arguments[1].Expression is MemberAccessExpressionSyntax level &&
            level.Name.Identifier.ValueText == "ProjectElevation");
        wallOffsetCallCount++;
    }
}
Check("All four wall offset call sites are checked", wallOffsetCallCount == 4);
Console.WriteLine($"{passed}/{passed} numerical and source-integration checks passed. No Revit geometry or model execution tested.");
