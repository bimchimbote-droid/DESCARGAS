# Corrección de altura de muros de Tarrajeo / Encofrado

Se corrige la mezcla de coordenadas de las caras (origen interno del proyecto)
con Level.Elevation (que puede usar el punto topográfico). La selección del nivel
y WALL_BASE_OFFSET usan ahora ProjectElevation en los muros rectangulares,
curvos y de perfil. El cálculo común conserva la altura geométrica de la cara.
No se añade una traslación adicional ni se modifica el espesor o los recortes.
La colocación lateral se mantiene a medio espesor hacia el exterior de la cara.

Los seis modos por elementos (vigas, columnas, muros, cimentaciones, losas,
escaleras) comparten el motor de muros corregido. En vigas, columnas y
cimentaciones, si falla transformar un sólido al modelo activo, se omite:
antes se continuaba con coordenadas locales como si fueran del anfitrión.
El motor alternativo TarrajeoCore también queda coherente.

## Instalación

1. Cierra Revit y respalda los seis archivos REEMPLAZAR de ARCHIVOS.json.
2. Compara tus hashes con sha256_base. Si coinciden, copia los seis archivos
   de MYG/ sobre las mismas rutas de tu solución reestructurada.
3. Si has modificado esos archivos después de la base indicada, NO los
   sustituyas sin combinar los cambios: usa ENTREGA_TARRAJEO/CAMBIOS.patch.
   Desde la raíz del repositorio ejecuta primero:
   git apply --check ENTREGA_TARRAJEO/CAMBIOS.patch
   Solo si pasa y tras revisar el parche, aplica:
   git apply ENTREGA_TARRAJEO/CAMBIOS.patch
   Elige copiar archivos O aplicar el parche, no ambos.
4. No reemplaces MYG.csproj. Los seis .cs existentes ya están incluidos en la
   compilación. Conserva tus dependencias y la salida portable del proyecto.
5. La carpeta Pruebas/ es un proyecto de comprobaciones separado: no agregues
   su Program.cs ni sus referencias Roslyn al proyecto del add-in.
6. Recompila en Visual Studio sobre Windows con Revit y Office instalados.
   Vuelve a abrir Revit y carga tu nueva DLL como lo haces habitualmente.

Se corrigen las NUEVAS creaciones. Los muros ya generados en una posición
incorrecta no se mueven automáticamente. En una copia del modelo, identifica
y elimina solo esos elementos erróneos y vuelve a ejecutar la herramienta.

## Configuración

No se añaden paquetes ni referencias al add-in y no se cambia su framework,
manifest, ventanas, nombres, namespaces, recursos o lógica de licencia.
TarrajeoAlturas.cs ya existía y estaba incluido en MYG.csproj.
Para las pruebas separadas se necesita SDK .NET 10; no requieren Revit ni
paquetes NuGet adicionales. Desde la raíz de la solución:

dotnet run --project Pruebas/TarrajeoAlturas.Tests/TarrajeoAlturas.Tests.csproj -c Release

## GitHub y tu PC

El ZIP se publica únicamente en bimchimbote-droid/DESCARGAS. Publicarlo no
instala el cambio en tu PC ni hace Commit/Push en el repositorio del código.
Tras aplicar y probar: en Visual Studio abre Cambios de Git, revisa únicamente
estos archivos, escribe un mensaje, haz Commit y usa Push cuando decidas
subirlos a TU repositorio de código. No se ha hecho ese Push por tu cuenta.

Consulta BASE_USADA.md y VALIDACION.md antes de reemplazar archivos.
