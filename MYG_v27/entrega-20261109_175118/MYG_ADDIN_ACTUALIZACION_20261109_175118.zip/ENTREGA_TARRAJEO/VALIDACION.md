# Validación y límites

## Ejecutado

- 25/25 comprobaciones numéricas y de integración de fuente: 14 casos de altura
  de muros (desnivel topográfico de 1296.411 m, cotas negativas, niveles elevados,
  traslación a anfitrión, reconstrucción de Z y entradas no finitas), 4 casos de
  suelos y 7 comprobaciones de uso de ProjectElevation en los motores.
- Proyecto de pruebas compilado y ejecutado con SDK .NET 10.0.403.
- Roslyn: 179 fuentes activas, Debug y Release, 0 errores de sintaxis; 9 recursos
  y 3 entradas None existentes, sin duplicados.
- Auditoría de rutas: cara nativa/vinculada y seis selectores de elementos usan
  el motor común. No se añade una transformación a las rutas correctas.
- git diff --check: aprobado.
- Cambios de licencia anteriores: conservados byte por byte.

## Compilación completa intentada

Release|x64 con MSBuild de SDK .NET, referencias net48 restauradas y salida
fuera de las carpetas de Revit. El proceso terminó con código 1 y MSB4803:
ResolveComReference no está soportado por MSBuild de .NET; necesita el MSBuild
.NET Framework de Windows. También reapareció la advertencia preexistente
MSB3277 por versiones de EPPlus.Interfaces. No se generó una nueva MYG.dll.
La compatibilidad net48/Revit2027 del proyecto permanece como estaba.

## Pendiente dentro de Revit (no ejecutado aquí)

Trabaja con una copia del modelo y un tipo del espesor real deseado.
1. Selección de cara vertical de viga: el muro debe cubrir exactamente su rango
   Z y tocar la cara con su superficie interior; verificar desde sección/3D.
2. Mismo caso con Nivel cuya Elevation use el punto topográfico (~1296 m de
   diferencia): base = ProjectElevation del nivel + desfase = Z de la cara.
3. Repetir por elementos: viga, columna, muro, cimentación, losa y escalera.
4. Repetir con vínculo trasladado en Z y rotado y con instancia anidada; la
   transformación debe aplicarse una sola vez al pasar al anfitrión.
5. Perfil irregular, huecos/mordidas y curva cilíndrica: comparar extremos Z,
   perfil y contacto antes/después; probar Permitir Unión activado/desactivado.
6. Suelos en caras superiores/inferiores: confirmar que permanecen como antes.
7. Si un sólido no puede transformarse, debe omitirse sin crear en su origen
   local. Revisar resultados del lote; no se certifica geometría no admitida.

Los cálculos y la lectura de fuente no prueban contacto geométrico dentro de
Revit. No se garantiza ausencia de errores ni se reparan automáticamente los
muros ya creados lejos. CrearConBoceto existe pero no está llamado en esta
versión; si se usara, su muro base también emplearía el rectangular corregido.
