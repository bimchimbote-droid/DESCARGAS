# Base utilizada

- Checkout de trabajo seleccionado: bimchimbote-droid/MYG_v27_reestructurado.
- Commit completo: da11b13a3f5ce35b9565bf4d5bd27cb761091102 (master).
- Referencia indicada en el prompt: bimchimbote-droid/MYG_v27 main,
  a41d354e8206e401a881aacfff3f5da7dfe74d00. Es la base original anterior a la
  reestructuración. No se sustituyó la copia actual por esa versión anterior.
- Comparación adicional: los archivos de este módulo del commit de trabajo
  coinciden byte por byte con las entregas Tarrajeo disponibles en DESCARGAS
  (20261108_111026 y 20261108_111706). Entregas posteriores de muros/suelos de
  Rooms pertenecen a Arquitectura/Habitaciones y no se modificaron.
- Al empezar ya existían cambios locales de licencia/Add-in Manager en:
  MYG/Compartido/Licencias/LicenciaManager.cs,
  MYG/Compartido/Licencias/MYG_ControlAccesoComandos.cs,
  MYG/Funcionalidades/Acceso/MYG_LoginCommand.cs,
  MYG/Funcionalidades/Mep/Tubos/ALINEARTUBOS_EJECUTAR.cs.
  Se verificó que esos cambios se conservan exactamente y quedan fuera del ZIP.
- También quedan fuera los archivos de configuración, dependencias y código sin
  cambios. Los hashes anteriores y finales de los seis archivos afectados están
  en ARCHIVOS.json. Esta entrega conserva la estructura reestructurada.
