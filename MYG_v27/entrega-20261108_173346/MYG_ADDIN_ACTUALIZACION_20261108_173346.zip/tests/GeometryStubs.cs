// Small Euclidean doubles used solely for geometry regression tests.
// These types do not model Revit documents, transactions, solids, joins or room queries.
sealed class XYZ
{
    public double X { get; } public double Y { get; } public double Z { get; }
    public XYZ(double x,double y,double z) { X=x;Y=y;Z=z; }
    public static XYZ operator +(XYZ a,XYZ b)=>new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
    public static XYZ operator -(XYZ a,XYZ b)=>new XYZ(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
    public XYZ Multiply(double k)=>new XYZ(k*X,k*Y,k*Z);
    public double GetLength()=>Math.Sqrt(X*X+Y*Y+Z*Z);
    public XYZ Normalize()=>Multiply(1/GetLength());
    public double DistanceTo(XYZ b)=>(this-b).GetLength();
    public double DotProduct(XYZ b)=>X*b.X+Y*b.Y+Z*b.Z;
    public XYZ CrossProduct(XYZ b)=>new XYZ(Y*b.Z-Z*b.Y,Z*b.X-X*b.Z,X*b.Y-Y*b.X);
}
abstract class Curve
{
    public virtual bool IsBound=>true;
    public abstract XYZ GetEndPoint(int index);
    public double Length=>GetEndPoint(0).DistanceTo(GetEndPoint(1));
}
sealed class Line:Curve
{
    readonly XYZ start,end;
    Line(XYZ a,XYZ b) { start=a;end=b; }
    public static Line CreateBound(XYZ a,XYZ b) { if(a.DistanceTo(b)<1e-9) throw new ArgumentException("Zero line");return new Line(a,b); }
    public override XYZ GetEndPoint(int index)=>index==0?start:end;
}
sealed class Arc:Curve
{
    readonly XYZ start,end;
    public Arc(XYZ a,XYZ b){start=a;end=b;}
    public override XYZ GetEndPoint(int index)=>index==0?start:end;
}
sealed class ElementId { public long Value {get;} public ElementId(long value) {Value=value;} }
sealed class CurvaBoundaryMYG { public Curve Curva {get;set;} public ElementId ElementoBoundaryId {get;set;} }
sealed class VacioPuertaEnSegmento
{
    public ElementId IdPuerta {get;set;}
    public double Inicio {get;set;} public double Fin {get;set;}
    public XYZ DireccionProyeccion {get;set;} public double Profundidad {get;set;}
}
sealed class FakeApplication { public double ShortCurveTolerance=>0.0026; }
sealed class FakeDocument { public FakeApplication Application {get;}=new FakeApplication(); }
sealed class FakeUiDocument { public FakeDocument Document {get;}=new FakeDocument(); }
partial class Handler { public FakeUiDocument UiDoc {get;}=new FakeUiDocument(); }
// Explicit query doubles: deterministic collection, bounding boxes and room-membership.
// Passing these tests does not validate Autodesk query behavior.
abstract class Element
{
    public ElementId Id {get;set;}
    public object Location {get;set;}
    public BoundingBoxXYZ Box {get;set;}
    public BoundingBoxXYZ get_BoundingBox(object view)=>Box;
}
sealed class BoundingBoxXYZ { public XYZ Min {get;set;} public XYZ Max {get;set;} }
sealed class Phase:Element { }
sealed class LocationCurve { public Curve Curve {get;set;} }
sealed class LocationPoint { public XYZ Point {get;set;} }
sealed class Wall:Element { public double Width {get;set;} }
sealed class Level:Element { public double ProjectElevation {get;set;} }
sealed class Room:Element
{
    public ElementId CreatedPhaseId {get;set;}
    public bool MembershipEnabled {get;set;}=true;
    public bool IsPointInRoom(XYZ p)=>MembershipEnabled && Box.Min.X<p.X && p.X<Box.Max.X && Box.Min.Y<p.Y && p.Y<Box.Max.Y && Box.Min.Z<p.Z && p.Z<Box.Max.Z;
}
sealed class FamilyInstance:Element
{
    public Element Host {get;set;}
    public Room From {get;set;} public Room To {get;set;}
    public Room get_FromRoom(Phase phase)=>From;
    public Room get_ToRoom(Phase phase)=>To;
}
enum BuiltInCategory { OST_Doors }
sealed class Document
{
    public List<Element> Elements {get;}=new();
    public Element GetElement(ElementId id)=>Elements.FirstOrDefault(x=>x.Id.Value==id.Value);
}
sealed class FilteredElementCollector:IEnumerable<Element>
{
    readonly Document document;
    public FilteredElementCollector(Document doc) {document=doc;}
    public FilteredElementCollector OfCategory(BuiltInCategory cat)=>this;
    public FilteredElementCollector WhereElementIsNotElementType()=>this;
    public IEnumerator<Element> GetEnumerator()=>document.Elements.GetEnumerator();
    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()=>GetEnumerator();
}
partial class Handler { List<FamilyInstance> _cachePuertasDocumento; }
partial class Handler { double _cotaBaseSuelosFeet, _cotaSuperiorSuelosFeet; }
