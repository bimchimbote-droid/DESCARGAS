#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
handler_path=${1:-../MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs}
if [ "$#" -gt 1 ]; then
  python3 extract_methods.py "$handler_path" "$2"
else
  python3 extract_methods.py "$handler_path"
fi
"${DOTNET_CMD:-dotnet}" run --project Regression.csproj --configuration Release
