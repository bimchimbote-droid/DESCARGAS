// Test expectations are expressed independently as physical dimensions and area.
partial class Handler
{
    static double F(double m)=>m/0.3048;
    static XYZ P(double x,double y)=>new XYZ(F(x),F(y),F(3.25));
    static Line L(double x,double y,double xx,double yy)=>Line.CreateBound(P(x,y),P(xx,yy));
    static CurvaBoundaryMYG B(Curve curve)=>new CurvaBoundaryMYG{Curva=curve,ElementoBoundaryId=new ElementId(17)};
    static VacioPuertaEnSegmento Door(double lo,double hi,double depth=.13)=>new VacioPuertaEnSegmento{Inicio=F(lo),Fin=F(hi),Profundidad=F(depth),DireccionProyeccion=new XYZ(0,-1,0),IdPuerta=new ElementId(5)};
    static void Near(double actual,double expected,string label,double tol=1e-9)
    { if(double.IsNaN(actual)||Math.Abs(actual-expected)>tol) throw new Exception(label+": expected "+expected+", actual "+actual); }
    static void True(bool condition,string label) {if(!condition)throw new Exception(label);}
    static double Area(List<Curve> curves)
    {
        double area=0;
        foreach(var c in curves){var a=c.GetEndPoint(0);var b=c.GetEndPoint(1);area+=a.X*b.Y-b.X*a.Y;}
        return Math.Abs(area)*.5*.3048*.3048;
    }
    static void Connected(List<Curve> curves)
    {
        for(int i=0;i<curves.Count;i++)Near(curves[i].GetEndPoint(1).DistanceTo(curves[(i+1)%curves.Count].GetEndPoint(0)),0,"closed contiguous profile");
    }
    List<Curve> Notched(List<CurvaBoundaryMYG> boundaries,List<VacioPuertaEnSegmento> doors)
    {
        var curves=new List<Curve>();
        foreach(var item in boundaries)
        {
            var a=item.Curva.GetEndPoint(0);var b=item.Curva.GetEndPoint(1);
            if(Math.Abs(a.Y)<1e-10&&Math.Abs(b.Y)<1e-10)
                curves.AddRange(CrearLineaConVaciosDePuerta((Line)item.Curva,doors));
            else curves.Add(item.Curva);
        }
        return curves;
    }
    static List<CurvaBoundaryMYG> Rectangle()=>new(){ B(L(0,0,4,0)),B(L(4,0,4,3)),B(L(4,3,0,3)),B(L(0,3,0,0)) };
    void TestExactDepth()
    {
        var curves=Notched(Rectangle(),new(){Door(1.5,2.5)});
        Connected(curves);Near(Area(curves),12+.13,"rectangular notch area");
        Near(curves.Min(x=>x.GetEndPoint(0).Y)*.3048,-.13,"exact manual depth");
        foreach(var c in curves){Near(c.GetEndPoint(0).Z,F(3.25),"base elevation unchanged");Near(c.GetEndPoint(1).Z,F(3.25),"end elevation unchanged");}
    }
    void TestSplit()
    {
        var original=new List<CurvaBoundaryMYG>{B(L(0,0,2,0)),B(L(2,0,4,0)),B(L(4,0,4,3)),B(L(4,3,0,3)),B(L(0,3,0,0))};
        var merged=UnificarTramosBoundaryColineales(original);
        True(merged.Count==4,"split straight boundary merged");
        True(original.Count==5,"input collection not modified");Near(original[0].Curva.GetEndPoint(1).X,F(2),"input edge not modified");
        var curves=Notched(merged,new(){Door(1.5,2.5)});Connected(curves);Near(Area(curves),12+.13,"door spans previous split at full width");
    }
    void TestCyclic()
    {
        var split=new List<CurvaBoundaryMYG>{B(L(2,0,4,0)),B(L(4,0,4,3)),B(L(4,3,0,3)),B(L(0,3,0,0)),B(L(0,0,2,0))};
        var merged=UnificarTramosBoundaryColineales(split);True(merged.Count==4,"last/first straight segments merged");
        var curves=Notched(merged,new(){Door(1.5,2.5)});Connected(curves);Near(Area(curves),12+.13,"door spans former cyclic seam at full width");
    }
    void TestReverse()
    {
        var reverse=new List<CurvaBoundaryMYG>{B(L(4,0,0,0)),B(L(0,0,0,3)),B(L(0,3,4,3)),B(L(4,3,4,0))};
        var curves=Notched(reverse,new(){Door(1.5,2.5)});Connected(curves);Near(Area(curves),12+.13,"reverse boundary orientation expands outward");
    }
    void TestOverlap()
    {
        var curves=Notched(Rectangle(),new(){Door(1,2),Door(1.5,2.5)});Connected(curves);Near(Area(curves),12+1.5*.13,"overlap union area counted once");
    }
    void TestNoNotches()
    {
        var original=L(0,0,4,0);var curves=CrearLineaConVaciosDePuerta(original,new());
        True(curves.Count==1&&ReferenceEquals(curves[0],original),"empty door list preserves boundary");
        True(CrearLineaConVaciosDePuerta(original,null).Count==1,"null doors preserve boundary");
        Near(Area(Notched(Rectangle(),new())),12,"no-door room area unchanged");
    }
    void TestHeights()
    {
        double level=F(17.4),pickedSurface=F(17.55),lower=F(.05),upper=F(.012);
        double baseOffset=pickedSurface-level;
        double lowerTop=level+CalcularOffsetSuperiorCapa(baseOffset,lower,upper,false);
        double upperTop=level+CalcularOffsetSuperiorCapa(baseOffset,lower,upper,true);
        Near(lowerTop-lower,pickedSurface,"lower slab bottom equals picked surface at nonzero level");
        Near(upperTop-upper,lowerTop,"upper slab bottom equals lower slab top");
        Near(upperTop*0.3048,17.612,"stacked top elevation");
        bool rejected=false;try{CalcularOffsetSuperiorCapa(baseOffset,0,upper,false);}catch(ArgumentException){rejected=true;}True(rejected,"invalid thickness rejected");
    }
    void TestCurvesPreserved()
    {
        var arc=new Arc(P(4,0),P(4,3));var input=new List<CurvaBoundaryMYG>{B(L(0,0,4,0)),B(arc),B(L(4,3,0,3)),B(L(0,3,0,0))};
        var output=UnificarTramosBoundaryColineales(input);True(output.Count==4&&ReferenceEquals(output[1].Curva,arc),"arcs preserved");
        var opposite=new List<CurvaBoundaryMYG>{B(L(0,0,4,0)),B(L(4,0,0,0))};True(UnificarTramosBoundaryColineales(opposite).Count==2,"reversed returns not merged");
    }
    static XYZ At(double x,double y,double z)=>new XYZ(F(x),F(y),F(z));
    static BoundingBoxXYZ Box(double minX,double minY,double minZ,double maxX,double maxY,double maxZ)=>new(){Min=At(minX,minY,minZ),Max=At(maxX,maxY,maxZ)};
    void TestDoorCandidates()
    {
        _cotaBaseSuelosFeet=F(10.15);_cotaSuperiorSuelosFeet=F(10.212);
        var phase=new Phase{Id=new ElementId(1)};
        var room=new Room{Id=new ElementId(101),CreatedPhaseId=phase.Id,Box=Box(0,0,10,4,3,13)};
        var finish=new Wall{Id=new ElementId(2),Width=F(.03)};
        var host=new Wall{Id=new ElementId(3),Width=F(.2),Location=new LocationCurve{Curve=Line.CreateBound(At(0,-.1,10),At(4,-.1,10))}};
        FamilyInstance MakeDoor(long id)=>new(){Id=new ElementId(id),Host=host,Location=new LocationPoint{Point=At(2,-.1,10)},Box=Box(1.5,-.2,10,2.5,0,12.2)};
        var actual=MakeDoor(4);actual.From=room;
        var otherLevel=MakeDoor(5);otherLevel.Box=Box(1.5,-.2,14,2.5,0,16.2);
        var perpendicular=MakeDoor(6);perpendicular.Host=new Wall{Id=new ElementId(9),Width=F(.2),Location=new LocationCurve{Curve=Line.CreateBound(At(2,-2,10),At(2,2,10))}};
        var unrelated=MakeDoor(7);unrelated.From=new Room{Id=new ElementId(999)};
        var aboveFloorBand=MakeDoor(10);aboveFloorBand.Box=Box(1.5,-.2,11,2.5,0,12.2);
        var fallback=MakeDoor(8); // Both room associations absent: use spatial probes.
        var doc=new Document();doc.Elements.AddRange(new Element[]{phase,room,finish,host,actual,otherLevel,perpendicular,unrelated,fallback,aboveFloorBand});
        var candidates=ObtenerPuertasCandidatasParaBoundary(doc,room,finish,Line.CreateBound(At(0,0,10),At(4,0,10)));
        True(candidates.Count==2,"only actual host door and spatial fallback accepted");
        True(candidates.Any(x=>x.Id.Value==4),"finish wall differs from host: door detected");
        True(candidates.Any(x=>x.Id.Value==8),"missing From/ToRoom: spatial fallback detected");
        True(!candidates.Any(x=>x.Id.Value==5),"other level rejected");
        True(!candidates.Any(x=>x.Id.Value==6),"perpendicular host rejected");
        True(!candidates.Any(x=>x.Id.Value==7),"door assigned to other room rejected");
        True(!candidates.Any(x=>x.Id.Value==10),"door above actual picked floor band rejected");
    }
    void TestSpatialRejection()
    {
        _cotaBaseSuelosFeet=F(10.15);_cotaSuperiorSuelosFeet=F(10.212);
        var room=new Room{Id=new ElementId(101),CreatedPhaseId=new ElementId(1),Box=Box(0,0,10,4,3,13),MembershipEnabled=false};
        var host=new Wall{Id=new ElementId(3),Width=F(.2),Location=new LocationCurve{Curve=Line.CreateBound(At(0,-.1,10),At(4,-.1,10))}};
        var door=new FamilyInstance{Id=new ElementId(4),Host=host,Location=new LocationPoint{Point=At(2,-.1,10)},Box=Box(1.5,-.2,10,2.5,0,12.2)};
        var doc=new Document();doc.Elements.Add(door);
        True(ObtenerPuertasCandidatasParaBoundary(doc,room,null,Line.CreateBound(At(0,0,10),At(4,0,10))).Count==0,"no relation and no interior probes: rejected");
    }
    public static void Main()
    {
        var handler=new Handler();
        var cases=new (string,Action)[]{("exact .13m notch",handler.TestExactDepth),("split boundary",handler.TestSplit),("cyclic seam",handler.TestCyclic),("reverse orientation",handler.TestReverse),("overlapping doors",handler.TestOverlap),("no notches",handler.TestNoNotches),("surface/stack height",handler.TestHeights),("curves and returns",handler.TestCurvesPreserved),("door candidate classification",handler.TestDoorCandidates),("spatial rejection",new Handler().TestSpatialRejection)};
        foreach(var test in cases){test.Item2();Console.WriteLine("PASS "+test.Item1);}Console.WriteLine($"{cases.Length} passed; 0 failed. Geometry doubles only; no Revit integration executed.");
    }
}
