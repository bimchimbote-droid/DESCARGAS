# Regresión de quiebres de puertas

Estas pruebas ejecutan **12 métodos extraídos del handler entregado**. Utilizan dobles de geometría y consultas mínimos; no cargan Autodesk Revit ni sustituyen la prueba del complemento en un modelo.

Requisitos: .NET SDK 8 y Python 3. Desde esta carpeta:

```bash
bash run.sh ../MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs
```

Para un SDK fuera de PATH: `DOTNET_CMD=/ruta/dotnet bash run.sh /ruta/al/handler.cs`.

`extract_methods.py` genera `GeneratedHandler.cs` desde el código indicado y registra su SHA-256. No mantenga una copia manual de las implementaciones. `dotnet run` compila el ejecutable de pruebas independiente; este proyecto no se incorpora a la solución del add-in.

Casos ejecutados (10): profundidad exacta de 0.13 m y área añadida, boundary colineal dividido, división en la costura cíclica, orientación invertida, solapamiento de puertas, ausencia de quiebres, altura de superficie con nivel distinto de cero y apilamiento, conservación de arcos/retornos, clasificación de puertas candidatas y rechazo espacial. La clasificación verifica anfitrión distinto del muro de acabado, rechazo por planta/altura de suelo, anfitrión perpendicular y Room ajeno, y respaldo espacial cuando faltan FromRoom/ToRoom.

Limitaciones: los dobles definen resultados geométricos y de consulta deterministas. No verifican la implementación de IsPointInRoom, FromRoom/ToRoom, sólidos de familias, Floor.Create, transacciones, uniones/corte de geometría ni API/COM de Revit. Requiere prueba posterior en Windows/Revit con el modelo de la captura, una o dos capas y superficie picada.

La entrega omite bin/, obj/ y GeneratedHandler.cs: se regeneran al ejecutar las pruebas.
