#!/usr/bin/env python3
"""Extract real handler methods, not copies of their implementations."""
from pathlib import Path
import hashlib, re, sys
handler = Path(sys.argv[1]).resolve()
source = handler.read_text(encoding='utf-8-sig')
names = ['CalcularOffsetSuperiorCapa', 'EsNumeroFinitoSuelo', 'CrearLineaConVaciosDePuerta',
         'UnirVaciosSolapados', 'UnificarTramosBoundaryColineales', 'DireccionXY',
         'NormalizarXY', 'DistanciaXY', 'MetrosAPies', 'ProductoPuntoXY',
         'ObtenerPuertasCandidatasParaBoundary', 'ObtenerCotaSondaInteriorRoom']
methods=[]
for name in names:
    match=re.search(r'^        private[^\n]*\b'+re.escape(name)+r'\s*\(',source,re.M)
    if match:
        end=re.search(r'^        }\s*$',source[match.start():],re.M)
        if not end: raise SystemExit('No closing brace: '+name)
        method=source[match.start():match.start()+end.end()]
    elif name=='UnificarTramosBoundaryColineales' and len(sys.argv)>2:
        helper=Path(sys.argv[2]).read_text()
        start=helper.index('        private List<CurvaBoundaryMYG>')
        method=helper[start:]
    else: raise SystemExit('Handler method not found: '+name)
    methods.append(method)
output=Path(__file__).parent/'GeneratedHandler.cs'
output.write_text('// Generated from actual handler; do not edit.\n// SHA256: '+hashlib.sha256(handler.read_bytes()).hexdigest()+'\nusing System;\nusing System.Collections.Generic;\nusing System.Linq;\npartial class Handler\n{\n'+ '\n\n'.join(methods)+'\n}\n')
print('Extracted',len(methods),'actual methods from',handler.name)
