# Corrección del quiebre de puertas al crear suelos desde Rooms

## Base de esta entrega

Repositorio de trabajo: bimchimbote-droid/MYG_v27_reestructurado, commit da11b13a3f5ce35b9565bf4d5bd27cb761091102; no tenía cambios locales al comenzar. No se sustituyó por main de MYG_v27 (a41d354e8206e401a881aacfff3f5da7dfe74d00). El handler original coincide byte por byte con el de la última entrega publicada en DESCARGAS: commit 383233121d7a19d2cdcf685012634948de22edce, MYG_v27/entrega-20261108_164927-suelos-rooms-vinculos/MYG_SUELOS_ROOMS_VINCULOS_SOLO_CAMBIOS_20261108_164927.zip.

SHA-256 original del handler: 2ce30615b07c09034e4a492adba5f5ae46c80c0c7aa03b39e5f623ec76a52705
SHA-256 nuevo del handler: 3647358d29b6e6fd8cc6fecb03627d2f925107c89791dfe855d30a43ece09309

La edición inconclusa de otra sesión mencionada en el contexto no estaba en esta máquina. La implementación parte del archivo disponible y de la entrega anterior verificada, conservando la selección de superficies vinculadas y el cálculo existente de cotas.

## A. Comportamiento

- Detecta puertas del documento actual aunque su anfitrión real sea distinto del muro de acabado que delimita el Room. Verifica alineación, fase/FromRoom/ToRoom cuando están disponibles, distancia, lado interior y altura. Recolecta las puertas una vez por ejecución.
- El valor manual positivo, por ejemplo 0.13 m, sigue siendo la profundidad desde el límite de acabado hacia la puerta; 0 conserva la profundidad automática existente.
- Unifica tramos rectos colineales consecutivos, incluida la costura primero/último, para no recortar el ancho de una puerta al primer fragmento. Conserva arcos y esquinas.
- Las sondas de pertenencia se sitúan dentro del volumen vertical del Room. La puerta debe alcanzar la banda de altura real de las capas, con 5 cm de tolerancia para umbrales.
- Un quiebre calculado no se sustituye por un suelo sin puertas si el boceto falla. Las reparaciones son completas: no se descartan huecos o contornos fallidos. Si no puede crearse, se informa el Room omitido y se deja diagnóstico.
- Si no se detectan puertas compatibles, se informa expresamente que no se añadieron quiebres.
- Busca muros del modelo actual que intersecten cada suelo creado usando su geometría y altura reales. Intenta unirlos y conservar el suelo como elemento cortante. Cada unión está aislada; sus fallos u orden de corte no confirmado se registran por ID en el diagnóstico cuya ruta aparece al finalizar.
- Con quiebres calculados y descuento de intersecciones activado, los muros se resuelven por unión, no por resta en planta que borraría el quiebre. Los demás descuentos y solapes entre Rooms se conservan.
- Mantiene la base picada y el apilamiento existentes; la capa superior parte del contorno realmente utilizado para la inferior. Se conserva el comportamiento previo de informar creación parcial si solo una capa puede crearse.

## B. Archivos e intervención

| Ruta | Acción | Uso |
| --- | --- | --- |
| MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs | REEMPLAZAR | Archivo completo actualizado. Ya está incluido una vez en el csproj. |
| tests/Regression.csproj | CREAR, opcional para validar | Proyecto independiente, NO agregar al add-in. |
| tests/Program.cs | CREAR, opcional para validar | Diez escenarios de regresión. |
| tests/GeometryStubs.cs | CREAR, opcional para validar | Dobles de geometría/consulta; no implementan Revit. |
| tests/extract_methods.py | CREAR, opcional para validar | Extrae 12 métodos reales del handler para las pruebas. |
| tests/run.sh | CREAR, opcional para validar | Ejecuta extracción y pruebas. |
| tests/README.md | CREAR, opcional para validar | Instrucciones y límites de las pruebas. |
| LEEME_ENTREGA.md | CREAR, documentación de entrega | Este documento. |
| MANIFIESTO.json | CREAR, documentación de entrega | Relación y hashes de los archivos. |

No hay eliminaciones ni parches de configuración. El formulario, comando, csproj, paquetes, recursos y demás fuentes quedan SIN CAMBIOS y fuera del ZIP. No se entrega DLL.

## C/D. Instalación

1. Respalde su versión actual del handler y su instalación funcional. Compare el archivo con el original indicado arriba. Reemplazarlo completo puede sobrescribir cambios locales o posteriores: si difiere, integre el cambio con comparación de archivos, conservando sus avances.
2. Extraiga el ZIP en una carpeta temporal. Copie únicamente MYG/ sobre la raíz de su solución, respetando la ruta exacta del handler. No copie tests dentro del proyecto MYG ni agregue sus archivos al csproj.
3. Revise el diff en Visual Studio. Compile en Windows con las referencias reales de su versión de Revit y las dependencias/COM de Office que ya exige el proyecto. Use una salida controlada; el proyecto conserva rutas personales de Debug.
4. Cierre Revit y pruebe la nueva DLL compilada con una copia del modelo antes de actualizar su instalación habitual. Conserve el manifiesto .addin y los iconos existentes.

Para repetir las pruebas independientes en Linux/WSL/Git Bash, con SDK .NET 8 y Python 3, desde la raíz extraída:

```bash
bash tests/run.sh
```

Estas pruebas se compilan aparte; no son pruebas ejecutadas dentro de Revit. No alteran versiones de paquetes del add-in.

## E. Configuración

No se añadieron referencias, paquetes, elementos de proyecto ni ajustes de ventana. Se mantienen .NET Framework 4.8, referencias a Revit 2027 y COM del proyecto original. Su compatibilidad con la instalación real debe revisarse en Windows; esta entrega no migra el framework ni corrige dependencias ajenas al quiebre.

## F. Validación ejecutada

- git diff --check: sin errores.
- Referencias de archivos del proyecto: existen los 179 Compile, 9 EmbeddedResource y 3 None; el handler figura una sola vez.
- Roslyn, C# 7.3: los 179 archivos C# activos completos analizados, 0 errores de sintaxis.
- Ejecutable de regresión .NET 8: 10 escenarios aprobados, 0 fallidos, ejecutando 12 métodos extraídos del archivo final. Cubre profundidad/área 0.13 m, tramos colineales/cíclicos, orientación inversa, puertas solapadas, ausencia de quiebres, altura y apilamiento, conservación de curvas y selección/rechazo de candidatos (incluido anfitrión distinto del acabado).
- Compilación completa intentada con MSBuild .NET 8 en Linux: FALLÓ en MSB4803, ResolveComReference no soportado. También faltan RevitAPI/RevitAPIUI y referencias Windows. El conflicto EPPlus preexistente sigue presente. No se generó una DLL validada.
- Las pruebas usan dobles deterministas: NO comprueban semántica de la API real, sólidos de familias, Floor.Create, transacciones, JoinGeometry ni funcionamiento del add-in.

### Pruebas pendientes en Windows/Revit

1. Reproducir el Room de la captura: Incluir Puertas, profundidad 0.13, dos capas y superficie picada. Editar los bocetos: ambas capas deben tener la prolongación de 13 cm y todo el ancho detectado de la puerta.
2. Comprobar puerta alojada en muro estructural con muro de acabado delimitando el Room; repetir con el borde dividido en tramos rectos, incluido primero/último.
3. Medir las cotas: inferior inferior = base picada; superior inferior = base + espesor inferior; superior superior = base + espesor inferior + espesor superior. Repetir con una sola capa y modo nivel/desfase.
4. Verificar unión/corte con muros anfitriones y otros muros intersectantes; un muro solo cercano en planta o de otra altura no debe unirse. Revisar diagnóstico si Revit rechaza una unión.
5. Repetir con descuento de intersecciones activado/desactivado y dos Rooms adyacentes, revisando solapes y huecos.
6. Probar 0 (profundidad automática), Incluir Puertas desactivado, Room sin puertas, puertas de otra planta/fase y una familia sin FromRoom/ToRoom.
7. Forzar un perfil con quiebre inválido: debe informar el fallo sin crear un suelo plano como sustituto. Verificar que no se pierdan contornos internos durante reparación.
8. Verificar que siguen funcionando picar superficie local/vinculada, parámetros de acabado del Room y la selección final.

## G. GitHub

La publicación del ZIP en DESCARGAS no instala archivos en su PC ni actualiza MYG_v27 o MYG_v27_reestructurado. No se hizo commit ni push de esos repositorios de código. Tras copiar y probar en Visual Studio, revise Git Changes, seleccione solamente los cambios que quiera conservar, haga Commit y luego Push a su repositorio cuando lo decida.

## H. Límites

Falta validación funcional en Revit con el modelo real. La detección de puertas mantiene soporte de tramos rectos y anfitriones Wall rectos; los arcos se conservan sin inventar quiebres nuevos. Los muros vinculados no se unen: el alcance confirmado son puertas y muros del documento actual. Una unión puede ser rechazada por Revit o quedar sin el orden de corte solicitado; el informe lo registra. La geometría real de la familia sigue determinando el ancho y puede necesitar revisión si incluye sólidos auxiliares. No se garantiza la compatibilidad del proyecto original con Revit 2027 sin compilarlo y probarlo en Windows.
