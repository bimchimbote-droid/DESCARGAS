using System;
using System.Collections.Generic;
using System.Linq;
partial class Harness
{
    const double N=1e-8, Min=.001;
    static void Near(double a,double b,string label,double eps=1e-7)
    {if(double.IsNaN(a)||Math.Abs(a-b)>eps)throw new Exception(label+": expected "+b+", actual "+a);}
    static void True(bool condition,string label){if(!condition)throw new Exception(label);}
    static void Throws<T>(Action action,string label) where T:Exception
    {try{action();}catch(T){return;}throw new Exception(label+": did not throw "+typeof(T).Name);}
    static double Area(FragmentoTarrajeoMYG f)=>(f.Fin-f.Inicio)*(f.ZSuperior-f.ZBase);
    static double Overlap(FragmentoTarrajeoMYG a,FragmentoTarrajeoMYG b)=>Math.Max(0,Math.Min(a.Fin,b.Fin)-Math.Max(a.Inicio,b.Inicio))*Math.Max(0,Math.Min(a.ZSuperior,b.ZSuperior)-Math.Max(a.ZBase,b.ZBase));
    static List<FragmentoTarrajeoMYG> P(double l=5,double b=0,double t=3,double i=0,double f=5,double rb=0,double rt=1.5)=>PlanificarRestosTarrajeo(l,b,t,i,f,rb,rt,N,Min);
    static void VerifyPartition(List<FragmentoTarrajeoMYG> fragments,double l,double b,double t,double i,double f,double rb,double rt)
    {
        double ci=Math.Max(0,i),cf=Math.Min(l,f),cb=Math.Max(b,rb),ct=Math.Min(t,rt);
        var removed=new FragmentoTarrajeoMYG{Inicio=ci,Fin=cf,ZBase=cb,ZSuperior=ct};
        Near(fragments.Sum(Area)+Area(removed),l*(t-b),"original area is partitioned exactly");
        foreach(var x in fragments)
        {
            True(x.Inicio>=-N&&x.Fin<=l+N&&x.ZBase>=b-N&&x.ZSuperior<=t+N,"fragment within old envelope");
            True(x.Fin-x.Inicio>=Min&&x.ZSuperior-x.ZBase>=Min,"every remnant is modelable");
            Near(Overlap(x,removed),0,"no retained plaster in replacement rectangle");
        }
        for(int a=0;a<fragments.Count;a++)for(int j=a+1;j<fragments.Count;j++)Near(Overlap(fragments[a],fragments[j]),0,"retained fragments do not overlap");
    }
    static void FullSpanUpper()
    {var f=P();True(f.Count==1,"only upper remnant");Near(f[0].ZBase,1.5,"upper starts at requested input height");Near(f[0].ZSuperior,3,"original top preserved");Near(f[0].ZSuperior-f[0].ZBase,1.5,"3m original minus 1.5m input leaves 1.5m upper plaster");VerifyPartition(f,5,0,3,0,5,0,1.5);}
    static void PartialSpanFourRemainders()
    {var f=P(i:1,f:4,rb:.5,rt:2);True(f.Count==4,"left right lower and upper retained");VerifyPartition(f,5,0,3,1,4,.5,2);Near(f.Where(x=>x.Inicio==0||x.Fin==5).Sum(Area),6,"unselected longitudinal portions fully preserved");}
    static void RaisedBase()
    {var f=P(rb:1,rt:2);True(f.Count==2,"lower and upper retained");VerifyPartition(f,5,0,3,0,5,1,2);True(f.Any(x=>x.ZBase==0&&x.ZSuperior==1),"portion below picked base retained");}
    static void TallerThanOld()
    {var f=P(rb:-1,rt:8);True(f.Count==0,"entire original replaced when band covers it");VerifyPartition(f,5,0,3,0,5,-1,8);}
    static void ClippedLongitudinalSpan()
    {var f=P(i:-2,f:8);True(f.Count==1,"outside longitudinal bounds clipped");VerifyPartition(f,5,0,3,-2,8,0,1.5);}
    static void NonzeroElevation()
    {var f=P(b:15.8,t:18.6,rb:15.95,rt:17.45);True(f.Count==2,"nonzero base keeps lower and upper");VerifyPartition(f,5,15.8,18.6,0,5,15.95,17.45);Near(f.Max(x=>x.ZSuperior),18.6,"top at actual internal elevation unchanged");}
    static void TooThinUpperFails()
    {Throws<InvalidOperationException>(()=>P(rt:3-.0005),"thin upper must fail rather than disappear");}
    static void TooThinSideFails()
    {Throws<InvalidOperationException>(()=>P(i:.0005),"thin side must fail rather than disappear");}
    static void NumericCoincidence()
    {var f=P(i:N/2,f:5-N/2,rt:1.5);True(f.Count==1,"subnumeric side noise considered coincident");Near(f[0].Inicio,0,"left coincidence");Near(f[0].Fin,5,"right coincidence");}
    static void NoPositiveIntersection()
    {Throws<InvalidOperationException>(()=>P(i:6,f:7),"outside longitudinal band");Throws<InvalidOperationException>(()=>P(rb:3,rt:4),"top contact only");Throws<InvalidOperationException>(()=>P(i:5,f:7),"end contact only");}
    static void ReversedInvalid()
    {Throws<ArgumentException>(()=>P(i:4,f:1),"reversed longitudinal bounds rejected");Throws<ArgumentException>(()=>P(rb:2,rt:1),"reversed vertical band rejected");Throws<ArgumentException>(()=>P(b:3,t:2),"reversed old height rejected");Throws<ArgumentException>(()=>P(l:0),"zero length rejected");}
    static void NonFiniteInvalid()
    {Throws<ArgumentException>(()=>P(i:double.NaN),"NaN rejected");Throws<ArgumentException>(()=>P(rt:double.PositiveInfinity),"infinity rejected");Throws<ArgumentException>(()=>P(b:-double.MaxValue,t:double.MaxValue),"overflowing height rejected");Throws<ArgumentException>(()=>PlanificarRestosTarrajeo(5,0,3,0,5,0,1.5,0,Min),"zero numeric tolerance rejected");Throws<ArgumentException>(()=>PlanificarRestosTarrajeo(5,0,3,0,5,0,1.5,N,N),"ambiguous model tolerance rejected");}
    static void GridAreaConservation()
    {
        int cases=0;
        foreach(double i in new[]{0d,.25,2})foreach(double f in new[]{2.5,4,5})foreach(double rb in new[]{-.5,0,.2})foreach(double rt in new[]{1d,2.6,3.5})
        {var fragments=P(i:i,f:f,rb:rb,rt:rt);VerifyPartition(fragments,5,0,3,i,f,rb,rt);cases++;}
        True(cases==81,"all grid partitions executed");
    }
    static void Main()
    {
        var cases=new (string,Action)[]{("preserve full upper plaster",FullSpanUpper),("partial span retains four remainders",PartialSpanFourRemainders),("raised input base preserves lower plaster",RaisedBase),("band higher than original",TallerThanOld),("clip span to original",ClippedLongitudinalSpan),("nonzero internal elevations",NonzeroElevation),("thin upper fails safely",TooThinUpperFails),("thin side fails safely",TooThinSideFails),("numeric coincidences only",NumericCoincidence),("no positive intersection rejected",NoPositiveIntersection),("reversed dimensions rejected",ReversedInvalid),("nonfinite/tolerance rejected",NonFiniteInvalid),("81 area partitions conserve material",GridAreaConservation)};
        foreach(var c in cases){c.Item2();Console.WriteLine("PASS "+c.Item1);}Console.WriteLine($"{cases.Length} passed; 0 failed. Pure alzado planner only; no Revit API or model integration executed.");
    }
}
