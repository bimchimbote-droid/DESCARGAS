#!/usr/bin/env python3
"""Extract the real planner and fragment DTO; no manual implementation copies."""
from pathlib import Path
import hashlib, re, sys
source_path = Path(sys.argv[1]).resolve()
source = source_path.read_text(encoding='utf-8-sig')
parts=[]
for pattern in [r'^\s*private static List<FragmentoTarrajeoMYG> PlanificarRestosTarrajeo\s*\(',r'^\s*private class FragmentoTarrajeoMYG\b']:
    match=re.search(pattern,source,re.M)
    if not match: raise SystemExit('Production declaration missing: '+pattern)
    opening=source.index('{',match.start())
    # The extracted production method/class contains no brace characters in
    # string literals. Track block depth to include lambdas and nested blocks.
    level=1; end=opening+1
    while level and end<len(source):
        if source[end]=='{':level+=1
        elif source[end]=='}':level-=1
        end+=1
    if level:raise SystemExit('Unterminated production declaration')
    parts.append(source[match.start():end])
output=Path(__file__).parent/'GeneratedPlanner.cs'
output.write_text('// Generated from production; do not edit.\n// SHA256: '+hashlib.sha256(source_path.read_bytes()).hexdigest()+'\nusing System;\nusing System.Collections.Generic;\npartial class Harness\n{\n'+'\n\n'.join(parts)+'\n}\n')
print('Extracted actual planner and fragment DTO from',source_path.name)
