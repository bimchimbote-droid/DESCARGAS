# Regresión del reparto de tarrajeo por altura

Este proyecto independiente ejecuta el planificador `PlanificarRestosTarrajeo` y su DTO extraídos del handler entregado. No mantiene una copia manual de la implementación.

El planificador resta la franja de reemplazo del alzado rectangular del tarrajeo y conserva los restos: izquierda y derecha a altura completa, más las franjas inferior y superior en el intervalo central. No calcula sólidos ni modifica un modelo Revit.

Requisitos: .NET SDK 8 y Python 3. Si esta carpeta se instala como `tests/ReemplazoTarrajeo`, desde la raíz extraída:

```bash
bash tests/ReemplazoTarrajeo/run.sh
```

También se puede indicar la ruta exacta del handler:

```bash
bash run.sh /ruta/MUROSDEROOM_EJECUTAR_HANDLER.cs
```

El script genera `GeneratedPlanner.cs` con el SHA-256 del archivo fuente leído. No agregue el proyecto de pruebas, sus fuentes ni sus archivos generados al proyecto MYG.

Casos ejecutados: **13 escenarios aprobados, 0 fallidos**, incluidos 81 repartos adicionales de conservación de área. Se verifica la conservación del tarrajeo superior; restos laterales ante reemplazo parcial; parte inferior cuando la base de reemplazo está elevada; reemplazo que supera la altura original; recorte a los límites longitudinales; cotas internas distintas de cero; rechazo de restos físicamente demasiado finos; coincidencias dentro de la tolerancia numérica; rechazo de contactos sin área, dimensiones invertidas, NaN/infinito y tolerancias inválidas; límites, ausencia de solapes y conservación de área en todos los repartos.

Estas pruebas sólo verifican matemáticas y decisiones del planificador. **No validan** identificación de acabados, transacciones, copias/eliminaciones de muros, parámetros, perfiles, huecos, referencias, aceptación de Wall.Create ni el resultado visual real de Autodesk Revit. Se requiere compilación y prueba posterior en Windows/Revit con una copia del modelo.

Para la entrega incluir sólo `Regression.csproj`, `Program.cs`, `extract_planner.py`, `run.sh` y este `README.md`. Excluir `GeneratedPlanner.cs`, `bin/` y `obj/`.
