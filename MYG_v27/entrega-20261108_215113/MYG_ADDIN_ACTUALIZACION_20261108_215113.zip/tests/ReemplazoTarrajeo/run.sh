#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
handler_path=${1:-../../MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs}
python3 extract_planner.py "$handler_path"
"${DOTNET_CMD:-dotnet}" run --project Regression.csproj --configuration Release
