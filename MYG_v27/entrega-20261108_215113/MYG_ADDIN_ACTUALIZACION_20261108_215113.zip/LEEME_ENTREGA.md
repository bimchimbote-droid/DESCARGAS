# Reemplazo parcial de tarrajeo desde Rooms

## A. Resultado

En Crear Muro desde Rooms se añade el checkbox **Reemplazar tarrajeo hasta la altura indicada**, desmarcado por defecto, y el selector **Tarrajeo existente a sustituir**. Se elige explícitamente el tipo de acabado anterior; no se deduce por nombre ni se sustituye automáticamente el muro del soporte.

Ejemplo: tarrajeo independiente de 3.00 m; acabado nuevo cerámico con altura 1.50 m y base 0.00. El nuevo acabado ocupa de 0.00 a 1.50 m; el tarrajeo anterior permanece de 1.50 a 3.00 m. Si se pica una base elevada, la franja comienza en esa cota interna y termina en base + altura; se conserva también el material anterior por debajo cuando existe.

Es un recorte real de los elementos de acabado, no solo una unión visual: el original conserva el paño superior cuando queda; si la sustitución ocupa solo parte del recorrido, se conservan también los laterales mediante fragmentos del mismo tipo. Los restos se comprueban por tipo, eje, restricciones y rango Z real. Se conserva la cara posterior de apoyo del tarrajeo anterior; si cambia el espesor del acabado nuevo, la diferencia se refleja hacia el Room, sin añadir ambos espesores uno sobre otro.

Con el checkbox desactivado continúa el flujo anterior de crear muros hacia el interior. No se modificaron las herramientas de suelos, sus quiebres ni su unión con muros.

## Base inspeccionada

Checkout: bimchimbote-droid/MYG_v27_reestructurado, HEAD da11b13a3f5ce35b9565bf4d5bd27cb761091102. Se conservaron los cambios locales previos del handler de suelos: se verificó que sigue idéntico a la entrega de DESCARGAS en commit 625fa1943c214ed773ecb0a77a517f6c98e6a841, ZIP MYG_ADDIN_ACTUALIZACION_20261108_174539.zip. Ese archivo no se incluye porque no se modificó en este cambio. No se sustituyó el checkout por main de MYG_v27.

Los dos archivos de muros se respaldaron al comenzar; sus hashes original/nuevo están en MANIFIESTO.json.

## B. Archivos afectados

| Ruta exacta | Acción | Descripción |
| --- | --- | --- |
| MYG/Funcionalidades/Arquitectura/Habitaciones/CrearMuroDesdeRoomForm.cs | REEMPLAZAR | Checkbox, selector y validación; ventana con desplazamiento para acceder a controles e informe. |
| MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs | REEMPLAZAR | Selección acotada, planificación de restos, creación y recorte transaccional. |
| CAMBIOS_TARRAJEO.patch | CREAR; alternativa de instalación | Parche puntual de esos mismos dos archivos. No aplicarlo además de reemplazarlos. |
| tests/ReemplazoTarrajeo/Regression.csproj | CREAR, prueba opcional | Proyecto .NET 8 independiente del add-in. |
| tests/ReemplazoTarrajeo/Program.cs | CREAR, prueba opcional | 13 escenarios del planificador. |
| tests/ReemplazoTarrajeo/extract_planner.py | CREAR, prueba opcional | Extrae el método real y DTO desde el handler final. |
| tests/ReemplazoTarrajeo/run.sh | CREAR, prueba opcional | Ejecuta extracción y pruebas. |
| tests/ReemplazoTarrajeo/README.md | CREAR, documentación | Alcance y límites de las pruebas. |
| LEEME_ENTREGA.md | CREAR, documentación | Este documento. |
| MANIFIESTO.json | CREAR, documentación | Relación de archivos y hashes. |

SIN CAMBIOS y fuera del ZIP: comando, csproj, paquetes, recursos, handler de suelos y demás fuentes. No hay eliminaciones de archivos ni DLL entregada.

## C/D. Instalación y uso

1. Respalde sus dos archivos y la DLL que usa actualmente. Compare antes de reemplazar: los archivos completos pueden sobrescribir modificaciones locales o posteriores.
2. Elija UN procedimiento: copie los dos archivos completos sobre las mismas rutas de su solución, O use `git apply --check CAMBIOS_TARRAJEO.patch` y luego `git apply CAMBIOS_TARRAJEO.patch` desde la raíz. Si el parche no aplica, integre con comparación de archivos conservando sus avances. No fuerce el parche ni combine ambos procedimientos.
3. No agregue el proyecto de pruebas al add-in. Las dos fuentes ya están incluidas en MYG.csproj. Compile en Windows con las herramientas y dependencias reales de su proyecto; cierre Revit al sustituir la DLL y pruebe con una copia del modelo antes de su uso habitual.
4. Abra Crear Muro desde Rooms. Seleccione Rooms, el tipo de acabado NUEVO en Tipo de muro, altura y base/nivel. Active el checkbox y seleccione exactamente el tipo del tarrajeo EXISTENTE. Deben ser dos tipos básicos distintos. Ejecute y revise los paños sustituidos y los tramos sin reemplazar.
5. En un tramo no compatible, se conservan el acabado antiguo y el resto del modelo; no se añade una segunda capa como respaldo. El informe detallado aparece al finalizar y puede recorrerse en la ventana.

## E. Configuración y alcance

Sin paquetes, referencias ni cambios de proyecto adicionales. La selección explícita se limita a muros básicos y la ejecución rechaza muros marcados como estructurales. El acabado anterior debe ser un muro de tarrajeo separado; no se edita una capa de un muro compuesto estructural ni se cambia su tipo.

Se buscan acabados alineados y coincidentes con el tramo, también cuando el tarrajeo no delimita habitaciones y el boundary está en la cara del soporte. Se exige la misma fase de creación y opción de diseño del Room. La vista activa debe permitir crear el acabado en esa misma fase/opción; no se altera automáticamente la configuración de fases del proyecto.

## F. Validación ejecutada

- Planificador REAL extraído del handler final: 13 escenarios aprobados, 0 fallidos; incluye 81 particiones que comprueban conservación de área, ausencia de solapes y la sustitución de 1.50 m en un tarrajeo de 3.00 m.
- Casos adicionales: reemplazo parcial en longitud con cuatro restos, base elevada conservando la franja inferior, altura nueva mayor que la original, cotas internas no nulas, valores inválidos y restos demasiado pequeños rechazados.
- Roslyn con C# 7.3: los 179 archivos activos completos analizados, 0 errores de sintaxis.
- Rutas de proyecto: 179 Compile, 9 EmbeddedResource y 3 None existentes; las dos fuentes figuran una vez. git diff --check sin errores.
- Compilación completa intentada en Linux con MSBuild .NET 8: FALLÓ en MSB4803 porque ResolveComReference requiere MSBuild de .NET Framework. Faltan también las referencias reales de Revit/Windows; el conflicto EPPlus preexistente se mantiene. No se produjo una DLL validada.
- Las pruebas de planificación son matemáticas: NO prueban la API de Revit, la interfaz WinForms, CopyElement, doc.Delete, transacciones, restricciones, vanos o el modelo real. No se ha realizado la validación funcional en Revit.

Para repetir las pruebas con .NET SDK 8 y Python 3, desde la raíz extraída:

```bash
bash tests/ReemplazoTarrajeo/run.sh
```

### Prueba pendiente en Windows/Revit

- Checkbox desactivado: comprobar creación anterior sin recortar muros existentes.
- Tarrajeo de 3.00 m y acabado nuevo de 1.50 m: medir ambos elementos, confirmar tipo anterior de 1.50 a 3.00 y nuevo tipo debajo, sin duplicidad.
- Base picada elevada: confirmar que la franja se mide desde ella, conservando material anterior por debajo y por encima.
- Reemplazo solo en parte de un muro: conservar laterales y paño superior; probar varios Rooms y tramos consecutivos del mismo acabado.
- Diferentes espesores: verificar la cara de apoyo y el espacio del Room en sección/planta.
- Verificar que el muro estructural, los otros tipos de acabado y los acabados de otras fases/opciones no cambiaron.
- Probar vanos alojados en el soporte y varios paños de acabado rectangulares; revisar informe si no puede conservarse un vano.
- Probar un tramo no compatible y confirmar que creación y recorte se revierten juntos, sin superponer otro muro nuevo.

## G. GitHub

Publicar el ZIP en bimchimbote-droid/DESCARGAS no instala archivos en su PC ni actualiza MYG_v27 o MYG_v27_reestructurado. No se hizo commit ni push del código. Después de instalar y probar en Visual Studio, revise Git Changes, seleccione los cambios, haga Commit y luego Push cuando decida conservarlos.

## H. Límites concretos

El modo de reemplazo admite tarrajeos independientes, rectos, verticales y rectangulares. No recorta muros curvos, perfil editado, grupos, fijados, miembros de apilados, acabados con familias alojadas o basadas en cara ni geometrías especiales que no puedan conservarse. El informe identifica esos tramos; quedan intactos.

Cuando se necesita copiar más de un resto de un tarrajeo con uniones geométricas existentes, se omite el tramo para no perder cortes que afecten a las copias. Si queda solo un resto, se reutiliza el original y se verifican sus alturas reales. No se borran dependencias para forzar la sustitución: si al desaparecer todo el paño se afectarían anotaciones u otros elementos dependientes, se revierte el tramo.

Los originales conservados pueden pasar a restricciones no conectadas manteniendo sus cotas; sus copias conservan el tipo y parámetros, actualizando GEN_ID Elemento al ID nuevo cuando ese parámetro admite escritura. Los vanos en perfiles editados anteriores requieren un flujo adicional de edición de bocetos y no se reconstruyen a ciegas. Restos por debajo de la tolerancia modelable de Revit provocan rechazo, nunca su desaparición silenciosa. La vista previa y el resultado físico deben comprobarse en su modelo antes de usar esta opción sobre el archivo de trabajo.
