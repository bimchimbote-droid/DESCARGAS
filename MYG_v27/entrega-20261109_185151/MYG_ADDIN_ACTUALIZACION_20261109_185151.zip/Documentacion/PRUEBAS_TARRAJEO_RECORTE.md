# Recorte y selección continua de Tarrajeo / Encofrado

## Revisión de huellas estrechas en geometría unida

El aviso nuevo de la captura identifica una huella proyectada menor que la
tolerancia de líneas, en la etapa de proyección de un elemento de armazón
estructural vinculado. No demuestra por sí solo que la causa sea una unión.
La versión previa solo reconocía cobertura por una huella rectangular sin huecos.

Ahora se comprueba la cobertura completa mediante el área recortada por el
triángulo original, incluyendo contornos cóncavos y restando sus huecos. Hay una
prueba rápida para perfiles convexos sin huecos. No basta con que los tres
vértices estén en material si el triángulo cruza una mordida o encierra un hueco.

Si la huella original no tiene área dentro del paño, se descarta ANTES de
ampliarla: una separación real no debe inventar una interferencia. Si está
cubierta por otra huella, no se añade un cortante duplicado. Si realmente corta
y no está cubierta, se reconstruye con una caja orientada LOCAL al triángulo,
según su lado mayor, con aristas mínimas de `1.1 * PTOL` (aprox. 1.006 mm).
No se usa la caja de la viga completa ni se modifica o desune el modelo.

Esta regularización es conservadora: conserva todo el obstáculo, pero puede
descontar algo más de revestimiento cerca de esa huella. El crecimiento respecto
de su caja orientada es como máximo aprox. 0.503 mm por lado y eje local; la
distancia adicional al triángulo puede ser del orden de 1 mm. No es una promesa
de exactitud dimensional submilimétrica. El espesor de 15 mm y la tolerancia de
líneas no se modifican. Si Revit aún rechaza la reconstrucción posterior, se
mantiene el aviso y la selección continua.

## Revisión para separaciones de milímetros y elementos unidos

La entrega anterior todavía podía avisar antes de obtener las huellas. Ahora se
comprueba primero si la caja del sólido está realmente separada del perfil en U/V.
Después se recorta entre los dos planos del espesor exterior con
`CutWithHalfSpace`, sin intersectarlo antes con todo el perímetro de la cara.
Así se evita esa fuente de aristas coincidentes y láminas diminutas. Si el
recorte con planos falla, se intenta la intersección exacta con la sonda; si
también falla, se avisa y no se presupone que el sólido está separado.

Las comprobaciones de cruces comparan distancias con distancias, y la igualdad
de puntos usa la distancia radial. Esto permite distinguir separaciones de 1, 2
y 3 mm sin cambiar la tolerancia de líneas ni mover, desunir o extender elementos.
Las caras planas y los triángulos cuya proyección está completamente fuera de
la caja del perfil se excluyen antes de validar sus aristas.

Si aún no se resuelve un recorte, el aviso muestra la etapa, el espesor y el
origen de extracción del sólido: ID del elemento, categoría y vínculo si existe.
La extracción puede incluir geometría de dependientes; el ID mostrado corresponde
al origen de esa extracción, no necesariamente al subelemento exacto. No se
incluyen rutas ni nombres de modelos. El aviso permite seguir seleccionando.

La captura por sí sola no determina si el fallo es una unión o un suelo separado.
No se ha reproducido ese modelo dentro de Revit.
Una separación normal de 2 mm no excluye al sólido si el revestimiento tiene
15 mm y alcanza ese sólido: en ese caso sí debe descontarse su huella. Solo se
descartan candidatos que quedan fuera del volumen o del área real del paño.

El descuento se calcula a partir de los sólidos visibles que ocupan el espesor
exterior del revestimiento. Su huella se resta del perfil completo: no se intenta
crear un vaciado parcial a través del espesor de un muro de Revit. Un resultado
rectangular usa la creación normal de muro; los demás perfiles conservan sus
mordidas y huecos.

El cortante temporal sobrepasa ambos extremos incluso en los reintentos del
boolean. El perfil se recupera de un único plano extremo, incluyendo todas sus
islas. Se comparan los contornos proyectados para no descontar dos veces la misma
huella ni confundir figuras distintas con la misma área y caja.

Si el boolean falla y tanto la cara como todas las huellas son rectángulos sin
huecos, se usa una resta en 2D y se crean los restos rectangulares por separado.
No se repone el paño original encima de una interferencia. Las bandas menores que
la tolerancia de líneas se omiten. Las proyecciones estrechas se comprueban y
regularizan según lo descrito arriba; los recortes no resueltos siguen avisando
y permiten seleccionar otra cara.

Los errores de una cara no finalizan la sesión. Tras cerrar el aviso se puede
seleccionar otra cara para muro o suelo. Esc vuelve al formulario. La falta de
tipo o de handler también vuelve al formulario para corregir la configuración.

## Pruebas aisladas

Los scripts de `Pruebas/` extraen los métodos actuales de los handlers y los
ejecutan con un SDK .NET local, sin descargar paquetes. Utilizan sustitutos mínimos
de la API de Revit; no cargan Revit ni validan su motor geométrico, las uniones,
las transacciones reales o el comportamiento de `ExternalEvent` en la aplicación.
Consultar los argumentos de cada script con `--help`.

`probar_geometria_tarrajeo.py` incluye los casos de 1, 2 y 3 mm y perfiles girados.
También verifica cobertura en perfiles irregulares y con huecos, el contacto del
triángulo original y la contención y crecimiento de su envolvente local.
`probar_espesor_tarrajeo.py` comprueba los planos de corte, exclusiones de cajas,
preservación de separaciones y la alternativa ante fallos con sustitutos de API.
No comprueba el boolean real de Revit ni reproduce las uniones del modelo.

## Comprobación funcional pendiente en Revit sobre Windows

Compilar con el entorno Windows y las referencias reales del proyecto. Probar
sobre una copia de un modelo, con un tipo de revestimiento de espesor conocido:

| Caso | Resultado esperado |
| --- | --- |
| Cara rectangular de viga sin interferencias | Muro rectangular con la altura y longitud de la cara. |
| Sólido que invade solo una parte del espesor exterior | Su huella se descuenta en todo el espesor; no queda una lámina residual ni aparece el perfil original sin cortar. |
| Interferencia rectangular en un borde | Paño rectangular reducido o perfil con mordida, según la huella. |
| Interferencia interior o que divide toda la altura | Hueco o paños separados, sin rellenar la interferencia. |
| Varias interferencias rectangulares que se solapan | Se descuenta su unión; no se duplican los descuentos. |
| Boolean no resuelto con cara y huellas rectangulares | Se crean los restos rectangulares libres; pueden ser varios muros. |
| Sólido tangente o únicamente detrás de la cara anfitriona | No elimina el revestimiento exterior. |
| Suelo separado 1, 2 y 3 mm fuera del perfil en altura o en dirección U | Se mantiene la separación; no se descuenta ni cierra ese espacio. |
| Suelo que entra realmente en el espesor exterior | Solo su huella efectiva recorta el perfil completo. |
| Viga unida a muro/suelo, con el mismo ensayo sin unión en una copia | El comando no altera esas uniones para calcular el recorte. Comparar los perfiles y, si falla, el ID y la etapa del aviso. |
| Huella estrecha de la viga vinculada indicada en la captura | No se omite todo el paño por esa sola huella; se reconoce la cobertura o se usa su envolvente local. Medir el pequeño recorte adicional permitido. |
| Triángulo estrecho completamente dentro de un hueco o separado del paño | No se regulariza ni crea una interferencia nueva a través de la separación. |
| Vínculo visible, movido y girado | Se aplica su transformación una sola vez; la cara anfitriona no se autorrecorta. |
| Sólido oculto o vínculo excluido por la configuración | No recorta el revestimiento. |
| Cara totalmente ocupada o recorte no resoluble | No se crea el paño; un aviso, sin el segundo aviso genérico repetido, y luego otra selección. |
| Cara inválida o fallo de creación de muro/suelo | Cerrar el aviso permite seleccionar después una cara válida sin volver a pulsar el botón del comando. |
| Esc en la siguiente selección | Termina la sesión y restaura el formulario; conserva lo ya creado. |

Las capturas del problema deben repetirse con el modelo original para confirmar
el resultado visual y dimensional. Las pruebas aisladas y el análisis de sintaxis
no sustituyen esta comprobación.
