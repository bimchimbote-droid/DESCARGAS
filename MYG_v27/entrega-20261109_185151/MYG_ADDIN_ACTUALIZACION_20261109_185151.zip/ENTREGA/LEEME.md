# Tarrajeo / Encofrado: huellas estrechas de geometría irregular

## Base conservada

Repositorio de trabajo real: bimchimbote-droid/MYG_v27_reestructurado. Commit fuente base: 56682a0299f9cb62dacecce6ef269a13c864c4b3, rama local work. Se conservan sus cambios locales de las entregas anteriores. Esta revisión es incremental respecto de MYG_ADDIN_ACTUALIZACION_20261109_184033.zip, publicada en DESCARGAS commit 0797c08cd60104a5e7761b91eff8435a96d2b93d, SHA-256 f59d8f730bcc25091a903f8da916761810b8f218cd060c6ef55390db534af7e0.

El texto general de entrega menciona MYG_v27/main; no se sustituyó la copia reestructurada por aquel ref ni se modificó ninguna rama del código. Las rutas son las actuales de MYG_v27_reestructurado. No aplicar sin adaptar a una solución con otra estructura.

Solo cambian el handler de muros, la prueba geométrica y la guía. No se incluyen selector, handler de suelos, pruebas de selección/espesor, proyectos, dependencias ni recursos porque no cambian. Conservar sus versiones anteriores. No hay eliminaciones ni nuevos archivos de aplicación.

## Problema identificado

La captura más reciente identifica la fase de proyección y el mensaje de huella menor que la tolerancia. Eso demuestra una lámina proyectada no representable con las comprobaciones anteriores; no demuestra por sí solo que su origen sea una unión de Revit. La cobertura solo se aceptaba antes si una única huella rectangular sin huecos contenía el triángulo completo.

## Corrección

- Se comprueba cobertura completa con área recortada por el triángulo original, incluyendo contornos cóncavos y restando huecos. Hay una prueba rápida válida solo para perfiles convexos sin huecos. No se deduce cobertura general solo a partir de sus tres vértices.
- Se comprueba el área de la huella ORIGINAL dentro del paño antes de regularizarla. Una huella completamente separada o dentro de un hueco no crea una interferencia nueva por ampliación.
- Si la lámina está completamente cubierta, no se añade otro cortante.
- Si realmente entra en el paño y no está cubierta, se construye una envolvente rectangular orientada según su lado mayor, local exclusivamente a ese triángulo, con aristas mínimas 1.1*PTOL (aprox. 1.006 mm). No se utiliza la caja completa de la viga ni se mueve o desune el modelo.
- Se conservan el recorte entre planos del espesor exterior, la exclusión del origen, visibilidad, vínculos y la selección continua hasta Esc.

La regularización es CONSERVADORA: mantiene el obstáculo completo, a costa de un pequeño recorte adicional del revestimiento. La ampliación por cada lado/eje de la caja orientada original es como máximo aprox. 0.503 mm; la distancia adicional al triángulo puede ser del orden de 1 mm. Las pruebas exigen <=1.2*PTOL (aprox. 1.10 mm) para los casos regulares evaluados. No se garantiza exactitud dimensional submilimétrica ni cero recorte adicional. No cambia el espesor de 15 mm ni PTOL.

## Instalación

1. Cerrar Revit y respaldar solución y DLL actuales.
2. Comparar tus cambios locales/posteriores: reemplazar un archivo completo puede sobrescribirlos. Integrar mediante comparación/merge si existen diferencias propias.
3. Reemplazar únicamente MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs conservando su ruta. Ya está incluido en el .csproj; no volver a incorporarlo. Mantener selector y handler de suelos anteriores.
4. Alternativa al reemplazo: desde la raíz compatible con el ZIP anterior, ejecutar `git apply --check RUTA/ENTREGA/ACTUALIZACION.patch` y después `git apply RUTA/ENTREGA/ACTUALIZACION.patch`. No aplicar también el parche tras reemplazar el .cs. El parche se comprobó contra el archivo de la entrega anterior y reproduce el final byte por byte. Si falla la comprobación, comparar sin forzar.
5. Reemplazar opcionalmente Pruebas/probar_geometria_tarrajeo.py y Documentacion/PRUEBAS_TARRAJEO_RECORTE.md. El script es una prueba externa, no se añade al proyecto del add-in.
6. Compilar en Windows con las referencias reales. Con Revit cerrado, actualizar la DLL de una instalación de prueba y repetir sobre una copia del modelo de la captura. Se conservan manifiesto .addin, iconos y dependencias existentes. Este ZIP entrega fuentes, NO una DLL nueva.

## Configuración

No se agregaron referencias, paquetes ni ajustes. Se mantiene la configuración .NET Framework 4.8 / referencias Revit 2027 / COM Office/Excel existente, cuya compatibilidad real debe verificarse en Windows. No se migró ni reorganizó el proyecto.

## Validación ejecutada

- Roslyn C# 7.3: 179 archivos activos, cero errores sintácticos. No equivale a compilar el add-in completo.
- Pruebas UV actualizadas: 10528 aserciones aprobadas. Cubren perfiles convexos y cóncavos, huecos contenidos/cruzados, área de componentes desconectados, separaciones de 1 mm, contacto real submilimétrico, huellas rotadas/trasladadas y envolventes locales. Una comprobación independiente asegura contención del triángulo y límites de crecimiento.
- Regresión de espesor anterior: 112 aserciones aprobadas. El script no cambió y queda fuera del ZIP.
- git diff --check limpio. Parche incremental aplicado sobre la versión anterior en una carpeta temporal: archivo final idéntico.

Repetir con Python 3 y un SDK .NET 8 o posterior completo ya instalado, sin NuGet ni descargas:

```sh
python Pruebas/probar_geometria_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
```

El script admite --help y crea archivos temporales. Se verificó en Linux; utilizar rutas compatibles o WSL para otros sistemas. Extrae y ejecuta los helpers del código actual con sustitutos mínimos, no carga Revit.

## Validación pendiente y límites

No se compiló el add-in completo ni se generó DLL: el entorno es Linux, sin Revit, MSBuild de .NET Framework ni COM de Office. Falta validar los sólidos, booleanos, transacciones, perfil y uniones reales en Revit con la viga de la captura. La mejora del caso de milímetros fue comunicada por el usuario; no se presenta como una prueba nativa ejecutada aquí.

Repetir la selección de la viga vinculada indicada por el aviso, comparando una copia con/sin unión solo como diagnóstico; el comando no desune nada. Medir las zonas de regularización. Probar perfiles cóncavos, huecos, vínculos transformados y huellas estrechas separadas del paño. Si Revit rechaza la reconstrucción posterior, continúa mostrándose el diagnóstico sin terminar la selección.

## GitHub

Solo se publica este ZIP en una ruta nueva de bimchimbote-droid/DESCARGAS, conservando entregas anteriores. Esto no instala nada en tu PC ni actualiza ramas de MYG_v27 o MYG_v27_reestructurado.

En Visual Studio: revisar Cambios de Git, comparar los archivos y realizar Commit local. Si decides sincronizar tu código, comprobar repositorio/rama y usar Push con tu autorización. La entrega no realiza ese Push.

ARCHIVOS.json contiene la relación y SHA-256 individual de todos los archivos excepto sí mismo. El enlace fijado al commit y la descarga/SHA-256 del ZIP se verifican tras publicar y se informan en la respuesta.
