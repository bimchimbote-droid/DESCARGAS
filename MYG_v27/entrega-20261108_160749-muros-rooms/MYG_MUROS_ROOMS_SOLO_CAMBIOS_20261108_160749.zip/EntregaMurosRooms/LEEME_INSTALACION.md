# Crear muro desde Rooms: corrección de alturas

Esta actualización parcial se aplica sobre la versión reorganizada de `bimchimbote-droid/MYG_v27` utilizada en la conversación. Se acumula a las correcciones anteriores de tarrajeo y muros por contorno; no las sustituye ni las revierte.

## Archivos del add-in que debes reemplazar

| Ruta relativa a la raíz de tu solución | Acción |
| --- | --- |
| `MYG/Funcionalidades/Arquitectura/Habitaciones/CrearMuroDesdeRoomForm.cs` | REEMPLAZAR completo |
| `MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs` | REEMPLAZAR completo |

No hay nuevos archivos que agregar al proyecto del add-in, modificaciones de `.csproj`, paquetes nuevos ni eliminaciones. El ZIP no incluye fuentes de aplicación sin cambios.

## Corrección

El formulario restaba `Level.Elevation` de la cota interna del punto seleccionado. En la captura, `0,25 - 1299,691 = -1299,441 m`, que mezcla la altura interna con una cota mostrada del nivel referida a otra base.

Ahora el cálculo utiliza `Level.ProjectElevation`. La vista previa llama al mismo método que utiliza la ejecución. La lista de niveles muestra explícitamente su **cota interna**, sin modificar la elevación ni las coordenadas de los niveles del modelo. Si el nivel tiene cota interna 0 m, una superficie picada a 0,25 m produce desfase 0,25 m; si su cota interna es distinta, se calcula la diferencia correspondiente.

La misma referencia interna se usa para seleccionar el nivel cercano, proyectar el boundary, buscar el interior del Room, calcular las alturas de vanos y crear los segmentos por encima o debajo de ellos. El punto `Reference.GlobalPoint` no recibe una transformación adicional.

Se conserva el comportamiento de **LIMPIAR/sin superficie**: desfase cero respecto al nivel seleccionado. También se mantienen el desplazamiento hacia el interior, línea de acabado interior, selección múltiple, puertas, segmentación, uniones y parámetros de gestión.

Antes de confirmar el lote, se comprueba que las restricciones verticales de cada muro queden dentro del intervalo solicitado. Esto admite piezas más bajas o con base elevada alrededor de vanos y detecta el desplazamiento grande reportado. Un fallo de esa comprobación impide guardar el lote. Las excepciones de regeneración se propagan hasta abandonar la transacción, sin continuar sobre el documento en estado de fallo.

Esta comprobación de restricciones no certifica toda la geometría, el detalle de cada vano ni ausencia de interferencias con cualquier objeto del modelo.

## Instalación

1. Respalda tu solución y la DLL instalada. Si modificaste alguno de estos dos archivos después de descargar la estructura reorganizada, compara tus cambios antes de sustituirlos.
2. Extrae el ZIP y copia únicamente los dos archivos de la tabla conservando sus rutas. Ya forman parte del proyecto; no agregues copias duplicadas.
3. Recompila en Visual Studio sobre Windows con tus referencias reales de Revit y Office/Excel. Si faltan paquetes, restaura NuGet. Desde Developer PowerShell, después de restaurar, el comando equivalente es `MSBuild.exe MYG\MYG.csproj /t:Build /p:Configuration=Release /p:Platform=x64`.
4. Cierra Revit antes de actualizar la DLL compilada. Conserva tu manifiesto `.addin`, iconos y dependencias de la instalación.
5. Prueba en una copia del modelo: selecciona el Room, el tipo y altura del muro, vuelve a picar la superficie y comprueba la vista previa antes de ejecutar.
6. Prueba además cambiar el nivel tras picar, usar LIMPIAR, un nivel de cota interna distinta de cero y un Room con puertas o ventanas. Revisa base, altura y ubicación de las piezas creadas.

Los muros erróneos ya creados no se mueven ni eliminan automáticamente. Deshaz o revisa los que correspondan en tu modelo de prueba antes de repetir.

## Verificación realizada y pendiente

- 76 comprobaciones aprobadas, 0 fallidas: 61 casos matemáticos y 15 auditorías de código.
- Las pruebas ejecutan cuerpos reales extraídos mediante Roslyn. Para el cálculo del formulario se usa un `Level` de datos de prueba con `Elevation` y `ProjectElevation`; no es la API ni una ejecución de Revit.
- Se cubre el caso de la captura, desfase cero sin superficie, cambio de cota mostrada sin alterar la interna, niveles positivos/negativos, intervalos de piezas de vanos, posiciones remotas, tolerancia de 1 mm y valores inválidos.
- 179 archivos activos analizados sin errores de sintaxis C# 7.3. Otros 29 métodos del formulario y 77 del handler conservan exactamente su contenido fuera del alcance corregido.
- Solo cambiaron estos dos archivos existentes. Proyecto, paquetes, recursos, otras herramientas y correcciones anteriores permanecen iguales respecto a la copia de esta sesión.
- La compilación completa en Linux sigue detenida por `MSB4803`: las referencias COM requieren MSBuild de .NET Framework en Windows. No se generó una DLL nueva aquí ni se ejecutó Revit.
- La compilación y validación funcional en tu modelo y versión de Revit siguen pendientes. No se garantiza que cualquier otro problema de geometría se resuelva con esta corrección de altura.

`Pruebas/MurosRoomsAlturas/` es un proyecto opcional de desarrollo. No agregues sus archivos al proyecto del add-in. Con SDK .NET 10 puedes ejecutar `dotnet run --project Pruebas/MurosRoomsAlturas/MurosRoomsAlturas.Tests.csproj`; no utiliza NuGet externo ni cambia el framework del add-in.

La referencia Git es `a41d354e8206e401a881aacfff3f5da7dfe74d00`, más la reorganización y correcciones previas de la sesión. Solo se publica este ZIP en `bimchimbote-droid/DESCARGAS`; no se hace Push al repositorio del código. Tras instalar y validar, usa Cambios de Git en Visual Studio para revisar, hacer Commit y después Push a tu rama.
