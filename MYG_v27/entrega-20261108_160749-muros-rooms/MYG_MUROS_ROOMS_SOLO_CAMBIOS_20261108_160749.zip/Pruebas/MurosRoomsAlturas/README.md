# Pruebas de cotas de Muros desde Rooms

Este proyecto usa Roslyn para extraer y ejecutar las declaraciones **reales, sin cambiar sus cuerpos**, de `ObtenerDesfaseBaseFeet` en `CrearMuroDesdeRoomForm.cs` y `RangoMuroDentroDeAlturasSolicitadas` en `MUROSDEROOM_EJECUTAR_HANDLER.cs`. Ambos archivos proceden de `MYG/Funcionalidades/Arquitectura/Habitaciones/` y se copian al directorio de salida como contenido. No hay copias de sus fórmulas en las pruebas.

La compilación en memoria añade dos clases contenedoras, los dos campos de estado utilizados por el formulario y una envoltura para preparar esos campos. El tipo `Level` de pruebas es un **stub de datos** con las propiedades `ProjectElevation` y `Elevation`: no es el tipo de Revit, no simula sus restricciones ni su geometría. Permite cambiar independientemente ambas cotas y comprobar qué dato utiliza el cálculo original. La UI WinForms tampoco se ejecuta.

Los casos reproducen la superficie a 0.25 m con cota de proyecto 0 m y cota mostrada 1299.691 m, el desfase incorrecto antiguo de -1299.441 m, niveles de proyecto no nulos y negativos, y la independencia respecto a la cota mostrada. Se verifica también el comportamiento actual sin superficie o con nivel nulo (desfase cero). La prueba del rango acepta piezas inferiores, superiores e interiores generadas por vanos; rechaza cotas remotas, rangos inválidos y valores NaN/infinito; comprueba los límites de tolerancia de 1 mm.

La auditoría AST comprueba que la vista previa y ejecución llaman al mismo cálculo, que combo y selector utilizan `ProjectElevation`, que la UI identifica la cota interna, que boundary/interior de Room/segmentación/huecos utilizan la referencia interna, y que la verificación de restricciones se ejecuta después de regenerar y antes de confirmar la transacción.

## Ejecutar

Requiere .NET SDK 10. Roslyn se referencia desde `$(MSBuildSDKsPath)/../Roslyn/bincore`, incluido en el SDK. No usa paquetes NuGet externos.

Desde la raíz del repositorio:

```bash
dotnet run --project Pruebas/MurosRoomsAlturas/MurosRoomsAlturas.Tests.csproj --configuration Release
```

En el entorno en la nube puede activarse el SDK instalado con:

```bash
source /workspace/.onboarding/MYG_v27/activate.sh
```

La consola muestra el total y los casos por grupo. Cualquier prueba fallida o error de extracción/compilación termina con código de salida distinto de cero. Los cálculos usan pies internos; los valores en metros se convierten con 1 pie = 0.3048 m.

## Alcance

No se compila el addin, no se inicia Revit y no se comprueba el comportamiento real de `Wall.Create`, Room, vanos o transacciones. Las auditorías comprueban la sintaxis de las llamadas presentes, no su ejecución. La integración y la ubicación geométrica final deben probarse en Revit con la solución completa y modelos representativos.
