using System.Globalization;
using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

// Se conservan completos los cuerpos originales. El Level local solo expone
// dos datos y no implementa, simula ni sustituye la API o geometría de Revit.
var pruebas = new List<(string Grupo, string Nombre, Action Ejecutar)>();
SyntaxNode form = LeerFuente("CrearMuroDesdeRoomForm.cs");
SyntaxNode handler = LeerFuente("MUROSDEROOM_EJECUTAR_HANDLER.cs");
MethodDeclarationSyntax metodoDesfase = Metodo(form, "ObtenerDesfaseBaseFeet");
MethodDeclarationSyntax metodoRango = Metodo(handler, "RangoMuroDentroDeAlturasSolicitadas");
string codigo = """
    using System;
    namespace MYG_Addin
    {
        public class Level
        {
            public double ProjectElevation { get; set; }
            public double Elevation { get; set; }
        }
        public class FormReal
        {
            private bool _usarCotaBaseDesdeSuperficie;
            private double _cotaBaseSuperficieFeet;
    """ + metodoDesfase.ToFullString() + """
            public static double Evaluar(bool usar, double cota, double proyecto, double mostrada, bool nivelNulo)
            {
                var instancia = new FormReal();
                instancia._usarCotaBaseDesdeSuperficie = usar;
                instancia._cotaBaseSuperficieFeet = cota;
                Level nivel = nivelNulo ? null : new Level { ProjectElevation = proyecto, Elevation = mostrada };
                return instancia.ObtenerDesfaseBaseFeet(nivel);
            }
        }
        public static class HandlerReal
        {
    """ + metodoRango.ToFullString() + "\n}\n}";
string? plataforma = AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") as string;
if (string.IsNullOrEmpty(plataforma))
    throw new InvalidOperationException("Faltan los ensamblados de plataforma .NET.");
var referencias = plataforma.Split(Path.PathSeparator).Select(p => MetadataReference.CreateFromFile(p));
var compilacion = CSharpCompilation.Create("MurosRoomsMetodosReales", [CSharpSyntaxTree.ParseText(codigo)],
    referencias, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var memoria = new MemoryStream();
var emision = compilacion.Emit(memoria);
if (!emision.Success)
    throw new InvalidOperationException(string.Join(Environment.NewLine, emision.Diagnostics));
Assembly ensamblado = Assembly.Load(memoria.ToArray());
var desfase = (Func<bool, double, double, double, bool, double>)ensamblado.GetType("MYG_Addin.FormReal")!
    .GetMethod("Evaluar")!.CreateDelegate(typeof(Func<bool, double, double, double, bool, double>));
var rango = (Func<double, double, double, double, double, bool>)ensamblado.GetType("MYG_Addin.HandlerReal")!
    .GetMethod("RangoMuroDentroDeAlturasSolicitadas", BindingFlags.NonPublic | BindingFlags.Static)!
    .CreateDelegate(typeof(Func<double, double, double, double, double, bool>));
double mm = Metros(.001);

(string Nombre, bool Usar, double Cota, double Proyecto, double Mostrada, bool Nulo, double Esperado)[] casosDesfase =
[
    ("captura superficie 0.25 m y nivel mostrado 1299.691 m", true, Metros(.25), 0, Metros(1299.691), false, Metros(.25)),
    ("nivel de proyecto positivo bajo superficie", true, Metros(10.25), Metros(10), Metros(1309.691), false, Metros(.25)),
    ("nivel de proyecto positivo sobre superficie", true, Metros(9.75), Metros(10), Metros(1309.691), false, Metros(-.25)),
    ("nivel de proyecto negativo bajo superficie", true, Metros(-9.75), Metros(-10), Metros(1289.691), false, Metros(.25)),
    ("nivel de proyecto negativo sobre superficie", true, Metros(-10.25), Metros(-10), Metros(1289.691), false, Metros(-.25)),
    ("superficie positiva y nivel negativo", true, 8, -12, 9000, false, 20),
    ("superficie negativa y nivel positivo", true, -8, 12, -9000, false, -20),
    ("superficie en el nivel", true, 12, 12, 99, false, 0),
    ("sin superficie con nivel positivo", false, 99, 12, 999, false, 0),
    ("sin superficie con nivel negativo", false, -99, -12, -999, false, 0),
    ("sin superficie no usa cota inválida", false, double.NaN, 12, 999, false, 0),
    ("nivel nulo con superficie conserva retorno cero", true, Metros(.25), 0, 0, true, 0),
    ("nivel nulo sin superficie conserva retorno cero", false, Metros(.25), 0, 0, true, 0)
];
foreach (var caso in casosDesfase)
    Agregar("desfases reales", caso.Nombre, () => Cerca(
        desfase(caso.Usar, caso.Cota, caso.Proyecto, caso.Mostrada, caso.Nulo), caso.Esperado));

foreach (double mostrada in new[] { Metros(-1300), 0, Metros(1299.691), Metros(100000), double.NaN, double.PositiveInfinity })
    Agregar("independencia de Elevation", $"solo cambia Elevation a {Etiqueta(mostrada)}", () =>
    {
        double resultado = desfase(true, Metros(10.25), Metros(10), mostrada, false);
        Cerca(resultado, Metros(.25));
        Cerca(Metros(10) + resultado, Metros(10.25));
    });

(string Nombre, double BaseReal, double TopReal, double BasePedida, double TopPedida, bool Esperado)[] casosRango =
[
    ("muro completo desde superficie", Metros(.25), Metros(3.25), Metros(.25), Metros(3.25), true),
    ("pieza bajo ventana", Metros(.25), Metros(1.1), Metros(.25), Metros(3.25), true),
    ("pieza sobre ventana", Metros(2.1), Metros(3.25), Metros(.25), Metros(3.25), true),
    ("pieza interior entre vanos", Metros(1.1), Metros(2.1), Metros(.25), Metros(3.25), true),
    ("pieza superior de puerta", Metros(2.35), Metros(3.25), Metros(.25), Metros(3.25), true),
    ("intervalo negativo completo", -20, -10, -20, -10, true),
    ("pieza dentro de intervalo negativo", -18, -12, -20, -10, true),
    ("intervalo cruza el cero", -3, 7, -3, 7, true),
    ("desfase antiguo -1299.441 m rechazado", Metros(-1299.441), Metros(-1296.441), Metros(.25), Metros(3.25), false),
    ("remoto 1300 m por debajo", Metros(-1299.75), Metros(-1296.75), Metros(.25), Metros(3.25), false),
    ("remoto 1300 m por encima", Metros(1300.25), Metros(1303.25), Metros(.25), Metros(3.25), false),
    ("pieza completamente bajo rango", -10, -1, 0, 10, false),
    ("pieza completamente sobre rango", 11, 20, 0, 10, false),
    ("base exterior aunque coronación interior", -1, 5, 0, 10, false),
    ("coronación exterior aunque base interior", 5, 11, 0, 10, false),
    ("base 0.999 mm bajo límite", -Metros(.000999), 5, 0, 10, true),
    ("base exactamente 1 mm bajo límite", -mm, 5, 0, 10, true),
    ("base 1.001 mm bajo límite", -Metros(.001001), 5, 0, 10, false),
    ("coronación 0.999 mm sobre límite", -5, Metros(.000999), -10, 0, true),
    ("coronación exactamente 1 mm sobre límite", -5, mm, -10, 0, true),
    ("coronación 1.001 mm sobre límite", -5, Metros(.001001), -10, 0, false),
    ("rango real invertido", 10, 0, 0, 10, false),
    ("rango solicitado invertido", 0, 10, 10, 0, false),
    ("altura real cero", 5, 5, 0, 10, false),
    ("altura solicitada cero", 0, 10, 5, 5, false)
];
foreach (var caso in casosRango)
    Agregar("rangos reales", caso.Nombre, () => Igual(
        rango(caso.BaseReal, caso.TopReal, caso.BasePedida, caso.TopPedida, mm), caso.Esperado));
Agregar("rangos inválidos", "tolerancia cero", () => Falso(rango(0, 10, 0, 10, 0)));
Agregar("rangos inválidos", "tolerancia negativa", () => Falso(rango(0, 10, 0, 10, -mm)));
for (int posicion = 0; posicion < 5; posicion++)
{
    foreach (double invalido in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity })
    {
        int indice = posicion;
        Agregar("rangos inválidos", $"argumento {indice + 1}: {Etiqueta(invalido)}", () =>
        {
            double[] valores = [0, 10, 0, 10, mm];
            valores[indice] = invalido;
            Falso(rango(valores[0], valores[1], valores[2], valores[3], valores[4]));
        });
    }
}

Agregar("auditoría AST", "vista previa llama cálculo real con nivel", () =>
{
    var llamada = Invocaciones(Metodo(form, "ActualizarTextoSuperficie"), "ObtenerDesfaseBaseFeet").Single();
    Verdadero(llamada.ArgumentList.Arguments.Single().Expression.ToString() == "nivel");
});
Agregar("auditoría AST", "ejecución llama cálculo del formulario con nivel", () =>
{
    var llamada = Invocaciones(Metodo(handler, "CrearMurosDesdeRooms"), "ObtenerDesfaseBaseFeet").Single();
    Verdadero(llamada.Expression is MemberAccessExpressionSyntax acceso && acceso.Expression.ToString() == "Form");
    Verdadero(llamada.ArgumentList.Arguments.Single().Expression.ToString() == "nivel");
});
Agregar("auditoría AST", "fuentes sin accesos a Elevation", () =>
{
    Falso(form.DescendantNodes().OfType<MemberAccessExpressionSyntax>().Any(a => a.Name.Identifier.ValueText == "Elevation"));
    Falso(handler.DescendantNodes().OfType<MemberAccessExpressionSyntax>().Any(a => a.Name.Identifier.ValueText == "Elevation"));
});
Agregar("auditoría AST", "combo ordena y guarda cotas ProjectElevation", () =>
{
    var cargar = Metodo(form, "CargarNiveles");
    Verdadero(cargar.DescendantNodes().OfType<MemberAccessExpressionSyntax>().Count(a => a.Name.Identifier.ValueText == "ProjectElevation") >= 4);
    var asignacion = cargar.DescendantNodes().OfType<AssignmentExpressionSyntax>().Single(a => a.Left.ToString() == "item.ElevacionFeet");
    Verdadero(EsProjectElevation(asignacion.Right));
});
Agregar("auditoría AST", "combo identifica cota interna", () =>
    Verdadero(Literales(Metodo(form, "CargarNiveles")).Any(s => s.Contains("cota interna", StringComparison.OrdinalIgnoreCase))));
Agregar("auditoría AST", "vista previa identifica cota interna picada", () =>
    Verdadero(Literales(Metodo(form, "ActualizarTextoSuperficie")).Any(s => s.Contains("Cota interna picada", StringComparison.Ordinal))));
Agregar("auditoría AST", "selector más cercano usa ProjectElevation", () =>
    Verdadero(Metodo(handler, "ObtenerNivelMasCercano").DescendantNodes().OfType<MemberAccessExpressionSyntax>().Any(a => a.Name.Identifier.ValueText == "ProjectElevation")));
Agregar("auditoría AST", "boundary recibe cota interna más desfase", () =>
{
    var llamada = Invocaciones(Metodo(handler, "CrearMurosDesdeRooms"), "ObtenerTramosBoundaryRoom").Single();
    Verdadero(EsSumaBase(llamada.ArgumentList.Arguments[2].Expression));
});
Agregar("auditoría AST", "interior del Room recibe cota interna más desfase", () =>
{
    var llamada = Invocaciones(Metodo(handler, "CrearMurosDesdeBoundaryHaciaAdentro"), "ObtenerDireccionHaciaInteriorRoom").Single();
    Verdadero(EsSumaBase(llamada.ArgumentList.Arguments[2].Expression));
});
Agregar("auditoría AST", "segmentación calcula base con ProjectElevation", () =>
{
    var variable = Metodo(handler, "CrearMurosSegmentadosPorHuecos").DescendantNodes().OfType<VariableDeclaratorSyntax>()
        .Single(v => v.Identifier.ValueText == "zBaseMuro");
    Verdadero(EsSumaBase(variable.Initializer!.Value));
});
Agregar("auditoría AST", "segmentación propaga límites a los huecos", () =>
{
    var llamada = Invocaciones(Metodo(handler, "CrearMurosSegmentadosPorHuecos"), "PrepararHuecosParaSegmentacion").Single();
    Verdadero(llamada.ArgumentList.Arguments[2].Expression.ToString() == "zBaseMuro");
    Verdadero(llamada.ArgumentList.Arguments[3].Expression.ToString() == "zSuperiorMuro");
});
Agregar("auditoría AST", "piezas por huecos calculan offset contra ProjectElevation", () =>
{
    var variable = Metodo(handler, "CrearMuroRectangularDesdeIntervalo").DescendantNodes().OfType<VariableDeclaratorSyntax>()
        .Single(v => v.Identifier.ValueText == "offsetBase");
    Verdadero(variable.Initializer!.Value is BinaryExpressionSyntax resta && resta.IsKind(SyntaxKind.SubtractExpression) &&
        resta.Left.ToString() == "zInferior" && EsProjectElevation(resta.Right));
});
Agregar("auditoría AST", "verificación recupera base de restricción interna", () =>
{
    var variable = Metodo(handler, "VerificarAlturasMurosDesdeRooms").DescendantNodes().OfType<VariableDeclaratorSyntax>()
        .Single(v => v.Identifier.ValueText == "zBaseReal");
    Verdadero(variable.Initializer!.Value is BinaryExpressionSyntax suma && suma.IsKind(SyntaxKind.AddExpression) && EsProjectElevation(suma.Left));
    Verdadero(Invocaciones(Metodo(handler, "VerificarAlturasMurosDesdeRooms"), "RangoMuroDentroDeAlturasSolicitadas").Length == 1);
});
Agregar("auditoría AST", "verificación usa 1 mm de tolerancia", () =>
{
    var variable = Metodo(handler, "VerificarAlturasMurosDesdeRooms").DescendantNodes().OfType<VariableDeclaratorSyntax>()
        .Single(v => v.Identifier.ValueText == "tolerancia");
    var llamada = variable.Initializer!.Value as InvocationExpressionSyntax;
    Verdadero(llamada is not null && llamada.Expression.ToString() == "MetrosAPies");
    var literal = llamada!.ArgumentList.Arguments.Single().Expression as LiteralExpressionSyntax;
    Verdadero(literal is not null && Convert.ToDouble(literal.Token.Value, CultureInfo.InvariantCulture) == .001);
});
Agregar("auditoría AST", "guard tras regenerar y antes de Commit", () =>
{
    var crear = Metodo(handler, "CrearMurosDesdeRooms");
    var verificar = Invocaciones(crear, "VerificarAlturasMurosDesdeRooms").Single();
    var confirmar = Invocaciones(crear, "Commit").Single();
    Verdadero(Invocaciones(crear, "Regenerate").Any(r => r.SpanStart < verificar.SpanStart));
    Verdadero(verificar.SpanStart < confirmar.SpanStart);
    Verdadero(EsSumaBase(verificar.ArgumentList.Arguments[2].Expression));
});

int correctas = 0;
int fallidas = 0;
foreach (var prueba in pruebas)
{
    try
    {
        prueba.Ejecutar();
        correctas++;
        Console.WriteLine($"OK [{prueba.Grupo}] {prueba.Nombre}");
    }
    catch (Exception ex)
    {
        fallidas++;
        Console.Error.WriteLine($"FALLO [{prueba.Grupo}] {prueba.Nombre}: {ex.Message}");
    }
}
Console.WriteLine();
foreach (var grupo in pruebas.GroupBy(p => p.Grupo))
    Console.WriteLine($"{grupo.Key}: {grupo.Count()} casos");
Console.WriteLine($"TOTAL: {pruebas.Count}; CORRECTAS: {correctas}; FALLIDAS: {fallidas}");
Console.WriteLine("Alcance: métodos reales con stub de datos Level y auditoría AST; no ejecuta Revit ni compila el addin.");
return fallidas == 0 ? 0 : 1;

void Agregar(string grupo, string nombre, Action ejecutar) => pruebas.Add((grupo, nombre, ejecutar));
static SyntaxNode LeerFuente(string nombre) => CSharpSyntaxTree.ParseText(
    File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "CodigoFuente", nombre))).GetRoot();
static MethodDeclarationSyntax Metodo(SyntaxNode fuente, string nombre) => fuente.DescendantNodes().OfType<MethodDeclarationSyntax>()
    .Single(m => m.Identifier.ValueText == nombre);
static InvocationExpressionSyntax[] Invocaciones(SyntaxNode nodo, string nombre) =>
    nodo.DescendantNodes().OfType<InvocationExpressionSyntax>().Where(i => i.Expression switch
    {
        IdentifierNameSyntax identificador => identificador.Identifier.ValueText == nombre,
        MemberAccessExpressionSyntax miembro => miembro.Name.Identifier.ValueText == nombre,
        _ => false
    }).ToArray();
static IEnumerable<string> Literales(SyntaxNode nodo) => nodo.DescendantNodes().OfType<LiteralExpressionSyntax>()
    .Where(l => l.IsKind(SyntaxKind.StringLiteralExpression)).Select(l => l.Token.ValueText);
static bool EsProjectElevation(ExpressionSyntax expresion) => expresion is MemberAccessExpressionSyntax acceso &&
    acceso.Name.Identifier.ValueText == "ProjectElevation";
static bool EsSumaBase(ExpressionSyntax expresion) => expresion is BinaryExpressionSyntax suma &&
    suma.IsKind(SyntaxKind.AddExpression) && EsProjectElevation(suma.Left) && suma.Right.ToString() == "baseOffsetFeet";
static double Metros(double metros) => metros / .3048;
static string Etiqueta(double valor) => valor.ToString("G17", CultureInfo.InvariantCulture);
static void Verdadero(bool valor)
{
    if (!valor) throw new InvalidOperationException("Se esperaba verdadero.");
}
static void Falso(bool valor)
{
    if (valor) throw new InvalidOperationException("Se esperaba falso.");
}
static void Igual(bool real, bool esperado)
{
    if (real != esperado) throw new InvalidOperationException($"Se esperaba {esperado}, obtenido {real}.");
}
static void Cerca(double real, double esperado)
{
    if (double.IsNaN(real) || double.IsInfinity(real) || Math.Abs(real - esperado) > 1e-8)
        throw new InvalidOperationException($"Se esperaba {Etiqueta(esperado)}, obtenido {Etiqueta(real)} pies.");
}
