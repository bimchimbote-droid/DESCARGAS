using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 4.2 - CREAR MURO DESDE ROOM
    // =====================================

    public class CrearMuroDesdeRoomForm : WinForms.Form
    {
        // =========================================================
        // ENUM INTERNO
        // =========================================================

        public enum RoomMuroAccion
        {
            Ninguna,
            SeleccionarRoom,
            PicarSuperficieBase,
            CrearMuro
        }

        // =========================================================
        // VARIABLES
        // =========================================================

        private UIDocument _uidoc;
        private Document _doc;

        private WinForms.Label lblRoomSeleccionado;
        private WinForms.Label lblTituloTipoMuro;
        private WinForms.Label lblAltura;
        private WinForms.Label lblNivel;
        private WinForms.Label lblSuperficie;
        private WinForms.Label lblSuperficieInfo;
        private WinForms.Label lblResultado;

        private WinForms.ComboBox cmbTipoMuro;
        private WinForms.ComboBox cmbNivel;
        private WinForms.TextBox txtAlturaMetros;

        private WinForms.Button btnSeleccionarRoom;
        private WinForms.Button btnPicarSuperficie;
        private WinForms.Button btnLimpiarSuperficie;
        private WinForms.Button btnEjecutar;
        private WinForms.Button btnCerrar;

        private List<RoomMuroTipoItem> _tiposMuro = new List<RoomMuroTipoItem>();
        private List<RoomMuroNivelItem> _niveles = new List<RoomMuroNivelItem>();

        private bool _filtrandoCombo = false;
        private bool _cargandoCombos = false;
        private string _ultimoResultado = "";

        private bool _usarCotaBaseDesdeSuperficie = false;
        private double _cotaBaseSuperficieFeet = 0.0;

        public ExternalEvent EjecutarEvent;
        public EjecutarCrearMuroDesdeRoomHandler Handler;

        public List<ElementId> RoomsSeleccionadosIds { get; set; }

        public bool UsarCotaBaseDesdeSuperficie
        {
            get { return _usarCotaBaseDesdeSuperficie; }
        }

        public double CotaBaseSuperficieFeet
        {
            get { return _cotaBaseSuperficieFeet; }
        }

        public double AlturaMetros
        {
            get
            {
                if (txtAlturaMetros == null)
                    return 0.0;

                string texto = txtAlturaMetros.Text;

                if (string.IsNullOrWhiteSpace(texto))
                    return 0.0;

                texto = texto.Trim().Replace(",", ".");

                double valor;

                if (double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor))
                {
                    return valor;
                }

                return 0.0;
            }
        }

        public ElementId TipoMuroSeleccionadoId
        {
            get { return ObtenerTipoMuroIdDesdeCombo(cmbTipoMuro); }
        }

        public ElementId NivelSeleccionadoId
        {
            get { return ObtenerNivelIdDesdeCombo(cmbNivel); }
        }

        public CrearMuroDesdeRoomForm(UIDocument uidoc)
        {
            _uidoc = uidoc;
            _doc = uidoc.Document;

            RoomsSeleccionadosIds = new List<ElementId>();

            this.Text = "🏠 Crear Muro desde Rooms";
            this.Width = 540;
            this.Height = 620;
            this.MinimumSize = new Drawing.Size(540, 620);
            this.MaximumSize = new Drawing.Size(540, 620);
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;
            this.AutoScaleMode = WinForms.AutoScaleMode.Dpi;

            WinForms.Label lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "01. SELECCIONAR HABITACIÓN / ROOM",
                Left = 20,
                Top = 38,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            btnSeleccionarRoom = new WinForms.Button()
            {
                Text = "SELECCIONAR ROOMS",
                Width = 180,
                Height = 32,
                Left = 20,
                Top = 65,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarRoom.FlatAppearance.BorderSize = 0;

            btnSeleccionarRoom.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = RoomMuroAccion.SeleccionarRoom;
                EjecutarEvent?.Raise();
            };

            lblRoomSeleccionado = new WinForms.Label()
            {
                Text = "Rooms seleccionados: Ninguno",
                Left = 20,
                Top = 107,
                Width = 480,
                Height = 55,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            lblTituloTipoMuro = new WinForms.Label()
            {
                Text = "02. TIPO DE MURO",
                Left = 20,
                Top = 175,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            cmbTipoMuro = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 202,
                Width = 480,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.None,
                AutoCompleteSource = WinForms.AutoCompleteSource.None,
                IntegralHeight = false,
                DropDownHeight = 180
            };

            lblAltura = new WinForms.Label()
            {
                Text = "03. ALTURA DEL MURO (m)",
                Left = 20,
                Top = 245,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtAlturaMetros = new WinForms.TextBox()
            {
                Left = 20,
                Top = 272,
                Width = 120,
                Height = 25,
                Text = "2.40",
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            WinForms.Label lblNotaAltura = new WinForms.Label()
            {
                Text = "Altura no conectada del muro",
                Left = 155,
                Top = 275,
                Width = 350,
                Height = 22,
                ForeColor = Drawing.Color.FromArgb(90, 90, 90)
            };

            lblNivel = new WinForms.Label()
            {
                Text = "04. NIVEL DE REFERENCIA",
                Left = 20,
                Top = 315,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            cmbNivel = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 342,
                Width = 480,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.None,
                AutoCompleteSource = WinForms.AutoCompleteSource.None,
                IntegralHeight = false,
                DropDownHeight = 180
            };

            cmbNivel.SelectedIndexChanged += (s, e) =>
            {
                ActualizarTextoSuperficie();
            };

            lblSuperficie = new WinForms.Label()
            {
                Text = "05. COTA BASE DESDE SUPERFICIE",
                Left = 20,
                Top = 385,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            btnPicarSuperficie = new WinForms.Button()
            {
                Text = "PICAR SUPERFICIE",
                Width = 155,
                Height = 32,
                Left = 20,
                Top = 412,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnPicarSuperficie.FlatAppearance.BorderSize = 0;

            btnPicarSuperficie.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = RoomMuroAccion.PicarSuperficieBase;
                EjecutarEvent?.Raise();
            };

            btnLimpiarSuperficie = new WinForms.Button()
            {
                Text = "LIMPIAR",
                Width = 90,
                Height = 32,
                Left = 185,
                Top = 412,
                BackColor = Drawing.Color.FromArgb(130, 130, 130),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnLimpiarSuperficie.FlatAppearance.BorderSize = 0;

            btnLimpiarSuperficie.Click += (s, e) =>
            {
                _usarCotaBaseDesdeSuperficie = false;
                _cotaBaseSuperficieFeet = 0.0;
                ActualizarTextoSuperficie();
                MostrarResultado("Cota base limpiada. Se usará desfase base 0.00 m respecto al nivel seleccionado.");
            };

            lblSuperficieInfo = new WinForms.Label()
            {
                Text = "Sin superficie picada. Se usará desfase base 0.00 m.",
                Left = 20,
                Top = 452,
                Width = 480,
                Height = 40,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Width = 135,
                Height = 36,
                Left = 220,
                Top = 510,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;
            btnEjecutar.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnEjecutar.Click += (s, e) =>
            {
                AsegurarSeleccionCombo(cmbTipoMuro);
                AsegurarSeleccionCombo(cmbNivel);

                if (RoomsSeleccionadosIds == null || RoomsSeleccionadosIds.Count == 0)
                {
                    MostrarResultado("Debe seleccionar una o más habitaciones / Rooms antes de ejecutar.");
                    return;
                }

                if (TipoMuroSeleccionadoId == ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar el tipo de muro.");
                    return;
                }

                if (AlturaMetros <= 0.0)
                {
                    MostrarResultado("Debe ingresar una altura de muro válida mayor que 0.00 m.");
                    return;
                }

                if (NivelSeleccionadoId == ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar un nivel de referencia.");
                    return;
                }

                if (Handler == null)
                    return;

                Handler.Accion = RoomMuroAccion.CrearMuro;
                EjecutarEvent?.Raise();
            };

            btnCerrar = new WinForms.Button()
            {
                Text = "CERRAR",
                Width = 130,
                Height = 36,
                Left = 370,
                Top = 510,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnCerrar.FlatAppearance.BorderSize = 0;

            btnCerrar.Click += (s, e) =>
            {
                this.Close();
            };

            lblResultado = new WinForms.Label()
            {
                Text = "",
                Left = 20,
                Top = 555,
                Width = 480,
                Height = 38,
                Visible = true,
                ForeColor = Drawing.Color.FromArgb(90, 90, 90)
            };

            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(btnSeleccionarRoom);
            Controls.Add(lblRoomSeleccionado);

            Controls.Add(lblTituloTipoMuro);
            Controls.Add(cmbTipoMuro);

            Controls.Add(lblAltura);
            Controls.Add(txtAlturaMetros);
            Controls.Add(lblNotaAltura);

            Controls.Add(lblNivel);
            Controls.Add(cmbNivel);

            Controls.Add(lblSuperficie);
            Controls.Add(btnPicarSuperficie);
            Controls.Add(btnLimpiarSuperficie);
            Controls.Add(lblSuperficieInfo);

            Controls.Add(btnEjecutar);
            Controls.Add(btnCerrar);
            Controls.Add(lblResultado);

            ConfigurarComboConFiltro(cmbTipoMuro);
            ConfigurarComboConFiltro(cmbNivel);

            CargarTiposDeMuro();
            CargarNiveles();
            ActualizarTextoSuperficie();

            MostrarResultado("Seleccione los Rooms, tipo de muro, altura y ejecute.");
        }

        // =========================================================
        // COTA BASE DESDE SUPERFICIE
        // =========================================================

        public void AplicarCotaBaseDesdeSuperficie(XYZ puntoGlobal, Level nivelCercano)
        {
            if (puntoGlobal == null)
                return;

            _usarCotaBaseDesdeSuperficie = true;
            _cotaBaseSuperficieFeet = puntoGlobal.Z;

            if (nivelCercano != null)
                SeleccionarNivelEnCombo(nivelCercano.Id);

            ActualizarTextoSuperficie();
            MostrarResultado("Cota base tomada desde superficie.");
        }

        public double ObtenerDesfaseBaseFeet(Level nivel)
        {
            if (nivel == null)
                return 0.0;

            if (!_usarCotaBaseDesdeSuperficie)
                return 0.0;

            return _cotaBaseSuperficieFeet - nivel.ProjectElevation;
        }

        private void ActualizarTextoSuperficie()
        {
            if (lblSuperficieInfo == null)
                return;

            if (!_usarCotaBaseDesdeSuperficie)
            {
                lblSuperficieInfo.Text = "Sin superficie picada. Se usará desfase base 0.00 m.";
                return;
            }

            Level nivel = ObtenerNivelDesdeCombo();
            // La vista previa y la ejecución comparten exactamente el cálculo.
            double offsetFeet = ObtenerDesfaseBaseFeet(nivel);

            lblSuperficieInfo.Text =
                "Cota interna picada: " + PiesAMetros(_cotaBaseSuperficieFeet).ToString("0.###") + " m" +
                " | Desfase base: " + PiesAMetros(offsetFeet).ToString("0.###") + " m";
        }

        // =========================================================
        // COMBOBOX EDITABLES CON FILTRO EN TIEMPO REAL
        // =========================================================

        private void ConfigurarComboConFiltro(WinForms.ComboBox combo)
        {
            if (combo == null)
                return;

            combo.TextUpdate += Combo_TextUpdate;
            combo.KeyDown += Combo_KeyDown;
            combo.Leave += Combo_Leave;
            combo.DropDown += Combo_DropDown;
        }

        private void Combo_TextUpdate(object sender, EventArgs e)
        {
            if (_cargandoCombos || _filtrandoCombo)
                return;

            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            if (combo == cmbTipoMuro)
            {
                FiltrarComboTiposMuro(combo, combo.Text);
                return;
            }

            if (combo == cmbNivel)
            {
                FiltrarComboNiveles(combo, combo.Text);
                return;
            }
        }

        private void Combo_KeyDown(object sender, WinForms.KeyEventArgs e)
        {
            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            if (e.KeyCode == WinForms.Keys.Escape)
            {
                RestaurarComboCompleto(combo, true);
                e.Handled = true;
                return;
            }

            if (e.KeyCode == WinForms.Keys.Enter || e.KeyCode == WinForms.Keys.Tab)
            {
                AsegurarSeleccionCombo(combo);
                combo.SelectionStart = combo.Text.Length;
                combo.SelectionLength = 0;
            }
        }

        private void Combo_Leave(object sender, EventArgs e)
        {
            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            AsegurarSeleccionCombo(combo);
            ActualizarTextoSuperficie();
        }

        private void Combo_DropDown(object sender, EventArgs e)
        {
            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            if (combo.Items.Count == 0)
                RestaurarComboCompleto(combo, false);
        }

        private void FiltrarComboTiposMuro(WinForms.ComboBox combo, string textoFiltro)
        {
            if (combo == null)
                return;

            string textoActual = combo.Text;
            int cursor = combo.SelectionStart;

            List<object> filtrados = new List<object>();

            foreach (RoomMuroTipoItem item in _tiposMuro)
            {
                if (item == null)
                    continue;

                if (CoincideFiltro(item.Nombre, textoFiltro))
                    filtrados.Add(item);
            }

            AplicarFiltroACombo(combo, filtrados, textoActual, cursor);
        }

        private void FiltrarComboNiveles(WinForms.ComboBox combo, string textoFiltro)
        {
            if (combo == null)
                return;

            string textoActual = combo.Text;
            int cursor = combo.SelectionStart;

            List<object> filtrados = new List<object>();

            foreach (RoomMuroNivelItem item in _niveles)
            {
                if (item == null)
                    continue;

                if (CoincideFiltro(item.Nombre, textoFiltro))
                    filtrados.Add(item);
            }

            AplicarFiltroACombo(combo, filtrados, textoActual, cursor);
        }

        private void AplicarFiltroACombo(
            WinForms.ComboBox combo,
            List<object> itemsFiltrados,
            string textoActual,
            int cursor)
        {
            if (combo == null)
                return;

            try
            {
                _filtrandoCombo = true;

                combo.BeginUpdate();
                combo.Items.Clear();

                if (itemsFiltrados != null)
                {
                    foreach (object item in itemsFiltrados)
                    {
                        if (item != null)
                            combo.Items.Add(item);
                    }
                }

                combo.EndUpdate();

                combo.Text = textoActual;

                if (cursor < 0)
                    cursor = 0;

                if (cursor > combo.Text.Length)
                    cursor = combo.Text.Length;

                combo.SelectionStart = cursor;
                combo.SelectionLength = 0;

                if (combo.Focused)
                {
                    try
                    {
                        combo.DroppedDown = true;
                        WinForms.Cursor.Current = WinForms.Cursors.Default;
                    }
                    catch
                    {
                    }
                }
            }
            finally
            {
                _filtrandoCombo = false;
            }
        }

        private void RestaurarComboCompleto(WinForms.ComboBox combo, bool conservarTexto)
        {
            if (combo == null)
                return;

            string textoActual = combo.Text;
            int cursor = combo.SelectionStart;

            try
            {
                _filtrandoCombo = true;

                combo.BeginUpdate();
                combo.Items.Clear();

                if (combo == cmbTipoMuro)
                {
                    foreach (RoomMuroTipoItem item in _tiposMuro)
                    {
                        if (item != null)
                            combo.Items.Add(item);
                    }
                }
                else if (combo == cmbNivel)
                {
                    foreach (RoomMuroNivelItem item in _niveles)
                    {
                        if (item != null)
                            combo.Items.Add(item);
                    }
                }

                combo.EndUpdate();

                if (conservarTexto)
                {
                    combo.Text = textoActual;

                    if (cursor < 0)
                        cursor = 0;

                    if (cursor > combo.Text.Length)
                        cursor = combo.Text.Length;

                    combo.SelectionStart = cursor;
                    combo.SelectionLength = 0;
                }
            }
            finally
            {
                _filtrandoCombo = false;
            }
        }

        private void AsegurarSeleccionCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return;

            if (_cargandoCombos || _filtrandoCombo)
                return;

            if (combo.SelectedItem != null)
                return;

            if (combo == cmbTipoMuro)
            {
                RoomMuroTipoItem tipo = BuscarTipoMuroPorTexto(combo.Text);

                if (tipo != null)
                {
                    RestaurarComboCompleto(combo, false);
                    SeleccionarTipoMuroEnCombo(tipo.Id);
                    return;
                }
            }

            if (combo == cmbNivel)
            {
                RoomMuroNivelItem nivel = BuscarNivelPorTexto(combo.Text);

                if (nivel != null)
                {
                    RestaurarComboCompleto(combo, false);
                    SeleccionarNivelEnCombo(nivel.Id);
                    return;
                }
            }
        }

        private ElementId ObtenerTipoMuroIdDesdeCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return ElementId.InvalidElementId;

            RoomMuroTipoItem itemSeleccionado = combo.SelectedItem as RoomMuroTipoItem;

            if (itemSeleccionado != null && itemSeleccionado.Id != null)
                return itemSeleccionado.Id;

            RoomMuroTipoItem itemPorTexto = BuscarTipoMuroPorTexto(combo.Text);

            if (itemPorTexto != null && itemPorTexto.Id != null)
                return itemPorTexto.Id;

            return ElementId.InvalidElementId;
        }

        private ElementId ObtenerNivelIdDesdeCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return ElementId.InvalidElementId;

            RoomMuroNivelItem itemSeleccionado = combo.SelectedItem as RoomMuroNivelItem;

            if (itemSeleccionado != null && itemSeleccionado.Id != null)
                return itemSeleccionado.Id;

            RoomMuroNivelItem itemPorTexto = BuscarNivelPorTexto(combo.Text);

            if (itemPorTexto != null && itemPorTexto.Id != null)
                return itemPorTexto.Id;

            return ElementId.InvalidElementId;
        }

        private Level ObtenerNivelDesdeCombo()
        {
            ElementId idNivel = NivelSeleccionadoId;

            if (idNivel == ElementId.InvalidElementId)
                return null;

            return _doc.GetElement(idNivel) as Level;
        }

        private RoomMuroTipoItem BuscarTipoMuroPorTexto(string texto)
        {
            if (_tiposMuro == null || _tiposMuro.Count == 0)
                return null;

            string filtro = NormalizarTexto(texto);

            if (string.IsNullOrWhiteSpace(filtro))
                return null;

            foreach (RoomMuroTipoItem item in _tiposMuro)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre) == filtro)
                    return item;
            }

            foreach (RoomMuroTipoItem item in _tiposMuro)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre).Contains(filtro))
                    return item;
            }

            return null;
        }

        private RoomMuroNivelItem BuscarNivelPorTexto(string texto)
        {
            if (_niveles == null || _niveles.Count == 0)
                return null;

            string filtro = NormalizarTexto(texto);

            if (string.IsNullOrWhiteSpace(filtro))
                return null;

            foreach (RoomMuroNivelItem item in _niveles)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre) == filtro)
                    return item;
            }

            foreach (RoomMuroNivelItem item in _niveles)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre).Contains(filtro))
                    return item;
            }

            return null;
        }

        private bool CoincideFiltro(string textoBase, string textoFiltro)
        {
            string baseNormalizada = NormalizarTexto(textoBase);
            string filtroNormalizado = NormalizarTexto(textoFiltro);

            if (string.IsNullOrWhiteSpace(filtroNormalizado))
                return true;

            return baseNormalizada.Contains(filtroNormalizado);
        }

        private string NormalizarTexto(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string textoFormD = texto.Trim().Normalize(System.Text.NormalizationForm.FormD);
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            for (int i = 0; i < textoFormD.Length; i++)
            {
                char c = textoFormD[i];

                System.Globalization.UnicodeCategory categoria =
                    System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c);

                if (categoria != System.Globalization.UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }

            return sb.ToString()
                .Normalize(System.Text.NormalizationForm.FormC)
                .ToUpperInvariant();
        }

        // =========================================================
        // CARGA DE TIPOS Y NIVELES
        // =========================================================

        private void CargarTiposDeMuro()
        {
            try
            {
                _cargandoCombos = true;

                _tiposMuro.Clear();
                cmbTipoMuro.Items.Clear();

                List<WallType> tipos = new List<WallType>();

                FilteredElementCollector collector = new FilteredElementCollector(_doc);
                collector.OfClass(typeof(WallType));

                foreach (Element elemento in collector)
                {
                    WallType tipo = elemento as WallType;

                    if (tipo == null)
                        continue;

                    tipos.Add(tipo);
                }

                tipos.Sort(delegate (WallType a, WallType b)
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;

                    return string.Compare(a.Name, b.Name, System.StringComparison.CurrentCultureIgnoreCase);
                });

                foreach (WallType tipo in tipos)
                {
                    if (tipo == null)
                        continue;

                    RoomMuroTipoItem item = new RoomMuroTipoItem();
                    item.Id = tipo.Id;
                    item.Nombre = tipo.Name;

                    _tiposMuro.Add(item);
                    cmbTipoMuro.Items.Add(item);
                }

                if (cmbTipoMuro.Items.Count > 0)
                    cmbTipoMuro.SelectedIndex = 0;
            }
            finally
            {
                _cargandoCombos = false;
            }
        }

        private void CargarNiveles()
        {
            try
            {
                _cargandoCombos = true;

                _niveles.Clear();
                cmbNivel.Items.Clear();

                List<Level> niveles = new List<Level>();

                FilteredElementCollector collector = new FilteredElementCollector(_doc);
                collector.OfClass(typeof(Level));

                foreach (Element elemento in collector)
                {
                    Level nivel = elemento as Level;

                    if (nivel == null)
                        continue;

                    niveles.Add(nivel);
                }

                niveles.Sort(delegate (Level a, Level b)
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;

                    return a.ProjectElevation.CompareTo(b.ProjectElevation);
                });

                foreach (Level nivel in niveles)
                {
                    if (nivel == null)
                        continue;

                    RoomMuroNivelItem item = new RoomMuroNivelItem();
                    item.Id = nivel.Id;
                    item.Nombre = nivel.Name + "  (cota interna: " + PiesAMetros(nivel.ProjectElevation).ToString("0.###") + " m)";
                    item.ElevacionFeet = nivel.ProjectElevation;

                    _niveles.Add(item);
                    cmbNivel.Items.Add(item);
                }

                if (cmbNivel.Items.Count > 0)
                    cmbNivel.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MostrarResultado("Error al cargar niveles: " + ex.Message);
            }
            finally
            {
                _cargandoCombos = false;
            }
        }

        public void SeleccionarNivelEnCombo(ElementId nivelId)
        {
            if (nivelId == null || nivelId == ElementId.InvalidElementId)
                return;

            RestaurarComboCompleto(cmbNivel, false);

            for (int i = 0; i < cmbNivel.Items.Count; i++)
            {
                RoomMuroNivelItem item = cmbNivel.Items[i] as RoomMuroNivelItem;

                if (item == null || item.Id == null)
                    continue;

                if (item.Id.Value == nivelId.Value)
                {
                    cmbNivel.SelectedIndex = i;
                    return;
                }
            }
        }

        private void SeleccionarTipoMuroEnCombo(ElementId tipoId)
        {
            if (tipoId == null || tipoId == ElementId.InvalidElementId)
                return;

            RestaurarComboCompleto(cmbTipoMuro, false);

            for (int i = 0; i < cmbTipoMuro.Items.Count; i++)
            {
                RoomMuroTipoItem item = cmbTipoMuro.Items[i] as RoomMuroTipoItem;

                if (item == null || item.Id == null)
                    continue;

                if (item.Id.Value == tipoId.Value)
                {
                    cmbTipoMuro.SelectedIndex = i;
                    return;
                }
            }
        }

        // =========================================================
        // ACTUALIZAR ROOMS Y RESULTADOS
        // =========================================================

        public void ActualizarRoomsSeleccionados(List<Room> rooms)
        {
            RoomsSeleccionadosIds = new List<ElementId>();

            if (rooms == null || rooms.Count == 0)
            {
                lblRoomSeleccionado.Text = "Rooms seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún Room válido.");
                return;
            }

            List<string> nombres = new List<string>();

            foreach (Room room in rooms)
            {
                if (room == null)
                    continue;

                bool yaExiste = false;

                foreach (ElementId idExistente in RoomsSeleccionadosIds)
                {
                    if (idExistente == null)
                        continue;

                    if (idExistente.Value == room.Id.Value)
                    {
                        yaExiste = true;
                        break;
                    }
                }

                if (!yaExiste)
                    RoomsSeleccionadosIds.Add(room.Id);

                nombres.Add(ObtenerNombreRoom(room));
            }

            string textoNombres = "";
            int maximo = Math.Min(6, nombres.Count);

            for (int i = 0; i < maximo; i++)
            {
                if (i > 0)
                    textoNombres += ", ";

                textoNombres += nombres[i];
            }

            if (nombres.Count > 6)
                textoNombres += " ...";

            lblRoomSeleccionado.Text =
                "Rooms seleccionados: " + RoomsSeleccionadosIds.Count.ToString() + "\r\n" +
                textoNombres;

            MostrarResultado("Rooms seleccionados: " + RoomsSeleccionadosIds.Count.ToString());
        }

        public void MostrarResultado(string texto)
        {
            _ultimoResultado = texto ?? "";

            if (lblResultado == null)
                return;

            lblResultado.Text = _ultimoResultado;
            lblResultado.Visible = true;

            if (string.IsNullOrWhiteSpace(_ultimoResultado))
                return;

            if (_ultimoResultado.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase))
            {
                lblResultado.ForeColor = Drawing.Color.FromArgb(190, 40, 40);
            }
            else
            {
                lblResultado.ForeColor = Drawing.Color.FromArgb(70, 70, 70);
            }
        }

        public void OcultarTemporalmenteParaSeleccion()
        {
            try
            {
                this.Hide();
            }
            catch
            {
            }
        }

        public void MostrarLuegoDeSeleccion()
        {
            try
            {
                if (!this.IsDisposed)
                {
                    this.Show();
                    this.Activate();
                    this.TopMost = true;
                }
            }
            catch
            {
            }
        }

        private string ObtenerNombreRoom(Room room)
        {
            if (room == null)
                return "Room";

            string numero = "";
            string nombre = "";

            try
            {
                numero = room.Number;
            }
            catch
            {
            }

            try
            {
                nombre = room.Name;
            }
            catch
            {
            }

            if (!string.IsNullOrWhiteSpace(numero) && !string.IsNullOrWhiteSpace(nombre))
                return numero + " - " + nombre;

            if (!string.IsNullOrWhiteSpace(nombre))
                return nombre;

            if (!string.IsNullOrWhiteSpace(numero))
                return numero;

            return "Room " + room.Id.Value.ToString();
        }

        private double PiesAMetros(double pies)
        {
            return pies * 0.3048;
        }

        // =========================================================
        // CLASES INTERNAS
        // =========================================================

        private class RoomMuroTipoItem
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        private class RoomMuroNivelItem
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }
            public double ElevacionFeet { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }
    }

}
