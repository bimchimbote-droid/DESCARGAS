using Autodesk.Revit.DB;
using System.Reflection;
partial class Handler
{
    static double F(double meters)=>meters/.3048;
    static void True(bool condition,string message){if(!condition)throw new Exception(message);}
    static void Equal(int actual,int expected,string message){if(actual!=expected)throw new Exception(message+": expected "+expected+", actual "+actual);}
    static void Near(double actual,double expected,string label,double tolerance=1e-10)
    {if(double.IsNaN(actual)||double.IsInfinity(actual)||Math.Abs(actual-expected)>tolerance)throw new Exception(label+": expected "+expected+", actual "+actual);}
    static void Rejected(Action action,string label){bool rejected=false;try{action();}catch(ArgumentException){rejected=true;}True(rejected,label);}
    void OffsetThin()
    {
        double center=CalcularDesplazamientoCentroConOffset(F(.01),F(.015));
        Near((center-F(.01)*.5)*.3048,-.015,"backface at exterior input");Near((center+F(.01)*.5)*.3048,-.005,"front remains exterior for thinner wall");
    }
    void OffsetEqual()
    {
        double center=CalcularDesplazamientoCentroConOffset(F(.015),F(.015));
        Near((center+F(.015)*.5)*.3048,0,"equal thickness finishes on Room boundary");
    }
    void OffsetThick()
    {
        double center=CalcularDesplazamientoCentroConOffset(F(.02),F(.015));
        Near((center-F(.02)*.5)*.3048,-.015,"thick wall still starts at exterior input");
        Near((center+F(.02)*.5)*.3048,.005,"thick wall intentionally grows inward beyond Room boundary");
    }
    void ZeroOffset()
    {
        double center=CalcularDesplazamientoCentroConOffset(F(.01),0);
        Near(center-F(.01)*.5,0,"zero offset starts on boundary");Near((center+F(.01)*.5)*.3048,.01,"zero offset grows inward full width");
    }
    void OffsetSignsAndScales()
    {
        foreach(double width in new[]{.005,.01,.015,.02,.05})foreach(double offset in new[]{0,.005,.015,.04})
        {
            double center=CalcularDesplazamientoCentroConOffset(F(width),F(offset));
            Near((center-F(width)*.5)*.3048,-offset,"backface independent of thickness");Near((center+F(width)*.5)*.3048,width-offset,"front measured from shifted exterior face");
        }
    }
    void RotatedOffset()
    {
        double center=CalcularDesplazamientoCentroConOffset(F(.02),F(.015));
        foreach(var n in new[]{new XYZ(1,0,0),new XYZ(0,-1,0),new XYZ(Math.Sqrt(.5),Math.Sqrt(.5),0)})
        {
            var boundary=new XYZ(F(7),F(-3),F(.215));var axis=boundary+n.Multiply(center);
            Near((axis-boundary).DotProduct(n),center,"offset follows local inside normal");Near(axis.Z,boundary.Z,"horizontal offset never changes picked base height");
        }
    }
    void InvalidOffsets()
    {
        foreach(double value in new[]{double.NaN,double.PositiveInfinity,double.NegativeInfinity})
        {
            Rejected(()=>CalcularDesplazamientoCentroConOffset(value,F(.015)),"nonfinite width rejected");Rejected(()=>CalcularDesplazamientoCentroConOffset(F(.01),value),"nonfinite offset rejected");
        }
        Rejected(()=>CalcularDesplazamientoCentroConOffset(0,F(.015)),"zero width rejected");Rejected(()=>CalcularDesplazamientoCentroConOffset(-1,F(.015)),"negative width rejected");Rejected(()=>CalcularDesplazamientoCentroConOffset(F(.01),-F(.001)),"negative exterior offset rejected");
    }
    void InputCommaAndPoint()
    {
        Near(new OffsetFormProbe("0.015").OffsetExteriorMetros,.015,"decimal point parsed in meters");Near(new OffsetFormProbe("0,015").OffsetExteriorMetros,.015,"decimal comma parsed in meters");Near(new OffsetFormProbe("  0,015  ").OffsetExteriorMetros,.015,"whitespace accepted");
    }
    void InvalidInputText()
    {
        foreach(string text in new[]{null,"","  ","abc","0.015 m"})True(double.IsNaN(new OffsetFormProbe(text).OffsetExteriorMetros),"invalid numeric text must not silently become zero");
        True(double.IsNaN(new OffsetFormProbe("0.015",false).OffsetExteriorMetros),"unavailable control rejected");
    }
    void NegativeInputRemainsInvalid()
    {
        double input=new OffsetFormProbe("-0.001").OffsetExteriorMetros;True(input<0,"negative input not silently clamped");Rejected(()=>CalcularDesplazamientoCentroConOffset(F(.01),F(input)),"negative parsed offset rejected by production math");
    }
    static BoundingBoxXYZ Box(double z=10)=>new(){Min=new XYZ(0,0,z),Max=new XYZ(5,5,z+.2)};
    static (Document doc,Wall nuevo,Wall viejo) Model(long oldId=2)
    {
        var doc=new Document();var nuevo=new Wall{Id=new ElementId(100),Box=Box()};var viejo=new Wall{Id=new ElementId(oldId),Box=Box()};doc.Elements.AddRange(new Element[]{nuevo,viejo});return(doc,nuevo,viejo);
    }
    static bool NewCuts(Document doc,Wall nuevo,Wall viejo)=>doc.Joins.TryGetValue(new(nuevo.Id.Value,viejo.Id.Value),out var state)&&state.Joined&&state.NewCuts;
    (int count,int failed,List<string> log) Execute(Document doc,Wall nuevo,HashSet<long> existing=null,ElementId phase=null)
    {
        var method=typeof(Handler).GetMethod("CortarMurosExistentesConNuevo",BindingFlags.Instance|BindingFlags.NonPublic);
        var parameters=method.GetParameters();var args=new object[parameters.Length];var log=new List<string>();object confirmed=null;
        for(int i=0;i<parameters.Length;i++)
        {
            var t=parameters[i].ParameterType;
            if(t==typeof(Document))args[i]=doc;
            else if(t==typeof(Wall))args[i]=nuevo;
            else if(t==typeof(HashSet<long>))args[i]=existing??new HashSet<long>(doc.Elements.OfType<Wall>().Where(x=>x.Id!=nuevo.Id).Select(x=>x.Id.Value));
            else if(t==typeof(ElementId))args[i]=phase??new ElementId(11);
            else if(t==typeof(List<string>))args[i]=log;
            else if(t==typeof(int).MakeByRefType())args[i]=0;
            else if(t.IsGenericType&&t.GetGenericTypeDefinition()==typeof(List<>)){args[i]=Activator.CreateInstance(t);confirmed=args[i];}
            else throw new Exception("Unknown production parameter "+parameters[i]);
        }
        try
        {
            object value=method.Invoke(this,args);int failed=0;
            for(int i=0;i<parameters.Length;i++)if(parameters[i].ParameterType==typeof(int).MakeByRefType())failed+=(int)args[i];
            int count=value is int x?x:confirmed is not null?(int)confirmed.GetType().GetProperty("Count").GetValue(confirmed):0;
            return(count,failed,log);
        }
        catch(TargetInvocationException e){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(e.InnerException).Throw();throw;}
    }
    void NewPriority()
    {
        var(doc,nuevo,viejo)=Model();var r=Execute(doc,nuevo);True(NewCuts(doc,nuevo,viejo),"new wall final cutter");True(doc.Calls.Contains("join:2")&&doc.Calls.Contains("switch:2"),"native join and order switch invoked");True(r.count>0,"only verified native cut counted");True(doc.RegenerationCount>=3,"geometry regenerated before queries");
    }
    void AlreadyWrongOrder()
    {
        var(doc,nuevo,viejo)=Model();doc.Joins[new(100,2)]=new(true,false);var r=Execute(doc,nuevo);True(NewCuts(doc,nuevo,viejo),"existing join corrected");True(!doc.Calls.Contains("join:2"),"existing join not recreated");True(r.count>0,"corrected join counted");
    }
    void AlreadyCorrectOrder()
    {
        var(doc,nuevo,viejo)=Model();doc.Joins[new(100,2)]=new(true,true);var r=Execute(doc,nuevo);True(NewCuts(doc,nuevo,viejo),"new-priority join preserved");True(!doc.Calls.Contains("switch:2"),"correct join not inverted");True(r.count>0,"already correct join verified");
    }
    void AllExistingNotNewIds()
    {
        var(doc,nuevo,viejo)=Model();var anotherOld=new Wall{Id=new ElementId(3),Box=Box(),DefaultNewCutter=true};var anotherNew=new Wall{Id=new ElementId(101),Box=Box()};doc.Elements.AddRange(new Element[]{anotherOld,anotherNew});var r=Execute(doc,nuevo,new(){2,3});
        True(NewCuts(doc,nuevo,viejo)&&NewCuts(doc,nuevo,anotherOld),"all eligible existing walls cut");True(!doc.Calls.Contains("join:101"),"new walls excluded from existing-wall cut pass");
    }
    void PreserveOldEnvelope()
    {
        var(doc,nuevo,viejo)=Model();viejo.Box=new(){Min=new XYZ(0,0,9),Max=new XYZ(5,5,13)};var oldBox=viejo.Box;Execute(doc,nuevo);
        True(ReferenceEquals(viejo,doc.GetElement(viejo.Id)),"old wall ID retained");True(ReferenceEquals(oldBox,viejo.Box),"old wall envelope/upper part not physically resized by orchestration");Near(viejo.Box.Max.Z,13,"upper height unchanged");
    }
    void WrongPhaseSkipped()
    {
        var(doc,nuevo,viejo)=Model();viejo.PhaseStatus=ElementOnPhaseStatus.Demolished;var r=Execute(doc,nuevo);True(!doc.Calls.Contains("join:2"),"wall absent in Room phase skipped");Equal(r.count,0,"absent phase not counted");
    }
    void WrongOptionSkipped()
    {
        var(doc,nuevo,viejo)=Model();viejo.DesignOption=new(){Id=new ElementId(22)};var r=Execute(doc,nuevo);True(!doc.Calls.Contains("join:2"),"alternate design option skipped");Equal(r.count,0,"other option not counted");
    }
    void ExactSolidFilter()
    {
        var(doc,nuevo,viejo)=Model();doc.UseExactIntersections=true;var actual=new Wall{Id=new ElementId(3),Box=Box()};doc.Elements.Add(actual);doc.ExactIntersections.Add(new(100,3));var r=Execute(doc,nuevo);
        True(!doc.Calls.Contains("join:2"),"bbox-only false positive skipped");True(NewCuts(doc,nuevo,actual),"positive solid intersection reaches native join");
    }
    void RejectedPairContinues()
    {
        var(doc,nuevo,viejo)=Model();viejo.JoinAccept=false;var next=new Wall{Id=new ElementId(3),Box=Box(),DefaultNewCutter=true};doc.Elements.Add(next);var r=Execute(doc,nuevo);True(!doc.Joins.ContainsKey(new(100,2)),"rejected native join leaves no relation");True(NewCuts(doc,nuevo,next),"other intersecting wall continues");True(r.log.Any(x=>x.Contains("2")),"rejected wall ID reported");
    }
    void SwitchFailure()
    {
        var(doc,nuevo,viejo)=Model();viejo.SwitchThrows=true;var r=Execute(doc,nuevo);True(!doc.Joins.ContainsKey(new(100,2)),"failed order change rolls back new relation");Equal(r.count,0,"failed order never counted");
    }
    void SilentSwitchFailure()
    {
        var(doc,nuevo,viejo)=Model();viejo.SwitchSilent=true;var r=Execute(doc,nuevo);True(!doc.Joins.ContainsKey(new(100,2)),"no-op order change detected and rolled back");Equal(r.count,0,"silent wrong order never successful");
    }
    void ActualHeightFilter()
    {
        var(doc,nuevo,viejo)=Model();var higher=new Wall{Id=new ElementId(3),Box=Box(14)};doc.Elements.Add(higher);Execute(doc,nuevo);True(!doc.Calls.Contains("join:3"),"wall at other height excluded");True(doc.LastFilterBox.MinimumPoint.Z>9.9&&doc.LastFilterBox.MaximumPoint.Z<10.3,"actual created-wall height used");
    }
    void FatalRegeneration()
    {
        var(doc,nuevo,viejo)=Model();doc.ThrowOnRegenerate=true;bool thrown=false;try{Execute(doc,nuevo);}catch(Autodesk.Revit.Exceptions.RegenerationFailedException){thrown=true;}True(thrown,"fatal regeneration propagates instead of committing unverified cut");
    }
    void ExistingJoinOutsideBox()
    {
        var(doc,nuevo,viejo)=Model();viejo.Box=Box(15);doc.Joins[new(100,2)]=new(true,false);var r=Execute(doc,nuevo);
        True(NewCuts(doc,nuevo,viejo),"existing relation still corrected outside current solid bbox");True(r.count>0,"existing relation verified despite no remaining solid intersection");
    }
    void MultipleSolidsDeduplicate()
    {
        var(doc,nuevo,viejo)=Model();var one=new Solid{Box=nuevo.Box,OwnerId=nuevo.Id.Value};var two=new Solid{Box=nuevo.Box,OwnerId=nuevo.Id.Value};
        nuevo.Geometry=new GeometryElement{one,new GeometryInstance{Geometry=new GeometryElement{two}}};var r=Execute(doc,nuevo);
        Equal(doc.Calls.Count(x=>x=="join:2"),1,"multiple solids/instances never duplicate native pair operation");Equal(r.count,1,"unique old-new pair counted once");
    }
    void MissingGeometryFails()
    {
        var(doc,nuevo,viejo)=Model();nuevo.Geometry=new();bool failed=false;try{Execute(doc,nuevo);}catch(InvalidOperationException){failed=true;}
        True(failed,"missing geometry cannot silently pass cut readiness");True(!doc.Calls.Contains("join:2"),"no joins made on unverifiable geometry");
    }
    void FinalPriorityVerification()
    {
        var(doc,nuevo,viejo)=Model();Execute(doc,nuevo);doc.Joins[new(100,2)]=new(true,false);bool failed=false;
        try{VerificarPrioridadSobreUnionesExistentes(doc,nuevo,new(){2},new ElementId(11));}catch(InvalidOperationException){failed=true;}
        True(failed,"final guard detects order changed after a previously successful pair");
    }
    void ExistingWrongOrderCannotCommitAsSuccess()
    {
        var(doc,nuevo,viejo)=Model();doc.Joins[new(100,2)]=new(true,false);viejo.SwitchThrows=true;bool rejected=false;
        try{Execute(doc,nuevo);}catch(InvalidOperationException){rejected=true;}
        True(rejected,"batch cannot proceed when existing old-priority join cannot be repaired");
        True(doc.Joins[new(100,2)].Joined&&!doc.Joins[new(100,2)].NewCuts,"rollback preserves original relationship instead of deleting model data");
    }
    void RestoreBeforeGeometryQuery()
    {
        var(doc,nuevo,viejo)=Model();nuevo.OwnerDocument=doc;nuevo.HideGeometryWhileOldCuts=true;doc.Joins[new(100,2)]=new(true,false);var r=Execute(doc,nuevo);
        True(NewCuts(doc,nuevo,viejo),"old automatic cut reversed even if new geometry initially absent");True(r.count>0,"restored new geometry then reaches cut verification");
        int flip=doc.Calls.IndexOf("switch:2");int box=doc.Calls.IndexOf("bbox:100");int geo=doc.Calls.IndexOf("geometry:100");
        True(flip>=0&&box>flip&&geo>flip,"priority repaired before bbox/solid collection");
    }
    static void Main()
    {
        var h=new Handler();var tests=new (string,Action)[]{
            ("15mm exterior start and thin inward growth",h.OffsetThin),("equal thickness reaches Room boundary",h.OffsetEqual),("thicker wall intentionally grows into Room",h.OffsetThick),("zero exterior offset",h.ZeroOffset),("20 thickness/offset pairs",h.OffsetSignsAndScales),("rotated local normal and unchanged base Z",h.RotatedOffset),("invalid inputs rejected",h.InvalidOffsets),
            ("new wall cuts old",h.NewPriority),("existing wrong join order corrected",h.AlreadyWrongOrder),("existing correct join order retained",h.AlreadyCorrectOrder),("all old IDs cut but newly created IDs excluded",h.AllExistingNotNewIds),("old ID and upper envelope retained",h.PreserveOldEnvelope),("other phase skipped",h.WrongPhaseSkipped),("other design option skipped",h.WrongOptionSkipped),("solid intersection rather than bbox alone",h.ExactSolidFilter),("native rejection isolated and next pair continues",h.RejectedPairContinues),("failed order switch rolls back",h.SwitchFailure),("silent wrong order rejected",h.SilentSwitchFailure),("actual created height filters walls",h.ActualHeightFilter),("fatal regeneration propagates",h.FatalRegeneration),("existing join checked outside current bbox",h.ExistingJoinOutsideBox),("multiple solids and instances deduplicate",h.MultipleSolidsDeduplicate),("missing geometry fails before native cut",h.MissingGeometryFails),("final priority guard detects later reversal",h.FinalPriorityVerification),("preexisting unrepairable order aborts before geometry",h.ExistingWrongOrderCannotCommitAsSuccess),("automatic old cut repaired before geometry query",h.RestoreBeforeGeometryQuery),("offset input accepts comma and point",h.InputCommaAndPoint),("invalid offset text remains invalid",h.InvalidInputText),("negative numeric input rejected rather than clamped",h.NegativeInputRemainsInvalid)};
        foreach(var t in tests){t.Item2();Console.WriteLine("PASS "+t.Item1);}Console.WriteLine($"{tests.Length} passed; 0 failed. Deterministic doubles/math only; no Revit integration executed.");
    }
}

partial class OffsetFormProbe
{
    private sealed class TextBoxDouble { public string Text; }
    private TextBoxDouble txtOffsetExteriorMetros;
    public OffsetFormProbe(string text,bool control=true){txtOffsetExteriorMetros=control?new TextBoxDouble{Text=text}:null;}
}
