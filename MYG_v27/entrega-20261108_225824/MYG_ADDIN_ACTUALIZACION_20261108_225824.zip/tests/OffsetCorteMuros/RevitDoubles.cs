// Deterministic orchestration doubles. They do not implement Autodesk Revit geometry.
namespace Autodesk.Revit.Exceptions
{
    public class RegenerationFailedException : System.Exception { public RegenerationFailedException(string message):base(message){} }
}
namespace Autodesk.Revit.DB
{
    public class ElementId
    {
        public long Value {get;} public ElementId(long value){Value=value;}
        public static ElementId InvalidElementId=new(-1);
        public override bool Equals(object value)=>value is ElementId id&&id.Value==Value;
        public override int GetHashCode()=>Value.GetHashCode();
        public static bool operator==(ElementId a,ElementId b)=>ReferenceEquals(a,b)||(a is not null&&b is not null&&a.Value==b.Value);
        public static bool operator!=(ElementId a,ElementId b)=>!(a==b);
    }
    public class XYZ
    {
        public double X{get;}public double Y{get;}public double Z{get;}
        public XYZ(double x,double y,double z){X=x;Y=y;Z=z;}
        public static XYZ Zero=>new(0,0,0);
        public static XYZ BasisZ=>new(0,0,1);
        public static XYZ operator+(XYZ a,XYZ b)=>new(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static XYZ operator-(XYZ a,XYZ b)=>new(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public XYZ Multiply(double value)=>new(X*value,Y*value,Z*value);
        public double DotProduct(XYZ other)=>X*other.X+Y*other.Y+Z*other.Z;
        public double GetLength()=>Math.Sqrt(DotProduct(this));
        public XYZ Normalize()=>Multiply(1/GetLength());
    }
    public class BoundingBoxXYZ { public XYZ Min{get;set;}public XYZ Max{get;set;} }
    public class Outline:System.IDisposable
    {
        public XYZ MinimumPoint{get;}public XYZ MaximumPoint{get;}
        public Outline(XYZ min,XYZ max){MinimumPoint=min;MaximumPoint=max;}
        public void Dispose(){}
    }
    public abstract class ElementFilter:System.IDisposable
    {
        public abstract bool PassesFilter(Document doc,ElementId id);
        public void Dispose(){}
    }
    public class BoundingBoxIntersectsFilter:ElementFilter
    {
        readonly Outline box;
        public BoundingBoxIntersectsFilter(Outline outline){box=outline;}
        public override bool PassesFilter(Document doc,ElementId id)
        {
            var b=doc.GetElement(id).Box; doc.LastFilterBox=box;
            return b is not null&&b.Min.X<=box.MaximumPoint.X&&b.Max.X>=box.MinimumPoint.X&&b.Min.Y<=box.MaximumPoint.Y&&b.Max.Y>=box.MinimumPoint.Y&&b.Min.Z<=box.MaximumPoint.Z&&b.Max.Z>=box.MinimumPoint.Z;
        }
    }
    public class ElementIntersectsSolidFilter:ElementFilter
    {
        readonly Solid solid;
        public ElementIntersectsSolidFilter(Solid s){solid=s;}
        public override bool PassesFilter(Document doc,ElementId id)
        {
            if(doc.UseExactIntersections)return doc.ExactIntersections.Contains(new(solid.OwnerId,id.Value));
            var a=solid.Box;var b=doc.GetElement(id).Box;
            return a is not null&&b is not null&&a.Min.X<b.Max.X&&a.Max.X>b.Min.X&&a.Min.Y<b.Max.Y&&a.Max.Y>b.Min.Y&&a.Min.Z<b.Max.Z&&a.Max.Z>b.Min.Z;
        }
    }
    public class GeometryObject{}
    public class FaceArray {public int Size{get;set;}=6;}
    public class Solid:GeometryObject { public double Volume{get;set;}=1;public FaceArray Faces{get;set;}=new();public BoundingBoxXYZ Box;public long OwnerId; }
    public class GeometryElement:List<GeometryObject>{}
    public class GeometryInstance:GeometryObject { public GeometryElement Geometry=new();public GeometryElement GetInstanceGeometry()=>Geometry; }
    public enum ViewDetailLevel {Fine}
    public class Options {public bool ComputeReferences{get;set;}public bool IncludeNonVisibleObjects{get;set;}public ViewDetailLevel DetailLevel{get;set;} }
    public enum ElementOnPhaseStatus {None,Existing,New,Demolished,Temporary}
    public class Element
    {
        public ElementId Id{get;set;}
        public BoundingBoxXYZ Box{get;set;}
        public DesignOption DesignOption{get;set;}
        public bool IsValidObject{get;set;}=true;
        public ElementOnPhaseStatus PhaseStatus{get;set;}=ElementOnPhaseStatus.Existing;
        public virtual BoundingBoxXYZ get_BoundingBox(object view)=>Box;
        public ElementOnPhaseStatus GetPhaseStatus(ElementId phaseId){if(phaseId is null||phaseId==ElementId.InvalidElementId)throw new ArgumentException("Invalid phase");return PhaseStatus;}
    }
    public class DesignOption:Element{}
    public class Phase:Element{}
    public class Wall:Element
    {
        public bool JoinAccept=true;
        public bool DefaultNewCutter=false;
        public bool SwitchThrows=false;
        public bool SwitchSilent=false;
        public GeometryElement Geometry;
        public Document OwnerDocument;
        public bool HideGeometryWhileOldCuts;
        bool Hidden=>HideGeometryWhileOldCuts&&OwnerDocument is not null&&OwnerDocument.Joins.Any(x=>x.Key.NewId==Id.Value&&x.Value.Joined&&!x.Value.NewCuts);
        public override BoundingBoxXYZ get_BoundingBox(object view)
        {
            OwnerDocument?.Calls.Add("bbox:"+Id.Value);return Hidden?null:Box;
        }
        public virtual GeometryElement get_Geometry(Options options)
        {
            OwnerDocument?.Calls.Add("geometry:"+Id.Value);
            return Hidden?new GeometryElement():Geometry??new GeometryElement{new Solid{Box=Box,OwnerId=Id.Value}};
        }
    }
    public readonly record struct Pair(long NewId,long OldId);
    public readonly record struct JoinState(bool Joined,bool NewCuts);
    public class Document
    {
        public List<Element> Elements=new();
        public Dictionary<Pair,JoinState> Joins=new();
        public Dictionary<Pair,JoinState> Pending=new();
        public List<string> Calls=new();
        public Outline LastFilterBox;
        public int RegenerationCount;
        public bool ThrowOnRegenerate;
        public bool UseExactIntersections;
        public HashSet<Pair> ExactIntersections=new();
        public Element GetElement(ElementId id)=>Elements.FirstOrDefault(x=>x.Id==id);
        public void Regenerate()
        {
            Calls.Add("regenerate");RegenerationCount++;
            if(ThrowOnRegenerate)throw new Autodesk.Revit.Exceptions.RegenerationFailedException("regeneration failed");
            foreach(var pair in Pending)Joins[pair.Key]=pair.Value;
            Pending.Clear();
        }
    }
    public class FilteredElementCollector:IEnumerable<Element>
    {
        readonly Document doc;IEnumerable<Element> query;
        public FilteredElementCollector(Document document){doc=document;query=document.Elements;}
        public FilteredElementCollector OfClass(Type t){query=query.Where(x=>t.IsAssignableFrom(x.GetType()));return this;}
        public FilteredElementCollector WhereElementIsNotElementType()=>this;
        public FilteredElementCollector WherePasses(ElementFilter filter){query=query.Where(x=>filter.PassesFilter(doc,x.Id));return this;}
        public ICollection<ElementId> ToElementIds()=>query.Select(x=>x.Id).ToList();
        public IEnumerator<Element> GetEnumerator()=>query.GetEnumerator();
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()=>GetEnumerator();
    }
    public enum TransactionStatus{Uninitialized,Started,Committed,RolledBack}
    public class SubTransaction:System.IDisposable
    {
        readonly Document doc;Dictionary<Pair,JoinState> savedJoins,savedPending;TransactionStatus status;
        public SubTransaction(Document document){doc=document;}
        public TransactionStatus Start(){savedJoins=new(doc.Joins);savedPending=new(doc.Pending);status=TransactionStatus.Started;doc.Calls.Add("start");return status;}
        public TransactionStatus GetStatus()=>status;
        public TransactionStatus Commit(){status=TransactionStatus.Committed;doc.Calls.Add("commit");return status;}
        public TransactionStatus RollBack(){doc.Joins=new(savedJoins);doc.Pending=new(savedPending);status=TransactionStatus.RolledBack;doc.Calls.Add("rollback");return status;}
        public void Dispose(){if(status==TransactionStatus.Started)RollBack();}
    }
    public static class JoinGeometryUtils
    {
        static Pair Key(Element nuevo,Element viejo)=>new(nuevo.Id.Value,viejo.Id.Value);
        public static bool AreElementsJoined(Document doc,Element nuevo,Element viejo)=>doc.Joins.TryGetValue(Key(nuevo,viejo),out var state)&&state.Joined;
        public static ICollection<ElementId> GetJoinedElements(Document doc,Element nuevo)=>doc.Joins.Where(x=>x.Key.NewId==nuevo.Id.Value&&x.Value.Joined).Select(x=>new ElementId(x.Key.OldId)).ToList();
        public static void JoinGeometry(Document doc,Element nuevo,Element viejo)
        {
            doc.Calls.Add("join:"+viejo.Id.Value);var w=(Wall)viejo;
            if(!w.JoinAccept)throw new InvalidOperationException("Native join rejected this pair");
            doc.Pending[Key(nuevo,viejo)]=new(true,w.DefaultNewCutter);
        }
        public static bool IsCuttingElementInJoin(Document doc,Element nuevo,Element viejo)
        {
            doc.Calls.Add("is-cutting:"+viejo.Id.Value);
            if(!AreElementsJoined(doc,nuevo,viejo))throw new InvalidOperationException("Query requires regenerated join");
            return doc.Joins[Key(nuevo,viejo)].NewCuts;
        }
        public static void SwitchJoinOrder(Document doc,Element nuevo,Element viejo)
        {
            doc.Calls.Add("switch:"+viejo.Id.Value);var w=(Wall)viejo;
            if(w.SwitchThrows)throw new InvalidOperationException("Switch order rejected");
            if(!AreElementsJoined(doc,nuevo,viejo))throw new InvalidOperationException("Switch requires regenerated join");
            if(!w.SwitchSilent)doc.Pending[Key(nuevo,viejo)]=new(true,!doc.Joins[Key(nuevo,viejo)].NewCuts);
        }
    }
}
