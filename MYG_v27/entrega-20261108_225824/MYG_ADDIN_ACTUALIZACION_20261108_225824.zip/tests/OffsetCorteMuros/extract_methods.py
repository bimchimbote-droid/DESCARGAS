#!/usr/bin/env python3
"""Extract production implementations at run time, never keep manual copies."""
from pathlib import Path
import hashlib,re,sys
source_path=Path(sys.argv[1]).resolve()
source=source_path.read_text(encoding='utf-8-sig')
names=['CalcularDesplazamientoCentroConOffset','CortarMurosExistentesConNuevo','RestaurarPrioridadDelNuevoEnUnionesPrevias','EsMuroExistenteAplicableAlCorte','AgregarSolidosParaCorte','VerificarCorteMuroNuevo','VerificarPrioridadSobreUnionesExistentes','MetrosAPies']
methods=[]
for name in names:
    match=re.search(r'^    private[^\n]*\b'+re.escape(name)+r'\s*\(',source,re.M)
    if not match:raise SystemExit('Production method not found: '+name)
    end=re.search(r'^    }\s*$',source[match.start():],re.M)
    if not end:raise SystemExit('Closing brace not found: '+name)
    methods.append(source[match.start():match.start()+end.end()])
for name in ['ParCorteMuroOffsetMYG']:
    match=re.search(r'^    private class '+re.escape(name)+r'\b',source,re.M)
    if not match:raise SystemExit('Production DTO not found: '+name)
    end=re.search(r'^    }\s*$',source[match.start():],re.M)
    if not end:raise SystemExit('Closing brace not found: '+name)
    methods.append(source[match.start():match.start()+end.end()])
form_path=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else source_path.with_name('CrearMuroDesdeRoomForm.cs')
form=form_path.read_text(encoding='utf-8-sig')
match=re.search(r'^        public double OffsetExteriorMetros\s*$',form,re.M)
if not match:raise SystemExit('Production property not found: OffsetExteriorMetros')
end=re.search(r'^        }\s*$',form[match.start():],re.M)
if not end:raise SystemExit('Closing brace not found: OffsetExteriorMetros')
property_source=form[match.start():match.start()+end.end()]
output=Path(__file__).parent/'GeneratedHandler.cs'  
output.write_text('// Generated from actual source; do not edit.\n// SHA256 '+hashlib.sha256(source_path.read_bytes()).hexdigest()+'\nusing Autodesk.Revit.DB;\nusing System;\nusing System.Collections.Generic;\nusing System.Linq;\npartial class Handler\n{\n'+'\n\n'.join(methods)+'\n}\n// Form SHA256 '+hashlib.sha256(form_path.read_bytes()).hexdigest()+'\npartial class OffsetFormProbe {\n'+property_source+'\n}\n')
print('Extracted 8 actual methods, pair DTO and offset input property from final sources')
