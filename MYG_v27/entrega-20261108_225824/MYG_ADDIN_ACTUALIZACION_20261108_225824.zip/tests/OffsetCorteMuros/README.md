# Regresión de offset exterior y corte con prioridad del muro nuevo

Estas pruebas extraen **ocho métodos reales y el DTO de parejas de corte del handler final**, además de la propiedad real `OffsetExteriorMetros` del formulario. No mantienen copias manuales de las implementaciones.

Requisitos: SDK .NET 8 y Python 3. Si se entrega esta carpeta dentro de `tests/OffsetCorteMuros`, desde la raíz extraída:

```bash
bash tests/OffsetCorteMuros/run.sh
```

El ejecutor encuentra ambas fuentes en `MYG/Funcionalidades/Arquitectura/Habitaciones/`. También puede indicar el handler explícitamente:

```bash
DOTNET_CMD=/ruta/dotnet bash run.sh /ruta/MUROSDEROOM_EJECUTAR_HANDLER.cs
```

El formulario se busca junto al handler. Como segundo argumento opcional puede indicar su ruta. `extract_methods.py` registra los hashes de ambas fuentes en el archivo generado. No agregue este proyecto ni sus dobles al add-in.

Resultado observado: **29 escenarios aprobados, 0 fallidos**, incluidos 20 pares de espesor/offset.

Las expectativas geométricas se expresan como dimensiones físicas, no como una copia del algoritmo: con offset exterior 0.015 m y espesor nuevo 0.010 m, la cara de inicio está a -0.015 m y la cara final a -0.005 m respecto al contorno; con espesor 0.020 m, la cara final está a +0.005 m hacia dentro del Room. El espesor crece hacia el Room desde la cara desplazada. Se cubren offset0, normales giradas y conservación de la cota Z, entrada con punto/coma, dimensiones inválidas y valores no finitos.

La parte de orquestación verifica unión nativa, inversión de orden, corrección de uniones anteriores, todos los IDs existentes frente a IDs recién creados, fase/opción de diseño, filtrado por sólidos frente a falsos positivos de cajas, aislamiento de rechazos, rollback, propagación de errores de regeneración y verificación final del orden. Los dobles solo hacen visibles los cambios de unión después de `Regenerate`, para detectar consultas prematuras.

Una regresión específica simula una unión automática en la que el muro antiguo deja al nuevo sin caja ni sólido visible. El método debe invertir el orden **antes** de consultar la geometría nueva. Otra comprueba que un orden previo que no puede repararse impide continuar como si el nuevo fuera cortante.

**Límites:** las clases de documento, filtros, sólidos, controles y transacciones son dobles deterministas. No implementan geometría de Autodesk ni prueban la aceptación real de JoinGeometry, la selección interactiva, la interfaz WinForms o el corte físico. Comprobar que el ID y rango superior del antiguo no se redimensionan en la orquestación no equivale a medir el volumen real conservado en Revit. La posición, el contacto, el corte y las uniones tras el commit deben validarse con el modelo real en Windows/Revit.

Solo entregar estos seis archivos fuente/documentación: `Regression.csproj`, `RevitDoubles.cs`, `Program.cs`, `extract_methods.py`, `run.sh`, `README.md`. Excluir `GeneratedHandler.cs`, `bin/` y `obj/`: se regeneran al ejecutar.
