# Compilación aislada de las dos fuentes con API real

El comprobador Roslyn permite compilar el handler y la ventana REALES, sin ejecutarlos. Usa DLL reales de RevitAPI/RevitAPIUI y referencias de plataforma/WinForms, que no se redistribuyen en la entrega.

Ejemplo con rutas propias:

```bash
dotnet run --project Check.csproj --configuration Release -- /ruta/MUROSDEROOM_EJECUTAR_HANDLER.cs /ruta/api-revit2027 /ruta/referencias-net10 /ruta/referencias-windows10 --form /ruta/CrearMuroDesdeRoomForm.cs
```

Se verificó con Revit_All_Main_Versions_API_x64 2027.0.0 (RevitAPI 27.0.4.0), Microsoft.NETCore.App.Ref 10.0.0 y Microsoft.WindowsDesktop.App.Ref 10.0.0, obtenidos mediante NuGet con TLS verificado. El ejecutor del comprobador utiliza SDK .NET 8. Las referencias deben corresponder a la versión de API elegida.

Con `--form`, se compilan las dos fuentes entregadas. Únicamente se declaran vacíos los namespaces de Office/EPPlus/Properties que el formulario importa pero no usa; no se simulan tipos ni métodos Revit/WinForms. Esto no comprueba Office/COM ni el proyecto completo de Visual Studio.

Sin `--form` se utiliza FormStub.txt como adaptador de ventana para verificar solamente el handler. `--phase-only` limita la compilación al resolvedor de fase. No agregue estos adaptadores o pruebas al add-in.

Resultado de la entrega: dos fuentes completas, cero errores semánticos y emisión correcta contra API2027 y referencias WinForms. El comprobador no carga Autodesk para ejecutar código nativo ni valida geometría, uniones, selección o interfaz en pantalla.
