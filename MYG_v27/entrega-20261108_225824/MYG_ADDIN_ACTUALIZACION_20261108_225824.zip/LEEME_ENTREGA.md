# Offset exterior manual y corte con prioridad del muro nuevo

## A. Comportamiento

Se añade el input **Offset exterior (m)**, valor inicial 0.015, activado con el checkbox **Aplicar offset y cortar muros existentes**. La opción comienza desmarcada. Apagada mantiene el flujo anterior de crear muros hacia dentro del Room y no aplica el offset escrito.

Activada, el contorno de creación se desplaza hacia fuera del Room la distancia indicada y, desde ahí, el espesor del tipo elegido crece hacia el Room. Es un desplazamiento HORIZONTAL, independiente de la base picada y la altura.

Convención local: distancia positiva = hacia dentro del Room. Con offset o y espesor e, cara inicial = -o, eje = e/2-o, cara final = e-o.

| Offset | Espesor del tipo nuevo | Cara inicial | Eje | Cara final |
| --- | --- | --- | --- | --- |
| 0.015 m | 0.010 m | -0.015 m | -0.010 m | -0.005 m |
| 0.015 m | 0.015 m | -0.015 m | -0.0075 m | 0.000 m |
| 0.015 m | 0.020 m | -0.015 m | -0.005 m | +0.005 m |

Por petición del usuario, si el tipo es más grueso que el offset, la cara final SÍ puede avanzar dentro del Room. Se sustituye así el control anterior que exigía que toda la sección quedara fuera. El offset acepta punto o coma; debe ser finito y mayor o igual que cero. Se conserva el espesor real del tipo, no se modifica el tipo para igualarlo al offset.

Se buscan **TODOS los muros existentes del documento actual que intersectan los sólidos del muro nuevo**, no solo los seleccionados ni los del mismo tipo. No hace falta picar muros existentes. La búsqueda usa caja 3D y filtro de sólidos reales, con fase aplicable del Room y opción de diseño compatible. Los muros recién creados se excluyen de la lista de antiguos.

Después de limpiar los encuentros entre muros nuevos se ejecuta Unir geometría con los antiguos y se cambia/verifica el orden para que **el NUEVO sea el cortante**. Si una unión automática antigua ya recortó al nuevo, se restaura su prioridad antes de consultar sólidos. Una pareja se contabiliza únicamente si está unida y se confirma que corta el nuevo. La prioridad y el offset se comprueban otra vez antes de confirmar el lote.

Este modo recorta mediante **unión geométrica**, no mediante borrar/copiar/dividir físicamente el elemento viejo. El muro antiguo conserva su ID, perfil y restricciones; pierde solo el volumen compartido que Revit permite cortar. La zona superior y lo que no se solapa se conservan. No se generan obligatoriamente muros superiores independientes. Si el nuevo no ocupa todo el espesor anterior, el material viejo que no se intersecta permanece.

## Base inspeccionada

Checkout bimchimbote-droid/MYG_v27_reestructurado, HEAD da11b13a3f5ce35b9565bf4d5bd27cb761091102, con las actualizaciones locales previas conservadas. El handler de entrada coincide con DESCARGAS commit 26c43db540c52dfa08e2539b29d03db756f3ceea, entrega MYG_ADDIN_ACTUALIZACION_20261108_222534.zip. La ventana de entrada coincide con la entrega de selección directa b73b24819ac63379733b07781a7ba454a9ef8ce5; el fix de fase anterior no cambiaba esa ventana. No se reemplazó el código actual por main de MYG_v27.

La herramienta de suelos se mantiene idéntica a su entrega anterior y queda fuera del ZIP. MANIFIESTO.json registra hashes original/final de las dos fuentes afectadas.

## B. Archivos

| Ruta exacta | Acción | Descripción |
| --- | --- | --- |
| MYG/Funcionalidades/Arquitectura/Habitaciones/CrearMuroDesdeRoomForm.cs | REEMPLAZAR | Checkbox/input y validación; alcance a todos los muros sin selección manual. |
| MYG/Funcionalidades/Arquitectura/Habitaciones/MUROSDEROOM_EJECUTAR_HANDLER.cs | REEMPLAZAR | Creación desplazada, búsqueda sólida y prioridad de corte nativa. |
| OFFSET_Y_CORTE_MUROS.patch | CREAR, alternativa | Parche de esas mismas fuentes; no aplicar además del reemplazo completo. |
| tests/OffsetCorteMuros/Regression.csproj | CREAR, prueba opcional | Ejecutable independiente .NET 8. |
| tests/OffsetCorteMuros/RevitDoubles.cs | CREAR, prueba opcional | Dobles de la API para probar decisiones. |
| tests/OffsetCorteMuros/Program.cs | CREAR, prueba opcional | 29 escenarios de regresión. |
| tests/OffsetCorteMuros/extract_methods.py | CREAR, prueba opcional | Extrae métodos reales y getter del input. |
| tests/OffsetCorteMuros/run.sh | CREAR, prueba opcional | Ejecutor de pruebas. |
| tests/OffsetCorteMuros/README.md | CREAR, documentación | Alcance y límites. |
| tests/OffsetCorteApi/Check.csproj | CREAR, prueba opcional | Comprobador semántico con DLL reales. |
| tests/OffsetCorteApi/Program.cs | CREAR, prueba opcional | Compila ambas fuentes o handler aislado. |
| tests/OffsetCorteApi/FormStub.txt | CREAR, prueba opcional | Adaptador de prueba opcional; no va en el add-in. |
| tests/OffsetCorteApi/README.md | CREAR, documentación | Referencias y ejecución de comprobación API. |
| LEEME_ENTREGA.md | CREAR, documentación | Este archivo. |
| MANIFIESTO.json | CREAR, documentación | Relación y hashes. |

SIN CAMBIOS y fuera del ZIP: comando, proyecto, paquetes, recursos, suelos y resto de las fuentes. No hay eliminaciones de archivos fuente ni DLL entregada.

## C/D. Instalación y uso

1. Respalde las dos fuentes y su instalación funcional. Compare antes de reemplazar: los archivos completos podrían sobrescribir modificaciones locales o posteriores.
2. Elija UN procedimiento: copie las dos fuentes completas sobre sus rutas, O desde la raíz aplique `git apply --check OFFSET_Y_CORTE_MUROS.patch` y después `git apply OFFSET_Y_CORTE_MUROS.patch`. Si no aplica limpiamente, integre con comparación de archivos; no fuerce ni pierda sus avances. No combine ambos procedimientos.
3. Las fuentes ya están incluidas en el csproj. No agregue los proyectos de pruebas ni sus adaptadores al add-in. Compile en Windows con sus referencias/COM reales. Cierre Revit al sustituir su DLL y pruebe en una copia del modelo.
4. Seleccione los Rooms, el tipo de muro/zócalo NUEVO, altura y base/nivel. Active **Aplicar offset y cortar muros existentes**. Introduzca **0.015** (o 0,015) en **Offset exterior (m)** y ejecute. El offset no cambia la base picada ni se suma a la altura.
5. No se seleccionan muros existentes: el alcance confirmado es todos los muros anteriores intersectantes del modelo actual. Revise el número de uniones confirmadas y cualquier mensaje CORTE NO CONFIRMADO con IDs.

## E. Configuración

Sin nuevas referencias, paquetes ni cambios de proyecto. Se conserva el resolvedor de fase corregido basado en ROOM_PHASE_ID. El tipo del muro nuevo debe ser Basic para este modo. No se modifican automáticamente los tipos ni sus espesores.

El comportamiento de recorte físico de la entrega anterior ya no se usa en este modo: no depende de identificar un tarrajeo por tipo ni de que su perfil sea rectangular para dividirlo. Las restricciones de la operación nativa de Revit siguen aplicando; no se usa un vacío ni se elimina el muro viejo como respaldo de una unión fallida.

## F. Validación ejecutada

- Dos fuentes COMPLETAS (handler y formulario) compiladas en el comprobador aislado con DLL reales de referencia RevitAPI/RevitAPIUI 2027 y referencias reales WinForms: **0 errores semánticos**, emisión correcta. Solo se declararon vacíos namespaces importados de Office/EPPlus que el formulario no utiliza; ningún miembro Revit/WinForms se simuló en esa comprobación.
- 29 escenarios de regresión aprobados, 0 fallidos, extrayendo ocho métodos reales, el DTO de corte y la propiedad del input. Incluye 20 pares de offset/espesor, coma/punto, crecimiento hacia dentro, prioridad nueva, uniones existentes, restauración previa a leer geometría, alcance viejo/nuevo, fase/opción, sólidos frente a caja, rechazo/rollback y fallo fatal de regeneración.
- La prueba de conservación de ID/altura del antiguo usa dobles de contrato: no mide el volumen CSG real de Revit.
- Rutas del proyecto: existen los 179 Compile, 9 EmbeddedResource y 3 None; las dos fuentes figuran una vez. git diff --check correcto. El parche fue aplicado a los archivos de entrada y produjo exactamente los bytes de las dos fuentes finales.
- La compilación aislada no es la compilación de MYG.csproj con Office/COM ni una ejecución del complemento. Falta recompilar la solución completa en Windows y probar la geometría/interfaz dentro de Revit. No se entrega una DLL validada.

Repetir pruebas con SDK .NET 8 y Python 3:

```bash
bash tests/OffsetCorteMuros/run.sh
```

La comprobación con API real se documenta en tests/OffsetCorteApi/README.md. No se incluyen DLL Autodesk, paquetes restaurables ni salidas de compilación.

### Pruebas pendientes en Revit

- Reproducir el Room de la captura con offset 0.015, altura 2.10 y base picada; medir cara inicial, espesor y altura real.
- Probar espesores nuevo menor/igual/mayor que el offset: solo el tipo determina el espesor; el frente se sitúa en espesor menos offset respecto al contorno.
- Confirmar con Unir geometría/Cambiar orden que el nuevo corta a todos los muros realmente atravesados, incluidos acabados y ladrillo cuando se solapen, sin recortarse por ellos.
- Comprobar que el tarrajeo superior y las partes sin solape permanecen, con el mismo ID del muro antiguo.
- Revisar puertas/ventanas, encuentros de esquina, retornos cortos y diferentes fases/opciones. Probar un muro cercano sin intersección: no debe afectarse por su caja sola.
- Desactivar el checkbox y verificar que no se aplica el offset ni el corte a antiguos; debe continuar la creación normal.

## G. GitHub

Publicar el ZIP en bimchimbote-droid/DESCARGAS no instala cambios en su PC ni actualiza MYG_v27/MYG_v27_reestructurado. No se hizo commit ni push del código. Tras instalar, compilar y probar en Visual Studio, revise Git Changes, haga Commit y luego Push cuando decida conservarlo.

## H. Límites concretos

El modo manual soporta boundaries RECTOS; los arcos se informan sin usar una traslación que fingiría un offset concéntrico. El corte afecta a Wall del documento actual, con fase aplicable y opción compatible. No corta columnas, familias o muros de vínculos.

Revit puede rechazar uniones por restricciones del modelo, grupos, categorías o geometría. Las parejas no confirmadas se registran con IDs; no se afirma que estén cortadas. Si una unión automática mantiene al antiguo cortando al nuevo y no puede corregirse, o se pierde el offset/espesor, no se confirma el lote. Un retorno nuevo muy corto puede quedar consumido por otro muro nuevo durante la limpieza y dejar de tener sólido; ese caso también revierte el lote en vez de guardar geometría incompleta.

La unión geométrica elimina solo el solape real; no equivale a borrar toda una franja del tarrajeo si el nuevo no la ocupa. Los muros antiguos conservan sus restricciones e ID; sus cantidades y visualización dependen del cálculo nativo de Revit. Deben comprobarse en el modelo.
