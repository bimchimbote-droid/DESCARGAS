using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    // Flujo exclusivo de la casilla: no cambia el filtro ni el motor del modo original.
    internal static class TarrajeoTodasLasCarasHelper
    {
        internal sealed class Origen
        {
            internal Element Host;
            internal Element Geometria;
            internal Transform Transformacion;
            internal List<Element> OrigenesRecorte;
        }

        private sealed class Trabajo
        {
            internal Origen Origen;
            internal Face Cara;
        }

        internal static void Crear(UIDocument uidoc, IList<Origen> origenes,
            WallType tipoMuro, FloorType tipoSuelo, bool permitirUnion, bool considerarVinculos)
        {
            if (tipoMuro == null || tipoSuelo == null)
            {
                TaskDialog.Show("MYG - Todas las caras",
                    "Seleccione un tipo de muro y un tipo de suelo para tarrajear todas las caras libres.");
                return;
            }

            Document doc = uidoc.Document;
            var muros = new Tarrajeo_MurosHandler { UiDoc = uidoc, ConsiderarVinculos = considerarVinculos };
            var suelos = new Tarrajeo_SuelosHandler { UiDoc = uidoc, ConsiderarVinculos = considerarVinculos };
            muros.PrepararNuevaEjecucion();
            suelos.PrepararNuevaEjecucion();
            var uniones = TarrajeoVistaActivaUnionesHelper.InvertirTemporalmenteUnionesOcultasQueCortan(
                doc, origenes.SelectMany(o => o.OrigenesRecorte ?? new List<Element> { o.Geometria }), muros);
            int creados = 0, omitidos = 0, sinAcabado = 0;
            try
            {
                // Capturar todas las caras antes de crear acabados en el modelo.
                var trabajos = new List<Trabajo>();
                foreach (Origen origen in origenes)
                {
                    var opciones = new Options
                    {
                        ComputeReferences = false,
                        IncludeNonVisibleObjects = true,
                        DetailLevel = ViewDetailLevel.Fine
                    };
                    AgregarCaras(origen.Geometria.get_Geometry(opciones),
                        origen.Transformacion ?? Transform.Identity, origen, trabajos);
                }
                foreach (Trabajo trabajo in trabajos)
                {
                    Face cara = trabajo.Cara;
                    PlanarFace plana = cara as PlanarFace;
                    CylindricalFace cilindrica = cara as CylindricalFace;
                    Origen origen = trabajo.Origen;
                    var recorte = origen.OrigenesRecorte ?? new List<Element> { origen.Geometria };
                    if ((plana != null && Math.Abs(plana.FaceNormal.Normalize().Z) < 0.001) ||
                        (cilindrica != null && Math.Abs(Math.Abs(cilindrica.Axis.Normalize().Z) - 1.0) < 0.001))
                    {
                        muros.ConfigurarOrigenesDeRecorte(recorte, origen.Host as RevitLinkInstance);
                        List<Wall> nuevos = muros.CrearMurosDesdeFaceProcesada(doc, uidoc, origen.Host,
                            cara, Transform.Identity, tipoMuro, permitirUnion);
                        if (nuevos != null && nuevos.Count > 0) creados += nuevos.Count;
                        else sinAcabado++;
                    }
                    else if (plana != null && Math.Abs(plana.FaceNormal.Normalize().Z) >= 0.001)
                    {
                        // El motor existente coloca el espesor hacia el exterior según la normal,
                        // tanto en caras inferiores como superiores, y recorta los contactos visibles.
                        suelos.ConfigurarOrigenesDeRecorte(recorte, origen.Host as RevitLinkInstance);
                        if (suelos.CrearSueloDesdeCaraPlanarProcesada(doc, uidoc, origen.Host,
                            plana, Transform.Identity, tipoSuelo))
                            creados += suelos.UltimaCantidadSuelosCreados;
                        else sinAcabado++;
                    }
                    else
                    {
                        // No aproximar superficies que los motores actuales no pueden representar.
                        omitidos++;
                    }
                }
                if (omitidos > 0 || sinAcabado > 0 || creados == 0)
                    TaskDialog.Show("MYG - Todas las caras",
                        "Acabados creados: " + creados + ".\nCaras con geometría no compatible: " + omitidos +
                        ".\nCaras sin acabado (ocupadas o rechazadas por el motor): " + sinAcabado +
                        ".\nLas caras ocupadas se recortan con los motores actuales. Revise el resultado en el modelo.");
            }
            finally
            {
                TarrajeoVistaActivaUnionesHelper.RestaurarUnionesOcultasInvertidas(doc, uniones);
            }
        }

        private static void AgregarCaras(GeometryElement geometria, Transform transformacion,
            Origen origen, List<Trabajo> trabajos)
        {
            if (geometria == null) return;
            foreach (GeometryObject objeto in geometria)
            {
                Solid solido = objeto as Solid;
                if (solido != null && solido.Faces.Size > 0 && solido.Volume > 0)
                {
                    Solid modelo = transformacion.IsIdentity ? solido : SolidUtils.CreateTransformed(solido, transformacion);
                    foreach (Face cara in modelo.Faces)
                        if (cara.Area > 0.0001)
                            trabajos.Add(new Trabajo { Origen = origen, Cara = cara });
                    continue;
                }
                GeometryInstance instancia = objeto as GeometryInstance;
                if (instancia != null)
                    AgregarCaras(instancia.GetSymbolGeometry(), transformacion.Multiply(instancia.Transform), origen, trabajos);
            }
        }
    }
}
