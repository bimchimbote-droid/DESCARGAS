# A. Resumen

Se añade una casilla «Tarrajeo (todas las caras)», desmarcada inicialmente, debajo de «Considerar vínculos». Activada envía las caras libres laterales, inferiores y superiores de las seis categorías a los motores existentes. Las caras planas inclinadas utilizan el motor de suelos; las verticales y cilíndricas verticales, el de muros. Se conservan los recortes por elementos visibles de la vista activa, la selección de vínculos y Permitir Unión para muros. Se requieren ambos tipos (muro y suelo). Las superficies no representables por los motores actuales se omiten con aviso; no se convierten mediante aproximaciones.

Desmarcada ejecuta el código anterior. Los motores compartidos y el resto de ventanas/encofrados no se modifican. La tarjeta y ventana crecen 26 px para alojar la casilla.

# B. Archivos afectados

Todas las rutas de código siguientes comienzan por `MYG/Funcionalidades/Estructuras/Tarrajeo/`:

| Archivo | Acción | Descripción |
|---|---|---|
| TarrajeoElementosForm.cs | REEMPLAZAR | Casilla y ajuste de espacio y tabulación. |
| SeleccionarVigasTarrajeoHandler.cs | REEMPLAZAR | Bifurcación exclusiva de la opción activada. |
| SeleccionarColumnasTarrajeoHandler.cs | REEMPLAZAR | Bifurcación y validación condicional del tipo. |
| SeleccionarMurosTarrajeoHandler.cs | REEMPLAZAR | Bifurcación y validación condicional del tipo. |
| SeleccionarCimentacionTarrajeoHandler.cs | REEMPLAZAR | Bifurcación y validación condicional del tipo. |
| SeleccionarLosasTarrajeoHandler.cs | REEMPLAZAR | Bifurcación exclusiva de la opción activada. |
| SeleccionarEscalerasTarrajeoHandler.cs | REEMPLAZAR | Bifurcación utilizando la extracción existente de componentes. |
| TarrajeoTodasLasCarasHelper.cs | CREAR | Recopilación de caras y llamada a los motores existentes. |

| Otra ruta | Acción | Descripción |
|---|---|---|
| MYG/MYG.csproj | MODIFICAR | Aplicar `entrega/proyecto.patch`: añade solo la inclusión del nuevo helper. |
| entrega/validar_estatico.py | CREAR | Comprobaciones estáticas externas, no proyecto de pruebas Revit. |
| entrega/LEEME.md | CREAR | Instrucciones y relación de archivos. |
| entrega/manifiesto.json | CREAR | Base, estado inicial y hashes de contenido. |

No hay eliminaciones. Los archivos sin cambios quedan fuera del ZIP.

# C. Descarga

El ZIP contiene 12 archivos: ocho C#, un parche de proyecto, estas instrucciones, una comprobación estática y un manifiesto. El enlace real, ruta de publicación y verificación SHA-256 se informan al entregar, una vez completada la publicación.

# D. Instalación

1. Trabajar sobre la solución reestructurada de `bimchimbote-droid/MYG_v27_reestructurado`, base `4ee89ee7b195b4a729126df4ccf2ed6118533f0f`, rama master. Al iniciar el trabajo no existían cambios locales. No se descargó ni sustituyó por MYG_v27/main: no es la base de esta entrega.
2. Respaldar los archivos afectados o guardar los cambios propios en Git. REEMPLAZAR puede sobrescribir modificaciones locales o posteriores: compararlos antes de copiar si su versión difiere de la base.
3. Extraer el ZIP en una carpeta temporal. Copiar los siete archivos REEMPLAZAR completos y el archivo CREAR del helper, conservando sus rutas relativas.
4. Desde la raíz de la solución, ejecutar `git apply --check /ruta/entrega/proyecto.patch` y después `git apply /ruta/entrega/proyecto.patch`. Si falla por diferencias del proyecto, agregar el helper en Visual Studio con «Agregar > Elemento existente» una sola vez. No reemplazar el csproj completo ni modificar dependencias.
5. Los archivos de `entrega/` son documentación y comprobaciones externas; no agregarlos al proyecto C#.
6. En Windows, compilar la configuración adecuada. Cerrar Revit antes de sustituir las DLL de la instalación y conservar el manifiesto .addin y los iconos existentes. Esta entrega contiene código fuente, no una DLL compilada.

# E. Configuración

Sin nuevas referencias, paquetes, recursos o variables de aplicación. Solo se incluye el helper en el proyecto existente. Mantener las dependencias actuales; esta entrega no corrige ni migra la combinación .NET Framework 4.8/Revit 2027.

# F. Validación

Ejecutadas en Linux:

- Análisis sintáctico C# con tree-sitter de los ocho archivos afectados: correcto.
- Regresión estática de los seis selectores: al retirar la nueva bifurcación y restaurar la condición de validación, el contenido coincide exactamente con el commit base, ignorando BOM UTF-8.
- XML del proyecto: 183 fuentes, todas existentes, sin duplicados; helper incluido una sola vez.
- Motores Tarrajeo_MurosHandler y Tarrajeo_SuelosHandler: idénticos a la base.
- git diff --check: correcto.

Para repetir la revisión estática, instalar en un entorno Python aparte `tree-sitter==0.26.1 tree-sitter-c-sharp==0.23.5` y ejecutar `python entrega/validar_estatico.py /ruta/al/checkout`. Requiere que el commit base esté disponible en Git. No sustituye una compilación.

Compilación: NO ejecutada; faltan Windows, MSBuild/.NET Framework y las dependencias COM/Revit apropiadas. Pruebas funcionales en Revit: NO ejecutadas.

Matriz pendiente en una copia de modelo:

- Comparar opción desactivada frente a la versión base en las seis categorías y encofrados.
- Activar en cada categoría: laterales e inferiores, además de superiores; comprobar orientación y espesor exterior con los tipos elegidos.
- Caras totalmente ocupadas: no crear; parcialmente ocupadas: recortar. Verificar encuentros muro-columna, viga-losa y componentes de escalera.
- Probar nativos y vínculos trasladados/rotados, Permitir Unión activada/desactivada, vista con elementos ocultos y restauración de uniones tras cancelar o fallar.
- Revisar huecos, superficies inclinadas/cilíndricas y avisos de geometría no compatible; no duplicar acabados ejecutando sobre elementos ya procesados.
- Verificar disposición y navegación por teclado con la escala de pantalla utilizada.

# G. GitHub

La autorización de publicación se utiliza solo para añadir un ZIP nuevo en DESCARGAS. No se hace commit/push en MYG_v27 ni en MYG_v27_reestructurado. Publicar el ZIP no instala los cambios en su PC ni actualiza el repositorio de código.

Después de instalar y probar: abrir «Cambios de Git» en Visual Studio, revisar las diferencias y la inclusión del helper, seleccionar únicamente los archivos deseados y hacer Commit. Hacer Push desde Visual Studio cuando decida publicar su código.

# H. Limitaciones

El modo nuevo utiliza las caras geométricas que entrega Revit y el criterio de visibilidad/recorte actual. No reconstruye superficies arbitrarias ni elimina la limitación de los motores existentes a geometría compatible. No se garantiza un acabado sobre caras curvas distintas de cilindros verticales. Un aviso resume caras sin acabado y no compatibles. Un fallo puede dejar acabados previos ya creados, como en el flujo existente: revisar el modelo y utilizar Deshacer cuando proceda. No ejecutar en el modelo de producción sin compilar y validar primero. La compatibilidad .NET/Revit pendiente del repositorio se mantiene como limitación preexistente.
