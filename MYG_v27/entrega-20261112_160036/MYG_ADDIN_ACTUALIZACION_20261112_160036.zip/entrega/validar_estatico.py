"""Revisión estática de esta entrega; no compila ni ejecuta Revit.
Ejecutar en el checkout modificado: python validar_estatico.py /ruta/al/checkout
Requiere tree-sitter==0.26.1 y tree-sitter-c-sharp==0.23.5.
"""
import sys, subprocess, re
from pathlib import Path
import xml.etree.ElementTree as ET
from tree_sitter import Language, Parser
import tree_sitter_c_sharp
root = Path(sys.argv[1]).resolve()
base = '4ee89ee7b195b4a729126df4ccf2ed6118533f0f'
d = root/'MYG/Funcionalidades/Estructuras/Tarrajeo'
parser = Parser(Language(tree_sitter_c_sharp.language()))
files = [d/'TarrajeoElementosForm.cs', d/'TarrajeoTodasLasCarasHelper.cs', *sorted(d.glob('Seleccionar*TarrajeoHandler.cs'))]
for p in files:
    tree = parser.parse(p.read_bytes())
    assert not tree.root_node.has_error, f'Sintaxis C#: {p}'
print(f'PASS: sintaxis de {len(files)} archivos C# afectados')
for p in sorted(d.glob('Seleccionar*TarrajeoHandler.cs')):
    original = subprocess.check_output(['git', '-C', str(root), 'show', base+':'+str(p.relative_to(root))]).decode('utf-8-sig')
    updated = p.read_text(encoding='utf-8-sig')
    # Retirar únicamente la nueva bifurcación y recuperar la validación anterior.
    restored, count = re.subn(r'            if \(Form != null && Form.TarrajeoTodasLasCaras\)\n            \{.*?                MostrarFormulario\(\);\n                return;\n            \}\n\n', '', updated, count=1, flags=re.S)
    assert count == 1, p
    restored = restored.replace('if (TipoMuro == null && !(Form != null && Form.TarrajeoTodasLasCaras))', 'if (TipoMuro == null)')
    assert restored == original, f'Cambió lógica preexistente: {p}'
print('PASS: los seis selectores conservan el código anterior fuera de la bifurcación y su validación condicional')
ns={'m':'http://schemas.microsoft.com/developer/msbuild/2003'}
project=ET.parse(root/'MYG/MYG.csproj')
includes=[e.attrib['Include'] for e in project.findall('.//m:Compile',ns)]
assert len(includes)==len(set(includes))
assert sum(x.endswith('TarrajeoTodasLasCarasHelper.cs') for x in includes)==1
assert all((root/'MYG'/s.replace('\\','/')).is_file() for s in includes)
print(f'PASS: {len(includes)} fuentes incluidas, existentes y sin duplicados')
for name in ['Tarrajeo_MurosHandler.cs','Tarrajeo_SuelosHandler.cs']:
    p=d/name
    old=subprocess.check_output(['git','-C',str(root),'show',base+':'+str(p.relative_to(root))])
    assert p.read_bytes()==old
print('PASS: motores existentes de muros y suelos sin cambios')
