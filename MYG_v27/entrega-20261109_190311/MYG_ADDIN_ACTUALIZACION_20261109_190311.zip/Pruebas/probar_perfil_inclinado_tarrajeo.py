#!/usr/bin/env python3
"""Pruebas del respaldo de perfil planar inclinado sin instalar dependencias.

Extrae el adaptador planar y sus conversiones del código real. El motor de
recorte se sustituye por resultados programados; verifica planos, candidatos,
contornos y fallos, sin reproducir booleanos, uniones o suelos reales de Revit.
Los archivos generados se guardan en un directorio temporal que se elimina al salir.
"""
from pathlib import Path
import argparse
import atexit
import json
import re
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description='Ejecuta regresiones UV extraídas del código real, sin Revit ni NuGet.')
parser.add_argument('--dotnet', default=shutil.which('dotnet'), help='Ruta al ejecutable de un SDK .NET 8 o posterior')
args = parser.parse_args()
if not args.dotnet:
    parser.error('Instala un SDK .NET o indica --dotnet /ruta/dotnet')
DOTNET = Path(args.dotnet).resolve()
SDK_ROOT = DOTNET.parent
compilers = sorted((SDK_ROOT / 'sdk').glob('*/Roslyn/bincore/csc.dll'))
refdirs = sorted((SDK_ROOT / 'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net*'))
runtimes = sorted((SDK_ROOT / 'shared/Microsoft.NETCore.App').glob('*'))
if not compilers or not refdirs or not runtimes:
    parser.error('La ruta debe contener un SDK completo con compilador y reference pack')
BASE = Path(tempfile.mkdtemp(prefix='myg-inclinado-'))
atexit.register(shutil.rmtree, BASE)
REPO = Path(__file__).resolve().parents[1]
SOURCE = REPO / 'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs'
text = SOURCE.read_text(encoding='utf-8-sig')

def block(pattern):
    match = re.search(pattern, text)
    if not match:
        raise ValueError(pattern)
    start = text.index('{', match.start())
    depth = 1
    end = start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]

names = ['CrearMarcoPlanarParaRecorte', 'LoopDesdeCurveLoop', 'LoopDesdeUV',
         'ClasificarComponentes', 'PuntoInteriorSeguro', 'CurvasLoop', 'CurveLoopDesdeLoop',
         'PuntosCurva', 'Limpiar', 'EsPuntoColinealIntermedio', 'Igual', 'Area', 'AreaAbs',
         'LoopSeguro', 'TieneSegmentosCortos', 'LoopTieneCruces', 'SegmentosIntersectan2D',
         'Orient2D', 'PuntoEnSegmento2D', 'EsToqueDeExtremo', 'Dist2D', 'PuntoEnPoligono', 'Similar',
         'CrearHuellaLaminaRepresentable']
methods = [block(r'    private [^\n]+\b' + name + r'\s*\(') for name in names]
methods.append(block(r'    public bool IntentarRecortarPerfilPlanar\s*\('))
constants = re.findall(r'    private const double (?:TOL|PTOL)\s*=.*?;', text)
classes = [block(r'public class ' + name + r'\b') for name in ['MarcoMuro', 'LoopMuro', 'ComponenteMuro', 'UV2']]
classes.append(block(r'    private class ResultadoRecorteSolidos\b'))
stubs = r'''
public class XYZ {
    public double X,Y,Z;
    public XYZ(double x,double y,double z){X=x;Y=y;Z=z;}
    public static XYZ BasisX{get{return new XYZ(1,0,0);}}
    public static XYZ BasisY{get{return new XYZ(0,1,0);}}
    public static XYZ BasisZ{get{return new XYZ(0,0,1);}}
    public XYZ Multiply(double s){return new XYZ(X*s,Y*s,Z*s);}
    public double DotProduct(XYZ b){return X*b.X+Y*b.Y+Z*b.Z;}
    public XYZ CrossProduct(XYZ b){return new XYZ(Y*b.Z-Z*b.Y,Z*b.X-X*b.Z,X*b.Y-Y*b.X);}
    public double GetLength(){return Math.Sqrt(DotProduct(this));}
    public XYZ Normalize(){return Multiply(1/GetLength());}
    public double DistanceTo(XYZ b){return (this-b).GetLength();}
    public static XYZ operator +(XYZ a,XYZ b){return new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}
    public static XYZ operator -(XYZ a,XYZ b){return new XYZ(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}
}
public class Transform {
    XYZ shift=new XYZ(0,0,0);
    public static Transform Identity{get{return new Transform();}}
    public static Transform CreateTranslation(XYZ p){return new Transform{shift=p};}
    public XYZ OfPoint(XYZ p){return p+shift;}
}
public class Curve {
    public XYZ A,B;
    public double Length{get{return A.DistanceTo(B);}}
    public IList<XYZ> Tessellate(){return new List<XYZ>{A,B};}
    public XYZ GetEndPoint(int i){return i==0?A:B;}
    public Curve CreateTransformed(Transform t){return new Curve{A=t.OfPoint(A),B=t.OfPoint(B)};}
}
public class Line:Curve {public static Line CreateBound(XYZ a,XYZ b){return new Line{A=a,B=b};}}
public class CurveLoop:IEnumerable<Curve> {
    public static bool ForceOpen;
    public List<Curve> Curves=new List<Curve>();
    public void Append(Curve c){Curves.Add(c);}
    public bool IsOpen(){return ForceOpen||Curves.Count<3||Curves[0].A.DistanceTo(Curves[Curves.Count-1].B)>1e-9;}
    public IEnumerator<Curve> GetEnumerator(){return Curves.GetEnumerator();}
    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator(){return GetEnumerator();}
}
public class Document{public int Mutations;}
public class View{}
public class Element{}
public class Solid{}
'''
core = r'''
    Dictionary<Solid,string> _origenesSolidosCortantes=new Dictionary<Solid,string>();
    Queue<Func<ComponenteMuro,MarcoMuro,ResultadoRecorteSolidos>> scripted=new Queue<Func<ComponenteMuro,MarcoMuro,ResultadoRecorteSolidos>>();
    List<List<Solid>> received=new List<List<Solid>>();
    int coreCalls;
    List<double> minimums=new List<double>();
    private ResultadoRecorteSolidos RecortarComponentePorEspesorReal(Document doc,View view,Element host,ComponenteMuro component,MarcoMuro frame,XYZ normal,double width,List<Solid> candidates,double minimum=0) {
        coreCalls++;received.Add(candidates);minimums.Add(minimum);
        Check(normal.DistanceTo(frame.Normal)<1e-10,"core receives frame normal");
        Near(width,15/304.8,"core receives exact 15mm thickness");
        return scripted.Count>0?scripted.Dequeue()(component,frame):new ResultadoRecorteSolidos();
    }
'''
tests = r'''
    static int passed;
    static void Check(bool value,string name){if(!value)throw new Exception(name);passed++;}
    static void Near(double actual,double expected,string name){Check(Math.Abs(actual-expected)<1e-8,name+" actual="+actual+" expected="+expected);}
    static void Vector(XYZ a,XYZ b,string name){Near(a.DistanceTo(b),0,name);}
    CurveLoop Rectangle(XYZ origin,XYZ u,XYZ v,double minU,double maxU,double minV,double maxV) {
        XYZ[] points={origin+u.Multiply(minU)+v.Multiply(minV),origin+u.Multiply(maxU)+v.Multiply(minV),origin+u.Multiply(maxU)+v.Multiply(maxV),origin+u.Multiply(minU)+v.Multiply(maxV)};
        var loop=new CurveLoop();for(int i=0;i<4;i++)loop.Append(Line.CreateBound(points[i],points[(i+1)%4]));return loop;
    }
    LoopMuro Rect(MarcoMuro frame,double minU,double maxU,double minV,double maxV) {
        return LoopDesdeUV(new List<UV2>{new UV2(minU,minV),new UV2(maxU,minV),new UV2(maxU,maxV),new UV2(minU,maxV),new UV2(minU,minV)},frame);
    }
    void Reset(){coreCalls=0;received.Clear();scripted.Clear();minimums.Clear();CurveLoop.ForceOpen=false;}
    public void Run(){
        var normals=new List<XYZ>{XYZ.BasisZ,XYZ.BasisZ.Multiply(-1),XYZ.BasisX,XYZ.BasisX.Multiply(-1),XYZ.BasisY,new XYZ(1,2,3),new XYZ(1,0,1e-8),new XYZ(1,0,-1e-8)};
        foreach(double z in new[]{0.9-1e-8,0.9,0.9+1e-8,-0.9-1e-8,-0.9+1e-8})normals.Add(new XYZ(Math.Sqrt(1-z*z),0,z));
        var doc=new Document();var view=new View();var host=new Element();double width=15/304.8;var origin=new XYZ(123,-87,42);
        var candidates=new List<Solid>{new Solid(),new Solid()};
        List<List<CurveLoop>> profiles;bool cut;string diagnostic;
        foreach(var normal in normals){
            Reset();var frame=CrearMarcoPlanarParaRecorte(origin,normal,width);var n=normal.Normalize();
            Near(frame.U.GetLength(),1,"unit U");Near(frame.V.GetLength(),1,"unit V");Near(frame.Normal.GetLength(),1,"unit normal");
            Near(frame.U.DotProduct(frame.V),0,"UV orthogonal");Near(frame.U.DotProduct(n),0,"U perpendicular to normal");Near(frame.V.DotProduct(n),0,"V perpendicular to normal");
            Vector(frame.U.CrossProduct(frame.V),n,"frame right handed");Vector(frame.Origen,origin+n.Multiply(width/2),"frame centered outside physical face");
            var outer=Rectangle(origin,frame.U,frame.V,0,10,0,10);var hole=Rectangle(origin,frame.U,frame.V,3,7,3,7);
            var input=new List<CurveLoop>{outer,hole};var snapshot=input.SelectMany(loop=>loop.Select(c=>new XYZ(c.A.X,c.A.Y,c.A.Z))).ToArray();
            Check(IntentarRecortarPerfilPlanar(doc,view,host,input,origin,normal,width,candidates,out profiles,out cut,out diagnostic),"no-change planar profile succeeds");
            Check(!cut&&diagnostic==string.Empty,"no-change status");Check(profiles.Count==1&&profiles[0].Count==2,"original hole preserved");
            Check(coreCalls==1&&Object.ReferenceEquals(received[0],candidates),"exact prefiltered candidate list passed without recollection");
            var output=profiles.SelectMany(p=>p.SelectMany(loop=>loop.Select(c=>c.A))).ToArray();
            foreach(var point in output){Near((point-origin).DotProduct(n),0,"roundtrip returns original inclined plane");Check(snapshot.Any(p=>p.DistanceTo(point)<1e-8),"roundtrip retains original vertex");}
            var after=input.SelectMany(loop=>loop.Select(c=>c.A)).ToArray();for(int i=0;i<after.Length;i++)Vector(after[i],snapshot[i],"input curves unchanged");
            Check(doc.Mutations==0&&candidates.Count==2,"no document or candidate list mutation");
        }
        Reset();var horizontal=CrearMarcoPlanarParaRecorte(origin,XYZ.BasisZ,width);var initial=new List<CurveLoop>{Rectangle(origin,horizontal.U,horizontal.V,0,10,0,10)};
        scripted.Enqueue((component,frame)=>new ResultadoRecorteSolidos{HuboCambio=true,Loops=new List<LoopMuro>{Rect(frame,0,4,0,10),Rect(frame,6,10,0,10)}});
        Check(IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"split core output accepted");
        Check(cut&&profiles.Count==2&&profiles.All(p=>p.Count==1),"two separated islands returned");
        Reset();scripted.Enqueue((component,frame)=>new ResultadoRecorteSolidos{HuboCambio=true,Loops=new List<LoopMuro>{Rect(frame,0,10,0,10),Rect(frame,3,7,3,7)}});
        Check(IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"hole core output accepted");
        Check(cut&&profiles.Count==1&&profiles[0].Count==2,"cut hole returned with exterior");
        Reset();scripted.Enqueue((component,frame)=>new ResultadoRecorteSolidos{HuboCambio=true,EliminadoCompletamente=true});
        Check(IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"full occlusion is successful empty result");Check(cut&&profiles.Count==0,"full occlusion never restores original");
        Reset();scripted.Enqueue((component,frame)=>new ResultadoRecorteSolidos{HuboCambio=true});
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"partial result missing loops fails");Check(!cut&&profiles.Count==0&&diagnostic.Contains("parcialmente"),"missing loops diagnosis no unsafe output");
        Reset();scripted.Enqueue((component,frame)=>null);
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"null core result fails");Check(!cut&&profiles.Count==0&&diagnostic.Length>0,"null result diagnosis");
        Reset();var twoIslands=new List<CurveLoop>{initial[0],Rectangle(origin,horizontal.U,horizontal.V,20,30,0,10)};
        scripted.Enqueue((component,frame)=>new ResultadoRecorteSolidos());scripted.Enqueue((component,frame)=>new ResultadoRecorteSolidos{FalloReconstruccion=true,Diagnostico="injected second island failure"});
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,twoIslands,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"failure after partial output fails entire request");
        Check(profiles.Count==0&&!cut&&diagnostic.Contains("second island"),"failure clears previously produced output");
        Reset();CurveLoop.ForceOpen=true;
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"open output loop rejected");Check(profiles.Count==0&&!cut&&diagnostic.Contains("abierto"),"open output gives diagnosis");
        Reset();foreach(double invalid in new[]{0,-1,double.NaN,double.PositiveInfinity}){
            Check(!IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,invalid,candidates,out profiles,out cut,out diagnostic),"invalid width rejected");Check(coreCalls==0&&profiles.Count==0&&!cut,"invalid width does not enter core");
        }
        Check(!IntentarRecortarPerfilPlanar(null,view,host,initial,origin,XYZ.BasisZ,width,candidates,out profiles,out cut,out diagnostic),"missing document rejected");
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,new XYZ(0,0,0),width,candidates,out profiles,out cut,out diagnostic),"zero normal rejected");
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,initial,origin,XYZ.BasisZ,width,null,out profiles,out cut,out diagnostic),"missing filtered candidate list rejected");
        Reset();var fortyFive=new XYZ(1,0,1).Normalize();var slopeFrame=CrearMarcoPlanarParaRecorte(origin,fortyFive,width);
        var inclinedInput=new List<CurveLoop>{Rectangle(origin,slopeFrame.U,slopeFrame.V,0,10,0,10)};
        double projectedTolerance=0.002604;
        Check(IntentarRecortarPerfilPlanar(doc,view,host,inclinedInput,origin,fortyFive,width,candidates,out profiles,out cut,out diagnostic,projectedTolerance),"45-degree projected tolerance accepted");
        Near(minimums.Single(),1.1*projectedTolerance/Math.Abs(fortyFive.Z),"45-degree minimum compensates horizontal projection");
        Check(minimums.Single()*Math.Abs(fortyFive.Z)>projectedTolerance,"projected minimum exceeds short-curve tolerance");
        Reset();Check(IntentarRecortarPerfilPlanar(doc,view,host,inclinedInput,origin,fortyFive,width,candidates,out profiles,out cut,out diagnostic),"default planar call remains compatible");
        Near(minimums.Single(),0,"default optional minimum unchanged");
        Reset();foreach(double invalid in new[]{-1,double.NaN,double.PositiveInfinity,double.NegativeInfinity}) {
            Check(!IntentarRecortarPerfilPlanar(doc,view,host,inclinedInput,origin,fortyFive,width,candidates,out profiles,out cut,out diagnostic,invalid),"invalid projected tolerance rejected");
            Check(coreCalls==0&&profiles.Count==0&&!cut&&diagnostic.Length>0,"invalid projected tolerance does not reach core");
        }
        Reset();var steep=new XYZ(1,0,0.01).Normalize();var steepFrame=CrearMarcoPlanarParaRecorte(origin,steep,width);
        var steepInput=new List<CurveLoop>{Rectangle(origin,steepFrame.U,steepFrame.V,0,10,0,10)};
        Check(IntentarRecortarPerfilPlanar(doc,view,host,steepInput,origin,steep,width,candidates,out profiles,out cut,out diagnostic,projectedTolerance),"steep unchanged profile does not require proxy");
        Check(minimums.Single()>2*PTOL,"steep requirement passed to core without blanket rejection");
        Reset();var verticalFrame=CrearMarcoPlanarParaRecorte(origin,XYZ.BasisX,width);
        var verticalInput=new List<CurveLoop>{Rectangle(origin,verticalFrame.U,verticalFrame.V,0,10,0,10)};
        Check(!IntentarRecortarPerfilPlanar(doc,view,host,verticalInput,origin,XYZ.BasisX,width,candidates,out profiles,out cut,out diagnostic,projectedTolerance),"vertical face cannot request horizontal floor projection");
        Check(coreCalls==0&&profiles.Count==0&&diagnostic.Contains("vertical"),"vertical projection rejected before core with diagnosis");
        var thin=new List<UV2>{new UV2(0,0),new UV2(10,0),new UV2(5,0.0001)};
        double required=1.1*projectedTolerance/Math.Abs(fortyFive.Z);
        var proxy=CrearHuellaLaminaRepresentable(thin,slopeFrame,required);
        Check(proxy!=null&&LoopSeguro(proxy),"projection-compensated narrow proxy valid");
        Near(proxy.MaxV-proxy.MinV,required,"proxy short side uses requested normal-plane minimum");
        Check((proxy.MaxV-proxy.MinV)*Math.Abs(fortyFive.Z)>projectedTolerance,"proxy horizontal side survives floor projection");
        bool capped=false;try{CrearHuellaLaminaRepresentable(thin,slopeFrame,3/304.8);}catch(InvalidOperationException){capped=true;}
        Check(capped,"3mm requested regularization rejected instead of broadening cut");
        Console.WriteLine("Inclined planar adapter: "+passed+" assertions passed (scripted core, not Revit kernel)");
    }
    static int Main(){try{new Harness().Run();return 0;}catch(Exception ex){Console.Error.WriteLine(ex);return 1;}}
'''
src = '\n'.join(['using System;using System.Collections.Generic;using System.Linq;', stubs,
                 *classes[:4], 'class Harness {', classes[4], *constants, core, *methods, tests, '}'])
out = BASE / 'inclined'
out.mkdir(exist_ok=True)
(out / 'Inclined.cs').write_text(src)
refs = list(refdirs[-1].glob('*.dll'))
rsp = out / 'compile.rsp'
rsp.write_text('\n'.join(['-nologo', '-langversion:7.3', '-nostdlib+', '-target:exe', '-out:' + str(out / 'Inclined.dll')]
                         + ['-r:' + str(p) for p in refs] + [str(out / 'Inclined.cs')]))
subprocess.run([str(DOTNET), str(compilers[-1]), '@' + str(rsp)], check=True)
(out / 'Inclined.runtimeconfig.json').write_text(json.dumps({'runtimeOptions': {'framework': {
    'name': 'Microsoft.NETCore.App', 'version': runtimes[-1].name}}}))
subprocess.run([str(DOTNET), str(out / 'Inclined.dll')], check=True)

