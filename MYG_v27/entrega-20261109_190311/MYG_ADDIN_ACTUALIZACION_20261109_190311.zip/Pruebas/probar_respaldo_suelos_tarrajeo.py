#!/usr/bin/env python3
"""Check floor fallback integration using the actual floor processing method.

Requires a local .NET 8 SDK (--dotnet or DOTNET_ROOT); downloads nothing.
Revit geometry, profile construction, floor creation and the planar engine are
substituted to isolate routing, inputs, hole preservation and failure handling.
"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import tempfile

REPO = Path(__file__).resolve().parents[1]
SOURCE = REPO / 'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs'

CODE = r'''
using System;
using System.Collections.Generic;
using System.Linq;
class XYZ {
 public double X,Y,Z;
 public XYZ(double x,double y,double z) {X=x;Y=y;Z=z;}
 public double GetLength() {return Math.Sqrt(X*X+Y*Y+Z*Z);}
 public XYZ Normalize() {double d=GetLength();return new XYZ(X/d,Y/d,Z/d);}
 public double DotProduct(XYZ b) {return X*b.X+Y*b.Y+Z*b.Z;}
 public static XYZ operator -(XYZ a,XYZ b) {return new XYZ(a.X-b.X,a.Y-b.Y,a.Z-b.Z);}
}
class Document { }
class View { }
class UIDocument { public View ActiveView=new View(); }
class ElementId { }
class Element { public ElementId Id=new ElementId(); }
class FloorType { }
class Transform {
 public static Transform Identity=new Transform();
 public XYZ OfVector(XYZ x) {return x;}
 public XYZ OfPoint(XYZ x) {return x;}
}
class CurveLoop { public string Id; public CurveLoop(string id) {Id=id;} }
class Face { }
class PlanarFace:Face {
 public XYZ FaceNormal=new XYZ(0,0,1),Origin=new XYZ(0,0,0); public double Area=10;
 public IList<CurveLoop> Loops=new List<CurveLoop>{new CurveLoop("original-arc")};
 public IList<CurveLoop> GetEdgesAsCurveLoops() {return Loops;}
}
class Solid {
 public string Id; public double Volume=10;
 public List<Face> Faces=new List<Face>{new PlanarFace()};
 public Solid(string id="solid") {Id=id;}
}
class Outline { }
class Level { public double ProjectElevation=0; }
class Plane {
 public XYZ Normal;
 public static Plane CreateByNormalAndOrigin(XYZ n,XYZ o) {return new Plane{Normal=n};}
}
enum BooleanOperationsType {Intersect,Difference}
static class BooleanOperationsUtils {
 public static Solid ExecuteBooleanOperation(Solid a,Solid b,BooleanOperationsType kind) {
  Engine.Operations.Add(kind+":"+a.Id+":"+b.Id);
  if(Engine.Steps.Count>0) {object step=Engine.Steps.Dequeue(); if(step is Exception ex)throw ex;return (Solid)step;}
  return new Solid(kind==BooleanOperationsType.Intersect?"intersection":"partially-cut");
 }
}
static class Engine {
 public static Queue<object> Steps;
 public static List<string> Operations;
 public static bool HuellaFail,SketchLosesHole,PlanarSuccess,PlanarChanged,PlanarThrows;
 public static int PlanarCalls; public static string PlanarDiagnostic;
 public static List<Solid> ReceivedCandidates;
 public static IList<CurveLoop> ReceivedLoops;
 public static List<List<CurveLoop>> PlanarProfiles;
 public static XYZ ReceivedNormal; public static double ReceivedCurveTolerance;
 public static void Reset() {
  Steps=new Queue<object>();Operations=new List<string>(); HuellaFail=false;SketchLosesHole=false;
  PlanarSuccess=true;PlanarChanged=true;PlanarThrows=false;PlanarCalls=0;PlanarDiagnostic="planar detail";
  ReceivedCandidates=null;ReceivedLoops=null;ReceivedNormal=null;ReceivedCurveTolerance=0;
  PlanarProfiles=new List<List<CurveLoop>>{new List<CurveLoop>{new CurveLoop("recovered")}};
 }
}
class Tarrajeo_MurosHandler {
 public bool IntentarRecortarPerfilPlanar(Document d,View v,Element host,IList<CurveLoop> loops,XYZ origin,XYZ normal,
  double thickness,List<Solid> candidates,out List<List<CurveLoop>> profiles,out bool changed,out string diagnostic, double shortCurveTolerance=0) {
  Engine.PlanarCalls++;Engine.ReceivedCandidates=candidates;Engine.ReceivedLoops=loops;Engine.ReceivedNormal=normal;Engine.ReceivedCurveTolerance=shortCurveTolerance;
  if(Engine.PlanarThrows)throw new InvalidOperationException("planar thrown detail");
  profiles=Engine.PlanarProfiles;changed=Engine.PlanarChanged;diagnostic=Engine.PlanarDiagnostic;return Engine.PlanarSuccess;
 }
}
class Harness {
 const double TOL=1e-9,SEARCH_MARGIN=0.1,SEPARACION_EXTERIOR_REINTENTO=0.003;
 public string UltimoDiagnostico;
 public List<Solid> Candidates=new List<Solid>{new Solid("candidate-1"),new Solid("candidate-2")};
 public List<CurveLoop> OriginalLoops,ExtrusionLoops=new List<CurveLoop>{new CurveLoop("extrusion-repaired")};
 public List<List<CurveLoop>> Created=new List<List<CurveLoop>>();
 public int NativeSketchCalls,RecoveredSketchCalls; public List<bool> Slopes=new List<bool>();
 public List<double> Thicknesses=new List<double>();
 bool Fallar(string phase,string detail,Exception ex=null) {UltimoDiagnostico=phase+": "+detail+(ex==null?"":" | "+ex.Message);return false;}
 double ObtenerToleranciaCurvaCorta(Document d) {return 0.001;}
 List<CurveLoop> TransformCurveLoops(IList<CurveLoop> loops,Transform t) {OriginalLoops=loops.ToList();return OriginalLoops;}
 double GetFloorThickness(FloorType t) {return 0.05;}
 Solid CrearSolidoTemporalRobusto(PlanarFace f,IList<CurveLoop> original,List<CurveLoop> model,Transform t,XYZ n,
  XYZ origin,double depth,double tol,out List<CurveLoop> loops,out string detail) {
  loops=ExtrusionLoops;detail="";return new Solid("original-base");
 }
 Outline CreateOutlineFromLoops(List<CurveLoop> ls,XYZ n,double d) {return new Outline();}
 List<Solid> GetVisibleNativeAndLinkedSolids(Document d,View v,Outline box,ElementId id) {return Candidates;}
 List<Solid> CrearPrismasDeHuellaDeInterseccion(Solid s,XYZ origin,XYZ n,double depth,double tol,out string detail) {
  detail="footprint failure detail";return Engine.HuellaFail?null:new List<Solid>{new Solid("cutter")};
 }
 Level GetBaseLevelForFloor(Document d,Element e,double z) {return new Level();}
 bool AreParallel(XYZ a,XYZ b) {return Math.Abs(Math.Abs(a.DotProduct(b))-1)<1e-6;}
 List<CurveLoop> ConstruirSketchHorizontalDesdeCara(PlanarFace f,Plane p,double z,double tol,out string detail) {
  NativeSketchCalls++;detail="";return f.GetEdgesAsCurveLoops().ToList();
 }
 List<CurveLoop> ConstruirSketchHorizontalDesdeLoops(IList<CurveLoop> loops,Plane p,double z,double tol,out string detail) {
  RecoveredSketchCalls++;detail="sketch detail";
  return Engine.SketchLosesHole?loops.Take(1).ToList():loops.ToList();
 }
 bool IntentarCrearSuelo(Document d,List<CurveLoop> sketch,FloorType type,Level level,XYZ origin,XYZ normal,
  double thickness,bool inclined,double separation,out string detail) {
  detail="";Created.Add(sketch);Slopes.Add(inclined);Thicknesses.Add(thickness);return true;
 }
__METHOD__
}
static class Program {
 static int checks;
 static void Check(bool condition,string name) {if(!condition)throw new Exception(name);checks++;Console.WriteLine("PASS "+name);}
 static bool Run(Harness h,bool inclined=false) {return h.CrearSueloDesdeCaraPlanarProcesada(
  new Document(),new UIDocument(),new Element(),new PlanarFace{FaceNormal=inclined?new XYZ(0,0.6,0.8):new XYZ(0,0,1)},
  Transform.Identity,new FloorType());}
 static Harness Fresh() {Engine.Reset();return new Harness();}
 static void FailIntersection() {Engine.Steps.Enqueue(new InvalidOperationException("primary intersection detail"));}
 static void Tests() {
  var h=Fresh();Check(Run(h),"normal Boolean path succeeds");
  Check(Engine.PlanarCalls==0&&h.NativeSketchCalls==1&&h.RecoveredSketchCalls==0,"normal path does not invoke planar fallback");
  Check(h.Created.Count==1&&h.Created[0][0].Id=="original-arc","normal path retains original curve object");

  h=Fresh();FailIntersection();Check(Run(h),"intersection failure recovers through planar profile");
  Check(Engine.PlanarCalls==1&&object.ReferenceEquals(Engine.ReceivedCandidates,h.Candidates),"fallback receives exact precollected native/link candidates list");
  Check(Engine.ReceivedCurveTolerance==0.001,"fallback receives floor application's short-curve tolerance");
  Check(Engine.ReceivedLoops[0]==h.OriginalLoops[0]&&Engine.ReceivedLoops[0]!=h.ExtrusionLoops[0],"fallback recomputes from original selected loops before extrusion repair");
  Check(h.NativeSketchCalls==0&&h.Created.Count==1&&h.Created[0][0].Id=="recovered","fallback bypasses partially processed solid and native-face reconstruction");

  h=Fresh();Engine.Steps.Enqueue(new Solid("intersection"));Engine.Steps.Enqueue(new InvalidOperationException("difference detail"));
  Check(Run(h)&&Engine.PlanarCalls==1,"difference exception invokes fallback");

  h=Fresh();Engine.Steps.Enqueue(null);Check(Run(h)&&Engine.PlanarCalls==1,"null intersection invokes fallback rather than restoring uncut face");
  h=Fresh();Engine.Steps.Enqueue(new Solid("intersection"));Engine.Steps.Enqueue(null);
  Check(Run(h)&&Engine.PlanarCalls==1,"null difference invokes fallback rather than claiming full occlusion");

  h=Fresh();Engine.HuellaFail=true;Check(Run(h)&&Engine.PlanarCalls==1,"unreconstructable footprint invokes fallback");

  h=Fresh();Engine.Steps.Enqueue(new Solid("intersection"));Engine.Steps.Enqueue(new Solid("partial-first"));
  Engine.Steps.Enqueue(new InvalidOperationException("second candidate failure"));
  Check(Run(h)&&Engine.PlanarCalls==1&&Engine.ReceivedCandidates.Count==2,"failure after a successful cut recomputes against all original candidates");
  Check(h.NativeSketchCalls==0&&h.Created[0][0].Id=="recovered","partial solid never supplies a fallback sketch");

  h=Fresh();FailIntersection();Engine.PlanarProfiles=new List<List<CurveLoop>>{
   new List<CurveLoop>{new CurveLoop("island-1"),new CurveLoop("hole-1")},
   new List<CurveLoop>{new CurveLoop("island-2")}};
  Check(Run(h)&&h.Created.Count==2&&h.Created[0].Count==2&&h.Created[1].Count==1,"recovered islands and holes reach existing floor creation intact");

  h=Fresh();FailIntersection();Engine.PlanarProfiles[0].Add(new CurveLoop("hole"));Engine.SketchLosesHole=true;
  Check(!Run(h)&&h.Created.Count==0&&h.UltimoDiagnostico.Contains("huecos"),"losing a recovered hole rejects face without original-profile restoration");

  h=Fresh();FailIntersection();Engine.PlanarProfiles.Clear();
  Check(!Run(h)&&h.Created.Count==0&&h.UltimoDiagnostico.Contains("completamente"),"empty successful fallback means fully occluded, no new floor");

  h=Fresh();FailIntersection();Engine.PlanarSuccess=false;
  Check(!Run(h)&&h.Created.Count==0&&h.UltimoDiagnostico.Contains("primary intersection detail")&&h.UltimoDiagnostico.Contains("planar detail"),"failed fallback retains both primary and fallback phase diagnostics");

  h=Fresh();FailIntersection();Engine.PlanarThrows=true;
  Check(!Run(h)&&h.Created.Count==0&&h.UltimoDiagnostico.Contains("primary intersection detail")&&h.UltimoDiagnostico.Contains("planar thrown detail"),"throwing fallback retains both failure diagnostics");

  h=Fresh();FailIntersection();Check(Run(h,true)&&h.Slopes[0]&&h.Thicknesses[0]==0.05&&Engine.ReceivedNormal.Z==0.8,"inclined fallback retains existing slope flag, normal and nominal thickness");
 }
 static int Main() {try{Tests();Console.WriteLine("Total assertions passed: "+checks);return 0;}catch(Exception ex){Console.Error.WriteLine(ex);return 1;}}
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dotnet', default=os.environ.get('DOTNET_ROOT') or shutil.which('dotnet'))
    args = parser.parse_args()
    if not args.dotnet:
        parser.error('Set DOTNET_ROOT or pass --dotnet /path/to/dotnet')
    dotnet = Path(args.dotnet).resolve()
    if dotnet.is_dir():
        dotnet /= 'dotnet'
    compiler = sorted(dotnet.parent.glob('sdk/*/Roslyn/bincore/csc.dll'))[-1]
    refs = sorted(dotnet.parent.glob('packs/Microsoft.NETCore.App.Ref/8.*/ref/net8.0'))[-1]
    text = SOURCE.read_text(encoding='utf-8-sig')
    start = text.index('    public bool CrearSueloDesdeCaraPlanarProcesada(')
    end = text.index('    private List<CurveLoop> ConstruirSketchHorizontalDesdeCara(', start)
    with tempfile.TemporaryDirectory(prefix='myg-floor-fallback-') as tmp:
        work = Path(tmp)
        (work / 'Program.cs').write_text(CODE.replace('__METHOD__', text[start:end]), encoding='utf-8')
        (work / 'test.runtimeconfig.json').write_text(json.dumps({'runtimeOptions': {'tfm': 'net8.0', 'framework': {'name': 'Microsoft.NETCore.App', 'version': '8.0.0'}}}))
        rsp = ['-nologo', '-target:exe', '-out:test.dll', '-langversion:7.3']
        rsp += ['-r:"' + str(dll) + '"' for dll in refs.glob('*.dll')]
        rsp += ['Program.cs']
        (work / 'compile.rsp').write_text('\n'.join(rsp))
        subprocess.run([str(dotnet), str(compiler), '@compile.rsp'], cwd=work, check=True)
        subprocess.run([str(dotnet), 'test.dll'], cwd=work, check=True, timeout=30)


if __name__ == '__main__':
    main()
