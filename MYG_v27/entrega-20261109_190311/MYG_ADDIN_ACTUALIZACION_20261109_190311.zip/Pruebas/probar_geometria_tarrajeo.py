#!/usr/bin/env python3
"""Regresiones de geometría UV sin dependencias NuGet ni instalación automática.

Extrae los helpers del código de producción y los compila como C# 7.3. XYZ solo
aporta suma y multiplicación para construir puntos; no simula sólidos, booleanos
ni creación de elementos de Revit. Estos casos no sustituyen las pruebas en Revit.
Los archivos generados se guardan en un directorio temporal que se elimina al salir.
"""
from pathlib import Path
import argparse
import atexit
import json
import re
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description='Ejecuta regresiones UV extraídas del código real, sin Revit ni NuGet.')
parser.add_argument('--dotnet', default=shutil.which('dotnet'), help='Ruta al ejecutable de un SDK .NET 8 o posterior')
args = parser.parse_args()
if not args.dotnet:
    parser.error('Instala un SDK .NET o indica --dotnet /ruta/dotnet')
DOTNET = Path(args.dotnet).resolve()
SDK_ROOT = DOTNET.parent
compilers = sorted((SDK_ROOT / 'sdk').glob('*/Roslyn/bincore/csc.dll'))
refdirs = sorted((SDK_ROOT / 'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net*'))
runtimes = sorted((SDK_ROOT / 'shared/Microsoft.NETCore.App').glob('*'))
if not compilers or not refdirs or not runtimes:
    parser.error('La ruta debe contener un SDK completo con compilador y reference pack')
BASE = Path(tempfile.mkdtemp(prefix='myg-geometria-'))
atexit.register(shutil.rmtree, BASE)
REPO = Path(__file__).resolve().parents[1]
SOURCE = REPO / 'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs'
text = SOURCE.read_text(encoding='utf-8-sig')

def block(pattern):
    match = re.search(pattern, text)
    if not match:
        raise ValueError(pattern)
    start = text.index('{', match.start())
    depth = 1
    end = start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]

names = ['RestarRectangulosEnPlano', 'AgregarRestoRectangular', 'EsRectangulo', 'Similar',
         'HuellasIguales', 'LoopDesdeUV', 'Limpiar', 'EsPuntoColinealIntermedio', 'Igual',
         'Area', 'AreaAbs', 'LoopSeguro', 'TieneSegmentosCortos', 'LoopTieneCruces',
         'SegmentosIntersectan2D', 'Orient2D', 'PuntoEnSegmento2D', 'EsToqueDeExtremo', 'Dist2D',
         'LaminaCubiertaPorSeccionConvexa', 'CrearHuellaLaminaRepresentable',
         'LaminaAlcanzaPerfil', 'AreaContornoDentroDeTriangulo', 'AreaPerfilDentroDeTriangulo',
         'LaminaCubiertaPorSeccion', 'ClasificarComponentes', 'PuntoInteriorSeguro', 'PuntoEnPoligono']
methods = [block(r'    private [^\n]+\b' + n + r'\s*\(') for n in names]
constants = re.findall(r'    private const double (?:TOL|PTOL|BOOLEAN_RETRY_OFFSET|SOBREPASO_PERFIL)\s*=.*?;', text)
classes = [block(r'public class ' + n + r'\b') for n in ['MarcoMuro', 'LoopMuro', 'ComponenteMuro', 'UV2']]
tests = r'''
    static int passed;
    static void Check(bool ok, string name) { if (!ok) throw new Exception(name); passed++; }
    static void Near(double actual, double expected, string name) { Check(Math.Abs(actual - expected) < 1e-7, name + " (" + actual + ")"); }
    MarcoMuro frame = new MarcoMuro { Origen = new XYZ(0,0,0), U = new XYZ(1,0,0), V = new XYZ(0,1,0), Normal = new XYZ(0,0,1) };
    LoopMuro Poly(params double[] xy) {
        var pts = new List<UV2>();
        for (int i=0;i<xy.Length;i+=2) pts.Add(new UV2(xy[i],xy[i+1]));
        return LoopDesdeUV(pts,frame);
    }
    LoopMuro Rect(double a, double b, double c, double d) { return Poly(a,c,b,c,b,d,a,d,a,c); }
    ComponenteMuro C(LoopMuro lp) { return new ComponenteMuro { Exterior=lp, Huecos=new List<LoopMuro>() }; }
    List<LoopMuro> Cut(ComponenteMuro basis, params ComponenteMuro[] cutters) {
        List<LoopMuro> result;
        Check(RestarRectangulosEnPlano(basis,cutters.ToList(),out result), "accepted rectangular subtraction");
        for (int i=0;i<result.Count;i++) {
            Check(EsRectangulo(result[i]) && LoopSeguro(result[i]),"safe rectangular remainder");
            foreach (var cutter in cutters) {
                double du=Math.Min(result[i].MaxU,cutter.Exterior.MaxU)-Math.Max(result[i].MinU,cutter.Exterior.MinU);
                double dv=Math.Min(result[i].MaxV,cutter.Exterior.MaxV)-Math.Max(result[i].MinV,cutter.Exterior.MinV);
                Check(du<=1e-10 || dv<=1e-10,"remainder never overlaps a cutter");
            }
            for (int j=i+1;j<result.Count;j++) {
                double du=Math.Min(result[i].MaxU,result[j].MaxU)-Math.Max(result[i].MinU,result[j].MinU);
                double dv=Math.Min(result[i].MaxV,result[j].MaxV)-Math.Max(result[i].MinV,result[j].MinV);
                Check(du<=0 || dv<=0,"remainders disjoint");
            }
        }
        return result;
    }

    // Independent oracles for the triangle/proxy tests. They do not call the
    // production orientation, distance, point-in-polygon or clipping helpers.
    static double CrossOracle(UV2 a, UV2 b, UV2 c) {
        return (b.U-a.U)*(c.V-a.V)-(b.V-a.V)*(c.U-a.U);
    }
    static bool ConvexContainsOracle(List<UV2> closed, UV2 p) {
        bool pos=false,neg=false;
        for(int i=0;i<closed.Count-1;i++) {
            double c=CrossOracle(closed[i],closed[i+1],p);
            pos|=c>1e-10;neg|=c< -1e-10;
        }
        return !(pos&&neg);
    }
    static double SegmentDistanceOracle(UV2 p,UV2 a,UV2 b) {
        double u=b.U-a.U,v=b.V-a.V;
        double f=Math.Max(0,Math.Min(1,((p.U-a.U)*u+(p.V-a.V)*v)/(u*u+v*v)));
        double du=p.U-a.U-f*u,dv=p.V-a.V-f*v;return Math.Sqrt(du*du+dv*dv);
    }
    static double TriangleDistanceOracle(UV2 p,List<UV2> t) {
        var closed=new List<UV2>(t);closed.Add(t[0]);
        if(ConvexContainsOracle(closed,p))return 0;
        return Enumerable.Range(0,3).Min(i=>SegmentDistanceOracle(p,t[i],t[(i+1)%3]));
    }
    static List<UV2> Triangle(params double[] xy) {
        return new List<UV2>{new UV2(xy[0],xy[1]),new UV2(xy[2],xy[3]),new UV2(xy[4],xy[5])};
    }
    void CheckProxy(List<UV2> triangle,string name) {
        var proxy=CrearHuellaLaminaRepresentable(triangle,frame);
        Check(proxy!=null && LoopSeguro(proxy),name+" proxy is Revit-safe UV loop");
        foreach(var point in triangle)Check(ConvexContainsOracle(proxy.Puntos2D,point),name+" original vertex included");
        int ai=0,bi=1;double length=0;
        for(int i=0;i<3;i++)for(int j=i+1;j<3;j++) {
            double len=Math.Sqrt(Math.Pow(triangle[i].U-triangle[j].U,2)+Math.Pow(triangle[i].V-triangle[j].V,2));
            if(len>length){ai=i;bi=j;length=len;}
        }
        double u=(triangle[bi].U-triangle[ai].U)/length,v=(triangle[bi].V-triangle[ai].V)/length;
        Func<UV2,double> t=p=>(p.U-triangle[ai].U)*u+(p.V-triangle[ai].V)*v;
        Func<UV2,double> q=p=>-(p.U-triangle[ai].U)*v+(p.V-triangle[ai].V)*u;
        double ot0=triangle.Min(t),ot1=triangle.Max(t),oq0=triangle.Min(q),oq1=triangle.Max(q);
        double pt0=proxy.Puntos2D.Min(t),pt1=proxy.Puntos2D.Max(t),pq0=proxy.Puntos2D.Min(q),pq1=proxy.Puntos2D.Max(q);
        Check(ot0-pt0<=0.55*PTOL+1e-9 && pt1-ot1<=0.55*PTOL+1e-9,name+" local long-axis expansion bounded");
        Check(oq0-pq0<=0.55*PTOL+1e-9 && pq1-oq1<=0.55*PTOL+1e-9,name+" local short-axis expansion bounded");
        Check(pt1-pt0>=1.1*PTOL-1e-9 && pq1-pq0>=1.1*PTOL-1e-9,name+" minimum proxy side exceeds tolerance");
        foreach(var point in proxy.Puntos2D)Check(TriangleDistanceOracle(point,triangle)<=1.2*PTOL+1e-8,name+" added region stays close to original triangle");
        // Convexity: inclusion of all three original vertices proves the whole
        // triangle is included. Distance to a convex triangle is convex, so a
        // bound at rectangle vertices bounds its entire additional region.
        for(int i=0;i<=10;i++)for(int j=0;j<=10-i;j++) {
            double a=i/10.0,b=j/10.0,c=1-a-b;
            Check(ConvexContainsOracle(proxy.Puntos2D,new UV2(a*triangle[0].U+b*triangle[1].U+c*triangle[2].U,a*triangle[0].V+b*triangle[1].V+c*triangle[2].V)),name+" sampled original triangle included");
        }
    }
    void CheckThinFootprints() {
        var diamond=C(Poly(0,5,5,0,10,5,5,10,0,5));
        var triangle=Triangle(4,4,6,4,5,6);
        Check(LaminaCubiertaPorSeccionConvexa(triangle,diamond),"nonrectangular convex footprint covers triangle");
        var reverseDiamond=C(Poly(0,5,5,10,10,5,5,0,0,5));
        Check(LaminaCubiertaPorSeccionConvexa(triangle,reverseDiamond),"reverse convex footprint covers triangle");
        Check(!LaminaCubiertaPorSeccionConvexa(Triangle(4,4,12,4,5,6),diamond),"outside vertex cannot be ignored");
        var joined=C(Poly(0,0,10,0,10,3,3,3,3,10,0,10,0,0));
        var crossingNotch=Triangle(1,8,8,1,1,1);
        Check(!LaminaCubiertaPorSeccionConvexa(crossingNotch,joined),"concavity cannot be proved covered by vertices");
        Near(AreaContornoDentroDeTriangulo(joined.Exterior.Puntos2D,crossingNotch),20,"clipping L removes notch area analytically");
        Check(!LaminaCubiertaPorSeccion(crossingNotch,joined),"concave notch crossing not fully covered");
        Check(LaminaCubiertaPorSeccion(Triangle(0.5,0.5,9,0.5,0.5,2),joined),"triangle inside concave arm fully covered");
        Check(LaminaAlcanzaPerfil(crossingNotch,joined),"joined footprint real overlap remains");
        var withHole=C(Rect(0,10,0,10));withHole.Huecos.Add(Rect(3,7,3,7));
        Check(!LaminaCubiertaPorSeccionConvexa(Triangle(1,1,9,1,5,9),withHole),"hole forbids vertex-only coverage proof");
        Check(!LaminaAlcanzaPerfil(Triangle(4,4,6,4,5,6),withHole),"triangle wholly inside hole skipped");
        Check(!LaminaCubiertaPorSeccion(Triangle(4,4,6,4,5,6),withHole),"triangle in hole not covered");
        Check(!LaminaCubiertaPorSeccion(Triangle(1,1,9,1,5,9),withHole),"enclosed hole forbids full coverage");
        Check(LaminaCubiertaPorSeccion(Triangle(0.5,0.5,9,0.5,0.5,2),withHole),"unaffected triangle covered despite remote hole");
        Check(LaminaAlcanzaPerfil(Triangle(1,1,9,1,5,9),withHole),"triangle around hole still overlaps material");
        var topTriangle=Triangle(-100,5,100,5,0,105);
        Near(AreaContornoDentroDeTriangulo(withHole.Exterior.Puntos2D,topTriangle),50,"square top half clip area");
        Near(AreaContornoDentroDeTriangulo(withHole.Huecos[0].Puntos2D,topTriangle),8,"hole top half clip area");
        var uShape=C(Poly(0,0,10,0,10,10,8,10,8,2,2,2,2,10,0,10,0,0));
        Near(AreaContornoDentroDeTriangulo(uShape.Exterior.Puntos2D,topTriangle),20,"concave clipping keeps disconnected lobes");
        var reverseU=uShape.Exterior.Puntos2D.AsEnumerable().Reverse().Select(p=>new UV2(p.U,p.V)).ToList();
        Near(AreaContornoDentroDeTriangulo(reverseU,topTriangle),20,"reverse concave clipping disconnected area");
        var reversedTriangle=topTriangle.AsEnumerable().Reverse().ToList();
        Near(AreaContornoDentroDeTriangulo(uShape.Exterior.Puntos2D,reversedTriangle),20,"reverse triangle clipping area");
        var upperHole=Rect(0.5,1.5,6,8);uShape.Huecos.Add(upperHole);
        Near(AreaContornoDentroDeTriangulo(uShape.Exterior.Puntos2D,topTriangle)-AreaContornoDentroDeTriangulo(upperHole.Puntos2D,topTriangle),18,"disconnected clipping subtracts hole independently");
        double mm=1/304.8;
        var narrowHole=C(Rect(0,10,0,10));narrowHole.Huecos.Add(Rect(5,5+mm,2,8));
        var inMillimeterHole=Triangle(5+0.25*mm,3,5+0.25*mm,7,5+0.75*mm,5);
        Check(!LaminaAlcanzaPerfil(inMillimeterHole,narrowHole),"original triangle in 1mm hole skipped before regularization");
        var inflated=CrearHuellaLaminaRepresentable(inMillimeterHole,frame);
        Check(inflated.MinU<5 || inflated.MaxU>5+mm,"proxy alone would reach material across tiny hole");
        Check(!LaminaAlcanzaPerfil(Triangle(10+mm,2,10+mm,8,10+1.1*mm,4),C(Rect(0,10,0,10))),"original 1mm external gap remains separate");
        Check(LaminaAlcanzaPerfil(Triangle(10-0.1*mm,2,10-0.1*mm,8,10+0.1*mm,4),C(Rect(0,10,0,10))),"positive submillimeter original overlap retained");
        Check(!LaminaAlcanzaPerfil(Triangle(10,2,10,8,11,4),C(Rect(0,10,0,10))),"exact triangle tangent skipped");
        Check(!LaminaAlcanzaPerfil(Triangle(1,1,2,2,3,3),C(Rect(0,10,0,10))),"zero-area original triangle skipped");
        CheckProxy(Triangle(0,0,10,0,5,0.0001),"horizontal long sliver");
        CheckProxy(Triangle(0,0,0.0001,0,0,0.0001),"tiny local sliver");
        var thinRandom=new Random(792031);
        for(int test=0;test<100;test++) {
            double angle=thinRandom.NextDouble()*2*Math.PI,cu=Math.Cos(angle),cv=Math.Sin(angle);
            double length=0.004+50*thinRandom.NextDouble(),height=PTOL*(0.0001+0.9998*thinRandom.NextDouble());
            double x=2000*(thinRandom.NextDouble()-0.5),y=2000*(thinRandom.NextDouble()-0.5);
            double fraction=0.01+0.98*thinRandom.NextDouble();
            var t=Triangle(x,y,x+length*cu,y+length*cv,x+fraction*length*cu-height*cv,y+fraction*length*cv+height*cu);
            CheckProxy(t,"translated rotated sliver "+test);
        }
        var longDiagonal=Triangle(100,200,1100,1200,600-0.0001,700+0.0001);
        var localProxy=CrearHuellaLaminaRepresentable(longDiagonal,frame);
        Check(localProxy.AreaAbs<10,"sliver proxy cannot become whole diagonal axis-aligned bbox");
        CheckProxy(longDiagonal,"long diagonal local envelope");
    }

    LoopMuro ReverseLoop(LoopMuro loop) {
        return LoopDesdeUV(loop.Puntos2D.AsEnumerable().Reverse()
            .Select(p=>new UV2(p.U,p.V)).ToList(),loop.Marco);
    }
    void CheckNestedComponents() {
        var outer=Rect(0,20,0,20);var opening=Rect(2,18,2,18);
        var island=Rect(4,16,4,16);var innerOpening=Rect(6,14,6,14);
        var simple=ClasificarComponentes(new List<LoopMuro>{opening,outer});
        Check(simple.Count==1 && Similar(simple[0].Exterior,outer) && simple[0].Huecos.Count==1 &&
            Similar(simple[0].Huecos[0],opening),"ordinary outer and hole remain one component");

        var ring=ClasificarComponentes(new List<LoopMuro>{island,outer,opening});
        Check(ring.Count==2,"annular cut retains island as a second component");
        var ringOuter=ring.Single(c=>Similar(c.Exterior,outer));
        var ringIsland=ring.Single(c=>Similar(c.Exterior,island));
        Check(ringOuter.Huecos.Count==1 && Similar(ringOuter.Huecos[0],opening),
            "ring opening belongs only to outer component");
        Check(ringIsland.Huecos.Count==0,"depth-two island is material, not another hole");
        Near(ring.Sum(c=>c.Exterior.AreaAbs-c.Huecos.Sum(h=>h.AreaAbs)),288,"ring retained material area");

        var disjointOuter=Rect(30,40,0,10);var disjointHole=Rect(32,38,2,8);
        var loops=new List<LoopMuro>{innerOpening,island,opening,outer,disjointHole,disjointOuter};
        var orders=new Random(563829);
        for(int test=0;test<24;test++) {
            // Alternate windings and random input order must not affect parenthood.
            var shuffled=loops.Select((p,i)=>((i+test)%2==0?ReverseLoop(p):p))
                .OrderBy(p=>orders.Next()).ToList();
            var components=ClasificarComponentes(shuffled);
            Check(components.Count==3,"three material islands independent of winding/order "+test);
            var outerComponent=components.Single(c=>Similar(c.Exterior,outer));
            var islandComponent=components.Single(c=>Similar(c.Exterior,island));
            var disjointComponent=components.Single(c=>Similar(c.Exterior,disjointOuter));
            Check(outerComponent.Huecos.Count==1 && Similar(outerComponent.Huecos[0],opening),
                "depth-one opening attached to immediate outer parent "+test);
            Check(islandComponent.Huecos.Count==1 && Similar(islandComponent.Huecos[0],innerOpening),
                "depth-three opening attached to immediate island parent "+test);
            Check(disjointComponent.Huecos.Count==1 && Similar(disjointComponent.Huecos[0],disjointHole),
                "disjoint exterior retains only its own hole "+test);
            Near(components.Sum(c=>c.Exterior.AreaAbs-c.Huecos.Sum(h=>h.AreaAbs)),288,
                "alternating depth material area "+test);
        }
        loops.Add(ReverseLoop(outer));loops.Add(ReverseLoop(opening));
        var duplicates=ClasificarComponentes(loops);
        Check(duplicates.Count==3 && duplicates.Sum(c=>c.Huecos.Count)==3,
            "cyclic/reversed duplicates do not alter nesting parity");

        var triangleA=Poly(0,0,10,0,0,10,0,0);
        var triangleB=Poly(10,0,10,10,0,10,10,0);
        Check(ClasificarComponentes(new List<LoopMuro>{triangleA,triangleB}).Count==2,
            "distinct complementary triangles with same area and bbox remain separate");
        Check(ClasificarComponentes(null).Count==0 && ClasificarComponentes(new List<LoopMuro>()).Count==0,
            "empty classifier input returns no components");
    }

    public void Run() {
        CheckNestedComponents();
        CheckThinFootprints();
        var basis=C(Rect(0,10,0,10));
        Near(Cut(basis,C(Rect(20,30,20,30))).Sum(x=>x.AreaAbs),100,"no overlap preserves area");
        Near(Cut(basis,C(Rect(10,20,0,10))).Sum(x=>x.AreaAbs),100,"edge tangent preserves area");
        Near(Cut(basis,C(Rect(10,20,10,20))).Sum(x=>x.AreaAbs),100,"corner tangent preserves area");
        Check(Cut(basis,C(Rect(-1,11,-1,11))).Count==0,"full cover removes all");
        var top=Cut(basis,C(Rect(-1,11,7,11)));
        Check(top.Count==1,"top strip leaves one rectangle"); Near(top.Sum(x=>x.AreaAbs),70,"top strip area");
        var right=Cut(basis,C(Rect(7,11,-1,11)));
        Check(right.Count==1,"right strip leaves one rectangle"); Near(right.Sum(x=>x.AreaAbs),70,"right strip area");
        var hole=Cut(basis,C(Rect(3,7,3,7)));
        Check(hole.Count==4,"internal opening leaves four pieces"); Near(hole.Sum(x=>x.AreaAbs),84,"internal opening area");
        var split=Cut(basis,C(Rect(4,6,-1,11)));
        Check(split.Count==2,"middle divider leaves two walls");Near(split.Sum(x=>x.AreaAbs),80,"middle divider area");
        var union=Cut(basis,C(Rect(2,6,2,6)),C(Rect(4,8,4,8)));
        Near(union.Sum(x=>x.AreaAbs),72,"overlapping cuts remove union once");
        var repeated=Cut(basis,C(Rect(2,6,2,6)),C(Rect(2,6,2,6)));
        Near(repeated.Sum(x=>x.AreaAbs),84,"duplicate cuts remove once");
        List<LoopMuro> ignored;
        Check(!RestarRectangulosEnPlano(basis,new List<ComponenteMuro>{C(Poly(0,0,5,0,0,5,0,0))},out ignored),"nonrectangle cutter rejected");
        var cutterWithHole=C(Rect(2,8,2,8)); cutterWithHole.Huecos.Add(Rect(3,7,3,7));
        Check(!RestarRectangulosEnPlano(basis,new List<ComponenteMuro>{cutterWithHole},out ignored),"cutter with hole rejected");
        var baseWithHole=C(Rect(0,10,0,10));baseWithHole.Huecos.Add(Rect(3,7,3,7));
        Check(!RestarRectangulosEnPlano(baseWithHole,new List<ComponenteMuro>{C(Rect(2,8,2,8))},out ignored),"base with hole rejected");
        Check(!RestarRectangulosEnPlano(basis,new List<ComponenteMuro>(),out ignored),"empty cutter list rejected");
        var a=Rect(0,10,0,10);
        var cyclic=Poly(10,0,10,10,0,10,0,0,10,0);
        var reversed=Poly(0,0,0,10,10,10,10,0,0,0);
        Check(Similar(a,cyclic),"cyclic footprint equal"); Check(Similar(a,reversed),"reversed footprint equal");
        var rotatedFrame=new MarcoMuro {Origen=new XYZ(100,40,2),U=new XYZ(0,1,0),V=new XYZ(0,0,1),Normal=new XYZ(1,0,0)};
        var axisBefore=frame;frame=rotatedFrame;var rotated=Rect(0,10,0,10);frame=axisBefore;
        Check(Similar(a,rotated),"same UV footprint in rotated frame");
        var triangle1=Poly(0,0,10,0,0,10,0,0);var triangle2=Poly(0,0,10,10,0,10,0,0);
        Near(triangle1.AreaAbs,triangle2.AreaAbs,"diagonal triangles same area");
        Check(!Similar(triangle1,triangle2),"diagonal triangles with same bbox distinguished");
        var ca=C(a);ca.Huecos.Add(Rect(2,3,2,3));ca.Huecos.Add(Rect(6,8,6,8));
        var cb=C(reversed);cb.Huecos.Add(Rect(6,8,6,8));cb.Huecos.Add(Rect(2,3,2,3));
        Check(HuellasIguales(ca,cb),"same holes in different order equal");cb.Huecos[0]=Rect(5,8,6,8);
        Check(!HuellasIguales(ca,cb),"different holes distinguished");
        Check(EsRectangulo(Poly(0,0,10,0.001,9.999,10,0.001,9.999,0,0)),"jittered corners rectangle");
        Check(!EsRectangulo(Poly(0,5,5,0,10,5,5,10,0,5)),"diagonal diamond rejected");
        Near(Cut(basis,C(Rect(9.999,11,0,10))).Sum(x=>x.AreaAbs),99.99,"thin real edge intersection trimmed");
        Check(Cut(basis,C(Rect(0.001,11,-1,11))).Count==0,"uncreatable sub-tolerance sliver omitted");
        // PTOL es una longitud (.9144 mm), no un área. La validación de
        // cruces debe dar el mismo resultado en perfiles pequeños y grandes.
        const double mm=1.0/304.8;
        for (int milimetros=1;milimetros<=3;milimetros++) {
            double ancho=milimetros*mm;
            var pequeno=Rect(0,ancho,0,10*mm);
            Check(pequeno!=null && LoopSeguro(pequeno),"safe "+milimetros+" mm wide rectangle");
            Check(EsRectangulo(pequeno),"rectangular "+milimetros+" mm wide profile");

            double diagonal=10*mm/Math.Sqrt(2), separacion=ancho/Math.Sqrt(2);
            var inicio=new UV2(0,0);var fin=new UV2(diagonal,diagonal);
            var paraleloInicio=new UV2(-separacion,separacion);
            var paraleloFin=new UV2(diagonal-separacion,diagonal+separacion);
            Check(!SegmentosIntersectan2D(inicio,fin,paraleloInicio,paraleloFin,false),
                "rotated parallel segments separated "+milimetros+" mm do not intersect");
            Check(!PuntoEnSegmento2D(paraleloInicio,inicio,fin),
                "point "+milimetros+" mm off short diagonal segment rejected");
            Check(!Igual(inicio,paraleloInicio),
                "diagonal endpoints "+milimetros+" mm apart remain distinct");
            var girado=Poly(0,0,diagonal,diagonal,diagonal-separacion,diagonal+separacion,
                -separacion,separacion,0,0);
            Check(girado!=null && LoopSeguro(girado),
                "safe rotated "+milimetros+" mm wide rectangle survives cleanup");
        }
        Check(Igual(new UV2(0,0),new UV2(0.5*mm/Math.Sqrt(2),0.5*mm/Math.Sqrt(2))),
            "diagonal endpoints within tolerance merge");
        Check(!Igual(null,new UV2(0,0)),"missing UV point is not equal");
        Check(SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,10*mm),
            new UV2(0,10*mm),new UV2(10*mm,0),false),"small true crossing detected");
        Check(SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(10*mm,0),new UV2(10*mm,10*mm),false),"endpoint contact detected when forbidden");
        Check(!SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(10*mm,0),new UV2(10*mm,10*mm),true),"endpoint-only contact allowed");
        Check(SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(5*mm,0),new UV2(5*mm,10*mm),true),"T contact remains an intersection");
        Check(SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(0,0),new UV2(5*mm,0),true),"shared endpoint does not hide collinear overlap");
        Check(SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(0,0),new UV2(10*mm,0),true),"identical segment is overlap, not endpoint-only contact");
        Check(SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(10*mm,0),new UV2(0,0),true),"reversed identical segment remains overlap");
        Check(!SegmentosIntersectan2D(new UV2(0,0),new UV2(10*mm,0),
            new UV2(12*mm,0),new UV2(20*mm,0),false),"disjoint collinear segments remain separate");
        Check(!PuntoEnSegmento2D(new UV2(12*mm,0),new UV2(0,0),new UV2(10*mm,0)),
            "point beyond endpoint tolerance rejected");
        Check(PuntoEnSegmento2D(new UV2(5*mm,0),new UV2(0,0),new UV2(10*mm,0)),
            "point inside short segment accepted");
        var random=new Random(35207);
        for (int test=0;test<100;test++) {
            var cuts=new List<ComponenteMuro>();
            for(int k=0;k<5;k++) {
                int x0=random.Next(-3,13),x1=random.Next(-3,13),y0=random.Next(-3,13),y1=random.Next(-3,13);
                cuts.Add(C(Rect(Math.Min(x0,x1),Math.Max(x0,x1)+1,Math.Min(y0,y1),Math.Max(y0,y1)+1)));
            }
            double expected=0;
            for(int x=0;x<10;x++) for(int y=0;y<10;y++)
                if(!cuts.Any(c=>x+0.5>c.Exterior.MinU&&x+0.5<c.Exterior.MaxU&&y+0.5>c.Exterior.MinV&&y+0.5<c.Exterior.MaxV)) expected++;
            Near(Cut(basis,cuts.ToArray()).Sum(x=>x.AreaAbs),expected,"seeded integer grid area "+test);
        }
        Check(SOBREPASO_PERFIL>BOOLEAN_RETRY_OFFSET,"cutter overtravel exceeds boolean translation");
        Console.WriteLine("Total assertions passed: " + passed);
    }
    static int Main() { try { new Harness().Run(); return 0; } catch(Exception e) { Console.Error.WriteLine(e);return 1;} }
'''
stub = r'''
public class XYZ {
    public double X,Y,Z;
    public XYZ(double x,double y,double z) {X=x;Y=y;Z=z;}
    public XYZ Multiply(double a) {return new XYZ(X*a,Y*a,Z*a);}
    public static XYZ operator +(XYZ a,XYZ b) {return new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);}
}
'''
src = '\n'.join(['using System;using System.Collections.Generic;using System.Linq;', stub, *classes,
                 'class Harness {', *constants, *methods, tests, '}'])
out = BASE / 'geometry'
out.mkdir(exist_ok=True)
(out/'Geometry.cs').write_text(src)
refs=list(refdirs[-1].glob('*.dll'))
rsp=out/'compile.rsp'
rsp.write_text('\n'.join(['-nologo','-langversion:7.3','-nostdlib+','-target:exe','-out:'+str(out/'Geometry.dll')]+['-r:'+str(p) for p in refs]+[str(out/'Geometry.cs')]))
subprocess.run([str(DOTNET),str(compilers[-1]),'@'+str(rsp)],check=True)
(out/'Geometry.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'framework':{'name':'Microsoft.NETCore.App','version':runtimes[-1].name}}}))
subprocess.run([str(DOTNET),str(out/'Geometry.dll')],check=True)
