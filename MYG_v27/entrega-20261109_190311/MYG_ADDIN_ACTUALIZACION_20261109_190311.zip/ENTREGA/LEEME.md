# Actualización: respaldo para suelos y caras inclinadas

Base de trabajo: bimchimbote-droid/MYG_v27_reestructurado, commit fuente 56682a0299f9cb62dacecce6ef269a13c864c4b3, rama local work. Se conservan todos los cambios locales de las entregas anteriores. Base acumulada: ZIP MYG_ADDIN_ACTUALIZACION_20261109_185151.zip, DESCARGAS commit 39ef8f3268a447a0332565a78417c097ec11bd24, SHA-256 5c008ae2aba545b9d6e36918666727107546989244f768520968c442342ff589. El handler de suelos no cambió en las últimas entregas y su base exacta es el ZIP MYG_ADDIN_ACTUALIZACION_20261109_182724.zip (commit 9bd583210f8ac7c71e6ab736ce74a29ee00ff64c). No se sustituyó la copia por MYG_v27/main ni se modificaron sus ramas.

## Implementación

Si fallan Intersect, Difference o la huella del suelo, se recalcula el recorte completo con el motor planar robusto en un marco ortonormal de la cara inclinada. Se usan los candidatos originales ya filtrados/transformados por suelos; se conservan exclusiones del anfitrión, escaleras, visibilidad y vínculos. No crea muros ni vuelve a recoger candidatos. Se descartan los recortes parciales del intento fallido y se devuelven perfiles en el plano original con todas las islas y huecos. Se corrige su clasificación por profundidad de anidación. Un resultado vacío no restaura el perfil original.

La tolerancia de las aristas regularizadas considera su acortamiento al proyectar a XY: mínimo1.1*ShortCurveTolerance/|Normal.Z|. Se rechaza una regularización superior a2*PTOL (aprox.1.829mm); no se agrandan arbitrariamente los recortes en pendientes extremas. Conserva los cambios previos de milímetros y selección continua. El recorrido normal que ya funciona, Floor.Create y SlabShapeEditor se mantienen.

## Instalación

1. Cerrar Revit, respaldar la solución y DLL actuales. Comparar cambios locales/posteriores: sustituir archivos completos puede sobrescribirlos.
2. REEMPLAZAR JUNTOS los dos handlers .cs, conservando sus rutas de ARCHIVOS.json. El de suelos depende del nuevo método público del de muros. Ambos ya están incluidos en el proyecto: no agregarlos de nuevo. Conservar el selector anterior.
3. Alternativa al reemplazo: desde la raíz compatible con las entregas anteriores, ejecutar `git apply --check RUTA/ENTREGA/ACTUALIZACION.patch` y después `git apply RUTA/ENTREGA/ACTUALIZACION.patch`. No aplicar ambas opciones. El parche se comprobó sobre las versiones base indicadas y reproduce los dos archivos finales byte por byte. Si falla, comparar/integrar sin forzar.
4. Copiar las pruebas/documentación si se desean conservar. Los scripts Python son externos: NO incluirlos en la compilación del add-in. No hay eliminaciones.
5. Compilar en Visual Studio sobre Windows y actualizar la DLL de una instalación de prueba con Revit cerrado. Mantener manifiesto.addin, iconos y dependencias existentes. Probar una copia del modelo de la captura. No se entrega DLL nueva.

## Configuración

Sin paquetes, referencias ni cambios de .csproj/.slnx. Se mantiene la configuración actual .NET Framework4.8, referencias Revit2027 y COM Office/Excel; su compatibilidad real debe comprobarse en Windows. Nombres, namespaces, botones y ventanas sin cambios.

## Validación

-179 archivos activos pasan análisis de sintaxis Roslyn C#7.3; no es compilación completa.
-10656 aserciones aprobadas, incluidas islas anidadas y huecos.
-575 aserciones del adaptador inclinado aprobadas: marcos, retorno al plano original, tolerancias, perfiles, candidatos y fallos.
-20 aserciones de integración de suelos aprobadas: disparadores del respaldo, originalidad de loops/candidatos, descarte de sólido parcial, huecos/islas, ocupación completa y doble diagnóstico.
-git diff --check limpio; parche aplicado y comparado con archivos finales.

Repetir con Python3 y SDK.NET8 o posterior completo instalado, sin NuGet/descargas:

```sh
python Pruebas/probar_geometria_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
python Pruebas/probar_perfil_inclinado_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
python Pruebas/probar_respaldo_suelos_tarrajeo.py --dotnet RUTA_AL_EJECUTABLE_DOTNET
```

Scripts con --help, probados en Linux; usar rutas compatibles/WSL para otros sistemas. Se extrae código actual con sustitutos de API y motor programado donde corresponde, sin kernel real de Revit.

## Limitaciones y comprobación pendiente

No se compiló el add-in completo ni se generó DLL: entorno Linux sin Revit, MSBuild de.NET Framework ni COM Office. Probar en Revit la cara inclinada de la captura, caras superiores/inferiores, islas, huecos, vínculos transformados y varias interferencias. Medir el contacto real y espesor del suelo inclinado: se conserva el cálculo actual (sonda normal y desfase vertical de SlabShapeEditor), cuya equivalencia física no se certifica sin Revit. El respaldo puede linealizar curvas y regularizar láminas con un pequeño recorte adicional; no se garantiza exactitud submilimétrica. Las pendientes/contornos no representables siguen avisando sin terminar la selección.

## GitHub

Solo se publica este ZIP en una ruta nueva de bimchimbote-droid/DESCARGAS, preservando entregas previas. No instala cambios en tu PC ni actualiza ramas de MYG_v27/MYG_v27_reestructurado. En Visual Studio revisar Cambios de Git, comparar, hacer Commit local y usar Push solo cuando decidas sincronizar tu código. No se hizo ese Push.
