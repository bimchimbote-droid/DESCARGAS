# Actualización MYG: buscadores y orientación del tarrajeo

## Base utilizada
Repositorio seleccionado: bimchimbote-droid/MYG_v27_reestructurado, rama master.
Commit base: 56682a0299f9cb62dacecce6ef269a13c864c4b3.
El checkout no tenía cambios locales al iniciar. Se conservaron proyecto, namespaces, recursos y versiones de dependencias. No se sustituyó por MYG_v27/main: el documento aportado menciona ese repositorio, pero la copia actual seleccionada es la reestructurada. Esta entrega usa las rutas de la copia seleccionada.

## Comportamiento
Los selectores de tipo de suelo y muro permiten reemplazar el texto seleccionado y buscar mientras se escribe. El filtrado se aplica en el siguiente turno de eventos, sin reconstruir Items dentro de la notificación de edición nativa. Se preservan consulta/cursor y se gestionan listas vacías, confirmación y cancelación.
Los nuevos muros de tarrajeo verifican la normal de su cara exterior física después de regenerar. Se invierten si es necesario para que la primera capa exterior del tipo (Acabado 2/pintura en el ejemplo) mire fuera del elemento revestido. Se conserva la estructura de capas del tipo. En arcos se compara en el punto medio, también para superficies cóncavas. No se cambia automáticamente ningún muro ya creado.

## Archivos del add-in
| Acción | Ruta | Cambio |
|---|---|---|
| REEMPLAZAR | MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoForm.cs | Filtro compartido de los selectores. |
| REEMPLAZAR | MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs | Orientación exterior de los muros creados. |

No hay archivos del add-in para CREAR o ELIMINAR. MYG.csproj, packages.config, recursos y demás fuentes: SIN CAMBIOS, fuera del ZIP. CAMBIOS.patch es una alternativa MODIFICAR para aplicar los mismos cambios mediante parche; no aplicar además de reemplazar los archivos.

## Instalación
1. Cierra Revit y respalda tu solución, DLL y dependencias actuales.
2. Extrae el ZIP en una carpeta temporal. Compara las rutas y el commit base con tu versión. Reemplazar archivos completos puede sobrescribir modificaciones locales o posteriores; combina tus cambios si existen. Si usas la versión monolítica de MYG_v27/main, estas rutas no son equivalentes y no debes copiar archivos a ciegas.
3. Copia únicamente los dos archivos de MYG/ sobre las mismas rutas de tu solución reestructurada. Ya están incluidos en el proyecto; no agregues archivos adicionales al add-in.
4. Alternativa desde la raíz del checkout: git apply --check /ruta/CAMBIOS.patch y, si no hay conflictos, git apply /ruta/CAMBIOS.patch. No usar ambas vías.
5. Compila en Visual Studio/Windows con MSBuild de .NET Framework, referencias reales de Revit y COM de Office. No copies las pruebas al proyecto MYG. Conserva el manifiesto .addin y los iconos de tu instalación.
6. Con Revit cerrado, actualiza la DLL y dependencias de tu instalación de prueba. Abre un modelo de prueba y comprueba los casos indicados abajo. Los revestimientos existentes no se reorientan: vuelve a generarlos de forma controlada si necesitas actualizarlos.

## Configuración
No se agregan paquetes, referencias ni cambios de configuración. Se mantiene .NET Framework 4.8 y las referencias de Revit 2027 del proyecto. Su compatibilidad real debe verificarse en el equipo Windows. El SDK .NET 10 usado en Linux es solo herramienta de revisión, no una migración del add-in.

## Validación y límites
La revisión de sintaxis Roslyn C# 7.3 abarca los 179 archivos activos; se verifican también 9 recursos y 3 None, sin archivos faltantes ni duplicados. No equivale a compilación.
La compilación se intentó en Linux: se detiene en MSB4803 (ResolveComReference requiere MSBuild de .NET Framework). También reproduce la advertencia previa MSB3277 por EPPlus.Interfaces; no se actualizan dependencias para ocultarla. No se generó una DLL nueva.
Las pruebas aisladas incluidas utilizan dobles de las APIs. Sus resultados exactos se registran en VALIDACION.md. No prueban controles nativos de Windows ni geometría ejecutada por Revit.
Pendiente en Revit: seleccionar todo o parte del nombre, escribir y pegar, borrar, consultas sin coincidencias, Enter/Escape y selección con ratón en ambos tipos y ventanas. Crear muros de tarrajeo en caras opuestas, perfiles y arcos cóncavos/convexos, con y sin unión y en vínculos, y verificar que la pintura mire fuera sin desplazar el revestimiento. El cambio respeta el orden exterior/interior definido en el tipo; no mueve una capa definida como interior al exterior.

## GitHub
El ZIP se publica por autorización expresa únicamente en DESCARGAS, conservando entregas anteriores. No se hace push al repositorio del código. Descargar o publicar este ZIP no cambia tu PC ni actualiza MYG_v27 o MYG_v27_reestructurado.
En Visual Studio, revisa Git Changes y los diffs, compila y prueba; después crea tu commit y usa Push cuando decidas guardar esos cambios en el repositorio correcto.
