# Resultados de esta entrega

- Base real: bimchimbote-droid/MYG_v27_reestructurado master, 56682a0299f9cb62dacecce6ef269a13c864c4b3. Estado inicial sin cambios locales. Solo se modificaron las dos fuentes del manifiesto. No se hizo commit ni push al repositorio del código.
- git diff --check: correcto.
- Revisión estática Roslyn C# 7.3: 179 Compile sin errores sintácticos; 9 EmbeddedResource y 3 None presentes, sin duplicados. No es compilación del add-in.
- Regresiones de buscador (helper real + doble de ComboBox): 12 pasan, 0 fallan. La base falla con Items mutated inside native TextUpdate. Se verifican edición seleccionada/cursor, consulta vacía/sin coincidencias, Enter/Escape, confirmación, cola de eventos y pérdida de foco.
- Regresiones de orientación (helper real + dobles API): 15/15 pasan en la versión final; 8/15 en la base, con 7 fallos. Se prueban caras opuestas, regeneración, normal media de arcos convexos/cóncavos, eje al voltear y errores de orientación.
- Compilación aislada del helper de orientación contra RevitAPI.dll incluida: 0 errores, 3 advertencias de dependencias Microsoft.VisualBasic/System.Drawing/WindowsBase. Esto solo verifica firmas del helper, no el add-in completo.
- Compilación completa intentada en Linux con SDK 10.0.403 y reference assemblies net48: bloqueada por MSB4803 ResolveComReference (exige MSBuild de .NET Framework). Advertencia preexistente MSB3277 EPPlus.Interfaces reproducida. No se generó DLL nueva.
- No se ejecutó Windows/WinForms nativo ni Autodesk Revit. No se validaron aún selección real/pegado/teclado en controles nativos ni materiales/capas, geometría, perfiles, vínculos y uniones dentro del modelo. Ver instrucciones para la prueba funcional pendiente.

Las carpetas Tests son proyectos de pruebas opcionales separados; no necesitan incorporarse a MYG.csproj. No instalan dependencias nuevas en el add-in.
