// Minimal simulation for control flow and vector arithmetic, not Revit geometry.
using System;
using System.Collections.Generic;
namespace Autodesk.Revit.DB
{
    public class XYZ
    {
        public double X, Y, Z;
        public XYZ(double x, double y, double z) { X=x; Y=y; Z=z; }
        public double GetLength() { return Math.Sqrt(X*X+Y*Y+Z*Z); }
        public XYZ Normalize() { return Multiply(1.0/GetLength()); }
        public XYZ Multiply(double factor) { return new XYZ(X*factor,Y*factor,Z*factor); }
        public double DotProduct(XYZ other) { return X*other.X+Y*other.Y+Z*other.Z; }
    }
    public enum BuiltInParameter { WALL_KEY_REF_PARAM }
    public enum StorageType { Integer }
    public enum ShellLayerType { Exterior }
    public class Parameter
    {
        public bool IsReadOnly;
        public StorageType StorageType = StorageType.Integer;
        public int Value = 2;
        public bool Set(int value) { Value=value; return true; }
    }
    public class Document
    {
        public int Regenerations;
        public bool FailRegeneration;
        public void Regenerate()
        {
            if (FailRegeneration) throw new InvalidOperationException("Simulated regeneration failure");
            Regenerations++;
        }
    }
    public class Curve { public XYZ Evaluate(double t, bool normalized) { return new XYZ(0,0,0); } }
    public class LocationCurve { public Curve Curve = new Curve(); }
    public class UV { }
    public class IntersectionResult { public UV UVPoint = new UV(); }
    public class Reference { public Face Face; }
    public class Face
    {
        public XYZ Normal;
        public double Area = 100;
        public virtual XYZ ComputeNormal(UV uv) { return Normal; }
        public IntersectionResult Project(XYZ point) { return new IntersectionResult(); }
    }
    public class PlanarFace : Face { public XYZ FaceNormal { get { return Normal; } } }
    public class Wall
    {
        public Document Document = new Document();
        public Parameter Key = new Parameter();
        public object Location = new LocationCurve();
        public Face Exterior;
        public XYZ StartNormal;
        public XYZ StaleNormal;
        public bool FlipWorks = true;
        public bool RequireCenterlineForFlip;
        public int Flips;
        public XYZ Orientation
        {
            get { return Document.Regenerations == 0 && StaleNormal != null ? StaleNormal : StartNormal; }
        }
        public Parameter get_Parameter(BuiltInParameter parameter) { return Key; }
        public Face GetGeometryObjectFromReference(Reference reference) { return reference.Face; }
        public void Flip()
        {
            Flips++;
            if (RequireCenterlineForFlip && Key.Value != 0)
                throw new InvalidOperationException("Flip would move wall about the wrong location line");
            if (!FlipWorks) return;
            StartNormal = StartNormal.Multiply(-1);
            if (Exterior != null) Exterior.Normal = Exterior.Normal.Multiply(-1);
        }
    }
    public static class HostObjectUtils
    {
        public static IList<Reference> GetSideFaces(Wall wall, ShellLayerType side)
        {
            return wall.Exterior == null ? new List<Reference>() : new List<Reference> { new Reference { Face=wall.Exterior } };
        }
    }
}
