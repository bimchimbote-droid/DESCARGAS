#!/usr/bin/env python3
"""Run the actual orientation helper against API doubles; this does not run Revit."""
import argparse
import pathlib
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('repository', type=pathlib.Path)
parser.add_argument('--ref', help='Read helper from this Git ref instead of the working copy')
args = parser.parse_args()
relative = 'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs'
if args.ref:
    source = subprocess.check_output(['git', '-C', str(args.repository), 'show', args.ref + ':' + relative], text=True)
else:
    source = (args.repository / relative).read_text(encoding='utf-8-sig')
start = source.index('    private void OrientarMuro(Wall wall, XYZ normal)')
end = source.index('    private void ConfigurarLineaUbicacionExterior(Wall wall)', start)
root = pathlib.Path(__file__).resolve().parent
(root / 'GeneratedMotor.cs').write_text('''// Generated from the selected source; do not edit.
using System;
using System.Linq;
using Autodesk.Revit.DB;
public class Motor
{
    private const double TOL = 1e-6;
    public void Orientar(Wall wall, XYZ normal) { OrientarMuro(wall, normal); }
''' + source[start:end] + '}\n')
raise SystemExit(subprocess.run(['dotnet', 'run', '--project', str(root / 'Regression.csproj')]).returncode)
