# Regresión aislada de orientación

Requiere Python 3 y SDK .NET 10. Desde la raíz del código/ZIP extraído:

```sh
python3 Tests/OrientacionMuro/run.py .
```

En Windows puedes usar `py` en lugar de `python3`. No agregues este proyecto de pruebas al add-in ni copies su salida a Revit. El script extrae el helper REAL del archivo de producción y genera GeneratedMotor.cs temporalmente junto al proyecto de pruebas; no mantiene una copia del motor. Se compila y ejecuta con dobles de la API, no con Revit.

Resultado: versión final 15/15; commit base 56682a0 8/15 (7 fallos). Cubre normales planas en ambos sentidos, regeneración previa, arcos convexos/cóncavos por punto medio, volteo respecto al eje y rechazo si Flip, geometría o regeneración fallan. No prueba operaciones reales ni transacciones de Autodesk Revit, ni los recortes/uniones del motor completo.

Para probar la base desde un checkout que tenga el commit: `python3 Tests/OrientacionMuro/run.py /ruta/al/checkout --ref 56682a0299f9cb62dacecce6ef269a13c864c4b3`. El fallo de los casos de regresión en la base es esperado; la herramienta devuelve salida distinta de cero.
