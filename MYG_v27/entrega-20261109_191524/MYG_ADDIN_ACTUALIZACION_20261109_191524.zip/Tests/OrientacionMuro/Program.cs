using Autodesk.Revit.DB;
int count = 0;
int failed = 0;
void Check(string name, Action action)
{
    count++;
    try { action(); Console.WriteLine("PASS " + name); }
    catch (Exception e) { failed++; Console.WriteLine("FAIL " + name + ": " + e.Message); }
}
void Require(bool ok, string message) { if (!ok) throw new Exception(message); }
Wall NewWall(XYZ normal, bool curved = false)
{
    return new Wall { StartNormal = normal, Exterior = curved ? new Face { Normal=normal } : new PlanarFace { Normal=normal } };
}
void ExpectFailure(Wall wall, XYZ target)
{
    bool threw = false;
    try { new Motor().Orientar(wall, target); }
    catch (InvalidOperationException) { threw = true; }
    Require(threw, "unverified orientation was accepted");
}
var directions = new[] { new XYZ(1,0,0), new XYZ(-1,0,0), new XYZ(0,1,0), new XYZ(0,-1,0) };
for (int i=0; i<directions.Length; i++)
{
    XYZ direction = directions[i];
    Check("planar already aligned " + i, () => {
        Wall wall=NewWall(direction);
        new Motor().Orientar(wall,direction);
        Require(wall.Flips==0 && wall.Exterior.Normal.DotProduct(direction)>0.99,"aligned wall was flipped");
    });
    Check("planar reversed " + i, () => {
        Wall wall=NewWall(direction.Multiply(-1));
        new Motor().Orientar(wall,direction);
        Require(wall.Flips==1 && wall.Exterior.Normal.DotProduct(direction)>0.99,"reversed wall was not corrected");
    });
}
var outward = new XYZ(0,1,0);
Check("regenerate before reading new wall geometry", () => {
    Wall wall=NewWall(outward); wall.StaleNormal=outward.Multiply(-1);
    new Motor().Orientar(wall,outward);
    Require(wall.Document.Regenerations>0 && wall.Flips==0,"stale initial orientation used");
});
Check("convex arc uses midpoint exterior, not start normal", () => {
    Wall wall=NewWall(outward,true); wall.StartNormal=outward.Multiply(-1);
    new Motor().Orientar(wall,outward);
    Require(wall.Flips==0 && wall.Exterior.Normal.DotProduct(outward)>0.99,"start normal flipped a correct arc");
});
Check("concave arc keeps inward radial exterior", () => {
    XYZ inward=outward.Multiply(-1); Wall wall=NewWall(inward,true); wall.StartNormal=outward;
    new Motor().Orientar(wall,inward);
    Require(wall.Flips==0 && wall.Exterior.Normal.DotProduct(inward)>0.99,"concave arc exterior inverted");
});
Check("flip around centerline", () => {
    Wall wall=NewWall(outward.Multiply(-1)); wall.RequireCenterlineForFlip=true;
    new Motor().Orientar(wall,outward);
    Require(wall.Key.Value==0 && wall.Exterior.Normal.DotProduct(outward)>0.99,"location line not normalized");
});
Check("failed flip is rejected", () => {
    Wall wall=NewWall(outward.Multiply(-1)); wall.FlipWorks=false;
    ExpectFailure(wall,outward);
});
Check("missing exterior face is rejected", () => {
    Wall wall=NewWall(outward); wall.Exterior=null;
    ExpectFailure(wall,outward);
});
Check("regeneration failure propagates to transaction owner", () => {
    Wall wall=NewWall(outward); wall.Document.FailRegeneration=true;
    ExpectFailure(wall,outward);
});
Console.WriteLine($"{count-failed}/{count} simulated orientation checks passed; Revit has not been executed.");
return failed==0 ? 0 : 1;
