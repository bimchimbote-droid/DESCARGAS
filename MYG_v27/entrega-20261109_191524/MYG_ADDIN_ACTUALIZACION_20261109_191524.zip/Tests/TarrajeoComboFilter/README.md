# Regresión del buscador de tipos de Tarrajeo

Pruebas aisladas, opcionales, con SDK .NET 10; no añadas este proyecto a la solución del add-in ni copies su salida a Revit. No necesita paquetes NuGet externos. Utiliza las bibliotecas Roslyn incluidas en el SDK.

Coloca esta carpeta como `Tests/TarrajeoComboFilter/` junto a la carpeta `MYG/`. Desde la raíz del código ejecuta:

```sh
dotnet run --project Tests/TarrajeoComboFilter -- MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoForm.cs
```

El ejecutable extrae y compila **las clases reales** `CatalogoTiposTarrajeo` y `FiltroComboTarrajeo` del archivo indicado; no mantiene una copia de su implementación. Un doble de ComboBox modela texto, selección y la cola de BeginInvoke, y rechaza modificar Items mientras se procesa TextUpdate. Ese contrato permite detectar la reconstrucción sincrónica insegura de la lista.

Los 12 casos comprueban reemplazar texto seleccionado y continuar escribiendo; búsqueda sin distinción de mayúsculas/tildes; cero coincidencias y Enter; vaciar consulta; agrupar ediciones pendientes; Enter y Escape antes de ejecutar pendientes; selección confirmada con pendiente; reemplazo en medio del texto y cursor; control eliminado con pendiente; independencia entre combos; y pérdida de foco durante la edición.

Resultado esperado: `12 passed, 0 failed`, código de salida 0. Cualquier excepción o fallo devuelve código distinto de cero. El archivo de la versión base falla con `Items mutated inside native TextUpdate`; el archivo corregido supera los 12 casos.

**Límite:** el doble no es WinForms nativo. Estas pruebas no demuestran la ausencia de errores de Windows ni ejecutan Revit. Deben completarse en Windows/Revit las comprobaciones de escribir sobre selección, pegado, flechas, Enter, Escape, cero resultados y cambio entre las ventanas por caras/elementos, tanto en tipos de suelo como de muro.
