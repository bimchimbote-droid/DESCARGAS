using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

// Exercise the actual production helpers against a deterministic control double.
// This is a regression test of event ordering, not a Windows/Revit UI test.
if (args.Length != 1)
{
    Console.Error.WriteLine("Usage: dotnet run --project Tests/TarrajeoComboFilter -- <TarrajeoForm.cs>");
    return 2;
}

try
{
    var options = new CSharpParseOptions(LanguageVersion.CSharp7_3);
    var source = CSharpSyntaxTree.ParseText(File.ReadAllText(args[0]), options);
    string[] names = { "CatalogoTiposTarrajeo", "FiltroComboTarrajeo" };
    var helpers = names.Select(name => source.GetRoot().DescendantNodes()
        .OfType<ClassDeclarationSyntax>().Single(node => node.Identifier.ValueText == name));
    string extracted = "using System; using System.Collections.Generic; using System.Globalization; " +
        "using System.Linq; using WinForms = ComboDouble; namespace MYG_Addin {\n" +
        string.Join("\n", helpers.Select(node => node.ToFullString())) + "\n}";
    var trees = new[]
    {
        CSharpSyntaxTree.ParseText(extracted, options),
        CSharpSyntaxTree.ParseText(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Harness.cs")), options)
    };
    var platformAssemblies = (string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!;
    var references = platformAssemblies.Split(Path.PathSeparator)
        .Select(path => MetadataReference.CreateFromFile(path));
    var compilation = CSharpCompilation.Create("ComboFilterRegression", trees, references,
        new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
    using var stream = new MemoryStream();
    var result = compilation.Emit(stream);
    if (!result.Success)
    {
        foreach (var diagnostic in result.Diagnostics.Where(item => item.Severity == DiagnosticSeverity.Error))
            Console.Error.WriteLine(diagnostic);
        return 1;
    }
    var assembly = Assembly.Load(stream.ToArray());
    return (int)assembly.GetType("MYG_Addin.Regression")!.GetMethod("Run")!.Invoke(null, null)!;
}
catch (Exception exception)
{
    Console.Error.WriteLine((exception.InnerException ?? exception).ToString());
    return 1;
}
