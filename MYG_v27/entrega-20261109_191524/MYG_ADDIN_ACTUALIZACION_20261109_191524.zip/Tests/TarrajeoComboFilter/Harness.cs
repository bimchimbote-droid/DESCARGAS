using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace ComboDouble
{
    public enum ComboBoxStyle { DropDown }
    public enum AutoCompleteMode { None }
    public enum AutoCompleteSource { None }
    public enum Keys { A, Enter, Escape }
    public delegate void MethodInvoker();
    public sealed class KeyEventArgs : EventArgs
    {
        public bool Control, Handled, SuppressKeyPress;
        public Keys KeyCode;
    }
    public sealed class Form
    {
        public event EventHandler Load;
        public void Show() { if (Load != null) Load(this, EventArgs.Empty); }
    }

    // The double rejects item mutations during TextUpdate, simulating the native
    // notification whose old item index is still in use until the event returns.
    // BeginInvoke is queued explicitly so tests can exercise pending edits/keys.
    public sealed class ComboBox
    {
        public sealed class ObjectCollection : Collection<object>
        {
            private readonly ComboBox _owner;
            public ObjectCollection(ComboBox owner) { _owner = owner; }
            protected override void ClearItems()
            {
                if (_owner._editing) throw new InvalidOperationException("Items mutated inside native TextUpdate");
                base.ClearItems();
                _owner._index = -1;
            }
            public void AddRange(object[] values) { foreach (object value in values) Add(value); }
        }

        private int _index = -1;
        private string _text = string.Empty;
        private bool _editing;
        private readonly Queue<Delegate> _pending = new Queue<Delegate>();
        public readonly ObjectCollection Items;
        public ComboBox() { Items = new ObjectCollection(this); }
        public ComboBoxStyle DropDownStyle;
        public AutoCompleteMode AutoCompleteMode;
        public AutoCompleteSource AutoCompleteSource;
        public bool IsDisposed, IsHandleCreated = true, Visible = true, Focused = true;
        public int SelectionStart, SelectionLength;
        public int PendingCount { get { return _pending.Count; } }
        public bool DroppedDown
        {
            get { return _dropped; }
            set { _dropped = value; if (value) Select(0, Text.Length); }
        }
        private bool _dropped;
        public int SelectedIndex
        {
            get { return _index; }
            set
            {
                if (value < -1 || value >= Items.Count) throw new ArgumentOutOfRangeException("SelectedIndex");
                _index = value;
                _text = value < 0 ? string.Empty : GetItemText(Items[value]);
                Select(_text.Length, 0);
            }
        }
        public object SelectedItem
        {
            get { return _index < 0 ? null : Items[_index]; }
            set { SelectedIndex = Items.IndexOf(value); }
        }
        public string Text
        {
            get { return _text; }
            set
            {
                _text = value;
                _index = -1;
                for (int i = 0; i < Items.Count; i++)
                    if (GetItemText(Items[i]) == value) { _index = i; break; }
                Select(value.Length, 0);
            }
        }
        public event EventHandler TextUpdate, SelectionChangeCommitted, Leave;
        public event EventHandler<KeyEventArgs> KeyDown;
        public string GetItemText(object item) { return item.ToString(); }
        public void BeginUpdate() { }
        public void EndUpdate() { }
        public void BeginInvoke(Delegate action) { _pending.Enqueue(action); }
        public void Select(int start, int length) { SelectionStart = start; SelectionLength = length; }
        public void Flush() { while (_pending.Count > 0) _pending.Dequeue().DynamicInvoke(); }
        public void Edit(string inserted)
        {
            _text = _text.Remove(SelectionStart, SelectionLength).Insert(SelectionStart, inserted);
            SelectionStart += inserted.Length;
            SelectionLength = 0;
            _index = -1;
            _editing = true;
            try { if (TextUpdate != null) TextUpdate(this, EventArgs.Empty); }
            finally { _editing = false; }
        }
        public void Key(Keys key, bool control = false)
        {
            if (KeyDown != null) KeyDown(this, new KeyEventArgs { KeyCode = key, Control = control });
        }
        public void Commit(int index)
        {
            SelectedIndex = index;
            if (SelectionChangeCommitted != null) SelectionChangeCommitted(this, EventArgs.Empty);
        }
        public void LoseFocus()
        {
            Focused = false;
            if (Leave != null) Leave(this, EventArgs.Empty);
        }
    }
}

namespace MYG_Addin
{
    public static class Regression
    {
        private static readonly string[] Names = { "Suelo de concreto", "Tarrajeo fino", "Muro cerámico" };
        private static ComboDouble.ComboBox Create()
        {
            var combo = new ComboDouble.ComboBox();
            var form = new ComboDouble.Form();
            combo.Items.AddRange(Names.Cast<object>().ToArray());
            combo.SelectedIndex = 0;
            FiltroComboTarrajeo.Configurar(combo, form);
            form.Show();
            return combo;
        }
        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
        private static void Query(ComboDouble.ComboBox combo, string text)
        {
            combo.Key(ComboDouble.Keys.A, true);
            combo.Edit(text);
            combo.Flush();
        }
        public static int Run()
        {
            int passed = 0;
            var combo = Create();
            Query(combo, "ta");
            Assert(combo.Text == "ta" && combo.Items.Count == 1 && combo.SelectedItem == null &&
                combo.SelectionStart == 2 && combo.SelectionLength == 0, "Selected text replacement/filter/caret failed");
            combo.Edit("r"); combo.Flush();
            Assert(combo.Text == "tar", "Typing must continue the query");
            passed++;

            Query(combo, "CERAMICO");
            Assert(combo.Items.Count == 1 && object.ReferenceEquals(combo.Items[0], Names[2]), "Accent/case-insensitive search failed");
            passed++;

            Query(combo, "unmatched");
            combo.Key(ComboDouble.Keys.Enter);
            Assert(combo.Items.Count == 0 && combo.SelectedIndex == -1 && combo.Text == "unmatched", "Empty results/Enter failed");
            passed++;

            Query(combo, string.Empty);
            Assert(combo.Items.Count == Names.Length && combo.Text == string.Empty, "Clearing must restore full catalogue");
            passed++;

            combo = Create();
            combo.Key(ComboDouble.Keys.A, true); combo.Edit("t"); combo.Edit("a");
            Assert(combo.PendingCount == 1, "Pending edits must coalesce");
            combo.Flush();
            Assert(combo.Text == "ta" && combo.Items.Count == 1, "Latest pending query lost");
            passed++;

            combo = Create();
            combo.Key(ComboDouble.Keys.A, true); combo.Edit("tar");
            combo.Key(ComboDouble.Keys.Enter); combo.Flush();
            Assert(object.ReferenceEquals(combo.SelectedItem, Names[1]), "Enter must apply pending filter and confirm actual type");
            passed++;

            combo = Create();
            combo.Key(ComboDouble.Keys.A, true); combo.Edit("bad query");
            combo.Key(ComboDouble.Keys.Escape); combo.Flush();
            Assert(object.ReferenceEquals(combo.SelectedItem, Names[0]) && combo.Items.Count == Names.Length, "Escape must restore previous selection and cancel pending filter");
            passed++;

            combo = Create();
            combo.Key(ComboDouble.Keys.A, true); combo.Edit("tar");
            combo.Commit(2); combo.Flush();
            Assert(object.ReferenceEquals(combo.SelectedItem, Names[2]), "Committed selection must cancel stale filter");
            passed++;

            combo = Create(); Query(combo, "abxxcd");
            combo.Select(2, 2); combo.Edit("z"); combo.Flush();
            Assert(combo.Text == "abzcd" && combo.SelectionStart == 3 && combo.SelectionLength == 0, "Replacing a middle selection must preserve cursor");
            passed++;

            combo = Create(); combo.Key(ComboDouble.Keys.A, true); combo.Edit("tar");
            combo.IsDisposed = true; combo.Flush();
            Assert(combo.Items.Count == Names.Length, "Disposed control must ignore queued filter");
            passed++;

            var other = Create(); combo = Create(); Query(combo, "tar");
            Assert(other.Items.Count == Names.Length && other.Text == Names[0], "Combo catalogues must remain independent");
            passed++;

            combo = Create(); combo.Key(ComboDouble.Keys.A, true); combo.Edit("tar");
            combo.LoseFocus(); combo.Flush();
            Assert(combo.Items.Count == 1 && combo.Text == "tar" && combo.SelectedItem == null && !combo.DroppedDown,
                "Leaving during a pending edit must apply the query without confirming an old type or opening dropdown");
            passed++;

            Console.WriteLine("Combo filter regressions: " + passed + " passed, 0 failed (control double; Windows/Revit UI untested).");
            return 0;
        }
    }
}
