# Pruebas de alturas de Muros por contorno

Este proyecto verifica los métodos matemáticos **reales** del archivo `MYG/Funcionalidades/Arquitectura/MurosContorno/MUROS_CONTORNO_EJECUTAR_HANDLER.cs`. El archivo se copia como contenido al compilar las pruebas. Roslyn analiza su sintaxis, extrae sin cambios las declaraciones de `CalcularDesfaseBasePano`, `CoincidenAlturasMuro` y `EsAlturaFinitaMuro`, las compila en memoria y ejecuta sus métodos privados mediante delegados. No contiene una copia de las fórmulas de producción.

También audita la conexión de esos métodos con las dos rutas de creación: uso de `ProjectElevation`, ausencia de reasignación de `LocationCurve.Curve`, validación de altura para muro simple y perfil, límites del perfil recortado, subtransacción y comprobación después de regenerar antes de confirmar.

Los casos incluyen el desplazamiento de 1300 m y la base incorrecta de -1291.881 m, niveles de proyecto positivos y negativos, bases elevadas por sobrecimiento, límites reales muy alejados por arriba o por abajo, tolerancia de 1 mm, valores no finitos, desbordamiento y rangos invertidos. Las unidades de los métodos son pies internos; los casos expresados en metros se convierten con 1 pie = 0.3048 m.

## Ejecutar

Requiere .NET SDK 10. No utiliza paquetes NuGet externos: las referencias a Roslyn proceden de `$(MSBuildSDKsPath)/../Roslyn/bincore`, incluido en el SDK.

Desde la raíz del repositorio:

```bash
dotnet run --project Pruebas/MurosContornoAlturas/MurosContornoAlturas.Tests.csproj --configuration Release
```

En este entorno en la nube se puede activar primero el SDK instalado con:

```bash
source /workspace/.onboarding/MYG_v27/activate.sh
```

Una prueba fallida o un error al extraer/compilar el código termina con código de salida distinto de cero. La consola informa el número de casos por grupo y el total.

## Alcance

Estas pruebas no ejecutan Revit, no simulan su API, no compilan el addin y no certifican el resultado geométrico de `Wall.Create`. La auditoría de sintaxis comprueba las llamadas presentes en el código, sin sustituir una prueba de integración. La carga del complemento y la ubicación final de los muros con distintos modelos, vínculos, perfiles y bases compartidas deben verificarse en Revit con la solución completa.
