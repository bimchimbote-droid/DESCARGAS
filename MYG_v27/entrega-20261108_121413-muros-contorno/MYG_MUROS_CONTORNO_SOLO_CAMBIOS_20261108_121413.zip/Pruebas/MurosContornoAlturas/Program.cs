using System.Globalization;
using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

// Se ejecutan los cuerpos reales de producción; no hay una segunda implementación
// de sus fórmulas en este proyecto ni referencias a las bibliotecas de Revit.
var pruebas = new List<(string Grupo, string Nombre, Action Ejecutar)>();
const string nombreArchivo = "MUROS_CONTORNO_EJECUTAR_HANDLER.cs";
string rutaFuente = Path.Combine(AppContext.BaseDirectory, "CodigoFuente", nombreArchivo);
string fuente = File.ReadAllText(rutaFuente);
var arbol = CSharpSyntaxTree.ParseText(fuente);
SyntaxNode raiz = arbol.GetRoot();
string[] nombres = ["CalcularDesfaseBasePano", "CoincidenAlturasMuro", "EsAlturaFinitaMuro"];
var metodos = raiz.DescendantNodes().OfType<MethodDeclarationSyntax>()
    .Where(m => nombres.Contains(m.Identifier.ValueText)).ToArray();
foreach (string nombre in nombres)
{
    if (metodos.Count(m => m.Identifier.ValueText == nombre) != 1)
        throw new InvalidOperationException($"Se esperaba un único método real: {nombre}.");
}

// ToFullString conserva el texto de cada declaración, incluido el cuerpo.
// La única envoltura añadida es la clase que permite compilar sin tipos de Revit.
string codigoExtraido = "using System;\npublic static class MetodosReales\n{\n" +
    string.Join("\n", metodos.Select(m => m.ToFullString())) + "\n}";
string? ensambladosPlataforma = AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") as string;
if (string.IsNullOrEmpty(ensambladosPlataforma))
    throw new InvalidOperationException("No se encontraron los ensamblados de la plataforma .NET.");
var referencias = ensambladosPlataforma.Split(Path.PathSeparator)
    .Select(p => MetadataReference.CreateFromFile(p));
var compilacion = CSharpCompilation.Create("MurosContornoMetodosReales",
    [CSharpSyntaxTree.ParseText(codigoExtraido)], referencias,
    new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var memoria = new MemoryStream();
var emision = compilacion.Emit(memoria);
if (!emision.Success)
    throw new InvalidOperationException(string.Join(Environment.NewLine, emision.Diagnostics));
Type clase = Assembly.Load(memoria.ToArray()).GetType("MetodosReales", throwOnError: true)!;
var desfase = ObtenerDelegado<Func<double, double, double>>("CalcularDesfaseBasePano");
var coinciden = ObtenerDelegado<Func<double, double, double, double, double, bool>>("CoincidenAlturasMuro");
var finita = ObtenerDelegado<Func<double, bool>>("EsAlturaFinitaMuro");
double mm = Metros(0.001);

// Valores esperados independientes, en pies internos de Revit.
(string Nombre, double Base, double Nivel, double Desfase)[] casosDesfase =
[
    ("nivel cero", 12, 0, 12),
    ("base y nivel iguales", 12, 12, 0),
    ("nivel positivo bajo la base", 15, 10, 5),
    ("nivel positivo sobre la base", 8, 10, -2),
    ("nivel negativo bajo la base", -7, -10, 3),
    ("nivel negativo sobre la base", -15, -10, -5),
    ("base positiva con nivel negativo", 8, -12, 20),
    ("base negativa con nivel positivo", -8, 12, -20),
    ("sobrecimiento elevado 0.45 m", Metros(10.45), Metros(10), Metros(0.45)),
    ("cota interna elevada", Metros(1308.119), Metros(1300), Metros(8.119)),
    ("cota interna negativa", Metros(-1291.881), Metros(-1300), Metros(8.119)),
    ("regresión compartidas 1300 m", Metros(8.119), 0, Metros(8.119))
];
foreach (var caso in casosDesfase)
{
    Agregar("desfases", caso.Nombre, () =>
    {
        double resultado = desfase(caso.Base, caso.Nivel);
        Cerca(resultado, caso.Desfase);
        Cerca(caso.Nivel + resultado, caso.Base);
    });
}

double[] noFinitas = [double.NaN, double.PositiveInfinity, double.NegativeInfinity];
foreach (double invalida in noFinitas)
{
    Agregar("desfases inválidos", $"base {Etiqueta(invalida)}", () => ArgumentoInvalido(() => desfase(invalida, 0)));
    Agregar("desfases inválidos", $"nivel {Etiqueta(invalida)}", () => ArgumentoInvalido(() => desfase(0, invalida)));
}
Agregar("desfases inválidos", "desbordamiento positivo", () => ArgumentoInvalido(() => desfase(double.MaxValue, -double.MaxValue)));
Agregar("desfases inválidos", "desbordamiento negativo", () => ArgumentoInvalido(() => desfase(-double.MaxValue, double.MaxValue)));

foreach (double valor in new[] { 0.0, -0.0, 1.0, -1.0, double.Epsilon, double.MaxValue, -double.MaxValue })
    Agregar("finitud", $"acepta {Etiqueta(valor)}", () => Verdadero(finita(valor)));
foreach (double valor in noFinitas)
    Agregar("finitud", $"rechaza {Etiqueta(valor)}", () => Falso(finita(valor)));

Agregar("alturas", "intervalo correcto positivo", () => Verdadero(coinciden(12, 22, 12, 22, mm)));
Agregar("alturas", "intervalo correcto negativo", () => Verdadero(coinciden(-22, -12, -22, -12, mm)));
Agregar("alturas", "intervalo cruza el cero", () => Verdadero(coinciden(-4, 6, -4, 6, mm)));
Agregar("alturas", "sobrecimiento eleva toda la base del perfil", () =>
    Verdadero(coinciden(Metros(10.45), Metros(13), Metros(10.45), Metros(13), mm)));
Agregar("alturas", "perfil elevado no coincide con base original", () =>
    Falso(coinciden(Metros(10.45), Metros(13), Metros(10), Metros(13), mm)));
Agregar("alturas", "regresión suelo -1291.881 m", () =>
    Falso(coinciden(Metros(-1291.881), Metros(-1288.881), Metros(8.119), Metros(11.119), mm)));
Agregar("alturas", "bbox remoto 1300 m hacia abajo", () =>
    Falso(coinciden(Metros(-1290), Metros(-1287), Metros(10), Metros(13), mm)));
Agregar("alturas", "bbox remoto 1300 m hacia arriba", () =>
    Falso(coinciden(Metros(1310), Metros(1313), Metros(10), Metros(13), mm)));
Agregar("alturas", "base 0.999 mm desplazada", () => Verdadero(coinciden(Metros(.000999), 10, 0, 10, mm)));
Agregar("alturas", "base exactamente 1 mm desplazada", () => Verdadero(coinciden(mm, 10, 0, 10, mm)));
Agregar("alturas", "base exactamente -1 mm desplazada", () => Verdadero(coinciden(-mm, 10, 0, 10, mm)));
Agregar("alturas", "base 1.001 mm desplazada", () => Falso(coinciden(Metros(.001001), 10, 0, 10, mm)));
Agregar("alturas", "coronación 0.999 mm desplazada", () => Verdadero(coinciden(-10, Metros(.000999), -10, 0, mm)));
Agregar("alturas", "coronación exactamente 1 mm desplazada", () => Verdadero(coinciden(-10, mm, -10, 0, mm)));
Agregar("alturas", "coronación exactamente -1 mm desplazada", () => Verdadero(coinciden(-10, -mm, -10, 0, mm)));
Agregar("alturas", "coronación 1.001 mm desplazada", () => Falso(coinciden(-10, Metros(.001001), -10, 0, mm)));
Agregar("alturas", "base correcta y coronación incorrecta", () => Falso(coinciden(0, 10.1, 0, 10, mm)));
Agregar("alturas", "base incorrecta y coronación correcta", () => Falso(coinciden(.1, 10, 0, 10, mm)));
Agregar("alturas inválidas", "rango real invertido", () => Falso(coinciden(10, 0, 0, 10, mm)));
Agregar("alturas inválidas", "rango esperado invertido", () => Falso(coinciden(0, 10, 10, 0, mm)));
Agregar("alturas inválidas", "rango real nulo", () => Falso(coinciden(10, 10, 0, 10, mm)));
Agregar("alturas inválidas", "rango esperado nulo", () => Falso(coinciden(0, 10, 0, 0, mm)));
Agregar("alturas inválidas", "tolerancia cero", () => Falso(coinciden(0, 10, 0, 10, 0)));
Agregar("alturas inválidas", "tolerancia negativa", () => Falso(coinciden(0, 10, 0, 10, -mm)));
Agregar("alturas inválidas", "diferencias desbordan", () =>
    Falso(coinciden(-double.MaxValue, -double.MaxValue / 2, double.MaxValue / 2, double.MaxValue, mm)));
for (int posicion = 0; posicion < 5; posicion++)
{
    foreach (double invalida in noFinitas)
    {
        int indice = posicion;
        Agregar("alturas inválidas", $"argumento {indice + 1}: {Etiqueta(invalida)}", () =>
        {
            double[] argumentos = [0, 10, 0, 10, mm];
            argumentos[indice] = invalida;
            Falso(coinciden(argumentos[0], argumentos[1], argumentos[2], argumentos[3], argumentos[4]));
        });
    }
}

Agregar("auditoría de fuente", "tres declaraciones privadas estáticas originales", () =>
{
    Verdadero(metodos.Length == 3);
    Verdadero(metodos.All(m => m.Modifiers.Any(SyntaxKind.PrivateKeyword) && m.Modifiers.Any(SyntaxKind.StaticKeyword)));
});
Agregar("auditoría de fuente", "desfase: dos llamadas y nivel ProjectElevation", () =>
{
    var llamadas = Invocaciones(raiz, "CalcularDesfaseBasePano");
    Verdadero(llamadas.Length == 2);
    Verdadero(llamadas.All(i => i.ArgumentList.Arguments.Count == 2 &&
        i.ArgumentList.Arguments[1].Expression is MemberAccessExpressionSyntax acceso &&
        acceso.Expression is IdentifierNameSyntax objeto && objeto.Identifier.ValueText == "nivelBase" &&
        acceso.Name.Identifier.ValueText == "ProjectElevation"));
});
Agregar("auditoría de fuente", "ningún acceso a Level.Elevation", () =>
    Falso(raiz.DescendantNodes().OfType<MemberAccessExpressionSyntax>().Any(a => a.Name.Identifier.ValueText == "Elevation")));
Agregar("auditoría de fuente", "selector de nivel compara ProjectElevation", () =>
{
    var selector = Metodo("ObtenerNivelBase");
    int cantidad = selector.DescendantNodes().OfType<MemberAccessExpressionSyntax>().Count(a => a.Name.Identifier.ValueText == "ProjectElevation");
    Verdadero(cantidad >= 4);
});
Agregar("auditoría de fuente", "configuración no reasigna LocationCurve.Curve", () =>
    Falso(Metodo("ConfigurarParametrosMuroCreado").DescendantNodes().OfType<AssignmentExpressionSyntax>()
        .Any(a => a.Left.DescendantNodesAndSelf().OfType<MemberAccessExpressionSyntax>().Any(m => m.Name.Identifier.ValueText == "Curve"))));
foreach (string nombre in new[] { "CrearMuroPanoSimple", "CrearMuroPanoConPerfil" })
{
    Agregar("auditoría de fuente", $"{nombre} valida la altura real", () =>
        Verdadero(Invocaciones(Metodo(nombre), "CrearMuroConAlturasVerificadas").Length == 1));
}
Agregar("auditoría de fuente", "perfil valida extremos del perfil recortado", () =>
{
    var llamada = Invocaciones(Metodo("CrearMuroPanoConPerfil"), "CrearMuroConAlturasVerificadas").Single();
    var parametros = Metodo("CrearMuroConAlturasVerificadas").ParameterList.Parameters;
    int baseIndice = parametros.IndexOf(parametros.Single(p => p.Identifier.ValueText == "zBaseEsperada"));
    int topIndice = parametros.IndexOf(parametros.Single(p => p.Identifier.ValueText == "zTopEsperada"));
    Verdadero(llamada.ArgumentList.Arguments[baseIndice].Expression.ToString() == "zBasePerfil");
    Verdadero(llamada.ArgumentList.Arguments[topIndice].Expression.ToString() == "zTopPerfil");
});
Agregar("auditoría de fuente", "guarda usa SubTransaction", () =>
    Verdadero(Metodo("CrearMuroConAlturasVerificadas").DescendantNodes().OfType<ObjectCreationExpressionSyntax>()
        .Any(c => c.Type.ToString() == "SubTransaction")));
Agregar("auditoría de fuente", "guarda usa tolerancia de 1 mm", () =>
{
    var guarda = Metodo("CrearMuroConAlturasVerificadas");
    var llamada = Invocaciones(guarda, "CoincidenAlturasMuro").Single();
    ExpressionSyntax expresion = llamada.ArgumentList.Arguments[4].Expression;
    if (expresion is IdentifierNameSyntax variable)
        expresion = guarda.DescendantNodes().OfType<VariableDeclaratorSyntax>()
            .Single(v => v.Identifier.ValueText == variable.Identifier.ValueText).Initializer!.Value;
    var tolerancia = expresion as InvocationExpressionSyntax;
    Verdadero(tolerancia is not null && tolerancia.Expression.ToString() == "MetrosAPies");
    var literal = tolerancia!.ArgumentList.Arguments.Single().Expression as LiteralExpressionSyntax;
    Verdadero(literal is not null && Convert.ToDouble(literal.Token.Value, CultureInfo.InvariantCulture) == .001);
});
Agregar("auditoría de fuente", "guarda regenera antes de medir y confirmar", () =>
{
    MethodDeclarationSyntax guarda = Metodo("CrearMuroConAlturasVerificadas");
    var regenerar = Invocaciones(guarda, "Regenerate").Single();
    var medir = Invocaciones(guarda, "get_BoundingBox").Single();
    var validar = Invocaciones(guarda, "CoincidenAlturasMuro").Single();
    var confirmar = Invocaciones(guarda, "Commit").Single();
    Verdadero(regenerar.SpanStart < medir.SpanStart && medir.SpanStart < validar.SpanStart && validar.SpanStart < confirmar.SpanStart);
    Verdadero(Invocaciones(guarda, "RollBack").Length >= 1);
});

int correctas = 0;
int fallidas = 0;
foreach (var prueba in pruebas)
{
    try
    {
        prueba.Ejecutar();
        correctas++;
        Console.WriteLine($"OK [{prueba.Grupo}] {prueba.Nombre}");
    }
    catch (Exception ex)
    {
        fallidas++;
        Console.Error.WriteLine($"FALLO [{prueba.Grupo}] {prueba.Nombre}: {ex.Message}");
    }
}
Console.WriteLine();
foreach (var grupo in pruebas.GroupBy(p => p.Grupo))
    Console.WriteLine($"{grupo.Key}: {grupo.Count()} casos");
Console.WriteLine($"TOTAL: {pruebas.Count}; CORRECTAS: {correctas}; FALLIDAS: {fallidas}");
Console.WriteLine("Alcance: métodos matemáticos reales y auditoría sintáctica; no ejecuta Revit ni compila el addin.");
return fallidas == 0 ? 0 : 1;

T ObtenerDelegado<T>(string nombre) where T : Delegate =>
    (T)clase.GetMethod(nombre, BindingFlags.NonPublic | BindingFlags.Static)!.CreateDelegate(typeof(T));
void Agregar(string grupo, string nombre, Action ejecutar) => pruebas.Add((grupo, nombre, ejecutar));
MethodDeclarationSyntax Metodo(string nombre) => raiz.DescendantNodes().OfType<MethodDeclarationSyntax>()
    .Single(m => m.Identifier.ValueText == nombre);
static InvocationExpressionSyntax[] Invocaciones(SyntaxNode nodo, string nombre) =>
    nodo.DescendantNodes().OfType<InvocationExpressionSyntax>().Where(i => i.Expression switch
    {
        IdentifierNameSyntax identificador => identificador.Identifier.ValueText == nombre,
        MemberAccessExpressionSyntax miembro => miembro.Name.Identifier.ValueText == nombre,
        _ => false
    }).ToArray();
static double Metros(double metros) => metros / .3048;
static string Etiqueta(double valor) => valor.ToString("G17", CultureInfo.InvariantCulture);
static void Verdadero(bool valor)
{
    if (!valor) throw new InvalidOperationException("Se esperaba verdadero.");
}
static void Falso(bool valor)
{
    if (valor) throw new InvalidOperationException("Se esperaba falso.");
}
static void Cerca(double real, double esperado)
{
    if (double.IsNaN(real) || double.IsInfinity(real) || Math.Abs(real - esperado) > 1e-8)
        throw new InvalidOperationException($"Esperado {Etiqueta(esperado)}, obtenido {Etiqueta(real)} pies.");
}
static void ArgumentoInvalido(Action accion)
{
    try { accion(); }
    catch (ArgumentException) { return; }
    throw new InvalidOperationException("Se esperaba ArgumentException.");
}
