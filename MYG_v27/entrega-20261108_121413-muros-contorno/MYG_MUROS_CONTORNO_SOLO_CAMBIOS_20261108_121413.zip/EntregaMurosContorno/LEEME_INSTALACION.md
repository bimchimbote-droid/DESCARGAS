# Corrección de alturas: Muros por contorno

Esta actualización parcial corresponde a la estructura reorganizada de `bimchimbote-droid/MYG_v27` usada en la conversación. No es una solución nueva ni incluye archivos del add-in sin cambios.

## Archivo de aplicación que debes reemplazar

| Ruta relativa a la raíz de tu solución | Acción |
| --- | --- |
| `MYG/Funcionalidades/Arquitectura/MurosContorno/MUROS_CONTORNO_EJECUTAR_HANDLER.cs` | REEMPLAZAR completo |

No hay archivos nuevos que agregar al proyecto del add-in, cambios de `.csproj`, dependencias nuevas ni eliminaciones. La corrección de tarrajeo de la entrega anterior se conserva: no debes desinstalarla ni reemplazar sus archivos con versiones antiguas.

## Qué se corrigió

1. La selección del nivel, los puntos del eje y el desfase de base ahora usan `Level.ProjectElevation`, coherente con la geometría del vínculo que ya está transformada al documento anfitrión. No se vuelve a aplicar la transformación del vínculo.
2. Se retiró la reasignación de `LocationCurve.Curve` a la línea situada en la cota del nivel después de configurar el desfase. El eje ya se proporciona a `Wall.Create`; la base se controla con las restricciones del muro.
3. La creación de cada muro se verifica dentro de una `SubTransaction`. Se comprueban nivel, desfase y altura editable reales, además de que la geometría alcance el rango vertical del paño o del perfil recortado. Si falla, se revierte ese intento y se muestra el último diagnóstico de rechazo.
4. El control permite que los barridos del tipo sobresalgan del rango esperado; no usa el extremo de un barrido como base de restricción. Un fallo de regeneración aborta y revierte la transacción principal, sin continuar creando elementos.

La generación de paños, los descuentos de sobrecimientos, los filtros de selección, las transformaciones, los controles y el resto de herramientas se conservaron. Se verificó que otros 77 métodos de este archivo mantienen exactamente su contenido.

## Instalación

1. Respalda tu solución y la DLL instalada. Si modificaste este archivo después de descargar la estructura reorganizada, compara tus cambios antes de sustituirlo.
2. Extrae el ZIP y copia el archivo de la tabla a esa misma ruta en tu solución. No borres las otras carpetas ni agregues un segundo ejemplar del handler.
3. Abre tu solución en Visual Studio sobre Windows y recompila con las referencias reales de Revit y Office/Excel. Si faltan paquetes, restaura NuGet. Desde Developer PowerShell, después de restaurar, el comando equivalente es `MSBuild.exe MYG\MYG.csproj /t:Build /p:Configuration=Release /p:Platform=x64`.
4. Cierra Revit antes de actualizar la DLL compilada. Conserva tu manifiesto `.addin`, iconos y demás dependencias de la instalación.
5. Prueba en una copia del modelo con un paño sencillo, otro con sobrecimiento y otro con perfil. Repite con niveles de coordenadas compartidas y con un vínculo desplazado verticalmente.

El cambio afecta la creación futura. No mueve ni elimina los muros erróneos creados anteriormente. Revísalos y deshaz o elimina los que correspondan en tu modelo de prueba antes de repetir.

## Pruebas y límites

- 81 comprobaciones ejecutadas y aprobadas: 70 casos matemáticos de los métodos reales y 11 auditorías de su conexión con la creación de muros. No se copian las fórmulas: Roslyn extrae los métodos del handler para ejecutarlos.
- 179 archivos activos del add-in analizados sin errores de sintaxis C# 7.3.
- Solo un archivo de producción cambió respecto a la versión anterior de esta sesión. Proyecto, paquetes, recursos y correcciones previas de tarrajeo permanecen iguales.
- La compilación completa en Linux sigue detenida por `MSB4803`: las referencias COM requieren MSBuild de .NET Framework en Windows. No se generó una DLL nueva aquí ni se ejecutó Revit.
- La validación funcional de `Wall.Create` con los modelos, perfiles y tipos concretos sigue pendiente en Revit. Esta entrega corrige las alturas, no certifica ausencia de interferencias con cualquier elemento del modelo ni cambia la ubicación horizontal calculada por los paños.

`Pruebas/MurosContornoAlturas/` es un proyecto independiente y opcional para desarrollo. No agregues sus `.cs` al proyecto del add-in. Requiere SDK .NET 10 para ejecutar `dotnet run --project Pruebas/MurosContornoAlturas/MurosContornoAlturas.Tests.csproj`; esto no cambia el framework del add-in.

La base Git es `a41d354e8206e401a881aacfff3f5da7dfe74d00`, más la reorganización y las correcciones locales previas de la sesión. La publicación del ZIP en `bimchimbote-droid/DESCARGAS` no aplica archivos a tu PC ni hace Push a `MYG_v27`. Después de validar, revisa Cambios de Git en Visual Studio, haz Commit y después Push a tu rama cuando corresponda.
