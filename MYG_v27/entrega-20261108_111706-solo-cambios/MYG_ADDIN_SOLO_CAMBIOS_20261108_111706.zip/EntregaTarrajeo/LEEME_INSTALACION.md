# Actualización parcial de Tarrajeo/Encofrado

Este ZIP sustituye la entrega anterior que incluía todos los .cs. Contiene únicamente los archivos de aplicación modificados o nuevos, las pruebas nuevas y la documentación necesaria. No incluye ningún .cs de aplicación sin cambios.

## Aplicación de la corrección

Respalda tu solución y aplica esta entrega sobre la versión reorganizada que ya tienes, no sobre el antiguo archivo monolítico MYGCommand.cs.

En `MYG/Funcionalidades/Estructuras/Tarrajeo/`:

| Archivo | Acción |
| --- | --- |
| Tarrajeo_SuelosHandler.cs | REEMPLAZAR completo |
| TarrajeoCore.cs | REEMPLAZAR completo |
| TarrajeoAlturas.cs | CREAR e incluir en el proyecto |
| TarrajeoValidacionSuelo.cs | CREAR e incluir en el proyecto |

1. Extrae el ZIP y copia únicamente esos cuatro archivos conservando sus rutas relativas.
2. En Visual Studio selecciona Agregar → Elemento existente sobre la carpeta de Tarrajeo del proyecto y agrega únicamente los dos archivos nuevos. El proyecto enumera los archivos explícitamente.
3. Como alternativa al paso 2, desde la raíz de la solución puedes ejecutar `git apply --check EntregaTarrajeo/AGREGAR_ARCHIVOS_CSPROJ.patch` y después `git apply EntregaTarrajeo/AGREGAR_ARCHIVOS_CSPROJ.patch`. No apliques ambas opciones ni dupliques las entradas Compile.
4. Recompila en Windows con las referencias reales de Revit/Office. Después de restaurar dependencias, el comando desde Developer PowerShell es `MSBuild.exe MYG\MYG.csproj /t:Build /p:Configuration=Release /p:Platform=x64`.
5. Cierra Revit antes de actualizar la DLL y prueba primero en una copia del modelo. Conserva tu manifiesto .addin, iconos y dependencias.

No se reemplazan tu .csproj completo, packages.config ni app.config: se preservan tus actualizaciones locales de NuGet. No hay archivos que eliminar ni paquetes nuevos que instalar para el add-in. Si modificaste estos .cs después de la entrega anterior, compara tus cambios antes de reemplazarlos.

## Qué se corrigió y verificó

Se usa ProjectElevation en el cálculo y selección de alturas de suelos para no mezclar coordenadas internas con cotas compartidas. En el motor por cara se comprueba el contacto exterior de suelos horizontales con tolerancia de 0,1 mm. Si falla, se revierte el intento completo. Se mantiene el respaldo existente de separación exterior de 0,8 mm. Los métodos de muros y demás herramientas no se modificaron.

La lógica es la misma del ZIP anterior; este cambio de entrega solo reduce el contenido empaquetado. Se verificó que los cuatro .cs y las pruebas coinciden por bytes con esa entrega.

- 57 pruebas matemáticas aprobadas, 0 fallidas, 71 aserciones.
- 179 archivos activos analizados sin errores de sintaxis C# 7.3.
- La compilación completa en Linux sigue bloqueada por MSB4803, debido a las referencias COM; no se generó una DLL aquí.
- No se ejecutó Revit. La validación funcional, las pendientes, familias y vínculos siguen pendientes en Windows/Revit.
- El contacto con el plano seleccionado no certifica ausencia de choque con todo objeto del modelo ni con cualquier criterio de un detector externo.
- Los suelos erróneos creados anteriormente no se mueven ni eliminan automáticamente.

`Pruebas/TarrajeoAlturas/` es un proyecto independiente de pruebas matemáticas. No agregues Program.cs ni su proyecto al add-in. Para ejecutarlo se necesita SDK .NET 10: `dotnet run --project Pruebas/TarrajeoAlturas/TarrajeoAlturas.Tests.csproj`. No cambia el framework del add-in.

La base es el commit a41d354e8206e401a881aacfff3f5da7dfe74d00 más la reorganización local de la sesión. Solo se publica el ZIP en bimchimbote-droid/DESCARGAS; no se hace Push al repositorio del código. Tras validar en tu equipo, revisa Cambios de Git en Visual Studio, haz Commit y después Push a tu rama.

`ARCHIVOS.csv` enumera los archivos de código/pruebas y la acción puntual sobre el proyecto. Los otros dos archivos son documentación de esta entrega.
