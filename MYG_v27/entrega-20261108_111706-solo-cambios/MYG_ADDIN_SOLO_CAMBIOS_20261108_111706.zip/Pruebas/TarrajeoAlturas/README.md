# Pruebas de alturas del tarrajeo

Esta consola compila mediante `Compile/Link` el archivo real `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoAlturas.cs`. No utiliza una copia de su algoritmo, paquetes de pruebas externos ni la API de Revit. Es independiente de la solución del add-in y requiere un SDK de .NET 10.

Desde la raíz de la entrega:

```sh
dotnet run --project Pruebas/TarrajeoAlturas/TarrajeoAlturas.Tests.csproj
```

La salida muestra cada caso, los totales y el alcance de la validación. Devuelve código de salida distinto de cero si algún caso falla.

Se comprueban contacto superior e inferior, espesor de 20 cm, niveles internos positivos y negativos, regresión de una cota compartida desplazada 1300 m, respaldo exterior de 0.8 mm, posición remota, valores no finitos y argumentos inválidos. Las pruebas utilizan directamente la constante de producción `TarrajeoAlturas.ToleranciaContactoPies`, equivalente a 0.1 mm. Comprueban que un ruido de 0.05 mm se acepta y que una penetración o separación no solicitada de 0.2 mm se rechaza. También verifican que el respaldo de 0.8 mm no se da por válido cuando la geometría quedó con separación cero.

Estas pruebas **no son una compilación del add-in ni una prueba dentro de Revit**. No validan la transformación de familias o vínculos, la generación de geometría, las inclinaciones reales, las uniones ni las interferencias contra otros elementos. Esas comprobaciones deben ejecutarse con el add-in compilado sobre Windows y Revit.
