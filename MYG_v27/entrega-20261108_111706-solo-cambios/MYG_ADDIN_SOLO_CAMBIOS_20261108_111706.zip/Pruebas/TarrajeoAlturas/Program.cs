using MYG_Addin;

// Se compila el helper real mediante Compile/Link, sin copiar su implementación.
// Estas pruebas NO cargan Revit y NO sustituyen una prueba con geometría real.
const double FeetPerMeter = 1.0 / 0.3048;
double M(double meters) => meters * FeetPerMeter;
double thickness = M(0.20);
double tolerance = TarrajeoAlturas.ToleranciaContactoPies;
double gap = M(0.0008);
var cases = new List<(string Name, Action Run)>();
int assertions = 0;
void Check(bool condition, string message)
{
    assertions++;
    if (!condition) throw new InvalidOperationException(message);
}
void Near(double actual, double expected, string message)
{
    Check(Math.Abs(actual - expected) <= 1e-8, $"{message}: {actual:G17} != {expected:G17}");
}
void Reject(Action action)
{
    try { action(); }
    catch (ArgumentException) { assertions++; return; }
    throw new InvalidOperationException("Se esperaba ArgumentException.");
}
void Add(string name, Action run) => cases.Add((name, run));

Add("Cara superior: contacto inferior y espesor exterior de 20 cm", () =>
{
    double face = M(3.0), level = 0.0;
    double top = level + TarrajeoAlturas.CalcularDesfase(face, level, 1.0, thickness, 0.0);
    Near(top - thickness, face, "La base del acabado debe tocar la cara");
    Near(top, M(3.20), "El acabado debe extenderse hacia arriba");
    Check(TarrajeoAlturas.ContactoExteriorValido(top - thickness - face, top - face, 0, tolerance), "Contacto exterior rechazado");
});
Add("Cara inferior: contacto superior y espesor exterior de 20 cm", () =>
{
    double face = M(3.0), level = M(1.5);
    double top = level + TarrajeoAlturas.CalcularDesfase(face, level, -1.0, thickness, 0.0);
    Near(top, face, "La cara superior del acabado debe tocar la seleccionada");
    Near(top - thickness, M(2.80), "El acabado debe extenderse hacia abajo");
    Check(TarrajeoAlturas.ContactoExteriorValido(face - top, face - (top - thickness), 0, tolerance), "Contacto inferior rechazado");
});
Add("Regresión: cota compartida desplazada 1300 m no modifica la posición interna", () =>
{
    double levelProject = M(0.0), displayedSharedElevation = M(1300.0), face = M(8.0);
    double correctOffset = TarrajeoAlturas.CalcularDesfase(face, levelProject, 1.0, thickness, 0.0);
    Near(levelProject + correctOffset - thickness, face, "Contacto con la cara a 8 m");
    double legacyOffset = face - displayedSharedElevation + thickness;
    double legacyBottom = levelProject + legacyOffset - thickness;
    Near(legacyBottom - face, -M(1300.0), "La mezcla anterior reproduce una bajada de 1300 m");
    Check(!TarrajeoAlturas.ContactoExteriorValido(legacyBottom - face, legacyBottom + thickness - face, 0, tolerance), "El suelo remoto anterior debe rechazarse");
});
Add("Trasladar cara y nivel juntos conserva el desfase", () =>
{
    double reference = TarrajeoAlturas.CalcularDesfase(M(12), M(4), 1, thickness, 0);
    foreach (double translation in new[] { M(1300), -M(1300), M(100000) })
        Near(TarrajeoAlturas.CalcularDesfase(M(12) + translation, M(4) + translation, 1, thickness, 0), reference, "Invariancia frente al origen interno");
});
foreach (double levelMeters in new[] { -1500.0, -3.0, 4.0, 1500.0 })
{
    double sampleLevel = M(levelMeters);
    Add($"Nivel interno {levelMeters} m: conserva contacto arriba y abajo", () =>
    {
        double face = sampleLevel + M(2);
        double upperTop = sampleLevel + TarrajeoAlturas.CalcularDesfase(face, sampleLevel, 1, thickness, 0);
        double lowerTop = sampleLevel + TarrajeoAlturas.CalcularDesfase(face, sampleLevel, -1, thickness, 0);
        Near(upperTop - thickness, face, "Contacto superior");
        Near(lowerTop, face, "Contacto inferior");
    });
}
foreach (double normal in new[] { 1.0, -1.0 })
{
    double sampleNormal = normal;
    Add($"Respaldo exterior 0.8 mm, normal {normal}", () =>
    {
        double face = M(5), level = M(2);
        double top = level + TarrajeoAlturas.CalcularDesfase(face, level, sampleNormal, thickness, gap);
        double minDistance = sampleNormal > 0 ? top - thickness - face : face - top;
        Near(minDistance, gap, "Separación hacia el exterior");
        Check(TarrajeoAlturas.ContactoExteriorValido(minDistance, minDistance + thickness, gap, tolerance), "Respaldo válido rechazado");
    });
}
Add("Rechaza penetración de 2 mm", () => Check(!TarrajeoAlturas.ContactoExteriorValido(-M(0.002), thickness, 0, tolerance), "No debe aceptar invasión del lado interior"));
Add("Rechaza separación no solicitada de 2 mm", () => Check(!TarrajeoAlturas.ContactoExteriorValido(M(0.002), thickness + M(0.002), 0, tolerance), "No debe aceptar una separación mayor a la tolerancia"));
Add("La tolerancia común de producción equivale a 0.1 mm", () => Near(tolerance, M(0.0001), "Tolerancia común inesperada"));
Add("Tolera ruido geométrico de 0.05 mm", () => Check(TarrajeoAlturas.ContactoExteriorValido(-M(0.00005), thickness, 0, tolerance), "Ruido dentro de tolerancia rechazado"));
Add("Rechaza penetración de 0.2 mm", () => Check(!TarrajeoAlturas.ContactoExteriorValido(-M(0.0002), thickness, 0, tolerance), "No debe aceptar penetración mayor a 0.1 mm"));
Add("Rechaza separación no solicitada de 0.2 mm", () => Check(!TarrajeoAlturas.ContactoExteriorValido(M(0.0002), thickness + M(0.0002), 0, tolerance), "No debe aceptar separación mayor a 0.1 mm"));
Add("Respaldo de 0.8 mm exige la separación real solicitada", () => Check(!TarrajeoAlturas.ContactoExteriorValido(0, thickness, gap, tolerance), "No debe aceptar contacto cero cuando el respaldo solicita 0.8 mm"));
Add("Rechaza suelo remoto 1291.881 m hacia abajo", () => Check(!TarrajeoAlturas.ContactoExteriorValido(-M(1291.881), -M(1291.681), 0, tolerance), "Suelo remoto aceptado"));
Add("Rechaza suelo remoto 1291.881 m hacia arriba", () => Check(!TarrajeoAlturas.ContactoExteriorValido(M(1291.881), M(1292.081), 0, tolerance), "Suelo remoto aceptado"));
Add("Rechaza extremos geométricos invertidos", () => Check(!TarrajeoAlturas.ContactoExteriorValido(thickness, 0, 0, tolerance), "Intervalo invertido aceptado"));
Add("Límite exacto de tolerancia permanece permitido", () => Check(TarrajeoAlturas.ContactoExteriorValido(-tolerance, thickness, 0, tolerance), "Límite de tolerancia rechazado"));

foreach (double invalid in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity })
{
    double value = invalid;
    for (int field = 0; field < 5; field++)
    {
        int position = field;
        Add($"Desfase rechaza {invalid} en argumento {field}", () =>
        {
            double[] args = { M(3), 0, 1, thickness, 0 };
            args[position] = value;
            Reject(() => TarrajeoAlturas.CalcularDesfase(args[0], args[1], args[2], args[3], args[4]));
        });
    }
    for (int field = 0; field < 4; field++)
    {
        int position = field;
        Add($"Contacto rechaza {invalid} en argumento {field}", () =>
        {
            double[] args = { 0, thickness, 0, tolerance };
            args[position] = value;
            Check(!TarrajeoAlturas.ContactoExteriorValido(args[0], args[1], args[2], args[3]), "Valor no finito aceptado");
        });
    }
}
Add("Rechaza espesor cero", () => Reject(() => TarrajeoAlturas.CalcularDesfase(1, 0, 1, 0, 0)));
Add("Rechaza espesor negativo", () => Reject(() => TarrajeoAlturas.CalcularDesfase(1, 0, 1, -1, 0)));
Add("Rechaza separación negativa", () => Reject(() => TarrajeoAlturas.CalcularDesfase(1, 0, 1, 1, -1)));
Add("Rechaza normal vertical de muro", () => Reject(() => TarrajeoAlturas.CalcularDesfase(1, 0, 0, 1, 0)));
Add("Rechaza normal casi vertical de muro", () => Reject(() => TarrajeoAlturas.CalcularDesfase(1, 0, 0.00001, 1, 0)));
Add("Rechaza desbordamiento del cálculo", () => Reject(() => TarrajeoAlturas.CalcularDesfase(double.MaxValue, -double.MaxValue, 1, 1, 0)));
Add("Contacto rechaza tolerancia cero", () => Check(!TarrajeoAlturas.ContactoExteriorValido(0, thickness, 0, 0), "Tolerancia cero aceptada"));
Add("Contacto rechaza tolerancia negativa", () => Check(!TarrajeoAlturas.ContactoExteriorValido(0, thickness, 0, -1), "Tolerancia negativa aceptada"));
Add("Contacto rechaza separación negativa", () => Check(!TarrajeoAlturas.ContactoExteriorValido(0, thickness, -1, tolerance), "Separación negativa aceptada"));

int failed = 0;
foreach (var test in cases)
{
    try { test.Run(); Console.WriteLine("PASS " + test.Name); }
    catch (Exception ex) { failed++; Console.Error.WriteLine("FAIL " + test.Name + ": " + ex.Message); }
}
Console.WriteLine($"RESULTADO: {cases.Count - failed} aprobadas, {failed} fallidas, {cases.Count} ejecutadas; {assertions} aserciones.");
Console.WriteLine("Alcance: matemáticas del helper real. No se ejecutó Revit ni se validaron sólidos mediante su API.");
Environment.ExitCode = failed == 0 ? 0 : 1;
