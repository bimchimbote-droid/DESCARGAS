using Autodesk.Revit.DB;
using System;

namespace MYG_Addin
{
    internal static class TarrajeoValidacionSuelo
    {
        // 0.1 mm: tolerancia geométrica, inferior al respaldo exterior de 0.8 mm.
        // No se añade esta distancia al suelo ni se cambia su espesor.

        internal static bool ComprobarContactoHorizontal(
            Floor suelo,
            XYZ origenCara,
            XYZ normalCara,
            double separacionExterior,
            out string detalle)
        {
            detalle = string.Empty;

            try
            {
                if (suelo == null || origenCara == null || normalCara == null ||
                    normalCara.GetLength() < 0.0001)
                {
                    detalle = "No se pudo comprobar la posición del suelo creado.";
                    return false;
                }

                XYZ normal = normalCara.Normalize();
                double minima = double.PositiveInfinity;
                double maxima = double.NegativeInfinity;
                int puntos = 0;
                GeometryElement geometria = suelo.get_Geometry(new Options
                {
                    DetailLevel = ViewDetailLevel.Fine,
                    ComputeReferences = false,
                    IncludeNonVisibleObjects = false
                });

                MedirGeometria(geometria, Transform.Identity, origenCara, normal,
                    ref minima, ref maxima, ref puntos);

                if (puntos == 0)
                {
                    detalle = "El suelo creado no devolvió geometría sólida verificable.";
                    return false;
                }

                if (TarrajeoAlturas.ContactoExteriorValido(
                    minima, maxima, separacionExterior, TarrajeoAlturas.ToleranciaContactoPies))
                {
                    return true;
                }

                detalle = "El suelo no quedó en contacto exterior con la cara. " +
                    "Distancia mínima (pies): " + minima.ToString("G17") +
                    "; máxima: " + maxima.ToString("G17") +
                    "; separación prevista: " + separacionExterior.ToString("G17") + ".";
                return false;
            }
            catch (Exception ex)
            {
                detalle = "No se pudo validar la geometría final del suelo: " + ex.Message;
                return false;
            }
        }

        private static void MedirGeometria(
            GeometryElement geometria,
            Transform transformacion,
            XYZ origen,
            XYZ normal,
            ref double minima,
            ref double maxima,
            ref int puntos)
        {
            if (geometria == null)
                return;

            foreach (GeometryObject objeto in geometria)
            {
                Solid solido = objeto as Solid;
                if (solido != null && solido.Volume > 0.0)
                {
                    foreach (Face cara in solido.Faces)
                    {
                        Mesh malla = cara.Triangulate();
                        foreach (XYZ vertice in malla.Vertices)
                        {
                            double distancia = (transformacion.OfPoint(vertice) - origen)
                                .DotProduct(normal);
                            if (double.IsNaN(distancia) || double.IsInfinity(distancia))
                                throw new InvalidOperationException("Vértice no finito en el suelo.");
                            minima = Math.Min(minima, distancia);
                            maxima = Math.Max(maxima, distancia);
                            puntos++;
                        }
                    }
                    continue;
                }

                GeometryInstance instancia = objeto as GeometryInstance;
                if (instancia != null)
                {
                    MedirGeometria(instancia.GetSymbolGeometry(),
                        transformacion.Multiply(instancia.Transform), origen, normal,
                        ref minima, ref maxima, ref puntos);
                }
            }
        }
    }
}
