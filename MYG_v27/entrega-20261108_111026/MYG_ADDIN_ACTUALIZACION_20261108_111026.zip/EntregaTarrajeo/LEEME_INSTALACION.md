# Corrección de alturas del tarrajeo de suelos

Esta entrega corresponde a la versión reorganizada de `bimchimbote-droid/MYG_v27` utilizada en esta conversación. La referencia Git es `a41d354e8206e401a881aacfff3f5da7dfe74d00`, más la reorganización local previa. No se ha hecho Push al repositorio del código.

## Qué cambia

La geometría de las caras utiliza las coordenadas internas del documento anfitrión. El cálculo de los suelos restaba `Level.Elevation`, cuyo valor puede depender de la base de elevación mostrada del nivel. Ahora usa `Level.ProjectElevation` para el boceto, desfase, selección de niveles y alturas de vértices de los suelos. Se conserva el ajuste de espesor y orientación: sobre una cara superior, la cara inferior del acabado toca la seleccionada; debajo de una cara inferior, la cara superior toca la seleccionada.

En el motor de suelos por cara se comprueba además la geometría sólida horizontal después de crearla. Sus vértices deben quedar en el semiespacio exterior y en contacto con el plano seleccionado, con tolerancia de lectura de 0,1 mm. Si no pasa la comprobación, se revierte todo el intento mediante `TransactionGroup`, incluidas sus fases confirmadas. El respaldo original de separación exterior de 0,8 mm se mantiene para intentos horizontales rechazados.

Esto detecta una posición remota o una penetración respecto al plano seleccionado. No certifica que un detector externo no reporte contacto como clash ni ausencia de interferencias con cualquier otro objeto del modelo. Se conserva el recorte existente por sólidos visibles. La comprobación geométrica nueva es para caras horizontales; la corrección de referencia de altura también se aplica a la ruta inclinada, cuya geometría debe probarse en Revit.

## Archivos que requieren intervención

| Ruta relativa a la raíz de tu solución | Acción | Descripción |
| --- | --- | --- |
| `MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs` | REEMPLAZAR | Alturas coherentes, comprobación exterior y reversión del intento inválido. |
| `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoCore.cs` | REEMPLAZAR | Misma referencia interna en la ruta de creación de suelos; métodos de muros conservados. |
| `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoAlturas.cs` | CREAR | Cálculo compartido de desfases y criterio numérico de contacto. |
| `MYG/Funcionalidades/Estructuras/Tarrajeo/TarrajeoValidacionSuelo.cs` | CREAR | Lectura de geometría real y comprobación contra el plano seleccionado. |
| `MYG/MYG.csproj` | MODIFICAR | Incorporar los dos archivos nuevos; conserva tu archivo local y sus referencias actuales. |
| `Pruebas/TarrajeoAlturas/` | CREAR, opcional para desarrollo | Proyecto de pruebas matemáticas independiente; no agregar sus fuentes al proyecto del add-in. |

No hay eliminaciones. Los demás `.cs` se incluyen completos por tu solicitud y se identifican como `SIN CAMBIOS` en `ARCHIVOS.csv`. No necesitas reemplazarlos para aplicar esta corrección.

## Instalación sobre tu copia actual

1. Respalda tu solución y la DLL que utilizas. Si tienes cambios locales, revísalos o haz Commit antes de reemplazar fuentes.
2. Extrae el ZIP. Sus carpetas `MYG/`, `Pruebas/` y `EntregaTarrajeo/` son relativas a la raíz de la solución; no es una solución nueva.
3. Copia los dos archivos REEMPLAZAR a las rutas de la tabla. Si los modificaste después de descargar la versión reorganizada, compara antes sus cambios.
4. Copia los dos archivos CREAR a la misma carpeta de tarrajeo.
5. En Visual Studio, haz clic derecho sobre la carpeta de Tarrajeo del proyecto y selecciona **Agregar → Elemento existente**. Selecciona únicamente `TarrajeoAlturas.cs` y `TarrajeoValidacionSuelo.cs`. Esto actualiza tu `.csproj` conservando las actualizaciones NuGet que hayas realizado.
6. Como alternativa al paso anterior, `AGREGAR_ARCHIVOS_CSPROJ.patch` contiene exactamente las dos entradas `Compile` necesarias. Puedes aplicarlo con `git apply --check EntregaTarrajeo/AGREGAR_ARCHIVOS_CSPROJ.patch` y después `git apply EntregaTarrajeo/AGREGAR_ARCHIVOS_CSPROJ.patch`, desde la raíz de tu solución. Utiliza una de las dos opciones, sin duplicar las entradas.
7. Restaura NuGet si Visual Studio lo solicita y recompila con las herramientas Windows de tu instalación. Después de restaurar, el comando equivalente desde Developer PowerShell es `MSBuild.exe MYG\MYG.csproj /t:Build /p:Configuration=Release /p:Platform=x64`. Este comando Windows no se ejecutó en la máquina Linux de revisión.
8. Cierra Revit antes de sustituir la DLL por la compilada. Conserva tu manifiesto `.addin`, los iconos y las dependencias de tu instalación. Prueba primero en una copia de un modelo.

El ZIP no sustituye tu `.csproj`, `packages.config` ni `app.config`. Así no revierte una actualización local de `System.Security.Cryptography.Xml` u otras referencias. El cambio no requiere nuevos paquetes NuGet para el add-in.

Los siete archivos de `MYG/ArchivoNoCompilado/` siguen excluidos: no los agregues al proyecto. Los `.cs` de `Pruebas/` pertenecen únicamente al proyecto de pruebas.

## Validación realizada y pendiente

- SDK de comprobación: .NET 10.0.403; el add-in conserva su configuración original de .NET Framework 4.8 y referencias a Revit 2027.
- 57 pruebas matemáticas ejecutadas: 57 aprobadas, 0 fallidas, 71 aserciones. Compilan el helper real, no una copia de sus fórmulas.
- Los 179 archivos activos del add-in pasan el análisis de sintaxis C# 7.3.
- Los métodos de muros de `TarrajeoCore.cs`, los demás archivos existentes, paquetes, recursos, licencias, Ribbon y configuraciones se conservaron respecto a la copia de esta sesión, salvo las tres rutas modificadas indicadas en `COMPROBACIONES.json`.
- El intento de compilación completa se detiene con `MSB4803`: las referencias COM requieren MSBuild de .NET Framework en Windows. No se generó una DLL nueva aquí.
- No se ejecutó Revit. Están pendientes los casos con coordenadas compartidas reales, caras superiores/inferiores, niveles positivos/negativos, pendientes, vínculos, familias y modelos in situ. No se garantiza que un cambio de altura resuelva una referencia geométrica local incorrecta de una familia.
- Los suelos erróneos creados antes de instalar esta corrección no se mueven ni eliminan automáticamente. Revísalos y deshaz o elimina los que correspondan en tu modelo de prueba antes de repetir la selección.

Para ejecutar las pruebas matemáticas con un SDK .NET 10 instalado: `dotnet run --project Pruebas/TarrajeoAlturas/TarrajeoAlturas.Tests.csproj`. El SDK de pruebas no cambia el framework del add-in.

## Publicación de tu código

Publicar el ZIP en `bimchimbote-droid/DESCARGAS` no aplica los cambios a tu PC ni actualiza `MYG_v27`. Tras instalar y verificar, usa **Cambios de Git** en Visual Studio para revisar los archivos, hacer Commit y después Push a la rama que decidas. La publicación del código no se realiza automáticamente.
