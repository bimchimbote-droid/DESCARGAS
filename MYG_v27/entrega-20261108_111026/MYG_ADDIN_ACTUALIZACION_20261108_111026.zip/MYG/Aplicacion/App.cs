using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =======================================
    // APP PRINCIPAL
    // =======================================
    public partial class App : IExternalApplication
    {

        public Result OnStartup(UIControlledApplication application)
        {
            // ✔ AGREGAR ESTO PRIMERO (CRITICO)
            AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;

            System.Text.Encoding.RegisterProvider(
                System.Text.CodePagesEncodingProvider.Instance);

            string tabName = "MYG";

            try { application.CreateRibbonTab(tabName); }
            catch { }

            string assemblyPath = Assembly.GetExecutingAssembly().Location;

            _assemblyPathGlobal = assemblyPath;

            // Evento para que los iconos cambien cuando cambias tema claro/oscuro sin cerrar Revit.
            try
            {
                application.ThemeChanged += Application_ThemeChanged;
            }
            catch { }
            CrearPanelAcceso(application, tabName, assemblyPath);

            CrearPanelTablas(application, tabName, assemblyPath);

            CrearPanelGestion(application, tabName, assemblyPath);

            CrearPanelEstructuras(application, tabName, assemblyPath);

            CrearPanelArquitectura(application, tabName, assemblyPath);

            CrearPanelMep(application, tabName, assemblyPath);


            MYG_ControlAccesoComandos.RegistrarInicioNormal();

            if (LicenciaManager.IntentarIngresoAutomatico())
            {
                MYG_Sesion.IniciarSesion();
                MYG_RibbonControl.HabilitarBotones(true);
            }
            return Result.Succeeded;
        }





        public Result OnShutdown(UIControlledApplication application)
        {
            try
            {
                application.ThemeChanged -= Application_ThemeChanged;
            }
            catch { }

            MYG_ControlAccesoComandos.Finalizar();
            MYG_RibbonControl.Limpiar();
            MYG_Sesion.CerrarSesion();

            return Result.Succeeded;
        }

        private Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            try
            {
                string folder = Path.GetDirectoryName(
                    Assembly.GetExecutingAssembly().Location);

                string dllName =
                    new AssemblyName(args.Name).Name + ".dll";

                string dllPath = Path.Combine(folder, dllName);

                if (File.Exists(dllPath))
                {
                    return Assembly.LoadFrom(dllPath);
                }
            }
            catch { }

            return null;
        }
    }

}
