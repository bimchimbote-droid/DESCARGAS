﻿// =====================================
// ARCHIVO 02 - PANEL ACERO LONGITUDINAL
// PanelAceroLongitudinalVigas.cs
// PEGAR DENTRO DEL NAMESPACE MYG_Addin
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Windows.Media;

public class PanelAceroLongitudinalVigas : WinForms.Panel
{
    private AceroLongitudinalVigasForm form;

    // =====================================
    // CONTROLES PRINCIPALES
    // =====================================
    private WinForms.ComboBox cmbTipoSuperior;
    private WinForms.ComboBox cmbTipoInferior;
    private WinForms.ComboBox cmbTipoCentral;

    private WinForms.TextBox txtCantidadSuperior;
    private WinForms.TextBox txtCantidadInferior;
    private WinForms.TextBox txtRecubrimiento;

    private WinForms.CheckBox chkDetectarColumnas;
    private WinForms.CheckBox chkAceroCentral;

    private WinForms.CheckBox chkCrearEmpalmes;
    private WinForms.TextBox txtLongitudEmpalme;
    private WinForms.TextBox txtLongitudBarra;

    private WinForms.CheckBox chkUsarRNE;
    private WinForms.Label lblInfoRNE;

    private WinForms.CheckBox chkGanchoInicio;
    private WinForms.CheckBox chkGanchoFin;

    private WinForms.TextBox txtLongitudGanchoInicio;
    private WinForms.TextBox txtLongitudGanchoFin;

    private WinForms.TextBox txtLongitudDesarrolloInicio;
    private WinForms.TextBox txtLongitudDesarrolloFin;

    private WinForms.Label lblTipoCentral;
    private WinForms.Label lblCantidadCentral;
    private WinForms.Label lblCmEmpalme;

    private WinForms.Label lblLongitudEmpalme;
    private WinForms.Label lblLongitudBarra;
    private WinForms.Label lblMBarra;

    private List<VigaLongitudinalPreview> previewVigas =
        new List<VigaLongitudinalPreview>();

    // =====================================
    // COLORES DE PREVIEW
    // =====================================
    private readonly Drawing.Color ColorAceroSuperior = Drawing.Color.FromArgb(0, 90, 200);
    private readonly Drawing.Color ColorAceroInferior = Drawing.Color.FromArgb(220, 120, 0);
    private readonly Drawing.Color ColorAceroCentral = Drawing.Color.FromArgb(0, 150, 70);
    private readonly Drawing.Color ColorEmpalmePreview = Drawing.Color.FromArgb(220, 45, 45);

    // =====================================
    // RNE - VALORES BASE
    // =====================================
    private double rneFcKgCm2 = 210.0;
    private double rneFyMpa = 420.0;
    private double rnePsiE = 1.0;
    private double rneLambda = 1.0;
    private double rneFactorEmpalme = 1.30;
    private double rneMinEmpalmeMm = 300.0;

    private double rnePsiSuperior = 1.30;
    private double rnePsiInferior = 1.00;
    private double rnePsiCentral = 1.00;

    private double empalmeRNESuperiorCm = 0.0;
    private double empalmeRNEInferiorCm = 0.0;
    private double empalmeRNECentralCm = 0.0;

    private bool actualizandoRNE = false;

    // =====================================
    // CONSTRUCTOR
    // =====================================
    public PanelAceroLongitudinalVigas(AceroLongitudinalVigasForm owner)
    {
        form = owner;

        this.BackColor = Drawing.Color.FromArgb(245, 247, 250);

        CrearControles();
        ActualizarEstadoAceroCentral();
        ActualizarEstadoEmpalmes();
        ActualizarEstadoRNE();
        ActualizarEstadoGanchos();
    }

    // =====================================
    // CREAR CONTROLES
    // =====================================
    private void CrearControles()
    {
        WinForms.GroupBox grp = new WinForms.GroupBox()
        {
            Text = "Parámetros de acero longitudinal",
            Left = 0,
            Top = 0,
            Width = 735,
            Height = 205,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        // =====================================
        // FILA 01 - SUPERIOR
        // =====================================
        WinForms.Label lblTipoSuperior = CrearLabel("Tipo barra superior:", 20, 28, 130);
        cmbTipoSuperior = CrearCombo(155, 25, 190);

        cmbTipoSuperior.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreview();
        };

        WinForms.Label lblCantidadSuperior = CrearLabel("Cantidad superior:", 370, 28, 125);

        txtCantidadSuperior = CrearTextBox(500, 25, 55, "2");
        txtCantidadSuperior.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblColorSuperior = new WinForms.Label()
        {
            Text = "●",
            Left = 565,
            Top = 23,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        // =====================================
        // FILA 02 - INFERIOR
        // =====================================
        WinForms.Label lblTipoInferior = CrearLabel("Tipo barra inferior:", 20, 60, 130);
        cmbTipoInferior = CrearCombo(155, 57, 190);

        cmbTipoInferior.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreview();
        };

        WinForms.Label lblCantidadInferior = CrearLabel("Cantidad inferior:", 370, 60, 125);

        txtCantidadInferior = CrearTextBox(500, 57, 55, "2");
        txtCantidadInferior.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblColorInferior = new WinForms.Label()
        {
            Text = "●",
            Left = 565,
            Top = 55,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        // =====================================
        // FILA 03 - CENTRAL
        // =====================================
        chkAceroCentral = new WinForms.CheckBox()
        {
            Text = "",
            Left = 20,
            Top = 91,
            Width = 18,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false
        };

        chkAceroCentral.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoAceroCentral();

            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreview();
        };

        lblTipoCentral = CrearLabel("Tipo barra central:", 42, 91, 120);
        cmbTipoCentral = CrearCombo(155, 88, 190);

        cmbTipoCentral.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreview();
        };

        lblCantidadCentral = CrearLabel("Cantidad central: 2", 370, 91, 145);

        WinForms.Label lblColorCentral = new WinForms.Label()
        {
            Text = "●",
            Left = 520,
            Top = 86,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroCentral,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        // =====================================
        // FILA 04 - RECUBRIMIENTO Y COLUMNAS
        // =====================================
        WinForms.Label lblRecubrimiento = CrearLabel("Recubrimiento:", 20, 123, 130);

        txtRecubrimiento = CrearTextBox(155, 120, 55, "4");
        txtRecubrimiento.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblCmRec = CrearLabelNormal("cm", 215, 123, 30);

        chkDetectarColumnas = new WinForms.CheckBox()
        {
            Text = "Detectar columnas adyacentes",
            Left = 270,
            Top = 121,
            Width = 230,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = true,
            Font = new Drawing.Font("Segoe UI", 8.5F)
        };

        chkDetectarColumnas.CheckedChanged += (s, e) => RefrescarPreview();

        // =====================================
        // FILA 05 - EMPALMES
        // =====================================
        chkCrearEmpalmes = new WinForms.CheckBox()
        {
            Text = "Crear empalmes",
            Left = 20,
            Top = 153,
            Width = 125,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        chkCrearEmpalmes.CheckedChanged += (s, e) =>
        {
            if (!actualizandoRNE &&
                chkCrearEmpalmes != null &&
                !chkCrearEmpalmes.Checked &&
                chkUsarRNE != null &&
                chkUsarRNE.Checked)
            {
                actualizandoRNE = true;
                chkUsarRNE.Checked = false;
                actualizandoRNE = false;
            }

            ActualizarEstadoEmpalmes();
            ActualizarEstadoRNE();
            RefrescarPreview();
        };

        lblLongitudEmpalme = CrearLabel("L. empalme:", 155, 154, 82);

        txtLongitudEmpalme = CrearTextBox(240, 151, 45, "60");
        txtLongitudEmpalme.TextChanged += (s, e) => RefrescarPreview();

        lblCmEmpalme = CrearLabelNormal("cm", 290, 154, 30);

        lblLongitudBarra = CrearLabel("Long. barra:", 340, 154, 85);

        txtLongitudBarra = CrearTextBox(425, 151, 45, "9");
        txtLongitudBarra.TextChanged += (s, e) => RefrescarPreview();

        lblMBarra = CrearLabelNormal("m", 475, 154, 20);

        chkUsarRNE = new WinForms.CheckBox()
        {
            Text = "RNE",
            Left = 505,
            Top = 153,
            Width = 60,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold)
        };

        chkUsarRNE.CheckedChanged += (s, e) =>
        {
            if (!actualizandoRNE &&
                chkUsarRNE != null &&
                chkUsarRNE.Checked &&
                chkCrearEmpalmes != null &&
                !chkCrearEmpalmes.Checked)
            {
                actualizandoRNE = true;
                chkCrearEmpalmes.Checked = true;
                actualizandoRNE = false;
            }

            ActualizarEstadoEmpalmes();
            ActualizarEstadoRNE();
            RefrescarPreview();
        };

        lblInfoRNE = new WinForms.Label()
        {
            Text = "",
            Left = 570,
            Top = 154,
            Width = 145,
            Height = 40,
            ForeColor = Drawing.Color.FromArgb(90, 90, 90),
            Font = new Drawing.Font("Segoe UI", 7.3F, Drawing.FontStyle.Bold),
            TextAlign = Drawing.ContentAlignment.MiddleLeft,
            Visible = false
        };

        // =====================================
        // FILA 06 - GANCHOS Y DESARROLLO
        // =====================================
        chkGanchoInicio = new WinForms.CheckBox()
        {
            Text = "Gancho inicio",
            Left = 20,
            Top = 178,
            Width = 105,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        chkGanchoInicio.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoGanchos();
            RefrescarPreview();
        };

        txtLongitudGanchoInicio = CrearTextBox(125, 177, 42, "15");
        txtLongitudGanchoInicio.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblCmGanchoInicio = CrearLabelNormal("cm", 170, 180, 25);

        chkGanchoFin = new WinForms.CheckBox()
        {
            Text = "Gancho fin",
            Left = 205,
            Top = 178,
            Width = 90,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        chkGanchoFin.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoGanchos();
            RefrescarPreview();
        };

        txtLongitudGanchoFin = CrearTextBox(295, 177, 42, "15");
        txtLongitudGanchoFin.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblCmGanchoFin = CrearLabelNormal("cm", 340, 180, 25);

        WinForms.Label lblDesarrolloInicio = CrearLabel("L. des. ini:", 375, 180, 75);
        txtLongitudDesarrolloInicio = CrearTextBox(450, 177, 42, "60");
        txtLongitudDesarrolloInicio.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblCmDesIni = CrearLabelNormal("cm", 495, 180, 25);

        WinForms.Label lblDesarrolloFin = CrearLabel("L. des. fin:", 535, 180, 75);
        txtLongitudDesarrolloFin = CrearTextBox(610, 177, 42, "60");
        txtLongitudDesarrolloFin.TextChanged += (s, e) => RefrescarPreview();

        WinForms.Label lblCmDesFin = CrearLabelNormal("cm", 655, 180, 25);

        // =====================================
        // AGREGAR CONTROLES
        // =====================================
        grp.Controls.Add(lblTipoSuperior);
        grp.Controls.Add(cmbTipoSuperior);
        grp.Controls.Add(lblCantidadSuperior);
        grp.Controls.Add(txtCantidadSuperior);
        grp.Controls.Add(lblColorSuperior);

        grp.Controls.Add(lblTipoInferior);
        grp.Controls.Add(cmbTipoInferior);
        grp.Controls.Add(lblCantidadInferior);
        grp.Controls.Add(txtCantidadInferior);
        grp.Controls.Add(lblColorInferior);

        grp.Controls.Add(chkAceroCentral);
        grp.Controls.Add(lblTipoCentral);
        grp.Controls.Add(cmbTipoCentral);
        grp.Controls.Add(lblCantidadCentral);
        grp.Controls.Add(lblColorCentral);

        grp.Controls.Add(lblRecubrimiento);
        grp.Controls.Add(txtRecubrimiento);
        grp.Controls.Add(lblCmRec);
        grp.Controls.Add(chkDetectarColumnas);

        grp.Controls.Add(chkCrearEmpalmes);
        grp.Controls.Add(lblLongitudEmpalme);
        grp.Controls.Add(txtLongitudEmpalme);
        grp.Controls.Add(lblCmEmpalme);
        grp.Controls.Add(lblLongitudBarra);
        grp.Controls.Add(txtLongitudBarra);
        grp.Controls.Add(lblMBarra);
        grp.Controls.Add(chkUsarRNE);
        grp.Controls.Add(lblInfoRNE);

        grp.Controls.Add(chkGanchoInicio);
        grp.Controls.Add(txtLongitudGanchoInicio);
        grp.Controls.Add(lblCmGanchoInicio);

        grp.Controls.Add(chkGanchoFin);
        grp.Controls.Add(txtLongitudGanchoFin);
        grp.Controls.Add(lblCmGanchoFin);

        grp.Controls.Add(lblDesarrolloInicio);
        grp.Controls.Add(txtLongitudDesarrolloInicio);
        grp.Controls.Add(lblCmDesIni);

        grp.Controls.Add(lblDesarrolloFin);
        grp.Controls.Add(txtLongitudDesarrolloFin);
        grp.Controls.Add(lblCmDesFin);

        this.Controls.Add(grp);
    }

    // =====================================
    // CONTROLES AUXILIARES
    // =====================================
    private WinForms.Label CrearLabel(string texto, int left, int top, int width)
    {
        return new WinForms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(45, 45, 45)
        };
    }

    private WinForms.Label CrearLabelNormal(string texto, int left, int top, int width)
    {
        return new WinForms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.2F),
            ForeColor = Drawing.Color.Gray
        };
    }

    private WinForms.TextBox CrearTextBox(int left, int top, int width, string text)
    {
        return new WinForms.TextBox()
        {
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            BackColor = Drawing.Color.White,
            Text = text
        };
    }

    private WinForms.ComboBox CrearCombo(int left, int top, int width)
    {
        return new WinForms.ComboBox()
        {
            Left = left,
            Top = top,
            Width = width,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false
        };
    }

    // =====================================
    // ACTIVAR PANEL
    // =====================================
    public void Activar()
    {
        RefrescarPreview();
    }

    // =====================================
    // CARGAR TIPOS
    // =====================================
    public void CargarTiposArmadura(List<RebarBarType> tipos)
    {
        cmbTipoSuperior.Items.Clear();
        cmbTipoInferior.Items.Clear();
        cmbTipoCentral.Items.Clear();

        if (tipos == null)
            return;

        foreach (RebarBarType tipo in tipos)
        {
            cmbTipoSuperior.Items.Add(tipo);
            cmbTipoInferior.Items.Add(tipo);
            cmbTipoCentral.Items.Add(tipo);
        }

        cmbTipoSuperior.DisplayMember = "Name";
        cmbTipoInferior.DisplayMember = "Name";
        cmbTipoCentral.DisplayMember = "Name";

        if (cmbTipoSuperior.Items.Count > 0)
            cmbTipoSuperior.SelectedIndex = 0;

        if (cmbTipoInferior.Items.Count > 0)
            cmbTipoInferior.SelectedIndex = 0;

        if (cmbTipoCentral.Items.Count > 0)
            cmbTipoCentral.SelectedIndex = 0;

        ActualizarEstadoAceroCentral();

        if (UsarRNE)
            CalcularYAplicarEmpalmeRNE();
    }

    // =====================================
    // ESTADOS
    // =====================================
    private void ActualizarEstadoAceroCentral()
    {
        bool activo = chkAceroCentral != null && chkAceroCentral.Checked;

        if (cmbTipoCentral != null)
        {
            cmbTipoCentral.Enabled = activo;
            cmbTipoCentral.BackColor = activo
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (lblTipoCentral != null)
            lblTipoCentral.Enabled = activo;

        if (lblCantidadCentral != null)
            lblCantidadCentral.Enabled = activo;
    }

    private void ActualizarEstadoEmpalmes()
    {
        bool activo = chkCrearEmpalmes != null && chkCrearEmpalmes.Checked;
        bool usarRNE = chkUsarRNE != null && chkUsarRNE.Checked;

        if (lblLongitudEmpalme != null)
            lblLongitudEmpalme.Enabled = activo;

        if (txtLongitudEmpalme != null)
        {
            txtLongitudEmpalme.Enabled = activo && !usarRNE;
            txtLongitudEmpalme.BackColor = activo && !usarRNE
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (lblCmEmpalme != null)
            lblCmEmpalme.Enabled = activo && !usarRNE;

        if (lblLongitudBarra != null)
            lblLongitudBarra.Enabled = activo;

        if (txtLongitudBarra != null)
        {
            txtLongitudBarra.Enabled = activo;
            txtLongitudBarra.BackColor = activo
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (lblMBarra != null)
            lblMBarra.Enabled = activo;
    }

    private void ActualizarEstadoRNE()
    {
        bool usarRNE = chkUsarRNE != null && chkUsarRNE.Checked;
        bool crearEmpalmes = chkCrearEmpalmes != null && chkCrearEmpalmes.Checked;

        if (lblInfoRNE != null)
            lblInfoRNE.Visible = usarRNE && crearEmpalmes;

        if (usarRNE && crearEmpalmes)
        {
            if (txtLongitudEmpalme != null)
                txtLongitudEmpalme.Text = "";

            CalcularYAplicarEmpalmeRNE();
        }
        else
        {
            empalmeRNESuperiorCm = 0.0;
            empalmeRNEInferiorCm = 0.0;
            empalmeRNECentralCm = 0.0;

            if (lblInfoRNE != null)
                lblInfoRNE.Text = "";

            if (txtLongitudEmpalme != null &&
                string.IsNullOrWhiteSpace(txtLongitudEmpalme.Text))
            {
                txtLongitudEmpalme.Text = "60";
            }
        }
    }

    private void ActualizarEstadoGanchos()
    {
        bool inicio = chkGanchoInicio != null && chkGanchoInicio.Checked;
        bool fin = chkGanchoFin != null && chkGanchoFin.Checked;

        if (txtLongitudGanchoInicio != null)
        {
            txtLongitudGanchoInicio.Enabled = inicio;
            txtLongitudGanchoInicio.BackColor = inicio
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (txtLongitudGanchoFin != null)
        {
            txtLongitudGanchoFin.Enabled = fin;
            txtLongitudGanchoFin.BackColor = fin
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }
    }

    private void RefrescarPreview()
    {
        if (form != null && form.panelPreview != null)
            form.panelPreview.Invalidate();
    }

    // =====================================
    // VALIDAR
    // =====================================
    public bool ValidarAntesEjecutar()
    {
        if (TipoSuperiorSeleccionado == null)
        {
            WinForms.MessageBox.Show("Debe seleccionar el tipo de barra superior.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (TipoInferiorSeleccionado == null)
        {
            WinForms.MessageBox.Show("Debe seleccionar el tipo de barra inferior.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (AceroCentral && TipoCentralSeleccionado == null)
        {
            WinForms.MessageBox.Show("Debe seleccionar el tipo de barra central.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (!TextoNumeroMayorCero(CantidadSuperiorTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar una cantidad superior válida.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (!TextoNumeroMayorCero(CantidadInferiorTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar una cantidad inferior válida.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (!TextoNumeroMayorIgualCero(RecubrimientoTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar un recubrimiento válido.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (CrearEmpalmes)
        {
            if (UsarRNE)
            {
                CalcularYAplicarEmpalmeRNE();

                if (empalmeRNESuperiorCm <= 0.0 ||
                    empalmeRNEInferiorCm <= 0.0)
                {
                    WinForms.MessageBox.Show("No se pudo calcular la longitud de empalme RNE.", "MYG",
                        WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
            {
                if (!TextoNumeroMayorCero(LongitudEmpalmeTexto))
                {
                    WinForms.MessageBox.Show("Debe ingresar una longitud de empalme válida.", "MYG",
                        WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                    return false;
                }
            }

            if (!TextoNumeroMayorCero(LongitudBarraTexto))
            {
                WinForms.MessageBox.Show("Debe ingresar una longitud de barra válida.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (GanchoInicio && !TextoNumeroMayorCero(LongitudGanchoInicioTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar una longitud de gancho inicial válida.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (GanchoFin && !TextoNumeroMayorCero(LongitudGanchoFinTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar una longitud de gancho final válida.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (LongitudDesarrolloInicioHabilitada &&
            !TextoNumeroMayorIgualCero(LongitudDesarrolloInicioTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar una longitud de desarrollo inicial válida.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        if (LongitudDesarrolloFinHabilitada &&
            !TextoNumeroMayorIgualCero(LongitudDesarrolloFinTexto))
        {
            WinForms.MessageBox.Show("Debe ingresar una longitud de desarrollo final válida.", "MYG",
                WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }

    private bool TextoNumeroMayorCero(string texto)
    {
        double valor = 0.0;

        if (!TryLeerDouble(texto, out valor))
            return false;

        return valor > 0.0;
    }

    private bool TextoNumeroMayorIgualCero(string texto)
    {
        double valor = 0.0;

        if (!TryLeerDouble(texto, out valor))
            return false;

        return valor >= 0.0;
    }

    private bool TryLeerDouble(string texto, out double valor)
    {
        valor = 0.0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string t = texto.Trim().Replace(",", ".");

        return double.TryParse(
            t,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor);
    }

    // =====================================
    // PROPIEDADES USADAS POR EL HANDLER
    // =====================================
    public RebarBarType TipoSuperiorSeleccionado
    {
        get { return cmbTipoSuperior.SelectedItem as RebarBarType; }
    }

    public RebarBarType TipoInferiorSeleccionado
    {
        get { return cmbTipoInferior.SelectedItem as RebarBarType; }
    }

    public RebarBarType TipoCentralSeleccionado
    {
        get { return cmbTipoCentral.SelectedItem as RebarBarType; }
    }

    public bool AceroCentral
    {
        get { return chkAceroCentral != null && chkAceroCentral.Checked; }
    }

    public bool CrearEmpalmes
    {
        get { return chkCrearEmpalmes != null && chkCrearEmpalmes.Checked; }
    }

    public bool UsarRNE
    {
        get { return chkUsarRNE != null && chkUsarRNE.Checked; }
    }

    public string LongitudEmpalmeTexto
    {
        get
        {
            if (UsarRNE)
                return LongitudEmpalmeInferiorTexto;

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudEmpalmeSuperiorTexto
    {
        get
        {
            if (UsarRNE)
                return FormatearCentimetrosEnteros(empalmeRNESuperiorCm);

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudEmpalmeInferiorTexto
    {
        get
        {
            if (UsarRNE)
                return FormatearCentimetrosEnteros(empalmeRNEInferiorCm);

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudEmpalmeCentralTexto
    {
        get
        {
            if (UsarRNE)
                return FormatearCentimetrosEnteros(empalmeRNECentralCm);

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudBarraTexto
    {
        get { return txtLongitudBarra.Text.Trim(); }
    }

    public string CantidadSuperiorTexto
    {
        get { return txtCantidadSuperior.Text.Trim(); }
    }

    public string CantidadInferiorTexto
    {
        get { return txtCantidadInferior.Text.Trim(); }
    }

    public string RecubrimientoTexto
    {
        get { return txtRecubrimiento.Text.Trim(); }
    }

    public bool DetectarColumnas
    {
        get { return chkDetectarColumnas != null && chkDetectarColumnas.Checked; }
    }

    public bool GanchoInicio
    {
        get { return chkGanchoInicio != null && chkGanchoInicio.Checked; }
    }

    public bool GanchoFin
    {
        get { return chkGanchoFin != null && chkGanchoFin.Checked; }
    }

    public string LongitudGanchoInicioTexto
    {
        get { return txtLongitudGanchoInicio.Text.Trim(); }
    }

    public string LongitudGanchoFinTexto
    {
        get { return txtLongitudGanchoFin.Text.Trim(); }
    }

    public string LongitudDesarrolloInicioTexto
    {
        get { return txtLongitudDesarrolloInicio.Text.Trim(); }
    }

    public string LongitudDesarrolloFinTexto
    {
        get { return txtLongitudDesarrolloFin.Text.Trim(); }
    }

    public bool LongitudDesarrolloInicioHabilitada
    {
        get { return txtLongitudDesarrolloInicio != null && txtLongitudDesarrolloInicio.Enabled; }
    }

    public bool LongitudDesarrolloFinHabilitada
    {
        get { return txtLongitudDesarrolloFin != null && txtLongitudDesarrolloFin.Enabled; }
    }

    // =====================================
    // MODELO PREVIEW PARA HANDLER
    // =====================================
    public AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview ObtenerModeloPreviewActual()
    {
        AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modelo =
            new AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview();

        // IMPORTANTE:
        // Se deja Valido = false para que tu handler actual use la lógica original
        // de creación por geometría real como respaldo, sin romper tu creación actual.
        modelo.Valido = false;

        double recCm = 0.0;
        TryLeerDouble(RecubrimientoTexto, out recCm);

        modelo.RecubrimientoMm = recCm * 10.0;
        modelo.CrearEmpalmes = CrearEmpalmes;

        double longBarraM = 0.0;
        TryLeerDouble(LongitudBarraTexto, out longBarraM);
        modelo.LongitudBarraMm = longBarraM * 1000.0;

        double empSupCm = 0.0;
        double empInfCm = 0.0;
        double empCenCm = 0.0;

        TryLeerDouble(LongitudEmpalmeSuperiorTexto, out empSupCm);
        TryLeerDouble(LongitudEmpalmeInferiorTexto, out empInfCm);
        TryLeerDouble(LongitudEmpalmeCentralTexto, out empCenCm);

        modelo.LongitudEmpalmeSuperiorMm = empSupCm * 10.0;
        modelo.LongitudEmpalmeInferiorMm = empInfCm * 10.0;
        modelo.LongitudEmpalmeCentralMm = empCenCm * 10.0;

        modelo.GanchoInicio = GanchoInicio;
        modelo.GanchoFin = GanchoFin;

        double ganIniCm = 0.0;
        double ganFinCm = 0.0;

        TryLeerDouble(LongitudGanchoInicioTexto, out ganIniCm);
        TryLeerDouble(LongitudGanchoFinTexto, out ganFinCm);

        modelo.LongitudGanchoInicioMm = ganIniCm * 10.0;
        modelo.LongitudGanchoFinMm = ganFinCm * 10.0;

        return modelo;
    }

    // =====================================
    // ACTUALIZAR PREVIEW
    // =====================================
    public void ActualizarVistaPreviaMultiple(List<VigaLongitudinalPreview> vigas)
    {
        previewVigas = vigas ?? new List<VigaLongitudinalPreview>();
        RefrescarPreview();
    }

    // =====================================
    // DIBUJAR VISTA PRELIMINAR
    // =====================================
    public void DibujarVistaPrevia(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        List<VigaLongitudinalPreview> vigas)
    {
        if (g == null)
            return;

        List<VigaLongitudinalPreview> lista =
            vigas != null && vigas.Count > 0
                ? vigas
                : previewVigas;

        if (lista == null || lista.Count == 0)
        {
            using (Drawing.Brush b = new Drawing.SolidBrush(Drawing.Color.Gray))
            {
                g.DrawString(
                    "Seleccione vigas para generar la vista preliminar.",
                    new Drawing.Font("Segoe UI", 8.5F),
                    b,
                    area.Left + 10,
                    area.Top + 10);
            }

            return;
        }

        double totalMm = 0.0;

        foreach (VigaLongitudinalPreview v in lista)
        {
            if (v == null)
                continue;

            double l = v.LongitudSolidoMm > 0.0 ? v.LongitudSolidoMm : v.LongitudMm;

            if (l > 0.0)
                totalMm += l;
        }

        if (totalMm <= 0.0)
            return;

        double ldIniMm = 0.0;
        double ldFinMm = 0.0;

        if (LongitudDesarrolloInicioHabilitada)
        {
            double cm = 0.0;
            if (TryLeerDouble(LongitudDesarrolloInicioTexto, out cm))
                ldIniMm = cm * 10.0;
        }

        if (LongitudDesarrolloFinHabilitada)
        {
            double cm = 0.0;
            if (TryLeerDouble(LongitudDesarrolloFinTexto, out cm))
                ldFinMm = cm * 10.0;
        }

        double minXModelo = -ldIniMm;
        double maxXModelo = totalMm + ldFinMm;

        if (maxXModelo <= minXModelo)
            return;

        Func<double, float> mapX = (xMm) =>
        {
            double t = (xMm - minXModelo) / (maxXModelo - minXModelo);
            return (float)(area.Left + t * area.Width);
        };

        float yCentro = area.Top + area.Height * 0.50f;
        float altoViga = Math.Max(55f, area.Height * 0.32f);

        float ySup = yCentro - altoViga / 2f;
        float yInf = yCentro + altoViga / 2f;

        float yAcSup = ySup + 18f;
        float yAcInf = yInf - 18f;
        float yAcCen = yCentro;

        // =====================================
        // DIBUJAR VIGAS
        // =====================================
        float xCursor = mapX(0.0);

        using (Drawing.Pen penViga = new Drawing.Pen(Drawing.Color.FromArgb(90, 90, 90), 2f))
        using (Drawing.Brush brushViga = new Drawing.SolidBrush(Drawing.Color.FromArgb(235, 235, 235)))
        using (Drawing.Brush brushTexto = new Drawing.SolidBrush(Drawing.Color.FromArgb(70, 70, 70)))
        {
            double acumulado = 0.0;

            foreach (VigaLongitudinalPreview v in lista)
            {
                if (v == null)
                    continue;

                double l = v.LongitudSolidoMm > 0.0 ? v.LongitudSolidoMm : v.LongitudMm;

                if (l <= 0.0)
                    continue;

                float x0 = mapX(acumulado);
                float x1 = mapX(acumulado + l);

                Drawing.RectangleF rect = new Drawing.RectangleF(
                    x0,
                    ySup,
                    Math.Max(1f, x1 - x0),
                    yInf - ySup);

                g.FillRectangle(brushViga, rect);
                g.DrawRectangle(
                    penViga,
                    rect.X,
                    rect.Y,
                    rect.Width,
                    rect.Height);

                string nombre = string.IsNullOrWhiteSpace(v.Nombre) ? "Viga" : v.Nombre;

                g.DrawString(
                    nombre,
                    new Drawing.Font("Segoe UI", 7.5F, Drawing.FontStyle.Bold),
                    brushTexto,
                    x0 + 4,
                    yInf + 6);

                acumulado += l;
            }
        }

        // =====================================
        // DIBUJAR COLUMNAS REFERENCIALES
        // =====================================
        using (Drawing.Brush brushCol = new Drawing.SolidBrush(Drawing.Color.FromArgb(205, 205, 205)))
        using (Drawing.Pen penCol = new Drawing.Pen(Drawing.Color.FromArgb(120, 120, 120), 1f))
        {
            double acumulado = 0.0;

            foreach (VigaLongitudinalPreview v in lista)
            {
                if (v == null)
                    continue;

                double l = v.LongitudSolidoMm > 0.0 ? v.LongitudSolidoMm : v.LongitudMm;

                if (v.Columnas != null)
                {
                    foreach (AceroLongitudinalVigasForm.ColumnaPreview col in v.Columnas)
                    {
                        if (col == null)
                            continue;

                        double centro = acumulado + col.CentroMm;
                        double ancho = col.AnchoMm > 0.0 ? col.AnchoMm : 300.0;

                        float xc = mapX(centro);
                        float x0 = mapX(centro - ancho / 2.0);
                        float x1 = mapX(centro + ancho / 2.0);

                        Drawing.RectangleF rc = new Drawing.RectangleF(
                            x0,
                            ySup - 22f,
                            Math.Max(4f, x1 - x0),
                            (yInf - ySup) + 44f);

                        g.FillRectangle(brushCol, rc);
                        g.DrawRectangle(penCol, rc.X, rc.Y, rc.Width, rc.Height);
                    }
                }

                acumulado += l;
            }
        }

        // =====================================
        // DIBUJAR ACEROS
        // =====================================
        double xBarraIni = -ldIniMm;
        double xBarraFin = totalMm + ldFinMm;

        using (Drawing.Pen penSup = new Drawing.Pen(ColorAceroSuperior, 2.5f))
        using (Drawing.Pen penInf = new Drawing.Pen(ColorAceroInferior, 2.5f))
        using (Drawing.Pen penCen = new Drawing.Pen(ColorAceroCentral, 2.0f))
        {
            g.DrawLine(penSup, mapX(xBarraIni), yAcSup, mapX(xBarraFin), yAcSup);
            g.DrawLine(penInf, mapX(xBarraIni), yAcInf, mapX(xBarraFin), yAcInf);

            if (AceroCentral)
                g.DrawLine(penCen, mapX(xBarraIni), yAcCen, mapX(xBarraFin), yAcCen);
        }

        // =====================================
        // GANCHOS REFERENCIALES
        // =====================================
        using (Drawing.Pen penGancho = new Drawing.Pen(Drawing.Color.FromArgb(60, 60, 60), 1.5f))
        {
            if (GanchoInicio)
            {
                float x = mapX(xBarraIni);
                g.DrawLine(penGancho, x, yAcSup, x - 12f, yAcSup + 18f);
                g.DrawLine(penGancho, x, yAcInf, x - 12f, yAcInf - 18f);
            }

            if (GanchoFin)
            {
                float x = mapX(xBarraFin);
                g.DrawLine(penGancho, x, yAcSup, x + 12f, yAcSup + 18f);
                g.DrawLine(penGancho, x, yAcInf, x + 12f, yAcInf - 18f);
            }
        }

        // =====================================
        // DIBUJAR EMPALMES REFERENCIALES
        // =====================================
        if (CrearEmpalmes)
        {
            double longBarraM = 0.0;
            double empalmeCm = 0.0;

            TryLeerDouble(LongitudBarraTexto, out longBarraM);
            TryLeerDouble(LongitudEmpalmeTexto, out empalmeCm);

            double longBarraMm = longBarraM * 1000.0;
            double empalmeMm = empalmeCm * 10.0;

            if (longBarraMm > empalmeMm && empalmeMm > 0.0)
            {
                using (Drawing.Pen penEmp = new Drawing.Pen(ColorEmpalmePreview, 4.0f))
                {
                    double paso = longBarraMm - empalmeMm;
                    double x = xBarraIni + paso;

                    while (x < xBarraFin - 1.0)
                    {
                        double e0 = x;
                        double e1 = Math.Min(x + empalmeMm, xBarraFin);

                        g.DrawLine(penEmp, mapX(e0), yAcSup, mapX(e1), yAcSup);
                        g.DrawLine(penEmp, mapX(e0), yAcInf, mapX(e1), yAcInf);

                        if (AceroCentral)
                            g.DrawLine(penEmp, mapX(e0), yAcCen, mapX(e1), yAcCen);

                        x += paso;
                    }
                }
            }
        }

        // =====================================
        // COTA GENERAL
        // =====================================
        using (Drawing.Pen penCota = new Drawing.Pen(Drawing.Color.Gray, 1f))
        using (Drawing.Brush brush = new Drawing.SolidBrush(Drawing.Color.Gray))
        {
            penCota.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

            float yCota = area.Bottom - 18f;

            g.DrawLine(penCota, mapX(0.0), yCota, mapX(totalMm), yCota);

            string texto = "Longitud ref.: " +
                (totalMm / 1000.0).ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) +
                " m";

            g.DrawString(
                texto,
                new Drawing.Font("Segoe UI", 8F),
                brush,
                mapX(0.0),
                yCota + 2f);
        }
    }

    // =====================================
    // RNE
    // =====================================
    private void CalcularYAplicarEmpalmeRNE()
    {
        if (!UsarRNE)
            return;

        empalmeRNESuperiorCm = CalcularEmpalmeRNECm(
            TipoSuperiorSeleccionado,
            rneFcKgCm2,
            rnePsiSuperior);

        empalmeRNEInferiorCm = CalcularEmpalmeRNECm(
            TipoInferiorSeleccionado,
            rneFcKgCm2,
            rnePsiInferior);

        if (AceroCentral && TipoCentralSeleccionado != null)
        {
            empalmeRNECentralCm = CalcularEmpalmeRNECm(
                TipoCentralSeleccionado,
                rneFcKgCm2,
                rnePsiCentral);
        }
        else
        {
            empalmeRNECentralCm = empalmeRNEInferiorCm;
        }

        ActualizarTextoInfoRNE();
    }

    private double CalcularEmpalmeRNECm(
        RebarBarType tipoBarra,
        double fcKgCm2,
        double psiT)
    {
        double dbMm = ObtenerDiametroBarraMm(tipoBarra);

        if (dbMm <= 0.0)
            return 0.0;

        double ldMm = CalcularLdRNEMm(dbMm, fcKgCm2, psiT);

        if (ldMm <= 0.0)
            return 0.0;

        double leMm = rneFactorEmpalme * ldMm;

        if (leMm < rneMinEmpalmeMm)
            leMm = rneMinEmpalmeMm;

        return Math.Ceiling(leMm / 10.0);
    }

    private double CalcularLdRNEMm(
        double dbMm,
        double fcKgCm2,
        double psiT)
    {
        if (dbMm <= 0.0 || fcKgCm2 <= 0.0)
            return 0.0;

        double fcMpa = fcKgCm2 / 10.0;

        if (fcMpa <= 0.0)
            return 0.0;

        double fyMpa = rneFyMpa <= 0.0 ? 420.0 : rneFyMpa;
        double psiE = rnePsiE <= 0.0 ? 1.0 : rnePsiE;
        double lambda = rneLambda <= 0.0 ? 1.0 : rneLambda;

        double limiteTresCuartosMm = 19.05;
        double denominador = dbMm <= limiteTresCuartosMm ? 2.6 : 2.1;

        return (fyMpa * psiT * psiE * dbMm) /
            (denominador * lambda * Math.Sqrt(fcMpa));
    }

    private void ActualizarTextoInfoRNE()
    {
        if (lblInfoRNE == null)
            return;

        if (!UsarRNE || !CrearEmpalmes)
        {
            lblInfoRNE.Text = "";
            return;
        }

        string sup = empalmeRNESuperiorCm > 0.0
            ? FormatearCentimetrosEnteros(empalmeRNESuperiorCm) + " cm"
            : "--";

        string inf = empalmeRNEInferiorCm > 0.0
            ? FormatearCentimetrosEnteros(empalmeRNEInferiorCm) + " cm"
            : "--";

        if (AceroCentral)
        {
            string cen = empalmeRNECentralCm > 0.0
                ? FormatearCentimetrosEnteros(empalmeRNECentralCm) + " cm"
                : "--";

            lblInfoRNE.Text = "RNE Sup: " + sup + "\nInf: " + inf + " | Cen: " + cen;
        }
        else
        {
            lblInfoRNE.Text = "RNE Sup: " + sup + "\nInf: " + inf;
        }
    }

    private string FormatearCentimetrosEnteros(double valorCm)
    {
        if (valorCm <= 0.0)
            return "";

        return Math.Ceiling(valorCm).ToString(
            "0",
            System.Globalization.CultureInfo.InvariantCulture);
    }

    private double ObtenerDiametroBarraMm(RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        string[] nombresParametros =
        {
            "Diámetro de barra",
            "Diámetro de barra de modelo",
            "Bar Diameter",
            "Model Bar Diameter",
            "Nominal Diameter",
            "Diámetro nominal"
        };

        foreach (string nombre in nombresParametros)
        {
            try
            {
                Parameter p = tipo.LookupParameter(nombre);

                if (p != null && p.StorageType == StorageType.Double)
                {
                    double valorInterno = p.AsDouble();

                    if (valorInterno > 0.0)
                    {
                        double mm = UnitUtils.ConvertFromInternalUnits(
                            valorInterno,
                            UnitTypeId.Millimeters);

                        if (mm > 0.0)
                            return mm;
                    }
                }
            }
            catch
            {
                // Continuar.
            }
        }

        try
        {
            return ObtenerDiametroDesdeNombreTipo(tipo.Name);
        }
        catch
        {
            return 0.0;
        }
    }

    private double ObtenerDiametroDesdeNombreTipo(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre))
            return 0.0;

        string t = nombre.Trim().ToUpperInvariant();

        if (t.Contains("3/8"))
            return 9.525;

        if (t.Contains("1/2"))
            return 12.700;

        if (t.Contains("5/8"))
            return 15.875;

        if (t.Contains("3/4"))
            return 19.050;

        if (t.Contains("7/8"))
            return 22.225;

        if (t.Contains("1\"") || t.Contains("1''") || t.Contains(" 1 "))
            return 25.400;

        System.Text.RegularExpressions.Match m =
            System.Text.RegularExpressions.Regex.Match(
                t.Replace(",", "."),
                @"\d+(\.\d+)?");

        if (m.Success)
        {
            double valor = 0.0;

            if (double.TryParse(
                m.Value,
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor))
            {
                if (valor > 0.0 && valor <= 60.0)
                    return valor;
            }
        }

        return 0.0;
    }
}