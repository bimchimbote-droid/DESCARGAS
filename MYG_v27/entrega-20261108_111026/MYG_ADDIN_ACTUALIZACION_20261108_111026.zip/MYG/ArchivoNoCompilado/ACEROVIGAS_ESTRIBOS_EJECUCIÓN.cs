﻿// =====================================
// HANDLER TEMPORAL - EJECUTAR ESTRIBOS
// Luego aquí irá la lógica real para crear estribos.
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

public class EjecutarEstribosVigasHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public AceroLongitudinalVigasForm Form;
    public SeleccionarVigasAceroLongitudinalHandler SeleccionHandler;

    public void Execute(UIApplication app)
    {
        TaskDialog.Show(
            "MYG - Estribos",
            "Modo Estribos activo.\n\n" +
            "Todavía falta conectar la lógica real de creación de estribos.");
    }

    public string GetName()
    {
        return "MYG - Ejecutar estribos en vigas";
    }
}