﻿
// =====================================
// CLASE AUXILIAR - VISTA PRELIMINAR DE VIGA
// =====================================
using MYG_Addin;
using System.Collections.Generic;


public class VigaLongitudinalPreview
{
    public double LongitudMm { get; set; }

    // Longitud visible/libre del sólido real de la viga.
    // Se mantiene como respaldo para la ventana.
    public double LongitudSolidoMm { get; set; }

    // 🔥 NUEVO: datos geométricos para que la ventana pueda detectar inclinación.
    public double DeltaZMm { get; set; }
    public double ProyeccionHorizontalMm { get; set; }
    public double AnguloGrados { get; set; }
    public bool EsInclinada { get; set; }

    // PERFIL LIMPIO PARA VIGAS / ARMAZONES DE SECCIÓN VARIABLE.
    // Se guarda solo inicio y fin de la cara superior/inferior.
    // No se guardan todos los vértices del sólido para evitar picos o quiebres falsos.
    public bool TienePerfilSeccionVariable { get; set; }
    public double ZSuperiorInicioMm { get; set; }
    public double ZSuperiorFinMm { get; set; }
    public double ZInferiorInicioMm { get; set; }
    public double ZInferiorFinMm { get; set; }

    // PERFIL DETALLADO PARA QUE LA VENTANA Y EL HANDLER USEN LA MISMA RUTA.
    // La ventana lo lee por reflexión con los nombres PerfilSuperiorMm / PerfilInferiorMm.
    public class PuntoPerfilMm
    {
        public double XMm { get; set; }
        public double ZMm { get; set; }

        public PuntoPerfilMm(double xMm, double zMm)
        {
            XMm = xMm;
            ZMm = zMm;
        }
    }

    public List<PuntoPerfilMm> PerfilSuperiorMm { get; set; }
    public List<PuntoPerfilMm> PerfilInferiorMm { get; set; }

    public List<AceroLongitudinalVigasForm.ColumnaPreview> Columnas { get; set; }
    public string Nombre { get; set; }

    public VigaLongitudinalPreview(
        double longitudMm,
        List<AceroLongitudinalVigasForm.ColumnaPreview> columnas,
        string nombre)
    {
        LongitudMm = longitudMm;
        LongitudSolidoMm = 0.0;
        DeltaZMm = 0.0;
        ProyeccionHorizontalMm = longitudMm;
        AnguloGrados = 0.0;
        EsInclinada = false;

        TienePerfilSeccionVariable = false;
        ZSuperiorInicioMm = 0.0;
        ZSuperiorFinMm = 0.0;
        ZInferiorInicioMm = 0.0;
        ZInferiorFinMm = 0.0;
        PerfilSuperiorMm = new List<PuntoPerfilMm>();
        PerfilInferiorMm = new List<PuntoPerfilMm>();

        Columnas = columnas ?? new List<AceroLongitudinalVigasForm.ColumnaPreview>();
        Nombre = nombre;
    }
}