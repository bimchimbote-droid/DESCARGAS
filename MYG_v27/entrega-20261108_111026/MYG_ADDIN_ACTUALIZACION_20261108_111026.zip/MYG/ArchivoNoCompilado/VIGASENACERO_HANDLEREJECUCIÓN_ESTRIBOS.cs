﻿// =====================================
// HANDLER EXTERNO - EJECUTAR ESTRIBOS
// Archivo: EjecutarEstribosVigasHandler.cs
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace MYG_Addin
{
    public class EjecutarEstribosVigasHandler : IExternalEventHandler
    {
        public UIDocument UiDoc;
        public AceroLongitudinalVigasForm Form;
        public SeleccionarVigasAceroLongitudinalHandler SeleccionHandler;

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

            if (uidoc == null)
                return;

            if (Form == null)
                return;

            if (SeleccionHandler == null ||
                SeleccionHandler.VigasSeleccionadas == null ||
                SeleccionHandler.VigasSeleccionadas.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Estribos",
                    "Primero debe seleccionar una o más vigas o armazones estructurales.");

                return;
            }

            TaskDialog.Show(
                "MYG - Estribos",
                "Modo Estribos activo.\n\n" +
                "Cantidad de vigas seleccionadas: " +
                SeleccionHandler.VigasSeleccionadas.Count.ToString() +
                "\n\nAquí irá la lógica real para crear estribos.");
        }

        public string GetName()
        {
            return "MYG - Ejecutar estribos en vigas";
        }
    }
}