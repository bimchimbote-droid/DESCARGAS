﻿// =====================================
// ARCHIVO 03 - PANEL ESTRIBOS
// PanelEstribosVigas.cs
// PEGAR DENTRO DEL NAMESPACE MYG_Addin
// =====================================

using Autodesk.Revit.DB.Structure;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Windows.Media;

public class PanelEstribosVigas : WinForms.Panel
{
    private AceroLongitudinalVigasForm form;

    // =====================================
    // CONTROLES
    // =====================================
    private WinForms.ComboBox cmbTipoEstribo;

    private WinForms.TextBox txtRecubrimiento;
    private WinForms.TextBox txtSeparacionEstribo;
    private WinForms.TextBox txtLongitudGanchoEstribo;

    private WinForms.CheckBox chkDetectarColumnas;
    private WinForms.CheckBox chkGanchoEstribo;

    private WinForms.Label lblCantidadEstimativa;
    private WinForms.Label lblInfo;

    private List<VigaLongitudinalPreview> previewVigas =
        new List<VigaLongitudinalPreview>();

    private readonly Drawing.Color ColorEstribo = Drawing.Color.FromArgb(145, 60, 180);
    private readonly Drawing.Color ColorViga = Drawing.Color.FromArgb(235, 235, 235);
    private readonly Drawing.Color ColorBorde = Drawing.Color.FromArgb(90, 90, 90);
    private readonly Drawing.Color ColorColumna = Drawing.Color.FromArgb(205, 205, 205);

    // =====================================
    // CONSTRUCTOR
    // =====================================
    public PanelEstribosVigas(AceroLongitudinalVigasForm owner)
    {
        form = owner;

        this.BackColor = Drawing.Color.FromArgb(245, 247, 250);

        CrearControles();
        ActualizarEstadoGancho();
    }

    // =====================================
    // CREAR CONTROLES
    // =====================================
    private void CrearControles()
    {
        WinForms.GroupBox grp = new WinForms.GroupBox()
        {
            Text = "Parámetros de estribos",
            Left = 0,
            Top = 0,
            Width = 735,
            Height = 205,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        // =====================================
        // FILA 01 - TIPO ESTRIBO
        // =====================================
        WinForms.Label lblTipoEstribo = CrearLabel("Tipo de estribo:", 20, 30, 125);

        cmbTipoEstribo = new WinForms.ComboBox()
        {
            Left = 155,
            Top = 27,
            Width = 210,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false
        };

        cmbTipoEstribo.SelectedIndexChanged += (s, e) =>
        {
            RefrescarPreview();
        };

        WinForms.Label lblColor = new WinForms.Label()
        {
            Text = "●",
            Left = 370,
            Top = 24,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = ColorEstribo,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        // =====================================
        // FILA 02 - RECUBRIMIENTO
        // =====================================
        WinForms.Label lblRecubrimiento = CrearLabel("Recubrimiento:", 20, 65, 125);

        txtRecubrimiento = CrearTextBox(155, 62, 55, "4");

        txtRecubrimiento.TextChanged += (s, e) =>
        {
            RefrescarPreview();
        };

        WinForms.Label lblCmRec = CrearLabelNormal("cm", 215, 65, 35);

        chkDetectarColumnas = new WinForms.CheckBox()
        {
            Text = "Detectar columnas adyacentes",
            Left = 270,
            Top = 63,
            Width = 240,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = true,
            Font = new Drawing.Font("Segoe UI", 8.5F)
        };

        chkDetectarColumnas.CheckedChanged += (s, e) =>
        {
            RefrescarPreview();
        };

        // =====================================
        // FILA 03 - SEPARACIÓN
        // =====================================
        WinForms.Label lblSeparacion = CrearLabel("Separación:", 20, 100, 125);

        txtSeparacionEstribo = CrearTextBox(155, 97, 55, "15");

        txtSeparacionEstribo.TextChanged += (s, e) =>
        {
            ActualizarCantidadEstimativa();
            RefrescarPreview();
        };

        WinForms.Label lblCmSep = CrearLabelNormal("cm", 215, 100, 35);

        lblCantidadEstimativa = new WinForms.Label()
        {
            Text = "Cantidad estimada: --",
            Left = 270,
            Top = 100,
            Width = 250,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(70, 70, 70)
        };

        // =====================================
        // FILA 04 - GANCHO
        // =====================================
        chkGanchoEstribo = new WinForms.CheckBox()
        {
            Text = "Gancho de estribo",
            Left = 20,
            Top = 133,
            Width = 130,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = true,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        chkGanchoEstribo.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoGancho();
            RefrescarPreview();
        };

        WinForms.Label lblGancho = CrearLabel("L. gancho:", 155, 134, 80);

        txtLongitudGanchoEstribo = CrearTextBox(240, 131, 55, "10");

        txtLongitudGanchoEstribo.TextChanged += (s, e) =>
        {
            RefrescarPreview();
        };

        WinForms.Label lblCmGancho = CrearLabelNormal("cm", 300, 134, 35);

        // =====================================
        // INFO
        // =====================================
        lblInfo = new WinForms.Label()
        {
            Text = "Los estribos usarán la misma selección de vigas/armazones y la misma vista preliminar.",
            Left = 20,
            Top = 168,
            Width = 690,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.Gray
        };

        // =====================================
        // AGREGAR CONTROLES
        // =====================================
        grp.Controls.Add(lblTipoEstribo);
        grp.Controls.Add(cmbTipoEstribo);
        grp.Controls.Add(lblColor);

        grp.Controls.Add(lblRecubrimiento);
        grp.Controls.Add(txtRecubrimiento);
        grp.Controls.Add(lblCmRec);
        grp.Controls.Add(chkDetectarColumnas);

        grp.Controls.Add(lblSeparacion);
        grp.Controls.Add(txtSeparacionEstribo);
        grp.Controls.Add(lblCmSep);
        grp.Controls.Add(lblCantidadEstimativa);

        grp.Controls.Add(chkGanchoEstribo);
        grp.Controls.Add(lblGancho);
        grp.Controls.Add(txtLongitudGanchoEstribo);
        grp.Controls.Add(lblCmGancho);

        grp.Controls.Add(lblInfo);

        this.Controls.Add(grp);
    }

    // =====================================
    // CONTROLES AUXILIARES
    // =====================================
    private WinForms.Label CrearLabel(string texto, int left, int top, int width)
    {
        return new WinForms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(45, 45, 45)
        };
    }

    private WinForms.Label CrearLabelNormal(string texto, int left, int top, int width)
    {
        return new WinForms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.2F),
            ForeColor = Drawing.Color.Gray
        };
    }

    private WinForms.TextBox CrearTextBox(int left, int top, int width, string text)
    {
        return new WinForms.TextBox()
        {
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            BackColor = Drawing.Color.White,
            Text = text
        };
    }

    // =====================================
    // ACTIVAR PANEL
    // =====================================
    public void Activar()
    {
        ActualizarCantidadEstimativa();
        RefrescarPreview();
    }

    // =====================================
    // CARGAR TIPOS DE ARMADURA
    // =====================================
    public void CargarTiposArmadura(List<RebarBarType> tipos)
    {
        cmbTipoEstribo.Items.Clear();

        if (tipos == null)
            return;

        foreach (RebarBarType tipo in tipos)
        {
            if (tipo == null)
                continue;

            cmbTipoEstribo.Items.Add(tipo);
        }

        cmbTipoEstribo.DisplayMember = "Name";

        if (cmbTipoEstribo.Items.Count > 0)
            cmbTipoEstribo.SelectedIndex = 0;
    }

    // =====================================
    // ESTADOS
    // =====================================
    private void ActualizarEstadoGancho()
    {
        bool activo = chkGanchoEstribo != null && chkGanchoEstribo.Checked;

        if (txtLongitudGanchoEstribo != null)
        {
            txtLongitudGanchoEstribo.Enabled = activo;
            txtLongitudGanchoEstribo.BackColor = activo
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }
    }

    private void RefrescarPreview()
    {
        ActualizarCantidadEstimativa();

        if (form != null && form.panelPreview != null)
            form.panelPreview.Invalidate();
    }

    // =====================================
    // VALIDAR
    // =====================================
    public bool ValidarAntesEjecutar()
    {
        if (TipoEstriboSeleccionado == null)
        {
            WinForms.MessageBox.Show(
                "Debe seleccionar el tipo de estribo.",
                "MYG",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Warning);

            return false;
        }

        if (!TextoNumeroMayorIgualCero(RecubrimientoTexto))
        {
            WinForms.MessageBox.Show(
                "Debe ingresar un recubrimiento válido.",
                "MYG",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Warning);

            return false;
        }

        if (!TextoNumeroMayorCero(SeparacionEstriboTexto))
        {
            WinForms.MessageBox.Show(
                "Debe ingresar una separación de estribos válida mayor que cero.",
                "MYG",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Warning);

            return false;
        }

        if (GanchoEstribo &&
            !TextoNumeroMayorCero(LongitudGanchoEstriboTexto))
        {
            WinForms.MessageBox.Show(
                "Debe ingresar una longitud de gancho válida mayor que cero.",
                "MYG",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Warning);

            return false;
        }

        return true;
    }

    private bool TextoNumeroMayorCero(string texto)
    {
        double valor = 0.0;

        if (!TryLeerDouble(texto, out valor))
            return false;

        return valor > 0.0;
    }

    private bool TextoNumeroMayorIgualCero(string texto)
    {
        double valor = 0.0;

        if (!TryLeerDouble(texto, out valor))
            return false;

        return valor >= 0.0;
    }

    private bool TryLeerDouble(string texto, out double valor)
    {
        valor = 0.0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string t = texto.Trim().Replace(",", ".");

        return double.TryParse(
            t,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor);
    }

    // =====================================
    // PROPIEDADES PARA EL HANDLER DE ESTRIBOS
    // =====================================
    public RebarBarType TipoEstriboSeleccionado
    {
        get { return cmbTipoEstribo.SelectedItem as RebarBarType; }
    }

    public string RecubrimientoTexto
    {
        get { return txtRecubrimiento.Text.Trim(); }
    }

    public string SeparacionEstriboTexto
    {
        get { return txtSeparacionEstribo.Text.Trim(); }
    }

    public string LongitudGanchoEstriboTexto
    {
        get { return txtLongitudGanchoEstribo.Text.Trim(); }
    }

    public bool DetectarColumnas
    {
        get { return chkDetectarColumnas != null && chkDetectarColumnas.Checked; }
    }

    public bool GanchoEstribo
    {
        get { return chkGanchoEstribo != null && chkGanchoEstribo.Checked; }
    }

    // =====================================
    // MODELO PARA HANDLER DE ESTRIBOS
    // =====================================
    public AceroLongitudinalVigasForm.ModeloEstribosPreview ObtenerModeloEstribosActual()
    {
        AceroLongitudinalVigasForm.ModeloEstribosPreview modelo =
            new AceroLongitudinalVigasForm.ModeloEstribosPreview();

        double recCm = 0.0;
        double sepCm = 0.0;
        double ganCm = 0.0;

        TryLeerDouble(RecubrimientoTexto, out recCm);
        TryLeerDouble(SeparacionEstriboTexto, out sepCm);
        TryLeerDouble(LongitudGanchoEstriboTexto, out ganCm);

        modelo.Valido = true;
        modelo.RecubrimientoMm = recCm * 10.0;
        modelo.SeparacionMm = sepCm * 10.0;
        modelo.GanchoMm = GanchoEstribo ? ganCm * 10.0 : 0.0;
        modelo.CantidadEstimativa = CalcularCantidadEstimativa();

        return modelo;
    }

    // =====================================
    // ACTUALIZAR PREVIEW
    // =====================================
    public void ActualizarVistaPreviaMultiple(List<VigaLongitudinalPreview> vigas)
    {
        previewVigas = vigas ?? new List<VigaLongitudinalPreview>();

        ActualizarCantidadEstimativa();
        RefrescarPreview();
    }

    private double ObtenerLongitudTotalPreviewMm()
    {
        double total = 0.0;

        if (previewVigas == null || previewVigas.Count == 0)
            return total;

        foreach (VigaLongitudinalPreview v in previewVigas)
        {
            if (v == null)
                continue;

            double l = v.LongitudSolidoMm > 0.0
                ? v.LongitudSolidoMm
                : v.LongitudMm;

            if (l > 0.0)
                total += l;
        }

        return total;
    }

    private int CalcularCantidadEstimativa()
    {
        double totalMm = ObtenerLongitudTotalPreviewMm();

        if (totalMm <= 0.0)
            return 0;

        double sepCm = 0.0;

        if (!TryLeerDouble(SeparacionEstriboTexto, out sepCm))
            return 0;

        double sepMm = sepCm * 10.0;

        if (sepMm <= 0.0)
            return 0;

        return Math.Max(1, (int)Math.Floor(totalMm / sepMm) + 1);
    }

    private void ActualizarCantidadEstimativa()
    {
        if (lblCantidadEstimativa == null)
            return;

        int cantidad = CalcularCantidadEstimativa();

        if (cantidad <= 0)
            lblCantidadEstimativa.Text = "Cantidad estimada: --";
        else
            lblCantidadEstimativa.Text = "Cantidad estimada: " + cantidad.ToString();
    }

    // =====================================
    // DIBUJAR VISTA PRELIMINAR
    // =====================================
    public void DibujarVistaPrevia(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        List<VigaLongitudinalPreview> vigas)
    {
        if (g == null)
            return;

        List<VigaLongitudinalPreview> lista =
            vigas != null && vigas.Count > 0
                ? vigas
                : previewVigas;

        if (lista == null || lista.Count == 0)
        {
            using (Drawing.Brush b = new Drawing.SolidBrush(Drawing.Color.Gray))
            {
                g.DrawString(
                    "Seleccione vigas para generar la vista preliminar de estribos.",
                    new Drawing.Font("Segoe UI", 8.5F),
                    b,
                    area.Left + 10,
                    area.Top + 10);
            }

            return;
        }

        double totalMm = 0.0;

        foreach (VigaLongitudinalPreview v in lista)
        {
            if (v == null)
                continue;

            double l = v.LongitudSolidoMm > 0.0
                ? v.LongitudSolidoMm
                : v.LongitudMm;

            if (l > 0.0)
                totalMm += l;
        }

        if (totalMm <= 0.0)
            return;

        Func<double, float> mapX = (xMm) =>
        {
            double t = xMm / totalMm;
            return (float)(area.Left + t * area.Width);
        };

        float yCentro = area.Top + area.Height * 0.50f;
        float altoViga = Math.Max(70f, area.Height * 0.38f);

        float ySup = yCentro - altoViga / 2f;
        float yInf = yCentro + altoViga / 2f;

        // =====================================
        // DIBUJAR VIGAS
        // =====================================
        using (Drawing.Pen penViga = new Drawing.Pen(ColorBorde, 2f))
        using (Drawing.Brush brushViga = new Drawing.SolidBrush(ColorViga))
        using (Drawing.Brush brushTexto = new Drawing.SolidBrush(Drawing.Color.FromArgb(70, 70, 70)))
        {
            double acumulado = 0.0;

            foreach (VigaLongitudinalPreview v in lista)
            {
                if (v == null)
                    continue;

                double l = v.LongitudSolidoMm > 0.0
                    ? v.LongitudSolidoMm
                    : v.LongitudMm;

                if (l <= 0.0)
                    continue;

                float x0 = mapX(acumulado);
                float x1 = mapX(acumulado + l);

                Drawing.RectangleF rect = new Drawing.RectangleF(
                    x0,
                    ySup,
                    Math.Max(1f, x1 - x0),
                    yInf - ySup);

                g.FillRectangle(brushViga, rect);
                g.DrawRectangle(
                    penViga,
                    rect.X,
                    rect.Y,
                    rect.Width,
                    rect.Height);

                string nombre = string.IsNullOrWhiteSpace(v.Nombre)
                    ? "Viga"
                    : v.Nombre;

                g.DrawString(
                    nombre,
                    new Drawing.Font("Segoe UI", 7.5F, Drawing.FontStyle.Bold),
                    brushTexto,
                    x0 + 4,
                    yInf + 6);

                acumulado += l;
            }
        }

        // =====================================
        // DIBUJAR COLUMNAS REFERENCIALES
        // =====================================
        using (Drawing.Brush brushCol = new Drawing.SolidBrush(ColorColumna))
        using (Drawing.Pen penCol = new Drawing.Pen(Drawing.Color.FromArgb(120, 120, 120), 1f))
        {
            double acumulado = 0.0;

            foreach (VigaLongitudinalPreview v in lista)
            {
                if (v == null)
                    continue;

                double l = v.LongitudSolidoMm > 0.0
                    ? v.LongitudSolidoMm
                    : v.LongitudMm;

                if (v.Columnas != null)
                {
                    foreach (AceroLongitudinalVigasForm.ColumnaPreview col in v.Columnas)
                    {
                        if (col == null)
                            continue;

                        double centro = acumulado + col.CentroMm;
                        double ancho = col.AnchoMm > 0.0 ? col.AnchoMm : 300.0;

                        float x0 = mapX(centro - ancho / 2.0);
                        float x1 = mapX(centro + ancho / 2.0);

                        Drawing.RectangleF rc = new Drawing.RectangleF(
                            x0,
                            ySup - 22f,
                            Math.Max(4f, x1 - x0),
                            (yInf - ySup) + 44f);

                        g.FillRectangle(brushCol, rc);
                        g.DrawRectangle(penCol, rc.X, rc.Y, rc.Width, rc.Height);
                    }
                }

                acumulado += l;
            }
        }

        // =====================================
        // DIBUJAR ESTRIBOS
        // =====================================
        double sepCm = 0.0;

        if (!TryLeerDouble(SeparacionEstriboTexto, out sepCm))
            sepCm = 15.0;

        double sepMm = sepCm * 10.0;

        if (sepMm <= 0.0)
            sepMm = 150.0;

        double recCm = 0.0;
        TryLeerDouble(RecubrimientoTexto, out recCm);

        float recPx = (float)Math.Max(5.0, recCm * 1.2);

        using (Drawing.Pen penEstribo = new Drawing.Pen(ColorEstribo, 2.0f))
        using (Drawing.Pen penEstriboFino = new Drawing.Pen(ColorEstribo, 1.0f))
        using (Drawing.Brush brushTexto = new Drawing.SolidBrush(ColorEstribo))
        {
            double xMm = 0.0;
            int contador = 0;

            while (xMm <= totalMm + 0.001)
            {
                float x = mapX(xMm);

                Drawing.RectangleF rcEstribo = new Drawing.RectangleF(
                    x - 4f,
                    ySup + recPx,
                    8f,
                    (yInf - ySup) - 2f * recPx);

                g.DrawRectangle(
                    penEstribo,
                    rcEstribo.X,
                    rcEstribo.Y,
                    rcEstribo.Width,
                    rcEstribo.Height);

                contador++;

                xMm += sepMm;
            }

            // Asegura estribo en el extremo final.
            float xFin = mapX(totalMm);

            Drawing.RectangleF rcFin = new Drawing.RectangleF(
                xFin - 4f,
                ySup + recPx,
                8f,
                (yInf - ySup) - 2f * recPx);

            g.DrawRectangle(
                penEstribo,
                rcFin.X,
                rcFin.Y,
                rcFin.Width,
                rcFin.Height);

            // Texto de separación.
            string textoSep = "Estribos @ " +
                sepCm.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) +
                " cm";

            g.DrawString(
                textoSep,
                new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                brushTexto,
                area.Left + 5,
                area.Top + 5);

            // Línea guía longitudinal.
            penEstriboFino.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

            g.DrawLine(
                penEstriboFino,
                mapX(0.0),
                yCentro,
                mapX(totalMm),
                yCentro);
        }

        // =====================================
        // COTA GENERAL
        // =====================================
        using (Drawing.Pen penCota = new Drawing.Pen(Drawing.Color.Gray, 1f))
        using (Drawing.Brush brush = new Drawing.SolidBrush(Drawing.Color.Gray))
        {
            penCota.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

            float yCota = area.Bottom - 18f;

            g.DrawLine(penCota, mapX(0.0), yCota, mapX(totalMm), yCota);

            string texto = "Longitud ref.: " +
                (totalMm / 1000.0).ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) +
                " m";

            g.DrawString(
                texto,
                new Drawing.Font("Segoe UI", 8F),
                brush,
                mapX(0.0),
                yCota + 2f);
        }
    }
}