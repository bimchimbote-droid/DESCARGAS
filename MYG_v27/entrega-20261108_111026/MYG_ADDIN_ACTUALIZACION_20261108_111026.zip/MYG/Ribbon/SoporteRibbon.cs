using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        // =======================================
        // VARIABLES GLOBALES PARA ACTUALIZAR ICONOS EN TIEMPO REAL
        // =======================================
        private static string _assemblyPathGlobal = null;

        private static PushButton _buttonTablasAutomaticas = null;
        private static PushButton _buttonIngresarMetrados = null;
        private static PushButton _buttonExportarTablas = null;

        private static PushButton _buttonCopiarParametros = null;
        private static PushButton _buttonCrearParametros = null;
        private static PushButton _buttonGestionProyecto = null;
        private static PushButton _buttonExportarDWGPDF = null;
        private static PushButton _buttonElementosNoTabulados = null;
        private static PushButton _buttonComprobarInterferencias = null;
        private static PushButton _buttonImportarNavisworks = null;

        private static PushButton _buttonRoomSuelo = null;
        private static PushButton _buttonRoomMuro = null;
        private static PushButton _buttonCuadroAcabados = null;
        private static PushButton _buttonMurosContorno = null;
        private static PushButton _buttonTarrajeoInterior = null;
        private static PushButton _buttonCieloRasoAcustico = null;

        private static PushButton _buttonBandejaColgador = null;
        private static PushButton _buttonCircuitoTablero = null;
        private static PushButton _buttonCablesDS = null;
        private static PushButton _buttonCADBloquesFamilias = null;
        private static PushButton _buttonTubosAuto = null;
        private static PushButton _buttonAlinearSeccionTubo = null;
        private PushButton _buttonExportarDashboard;

        //---------------------------------------------------------
        // EVENTO: CAMBIO DE TEMA CLARO / OSCURO DE REVIT
        //---------------------------------------------------------
        private void Application_ThemeChanged(
            object sender,
            Autodesk.Revit.UI.Events.ThemeChangedEventArgs e)
        {
            try
            {
                ActualizarIconosPorTema();
            }
            catch
            {
                // No mostramos mensajes para no interrumpir al usuario.
            }
        }

        //---------------------------------------------------------
        // ACTUALIZAR ICONOS APILADOS AL CAMBIAR TEMA DE REVIT
        //---------------------------------------------------------
        private static void ActualizarIconosPorTema()
        {
            // PANEL 1 - TABLAS DE PLANIFICACIÓN
            ActualizarIconoPequeno(
                _buttonTablasAutomaticas,
                "Tablas_automaticas.png");

            ActualizarIconoPequeno(
                _buttonIngresarMetrados,
                "Ingresar_metrados.png");

            ActualizarIconoPequeno(
                _buttonExportarTablas,
                "Exportar_tablas.png");

            // PANEL 2 - GESTIÓN DE INFORMACIÓN
            ActualizarIconoPequeno(
                _buttonCopiarParametros,
                "Copiar_parametros.png");

            ActualizarIconoPequeno(
                _buttonCrearParametros,
                "Crear_parametros_excel.png");

            ActualizarIconoPequeno(
                _buttonGestionProyecto,
                "Gestion_proyecto.png");

            ActualizarIconoPequeno(
                _buttonExportarDWGPDF,
                "Exportar_dwg_pdf.png");

            ActualizarIconoPequeno(
                _buttonElementosNoTabulados,
                "Elementos_no_tabulados.png");

            ActualizarIconoPequeno(
                _buttonComprobarInterferencias,
                "Interferencias_MYG.png");

            ActualizarIconoGrande(
                _buttonImportarNavisworks,
                "Interferencias_MYG.png");

            // PANEL 4 - ARQUITECTURA
            ActualizarIconoPequeno(
                _buttonRoomSuelo,
                "Room_a_suelo.png");

            ActualizarIconoPequeno(
                _buttonRoomMuro,
                "Room_a_muro.png");

            ActualizarIconoPequeno(
                _buttonCuadroAcabados,
                "Cuadro_acabados_room.png");

            ActualizarIconoPequeno(
                _buttonMurosContorno,
                "Muros_contorno_estructura.png");

            ActualizarIconoPequeno(
                _buttonTarrajeoInterior,
                "Tarrajeo_interior_confinamiento.png");

            ActualizarIconoPequeno(
                _buttonCieloRasoAcustico,
                "cielo_raso_acustico_47.png");

            // PANEL 5 - MEP
            ActualizarIconoPequeno(
                _buttonBandejaColgador,
                "hangers_bandejas.png");

            ActualizarIconoPequeno(
                _buttonCircuitoTablero,
                "ele_circuito_tablero.png");

            ActualizarIconoPequeno(
                _buttonCablesDS,
                "ele_cables_directshape.png");

            ActualizarIconoPequeno(
                _buttonCADBloquesFamilias,
                "CAD_bloques_familias.png");

            ActualizarIconoPequeno(
                _buttonTubosAuto,
                "ele_tubos_automaticos.png");
        }

        //---------------------------------------------------------
        // ACTUALIZAR UN BOTÓN GRANDE NORMAL
        //---------------------------------------------------------
        private static void ActualizarIconoGrande(
            PushButton boton,
            string nombreArchivoIcono)
        {
            if (boton == null)
                return;

            if (string.IsNullOrWhiteSpace(_assemblyPathGlobal))
                return;

            string rutaIcono = ObtenerRutaIconoSegunTema(
                _assemblyPathGlobal,
                nombreArchivoIcono);

            System.Windows.Media.Imaging.BitmapImage bmpLarge =
                CargarBitmapDesdeRuta(
                    rutaIcono,
                    32);

            System.Windows.Media.Imaging.BitmapImage bmpSmall =
                CargarBitmapDesdeRuta(
                    rutaIcono,
                    16);

            if (bmpLarge != null)
            {
                boton.LargeImage = bmpLarge;
            }

            if (bmpSmall != null)
            {
                boton.Image = bmpSmall;
            }
        }

        //---------------------------------------------------------
        // ACTUALIZAR UN BOTÓN PEQUEÑO APILADO
        //---------------------------------------------------------
        private static void ActualizarIconoPequeno(
            PushButton boton,
            string nombreArchivoIcono)
        {
            if (boton == null)
                return;

            if (string.IsNullOrWhiteSpace(_assemblyPathGlobal))
                return;

            string rutaIcono = ObtenerRutaIconoSegunTema(
                _assemblyPathGlobal,
                nombreArchivoIcono);

            System.Windows.Media.Imaging.BitmapImage bmp =
                CargarBitmapDesdeRuta(
                    rutaIcono,
                    16);

            if (bmp != null)
            {
                boton.Image = bmp;
            }
        }

        //---------------------------------------------------------
        // OBTENER RUTA DE ICONO SEGÚN TEMA DE REVIT
        //---------------------------------------------------------
        private static string ObtenerRutaIconoSegunTema(
            string assemblyPath,
            string nombreArchivoIcono)
        {
            string folderPath = System.IO.Path.GetDirectoryName(assemblyPath);

            string subcarpetaTema = "Tema_oscuro";

            try
            {
                Autodesk.Revit.UI.UITheme temaActual =
                    Autodesk.Revit.UI.UIThemeManager.CurrentTheme;

                if (temaActual == Autodesk.Revit.UI.UITheme.Light)
                {
                    subcarpetaTema = "Tema_claro";
                }
                else
                {
                    subcarpetaTema = "Tema_oscuro";
                }
            }
            catch
            {
                // Si falla la detección del tema, se usa oscuro por defecto.
                subcarpetaTema = "Tema_oscuro";
            }

            string rutaConTema = System.IO.Path.Combine(
                folderPath,
                "iconos",
                subcarpetaTema,
                nombreArchivoIcono);

            if (System.IO.File.Exists(rutaConTema))
            {
                return rutaConTema;
            }

            // Ruta de respaldo por si todavía tienes los iconos directo en la carpeta iconos.
            string rutaSinTema = System.IO.Path.Combine(
                folderPath,
                "iconos",
                nombreArchivoIcono);

            return rutaSinTema;
        }

        //---------------------------------------------------------
        // CARGAR BITMAP DESDE RUTA
        //---------------------------------------------------------
        private static System.Windows.Media.Imaging.BitmapImage CargarBitmapDesdeRuta(
            string rutaIcono,
            int decodePixelSize = 16)
        {
            if (string.IsNullOrWhiteSpace(rutaIcono))
            {
                return null;
            }

            if (!System.IO.File.Exists(rutaIcono))
            {
                return null;
            }

            System.Windows.Media.Imaging.BitmapImage bmp =
                new System.Windows.Media.Imaging.BitmapImage();

            bmp.BeginInit();

            bmp.UriSource = new System.Uri(
                rutaIcono,
                System.UriKind.Absolute);

            bmp.CacheOption =
                System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;

            // Evita que WPF conserve una versión anterior del PNG en caché.
            bmp.CreateOptions =
                System.Windows.Media.Imaging.BitmapCreateOptions.IgnoreImageCache;

            if (decodePixelSize > 0)
            {
                bmp.DecodePixelWidth = decodePixelSize;
                bmp.DecodePixelHeight = decodePixelSize;
            }

            bmp.EndInit();
            bmp.Freeze();

            return bmp;
        }
    }

}
