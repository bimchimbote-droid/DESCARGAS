using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =======================================
    // CONTROL DE BOTONES DEL RIBBON
    // =======================================
    public static class MYG_RibbonControl
    {
        private static readonly List<RibbonItem> BotonesProtegidos =
            new List<RibbonItem>();

        public static void RegistrarBotonProtegido(RibbonItem boton)
        {
            if (boton == null) return;

            BotonesProtegidos.Add(boton);
            boton.Enabled = MYG_Sesion.Logueado;
        }

        public static void HabilitarBotones(bool habilitar)
        {
            foreach (RibbonItem boton in BotonesProtegidos)
            {
                if (boton != null)
                    boton.Enabled = habilitar;
            }
        }

        public static void Limpiar()
        {
            BotonesProtegidos.Clear();
        }
    }

}
