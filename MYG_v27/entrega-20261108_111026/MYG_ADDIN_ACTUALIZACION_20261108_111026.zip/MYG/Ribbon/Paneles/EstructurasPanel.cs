using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        private void CrearPanelEstructuras(UIControlledApplication application, string tabName, string assemblyPath)
        {












            // =====================================
            // PANEL 3 ESTRUCTURAS
            // =====================================
            RibbonPanel panelEstructuras = application.CreateRibbonPanel(
                tabName,
                "ESTRUCTURAS");


            //---------------------------------------------------------
            // PANEL 3 - BOTÓN 3.1
            // MOVIMIENTO DE TIERRAS - MYG REX
            //---------------------------------------------------------

            PushButtonData buttonData31 = new PushButtonData(
                "MYG_REX",
                "Movimiento\nde tierras",
                assemblyPath,
                "MYG_Addin.MYG_REX_Command");

            PushButton button31 =
                panelEstructuras.AddItem(buttonData31) as PushButton;

            if (button31 != null)
            {
                button31.ToolTip =
                    "Herramienta MYG REX (Excavación + Relleno).";

                MYG_RibbonControl.RegistrarBotonProtegido(button31);

                string iconPath31 = ObtenerRutaIconoSegunTema(
                    assemblyPath,
                    "rex.png");

                System.Windows.Media.Imaging.BitmapImage bmp31_16 =
                    CargarBitmapDesdeRuta(iconPath31, 16);

                System.Windows.Media.Imaging.BitmapImage bmp31_32 =
                    CargarBitmapDesdeRuta(iconPath31, 32);

                if (bmp31_16 != null)
                    button31.Image = bmp31_16;

                if (bmp31_32 != null)
                    button31.LargeImage = bmp31_32;
            }


            //---------------------------------------------------------
            // PANEL 3 - BOTÓN 3.2
            // TARRAJEO Y ENCOFRADOS
            //---------------------------------------------------------

            PushButtonData buttonData32 = new PushButtonData(
                "MYG_TARRAJEO",
                "Tarrajeo y\nEncofrados",
                assemblyPath,
                "MYG_Addin.MYG_TarrajeoCommand");

            PushButton button32 =
                panelEstructuras.AddItem(buttonData32) as PushButton;

            if (button32 != null)
            {
                button32.ToolTip =
                    "Genera un suelo a partir de una cara horizontal seleccionada.\n" +
                    "Permite elegir un tipo de suelo existente del proyecto.";

                MYG_RibbonControl.RegistrarBotonProtegido(button32);

                string iconPath32 = ObtenerRutaIconoSegunTema(
                    assemblyPath,
                    "tarrajeo.png");

                System.Windows.Media.Imaging.BitmapImage bmp32_16 =
                    CargarBitmapDesdeRuta(iconPath32, 16);

                System.Windows.Media.Imaging.BitmapImage bmp32_32 =
                    CargarBitmapDesdeRuta(iconPath32, 32);

                if (bmp32_16 != null)
                    button32.Image = bmp32_16;

                if (bmp32_32 != null)
                    button32.LargeImage = bmp32_32;
            }


            //=========================================================
            // PANEL 3 - GRUPO DE ACEROS
            // MENÚ DESPLEGABLE
            //=========================================================

            PulldownButtonData menuDataAceros = new PulldownButtonData(
                "MYG_ACEROS_ESTRUCTURA",
                "Aceros");

            menuDataAceros.ToolTip =
                "Aceros estructurales\n\n" +
                "Agrupa las herramientas de automatización de acero de refuerzo " +
                "para cimentaciones, vigas, escaleras, columnas y muros.";

            string iconPathAceros = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "aceros.png");

            System.Windows.Media.Imaging.BitmapImage bmpAceros16 =
                CargarBitmapDesdeRuta(iconPathAceros, 16);

            System.Windows.Media.Imaging.BitmapImage bmpAceros32 =
                CargarBitmapDesdeRuta(iconPathAceros, 32);

            if (bmpAceros16 == null || bmpAceros32 == null)
            {
                string iconPathAcerosRespaldo = ObtenerRutaIconoSegunTema(
                    assemblyPath,
                    "acero_cimentacion.png");

                if (bmpAceros16 == null)
                    bmpAceros16 = CargarBitmapDesdeRuta(
                        iconPathAcerosRespaldo,
                        16);

                if (bmpAceros32 == null)
                    bmpAceros32 = CargarBitmapDesdeRuta(
                        iconPathAcerosRespaldo,
                        32);
            }

            if (bmpAceros16 != null)
                menuDataAceros.Image = bmpAceros16;

            if (bmpAceros32 != null)
                menuDataAceros.LargeImage = bmpAceros32;

            PulldownButton menuAceros =
                panelEstructuras.AddItem(menuDataAceros)
                as PulldownButton;

            if (menuAceros != null)
            {
                System.Func<PushButtonData, string, PushButton>
                    agregarOpcionAcero =
                    (datos, nombreIcono) =>
                    {
                        string ruta = ObtenerRutaIconoSegunTema(
                            assemblyPath,
                            nombreIcono);

                        System.Windows.Media.Imaging.BitmapImage icono16 =
                            CargarBitmapDesdeRuta(
                                ruta,
                                16);

                        System.Windows.Media.Imaging.BitmapImage icono32 =
                            CargarBitmapDesdeRuta(
                                ruta,
                                32);

                        if (icono16 == null)
                            icono16 = bmpAceros16;

                        if (icono32 == null)
                            icono32 = bmpAceros32;

                        if (icono16 != null)
                            datos.Image = icono16;

                        if (icono32 != null)
                            datos.LargeImage = icono32;

                        PushButton botonInterno =
                            menuAceros.AddPushButton(datos);

                        if (botonInterno != null)
                        {
                            MYG_RibbonControl
                                .RegistrarBotonProtegido(
                                    botonInterno);
                        }

                        return botonInterno;
                    };


                //=====================================================
                // ACERO EN CIMENTACIÓN
                //=====================================================

                PushButtonData dataAceroCimentacion =
                    new PushButtonData(
                        "MYG_ACERO_CIMENTACION",
                        "Acero en Cimentación",
                        assemblyPath,
                        "MYG_Addin.AceroCimentacionCommand");

                dataAceroCimentacion.ToolTip =
                    "Crea acero en cimentaciones estructurales.\n" +
                    "Permite seleccionar tipo de armadura, espaciamiento y recubrimiento.\n" +
                    "Genera una malla inferior con barras en ambas direcciones.";

                agregarOpcionAcero(
                    dataAceroCimentacion,
                    "acero_cimentacion.png");


                //=====================================================
                // ACERO EN VIGAS
                //=====================================================

                PushButtonData dataAceroVigas =
                    new PushButtonData(
                        "MYG_ACERO_EN_VIGAS",
                        "Acero en Vigas",
                        assemblyPath,
                        "MYG_Addin.MYG_AceroVigasCommand");

                dataAceroVigas.ToolTip =
                    "Genera acero de refuerzo en vigas estructurales.\n" +
                    "Incluye acero longitudinal y estribos.";

                agregarOpcionAcero(
                    dataAceroVigas,
                    "acero_longitudinal_vigas_32.png");


                //=====================================================
                // ACERO EN LOSAS
                //=====================================================

                PushButtonData dataAceroLosas =
                    new PushButtonData(
                        "MYG_ACERO_EN_LOSAS",
                        "Acero en Losas",
                        assemblyPath,
                        "MYG_Addin.MYG_AceroLosasCommand");

                dataAceroLosas.ToolTip =
                    "Genera acero de refuerzo en losas macizas.\n\n" +
                    "Permite seleccionar múltiples losas y configurar:\n" +
                    "• Acero inferior D1 / D2.\n" +
                    "• Acero superior D1 / D2.\n" +
                    "• Tipo y diámetro de barra.\n" +
                    "• Espaciamiento.\n" +
                    "• Recubrimientos.\n" +
                    "• Adaptación automática a huecos.\n\n" +
                    "La dirección principal se detecta automáticamente " +
                    "según la geometría de cada losa.";

                agregarOpcionAcero(
                    dataAceroLosas,
                    "acero_losas.png");


                menuAceros.AddSeparator();


                //=====================================================
                // ACERO EN ESCALERAS
                //=====================================================

                PushButtonData dataAceroEscalera =
                    new PushButtonData(
                        "MYG_ACERO_ESCALERA",
                        "Acero en Escaleras",
                        assemblyPath,
                        "MYG_Addin.AceroEscaleraCommand");

                dataAceroEscalera.ToolTip =
                    "Crea acero de refuerzo en tramos de escalera.\n" +
                    "Genera acero principal inferior siguiendo la pendiente " +
                    "y acero transversal de repartición.";

                agregarOpcionAcero(
                    dataAceroEscalera,
                    "acero_escalera.png");


                //=====================================================
                // ACERO EN COLUMNAS
                //=====================================================

                PushButtonData dataAceroColumnas =
                    new PushButtonData(
                        "MYG_ACERO_COLUMNA",
                        "Acero en Columnas",
                        assemblyPath,
                        "MYG_Addin.AceroColumnaCommand");

                dataAceroColumnas.ToolTip =
                    "Crea acero longitudinal y estribos en columnas estructurales.\n" +
                    "Permite seleccionar columnas desde la ventana y trabaja " +
                    "con secciones rectangulares, L, T y perfiles ortogonales.";

                agregarOpcionAcero(
                    dataAceroColumnas,
                    "acero_columna.png");


                //=====================================================
                // ACERO EN MUROS
                //=====================================================

                PushButtonData dataAceroMuros =
                    new PushButtonData(
                        "MYG_ACERO_MURO",
                        "Acero en Muros",
                        assemblyPath,
                        "MYG_Addin.AceroMuroCommand");

                dataAceroMuros.ToolTip =
                    "Crea acero vertical y horizontal en muros estructurales.\n" +
                    "Muestra una vista previa lateral de los muros seleccionados.\n" +
                    "Cuando los muros forman una cadena en serie, los aceros " +
                    "horizontales se generan continuos a través de la cadena.";

                agregarOpcionAcero(
                    dataAceroMuros,
                    "acero_muros.png");
            }


            //---------------------------------------------------------
            // PANEL 3 - FAMILIAS COLUMNAS CAD
            //---------------------------------------------------------

            PushButtonData buttonData35 = new PushButtonData(
                "MYG_CREAR_FAMILIAS_COLUMNAS_CAD",
                "Familias\nColumnas CAD",
                assemblyPath,
                "MYG_Addin.CrearFamiliasColumnasCadCommand");

            PushButton button35 =
                panelEstructuras.AddItem(buttonData35) as PushButton;

            if (button35 != null)
            {
                button35.ToolTip =
                    "Crea familias de columnas estructurales desde secciones en bloques CAD.\n" +
                    "Permite seleccionar un DWG, una plantilla de familia y generar las familias en Revit.";

                MYG_RibbonControl.RegistrarBotonProtegido(button35);

                string iconPath35 = ObtenerRutaIconoSegunTema(
                    assemblyPath,
                    "familias_columnas_cad_32.png");

                System.Windows.Media.Imaging.BitmapImage bmp35_16 =
                    CargarBitmapDesdeRuta(
                        iconPath35,
                        16);

                System.Windows.Media.Imaging.BitmapImage bmp35_32 =
                    CargarBitmapDesdeRuta(
                        iconPath35,
                        32);

                if (bmp35_16 == null)
                {
                    string iconPath35Small =
                        ObtenerRutaIconoSegunTema(
                            assemblyPath,
                            "familias_columnas_cad_16.png");

                    bmp35_16 =
                        CargarBitmapDesdeRuta(
                            iconPath35Small,
                            16);
                }

                if (bmp35_16 != null)
                    button35.Image = bmp35_16;

                if (bmp35_32 != null)
                    button35.LargeImage = bmp35_32;
            }
        }
    }

}
