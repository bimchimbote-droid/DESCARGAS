using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        private void CrearPanelAcceso(UIControlledApplication application, string tabName, string assemblyPath)
        {

            // =====================================
            // PANEL 0 - LOGIN
            // =====================================
            RibbonPanel panelAcceso = application.CreateRibbonPanel(
                tabName,
                "ACCESO");

            PushButtonData buttonDataLogin = new PushButtonData(
                "MYG_LOGIN",
                "Login\nMYG",
                assemblyPath,
                "MYG_Addin.MYG_LoginCommand");

            PushButton buttonLogin = panelAcceso.AddItem(buttonDataLogin) as PushButton;

            buttonLogin.ToolTip =
                "Iniciar sesión para habilitar las herramientas MYG.";

            string folderPathLogin = Path.GetDirectoryName(assemblyPath);
            string iconPathLogin = Path.Combine(folderPathLogin, "iconos", "login.png");

            if (File.Exists(iconPathLogin))
            {
                var bmpLogin = new System.Windows.Media.Imaging.BitmapImage();

                bmpLogin.BeginInit();
                bmpLogin.UriSource = new Uri(iconPathLogin, UriKind.Absolute);
                bmpLogin.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                bmpLogin.EndInit();

                buttonLogin.LargeImage = bmpLogin;
                buttonLogin.Image = bmpLogin;
            }
        }
    }

}
