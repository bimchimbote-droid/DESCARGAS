using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        private void CrearPanelArquitectura(UIControlledApplication application, string tabName, string assemblyPath)
        {


            //---------------------------------------------------------
            // PANEL 4 (ARQUITECTURA)
            //---------------------------------------------------------
            RibbonPanel panelArquitectura = application.CreateRibbonPanel(
                tabName,
                "ARQUITECTURA");

            //---------------------------------------------------------
            // GRUPO ARQ 4.1 / 4.2 / 4.3
            // ROOM A SUELO / ROOM A MURO / CUADRO ACABADOS
            //---------------------------------------------------------

            PushButtonData buttonData41 = new PushButtonData(
                "CREARSUELODESDEROOM_ARQ",
                "Room a Suelo",
                assemblyPath,
                "MYG_Addin.CrearSueloDesdeRoomCommand");

            buttonData41.ToolTip =
                "Room a Suelo\n\n" +
                "Crea un suelo usando el boundary de una habitación seleccionada como boceto.\n" +
                "Permite seleccionar una o dos capas de suelo, el nivel de referencia y el desfase.";

            string iconPath41 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Room_a_suelo.png");

            System.Windows.Media.Imaging.BitmapImage bmp41 =
                CargarBitmapDesdeRuta(
                    iconPath41,
                    16);

            if (bmp41 != null)
            {
                buttonData41.Image = bmp41;
            }

            PushButtonData buttonData42 = new PushButtonData(
                "CREARMURODESDEROOM_ARQ",
                "Room a Muro",
                assemblyPath,
                "MYG_Addin.CrearMuroDesdeRoomCommand");

            buttonData42.ToolTip =
                "Room a Muro\n\n" +
                "Crea muros usando el boundary de una o más habitaciones seleccionadas.\n" +
                "Permite seleccionar el tipo de muro, altura, nivel de referencia y tomar la cota base desde una superficie.";

            string iconPath42 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Room_a_muro.png");

            System.Windows.Media.Imaging.BitmapImage bmp42 =
                CargarBitmapDesdeRuta(
                    iconPath42,
                    16);

            if (bmp42 != null)
            {
                buttonData42.Image = bmp42;
            }

            PushButtonData buttonData43 = new PushButtonData(
                "CUADROACABADOSROOM_ARQ",
                "Cuadro Acab.",
                assemblyPath,
                "MYG_Addin.CuadroAcabadosRoomCommand");

            buttonData43.ToolTip =
                "Cuadro de Acabados\n\n" +
                "Selecciona habitaciones / Rooms y detecta los muros y suelos relacionados.\n" +
                "Exporta un cuadro de acabados en Excel.";

            string iconPath43 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Cuadro_acabados_room.png");

            System.Windows.Media.Imaging.BitmapImage bmp43 =
                CargarBitmapDesdeRuta(
                    iconPath43,
                    16);

            if (bmp43 != null)
            {
                buttonData43.Image = bmp43;
            }

            System.Collections.Generic.IList<RibbonItem> botonesArqRooms =
                panelArquitectura.AddStackedItems(
                    buttonData41,
                    buttonData42,
                    buttonData43);

            PushButton button41 = botonesArqRooms[0] as PushButton;
            PushButton button42 = botonesArqRooms[1] as PushButton;
            PushButton button43 = botonesArqRooms[2] as PushButton;

            _buttonRoomSuelo = button41;
            _buttonRoomMuro = button42;
            _buttonCuadroAcabados = button43;

            if (button41 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button41);
            }


            if (button42 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button42);
            }

            if (button43 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button43);
            }

            //---------------------------------------------------------
            // GRUPO ARQ 4.5 / 4.6 / 4.7
            // MUROS CONTORNO / TARRAJEO INTERIOR / CIELO RASO
            //---------------------------------------------------------

            PushButtonData buttonData45 = new PushButtonData(
                "MUROSCONTORNOESTRUCTURA_ARQ",
                "Muros Contorno",
                assemblyPath,
                "MYG_Addin.CrearMurosContornoEstructuraCommand");

            buttonData45.ToolTip =
                "Muros Contorno\n\n" +
                "Selecciona columnetas y vigas de confinamiento desde un vínculo estructural.\n" +
                "Crea muros en el contorno de elementos de categoría Pilar estructural y Armazón estructural.";

            string iconPath45 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Muros_contorno_estructura.png");

            System.Windows.Media.Imaging.BitmapImage bmp45 =
                CargarBitmapDesdeRuta(
                    iconPath45,
                    16);

            if (bmp45 != null)
            {
                buttonData45.Image = bmp45;
            }

            PushButtonData buttonData46 = new PushButtonData(
                "TARRAJEOINTERIORCONFINAMIENTO_ARQ",
                "Tarrajeo Int.",
                assemblyPath,
                typeof(CrearTarrajeoInteriorConfinamientoCommand).FullName);

            buttonData46.ToolTip =
                "Tarrajeo Interior\n\n" +
                "Selecciona muros, columnetas y vigas de confinamiento nativas o vinculadas.\n" +
                "Crea tarrajeo interior como muro delgado pegado a las caras interiores.";

            string iconPath46 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Tarrajeo_interior_confinamiento.png");

            System.Windows.Media.Imaging.BitmapImage bmp46 =
                CargarBitmapDesdeRuta(
                    iconPath46,
                    16);

            if (bmp46 != null)
            {
                buttonData46.Image = bmp46;
            }

            Autodesk.Revit.UI.PushButtonData buttonData47 = new Autodesk.Revit.UI.PushButtonData(
                "MYG_CIELO_RASO_ACUSTICO_47",
                "Cielo Raso",
                assemblyPath,
                "MYG_Addin.MYG_CieloRasoAcusticoCommand");

            buttonData47.ToolTip =
                "Cielo Raso Acústico\n\n" +
                "Genera un sistema suspendido para cielo raso acústico desde una superficie.\n" +
                "Crea marco, perfiles principales, perfiles secundarios y colgadores.";

            string iconPath47 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "cielo_raso_acustico_47.png");

            System.Windows.Media.Imaging.BitmapImage bmp47 =
                CargarBitmapDesdeRuta(
                    iconPath47,
                    16);

            if (bmp47 != null)
            {
                buttonData47.Image = bmp47;
            }

            System.Collections.Generic.IList<RibbonItem> botonesArqAcabados =
                panelArquitectura.AddStackedItems(
                    buttonData45,
                    buttonData46,
                    buttonData47);

            PushButton button45 = botonesArqAcabados[0] as PushButton;
            PushButton button46 = botonesArqAcabados[1] as PushButton;
            PushButton button47 = botonesArqAcabados[2] as PushButton;

            _buttonMurosContorno = button45;
            _buttonTarrajeoInterior = button46;
            _buttonCieloRasoAcustico = button47;

            if (button45 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button45);
            }

            if (button46 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button46);
            }

            if (button47 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button47);
            }
        }
    }

}
