using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        private void CrearPanelGestion(UIControlledApplication application, string tabName, string assemblyPath)
        {





            // =====================================
            // PANEL 2 COMPLETO - GESTIÓN DE INFORMACIÓN
            // INCLUYE BOTÓN 2.9: ASIGNAR HABITACIÓN A PARÁMETRO
            // SIN USING NI NAMESPACE
            //
            // REEMPLAZA COMPLETAMENTE TU BLOQUE ACTUAL DEL PANEL 2
            // POR ESTE CÓDIGO.
            // =====================================

            //---------------------------------------------------------
            // PANEL 2 (GESTIÓN DE INFORMACIÓN)
            //---------------------------------------------------------
            RibbonPanel panelGestion = application.CreateRibbonPanel(
                tabName,
                "GESTIÓN DE INFORMACIÓN");

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.1 (COPIAR PARÁMETROS)
            // BOTÓN APILADO
            //---------------------------------------------------------
            PushButtonData buttonData21 = new PushButtonData(
                "COPIARPARAMETROS",
                "Copiar Parámetros",
                assemblyPath,
                "MYG_Addin.CopiarParametrosCommand");

            buttonData21.ToolTip =
                "Copia el valor de un parámetro origen a uno o más parámetros destino.\n" +
                "Luego podrá seleccionar los elementos.";

            string iconPath21 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Copiar_parametros.png");

            System.Windows.Media.Imaging.BitmapImage bmp21 =
                CargarBitmapDesdeRuta(
                    iconPath21,
                    16);

            if (bmp21 != null)
            {
                buttonData21.Image = bmp21;
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.3 (CREAR PARÁMETROS DESDE EXCEL)
            // BOTÓN APILADO
            //---------------------------------------------------------
            PushButtonData buttonData23 = new PushButtonData(
                "CREARPARAMETROSEXCEL",
                "Crear Parámetros",
                assemblyPath,
                "MYG_Addin.CrearParametrosExcelCommand");

            buttonData23.ToolTip =
                "Crea parámetros compartidos desde un Excel y los registra como parámetros de proyecto.\n" +
                "Permite asignarlos por categoría, tipo de dato, grupo de Revit e instancia/tipo.";

            string iconPath23 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Crear_parametros_excel.png");

            System.Windows.Media.Imaging.BitmapImage bmp23 =
                CargarBitmapDesdeRuta(
                    iconPath23,
                    16);

            if (bmp23 != null)
            {
                buttonData23.Image = bmp23;
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.6 (GESTIONAR ELEMENTOS DEL PROYECTO)
            // BOTÓN APILADO
            //---------------------------------------------------------
            PushButtonData buttonData26 = new PushButtonData(
                "GESTIONELEMENTOSPROYECTO26",
                "Gestión Proyecto",
                assemblyPath,
                "MYG_Addin.GestionElementosProyectoCommand");

            buttonData26.ToolTip =
                "Permite gestionar elementos del proyecto:\n" +
                "1. Parámetros de proyecto.\n" +
                "2. Plantillas de vistas.\n" +
                "3. Filtros.\n\n" +
                "Muestra listas con checks para seleccionar todo, deseleccionar todo y eliminar lo seleccionado.";

            string iconPath26 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Gestion_proyecto.png");

            System.Windows.Media.Imaging.BitmapImage bmp26 =
                CargarBitmapDesdeRuta(
                    iconPath26,
                    16);

            if (bmp26 != null)
            {
                buttonData26.Image = bmp26;
            }

            //---------------------------------------------------------
            // CREAR PRIMERA COLUMNA DE 3 BOTONES APILADOS
            // 2.1 / 2.3 / 2.6
            //---------------------------------------------------------
            System.Collections.Generic.IList<RibbonItem> botonesGestionApilados =
                panelGestion.AddStackedItems(
                    buttonData21,
                    buttonData23,
                    buttonData26);

            //---------------------------------------------------------
            // RECUPERAR BOTONES APILADOS
            //---------------------------------------------------------
            PushButton button21 =
                botonesGestionApilados[0] as PushButton;

            PushButton button23 =
                botonesGestionApilados[1] as PushButton;

            PushButton button26 =
                botonesGestionApilados[2] as PushButton;

            //---------------------------------------------------------
            // GUARDAR REFERENCIAS PARA CAMBIO DE TEMA EN TIEMPO REAL
            //---------------------------------------------------------
            _buttonCopiarParametros = button21;
            _buttonCrearParametros = button23;
            _buttonGestionProyecto = button26;

            //---------------------------------------------------------
            // REGISTRAR BOTONES PROTEGIDOS APILADOS
            //---------------------------------------------------------
            if (button21 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button21);
            }

            if (button23 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button23);
            }

            if (button26 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button26);
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTONES 2.2 / 2.4 / 2.5
            // SEGUNDA COLUMNA DE BOTONES APILADOS CON TEXTO CORTO
            //
            // 2.2 = DWG/PDF
            // 2.4 = No Tab.
            // 2.5 = Interf.
            //---------------------------------------------------------

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.2 (EXPORTAR DWG / PDF)
            //---------------------------------------------------------
            PushButtonData buttonData22 = new PushButtonData(
                "EXPORTARDWGPDF",
                "DWG/PDF",
                assemblyPath,
                "MYG_Addin.ExportDWGCommand");

            buttonData22.ToolTip =
                "Exportar DWG / PDF\n\n" +
                "Exporta automáticamente los planos de un View Set.\n" +
                "Permite seleccionar la carpeta de destino,\n" +
                "la configuración DWG y exportar DWG/PDF.";

            string iconPath22 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Exportar_dwg_pdf.png");

            System.Windows.Media.Imaging.BitmapImage bmp22 =
                CargarBitmapDesdeRuta(
                    iconPath22,
                    16);

            if (bmp22 != null)
            {
                buttonData22.Image = bmp22;
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.4 (ELEMENTOS NO TABULADOS)
            //---------------------------------------------------------
            PushButtonData buttonData24 = new PushButtonData(
                "ELEMENTOSNOTABULADOS",
                "No Tab.",
                assemblyPath,
                "MYG_Addin.ElementosNoTabuladosCommand");

            buttonData24.ToolTip =
                "Elementos No Tabulados\n\n" +
                "Evalúa los elementos del modelo y lista aquellos que no aparecen en ninguna tabla de planificación.\n" +
                "Luego permite seleccionarlos directamente en Revit.";

            string iconPath24 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Elementos_no_tabulados.png");

            System.Windows.Media.Imaging.BitmapImage bmp24 =
                CargarBitmapDesdeRuta(
                    iconPath24,
                    16);

            if (bmp24 != null)
            {
                buttonData24.Image = bmp24;
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.5 (COMPROBACIÓN DE INTERFERENCIAS)
            //---------------------------------------------------------
            PushButtonData buttonData25 = new PushButtonData(
                "MYG_INTERFERENCIAS",
                "Interf.",
                assemblyPath,
                "MYG_Addin.MYG_InterferenciasCommand");

            buttonData25.ToolTip =
                "Comprobar Interferencias\n\n" +
                "Detecta interferencias entre dos categorías del modelo.\n" +
                "Desde la lista de interferencias permite aislar los 2 elementos involucrados para revisarlos y tomar medidas manualmente.";

            string iconPath25 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Interferencias_MYG.png");

            System.Windows.Media.Imaging.BitmapImage bmp25 =
                CargarBitmapDesdeRuta(
                    iconPath25,
                    16);

            if (bmp25 != null)
            {
                buttonData25.Image = bmp25;
            }

            //---------------------------------------------------------
            // CREAR SEGUNDA COLUMNA DE 3 BOTONES APILADOS
            // 2.2 / 2.4 / 2.5
            //---------------------------------------------------------
            System.Collections.Generic.IList<RibbonItem> botonesGestionCompactos =
                panelGestion.AddStackedItems(
                    buttonData22,
                    buttonData24,
                    buttonData25);

            //---------------------------------------------------------
            // RECUPERAR BOTONES APILADOS
            //---------------------------------------------------------
            PushButton button22 =
                botonesGestionCompactos[0] as PushButton;

            PushButton button24 =
                botonesGestionCompactos[1] as PushButton;

            PushButton button25 =
                botonesGestionCompactos[2] as PushButton;

            //---------------------------------------------------------
            // GUARDAR REFERENCIAS PARA CAMBIO DE TEMA EN TIEMPO REAL
            //---------------------------------------------------------
            _buttonExportarDWGPDF = button22;
            _buttonElementosNoTabulados = button24;
            _buttonComprobarInterferencias = button25;

            //---------------------------------------------------------
            // REGISTRAR BOTONES PROTEGIDOS
            //---------------------------------------------------------
            if (button22 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button22);
            }

            if (button24 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button24);
            }

            if (button25 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button25);
            }

            //---------------------------------------------------------
            // PANEL 2 - MYG NAVIS: IMPORTAR JSON DE CLASH DETECTIVE
            // No sustituye el boton existente de comprobacion.
            //---------------------------------------------------------
            PushButtonData buttonDataNavisJson = new PushButtonData(
                "MYG_NAVISWORKS_JSON_IMPORT",
                "Navis\nJSON",
                assemblyPath,
                typeof(MYG_NavisworksImportCommand).FullName);

            buttonDataNavisJson.ToolTip =
                "MYG NAVIS - Importar interferencias desde JSON\n\n" +
                "Carga los JSON MYG_BIM_CLASH exportados por MYG NAVIS, " +
                "localiza elementos nativos y elementos en vinculos Revit, " +
                "y permite seleccionar y aislar el conflicto con doble clic.";

            PushButton buttonNavisJson =
                panelGestion.AddItem(buttonDataNavisJson) as PushButton;

            _buttonImportarNavisworks = buttonNavisJson;
            if (buttonNavisJson != null)
            {
                string rutaIconoNavis = ObtenerRutaIconoSegunTema(
                    assemblyPath, "Interferencias_MYG.png");

                System.Windows.Media.Imaging.BitmapImage bmpNavisGrande =
                    CargarBitmapDesdeRuta(rutaIconoNavis, 32);
                System.Windows.Media.Imaging.BitmapImage bmpNavisPequeno =
                    CargarBitmapDesdeRuta(rutaIconoNavis, 16);

                if (bmpNavisGrande != null)
                    buttonNavisJson.LargeImage = bmpNavisGrande;
                if (bmpNavisPequeno != null)
                    buttonNavisJson.Image = bmpNavisPequeno;

                MYG_RibbonControl.RegistrarBotonProtegido(buttonNavisJson);
            }

            //---------------------------------------------------------
            // SEPARADOR PANEL 2
            //---------------------------------------------------------
            panelGestion.AddSeparator();

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.7 (EXPORTAR DASHBOARD BIM LOCAL)
            // PRIMER BOTÓN DE LA TERCERA COLUMNA APILADA
            //---------------------------------------------------------
            PushButtonData buttonData27 = new PushButtonData(
                "EXPORTARDASHBOARDLOCAL27",
                "Exportar Dashboard",
                assemblyPath,
                "MYG_Addin.ExportarDashboardCommand");

            buttonData27.ToolTip =
                "Exportar Dashboard BIM Local\n\n" +
                "Exporta información del modelo y genera un visor/dashboard local en HTML.\n" +
                "Incluye data CSV, visor 3D OBJ, relaciones por ElementId, tarjetas resumen,\n" +
                "botones por categoría, tabla de elementos y panel de propiedades.\n\n" +
                "No depende de Autodesk Data Exchange ni de ACC.";

            string iconPath27 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Exportar_dashboard.png");

            System.Windows.Media.Imaging.BitmapImage bmp27 =
                CargarBitmapDesdeRuta(
                    iconPath27,
                    16);

            if (bmp27 != null)
            {
                buttonData27.Image = bmp27;
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.8
            // FILTRO DE VISTA POR PARÁMETROS
            // SEGUNDO BOTÓN DE LA TERCERA COLUMNA APILADA
            //---------------------------------------------------------
            PushButtonData buttonData28 = new PushButtonData(
                "FILTROVISTAPARAMETROS28",
                "Filtro de Vista\npor Parámetros",
                assemblyPath,
                "MYG_Addin.ColorearParametroCommand");

            buttonData28.ToolTip =
                "Filtro de Vista por Parámetros\n\n" +
                "Analiza los elementos visibles de la vista 3D activa.\n" +
                "Lista los parámetros disponibles de instancia y de tipo.\n" +
                "Agrupa los elementos según los valores únicos del parámetro seleccionado.\n" +
                "Aplica colores mediante Propiedades de vista temporales.\n" +
                "Genera una leyenda interactiva con color, valor, cantidad y porcentaje.\n\n" +
                "Permite seleccionar valores, aislar los valores marcados,\n" +
                "mostrar nuevamente todos los elementos y restaurar la vista\n" +
                "sin dejar filtros ni colores permanentes.";

            string iconPath28 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Filtro_vista_parametros.png");

            System.Windows.Media.Imaging.BitmapImage bmp28 =
                CargarBitmapDesdeRuta(
                    iconPath28,
                    16);

            if (bmp28 != null)
            {
                buttonData28.Image = bmp28;
            }

            //---------------------------------------------------------
            // PANEL 2 - BOTÓN 2.9
            // ASIGNAR NOMBRE DE HABITACIÓN A PARÁMETRO
            // TERCER BOTÓN DE LA TERCERA COLUMNA APILADA
            //---------------------------------------------------------
            PushButtonData buttonData29 = new PushButtonData(
                "ASIGNARHABITACIONPARAMETRO29",
                "Hab. a\nParámetro",
                assemblyPath,
                "MYG_Addin.AsignarHabitacionParametroCommand");

            buttonData29.ToolTip =
                "Asignar Habitación a Parámetro\n\n" +
                "Permite escoger una categoría y, opcionalmente, filtrar por tipo.\n" +
                "Luego selecciona elementos en Revit obedeciendo esos filtros,\n" +
                "detecta automáticamente la habitación correspondiente a cada elemento\n" +
                "y permite escribir el nombre de la habitación en un parámetro de instancia.\n\n" +
                "El selector de parámetros muestra los parámetros de instancia presentes\n" +
                "en los elementos seleccionados.";

            // Se reutiliza un icono que ya existe en tu add-in para no crear
            // una dependencia adicional. Si luego creas un icono propio,
            // cambia únicamente el nombre del archivo de la línea siguiente.
            string iconPath29 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Copiar_parametros.png");

            System.Windows.Media.Imaging.BitmapImage bmp29 =
                CargarBitmapDesdeRuta(
                    iconPath29,
                    16);

            if (bmp29 != null)
            {
                buttonData29.Image = bmp29;
            }

            //---------------------------------------------------------
            // CREAR TERCERA COLUMNA DE 3 BOTONES APILADOS
            //
            // ARRIBA: 2.7 - EXPORTAR DASHBOARD
            // MEDIO : 2.8 - FILTRO DE VISTA POR PARÁMETROS
            // ABAJO : 2.9 - HABITACIÓN A PARÁMETRO
            //---------------------------------------------------------
            System.Collections.Generic.IList<RibbonItem>
                botonesGestionDashboardFiltros =
                    panelGestion.AddStackedItems(
                        buttonData27,
                        buttonData28,
                        buttonData29);

            //---------------------------------------------------------
            // RECUPERAR BOTONES APILADOS
            //---------------------------------------------------------
            PushButton button27 =
                botonesGestionDashboardFiltros[0] as PushButton;

            PushButton button28 =
                botonesGestionDashboardFiltros[1] as PushButton;

            PushButton button29 =
                botonesGestionDashboardFiltros[2] as PushButton;

            //---------------------------------------------------------
            // GUARDAR REFERENCIA EXISTENTE PARA CAMBIO DE TEMA
            //---------------------------------------------------------
            _buttonExportarDashboard = button27;

            // Los botones 2.8 y 2.9 no se guardan en variables de clase.
            // Así no necesitas declarar referencias adicionales para ellos.

            //---------------------------------------------------------
            // REGISTRAR BOTONES PROTEGIDOS
            //---------------------------------------------------------
            if (button27 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button27);
            }

            if (button28 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button28);
            }

            if (button29 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button29);
            }
        }
    }

}
