using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        private void CrearPanelTablas(UIControlledApplication application, string tabName, string assemblyPath)
        {

            //---------------------------------------------------------
            // PANEL 1 (TABLAS DE PLANIFICACIÓN)
            //---------------------------------------------------------
            RibbonPanel panel = application.CreateRibbonPanel(
                tabName,
                "TABLAS DE PLANIFICACIÓN");

            //---------------------------------------------------------
            // PANEL 1 - BOTON 1.1 (TABLAS AUTOMATICAS)
            //---------------------------------------------------------
            PushButtonData buttonData11 = new PushButtonData(
                "TABLASAUTOMATICAS",
                "Tablas automáticas",
                assemblyPath,
                "MYG_Addin.DuplicateSchedulesCommand");

            buttonData11.ToolTip = "Traer partidas de una plantilla de excel";

            string iconPath11 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Tablas_automaticas.png");

            System.Windows.Media.Imaging.BitmapImage bmp11 =
                CargarBitmapDesdeRuta(iconPath11);

            if (bmp11 != null)
            {
                buttonData11.Image = bmp11;
            }

            //---------------------------------------------------------
            // PANEL 1 - BOTON 1.2 (INGRESAR METRADOS)
            //---------------------------------------------------------
            PushButtonData buttonData12 = new PushButtonData(
                "INGRESARMETRADOS",
                "Ingresar Metrados",
                assemblyPath,
                "MYG_Addin.IngresarMetradosCommand");

            buttonData12.ToolTip = "Regresar los metrados a una plantilla de excel";

            string iconPath12 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Ingresar_metrados.png");

            System.Windows.Media.Imaging.BitmapImage bmp12 =
                CargarBitmapDesdeRuta(iconPath12);

            if (bmp12 != null)
            {
                buttonData12.Image = bmp12;
            }

            //---------------------------------------------------------
            // PANEL 1 - BOTON 1.3 (EXPORTAR TABLAS)
            //---------------------------------------------------------
            PushButtonData buttonData13 = new PushButtonData(
                "EXPORTARTABLAS",
                "Exportar Tablas",
                assemblyPath,
                "MYG_Addin.ExportarTablasCommand");

            buttonData13.ToolTip = "Exportar tablas a Excel";

            string iconPath13 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "Exportar_tablas.png");

            System.Windows.Media.Imaging.BitmapImage bmp13 =
                CargarBitmapDesdeRuta(iconPath13);

            if (bmp13 != null)
            {
                buttonData13.Image = bmp13;
            }

            //---------------------------------------------------------
            // CREAR LOS 3 BOTONES COMO LISTA VERTICAL
            //---------------------------------------------------------
            System.Collections.Generic.IList<RibbonItem> botonesTablas =
                panel.AddStackedItems(
                    buttonData11,
                    buttonData12,
                    buttonData13);

            //---------------------------------------------------------
            // RECUPERAR BOTONES CREADOS
            //---------------------------------------------------------
            PushButton button11 = botonesTablas[0] as PushButton;
            PushButton button12 = botonesTablas[1] as PushButton;
            PushButton button13 = botonesTablas[2] as PushButton;

            // Guardar referencia de los botones para actualizar sus iconos en tiempo real.
            _buttonTablasAutomaticas = button11;
            _buttonIngresarMetrados = button12;
            _buttonExportarTablas = button13;

            //---------------------------------------------------------
            // REGISTRAR BOTONES PROTEGIDOS
            //---------------------------------------------------------
            if (button11 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button11);
            }

            if (button12 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button12);
            }

            if (button13 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button13);
            }
        }
    }

}
