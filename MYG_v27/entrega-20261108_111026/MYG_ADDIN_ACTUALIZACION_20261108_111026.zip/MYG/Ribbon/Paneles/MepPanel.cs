using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    public partial class App
    {
        private void CrearPanelMep(UIControlledApplication application, string tabName, string assemblyPath)
        {




            // =====================================
            // PANEL 5 MEP
            // =====================================
            RibbonPanel panelMEP = application.CreateRibbonPanel(
                tabName,
                "MEP");

            //---------------------------------------------------------
            // GRUPO MEP 5.1 / 5.2 / 5.3
            // BANDEJA A COLGADOR / CIRCUITO TABLERO / CABLES DS
            //---------------------------------------------------------

            PushButtonData buttonData51 = new PushButtonData(
                "MYG_HANGERS_BANDEJAS_51",
                "Bandeja Colg.",
                assemblyPath,
                "MYG_Addin.MYG_HangersBandejasCommand");

            buttonData51.ToolTip =
                "Bandeja a Colgador\n\n" +
                "Genera colgadores/sujetadores para bandejas portacables.\n" +
                "Detecta la parte inferior de la bandeja, toma un nivel superior de referencia\n" +
                "y modifica el parámetro de instancia 'Altura de colgador'.";

            string iconPath51 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "hangers_bandejas.png");

            System.Windows.Media.Imaging.BitmapImage bmp51 =
                CargarBitmapDesdeRuta(
                    iconPath51,
                    16);

            if (bmp51 != null)
            {
                buttonData51.Image = bmp51;
            }

            PushButtonData buttonData52 = new PushButtonData(
                "MYG_ELE_CIRCUITO_TABLERO_52",
                "Circuito Tab.",
                assemblyPath,
                "MYG_Addin.EleCircuitoTableroCommand");

            buttonData52.ToolTip =
                "Circuito Tablero\n\n" +
                "Selecciona un tablero eléctrico y detecta los elementos conectados mediante conectores MEP.\n" +
                "Asigna automáticamente el parámetro de instancia 'ELE_Circuito'.";

            string iconPath52 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "ele_circuito_tablero.png");

            System.Windows.Media.Imaging.BitmapImage bmp52 =
                CargarBitmapDesdeRuta(
                    iconPath52,
                    16);

            if (bmp52 != null)
            {
                buttonData52.Image = bmp52;
            }

            PushButtonData buttonData53 = new PushButtonData(
                "MYG_ELE_CABLES_DIRECTSHAPE_53",
                "Cables DS",
                assemblyPath,
                "MYG_Addin.EleCablesDirectShapeCommand");

            buttonData53.ToolTip =
                "Cables DirectShape\n\n" +
                "Genera cables visuales mediante DirectShape dentro de bandejas portacables.\n" +
                "Lee el parámetro de instancia 'ELE_N°Cables' en cada tramo recto.";

            string iconPath53 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "ele_cables_directshape.png");

            System.Windows.Media.Imaging.BitmapImage bmp53 =
                CargarBitmapDesdeRuta(
                    iconPath53,
                    16);

            if (bmp53 != null)
            {
                buttonData53.Image = bmp53;
            }

            System.Collections.Generic.IList<RibbonItem> botonesMEPElectrico =
                panelMEP.AddStackedItems(
                    buttonData51,
                    buttonData52,
                    buttonData53);

            PushButton button51 = botonesMEPElectrico[0] as PushButton;
            PushButton button52 = botonesMEPElectrico[1] as PushButton;
            PushButton button53 = botonesMEPElectrico[2] as PushButton;

            _buttonBandejaColgador = button51;
            _buttonCircuitoTablero = button52;
            _buttonCablesDS = button53;

            if (button51 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button51);
            }

            if (button52 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button52);
            }

            if (button53 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button53);
            }

            //---------------------------------------------------------
            // GRUPO MEP 5.4 / 5.5 / 5.6
            // CAD BLOQUES A FAMILIAS / TUBOS AUTOMÁTICOS / SECCIÓN A TUBO
            //---------------------------------------------------------

            PushButtonData buttonData54 = new PushButtonData(
                "CADBLOQUESAFAMILIAS_MEP_54",
                "CAD Familias",
                assemblyPath,
                "MYG_Addin.CrearFamiliasDesdeBloquesCad54Command");

            buttonData54.ToolTip =
                "CAD Bloques Familias\n\n" +
                "Selecciona un vínculo/importación CAD y un Excel con matriz de bloques CAD y tipos de familia.\n" +
                "Detecta los bloques del CAD y crea familias por cara en la superficie más próxima.";

            string iconPath54 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "CAD_bloques_familias.png");

            System.Windows.Media.Imaging.BitmapImage bmp54 =
                CargarBitmapDesdeRuta(
                    iconPath54,
                    16);

            if (bmp54 != null)
            {
                buttonData54.Image = bmp54;
            }

            PushButtonData buttonData55 = new PushButtonData(
                "MYG_ELE_TUBOS_AUTOMATICOS_55",
                "Tubos Auto",
                assemblyPath,
                "MYG_Addin.EleTubosAutomaticos55Command");

            buttonData55.ToolTip =
                "Tubos Auto\n\n" +
                "Genera tubos/conduits automáticos entre dos conectores MEP.\n" +
                "Si los conectores no están alineados, propone una ruta ortogonal tipo L/Z con codos automáticos.";

            string iconPath55 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "ele_tubos_automaticos.png");

            System.Windows.Media.Imaging.BitmapImage bmp55 =
                CargarBitmapDesdeRuta(
                    iconPath55,
                    16);

            if (bmp55 != null)
            {
                buttonData55.Image = bmp55;
            }

            PushButtonData buttonData56 = new PushButtonData(
                "MYG_ELE_ALINEAR_SECCION_TUBO_56",
                "Sec. Tubo",
                assemblyPath,
                "MYG_Addin.EleAlinearSeccionTubo56Command");

            buttonData56.ToolTip =
                "Alinear sección a tubo\n\n" +
                "Selecciona primero una tubería/tubo/conduit y luego una sección existente.\n" +
                "Mueve la sección al centro del tubo y la rota para quedar alineada al eje del tubo.";

            string iconPath56 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "ele_alinear_seccion_tubo.png");

            System.Windows.Media.Imaging.BitmapImage bmp56 =
                CargarBitmapDesdeRuta(
                    iconPath56,
                    16);

            if (bmp56 != null)
            {
                buttonData56.Image = bmp56;
            }

            System.Collections.Generic.IList<RibbonItem> botonesMEPCADTubos =
                panelMEP.AddStackedItems(
                    buttonData54,
                    buttonData55,
                    buttonData56);

            PushButton button54 = botonesMEPCADTubos[0] as PushButton;
            PushButton button55 = botonesMEPCADTubos[1] as PushButton;
            PushButton button56 = botonesMEPCADTubos[2] as PushButton;

            _buttonCADBloquesFamilias = button54;
            _buttonTubosAuto = button55;
            _buttonAlinearSeccionTubo = button56;

            if (button54 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button54);
            }

            if (button55 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button55);
            }

            if (button56 != null)
            {
                MYG_RibbonControl.RegistrarBotonProtegido(button56);
            }

            //---------------------------------------------------------
            // GRUPO MEP 5.7
            // MENÚ DESPLEGABLE TRAZADO MEP 3D
            //---------------------------------------------------------

            PulldownButtonData menuData57 = new PulldownButtonData(
                "MYG_MEP_TRAZADO_3D_57",
                "Trazado\nMEP 3D");

            menuData57.ToolTip =
                "Trazado MEP 3D\n\n" +
                "Agrupa herramientas para iniciar tramos desde conectores, crear codos direccionales, " +
                "mover y conectar elementos, alinear conectores y voltear familias múltiples.";

            string iconPath57 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "mep_trazado_3d.png");

            System.Windows.Media.Imaging.BitmapImage bmp57_16 =
                CargarBitmapDesdeRuta(iconPath57, 16);

            System.Windows.Media.Imaging.BitmapImage bmp57_32 =
                CargarBitmapDesdeRuta(iconPath57, 32);

            if (bmp57_16 == null || bmp57_32 == null)
            {
                string iconPath57Respaldo = ObtenerRutaIconoSegunTema(
                    assemblyPath,
                    "ele_tubos_automaticos.png");

                if (bmp57_16 == null)
                    bmp57_16 = CargarBitmapDesdeRuta(iconPath57Respaldo, 16);

                if (bmp57_32 == null)
                    bmp57_32 = CargarBitmapDesdeRuta(iconPath57Respaldo, 32);
            }

            if (bmp57_16 != null)
                menuData57.Image = bmp57_16;

            if (bmp57_32 != null)
                menuData57.LargeImage = bmp57_32;

            PulldownButton menuTrazadoMEP3D =
                panelMEP.AddItem(menuData57) as PulldownButton;

            if (menuTrazadoMEP3D != null)
            {
                System.Func<PushButtonData, string, PushButton> agregarOpcionMEP3D =
                    (datos, nombreIcono) =>
                    {
                        string ruta = ObtenerRutaIconoSegunTema(
                            assemblyPath,
                            nombreIcono);

                        System.Windows.Media.Imaging.BitmapImage icono16 =
                            CargarBitmapDesdeRuta(ruta, 16);

                        System.Windows.Media.Imaging.BitmapImage icono32 =
                            CargarBitmapDesdeRuta(ruta, 32);

                        if (icono16 == null)
                            icono16 = bmp57_16;

                        if (icono32 == null)
                            icono32 = bmp57_32;

                        if (icono16 != null)
                            datos.Image = icono16;

                        if (icono32 != null)
                            datos.LargeImage = icono32;

                        PushButton botonInterno =
                            menuTrazadoMEP3D.AddPushButton(datos);

                        if (botonInterno != null)
                            MYG_RibbonControl.RegistrarBotonProtegido(botonInterno);

                        return botonInterno;
                    };

                PushButtonData dataBloom57 = new PushButtonData(
                    "MYG_MEP3D_BLOOM_571",
                    "Bloom - Iniciar tramos",
                    assemblyPath,
                    "MYG_Addin.MEP3DBloomCommand");

                dataBloom57.ToolTip =
                    "Crea un tramo corto desde cada conector MEP libre del elemento seleccionado. " +
                    "Conserva el tipo cuando parte desde un tramo existente.";

                agregarOpcionMEP3D(
                    dataBloom57,
                    "mep3d_bloom.png");


                menuTrazadoMEP3D.AddSeparator();

                PushButtonData dataArriba57 = new PushButtonData(
                    "MYG_MEP3D_CODO_ARRIBA_572",
                    "Codo arriba",
                    assemblyPath,
                    "MYG_Addin.MEP3DElbowUpCommand");

                dataArriba57.ToolTip =
                    "Selecciona un tramo cerca de un extremo libre y crea un codo con un nuevo tramo hacia arriba.";

                agregarOpcionMEP3D(
                    dataArriba57,
                    "mep3d_codo_arriba.png");

                PushButtonData dataAbajo57 = new PushButtonData(
                    "MYG_MEP3D_CODO_ABAJO_573",
                    "Codo abajo",
                    assemblyPath,
                    "MYG_Addin.MEP3DElbowDownCommand");

                dataAbajo57.ToolTip =
                    "Selecciona un tramo cerca de un extremo libre y crea un codo con un nuevo tramo hacia abajo.";

                agregarOpcionMEP3D(
                    dataAbajo57,
                    "mep3d_codo_abajo.png");

                PushButtonData dataIzquierda57 = new PushButtonData(
                    "MYG_MEP3D_CODO_IZQUIERDA_574",
                    "Codo izquierda",
                    assemblyPath,
                    "MYG_Addin.MEP3DElbowLeftCommand");

                dataIzquierda57.ToolTip =
                    "Crea un codo hacia la izquierda interpretada según la orientación de la vista activa.";

                agregarOpcionMEP3D(
                    dataIzquierda57,
                    "mep3d_codo_izquierda.png");

                PushButtonData dataDerecha57 = new PushButtonData(
                    "MYG_MEP3D_CODO_DERECHA_575",
                    "Codo derecha",
                    assemblyPath,
                    "MYG_Addin.MEP3DElbowRightCommand");

                dataDerecha57.ToolTip =
                    "Crea un codo hacia la derecha interpretada según la orientación de la vista activa.";

                agregarOpcionMEP3D(
                    dataDerecha57,
                    "mep3d_codo_derecha.png");

                menuTrazadoMEP3D.AddSeparator();

                PushButtonData dataMover57 = new PushButtonData(
                    "MYG_MEP3D_MOVER_CONECTAR_576",
                    "Mover y alinear",
                    assemblyPath,
                    "MYG_Addin.MEP3DMoveConnectCommand");

                dataMover57.ToolTip =
                    "Selecciona primero el tramo de referencia y luego el tramo móvil. " +
                    "Alinea el segundo tramo como la herramienta Alinear de Revit, sin ejecutar TRIM, " +
                    "sin crear accesorios y sin conectar el extremo superior.";

                agregarOpcionMEP3D(
                    dataMover57,
                    "mep3d_mover_conectar.png");

                PushButtonData dataMoverAlinear57 = new PushButtonData(
                    "MYG_MEP3D_MOVER_ALINEAR_CONECTAR_577",
                    "Mover, alinear y conectar",
                    assemblyPath,
                    "MYG_Addin.MEP3DMoveConnectAlignCommand");

                dataMoverAlinear57.ToolTip =
                    "Primero alinea el segundo tramo como la herramienta de Revit y después ejecuta " +
                    "TRIM/Extender a esquina para crear el accesorio y completar la conexión.";

                agregarOpcionMEP3D(
                    dataMoverAlinear57,
                    "mep3d_mover_alinear.png");

                menuTrazadoMEP3D.AddSeparator();

                PushButtonData dataVoltear57 = new PushButtonData(
                    "MYG_MEP3D_VOLTEAR_MULTIPLE_578",
                    "Voltear múltiple",
                    assemblyPath,
                    "MYG_Addin.MEP3DFlipMultipleCommand");

                dataVoltear57.ToolTip =
                    "Voltea varias familias mediante Facing, Hand, ambos modos o giro de 180°, " +
                    "según la configuración guardada.";

                agregarOpcionMEP3D(
                    dataVoltear57,
                    "mep3d_voltear_multiple.png");

                PushButtonData dataConfig57 = new PushButtonData(
                    "MYG_MEP3D_CONFIGURACION_579",
                    "Configuración",
                    assemblyPath,
                    "MYG_Addin.MEP3DSettingsCommand");

                dataConfig57.ToolTip =
                    "Configura longitudes, tolerancias, dominios habilitados, movimiento de ramales y modo de volteo.";

                agregarOpcionMEP3D(
                    dataConfig57,
                    "mep3d_configuracion.png");
            }



            //---------------------------------------------------------
            // GRUPO MEP 5.8
            // INFORMACIÓN CABLES CIRCUITO
            //---------------------------------------------------------

            PushButtonData buttonData58 = new PushButtonData(
                "MYG_INFO_CABLES_CIRCUITO_58",
                "Información\ncables circuito",
                assemblyPath,
                "MYG_Addin.InformacionCablesCircuitoCommand");

            buttonData58.ToolTip =
                "Información cables circuito\n\n" +
                "Selecciona dos Aparatos eléctricos y/o Equipos mecánicos.\n" +
                "Detecta una ruta física corta por bandejas y conduits mediante geometría sólida/proximidad,\n" +
                "aunque los elementos no estén conectados lógicamente por conectores MEP.\n" +
                "Escribe temporalmente información de diagnóstico en el parámetro Comentarios.";

            string iconPath58 = ObtenerRutaIconoSegunTema(
                assemblyPath,
                "info_cables_circuito.png");

            System.Windows.Media.Imaging.BitmapImage bmp58_16 =
                CargarBitmapDesdeRuta(iconPath58, 16);

            System.Windows.Media.Imaging.BitmapImage bmp58_32 =
                CargarBitmapDesdeRuta(iconPath58, 32);

            // Respaldo mientras todavía no exista el icono propio.
            if (bmp58_16 == null || bmp58_32 == null)
            {
                string iconPath58Respaldo = ObtenerRutaIconoSegunTema(
                    assemblyPath,
                    "ele_circuito_tablero.png");

                if (bmp58_16 == null)
                    bmp58_16 = CargarBitmapDesdeRuta(iconPath58Respaldo, 16);

                if (bmp58_32 == null)
                    bmp58_32 = CargarBitmapDesdeRuta(iconPath58Respaldo, 32);
            }

            if (bmp58_16 != null)
                buttonData58.Image = bmp58_16;

            if (bmp58_32 != null)
                buttonData58.LargeImage = bmp58_32;

            PushButton button58 =
                panelMEP.AddItem(buttonData58) as PushButton;

            if (button58 != null)
                MYG_RibbonControl.RegistrarBotonProtegido(button58);
        }
    }

}
