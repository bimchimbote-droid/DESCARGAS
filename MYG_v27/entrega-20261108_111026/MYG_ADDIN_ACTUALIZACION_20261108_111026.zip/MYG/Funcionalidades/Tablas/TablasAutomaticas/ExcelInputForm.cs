using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
    // =======================================
    // VENTANA EMERGENTE 1 (TABLAS AUTOMATICAS)
    // =======================================
    public class ExcelInputForm : WinForms.Form
    {
        public string ExcelPath { get; private set; }
        public string SheetName => txtSheet.Text;

        WinForms.TextBox txtRuta;
        WinForms.TextBox txtSheet;
        WinForms.Button btnBuscar;
        WinForms.Button btnEjecutar;

        public ExcelInputForm()
        {
            this.Text = "📊 Tablas Automáticas";
            this.Width = 500;
            this.Height = 280;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.White;
            this.Font = new Drawing.Font("Segoe UI", 9F);

            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 10,
                Width = 400,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            var lblRuta = new WinForms.Label()
            {
                Text = "01. ARCHIVO EXCEL",
                Left = 20,
                Top = 40,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtRuta = new WinForms.TextBox()
            {
                Left = 20,
                Top = 65,
                Width = 320,
                ReadOnly = true,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };

            btnBuscar = new WinForms.Button()
            {
                Text = "Examinar",
                Left = 350,
                Top = 63,
                Width = 100,
                Height = 28,
                BackColor = Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F),
                Cursor = WinForms.Cursors.Hand
            };

            btnBuscar.FlatAppearance.BorderSize = 1;
            btnBuscar.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);

            btnBuscar.Click += BtnBuscar_Click;

            // Hover y click moderno
            btnBuscar.MouseEnter += (s, e) =>
            {
                btnBuscar.BackColor = Drawing.Color.FromArgb(225, 225, 225);
            };
            btnBuscar.MouseLeave += (s, e) =>
            {
                btnBuscar.BackColor = Drawing.Color.FromArgb(240, 240, 240);
            };
            btnBuscar.MouseDown += (s, e) =>
            {
                btnBuscar.BackColor = Drawing.Color.FromArgb(210, 210, 210);
            };
            btnBuscar.MouseUp += (s, e) =>
            {
                btnBuscar.BackColor = Drawing.Color.FromArgb(225, 225, 225);
            };

            var lblSheet = new WinForms.Label()
            {
                Text = "02. NOMBRE DE LA HOJA",
                Left = 20,
                Top = 105,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtSheet = new WinForms.TextBox()
            {
                Left = 20,
                Top = 130,
                Width = 200,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };

            // Línea divisoria
            var linea = new WinForms.Label()
            {
                Left = 20,
                Top = 165,
                Width = 430,
                Height = 1,
                BackColor = Drawing.Color.FromArgb(220, 220, 220)
            };

            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Left = 20,
                Top = 180,
                Width = 430,
                Height = 38,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;

            // Hover botón principal
            btnEjecutar.MouseEnter += (s, e) =>
            {
                btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 100, 190);
            };
            btnEjecutar.MouseLeave += (s, e) =>
            {
                btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 120, 215);
            };
            btnEjecutar.MouseDown += (s, e) =>
            {
                btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 80, 160);
            };
            btnEjecutar.MouseUp += (s, e) =>
            {
                btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 100, 190);
            };

            btnEjecutar.Click += BtnEjecutar_Click;

            this.AcceptButton = btnEjecutar;

            Controls.Add(lblAutor);
            Controls.Add(lblRuta);
            Controls.Add(txtRuta);
            Controls.Add(btnBuscar);
            Controls.Add(lblSheet);
            Controls.Add(txtSheet);
            Controls.Add(linea);
            Controls.Add(btnEjecutar);

            // ===== CARGAR SETTINGS =====

            if (!string.IsNullOrEmpty(MYG.Properties.Settings.Default.V1LastExcelPath))
            {
                ExcelPath = MYG.Properties.Settings.Default.V1LastExcelPath;
                txtRuta.Text = ExcelPath;
            }

            txtSheet.Text = MYG.Properties.Settings.Default.V1LastSheetName;
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            var dialog = new WinForms.OpenFileDialog();
            dialog.Filter = "Excel (*.xlsx)|*.xlsx";

            if (dialog.ShowDialog() == WinForms.DialogResult.OK)
            {
                ExcelPath = dialog.FileName;
                txtRuta.Text = ExcelPath;
            }
        }

        private void BtnEjecutar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ExcelPath) ||
                string.IsNullOrWhiteSpace(txtSheet.Text))
            {
                WinForms.MessageBox.Show("Selecciona archivo Excel y nombre de hoja");
                return;
            }

            // ===== GUARDAR SETTINGS =====

            MYG.Properties.Settings.Default.V1LastExcelPath = ExcelPath;
            MYG.Properties.Settings.Default.V1LastSheetName = txtSheet.Text;

            MYG.Properties.Settings.Default.Save();

            this.DialogResult = WinForms.DialogResult.OK;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ExcelInputForm
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "ExcelInputForm";
            this.Load += new System.EventHandler(this.ExcelInputForm_Load);
            this.ResumeLayout(false);

        }

        private void ExcelInputForm_Load(object sender, EventArgs e)
        {

        }
    }

}
