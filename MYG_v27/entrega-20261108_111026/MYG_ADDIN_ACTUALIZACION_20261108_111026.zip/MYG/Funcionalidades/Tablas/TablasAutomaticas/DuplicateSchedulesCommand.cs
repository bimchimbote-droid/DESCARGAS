using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
















    // ===============================
    // COMANDO 1 (TABLAS AUTOMATICAS)
    // ===============================

    [Transaction(TransactionMode.Manual)]
    public class DuplicateSchedulesCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;
            List<string> created_schedules = new List<string>();

            ExcelInputForm form = new ExcelInputForm();
            if (form.ShowDialog() != WinForms.DialogResult.OK)
                return Result.Cancelled;

            string excelPath = form.ExcelPath;
            string sheetName = form.SheetName;

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var rows = new List<List<string>>();

            using (var package = new ExcelPackage(new FileInfo(excelPath)))
            {
                var ws = package.Workbook.Worksheets[sheetName];

                if (ws == null)
                {
                    TaskDialog.Show("Error", "La hoja no existe");
                    return Result.Failed;
                }

                if (ws.Dimension == null)
                {
                    TaskDialog.Show("Error", "La hoja está vacía");
                    return Result.Failed;
                }

                int maxRow = ws.Dimension.End.Row;
                int maxCol = ws.Dimension.End.Column;

                for (int r = 2; r <= maxRow; r++)
                {
                    var row = new List<string>(maxCol);
                    for (int c = 1; c <= maxCol; c++)
                        row.Add(ws.Cells[r, c].Text);

                    if (row.Count < 19)
                        row.AddRange(Enumerable.Repeat<string>(null, 19 - row.Count));

                    rows.Add(row);
                }
            }

            var schedules = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSchedule))
                .Cast<ViewSchedule>()
                .ToDictionary(x => x.Name, x => x);

            using (Transaction t = new Transaction(doc, "Duplicar tablas"))
            {
                t.Start();

                foreach (var row in rows)
                {
                    try
                    {
                        string subpartida = row[1];
                        string subpartida01 = row[2];
                        string subpartida02 = row[3];
                        string subpartida03 = row[4];
                        string partida = row[5];
                        string plantilla = row[6];

                        if (!schedules.TryGetValue(plantilla, out ViewSchedule template))
                        {
                            created_schedules.Add("Plantilla no encontrada");
                            continue;
                        }

                        ElementId newId = template.Duplicate(ViewDuplicateOption.Duplicate);
                        ViewSchedule newSchedule = doc.GetElement(newId) as ViewSchedule;

                        if (!string.IsNullOrEmpty(partida))
                        {
                            string safe = ReplaceColonWithDot(SanitizeName(partida));
                            newSchedule.Name = safe;
                        }

                        // =====================================================
                        // MODIFICADO:
                        // Evita que Revit muestre "???" cuando algún parámetro
                        // de organización del navegador está vacío.
                        //
                        // También evita repetir subtítulos como:
                        // 1.2 MOVIMIENTO DE TIERRAS
                        //    1.2 MOVIMIENTO DE TIERRAS
                        //       1.2 MOVIMIENTO DE TIERRAS
                        //
                        // Si un nivel viene vacío desde Excel, se coloca un
                        // carácter invisible en vez de copiar el último valor.
                        // =====================================================

                        CompletarGruposVistasSinDuplicar(
                            ref subpartida,
                            ref subpartida01,
                            ref subpartida02,
                            ref subpartida03,
                            partida);

                        SetParametroTexto(newSchedule, "SHE_GrupoVistas", subpartida);
                        SetParametroTexto(newSchedule, "SHE_GrupoVistas01", subpartida01);
                        SetParametroTexto(newSchedule, "SHE_GrupoVistas02", subpartida02);
                        SetParametroTexto(newSchedule, "SHE_GrupoVistas03", subpartida03);

                        var fieldMap = GetFieldMap(newSchedule);

                        // ✅ Pasamos doc al método
                        AddFilterFast(doc, newSchedule, fieldMap, row[7], row[8], row[9]);
                        AddFilterFast(doc, newSchedule, fieldMap, row[10], row[11], row[12]);
                        AddFilterFast(doc, newSchedule, fieldMap, row[13], row[14], row[15]);
                        AddFilterFast(doc, newSchedule, fieldMap, row[16], row[17], row[18]);

                        created_schedules.Add(newSchedule.Name);
                    }
                    catch (Exception ex)
                    {
                        created_schedules.Add(ex.Message);
                    }
                }

                t.Commit();
            }

            int totalCreadas = created_schedules.Count(x => !x.Contains("no encontrada"));
            TaskDialog.Show("Resultado", $"{totalCreadas} tablas creadas");

            return Result.Succeeded;
        }

        Dictionary<string, ScheduleField> GetFieldMap(ViewSchedule schedule)
        {
            var map = new Dictionary<string, ScheduleField>(StringComparer.OrdinalIgnoreCase);
            var def = schedule.Definition;

            for (int i = 0; i < def.GetFieldCount(); i++)
            {
                var f = def.GetField(i);
                map[f.GetName()] = f;
            }
            return map;
        }

        // =====================================================
        // NUEVO:
        // Completa los parámetros de grupo sin duplicar títulos.
        // Los vacíos se reemplazan por un carácter invisible.
        // =====================================================
        void CompletarGruposVistasSinDuplicar(
            ref string subpartida,
            ref string subpartida01,
            ref string subpartida02,
            ref string subpartida03,
            string partida)
        {
            subpartida = LimpiarTexto(subpartida);
            subpartida01 = LimpiarTexto(subpartida01);
            subpartida02 = LimpiarTexto(subpartida02);
            subpartida03 = LimpiarTexto(subpartida03);
            partida = LimpiarTexto(partida);

            // Carácter invisible.
            // Sirve para que Revit no muestre "???"
            // y tampoco repita subtítulos.
            string nivelOculto = "\u200B";

            if (string.IsNullOrWhiteSpace(subpartida03))
                subpartida03 = nivelOculto;

            if (string.IsNullOrWhiteSpace(subpartida02))
                subpartida02 = nivelOculto;

            if (string.IsNullOrWhiteSpace(subpartida01))
                subpartida01 = nivelOculto;

            if (string.IsNullOrWhiteSpace(subpartida))
                subpartida = nivelOculto;
        }

        // =====================================================
        // NUEVO:
        // Asigna texto a un parámetro verificando existencia
        // y que no sea de solo lectura.
        // =====================================================
        void SetParametroTexto(Element elem, string nombreParametro, string valor)
        {
            if (elem == null) return;

            Parameter p = elem.LookupParameter(nombreParametro);

            if (p == null) return;
            if (p.IsReadOnly) return;

            p.Set(valor ?? "");
        }

        // =====================================================
        // NUEVO:
        // Limpia texto nulo o con espacios.
        // =====================================================
        string LimpiarTexto(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            return texto.Trim();
        }

        // 🔥 MÉTODO MODIFICADO (ahora recibe Document)
        void AddFilterFast(Document doc, ViewSchedule schedule, Dictionary<string, ScheduleField> fieldMap, string parametro, string valor, string regla)
        {
            if (string.IsNullOrWhiteSpace(parametro) || string.IsNullOrWhiteSpace(regla)) return;
            if (!fieldMap.TryGetValue(parametro, out ScheduleField field)) return;

            string r = regla.Trim().ToLower();
            string v = valor?.Trim();
            if (string.IsNullOrWhiteSpace(v)) return;

            ScheduleFilter filter = null;

            // 1️⃣ Reglas de texto primero
            if (r == "beginswith" || r == "empieza por" || r == "empieza")
                filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.BeginsWith, v);

            else if (r == "doesnotbeginwith" || r == "no empieza por" || r == "no empieza")
                filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.NotBeginsWith, v);

            else if (r == "contains" || r == "contiene")
                filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.Contains, v);

            else if (r == "notcontains" || r == "no contiene")
                filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.NotContains, v);

            else if (r == "hasvalue" || r == "tiene un valor" || r == "no vacio")
                filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.HasValue);

            // 2️⃣ Reglas de igualdad
            else if (r == "equals" || r == "=" || r == "igual" || r == "es igual a")
            {
                ForgeTypeId specId = field.GetSpecTypeId();

                bool isDouble =
                    specId == SpecTypeId.Length ||
                    specId == SpecTypeId.Area ||
                    specId == SpecTypeId.Volume ||
                    specId == SpecTypeId.Angle ||
                    specId.TypeId.ToLower().Contains("length") ||
                    specId.TypeId.ToLower().Contains("diameter") ||
                    specId.TypeId.ToLower().Contains("size") ||
                    specId.TypeId.ToLower().Contains("angle");

                // =====================================================
                // 🔹 BOOLEANOS (YES/NO) — DETECCIÓN REAL DEL PARÁMETRO
                // =====================================================

                bool isBoolean = false;

                ParameterElement paramElem =
                    doc.GetElement(field.ParameterId) as ParameterElement;

                if (paramElem != null)
                {
                    Definition def = paramElem.GetDefinition();
                    if (def != null && def.GetDataType() == SpecTypeId.Boolean.YesNo)
                        isBoolean = true;
                }

                if (isBoolean &&
                    (v.Equals("Sí", StringComparison.OrdinalIgnoreCase) ||
                     v.Equals("true", StringComparison.OrdinalIgnoreCase) ||
                     v == "1" ||
                     v.Equals("No", StringComparison.OrdinalIgnoreCase) ||
                     v.Equals("false", StringComparison.OrdinalIgnoreCase) ||
                     v == "0"))
                {
                    int boolVal = (v == "1" ||
                                   v.Equals("Sí", StringComparison.OrdinalIgnoreCase) ||
                                   v.Equals("true", StringComparison.OrdinalIgnoreCase)) ? 1 : 0;

                    filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.Equal, boolVal);
                }

                // =====================================================
                // 🔹 DOUBLE (NO TOCADO)
                // =====================================================
                else if (isDouble)
                {
                    double internalVal;

                    if (UnitFormatUtils.TryParse(
                        doc.GetUnits(),
                        specId,
                        v, // 👈 el valor tal cual del Excel (ej: 3/4", 1 1/4", etc.)
                        out internalVal))
                    {
                        filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.Equal, internalVal);
                    }
                }

                // =====================================================
                // 🔹 ENTERO
                // =====================================================
                else if (int.TryParse(v, out int intVal))
                {
                    filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.Equal, intVal);
                }

                // =====================================================
                // 🔹 TEXTO
                // =====================================================
                else
                {
                    filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.Equal, v);
                }
            }

            else if (r == "notequals" || r == "no es igual a" || r == "no igual" || r == "≠")
            {
                if (double.TryParse(v, out double num))
                    filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.NotEqual, num);
                else
                    filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.NotEqual, v);
            }

            else if (r == "greaterthan" || r == "es mayor que" || r == ">" || r == "mayor")
            {
                ForgeTypeId specId = field.GetSpecTypeId();

                bool isDouble = UnitUtils.IsMeasurableSpec(specId);

                if (isDouble)
                {
                    double internalVal;

                    // limpieza opcional
                    v = v.Replace("°", "").Trim();

                    if (UnitFormatUtils.TryParse(
                        doc.GetUnits(),
                        specId,
                        v,
                        out internalVal))
                    {
                        filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.GreaterThan, internalVal);
                    }
                }
            }

            else if (r == "lessthan" || r == "menor que" || r == "<" || r == "menor" || r == "es menor que")
            {
                ForgeTypeId specId = field.GetSpecTypeId();
                bool isDouble = UnitUtils.IsMeasurableSpec(specId);

                if (isDouble)
                {
                    double internalVal;

                    v = v.Replace("°", "").Trim();

                    if (UnitFormatUtils.TryParse(
                        doc.GetUnits(),
                        specId,
                        v,
                        out internalVal))
                    {
                        filter = new ScheduleFilter(field.FieldId, ScheduleFilterType.LessThan, internalVal);
                    }
                }
            }

            if (filter != null)
                schedule.Definition.AddFilter(filter);
        }

        string SanitizeName(string name)
        {
            return Regex.Replace(name, @"[\\{}\[\]\|;<>?`~]", "");
        }

        string ReplaceColonWithDot(string name)
        {
            if (string.IsNullOrEmpty(name)) return name;
            return name.Replace(":", "ː");
        }
    }

}
