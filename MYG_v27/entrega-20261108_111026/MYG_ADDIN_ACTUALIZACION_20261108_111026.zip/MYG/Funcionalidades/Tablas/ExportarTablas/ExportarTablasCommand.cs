using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ===============================
    // COMANDO 3 (EXPORTAR TABLAS)
    // ===============================

    [Transaction(TransactionMode.Manual)]
    public class ExportarTablasCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            var form = new ExportarTablasForm(doc);

            if (form.ShowDialog() != WinForms.DialogResult.OK)
                return Result.Cancelled;

            string folder = form.FolderPath;
            string activo = form.Activo;
            string codigo = form.Codigo;
            string especialidad = form.Especialidad;
            string logoPath = form.LogoPath;
            bool exportarPDF = form.ExportarPDF;
            bool ajustarTablasAlAnchoMaximo = form.AjustarTablasAlAnchoMaximo;
            List<string> tablasSeleccionadasIds = form.TablasSeleccionadasIds;

            string filepath = Path.Combine(
                folder,
                "SUSTENTO DE METRADOS - " + especialidad + " - " + activo + ".xlsx"
            );

            ExportarExcel(
                doc,
                filepath,
                activo,
                codigo,
                especialidad,
                tablasSeleccionadasIds,
                logoPath,
                exportarPDF,
                ajustarTablasAlAnchoMaximo
            );

            TaskDialog.Show("Exportar Tablas", "Excel creado correctamente");

            return Result.Succeeded;
        }

        private void ExportarExcel(
            Document doc,
            string filepath,
            string activo,
            string codigo,
            string especialidad,
            List<string> tablasSeleccionadasIds,
            string logoPath,
            bool exportarPDF,
            bool ajustarTablasAlAnchoMaximo)
        {
            // =====================================================
            // HABILITAR CODIFICACIONES LEGACY PARA EPPLUS / .NET 8
            // NECESARIO EN REVIT 2027
            // =====================================================

            System.Text.Encoding.RegisterProvider(
                System.Text.CodePagesEncodingProvider.Instance
            );

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage())
            {
                var ws = package.Workbook.Worksheets.Add("Export");

                // =====================================================
                // CONFIGURACION GLOBAL DE HOJA (A4 HORIZONTAL)
                // =====================================================

                ws.Cells.Style.Font.Name = "Arial Narrow";
                ws.Cells.Style.Font.Size = 11;

                ws.PrinterSettings.PaperSize = ePaperSize.A4;
                ws.PrinterSettings.Orientation = eOrientation.Landscape;

                ws.PrinterSettings.FitToPage = true;
                ws.PrinterSettings.FitToWidth = 1;
                ws.PrinterSettings.FitToHeight = 0;

                ws.View.PageBreakView = true;

                // =======================================
                // REPETIR FILAS EN IMPRESION
                // =======================================

                ws.PrinterSettings.RepeatRows = ws.Cells["1:7"];

                int fila = 1;

                var schedules = tablasSeleccionadasIds
                    .Select(id => doc.GetElement(id) as ViewSchedule)
                    .Where(x => x != null && !x.IsTemplate)
                    .ToList();

                // =====================================================
                // ANCHO MAXIMO DE LAS TABLAS SELECCIONADAS
                // =====================================================

                int maxCols = 4;

                foreach (var sched in schedules)
                {
                    int count = 0;

                    for (int i = 0; i < sched.Definition.GetFieldCount(); i++)
                        if (!sched.Definition.GetField(i).IsHidden)
                            count++;

                    if (count > maxCols)
                        maxCols = count;
                }

                string proyecto = doc.ProjectInformation.Name;

                // =====================================================
                // UBICACION DESDE "DIRECCION DE PROYECTO"
                // =====================================================

                string ubicacion = "";

                Parameter pDireccion = doc.ProjectInformation
                    .get_Parameter(BuiltInParameter.PROJECT_ADDRESS);

                if (pDireccion != null)
                    ubicacion = pDireccion.AsString();

                // =====================================================
                // ENTIDAD DESDE "NOMBRE DE CLIENTE"
                // =====================================================

                string entidad = "";

                Parameter pCliente = doc.ProjectInformation.LookupParameter("Nombre de cliente");

                if (pCliente == null)
                {
                    pCliente = doc.ProjectInformation.LookupParameter("Client Name");
                }

                if (pCliente != null)
                {
                    entidad = pCliente.AsString();
                }

                // =======================================
                // ENCABEZADO
                // =======================================

                EscribirEncabezado(ws, ref fila, "PROYECTO", proyecto, maxCols);
                EscribirEncabezado(ws, ref fila, "ENTIDAD", entidad, maxCols);
                EscribirEncabezado(ws, ref fila, "UBICACION", ubicacion, maxCols);
                EscribirEncabezado(ws, ref fila, "ACTIVO", activo, maxCols);
                EscribirEncabezado(ws, ref fila, "CODIGO", codigo, maxCols);
                EscribirEncabezado(ws, ref fila, "ESPECIALIDAD", especialidad, maxCols);

                InsertarLogo(ws, logoPath, maxCols);

                // =======================================
                // COLOR GRIS PARA TITULOS
                // =======================================

                var rangoTitulos = ws.Cells[1, 1, 6, 1];

                rangoTitulos.Style.Fill.PatternType =
                    OfficeOpenXml.Style.ExcelFillStyle.Solid;

                rangoTitulos.Style.Fill.BackgroundColor.SetColor(
                    System.Drawing.Color.LightGray);

                fila++;

                // =======================================
                // TITULO DOCUMENTO
                // =======================================

                ws.Cells[fila, 1, fila, maxCols].Merge = true;
                ws.Cells[fila, 1].Value = "SUSTENTO DE METRADOS BIM";

                ws.Cells[fila, 1].Style.Font.Bold = true;
                ws.Cells[fila, 1].Style.Font.Size = 14;

                ws.Cells[fila, 1].Style.HorizontalAlignment =
                    OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                fila += 2;

                foreach (var sched in schedules)
                {
                    var headers = new List<string>();
                    var columnasValidas = new List<int>();

                    var fieldsVisibles = sched.Definition.GetFieldOrder()
                        .Select(id => sched.Definition.GetField(id))
                        .Where(f => !f.IsHidden)
                        .ToList();

                    int indexField = 0;

                    var body = sched.GetTableData().GetSectionData(SectionType.Body);

                    for (int c = 0; c < body.NumberOfColumns; c++)
                    {
                        bool tieneDatos = false;

                        for (int r = 1; r < body.NumberOfRows; r++)
                        {
                            string val = sched.GetCellText(SectionType.Body, r, c);

                            if (!string.IsNullOrWhiteSpace(val))
                            {
                                tieneDatos = true;
                                break;
                            }
                        }

                        if (tieneDatos)
                        {
                            columnasValidas.Add(c);

                            if (indexField < fieldsVisibles.Count)
                            {
                                headers.Add(fieldsVisibles[indexField].ColumnHeading);
                                indexField++;
                            }
                            else
                            {
                                headers.Add("");
                            }
                        }
                    }

                    if (headers.Count == 0)
                        continue;

                    // =====================================================
                    // SI EL CHECK ESTA ACTIVADO:
                    // distribuye las columnas de esta tabla dentro de maxCols.
                    // SI ESTA DESACTIVADO:
                    // conserva exactamente el comportamiento original.
                    // =====================================================

                    List<Tuple<int, int>> rangosColumnas = null;

                    if (ajustarTablasAlAnchoMaximo)
                        rangosColumnas = CalcularRangosColumnas(headers.Count, maxCols);

                    int ultimaColumnaTabla =
                        ajustarTablasAlAnchoMaximo ? maxCols : headers.Count;

                    // ===== TITULO DE LA TABLA =====

                    ws.Cells[fila, 1, fila, ultimaColumnaTabla].Merge = true;

                    var tituloPartida = ws.Cells[fila, 1];

                    tituloPartida.Value = sched.Name;

                    tituloPartida.Style.Font.Bold = true;
                    tituloPartida.Style.Font.Color.SetColor(System.Drawing.Color.White);

                    tituloPartida.Style.Fill.PatternType =
                        OfficeOpenXml.Style.ExcelFillStyle.Solid;

                    tituloPartida.Style.Fill.BackgroundColor.SetColor(
                        System.Drawing.Color.FromArgb(16, 72, 97));

                    tituloPartida.Style.HorizontalAlignment =
                        OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                    AplicarBordes(ws.Cells[fila, 1, fila, ultimaColumnaTabla]);

                    fila++;

                    // ===== ENCABEZADOS =====

                    for (int i = 0; i < headers.Count; i++)
                    {
                        if (ajustarTablasAlAnchoMaximo)
                        {
                            int colInicio = rangosColumnas[i].Item1;
                            int colFin = rangosColumnas[i].Item2;

                            var rangoHeader = ws.Cells[fila, colInicio, fila, colFin];

                            if (colFin > colInicio)
                                rangoHeader.Merge = true;

                            ws.Cells[fila, colInicio].Value = headers[i];

                            rangoHeader.Style.Font.Bold = true;
                            rangoHeader.Style.WrapText = true;

                            rangoHeader.Style.Fill.PatternType =
                                OfficeOpenXml.Style.ExcelFillStyle.Solid;

                            rangoHeader.Style.Fill.BackgroundColor.SetColor(
                                System.Drawing.Color.LightGray);

                            AplicarBordes(rangoHeader);
                        }
                        else
                        {
                            var cell = ws.Cells[fila, i + 1];

                            cell.Value = headers[i];
                            cell.Style.Font.Bold = true;

                            cell.Style.Fill.PatternType =
                                OfficeOpenXml.Style.ExcelFillStyle.Solid;

                            cell.Style.Fill.BackgroundColor.SetColor(
                                System.Drawing.Color.LightGray);
                        }
                    }

                    if (!ajustarTablasAlAnchoMaximo)
                        AplicarBordes(ws.Cells[fila, 1, fila, headers.Count]);

                    fila++;

                    // ===== CUERPO =====

                    for (int r = 1; r < body.NumberOfRows; r++)
                    {
                        bool esTotal = false;

                        List<string> valores = new List<string>();

                        foreach (int c in columnasValidas)
                        {
                            string val = "";

                            try
                            {
                                val = sched.GetCellText(SectionType.Body, r, c);
                            }
                            catch
                            {
                                continue;
                            }

                            valores.Add(val);

                            if (!string.IsNullOrEmpty(val) &&
                                val.ToLower().Contains("total"))
                                esTotal = true;
                        }

                        bool esAgrupacion =
                            valores.Count > 0 &&
                            valores.Skip(1).All(v => string.IsNullOrEmpty(v));

                        if (esAgrupacion)
                        {
                            int ultimaColumnaAgrupacion =
                                ajustarTablasAlAnchoMaximo ? maxCols : headers.Count;

                            var rangoAgrupacion = ws.Cells[
                                fila,
                                1,
                                fila,
                                ultimaColumnaAgrupacion
                            ];

                            rangoAgrupacion.Merge = true;

                            ws.Cells[fila, 1].Value = valores[0];

                            ws.Cells[fila, 1].Style.Font.Bold = true;

                            ws.Cells[fila, 1].Style.HorizontalAlignment =
                                OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;

                            rangoAgrupacion.Style.Fill.PatternType =
                                OfficeOpenXml.Style.ExcelFillStyle.Solid;

                            rangoAgrupacion.Style.Fill.BackgroundColor.SetColor(
                                System.Drawing.Color.FromArgb(242, 242, 242));

                            AplicarBordes(rangoAgrupacion);
                        }
                        else
                        {
                            if (ajustarTablasAlAnchoMaximo)
                            {
                                for (int i = 0; i < valores.Count; i++)
                                {
                                    int colInicio = rangosColumnas[i].Item1;
                                    int colFin = rangosColumnas[i].Item2;

                                    var rangoDato = ws.Cells[
                                        fila,
                                        colInicio,
                                        fila,
                                        colFin
                                    ];

                                    if (colFin > colInicio)
                                        rangoDato.Merge = true;

                                    ws.Cells[fila, colInicio].Value = valores[i];
                                    rangoDato.Style.WrapText = true;

                                    AplicarBordes(rangoDato);
                                }

                                if (esTotal)
                                    ws.Cells[fila, 1, fila, maxCols].Style.Font.Bold = true;
                            }
                            else
                            {
                                for (int i = 0; i < valores.Count; i++)
                                {
                                    ws.Cells[fila, i + 1].Value = valores[i];
                                }

                                if (esTotal)
                                    ws.Cells[fila, 1, fila, headers.Count].Style.Font.Bold = true;

                                AplicarBordes(ws.Cells[fila, 1, fila, headers.Count]);
                            }
                        }

                        fila++;
                    }

                    fila += 2;
                }

                // =====================================================
                // ANCHOS + ALTURAS DINÁMICAS
                // =====================================================

                // IMPORTANTE:
                // AutoFit por sí solo deja las columnas demasiado angostas.
                // Primero hace un AutoFit moderado y, si está activo el check,
                // ensancha la malla completa para aprovechar una hoja A4 HORIZONTAL.
                ws.Cells.AutoFitColumns(8, 24);

                if (ajustarTablasAlAnchoMaximo)
                {
                    AjustarAnchosParaA4Horizontal(ws, maxCols);
                }

                // La altura se calcula DESPUÉS de definir el ancho final.
                // Así, al haber más espacio horizontal, los textos se parten
                // en menos líneas y entran muchas más filas por página.
                AjustarAlturasFilasDinamicamente(
                    ws,
                    1,
                    Math.Max(1, fila - 1),
                    3
                );

                // Solo modifica el área/centrado de impresión cuando el check está activo.
                if (ajustarTablasAlAnchoMaximo)
                {
                    ws.PrinterSettings.HorizontalCentered = true;
                    ws.PrinterSettings.PrintArea =
                        ws.Cells[1, 1, Math.Max(1, fila - 1), maxCols];
                }

                package.SaveAs(new FileInfo(filepath));

                // =======================================
                // EXPORTAR PDF
                // =======================================

                if (exportarPDF)
                {
                    string pdfPath = Path.ChangeExtension(filepath, ".pdf");

                    var excel = new ExcelInterop.Application();
                    excel.Visible = false;

                    var wb = excel.Workbooks.Open(filepath);

                    ExcelInterop.Worksheet sheet =
                        (ExcelInterop.Worksheet)wb.Worksheets[1];

                    sheet.PageSetup.PaperSize =
                        ExcelInterop.XlPaperSize.xlPaperA4;

                    sheet.PageSetup.Orientation =
                        ExcelInterop.XlPageOrientation.xlLandscape;

                    sheet.PageSetup.PrintArea =
                        sheet.UsedRange.Address;

                    sheet.PageSetup.Zoom = false;
                    sheet.PageSetup.FitToPagesWide = 1;
                    sheet.PageSetup.FitToPagesTall = false;

                    sheet.PageSetup.LeftMargin = excel.CentimetersToPoints(1);
                    sheet.PageSetup.RightMargin = excel.CentimetersToPoints(1);
                    sheet.PageSetup.TopMargin = excel.CentimetersToPoints(1);
                    sheet.PageSetup.BottomMargin = excel.CentimetersToPoints(1);

                    if (ajustarTablasAlAnchoMaximo)
                        sheet.PageSetup.CenterHorizontally = true;

                    wb.ExportAsFixedFormat(
                        ExcelInterop.XlFixedFormatType.xlTypePDF,
                        pdfPath
                    );

                    wb.Close(false);
                    excel.Quit();
                }
            }
        }

        // =====================================================
        // ANCHO DE COLUMNAS PARA A4 HORIZONTAL
        // =====================================================
        // El problema de AutoFitColumns es que calcula el ancho mínimo necesario
        // y desaprovecha gran parte del ancho físico de una hoja horizontal.
        //
        // Esta rutina:
        // 1. conserva columnas que AutoFit detectó como anchas,
        // 2. impone un ancho mínimo según la cantidad de columnas,
        // 3. reparte el espacio sobrante para que la tabla se vea más extendida,
        // 4. evita anchos excesivos que luego harían que Excel reduzca demasiado
        //    la escala al imprimir.
        private void AjustarAnchosParaA4Horizontal(
            ExcelWorksheet ws,
            int maxCols)
        {
            if (ws == null || maxCols <= 0)
                return;

            // Ancho mínimo por columna según cuántas columnas tenga la tabla mayor.
            // Para el caso de 12 columnas de tu captura: 13.0 por columna.
            double anchoMinimo;

            if (maxCols <= 5)
                anchoMinimo = 18.0;
            else if (maxCols <= 8)
                anchoMinimo = 15.0;
            else if (maxCols <= 10)
                anchoMinimo = 14.0;
            else if (maxCols <= 12)
                anchoMinimo = 13.0;
            else if (maxCols <= 15)
                anchoMinimo = 10.5;
            else if (maxCols <= 18)
                anchoMinimo = 9.0;
            else
                anchoMinimo = 8.0;

            // Límite razonable para una celda individual.
            double anchoMaximo = 24.0;

            for (int c = 1; c <= maxCols; c++)
            {
                double actual = ws.Column(c).Width;

                if (actual < anchoMinimo)
                    actual = anchoMinimo;

                if (actual > anchoMaximo)
                    actual = anchoMaximo;

                ws.Column(c).Width = actual;
            }

            // Para tablas de hasta 12 columnas aprovechamos todavía mejor
            // el formato apaisado. Si después del AutoFit el ancho total quedó
            // corto, se amplían todas proporcionalmente hasta un ancho objetivo.
            double anchoObjetivoTotal;

            if (maxCols <= 6)
                anchoObjetivoTotal = 105.0;
            else if (maxCols <= 8)
                anchoObjetivoTotal = 120.0;
            else if (maxCols <= 10)
                anchoObjetivoTotal = 140.0;
            else if (maxCols <= 12)
                anchoObjetivoTotal = 156.0;
            else if (maxCols <= 15)
                anchoObjetivoTotal = 160.0;
            else
                anchoObjetivoTotal = 165.0;

            double anchoActualTotal = 0.0;

            for (int c = 1; c <= maxCols; c++)
                anchoActualTotal += ws.Column(c).Width;

            if (anchoActualTotal > 0.0 && anchoActualTotal < anchoObjetivoTotal)
            {
                double factor = anchoObjetivoTotal / anchoActualTotal;

                for (int c = 1; c <= maxCols; c++)
                {
                    double nuevo = ws.Column(c).Width * factor;

                    if (nuevo > anchoMaximo)
                        nuevo = anchoMaximo;

                    ws.Column(c).Width = nuevo;
                }
            }
        }

        // =====================================================
        // ALTURA DINÁMICA DE FILAS
        // =====================================================
        // - No usa una sola altura fija para todas las filas.
        // - Calcula cuántas líneas requiere cada celda según su ancho real.
        // - Reconoce celdas combinadas.
        // - Filas cortas: 1 línea.
        // - Filas con texto medio: 2 o 3 líneas.
        // - Textos muy largos: se limita a maxLineas y usa ShrinkToFit
        //   para que una sola descripción no genere filas enormes.
        private void AjustarAlturasFilasDinamicamente(
            ExcelWorksheet ws,
            int primeraFila,
            int ultimaFila,
            int maxLineas)
        {
            if (ws == null || ws.Dimension == null)
                return;

            if (maxLineas < 1)
                maxLineas = 1;

            int ultimaColumna = ws.Dimension.End.Column;

            for (int r = primeraFila; r <= ultimaFila; r++)
            {
                bool tieneContenido = false;
                int lineasFila = 1;
                double mayorFuente = 11.0;

                for (int c = 1; c <= ultimaColumna; c++)
                {
                    int colInicio = c;
                    int colFin = c;

                    // Si la celda pertenece a un rango combinado, trabajamos
                    // solamente con la celda superior izquierda del rango.
                    string direccionCombinada = ws.MergedCells[r, c];

                    if (!string.IsNullOrEmpty(direccionCombinada))
                    {
                        var rangoCombinado = ws.Cells[direccionCombinada];

                        // Si no estamos en la primera columna del combinado,
                        // ya fue evaluado anteriormente.
                        if (c != rangoCombinado.Start.Column)
                            continue;

                        colInicio = rangoCombinado.Start.Column;
                        colFin = rangoCombinado.End.Column;
                    }

                    var celda = ws.Cells[r, colInicio];
                    string texto = celda.Text ?? "";

                    if (string.IsNullOrWhiteSpace(texto))
                    {
                        c = colFin;
                        continue;
                    }

                    tieneContenido = true;

                    double fuente = celda.Style.Font.Size;
                    if (fuente <= 0)
                        fuente = 11.0;

                    if (fuente > mayorFuente)
                        mayorFuente = fuente;

                    // Ancho real disponible de la celda o del rango combinado.
                    double anchoDisponible = 0.0;

                    for (int cc = colInicio; cc <= colFin; cc++)
                        anchoDisponible += ws.Column(cc).Width;

                    int lineasNecesarias = CalcularLineasNecesarias(
                        texto,
                        anchoDisponible
                    );

                    if (lineasNecesarias > maxLineas)
                    {
                        // Evita alturas descontroladas. Excel reduce ligeramente
                        // el texto para conservarlo dentro del espacio disponible.
                        if (!string.IsNullOrEmpty(direccionCombinada))
                        {
                            var rango = ws.Cells[direccionCombinada];
                            rango.Style.WrapText = true;
                            rango.Style.ShrinkToFit = true;
                        }
                        else
                        {
                            celda.Style.WrapText = true;
                            celda.Style.ShrinkToFit = true;
                        }

                        lineasNecesarias = maxLineas;
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(direccionCombinada))
                        {
                            var rango = ws.Cells[direccionCombinada];
                            rango.Style.WrapText = true;
                            rango.Style.ShrinkToFit = false;
                        }
                        else
                        {
                            celda.Style.WrapText = true;
                            celda.Style.ShrinkToFit = false;
                        }
                    }

                    if (lineasNecesarias > lineasFila)
                        lineasFila = lineasNecesarias;

                    c = colFin;
                }

                if (!tieneContenido)
                {
                    // Las filas vacías que separan tablas ocupan muy poco espacio.
                    ws.Row(r).Height = 5.0;
                    continue;
                }

                // Altura aproximada por línea en puntos.
                // Se adapta también si la fila tiene texto de 12, 14 pt, etc.
                double alturaPorLinea = Math.Max(12.0, mayorFuente * 1.20);
                double alturaFinal = 3.0 + (lineasFila * alturaPorLinea);

                ws.Row(r).Height = alturaFinal;
            }
        }

        // =====================================================
        // ESTIMA CUÁNTAS LÍNEAS NECESITA UN TEXTO
        // =====================================================
        private int CalcularLineasNecesarias(
            string texto,
            double anchoDisponible)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return 1;

            if (anchoDisponible <= 0)
                return 1;

            // Con Arial Narrow caben más caracteres que con Calibri.
            // El factor 1.18 funciona bien para texto de 10-11 pt.
            int caracteresPorLinea = Math.Max(
                1,
                (int)Math.Floor(anchoDisponible * 1.18)
            );

            int totalLineas = 0;

            string[] parrafos = texto
                .Replace("\r\n", "\n")
                .Replace("\r", "\n")
                .Split('\n');

            foreach (string parrafoOriginal in parrafos)
            {
                string parrafo = (parrafoOriginal ?? "").Trim();

                if (parrafo.Length == 0)
                {
                    totalLineas++;
                    continue;
                }

                string[] palabras = parrafo
                    .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                int longitudLinea = 0;
                int lineasParrafo = 1;

                foreach (string palabra in palabras)
                {
                    // Palabra más larga que el ancho disponible.
                    if (palabra.Length > caracteresPorLinea)
                    {
                        if (longitudLinea > 0)
                        {
                            lineasParrafo++;
                            longitudLinea = 0;
                        }

                        int lineasPalabra = (int)Math.Ceiling(
                            (double)palabra.Length / caracteresPorLinea
                        );

                        lineasParrafo += lineasPalabra - 1;
                        longitudLinea = palabra.Length % caracteresPorLinea;

                        if (longitudLinea == 0)
                            longitudLinea = caracteresPorLinea;

                        continue;
                    }

                    int requerido =
                        longitudLinea == 0
                            ? palabra.Length
                            : longitudLinea + 1 + palabra.Length;

                    if (requerido <= caracteresPorLinea)
                    {
                        longitudLinea = requerido;
                    }
                    else
                    {
                        lineasParrafo++;
                        longitudLinea = palabra.Length;
                    }
                }

                totalLineas += lineasParrafo;
            }

            return Math.Max(1, totalLineas);
        }

        // =====================================================
        // REPARTE N COLUMNAS LOGICAS DENTRO DE maxCols
        // Ej.: 4 columnas en una malla de 12 => A:C, D:F, G:I, J:L
        // =====================================================

        private List<Tuple<int, int>> CalcularRangosColumnas(
            int cantidadColumnas,
            int maxCols)
        {
            var resultado = new List<Tuple<int, int>>();

            if (cantidadColumnas <= 0 || maxCols <= 0)
                return resultado;

            for (int i = 0; i < cantidadColumnas; i++)
            {
                int inicio =
                    (int)Math.Round(
                        (double)i * maxCols / cantidadColumnas,
                        MidpointRounding.AwayFromZero) + 1;

                int fin =
                    (int)Math.Round(
                        (double)(i + 1) * maxCols / cantidadColumnas,
                        MidpointRounding.AwayFromZero);

                if (fin < inicio)
                    fin = inicio;

                resultado.Add(Tuple.Create(inicio, fin));
            }

            return resultado;
        }

        private void EscribirEncabezado(
            ExcelWorksheet ws,
            ref int fila,
            string titulo,
            string valor,
            int maxCols)
        {
            ws.Cells[fila, 1].Value = titulo;
            ws.Cells[fila, 1].Style.Font.Bold = true;

            ws.Cells[fila, 2, fila, maxCols - 1].Merge = true;
            ws.Cells[fila, 2].Value = valor;

            AplicarBordes(ws.Cells[fila, 1, fila, maxCols - 1]);

            fila++;
        }

        private void InsertarLogo(ExcelWorksheet ws, string logoPath, int maxCols)
        {
            if (string.IsNullOrEmpty(logoPath))
                return;

            if (!File.Exists(logoPath))
                return;

            int colLogo = maxCols;

            var rangoLogo = ws.Cells[1, colLogo, 6, colLogo];

            rangoLogo.Merge = true;

            rangoLogo.Style.HorizontalAlignment =
                OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

            rangoLogo.Style.VerticalAlignment =
                OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

            AplicarBordes(rangoLogo);

            var picture = ws.Drawings.AddPicture(
                "Logo",
                new FileInfo(logoPath)
            );

            using (var img = System.Drawing.Image.FromFile(logoPath))
            {
                double anchoCelda = ws.Column(colLogo).Width * 7;

                double altoCelda =
                    ws.Row(1).Height +
                    ws.Row(2).Height +
                    ws.Row(3).Height +
                    ws.Row(4).Height +
                    ws.Row(5).Height +
                    ws.Row(6).Height;

                double ratioX = anchoCelda / img.Width;
                double ratioY = altoCelda / img.Height;

                double ratio = Math.Min(ratioX, ratioY);

                int width = (int)(img.Width * ratio);
                int height = (int)(img.Height * ratio);

                picture.SetSize(width, height);

                int offsetX = (int)((anchoCelda - width) / 2);
                int offsetY = (int)((altoCelda - height) / 2);

                picture.SetPosition(0, offsetY, colLogo - 1, offsetX);
            }
        }

        private void AplicarBordes(ExcelRange range)
        {
            var border = range.Style.Border;

            border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

            range.Style.HorizontalAlignment =
                OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

            range.Style.VerticalAlignment =
                OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
        }
    }

}
