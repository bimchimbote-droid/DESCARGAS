using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA EMERGENTE 3 (EXPORTAR TABLAS)
    // =====================================
    public class ExportarTablasForm : WinForms.Form
    {
        public string FolderPath { get; private set; }
        public string LogoPath { get; private set; }

        public string Activo => txtActivo.Text;
        public string Codigo => txtCodigo.Text;
        public string Especialidad => txtEspecialidad.Text;
        public bool ExportarPDF => chkPDF.Checked;
        public bool AjustarTablasAlAnchoMaximo => chkAjustarAncho.Checked;

        public List<string> TablasSeleccionadasIds
        {
            get
            {
                return todasLasTablas
                    .Where(x => idsSeleccionados.Contains(x.UniqueId))
                    .Select(x => x.UniqueId)
                    .ToList();
            }
        }

        WinForms.TextBox txtRuta;
        WinForms.TextBox txtActivo;
        WinForms.TextBox txtCodigo;
        WinForms.TextBox txtEspecialidad;
        WinForms.TextBox txtLogo;
        WinForms.TextBox txtBuscarTabla;

        WinForms.Button btnBuscar;
        WinForms.Button btnBuscarLogo;
        WinForms.Button btnEjecutar;
        WinForms.Button btnSeleccionarTodo;
        WinForms.Button btnDeseleccionarTodo;

        WinForms.CheckBox chkPDF;
        WinForms.CheckBox chkAjustarAncho;
        WinForms.ListView chkListaTablas;

        private List<TablaItem> todasLasTablas = new List<TablaItem>();
        private HashSet<string> idsSeleccionados = new HashSet<string>();

        private bool actualizandoChecks = false;
        private bool aplicarCheckMultiple = false;
        private List<WinForms.ListViewItem> itemsParaCheckMultiple = new List<WinForms.ListViewItem>();

        private class TablaItem
        {
            public string Name { get; set; }
            public string UniqueId { get; set; }

            public override string ToString()
            {
                return Name;
            }
        }

        public ExportarTablasForm(Document doc)
        {
            this.Text = "📤 Exportar Tablas";
            this.Width = 500;
            this.Height = 790;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.White;
            this.Font = new Drawing.Font("Segoe UI", 9F);

            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 10,
                Width = 430,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            // ===== CARPETA =====
            var lblRuta = new WinForms.Label()
            {
                Text = "01. CARPETA DE DESTINO",
                Left = 20,
                Top = 40,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtRuta = new WinForms.TextBox()
            {
                Left = 20,
                Top = 65,
                Width = 320,
                ReadOnly = true,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };

            btnBuscar = CrearBotonSecundario(350, 63);
            btnBuscar.Click += BtnBuscar_Click;

            // ===== ACTIVO =====
            var lblActivo = new WinForms.Label()
            {
                Text = "02. NOMBRE DEL ACTIVO",
                Left = 20,
                Top = 105,
                Width = 220,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtActivo = CrearTextBox(20, 130);

            // ===== CODIGO =====
            var lblCodigo = new WinForms.Label()
            {
                Text = "03. CÓDIGO",
                Left = 250,
                Top = 105,
                Width = 200,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtCodigo = CrearTextBox(250, 130);

            // ===== ESPECIALIDAD =====
            var lblEspecialidad = new WinForms.Label()
            {
                Text = "04. ESPECIALIDAD",
                Left = 20,
                Top = 170,
                Width = 200,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtEspecialidad = new WinForms.TextBox()
            {
                Left = 20,
                Top = 195,
                Width = 430,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };

            // ===== LOGO =====
            var lblLogo = new WinForms.Label()
            {
                Text = "05. LOGO (PNG / JPG)",
                Left = 20,
                Top = 235,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtLogo = new WinForms.TextBox()
            {
                Left = 20,
                Top = 260,
                Width = 320,
                ReadOnly = true,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };

            btnBuscarLogo = CrearBotonSecundario(350, 258);
            btnBuscarLogo.Click += BtnBuscarLogo_Click;

            // ===== CHECK PDF =====
            chkPDF = new WinForms.CheckBox()
            {
                Text = "Exportar también en PDF",
                Left = 20,
                Top = 295,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(60, 60, 60)
            };

            // ===== CHECK AJUSTAR TABLAS AL ANCHO MAXIMO =====
            chkAjustarAncho = new WinForms.CheckBox()
            {
                Text = "Ajustar todas las tablas al ancho máximo",
                Left = 20,
                Top = 320,
                Width = 360,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(60, 60, 60)
            };

            // ===== TABLAS DE PLANIFICACION =====
            var lblTablas = new WinForms.Label()
            {
                Text = "06. TABLAS DE PLANIFICACIÓN A EXPORTAR",
                Left = 20,
                Top = 365,
                Width = 430,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtBuscarTabla = new WinForms.TextBox()
            {
                Left = 20,
                Top = 390,
                Width = 430,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };

            txtBuscarTabla.TextChanged += TxtBuscarTabla_TextChanged;

            btnSeleccionarTodo = new WinForms.Button()
            {
                Text = "Seleccionar todo",
                Left = 20,
                Top = 425,
                Width = 210,
                Height = 30,
                BackColor = Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarTodo.FlatAppearance.BorderSize = 1;
            btnSeleccionarTodo.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);
            btnSeleccionarTodo.Click += BtnSeleccionarTodo_Click;

            btnDeseleccionarTodo = new WinForms.Button()
            {
                Text = "Deseleccionar todo",
                Left = 240,
                Top = 425,
                Width = 210,
                Height = 30,
                BackColor = Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };

            btnDeseleccionarTodo.FlatAppearance.BorderSize = 1;
            btnDeseleccionarTodo.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);
            btnDeseleccionarTodo.Click += BtnDeseleccionarTodo_Click;

            chkListaTablas = new WinForms.ListView()
            {
                Left = 20,
                Top = 465,
                Width = 430,
                Height = 180,
                CheckBoxes = true,
                FullRowSelect = true,
                MultiSelect = true,
                View = WinForms.View.Details,
                HeaderStyle = WinForms.ColumnHeaderStyle.None,
                HideSelection = false,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250),
                Font = new Drawing.Font("Segoe UI", 8.5F)
            };

            chkListaTablas.Columns.Add("Tabla", 405);

            chkListaTablas.ItemChecked += ChkListaTablas_ItemChecked;
            chkListaTablas.MouseDown += ChkListaTablas_MouseDown;

            // ===== LINEA =====
            var linea = new WinForms.Label()
            {
                Left = 20,
                Top = 665,
                Width = 430,
                Height = 1,
                BackColor = Drawing.Color.FromArgb(220, 220, 220)
            };

            // ===== BOTON EJECUTAR =====
            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Left = 20,
                Top = 685,
                Width = 430,
                Height = 40,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;

            btnEjecutar.MouseEnter += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.MouseLeave += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 120, 215);
            btnEjecutar.MouseDown += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 80, 160);
            btnEjecutar.MouseUp += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 100, 190);

            btnEjecutar.Click += BtnEjecutar_Click;
            this.AcceptButton = btnEjecutar;

            // ===== CONTROLES =====
            Controls.Add(lblAutor);
            Controls.Add(lblRuta);
            Controls.Add(txtRuta);
            Controls.Add(btnBuscar);
            Controls.Add(lblActivo);
            Controls.Add(txtActivo);
            Controls.Add(lblCodigo);
            Controls.Add(txtCodigo);
            Controls.Add(lblEspecialidad);
            Controls.Add(txtEspecialidad);
            Controls.Add(lblLogo);
            Controls.Add(txtLogo);
            Controls.Add(btnBuscarLogo);
            Controls.Add(chkPDF);
            Controls.Add(chkAjustarAncho);
            Controls.Add(lblTablas);
            Controls.Add(txtBuscarTabla);
            Controls.Add(btnSeleccionarTodo);
            Controls.Add(btnDeseleccionarTodo);
            Controls.Add(chkListaTablas);
            Controls.Add(linea);
            Controls.Add(btnEjecutar);

            // ===== SETTINGS =====
            if (!string.IsNullOrEmpty(MYG.Properties.Settings.Default.V3LastFolderPath))
            {
                FolderPath = MYG.Properties.Settings.Default.V3LastFolderPath;
                txtRuta.Text = FolderPath;
            }

            txtActivo.Text = MYG.Properties.Settings.Default.V3LastActivo;
            txtCodigo.Text = MYG.Properties.Settings.Default.V3LastCodigo;
            txtEspecialidad.Text = MYG.Properties.Settings.Default.V3LastEspecialidad;

            if (!string.IsNullOrEmpty(MYG.Properties.Settings.Default.V3LastLogoPath))
            {
                LogoPath = MYG.Properties.Settings.Default.V3LastLogoPath;
                txtLogo.Text = LogoPath;
            }

            CargarTablasDelProyecto(doc);
            CargarListaFiltrada("");
        }

        // ===== METODOS VISUALES =====

        private WinForms.TextBox CrearTextBox(int left, int top)
        {
            return new WinForms.TextBox()
            {
                Left = left,
                Top = top,
                Width = 200,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.FromArgb(250, 250, 250)
            };
        }

        private WinForms.Button CrearBotonSecundario(int left, int top)
        {
            var btn = new WinForms.Button()
            {
                Text = "Examinar",
                Left = left,
                Top = top,
                Width = 100,
                Height = 28,
                BackColor = Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);

            btn.MouseEnter += (s, e) => btn.BackColor = Drawing.Color.FromArgb(225, 225, 225);
            btn.MouseLeave += (s, e) => btn.BackColor = Drawing.Color.FromArgb(240, 240, 240);
            btn.MouseDown += (s, e) => btn.BackColor = Drawing.Color.FromArgb(210, 210, 210);
            btn.MouseUp += (s, e) => btn.BackColor = Drawing.Color.FromArgb(225, 225, 225);

            return btn;
        }

        // ===== CARGA DE TABLAS =====

        private void CargarTablasDelProyecto(Document doc)
        {
            todasLasTablas = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSchedule))
                .Cast<ViewSchedule>()
                .Where(x => !x.IsTemplate)
                .OrderBy(x => x.Name)
                .Select(x => new TablaItem()
                {
                    Name = x.Name,
                    UniqueId = x.UniqueId
                })
                .ToList();

            idsSeleccionados = new HashSet<string>(
                todasLasTablas.Select(x => x.UniqueId)
            );
        }

        private void CargarListaFiltrada(string filtro)
        {
            string texto = filtro == null ? "" : filtro.Trim().ToLower();

            var lista = todasLasTablas
                .Where(x =>
                    string.IsNullOrEmpty(texto) ||
                    x.Name.ToLower().Contains(texto))
                .ToList();

            actualizandoChecks = true;

            chkListaTablas.BeginUpdate();
            chkListaTablas.Items.Clear();

            foreach (var item in lista)
            {
                WinForms.ListViewItem lvi = new WinForms.ListViewItem(item.Name);
                lvi.Tag = item;
                lvi.Checked = idsSeleccionados.Contains(item.UniqueId);

                chkListaTablas.Items.Add(lvi);
            }

            chkListaTablas.EndUpdate();

            actualizandoChecks = false;
        }

        // ===== EVENTOS =====

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            var dialog = new WinForms.FolderBrowserDialog();

            if (dialog.ShowDialog() == WinForms.DialogResult.OK)
            {
                FolderPath = dialog.SelectedPath;
                txtRuta.Text = FolderPath;
            }
        }

        private void BtnBuscarLogo_Click(object sender, EventArgs e)
        {
            var dialog = new WinForms.OpenFileDialog();
            dialog.Title = "Seleccionar logo";
            dialog.Filter = "Imagen (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg";

            if (dialog.ShowDialog() == WinForms.DialogResult.OK)
            {
                LogoPath = dialog.FileName;
                txtLogo.Text = LogoPath;
            }
        }

        private void TxtBuscarTabla_TextChanged(object sender, EventArgs e)
        {
            CargarListaFiltrada(txtBuscarTabla.Text);
        }

        private void ChkListaTablas_MouseDown(object sender, WinForms.MouseEventArgs e)
        {
            WinForms.ListViewHitTestInfo hit = chkListaTablas.HitTest(e.Location);

            if (hit == null || hit.Item == null) return;

            bool clicEnCheck =
                (hit.Location & WinForms.ListViewHitTestLocations.StateImage)
                == WinForms.ListViewHitTestLocations.StateImage;

            if (!clicEnCheck) return;

            aplicarCheckMultiple = false;
            itemsParaCheckMultiple.Clear();

            if (chkListaTablas.SelectedItems.Count <= 1) return;

            foreach (WinForms.ListViewItem itemSeleccionado in chkListaTablas.SelectedItems)
            {
                itemsParaCheckMultiple.Add(itemSeleccionado);
            }

            if (!itemsParaCheckMultiple.Contains(hit.Item))
            {
                itemsParaCheckMultiple.Add(hit.Item);
            }

            aplicarCheckMultiple = true;
        }

        private void ChkListaTablas_ItemChecked(object sender, WinForms.ItemCheckedEventArgs e)
        {
            if (actualizandoChecks) return;

            TablaItem item = e.Item.Tag as TablaItem;

            if (item == null) return;

            ActualizarEstadoTabla(item, e.Item.Checked);

            if (!aplicarCheckMultiple) return;

            bool nuevoEstado = e.Item.Checked;

            // Se ejecuta después de que el ListView termine su cambio interno de check.
            this.BeginInvoke(new Action(() =>
            {
                actualizandoChecks = true;

                foreach (WinForms.ListViewItem itemSeleccionado in itemsParaCheckMultiple)
                {
                    if (itemSeleccionado == null) continue;

                    itemSeleccionado.Checked = nuevoEstado;

                    TablaItem tabla = itemSeleccionado.Tag as TablaItem;

                    if (tabla == null) continue;

                    ActualizarEstadoTabla(tabla, nuevoEstado);
                }

                // Refuerza también el elemento donde hiciste clic.
                e.Item.Checked = nuevoEstado;
                ActualizarEstadoTabla(item, nuevoEstado);

                actualizandoChecks = false;

                aplicarCheckMultiple = false;
                itemsParaCheckMultiple.Clear();
            }));
        }

        private void ActualizarEstadoTabla(TablaItem item, bool seleccionado)
        {
            if (item == null) return;

            if (seleccionado)
            {
                if (!idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Add(item.UniqueId);
            }
            else
            {
                if (idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Remove(item.UniqueId);
            }
        }

        private void BtnSeleccionarTodo_Click(object sender, EventArgs e)
        {
            actualizandoChecks = true;

            chkListaTablas.BeginUpdate();

            foreach (WinForms.ListViewItem lvi in chkListaTablas.Items)
            {
                TablaItem item = lvi.Tag as TablaItem;

                if (item == null) continue;

                ActualizarEstadoTabla(item, true);
                lvi.Checked = true;
            }

            chkListaTablas.EndUpdate();

            actualizandoChecks = false;
        }

        private void BtnDeseleccionarTodo_Click(object sender, EventArgs e)
        {
            // Deselecciona TODAS las tablas del proyecto,
            // incluso las que no están visibles por el filtro.
            idsSeleccionados.Clear();

            actualizandoChecks = true;

            chkListaTablas.BeginUpdate();

            foreach (WinForms.ListViewItem lvi in chkListaTablas.Items)
            {
                lvi.Checked = false;
            }

            chkListaTablas.EndUpdate();

            actualizandoChecks = false;
        }

        private void BtnEjecutar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FolderPath) ||
                string.IsNullOrWhiteSpace(txtActivo.Text) ||
                string.IsNullOrWhiteSpace(txtCodigo.Text) ||
                string.IsNullOrWhiteSpace(txtEspecialidad.Text))
            {
                WinForms.MessageBox.Show("Complete todos los campos");
                return;
            }

            if (TablasSeleccionadasIds.Count == 0)
            {
                WinForms.MessageBox.Show("Seleccione al menos una tabla de planificación para exportar");
                return;
            }

            MYG.Properties.Settings.Default.V3LastFolderPath = FolderPath;
            MYG.Properties.Settings.Default.V3LastActivo = txtActivo.Text;
            MYG.Properties.Settings.Default.V3LastCodigo = txtCodigo.Text;
            MYG.Properties.Settings.Default.V3LastEspecialidad = txtEspecialidad.Text;
            MYG.Properties.Settings.Default.V3LastLogoPath = LogoPath ?? "";

            MYG.Properties.Settings.Default.Save();

            this.DialogResult = WinForms.DialogResult.OK;
        }
    }

}
