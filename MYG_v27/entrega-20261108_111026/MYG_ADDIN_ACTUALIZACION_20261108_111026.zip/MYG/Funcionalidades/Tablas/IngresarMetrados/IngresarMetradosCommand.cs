using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ===============================
    // COMANDO 2 (INGRESAR METRADOS)
    // MODIFICADO: USA TABLAS SELECCIONADAS
    // ===============================
    [Transaction(TransactionMode.Manual)]
    public class IngresarMetradosCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            var form = new IngresarMetradosForm(doc);

            if (form.ShowDialog() != WinForms.DialogResult.OK)
                return Result.Cancelled;

            string excelPath = form.ExcelPath;
            string sheetName = form.SheetName;
            string blockName = form.BlockName;
            List<string> tablasSeleccionadasIds = form.TablasSeleccionadasIds;

            var lista = ObtenerPartidasYMetrados(
                doc,
                tablasSeleccionadasIds);

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage(new FileInfo(excelPath)))
            {
                var ws = package.Workbook.Worksheets[sheetName];

                if (ws == null)
                {
                    TaskDialog.Show(
                        "Ingresar Metrados",
                        "No se encontró la hoja '" + sheetName + "' en el archivo Excel.");

                    return Result.Cancelled;
                }

                if (ws.Dimension == null)
                {
                    TaskDialog.Show(
                        "Ingresar Metrados",
                        "La hoja seleccionada no contiene información.");

                    return Result.Cancelled;
                }

                int colBloque = -1;

                for (int c = 1; c <= ws.Dimension.End.Column; c++)
                {
                    if (ws.Cells[6, c].Text.Trim().ToUpper()
                        == blockName.ToUpper())
                    {
                        colBloque = c;
                        break;
                    }
                }

                if (colBloque == -1)
                {
                    TaskDialog.Show(
                        "Ingresar Metrados",
                        "No se encontró el activo '" + blockName + "' en la fila 6 del Excel.");

                    return Result.Cancelled;
                }

                var dic = lista
                    .GroupBy(
                        x => ObtenerCodigoItem(x.Item1),
                        StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(
                        g => g.Key,
                        g => g.Last().Item2,
                        StringComparer.OrdinalIgnoreCase);

                int actualizados = 0;

                for (int r = 7; r <= ws.Dimension.End.Row; r++)
                {
                    string item = ws.Cells[r, 16].Text.Trim();

                    if (dic.ContainsKey(item))
                    {
                        ws.Cells[r, colBloque].Value = dic[item];
                        actualizados++;
                    }
                }

                package.Save();

                TaskDialog.Show(
                    "Resultado",
                    actualizados + " items actualizados");
            }

            return Result.Succeeded;
        }

        private List<Tuple<string, double>> ObtenerPartidasYMetrados(
            Document doc,
            List<string> tablasSeleccionadasIds)
        {
            var lista = new List<Tuple<string, double>>();

            if (tablasSeleccionadasIds == null ||
                tablasSeleccionadasIds.Count == 0)
            {
                return lista;
            }

            foreach (string uniqueId in tablasSeleccionadasIds)
            {
                ViewSchedule sched = doc.GetElement(uniqueId) as ViewSchedule;

                if (sched == null) continue;
                if (sched.IsTemplate) continue;

                double metrado = 0;

                try
                {
                    var body = sched.GetTableData()
                        .GetSectionData(SectionType.Body);

                    if (body == null) continue;
                    if (body.NumberOfRows <= 0) continue;
                    if (body.NumberOfColumns <= 0) continue;

                    int lastRow = body.NumberOfRows - 1;
                    int lastCol = body.NumberOfColumns - 1;

                    string txt = sched.GetCellText(
                        SectionType.Body,
                        lastRow,
                        lastCol);

                    metrado = ConvertirTextoADouble(txt);
                }
                catch
                {
                    metrado = 0;
                }

                lista.Add(
                    new Tuple<string, double>(
                        sched.Name,
                        metrado));
            }

            return lista;
        }

        private double ConvertirTextoADouble(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return 0;

            string limpio = texto
                .Replace("Total general:", "")
                .Replace("TOTAL GENERAL:", "")
                .Trim();

            System.Text.RegularExpressions.Match match =
                System.Text.RegularExpressions.Regex.Match(
                    limpio,
                    @"-?\d+(?:[.,]\d+)?");

            if (!match.Success)
                return 0;

            string numero = match.Value.Replace(",", ".");

            double valor = 0;

            double.TryParse(
                numero,
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor);

            return valor;
        }

        private string ObtenerCodigoItem(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                return "";

            nombre = nombre.Trim();

            if (nombre.Contains(" "))
                return nombre.Split(' ')[0];

            return nombre;
        }
    }

}
