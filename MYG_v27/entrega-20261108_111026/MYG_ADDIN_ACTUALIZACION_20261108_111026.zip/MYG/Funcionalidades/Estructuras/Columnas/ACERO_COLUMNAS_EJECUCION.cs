﻿// ==========================================
// ÚNICO HANDLER EXTERNO 3.9 - DOBLECES LIBRES Y FINALIZACION SILENCIOSA
// SELECCIÓN + ANÁLISIS + LONGITUDINALES + ESTRIBOS
// REVIT 2027 - CIRCULARES SOLAPADOS + GANCHOS 90° INTERIORES
// ==========================================
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

public enum AceroColumnaAccion
{
    Ninguna,
    Seleccionar,
    Crear
}

public class AceroColumnaSelectionFilter : ISelectionFilter
{
    public bool AllowElement(Element elem)
    {
        if (elem == null || elem.Category == null)
            return false;

        if (elem.Category.Id.Value !=
            (long)BuiltInCategory.OST_StructuralColumns)
        {
            return false;
        }

        FamilyInstance columna = elem as FamilyInstance;

        if (columna == null)
            return false;

        try
        {
            return RebarHostData.GetRebarHostData(columna) != null;
        }
        catch
        {
            return false;
        }
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        return false;
    }
}

public class AceroColumnaHandler : IExternalEventHandler
{
    // Manejo local a las transacciones de este comando. No registra
    // manejadores globales ni confirma automaticamente "Suprimir armadura".
    private sealed class SuprimirAdvertenciasNoCriticas : IFailuresPreprocessor
    {
        public readonly List<string> Errores = new List<string>();
        public readonly List<string> Advertencias = new List<string>();

        public FailureProcessingResult PreprocessFailures(
            FailuresAccessor failuresAccessor)
        {
            bool cancelar = false;
            foreach (FailureMessageAccessor mensaje in
                failuresAccessor.GetFailureMessages())
            {
                if (mensaje == null)
                    continue;
                FailureSeverity gravedad = mensaje.GetSeverity();
                if (gravedad == FailureSeverity.None)
                    continue;
                string detalle = mensaje.GetDescriptionText();
                ICollection<ElementId> ids = mensaje.GetFailingElementIds();
                if (ids != null && ids.Count > 0)
                    detalle += " | IDs: " + string.Join(", ",
                        ids.Select(id => id.Value.ToString()));
                if (gravedad == FailureSeverity.Warning)
                {
                    if (!Advertencias.Contains(detalle))
                        Advertencias.Add(detalle);
                    failuresAccessor.DeleteWarning(mensaje);
                }
                else
                {
                    if (!Errores.Contains(detalle))
                        Errores.Add(detalle);
                    cancelar = true;
                }
            }
            // Un error no se puede convertir en exito ocultando su ventana.
            // SetClearAfterRollback permite revertir el grupo sin dialogos.
            return cancelar
                ? FailureProcessingResult.ProceedWithRollBack
                : FailureProcessingResult.Continue;
        }
    }

    private SuprimirAdvertenciasNoCriticas ConfigurarManejoSilenciosoDeAdvertencias(
        Transaction transaccion)
    {
        var manejador = new SuprimirAdvertenciasNoCriticas();
        FailureHandlingOptions opciones = transaccion.GetFailureHandlingOptions();
        opciones.SetFailuresPreprocessor(manejador);
        opciones.SetClearAfterRollback(true);
        transaccion.SetFailureHandlingOptions(opciones);
        return manejador;
    }

    public string UltimoInformeCreacion { get; private set; } = "";
    public string RutaUltimoInformeCreacion { get; private set; } = "";

    private void GuardarInformeCreacionSilenciosoMYG(string texto)
    {
        UltimoInformeCreacion = texto ?? "";
        RutaUltimoInformeCreacion = "";
        try
        {
            string carpeta = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MYG", "Registros");
            System.IO.Directory.CreateDirectory(carpeta);
            string ruta = System.IO.Path.Combine(carpeta, "UltimaCreacionAceroColumnas.txt");
            System.IO.File.WriteAllText(ruta, UltimoInformeCreacion,
                new System.Text.UTF8Encoding(true));
            RutaUltimoInformeCreacion = ruta;
        }
        catch (Exception ex)
        {
            // El detalle permanece accesible en memoria si no se puede escribir.
            UltimoInformeCreacion += Environment.NewLine +
                "No se pudo guardar el registro: " + ex.Message;
        }
    }
    public UIDocument UiDoc;
    public AceroColumnaForm Form;

    public AceroColumnaAccion Accion =
        AceroColumnaAccion.Ninguna;

    internal AceroColumnaConfiguracion ConfiguracionPendiente;

    public List<ElementId> ColumnasSeleccionadas =
        new List<ElementId>();

    private const double Tol = 1e-7;
    private const double TolGeometria = 1e-5;

    // Indica si en la ventana se crearon regiones gráficas de elemento de borde.
    // Solo en ese caso los estribos y longitudinales reciben esa denominación.
    private bool tieneElementosBordeActualMYG = false;

    // Guarda el último fallo real de Revit para mostrar un diagnóstico útil
    // cuando ninguna barra de una columna pudo crearse.
    private string ultimoErrorCreacion = "";

    // Forma recta validada por cada tipo de barra. Se guarda únicamente una
    // RebarShape cuyo parámetro "Longitud de barra" y cuya geometría central
    // hayan sido comprobados después de regenerar el documento. De esta forma
    // no se reutiliza una forma 00 defectuosa que muestre A correctamente pero
    // deje REBAR_ELEM_LENGTH y REBAR_ELEM_TOTAL_LENGTH en cero.
    private readonly Dictionary<long, ElementId>
        formasRectasLongitudinalesValidas =
        new Dictionary<long, ElementId>();

    private class PuntoLocal
    {
        public double X;
        public double Y;

        public PuntoLocal()
        {
        }

        public PuntoLocal(double x, double y)
        {
            X = x;
            Y = y;
        }

        public PuntoLocal Copiar()
        {
            return new PuntoLocal(X, Y);
        }
    }

    private class PosicionLongitudinalTipada
    {
        public PuntoLocal Punto;
        public RebarBarType Tipo;
    }

    private class GrupoLongitudinalPreparado
    {
        public AceroColumnaGrupoLongitudinal2D Definicion;
        public PuntoLocal Inicio;
        public PuntoLocal Fin;
        public RebarBarType Tipo;
        public List<PuntoLocal> Centros = new List<PuntoLocal>();
    }

    private class ResultadoTramoEmpalmeLongitudinal
    {
        public Rebar Rebar;
        public double EstacionFin;
        public double LongitudReal;
    }

    private class RectanguloLocal
    {
        public double MinX;
        public double MaxX;
        public double MinY;
        public double MaxY;

        public double Ancho
        {
            get { return MaxX - MinX; }
        }

        public double Alto
        {
            get { return MaxY - MinY; }
        }
    }

    private class DatosColumna
    {
        public FamilyInstance Columna;
        public XYZ Origen;
        public XYZ EjeX;
        public XYZ EjeY;
        public double ZInferior;
        public double ZSuperior;
        // Contorno principal conservado por compatibilidad con la lógica
        // histórica. Siempre corresponde a la región de mayor área.
        public List<PuntoLocal> Contorno = new List<PuntoLocal>();

        // Una familia de columna puede estar formada por varios sólidos
        // desconectados en planta. Cada región se conserva como un polígono
        // independiente para no crear diagonales ficticias entre sólidos.
        public List<List<PuntoLocal>> Contornos =
            new List<List<PuntoLocal>>();

        public List<Solid> Solidos = new List<Solid>();
    }

    // Agrupa columnas que pertenecen al mismo eje vertical. Los longitudinales
    // se crean una sola vez, usando como host la columna inferior y extendiendo
    // la barra desde la base del primer tramo hasta la coronación del último.
    // Los estribos se siguen creando por cada anfitrión porque cada conjunto
    // debe conservar su propia zona, separación y host de Revit.
    private class GrupoColumnasVerticales
    {
        public List<DatosColumna> Tramos = new List<DatosColumna>();

        public double ZInferior
        {
            get
            {
                return Tramos.Count == 0
                    ? 0.0
                    : Tramos.Min(x => x.ZInferior);
            }
        }

        public double ZSuperior
        {
            get
            {
                return Tramos.Count == 0
                    ? 0.0
                    : Tramos.Max(x => x.ZSuperior);
            }
        }

        public DatosColumna TramoInferior
        {
            get
            {
                return Tramos
                    .OrderBy(x => x.ZInferior)
                    .ThenBy(x => x.ZSuperior)
                    .FirstOrDefault();
            }
        }

        public DatosColumna TramoSuperior
        {
            get
            {
                return Tramos
                    .OrderByDescending(x => x.ZSuperior)
                    .ThenByDescending(x => x.ZInferior)
                    .FirstOrDefault();
            }
        }
    }

    // Intervalo vertical permitido para ubicar un empalme longitudinal.
    // Inicio y Fin se guardan primero como cotas Z absolutas y, antes de crear
    // las barras, se convierten en estaciones medidas desde la base real del
    // grupo vertical (incluido el anclaje inferior).
    private class ZonaEmpalmeLongitudinal
    {
        public double Inicio;
        public double Fin;
        public long ColumnaId;
        public string Etiqueta;
    }

    private class ResultadoColumna
    {
        public int Longitudinales;
        public int ConjuntosEstribos;
        public List<ElementId> Ids = new List<ElementId>();
        public List<string> Errores = new List<string>();

        public int Total
        {
            get { return Longitudinales + ConjuntosEstribos; }
        }
    }

    private class IntervaloVerticalNodo
    {
        public double Inicio;
        public double Fin;
        public string Nombre;
    }

    private class ZonaEstribos
    {
        public double Inicio;
        public double Fin;
        public double Espaciamiento;
        public int Cantidad;
        public bool UsarCantidadExacta;

        // En las zonas RESTO el rango se mide entre los últimos estribos de
        // las zonas extremas. Esos dos estribos ya existen, por lo que el
        // conjunto RESTO debe conservar la regla ESPACIADO MÁXIMO pero sin
        // volver a materializar las barras de inicio y fin.
        public bool OmitirPrimeraBarra;
        public bool OmitirUltimaBarra;

        public string Nombre;
    }

    private class PerfilEstriboPreparado
    {
        public List<Curve> Curvas = new List<Curve>();
        public List<PuntoLocal> PoligonoOriginal = new List<PuntoLocal>();
        public List<PuntoLocal> CadenaLocal = new List<PuntoLocal>();
        public DatosColumna Datos;
        public double Elevacion;
        public RebarTerminationOrientation OrientacionInicio =
            RebarTerminationOrientation.Right;
        public RebarTerminationOrientation OrientacionFin =
            RebarTerminationOrientation.Left;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
            return;

        try
        {
            if (Accion == AceroColumnaAccion.Seleccionar)
            {
                SeleccionarColumnas(uidoc);
            }
            else if (Accion == AceroColumnaAccion.Crear)
            {
                CrearAcero(uidoc);
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            Form?.ActualizarEstado("Selección cancelada.");
            Form?.MostrarDespuesSeleccion();
        }
        catch (Exception ex)
        {
            Form?.MostrarDespuesSeleccion();
            Form?.ActualizarEstado("Se produjo un error.");

            TaskDialog.Show(
                "MYG",
                "Se produjo un error:\n\n" + ex.Message);
        }
        finally
        {
            Accion = AceroColumnaAccion.Ninguna;
            Form?.EstablecerBotonesActivos(true);
        }
    }

    private void SeleccionarColumnas(UIDocument uidoc)
    {
        if (Form == null || Form.IsDisposed)
            return;

        Form.ActualizarEstado(
            "Seleccione columnas estructurales y pulse Finalizar.");

        IList<Reference> referencias =
            uidoc.Selection.PickObjects(
                ObjectType.Element,
                new AceroColumnaSelectionFilter(),
                "Seleccione columnas estructurales de concreto");

        List<ElementId> nuevosIds = new List<ElementId>();

        foreach (Reference referencia in referencias)
        {
            if (referencia == null)
                continue;

            ElementId id = referencia.ElementId;

            if (id == null || id == ElementId.InvalidElementId)
                continue;

            if (!nuevosIds.Contains(id))
                nuevosIds.Add(id);
        }

        ColumnasSeleccionadas.Clear();
        ColumnasSeleccionadas.AddRange(nuevosIds);

        uidoc.Selection.SetElementIds(ColumnasSeleccionadas);

        Document doc = uidoc.Document;
        AceroColumnaVistaSeccion vista = null;
        List<string> descripciones = new List<string>();

        foreach (ElementId id in ColumnasSeleccionadas)
        {
            FamilyInstance columna = doc.GetElement(id) as FamilyInstance;

            if (columna == null)
                continue;

            descripciones.Add(DescribirColumna(doc, columna));

            if (vista == null)
            {
                DatosColumna datos = ObtenerDatosColumna(columna);

                if (datos != null)
                    vista = CrearVistaSeccion(datos);
            }
        }

        Form.ActualizarSeleccion(
            vista,
            descripciones,
            ColumnasSeleccionadas.Count);

        Form.ActualizarEstado(
            ColumnasSeleccionadas.Count > 0
                ? "Selección completada. La sección inicia limpia, sin longitudinales ni estribos."
                : "No se seleccionaron columnas.");

        Form.MostrarDespuesSeleccion();
    }

    private void CrearAcero(UIDocument uidoc)
    {
        Document doc = uidoc.Document;

        // Los ElementId de forma pertenecen al documento activo y solo deben
        // reutilizarse dentro de esta ejecución.
        formasRectasLongitudinalesValidas.Clear();

        if (Form == null || Form.IsDisposed)
            return;

        if (ColumnasSeleccionadas == null ||
            ColumnasSeleccionadas.Count == 0)
        {
            TaskDialog.Show(
                "MYG",
                "Primero debe pulsar SELECCIONAR COLUMNAS y seleccionar " +
                "una o más columnas estructurales.");
            return;
        }

        AceroColumnaConfiguracion configuracion =
            ConfiguracionPendiente;

        if (configuracion == null)
        {
            string error;

            if (!Form.TryObtenerConfiguracion(
                out configuracion,
                out error))
            {
                TaskDialog.Show("MYG", error);
                return;
            }
        }

        // La ventana es la fuente de verdad: si no dibujó regiones de elemento
        // de borde, ninguna barra se etiqueta como "de elemento de borde".
        tieneElementosBordeActualMYG =
            configuracion != null && configuracion.TieneElementosBorde;

        Form.EstablecerBotonesActivos(false);
        Form.ActualizarEstado(
            "Analizando continuidad vertical y creando acero...");

        double recubrimiento = ConvertirCm(configuracion.RecubrimientoCm);
        double separacionMaxima =
            ConvertirCm(configuracion.SeparacionMaximaLongitudinalCm);
        double anclajeInferior =
            ConvertirCm(configuracion.AnclajeInferiorCm);
        double prolongacionSuperior =
            ConvertirCm(configuracion.ProlongacionSuperiorCm);
        double longitudComercialLongitudinal = ConvertirMetros(
            configuracion.LongitudComercialLongitudinalM);
        double longitudEmpalmeLongitudinal = ConvertirMetros(
            configuracion.LongitudEmpalmeLongitudinalM);
        double longitudZonaConfinada =
            ConvertirCm(configuracion.LongitudZonaConfinadaCm);
        double espaciamientoConfinado =
            ConvertirCm(configuracion.EspaciamientoConfinadoCm);
        double espaciamientoCentral =
            ConvertirCm(configuracion.EspaciamientoCentralCm);

        int columnasCorrectas = 0;
        int columnasFallidas = 0;
        int barrasLongitudinales = 0;
        int conjuntosEstribos = 0;
        int gruposVerticalesContinuos = 0;
        List<ElementId> idsCreados = new List<ElementId>();
        List<string> errores = new List<string>();
        List<string> advertenciasRevit = new List<string>();
        UltimoInformeCreacion = "";
        RutaUltimoInformeCreacion = "";

        // Se obtiene la geometría una sola vez para detectar las columnas que
        // realmente están apiladas. Una columna inválida se reporta antes de
        // iniciar las transacciones de creación.
        List<DatosColumna> datosSeleccionados =
            new List<DatosColumna>();

        foreach (ElementId id in ColumnasSeleccionadas)
        {
            FamilyInstance columna =
                doc.GetElement(id) as FamilyInstance;

            if (columna == null)
            {
                columnasFallidas++;
                errores.Add(
                    "ID " + id.Value + ": no es una columna válida.");
                continue;
            }

            DatosColumna datos = ObtenerDatosColumna(columna);

            if (!TieneContornosValidos(datos))
            {
                columnasFallidas++;
                errores.Add(
                    "ID " + id.Value +
                    ": no se pudo obtener una sección válida.");
                continue;
            }

            datosSeleccionados.Add(datos);
        }

        List<GrupoColumnasVerticales> gruposVerticales =
            AgruparColumnasVerticales(datosSeleccionados);

        List<Element> elementosPotencialesNodo =
            ObtenerElementosPotencialesNodo(doc, configuracion);

        gruposVerticalesContinuos = gruposVerticales.Count(x =>
            x != null && x.Tramos.Count > 1);

        using (TransactionGroup grupoGeneral =
            new TransactionGroup(
                doc,
                "MYG - Acero continuo en columnas"))
        {
            grupoGeneral.Start();

            foreach (GrupoColumnasVerticales grupoVertical in gruposVerticales)
            {
                if (grupoVertical == null ||
                    grupoVertical.Tramos == null ||
                    grupoVertical.Tramos.Count == 0)
                {
                    continue;
                }

                List<DatosColumna> tramos = grupoVertical.Tramos
                    .OrderBy(x => x.ZInferior)
                    .ThenBy(x => x.ZSuperior)
                    .ToList();

                List<ZonaEmpalmeLongitudinal> zonasMitadCentralGrupo =
                    ObtenerZonasEmpalmeMitadCentral(tramos);

                // ANFITRIÓN ÚNICO DE LONGITUDINALES:
                // Cada grupo vertical resuelve explícitamente su columna más baja.
                // Todas las piezas longitudinales del grupo (rectas o empalmadas)
                // se crean usando este mismo anfitrión, aunque atraviesen los
                // niveles superiores. Los estribos conservan el host de cada tramo.
                DatosColumna datosAnfitrionLongitudinal =
                    grupoVertical.TramoInferior ?? tramos[0];

                FamilyInstance anfitrionLongitudinalGrupo =
                    datosAnfitrionLongitudinal != null
                        ? datosAnfitrionLongitudinal.Columna
                        : null;

                if (anfitrionLongitudinalGrupo == null ||
                    RebarHostData.GetRebarHostData(
                        anfitrionLongitudinalGrupo) == null)
                {
                    columnasFallidas += tramos.Count;
                    errores.Add(
                        "Grupo vertical: no se pudo determinar una columna " +
                        "inferior válida como anfitrión de los longitudinales.");
                    continue;
                }

                DatosColumna tramoInferior = datosAnfitrionLongitudinal;
                string nombreTransaccion = tramos.Count > 1
                    ? "Acero continuo " +
                      tramoInferior.Columna.Id.Value +
                      " (" + tramos.Count + " tramos)"
                    : "Acero columna " +
                      tramoInferior.Columna.Id.Value;

                using (Transaction transaccion =
                    new Transaction(doc, nombreTransaccion))
                {
                    transaccion.Start();
                    SuprimirAdvertenciasNoCriticas manejoFallos =
                        ConfigurarManejoSilenciosoDeAdvertencias(transaccion);

                    ResultadoColumna resultadoGrupo =
                        new ResultadoColumna();

                    try
                    {
                        for (int i = 0; i < tramos.Count; i++)
                        {
                            DatosColumna datosTramo = tramos[i];

                            // Solo el tramo que coincide con el anfitrión más
                            // bajo crea longitudinales. No se depende del orden
                            // original de selección ni del orden de ElementId.
                            bool crearLongitudinalesEnEsteTramo =
                                datosTramo.Columna.Id ==
                                anfitrionLongitudinalGrupo.Id;

                            // Sincroniza el anfitrión con el tipo de
                            // recubrimiento elegido en la ventana. Se asigna a
                            // Cara superior, Cara inferior y Otras caras.
                            AplicarTipoRecubrimientoRevitAColumna(
                                doc,
                                datosTramo.Columna,
                                configuracion.RecubrimientoTipoId);

                            ResultadoColumna resultadoTramo =
                                CrearAceroEnColumna(
                                    doc,
                                    datosTramo.Columna,
                                    configuracion,
                                    recubrimiento,
                                    separacionMaxima,
                                    anclajeInferior,
                                    prolongacionSuperior,
                                    longitudZonaConfinada,
                                    espaciamientoConfinado,
                                    espaciamientoCentral,
                                    crearLongitudinalesEnEsteTramo,
                                    grupoVertical.ZInferior,
                                    grupoVertical.ZSuperior,
                                    datosTramo,
                                    anfitrionLongitudinalGrupo,
                                    datosAnfitrionLongitudinal,
                                    configuracion.ConsiderarEmpalmesLongitudinales,
                                    configuracion.UbicarEmpalmesMitadCentralE060,
                                    longitudComercialLongitudinal,
                                    longitudEmpalmeLongitudinal,
                                    zonasMitadCentralGrupo,
                                    elementosPotencialesNodo);

                            if (resultadoTramo == null)
                                continue;

                            resultadoGrupo.Longitudinales +=
                                resultadoTramo.Longitudinales;
                            resultadoGrupo.ConjuntosEstribos +=
                                resultadoTramo.ConjuntosEstribos;
                            resultadoGrupo.Ids.AddRange(resultadoTramo.Ids);

                            if (resultadoTramo.Errores.Count > 0)
                            {
                                resultadoGrupo.Errores.AddRange(
                                    resultadoTramo.Errores.Select(x =>
                                        "ID " +
                                        datosTramo.Columna.Id.Value +
                                        ": " + x));
                            }
                        }

                        if (resultadoGrupo.Total > 0)
                        {
                            TransactionStatus estadoCommit = transaccion.Commit();
                            advertenciasRevit.AddRange(manejoFallos.Advertencias.Select(
                                x => nombreTransaccion + ": " + x));
                            if (estadoCommit != TransactionStatus.Committed)
                            {
                                columnasFallidas += tramos.Count;
                                errores.AddRange(resultadoGrupo.Errores);
                                errores.Add(nombreTransaccion +
                                    ": grupo NO guardado; estado " + estadoCommit + ". " +
                                    string.Join(" | ", manejoFallos.Errores));
                                continue;
                            }
                            columnasCorrectas += tramos.Count;
                            barrasLongitudinales +=
                                resultadoGrupo.Longitudinales;
                            conjuntosEstribos +=
                                resultadoGrupo.ConjuntosEstribos;
                            idsCreados.AddRange(resultadoGrupo.Ids);

                            if (resultadoGrupo.Errores.Count > 0)
                                errores.AddRange(resultadoGrupo.Errores);
                        }
                        else
                        {
                            transaccion.RollBack();
                            columnasFallidas += tramos.Count;

                            string idsGrupo = string.Join(
                                ", ",
                                tramos.Select(x =>
                                    x.Columna.Id.Value.ToString()));

                            string detalleResultado =
                                resultadoGrupo.Errores.Count > 0
                                ? string.Join(
                                    " | ",
                                    resultadoGrupo.Errores.Take(3))
                                : "no se pudo generar armadura válida.";

                            errores.Add(
                                "Grupo [" + idsGrupo + "]: " +
                                detalleResultado);
                        }
                    }
                    catch (Exception ex)
                    {
                        if (transaccion.GetStatus() == TransactionStatus.Started)
                            transaccion.RollBack();
                        errores.AddRange(manejoFallos.Errores.Select(
                            x => nombreTransaccion + ": " + x));
                        columnasFallidas += tramos.Count;

                        string idsGrupo = string.Join(
                            ", ",
                            tramos.Select(x =>
                                x.Columna.Id.Value.ToString()));

                        errores.Add(
                            "Grupo [" + idsGrupo + "]: " + ex.Message);
                    }
                }
            }

            grupoGeneral.Assimilate();
        }

        ConfiguracionPendiente = null;

        if (idsCreados.Count > 0)
            uidoc.Selection.SetElementIds(idsCreados);

        string resumen =
            "Creados: " + barrasLongitudinales + " longitudinales y " +
            conjuntosEstribos + " conjuntos de estribos. Incidencias: " +
            errores.Count + ". Columnas sin guardar: " + columnasFallidas + ".";
        string informe = "MYG - Creacion de acero en columnas" + Environment.NewLine +
            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine +
            "Documento: " + doc.Title + Environment.NewLine + resumen + Environment.NewLine +
            "Columnas con armadura guardada (pueden tener incidencias): " + columnasCorrectas +
            Environment.NewLine + Environment.NewLine +
            "INCIDENCIAS DE CREACION:" + Environment.NewLine +
            (errores.Count > 0 ? string.Join(Environment.NewLine, errores) : "Ninguna.") +
            Environment.NewLine + Environment.NewLine +
            "ADVERTENCIAS DE REVIT OMITIDAS:" + Environment.NewLine +
            (advertenciasRevit.Count > 0
                ? string.Join(Environment.NewLine, advertenciasRevit) : "Ninguna.");
        GuardarInformeCreacionSilenciosoMYG(informe);
        // Sin TaskDialog final. Las incidencias siguen visibles y consultables.
        Form.ActualizarEstado(resumen +
            (string.IsNullOrEmpty(RutaUltimoInformeCreacion)
                ? " Registro disponible en UltimoInformeCreacion."
                : " Registro: %LOCALAPPDATA%\\MYG\\Registros."));
    }

    private void AplicarTipoRecubrimientoRevitAColumna(
        Document doc,
        FamilyInstance columna,
        ElementId tipoRecubrimientoId)
    {
        if (doc == null || columna == null ||
            tipoRecubrimientoId == null ||
            tipoRecubrimientoId == ElementId.InvalidElementId)
        {
            return;
        }

        RebarCoverType tipo =
            doc.GetElement(tipoRecubrimientoId) as RebarCoverType;

        if (tipo == null)
            return;

        BuiltInParameter[] parametros = new BuiltInParameter[]
        {
            BuiltInParameter.CLEAR_COVER_TOP,
            BuiltInParameter.CLEAR_COVER_BOTTOM,
            BuiltInParameter.CLEAR_COVER_OTHER
        };

        foreach (BuiltInParameter bip in parametros)
        {
            try
            {
                Parameter p = columna.get_Parameter(bip);

                if (p == null ||
                    p.IsReadOnly ||
                    p.StorageType != StorageType.ElementId)
                {
                    continue;
                }

                ElementId actual = p.AsElementId();

                // Si ya tiene ese recubrimiento no se toca. Si tiene otro,
                // se reemplaza por el seleccionado, exactamente como hacerlo
                // desde Propiedades de Revit.
                if (actual != tipoRecubrimientoId)
                    p.Set(tipoRecubrimientoId);
            }
            catch
            {
                // Algunas familias/categorías pueden no exponer uno de los
                // tres parámetros. Los restantes sí se siguen actualizando.
            }
        }
    }

    private ResultadoColumna CrearAceroEnColumna(
        Document doc,
        FamilyInstance columna,
        AceroColumnaConfiguracion configuracion,
        double recubrimiento,
        double separacionMaxima,
        double anclajeInferior,
        double prolongacionSuperior,
        double longitudZonaConfinada,
        double espaciamientoConfinado,
        double espaciamientoCentral,
        bool crearLongitudinalesEnEsteTramo,
        double zInferiorLongitudinalGrupo,
        double zSuperiorLongitudinalGrupo,
        DatosColumna datosPrecalculados,
        FamilyInstance anfitrionLongitudinalGrupo,
        DatosColumna datosAnfitrionLongitudinalGrupo,
        bool considerarEmpalmesLongitudinales,
        bool ubicarEmpalmesMitadCentralE060,
        double longitudComercialLongitudinal,
        double longitudEmpalmeLongitudinal,
        List<ZonaEmpalmeLongitudinal> zonasMitadCentralGrupo,
        List<Element> elementosPotencialesNodo)
    {
        ultimoErrorCreacion = "";

        if (RebarHostData.GetRebarHostData(columna) == null)
            return null;

        DatosColumna datos = datosPrecalculados ??
            ObtenerDatosColumna(columna);

        if (!TieneContornosValidos(datos))
            return null;

        // El host de estribos sigue siendo 'columna'. Para longitudinales se
        // fuerza el host inferior del grupo y nunca se sustituye por un tramo
        // superior durante la creación de piezas comerciales o empalmes.
        FamilyInstance hostLongitudinal =
            anfitrionLongitudinalGrupo ?? columna;

        DatosColumna datosHostLongitudinal =
            datosAnfitrionLongitudinalGrupo ?? datos;

        if (hostLongitudinal == null ||
            datosHostLongitudinal == null ||
            !TieneContornosValidos(datosHostLongitudinal) ||
            RebarHostData.GetRebarHostData(hostLongitudinal) == null)
        {
            throw new InvalidOperationException(
                "No se pudo resolver el anfitrión inferior del grupo para " +
                "crear los aceros longitudinales.");
        }

        ResultadoColumna resultado = new ResultadoColumna();

        double diametroLongitudinal =
            ObtenerDiametroBarra(configuracion.TipoLongitudinal);

        double diametroEstribo =
            ObtenerDiametroBarra(configuracion.TipoEstribo);

        // Para contacto y amarre geométrico se usa el diámetro modelado,
        // porque es el diámetro que Revit representa físicamente en 3D.
        double diametroModeloLongitudinal =
            ObtenerDiametroModeloBarra(configuracion.TipoLongitudinal);

        if (configuracion.LongitudinalesTipadas != null &&
            configuracion.LongitudinalesTipadas.Count > 0)
        {
            diametroModeloLongitudinal = configuracion.LongitudinalesTipadas
                .Where(x => x != null && x.TipoBarra != null)
                .Select(x => ObtenerDiametroModeloBarra(x.TipoBarra))
                .DefaultIfEmpty(diametroModeloLongitudinal)
                .Max();
        }

        if (configuracion.GruposLongitudinales != null &&
            configuracion.GruposLongitudinales.Count > 0)
        {
            diametroModeloLongitudinal = configuracion.GruposLongitudinales
                .Where(x => x != null && x.TipoBarra != null)
                .Select(x => ObtenerDiametroModeloBarra(x.TipoBarra))
                .DefaultIfEmpty(diametroModeloLongitudinal)
                .Concat(new double[] { diametroModeloLongitudinal })
                .Max();
        }

        // Centros reales de las barras longitudinales creadas en esta columna.
        // Se reutilizan para hacer tangentes los rombos/cuadriláteros y las
        // trabas C/S, evitando que los recorridos queden demasiado interiores.
        List<PuntoLocal> centrosLongitudinales = new List<PuntoLocal>();

        bool hayEstribosManualesConTipo =
            configuracion.UsarDisenoManual &&
            configuracion.EstribosManuales != null &&
            configuracion.EstribosManuales.Any(x =>
                x != null && x.TipoBarra != null);

        if (configuracion.CrearEstribos &&
            !hayEstribosManualesConTipo &&
            configuracion.TipoEstribo != null &&
            configuracion.TipoGanchoEstribo != null &&
            !GanchoPermitidoParaTipoBarra(
                configuracion.TipoEstribo,
                configuracion.TipoGanchoEstribo))
        {
            throw new InvalidOperationException(
                "El tipo de barra de estribo '" +
                configuracion.TipoEstribo.Name +
                "' no permite el gancho '" +
                configuracion.TipoGanchoEstribo.Name +
                "'. Active ese gancho dentro de las propiedades del tipo " +
                "de barra o seleccione un gancho Estribo/Tirante compatible.");
        }

        bool hayDefinicionLongitudinal =
            configuracion.TipoLongitudinal != null ||
            (configuracion.LongitudinalesTipadas != null &&
             configuracion.LongitudinalesTipadas.Count > 0) ||
            (configuracion.GruposLongitudinales != null &&
             configuracion.GruposLongitudinales.Count > 0);

        // Las posiciones se calculan también en los tramos superiores. Aunque
        // allí no se creen barras nuevas, sus centros son necesarios para que
        // los rombos y las grapas C/S sigan abrazando los longitudinales.
        if (hayDefinicionLongitudinal &&
            (configuracion.CrearLongitudinales ||
             configuracion.CrearEstribos))
        {
            List<PosicionLongitudinalTipada> posiciones =
                new List<PosicionLongitudinalTipada>();

            if (configuracion.UsarDisenoManual &&
                configuracion.LongitudinalesTipadas != null &&
                configuracion.LongitudinalesTipadas.Count > 0)
            {
                foreach (AceroColumnaBarraLongitudinal2D definicion in
                    configuracion.LongitudinalesTipadas)
                {
                    if (definicion == null || definicion.Punto == null)
                        continue;

                    List<PuntoLocal> mapeado = MapearPuntosDelDiseno(
                        new List<AceroColumnaPunto2D> { definicion.Punto },
                        configuracion.ContornoReferencia,
                        datos.Contorno,
                        false,
                        configuracion.ContornosReferencia,
                        datos.Contornos);

                    if (mapeado.Count == 0)
                        continue;

                    posiciones.Add(new PosicionLongitudinalTipada
                    {
                        Punto = mapeado[0],
                        Tipo = definicion.TipoBarra ??
                            configuracion.TipoLongitudinal
                    });
                }
            }
            else if (configuracion.UsarDisenoManual &&
                configuracion.LongitudinalesManuales != null &&
                configuracion.LongitudinalesManuales.Count > 0)
            {
                List<PuntoLocal> mapeadas = MapearPuntosDelDiseno(
                    configuracion.LongitudinalesManuales,
                    configuracion.ContornoReferencia,
                    datos.Contorno,
                    false,
                    configuracion.ContornosReferencia,
                    datos.Contornos);

                foreach (PuntoLocal punto in mapeadas)
                {
                    posiciones.Add(new PosicionLongitudinalTipada
                    {
                        Punto = punto,
                        Tipo = configuracion.TipoLongitudinal
                    });
                }
            }
            else if (configuracion.UsarDisenoManual &&
                configuracion.GruposLongitudinales != null &&
                configuracion.GruposLongitudinales.Count > 0)
            {
                // Los grupos se procesan inmediatamente después. No se generan
                // longitudinales automáticos adicionales cuando el diseño manual
                // contiene exclusivamente conjuntos lineales.
            }
            else
            {
                double retiroLongitudinal =
                    recubrimiento +
                    (configuracion.CrearEstribos ? diametroEstribo : 0.0) +
                    diametroLongitudinal / 2.0;

                List<List<PuntoLocal>> contornosLongitudinales =
                    new List<List<PuntoLocal>>();

                foreach (List<PuntoLocal> region in ObtenerContornosValidos(datos))
                {
                    List<PuntoLocal> interior = DesfasarPoligonoInterior(
                        region,
                        retiroLongitudinal);

                    if (interior != null && interior.Count >= 3)
                        contornosLongitudinales.Add(interior);
                }

                if (contornosLongitudinales.Count == 0)
                {
                    throw new InvalidOperationException(
                        "El recubrimiento y los diámetros dejan todas las regiones " +
                        "de la sección sin espacio interior para barras longitudinales.");
                }

                foreach (List<PuntoLocal> contornoLongitudinal in
                    contornosLongitudinales)
                {
                    foreach (PuntoLocal punto in DistribuirPuntosEnContorno(
                        contornoLongitudinal,
                        separacionMaxima,
                        Math.Max(
                            diametroLongitudinal * 1.10,
                            TolGeometria)))
                    {
                        posiciones.Add(new PosicionLongitudinalTipada
                        {
                            Punto = punto,
                            Tipo = configuracion.TipoLongitudinal
                        });
                    }
                }
            }

            int indiceGrupo = 1;
            if (configuracion.UsarDisenoManual &&
                configuracion.GruposLongitudinales != null)
            {
                foreach (AceroColumnaGrupoLongitudinal2D grupoDef in
                    configuracion.GruposLongitudinales)
                {
                    if (grupoDef == null || grupoDef.PuntoInicio == null ||
                        grupoDef.PuntoFin == null)
                    {
                        continue;
                    }

                    List<PuntoLocal> extremos = MapearPuntosDelDiseno(
                        new List<AceroColumnaPunto2D>
                        {
                            grupoDef.PuntoInicio,
                            grupoDef.PuntoFin
                        },
                        configuracion.ContornoReferencia,
                        datos.Contorno,
                        false,
                        configuracion.ContornosReferencia,
                        datos.Contornos);

                    if (extremos.Count < 2 ||
                        Distancia(extremos[0], extremos[1]) <= TolGeometria)
                    {
                        continue;
                    }

                    RebarBarType tipoGrupo = grupoDef.TipoBarra ??
                        configuracion.TipoLongitudinal;
                    if (tipoGrupo == null)
                        continue;

                    List<PuntoLocal> centrosGrupo =
                        GenerarCentrosGrupoLongitudinal(
                            extremos[0],
                            extremos[1],
                            grupoDef);

                    foreach (PuntoLocal centro in centrosGrupo)
                    {
                        PuntoLocal ajustadoCentro = AjustarPuntoDentroContornos(
                            centro,
                            ObtenerContornosValidos(datos));
                        if (!centrosLongitudinales.Any(x =>
                            Distancia(x, ajustadoCentro) <= TolGeometria))
                        {
                            centrosLongitudinales.Add(ajustadoCentro.Copiar());
                        }
                    }

                    if (!configuracion.CrearLongitudinales ||
                        !crearLongitudinalesEnEsteTramo)
                    {
                        indiceGrupo++;
                        continue;
                    }

                    // Tanto SIN empalmes como CON empalmes se conservan
                    // Rebar Set reales. Con empalmes, cada pieza comercial es
                    // un SET completo con la MISMA regla de diseño.
                    if (considerarEmpalmesLongitudinales)
                    {
                        double longitudEmpalmeParaTipo =
                            longitudEmpalmeLongitudinal;

                        if (configuracion.UsarCalculoRneEmpalme)
                        {
                            longitudEmpalmeParaTipo =
                                CalcularLongitudEmpalmeRneInterna(
                                    tipoGrupo,
                                    configuracion);
                        }

                        List<Rebar> setsEmpalmados =
                            CrearGrupoLongitudinalConEmpalmesComoSets(
                                doc,
                                hostLongitudinal,
                                datosHostLongitudinal,
                                extremos[0],
                                extremos[1],
                                tipoGrupo,
                                grupoDef,
                                recubrimiento,
                                anclajeInferior,
                                prolongacionSuperior,
                                zInferiorLongitudinalGrupo,
                                zSuperiorLongitudinalGrupo,
                                ubicarEmpalmesMitadCentralE060,
                                longitudComercialLongitudinal,
                                longitudEmpalmeParaTipo,
                                zonasMitadCentralGrupo);

                        if (setsEmpalmados != null &&
                            setsEmpalmados.Count > 0)
                        {
                            int cantidadFisica =
                                CalcularCantidadFisicaGrupoLongitudinal(
                                    extremos[0],
                                    extremos[1],
                                    grupoDef);

                            resultado.Longitudinales +=
                                cantidadFisica * setsEmpalmados.Count;

                            int piezaSet = 1;

                            foreach (Rebar setEmpalmado in setsEmpalmados)
                            {
                                if (setEmpalmado == null)
                                    continue;

                                resultado.Ids.Add(setEmpalmado.Id);

                                if (configuracion.CompletarParametros)
                                {
                                    CompletarParametros(
                                        setEmpalmado,
                                        hostLongitudinal,
                                        "Grupo longitudinal empalmado " +
                                            tipoGrupo.Name +
                                            " - " +
                                            ObtenerTextoReglaGrupo(grupoDef) +
                                            " - Pieza " + piezaSet,
                                        "COL-PRI-GRP-" + indiceGrupo +
                                            "-P" + piezaSet);
                                }

                                piezaSet++;
                            }
                        }
                        else if (!string.IsNullOrWhiteSpace(
                            ultimoErrorCreacion))
                        {
                            resultado.Errores.Add(
                                "Grupo longitudinal " + indiceGrupo +
                                " con empalmes: " +
                                ultimoErrorCreacion);
                        }
                    }
                    else
                    {
                        Rebar conjunto = CrearGrupoLongitudinal(
                            doc,
                            hostLongitudinal,
                            datosHostLongitudinal,
                            extremos[0],
                            extremos[1],
                            tipoGrupo,
                            grupoDef,
                            recubrimiento,
                            anclajeInferior,
                            prolongacionSuperior,
                            zInferiorLongitudinalGrupo,
                            zSuperiorLongitudinalGrupo);

                        if (conjunto != null)
                        {
                            int cantidadFisica =
                                CalcularCantidadFisicaGrupoLongitudinal(
                                    extremos[0],
                                    extremos[1],
                                    grupoDef);
                            resultado.Longitudinales += cantidadFisica;
                            resultado.Ids.Add(conjunto.Id);
                            if (configuracion.CompletarParametros)
                            {
                                CompletarParametros(
                                    conjunto,
                                    hostLongitudinal,
                                    "Grupo longitudinal " + tipoGrupo.Name +
                                        " - " + ObtenerTextoReglaGrupo(grupoDef),
                                    "COL-PRI-GRP-" + indiceGrupo);
                            }
                        }
                        else if (!string.IsNullOrWhiteSpace(ultimoErrorCreacion))
                        {
                            resultado.Errores.Add(
                                "Grupo longitudinal " + indiceGrupo + ": " +
                                ultimoErrorCreacion);
                        }
                    }

                    indiceGrupo++;
                }
            }

            int indice = 1;

            foreach (PosicionLongitudinalTipada definicion in posiciones)
            {
                if (definicion == null || definicion.Punto == null ||
                    definicion.Tipo == null)
                {
                    continue;
                }

                PuntoLocal posicion = AjustarPuntoDentroContornos(
                    definicion.Punto,
                    ObtenerContornosValidos(datos));

                if (!centrosLongitudinales.Any(x =>
                    Distancia(x, posicion) <= TolGeometria))
                {
                    centrosLongitudinales.Add(posicion.Copiar());
                }

                // En los tramos superiores solo se reconstruyen los centros de
                // referencia. La barra física ya fue creada por el tramo base.
                if (!configuracion.CrearLongitudinales ||
                    !crearLongitudinalesEnEsteTramo)
                {
                    continue;
                }

                double diametroDefinicion =
                    ObtenerDiametroBarra(definicion.Tipo);

                double longitudEmpalmeParaTipo =
                    longitudEmpalmeLongitudinal;

                if (considerarEmpalmesLongitudinales &&
                    configuracion.UsarCalculoRneEmpalme)
                {
                    longitudEmpalmeParaTipo =
                        CalcularLongitudEmpalmeRneInterna(
                            definicion.Tipo,
                            configuracion);

                    if (longitudEmpalmeParaTipo <= Tol)
                    {
                        throw new InvalidOperationException(
                            "No se pudo calcular la longitud de empalme RNE " +
                            "para el tipo '" + definicion.Tipo.Name + "'.");
                    }

                    if (longitudEmpalmeParaTipo >=
                        longitudComercialLongitudinal - Tol)
                    {
                        double leM = UnitUtils.ConvertFromInternalUnits(
                            longitudEmpalmeParaTipo,
                            UnitTypeId.Meters);
                        throw new InvalidOperationException(
                            "El empalme RNE calculado para '" +
                            definicion.Tipo.Name + "' es " +
                            leM.ToString("0.###", CultureInfo.InvariantCulture) +
                            " m y debe ser menor que la longitud comercial.");
                    }
                }

                List<Rebar> piezasLongitudinales =
                    CrearBarrasLongitudinalesConEmpalmes(
                        doc,
                        hostLongitudinal,
                        datosHostLongitudinal,
                        posicion,
                        definicion.Tipo,
                        recubrimiento,
                        diametroDefinicion,
                        anclajeInferior,
                        prolongacionSuperior,
                        zInferiorLongitudinalGrupo,
                        zSuperiorLongitudinalGrupo,
                        considerarEmpalmesLongitudinales,
                        ubicarEmpalmesMitadCentralE060,
                        longitudComercialLongitudinal,
                        longitudEmpalmeParaTipo,
                        zonasMitadCentralGrupo);

                if (piezasLongitudinales == null ||
                    piezasLongitudinales.Count == 0)
                {
                    continue;
                }

                for (int piezaIndice = 0;
                     piezaIndice < piezasLongitudinales.Count;
                     piezaIndice++)
                {
                    Rebar barra = piezasLongitudinales[piezaIndice];

                    if (barra == null)
                        continue;

                    resultado.Longitudinales++;
                    resultado.Ids.Add(barra.Id);

                    if (configuracion.CompletarParametros)
                    {
                        CompletarParametros(
                            barra,
                            hostLongitudinal,
                            piezasLongitudinales.Count > 1
                                ? "Acero longitudinal empalmado de columna - " +
                                  definicion.Tipo.Name
                                : "Acero longitudinal continuo de columna - " +
                                  definicion.Tipo.Name,
                            "COL-PRI-CONT-" + indice +
                            (piezasLongitudinales.Count > 1
                                ? "-P" + (piezaIndice + 1)
                                : "") +
                            "-HOST-" + hostLongitudinal.Id.Value);
                    }
                }

                indice++;
            }
        }

        if (configuracion.CrearEstribos &&
            (configuracion.TipoEstribo != null || hayEstribosManualesConTipo))
        {
            double retiroEstribo =
                recubrimiento + diametroEstribo / 2.0;

            List<ZonaEstribos> zonas = ObtenerZonasEstribos(
                doc,
                columna,
                datos,
                retiroEstribo,
                configuracion,
                elementosPotencialesNodo,
                longitudZonaConfinada,
                espaciamientoConfinado,
                espaciamientoCentral,
                null);

            bool usoManual =
                configuracion.UsarDisenoManual &&
                configuracion.EstribosManuales != null &&
                configuracion.EstribosManuales.Count > 0;

            if (usoManual)
            {
                int indiceEstribo = 1;

                foreach (AceroColumnaEstribo2D definicion in
                    configuracion.EstribosManuales)
                {
                    if (definicion == null || definicion.Puntos == null)
                        continue;

                    RebarBarType tipoEstriboDefinicion =
                        definicion.TipoBarra ?? configuracion.TipoEstribo;

                    if (tipoEstriboDefinicion == null)
                        continue;

                    bool esHorizontalAlma =
                        definicion.Tipo ==
                            AceroColumnaTipoEstribo2D.HorizontalAlma;

                    bool esCircular =
                        definicion.Tipo ==
                            AceroColumnaTipoEstribo2D.Circular;

                    RebarHookType ganchoDefinicion = esHorizontalAlma
                        ? null
                        : esCircular
                            ? ResolverGanchoCircular90(
                                doc,
                                tipoEstriboDefinicion,
                                configuracion.TipoGanchoEstribo)
                            : configuracion.TipoGanchoEstribo;

                    if (esCircular && ganchoDefinicion == null)
                    {
                        resultado.Errores.Add(
                            definicion.Tipo + ": no se encontró un tipo de " +
                            "gancho de 90° compatible con la barra '" +
                            tipoEstriboDefinicion.Name + "'. Cree o habilite " +
                            "un gancho Estribo/Tirante de 90° para ese tipo de barra.");
                        continue;
                    }

                    if (ganchoDefinicion != null &&
                        !GanchoPermitidoParaTipoBarra(
                            tipoEstriboDefinicion,
                            ganchoDefinicion))
                    {
                        resultado.Errores.Add(
                            definicion.Tipo + ": el tipo '" +
                            tipoEstriboDefinicion.Name +
                            "' no permite el gancho '" +
                            ganchoDefinicion.Name + "'.");
                        continue;
                    }

                    double diametroEstriboDefinicion =
                        ObtenerDiametroBarra(tipoEstriboDefinicion);
                    List<ZonaEstribos> zonasDefinicion = ObtenerZonasEstribos(
                        doc,
                        columna,
                        datos,
                        recubrimiento + diametroEstriboDefinicion / 2.0,
                        configuracion,
                        elementosPotencialesNodo,
                        longitudZonaConfinada,
                        espaciamientoConfinado,
                        espaciamientoCentral,
                        definicion);

                    int minimo = definicion.Cerrado ? 3 : 2;

                    if (definicion.Puntos.Count < minimo)
                        continue;

                    bool ajustarDentroSeccion =
                        definicion.Tipo != AceroColumnaTipoEstribo2D.Croquis &&
                        definicion.Tipo !=
                            AceroColumnaTipoEstribo2D.HorizontalAlma;

                    List<PuntoLocal> puntos = MapearPuntosDelDiseno(
                        definicion.Puntos,
                        configuracion.ContornoReferencia,
                        datos.Contorno,
                        ajustarDentroSeccion,
                        configuracion.ContornosReferencia,
                        datos.Contornos);

                    if (puntos.Count < minimo)
                        continue;

                    foreach (ZonaEstribos zona in zonasDefinicion)
                    {
                        Rebar estribo = CrearConjuntoEstribosPersonalizado(
                            doc,
                            columna,
                            datos,
                            puntos,
                            definicion.Cerrado,
                            tipoEstriboDefinicion,
                            ganchoDefinicion,
                            zona,
                            definicion.IndiceEsquinaGancho,
                            definicion.Tipo,
                            diametroModeloLongitudinal,
                            recubrimiento,
                            centrosLongitudinales,
                            ConvertirMetros(configuracion.LongitudEmpalmeLongitudinalM),
                            definicion.Tipo.ToString());

                        if (estribo == null)
                        {
                            if (!string.IsNullOrWhiteSpace(ultimoErrorCreacion))
                            {
                                resultado.Errores.Add(
                                    definicion.Tipo + " - " + zona.Nombre +
                                    ": " + ultimoErrorCreacion);
                            }

                            continue;
                        }

                        resultado.ConjuntosEstribos++;
                        resultado.Ids.Add(estribo.Id);

                        if (configuracion.CompletarParametros)
                        {
                            bool esGanchoAbierto =
                                definicion.Tipo == AceroColumnaTipoEstribo2D.TrabaC ||
                                definicion.Tipo == AceroColumnaTipoEstribo2D.TrabaS ||
                                definicion.Tipo == AceroColumnaTipoEstribo2D.TrabaGancho;

                            string nombreTipo = esHorizontalAlma
                                ? "Refuerzo horizontal de alma"
                                : esGanchoAbierto
                                    ? "Gancho o traba de columna"
                                    : "Estribo de columna";

                            CompletarParametros(
                                estribo,
                                columna,
                                nombreTipo + " " + tipoEstriboDefinicion.Name + " - " + zona.Nombre,
                                (esHorizontalAlma ? "COL-ALMA-" : "COL-EST-") +
                                indiceEstribo +
                                "-" + zona.Nombre,
                                ObtenerTextoDistribucionEstribosMYG(
                                    configuracion,
                                    zona,
                                    definicion));
                        }
                    }

                    indiceEstribo++;
                }
            }
            else
            {
                List<RectanguloLocal> rectangulos =
                    new List<RectanguloLocal>();

                foreach (List<PuntoLocal> region in ObtenerContornosValidos(datos))
                {
                    List<RectanguloLocal> parciales =
                        DescomponerEnRectangulos(region);

                    if (parciales != null && parciales.Count > 0)
                    {
                        rectangulos.AddRange(parciales);
                    }
                    else
                    {
                        RectanguloLocal cajaRegion = ObtenerCaja(region);
                        if (cajaRegion != null)
                            rectangulos.Add(cajaRegion);
                    }
                }

                int indiceRectangulo = 1;

                foreach (RectanguloLocal rectanguloOriginal in rectangulos)
                {
                    RectanguloLocal rectangulo = new RectanguloLocal
                    {
                        MinX = rectanguloOriginal.MinX + retiroEstribo,
                        MaxX = rectanguloOriginal.MaxX - retiroEstribo,
                        MinY = rectanguloOriginal.MinY + retiroEstribo,
                        MaxY = rectanguloOriginal.MaxY - retiroEstribo
                    };

                    if (rectangulo.Ancho <= diametroEstribo * 2.0 + Tol ||
                        rectangulo.Alto <= diametroEstribo * 2.0 + Tol)
                    {
                        continue;
                    }

                    foreach (ZonaEstribos zona in zonas)
                    {
                        Rebar estribo = CrearConjuntoEstribos(
                            doc,
                            columna,
                            datos,
                            rectangulo,
                            configuracion.TipoEstribo,
                            configuracion.TipoGanchoEstribo,
                            zona);

                        if (estribo == null)
                        {
                            if (!string.IsNullOrWhiteSpace(ultimoErrorCreacion))
                            {
                                resultado.Errores.Add(
                                    "Estribo automático " + zona.Nombre +
                                    ": " + ultimoErrorCreacion);
                            }

                            continue;
                        }

                        resultado.ConjuntosEstribos++;
                        resultado.Ids.Add(estribo.Id);

                        if (configuracion.CompletarParametros)
                        {
                            CompletarParametros(
                                estribo,
                                columna,
                                "Estribo de columna - " + zona.Nombre,
                                "COL-EST-" +
                                indiceRectangulo +
                                "-" + zona.Nombre,
                                ObtenerTextoDistribucionEstribosMYG(
                                    configuracion,
                                    zona,
                                    null));
                        }
                    }

                    indiceRectangulo++;
                }
            }
        }

        if (resultado.Total == 0 &&
            !string.IsNullOrWhiteSpace(ultimoErrorCreacion))
        {
            resultado.Errores.Add(ultimoErrorCreacion);
        }

        resultado.Errores = resultado.Errores
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct()
            .ToList();

        return resultado;
    }

    // ================================================================
    // LONGITUDINALES CON EMPALMES Y QUIEBRE
    // ================================================================
    // Cuando la altura desarrollada supera la longitud comercial, cada
    // longitudinal se divide en piezas. La pieza inferior termina con:
    //   1) tramo vertical sobre el eje original;
    //   2) quiebre inclinado hacia el núcleo de la columna;
    private List<ZonaEmpalmeLongitudinal>
        ObtenerZonasEmpalmeMitadCentral(
            List<DatosColumna> tramos)
    {
        List<ZonaEmpalmeLongitudinal> zonas =
            new List<ZonaEmpalmeLongitudinal>();

        if (tramos == null)
            return zonas;

        foreach (DatosColumna tramo in tramos
            .Where(x => x != null)
            .OrderBy(x => x.ZInferior)
            .ThenBy(x => x.ZSuperior))
        {
            double altura = tramo.ZSuperior - tramo.ZInferior;

            if (altura <= TolGeometria)
                continue;

            // Mitad central de la altura geométrica del elemento seleccionado:
            // [Zi + H/4, Zs - H/4]. La detección se realiza por cada tramo, no
            // sobre la altura total acumulada del grupo.
            double inicio = tramo.ZInferior + altura * 0.25;
            double fin = tramo.ZSuperior - altura * 0.25;

            if (fin <= inicio + TolGeometria)
                continue;

            long id = tramo.Columna != null
                ? tramo.Columna.Id.Value
                : -1L;

            zonas.Add(new ZonaEmpalmeLongitudinal
            {
                Inicio = inicio,
                Fin = fin,
                ColumnaId = id,
                Etiqueta = id > 0
                    ? "la mitad central de la columna ID " + id
                    : "la mitad central del tramo"
            });
        }

        return zonas;
    }

    private List<ZonaEmpalmeLongitudinal>
        ConvertirZonasEmpalmeAEstaciones(
            List<ZonaEmpalmeLongitudinal> zonasAbsolutas,
            double zBase,
            double zSuperior)
    {
        List<ZonaEmpalmeLongitudinal> resultado =
            new List<ZonaEmpalmeLongitudinal>();

        if (zonasAbsolutas == null || zSuperior <= zBase + Tol)
            return resultado;

        double longitudTotal = zSuperior - zBase;

        foreach (ZonaEmpalmeLongitudinal zona in zonasAbsolutas)
        {
            if (zona == null)
                continue;

            double inicio = Math.Max(0.0, zona.Inicio - zBase);
            double fin = Math.Min(longitudTotal, zona.Fin - zBase);

            if (fin <= inicio + TolGeometria)
                continue;

            resultado.Add(new ZonaEmpalmeLongitudinal
            {
                Inicio = inicio,
                Fin = fin,
                ColumnaId = zona.ColumnaId,
                Etiqueta = zona.Etiqueta
            });
        }

        return resultado
            .OrderBy(x => x.Inicio)
            .ThenBy(x => x.Fin)
            .ToList();
    }

    private bool TryObtenerIntervaloEmpalmeMitadCentral(
        double estacionInicioPieza,
        double longitudTotal,
        double longitudComercial,
        double longitudEmpalme,
        double longitudQuiebre,
        double desfaseEmpalme,
        double longitudMinimaGeometrica,
        List<ZonaEmpalmeLongitudinal> zonasPermitidas,
        out double estacionMinimaFin,
        out double estacionMaximaFin,
        out string zonaSeleccionada)
    {
        estacionMinimaFin = 0.0;
        estacionMaximaFin = 0.0;
        zonaSeleccionada = "";

        if (zonasPermitidas == null || zonasPermitidas.Count == 0)
            return false;

        // La longitud desarrollada de la pieza es el avance vertical más el
        // incremento que introduce el tramo diagonal del quiebre. Con esta
        // corrección se obtiene la estación máxima compatible con la longitud
        // comercial antes de llamar a la medición real de Revit.
        double incrementoDiagonal = Math.Sqrt(
            longitudQuiebre * longitudQuiebre +
            desfaseEmpalme * desfaseEmpalme) - longitudQuiebre;

        double finObjetivo =
            estacionInicioPieza +
            longitudComercial -
            Math.Max(0.0, incrementoDiagonal);

        // Después del traslape debe quedar una pieza final con longitud
        // geométrica positiva. Como la pieza siguiente comienza en
        // EstacionFin - LongitudEmpalme, este límite se expresa sobre el fin
        // de la pieza actual.
        double limiteParaDejarPiezaSiguiente =
            longitudTotal - longitudMinimaGeometrica + longitudEmpalme;

        ZonaEmpalmeLongitudinal mejorZona = null;
        double mejorMinimo = 0.0;
        double mejorMaximo = double.NegativeInfinity;

        foreach (ZonaEmpalmeLongitudinal zona in zonasPermitidas)
        {
            if (zona == null)
                continue;

            // Se exige que TODO el detalle quede en la mitad central:
            // inicio del quiebre, tramo inclinado y traslape paralelo.
            double minimoZona = Math.Max(
                zona.Inicio + longitudQuiebre + longitudEmpalme,
                estacionInicioPieza +
                    longitudQuiebre +
                    longitudEmpalme +
                    longitudMinimaGeometrica);

            double maximoZona = Math.Min(
                zona.Fin,
                Math.Min(finObjetivo, limiteParaDejarPiezaSiguiente));

            if (maximoZona <= minimoZona + TolGeometria)
                continue;

            // Se elige la zona más alta que aún permite respetar la longitud
            // comercial. Así no se corta una barra de 9 m en la primera mitad
            // central disponible si puede alcanzar una mitad central superior.
            if (mejorZona == null || maximoZona > mejorMaximo)
            {
                mejorZona = zona;
                mejorMinimo = minimoZona;
                mejorMaximo = maximoZona;
            }
        }

        if (mejorZona == null)
            return false;

        estacionMinimaFin = mejorMinimo;
        estacionMaximaFin = mejorMaximo;
        zonaSeleccionada = mejorZona.Etiqueta ?? "la mitad central";
        return true;
    }

    //   3) tramo vertical paralelo con la longitud exacta de empalme.
    // La pieza siguiente comienza sobre el eje original en el inicio del
    // traslape. El anclaje inferior solo pertenece a la primera pieza y la
    // prolongación superior solo a la última.
    private double CalcularLongitudEmpalmeRneInterna(
        RebarBarType tipo,
        AceroColumnaConfiguracion configuracion)
    {
        if (tipo == null || configuracion == null)
            return 0.0;

        double diametroPies = ObtenerDiametroBarra(tipo);
        if (diametroPies <= Tol)
            return 0.0;

        double diametroMm = UnitUtils.ConvertFromInternalUnits(
            diametroPies,
            UnitTypeId.Millimeters);

        double fcKgCm2 = configuracion.RneFcKgCm2;
        double fyMpa = configuracion.RneFyMpa;
        double psiT = configuracion.RnePsiT;
        double psiE = configuracion.RnePsiE;
        double lambda = configuracion.RneLambda;
        double factorClase = configuracion.RneFactorClaseEmpalme;
        double minimoMm = configuracion.RneLongitudMinimaMm;
        bool condicionesTabla121 = configuracion.RneCondicionesTabla121;
        double redondeoSuperiorMm = configuracion.RneRedondeoSuperiorMm;

        if (diametroMm <= 0.0 || fcKgCm2 <= 0.0 || fyMpa <= 0.0 ||
            psiT <= 0.0 || psiE <= 0.0 || lambda <= 0.0 ||
            factorClase <= 0.0 || minimoMm <= 0.0 ||
            redondeoSuperiorMm < 0.0 || !condicionesTabla121)
        {
            return 0.0;
        }

        // Conversión usada para permitir el ingreso habitual en kg/cm².
        double fcMpa = fcKgCm2 * 0.0980665;

        // Forma simplificada indicada: fy/(2.6*sqrt(f'c))*db para barras
        // de 3/4" o menores y fy/(2.1*sqrt(f'c))*db para barras mayores.
        double divisor = diametroMm <= 19.05 + 1e-6 ? 2.6 : 2.1;

        double ldMm =
            (fyMpa / (divisor * Math.Sqrt(fcMpa))) *
            psiT * psiE * lambda * diametroMm;
        ldMm = Math.Max(ldMm, minimoMm);

        double longitudEmpalmeMm = Math.Max(
            factorClase * ldMm,
            minimoMm);
        if (redondeoSuperiorMm > 1e-6)
        {
            longitudEmpalmeMm = Math.Ceiling(
                (longitudEmpalmeMm - 1e-9) / redondeoSuperiorMm) *
                redondeoSuperiorMm;
        }

        return UnitUtils.ConvertToInternalUnits(
            longitudEmpalmeMm,
            UnitTypeId.Millimeters);
    }


    // ================================================================
    // EMPALMES DE GRUPOS LONGITUDINALES COMO REBAR SET
    // ================================================================
    // Cada pieza comercial es UN Rebar Set completo. Nunca se explota el
    // grupo en barras individuales. La regla definida en la ventana
    // (máximo, número+espaciado o número fijo) prevalece en TODAS las piezas.
    private List<Rebar> CrearGrupoLongitudinalConEmpalmesComoSets(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        PuntoLocal inicio,
        PuntoLocal fin,
        RebarBarType tipo,
        AceroColumnaGrupoLongitudinal2D grupo,
        double recubrimiento,
        double anclajeInferior,
        double prolongacionSuperior,
        double zInferiorGrupo,
        double zSuperiorGrupo,
        bool ubicarEmpalmesMitadCentralE060,
        double longitudComercial,
        double longitudEmpalme,
        List<ZonaEmpalmeLongitudinal> zonasMitadCentralGrupo)
    {
        return CrearPiezasLongitudinalesConQuiebreMYG(
            doc, host, datos, inicio, fin, tipo, grupo,
            recubrimiento, anclajeInferior, prolongacionSuperior,
            zInferiorGrupo, zSuperiorGrupo,
            ubicarEmpalmesMitadCentralE060, longitudComercial,
            longitudEmpalme, zonasMitadCentralGrupo);
    }

    private List<Rebar> CrearBarrasLongitudinalesConEmpalmes(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        PuntoLocal posicion,
        RebarBarType tipo,
        double recubrimiento,
        double diametro,
        double anclajeInferior,
        double prolongacionSuperior,
        double zInferiorGrupo,
        double zSuperiorGrupo,
        bool considerarEmpalmes,
        bool ubicarEmpalmesMitadCentralE060,
        double longitudComercial,
        double longitudEmpalme,
        List<ZonaEmpalmeLongitudinal> zonasMitadCentralGrupo)
    {
        List<Rebar> resultado = new List<Rebar>();
        if (doc == null || host == null || datos == null ||
            posicion == null || tipo == null)
            return resultado;

        if (!considerarEmpalmes)
        {
            Rebar unica = CrearBarraLongitudinal(
                doc, host, datos, posicion, tipo, recubrimiento,
                diametro, anclajeInferior, prolongacionSuperior,
                zInferiorGrupo, zSuperiorGrupo);
            if (unica != null)
                resultado.Add(unica);
            return resultado;
        }

        // La posicion individual SI es una barra individual, pues el
        // usuario la dibujo asi. Un GrupoLongitudinal2D nunca entra aqui.
        return CrearPiezasLongitudinalesConQuiebreMYG(
            doc, host, datos, posicion, null, tipo, null,
            recubrimiento, anclajeInferior, prolongacionSuperior,
            zInferiorGrupo, zSuperiorGrupo,
            ubicarEmpalmesMitadCentralE060, longitudComercial,
            longitudEmpalme, zonasMitadCentralGrupo);
    }

    private ResultadoTramoEmpalmeLongitudinal
        CrearTramoLongitudinalAjustadoALongitud(
            Document doc,
            Element host,
            RebarBarType tipo,
            XYZ normal,
            XYZ origen,
            XYZ direccionPrincipal,
            XYZ direccionEmpalme,
            double estacionInicio,
            double estacionMinimaFin,
            double estacionMaximaFin,
            double longitudObjetivo,
            double longitudEmpalme,
            double desfaseEmpalme,
            double longitudQuiebre)
    {
        if (estacionMaximaFin <= estacionMinimaFin + Tol)
            return null;

        double inferior = estacionMinimaFin;
        double superior = estacionMaximaFin;
        double mejorEstacion = estacionMinimaFin;
        double mejorDiferencia = double.MaxValue;
        double mejorLongitud = 0.0;
        double toleranciaLongitud = UnitUtils.ConvertToInternalUnits(
            1.0,
            UnitTypeId.Millimeters);

        for (int i = 0; i < 20; i++)
        {
            double estacionEvaluada = (inferior + superior) * 0.5;
            List<Curve> curvas = ConstruirCurvasTramoLongitudinal(
                origen,
                direccionPrincipal,
                direccionEmpalme,
                estacionInicio,
                estacionEvaluada,
                true,
                longitudEmpalme,
                desfaseEmpalme,
                longitudQuiebre);

            double longitudReal = MedirLongitudLongitudinalTemporal(
                doc,
                host,
                tipo,
                normal,
                curvas);

            if (longitudReal <= TolGeometria)
            {
                // Respaldo matemático para dirigir la búsqueda. La pieza final
                // solo se acepta si Revit reporta posteriormente longitud válida.
                longitudReal = curvas.Where(x => x != null).Sum(x => x.Length);
            }

            double diferencia = Math.Abs(longitudReal - longitudObjetivo);

            if (diferencia < mejorDiferencia)
            {
                mejorDiferencia = diferencia;
                mejorEstacion = estacionEvaluada;
                mejorLongitud = longitudReal;
            }

            if (longitudReal < longitudObjetivo)
                inferior = estacionEvaluada;
            else
                superior = estacionEvaluada;

            if (diferencia <= toleranciaLongitud)
                break;
        }

        List<Curve> curvasFinales = ConstruirCurvasTramoLongitudinal(
            origen,
            direccionPrincipal,
            direccionEmpalme,
            estacionInicio,
            mejorEstacion,
            true,
            longitudEmpalme,
            desfaseEmpalme,
            longitudQuiebre);

        Rebar rebarFinal = CrearLongitudinalConCurvasValidado(
            doc,
            host,
            tipo,
            normal,
            curvasFinales,
            "pieza longitudinal con quiebre");

        if (rebarFinal == null)
            return null;

        double longitudFinal = ObtenerParametroLongitud(
            rebarFinal,
            BuiltInParameter.REBAR_ELEM_LENGTH);

        if (longitudFinal <= TolGeometria)
            longitudFinal = ObtenerLongitudCentroRebar(rebarFinal);

        if (longitudFinal > longitudObjetivo +
            UnitUtils.ConvertToInternalUnits(3.0, UnitTypeId.Millimeters))
        {
            EliminarElementoSeguro(doc, rebarFinal.Id);
            ultimoErrorCreacion =
                "La pieza longitudinal empalmada excede la longitud comercial: " +
                UnitUtils.ConvertFromInternalUnits(
                    longitudFinal,
                    UnitTypeId.Meters).ToString("0.###", CultureInfo.InvariantCulture) +
                " m > " +
                UnitUtils.ConvertFromInternalUnits(
                    longitudObjetivo,
                    UnitTypeId.Meters).ToString("0.###", CultureInfo.InvariantCulture) +
                " m.";
            return null;
        }

        return new ResultadoTramoEmpalmeLongitudinal
        {
            Rebar = rebarFinal,
            EstacionFin = mejorEstacion,
            LongitudReal = longitudFinal > TolGeometria
                ? longitudFinal
                : mejorLongitud
        };
    }

    private List<Curve> ConstruirCurvasTramoLongitudinal(
        XYZ origen,
        XYZ direccionPrincipal,
        XYZ direccionEmpalme,
        double estacionInicio,
        double estacionFin,
        bool tieneEmpalmeFinal,
        double longitudEmpalme,
        double desfaseEmpalme,
        double longitudQuiebre)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (!tieneEmpalmeFinal)
        {
            AgregarPuntoLongitudinalSiDistinto(
                puntos,
                origen.Add(direccionPrincipal.Multiply(estacionInicio)));
            AgregarPuntoLongitudinalSiDistinto(
                puntos,
                origen.Add(direccionPrincipal.Multiply(estacionFin)));
        }
        else
        {
            double estacionInicioEmpalme =
                estacionFin - longitudEmpalme;
            double estacionInicioQuiebre =
                estacionInicioEmpalme - longitudQuiebre;

            if (estacionInicioQuiebre < estacionInicio)
                estacionInicioQuiebre = estacionInicio;
            if (estacionInicioEmpalme < estacionInicioQuiebre)
                estacionInicioEmpalme = estacionInicioQuiebre;

            AgregarPuntoLongitudinalSiDistinto(
                puntos,
                origen.Add(direccionPrincipal.Multiply(estacionInicio)));
            AgregarPuntoLongitudinalSiDistinto(
                puntos,
                origen.Add(direccionPrincipal.Multiply(estacionInicioQuiebre)));
            AgregarPuntoLongitudinalSiDistinto(
                puntos,
                origen
                    .Add(direccionPrincipal.Multiply(estacionInicioEmpalme))
                    .Add(direccionEmpalme.Multiply(desfaseEmpalme)));
            AgregarPuntoLongitudinalSiDistinto(
                puntos,
                origen
                    .Add(direccionPrincipal.Multiply(estacionFin))
                    .Add(direccionEmpalme.Multiply(desfaseEmpalme)));
        }

        List<Curve> curvas = new List<Curve>();
        for (int i = 0; i + 1 < puntos.Count; i++)
        {
            if (puntos[i].DistanceTo(puntos[i + 1]) > TolGeometria)
                curvas.Add(Line.CreateBound(puntos[i], puntos[i + 1]));
        }

        return curvas;
    }

    private void AgregarPuntoLongitudinalSiDistinto(
        List<XYZ> puntos,
        XYZ punto)
    {
        if (puntos == null || punto == null)
            return;

        if (puntos.Count == 0 ||
            puntos[puntos.Count - 1].DistanceTo(punto) > TolGeometria)
        {
            puntos.Add(punto);
        }
    }

    // MYG: orientacion por centroide eliminada definitivamente.


    private double MedirLongitudLongitudinalTemporal(
        Document doc,
        Element host,
        RebarBarType tipo,
        XYZ normal,
        IList<Curve> curvas)
    {
        if (doc == null || host == null || tipo == null ||
            normal == null || normal.GetLength() <= Tol ||
            curvas == null || curvas.Count == 0)
        {
            return 0.0;
        }

        bool[] usarExistente = new bool[] { true, false };

        foreach (bool reutilizar in usarExistente)
        {
            using (SubTransaction sub = new SubTransaction(doc))
            {
                sub.Start();
                try
                {
                    Rebar rebar;
                    using (BarTerminationsData terminaciones =
                        new BarTerminationsData(doc))
                    {
                        rebar = Rebar.CreateFromCurves(
                            doc,
                            RebarStyle.Standard,
                            tipo,
                            host,
                            normal.Normalize(),
                            curvas,
                            terminaciones,
                            reutilizar,
                            !reutilizar);
                    }

                    if (rebar == null)
                    {
                        sub.RollBack();
                        continue;
                    }

                    EstablecerRebarIndividual(rebar);
                    doc.Regenerate();

                    double longitud = ObtenerParametroLongitud(
                        rebar,
                        BuiltInParameter.REBAR_ELEM_LENGTH);
                    if (longitud <= TolGeometria)
                        longitud = ObtenerLongitudCentroRebar(rebar);

                    sub.RollBack();
                    if (longitud > TolGeometria)
                        return longitud;
                }
                catch
                {
                    try
                    {
                        if (sub.GetStatus() == TransactionStatus.Started)
                            sub.RollBack();
                    }
                    catch
                    {
                    }
                }
            }
        }

        return 0.0;
    }

    // ================================================================
    // MYG 2027 - GANCHO INFERIOR NATIVO «GANCHO AL FINAL»
    // ================================================================
    // La cadena entra con el extremo superior primero y la base al final.
    // El tramo horizontal inferior NO forma parte del boceto. La longitud
    // de su rama, radio y doblado los calcula Revit desde RebarHookType
    // STANDARD de 90° y RebarBarType; no se inventan como una linea de 10 cm.
    private List<Curve> InvertirCadenaLongitudinalMYG(IList<Curve> curvas)
    {
        List<Curve> invertidas = new List<Curve>();
        if (curvas == null)
            return invertidas;
        for (int i = curvas.Count - 1; i >= 0; i--)
        {
            Curve curva = curvas[i];
            if (curva == null || !(curva is Line))
                return new List<Curve>();
            invertidas.Add(Line.CreateBound(
                curva.GetEndPoint(1), curva.GetEndPoint(0)));
        }
        return invertidas;
    }

    private bool GanchoInferiorNativoApuntaHaciaAfueraMYG(
        Rebar rebar, XYZ baseInferior, XYZ direccionInterior)
    {
        if (rebar == null || baseInferior == null ||
            direccionInterior == null || direccionInterior.GetLength() <= Tol)
            return false;

        XYZ afuera = new XYZ(-direccionInterior.X,
            -direccionInterior.Y, 0.0);
        if (afuera.GetLength() <= Tol)
            return false;
        afuera = afuera.Normalize();

        IList<Curve> cadena = rebar.GetCenterlineCurves(
            false, false, false,
            MultiplanarOption.IncludeOnlyPlanarCurves, 0);
        if (cadena == null || cadena.Count == 0)
            return false;

        // Revit puede devolver el orden de la cadena invertido según la
        // RebarShape seleccionada; no depender de [last].GetEndPoint(1).
        // Se comparan solo extremos cercanos a la cota inferior para no
        // confundirlos con el tramo horizontal superior del boceto.
        double toleranciaZ = UnitUtils.ConvertToInternalUnits(
            15.0, UnitTypeId.Centimeters);
        double minimo = UnitUtils.ConvertToInternalUnits(
            2.0, UnitTypeId.Millimeters);
        foreach (Curve curva in cadena)
        {
            if (curva == null)
                continue;
            for (int extremo = 0; extremo < 2; extremo++)
            {
                XYZ p = curva.GetEndPoint(extremo);
                if (Math.Abs(p.Z - baseInferior.Z) > toleranciaZ)
                    continue;
                XYZ desplazamiento = new XYZ(
                    p.X - baseInferior.X,
                    p.Y - baseInferior.Y, 0.0);
                if (desplazamiento.GetLength() > minimo &&
                    desplazamiento.Normalize().DotProduct(afuera) > 0.30)
                    return true;
            }
        }
        return false;
    }

    private Rebar CrearLongitudinalConGanchoInferiorNativoMYG(
        Document doc, Element host, RebarBarType tipo,
        XYZ normal, IList<Curve> curvas,
        XYZ baseInferior, XYZ direccionInterior,
        string descripcion)
    {
        if (doc == null || host == null || tipo == null ||
            normal == null || normal.GetLength() <= Tol ||
            curvas == null || curvas.Count == 0 ||
            baseInferior == null || direccionInterior == null)
            return null;

        RebarHookType tipo90 = ResolverGanchoLongitudinal90(doc, tipo);
        if (tipo90 == null)
        {
            ultimoErrorCreacion = descripcion +
                ": No hay gancho ESTÁNDAR de 90° habilitado para '" +
                tipo.Name + "'. No utilizar Estribo/Tirante para longitudinales.";
            return null;
        }

        string diagnostico = "";
        foreach (RebarTerminationOrientation lado in new[]
        {
            RebarTerminationOrientation.Right,
            RebarTerminationOrientation.Left
        })
        {
            foreach (bool existente in new[] { true, false })
            {
                using (SubTransaction sub = new SubTransaction(doc))
                {
                    sub.Start();
                    try
                    {
                        Rebar barra;
                        using (BarTerminationsData term =
                            new BarTerminationsData(doc))
                        {
                            // NO colocar HookTypeIdAtStart: el extremo
                            // SUPERIOR es la primera curva, ya dibujado.
                            term.HookTypeIdAtEnd = tipo90.Id;
                            term.TerminationOrientationAtEnd = lado;
                            term.TerminationRotationAngleAtEnd = 0.0;

                            barra = Rebar.CreateFromCurves(
                                doc, RebarStyle.Standard, tipo, host,
                                normal.Normalize(), curvas, term,
                                existente, !existente);
                        }

                        if (barra == null)
                        {
                            diagnostico = "Revit no encontró RebarShape " +
                                "compatible con gancho nativo al final.";
                            sub.RollBack();
                            continue;
                        }
                        EstablecerRebarIndividual(barra);
                        doc.Regenerate();

                        if (barra.GetHookTypeId(1) != tipo90.Id ||
                            barra.GetHookTypeId(0) != ElementId.InvalidElementId)
                        {
                            diagnostico = "Revit no conservó el gancho SOLO " +
                                "en el final inferior.";
                            sub.RollBack();
                            continue;
                        }
                        if (!GanchoInferiorNativoApuntaHaciaAfueraMYG(
                            barra, baseInferior, direccionInterior))
                        {
                            diagnostico = "Gancho nativo " + lado +
                                " no orientado hacia afuera del concreto.";
                            sub.RollBack();
                            continue;
                        }

                        double longitud = ObtenerParametroLongitud(
                            barra, BuiltInParameter.REBAR_ELEM_LENGTH);
                        double longitudTotal = ObtenerParametroLongitud(
                            barra, BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH);
                        if (longitud <= TolGeometria ||
                            longitudTotal <= TolGeometria)
                        {
                            diagnostico = "Revit devolvió metrados de " +
                                "longitud nulos para el gancho inferior nativo.";
                            sub.RollBack();
                            continue;
                        }

                        sub.Commit();
                        ultimoErrorCreacion = "";
                        return barra;
                    }
                    catch (Exception ex)
                    {
                        diagnostico = ex.GetType().Name + ": " + ex.Message;
                        try
                        {
                            if (sub.GetStatus() == TransactionStatus.Started)
                                sub.RollBack();
                        }
                        catch { }
                    }
                }
            }
        }
        ultimoErrorCreacion = descripcion +
            ": no se pudo crear el gancho NATIVO inferior al final. " +
            diagnostico;
        return null;
    }

    private Rebar CrearLongitudinalConCurvasValidado(
        Document doc,
        Element host,
        RebarBarType tipo,
        XYZ normal,
        IList<Curve> curvas,
        string descripcion)
    {
        if (doc == null || host == null || tipo == null ||
            normal == null || normal.GetLength() <= Tol ||
            curvas == null || curvas.Count == 0)
        {
            return null;
        }

        double longitudCurvas = curvas
            .Where(x => x != null)
            .Sum(x => x.Length);
        bool[] usarExistente = new bool[] { true, false };

        foreach (bool reutilizar in usarExistente)
        {
            using (SubTransaction sub = new SubTransaction(doc))
            {
                sub.Start();
                try
                {
                    Rebar rebar;
                    using (BarTerminationsData terminaciones =
                        new BarTerminationsData(doc))
                    {
                        rebar = Rebar.CreateFromCurves(
                            doc,
                            RebarStyle.Standard,
                            tipo,
                            host,
                            normal.Normalize(),
                            curvas,
                            terminaciones,
                            reutilizar,
                            !reutilizar);
                    }

                    if (rebar == null)
                    {
                        sub.RollBack();
                        continue;
                    }

                    EstablecerRebarIndividual(rebar);
                    doc.Regenerate();

                    double longitudBarra = ObtenerParametroLongitud(
                        rebar,
                        BuiltInParameter.REBAR_ELEM_LENGTH);
                    double longitudTotal = ObtenerParametroLongitud(
                        rebar,
                        BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH);
                    double longitudCentro = ObtenerLongitudCentroRebar(rebar);

                    bool valida = longitudBarra > TolGeometria &&
                        longitudTotal > TolGeometria &&
                        longitudCentro > TolGeometria;

                    if (valida && longitudCurvas > TolGeometria)
                    {
                        double diferenciaRelativa = Math.Abs(
                            longitudBarra - longitudCurvas) /
                            longitudCurvas;
                        valida = diferenciaRelativa <= 0.10;
                    }

                    if (!valida)
                    {
                        ultimoErrorCreacion =
                            descripcion +
                            " - Revit creó la pieza pero no calculó una " +
                            "longitud desarrollada válida.";
                        sub.RollBack();
                        continue;
                    }

                    sub.Commit();
                    return rebar;
                }
                catch (Exception ex)
                {
                    ultimoErrorCreacion =
                        descripcion + " - " + ex.GetType().Name +
                        ": " + ex.Message;
                    try
                    {
                        if (sub.GetStatus() == TransactionStatus.Started)
                            sub.RollBack();
                    }
                    catch
                    {
                    }
                }
            }
        }

        return null;
    }

    private List<PuntoLocal> GenerarCentrosGrupoLongitudinal(
        PuntoLocal inicio,
        PuntoLocal fin,
        AceroColumnaGrupoLongitudinal2D grupo)
    {
        List<PuntoLocal> resultado = new List<PuntoLocal>();
        if (inicio == null || fin == null || grupo == null)
            return resultado;

        double longitud = Distancia(inicio, fin);
        int cantidad = CalcularCantidadGrupoLongitudinal(inicio, fin, grupo);
        if (cantidad <= 0)
            return resultado;

        double espaciado = ConvertirCm(System.Math.Max(0.10, grupo.EspaciadoCm));
        for (int i = 0; i < cantidad; i++)
        {
            if ((i == 0 && grupo.OmitirPrimeraBarra) ||
                (i == cantidad - 1 && grupo.OmitirUltimaBarra))
            {
                continue;
            }

            double t;
            if (cantidad <= 1 || longitud <= Tol)
            {
                t = 0.0;
            }
            else if (grupo.Regla ==
                AceroColumnaReglaGrupoLongitudinal.NumeroConEspaciado)
            {
                t = System.Math.Min(1.0, (i * espaciado) / longitud);
            }
            else
            {
                t = (double)i / (cantidad - 1);
            }

            resultado.Add(new PuntoLocal(
                inicio.X + (fin.X - inicio.X) * t,
                inicio.Y + (fin.Y - inicio.Y) * t));
        }
        return resultado;
    }

    private int CalcularCantidadGrupoLongitudinal(
        PuntoLocal inicio,
        PuntoLocal fin,
        AceroColumnaGrupoLongitudinal2D grupo)
    {
        if (inicio == null || fin == null || grupo == null)
            return 0;

        double longitud = Distancia(inicio, fin);
        if (longitud <= Tol)
            return 1;

        if (grupo.Regla ==
            AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo)
        {
            double esp = ConvertirCm(System.Math.Max(0.10, grupo.EspaciadoCm));
            return System.Math.Max(
                2,
                (int)System.Math.Ceiling(longitud / esp) + 1);
        }

        return System.Math.Max(1, System.Math.Min(1002, grupo.Cantidad));
    }

    private int CalcularCantidadFisicaGrupoLongitudinal(
        PuntoLocal inicio,
        PuntoLocal fin,
        AceroColumnaGrupoLongitudinal2D grupo)
    {
        int cantidad = CalcularCantidadGrupoLongitudinal(inicio, fin, grupo);
        if (cantidad <= 0 || grupo == null)
            return 0;

        int fisica = cantidad;
        if (grupo.OmitirPrimeraBarra)
            fisica--;
        if (cantidad > 1 && grupo.OmitirUltimaBarra)
            fisica--;

        return System.Math.Max(0, fisica);
    }

    private string ObtenerTextoReglaGrupo(
        AceroColumnaGrupoLongitudinal2D grupo)
    {
        if (grupo == null)
            return "sin regla";

        if (grupo.Regla ==
            AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo)
        {
            return "espaciado máximo " +
                grupo.EspaciadoCm.ToString("0.##", CultureInfo.InvariantCulture) +
                " cm";
        }

        if (grupo.Regla ==
            AceroColumnaReglaGrupoLongitudinal.NumeroConEspaciado)
        {
            return grupo.Cantidad + " barras @ " +
                grupo.EspaciadoCm.ToString("0.##", CultureInfo.InvariantCulture) +
                " cm";
        }

        return "número fijo " + grupo.Cantidad;
    }

    // ================================================================
    // DIRECCIÓN COMÚN DE GANCHOS PARA UN REBAR SET LONGITUDINAL
    // ================================================================
    // Se calcula UNA SOLA dirección para todo el conjunto.
    // No se orienta cada barra hacia el centro geométrico.
    // La dirección elegida es perpendicular a la línea de distribución y
    // se selecciona el sentido que entra al concreto.
    // =============================================================
    // MYG - DIRECCION HACIA CONCRETO: SIN CENTROIDE NI NUCLEO
    // =============================================================
    // Las dos normales del GRUPO se examinan contra el contorno local.
    // La profundidad orienta el doblez, pero NO limita su longitud.
    // Se conserva UNA orientacion para todas las posiciones del set.
    private double ProfundidadInteriorRayMYG(
        List<PuntoLocal> region, PuntoLocal p, double nx, double ny)
    {
        if (region == null || region.Count < 3 || p == null)
            return 0.0;

        // Si ni siquiera 2 mm de avance entran en el concreto, es
        // la direccion exterior. Un punto justo sobre una cara es valido.
        double test = ConvertirCm(0.2);
        PuntoLocal muestra = new PuntoLocal(
            p.X + nx * test, p.Y + ny * test);
        if (!PuntoDentroPoligono(muestra, region))
            return 0.0;

        double minimo = double.MaxValue;
        for (int i = 0; i < region.Count; i++)
        {
            PuntoLocal a = region[i];
            PuntoLocal b = region[(i + 1) % region.Count];
            if (a == null || b == null)
                continue;

            double ex = b.X - a.X;
            double ey = b.Y - a.Y;
            double determinante = nx * ey - ny * ex;
            if (Math.Abs(determinante) <= 1e-12)
                continue;

            double qx = a.X - p.X;
            double qy = a.Y - p.Y;
            double t = (qx * ey - qy * ex) / determinante;
            double u = (qx * ny - qy * nx) / determinante;

            if (t > TolGeometria &&
                u >= -TolGeometria && u <= 1.0 + TolGeometria &&
                t < minimo)
            {
                minimo = t;
            }
        }
        return minimo < double.MaxValue ? minimo : 0.0;
    }

    private double ProfundidadMinimaGrupoMYG(
        DatosColumna datos,
        IList<PuntoLocal> posiciones,
        double nx, double ny)
    {
        if (datos == null || posiciones == null || posiciones.Count == 0)
            return 0.0;

        double profundidad = double.MaxValue;
        foreach (PuntoLocal p in posiciones)
        {
            if (p == null)
                continue;
            List<PuntoLocal> region = ObtenerContornoAdecuado(
                datos, new List<PuntoLocal> { p });
            double d = ProfundidadInteriorRayMYG(region, p, nx, ny);
            if (d <= TolGeometria)
                return 0.0;
            profundidad = Math.Min(profundidad, d);
        }
        return profundidad < double.MaxValue ? profundidad : 0.0;
    }

    // Solo se usa para una barra que SI FUE DIBUJADA individualmente.
    // Se calcula la normal de la cara mas cercana, NO un vector al centro.
    private XYZ ObtenerInteriorLocalDeBarraMYG(
        DatosColumna datos, PuntoLocal posicion)
    {
        if (datos == null || posicion == null)
            return null;

        List<PuntoLocal> region = ObtenerContornoAdecuado(
            datos, new List<PuntoLocal> { posicion });
        if (region == null || region.Count < 3)
            return null;

        double mejorDistanciaCara = double.MaxValue;
        double mejorProfundidad = 0.0;
        double mejorX = 0.0;
        double mejorY = 0.0;

        for (int i = 0; i < region.Count; i++)
        {
            PuntoLocal a = region[i];
            PuntoLocal b = region[(i + 1) % region.Count];
            double ex = b.X - a.X;
            double ey = b.Y - a.Y;
            double largo = Math.Sqrt(ex * ex + ey * ey);
            if (largo <= TolGeometria)
                continue;

            double distancia = DistanciaPuntoSegmento(posicion, a, b);
            double nx = -ey / largo;
            double ny = ex / largo;
            double pMas = ProfundidadInteriorRayMYG(
                region, posicion, nx, ny);
            double pMenos = ProfundidadInteriorRayMYG(
                region, posicion, -nx, -ny);
            double prof = Math.Max(pMas, pMenos);
            if (prof <= TolGeometria)
                continue;

            // Cara local mas cercana; ante empate, direccion con mas
            // concreto. Ningun centro geometrico entra en el calculo.
            if (distancia < mejorDistanciaCara - TolGeometria ||
                (Math.Abs(distancia - mejorDistanciaCara) <= TolGeometria &&
                 prof > mejorProfundidad))
            {
                mejorDistanciaCara = distancia;
                mejorProfundidad = prof;
                mejorX = pMas >= pMenos ? nx : -nx;
                mejorY = pMas >= pMenos ? ny : -ny;
            }
        }

        if (mejorProfundidad <= TolGeometria)
            return null;

        XYZ mundo = datos.EjeX.Multiply(mejorX)
            .Add(datos.EjeY.Multiply(mejorY));
        XYZ horizontal = new XYZ(mundo.X, mundo.Y, 0.0);
        return horizontal.GetLength() > Tol
            ? horizontal.Normalize() : null;
    }

    private class TramoEmpalmadoSetMYG
    {
        public double Inicio;
        public double Fin;
        public bool Primera;
        public bool Ultima;
    }

    // Un unico planificador para grupos y barras originalmente individuales.
    // En los grupos CADA pieza devuelve un unico Rebar Set con la misma regla.
    private List<Rebar> CrearPiezasLongitudinalesConQuiebreMYG(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        PuntoLocal inicio,
        PuntoLocal fin,
        RebarBarType tipo,
        AceroColumnaGrupoLongitudinal2D grupo,
        double recubrimiento,
        double anclajeInferior,
        double prolongacionSuperior,
        double zInferiorGrupo,
        double zSuperiorGrupo,
        bool ubicarEmpalmesMitadCentralE060,
        double longitudComercial,
        double longitudEmpalme,
        List<ZonaEmpalmeLongitudinal> zonasMitadCentralGrupo)
    {
        List<Rebar> resultado = new List<Rebar>();
        if (doc == null || host == null || datos == null ||
            inicio == null || tipo == null)
            return resultado;

        bool esSet = grupo != null;
        double longitudDistribucion = esSet ? Distancia(inicio, fin) : 0.0;
        if (esSet && (fin == null || longitudDistribucion <= TolGeometria))
            return resultado;

        double zBase = zInferiorGrupo - Math.Max(0.0, anclajeInferior);
        double zTope = zSuperiorGrupo - Math.Max(0.0, recubrimiento) +
            Math.Max(0.0, prolongacionSuperior);
        double L = zTope - zBase;
        if (L <= TolGeometria)
            return resultado;

        double diametro = ObtenerDiametroBarra(tipo);
        double diametroModelo = ObtenerDiametroModeloBarra(tipo);
        double longitudGancho = Math.Max(6.0 * diametro, ConvertirCm(10.0));
        double desfase = Math.Max(
            Math.Max(diametro, diametroModelo) + ConvertirCm(0.2),
            ConvertirCm(1.0));
        double tramoQuiebre = Math.Max(6.0 * diametro, ConvertirCm(10.0));
        double excesoDiagonal = Math.Sqrt(
            tramoQuiebre * tramoQuiebre + desfase * desfase) - tramoQuiebre;
        double margenLongitud = ConvertirCm(0.2);

        List<PuntoLocal> posiciones;
        XYZ dirDistribucion;
        XYZ dirInterior;
        if (esSet)
        {
            posiciones = GenerarCentrosGrupoLongitudinal(inicio, fin, grupo);
            if (posiciones == null || posiciones.Count == 0)
                return resultado;
            dirDistribucion = datos.EjeX.Multiply(fin.X - inicio.X)
                .Add(datos.EjeY.Multiply(fin.Y - inicio.Y));
            if (dirDistribucion.GetLength() <= Tol)
                return resultado;
            dirDistribucion = dirDistribucion.Normalize();
            dirInterior = ObtenerDireccionComunGanchoGrupoLongitudinal(
                datos, inicio, fin, grupo);
        }
        else
        {
            posiciones = new List<PuntoLocal> { inicio };
            dirDistribucion = null;
            dirInterior = ObtenerInteriorLocalDeBarraMYG(datos, inicio);
        }

        if (dirInterior == null || dirInterior.GetLength() <= Tol)
        {
            ultimoErrorCreacion =
                "No existe una normal comun hacia el concreto para esta " +
                "distribucion; no se convertira el conjunto a individuales.";
            return resultado;
        }
        dirInterior = dirInterior.Normalize();

        // La seccion solo determina el SENTIDO del doblez.
        // Se conserva la longitud completa aunque sobrepase la cara opuesta.

        if (L + 2.0 * longitudGancho > longitudComercial &&
            longitudComercial <= longitudEmpalme +
            tramoQuiebre + longitudGancho + ConvertirCm(5.0))
        {
            ultimoErrorCreacion =
                "La longitud comercial no permite el quiebre, " +
                "el empalme ni el gancho de la primera pieza.";
            return resultado;
        }

        List<ZonaEmpalmeLongitudinal> zonas =
            ubicarEmpalmesMitadCentralE060
                ? ConvertirZonasEmpalmeAEstaciones(
                    zonasMitadCentralGrupo, zBase, zTope)
                : new List<ZonaEmpalmeLongitudinal>();
        if (ubicarEmpalmesMitadCentralE060 && zonas.Count == 0 &&
            L + 2.0 * longitudGancho > longitudComercial)
        {
            ultimoErrorCreacion =
                "E.060 activo: no se detectaron zonas de mitad central " +
                "en los elementos seleccionados.";
            return resultado;
        }

        // La geometria NO puede avanzar al siguiente empalme si la pieza
        // anterior no llega hasta la estacion de empalme + el traslape.
        List<TramoEmpalmadoSetMYG> plan =
            new List<TramoEmpalmadoSetMYG>();
        double s = 0.0;
        int seguridad = 0;
        while (s < L - TolGeometria && seguridad++ < 500)
        {
            bool primera = plan.Count == 0;
            double gastosFinales = longitudGancho +
                (primera ? longitudGancho : 0.0);
            double resto = L - s;
            if (resto + gastosFinales <=
                longitudComercial - margenLongitud + TolGeometria)
            {
                plan.Add(new TramoEmpalmadoSetMYG
                {
                    Inicio = s,
                    Fin = L,
                    Primera = primera,
                    Ultima = true
                });
                break;
            }

            // Se descuenta el gancho inferior (primera pieza) y la longitud
            // adicional de la diagonal. La ultima pieza descuenta el superior.
            double axialMax = longitudComercial - margenLongitud -
                (primera ? longitudGancho : 0.0) - excesoDiagonal;
            if (axialMax <= longitudEmpalme +
                tramoQuiebre + ConvertirCm(5.0) + TolGeometria)
            {
                ultimoErrorCreacion =
                    "La longitud comercial es insuficiente para crear " +
                    "el detalle con quiebre y traslape.";
                return resultado;
            }

            double finMax = Math.Min(
                s + axialMax,
                L - ConvertirCm(5.0) + longitudEmpalme);
            double finMin = s + longitudEmpalme +
                tramoQuiebre + ConvertirCm(5.0);
            double finElegido = finMax;

            if (ubicarEmpalmesMitadCentralE060)
            {
                finElegido = double.NaN;
                foreach (ZonaEmpalmeLongitudinal zona in zonas)
                {
                    // Quiebre y solape COMPLETOS dentro de una mitad central.
                    double minimo = Math.Max(
                        finMin,
                        zona.Inicio + tramoQuiebre + longitudEmpalme);
                    double maximo = Math.Min(finMax, zona.Fin);
                    if (maximo + TolGeometria < minimo)
                        continue;
                    if (double.IsNaN(finElegido) || maximo > finElegido)
                        finElegido = maximo;
                }
                if (double.IsNaN(finElegido))
                {
                    ultimoErrorCreacion =
                        "E.060: no hay mitad central alcanzable que aloje " +
                        "el quiebre y todo el empalme sin superar la " +
                        "longitud comercial. Revise la altura de las columnas, " +
                        "el valor del empalme o la longitud comercial.";
                    return resultado;
                }
            }

            if (finElegido < finMin - TolGeometria)
            {
                ultimoErrorCreacion =
                    "No existe longitud suficiente para el quiebre y empalme.";
                return resultado;
            }

            double siguiente = finElegido - longitudEmpalme;
            if (siguiente <= s + TolGeometria ||
                siguiente >= L - TolGeometria)
            {
                ultimoErrorCreacion =
                    "Empalme sin avance positivo o ultima pieza invalida.";
                return resultado;
            }
            plan.Add(new TramoEmpalmadoSetMYG
            {
                Inicio = s,
                Fin = finElegido,
                Primera = primera,
                Ultima = false
            });
            s = siguiente;
        }

        if (seguridad >= 500 || plan.Count == 0 ||
            !plan[plan.Count - 1].Ultima)
        {
            ultimoErrorCreacion =
                "No fue posible cerrar el plan de piezas comerciales.";
            return resultado;
        }

        XYZ normal;
        if (esSet)
            normal = dirDistribucion;
        else
        {
            normal = XYZ.BasisZ.CrossProduct(dirInterior);
            if (normal.GetLength() <= Tol)
                normal = datos.EjeX;
            normal = normal.Normalize();
        }

        foreach (TramoEmpalmadoSetMYG tramo in plan)
        {
            // CADA pieza empieza sobre la posicion dibujada por el usuario.
            // El ultimo tramo de la pieza anterior entra +desfase al concreto.
            // NO se hace comenzar la pieza siguiente en +desfase, porque eso
            // volvia a SUPERPONER los dos longitudinales durante el traslape.
            XYZ p0 = LocalAMundial(
                datos, inicio, zBase + tramo.Inicio);
            XYZ pFinEje = LocalAMundial(
                datos, inicio, zBase + tramo.Fin);
            List<Curve> curvas = new List<Curve>();

            // Gancho inferior NATIVO se agregará después y solamente
            // a la primera pieza comercial, no al boceto.

            if (tramo.Ultima)
            {
                curvas.Add(Line.CreateBound(p0, pFinEje));
                XYZ libreSup = pFinEje.Add(
                    dirInterior.Multiply(longitudGancho));
                curvas.Add(Line.CreateBound(pFinEje, libreSup));
            }
            else
            {
                double zInicioEmpalme = tramo.Fin - longitudEmpalme;
                double zInicioQuiebre = zInicioEmpalme - tramoQuiebre;
                XYZ pAntes = LocalAMundial(
                    datos, inicio, zBase + zInicioQuiebre);
                XYZ pDespues = LocalAMundial(
                    datos, inicio, zBase + zInicioEmpalme)
                    .Add(dirInterior.Multiply(desfase));
                XYZ pExtremo = pFinEje.Add(
                    dirInterior.Multiply(desfase));
                if (p0.DistanceTo(pAntes) > TolGeometria)
                    curvas.Add(Line.CreateBound(p0, pAntes));
                curvas.Add(Line.CreateBound(pAntes, pDespues));
                curvas.Add(Line.CreateBound(pDespues, pExtremo));
            }

            Rebar pieza;
            if (tramo.Primera)
            {
                // Última curva termina físicamente abajo para que la API
                // asigne HookTypeIdAtEnd al ANCLAJE INFERIOR.
                List<Curve> curvasInvertidas =
                    InvertirCadenaLongitudinalMYG(curvas);
                pieza = CrearLongitudinalConGanchoInferiorNativoMYG(
                    doc, host, tipo, normal, curvasInvertidas,
                    p0, dirInterior,
                    "primera pieza de empalme - gancho inferior nativo");
            }
            else
            {
                pieza = CrearLongitudinalConCurvasValidado(
                    doc, host, tipo, normal, curvas,
                    "pieza longitudinal con quiebre y orientacion local al concreto");
            }
            if (pieza == null)
            {
                foreach (Rebar r in resultado)
                    EliminarElementoSeguro(doc, r.Id);
                resultado.Clear();
                return resultado;
            }

            try
            {
                if (esSet)
                {
                    RebarShapeDrivenAccessor accessor =
                        pieza.GetShapeDrivenAccessor();
                    if (accessor == null)
                        throw new InvalidOperationException(
                            "La pieza no admite regla Rebar Set.");
                    int cantidad = CalcularCantidadGrupoLongitudinal(
                        inicio, fin, grupo);
                    if (CalcularCantidadFisicaGrupoLongitudinal(
                            inicio, fin, grupo) <= 0)
                        throw new InvalidOperationException(
                            "El grupo no tiene posiciones visibles.");
                    double espacio = ConvertirCm(
                        Math.Max(0.10, grupo.EspaciadoCm));
                    bool primeraVisible = !grupo.OmitirPrimeraBarra;
                    bool ultimaVisible = !grupo.OmitirUltimaBarra;
                    if (cantidad <= 1)
                        accessor.SetLayoutAsSingle();
                    else if (grupo.Regla ==
                        AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo)
                        accessor.SetLayoutAsMaximumSpacing(
                            espacio, longitudDistribucion,
                            true, primeraVisible, ultimaVisible);
                    else if (grupo.Regla ==
                        AceroColumnaReglaGrupoLongitudinal.NumeroConEspaciado)
                        accessor.SetLayoutAsNumberWithSpacing(
                            cantidad, espacio,
                            true, primeraVisible, ultimaVisible);
                    else
                        accessor.SetLayoutAsFixedNumber(
                            cantidad, longitudDistribucion,
                            true, primeraVisible, ultimaVisible);
                }
                doc.Regenerate();

                // La longitud comercial es la de CADA barra del set, no
                // la suma de todas sus posiciones.
                double largo = ObtenerParametroLongitud(
                    pieza, BuiltInParameter.REBAR_ELEM_LENGTH);
                if (largo <= TolGeometria)
                    throw new InvalidOperationException(
                        "Revit no calculó la longitud nativa de esta pieza.");
                if (largo > longitudComercial + ConvertirCm(0.3))
                    throw new InvalidOperationException(
                        "Pieza supera la longitud comercial: " +
                        UnitUtils.ConvertFromInternalUnits(
                            largo, UnitTypeId.Meters).ToString(
                                "0.###", CultureInfo.InvariantCulture) + " m.");
                resultado.Add(pieza);
            }
            catch (Exception ex)
            {
                EliminarElementoSeguro(doc, pieza.Id);
                foreach (Rebar r in resultado)
                    EliminarElementoSeguro(doc, r.Id);
                resultado.Clear();
                ultimoErrorCreacion =
                    "Error aplicando regla/longitud comercial: " + ex.Message;
                return resultado;
            }
        }

        ultimoErrorCreacion = "";
        return resultado;
    }

    private XYZ ObtenerDireccionComunGanchoGrupoLongitudinal(
        DatosColumna datos,
        PuntoLocal inicio,
        PuntoLocal fin,
        AceroColumnaGrupoLongitudinal2D grupo = null)
    {
        if (datos == null || inicio == null || fin == null)
            return null;
        double dx = fin.X - inicio.X;
        double dy = fin.Y - inicio.Y;
        double modulo = Math.Sqrt(dx * dx + dy * dy);
        if (modulo <= TolGeometria)
            return null;

        // Solo dos posibilidades para TODO el Rebar Set:
        // normales perpendiculares a la linea de distribucion.
        double nx = -dy / modulo;
        double ny = dx / modulo;
        // Las posiciones reales del set se usan SOLO para elegir UNA
        // normal compartida. Se ignoran las posiciones ocultas, si las hay.
        List<PuntoLocal> posiciones = grupo != null
            ? GenerarCentrosGrupoLongitudinal(inicio, fin, grupo)
            : new List<PuntoLocal>();
        if (posiciones == null)
            posiciones = new List<PuntoLocal>();
        if (posiciones.Count == 0)
        {
            for (int i = 0; i <= 4; i++)
            {
                double t = i / 4.0;
                posiciones.Add(new PuntoLocal(
                    inicio.X + dx * t, inicio.Y + dy * t));
            }
        }
        double a = ProfundidadMinimaGrupoMYG(
            datos, posiciones, nx, ny);
        double b = ProfundidadMinimaGrupoMYG(
            datos, posiciones, -nx, -ny);
        // Una posicion sin concreto en una de las normales no invalida
        // todo el conjunto. Si la profundidad minima no distingue sentidos,
        // se compara el recorrido total de las posiciones reales. Esto SOLO
        // orienta: no limita la longitud del gancho ni mueve las barras.
        if (Math.Abs(a - b) <= TolGeometria)
        {
            a = 0.0;
            b = 0.0;
            foreach (PuntoLocal p in posiciones)
            {
                if (p == null)
                    continue;
                List<PuntoLocal> region = ObtenerContornoAdecuado(
                    datos, new List<PuntoLocal> { p });
                a += ProfundidadInteriorRayMYG(region, p, nx, ny);
                b += ProfundidadInteriorRayMYG(region, p, -nx, -ny);
            }
        }
        if (Math.Abs(a - b) <= TolGeometria)
        {
            // Desempate geometrico: normal interior de la cara paralela
            // mas cercana al punto medio. No usa el centroide ni cambia
            // la normal entre barras; funciona tambien con extremos fuera.
            PuntoLocal medio = new PuntoLocal(
                (inicio.X + fin.X) * 0.5, (inicio.Y + fin.Y) * 0.5);
            List<PuntoLocal> region = ObtenerContornoAdecuado(
                datos, new List<PuntoLocal> { medio });
            if (region == null || region.Count < 3)
                return null;
            double areaDoble = 0.0;
            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal p = region[i];
                PuntoLocal q = region[(i + 1) % region.Count];
                areaDoble += p.X * q.Y - q.X * p.Y;
            }
            if (Math.Abs(areaDoble) <= Tol * Tol)
                return null;
            double mejorDistancia = double.MaxValue;
            double mejorAlineacion = -1.0;
            double sentido = 1.0;
            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal p = region[i];
                PuntoLocal q = region[(i + 1) % region.Count];
                double ex = q.X - p.X;
                double ey = q.Y - p.Y;
                double largo = Math.Sqrt(ex * ex + ey * ey);
                if (largo <= TolGeometria)
                    continue;
                double signo = areaDoble > 0.0 ? 1.0 : -1.0;
                double producto = signo * (-ey * nx + ex * ny) / largo;
                double alineacion = Math.Abs(producto);
                double distancia = DistanciaPuntoSegmento(medio, p, q);
                if (alineacion > mejorAlineacion + TolGeometria ||
                    (Math.Abs(alineacion - mejorAlineacion) <= TolGeometria &&
                     distancia < mejorDistancia))
                {
                    mejorAlineacion = alineacion;
                    mejorDistancia = distancia;
                    sentido = producto >= 0.0 ? 1.0 : -1.0;
                }
            }
            if (mejorAlineacion <= Tol)
                return null;
            a = sentido;
            b = -sentido;
        }
        if (b > a)
        {
            nx = -nx;
            ny = -ny;
        }
        XYZ v = datos.EjeX.Multiply(nx)
            .Add(datos.EjeY.Multiply(ny));
        XYZ h = new XYZ(v.X, v.Y, 0.0);
        return h.GetLength() > Tol ? h.Normalize() : null;
    }

    private List<Curve> CrearCurvasGrupoLongitudinalCon90Comun(
        XYZ puntoBase,
        XYZ puntoSuperior,
        XYZ direccionInteriorComun,
        double longitudGancho)
    {
        List<Curve> curvas = new List<Curve>();

        if (puntoBase == null || puntoSuperior == null ||
            direccionInteriorComun == null ||
            direccionInteriorComun.GetLength() <= Tol)
        {
            return curvas;
        }

        XYZ interior = new XYZ(
            direccionInteriorComun.X,
            direccionInteriorComun.Y,
            0.0);

        if (interior.GetLength() <= Tol)
            return curvas;

        interior = interior.Normalize();

        double lg = Math.Max(
            longitudGancho,
            ConvertirCm(10.0));

        // Revit dibujará el gancho INFERIOR como terminación NATIVA
        // en el FINAL de la barra. Se invierte el sentido de las curvas,
        // pero NO se cambia la posición ni la geometría del eje.
        // El gancho SUPERIOR permanece dibujado en el boceto.
        XYZ extremoSuperior =
            puntoSuperior.Add(interior.Multiply(lg));

        curvas.Add(Line.CreateBound(extremoSuperior, puntoSuperior));
        curvas.Add(Line.CreateBound(puntoSuperior, puntoBase));

        return curvas;
    }

    private Rebar CrearGrupoLongitudinal(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        PuntoLocal inicio,
        PuntoLocal fin,
        RebarBarType tipo,
        AceroColumnaGrupoLongitudinal2D grupo,
        double recubrimiento,
        double anclajeInferior,
        double prolongacionSuperior,
        double zInferiorGrupo,
        double zSuperiorGrupo)
    {
        if (doc == null || host == null || datos == null || inicio == null ||
            fin == null || tipo == null || grupo == null)
        {
            return null;
        }

        double longitudDistribucion = Distancia(inicio, fin);
        if (longitudDistribucion <= Tol)
            return null;

        // SE CONSERVAN EXACTAMENTE LAS COTAS DEL CÓDIGO ORIGINAL.
        double zBase =
            zInferiorGrupo -
            System.Math.Max(0.0, anclajeInferior);

        double zSuperior =
            zSuperiorGrupo -
            System.Math.Max(0.0, recubrimiento) +
            System.Math.Max(0.0, prolongacionSuperior);

        if (zSuperior <= zBase + Tol)
            return null;

        // SE CONSERVA EXACTAMENTE LA POSICIÓN ORIGINAL DEL PRIMER ELEMENTO
        // DEL SET. No se mueve hacia el centro ni se recalcula por barra.
        XYZ puntoBase =
            LocalAMundial(
                datos,
                inicio,
                zBase);

        XYZ puntoSuperior =
            LocalAMundial(
                datos,
                inicio,
                zSuperior);

        XYZ direccionDistribucion =
            datos.EjeX.Multiply(fin.X - inicio.X)
                .Add(datos.EjeY.Multiply(fin.Y - inicio.Y));

        if (direccionDistribucion == null ||
            direccionDistribucion.GetLength() <= Tol)
        {
            return null;
        }

        direccionDistribucion =
            direccionDistribucion.Normalize();

        // UNA SOLA ORIENTACIÓN PARA TODAS LAS POSICIONES DEL SET.
        XYZ direccionInteriorComun =
            ObtenerDireccionComunGanchoGrupoLongitudinal(
                datos,
                inicio,
                fin,
                grupo);

        double diametro =
            ObtenerDiametroBarra(tipo);

        double longitudGancho =
            Math.Max(
                diametro * 6.0,
                ConvertirCm(10.0));

        if (direccionInteriorComun == null ||
            direccionInteriorComun.GetLength() <= Tol)
        {
            ultimoErrorCreacion =
                "No se encontro una direccion comun hacia el concreto " +
                "compatible con las posiciones del Rebar Set.";
            return null;
        }
        // La seccion solo determina el SENTIDO del doblez.
        // Se conserva la longitud completa aunque sobrepase la cara opuesta.

        List<Curve> curvas =
            CrearCurvasGrupoLongitudinalCon90Comun(
                puntoBase,
                puntoSuperior,
                direccionInteriorComun,
                longitudGancho);

        if (curvas == null || curvas.Count != 2)
        {
            ultimoErrorCreacion =
                "No se pudo construir la forma longitudinal común del conjunto.";
            return null;
        }

        // IMPORTANTE:
        // El normal coincide con la dirección de distribución.
        // Por eso Revit replica UNA MISMA FORMA a lo largo del conjunto,
        // manteniendo todos los ganchos paralelos.
        Rebar rebar =
            CrearLongitudinalConGanchoInferiorNativoMYG(
                doc, host, tipo, direccionDistribucion, curvas,
                puntoBase, direccionInteriorComun,
                "grupo longitudinal - gancho inferior nativo al final");

        if (rebar == null)
            return null;

        try
        {
            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            if (accessor == null)
                return rebar;

            int cantidad =
                CalcularCantidadGrupoLongitudinal(
                    inicio,
                    fin,
                    grupo);

            int cantidadFisica =
                CalcularCantidadFisicaGrupoLongitudinal(
                    inicio,
                    fin,
                    grupo);

            if (cantidadFisica <= 0)
            {
                doc.Delete(rebar.Id);
                return null;
            }

            double espaciamiento =
                ConvertirCm(
                    System.Math.Max(
                        0.10,
                        grupo.EspaciadoCm));

            bool incluirPrimera =
                !grupo.OmitirPrimeraBarra;

            bool incluirUltima =
                !grupo.OmitirUltimaBarra;

            // ========================================================
            // LA REGLA INGRESADA EN LA VENTANA SIEMPRE PREVALECE.
            // ========================================================
            if (cantidad <= 1)
            {
                accessor.SetLayoutAsSingle();
            }
            else if (grupo.Regla ==
                AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo)
            {
                accessor.SetLayoutAsMaximumSpacing(
                    espaciamiento,
                    longitudDistribucion,
                    true,
                    incluirPrimera,
                    incluirUltima);
            }
            else if (grupo.Regla ==
                AceroColumnaReglaGrupoLongitudinal.NumeroConEspaciado)
            {
                accessor.SetLayoutAsNumberWithSpacing(
                    cantidad,
                    espaciamiento,
                    true,
                    incluirPrimera,
                    incluirUltima);
            }
            else
            {
                // NÚMERO FIJO: se mantiene exactamente como conjunto.
                accessor.SetLayoutAsFixedNumber(
                    cantidad,
                    longitudDistribucion,
                    true,
                    incluirPrimera,
                    incluirUltima);
            }

            doc.Regenerate();
            ultimoErrorCreacion = "";
            return rebar;
        }
        catch (Exception ex)
        {
            ultimoErrorCreacion =
                "No se pudo aplicar la regla del grupo longitudinal: " +
                ex.Message;

            try
            {
                doc.Delete(rebar.Id);
            }
            catch
            {
            }

            return null;
        }
    }

    private Rebar CrearBarraLongitudinal(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        PuntoLocal posicion,
        RebarBarType tipo,
        double recubrimiento,
        double diametro,
        double anclajeInferior,
        double prolongacionSuperior,
        double zInferiorGrupo,
        double zSuperiorGrupo)
    {
        if (doc == null || host == null || datos == null ||
            posicion == null || tipo == null)
            return null;

        double zi = !double.IsNaN(zInferiorGrupo) &&
                    !double.IsInfinity(zInferiorGrupo)
            ? zInferiorGrupo : datos.ZInferior;
        double zs = !double.IsNaN(zSuperiorGrupo) &&
                    !double.IsInfinity(zSuperiorGrupo)
            ? zSuperiorGrupo : datos.ZSuperior;
        double zBase = zi - Math.Max(0.0, anclajeInferior);
        double zTope = zs - Math.Max(0.0, recubrimiento) +
            Math.Max(0.0, prolongacionSuperior);
        if (zTope <= zBase + TolGeometria)
            return null;

        XYZ interior = ObtenerInteriorLocalDeBarraMYG(datos, posicion);
        if (interior == null || interior.GetLength() <= Tol)
        {
            ultimoErrorCreacion =
                "No se encontro una normal interior de la cara local del concreto.";
            return null;
        }
        double gancho = Math.Max(6.0 * diametro, ConvertirCm(10.0));
        // La seccion solo determina el SENTIDO del doblez.
        // Se conserva la longitud completa aunque sobrepase la cara opuesta.

        XYZ p0 = LocalAMundial(datos, posicion, zBase);
        XYZ p1 = LocalAMundial(datos, posicion, zTope);
        // Boceto solo con gancho SUPERIOR; el INFERIOR se añade
        // como «Gancho al final» nativo de Revit.
        List<Curve> curvas = new List<Curve>
        {
            Line.CreateBound(p1.Add(interior.Multiply(gancho)), p1),
            Line.CreateBound(p1, p0)
        };
        XYZ plano = XYZ.BasisZ.CrossProduct(interior);
        if (plano.GetLength() <= Tol)
            plano = datos.EjeX;
        return CrearLongitudinalConGanchoInferiorNativoMYG(
            doc, host, tipo, plano.Normalize(), curvas,
            p0, interior,
            "barra individual - gancho inferior nativo al final");
    }

    // Crea una barra recta sin permitir que Revit elija automáticamente una
    // RebarShape defectuosa. Primero reutiliza una forma previamente validada
    // para el mismo tipo; después fuerza la creación de una forma nueva; y,
    // como respaldo, prueba de manera explícita las formas estándar existentes.
    // Ninguna barra se acepta mientras "Longitud de barra" y "Longitud total"
    // sigan en cero.
    private Rebar CrearBarraLongitudinalRectaConLongitudValida(
        Document doc,
        RebarBarType tipo,
        Element host,
        XYZ normal,
        IList<Curve> curvas,
        string descripcion)
    {
        if (doc == null || tipo == null || host == null ||
            normal == null || normal.GetLength() <= Tol ||
            curvas == null || curvas.Count == 0)
        {
            return null;
        }

        double longitudEsperada = curvas
            .Where(x => x != null)
            .Sum(x => x.Length);

        if (longitudEsperada <= TolGeometria)
        {
            ultimoErrorCreacion =
                descripcion + " - la curva longitudinal tiene longitud cero.";
            return null;
        }

        long claveTipo = tipo.Id.Value;
        ElementId formaGuardadaId;

        if (formasRectasLongitudinalesValidas.TryGetValue(
                claveTipo,
                out formaGuardadaId) &&
            formaGuardadaId != null &&
            formaGuardadaId != ElementId.InvalidElementId)
        {
            RebarShape formaGuardada =
                doc.GetElement(formaGuardadaId) as RebarShape;

            if (formaGuardada != null)
            {
                Rebar reutilizada = IntentarCrearLongitudinalConFormaEspecifica(
                    doc,
                    formaGuardada,
                    tipo,
                    host,
                    normal,
                    curvas,
                    longitudEsperada,
                    descripcion + " con forma validada");

                if (reutilizada != null)
                    return reutilizada;
            }

            formasRectasLongitudinalesValidas.Remove(claveTipo);
        }

        // No se permite reutilizar una forma existente en este intento. Revit
        // debe generar una RebarShape nueva a partir de la línea recta. Esto
        // evita que seleccione nuevamente la forma 00 que reportaba longitud 0.
        using (SubTransaction subTransaccion = new SubTransaction(doc))
        {
            subTransaccion.Start();

            try
            {
                Rebar rebar;

                using (BarTerminationsData terminaciones =
                    new BarTerminationsData(doc))
                {
                    rebar = Rebar.CreateFromCurves(
                        doc,
                        RebarStyle.Standard,
                        tipo,
                        host,
                        normal.Normalize(),
                        curvas,
                        terminaciones,
                        false,
                        true);
                }

                if (rebar != null)
                {
                    EstablecerRebarIndividual(rebar);
                    doc.Regenerate();

                    string diagnostico;
                    if (EsLongitudRebarValida(
                            rebar,
                            longitudEsperada,
                            out diagnostico))
                    {
                        ElementId formaId = ObtenerIdFormaRebar(rebar);

                        if (formaId != null &&
                            formaId != ElementId.InvalidElementId)
                        {
                            formasRectasLongitudinalesValidas[claveTipo] =
                                formaId;
                        }

                        subTransaccion.Commit();
                        return rebar;
                    }

                    ultimoErrorCreacion =
                        descripcion +
                        " - la forma recta nueva no calculó la longitud: " +
                        diagnostico;
                }
                else
                {
                    ultimoErrorCreacion =
                        descripcion +
                        " - Revit no pudo crear una forma recta nueva.";
                }

                subTransaccion.RollBack();
            }
            catch (Exception ex)
            {
                ultimoErrorCreacion =
                    descripcion + " - forma recta nueva - " +
                    ex.GetType().Name + ": " + ex.Message;

                try
                {
                    if (subTransaccion.GetStatus() ==
                        TransactionStatus.Started)
                    {
                        subTransaccion.RollBack();
                    }
                }
                catch
                {
                }
            }
        }

        // Respaldo: se prueban explícitamente las formas existentes. Al usar
        // CreateFromCurvesAndShape Revit ya no decide por su cuenta qué forma
        // asignar; solo se conserva una forma si reporta longitud correctamente.
        List<RebarShape> formasExistentes =
            new FilteredElementCollector(doc)
                .OfClass(typeof(RebarShape))
                .Cast<RebarShape>()
                .OrderBy(x => x.Name)
                .ToList();

        foreach (RebarShape forma in formasExistentes)
        {
            if (forma == null)
                continue;

            Rebar candidata = IntentarCrearLongitudinalConFormaEspecifica(
                doc,
                forma,
                tipo,
                host,
                normal,
                curvas,
                longitudEsperada,
                descripcion + " con forma " + forma.Name);

            if (candidata == null)
                continue;

            formasRectasLongitudinalesValidas[claveTipo] = forma.Id;
            return candidata;
        }

        if (string.IsNullOrWhiteSpace(ultimoErrorCreacion))
        {
            ultimoErrorCreacion =
                descripcion +
                " - no existe una RebarShape recta con fórmula de longitud válida.";
        }

        return null;
    }

    private Rebar IntentarCrearLongitudinalConFormaEspecifica(
        Document doc,
        RebarShape forma,
        RebarBarType tipo,
        Element host,
        XYZ normal,
        IList<Curve> curvas,
        double longitudEsperada,
        string descripcion)
    {
        if (doc == null || forma == null || tipo == null || host == null ||
            normal == null || normal.GetLength() <= Tol ||
            curvas == null || curvas.Count == 0)
        {
            return null;
        }

        using (SubTransaction subTransaccion = new SubTransaction(doc))
        {
            subTransaccion.Start();

            try
            {
                Rebar rebar;

                using (BarTerminationsData terminaciones =
                    new BarTerminationsData(doc))
                {
                    rebar = Rebar.CreateFromCurvesAndShape(
                        doc,
                        forma,
                        tipo,
                        host,
                        normal.Normalize(),
                        curvas,
                        terminaciones);
                }

                if (rebar == null)
                {
                    subTransaccion.RollBack();
                    return null;
                }

                EstablecerRebarIndividual(rebar);
                doc.Regenerate();

                string diagnostico;
                if (!EsLongitudRebarValida(
                        rebar,
                        longitudEsperada,
                        out diagnostico))
                {
                    ultimoErrorCreacion =
                        descripcion +
                        " - longitud inválida: " + diagnostico;
                    subTransaccion.RollBack();
                    return null;
                }

                subTransaccion.Commit();
                return rebar;
            }
            catch
            {
                try
                {
                    if (subTransaccion.GetStatus() ==
                        TransactionStatus.Started)
                    {
                        subTransaccion.RollBack();
                    }
                }
                catch
                {
                }

                // Es normal que la mayoría de RebarShape no coincidan con una
                // sola línea recta; se continúa con la siguiente sin llenar el
                // reporte con excepciones irrelevantes.
                return null;
            }
        }
    }

    private void EstablecerRebarIndividual(Rebar rebar)
    {
        if (rebar == null)
            return;

        try
        {
            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            if (accessor != null)
                accessor.SetLayoutAsSingle();
        }
        catch
        {
            // CreateFromCurves ya crea una barra individual por defecto. Este
            // ajuste solo asegura que "Longitud total" sea igual a la longitud
            // de una barra y no dependa de una regla de distribución heredada.
        }
    }

    private bool EsLongitudRebarValida(
        Rebar rebar,
        double longitudEsperada,
        out string diagnostico)
    {
        diagnostico = "";

        if (rebar == null || !rebar.IsValidObject)
        {
            diagnostico = "rebar nulo o inválido";
            return false;
        }

        double longitudBarra = ObtenerParametroLongitud(
            rebar,
            BuiltInParameter.REBAR_ELEM_LENGTH);
        double longitudTotal = ObtenerParametroLongitud(
            rebar,
            BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH);
        double longitudGeometrica = ObtenerLongitudCentroRebar(rebar);

        double tolerancia = Math.Max(
            ConvertirCm(0.10),
            longitudEsperada * 0.001);

        bool parametroBarraValido =
            longitudBarra > TolGeometria &&
            Math.Abs(longitudBarra - longitudEsperada) <=
                Math.Max(tolerancia, longitudEsperada * 0.01);

        bool parametroTotalValido =
            longitudTotal > TolGeometria &&
            Math.Abs(longitudTotal - longitudEsperada) <=
                Math.Max(tolerancia, longitudEsperada * 0.01);

        bool geometriaValida =
            longitudGeometrica > TolGeometria &&
            Math.Abs(longitudGeometrica - longitudEsperada) <=
                Math.Max(tolerancia, longitudEsperada * 0.01);

        diagnostico =
            "esperada=" + FormatearMilimetros(longitudEsperada) +
            ", barra=" + FormatearMilimetros(longitudBarra) +
            ", total=" + FormatearMilimetros(longitudTotal) +
            ", geometría=" + FormatearMilimetros(longitudGeometrica);

        return parametroBarraValido &&
               parametroTotalValido &&
               geometriaValida;
    }

    private double ObtenerParametroLongitud(
        Element elemento,
        BuiltInParameter parametro)
    {
        if (elemento == null)
            return 0.0;

        try
        {
            Parameter p = elemento.get_Parameter(parametro);

            if (p != null && p.StorageType == StorageType.Double)
                return p.AsDouble();
        }
        catch
        {
        }

        return 0.0;
    }

    private double ObtenerLongitudCentroRebar(Rebar rebar)
    {
        if (rebar == null)
            return 0.0;

        try
        {
            IList<Curve> curvasCentro = rebar.GetCenterlineCurves(
                false,
                true,
                true,
                MultiplanarOption.IncludeOnlyPlanarCurves,
                0);

            if (curvasCentro == null)
                return 0.0;

            return curvasCentro
                .Where(x => x != null)
                .Sum(x => x.Length);
        }
        catch
        {
            return 0.0;
        }
    }

    private ElementId ObtenerIdFormaRebar(Rebar rebar)
    {
        if (rebar == null)
            return ElementId.InvalidElementId;

        try
        {
            Parameter parametroForma =
                rebar.get_Parameter(BuiltInParameter.REBAR_SHAPE);

            if (parametroForma != null &&
                parametroForma.StorageType == StorageType.ElementId)
            {
                ElementId id = parametroForma.AsElementId();
                return id ?? ElementId.InvalidElementId;
            }
        }
        catch
        {
        }

        return ElementId.InvalidElementId;
    }

    private string FormatearMilimetros(double valorPies)
    {
        if (double.IsNaN(valorPies) || double.IsInfinity(valorPies))
            return "n/a";

        double mm = UnitUtils.ConvertFromInternalUnits(
            valorPies,
            UnitTypeId.Millimeters);

        return mm.ToString("0.##", CultureInfo.InvariantCulture) + " mm";
    }

    private Rebar CrearConjuntoEstribos(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        RectanguloLocal rectangulo,
        RebarBarType tipo,
        RebarHookType tipoGancho,
        ZonaEstribos zona)
    {
        List<PuntoLocal> puntos = new List<PuntoLocal>
        {
            new PuntoLocal(rectangulo.MinX, rectangulo.MinY),
            new PuntoLocal(rectangulo.MaxX, rectangulo.MinY),
            new PuntoLocal(rectangulo.MaxX, rectangulo.MaxY),
            new PuntoLocal(rectangulo.MinX, rectangulo.MaxY)
        };

        return CrearConjuntoEstribosPersonalizado(
            doc,
            host,
            datos,
            puntos,
            true,
            tipo,
            tipoGancho,
            zona,
            -1,
            AceroColumnaTipoEstribo2D.Rectangular,
            0.0,
            0.0,
            null,
            0.0,
            "estribo rectangular");
    }

    private Rebar CrearConjuntoEstribosPersonalizado(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        List<PuntoLocal> puntos,
        bool cerrado,
        RebarBarType tipo,
        RebarHookType tipoGancho,
        ZonaEstribos zona,
        int indiceEsquinaGancho,
        AceroColumnaTipoEstribo2D tipoDiseno,
        double diametroLongitudinal,
        double recubrimiento,
        List<PuntoLocal> centrosLongitudinales,
        double longitudEmpalmeCircular,
        string descripcionForma)
    {
        if (zona == null || puntos == null || tipo == null)
            return null;

        int minimo = cerrado ? 3 : 2;

        if (puntos.Count < minimo || zona.Fin < zona.Inicio - Tol)
            return null;

        // El estribo circular se crea como LappedCircle: el recorrido supera
        // los 360° únicamente dentro del empalme local. A diferencia de los
        // estribos poligonales, sus dos terminaciones se resuelven siempre con
        // ganchos de 90° orientados radialmente hacia el núcleo.
        if (tipoDiseno == AceroColumnaTipoEstribo2D.Circular)
        {
            return CrearConjuntoEstribosCircularSolapado(
                doc,
                host,
                datos,
                puntos,
                tipo,
                tipoGancho,
                zona,
                indiceEsquinaGancho,
                diametroLongitudinal,
                recubrimiento,
                centrosLongitudinales,
                longitudEmpalmeCircular,
                descripcionForma);
        }

        PerfilEstriboPreparado perfil = PrepararPerfilEstribo(
            datos,
            puntos,
            cerrado,
            tipo,
            tipoGancho,
            indiceEsquinaGancho,
            tipoDiseno,
            diametroLongitudinal,
            recubrimiento,
            centrosLongitudinales,
            zona.Inicio);

        if (perfil == null || perfil.Curvas.Count == 0)
            return null;

        double longitud = zona.Fin - zona.Inicio;

        RebarStyle estiloRebar =
            tipoDiseno == AceroColumnaTipoEstribo2D.HorizontalAlma
                ? RebarStyle.Standard
                : RebarStyle.StirrupTie;

        System.Action<Rebar> configurarDistribucion = rebar =>
        {
            if (rebar == null)
                return;

            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            // IMPORTANTE: una distribución por espaciamiento máximo puede
            // guardar Cantidad = 0 porque la cantidad real la calcula Revit
            // según toda la longitud del rango. Por eso no debe interpretarse
            // Cantidad <= 1 como una barra individual salvo que la regla sea
            // realmente de cantidad exacta.
            bool incluirPrimera = !zona.OmitirPrimeraBarra;
            bool incluirUltima = !zona.OmitirUltimaBarra;

            if (longitud <= Tol)
            {
                accessor.SetLayoutAsSingle();
            }
            else if (zona.UsarCantidadExacta)
            {
                int cantidadExacta = System.Math.Max(
                    1,
                    System.Math.Min(1002, zona.Cantidad));

                if (cantidadExacta <= 1)
                {
                    accessor.SetLayoutAsSingle();
                }
                else
                {
                    accessor.SetLayoutAsNumberWithSpacing(
                        cantidadExacta,
                        zona.Espaciamiento,
                        true,
                        incluirPrimera,
                        incluirUltima);
                }
            }
            else
            {
                // TOTAL y RESTO conservan la regla nativa ESPACIADO MÁXIMO.
                // El rango RESTO ya llega centrado y sin posiciones coincidentes,
                // por lo que sus extremos se incluyen normalmente.
                double espaciamientoMaximo = System.Math.Max(
                    zona.Espaciamiento,
                    UnitUtils.ConvertToInternalUnits(
                        1.0,
                        UnitTypeId.Millimeters));

                accessor.SetLayoutAsMaximumSpacing(
                    espaciamientoMaximo,
                    longitud,
                    true,
                    incluirPrimera,
                    incluirUltima);
            }
        };

        if (tipoGancho == null)
        {
            return CrearRebarShapeDrivenSeguro(
                doc,
                estiloRebar,
                tipo,
                host,
                XYZ.BasisZ,
                perfil.Curvas,
                null,
                null,
                perfil.OrientacionInicio,
                perfil.OrientacionFin,
                false,
                configurarDistribucion,
                descripcionForma + " sin gancho");
        }

        bool esGanchoTipoC =
            tipoDiseno == AceroColumnaTipoEstribo2D.TrabaC;
        bool esGanchoTipoS =
            tipoDiseno == AceroColumnaTipoEstribo2D.TrabaS;
        bool esGanchoAnterior =
            tipoDiseno == AceroColumnaTipoEstribo2D.TrabaGancho;

        if (!cerrado &&
            (esGanchoTipoC || esGanchoTipoS || esGanchoAnterior))
        {
            return CrearRebarShapeDrivenSeguro(
                doc,
                RebarStyle.StirrupTie,
                tipo,
                host,
                XYZ.BasisZ,
                perfil.Curvas,
                tipoGancho,
                tipoGancho,
                perfil.OrientacionInicio,
                perfil.OrientacionFin,
                true,
                configurarDistribucion,
                descripcionForma +
                    (esGanchoTipoS
                        ? " tipo S adaptado a longitudinales"
                        : " tipo C adaptado a longitudinales"));
        }

        System.Func<Rebar, bool> validarInterior = null;

        if (cerrado)
        {
            validarInterior = rebar =>
                RebarGanchosHaciaInterior(
                    rebar,
                    perfil);
        }

        Rebar resultadoConGancho = CrearEstriboConGanchoSeguro(
            doc,
            host,
            tipo,
            tipoGancho,
            perfil,
            configurarDistribucion,
            validarInterior,
            descripcionForma,
            tipoDiseno == AceroColumnaTipoEstribo2D.Croquis);

        if (resultadoConGancho != null ||
            tipoDiseno != AceroColumnaTipoEstribo2D.Croquis ||
            !cerrado)
        {
            return resultadoConGancho;
        }

        // Un croquis no es siempre equivalente a un rectángulo o a un rombo.
        // Probar las dos aperturas alternativas SIN tocar la geometría de
        // longitudinales, la distribución en Z ni la elección de gancho 135°.
        string primerErrorCroquisMYG = ultimoErrorCreacion;
        for (int alternativaMYG = 1; alternativaMYG <= 2; alternativaMYG++)
        {
            PerfilEstriboPreparado varianteMYG = PrepararPerfilEstribo(
                datos,
                puntos,
                cerrado,
                tipo,
                tipoGancho,
                indiceEsquinaGancho,
                tipoDiseno,
                diametroLongitudinal,
                recubrimiento,
                centrosLongitudinales,
                zona.Inicio,
                alternativaMYG);

            if (varianteMYG == null || varianteMYG.Curvas.Count == 0)
                continue;

            System.Func<Rebar, bool> validarVarianteMYG = rebar =>
                RebarGanchosHaciaInterior(rebar, varianteMYG);

            resultadoConGancho = CrearEstriboConGanchoSeguro(
                doc,
                host,
                tipo,
                tipoGancho,
                varianteMYG,
                configurarDistribucion,
                validarVarianteMYG,
                descripcionForma + " (apertura croquis " +
                    (alternativaMYG + 1) + ")",
                true);

            if (resultadoConGancho != null)
                return resultadoConGancho;
        }

        // No esconder una omisión de armadura ni un metrado nativo en cero.
        // Sólo se muestra un diagnóstico breve por columna, con motivo real.
        ultimoErrorCreacion =
            "CROQUIS - " + zona.Nombre +
            ": no se pudo crear un Rebar Set con DOS ganchos de 135° " +
            "y longitud/volumen nativos válidos. " +
            "No incluya en los metrados una forma que indique 0 mm o 0 kg. " +
            "Se requieren " + perfil.Curvas.Count +
            " segmentos de contorno en esta apertura; confirme una " +
            "RebarShape paramétrica con estos segmentos y dos ganchos. " +
            "Primer intento: " +
            ResumirErrorCroquisMYG(primerErrorCroquisMYG, 260);
        return null;
    }


    // Limita la longitud del error sin ocultar que una pieza quedó sin crear.
    private string ResumirErrorCroquisMYG(string detalle, int maxCaracteres)
    {
        if (string.IsNullOrWhiteSpace(detalle))
            return "Sin detalle adicional de la API de Revit.";

        string texto = detalle.Trim();
        if (maxCaracteres < 40 || texto.Length <= maxCaracteres)
            return texto;

        return texto.Substring(0, maxCaracteres) + "...";
    }

    private Rebar CrearConjuntoEstribosCircularSolapado(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        List<PuntoLocal> puntos,
        RebarBarType tipo,
        RebarHookType tipoGanchoCircular90,
        ZonaEstribos zona,
        int indiceEsquinaGancho,
        double diametroLongitudinal,
        double recubrimiento,
        List<PuntoLocal> centrosLongitudinales,
        double longitudEmpalmeSolicitada,
        string descripcionForma)
    {
        if (doc == null || host == null || datos == null ||
            puntos == null || puntos.Count < 8 || tipo == null ||
            zona == null)
        {
            return null;
        }

        if (tipoGanchoCircular90 == null ||
            !EsGanchoDeNoventaGrados(tipoGanchoCircular90))
        {
            ultimoErrorCreacion =
                descripcionForma +
                " - el estribo circular requiere dos ganchos de 90°.";
            return null;
        }

        PuntoLocal centro;
        double radio;

        if (!TryAjustarCirculoPuntos(puntos, out centro, out radio) ||
            centro == null || radio <= TolGeometria)
        {
            ultimoErrorCreacion =
                descripcionForma +
                " - no se pudo reconocer el centro y radio del estribo circular.";
            return null;
        }

        double diametroEstribo = ObtenerDiametroBarra(tipo);
        if (diametroEstribo <= TolGeometria)
            diametroEstribo = UnitUtils.ConvertToInternalUnits(
                8.0,
                UnitTypeId.Millimeters);

        // El punto de inicio del solape se orienta hacia una longitudinal
        // periférica. En circulares IndiceEsquinaGancho representa la posición
        // angular preferida del empalme, no una esquina ni un gancho.
        int indicePreferido = indiceEsquinaGancho;
        if (indicePreferido < 0 || indicePreferido >= puntos.Count)
            indicePreferido = 0;

        PuntoLocal puntoPreferido = puntos[indicePreferido];
        double anguloPreferido = Math.Atan2(
            puntoPreferido.Y - centro.Y,
            puntoPreferido.X - centro.X);

        double anguloEmpalme = ResolverAnguloCierreCircularEnLongitudinal(
            centro,
            radio,
            anguloPreferido,
            centrosLongitudinales,
            diametroLongitudinal,
            diametroEstribo);

        double circunferencia = 2.0 * Math.PI * radio;

        // El empalme debe abrazar únicamente la longitudinal elegida. Para ello
        // se calcula su abertura con tres datos reales:
        //   1) diámetro de la longitudinal;
        //   2) diámetro del estribo;
        //   3) separación angular a las longitudinales vecinas.
        //
        // El sector siempre queda centrado en la barra de amarre y termina antes
        // de alcanzar las barras contiguas. La longitud de empalme longitudinal
        // guardada en la data no controla esta geometría circular.
        double anguloSolape = ResolverAnguloSolapeCircularUnaLongitudinal(
            centro,
            radio,
            anguloEmpalme,
            centrosLongitudinales,
            diametroLongitudinal,
            diametroEstribo);

        double longitudEmpalme = radio * anguloSolape;

        // Se admite un valor manual únicamente cuando sea todavía más corto y
        // conserve un sector geométricamente válido. Nunca puede ampliar el
        // amarre hasta alcanzar una segunda longitudinal.
        if (longitudEmpalmeSolicitada > TolGeometria &&
            longitudEmpalmeSolicitada < longitudEmpalme)
        {
            double anguloSolicitado =
                longitudEmpalmeSolicitada / radio;

            double minimoAbsoluto =
                1.0 * Math.PI / 180.0;

            anguloSolape = Math.Max(
                minimoAbsoluto,
                Math.Min(anguloSolape, anguloSolicitado));

            longitudEmpalme = radio * anguloSolape;
        }

        if (anguloSolape <= TolGeometria ||
            anguloSolape >= Math.PI - 1.0e-6)
        {
            ultimoErrorCreacion =
                descripcionForma +
                " - no se pudo obtener un solape local válido. Empalme: " +
                FormatearMilimetros(longitudEmpalme) +
                ", circunferencia: " +
                FormatearMilimetros(circunferencia) + ".";
            return null;
        }

        // Ambos extremos quedan a cada lado de la MISMA longitudinal de cierre.
        // El recorrido inicia medio solape antes de esa barra y termina medio
        // solape después de completar exactamente una vuelta.
        double anguloInicio =
            anguloEmpalme - anguloSolape * 0.5;

        double barridoTotal =
            2.0 * Math.PI + anguloSolape;

        List<Curve> curvas = new List<Curve>();

        // Cada arco se mantiene por debajo de 90° para favorecer la creación
        // automática de una RebarShape de tipo LappedCircle.
        int cantidadArcos = Math.Max(
            5,
            (int)Math.Ceiling(
                barridoTotal / (Math.PI * 0.5)));

        double barridoArco =
            barridoTotal / cantidadArcos;

        for (int i = 0; i < cantidadArcos; i++)
        {
            double a0 = anguloInicio + i * barridoArco;
            double a1 = a0 + barridoArco;
            double am = (a0 + a1) * 0.5;

            XYZ inicio = LocalAMundial(
                datos,
                new PuntoLocal(
                    centro.X + radio * Math.Cos(a0),
                    centro.Y + radio * Math.Sin(a0)),
                zona.Inicio);

            XYZ fin = LocalAMundial(
                datos,
                new PuntoLocal(
                    centro.X + radio * Math.Cos(a1),
                    centro.Y + radio * Math.Sin(a1)),
                zona.Inicio);

            XYZ medio = LocalAMundial(
                datos,
                new PuntoLocal(
                    centro.X + radio * Math.Cos(am),
                    centro.Y + radio * Math.Sin(am)),
                zona.Inicio);

            if (inicio.DistanceTo(fin) <= TolGeometria)
                continue;

            curvas.Add(Arc.Create(inicio, fin, medio));
        }

        if (curvas.Count < 5)
        {
            ultimoErrorCreacion =
                descripcionForma +
                " - no se pudo construir la cadena circular solapada.";
            return null;
        }

        double longitudZona = zona.Fin - zona.Inicio;

        System.Action<Rebar> configurarDistribucion = rebar =>
        {
            if (rebar == null)
                return;

            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            bool incluirPrimera = !zona.OmitirPrimeraBarra;
            bool incluirUltima = !zona.OmitirUltimaBarra;

            if (longitudZona <= Tol)
            {
                accessor.SetLayoutAsSingle();
            }
            else if (zona.UsarCantidadExacta)
            {
                int cantidad = Math.Max(
                    1,
                    Math.Min(1002, zona.Cantidad));

                if (cantidad <= 1)
                {
                    accessor.SetLayoutAsSingle();
                }
                else
                {
                    accessor.SetLayoutAsNumberWithSpacing(
                        cantidad,
                        zona.Espaciamiento,
                        true,
                        incluirPrimera,
                        incluirUltima);
                }
            }
            else
            {
                double espaciamiento = Math.Max(
                    zona.Espaciamiento,
                    UnitUtils.ConvertToInternalUnits(
                        1.0,
                        UnitTypeId.Millimeters));

                accessor.SetLayoutAsMaximumSpacing(
                    espaciamiento,
                    longitudZona,
                    true,
                    incluirPrimera,
                    incluirUltima);
            }
        };

        Rebar creado = CrearCircularSolapadoConGanchos90Seguro(
            doc,
            host,
            datos,
            tipo,
            tipoGanchoCircular90,
            curvas,
            centro,
            configurarDistribucion,
            descripcionForma +
                " circular solapado con ganchos 90° (" +
                FormatearMilimetros(longitudEmpalme) +
                " de empalme local)");

        if (creado == null &&
            string.IsNullOrWhiteSpace(ultimoErrorCreacion))
        {
            ultimoErrorCreacion =
                descripcionForma +
                " - Revit no pudo crear la forma circular solapada " +
                "con dos ganchos de 90°.";
        }

        return creado;
    }


    private RebarHookType ResolverGanchoLongitudinal90(
        Document doc,
        RebarBarType tipoBarra)
    {
        if (doc == null || tipoBarra == null)
            return null;

        List<RebarHookType> candidatos =
            new FilteredElementCollector(doc)
                .OfClass(typeof(RebarHookType))
                .Cast<RebarHookType>()
                .Where(x =>
                    x != null &&
                    EsGanchoDeNoventaGrados(x) &&
                    x.Style == RebarStyle.Standard &&
                    GanchoPermitidoParaTipoBarra(tipoBarra, x))
                .OrderBy(x =>
                {
                    string nombre = x.Name ?? "";
                    bool pareceEstribo =
                        nombre.IndexOf(
                            "Estribo",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                        nombre.IndexOf(
                            "Tirante",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                        nombre.IndexOf(
                            "Tie",
                            StringComparison.OrdinalIgnoreCase) >= 0;

                    // Para barras longitudinales se prefieren los tipos estándar
                    // antes que los tipos nombrados específicamente para estribos.
                    return pareceEstribo ? 1 : 0;
                })
                .ThenBy(x => x.Name)
                .ToList();

        return candidatos.FirstOrDefault();
    }

    // MYG: ya no se asignan ganchos longitudinales con Right/Left.


    // MYG: validador antiguo de terminaciones retirado.


    // MYG: validador radial hacia nucleo retirado.


    private bool VectorHorizontalApuntaA(
        XYZ vector,
        XYZ direccionDeseada)
    {
        if (vector == null || direccionDeseada == null)
            return false;

        XYZ horizontal = new XYZ(vector.X, vector.Y, 0.0);
        XYZ deseada = new XYZ(
            direccionDeseada.X,
            direccionDeseada.Y,
            0.0);

        if (horizontal.GetLength() <= TolGeometria ||
            deseada.GetLength() <= TolGeometria)
        {
            return false;
        }

        double producto = horizontal.Normalize().DotProduct(
            deseada.Normalize());

        // Se admite una pequeña desviación geométrica debida al radio de doblado.
        return producto >= 0.20;
    }

    private RebarHookType ResolverGanchoCircular90(
        Document doc,
        RebarBarType tipoBarra,
        RebarHookType preferido)
    {
        if (doc == null || tipoBarra == null)
            return null;

        if (preferido != null &&
            EsGanchoDeNoventaGrados(preferido) &&
            GanchoPermitidoParaTipoBarra(tipoBarra, preferido))
        {
            return preferido;
        }

        List<RebarHookType> candidatos =
            new FilteredElementCollector(doc)
                .OfClass(typeof(RebarHookType))
                .Cast<RebarHookType>()
                .Where(x =>
                    x != null &&
                    EsGanchoDeNoventaGrados(x) &&
                    GanchoPermitidoParaTipoBarra(tipoBarra, x))
                .OrderBy(x =>
                {
                    string nombre = x.Name ?? "";
                    bool pareceEstribo =
                        nombre.IndexOf(
                            "Estribo",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                        nombre.IndexOf(
                            "Tirante",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                        nombre.IndexOf(
                            "Tie",
                            StringComparison.OrdinalIgnoreCase) >= 0;

                    return pareceEstribo ? 0 : 1;
                })
                .ThenBy(x => x.Name)
                .ToList();

        return candidatos.FirstOrDefault();
    }

    private bool EsGanchoDeNoventaGrados(
        RebarHookType tipoGancho)
    {
        if (tipoGancho == null)
            return false;

        double angulo;

        try
        {
            angulo = tipoGancho.HookAngle;
        }
        catch
        {
            Parameter parametro = tipoGancho.get_Parameter(
                BuiltInParameter.REBAR_HOOK_ANGLE);

            if (parametro == null ||
                parametro.StorageType != StorageType.Double)
            {
                return false;
            }

            angulo = parametro.AsDouble();
        }

        double tolerancia =
            0.75 * Math.PI / 180.0;

        return Math.Abs(
            angulo - Math.PI * 0.5) <= tolerancia;
    }

    private Rebar CrearCircularSolapadoConGanchos90Seguro(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        RebarBarType tipoBarra,
        RebarHookType tipoGancho90,
        IList<Curve> curvas,
        PuntoLocal centro,
        System.Action<Rebar> configurarDistribucion,
        string descripcion)
    {
        if (doc == null || host == null || datos == null ||
            tipoBarra == null || tipoGancho90 == null ||
            curvas == null || curvas.Count == 0 ||
            centro == null)
        {
            return null;
        }

        List<Tuple<RebarTerminationOrientation,
                   RebarTerminationOrientation>> combinaciones =
            new List<Tuple<RebarTerminationOrientation,
                           RebarTerminationOrientation>>
            {
                Tuple.Create(
                    RebarTerminationOrientation.Right,
                    RebarTerminationOrientation.Left),
                Tuple.Create(
                    RebarTerminationOrientation.Left,
                    RebarTerminationOrientation.Right),
                Tuple.Create(
                    RebarTerminationOrientation.Right,
                    RebarTerminationOrientation.Right),
                Tuple.Create(
                    RebarTerminationOrientation.Left,
                    RebarTerminationOrientation.Left)
            };

        List<string> errores = new List<string>();

        // Primer método: crear directamente la forma LappedCircle con las dos
        // terminaciones de 90°. Se prueban primero las formas existentes y,
        // después, la creación de una forma nueva cuando el proyecto lo permite.
        foreach (bool crearNuevaForma in new bool[] { false, true })
        {
            foreach (Tuple<RebarTerminationOrientation,
                           RebarTerminationOrientation> combinacion in
                     combinaciones)
            {
                using (SubTransaction subTransaccion =
                    new SubTransaction(doc))
                {
                    subTransaccion.Start();

                    try
                    {
                        Rebar rebar;

                        using (BarTerminationsData terminaciones =
                            new BarTerminationsData(doc))
                        {
                            terminaciones.HookTypeIdAtStart =
                                tipoGancho90.Id;
                            terminaciones.HookTypeIdAtEnd =
                                tipoGancho90.Id;
                            terminaciones.TerminationOrientationAtStart =
                                combinacion.Item1;
                            terminaciones.TerminationOrientationAtEnd =
                                combinacion.Item2;

                            rebar = Rebar.CreateFromCurves(
                                doc,
                                RebarStyle.StirrupTie,
                                tipoBarra,
                                host,
                                XYZ.BasisZ,
                                curvas,
                                terminaciones,
                                true,
                                crearNuevaForma);
                        }

                        if (rebar == null)
                        {
                            subTransaccion.RollBack();
                            continue;
                        }

                        doc.Regenerate();

                        bool tiposCorrectos =
                            rebar.GetHookTypeId(0) ==
                                tipoGancho90.Id &&
                            rebar.GetHookTypeId(1) ==
                                tipoGancho90.Id;

                        if (!tiposCorrectos ||
                            !RebarContieneGanchos(rebar))
                        {
                            errores.Add(
                                combinacion.Item1 + "/" +
                                combinacion.Item2 +
                                ": Revit descartó uno o ambos ganchos.");
                            subTransaccion.RollBack();
                            continue;
                        }

                        if (!RebarGanchosCircularesHaciaInterior(
                                rebar,
                                datos,
                                centro,
                                curvas))
                        {
                            errores.Add(
                                combinacion.Item1 + "/" +
                                combinacion.Item2 +
                                ": los ganchos quedaron hacia afuera.");
                            subTransaccion.RollBack();
                            continue;
                        }

                        if (configurarDistribucion != null)
                            configurarDistribucion(rebar);

                        doc.Regenerate();
                        subTransaccion.Commit();
                        ultimoErrorCreacion = "";
                        return rebar;
                    }
                    catch (Exception ex)
                    {
                        errores.Add(
                            combinacion.Item1 + "/" +
                            combinacion.Item2 + ": " +
                            ex.GetType().Name + " - " +
                            ex.Message);

                        try
                        {
                            if (subTransaccion.GetStatus() ==
                                TransactionStatus.Started)
                            {
                                subTransaccion.RollBack();
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        // Respaldo: crea primero la forma circular solapada que Revit ya sabe
        // resolver y asigna después los ganchos de 90° a sus dos extremos.
        // Todo ocurre dentro de la misma SubTransaction: si Revit no conserva
        // ambos ganchos, no queda un estribo incompleto en el modelo.
        foreach (Tuple<RebarTerminationOrientation,
                       RebarTerminationOrientation> combinacion in
                 combinaciones)
        {
            using (SubTransaction subTransaccion =
                new SubTransaction(doc))
            {
                subTransaccion.Start();

                try
                {
                    Rebar rebar;

                    using (BarTerminationsData terminacionesVacias =
                        new BarTerminationsData(doc))
                    {
                        rebar = Rebar.CreateFromCurves(
                            doc,
                            RebarStyle.StirrupTie,
                            tipoBarra,
                            host,
                            XYZ.BasisZ,
                            curvas,
                            terminacionesVacias,
                            true,
                            true);
                    }

                    if (rebar == null)
                    {
                        subTransaccion.RollBack();
                        continue;
                    }

                    rebar.SetHookTypeId(0, tipoGancho90.Id);
                    rebar.SetHookTypeId(1, tipoGancho90.Id);
                    rebar.SetTerminationOrientation(
                        0,
                        combinacion.Item1);
                    rebar.SetTerminationOrientation(
                        1,
                        combinacion.Item2);
                    rebar.SetTerminationRotationAngle(0, 0.0);
                    rebar.SetTerminationRotationAngle(1, 0.0);

                    doc.Regenerate();

                    bool tiposCorrectos =
                        rebar.GetHookTypeId(0) ==
                            tipoGancho90.Id &&
                        rebar.GetHookTypeId(1) ==
                            tipoGancho90.Id;

                    if (!tiposCorrectos ||
                        !RebarContieneGanchos(rebar) ||
                        !RebarGanchosCircularesHaciaInterior(
                            rebar,
                            datos,
                            centro,
                            curvas))
                    {
                        errores.Add(
                            "Asignación posterior " +
                            combinacion.Item1 + "/" +
                            combinacion.Item2 +
                            ": Revit no conservó los dos ganchos interiores.");
                        subTransaccion.RollBack();
                        continue;
                    }

                    if (configurarDistribucion != null)
                        configurarDistribucion(rebar);

                    doc.Regenerate();
                    subTransaccion.Commit();
                    ultimoErrorCreacion = "";
                    return rebar;
                }
                catch (Exception ex)
                {
                    errores.Add(
                        "Asignación posterior " +
                        combinacion.Item1 + "/" +
                        combinacion.Item2 + ": " +
                        ex.GetType().Name + " - " +
                        ex.Message);

                    try
                    {
                        if (subTransaccion.GetStatus() ==
                            TransactionStatus.Started)
                        {
                            subTransaccion.RollBack();
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        ultimoErrorCreacion =
            descripcion +
            " - no se pudieron crear dos ganchos de 90° interiores. " +
            "Tipo de gancho probado: '" +
            tipoGancho90.Name + "'. Intentos: " +
            string.Join(" | ", errores.Take(8));

        return null;
    }

    private bool RebarGanchosCircularesHaciaInterior(
        Rebar rebar,
        DatosColumna datos,
        PuntoLocal centro,
        IList<Curve> curvasBase)
    {
        if (rebar == null || datos == null || centro == null ||
            curvasBase == null || curvasBase.Count == 0)
        {
            return false;
        }

        try
        {
            IList<Curve> curvasConGanchos =
                rebar.GetCenterlineCurves(
                    false,
                    false,
                    false,
                    MultiplanarOption.IncludeOnlyPlanarCurves,
                    0);

            if (curvasConGanchos == null ||
                curvasConGanchos.Count == 0)
            {
                return false;
            }

            List<XYZ> terminales =
                ObtenerTerminalesCadena(curvasConGanchos);

            if (terminales == null || terminales.Count < 2)
                return false;

            XYZ baseInicio = curvasBase[0].GetEndPoint(0);
            XYZ baseFin =
                curvasBase[curvasBase.Count - 1].GetEndPoint(1);

            XYZ terminalA = terminales[0];
            XYZ terminalB = terminales[1];

            double directa =
                terminalA.DistanceTo(baseInicio) +
                terminalB.DistanceTo(baseFin);
            double cruzada =
                terminalB.DistanceTo(baseInicio) +
                terminalA.DistanceTo(baseFin);

            XYZ extremoInicio =
                directa <= cruzada ? terminalA : terminalB;
            XYZ extremoFin =
                directa <= cruzada ? terminalB : terminalA;

            PuntoLocal baseInicioLocal =
                ProyectarPuntoMundialALocal(datos, baseInicio);
            PuntoLocal baseFinLocal =
                ProyectarPuntoMundialALocal(datos, baseFin);
            PuntoLocal extremoInicioLocal =
                ProyectarPuntoMundialALocal(datos, extremoInicio);
            PuntoLocal extremoFinLocal =
                ProyectarPuntoMundialALocal(datos, extremoFin);

            if (baseInicioLocal == null || baseFinLocal == null ||
                extremoInicioLocal == null || extremoFinLocal == null)
            {
                return false;
            }

            double radioBaseInicio =
                Distancia(baseInicioLocal, centro);
            double radioBaseFin =
                Distancia(baseFinLocal, centro);
            double radioExtremoInicio =
                Distancia(extremoInicioLocal, centro);
            double radioExtremoFin =
                Distancia(extremoFinLocal, centro);

            double toleranciaInterior = Math.Max(
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Millimeters),
                TolGeometria * 5.0);

            return
                radioExtremoInicio <
                    radioBaseInicio - toleranciaInterior &&
                radioExtremoFin <
                    radioBaseFin - toleranciaInterior;
        }
        catch
        {
            return false;
        }
    }

    private PuntoLocal ProyectarPuntoMundialALocal(
        DatosColumna datos,
        XYZ punto)
    {
        if (datos == null || datos.Origen == null ||
            datos.EjeX == null || datos.EjeY == null ||
            punto == null)
        {
            return null;
        }

        XYZ vector = punto - datos.Origen;

        return new PuntoLocal(
            vector.DotProduct(datos.EjeX),
            vector.DotProduct(datos.EjeY));
    }

    private Rebar CrearConjuntoEstribosCircularFreeForm(
        Document doc,
        FamilyInstance host,
        DatosColumna datos,
        List<PuntoLocal> puntos,
        RebarBarType tipo,
        RebarHookType tipoGancho,
        ZonaEstribos zona,
        int indiceEsquinaGancho,
        double diametroLongitudinal,
        double recubrimiento,
        List<PuntoLocal> centrosLongitudinales,
        string descripcionForma)
    {
        if (doc == null || host == null || datos == null ||
            puntos == null || puntos.Count < 8 || tipo == null ||
            zona == null)
        {
            return null;
        }

        PerfilEstriboPreparado perfilBase = PrepararPerfilEstribo(
            datos,
            puntos,
            true,
            tipo,
            tipoGancho,
            indiceEsquinaGancho,
            AceroColumnaTipoEstribo2D.Circular,
            diametroLongitudinal,
            recubrimiento,
            centrosLongitudinales,
            zona.Inicio);

        if (perfilBase == null || perfilBase.Curvas == null ||
            perfilBase.Curvas.Count == 0)
        {
            if (string.IsNullOrWhiteSpace(ultimoErrorCreacion))
            {
                ultimoErrorCreacion =
                    descripcionForma +
                    " - no se pudo preparar el recorrido circular Free Form.";
            }

            return null;
        }

        List<double> elevaciones =
            ObtenerElevacionesZonaEstribosFreeForm(zona);

        if (elevaciones.Count == 0)
        {
            ultimoErrorCreacion =
                descripcionForma +
                " - la zona no produjo posiciones verticales válidas.";
            return null;
        }

        List<IList<Curve>> curvasPorBarra =
            new List<IList<Curve>>();

        foreach (double elevacion in elevaciones)
        {
            double desplazamientoZ = elevacion - zona.Inicio;
            IList<Curve> curvasTrasladadas =
                TrasladarCurvasEnZ(
                    perfilBase.Curvas,
                    desplazamientoZ);

            if (curvasTrasladadas == null ||
                curvasTrasladadas.Count == 0)
            {
                ultimoErrorCreacion =
                    descripcionForma +
                    " - no se pudo trasladar el recorrido circular a la " +
                    "elevación " + elevacion.ToString(
                        "0.######",
                        CultureInfo.InvariantCulture) + ".";
                return null;
            }

            curvasPorBarra.Add(curvasTrasladadas);
        }

        return CrearFreeFormCircularConGanchosSeguro(
            doc,
            host,
            tipo,
            tipoGancho,
            curvasPorBarra,
            perfilBase,
            descripcionForma + " Free Form");
    }

    private List<double> ObtenerElevacionesZonaEstribosFreeForm(
        ZonaEstribos zona)
    {
        List<double> resultado = new List<double>();

        if (zona == null)
            return resultado;

        double inicio = zona.Inicio;
        double fin = Math.Max(zona.Inicio, zona.Fin);
        double longitud = fin - inicio;

        if (longitud <= Tol)
        {
            if (!zona.OmitirPrimeraBarra && !zona.OmitirUltimaBarra)
                resultado.Add(inicio);
            return resultado;
        }

        if (zona.UsarCantidadExacta)
        {
            int cantidad = Math.Max(
                1,
                Math.Min(1002, zona.Cantidad));

            double espaciamiento = Math.Max(
                zona.Espaciamiento,
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters));

            for (int i = 0; i < cantidad; i++)
            {
                if (i == 0 && zona.OmitirPrimeraBarra)
                    continue;
                if (i == cantidad - 1 && zona.OmitirUltimaBarra)
                    continue;

                double z = inicio + i * espaciamiento;
                if (z > fin + Tol)
                    break;

                resultado.Add(Math.Min(z, fin));
            }

            return resultado;
        }

        // Regla ESPACIADO MÁXIMO: se calcula sobre el rango efectivo.
        // RESTO ya llega desplazado hacia el interior y no necesita ocultar
        // ninguna posición extrema.
        double separacionMaxima = Math.Max(
            zona.Espaciamiento,
            UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Millimeters));

        int intervalos = Math.Max(
            1,
            (int)Math.Ceiling(longitud / separacionMaxima));

        double separacionReal = longitud / intervalos;

        for (int i = 0; i <= intervalos; i++)
        {
            if (i == 0 && zona.OmitirPrimeraBarra)
                continue;
            if (i == intervalos && zona.OmitirUltimaBarra)
                continue;

            resultado.Add(
                i == intervalos
                    ? fin
                    : inicio + i * separacionReal);
        }

        return resultado;
    }

    private IList<Curve> TrasladarCurvasEnZ(
        IList<Curve> curvas,
        double desplazamientoZ)
    {
        List<Curve> resultado = new List<Curve>();

        if (curvas == null || curvas.Count == 0)
            return resultado;

        Transform traslado = Transform.CreateTranslation(
            new XYZ(0.0, 0.0, desplazamientoZ));

        foreach (Curve curva in curvas)
        {
            if (curva == null || !curva.IsBound)
                return new List<Curve>();

            Curve copia = curva.CreateTransformed(traslado);

            if (copia == null || !copia.IsBound)
                return new List<Curve>();

            resultado.Add(copia);
        }

        return resultado;
    }

    private Rebar CrearFreeFormCircularConGanchosSeguro(
        Document doc,
        Element host,
        RebarBarType tipoBarra,
        RebarHookType tipoGancho,
        IList<IList<Curve>> curvasPorBarra,
        PerfilEstriboPreparado perfilBase,
        string descripcion)
    {
        if (doc == null || host == null || tipoBarra == null ||
            curvasPorBarra == null || curvasPorBarra.Count == 0 ||
            perfilBase == null)
        {
            return null;
        }

        List<Tuple<RebarTerminationOrientation,
                   RebarTerminationOrientation>> combinaciones =
            new List<Tuple<RebarTerminationOrientation,
                           RebarTerminationOrientation>>();

        if (tipoGancho == null)
        {
            combinaciones.Add(Tuple.Create(
                RebarTerminationOrientation.Left,
                RebarTerminationOrientation.Left));
        }
        else
        {
            // En una geometría basada en arco, Left corresponde al interior.
            // Se prueba primero Left/Left y después las demás combinaciones por
            // compatibilidad con proyectos cuya normal o sentido de curvas esté
            // invertido.
            AgregarCombinacionOrientacion(
                combinaciones,
                RebarTerminationOrientation.Left,
                RebarTerminationOrientation.Left);
            AgregarCombinacionOrientacion(
                combinaciones,
                perfilBase.OrientacionInicio,
                perfilBase.OrientacionFin);
            AgregarCombinacionOrientacion(
                combinaciones,
                RebarTerminationOrientation.Right,
                RebarTerminationOrientation.Left);
            AgregarCombinacionOrientacion(
                combinaciones,
                RebarTerminationOrientation.Left,
                RebarTerminationOrientation.Right);
            AgregarCombinacionOrientacion(
                combinaciones,
                RebarTerminationOrientation.Right,
                RebarTerminationOrientation.Right);
        }

        string erroresIntentos = "";

        foreach (Tuple<RebarTerminationOrientation,
                       RebarTerminationOrientation> combinacion in
                 combinaciones)
        {
            using (SubTransaction subTransaccion =
                new SubTransaction(doc))
            {
                subTransaccion.Start();

                try
                {
                    Rebar rebar;
                    RebarFreeFormValidationResult errorFreeForm;

                    using (RebarFreeFormCreationResult creacion =
                        Rebar.CreateFreeForm(
                            doc,
                            tipoBarra,
                            host,
                            curvasPorBarra,
                            RebarStyle.StirrupTie))
                    {
                        errorFreeForm = creacion.Error;
                        rebar = creacion.Rebar;
                    }

                    if (errorFreeForm !=
                            RebarFreeFormValidationResult.Success ||
                        rebar == null)
                    {
                        ultimoErrorCreacion =
                            descripcion +
                            " - CreateFreeForm: " + errorFreeForm + ".";
                        subTransaccion.RollBack();
                        continue;
                    }

                    if (tipoGancho != null)
                    {
                        // Free Form evita depender de una RebarShape circular.
                        // Los ganchos se asignan después de crear el cuerpo de
                        // arcos, por lo que Revit no necesita encontrar ni crear
                        // una familia de forma compatible.
                        rebar.SetHookTypeId(0, tipoGancho.Id);
                        rebar.SetHookTypeId(1, tipoGancho.Id);

                        rebar.SetTerminationOrientation(
                            0,
                            combinacion.Item1);
                        rebar.SetTerminationOrientation(
                            1,
                            combinacion.Item2);

                        rebar.SetTerminationRotationAngle(0, 0.0);
                        rebar.SetTerminationRotationAngle(1, 0.0);

                        // Todos los estribos del conjunto están en planos XY.
                        // Se fija la normal Z para que los ganchos permanezcan en
                        // el plano del estribo y se orienten hacia la longitudinal
                        // utilizada como cierre.
                        using (RebarFreeFormAccessor accessor =
                            rebar.GetFreeFormAccessor())
                        {
                            for (int indiceBarra = 0;
                                 indiceBarra < curvasPorBarra.Count;
                                 indiceBarra++)
                            {
                                for (int extremo = 0;
                                     extremo <= 1;
                                     extremo++)
                                {
                                    if (accessor.CanBeTerminationPlaneNormal(
                                            indiceBarra,
                                            extremo,
                                            XYZ.BasisZ))
                                    {
                                        accessor.SetTerminationPlaneNormalForBarIndex(
                                            indiceBarra,
                                            extremo,
                                            XYZ.BasisZ);
                                    }
                                }
                            }
                        }
                    }

                    doc.Regenerate();

                    if (tipoGancho != null)
                    {
                        bool idsGanchosValidos =
                            rebar.GetHookTypeId(0) == tipoGancho.Id &&
                            rebar.GetHookTypeId(1) == tipoGancho.Id;

                        if (!idsGanchosValidos ||
                            !RebarContieneGanchos(rebar))
                        {
                            ultimoErrorCreacion =
                                descripcion +
                                " - el cuerpo Free Form se creó, pero Revit " +
                                "no conservó ambos ganchos.";
                            subTransaccion.RollBack();
                            continue;
                        }

                        if (!RebarGanchosHaciaInterior(
                                rebar,
                                perfilBase))
                        {
                            ultimoErrorCreacion =
                                descripcion +
                                " - los ganchos Free Form quedaron fuera del " +
                                "núcleo para la orientación " +
                                combinacion.Item1 + "/" +
                                combinacion.Item2 + ".";
                            subTransaccion.RollBack();
                            continue;
                        }
                    }

                    subTransaccion.Commit();
                    ultimoErrorCreacion = "";
                    return rebar;
                }
                catch (Exception ex)
                {
                    ultimoErrorCreacion =
                        descripcion + " [" +
                        combinacion.Item1 + "/" +
                        combinacion.Item2 + "] - " +
                        ex.GetType().Name + ": " + ex.Message;

                    try
                    {
                        if (subTransaccion.GetStatus() ==
                            TransactionStatus.Started)
                        {
                            subTransaccion.RollBack();
                        }
                    }
                    catch
                    {
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(ultimoErrorCreacion))
            {
                if (erroresIntentos.Length > 0)
                    erroresIntentos += " | ";

                erroresIntentos += ultimoErrorCreacion;
            }
        }

        ultimoErrorCreacion =
            descripcion +
            " - no se pudo crear el estribo circular como Free Form Rebar." +
            (string.IsNullOrWhiteSpace(erroresIntentos)
                ? ""
                : " Intentos: " + erroresIntentos);

        return null;
    }

    private PerfilEstriboPreparado PrepararPerfilEstribo(
        DatosColumna datos,
        List<PuntoLocal> puntosOriginales,
        bool cerrado,
        RebarBarType tipoBarra,
        RebarHookType tipoGancho,
        int indiceEsquinaGancho,
        AceroColumnaTipoEstribo2D tipoDiseno,
        double diametroLongitudinal,
        double recubrimiento,
        List<PuntoLocal> centrosLongitudinales,
        double elevacion,
        int alternativaAperturaCroquisMYG = 0)
    {
        if (datos == null || puntosOriginales == null)
            return null;

        List<PuntoLocal> puntos = new List<PuntoLocal>();

        foreach (PuntoLocal punto in puntosOriginales)
        {
            if (punto == null)
                continue;

            if (puntos.Count == 0 ||
                Distancia(puntos[puntos.Count - 1], punto) > TolGeometria)
            {
                puntos.Add(punto.Copiar());
            }
        }

        if (cerrado && puntos.Count > 2 &&
            Distancia(puntos[0], puntos[puntos.Count - 1]) <= TolGeometria)
        {
            puntos.RemoveAt(puntos.Count - 1);
        }

        int minimo = cerrado ? 3 : 2;

        if (puntos.Count < minimo)
            return null;

        // CROQUIS: eliminar vértices intermedios estrictamente colineales.
        // Una línea de croquis subdividida por puntos CAD/Revit produce
        // demasiados segmentos para identificar una RebarShape paramétrica.
        // Se conserva cada esquina verdadera y no se modifica el croquis UI.
        if (cerrado && tipoDiseno == AceroColumnaTipoEstribo2D.Croquis)
        {
            puntos = SimplificarVerticesColinealesCroquisMYG(puntos);
            if (puntos.Count < 3)
            {
                ultimoErrorCreacion =
                    "Croquis: la sección no conserva tres vértices válidos.";
                return null;
            }
        }

        List<PuntoLocal> contornoActivo =
            ObtenerContornoAdecuado(datos, puntos);

        // Los puntos dibujados en la ventana pueden coincidir con los centros
        // de barras longitudinales. Para rombos y cuadriláteros derivados de
        // ellos, se reemplaza cada vértice vinculado por la intersección de las
        // dos tangentes a la barra. De esta manera la armadura abraza la barra
        // y llega al mismo nivel del estribo exterior, sin quedar retraída.
        if (cerrado &&
            (tipoDiseno == AceroColumnaTipoEstribo2D.Rombo ||
             tipoDiseno == AceroColumnaTipoEstribo2D.CuadrilateroLibre) &&
            centrosLongitudinales != null &&
            centrosLongitudinales.Count > 0)
        {
            puntos = AjustarVerticesCerradosATangenciaLongitudinales(
                puntos,
                centrosLongitudinales,
                diametroLongitudinal,
                ObtenerDiametroModeloBarra(tipoBarra),
                ObtenerRadioDobladoEjeEstribo(tipoBarra),
                contornoActivo);
        }

        PerfilEstriboPreparado resultado = new PerfilEstriboPreparado
        {
            Datos = datos,
            Elevacion = elevacion,
            PoligonoOriginal = puntos.Select(x => x.Copiar()).ToList()
        };

        if (cerrado &&
            tipoDiseno == AceroColumnaTipoEstribo2D.Circular)
        {
            return PrepararPerfilEstriboCircular(
                datos,
                puntos,
                tipoBarra,
                tipoGancho,
                indiceEsquinaGancho,
                diametroLongitudinal,
                centrosLongitudinales,
                elevacion);
        }

        List<PuntoLocal> cadena = puntos.Select(x => x.Copiar()).ToList();

        bool esGanchoTipoC =
            tipoDiseno == AceroColumnaTipoEstribo2D.TrabaC;
        bool esGanchoTipoS =
            tipoDiseno == AceroColumnaTipoEstribo2D.TrabaS;
        bool esGanchoAnterior =
            tipoDiseno == AceroColumnaTipoEstribo2D.TrabaGancho;

        if (!cerrado &&
            (esGanchoTipoC || esGanchoTipoS || esGanchoAnterior) &&
            cadena.Count >= 2)
        {
            RebarTerminationOrientation orientacionInicio;
            RebarTerminationOrientation orientacionFin;

            cadena = PrepararGanchoAdaptadoLongitudinales(
                cadena[0],
                cadena[cadena.Count - 1],
                esGanchoTipoS,
                diametroLongitudinal,
                ObtenerDiametroModeloBarra(tipoBarra),
                ObtenerRadioDobladoEjeEstribo(tipoBarra),
                contornoActivo,
                out orientacionInicio,
                out orientacionFin);

            resultado.OrientacionInicio = orientacionInicio;
            resultado.OrientacionFin = orientacionFin;
        }

        if (cerrado && tipoGancho != null)
        {
            int esquinaGancho = ResolverIndiceEsquinaGancho(
                puntos,
                indiceEsquinaGancho);

            // Para CROQUIS con dos ganchos de 135° NO se puede pasar a
            // CreateFromCurves una cadena cuyo primer y último punto coinciden.
            // Esa es precisamente la cadena que usa el resto del Handler para
            // estribos cerrados y es la que disparaba "no RebarShape compatible".
            // Se abre únicamente el croquis cerca de la esquina seleccionada;
            // Revit añade después los dos ganchos, sin repetir segmentos.
            if (tipoDiseno == AceroColumnaTipoEstribo2D.Croquis)
            {
                cadena = AbrirCadenaCroquis135MYG(
                    puntos,
                    esquinaGancho,
                    tipoBarra,
                    alternativaAperturaCroquisMYG);
            }
            else
            {
                cadena = CerrarContornoEnEsquinaParaGanchos(
                    puntos,
                    esquinaGancho);
            }

            if (cadena == null || cadena.Count < 4)
                return null;

            resultado.OrientacionInicio =
                ResolverOrientacionGanchoInicio(cadena, puntos);
            resultado.OrientacionFin =
                ResolverOrientacionGanchoFin(cadena, puntos);
        }

        resultado.CadenaLocal = cadena.Select(x => x.Copiar()).ToList();

        int cantidadSegmentos = cerrado && tipoGancho == null
            ? cadena.Count
            : cadena.Count - 1;

        for (int i = 0; i < cantidadSegmentos; i++)
        {
            PuntoLocal a = cadena[i];
            PuntoLocal b = cerrado && tipoGancho == null
                ? cadena[(i + 1) % cadena.Count]
                : cadena[i + 1];

            XYZ q1 = LocalAMundial(datos, a, elevacion);
            XYZ q2 = LocalAMundial(datos, b, elevacion);

            if (q1.DistanceTo(q2) <= TolGeometria)
                continue;

            resultado.Curvas.Add(Line.CreateBound(q1, q2));
        }

        return resultado.Curvas.Count > 0 ? resultado : null;
    }

    private PerfilEstriboPreparado PrepararPerfilEstriboCircular(
        DatosColumna datos,
        List<PuntoLocal> puntos,
        RebarBarType tipoBarra,
        RebarHookType tipoGancho,
        int indiceEsquinaGancho,
        double diametroLongitudinal,
        List<PuntoLocal> centrosLongitudinales,
        double elevacion)
    {
        if (datos == null || puntos == null || puntos.Count < 8)
            return null;

        PuntoLocal centro;
        double radio;
        if (!TryAjustarCirculoPuntos(puntos, out centro, out radio))
        {
            ultimoErrorCreacion =
                "No se pudo reconstruir el recorrido circular real.";
            return null;
        }

        int indiceCierre = ResolverIndiceEsquinaGancho(
            puntos,
            indiceEsquinaGancho);

        if (indiceCierre < 0 || indiceCierre >= puntos.Count)
            indiceCierre = 0;

        PuntoLocal puntoCierrePreferido = puntos[indiceCierre];

        double anguloPreferido = Math.Atan2(
            puntoCierrePreferido.Y - centro.Y,
            puntoCierrePreferido.X - centro.X);

        double diametroEstribo = Math.Max(
            ObtenerDiametroModeloBarra(tipoBarra),
            TolGeometria);

        // El cierre de un estribo circular debe coincidir con una barra
        // longitudinal periférica. El índice dibujado por el usuario define la
        // dirección preferida y, dentro de esa dirección, se escoge la barra
        // longitudinal más próxima al recorrido circular.
        double anguloCierre = ResolverAnguloCierreCircularEnLongitudinal(
            centro,
            radio,
            anguloPreferido,
            centrosLongitudinales,
            diametroLongitudinal,
            diametroEstribo);

        const int muestrasPoligono = 64;
        List<PuntoLocal> poligono = new List<PuntoLocal>();

        for (int i = 0; i < muestrasPoligono; i++)
        {
            double angulo =
                2.0 * Math.PI * i / muestrasPoligono;

            poligono.Add(new PuntoLocal(
                centro.X + radio * Math.Cos(angulo),
                centro.Y + radio * Math.Sin(angulo)));
        }

        PerfilEstriboPreparado resultado =
            new PerfilEstriboPreparado
            {
                Datos = datos,
                Elevacion = elevacion,
                PoligonoOriginal = poligono
            };

        double anguloInicio;
        double barridoTotal;

        if (tipoGancho == null)
        {
            // Sin ganchos se conserva el círculo completo.
            anguloInicio = anguloCierre;
            barridoTotal = 2.0 * Math.PI;
        }
        else
        {
            // Un recorrido completamente cerrado no admite dos terminaciones en
            // el mismo punto. Se deja una abertura calculada alrededor de la
            // barra longitudinal de amarre y Revit agrega los dos ganchos de
            // 135° en los extremos de esta cadena abierta.
            double radioDoblado = Math.Max(
                ObtenerRadioDobladoEjeEstribo(tipoBarra),
                diametroEstribo);

            double radioLongitudinal = Math.Max(
                diametroLongitudinal * 0.5,
                diametroEstribo * 0.5);

            double semianchoAbertura = Math.Max(
                radioLongitudinal + diametroEstribo * 0.5,
                radioDoblado + diametroEstribo * 0.5);

            // La abertura depende de los diámetros y del radio de doblado, pero
            // se limita para que el cuerpo circular siga siendo dominante.
            semianchoAbertura = Math.Min(
                semianchoAbertura,
                radio * 0.33);

            double relacion = radio <= TolGeometria
                ? 0.08
                : semianchoAbertura / radio;

            relacion = Math.Max(
                0.015,
                Math.Min(0.33, relacion));

            double medioAnguloAbertura = Math.Asin(relacion);

            anguloInicio = anguloCierre + medioAnguloAbertura;
            barridoTotal =
                2.0 * Math.PI - 2.0 * medioAnguloAbertura;
        }

        // La cadena local se utiliza para resolver la orientación interior de
        // ambos ganchos y para validar posteriormente su geometría.
        int muestrasCadena = Math.Max(
            24,
            (int)Math.Ceiling(
                barridoTotal / (Math.PI / 24.0)));

        List<PuntoLocal> cadena = new List<PuntoLocal>();

        for (int i = 0; i <= muestrasCadena; i++)
        {
            double t = (double)i / muestrasCadena;
            double angulo = anguloInicio + barridoTotal * t;

            cadena.Add(new PuntoLocal(
                centro.X + radio * Math.Cos(angulo),
                centro.Y + radio * Math.Sin(angulo)));
        }

        resultado.CadenaLocal =
            cadena.Select(x => x.Copiar()).ToList();

        if (tipoGancho != null)
        {
            resultado.OrientacionInicio =
                ResolverOrientacionGanchoInicio(
                    cadena,
                    poligono);

            resultado.OrientacionFin =
                ResolverOrientacionGanchoFin(
                    cadena,
                    poligono);
        }

        // Las formas de armadura de Revit no admiten un único arco mayor de
        // 180°. El recorrido se divide en arcos de 90° como máximo.
        int cantidadArcos = Math.Max(
            1,
            (int)Math.Ceiling(
                barridoTotal / (Math.PI * 0.5)));

        double barridoArco =
            barridoTotal / cantidadArcos;

        for (int i = 0; i < cantidadArcos; i++)
        {
            double a0 =
                anguloInicio + i * barridoArco;
            double a1 = a0 + barridoArco;
            double am = (a0 + a1) * 0.5;

            XYZ inicio = LocalAMundial(
                datos,
                new PuntoLocal(
                    centro.X + radio * Math.Cos(a0),
                    centro.Y + radio * Math.Sin(a0)),
                elevacion);

            XYZ fin = LocalAMundial(
                datos,
                new PuntoLocal(
                    centro.X + radio * Math.Cos(a1),
                    centro.Y + radio * Math.Sin(a1)),
                elevacion);

            XYZ medio = LocalAMundial(
                datos,
                new PuntoLocal(
                    centro.X + radio * Math.Cos(am),
                    centro.Y + radio * Math.Sin(am)),
                elevacion);

            if (inicio.DistanceTo(fin) <= TolGeometria)
                continue;

            resultado.Curvas.Add(
                Arc.Create(inicio, fin, medio));
        }

        if (resultado.Curvas.Count == 0)
        {
            ultimoErrorCreacion =
                "No se pudo construir la cadena de arcos del estribo circular.";
            return null;
        }

        return resultado;
    }

    private double ResolverAnguloSolapeCircularUnaLongitudinal(
        PuntoLocal centro,
        double radioEstribo,
        double anguloCierre,
        List<PuntoLocal> centrosLongitudinales,
        double diametroLongitudinal,
        double diametroEstribo)
    {
        double unGrado = Math.PI / 180.0;

        if (centro == null || radioEstribo <= TolGeometria)
            return 4.0 * unGrado;

        diametroEstribo = Math.Max(
            diametroEstribo,
            UnitUtils.ConvertToInternalUnits(
                6.0,
                UnitTypeId.Millimeters));

        diametroLongitudinal = Math.Max(
            diametroLongitudinal,
            diametroEstribo);

        // Abertura necesaria para que los dos extremos queden a ambos lados de
        // una sola longitudinal. Se usa la suma de radios de las barras y una
        // pequeña reserva equivalente a medio diámetro del estribo.
        double semianchoFisico =
            diametroLongitudinal * 0.5 +
            diametroEstribo * 1.25;

        double relacion = Math.Min(
            0.95,
            semianchoFisico /
            Math.Max(radioEstribo, TolGeometria));

        double anguloObjetivo =
            2.0 * Math.Asin(relacion);

        double separacionVecina = double.MaxValue;

        if (centrosLongitudinales != null &&
            centrosLongitudinales.Count > 1)
        {
            foreach (PuntoLocal candidato in centrosLongitudinales)
            {
                if (candidato == null)
                    continue;

                double radioCandidato =
                    Distancia(centro, candidato);

                // Solo se consideran longitudinales periféricas capaces de
                // compartir el mismo anillo del estribo.
                if (radioCandidato < radioEstribo * 0.45)
                    continue;

                if (radioCandidato >
                    radioEstribo +
                    Math.Max(
                        diametroLongitudinal,
                        diametroEstribo) * 1.5)
                {
                    continue;
                }

                double anguloCandidato = Math.Atan2(
                    candidato.Y - centro.Y,
                    candidato.X - centro.X);

                double diferencia =
                    DiferenciaAngularCircular(
                        anguloCandidato,
                        anguloCierre);

                // La barra de amarre coincide prácticamente con anguloCierre y
                // no debe contarse como vecina.
                if (diferencia <= 0.25 * unGrado)
                    continue;

                separacionVecina = Math.Min(
                    separacionVecina,
                    diferencia);
            }
        }

        // El sector completo ocupa como máximo el 55 % de la distancia angular
        // hasta la longitudinal vecina más próxima. De este modo sus extremos
        // permanecen claramente dentro de la celda angular de una sola barra.
        double maximoPorVecinos =
            separacionVecina < double.MaxValue
                ? separacionVecina * 0.55
                : 8.0 * unGrado;

        double maximoAbsoluto = 10.0 * unGrado;
        double minimoAbsoluto = 1.0 * unGrado;

        double angulo = Math.Min(
            anguloObjetivo,
            Math.Min(
                maximoPorVecinos,
                maximoAbsoluto));

        // No se fuerza un mínimo mayor que el permitido por los vecinos.
        double minimoAplicable = Math.Min(
            minimoAbsoluto,
            maximoPorVecinos);

        return Math.Max(
            minimoAplicable,
            angulo);
    }

    private double ResolverAnguloCierreCircularEnLongitudinal(
        PuntoLocal centro,
        double radioEstribo,
        double anguloPreferido,
        List<PuntoLocal> centrosLongitudinales,
        double diametroLongitudinal,
        double diametroEstribo)
    {
        if (centro == null ||
            centrosLongitudinales == null ||
            centrosLongitudinales.Count == 0 ||
            radioEstribo <= TolGeometria)
        {
            return anguloPreferido;
        }

        double radioObjetivo = Math.Max(
            TolGeometria,
            radioEstribo -
            (diametroLongitudinal + diametroEstribo) * 0.5);

        PuntoLocal mejor = null;
        double mejorPuntaje = double.MaxValue;

        foreach (PuntoLocal candidato in centrosLongitudinales)
        {
            if (candidato == null)
                continue;

            double radioCandidato =
                Distancia(centro, candidato);

            // Se descartan barras centrales. El cierre debe amarrarse a una
            // barra periférica próxima al estribo.
            if (radioCandidato < radioEstribo * 0.45)
                continue;

            if (radioCandidato >
                radioEstribo +
                Math.Max(
                    diametroLongitudinal,
                    diametroEstribo))
            {
                continue;
            }

            double anguloCandidato = Math.Atan2(
                candidato.Y - centro.Y,
                candidato.X - centro.X);

            double errorAngular =
                DiferenciaAngularCircular(
                    anguloCandidato,
                    anguloPreferido);

            double errorRadial = Math.Abs(
                radioCandidato - radioObjetivo) /
                Math.Max(radioEstribo, TolGeometria);

            double puntaje =
                errorAngular + errorRadial * 0.20;

            if (puntaje < mejorPuntaje)
            {
                mejorPuntaje = puntaje;
                mejor = candidato;
            }
        }

        if (mejor == null)
            return anguloPreferido;

        return Math.Atan2(
            mejor.Y - centro.Y,
            mejor.X - centro.X);
    }

    private double DiferenciaAngularCircular(
        double anguloA,
        double anguloB)
    {
        double diferencia =
            Math.Abs(anguloA - anguloB) %
            (2.0 * Math.PI);

        return diferencia > Math.PI
            ? 2.0 * Math.PI - diferencia
            : diferencia;
    }

    private bool TryAjustarCirculoPuntos(
        IList<PuntoLocal> puntos,
        out PuntoLocal centro,
        out double radio)
    {
        centro = null;
        radio = 0.0;
        if (puntos == null || puntos.Count < 8)
            return false;

        double sx = 0.0;
        double sy = 0.0;
        int cantidad = 0;
        foreach (PuntoLocal p in puntos)
        {
            if (p == null)
                continue;
            sx += p.X;
            sy += p.Y;
            cantidad++;
        }

        if (cantidad < 8)
            return false;

        centro = new PuntoLocal(sx / cantidad, sy / cantidad);
        foreach (PuntoLocal p in puntos)
        {
            if (p != null)
                radio += Distancia(centro, p);
        }
        radio /= cantidad;

        if (radio <= TolGeometria)
            return false;

        double desviacion = 0.0;
        foreach (PuntoLocal p in puntos)
        {
            if (p == null)
                continue;
            desviacion = Math.Max(
                desviacion,
                Math.Abs(Distancia(centro, p) - radio));
        }

        return desviacion <= Math.Max(radio * 0.04, ConvertirCm(0.10));
    }

    private List<PuntoLocal> PrepararGanchoAdaptadoLongitudinales(
        PuntoLocal centroInicio,
        PuntoLocal centroFin,
        bool tipoS,
        double diametroLongitudinal,
        double diametroEstribo,
        double radioDobladoEje,
        List<PuntoLocal> contornoColumna,
        out RebarTerminationOrientation orientacionInicio,
        out RebarTerminationOrientation orientacionFin)
    {
        orientacionInicio = RebarTerminationOrientation.Right;
        orientacionFin = tipoS
            ? RebarTerminationOrientation.Left
            : RebarTerminationOrientation.Right;

        if (centroInicio == null || centroFin == null)
            return new List<PuntoLocal>();

        PuntoLocal direccionCentros = NormalizarPuntoLocal(
            new PuntoLocal(
                centroFin.X - centroInicio.X,
                centroFin.Y - centroInicio.Y));

        if (direccionCentros == null ||
            Math.Abs(direccionCentros.X) +
            Math.Abs(direccionCentros.Y) <= TolGeometria)
        {
            return new List<PuntoLocal>();
        }

        PuntoLocal normalIzquierda = new PuntoLocal(
            -direccionCentros.Y,
            direccionCentros.X);

        PuntoLocal centroide = CentroidePuntos(contornoColumna);
        PuntoLocal puntoMedio = new PuntoLocal(
            (centroInicio.X + centroFin.X) * 0.5,
            (centroInicio.Y + centroFin.Y) * 0.5);

        double productoInterior =
            normalIzquierda.X * (centroide.X - puntoMedio.X) +
            normalIzquierda.Y * (centroide.Y - puntoMedio.Y);

        double signoInterior = productoInterior >= 0.0 ? 1.0 : -1.0;
        PuntoLocal normalInterior = new PuntoLocal(
            normalIzquierda.X * signoInterior,
            normalIzquierda.Y * signoInterior);

        // Distancia entre ejes para que las superficies de la longitudinal
        // y de la grapa resulten tangentes.
        double radioContacto = Math.Max(
            (diametroLongitudinal + diametroEstribo) * 0.5,
            TolGeometria);

        PuntoLocal inicioCuerpo;
        PuntoLocal finCuerpo;
        bool grapaSCentrada = false;

        if (tipoS &&
            TryCalcularCuerpoGrapaSCurvaturasCentradas(
                centroInicio,
                centroFin,
                radioDobladoEje,
                radioContacto,
                normalInterior,
                contornoColumna,
                out inicioCuerpo,
                out finCuerpo))
        {
            grapaSCentrada = true;

            // PRIMER PASO: se conserva la inclinación variable obtenida con
            // la tangente interior común entre las dos curvaturas centradas
            // en las barras longitudinales. No se usa un ángulo constante.
        }
        else
        {
            // Comportamiento de respaldo y comportamiento normal para C.
            // Se conserva la adaptación ya validada por diámetros.
            double ladoInicio = 1.0;
            double ladoFin = tipoS ? -1.0 : 1.0;

            PuntoLocal tangenciaInicio = new PuntoLocal(
                centroInicio.X +
                    normalInterior.X * radioContacto * ladoInicio,
                centroInicio.Y +
                    normalInterior.Y * radioContacto * ladoInicio);

            PuntoLocal tangenciaFin = new PuntoLocal(
                centroFin.X +
                    normalInterior.X * radioContacto * ladoFin,
                centroFin.Y +
                    normalInterior.Y * radioContacto * ladoFin);

            PuntoLocal tangenteCuerpo = NormalizarPuntoLocal(
                new PuntoLocal(
                    tangenciaFin.X - tangenciaInicio.X,
                    tangenciaFin.Y - tangenciaInicio.Y));

            double distanciaEntreCentros = Distancia(
                centroInicio,
                centroFin);

            double extensionAmarre = CalcularExtensionAmarreGancho(
                radioContacto,
                radioDobladoEje,
                distanciaEntreCentros);

            inicioCuerpo = new PuntoLocal(
                tangenciaInicio.X -
                    tangenteCuerpo.X * extensionAmarre,
                tangenciaInicio.Y -
                    tangenteCuerpo.Y * extensionAmarre);

            finCuerpo = new PuntoLocal(
                tangenciaFin.X +
                    tangenteCuerpo.X * extensionAmarre,
                tangenciaFin.Y +
                    tangenteCuerpo.Y * extensionAmarre);

            if (contornoColumna != null && contornoColumna.Count >= 3)
            {
                inicioCuerpo = LimitarPuntoEnDireccionDentroPoligono(
                    tangenciaInicio,
                    inicioCuerpo,
                    contornoColumna);

                finCuerpo = LimitarPuntoEnDireccionDentroPoligono(
                    tangenciaFin,
                    finCuerpo,
                    contornoColumna);
            }
        }

        // SEGUNDO PASO, SOLO PARA GRAPAS S:
        // Los puntos anteriores son los puntos geométricos de tangencia que
        // fijan correctamente la pendiente. Sin embargo, Revit interpreta
        // los extremos de la curva base como vértices teóricos desde los que
        // desarrolla el doblado y el gancho. Por eso se prolongan ambos
        // extremos sobre LA MISMA RECTA VARIABLE. La pendiente no cambia;
        // únicamente se recupera la proyección necesaria para que el arco de
        // doblado envuelva la barra longitudinal.
        if (tipoS && grapaSCentrada)
        {
            PuntoLocal direccionVariable = NormalizarPuntoLocal(
                new PuntoLocal(
                    finCuerpo.X - inicioCuerpo.X,
                    finCuerpo.Y - inicioCuerpo.Y));

            if (direccionVariable != null &&
                Math.Abs(direccionVariable.X) +
                Math.Abs(direccionVariable.Y) > TolGeometria)
            {
                double distanciaEntreCentros = Distancia(
                    centroInicio,
                    centroFin);

                double proyeccionAmarre =
                    CalcularExtensionAmarreGancho(
                        radioContacto,
                        radioDobladoEje,
                        distanciaEntreCentros);

                PuntoLocal baseInicioCentrada = inicioCuerpo.Copiar();
                PuntoLocal baseFinCentrada = finCuerpo.Copiar();

                PuntoLocal inicioProyectado = new PuntoLocal(
                    baseInicioCentrada.X -
                        direccionVariable.X * proyeccionAmarre,
                    baseInicioCentrada.Y -
                        direccionVariable.Y * proyeccionAmarre);

                PuntoLocal finProyectado = new PuntoLocal(
                    baseFinCentrada.X +
                        direccionVariable.X * proyeccionAmarre,
                    baseFinCentrada.Y +
                        direccionVariable.Y * proyeccionAmarre);

                // La prolongación puede llegar hasta la cara del anfitrión,
                // pero nunca atravesarla. Se limita cada extremo de forma
                // independiente sin rotar ni cambiar la pendiente del cuerpo.
                if (contornoColumna != null &&
                    contornoColumna.Count >= 3)
                {
                    inicioProyectado =
                        LimitarPuntoEnDireccionDentroPoligono(
                            baseInicioCentrada,
                            inicioProyectado,
                            contornoColumna);

                    finProyectado =
                        LimitarPuntoEnDireccionDentroPoligono(
                            baseFinCentrada,
                            finProyectado,
                            contornoColumna);
                }

                if (Distancia(
                    inicioProyectado,
                    finProyectado) > TolGeometria)
                {
                    inicioCuerpo = inicioProyectado;
                    finCuerpo = finProyectado;
                }
            }
        }

        PuntoLocal tangenteReal = NormalizarPuntoLocal(
            new PuntoLocal(
                finCuerpo.X - inicioCuerpo.X,
                finCuerpo.Y - inicioCuerpo.Y));

        PuntoLocal direccionGanchoInicio = NormalizarPuntoLocal(
            new PuntoLocal(
                centroInicio.X - inicioCuerpo.X,
                centroInicio.Y - inicioCuerpo.Y));

        PuntoLocal direccionGanchoFin = NormalizarPuntoLocal(
            new PuntoLocal(
                centroFin.X - finCuerpo.X,
                centroFin.Y - finCuerpo.Y));

        orientacionInicio = ResolverOrientacionInicioPorDireccion(
            tangenteReal,
            direccionGanchoInicio);
        orientacionFin = ResolverOrientacionFinPorDireccion(
            tangenteReal,
            direccionGanchoFin);

        // Regla física:
        // - C: ambos ganchos en el mismo lado físico.
        // - S: ganchos en lados físicos opuestos.
        if (tipoS)
        {
            if (orientacionInicio == orientacionFin)
                orientacionFin = InvertirOrientacion(orientacionFin);
        }
        else
        {
            if (orientacionInicio != orientacionFin)
                orientacionFin = orientacionInicio;
        }

        // Sentido de ejecución validado por el usuario en Revit.
        // Solo cambia el lado de las terminaciones; no modifica la posición
        // calculada del cuerpo ni la tangencia/centrado de las curvaturas.
        orientacionInicio = InvertirOrientacion(orientacionInicio);
        orientacionFin = InvertirOrientacion(orientacionFin);

        return new List<PuntoLocal>
        {
            inicioCuerpo,
            finCuerpo
        };
    }

    private bool TryCalcularCuerpoGrapaSCurvaturasCentradas(
        PuntoLocal centroInicio,
        PuntoLocal centroFin,
        double radioDobladoEje,
        double radioContacto,
        PuntoLocal normalInterior,
        List<PuntoLocal> contornoColumna,
        out PuntoLocal inicioCuerpo,
        out PuntoLocal finCuerpo)
    {
        inicioCuerpo = null;
        finCuerpo = null;

        if (centroInicio == null || centroFin == null)
            return false;

        double distanciaCentros = Distancia(
            centroInicio,
            centroFin);

        // Radio real al eje de la curvatura que Revit genera para el
        // tipo de estribo. Usarlo directamente es lo que hace coincidir el
        // centro del arco con el centro de la longitudinal.
        double radioCurvatura = Math.Max(
            radioDobladoEje,
            TolGeometria);

        // Para que exista una tangente interior común entre las dos
        // curvaturas opuestas, la separación debe ser mayor que 2R.
        if (distanciaCentros <=
            2.0 * radioCurvatura + TolGeometria)
        {
            return false;
        }

        PuntoLocal ejeCentros = NormalizarPuntoLocal(
            new PuntoLocal(
                centroFin.X - centroInicio.X,
                centroFin.Y - centroInicio.Y));

        PuntoLocal normalEje = new PuntoLocal(
            -ejeCentros.Y,
            ejeCentros.X);

        // Solución geométrica sin ángulo prefijado:
        // sen(phi) = 2R / D
        // cos(phi) = sqrt(D² - (2R)²) / D
        // Se calculan directamente seno y coseno a partir de R y D;
        // por tanto la inclinación cambia automáticamente con los diámetros
        // y con la separación real entre longitudinales.
        double senoVariable = Math.Max(
            0.0,
            Math.Min(
                0.999999,
                (2.0 * radioCurvatura) / distanciaCentros));

        double cosenoVariable = Math.Sqrt(
            Math.Max(
                0.0,
                1.0 - senoVariable * senoVariable));

        PuntoLocal tangenteA = NormalizarPuntoLocal(
            new PuntoLocal(
                ejeCentros.X * cosenoVariable +
                    normalEje.X * senoVariable,
                ejeCentros.Y * cosenoVariable +
                    normalEje.Y * senoVariable));

        PuntoLocal normalA = new PuntoLocal(
            -tangenteA.Y,
            tangenteA.X);

        PuntoLocal inicioA = new PuntoLocal(
            centroInicio.X - normalA.X * radioCurvatura,
            centroInicio.Y - normalA.Y * radioCurvatura);

        PuntoLocal finA = new PuntoLocal(
            centroFin.X + normalA.X * radioCurvatura,
            centroFin.Y + normalA.Y * radioCurvatura);

        PuntoLocal tangenteB = NormalizarPuntoLocal(
            new PuntoLocal(
                ejeCentros.X * cosenoVariable -
                    normalEje.X * senoVariable,
                ejeCentros.Y * cosenoVariable -
                    normalEje.Y * senoVariable));

        PuntoLocal normalB = new PuntoLocal(
            -tangenteB.Y,
            tangenteB.X);

        PuntoLocal inicioB = new PuntoLocal(
            centroInicio.X + normalB.X * radioCurvatura,
            centroInicio.Y + normalB.Y * radioCurvatura);

        PuntoLocal finB = new PuntoLocal(
            centroFin.X - normalB.X * radioCurvatura,
            centroFin.Y - normalB.Y * radioCurvatura);

        // Referencia del lado que ya fue validado visualmente por el usuario.
        PuntoLocal referenciaInicio = new PuntoLocal(
            centroInicio.X + normalInterior.X * radioContacto,
            centroInicio.Y + normalInterior.Y * radioContacto);

        PuntoLocal referenciaFin = new PuntoLocal(
            centroFin.X - normalInterior.X * radioContacto,
            centroFin.Y - normalInterior.Y * radioContacto);

        double puntajeA = EvaluarCandidatoGrapaS(
            inicioA,
            finA,
            referenciaInicio,
            referenciaFin,
            contornoColumna,
            distanciaCentros);

        double puntajeB = EvaluarCandidatoGrapaS(
            inicioB,
            finB,
            referenciaInicio,
            referenciaFin,
            contornoColumna,
            distanciaCentros);

        if (double.IsInfinity(puntajeA) &&
            double.IsInfinity(puntajeB))
        {
            return false;
        }

        if (puntajeA <= puntajeB)
        {
            inicioCuerpo = inicioA;
            finCuerpo = finA;
        }
        else
        {
            inicioCuerpo = inicioB;
            finCuerpo = finB;
        }

        return inicioCuerpo != null &&
               finCuerpo != null &&
               Distancia(inicioCuerpo, finCuerpo) > TolGeometria;
    }

    private double EvaluarCandidatoGrapaS(
        PuntoLocal inicio,
        PuntoLocal fin,
        PuntoLocal referenciaInicio,
        PuntoLocal referenciaFin,
        List<PuntoLocal> contornoColumna,
        double escala)
    {
        if (inicio == null || fin == null)
            return double.PositiveInfinity;

        double puntaje =
            Distancia(inicio, referenciaInicio) +
            Distancia(fin, referenciaFin);

        if (contornoColumna == null || contornoColumna.Count < 3)
            return puntaje;

        // Se penaliza fuertemente cualquier solución cuyo cuerpo salga del
        // contorno de la columna. No se recortan sus extremos porque hacerlo
        // perdería el centrado exacto de las curvaturas.
        const int muestras = 12;

        for (int i = 0; i <= muestras; i++)
        {
            double t = (double)i / muestras;
            PuntoLocal muestra = new PuntoLocal(
                inicio.X + (fin.X - inicio.X) * t,
                inicio.Y + (fin.Y - inicio.Y) * t);

            if (!PuntoDentroPoligono(muestra, contornoColumna))
                puntaje += Math.Max(escala, 1.0) * 100.0;
        }

        return puntaje;
    }

    private double CalcularExtensionAmarreGancho(
        double radioContacto,
        double radioDobladoEje,
        double distanciaEntreCentros)
    {
        // Misma compensación geométrica utilizada en el rombo, particularizada
        // al doblado de 135° del gancho:
        // e = Rc + Rb * (1 / sin(135° / 2) - 1)
        double senoMedio = Math.Sin(
            135.0 * Math.PI / 360.0);

        double extension =
            radioContacto +
            radioDobladoEje *
            ((1.0 / Math.Max(senoMedio, 0.20)) - 1.0);

        double limitePorDistancia = Math.Max(
            radioContacto,
            distanciaEntreCentros * 0.25);

        return Math.Max(
            radioContacto,
            Math.Min(extension, limitePorDistancia));
    }

    private PuntoLocal LimitarPuntoEnDireccionDentroPoligono(
        PuntoLocal origenDentro,
        PuntoLocal candidato,
        List<PuntoLocal> poligono)
    {
        if (origenDentro == null || candidato == null ||
            poligono == null || poligono.Count < 3)
        {
            return candidato;
        }

        if (PuntoDentroPoligono(candidato, poligono))
            return candidato;

        double inferior = 0.0;
        double superior = 1.0;
        PuntoLocal mejor = origenDentro.Copiar();

        for (int i = 0; i < 32; i++)
        {
            double t = (inferior + superior) * 0.5;
            PuntoLocal prueba = new PuntoLocal(
                origenDentro.X + (candidato.X - origenDentro.X) * t,
                origenDentro.Y + (candidato.Y - origenDentro.Y) * t);

            if (PuntoDentroPoligono(prueba, poligono))
            {
                inferior = t;
                mejor = prueba;
            }
            else
            {
                superior = t;
            }
        }

        return mejor;
    }

    private List<PuntoLocal> AjustarVerticesCerradosATangenciaLongitudinales(
        List<PuntoLocal> verticesDiseno,
        List<PuntoLocal> centrosLongitudinales,
        double diametroLongitudinal,
        double diametroEstribo,
        double radioDobladoEje,
        List<PuntoLocal> contornoColumna)
    {
        List<PuntoLocal> resultado = verticesDiseno == null
            ? new List<PuntoLocal>()
            : verticesDiseno.Select(x => x.Copiar()).ToList();

        if (resultado.Count < 3 ||
            centrosLongitudinales == null ||
            centrosLongitudinales.Count == 0)
        {
            return resultado;
        }

        // Distancia entre ejes cuando la superficie del estribo toca la
        // superficie de la longitudinal.
        double radioContacto = Math.Max(
            (diametroLongitudinal + diametroEstribo) * 0.5,
            TolGeometria);

        radioDobladoEje = Math.Max(
            radioDobladoEje,
            diametroEstribo * 0.5 + TolGeometria);

        double toleranciaVinculo = Math.Max(
            radioContacto * 2.25,
            ConvertirCm(2.5));

        List<PuntoLocal> baseCalculo =
            verticesDiseno.Select(x => x.Copiar()).ToList();

        for (int i = 0; i < baseCalculo.Count; i++)
        {
            PuntoLocal puntoDiseno = baseCalculo[i];
            PuntoLocal centroBarra = centrosLongitudinales
                .OrderBy(x => Distancia(x, puntoDiseno))
                .FirstOrDefault();

            if (centroBarra == null ||
                Distancia(centroBarra, puntoDiseno) > toleranciaVinculo)
            {
                continue;
            }

            PuntoLocal anterior =
                baseCalculo[(i - 1 + baseCalculo.Count) % baseCalculo.Count];
            PuntoLocal siguiente =
                baseCalculo[(i + 1) % baseCalculo.Count];

            PuntoLocal candidato = CalcularVerticeVirtualParaAmarreCurvo(
                centroBarra,
                anterior,
                siguiente,
                baseCalculo,
                radioContacto,
                radioDobladoEje);

            // El vértice enviado a CreateFromCurves es la intersección virtual
            // de los tramos rectos. Por ello puede quedar por fuera del eje del
            // estribo perimetral: Revit lo sustituye por el arco de doblado.
            // Únicamente se limita a la cara del anfitrión para evitar una
            // intersección teórica totalmente externa a la columna.
            if (contornoColumna != null &&
                contornoColumna.Count >= 3 &&
                !PuntoDentroPoligono(candidato, contornoColumna))
            {
                candidato = AjustarPuntoDentroPoligono(
                    candidato,
                    contornoColumna);
            }

            resultado[i] = candidato;
        }

        return resultado;
    }

    private PuntoLocal CalcularVerticeVirtualParaAmarreCurvo(
        PuntoLocal centroLongitudinal,
        PuntoLocal verticeAnterior,
        PuntoLocal verticeSiguiente,
        List<PuntoLocal> poligono,
        double radioContacto,
        double radioDobladoEje)
    {
        if (centroLongitudinal == null ||
            verticeAnterior == null ||
            verticeSiguiente == null)
        {
            return centroLongitudinal != null
                ? centroLongitudinal.Copiar()
                : new PuntoLocal();
        }

        PuntoLocal centroPoligono = CentroidePuntos(poligono);

        PuntoLocal haciaAnterior = NormalizarPuntoLocal(
            new PuntoLocal(
                verticeAnterior.X - centroLongitudinal.X,
                verticeAnterior.Y - centroLongitudinal.Y));
        PuntoLocal haciaSiguiente = NormalizarPuntoLocal(
            new PuntoLocal(
                verticeSiguiente.X - centroLongitudinal.X,
                verticeSiguiente.Y - centroLongitudinal.Y));

        PuntoLocal interior = NormalizarPuntoLocal(
            new PuntoLocal(
                haciaAnterior.X + haciaSiguiente.X,
                haciaAnterior.Y + haciaSiguiente.Y));
        PuntoLocal exterior = new PuntoLocal(-interior.X, -interior.Y);

        PuntoLocal direccionFuera = NormalizarPuntoLocal(
            new PuntoLocal(
                centroLongitudinal.X - centroPoligono.X,
                centroLongitudinal.Y - centroPoligono.Y));

        if (ProductoPunto(exterior, direccionFuera) < 0.0)
        {
            exterior.X *= -1.0;
            exterior.Y *= -1.0;
        }

        PuntoLocal candidato = new PuntoLocal(
            centroLongitudinal.X + exterior.X * radioContacto,
            centroLongitudinal.Y + exterior.Y * radioContacto);

        for (int iteracion = 0; iteracion < 10; iteracion++)
        {
            haciaAnterior = NormalizarPuntoLocal(
                new PuntoLocal(
                    verticeAnterior.X - candidato.X,
                    verticeAnterior.Y - candidato.Y));
            haciaSiguiente = NormalizarPuntoLocal(
                new PuntoLocal(
                    verticeSiguiente.X - candidato.X,
                    verticeSiguiente.Y - candidato.Y));

            interior = NormalizarPuntoLocal(
                new PuntoLocal(
                    haciaAnterior.X + haciaSiguiente.X,
                    haciaAnterior.Y + haciaSiguiente.Y));
            exterior = new PuntoLocal(-interior.X, -interior.Y);

            if (ProductoPunto(exterior, direccionFuera) < 0.0)
            {
                exterior.X *= -1.0;
                exterior.Y *= -1.0;
            }

            double producto = ProductoPunto(
                haciaAnterior,
                haciaSiguiente);
            producto = Math.Max(-1.0, Math.Min(1.0, producto));

            double anguloInterior = Math.Acos(producto);
            double senoMedio = Math.Sin(anguloInterior * 0.5);

            if (senoMedio < 0.20)
                senoMedio = 0.20;

            // Fórmula del vértice virtual que compensa el redondeo real:
            // e = Rc + Rb * (csc(a/2) - 1)
            // Rc = (ØL_modelo + ØE_modelo) / 2
            // Rb = Ødoblado_interior/2 + ØE_modelo/2
            // Con esta extensión, la cara interior de la curva del estribo
            // resulta tangente a la barra longitudinal.
            double extensionVirtual =
                radioContacto +
                radioDobladoEje *
                ((1.0 / senoMedio) - 1.0);

            PuntoLocal nuevo = new PuntoLocal(
                centroLongitudinal.X + exterior.X * extensionVirtual,
                centroLongitudinal.Y + exterior.Y * extensionVirtual);

            if (Distancia(nuevo, candidato) <= TolGeometria * 10.0)
            {
                candidato = nuevo;
                break;
            }

            candidato = new PuntoLocal(
                candidato.X * 0.35 + nuevo.X * 0.65,
                candidato.Y * 0.35 + nuevo.Y * 0.65);
        }

        return candidato;
    }

    private double ProductoPunto(PuntoLocal a, PuntoLocal b)
    {
        if (a == null || b == null)
            return 0.0;

        return a.X * b.X + a.Y * b.Y;
    }

    private RebarTerminationOrientation ResolverOrientacionInicioPorDireccion(
        PuntoLocal tangente,
        PuntoLocal direccionDeseada)
    {
        PuntoLocal derecha = new PuntoLocal(
            -tangente.Y,
            tangente.X);
        PuntoLocal izquierda = new PuntoLocal(
            tangente.Y,
            -tangente.X);

        double productoDerecha =
            derecha.X * direccionDeseada.X +
            derecha.Y * direccionDeseada.Y;
        double productoIzquierda =
            izquierda.X * direccionDeseada.X +
            izquierda.Y * direccionDeseada.Y;

        return productoDerecha >= productoIzquierda
            ? RebarTerminationOrientation.Right
            : RebarTerminationOrientation.Left;
    }

    private RebarTerminationOrientation ResolverOrientacionFinPorDireccion(
        PuntoLocal tangente,
        PuntoLocal direccionDeseada)
    {
        PuntoLocal derecha = new PuntoLocal(
            tangente.Y,
            -tangente.X);
        PuntoLocal izquierda = new PuntoLocal(
            -tangente.Y,
            tangente.X);

        double productoDerecha =
            derecha.X * direccionDeseada.X +
            derecha.Y * direccionDeseada.Y;
        double productoIzquierda =
            izquierda.X * direccionDeseada.X +
            izquierda.Y * direccionDeseada.Y;

        return productoDerecha >= productoIzquierda
            ? RebarTerminationOrientation.Right
            : RebarTerminationOrientation.Left;
    }

    private int ResolverIndiceEsquinaGancho(
        List<PuntoLocal> puntos,
        int indiceSolicitado)
    {
        if (puntos == null || puntos.Count == 0)
            return -1;

        if (indiceSolicitado >= 0 &&
            indiceSolicitado < puntos.Count)
        {
            return indiceSolicitado;
        }

        double minX = puntos.Min(x => x.X);
        double maxX = puntos.Max(x => x.X);
        double minY = puntos.Min(x => x.Y);
        double maxY = puntos.Max(x => x.Y);
        double ancho = Math.Max(maxX - minX, TolGeometria);
        double alto = Math.Max(maxY - minY, TolGeometria);
        int mejorIndice = 0;
        double mejorPuntaje = double.MinValue;

        for (int i = 0; i < puntos.Count; i++)
        {
            double nx = (puntos[i].X - minX) / ancho;
            double ny = (puntos[i].Y - minY) / alto;
            double puntaje = nx + ny;

            if (puntaje > mejorPuntaje)
            {
                mejorPuntaje = puntaje;
                mejorIndice = i;
            }
        }

        return mejorIndice;
    }

    // =============================================================
    // MYG: APERTURA GEOMÉTRICA DE CROQUIS PARA DOS GANCHOS DE 135°
    // =============================================================
    // Los vértices del usuario se respetan: sólo se abre una distancia
    // corta en la esquina de gancho para que CreateFromCurves reciba
    // una cadena ABIERTA. Esto no mueve la sección, no cambia las
    // alturas y mantiene cada zona vertical como un solo Rebar Set.
    // alternativa 0: pequeña apertura en el lado siguiente a esquina.
    // alternativa 1: apertura en el lado anterior a esquina.
    // alternativa 2: pequeña apertura a ambos lados de esquina.
    // Limpieza conservadora de croquis: elimina exclusivamente puntos
    // sobre un segmento recto en el mismo sentido. No aproxima curvas,
    // no desplaza ejes y no borra esquinas interiores de una sección en L.
    private List<PuntoLocal> SimplificarVerticesColinealesCroquisMYG(
        List<PuntoLocal> original)
    {
        List<PuntoLocal> pts = original == null
            ? new List<PuntoLocal>()
            : original.Where(p => p != null)
                .Select(p => p.Copiar()).ToList();

        if (pts.Count < 4)
            return pts;

        double errorMaximo = ConvertirCm(0.02); // 0.2 mm
        bool cambio = true;
        int vueltas = 0;
        while (cambio && pts.Count > 3 && vueltas++ < 1000)
        {
            cambio = false;
            for (int i = 0; i < pts.Count; i++)
            {
                PuntoLocal a = pts[(i + pts.Count - 1) % pts.Count];
                PuntoLocal b = pts[i];
                PuntoLocal c = pts[(i + 1) % pts.Count];
                double abx = b.X - a.X;
                double aby = b.Y - a.Y;
                double bcx = c.X - b.X;
                double bcy = c.Y - b.Y;
                double lab = Math.Sqrt(abx * abx + aby * aby);
                double lbc = Math.Sqrt(bcx * bcx + bcy * bcy);
                if (lab < TolGeometria || lbc < TolGeometria)
                {
                    pts.RemoveAt(i);
                    cambio = true;
                    break;
                }
                double cruz = abx * bcy - aby * bcx;
                double producto = abx * bcx + aby * bcy;
                // Eliminar solo si son colineales y avanzan en el mismo sentido.
                if (producto > 0.0 &&
                    Math.Abs(cruz) / lab <= errorMaximo)
                {
                    pts.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }
        return pts;
    }

    private List<PuntoLocal> AbrirCadenaCroquis135MYG(
        List<PuntoLocal> puntos,
        int indiceEsquina,
        RebarBarType tipoBarra,
        int alternativa)
    {
        if (puntos == null || puntos.Count < 3)
            return null;

        int n = puntos.Count;
        if (indiceEsquina < 0 || indiceEsquina >= n)
            indiceEsquina = ResolverIndiceEsquinaGancho(puntos, -1);

        PuntoLocal esquina = puntos[indiceEsquina];
        PuntoLocal siguiente = puntos[(indiceEsquina + 1) % n];
        PuntoLocal anterior = puntos[(indiceEsquina + n - 1) % n];

        double ladoSiguiente = Distancia(esquina, siguiente);
        double ladoAnterior = Distancia(esquina, anterior);
        if (ladoSiguiente <= TolGeometria ||
            ladoAnterior <= TolGeometria)
            return null;

        double db = tipoBarra != null
            ? ObtenerDiametroBarra(tipoBarra)
            : ConvertirCm(1.0);
        double aperturaSolicitada = Math.Max(
            1.5 * db,
            ConvertirCm(1.0));

        // Limitar la apertura al 10 % del lado y preservar los
        // vértices y la geometría fundamental del Croquis.
        double retiroInicio = Math.Min(
            aperturaSolicitada,
            ladoSiguiente * 0.10);
        double retiroFin = Math.Min(
            aperturaSolicitada,
            ladoAnterior * 0.10);

        List<PuntoLocal> cadena = new List<PuntoLocal>();

        if (alternativa == 0 || alternativa == 2)
        {
            cadena.Add(PuntoDesdeEsquina(
                esquina, siguiente, retiroInicio));
        }
        else
        {
            cadena.Add(esquina.Copiar());
        }

        for (int paso = 1; paso < n; paso++)
        {
            int j = (indiceEsquina + paso) % n;
            PuntoLocal p = puntos[j];
            if (Distancia(cadena[cadena.Count - 1], p) >
                TolGeometria)
            {
                cadena.Add(p.Copiar());
            }
        }

        if (alternativa == 1 || alternativa == 2)
        {
            PuntoLocal finAbierto = PuntoDesdeEsquina(
                esquina, anterior, retiroFin);
            if (Distancia(cadena[cadena.Count - 1],
                finAbierto) > TolGeometria)
            {
                cadena.Add(finAbierto);
            }
        }
        else
        {
            cadena.Add(esquina.Copiar());
        }

        if (cadena.Count < 4 ||
            Distancia(cadena[0],
                cadena[cadena.Count - 1]) <= TolGeometria)
        {
            return null;
        }

        return cadena;
    }

    private List<PuntoLocal> CerrarContornoEnEsquinaParaGanchos(
        List<PuntoLocal> puntos,
        int indiceEsquina)
    {
        if (puntos == null || puntos.Count < 3)
            return null;

        int cantidad = puntos.Count;

        if (indiceEsquina < 0 || indiceEsquina >= cantidad)
            indiceEsquina = ResolverIndiceEsquinaGancho(puntos, -1);

        // La cadena inicia y termina exactamente en la misma esquina.
        // Así el cuerpo del estribo recorre todos los lados y cierra por
        // completo la esquina donde se aplican las dos terminaciones de 135°.
        // La barra longitudinal de esquina queda dentro del confinamiento.
        List<PuntoLocal> cadena = new List<PuntoLocal>();
        cadena.Add(puntos[indiceEsquina].Copiar());

        for (int paso = 1; paso < cantidad; paso++)
        {
            int indice = (indiceEsquina + paso) % cantidad;
            cadena.Add(puntos[indice].Copiar());
        }

        cadena.Add(puntos[indiceEsquina].Copiar());
        return cadena;
    }

    private PuntoLocal PuntoDesdeEsquina(
        PuntoLocal esquina,
        PuntoLocal destino,
        double distancia)
    {
        double longitud = Distancia(esquina, destino);

        if (longitud <= TolGeometria)
            return esquina.Copiar();

        double factor = Math.Min(
            1.0,
            Math.Max(0.0, distancia / longitud));

        return new PuntoLocal(
            esquina.X + (destino.X - esquina.X) * factor,
            esquina.Y + (destino.Y - esquina.Y) * factor);
    }

    private double AreaFirmadaPuntos(List<PuntoLocal> puntos)
    {
        if (puntos == null || puntos.Count < 3)
            return 0.0;

        double area = 0.0;

        for (int i = 0; i < puntos.Count; i++)
        {
            PuntoLocal a = puntos[i];
            PuntoLocal b = puntos[(i + 1) % puntos.Count];
            area += a.X * b.Y - b.X * a.Y;
        }

        return area * 0.5;
    }

    private Rebar CrearEstriboConGanchoSeguro(
        Document doc,
        Element host,
        RebarBarType tipoBarra,
        RebarHookType tipoGancho,
        PerfilEstriboPreparado perfil,
        System.Action<Rebar> configurarDespuesCrear,
        System.Func<Rebar, bool> validarInterior,
        string descripcion,
        bool exigirMetradoNativoMYG = false)
    {
        if (tipoGancho == null || perfil == null)
            return null;

        List<Tuple<RebarTerminationOrientation, RebarTerminationOrientation>>
            combinaciones =
            new List<Tuple<RebarTerminationOrientation, RebarTerminationOrientation>>();

        AgregarCombinacionOrientacion(
            combinaciones,
            perfil.OrientacionInicio,
            perfil.OrientacionFin);
        AgregarCombinacionOrientacion(
            combinaciones,
            InvertirOrientacion(perfil.OrientacionInicio),
            perfil.OrientacionFin);
        AgregarCombinacionOrientacion(
            combinaciones,
            perfil.OrientacionInicio,
            InvertirOrientacion(perfil.OrientacionFin));
        AgregarCombinacionOrientacion(
            combinaciones,
            InvertirOrientacion(perfil.OrientacionInicio),
            InvertirOrientacion(perfil.OrientacionFin));

        string erroresIntentos = "";

        foreach (Tuple<RebarTerminationOrientation,
                       RebarTerminationOrientation> combinacion in combinaciones)
        {
            ultimoErrorCreacion = "";

            Rebar creado = CrearRebarShapeDrivenSeguro(
                doc,
                RebarStyle.StirrupTie,
                tipoBarra,
                host,
                XYZ.BasisZ,
                perfil.Curvas,
                tipoGancho,
                tipoGancho,
                combinacion.Item1,
                combinacion.Item2,
                true,
                configurarDespuesCrear,
                descripcion +
                " con ganchos 135° interiores [" +
                combinacion.Item1 + "/" +
                combinacion.Item2 + "]",
                validarInterior,
                exigirMetradoNativoMYG);

            if (creado != null)
                return creado;

            if (!string.IsNullOrWhiteSpace(ultimoErrorCreacion))
            {
                if (erroresIntentos.Length > 0)
                    erroresIntentos += " | ";

                erroresIntentos +=
                    combinacion.Item1 + "/" + combinacion.Item2 +
                    ": " + ultimoErrorCreacion;
            }
        }

        ultimoErrorCreacion =
            descripcion +
            " - Revit no encontró una combinación de orientación que " +
            "mantenga ambos ganchos de 135° dentro del estribo." +
            (string.IsNullOrWhiteSpace(erroresIntentos)
                ? ""
                : " Intentos: " + erroresIntentos);

        return null;
    }

    private void AgregarCombinacionOrientacion(
        List<Tuple<RebarTerminationOrientation,
                   RebarTerminationOrientation>> combinaciones,
        RebarTerminationOrientation inicio,
        RebarTerminationOrientation fin)
    {
        if (combinaciones == null)
            return;

        bool existe = combinaciones.Any(x =>
            x.Item1 == inicio && x.Item2 == fin);

        if (!existe)
        {
            combinaciones.Add(
                Tuple.Create(inicio, fin));
        }
    }

    private RebarTerminationOrientation ResolverOrientacionGanchoInicio(
        List<PuntoLocal> cadena,
        List<PuntoLocal> poligono)
    {
        if (cadena == null || cadena.Count < 2)
            return RebarTerminationOrientation.Right;

        PuntoLocal tangente = NormalizarPuntoLocal(
            new PuntoLocal(
                cadena[1].X - cadena[0].X,
                cadena[1].Y - cadena[0].Y));

        // En el inicio, según la definición de Revit:
        // Right = normal x tangente; Left = tangente x normal.
        PuntoLocal derecha = new PuntoLocal(
            -tangente.Y,
            tangente.X);
        PuntoLocal izquierda = new PuntoLocal(
            tangente.Y,
            -tangente.X);

        return ElegirOrientacionPorInterior(
            cadena[0],
            derecha,
            izquierda,
            poligono);
    }

    private RebarTerminationOrientation ResolverOrientacionGanchoFin(
        List<PuntoLocal> cadena,
        List<PuntoLocal> poligono)
    {
        if (cadena == null || cadena.Count < 2)
            return RebarTerminationOrientation.Left;

        int ultimo = cadena.Count - 1;
        PuntoLocal tangente = NormalizarPuntoLocal(
            new PuntoLocal(
                cadena[ultimo].X - cadena[ultimo - 1].X,
                cadena[ultimo].Y - cadena[ultimo - 1].Y));

        // En el final, Right = tangente x normal; Left = normal x tangente.
        PuntoLocal derecha = new PuntoLocal(
            tangente.Y,
            -tangente.X);
        PuntoLocal izquierda = new PuntoLocal(
            -tangente.Y,
            tangente.X);

        return ElegirOrientacionPorInterior(
            cadena[ultimo],
            derecha,
            izquierda,
            poligono);
    }

    private RebarTerminationOrientation ElegirOrientacionPorInterior(
        PuntoLocal extremo,
        PuntoLocal direccionRight,
        PuntoLocal direccionLeft,
        List<PuntoLocal> poligono)
    {
        if (extremo == null || poligono == null || poligono.Count < 3)
            return RebarTerminationOrientation.Right;

        RectanguloLocal caja = ObtenerCaja(poligono);
        double escala = caja == null
            ? ConvertirCm(2.0)
            : Math.Max(
                Math.Min(caja.Ancho, caja.Alto) * 0.08,
                ConvertirCm(1.0));

        PuntoLocal puntoRight = new PuntoLocal(
            extremo.X + direccionRight.X * escala,
            extremo.Y + direccionRight.Y * escala);
        PuntoLocal puntoLeft = new PuntoLocal(
            extremo.X + direccionLeft.X * escala,
            extremo.Y + direccionLeft.Y * escala);

        bool rightDentro = PuntoDentroPoligono(puntoRight, poligono);
        bool leftDentro = PuntoDentroPoligono(puntoLeft, poligono);

        if (rightDentro && !leftDentro)
            return RebarTerminationOrientation.Right;

        if (leftDentro && !rightDentro)
            return RebarTerminationOrientation.Left;

        PuntoLocal centro = CentroidePuntos(poligono);
        PuntoLocal haciaCentro = NormalizarPuntoLocal(
            new PuntoLocal(
                centro.X - extremo.X,
                centro.Y - extremo.Y));

        double productoRight =
            direccionRight.X * haciaCentro.X +
            direccionRight.Y * haciaCentro.Y;
        double productoLeft =
            direccionLeft.X * haciaCentro.X +
            direccionLeft.Y * haciaCentro.Y;

        return productoRight >= productoLeft
            ? RebarTerminationOrientation.Right
            : RebarTerminationOrientation.Left;
    }

    private PuntoLocal NormalizarPuntoLocal(PuntoLocal vector)
    {
        if (vector == null)
            return new PuntoLocal(1.0, 0.0);

        double longitud = Math.Sqrt(
            vector.X * vector.X + vector.Y * vector.Y);

        if (longitud <= TolGeometria)
            return new PuntoLocal(1.0, 0.0);

        return new PuntoLocal(
            vector.X / longitud,
            vector.Y / longitud);
    }

    private PuntoLocal CentroidePuntos(List<PuntoLocal> puntos)
    {
        if (puntos == null || puntos.Count == 0)
            return new PuntoLocal();

        double x = 0.0;
        double y = 0.0;

        foreach (PuntoLocal punto in puntos)
        {
            x += punto.X;
            y += punto.Y;
        }

        return new PuntoLocal(
            x / puntos.Count,
            y / puntos.Count);
    }

    private RebarTerminationOrientation InvertirOrientacion(
        RebarTerminationOrientation orientacion)
    {
        return orientacion == RebarTerminationOrientation.Right
            ? RebarTerminationOrientation.Left
            : RebarTerminationOrientation.Right;
    }

    private bool GanchoPermitidoParaTipoBarra(
        RebarBarType tipoBarra,
        RebarHookType tipoGancho)
    {
        if (tipoBarra == null || tipoGancho == null)
            return true;

        try
        {
            System.Reflection.MethodInfo[] metodos =
                typeof(RebarBarType).GetMethods();

            foreach (System.Reflection.MethodInfo metodo in metodos)
            {
                if (!metodo.Name.Equals(
                    "GetHookPermission",
                    StringComparison.Ordinal) ||
                    metodo.GetParameters().Length != 1)
                {
                    continue;
                }

                Type tipoParametro = metodo.GetParameters()[0].ParameterType;
                object argumento = null;

                if (tipoParametro == typeof(ElementId))
                    argumento = tipoGancho.Id;
                else if (tipoParametro.IsAssignableFrom(typeof(RebarHookType)))
                    argumento = tipoGancho;

                if (argumento == null)
                    continue;

                object valor = metodo.Invoke(
                    tipoBarra,
                    new object[] { argumento });

                if (valor is bool)
                    return (bool)valor;
            }
        }
        catch
        {
        }

        return true;
    }

    private bool RebarContieneGanchos(Rebar rebar)
    {
        if (rebar == null)
            return false;

        try
        {
            IList<Curve> sinGanchos = rebar.GetCenterlineCurves(
                false,
                true,
                false,
                MultiplanarOption.IncludeOnlyPlanarCurves,
                0);

            IList<Curve> conGanchos = rebar.GetCenterlineCurves(
                false,
                false,
                false,
                MultiplanarOption.IncludeOnlyPlanarCurves,
                0);

            if (conGanchos == null || conGanchos.Count == 0)
                return false;

            double longitudSin = sinGanchos == null
                ? 0.0
                : sinGanchos.Sum(x => x != null ? x.Length : 0.0);

            double longitudCon = conGanchos.Sum(
                x => x != null ? x.Length : 0.0);

            return conGanchos.Count > (sinGanchos != null ? sinGanchos.Count : 0) ||
                   longitudCon > longitudSin + TolGeometria;
        }
        catch
        {
            return false;
        }
    }

    private bool RebarGanchosHaciaInterior(
        Rebar rebar,
        PerfilEstriboPreparado perfil)
    {
        if (rebar == null || perfil == null ||
            perfil.Datos == null ||
            perfil.PoligonoOriginal == null ||
            perfil.PoligonoOriginal.Count < 3 ||
            perfil.Curvas == null || perfil.Curvas.Count == 0)
        {
            return false;
        }

        try
        {
            IList<Curve> curvasConGanchos =
                rebar.GetCenterlineCurves(
                    false,
                    false,
                    false,
                    MultiplanarOption.IncludeOnlyPlanarCurves,
                    0);

            if (curvasConGanchos == null ||
                curvasConGanchos.Count == 0)
            {
                return false;
            }

            List<XYZ> terminales =
                ObtenerTerminalesCadena(curvasConGanchos);

            XYZ baseInicio = perfil.Curvas[0].GetEndPoint(0);
            XYZ baseFin =
                perfil.Curvas[perfil.Curvas.Count - 1].GetEndPoint(1);

            if (terminales.Count < 2)
            {
                Curve primera = curvasConGanchos[0];
                Curve ultima =
                    curvasConGanchos[curvasConGanchos.Count - 1];

                XYZ primera0 = primera.GetEndPoint(0);
                XYZ primera1 = primera.GetEndPoint(1);
                XYZ ultima0 = ultima.GetEndPoint(0);
                XYZ ultima1 = ultima.GetEndPoint(1);

                XYZ posibleInicio =
                    primera0.DistanceTo(baseInicio) >=
                    primera1.DistanceTo(baseInicio)
                        ? primera0
                        : primera1;
                XYZ posibleFin =
                    ultima0.DistanceTo(baseFin) >=
                    ultima1.DistanceTo(baseFin)
                        ? ultima0
                        : ultima1;

                terminales = new List<XYZ>
                {
                    posibleInicio,
                    posibleFin
                };
            }

            XYZ terminalA = terminales[0];
            XYZ terminalB = terminales[1];

            double asignacionDirecta =
                terminalA.DistanceTo(baseInicio) +
                terminalB.DistanceTo(baseFin);
            double asignacionCruzada =
                terminalB.DistanceTo(baseInicio) +
                terminalA.DistanceTo(baseFin);

            XYZ ganchoInicio = asignacionDirecta <= asignacionCruzada
                ? terminalA
                : terminalB;
            XYZ ganchoFin = asignacionDirecta <= asignacionCruzada
                ? terminalB
                : terminalA;

            return PuntoGanchoDentro(
                       perfil,
                       baseInicio,
                       ganchoInicio) &&
                   PuntoGanchoDentro(
                       perfil,
                       baseFin,
                       ganchoFin);
        }
        catch
        {
            return false;
        }
    }

    private List<XYZ> ObtenerTerminalesCadena(
        IList<Curve> curvas)
    {
        List<XYZ> puntos = new List<XYZ>();
        List<int> grados = new List<int>();
        double tolerancia = Math.Max(
            TolGeometria * 10.0,
            ConvertirCm(0.05));

        if (curvas == null)
            return puntos;

        foreach (Curve curva in curvas)
        {
            if (curva == null || !curva.IsBound)
                continue;

            RegistrarExtremoCadena(
                curva.GetEndPoint(0),
                puntos,
                grados,
                tolerancia);
            RegistrarExtremoCadena(
                curva.GetEndPoint(1),
                puntos,
                grados,
                tolerancia);
        }

        List<XYZ> terminales = new List<XYZ>();

        for (int i = 0; i < puntos.Count; i++)
        {
            if (grados[i] == 1)
                terminales.Add(puntos[i]);
        }

        if (terminales.Count <= 2)
            return terminales;

        // Una cadena abierta correcta tiene dos terminales. Si Revit devuelve
        // segmentos auxiliares, conservar el par más separado.
        double mayor = double.MinValue;
        XYZ mejorA = null;
        XYZ mejorB = null;

        for (int i = 0; i < terminales.Count; i++)
        {
            for (int j = i + 1; j < terminales.Count; j++)
            {
                double distancia = terminales[i].DistanceTo(terminales[j]);

                if (distancia > mayor)
                {
                    mayor = distancia;
                    mejorA = terminales[i];
                    mejorB = terminales[j];
                }
            }
        }

        return mejorA == null
            ? new List<XYZ>()
            : new List<XYZ> { mejorA, mejorB };
    }

    private void RegistrarExtremoCadena(
        XYZ punto,
        List<XYZ> puntos,
        List<int> grados,
        double tolerancia)
    {
        if (punto == null)
            return;

        for (int i = 0; i < puntos.Count; i++)
        {
            if (puntos[i].DistanceTo(punto) <= tolerancia)
            {
                grados[i]++;
                return;
            }
        }

        puntos.Add(punto);
        grados.Add(1);
    }

    private bool PuntoGanchoDentro(
        PerfilEstriboPreparado perfil,
        XYZ baseGancho,
        XYZ extremoGancho)
    {
        if (perfil == null || perfil.Datos == null ||
            baseGancho == null || extremoGancho == null)
        {
            return false;
        }

        PuntoLocal baseLocal = MundoALocal2D(
            perfil.Datos,
            baseGancho);
        PuntoLocal extremoLocal = MundoALocal2D(
            perfil.Datos,
            extremoGancho);

        double tolerancia = ConvertirCm(0.35);
        bool extremoDentro =
            PuntoDentroPoligono(
                extremoLocal,
                perfil.PoligonoOriginal) ||
            DistanciaPuntoAlContorno(
                extremoLocal,
                perfil.PoligonoOriginal) <= tolerancia;

        if (!extremoDentro)
            return false;

        // La parte útil del gancho debe internarse en el núcleo. No se evalúa
        // toda la curva del doblado porque el radio de doblado puede sobresalir
        // mínimamente del polígono de ejes aun cuando la patilla sea interior.
        double[] factores = new double[] { 0.35, 0.60, 0.85 };

        foreach (double factor in factores)
        {
            PuntoLocal muestra = new PuntoLocal(
                baseLocal.X +
                    (extremoLocal.X - baseLocal.X) * factor,
                baseLocal.Y +
                    (extremoLocal.Y - baseLocal.Y) * factor);

            if (!PuntoDentroPoligono(
                    muestra,
                    perfil.PoligonoOriginal) &&
                DistanciaPuntoAlContorno(
                    muestra,
                    perfil.PoligonoOriginal) > tolerancia)
            {
                return false;
            }
        }

        return true;
    }

    private PuntoLocal MundoALocal2D(
        DatosColumna datos,
        XYZ punto)
    {
        XYZ vector = punto.Subtract(datos.Origen);

        return new PuntoLocal(
            vector.DotProduct(datos.EjeX),
            vector.DotProduct(datos.EjeY));
    }

    private double DistanciaPuntoAlContorno(
        PuntoLocal punto,
        List<PuntoLocal> poligono)
    {
        if (punto == null || poligono == null ||
            poligono.Count < 2)
        {
            return double.MaxValue;
        }

        double menor = double.MaxValue;

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoLocal a = poligono[i];
            PuntoLocal b = poligono[(i + 1) % poligono.Count];
            menor = Math.Min(
                menor,
                DistanciaPuntoSegmento(punto, a, b));
        }

        return menor;
    }

    private Rebar CrearRebarShapeDrivenSeguro(
        Document doc,
        RebarStyle estilo,
        RebarBarType tipo,
        Element host,
        XYZ normal,
        IList<Curve> curvas,
        RebarHookType ganchoInicial,
        RebarHookType ganchoFinal,
        RebarTerminationOrientation orientacionInicio,
        RebarTerminationOrientation orientacionFin,
        bool exigirGanchos,
        System.Action<Rebar> configurarDespuesCrear,
        string descripcion,
        System.Func<Rebar, bool> validarAdicional = null,
        bool exigirMetradoNativoMYG = false)
    {
        if (doc == null || tipo == null || host == null ||
            normal == null || normal.GetLength() <= Tol ||
            curvas == null || curvas.Count == 0)
        {
            return null;
        }

        // Para CROQUIS, priorizar una RebarShape NUEVA. Una forma antigua
        // puede dibujar A/B/C/D correctamente pero devolver 0 mm y 0 cm3.
        // El segundo intento usa una forma existente, sólo si pasa la QA.
        // Primero probar la equivalencia a Croquis nativo de Revit
        // (buscar forma existente y crearla si es posible): true / true.
        // Después, los dos caminos explícitos. Cada intento es reversible.
        bool[] crearNuevaForma = exigirMetradoNativoMYG
            ? new bool[] { true, true, false }
            : new bool[] { false, true };

        for (int intentoFormaMYG = 0;
             intentoFormaMYG < crearNuevaForma.Length;
             intentoFormaMYG++)
        {
            bool crearNueva = crearNuevaForma[intentoFormaMYG];
            bool usarExistente = exigirMetradoNativoMYG &&
                intentoFormaMYG == 0 ? true : !crearNueva;
            using (SubTransaction subTransaccion =
                new SubTransaction(doc))
            {
                subTransaccion.Start();

                try
                {
                    Rebar rebar;

                    using (BarTerminationsData terminaciones =
                        new BarTerminationsData(doc))
                    {
                        if (ganchoInicial != null)
                        {
                            terminaciones.HookTypeIdAtStart =
                                ganchoInicial.Id;
                            terminaciones.TerminationOrientationAtStart =
                                orientacionInicio;
                        }

                        if (ganchoFinal != null)
                        {
                            terminaciones.HookTypeIdAtEnd =
                                ganchoFinal.Id;
                            terminaciones.TerminationOrientationAtEnd =
                                orientacionFin;
                        }

                        rebar = Rebar.CreateFromCurves(
                            doc,
                            estilo,
                            tipo,
                            host,
                            normal.Normalize(),
                            curvas,
                            terminaciones,
                            usarExistente,
                            crearNueva);
                    }

                    if (rebar == null)
                    {
                        subTransaccion.RollBack();
                        continue;
                    }

                    if (exigirMetradoNativoMYG)
                        doc.Regenerate();

                    if (exigirGanchos && !RebarContieneGanchos(rebar))
                    {
                        ultimoErrorCreacion =
                            descripcion +
                            " - Revit creó la forma pero descartó sus terminaciones.";
                        subTransaccion.RollBack();
                        continue;
                    }

                    if (validarAdicional != null &&
                        !validarAdicional(rebar))
                    {
                        ultimoErrorCreacion =
                            descripcion +
                            " - Revit orientó uno o ambos ganchos hacia afuera; " +
                            "la creación fue cancelada.";
                        subTransaccion.RollBack();
                        continue;
                    }

                    if (configurarDespuesCrear != null)
                        configurarDespuesCrear(rebar);

                    // La validación debe ejecutarse DESPUÉS de definir el
                    // espaciamiento y número real del Rebar Set.
                    if (exigirMetradoNativoMYG)
                    {
                        string diagnosticoMetradoMYG;
                        if (!ValidarMetradoCroquisRevitMYG(
                            doc, rebar, out diagnosticoMetradoMYG))
                        {
                            ultimoErrorCreacion = descripcion +
                                " - METRADO INVÁLIDO: " +
                                diagnosticoMetradoMYG;
                            // Si no tiene longitud válida no se deja en el
                            // modelo como supuesto conjunto satisfactorio.
                            subTransaccion.RollBack();
                            continue;
                        }
                    }

                    subTransaccion.Commit();
                    ultimoErrorCreacion = "";
                    return rebar;
                }
                catch (Exception ex)
                {
                    ultimoErrorCreacion =
                        descripcion + " - " +
                        ex.GetType().Name + ": " + ex.Message;

                    try
                    {
                        if (subTransaccion.GetStatus() ==
                            TransactionStatus.Started)
                        {
                            subTransaccion.RollBack();
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        if (string.IsNullOrWhiteSpace(ultimoErrorCreacion))
        {
            ultimoErrorCreacion =
                descripcion +
                " - Revit no encontró ni pudo crear una RebarShape compatible.";
        }

        return null;
    }

    // =============================================================
    // QA DE METRADOS NATIVOS: CROQUIS CON 135° (REVIT 2027)
    // =============================================================
    // No escribe en parámetros nativos de solo lectura ni sustituye peso
    // por un valor estimado que descoordine tablas y planos.
    // Se verifica longitud de UNA barra, longitud TOTAL y volumen del SET.
    private bool ValidarMetradoCroquisRevitMYG(
        Document doc, Rebar rebar, out string diagnostico)
    {
        diagnostico = "";
        if (doc == null || rebar == null || !rebar.IsValidObject)
        {
            diagnostico = "El Rebar no existe o no es válido.";
            return false;
        }

        try
        {
            doc.Regenerate();
            // Obliga a actualizar los parámetros calculados del elemento
            // antes de consultar sus métricas para una planificación.
            try { rebar.EvaluateAllParameterValues(); }
            catch { /* Compatibilidad entre instalaciones y formas */ }
            doc.Regenerate();

            double lBarra = ObtenerParametroLongitud(
                rebar, BuiltInParameter.REBAR_ELEM_LENGTH);
            double lTotal = ObtenerParametroLongitud(
                rebar, BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH);
            double lGeometria = ObtenerLongitudCentroRebarMYG(rebar);
            double volumen = 0.0;
            try { volumen = rebar.Volume; }
            catch { }

            // En Revit 2027: masa total = longitud total * masa por longitud.
            Parameter masaNativa =
                rebar.LookupParameter("Masa de refuerzo") ??
                rebar.LookupParameter("Reinforcement Mass");
            bool tieneMasaNativa = masaNativa != null &&
                masaNativa.StorageType == StorageType.Double;
            double masaCalculada = tieneMasaNativa
                ? masaNativa.AsDouble() : 0.0;

            diagnostico =
                "Longitud barra=" + FormatearMilimetros(lBarra) +
                ", longitud total=" + FormatearMilimetros(lTotal) +
                ", geometría=" + FormatearMilimetros(lGeometria) +
                ", volumen(ft³)=" + volumen.ToString(
                    "0.######", CultureInfo.InvariantCulture) + ".";

            // La geometría sola no basta: el problema mostrado por el usuario
            // es precisamente un sólido visible con parámetros de metrado 0.
            if (lGeometria <= TolGeometria)
            {
                diagnostico += " Revit no devuelve el eje del estribo.";
                return false;
            }
            if (lBarra <= TolGeometria ||
                lTotal <= TolGeometria || volumen <= 1e-12)
            {
                diagnostico +=
                    " La forma se dibuja, pero Revit no calcula su " +
                    "longitud/volumen de planificación. " +
                    "Revisar fórmula de la familia RebarShape.";
                return false;
            }
            if (lTotal + ConvertirCm(0.1) < lBarra)
            {
                diagnostico += " Longitud total inferior a una barra.";
                return false;
            }
            if (tieneMasaNativa && masaCalculada <= 1e-12)
            {
                diagnostico +=
                    " La masa de refuerzo sigue en 0. Revisar en el tipo " +
                    "de barra la masa por unidad de longitud (Revit 2027).";
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            diagnostico = "No se pudieron evaluar los parámetros: " +
                ex.Message;
            return false;
        }
    }

    private double ObtenerLongitudCentroRebarMYG(Rebar rebar)
    {
        if (rebar == null) return 0.0;
        try
        {
            IList<Curve> curvas = rebar.GetCenterlineCurves(
                false, false, false,
                MultiplanarOption.IncludeOnlyPlanarCurves, 0);
            if (curvas == null) return 0.0;
            return curvas.Where(x => x != null).Sum(x => x.Length);
        }
        catch { return 0.0; }
    }

    private bool EsVigaEstructuralParaNodo(Element elemento)
    {
        FamilyInstance viga = elemento as FamilyInstance;

        if (viga == null || viga.Category == null)
            return false;

        if (viga.Category.Id.Value !=
            (long)BuiltInCategory.OST_StructuralFraming)
        {
            return false;
        }

        // Structural Framing también contiene arriostres. Solo se aceptan
        // elementos clasificados realmente como viga.
        return viga.StructuralType == StructuralType.Beam;
    }

    private bool EsSueloParaNodo(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        if (elemento.Category.Id.Value !=
            (long)BuiltInCategory.OST_Floors)
        {
            return false;
        }

        // Se acepta cualquier elemento real de la categoría Suelos. La detección
        // geométrica posterior decide si toca la columna; así también funcionan
        // suelos que por error de modelado no tengan activada la opción estructural.
        return elemento is Floor;
    }

    private List<Element> ObtenerElementosPotencialesNodo(
        Document doc,
        AceroColumnaConfiguracion configuracion)
    {
        List<Element> resultado = new List<Element>();

        if (doc == null || configuracion == null ||
            !configuracion.UsarDistribucionNodoEntrepiso)
        {
            return resultado;
        }

        if (configuracion.DetectarNodosPorVigas)
        {
            resultado.AddRange(
                new FilteredElementCollector(doc)
                    .OfCategory(BuiltInCategory.OST_StructuralFraming)
                    .WhereElementIsNotElementType()
                    .ToElements()
                    .Where(x => EsVigaEstructuralParaNodo(x)));
        }

        if (configuracion.DetectarNodosPorLosas)
        {
            resultado.AddRange(
                new FilteredElementCollector(doc)
                    .OfCategory(BuiltInCategory.OST_Floors)
                    .WhereElementIsNotElementType()
                    .ToElements()
                    .Where(x => EsSueloParaNodo(x)));
        }

        return resultado
            .Where(x => x != null)
            .GroupBy(x => x.Id.Value)
            .Select(x => x.First())
            .ToList();
    }

    private List<ZonaEstribos> ObtenerZonasEstribosNodoEntrepiso(
        Document doc,
        FamilyInstance columna,
        DatosColumna datos,
        double retiroVertical,
        AceroColumnaConfiguracion configuracion,
        List<Element> elementosPotencialesNodo,
        AceroColumnaEstribo2D definicion)
    {
        List<ZonaEstribos> resultado = new List<ZonaEstribos>();
        double inicioTotal = datos.ZInferior + retiroVertical;
        double finTotal = datos.ZSuperior - retiroVertical;
        if (finTotal <= inicioTotal + Tol)
            return resultado;

        int tipoEntrepiso = configuracion.TipoDistribucionEstribosEntrepiso;
        double[] separacionesEntrepisoCm =
            configuracion.SeparacionesDistribucionEstribosEntrepisoCm;
        int[] cantidadesEntrepiso =
            configuracion.CantidadesDistribucionEstribosEntrepiso;

        if (definicion != null &&
            definicion.UsarDistribucionEntrepisoPersonalizada)
        {
            tipoEntrepiso = System.Math.Max(1, System.Math.Min(4,
                definicion.TipoDistribucionEntrepiso));
            separacionesEntrepisoCm = definicion.SeparacionesEntrepisoCm;
            cantidadesEntrepiso = definicion.CantidadesEntrepiso;
        }

        List<IntervaloVerticalNodo> nodos = DetectarIntervalosNodo(
            doc,
            columna,
            datos,
            inicioTotal,
            finTotal,
            configuracion,
            elementosPotencialesNodo);

        // Separación geométrica solicitada respecto de cada CARA DEL NODO:
        //
        //   ENTREPISO  ---> termina 5 cm ANTES de la cara del nodo.
        //   NODO       ---> empieza 5 cm HACIA ADENTRO desde la cara del nodo.
        //
        // Lo mismo se aplica en la cara superior del nodo:
        //
        //   NODO       ---> termina 5 cm antes de salir del nodo.
        //   ENTREPISO  ---> empieza 5 cm DESPUÉS de la cara del nodo.
        //
        // Por tanto, alrededor de cada cara física queda una franja de transición
        // de 5 cm hacia cada lado. La detección del nodo sigue usando la geometría
        // real de viga/losa; solo se modifican los límites de distribución.
        double retiroCaraNodo = UnitUtils.ConvertToInternalUnits(
            5.0,
            UnitTypeId.Centimeters);

        double cursor = inicioTotal;
        int indiceEntrepiso = 1;

        foreach (IntervaloVerticalNodo nodo in nodos)
        {
            if (nodo == null)
                continue;

            // -----------------------------
            // ENTREPISO INFERIOR
            // -----------------------------
            // Último estribo del entrepiso: 5 cm antes de la cara inferior
            // del nodo.
            double finEntrepiso =
                System.Math.Min(
                    finTotal,
                    nodo.Inicio - retiroCaraNodo);

            if (finEntrepiso > cursor + Tol)
            {
                resultado.AddRange(
                    ConstruirZonasDistribucionEstribosEnRango(
                        cursor,
                        finEntrepiso,
                        tipoEntrepiso,
                        ConvertirSeparacionesPerfil(
                            separacionesEntrepisoCm),
                        cantidadesEntrepiso,
                        "ENTREPISO-" + indiceEntrepiso));

                indiceEntrepiso++;
            }

            // -----------------------------
            // DISTRIBUCIÓN DENTRO DEL NODO
            // -----------------------------
            // Primer estribo del nodo: 5 cm hacia adentro desde su cara inferior.
            // Último estribo del nodo: 5 cm hacia adentro desde su cara superior.
            double inicioNodo =
                System.Math.Max(
                    inicioTotal,
                    nodo.Inicio + retiroCaraNodo);

            double finNodo =
                System.Math.Min(
                    finTotal,
                    nodo.Fin - retiroCaraNodo);

            // Solo se crea distribución de nodo cuando queda un rango físico
            // válido después de descontar los 5 cm de ambas caras.
            if (finNodo >= inicioNodo - Tol)
            {
                resultado.AddRange(
                    ConstruirZonasDistribucionEstribosEnRango(
                        inicioNodo,
                        finNodo,
                        configuracion.TipoDistribucionEstribosNodo,
                        ConvertirSeparacionesPerfil(
                            configuracion.SeparacionesDistribucionEstribosNodoCm),
                        configuracion.CantidadesDistribucionEstribosNodo,
                        nodo.Nombre));
            }

            // -----------------------------
            // SIGUIENTE ENTREPISO
            // -----------------------------
            // Comienza 5 cm después de la cara superior del nodo.
            cursor =
                System.Math.Max(
                    cursor,
                    nodo.Fin + retiroCaraNodo);
        }

        if (finTotal > cursor + Tol)
        {
            resultado.AddRange(ConstruirZonasDistribucionEstribosEnRango(
                cursor,
                finTotal,
                tipoEntrepiso,
                ConvertirSeparacionesPerfil(
                    separacionesEntrepisoCm),
                cantidadesEntrepiso,
                "ENTREPISO-" + indiceEntrepiso));
        }

        return resultado
            .Where(x => x != null && x.Fin >= x.Inicio - Tol)
            .OrderBy(x => x.Inicio)
            .ThenBy(x => x.Fin)
            .ToList();
    }

    private double[] ConvertirSeparacionesPerfil(double[] separacionesCm)
    {
        double[] resultado = new double[4];
        for (int i = 0; i < 4; i++)
        {
            double cm = separacionesCm != null && i < separacionesCm.Length
                ? separacionesCm[i]
                : 20.0;
            resultado[i] = ConvertirCm(System.Math.Max(0.1, cm));
        }
        return resultado;
    }

    private PuntoLocal PuntoMundialALocalNodo(
        DatosColumna datos,
        XYZ punto)
    {
        XYZ vector = punto.Subtract(datos.Origen);

        return new PuntoLocal(
            vector.DotProduct(datos.EjeX),
            vector.DotProduct(datos.EjeY));
    }

    private double OrientacionNodo2D(
        PuntoLocal a,
        PuntoLocal b,
        PuntoLocal c)
    {
        return (b.X - a.X) * (c.Y - a.Y) -
               (b.Y - a.Y) * (c.X - a.X);
    }

    private bool SegmentosNodoIntersectan2D(
        PuntoLocal a,
        PuntoLocal b,
        PuntoLocal c,
        PuntoLocal d,
        double tolerancia)
    {
        double o1 = OrientacionNodo2D(a, b, c);
        double o2 = OrientacionNodo2D(a, b, d);
        double o3 = OrientacionNodo2D(c, d, a);
        double o4 = OrientacionNodo2D(c, d, b);
        double eps = System.Math.Max(TolGeometria, tolerancia * 0.01);

        if (((o1 > eps && o2 < -eps) || (o1 < -eps && o2 > eps)) &&
            ((o3 > eps && o4 < -eps) || (o3 < -eps && o4 > eps)))
        {
            return true;
        }

        return DistanciaPuntoSegmento(a, c, d) <= tolerancia ||
               DistanciaPuntoSegmento(b, c, d) <= tolerancia ||
               DistanciaPuntoSegmento(c, a, b) <= tolerancia ||
               DistanciaPuntoSegmento(d, a, b) <= tolerancia;
    }

    private List<Solid> ObtenerSolidosElementoNodo(Element elemento)
    {
        List<Solid> resultado = new List<Solid>();
        if (elemento == null)
            return resultado;

        try
        {
            Options opciones = new Options
            {
                ComputeReferences = false,
                IncludeNonVisibleObjects = true,
                DetailLevel = ViewDetailLevel.Fine
            };

            GeometryElement geometria = elemento.get_Geometry(opciones);
            if (geometria != null)
                resultado.AddRange(ObtenerSolidos(geometria));
        }
        catch
        {
        }

        return resultado
            .Where(x => x != null && x.Volume > Tol && x.Faces.Size > 0)
            .ToList();
    }

    private bool TryObtenerRangoVerticalElementoNodo(
        Element elemento,
        out double zMin,
        out double zMax)
    {
        zMin = double.MaxValue;
        zMax = double.MinValue;
        bool encontrado = false;

        foreach (Solid solid in ObtenerSolidosElementoNodo(elemento))
        {
            foreach (Face face in solid.Faces)
            {
                Mesh malla = null;
                try
                {
                    malla = face.Triangulate();
                }
                catch
                {
                    malla = null;
                }

                if (malla == null)
                    continue;

                for (int i = 0; i < malla.Vertices.Count; i++)
                {
                    XYZ p = malla.Vertices[i];
                    if (p == null)
                        continue;

                    zMin = System.Math.Min(zMin, p.Z);
                    zMax = System.Math.Max(zMax, p.Z);
                    encontrado = true;
                }
            }
        }

        if (!encontrado)
        {
            BoundingBoxXYZ bb = elemento != null
                ? elemento.get_BoundingBox(null)
                : null;

            if (bb != null)
            {
                zMin = bb.Min.Z;
                zMax = bb.Max.Z;
                encontrado = true;
            }
        }

        return encontrado && zMax > zMin + Tol;
    }

    private bool CajasNodoSeAcercanEnPlanta(
        Element elemento,
        DatosColumna datos,
        double tolerancia)
    {
        BoundingBoxXYZ bb = elemento != null
            ? elemento.get_BoundingBox(null)
            : null;
        List<List<PuntoLocal>> regiones = ObtenerContornosValidos(datos);

        if (bb == null || regiones.Count == 0)
            return true;

        double minX = double.MaxValue;
        double minY = double.MaxValue;
        double maxX = double.MinValue;
        double maxY = double.MinValue;

        foreach (List<PuntoLocal> region in regiones)
        {
            foreach (PuntoLocal p in region)
            {
                XYZ q = LocalAMundial(datos, p, 0.0);
                minX = System.Math.Min(minX, q.X);
                minY = System.Math.Min(minY, q.Y);
                maxX = System.Math.Max(maxX, q.X);
                maxY = System.Math.Max(maxY, q.Y);
            }
        }

        return bb.Max.X >= minX - tolerancia &&
               bb.Min.X <= maxX + tolerancia &&
               bb.Max.Y >= minY - tolerancia &&
               bb.Min.Y <= maxY + tolerancia;
    }

    private bool PuntoCercaDeSeccionNodo(
        PuntoLocal punto,
        List<List<PuntoLocal>> regiones,
        double tolerancia)
    {
        foreach (List<PuntoLocal> region in regiones)
        {
            if (region == null || region.Count < 3)
                continue;

            if (PuntoDentroPoligono(punto, region))
                return true;

            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal a = region[i];
                PuntoLocal b = region[(i + 1) % region.Count];
                if (DistanciaPuntoSegmento(punto, a, b) <= tolerancia)
                    return true;
            }
        }

        return false;
    }

    private bool SegmentoCercaDeSeccionNodo(
        PuntoLocal a,
        PuntoLocal b,
        List<List<PuntoLocal>> regiones,
        double tolerancia)
    {
        if (PuntoCercaDeSeccionNodo(a, regiones, tolerancia) ||
            PuntoCercaDeSeccionNodo(b, regiones, tolerancia))
        {
            return true;
        }

        foreach (List<PuntoLocal> region in regiones)
        {
            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal c = region[i];
                PuntoLocal d = region[(i + 1) % region.Count];
                if (SegmentosNodoIntersectan2D(
                    a,
                    b,
                    c,
                    d,
                    tolerancia))
                {
                    return true;
                }
            }
        }

        return false;
    }

    private Solid CrearPrismaRegionNodo(
        DatosColumna datos,
        List<PuntoLocal> region,
        double zInferior,
        double zSuperior)
    {
        if (datos == null || region == null || region.Count < 3 ||
            zSuperior <= zInferior + Tol)
        {
            return null;
        }

        try
        {
            List<Curve> curvas = new List<Curve>();
            for (int i = 0; i < region.Count; i++)
            {
                XYZ a = LocalAMundial(datos, region[i], zInferior);
                XYZ b = LocalAMundial(
                    datos,
                    region[(i + 1) % region.Count],
                    zInferior);

                if (a.DistanceTo(b) <= TolGeometria)
                    return null;

                curvas.Add(Line.CreateBound(a, b));
            }

            CurveLoop loop = CurveLoop.Create(curvas);
            return GeometryCreationUtilities.CreateExtrusionGeometry(
                new List<CurveLoop> { loop },
                XYZ.BasisZ,
                zSuperior - zInferior);
        }
        catch
        {
            return null;
        }
    }

    private bool SolidoIntersectaSeccionColumnaNodo(
        Solid solid,
        DatosColumna datos,
        double toleranciaVertical)
    {
        if (solid == null || datos == null)
            return false;

        double z0 = datos.ZInferior - toleranciaVertical;
        double z1 = datos.ZSuperior + toleranciaVertical;

        foreach (List<PuntoLocal> region in ObtenerContornosValidos(datos))
        {
            Solid prisma = CrearPrismaRegionNodo(datos, region, z0, z1);
            if (prisma == null)
                continue;

            try
            {
                Solid interseccion = BooleanOperationsUtils.ExecuteBooleanOperation(
                    solid,
                    prisma,
                    BooleanOperationsType.Intersect);

                if (interseccion != null && interseccion.Volume > 1e-10)
                    return true;
            }
            catch
            {
            }
        }

        return false;
    }

    private bool CaraHorizontalContieneMuestraColumnaNodo(
        Solid solid,
        DatosColumna datos,
        double tolerancia)
    {
        List<List<PuntoLocal>> regiones = ObtenerContornosValidos(datos);
        if (solid == null || regiones.Count == 0)
            return false;

        List<PuntoLocal> muestras = new List<PuntoLocal>();
        foreach (List<PuntoLocal> region in regiones)
        {
            PuntoLocal centro = CentroidePoligono(region);
            if (centro != null)
                muestras.Add(centro);

            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal a = region[i];
                PuntoLocal b = region[(i + 1) % region.Count];
                muestras.Add(a.Copiar());
                muestras.Add(new PuntoLocal(
                    (a.X + b.X) * 0.5,
                    (a.Y + b.Y) * 0.5));
            }
        }

        foreach (Face face in solid.Faces)
        {
            PlanarFace plana = face as PlanarFace;
            if (plana == null)
                continue;

            XYZ normal = plana.FaceNormal;
            if (normal == null || System.Math.Abs(normal.Z) < 0.90)
                continue;

            foreach (PuntoLocal muestra in muestras)
            {
                XYZ punto = LocalAMundial(datos, muestra, plana.Origin.Z);
                IntersectionResult proyeccion = null;
                try
                {
                    proyeccion = plana.Project(punto);
                }
                catch
                {
                    proyeccion = null;
                }

                if (proyeccion == null || proyeccion.XYZPoint == null)
                    continue;

                XYZ p = proyeccion.XYZPoint;
                double distanciaPlanta = System.Math.Sqrt(
                    (p.X - punto.X) * (p.X - punto.X) +
                    (p.Y - punto.Y) * (p.Y - punto.Y));

                if (distanciaPlanta > tolerancia + TolGeometria)
                    continue;

                bool dentro = false;
                try
                {
                    dentro = plana.IsInside(proyeccion.UVPoint);
                }
                catch
                {
                    dentro = false;
                }

                if (dentro)
                    return true;
            }
        }

        return false;
    }

    private bool ElementoTocaSeccionColumnaNodo(
        Element elemento,
        DatosColumna datos,
        double tolerancia)
    {
        if (elemento == null || datos == null)
            return false;

        if (!CajasNodoSeAcercanEnPlanta(elemento, datos, tolerancia))
            return false;

        double zMin;
        double zMax;
        if (!TryObtenerRangoVerticalElementoNodo(
            elemento,
            out zMin,
            out zMax))
        {
            return false;
        }

        if (zMax < datos.ZInferior - tolerancia ||
            zMin > datos.ZSuperior + tolerancia)
        {
            return false;
        }

        List<Solid> solidos = ObtenerSolidosElementoNodo(elemento);
        foreach (Solid solid in solidos)
        {
            if (SolidoIntersectaSeccionColumnaNodo(
                solid,
                datos,
                tolerancia))
            {
                return true;
            }
        }

        foreach (Solid solid in solidos)
        {
            if (CaraHorizontalContieneMuestraColumnaNodo(
                solid,
                datos,
                tolerancia))
            {
                return true;
            }
        }

        List<List<PuntoLocal>> regiones = ObtenerContornosValidos(datos);
        foreach (Solid solid in solidos)
        {
            foreach (Edge edge in solid.Edges)
            {
                IList<XYZ> puntos = null;
                try
                {
                    puntos = edge.Tessellate();
                }
                catch
                {
                    puntos = null;
                }

                if (puntos == null || puntos.Count < 2)
                    continue;

                for (int i = 0; i + 1 < puntos.Count; i++)
                {
                    PuntoLocal a = PuntoMundialALocalNodo(datos, puntos[i]);
                    PuntoLocal b = PuntoMundialALocalNodo(datos, puntos[i + 1]);

                    if (SegmentoCercaDeSeccionNodo(
                        a,
                        b,
                        regiones,
                        tolerancia))
                    {
                        return true;
                    }
                }
            }
        }

        // Respaldo geométrico para familias de viga cuya geometría sólida no
        // pueda leerse: se prueba su eje, siempre con la misma tolerancia de 1 cm.
        LocationCurve ubicacion = elemento.Location as LocationCurve;
        Curve curva = ubicacion != null ? ubicacion.Curve : null;
        if (curva != null)
        {
            IList<XYZ> puntos = null;
            try
            {
                puntos = curva.Tessellate();
            }
            catch
            {
                puntos = null;
            }

            if (puntos != null)
            {
                for (int i = 0; i + 1 < puntos.Count; i++)
                {
                    PuntoLocal a = PuntoMundialALocalNodo(datos, puntos[i]);
                    PuntoLocal b = PuntoMundialALocalNodo(datos, puntos[i + 1]);
                    if (SegmentoCercaDeSeccionNodo(
                        a,
                        b,
                        regiones,
                        tolerancia))
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private bool IntervalosNodoSolapan(
        IntervaloVerticalNodo a,
        IntervaloVerticalNodo b,
        double tolerancia)
    {
        if (a == null || b == null)
            return false;

        return a.Inicio <= b.Fin + tolerancia &&
               b.Inicio <= a.Fin + tolerancia;
    }

    private List<IntervaloVerticalNodo> DetectarIntervalosElementosNodo(
        IEnumerable<Element> elementos,
        FamilyInstance columna,
        DatosColumna datos,
        double inicioTotal,
        double finTotal,
        double extensionInferior,
        double extensionSuperior,
        double toleranciaContacto,
        string prefijo)
    {
        List<IntervaloVerticalNodo> resultado =
            new List<IntervaloVerticalNodo>();

        if (elementos == null)
            return resultado;

        foreach (Element elemento in elementos)
        {
            if (elemento == null ||
                (columna != null && elemento.Id == columna.Id))
            {
                continue;
            }

            double zMin;
            double zMax;
            if (!TryObtenerRangoVerticalElementoNodo(
                elemento,
                out zMin,
                out zMax))
            {
                continue;
            }

            if (zMax < datos.ZInferior - toleranciaContacto ||
                zMin > datos.ZSuperior + toleranciaContacto)
            {
                continue;
            }

            if (!ElementoTocaSeccionColumnaNodo(
                elemento,
                datos,
                toleranciaContacto))
            {
                continue;
            }

            double inicio = System.Math.Max(
                inicioTotal,
                zMin - extensionInferior);
            double fin = System.Math.Min(
                finTotal,
                zMax + extensionSuperior);

            if (fin <= inicio + Tol)
                continue;

            resultado.Add(new IntervaloVerticalNodo
            {
                Inicio = inicio,
                Fin = fin,
                Nombre = prefijo + elemento.Id.Value
            });
        }

        return resultado;
    }

    private List<IntervaloVerticalNodo> DetectarIntervalosNodo(
        Document doc,
        FamilyInstance columna,
        DatosColumna datos,
        double inicioTotal,
        double finTotal,
        AceroColumnaConfiguracion configuracion,
        List<Element> candidatos)
    {
        List<IntervaloVerticalNodo> seleccionados =
            new List<IntervaloVerticalNodo>();

        double extensionInferior = ConvertirCm(
            System.Math.Max(0.0, configuracion.ExtensionNodoInferiorCm));
        double extensionSuperior = ConvertirCm(
            System.Math.Max(0.0, configuracion.ExtensionNodoSuperiorCm));

        // Tolerancia fija solicitada para errores pequeños de modelado: una viga
        // o un suelo puede quedar separado hasta 1 cm y aun así se reconoce como
        // conectado a la columna.
        double toleranciaContacto = ConvertirCm(1.0);

        List<Element> lista = candidatos ?? new List<Element>();

        // PRIORIDAD 1: VIGAS. Se toma la altura real de su geometría sólida.
        List<IntervaloVerticalNodo> intervalosViga =
            configuracion.DetectarNodosPorVigas
                ? DetectarIntervalosElementosNodo(
                    lista.Where(x => EsVigaEstructuralParaNodo(x)),
                    columna,
                    datos,
                    inicioTotal,
                    finTotal,
                    extensionInferior,
                    extensionSuperior,
                    toleranciaContacto,
                    "NODO-VIGA-ID")
                : new List<IntervaloVerticalNodo>();

        intervalosViga = FusionarIntervalosNodo(
            intervalosViga,
            inicioTotal,
            finTotal);
        seleccionados.AddRange(intervalosViga);

        // PRIORIDAD 2: SUELOS. Solo se incorporan en encuentros verticales donde
        // no exista ya una viga detectada. De este modo una losa no agranda ni
        // desplaza un nodo cuya altura ya quedó definida por una viga real.
        List<IntervaloVerticalNodo> intervalosSuelo =
            configuracion.DetectarNodosPorLosas
                ? DetectarIntervalosElementosNodo(
                    lista.Where(x => EsSueloParaNodo(x)),
                    columna,
                    datos,
                    inicioTotal,
                    finTotal,
                    extensionInferior,
                    extensionSuperior,
                    toleranciaContacto,
                    "NODO-SUELO-ID")
                : new List<IntervaloVerticalNodo>();

        intervalosSuelo = FusionarIntervalosNodo(
            intervalosSuelo,
            inicioTotal,
            finTotal);

        foreach (IntervaloVerticalNodo suelo in intervalosSuelo)
        {
            bool yaCubiertoPorViga = intervalosViga.Any(viga =>
                IntervalosNodoSolapan(
                    viga,
                    suelo,
                    toleranciaContacto));

            if (!yaCubiertoPorViga)
                seleccionados.Add(suelo);
        }

        // No se crean nodos por niveles. Si en una elevación no se detecta
        // una viga ni un suelo en contacto con la columna, todo ese rango se
        // conserva como ENTREPISO. Esto evita nodos artificiales generados
        // únicamente por la elevación de un Level de Revit.

        return FusionarIntervalosNodo(
            seleccionados,
            inicioTotal,
            finTotal);
    }

    private List<IntervaloVerticalNodo> FusionarIntervalosNodo(
        List<IntervaloVerticalNodo> intervalos,
        double minimo,
        double maximo)
    {
        List<IntervaloVerticalNodo> ordenados = (intervalos ??
            new List<IntervaloVerticalNodo>())
            .Where(x => x != null && x.Fin > x.Inicio + Tol)
            .OrderBy(x => x.Inicio)
            .ThenBy(x => x.Fin)
            .ToList();
        List<IntervaloVerticalNodo> resultado =
            new List<IntervaloVerticalNodo>();
        double toleranciaUnion = ConvertirCm(1.0);

        foreach (IntervaloVerticalNodo actual in ordenados)
        {
            actual.Inicio = System.Math.Max(minimo, actual.Inicio);
            actual.Fin = System.Math.Min(maximo, actual.Fin);
            if (actual.Fin <= actual.Inicio + Tol)
                continue;

            if (resultado.Count == 0 ||
                actual.Inicio > resultado[resultado.Count - 1].Fin + toleranciaUnion)
            {
                resultado.Add(new IntervaloVerticalNodo
                {
                    Inicio = actual.Inicio,
                    Fin = actual.Fin,
                    Nombre = actual.Nombre
                });
            }
            else
            {
                IntervaloVerticalNodo ultimo = resultado[resultado.Count - 1];
                ultimo.Fin = System.Math.Max(ultimo.Fin, actual.Fin);
                if (!ultimo.Nombre.Contains(actual.Nombre))
                    ultimo.Nombre += "+" + actual.Nombre;
            }
        }
        return resultado;
    }

    private List<ZonaEstribos> ConstruirZonasDistribucionEstribosEnRango(
        double inicioTotal,
        double finTotal,
        int tipoDistribucion,
        double[] separaciones,
        int[] cantidades,
        string prefijo)
    {
        List<ZonaEstribos> resultado = new List<ZonaEstribos>();
        if (finTotal < inicioTotal - Tol)
            return resultado;

        int n = System.Math.Max(1, System.Math.Min(4, tipoDistribucion));
        double separacionPrimera = separaciones != null && separaciones.Length > 0
            ? separaciones[0]
            : ConvertirCm(20.0);

        if (n == 1)
        {
            resultado.Add(new ZonaEstribos
            {
                Inicio = inicioTotal,
                Fin = finTotal,
                Espaciamiento = separacionPrimera,
                Cantidad = 0,
                UsarCantidadExacta = false,
                Nombre = prefijo + "-TOTAL"
            });
            return resultado;
        }

        double ultimoInferior = inicioTotal;
        double ultimoSuperior = finTotal;
        bool hayZonasExtremo = false;
        for (int zona = 0; zona < n - 1; zona++)
        {
            double separacion = separaciones != null && zona < separaciones.Length
                ? separaciones[zona]
                : ConvertirCm(10.0);
            int cantidadSolicitada = cantidades != null && zona < cantidades.Length
                ? cantidades[zona]
                : 1;
            if (separacion <= Tol || cantidadSolicitada <= 0)
                continue;

            double primeroInferior = hayZonasExtremo
                ? ultimoInferior + separacion
                : inicioTotal;
            double primeroSuperior = hayZonasExtremo
                ? ultimoSuperior - separacion
                : finTotal;
            if (primeroSuperior < primeroInferior - Tol)
                break;

            double disponible = primeroSuperior - primeroInferior;
            int cantidadMaxima = disponible <= Tol
                ? 1
                : System.Math.Max(1,
                    (int)System.Math.Floor((disponible + Tol) /
                    (2.0 * separacion)) + 1);
            int cantidadUsada = System.Math.Max(1,
                System.Math.Min(cantidadSolicitada, cantidadMaxima));
            double finInferior = primeroInferior +
                ((cantidadUsada - 1) * separacion);
            double inicioSuperior = primeroSuperior -
                ((cantidadUsada - 1) * separacion);

            resultado.Add(new ZonaEstribos
            {
                Inicio = primeroInferior,
                Fin = finInferior,
                Espaciamiento = separacion,
                Cantidad = cantidadUsada,
                UsarCantidadExacta = true,
                Nombre = prefijo + "-Z" + (zona + 1) + "-INF"
            });
            if (inicioSuperior > finInferior + Tol)
            {
                resultado.Add(new ZonaEstribos
                {
                    Inicio = inicioSuperior,
                    Fin = primeroSuperior,
                    Espaciamiento = separacion,
                    Cantidad = cantidadUsada,
                    UsarCantidadExacta = true,
                    Nombre = prefijo + "-Z" + (zona + 1) + "-SUP"
                });
            }
            ultimoInferior = finInferior;
            ultimoSuperior = inicioSuperior;
            hayZonasExtremo = true;
        }

        int indiceResto = n - 1;
        double separacionResto = separaciones != null &&
            indiceResto < separaciones.Length
            ? separaciones[indiceResto]
            : ConvertirCm(20.0);

        if (separacionResto > Tol)
        {
            double inicioRango = hayZonasExtremo
                ? ultimoInferior
                : inicioTotal;
            double finRango = hayZonasExtremo
                ? ultimoSuperior
                : finTotal;
            double longitudRango = finRango - inicioRango;

            // RESTO CENTRADO SIN BARRAS OCULTAS:
            // Las barras de las zonas extremas ya existen en inicioRango y finRango.
            // En vez de crear RESTO sobre esos mismos límites y ocultar sus extremos,
            // se calcula el espaciamiento real <= espaciamiento máximo y se desplaza
            // el rango RESTO una separación real hacia adentro por cada lado.
            //
            // De esta forma:
            //   [último extremo] -- sReal -- [1er RESTO] ... [último RESTO] -- sReal -- [primer extremo]
            //
            // No hay barras coincidentes, no se oculta ningún extremo del conjunto
            // RESTO y la distribución queda centrada entre las dos zonas vecinas.
            if (hayZonasExtremo)
            {
                int intervalosTotales = System.Math.Max(
                    1,
                    (int)System.Math.Ceiling(
                        longitudRango / separacionResto));

                // Para que exista por lo menos una barra interior deben existir
                // dos o más intervalos entre los estribos límite.
                if (intervalosTotales >= 2)
                {
                    double separacionReal =
                        longitudRango / intervalosTotales;

                    double inicioResto =
                        inicioRango + separacionReal;
                    double finResto =
                        finRango - separacionReal;

                    if (finResto >= inicioResto - Tol)
                    {
                        resultado.Add(new ZonaEstribos
                        {
                            Inicio = inicioResto,
                            Fin = finResto,
                            Espaciamiento = separacionResto,
                            Cantidad = 0,
                            UsarCantidadExacta = false,
                            OmitirPrimeraBarra = false,
                            OmitirUltimaBarra = false,
                            Nombre = prefijo + "-RESTO"
                        });
                    }
                }
            }
            else if (longitudRango > Tol)
            {
                // Si no existen zonas extremas, RESTO ocupa todo el rango y sí
                // conserva naturalmente sus extremos.
                resultado.Add(new ZonaEstribos
                {
                    Inicio = inicioRango,
                    Fin = finRango,
                    Espaciamiento = separacionResto,
                    Cantidad = 0,
                    UsarCantidadExacta = false,
                    OmitirPrimeraBarra = false,
                    OmitirUltimaBarra = false,
                    Nombre = prefijo + "-RESTO"
                });
            }
        }
        return resultado;
    }

    private List<ZonaEstribos> ObtenerZonasEstribos(
        Document doc,
        FamilyInstance columna,
        DatosColumna datos,
        double retiroVertical,
        AceroColumnaConfiguracion configuracion,
        List<Element> elementosPotencialesNodo,
        double longitudZonaConfinadaLegacy,
        double espaciamientoConfinadoLegacy,
        double espaciamientoCentralLegacy,
        AceroColumnaEstribo2D definicion)
    {
        if (datos == null)
            return new List<ZonaEstribos>();

        if (configuracion != null &&
            configuracion.UsarDistribucionNodoEntrepiso)
        {
            return ObtenerZonasEstribosNodoEntrepiso(
                doc,
                columna,
                datos,
                retiroVertical,
                configuracion,
                elementosPotencialesNodo,
                definicion);
        }

        int tipo = configuracion != null
            ? System.Math.Max(1, System.Math.Min(4,
                configuracion.TipoDistribucionEstribos))
            : 0;

        double[] separacionesCm = configuracion != null
            ? configuracion.SeparacionesDistribucionEstribosCm
            : null;
        int[] cantidades = configuracion != null
            ? configuracion.CantidadesDistribucionEstribos
            : null;

        bool distribucionNuevaValida = tipo >= 1 && tipo <= 4 &&
            separacionesCm != null && separacionesCm.Length >= tipo &&
            cantidades != null && cantidades.Length >= tipo;

        if (!distribucionNuevaValida)
        {
            return ObtenerZonasEstribosLegacy(
                datos,
                retiroVertical,
                longitudZonaConfinadaLegacy,
                espaciamientoConfinadoLegacy,
                espaciamientoCentralLegacy);
        }

        double[] separaciones = new double[4];
        for (int i = 0; i < 4; i++)
        {
            double cm = i < separacionesCm.Length
                ? separacionesCm[i]
                : 20.0;
            separaciones[i] = ConvertirCm(System.Math.Max(0.1, cm));
        }

        return ConstruirZonasDistribucionEstribos(
            datos,
            retiroVertical,
            tipo,
            separaciones,
            cantidades);
    }

    private List<ZonaEstribos> ConstruirZonasDistribucionEstribos(
        DatosColumna datos,
        double retiroVertical,
        int tipoDistribucion,
        double[] separaciones,
        int[] cantidades)
    {
        List<ZonaEstribos> resultado = new List<ZonaEstribos>();

        double inicioTotal = datos.ZInferior + retiroVertical;
        double finTotal = datos.ZSuperior - retiroVertical;

        if (finTotal < inicioTotal - Tol)
            return resultado;

        int n = System.Math.Max(1, System.Math.Min(4, tipoDistribucion));
        double separacionPrimera = separaciones != null &&
            separaciones.Length > 0
            ? separaciones[0]
            : ConvertirCm(20.0);

        if (n == 1)
        {
            resultado.Add(new ZonaEstribos
            {
                Inicio = inicioTotal,
                Fin = finTotal,
                Espaciamiento = separacionPrimera,
                Cantidad = 0,
                UsarCantidadExacta = false,
                Nombre = "TOTAL"
            });

            return resultado;
        }

        double ultimoInferior = inicioTotal;
        double ultimoSuperior = finTotal;
        bool hayZonasExtremo = false;

        // Las primeras n-1 filas se aplican simétricamente desde la base y
        // desde la coronación de la columna. Cada fila comienza usando su
        // propia separación medida desde el último estribo anterior.
        for (int zona = 0; zona < n - 1; zona++)
        {
            double separacion = separaciones != null &&
                zona < separaciones.Length
                ? separaciones[zona]
                : ConvertirCm(10.0);
            int cantidadSolicitada = cantidades != null &&
                zona < cantidades.Length
                ? cantidades[zona]
                : 1;

            if (separacion <= Tol || cantidadSolicitada <= 0)
                continue;

            double primeroInferior = hayZonasExtremo
                ? ultimoInferior + separacion
                : inicioTotal;
            double primeroSuperior = hayZonasExtremo
                ? ultimoSuperior - separacion
                : finTotal;

            if (primeroSuperior < primeroInferior - Tol)
                break;

            double disponible = primeroSuperior - primeroInferior;
            int cantidadMaxima = disponible <= Tol
                ? 1
                : System.Math.Max(1,
                    (int)System.Math.Floor(
                        (disponible + Tol) / (2.0 * separacion)) + 1);
            int cantidadUsada = System.Math.Max(1,
                System.Math.Min(cantidadSolicitada, cantidadMaxima));

            double finInferior = primeroInferior +
                ((cantidadUsada - 1) * separacion);
            double inicioSuperior = primeroSuperior -
                ((cantidadUsada - 1) * separacion);

            resultado.Add(new ZonaEstribos
            {
                Inicio = primeroInferior,
                Fin = finInferior,
                Espaciamiento = separacion,
                Cantidad = cantidadUsada,
                UsarCantidadExacta = true,
                Nombre = "Z" + (zona + 1) + "-INF"
            });

            // Si ambas posiciones coinciden, se crea una sola zona para no
            // duplicar el mismo estribo en el centro.
            if (inicioSuperior > finInferior + Tol)
            {
                resultado.Add(new ZonaEstribos
                {
                    Inicio = inicioSuperior,
                    Fin = primeroSuperior,
                    Espaciamiento = separacion,
                    Cantidad = cantidadUsada,
                    UsarCantidadExacta = true,
                    Nombre = "Z" + (zona + 1) + "-SUP"
                });
            }

            ultimoInferior = finInferior;
            ultimoSuperior = inicioSuperior;
            hayZonasExtremo = true;
        }

        // La última fila es RESTO y conserva la regla nativa ESPACIADO MÁXIMO.
        // Cuando hay zonas extremas NO se reutilizan sus barras límite ni se
        // ocultan extremos del conjunto. El rango de RESTO se centra entre ellas.
        int indiceResto = n - 1;
        double separacionResto = separaciones != null &&
            indiceResto < separaciones.Length
            ? separaciones[indiceResto]
            : ConvertirCm(20.0);

        if (separacionResto > Tol)
        {
            double inicioRango = hayZonasExtremo
                ? ultimoInferior
                : inicioTotal;
            double finRango = hayZonasExtremo
                ? ultimoSuperior
                : finTotal;
            double longitudRango = finRango - inicioRango;

            if (hayZonasExtremo)
            {
                int intervalosTotales = System.Math.Max(
                    1,
                    (int)System.Math.Ceiling(
                        longitudRango / separacionResto));

                if (intervalosTotales >= 2)
                {
                    double separacionReal =
                        longitudRango / intervalosTotales;

                    double inicioResto =
                        inicioRango + separacionReal;
                    double finResto =
                        finRango - separacionReal;

                    if (finResto >= inicioResto - Tol)
                    {
                        resultado.Add(new ZonaEstribos
                        {
                            Inicio = inicioResto,
                            Fin = finResto,
                            Espaciamiento = separacionResto,
                            Cantidad = 0,
                            UsarCantidadExacta = false,
                            OmitirPrimeraBarra = false,
                            OmitirUltimaBarra = false,
                            Nombre = "RESTO"
                        });
                    }
                }
            }
            else if (longitudRango > Tol)
            {
                resultado.Add(new ZonaEstribos
                {
                    Inicio = inicioRango,
                    Fin = finRango,
                    Espaciamiento = separacionResto,
                    Cantidad = 0,
                    UsarCantidadExacta = false,
                    OmitirPrimeraBarra = false,
                    OmitirUltimaBarra = false,
                    Nombre = "RESTO"
                });
            }
        }

        return resultado
            .Where(x => x != null && x.Fin >= x.Inicio - Tol)
            .OrderBy(x => x.Inicio)
            .ThenBy(x => x.Fin)
            .ToList();
    }

    private List<ZonaEstribos> ObtenerZonasEstribosLegacy(
        DatosColumna datos,
        double retiroVertical,
        double longitudZonaConfinada,
        double espaciamientoConfinado,
        double espaciamientoCentral)
    {
        List<ZonaEstribos> resultado = new List<ZonaEstribos>();

        double inicio = datos.ZInferior + retiroVertical;
        double fin = datos.ZSuperior - retiroVertical;
        double altura = fin - inicio;

        if (altura <= Tol)
            return resultado;

        double zona = System.Math.Min(
            System.Math.Max(longitudZonaConfinada, 0.0),
            altura / 2.0);

        if (zona <= Tol || altura <= 2.0 * zona + Tol)
        {
            resultado.Add(new ZonaEstribos
            {
                Inicio = inicio,
                Fin = fin,
                Espaciamiento = espaciamientoConfinado,
                Cantidad = 0,
                UsarCantidadExacta = false,
                Nombre = "TOTAL"
            });

            return resultado;
        }

        double finInferior = inicio + zona;
        double inicioSuperior = fin - zona;

        resultado.Add(new ZonaEstribos
        {
            Inicio = inicio,
            Fin = finInferior,
            Espaciamiento = espaciamientoConfinado,
            Cantidad = 0,
            UsarCantidadExacta = false,
            Nombre = "INF"
        });

        double margenCentro = System.Math.Min(
            espaciamientoCentral * 0.35,
            System.Math.Max((inicioSuperior - finInferior) * 0.10, 0.0));

        if (inicioSuperior - finInferior > Tol)
        {
            resultado.Add(new ZonaEstribos
            {
                Inicio = finInferior + margenCentro,
                Fin = inicioSuperior - margenCentro,
                Espaciamiento = espaciamientoCentral,
                Cantidad = 0,
                UsarCantidadExacta = false,
                Nombre = "CENTRO"
            });
        }

        resultado.Add(new ZonaEstribos
        {
            Inicio = inicioSuperior,
            Fin = fin,
            Espaciamiento = espaciamientoConfinado,
            Cantidad = 0,
            UsarCantidadExacta = false,
            Nombre = "SUP"
        });

        return resultado;
    }

    private List<GrupoColumnasVerticales> AgruparColumnasVerticales(
        List<DatosColumna> datosColumnas)
    {
        List<GrupoColumnasVerticales> grupos =
            new List<GrupoColumnasVerticales>();

        if (datosColumnas == null || datosColumnas.Count == 0)
            return grupos;

        List<DatosColumna> ordenadas = datosColumnas
            .Where(x => x != null && x.Columna != null)
            .OrderBy(x => x.ZInferior)
            .ThenBy(x => x.ZSuperior)
            .ThenBy(x => x.Columna.Id.Value)
            .ToList();

        foreach (DatosColumna candidata in ordenadas)
        {
            GrupoColumnasVerticales mejorGrupo = null;
            double mejorSeparacionZ = double.MaxValue;

            foreach (GrupoColumnasVerticales grupo in grupos)
            {
                DatosColumna superior = grupo.TramoSuperior;

                if (!SonColumnasApilables(superior, candidata))
                    continue;

                double separacionZ = Math.Abs(
                    candidata.ZInferior - superior.ZSuperior);

                if (separacionZ < mejorSeparacionZ)
                {
                    mejorSeparacionZ = separacionZ;
                    mejorGrupo = grupo;
                }
            }

            if (mejorGrupo == null)
            {
                mejorGrupo = new GrupoColumnasVerticales();
                grupos.Add(mejorGrupo);
            }

            mejorGrupo.Tramos.Add(candidata);
            mejorGrupo.Tramos = mejorGrupo.Tramos
                .OrderBy(x => x.ZInferior)
                .ThenBy(x => x.ZSuperior)
                .ToList();
        }

        return grupos
            .OrderBy(x =>
            {
                DatosColumna inferior = x.TramoInferior;
                XYZ centro = ObtenerCentroMundialEnPlanta(inferior);
                return centro != null ? centro.X : 0.0;
            })
            .ThenBy(x =>
            {
                DatosColumna inferior = x.TramoInferior;
                XYZ centro = ObtenerCentroMundialEnPlanta(inferior);
                return centro != null ? centro.Y : 0.0;
            })
            .ThenBy(x => x.ZInferior)
            .ToList();
    }

    private bool SonColumnasApilables(
        DatosColumna inferior,
        DatosColumna superior)
    {
        if (inferior == null || superior == null ||
            inferior.Columna == null || superior.Columna == null)
        {
            return false;
        }

        // Solo se encadenan tramos consecutivos. Se admiten pequeñas uniones,
        // solapes o desfases de modelado de hasta 5 cm entre niveles.
        double toleranciaVertical = ConvertirCm(5.0);

        if (superior.ZInferior >
            inferior.ZSuperior + toleranciaVertical)
        {
            return false;
        }

        if (superior.ZSuperior <=
            inferior.ZSuperior + TolGeometria)
        {
            return false;
        }

        XYZ centroInferior = ObtenerCentroMundialEnPlanta(inferior);
        XYZ centroSuperior = ObtenerCentroMundialEnPlanta(superior);

        if (centroInferior == null || centroSuperior == null)
            return false;

        double distanciaHorizontal = Math.Sqrt(
            Math.Pow(centroSuperior.X - centroInferior.X, 2.0) +
            Math.Pow(centroSuperior.Y - centroInferior.Y, 2.0));

        RectanguloLocal cajaInferior = ObtenerCaja(
            ObtenerTodosPuntos(inferior));
        RectanguloLocal cajaSuperiorEnInferior = ObtenerCaja(
            TransformarContornoAReferencia(
                superior,
                inferior));

        if (cajaInferior == null || cajaSuperiorEnInferior == null)
            return false;

        double dimensionMenor = Math.Max(
            TolGeometria,
            Math.Min(
                Math.Min(cajaInferior.Ancho, cajaInferior.Alto),
                Math.Min(
                    cajaSuperiorEnInferior.Ancho,
                    cajaSuperiorEnInferior.Alto)));

        double toleranciaCentro = Math.Max(
            ConvertirCm(2.0),
            dimensionMenor * 0.05);

        if (distanciaHorizontal > toleranciaCentro)
            return false;

        // Los ejes pueden estar invertidos 180° sin romper la continuidad,
        // pero no se agrupan secciones con una rotación realmente diferente.
        double cosenoMinimo = Math.Cos(Math.PI / 180.0);
        double alineacionX = Math.Abs(
            inferior.EjeX.DotProduct(superior.EjeX));
        double alineacionY = Math.Abs(
            inferior.EjeY.DotProduct(superior.EjeY));

        if (alineacionX < cosenoMinimo ||
            alineacionY < cosenoMinimo)
        {
            return false;
        }

        double areaInferior = Math.Max(
            cajaInferior.Ancho * cajaInferior.Alto,
            TolGeometria);
        double areaSuperior = Math.Max(
            cajaSuperiorEnInferior.Ancho *
            cajaSuperiorEnInferior.Alto,
            TolGeometria);

        double solapeX = Math.Max(
            0.0,
            Math.Min(
                cajaInferior.MaxX,
                cajaSuperiorEnInferior.MaxX) -
            Math.Max(
                cajaInferior.MinX,
                cajaSuperiorEnInferior.MinX));

        double solapeY = Math.Max(
            0.0,
            Math.Min(
                cajaInferior.MaxY,
                cajaSuperiorEnInferior.MaxY) -
            Math.Max(
                cajaInferior.MinY,
                cajaSuperiorEnInferior.MinY));

        double areaSolape = solapeX * solapeY;
        double razonSolape = areaSolape /
            Math.Max(Math.Min(areaInferior, areaSuperior), TolGeometria);
        double razonAreas = Math.Min(areaInferior, areaSuperior) /
            Math.Max(areaInferior, areaSuperior);

        // Se exige prácticamente la misma sección. Si la sección cambia de
        // forma o tamaño de manera importante, es más seguro mantener grupos
        // separados porque normalmente requiere empalmes o transición de barras.
        return razonSolape >= 0.90 && razonAreas >= 0.90;
    }

    private XYZ ObtenerCentroMundialEnPlanta(DatosColumna datos)
    {
        if (datos == null || datos.Origen == null ||
            datos.EjeX == null || datos.EjeY == null ||
            !TieneContornosValidos(datos))
        {
            return null;
        }

        PuntoLocal centroLocal = CentroidePuntos(ObtenerTodosPuntos(datos));

        if (centroLocal == null)
            return null;

        return datos.Origen
            .Add(datos.EjeX.Multiply(centroLocal.X))
            .Add(datos.EjeY.Multiply(centroLocal.Y));
    }

    private List<PuntoLocal> TransformarContornoAReferencia(
        DatosColumna origenDatos,
        DatosColumna referencia)
    {
        List<PuntoLocal> resultado = new List<PuntoLocal>();

        if (origenDatos == null || referencia == null ||
            !TieneContornosValidos(origenDatos))
        {
            return resultado;
        }

        foreach (PuntoLocal punto in ObtenerTodosPuntos(origenDatos))
        {
            if (punto == null)
                continue;

            XYZ mundial = origenDatos.Origen
                .Add(origenDatos.EjeX.Multiply(punto.X))
                .Add(origenDatos.EjeY.Multiply(punto.Y));

            XYZ vectorReferencia = mundial.Subtract(referencia.Origen);

            resultado.Add(new PuntoLocal(
                vectorReferencia.DotProduct(referencia.EjeX),
                vectorReferencia.DotProduct(referencia.EjeY)));
        }

        return resultado;
    }

    private DatosColumna ObtenerDatosColumna(FamilyInstance columna)
    {
        if (columna == null)
            return null;

        LocationPoint ubicacion = columna.Location as LocationPoint;

        if (ubicacion == null)
            return null;

        double rotacion = ubicacion.Rotation;

        XYZ ejeX = new XYZ(
            Math.Cos(rotacion),
            Math.Sin(rotacion),
            0.0).Normalize();

        XYZ ejeY = new XYZ(
            -Math.Sin(rotacion),
            Math.Cos(rotacion),
            0.0).Normalize();

        XYZ origen = new XYZ(
            ubicacion.Point.X,
            ubicacion.Point.Y,
            0.0);

        Options opciones = new Options
        {
            ComputeReferences = true,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geometria = columna.get_Geometry(opciones);

        if (geometria == null)
            return null;

        List<Solid> solidos = ObtenerSolidos(geometria);

        if (solidos.Count == 0)
            return null;

        double zInferior;
        double zSuperior;

        if (!ObtenerExtremosVerticales(
            solidos,
            out zInferior,
            out zSuperior))
        {
            return null;
        }

        if (zSuperior <= zInferior + Tol)
            return null;

        List<PlanarFace> carasSeccion =
            ObtenerCarasInferioresDeTodosLosSolidos(solidos);

        if (carasSeccion.Count == 0)
            return null;

        List<List<PuntoLocal>> contornos =
            new List<List<PuntoLocal>>();

        foreach (PlanarFace caraSeccion in carasSeccion)
        {
            List<XYZ> contornoMundial =
                ObtenerContornoExterior(caraSeccion);

            if (contornoMundial.Count < 3)
                continue;

            List<PuntoLocal> contorno = new List<PuntoLocal>();

            foreach (XYZ punto in contornoMundial)
            {
                XYZ vector = punto.Subtract(origen);

                contorno.Add(new PuntoLocal(
                    vector.DotProduct(ejeX),
                    vector.DotProduct(ejeY)));
            }

            contorno = LimpiarPoligono(contorno);

            if (contorno.Count < 3 ||
                Math.Abs(AreaFirmada(contorno)) <= TolGeometria)
            {
                continue;
            }

            if (AreaFirmada(contorno) < 0.0)
                contorno.Reverse();

            if (!ContornoDuplicado(contornos, contorno))
                contornos.Add(contorno);
        }

        contornos = contornos
            .Where(x => x != null && x.Count >= 3)
            .OrderByDescending(x => Math.Abs(AreaFirmada(x)))
            .ToList();

        if (contornos.Count == 0)
            return null;

        return new DatosColumna
        {
            Columna = columna,
            Origen = origen,
            EjeX = ejeX,
            EjeY = ejeY,
            ZInferior = zInferior,
            ZSuperior = zSuperior,
            Contorno = contornos[0]
                .Select(x => x.Copiar())
                .ToList(),
            Contornos = contornos
                .Select(x => x.Select(p => p.Copiar()).ToList())
                .ToList(),
            Solidos = solidos
        };
    }

    private List<Solid> ObtenerSolidos(GeometryElement geometria)
    {
        List<Solid> resultado = new List<Solid>();

        if (geometria == null)
            return resultado;

        foreach (GeometryObject objeto in geometria)
        {
            Solid solid = objeto as Solid;

            if (solid != null &&
                solid.Volume > Tol &&
                solid.Faces.Size > 0)
            {
                resultado.Add(solid);
                continue;
            }

            GeometryInstance instancia = objeto as GeometryInstance;

            if (instancia == null)
                continue;

            GeometryElement geometriaInstancia =
                instancia.GetInstanceGeometry();

            if (geometriaInstancia == null)
                continue;

            resultado.AddRange(ObtenerSolidos(geometriaInstancia));
        }

        return resultado;
    }

    private List<PlanarFace> ObtenerCarasInferioresDeTodosLosSolidos(
        List<Solid> solidos)
    {
        List<PlanarFace> resultado = new List<PlanarFace>();

        if (solidos == null)
            return resultado;

        double toleranciaZ = Math.Max(TolGeometria * 20.0, 1e-5);

        foreach (Solid solid in solidos)
        {
            if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                continue;

            List<PlanarFace> descendentes = new List<PlanarFace>();
            List<PlanarFace> horizontales = new List<PlanarFace>();

            foreach (Face face in solid.Faces)
            {
                PlanarFace planar = face as PlanarFace;
                if (planar == null || planar.Area <= TolGeometria)
                    continue;

                XYZ normal;
                try
                {
                    normal = planar.FaceNormal.Normalize();
                }
                catch
                {
                    continue;
                }

                if (normal.Z < -0.90)
                    descendentes.Add(planar);

                if (Math.Abs(normal.Z) > 0.90)
                    horizontales.Add(planar);
            }

            List<PlanarFace> candidatas = descendentes.Count > 0
                ? descendentes
                : horizontales;

            if (candidatas.Count == 0)
                continue;

            double menorZ = candidatas.Min(x => x.Origin.Z);

            foreach (PlanarFace cara in candidatas)
            {
                if (Math.Abs(cara.Origin.Z - menorZ) <= toleranciaZ)
                    resultado.Add(cara);
            }
        }

        return resultado;
    }

    private bool ContornoDuplicado(
        List<List<PuntoLocal>> existentes,
        List<PuntoLocal> candidato)
    {
        if (existentes == null || candidato == null || candidato.Count < 3)
            return false;

        RectanguloLocal cajaCandidato = ObtenerCaja(candidato);
        double areaCandidato = Math.Abs(AreaFirmada(candidato));
        PuntoLocal centroCandidato = CentroidePuntos(candidato);

        foreach (List<PuntoLocal> existente in existentes)
        {
            if (existente == null || existente.Count < 3)
                continue;

            RectanguloLocal cajaExistente = ObtenerCaja(existente);
            PuntoLocal centroExistente = CentroidePuntos(existente);

            if (cajaCandidato == null || cajaExistente == null ||
                centroCandidato == null || centroExistente == null)
            {
                continue;
            }

            double areaExistente = Math.Abs(AreaFirmada(existente));
            double referencia = Math.Max(
                Math.Max(cajaCandidato.Ancho, cajaCandidato.Alto),
                Math.Max(cajaExistente.Ancho, cajaExistente.Alto));
            double tolerancia = Math.Max(TolGeometria * 20.0, referencia * 1e-6);

            if (Math.Abs(areaCandidato - areaExistente) <=
                    Math.Max(TolGeometria, areaExistente * 1e-6) &&
                Distancia(centroCandidato, centroExistente) <= tolerancia &&
                Math.Abs(cajaCandidato.MinX - cajaExistente.MinX) <= tolerancia &&
                Math.Abs(cajaCandidato.MaxX - cajaExistente.MaxX) <= tolerancia &&
                Math.Abs(cajaCandidato.MinY - cajaExistente.MinY) <= tolerancia &&
                Math.Abs(cajaCandidato.MaxY - cajaExistente.MaxY) <= tolerancia)
            {
                return true;
            }
        }

        return false;
    }

    // ================================================================
    // CONTORNO DE SECCIÓN ORDENADO
    // ================================================================
    // EdgeArray conserva las aristas del loop, pero la teselación de cada Edge
    // puede venir orientada en cualquiera de los dos sentidos. Si se concatenan
    // sin comprobar sus extremos, el final de una arista puede unirse al extremo
    // incorrecto de la siguiente y aparecen diagonales cruzadas en la vista 2D.
    //
    // Esta versión encadena cada tramo por proximidad de extremos, invierte el
    // teselado cuando es necesario y solo acepta loops realmente cerrados.
    private List<XYZ> ObtenerContornoExterior(PlanarFace cara)
    {
        List<XYZ> mejor = new List<XYZ>();
        double mejorArea = 0.0;

        if (cara == null)
            return mejor;

        foreach (EdgeArray loop in cara.EdgeLoops)
        {
            List<List<XYZ>> tramos =
                new List<List<XYZ>>();

            foreach (Edge edge in loop)
            {
                if (edge == null)
                    continue;

                IList<XYZ> teselado;

                try
                {
                    teselado = edge.Tessellate();
                }
                catch
                {
                    continue;
                }

                List<XYZ> tramo =
                    LimpiarPuntosConsecutivosXYZ(teselado);

                if (tramo.Count >= 2)
                    tramos.Add(tramo);
            }

            List<XYZ> puntos =
                EncadenarTramosDeContorno(tramos);

            puntos = LimpiarPuntosConsecutivosXYZ(puntos);

            if (puntos.Count > 1 &&
                puntos[0].DistanceTo(
                    puntos[puntos.Count - 1]) <=
                TolGeometria * 10.0)
            {
                puntos.RemoveAt(puntos.Count - 1);
            }

            if (puntos.Count < 3)
                continue;

            double area = Math.Abs(AreaXY(puntos));

            if (area > mejorArea + TolGeometria)
            {
                mejorArea = area;
                mejor = puntos
                    .Select(p => new XYZ(p.X, p.Y, p.Z))
                    .ToList();
            }
        }

        return mejor;
    }

    private List<XYZ> EncadenarTramosDeContorno(
        List<List<XYZ>> tramosOriginales)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (tramosOriginales == null ||
            tramosOriginales.Count == 0)
        {
            return resultado;
        }

        List<List<XYZ>> pendientes =
            tramosOriginales
                .Where(x => x != null && x.Count >= 2)
                .Select(x => x
                    .Where(p => p != null)
                    .Select(p => new XYZ(p.X, p.Y, p.Z))
                    .ToList())
                .Where(x => x.Count >= 2)
                .ToList();

        if (pendientes.Count == 0)
            return resultado;

        // Se inicia con cualquier arista. El resto se orientará de modo que su
        // primer punto coincida con el último punto ya incorporado.
        resultado.AddRange(pendientes[0]);
        pendientes.RemoveAt(0);

        double toleranciaConexion =
            Math.Max(TolGeometria * 10.0, 1e-6);

        int seguridad = 0;

        while (pendientes.Count > 0 && seguridad < 10000)
        {
            seguridad++;

            XYZ extremoActual = resultado[resultado.Count - 1];
            int mejorIndice = -1;
            bool invertir = false;
            double mejorDistancia = double.MaxValue;

            for (int i = 0; i < pendientes.Count; i++)
            {
                List<XYZ> tramo = pendientes[i];

                if (tramo == null || tramo.Count < 2)
                    continue;

                double distanciaInicio =
                    extremoActual.DistanceTo(tramo[0]);

                double distanciaFin =
                    extremoActual.DistanceTo(
                        tramo[tramo.Count - 1]);

                if (distanciaInicio < mejorDistancia)
                {
                    mejorDistancia = distanciaInicio;
                    mejorIndice = i;
                    invertir = false;
                }

                if (distanciaFin < mejorDistancia)
                {
                    mejorDistancia = distanciaFin;
                    mejorIndice = i;
                    invertir = true;
                }
            }

            // Un EdgeLoop válido debe poder encadenarse sin saltos. Si no existe
            // continuidad, se descarta el loop para no dibujar un polígono cruzado.
            if (mejorIndice < 0 ||
                mejorDistancia > toleranciaConexion)
            {
                return new List<XYZ>();
            }

            List<XYZ> siguiente =
                pendientes[mejorIndice];

            pendientes.RemoveAt(mejorIndice);

            if (invertir)
                siguiente.Reverse();

            AgregarTramoContinuoXYZ(
                resultado,
                siguiente,
                toleranciaConexion);
        }

        if (pendientes.Count > 0 ||
            resultado.Count < 3)
        {
            return new List<XYZ>();
        }

        // Se comprueba el cierre real del loop antes de entregarlo a la ventana.
        if (resultado[resultado.Count - 1].DistanceTo(
                resultado[0]) > toleranciaConexion)
        {
            return new List<XYZ>();
        }

        return resultado;
    }

    private void AgregarTramoContinuoXYZ(
        List<XYZ> destino,
        List<XYZ> tramo,
        double tolerancia)
    {
        if (destino == null || tramo == null ||
            tramo.Count == 0)
        {
            return;
        }

        int indiceInicial = 0;

        if (destino.Count > 0 &&
            destino[destino.Count - 1].DistanceTo(
                tramo[0]) <= tolerancia)
        {
            indiceInicial = 1;
        }

        for (int i = indiceInicial; i < tramo.Count; i++)
        {
            XYZ punto = tramo[i];

            if (punto == null)
                continue;

            if (destino.Count == 0 ||
                destino[destino.Count - 1].DistanceTo(
                    punto) > TolGeometria)
            {
                destino.Add(
                    new XYZ(punto.X, punto.Y, punto.Z));
            }
        }
    }

    private List<XYZ> LimpiarPuntosConsecutivosXYZ(
        IEnumerable<XYZ> puntos)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (puntos == null)
            return resultado;

        foreach (XYZ punto in puntos)
        {
            if (punto == null)
                continue;

            if (resultado.Count == 0 ||
                resultado[resultado.Count - 1].DistanceTo(
                    punto) > TolGeometria)
            {
                resultado.Add(
                    new XYZ(punto.X, punto.Y, punto.Z));
            }
        }

        return resultado;
    }

    private bool ObtenerExtremosVerticales(
        List<Solid> solidos,
        out double zInferior,
        out double zSuperior)
    {
        zInferior = double.MaxValue;
        zSuperior = double.MinValue;

        foreach (Solid solid in solidos)
        {
            foreach (Face face in solid.Faces)
            {
                Mesh malla;

                try
                {
                    malla = face.Triangulate();
                }
                catch
                {
                    continue;
                }

                if (malla == null)
                    continue;

                for (int i = 0; i < malla.Vertices.Count; i++)
                {
                    XYZ p = malla.Vertices[i];
                    zInferior = Math.Min(zInferior, p.Z);
                    zSuperior = Math.Max(zSuperior, p.Z);
                }
            }
        }

        return zInferior < double.MaxValue &&
               zSuperior > double.MinValue;
    }

    private List<PuntoLocal> LimpiarPoligono(
        List<PuntoLocal> puntos)
    {
        List<PuntoLocal> sinDuplicados = new List<PuntoLocal>();

        foreach (PuntoLocal punto in puntos)
        {
            if (sinDuplicados.Count == 0 ||
                Distancia(
                    sinDuplicados[sinDuplicados.Count - 1],
                    punto) > TolGeometria)
            {
                sinDuplicados.Add(punto.Copiar());
            }
        }

        if (sinDuplicados.Count > 1 &&
            Distancia(
                sinDuplicados[0],
                sinDuplicados[sinDuplicados.Count - 1]) <=
            TolGeometria)
        {
            sinDuplicados.RemoveAt(sinDuplicados.Count - 1);
        }

        bool cambio = true;

        while (cambio && sinDuplicados.Count >= 3)
        {
            cambio = false;

            for (int i = 0; i < sinDuplicados.Count; i++)
            {
                PuntoLocal anterior =
                    sinDuplicados[(i - 1 + sinDuplicados.Count) %
                                  sinDuplicados.Count];
                PuntoLocal actual = sinDuplicados[i];
                PuntoLocal siguiente =
                    sinDuplicados[(i + 1) % sinDuplicados.Count];

                double cruz =
                    (actual.X - anterior.X) *
                    (siguiente.Y - actual.Y) -
                    (actual.Y - anterior.Y) *
                    (siguiente.X - actual.X);

                if (Math.Abs(cruz) <= TolGeometria)
                {
                    sinDuplicados.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        return sinDuplicados;
    }

    private List<PuntoLocal> DesfasarPoligonoInterior(
        List<PuntoLocal> poligono,
        double distancia)
    {
        List<PuntoLocal> resultado = new List<PuntoLocal>();

        if (poligono == null || poligono.Count < 3)
            return resultado;

        if (distancia <= Tol)
            return poligono.Select(p => p.Copiar()).ToList();

        List<PuntoLocal> ccw =
            poligono.Select(p => p.Copiar()).ToList();

        if (AreaFirmada(ccw) < 0.0)
            ccw.Reverse();

        for (int i = 0; i < ccw.Count; i++)
        {
            PuntoLocal anterior =
                ccw[(i - 1 + ccw.Count) % ccw.Count];
            PuntoLocal actual = ccw[i];
            PuntoLocal siguiente = ccw[(i + 1) % ccw.Count];

            PuntoLocal a1;
            PuntoLocal a2;
            PuntoLocal b1;
            PuntoLocal b2;

            CrearLineaDesfasada(
                anterior,
                actual,
                distancia,
                out a1,
                out a2);

            CrearLineaDesfasada(
                actual,
                siguiente,
                distancia,
                out b1,
                out b2);

            PuntoLocal interseccion;

            if (!InterseccionLineas(
                a1,
                a2,
                b1,
                b2,
                out interseccion))
            {
                PuntoLocal n1 = NormalInterior(anterior, actual);
                PuntoLocal n2 = NormalInterior(actual, siguiente);
                PuntoLocal promedio = new PuntoLocal(
                    n1.X + n2.X,
                    n1.Y + n2.Y);

                double longitud =
                    Math.Sqrt(
                        promedio.X * promedio.X +
                        promedio.Y * promedio.Y);

                if (longitud <= Tol)
                    promedio = n1;
                else
                {
                    promedio.X /= longitud;
                    promedio.Y /= longitud;
                }

                interseccion = new PuntoLocal(
                    actual.X + promedio.X * distancia,
                    actual.Y + promedio.Y * distancia);
            }

            resultado.Add(interseccion);
        }

        resultado = LimpiarPoligono(resultado);

        if (resultado.Count < 3 ||
            Math.Abs(AreaFirmada(resultado)) <= TolGeometria)
        {
            return new List<PuntoLocal>();
        }

        if (AreaFirmada(resultado) < 0.0)
            resultado.Reverse();

        PuntoLocal centro = CentroidePoligono(resultado);

        if (!PuntoDentroPoligono(centro, poligono))
        {
            return new List<PuntoLocal>();
        }

        return resultado;
    }

    private void CrearLineaDesfasada(
        PuntoLocal a,
        PuntoLocal b,
        double distancia,
        out PuntoLocal p1,
        out PuntoLocal p2)
    {
        PuntoLocal normal = NormalInterior(a, b);

        p1 = new PuntoLocal(
            a.X + normal.X * distancia,
            a.Y + normal.Y * distancia);

        p2 = new PuntoLocal(
            b.X + normal.X * distancia,
            b.Y + normal.Y * distancia);
    }

    private PuntoLocal NormalInterior(PuntoLocal a, PuntoLocal b)
    {
        double dx = b.X - a.X;
        double dy = b.Y - a.Y;
        double longitud = Math.Sqrt(dx * dx + dy * dy);

        if (longitud <= Tol)
            return new PuntoLocal(0.0, 0.0);

        return new PuntoLocal(-dy / longitud, dx / longitud);
    }

    private bool InterseccionLineas(
        PuntoLocal a1,
        PuntoLocal a2,
        PuntoLocal b1,
        PuntoLocal b2,
        out PuntoLocal interseccion)
    {
        interseccion = null;

        double x1 = a1.X;
        double y1 = a1.Y;
        double x2 = a2.X;
        double y2 = a2.Y;
        double x3 = b1.X;
        double y3 = b1.Y;
        double x4 = b2.X;
        double y4 = b2.Y;

        double denominador =
            (x1 - x2) * (y3 - y4) -
            (y1 - y2) * (x3 - x4);

        if (Math.Abs(denominador) <= Tol)
            return false;

        double determinante1 = x1 * y2 - y1 * x2;
        double determinante2 = x3 * y4 - y3 * x4;

        double x =
            (determinante1 * (x3 - x4) -
             (x1 - x2) * determinante2) /
            denominador;

        double y =
            (determinante1 * (y3 - y4) -
             (y1 - y2) * determinante2) /
            denominador;

        interseccion = new PuntoLocal(x, y);
        return true;
    }

    private List<PuntoLocal> DistribuirPuntosEnContorno(
        List<PuntoLocal> contorno,
        double separacionMaxima,
        double distanciaMinima)
    {
        List<PuntoLocal> candidatos = new List<PuntoLocal>();

        if (contorno == null || contorno.Count < 3)
            return candidatos;

        for (int i = 0; i < contorno.Count; i++)
        {
            PuntoLocal a = contorno[i];
            PuntoLocal b = contorno[(i + 1) % contorno.Count];
            double longitud = Distancia(a, b);

            if (longitud <= Tol)
                continue;

            int segmentos = Math.Max(
                1,
                (int)Math.Ceiling(longitud / separacionMaxima));

            for (int j = 0; j < segmentos; j++)
            {
                double t = (double)j / segmentos;
                PuntoLocal punto = new PuntoLocal(
                    a.X + (b.X - a.X) * t,
                    a.Y + (b.Y - a.Y) * t);

                if (!ContienePuntoCercano(
                    candidatos,
                    punto,
                    distanciaMinima))
                {
                    candidatos.Add(punto);
                }
            }
        }

        return candidatos;
    }

    private PuntoLocal ObtenerDireccionInteriorEnPunto(
        PuntoLocal punto,
        List<PuntoLocal> poligono)
    {
        double mejorDistancia = double.MaxValue;
        PuntoLocal mejorNormal = new PuntoLocal(1.0, 0.0);

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoLocal a = poligono[i];
            PuntoLocal b = poligono[(i + 1) % poligono.Count];

            double distancia =
                DistanciaPuntoSegmento(punto, a, b);

            if (distancia < mejorDistancia)
            {
                mejorDistancia = distancia;
                mejorNormal = NormalInterior(a, b);
            }
        }

        PuntoLocal prueba = new PuntoLocal(
            punto.X + mejorNormal.X * 0.01,
            punto.Y + mejorNormal.Y * 0.01);

        if (!PuntoDentroPoligono(prueba, poligono))
        {
            mejorNormal.X *= -1.0;
            mejorNormal.Y *= -1.0;
        }

        return mejorNormal;
    }

    private List<RectanguloLocal> DescomponerEnRectangulos(
        List<PuntoLocal> poligono)
    {
        List<RectanguloLocal> resultado =
            new List<RectanguloLocal>();

        if (poligono == null || poligono.Count < 3)
            return resultado;

        bool ortogonal = true;

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoLocal a = poligono[i];
            PuntoLocal b = poligono[(i + 1) % poligono.Count];

            if (Math.Abs(a.X - b.X) > TolGeometria &&
                Math.Abs(a.Y - b.Y) > TolGeometria)
            {
                ortogonal = false;
                break;
            }
        }

        if (!ortogonal)
        {
            RectanguloLocal caja = ObtenerCaja(poligono);

            if (caja != null)
                resultado.Add(caja);

            return resultado;
        }

        List<double> xs = UnicosOrdenados(
            poligono.Select(p => p.X).ToList());
        List<double> ys = UnicosOrdenados(
            poligono.Select(p => p.Y).ToList());

        if (xs.Count < 2 || ys.Count < 2)
            return resultado;

        Dictionary<string, RectanguloLocal> activos =
            new Dictionary<string, RectanguloLocal>();

        for (int j = 0; j < ys.Count - 1; j++)
        {
            double yMin = ys[j];
            double yMax = ys[j + 1];
            List<RectanguloLocal> bandas =
                new List<RectanguloLocal>();

            int i = 0;

            while (i < xs.Count - 1)
            {
                double xCentro = (xs[i] + xs[i + 1]) / 2.0;
                double yCentro = (yMin + yMax) / 2.0;

                if (!PuntoDentroPoligono(
                    new PuntoLocal(xCentro, yCentro),
                    poligono))
                {
                    i++;
                    continue;
                }

                int inicio = i;
                int fin = i + 1;
                i++;

                while (i < xs.Count - 1)
                {
                    xCentro = (xs[i] + xs[i + 1]) / 2.0;

                    if (!PuntoDentroPoligono(
                        new PuntoLocal(xCentro, yCentro),
                        poligono))
                    {
                        break;
                    }

                    fin = i + 1;
                    i++;
                }

                bandas.Add(new RectanguloLocal
                {
                    MinX = xs[inicio],
                    MaxX = xs[fin],
                    MinY = yMin,
                    MaxY = yMax
                });
            }

            Dictionary<string, RectanguloLocal> nuevosActivos =
                new Dictionary<string, RectanguloLocal>();

            foreach (RectanguloLocal banda in bandas)
            {
                string clave = ClaveIntervalo(banda.MinX, banda.MaxX);
                RectanguloLocal existente;

                if (activos.TryGetValue(clave, out existente) &&
                    Math.Abs(existente.MaxY - banda.MinY) <=
                    TolGeometria)
                {
                    existente.MaxY = banda.MaxY;
                    nuevosActivos[clave] = existente;
                    activos.Remove(clave);
                }
                else
                {
                    nuevosActivos[clave] = banda;
                }
            }

            foreach (RectanguloLocal finalizado in activos.Values)
                resultado.Add(finalizado);

            activos = nuevosActivos;
        }

        foreach (RectanguloLocal finalizado in activos.Values)
            resultado.Add(finalizado);

        return resultado
            .Where(r => r.Ancho > TolGeometria && r.Alto > TolGeometria)
            .ToList();
    }

    private RectanguloLocal ObtenerCaja(List<PuntoLocal> puntos)
    {
        if (puntos == null || puntos.Count == 0)
            return null;

        return new RectanguloLocal
        {
            MinX = puntos.Min(p => p.X),
            MaxX = puntos.Max(p => p.X),
            MinY = puntos.Min(p => p.Y),
            MaxY = puntos.Max(p => p.Y)
        };
    }

    private List<double> UnicosOrdenados(List<double> valores)
    {
        List<double> resultado = new List<double>();

        foreach (double valor in valores.OrderBy(x => x))
        {
            if (resultado.Count == 0 ||
                Math.Abs(resultado[resultado.Count - 1] - valor) >
                TolGeometria)
            {
                resultado.Add(valor);
            }
        }

        return resultado;
    }

    private string ClaveIntervalo(double min, double max)
    {
        return Math.Round(min, 6).ToString(CultureInfo.InvariantCulture) +
               "|" +
               Math.Round(max, 6).ToString(CultureInfo.InvariantCulture);
    }

    private bool PuntoDentroPoligono(
        PuntoLocal punto,
        List<PuntoLocal> poligono)
    {
        bool dentro = false;

        for (int i = 0, j = poligono.Count - 1;
             i < poligono.Count;
             j = i++)
        {
            PuntoLocal pi = poligono[i];
            PuntoLocal pj = poligono[j];

            if (DistanciaPuntoSegmento(punto, pj, pi) <= TolGeometria)
                return true;

            bool intersecta =
                ((pi.Y > punto.Y) != (pj.Y > punto.Y)) &&
                (punto.X <
                 (pj.X - pi.X) *
                 (punto.Y - pi.Y) /
                 ((pj.Y - pi.Y) + 1e-20) +
                 pi.X);

            if (intersecta)
                dentro = !dentro;
        }

        return dentro;
    }

    private double DistanciaPuntoSegmento(
        PuntoLocal p,
        PuntoLocal a,
        PuntoLocal b)
    {
        double dx = b.X - a.X;
        double dy = b.Y - a.Y;
        double longitud2 = dx * dx + dy * dy;

        if (longitud2 <= Tol)
            return Distancia(p, a);

        double t =
            ((p.X - a.X) * dx + (p.Y - a.Y) * dy) /
            longitud2;

        t = Math.Max(0.0, Math.Min(1.0, t));

        PuntoLocal proyeccion = new PuntoLocal(
            a.X + t * dx,
            a.Y + t * dy);

        return Distancia(p, proyeccion);
    }

    private PuntoLocal CentroidePoligono(List<PuntoLocal> poligono)
    {
        double areaDoble = 0.0;
        double cx = 0.0;
        double cy = 0.0;

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoLocal a = poligono[i];
            PuntoLocal b = poligono[(i + 1) % poligono.Count];
            double cruz = a.X * b.Y - b.X * a.Y;

            areaDoble += cruz;
            cx += (a.X + b.X) * cruz;
            cy += (a.Y + b.Y) * cruz;
        }

        if (Math.Abs(areaDoble) <= Tol)
        {
            return new PuntoLocal(
                poligono.Average(p => p.X),
                poligono.Average(p => p.Y));
        }

        return new PuntoLocal(
            cx / (3.0 * areaDoble),
            cy / (3.0 * areaDoble));
    }

    private bool ContienePuntoCercano(
        List<PuntoLocal> puntos,
        PuntoLocal punto,
        double tolerancia)
    {
        foreach (PuntoLocal existente in puntos)
        {
            if (Distancia(existente, punto) <= tolerancia)
                return true;
        }

        return false;
    }

    private double Distancia(PuntoLocal a, PuntoLocal b)
    {
        double dx = b.X - a.X;
        double dy = b.Y - a.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    private double AreaFirmada(List<PuntoLocal> puntos)
    {
        double area = 0.0;

        for (int i = 0; i < puntos.Count; i++)
        {
            PuntoLocal a = puntos[i];
            PuntoLocal b = puntos[(i + 1) % puntos.Count];
            area += a.X * b.Y - b.X * a.Y;
        }

        return area / 2.0;
    }

    private double AreaXY(List<XYZ> puntos)
    {
        if (puntos == null || puntos.Count < 3)
            return 0.0;

        double area = 0.0;

        for (int i = 0; i < puntos.Count; i++)
        {
            XYZ a = puntos[i];
            XYZ b = puntos[(i + 1) % puntos.Count];
            area += a.X * b.Y - b.X * a.Y;
        }

        return area / 2.0;
    }

    private XYZ LocalAMundial(
        DatosColumna datos,
        PuntoLocal punto,
        double z)
    {
        return new XYZ(
            datos.Origen.X +
            datos.EjeX.X * punto.X +
            datos.EjeY.X * punto.Y,
            datos.Origen.Y +
            datos.EjeX.Y * punto.X +
            datos.EjeY.Y * punto.Y,
            z);
    }

    private bool TieneContornosValidos(DatosColumna datos)
    {
        return ObtenerContornosValidos(datos).Count > 0;
    }

    private List<List<PuntoLocal>> ObtenerContornosValidos(
        DatosColumna datos)
    {
        List<List<PuntoLocal>> resultado = new List<List<PuntoLocal>>();

        if (datos == null)
            return resultado;

        if (datos.Contornos != null)
        {
            foreach (List<PuntoLocal> region in datos.Contornos)
            {
                if (region != null && region.Count >= 3 &&
                    Math.Abs(AreaFirmada(region)) > TolGeometria)
                {
                    resultado.Add(region);
                }
            }
        }

        if (resultado.Count == 0 && datos.Contorno != null &&
            datos.Contorno.Count >= 3)
        {
            resultado.Add(datos.Contorno);
        }

        return resultado;
    }

    private List<PuntoLocal> ObtenerTodosPuntos(DatosColumna datos)
    {
        List<PuntoLocal> resultado = new List<PuntoLocal>();

        foreach (List<PuntoLocal> region in ObtenerContornosValidos(datos))
            resultado.AddRange(region.Where(x => x != null));

        return resultado;
    }

    private List<List<PuntoLocal>> NormalizarContornosDestino(
        List<List<PuntoLocal>> contornos,
        List<PuntoLocal> contornoPrincipal)
    {
        List<List<PuntoLocal>> resultado = new List<List<PuntoLocal>>();

        if (contornos != null)
        {
            foreach (List<PuntoLocal> region in contornos)
            {
                if (region != null && region.Count >= 3)
                    resultado.Add(region);
            }
        }

        if (resultado.Count == 0 && contornoPrincipal != null &&
            contornoPrincipal.Count >= 3)
        {
            resultado.Add(contornoPrincipal);
        }

        return resultado;
    }

    private bool PuntoDentroDeAlgunaRegion(
        PuntoLocal punto,
        List<List<PuntoLocal>> contornos)
    {
        if (punto == null || contornos == null)
            return false;

        foreach (List<PuntoLocal> region in contornos)
        {
            if (region != null && region.Count >= 3 &&
                PuntoDentroPoligono(punto, region))
            {
                return true;
            }
        }

        return false;
    }

    private List<PuntoLocal> ObtenerContornoAdecuado(
        DatosColumna datos,
        IList<PuntoLocal> puntos)
    {
        List<List<PuntoLocal>> regiones = ObtenerContornosValidos(datos);

        if (regiones.Count == 0)
            return new List<PuntoLocal>();

        if (puntos != null)
        {
            foreach (PuntoLocal punto in puntos)
            {
                if (punto == null)
                    continue;

                foreach (List<PuntoLocal> region in regiones)
                {
                    if (PuntoDentroPoligono(punto, region))
                        return region;
                }
            }
        }

        PuntoLocal referencia = puntos != null
            ? puntos.FirstOrDefault(x => x != null)
            : null;

        if (referencia == null)
            return regiones[0];

        List<PuntoLocal> mejor = regiones[0];
        double mejorDistancia = double.MaxValue;

        foreach (List<PuntoLocal> region in regiones)
        {
            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal proyeccion = ProyectarPuntoSegmento(
                    referencia,
                    region[i],
                    region[(i + 1) % region.Count]);
                double d = Distancia(referencia, proyeccion);

                if (d < mejorDistancia)
                {
                    mejorDistancia = d;
                    mejor = region;
                }
            }
        }

        return mejor;
    }

    private PuntoLocal AjustarPuntoDentroContornos(
        PuntoLocal punto,
        List<List<PuntoLocal>> contornos)
    {
        if (punto == null || contornos == null || contornos.Count == 0)
            return punto;

        foreach (List<PuntoLocal> region in contornos)
        {
            if (region != null && region.Count >= 3 &&
                PuntoDentroPoligono(punto, region))
            {
                return punto;
            }
        }

        PuntoLocal mejor = punto.Copiar();
        double mejorDistancia = double.MaxValue;
        List<PuntoLocal> regionMejor = null;

        foreach (List<PuntoLocal> region in contornos)
        {
            if (region == null || region.Count < 3)
                continue;

            for (int i = 0; i < region.Count; i++)
            {
                PuntoLocal proyeccion = ProyectarPuntoSegmento(
                    punto,
                    region[i],
                    region[(i + 1) % region.Count]);
                double distancia = Distancia(punto, proyeccion);

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejor = proyeccion;
                    regionMejor = region;
                }
            }
        }

        if (regionMejor != null)
        {
            PuntoLocal centro = CentroidePoligono(regionMejor);
            double dx = centro.X - mejor.X;
            double dy = centro.Y - mejor.Y;
            double longitud = Math.Sqrt(dx * dx + dy * dy);

            if (longitud > Tol)
            {
                double nudging = Math.Min(0.001, longitud * 0.05);
                mejor.X += dx / longitud * nudging;
                mejor.Y += dy / longitud * nudging;
            }
        }

        return mejor;
    }

    private List<PuntoLocal> MapearPuntosDelDiseno(
        IList<AceroColumnaPunto2D> puntosDiseno,
        IList<AceroColumnaPunto2D> contornoReferencia,
        List<PuntoLocal> contornoDestino,
        bool ajustarDentro,
        IList<List<AceroColumnaPunto2D>> contornosReferencia = null,
        List<List<PuntoLocal>> contornosDestino = null)
    {
        List<PuntoLocal> resultado = new List<PuntoLocal>();

        List<AceroColumnaPunto2D> referenciaTotal =
            new List<AceroColumnaPunto2D>();

        if (contornosReferencia != null)
        {
            foreach (List<AceroColumnaPunto2D> region in contornosReferencia)
            {
                if (region != null && region.Count >= 3)
                    referenciaTotal.AddRange(region.Where(x => x != null));
            }
        }

        if (referenciaTotal.Count < 3 && contornoReferencia != null)
            referenciaTotal.AddRange(contornoReferencia.Where(x => x != null));

        List<PuntoLocal> destinoTotal = new List<PuntoLocal>();
        List<List<PuntoLocal>> regionesDestino =
            NormalizarContornosDestino(contornosDestino, contornoDestino);

        foreach (List<PuntoLocal> region in regionesDestino)
            destinoTotal.AddRange(region.Where(x => x != null));

        if (puntosDiseno == null || destinoTotal.Count < 3)
            return resultado;

        double refMinX = 0.0;
        double refMaxX = 0.0;
        double refMinY = 0.0;
        double refMaxY = 0.0;
        bool tieneReferencia = referenciaTotal.Count >= 3;

        if (tieneReferencia)
        {
            refMinX = referenciaTotal.Min(p => p.X);
            refMaxX = referenciaTotal.Max(p => p.X);
            refMinY = referenciaTotal.Min(p => p.Y);
            refMaxY = referenciaTotal.Max(p => p.Y);
        }

        double destMinX = destinoTotal.Min(p => p.X);
        double destMaxX = destinoTotal.Max(p => p.X);
        double destMinY = destinoTotal.Min(p => p.Y);
        double destMaxY = destinoTotal.Max(p => p.Y);

        double refAncho = refMaxX - refMinX;
        double refAlto = refMaxY - refMinY;
        double destAncho = destMaxX - destMinX;
        double destAlto = destMaxY - destMinY;

        foreach (AceroColumnaPunto2D p in puntosDiseno)
        {
            if (p == null)
                continue;

            PuntoLocal local;

            if (tieneReferencia &&
                Math.Abs(refAncho) > Tol &&
                Math.Abs(refAlto) > Tol)
            {
                double u = (p.X - refMinX) / refAncho;
                double v = (p.Y - refMinY) / refAlto;

                local = new PuntoLocal(
                    destMinX + u * destAncho,
                    destMinY + v * destAlto);
            }
            else
            {
                local = new PuntoLocal(p.X, p.Y);
            }

            if (ajustarDentro)
                local = AjustarPuntoDentroContornos(local, regionesDestino);

            resultado.Add(local);
        }

        return resultado;
    }

    private PuntoLocal AjustarPuntoDentroPoligono(
        PuntoLocal punto,
        List<PuntoLocal> poligono)
    {
        if (punto == null || poligono == null || poligono.Count < 3)
            return punto;

        if (PuntoDentroPoligono(punto, poligono))
            return punto;

        PuntoLocal mejor = poligono[0].Copiar();
        double mejorDistancia = double.MaxValue;

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoLocal a = poligono[i];
            PuntoLocal b = poligono[(i + 1) % poligono.Count];
            PuntoLocal proyeccion = ProyectarPuntoSegmento(punto, a, b);
            double distancia = Distancia(punto, proyeccion);

            if (distancia < mejorDistancia)
            {
                mejorDistancia = distancia;
                mejor = proyeccion;
            }
        }

        PuntoLocal centro = CentroidePoligono(poligono);
        double dx = centro.X - mejor.X;
        double dy = centro.Y - mejor.Y;
        double longitud = Math.Sqrt(dx * dx + dy * dy);

        if (longitud > Tol)
        {
            double nudging = Math.Min(0.001, longitud * 0.05);
            mejor.X += dx / longitud * nudging;
            mejor.Y += dy / longitud * nudging;
        }

        return mejor;
    }

    private PuntoLocal ProyectarPuntoSegmento(
        PuntoLocal p,
        PuntoLocal a,
        PuntoLocal b)
    {
        double dx = b.X - a.X;
        double dy = b.Y - a.Y;
        double longitud2 = dx * dx + dy * dy;

        if (longitud2 <= Tol)
            return a.Copiar();

        double t =
            ((p.X - a.X) * dx + (p.Y - a.Y) * dy) /
            longitud2;

        t = Math.Max(0.0, Math.Min(1.0, t));

        return new PuntoLocal(
            a.X + t * dx,
            a.Y + t * dy);
    }

    private AceroColumnaVistaSeccion CrearVistaSeccion(
        DatosColumna datos)
    {
        List<List<PuntoLocal>> regiones = ObtenerContornosValidos(datos);
        RectanguloLocal caja = ObtenerCaja(ObtenerTodosPuntos(datos));

        string dimensiones = "";

        if (caja != null)
        {
            double anchoCm = UnitUtils.ConvertFromInternalUnits(
                caja.Ancho,
                UnitTypeId.Centimeters);

            double altoCm = UnitUtils.ConvertFromInternalUnits(
                caja.Alto,
                UnitTypeId.Centimeters);

            dimensiones =
                anchoCm.ToString("0.#", CultureInfo.InvariantCulture) +
                " x " +
                altoCm.ToString("0.#", CultureInfo.InvariantCulture) +
                " cm";

            if (regiones.Count > 1)
                dimensiones += "  |  " + regiones.Count + " regiones";
        }

        string nombreTipo = "Columna";

        if (datos.Columna.Symbol != null)
        {
            nombreTipo =
                datos.Columna.Symbol.FamilyName +
                " : " +
                datos.Columna.Symbol.Name;
        }

        AceroColumnaVistaSeccion vista = new AceroColumnaVistaSeccion
        {
            NombreTipo = nombreTipo,
            Dimensiones = dimensiones
        };

        foreach (List<PuntoLocal> region in regiones)
        {
            List<AceroColumnaPunto2D> regionVista = region
                .Select(p => new AceroColumnaPunto2D(p.X, p.Y))
                .ToList();

            vista.Contornos.Add(regionVista);
        }

        if (vista.Contornos.Count > 0)
        {
            vista.Contorno = vista.Contornos[0]
                .Select(p => p.Copiar())
                .ToList();
        }

        return vista;
    }

    // ==========================================
    // ELIMINAR ELEMENTO DE FORMA SEGURA
    // Se utiliza para retirar piezas temporales o
    // candidatos de empalme que no cumplen la longitud.
    // ==========================================
    private void EliminarElementoSeguro(
        Document doc,
        ElementId id)
    {
        if (doc == null ||
            id == null ||
            id == ElementId.InvalidElementId)
        {
            return;
        }

        try
        {
            // Evita llamar Delete sobre un identificador que ya fue
            // eliminado o revertido por una SubTransaction.
            if (doc.GetElement(id) != null)
                doc.Delete(id);
        }
        catch
        {
            // La limpieza de candidatos no debe interrumpir la creación
            // del resto de las barras longitudinales.
        }
    }

    private string DescribirColumna(
        Document doc,
        FamilyInstance columna)
    {
        string familia = columna.Symbol != null
            ? columna.Symbol.FamilyName
            : "Columna";

        string tipo = columna.Symbol != null
            ? columna.Symbol.Name
            : "Sin tipo";

        string nivelBase = ObtenerNombreNivel(
            doc,
            columna.get_Parameter(
                BuiltInParameter.FAMILY_BASE_LEVEL_PARAM));

        string nivelSuperior = ObtenerNombreNivel(
            doc,
            columna.get_Parameter(
                BuiltInParameter.FAMILY_TOP_LEVEL_PARAM));

        return
            "ID " + columna.Id.Value.ToString().PadRight(9) +
            " | " + familia + " : " + tipo +
            " | " + nivelBase + " → " + nivelSuperior;
    }

    private string ObtenerNombreNivel(
        Document doc,
        Parameter parametro)
    {
        if (parametro == null ||
            parametro.StorageType != StorageType.ElementId)
        {
            return "Sin nivel";
        }

        ElementId id = parametro.AsElementId();

        if (id == null || id == ElementId.InvalidElementId)
            return "Sin nivel";

        Level nivel = doc.GetElement(id) as Level;
        return nivel != null ? nivel.Name : "Sin nivel";
    }

    private double ObtenerDiametroBarra(RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        Parameter parametro =
            tipo.get_Parameter(
                BuiltInParameter.REBAR_BAR_DIAMETER);

        if (parametro != null &&
            parametro.StorageType == StorageType.Double)
        {
            return parametro.AsDouble();
        }

        parametro = tipo.LookupParameter("Diámetro de barra");

        if (parametro != null &&
            parametro.StorageType == StorageType.Double)
        {
            return parametro.AsDouble();
        }

        parametro = tipo.LookupParameter("Bar Diameter");

        if (parametro != null &&
            parametro.StorageType == StorageType.Double)
        {
            return parametro.AsDouble();
        }

        return 0.0;
    }

    private double ObtenerDiametroModeloBarra(RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        try
        {
            if (tipo.BarModelDiameter > Tol)
                return tipo.BarModelDiameter;
        }
        catch
        {
        }

        return ObtenerDiametroBarra(tipo);
    }

    private double ObtenerRadioDobladoEjeEstribo(RebarBarType tipo)
    {
        if (tipo == null)
            return TolGeometria;

        double diametroModelo = ObtenerDiametroModeloBarra(tipo);
        double diametroDobladoInterior = 0.0;

        try
        {
            diametroDobladoInterior = tipo.StirrupTieBendDiameter;
        }
        catch
        {
        }

        if (diametroDobladoInterior <= TolGeometria)
        {
            Parameter parametro = tipo.get_Parameter(
                BuiltInParameter.REBAR_BAR_STIRRUP_BEND_DIAMETER);

            if (parametro != null &&
                parametro.StorageType == StorageType.Double)
            {
                diametroDobladoInterior = parametro.AsDouble();
            }
        }

        if (diametroDobladoInterior <= TolGeometria)
        {
            // Respaldo solo para tipos sin el parámetro configurado.
            diametroDobladoInterior = diametroModelo * 4.0;
        }

        return Math.Max(
            diametroDobladoInterior * 0.5 +
            diametroModelo * 0.5,
            TolGeometria);
    }


    // =========================================================
    // TEXTO DE DISTRIBUCIÓN PARA COMENTARIOS DE ESTRIBOS
    // Ejemplo:
    // Est. 2@0.05, 3@0.10, rto. @0.20 a/e
    // =========================================================
    private string ObtenerTextoDistribucionEstribosMYG(
        AceroColumnaConfiguracion configuracion,
        ZonaEstribos zona,
        AceroColumnaEstribo2D definicion = null)
    {
        if (configuracion == null)
            return "";

        int tipoDistribucion;
        double[] separacionesCm;
        int[] cantidades;

        string nombreZona = zona != null
            ? (zona.Nombre ?? "")
            : "";

        bool esNodo =
            nombreZona.IndexOf(
                "NODO",
                StringComparison.OrdinalIgnoreCase) >= 0;

        if (configuracion.UsarDistribucionNodoEntrepiso)
        {
            if (esNodo)
            {
                tipoDistribucion =
                    configuracion.TipoDistribucionEstribosNodo;
                separacionesCm =
                    configuracion.SeparacionesDistribucionEstribosNodoCm;
                cantidades =
                    configuracion.CantidadesDistribucionEstribosNodo;
            }
            else
            {
                tipoDistribucion =
                    configuracion.TipoDistribucionEstribosEntrepiso;
                separacionesCm =
                    configuracion.SeparacionesDistribucionEstribosEntrepisoCm;
                cantidades =
                    configuracion.CantidadesDistribucionEstribosEntrepiso;

                // Si este estribo tiene una distribución personalizada para
                // ENTREPISO, esa configuración es la que debe aparecer.
                if (definicion != null &&
                    definicion.UsarDistribucionEntrepisoPersonalizada)
                {
                    tipoDistribucion = System.Math.Max(
                        1,
                        System.Math.Min(
                            4,
                            definicion.TipoDistribucionEntrepiso));

                    separacionesCm =
                        definicion.SeparacionesEntrepisoCm;
                    cantidades =
                        definicion.CantidadesEntrepiso;
                }
            }
        }
        else
        {
            tipoDistribucion =
                configuracion.TipoDistribucionEstribos;
            separacionesCm =
                configuracion.SeparacionesDistribucionEstribosCm;
            cantidades =
                configuracion.CantidadesDistribucionEstribos;
        }

        return FormatearDistribucionEstribosMYG(
            tipoDistribucion,
            separacionesCm,
            cantidades);
    }

    private string FormatearDistribucionEstribosMYG(
        int tipoDistribucion,
        double[] separacionesCm,
        int[] cantidades)
    {
        int n = System.Math.Max(
            1,
            System.Math.Min(4, tipoDistribucion));

        List<string> partes = new List<string>();

        // En distribuciones de 2, 3 o 4 tramos, todas las filas anteriores
        // a la última son cantidades fijas tomadas a ambos extremos.
        for (int i = 0; i < n - 1; i++)
        {
            int cantidad =
                cantidades != null && i < cantidades.Length
                    ? cantidades[i]
                    : 0;

            double separacionCm =
                separacionesCm != null && i < separacionesCm.Length
                    ? separacionesCm[i]
                    : 0.0;

            if (cantidad <= 0 || separacionCm <= 0.0)
                continue;

            partes.Add(
                cantidad.ToString(
                    CultureInfo.InvariantCulture) +
                "@" +
                FormatearSeparacionMetrosMYG(separacionCm));
        }

        // La última fila siempre representa TOTAL/RESTO con espaciamiento máximo.
        int indiceResto = n - 1;
        double separacionRestoCm =
            separacionesCm != null &&
            indiceResto < separacionesCm.Length
                ? separacionesCm[indiceResto]
                : 0.0;

        if (separacionRestoCm > 0.0)
        {
            partes.Add(
                "rto. @" +
                FormatearSeparacionMetrosMYG(
                    separacionRestoCm) +
                " a/e");
        }

        if (partes.Count == 0)
            return "Est.";

        return "Est. " + string.Join(", ", partes);
    }

    private string FormatearSeparacionMetrosMYG(double valorCm)
    {
        double valorM = valorCm / 100.0;

        // Se usa punto decimal de forma intencional para que el texto quede
        // exactamente con el formato habitual de planos estructurales:
        // 0.05, 0.10, 0.20, etc.
        return valorM.ToString(
            "0.00",
            CultureInfo.InvariantCulture);
    }


    private void CompletarParametros(
        Rebar rebar,
        Element host,
        string tipoAcero,
        string prefijoMarca,
        string comentarioPersonalizado = null)
    {
        if (rebar == null)
            return;

        Document doc = rebar.Document;
        string clasificacion = ObtenerClasificacionAceroMYG(tipoAcero, prefijoMarca);
        string descripcionHost = ObtenerDescripcionTipoHostMYG(host);
        string ubicacionHost = ObtenerValorParametroMYG(
            host, "STR_Ubicación", "STR_Ubicacion", "STR Ubicación", "STR Ubicacion");
        string nivelHost = ObtenerValorParametroMYG(
            host, "GEN_Nivel", "GEN Nivel");

        Parameter comentarios = rebar.get_Parameter(
            BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

        if (comentarios != null && !comentarios.IsReadOnly)
        {
            string textoComentarios =
                !string.IsNullOrWhiteSpace(comentarioPersonalizado)
                    ? comentarioPersonalizado
                    : (tipoAcero ?? "");

            TrySetParametroMYG(comentarios, textoComentarios, doc);
        }

        Parameter marca = rebar.get_Parameter(
            BuiltInParameter.ALL_MODEL_MARK);

        if (marca != null && !marca.IsReadOnly)
        {
            string idHost = host != null
                ? host.Id.Value.ToString()
                : "SIN-HOST";

            TrySetParametroMYG(
                marca,
                (prefijoMarca ?? "ACERO") + "-" + idHost,
                doc);
        }

        AsignarTodosMYG(
            rebar,
            new string[] { "EST_Tipo Refuerzo" },
            tipoAcero ?? "");

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_AnfitriónAcero",
                "STR_AnfitrionAcero",
                "STR_Anfitrión Acero",
                "STR_Anfitrion Acero"
            },
            descripcionHost);

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_Materialidad",
                "STR Materialidad"
            },
            "Acero corrugado");

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_Resistencia",
                "STR Resistencia"
            },
            "F'c=4200 kg/cm²");

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_TipoDeElemento (V/H)",
                "STR_TipoDeElemento",
                "STR TipoDeElemento (V/H)",
                "STR TipoDeElemento"
            },
            clasificacion);

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_Ubicación",
                "STR_Ubicacion",
                "STR Ubicación",
                "STR Ubicacion"
            },
            ubicacionHost);

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "GEN_Disciplina",
                "GEN Disciplina"
            },
            "Estructuras");

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "GEN_ID Elemento",
                "GEN_IDElemento",
                "GEN ID Elemento"
            },
            rebar.Id.Value.ToString());

        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "GEN_Nivel",
                "GEN Nivel"
            },
            nivelHost);
    }

    private string ObtenerClasificacionAceroMYG(
        string tipoAcero,
        string prefijoMarca)
    {
        string texto = ((tipoAcero ?? "") + " " +
                        (prefijoMarca ?? "")).ToUpperInvariant();

        string zona = texto.Contains("NODO")
            ? "Nodo"
            : "Entrepiso";

        if (texto.Contains("HORIZONTAL") && texto.Contains("ALMA"))
            return "Horizontal de alma - " + zona;

        if (texto.Contains("VERTICAL") && texto.Contains("ALMA"))
            return "Vertical de alma - " + zona;

        if (texto.Contains("ESTRIBO") ||
            texto.Contains("TRABA") ||
            texto.Contains("GANCHO"))
        {
            return tieneElementosBordeActualMYG
                ? "Estribo de elemento de borde - " + zona
                : "Estribo - " + zona;
        }

        if (texto.Contains("LONGITUDINAL"))
        {
            return tieneElementosBordeActualMYG
                ? "Longitudinal de elemento de borde - " + zona
                : "Longitudinal - " + zona;
        }

        return (tipoAcero ?? "").Trim();
    }

    private string ObtenerDescripcionTipoHostMYG(Element host)
    {
        if (host == null || host.Document == null)
            return "";

        try
        {
            ElementId tipoId = host.GetTypeId();
            if (tipoId == null || tipoId == ElementId.InvalidElementId)
                return "";

            Element tipo = host.Document.GetElement(tipoId);
            if (tipo == null)
                return "";

            string descripcion = ObtenerValorParametroMYG(
                tipo,
                "Descripción",
                "Descripcion",
                "Description",
                "Descripción de la cimentación",
                "Descripcion de la cimentacion");

            if (!string.IsNullOrWhiteSpace(descripcion))
                return descripcion.Trim();

            return tipo.Name ?? "";
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerValorParametroMYG(
        Element elemento,
        params string[] nombres)
    {
        if (elemento == null || nombres == null)
            return "";

        HashSet<string> buscados = new HashSet<string>(
            nombres.Where(x => !string.IsNullOrWhiteSpace(x)),
            StringComparer.OrdinalIgnoreCase);

        foreach (Parameter p in elemento.Parameters)
        {
            if (p == null || p.Definition == null)
                continue;

            if (!buscados.Contains(p.Definition.Name))
                continue;

            string valor = "";

            try
            {
                valor = p.AsValueString();
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(valor))
            {
                try
                {
                    if (p.StorageType == StorageType.String)
                        valor = p.AsString();
                    else if (p.StorageType == StorageType.Integer)
                        valor = p.AsInteger().ToString();
                    else if (p.StorageType == StorageType.Double)
                        valor = p.AsDouble().ToString(
                            System.Globalization.CultureInfo.InvariantCulture);
                    else if (p.StorageType == StorageType.ElementId)
                        valor = p.AsElementId().Value.ToString();
                }
                catch
                {
                    valor = "";
                }
            }

            if (!string.IsNullOrWhiteSpace(valor))
                return valor.Trim();
        }

        return "";
    }

    private void AsignarTodosMYG(
        Element elemento,
        IEnumerable<string> nombres,
        string valor)
    {
        if (elemento == null || nombres == null)
            return;

        HashSet<string> buscados = new HashSet<string>(
            nombres.Where(x => !string.IsNullOrWhiteSpace(x)),
            StringComparer.OrdinalIgnoreCase);

        foreach (Parameter p in elemento.Parameters)
        {
            if (p == null ||
                p.Definition == null ||
                p.IsReadOnly ||
                !buscados.Contains(p.Definition.Name))
            {
                continue;
            }

            TrySetParametroMYG(
                p,
                valor ?? "",
                elemento.Document);
        }
    }

    private bool TrySetParametroMYG(
        Parameter parametro,
        string valor,
        Document doc)
    {
        if (parametro == null || parametro.IsReadOnly)
            return false;

        try
        {
            if (parametro.StorageType == StorageType.String)
                return parametro.Set(valor ?? "");

            if (parametro.StorageType == StorageType.Integer)
            {
                int entero;
                return int.TryParse(valor, out entero) &&
                       parametro.Set(entero);
            }

            if (parametro.StorageType == StorageType.Double)
            {
                double numero;

                if (double.TryParse(
                    valor,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.CurrentCulture,
                    out numero) ||
                    double.TryParse(
                    valor,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out numero))
                {
                    return parametro.Set(numero);
                }

                try
                {
                    return parametro.SetValueString(valor);
                }
                catch
                {
                    return false;
                }
            }

            if (parametro.StorageType == StorageType.ElementId)
            {
                long id;
                return long.TryParse(valor, out id) &&
                       parametro.Set(new ElementId(id));
            }
        }
        catch
        {
        }

        return false;
    }

    private double ConvertirCm(double valorCm)
    {
        return UnitUtils.ConvertToInternalUnits(
            valorCm,
            UnitTypeId.Centimeters);
    }

    private double ConvertirMetros(double valorM)
    {
        return UnitUtils.ConvertToInternalUnits(
            valorM,
            UnitTypeId.Meters);
    }

    public string GetName()
    {
        return "MYG - Acero longitudinal y estribos en columnas";
    }
}
