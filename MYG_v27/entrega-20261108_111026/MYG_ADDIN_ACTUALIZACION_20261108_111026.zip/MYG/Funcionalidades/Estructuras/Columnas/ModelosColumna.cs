using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // ==========================================
    // VENTANA 3.7 - ACERO EN COLUMNAS | ALMA OFFSET 2 PULGADAS
    // SIN USING NI NAMESPACE
    // EDITOR DINÁMICO 2D + OSNAP + CTRL+Z + SUPR
    // GANCHOS 135° POLIGONALES Y GANCHOS 90° EN ESTRIBOS CIRCULARES
    // ==========================================


    #region TIPOS Y MODELOS AUXILIARES (PLEGAR TODO AQUÍ)

    internal class AceroColumnaPunto2D
    {
        public double X { get; set; }
        public double Y { get; set; }

        public AceroColumnaPunto2D()
        {
        }

        public AceroColumnaPunto2D(double x, double y)
        {
            X = x;
            Y = y;
        }

        public AceroColumnaPunto2D Copiar()
        {
            return new AceroColumnaPunto2D(X, Y);
        }
    }

    internal class AceroColumnaVistaSeccion
    {
        // Región principal (la de mayor área). Se conserva para compatibilidad
        // con diseños y rutinas anteriores.
        public System.Collections.Generic.List<AceroColumnaPunto2D> Contorno
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaPunto2D>();

        // Todas las regiones desconectadas que forman la sección de la familia.
        // Cada lista es un polígono independiente y nunca se conecta con otra.
        public System.Collections.Generic.List<
            System.Collections.Generic.List<AceroColumnaPunto2D>> Contornos
        { get; set; } =
            new System.Collections.Generic.List<
                System.Collections.Generic.List<AceroColumnaPunto2D>>();

        public string NombreTipo { get; set; } = "";
        public string Dimensiones { get; set; } = "";
    }

    internal enum AceroColumnaTipoEstribo2D
    {
        Rectangular,
        Rombo,
        CuadrilateroLibre,
        AdaptadoContorno,
        Croquis,
        TrabaC,
        TrabaS,
        // Compatibilidad con diseños guardados de versiones anteriores.
        TrabaGancho,
        // Se agrega al final para conservar los valores numéricos de las
        // versiones anteriores de la data guardada.
        HorizontalAlma,
        // Estribo circular real. Se mantiene al final para no modificar los
        // valores numéricos de las datas anteriores.
        Circular
    }

    internal class AceroColumnaEstribo2D
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString("N");
        public AceroColumnaTipoEstribo2D Tipo { get; set; }
        public bool Cerrado { get; set; }

        // Cada recorrido conserva el tipo con el que fue creado. Cambiar el
        // desplegable solo afecta a los recorridos nuevos.
        public Autodesk.Revit.DB.Structure.RebarBarType TipoBarra { get; set; }
        public double DiametroPies { get; set; }

        // Esquina donde el recorrido queda completamente cerrado y se
        // aplican terminaciones de 135° en polígonos y de 90° en circulares.
        // -1 permite calcular automáticamente la esquina superior derecha.
        public int IndiceEsquinaGancho { get; set; } = -1;

        // Perfil opcional aplicado únicamente en las zonas de ENTREPISO.
        // Las zonas de NODO siempre conservan el perfil global configurado
        // en la pestaña Stirrups.
        public bool UsarDistribucionEntrepisoPersonalizada { get; set; }
        public int TipoDistribucionEntrepiso { get; set; } = 2;
        public double[] SeparacionesEntrepisoCm { get; set; } =
            new double[] { 10.0, 20.0, 20.0, 20.0 };
        public int[] CantidadesEntrepiso { get; set; } =
            new int[] { 6, 0, 0, 0 };

        public System.Collections.Generic.List<AceroColumnaPunto2D> Puntos
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaPunto2D>();

        public AceroColumnaEstribo2D Copiar()
        {
            AceroColumnaEstribo2D copia = new AceroColumnaEstribo2D
            {
                Id = Id,
                Tipo = Tipo,
                Cerrado = Cerrado,
                TipoBarra = TipoBarra,
                DiametroPies = DiametroPies,
                IndiceEsquinaGancho = IndiceEsquinaGancho,
                UsarDistribucionEntrepisoPersonalizada =
                    UsarDistribucionEntrepisoPersonalizada,
                TipoDistribucionEntrepiso = TipoDistribucionEntrepiso,
                SeparacionesEntrepisoCm = SeparacionesEntrepisoCm != null
                    ? (double[])SeparacionesEntrepisoCm.Clone()
                    : new double[] { 10.0, 20.0, 20.0, 20.0 },
                CantidadesEntrepiso = CantidadesEntrepiso != null
                    ? (int[])CantidadesEntrepiso.Clone()
                    : new int[] { 6, 0, 0, 0 }
            };

            foreach (AceroColumnaPunto2D p in Puntos)
                copia.Puntos.Add(p.Copiar());

            return copia;
        }
    }

    internal enum AceroColumnaTipoElementoBorde2D
    {
        Rectangular,
        TipoL,
        TipoT,
        Libre
    }

    internal enum AceroColumnaTipoCotaElementoBorde2D
    {
        AnchoTotal,
        AltoTotal,
        EspesorHorizontal,
        EspesorVertical,
        AnchoAlma,
        EspesorAla
    }

    internal class AceroColumnaElementoBorde2D
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString("N");
        public AceroColumnaTipoElementoBorde2D Tipo { get; set; }
        public double CentroX { get; set; }
        public double CentroY { get; set; }
        public double Ancho { get; set; }
        public double Alto { get; set; }
        public double EspesorHorizontal { get; set; }
        public double EspesorVertical { get; set; }
        public double AnchoAlma { get; set; }
        public double EspesorAla { get; set; }

        // Para elementos de borde LIBRES los vértices se almacenan en
        // coordenadas locales respecto de CentroX/CentroY. Así el elemento puede
        // moverse, copiarse y deshacerse con la misma lógica de los tipos
        // paramétricos, sin crear geometría en Revit.
        public System.Collections.Generic.List<AceroColumnaPunto2D> PuntosLibres
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaPunto2D>();

        public AceroColumnaElementoBorde2D Copiar()
        {
            AceroColumnaElementoBorde2D copia = new AceroColumnaElementoBorde2D
            {
                Id = Id,
                Tipo = Tipo,
                CentroX = CentroX,
                CentroY = CentroY,
                Ancho = Ancho,
                Alto = Alto,
                EspesorHorizontal = EspesorHorizontal,
                EspesorVertical = EspesorVertical,
                AnchoAlma = AnchoAlma,
                EspesorAla = EspesorAla
            };

            foreach (AceroColumnaPunto2D p in PuntosLibres)
                copia.PuntosLibres.Add(p.Copiar());

            return copia;
        }
    }

    internal class AceroColumnaHitCotaElementoBorde2D
    {
        public int IndiceElemento { get; set; }
        public AceroColumnaTipoCotaElementoBorde2D TipoCota { get; set; }
        public System.Drawing.RectangleF Caja { get; set; }
    }

    internal class AceroColumnaBarraLongitudinal2D
    {
        public AceroColumnaPunto2D Punto { get; set; } =
            new AceroColumnaPunto2D();

        public Autodesk.Revit.DB.Structure.RebarBarType TipoBarra { get; set; }
        public double DiametroPies { get; set; }

        public AceroColumnaBarraLongitudinal2D Copiar()
        {
            return new AceroColumnaBarraLongitudinal2D
            {
                Punto = Punto != null ? Punto.Copiar() : null,
                TipoBarra = TipoBarra,
                DiametroPies = DiametroPies
            };
        }
    }


    internal enum AceroColumnaReglaGrupoLongitudinal
    {
        EspaciadoMaximo = 0,
        NumeroConEspaciado = 1,
        NumeroFijo = 2
    }

    internal class AceroColumnaGrupoLongitudinal2D
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString("N");

        public AceroColumnaPunto2D PuntoInicio { get; set; } =
            new AceroColumnaPunto2D();

        public AceroColumnaPunto2D PuntoFin { get; set; } =
            new AceroColumnaPunto2D();

        public Autodesk.Revit.DB.Structure.RebarBarType TipoBarra { get; set; }
        public double DiametroPies { get; set; }

        public AceroColumnaReglaGrupoLongitudinal Regla { get; set; } =
            AceroColumnaReglaGrupoLongitudinal.NumeroFijo;

        // Se conserva en centímetros para que el valor mostrado al usuario
        // coincida exactamente con el que se envía al handler.
        public double EspaciadoCm { get; set; } = 20.0;
        public int Cantidad { get; set; } = 4;

        // Un grupo circular se conserva paramétrico dentro de la ventana,
        // aunque Revit materialice sus posiciones como barras individuales.
        public bool EsCircular { get; set; } = false;

        public AceroColumnaPunto2D CentroCircular { get; set; } =
            new AceroColumnaPunto2D();

        public double RadioCircularPies { get; set; } = 0.0;

        public double AnguloInicialRadianes { get; set; } = 0.0;

        // Se calculan automáticamente según los aceros ya existentes. No son
        // preferencias del usuario: representan posiciones de extremo que no
        // deben materializarse porque coinciden con otra barra longitudinal.
        public bool OmitirPrimeraBarra { get; set; } = false;
        public bool OmitirUltimaBarra { get; set; } = false;

        public AceroColumnaGrupoLongitudinal2D Copiar()
        {
            return new AceroColumnaGrupoLongitudinal2D
            {
                Id = Id,
                PuntoInicio = PuntoInicio != null ? PuntoInicio.Copiar() : null,
                PuntoFin = PuntoFin != null ? PuntoFin.Copiar() : null,
                TipoBarra = TipoBarra,
                DiametroPies = DiametroPies,
                Regla = Regla,
                EspaciadoCm = EspaciadoCm,
                Cantidad = Cantidad,
                EsCircular = EsCircular,
                CentroCircular = CentroCircular != null
                    ? CentroCircular.Copiar()
                    : null,
                RadioCircularPies = RadioCircularPies,
                AnguloInicialRadianes = AnguloInicialRadianes,
                OmitirPrimeraBarra = OmitirPrimeraBarra,
                OmitirUltimaBarra = OmitirUltimaBarra
            };
        }
    }


    internal sealed class AceroColumnaConfiguracionNodosForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.CheckBox chkVigas;
        private System.Windows.Forms.CheckBox chkLosas;
        private System.Windows.Forms.CheckBox chkNiveles;
        private System.Windows.Forms.NumericUpDown nudExtensionInferior;
        private System.Windows.Forms.NumericUpDown nudExtensionSuperior;
        private System.Windows.Forms.NumericUpDown nudNivelInferior;
        private System.Windows.Forms.NumericUpDown nudNivelSuperior;

        public bool DetectarVigas { get { return chkVigas.Checked; } }
        public bool DetectarLosas { get { return chkLosas != null && chkLosas.Checked; } }
        public bool UsarNivelesRespaldo { get { return false; } }
        public double ExtensionInferiorCm { get { return (double)nudExtensionInferior.Value; } }
        public double ExtensionSuperiorCm { get { return (double)nudExtensionSuperior.Value; } }
        public double AlturaNivelInferiorCm { get { return (double)nudNivelInferior.Value; } }
        public double AlturaNivelSuperiorCm { get { return (double)nudNivelSuperior.Value; } }

        public AceroColumnaConfiguracionNodosForm(
            bool detectarVigas,
            bool detectarLosas,
            bool usarNiveles,
            double extensionInferiorCm,
            double extensionSuperiorCm,
            double alturaNivelInferiorCm,
            double alturaNivelSuperiorCm)
        {
            Text = "MYG - Detección de nodos";
            Width = 530;
            Height = 350;
            StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = System.Drawing.Color.FromArgb(247, 248, 250);
            Font = new System.Drawing.Font("Segoe UI", 9F);

            System.Windows.Forms.Label titulo = new System.Windows.Forms.Label
            {
                Text = "DETECCIÓN AUTOMÁTICA DE ZONAS DE NODO",
                Left = 20,
                Top = 18,
                Width = 450,
                Height = 26,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(0, 90, 160)
            };

            System.Windows.Forms.Label ayuda = new System.Windows.Forms.Label
            {
                Text = "Detección exclusiva por geometría: 1) viga estructural pegada o separada hasta 1 cm; 2) si no hay viga en ese encuentro, suelo. Si no existe ninguno, el rango se mantiene como ENTREPISO.",
                Left = 24,
                Top = 52,
                Width = 462,
                Height = 56,
                ForeColor = System.Drawing.Color.FromArgb(75, 75, 75)
            };

            chkVigas = new System.Windows.Forms.CheckBox
            {
                Text = "1. Detectar vigas estructurales con tolerancia de contacto de 1 cm",
                Left = 35,
                Top = 112,
                Width = 460,
                Height = 24,
                Checked = detectarVigas
            };
            chkLosas = new System.Windows.Forms.CheckBox
            {
                Text = "2. Si no hay viga en ese encuentro, detectar suelos",
                Left = 35,
                Top = 142,
                Width = 460,
                Height = 24,
                Checked = detectarLosas
            };
            // Se conserva el control interno solo por compatibilidad binaria y
            // de data. La detección por niveles queda desactivada permanentemente.
            chkNiveles = new System.Windows.Forms.CheckBox
            {
                Checked = false,
                Visible = false
            };

            System.Windows.Forms.GroupBox grpReal = new System.Windows.Forms.GroupBox
            {
                Text = "Extensión adicional de nodos detectados por viga o suelo",
                Left = 24,
                Top = 178,
                Width = 442,
                Height = 78
            };
            grpReal.Controls.Add(new System.Windows.Forms.Label { Text = "Inferior:", Left = 20, Top = 33, Width = 60 });
            nudExtensionInferior = CrearNumerico(extensionInferiorCm, 82, 29);
            grpReal.Controls.Add(nudExtensionInferior);
            grpReal.Controls.Add(new System.Windows.Forms.Label { Text = "cm", Left = 150, Top = 33, Width = 30 });
            grpReal.Controls.Add(new System.Windows.Forms.Label { Text = "Superior:", Left = 225, Top = 33, Width = 65 });
            nudExtensionSuperior = CrearNumerico(extensionSuperiorCm, 292, 29);
            grpReal.Controls.Add(nudExtensionSuperior);
            grpReal.Controls.Add(new System.Windows.Forms.Label { Text = "cm", Left = 360, Top = 33, Width = 30 });

            // Campos legacy: se inicializan para poder leer datas antiguas, pero
            // no se muestran ni intervienen en la detección actual.
            nudNivelInferior = CrearNumerico(alturaNivelInferiorCm, 0, 0);
            nudNivelSuperior = CrearNumerico(alturaNivelSuperiorCm, 0, 0);

            System.Windows.Forms.Button aceptar = new System.Windows.Forms.Button
            {
                Text = "ACEPTAR",
                Left = 288,
                Top = 270,
                Width = 96,
                Height = 30,
                DialogResult = System.Windows.Forms.DialogResult.OK,
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat
            };
            aceptar.FlatAppearance.BorderSize = 0;
            System.Windows.Forms.Button cancelar = new System.Windows.Forms.Button
            {
                Text = "CANCELAR",
                Left = 390,
                Top = 270,
                Width = 96,
                Height = 30,
                DialogResult = System.Windows.Forms.DialogResult.Cancel
            };

            Controls.Add(titulo);
            Controls.Add(ayuda);
            Controls.Add(chkVigas);
            Controls.Add(chkLosas);
            Controls.Add(grpReal);
            Controls.Add(aceptar);
            Controls.Add(cancelar);
            AcceptButton = aceptar;
            CancelButton = cancelar;
        }

        private System.Windows.Forms.NumericUpDown CrearNumerico(double valor, int left, int top)
        {
            decimal v = (decimal)System.Math.Max(0.0, System.Math.Min(300.0, valor));
            return new System.Windows.Forms.NumericUpDown
            {
                Left = left,
                Top = top,
                Width = 64,
                Height = 23,
                Minimum = 0,
                Maximum = 300,
                DecimalPlaces = 0,
                Increment = 1,
                Value = v,
                TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            };
        }
    }

    internal class AceroColumnaConfiguracion
    {
        public Autodesk.Revit.DB.Structure.RebarBarType TipoLongitudinal
        { get; set; }

        public Autodesk.Revit.DB.Structure.RebarBarType TipoEstribo
        { get; set; }

        public Autodesk.Revit.DB.Structure.RebarHookType TipoGanchoEstribo
        { get; set; }

        public bool CrearLongitudinales { get; set; }
        public bool CrearEstribos { get; set; }
        public bool CompletarParametros { get; set; }
        public bool ProcesarPorNivel { get; set; }
        public bool UsarDisenoManual { get; set; }

        // TRUE únicamente cuando el usuario dibujó una o más regiones gráficas
        // de elemento de borde en la ventana.
        public bool TieneElementosBorde { get; set; }

        public double RecubrimientoCm { get; set; }

        // Tipo de recubrimiento nativo seleccionado en Revit. El handler lo
        // asigna a Cara superior, Cara inferior y Otras caras del anfitrión.
        public Autodesk.Revit.DB.ElementId RecubrimientoTipoId { get; set; } =
            Autodesk.Revit.DB.ElementId.InvalidElementId;

        public double SeparacionMaximaLongitudinalCm { get; set; }
        public double AnclajeInferiorCm { get; set; }
        public double ProlongacionSuperiorCm { get; set; }

        // Empalmes longitudinales con quiebre. La longitud comercial y el
        // traslape se ingresan en metros; el desfase lateral y la longitud del
        // quiebre se calculan automáticamente según el diámetro de cada barra.
        public bool ConsiderarEmpalmesLongitudinales { get; set; }
        public bool UbicarEmpalmesMitadCentralE060 { get; set; }
        public double LongitudComercialLongitudinalM { get; set; }
        public double LongitudEmpalmeLongitudinalM { get; set; }

        // Cálculo automático del traslape según los parámetros indicados para
        // RNE E.060. El handler calcula la longitud individualmente para cada
        // tipo/diámetro longitudinal, por lo que un mismo diseño puede contener
        // barras de diámetros diferentes sin usar una longitud global incorrecta.
        public bool UsarCalculoRneEmpalme { get; set; }
        public double RneFcKgCm2 { get; set; } = 210.0;
        public double RneFyMpa { get; set; } = 420.0;
        public double RnePsiT { get; set; } = 1.0;
        public double RnePsiE { get; set; } = 1.0;
        public double RneLambda { get; set; } = 1.0;
        public double RneFactorClaseEmpalme { get; set; } = 1.30;
        public double RneLongitudMinimaMm { get; set; } = 300.0;
        public bool RneCondicionesTabla121 { get; set; } = true;
        public double RneRedondeoSuperiorMm { get; set; } = 50.0;

        public double LongitudZonaConfinadaCm { get; set; }
        public double EspaciamientoConfinadoCm { get; set; }
        public double EspaciamientoCentralCm { get; set; }

        // Distribución vertical editable de estribos, equivalente a la usada en
        // el módulo de vigas. Tipo 1 = separación constante. En tipos 2 a 4,
        // las primeras filas se aplican simétricamente desde ambos extremos y
        // la última fila corresponde al RESTO central con espaciamiento máximo.
        public int TipoDistribucionEstribos { get; set; } = 2;
        public double[] SeparacionesDistribucionEstribosCm { get; set; } =
            new double[] { 10.0, 20.0, 20.0, 20.0 };
        public int[] CantidadesDistribucionEstribos { get; set; } =
            new int[] { 6, 0, 0, 0 };


        // Distribución diferenciada entre zonas de nodo y entrepiso.
        public bool UsarDistribucionNodoEntrepiso { get; set; }
        public bool DetectarNodosPorVigas { get; set; } = true;
        public bool DetectarNodosPorLosas { get; set; } = true;
        public bool UsarNivelesComoRespaldo { get; set; } = false;
        public double ExtensionNodoInferiorCm { get; set; } = 0.0;
        public double ExtensionNodoSuperiorCm { get; set; } = 0.0;
        public double AlturaNodoInferiorNivelCm { get; set; } = 30.0;
        public double AlturaNodoSuperiorNivelCm { get; set; } = 30.0;

        public int TipoDistribucionEstribosNodo { get; set; } = 1;
        public double[] SeparacionesDistribucionEstribosNodoCm { get; set; } =
            new double[] { 10.0, 10.0, 10.0, 10.0 };
        public int[] CantidadesDistribucionEstribosNodo { get; set; } =
            new int[] { 0, 0, 0, 0 };

        public int TipoDistribucionEstribosEntrepiso { get; set; } = 2;
        public double[] SeparacionesDistribucionEstribosEntrepisoCm { get; set; } =
            new double[] { 10.0, 20.0, 20.0, 20.0 };
        public int[] CantidadesDistribucionEstribosEntrepiso { get; set; } =
            new int[] { 6, 0, 0, 0 };

        public System.Collections.Generic.List<AceroColumnaPunto2D>
            ContornoReferencia
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaPunto2D>();

        public System.Collections.Generic.List<
            System.Collections.Generic.List<AceroColumnaPunto2D>>
            ContornosReferencia
        { get; set; } =
            new System.Collections.Generic.List<
                System.Collections.Generic.List<AceroColumnaPunto2D>>();

        public System.Collections.Generic.List<AceroColumnaPunto2D>
            LongitudinalesManuales
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaPunto2D>();

        public System.Collections.Generic.List<AceroColumnaBarraLongitudinal2D>
            LongitudinalesTipadas
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaBarraLongitudinal2D>();

        public System.Collections.Generic.List<AceroColumnaGrupoLongitudinal2D>
            GruposLongitudinales
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaGrupoLongitudinal2D>();

        public System.Collections.Generic.List<AceroColumnaEstribo2D>
            EstribosManuales
        { get; set; } =
            new System.Collections.Generic.List<AceroColumnaEstribo2D>();
    }

    internal class AceroColumnaPanelDobleBuffer : System.Windows.Forms.Panel
    {
        public AceroColumnaPanelDobleBuffer()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            SetStyle(
                System.Windows.Forms.ControlStyles.AllPaintingInWmPaint |
                System.Windows.Forms.ControlStyles.UserPaint |
                System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer,
                true);
        }
    }

    internal enum AceroColumnaTipoSnap
    {
        Ninguno,
        Extremo,
        PuntoMedio,
        Centro,
        Interseccion,
        Perpendicular,
        Cercano
    }

    internal class AceroColumnaResultadoSnap
    {
        public bool Valido { get; set; }
        public AceroColumnaPunto2D Punto { get; set; }
        public AceroColumnaTipoSnap Tipo { get; set; }
        public string Texto { get; set; } = "";

        public static AceroColumnaResultadoSnap Ninguno()
        {
            return new AceroColumnaResultadoSnap
            {
                Valido = false,
                Punto = null,
                Tipo = AceroColumnaTipoSnap.Ninguno,
                Texto = ""
            };
        }
    }

    internal class AceroColumnaSegmento2D
    {
        public AceroColumnaPunto2D A { get; set; }
        public AceroColumnaPunto2D B { get; set; }

        public AceroColumnaSegmento2D(
            AceroColumnaPunto2D a,
            AceroColumnaPunto2D b)
        {
            A = a;
            B = b;
        }
    }

    internal class AceroColumnaBarraOsnap : System.Windows.Forms.FlowLayoutPanel
    {
        private bool bloqueando;

        private System.Windows.Forms.CheckBox chkActivo;
        private System.Windows.Forms.CheckBox chkExtremo;
        private System.Windows.Forms.CheckBox chkPuntoMedio;
        private System.Windows.Forms.CheckBox chkCentro;
        private System.Windows.Forms.CheckBox chkInterseccion;
        private System.Windows.Forms.CheckBox chkPerpendicular;
        private System.Windows.Forms.CheckBox chkCercano;

        public event System.EventHandler ConfiguracionCambiada;

        public bool Activo
        {
            get { return chkActivo.Checked; }
        }

        public bool Extremo
        {
            get { return chkExtremo.Checked; }
        }

        public bool PuntoMedio
        {
            get { return chkPuntoMedio.Checked; }
        }

        public bool Centro
        {
            get { return chkCentro.Checked; }
        }

        public bool Interseccion
        {
            get { return chkInterseccion.Checked; }
        }

        public bool Perpendicular
        {
            get { return chkPerpendicular.Checked; }
        }

        public bool Cercano
        {
            get { return chkCercano.Checked; }
        }

        public AceroColumnaBarraOsnap()
        {
            Height = 30;
            Width = 550;
            AutoSize = false;
            WrapContents = false;
            FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight;
            Padding = new System.Windows.Forms.Padding(4, 3, 2, 2);
            Margin = new System.Windows.Forms.Padding(0);
            BackColor = System.Drawing.Color.FromArgb(242, 245, 248);
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            chkActivo = CrearCheck("OSNAP (F3)", 86, true);
            chkExtremo = CrearCheck("Extremo", 74, true);
            chkPuntoMedio = CrearCheck("Medio", 65, true);
            chkCentro = CrearCheck("Centro", 68, true);
            chkInterseccion = CrearCheck("Intersección", 94, true);
            chkPerpendicular = CrearCheck("Perp.", 58, true);
            chkPerpendicular.AccessibleName = "Referencia perpendicular";
            chkCercano = CrearCheck("Cercano", 74, true);

            Controls.Add(chkActivo);
            Controls.Add(chkExtremo);
            Controls.Add(chkPuntoMedio);
            Controls.Add(chkCentro);
            Controls.Add(chkInterseccion);
            Controls.Add(chkPerpendicular);
            Controls.Add(chkCercano);

            ActualizarHabilitacion();
        }

        private System.Windows.Forms.CheckBox CrearCheck(
            string texto,
            int width,
            bool marcado)
        {
            System.Windows.Forms.CheckBox check =
                new System.Windows.Forms.CheckBox
                {
                    Text = texto,
                    Width = width,
                    Height = 21,
                    Checked = marcado,
                    AutoSize = false,
                    Margin = new System.Windows.Forms.Padding(1, 0, 1, 0),
                    Font = new System.Drawing.Font("Segoe UI", 7.8F),
                    ForeColor = System.Drawing.Color.FromArgb(45, 45, 45),
                    BackColor = System.Drawing.Color.Transparent
                };

            check.CheckedChanged += (s, e) =>
            {
                if (check == chkActivo)
                    ActualizarHabilitacion();

                if (!bloqueando && ConfiguracionCambiada != null)
                    ConfiguracionCambiada(this, System.EventArgs.Empty);
            };

            return check;
        }

        private void ActualizarHabilitacion()
        {
            bool activo = chkActivo != null && chkActivo.Checked;

            if (chkExtremo != null)
                chkExtremo.Enabled = activo;
            if (chkPuntoMedio != null)
                chkPuntoMedio.Enabled = activo;
            if (chkCentro != null)
                chkCentro.Enabled = activo;
            if (chkInterseccion != null)
                chkInterseccion.Enabled = activo;
            if (chkPerpendicular != null)
                chkPerpendicular.Enabled = activo;
            if (chkCercano != null)
                chkCercano.Enabled = activo;
        }

        public void EstablecerEstado(
            bool activo,
            bool extremo,
            bool puntoMedio,
            bool centro,
            bool interseccion,
            bool perpendicular,
            bool cercano)
        {
            bloqueando = true;

            chkActivo.Checked = activo;
            chkExtremo.Checked = extremo;
            chkPuntoMedio.Checked = puntoMedio;
            chkCentro.Checked = centro;
            chkInterseccion.Checked = interseccion;
            chkPerpendicular.Checked = perpendicular;
            chkCercano.Checked = cercano;

            bloqueando = false;
            ActualizarHabilitacion();
        }
    }

    internal enum AceroColumnaHerramientaLongitudinal
    {
        SeleccionarMover,
        MoverDosPuntos,
        CopiarDosPuntos,
        Agregar,
        DistribuirDosPuntos,
        DistribuirCircular,
        Eliminar
    }

    internal enum AceroColumnaHerramientaEstribo
    {
        SeleccionarMover,
        MoverDosPuntos,
        CopiarDosPuntos,
        Rectangular,
        Rombo,
        Croquis,
        HorizontalAlmaDosPuntos,
        GanchoC,
        GanchoS,
        CambiarGancho,
        Eliminar
    }

    // Intercepta los atajos antes de que el mensaje llegue a Revit.
    // Es necesario para una ventana modeless: ProcessCmdKey solo funciona
    // cuando un control WinForms tiene efectivamente el foco del teclado.
    internal class AceroColumnaFiltroAtajosVentana :
        System.Windows.Forms.IMessageFilter
    {
        private readonly System.WeakReference referenciaFormulario;

        public AceroColumnaFiltroAtajosVentana(AceroColumnaForm formulario)
        {
            referenciaFormulario = new System.WeakReference(formulario);
        }

        public bool PreFilterMessage(ref System.Windows.Forms.Message m)
        {
            const int WM_KEYDOWN = 0x0100;
            const int WM_CHAR = 0x0102;
            const int WM_SYSKEYDOWN = 0x0104;
            const int WM_SYSCHAR = 0x0106;

            AceroColumnaForm formulario =
                referenciaFormulario.Target as AceroColumnaForm;

            if (formulario == null || formulario.IsDisposed)
                return false;

            // WM_CHAR contiene el carácter real según el idioma y distribución
            // del teclado. Es más confiable que traducir Keys manualmente para
            // números, coma decimal y símbolos de unidades.
            if (m.Msg == WM_CHAR || m.Msg == WM_SYSCHAR)
            {
                char caracter = (char)(int)m.WParam;
                return formulario.ProcesarCaracterAntesDeRevit(caracter);
            }

            if (m.Msg != WM_KEYDOWN && m.Msg != WM_SYSKEYDOWN)
                return false;

            System.Windows.Forms.Keys tecla =
                ((System.Windows.Forms.Keys)(int)m.WParam) &
                System.Windows.Forms.Keys.KeyCode;

            System.Windows.Forms.Keys datosTecla =
                tecla | System.Windows.Forms.Control.ModifierKeys;

            return formulario.ProcesarAtajoAntesDeRevit(datosTecla);
        }
    }


    // Ventana modal de parámetros para calcular el empalme por tracción.
    // Se mantiene en el mismo archivo para que el usuario solo tenga que
    // reemplazar AceroColumnaForm.cs y no agregar archivos nuevos al proyecto.
    internal class AceroColumnaRneEmpalmeForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.CheckBox chkUsarRne;
        private System.Windows.Forms.CheckBox chkCondicionesTabla121;
        private System.Windows.Forms.TextBox txtFc;
        private System.Windows.Forms.TextBox txtFy;
        private System.Windows.Forms.TextBox txtPsiT;
        private System.Windows.Forms.TextBox txtPsiE;
        private System.Windows.Forms.TextBox txtLambda;
        private System.Windows.Forms.ComboBox cmbClase;
        private System.Windows.Forms.TextBox txtMinimo;
        private System.Windows.Forms.TextBox txtRedondeoCm;
        private System.Windows.Forms.Label lblResultado;
        private readonly double diametroReferenciaMm;

        public bool UsarCalculoRne { get; private set; }
        public double FcKgCm2 { get; private set; }
        public double FyMpa { get; private set; }
        public double PsiT { get; private set; }
        public double PsiE { get; private set; }
        public double Lambda { get; private set; }
        public double FactorClase { get; private set; }
        public double LongitudMinimaMm { get; private set; }
        public bool CondicionesTabla121 { get; private set; }
        public double RedondeoSuperiorMm { get; private set; }
        public double LongitudDesarrolloReferenciaMm { get; private set; }
        public double LongitudEmpalmeReferenciaMm { get; private set; }

        public AceroColumnaRneEmpalmeForm(
            bool usarRne,
            double fcKgCm2,
            double fyMpa,
            double psiT,
            double psiE,
            double lambda,
            double factorClase,
            double longitudMinimaMm,
            bool condicionesTabla121,
            double redondeoSuperiorMm,
            double diametroReferenciaMm)
        {
            this.diametroReferenciaMm = diametroReferenciaMm > 0.0
                ? diametroReferenciaMm
                : 15.875;

            Text = "RNE E.060 - Empalme longitudinal";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowIcon = false;
            ShowInTaskbar = false;

            // La ventana principal del add-in trabaja con TopMost=true. La ventana
            // modal debe estar también temporalmente en primer plano para que no
            // quede oculta detrás de la ventana principal o de Revit.
            TopMost = true;
            ClientSize = new System.Drawing.Size(520, 520);
            BackColor = System.Drawing.Color.FromArgb(246, 248, 251);
            Font = new System.Drawing.Font("Segoe UI", 9F);

            System.Windows.Forms.Label titulo = new System.Windows.Forms.Label
            {
                Text = "CÁLCULO AUTOMÁTICO DEL EMPALME A TRACCIÓN",
                Left = 20,
                Top = 16,
                Width = 480,
                Height = 26,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Font = new System.Drawing.Font(
                    "Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(0, 82, 150)
            };

            chkUsarRne = new System.Windows.Forms.CheckBox
            {
                Text = "Usar cálculo automático RNE E.060 por diámetro",
                Left = 25,
                Top = 52,
                Width = 455,
                Height = 25,
                Checked = usarRne,
                Font = new System.Drawing.Font(
                    "Segoe UI", 9F, System.Drawing.FontStyle.Bold)
            };

            chkCondicionesTabla121 = new System.Windows.Forms.CheckBox
            {
                Text = "Se cumplen recubrimiento, separación y estribos de Tabla 12.1",
                Left = 25,
                Top = 80,
                Width = 470,
                Height = 24,
                Checked = condicionesTabla121,
                Font = new System.Drawing.Font("Segoe UI", 8.3F)
            };

            System.Windows.Forms.GroupBox grupo = new System.Windows.Forms.GroupBox
            {
                Text = "Parámetros",
                Left = 20,
                Top = 108,
                Width = 480,
                Height = 285,
                BackColor = BackColor
            };

            txtFc = CrearEntrada(grupo, "f'c:", "kg/cm²", 26, fcKgCm2, "0.###");
            txtFy = CrearEntrada(grupo, "fy:", "MPa", 58, fyMpa, "0.###");
            txtPsiT = CrearEntrada(grupo, "ψt:", "", 90, psiT, "0.###");
            txtPsiE = CrearEntrada(grupo, "ψe:", "", 122, psiE, "0.###");
            txtLambda = CrearEntrada(grupo, "λ:", "", 154, lambda, "0.###");

            System.Windows.Forms.Label lblClase = new System.Windows.Forms.Label
            {
                Text = "Clase:",
                Left = 22,
                Top = 190,
                Width = 130,
                Height = 22
            };
            cmbClase = new System.Windows.Forms.ComboBox
            {
                Left = 165,
                Top = 186,
                Width = 180,
                Height = 24,
                DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            };
            cmbClase.Items.Add("Clase A  (1.0 ld)");
            cmbClase.Items.Add("Clase B  (1.3 ld)");
            cmbClase.SelectedIndex = factorClase <= 1.0001 ? 0 : 1;
            grupo.Controls.Add(lblClase);
            grupo.Controls.Add(cmbClase);

            System.Windows.Forms.Label lblMin = new System.Windows.Forms.Label
            {
                Text = "Longitud mínima:",
                Left = 22,
                Top = 218,
                Width = 130,
                Height = 22
            };
            txtMinimo = new System.Windows.Forms.TextBox
            {
                Left = 165,
                Top = 214,
                Width = 95,
                Height = 24,
                Text = longitudMinimaMm.ToString(
                    "0.###", System.Globalization.CultureInfo.InvariantCulture),
                TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            };
            System.Windows.Forms.Label lblMm = new System.Windows.Forms.Label
            {
                Text = "mm",
                Left = 268,
                Top = 218,
                Width = 45,
                Height = 22
            };
            grupo.Controls.Add(lblMin);
            grupo.Controls.Add(txtMinimo);
            grupo.Controls.Add(lblMm);

            System.Windows.Forms.Label lblRedondeo = new System.Windows.Forms.Label
            {
                Text = "Redondeo superior:",
                Left = 22,
                Top = 250,
                Width = 140,
                Height = 22
            };
            txtRedondeoCm = new System.Windows.Forms.TextBox
            {
                Left = 165,
                Top = 246,
                Width = 95,
                Height = 24,
                Text = (redondeoSuperiorMm / 10.0).ToString(
                    "0.###", System.Globalization.CultureInfo.InvariantCulture),
                TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            };
            System.Windows.Forms.Label lblCmRedondeo = new System.Windows.Forms.Label
            {
                Text = "cm",
                Left = 268,
                Top = 250,
                Width = 45,
                Height = 22
            };
            grupo.Controls.Add(lblRedondeo);
            grupo.Controls.Add(txtRedondeoCm);
            grupo.Controls.Add(lblCmRedondeo);

            lblResultado = new System.Windows.Forms.Label
            {
                Left = 20,
                Top = 402,
                Width = 480,
                Height = 60,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.White,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Font = new System.Drawing.Font(
                    "Segoe UI", 9F, System.Drawing.FontStyle.Bold)
            };

            System.Windows.Forms.Label nota = new System.Windows.Forms.Label
            {
                Text = "El handler recalculará Le para cada barra según su diámetro real. " +
                       "La vista previa usa el diámetro de referencia del diseño actual.",
                Left = 24,
                Top = 466,
                Width = 472,
                Height = 18,
                ForeColor = System.Drawing.Color.DimGray,
                Font = new System.Drawing.Font("Segoe UI", 8F)
            };

            System.Windows.Forms.Button btnAplicar = new System.Windows.Forms.Button
            {
                Text = "CALCULAR Y APLICAR",
                Left = 250,
                Top = 486,
                Width = 160,
                Height = 30,
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font(
                    "Segoe UI", 8.5F, System.Drawing.FontStyle.Bold)
            };
            btnAplicar.FlatAppearance.BorderSize = 0;
            btnAplicar.Click += (s, e) => AplicarYCerrar();

            System.Windows.Forms.Button btnCancelar = new System.Windows.Forms.Button
            {
                Text = "CANCELAR",
                Left = 416,
                Top = 486,
                Width = 84,
                Height = 30,
                DialogResult = System.Windows.Forms.DialogResult.Cancel
            };

            Controls.Add(titulo);
            Controls.Add(chkUsarRne);
            Controls.Add(chkCondicionesTabla121);
            Controls.Add(grupo);
            Controls.Add(lblResultado);
            Controls.Add(nota);
            Controls.Add(btnAplicar);
            Controls.Add(btnCancelar);

            AcceptButton = btnAplicar;
            CancelButton = btnCancelar;

            System.EventHandler refrescar = (s, e) => ActualizarResultado(false);
            txtFc.TextChanged += refrescar;
            txtFy.TextChanged += refrescar;
            txtPsiT.TextChanged += refrescar;
            txtPsiE.TextChanged += refrescar;
            txtLambda.TextChanged += refrescar;
            txtMinimo.TextChanged += refrescar;
            txtRedondeoCm.TextChanged += refrescar;
            cmbClase.SelectedIndexChanged += refrescar;
            chkCondicionesTabla121.CheckedChanged += refrescar;
            chkUsarRne.CheckedChanged += (s, e) =>
            {
                ActualizarHabilitacion();
                ActualizarResultado(false);
            };

            Shown += (s, e) =>
            {
                try
                {
                    BringToFront();
                    Activate();
                    Focus();
                }
                catch
                {
                }
            };

            ActualizarHabilitacion();
            ActualizarResultado(false);
        }

        private System.Windows.Forms.TextBox CrearEntrada(
            System.Windows.Forms.Control padre,
            string etiqueta,
            string unidad,
            int top,
            double valor,
            string formato)
        {
            System.Windows.Forms.Label lbl = new System.Windows.Forms.Label
            {
                Text = etiqueta,
                Left = 22,
                Top = top + 4,
                Width = 130,
                Height = 22
            };
            System.Windows.Forms.TextBox txt = new System.Windows.Forms.TextBox
            {
                Left = 165,
                Top = top,
                Width = 95,
                Height = 24,
                Text = valor.ToString(
                    formato, System.Globalization.CultureInfo.InvariantCulture),
                TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            };
            System.Windows.Forms.Label und = new System.Windows.Forms.Label
            {
                Text = unidad,
                Left = 268,
                Top = top + 4,
                Width = 80,
                Height = 22
            };
            padre.Controls.Add(lbl);
            padre.Controls.Add(txt);
            padre.Controls.Add(und);
            return txt;
        }

        private void ActualizarHabilitacion()
        {
            bool habilitado = chkUsarRne.Checked;
            txtFc.Enabled = habilitado;
            txtFy.Enabled = habilitado;
            txtPsiT.Enabled = habilitado;
            txtPsiE.Enabled = habilitado;
            txtLambda.Enabled = habilitado;
            txtMinimo.Enabled = habilitado;
            txtRedondeoCm.Enabled = habilitado;
            chkCondicionesTabla121.Enabled = habilitado;
            cmbClase.Enabled = habilitado;
        }

        private void AplicarYCerrar()
        {
            if (!ActualizarResultado(true))
                return;

            UsarCalculoRne = chkUsarRne.Checked;
            DialogResult = System.Windows.Forms.DialogResult.OK;
            Close();
        }

        private bool ActualizarResultado(bool mostrarError)
        {
            double fc;
            double fy;
            double psiT;
            double psiE;
            double lambda;
            double minimo;
            double redondeoCm;

            if (!TryLeer(txtFc.Text, out fc) || fc <= 0.0 ||
                !TryLeer(txtFy.Text, out fy) || fy <= 0.0 ||
                !TryLeer(txtPsiT.Text, out psiT) || psiT <= 0.0 ||
                !TryLeer(txtPsiE.Text, out psiE) || psiE <= 0.0 ||
                !TryLeer(txtLambda.Text, out lambda) || lambda <= 0.0 ||
                !TryLeer(txtMinimo.Text, out minimo) || minimo <= 0.0 ||
                !TryLeer(txtRedondeoCm.Text, out redondeoCm) || redondeoCm < 0.0)
            {
                lblResultado.Text = "Ingrese valores numéricos mayores que cero.";
                lblResultado.ForeColor = System.Drawing.Color.Firebrick;

                if (mostrarError)
                {
                    System.Windows.Forms.MessageBox.Show(
                        this,
                        "Todos los parámetros RNE deben ser numéricos y mayores que cero.",
                        "MYG - Parámetros RNE",
                        System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Warning);
                }
                return false;
            }

            if (chkUsarRne.Checked && !chkCondicionesTabla121.Checked)
            {
                lblResultado.Text =
                    "La fórmula simplificada no debe aplicarse si no se cumplen " +
                    "las condiciones indicadas. Desactive RNE y use el valor manual.";
                lblResultado.ForeColor = System.Drawing.Color.Firebrick;
                if (mostrarError)
                {
                    System.Windows.Forms.MessageBox.Show(
                        this,
                        "La automatización implementa la fórmula simplificada. " +
                        "Confirme las condiciones de Tabla 12.1 o use una longitud manual.",
                        "MYG - Empalme RNE",
                        System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Warning);
                }
                return false;
            }

            double factorClase = cmbClase.SelectedIndex == 0 ? 1.0 : 1.30;
            double fcMpa = fc * 0.0980665;
            double divisor = diametroReferenciaMm <= 19.05 + 1e-6
                ? 2.6
                : 2.1;
            double ld =
                (fy / (divisor * System.Math.Sqrt(fcMpa))) *
                psiT * psiE * lambda * diametroReferenciaMm;
            ld = System.Math.Max(ld, minimo);
            double le = System.Math.Max(factorClase * ld, minimo);
            double redondeoMm = redondeoCm * 10.0;
            if (redondeoMm > 1e-6)
            {
                le = System.Math.Ceiling((le - 1e-9) / redondeoMm) * redondeoMm;
            }

            FcKgCm2 = fc;
            FyMpa = fy;
            PsiT = psiT;
            PsiE = psiE;
            Lambda = lambda;
            FactorClase = factorClase;
            LongitudMinimaMm = minimo;
            CondicionesTabla121 = chkCondicionesTabla121.Checked;
            RedondeoSuperiorMm = redondeoMm;
            LongitudDesarrolloReferenciaMm = ld;
            LongitudEmpalmeReferenciaMm = le;

            if (!chkUsarRne.Checked)
            {
                lblResultado.Text =
                    "Cálculo automático desactivado. Se conservará el valor manual " +
                    "de la pestaña Longitudinal.";
                lblResultado.ForeColor = System.Drawing.Color.DimGray;
                return true;
            }

            lblResultado.Text =
                "Ø referencia = " + diametroReferenciaMm.ToString("0.###") + " mm" +
                "     ld = " + ld.ToString("0") + " mm" +
                "     Le = " + le.ToString("0") + " mm  (" +
                (le / 1000.0).ToString("0.###") + " m)";
            lblResultado.ForeColor = System.Drawing.Color.FromArgb(0, 90, 150);
            return true;
        }

        private bool TryLeer(string texto, out double valor)
        {
            valor = 0.0;
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            string limpio = texto.Trim().Replace(',', '.');
            return double.TryParse(
                limpio,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor);
        }
    }

    // Ventana modal para asignar una distribución de ENTREPISO a uno o
    // varios recorridos seleccionados. La distribución de NODO no se edita
    // aquí y siempre continúa usando el perfil global de la pestaña Stirrups.
    internal sealed class AceroColumnaDistribucionEntrepisoForm :
        System.Windows.Forms.Form
    {
        private readonly System.Windows.Forms.RadioButton rdoGeneral;
        private readonly System.Windows.Forms.RadioButton rdoPersonalizada;
        private readonly System.Windows.Forms.ComboBox cmbTipo;
        private readonly System.Windows.Forms.Panel pnlFilas;
        private readonly System.Windows.Forms.Label[] lblZona =
            new System.Windows.Forms.Label[4];
        private readonly System.Windows.Forms.Label[] lblSeparacion =
            new System.Windows.Forms.Label[4];
        private readonly System.Windows.Forms.Label[] lblCantidad =
            new System.Windows.Forms.Label[4];
        private readonly System.Windows.Forms.Label[] lblUnidadCantidad =
            new System.Windows.Forms.Label[4];
        private readonly System.Windows.Forms.NumericUpDown[] nudSeparacion =
            new System.Windows.Forms.NumericUpDown[4];
        private readonly System.Windows.Forms.NumericUpDown[] nudCantidad =
            new System.Windows.Forms.NumericUpDown[4];

        public bool UsarPersonalizada { get; private set; }
        public int TipoDistribucion { get; private set; }
        public double[] SeparacionesCm { get; private set; }
        public int[] Cantidades { get; private set; }

        public AceroColumnaDistribucionEntrepisoForm(
            int cantidadSeleccionados,
            bool usarPersonalizada,
            int tipoDistribucion,
            double[] separacionesCm,
            int[] cantidades)
        {
            Text = "MYG - Distribución de entrepiso";
            Width = 520;
            Height = 455;
            StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = System.Drawing.Color.FromArgb(247, 248, 250);
            Font = new System.Drawing.Font("Segoe UI", 9F);

            System.Windows.Forms.Label titulo = new System.Windows.Forms.Label
            {
                Text = "DISTRIBUCIÓN PERSONALIZADA SOLO PARA ENTREPISO",
                Left = 18,
                Top = 16,
                Width = 470,
                Height = 25,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Font = new System.Drawing.Font(
                    "Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(0, 90, 160)
            };

            System.Windows.Forms.Label seleccion = new System.Windows.Forms.Label
            {
                Text = "Recorridos seleccionados: " + cantidadSeleccionados,
                Left = 24,
                Top = 50,
                Width = 455,
                Height = 22,
                Font = new System.Drawing.Font(
                    "Segoe UI", 9F, System.Drawing.FontStyle.Bold)
            };

            rdoGeneral = new System.Windows.Forms.RadioButton
            {
                Text = "Usar la distribución general de ENTREPISO",
                Left = 28,
                Top = 79,
                Width = 420,
                Height = 24,
                Checked = !usarPersonalizada
            };
            rdoPersonalizada = new System.Windows.Forms.RadioButton
            {
                Text = "Usar distribución personalizada en los seleccionados",
                Left = 28,
                Top = 106,
                Width = 440,
                Height = 24,
                Checked = usarPersonalizada
            };

            System.Windows.Forms.Label lblTipo = new System.Windows.Forms.Label
            {
                Text = "Tipo de distribución:",
                Left = 28,
                Top = 143,
                Width = 140,
                Height = 22
            };
            cmbTipo = new System.Windows.Forms.ComboBox
            {
                Left = 170,
                Top = 139,
                Width = 300,
                Height = 24,
                DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            };
            cmbTipo.Items.Add("1. Separación constante");
            cmbTipo.Items.Add("2. Dos tramos de espaciado");
            cmbTipo.Items.Add("3. Tres tramos de espaciado");
            cmbTipo.Items.Add("4. Cuatro tramos de espaciado");
            cmbTipo.SelectedIndex = System.Math.Max(0,
                System.Math.Min(3, tipoDistribucion - 1));

            pnlFilas = new System.Windows.Forms.Panel
            {
                Left = 28,
                Top = 174,
                Width = 442,
                Height = 118,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.White
            };

            for (int i = 0; i < 4; i++)
            {
                int y = 7 + i * 27;
                lblZona[i] = new System.Windows.Forms.Label
                {
                    Left = 8,
                    Top = y + 3,
                    Width = 105,
                    Height = 20
                };
                lblSeparacion[i] = new System.Windows.Forms.Label
                {
                    Text = "Sep.:",
                    Left = 112,
                    Top = y + 3,
                    Width = 38,
                    Height = 20
                };
                nudSeparacion[i] = new System.Windows.Forms.NumericUpDown
                {
                    Left = 151,
                    Top = y,
                    Width = 62,
                    Height = 22,
                    Minimum = 1,
                    Maximum = 100,
                    DecimalPlaces = 0,
                    TextAlign = System.Windows.Forms.HorizontalAlignment.Center,
                    Value = (decimal)System.Math.Max(1.0,
                        separacionesCm != null && i < separacionesCm.Length
                            ? separacionesCm[i] : (i == 0 ? 10.0 : 20.0))
                };
                System.Windows.Forms.Label lblCm = new System.Windows.Forms.Label
                {
                    Text = "cm",
                    Left = 217,
                    Top = y + 3,
                    Width = 27,
                    Height = 20,
                    ForeColor = System.Drawing.Color.Gray
                };
                lblCantidad[i] = new System.Windows.Forms.Label
                {
                    Text = "Cant.:",
                    Left = 252,
                    Top = y + 3,
                    Width = 150,
                    Height = 20
                };
                nudCantidad[i] = new System.Windows.Forms.NumericUpDown
                {
                    Left = 296,
                    Top = y,
                    Width = 62,
                    Height = 22,
                    Minimum = 1,
                    Maximum = 1000,
                    DecimalPlaces = 0,
                    TextAlign = System.Windows.Forms.HorizontalAlignment.Center,
                    Value = (decimal)System.Math.Max(1,
                        cantidades != null && i < cantidades.Length
                            ? cantidades[i] : (i == 0 ? 6 : 1))
                };
                lblUnidadCantidad[i] = new System.Windows.Forms.Label
                {
                    Text = "und.",
                    Left = 362,
                    Top = y + 3,
                    Width = 38,
                    Height = 20,
                    ForeColor = System.Drawing.Color.Gray
                };
                pnlFilas.Controls.Add(lblZona[i]);
                pnlFilas.Controls.Add(lblSeparacion[i]);
                pnlFilas.Controls.Add(nudSeparacion[i]);
                pnlFilas.Controls.Add(lblCm);
                pnlFilas.Controls.Add(lblCantidad[i]);
                pnlFilas.Controls.Add(nudCantidad[i]);
                pnlFilas.Controls.Add(lblUnidadCantidad[i]);
            }

            System.Windows.Forms.Label notaNodo = new System.Windows.Forms.Label
            {
                Text = "NODOS: todos los recorridos conservarán el perfil global " +
                       "configurado en Stirrups.",
                Left = 28,
                Top = 303,
                Width = 442,
                Height = 38,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70),
                Font = new System.Drawing.Font(
                    "Segoe UI", 8.4F, System.Drawing.FontStyle.Bold)
            };

            System.Windows.Forms.Button aceptar = new System.Windows.Forms.Button
            {
                Text = "APLICAR",
                Left = 274,
                Top = 356,
                Width = 105,
                Height = 32,
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font(
                    "Segoe UI", 8.5F, System.Drawing.FontStyle.Bold)
            };
            aceptar.FlatAppearance.BorderSize = 0;
            aceptar.Click += (s, e) => AplicarYCerrar();

            System.Windows.Forms.Button cancelar = new System.Windows.Forms.Button
            {
                Text = "CANCELAR",
                Left = 385,
                Top = 356,
                Width = 85,
                Height = 32,
                DialogResult = System.Windows.Forms.DialogResult.Cancel
            };

            Controls.Add(titulo);
            Controls.Add(seleccion);
            Controls.Add(rdoGeneral);
            Controls.Add(rdoPersonalizada);
            Controls.Add(lblTipo);
            Controls.Add(cmbTipo);
            Controls.Add(pnlFilas);
            Controls.Add(notaNodo);
            Controls.Add(aceptar);
            Controls.Add(cancelar);
            AcceptButton = aceptar;
            CancelButton = cancelar;

            rdoGeneral.CheckedChanged += (s, e) => ActualizarHabilitacion();
            rdoPersonalizada.CheckedChanged += (s, e) => ActualizarHabilitacion();
            cmbTipo.SelectedIndexChanged += (s, e) => ActualizarFilas();
            ActualizarFilas();
            ActualizarHabilitacion();
        }

        private void ActualizarHabilitacion()
        {
            bool activo = rdoPersonalizada.Checked;
            cmbTipo.Enabled = activo;
            pnlFilas.Enabled = activo;
        }

        private void ActualizarFilas()
        {
            int tipo = System.Math.Max(1, cmbTipo.SelectedIndex + 1);
            for (int i = 0; i < 4; i++)
            {
                bool visible = i < tipo;
                bool resto = visible && tipo > 1 && i == tipo - 1;
                bool espaciadoMaximo = visible && (tipo == 1 || resto);

                lblZona[i].Visible = true;
                lblSeparacion[i].Visible = visible;
                nudSeparacion[i].Visible = visible;
                nudSeparacion[i].Enabled = visible;

                if (!visible)
                {
                    lblZona[i].Text = "—";
                    lblCantidad[i].Visible = false;
                    nudCantidad[i].Visible = false;
                    lblUnidadCantidad[i].Visible = false;
                    continue;
                }

                lblZona[i].Text = tipo == 1
                    ? "TOTAL (máx.)"
                    : (resto ? "RESTO (máx.)" : "Zona " + (i + 1));
                lblSeparacion[i].Text = espaciadoMaximo ? "Máx.:" : "Sep.:";

                lblCantidad[i].Visible = true;
                lblCantidad[i].Text = espaciadoMaximo
                    ? "ESPACIADO MÁXIMO"
                    : "Cant.:";
                lblCantidad[i].Width = espaciadoMaximo ? 150 : 42;

                nudCantidad[i].Visible = !espaciadoMaximo;
                nudCantidad[i].Enabled = !espaciadoMaximo;
                lblUnidadCantidad[i].Visible = !espaciadoMaximo;
            }
        }

        private void AplicarYCerrar()
        {
            UsarPersonalizada = rdoPersonalizada.Checked;
            TipoDistribucion = System.Math.Max(1, cmbTipo.SelectedIndex + 1);
            SeparacionesCm = new double[4];
            Cantidades = new int[4];
            for (int i = 0; i < 4; i++)
            {
                SeparacionesCm[i] = (double)nudSeparacion[i].Value;
                Cantidades[i] = (int)nudCantidad[i].Value;
            }
            DialogResult = System.Windows.Forms.DialogResult.OK;
            Close();
        }
    }


    internal sealed class AceroColumnaReglaGrupoLongitudinalForm :
        System.Windows.Forms.Form
    {
        private readonly System.Windows.Forms.ComboBox cmbRegla;
        private readonly System.Windows.Forms.NumericUpDown nudEspaciado;
        private readonly System.Windows.Forms.NumericUpDown nudCantidad;
        private readonly System.Windows.Forms.Label lblLongitud;
        private readonly System.Windows.Forms.Label lblResultado;
        private readonly double longitudDisponibleCm;
        private readonly bool esCircular;

        public AceroColumnaReglaGrupoLongitudinal ReglaSeleccionada
        {
            get
            {
                if (esCircular)
                {
                    return cmbRegla.SelectedIndex == 0
                        ? AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo
                        : AceroColumnaReglaGrupoLongitudinal.NumeroFijo;
                }

                return cmbRegla.SelectedIndex == 0
                    ? AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo
                    : cmbRegla.SelectedIndex == 1
                        ? AceroColumnaReglaGrupoLongitudinal.NumeroConEspaciado
                        : AceroColumnaReglaGrupoLongitudinal.NumeroFijo;
            }
        }

        public double EspaciadoCm { get { return (double)nudEspaciado.Value; } }
        public int Cantidad { get { return (int)nudCantidad.Value; } }

        public AceroColumnaReglaGrupoLongitudinalForm(
            AceroColumnaGrupoLongitudinal2D grupo,
            double longitudCm)
        {
            longitudDisponibleCm = System.Math.Max(0.0, longitudCm);
            esCircular = grupo != null && grupo.EsCircular;

            Text = "MYG - Regla del grupo longitudinal";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new System.Drawing.Size(470, 285);
            Font = new System.Drawing.Font("Segoe UI", 9F);

            // Este cuadro puede abrirse desde una ventana modeless TopMost dentro
            // de Revit. Se fuerza al frente también después de Shown para evitar
            // que quede oculto detrás del formulario principal o de Revit.
            TopMost = true;
            Shown += (s, e) =>
            {
                BeginInvoke(new System.Action(() =>
                {
                    TopMost = true;
                    BringToFront();
                    Activate();
                    Focus();
                }));
            };

            System.Windows.Forms.Label titulo = new System.Windows.Forms.Label
            {
                Left = 18,
                Top = 17,
                Width = 430,
                Height = 25,
                Text = grupo != null && grupo.EsCircular
                    ? "DISTRIBUCIÓN CIRCULAR LONGITUDINAL"
                    : "DISTRIBUCIÓN DEL GRUPO LONGITUDINAL",
                Font = new System.Drawing.Font(
                    "Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(0, 95, 155)
            };
            Controls.Add(titulo);

            lblLongitud = new System.Windows.Forms.Label
            {
                Left = 20,
                Top = 52,
                Width = 420,
                Height = 22,
                Text = grupo != null && grupo.EsCircular
                    ? "Longitud de la circunferencia: " +
                        longitudDisponibleCm.ToString("0.##") + " cm"
                    : "Longitud definida entre los dos puntos: " +
                        longitudDisponibleCm.ToString("0.##") + " cm"
            };
            Controls.Add(lblLongitud);

            Controls.Add(new System.Windows.Forms.Label
            {
                Left = 20,
                Top = 89,
                Width = 150,
                Height = 22,
                Text = "Regla de distribución:"
            });

            cmbRegla = new System.Windows.Forms.ComboBox
            {
                Left = 176,
                Top = 85,
                Width = 265,
                DropDownStyle =
                    System.Windows.Forms.ComboBoxStyle.DropDownList
            };
            cmbRegla.Items.Add("Espaciado máximo");
            if (esCircular)
            {
                cmbRegla.Items.Add("Cantidad fija");
            }
            else
            {
                cmbRegla.Items.Add("Número con espaciado");
                cmbRegla.Items.Add("Número fijo");
            }
            Controls.Add(cmbRegla);

            Controls.Add(new System.Windows.Forms.Label
            {
                Left = 20,
                Top = 127,
                Width = 150,
                Height = 22,
                Text = "Espaciado:"
            });

            nudEspaciado = new System.Windows.Forms.NumericUpDown
            {
                Left = 176,
                Top = 123,
                Width = 110,
                DecimalPlaces = 2,
                Minimum = 0.10M,
                Maximum = 1000M,
                Increment = 0.50M,
                Value = (decimal)System.Math.Max(
                    0.10,
                    grupo != null ? grupo.EspaciadoCm : 20.0)
            };
            Controls.Add(nudEspaciado);
            Controls.Add(new System.Windows.Forms.Label
            {
                Left = 292,
                Top = 127,
                Width = 35,
                Height = 22,
                Text = "cm"
            });

            Controls.Add(new System.Windows.Forms.Label
            {
                Left = 20,
                Top = 164,
                Width = 150,
                Height = 22,
                Text = "Cantidad:"
            });

            nudCantidad = new System.Windows.Forms.NumericUpDown
            {
                Left = 176,
                Top = 160,
                Width = 110,
                Minimum = 1,
                Maximum = 1002,
                Value = System.Math.Max(
                    1,
                    grupo != null ? grupo.Cantidad : 4)
            };
            Controls.Add(nudCantidad);

            lblResultado = new System.Windows.Forms.Label
            {
                Left = 20,
                Top = 198,
                Width = 420,
                Height = 30,
                ForeColor = System.Drawing.Color.FromArgb(65, 65, 65)
            };
            Controls.Add(lblResultado);

            System.Windows.Forms.Button btnAceptar =
                new System.Windows.Forms.Button
                {
                    Left = 278,
                    Top = 238,
                    Width = 82,
                    Height = 30,
                    Text = "APLICAR",
                    DialogResult = System.Windows.Forms.DialogResult.OK
                };
            Controls.Add(btnAceptar);

            System.Windows.Forms.Button btnCancelar =
                new System.Windows.Forms.Button
                {
                    Left = 367,
                    Top = 238,
                    Width = 82,
                    Height = 30,
                    Text = "CANCELAR",
                    DialogResult = System.Windows.Forms.DialogResult.Cancel
                };
            Controls.Add(btnCancelar);

            AcceptButton = btnAceptar;
            CancelButton = btnCancelar;

            AceroColumnaReglaGrupoLongitudinal regla = grupo != null
                ? grupo.Regla
                : AceroColumnaReglaGrupoLongitudinal.NumeroFijo;
            cmbRegla.SelectedIndex = regla ==
                AceroColumnaReglaGrupoLongitudinal.EspaciadoMaximo
                    ? 0
                    : esCircular
                        ? 1
                        : regla ==
                            AceroColumnaReglaGrupoLongitudinal.NumeroConEspaciado
                            ? 1
                            : 2;

            cmbRegla.SelectedIndexChanged += (s, e) => ActualizarControles();
            nudEspaciado.ValueChanged += (s, e) => ActualizarResumen();
            nudCantidad.ValueChanged += (s, e) => ActualizarResumen();
            ActualizarControles();
        }

        private void ActualizarControles()
        {
            bool usaEspaciado = esCircular
                ? cmbRegla.SelectedIndex == 0
                : cmbRegla.SelectedIndex <= 1;
            bool usaCantidad = cmbRegla.SelectedIndex >= 1;
            nudEspaciado.Enabled = usaEspaciado;
            nudCantidad.Enabled = usaCantidad;
            ActualizarResumen();
        }

        private void ActualizarResumen()
        {
            if (esCircular && cmbRegla.SelectedIndex == 1)
            {
                int cantidadCircular = System.Math.Max(
                    3,
                    (int)nudCantidad.Value);
                double separacionReal = cantidadCircular <= 0
                    ? 0.0
                    : longitudDisponibleCm / cantidadCircular;
                lblResultado.Text =
                    "Se crearán " + cantidadCircular +
                    " barras individuales uniformes. Separación aproximada: " +
                    separacionReal.ToString("0.##") + " cm.";
                return;
            }

            if (cmbRegla.SelectedIndex == 0)
            {
                int cantidad = longitudDisponibleCm <= 1e-9
                    ? 1
                    : esCircular
                        ? System.Math.Max(
                            3,
                            (int)System.Math.Ceiling(
                                longitudDisponibleCm /
                                System.Math.Max(
                                    0.10,
                                    (double)nudEspaciado.Value)))
                        : System.Math.Max(
                            2,
                            (int)System.Math.Ceiling(
                                longitudDisponibleCm /
                                System.Math.Max(
                                    0.10,
                                    (double)nudEspaciado.Value)) + 1);
                lblResultado.Text = esCircular
                    ? "Se crearán " + cantidad +
                        " barras individuales uniformes sin superar el máximo."
                    : "Revit distribuirá aproximadamente " + cantidad +
                        " barras sin superar el espaciado indicado.";
            }
            else if (cmbRegla.SelectedIndex == 1)
            {
                double ocupado = System.Math.Max(
                    0,
                    ((int)nudCantidad.Value - 1) *
                    (double)nudEspaciado.Value);
                lblResultado.Text =
                    "Longitud ocupada por la regla: " +
                    ocupado.ToString("0.##") + " cm.";
            }
            else
            {
                double sep = (int)nudCantidad.Value <= 1
                    ? 0.0
                    : longitudDisponibleCm /
                        ((int)nudCantidad.Value - 1);
                lblResultado.Text =
                    "Las barras ocuparán todo el tramo con separación aproximada " +
                    sep.ToString("0.##") + " cm.";
            }
        }
    }

    #endregion

}
