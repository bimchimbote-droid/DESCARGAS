using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // ==========================================
    // COMANDO 3.7 - ACERO LONGITUDINAL EN COLUMNAS
    // SIN USING NI NAMESPACE
    // VENTANA MODELESS + UN SOLO HANDLER
    // ==========================================

    [Autodesk.Revit.Attributes.Transaction(
        Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class AceroColumnaCommand : Autodesk.Revit.UI.IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc =
                commandData.Application.ActiveUIDocument;

            if (uidoc == null)
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.DB.Document doc = uidoc.Document;

            System.Collections.Generic.IEnumerable<
                Autodesk.Revit.DB.Structure.RebarBarType> consultaArmadura =
                System.Linq.Enumerable.Cast<
                    Autodesk.Revit.DB.Structure.RebarBarType>(
                        new Autodesk.Revit.DB.FilteredElementCollector(doc)
                            .OfClass(
                                typeof(
                                    Autodesk.Revit.DB.Structure.RebarBarType)));

            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarBarType> tiposArmadura =
                System.Linq.Enumerable.ToList(
                    System.Linq.Enumerable.OrderBy(
                        consultaArmadura,
                        x => x.Name));

            if (tiposArmadura.Count == 0)
            {
                Autodesk.Revit.UI.TaskDialog.Show(
                    "MYG",
                    "No se encontraron tipos de armadura estructural en el proyecto.");

                return Autodesk.Revit.UI.Result.Cancelled;
            }

            System.Collections.Generic.IEnumerable<
                Autodesk.Revit.DB.Structure.RebarHookType> consultaGanchos =
                System.Linq.Enumerable.Cast<
                    Autodesk.Revit.DB.Structure.RebarHookType>(
                        new Autodesk.Revit.DB.FilteredElementCollector(doc)
                            .OfClass(
                                typeof(
                                    Autodesk.Revit.DB.Structure.RebarHookType)));

            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarHookType> tiposGancho =
                System.Linq.Enumerable.ToList(
                    System.Linq.Enumerable.OrderBy(
                        consultaGanchos,
                        x => x.Name));

            AceroColumnaForm form = new AceroColumnaForm();
            form.CargarTiposArmadura(tiposArmadura);
            form.CargarTiposGancho(tiposGancho);

            AceroColumnaHandler handler = new AceroColumnaHandler
            {
                UiDoc = uidoc,
                Form = form
            };

            Autodesk.Revit.UI.ExternalEvent externalEvent =
                Autodesk.Revit.UI.ExternalEvent.Create(handler);

            form.Handler = handler;
            form.ExternalEvent = externalEvent;
            form.Show();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}
