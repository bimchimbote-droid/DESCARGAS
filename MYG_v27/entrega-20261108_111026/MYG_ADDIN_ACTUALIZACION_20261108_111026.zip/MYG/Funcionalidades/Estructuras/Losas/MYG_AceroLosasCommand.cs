using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ============================================================================
    // BLOQUE COMPLETO - ACERO EN LOSAS
    // PARA TU ARCHIVO MYGCommands.cs
    //
    // SIN USING
    // SIN NAMESPACE
    //
    // IMPORTANTE:
    // Este bloque debe estar DENTRO del namespace MYG_Addin que ya tiene
    // tu archivo MYGCommands.cs.
    //
    // En adelante NO necesitas modificar este comando.
    // ============================================================================

    [Autodesk.Revit.Attributes.Transaction(
        Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class MYG_AceroLosasCommand :
        Autodesk.Revit.UI.IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc =
                commandData.Application.ActiveUIDocument;

            if (uidoc == null)
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.DB.Document doc =
                uidoc.Document;

            if (doc == null)
                return Autodesk.Revit.UI.Result.Cancelled;

            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarBarType>
                tiposBarra =
                new System.Collections.Generic.List<
                    Autodesk.Revit.DB.Structure.RebarBarType>();

            Autodesk.Revit.DB.FilteredElementCollector collector =
                new Autodesk.Revit.DB.FilteredElementCollector(
                    doc);

            collector.OfClass(
                typeof(
                    Autodesk.Revit.DB.Structure.RebarBarType));

            foreach (
                Autodesk.Revit.DB.Element elemento
                in collector)
            {
                Autodesk.Revit.DB.Structure.RebarBarType tipo =
                    elemento
                    as Autodesk.Revit.DB.Structure.RebarBarType;

                if (tipo != null)
                    tiposBarra.Add(tipo);
            }

            tiposBarra.Sort(
                delegate (
                    Autodesk.Revit.DB.Structure.RebarBarType a,
                    Autodesk.Revit.DB.Structure.RebarBarType b)
                {
                    string na =
                        a == null
                        ? ""
                        : a.Name;

                    string nb =
                        b == null
                        ? ""
                        : b.Name;

                    return string.Compare(
                        na,
                        nb,
                        System.StringComparison.OrdinalIgnoreCase);
                });

            if (tiposBarra.Count == 0)
            {
                Autodesk.Revit.UI.TaskDialog.Show(
                    "MYG",
                    "No se encontraron tipos de barra de armadura en el proyecto.");

                return Autodesk.Revit.UI.Result.Cancelled;
            }

            AceroLosasForm.Abrir(
                uidoc,
                tiposBarra);

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}
