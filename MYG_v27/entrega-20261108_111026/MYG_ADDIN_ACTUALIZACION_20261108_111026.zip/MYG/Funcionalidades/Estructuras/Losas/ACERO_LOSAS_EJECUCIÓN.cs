﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Globalization;

// ============================================================================
// ALIAS EXPLICITOS PARA EVITAR CONFLICTOS ENTRE REVIT Y WINFORMS/DRAWING
// ============================================================================

using Form = System.Windows.Forms.Form;
using Panel = System.Windows.Forms.Panel;
using Label = System.Windows.Forms.Label;
using Button = System.Windows.Forms.Button;
using FlowLayoutPanel = System.Windows.Forms.FlowLayoutPanel;
using GroupBox = System.Windows.Forms.GroupBox;
using CheckBox = System.Windows.Forms.CheckBox;
using ComboBox = System.Windows.Forms.ComboBox;
using NumericUpDown = System.Windows.Forms.NumericUpDown;
using Control = System.Windows.Forms.Control;
using Padding = System.Windows.Forms.Padding;
using Cursor = System.Windows.Forms.Cursor;
using PaintEventArgs = System.Windows.Forms.PaintEventArgs;
using MouseEventArgs = System.Windows.Forms.MouseEventArgs;

using DockStyle = System.Windows.Forms.DockStyle;
using FormStartPosition = System.Windows.Forms.FormStartPosition;
using FormBorderStyle = System.Windows.Forms.FormBorderStyle;
using AnchorStyles = System.Windows.Forms.AnchorStyles;
using BorderStyle = System.Windows.Forms.BorderStyle;
using ComboBoxStyle = System.Windows.Forms.ComboBoxStyle;
using FlatStyle = System.Windows.Forms.FlatStyle;
using Cursors = System.Windows.Forms.Cursors;
using MouseButtons = System.Windows.Forms.MouseButtons;
using ControlStyles = System.Windows.Forms.ControlStyles;

using Color = System.Drawing.Color;
using Point = System.Drawing.Point;
using PointF = System.Drawing.PointF;
using Size = System.Drawing.Size;
using Font = System.Drawing.Font;
using FontStyle = System.Drawing.FontStyle;
using ContentAlignment = System.Drawing.ContentAlignment;
using Graphics = System.Drawing.Graphics;
using Pen = System.Drawing.Pen;
using Brush = System.Drawing.Brush;
using SolidBrush = System.Drawing.SolidBrush;
using Brushes = System.Drawing.Brushes;
using SizeF = System.Drawing.SizeF;
using RectangleF = System.Drawing.RectangleF;
using Pens = System.Drawing.Pens;

using SmoothingMode = System.Drawing.Drawing2D.SmoothingMode;
using DashStyle = System.Drawing.Drawing2D.DashStyle;
using LineCap = System.Drawing.Drawing2D.LineCap;

namespace MYG_Addin
{
    // =====================================================================
    // MYG - ACERO EN LOSAS - PAÑOS - REVIT 2027
    // UNICO HANDLER EXTERNO DEL MODULO.
    // VERSION: JSON AUTOCONTENIDO + UNDO/REDO + FIX HUECOS + OSNAP REVIT + GANCHOS NATIVOS.
    // MYGCommands.cs y el puente AceroLosasForm NO SE MODIFICAN.
    // =====================================================================
    public class EjecutarAceroLosasHandler : IExternalEventHandler
    {
        public static void Abrir(UIDocument uidoc, List<RebarBarType> tiposBarra)
        {
            if (uidoc == null) return;

            EjecutarAceroLosasHandler h = new EjecutarAceroLosasHandler();
            h._uidoc = uidoc;
            ExternalEvent ev = ExternalEvent.Create(h);
            VentanaAceroLosas f = new VentanaAceroLosas(h, ev, tiposBarra);
            h._form = f;
            f.Show();
        }

        private UIDocument _uidoc;
        private VentanaAceroLosas _form;
        private Accion _accion = Accion.Ninguna;
        private readonly List<ElementId> _universo = new List<ElementId>();
        private readonly List<PreviewLosa> _previewGeneral = new List<PreviewLosa>();

        // Secciones de sólidos estructurales detectadas AUTOMATICAMENTE por
        // un plano horizontal imaginario en la mitad de cada Floor seleccionado.
        // El selector sigue aceptando UNICAMENTE Floors.
        private readonly List<PreviewSoporte> _previewSoportes = new List<PreviewSoporte>();

        // Cache del RebarHookType nativo de 90°.
        // Se busca una sola vez por handler/documento para no recorrer todos
        // los tipos de gancho en cada Rebar Set.
        private ElementId _gancho90IdCache = ElementId.InvalidElementId;
        private bool _gancho90Buscado = false;

        private readonly List<PanoData> _panos = new List<PanoData>();
        private int _panoActivoId = -1;
        private int _siguientePano = 1;

        // =================================================================
        // HISTORIAL GLOBAL DEL EDITOR
        // =================================================================
        // Cada entrada es un snapshot JSON completo:
        // - losas seleccionadas,
        // - boceto general,
        // - huecos,
        // - D1 / D2,
        // - diámetros / espaciamientos,
        // - recubrimientos / offset,
        // - reglas.
        //
        // Por eso DESHACER también puede revertir una carga de archivo.
        private readonly Stack<string> _undoEstados =
            new Stack<string>();

        private readonly Stack<string> _redoEstados =
            new Stack<string>();

        private bool _restaurandoEstado = false;

        // Evita crear dos Rebar Sets con exactamente la misma geometría
        // durante la ejecución de un mismo paño.
        private readonly HashSet<string> _firmasConjuntosActuales =
            new HashSet<string>(StringComparer.Ordinal);

        private const double TOL = 1e-8;
        private static readonly double TOL_UNION = UnitUtils.ConvertToInternalUnits(0.3, UnitTypeId.Centimeters);
        private static readonly double EPS_HOST = UnitUtils.ConvertToInternalUnits(0.05, UnitTypeId.Centimeters);

        // =============================================================
        // REGLA DE PENETRACION EN APOYOS
        // =============================================================
        // Una barra SOLO puede atravesar/entrar a un apoyo cuando llega
        // aproximadamente PERPENDICULAR a su cara resistente.
        //
        // Para VIGAS/MUROS:
        //   - perpendicular al eje longitudinal -> SE PERMITE entrar;
        //   - paralela/oblicua al eje longitudinal -> el apoyo BLOQUEA.
        //
        // Para PILARES:
        //   - se permite solamente si existe una cara del pilar cuyo borde
        //     sea aproximadamente perpendicular a la dirección de la barra.
        //
        // 25° significa que aceptamos 90° ± 25° como "perpendicular".
        private const double ANGULO_PERP_APOYO_GRADOS = 25.0;
        private static readonly double GAP_MAX_VIGA = UnitUtils.ConvertToInternalUnits(120.0, UnitTypeId.Centimeters);
        // Detección geométrica mediante un PLANO HORIZONTAL IMAGINARIO situado
        // en la mitad del espesor de cada Floor seleccionado.
        // Solo se consideran sólidos cuya geometría REAL atraviesa ese plano.
        private static readonly double TOL_PLANO_MEDIO = UnitUtils.ConvertToInternalUnits(0.05, UnitTypeId.Centimeters);
        private static readonly double TOL_ADYACENCIA_SOLIDOS = UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters);
        private static readonly double PREFILTRO_XY_PLANO = UnitUtils.ConvertToInternalUnits(10.0, UnitTypeId.Centimeters);

        // Limpieza de la red de apoyos en planta:
        // - evita pequeños huecos visuales entre vigas/columnas/muros
        // - no deforma la geometría a grandes distancias
        private static readonly double TOL_CONEXION_RED = UnitUtils.ConvertToInternalUnits(2.5, UnitTypeId.Centimeters);
        private static readonly double TOL_VERTICE_RED = UnitUtils.ConvertToInternalUnits(0.5, UnitTypeId.Centimeters);
        private static readonly double TOL_COLINEAL_RED = UnitUtils.ConvertToInternalUnits(0.2, UnitTypeId.Centimeters);

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = _uidoc ?? app.ActiveUIDocument;
            if (uidoc == null || _form == null || _form.IsDisposed) return;

            try
            {
                switch (_accion)
                {
                    case Accion.SeleccionarUniverso:
                        SeleccionarUniverso(uidoc, uidoc.Document);
                        break;
                    case Accion.CrearActivo:
                        CrearPanoActivo(uidoc.Document);
                        break;
                    case Accion.CrearTodos:
                        CrearTodos(uidoc.Document);
                        break;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException) { }
            catch (Exception ex)
            {
                TaskDialog.Show("MYG - Acero en Losas", "ERROR:\n\n" + ex.Message + "\n\n" + ex.StackTrace);
            }
            finally
            {
                _accion = Accion.Ninguna;
            }
        }

        public string GetName() { return "MYG - Acero en Losas - Boceto General"; }

        private void PedirUniverso()
        {
            _form.GuardarPanoActivo();
            _accion = Accion.SeleccionarUniverso;
            _form.ExternalEvent.Raise();
        }

        private void PedirCrearActivo()
        {
            _form.GuardarPanoActivo();
            _accion = Accion.CrearActivo;
            _form.ExternalEvent.Raise();
        }

        private void PedirCrearTodos()
        {
            _form.GuardarPanoActivo();
            _accion = Accion.CrearTodos;
            _form.ExternalEvent.Raise();
        }

        private PanoData PanoActivo()
        {
            return _panos.FirstOrDefault(x => x.Id == _panoActivoId);
        }

        // =====================================================================
        // HISTORIAL + GUARDAR / CARGAR DATA
        // =====================================================================

        private void RegistrarUndo()
        {
            if (_restaurandoEstado)
                return;

            string estado =
                SerializarEstadoActual();

            if (string.IsNullOrEmpty(
                    estado))
            {
                return;
            }

            if (_undoEstados.Count == 0 ||
                !string.Equals(
                    _undoEstados.Peek(),
                    estado,
                    StringComparison.Ordinal))
            {
                _undoEstados.Push(
                    estado);
            }

            _redoEstados.Clear();

            if (_form != null &&
                !_form.IsDisposed)
            {
                _form.ActualizarBotonesHistorial();
            }
        }

        private void DeshacerEstado()
        {
            if (_form == null ||
                _form.IsDisposed ||
                _undoEstados.Count == 0)
            {
                return;
            }

            _form.SincronizarUISinHistorial();
            _form.CancelarDibujoTemporalParaHistorial();

            string actual =
                SerializarEstadoActual();

            string anterior =
                _undoEstados.Pop();

            if (!string.IsNullOrEmpty(
                    actual))
            {
                _redoEstados.Push(
                    actual);
            }

            AplicarEstadoSerializado(
                anterior);

            _form.ActualizarBotonesHistorial();
        }

        private void RehacerEstado()
        {
            if (_form == null ||
                _form.IsDisposed ||
                _redoEstados.Count == 0)
            {
                return;
            }

            _form.SincronizarUISinHistorial();
            _form.CancelarDibujoTemporalParaHistorial();

            string actual =
                SerializarEstadoActual();

            string siguiente =
                _redoEstados.Pop();

            if (!string.IsNullOrEmpty(
                    actual))
            {
                _undoEstados.Push(
                    actual);
            }

            AplicarEstadoSerializado(
                siguiente);

            _form.ActualizarBotonesHistorial();
        }

        private bool PuedeDeshacer()
        {
            return
                _undoEstados.Count >
                0;
        }

        private bool PuedeRehacer()
        {
            return
                _redoEstados.Count >
                0;
        }

        private bool GuardarDataArchivo(
            string ruta,
            out string mensaje)
        {
            mensaje = "";

            if (string.IsNullOrWhiteSpace(
                    ruta))
            {
                mensaje =
                    "Ruta de archivo no válida.";

                return false;
            }

            try
            {
                if (_form != null &&
                    !_form.IsDisposed)
                {
                    _form.SincronizarUISinHistorial();
                }

                string json =
                    SerializarEstadoActual();

                File.WriteAllText(
                    ruta,
                    json,
                    new UTF8Encoding(
                        false));

                mensaje =
                    "Data guardada correctamente.";

                return true;
            }
            catch (Exception ex)
            {
                mensaje =
                    "No se pudo guardar la data.\n\n" +
                    ex.Message;

                return false;
            }
        }

        private bool CargarDataArchivo(
            string ruta,
            out string mensaje)
        {
            mensaje = "";

            if (string.IsNullOrWhiteSpace(
                    ruta) ||
                !File.Exists(ruta))
            {
                mensaje =
                    "No se encontró el archivo.";

                return false;
            }

            try
            {
                string json =
                    File.ReadAllText(
                        ruta,
                        Encoding.UTF8);

                EstadoEditorData estado =
                    DeserializarEstado(
                        json);

                if (estado == null)
                {
                    mensaje =
                        "El archivo no contiene una data válida de MYG - Acero en Losas.";

                    return false;
                }

                if (_form != null &&
                    !_form.IsDisposed)
                {
                    _form.SincronizarUISinHistorial();
                    _form.CancelarDibujoTemporalParaHistorial();
                }

                // La carga se considera UNA operación reversible.
                // Por tanto, DESHACER recupera exactamente el estado previo.
                RegistrarUndo();

                int faltantes =
                    AplicarEstado(
                        estado);

                mensaje =
                    "Data cargada correctamente." +
                    (
                        faltantes > 0
                        ? "\n\nNo se pudieron recuperar " +
                          faltantes +
                          " losas del archivo. El boceto y los huecos sí fueron restaurados."
                        : ""
                    );

                if (_form != null &&
                    !_form.IsDisposed)
                {
                    _form.ActualizarBotonesHistorial();
                }

                return true;
            }
            catch (Exception ex)
            {
                mensaje =
                    "No se pudo cargar la data.\n\n" +
                    ex.Message;

                return false;
            }
        }

        private string SerializarEstadoActual()
        {
            return SerializarEstadoJson(
                CapturarEstado());
        }

        private EstadoEditorData DeserializarEstado(
            string json)
        {
            if (string.IsNullOrWhiteSpace(json))
                return null;

            return DeserializarEstadoJson(json);
        }

        // =================================================================
        // JSON AUTOCONTENIDO SIN ENSAMBLADOS ADICIONALES
        // =================================================================
        // Guardar/Cargar Data no depende de librerías JSON externas ni de
        // atributos de serialización. Esto evita agregar referencias nuevas
        // al proyecto del add-in.
        // =================================================================

        private string SerializarEstadoJson(EstadoEditorData estado)
        {
            if (estado == null)
                return "{}";

            StringBuilder sb = new StringBuilder(8192);
            sb.Append("{");
            JsonPropiedadCadena(sb, "Version", estado.Version, true);
            sb.Append(",\"Losas\":[");

            if (estado.Losas != null)
            {
                for (int i = 0; i < estado.Losas.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    ReferenciaLosaData l = estado.Losas[i];
                    if (l == null)
                    {
                        sb.Append("null");
                        continue;
                    }
                    sb.Append("{\"ElementId\":");
                    sb.Append(l.ElementId.ToString(CultureInfo.InvariantCulture));
                    sb.Append(",");
                    JsonPropiedadCadena(sb, "UniqueId", l.UniqueId, true);
                    sb.Append("}");
                }
            }

            sb.Append("]");
            sb.Append(",\"Boceto\":");
            SerializarBocetoJson(sb, estado.Boceto);
            sb.Append("}");
            return sb.ToString();
        }

        private void SerializarBocetoJson(StringBuilder sb, BocetoEditorData b)
        {
            if (b == null)
            {
                sb.Append("null");
                return;
            }

            sb.Append("{");
            JsonPropiedadCadena(sb, "Nombre", b.Nombre, true);
            JsonPropiedadBool(sb, "EsPoligonal", b.EsPoligonal);

            sb.Append(",\"Rectangulo\":");
            SerializarListaPuntosJson(sb, b.Rectangulo);

            sb.Append(",\"Huecos\":[");
            if (b.Huecos != null)
            {
                for (int i = 0; i < b.Huecos.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    SerializarListaPuntosJson(sb, b.Huecos[i]);
                }
            }
            sb.Append("]");

            sb.Append(",\"D1\":"); SerializarPuntoJson(sb, b.D1);
            sb.Append(",\"D1A\":"); SerializarPuntoJson(sb, b.D1A);
            sb.Append(",\"D1B\":"); SerializarPuntoJson(sb, b.D1B);
            sb.Append(",\"D2\":"); SerializarPuntoJson(sb, b.D2);
            sb.Append(",\"D2A\":"); SerializarPuntoJson(sb, b.D2A);
            sb.Append(",\"D2B\":"); SerializarPuntoJson(sb, b.D2B);

            JsonPropiedadBool(sb, "D1Definida", b.D1Definida);
            JsonPropiedadBool(sb, "D2Definida", b.D2Definida);
            JsonPropiedadBool(sb, "D2Auto", b.D2Auto);
            JsonPropiedadBool(sb, "CrearInfD1", b.CrearInfD1);
            JsonPropiedadBool(sb, "CrearInfD2", b.CrearInfD2);
            JsonPropiedadBool(sb, "CrearSupD1", b.CrearSupD1);
            JsonPropiedadBool(sb, "CrearSupD2", b.CrearSupD2);

            sb.Append(",\"TipoInfD1\":"); SerializarTipoJson(sb, b.TipoInfD1);
            sb.Append(",\"TipoInfD2\":"); SerializarTipoJson(sb, b.TipoInfD2);
            sb.Append(",\"TipoSupD1\":"); SerializarTipoJson(sb, b.TipoSupD1);
            sb.Append(",\"TipoSupD2\":"); SerializarTipoJson(sb, b.TipoSupD2);

            JsonPropiedadNumero(sb, "EspInfD1Cm", b.EspInfD1Cm);
            JsonPropiedadNumero(sb, "EspInfD2Cm", b.EspInfD2Cm);
            JsonPropiedadNumero(sb, "EspSupD1Cm", b.EspSupD1Cm);
            JsonPropiedadNumero(sb, "EspSupD2Cm", b.EspSupD2Cm);
            JsonPropiedadNumero(sb, "RecInfCm", b.RecInfCm);
            JsonPropiedadNumero(sb, "RecSupCm", b.RecSupCm);
            JsonPropiedadNumero(sb, "OffsetBocetoCm", b.OffsetBocetoCm);
            JsonPropiedadBool(sb, "AtravesarVigas", b.AtravesarVigas);
            JsonPropiedadBool(sb, "RespetarHuecos", b.RespetarHuecos);
            sb.Append("}");
        }

        private void SerializarListaPuntosJson(StringBuilder sb, List<PuntoData> puntos)
        {
            sb.Append("[");
            if (puntos != null)
            {
                for (int i = 0; i < puntos.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    SerializarPuntoJson(sb, puntos[i]);
                }
            }
            sb.Append("]");
        }

        private void SerializarPuntoJson(StringBuilder sb, PuntoData p)
        {
            if (p == null)
            {
                sb.Append("null");
                return;
            }
            sb.Append("{\"X\":");
            sb.Append(p.X.ToString("R", CultureInfo.InvariantCulture));
            sb.Append(",\"Y\":");
            sb.Append(p.Y.ToString("R", CultureInfo.InvariantCulture));
            sb.Append(",\"Z\":");
            sb.Append(p.Z.ToString("R", CultureInfo.InvariantCulture));
            sb.Append("}");
        }

        private void SerializarTipoJson(StringBuilder sb, ReferenciaTipoData r)
        {
            if (r == null)
            {
                sb.Append("null");
                return;
            }
            sb.Append("{\"ElementId\":");
            sb.Append(r.ElementId.ToString(CultureInfo.InvariantCulture));
            sb.Append(",");
            JsonPropiedadCadena(sb, "Nombre", r.Nombre, true);
            sb.Append("}");
        }

        private void JsonPropiedadCadena(StringBuilder sb, string nombre, string valor, bool sinComaInicial)
        {
            if (!sinComaInicial) sb.Append(",");
            sb.Append("\""); sb.Append(JsonEscape(nombre)); sb.Append("\":\"");
            sb.Append(JsonEscape(valor ?? "")); sb.Append("\"");
        }

        private void JsonPropiedadBool(StringBuilder sb, string nombre, bool valor)
        {
            sb.Append(",\""); sb.Append(JsonEscape(nombre)); sb.Append("\":");
            sb.Append(valor ? "true" : "false");
        }

        private void JsonPropiedadNumero(StringBuilder sb, string nombre, double valor)
        {
            sb.Append(",\""); sb.Append(JsonEscape(nombre)); sb.Append("\":");
            sb.Append(valor.ToString("R", CultureInfo.InvariantCulture));
        }

        private string JsonEscape(string texto)
        {
            if (string.IsNullOrEmpty(texto)) return "";
            StringBuilder sb = new StringBuilder(texto.Length + 16);
            foreach (char c in texto)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < 32)
                            sb.Append("\\u" + ((int)c).ToString("x4", CultureInfo.InvariantCulture));
                        else
                            sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }

        private EstadoEditorData DeserializarEstadoJson(string json)
        {
            object rootObj = new MiniJsonParser(json).Parse();
            Dictionary<string, object> root = rootObj as Dictionary<string, object>;
            if (root == null) return null;

            EstadoEditorData e = new EstadoEditorData();
            e.Version = JsonString(root, "Version", "");

            List<object> losas = JsonArray(root, "Losas");
            if (losas != null)
            {
                foreach (object item in losas)
                {
                    Dictionary<string, object> d = item as Dictionary<string, object>;
                    if (d == null) continue;
                    e.Losas.Add(new ReferenciaLosaData
                    {
                        ElementId = JsonLong(d, "ElementId", 0),
                        UniqueId = JsonString(d, "UniqueId", "")
                    });
                }
            }

            Dictionary<string, object> boceto = JsonObject(root, "Boceto");
            if (boceto != null)
                e.Boceto = DeserializarBocetoJson(boceto);
            return e;
        }

        private BocetoEditorData DeserializarBocetoJson(Dictionary<string, object> d)
        {
            if (d == null) return null;
            BocetoEditorData b = new BocetoEditorData();
            b.Nombre = JsonString(d, "Nombre", "BOCETO GENERAL");
            b.EsPoligonal = JsonBool(d, "EsPoligonal", true);
            b.Rectangulo = DeserializarListaPuntosJson(JsonArray(d, "Rectangulo"));

            List<object> huecos = JsonArray(d, "Huecos");
            if (huecos != null)
            {
                foreach (object h in huecos)
                {
                    List<object> lista = h as List<object>;
                    if (lista != null)
                        b.Huecos.Add(DeserializarListaPuntosJson(lista));
                }
            }

            b.D1 = DeserializarPuntoJson(JsonObject(d, "D1"));
            b.D1A = DeserializarPuntoJson(JsonObject(d, "D1A"));
            b.D1B = DeserializarPuntoJson(JsonObject(d, "D1B"));
            b.D2 = DeserializarPuntoJson(JsonObject(d, "D2"));
            b.D2A = DeserializarPuntoJson(JsonObject(d, "D2A"));
            b.D2B = DeserializarPuntoJson(JsonObject(d, "D2B"));
            b.D1Definida = JsonBool(d, "D1Definida", false);
            b.D2Definida = JsonBool(d, "D2Definida", false);
            b.D2Auto = JsonBool(d, "D2Auto", true);
            b.CrearInfD1 = JsonBool(d, "CrearInfD1", true);
            b.CrearInfD2 = JsonBool(d, "CrearInfD2", true);
            b.CrearSupD1 = JsonBool(d, "CrearSupD1", true);
            b.CrearSupD2 = JsonBool(d, "CrearSupD2", true);
            b.TipoInfD1 = DeserializarTipoJson(JsonObject(d, "TipoInfD1"));
            b.TipoInfD2 = DeserializarTipoJson(JsonObject(d, "TipoInfD2"));
            b.TipoSupD1 = DeserializarTipoJson(JsonObject(d, "TipoSupD1"));
            b.TipoSupD2 = DeserializarTipoJson(JsonObject(d, "TipoSupD2"));
            b.EspInfD1Cm = JsonDouble(d, "EspInfD1Cm", 20.0);
            b.EspInfD2Cm = JsonDouble(d, "EspInfD2Cm", 20.0);
            b.EspSupD1Cm = JsonDouble(d, "EspSupD1Cm", 20.0);
            b.EspSupD2Cm = JsonDouble(d, "EspSupD2Cm", 20.0);
            b.RecInfCm = JsonDouble(d, "RecInfCm", 2.5);
            b.RecSupCm = JsonDouble(d, "RecSupCm", 2.5);
            b.OffsetBocetoCm = JsonDouble(d, "OffsetBocetoCm", 2.5);
            b.AtravesarVigas = JsonBool(d, "AtravesarVigas", true);
            b.RespetarHuecos = JsonBool(d, "RespetarHuecos", true);
            return b;
        }

        private List<PuntoData> DeserializarListaPuntosJson(List<object> lista)
        {
            List<PuntoData> r = new List<PuntoData>();
            if (lista == null) return r;
            foreach (object item in lista)
            {
                PuntoData p = DeserializarPuntoJson(item as Dictionary<string, object>);
                if (p != null) r.Add(p);
            }
            return r;
        }

        private PuntoData DeserializarPuntoJson(Dictionary<string, object> d)
        {
            if (d == null) return null;
            return new PuntoData
            {
                X = JsonDouble(d, "X", 0.0),
                Y = JsonDouble(d, "Y", 0.0),
                Z = JsonDouble(d, "Z", 0.0)
            };
        }

        private ReferenciaTipoData DeserializarTipoJson(Dictionary<string, object> d)
        {
            if (d == null) return null;
            return new ReferenciaTipoData
            {
                ElementId = JsonLong(d, "ElementId", 0),
                Nombre = JsonString(d, "Nombre", "")
            };
        }

        private Dictionary<string, object> JsonObject(Dictionary<string, object> d, string key)
        {
            if (d == null) return null;
            object v;
            return d.TryGetValue(key, out v) ? v as Dictionary<string, object> : null;
        }

        private List<object> JsonArray(Dictionary<string, object> d, string key)
        {
            if (d == null) return null;
            object v;
            return d.TryGetValue(key, out v) ? v as List<object> : null;
        }

        private string JsonString(Dictionary<string, object> d, string key, string def)
        {
            object v;
            if (d == null || !d.TryGetValue(key, out v) || v == null) return def;
            string s = v as string;
            return s ?? Convert.ToString(v, CultureInfo.InvariantCulture) ?? def;
        }

        private bool JsonBool(Dictionary<string, object> d, string key, bool def)
        {
            object v;
            if (d == null || !d.TryGetValue(key, out v) || v == null) return def;
            if (v is bool) return (bool)v;
            bool r;
            return bool.TryParse(Convert.ToString(v, CultureInfo.InvariantCulture), out r) ? r : def;
        }

        private double JsonDouble(Dictionary<string, object> d, string key, double def)
        {
            object v;
            if (d == null || !d.TryGetValue(key, out v) || v == null) return def;
            if (v is double) return (double)v;
            if (v is long) return (double)(long)v;
            if (v is int) return (double)(int)v;
            double r;
            return double.TryParse(Convert.ToString(v, CultureInfo.InvariantCulture), NumberStyles.Float,
                CultureInfo.InvariantCulture, out r) ? r : def;
        }

        private long JsonLong(Dictionary<string, object> d, string key, long def)
        {
            object v;
            if (d == null || !d.TryGetValue(key, out v) || v == null) return def;
            if (v is long) return (long)v;
            if (v is int) return (long)(int)v;
            long r;
            if (long.TryParse(Convert.ToString(v, CultureInfo.InvariantCulture), NumberStyles.Integer,
                CultureInfo.InvariantCulture, out r)) return r;
            return (long)JsonDouble(d, key, def);
        }

        private sealed class MiniJsonParser
        {
            private readonly string _s;
            private int _i;

            internal MiniJsonParser(string s)
            {
                _s = s ?? "";
                _i = 0;
            }

            internal object Parse()
            {
                Skip();
                object value = Value();
                Skip();
                if (_i != _s.Length)
                    throw new FormatException("JSON inválido: caracteres sobrantes al final.");
                return value;
            }

            private object Value()
            {
                Skip();
                if (_i >= _s.Length) throw new FormatException("JSON incompleto.");
                char c = _s[_i];
                if (c == '{') return ObjectValue();
                if (c == '[') return ArrayValue();
                if (c == '"') return StringValue();
                if (c == '-' || c == '+' || char.IsDigit(c)) return NumberValue();
                if (Match("true")) { _i += 4; return true; }
                if (Match("false")) { _i += 5; return false; }
                if (Match("null")) { _i += 4; return null; }
                throw new FormatException("JSON inválido en posición " + _i.ToString(CultureInfo.InvariantCulture) + ".");
            }

            private Dictionary<string, object> ObjectValue()
            {
                Dictionary<string, object> d = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                Expect('{');
                Skip();
                if (Take('}')) return d;
                while (true)
                {
                    string key = StringValue();
                    Skip(); Expect(':');
                    d[key] = Value();
                    Skip();
                    if (Take('}')) break;
                    Expect(',');
                }
                return d;
            }

            private List<object> ArrayValue()
            {
                List<object> r = new List<object>();
                Expect('[');
                Skip();
                if (Take(']')) return r;
                while (true)
                {
                    r.Add(Value());
                    Skip();
                    if (Take(']')) break;
                    Expect(',');
                }
                return r;
            }

            private string StringValue()
            {
                Skip(); Expect('"');
                StringBuilder sb = new StringBuilder();
                while (_i < _s.Length)
                {
                    char c = _s[_i++];
                    if (c == '"') return sb.ToString();
                    if (c != '\\') { sb.Append(c); continue; }
                    if (_i >= _s.Length) throw new FormatException("Escape JSON incompleto.");
                    char e = _s[_i++];
                    switch (e)
                    {
                        case '"': sb.Append('"'); break;
                        case '\\': sb.Append('\\'); break;
                        case '/': sb.Append('/'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'n': sb.Append('\n'); break;
                        case 'r': sb.Append('\r'); break;
                        case 't': sb.Append('\t'); break;
                        case 'u':
                            if (_i + 4 > _s.Length) throw new FormatException("Escape Unicode incompleto.");
                            string hex = _s.Substring(_i, 4);
                            int code;
                            if (!int.TryParse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out code))
                                throw new FormatException("Escape Unicode inválido.");
                            sb.Append((char)code); _i += 4; break;
                        default: throw new FormatException("Escape JSON no reconocido.");
                    }
                }
                throw new FormatException("Cadena JSON sin cerrar.");
            }

            private object NumberValue()
            {
                int start = _i;
                if (_i < _s.Length && (_s[_i] == '-' || _s[_i] == '+')) _i++;
                while (_i < _s.Length && char.IsDigit(_s[_i])) _i++;
                bool real = false;
                if (_i < _s.Length && _s[_i] == '.')
                {
                    real = true; _i++;
                    while (_i < _s.Length && char.IsDigit(_s[_i])) _i++;
                }
                if (_i < _s.Length && (_s[_i] == 'e' || _s[_i] == 'E'))
                {
                    real = true; _i++;
                    if (_i < _s.Length && (_s[_i] == '+' || _s[_i] == '-')) _i++;
                    while (_i < _s.Length && char.IsDigit(_s[_i])) _i++;
                }
                string token = _s.Substring(start, _i - start);
                if (!real)
                {
                    long l;
                    if (long.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out l)) return l;
                }
                double d;
                if (!double.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out d))
                    throw new FormatException("Número JSON inválido: " + token);
                return d;
            }

            private void Skip()
            {
                while (_i < _s.Length && char.IsWhiteSpace(_s[_i])) _i++;
            }

            private bool Match(string x)
            {
                if (_i + x.Length > _s.Length) return false;
                return string.Compare(_s, _i, x, 0, x.Length, StringComparison.Ordinal) == 0;
            }

            private bool Take(char c)
            {
                Skip();
                if (_i < _s.Length && _s[_i] == c) { _i++; return true; }
                return false;
            }

            private void Expect(char c)
            {
                Skip();
                if (_i >= _s.Length || _s[_i] != c)
                    throw new FormatException("JSON inválido: se esperaba '" + c + "' en posición " +
                        _i.ToString(CultureInfo.InvariantCulture) + ".");
                _i++;
            }
        }

        private void AplicarEstadoSerializado(
            string json)
        {
            EstadoEditorData estado =
                DeserializarEstado(
                    json);

            if (estado == null)
                return;

            AplicarEstado(
                estado);
        }

        private EstadoEditorData CapturarEstado()
        {
            EstadoEditorData e =
                new EstadoEditorData();

            e.Version =
                "MYG_ACERO_LOSAS_2027_V1";

            Document doc =
                _uidoc == null
                ? null
                : _uidoc.Document;

            foreach (ElementId id
                in _universo)
            {
                if (id == null)
                    continue;

                Element el =
                    doc == null
                    ? null
                    : doc.GetElement(id);

                e.Losas.Add(
                    new ReferenciaLosaData
                    {
                        ElementId =
                            id.Value,

                        UniqueId =
                            el == null
                            ? ""
                            : el.UniqueId
                    });
            }

            PanoData p =
                PanoActivo();

            if (p != null)
            {
                e.Boceto =
                    CapturarBoceto(
                        p,
                        doc);
            }

            return e;
        }

        private BocetoEditorData CapturarBoceto(
            PanoData p,
            Document doc)
        {
            BocetoEditorData b =
                new BocetoEditorData();

            if (p == null)
                return b;

            b.Nombre =
                p.Nombre ??
                "BOCETO GENERAL";

            b.EsPoligonal =
                p.EsPoligonal;

            b.Rectangulo =
                AListaPuntosData(
                    p.Rectangulo);

            foreach (List<XYZ> h
                in p.HuecosManuales)
            {
                b.Huecos.Add(
                    AListaPuntosData(
                        h));
            }

            b.D1 =
                APuntoData(p.D1);

            b.D1A =
                APuntoData(p.D1A);

            b.D1B =
                APuntoData(p.D1B);

            b.D2 =
                APuntoData(p.D2);

            b.D2A =
                APuntoData(p.D2A);

            b.D2B =
                APuntoData(p.D2B);

            b.D1Definida =
                p.D1Definida;

            b.D2Definida =
                p.D2Definida;

            b.D2Auto =
                p.D2Auto;

            b.CrearInfD1 =
                p.CrearInfD1;

            b.CrearInfD2 =
                p.CrearInfD2;

            b.CrearSupD1 =
                p.CrearSupD1;

            b.CrearSupD2 =
                p.CrearSupD2;

            b.TipoInfD1 =
                CrearReferenciaTipo(
                    doc,
                    p.TipoInfD1Id);

            b.TipoInfD2 =
                CrearReferenciaTipo(
                    doc,
                    p.TipoInfD2Id);

            b.TipoSupD1 =
                CrearReferenciaTipo(
                    doc,
                    p.TipoSupD1Id);

            b.TipoSupD2 =
                CrearReferenciaTipo(
                    doc,
                    p.TipoSupD2Id);

            b.EspInfD1Cm =
                p.EspInfD1Cm;

            b.EspInfD2Cm =
                p.EspInfD2Cm;

            b.EspSupD1Cm =
                p.EspSupD1Cm;

            b.EspSupD2Cm =
                p.EspSupD2Cm;

            b.RecInfCm =
                p.RecInfCm;

            b.RecSupCm =
                p.RecSupCm;

            b.OffsetBocetoCm =
                p.RecLatCm;

            b.AtravesarVigas =
                p.AtravesarVigas;

            b.RespetarHuecos =
                p.RespetarHuecos;

            return b;
        }

        private ReferenciaTipoData CrearReferenciaTipo(
            Document doc,
            ElementId id)
        {
            ReferenciaTipoData r =
                new ReferenciaTipoData();

            if (id == null ||
                id == ElementId.InvalidElementId)
            {
                return r;
            }

            r.ElementId =
                id.Value;

            try
            {
                Element e =
                    doc == null
                    ? null
                    : doc.GetElement(id);

                r.Nombre =
                    e == null
                    ? ""
                    : e.Name;
            }
            catch
            {
            }

            return r;
        }

        private int AplicarEstado(
            EstadoEditorData estado)
        {
            if (estado == null)
                return 0;

            Document doc =
                _uidoc == null
                ? null
                : _uidoc.Document;

            if (doc == null)
                return 0;

            _restaurandoEstado =
                true;

            int faltantes =
                0;

            try
            {
                _universo.Clear();
                _previewGeneral.Clear();
                _previewSoportes.Clear();
                _panos.Clear();

                _panoActivoId =
                    -1;

                _siguientePano =
                    1;

                if (estado.Losas != null)
                {
                    foreach (ReferenciaLosaData refLosa
                        in estado.Losas)
                    {
                        if (refLosa == null)
                            continue;

                        Element el =
                            null;

                        if (!string.IsNullOrWhiteSpace(
                                refLosa.UniqueId))
                        {
                            try
                            {
                                el =
                                    doc.GetElement(
                                        refLosa.UniqueId);
                            }
                            catch
                            {
                            }
                        }

                        if (el == null &&
                            refLosa.ElementId != 0)
                        {
                            try
                            {
                                el =
                                    doc.GetElement(
                                        new ElementId(
                                            refLosa.ElementId));
                            }
                            catch
                            {
                            }
                        }

                        Floor floor =
                            el as Floor;

                        if (floor == null)
                        {
                            faltantes++;
                            continue;
                        }

                        if (!_universo.Any(
                                x =>
                                    x.Value ==
                                    floor.Id.Value))
                        {
                            _universo.Add(
                                floor.Id);
                        }
                    }
                }

                foreach (ElementId id
                    in _universo)
                {
                    PreviewLosa pv =
                        CrearPreview(
                            doc.GetElement(id)
                            as Floor);

                    if (pv != null)
                        _previewGeneral.Add(pv);
                }

                DetectarSoportesAdyacentes(
                    doc);

                if (estado.Boceto != null &&
                    estado.Boceto.Rectangulo != null &&
                    estado.Boceto.Rectangulo.Count >= 3)
                {
                    PanoData p =
                        RestaurarBoceto(
                            estado.Boceto,
                            doc);

                    if (p != null)
                    {
                        _panos.Add(p);

                        _panoActivoId =
                            p.Id;
                    }
                }

                if (_form != null &&
                    !_form.IsDisposed)
                {
                    _form.ActualizarUniverso(
                        _universo.Count);

                    _form.RefrescarBotonesPanos();

                    PanoData activo =
                        PanoActivo();

                    if (activo != null)
                        _form.CargarPano(activo);
                    else
                        _form.LimpiarPanoActivo();

                    _form.AjustarPreview();
                }
            }
            finally
            {
                _restaurandoEstado =
                    false;
            }

            return faltantes;
        }

        private PanoData RestaurarBoceto(
            BocetoEditorData b,
            Document doc)
        {
            if (b == null ||
                b.Rectangulo == null ||
                b.Rectangulo.Count < 3)
            {
                return null;
            }

            PanoData p =
                new PanoData();

            p.Id =
                1;

            p.Nombre =
                string.IsNullOrWhiteSpace(
                    b.Nombre)
                ? "BOCETO GENERAL"
                : b.Nombre;

            p.EsPoligonal =
                true;

            foreach (PuntoData q
                in b.Rectangulo)
            {
                XYZ x =
                    AXYZ(q);

                if (x != null)
                    p.Rectangulo.Add(x);
            }

            foreach (List<PuntoData> h
                in b.Huecos)
            {
                List<XYZ> loop =
                    new List<XYZ>();

                if (h != null)
                {
                    foreach (PuntoData q
                        in h)
                    {
                        XYZ x =
                            AXYZ(q);

                        if (x != null)
                            loop.Add(x);
                    }
                }

                if (loop.Count >= 3)
                    p.HuecosManuales.Add(loop);
            }

            if (p.Rectangulo.Count < 3)
                return null;

            Box2 box =
                BoundingXY(
                    p.Rectangulo);

            p.RectP1 =
                new XYZ(
                    box.MinX,
                    box.MinY,
                    0.0);

            p.RectP2 =
                new XYZ(
                    box.MaxX,
                    box.MaxY,
                    0.0);

            p.CentroRect =
                CentroidePoligonoXY(
                    p.Rectangulo);

            foreach (PreviewLosa pv
                in _previewGeneral)
            {
                if (pv == null ||
                    pv.Exterior == null ||
                    pv.Exterior.Count < 3)
                {
                    continue;
                }

                if (PoligonosIntersectanXY(
                        p.Rectangulo,
                        pv.Exterior))
                {
                    p.Losas.Add(
                        pv.LosaId);

                    p.Preview.Add(
                        pv);
                }
            }

            p.D1 =
                AXYZ(b.D1);

            p.D1A =
                AXYZ(b.D1A);

            p.D1B =
                AXYZ(b.D1B);

            p.D2 =
                AXYZ(b.D2);

            p.D2A =
                AXYZ(b.D2A);

            p.D2B =
                AXYZ(b.D2B);

            p.D1Definida =
                b.D1Definida &&
                p.D1 != null &&
                p.D1A != null &&
                p.D1B != null;

            p.D2Definida =
                b.D2Definida &&
                p.D2 != null &&
                p.D2A != null &&
                p.D2B != null;

            p.D2Auto =
                b.D2Auto;

            p.CrearInfD1 =
                b.CrearInfD1;

            p.CrearInfD2 =
                b.CrearInfD2;

            p.CrearSupD1 =
                b.CrearSupD1;

            p.CrearSupD2 =
                b.CrearSupD2;

            p.TipoInfD1Id =
                ResolverTipoId(
                    doc,
                    b.TipoInfD1);

            p.TipoInfD2Id =
                ResolverTipoId(
                    doc,
                    b.TipoInfD2);

            p.TipoSupD1Id =
                ResolverTipoId(
                    doc,
                    b.TipoSupD1);

            p.TipoSupD2Id =
                ResolverTipoId(
                    doc,
                    b.TipoSupD2);

            p.EspInfD1Cm =
                b.EspInfD1Cm;

            p.EspInfD2Cm =
                b.EspInfD2Cm;

            p.EspSupD1Cm =
                b.EspSupD1Cm;

            p.EspSupD2Cm =
                b.EspSupD2Cm;

            p.RecInfCm =
                b.RecInfCm;

            p.RecSupCm =
                b.RecSupCm;

            p.RecLatCm =
                b.OffsetBocetoCm;

            p.AtravesarVigas =
                b.AtravesarVigas;

            p.RespetarHuecos =
                b.RespetarHuecos;

            AsegurarDireccionesAutomaticas(
                p);

            return p;
        }

        private ElementId ResolverTipoId(
            Document doc,
            ReferenciaTipoData referencia)
        {
            if (referencia == null)
                return ElementId.InvalidElementId;

            if (referencia.ElementId != 0)
            {
                try
                {
                    RebarBarType porId =
                        doc.GetElement(
                            new ElementId(
                                referencia.ElementId))
                        as RebarBarType;

                    if (porId != null)
                        return porId.Id;
                }
                catch
                {
                }
            }

            if (!string.IsNullOrWhiteSpace(
                    referencia.Nombre))
            {
                RebarBarType porNombre =
                    new FilteredElementCollector(doc)
                        .OfClass(typeof(RebarBarType))
                        .Cast<RebarBarType>()
                        .FirstOrDefault(
                            x =>
                                x != null &&
                                string.Equals(
                                    x.Name,
                                    referencia.Nombre,
                                    StringComparison.OrdinalIgnoreCase));

                if (porNombre != null)
                    return porNombre.Id;
            }

            return ElementId.InvalidElementId;
        }

        private List<PuntoData> AListaPuntosData(
            IEnumerable<XYZ> puntos)
        {
            List<PuntoData> r =
                new List<PuntoData>();

            if (puntos == null)
                return r;

            foreach (XYZ p
                in puntos)
            {
                PuntoData q =
                    APuntoData(p);

                if (q != null)
                    r.Add(q);
            }

            return r;
        }

        private PuntoData APuntoData(
            XYZ p)
        {
            if (p == null)
                return null;

            return
                new PuntoData
                {
                    X = p.X,
                    Y = p.Y,
                    Z = p.Z
                };
        }

        private XYZ AXYZ(
            PuntoData p)
        {
            if (p == null)
                return null;

            return
                new XYZ(
                    p.X,
                    p.Y,
                    p.Z);
        }

        private void ActivarPano(int id)
        {
            PanoData p = _panos.FirstOrDefault(x => x.Id == id);
            if (p == null) return;
            _form.GuardarPanoActivo();
            _panoActivoId = id;
            _form.CargarPano(p);
            _form.RefrescarBotonesPanos();
            _form.InvalidarPreview();
        }

        private void EliminarPanoActivo()
        {
            PanoData p = PanoActivo();
            if (p == null) return;

            RegistrarUndo();

            _panos.Remove(p);
            _panoActivoId = _panos.Count == 0 ? -1 : _panos[_panos.Count - 1].Id;
            _form.RefrescarBotonesPanos();
            if (PanoActivo() != null) _form.CargarPano(PanoActivo());
            else _form.LimpiarPanoActivo();
            _form.InvalidarPreview();
        }

        // =====================================================================
        // UNIVERSO Y PAÑOS
        // =====================================================================
        private void SeleccionarUniverso(UIDocument uidoc, Document doc)
        {
            if (_panos.Count > 0)
            {
                TaskDialog td = new TaskDialog("MYG - Acero en Losas");
                td.MainInstruction = "Cambiar la selección general eliminará el boceto general definido en memoria.";
                td.MainContent = "Los Rebar ya creados en el modelo no se eliminarán automáticamente. ¿Desea continuar?";
                td.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No;
                if (td.Show() != TaskDialogResult.Yes) return;
            }

            _form.TopMost = false;
            IList<Reference> refs;
            try
            {
                refs = uidoc.Selection.PickObjects(ObjectType.Element, new FiltroLosas(),
                    "Seleccione las losas que servirán como anfitriones del armado");
            }
            finally
            {
                if (!_form.IsDisposed) _form.TopMost = true;
            }

            if (refs == null || refs.Count == 0) return;

            RegistrarUndo();

            _universo.Clear();
            _previewGeneral.Clear();
            _previewSoportes.Clear();
            _panos.Clear();
            _panoActivoId = -1;
            _siguientePano = 1;

            foreach (Reference r in refs.Where(x => x != null))
                if (!_universo.Contains(r.ElementId)) _universo.Add(r.ElementId);

            foreach (ElementId id in _universo)
            {
                PreviewLosa pv = CrearPreview(doc.GetElement(id) as Floor);
                if (pv != null) _previewGeneral.Add(pv);
            }

            DetectarSoportesAdyacentes(doc);

            _form.ActualizarUniverso(_universo.Count);
            _form.RefrescarBotonesPanos();
            _form.LimpiarPanoActivo();
            _form.AjustarPreview();
        }

        // =====================================================================
        // DETECCION DE SOLIDOS ESTRUCTURALES MEDIANTE PLANO HORIZONTAL MEDIO
        // =====================================================================
        // IDEA:
        // 1) El usuario selecciona UNICAMENTE Floors.
        // 2) Para cada Floor se calcula Zmedio = (BoundingBox.Min.Z + Max.Z) / 2.
        // 3) Se imagina un plano horizontal infinito Z = Zmedio.
        // 4) Vigas, pilares estructurales y muros estructurales solo se aceptan
        //    si alguno de sus SOLIDOS REALES es cortado por ese plano.
        // 5) Del sólido cortado se obtiene su sección XY en ese nivel.
        // 6) La sección debe tocar/intersectar el Floor seleccionado, permitiendo
        //    una tolerancia pequeña de modelado (2 cm).
        //
        // Resultado:
        // - Ya NO aparecen elementos simplemente porque su BoundingBox está cerca.
        // - Un soporte de otro nivel no aparece si no cruza el plano medio.
        // - El preview/OSNAP usa la sección real del sólido en Zmedio.
        // =====================================================================
        private void DetectarSoportesAdyacentes(Document doc)
        {
            _previewSoportes.Clear();

            if (doc == null ||
                _previewGeneral.Count == 0 ||
                _universo.Count == 0)
            {
                return;
            }

            // =============================================================
            // IDEA DE ESTA VERSION
            // =============================================================
            // 1. El usuario selecciona SOLAMENTE Floors.
            // 2. Cada Floor define un plano imaginario Z = mitad de su espesor.
            // 3. Se seccionan los sólidos REALES de:
            //      - vigas estructurales
            //      - pilares estructurales
            //      - muros estructurales
            // 4. NO se mezclan secciones de distintas cotas Z.
            //
            // Ese último punto corrige el problema de la versión anterior:
            // antes se juntaban todos los puntos de un mismo elemento cortados
            // por varios Floors y luego se hacía un ConvexHull global.
            // En elementos inclinados, uniones o vigas con distinta geometría
            // eso producía trapecios, picos y polígonos deformados.
            //
            // Ahora cada corte se conserva como un polígono independiente,
            // se limpia, y al final se elige la sección REPRESENTATIVA del
            // elemento. Después se corrigen solamente pequeños huecos entre
            // elementos adyacentes.
            // =============================================================

            List<Element> candidatos =
                new List<Element>();

            candidatos.AddRange(
                new FilteredElementCollector(doc)
                    .OfCategory(BuiltInCategory.OST_StructuralFraming)
                    .WhereElementIsNotElementType()
                    .ToElements());

            candidatos.AddRange(
                new FilteredElementCollector(doc)
                    .OfCategory(BuiltInCategory.OST_StructuralColumns)
                    .WhereElementIsNotElementType()
                    .ToElements());

            candidatos.AddRange(
                new FilteredElementCollector(doc)
                    .OfCategory(BuiltInCategory.OST_Walls)
                    .WhereElementIsNotElementType()
                    .ToElements());

            Dictionary<long, BoundingBoxXYZ> cajas =
                new Dictionary<long, BoundingBoxXYZ>();

            Dictionary<long, Element> elementosValidos =
                new Dictionary<long, Element>();

            foreach (Element e in candidatos)
            {
                if (e == null)
                    continue;

                Wall muro = e as Wall;

                if (muro != null &&
                    !EsMuroEstructural(muro))
                {
                    continue;
                }

                BoundingBoxXYZ bb = null;

                try
                {
                    bb = e.get_BoundingBox(null);
                }
                catch
                {
                }

                if (bb == null)
                    continue;

                cajas[e.Id.Value] = bb;
                elementosValidos[e.Id.Value] = e;
            }

            Dictionary<long, List<SeccionSoporteCandidata>> candidatas =
                new Dictionary<long, List<SeccionSoporteCandidata>>();

            foreach (ElementId floorId in _universo)
            {
                Floor floor =
                    doc.GetElement(floorId)
                    as Floor;

                if (floor == null)
                    continue;

                PreviewLosa pvFloor =
                    _previewGeneral.FirstOrDefault(
                        x =>
                            x != null &&
                            x.LosaId != null &&
                            x.LosaId.Value == floor.Id.Value);

                if (pvFloor == null ||
                    pvFloor.Exterior == null ||
                    pvFloor.Exterior.Count < 3)
                {
                    continue;
                }

                BoundingBoxXYZ bbFloor = null;

                try
                {
                    bbFloor =
                        floor.get_BoundingBox(null);
                }
                catch
                {
                }

                if (bbFloor == null)
                    continue;

                double zMedio =
                    (bbFloor.Min.Z +
                     bbFloor.Max.Z) /
                    2.0;

                Box2 cajaFloorXY =
                    BoundingXY(
                        pvFloor.Exterior);

                foreach (KeyValuePair<long, Element> kv
                    in elementosValidos)
                {
                    Element e = kv.Value;

                    if (e == null ||
                        e.Id.Value == floor.Id.Value)
                    {
                        continue;
                    }

                    BoundingBoxXYZ bb;

                    if (!cajas.TryGetValue(
                            e.Id.Value,
                            out bb) ||
                        bb == null)
                    {
                        continue;
                    }

                    // El plano medio debe atravesar la caja del elemento.
                    if (zMedio <
                            bb.Min.Z -
                            TOL_PLANO_MEDIO ||
                        zMedio >
                            bb.Max.Z +
                            TOL_PLANO_MEDIO)
                    {
                        continue;
                    }

                    // Prefiltro XY solamente para evitar abrir geometrías
                    // completamente lejanas.
                    if (bb.Max.X <
                            cajaFloorXY.MinX -
                            PREFILTRO_XY_PLANO ||
                        bb.Min.X >
                            cajaFloorXY.MaxX +
                            PREFILTRO_XY_PLANO ||
                        bb.Max.Y <
                            cajaFloorXY.MinY -
                            PREFILTRO_XY_PLANO ||
                        bb.Min.Y >
                            cajaFloorXY.MaxY +
                            PREFILTRO_XY_PLANO)
                    {
                        continue;
                    }

                    List<List<XYZ>> secciones =
                        ObtenerSeccionesHorizontalesElemento(
                            e,
                            zMedio);

                    if (secciones.Count == 0)
                        continue;

                    foreach (List<XYZ> seccionRaw
                        in secciones)
                    {
                        List<XYZ> seccion =
                            LimpiarPoligonoSeccionExacta(
                                seccionRaw);

                        if (seccion == null ||
                            seccion.Count < 3)
                        {
                            continue;
                        }

                        double distancia =
                            DistanciaMinimaPoligonosXY(
                                seccion,
                                pvFloor.Exterior);

                        if (distancia >
                            TOL_ADYACENCIA_SOLIDOS)
                        {
                            continue;
                        }

                        double area =
                            Math.Abs(
                                AreaPoligonoXY(
                                    seccion));

                        if (area <= TOL)
                            continue;

                        List<SeccionSoporteCandidata> lista;

                        if (!candidatas.TryGetValue(
                                e.Id.Value,
                                out lista))
                        {
                            lista =
                                new List<SeccionSoporteCandidata>();

                            candidatas[e.Id.Value] =
                                lista;
                        }

                        // Evitar duplicados de la misma sección cuando dos
                        // Floors contiguos producen exactamente el mismo corte.
                        if (!ExisteSeccionEquivalente(
                                lista,
                                seccion,
                                zMedio))
                        {
                            lista.Add(
                                new SeccionSoporteCandidata
                                {
                                    Elemento = e,
                                    PlanoZ = zMedio,
                                    Poligono = seccion,
                                    Area = area,
                                    DistanciaALosa = distancia,
                                    Box = bb
                                });
                        }
                    }
                }
            }

            // =============================================================
            // UNA GEOMETRIA LIMPIA POR ELEMENTO
            // =============================================================
            foreach (KeyValuePair<long, List<SeccionSoporteCandidata>> kv
                in candidatas)
            {
                List<SeccionSoporteCandidata> lista =
                    kv.Value;

                if (lista == null ||
                    lista.Count == 0)
                {
                    continue;
                }

                Element e =
                    lista[0].Elemento;

                if (e == null)
                    continue;

                SeccionSoporteCandidata elegida =
                    ElegirSeccionRepresentativa(
                        lista,
                        TipoSoporte(e));

                if (elegida == null ||
                    elegida.Poligono == null ||
                    elegida.Poligono.Count < 3)
                {
                    continue;
                }

                _previewSoportes.Add(
                    new PreviewSoporte
                    {
                        ElementId = e.Id,
                        Tipo = TipoSoporte(e),
                        Exterior =
                            LimpiarPoligonoSeccionExacta(
                                elegida.Poligono),
                        Box = elegida.Box,
                        PlanoZ = elegida.PlanoZ
                    });
            }

            // =============================================================
            // CONEXION FINAL DE LA RED
            // =============================================================
            // Solo corrige huecos PEQUEÑOS de modelado.
            // No inventa vigas ni prolonga elementos varios centímetros.
            AjustarConexionRedSoportes();
        }

        private bool EsMuroEstructural(Wall muro)
        {
            if (muro == null)
                return false;

            try
            {
                Parameter p =
                    muro.get_Parameter(
                        BuiltInParameter
                            .WALL_STRUCTURAL_SIGNIFICANT);

                return
                    p != null &&
                    p.AsInteger() != 0;
            }
            catch
            {
                return false;
            }
        }

        private string TipoSoporte(Element e)
        {
            if (e == null ||
                e.Category == null)
            {
                return "APOYO";
            }

            long catId =
                e.Category.Id.Value;

            if (catId ==
                (long)BuiltInCategory
                    .OST_StructuralFraming)
            {
                return "VIGA";
            }

            if (catId ==
                (long)BuiltInCategory
                    .OST_StructuralColumns)
            {
                return "PILAR";
            }

            if (catId ==
                (long)BuiltInCategory
                    .OST_Walls)
            {
                return "MURO";
            }

            return "APOYO";
        }

        // =====================================================================
        // CORTE HORIZONTAL DE SOLIDOS
        // =====================================================================

        private List<List<XYZ>> ObtenerSeccionesHorizontalesElemento(
            Element elemento,
            double planoZ)
        {
            List<List<XYZ>> secciones =
                new List<List<XYZ>>();

            if (elemento == null)
                return secciones;

            try
            {
                Options op =
                    new Options
                    {
                        DetailLevel =
                            ViewDetailLevel.Fine,

                        IncludeNonVisibleObjects =
                            true,

                        ComputeReferences =
                            false
                    };

                GeometryElement geo =
                    elemento.get_Geometry(op);

                RecolectarSeccionesHorizontales(
                    geo,
                    planoZ,
                    secciones);
            }
            catch
            {
            }

            // Limpiar aquí también para que todo lo que salga de este método
            // ya sea utilizable en preview y OSNAP.
            List<List<XYZ>> limpias =
                new List<List<XYZ>>();

            foreach (List<XYZ> s
                in secciones)
            {
                List<XYZ> q =
                    LimpiarPoligonoSeccionExacta(
                        s);

                if (q != null &&
                    q.Count >= 3)
                {
                    limpias.Add(q);
                }
            }

            return limpias;
        }

        private void RecolectarSeccionesHorizontales(
            GeometryElement geo,
            double planoZ,
            List<List<XYZ>> secciones)
        {
            if (geo == null ||
                secciones == null)
            {
                return;
            }

            foreach (GeometryObject obj
                in geo)
            {
                Solid solid =
                    obj as Solid;

                if (solid != null)
                {
                    if (solid.Volume <= TOL ||
                        solid.Faces == null ||
                        solid.Faces.Size == 0)
                    {
                        continue;
                    }

                    // =====================================================
                    // IMPORTANTE:
                    // Ya NO se usa ConvexHull para reconstruir el corte.
                    //
                    // ConvexHull "saltaba" vértices cóncavos y convertía
                    // geometrías tipo T / L / escalonadas en triángulos o
                    // trapecios. Eso era exactamente lo que se veía mal
                    // en el preview.
                    //
                    // Ahora:
                    // 1) triangulamos las CARAS del sólido,
                    // 2) intersectamos cada triángulo con el plano Z,
                    // 3) obtenemos segmentos reales del corte,
                    // 4) cosemos los segmentos en loops cerrados.
                    //
                    // Así se conservan TODOS los cambios de dirección del
                    // contorno, incluidos los vértices cóncavos.
                    // =====================================================

                    List<List<XYZ>> loops =
                        SeccionarSolidHorizontalExacto(
                            solid,
                            planoZ);

                    foreach (List<XYZ> loop
                        in loops)
                    {
                        if (loop != null &&
                            loop.Count >= 3)
                        {
                            secciones.Add(loop);
                        }
                    }

                    continue;
                }

                GeometryInstance gi =
                    obj as GeometryInstance;

                if (gi != null)
                {
                    try
                    {
                        RecolectarSeccionesHorizontales(
                            gi.GetInstanceGeometry(),
                            planoZ,
                            secciones);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private List<List<XYZ>> SeccionarSolidHorizontalExacto(
            Solid solid,
            double planoZ)
        {
            List<List<XYZ>> resultado =
                new List<List<XYZ>>();

            if (solid == null ||
                solid.Faces == null ||
                solid.Faces.Size == 0)
            {
                return resultado;
            }

            List<SegmentoCortePlano> segmentos =
                new List<SegmentoCortePlano>();

            foreach (Face face
                in solid.Faces)
            {
                if (face == null)
                    continue;

                Mesh mesh = null;

                try
                {
                    mesh =
                        face.Triangulate();
                }
                catch
                {
                }

                if (mesh == null ||
                    mesh.NumTriangles <= 0)
                {
                    continue;
                }

                for (int i = 0;
                    i < mesh.NumTriangles;
                    i++)
                {
                    MeshTriangle tri = null;

                    try
                    {
                        tri =
                            mesh.get_Triangle(i);
                    }
                    catch
                    {
                    }

                    if (tri == null)
                        continue;

                    XYZ a = null;
                    XYZ b = null;
                    XYZ c = null;

                    try
                    {
                        a = tri.get_Vertex(0);
                        b = tri.get_Vertex(1);
                        c = tri.get_Vertex(2);
                    }
                    catch
                    {
                    }

                    if (a == null ||
                        b == null ||
                        c == null)
                    {
                        continue;
                    }

                    AgregarInterseccionTrianguloPlano(
                        segmentos,
                        a,
                        b,
                        c,
                        planoZ);
                }
            }

            if (segmentos.Count == 0)
                return resultado;

            // Eliminar segmentos repetidos generados por triángulos
            // adyacentes o por caras coincidentes.
            segmentos =
                EliminarSegmentosDuplicados(
                    segmentos);

            if (segmentos.Count == 0)
                return resultado;

            // Unificar extremos prácticamente coincidentes antes de armar
            // los loops. Esto hace que dos triángulos que llegan al mismo
            // vértice realmente compartan el MISMO nodo.
            NormalizarExtremosSegmentos(
                segmentos);

            List<List<XYZ>> loops =
                CoserSegmentosEnLoops(
                    segmentos);

            foreach (List<XYZ> loop
                in loops)
            {
                List<XYZ> limpio =
                    LimpiarPoligonoSeccionExacta(
                        loop);

                if (limpio == null ||
                    limpio.Count < 3)
                {
                    continue;
                }

                double area =
                    Math.Abs(
                        AreaPoligonoXY(
                            limpio));

                if (area <= TOL)
                    continue;

                resultado.Add(limpio);
            }

            return resultado;
        }

        private void AgregarInterseccionTrianguloPlano(
            List<SegmentoCortePlano> segmentos,
            XYZ a,
            XYZ b,
            XYZ c,
            double planoZ)
        {
            if (segmentos == null ||
                a == null ||
                b == null ||
                c == null)
            {
                return;
            }

            bool aPlano =
                Math.Abs(
                    a.Z -
                    planoZ) <=
                TOL_PLANO_MEDIO;

            bool bPlano =
                Math.Abs(
                    b.Z -
                    planoZ) <=
                TOL_PLANO_MEDIO;

            bool cPlano =
                Math.Abs(
                    c.Z -
                    planoZ) <=
                TOL_PLANO_MEDIO;

            // Si el triángulo entero es coplanar NO agregamos sus tres
            // aristas: esas triangulaciones contienen diagonales internas.
            // El borde real de esa cara será recuperado por las caras
            // laterales del sólido.
            if (aPlano &&
                bPlano &&
                cPlano)
            {
                return;
            }

            List<XYZ> puntos =
                new List<XYZ>();

            AgregarInterseccionAristaPlano(
                puntos,
                a,
                b,
                planoZ);

            AgregarInterseccionAristaPlano(
                puntos,
                b,
                c,
                planoZ);

            AgregarInterseccionAristaPlano(
                puntos,
                c,
                a,
                planoZ);

            puntos =
                PuntosXYUnicos(
                    puntos);

            if (puntos.Count < 2)
                return;

            XYZ p0 = null;
            XYZ p1 = null;
            double mayor =
                -1.0;

            // En casos degenerados pueden quedar 3 puntos. Tomamos los dos
            // más alejados, que representan el tramo real del corte.
            for (int i = 0;
                i < puntos.Count;
                i++)
            {
                for (int j = i + 1;
                    j < puntos.Count;
                    j++)
                {
                    double d =
                        DistanciaXY(
                            puntos[i],
                            puntos[j]);

                    if (d > mayor)
                    {
                        mayor = d;
                        p0 = puntos[i];
                        p1 = puntos[j];
                    }
                }
            }

            if (p0 == null ||
                p1 == null)
            {
                return;
            }

            double minLong =
                UnitUtils.ConvertToInternalUnits(
                    0.02,
                    UnitTypeId.Centimeters);

            if (DistanciaXY(
                    p0,
                    p1) <=
                minLong)
            {
                return;
            }

            segmentos.Add(
                new SegmentoCortePlano
                {
                    A =
                        new XYZ(
                            p0.X,
                            p0.Y,
                            0.0),

                    B =
                        new XYZ(
                            p1.X,
                            p1.Y,
                            0.0)
                });
        }

        private void AgregarInterseccionAristaPlano(
            List<XYZ> puntos,
            XYZ a,
            XYZ b,
            double planoZ)
        {
            if (puntos == null ||
                a == null ||
                b == null)
            {
                return;
            }

            double da =
                a.Z -
                planoZ;

            double db =
                b.Z -
                planoZ;

            bool aPlano =
                Math.Abs(da) <=
                TOL_PLANO_MEDIO;

            bool bPlano =
                Math.Abs(db) <=
                TOL_PLANO_MEDIO;

            if (aPlano)
            {
                puntos.Add(
                    new XYZ(
                        a.X,
                        a.Y,
                        0.0));
            }

            if (bPlano)
            {
                puntos.Add(
                    new XYZ(
                        b.X,
                        b.Y,
                        0.0));
            }

            // Si ambos están en el plano ya tenemos los dos extremos.
            if (aPlano &&
                bPlano)
            {
                return;
            }

            bool cruza =
                (da <
                    -TOL_PLANO_MEDIO &&
                 db >
                    TOL_PLANO_MEDIO)
                ||
                (da >
                    TOL_PLANO_MEDIO &&
                 db <
                    -TOL_PLANO_MEDIO);

            if (!cruza)
                return;

            double dz =
                b.Z -
                a.Z;

            if (Math.Abs(dz) <=
                TOL)
            {
                return;
            }

            double t =
                (planoZ -
                 a.Z) /
                dz;

            if (t <
                    -TOL ||
                t >
                    1.0 +
                    TOL)
            {
                return;
            }

            XYZ p =
                a +
                (b - a) *
                t;

            puntos.Add(
                new XYZ(
                    p.X,
                    p.Y,
                    0.0));
        }

        private List<XYZ> PuntosXYUnicos(
            List<XYZ> puntos)
        {
            List<XYZ> resultado =
                new List<XYZ>();

            if (puntos == null)
                return resultado;

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.05,
                    UnitTypeId.Centimeters);

            foreach (XYZ p
                in puntos)
            {
                if (p == null)
                    continue;

                bool existe =
                    resultado.Any(
                        q =>
                            Math.Abs(
                                q.X -
                                p.X) <=
                                tol &&
                            Math.Abs(
                                q.Y -
                                p.Y) <=
                                tol);

                if (!existe)
                {
                    resultado.Add(
                        new XYZ(
                            p.X,
                            p.Y,
                            0.0));
                }
            }

            return resultado;
        }

        private double DistanciaXY(
            XYZ a,
            XYZ b)
        {
            if (a == null ||
                b == null)
            {
                return double.MaxValue;
            }

            double dx =
                a.X -
                b.X;

            double dy =
                a.Y -
                b.Y;

            return
                Math.Sqrt(
                    dx * dx +
                    dy * dy);
        }

        private List<SegmentoCortePlano> EliminarSegmentosDuplicados(
            List<SegmentoCortePlano> entrada)
        {
            List<SegmentoCortePlano> salida =
                new List<SegmentoCortePlano>();

            if (entrada == null)
                return salida;

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.05,
                    UnitTypeId.Centimeters);

            foreach (SegmentoCortePlano s
                in entrada)
            {
                if (s == null ||
                    s.A == null ||
                    s.B == null)
                {
                    continue;
                }

                bool duplicado =
                    salida.Any(
                        x =>
                            (
                                DistanciaXY(
                                    x.A,
                                    s.A) <=
                                    tol &&
                                DistanciaXY(
                                    x.B,
                                    s.B) <=
                                    tol
                            )
                            ||
                            (
                                DistanciaXY(
                                    x.A,
                                    s.B) <=
                                    tol &&
                                DistanciaXY(
                                    x.B,
                                    s.A) <=
                                    tol
                            ));

                if (!duplicado)
                {
                    salida.Add(
                        new SegmentoCortePlano
                        {
                            A =
                                new XYZ(
                                    s.A.X,
                                    s.A.Y,
                                    0.0),

                            B =
                                new XYZ(
                                    s.B.X,
                                    s.B.Y,
                                    0.0)
                        });
                }
            }

            return salida;
        }

        private void NormalizarExtremosSegmentos(
            List<SegmentoCortePlano> segmentos)
        {
            if (segmentos == null ||
                segmentos.Count == 0)
            {
                return;
            }

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.10,
                    UnitTypeId.Centimeters);

            List<XYZ> nodos =
                new List<XYZ>();

            foreach (SegmentoCortePlano s
                in segmentos)
            {
                if (s == null)
                    continue;

                s.A =
                    ObtenerNodoNormalizado(
                        nodos,
                        s.A,
                        tol);

                s.B =
                    ObtenerNodoNormalizado(
                        nodos,
                        s.B,
                        tol);
            }
        }

        private XYZ ObtenerNodoNormalizado(
            List<XYZ> nodos,
            XYZ p,
            double tol)
        {
            if (p == null)
                return null;

            foreach (XYZ n
                in nodos)
            {
                if (DistanciaXY(
                        n,
                        p) <=
                    tol)
                {
                    return n;
                }
            }

            XYZ nuevo =
                new XYZ(
                    p.X,
                    p.Y,
                    0.0);

            nodos.Add(nuevo);

            return nuevo;
        }

        private List<List<XYZ>> CoserSegmentosEnLoops(
            List<SegmentoCortePlano> segmentos)
        {
            List<List<XYZ>> loops =
                new List<List<XYZ>>();

            if (segmentos == null ||
                segmentos.Count == 0)
            {
                return loops;
            }

            bool[] usado =
                new bool[
                    segmentos.Count];

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.15,
                    UnitTypeId.Centimeters);

            for (int semilla = 0;
                semilla < segmentos.Count;
                semilla++)
            {
                if (usado[semilla])
                    continue;

                SegmentoCortePlano primero =
                    segmentos[semilla];

                if (primero == null ||
                    primero.A == null ||
                    primero.B == null)
                {
                    usado[semilla] = true;
                    continue;
                }

                List<XYZ> cadena =
                    new List<XYZ>();

                cadena.Add(
                    primero.A);

                cadena.Add(
                    primero.B);

                usado[semilla] =
                    true;

                XYZ inicio =
                    primero.A;

                XYZ anterior =
                    primero.A;

                XYZ actual =
                    primero.B;

                bool cerrado =
                    false;

                int seguridad =
                    0;

                while (seguridad <
                    segmentos.Count +
                    10)
                {
                    seguridad++;

                    if (DistanciaXY(
                            actual,
                            inicio) <=
                        tol &&
                        cadena.Count >= 4)
                    {
                        cerrado =
                            true;

                        break;
                    }

                    int siguienteIndice =
                        BuscarSiguienteSegmentoLoop(
                            segmentos,
                            usado,
                            anterior,
                            actual,
                            tol);

                    if (siguienteIndice < 0)
                        break;

                    SegmentoCortePlano siguiente =
                        segmentos[
                            siguienteIndice];

                    usado[
                        siguienteIndice] =
                        true;

                    XYZ nuevo =
                        DistanciaXY(
                            siguiente.A,
                            actual) <=
                            tol
                        ? siguiente.B
                        : siguiente.A;

                    anterior =
                        actual;

                    actual =
                        nuevo;

                    cadena.Add(
                        actual);
                }

                if (!cerrado)
                {
                    // No inventamos un polígono si la cadena no pudo
                    // cerrarse. Es preferible descartar ese loop antes que
                    // volver a conectar extremos mediante una diagonal.
                    continue;
                }

                if (cadena.Count > 1 &&
                    DistanciaXY(
                        cadena[0],
                        cadena[
                            cadena.Count - 1]) <=
                    tol)
                {
                    cadena.RemoveAt(
                        cadena.Count - 1);
                }

                if (cadena.Count >= 3)
                    loops.Add(cadena);
            }

            return loops;
        }

        private int BuscarSiguienteSegmentoLoop(
            List<SegmentoCortePlano> segmentos,
            bool[] usado,
            XYZ anterior,
            XYZ actual,
            double tol)
        {
            List<int> candidatos =
                new List<int>();

            for (int i = 0;
                i < segmentos.Count;
                i++)
            {
                if (usado[i])
                    continue;

                SegmentoCortePlano s =
                    segmentos[i];

                if (s == null ||
                    s.A == null ||
                    s.B == null)
                {
                    continue;
                }

                if (DistanciaXY(
                        s.A,
                        actual) <=
                        tol ||
                    DistanciaXY(
                        s.B,
                        actual) <=
                        tol)
                {
                    candidatos.Add(i);
                }
            }

            if (candidatos.Count == 0)
                return -1;

            if (candidatos.Count == 1)
                return candidatos[0];

            // Si por triangulación hay más de una salida desde el mismo
            // nodo, elegimos la que continúa el contorno sin devolverse
            // sobre el segmento anterior.
            XYZ dirAnterior =
                actual -
                anterior;

            dirAnterior =
                new XYZ(
                    dirAnterior.X,
                    dirAnterior.Y,
                    0.0);

            if (dirAnterior.GetLength() <=
                TOL)
            {
                return candidatos[0];
            }

            dirAnterior =
                dirAnterior.Normalize();

            int mejor =
                -1;

            double mejorScore =
                double.NegativeInfinity;

            foreach (int i
                in candidatos)
            {
                SegmentoCortePlano s =
                    segmentos[i];

                XYZ otro =
                    DistanciaXY(
                        s.A,
                        actual) <=
                        tol
                    ? s.B
                    : s.A;

                XYZ dir =
                    otro -
                    actual;

                dir =
                    new XYZ(
                        dir.X,
                        dir.Y,
                        0.0);

                if (dir.GetLength() <=
                    TOL)
                {
                    continue;
                }

                dir =
                    dir.Normalize();

                // Valor alto = continuación más natural.
                // Penalizamos fuertemente devolverse 180°.
                double dot =
                    dirAnterior.DotProduct(
                        dir);

                if (dot >
                    mejorScore)
                {
                    mejorScore =
                        dot;

                    mejor =
                        i;
                }
            }

            return
                mejor >= 0
                ? mejor
                : candidatos[0];
        }

        private List<XYZ> LimpiarPoligonoSeccionExacta(
            List<XYZ> entrada)
        {
            List<XYZ> p =
                new List<XYZ>();

            if (entrada == null)
                return p;

            double tolPunto =
                UnitUtils.ConvertToInternalUnits(
                    0.05,
                    UnitTypeId.Centimeters);

            double tolColineal =
                UnitUtils.ConvertToInternalUnits(
                    0.02,
                    UnitTypeId.Centimeters);

            foreach (XYZ q
                in entrada)
            {
                if (q == null)
                    continue;

                XYZ n =
                    new XYZ(
                        q.X,
                        q.Y,
                        0.0);

                if (p.Count == 0 ||
                    DistanciaXY(
                        p[
                            p.Count - 1],
                        n) >
                    tolPunto)
                {
                    p.Add(n);
                }
            }

            if (p.Count > 1 &&
                DistanciaXY(
                    p[0],
                    p[
                        p.Count - 1]) <=
                tolPunto)
            {
                p.RemoveAt(
                    p.Count - 1);
            }

            if (p.Count < 3)
                return p;

            // Solo eliminamos puntos REALMENTE colineales.
            // La tolerancia es mucho menor que antes para no saltarnos
            // vértices cortos o entrantes del perfil.
            bool cambio =
                true;

            int guard =
                0;

            while (cambio &&
                p.Count >= 3 &&
                guard < 20)
            {
                guard++;
                cambio = false;

                for (int i = 0;
                    i < p.Count;
                    i++)
                {
                    XYZ a =
                        p[
                            (i - 1 +
                             p.Count) %
                            p.Count];

                    XYZ b =
                        p[i];

                    XYZ c =
                        p[
                            (i + 1) %
                            p.Count];

                    double d =
                        DistanciaPuntoSegmentoXY(
                            b,
                            a,
                            c);

                    if (d <=
                        tolColineal &&
                        PuntoEntreExtremosXY(
                            b,
                            a,
                            c,
                            tolPunto))
                    {
                        p.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }

            if (p.Count >= 3 &&
                AreaPoligonoXY(p) <
                0.0)
            {
                p.Reverse();
            }

            return p;
        }

        private bool PuntoEntreExtremosXY(
            XYZ p,
            XYZ a,
            XYZ b,
            double tol)
        {
            if (p == null ||
                a == null ||
                b == null)
            {
                return false;
            }

            double minX =
                Math.Min(
                    a.X,
                    b.X) -
                tol;

            double maxX =
                Math.Max(
                    a.X,
                    b.X) +
                tol;

            double minY =
                Math.Min(
                    a.Y,
                    b.Y) -
                tol;

            double maxY =
                Math.Max(
                    a.Y,
                    b.Y) +
                tol;

            return
                p.X >= minX &&
                p.X <= maxX &&
                p.Y >= minY &&
                p.Y <= maxY;
        }

        private void AgregarPuntoXYUnico(
            List<XYZ> puntos,
            XYZ punto)
        {
            if (puntos == null ||
                punto == null)
            {
                return;
            }

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.05,
                    UnitTypeId.Centimeters);

            foreach (XYZ p
                in puntos)
            {
                if (Math.Abs(
                        p.X -
                        punto.X) <=
                        tol &&
                    Math.Abs(
                        p.Y -
                        punto.Y) <=
                        tol)
                {
                    return;
                }
            }

            puntos.Add(
                new XYZ(
                    punto.X,
                    punto.Y,
                    0.0));
        }

        private List<XYZ> ConvexHullXY(
            List<XYZ> puntos)
        {
            List<XYZ> pts =
                new List<XYZ>();

            if (puntos == null)
                return pts;

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.05,
                    UnitTypeId.Centimeters);

            foreach (XYZ p
                in puntos
                .Where(x => x != null)
                .OrderBy(x => x.X)
                .ThenBy(x => x.Y))
            {
                XYZ q =
                    new XYZ(
                        p.X,
                        p.Y,
                        0.0);

                bool existe =
                    pts.Any(
                        x =>
                            Math.Abs(
                                x.X -
                                q.X) <=
                                tol &&
                            Math.Abs(
                                x.Y -
                                q.Y) <=
                                tol);

                if (!existe)
                    pts.Add(q);
            }

            if (pts.Count <= 3)
                return pts;

            List<XYZ> lower =
                new List<XYZ>();

            foreach (XYZ p
                in pts)
            {
                while (
                    lower.Count >= 2 &&
                    Cruz2D(
                        lower[
                            lower.Count - 2],
                        lower[
                            lower.Count - 1],
                        p) <=
                    TOL)
                {
                    lower.RemoveAt(
                        lower.Count - 1);
                }

                lower.Add(p);
            }

            List<XYZ> upper =
                new List<XYZ>();

            for (int i =
                    pts.Count - 1;
                i >= 0;
                i--)
            {
                XYZ p =
                    pts[i];

                while (
                    upper.Count >= 2 &&
                    Cruz2D(
                        upper[
                            upper.Count - 2],
                        upper[
                            upper.Count - 1],
                        p) <=
                    TOL)
                {
                    upper.RemoveAt(
                        upper.Count - 1);
                }

                upper.Add(p);
            }

            if (lower.Count > 0)
                lower.RemoveAt(
                    lower.Count - 1);

            if (upper.Count > 0)
                upper.RemoveAt(
                    upper.Count - 1);

            lower.AddRange(
                upper);

            return lower;
        }

        private double Cruz2D(
            XYZ o,
            XYZ a,
            XYZ b)
        {
            return
                (a.X - o.X) *
                (b.Y - o.Y)
                -
                (a.Y - o.Y) *
                (b.X - o.X);
        }

        private double AreaPoligonoXY(
            List<XYZ> poligono)
        {
            if (poligono == null ||
                poligono.Count < 3)
            {
                return 0.0;
            }

            double area =
                0.0;

            for (int i = 0;
                i < poligono.Count;
                i++)
            {
                XYZ a =
                    poligono[i];

                XYZ b =
                    poligono[
                        (i + 1) %
                        poligono.Count];

                area +=
                    a.X *
                    b.Y -
                    b.X *
                    a.Y;
            }

            return
                area /
                2.0;
        }

        // =====================================================================
        // LIMPIEZA DE POLIGONOS DE APOYO
        // =====================================================================

        private List<XYZ> LimpiarPoligonoSoporte(
            List<XYZ> entrada)
        {
            List<XYZ> p =
                new List<XYZ>();

            if (entrada == null)
                return p;

            // 1. eliminar puntos repetidos consecutivos
            foreach (XYZ q
                in entrada)
            {
                if (q == null)
                    continue;

                XYZ n =
                    new XYZ(
                        q.X,
                        q.Y,
                        0.0);

                if (p.Count == 0 ||
                    p[
                        p.Count - 1]
                    .DistanceTo(n) >
                    TOL_VERTICE_RED)
                {
                    p.Add(n);
                }
            }

            if (p.Count > 1 &&
                p[0].DistanceTo(
                    p[
                        p.Count - 1]) <=
                TOL_VERTICE_RED)
            {
                p.RemoveAt(
                    p.Count - 1);
            }

            if (p.Count < 3)
                return p;

            // 2. eliminar vértices prácticamente colineales.
            bool cambio =
                true;

            int seguridad =
                0;

            while (cambio &&
                p.Count >= 3 &&
                seguridad < 10)
            {
                seguridad++;
                cambio = false;

                for (int i = 0;
                    i < p.Count;
                    i++)
                {
                    XYZ a =
                        p[
                            (i - 1 +
                             p.Count) %
                            p.Count];

                    XYZ b =
                        p[i];

                    XYZ c =
                        p[
                            (i + 1) %
                            p.Count];

                    double d =
                        DistanciaPuntoSegmentoXY(
                            b,
                            a,
                            c);

                    if (d <=
                        TOL_COLINEAL_RED)
                    {
                        p.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }

            if (p.Count < 3)
                return p;

            // 3. sentido estable antihorario
            if (AreaPoligonoXY(p) <
                0.0)
            {
                p.Reverse();
            }

            return p;
        }

        private bool ExisteSeccionEquivalente(
            List<SeccionSoporteCandidata> existentes,
            List<XYZ> poligono,
            double z)
        {
            if (existentes == null ||
                poligono == null ||
                poligono.Count < 3)
            {
                return false;
            }

            Box2 b =
                BoundingXY(
                    poligono);

            double tolZ =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            double tolXY =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            foreach (SeccionSoporteCandidata s
                in existentes)
            {
                if (s == null ||
                    s.Poligono == null)
                {
                    continue;
                }

                if (Math.Abs(
                        s.PlanoZ -
                        z) >
                    tolZ)
                {
                    continue;
                }

                Box2 bs =
                    BoundingXY(
                        s.Poligono);

                bool mismaCaja =
                    Math.Abs(
                        b.MinX -
                        bs.MinX) <=
                        tolXY &&
                    Math.Abs(
                        b.MaxX -
                        bs.MaxX) <=
                        tolXY &&
                    Math.Abs(
                        b.MinY -
                        bs.MinY) <=
                        tolXY &&
                    Math.Abs(
                        b.MaxY -
                        bs.MaxY) <=
                        tolXY;

                if (mismaCaja)
                    return true;
            }

            return false;
        }

        private SeccionSoporteCandidata ElegirSeccionRepresentativa(
            List<SeccionSoporteCandidata> lista,
            string tipo)
        {
            if (lista == null ||
                lista.Count == 0)
            {
                return null;
            }

            // Evitar que un pequeño sólido auxiliar de una familia gane
            // frente al sólido principal.
            //
            // Para VIGA/MURO queremos normalmente la sección de mayor área
            // en planta. Para PILAR también, porque así descartamos herrajes,
            // conectores o sólidos auxiliares diminutos.
            return
                lista
                .Where(
                    x =>
                        x != null &&
                        x.Poligono != null &&
                        x.Poligono.Count >= 3)
                .OrderByDescending(
                    x => x.Area)
                .ThenBy(
                    x => x.DistanciaALosa)
                .FirstOrDefault();
        }

        private void AjustarConexionRedSoportes()
        {
            if (_previewSoportes == null ||
                _previewSoportes.Count < 2)
            {
                return;
            }

            // =============================================================
            // AJUSTE CONSERVADOR
            // =============================================================
            // La versión anterior proyectaba CADA vértice de una viga hasta
            // una cara vecina si estaba a <= 2.5 cm.
            //
            // Eso podía mover un solo vértice de un extremo y dejar el otro
            // quieto, convirtiendo un extremo rectangular en una diagonal /
            // trapecio.
            //
            // Ahora SOLO hacemos "weld" de vértices que ya son prácticamente
            // coincidentes (tolerancia pequeña). No inventamos nuevas caras.
            // La geometría principal viene del corte exacto de sólidos.
            // =============================================================

            double tolWeld =
                UnitUtils.ConvertToInternalUnits(
                    0.20,
                    UnitTypeId.Centimeters);

            for (int i = 0;
                i < _previewSoportes.Count;
                i++)
            {
                PreviewSoporte a =
                    _previewSoportes[i];

                if (a == null ||
                    a.Exterior == null ||
                    a.Exterior.Count < 3)
                {
                    continue;
                }

                for (int ia = 0;
                    ia < a.Exterior.Count;
                    ia++)
                {
                    XYZ va =
                        a.Exterior[ia];

                    if (va == null)
                        continue;

                    List<XYZ> coincidentes =
                        new List<XYZ>();

                    coincidentes.Add(va);

                    for (int j = 0;
                        j < _previewSoportes.Count;
                        j++)
                    {
                        if (i == j)
                            continue;

                        PreviewSoporte b =
                            _previewSoportes[j];

                        if (b == null ||
                            b.Exterior == null)
                        {
                            continue;
                        }

                        foreach (XYZ vb
                            in b.Exterior)
                        {
                            if (vb == null)
                                continue;

                            if (DistanciaXY(
                                    va,
                                    vb) <=
                                tolWeld)
                            {
                                coincidentes.Add(vb);
                            }
                        }
                    }

                    if (coincidentes.Count <= 1)
                        continue;

                    double sx =
                        coincidentes.Sum(
                            x => x.X);

                    double sy =
                        coincidentes.Sum(
                            x => x.Y);

                    XYZ promedio =
                        new XYZ(
                            sx /
                            coincidentes.Count,

                            sy /
                            coincidentes.Count,

                            0.0);

                    a.Exterior[ia] =
                        promedio;
                }
            }

            foreach (PreviewSoporte s
                in _previewSoportes)
            {
                if (s == null)
                    continue;

                s.Exterior =
                    LimpiarPoligonoSeccionExacta(
                        s.Exterior);
            }
        }

        private XYZ ProyeccionPuntoSegmentoXY(
            XYZ p,
            XYZ a,
            XYZ b)
        {
            if (p == null ||
                a == null ||
                b == null)
            {
                return null;
            }

            double vx =
                b.X -
                a.X;

            double vy =
                b.Y -
                a.Y;

            double den =
                vx * vx +
                vy * vy;

            if (den <= TOL)
                return a;

            double t =
                (
                    (p.X - a.X) *
                    vx +
                    (p.Y - a.Y) *
                    vy
                ) /
                den;

            t =
                Math.Max(
                    0.0,
                    Math.Min(
                        1.0,
                        t));

            return
                new XYZ(
                    a.X +
                    t * vx,
                    a.Y +
                    t * vy,
                    0.0);
        }

        // ÚNICA implementación de distancia punto-segmento XY.
        // No duplicar: la usa tanto la limpieza de apoyos como la distancia entre polígonos.
        private double DistanciaPuntoSegmentoXY(
            XYZ p,
            XYZ a,
            XYZ b)
        {
            XYZ q =
                ProyeccionPuntoSegmentoXY(
                    p,
                    a,
                    b);

            if (q == null)
                return double.MaxValue;

            return
                p.DistanceTo(q);
        }

        // =====================================================================
        // DISTANCIA REAL ENTRE DOS POLIGONOS EN PLANTA
        // =====================================================================
        private double DistanciaMinimaPoligonosXY(
            List<XYZ> a,
            List<XYZ> b)
        {
            if (a == null || b == null ||
                a.Count < 3 || b.Count < 3)
            {
                return double.MaxValue;
            }

            // Si se intersectan o uno contiene al otro, son adyacentes con
            // distancia cero.
            if (PoligonosIntersectanXY(a, b))
                return 0.0;

            double min = double.MaxValue;

            foreach (XYZ p in a)
            {
                for (int i = 0; i < b.Count; i++)
                {
                    double d = DistanciaPuntoSegmentoXY(
                        p,
                        b[i],
                        b[(i + 1) % b.Count]);

                    if (d < min)
                        min = d;
                }
            }

            foreach (XYZ p in b)
            {
                for (int i = 0; i < a.Count; i++)
                {
                    double d = DistanciaPuntoSegmentoXY(
                        p,
                        a[i],
                        a[(i + 1) % a.Count]);

                    if (d < min)
                        min = d;
                }
            }

            return min;
        }



        private PanoData CrearPanoRectangular(XYZ p1, XYZ p2)
        {
            if (p1 == null || p2 == null || _previewGeneral.Count == 0)
                return null;

            double minX = Math.Min(p1.X, p2.X);
            double maxX = Math.Max(p1.X, p2.X);
            double minY = Math.Min(p1.Y, p2.Y);
            double maxY = Math.Max(p1.Y, p2.Y);

            double minLado =
                UnitUtils.ConvertToInternalUnits(
                    15.0,
                    UnitTypeId.Centimeters);

            if ((maxX - minX) < minLado ||
                (maxY - minY) < minLado)
            {
                return null;
            }

            List<XYZ> limite =
                new List<XYZ>
                {
                    new XYZ(minX, minY, 0.0),
                    new XYZ(maxX, minY, 0.0),
                    new XYZ(maxX, maxY, 0.0),
                    new XYZ(minX, maxY, 0.0)
                };

            return CrearPanoDesdeLimite(
                limite,
                false);
        }

        private PanoData CrearPanoPoligonal(
            List<XYZ> vertices)
        {
            if (vertices == null ||
                vertices.Count < 3 ||
                _previewGeneral.Count == 0)
            {
                return null;
            }

            List<XYZ> limite =
                LimpiarVerticesPano(
                    vertices);

            if (limite.Count < 3)
                return null;

            double minAreaLado =
                UnitUtils.ConvertToInternalUnits(
                    15.0,
                    UnitTypeId.Centimeters);

            double area =
                Math.Abs(
                    AreaPoligonoXY(
                        limite));

            if (area <
                minAreaLado *
                minAreaLado)
            {
                return null;
            }

            if (PoligonoAutointersectaXY(
                    limite))
            {
                return null;
            }

            return CrearPanoDesdeLimite(
                limite,
                true);
        }

        private bool AgregarHuecoManual(
            List<XYZ> vertices,
            out string mensaje)
        {
            mensaje = "";

            PanoData pano =
                PanoActivo();

            if (pano == null ||
                pano.Rectangulo == null ||
                pano.Rectangulo.Count < 3)
            {
                mensaje =
                    "Primero dibuje y cierre el boceto general.";

                return false;
            }

            if (vertices == null ||
                vertices.Count < 3)
            {
                mensaje =
                    "El hueco necesita al menos 3 vértices.";

                return false;
            }

            List<XYZ> hueco =
                LimpiarVerticesPano(
                    vertices);

            if (hueco.Count < 3)
            {
                mensaje =
                    "El hueco necesita al menos 3 vértices válidos.";

                return false;
            }

            if (PoligonoAutointersectaXY(
                    hueco))
            {
                mensaje =
                    "El hueco se cruza consigo mismo. Redibújelo.";

                return false;
            }

            double minAreaLado =
                UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Centimeters);

            double area =
                Math.Abs(
                    AreaPoligonoXY(
                        hueco));

            if (area <
                minAreaLado *
                minAreaLado)
            {
                mensaje =
                    "El hueco es demasiado pequeño.";

                return false;
            }

            // Todos los vértices deben estar estrictamente dentro del
            // boundary exterior. Si toca el boundary, ya no es un hueco:
            // debe resolverse editando el boceto general.
            foreach (XYZ q in hueco)
            {
                if (!PuntoEnPoligonoXY(
                        q,
                        pano.Rectangulo))
                {
                    mensaje =
                        "El hueco debe quedar completamente dentro del boceto general y no tocar su borde.";

                    return false;
                }
            }

            // Ningún lado del hueco puede cruzar el borde exterior.
            for (int i = 0;
                i < hueco.Count;
                i++)
            {
                XYZ a0 =
                    hueco[i];

                XYZ a1 =
                    hueco[
                        (i + 1) %
                        hueco.Count];

                for (int j = 0;
                    j < pano.Rectangulo.Count;
                    j++)
                {
                    XYZ b0 =
                        pano.Rectangulo[j];

                    XYZ b1 =
                        pano.Rectangulo[
                            (j + 1) %
                            pano.Rectangulo.Count];

                    if (SegmentosIntersectanXY(
                            a0,
                            a1,
                            b0,
                            b1))
                    {
                        mensaje =
                            "El hueco no puede cruzar ni tocar el boundary exterior.";

                        return false;
                    }
                }
            }

            // Evitar huecos superpuestos, contenidos uno dentro de otro o
            // tocándose. Esto mantiene un boundary limpio y determinista.
            foreach (List<XYZ> existente
                in pano.HuecosManuales)
            {
                if (existente == null ||
                    existente.Count < 3)
                {
                    continue;
                }

                if (PoligonosIntersectanXY(
                        hueco,
                        existente))
                {
                    mensaje =
                        "El nuevo hueco intersecta o se superpone con otro hueco manual.";

                    return false;
                }
            }

            // Copia defensiva.
            List<XYZ> copia =
                hueco
                .Select(
                    q =>
                        new XYZ(
                            q.X,
                            q.Y,
                            0.0))
                .ToList();

            RegistrarUndo();

            pano.HuecosManuales.Add(
                copia);

            mensaje =
                "Hueco " +
                pano.HuecosManuales.Count +
                " creado · " +
                copia.Count +
                " vértices.";

            _form.RefrescarBotonesPanos();
            _form.InvalidarPreview();

            return true;
        }

        private PanoData CrearPanoDesdeLimite(
            List<XYZ> limite,
            bool poligonal)
        {
            if (limite == null ||
                limite.Count < 3)
            {
                return null;
            }

            // =============================================================
            // BOCETO GENERAL ÚNICO
            // =============================================================
            // Ya no existen múltiples paños. Cada nuevo cierre reemplaza el
            // boceto general anterior. Se conserva PanoData únicamente como
            // contenedor interno para no duplicar todo el motor de armado.

            RegistrarUndo();

            _panos.Clear();
            _panoActivoId = -1;
            _siguientePano = 1;

            PanoData pano =
                new PanoData();

            pano.Id = 1;
            pano.Nombre = "BOCETO GENERAL";
            pano.EsPoligonal = true;

            foreach (XYZ p
                in limite)
            {
                pano.Rectangulo.Add(
                    new XYZ(
                        p.X,
                        p.Y,
                        0.0));
            }

            Box2 box =
                BoundingXY(
                    pano.Rectangulo);

            pano.RectP1 =
                new XYZ(
                    box.MinX,
                    box.MinY,
                    0.0);

            pano.RectP2 =
                new XYZ(
                    box.MaxX,
                    box.MaxY,
                    0.0);

            pano.CentroRect =
                CentroidePoligonoXY(
                    pano.Rectangulo);

            // Una misma losa puede participar en varios paños.
            // El límite real del armado es el polígono del paño, no el Floor.
            foreach (PreviewLosa pv
                in _previewGeneral)
            {
                if (pv == null ||
                    pv.Exterior == null ||
                    pv.Exterior.Count < 3)
                {
                    continue;
                }

                if (PoligonosIntersectanXY(
                        pano.Rectangulo,
                        pv.Exterior))
                {
                    pano.Losas.Add(
                        pv.LosaId);

                    pano.Preview.Add(
                        pv);
                }
            }

            if (pano.Losas.Count == 0)
                return null;

            _form.InicializarNuevoPano(
                pano);

            // Antes se forzaba D1Definida/D2Definida = false.
            // Eso provocaba el error "PAÑO A: dibuje D1." al ejecutar
            // directamente un paño recién creado.
            //
            // Ahora cada paño nace con D1/D2 automáticos basados en su
            // geometría. El usuario conserva TOTAL libertad para
            // sobreescribirlos con Dibujar D1 / Dibujar D2.
            AsegurarDireccionesAutomaticas(
                pano);

            _panos.Add(
                pano);

            _panoActivoId =
                pano.Id;

            _form.RefrescarBotonesPanos();
            _form.CargarPano(pano);
            _form.AjustarPreview();

            return pano;
        }

        private List<XYZ> LimpiarVerticesPano(
            List<XYZ> entrada)
        {
            List<XYZ> salida =
                new List<XYZ>();

            if (entrada == null)
                return salida;

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.10,
                    UnitTypeId.Centimeters);

            foreach (XYZ p
                in entrada)
            {
                if (p == null)
                    continue;

                XYZ q =
                    new XYZ(
                        p.X,
                        p.Y,
                        0.0);

                if (salida.Count == 0 ||
                    DistanciaXY(
                        salida[
                            salida.Count - 1],
                        q) >
                    tol)
                {
                    salida.Add(q);
                }
            }

            if (salida.Count > 1 &&
                DistanciaXY(
                    salida[0],
                    salida[
                        salida.Count - 1]) <=
                tol)
            {
                salida.RemoveAt(
                    salida.Count - 1);
            }

            return salida;
        }

        private bool PoligonoAutointersectaXY(
            List<XYZ> pol)
        {
            if (pol == null ||
                pol.Count < 4)
            {
                return false;
            }

            int n =
                pol.Count;

            for (int i = 0;
                i < n;
                i++)
            {
                XYZ a1 =
                    pol[i];

                XYZ a2 =
                    pol[
                        (i + 1) %
                        n];

                for (int j = i + 1;
                    j < n;
                    j++)
                {
                    // Segmentos adyacentes comparten un vértice y no cuentan
                    // como auto-intersección.
                    if (j == i ||
                        j == i + 1 ||
                        (i == 0 &&
                         j == n - 1))
                    {
                        continue;
                    }

                    XYZ b1 =
                        pol[j];

                    XYZ b2 =
                        pol[
                            (j + 1) %
                            n];

                    if (SegmentosIntersectanXY(
                            a1,
                            a2,
                            b1,
                            b2))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private XYZ CentroidePoligonoXY(
            List<XYZ> pol)
        {
            if (pol == null ||
                pol.Count < 3)
            {
                return XYZ.Zero;
            }

            double area2 =
                0.0;

            double cx =
                0.0;

            double cy =
                0.0;

            for (int i = 0;
                i < pol.Count;
                i++)
            {
                XYZ a =
                    pol[i];

                XYZ b =
                    pol[
                        (i + 1) %
                        pol.Count];

                double cross =
                    a.X *
                    b.Y -
                    b.X *
                    a.Y;

                area2 +=
                    cross;

                cx +=
                    (a.X + b.X) *
                    cross;

                cy +=
                    (a.Y + b.Y) *
                    cross;
            }

            if (Math.Abs(area2) <=
                TOL)
            {
                Box2 b =
                    BoundingXY(pol);

                return
                    new XYZ(
                        (b.MinX + b.MaxX) /
                        2.0,
                        (b.MinY + b.MaxY) /
                        2.0,
                        0.0);
            }

            double factor =
                1.0 /
                (3.0 * area2);

            return
                new XYZ(
                    cx * factor,
                    cy * factor,
                    0.0);
        }

        private bool PoligonosIntersectanXY(List<XYZ> a, List<XYZ> b)
        {
            if (a == null || b == null || a.Count < 3 || b.Count < 3) return false;
            Box2 ba = BoundingXY(a), bb = BoundingXY(b);
            if (ba.MaxX < bb.MinX || ba.MinX > bb.MaxX || ba.MaxY < bb.MinY || ba.MinY > bb.MaxY) return false;

            foreach (XYZ p in a) if (PuntoEnPoligonoXY(p, b)) return true;
            foreach (XYZ p in b) if (PuntoEnPoligonoXY(p, a)) return true;

            for (int i = 0; i < a.Count; i++)
            {
                XYZ a1 = a[i], a2 = a[(i + 1) % a.Count];
                for (int j = 0; j < b.Count; j++)
                    if (SegmentosIntersectanXY(a1, a2, b[j], b[(j + 1) % b.Count])) return true;
            }
            return false;
        }

        private Box2 BoundingXY(List<XYZ> pts)
        {
            Box2 b = new Box2();
            foreach (XYZ p in pts)
            {
                if (p.X < b.MinX) b.MinX = p.X; if (p.X > b.MaxX) b.MaxX = p.X;
                if (p.Y < b.MinY) b.MinY = p.Y; if (p.Y > b.MaxY) b.MaxY = p.Y;
            }
            return b;
        }

        private bool PuntoEnPoligonoXY(XYZ p, List<XYZ> pol)
        {
            bool dentro = false;
            for (int i = 0, j = pol.Count - 1; i < pol.Count; j = i++)
            {
                XYZ pi = pol[i], pj = pol[j];
                bool cruce = ((pi.Y > p.Y) != (pj.Y > p.Y)) &&
                    (p.X < (pj.X - pi.X) * (p.Y - pi.Y) / (pj.Y - pi.Y + 1e-20) + pi.X);
                if (cruce) dentro = !dentro;
            }
            return dentro;
        }

        private bool SegmentosIntersectanXY(XYZ a1, XYZ a2, XYZ b1, XYZ b2)
        {
            P2 A1 = new P2 { X = a1.X, Y = a1.Y }, A2 = new P2 { X = a2.X, Y = a2.Y };
            P2 B1 = new P2 { X = b1.X, Y = b1.Y }, B2 = new P2 { X = b2.X, Y = b2.Y };
            double d1 = Orient(A1, A2, B1), d2 = Orient(A1, A2, B2), d3 = Orient(B1, B2, A1), d4 = Orient(B1, B2, A2);
            if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return true;
            if (Math.Abs(d1) < TOL && EnSegmento(A1, A2, B1)) return true;
            if (Math.Abs(d2) < TOL && EnSegmento(A1, A2, B2)) return true;
            if (Math.Abs(d3) < TOL && EnSegmento(B1, B2, A1)) return true;
            if (Math.Abs(d4) < TOL && EnSegmento(B1, B2, A2)) return true;
            return false;
        }

        private double Orient(P2 a, P2 b, P2 c)
        {
            return (b.X - a.X) * (c.Y - a.Y) - (b.Y - a.Y) * (c.X - a.X);
        }

        private bool EnSegmento(P2 a, P2 b, P2 p)
        {
            return p.X >= Math.Min(a.X, b.X) - TOL && p.X <= Math.Max(a.X, b.X) + TOL &&
                   p.Y >= Math.Min(a.Y, b.Y) - TOL && p.Y <= Math.Max(a.Y, b.Y) + TOL;
        }

        private string NombrePano(int numero)
        {
            string s = "";
            int n = numero;
            while (n > 0)
            {
                n--;
                s = (char)('A' + n % 26) + s;
                n /= 26;
            }
            return s;
        }

        // =====================================================================
        // CREACION DE ACERO
        // =====================================================================
        private void CrearPanoActivo(Document doc)
        {
            PanoData p = PanoActivo();

            if (p == null)
            {
                TaskDialog.Show(
                    "MYG - Acero en Losas",
                    "Dibuje el boceto general.");

                return;
            }

            try
            {
                ValidarPano(
                    doc,
                    p);
            }
            catch (Exception ex)
            {
                TaskDialog.Show(
                    "MYG - Configuración del boceto",
                    ex.Message);

                return;
            }

            ResultadoPano r =
                null;

            RebarFailurePreprocessor pre =
                new RebarFailurePreprocessor();

            TransactionStatus estado =
                TransactionStatus.Uninitialized;

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Acero - Boceto General"))
            {
                tx.Start();

                FailureHandlingOptions fho =
                    tx.GetFailureHandlingOptions();

                fho.SetFailuresPreprocessor(pre);
                fho.SetClearAfterRollback(true);

                tx.SetFailureHandlingOptions(fho);

                EliminarAceroAnterior(
                    doc,
                    p);

                r =
                    CrearAceroPano(
                        doc,
                        p);

                estado =
                    tx.Commit();
            }

            if (estado !=
                TransactionStatus.Committed)
            {
                TaskDialog.Show(
                    "MYG - Acero en Losas",
                    "No se pudo confirmar la creación del acero.\n\n" +
                    pre.Resumen());

                return;
            }

            MostrarResultado(
                doc,
                p,
                r,
                pre);
        }

        private void CrearTodos(Document doc)
        {
            if (_panos.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Acero en Losas",
                    "No existe un boceto general cerrado.");

                return;
            }

            List<string> erroresValidacion =
                new List<string>();

            foreach (PanoData p
                in _panos)
            {
                try
                {
                    ValidarPano(
                        doc,
                        p);
                }
                catch (Exception ex)
                {
                    erroresValidacion.Add(
                        ex.Message);
                }
            }

            if (erroresValidacion.Count > 0)
            {
                TaskDialog.Show(
                    "MYG - Configuración del boceto",
                    string.Join(
                        "\n",
                        erroresValidacion));

                return;
            }

            int puentes =
                0;

            int ok =
                0;

            List<string> errores =
                new List<string>();

            RebarFailurePreprocessor pre =
                new RebarFailurePreprocessor();

            TransactionStatus estado =
                TransactionStatus.Uninitialized;

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Acero en Todos los Paños"))
            {
                tx.Start();

                FailureHandlingOptions fho =
                    tx.GetFailureHandlingOptions();

                fho.SetFailuresPreprocessor(pre);
                fho.SetClearAfterRollback(true);

                tx.SetFailureHandlingOptions(fho);

                foreach (PanoData p
                    in _panos)
                {
                    using (SubTransaction st =
                        new SubTransaction(doc))
                    {
                        st.Start();

                        try
                        {
                            EliminarAceroAnterior(
                                doc,
                                p);

                            ResultadoPano r =
                                CrearAceroPano(
                                    doc,
                                    p);

                            puentes +=
                                r.Puentes;

                            foreach (string e
                                in r.Errores)
                            {
                                errores.Add(
                                    p.Nombre +
                                    ": " +
                                    e);
                            }

                            st.Commit();
                            ok++;
                        }
                        catch (Exception ex)
                        {
                            st.RollBack();

                            errores.Add(
                                p.Nombre +
                                ": " +
                                ex.Message);
                        }
                    }
                }

                estado =
                    tx.Commit();
            }

            if (estado !=
                TransactionStatus.Committed)
            {
                TaskDialog.Show(
                    "MYG - Acero en Losas",
                    "La transacción general no pudo confirmarse.\n\n" +
                    pre.Resumen());

                return;
            }

            int setsReales =
                0;

            int posicionesReales =
                0;

            foreach (PanoData p
                in _panos)
            {
                Tuple<int, int> conteo =
                    ContarAceroRealPano(
                        doc,
                        p);

                setsReales +=
                    conteo.Item1;

                posicionesReales +=
                    conteo.Item2;
            }

            string m =
                "Proceso terminado.\n\n" +
                "Paños procesados: " +
                ok +
                " / " +
                _panos.Count +
                "\nRebar Sets reales: " +
                setsReales +
                "\nPosiciones de barra reales: " +
                posicionesReales +
                "\nTramos puente: " +
                puentes;

            if (pre.RebarsEliminados > 0)
            {
                m +=
                    "\nRebar inválidos descartados automáticamente: " +
                    pre.RebarsEliminados;
            }

            if (errores.Count > 0)
            {
                m +=
                    "\n\nObservaciones:\n" +
                    string.Join(
                        "\n",
                        errores.Take(20));
            }

            TaskDialog.Show(
                "MYG - Acero en Losas",
                m);
        }

        private ResultadoPano CrearAceroPano(Document doc, PanoData p)
        {
            _firmasConjuntosActuales.Clear();

            ResultadoPano total = new ResultadoPano();
            List<Floor> floors = p.Losas.Select(id => doc.GetElement(id) as Floor).Where(x => x != null).ToList();
            if (floors.Count == 0) throw new Exception(p.Nombre + ": no contiene Floors válidos.");

            List<VigaData> vigas = p.AtravesarVigas ? ObtenerVigasCercanas(doc, p) : new List<VigaData>();
            RebarBarType infD1 = Tipo(doc, p.TipoInfD1Id);
            RebarBarType infD2 = Tipo(doc, p.TipoInfD2Id);
            RebarBarType supD1 = Tipo(doc, p.TipoSupD1Id);
            RebarBarType supD2 = Tipo(doc, p.TipoSupD2Id);

            double recInf = UnitUtils.ConvertToInternalUnits(p.RecInfCm, UnitTypeId.Centimeters);
            double recSup = UnitUtils.ConvertToInternalUnits(p.RecSupCm, UnitTypeId.Centimeters);
            double recLat = UnitUtils.ConvertToInternalUnits(p.RecLatCm, UnitTypeId.Centimeters);
            double dInfD1 = Diametro(infD1), dInfD2 = Diametro(infD2), dSupD1 = Diametro(supD1), dSupD2 = Diametro(supD2);

            if (p.CrearInfD1) Acumular(total, CrearCapa(doc, p, floors, vigas, false, p.D1, p.D1A, p.D1B,
                infD1, p.EspInfD1Cm, recInf + dInfD1 / 2.0, recLat, "INF_D1"));

            if (p.CrearInfD2) Acumular(total, CrearCapa(doc, p, floors, vigas, false, p.D2, p.D2A, p.D2B,
                infD2, p.EspInfD2Cm, recInf + (p.CrearInfD1 ? dInfD1 : 0.0) + dInfD2 / 2.0, recLat, "INF_D2"));

            if (p.CrearSupD1) Acumular(total, CrearCapa(doc, p, floors, vigas, true, p.D1, p.D1A, p.D1B,
                supD1, p.EspSupD1Cm, recSup + dSupD1 / 2.0, recLat, "SUP_D1"));

            if (p.CrearSupD2) Acumular(total, CrearCapa(doc, p, floors, vigas, true, p.D2, p.D2A, p.D2B,
                supD2, p.EspSupD2Cm, recSup + (p.CrearSupD1 ? dSupD1 : 0.0) + dSupD2 / 2.0, recLat, "SUP_D2"));

            return total;
        }

        private void Acumular(ResultadoPano a, ResultadoCapa b)
        {
            a.Barras += b.Barras;
            a.Puentes += b.Puentes;
            a.Errores.AddRange(b.Errores);
        }

        // =====================================================================
        // CREAR CAPA COMO CONJUNTOS CONTINUOS CON REGLA "ESPACIADO MAXIMO"
        // =====================================================================
        // IMPORTANTE:
        // - Ya NO se crea una barra individual por cada posición.
        // - Cada franja geométrica se crea como un Rebar SET.
        // - Revit recibe SetLayoutAsMaximumSpacing() con el valor del input.
        // - Los límites internos entre losas del mismo paño se unen para que
        //   las barras sean continuas. Si Revit no acepta un único host para
        //   toda la continuidad, se hace fallback por host, manteniendo la
        //   MISMA regla MaximumSpacing y la MISMA fase transversal.
        // =====================================================================
        private ResultadoCapa CrearCapa(
            Document doc, PanoData pano, List<Floor> floors, List<VigaData> vigas, bool superior,
            XYZ direccion, XYZ lineaA, XYZ lineaB, RebarBarType tipo, double espMaxCm,
            double profundidad, double recLat, string capa)
        {
            ResultadoCapa r = new ResultadoCapa();

            if (direccion == null ||
                lineaA == null ||
                lineaB == null ||
                tipo == null ||
                pano == null ||
                pano.Rectangulo.Count < 3)
            {
                return r;
            }

            XYZ dir = new XYZ(
                direccion.X,
                direccion.Y,
                0.0);

            if (dir.GetLength() < TOL)
                return r;

            dir = dir.Normalize();

            // Perpendicular a la barra en planta.
            // Es también la dirección de distribución del Rebar Set.
            XYZ trans = new XYZ(
                -dir.Y,
                dir.X,
                0.0).Normalize();

            double espMax =
                UnitUtils.ConvertToInternalUnits(
                    espMaxCm,
                    UnitTypeId.Centimeters);

            if (espMax <= TOL)
                return r;

            // =============================================================
            // D1 / D2 = SOLO DIRECCION + FASE
            // =============================================================
            // Los extremos gráficos de D1 / D2 YA NO limitan la longitud
            // longitudinal de las barras.
            //
            // La línea maestra aporta solamente:
            //   1) el vector de dirección "dir";
            //   2) la posición transversal de referencia "yMaster";
            //
            // La longitud real se obtiene después exclusivamente desde:
            //   - el BOCETO GENERAL,
            //   - huecos,
            //   - apoyos bloqueadores,
            //   - offset del boceto.
            // =============================================================

            // =============================================================
            // EL PAÑO ES AHORA EL BOUNDARY MAESTRO
            // =============================================================
            // El contorno de cada Floor ya NO recorta longitudinalmente las
            // barras. Los Floors solamente sirven para:
            //   1) obtener la elevación / cara de referencia,
            //   2) ser host cuando Revit lo permita.
            //
            // La geometría real que recorta el acero es:
            //
            //   BOCETO GENERAL
            //   - HUECOS FLOOR
            //   - HUECOS MANUALES
            //   - APOYOS BLOQUEADORES
            //   - RECUBRIMIENTO LATERAL
            //
            // D1/D2 NO recortan la longitud: solo aportan dirección + fase.
            //
            // Esto permite que un paño pase por vigas, pilares, muros o por
            // el límite entre dos Floors sin perder barras.
            // =============================================================

            // =============================================================
            // OFFSET GEOMETRICO REAL DEL BOCETO
            // =============================================================
            // "recLat" se utiliza ahora como OFFSET DEL BOCETO en planta.
            //
            // - El contorno exterior se desplaza HACIA ADENTRO.
            // - Los huecos se desplazan HACIA AFUERA.
            //
            // De esta forma la zona útil del acero es una verdadera región
            // offset, no simplemente un recorte X/Y de cada barra.
            // Esto respeta correctamente:
            //   - esquinas,
            //   - cambios de dirección,
            //   - bocetos poligonales,
            //   - entrantes,
            //   - huecos.
            // =============================================================

            List<XYZ> contornoUtilXYZ =
                OffsetPoligonoXY(
                    pano.Rectangulo,
                    recLat,
                    true);

            if (contornoUtilXYZ == null ||
                contornoUtilXYZ.Count < 3)
            {
                r.Errores.Add(
                    capa +
                    ": el Offset del boceto es demasiado grande o genera un contorno inválido.");

                return r;
            }

            List<P2> pano2D =
                A2D(
                    contornoUtilXYZ,
                    dir,
                    trans);

            // Huecos manuales del BOCETO GENERAL en el mismo sistema local
            // de la dirección actual. Estos huecos sí son parte del boundary
            // de armado y no dependen de la geometría de los Floors.
            List<List<P2>> huecosManuales2D =
                new List<List<P2>>();

            if (pano.HuecosManuales != null)
            {
                foreach (List<XYZ> hm
                    in pano.HuecosManuales)
                {
                    if (hm == null ||
                        hm.Count < 3)
                    {
                        continue;
                    }

                    List<XYZ> huecoUtilXYZ =
                        OffsetPoligonoXY(
                            hm,
                            recLat,
                            false);

                    if (huecoUtilXYZ == null ||
                        huecoUtilXYZ.Count < 3)
                    {
                        continue;
                    }

                    huecosManuales2D.Add(
                        A2D(
                            huecoUtilXYZ,
                            dir,
                            trans));
                }
            }

            // =============================================================
            // APOYOS QUE BLOQUEAN ESTA DIRECCION
            // =============================================================
            // NO todos los apoyos recortan una dirección.
            //
            // Ejemplo:
            //   - barra D1 horizontal + muro/viga horizontal:
            //       son paralelos -> el acero NO debe meterse dentro.
            //
            //   - barra D1 horizontal + muro/viga vertical:
            //       la barra llega perpendicular a la cara -> sí puede
            //       penetrar/atravesar para anclaje/continuidad.
            //
            // El recorte se hace en el MISMO sistema local dir/trans que
            // utiliza el paño.
            List<SoporteBloqueoDireccion> bloqueadoresDireccion =
                ObtenerSoportesBloqueadoresDireccion(
                    dir,
                    trans);

            // El boundary ya viene offseteado geométricamente.
            // NO volver a descontar recLat aquí para evitar doble offset.
            double ymin =
                pano2D.Min(q => q.Y);

            double ymax =
                pano2D.Max(q => q.Y);

            if (ymax <=
                ymin + TOL)
            {
                return r;
            }

            // -------------------------------------------------------------
            // Preparar Floors únicamente como hosts / referencia Z.
            // NO se usarán sus contornos exteriores como límite del acero.
            // -------------------------------------------------------------
            List<LosaCapa> datos =
                new List<LosaCapa>();

            foreach (Floor floor
                in floors)
            {
                if (floor == null)
                    continue;

                PlanarFace face =
                    CaraPrincipal(
                        floor,
                        superior);

                if (face == null)
                {
                    r.Errores.Add(
                        "Floor " +
                        floor.Id.Value +
                        ": no se encontró cara " +
                        (
                            superior
                            ? "superior."
                            : "inferior."
                        ));

                    continue;
                }

                if (Math.Abs(
                        face.FaceNormal.Z) <
                    0.5)
                {
                    r.Errores.Add(
                        "Floor " +
                        floor.Id.Value +
                        ": cara demasiado vertical.");

                    continue;
                }

                List<List<XYZ>> loops =
                    Loops(face);

                List<XYZ> ext =
                    Exterior(loops);

                if (ext == null ||
                    ext.Count < 3)
                {
                    continue;
                }

                // Basta con que el Floor esté seleccionado y sea razonablemente
                // cercano al paño. No exigimos que su exterior contenga cada
                // barra que posteriormente vamos a crear.
                if (!PoligonosIntersectanXY(
                        pano.Rectangulo,
                        ext))
                {
                    Box2 bp =
                        BoundingXY(
                            pano.Rectangulo);

                    Box2 bf =
                        BoundingXY(
                            ext);

                    double margen =
                        UnitUtils.ConvertToInternalUnits(
                            100.0,
                            UnitTypeId.Centimeters);

                    bool cerca =
                        bf.MaxX >=
                            bp.MinX - margen &&
                        bf.MinX <=
                            bp.MaxX + margen &&
                        bf.MaxY >=
                            bp.MinY - margen &&
                        bf.MinY <=
                            bp.MaxY + margen;

                    if (!cerca)
                        continue;
                }

                LosaCapa d =
                    new LosaCapa();

                d.Host =
                    floor;

                d.Face =
                    face;

                d.Normal =
                    face.FaceNormal.Normalize();

                d.Exterior =
                    A2D(
                        ext,
                        dir,
                        trans);

                foreach (List<XYZ> lp
                    in loops)
                {
                    if (!object.ReferenceEquals(
                            lp,
                            ext))
                    {
                        List<XYZ> huecoFloorUtil =
                            OffsetPoligonoXY(
                                lp,
                                recLat,
                                false);

                        if (huecoFloorUtil != null &&
                            huecoFloorUtil.Count >= 3)
                        {
                            d.Huecos.Add(
                                A2D(
                                    huecoFloorUtil,
                                    dir,
                                    trans));
                        }
                    }
                }

                datos.Add(d);
            }

            if (datos.Count == 0)
            {
                r.Errores.Add(
                    capa +
                    ": no se encontró ningún Floor de referencia para la elevación del acero.");

                return r;
            }

            XYZ master =
                new XYZ(
                    (
                        lineaA.X +
                        lineaB.X
                    ) /
                    2.0,
                    (
                        lineaA.Y +
                        lineaB.Y
                    ) /
                    2.0,
                    0.0);

            double yMaster =
                master.DotProduct(
                    trans);

            yMaster =
                Math.Max(
                    ymin,
                    Math.Min(
                        ymax,
                        yMaster));

            // =============================================================
            // CORTES TRANSVERSALES
            // =============================================================
            // Solo cambian cuando cambia:
            //   - el PAÑO,
            //   - un HUECO,
            //   - la línea maestra.
            //
            // Un borde de Floor ya NO crea una franja nueva.
            // =============================================================
            List<double> cortesY =
                CortesTransversales(
                    pano2D,
                    datos,
                    bloqueadoresDireccion,
                    huecosManuales2D,
                    dir,
                    trans,
                    ymin,
                    ymax,
                    yMaster,
                    pano.RespetarHuecos);

            if (cortesY.Count < 2)
                return r;

            for (int banda = 0;
                banda <
                cortesY.Count - 1;
                banda++)
            {
                double y0 =
                    cortesY[banda];

                double y1 =
                    cortesY[
                        banda + 1];

                double arrayLength =
                    y1 - y0;

                if (arrayLength <= TOL)
                    continue;

                double yEval =
                    (
                        y0 +
                        y1
                    ) /
                    2.0;

                // =========================================================
                // 1) TRAMOS REALES DEL PAÑO A ESTA ALTURA
                // =========================================================
                List<Intervalo> tramosPano =
                    IntervalosPoligono(
                        yEval,
                        pano2D);

                if (tramosPano.Count == 0)
                    continue;

                // =========================================================
                // INTERVALOS BASE DEL BOCETO ÚTIL
                // =========================================================
                // Se conservan ANTES de restar huecos y apoyos.
                //
                // Sirven para saber qué extremos pertenecen realmente al
                // perímetro exterior del boceto. Las mechas SOLO pueden
                // proyectarse desde esos extremos exteriores; nunca desde:
                //   - un hueco,
                //   - un entrante interior,
                //   - un corte producido por un apoyo interno.
                // =========================================================
                List<Intervalo> tramosBaseBoceto =
                    CopiarIntervalosBasicos(
                        tramosPano);

                // =========================================================
                // 2) LOS HUECOS SI CORTAN.
                //    Los límites EXTERIORES de los Floors NO.
                // =========================================================
                if (pano.RespetarHuecos)
                {
                    // =====================================================
                    // IMPORTANTE - HUECOS DE FLOOR NO SON CORTE GLOBAL
                    // =====================================================
                    // Antes TODOS los loops interiores de TODOS los Floors
                    // seleccionados se restaban del boceto general.
                    //
                    // En una planta compuesta por muchas losas esto genera
                    // "huecos fantasma": un vacío perteneciente a UN Floor
                    // podía borrar el acero aunque otra losa/viga/muro sí
                    // existiera en esa misma posición.
                    //
                    // NUEVA REGLA:
                    // - El BOCETO GENERAL + HUECOS DIBUJADOS por el usuario
                    //   son el boundary geométrico maestro.
                    // - Los huecos propios de cada Floor se usan SOLAMENTE
                    //   para comprobar si ESE Floor puede alojar un Rebar.
                    // - Nunca vuelven a recortar globalmente el armado.
                    //
                    // Esto elimina grandes zonas blancas no dibujadas como
                    // hueco en el preview.
                    // =====================================================

                    // Huecos MANUALES dibujados en el boceto general.
                    // Estos son independientes de los boundaries de los Floors
                    // y siempre recortan todas las capas/direcciones activas.
                    foreach (List<P2> huecoManual
                        in huecosManuales2D)
                    {
                        List<Intervalo> ih =
                            IntervalosPoligono(
                                yEval,
                                huecoManual);

                        foreach (Intervalo h
                            in ih)
                        {
                            tramosPano =
                                RestarHueco(
                                    tramosPano,
                                    h);
                        }
                    }
                }

                if (tramosPano.Count == 0)
                    continue;

                // =========================================================
                // 3) APOYOS / NUDOS ESTRUCTURALES
                // =========================================================
                // PERPENDICULAR no significa automáticamente "pasar".
                //
                // Se mantiene continuidad SOLO cuando existe un corredor real:
                //
                //     BOCETO -> ENTRADA -> APOYO -> SALIDA -> BOCETO
                //
                // Si el apoyo está en una esquina, termina contra una placa /
                // columna, toca el boundary o forma un nudo sin salida opuesta,
                // se recorta igual que una zona prohibida.
                tramosPano =
                    RestarBloqueadoresDireccion(
                        tramosPano,
                        bloqueadoresDireccion,
                        yEval);

                if (tramosPano.Count == 0)
                    continue;

                bool incluirPrimera =
                    banda == 0;

                bool incluirUltima =
                    true;

                for (int ip = 0;
                    ip < tramosPano.Count;
                    ip++)
                {
                    Intervalo tramo =
                        tramosPano[ip];

                    if (tramo == null ||
                        tramo.Fin <=
                        tramo.Inicio + TOL)
                    {
                        continue;
                    }

                    // =====================================================
                    // BOUNDARY FINAL
                    // =====================================================
                    // Ya NO aparece grupo.Inicio / grupo.Fin ni el exterior
                    // del Floor.
                    //
                    // El largo sale EXCLUSIVAMENTE de:
                    //   - boundary del boceto general
                    //   - huecos
                    //   - apoyos cuya cara NO es perpendicular a la barra
                    //   - offset del boceto
                    //
                    // D1 / D2 NO ponen límite en sus extremos.
                    // =====================================================
                    // =====================================================
                    // EXTREMOS REALES = BOUNDARY OFFSETEADO
                    // =====================================================
                    // El Offset del boceto ya está incorporado en pano2D.
                    // Por eso x0/x1 se toman DIRECTAMENTE del intervalo útil.
                    //
                    // No se vuelve a sumar/restar recLat aquí:
                    // hacerlo produciría un doble offset.
                    // =====================================================
                    double x0 =
                        tramo.Inicio;

                    double x1 =
                        tramo.Fin;

                    bool tieneMechaIzq =
                        false;

                    bool tieneMechaDer =
                        false;

                    if (x1 <=
                        x0 + TOL)
                    {
                        continue;
                    }

                    // =====================================================
                    // MECHAS EN APOYOS TERMINALES
                    // =====================================================
                    // La misma opción de continuidad activa también la
                    // proyección automática de mechas.
                    //
                    // REGLA:
                    //
                    // 1. El extremo debe pertenecer al perímetro EXTERIOR
                    //    del boceto útil.
                    //
                    // 2. Debe existir inmediatamente fuera del boceto un
                    //    único apoyo estructural:
                    //       VIGA / MURO-PLACA / PILAR.
                    //
                    // 3. La barra debe llegar perpendicular o casi
                    //    perpendicular al apoyo.
                    //
                    // 4. Si en esa zona hay más de un apoyo superpuesto o
                    //    conectado (ej. columna + placa de esquina), NO se
                    //    genera mecha. Se considera un NUDO.
                    //
                    // 5. El extremo se proyecta hasta la CARA OPUESTA del
                    //    apoyo menos el mismo Offset del boceto.
                    //
                    // Así:
                    //
                    //      LOSA               APOYO TERMINAL
                    //  ===================|████████████████
                    //                     |-------------> mecha
                    //                              ↑
                    //                        offset final
                    //
                    // D1/D2 siguen siendo SOLO dirección + fase.
                    // =====================================================
                    if (pano.AtravesarVigas)
                    {
                        Intervalo tramoBase =
                            EncontrarIntervaloBaseBoceto(
                                tramosBaseBoceto,
                                tramo);

                        if (tramoBase != null)
                        {
                            bool primerTramo =
                                EsPrimerTramoFinalEnBase(
                                    tramosPano,
                                    tramo,
                                    tramoBase);

                            bool ultimoTramo =
                                EsUltimoTramoFinalEnBase(
                                    tramosPano,
                                    tramo,
                                    tramoBase);

                            if (primerTramo)
                            {
                                MechaTerminalData mechaIzq =
                                    BuscarMechaTerminal(
                                        bloqueadoresDireccion,
                                        dir,
                                        trans,
                                        y0,
                                        y1,
                                        yEval,
                                        tramoBase.Inicio,
                                        x0,
                                        -1,
                                        recLat);

                                if (mechaIzq != null &&
                                    mechaIzq.Valida &&
                                    mechaIzq.ExtremoFinal <
                                        x0 - TOL)
                                {
                                    x0 =
                                        mechaIzq.ExtremoFinal;

                                    tieneMechaIzq =
                                        true;
                                }
                            }

                            if (ultimoTramo)
                            {
                                MechaTerminalData mechaDer =
                                    BuscarMechaTerminal(
                                        bloqueadoresDireccion,
                                        dir,
                                        trans,
                                        y0,
                                        y1,
                                        yEval,
                                        tramoBase.Fin,
                                        x1,
                                        +1,
                                        recLat);

                                if (mechaDer != null &&
                                    mechaDer.Valida &&
                                    mechaDer.ExtremoFinal >
                                        x1 + TOL)
                                {
                                    x1 =
                                        mechaDer.ExtremoFinal;

                                    tieneMechaDer =
                                        true;
                                }
                            }
                        }
                    }

                    if (x1 <=
                        x0 + TOL)
                    {
                        continue;
                    }

                    LosaCapa referencia =
                        ElegirLosaReferenciaPano(
                            datos,
                            yEval,
                            x0,
                            x1);

                    if (referencia == null)
                    {
                        r.Errores.Add(
                            capa +
                            " - franja " +
                            banda +
                            ": no se encontró Floor de referencia.");

                        continue;
                    }

                    try
                    {
                        int creadas =
                            CrearIntervaloPanoComoConjuntoMaximo(
                                doc,
                                pano,
                                datos,
                                referencia,
                                tipo,
                                dir,
                                trans,
                                y0,
                                y1,
                                yEval,
                                x0,
                                x1,
                                espMax,
                                profundidad,
                                incluirPrimera,
                                incluirUltima,
                                tieneMechaIzq,
                                tieneMechaDer,
                                capa,
                                r.Errores);

                        r.Barras +=
                            creadas;
                    }
                    catch (Exception ex)
                    {
                        r.Errores.Add(
                            capa +
                            " - franja " +
                            banda +
                            " - tramo " +
                            ip +
                            ": " +
                            ex.Message);
                    }
                }
            }

            return r;
        }

        // =====================================================================
        // MECHAS TERMINALES
        // =====================================================================

        private List<Intervalo> CopiarIntervalosBasicos(
            List<Intervalo> entrada)
        {
            List<Intervalo> salida =
                new List<Intervalo>();

            if (entrada == null)
                return salida;

            foreach (Intervalo x
                in entrada)
            {
                if (x == null ||
                    x.Fin <=
                        x.Inicio + TOL)
                {
                    continue;
                }

                salida.Add(
                    new Intervalo
                    {
                        Inicio =
                            x.Inicio,

                        Fin =
                            x.Fin,

                        InicioHueco =
                            x.InicioHueco,

                        FinHueco =
                            x.FinHueco
                    });
            }

            return salida;
        }

        private Intervalo EncontrarIntervaloBaseBoceto(
            List<Intervalo> bases,
            Intervalo tramo)
        {
            if (bases == null ||
                tramo == null)
            {
                return null;
            }

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            return
                bases
                .Where(
                    b =>
                        b != null &&
                        b.Inicio <=
                            tramo.Inicio + tol &&
                        b.Fin >=
                            tramo.Fin - tol)
                .OrderBy(
                    b =>
                        b.Fin -
                        b.Inicio)
                .FirstOrDefault();
        }

        private bool EsPrimerTramoFinalEnBase(
            List<Intervalo> finales,
            Intervalo actual,
            Intervalo baseBoceto)
        {
            if (finales == null ||
                actual == null ||
                baseBoceto == null)
            {
                return false;
            }

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            double minimo =
                finales
                .Where(
                    t =>
                        t != null &&
                        t.Fin >
                            baseBoceto.Inicio + tol &&
                        t.Inicio <
                            baseBoceto.Fin - tol)
                .Select(
                    t => t.Inicio)
                .DefaultIfEmpty(
                    double.MaxValue)
                .Min();

            return
                minimo !=
                    double.MaxValue &&
                Math.Abs(
                    actual.Inicio -
                    minimo) <=
                    tol;
        }

        private bool EsUltimoTramoFinalEnBase(
            List<Intervalo> finales,
            Intervalo actual,
            Intervalo baseBoceto)
        {
            if (finales == null ||
                actual == null ||
                baseBoceto == null)
            {
                return false;
            }

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            double maximo =
                finales
                .Where(
                    t =>
                        t != null &&
                        t.Fin >
                            baseBoceto.Inicio + tol &&
                        t.Inicio <
                            baseBoceto.Fin - tol)
                .Select(
                    t => t.Fin)
                .DefaultIfEmpty(
                    double.MinValue)
                .Max();

            return
                maximo !=
                    double.MinValue &&
                Math.Abs(
                    actual.Fin -
                    maximo) <=
                    tol;
        }

        private MechaTerminalData BuscarMechaTerminal(
            List<SoporteBloqueoDireccion> soportes,
            XYZ dir,
            XYZ trans,
            double y0,
            double y1,
            double yEval,
            double xBoundary,
            double xActual,
            int lado,
            double offsetFinal)
        {
            MechaTerminalData invalida =
                new MechaTerminalData
                {
                    Valida =
                        false
                };

            if (soportes == null ||
                soportes.Count == 0 ||
                dir == null ||
                trans == null ||
                (
                    lado != -1 &&
                    lado != +1
                ))
            {
                return invalida;
            }

            double eps =
                Math.Min(
                    UnitUtils.ConvertToInternalUnits(
                        0.20,
                        UnitTypeId.Centimeters),
                    Math.Max(
                        0.0,
                        (y1 - y0) *
                        0.10));

            double ya =
                y0 + eps;

            double ym =
                yEval;

            double yb =
                y1 - eps;

            if (yb < ya)
            {
                ya = ym;
                yb = ym;
            }

            // El boundary útil está desplazado hacia adentro.
            // Por eso permitimos buscar el apoyo unos centímetros fuera
            // del límite útil para encontrar la cara estructural real.
            double toleranciaAdyacencia =
                Math.Max(
                    offsetFinal +
                    UnitUtils.ConvertToInternalUnits(
                        3.0,
                        UnitTypeId.Centimeters),
                    UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Centimeters));

            double toleranciaUnion =
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Centimeters);

            List<CandidatoMechaTerminal> candidatos =
                new List<CandidatoMechaTerminal>();

            foreach (SoporteBloqueoDireccion s
                in soportes)
            {
                if (s == null ||
                    s.Soporte == null ||
                    s.Soporte.ElementId == null ||
                    s.Poligono2D == null ||
                    s.Poligono2D.Count < 3)
                {
                    continue;
                }

                // La mecha solo nace si la llegada angular es válida.
                // Los apoyos paralelos/oblicuos se consideran bloqueo.
                if (!s.PermitePasoAngular)
                    continue;

                List<Intervalo> ia =
                    IntervalosPoligono(
                        ya,
                        s.Poligono2D);

                List<Intervalo> im =
                    IntervalosPoligono(
                        ym,
                        s.Poligono2D);

                List<Intervalo> ib =
                    IntervalosPoligono(
                        yb,
                        s.Poligono2D);

                // La mecha es un Rebar Set. El apoyo debe existir en TODA
                // la banda transversal y no solamente sobre yEval.
                List<Intervalo> comunes =
                    IntersectarIntervalos(
                        IntersectarIntervalos(
                            ia,
                            im),
                        ib);

                foreach (Intervalo iv
                    in comunes)
                {
                    if (iv == null ||
                        iv.Fin <=
                            iv.Inicio + TOL)
                    {
                        continue;
                    }

                    bool tocaBoundary =
                        false;

                    bool conectaConTramo =
                        false;

                    if (lado < 0)
                    {
                        // El soporte debe extenderse realmente hacia afuera
                        // del boundary izquierdo.
                        tocaBoundary =
                            iv.Inicio <
                                xBoundary - TOL &&
                            iv.Fin >=
                                xBoundary -
                                toleranciaAdyacencia;

                        // El tramo final debe llegar hasta la cara interior
                        // del mismo apoyo o hasta el boundary offseteado.
                        conectaConTramo =
                            xActual <=
                                Math.Max(
                                    xBoundary,
                                    iv.Fin) +
                                toleranciaAdyacencia;
                    }
                    else
                    {
                        tocaBoundary =
                            iv.Fin >
                                xBoundary + TOL &&
                            iv.Inicio <=
                                xBoundary +
                                toleranciaAdyacencia;

                        conectaConTramo =
                            xActual >=
                                Math.Min(
                                    xBoundary,
                                    iv.Inicio) -
                                toleranciaAdyacencia;
                    }

                    if (!tocaBoundary ||
                        !conectaConTramo)
                    {
                        continue;
                    }

                    candidatos.Add(
                        new CandidatoMechaTerminal
                        {
                            Soporte =
                                s,

                            Inicio =
                                iv.Inicio,

                            Fin =
                                iv.Fin
                        });
                }
            }

            if (candidatos.Count == 0)
                return invalida;

            // =============================================================
            // DETECCIÓN DE NUDO / ESQUINA
            // =============================================================
            //
            // Si alrededor del mismo extremo aparecen dos o más elementos
            // estructurales distintos que se tocan/solapan, NO proyectamos.
            //
            // Esto bloquea:
            //   - columna + placa;
            //   - columna + viga;
            //   - encuentro de dos muros;
            //   - cualquier esquina/nudo estructural compuesto.
            //
            // Una mecha terminal solo se crea contra UN apoyo limpio.
            // =============================================================

            CandidatoMechaTerminal principal =
                candidatos
                .OrderBy(
                    c =>
                        lado < 0
                        ? Math.Abs(
                            xBoundary -
                            c.Fin)
                        : Math.Abs(
                            c.Inicio -
                            xBoundary))
                .FirstOrDefault();

            if (principal == null ||
                principal.Soporte == null ||
                principal.Soporte.Soporte == null)
            {
                return invalida;
            }

            double clusterInicio =
                principal.Inicio;

            double clusterFin =
                principal.Fin;

            bool cambio =
                true;

            HashSet<long> idsCluster =
                new HashSet<long>();

            while (cambio)
            {
                cambio =
                    false;

                foreach (CandidatoMechaTerminal c
                    in candidatos)
                {
                    if (c == null ||
                        c.Soporte == null ||
                        c.Soporte.Soporte == null ||
                        c.Soporte.Soporte.ElementId == null)
                    {
                        continue;
                    }

                    bool tocaCluster =
                        c.Fin >=
                            clusterInicio -
                            toleranciaUnion &&
                        c.Inicio <=
                            clusterFin +
                            toleranciaUnion;

                    if (!tocaCluster)
                        continue;

                    long id =
                        c.Soporte
                        .Soporte
                        .ElementId
                        .Value;

                    if (idsCluster.Add(id))
                    {
                        double nuevoInicio =
                            Math.Min(
                                clusterInicio,
                                c.Inicio);

                        double nuevoFin =
                            Math.Max(
                                clusterFin,
                                c.Fin);

                        if (Math.Abs(
                                nuevoInicio -
                                clusterInicio) >
                                TOL ||
                            Math.Abs(
                                nuevoFin -
                                clusterFin) >
                                TOL)
                        {
                            clusterInicio =
                                nuevoInicio;

                            clusterFin =
                                nuevoFin;

                            cambio =
                                true;
                        }
                    }
                }
            }

            // Más de un elemento real = nudo / esquina.
            if (idsCluster.Count != 1)
                return invalida;

            // La región debe corresponder al mismo ElementId del principal.
            long idPrincipal =
                principal
                .Soporte
                .Soporte
                .ElementId
                .Value;

            if (!idsCluster.Contains(
                    idPrincipal))
            {
                return invalida;
            }

            // =============================================================
            // EXTREMO FINAL DE LA MECHA
            // =============================================================
            //
            // Hasta cara opuesta menos el mismo Offset del boceto.
            //
            // izquierda:
            //      cara exterior = Inicio
            //      final = Inicio + offset
            //
            // derecha:
            //      cara exterior = Fin
            //      final = Fin - offset
            // =============================================================

            double extremoFinal =
                lado < 0
                ? clusterInicio +
                    offsetFinal
                : clusterFin -
                    offsetFinal;

            double extensionMinima =
                UnitUtils.ConvertToInternalUnits(
                    2.0,
                    UnitTypeId.Centimeters);

            if (lado < 0)
            {
                if (extremoFinal >=
                    xActual -
                    extensionMinima)
                {
                    return invalida;
                }
            }
            else
            {
                if (extremoFinal <=
                    xActual +
                    extensionMinima)
                {
                    return invalida;
                }
            }

            return
                new MechaTerminalData
                {
                    Valida =
                        true,

                    ExtremoFinal =
                        extremoFinal,

                    ElementIdSoporte =
                        principal
                        .Soporte
                        .Soporte
                        .ElementId,

                    TipoSoporte =
                        principal
                        .Soporte
                        .Soporte
                        .Tipo
                };
        }

        // =====================================================================
        // FLOOR DE REFERENCIA PARA Z / HOST
        // =====================================================================

        private LosaCapa ElegirLosaReferenciaPano(
            List<LosaCapa> datos,
            double yEval,
            double x0,
            double x1)
        {
            if (datos == null ||
                datos.Count == 0)
            {
                return null;
            }

            double centro =
                (
                    x0 +
                    x1
                ) /
                2.0;

            LosaCapa mejor =
                null;

            double mejorSolape =
                -1.0;

            double mejorDist =
                double.MaxValue;

            foreach (LosaCapa d
                in datos)
            {
                if (d == null ||
                    d.Exterior == null ||
                    d.Exterior.Count < 3)
                {
                    continue;
                }

                List<Intervalo> ints =
                    IntervalosPoligono(
                        yEval,
                        d.Exterior);

                double solape =
                    0.0;

                double dist =
                    double.MaxValue;

                foreach (Intervalo iv
                    in ints)
                {
                    double ini =
                        Math.Max(
                            x0,
                            iv.Inicio);

                    double fin =
                        Math.Min(
                            x1,
                            iv.Fin);

                    if (fin >
                        ini + TOL)
                    {
                        solape +=
                            fin - ini;
                    }

                    if (centro <
                        iv.Inicio)
                    {
                        dist =
                            Math.Min(
                                dist,
                                iv.Inicio -
                                centro);
                    }
                    else if (centro >
                        iv.Fin)
                    {
                        dist =
                            Math.Min(
                                dist,
                                centro -
                                iv.Fin);
                    }
                    else
                    {
                        dist =
                            0.0;
                    }
                }

                if (solape >
                        mejorSolape +
                        TOL ||
                    (
                        Math.Abs(
                            solape -
                            mejorSolape) <=
                            TOL &&
                        dist <
                            mejorDist
                    ))
                {
                    mejor =
                        d;

                    mejorSolape =
                        solape;

                    mejorDist =
                        dist;
                }
            }

            return
                mejor ??
                datos[0];
        }

        // =====================================================================
        // CREAR UN TRAMO COMPLETO DEL PAÑO.
        // EL FLOOR ES HOST, NO BOUNDARY.
        // =====================================================================

        private int CrearIntervaloPanoComoConjuntoMaximo(
            Document doc,
            PanoData pano,
            List<LosaCapa> datos,
            LosaCapa referencia,
            RebarBarType tipo,
            XYZ dir,
            XYZ trans,
            double y0,
            double y1,
            double yEval,
            double x0,
            double x1,
            double espMax,
            double profundidad,
            bool incluirPrimera,
            bool incluirUltima,
            bool tieneMechaIzq,
            bool tieneMechaDer,
            string capa,
            List<string> errores)
        {
            if (doc == null ||
                pano == null ||
                datos == null ||
                datos.Count == 0 ||
                referencia == null ||
                referencia.Face == null ||
                tipo == null)
            {
                return 0;
            }

            double arrayLength =
                y1 - y0;

            // =============================================================
            // GANCHOS 90° EN EXTREMOS
            // =============================================================
            // Los ganchos se modelan geométricamente como una pata a 90°
            // en el plano vertical de la barra.
            //
            // Capa inferior -> pata hacia ARRIBA.
            // Capa superior -> pata hacia ABAJO.
            //
            // La longitud y el diámetro de doblado los controla el RebarHookType nativo.
            // =============================================================
            bool ganchoHaciaArriba =
                !(
                    !string.IsNullOrEmpty(capa) &&
                    capa.StartsWith(
                        "SUP_",
                        StringComparison.OrdinalIgnoreCase)
                );

            double diametro =
                Math.Max(
                    Diametro(tipo),
                    UnitUtils.ConvertToInternalUnits(
                        0.5,
                        UnitTypeId.Centimeters));

            double minArray =
                Math.Max(
                    UnitUtils.ConvertToInternalUnits(
                        1.5,
                        UnitTypeId.Centimeters),
                    diametro * 1.25);

            if (arrayLength <= minArray ||
                x1 <= x0 + TOL)
            {
                return 0;
            }

            // =============================================================
            // INTENTO PRIORITARIO:
            // MECHAS TERMINALES CONTINUAS COMO UN SOLO ACERO
            // =============================================================
            // Cuando existe mecha en uno o ambos extremos, primero intentamos
            // crear UN SOLO Rebar Set desde x0 hasta x1 usando el host y la
            // cara de referencia del tramo (normalmente el Floor anfitrión).
            //
            // Objetivo:
            //   que las mechas no salgan como varios aceros pequeños
            //   independientes, sino como una sola barra continua junto con
            //   el tramo interior del boceto.
            //
            // Si Revit acepta este host continuo "de referencia", salimos.
            // Si no lo acepta, mantenemos la lógica multihost existente.
            //
            // Esto NO altera la regla geométrica:
            //   - la continuidad solo se propone para mechas ya validadas;
            //   - esquinas/nudos siguen bloqueados antes de llegar aquí.
            // =============================================================
            if (tieneMechaIzq ||
                tieneMechaDer)
            {
                try
                {
                    Element hostMechaContinuo =
                        referencia.Host;

                    if (hostMechaContinuo != null &&
                        referencia.Face != null)
                    {
                        XYZ caMecha =
                            PuntoCara(
                                referencia.Face,
                                referencia.Normal,
                                dir,
                                trans,
                                x0,
                                y0,
                                profundidad);

                        XYZ cbMecha =
                            PuntoCara(
                                referencia.Face,
                                referencia.Normal,
                                dir,
                                trans,
                                x1,
                                y0,
                                profundidad);

                        Rebar rbMechaContinuo =
                            CrearConjuntoMaximo(
                                doc,
                                hostMechaContinuo,
                                tipo,
                                trans,
                                caMecha,
                                cbMecha,
                                espMax,
                                arrayLength,
                                incluirPrimera,
                                incluirUltima,
                                Token(pano) +
                                "CAPA=" +
                                capa +
                                "|MAX_SPACING=1|PANO_BOUNDARY=1|MECHA_TERMINAL_CONTINUA=1|GANCHO90_NATIVO=1",
                                true,
                                true,
                                ganchoHaciaArriba);

                        if (rbMechaContinuo != null)
                        {
                            return
                                NumeroPosiciones(
                                    rbMechaContinuo);
                        }
                    }
                }
                catch
                {
                    // Si Revit no acepta la continuidad total en el host de
                    // referencia, seguimos con la lógica actual.
                }
            }

            // =============================================================
            // CONTINUIDAD REAL CON HOST COMPLETAMENTE VALIDO
            // =============================================================
            // Primero intentamos UN SOLO Rebar Set de x0 a x1, PERO
            // únicamente cuando un mismo Floor/apoyo contiene realmente
            // TODA la barra y TODA la banda transversal.
            //
            // Si no existe ese host completo, NO forzamos un host parcial:
            // pasamos directamente al fallback multihost. De esta manera
            // no desaparecen D1/D2 durante el Commit.
            Element hostContinuo =
                BuscarHostContinuoValido(
                    doc,
                    datos,
                    dir,
                    trans,
                    y0,
                    y1,
                    yEval,
                    x0,
                    x1,
                    pano.RespetarHuecos);

            if (hostContinuo != null)
            {
                try
                {
                    // Si el host continuo es un Floor seleccionado,
                    // usamos SU propia cara/elevación. Si es un apoyo
                    // estructural, usamos la cara de referencia del paño.
                    LosaCapa dataHostContinuo =
                        datos.FirstOrDefault(
                            d =>
                                d != null &&
                                d.Host != null &&
                                d.Host.Id.Value ==
                                    hostContinuo.Id.Value);

                    PlanarFace faceContinuo =
                        dataHostContinuo != null &&
                        dataHostContinuo.Face != null
                        ? dataHostContinuo.Face
                        : referencia.Face;

                    XYZ normalContinuo =
                        dataHostContinuo != null &&
                        dataHostContinuo.Normal != null
                        ? dataHostContinuo.Normal
                        : referencia.Normal;

                    XYZ ca =
                        PuntoCara(
                            faceContinuo,
                            normalContinuo,
                            dir,
                            trans,
                            x0,
                            y0,
                            profundidad);

                    XYZ cb =
                        PuntoCara(
                            faceContinuo,
                            normalContinuo,
                            dir,
                            trans,
                            x1,
                            y0,
                            profundidad);

                    Rebar continuo =
                        CrearConjuntoMaximo(
                            doc,
                            hostContinuo,
                            tipo,
                            trans,
                            ca,
                            cb,
                            espMax,
                            arrayLength,
                            incluirPrimera,
                            incluirUltima,
                            Token(pano) +
                            "CAPA=" +
                            capa +
                            "|MAX_SPACING=1|PANO_BOUNDARY=1|CONTINUO_HOST_VALIDO=1|GANCHO90_NATIVO=1",
                            true,
                            true,
                            ganchoHaciaArriba);

                    if (continuo != null)
                    {
                        return
                            NumeroPosiciones(
                                continuo);
                    }
                }
                catch
                {
                    // Si Revit no acepta un único host continuo,
                    // mantenemos el fallback multihost de abajo.
                }
            }

            // =============================================================
            // HOSTS REALES ÚNICAMENTE
            // =============================================================
            // El paño sigue siendo el boundary geométrico maestro, pero un
            // Rebar de Revit SIEMPRE necesita un anfitrión real.
            //
            // La versión anterior intentaba crear todo el tramo sobre un
            // Floor cualquiera. Eso generaba:
            //   - barras totalmente fuera de su anfitrión;
            //   - errores al Commit;
            //   - rollback del paño completo.
            //
            // Ahora cada tramo lógico se divide SIN SOLAPE entre Floors,
            // vigas, pilares y muros realmente presentes.
            // =============================================================

            List<CoberturaHostPano> coberturas =
                ObtenerCoberturasHostPano(
                    doc,
                    datos,
                    dir,
                    trans,
                    y0,
                    y1,
                    yEval,
                    x0,
                    x1,
                    pano.RespetarHuecos);

            List<CoberturaHostPano> cadena =
                ConstruirCadenaHostsPano(
                    coberturas,
                    x0,
                    x1);

            if (cadena.Count == 0)
            {
                if (errores != null)
                {
                    errores.Add(
                        capa +
                        ": no existe anfitrión estructural real para esta franja.");
                }

                return 0;
            }

            int total =
                0;

            double cubierto =
                cadena.Sum(
                    c =>
                        c == null
                        ? 0.0
                        : Math.Max(
                            0.0,
                            c.Fin - c.Inicio));

            double largoLogico =
                x1 - x0;

            double toleranciaHueco =
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Centimeters);

            if (errores != null &&
                cubierto <
                    largoLogico -
                    toleranciaHueco)
            {
                errores.Add(
                    capa +
                    ": parte del paño no posee Floor/Viga/Pilar/Muro que pueda alojar Rebar.");
            }

            foreach (CoberturaHostPano c
                in cadena)
            {
                if (c == null ||
                    c.Host == null)
                {
                    continue;
                }

                double sx0 =
                    Math.Max(
                        x0,
                        c.Inicio);

                double sx1 =
                    Math.Min(
                        x1,
                        c.Fin);

                // NO usar solapes entre hosts: dos sets solapados pueden
                // producir "barras coincidentes".
                if (sx1 <= sx0 + TOL)
                    continue;

                List<Element> hostsParaTramo =
                    ObtenerHostsAlternativosSubtramo(
                        coberturas,
                        sx0,
                        sx1);

                if (hostsParaTramo.Count == 0)
                    hostsParaTramo.Add(c.Host);

                bool creado =
                    false;

                foreach (Element host
                    in hostsParaTramo)
                {
                    if (host == null)
                        continue;

                    LosaCapa dataHost =
                        datos.FirstOrDefault(
                            d =>
                                d != null &&
                                d.Host != null &&
                                d.Host.Id.Value ==
                                    host.Id.Value);

                    PlanarFace faceBase =
                        dataHost != null &&
                        dataHost.Face != null
                        ? dataHost.Face
                        : referencia.Face;

                    XYZ normalBase =
                        dataHost != null &&
                        dataHost.Normal != null
                        ? dataHost.Normal
                        : referencia.Normal;

                    XYZ sa =
                        PuntoCara(
                            faceBase,
                            normalBase,
                            dir,
                            trans,
                            sx0,
                            y0,
                            profundidad);

                    XYZ sb =
                        PuntoCara(
                            faceBase,
                            normalBase,
                            dir,
                            trans,
                            sx1,
                            y0,
                            profundidad);

                    try
                    {
                        double tolGanchoExtremo =
                            UnitUtils.ConvertToInternalUnits(
                                0.2,
                                UnitTypeId.Centimeters);

                        bool ganchoInicioSubtramo =
                            Math.Abs(
                                sx0 -
                                x0) <=
                            tolGanchoExtremo;

                        bool ganchoFinSubtramo =
                            Math.Abs(
                                sx1 -
                                x1) <=
                            tolGanchoExtremo;

                        Rebar rb =
                            CrearConjuntoMaximo(
                                doc,
                                host,
                                tipo,
                                trans,
                                sa,
                                sb,
                                espMax,
                                arrayLength,
                                incluirPrimera,
                                incluirUltima,
                                Token(pano) +
                                "CAPA=" +
                                capa +
                                "|MAX_SPACING=1|PANO_BOUNDARY=1|HOST_REAL=1|GANCHO90_NATIVO=1",
                                ganchoInicioSubtramo,
                                ganchoFinSubtramo,
                                ganchoHaciaArriba);

                        if (rb != null)
                        {
                            total +=
                                NumeroPosiciones(
                                    rb);

                            creado =
                                true;

                            break;
                        }
                    }
                    catch
                    {
                        // Probar otro host que cubra el MISMO subtramo.
                    }
                }

                if (!creado &&
                    errores != null)
                {
                    errores.Add(
                        capa +
                        ": Revit rechazó un subtramo con host real.");
                }
            }

            return total;
        }

        // =====================================================================
        // HOST CONTINUO PARA APOYOS PERPENDICULARES
        // =====================================================================

        private Element BuscarHostContinuoValido(
            Document doc,
            List<LosaCapa> datos,
            XYZ dir,
            XYZ trans,
            double y0,
            double y1,
            double yEval,
            double x0,
            double x1,
            bool respetarHuecos)
        {
            if (doc == null ||
                datos == null ||
                dir == null ||
                trans == null ||
                y1 <= y0 + TOL ||
                x1 <= x0 + TOL)
            {
                return null;
            }

            // =============================================================
            // REGLA FUNDAMENTAL
            // =============================================================
            // Un único Rebar Set de x0 a x1 SOLO puede usar un host si ese
            // mismo host contiene TODA la longitud del bar y TODA la banda
            // transversal del set.
            //
            // Antes bastaba con que una viga/pilar/muro tuviera UN PEQUEÑO
            // SOLAPE con x0-x1. Eso hacía que una viga perpendicular estrecha
            // fuese elegida como host para una barra que atravesaba todo el
            // boceto. Revit creaba provisionalmente el set y luego lo borraba
            // al Commit por estar mayormente fuera de su anfitrión.
            //
            // Ese era el motivo por el que una dirección podía desaparecer
            // casi completa (normalmente D1 o D2).
            // =============================================================

            double epsY =
                Math.Min(
                    UnitUtils.ConvertToInternalUnits(
                        0.20,
                        UnitTypeId.Centimeters),
                    (y1 - y0) * 0.10);

            double ya =
                y0 + epsY;

            double ym =
                yEval;

            double yb =
                y1 - epsY;

            if (yb < ya)
            {
                ya = ym;
                yb = ym;
            }

            double tolCobertura =
                UnitUtils.ConvertToInternalUnits(
                    0.20,
                    UnitTypeId.Centimeters);

            // -------------------------------------------------------------
            // 1) PRIORIDAD: UN FLOOR QUE CUBRA TODO EL TRAMO.
            // -------------------------------------------------------------
            LosaCapa mejorFloor =
                null;

            double mejorMargenFloor =
                double.NegativeInfinity;

            foreach (LosaCapa d
                in datos)
            {
                if (d == null ||
                    d.Host == null ||
                    d.Exterior == null ||
                    d.Exterior.Count < 3)
                {
                    continue;
                }

                List<Intervalo> comunes =
                    IntervalosHostConservadoresBanda(
                        ya,
                        ym,
                        yb,
                        d.Exterior,
                        d.Huecos,
                        respetarHuecos);

                foreach (Intervalo iv
                    in comunes)
                {
                    if (iv == null)
                        continue;

                    bool cubreTodo =
                        iv.Inicio <=
                            x0 + tolCobertura &&
                        iv.Fin >=
                            x1 - tolCobertura;

                    if (!cubreTodo)
                        continue;

                    double margen =
                        Math.Min(
                            x0 - iv.Inicio,
                            iv.Fin - x1);

                    if (mejorFloor == null ||
                        margen >
                            mejorMargenFloor + TOL)
                    {
                        mejorFloor =
                            d;

                        mejorMargenFloor =
                            margen;
                    }
                }
            }

            if (mejorFloor != null &&
                mejorFloor.Host != null)
            {
                return
                    mejorFloor.Host;
            }

            // -------------------------------------------------------------
            // 2) APOYO ESTRUCTURAL:
            // SOLO si es una llegada perpendicular Y el apoyo contiene
            // TODA la barra x0-x1 en toda la banda y0-y1.
            //
            // En la práctica esto evita elegir como host continuo una viga
            // vertical de 50 cm para una barra horizontal de 8 m.
            // -------------------------------------------------------------
            if (_previewSoportes == null ||
                _previewSoportes.Count == 0)
            {
                return null;
            }

            PreviewSoporte mejorSoporte =
                null;

            double mejorMargenSoporte =
                double.NegativeInfinity;

            int mejorPrioridad =
                int.MaxValue;

            foreach (PreviewSoporte s
                in _previewSoportes)
            {
                if (s == null ||
                    s.ElementId == null ||
                    s.Exterior == null ||
                    s.Exterior.Count < 3)
                {
                    continue;
                }

                if (!PuedeBarraEntrarPerpendicularSoporte(
                        s,
                        dir))
                {
                    continue;
                }

                List<P2> pol =
                    A2D(
                        s.Exterior,
                        dir,
                        trans);

                if (pol == null ||
                    pol.Count < 3)
                {
                    continue;
                }

                List<Intervalo> ia =
                    IntervalosPoligono(
                        ya,
                        pol);

                List<Intervalo> im =
                    IntervalosPoligono(
                        ym,
                        pol);

                List<Intervalo> ib =
                    IntervalosPoligono(
                        yb,
                        pol);

                List<Intervalo> comunes =
                    IntersectarIntervalos(
                        IntersectarIntervalos(
                            ia,
                            im),
                        ib);

                foreach (Intervalo iv
                    in comunes)
                {
                    if (iv == null)
                        continue;

                    bool cubreTodo =
                        iv.Inicio <=
                            x0 + tolCobertura &&
                        iv.Fin >=
                            x1 - tolCobertura;

                    if (!cubreTodo)
                        continue;

                    int prioridad =
                        s.Tipo == "VIGA"
                        ? 0
                        : s.Tipo == "MURO"
                            ? 1
                            : s.Tipo == "PILAR"
                                ? 2
                                : 3;

                    double margen =
                        Math.Min(
                            x0 - iv.Inicio,
                            iv.Fin - x1);

                    if (mejorSoporte == null ||
                        prioridad <
                            mejorPrioridad ||
                        (
                            prioridad ==
                                mejorPrioridad &&
                            margen >
                                mejorMargenSoporte + TOL
                        ))
                    {
                        mejorSoporte =
                            s;

                        mejorPrioridad =
                            prioridad;

                        mejorMargenSoporte =
                            margen;
                    }
                }
            }

            if (mejorSoporte == null ||
                mejorSoporte.ElementId == null)
            {
                return null;
            }

            return
                doc.GetElement(
                    mejorSoporte.ElementId);
        }

        private List<Element> ObtenerHostsAlternativosSubtramo(
            List<CoberturaHostPano> coberturas,
            double x0,
            double x1)
        {
            List<Element> salida =
                new List<Element>();

            if (coberturas == null ||
                x1 <= x0 + TOL)
            {
                return salida;
            }

            HashSet<long> ids =
                new HashSet<long>();

            double tol =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            foreach (CoberturaHostPano c
                in coberturas
                .Where(
                    c =>
                        c != null &&
                        c.Host != null &&
                        c.Inicio <=
                            x0 + tol &&
                        c.Fin >=
                            x1 - tol)
                .OrderBy(c => c.Prioridad)
                .ThenByDescending(
                    c => c.Fin - c.Inicio))
            {
                if (ids.Add(c.Host.Id.Value))
                    salida.Add(c.Host);
            }

            return salida;
        }

        // =====================================================================
        // HOSTS CANDIDATOS PARA UN TRAMO DEL PAÑO
        // =====================================================================

        private List<Element> ObtenerHostsCandidatosPano(
            Document doc,
            List<LosaCapa> datos,
            double yEval,
            double x0,
            double x1)
        {
            List<Tuple<Element, double, int>> candidatos =
                new List<Tuple<Element, double, int>>();

            HashSet<long> ids =
                new HashSet<long>();

            // Floors primero, ordenados por cuánto se solapan con el tramo.
            foreach (LosaCapa d
                in datos)
            {
                if (d == null ||
                    d.Host == null)
                {
                    continue;
                }

                double solape =
                    LongitudSolapeIntervalos(
                        IntervalosPoligono(
                            yEval,
                            d.Exterior),
                        x0,
                        x1);

                candidatos.Add(
                    Tuple.Create(
                        (Element)d.Host,
                        solape,
                        0));
            }

            // Después apoyos estructurales detectados por el plano medio.
            foreach (PreviewSoporte s
                in _previewSoportes)
            {
                if (s == null ||
                    s.ElementId == null ||
                    s.Exterior == null ||
                    s.Exterior.Count < 3)
                {
                    continue;
                }

                Element host =
                    doc.GetElement(
                        s.ElementId);

                if (host == null)
                    continue;

                List<P2> pol =
                    A2D(
                        s.Exterior,
                        XYZ.BasisX,
                        XYZ.BasisY);

                // Reproyectar al sistema dir/trans del caller no es posible
                // con BasisX/BasisY aquí, por eso el orden fino por apoyo se
                // deja para ObtenerCoberturasHostPano().
                candidatos.Add(
                    Tuple.Create(
                        host,
                        0.0,
                        1));
            }

            List<Element> salida =
                new List<Element>();

            foreach (Tuple<Element, double, int> t
                in candidatos
                .OrderBy(x => x.Item3)
                .ThenByDescending(x => x.Item2))
            {
                if (t.Item1 == null)
                    continue;

                long id =
                    t.Item1.Id.Value;

                if (ids.Add(id))
                    salida.Add(
                        t.Item1);
            }

            return salida;
        }

        private double LongitudSolapeIntervalos(
            List<Intervalo> intervalos,
            double x0,
            double x1)
        {
            double total =
                0.0;

            if (intervalos == null)
                return total;

            foreach (Intervalo iv
                in intervalos)
            {
                double a =
                    Math.Max(
                        x0,
                        iv.Inicio);

                double b =
                    Math.Min(
                        x1,
                        iv.Fin);

                if (b >
                    a + TOL)
                {
                    total +=
                        b - a;
                }
            }

            return total;
        }

        // =====================================================================
        // COBERTURA REAL DE HOSTS PARA FALLBACK
        // =====================================================================

        private List<CoberturaHostPano> ObtenerCoberturasHostPano(
            Document doc,
            List<LosaCapa> datos,
            XYZ dir,
            XYZ trans,
            double y0,
            double y1,
            double yEval,
            double x0,
            double x1,
            bool respetarHuecos)
        {
            List<CoberturaHostPano> r =
                new List<CoberturaHostPano>();

            if (doc == null ||
                datos == null ||
                dir == null ||
                trans == null ||
                y1 <= y0 + TOL)
            {
                return r;
            }

            double eps =
                Math.Min(
                    UnitUtils.ConvertToInternalUnits(
                        0.2,
                        UnitTypeId.Centimeters),
                    (y1 - y0) * 0.10);

            double ya =
                y0 + eps;

            double ym =
                yEval;

            double yb =
                y1 - eps;

            if (yb < ya)
            {
                ya = ym;
                yb = ym;
            }

            // -------------------------------------------------------------
            // FLOORS: el host debe cubrir la franja completa, no sólo yEval.
            // -------------------------------------------------------------
            foreach (LosaCapa d
                in datos)
            {
                if (d == null ||
                    d.Host == null ||
                    d.Exterior == null ||
                    d.Exterior.Count < 3)
                {
                    continue;
                }

                List<Intervalo> ints =
                    IntervalosHostConservadoresBanda(
                        ya,
                        ym,
                        yb,
                        d.Exterior,
                        d.Huecos,
                        respetarHuecos);

                foreach (Intervalo iv
                    in ints)
                {
                    double a =
                        Math.Max(
                            x0,
                            iv.Inicio);

                    double b =
                        Math.Min(
                            x1,
                            iv.Fin);

                    if (b <= a + TOL)
                        continue;

                    r.Add(
                        new CoberturaHostPano
                        {
                            Host =
                                d.Host,

                            Inicio =
                                a,

                            Fin =
                                b,

                            Prioridad =
                                0
                        });
                }
            }

            // -------------------------------------------------------------
            // APOYOS: misma regla conservadora en toda la banda y0-y1.
            // -------------------------------------------------------------
            foreach (PreviewSoporte s
                in _previewSoportes)
            {
                if (s == null ||
                    s.ElementId == null ||
                    s.Exterior == null ||
                    s.Exterior.Count < 3)
                {
                    continue;
                }

                Element host =
                    doc.GetElement(
                        s.ElementId);

                if (host == null)
                    continue;

                List<P2> pol =
                    A2D(
                        s.Exterior,
                        dir,
                        trans);

                List<Intervalo> ia =
                    IntervalosPoligono(
                        ya,
                        pol);

                List<Intervalo> im =
                    IntervalosPoligono(
                        ym,
                        pol);

                List<Intervalo> ib =
                    IntervalosPoligono(
                        yb,
                        pol);

                List<Intervalo> ints =
                    IntersectarIntervalos(
                        IntersectarIntervalos(
                            ia,
                            im),
                        ib);

                foreach (Intervalo iv
                    in ints)
                {
                    double a =
                        Math.Max(
                            x0,
                            iv.Inicio);

                    double b =
                        Math.Min(
                            x1,
                            iv.Fin);

                    if (b <= a + TOL)
                        continue;

                    r.Add(
                        new CoberturaHostPano
                        {
                            Host =
                                host,

                            Inicio =
                                a,

                            Fin =
                                b,

                            Prioridad =
                                s.Tipo == "VIGA"
                                ? 1
                                : s.Tipo == "PILAR"
                                    ? 2
                                    : 3
                        });
                }
            }

            return
                r
                .OrderBy(x => x.Inicio)
                .ThenBy(x => x.Prioridad)
                .ThenByDescending(x => x.Fin)
                .ToList();
        }

        private List<Intervalo> IntervalosHostConservadoresBanda(
            double ya,
            double ym,
            double yb,
            List<P2> exterior,
            List<List<P2>> huecos,
            bool respetarHuecos)
        {
            List<Intervalo> a =
                IntervalosLosa(
                    ya,
                    exterior,
                    huecos,
                    respetarHuecos);

            List<Intervalo> m =
                IntervalosLosa(
                    ym,
                    exterior,
                    huecos,
                    respetarHuecos);

            List<Intervalo> b =
                IntervalosLosa(
                    yb,
                    exterior,
                    huecos,
                    respetarHuecos);

            return
                IntersectarIntervalos(
                    IntersectarIntervalos(
                        a,
                        m),
                    b);
        }

        // =====================================================================
        // CADENA CONTINUA DE HOSTS ENTRE x0 Y x1
        // =====================================================================

        private List<CoberturaHostPano> ConstruirCadenaHostsPano(
            List<CoberturaHostPano> coberturas,
            double x0,
            double x1)
        {
            List<CoberturaHostPano> salida =
                new List<CoberturaHostPano>();

            if (coberturas == null ||
                coberturas.Count == 0 ||
                x1 <= x0 + TOL)
            {
                return salida;
            }

            // Partición exacta por inicios/fines de hosts.
            // NO se rellena ningún hueco y NO se extiende ningún host.
            List<double> cortes =
                new List<double>
                {
                    x0,
                    x1
                };

            foreach (CoberturaHostPano c
                in coberturas)
            {
                if (c == null ||
                    c.Host == null)
                {
                    continue;
                }

                double a =
                    Math.Max(
                        x0,
                        c.Inicio);

                double b =
                    Math.Min(
                        x1,
                        c.Fin);

                if (b <= a + TOL)
                    continue;

                cortes.Add(a);
                cortes.Add(b);
            }

            cortes.Sort();

            double tolCorte =
                UnitUtils.ConvertToInternalUnits(
                    0.1,
                    UnitTypeId.Centimeters);

            List<double> limpios =
                new List<double>();

            foreach (double x
                in cortes)
            {
                if (limpios.Count == 0 ||
                    Math.Abs(
                        x -
                        limpios[
                            limpios.Count - 1]) >
                    tolCorte)
                {
                    limpios.Add(x);
                }
            }

            for (int i = 0;
                i < limpios.Count - 1;
                i++)
            {
                double a =
                    limpios[i];

                double b =
                    limpios[i + 1];

                if (b <= a + TOL)
                    continue;

                double mid =
                    (a + b) / 2.0;

                CoberturaHostPano elegido =
                    coberturas
                    .Where(
                        c =>
                            c != null &&
                            c.Host != null &&
                            c.Inicio <=
                                mid + TOL &&
                            c.Fin >=
                                mid - TOL)
                    .OrderBy(c => c.Prioridad)
                    .ThenByDescending(
                        c => c.Fin - c.Inicio)
                    .FirstOrDefault();

                if (elegido == null)
                    continue;

                if (salida.Count > 0 &&
                    salida[
                        salida.Count - 1]
                        .Host.Id.Value ==
                    elegido.Host.Id.Value &&
                    Math.Abs(
                        salida[
                            salida.Count - 1]
                            .Fin -
                        a) <=
                    tolCorte)
                {
                    salida[
                        salida.Count - 1]
                        .Fin =
                        b;
                }
                else
                {
                    salida.Add(
                        new CoberturaHostPano
                        {
                            Host =
                                elegido.Host,

                            Inicio =
                                a,

                            Fin =
                                b,

                            Prioridad =
                                elegido.Prioridad
                        });
                }
            }

            return salida;
        }

        // =====================================================================
        // REGLA DE PENETRACION PERPENDICULAR EN APOYOS
        // =====================================================================

        private List<SoporteBloqueoDireccion> ObtenerSoportesBloqueadoresDireccion(
            XYZ dir,
            XYZ trans)
        {
            List<SoporteBloqueoDireccion> resultado =
                new List<SoporteBloqueoDireccion>();

            if (dir == null ||
                trans == null ||
                _previewSoportes == null ||
                _previewSoportes.Count == 0)
            {
                return resultado;
            }

            XYZ d =
                new XYZ(
                    dir.X,
                    dir.Y,
                    0.0);

            if (d.GetLength() <= TOL)
                return resultado;

            d =
                d.Normalize();

            // =============================================================
            // IMPORTANTE
            // =============================================================
            // Antes aquí SOLO guardábamos los apoyos paralelos/oblicuos.
            // Eso no permitía distinguir un apoyo perpendicular "pasante"
            // de un apoyo perpendicular ubicado en una esquina o nudo.
            //
            // Ahora guardamos TODOS los apoyos junto con una bandera:
            //
            //   PermitePasoAngular = true
            //       la barra llega perpendicular/casi perpendicular.
            //
            //   PermitePasoAngular = false
            //       la barra llega paralela/oblicua.
            //
            // La decisión final de dejar pasar se toma DESPUÉS, para cada
            // línea de acero, comprobando además que realmente exista:
            //
            //   ENTRADA  -> APOYO -> SALIDA
            //
            // dentro del mismo boundary útil del boceto.
            // =============================================================

            foreach (PreviewSoporte s
                in _previewSoportes)
            {
                if (s == null ||
                    s.Exterior == null ||
                    s.Exterior.Count < 3)
                {
                    continue;
                }

                List<P2> pol =
                    A2D(
                        s.Exterior,
                        dir,
                        trans);

                if (pol == null ||
                    pol.Count < 3)
                {
                    continue;
                }

                resultado.Add(
                    new SoporteBloqueoDireccion
                    {
                        Soporte =
                            s,

                        Poligono2D =
                            pol,

                        PermitePasoAngular =
                            PuedeBarraEntrarPerpendicularSoporte(
                                s,
                                d)
                    });
            }

            return resultado;
        }

        private bool PuedeBarraEntrarPerpendicularSoporte(
            PreviewSoporte soporte,
            XYZ dir)
        {
            if (soporte == null ||
                soporte.Exterior == null ||
                soporte.Exterior.Count < 2 ||
                dir == null)
            {
                return false;
            }

            XYZ d =
                new XYZ(
                    dir.X,
                    dir.Y,
                    0.0);

            if (d.GetLength() <= TOL)
                return false;

            d =
                d.Normalize();

            string tipo =
                soporte.Tipo ??
                "";

            // -------------------------------------------------------------
            // VIGAS / MUROS
            // -------------------------------------------------------------
            // Usamos el eje longitudinal real del polígono.
            //
            // dir ⟂ eje:
            //     la barra atraviesa las CARAS LARGAS perpendicularmente
            //     -> SE PERMITE.
            //
            // dir ∥ eje:
            //     la barra corre dentro del apoyo / paralela a sus caras
            //     -> SE BLOQUEA.
            // -------------------------------------------------------------
            if (tipo == "VIGA" ||
                tipo == "MURO")
            {
                XYZ eje =
                    EjeLongitudinalSoporte(
                        soporte.Exterior);

                if (eje == null ||
                    eje.GetLength() <= TOL)
                {
                    return
                        TieneCaraPerpendicularADireccion(
                            soporte.Exterior,
                            d);
                }

                eje =
                    eje.Normalize();

                double dot =
                    Math.Abs(
                        eje.DotProduct(
                            d));

                double limitePerpendicular =
                    Math.Sin(
                        ANGULO_PERP_APOYO_GRADOS *
                        Math.PI /
                        180.0);

                // dot ~= 0 => barra perpendicular al eje longitudinal.
                return
                    dot <=
                    limitePerpendicular;
            }

            // -------------------------------------------------------------
            // PILARES
            // -------------------------------------------------------------
            // Un pilar no tiene un único "eje largo" útil en planta.
            // Permitimos entrar únicamente cuando existe una CARA real cuyo
            // borde sea aproximadamente perpendicular a la dirección de la
            // barra. Eso significa que la normal de esa cara es paralela a
            // la barra.
            // -------------------------------------------------------------
            if (tipo == "PILAR")
            {
                return
                    TieneCaraPerpendicularADireccion(
                        soporte.Exterior,
                        d);
            }

            // Para cualquier apoyo desconocido aplicamos la regla estricta.
            return
                TieneCaraPerpendicularADireccion(
                    soporte.Exterior,
                    d);
        }

        private XYZ EjeLongitudinalSoporte(
            List<XYZ> poligono)
        {
            if (poligono == null ||
                poligono.Count < 2)
            {
                return null;
            }

            XYZ mejor =
                null;

            double mayor =
                -1.0;

            for (int i = 0;
                i < poligono.Count;
                i++)
            {
                XYZ a =
                    poligono[i];

                XYZ b =
                    poligono[
                        (i + 1) %
                        poligono.Count];

                if (a == null ||
                    b == null)
                {
                    continue;
                }

                XYZ v =
                    new XYZ(
                        b.X - a.X,
                        b.Y - a.Y,
                        0.0);

                double l =
                    v.GetLength();

                if (l >
                    mayor + TOL)
                {
                    mayor =
                        l;

                    mejor =
                        v;
                }
            }

            if (mejor == null ||
                mejor.GetLength() <= TOL)
            {
                return null;
            }

            return
                mejor.Normalize();
        }

        private bool TieneCaraPerpendicularADireccion(
            List<XYZ> poligono,
            XYZ dir)
        {
            if (poligono == null ||
                poligono.Count < 2 ||
                dir == null)
            {
                return false;
            }

            XYZ d =
                new XYZ(
                    dir.X,
                    dir.Y,
                    0.0);

            if (d.GetLength() <= TOL)
                return false;

            d =
                d.Normalize();

            double limitePerpendicular =
                Math.Sin(
                    ANGULO_PERP_APOYO_GRADOS *
                    Math.PI /
                    180.0);

            double longitudMinCara =
                UnitUtils.ConvertToInternalUnits(
                    2.0,
                    UnitTypeId.Centimeters);

            for (int i = 0;
                i < poligono.Count;
                i++)
            {
                XYZ a =
                    poligono[i];

                XYZ b =
                    poligono[
                        (i + 1) %
                        poligono.Count];

                if (a == null ||
                    b == null)
                {
                    continue;
                }

                XYZ borde =
                    new XYZ(
                        b.X - a.X,
                        b.Y - a.Y,
                        0.0);

                double largo =
                    borde.GetLength();

                if (largo <=
                    longitudMinCara)
                {
                    continue;
                }

                borde =
                    borde.Normalize();

                // borde perpendicular a la barra => la barra llega normal
                // a esa cara.
                double dot =
                    Math.Abs(
                        borde.DotProduct(
                            d));

                if (dot <=
                    limitePerpendicular)
                {
                    return true;
                }
            }

            return false;
        }

        private List<Intervalo> RestarBloqueadoresDireccion(
            List<Intervalo> tramos,
            List<SoporteBloqueoDireccion> bloqueadores,
            double yEval)
        {
            List<Intervalo> resultado =
                tramos == null
                ? new List<Intervalo>()
                : tramos
                    .Select(
                        x =>
                            new Intervalo
                            {
                                Inicio =
                                    x.Inicio,

                                Fin =
                                    x.Fin,

                                InicioHueco =
                                    x.InicioHueco,

                                FinHueco =
                                    x.FinHueco
                            })
                    .ToList();

            if (resultado.Count == 0 ||
                bloqueadores == null ||
                bloqueadores.Count == 0)
            {
                return resultado;
            }

            // =============================================================
            // 1) CORTAR TODOS LOS APOYOS CON ESTA MISMA LÍNEA DE ACERO
            // =============================================================
            //
            // Se trabaja por yEval para NO agrupar toda la estructura del
            // edificio. Solo se fusionan los sólidos que realmente coinciden
            // o se tocan sobre ESTA línea.
            //
            // Esto es importante en nudos:
            //
            //      COLUMNA
            //        ███
            //  ------███████████  PLACA
            //
            // Para esa línea, columna + placa forman UNA región ocupada.
            // Si cualquiera de ellas no permite el paso o no existe salida
            // por el lado opuesto, toda la región se bloquea.
            // =============================================================

            List<IntervaloApoyoDireccion> ocupaciones =
                new List<IntervaloApoyoDireccion>();

            foreach (SoporteBloqueoDireccion s
                in bloqueadores)
            {
                if (s == null ||
                    s.Poligono2D == null ||
                    s.Poligono2D.Count < 3)
                {
                    continue;
                }

                List<Intervalo> ocupados =
                    IntervalosPoligono(
                        yEval,
                        s.Poligono2D);

                foreach (Intervalo ocupado
                    in ocupados)
                {
                    if (ocupado == null ||
                        ocupado.Fin <=
                            ocupado.Inicio + TOL)
                    {
                        continue;
                    }

                    ocupaciones.Add(
                        new IntervaloApoyoDireccion
                        {
                            Inicio =
                                ocupado.Inicio,

                            Fin =
                                ocupado.Fin,

                            PermitePasoAngular =
                                s.PermitePasoAngular,

                            Soportes =
                                new List<PreviewSoporte>
                                {
                                    s.Soporte
                                }
                        });
                }
            }

            if (ocupaciones.Count == 0)
                return resultado;

            // =============================================================
            // 2) FUSIONAR OCUPACIONES QUE SE TOCAN / SOLAPAN
            // =============================================================
            //
            // La fusión es LOCAL a yEval. Así una placa y una columna de una
            // esquina se analizan como un único nudo sólido, pero no se
            // convierte toda la retícula estructural en un único cluster.
            // =============================================================

            List<IntervaloApoyoDireccion> regiones =
                FusionarIntervalosApoyosDireccion(
                    ocupaciones);

            // =============================================================
            // 3) DECIDIR PARA CADA REGIÓN:
            //
            // A) Todos los sólidos permiten llegada perpendicular
            // B) Existe material útil del boceto ANTES de la región
            // C) Existe material útil del boceto DESPUÉS de la región
            //
            // A+B+C => CONTINUIDAD. No se resta nada.
            //
            // Si falla cualquiera:
            //   - paralelo/oblicuo,
            //   - esquina,
            //   - terminación contra columna/placa,
            //   - región tocando el boundary,
            // la región se RESTA y el acero termina en la primera cara.
            // =============================================================

            double salidaMinima =
                UnitUtils.ConvertToInternalUnits(
                    2.0,
                    UnitTypeId.Centimeters);

            foreach (IntervaloApoyoDireccion region
                in regiones)
            {
                if (region == null ||
                    region.Fin <=
                        region.Inicio + TOL)
                {
                    continue;
                }

                bool corredorPasante =
                    region.PermitePasoAngular &&
                    TieneEntradaYSalidaReal(
                        resultado,
                        region.Inicio,
                        region.Fin,
                        salidaMinima);

                if (corredorPasante)
                {
                    // PERPENDICULAR + ENTRADA + SALIDA:
                    // mantener el mismo intervalo del boceto.
                    //
                    // La barra pasa geométricamente continua por el apoyo.
                    continue;
                }

                // SIN SALIDA REAL o NO PERPENDICULAR:
                // el sólido completo de la región/nudo es una zona prohibida.
                resultado =
                    RestarIntervaloBloqueo(
                        resultado,
                        new Intervalo
                        {
                            Inicio =
                                region.Inicio,

                            Fin =
                                region.Fin,

                            InicioHueco =
                                true,

                            FinHueco =
                                true
                        });

                if (resultado.Count == 0)
                    return resultado;
            }

            return
                resultado
                .OrderBy(x => x.Inicio)
                .ThenBy(x => x.Fin)
                .ToList();
        }

        private List<IntervaloApoyoDireccion> FusionarIntervalosApoyosDireccion(
            List<IntervaloApoyoDireccion> entrada)
        {
            List<IntervaloApoyoDireccion> salida =
                new List<IntervaloApoyoDireccion>();

            if (entrada == null ||
                entrada.Count == 0)
            {
                return salida;
            }

            double toleranciaUnion =
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Centimeters);

            List<IntervaloApoyoDireccion> ordenados =
                entrada
                .Where(
                    x =>
                        x != null &&
                        x.Fin >
                            x.Inicio + TOL)
                .OrderBy(
                    x => x.Inicio)
                .ThenBy(
                    x => x.Fin)
                .ToList();

            foreach (IntervaloApoyoDireccion item
                in ordenados)
            {
                if (salida.Count == 0)
                {
                    salida.Add(
                        CopiarIntervaloApoyoDireccion(
                            item));

                    continue;
                }

                IntervaloApoyoDireccion ultimo =
                    salida[
                        salida.Count - 1];

                if (item.Inicio <=
                    ultimo.Fin +
                    toleranciaUnion)
                {
                    ultimo.Fin =
                        Math.Max(
                            ultimo.Fin,
                            item.Fin);

                    // Basta que UNO de los sólidos que forman el nudo no
                    // permita el paso angular para que el conjunto bloquee.
                    ultimo.PermitePasoAngular =
                        ultimo.PermitePasoAngular &&
                        item.PermitePasoAngular;

                    if (item.Soportes != null)
                    {
                        foreach (PreviewSoporte s
                            in item.Soportes)
                        {
                            if (s == null)
                                continue;

                            bool existe =
                                ultimo.Soportes.Any(
                                    q =>
                                        q != null &&
                                        q.ElementId != null &&
                                        s.ElementId != null &&
                                        q.ElementId.Value ==
                                            s.ElementId.Value);

                            if (!existe)
                                ultimo.Soportes.Add(s);
                        }
                    }
                }
                else
                {
                    salida.Add(
                        CopiarIntervaloApoyoDireccion(
                            item));
                }
            }

            return salida;
        }

        private IntervaloApoyoDireccion CopiarIntervaloApoyoDireccion(
            IntervaloApoyoDireccion origen)
        {
            IntervaloApoyoDireccion copia =
                new IntervaloApoyoDireccion();

            if (origen == null)
                return copia;

            copia.Inicio =
                origen.Inicio;

            copia.Fin =
                origen.Fin;

            copia.PermitePasoAngular =
                origen.PermitePasoAngular;

            if (origen.Soportes != null)
            {
                copia.Soportes.AddRange(
                    origen.Soportes
                    .Where(x => x != null));
            }

            return copia;
        }

        private bool TieneEntradaYSalidaReal(
            List<Intervalo> tramosUtiles,
            double inicioApoyo,
            double finApoyo,
            double salidaMinima)
        {
            if (tramosUtiles == null ||
                tramosUtiles.Count == 0 ||
                finApoyo <=
                    inicioApoyo + TOL)
            {
                return false;
            }

            // El apoyo debe estar contenido dentro de UN MISMO tramo útil
            // del boceto y debe sobrar una longitud real por ambos lados.
            //
            // Esto descarta automáticamente:
            //   - apoyos en el borde exterior;
            //   - columnas/placas en esquinas;
            //   - nudos que terminan el paño;
            //   - apoyo pegado a un hueco;
            //   - cualquier caso sin "cara de salida".
            foreach (Intervalo t
                in tramosUtiles)
            {
                if (t == null)
                    continue;

                bool contiene =
                    t.Inicio <=
                        inicioApoyo + TOL &&
                    t.Fin >=
                        finApoyo - TOL;

                if (!contiene)
                    continue;

                double entrada =
                    inicioApoyo -
                    t.Inicio;

                double salida =
                    t.Fin -
                    finApoyo;

                if (entrada >=
                        salidaMinima &&
                    salida >=
                        salidaMinima)
                {
                    return true;
                }
            }

            return false;
        }

        private List<Intervalo> RestarIntervaloBloqueo(
            List<Intervalo> existentes,
            Intervalo bloqueo)
        {
            List<Intervalo> salida =
                new List<Intervalo>();

            if (existentes == null ||
                bloqueo == null)
            {
                return salida;
            }

            foreach (Intervalo actual
                in existentes)
            {
                if (actual == null)
                    continue;

                if (bloqueo.Fin <=
                        actual.Inicio + TOL ||
                    bloqueo.Inicio >=
                        actual.Fin - TOL)
                {
                    salida.Add(
                        actual);

                    continue;
                }

                // Parte anterior al apoyo.
                if (bloqueo.Inicio >
                    actual.Inicio + TOL)
                {
                    double fin =
                        Math.Min(
                            bloqueo.Inicio,
                            actual.Fin);

                    if (fin >
                        actual.Inicio + TOL)
                    {
                        salida.Add(
                            new Intervalo
                            {
                                Inicio =
                                    actual.Inicio,

                                Fin =
                                    fin,

                                InicioHueco =
                                    actual.InicioHueco,

                                // Usamos el flag de hueco como "corte duro".
                                // Así las rutinas de continuidad tampoco
                                // intentan volver a puentear el apoyo.
                                FinHueco =
                                    true
                            });
                    }
                }

                // Parte posterior al apoyo.
                if (bloqueo.Fin <
                    actual.Fin - TOL)
                {
                    double inicio =
                        Math.Max(
                            bloqueo.Fin,
                            actual.Inicio);

                    if (actual.Fin >
                        inicio + TOL)
                    {
                        salida.Add(
                            new Intervalo
                            {
                                Inicio =
                                    inicio,

                                Fin =
                                    actual.Fin,

                                InicioHueco =
                                    true,

                                FinHueco =
                                    actual.FinHueco
                            });
                    }
                }
            }

            return salida;
        }

        // =====================================================================
        // CORTES TRANSVERSALES DE LA GEOMETRIA
        // =====================================================================
        private List<double> CortesTransversales(
            List<P2> rect2D,
            List<LosaCapa> datos,
            List<SoporteBloqueoDireccion> bloqueadoresDireccion,
            List<List<P2>> huecosManuales2D,
            XYZ dir,
            XYZ trans,
            double ymin,
            double ymax,
            double yMaster,
            bool respetarHuecos)
        {
            List<double> valores = new List<double>();

            AgregarCorteY(valores, ymin, ymin, ymax);
            AgregarCorteY(valores, ymax, ymin, ymax);
            AgregarCorteY(valores, yMaster, ymin, ymax);

            // Vértices del límite cerrado del paño.
            foreach (P2 p in rect2D)
                AgregarCorteY(valores, p.Y, ymin, ymax);

            // Los bordes EXTERIORES de los Floors NO recortan el acero,
            // pero SÍ dividen internamente los Rebar Sets por host.
            //
            // Esto evita que un solo Rebar Set, hospedado en un Floor,
            // distribuya barras hacia otro Floor y genere el aviso:
            // "La armadura se encuentra totalmente fuera de su anfitrión".
            if (datos != null)
            {
                foreach (LosaCapa d in datos)
                {
                    if (d == null || d.Exterior == null)
                        continue;

                    foreach (P2 p in d.Exterior)
                        AgregarCorteY(valores, p.Y, ymin, ymax);
                }
            }

            // Los apoyos estructurales también dividen internamente por host.
            if (_previewSoportes != null &&
                dir != null &&
                trans != null)
            {
                foreach (PreviewSoporte s in _previewSoportes)
                {
                    if (s == null ||
                        s.Exterior == null ||
                        s.Exterior.Count < 3)
                        continue;

                    List<P2> polHost = A2D(s.Exterior, dir, trans);

                    foreach (P2 p in polHost)
                        AgregarCorteY(valores, p.Y, ymin, ymax);
                }
            }

            // Los huecos internos de Floors NO introducen cortes globales.
            // Permanecen en LosaCapa.Huecos únicamente para validar hosts.
            //
            // Los huecos MANUALES sí introducen cortes transversales
            // exactamente en cada cambio de vértice del loop. De este modo
            // una banda de Rebar Set nunca salta por encima de un hueco.
            if (respetarHuecos &&
                huecosManuales2D != null)
            {
                foreach (List<P2> hm
                    in huecosManuales2D)
                {
                    if (hm == null)
                        continue;

                    foreach (P2 p
                        in hm)
                    {
                        AgregarCorteY(
                            valores,
                            p.Y,
                            ymin,
                            ymax);
                    }
                }
            }

            // Los límites transversales de los apoyos que BLOQUEAN esta
            // dirección también deben dividir la distribución. Así ningún
            // Rebar Set cruza transversalmente una franja donde cambia la
            // presencia de una viga/muro/pilar bloqueador.
            if (bloqueadoresDireccion != null)
            {
                foreach (SoporteBloqueoDireccion s
                    in bloqueadoresDireccion)
                {
                    if (s == null ||
                        s.Poligono2D == null)
                    {
                        continue;
                    }

                    foreach (P2 p
                        in s.Poligono2D)
                    {
                        AgregarCorteY(
                            valores,
                            p.Y,
                            ymin,
                            ymax);
                    }
                }
            }

            valores.Sort();

            // Agrupar cortes prácticamente coincidentes para evitar crear
            // cientos de franjas diminutas por teselaciones curvas.
            double toleranciaCorte = UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters);

            List<double> limpio = new List<double>();

            foreach (double y in valores)
            {
                if (limpio.Count == 0)
                {
                    limpio.Add(y);
                    continue;
                }

                if (Math.Abs(y - limpio[limpio.Count - 1]) <= toleranciaCorte)
                    continue;

                limpio.Add(y);
            }

            // Garantizar extremos exactos.
            if (limpio.Count == 0 || Math.Abs(limpio[0] - ymin) > TOL)
                limpio.Insert(0, ymin);

            if (Math.Abs(limpio[limpio.Count - 1] - ymax) > TOL)
                limpio.Add(ymax);

            return limpio;
        }

        private void AgregarCorteY(
            List<double> valores,
            double y,
            double ymin,
            double ymax)
        {
            if (y <= ymin + TOL)
                y = ymin;
            else if (y >= ymax - TOL)
                y = ymax;

            if (y < ymin - TOL || y > ymax + TOL)
                return;

            valores.Add(y);
        }

        // =====================================================================
        // CREAR UN GRUPO CONTINUO COMO REBAR SET MAXIMUM SPACING
        // =====================================================================
        private int CrearGrupoComoConjuntoMaximo(
            Document doc,
            PanoData pano,
            Grupo grupo,
            RebarBarType tipo,
            XYZ dir,
            XYZ trans,
            double y0,
            double y1,
            double x0,
            double x1,
            double espMax,
            double profundidad,
            bool incluirPrimera,
            bool incluirUltima,
            string capa,
            List<string> errores)
        {
            if (grupo == null || grupo.Segmentos.Count == 0)
                return 0;

            double arrayLength = y1 - y0;

            double minArray = UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

            if (arrayLength <= minArray)
                return 0;

            Segmento primero = grupo.Segmentos[0];
            Segmento ultimo = grupo.Segmentos[grupo.Segmentos.Count - 1];

            // -------------------------------------------------------------
            // PRIMER INTENTO:
            // Un único Rebar Set continuo a través de todas las losas y vigas
            // del grupo. El host será la primera losa, pero la geometría de la
            // barra llega hasta el último segmento. Revit permite barras que
            // se extienden más allá del contorno del host; si un proyecto en
            // particular no lo permite, se activa automáticamente el fallback.
            // -------------------------------------------------------------
            try
            {
                XYZ a = PuntoCara(
                    primero.Data.Face,
                    primero.Data.Normal,
                    dir,
                    trans,
                    x0,
                    y0,
                    profundidad);

                XYZ b = PuntoCara(
                    ultimo.Data.Face,
                    ultimo.Data.Normal,
                    dir,
                    trans,
                    x1,
                    y0,
                    profundidad);

                Rebar rb = CrearConjuntoMaximo(
                    doc,
                    primero.Data.Host,
                    tipo,
                    trans,
                    a,
                    b,
                    espMax,
                    arrayLength,
                    incluirPrimera,
                    incluirUltima,
                    Token(pano) +
                    "CAPA=" + capa +
                    "|MAX_SPACING=1|CONTINUO=1");

                if (rb != null)
                    return NumeroPosiciones(rb);
            }
            catch (Exception exContinuo)
            {
                // No abortamos. Intentaremos crear sets por host pero sin
                // perder alineación ni la regla MaximumSpacing.
                if (errores != null)
                {
                    errores.Add(
                        capa +
                        ": Revit no aceptó un único host continuo; " +
                        "se aplicó continuidad por host. Detalle: " +
                        exContinuo.Message);
                }
            }

            // -------------------------------------------------------------
            // FALLBACK:
            // Un set por cada host, todos con el mismo y0, arrayLength y
            // MaximumSpacing. Los extremos internos se solapan ligeramente
            // para que visualmente y geométricamente la barra sea continua.
            // -------------------------------------------------------------
            int total = 0;

            double solapeInterno = UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

            for (int i = 0; i < grupo.Segmentos.Count; i++)
            {
                Segmento s = grupo.Segmentos[i];

                double sx0 = s.Inicio;
                double sx1 = s.Fin;

                bool primeroGrupo = (i == 0);
                bool ultimoGrupo = (i == grupo.Segmentos.Count - 1);

                if (primeroGrupo)
                    sx0 = x0;
                else
                    sx0 -= solapeInterno;

                if (ultimoGrupo)
                    sx1 = x1;
                else
                    sx1 += solapeInterno;

                if (sx1 <= sx0 + TOL)
                    continue;

                try
                {
                    XYZ a = PuntoCara(
                        s.Data.Face,
                        s.Data.Normal,
                        dir,
                        trans,
                        sx0,
                        y0,
                        profundidad);

                    XYZ b = PuntoCara(
                        s.Data.Face,
                        s.Data.Normal,
                        dir,
                        trans,
                        sx1,
                        y0,
                        profundidad);

                    Rebar rb = CrearConjuntoMaximo(
                        doc,
                        s.Data.Host,
                        tipo,
                        trans,
                        a,
                        b,
                        espMax,
                        arrayLength,
                        incluirPrimera,
                        incluirUltima,
                        Token(pano) +
                        "CAPA=" + capa +
                        "|MAX_SPACING=1|CONTINUO_HOST=1");

                    if (rb != null)
                        total += NumeroPosiciones(rb);
                }
                catch (Exception ex)
                {
                    if (errores != null)
                    {
                        errores.Add(
                            capa +
                            " - Floor " +
                            s.Data.Host.Id.Value +
                            ": " +
                            ex.Message);
                    }
                }
            }

            return total;
        }

        // =====================================================================
        // GANCHOS NATIVOS DE REVIT - 90°
        // =====================================================================
        //
        // La geometría base del Rebar queda RECTA.
        // Los ganchos se asignan mediante BarTerminationsData:
        //
        //   Inicio de barra  = Gancho
        //   Gancho al inicio = RebarHookType 90°
        //   Final de barra   = Gancho
        //   Gancho al final  = RebarHookType 90°
        //
        // Esto hace que Revit controle de forma nativa:
        //   - diámetro de doblado;
        //   - extensión del gancho;
        //   - forma;
        //   - parámetros de instancia;
        //   - edición posterior desde Propiedades.
        //
        // En Revit 2026/2027 los métodos antiguos basados en
        // RebarHookOrientation están obsoletos. Aquí se utiliza
        // RebarTerminationOrientation.
        // =====================================================================

        private RebarHookType ObtenerGancho90(
            Document doc)
        {
            if (doc == null)
                return null;

            if (_gancho90Buscado)
            {
                if (_gancho90IdCache != null &&
                    _gancho90IdCache != ElementId.InvalidElementId)
                {
                    try
                    {
                        return
                            doc.GetElement(
                                _gancho90IdCache)
                            as RebarHookType;
                    }
                    catch
                    {
                    }
                }

                return null;
            }

            _gancho90Buscado =
                true;

            List<RebarHookType> tipos =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(RebarHookType))
                    .Cast<RebarHookType>()
                    .Where(x => x != null)
                    .ToList();

            if (tipos.Count == 0)
                return null;

            double angulo90 =
                Math.PI /
                2.0;

            double toleranciaAngulo =
                Math.PI /
                180.0 *
                1.0;

            List<RebarHookType> tipos90 =
                tipos
                .Where(
                    h =>
                    {
                        try
                        {
                            return
                                Math.Abs(
                                    h.HookAngle -
                                    angulo90) <=
                                toleranciaAngulo;
                        }
                        catch
                        {
                            return false;
                        }
                    })
                .ToList();

            if (tipos90.Count == 0)
                return null;

            // Prioridad:
            // 1. Nombre exacto usado en la interfaz española.
            // 2. Variantes habituales.
            // 3. Cualquier RebarHookType cuyo HookAngle sea 90°.
            string[] nombresPreferidos =
            {
                "Estándar - 90°",
                "Estandar - 90°",
                "Standard - 90°",
                "Estándar 90°",
                "Estandar 90°",
                "Standard 90°"
            };

            RebarHookType elegido =
                null;

            foreach (string nombre
                in nombresPreferidos)
            {
                elegido =
                    tipos90.FirstOrDefault(
                        h =>
                            string.Equals(
                                h.Name,
                                nombre,
                                StringComparison.OrdinalIgnoreCase));

                if (elegido != null)
                    break;
            }

            if (elegido == null)
            {
                elegido =
                    tipos90
                    .OrderByDescending(
                        h =>
                            !string.IsNullOrEmpty(h.Name) &&
                            h.Name.IndexOf(
                                "90",
                                StringComparison.OrdinalIgnoreCase) >=
                            0)
                    .ThenBy(
                        h => h.Name)
                    .FirstOrDefault();
            }

            if (elegido != null)
            {
                _gancho90IdCache =
                    elegido.Id;
            }

            return elegido;
        }

        private RebarTerminationOrientation OrientacionGanchoInicio(
            bool haciaArriba)
        {
            // Para una barra horizontal cuyo normal del plano es "trans":
            //
            // START:
            //   Left  -> +Z
            //   Right -> -Z
            //
            // Así el acero inferior puede levantar el gancho y el superior
            // puede bajarlo.
            return
                haciaArriba
                ? RebarTerminationOrientation.Left
                : RebarTerminationOrientation.Right;
        }

        private RebarTerminationOrientation OrientacionGanchoFin(
            bool haciaArriba)
        {
            // En el extremo final la relación Left/Right se invierte para
            // obtener el MISMO sentido Z en ambos extremos.
            //
            // END:
            //   Right -> +Z
            //   Left  -> -Z
            return
                haciaArriba
                ? RebarTerminationOrientation.Right
                : RebarTerminationOrientation.Left;
        }

        private void ConfigurarTerminacionesNativas90(
            BarTerminationsData term,
            RebarHookType hook90,
            bool ganchoInicio,
            bool ganchoFin,
            bool haciaArriba)
        {
            if (term == null ||
                hook90 == null)
            {
                return;
            }

            if (ganchoInicio)
            {
                term.HookTypeIdAtStart =
                    hook90.Id;

                term.TerminationOrientationAtStart =
                    OrientacionGanchoInicio(
                        haciaArriba);

                term.TerminationRotationAngleAtStart =
                    0.0;
            }

            if (ganchoFin)
            {
                term.HookTypeIdAtEnd =
                    hook90.Id;

                term.TerminationOrientationAtEnd =
                    OrientacionGanchoFin(
                        haciaArriba);

                term.TerminationRotationAngleAtEnd =
                    0.0;
            }
        }

        private void ReafirmarTerminacionesNativas90(
            Rebar rb,
            bool ganchoInicio,
            bool ganchoFin,
            bool haciaArriba)
        {
            if (rb == null)
                return;

            try
            {
                if (ganchoInicio)
                {
                    rb.SetTerminationOrientation(
                        0,
                        OrientacionGanchoInicio(
                            haciaArriba));

                    rb.SetTerminationRotationAngle(
                        0,
                        0.0);
                }

                if (ganchoFin)
                {
                    rb.SetTerminationOrientation(
                        1,
                        OrientacionGanchoFin(
                            haciaArriba));

                    rb.SetTerminationRotationAngle(
                        1,
                        0.0);
                }
            }
            catch
            {
                // BarTerminationsData ya lleva la orientación.
                // Este segundo paso solo reafirma el valor de instancia.
            }
        }

        // =====================================================================
        // REBAR SET - REGLA DE DISEÑO: ESPACIADO MAXIMO
        // =====================================================================
        private Rebar CrearConjuntoMaximo(
            Document doc,
            Element host,
            RebarBarType tipo,
            XYZ normalDistribucion,
            XYZ a,
            XYZ b,
            double espaciadoMaximo,
            double longitudDistribucion,
            bool incluirPrimera,
            bool incluirUltima,
            string comentario,
            bool ganchoInicio = false,
            bool ganchoFin = false,
            bool ganchoHaciaArriba = true)
        {
            if (doc == null ||
                host == null ||
                tipo == null ||
                normalDistribucion == null ||
                a == null ||
                b == null)
            {
                return null;
            }

            if (a.DistanceTo(b) < UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Centimeters))
            {
                return null;
            }

            string firma =
                FirmaConjuntoRebar(
                    a,
                    b,
                    normalDistribucion,
                    espaciadoMaximo,
                    longitudDistribucion);

            firma +=
                "|GI=" +
                (ganchoInicio ? "1" : "0") +
                "|GF=" +
                (ganchoFin ? "1" : "0") +
                "|GZ=" +
                (ganchoHaciaArriba ? "UP" : "DN");

            if (_firmasConjuntosActuales.Contains(firma))
                return null;

            if (espaciadoMaximo <= TOL ||
                longitudDistribucion <= TOL)
            {
                return null;
            }

            XYZ normal = new XYZ(
                normalDistribucion.X,
                normalDistribucion.Y,
                normalDistribucion.Z);

            if (normal.GetLength() < TOL)
                return null;

            normal = normal.Normalize();

            // IMPORTANTE:
            // Los hooks NO forman parte de la lista de curvas.
            // La API de Revit recibe únicamente la línea principal recta;
            // el gancho se define mediante BarTerminationsData.
            List<Curve> curvas =
                new List<Curve>
                {
                    Line.CreateBound(
                        a,
                        b)
                };

            RebarHookType hook90 =
                null;

            if (ganchoInicio ||
                ganchoFin)
            {
                hook90 =
                    ObtenerGancho90(
                        doc);
            }

            Rebar rb;

            using (BarTerminationsData term =
                new BarTerminationsData(doc))
            {
                if (hook90 != null)
                {
                    ConfigurarTerminacionesNativas90(
                        term,
                        hook90,
                        ganchoInicio,
                        ganchoFin,
                        ganchoHaciaArriba);
                }

                rb =
                    Rebar.CreateFromCurves(
                        doc,
                        RebarStyle.Standard,
                        tipo,
                        host,
                        normal,
                        curvas,
                        term,
                        true,
                        true);
            }

            if (rb == null)
                return null;

            // Reafirmar explícitamente los parámetros nativos de orientación
            // de terminación. Esto utiliza la API moderna de Revit.
            if (hook90 != null &&
                (ganchoInicio ||
                 ganchoFin))
            {
                ReafirmarTerminacionesNativas90(
                    rb,
                    ganchoInicio,
                    ganchoFin,
                    ganchoHaciaArriba);
            }

            // ESTA ES LA PARTE QUE CAMBIA EN PROPIEDADES DE REVIT:
            // Regla de diseño = Espaciado máximo.
            try
            {
                using (RebarShapeDrivenAccessor accessor = rb.GetShapeDrivenAccessor())
                {
                    accessor.SetLayoutAsMaximumSpacing(
                        espaciadoMaximo,
                        longitudDistribucion,
                        true,
                        incluirPrimera,
                        incluirUltima);
                }
            }
            catch
            {
                try
                {
                    doc.Delete(rb.Id);
                }
                catch
                {
                }

                return null;
            }

            _firmasConjuntosActuales.Add(firma);

            try
            {
                Parameter p = rb.get_Parameter(
                    BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                if (p != null && !p.IsReadOnly)
                    p.Set(comentario);
            }
            catch
            {
            }

            return rb;
        }

        private string FirmaConjuntoRebar(
            XYZ a,
            XYZ b,
            XYZ normal,
            double espaciado,
            double longitudDistribucion)
        {
            if (a == null ||
                b == null ||
                normal == null)
            {
                return Guid.NewGuid().ToString();
            }

            XYZ p0 = a;
            XYZ p1 = b;

            bool invertir =
                p0.X > p1.X + TOL ||
                (
                    Math.Abs(p0.X - p1.X) <= TOL &&
                    (
                        p0.Y > p1.Y + TOL ||
                        (
                            Math.Abs(p0.Y - p1.Y) <= TOL &&
                            p0.Z > p1.Z
                        )
                    )
                );

            if (invertir)
            {
                XYZ tmp = p0;
                p0 = p1;
                p1 = tmp;
            }

            Func<double, double> R =
                v => Math.Round(v, 6);

            return
                R(p0.X) + "|" +
                R(p0.Y) + "|" +
                R(p0.Z) + "|" +
                R(p1.X) + "|" +
                R(p1.Y) + "|" +
                R(p1.Z) + "|" +
                R(normal.X) + "|" +
                R(normal.Y) + "|" +
                R(normal.Z) + "|" +
                R(espaciado) + "|" +
                R(longitudDistribucion);
        }

        private int NumeroPosiciones(Rebar rb)
        {
            if (rb == null) return 0;

            try
            {
                int n = rb.NumberOfBarPositions;
                return Math.Max(1, n);
            }
            catch
            {
                return 1;
            }
        }

        private List<Intervalo> IntersectarIntervalos(List<Intervalo> a, List<Intervalo> b)
        {
            List<Intervalo> r = new List<Intervalo>();
            if (a == null || b == null) return r;
            foreach (Intervalo ia in a)
                foreach (Intervalo ib in b)
                {
                    double ini = Math.Max(ia.Inicio, ib.Inicio);
                    double fin = Math.Min(ia.Fin, ib.Fin);
                    if (fin <= ini + TOL) continue;
                    r.Add(new Intervalo
                    {
                        Inicio = ini,
                        Fin = fin,
                        InicioHueco = Math.Abs(ini - ia.Inicio) < TOL ? ia.InicioHueco : false,
                        FinHueco = Math.Abs(fin - ia.Fin) < TOL ? ia.FinHueco : false
                    });
                }
            return r.OrderBy(x => x.Inicio).ThenBy(x => x.Fin).ToList();
        }

        // Espaciamiento máximo, manteniendo una barra sobre la línea maestra.
        private List<double> DistribucionMaxima(double min, double max, double master, double maxSpacing)
        {
            List<double> y = new List<double>();
            master = Math.Max(min, Math.Min(max, master));
            y.Add(master);

            double izq = master - min;
            if (izq > TOL)
            {
                int n = Math.Max(1, (int)Math.Ceiling(izq / maxSpacing));
                double s = izq / n;
                for (int i = 1; i <= n; i++) y.Add(master - s * i);
            }

            double der = max - master;
            if (der > TOL)
            {
                int n = Math.Max(1, (int)Math.Ceiling(der / maxSpacing));
                double s = der / n;
                for (int i = 1; i <= n; i++) y.Add(master + s * i);
            }

            y.Sort();
            List<double> limpio = new List<double>();
            foreach (double v in y)
                if (limpio.Count == 0 || Math.Abs(v - limpio[limpio.Count - 1]) > TOL) limpio.Add(v);
            return limpio;
        }

        // =====================================================================
        // CONTINUIDAD / HUECOS / VIGAS
        // =====================================================================
        private List<Grupo> GruposContinuidad(List<Segmento> segs, List<VigaData> vigas,
            XYZ dir, XYZ trans, double y, double profundidad, bool atravesarVigas)
        {
            List<Grupo> res = new List<Grupo>();
            if (segs.Count == 0) return res;

            Grupo g = new Grupo();
            g.Segmentos.Add(segs[0]); g.Inicio = segs[0].Inicio; g.Fin = segs[0].Fin;

            for (int i = 1; i < segs.Count; i++)
            {
                Segmento prev = g.Segmentos[g.Segmentos.Count - 1];
                Segmento sig = segs[i];
                bool unir = sig.Inicio <= g.Fin + TOL_UNION;
                Puente puente = null;

                if (!unir && atravesarVigas && !prev.FinHueco && !sig.InicioHueco)
                {
                    double gap = sig.Inicio - g.Fin;
                    if (gap > TOL_UNION && gap <= GAP_MAX_VIGA)
                    {
                        XYZ p0 = PuntoCara(prev.Data.Face, prev.Data.Normal, dir, trans, g.Fin - EPS_HOST, y, profundidad);
                        XYZ p1 = PuntoCara(sig.Data.Face, sig.Data.Normal, dir, trans, sig.Inicio + EPS_HOST, y, profundidad);
                        VigaData vd = BuscarViga(vigas, p0, p1);
                        if (vd != null)
                        {
                            unir = true;
                            puente = new Puente { Viga = vd.Elemento, A = p0, B = p1 };
                        }
                    }
                }

                if (unir)
                {
                    g.Segmentos.Add(sig);
                    if (sig.Fin > g.Fin) g.Fin = sig.Fin;
                    if (puente != null) g.Puentes.Add(puente);
                }
                else
                {
                    res.Add(g);
                    g = new Grupo();
                    g.Segmentos.Add(sig); g.Inicio = sig.Inicio; g.Fin = sig.Fin;
                }
            }
            res.Add(g);
            return res;
        }

        private List<Intervalo> IntervalosLosa(double y, List<P2> exterior, List<List<P2>> huecos, bool respetarHuecos)
        {
            List<Intervalo> res = IntervalosPoligono(y, exterior);
            if (!respetarHuecos) return res;
            foreach (List<P2> h in huecos)
                foreach (Intervalo ih in IntervalosPoligono(y, h)) res = RestarHueco(res, ih);
            return res;
        }

        private List<Intervalo> IntervalosPoligono(double y, List<P2> pol)
        {
            List<double> xs = new List<double>();
            if (pol == null || pol.Count < 3) return new List<Intervalo>();

            for (int i = 0; i < pol.Count; i++)
            {
                P2 a = pol[i], b = pol[(i + 1) % pol.Count];
                bool cruza = (a.Y <= y && b.Y > y) || (b.Y <= y && a.Y > y);
                if (!cruza) continue;
                double dy = b.Y - a.Y;
                if (Math.Abs(dy) < TOL) continue;
                double t = (y - a.Y) / dy;
                xs.Add(a.X + t * (b.X - a.X));
            }

            xs.Sort();
            List<double> limpio = new List<double>();
            foreach (double x in xs)
                if (limpio.Count == 0 || Math.Abs(x - limpio[limpio.Count - 1]) > TOL) limpio.Add(x);

            List<Intervalo> r = new List<Intervalo>();
            for (int i = 0; i + 1 < limpio.Count; i += 2)
                if (limpio[i + 1] > limpio[i] + TOL) r.Add(new Intervalo { Inicio = limpio[i], Fin = limpio[i + 1] });
            return r;
        }

        private List<Intervalo> RestarHueco(List<Intervalo> existentes, Intervalo h)
        {
            List<Intervalo> r = new List<Intervalo>();
            foreach (Intervalo a in existentes)
            {
                if (h.Fin <= a.Inicio + TOL || h.Inicio >= a.Fin - TOL) { r.Add(a); continue; }

                if (h.Inicio > a.Inicio + TOL)
                {
                    Intervalo izq = new Intervalo { Inicio = a.Inicio, Fin = Math.Min(h.Inicio, a.Fin), InicioHueco = a.InicioHueco, FinHueco = true };
                    if (izq.Fin > izq.Inicio + TOL) r.Add(izq);
                }
                if (h.Fin < a.Fin - TOL)
                {
                    Intervalo der = new Intervalo { Inicio = Math.Max(h.Fin, a.Inicio), Fin = a.Fin, InicioHueco = true, FinHueco = a.FinHueco };
                    if (der.Fin > der.Inicio + TOL) r.Add(der);
                }
            }
            return r;
        }

        // Ahora esta lista incluye vigas, pilares y muros estructurales.
        private List<VigaData> ObtenerVigasCercanas(Document doc, PanoData pano)
        {
            Box2 b = BoundingPano(pano);
            double m = GAP_MAX_VIGA + UnitUtils.ConvertToInternalUnits(50.0, UnitTypeId.Centimeters);
            List<VigaData> r = new List<VigaData>();

            foreach (PreviewSoporte s in _previewSoportes)
            {
                if (s == null || s.ElementId == null) continue;
                BoundingBoxXYZ bb = s.Box;
                if (bb == null)
                {
                    Element ee = doc.GetElement(s.ElementId);
                    try { bb = ee == null ? null : ee.get_BoundingBox(null); } catch { }
                }
                if (bb == null) continue;
                if (bb.Max.X < b.MinX - m || bb.Min.X > b.MaxX + m || bb.Max.Y < b.MinY - m || bb.Min.Y > b.MaxY + m) continue;

                Element e = doc.GetElement(s.ElementId);
                if (e == null) continue;
                r.Add(new VigaData { Elemento = e, Box = bb });
            }
            return r;
        }

        private VigaData BuscarViga(List<VigaData> vigas, XYZ a, XYZ b)
        {
            if (vigas == null) return null;
            XYZ p20 = a + (b - a) * 0.20, p50 = a + (b - a) * 0.50, p80 = a + (b - a) * 0.80;
            double txy = UnitUtils.ConvertToInternalUnits(3.0, UnitTypeId.Centimeters);
            double tz = UnitUtils.ConvertToInternalUnits(25.0, UnitTypeId.Centimeters);
            foreach (VigaData v in vigas)
                if (Dentro(p20, v.Box, txy, tz) && Dentro(p50, v.Box, txy, tz) && Dentro(p80, v.Box, txy, tz)) return v;
            return null;
        }

        private bool Dentro(XYZ p, BoundingBoxXYZ b, double txy, double tz)
        {
            return p.X >= b.Min.X - txy && p.X <= b.Max.X + txy && p.Y >= b.Min.Y - txy && p.Y <= b.Max.Y + txy && p.Z >= b.Min.Z - tz && p.Z <= b.Max.Z + tz;
        }

        // =====================================================================
        // REBAR / GEOMETRIA
        // =====================================================================
        private XYZ PuntoCara(PlanarFace face, XYZ normal, XYZ dir, XYZ trans, double x, double y, double profundidad)
        {
            XYZ xy = dir * x + trans * y;
            XYZ o = face.Origin;
            double z = o.Z;
            if (Math.Abs(normal.Z) > 1e-9)
                z = o.Z - (normal.X * (xy.X - o.X) + normal.Y * (xy.Y - o.Y)) / normal.Z;
            return new XYZ(xy.X, xy.Y, z) - normal * profundidad;
        }

        private Rebar CrearBarra(Document doc, Element host, RebarBarType tipo, XYZ normal, XYZ a, XYZ b, string comentario)
        {
            if (host == null || tipo == null || normal == null || a == null || b == null) return null;
            if (a.DistanceTo(b) < UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters)) return null;

            List<Curve> curvas = new List<Curve> { Line.CreateBound(a, b) };
            Rebar rb;
            using (BarTerminationsData term = new BarTerminationsData(doc))
            {
                rb = Rebar.CreateFromCurves(doc, RebarStyle.Standard, tipo, host, normal, curvas, term, true, true);
            }
            if (rb != null)
            {
                try
                {
                    Parameter p = rb.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
                    if (p != null && !p.IsReadOnly) p.Set(comentario);
                }
                catch { }
            }
            return rb;
        }

        private void EliminarAceroAnterior(Document doc, PanoData pano)
        {
            string token = Token(pano);
            List<ElementId> ids = new List<ElementId>();
            foreach (Rebar rb in new FilteredElementCollector(doc).OfClass(typeof(Rebar)).Cast<Rebar>())
            {
                try
                {
                    Parameter p = rb.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
                    string s = p == null ? null : p.AsString();
                    if (!string.IsNullOrEmpty(s) && s.StartsWith(token, StringComparison.Ordinal)) ids.Add(rb.Id);
                }
                catch { }
            }
            if (ids.Count > 0) doc.Delete(ids);
        }

        private string Token(PanoData p) { return "MYG_ACERO_LOSA|PANO=" + p.Id + "|"; }

        private RebarBarType Tipo(Document doc, ElementId id)
        {
            if (id == null || id == ElementId.InvalidElementId) return null;
            return doc.GetElement(id) as RebarBarType;
        }

        private double Diametro(RebarBarType t)
        {
            if (t == null) return 0.0;
            try { if (t.BarModelDiameter > TOL) return t.BarModelDiameter; } catch { }
            try { if (t.BarNominalDiameter > TOL) return t.BarNominalDiameter; } catch { }
            try
            {
                Parameter p = t.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER);
                if (p != null && p.StorageType == StorageType.Double) return p.AsDouble();
            }
            catch { }
            return 0.0;
        }

        private PlanarFace CaraPrincipal(Floor floor, bool superior)
        {
            IList<Reference> refs = superior ? HostObjectUtils.GetTopFaces(floor) : HostObjectUtils.GetBottomFaces(floor);
            if (refs == null || refs.Count == 0) return null;
            PlanarFace mejor = null; double area = -1;
            foreach (Reference r in refs)
            {
                try
                {
                    PlanarFace f = floor.GetGeometryObjectFromReference(r) as PlanarFace;
                    if (f != null && f.Area > area) { area = f.Area; mejor = f; }
                }
                catch { }
            }
            return mejor;
        }

        private List<List<XYZ>> Loops(PlanarFace face)
        {
            List<List<XYZ>> res = new List<List<XYZ>>();
            if (face == null) return res;
            foreach (EdgeArray ea in face.EdgeLoops)
            {
                List<XYZ> pts = new List<XYZ>();
                foreach (Edge ed in ea)
                    foreach (XYZ p in ed.Tessellate())
                        if (pts.Count == 0 || pts[pts.Count - 1].DistanceTo(p) > TOL) pts.Add(p);
                if (pts.Count > 1 && pts[0].DistanceTo(pts[pts.Count - 1]) < TOL) pts.RemoveAt(pts.Count - 1);
                if (pts.Count >= 3) res.Add(pts);
            }
            return res;
        }

        private List<XYZ> Exterior(List<List<XYZ>> loops)
        {
            List<XYZ> mejor = null; double amax = -1;
            foreach (List<XYZ> lp in loops)
            {
                double a = Math.Abs(AreaXY(lp));
                if (a > amax) { amax = a; mejor = lp; }
            }
            return mejor;
        }

        private double AreaXY(List<XYZ> p)
        {
            double a = 0;
            for (int i = 0; i < p.Count; i++)
            {
                XYZ x = p[i], y = p[(i + 1) % p.Count];
                a += x.X * y.Y - y.X * x.Y;
            }
            return a / 2.0;
        }

        private List<P2> A2D(List<XYZ> pts, XYZ dir, XYZ trans)
        {
            List<P2> r = new List<P2>();
            foreach (XYZ p in pts) r.Add(new P2 { X = p.DotProduct(dir), Y = p.DotProduct(trans) });
            return r;
        }

        private PreviewLosa CrearPreview(Floor floor)
        {
            if (floor == null) return null;
            PlanarFace f = CaraPrincipal(floor, true);
            if (f == null) return null;
            List<List<XYZ>> loops = Loops(f);
            List<XYZ> ext = Exterior(loops);
            if (ext == null) return null;

            PreviewLosa p = new PreviewLosa { LosaId = floor.Id, Nombre = floor.Name, Contornos = loops, Exterior = ext };
            foreach (List<XYZ> lp in loops) if (!object.ReferenceEquals(lp, ext)) p.Huecos.Add(lp);
            return p;
        }

        private Box2 BoundingPano(PanoData p)
        {
            Box2 b = new Box2();
            if (p != null && p.Rectangulo.Count > 0)
            {
                foreach (XYZ q in p.Rectangulo)
                {
                    if (q.X < b.MinX) b.MinX = q.X; if (q.X > b.MaxX) b.MaxX = q.X;
                    if (q.Y < b.MinY) b.MinY = q.Y; if (q.Y > b.MaxY) b.MaxY = q.Y;
                }
            }
            else if (p != null)
            {
                foreach (PreviewLosa pv in p.Preview)
                    foreach (XYZ q in pv.Exterior)
                    {
                        if (q.X < b.MinX) b.MinX = q.X; if (q.X > b.MaxX) b.MaxX = q.X;
                        if (q.Y < b.MinY) b.MinY = q.Y; if (q.Y > b.MaxY) b.MaxY = q.Y;
                    }
            }
            if (b.MinX == double.MaxValue) b.MinX = b.MaxX = b.MinY = b.MaxY = 0;
            return b;
        }

        // =====================================================================
        // DIRECCIONES AUTOMATICAS DE RESPALDO
        // =====================================================================
        //
        // Objetivo:
        // - un paño nuevo SIEMPRE debe poder ejecutarse;
        // - D1 se propone siguiendo el borde más largo del paño;
        // - D2 se genera perpendicular;
        // - las líneas maestras abarcan toda la proyección del paño;
        // - el usuario puede reemplazarlas después manualmente.
        //
        // Esto también sirve como "seguro" si por cualquier motivo un paño
        // llega a la ejecución sin D1/D2 definidos.

        private void AsegurarDireccionesAutomaticas(
            PanoData p)
        {
            if (p == null ||
                p.Rectangulo == null ||
                p.Rectangulo.Count < 3)
            {
                return;
            }

            // -------------------------------------------------------------
            // D1
            // -------------------------------------------------------------
            if (!p.D1Definida ||
                p.D1 == null ||
                p.D1A == null ||
                p.D1B == null)
            {
                XYZ d1 =
                    DireccionPrincipalPano(
                        p.Rectangulo);

                if (d1 != null &&
                    d1.GetLength() > TOL)
                {
                    d1 =
                        new XYZ(
                            d1.X,
                            d1.Y,
                            0.0)
                        .Normalize();

                    XYZ a;
                    XYZ b;

                    CrearLineaMaestraSobrePano(
                        p,
                        d1,
                        out a,
                        out b);

                    p.D1 =
                        d1;

                    p.D1A =
                        a;

                    p.D1B =
                        b;

                    p.D1Definida =
                        a != null &&
                        b != null &&
                        a.DistanceTo(b) > TOL;
                }
            }

            // -------------------------------------------------------------
            // D2
            // -------------------------------------------------------------
            if ((!p.D2Definida ||
                 p.D2 == null ||
                 p.D2A == null ||
                 p.D2B == null) &&
                p.D1Definida &&
                p.D1 != null)
            {
                XYZ d2 =
                    new XYZ(
                        -p.D1.Y,
                        p.D1.X,
                        0.0);

                if (d2.GetLength() > TOL)
                {
                    d2 =
                        d2.Normalize();

                    XYZ a;
                    XYZ b;

                    CrearLineaMaestraSobrePano(
                        p,
                        d2,
                        out a,
                        out b);

                    p.D2 =
                        d2;

                    p.D2A =
                        a;

                    p.D2B =
                        b;

                    p.D2Definida =
                        a != null &&
                        b != null &&
                        a.DistanceTo(b) > TOL;

                    p.D2Auto =
                        true;
                }
            }
        }

        private XYZ DireccionPrincipalPano(
            List<XYZ> poligono)
        {
            if (poligono == null ||
                poligono.Count < 2)
            {
                return XYZ.BasisX;
            }

            XYZ mejor =
                null;

            double mayor =
                -1.0;

            for (int i = 0;
                i < poligono.Count;
                i++)
            {
                XYZ a =
                    poligono[i];

                XYZ b =
                    poligono[
                        (i + 1) %
                        poligono.Count];

                if (a == null ||
                    b == null)
                {
                    continue;
                }

                XYZ v =
                    new XYZ(
                        b.X - a.X,
                        b.Y - a.Y,
                        0.0);

                double l =
                    v.GetLength();

                if (l >
                    mayor + TOL)
                {
                    mayor =
                        l;

                    mejor =
                        v;
                }
            }

            if (mejor == null ||
                mejor.GetLength() <= TOL)
            {
                return XYZ.BasisX;
            }

            return
                mejor.Normalize();
        }

        private void CrearLineaMaestraSobrePano(
            PanoData p,
            XYZ direccion,
            out XYZ a,
            out XYZ b)
        {
            a = null;
            b = null;

            if (p == null ||
                p.Rectangulo == null ||
                p.Rectangulo.Count < 3 ||
                direccion == null)
            {
                return;
            }

            XYZ d =
                new XYZ(
                    direccion.X,
                    direccion.Y,
                    0.0);

            if (d.GetLength() <= TOL)
                return;

            d =
                d.Normalize();

            XYZ t =
                new XYZ(
                    -d.Y,
                    d.X,
                    0.0);

            XYZ centro =
                p.CentroRect;

            if (centro == null)
            {
                Box2 box =
                    BoundingPano(p);

                centro =
                    new XYZ(
                        (box.MinX + box.MaxX) / 2.0,
                        (box.MinY + box.MaxY) / 2.0,
                        0.0);
            }

            double y =
                centro.DotProduct(t);

            double xmin =
                double.MaxValue;

            double xmax =
                double.MinValue;

            foreach (XYZ q
                in p.Rectangulo)
            {
                if (q == null)
                    continue;

                double x =
                    q.DotProduct(d);

                if (x < xmin)
                    xmin = x;

                if (x > xmax)
                    xmax = x;
            }

            if (xmin == double.MaxValue ||
                xmax == double.MinValue ||
                xmax <= xmin + TOL)
            {
                return;
            }

            a =
                d * xmin +
                t * y;

            b =
                d * xmax +
                t * y;
        }

        // =====================================================================
        // OFFSET 2D DEL BOCETO / HUECOS
        // =====================================================================
        //
        // haciaInterior = true:
        //     desplaza el perímetro exterior hacia adentro.
        //
        // haciaInterior = false:
        //     expande el polígono hacia afuera.
        //     Se usa para los huecos, porque al expandir el hueco se reduce
        //     correctamente la zona útil de armado.
        //
        // El cálculo se hace con las rectas offset de cada lado y la
        // intersección de los lados consecutivos. Funciona con polígonos
        // cerrados ortogonales u oblicuos y conserva la forma del boceto.
        // =====================================================================

        private List<XYZ> OffsetPoligonoXY(
            List<XYZ> poligono,
            double distancia,
            bool haciaInterior)
        {
            List<XYZ> salida =
                new List<XYZ>();

            if (poligono == null ||
                poligono.Count < 3)
            {
                return salida;
            }

            List<XYZ> p =
                LimpiarVerticesPano(
                    poligono);

            if (p == null ||
                p.Count < 3)
            {
                return salida;
            }

            if (distancia <= TOL)
            {
                return
                    p.Select(
                        q =>
                            new XYZ(
                                q.X,
                                q.Y,
                                0.0))
                    .ToList();
            }

            double area =
                AreaPoligonoXY(
                    p);

            if (Math.Abs(area) <= TOL)
                return salida;

            // Para un polígono antihorario, el interior queda a la izquierda
            // de cada lado. Para uno horario, a la derecha.
            double signoInterior =
                area > 0.0
                ? 1.0
                : -1.0;

            double sentido =
                haciaInterior
                ? 1.0
                : -1.0;

            int n =
                p.Count;

            double maxMiter =
                Math.Max(
                    distancia * 8.0,
                    UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Centimeters));

            for (int i = 0;
                i < n;
                i++)
            {
                XYZ prev =
                    p[
                        (i - 1 + n) %
                        n];

                XYZ cur =
                    p[i];

                XYZ next =
                    p[
                        (i + 1) %
                        n];

                XYZ ePrev =
                    new XYZ(
                        cur.X - prev.X,
                        cur.Y - prev.Y,
                        0.0);

                XYZ eNext =
                    new XYZ(
                        next.X - cur.X,
                        next.Y - cur.Y,
                        0.0);

                double lPrev =
                    ePrev.GetLength();

                double lNext =
                    eNext.GetLength();

                if (lPrev <= TOL ||
                    lNext <= TOL)
                {
                    continue;
                }

                XYZ tPrev =
                    ePrev /
                    lPrev;

                XYZ tNext =
                    eNext /
                    lNext;

                XYZ nPrev =
                    new XYZ(
                        -tPrev.Y,
                        tPrev.X,
                        0.0) *
                    signoInterior *
                    sentido;

                XYZ nNext =
                    new XYZ(
                        -tNext.Y,
                        tNext.X,
                        0.0) *
                    signoInterior *
                    sentido;

                XYZ a =
                    cur +
                    nPrev *
                    distancia;

                XYZ b =
                    cur +
                    nNext *
                    distancia;

                XYZ inter =
                    InterseccionLineasInfinitasXY(
                        a,
                        tPrev,
                        b,
                        tNext);

                if (inter == null)
                {
                    // Lados prácticamente paralelos.
                    XYZ suma =
                        nPrev +
                        nNext;

                    if (suma.GetLength() <= TOL)
                        suma = nPrev;

                    suma =
                        suma.Normalize();

                    inter =
                        cur +
                        suma *
                        distancia;
                }

                // Limitar picos de miter extremadamente largos en ángulos
                // muy agudos. En esos casos usamos una unión bisectriz.
                if (inter.DistanceTo(cur) >
                    maxMiter)
                {
                    XYZ suma =
                        nPrev +
                        nNext;

                    if (suma.GetLength() <= TOL)
                        suma = nPrev;

                    suma =
                        suma.Normalize();

                    inter =
                        cur +
                        suma *
                        distancia;
                }

                salida.Add(
                    new XYZ(
                        inter.X,
                        inter.Y,
                        0.0));
            }

            salida =
                LimpiarVerticesPano(
                    salida);

            if (salida == null ||
                salida.Count < 3)
            {
                return
                    new List<XYZ>();
            }

            // Si el offset colapsó o se autointersectó, no inventamos una
            // geometría. El caller informará que el offset es demasiado grande.
            if (PoligonoAutointersectaXY(
                    salida))
            {
                return
                    new List<XYZ>();
            }

            double areaSalida =
                AreaPoligonoXY(
                    salida);

            if (Math.Abs(areaSalida) <= TOL)
            {
                return
                    new List<XYZ>();
            }

            // El sentido del loop debe conservarse.
            if (
                (area > 0.0 &&
                 areaSalida < 0.0)
                ||
                (area < 0.0 &&
                 areaSalida > 0.0)
            )
            {
                salida.Reverse();
            }

            return salida;
        }

        private XYZ InterseccionLineasInfinitasXY(
            XYZ p1,
            XYZ d1,
            XYZ p2,
            XYZ d2)
        {
            if (p1 == null ||
                d1 == null ||
                p2 == null ||
                d2 == null)
            {
                return null;
            }

            double den =
                d1.X *
                d2.Y -
                d1.Y *
                d2.X;

            if (Math.Abs(den) <=
                1e-10)
            {
                return null;
            }

            double dx =
                p2.X -
                p1.X;

            double dy =
                p2.Y -
                p1.Y;

            double t =
                (
                    dx *
                    d2.Y -
                    dy *
                    d2.X
                ) /
                den;

            return
                new XYZ(
                    p1.X +
                    d1.X *
                    t,

                    p1.Y +
                    d1.Y *
                    t,

                    0.0);
        }

        private void ValidarPano(Document doc, PanoData p)
        {
            if (p == null) throw new Exception("No existe un boceto general cerrado.");

            // Seguro adicional: si un paño antiguo o editado llega sin
            // D1/D2, se regeneran automáticamente antes de validar.
            AsegurarDireccionesAutomaticas(
                p);
            if (p.Rectangulo.Count < 3) throw new Exception(p.Nombre + ": el límite cerrado del paño no está definido.");
            if (p.Losas.Count == 0) throw new Exception(p.Nombre + ": el límite del paño no intersecta losas.");
            if (!p.D1Definida || p.D1A == null || p.D1B == null) throw new Exception(p.Nombre + ": dibuje D1.");
            if (!p.D2Definida || p.D2A == null || p.D2B == null) throw new Exception(p.Nombre + ": dibuje o genere D2.");
            if (!p.CrearInfD1 && !p.CrearInfD2 && !p.CrearSupD1 && !p.CrearSupD2) throw new Exception(p.Nombre + ": active al menos una capa.");
            if (p.CrearInfD1 && Tipo(doc, p.TipoInfD1Id) == null) throw new Exception(p.Nombre + ": falta tipo Inferior D1.");
            if (p.CrearInfD2 && Tipo(doc, p.TipoInfD2Id) == null) throw new Exception(p.Nombre + ": falta tipo Inferior D2.");
            if (p.CrearSupD1 && Tipo(doc, p.TipoSupD1Id) == null) throw new Exception(p.Nombre + ": falta tipo Superior D1.");
            if (p.CrearSupD2 && Tipo(doc, p.TipoSupD2Id) == null) throw new Exception(p.Nombre + ": falta tipo Superior D2.");
            if (p.EspInfD1Cm <= 0 || p.EspInfD2Cm <= 0 || p.EspSupD1Cm <= 0 || p.EspSupD2Cm <= 0) throw new Exception(p.Nombre + ": espaciamiento inválido.");
        }

        private void MostrarResultado(
            Document doc,
            PanoData p,
            ResultadoPano r,
            RebarFailurePreprocessor pre)
        {
            Tuple<int, int> conteo =
                ContarAceroRealPano(
                    doc,
                    p);

            string m =
                p.Nombre +
                " terminado.\n\n" +
                "Losas: " +
                p.Losas.Count +
                "\nRebar Sets reales: " +
                conteo.Item1 +
                "\nPosiciones de barra reales: " +
                conteo.Item2 +
                "\nTramos puente: " +
                (r == null ? 0 : r.Puentes);

            if (pre != null &&
                pre.RebarsEliminados > 0)
            {
                m +=
                    "\nRebar inválidos descartados automáticamente: " +
                    pre.RebarsEliminados;
            }

            if (r != null &&
                r.Errores.Count > 0)
            {
                m +=
                    "\n\nObservaciones:\n" +
                    string.Join(
                        "\n",
                        r.Errores.Take(20));
            }

            TaskDialog.Show(
                "MYG - Acero en Losas",
                m);
        }

        private Tuple<int, int> ContarAceroRealPano(
            Document doc,
            PanoData pano)
        {
            int sets =
                0;

            int posiciones =
                0;

            if (doc == null ||
                pano == null)
            {
                return
                    Tuple.Create(
                        sets,
                        posiciones);
            }

            string token =
                Token(pano);

            foreach (Rebar rb
                in new FilteredElementCollector(doc)
                    .OfClass(typeof(Rebar))
                    .Cast<Rebar>())
            {
                if (rb == null)
                    continue;

                try
                {
                    Parameter p =
                        rb.get_Parameter(
                            BuiltInParameter
                                .ALL_MODEL_INSTANCE_COMMENTS);

                    string s =
                        p == null
                        ? null
                        : p.AsString();

                    if (string.IsNullOrEmpty(s) ||
                        !s.StartsWith(
                            token,
                            StringComparison.Ordinal))
                    {
                        continue;
                    }

                    sets++;

                    posiciones +=
                        NumeroPosiciones(
                            rb);
                }
                catch
                {
                }
            }

            return
                Tuple.Create(
                    sets,
                    posiciones);
        }

        // =====================================================================
        // VENTANA INTERNA
        // =====================================================================
        private class VentanaAceroLosas : Form
        {
            private readonly EjecutarAceroLosasHandler _h;
            internal readonly ExternalEvent ExternalEvent;
            private readonly List<RebarBarType> _tipos = new List<RebarBarType>();
            private bool _cargando;
            private ModoDibujo _modo = ModoDibujo.Ninguno;
            private XYZ _primerPunto;
            private XYZ _mouseModelo;
            private XYZ _snapActual;
            private string _snapNombre = "";

            // Guía temporal del OSNAP, similar a las inferencias visuales
            // de Revit. Se dibuja punteada mientras el cursor está alineado,
            // proyectado o trabajando sobre la extensión de una línea.
            private XYZ _snapGuiaA;
            private XYZ _snapGuiaB;

            private readonly List<XYZ> _puntosPoligono = new List<XYZ>();

            private readonly Color FONDO = Color.FromArgb(245, 247, 250);
            private readonly Color PRINCIPAL = Color.FromArgb(35, 92, 160);
            private readonly Color ACTIVO = Color.FromArgb(225, 238, 252);

            private Label lblUniverso, lblPano, lblDir, lblZoom, lblSnap;
            private GroupBox grpDir, grpInf, grpSup, grpReglas;
            private Button btnEliminar, btnCrearActivo, btnDibujarHueco;
            private Button btnUndo, btnRedo, btnGuardarData, btnCargarData;
            private CheckBox chkOsnap, chkD2Auto, chkInfD1, chkInfD2, chkSupD1, chkSupD2, chkVigas, chkHuecos;
            private ComboBox cmbInfD1, cmbInfD2, cmbSupD1, cmbSupD2;
            private NumericUpDown nudInfD1, nudInfD2, nudSupD1, nudSupD2, nudRecInf, nudRecSup, nudRecLat;
            private PreviewPanel preview;

            private double _zoom = 1.0, _escalaBase = 1.0, _cxm, _cym;
            private PointF _pan = new PointF(0, 0);
            private bool _transformValida, _arrastrando;
            private Point _ultimoMouse;
            private const double ZMIN = 0.10, ZMAX = 40.0, ZFACTOR = 1.18;

            internal VentanaAceroLosas(EjecutarAceroLosasHandler h, ExternalEvent ev, List<RebarBarType> tipos)
            {
                _h = h; ExternalEvent = ev;
                if (tipos != null) _tipos.AddRange(tipos.Where(x => x != null).OrderBy(x => x.Name));
                Text = "MYG - Acero en Losas";
                StartPosition = FormStartPosition.CenterScreen;
                FormBorderStyle = FormBorderStyle.Sizable;
                MinimumSize = new Size(1180, 790);
                ClientSize = new Size(1360, 900);
                BackColor = FONDO;
                Font = new Font("Segoe UI", 9F);
                TopMost = true;
                CrearUI();
                CargarTipos();
                ConectarConfig();
                LimpiarPanoActivo();
                ActualizarBotonesHistorial();
            }

            private void CrearUI()
            {
                Panel head = new Panel { Dock = DockStyle.Top, Height = 72, BackColor = Color.White };
                Label t = new Label { Text = "MYG - ACERO EN LOSAS", Left = 22, Top = 14, Width = 430, Height = 26, Font = new Font("Segoe UI", 13F, FontStyle.Bold) };
                Label st = new Label { Text = "Boceto general + huecos + Offset interior · OSNAP estilo Revit: END/MID/NEAR/PERP/PAR/EXT/INT/PROY/ORTO · D1/D2", Left = 22, Top = 42, Width = 1080, Height = 20, ForeColor = Color.DimGray };
                head.Controls.Add(t); head.Controls.Add(st); Controls.Add(head);

                Panel izq = new Panel { Left = 14, Top = 86, Width = 480, Height = ClientSize.Height - 100, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, AutoScroll = true };
                Controls.Add(izq);

                GroupBox gu = Grupo("1. Losas disponibles", 12, 12, 450, 90); izq.Controls.Add(gu);
                Button bSel = Boton("Seleccionar losas", 12, 29, 170, 34, true); bSel.Click += delegate { _h.PedirUniverso(); };
                lblUniverso = new Label { Text = "0 losas disponibles", Left = 195, Top = 37, Width = 230 };
                gu.Controls.Add(bSel); gu.Controls.Add(lblUniverso);

                GroupBox gp = Grupo("2. Boceto general de armado", 12, 112, 450, 170); izq.Controls.Add(gp);
                Button bPol = Boton("Dibujar boceto", 12, 28, 140, 32, true);
                bPol.Click += delegate { IniciarDibujo(ModoDibujo.PanoPol); };

                btnDibujarHueco = Boton("+ Dibujar hueco", 160, 28, 135, 32, true);
                btnDibujarHueco.Click += delegate
                {
                    // MODO CONTINUO:
                    // primer clic  -> entrar en modo crear huecos;
                    // segundo clic -> salir del modo crear huecos.
                    //
                    // Mientras el modo esté activo, cerrar un hueco NO sale
                    // del modo: inmediatamente queda listo para dibujar el
                    // siguiente.
                    if (_modo == ModoDibujo.HuecoPol)
                    {
                        FinalizarModoHuecos();
                    }
                    else
                    {
                        IniciarDibujo(
                            ModoDibujo.HuecoPol);
                    }
                };

                btnEliminar = Boton("Borrar boceto", 303, 28, 130, 32, false);
                btnEliminar.Click += delegate { _h.EliminarPanoActivo(); };

                // ---------------------------------------------------------
                // HISTORIAL + PERSISTENCIA
                // ---------------------------------------------------------
                btnUndo = Boton("↶", 12, 70, 38, 30, false);
                btnRedo = Boton("↷", 54, 70, 38, 30, false);

                btnUndo.Font = new Font("Segoe UI Symbol", 13F, FontStyle.Bold);
                btnRedo.Font = new Font("Segoe UI Symbol", 13F, FontStyle.Bold);

                btnUndo.Click += delegate { _h.DeshacerEstado(); };
                btnRedo.Click += delegate { _h.RehacerEstado(); };

                btnGuardarData = Boton("Guardar data", 104, 70, 120, 30, false);
                btnCargarData = Boton("Cargar data", 232, 70, 120, 30, false);

                btnGuardarData.Click += delegate { GuardarDataDialogo(); };
                btnCargarData.Click += delegate { CargarDataDialogo(); };

                System.Windows.Forms.ToolTip ttHist =
                    new System.Windows.Forms.ToolTip();

                ttHist.SetToolTip(btnUndo, "Deshacer");
                ttHist.SetToolTip(btnRedo, "Rehacer");
                ttHist.SetToolTip(btnGuardarData, "Guardar boceto, huecos, D1/D2 y configuración");
                ttHist.SetToolTip(btnCargarData, "Cargar data guardada. La carga también se puede deshacer.");

                lblPano = new Label { Text = "Boceto: no definido", Left = 12, Top = 112, Width = 420, Height = 36, ForeColor = Color.DimGray };

                gp.Controls.Add(bPol);
                gp.Controls.Add(btnDibujarHueco);
                gp.Controls.Add(btnEliminar);
                gp.Controls.Add(btnUndo);
                gp.Controls.Add(btnRedo);
                gp.Controls.Add(btnGuardarData);
                gp.Controls.Add(btnCargarData);
                gp.Controls.Add(lblPano);

                grpDir = Grupo("3. Direcciones maestras del armado", 12, 292, 450, 160); izq.Controls.Add(grpDir);
                Button d1 = Boton("Dibujar D1", 12, 28, 120, 30, false); d1.Click += delegate { IniciarDibujo(ModoDibujo.D1); };
                Button d2 = Boton("Dibujar D2", 140, 28, 120, 30, false); d2.Click += delegate { IniciarDibujo(ModoDibujo.D2); };
                Button swap = Boton("D1 / D2", 268, 28, 82, 30, false); swap.Click += delegate { Intercambiar(); };
                Button sug = Boton("Sugerir", 358, 28, 76, 30, false); sug.Click += delegate { Sugerir(); };
                chkOsnap = new CheckBox { Text = "OSNAP", Left = 14, Top = 70, Width = 82, Checked = true };
                chkD2Auto = new CheckBox { Text = "D2 perpendicular automática a D1", Left = 105, Top = 70, Width = 290, Checked = true };
                chkD2Auto.CheckedChanged += delegate
                {
                    if (_cargando) return;
                    PanoData p = _h.PanoActivo(); if (p == null) return;

                    _h.RegistrarUndo();

                    p.D2Auto = chkD2Auto.Checked;
                    if (p.D2Auto && p.D1Definida) GenerarD2(p);

                    ActualizarBotonesHistorial();
                };
                lblDir = new Label { Text = "Dibuje el boceto general.", Left = 14, Top = 100, Width = 415, Height = 44, ForeColor = Color.DimGray };
                grpDir.Controls.Add(d1); grpDir.Controls.Add(d2); grpDir.Controls.Add(swap); grpDir.Controls.Add(sug); grpDir.Controls.Add(chkOsnap); grpDir.Controls.Add(chkD2Auto); grpDir.Controls.Add(lblDir);

                grpInf = Grupo("4. Acero inferior - espaciamiento máximo", 12, 462, 450, 138); izq.Controls.Add(grpInf);
                FilaAcero(grpInf, 28, "Dirección D1", out chkInfD1, out cmbInfD1, out nudInfD1);
                FilaAcero(grpInf, 76, "Dirección D2", out chkInfD2, out cmbInfD2, out nudInfD2);

                grpSup = Grupo("5. Acero superior - espaciamiento máximo", 12, 610, 450, 138); izq.Controls.Add(grpSup);
                FilaAcero(grpSup, 28, "Dirección D1", out chkSupD1, out cmbSupD1, out nudSupD1);
                FilaAcero(grpSup, 76, "Dirección D2", out chkSupD2, out cmbSupD2, out nudSupD2);

                grpReglas = Grupo("6. Reglas del boceto general", 12, 758, 450, 148); izq.Controls.Add(grpReglas);
                NumericEtiqueta(grpReglas, "Rec. inferior", 14, 27, out nudRecInf, 2.5M);
                NumericEtiqueta(grpReglas, "Rec. superior", 150, 27, out nudRecSup, 2.5M);
                NumericEtiqueta(grpReglas, "Offset boceto", 286, 27, out nudRecLat, 2.5M);
                chkVigas = new CheckBox { Text = "Continuidad + mechas en apoyos terminales", Left = 14, Top = 88, Width = 335, Checked = true };
                chkHuecos = new CheckBox { Text = "Solo huecos dibujados cortan el acero", Left = 14, Top = 114, Width = 315, Checked = true };
                Label lblGanchos = new Label
                {
                    Text = "Gancho nativo en extremos: Estándar - 90°",
                    Left = 14,
                    Top = 136,
                    Width = 360,
                    Height = 18,
                    ForeColor = Color.DimGray
                };
                grpReglas.Height = 170;
                grpReglas.Controls.Add(chkVigas); grpReglas.Controls.Add(chkHuecos); grpReglas.Controls.Add(lblGanchos);

                Panel acciones = new Panel { Left = 12, Top = 940, Width = 450, Height = 92, BackColor = Color.White }; izq.Controls.Add(acciones);
                btnCrearActivo = Boton("CREAR ACERO EN BOCETO", 0, 8, 300, 40, true);
                btnCrearActivo.Click += delegate { _h.PedirCrearActivo(); };
                Button cerrar = Boton("Cerrar", 310, 8, 135, 40, false); cerrar.Click += delegate { Close(); };
                acciones.Controls.Add(btnCrearActivo); acciones.Controls.Add(cerrar);

                GroupBox gPrev = Grupo("Vista preliminar", 507, 86, 835, 800); gPrev.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right; Controls.Add(gPrev);
                Label ay = new Label { Text = "OSNAP: END · MID · NEAR · PERP · PAR · EXT · INT · PROY X/Y · ORTO | líneas guía automáticas", Left = 12, Top = 26, Width = 790, ForeColor = Color.DimGray };
                lblSnap = new Label { Text = "", Left = 12, Top = 45, Width = 430, Height = 18, ForeColor = Color.DarkOrange };
                gPrev.Controls.Add(ay); gPrev.Controls.Add(lblSnap);
                CrearZoom(gPrev);

                preview = new PreviewPanel { Left = 12, Top = 66, Width = gPrev.Width - 24, Height = gPrev.Height - 78, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
                preview.Paint += DibujarPreview;
                preview.MouseWheel += MouseWheelPreview;
                preview.MouseDown += MouseDownPreview;
                preview.MouseMove += MouseMovePreview;
                preview.MouseUp += MouseUpPreview;
                preview.MouseEnter += delegate { preview.Focus(); };
                preview.DoubleClick += delegate { if (_modo == ModoDibujo.Ninguno) AjustarPreview(); };
                gPrev.Controls.Add(preview);
            }

            private void GuardarDataDialogo()
            {
                SincronizarUISinHistorial();

                bool top =
                    TopMost;

                TopMost =
                    false;

                try
                {
                    using (System.Windows.Forms.SaveFileDialog dlg =
                        new System.Windows.Forms.SaveFileDialog())
                    {
                        dlg.Title =
                            "Guardar data - MYG Acero en Losas";

                        dlg.Filter =
                            "MYG Acero en Losas (*.json)|*.json|Todos los archivos (*.*)|*.*";

                        dlg.DefaultExt =
                            "json";

                        dlg.AddExtension =
                            true;

                        dlg.FileName =
                            "MYG_AceroLosas.json";

                        if (dlg.ShowDialog(this) !=
                            System.Windows.Forms.DialogResult.OK)
                        {
                            return;
                        }

                        string mensaje;

                        bool ok =
                            _h.GuardarDataArchivo(
                                dlg.FileName,
                                out mensaje);

                        lblDir.Text =
                            mensaje;

                        if (!ok)
                        {
                            TaskDialog.Show(
                                "MYG - Acero en Losas",
                                mensaje);
                        }
                    }
                }
                finally
                {
                    TopMost =
                        top;
                }
            }

            private void CargarDataDialogo()
            {
                bool top =
                    TopMost;

                TopMost =
                    false;

                try
                {
                    using (System.Windows.Forms.OpenFileDialog dlg =
                        new System.Windows.Forms.OpenFileDialog())
                    {
                        dlg.Title =
                            "Cargar data - MYG Acero en Losas";

                        dlg.Filter =
                            "MYG Acero en Losas (*.json)|*.json|Todos los archivos (*.*)|*.*";

                        dlg.Multiselect =
                            false;

                        if (dlg.ShowDialog(this) !=
                            System.Windows.Forms.DialogResult.OK)
                        {
                            return;
                        }

                        string mensaje;

                        bool ok =
                            _h.CargarDataArchivo(
                                dlg.FileName,
                                out mensaje);

                        lblDir.Text =
                            mensaje;

                        if (!ok)
                        {
                            TaskDialog.Show(
                                "MYG - Acero en Losas",
                                mensaje);
                        }
                    }
                }
                finally
                {
                    TopMost =
                        top;
                }
            }

            internal void ActualizarBotonesHistorial()
            {
                if (btnUndo != null)
                    btnUndo.Enabled =
                        _h.PuedeDeshacer();

                if (btnRedo != null)
                    btnRedo.Enabled =
                        _h.PuedeRehacer();
            }

            internal void SincronizarUISinHistorial()
            {
                if (_cargando)
                    return;

                PanoData p =
                    _h.PanoActivo();

                if (p == null)
                    return;

                CopiarUIaPano(p);
            }

            internal void CancelarDibujoTemporalParaHistorial()
            {
                _puntosPoligono.Clear();
                _primerPunto = null;
                _snapActual = null;
                _snapNombre = "";
                _snapGuiaA = null;
                _snapGuiaB = null;
                _modo = ModoDibujo.Ninguno;

                if (preview != null)
                    preview.Cursor = Cursors.Default;

                ActualizarBotonModoHuecos();
            }

            private bool ConfiguracionUIDifiere(
                PanoData p)
            {
                if (p == null)
                    return false;

                double tol =
                    1e-9;

                if (p.CrearInfD1 != chkInfD1.Checked ||
                    p.CrearInfD2 != chkInfD2.Checked ||
                    p.CrearSupD1 != chkSupD1.Checked ||
                    p.CrearSupD2 != chkSupD2.Checked ||
                    p.AtravesarVigas != chkVigas.Checked ||
                    p.RespetarHuecos != chkHuecos.Checked ||
                    p.D2Auto != chkD2Auto.Checked)
                {
                    return true;
                }

                ElementId i1 =
                    IdCombo(cmbInfD1);

                ElementId i2 =
                    IdCombo(cmbInfD2);

                ElementId s1 =
                    IdCombo(cmbSupD1);

                ElementId s2 =
                    IdCombo(cmbSupD2);

                if (ValorId(i1) !=
                        ValorId(p.TipoInfD1Id) ||
                    ValorId(i2) !=
                        ValorId(p.TipoInfD2Id) ||
                    ValorId(s1) !=
                        ValorId(p.TipoSupD1Id) ||
                    ValorId(s2) !=
                        ValorId(p.TipoSupD2Id))
                {
                    return true;
                }

                if (Math.Abs(
                        p.EspInfD1Cm -
                        (double)nudInfD1.Value) >
                        tol ||
                    Math.Abs(
                        p.EspInfD2Cm -
                        (double)nudInfD2.Value) >
                        tol ||
                    Math.Abs(
                        p.EspSupD1Cm -
                        (double)nudSupD1.Value) >
                        tol ||
                    Math.Abs(
                        p.EspSupD2Cm -
                        (double)nudSupD2.Value) >
                        tol ||
                    Math.Abs(
                        p.RecInfCm -
                        (double)nudRecInf.Value) >
                        tol ||
                    Math.Abs(
                        p.RecSupCm -
                        (double)nudRecSup.Value) >
                        tol ||
                    Math.Abs(
                        p.RecLatCm -
                        (double)nudRecLat.Value) >
                        tol)
                {
                    return true;
                }

                return false;
            }

            private long ValorId(
                ElementId id)
            {
                return
                    id == null
                    ? -1
                    : id.Value;
            }

            private GroupBox Grupo(string text, int l, int t, int w, int h)
            {
                return new GroupBox { Text = text, Left = l, Top = t, Width = w, Height = h, BackColor = Color.White, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            }

            private Button Boton(string text, int l, int t, int w, int h, bool principal)
            {
                Button b = new Button { Text = text, Left = l, Top = t, Width = w, Height = h, FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand };
                if (principal) { b.BackColor = PRINCIPAL; b.ForeColor = Color.White; b.FlatAppearance.BorderSize = 0; b.Font = new Font("Segoe UI", 9F, FontStyle.Bold); }
                else { b.BackColor = Color.White; b.ForeColor = Color.FromArgb(50, 50, 50); b.FlatAppearance.BorderColor = Color.LightGray; }
                return b;
            }

            private void FilaAcero(Control p, int top, string text, out CheckBox chk, out ComboBox cmb, out NumericUpDown nud)
            {
                chk = new CheckBox { Text = text, Left = 14, Top = top + 4, Width = 108, Checked = true };
                cmb = new ComboBox { Left = 125, Top = top, Width = 165, DropDownStyle = ComboBoxStyle.DropDownList };
                Label lm = new Label { Text = "@ máx.", Left = 297, Top = top + 5, Width = 46 };
                nud = new NumericUpDown { Left = 344, Top = top, Width = 67, DecimalPlaces = 1, Minimum = 1, Maximum = 100, Increment = 0.5M, Value = 20 };
                Label cm = new Label { Text = "cm", Left = 414, Top = top + 5, Width = 28 };
                p.Controls.Add(chk); p.Controls.Add(cmb); p.Controls.Add(lm); p.Controls.Add(nud); p.Controls.Add(cm);
            }

            private void NumericEtiqueta(Control p, string text, int l, int top, out NumericUpDown nud, decimal val)
            {
                Label lab = new Label { Text = text, Left = l, Top = top, Width = 110 };
                nud = new NumericUpDown { Left = l, Top = top + 24, Width = 78, DecimalPlaces = 1, Minimum = 0.5M, Maximum = 20, Increment = 0.5M, Value = val };
                Label cm = new Label { Text = "cm", Left = l + 82, Top = top + 28, Width = 28 };
                p.Controls.Add(lab); p.Controls.Add(nud); p.Controls.Add(cm);
            }

            private void CrearZoom(GroupBox g)
            {
                Button menos = Boton("-", g.ClientSize.Width - 205, 22, 34, 28, false); menos.Anchor = AnchorStyles.Top | AnchorStyles.Right; menos.Click += delegate { ZoomCentro(1.0 / ZFACTOR); };
                lblZoom = new Label { Text = "100%", Width = 50, Height = 28, Top = 27, Left = g.ClientSize.Width - 166, Anchor = AnchorStyles.Top | AnchorStyles.Right, TextAlign = ContentAlignment.MiddleCenter };
                Button mas = Boton("+", g.ClientSize.Width - 112, 22, 34, 28, false); mas.Anchor = AnchorStyles.Top | AnchorStyles.Right; mas.Click += delegate { ZoomCentro(ZFACTOR); };
                Button aj = Boton("Ajustar", g.ClientSize.Width - 74, 22, 70, 28, false); aj.Anchor = AnchorStyles.Top | AnchorStyles.Right; aj.Click += delegate { AjustarPreview(); };
                g.Controls.Add(menos); g.Controls.Add(lblZoom); g.Controls.Add(mas); g.Controls.Add(aj);
            }

            private void CargarTipos()
            {
                foreach (ComboBox c in new[] { cmbInfD1, cmbInfD2, cmbSupD1, cmbSupD2 })
                {
                    c.Items.Clear(); foreach (RebarBarType t in _tipos) c.Items.Add(t); c.DisplayMember = "Name"; if (c.Items.Count > 0) c.SelectedIndex = 0;
                }
            }

            private void ConectarConfig()
            {
                foreach (CheckBox c in new[] { chkInfD1, chkInfD2, chkSupD1, chkSupD2, chkVigas, chkHuecos }) c.CheckedChanged += delegate { GuardarPanoActivo(); };
                foreach (ComboBox c in new[] { cmbInfD1, cmbInfD2, cmbSupD1, cmbSupD2 }) c.SelectedIndexChanged += delegate { GuardarPanoActivo(); };
                foreach (NumericUpDown n in new[] { nudInfD1, nudInfD2, nudSupD1, nudSupD2, nudRecInf, nudRecSup, nudRecLat }) n.ValueChanged += delegate { GuardarPanoActivo(); };
            }

            internal void InicializarNuevoPano(PanoData p)
            {
                if (p == null) return;
                CopiarUIaPano(p);
                p.D2Auto = chkD2Auto.Checked;
            }

            internal void GuardarPanoActivo()
            {
                if (_cargando) return;

                PanoData p =
                    _h.PanoActivo();

                if (p == null)
                    return;

                if (ConfiguracionUIDifiere(p))
                    _h.RegistrarUndo();

                CopiarUIaPano(p);

                ActualizarBotonesHistorial();
            }

            private void CopiarUIaPano(PanoData p)
            {
                p.CrearInfD1 = chkInfD1.Checked; p.CrearInfD2 = chkInfD2.Checked; p.CrearSupD1 = chkSupD1.Checked; p.CrearSupD2 = chkSupD2.Checked;
                p.TipoInfD1Id = IdCombo(cmbInfD1); p.TipoInfD2Id = IdCombo(cmbInfD2); p.TipoSupD1Id = IdCombo(cmbSupD1); p.TipoSupD2Id = IdCombo(cmbSupD2);
                p.EspInfD1Cm = (double)nudInfD1.Value; p.EspInfD2Cm = (double)nudInfD2.Value; p.EspSupD1Cm = (double)nudSupD1.Value; p.EspSupD2Cm = (double)nudSupD2.Value;
                p.RecInfCm = (double)nudRecInf.Value; p.RecSupCm = (double)nudRecSup.Value; p.RecLatCm = (double)nudRecLat.Value;
                p.AtravesarVigas = chkVigas.Checked; p.RespetarHuecos = chkHuecos.Checked; p.D2Auto = chkD2Auto.Checked;
            }

            internal void CargarPano(PanoData p)
            {
                if (p == null) { LimpiarPanoActivo(); return; }
                _cargando = true;
                try
                {
                    lblPano.Text = "Boceto definido · " + p.Rectangulo.Count + " vértices · " + p.HuecosManuales.Count + " huecos · " + p.Losas.Count + " losas anfitrión";
                    chkInfD1.Checked = p.CrearInfD1; chkInfD2.Checked = p.CrearInfD2; chkSupD1.Checked = p.CrearSupD1; chkSupD2.Checked = p.CrearSupD2;
                    Seleccionar(cmbInfD1, p.TipoInfD1Id); Seleccionar(cmbInfD2, p.TipoInfD2Id); Seleccionar(cmbSupD1, p.TipoSupD1Id); Seleccionar(cmbSupD2, p.TipoSupD2Id);
                    nudInfD1.Value = Num(p.EspInfD1Cm, nudInfD1); nudInfD2.Value = Num(p.EspInfD2Cm, nudInfD2); nudSupD1.Value = Num(p.EspSupD1Cm, nudSupD1); nudSupD2.Value = Num(p.EspSupD2Cm, nudSupD2);
                    nudRecInf.Value = Num(p.RecInfCm, nudRecInf); nudRecSup.Value = Num(p.RecSupCm, nudRecSup); nudRecLat.Value = Num(p.RecLatCm, nudRecLat);
                    chkVigas.Checked = p.AtravesarVigas; chkHuecos.Checked = p.RespetarHuecos; chkD2Auto.Checked = p.D2Auto;
                    Habilitar(true); EstadoDireccion(p);
                }
                finally { _cargando = false; }
                InvalidarPreview();
            }

            internal void LimpiarPanoActivo()
            {
                _cargando = true;
                try { lblPano.Text = "Boceto: no definido"; lblDir.Text = "Dibuje primero el boceto general cerrado."; Habilitar(false); }
                finally { _cargando = false; }
                InvalidarPreview();
            }

            private void Habilitar(bool b)
            {
                grpDir.Enabled = b; grpInf.Enabled = b; grpSup.Enabled = b; grpReglas.Enabled = b; btnEliminar.Enabled = b; btnCrearActivo.Enabled = b;
            }

            private ElementId IdCombo(ComboBox c) { RebarBarType t = c.SelectedItem as RebarBarType; return t == null ? ElementId.InvalidElementId : t.Id; }
            private decimal Num(double v, NumericUpDown n) { decimal d = (decimal)v; if (d < n.Minimum) d = n.Minimum; if (d > n.Maximum) d = n.Maximum; return d; }
            private void Seleccionar(ComboBox c, ElementId id)
            {
                if (c.Items.Count == 0) return;
                if (id != null && id != ElementId.InvalidElementId)
                    for (int i = 0; i < c.Items.Count; i++) { RebarBarType t = c.Items[i] as RebarBarType; if (t != null && t.Id.Value == id.Value) { c.SelectedIndex = i; return; } }
                c.SelectedIndex = 0;
            }

            internal void ActualizarUniverso(int n)
            {
                int apoyos = _h._previewSoportes.Count;
                lblUniverso.Text = n + (n == 1 ? " losa" : " losas") + " · " + apoyos + " apoyos limpios";
            }

            internal void RefrescarBotonesPanos()
            {
                PanoData p = _h.PanoActivo();

                if (p == null)
                {
                    lblPano.Text = "Boceto: no definido";
                    btnCrearActivo.Enabled = false;
                    return;
                }

                lblPano.Text =
                    "Boceto definido · " +
                    p.Rectangulo.Count +
                    " vértices · " +
                    p.HuecosManuales.Count +
                    (p.HuecosManuales.Count == 1
                        ? " hueco · "
                        : " huecos · ") +
                    p.Losas.Count +
                    " losas anfitrión";

                btnCrearActivo.Enabled = true;
            }

            // -----------------------------------------------------------------
            // BOCETO GENERAL / D1 / D2 + OSNAP COMPLETO
            // -----------------------------------------------------------------
            private void IniciarDibujo(ModoDibujo m)
            {
                if (_h._previewGeneral.Count == 0)
                {
                    TaskDialog.Show(
                        "MYG - Acero en Losas",
                        "Primero seleccione las losas disponibles.");

                    return;
                }

                if (m != ModoDibujo.PanoPol &&
                    _h.PanoActivo() == null)
                {
                    TaskDialog.Show(
                        "MYG - Acero en Losas",
                        "Primero dibuje el boceto general cerrado.");

                    return;
                }

                _modo = m;
                _primerPunto = null;
                _snapActual = null;
                _snapNombre = "";
                _snapGuiaA = null;
                _snapGuiaB = null;
                _puntosPoligono.Clear();
                preview.Cursor = Cursors.Cross;

                ActualizarBotonModoHuecos();

                if (m == ModoDibujo.PanoPol)
                {
                    lblDir.Text =
                        "BOCETO GENERAL: marque vértices sucesivos. Para cerrar, haga clic sobre el primer vértice. Clic derecho = deshacer último.";
                }
                else if (m == ModoDibujo.HuecoPol)
                {
                    lblDir.Text =
                        "HUECOS CONTINUOS: cierre cada hueco sobre su primer vértice y empiece inmediatamente el siguiente. Pulse 'Finalizar huecos' para salir. Clic derecho = deshacer último.";
                }
                else if (m == ModoDibujo.D1)
                {
                    lblDir.Text =
                        "D1: clic inicial y clic final. OSNAP incluye PERP y PAR.";
                }
                else
                {
                    lblDir.Text =
                        "D2: clic inicial y clic final. OSNAP incluye PERP y PAR.";
                }

                InvalidarPreview();
            }

            private void FinalizarModoHuecos()
            {
                if (_modo !=
                    ModoDibujo.HuecoPol)
                {
                    return;
                }

                // Si había un hueco incompleto, se descarta solamente ese
                // trazado temporal. Los huecos ya cerrados permanecen.
                _puntosPoligono.Clear();
                _primerPunto = null;
                _snapActual = null;
                _snapNombre = "";
                _snapGuiaA = null;
                _snapGuiaB = null;

                _modo =
                    ModoDibujo.Ninguno;

                preview.Cursor =
                    Cursors.Default;

                ActualizarBotonModoHuecos();

                PanoData p =
                    _h.PanoActivo();

                int n =
                    p == null
                    ? 0
                    : p.HuecosManuales.Count;

                lblDir.Text =
                    "Modo de huecos finalizado · " +
                    n +
                    (n == 1
                        ? " hueco definido."
                        : " huecos definidos.");

                InvalidarPreview();
            }

            private void ActualizarBotonModoHuecos()
            {
                if (btnDibujarHueco == null)
                    return;

                bool activo =
                    _modo ==
                    ModoDibujo.HuecoPol;

                if (activo)
                {
                    btnDibujarHueco.Text =
                        "Finalizar huecos";

                    btnDibujarHueco.BackColor =
                        Color.FromArgb(
                            208,
                            112,
                            30);

                    btnDibujarHueco.ForeColor =
                        Color.White;

                    btnDibujarHueco.FlatAppearance.BorderSize =
                        0;

                    btnDibujarHueco.Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold);
                }
                else
                {
                    btnDibujarHueco.Text =
                        "+ Dibujar hueco";

                    btnDibujarHueco.BackColor =
                        PRINCIPAL;

                    btnDibujarHueco.ForeColor =
                        Color.White;

                    btnDibujarHueco.FlatAppearance.BorderSize =
                        0;

                    btnDibujarHueco.Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold);
                }
            }

            private void ProcesarClick(Point screen)
            {
                XYZ q =
                    PuntoConSnap(
                        screen);

                if (q == null)
                    return;

                if (_modo ==
                        ModoDibujo.PanoPol ||
                    _modo ==
                        ModoDibujo.HuecoPol)
                {
                    ProcesarClickPoligonal(
                        q,
                        screen);

                    return;
                }

                if (_primerPunto == null)
                {
                    _primerPunto =
                        q;

                    lblDir.Text =
                        "Primer punto definido. Haga clic en el segundo.";

                    preview.Invalidate();
                    return;
                }

                if (_modo ==
                    ModoDibujo.PanoRect)
                {
                    PanoData creado =
                        _h.CrearPanoRectangular(
                            _primerPunto,
                            q);

                    _primerPunto = null;
                    _modo = ModoDibujo.Ninguno;
                    _snapActual = null;
                    preview.Cursor = Cursors.Default;
                    ActualizarBotonModoHuecos();

                    lblDir.Text =
                        creado == null
                        ? "No se pudo crear el paño rectangular: debe intersectar al menos una losa."
                        : creado.Nombre +
                          " creado. Ahora dibuje D1/D2.";

                    InvalidarPreview();
                    return;
                }

                PanoData p =
                    _h.PanoActivo();

                if (p == null)
                    return;

                XYZ d =
                    new XYZ(
                        q.X - _primerPunto.X,
                        q.Y - _primerPunto.Y,
                        0.0);

                if (d.GetLength() <
                    1e-6)
                {
                    _primerPunto = null;
                    return;
                }

                d =
                    d.Normalize();

                _h.RegistrarUndo();

                if (_modo ==
                    ModoDibujo.D1)
                {
                    p.D1 = d;
                    p.D1A = _primerPunto;
                    p.D1B = q;
                    p.D1Definida = true;

                    if (p.D2Auto)
                        GenerarD2(p);
                }
                else
                {
                    p.D2 = d;
                    p.D2A = _primerPunto;
                    p.D2B = q;
                    p.D2Definida = true;
                    p.D2Auto = false;

                    _cargando = true;
                    chkD2Auto.Checked = false;
                    _cargando = false;
                }

                _primerPunto = null;
                _modo = ModoDibujo.Ninguno;
                _snapActual = null;
                preview.Cursor = Cursors.Default;
                ActualizarBotonModoHuecos();

                EstadoDireccion(p);
                RefrescarBotonesPanos();
                preview.Invalidate();
            }

            private void ProcesarClickPoligonal(
                XYZ q,
                Point screen)
            {
                if (q == null)
                    return;

                bool dibujandoHueco =
                    _modo ==
                    ModoDibujo.HuecoPol;

                string nombreModo =
                    dibujandoHueco
                    ? "HUECO"
                    : "BOCETO GENERAL";

                if (_puntosPoligono.Count == 0)
                {
                    // Un hueco debe comenzar dentro del boundary exterior.
                    if (dibujandoHueco)
                    {
                        PanoData p0 =
                            _h.PanoActivo();

                        if (p0 == null ||
                            !_h.PuntoEnPoligonoXY(
                                q,
                                p0.Rectangulo))
                        {
                            lblDir.Text =
                                "HUECO: el primer vértice debe quedar dentro del boceto general.";

                            return;
                        }
                    }

                    _puntosPoligono.Add(q);
                    _primerPunto = q;

                    lblDir.Text =
                        nombreModo +
                        ": vértice 1. Continúe marcando y cierre sobre el primer vértice.";

                    preview.Invalidate();
                    return;
                }

                XYZ primero =
                    _puntosPoligono[0];

                bool cerrar =
                    _puntosPoligono.Count >= 3 &&
                    DistanciaPantalla(
                        q,
                        primero) <=
                    7.0;

                if (cerrar)
                {
                    if (!CierrePoligonalValido())
                    {
                        lblDir.Text =
                            nombreModo +
                            ": no se puede cerrar porque el último tramo cruza otro lado.";

                        return;
                    }

                    if (dibujandoHueco)
                    {
                        string mensaje;

                        bool ok =
                            _h.AgregarHuecoManual(
                                new List<XYZ>(
                                    _puntosPoligono),
                                out mensaje);

                        if (!ok)
                        {
                            lblDir.Text =
                                mensaje;

                            return;
                        }

                        // =================================================
                        // MODO HUECOS CONSECUTIVOS
                        // =================================================
                        // Al cerrar un hueco NO abandonamos HuecoPol.
                        // Limpiamos únicamente los puntos del hueco recién
                        // terminado y quedamos esperando el primer vértice
                        // del siguiente.
                        //
                        // El usuario sale del modo solamente cuando vuelve
                        // a pulsar el botón "Finalizar huecos".
                        // =================================================
                        _puntosPoligono.Clear();
                        _primerPunto = null;
                        _snapActual = null;
                        _snapNombre = "";

                        _modo =
                            ModoDibujo.HuecoPol;

                        preview.Cursor =
                            Cursors.Cross;

                        ActualizarBotonModoHuecos();

                        PanoData pHuecos =
                            _h.PanoActivo();

                        int totalHuecos =
                            pHuecos == null
                            ? 0
                            : pHuecos.HuecosManuales.Count;

                        lblDir.Text =
                            mensaje +
                            " · Total: " +
                            totalHuecos +
                            (totalHuecos == 1
                                ? " hueco. "
                                : " huecos. ") +
                            "Continúe marcando el siguiente hueco o pulse 'Finalizar huecos'.";

                        RefrescarBotonesPanos();
                        InvalidarPreview();
                        return;
                    }

                    PanoData creado =
                        _h.CrearPanoPoligonal(
                            new List<XYZ>(
                                _puntosPoligono));

                    if (creado == null)
                    {
                        lblDir.Text =
                            "No se pudo cerrar el boceto general. Revise cruces, área o intersección con las losas seleccionadas.";

                        return;
                    }

                    _puntosPoligono.Clear();
                    _primerPunto = null;
                    _snapActual = null;
                    _modo = ModoDibujo.Ninguno;
                    preview.Cursor = Cursors.Default;
                    ActualizarBotonModoHuecos();

                    lblDir.Text =
                        "Boceto general cerrado. Ahora puede dibujar huecos o redibujar D1/D2.";

                    InvalidarPreview();
                    return;
                }

                XYZ ultimo =
                    _puntosPoligono[
                        _puntosPoligono.Count - 1];

                if (DistanciaPantalla(
                        q,
                        ultimo) <=
                    3.0)
                {
                    return;
                }

                if (!NuevoTramoPoligonalValido(
                        ultimo,
                        q))
                {
                    lblDir.Text =
                        nombreModo +
                        ": ese tramo cruza otro lado del polígono. Elija otro vértice.";

                    return;
                }

                // Mientras se dibuja un hueco no permitimos salir del
                // boundary exterior ni siquiera de manera temporal.
                if (dibujandoHueco)
                {
                    PanoData p =
                        _h.PanoActivo();

                    if (p == null ||
                        !_h.PuntoEnPoligonoXY(
                            q,
                            p.Rectangulo))
                    {
                        lblDir.Text =
                            "HUECO: todos los vértices deben quedar dentro del boceto general.";

                        return;
                    }
                }

                _puntosPoligono.Add(q);

                // Para PERP/PAR el punto base siempre es el último vértice.
                _primerPunto = q;

                lblDir.Text =
                    nombreModo +
                    ": " +
                    _puntosPoligono.Count +
                    " vértices. Cierre haciendo clic sobre el primer vértice.";

                preview.Invalidate();
            }

            private bool NuevoTramoPoligonalValido(
                XYZ a,
                XYZ b)
            {
                if (a == null ||
                    b == null)
                {
                    return false;
                }

                if (_puntosPoligono.Count < 2)
                    return true;

                // Segmentos existentes: [0-1], [1-2], ...
                // El nuevo segmento comparte el último vértice con el último
                // tramo existente, por eso ese último tramo se ignora.
                for (int i = 0;
                    i <
                    _puntosPoligono.Count - 2;
                    i++)
                {
                    XYZ s0 =
                        _puntosPoligono[i];

                    XYZ s1 =
                        _puntosPoligono[i + 1];

                    if (_h.SegmentosIntersectanXY(
                            a,
                            b,
                            s0,
                            s1))
                    {
                        return false;
                    }
                }

                return true;
            }

            private bool CierrePoligonalValido()
            {
                if (_puntosPoligono.Count < 3)
                    return false;

                XYZ a =
                    _puntosPoligono[
                        _puntosPoligono.Count - 1];

                XYZ b =
                    _puntosPoligono[0];

                // Ignoramos el primer segmento (comparte b) y el último
                // existente (comparte a).
                for (int i = 1;
                    i <
                    _puntosPoligono.Count - 2;
                    i++)
                {
                    if (_h.SegmentosIntersectanXY(
                            a,
                            b,
                            _puntosPoligono[i],
                            _puntosPoligono[i + 1]))
                    {
                        return false;
                    }
                }

                return true;
            }

            private void DeshacerUltimoVerticePoligonal()
            {
                if (_modo !=
                        ModoDibujo.PanoPol &&
                    _modo !=
                        ModoDibujo.HuecoPol)
                {
                    return;
                }

                if (_puntosPoligono.Count > 0)
                {
                    _puntosPoligono.RemoveAt(
                        _puntosPoligono.Count - 1);
                }

                _primerPunto =
                    _puntosPoligono.Count > 0
                    ? _puntosPoligono[
                        _puntosPoligono.Count - 1]
                    : null;

                _snapActual = null;

                string nombreModo =
                    _modo == ModoDibujo.HuecoPol
                    ? "HUECO"
                    : "BOCETO GENERAL";

                lblDir.Text =
                    _puntosPoligono.Count == 0
                    ? nombreModo + ": marque el primer vértice."
                    : nombreModo + ": " +
                      _puntosPoligono.Count +
                      " vértices. Clic derecho vuelve a quitar el último.";

                preview.Invalidate();
            }

            private void GenerarD2(PanoData p)
            {
                if (p == null ||
                    !p.D1Definida ||
                    p.D1 == null)
                {
                    return;
                }

                XYZ d =
                    new XYZ(
                        -p.D1.Y,
                        p.D1.X,
                        0.0);

                if (d.GetLength() <
                    1e-9)
                {
                    return;
                }

                p.D2 =
                    d.Normalize();

                XYZ c =
                    p.CentroRect ??
                    CentroPano(p);

                double L =
                    Math.Max(
                        1.0,
                        TamanoPano(p) *
                        0.75);

                p.D2A =
                    c -
                    p.D2 *
                    L /
                    2.0;

                p.D2B =
                    c +
                    p.D2 *
                    L /
                    2.0;

                p.D2Definida = true;
                p.D2Auto = true;

                EstadoDireccion(p);
                RefrescarBotonesPanos();
                InvalidarPreview();
            }

            private void Intercambiar()
            {
                PanoData p =
                    _h.PanoActivo();

                if (p == null ||
                    !p.D1Definida ||
                    !p.D2Definida)
                {
                    return;
                }

                _h.RegistrarUndo();

                XYZ d = p.D1;
                p.D1 = p.D2;
                p.D2 = d;

                XYZ a = p.D1A;
                XYZ b = p.D1B;

                p.D1A = p.D2A;
                p.D1B = p.D2B;
                p.D2A = a;
                p.D2B = b;

                p.D2Auto = false;
                _cargando = true;
                chkD2Auto.Checked = false;
                _cargando = false;

                EstadoDireccion(p);
                InvalidarPreview();
            }

            private void Sugerir()
            {
                PanoData p =
                    _h.PanoActivo();

                if (p == null ||
                    p.Rectangulo.Count < 3)
                {
                    return;
                }

                _h.RegistrarUndo();

                Box2 box =
                    _h.BoundingPano(p);

                double dx =
                    box.MaxX -
                    box.MinX;

                double dy =
                    box.MaxY -
                    box.MinY;

                p.D1 =
                    dx >= dy
                    ? XYZ.BasisX
                    : XYZ.BasisY;

                XYZ c =
                    p.CentroRect ??
                    CentroPano(p);

                double L =
                    Math.Max(
                        1.0,
                        Math.Max(
                            dx,
                            dy) *
                        0.80);

                p.D1A =
                    c -
                    p.D1 *
                    L /
                    2.0;

                p.D1B =
                    c +
                    p.D1 *
                    L /
                    2.0;

                p.D1Definida = true;

                if (p.D2Auto)
                    GenerarD2(p);

                EstadoDireccion(p);
                RefrescarBotonesPanos();
                InvalidarPreview();
            }

            private void EstadoDireccion(PanoData p)
            {
                if (p == null)
                {
                    lblDir.Text =
                        "Dibuje el boceto general.";

                    return;
                }

                lblDir.Text =
                    (p.D1Definida
                        ? "D1 ✓"
                        : "D1 pendiente") +
                    "   ·   " +
                    (p.D2Definida
                        ? "D2 ✓"
                        : "D2 pendiente") +
                    "\nOSNAP " +
                    (chkOsnap.Checked
                        ? "END / MID / NEAR / PERP / PAR / EXT / INT / PROY / ORTO"
                        : "apagado") +
                    " · la línea fija dirección y fase.";
            }

            // =============================================================
            // OSNAP
            // =============================================================
            private XYZ PuntoConSnap(Point screen)
            {
                XYZ raw =
                    PantallaAModelo(
                        screen);

                if (raw == null)
                    return null;

                _snapActual =
                    raw;

                _snapNombre =
                    "";

                _snapGuiaA =
                    null;

                _snapGuiaB =
                    null;

                if (!chkOsnap.Checked)
                {
                    if (lblSnap != null)
                        lblSnap.Text = "";

                    return raw;
                }

                SnapEvaluacion mejor =
                    new SnapEvaluacion();

                mejor.Punto = raw;
                mejor.Nombre = "";
                mejor.Prioridad = 999;
                mejor.DistanciaPix = double.MaxValue;
                mejor.GuiaA = null;
                mejor.GuiaB = null;

                // ---------------------------------------------------------
                // CIERRE DEL POLIGONO TEMPORAL: prioridad absoluta.
                // ---------------------------------------------------------
                if ((_modo ==
                         ModoDibujo.PanoPol ||
                     _modo ==
                         ModoDibujo.HuecoPol) &&
                    _puntosPoligono.Count >= 3)
                {
                    EvaluarCandidatoSnap(
                        _puntosPoligono[0],
                        "CERRAR",
                        0,
                        16.0,
                        screen,
                        mejor);
                }

                // ---------------------------------------------------------
                // Floors + huecos reales.
                // ---------------------------------------------------------
                foreach (PreviewLosa pv
                    in _h._previewGeneral)
                {
                    if (pv == null)
                        continue;

                    EvaluarLoopSnap(
                        pv.Exterior,
                        "FLOOR - ",
                        raw,
                        screen,
                        mejor);

                    foreach (List<XYZ> h
                        in pv.Huecos)
                    {
                        EvaluarLoopSnap(
                            h,
                            "HUECO FLOOR - ",
                            raw,
                            screen,
                            mejor);
                    }
                }

                // ---------------------------------------------------------
                // Vigas / pilares / muros detectados.
                // ---------------------------------------------------------
                foreach (PreviewSoporte s
                    in _h._previewSoportes)
                {
                    if (s == null ||
                        s.Exterior == null ||
                        s.Exterior.Count < 2)
                    {
                        continue;
                    }

                    string prefijo =
                        string.IsNullOrEmpty(
                            s.Tipo)
                        ? "APOYO - "
                        : s.Tipo + " - ";

                    EvaluarLoopSnap(
                        s.Exterior,
                        prefijo,
                        raw,
                        screen,
                        mejor);
                }

                // ---------------------------------------------------------
                // Boceto general + huecos manuales + D1/D2.
                // ---------------------------------------------------------
                PanoData pBoceto =
                    _h.PanoActivo();

                if (pBoceto != null)
                {
                    EvaluarLoopSnap(
                        pBoceto.Rectangulo,
                        "BOCETO - ",
                        raw,
                        screen,
                        mejor);

                    foreach (List<XYZ> hm
                        in pBoceto.HuecosManuales)
                    {
                        if (hm == null ||
                            hm.Count < 2)
                        {
                            continue;
                        }

                        EvaluarLoopSnap(
                            hm,
                            "HUECO - ",
                            raw,
                            screen,
                            mejor);
                    }

                    if (pBoceto.CentroRect != null)
                    {
                        EvaluarCandidatoSnap(
                            pBoceto.CentroRect,
                            "CENTER",
                            2,
                            11.0,
                            screen,
                            mejor);

                        EvaluarProyeccionAlineada(
                            pBoceto.CentroRect,
                            "CENTER",
                            raw,
                            screen,
                            mejor);
                    }

                    if (pBoceto.D1A != null &&
                        pBoceto.D1B != null)
                    {
                        EvaluarSegmentoSnap(
                            pBoceto.D1A,
                            pBoceto.D1B,
                            "D1 - ",
                            raw,
                            screen,
                            mejor);
                    }

                    if (pBoceto.D2A != null &&
                        pBoceto.D2B != null)
                    {
                        EvaluarSegmentoSnap(
                            pBoceto.D2A,
                            pBoceto.D2B,
                            "D2 - ",
                            raw,
                            screen,
                            mejor);
                    }
                }

                // ---------------------------------------------------------
                // Polígono temporal: vértices y lados ya dibujados.
                // ---------------------------------------------------------
                if ((_modo ==
                         ModoDibujo.PanoPol ||
                     _modo ==
                         ModoDibujo.HuecoPol) &&
                    _puntosPoligono.Count > 0)
                {
                    for (int i = 0;
                        i <
                        _puntosPoligono.Count;
                        i++)
                    {
                        string nombre =
                            i == 0 &&
                            _puntosPoligono.Count >= 3
                            ? "CERRAR"
                            : "POL - END";

                        EvaluarCandidatoSnap(
                            _puntosPoligono[i],
                            nombre,
                            i == 0 &&
                            _puntosPoligono.Count >= 3
                            ? 0
                            : 1,
                            14.0,
                            screen,
                            mejor);

                        EvaluarProyeccionAlineada(
                            _puntosPoligono[i],
                            "POL END",
                            raw,
                            screen,
                            mejor);
                    }

                    for (int i = 0;
                        i <
                        _puntosPoligono.Count - 1;
                        i++)
                    {
                        EvaluarSegmentoSnap(
                            _puntosPoligono[i],
                            _puntosPoligono[i + 1],
                            "POL - ",
                            raw,
                            screen,
                            mejor);
                    }
                }

                // ---------------------------------------------------------
                // ORTO:
                // inferencia de menor prioridad que snaps geométricos.
                // ---------------------------------------------------------
                if (_primerPunto != null)
                {
                    XYZ orto =
                        AplicarOrto(
                            raw,
                            screen);

                    if (orto != null &&
                        DistanciaPantalla(
                            orto,
                            raw) >
                        0.1)
                    {
                        EvaluarCandidatoSnap(
                            orto,
                            "ORTO",
                            7,
                            10.0,
                            screen,
                            mejor,
                            _primerPunto,
                            orto);
                    }
                }

                if (mejor.Prioridad <
                    999)
                {
                    _snapActual =
                        mejor.Punto;

                    _snapNombre =
                        mejor.Nombre;

                    _snapGuiaA =
                        mejor.GuiaA;

                    _snapGuiaB =
                        mejor.GuiaB;
                }
                else
                {
                    _snapActual =
                        raw;

                    _snapNombre =
                        "";

                    _snapGuiaA =
                        null;

                    _snapGuiaB =
                        null;
                }

                if (lblSnap != null)
                {
                    lblSnap.Text =
                        string.IsNullOrEmpty(
                            _snapNombre)
                        ? ""
                        : "OSNAP: " +
                          _snapNombre;
                }

                return _snapActual;
            }

            private void EvaluarLoopSnap(
                List<XYZ> loop,
                string prefijo,
                XYZ raw,
                Point screen,
                SnapEvaluacion mejor)
            {
                if (loop == null ||
                    loop.Count < 2)
                {
                    return;
                }

                for (int i = 0;
                    i < loop.Count;
                    i++)
                {
                    XYZ a =
                        loop[i];

                    XYZ b =
                        loop[
                            (i + 1) %
                            loop.Count];

                    EvaluarSegmentoSnap(
                        a,
                        b,
                        prefijo,
                        raw,
                        screen,
                        mejor);
                }
            }

            private void EvaluarSegmentoSnap(
                XYZ a,
                XYZ b,
                string prefijo,
                XYZ raw,
                Point screen,
                SnapEvaluacion mejor)
            {
                if (a == null ||
                    b == null ||
                    raw == null)
                {
                    return;
                }

                // =========================================================
                // ENDPOINT
                // =========================================================
                EvaluarCandidatoSnap(
                    a,
                    prefijo +
                    "END",
                    1,
                    13.0,
                    screen,
                    mejor);

                EvaluarCandidatoSnap(
                    b,
                    prefijo +
                    "END",
                    1,
                    13.0,
                    screen,
                    mejor);

                // Alineación proyectada X/Y desde endpoints.
                EvaluarProyeccionAlineada(
                    a,
                    prefijo + "END",
                    raw,
                    screen,
                    mejor);

                EvaluarProyeccionAlineada(
                    b,
                    prefijo + "END",
                    raw,
                    screen,
                    mejor);

                // =========================================================
                // MIDPOINT
                // =========================================================
                XYZ mid =
                    new XYZ(
                        (a.X + b.X) /
                        2.0,
                        (a.Y + b.Y) /
                        2.0,
                        0.0);

                EvaluarCandidatoSnap(
                    mid,
                    prefijo +
                    "MID",
                    2,
                    12.0,
                    screen,
                    mejor);

                EvaluarProyeccionAlineada(
                    mid,
                    prefijo + "MID",
                    raw,
                    screen,
                    mejor);

                // =========================================================
                // INTERSECTION / PERP / PAR
                // La base es siempre el último punto confirmado.
                // =========================================================
                if (_primerPunto != null)
                {
                    // INT:
                    // intersección entre el segmento/rayo que se está
                    // dibujando y el segmento de referencia.
                    XYZ inter =
                        InterseccionRayoActualConSegmento(
                            _primerPunto,
                            raw,
                            a,
                            b);

                    if (inter != null)
                    {
                        EvaluarCandidatoSnap(
                            inter,
                            prefijo +
                            "INT",
                            2,
                            12.0,
                            screen,
                            mejor,
                            _primerPunto,
                            inter);
                    }

                    // PERP:
                    // pie perpendicular REAL desde el último punto al
                    // segmento de referencia.
                    XYZ perp =
                        PiePerpendicularSegmentoXY(
                            _primerPunto,
                            a,
                            b);

                    if (perp != null)
                    {
                        EvaluarCandidatoSnap(
                            perp,
                            prefijo +
                            "PERP",
                            3,
                            13.0,
                            screen,
                            mejor,
                            _primerPunto,
                            perp);
                    }

                    // PAR:
                    // línea infinita por el último punto, paralela a la
                    // referencia. Funciona como inferencia de Revit.
                    XYZ paralelo =
                        PuntoParaleloDesdeBase(
                            _primerPunto,
                            raw,
                            a,
                            b);

                    if (paralelo != null)
                    {
                        EvaluarCandidatoSnap(
                            paralelo,
                            prefijo +
                            "PAR",
                            4,
                            10.0,
                            screen,
                            mejor,
                            _primerPunto,
                            paralelo);
                    }
                }

                // =========================================================
                // NEAR:
                // proyección ortogonal del cursor al segmento REAL.
                // =========================================================
                XYZ near =
                    ProyeccionSegmentoXY(
                        raw,
                        a,
                        b);

                EvaluarCandidatoSnap(
                    near,
                    prefijo +
                    "NEAR",
                    4,
                    10.0,
                    screen,
                    mejor);

                // =========================================================
                // EXTENSION / PROJECTION:
                // proyección del cursor sobre la LÍNEA INFINITA de la
                // referencia. Se usa solo si el pie cae fuera del segmento.
                //
                // Esto reproduce el comportamiento intuitivo que se busca:
                // pasar el cursor por una línea y poder continuar/proyectar
                // su alineación aunque el punto esté más allá del extremo.
                // =========================================================
                double parametroExtension;

                XYZ ext =
                    ProyeccionLineaInfinitaXY(
                        raw,
                        a,
                        b,
                        out parametroExtension);

                if (ext != null &&
                    (
                        parametroExtension <
                            -0.001 ||
                        parametroExtension >
                            1.001
                    ))
                {
                    EvaluarCandidatoSnap(
                        ext,
                        prefijo +
                        "EXT",
                        5,
                        10.0,
                        screen,
                        mejor,
                        a,
                        ext);
                }
            }

            private void EvaluarProyeccionAlineada(
                XYZ referencia,
                string nombreReferencia,
                XYZ raw,
                Point screen,
                SnapEvaluacion mejor)
            {
                if (referencia == null ||
                    raw == null ||
                    mejor == null)
                {
                    return;
                }

                PointF refScreen =
                    ModeloAPantalla(
                        referencia);

                // PROY-X:
                // misma coordenada X del punto de referencia.
                if (Math.Abs(
                        refScreen.X -
                        screen.X) <=
                    7.0)
                {
                    XYZ px =
                        new XYZ(
                            referencia.X,
                            raw.Y,
                            0.0);

                    EvaluarCandidatoSnap(
                        px,
                        nombreReferencia +
                        " PROY-X",
                        6,
                        8.0,
                        screen,
                        mejor,
                        referencia,
                        px);
                }

                // PROY-Y:
                // misma coordenada Y del punto de referencia.
                if (Math.Abs(
                        refScreen.Y -
                        screen.Y) <=
                    7.0)
                {
                    XYZ py =
                        new XYZ(
                            raw.X,
                            referencia.Y,
                            0.0);

                    EvaluarCandidatoSnap(
                        py,
                        nombreReferencia +
                        " PROY-Y",
                        6,
                        8.0,
                        screen,
                        mejor,
                        referencia,
                        py);
                }
            }

            private void EvaluarCandidatoSnap(
                XYZ candidato,
                string tipo,
                int prioridad,
                double umbralPix,
                Point screen,
                SnapEvaluacion mejor,
                XYZ guiaA = null,
                XYZ guiaB = null)
            {
                if (candidato == null ||
                    mejor == null)
                {
                    return;
                }

                PointF s =
                    ModeloAPantalla(
                        candidato);

                double dx =
                    s.X -
                    screen.X;

                double dy =
                    s.Y -
                    screen.Y;

                double d =
                    Math.Sqrt(
                        dx * dx +
                        dy * dy);

                if (d > umbralPix)
                    return;

                bool gana =
                    prioridad <
                        mejor.Prioridad
                    ||
                    (prioridad ==
                         mejor.Prioridad &&
                     d <
                         mejor.DistanciaPix);

                if (!gana)
                    return;

                mejor.Punto =
                    candidato;

                mejor.Nombre =
                    tipo;

                mejor.Prioridad =
                    prioridad;

                mejor.DistanciaPix =
                    d;

                mejor.GuiaA =
                    guiaA;

                mejor.GuiaB =
                    guiaB;
            }

            private XYZ ProyeccionLineaInfinitaXY(
                XYZ p,
                XYZ a,
                XYZ b,
                out double parametro)
            {
                parametro =
                    0.0;

                if (p == null ||
                    a == null ||
                    b == null)
                {
                    return null;
                }

                double vx =
                    b.X -
                    a.X;

                double vy =
                    b.Y -
                    a.Y;

                double den =
                    vx * vx +
                    vy * vy;

                if (den <
                    1e-20)
                {
                    return null;
                }

                parametro =
                    (
                        (p.X - a.X) *
                        vx +
                        (p.Y - a.Y) *
                        vy
                    ) /
                    den;

                return
                    new XYZ(
                        a.X +
                        parametro *
                        vx,
                        a.Y +
                        parametro *
                        vy,
                        0.0);
            }

            private XYZ InterseccionRayoActualConSegmento(
                XYZ baseP,
                XYZ raw,
                XYZ a,
                XYZ b)
            {
                if (baseP == null ||
                    raw == null ||
                    a == null ||
                    b == null)
                {
                    return null;
                }

                double rx =
                    raw.X -
                    baseP.X;

                double ry =
                    raw.Y -
                    baseP.Y;

                double sx =
                    b.X -
                    a.X;

                double sy =
                    b.Y -
                    a.Y;

                double rLen2 =
                    rx * rx +
                    ry * ry;

                if (rLen2 <
                    1e-20)
                {
                    return null;
                }

                double den =
                    rx * sy -
                    ry * sx;

                if (Math.Abs(den) <
                    1e-12)
                {
                    return null;
                }

                double qpx =
                    a.X -
                    baseP.X;

                double qpy =
                    a.Y -
                    baseP.Y;

                double t =
                    (
                        qpx *
                        sy -
                        qpy *
                        sx
                    ) /
                    den;

                double u =
                    (
                        qpx *
                        ry -
                        qpy *
                        rx
                    ) /
                    den;

                // El segmento de referencia debe contener la intersección.
                if (u <
                        -1e-6 ||
                    u >
                        1.0 +
                        1e-6)
                {
                    return null;
                }

                // El punto debe estar por delante del último punto dibujado.
                if (t <
                    -1e-6)
                {
                    return null;
                }

                return
                    new XYZ(
                        baseP.X +
                        t *
                        rx,
                        baseP.Y +
                        t *
                        ry,
                        0.0);
            }

            private XYZ PiePerpendicularSegmentoXY(
                XYZ baseP,
                XYZ a,
                XYZ b)
            {
                if (baseP == null ||
                    a == null ||
                    b == null)
                {
                    return null;
                }

                double vx =
                    b.X -
                    a.X;

                double vy =
                    b.Y -
                    a.Y;

                double den =
                    vx * vx +
                    vy * vy;

                if (den <
                    1e-20)
                {
                    return null;
                }

                double u =
                    ((baseP.X - a.X) * vx +
                     (baseP.Y - a.Y) * vy) /
                    den;

                // PERP solo si el pie cae realmente sobre el segmento.
                if (u < 0.0 ||
                    u > 1.0)
                {
                    return null;
                }

                return
                    new XYZ(
                        a.X +
                        u * vx,
                        a.Y +
                        u * vy,
                        0.0);
            }

            private XYZ PuntoParaleloDesdeBase(
                XYZ baseP,
                XYZ raw,
                XYZ a,
                XYZ b)
            {
                if (baseP == null ||
                    raw == null ||
                    a == null ||
                    b == null)
                {
                    return null;
                }

                XYZ dir =
                    new XYZ(
                        b.X - a.X,
                        b.Y - a.Y,
                        0.0);

                if (dir.GetLength() <
                    1e-9)
                {
                    return null;
                }

                dir =
                    dir.Normalize();

                XYZ v =
                    raw -
                    baseP;

                double t =
                    v.DotProduct(
                        dir);

                return
                    baseP +
                    dir *
                    t;
            }

            private XYZ ProyeccionSegmentoXY(
                XYZ p,
                XYZ a,
                XYZ b)
            {
                double vx =
                    b.X -
                    a.X;

                double vy =
                    b.Y -
                    a.Y;

                double den =
                    vx * vx +
                    vy * vy;

                if (den <
                    1e-20)
                {
                    return a;
                }

                double u =
                    ((p.X - a.X) * vx +
                     (p.Y - a.Y) * vy) /
                    den;

                u =
                    Math.Max(
                        0.0,
                        Math.Min(
                            1.0,
                            u));

                return
                    new XYZ(
                        a.X +
                        u * vx,
                        a.Y +
                        u * vy,
                        0.0);
            }

            private XYZ AplicarOrto(
                XYZ q,
                Point screen)
            {
                if (_primerPunto == null ||
                    q == null)
                {
                    return q;
                }

                PointF a =
                    ModeloAPantalla(
                        _primerPunto);

                PointF b =
                    ModeloAPantalla(q);

                if (Math.Abs(
                        b.X - a.X) <=
                    9.0)
                {
                    return
                        new XYZ(
                            _primerPunto.X,
                            q.Y,
                            0.0);
                }

                if (Math.Abs(
                        b.Y - a.Y) <=
                    9.0)
                {
                    return
                        new XYZ(
                            q.X,
                            _primerPunto.Y,
                            0.0);
                }

                return q;
            }

            private double DistanciaPantalla(
                XYZ a,
                XYZ b)
            {
                if (a == null ||
                    b == null)
                {
                    return double.MaxValue;
                }

                PointF pa =
                    ModeloAPantalla(a);

                PointF pb =
                    ModeloAPantalla(b);

                double dx =
                    pa.X -
                    pb.X;

                double dy =
                    pa.Y -
                    pb.Y;

                return
                    Math.Sqrt(
                        dx * dx +
                        dy * dy);
            }

            // -----------------------------------------------------------------
            // PREVIEW
            // -----------------------------------------------------------------
            internal void InvalidarPreview() { if (preview != null) preview.Invalidate(); }
            internal void AjustarPreview() { _zoom = 1.0; _pan = new PointF(0, 0); ActualizarZoom(); InvalidarPreview(); }

            private void DibujarPreview(object sender, PaintEventArgs e)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias; e.Graphics.Clear(Color.White);
                if (_h._previewGeneral.Count == 0) { _transformValida = false; Mensaje(e.Graphics, "Seleccione las losas disponibles."); return; }

                Box2 box = BoundingGeneral();
                double w = Math.Max(0.01, box.MaxX - box.MinX), h = Math.Max(0.01, box.MaxY - box.MinY), margen = 38;
                _escalaBase = Math.Min(Math.Max(10, preview.ClientSize.Width - 2 * margen) / w, Math.Max(10, preview.ClientSize.Height - 2 * margen) / h);
                _cxm = (box.MinX + box.MaxX) / 2.0; _cym = (box.MinY + box.MaxY) / 2.0; _transformValida = true;

                foreach (PreviewLosa pv in _h._previewGeneral)
                    FloorPreview(e.Graphics, pv, ModeloAPantalla, Color.FromArgb(247, 248, 250), Color.Silver, false);

                foreach (PreviewSoporte s in _h._previewSoportes)
                    SoportePreview(e.Graphics, s);

                PanoData activo = _h.PanoActivo();
                if (activo != null)
                {
                    RectanguloPreview(e.Graphics, activo, PRINCIPAL, true);

                    // Mostrar gráficamente la zona útil después del Offset.
                    OffsetBocetoPreview(
                        e.Graphics,
                        activo);

                    // Huecos manuales del boceto general.
                    for (int ih = 0;
                        ih < activo.HuecosManuales.Count;
                        ih++)
                    {
                        HuecoManualPreview(
                            e.Graphics,
                            activo.HuecosManuales[ih],
                            ih + 1);
                    }

                    NombrePanoPreview(e.Graphics, activo, ModeloAPantalla, PRINCIPAL);
                    if (activo.D1Definida) LineaPreview(e.Graphics, ModeloAPantalla, activo.D1A, activo.D1B, "D1", Color.FromArgb(20, 75, 185));
                    if (activo.D2Definida) LineaPreview(e.Graphics, ModeloAPantalla, activo.D2A, activo.D2B, "D2", Color.FromArgb(205, 45, 80));
                }

                if ((_modo == ModoDibujo.PanoPol ||
                     _modo == ModoDibujo.HuecoPol) &&
                    _puntosPoligono.Count > 0)
                {
                    Color colorTemporal =
                        _modo == ModoDibujo.HuecoPol
                        ? Color.Crimson
                        : Color.DarkOrange;

                    XYZ q2 =
                        _snapActual ??
                        _mouseModelo;

                    List<PointF> pts =
                        _puntosPoligono
                        .Select(ModeloAPantalla)
                        .ToList();

                    using (Pen pn =
                        new Pen(
                            colorTemporal,
                            2F))
                    {
                        pn.DashStyle =
                            DashStyle.Dash;

                        if (pts.Count >= 2)
                        {
                            e.Graphics.DrawLines(
                                pn,
                                pts.ToArray());
                        }

                        if (q2 != null)
                        {
                            PointF ultimo =
                                pts[
                                    pts.Count - 1];

                            PointF actual =
                                ModeloAPantalla(q2);

                            e.Graphics.DrawLine(
                                pn,
                                ultimo,
                                actual);
                        }

                        if (pts.Count >= 3)
                        {
                            PointF primero =
                                pts[0];

                            using (Pen cierre =
                                new Pen(
                                    Color.FromArgb(
                                        140,
                                        colorTemporal),
                                    1F))
                            {
                                cierre.DashStyle =
                                    DashStyle.Dot;

                                e.Graphics.DrawLine(
                                    cierre,
                                    pts[
                                        pts.Count - 1],
                                    primero);
                            }
                        }
                    }

                    foreach (PointF ptmp
                        in pts)
                    {
                        using (Brush br =
                            new SolidBrush(
                                colorTemporal))
                        {
                            e.Graphics.FillRectangle(
                                br,
                                ptmp.X - 3F,
                                ptmp.Y - 3F,
                                6F,
                                6F);
                        }
                    }
                }
                else if (_primerPunto != null &&
                         _mouseModelo != null)
                {
                    XYZ q2 =
                        _snapActual ??
                        _mouseModelo;

                    PointF a =
                        ModeloAPantalla(
                            _primerPunto);

                    PointF b =
                        ModeloAPantalla(q2);

                    using (Pen pn =
                        new Pen(
                            Color.DarkOrange,
                            2F))
                    {
                        pn.DashStyle =
                            DashStyle.Dash;

                        if (_modo ==
                            ModoDibujo.PanoRect)
                        {
                            RectangleF rr =
                                new RectangleF(
                                    Math.Min(a.X, b.X),
                                    Math.Min(a.Y, b.Y),
                                    Math.Abs(b.X - a.X),
                                    Math.Abs(b.Y - a.Y));

                            using (Brush br =
                                new SolidBrush(
                                    Color.FromArgb(
                                        25,
                                        Color.DarkOrange)))
                            {
                                e.Graphics.FillRectangle(
                                    br,
                                    rr);
                            }

                            e.Graphics.DrawRectangle(
                                pn,
                                rr.X,
                                rr.Y,
                                rr.Width,
                                rr.Height);
                        }
                        else
                        {
                            e.Graphics.DrawLine(
                                pn,
                                a,
                                b);
                        }
                    }
                }

                // =========================================================
                // GUÍA VISUAL DE INFERENCIA / PROYECCIÓN
                // =========================================================
                if (_snapGuiaA != null &&
                    _snapGuiaB != null &&
                    chkOsnap.Checked)
                {
                    PointF ga =
                        ModeloAPantalla(
                            _snapGuiaA);

                    PointF gb =
                        ModeloAPantalla(
                            _snapGuiaB);

                    using (Pen guia =
                        new Pen(
                            Color.FromArgb(
                                55,
                                145,
                                215),
                            1.25F))
                    {
                        guia.DashStyle =
                            DashStyle.Dash;

                        e.Graphics.DrawLine(
                            guia,
                            ga,
                            gb);
                    }
                }

                if (_snapActual != null &&
                    chkOsnap.Checked)
                {
                    PointF s =
                        ModeloAPantalla(
                            _snapActual);

                    using (Pen pn =
                        new Pen(
                            Color.DarkOrange,
                            2F))
                    {
                        // Símbolo distinto para los tipos inferidos.
                        bool inferido =
                            !string.IsNullOrEmpty(
                                _snapNombre)
                            &&
                            (
                                _snapNombre.IndexOf(
                                    "PROY",
                                    StringComparison.OrdinalIgnoreCase) >=
                                    0
                                ||
                                _snapNombre.IndexOf(
                                    "EXT",
                                    StringComparison.OrdinalIgnoreCase) >=
                                    0
                                ||
                                _snapNombre.IndexOf(
                                    "PAR",
                                    StringComparison.OrdinalIgnoreCase) >=
                                    0
                                ||
                                _snapNombre.IndexOf(
                                    "PERP",
                                    StringComparison.OrdinalIgnoreCase) >=
                                    0
                                ||
                                _snapNombre.IndexOf(
                                    "INT",
                                    StringComparison.OrdinalIgnoreCase) >=
                                    0
                            );

                        if (inferido)
                        {
                            e.Graphics.DrawEllipse(
                                pn,
                                s.X - 5,
                                s.Y - 5,
                                10,
                                10);
                        }
                        else
                        {
                            e.Graphics.DrawRectangle(
                                pn,
                                s.X - 5,
                                s.Y - 5,
                                10,
                                10);
                        }
                    }
                }
            }

            private void SoportePreview(Graphics g, PreviewSoporte s)
            {
                if (s == null || s.Exterior == null || s.Exterior.Count < 3) return;
                PointF[] pts = s.Exterior.Select(ModeloAPantalla).ToArray();
                Color borde = Color.FromArgb(105, 105, 105);
                Color relleno = Color.FromArgb(18, 95, 95, 95);
                if (s.Tipo == "PILAR") { borde = Color.FromArgb(190, 120, 35); relleno = Color.FromArgb(28, 230, 165, 80); }
                else if (s.Tipo == "MURO") { borde = Color.FromArgb(115, 75, 130); relleno = Color.FromArgb(22, 160, 120, 180); }
                else if (s.Tipo == "VIGA") { borde = Color.FromArgb(95, 95, 95); relleno = Color.FromArgb(22, 130, 130, 130); }
                using (Brush br = new SolidBrush(relleno))
                using (Pen pn = new Pen(borde, 1.25F))
                { g.FillPolygon(br, pts); g.DrawPolygon(pn, pts); }
            }

            private void HuecoManualPreview(
                Graphics g,
                List<XYZ> hueco,
                int indice)
            {
                if (g == null ||
                    hueco == null ||
                    hueco.Count < 3)
                {
                    return;
                }

                PointF[] pts =
                    hueco
                    .Select(ModeloAPantalla)
                    .ToArray();

                using (Brush fondo =
                    new SolidBrush(
                        Color.White))
                using (Pen borde =
                    new Pen(
                        Color.Crimson,
                        2.0F))
                {
                    borde.DashStyle =
                        DashStyle.Dash;

                    g.FillPolygon(
                        fondo,
                        pts);

                    g.DrawPolygon(
                        borde,
                        pts);
                }

                XYZ c =
                    _h.CentroidePoligonoXY(
                        hueco);

                PointF pc =
                    ModeloAPantalla(c);

                using (Font f =
                    new Font(
                        "Segoe UI",
                        8F,
                        FontStyle.Bold))
                using (Brush br =
                    new SolidBrush(
                        Color.Crimson))
                {
                    g.DrawString(
                        "H" + indice,
                        f,
                        br,
                        pc.X + 3F,
                        pc.Y + 3F);
                }
            }

            private void OffsetBocetoPreview(
                Graphics g,
                PanoData p)
            {
                if (g == null ||
                    p == null ||
                    p.Rectangulo == null ||
                    p.Rectangulo.Count < 3)
                {
                    return;
                }

                double offset =
                    UnitUtils.ConvertToInternalUnits(
                        p.RecLatCm,
                        UnitTypeId.Centimeters);

                if (offset <= TOL)
                    return;

                List<XYZ> exterior =
                    _h.OffsetPoligonoXY(
                        p.Rectangulo,
                        offset,
                        true);

                if (exterior != null &&
                    exterior.Count >= 3)
                {
                    PointF[] pts =
                        exterior
                        .Select(
                            ModeloAPantalla)
                        .ToArray();

                    using (Pen pen =
                        new Pen(
                            Color.ForestGreen,
                            1.5F))
                    {
                        pen.DashStyle =
                            DashStyle.Dash;

                        g.DrawPolygon(
                            pen,
                            pts);
                    }
                }

                // Para los huecos, el offset útil va HACIA AFUERA.
                foreach (List<XYZ> h
                    in p.HuecosManuales)
                {
                    if (h == null ||
                        h.Count < 3)
                    {
                        continue;
                    }

                    List<XYZ> huecoOffset =
                        _h.OffsetPoligonoXY(
                            h,
                            offset,
                            false);

                    if (huecoOffset == null ||
                        huecoOffset.Count < 3)
                    {
                        continue;
                    }

                    PointF[] pts =
                        huecoOffset
                        .Select(
                            ModeloAPantalla)
                        .ToArray();

                    using (Pen pen =
                        new Pen(
                            Color.ForestGreen,
                            1.2F))
                    {
                        pen.DashStyle =
                            DashStyle.Dash;

                        g.DrawPolygon(
                            pen,
                            pts);
                    }
                }
            }

            private void RectanguloPreview(Graphics g, PanoData p, Color color, bool activo)
            {
                if (p == null || p.Rectangulo.Count < 3) return;
                PointF[] pts = p.Rectangulo.Select(ModeloAPantalla).ToArray();
                using (Brush br = new SolidBrush(Color.FromArgb(activo ? 45 : 18, color)))
                using (Pen pn = new Pen(color, activo ? 2.4F : 1.6F))
                {
                    g.FillPolygon(br, pts); g.DrawPolygon(pn, pts);
                }
            }

            private void FloorPreview(Graphics g, PreviewLosa pv, Func<XYZ, PointF> tr, Color fill, Color border, bool active)
            {
                if (pv == null || pv.Exterior.Count < 3) return;
                PointF[] ext = pv.Exterior.Select(tr).ToArray();
                using (Brush br = new SolidBrush(fill)) using (Pen pn = new Pen(border, active ? 1.8F : 1.0F))
                {
                    g.FillPolygon(br, ext); g.DrawPolygon(pn, ext);
                    foreach (List<XYZ> h in pv.Huecos)
                    {
                        PointF[] ph = h.Select(tr).ToArray(); g.FillPolygon(Brushes.White, ph); g.DrawPolygon(Pens.IndianRed, ph);
                    }
                }
            }

            private void NombrePanoPreview(Graphics g, PanoData p, Func<XYZ, PointF> tr, Color color)
            {
                PointF q = tr(CentroPano(p)); using (Brush b = new SolidBrush(color)) using (Font f = new Font("Segoe UI", 9F, FontStyle.Bold)) g.DrawString(p.Nombre, f, b, q.X + 4, q.Y + 4);
            }

            private void LineaPreview(Graphics g, Func<XYZ, PointF> tr, XYZ a, XYZ b, string txt, Color color)
            {
                if (a == null || b == null) return; PointF pa = tr(a), pb = tr(b);
                using (Pen pn = new Pen(color, 3F)) using (Brush br = new SolidBrush(color)) using (Font f = new Font("Segoe UI", 9F, FontStyle.Bold))
                { pn.EndCap = LineCap.ArrowAnchor; g.DrawLine(pn, pa, pb); g.DrawString(txt, f, br, pb.X + 4, pb.Y - 10); }
            }

            private void Mensaje(Graphics g, string txt)
            {
                using (Font f = new Font("Segoe UI", 11F)) using (Brush b = new SolidBrush(Color.Gray))
                { SizeF s = g.MeasureString(txt, f); g.DrawString(txt, f, b, (preview.Width - s.Width) / 2, (preview.Height - s.Height) / 2); }
            }

            private Box2 BoundingGeneral()
            {
                Box2 b = new Box2();
                foreach (PreviewLosa pv in _h._previewGeneral)
                    foreach (XYZ p in pv.Exterior)
                    { if (p.X < b.MinX) b.MinX = p.X; if (p.X > b.MaxX) b.MaxX = p.X; if (p.Y < b.MinY) b.MinY = p.Y; if (p.Y > b.MaxY) b.MaxY = p.Y; }

                foreach (PreviewSoporte s in _h._previewSoportes)
                    if (s != null && s.Exterior != null)
                        foreach (XYZ p in s.Exterior)
                        { if (p.X < b.MinX) b.MinX = p.X; if (p.X > b.MaxX) b.MaxX = p.X; if (p.Y < b.MinY) b.MinY = p.Y; if (p.Y > b.MaxY) b.MaxY = p.Y; }
                return b;
            }

            private XYZ CentroPano(PanoData p) { if (p != null && p.CentroRect != null) return p.CentroRect; Box2 b = _h.BoundingPano(p); return new XYZ((b.MinX + b.MaxX) / 2, (b.MinY + b.MaxY) / 2, 0); }
            private double TamanoPano(PanoData p) { Box2 b = _h.BoundingPano(p); return Math.Max(b.MaxX - b.MinX, b.MaxY - b.MinY); }

            // -----------------------------------------------------------------
            // MOUSE / ZOOM / PAN
            // -----------------------------------------------------------------
            private void MouseDownPreview(object sender, MouseEventArgs e)
            {
                preview.Focus();

                if (e.Button == MouseButtons.Right &&
                    (_modo == ModoDibujo.PanoPol ||
                     _modo == ModoDibujo.HuecoPol))
                {
                    DeshacerUltimoVerticePoligonal();
                    return;
                }

                if (e.Button == MouseButtons.Left && _modo != ModoDibujo.Ninguno)
                {
                    ProcesarClick(e.Location);
                    return;
                }

                if (e.Button == MouseButtons.Middle)
                {
                    _arrastrando = true;
                    _ultimoMouse = e.Location;
                    preview.Capture = true;
                    preview.Cursor = Cursors.SizeAll;
                }
            }

            private void MouseMovePreview(object sender, MouseEventArgs e)
            {
                _mouseModelo = PantallaAModelo(e.Location);
                if (_arrastrando)
                {
                    int dx = e.X - _ultimoMouse.X, dy = e.Y - _ultimoMouse.Y;
                    _pan = new PointF(_pan.X + dx, _pan.Y + dy); _ultimoMouse = e.Location; preview.Invalidate(); return;
                }

                if (_transformValida && chkOsnap != null && chkOsnap.Checked) PuntoConSnap(e.Location);
                else
                {
                    _snapActual = null;
                    _snapNombre = "";
                    _snapGuiaA = null;
                    _snapGuiaB = null;

                    if (lblSnap != null)
                        lblSnap.Text = "";
                }
                if (_modo != ModoDibujo.Ninguno || _snapActual != null) preview.Invalidate();
            }

            private void MouseUpPreview(object sender, MouseEventArgs e)
            {
                if (e.Button != MouseButtons.Middle) return; _arrastrando = false; preview.Capture = false; preview.Cursor = _modo == ModoDibujo.Ninguno ? Cursors.Default : Cursors.Cross;
            }

            private void MouseWheelPreview(object sender, MouseEventArgs e) { ZoomEn(e.Delta > 0 ? ZFACTOR : 1.0 / ZFACTOR, e.Location); }
            private void ZoomCentro(double f) { ZoomEn(f, new Point(preview.Width / 2, preview.Height / 2)); }

            private void ZoomEn(double factor, Point p)
            {
                if (!_transformValida) return;
                double old = _zoom, nuevo = Math.Max(ZMIN, Math.Min(ZMAX, old * factor));
                double eOld = _escalaBase * old, eNew = _escalaBase * nuevo, cx = preview.Width / 2.0, cy = preview.Height / 2.0;
                double mx = (p.X - cx - _pan.X) / eOld, my = -(p.Y - cy - _pan.Y) / eOld;
                _pan = new PointF((float)(p.X - cx - mx * eNew), (float)(p.Y - cy + my * eNew)); _zoom = nuevo; ActualizarZoom(); preview.Invalidate();
            }

            private void ActualizarZoom() { if (lblZoom != null) lblZoom.Text = ((int)Math.Round(_zoom * 100)).ToString() + "%"; }

            private XYZ PantallaAModelo(Point p)
            {
                if (!_transformValida) return null; double e = _escalaBase * _zoom; if (e <= 1e-12) return null;
                double cx = preview.Width / 2.0, cy = preview.Height / 2.0;
                return new XYZ(_cxm + (p.X - cx - _pan.X) / e, _cym - (p.Y - cy - _pan.Y) / e, 0);
            }

            private PointF ModeloAPantalla(XYZ p)
            {
                if (!_transformValida || p == null) return PointF.Empty;
                double e = _escalaBase * _zoom;
                return new PointF((float)(preview.Width / 2.0 + (p.X - _cxm) * e + _pan.X),
                                  (float)(preview.Height / 2.0 - (p.Y - _cym) * e + _pan.Y));
            }
        }

        private class PreviewPanel : Panel
        {
            internal PreviewPanel()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
                UpdateStyles(); TabStop = true;
            }
            protected override void OnMouseDown(MouseEventArgs e) { Focus(); base.OnMouseDown(e); }
        }

        // =====================================================================
        // DATOS
        // =====================================================================
        // =====================================================================
        // FAILURE PREPROCESSOR
        // =====================================================================
        // Un único set defectuoso ya no debe cancelar 800+ barras correctas.
        // Los Rebar específicamente implicados en:
        //   - barras coincidentes;
        //   - totalmente fuera del host;
        // se eliminan y Revit vuelve a intentar el Commit.
        //
        // IMPORTANTE:
        // Sólo se eliminan ElementId cuyo elemento ES Rebar. Nunca se borra
        // el Floor, la viga, el pilar o el muro anfitrión.
        private class RebarFailurePreprocessor : IFailuresPreprocessor
        {
            private readonly HashSet<long> _idsEliminados =
                new HashSet<long>();

            private readonly List<string> _mensajes =
                new List<string>();

            internal int RebarsEliminados
            {
                get
                {
                    return
                        _idsEliminados.Count;
                }
            }

            internal string Resumen()
            {
                if (_mensajes.Count == 0)
                {
                    return
                        "Revit no devolvió un detalle adicional.";
                }

                return
                    string.Join(
                        "\n",
                        _mensajes
                            .Distinct()
                            .Take(20));
            }

            public FailureProcessingResult PreprocessFailures(
                FailuresAccessor failuresAccessor)
            {
                if (failuresAccessor == null)
                    return FailureProcessingResult.Continue;

                IList<FailureMessageAccessor> fallos =
                    failuresAccessor.GetFailureMessages();

                if (fallos == null ||
                    fallos.Count == 0)
                {
                    return FailureProcessingResult.Continue;
                }

                Document doc =
                    failuresAccessor.GetDocument();

                bool seResolvioAlgo =
                    false;

                bool errorNoResuelto =
                    false;

                foreach (FailureMessageAccessor f
                    in fallos)
                {
                    if (f == null)
                        continue;

                    string desc =
                        "";

                    try
                    {
                        desc =
                            f.GetDescriptionText() ??
                            "";
                    }
                    catch
                    {
                    }

                    string low =
                        desc.ToLowerInvariant();

                    FailureSeverity sev =
                        f.GetSeverity();

                    bool fueraHost =
                        low.Contains(
                            "fuera de su anfitrión") ||
                        low.Contains(
                            "outside of its host") ||
                        low.Contains(
                            "outside its host");

                    bool coincidente =
                        low.Contains(
                            "barras coincidentes") ||
                        low.Contains(
                            "coincident bars") ||
                        low.Contains(
                            "armaduras no puede tener barras coincidentes");

                    if (sev ==
                        FailureSeverity.Warning)
                    {
                        if (fueraHost)
                        {
                            List<ElementId> rebarIds =
                                ObtenerRebarIds(
                                    doc,
                                    f);

                            if (rebarIds.Count > 0 &&
                                failuresAccessor
                                    .IsElementsDeletionPermitted(
                                        rebarIds))
                            {
                                failuresAccessor.DeleteElements(
                                    rebarIds);

                                RegistrarEliminados(
                                    rebarIds);

                                seResolvioAlgo =
                                    true;

                                _mensajes.Add(
                                    "Se descartó armadura totalmente fuera de su host.");

                                continue;
                            }
                        }

                        // Otras advertencias no deben abrir el diálogo de Revit.
                        failuresAccessor.DeleteWarning(f);
                        seResolvioAlgo =
                            true;

                        continue;
                    }

                    if (sev ==
                        FailureSeverity.Error &&
                        (coincidente || fueraHost))
                    {
                        List<ElementId> rebarIds =
                            ObtenerRebarIds(
                                doc,
                                f);

                        if (rebarIds.Count > 0 &&
                            failuresAccessor
                                .IsElementsDeletionPermitted(
                                    rebarIds))
                        {
                            failuresAccessor.DeleteElements(
                                rebarIds);

                            RegistrarEliminados(
                                rebarIds);

                            seResolvioAlgo =
                                true;

                            _mensajes.Add(
                                coincidente
                                ? "Se descartó un Rebar Set con barras coincidentes."
                                : "Se descartó un Rebar fuera de su host.");

                            continue;
                        }
                    }

                    if (sev ==
                        FailureSeverity.Error)
                    {
                        errorNoResuelto =
                            true;

                        if (!string.IsNullOrWhiteSpace(desc))
                            _mensajes.Add(desc);
                    }
                }

                if (errorNoResuelto)
                {
                    return
                        FailureProcessingResult
                            .ProceedWithRollBack;
                }

                if (seResolvioAlgo)
                {
                    return
                        FailureProcessingResult
                            .ProceedWithCommit;
                }

                return
                    FailureProcessingResult
                        .Continue;
            }

            private List<ElementId> ObtenerRebarIds(
                Document doc,
                FailureMessageAccessor f)
            {
                List<ElementId> salida =
                    new List<ElementId>();

                if (doc == null ||
                    f == null)
                {
                    return salida;
                }

                ICollection<ElementId> ids =
                    null;

                try
                {
                    ids =
                        f.GetFailingElementIds();
                }
                catch
                {
                }

                if (ids == null)
                    return salida;

                foreach (ElementId id
                    in ids)
                {
                    if (id == null)
                        continue;

                    Element e =
                        doc.GetElement(id);

                    if (e is Rebar)
                        salida.Add(id);
                }

                return salida;
            }

            private void RegistrarEliminados(
                IEnumerable<ElementId> ids)
            {
                if (ids == null)
                    return;

                foreach (ElementId id
                    in ids)
                {
                    if (id != null)
                        _idsEliminados.Add(
                            id.Value);
                }
            }
        }

        // =====================================================================
        // DTOs DE PERSISTENCIA JSON
        // =====================================================================
        private class EstadoEditorData
        {
            public string Version;
            public List<ReferenciaLosaData> Losas =
                new List<ReferenciaLosaData>();
            public BocetoEditorData Boceto;
        }
        private class ReferenciaLosaData
        {
            public long ElementId;
            public string UniqueId;
        }
        private class PuntoData
        {
            public double X;
            public double Y;
            public double Z;
        }
        private class ReferenciaTipoData
        {
            public long ElementId;
            public string Nombre;
        }
        private class BocetoEditorData
        {
            public string Nombre;
            public bool EsPoligonal;
            public List<PuntoData> Rectangulo =
                new List<PuntoData>();
            public List<List<PuntoData>> Huecos =
                new List<List<PuntoData>>();
            public PuntoData D1;
            public PuntoData D1A;
            public PuntoData D1B;
            public PuntoData D2;
            public PuntoData D2A;
            public PuntoData D2B;
            public bool D1Definida;
            public bool D2Definida;
            public bool D2Auto;
            public bool CrearInfD1;
            public bool CrearInfD2;
            public bool CrearSupD1;
            public bool CrearSupD2;
            public ReferenciaTipoData TipoInfD1;
            public ReferenciaTipoData TipoInfD2;
            public ReferenciaTipoData TipoSupD1;
            public ReferenciaTipoData TipoSupD2;
            public double EspInfD1Cm;
            public double EspInfD2Cm;
            public double EspSupD1Cm;
            public double EspSupD2Cm;
            public double RecInfCm;
            public double RecSupCm;
            public double OffsetBocetoCm;
            public bool AtravesarVigas;
            public bool RespetarHuecos;
        }

        // Contenedor interno histórico. En esta versión representa ÚNICAMENTE
        // el BOCETO GENERAL; no existe gestión de múltiples paños.
        private class PanoData
        {
            internal int Id; internal string Nombre;
            internal readonly List<ElementId> Losas = new List<ElementId>();
            internal readonly List<PreviewLosa> Preview = new List<PreviewLosa>();
            internal XYZ RectP1, RectP2, CentroRect;
            internal readonly List<XYZ> Rectangulo = new List<XYZ>();

            // Huecos dibujados manualmente por el usuario dentro del boceto general.
            // Cada entrada es un loop cerrado (sin repetir el primer punto al final).
            internal readonly List<List<XYZ>> HuecosManuales = new List<List<XYZ>>();

            internal bool EsPoligonal;
            internal XYZ D1, D1A, D1B, D2, D2A, D2B;
            internal bool D1Definida, D2Definida, D2Auto = true;
            internal bool CrearInfD1 = true, CrearInfD2 = true, CrearSupD1 = true, CrearSupD2 = true;
            internal ElementId TipoInfD1Id = ElementId.InvalidElementId, TipoInfD2Id = ElementId.InvalidElementId, TipoSupD1Id = ElementId.InvalidElementId, TipoSupD2Id = ElementId.InvalidElementId;
            internal double EspInfD1Cm = 20, EspInfD2Cm = 20, EspSupD1Cm = 20, EspSupD2Cm = 20;
            internal double RecInfCm = 2.5, RecSupCm = 2.5, RecLatCm = 2.5;
            internal bool AtravesarVigas = true, RespetarHuecos = true;
        }

        private class PreviewLosa
        {
            internal ElementId LosaId; internal string Nombre;
            internal List<List<XYZ>> Contornos = new List<List<XYZ>>();
            internal List<XYZ> Exterior = new List<XYZ>();
            internal List<List<XYZ>> Huecos = new List<List<XYZ>>();
        }

        private class SegmentoCortePlano
        {
            internal XYZ A;
            internal XYZ B;
        }

        private class PreviewSoporte
        {
            internal ElementId ElementId;
            internal string Tipo;
            internal List<XYZ> Exterior = new List<XYZ>();
            internal BoundingBoxXYZ Box;
            internal double PlanoZ;
        }

        private class SoporteBloqueoDireccion
        {
            internal PreviewSoporte Soporte;
            internal List<P2> Poligono2D = new List<P2>();

            // true = la barra llega perpendicular/casi perpendicular.
            // La continuidad final todavía exige comprobar entrada + salida.
            internal bool PermitePasoAngular;
        }

        private class CandidatoMechaTerminal
        {
            internal SoporteBloqueoDireccion Soporte;
            internal double Inicio;
            internal double Fin;
        }

        private class MechaTerminalData
        {
            internal bool Valida;
            internal double ExtremoFinal;
            internal ElementId ElementIdSoporte;
            internal string TipoSoporte;
        }

        private class IntervaloApoyoDireccion
        {
            internal double Inicio;
            internal double Fin;

            // En una región fusionada todos los sólidos deben permitir
            // paso angular. Si uno falla, la región completa bloquea.
            internal bool PermitePasoAngular = true;

            internal List<PreviewSoporte> Soportes =
                new List<PreviewSoporte>();
        }

        private class SeccionSoporteCandidata
        {
            internal Element Elemento;
            internal double PlanoZ;
            internal List<XYZ> Poligono = new List<XYZ>();
            internal double Area;
            internal double DistanciaALosa;
            internal BoundingBoxXYZ Box;
        }

        private class SnapEvaluacion
        {
            internal XYZ Punto;
            internal string Nombre;
            internal int Prioridad;
            internal double DistanciaPix;

            // Línea guía temporal mostrada en el preview.
            internal XYZ GuiaA;
            internal XYZ GuiaB;
        }

        private class P2 { internal double X, Y; }
        private class Intervalo { internal double Inicio, Fin; internal bool InicioHueco, FinHueco; }
        private class LosaCapa { internal Floor Host; internal PlanarFace Face; internal XYZ Normal; internal List<P2> Exterior = new List<P2>(); internal List<List<P2>> Huecos = new List<List<P2>>(); }
        private class Segmento { internal LosaCapa Data; internal double Inicio, Fin; internal bool InicioHueco, FinHueco; }
        private class Grupo { internal double Inicio, Fin; internal List<Segmento> Segmentos = new List<Segmento>(); internal List<Puente> Puentes = new List<Puente>(); }
        private class Puente { internal Element Viga; internal XYZ A, B; }
        private class VigaData { internal Element Elemento; internal BoundingBoxXYZ Box; }

        private class CoberturaHostPano
        {
            internal Element Host;
            internal double Inicio;
            internal double Fin;
            internal int Prioridad;
        }
        private class ResultadoCapa { internal int Barras, Puentes; internal List<string> Errores = new List<string>(); }
        private class ResultadoPano { internal int Barras, Puentes; internal List<string> Errores = new List<string>(); }
        private class Box2 { internal double MinX = double.MaxValue, MaxX = double.MinValue, MinY = double.MaxValue, MaxY = double.MinValue; }

        private enum Accion { Ninguna, SeleccionarUniverso, CrearActivo, CrearTodos }
        private enum ModoDibujo { Ninguno, PanoRect, PanoPol, HuecoPol, D1, D2 }

        private class FiltroLosas : ISelectionFilter
        {
            public bool AllowElement(Element e) { return e is Floor; }
            public bool AllowReference(Reference r, XYZ p) { return false; }
        }

        private class FiltroLosasPermitidas : ISelectionFilter
        {
            private readonly HashSet<long> _ids;
            internal FiltroLosasPermitidas(HashSet<long> ids) { _ids = ids ?? new HashSet<long>(); }
            public bool AllowElement(Element e) { return e is Floor && _ids.Contains(e.Id.Value); }
            public bool AllowReference(Reference r, XYZ p) { return false; }
        }
    }
}
