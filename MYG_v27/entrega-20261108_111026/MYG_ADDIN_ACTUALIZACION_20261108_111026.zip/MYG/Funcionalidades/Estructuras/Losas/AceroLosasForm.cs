using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // ============================================================================
    // MYG - ACERO EN LOSAS
    // PUENTE MINIMO DE VENTANA
    //
    // SIN USING
    // SIN NAMESPACE
    //
    // NO MODIFICAR ESTE ARCHIVO EN ADELANTE.
    // Toda la ventana, preview y logica estan en ACERO_LOSAS_EJECUCION.cs.
    //
    // Visual Studio mostrara UN SOLO bloque/clase para contraer.
    // ============================================================================

    internal static class AceroLosasForm
    {
        public static void Abrir(
            Autodesk.Revit.UI.UIDocument uidoc,
            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarBarType> tiposBarra)
        {
            MYG_Addin.EjecutarAceroLosasHandler.Abrir(
                uidoc,
                tiposBarra);
        }
    }

}
