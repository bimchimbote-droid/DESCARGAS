﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

// =========================================================
// MYG - CONTROL GLOBAL DE FALLOS PARA EJECUCION MASIVA
// Revit 2027
//
// Objetivo:
// - Eliminar advertencias sin mostrar cuadros modales.
// - Si Revit ofrece "Separar elementos", aplicarlo automáticamente.
// - Si un error NO puede resolverse de forma segura, revertir SOLO la
//   transacción actual en silencio para que el lote continúe.
// - NUNCA usa una resolución que elimine/suprima elementos del modelo.
// =========================================================
public static class MYG_TarrajeoFallosSilenciosos
{
    public static void Configurar(Transaction tx)
    {
        if (tx == null)
            return;

        Configurar(tx, new MYG_TarrajeoPreprocesadorMasivo());
    }

    public static void Configurar(
        Transaction tx,
        IFailuresPreprocessor preprocesador)
    {
        if (tx == null || preprocesador == null)
            return;

        try
        {
            FailureHandlingOptions opciones = tx.GetFailureHandlingOptions();

            opciones = opciones
                .SetFailuresPreprocessor(preprocesador)
                .SetClearAfterRollback(true)
                .SetDelayedMiniWarnings(false);

            // Disponible en versiones recientes de Revit. Se invoca por
            // reflexión para no romper compilación si la firma cambia.
            try
            {
                MethodInfo metodo = typeof(FailureHandlingOptions).GetMethod(
                    "SetForcedModalHandling",
                    BindingFlags.Public | BindingFlags.Instance,
                    null,
                    new Type[] { typeof(bool) },
                    null);

                if (metodo != null)
                {
                    object resultado = metodo.Invoke(
                        opciones,
                        new object[] { false });

                    if (resultado is FailureHandlingOptions)
                        opciones = (FailureHandlingOptions)resultado;
                }
            }
            catch
            {
            }

            tx.SetFailureHandlingOptions(opciones);
        }
        catch
        {
        }
    }
}

public class MYG_TarrajeoPreprocesadorMasivo : IFailuresPreprocessor
{
    private int _pasadas;

    public string UltimoMensaje { get; private set; } = string.Empty;

    public FailureProcessingResult PreprocessFailures(
        FailuresAccessor failuresAccessor)
    {
        _pasadas++;

        if (failuresAccessor == null)
            return FailureProcessingResult.ProceedWithRollBack;

        IList<FailureMessageAccessor> fallos = null;

        try
        {
            fallos = failuresAccessor.GetFailureMessages();
        }
        catch
        {
            return FailureProcessingResult.ProceedWithRollBack;
        }

        if (fallos == null || fallos.Count == 0)
            return FailureProcessingResult.Continue;

        bool huboError = false;
        bool huboResolucion = false;
        bool hayErrorNoResuelto = false;
        List<string> mensajes = new List<string>();

        foreach (FailureMessageAccessor fallo in fallos)
        {
            if (fallo == null)
                continue;

            try
            {
                string texto = fallo.GetDescriptionText();

                if (!string.IsNullOrWhiteSpace(texto))
                    mensajes.Add(texto);
            }
            catch
            {
            }

            FailureSeverity severidad;

            try
            {
                severidad = fallo.GetSeverity();
            }
            catch
            {
                hayErrorNoResuelto = true;
                continue;
            }

            if (severidad == FailureSeverity.Warning)
            {
                try
                {
                    failuresAccessor.DeleteWarning(fallo);
                }
                catch
                {
                }

                continue;
            }

            huboError = true;

            // Primera y única resolución automática deliberada:
            // "Separar elementos". Es la opción segura para el caso
            // "No es posible mantener unidos los elementos".
            if (IntentarSepararElementos(failuresAccessor, fallo))
            {
                huboResolucion = true;
                continue;
            }

            // Cualquier otro error (por ejemplo "No es posible crear muro")
            // hace rollback SOLO de esta transacción. De esta forma no aparece
            // el cuadro modal y el procesamiento masivo continúa con la cara
            // o elemento siguiente.
            hayErrorNoResuelto = true;
        }

        UltimoMensaje = mensajes.Count > 0
            ? string.Join(" | ", mensajes.Distinct().Take(5))
            : string.Empty;

        // Protección contra ciclos de resolución repetidos.
        if (_pasadas > 8)
            return FailureProcessingResult.ProceedWithRollBack;

        if (hayErrorNoResuelto)
            return FailureProcessingResult.ProceedWithRollBack;

        if (huboError && huboResolucion)
            return FailureProcessingResult.ProceedWithCommit;

        // Solo había advertencias y ya fueron eliminadas.
        return FailureProcessingResult.ProceedWithCommit;
    }

    private bool IntentarSepararElementos(
        FailuresAccessor failuresAccessor,
        FailureMessageAccessor fallo)
    {
        if (failuresAccessor == null || fallo == null)
            return false;

        // Algunos fallos permiten establecer la resolución aunque en la
        // primera pasada IsFailureResolutionPermitted devuelva false.
        try
        {
            fallo.SetCurrentResolutionType(
                FailureResolutionType.DetachElements);

            failuresAccessor.ResolveFailure(fallo);
            return true;
        }
        catch
        {
        }

        try
        {
            if (fallo.HasResolutions() &&
                failuresAccessor.IsFailureResolutionPermitted(
                    fallo,
                    FailureResolutionType.DetachElements))
            {
                fallo.SetCurrentResolutionType(
                    FailureResolutionType.DetachElements);

                failuresAccessor.ResolveFailure(fallo);
                return true;
            }
        }
        catch
        {
        }

        return false;
    }
}
