﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;

// =========================================================
// MYG - UTILIDAD COMÚN: UNIONES OCULTAS SEGÚN VISTA ACTIVA
// =========================================================
// Recupera temporalmente la geometría completa del elemento seleccionado
// cuando otro elemento OCULTO en la vista activa lo está cortando mediante
// Join Geometry. Después del tarrajeo se restaura exactamente el orden de unión.
//
// IMPORTANTE:
// - Solo modifica temporalmente elementos NATIVOS del documento activo.
// - Los documentos vinculados son de solo lectura desde el host.
// - La visibilidad real la decide Tarrajeo_MurosHandler V75 mediante la vista
//   activa + CustomExporter.
// =========================================================
public static class TarrajeoVistaActivaUnionesHelper
{
    public sealed class UnionOcultaInvertida
    {
        public ElementId ElementoSeleccionadoId;
        public ElementId OtroId;
    }

    public static List<UnionOcultaInvertida> InvertirTemporalmenteUnionesOcultasQueCortan(
        Document doc,
        IEnumerable<Element> elementosSeleccionados,
        Tarrajeo_MurosHandler motorVisibilidad)
    {
        List<UnionOcultaInvertida> resultado =
            new List<UnionOcultaInvertida>();

        if (doc == null || elementosSeleccionados == null || motorVisibilidad == null)
            return resultado;

        List<Element> elementos = elementosSeleccionados
            .Where(e => e != null)
            .GroupBy(e => e.Id)
            .Select(g => g.First())
            .ToList();

        if (elementos.Count == 0)
            return resultado;

        List<UnionOcultaInvertida> candidatas =
            new List<UnionOcultaInvertida>();

        HashSet<string> claves = new HashSet<string>();

        foreach (Element seleccionado in elementos)
        {
            if (seleccionado == null)
                continue;

            try
            {
                if (!object.ReferenceEquals(seleccionado.Document, doc))
                    continue;
            }
            catch
            {
                continue;
            }

            ICollection<ElementId> unidos = null;

            try
            {
                unidos = JoinGeometryUtils.GetJoinedElements(doc, seleccionado);
            }
            catch
            {
                unidos = null;
            }

            if (unidos == null || unidos.Count == 0)
                continue;

            foreach (ElementId id in unidos)
            {
                if (id == null ||
                    id == ElementId.InvalidElementId ||
                    id.Equals(seleccionado.Id))
                {
                    continue;
                }

                Element otro = null;

                try
                {
                    otro = doc.GetElement(id);
                }
                catch
                {
                    otro = null;
                }

                if (otro == null)
                    continue;

                // Si el otro elemento SÍ aparece en la vista activa, su corte es
                // intencional y debe mantenerse.
                bool visible = true;

                try
                {
                    visible = motorVisibilidad
                        .EsElementoVisibleEnVistaActivaParaTarrajeo(otro);
                }
                catch
                {
                    visible = true;
                }

                if (visible)
                    continue;

                bool otroCortaSeleccionado = false;

                try
                {
                    if (!JoinGeometryUtils.AreElementsJoined(doc, seleccionado, otro))
                        continue;

                    otroCortaSeleccionado =
                        JoinGeometryUtils.IsCuttingElementInJoin(
                            doc,
                            otro,
                            seleccionado);
                }
                catch
                {
                    otroCortaSeleccionado = false;
                }

                if (!otroCortaSeleccionado)
                    continue;

                string clave = seleccionado.Id + "|" + otro.Id;

                if (!claves.Add(clave))
                    continue;

                candidatas.Add(new UnionOcultaInvertida()
                {
                    ElementoSeleccionadoId = seleccionado.Id,
                    OtroId = otro.Id
                });
            }
        }

        if (candidatas.Count == 0)
            return resultado;

        try
        {
            using (Transaction tx = new Transaction(
                doc,
                "MYG - Ignorar uniones ocultas para leer caras"))
            {
                tx.Start();
                MYG_TarrajeoFallosSilenciosos.Configurar(tx);

                foreach (UnionOcultaInvertida par in candidatas)
                {
                    if (par == null)
                        continue;

                    try
                    {
                        Element seleccionado = doc.GetElement(par.ElementoSeleccionadoId);
                        Element otro = doc.GetElement(par.OtroId);

                        if (seleccionado == null || otro == null)
                            continue;

                        if (!JoinGeometryUtils.AreElementsJoined(doc, seleccionado, otro))
                            continue;

                        // En la situación detectada, el elemento OCULTO corta al
                        // seleccionado. Invertimos el orden únicamente para leer
                        // la geometría completa que debe existir en esta vista.
                        JoinGeometryUtils.SwitchJoinOrder(
                            doc,
                            seleccionado,
                            otro);

                        resultado.Add(par);
                    }
                    catch
                    {
                    }
                }

                doc.Regenerate();
                TransactionStatus estado = tx.Commit();

                if (estado != TransactionStatus.Committed)
                    resultado.Clear();
            }
        }
        catch
        {
            resultado.Clear();
        }

        return resultado;
    }

    public static void RestaurarUnionesOcultasInvertidas(
        Document doc,
        IEnumerable<UnionOcultaInvertida> uniones)
    {
        if (doc == null || uniones == null)
            return;

        List<UnionOcultaInvertida> lista = uniones
            .Where(x => x != null)
            .ToList();

        if (lista.Count == 0)
            return;

        try
        {
            using (Transaction tx = new Transaction(
                doc,
                "MYG - Restaurar uniones ocultas"))
            {
                tx.Start();
                MYG_TarrajeoFallosSilenciosos.Configurar(tx);

                foreach (UnionOcultaInvertida par in lista)
                {
                    try
                    {
                        Element seleccionado = doc.GetElement(par.ElementoSeleccionadoId);
                        Element otro = doc.GetElement(par.OtroId);

                        if (seleccionado == null || otro == null)
                            continue;

                        if (!JoinGeometryUtils.AreElementsJoined(doc, seleccionado, otro))
                            continue;

                        // Tras la inversión temporal, el seleccionado debe estar
                        // cortando al otro. Solo entonces restauramos el orden.
                        bool seleccionadoCortaOtro =
                            JoinGeometryUtils.IsCuttingElementInJoin(
                                doc,
                                seleccionado,
                                otro);

                        if (seleccionadoCortaOtro)
                        {
                            JoinGeometryUtils.SwitchJoinOrder(
                                doc,
                                seleccionado,
                                otro);
                        }
                    }
                    catch
                    {
                    }
                }

                doc.Regenerate();
                tx.Commit();
            }
        }
        catch
        {
        }
    }
}
