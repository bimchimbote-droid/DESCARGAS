﻿// =====================================
// HANDLER V22 - SELECCIONAR VIGAS - VISTA ACTIVA REAL
// - Conserva V21: no prefiltra caras de extremo.
// - Usa Tarrajeo_MurosHandler V75 como autoridad de visibilidad.
// - Si un elemento OCULTO corta la viga por Join Geometry, invierte temporalmente
//   el orden de unión para recuperar la cara completa y lo restaura al finalizar.
// - Las caras inferiores/inclinadas usan Tarrajeo_SuelosHandler V29.
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

public class SeleccionarVigasTarrajeoHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoElementosForm Form;

    public FloorType TipoSuelo;
    public WallType TipoMuro;
    public bool PermitirUnion;
    public bool ConsiderarVinculos;

    // Motores comunes de creación.
    // El comando los inyecta para que por ELEMENTOS use la misma lógica que por CARAS.
    public Tarrajeo_MurosHandler CreadorMuros;
    public Tarrajeo_SuelosHandler CreadorSuelos;

    public List<ElementId> ElementosSeleccionados = new List<ElementId>();

    private const double TolNormalVertical = 0.001;
    private const double TolCaraSuperior = 0.001;
    private const double MinAreaCara = 0.0001;

    // 🔥 Para detectar si una cara es extremo de viga:
    // si la normal de la cara es casi paralela al eje longitudinal de la viga.
    private const double UmbralCaraExtremo = 0.85;

    // 🔥 Profundidad del sólido temporal para detectar cara tapada.
    // 0.06 ft ≈ 1.8 cm. Menos agresivo que 0.10 ft.
    private const double ProfundidadChequeoCaraTapada = 0.06;

    // 🔥 Si más del 60% del sólido temporal choca con columna/muro,
    // se considera cara tapada.
    private const double RatioMinimoCaraTapada = 0.60;

    private const double VolumenMinimoInterseccion = 1e-7;
    private const double MargenBusqueda = 0.05;

    private class CaraTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public RevitLinkInstance LinkOrigen;
        public Face Cara;
        public Transform TransformCara;
        public bool CrearComoMuro;
    }

    private class ElementoTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public Transform TransformCara;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;

        List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida> unionesOcultasInvertidas =
            new List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida>();

        try
        {
            //-------------------------------------------------
            // TOMAR DATOS DESDE EL FORMULARIO
            //-------------------------------------------------
            if (Form != null)
            {
                TipoSuelo = Form.TipoSueloSeleccionado;
                TipoMuro = Form.TipoMuroSeleccionado;
                PermitirUnion = Form.PermitirUnion;
                ConsiderarVinculos = Form.ConsiderarVinculos;
            }

            //-------------------------------------------------
            // VALIDAR TIPO DE SUELO O MURO
            //-------------------------------------------------
            if (TipoSuelo == null && TipoMuro == null)
            {
                TaskDialog.Show(
                    "MYG",
                    "Debe seleccionar un tipo de suelo o un tipo de muro.");

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // SELECCIONAR VIGAS
            //-------------------------------------------------
            ObjectType tipoSeleccion = ConsiderarVinculos ? ObjectType.LinkedElement : ObjectType.Element;

            IList<Reference> refs = uidoc.Selection.PickObjects(
                tipoSeleccion,
                new VigasTarrajeoSelectionFilter(doc, ConsiderarVinculos),
                ConsiderarVinculos
                    ? "Seleccione vigas estructurales de vínculos"
                    : "Seleccione vigas estructurales");

            if (refs == null || refs.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            List<ElementoTrabajo> elementosTrabajo = ObtenerElementosTrabajo(doc, refs);

            ElementosSeleccionados = elementosTrabajo
                .Where(x => x != null && x.HostElem != null)
                .Select(x => x.HostElem.Id)
                .Distinct()
                .ToList();

            if (elementosTrabajo.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // VISTA ACTIVA REAL - PREPARAR MOTORES ANTES DE LEER CARAS
            //-------------------------------------------------
            Tarrajeo_MurosHandler creadorMuros =
                CreadorMuros ?? new Tarrajeo_MurosHandler();

            Tarrajeo_SuelosHandler creadorSuelos =
                CreadorSuelos ?? new Tarrajeo_SuelosHandler();

            creadorMuros.UiDoc = uidoc;
            creadorSuelos.UiDoc = uidoc;

            creadorMuros.PrepararNuevaEjecucion();
            creadorSuelos.PrepararNuevaEjecucion();

            //-------------------------------------------------
            // IGNORAR SOLO UNIONES DE ELEMENTOS OCULTOS EN LA VISTA ACTIVA
            //-------------------------------------------------
            unionesOcultasInvertidas =
                TarrajeoVistaActivaUnionesHelper
                .InvertirTemporalmenteUnionesOcultasQueCortan(
                    doc,
                    elementosTrabajo
                        .Where(x => x != null && x.GeoElem != null)
                        .Select(x => x.GeoElem),
                    creadorMuros);

            //-------------------------------------------------
            // PREPROCESAR CARAS ANTES DE CREAR ELEMENTOS
            //-------------------------------------------------
            List<CaraTrabajo> carasParaCrear = new List<CaraTrabajo>();

            int vigasProcesadas = 0;
            int carasOmitidas = 0;
            int carasSuperioresOmitidas = 0;

            foreach (ElementoTrabajo et in elementosTrabajo)
            {
                Element elem = et != null ? et.HostElem : null;
                Element geoElem = et != null ? et.GeoElem : null;
                Transform transformCara = et != null && et.TransformCara != null ? et.TransformCara : Transform.Identity;

                if (elem == null || geoElem == null)
                    continue;

                vigasProcesadas++;

                List<Face> caras = ObtenerCarasValidasEnModelo(geoElem, transformCara);

                foreach (Face cara in caras)
                {
                    if (cara == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    if (cara.Area <= MinAreaCara)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    XYZ normal = ObtenerNormalCara(cara, Transform.Identity);

                    if (normal == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    normal = normal.Normalize();

                    //-------------------------------------------------
                    // OMITIR CARAS SUPERIORES
                    //-------------------------------------------------
                    if (normal.Z > TolCaraSuperior)
                    {
                        carasSuperioresOmitidas++;
                        continue;
                    }

                    //-------------------------------------------------
                    // V21 - NO PREFILTRAR CARAS DE EXTREMO
                    //-------------------------------------------------
                    // Toda cara geométricamente válida se envía al motor común.
                    // Si está realmente ocupada por un elemento visible HACIA EL
                    // EXTERIOR, el motor V74 la recortará o eliminará. Si el otro
                    // elemento está detrás de la cara, la cara permanece disponible.
                    //-------------------------------------------------

                    //-------------------------------------------------
                    // CARA VERTICAL → MURO
                    //-------------------------------------------------
                    if (Math.Abs(normal.Z) < TolNormalVertical)
                    {
                        if (TipoMuro == null)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        carasParaCrear.Add(new CaraTrabajo
                        {
                            HostElem = elem,
                            GeoElem = geoElem,
                            LinkOrigen = elem as RevitLinkInstance,
                            Cara = cara,
                            TransformCara = Transform.Identity,
                            CrearComoMuro = true
                        });

                        continue;
                    }

                    //-------------------------------------------------
                    // CARA INFERIOR O INCLINADA HACIA ABAJO → SUELO
                    //-------------------------------------------------
                    if (TipoSuelo == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    carasParaCrear.Add(new CaraTrabajo
                    {
                        HostElem = elem,
                        GeoElem = geoElem,
                        LinkOrigen = elem as RevitLinkInstance,
                        Cara = cara,
                        TransformCara = Transform.Identity,
                        CrearComoMuro = false
                    });
                }
            }

            if (carasParaCrear.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Tarrajeo por Vigas",
                    "No se encontraron caras válidas para crear tarrajeo.\n\n" +
                    "Vigas procesadas: " + vigasProcesadas + "\n" +
                    "Caras superiores omitidas: " + carasSuperioresOmitidas + "\n" +
                    "Caras omitidas: " + carasOmitidas);

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // CREAR TARRAJEO
            //-------------------------------------------------
            int murosCreados = 0;
            int suelosCreados = 0;

            foreach (CaraTrabajo item in carasParaCrear)
            {
                if (item == null || item.HostElem == null || item.Cara == null)
                {
                    carasOmitidas++;
                    continue;
                }

                //-------------------------------------------------
                // MISMA LÓGICA QUE TARRAJEO POR CARA:
                // Cara vertical -> motor común de muros.
                // Cara inferior/inclinada -> motor común de suelos.
                //-------------------------------------------------
                if (item.CrearComoMuro)
                {
                    creadorMuros.ConfigurarOrigenDeRecorte(
                        item.GeoElem ?? item.HostElem,
                        item.LinkOrigen);

                    List<Wall> murosCreadosCara = creadorMuros.CrearMurosDesdeFaceProcesada(
                        doc,
                        uidoc,
                        item.HostElem,
                        item.Cara,
                        item.TransformCara ?? Transform.Identity,
                        TipoMuro,
                        PermitirUnion);

                    if (murosCreadosCara != null && murosCreadosCara.Count > 0)
                        murosCreados += murosCreadosCara.Count;
                    else
                        carasOmitidas++;

                    continue;
                }

                PlanarFace caraPlanaSuelo = item.Cara as PlanarFace;

                if (caraPlanaSuelo == null)
                {
                    carasOmitidas++;
                    continue;
                }

                creadorSuelos.ConfigurarOrigenDeRecorte(
                    item.GeoElem ?? item.HostElem,
                    item.LinkOrigen);

                bool creadoSuelo = creadorSuelos.CrearSueloDesdeCaraPlanarProcesada(
                    doc,
                    uidoc,
                    item.HostElem,
                    caraPlanaSuelo,
                    item.TransformCara ?? Transform.Identity,
                    TipoSuelo);

                if (creadoSuelo)
                    suelosCreados++;
                else
                    carasOmitidas++;
            }

            //-------------------------------------------------
            // V13 - FINAL SILENCIOSO
            // No se muestra TaskDialog al terminar correctamente.
            // La ventana de elementos se restaura automáticamente.
            //-------------------------------------------------
            MostrarFormulario();
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarFormulario();
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG - Error",
                "Ocurrió un error al crear tarrajeo en vigas:\n\n" + ex.Message);

            MostrarFormulario();
        }
        finally
        {
            TarrajeoVistaActivaUnionesHelper
                .RestaurarUnionesOcultasInvertidas(
                    doc,
                    unionesOcultasInvertidas);
        }
    }

    // =====================================
    // EJE LONGITUDINAL DE LA VIGA
    // =====================================
    private bool TryGetEjeLongitudinalViga(
        Element elem,
        out XYZ eje)
    {
        eje = XYZ.Zero;

        try
        {
            LocationCurve lc = elem.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return false;

            XYZ p0 = lc.Curve.GetEndPoint(0);
            XYZ p1 = lc.Curve.GetEndPoint(1);

            XYZ dir = p1 - p0;

            if (dir.GetLength() < 1e-6)
                return false;

            eje = dir.Normalize();
            return true;
        }
        catch
        {
            eje = XYZ.Zero;
            return false;
        }
    }

    // =====================================
    // DETECTAR CARA DE EXTREMO DE VIGA
    // =====================================
    private bool EsCaraDeExtremoDeViga(
        XYZ normalCara,
        XYZ ejeViga)
    {
        try
        {
            if (normalCara == null || ejeViga == null)
                return false;

            XYZ n = normalCara.Normalize();
            XYZ e = ejeViga.Normalize();

            double dot = Math.Abs(n.DotProduct(e));

            return dot >= UmbralCaraExtremo;
        }
        catch
        {
            return false;
        }
    }

    // =====================================
    // V21 LEGACY - YA NO SE USA PARA PREFILTRAR CARAS
    // Se conserva por compatibilidad, pero todas las caras pasan al motor común V74
    // =====================================
    private bool EstaCaraDeExtremoTapadaPorElementoDeCierre(
        Document doc,
        View vistaActiva,
        Element hostElem,
        PlanarFace cara,
        XYZ normal)
    {
        try
        {
            if (doc == null) return false;
            if (hostElem == null) return false;
            if (cara == null) return false;
            if (normal == null) return false;

            normal = normal.Normalize();

            IList<CurveLoop> loopsCara = cara.GetEdgesAsCurveLoops();

            if (loopsCara == null || loopsCara.Count == 0)
                return false;

            //-------------------------------------------------
            // CREAR SÓLIDO TEMPORAL HACIA AFUERA DE LA CARA
            //-------------------------------------------------
            Solid solidCara = null;

            try
            {
                solidCara = GeometryCreationUtilities.CreateExtrusionGeometry(
                    loopsCara.ToList(),
                    normal,
                    ProfundidadChequeoCaraTapada);
            }
            catch
            {
                solidCara = null;
            }

            if (solidCara == null || solidCara.Volume <= 0)
                return false;

            //-------------------------------------------------
            // CREAR OUTLINE PARA BUSCAR ELEMENTOS CERCANOS
            //-------------------------------------------------
            Outline outline = CrearOutlineDeCara(
                loopsCara,
                normal,
                ProfundidadChequeoCaraTapada,
                MargenBusqueda);

            if (outline == null)
                return false;

            //-------------------------------------------------
            // BUSCAR SOLO ELEMENTOS QUE PUEDEN TAPAR EXTREMOS:
            // Columnas estructurales, columnas arquitectónicas y muros.
            //-------------------------------------------------
            FilteredElementCollector collectorCandidatos =
                vistaActiva != null && !vistaActiva.IsTemplate
                    ? new FilteredElementCollector(doc, vistaActiva.Id)
                    : new FilteredElementCollector(doc);

            List<Element> candidatos = collectorCandidatos
                .WherePasses(new BoundingBoxIntersectsFilter(outline))
                .WhereElementIsNotElementType()
                .Where(e => EsElementoDeCierreParaExtremo(e))
                .Where(e => e.Id != hostElem.Id)
                .Where(e => EsElementoVisibleEnVista(e, vistaActiva))
                .ToList();

            if (candidatos.Count == 0)
                return false;

            //-------------------------------------------------
            // CALCULAR INTERSECCIÓN
            //-------------------------------------------------
            double volumenInterseccionTotal = 0.0;

            foreach (Element elem in candidatos)
            {
                foreach (Solid solidElem in ObtenerSolidosElemento(elem, vistaActiva))
                {
                    try
                    {
                        if (solidElem == null || solidElem.Volume <= 0)
                            continue;

                        Solid interseccion = BooleanOperationsUtils.ExecuteBooleanOperation(
                            solidCara,
                            solidElem,
                            BooleanOperationsType.Intersect);

                        if (interseccion == null ||
                            interseccion.Volume <= VolumenMinimoInterseccion)
                        {
                            continue;
                        }

                        volumenInterseccionTotal += interseccion.Volume;

                        double ratio = volumenInterseccionTotal / solidCara.Volume;

                        if (ratio >= RatioMinimoCaraTapada)
                            return true;
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

            return false;
        }
        catch
        {
            return false;
        }
    }

    private bool EsElementoDeCierreParaExtremo(Element e)
    {
        if (e == null)
            return false;

        if (e.Category == null)
            return false;

        if (e.Category.CategoryType != CategoryType.Model)
            return false;

        if (e.ViewSpecific)
            return false;

        ElementId catId = e.Category.Id;

        // Columnas estructurales
        if (catId.Equals(new ElementId(BuiltInCategory.OST_StructuralColumns)))
            return true;

        // Columnas arquitectónicas
        if (catId.Equals(new ElementId(BuiltInCategory.OST_Columns)))
            return true;

        // Muros
        if (catId.Equals(new ElementId(BuiltInCategory.OST_Walls)))
            return true;

        return false;
    }

    private Outline CrearOutlineDeCara(
        IList<CurveLoop> loops,
        XYZ normal,
        double profundidad,
        double margen)
    {
        try
        {
            List<XYZ> puntos = new List<XYZ>();

            foreach (CurveLoop loop in loops)
            {
                foreach (Curve c in loop)
                {
                    XYZ p0 = c.GetEndPoint(0);
                    XYZ p1 = c.GetEndPoint(1);

                    puntos.Add(p0);
                    puntos.Add(p1);
                    puntos.Add(p0 + normal * profundidad);
                    puntos.Add(p1 + normal * profundidad);
                }
            }

            if (puntos.Count == 0)
                return null;

            double minX = puntos.Min(p => p.X) - margen;
            double minY = puntos.Min(p => p.Y) - margen;
            double minZ = puntos.Min(p => p.Z) - margen;

            double maxX = puntos.Max(p => p.X) + margen;
            double maxY = puntos.Max(p => p.Y) + margen;
            double maxZ = puntos.Max(p => p.Z) + margen;

            return new Outline(
                new XYZ(minX, minY, minZ),
                new XYZ(maxX, maxY, maxZ));
        }
        catch
        {
            return null;
        }
    }

    private List<Solid> ObtenerSolidosElemento(Element elem, View vistaActiva)
    {
        List<Solid> solids = new List<Solid>();

        if (elem == null)
            return solids;

        List<Options> opciones = new List<Options>();

        // V20: primero se toma la geometría que realmente participa en la vista.
        if (vistaActiva != null && !vistaActiva.IsTemplate)
        {
            try
            {
                opciones.Add(new Options()
                {
                    ComputeReferences = false,
                    IncludeNonVisibleObjects = false,
                    DetailLevel = ViewDetailLevel.Fine,
                    View = vistaActiva
                });
            }
            catch
            {
            }
        }

        opciones.Add(new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        });

        foreach (Options opt in opciones)
        {
            GeometryElement geo = null;

            try
            {
                geo = elem.get_Geometry(opt);
            }
            catch
            {
                geo = null;
            }

            if (geo == null)
                continue;

            int antes = solids.Count;

            ExtraerSolidos(
                geo,
                Transform.Identity,
                solids);

            if (solids.Count > antes)
                break;
        }

        return solids;
    }

    // =========================================================
    // V20 - VISIBILIDAD REAL EN LA VISTA ACTIVA
    // =========================================================
    private bool EsElementoVisibleEnVista(Element e, View vista)
    {
        if (e == null)
            return false;

        if (vista == null || vista.IsTemplate)
            return true;

        try
        {
            if (!object.ReferenceEquals(e.Document, vista.Document))
                return true;
        }
        catch
        {
            return true;
        }

        try
        {
            if (e.IsHidden(vista))
                return false;
        }
        catch
        {
        }

        try
        {
            if (e.Category != null && vista.GetCategoryHidden(e.Category.Id))
                return false;
        }
        catch
        {
        }

        try
        {
            if (vista.IsTemporaryHideIsolateActive())
            {
                bool visibleTemporal = vista.IsElementVisibleInTemporaryViewMode(
                    TemporaryViewMode.TemporaryHideIsolate,
                    e.Id);

                if (!visibleTemporal)
                    return false;
            }
        }
        catch
        {
        }

        if (EstaOcultoPorFiltroDeVista(e, vista))
            return false;

        return true;
    }

    private bool EstaOcultoPorFiltroDeVista(Element e, View vista)
    {
        if (e == null || vista == null || vista.IsTemplate)
            return false;

        try
        {
            ICollection<ElementId> filtros = vista.GetFilters();

            if (filtros == null || filtros.Count == 0)
                return false;

            foreach (ElementId idFiltro in filtros)
            {
                if (idFiltro == null || idFiltro == ElementId.InvalidElementId)
                    continue;

                bool visible = true;

                try
                {
                    visible = vista.GetFilterVisibility(idFiltro);
                }
                catch
                {
                    visible = true;
                }

                if (visible)
                    continue;

                Element filtro = vista.Document.GetElement(idFiltro);
                ParameterFilterElement pfe = filtro as ParameterFilterElement;

                if (pfe != null)
                {
                    if (e.Category == null)
                        continue;

                    ICollection<ElementId> categorias = null;

                    try
                    {
                        categorias = pfe.GetCategories();
                    }
                    catch
                    {
                        categorias = null;
                    }

                    if (categorias != null &&
                        categorias.Count > 0 &&
                        !categorias.Any(x => x != null && x.Equals(e.Category.Id)))
                    {
                        continue;
                    }

                    try
                    {
                        ElementFilter filtroReglas = pfe.GetElementFilter();

                        if (filtroReglas != null &&
                            filtroReglas.PassesFilter(e.Document, e.Id))
                        {
                            return true;
                        }
                    }
                    catch
                    {
                    }

                    continue;
                }

                SelectionFilterElement sfe = filtro as SelectionFilterElement;

                if (sfe != null)
                {
                    try
                    {
                        ICollection<ElementId> ids = sfe.GetElementIds();

                        if (ids != null && ids.Any(x => x != null && x.Equals(e.Id)))
                            return true;
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch
        {
        }

        return false;
    }

    private void ExtraerSolidos(
        GeometryElement geo,
        Transform transformActual,
        List<Solid> solids)
    {
        if (geo == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                Solid solidModelo = solid;

                try
                {
                    if (transformActual != null && !transformActual.IsIdentity)
                        solidModelo = SolidUtils.CreateTransformed(solid, transformActual);
                }
                catch
                {
                    solidModelo = solid;
                }

                if (solidModelo != null &&
                    solidModelo.Faces.Size > 0 &&
                    solidModelo.Edges.Size > 0 &&
                    solidModelo.Volume > 0)
                {
                    solids.Add(solidModelo);
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symbolGeo = gi.GetSymbolGeometry();

                if (symbolGeo != null)
                {
                    Transform nuevoTransform =
                        transformActual.Multiply(gi.Transform);

                    ExtraerSolidos(
                        symbolGeo,
                        nuevoTransform,
                        solids);
                }
            }
            catch
            {
                try
                {
                    GeometryElement instanceGeo = gi.GetInstanceGeometry();

                    if (instanceGeo != null)
                    {
                        ExtraerSolidos(
                            instanceGeo,
                            transformActual,
                            solids);
                    }
                }
                catch
                {
                }
            }
        }
    }

    // =====================================
    // V18 - OBTENER CARAS VÁLIDAS EN MODELO
    // Soporta PlanarFace y CylindricalFace.
    // Las transformaciones del vínculo / instancia se hornean en la geometría,
    // por eso las caras se envían luego al motor común con Transform.Identity.
    // =====================================
    private List<Face> ObtenerCarasValidasEnModelo(Element elem)
    {
        return ObtenerCarasValidasEnModelo(elem, Transform.Identity);
    }

    private List<Face> ObtenerCarasValidasEnModelo(Element elem, Transform transformBase)
    {
        List<Face> caras = new List<Face>();
        HashSet<string> keys = new HashSet<string>();

        Options opt = new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return caras;

        ExtraerCarasValidas(
            geo,
            transformBase ?? Transform.Identity,
            caras,
            keys);

        return caras;
    }

    private void ExtraerCarasValidas(
        GeometryElement geo,
        Transform transformActual,
        List<Face> caras,
        HashSet<string> keys)
    {
        if (geo == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                ProcesarSolido(
                    solid,
                    transformActual,
                    caras,
                    keys);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symbolGeo = gi.GetSymbolGeometry();

                if (symbolGeo != null)
                {
                    Transform nuevoTransform =
                        (transformActual ?? Transform.Identity).Multiply(gi.Transform);

                    ExtraerCarasValidas(
                        symbolGeo,
                        nuevoTransform,
                        caras,
                        keys);
                }
            }
            catch
            {
                try
                {
                    GeometryElement instanceGeo = gi.GetInstanceGeometry();

                    if (instanceGeo != null)
                    {
                        ExtraerCarasValidas(
                            instanceGeo,
                            transformActual ?? Transform.Identity,
                            caras,
                            keys);
                    }
                }
                catch
                {
                }
            }
        }
    }

    private void ProcesarSolido(
        Solid solid,
        Transform transformActual,
        List<Face> caras,
        HashSet<string> keys)
    {
        if (solid == null)
            return;

        if (solid.Faces == null || solid.Faces.Size == 0)
            return;

        if (solid.Edges == null || solid.Edges.Size == 0)
            return;

        Solid solidModelo = solid;

        try
        {
            if (transformActual != null && !transformActual.IsIdentity)
                solidModelo = SolidUtils.CreateTransformed(solid, transformActual);
        }
        catch
        {
            solidModelo = solid;
        }

        if (solidModelo == null)
            return;

        foreach (Face face in solidModelo.Faces)
        {
            if (face == null)
                continue;

            if (face.Area <= MinAreaCara)
                continue;

            bool esSoportada =
                face is PlanarFace ||
                face is CylindricalFace;

            if (!esSoportada)
                continue;

            string key = BuildFaceKey(face);

            if (!string.IsNullOrWhiteSpace(key))
            {
                if (keys.Contains(key))
                    continue;

                keys.Add(key);
            }

            caras.Add(face);
        }
    }

    private XYZ ObtenerNormalCara(Face face, Transform transformCara)
    {
        if (face == null)
            return null;

        if (transformCara == null)
            transformCara = Transform.Identity;

        try
        {
            PlanarFace pf = face as PlanarFace;

            if (pf != null)
                return transformCara.OfVector(pf.FaceNormal).Normalize();

            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                XYZ n = face.ComputeNormal(uv);

                if (n != null && n.GetLength() > 1e-9)
                    return transformCara.OfVector(n).Normalize();
            }
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerPuntoReferenciaFace(Face face)
    {
        if (face == null)
            return XYZ.Zero;

        try
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            if (loops != null)
            {
                foreach (CurveLoop loop in loops)
                {
                    foreach (Curve c in loop)
                    {
                        if (c != null)
                            return c.GetEndPoint(0);
                    }
                }
            }
        }
        catch
        {
        }

        try
        {
            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                return face.Evaluate(uv);
            }
        }
        catch
        {
        }

        return XYZ.Zero;
    }

    private string BuildFaceKey(Face face)
    {
        try
        {
            XYZ n = ObtenerNormalCara(face, Transform.Identity);
            XYZ p = ObtenerPuntoReferenciaFace(face);

            if (n == null)
                return null;

            string tipo = face.GetType().Name;

            return tipo + "|" +
                   Math.Round(n.X, 6) + "|" +
                   Math.Round(n.Y, 6) + "|" +
                   Math.Round(n.Z, 6) + "|" +
                   Math.Round(p.X, 6) + "|" +
                   Math.Round(p.Y, 6) + "|" +
                   Math.Round(p.Z, 6) + "|" +
                   Math.Round(face.Area, 6);
        }
        catch
        {
            return null;
        }
    }


    // =====================================
    // V15 - OBTENER ELEMENTOS NATIVOS O DE VÍNCULOS
    // =====================================
    private List<ElementoTrabajo> ObtenerElementosTrabajo(Document doc, IList<Reference> refs)
    {
        List<ElementoTrabajo> resultado = new List<ElementoTrabajo>();

        if (doc == null || refs == null)
            return resultado;

        foreach (Reference r in refs)
        {
            if (r == null)
                continue;

            Element elem = doc.GetElement(r.ElementId);

            if (elem == null)
                continue;

            RevitLinkInstance link = elem as RevitLinkInstance;

            if (link != null)
            {
                if (!ConsiderarVinculos)
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                ElementId linkedId = r.LinkedElementId;

                if (linkedId == ElementId.InvalidElementId)
                    continue;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null)
                    continue;

                if (!CategoriaValida(linkedElem))
                    continue;

                Transform tr = Transform.Identity;

                try
                {
                    tr = link.GetTotalTransform();
                }
                catch
                {
                    tr = Transform.Identity;
                }

                resultado.Add(new ElementoTrabajo()
                {
                    HostElem = link,
                    GeoElem = linkedElem,
                    TransformCara = tr
                });

                continue;
            }

            if (!CategoriaValida(elem))
                continue;

            resultado.Add(new ElementoTrabajo()
            {
                HostElem = elem,
                GeoElem = elem,
                TransformCara = Transform.Identity
            });
        }

        return resultado;
    }

    private bool CategoriaValida(Element elem)
    {
        if (elem == null)
            return false;

        Category cat = null;

        try
        {
            cat = elem.Category;
        }
        catch
        {
            cat = null;
        }

        if (cat == null)
            return false;

        return cat.Id.Equals(new ElementId(BuiltInCategory.OST_StructuralFraming));
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.RestaurarVentana();
                return;
            }
        }
        catch
        {
        }

        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.Show();
                Form.BringToFront();
                Form.Activate();
            }
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Seleccionar Vigas para Tarrajeo";
    }
}


// =====================================
// FILTRO - SOLO VIGAS / ARMAZÓN ESTRUCTURAL
// =====================================
public class VigasTarrajeoSelectionFilter : ISelectionFilter
{
    private readonly Document _doc;
    private readonly bool _considerarVinculos;

    public VigasTarrajeoSelectionFilter() : this(null, false)
    {
    }

    public VigasTarrajeoSelectionFilter(bool considerarVinculos) : this(null, considerarVinculos)
    {
    }

    public VigasTarrajeoSelectionFilter(Document doc, bool considerarVinculos)
    {
        _doc = doc;
        _considerarVinculos = considerarVinculos;
    }

    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        //-------------------------------------------------
        // Si se está seleccionando en vínculo, Revit primero
        // pasa el RevitLinkInstance por AllowElement.
        // Aquí se permite solo para que luego AllowReference
        // valide la categoría REAL del elemento vinculado.
        //-------------------------------------------------
        if (_considerarVinculos && elem is RevitLinkInstance)
            return true;

        return EsCategoriaPermitida(elem);
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        //-------------------------------------------------
        // Para elementos nativos, AllowElement ya filtró.
        //-------------------------------------------------
        if (!_considerarVinculos)
            return true;

        if (_doc == null || reference == null)
            return false;

        try
        {
            RevitLinkInstance link = _doc.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return true;

            ElementId linkedId = reference.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return false;

            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                return false;

            Element linkedElem = linkDoc.GetElement(linkedId);

            return EsCategoriaPermitida(linkedElem);
        }
        catch
        {
            return false;
        }
    }

    private bool EsCategoriaPermitida(Element elem)
    {
        if (elem == null)
            return false;

        if (elem.Category == null)
            return false;

        return elem.Category.Id.Equals(new ElementId(BuiltInCategory.OST_StructuralFraming));
    }
}