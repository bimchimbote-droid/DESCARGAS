﻿// =====================================
// HANDLER V21 - SELECCIONAR LOSAS - VISTA ACTIVA REAL
// - Conserva la transformación real de cada cara.
// - Usa Tarrajeo_MurosHandler V75 para decidir visibilidad real.
// - Si un elemento OCULTO corta la losa por Join Geometry, recupera temporalmente
//   la geometría completa antes de extraer caras y restaura la unión al finalizar.
// - Las caras inferiores/inclinadas usan Tarrajeo_SuelosHandler V29.
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

public class SeleccionarLosasTarrajeoHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoElementosForm Form;

    public FloorType TipoSuelo;
    public WallType TipoMuro;
    public bool PermitirUnion;
    public bool ConsiderarVinculos;

    // Motores comunes de creación.
    // El comando los inyecta para que por ELEMENTOS use la misma lógica que por CARAS.
    public Tarrajeo_MurosHandler CreadorMuros;
    public Tarrajeo_SuelosHandler CreadorSuelos;

    public List<ElementId> ElementosSeleccionados = new List<ElementId>();

    public string RutaUltimoReporte { get; private set; } = string.Empty;

    private const double TolNormalVertical = 0.001;
    private const double TolCaraSuperior = 0.001;
    private const double MinAreaCara = 0.0001;

    private class CaraTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public RevitLinkInstance LinkOrigen;
        public Face Cara;
        public Transform TransformCara;
        public bool CrearComoMuro;
    }

    private class ElementoTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public RevitLinkInstance LinkOrigen;
        public Transform TransformCara;
    }

    private class CaraGeometrica
    {
        public Face Cara;
        public Transform TransformCara;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;
        RutaUltimoReporte = string.Empty;

        List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida> unionesOcultasInvertidas =
            new List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida>();

        try
        {
            //-------------------------------------------------
            // TOMAR DATOS DESDE EL FORMULARIO
            //-------------------------------------------------
            if (Form != null)
            {
                TipoSuelo = Form.TipoSueloSeleccionado;
                TipoMuro = Form.TipoMuroSeleccionado;
                PermitirUnion = Form.PermitirUnion;
                ConsiderarVinculos = Form.ConsiderarVinculos;
            }

            //-------------------------------------------------
            // VALIDAR TIPO DE SUELO O MURO
            //-------------------------------------------------
            if (TipoSuelo == null && TipoMuro == null)
            {
                TaskDialog.Show(
                    "MYG",
                    "Debe seleccionar un tipo de suelo o un tipo de muro.");

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // SELECCIONAR LOSAS / SUELOS
            //-------------------------------------------------
            ObjectType tipoSeleccion = ConsiderarVinculos ? ObjectType.LinkedElement : ObjectType.Element;

            IList<Reference> refs = uidoc.Selection.PickObjects(
                tipoSeleccion,
                new LosasTarrajeoSelectionFilter(doc, ConsiderarVinculos),
                ConsiderarVinculos
                    ? "Seleccione losas de vínculos"
                    : "Seleccione losas");

            if (refs == null || refs.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            List<ElementoTrabajo> elementosTrabajo = ObtenerElementosTrabajo(doc, refs);

            ElementosSeleccionados = elementosTrabajo
                .Where(x => x != null && x.HostElem != null)
                .Select(x => x.HostElem.Id)
                .Distinct()
                .ToList();

            if (elementosTrabajo.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // VISTA ACTIVA REAL - PREPARAR MOTORES ANTES DE LEER CARAS
            //-------------------------------------------------
            Tarrajeo_MurosHandler creadorMuros =
                CreadorMuros ?? new Tarrajeo_MurosHandler();

            Tarrajeo_SuelosHandler creadorSuelos =
                CreadorSuelos ?? new Tarrajeo_SuelosHandler();

            creadorMuros.UiDoc = uidoc;
            creadorSuelos.UiDoc = uidoc;

            creadorMuros.PrepararNuevaEjecucion();
            creadorSuelos.PrepararNuevaEjecucion();

            //-------------------------------------------------
            // IGNORAR SOLO UNIONES DE ELEMENTOS OCULTOS EN LA VISTA ACTIVA
            //-------------------------------------------------
            unionesOcultasInvertidas =
                TarrajeoVistaActivaUnionesHelper
                .InvertirTemporalmenteUnionesOcultasQueCortan(
                    doc,
                    elementosTrabajo
                        .Where(x => x != null && x.GeoElem != null)
                        .Select(x => x.GeoElem),
                    creadorMuros);

            //-------------------------------------------------
            // PREPROCESAR CARAS
            //-------------------------------------------------
            List<CaraTrabajo> carasParaCrear = new List<CaraTrabajo>();

            int losasProcesadas = 0;
            int carasOmitidas = 0;
            int carasSuperioresOmitidas = 0;
            List<string> diagnosticos = new List<string>();

            foreach (ElementoTrabajo et in elementosTrabajo)
            {
                Element elem = et != null ? et.HostElem : null;
                Element geoElem = et != null ? et.GeoElem : null;
                Transform transformCara = et != null && et.TransformCara != null ? et.TransformCara : Transform.Identity;

                if (elem == null || geoElem == null)
                    continue;

                losasProcesadas++;

                List<CaraGeometrica> caras = ObtenerCarasValidasEnModelo(
                    geoElem,
                    transformCara);

                foreach (CaraGeometrica caraGeo in caras)
                {
                    Face cara = caraGeo != null ? caraGeo.Cara : null;
                    Transform transformCaraReal =
                        caraGeo != null && caraGeo.TransformCara != null
                            ? caraGeo.TransformCara
                            : Transform.Identity;

                    if (cara == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    if (cara.Area <= MinAreaCara)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    XYZ normal = ObtenerNormalCara(
                        cara,
                        transformCaraReal);

                    if (normal == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    normal = normal.Normalize();

                    //-------------------------------------------------
                    // OMITIR CARA SUPERIOR
                    // Si normal.Z es positivo, la cara mira hacia arriba.
                    //-------------------------------------------------
                    if (normal.Z > TolCaraSuperior)
                    {
                        carasSuperioresOmitidas++;
                        continue;
                    }

                    //-------------------------------------------------
                    // CARA VERTICAL LATERAL → MURO
                    //-------------------------------------------------
                    if (Math.Abs(normal.Z) < TolNormalVertical)
                    {
                        if (TipoMuro == null)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        carasParaCrear.Add(new CaraTrabajo
                        {
                            HostElem = elem,
                            GeoElem = geoElem,
                            LinkOrigen = et.LinkOrigen,
                            Cara = cara,
                            TransformCara = transformCaraReal,
                            CrearComoMuro = true
                        });

                        continue;
                    }

                    //-------------------------------------------------
                    // CARA INFERIOR O INCLINADA HACIA ABAJO → SUELO
                    //-------------------------------------------------
                    if (TipoSuelo == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    carasParaCrear.Add(new CaraTrabajo
                    {
                        HostElem = elem,
                        GeoElem = geoElem,
                        LinkOrigen = et.LinkOrigen,
                        Cara = cara,
                        TransformCara = transformCaraReal,
                        CrearComoMuro = false
                    });
                }
            }

            if (carasParaCrear.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Tarrajeo por Losas",
                    "No se encontraron caras válidas para crear tarrajeo.\n\n" +
                    "Losas procesadas: " + losasProcesadas + "\n" +
                    "Caras superiores omitidas: " + carasSuperioresOmitidas + "\n" +
                    "Caras omitidas: " + carasOmitidas);

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // CREAR TARRAJEO
            //-------------------------------------------------
            int murosCreados = 0;
            int suelosCreados = 0;

            foreach (CaraTrabajo item in carasParaCrear)
            {
                if (item == null || item.HostElem == null || item.Cara == null)
                {
                    carasOmitidas++;
                    continue;
                }

                //-------------------------------------------------
                // MISMA LÓGICA QUE TARRAJEO POR CARA:
                // Cara vertical -> motor común de muros.
                // Cara inferior/inclinada -> motor común de suelos.
                //-------------------------------------------------
                if (item.CrearComoMuro)
                {
                    creadorMuros.ConfigurarOrigenDeRecorte(
                        item.GeoElem ?? item.HostElem,
                        item.LinkOrigen);

                    List<Wall> murosNuevos = creadorMuros.CrearMurosDesdeFaceProcesada(
                        doc,
                        uidoc,
                        item.HostElem,
                        item.Cara,
                        item.TransformCara ?? Transform.Identity,
                        TipoMuro,
                        PermitirUnion);

                    if (murosNuevos != null && murosNuevos.Count > 0)
                        murosCreados += murosNuevos.Count;
                    else
                        carasOmitidas++;

                    continue;
                }

                PlanarFace caraPlanaSuelo = item.Cara as PlanarFace;

                if (caraPlanaSuelo == null)
                {
                    carasOmitidas++;
                    diagnosticos.Add(
                        ConstruirDiagnosticoCara(
                            item,
                            "La cara inferior no es PlanarFace y el motor de suelos no puede crearla."));
                    continue;
                }

                creadorSuelos.ConfigurarOrigenDeRecorte(
                    item.GeoElem ?? item.HostElem,
                    item.LinkOrigen);

                bool creadoSuelo = creadorSuelos.CrearSueloDesdeCaraPlanarProcesada(
                    doc,
                    uidoc,
                    item.HostElem,
                    caraPlanaSuelo,
                    item.TransformCara ?? Transform.Identity,
                    TipoSuelo);

                if (creadoSuelo)
                {
                    suelosCreados++;
                }
                else
                {
                    carasOmitidas++;

                    string detalle =
                        string.IsNullOrWhiteSpace(creadorSuelos.UltimoDiagnostico)
                            ? "El motor de suelos devolvió false sin diagnóstico."
                            : creadorSuelos.UltimoDiagnostico;

                    diagnosticos.Add(
                        ConstruirDiagnosticoCara(
                            item,
                            detalle));
                }
            }

            //-------------------------------------------------
            // V20 - DIAGNÓSTICO SILENCIOSO EN ARCHIVO
            // No abre TaskDialog al terminar el lote.
            //-------------------------------------------------
            if (diagnosticos.Count > 0)
            {
                RutaUltimoReporte = GuardarDiagnosticosEnArchivo(
                    losasProcesadas,
                    murosCreados,
                    suelosCreados,
                    carasOmitidas,
                    carasSuperioresOmitidas,
                    diagnosticos);
            }

            MostrarFormulario();
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarFormulario();
        }
        catch (Exception ex)
        {
            RutaUltimoReporte = GuardarErrorGeneralEnArchivo(ex);
            MostrarFormulario();
        }
        finally
        {
            TarrajeoVistaActivaUnionesHelper
                .RestaurarUnionesOcultasInvertidas(
                    doc,
                    unionesOcultasInvertidas);
        }
    }

    // =====================================
    // V19 - OBTENER CARAS SIN HORNEAR LA TRANSFORMACIÓN
    //
    // La Face se conserva en las coordenadas de su documento de origen
    // y se guarda, junto a ella, la transformación acumulada hacia el
    // documento anfitrión. Esto evita:
    // - transformar el sólido y perder estabilidad geométrica;
    // - aplicar dos veces la transformación del vínculo;
    // - enviar una cara local con Transform.Identity por error.
    // =====================================
    private List<CaraGeometrica> ObtenerCarasValidasEnModelo(Element elem)
    {
        return ObtenerCarasValidasEnModelo(
            elem,
            Transform.Identity);
    }

    private List<CaraGeometrica> ObtenerCarasValidasEnModelo(
        Element elem,
        Transform transformBase)
    {
        List<CaraGeometrica> caras =
            new List<CaraGeometrica>();

        HashSet<string> keys =
            new HashSet<string>();

        if (elem == null)
            return caras;

        Options opt = new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return caras;

        ExtraerCarasValidas(
            geo,
            transformBase ?? Transform.Identity,
            caras,
            keys);

        return caras;
    }

    private void ExtraerCarasValidas(
        GeometryElement geo,
        Transform transformActual,
        List<CaraGeometrica> caras,
        HashSet<string> keys)
    {
        if (geo == null ||
            caras == null ||
            keys == null)
        {
            return;
        }

        Transform tr =
            transformActual ?? Transform.Identity;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                ProcesarSolido(
                    solid,
                    tr,
                    caras,
                    keys);

                continue;
            }

            GeometryInstance gi =
                obj as GeometryInstance;

            if (gi == null)
                continue;

            bool procesado = false;

            //-------------------------------------------------
            // SymbolGeometry está en coordenadas locales de la instancia.
            // Se acumula gi.Transform una sola vez.
            //-------------------------------------------------
            try
            {
                GeometryElement symbolGeo =
                    gi.GetSymbolGeometry();

                if (symbolGeo != null)
                {
                    Transform nuevoTransform =
                        tr.Multiply(gi.Transform);

                    ExtraerCarasValidas(
                        symbolGeo,
                        nuevoTransform,
                        caras,
                        keys);

                    procesado = true;
                }
            }
            catch
            {
                procesado = false;
            }

            if (procesado)
                continue;

            //-------------------------------------------------
            // InstanceGeometry ya incorpora gi.Transform respecto del padre.
            // Por eso se conserva únicamente la transformación acumulada
            // anterior, que incluye la del vínculo cuando corresponde.
            //-------------------------------------------------
            try
            {
                GeometryElement instanceGeo =
                    gi.GetInstanceGeometry();

                if (instanceGeo != null)
                {
                    ExtraerCarasValidas(
                        instanceGeo,
                        tr,
                        caras,
                        keys);
                }
            }
            catch
            {
            }
        }
    }

    private void ProcesarSolido(
        Solid solid,
        Transform transformActual,
        List<CaraGeometrica> caras,
        HashSet<string> keys)
    {
        if (solid == null ||
            caras == null ||
            keys == null)
        {
            return;
        }

        if (solid.Faces == null ||
            solid.Faces.Size == 0)
        {
            return;
        }

        if (solid.Edges == null ||
            solid.Edges.Size == 0)
        {
            return;
        }

        Transform tr =
            transformActual ?? Transform.Identity;

        foreach (Face face in solid.Faces)
        {
            if (face == null)
                continue;

            if (face.Area <= MinAreaCara)
                continue;

            bool esSoportada =
                face is PlanarFace ||
                face is CylindricalFace;

            if (!esSoportada)
                continue;

            string key =
                BuildFaceKey(
                    face,
                    tr);

            if (!string.IsNullOrWhiteSpace(key))
            {
                if (keys.Contains(key))
                    continue;

                keys.Add(key);
            }

            caras.Add(
                new CaraGeometrica()
                {
                    Cara = face,
                    TransformCara = tr
                });
        }
    }

    private XYZ ObtenerNormalCara(Face face, Transform transformCara)
    {
        if (face == null)
            return null;

        if (transformCara == null)
            transformCara = Transform.Identity;

        try
        {
            PlanarFace pf = face as PlanarFace;

            if (pf != null)
                return transformCara.OfVector(pf.FaceNormal).Normalize();

            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                XYZ n = face.ComputeNormal(uv);

                if (n != null && n.GetLength() > 1e-9)
                    return transformCara.OfVector(n).Normalize();
            }
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerPuntoReferenciaFace(
        Face face,
        Transform transformCara)
    {
        if (face == null)
            return XYZ.Zero;

        Transform tr =
            transformCara ?? Transform.Identity;

        try
        {
            IList<CurveLoop> loops =
                face.GetEdgesAsCurveLoops();

            if (loops != null)
            {
                foreach (CurveLoop loop in loops)
                {
                    foreach (Curve c in loop)
                    {
                        if (c != null)
                            return tr.OfPoint(c.GetEndPoint(0));
                    }
                }
            }
        }
        catch
        {
        }

        try
        {
            BoundingBoxUV bb =
                face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                return tr.OfPoint(
                    face.Evaluate(uv));
            }
        }
        catch
        {
        }

        return XYZ.Zero;
    }

    private string BuildFaceKey(
        Face face,
        Transform transformCara)
    {
        try
        {
            Transform tr =
                transformCara ?? Transform.Identity;

            XYZ n =
                ObtenerNormalCara(
                    face,
                    tr);

            XYZ p =
                ObtenerPuntoReferenciaFace(
                    face,
                    tr);

            if (n == null)
                return null;

            string tipo =
                face.GetType().Name;

            return tipo + "|" +
                   Math.Round(n.X, 6) + "|" +
                   Math.Round(n.Y, 6) + "|" +
                   Math.Round(n.Z, 6) + "|" +
                   Math.Round(p.X, 6) + "|" +
                   Math.Round(p.Y, 6) + "|" +
                   Math.Round(p.Z, 6) + "|" +
                   Math.Round(face.Area, 6);
        }
        catch
        {
            return null;
        }
    }


    // =====================================
    // V15 - OBTENER ELEMENTOS NATIVOS O DE VÍNCULOS
    // =====================================
    private List<ElementoTrabajo> ObtenerElementosTrabajo(Document doc, IList<Reference> refs)
    {
        List<ElementoTrabajo> resultado = new List<ElementoTrabajo>();

        if (doc == null || refs == null)
            return resultado;

        foreach (Reference r in refs)
        {
            if (r == null)
                continue;

            Element elem = doc.GetElement(r.ElementId);

            if (elem == null)
                continue;

            RevitLinkInstance link = elem as RevitLinkInstance;

            if (link != null)
            {
                if (!ConsiderarVinculos)
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                ElementId linkedId = r.LinkedElementId;

                if (linkedId == ElementId.InvalidElementId)
                    continue;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null)
                    continue;

                if (!CategoriaValida(linkedElem))
                    continue;

                Transform tr = Transform.Identity;

                try
                {
                    tr = link.GetTotalTransform();
                }
                catch
                {
                    tr = Transform.Identity;
                }

                resultado.Add(new ElementoTrabajo()
                {
                    HostElem = link,
                    GeoElem = linkedElem,
                    LinkOrigen = link,
                    TransformCara = tr
                });

                continue;
            }

            if (!CategoriaValida(elem))
                continue;

            resultado.Add(new ElementoTrabajo()
            {
                HostElem = elem,
                GeoElem = elem,
                LinkOrigen = null,
                TransformCara = Transform.Identity
            });
        }

        return resultado;
    }

    private bool CategoriaValida(Element elem)
    {
        if (elem == null)
            return false;

        Category cat = null;

        try
        {
            cat = elem.Category;
        }
        catch
        {
            cat = null;
        }

        if (cat == null)
            return false;

        return cat.Id.Equals(new ElementId(BuiltInCategory.OST_Floors));
    }

    private string ConstruirDiagnosticoCara(
        CaraTrabajo item,
        string detalle)
    {
        try
        {
            string origen = "Elemento nativo";
            string idElemento = "N/D";
            string categoria = "Sin categoría";
            double area = 0.0;
            double normalZ = 0.0;

            if (item != null)
            {
                Element geoElem =
                    item.GeoElem ?? item.HostElem;

                if (geoElem != null)
                {
                    idElemento =
                        geoElem.Id.ToString();

                    if (geoElem.Category != null)
                        categoria = geoElem.Category.Name;
                }

                if (item.LinkOrigen != null)
                {
                    origen =
                        "Vínculo: " +
                        item.LinkOrigen.Name;
                }

                if (item.Cara != null)
                {
                    area = item.Cara.Area;

                    XYZ normal =
                        ObtenerNormalCara(
                            item.Cara,
                            item.TransformCara ?? Transform.Identity);

                    if (normal != null)
                        normalZ = normal.Z;
                }
            }

            return
                origen +
                " | Elemento: " + idElemento +
                " | Categoría: " + categoria +
                " | Área cara: " + area.ToString("0.0000") +
                " ft² | Normal.Z: " + normalZ.ToString("0.000000") +
                "\n" +
                detalle;
        }
        catch
        {
            return detalle;
        }
    }

    private string GuardarDiagnosticosEnArchivo(
        int losasProcesadas,
        int murosCreados,
        int suelosCreados,
        int carasOmitidas,
        int carasSuperioresOmitidas,
        List<string> diagnosticos)
    {
        try
        {
            if (diagnosticos == null || diagnosticos.Count == 0)
                return string.Empty;

            string ruta = Path.Combine(
                Path.GetTempPath(),
                "MYG_Tarrajeo_Losas_Diagnostico.log");

            StringBuilder sb = new StringBuilder();
            sb.AppendLine();
            sb.AppendLine(new string('=', 100));
            sb.AppendLine("MYG - DIAGNÓSTICO TARRAJEO POR LOSAS");
            sb.AppendLine("Fecha: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Losas procesadas: " + losasProcesadas);
            sb.AppendLine("Muros creados: " + murosCreados);
            sb.AppendLine("Suelos creados: " + suelosCreados);
            sb.AppendLine("Caras superiores omitidas: " + carasSuperioresOmitidas);
            sb.AppendLine("Caras omitidas: " + carasOmitidas);
            sb.AppendLine();

            for (int i = 0; i < diagnosticos.Count; i++)
            {
                sb.AppendLine("CASO " + (i + 1));
                sb.AppendLine(diagnosticos[i]);
                sb.AppendLine();
            }

            File.AppendAllText(ruta, sb.ToString());
            return ruta;
        }
        catch
        {
            return string.Empty;
        }
    }

    private string GuardarErrorGeneralEnArchivo(Exception ex)
    {
        try
        {
            string ruta = Path.Combine(
                Path.GetTempPath(),
                "MYG_Tarrajeo_Losas_Diagnostico.log");

            string texto =
                Environment.NewLine +
                "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " +
                "ERROR GENERAL EN TARRAJEO POR LOSAS" +
                Environment.NewLine +
                (ex == null
                    ? "Excepción no disponible."
                    : ex.GetType().Name + " - " + ex.Message) +
                Environment.NewLine +
                new string('-', 100) +
                Environment.NewLine;

            File.AppendAllText(ruta, texto);
            return ruta;
        }
        catch
        {
            return string.Empty;
        }
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.RestaurarVentana();
                return;
            }
        }
        catch
        {
        }

        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.Show();
                Form.BringToFront();
                Form.Activate();
            }
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Seleccionar Losas para Tarrajeo V20";
    }
}


// =====================================
// FILTRO - SOLO LOSAS / SUELOS
// =====================================
public class LosasTarrajeoSelectionFilter : ISelectionFilter
{
    private readonly Document _doc;
    private readonly bool _considerarVinculos;

    public LosasTarrajeoSelectionFilter() : this(null, false)
    {
    }

    public LosasTarrajeoSelectionFilter(bool considerarVinculos) : this(null, considerarVinculos)
    {
    }

    public LosasTarrajeoSelectionFilter(Document doc, bool considerarVinculos)
    {
        _doc = doc;
        _considerarVinculos = considerarVinculos;
    }

    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        //-------------------------------------------------
        // Si se está seleccionando en vínculo, Revit primero
        // pasa el RevitLinkInstance por AllowElement.
        // Aquí se permite solo para que luego AllowReference
        // valide la categoría REAL del elemento vinculado.
        //-------------------------------------------------
        if (_considerarVinculos && elem is RevitLinkInstance)
            return true;

        return EsCategoriaPermitida(elem);
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        //-------------------------------------------------
        // Para elementos nativos, AllowElement ya filtró.
        //-------------------------------------------------
        if (!_considerarVinculos)
            return true;

        if (_doc == null || reference == null)
            return false;

        try
        {
            RevitLinkInstance link = _doc.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return true;

            ElementId linkedId = reference.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return false;

            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                return false;

            Element linkedElem = linkDoc.GetElement(linkedId);

            return EsCategoriaPermitida(linkedElem);
        }
        catch
        {
            return false;
        }
    }

    private bool EsCategoriaPermitida(Element elem)
    {
        if (elem == null)
            return false;

        if (elem.Category == null)
            return false;

        return elem.Category.Id.Equals(new ElementId(BuiltInCategory.OST_Floors));
    }
}