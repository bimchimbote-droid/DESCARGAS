using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA PREVIA - MYG TARRAJEO
    // =====================================
    public class TarrajeoMenuForm : WinForms.Form
    {
        public TarrajeoForm FormTarrajeo;
        public TarrajeoElementosForm FormTarrajeoElementos;

        public TarrajeoMenuForm(
            TarrajeoForm formTarrajeo,
            TarrajeoElementosForm formTarrajeoElementos)
        {
            FormTarrajeo = formTarrajeo;
            FormTarrajeoElementos = formTarrajeoElementos;

            // ===== COLORES BASE =====
            Drawing.Color colorFondo = Drawing.Color.FromArgb(248, 249, 251);
            Drawing.Color colorTarjeta = Drawing.Color.White;
            Drawing.Color colorTextoPrincipal = Drawing.Color.FromArgb(32, 33, 36);
            Drawing.Color colorTextoSecundario = Drawing.Color.FromArgb(95, 99, 104);
            Drawing.Color colorBorde = Drawing.Color.FromArgb(225, 229, 235);
            Drawing.Color colorAzul = Drawing.Color.FromArgb(33, 115, 229);
            Drawing.Color colorAzulHover = Drawing.Color.FromArgb(20, 95, 200);
            Drawing.Color colorAzulDown = Drawing.Color.FromArgb(18, 80, 170);

            this.Text = "MYG - Tarrajeo";
            this.Width = 420;
            this.Height = 315;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = colorFondo;
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // ===== ENCABEZADO =====
            var lblTitulo = new WinForms.Label()
            {
                Text = "MYG – Tarrajeo",
                Left = 24,
                Top = 22,
                Width = 350,
                Height = 26,
                Font = new Drawing.Font("Segoe UI", 12F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorFondo
            };

            var lblSubtitulo = new WinForms.Label()
            {
                Text = "Seleccione el método de creación",
                Left = 24,
                Top = 50,
                Width = 350,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Regular),
                ForeColor = colorTextoSecundario,
                BackColor = colorFondo
            };

            // ===== TARJETA =====
            var pnlContenido = new WinForms.Panel()
            {
                Left = 22,
                Top = 86,
                Width = 360,
                Height = 140,
                BackColor = colorTarjeta,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            var lblMetodo = new WinForms.Label()
            {
                Text = "Métodos disponibles",
                Left = 18,
                Top = 12,
                Width = 300,
                Height = 18,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoSecundario,
                BackColor = colorTarjeta
            };

            var linea = new WinForms.Panel()
            {
                Left = 18,
                Top = 35,
                Width = 322,
                Height = 1,
                BackColor = colorBorde
            };

            // ===== BOTÓN TARRAJEO POR CARAS =====
            var btnTarrajeoPorCaras = new WinForms.Button()
            {
                Text = "Tarrajeo por caras",
                Width = 322,
                Height = 36,
                Left = 18,
                Top = 48,
                BackColor = colorAzul,
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9.2F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnTarrajeoPorCaras.FlatAppearance.BorderSize = 0;
            btnTarrajeoPorCaras.FlatAppearance.MouseOverBackColor = colorAzulHover;
            btnTarrajeoPorCaras.FlatAppearance.MouseDownBackColor = colorAzulDown;

            btnTarrajeoPorCaras.Click += (s, e) =>
            {
                MYG_TarrajeoUI.MinimizarTodo(this, FormTarrajeoElementos);

                if (FormTarrajeo != null)
                {
                    FormTarrajeo.StartPosition = WinForms.FormStartPosition.CenterScreen;
                    FormTarrajeo.RestaurarVentana();
                }
            };

            // ===== BOTÓN TARRAJEO POR ELEMENTOS =====
            var btnTarrajeoPorElementos = new WinForms.Button()
            {
                Text = "Tarrajeo por Elementos",
                Width = 322,
                Height = 36,
                Left = 18,
                Top = 92,
                BackColor = colorAzul,
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9.2F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnTarrajeoPorElementos.FlatAppearance.BorderSize = 0;
            btnTarrajeoPorElementos.FlatAppearance.MouseOverBackColor = colorAzulHover;
            btnTarrajeoPorElementos.FlatAppearance.MouseDownBackColor = colorAzulDown;

            btnTarrajeoPorElementos.Click += (s, e) =>
            {
                MYG_TarrajeoUI.MinimizarTodo(this, FormTarrajeo);

                if (FormTarrajeoElementos != null)
                {
                    FormTarrajeoElementos.StartPosition = WinForms.FormStartPosition.CenterScreen;
                    FormTarrajeoElementos.RestaurarVentana();
                }
            };

            // ===== AUTOR / PIE =====
            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila",
                Left = 24,
                Top = 245,
                Width = 350,
                Height = 18,
                Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Regular),
                ForeColor = colorTextoSecundario,
                BackColor = colorFondo,
                TextAlign = Drawing.ContentAlignment.MiddleCenter
            };

            // ===== AGREGAR CONTROLES =====
            pnlContenido.Controls.Add(lblMetodo);
            pnlContenido.Controls.Add(linea);
            pnlContenido.Controls.Add(btnTarrajeoPorCaras);
            pnlContenido.Controls.Add(btnTarrajeoPorElementos);

            Controls.Add(lblTitulo);
            Controls.Add(lblSubtitulo);
            Controls.Add(pnlContenido);
            Controls.Add(lblAutor);
        }
    }

}
