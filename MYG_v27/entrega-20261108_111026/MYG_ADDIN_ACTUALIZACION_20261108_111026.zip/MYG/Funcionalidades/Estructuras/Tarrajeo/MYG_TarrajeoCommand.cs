using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ===============================
    // COMANDO (MYG TARRAJEO) - LÓGICA COMÚN
    // ===============================


    [Transaction(TransactionMode.Manual)]
    public class MYG_TarrajeoCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null)
            {
                TaskDialog.Show("MYG", "No se encontró el documento activo.");
                return Result.Cancelled;
            }

            Document doc = uidoc.Document;

            try
            {
                //-------------------------------------------------
                // CREAR FORM PRINCIPAL - TARRAJEO POR CARAS
                //-------------------------------------------------
                TarrajeoForm form = new TarrajeoForm();

                //-------------------------------------------------
                // CREAR FORM - TARRAJEO POR ELEMENTOS
                //-------------------------------------------------
                TarrajeoElementosForm formElementos = new TarrajeoElementosForm();

                //-------------------------------------------------
                // OBTENER TIPOS DE SUELO DEL PROYECTO
                //-------------------------------------------------
                List<FloorType> floorTypes = new FilteredElementCollector(doc)
                    .OfClass(typeof(FloorType))
                    .Cast<FloorType>()
                    .Where(ft => !ft.IsFoundationSlab)
                    .OrderBy(ft => ft.Name)
                    .ToList();

                //-------------------------------------------------
                // OBTENER TIPOS DE MURO DEL PROYECTO
                //-------------------------------------------------
                List<WallType> wallTypes = new FilteredElementCollector(doc)
                    .OfClass(typeof(WallType))
                    .Cast<WallType>()
                    .Where(wt => wt.Kind == WallKind.Basic)
                    .OrderBy(wt => wt.Name)
                    .ToList();

                //-------------------------------------------------
                // LLENAR COMBOS - FORM TARRAJEO POR CARAS
                //-------------------------------------------------
                form.cmbTiposSuelo.Items.Clear();
                form.cmbTiposMuro.Items.Clear();

                form.cmbTiposSuelo.Items.AddRange(floorTypes.ToArray());
                form.cmbTiposMuro.Items.AddRange(wallTypes.ToArray());

                //-------------------------------------------------
                // LLENAR COMBOS - FORM TARRAJEO POR ELEMENTOS
                //-------------------------------------------------
                formElementos.cmbTiposSuelo.Items.Clear();
                formElementos.cmbTiposMuro.Items.Clear();

                formElementos.cmbTiposSuelo.Items.AddRange(floorTypes.ToArray());
                formElementos.cmbTiposMuro.Items.AddRange(wallTypes.ToArray());

                //-------------------------------------------------
                // SELECCIONAR POR DEFECTO EL PRIMER TIPO DISPONIBLE
                //-------------------------------------------------
                if (form.cmbTiposSuelo.Items.Count > 0)
                    form.cmbTiposSuelo.SelectedIndex = 0;

                if (form.cmbTiposMuro.Items.Count > 0)
                    form.cmbTiposMuro.SelectedIndex = 0;

                if (formElementos.cmbTiposSuelo.Items.Count > 0)
                    formElementos.cmbTiposSuelo.SelectedIndex = 0;

                if (formElementos.cmbTiposMuro.Items.Count > 0)
                    formElementos.cmbTiposMuro.SelectedIndex = 0;

                //=================================================
                // MOTORES / CREADORES COMUNES
                //=================================================
                // Estos son los mismos handlers que deben crear muros y suelos
                // tanto por selección de CARAS como por selección de ELEMENTOS.
                //=================================================

                //-------------------------------------------------
                // CREADOR COMÚN DE SUELOS
                //-------------------------------------------------
                var creadorSuelo = new Tarrajeo_SuelosHandler();
                creadorSuelo.UiDoc = uidoc;
                creadorSuelo.Form = form;

                //-------------------------------------------------
                // CREADOR COMÚN DE MUROS
                //-------------------------------------------------
                var creadorMuro = new Tarrajeo_MurosHandler();
                creadorMuro.UiDoc = uidoc;
                creadorMuro.Form = form;

                //-------------------------------------------------
                // EVENTOS DE CREACIÓN POR CARA
                //-------------------------------------------------
                ExternalEvent eventoSuelo = ExternalEvent.Create(creadorSuelo);
                ExternalEvent eventoMuro = ExternalEvent.Create(creadorMuro);

                //-------------------------------------------------
                // SELECTOR POR CARA
                //-------------------------------------------------
                var selectorHandler = new SeleccionarCarasHandler();
                selectorHandler.Form = form;
                selectorHandler.HandlerSuelo = creadorSuelo;
                selectorHandler.HandlerMuro = creadorMuro;
                selectorHandler.EventoSuelo = eventoSuelo;
                selectorHandler.EventoMuro = eventoMuro;

                ExternalEvent eventoSeleccion = ExternalEvent.Create(selectorHandler);

                //-------------------------------------------------
                // RELANZAR SELECCIÓN POR CARA
                //-------------------------------------------------
                creadorSuelo.SeleccionarEvent = eventoSeleccion;
                creadorMuro.SeleccionarEvent = eventoSeleccion;

                //-------------------------------------------------
                // PASAR AL FORM PRINCIPAL - POR CARAS
                //-------------------------------------------------
                form.Handler = selectorHandler;
                form.SeleccionarEvent = eventoSeleccion;

                //=================================================
                // TARRAJEO POR ELEMENTOS
                //=================================================
                // Estos handlers NO deben crear muros/suelos con lógica propia.
                // Su trabajo debe ser:
                // 1) seleccionar elementos,
                // 2) detectar caras,
                // 3) si la cara es vertical => llamar a CreadorMuros,
                // 4) si la cara es horizontal/inclinada => llamar a CreadorSuelos.
                //=================================================

                //=================================================
                // VIGAS
                //=================================================
                var handlerVigas = new SeleccionarVigasTarrajeoHandler();
                handlerVigas.UiDoc = uidoc;
                handlerVigas.Form = formElementos;
                handlerVigas.TipoSuelo = formElementos.TipoSueloSeleccionado;
                handlerVigas.TipoMuro = formElementos.TipoMuroSeleccionado;
                handlerVigas.PermitirUnion = formElementos.PermitirUnion;

                ConectarCreadoresComunes(handlerVigas, creadorMuro, creadorSuelo);

                ExternalEvent eventoVigas = ExternalEvent.Create(handlerVigas);

                //=================================================
                // COLUMNAS
                //=================================================
                var handlerColumnas = new SeleccionarColumnasTarrajeoHandler();
                handlerColumnas.UiDoc = uidoc;
                handlerColumnas.Form = formElementos;
                handlerColumnas.TipoMuro = formElementos.TipoMuroSeleccionado;
                handlerColumnas.PermitirUnion = formElementos.PermitirUnion;

                ConectarCreadoresComunes(handlerColumnas, creadorMuro, creadorSuelo);

                ExternalEvent eventoColumnas = ExternalEvent.Create(handlerColumnas);

                //=================================================
                // MUROS
                //=================================================
                var handlerMuros = new SeleccionarMurosTarrajeoHandler();
                handlerMuros.UiDoc = uidoc;
                handlerMuros.Form = formElementos;
                handlerMuros.TipoSuelo = formElementos.TipoSueloSeleccionado;
                handlerMuros.TipoMuro = formElementos.TipoMuroSeleccionado;
                handlerMuros.PermitirUnion = formElementos.PermitirUnion;

                ConectarCreadoresComunes(handlerMuros, creadorMuro, creadorSuelo);

                ExternalEvent eventoMuros = ExternalEvent.Create(handlerMuros);

                //=================================================
                // CIMENTACIÓN
                //=================================================
                var handlerCimentacion = new SeleccionarCimentacionTarrajeoHandler();
                handlerCimentacion.UiDoc = uidoc;
                handlerCimentacion.Form = formElementos;
                handlerCimentacion.TipoMuro = formElementos.TipoMuroSeleccionado;
                handlerCimentacion.PermitirUnion = formElementos.PermitirUnion;

                ConectarCreadoresComunes(handlerCimentacion, creadorMuro, creadorSuelo);

                ExternalEvent eventoCimentacion = ExternalEvent.Create(handlerCimentacion);

                //=================================================
                // LOSAS
                //=================================================
                var handlerLosas = new SeleccionarLosasTarrajeoHandler();
                handlerLosas.UiDoc = uidoc;
                handlerLosas.Form = formElementos;
                handlerLosas.TipoSuelo = formElementos.TipoSueloSeleccionado;
                handlerLosas.TipoMuro = formElementos.TipoMuroSeleccionado;
                handlerLosas.PermitirUnion = formElementos.PermitirUnion;

                ConectarCreadoresComunes(handlerLosas, creadorMuro, creadorSuelo);

                ExternalEvent eventoLosas = ExternalEvent.Create(handlerLosas);

                //=================================================
                // ESCALERAS
                //=================================================
                var handlerEscaleras = new SeleccionarEscalerasTarrajeoHandler();
                handlerEscaleras.UiDoc = uidoc;
                handlerEscaleras.Form = formElementos;
                handlerEscaleras.TipoSuelo = formElementos.TipoSueloSeleccionado;
                handlerEscaleras.TipoMuro = formElementos.TipoMuroSeleccionado;
                handlerEscaleras.PermitirUnion = formElementos.PermitirUnion;

                ConectarCreadoresComunes(handlerEscaleras, creadorMuro, creadorSuelo);

                ExternalEvent eventoEscaleras = ExternalEvent.Create(handlerEscaleras);

                //-------------------------------------------------
                // PASAR HANDLERS AL FORM DE ELEMENTOS
                //-------------------------------------------------
                formElementos.HandlerVigas = handlerVigas;
                formElementos.HandlerColumnas = handlerColumnas;
                formElementos.HandlerMuros = handlerMuros;
                formElementos.HandlerCimentacion = handlerCimentacion;
                formElementos.HandlerLosas = handlerLosas;
                formElementos.HandlerEscaleras = handlerEscaleras;

                //-------------------------------------------------
                // PASAR EVENTOS AL FORM DE ELEMENTOS
                //-------------------------------------------------
                formElementos.SeleccionarVigasEvent = eventoVigas;
                formElementos.SeleccionarColumnasEvent = eventoColumnas;
                formElementos.SeleccionarMurosEvent = eventoMuros;
                formElementos.SeleccionarCimentacionEvent = eventoCimentacion;
                formElementos.SeleccionarLosasEvent = eventoLosas;
                formElementos.SeleccionarEscalerasEvent = eventoEscaleras;

                //-------------------------------------------------
                // MOSTRAR VENTANA PREVIA
                //-------------------------------------------------
                TarrajeoMenuForm menu = new TarrajeoMenuForm(form, formElementos);
                menu.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;

                TaskDialog.Show(
                    "MYG - Error",
                    "Ocurrió un error al iniciar Tarrajeo / Encofrado:\n\n" + ex.Message);

                return Result.Failed;
            }
        }

        // =========================================================
        // CONEXIÓN DE MOTORES COMUNES POR REFLEXIÓN
        // =========================================================
        // Esto evita romper compilación si uno de los handlers todavía no tiene
        // la propiedad/campo público CreadorMuros o CreadorSuelos.
        //
        // Pero para que el flujo por ELEMENTOS realmente use la misma lógica,
        // tus handlers por elementos sí deben llamar a estos campos/propiedades.
        // =========================================================

        private static void ConectarCreadoresComunes(
            object handlerElementos,
            Tarrajeo_MurosHandler creadorMuros,
            Tarrajeo_SuelosHandler creadorSuelos)
        {
            if (handlerElementos == null)
                return;

            //-------------------------------------------------
            // Nombres recomendados
            //-------------------------------------------------
            AsignarMiembroSiExiste(handlerElementos, "CreadorMuros", creadorMuros);
            AsignarMiembroSiExiste(handlerElementos, "CreadorMuro", creadorMuros);
            AsignarMiembroSiExiste(handlerElementos, "MotorMuros", creadorMuros);
            AsignarMiembroSiExiste(handlerElementos, "MotorMuro", creadorMuros);
            AsignarMiembroSiExiste(handlerElementos, "HandlerMuroComun", creadorMuros);
            AsignarMiembroSiExiste(handlerElementos, "HandlerMurosComun", creadorMuros);

            AsignarMiembroSiExiste(handlerElementos, "CreadorSuelos", creadorSuelos);
            AsignarMiembroSiExiste(handlerElementos, "CreadorSuelo", creadorSuelos);
            AsignarMiembroSiExiste(handlerElementos, "MotorSuelos", creadorSuelos);
            AsignarMiembroSiExiste(handlerElementos, "MotorSuelo", creadorSuelos);
            AsignarMiembroSiExiste(handlerElementos, "HandlerSueloComun", creadorSuelos);
            AsignarMiembroSiExiste(handlerElementos, "HandlerSuelosComun", creadorSuelos);
        }

        private static bool AsignarMiembroSiExiste<T>(
            object target,
            string nombre,
            T valor)
            where T : class
        {
            if (target == null || string.IsNullOrWhiteSpace(nombre) || valor == null)
                return false;

            Type tipoTarget = target.GetType();
            Type tipoValor = typeof(T);

            //-------------------------------------------------
            // PROPIEDAD PÚBLICA
            //-------------------------------------------------
            try
            {
                PropertyInfo prop = tipoTarget.GetProperty(
                    nombre,
                    BindingFlags.Public | BindingFlags.Instance);

                if (prop != null && prop.CanWrite)
                {
                    if (prop.PropertyType.IsAssignableFrom(tipoValor))
                    {
                        prop.SetValue(target, valor, null);
                        return true;
                    }
                }
            }
            catch
            {
            }

            //-------------------------------------------------
            // CAMPO PÚBLICO
            //-------------------------------------------------
            try
            {
                FieldInfo field = tipoTarget.GetField(
                    nombre,
                    BindingFlags.Public | BindingFlags.Instance);

                if (field != null)
                {
                    if (field.FieldType.IsAssignableFrom(tipoValor))
                    {
                        field.SetValue(target, valor);
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }
    }

}
