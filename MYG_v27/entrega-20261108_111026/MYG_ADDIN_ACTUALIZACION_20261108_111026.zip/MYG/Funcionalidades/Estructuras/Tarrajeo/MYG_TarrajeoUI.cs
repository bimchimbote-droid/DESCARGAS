using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{











    // =====================================
    // HELPER GENERAL - VENTANAS TARRAJEO
    // =====================================

    public static class MYG_TarrajeoUI
    {
        public static void MinimizarTodo(params WinForms.Form[] formularios)
        {
            if (formularios == null)
                return;

            foreach (WinForms.Form f in formularios)
            {
                try
                {
                    if (f == null || f.IsDisposed)
                        continue;

                    f.WindowState = WinForms.FormWindowState.Minimized;
                    f.Hide();
                }
                catch
                {
                }
            }
        }

        public static void Restaurar(WinForms.Form formulario)
        {
            try
            {
                if (formulario == null || formulario.IsDisposed)
                    return;

                if (formulario.InvokeRequired)
                {
                    formulario.BeginInvoke(new Action(() =>
                    {
                        Restaurar(formulario);
                    }));
                    return;
                }

                formulario.Show();
                formulario.WindowState = WinForms.FormWindowState.Normal;
                formulario.TopMost = true;
                formulario.BringToFront();
                formulario.Activate();
            }
            catch
            {
            }
        }
    }

}
