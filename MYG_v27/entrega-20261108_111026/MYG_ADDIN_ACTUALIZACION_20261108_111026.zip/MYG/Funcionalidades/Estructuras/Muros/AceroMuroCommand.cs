using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ==========================================
    // COMANDO 3.8 - ACERO EN MUROS
    // SIN USING NI NAMESPACE
    // VENTANA MODELESS + UN SOLO HANDLER
    // ==========================================

    [Autodesk.Revit.Attributes.Transaction(
    Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class AceroMuroCommand : Autodesk.Revit.UI.IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc =
                commandData.Application.ActiveUIDocument;

            if (uidoc == null)
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.DB.Document doc = uidoc.Document;

            System.Collections.Generic.IEnumerable<
                Autodesk.Revit.DB.Structure.RebarBarType> consultaArmadura =
                System.Linq.Enumerable.Cast<
                    Autodesk.Revit.DB.Structure.RebarBarType>(
                        new Autodesk.Revit.DB.FilteredElementCollector(doc)
                            .OfClass(
                                typeof(
                                    Autodesk.Revit.DB.Structure.RebarBarType)));

            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarBarType> tiposArmadura =
                System.Linq.Enumerable.ToList(
                    System.Linq.Enumerable.OrderBy(
                        consultaArmadura,
                        x => x.Name));

            // =====================================================
            // RECUBRIMIENTOS CONFIGURADOS EN REVIT
            //
            // OBJETIVO:
            // Cargar TODOS los RebarCoverType definidos en el proyecto,
            // incluso si todavía no están asignados a ningún elemento.
            //
            // Esta lista corresponde a la ventana:
            // "Configuración de recubrimiento de armadura".
            // =====================================================

            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarCoverType> tiposRecubrimiento =
                new System.Collections.Generic.List<
                    Autodesk.Revit.DB.Structure.RebarCoverType>();

            System.Collections.Generic.HashSet<long> idsRecubrimientos =
                new System.Collections.Generic.HashSet<long>();

            System.Action<
                Autodesk.Revit.DB.Structure.RebarCoverType> agregarRecubrimiento =
                tipo =>
                {
                    if (tipo == null)
                        return;

                    if (idsRecubrimientos.Add(
                        tipo.Id.Value))
                    {
                        tiposRecubrimiento.Add(tipo);
                    }
                };

            // -----------------------------------------------------
            // FUENTE PRINCIPAL:
            // RebarCoverType existentes en el documento.
            //
            // Este collector NO depende de que el recubrimiento esté
            // actualmente usado por un muro/columna/viga.
            // -----------------------------------------------------
            try
            {
                System.Collections.Generic.IEnumerable<
                    Autodesk.Revit.DB.Structure.RebarCoverType> coversDocumento =
                    System.Linq.Enumerable.Cast<
                        Autodesk.Revit.DB.Structure.RebarCoverType>(
                            new Autodesk.Revit.DB.FilteredElementCollector(doc)
                                .OfClass(
                                    typeof(
                                        Autodesk.Revit.DB.Structure.RebarCoverType)));

                foreach (
                    Autodesk.Revit.DB.Structure.RebarCoverType cover
                    in coversDocumento)
                {
                    agregarRecubrimiento(cover);
                }
            }
            catch
            {
            }

            // -----------------------------------------------------
            // RESPALDO:
            // También añadimos covers realmente asignados a hosts.
            // Sirve como seguridad adicional en proyectos especiales.
            // -----------------------------------------------------
            Autodesk.Revit.DB.BuiltInCategory[] categoriasHost =
            {
            Autodesk.Revit.DB.BuiltInCategory.OST_Walls,
            Autodesk.Revit.DB.BuiltInCategory.OST_StructuralColumns,
            Autodesk.Revit.DB.BuiltInCategory.OST_Columns,
            Autodesk.Revit.DB.BuiltInCategory.OST_StructuralFraming,
            Autodesk.Revit.DB.BuiltInCategory.OST_Floors,
            Autodesk.Revit.DB.BuiltInCategory.OST_StructuralFoundation
        };

            foreach (
                Autodesk.Revit.DB.BuiltInCategory bic
                in categoriasHost)
            {
                try
                {
                    System.Collections.Generic.ICollection<
                        Autodesk.Revit.DB.Element> hosts =
                        new Autodesk.Revit.DB.FilteredElementCollector(doc)
                            .OfCategory(bic)
                            .WhereElementIsNotElementType()
                            .ToElements();

                    foreach (
                        Autodesk.Revit.DB.Element host
                        in hosts)
                    {
                        if (host == null)
                            continue;

                        Autodesk.Revit.DB.Structure.RebarHostData hostData =
                            null;

                        try
                        {
                            hostData =
                                Autodesk.Revit.DB.Structure.RebarHostData
                                    .GetRebarHostData(host);

                            if (hostData == null)
                                continue;

                            Autodesk.Revit.DB.Structure.RebarCoverType comun =
                                hostData.GetCommonCoverType();

                            if (comun != null)
                                agregarRecubrimiento(comun);

                            System.Collections.Generic.IList<
                                Autodesk.Revit.DB.Reference> caras =
                                hostData.GetExposedFaces();

                            if (caras != null)
                            {
                                foreach (
                                    Autodesk.Revit.DB.Reference cara
                                    in caras)
                                {
                                    if (cara == null)
                                        continue;

                                    Autodesk.Revit.DB.Structure.RebarCoverType tipoCara =
                                        hostData.GetCoverType(cara);

                                    if (tipoCara != null)
                                        agregarRecubrimiento(tipoCara);
                                }
                            }
                        }
                        catch
                        {
                        }
                        finally
                        {
                            if (hostData != null)
                                hostData.Dispose();
                        }
                    }
                }
                catch
                {
                }
            }

            // Igual que la tabla de Revit: primero por DESCRIPCIÓN.
            tiposRecubrimiento =
                System.Linq.Enumerable.ToList(
                    System.Linq.Enumerable.OrderBy(
                        tiposRecubrimiento,
                        x => x.Name));


            // =====================================================
            // TIPOS DE GANCHO CONFIGURADOS EN REVIT
            // =====================================================
            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarHookType> tiposGancho =
                new System.Collections.Generic.List<
                    Autodesk.Revit.DB.Structure.RebarHookType>();

            try
            {
                tiposGancho =
                    System.Linq.Enumerable.ToList(
                        System.Linq.Enumerable.OrderBy(
                            System.Linq.Enumerable.Cast<
                                Autodesk.Revit.DB.Structure.RebarHookType>(
                                    new Autodesk.Revit.DB.FilteredElementCollector(doc)
                                        .OfClass(
                                            typeof(
                                                Autodesk.Revit.DB.Structure.RebarHookType))),
                            x => x.Name));
            }
            catch
            {
                tiposGancho =
                    new System.Collections.Generic.List<
                        Autodesk.Revit.DB.Structure.RebarHookType>();
            }


            if (tiposArmadura.Count == 0)
            {
                Autodesk.Revit.UI.TaskDialog.Show(
                    "MYG",
                    "No se encontraron tipos de armadura estructural en el proyecto.");

                return Autodesk.Revit.UI.Result.Cancelled;
            }

            AceroMuroForm form = new AceroMuroForm();
            form.CargarTiposArmadura(tiposArmadura);
            form.CargarRecubrimientos(tiposRecubrimiento);
            form.CargarTiposGancho(tiposGancho);

            AceroMuroHandler handler = new AceroMuroHandler
            {
                UiDoc = uidoc,
                Form = form
            };

            Autodesk.Revit.UI.ExternalEvent externalEvent =
                Autodesk.Revit.UI.ExternalEvent.Create(handler);

            form.Handler = handler;
            form.ExternalEvent = externalEvent;
            form.Show();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}
