using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ==========================================
    // VENTANA 3.8 - ACERO EN MUROS
    // SIN USING NI NAMESPACE
    // VISTA PREVIA EN ELEVACIÓN LATERAL
    // HORIZONTALES CONTINUOS POR CADENA
    // ==========================================

    public class AceroMuroForm : System.Windows.Forms.Form
    {
        #region 01 - TIPOS Y MODELOS AUXILIARES (PLEGAR AQUÍ)

        internal class AceroMuroTramoVista
        {
            public long MuroId { get; set; }
            public string Nombre { get; set; } = "";
            public int Cadena { get; set; }

            // En el alzado longitudinal el muro curvo se muestra
            // DESENROLLADO según su longitud de arco.
            public bool EsCurvo { get; set; }

            // Coordenadas "desenrolladas" de la vista lateral.
            public double XInicio { get; set; }
            public double XFin { get; set; }

            // Elevaciones reales en pies internos de Revit.
            public double ZInferior { get; set; }
            public double ZSuperior { get; set; }
        }

        internal class AceroMuroVacioVista
        {
            public long ElementoId { get; set; }
            public bool TieneElementoReal { get; set; }

            public int Cadena { get; set; }
            public double XInicio { get; set; }
            public double XFin { get; set; }
            public double ZInferior { get; set; }
            public double ZSuperior { get; set; }

            // Recubrimiento real detectado en el elemento que ocupa
            // este tramo vacío (columna/pilar/elemento de borde).
            public double RecubrimientoCm { get; set; }
            public string NombreRecubrimiento { get; set; } = "";

            public string Descripcion { get; set; } = "";
        }

        internal class AceroMuroElementoExtremoVista
        {
            public long ElementoId { get; set; }
            public int Cadena { get; set; }
            public bool EsInicio { get; set; }

            public string Categoria { get; set; } = "";
            public string Nombre { get; set; } = "";

            public double XInicio { get; set; }
            public double XFin { get; set; }
            public double ZInferior { get; set; }
            public double ZSuperior { get; set; }

            // Recubrimiento real detectado en el host de Revit.
            public double RecubrimientoCm { get; set; }
            public string NombreRecubrimiento { get; set; } = "";
        }

        internal class AceroMuroVistaElevacion
        {
            public System.Collections.Generic.List<AceroMuroTramoVista> Tramos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroTramoVista>();

            public System.Collections.Generic.List<AceroMuroVacioVista> Vacios
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroVacioVista>();

            public System.Collections.Generic.List<AceroMuroElementoExtremoVista> ElementosExtremos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroElementoExtremoVista>();

            public int CantidadCadenas { get; set; }
            public int CantidadMuros { get; set; }

            public System.Collections.Generic.List<string> Avisos
            { get; set; } =
                new System.Collections.Generic.List<string>();
        }


        internal class AceroMuroVistaSeccion
        {
            public string NombreReferencia { get; set; } = "";
            public double Espesor { get; set; }
            public double Altura { get; set; }
            public int CantidadMuros { get; set; }
            public int CantidadVariantes { get; set; }

            // Límites reales del NÚCLEO medidos desde el centro
            // geométrico del espesor del muro.
            public bool TieneNucleo { get; set; }
            public double NucleoMinDesdeCentro { get; set; }
            public double NucleoMaxDesdeCentro { get; set; }

            public string Observacion { get; set; } = "";
        }

        internal class AceroMuroRecubrimientoItem
        {
            public Autodesk.Revit.DB.Structure.RebarCoverType Tipo { get; set; }
            public double ValorCm { get; set; }
            public string Texto { get; set; } = "";

            public override string ToString()
            {
                return Texto ?? "";
            }
        }

        internal class AceroMuroAjusteTramo
        {
            public long MuroId { get; set; }
            public double RetiroInicioCm { get; set; }
            public double RetiroFinCm { get; set; }
        }

        // =========================================================
        // GRUPO HORIZONTAL DEFINIDO LIBREMENTE CON 2 PUNTOS EN SECCIÓN
        //
        // MISMA IDEA DEL EDITOR DE VIGAS:
        // - los dos puntos definen la geometría REAL;
        // - no se reemplazan por una guía;
        // - U/V se guardan respecto de la sección total del muro;
        // - NO se limitan a 0..1: pueden quedar fuera del anfitrión.
        // =========================================================
        internal enum AceroMuroReglaDistribucionGrupo
        {
            NumeroFijo = 0,
            EspaciadoMaximo = 1
        }

        // =========================================================
        // VÍNCULOS INTELIGENTES DE LOS EXTREMOS 2P
        //
        // Si un extremo se captura sobre una GUIA H, no guardamos
        // únicamente la coordenada: guardamos también A QUÉ guía
        // pertenece. Así, si cambia REC / ØV / ØH / Malla, el
        // extremo sigue a la guía automáticamente.
        // =========================================================
        internal enum AceroMuroVinculoGuiaHorizontal2P
        {
            Ninguno = 0,
            MallaA = 1,
            MallaB = 2,
            UnaMalla = 3
        }

        internal enum AceroMuroVinculoVertical2P
        {
            Ninguno = 0,
            LimiteInferior = 1,
            LimiteSuperior = 2
        }

        internal class AceroMuroSnapPunto2P
        {
            public bool Valido { get; set; }
            public double X { get; set; }
            public double Z { get; set; }
            public double DistanciaPx { get; set; } = double.MaxValue;
            public string Texto { get; set; } = "";
            public AceroMuroVinculoGuiaHorizontal2P VinculoGuia
            { get; set; } = AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            public AceroMuroVinculoVertical2P VinculoVertical
            { get; set; } = AceroMuroVinculoVertical2P.Ninguno;
        }

        internal sealed class AceroMuroReglaGrupoHorizontalForm :
            System.Windows.Forms.Form
        {
            private readonly System.Windows.Forms.ComboBox cmbRegla;
            private readonly System.Windows.Forms.NumericUpDown nudEspaciado;
            private readonly System.Windows.Forms.NumericUpDown nudCantidad;
            private readonly System.Windows.Forms.Label lblResultado;
            private readonly double longitudDisponibleCm;

            public AceroMuroReglaDistribucionGrupo ReglaSeleccionada
            {
                get
                {
                    return
                        cmbRegla.SelectedIndex == 1
                            ? AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                            : AceroMuroReglaDistribucionGrupo.NumeroFijo;
                }
            }

            public double EspaciadoCm
            {
                get
                {
                    return
                        (double)nudEspaciado.Value;
                }
            }

            public int Cantidad
            {
                get
                {
                    return
                        (int)nudCantidad.Value;
                }
            }

            public AceroMuroReglaGrupoHorizontalForm(
                double longitudCm,
                AceroMuroReglaDistribucionGrupo reglaInicial,
                double espaciadoInicialCm,
                int cantidadInicial)
            {
                longitudDisponibleCm =
                    System.Math.Max(
                        0.0,
                        longitudCm);

                Text =
                    "MYG - Modificar distribución horizontal";

                StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterParent;

                FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.FixedDialog;

                MaximizeBox = false;
                MinimizeBox = false;
                ShowInTaskbar = false;

                // V8.49:
                // AceroMuroForm trabaja como TopMost. Si este diálogo se deja
                // con TopMost = false, Windows puede colocarlo DETRÁS de la
                // ventana principal aunque ShowDialog(this) ya la haya bloqueado.
                //
                // Resultado visible del fallo:
                // - la ventana principal queda deshabilitada;
                // - parece que no abrió nada;
                // - ESC cierra el diálogo oculto y "desbloquea" la principal.
                //
                // Por eso el editor modal también debe subir al nivel TopMost.
                TopMost = true;

                ClientSize =
                    new System.Drawing.Size(
                        470,
                        285);

                Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9F);

                BackColor =
                    System.Drawing.Color.FromArgb(
                        247,
                        248,
                        250);

                Controls.Add(
                    new System.Windows.Forms.Label
                    {
                        Left = 18,
                        Top = 16,
                        Width = 430,
                        Height = 25,
                        Text =
                            "MODIFICAR GRUPO HORIZONTAL",
                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                10F,
                                System.Drawing.FontStyle.Bold),
                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                0,
                                90,
                                160),
                        TextAlign =
                            System.Drawing.ContentAlignment.MiddleCenter
                    });

                Controls.Add(
                    new System.Windows.Forms.Label
                    {
                        Left = 22,
                        Top = 50,
                        Width = 420,
                        Height = 22,
                        Text =
                            "Longitud disponible: " +
                            longitudDisponibleCm.ToString(
                                "0.##") +
                            " cm"
                    });

                Controls.Add(
                    new System.Windows.Forms.Label
                    {
                        Left = 22,
                        Top = 87,
                        Width = 145,
                        Height = 22,
                        Text = "Regla:"
                    });

                cmbRegla =
                    new System.Windows.Forms.ComboBox
                    {
                        Left = 170,
                        Top = 83,
                        Width = 270,
                        DropDownStyle =
                            System.Windows.Forms.ComboBoxStyle.DropDownList
                    };

                cmbRegla.Items.Add(
                    "Número fijo");

                cmbRegla.Items.Add(
                    "Espaciado máximo");

                cmbRegla.SelectedIndex =
                    reglaInicial ==
                        AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                        ? 1
                        : 0;

                Controls.Add(
                    cmbRegla);

                Controls.Add(
                    new System.Windows.Forms.Label
                    {
                        Left = 22,
                        Top = 125,
                        Width = 145,
                        Height = 22,
                        Text = "Espaciado máximo:"
                    });

                decimal espInicial =
                    (decimal)System.Math.Max(
                        0.10,
                        System.Math.Min(
                            1000.0,
                            espaciadoInicialCm));

                nudEspaciado =
                    new System.Windows.Forms.NumericUpDown
                    {
                        Left = 170,
                        Top = 121,
                        Width = 105,
                        DecimalPlaces = 2,
                        Minimum = 0.10M,
                        Maximum = 1000M,
                        Increment = 0.50M,
                        Value = espInicial
                    };

                Controls.Add(
                    nudEspaciado);

                Controls.Add(
                    new System.Windows.Forms.Label
                    {
                        Left = 282,
                        Top = 125,
                        Width = 35,
                        Height = 22,
                        Text = "cm"
                    });

                Controls.Add(
                    new System.Windows.Forms.Label
                    {
                        Left = 22,
                        Top = 161,
                        Width = 145,
                        Height = 22,
                        Text = "Número de barras:"
                    });

                decimal cantInicial =
                    (decimal)System.Math.Max(
                        2,
                        System.Math.Min(
                            1002,
                            cantidadInicial));

                nudCantidad =
                    new System.Windows.Forms.NumericUpDown
                    {
                        Left = 170,
                        Top = 157,
                        Width = 105,
                        Minimum = 2,
                        Maximum = 1002,
                        Value = cantInicial
                    };

                Controls.Add(
                    nudCantidad);

                lblResultado =
                    new System.Windows.Forms.Label
                    {
                        Left = 22,
                        Top = 194,
                        Width = 420,
                        Height = 34,
                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                65,
                                65,
                                65)
                    };

                Controls.Add(
                    lblResultado);

                System.Windows.Forms.Button aceptar =
                    new System.Windows.Forms.Button
                    {
                        Left = 278,
                        Top = 238,
                        Width = 82,
                        Height = 30,
                        Text = "APLICAR",
                        DialogResult =
                            System.Windows.Forms.DialogResult.OK,
                        BackColor =
                            System.Drawing.Color.FromArgb(
                                0,
                                120,
                                215),
                        ForeColor =
                            System.Drawing.Color.White,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat
                    };

                aceptar.FlatAppearance.BorderSize = 0;

                Controls.Add(
                    aceptar);

                System.Windows.Forms.Button cancelar =
                    new System.Windows.Forms.Button
                    {
                        Left = 367,
                        Top = 238,
                        Width = 82,
                        Height = 30,
                        Text = "CANCELAR",
                        DialogResult =
                            System.Windows.Forms.DialogResult.Cancel
                    };

                Controls.Add(
                    cancelar);

                AcceptButton =
                    aceptar;

                CancelButton =
                    cancelar;

                // Refuerzo de Z-Order para Revit + ventana modeless TopMost.
                Shown +=
                    (s, e) =>
                    {
                        try
                        {
                            TopMost = true;
                            BringToFront();
                            Activate();
                            Focus();
                        }
                        catch
                        {
                        }
                    };

                Activated +=
                    (s, e) =>
                    {
                        try
                        {
                            if (!TopMost)
                                TopMost = true;
                        }
                        catch
                        {
                        }
                    };

                cmbRegla.SelectedIndexChanged +=
                    (s, e) =>
                        ActualizarControles();

                nudEspaciado.ValueChanged +=
                    (s, e) =>
                        ActualizarResumen();

                nudCantidad.ValueChanged +=
                    (s, e) =>
                        ActualizarResumen();

                ActualizarControles();
            }

            private void ActualizarControles()
            {
                bool numeroFijo =
                    cmbRegla.SelectedIndex == 0;

                nudCantidad.Enabled =
                    numeroFijo;

                nudEspaciado.Enabled =
                    !numeroFijo;

                ActualizarResumen();
            }

            private void ActualizarResumen()
            {
                if (cmbRegla.SelectedIndex == 0)
                {
                    int cantidad =
                        System.Math.Max(
                            2,
                            (int)nudCantidad.Value);

                    double separacionReal =
                        cantidad <= 1
                            ? 0.0
                            : longitudDisponibleCm /
                                (cantidad - 1);

                    lblResultado.Text =
                        "Se conservarán " +
                        cantidad +
                        " barras ocupando todo el tramo. " +
                        "Separación real: " +
                        separacionReal.ToString(
                            "0.##") +
                        " cm.";

                    return;
                }

                double espaciado =
                    System.Math.Max(
                        0.10,
                        (double)nudEspaciado.Value);

                int cantidadMaximo =
                    longitudDisponibleCm <= 1e-9
                        ? 2
                        : System.Math.Max(
                            2,
                            (int)System.Math.Ceiling(
                                longitudDisponibleCm /
                                espaciado) + 1);

                double real =
                    cantidadMaximo <= 1
                        ? 0.0
                        : longitudDisponibleCm /
                            (cantidadMaximo - 1);

                lblResultado.Text =
                    "Se crearán " +
                    cantidadMaximo +
                    " barras ocupando todo el tramo. " +
                    "Espaciado real: " +
                    real.ToString(
                        "0.##") +
                    " cm, sin superar el máximo indicado.";
            }
        }



        internal class AceroMuroEmpalmeDiametroData
        {
            public double DiametroMm { get; set; }
            public string Etiqueta { get; set; } = "";
            public double LongitudEmpalmeCm { get; set; }

            public AceroMuroEmpalmeDiametroData Copiar()
            {
                return new AceroMuroEmpalmeDiametroData
                {
                    DiametroMm = DiametroMm,
                    Etiqueta = Etiqueta ?? "",
                    LongitudEmpalmeCm = LongitudEmpalmeCm
                };
            }
        }


        internal sealed class AceroMuroEmpalmesPorDiametroForm :
            System.Windows.Forms.Form
        {
            private readonly System.Windows.Forms.DataGridView tabla;
            private readonly System.Collections.Generic.List<
                AceroMuroEmpalmeDiametroData> valores;

            public System.Collections.Generic.List<
                AceroMuroEmpalmeDiametroData> Valores
            {
                get
                {
                    System.Collections.Generic.List<
                        AceroMuroEmpalmeDiametroData> copia =
                            new System.Collections.Generic.List<
                                AceroMuroEmpalmeDiametroData>();

                    foreach (
                        AceroMuroEmpalmeDiametroData item
                        in valores)
                    {
                        if (item != null)
                            copia.Add(
                                item.Copiar());
                    }

                    return copia;
                }
            }

            public AceroMuroEmpalmesPorDiametroForm(
                System.Collections.Generic.List<
                    AceroMuroEmpalmeDiametroData> datos,
                System.Func<double, double> obtenerPredeterminado)
            {
                Text = "MYG - Longitudes de empalme por diámetro";
                Width = 560;
                Height = 500;
                MinimumSize =
                    new System.Drawing.Size(
                        520,
                        390);
                StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterParent;
                FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.Sizable;
                MinimizeBox = false;
                MaximizeBox = false;
                ShowInTaskbar = false;
                TopMost = true;
                BackColor =
                    System.Drawing.Color.FromArgb(
                        245,
                        247,
                        250);
                Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9F);

                valores =
                    new System.Collections.Generic.List<
                        AceroMuroEmpalmeDiametroData>();

                if (datos != null)
                {
                    foreach (
                        AceroMuroEmpalmeDiametroData item
                        in datos)
                    {
                        if (item != null)
                            valores.Add(
                                item.Copiar());
                    }
                }

                System.Windows.Forms.Panel cabecera =
                    new System.Windows.Forms.Panel
                    {
                        Dock =
                            System.Windows.Forms.DockStyle.Top,
                        Height = 46,
                        BackColor =
                            System.Drawing.Color.FromArgb(
                                34,
                                45,
                                58)
                    };

                System.Windows.Forms.Label titulo =
                    new System.Windows.Forms.Label
                    {
                        Text = "LONGITUD DE EMPALME POR DIÁMETRO",
                        Left = 16,
                        Top = 11,
                        Width = 500,
                        Height = 24,
                        ForeColor =
                            System.Drawing.Color.White,
                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                10F,
                                System.Drawing.FontStyle.Bold)
                    };

                cabecera.Controls.Add(
                    titulo);

                tabla =
                    new System.Windows.Forms.DataGridView
                    {
                        Dock =
                            System.Windows.Forms.DockStyle.Fill,
                        BackgroundColor =
                            System.Drawing.Color.White,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.None,
                        AllowUserToAddRows = false,
                        AllowUserToDeleteRows = false,
                        AllowUserToResizeRows = false,
                        RowHeadersVisible = false,
                        AutoGenerateColumns = false,
                        SelectionMode =
                            System.Windows.Forms.DataGridViewSelectionMode.CellSelect,
                        MultiSelect = false
                    };

                System.Windows.Forms.DataGridViewTextBoxColumn colDiametro =
                    new System.Windows.Forms.DataGridViewTextBoxColumn
                    {
                        HeaderText = "Diámetro",
                        Width = 180,
                        ReadOnly = true
                    };

                System.Windows.Forms.DataGridViewTextBoxColumn colMm =
                    new System.Windows.Forms.DataGridViewTextBoxColumn
                    {
                        HeaderText = "Ø real (mm)",
                        Width = 120,
                        ReadOnly = true
                    };

                System.Windows.Forms.DataGridViewTextBoxColumn colLt =
                    new System.Windows.Forms.DataGridViewTextBoxColumn
                    {
                        HeaderText = "Lt (cm)",
                        AutoSizeMode =
                            System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill,
                        MinimumWidth = 110,
                        ReadOnly = false
                    };

                tabla.Columns.Add(
                    colDiametro);

                tabla.Columns.Add(
                    colMm);

                tabla.Columns.Add(
                    colLt);

                foreach (
                    AceroMuroEmpalmeDiametroData item
                    in valores)
                {
                    if (item == null)
                        continue;

                    int indice =
                        tabla.Rows.Add(
                            item.Etiqueta ?? "",
                            item.DiametroMm.ToString(
                                "0.###",
                                System.Globalization.CultureInfo.InvariantCulture),
                            item.LongitudEmpalmeCm.ToString(
                                "0.##",
                                System.Globalization.CultureInfo.InvariantCulture));

                    tabla.Rows[indice].Tag =
                        item;
                }

                System.Windows.Forms.Panel pie =
                    new System.Windows.Forms.Panel
                    {
                        Dock =
                            System.Windows.Forms.DockStyle.Bottom,
                        Height = 58,
                        BackColor =
                            System.Drawing.Color.FromArgb(
                                245,
                                247,
                                250)
                    };

                System.Windows.Forms.Button aplicar =
                    new System.Windows.Forms.Button
                    {
                        Text = "APLICAR",
                        Left = 12,
                        Top = 13,
                        Width = 155,
                        Height = 32,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,
                        BackColor =
                            System.Drawing.Color.FromArgb(
                                18,
                                128,
                                211),
                        ForeColor =
                            System.Drawing.Color.White
                    };

                aplicar.Click +=
                    (s, e) =>
                    {
                        // Asegurar que el valor que se está editando
                        // quede confirmado antes de leer la tabla.
                        try
                        {
                            tabla.EndEdit();
                        }
                        catch
                        {
                        }

                        for (int i = 0;
                             i < tabla.Rows.Count;
                             i++)
                        {
                            System.Windows.Forms.DataGridViewRow fila =
                                tabla.Rows[i];

                            AceroMuroEmpalmeDiametroData item =
                                fila.Tag
                                as AceroMuroEmpalmeDiametroData;

                            if (item == null)
                                continue;

                            string texto =
                                System.Convert.ToString(
                                    fila.Cells[2].Value) ?? "";

                            texto =
                                texto.Trim()
                                    .Replace(
                                        ",",
                                        ".");

                            double valorCm;

                            if (!double.TryParse(
                                    texto,
                                    System.Globalization.NumberStyles.Float,
                                    System.Globalization.CultureInfo.InvariantCulture,
                                    out valorCm) ||
                                valorCm <= 0.0)
                            {
                                System.Windows.Forms.MessageBox.Show(
                                    this,
                                    "La longitud de empalme para " +
                                        (item.Etiqueta ?? "el diámetro") +
                                        " no es válida.",
                                    "MYG",
                                    System.Windows.Forms.MessageBoxButtons.OK,
                                    System.Windows.Forms.MessageBoxIcon.Warning);

                                tabla.CurrentCell =
                                    fila.Cells[2];

                                tabla.BeginEdit(
                                    true);

                                return;
                            }

                            item.LongitudEmpalmeCm =
                                valorCm;
                        }

                        DialogResult =
                            System.Windows.Forms.DialogResult.OK;

                        Close();
                    };

                pie.Controls.Add(
                    aplicar);

                Controls.Add(
                    tabla);

                Controls.Add(
                    pie);

                Controls.Add(
                    cabecera);

                AcceptButton =
                    aplicar;
            }

            protected override void OnShown(
                System.EventArgs e)
            {
                base.OnShown(
                    e);

                if (Owner != null)
                {
                    TopMost = true;
                    BringToFront();
                    Activate();
                }
            }
        }


        internal class AceroMuroGrupoHorizontal2Puntos
        {
            public string Id { get; set; } =
                System.Guid.NewGuid().ToString("N");

            public double InicioU { get; set; }
            public double InicioV { get; set; }
            public double FinU { get; set; }
            public double FinV { get; set; }

            // Vínculos paramétricos tipo constraint.
            public AceroMuroVinculoGuiaHorizontal2P InicioVinculoGuia
            { get; set; } = AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            public AceroMuroVinculoVertical2P InicioVinculoVertical
            { get; set; } = AceroMuroVinculoVertical2P.Ninguno;

            public AceroMuroVinculoGuiaHorizontal2P FinVinculoGuia
            { get; set; } = AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            public AceroMuroVinculoVertical2P FinVinculoVertical
            { get; set; } = AceroMuroVinculoVertical2P.Ninguno;

            // Cada grupo es INDEPENDIENTE. Ya no hereda una única regla
            // de distribución para las dos caras del muro.
            public AceroMuroReglaDistribucionGrupo ReglaDistribucion
            { get; set; } =
                AceroMuroReglaDistribucionGrupo.EspaciadoMaximo;

            public double EspaciamientoMaximoCm { get; set; } = 20.0;
            public int Cantidad { get; set; } = 4;

            // Tipo de barra propio del grupo.
            // Ya no depende del ComboBox global del panel derecho.
            public long TipoBarraId { get; set; } = 0;
            public string TipoBarraNombre { get; set; } = "";

            public AceroMuroGrupoHorizontal2Puntos Copiar()
            {
                return new AceroMuroGrupoHorizontal2Puntos
                {
                    Id = Id,
                    InicioU = InicioU,
                    InicioV = InicioV,
                    FinU = FinU,
                    FinV = FinV,
                    InicioVinculoGuia = InicioVinculoGuia,
                    InicioVinculoVertical = InicioVinculoVertical,
                    FinVinculoGuia = FinVinculoGuia,
                    FinVinculoVertical = FinVinculoVertical,
                    ReglaDistribucion = ReglaDistribucion,
                    EspaciamientoMaximoCm = EspaciamientoMaximoCm,
                    Cantidad = Cantidad,
                    TipoBarraId = TipoBarraId,
                    TipoBarraNombre = TipoBarraNombre
                };
            }
        }

        internal class AceroMuroGrupoVertical2Puntos
        {
            public string Id { get; set; } =
                System.Guid.NewGuid().ToString("N");

            public double InicioU { get; set; }
            public double InicioV { get; set; }
            public double FinU { get; set; }
            public double FinV { get; set; }

            public AceroMuroVinculoGuiaHorizontal2P InicioVinculoGuia
            { get; set; } = AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            public AceroMuroVinculoVertical2P InicioVinculoVertical
            { get; set; } = AceroMuroVinculoVertical2P.Ninguno;

            public AceroMuroVinculoGuiaHorizontal2P FinVinculoGuia
            { get; set; } = AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            public AceroMuroVinculoVertical2P FinVinculoVertical
            { get; set; } = AceroMuroVinculoVertical2P.Ninguno;

            public AceroMuroReglaDistribucionGrupo ReglaDistribucion
            { get; set; } =
                AceroMuroReglaDistribucionGrupo.EspaciadoMaximo;

            public double EspaciamientoMaximoCm { get; set; } = 20.0;
            public int Cantidad { get; set; } = 4;

            // Tipo de barra propio del grupo.
            public long TipoBarraId { get; set; } = 0;
            public string TipoBarraNombre { get; set; } = "";

            public AceroMuroGrupoVertical2Puntos Copiar()
            {
                return new AceroMuroGrupoVertical2Puntos
                {
                    Id = Id,
                    InicioU = InicioU,
                    InicioV = InicioV,
                    FinU = FinU,
                    FinV = FinV,
                    InicioVinculoGuia = InicioVinculoGuia,
                    InicioVinculoVertical = InicioVinculoVertical,
                    FinVinculoGuia = FinVinculoGuia,
                    FinVinculoVertical = FinVinculoVertical,
                    ReglaDistribucion = ReglaDistribucion,
                    EspaciamientoMaximoCm = EspaciamientoMaximoCm,
                    Cantidad = Cantidad,
                    TipoBarraId = TipoBarraId,
                    TipoBarraNombre = TipoBarraNombre
                };
            }
        }


        internal class AceroMuroConfiguracion
        {
            public Autodesk.Revit.DB.Structure.RebarBarType TipoVertical { get; set; }
            public Autodesk.Revit.DB.Structure.RebarBarType TipoHorizontal { get; set; }

            public bool CrearVerticales { get; set; }
            public bool CrearHorizontales { get; set; }

            public double RecubrimientoCm { get; set; }
            public double EspaciamientoVerticalCm { get; set; }
            public double EspaciamientoHorizontalCm { get; set; }

            // 0 = ambas caras
            // 1 = cara A de la cadena
            // 2 = cara B de la cadena
            public int ModoCaras { get; set; }

            public bool HorizontalesContinuosPorCadena { get; set; }

            // =====================================================
            // V8.77 - REFUERZO DIAGONAL AUTOMÁTICO EN HUECOS
            // =====================================================
            public bool CrearRefuerzoHuecos { get; set; }

            public Autodesk.Revit.DB.Structure.RebarBarType
                TipoRefuerzoHuecos
            { get; set; }

            // Longitud TOTAL de cada varilla diagonal, en cm.
            public double LongitudRefuerzoHuecosCm { get; set; }

            // Diseño libre en la SECCIÓN. Si existen grupos, estos reemplazan
            // la distribución horizontal automática por espaciamiento.
            public System.Collections.Generic.List<AceroMuroGrupoHorizontal2Puntos>
                GruposHorizontales2Puntos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroGrupoHorizontal2Puntos>();

            public System.Collections.Generic.List<AceroMuroGrupoVertical2Puntos>
                GruposVerticales2Puntos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroGrupoVertical2Puntos>();

            // Empalmes de los ACEROS HORIZONTALES.
            // LongitudComercialCm es la longitud máxima de cada pieza.
            public bool ConsiderarEmpalmeHorizontal { get; set; }
            public double LongitudComercialCm { get; set; }

            // Longitud de empalme editable por diámetro.
            // Se guarda en cm y se resuelve contra el diámetro REAL del RebarBarType.
            public System.Collections.Generic.List<AceroMuroEmpalmeDiametroData>
                EmpalmesPorDiametro
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroEmpalmeDiametroData>();

            // Si está activo, los Rebar creados se muestran
            // "sin tapar" en la vista activa al terminar.
            public bool VerElementosSinTapar { get; set; }

            // Diseño dinámico procedente de la vista previa.
            public bool UsarDisenoManual { get; set; } = true;

            public System.Collections.Generic.List<AceroMuroAjusteTramo>
                AjustesTramos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroAjusteTramo>();

            // Ajustes adicionales en la sección, medidos desde la posición
            // automática calculada por recubrimiento + 1/2 diámetro.
            public double AjusteCaraACm { get; set; }
            public double AjusteCaraBCm { get; set; }
            public double AjusteInferiorCm { get; set; }
            public double AjusteSuperiorCm { get; set; }

            // Ganchos únicamente para los ACEROS VERTICALES.
            // 0 = sin gancho | 90 = 90° | 180 = 180°
            public int AnguloGanchoInferior { get; set; }
            public int AnguloGanchoSuperior { get; set; }

            public Autodesk.Revit.DB.Structure.RebarHookType
                GanchoInferior
            { get; set; }

            public Autodesk.Revit.DB.Structure.RebarHookType
                GanchoSuperior
            { get; set; }

            // Longitud manual de gancho por extremo.
            // Se interpreta en centímetros desde la UI.
            public bool LongitudGanchoInferiorManual { get; set; }
            public bool LongitudGanchoSuperiorManual { get; set; }

            public double LongitudGanchoInferiorCm { get; set; }
            public double LongitudGanchoSuperiorCm { get; set; }
        }

        internal enum AceroMuroHerramientaEdicion
        {
            SeleccionarMover,
            MoverDosPuntos,
            CopiarDosPuntos,
            DistribuirHorizontalDosPuntos,
            DistribuirVerticalDosPuntos
        }

        // =========================================================
        // BLOQUEOS PORTABLES DE LOS EXTREMOS HORIZONTALES
        //
        // No se guarda una coordenada absoluta.
        // Se guarda QUÉ referencia debe seguir el acero.
        // Así, al cargar la data en otra serie, el extremo vuelve
        // a buscar el borde/recubrimiento del nuevo elemento extremo.
        // =========================================================
        internal enum AceroMuroTipoBloqueoExtremo
        {
            Ninguno = 0,
            BordeExteriorElemento = 1,
            RecubrimientoExteriorElemento = 2,
            BordeInteriorElemento = 3,
            RecubrimientoInteriorElemento = 4
        }

        internal class AceroMuroAjusteData
        {
            public int Indice { get; set; }
            public double InicioCm { get; set; }
            public double FinCm { get; set; }
        }

        internal class AceroMuroDataGuardada
        {
            public string TipoVertical { get; set; } = "";
            public string TipoHorizontal { get; set; } = "";
            public string Recubrimiento { get; set; } = "";
            public string EspVertical { get; set; } = "";
            public string EspHorizontal { get; set; } = "";
            public string Caras { get; set; } = "";

            public bool CrearVertical { get; set; } = true;
            public bool CrearHorizontal { get; set; } = true;
            public bool Continuos { get; set; } = true;
            public bool ConsiderarEmpalme { get; set; } = false;
            public string LongitudComercial { get; set; } = "9.0";

            // V8.77 - refuerzo diagonal en huecos.
            public bool CrearRefuerzoHuecos { get; set; } = true;
            public string TipoRefuerzoHuecos { get; set; } = "";
            public string LongitudRefuerzoHuecos { get; set; } = "0.65";

            public System.Collections.Generic.List<AceroMuroEmpalmeDiametroData>
                EmpalmesPorDiametro
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroEmpalmeDiametroData>();

            public bool VerElementosSinTapar { get; set; } = true;

            // =====================================================
            // V8.71 - DESARROLLO HORIZONTAL PORTABLE
            //
            // Estos valores representan la longitud REAL desde la cara
            // física del muro hasta el extremo del acero.
            //
            // No dependen del ElementId ni de cuántos muros formen la
            // selección actual.
            // =====================================================
            public bool DesarrolloHorizontalInicioDefinido { get; set; }
            public bool DesarrolloHorizontalFinDefinido { get; set; }

            public double DesarrolloHorizontalInicioM { get; set; }
            public double DesarrolloHorizontalFinM { get; set; }

            public double AjusteCaraACm { get; set; }
            public double AjusteCaraBCm { get; set; }
            public double AjusteInferiorCm { get; set; }
            public double AjusteSuperiorCm { get; set; }

            public int GanchoInferior { get; set; }
            public int GanchoSuperior { get; set; }

            public bool GanchoInferiorManual { get; set; }
            public bool GanchoSuperiorManual { get; set; }

            public string LongitudGanchoInferior { get; set; } = "";
            public string LongitudGanchoSuperior { get; set; } = "";

            public AceroMuroTipoBloqueoExtremo BloqueoInicio
            { get; set; } =
                AceroMuroTipoBloqueoExtremo.Ninguno;

            public AceroMuroTipoBloqueoExtremo BloqueoFin
            { get; set; } =
                AceroMuroTipoBloqueoExtremo.Ninguno;

            public System.Collections.Generic.List<AceroMuroAjusteData>
                Ajustes
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroAjusteData>();

            public System.Collections.Generic.List<AceroMuroGrupoHorizontal2Puntos>
                GruposHorizontales2Puntos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroGrupoHorizontal2Puntos>();

            public System.Collections.Generic.List<AceroMuroGrupoVertical2Puntos>
                GruposVerticales2Puntos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroGrupoVertical2Puntos>();
        }

        internal class AceroMuroEstadoEdicion
        {
            public System.Collections.Generic.Dictionary<long, double> AjusteInicioCm
            { get; set; } =
                new System.Collections.Generic.Dictionary<long, double>();

            public System.Collections.Generic.Dictionary<long, double> AjusteFinCm
            { get; set; } =
                new System.Collections.Generic.Dictionary<long, double>();

            public double AjusteCaraACm { get; set; }
            public double AjusteCaraBCm { get; set; }
            public double AjusteInferiorCm { get; set; }
            public double AjusteSuperiorCm { get; set; }

            public int GanchoInferior { get; set; }
            public int GanchoSuperior { get; set; }

            public bool GanchoInferiorManual { get; set; }
            public bool GanchoSuperiorManual { get; set; }

            public string LongitudGanchoInferior { get; set; } = "";
            public string LongitudGanchoSuperior { get; set; } = "";

            public AceroMuroTipoBloqueoExtremo BloqueoInicio
            { get; set; } =
                AceroMuroTipoBloqueoExtremo.Ninguno;

            public AceroMuroTipoBloqueoExtremo BloqueoFin
            { get; set; } =
                AceroMuroTipoBloqueoExtremo.Ninguno;

            public System.Collections.Generic.List<AceroMuroGrupoHorizontal2Puntos>
                GruposHorizontales2Puntos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroGrupoHorizontal2Puntos>();

            public System.Collections.Generic.List<AceroMuroGrupoVertical2Puntos>
                GruposVerticales2Puntos
            { get; set; } =
                new System.Collections.Generic.List<AceroMuroGrupoVertical2Puntos>();

            public AceroMuroEstadoEdicion Copiar()
            {
                AceroMuroEstadoEdicion copia =
                    new AceroMuroEstadoEdicion
                    {
                        AjusteCaraACm = AjusteCaraACm,
                        AjusteCaraBCm = AjusteCaraBCm,
                        AjusteInferiorCm = AjusteInferiorCm,
                        AjusteSuperiorCm = AjusteSuperiorCm,
                        GanchoInferior = GanchoInferior,
                        GanchoSuperior = GanchoSuperior,
                        GanchoInferiorManual = GanchoInferiorManual,
                        GanchoSuperiorManual = GanchoSuperiorManual,
                        LongitudGanchoInferior = LongitudGanchoInferior,
                        LongitudGanchoSuperior = LongitudGanchoSuperior,
                        BloqueoInicio = BloqueoInicio,
                        BloqueoFin = BloqueoFin
                    };

                foreach (
                    System.Collections.Generic.KeyValuePair<long, double> kv
                    in AjusteInicioCm)
                {
                    copia.AjusteInicioCm[kv.Key] = kv.Value;
                }

                foreach (
                    System.Collections.Generic.KeyValuePair<long, double> kv
                    in AjusteFinCm)
                {
                    copia.AjusteFinCm[kv.Key] = kv.Value;
                }

                foreach (
                    AceroMuroGrupoHorizontal2Puntos grupo
                    in GruposHorizontales2Puntos)
                {
                    if (grupo != null)
                        copia.GruposHorizontales2Puntos.Add(
                            grupo.Copiar());
                }

                foreach (
                    AceroMuroGrupoVertical2Puntos grupo
                    in GruposVerticales2Puntos)
                {
                    if (grupo != null)
                        copia.GruposVerticales2Puntos.Add(
                            grupo.Copiar());
                }

                return copia;
            }
        }

        internal class AceroMuroPanelDobleBuffer : System.Windows.Forms.Panel
        {
            public AceroMuroPanelDobleBuffer()
            {
                DoubleBuffered = true;
                ResizeRedraw = true;

                SetStyle(
                    System.Windows.Forms.ControlStyles.AllPaintingInWmPaint |
                    System.Windows.Forms.ControlStyles.UserPaint |
                    System.Windows.Forms.ControlStyles.OptimizedDoubleBuffer,
                    true);

                BackColor = System.Drawing.Color.White;
            }
        }

        #endregion

        #region 02 - IMPLEMENTACIÓN COMPLETA DE LA VENTANA (PLEGAR TODO AQUÍ)

        #region 02.1 - CAMPOS, ESTADO Y CONSTRUCTOR


        public Autodesk.Revit.UI.ExternalEvent ExternalEvent;
        public AceroMuroHandler Handler;

        private System.Windows.Forms.ComboBox cmbTipoVertical;
        private System.Windows.Forms.ComboBox cmbTipoHorizontal;
        private System.Windows.Forms.ComboBox cmbCaras;
        private System.Windows.Forms.ComboBox cmbRecubrimiento;

        // El ComboBox contiene STRING reales para garantizar que
        // siempre se vea la lista. Este diccionario conserva el
        // vínculo con el RebarCoverType de Revit.
        private readonly System.Collections.Generic.Dictionary<
            string,
            Autodesk.Revit.DB.Structure.RebarCoverType>
            recubrimientosRevitPorTexto =
                new System.Collections.Generic.Dictionary<
                    string,
                    Autodesk.Revit.DB.Structure.RebarCoverType>(
                        System.StringComparer.OrdinalIgnoreCase);

        // Se conservan ocultos como valores por defecto internos para
        // nuevos grupos y compatibilidad con datos anteriores.
        private System.Windows.Forms.TextBox txtEspVertical;
        private System.Windows.Forms.TextBox txtEspHorizontal;

        // =========================================================
        // CONFIGURACIÓN INDEPENDIENTE DEL GRUPO SELECCIONADO
        // =========================================================
        private System.Windows.Forms.Label lblGrupoSeleccionado;
        private System.Windows.Forms.ComboBox cmbGrupoDiametro;
        private System.Windows.Forms.ComboBox cmbGrupoRegla;
        private System.Windows.Forms.Label lblGrupoValor;
        private System.Windows.Forms.TextBox txtGrupoValor;
        private System.Windows.Forms.Label lblGrupoUnidad;
        private System.Windows.Forms.Button btnAplicarCambiosGrupo;
        private System.Windows.Forms.Label lblGrupoEstado;
        private bool actualizandoPanelGrupoSeleccionado;
        private bool panelGrupoTieneCambios;

        private readonly System.Collections.Generic.List<
            Autodesk.Revit.DB.Structure.RebarBarType>
            tiposArmaduraDisponibles =
                new System.Collections.Generic.List<
                    Autodesk.Revit.DB.Structure.RebarBarType>();

        // =========================================================
        // GANCHOS VERTICALES - selección directamente en SECCIÓN
        // =========================================================
        private readonly System.Collections.Generic.List<
            Autodesk.Revit.DB.Structure.RebarHookType>
            tiposGanchoDisponibles =
                new System.Collections.Generic.List<
                    Autodesk.Revit.DB.Structure.RebarHookType>();

        private Autodesk.Revit.DB.Structure.RebarHookType
            tipoGancho90;

        private Autodesk.Revit.DB.Structure.RebarHookType
            tipoGancho180;

        private int anguloGanchoInferior;
        private int anguloGanchoSuperior;

        private System.Drawing.RectangleF rectSelectorGanchoInferior =
            System.Drawing.RectangleF.Empty;

        private System.Drawing.RectangleF rectSelectorGanchoSuperior =
            System.Drawing.RectangleF.Empty;

        // Longitud manual de gancho.
        // Se ubica en la segunda fila de la barra de edición de SECCIÓN.
        private System.Windows.Forms.CheckBox chkLongGanchoSupManual;
        private System.Windows.Forms.CheckBox chkLongGanchoInfManual;
        private System.Windows.Forms.TextBox txtLongGanchoSup;
        private System.Windows.Forms.TextBox txtLongGanchoInf;

        private System.Windows.Forms.CheckBox chkVerticales;
        private System.Windows.Forms.CheckBox chkHorizontales;
        private System.Windows.Forms.CheckBox chkContinuos;
        private System.Windows.Forms.CheckBox chkConsiderarEmpalme;
        private System.Windows.Forms.TextBox txtLongitudComercial;
        private System.Windows.Forms.Button btnConfigurarEmpalmes;

        // V8.77 - controles del refuerzo diagonal de huecos.
        private System.Windows.Forms.CheckBox chkRefuerzoHuecos;
        private System.Windows.Forms.ComboBox cmbRefuerzoHuecosDiametro;
        private System.Windows.Forms.TextBox txtLongitudRefuerzoHuecos;
        private System.Windows.Forms.Label lblRefuerzoHuecosDiametro;
        private System.Windows.Forms.Label lblRefuerzoHuecosLongitud;
        private System.Windows.Forms.Label lblRefuerzoHuecosUnidad;

        private readonly System.Collections.Generic.List<
            AceroMuroEmpalmeDiametroData> empalmesPorDiametro =
                new System.Collections.Generic.List<
                    AceroMuroEmpalmeDiametroData>();
        private System.Windows.Forms.CheckBox chkVerSinTapar;

        private System.Windows.Forms.ListBox lstMuros;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.Label lblCadenas;
        private System.Windows.Forms.Label lblEstado;

        private AceroMuroPanelDobleBuffer pnlVistaAlzado;
        private AceroMuroPanelDobleBuffer pnlVistaSeccion;
        private System.Windows.Forms.TabControl tabVistas;

        public System.Windows.Forms.Button btnSeleccionar;
        public System.Windows.Forms.Button btnSeleccionarYEjecutar;
        public System.Windows.Forms.Button btnCrear;

        private AceroMuroVistaElevacion vistaElevacionActual;
        private AceroMuroVistaSeccion vistaSeccionActual;

        private double zoomVista = 1.0;
        private float panX;
        private float panY;
        private bool paneando;
        private System.Drawing.Point ultimoMouse;

        // =========================================================
        // EDITOR DINÁMICO ESTILO ACERO EN COLUMNAS
        // =========================================================
        private AceroMuroHerramientaEdicion herramientaAlzado =
            AceroMuroHerramientaEdicion.SeleccionarMover;

        private AceroMuroHerramientaEdicion herramientaSeccion =
            AceroMuroHerramientaEdicion.SeleccionarMover;

        private System.Windows.Forms.Panel panelEdicionAlzado;
        private System.Windows.Forms.Panel panelEdicionSeccion;

        private System.Windows.Forms.Button btnAlzSeleccionar;
        private System.Windows.Forms.Button btnAlzMoverDosPuntos;
        private System.Windows.Forms.Button btnAlzCopiarDosPuntos;
        private System.Windows.Forms.Button btnAlzRestablecer;
        private System.Windows.Forms.Button btnBloqueoInicio;
        private System.Windows.Forms.Button btnBloqueoFin;
        private System.Windows.Forms.Button btnGuardarData;
        private System.Windows.Forms.Button btnCargarData;

        private System.Windows.Forms.Button btnSecSeleccionar;
        private System.Windows.Forms.Button btnSecMoverDosPuntos;
        private System.Windows.Forms.Button btnSecDistribuirDosPuntos;
        private System.Windows.Forms.Button btnSecCrearVerticalDosPuntos;
        private System.Windows.Forms.Button btnSecEliminar;
        private System.Windows.Forms.Button btnSecDeshacer;
        private System.Windows.Forms.Button btnSecRehacer;
        private System.Windows.Forms.Button btnSecRestablecer;
        private System.Windows.Forms.NumericUpDown nudSecCantidadDosPuntos;

        // Editor inline del grupo seleccionado.
        private System.Windows.Forms.Panel pnlEditorGrupoHorizontal2P;
        private System.Windows.Forms.ComboBox cmbEditorReglaGrupoHorizontal2P;
        private System.Windows.Forms.NumericUpDown nudEditorEspaciadoGrupoHorizontal2P;
        private System.Windows.Forms.NumericUpDown nudEditorCantidadGrupoHorizontal2P;
        private System.Windows.Forms.Label lblEditorValorGrupoHorizontal2P;
        private System.Windows.Forms.Label lblEditorResumenGrupoHorizontal2P;
        private System.Windows.Forms.Button btnCerrarEditorGrupoHorizontal2P;
        private bool actualizandoEditorGrupoHorizontal2P = false;

        private System.Windows.Forms.Label lblAyudaAlzado;
        private System.Windows.Forms.Label lblAyudaSeccion;

        private long tramoSeleccionadoId;
        private int faseMoverDosPuntosAlzado;
        private double puntoBaseMoverDosPuntosAlzado;

        private int faseCopiarDosPuntosAlzado;
        private double puntoBaseCopiarDosPuntosAlzado;

        private int faseMoverDosPuntosSeccion;
        private System.Drawing.PointF puntoBaseMoverDosPuntosSeccion;

        // =========================================================
        // V8.57 - MOVER GRUPOS H/V CON 2 PUNTOS, TIPO REVIT
        //
        // Punto base + punto destino se guardan en coordenadas REALES
        // del modelo de la sección, no en píxeles.
        // =========================================================
        private System.Drawing.PointF puntoBaseMoverGruposModelo;
        private System.Drawing.PointF puntoDestinoMoverGruposModelo;
        private string seccionHandleSeleccionado = "";

        // =========================================================
        // DISTRIBUIR HORIZONTALES EN 2 PUNTOS - MISMA METODOLOGÍA
        // DEL EDITOR DE VIGAS.
        // =========================================================
        private readonly System.Collections.Generic.List<
            AceroMuroGrupoHorizontal2Puntos>
            gruposHorizontales2Puntos =
                new System.Collections.Generic.List<
                    AceroMuroGrupoHorizontal2Puntos>();

        private bool creandoHorizontalDosPuntos;
        private bool horizontal2PEsperandoSegundoClic;
        private System.Drawing.Point horizontal2PInicioPantalla;
        private double horizontal2PInicioX;
        private double horizontal2PInicioZ;
        private double horizontal2PFinX;
        private double horizontal2PFinZ;

        private AceroMuroVinculoGuiaHorizontal2P
            horizontal2PInicioVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;

        private AceroMuroVinculoVertical2P
            horizontal2PInicioVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

        private AceroMuroVinculoGuiaHorizontal2P
            horizontal2PFinVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;

        private AceroMuroVinculoVertical2P
            horizontal2PFinVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

        private string grupoHorizontal2PSeleccionadoId = "";

        // =========================================================
        // V8.55 - SELECCIÓN MÚLTIPLE CON CTRL
        // =========================================================
        private readonly System.Collections.Generic.HashSet<string>
            gruposHorizontales2PSeleccionados =
                new System.Collections.Generic.HashSet<string>(
                    System.StringComparer.Ordinal);


        private bool arrastrandoExtremoHorizontal2P;
        private bool arrastrandoInicioHorizontal2P;

        // =========================================================
        // VERTICALES LIBRES - CREAR V 2 PTOS
        // =========================================================
        private readonly System.Collections.Generic.List<
            AceroMuroGrupoVertical2Puntos>
            gruposVerticales2Puntos =
                new System.Collections.Generic.List<
                    AceroMuroGrupoVertical2Puntos>();

        private bool creandoVerticalDosPuntos;
        private bool vertical2PEsperandoSegundoClic;

        private System.Drawing.Point vertical2PInicioPantalla;

        private double vertical2PInicioX;
        private double vertical2PInicioZ;
        private double vertical2PFinX;
        private double vertical2PFinZ;

        private AceroMuroVinculoGuiaHorizontal2P
            vertical2PInicioVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;

        private AceroMuroVinculoVertical2P
            vertical2PInicioVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

        private AceroMuroVinculoGuiaHorizontal2P
            vertical2PFinVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;

        private AceroMuroVinculoVertical2P
            vertical2PFinVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

        private string grupoVertical2PSeleccionadoId = "";

        private readonly System.Collections.Generic.HashSet<string>
            gruposVerticales2PSeleccionados =
                new System.Collections.Generic.HashSet<string>(
                    System.StringComparer.Ordinal);

        private bool arrastrandoExtremoVertical2P;
        private bool arrastrandoInicioVertical2P;

        // =========================================================
        // V8.54 - RECUBRIMIENTO PARAMÉTRICO PARA VERTICALES
        //
        // Guarda el último recubrimiento ya aplicado a las guías.
        // Sirve para migrar automáticamente grupos creados en
        // versiones anteriores que visualmente estaban sobre una
        // GUIA V pero todavía no tenían almacenado el vínculo.
        // =========================================================
        private double ultimoRecubrimientoGuiasVerticalesCm =
            double.NaN;

        // Selección explícita del conjunto de verticales mostrado en la sección.
        // Al hacer clic sobre cualquiera de sus líneas se ilumina el conjunto
        // y aparecen manijas en sus extremos inferior/superior.
        private bool verticalesSeccionSeleccionados;

        private bool osnapActivo = true;
        private bool osnapExtremo = true;
        private bool osnapPuntoMedio = true;

        private readonly System.Collections.Generic.Stack<AceroMuroEstadoEdicion>
            pilaDeshacer =
                new System.Collections.Generic.Stack<AceroMuroEstadoEdicion>();

        private readonly System.Collections.Generic.Stack<AceroMuroEstadoEdicion>
            pilaRehacer =
                new System.Collections.Generic.Stack<AceroMuroEstadoEdicion>();

        private bool restaurandoHistorial;

        // -----------------------------
        // AJUSTES EDITABLES QUE SE ENVÍAN AL HANDLER
        // -----------------------------
        private System.Collections.Generic.Dictionary<long, double>
            ajusteInicioTramoCm =
                new System.Collections.Generic.Dictionary<long, double>();

        private System.Collections.Generic.Dictionary<long, double>
            ajusteFinTramoCm =
                new System.Collections.Generic.Dictionary<long, double>();

        private double ajusteSeccionIzquierdaCm;
        private double ajusteSeccionDerechaCm;
        private double ajusteSeccionInferiorCm;
        private double ajusteSeccionSuperiorCm;

        private bool arrastrandoHandleAlzado;
        private long tramoDragId;
        private bool tramoDragEsInicio;

        private bool arrastrandoHandleSeccion;
        private string seccionHandleActivo = "";

        // Última transformación visible del ALZADO
        private double alzadoCentroModeloX;
        private double alzadoEscala;
        private float alzadoCentroPanelX;

        // Última transformación visible de la SECCIÓN
        private double seccionEspesorActual;
        private double seccionAlturaActual;
        private double seccionEscalaActual;
        private double seccionFactorExageracionX;
        private float seccionCentroXActual;
        private float seccionYSuperiorActual;
        private float seccionYInferiorActual;

        // =========================================================
        // ÚLTIMOS VALORES USADOS - SE CONSERVAN AL CERRAR/ABRIR
        // LA VENTANA DURANTE LA MISMA SESIÓN DE REVIT.
        // =========================================================
        private static string ultimoTipoVertical = "";
        private static string ultimoTipoHorizontal = "";
        private static string ultimoRecubrimientoTexto = "";
        private static string ultimoEspVerticalTexto = "20";
        private static string ultimoEspHorizontalTexto = "20";
        private static string ultimoCarasTexto = "Doble malla";
        private static bool ultimoCrearVertical = true;
        private static bool ultimoCrearHorizontal = true;
        private static bool ultimoContinuos = true;
        private static bool ultimoConsiderarEmpalme = false;
        private static string ultimaLongitudComercialTexto = "9.0";

        private static bool ultimoCrearRefuerzoHuecos = true;
        private static string ultimoTipoRefuerzoHuecos = "";
        private static string ultimaLongitudRefuerzoHuecosTexto = "0.65";

        private static readonly System.Collections.Generic.List<
            AceroMuroEmpalmeDiametroData> ultimosEmpalmesPorDiametro =
                new System.Collections.Generic.List<
                    AceroMuroEmpalmeDiametroData>();

        private static bool ultimoVerSinTapar = true;
        private static int ultimoGanchoInferior = 0;
        private static int ultimoGanchoSuperior = 0;

        private static bool ultimoGanchoInferiorManual = false;
        private static bool ultimoGanchoSuperiorManual = false;

        private static string ultimoLongGanchoInferiorTexto = "";
        private static string ultimoLongGanchoSuperiorTexto = "";

        // OSNAP gráfico temporal.
        private bool snapAlzadoVisible;
        private double snapAlzadoX;
        private string snapAlzadoTexto = "";

        private AceroMuroTipoBloqueoExtremo
            bloqueoHorizontalInicio =
                AceroMuroTipoBloqueoExtremo.Ninguno;

        private AceroMuroTipoBloqueoExtremo
            bloqueoHorizontalFin =
                AceroMuroTipoBloqueoExtremo.Ninguno;

        private AceroMuroDataGuardada dataCargadaActiva;
        private static string ultimaRutaData = "";

        private bool snapSeccionVisible;
        private bool snapSeccionVertical;
        private double snapSeccionValor;
        private string snapSeccionTexto = "";

        // V8.47 - OSNAP VISUAL TIPO AUTODESK.
        // Guardamos el punto 2D real capturado para dibujar el símbolo
        // exactamente debajo del cursor, no solamente una línea infinita.
        private bool snapSeccionPuntoValido;
        private double snapSeccionPuntoX;
        private double snapSeccionPuntoZ;
        private string snapSeccionModo = "";

        // =========================================================
        // COTAS EDITABLES DE EXTENSIÓN VERTICAL FUERA DEL ANFITRIÓN
        // =========================================================
        private System.Drawing.RectangleF rectCotaExtensionInferior =
            System.Drawing.RectangleF.Empty;

        private System.Drawing.RectangleF rectCotaExtensionSuperior =
            System.Drawing.RectangleF.Empty;

        private bool cotaExtensionInferiorVisible;
        private bool cotaExtensionSuperiorVisible;

        // =========================================================
        // COTAS EDITABLES DE LONGITUD DE DESARROLLO HORIZONTAL
        // FUERA DEL ANFITRIÓN - VISTA DE ALZADO
        //
        // Se dibujan únicamente cuando el acero horizontal realmente
        // sale por la izquierda/derecha del tramo anfitrión.
        // =========================================================
        private readonly System.Collections.Generic.Dictionary<
            long,
            System.Drawing.RectangleF>
            rectCotaDesarrolloInicioPorMuro =
                new System.Collections.Generic.Dictionary<
                    long,
                    System.Drawing.RectangleF>();

        private readonly System.Collections.Generic.Dictionary<
            long,
            System.Drawing.RectangleF>
            rectCotaDesarrolloFinPorMuro =
                new System.Collections.Generic.Dictionary<
                    long,
                    System.Drawing.RectangleF>();

        private System.Windows.Forms.TextBox
            txtCotaDesarrolloHorizontalInline;

        private bool editandoCotaDesarrolloHorizontal;
        private bool editandoCotaDesarrolloEsInicio;
        private long editandoCotaDesarrolloMuroId;

        // =========================================================
        // V8.71 - MEMORIA DE DESARROLLO HORIZONTAL POR EXTREMO
        //
        // IMPORTANTE:
        // no se vincula al ID del muro. Se vincula al extremo global
        // INICIO / FIN de la selección.
        // =========================================================
        private bool desarrolloHorizontalInicioRecordadoDefinido;
        private bool desarrolloHorizontalFinRecordadoDefinido;

        private double desarrolloHorizontalInicioRecordadoM;
        private double desarrolloHorizontalFinRecordadoM;

        // =========================================================
        // ZOOM DE LA SECCIÓN CON RUEDA DEL MOUSE
        // =========================================================
        private double zoomSeccion = 1.0;
        private float panSeccionX;
        private float panSeccionY;

        // PAN en la vista de sección:
        // mantener presionada la rueda/botón central y arrastrar.
        private bool paneandoSeccion;
        private System.Drawing.Point ultimoMouseSeccion;

        // =========================================================
        // EDITOR INLINE DE COTA VERTICAL
        // La edición se hace directamente sobre la vista previa.
        // =========================================================
        private System.Windows.Forms.TextBox txtCotaInline;
        private bool editandoCotaInline;
        private bool editandoCotaSuperiorInline;

        public AceroMuroForm()
        {
            Text = "MYG - Acero en Muros";
            Width = 1180;
            Height = 720;
            MinimumSize = new System.Drawing.Size(980, 620);
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = true;
            ShowInTaskbar = true;
            TopMost = true;
            BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            Font = new System.Drawing.Font("Segoe UI", 9F);

            ConstruirInterfaz();

            anguloGanchoInferior =
                ultimoGanchoInferior;

            anguloGanchoSuperior =
                ultimoGanchoSuperior;

            ActualizarControlesLongitudGanchoManual(
                false);

            ConectarEventos();

            FormClosing +=
                (s, e) => GuardarValoresRecordados();

            ActualizarBotonesHerramienta();
            ActualizarAyudasHerramientas();
            ActualizarEstado("Seleccione uno o más muros estructurales.");
        }

        #endregion

        #region 02.2 - CONSTRUCCIÓN DE INTERFAZ

        private void ConstruirInterfaz()
        {
            System.Windows.Forms.Panel barraSuperior =
                new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Top,
                    Height = 58,
                    BackColor = System.Drawing.Color.FromArgb(34, 45, 58)
                };

            System.Windows.Forms.Label titulo =
                new System.Windows.Forms.Label
                {
                    Text = "ACERO EN MUROS",
                    Left = 18,
                    Top = 9,
                    Width = 300,
                    Height = 24,
                    ForeColor = System.Drawing.Color.White,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        12F,
                        System.Drawing.FontStyle.Bold)
                };

            System.Windows.Forms.Label subtitulo =
                new System.Windows.Forms.Label
                {
                    Text = "SECCIÓN DEL MURO + COTAS H PORTABLES ENTRE 1/2/N TRAMOS + EMPALMES Lt",
                    Left = 18,
                    Top = 32,
                    Width = 760,
                    Height = 18,
                    ForeColor = System.Drawing.Color.FromArgb(195, 207, 220)
                };

            // -----------------------------------------------------
            // DATA ARRIBA A LA DERECHA
            //
            // IMPORTANTE:
            // Se usa un panel con DockStyle.Right para que los botones
            // SIEMPRE queden visibles independientemente del ancho con
            // que WinForms inicialice la ventana.
            // -----------------------------------------------------
            System.Windows.Forms.Panel panelDataCabecera =
                new System.Windows.Forms.Panel
                {
                    Dock =
                        System.Windows.Forms.DockStyle.Right,
                    Width = 300,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            34, 45, 58),
                    Padding =
                        new System.Windows.Forms.Padding(
                            4, 12, 10, 10)
                };

            btnGuardarData =
                CrearBotonCabeceraData(
                    "GUARDAR DATA",
                    4,
                    12,
                    134);

            btnCargarData =
                CrearBotonCabeceraData(
                    "CARGAR DATA",
                    144,
                    12,
                    134);

            // No usamos Anchor Right en estos dos botones:
            // el panelDataCabecera ya está anclado por Dock.Right.
            btnGuardarData.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left;

            btnCargarData.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left;

            panelDataCabecera.Controls.Add(
                btnGuardarData);

            panelDataCabecera.Controls.Add(
                btnCargarData);

            barraSuperior.Controls.Add(
                panelDataCabecera);

            barraSuperior.Controls.Add(
                titulo);

            barraSuperior.Controls.Add(
                subtitulo);

            panelDataCabecera.BringToFront();

            System.Windows.Forms.Panel panelDerecho =
                new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Right,
                    Width = 350,
                    AutoScroll = true,
                    BackColor = System.Drawing.Color.FromArgb(245, 247, 250),
                    Padding = new System.Windows.Forms.Padding(10)
                };

            System.Windows.Forms.Panel panelCentro =
                new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Fill,
                    Padding = new System.Windows.Forms.Padding(12)
                };

            tabVistas = new System.Windows.Forms.TabControl
            {
                Dock = System.Windows.Forms.DockStyle.Fill,
                Appearance = System.Windows.Forms.TabAppearance.Normal
            };

            System.Windows.Forms.TabPage tabSeccion =
                new System.Windows.Forms.TabPage
                {
                    Text = "SECCIÓN DEL MURO",
                    BackColor = System.Drawing.Color.White
                };

            System.Windows.Forms.TabPage tabAlzado =
                new System.Windows.Forms.TabPage
                {
                    Text = "ALZADO LONGITUDINAL",
                    BackColor = System.Drawing.Color.White
                };

            pnlVistaSeccion = new AceroMuroPanelDobleBuffer
            {
                Dock = System.Windows.Forms.DockStyle.Fill,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                Cursor = System.Windows.Forms.Cursors.Cross,
                TabStop = true
            };

            pnlVistaAlzado = new AceroMuroPanelDobleBuffer
            {
                Dock = System.Windows.Forms.DockStyle.Fill,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                Cursor = System.Windows.Forms.Cursors.Cross,
                TabStop = true
            };

            // -----------------------------------------------------
            // FRANJA DE EDICIÓN - ALZADO
            // -----------------------------------------------------
            panelEdicionAlzado =
                new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Top,
                    Height = 30,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            246, 247, 249),
                    BorderStyle =
                        System.Windows.Forms.BorderStyle.FixedSingle
                };

            btnAlzSeleccionar =
                CrearBotonFranjaEdicion(
                    "SELECCIONAR", 8, 2, 108);

            btnAlzMoverDosPuntos =
                CrearBotonFranjaEdicion(
                    "MOVER HORIZ.", 120, 2, 112);

            btnAlzCopiarDosPuntos =
                CrearBotonFranjaEdicion(
                    "COPIAR HORIZ.", 236, 2, 112);

            btnAlzRestablecer =
                CrearBotonFranjaEdicion(
                    "RESTABLECER", 352, 2, 105);

            panelEdicionAlzado.Controls.Add(
                btnAlzSeleccionar);
            panelEdicionAlzado.Controls.Add(
                btnAlzMoverDosPuntos);
            panelEdicionAlzado.Controls.Add(
                btnAlzCopiarDosPuntos);
            panelEdicionAlzado.Controls.Add(
                btnAlzRestablecer);

            lblAyudaAlzado =
                new System.Windows.Forms.Label
                {
                    Dock = System.Windows.Forms.DockStyle.Bottom,
                    Height = 24,
                    Text =
                        "Jale el horizontal hasta BORDE/RECUBRIMIENTO del elemento extremo. " +
                        "Aparecerá un candado junto a la manija: clic = bloquear/desbloquear.",
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            248, 249, 251),
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            75, 75, 75),
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI", 7.8F),
                    Padding =
                        new System.Windows.Forms.Padding(
                            6, 4, 4, 2)
                };

            // -----------------------------------------------------
            // FRANJA DE EDICIÓN - SECCIÓN
            // -----------------------------------------------------
            panelEdicionSeccion =
                new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Top,
                    Height = 58,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            246, 247, 249),
                    BorderStyle =
                        System.Windows.Forms.BorderStyle.FixedSingle
                };

            btnSecSeleccionar =
                CrearBotonFranjaEdicion(
                    "SELECCIONAR", 8, 2, 96);

            btnSecMoverDosPuntos =
                CrearBotonFranjaEdicion(
                    "MOVER 2 PTOS", 108, 2, 108);

            btnSecDistribuirDosPuntos =
                CrearBotonFranjaEdicion(
                    "CREAR H 2 PTOS", 220, 2, 116);

            btnSecCrearVerticalDosPuntos =
                CrearBotonFranjaEdicion(
                    "CREAR V 2 PTOS", 340, 2, 116);

            btnSecEliminar =
                CrearBotonFranjaEdicion(
                    "ELIMINAR", 460, 2, 70);

            btnSecDeshacer =
                CrearBotonFranjaEdicion(
                    "↶", 534, 2, 34);

            btnSecRehacer =
                CrearBotonFranjaEdicion(
                    "↷", 572, 2, 34);

            btnSecRestablecer =
                CrearBotonFranjaEdicion(
                    "RESTABLECER", 610, 2, 92);

            System.Windows.Forms.Label lblCantidad2P =
                CrearLabel(
                    "Cant.:",
                    612,
                    5,
                    42,
                    false);

            nudSecCantidadDosPuntos =
                CrearNumerico(
                    4M,
                    656,
                    2,
                    58,
                    2M,
                    200M,
                    0);

            btnSecDeshacer.Font =
                new System.Drawing.Font(
                    "Segoe UI Symbol",
                    12.0F,
                    System.Drawing.FontStyle.Bold);

            btnSecRehacer.Font =
                new System.Drawing.Font(
                    "Segoe UI Symbol",
                    12.0F,
                    System.Drawing.FontStyle.Bold);

            btnSecDeshacer.AccessibleName =
                "Deshacer";

            btnSecRehacer.AccessibleName =
                "Rehacer";

            System.Windows.Forms.ToolTip toolTipEditorSeccion =
                new System.Windows.Forms.ToolTip();

            toolTipEditorSeccion.SetToolTip(
                btnSecEliminar,
                "Elimina el grupo manual 2 PTOS seleccionado o restablece la manija vertical seleccionada.");

            toolTipEditorSeccion.SetToolTip(
                btnSecDeshacer,
                "Deshacer (Ctrl+Z)");

            toolTipEditorSeccion.SetToolTip(
                btnSecRehacer,
                "Rehacer (Ctrl+Y)");

            panelEdicionSeccion.Controls.Add(
                btnSecSeleccionar);
            panelEdicionSeccion.Controls.Add(
                btnSecMoverDosPuntos);
            panelEdicionSeccion.Controls.Add(
                btnSecDistribuirDosPuntos);
            panelEdicionSeccion.Controls.Add(
                btnSecCrearVerticalDosPuntos);
            panelEdicionSeccion.Controls.Add(
                btnSecEliminar);
            panelEdicionSeccion.Controls.Add(
                btnSecDeshacer);
            panelEdicionSeccion.Controls.Add(
                btnSecRehacer);
            panelEdicionSeccion.Controls.Add(
                btnSecRestablecer);
            // La cantidad ya no es global. Cada grupo tiene su propia
            // regla: Espaciado máximo o Número fijo.
            lblCantidad2P.Visible = false;
            nudSecCantidadDosPuntos.Visible = false;

            // -----------------------------------------------------
            // SEGUNDA FILA - LONGITUD MANUAL DE GANCHO
            // -----------------------------------------------------
            chkLongGanchoSupManual =
                new System.Windows.Forms.CheckBox
                {
                    Text = "Long. manual SUP",
                    Left = 8,
                    Top = 31,
                    Width = 128,
                    Height = 23,
                    Checked =
                        ultimoGanchoSuperiorManual
                };

            txtLongGanchoSup =
                CrearTextBoxEntrada(
                    ultimoLongGanchoSuperiorTexto,
                    138,
                    31,
                    64);

            System.Windows.Forms.Label lblLongGanchoSupUnidad =
                CrearLabel(
                    "cm",
                    206,
                    34,
                    28,
                    false);

            chkLongGanchoInfManual =
                new System.Windows.Forms.CheckBox
                {
                    Text = "Long. manual INF",
                    Left = 244,
                    Top = 31,
                    Width = 128,
                    Height = 23,
                    Checked =
                        ultimoGanchoInferiorManual
                };

            txtLongGanchoInf =
                CrearTextBoxEntrada(
                    ultimoLongGanchoInferiorTexto,
                    374,
                    31,
                    64);

            System.Windows.Forms.Label lblLongGanchoInfUnidad =
                CrearLabel(
                    "cm",
                    442,
                    34,
                    28,
                    false);

            panelEdicionSeccion.Controls.Add(
                chkLongGanchoSupManual);

            panelEdicionSeccion.Controls.Add(
                txtLongGanchoSup);

            panelEdicionSeccion.Controls.Add(
                lblLongGanchoSupUnidad);

            panelEdicionSeccion.Controls.Add(
                chkLongGanchoInfManual);

            panelEdicionSeccion.Controls.Add(
                txtLongGanchoInf);

            panelEdicionSeccion.Controls.Add(
                lblLongGanchoInfUnidad);

            lblAyudaSeccion =
                new System.Windows.Forms.Label
                {
                    Dock = System.Windows.Forms.DockStyle.Bottom,
                    Height = 24,
                    Text =
                        "SELECCIONAR: arrastre Cara A, Cara B, borde inferior o superior. " +
                        "Los ajustes se enviarán al acero real.",
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            248, 249, 251),
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            75, 75, 75),
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI", 7.8F),
                    Padding =
                        new System.Windows.Forms.Padding(
                            6, 4, 4, 2)
                };

            // -----------------------------------------------------
            // EDITOR INLINE DE GRUPO HORIZONTAL 2 PUNTOS
            // -----------------------------------------------------
            pnlEditorGrupoHorizontal2P =
                new System.Windows.Forms.Panel
                {
                    Width = 246,
                    Height = 142,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            248, 250, 252),
                    BorderStyle =
                        System.Windows.Forms.BorderStyle.FixedSingle,
                    Visible = false
                };

            System.Windows.Forms.Label lblTituloEditorGrupo =
                new System.Windows.Forms.Label
                {
                    Text = "GRUPO HORIZONTAL",
                    Left = 10,
                    Top = 8,
                    Width = 180,
                    Height = 20,
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            8.5F,
                            System.Drawing.FontStyle.Bold),
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            35, 50, 65)
                };

            btnCerrarEditorGrupoHorizontal2P =
                new System.Windows.Forms.Button
                {
                    Text = "×",
                    Left = 212,
                    Top = 4,
                    Width = 27,
                    Height = 24,
                    FlatStyle =
                        System.Windows.Forms.FlatStyle.Flat,
                    BackColor =
                        System.Drawing.Color.White,
                    TabStop = false
                };

            btnCerrarEditorGrupoHorizontal2P.FlatAppearance.BorderSize = 0;

            System.Windows.Forms.Label lblReglaEditorGrupo =
                CrearLabel(
                    "Regla:",
                    10,
                    38,
                    54,
                    false);

            cmbEditorReglaGrupoHorizontal2P =
                new System.Windows.Forms.ComboBox
                {
                    Left = 66,
                    Top = 34,
                    Width = 164,
                    Height = 24,
                    DropDownStyle =
                        System.Windows.Forms.ComboBoxStyle.DropDownList
                };

            cmbEditorReglaGrupoHorizontal2P.Items.Add(
                "Espaciado máximo");
            cmbEditorReglaGrupoHorizontal2P.Items.Add(
                "Número fijo");

            lblEditorValorGrupoHorizontal2P =
                CrearLabel(
                    "Esp. máx.:",
                    10,
                    70,
                    70,
                    false);

            nudEditorEspaciadoGrupoHorizontal2P =
                new System.Windows.Forms.NumericUpDown
                {
                    Left = 82,
                    Top = 66,
                    Width = 82,
                    Height = 24,
                    DecimalPlaces = 1,
                    Minimum = 0.5M,
                    Maximum = 500.0M,
                    Increment = 0.5M,
                    Value = 20.0M,
                    TextAlign =
                        System.Windows.Forms.HorizontalAlignment.Right
                };

            System.Windows.Forms.Label lblUnidadEditorGrupo =
                CrearLabel(
                    "cm",
                    168,
                    70,
                    28,
                    false);

            nudEditorCantidadGrupoHorizontal2P =
                new System.Windows.Forms.NumericUpDown
                {
                    Left = 82,
                    Top = 66,
                    Width = 82,
                    Height = 24,
                    DecimalPlaces = 0,
                    Minimum = 2M,
                    Maximum = 500M,
                    Increment = 1M,
                    Value = 4M,
                    TextAlign =
                        System.Windows.Forms.HorizontalAlignment.Right,
                    Visible = false
                };

            lblEditorResumenGrupoHorizontal2P =
                new System.Windows.Forms.Label
                {
                    Left = 10,
                    Top = 101,
                    Width = 220,
                    Height = 31,
                    Text = "",
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            70, 80, 90),
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            7.6F)
                };

            pnlEditorGrupoHorizontal2P.Controls.Add(
                lblTituloEditorGrupo);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                btnCerrarEditorGrupoHorizontal2P);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                lblReglaEditorGrupo);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                cmbEditorReglaGrupoHorizontal2P);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                lblEditorValorGrupoHorizontal2P);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                nudEditorEspaciadoGrupoHorizontal2P);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                nudEditorCantidadGrupoHorizontal2P);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                lblUnidadEditorGrupo);
            pnlEditorGrupoHorizontal2P.Controls.Add(
                lblEditorResumenGrupoHorizontal2P);

            pnlVistaSeccion.Controls.Add(
                pnlEditorGrupoHorizontal2P);

            pnlEditorGrupoHorizontal2P.BringToFront();

            tabSeccion.Controls.Add(pnlVistaSeccion);
            tabSeccion.Controls.Add(lblAyudaSeccion);
            tabSeccion.Controls.Add(panelEdicionSeccion);

            tabAlzado.Controls.Add(pnlVistaAlzado);
            tabAlzado.Controls.Add(lblAyudaAlzado);
            tabAlzado.Controls.Add(panelEdicionAlzado);

            panelEdicionSeccion.BringToFront();
            lblAyudaSeccion.BringToFront();
            panelEdicionAlzado.BringToFront();
            lblAyudaAlzado.BringToFront();

            tabVistas.TabPages.Add(tabSeccion);
            tabVistas.TabPages.Add(tabAlzado);

            // IMPORTANTE:
            // La vista que aparece primero es el CORTE PERPENDICULAR AL EJE DEL MURO.
            tabVistas.SelectedIndex = 0;

            panelCentro.Controls.Add(tabVistas);

            int y = 10;

            btnSeleccionar = CrearBotonPrincipal(
                "SELECCIONAR MUROS",
                10,
                y,
                310,
                System.Drawing.Color.FromArgb(0, 120, 215));

            y += 42;

            btnSeleccionarYEjecutar = CrearBotonPrincipal(
                "SELECCIONAR Y EJECUTAR",
                10,
                y,
                310,
                System.Drawing.Color.FromArgb(0, 150, 136));

            System.Windows.Forms.ToolTip toolTipSeleccionEjecutar =
                new System.Windows.Forms.ToolTip();

            toolTipSeleccionEjecutar.SetToolTip(
                btnSeleccionarYEjecutar,
                "Modo continuo: selecciona una serie y pulsa Finalizar para crear el acero; inmediatamente podrás seleccionar la siguiente serie. Pulsa Esc para terminar el modo continuo.");

            y += 46;

            lblCantidad = CrearLabel(
                "Muros seleccionados: 0",
                10,
                y,
                310,
                true);

            y += 24;

            lblCadenas = CrearLabel(
                "Cadenas continuas: 0",
                10,
                y,
                310,
                false);

            y += 30;

            System.Windows.Forms.GroupBox grpSeleccion =
                new System.Windows.Forms.GroupBox
                {
                    Text = "Muros seleccionados",
                    Left = 10,
                    Top = y,
                    Width = 310,
                    Height = 86
                };

            lstMuros = new System.Windows.Forms.ListBox
            {
                Dock = System.Windows.Forms.DockStyle.Fill,
                BorderStyle = System.Windows.Forms.BorderStyle.None,
                IntegralHeight = false
            };

            grpSeleccion.Controls.Add(lstMuros);
            y += 96;

            System.Windows.Forms.GroupBox grpAcero =
                new System.Windows.Forms.GroupBox
                {
                    Text = "Configuración general / grupo seleccionado",
                    Left = 10,
                    Top = y,
                    Width = 310,
                    Height = 350
                };

            chkVerticales = new System.Windows.Forms.CheckBox
            {
                Text = "Habilitar acero vertical",
                Left = 16,
                Top = 24,
                Width = 150,
                Checked = ultimoCrearVertical
            };

            chkHorizontales = new System.Windows.Forms.CheckBox
            {
                Text = "Habilitar acero horizontal",
                Left = 160,
                Top = 24,
                Width = 145,
                Checked = ultimoCrearHorizontal
            };

            grpAcero.Controls.Add(chkVerticales);
            grpAcero.Controls.Add(chkHorizontales);

            // -----------------------------------------------------
            // CONTROLES ANTIGUOS OCULTOS.
            //
            // Ya no son inputs visibles. Solo guardan el último tipo
            // utilizado por orientación para inicializar grupos nuevos.
            // -----------------------------------------------------
            cmbTipoVertical = CrearComboTexto(
                -1000, -1000, 10);

            cmbTipoHorizontal = CrearComboTexto(
                -1000, -1000, 10);

            cmbTipoVertical.Visible = false;
            cmbTipoHorizontal.Visible = false;

            txtEspVertical = CrearTextBoxEntrada(
                ultimoEspVerticalTexto,
                -1000, -1000, 10);

            txtEspHorizontal = CrearTextBoxEntrada(
                ultimoEspHorizontalTexto,
                -1000, -1000, 10);

            txtEspVertical.Visible = false;
            txtEspHorizontal.Visible = false;

            grpAcero.Controls.Add(cmbTipoVertical);
            grpAcero.Controls.Add(cmbTipoHorizontal);
            grpAcero.Controls.Add(txtEspVertical);
            grpAcero.Controls.Add(txtEspHorizontal);

            grpAcero.Controls.Add(
                CrearLabel(
                    "Recubrimiento:",
                    16, 58, 106, false));

            cmbRecubrimiento = CrearComboTexto(
                124, 54, 162);

            cmbRecubrimiento.DropDownWidth = 360;
            cmbRecubrimiento.MaxDropDownItems = 16;
            cmbRecubrimiento.Text =
                ultimoRecubrimientoTexto;

            grpAcero.Controls.Add(
                cmbRecubrimiento);

            grpAcero.Controls.Add(
                CrearLabel(
                    "Malla:",
                    16, 88, 60, false));

            cmbCaras = CrearComboTexto(
                78, 84, 208);

            cmbCaras.Items.Add(
                "Doble malla");

            cmbCaras.Items.Add(
                "Una malla (centrada)");

            cmbCaras.Text =
                NormalizarTextoMalla(
                    ultimoCarasTexto);

            grpAcero.Controls.Add(
                cmbCaras);

            System.Windows.Forms.Panel separadorGrupo =
                new System.Windows.Forms.Panel
                {
                    Left = 12,
                    Top = 118,
                    Width = 286,
                    Height = 1,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            205, 210, 215)
                };

            grpAcero.Controls.Add(
                separadorGrupo);

            lblGrupoSeleccionado =
                new System.Windows.Forms.Label
                {
                    Left = 16,
                    Top = 128,
                    Width = 270,
                    Height = 22,
                    Text = "Grupo seleccionado: ninguno",
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            8.5F,
                            System.Drawing.FontStyle.Bold),
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            55, 65, 75)
                };

            grpAcero.Controls.Add(
                lblGrupoSeleccionado);

            grpAcero.Controls.Add(
                CrearLabel(
                    "Diámetro:",
                    16, 158, 78, false));

            cmbGrupoDiametro =
                CrearComboTexto(
                    96, 154, 190);

            cmbGrupoDiametro.DisplayMember =
                "Name";

            grpAcero.Controls.Add(
                cmbGrupoDiametro);

            grpAcero.Controls.Add(
                CrearLabel(
                    "Regla:",
                    16, 190, 78, false));

            cmbGrupoRegla =
                CrearComboTexto(
                    96, 186, 190);

            cmbGrupoRegla.Items.Add(
                "Espaciado máximo");

            cmbGrupoRegla.Items.Add(
                "Número fijo");

            grpAcero.Controls.Add(
                cmbGrupoRegla);

            lblGrupoValor =
                CrearLabel(
                    "Espaciado máx.:",
                    16, 222, 108, false);

            grpAcero.Controls.Add(
                lblGrupoValor);

            txtGrupoValor =
                CrearTextBoxEntrada(
                    "",
                    126, 218, 88);

            grpAcero.Controls.Add(
                txtGrupoValor);

            lblGrupoUnidad =
                CrearLabel(
                    "cm",
                    220, 222, 62, false);

            grpAcero.Controls.Add(
                lblGrupoUnidad);

            btnAplicarCambiosGrupo =
                CrearBotonPrincipal(
                    "APLICAR CAMBIOS",
                    16,
                    252,
                    270,
                    System.Drawing.Color.FromArgb(
                        0, 120, 215));

            btnAplicarCambiosGrupo.Height = 34;
            btnAplicarCambiosGrupo.Enabled = false;

            grpAcero.Controls.Add(
                btnAplicarCambiosGrupo);

            lblGrupoEstado =
                new System.Windows.Forms.Label
                {
                    Left = 16,
                    Top = 292,
                    Width = 270,
                    Height = 42,
                    Text =
                        "Seleccione un grupo H o V en la sección para editarlo.",
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            90, 95, 100)
                };

            grpAcero.Controls.Add(
                lblGrupoEstado);

            y += 360;

            chkContinuos = new System.Windows.Forms.CheckBox
            {
                Text = "Horizontales continuos por cadena",
                Left = 16,
                Top = y,
                Width = 280,
                Height = 24,
                Checked = ultimoContinuos
            };

            y += 28;

            // -----------------------------------------------------
            // EMPALMES HORIZONTALES
            // -----------------------------------------------------
            chkConsiderarEmpalme = new System.Windows.Forms.CheckBox
            {
                Text = "Considerar empalme libre",
                Left = 16,
                Top = y,
                Width = 142,
                Height = 24,
                Checked = ultimoConsiderarEmpalme
            };

            System.Windows.Forms.Label lblLongCom =
                CrearLabel(
                    "L. comercial:",
                    158,
                    y + 4,
                    72,
                    false);

            txtLongitudComercial =
                CrearTextBoxEntrada(
                    ultimaLongitudComercialTexto,
                    230,
                    y,
                    54);

            System.Windows.Forms.Label lblLongComUnidad =
                CrearLabel(
                    "m",
                    288,
                    y + 4,
                    20,
                    false);

            txtLongitudComercial.Enabled =
                ultimoConsiderarEmpalme;

            y += 28;

            btnConfigurarEmpalmes =
                new System.Windows.Forms.Button
                {
                    Text = "CONFIGURAR Lt POR Ø",
                    Left = 16,
                    Top = y,
                    Width = 270,
                    Height = 26,
                    FlatStyle =
                        System.Windows.Forms.FlatStyle.Flat,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            226,
                            236,
                            247),
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            25,
                            75,
                            120),
                    Visible =
                        ultimoConsiderarEmpalme,
                    Enabled =
                        ultimoConsiderarEmpalme &&
                        ultimoCrearHorizontal
                };

            y += 30;

            // -----------------------------------------------------
            // V8.77 - REFUERZO DIAGONAL AUTOMÁTICO EN HUECOS
            // -----------------------------------------------------
            chkRefuerzoHuecos =
                new System.Windows.Forms.CheckBox
                {
                    Text = "Refuerzo diagonal automático en huecos",
                    Left = 16,
                    Top = y,
                    Width = 286,
                    Height = 24,
                    Checked =
                        ultimoCrearRefuerzoHuecos
                };

            y += 27;

            lblRefuerzoHuecosDiametro =
                CrearLabel(
                    "Ø:",
                    16,
                    y + 4,
                    20,
                    false);

            cmbRefuerzoHuecosDiametro =
                CrearComboTexto(
                    36,
                    y,
                    112);

            cmbRefuerzoHuecosDiametro.DisplayMember =
                "Name";

            lblRefuerzoHuecosLongitud =
                CrearLabel(
                    "L.:",
                    156,
                    y + 4,
                    22,
                    false);

            txtLongitudRefuerzoHuecos =
                CrearTextBoxEntrada(
                    ultimaLongitudRefuerzoHuecosTexto,
                    180,
                    y,
                    72);

            lblRefuerzoHuecosUnidad =
                CrearLabel(
                    "m",
                    257,
                    y + 4,
                    24,
                    false);

            bool mostrarOpcionesRefuerzoHuecos =
                ultimoCrearRefuerzoHuecos;

            lblRefuerzoHuecosDiametro.Visible =
                mostrarOpcionesRefuerzoHuecos;

            cmbRefuerzoHuecosDiametro.Visible =
                mostrarOpcionesRefuerzoHuecos;

            lblRefuerzoHuecosLongitud.Visible =
                mostrarOpcionesRefuerzoHuecos;

            txtLongitudRefuerzoHuecos.Visible =
                mostrarOpcionesRefuerzoHuecos;

            lblRefuerzoHuecosUnidad.Visible =
                mostrarOpcionesRefuerzoHuecos;

            y += 30;

            chkVerSinTapar = new System.Windows.Forms.CheckBox
            {
                Text = "Ver elementos sin tapar en vista activa",
                Left = 16,
                Top = y,
                Width = 300,
                Height = 24,
                Checked = ultimoVerSinTapar
            };

            y += 32;

            btnCrear = CrearBotonPrincipal(
                "CREAR ACERO",
                10,
                y,
                310,
                System.Drawing.Color.FromArgb(35, 143, 82));

            y += 46;

            System.Windows.Forms.Button btnCerrar =
                CrearBotonPrincipal(
                    "CERRAR",
                    10,
                    y,
                    310,
                    System.Drawing.Color.FromArgb(105, 112, 120));

            btnCerrar.Click +=
                (s, e) => Close();

            y += 44;

            lblEstado = new System.Windows.Forms.Label
            {
                Left = 10,
                Top = y,
                Width = 310,
                Height = 54,
                ForeColor = System.Drawing.Color.FromArgb(65, 65, 65),
                AutoEllipsis = true
            };

            panelDerecho.Controls.Add(btnSeleccionar);
            panelDerecho.Controls.Add(btnSeleccionarYEjecutar);
            panelDerecho.Controls.Add(lblCantidad);
            panelDerecho.Controls.Add(lblCadenas);
            panelDerecho.Controls.Add(grpSeleccion);
            panelDerecho.Controls.Add(grpAcero);
            panelDerecho.Controls.Add(chkContinuos);
            panelDerecho.Controls.Add(chkConsiderarEmpalme);
            panelDerecho.Controls.Add(lblLongCom);
            panelDerecho.Controls.Add(txtLongitudComercial);
            panelDerecho.Controls.Add(lblLongComUnidad);
            panelDerecho.Controls.Add(btnConfigurarEmpalmes);

            panelDerecho.Controls.Add(chkRefuerzoHuecos);
            panelDerecho.Controls.Add(lblRefuerzoHuecosDiametro);
            panelDerecho.Controls.Add(cmbRefuerzoHuecosDiametro);
            panelDerecho.Controls.Add(lblRefuerzoHuecosLongitud);
            panelDerecho.Controls.Add(txtLongitudRefuerzoHuecos);
            panelDerecho.Controls.Add(lblRefuerzoHuecosUnidad);

            panelDerecho.Controls.Add(chkVerSinTapar);
            panelDerecho.Controls.Add(btnCrear);
            panelDerecho.Controls.Add(btnCerrar);
            panelDerecho.Controls.Add(lblEstado);

            Controls.Add(panelCentro);
            Controls.Add(panelDerecho);
            Controls.Add(barraSuperior);
        }

        private Autodesk.Revit.DB.Structure.RebarBarType
            ResolverTipoBarraGrupo(
                long tipoId,
                string nombre,
                System.Windows.Forms.ComboBox fallback)
        {
            if (tipoId > 0)
            {
                foreach (
                    Autodesk.Revit.DB.Structure.RebarBarType tipo
                    in tiposArmaduraDisponibles)
                {
                    if (tipo != null &&
                        tipo.Id != null &&
                        tipo.Id.Value == tipoId)
                    {
                        return tipo;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(nombre))
            {
                foreach (
                    Autodesk.Revit.DB.Structure.RebarBarType tipo
                    in tiposArmaduraDisponibles)
                {
                    if (tipo != null &&
                        string.Equals(
                            tipo.Name,
                            nombre.Trim(),
                            System.StringComparison.OrdinalIgnoreCase))
                    {
                        return tipo;
                    }
                }
            }

            return
                ResolverTipoBarra(
                    fallback);
        }

        private Autodesk.Revit.DB.Structure.RebarBarType
            ObtenerTipoPorDefectoGrupo(
                bool vertical)
        {
            Autodesk.Revit.DB.Structure.RebarBarType tipo =
                ResolverTipoBarra(
                    vertical
                        ? cmbTipoVertical
                        : cmbTipoHorizontal);

            if (tipo != null)
                return tipo;

            if (tiposArmaduraDisponibles.Count > 0)
                return tiposArmaduraDisponibles[0];

            return null;
        }

        private bool CtrlPresionado()
        {
            return
                (System.Windows.Forms.Control.ModifierKeys &
                 System.Windows.Forms.Keys.Control) ==
                System.Windows.Forms.Keys.Control;
        }

        private int ObtenerCantidadGruposSeleccionados()
        {
            return
                gruposHorizontales2PSeleccionados.Count +
                gruposVerticales2PSeleccionados.Count;
        }

        private bool EsGrupoHorizontalSeleccionado(
            string id)
        {
            return
                !string.IsNullOrWhiteSpace(id) &&
                gruposHorizontales2PSeleccionados.Contains(
                    id);
        }

        private bool EsGrupoVerticalSeleccionado(
            string id)
        {
            return
                !string.IsNullOrWhiteSpace(id) &&
                gruposVerticales2PSeleccionados.Contains(
                    id);
        }

        private void DepurarSeleccionMultiple()
        {
            System.Collections.Generic.List<string> borrarH =
                new System.Collections.Generic.List<string>();

            foreach (
                string id
                in gruposHorizontales2PSeleccionados)
            {
                if (ObtenerGrupoHorizontal2PuntosPorId(
                        id) == null)
                {
                    borrarH.Add(id);
                }
            }

            foreach (string id in borrarH)
                gruposHorizontales2PSeleccionados.Remove(id);

            System.Collections.Generic.List<string> borrarV =
                new System.Collections.Generic.List<string>();

            foreach (
                string id
                in gruposVerticales2PSeleccionados)
            {
                if (ObtenerGrupoVertical2PuntosPorId(
                        id) == null)
                {
                    borrarV.Add(id);
                }
            }

            foreach (string id in borrarV)
                gruposVerticales2PSeleccionados.Remove(id);

            if (!string.IsNullOrWhiteSpace(
                    grupoHorizontal2PSeleccionadoId) &&
                !gruposHorizontales2PSeleccionados.Contains(
                    grupoHorizontal2PSeleccionadoId))
            {
                grupoHorizontal2PSeleccionadoId = "";
            }

            if (!string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId) &&
                !gruposVerticales2PSeleccionados.Contains(
                    grupoVertical2PSeleccionadoId))
            {
                grupoVertical2PSeleccionadoId = "";
            }

            if (string.IsNullOrWhiteSpace(
                    grupoHorizontal2PSeleccionadoId) &&
                string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId))
            {
                foreach (
                    string id
                    in gruposVerticales2PSeleccionados)
                {
                    grupoVertical2PSeleccionadoId = id;
                    return;
                }

                foreach (
                    string id
                    in gruposHorizontales2PSeleccionados)
                {
                    grupoHorizontal2PSeleccionadoId = id;
                    return;
                }
            }
        }

        private void LimpiarSeleccionMultipleGrupos(
            bool actualizarPanel)
        {
            gruposHorizontales2PSeleccionados.Clear();
            gruposVerticales2PSeleccionados.Clear();

            grupoHorizontal2PSeleccionadoId = "";
            grupoVertical2PSeleccionadoId = "";

            if (actualizarPanel)
                ActualizarPanelGrupoSeleccionado();
        }

        private void SeleccionarSoloGrupoHorizontal(
            string id)
        {
            gruposHorizontales2PSeleccionados.Clear();
            gruposVerticales2PSeleccionados.Clear();

            if (!string.IsNullOrWhiteSpace(id))
            {
                gruposHorizontales2PSeleccionados.Add(id);
                grupoHorizontal2PSeleccionadoId = id;
            }
            else
            {
                grupoHorizontal2PSeleccionadoId = "";
            }

            grupoVertical2PSeleccionadoId = "";
        }

        private void SeleccionarSoloGrupoVertical(
            string id)
        {
            gruposHorizontales2PSeleccionados.Clear();
            gruposVerticales2PSeleccionados.Clear();

            if (!string.IsNullOrWhiteSpace(id))
            {
                gruposVerticales2PSeleccionados.Add(id);
                grupoVertical2PSeleccionadoId = id;
            }
            else
            {
                grupoVertical2PSeleccionadoId = "";
            }

            grupoHorizontal2PSeleccionadoId = "";
        }

        private void AlternarSeleccionGrupoHorizontal(
            string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return;

            if (gruposHorizontales2PSeleccionados.Contains(
                    id))
            {
                gruposHorizontales2PSeleccionados.Remove(
                    id);

                if (string.Equals(
                        grupoHorizontal2PSeleccionadoId,
                        id,
                        System.StringComparison.Ordinal))
                {
                    grupoHorizontal2PSeleccionadoId = "";
                }
            }
            else
            {
                gruposHorizontales2PSeleccionados.Add(
                    id);

                grupoHorizontal2PSeleccionadoId = id;
                grupoVertical2PSeleccionadoId = "";
            }

            DepurarSeleccionMultiple();
        }

        private void AlternarSeleccionGrupoVertical(
            string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return;

            if (gruposVerticales2PSeleccionados.Contains(
                    id))
            {
                gruposVerticales2PSeleccionados.Remove(
                    id);

                if (string.Equals(
                        grupoVertical2PSeleccionadoId,
                        id,
                        System.StringComparison.Ordinal))
                {
                    grupoVertical2PSeleccionadoId = "";
                }
            }
            else
            {
                gruposVerticales2PSeleccionados.Add(
                    id);

                grupoVertical2PSeleccionadoId = id;
                grupoHorizontal2PSeleccionadoId = "";
            }

            DepurarSeleccionMultiple();
        }

        private void ActualizarSeleccionGrupoHorizontalDesdeClick(
            string id,
            bool ctrl)
        {
            if (ctrl)
                AlternarSeleccionGrupoHorizontal(id);
            else
                SeleccionarSoloGrupoHorizontal(id);

            ActualizarPanelGrupoSeleccionado();
        }

        private void ActualizarSeleccionGrupoVerticalDesdeClick(
            string id,
            bool ctrl)
        {
            if (ctrl)
                AlternarSeleccionGrupoVertical(id);
            else
                SeleccionarSoloGrupoVertical(id);

            ActualizarPanelGrupoSeleccionado();
        }

        private System.Collections.Generic.List<
            AceroMuroGrupoHorizontal2Puntos>
            ObtenerGruposHorizontalesSeleccionados()
        {
            DepurarSeleccionMultiple();

            System.Collections.Generic.List<
                AceroMuroGrupoHorizontal2Puntos> lista =
                    new System.Collections.Generic.List<
                        AceroMuroGrupoHorizontal2Puntos>();

            foreach (
                string id
                in gruposHorizontales2PSeleccionados)
            {
                AceroMuroGrupoHorizontal2Puntos grupo =
                    ObtenerGrupoHorizontal2PuntosPorId(
                        id);

                if (grupo != null)
                    lista.Add(grupo);
            }

            return lista;
        }

        private System.Collections.Generic.List<
            AceroMuroGrupoVertical2Puntos>
            ObtenerGruposVerticalesSeleccionados()
        {
            DepurarSeleccionMultiple();

            System.Collections.Generic.List<
                AceroMuroGrupoVertical2Puntos> lista =
                    new System.Collections.Generic.List<
                        AceroMuroGrupoVertical2Puntos>();

            foreach (
                string id
                in gruposVerticales2PSeleccionados)
            {
                AceroMuroGrupoVertical2Puntos grupo =
                    ObtenerGrupoVertical2PuntosPorId(
                        id);

                if (grupo != null)
                    lista.Add(grupo);
            }

            return lista;
        }


        private bool TryObtenerGrupoSeleccionado(
            out AceroMuroGrupoHorizontal2Puntos grupoH,
            out AceroMuroGrupoVertical2Puntos grupoV)
        {
            grupoH = null;
            grupoV = null;

            DepurarSeleccionMultiple();

            if (!string.IsNullOrWhiteSpace(
                    grupoHorizontal2PSeleccionadoId))
            {
                grupoH =
                    ObtenerGrupoHorizontal2PuntosPorId(
                        grupoHorizontal2PSeleccionadoId);

                if (grupoH != null)
                    return true;
            }

            if (!string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId))
            {
                grupoV =
                    ObtenerGrupoVertical2PuntosPorId(
                        grupoVertical2PSeleccionadoId);

                if (grupoV != null)
                    return true;
            }

            foreach (
                string id
                in gruposVerticales2PSeleccionados)
            {
                grupoV =
                    ObtenerGrupoVertical2PuntosPorId(
                        id);

                if (grupoV != null)
                {
                    grupoVertical2PSeleccionadoId = id;
                    return true;
                }
            }

            foreach (
                string id
                in gruposHorizontales2PSeleccionados)
            {
                grupoH =
                    ObtenerGrupoHorizontal2PuntosPorId(
                        id);

                if (grupoH != null)
                {
                    grupoHorizontal2PSeleccionadoId = id;
                    return true;
                }
            }

            return false;
        }

        private void SeleccionarComboTipoPorGrupo(
            System.Windows.Forms.ComboBox combo,
            long tipoId,
            string nombre,
            bool vertical)
        {
            if (combo == null)
                return;

            Autodesk.Revit.DB.Structure.RebarBarType tipo =
                ResolverTipoBarraGrupo(
                    tipoId,
                    nombre,
                    vertical
                        ? cmbTipoVertical
                        : cmbTipoHorizontal);

            if (tipo == null)
            {
                combo.Text = "";
                return;
            }

            combo.SelectedItem =
                tipo;

            combo.Text =
                tipo.Name;
        }

        private void ActualizarEtiquetaValorGrupo()
        {
            if (lblGrupoValor == null ||
                lblGrupoUnidad == null ||
                cmbGrupoRegla == null)
            {
                return;
            }

            bool numeroFijo =
                cmbGrupoRegla.Text.Trim()
                    .Equals(
                        "Número fijo",
                        System.StringComparison.OrdinalIgnoreCase);

            lblGrupoValor.Text =
                numeroFijo
                    ? "Número fijo:"
                    : "Espaciado máx.:";

            lblGrupoUnidad.Text =
                numeroFijo
                    ? "barras"
                    : "cm";
        }

        private void MarcarPanelGrupoConCambios()
        {
            if (actualizandoPanelGrupoSeleccionado)
                return;

            AceroMuroGrupoHorizontal2Puntos grupoH;
            AceroMuroGrupoVertical2Puntos grupoV;

            if (!TryObtenerGrupoSeleccionado(
                    out grupoH,
                    out grupoV))
            {
                return;
            }

            panelGrupoTieneCambios = true;

            if (btnAplicarCambiosGrupo != null)
            {
                btnAplicarCambiosGrupo.Enabled = true;
                btnAplicarCambiosGrupo.Text =
                    "APLICAR CAMBIOS *";
            }

            if (lblGrupoEstado != null)
            {
                lblGrupoEstado.Text =
                    "Hay cambios pendientes. Pulse APLICAR CAMBIOS para actualizar este grupo.";
            }
        }

        private void PanelGrupoSeleccionado_Cambio(
            object sender,
            System.EventArgs e)
        {
            MarcarPanelGrupoConCambios();
        }

        private void PanelGrupoRegla_Cambio(
            object sender,
            System.EventArgs e)
        {
            ActualizarEtiquetaValorGrupo();
            MarcarPanelGrupoConCambios();
        }

        private void ActualizarPanelGrupoSeleccionado()
        {
            if (cmbGrupoDiametro == null ||
                cmbGrupoRegla == null ||
                txtGrupoValor == null ||
                btnAplicarCambiosGrupo == null)
            {
                return;
            }

            actualizandoPanelGrupoSeleccionado = true;

            try
            {
                AceroMuroGrupoHorizontal2Puntos grupoH;
                AceroMuroGrupoVertical2Puntos grupoV;

                bool tieneGrupo =
                    TryObtenerGrupoSeleccionado(
                        out grupoH,
                        out grupoV);

                cmbGrupoDiametro.Enabled =
                    tieneGrupo;

                cmbGrupoRegla.Enabled =
                    tieneGrupo;

                txtGrupoValor.Enabled =
                    tieneGrupo;

                btnAplicarCambiosGrupo.Enabled =
                    false;

                btnAplicarCambiosGrupo.Text =
                    "APLICAR CAMBIOS";

                panelGrupoTieneCambios =
                    false;

                if (!tieneGrupo)
                {
                    lblGrupoSeleccionado.Text =
                        "Grupo seleccionado: ninguno";

                    cmbGrupoDiametro.Text = "";
                    cmbGrupoRegla.Text = "";
                    txtGrupoValor.Text = "";

                    lblGrupoValor.Text =
                        "Espaciado máx.:";

                    lblGrupoUnidad.Text =
                        "cm";

                    lblGrupoEstado.Text =
                        "Seleccione un grupo H o V en la sección para editarlo.";

                    return;
                }

                bool vertical =
                    grupoV != null;

                long tipoId =
                    vertical
                        ? grupoV.TipoBarraId
                        : grupoH.TipoBarraId;

                string tipoNombre =
                    vertical
                        ? grupoV.TipoBarraNombre
                        : grupoH.TipoBarraNombre;

                AceroMuroReglaDistribucionGrupo regla =
                    vertical
                        ? grupoV.ReglaDistribucion
                        : grupoH.ReglaDistribucion;

                double esp =
                    vertical
                        ? grupoV.EspaciamientoMaximoCm
                        : grupoH.EspaciamientoMaximoCm;

                int cantidad =
                    vertical
                        ? grupoV.Cantidad
                        : grupoH.Cantidad;

                int cantidadSeleccionada =
                    ObtenerCantidadGruposSeleccionados();

                if (cantidadSeleccionada <= 1)
                {
                    lblGrupoSeleccionado.Text =
                        vertical
                            ? "Grupo seleccionado: VERTICAL"
                            : "Grupo seleccionado: HORIZONTAL";
                }
                else
                {
                    int cantidadH =
                        gruposHorizontales2PSeleccionados.Count;

                    int cantidadV =
                        gruposVerticales2PSeleccionados.Count;

                    lblGrupoSeleccionado.Text =
                        "Grupos seleccionados: " +
                        cantidadSeleccionada +
                        "  (H:" +
                        cantidadH +
                        " / V:" +
                        cantidadV +
                        ")";
                }

                SeleccionarComboTipoPorGrupo(
                    cmbGrupoDiametro,
                    tipoId,
                    tipoNombre,
                    vertical);

                cmbGrupoRegla.Text =
                    regla ==
                        AceroMuroReglaDistribucionGrupo.NumeroFijo
                        ? "Número fijo"
                        : "Espaciado máximo";

                if (regla ==
                    AceroMuroReglaDistribucionGrupo.NumeroFijo)
                {
                    txtGrupoValor.Text =
                        System.Math.Max(
                            2,
                            cantidad)
                        .ToString();
                }
                else
                {
                    txtGrupoValor.Text =
                        System.Math.Max(
                            0.1,
                            esp)
                        .ToString(
                            "0.##",
                            System.Globalization.CultureInfo.InvariantCulture);
                }

                ActualizarEtiquetaValorGrupo();

                if (cantidadSeleccionada <= 1)
                {
                    lblGrupoEstado.Text =
                        vertical
                            ? "Configuración independiente del grupo vertical seleccionado."
                            : "Configuración independiente del grupo horizontal seleccionado.";
                }
                else
                {
                    lblGrupoEstado.Text =
                        "CTRL mantiene la selección. Los valores mostrados son del grupo activo; APLICAR CAMBIOS afectará a los " +
                        cantidadSeleccionada +
                        " grupos seleccionados.";
                }

                // La guía de la orientación seleccionada utiliza
                // temporalmente el tipo propio de ese grupo.
                Autodesk.Revit.DB.Structure.RebarBarType tipo =
                    ResolverTipoBarraGrupo(
                        tipoId,
                        tipoNombre,
                        vertical
                            ? cmbTipoVertical
                            : cmbTipoHorizontal);

                if (tipo != null)
                {
                    if (vertical)
                    {
                        cmbTipoVertical.SelectedItem =
                            tipo;

                        cmbTipoVertical.Text =
                            tipo.Name;
                    }
                    else
                    {
                        cmbTipoHorizontal.SelectedItem =
                            tipo;

                        cmbTipoHorizontal.Text =
                            tipo.Name;
                    }
                }
            }
            finally
            {
                actualizandoPanelGrupoSeleccionado = false;
            }
        }

        private void BtnAplicarCambiosGrupo_Click(
            object sender,
            System.EventArgs e)
        {
            System.Collections.Generic.List<
                AceroMuroGrupoHorizontal2Puntos> gruposH =
                    ObtenerGruposHorizontalesSeleccionados();

            System.Collections.Generic.List<
                AceroMuroGrupoVertical2Puntos> gruposV =
                    ObtenerGruposVerticalesSeleccionados();

            if (gruposH.Count == 0 &&
                gruposV.Count == 0)
            {
                return;
            }

            Autodesk.Revit.DB.Structure.RebarBarType tipo =
                ResolverTipoBarra(
                    cmbGrupoDiametro);

            if (tipo == null)
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    "Seleccione un diámetro/tipo de barra existente de Revit.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            string reglaTexto =
                cmbGrupoRegla.Text.Trim();

            AceroMuroReglaDistribucionGrupo regla;

            if (reglaTexto.Equals(
                    "Número fijo",
                    System.StringComparison.OrdinalIgnoreCase))
            {
                regla =
                    AceroMuroReglaDistribucionGrupo.NumeroFijo;
            }
            else if (reglaTexto.Equals(
                    "Espaciado máximo",
                    System.StringComparison.OrdinalIgnoreCase))
            {
                regla =
                    AceroMuroReglaDistribucionGrupo.EspaciadoMaximo;
            }
            else
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    "La regla debe ser 'Espaciado máximo' o 'Número fijo'.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            double espaciadoCm =
                20.0;

            int cantidad =
                4;

            if (regla ==
                AceroMuroReglaDistribucionGrupo.NumeroFijo)
            {
                int n;

                if (!int.TryParse(
                        txtGrupoValor.Text.Trim(),
                        out n) ||
                    n < 2)
                {
                    System.Windows.Forms.MessageBox.Show(
                        this,
                        "El número fijo debe ser un entero mayor o igual a 2.",
                        "MYG",
                        System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Warning);

                    return;
                }

                cantidad = n;
            }
            else
            {
                if (!TryLeerLongitudCm(
                        txtGrupoValor.Text,
                        out espaciadoCm) ||
                    espaciadoCm <= 0.0)
                {
                    System.Windows.Forms.MessageBox.Show(
                        this,
                        "Ingrese un espaciamiento máximo válido en cm.",
                        "MYG",
                        System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Warning);

                    return;
                }
            }

            RegistrarDeshacer();

            foreach (
                AceroMuroGrupoVertical2Puntos grupoV
                in gruposV)
            {
                if (grupoV == null)
                    continue;

                grupoV.TipoBarraId =
                    tipo.Id.Value;

                grupoV.TipoBarraNombre =
                    tipo.Name;

                grupoV.ReglaDistribucion =
                    regla;

                if (regla ==
                    AceroMuroReglaDistribucionGrupo.NumeroFijo)
                {
                    grupoV.Cantidad =
                        cantidad;
                }
                else
                {
                    grupoV.EspaciamientoMaximoCm =
                        espaciadoCm;
                }

                VincularPuntoVerticalLegacySiCorresponde(
                    grupoV,
                    true,
                    ObtenerRecubrimientoCmActual());

                VincularPuntoVerticalLegacySiCorresponde(
                    grupoV,
                    false,
                    ObtenerRecubrimientoCmActual());
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupoH
                in gruposH)
            {
                if (grupoH == null)
                    continue;

                grupoH.TipoBarraId =
                    tipo.Id.Value;

                grupoH.TipoBarraNombre =
                    tipo.Name;

                grupoH.ReglaDistribucion =
                    regla;

                if (regla ==
                    AceroMuroReglaDistribucionGrupo.NumeroFijo)
                {
                    grupoH.Cantidad =
                        cantidad;
                }
                else
                {
                    grupoH.EspaciamientoMaximoCm =
                        espaciadoCm;
                }
            }

            if (gruposV.Count > 0)
            {
                cmbTipoVertical.SelectedItem =
                    tipo;

                cmbTipoVertical.Text =
                    tipo.Name;

                if (regla ==
                    AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
                {
                    txtEspVertical.Text =
                        espaciadoCm.ToString(
                            "0.##",
                            System.Globalization.CultureInfo.InvariantCulture);
                }

                ActualizarGruposVerticalesVinculadosAGuias();
            }

            if (gruposH.Count > 0)
            {
                cmbTipoHorizontal.SelectedItem =
                    tipo;

                cmbTipoHorizontal.Text =
                    tipo.Name;

                if (regla ==
                    AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
                {
                    txtEspHorizontal.Text =
                        espaciadoCm.ToString(
                            "0.##",
                            System.Globalization.CultureInfo.InvariantCulture);
                }

                ActualizarGruposVinculadosAGuiasSeccion();
            }

            GuardarValoresRecordados();

            panelGrupoTieneCambios =
                false;

            ActualizarPanelGrupoSeleccionado();

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Invalidate();

            if (pnlVistaAlzado != null)
                pnlVistaAlzado.Invalidate();

            int total =
                gruposH.Count +
                gruposV.Count;

            ActualizarEstado(
                total <= 1
                    ? "Cambios aplicados al grupo seleccionado."
                    : "Cambios aplicados a " +
                        total +
                        " grupos seleccionados.");
        }


        private double ObtenerLongitudEmpalmePredeterminadaCm(
            double diametroMm)
        {
            // Tabla indicada por el usuario + 5 cm:
            // 3/8"  45 -> 50 cm
            // 12 mm 55 -> 60 cm
            // 1/2"  60 -> 65 cm
            // 5/8"  75 -> 80 cm
            // 3/4"  85 -> 90 cm
            if (System.Math.Abs(
                    diametroMm -
                    9.525) <=
                0.25)
            {
                return 50.0;
            }

            if (System.Math.Abs(
                    diametroMm -
                    12.0) <=
                0.20)
            {
                return 60.0;
            }

            if (System.Math.Abs(
                    diametroMm -
                    12.7) <=
                0.20)
            {
                return 65.0;
            }

            if (System.Math.Abs(
                    diametroMm -
                    15.875) <=
                0.25)
            {
                return 80.0;
            }

            if (System.Math.Abs(
                    diametroMm -
                    19.05) <=
                0.25)
            {
                return 90.0;
            }

            // Para cualquier otro diámetro del proyecto:
            // criterio previo 60db, mínimo 30 cm, también +5 cm.
            double baseCm =
                System.Math.Max(
                    diametroMm * 6.0,
                    30.0);

            return
                baseCm +
                5.0;
        }


        private void AsegurarEmpalmesPorDiametroDisponibles()
        {
            // Restaurar memoria de la sesión solo si todavía no tenemos
            // una tabla activa en esta instancia.
            if (empalmesPorDiametro.Count == 0 &&
                ultimosEmpalmesPorDiametro.Count > 0)
            {
                foreach (
                    AceroMuroEmpalmeDiametroData item
                    in ultimosEmpalmesPorDiametro)
                {
                    if (item != null)
                        empalmesPorDiametro.Add(
                            item.Copiar());
                }
            }

            foreach (
                Autodesk.Revit.DB.Structure.RebarBarType tipo
                in tiposArmaduraDisponibles)
            {
                if (tipo == null)
                    continue;

                double diametroPies =
                    ObtenerDiametroBarraVistaDesdeTipo(
                        tipo);

                if (diametroPies <= 0.0)
                    continue;

                double diametroMm =
                    Autodesk.Revit.DB.UnitUtils.ConvertFromInternalUnits(
                        diametroPies,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

                AceroMuroEmpalmeDiametroData existente =
                    empalmesPorDiametro.Find(
                        x =>
                            x != null &&
                            System.Math.Abs(
                                x.DiametroMm -
                                diametroMm) <=
                            0.20);

                string etiqueta =
                    ObtenerTextoDiametroLeyenda(
                        tipo,
                        diametroPies);

                if (existente != null)
                {
                    if (string.IsNullOrWhiteSpace(
                        existente.Etiqueta))
                    {
                        existente.Etiqueta =
                            etiqueta;
                    }

                    continue;
                }

                empalmesPorDiametro.Add(
                    new AceroMuroEmpalmeDiametroData
                    {
                        DiametroMm =
                            diametroMm,
                        Etiqueta =
                            etiqueta,
                        LongitudEmpalmeCm =
                            ObtenerLongitudEmpalmePredeterminadaCm(
                                diametroMm)
                    });
            }

            empalmesPorDiametro.Sort(
                (a, b) =>
                {
                    if (a == null && b == null)
                        return 0;

                    if (a == null)
                        return 1;

                    if (b == null)
                        return -1;

                    return
                        a.DiametroMm.CompareTo(
                            b.DiametroMm);
                });

            ultimosEmpalmesPorDiametro.Clear();

            foreach (
                AceroMuroEmpalmeDiametroData item
                in empalmesPorDiametro)
            {
                if (item != null)
                    ultimosEmpalmesPorDiametro.Add(
                        item.Copiar());
            }

            if (btnConfigurarEmpalmes != null)
            {
                btnConfigurarEmpalmes.Text =
                    "CONFIGURAR Lt POR Ø  (" +
                    empalmesPorDiametro.Count +
                    ")";
            }
        }


        private void MostrarEditorEmpalmesPorDiametro()
        {
            AsegurarEmpalmesPorDiametroDisponibles();

            if (empalmesPorDiametro.Count == 0)
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    "No se encontraron diámetros de armadura disponibles en el proyecto.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            using (
                AceroMuroEmpalmesPorDiametroForm editor =
                    new AceroMuroEmpalmesPorDiametroForm(
                        empalmesPorDiametro,
                        ObtenerLongitudEmpalmePredeterminadaCm))
            {
                System.Windows.Forms.DialogResult resultado =
                    editor.ShowDialog(
                        this);

                if (resultado !=
                    System.Windows.Forms.DialogResult.OK)
                {
                    return;
                }

                empalmesPorDiametro.Clear();

                foreach (
                    AceroMuroEmpalmeDiametroData item
                    in editor.Valores)
                {
                    if (item != null)
                        empalmesPorDiametro.Add(
                            item.Copiar());
                }

                AsegurarEmpalmesPorDiametroDisponibles();

                GuardarValoresRecordados();

                ActualizarEstado(
                    "Longitudes de empalme por diámetro actualizadas.");

                if (pnlVistaAlzado != null)
                    pnlVistaAlzado.Invalidate();
            }
        }


        private System.Windows.Forms.ComboBox CrearComboTexto(
            int left,
            int top,
            int width)
        {
            return new System.Windows.Forms.ComboBox
            {
                Left = left,
                Top = top,
                Width = width,
                Height = 24,
                DropDownStyle =
                    System.Windows.Forms.ComboBoxStyle.DropDown,
                AutoCompleteMode =
                    System.Windows.Forms.AutoCompleteMode.SuggestAppend,
                AutoCompleteSource =
                    System.Windows.Forms.AutoCompleteSource.ListItems,
                IntegralHeight = false,
                MaxDropDownItems = 14
            };
        }

        private System.Windows.Forms.TextBox CrearTextBoxEntrada(
            string texto,
            int left,
            int top,
            int width)
        {
            return new System.Windows.Forms.TextBox
            {
                Text = texto ?? "",
                Left = left,
                Top = top,
                Width = width,
                Height = 24,
                BorderStyle =
                    System.Windows.Forms.BorderStyle.FixedSingle,
                TextAlign =
                    System.Windows.Forms.HorizontalAlignment.Center
            };
        }

        private System.Windows.Forms.Button CrearBotonCabeceraData(
            string texto,
            int left,
            int top,
            int width)
        {
            System.Windows.Forms.Button boton =
                new System.Windows.Forms.Button
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 30,
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            0, 120, 215),
                    ForeColor =
                        System.Drawing.Color.White,
                    FlatStyle =
                        System.Windows.Forms.FlatStyle.Flat,
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            8.0F,
                            System.Drawing.FontStyle.Bold),
                    Cursor =
                        System.Windows.Forms.Cursors.Hand,
                    TabStop = false
                };

            boton.FlatAppearance.BorderSize =
                0;

            return boton;
        }

        private System.Windows.Forms.Button CrearBotonFranjaEdicion(
            string texto,
            int left,
            int top,
            int width)
        {
            System.Windows.Forms.Button boton =
                new System.Windows.Forms.Button
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 24,
                    Margin =
                        new System.Windows.Forms.Padding(2),
                    BackColor =
                        System.Drawing.Color.FromArgb(
                            236, 240, 245),
                    ForeColor =
                        System.Drawing.Color.FromArgb(
                            30, 30, 30),
                    FlatStyle =
                        System.Windows.Forms.FlatStyle.Flat,
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            7.5F,
                            System.Drawing.FontStyle.Bold),
                    Cursor =
                        System.Windows.Forms.Cursors.Hand,
                    TabStop = false
                };

            boton.FlatAppearance.BorderColor =
                System.Drawing.Color.FromArgb(
                    182, 188, 196);

            return boton;
        }

        private void MarcarBoton(
            System.Windows.Forms.Button boton,
            bool activo)
        {
            if (boton == null)
                return;

            boton.BackColor =
                activo
                    ? System.Drawing.Color.FromArgb(
                        202, 225, 246)
                    : System.Drawing.Color.FromArgb(
                        236, 240, 245);

            boton.ForeColor =
                activo
                    ? System.Drawing.Color.FromArgb(
                        0, 82, 150)
                    : System.Drawing.Color.FromArgb(
                        30, 30, 30);

            boton.FlatAppearance.BorderColor =
                activo
                    ? System.Drawing.Color.FromArgb(
                        64, 132, 190)
                    : System.Drawing.Color.FromArgb(
                        182, 188, 196);
        }

        private System.Windows.Forms.Button CrearBotonPrincipal(
            string texto,
            int left,
            int top,
            int width,
            System.Drawing.Color color)
        {
            System.Windows.Forms.Button boton =
                new System.Windows.Forms.Button
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 36,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        9F,
                        System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand
                };

            boton.FlatAppearance.BorderSize = 0;
            return boton;
        }

        private System.Windows.Forms.Label CrearLabel(
            string texto,
            int left,
            int top,
            int width,
            bool negrita)
        {
            return new System.Windows.Forms.Label
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 22,
                Font = new System.Drawing.Font(
                    "Segoe UI",
                    9F,
                    negrita
                        ? System.Drawing.FontStyle.Bold
                        : System.Drawing.FontStyle.Regular)
            };
        }

        private System.Windows.Forms.NumericUpDown CrearNumerico(
            decimal valor,
            int left,
            int top,
            int width,
            decimal minimo,
            decimal maximo,
            int decimales)
        {
            return new System.Windows.Forms.NumericUpDown
            {
                Left = left,
                Top = top,
                Width = width,
                Height = 24,
                Minimum = minimo,
                Maximum = maximo,
                DecimalPlaces = decimales,
                Increment = decimales > 0 ? 0.5M : 1M,
                Value = valor,
                TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            };
        }

        #endregion

        #region 02.3 - EVENTOS Y HERRAMIENTAS DE EDICIÓN

        private void ConectarEventos()
        {
            btnSeleccionar.Click += BtnSeleccionar_Click;
            btnSeleccionarYEjecutar.Click +=
                BtnSeleccionarYEjecutar_Click;
            btnCrear.Click += BtnCrear_Click;

            btnAlzSeleccionar.Click +=
                (s, e) =>
                    CambiarHerramientaAlzado(
                        AceroMuroHerramientaEdicion.SeleccionarMover);

            btnAlzMoverDosPuntos.Click +=
                (s, e) =>
                    CambiarHerramientaAlzado(
                        AceroMuroHerramientaEdicion.MoverDosPuntos);

            btnAlzCopiarDosPuntos.Click +=
                (s, e) =>
                    CambiarHerramientaAlzado(
                        AceroMuroHerramientaEdicion.CopiarDosPuntos);

            btnAlzRestablecer.Click +=
                (s, e) =>
                {
                    FinalizarEditorCotaDesarrolloHorizontal(
                        false);

                    RegistrarDeshacer();

                    ajusteInicioTramoCm.Clear();
                    ajusteFinTramoCm.Clear();

                    desarrolloHorizontalInicioRecordadoDefinido =
                        false;

                    desarrolloHorizontalFinRecordadoDefinido =
                        false;

                    desarrolloHorizontalInicioRecordadoM =
                        0.0;

                    desarrolloHorizontalFinRecordadoM =
                        0.0;

                    bloqueoHorizontalInicio =
                        AceroMuroTipoBloqueoExtremo.Ninguno;

                    bloqueoHorizontalFin =
                        AceroMuroTipoBloqueoExtremo.Ninguno;

                    dataCargadaActiva = null;
                    tramoSeleccionadoId = 0;

                    ActualizarBotonesBloqueo();
                    pnlVistaAlzado.Invalidate();
                    ActualizarAyudasHerramientas();
                };

            btnGuardarData.Click +=
                (s, e) =>
                    GuardarDataDiseno();

            btnCargarData.Click +=
                (s, e) =>
                    CargarDataDiseno();

            btnSecSeleccionar.Click +=
                (s, e) =>
                    CambiarHerramientaSeccion(
                        AceroMuroHerramientaEdicion.SeleccionarMover);

            btnSecMoverDosPuntos.Click +=
                (s, e) =>
                    CambiarHerramientaSeccion(
                        AceroMuroHerramientaEdicion.MoverDosPuntos);

            btnSecDistribuirDosPuntos.Click +=
                (s, e) =>
                {
                    if (chkHorizontales != null &&
                        !chkHorizontales.Checked)
                    {
                        chkHorizontales.Checked = true;
                    }

                    CambiarHerramientaSeccion(
                        AceroMuroHerramientaEdicion.DistribuirHorizontalDosPuntos);
                };

            btnSecCrearVerticalDosPuntos.Click +=
                (s, e) =>
                {
                    if (chkVerticales != null &&
                        !chkVerticales.Checked)
                    {
                        chkVerticales.Checked = true;
                    }

                    CambiarHerramientaSeccion(
                        AceroMuroHerramientaEdicion.DistribuirVerticalDosPuntos);
                };

            btnSecEliminar.Click +=
                (s, e) =>
                {
                    if (!EliminarSeleccionEditorSeccion())
                    {
                        ActualizarEstado(
                            "ELIMINAR: seleccione un grupo 2 PTOS o una manija vertical editada.");
                    }
                };

            btnSecDeshacer.Click +=
                (s, e) =>
                    DeshacerDiseno();

            btnSecRehacer.Click +=
                (s, e) =>
                    RehacerDiseno();

            btnCerrarEditorGrupoHorizontal2P.Click +=
                (s, e) =>
                    OcultarEditorGrupoHorizontal2P();

            cmbEditorReglaGrupoHorizontal2P.SelectedIndexChanged +=
                (s, e) =>
                    AplicarCambioEditorGrupoHorizontal2P(
                        true);

            nudEditorEspaciadoGrupoHorizontal2P.ValueChanged +=
                (s, e) =>
                    AplicarCambioEditorGrupoHorizontal2P(
                        false);

            nudEditorCantidadGrupoHorizontal2P.ValueChanged +=
                (s, e) =>
                    AplicarCambioEditorGrupoHorizontal2P(
                        false);

            pnlVistaSeccion.Resize +=
                (s, e) =>
                    PosicionarEditorGrupoHorizontal2P();

            if (nudSecCantidadDosPuntos != null)
            {
                nudSecCantidadDosPuntos.ValueChanged +=
                    (s, e) =>
                    {
                        AceroMuroGrupoHorizontal2Puntos grupo =
                            ObtenerGrupoHorizontal2PuntosPorId(
                                grupoHorizontal2PSeleccionadoId);

                        if (grupo == null)
                            return;

                        int cantidadNueva =
                            System.Math.Max(
                                2,
                                (int)nudSecCantidadDosPuntos.Value);

                        if (grupo.Cantidad ==
                            cantidadNueva)
                        {
                            return;
                        }

                        RegistrarDeshacer();
                        grupo.Cantidad =
                            cantidadNueva;

                        pnlVistaSeccion.Invalidate();
                        pnlVistaAlzado.Invalidate();
                    };
            }

            btnSecRestablecer.Click +=
                (s, e) =>
                {
                    RegistrarDeshacer();
                    ajusteSeccionIzquierdaCm = 0.0;
                    ajusteSeccionDerechaCm = 0.0;
                    ajusteSeccionInferiorCm = 0.0;
                    ajusteSeccionSuperiorCm = 0.0;
                    seccionHandleSeleccionado = "";

                    gruposHorizontales2Puntos.Clear();
                    gruposHorizontales2PSeleccionados.Clear();
                    grupoHorizontal2PSeleccionadoId = "";
                    OcultarEditorGrupoHorizontal2P();
                    creandoHorizontalDosPuntos = false;
                    horizontal2PEsperandoSegundoClic = false;
                    arrastrandoExtremoHorizontal2P = false;

                    gruposVerticales2Puntos.Clear();
                    gruposVerticales2PSeleccionados.Clear();
                    grupoVertical2PSeleccionadoId = "";
                    creandoVerticalDosPuntos = false;
                    vertical2PEsperandoSegundoClic = false;
                    arrastrandoExtremoVertical2P = false;

                    verticalesSeccionSeleccionados = false;

                    zoomSeccion = 1.0;
                    panSeccionX = 0.0F;
                    panSeccionY = 0.0F;

                    FinalizarEditorCotaInline(
                        false);

                    pnlVistaSeccion.Invalidate();
                    ActualizarAyudasHerramientas();
                };

            pnlVistaSeccion.Paint += PnlVistaSeccion_Paint;
            pnlVistaAlzado.Paint += PnlVista_Paint;
            pnlVistaAlzado.MouseEnter +=
                (s, e) => pnlVistaAlzado.Focus();

            pnlVistaAlzado.MouseWheel += PnlVista_MouseWheel;
            pnlVistaAlzado.MouseDown += PnlVista_MouseDown;
            pnlVistaAlzado.MouseMove += PnlVista_MouseMove;
            pnlVistaAlzado.MouseUp += PnlVista_MouseUp;

            pnlVistaSeccion.MouseEnter +=
                (s, e) => pnlVistaSeccion.Focus();

            pnlVistaSeccion.MouseWheel +=
                PnlVistaSeccion_MouseWheel;

            pnlVistaSeccion.MouseDown += PnlVistaSeccion_MouseDown;
            pnlVistaSeccion.MouseMove += PnlVistaSeccion_MouseMove;
            pnlVistaSeccion.MouseUp += PnlVistaSeccion_MouseUp;

            // V8.48:
            // usamos MouseDoubleClick para recibir botón y coordenada exacta,
            // igual que el editor de vigas.
            pnlVistaSeccion.MouseDoubleClick +=
                PnlVistaSeccion_MouseDoubleClick;
            pnlVistaAlzado.DoubleClick +=
                (s, e) =>
                {
                    FinalizarEditorCotaDesarrolloHorizontal(
                        false);

                    RegistrarDeshacer();
                    zoomVista = 1.0;
                    panX = 0;
                    panY = 0;
                    ajusteInicioTramoCm.Clear();
                    ajusteFinTramoCm.Clear();

                    desarrolloHorizontalInicioRecordadoDefinido =
                        false;

                    desarrolloHorizontalFinRecordadoDefinido =
                        false;

                    desarrolloHorizontalInicioRecordadoM =
                        0.0;

                    desarrolloHorizontalFinRecordadoM =
                        0.0;

                    bloqueoHorizontalInicio =
                        AceroMuroTipoBloqueoExtremo.Ninguno;

                    bloqueoHorizontalFin =
                        AceroMuroTipoBloqueoExtremo.Ninguno;

                    tramoSeleccionadoId = 0;

                    ActualizarBotonesBloqueo();
                    pnlVistaAlzado.Invalidate();
                };

            chkVerticales.CheckedChanged += ConfiguracionVisualCambiada;
            chkHorizontales.CheckedChanged += ConfiguracionVisualCambiada;
            chkContinuos.CheckedChanged += ConfiguracionVisualCambiada;

            chkConsiderarEmpalme.CheckedChanged +=
                (s, e) =>
                {
                    if (txtLongitudComercial != null)
                        txtLongitudComercial.Enabled =
                            chkConsiderarEmpalme.Checked &&
                            chkHorizontales.Checked;

                    if (btnConfigurarEmpalmes != null)
                    {
                        btnConfigurarEmpalmes.Visible =
                            chkConsiderarEmpalme.Checked &&
                            chkHorizontales.Checked;

                        btnConfigurarEmpalmes.Enabled =
                            chkConsiderarEmpalme.Checked &&
                            chkHorizontales.Checked;
                    }

                    if (chkConsiderarEmpalme.Checked)
                        AsegurarEmpalmesPorDiametroDisponibles();

                    GuardarValoresRecordados();

                    pnlVistaAlzado.Invalidate();
                };

            btnConfigurarEmpalmes.Click +=
                (s, e) =>
                    MostrarEditorEmpalmesPorDiametro();

            txtLongitudComercial.TextChanged +=
                (s, e) =>
                {
                    GuardarValoresRecordados();
                    pnlVistaAlzado.Invalidate();
                };

            chkRefuerzoHuecos.CheckedChanged +=
                (s, e) =>
                {
                    bool visible =
                        chkRefuerzoHuecos.Checked;

                    if (lblRefuerzoHuecosDiametro != null)
                        lblRefuerzoHuecosDiametro.Visible =
                            visible;

                    if (cmbRefuerzoHuecosDiametro != null)
                    {
                        cmbRefuerzoHuecosDiametro.Visible =
                            visible;

                        cmbRefuerzoHuecosDiametro.Enabled =
                            visible;
                    }

                    if (lblRefuerzoHuecosLongitud != null)
                        lblRefuerzoHuecosLongitud.Visible =
                            visible;

                    if (txtLongitudRefuerzoHuecos != null)
                    {
                        txtLongitudRefuerzoHuecos.Visible =
                            visible;

                        txtLongitudRefuerzoHuecos.Enabled =
                            visible;
                    }

                    if (lblRefuerzoHuecosUnidad != null)
                        lblRefuerzoHuecosUnidad.Visible =
                            visible;

                    GuardarValoresRecordados();
                };

            cmbRefuerzoHuecosDiametro.SelectedIndexChanged +=
                (s, e) =>
                    GuardarValoresRecordados();

            cmbRefuerzoHuecosDiametro.TextChanged +=
                (s, e) =>
                    GuardarValoresRecordados();

            txtLongitudRefuerzoHuecos.TextChanged +=
                (s, e) =>
                    GuardarValoresRecordados();

            chkVerSinTapar.CheckedChanged += ConfiguracionVisualCambiada;

            chkLongGanchoSupManual.CheckedChanged +=
                (s, e) =>
                {
                    if (!restaurandoHistorial)
                        RegistrarDeshacer();

                    ActualizarControlesLongitudGanchoManual(
                        true);

                    GuardarValoresRecordados();

                    pnlVistaSeccion.Invalidate();
                    pnlVistaAlzado.Invalidate();
                };

            chkLongGanchoInfManual.CheckedChanged +=
                (s, e) =>
                {
                    if (!restaurandoHistorial)
                        RegistrarDeshacer();

                    ActualizarControlesLongitudGanchoManual(
                        true);

                    GuardarValoresRecordados();

                    pnlVistaSeccion.Invalidate();
                    pnlVistaAlzado.Invalidate();
                };

            txtLongGanchoSup.TextChanged +=
                (s, e) =>
                {
                    GuardarValoresRecordados();
                    pnlVistaSeccion.Invalidate();
                };

            txtLongGanchoInf.TextChanged +=
                (s, e) =>
                {
                    GuardarValoresRecordados();
                    pnlVistaSeccion.Invalidate();
                };
            cmbTipoVertical.SelectedIndexChanged += ConfiguracionVisualCambiada;
            cmbTipoVertical.TextChanged += ConfiguracionVisualCambiada;
            cmbTipoHorizontal.SelectedIndexChanged += ConfiguracionVisualCambiada;
            cmbTipoHorizontal.TextChanged += ConfiguracionVisualCambiada;
            cmbCaras.SelectedIndexChanged += ConfiguracionVisualCambiada;
            cmbCaras.TextChanged += ConfiguracionVisualCambiada;

            // El recubrimiento gobierna directamente la posición de:
            // 1) vertical exterior;
            // 2) guía horizontal interior.
            //
            // Usamos un evento específico para forzar el repintado
            // INMEDIATO de la sección al cambiar el RebarCoverType.
            cmbRecubrimiento.SelectedIndexChanged +=
                RecubrimientoVisualCambiado;

            cmbRecubrimiento.TextChanged +=
                RecubrimientoVisualCambiado;

            txtEspVertical.TextChanged += ConfiguracionVisualCambiada;
            txtEspHorizontal.TextChanged += ConfiguracionVisualCambiada;

            cmbGrupoDiametro.SelectedIndexChanged +=
                PanelGrupoSeleccionado_Cambio;

            cmbGrupoDiametro.TextChanged +=
                PanelGrupoSeleccionado_Cambio;

            cmbGrupoRegla.SelectedIndexChanged +=
                PanelGrupoRegla_Cambio;

            cmbGrupoRegla.TextChanged +=
                PanelGrupoRegla_Cambio;

            txtGrupoValor.TextChanged +=
                PanelGrupoSeleccionado_Cambio;

            btnAplicarCambiosGrupo.Click +=
                BtnAplicarCambiosGrupo_Click;
        }

        private void RecubrimientoVisualCambiado(
            object sender,
            System.EventArgs e)
        {
            double recubrimientoNuevoCm =
                ObtenerRecubrimientoCmActual();

            // -----------------------------------------------------
            // V8.54
            // Antes de recalcular las guías con el nuevo cover:
            // 1) detecta verticales antiguos que estaban realmente
            //    apoyados en la guía del cover anterior;
            // 2) les asigna vínculo;
            // 3) ConfiguracionVisualCambiada() mueve los vinculados
            //    a la nueva posición.
            // -----------------------------------------------------
            PrepararVinculosVerticalesAntesDeCambioRecubrimiento(
                recubrimientoNuevoCm);

            // Mantiene toda la lógica normal de configuración.
            ConfiguracionVisualCambiada(
                sender,
                e);

            // Segunda pasada explícita para garantizar que todos los
            // grupos verticales queden exactamente sobre su guía
            // paramétrica después del cambio de recubrimiento.
            ActualizarGruposVerticalesVinculadosAGuias();

            // El OSNAP anterior ya no debe quedarse visible porque
            // su posición puede corresponder al recubrimiento anterior.
            snapSeccionVisible = false;
            snapSeccionPuntoValido = false;
            snapSeccionTexto = "";
            snapSeccionModo = "";

            if (pnlVistaSeccion != null &&
                !pnlVistaSeccion.IsDisposed)
            {
                pnlVistaSeccion.Invalidate();
                pnlVistaSeccion.Update();
            }

            if (pnlVistaAlzado != null &&
                !pnlVistaAlzado.IsDisposed)
            {
                pnlVistaAlzado.Invalidate();
                pnlVistaAlzado.Update();
            }

            ActualizarResumenEditorGrupoHorizontal2P();
        }


        private void ConfiguracionVisualCambiada(
            object sender,
            System.EventArgs e)
        {
            // Los tipos/espaciados globales ya no se muestran.
            // Los grupos creados conservan su configuración independiente.
            cmbTipoVertical.Enabled = true;
            txtEspVertical.Enabled = true;
            cmbTipoHorizontal.Enabled = true;
            txtEspHorizontal.Enabled = true;
            chkContinuos.Enabled = chkHorizontales.Checked;

            if (chkConsiderarEmpalme != null)
                chkConsiderarEmpalme.Enabled =
                    chkHorizontales.Checked;

            if (txtLongitudComercial != null)
                txtLongitudComercial.Enabled =
                    chkHorizontales.Checked &&
                    chkConsiderarEmpalme != null &&
                    chkConsiderarEmpalme.Checked;

            if (btnConfigurarEmpalmes != null)
            {
                btnConfigurarEmpalmes.Visible =
                    chkHorizontales.Checked &&
                    chkConsiderarEmpalme != null &&
                    chkConsiderarEmpalme.Checked;

                btnConfigurarEmpalmes.Enabled =
                    btnConfigurarEmpalmes.Visible;
            }

            GuardarValoresRecordados();

            // Constraint paramétrico:
            // si un extremo fue capturado sobre GUIA H, actualizamos
            // su coordenada cada vez que cambia REC / Ø / Malla.
            ActualizarGruposVinculadosAGuiasSeccion();
            ActualizarGruposVerticalesVinculadosAGuias();

            if (bloqueoHorizontalInicio !=
                    AceroMuroTipoBloqueoExtremo.Ninguno ||
                bloqueoHorizontalFin !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                AplicarBloqueosATodasCadenas();
            }

            pnlVistaAlzado.Invalidate();
            pnlVistaSeccion.Invalidate();
        }


        private void PnlVistaSeccion_MouseWheel(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (editandoCotaInline)
            {
                FinalizarEditorCotaInline(
                    true);
            }

            if (vistaSeccionActual == null ||
                vistaSeccionActual.Altura <= 1e-9)
            {
                return;
            }

            double zoomAnterior =
                zoomSeccion;

            double factor =
                e.Delta > 0
                    ? 1.15
                    : 1.0 / 1.15;

            double nuevoZoom =
                zoomAnterior *
                factor;

            nuevoZoom =
                System.Math.Max(
                    0.35,
                    System.Math.Min(
                        8.0,
                        nuevoZoom));

            if (System.Math.Abs(
                nuevoZoom -
                zoomAnterior) <= 1e-9)
            {
                return;
            }

            // -----------------------------------------------------
            // ZOOM HACIA EL CURSOR
            //
            // Ajustamos el pan para que el punto bajo el cursor
            // permanezca aproximadamente en el mismo lugar visual.
            // -----------------------------------------------------
            float centroBaseX =
                pnlVistaSeccion.ClientSize.Width *
                0.50F;

            float margenSup = 62F;
            float margenInf = 54F;

            float centroBaseY =
                (margenSup +
                 (pnlVistaSeccion.ClientSize.Height -
                  margenInf)) * 0.5F;

            float centroActualX =
                centroBaseX +
                panSeccionX;

            float centroActualY =
                centroBaseY +
                panSeccionY;

            double proporcion =
                nuevoZoom /
                zoomAnterior;

            float nuevoCentroX =
                e.X -
                (float)(
                    (e.X -
                     centroActualX) *
                    proporcion);

            float nuevoCentroY =
                e.Y -
                (float)(
                    (e.Y -
                     centroActualY) *
                    proporcion);

            panSeccionX =
                nuevoCentroX -
                centroBaseX;

            panSeccionY =
                nuevoCentroY -
                centroBaseY;

            zoomSeccion =
                nuevoZoom;

            pnlVistaSeccion.Invalidate();
        }

        private bool EsReglaEspaciadoMaximo(
            AceroMuroGrupoHorizontal2Puntos grupo)
        {
            return
                grupo != null &&
                grupo.ReglaDistribucion ==
                    AceroMuroReglaDistribucionGrupo.EspaciadoMaximo;
        }

        private double ObtenerLongitudGrupoHorizontal2P(
            AceroMuroGrupoHorizontal2Puntos grupo)
        {
            if (grupo == null)
                return 0.0;

            double espesor =
                vistaSeccionActual != null
                    ? vistaSeccionActual.Espesor
                    : seccionEspesorActual;

            double altura =
                vistaSeccionActual != null
                    ? vistaSeccionActual.Altura
                    : seccionAlturaActual;

            if (espesor <= 1e-9 ||
                altura <= 1e-9)
            {
                return 0.0;
            }

            double dx =
                (grupo.FinU -
                 grupo.InicioU) *
                espesor;

            double dz =
                (grupo.FinV -
                 grupo.InicioV) *
                altura;

            return
                System.Math.Sqrt(
                    dx * dx +
                    dz * dz);
        }

        private int ObtenerCantidadGrupoHorizontal2P(
            AceroMuroGrupoHorizontal2Puntos grupo)
        {
            if (grupo == null)
                return 0;

            if (grupo.ReglaDistribucion ==
                AceroMuroReglaDistribucionGrupo.NumeroFijo)
            {
                return
                    System.Math.Max(
                        2,
                        grupo.Cantidad);
            }

            double longitud =
                ObtenerLongitudGrupoHorizontal2P(
                    grupo);

            double espaciadoCm =
                grupo.EspaciamientoMaximoCm > 0.0
                    ? grupo.EspaciamientoMaximoCm
                    : ObtenerEspHorizontalCmActual();

            double espaciado =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        System.Math.Max(
                            0.1,
                            espaciadoCm),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            if (longitud <= 1e-9 ||
                espaciado <= 1e-9)
            {
                return 2;
            }

            int intervalos =
                System.Math.Max(
                    1,
                    (int)System.Math.Ceiling(
                        longitud /
                        espaciado));

            return
                System.Math.Min(
                    500,
                    intervalos + 1);
        }

        private double ObtenerPasoRealGrupoHorizontal2PCm(
            AceroMuroGrupoHorizontal2Puntos grupo)
        {
            if (grupo == null)
                return 0.0;

            int cantidad =
                ObtenerCantidadGrupoHorizontal2P(
                    grupo);

            double longitud =
                ObtenerLongitudGrupoHorizontal2P(
                    grupo);

            if (cantidad <= 1 ||
                longitud <= 1e-9)
            {
                return 0.0;
            }

            double paso =
                longitud /
                (cantidad - 1);

            return
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        paso,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);
        }

        private void PosicionarEditorGrupoHorizontal2P()
        {
            if (pnlEditorGrupoHorizontal2P == null ||
                pnlVistaSeccion == null)
            {
                return;
            }

            int x =
                System.Math.Max(
                    8,
                    pnlVistaSeccion.ClientSize.Width -
                    pnlEditorGrupoHorizontal2P.Width -
                    10);

            pnlEditorGrupoHorizontal2P.Location =
                new System.Drawing.Point(
                    x,
                    10);

            pnlEditorGrupoHorizontal2P.BringToFront();
        }

        private void OcultarEditorGrupoHorizontal2P()
        {
            if (pnlEditorGrupoHorizontal2P != null)
                pnlEditorGrupoHorizontal2P.Visible = false;
        }

        private void ActualizarResumenEditorGrupoHorizontal2P()
        {
            if (lblEditorResumenGrupoHorizontal2P == null)
                return;

            AceroMuroGrupoHorizontal2Puntos grupo =
                ObtenerGrupoHorizontal2PuntosPorId(
                    grupoHorizontal2PSeleccionadoId);

            if (grupo == null)
            {
                lblEditorResumenGrupoHorizontal2P.Text = "";
                return;
            }

            int cantidad =
                ObtenerCantidadGrupoHorizontal2P(
                    grupo);

            if (grupo.ReglaDistribucion ==
                AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
            {
                double pasoReal =
                    ObtenerPasoRealGrupoHorizontal2PCm(
                        grupo);

                lblEditorResumenGrupoHorizontal2P.Text =
                    "Resultado: " +
                    cantidad +
                    " barras | paso real ≈ " +
                    pasoReal.ToString("0.0") +
                    " cm";
            }
            else
            {
                lblEditorResumenGrupoHorizontal2P.Text =
                    "Resultado: " +
                    cantidad +
                    " barras equidistantes";
            }
        }

        private void ActualizarVisibilidadEditorGrupoHorizontal2P()
        {
            AceroMuroGrupoHorizontal2Puntos grupo =
                ObtenerGrupoHorizontal2PuntosPorId(
                    grupoHorizontal2PSeleccionadoId);

            if (grupo == null)
                return;

            bool maximo =
                grupo.ReglaDistribucion ==
                AceroMuroReglaDistribucionGrupo.EspaciadoMaximo;

            if (lblEditorValorGrupoHorizontal2P != null)
            {
                lblEditorValorGrupoHorizontal2P.Text =
                    maximo
                        ? "Esp. máx.:"
                        : "N° fijo:";
            }

            if (nudEditorEspaciadoGrupoHorizontal2P != null)
                nudEditorEspaciadoGrupoHorizontal2P.Visible =
                    maximo;

            if (nudEditorCantidadGrupoHorizontal2P != null)
                nudEditorCantidadGrupoHorizontal2P.Visible =
                    !maximo;

            // La unidad cm solo tiene sentido en Espaciado máximo.
            foreach (
                System.Windows.Forms.Control control
                in pnlEditorGrupoHorizontal2P.Controls)
            {
                System.Windows.Forms.Label lbl =
                    control as System.Windows.Forms.Label;

                if (lbl != null &&
                    string.Equals(
                        lbl.Text,
                        "cm",
                        System.StringComparison.OrdinalIgnoreCase))
                {
                    lbl.Visible =
                        maximo;
                }
            }

            ActualizarResumenEditorGrupoHorizontal2P();
        }

        private void MostrarEditorGrupoHorizontal2P(
            string grupoId)
        {
            AceroMuroGrupoHorizontal2Puntos grupo =
                ObtenerGrupoHorizontal2PuntosPorId(
                    grupoId);

            if (grupo == null)
            {
                grupoHorizontal2PSeleccionadoId = "";
                OcultarEditorGrupoHorizontal2P();
                return;
            }

            grupoHorizontal2PSeleccionadoId =
                grupo.Id;

            // V8.48:
            // El editor inline queda desactivado.
            // El patrón estable del editor de vigas abre un diálogo
            // modal únicamente con DOBLE CLIC.
            OcultarEditorGrupoHorizontal2P();

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Invalidate();
        }

        private bool EditarReglaGrupoHorizontal2P(
            string grupoId)
        {
            if (string.IsNullOrWhiteSpace(
                    grupoId))
            {
                return false;
            }

            AceroMuroGrupoHorizontal2Puntos grupo =
                ObtenerGrupoHorizontal2PuntosPorId(
                    grupoId);

            if (grupo == null)
                return false;

            double longitudPies =
                ObtenerLongitudGrupoHorizontal2P(
                    grupo);

            if (longitudPies <= 1e-9)
                return false;

            double longitudCm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        longitudPies,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double espaciadoInicial =
                System.Math.Max(
                    0.10,
                    grupo.EspaciamientoMaximoCm > 0.0
                        ? grupo.EspaciamientoMaximoCm
                        : ObtenerEspHorizontalCmActual());

            int cantidadInicial =
                System.Math.Max(
                    2,
                    ObtenerCantidadGrupoHorizontal2P(
                        grupo));

            using (
                AceroMuroReglaGrupoHorizontalForm dialogo =
                    new AceroMuroReglaGrupoHorizontalForm(
                        longitudCm,
                        grupo.ReglaDistribucion,
                        espaciadoInicial,
                        cantidadInicial))
            {
                // =================================================
                // V8.49 - Z-ORDER SEGURO CON REVIT
                //
                // Esta ventana principal es modeless y TopMost=true.
                // ShowDialog(this) bloquea correctamente al owner, pero
                // Windows podía dejar el diálogo detrás del owner.
                //
                // Bajamos temporalmente el TopMost de la principal,
                // ponemos el editor al frente y, al cerrar, restauramos
                // el estado original.
                // =================================================
                bool topMostPrincipalAnterior =
                    this.TopMost;

                System.Windows.Forms.DialogResult resultado;

                try
                {
                    this.TopMost = false;

                    dialogo.TopMost = true;
                    dialogo.StartPosition =
                        System.Windows.Forms.FormStartPosition.CenterParent;

                    dialogo.BringToFront();

                    resultado =
                        dialogo.ShowDialog(
                            this);
                }
                finally
                {
                    try
                    {
                        this.TopMost =
                            topMostPrincipalAnterior;

                        this.BringToFront();
                        this.Activate();
                    }
                    catch
                    {
                    }
                }

                if (resultado !=
                    System.Windows.Forms.DialogResult.OK)
                {
                    return true;
                }

                RegistrarDeshacer();

                grupo.ReglaDistribucion =
                    dialogo.ReglaSeleccionada;

                if (grupo.ReglaDistribucion ==
                    AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
                {
                    grupo.EspaciamientoMaximoCm =
                        System.Math.Max(
                            0.10,
                            dialogo.EspaciadoCm);

                    grupo.Cantidad =
                        System.Math.Max(
                            2,
                            (int)System.Math.Ceiling(
                                longitudCm /
                                grupo.EspaciamientoMaximoCm) +
                            1);
                }
                else
                {
                    grupo.ReglaDistribucion =
                        AceroMuroReglaDistribucionGrupo.NumeroFijo;

                    grupo.Cantidad =
                        System.Math.Max(
                            2,
                            dialogo.Cantidad);
                }

                grupoHorizontal2PSeleccionadoId =
                    grupo.Id;

                ActualizarResumenEditorGrupoHorizontal2P();

                if (pnlVistaSeccion != null)
                    pnlVistaSeccion.Invalidate();

                if (pnlVistaAlzado != null)
                    pnlVistaAlzado.Invalidate();

                ActualizarAyudasHerramientas();

                return true;
            }
        }

        private bool EditarGrupoHorizontal2PDesdeDobleClic(
            System.Drawing.Point ubicacionPantalla)
        {
            if (gruposHorizontales2Puntos == null ||
                gruposHorizontales2Puntos.Count == 0)
            {
                return false;
            }

            string grupoId;

            // Primero intenta el grupo/segmento.
            if (!TryDetectarGrupoHorizontal2P(
                    ubicacionPantalla,
                    out grupoId))
            {
                // Si se hizo doble clic justo sobre una manija,
                // también se considera el mismo grupo.
                bool esInicio;

                if (!TryDetectarExtremoGrupoHorizontal2P(
                        ubicacionPantalla,
                        out grupoId,
                        out esInicio))
                {
                    return false;
                }
            }

            if (string.IsNullOrWhiteSpace(
                    grupoId))
            {
                return false;
            }

            grupoHorizontal2PSeleccionadoId =
                grupoId;

            verticalesSeccionSeleccionados =
                false;

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Invalidate();

            return
                EditarReglaGrupoHorizontal2P(
                    grupoId);
        }

        private void PnlVistaSeccion_MouseDoubleClick(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (e == null)
                return;

            if (e.Button ==
                System.Windows.Forms.MouseButtons.Middle)
            {
                zoomSeccion = 1.0;
                panSeccionX = 0.0F;
                panSeccionY = 0.0F;

                paneandoSeccion = false;

                if (pnlVistaSeccion != null)
                {
                    pnlVistaSeccion.Capture = false;
                    pnlVistaSeccion.Invalidate();
                }

                FinalizarEditorCotaInline(
                    false);

                return;
            }

            if (e.Button !=
                System.Windows.Forms.MouseButtons.Left ||
                herramientaSeccion !=
                    AceroMuroHerramientaEdicion.SeleccionarMover)
            {
                return;
            }

            bool ctrl =
                CtrlPresionado();

            string grupoVId;

            if (TryDetectarGrupoVertical2P(
                    e.Location,
                    out grupoVId))
            {
                ActualizarSeleccionGrupoVerticalDesdeClick(
                    grupoVId,
                    ctrl);

                if (cmbGrupoDiametro != null)
                    cmbGrupoDiametro.Focus();

                pnlVistaSeccion.Invalidate();
                return;
            }

            bool extremoInicio;

            if (TryDetectarExtremoGrupoVertical2P(
                    e.Location,
                    out grupoVId,
                    out extremoInicio))
            {
                ActualizarSeleccionGrupoVerticalDesdeClick(
                    grupoVId,
                    ctrl);

                if (cmbGrupoDiametro != null)
                    cmbGrupoDiametro.Focus();

                pnlVistaSeccion.Invalidate();
                return;
            }

            string grupoHId;

            if (TryDetectarGrupoHorizontal2P(
                    e.Location,
                    out grupoHId))
            {
                ActualizarSeleccionGrupoHorizontalDesdeClick(
                    grupoHId,
                    ctrl);

                if (cmbGrupoDiametro != null)
                    cmbGrupoDiametro.Focus();

                pnlVistaSeccion.Invalidate();
                return;
            }

            if (TryDetectarExtremoGrupoHorizontal2P(
                    e.Location,
                    out grupoHId,
                    out extremoInicio))
            {
                ActualizarSeleccionGrupoHorizontalDesdeClick(
                    grupoHId,
                    ctrl);

                if (cmbGrupoDiametro != null)
                    cmbGrupoDiametro.Focus();

                pnlVistaSeccion.Invalidate();
            }
        }


        private void AplicarCambioEditorGrupoHorizontal2P(
            bool cambioRegla)
        {
            if (actualizandoEditorGrupoHorizontal2P)
                return;

            AceroMuroGrupoHorizontal2Puntos grupo =
                ObtenerGrupoHorizontal2PuntosPorId(
                    grupoHorizontal2PSeleccionadoId);

            if (grupo == null)
                return;

            RegistrarDeshacer();

            if (cambioRegla)
            {
                grupo.ReglaDistribucion =
                    cmbEditorReglaGrupoHorizontal2P.SelectedIndex == 1
                        ? AceroMuroReglaDistribucionGrupo.NumeroFijo
                        : AceroMuroReglaDistribucionGrupo.EspaciadoMaximo;
            }

            if (nudEditorEspaciadoGrupoHorizontal2P != null)
            {
                grupo.EspaciamientoMaximoCm =
                    (double)nudEditorEspaciadoGrupoHorizontal2P.Value;
            }

            if (nudEditorCantidadGrupoHorizontal2P != null)
            {
                grupo.Cantidad =
                    System.Math.Max(
                        2,
                        (int)nudEditorCantidadGrupoHorizontal2P.Value);
            }

            ActualizarVisibilidadEditorGrupoHorizontal2P();

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Invalidate();

            if (pnlVistaAlzado != null)
                pnlVistaAlzado.Invalidate();
        }

        private bool PermitirMallaHorizontalAutomatica()
        {
            // V8.43:
            // no se generan horizontales "por defecto".
            // Cada cara se diseña mediante grupos independientes de 2 puntos.
            return false;
        }


        private AceroMuroGrupoVertical2Puntos
            ObtenerGrupoVertical2PuntosPorId(
                string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return null;

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo != null &&
                    string.Equals(
                        grupo.Id,
                        id,
                        System.StringComparison.Ordinal))
                {
                    return grupo;
                }
            }

            return null;
        }

        private System.Drawing.PointF
            ObtenerInicioModeloGrupoVertical2P(
                AceroMuroGrupoVertical2Puntos grupo)
        {
            return grupo == null
                ? System.Drawing.PointF.Empty
                : ObtenerPuntoModeloSeccion2P(
                    grupo.InicioU,
                    grupo.InicioV);
        }

        private System.Drawing.PointF
            ObtenerFinModeloGrupoVertical2P(
                AceroMuroGrupoVertical2Puntos grupo)
        {
            return grupo == null
                ? System.Drawing.PointF.Empty
                : ObtenerPuntoModeloSeccion2P(
                    grupo.FinU,
                    grupo.FinV);
        }

        private double ObtenerLongitudDistribucionVerticalEditorPies()
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                vistaElevacionActual.Tramos.Count == 0)
            {
                return 0.0;
            }

            AceroMuroTramoVista tramo =
                vistaElevacionActual.Tramos[0];

            if (tramo == null)
                return 0.0;

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diam =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double margen =
                rec +
                diam * 0.5;

            return
                System.Math.Max(
                    0.0,
                    (tramo.XFin -
                     tramo.XInicio) -
                    margen * 2.0);
        }

        private int ObtenerCantidadGrupoVertical2P(
            AceroMuroGrupoVertical2Puntos grupo)
        {
            if (grupo == null)
                return 0;

            if (grupo.ReglaDistribucion ==
                AceroMuroReglaDistribucionGrupo.NumeroFijo)
            {
                return
                    System.Math.Max(
                        2,
                        grupo.Cantidad);
            }

            double longitud =
                ObtenerLongitudDistribucionVerticalEditorPies();

            double espaciado =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        System.Math.Max(
                            0.1,
                            grupo.EspaciamientoMaximoCm),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            if (longitud <= 1e-9 ||
                espaciado <= 1e-9)
            {
                return 2;
            }

            return
                System.Math.Max(
                    2,
                    (int)System.Math.Ceiling(
                        longitud /
                        espaciado) +
                    1);
        }

        private AceroMuroGrupoVertical2Puntos
            ObtenerGrupoVerticalActivoParaGuias()
        {
            if (!string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId))
            {
                AceroMuroGrupoVertical2Puntos seleccionado =
                    ObtenerGrupoVertical2PuntosPorId(
                        grupoVertical2PSeleccionadoId);

                if (seleccionado != null)
                    return seleccionado;
            }

            if (arrastrandoExtremoVertical2P &&
                !string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId))
            {
                return
                    ObtenerGrupoVertical2PuntosPorId(
                        grupoVertical2PSeleccionadoId);
            }

            return null;
        }

        private Autodesk.Revit.DB.Structure.RebarBarType
            ObtenerTipoVerticalParaGrupo(
                AceroMuroGrupoVertical2Puntos grupo)
        {
            if (grupo != null)
            {
                Autodesk.Revit.DB.Structure.RebarBarType tipoGrupo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoVertical);

                if (tipoGrupo != null)
                    return tipoGrupo;
            }

            return
                ResolverTipoBarra(
                    cmbTipoVertical);
        }

        private double ObtenerDiametroVerticalGrupoPies(
            AceroMuroGrupoVertical2Puntos grupo)
        {
            Autodesk.Revit.DB.Structure.RebarBarType tipo =
                ObtenerTipoVerticalParaGrupo(
                    grupo);

            if (tipo != null)
            {
                double d =
                    ObtenerDiametroBarraVistaDesdeTipo(
                        tipo);

                if (d > 1e-9)
                    return d;
            }

            return
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);
        }

        private double ObtenerXVerticalLocalVistaParaGrupo(
            int cara,
            AceroMuroGrupoVertical2Puntos grupo,
            double recubrimientoCm)
        {
            if (vistaSeccionActual == null)
                return 0.0;

            double ajusteA =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteSeccionIzquierdaCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double ajusteB =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteSeccionDerechaCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double recubrimiento =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        System.Math.Max(
                            0.0,
                            recubrimientoCm),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double diametroVertical =
                ObtenerDiametroVerticalGrupoPies(
                    grupo);

            double baseVertical =
                recubrimiento +
                diametroVertical * 0.5;

            double nucleoMin =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMinDesdeCentro
                    : -seccionEspesorActual * 0.5;

            double nucleoMax =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMaxDesdeCentro
                    : seccionEspesorActual * 0.5;

            if (cara == 0)
            {
                double centroNucleo =
                    (nucleoMin +
                     nucleoMax) * 0.5;

                // UNA MALLA se mantiene centrada.
                // Si existen ganchos conservamos la lógica existente
                // de desplazamiento lateral para evitar interferencia.
                if (!DebeSepararCapasPorGancho())
                    return centroNucleo;

                double desplazamiento =
                    ObtenerSeparacionEjesCapasPiesVista();

                return
                    System.Math.Max(
                        nucleoMin,
                        System.Math.Min(
                            nucleoMax,
                            centroNucleo -
                            desplazamiento));
            }

            if (cara == 1)
            {
                double x =
                    nucleoMin +
                    baseVertical +
                    ajusteA;

                return
                    System.Math.Min(
                        nucleoMax,
                        System.Math.Max(
                            nucleoMin,
                            x));
            }

            if (cara == -1)
            {
                double x =
                    nucleoMax -
                    baseVertical -
                    ajusteB;

                return
                    System.Math.Min(
                        nucleoMax,
                        System.Math.Max(
                            nucleoMin,
                            x));
            }

            return
                (nucleoMin +
                 nucleoMax) * 0.5;
        }

        private void ObtenerRangoGuiasVerticalesSeccionParaGrupo(
            AceroMuroGrupoVertical2Puntos grupo,
            double recubrimientoCm,
            out double zInferior,
            out double zSuperior)
        {
            zInferior = 0.0;
            zSuperior = 0.0;

            if (vistaSeccionActual == null)
                return;

            double altura =
                vistaSeccionActual.Altura;

            double rec =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        System.Math.Max(
                            0.0,
                            recubrimientoCm),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double diam =
                ObtenerDiametroVerticalGrupoPies(
                    grupo);

            double centro =
                rec +
                diam * 0.5;

            double ajusteInf =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteSeccionInferiorCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double ajusteSup =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteSeccionSuperiorCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            zInferior =
                centro +
                ajusteInf;

            zSuperior =
                altura -
                centro -
                ajusteSup;

            zInferior =
                System.Math.Max(
                    -altura,
                    zInferior);

            zSuperior =
                System.Math.Min(
                    altura * 2.0,
                    zSuperior);

            if (zSuperior < zInferior)
                zSuperior = zInferior;
        }

        private AceroMuroVinculoGuiaHorizontal2P
            ObtenerVinculoGuiaVerticalMasCercanaParaGrupo(
                AceroMuroGrupoVertical2Puntos grupo,
                double xActual,
                double recubrimientoCm,
                double toleranciaPies)
        {
            if (grupo == null ||
                vistaSeccionActual == null)
            {
                return
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            }

            AceroMuroConfiguracion conf =
                ObtenerConfiguracionVisual();

            System.Collections.Generic.List<int> caras =
                ObtenerCarasVista(
                    conf.ModoCaras);

            double mejor =
                double.MaxValue;

            AceroMuroVinculoGuiaHorizontal2P mejorTipo =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            if (caras.Contains(1))
            {
                double x =
                    ObtenerXVerticalLocalVistaParaGrupo(
                        1,
                        grupo,
                        recubrimientoCm);

                double d =
                    System.Math.Abs(
                        xActual -
                        x);

                if (d < mejor)
                {
                    mejor = d;
                    mejorTipo =
                        AceroMuroVinculoGuiaHorizontal2P.MallaA;
                }
            }

            if (caras.Contains(-1))
            {
                double x =
                    ObtenerXVerticalLocalVistaParaGrupo(
                        -1,
                        grupo,
                        recubrimientoCm);

                double d =
                    System.Math.Abs(
                        xActual -
                        x);

                if (d < mejor)
                {
                    mejor = d;
                    mejorTipo =
                        AceroMuroVinculoGuiaHorizontal2P.MallaB;
                }
            }

            if (caras.Contains(0))
            {
                double x =
                    ObtenerXVerticalLocalVistaParaGrupo(
                        0,
                        grupo,
                        recubrimientoCm);

                double d =
                    System.Math.Abs(
                        xActual -
                        x);

                if (d < mejor)
                {
                    mejor = d;
                    mejorTipo =
                        AceroMuroVinculoGuiaHorizontal2P.UnaMalla;
                }
            }

            if (mejor <= toleranciaPies)
                return mejorTipo;

            return
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
        }

        private AceroMuroVinculoVertical2P
            ObtenerVinculoLimiteVerticalMasCercanoParaGrupo(
                AceroMuroGrupoVertical2Puntos grupo,
                double zActual,
                double recubrimientoCm,
                double toleranciaPies)
        {
            double zInf;
            double zSup;

            ObtenerRangoGuiasVerticalesSeccionParaGrupo(
                grupo,
                recubrimientoCm,
                out zInf,
                out zSup);

            double dInf =
                System.Math.Abs(
                    zActual -
                    zInf);

            double dSup =
                System.Math.Abs(
                    zActual -
                    zSup);

            if (dInf <= dSup &&
                dInf <= toleranciaPies)
            {
                return
                    AceroMuroVinculoVertical2P.LimiteInferior;
            }

            if (dSup < dInf &&
                dSup <= toleranciaPies)
            {
                return
                    AceroMuroVinculoVertical2P.LimiteSuperior;
            }

            return
                AceroMuroVinculoVertical2P.Ninguno;
        }

        private void VincularPuntoVerticalLegacySiCorresponde(
            AceroMuroGrupoVertical2Puntos grupo,
            bool inicio,
            double recubrimientoAnteriorCm)
        {
            if (grupo == null ||
                vistaSeccionActual == null)
            {
                return;
            }

            System.Drawing.PointF actual =
                inicio
                    ? ObtenerInicioModeloGrupoVertical2P(
                        grupo)
                    : ObtenerFinModeloGrupoVertical2P(
                        grupo);

            AceroMuroVinculoGuiaHorizontal2P vinculoX =
                inicio
                    ? grupo.InicioVinculoGuia
                    : grupo.FinVinculoGuia;

            AceroMuroVinculoVertical2P vinculoZ =
                inicio
                    ? grupo.InicioVinculoVertical
                    : grupo.FinVinculoVertical;

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        2.0,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            // Migración de grupos creados antes de guardar vínculos
            // paramétricos: solo se vincula si el punto estaba
            // realmente muy cerca de la guía anterior.
            if (vinculoX ==
                AceroMuroVinculoGuiaHorizontal2P.Ninguno)
            {
                AceroMuroVinculoGuiaHorizontal2P candidato =
                    ObtenerVinculoGuiaVerticalMasCercanaParaGrupo(
                        grupo,
                        actual.X,
                        recubrimientoAnteriorCm,
                        tolerancia);

                if (candidato !=
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno)
                {
                    if (inicio)
                        grupo.InicioVinculoGuia = candidato;
                    else
                        grupo.FinVinculoGuia = candidato;
                }
            }

            if (vinculoZ ==
                AceroMuroVinculoVertical2P.Ninguno)
            {
                AceroMuroVinculoVertical2P candidato =
                    ObtenerVinculoLimiteVerticalMasCercanoParaGrupo(
                        grupo,
                        actual.Y,
                        recubrimientoAnteriorCm,
                        tolerancia);

                if (candidato !=
                    AceroMuroVinculoVertical2P.Ninguno)
                {
                    if (inicio)
                        grupo.InicioVinculoVertical = candidato;
                    else
                        grupo.FinVinculoVertical = candidato;
                }
            }
        }

        private void PrepararVinculosVerticalesAntesDeCambioRecubrimiento(
            double recubrimientoNuevoCm)
        {
            if (gruposVerticales2Puntos.Count == 0)
            {
                ultimoRecubrimientoGuiasVerticalesCm =
                    recubrimientoNuevoCm;

                return;
            }

            if (double.IsNaN(
                ultimoRecubrimientoGuiasVerticalesCm))
            {
                ultimoRecubrimientoGuiasVerticalesCm =
                    recubrimientoNuevoCm;

                return;
            }

            if (System.Math.Abs(
                    recubrimientoNuevoCm -
                    ultimoRecubrimientoGuiasVerticalesCm) <=
                1e-9)
            {
                return;
            }

            // Antes de mover la guía al nuevo recubrimiento,
            // identificamos grupos antiguos que estaban apoyados
            // en la guía previa y les asignamos el vínculo.
            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                VincularPuntoVerticalLegacySiCorresponde(
                    grupo,
                    true,
                    ultimoRecubrimientoGuiasVerticalesCm);

                VincularPuntoVerticalLegacySiCorresponde(
                    grupo,
                    false,
                    ultimoRecubrimientoGuiasVerticalesCm);
            }

            ultimoRecubrimientoGuiasVerticalesCm =
                recubrimientoNuevoCm;
        }


        private System.Collections.Generic.List<
            System.Tuple<double, string>>
            ObtenerGuiasXVerticalesSeccion()
        {
            System.Collections.Generic.List<
                System.Tuple<double, string>> guias =
                    new System.Collections.Generic.List<
                        System.Tuple<double, string>>();

            if (vistaSeccionActual == null ||
                chkVerticales == null ||
                !chkVerticales.Checked)
            {
                return guias;
            }

            AceroMuroConfiguracion conf =
                ObtenerConfiguracionVisual();

            System.Collections.Generic.List<int> caras =
                ObtenerCarasVista(
                    conf.ModoCaras);

            double recCm =
                ObtenerRecubrimientoCmActual();

            AceroMuroGrupoVertical2Puntos grupoActivo =
                ObtenerGrupoVerticalActivoParaGuias();

            if (caras.Contains(1))
            {
                guias.Add(
                    System.Tuple.Create(
                        ObtenerXVerticalLocalVistaParaGrupo(
                            1,
                            grupoActivo,
                            recCm),
                        "GUIA V - MALLA A | REC " +
                        recCm.ToString("0.#") +
                        " cm"));
            }

            if (caras.Contains(-1))
            {
                guias.Add(
                    System.Tuple.Create(
                        ObtenerXVerticalLocalVistaParaGrupo(
                            -1,
                            grupoActivo,
                            recCm),
                        "GUIA V - MALLA B | REC " +
                        recCm.ToString("0.#") +
                        " cm"));
            }

            if (caras.Contains(0))
            {
                guias.Add(
                    System.Tuple.Create(
                        ObtenerXVerticalLocalVistaParaGrupo(
                            0,
                            grupoActivo,
                            recCm),
                        "GUIA V - UNA MALLA"));
            }

            return guias;
        }

        private void ObtenerRangoGuiasVerticalesSeccion(
            out double zInferior,
            out double zSuperior)
        {
            AceroMuroGrupoVertical2Puntos grupoActivo =
                ObtenerGrupoVerticalActivoParaGuias();

            ObtenerRangoGuiasVerticalesSeccionParaGrupo(
                grupoActivo,
                ObtenerRecubrimientoCmActual(),
                out zInferior,
                out zSuperior);
        }

        private bool TryObtenerXGuiaVerticalVinculada(
            AceroMuroGrupoVertical2Puntos grupo,
            AceroMuroVinculoGuiaHorizontal2P tipo,
            out double x)
        {
            x = 0.0;

            if (tipo ==
                AceroMuroVinculoGuiaHorizontal2P.Ninguno ||
                vistaSeccionActual == null)
            {
                return false;
            }

            double recCm =
                ObtenerRecubrimientoCmActual();

            if (tipo ==
                AceroMuroVinculoGuiaHorizontal2P.MallaA)
            {
                x =
                    ObtenerXVerticalLocalVistaParaGrupo(
                        1,
                        grupo,
                        recCm);

                return true;
            }

            if (tipo ==
                AceroMuroVinculoGuiaHorizontal2P.MallaB)
            {
                x =
                    ObtenerXVerticalLocalVistaParaGrupo(
                        -1,
                        grupo,
                        recCm);

                return true;
            }

            if (tipo ==
                AceroMuroVinculoGuiaHorizontal2P.UnaMalla)
            {
                x =
                    ObtenerXVerticalLocalVistaParaGrupo(
                        0,
                        grupo,
                        recCm);

                return true;
            }

            return false;
        }

        private bool TryObtenerZVerticalVinculado(
            AceroMuroGrupoVertical2Puntos grupo,
            AceroMuroVinculoVertical2P tipo,
            out double z)
        {
            z = 0.0;

            if (tipo ==
                AceroMuroVinculoVertical2P.Ninguno)
            {
                return false;
            }

            double zInferior;
            double zSuperior;

            ObtenerRangoGuiasVerticalesSeccionParaGrupo(
                grupo,
                ObtenerRecubrimientoCmActual(),
                out zInferior,
                out zSuperior);

            if (tipo ==
                AceroMuroVinculoVertical2P.LimiteInferior)
            {
                z = zInferior;
                return true;
            }

            if (tipo ==
                AceroMuroVinculoVertical2P.LimiteSuperior)
            {
                z = zSuperior;
                return true;
            }

            return false;
        }

        private bool EsGrupoHorizontalExcluidoParaSnapAledano(
            AceroMuroGrupoHorizontal2Puntos grupo)
        {
            if (grupo == null)
                return true;

            // Durante el arrastre de un extremo H no debemos usar
            // como referencia al mismo grupo que se está modificando.
            if (arrastrandoExtremoHorizontal2P &&
                !string.IsNullOrWhiteSpace(
                    grupoHorizontal2PSeleccionadoId) &&
                string.Equals(
                    grupo.Id,
                    grupoHorizontal2PSeleccionadoId,
                    System.StringComparison.Ordinal))
            {
                return true;
            }

            if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos &&
                EsGrupoHorizontalSeleccionado(
                    grupo.Id))
            {
                return true;
            }

            return false;
        }

        private bool EsGrupoVerticalExcluidoParaSnapAledano(
            AceroMuroGrupoVertical2Puntos grupo)
        {
            if (grupo == null)
                return true;

            // Durante el arrastre de un extremo V no debemos usar
            // como referencia al mismo grupo que se está modificando.
            if (arrastrandoExtremoVertical2P &&
                !string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId) &&
                string.Equals(
                    grupo.Id,
                    grupoVertical2PSeleccionadoId,
                    System.StringComparison.Ordinal))
            {
                return true;
            }

            if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos &&
                EsGrupoVerticalSeleccionado(
                    grupo.Id))
            {
                return true;
            }

            return false;
        }

        private void EvaluarAlineacionConPuntoAledano(
            System.Drawing.Point cursor,
            double xLibre,
            double zLibre,
            double xReferencia,
            double zReferencia,
            string descripcion,
            ref AceroMuroSnapPunto2P mejor)
        {
            float px =
                PantallaXSeccion(
                    xReferencia);

            float py =
                PantallaYSeccion(
                    zReferencia);

            double dxPx =
                System.Math.Abs(
                    cursor.X -
                    px);

            double dzPx =
                System.Math.Abs(
                    cursor.Y -
                    py);

            // -----------------------------------------------------
            // COINCIDENCIA X + Z
            //
            // Si el cursor está realmente cerca del punto de una
            // barra aledaña, captura la intersección exacta.
            // -----------------------------------------------------
            if (dxPx <= 8.0 &&
                dzPx <= 8.0)
            {
                double distancia =
                    System.Math.Sqrt(
                        dxPx * dxPx +
                        dzPx * dzPx);

                // Factor de prioridad para que, estando muy cerca del
                // punto real, gane frente al tracking de una sola
                // coordenada.
                EvaluarCandidatoSnap2PDistancia(
                    distancia * 0.35,
                    xReferencia,
                    zReferencia,
                    "EXTREMO ACERO ALEDAÑO | " +
                        descripcion,
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.Ninguno,
                    8.0,
                    ref mejor);
            }

            // -----------------------------------------------------
            // ALINEACIÓN HORIZONTAL CON ACERO ALEDAÑO
            //
            // Mantiene X libre y toma únicamente la altura Z.
            // Es la situación típica para igualar extremos SUP/INF
            // de dos grupos que están uno al lado del otro.
            // -----------------------------------------------------
            EvaluarCandidatoSnap2PDistancia(
                dzPx + 2.0,
                xLibre,
                zReferencia,
                "ALINEADO HORIZONTAL | ACERO ALEDAÑO | " +
                    descripcion,
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                13.0,
                ref mejor);

            // -----------------------------------------------------
            // ALINEACIÓN VERTICAL CON ACERO ALEDAÑO
            //
            // Mantiene Z libre y toma únicamente X.
            // -----------------------------------------------------
            EvaluarCandidatoSnap2PDistancia(
                dxPx + 2.0,
                xReferencia,
                zLibre,
                "ALINEADO VERTICAL | ACERO ALEDAÑO | " +
                    descripcion,
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                13.0,
                ref mejor);
        }

        private void EvaluarAlineacionConLineaAledana(
            System.Drawing.Point cursor,
            System.Drawing.PointF aModelo,
            System.Drawing.PointF bModelo,
            string descripcion,
            ref AceroMuroSnapPunto2P mejor)
        {
            float ax =
                PantallaXSeccion(
                    aModelo.X);

            float ay =
                PantallaYSeccion(
                    aModelo.Y);

            float bx =
                PantallaXSeccion(
                    bModelo.X);

            float by =
                PantallaYSeccion(
                    bModelo.Y);

            double vx =
                bx - ax;

            double vy =
                by - ay;

            double len2 =
                vx * vx +
                vy * vy;

            if (len2 <= 1e-9)
                return;

            double wx =
                cursor.X -
                ax;

            double wy =
                cursor.Y -
                ay;

            // Proyección sobre la RECTA INFINITA de la barra/grupo.
            // No se limita al segmento porque justamente queremos
            // poder EXTENDER manteniendo la alineación.
            double t =
                (wx * vx +
                 wy * vy) /
                len2;

            double qx =
                ax +
                t * vx;

            double qy =
                ay +
                t * vy;

            double dx =
                cursor.X -
                qx;

            double dy =
                cursor.Y -
                qy;

            double distanciaPx =
                System.Math.Sqrt(
                    dx * dx +
                    dy * dy);

            if (distanciaPx > 10.0)
                return;

            double xModelo =
                aModelo.X +
                t *
                (bModelo.X -
                 aModelo.X);

            double zModelo =
                aModelo.Y +
                t *
                (bModelo.Y -
                 aModelo.Y);

            // Etiqueta compatible con la simbología existente.
            string modo =
                System.Math.Abs(vx) >=
                System.Math.Abs(vy)
                    ? "ALINEADO HORIZONTAL"
                    : "ALINEADO VERTICAL";

            // Pequeña penalización: ENDPOINT real debe ganar si el
            // cursor está encima del extremo. Fuera de él, esta
            // referencia colineal es la que gobierna.
            EvaluarCandidatoSnap2PDistancia(
                distanciaPx + 3.0,
                xModelo,
                zModelo,
                modo +
                    " | ACERO ALEDAÑO | " +
                    descripcion,
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                13.0,
                ref mejor);
        }

        private void EvaluarSnapAcerosAledanos(
            System.Drawing.Point cursor,
            double xLibre,
            double zLibre,
            ref AceroMuroSnapPunto2P mejor)
        {
            // =====================================================
            // GRUPOS HORIZONTALES
            //
            // Además de inicio/fin, se consideran los puntos reales
            // de distribución del grupo. Así puede alinear un acero
            // nuevo con cualquiera de los aceros vecinos.
            // =====================================================
            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (EsGrupoHorizontalExcluidoParaSnapAledano(
                    grupo))
                {
                    continue;
                }

                System.Drawing.PointF a =
                    ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF b =
                    ObtenerFinModeloGrupoHorizontal2P(
                        grupo);

                EvaluarAlineacionConLineaAledana(
                    cursor,
                    a,
                    b,
                    "GRUPO H",
                    ref mejor);

                int cantidad =
                    System.Math.Max(
                        2,
                        ObtenerCantidadGrupoHorizontal2P(
                            grupo));

                // Seguridad gráfica: no necesitamos evaluar cientos
                // de referencias si el grupo tiene una distribución
                // extremadamente densa.
                cantidad =
                    System.Math.Min(
                        250,
                        cantidad);

                for (int i = 0;
                     i < cantidad;
                     i++)
                {
                    double t =
                        cantidad <= 1
                            ? 0.0
                            : (double)i /
                              (cantidad - 1);

                    double x =
                        a.X +
                        (b.X - a.X) *
                        t;

                    double z =
                        a.Y +
                        (b.Y - a.Y) *
                        t;

                    EvaluarAlineacionConPuntoAledano(
                        cursor,
                        xLibre,
                        zLibre,
                        x,
                        z,
                        "H " +
                            (i + 1),
                        ref mejor);
                }
            }

            // =====================================================
            // GRUPOS VERTICALES
            //
            // La geometría visible del grupo V funciona también como
            // referencia de tracking. Se consideran su línea y sus
            // dos extremos.
            // =====================================================
            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (EsGrupoVerticalExcluidoParaSnapAledano(
                    grupo))
                {
                    continue;
                }

                System.Drawing.PointF a =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF b =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                EvaluarAlineacionConLineaAledana(
                    cursor,
                    a,
                    b,
                    "GRUPO V",
                    ref mejor);

                EvaluarAlineacionConPuntoAledano(
                    cursor,
                    xLibre,
                    zLibre,
                    a.X,
                    a.Y,
                    "V INICIO",
                    ref mejor);

                EvaluarAlineacionConPuntoAledano(
                    cursor,
                    xLibre,
                    zLibre,
                    b.X,
                    b.Y,
                    "V FIN",
                    ref mejor);
            }
        }


        private AceroMuroSnapPunto2P ResolverSnapInteligenteVertical2P(
            System.Drawing.Point cursor,
            bool tieneReferencia,
            double referenciaX,
            double referenciaZ)
        {
            double xLibre =
                ModeloXSeccionDesdePantalla(
                    cursor.X);

            double zLibre =
                ModeloYSeccionDesdePantalla(
                    cursor.Y);

            AceroMuroSnapPunto2P mejor =
                new AceroMuroSnapPunto2P
                {
                    Valido = false,
                    X = xLibre,
                    Z = zLibre
                };

            if (!osnapActivo ||
                vistaSeccionActual == null)
            {
                return mejor;
            }

            double zInferior;
            double zSuperior;

            ObtenerRangoGuiasVerticalesSeccion(
                out zInferior,
                out zSuperior);

            System.Collections.Generic.List<
                System.Tuple<double, string>> guias =
                    ObtenerGuiasXVerticalesSeccion();

            foreach (
                System.Tuple<double, string> guia
                in guias)
            {
                if (guia == null)
                    continue;

                AceroMuroVinculoGuiaHorizontal2P tipo =
                    ObtenerTipoVinculoGuiaDesdeTexto(
                        guia.Item2);

                EvaluarCandidatoSnap2P(
                    cursor,
                    guia.Item1,
                    zInferior,
                    "EXTREMO GUIA V INF | " +
                        guia.Item2,
                    tipo,
                    AceroMuroVinculoVertical2P.LimiteInferior,
                    22.0,
                    ref mejor);

                EvaluarCandidatoSnap2P(
                    cursor,
                    guia.Item1,
                    zSuperior,
                    "EXTREMO GUIA V SUP | " +
                        guia.Item2,
                    tipo,
                    AceroMuroVinculoVertical2P.LimiteSuperior,
                    22.0,
                    ref mejor);
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                if (herramientaSeccion ==
                        AceroMuroHerramientaEdicion.MoverDosPuntos &&
                    EsGrupoVerticalSeleccionado(
                        grupo.Id))
                {
                    continue;
                }

                System.Drawing.PointF a =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF b =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                EvaluarCandidatoSnap2P(
                    cursor,
                    a.X,
                    a.Y,
                    "EXTREMO ACERO V",
                    grupo.InicioVinculoGuia,
                    grupo.InicioVinculoVertical,
                    18.0,
                    ref mejor);

                EvaluarCandidatoSnap2P(
                    cursor,
                    b.X,
                    b.Y,
                    "EXTREMO ACERO V",
                    grupo.FinVinculoGuia,
                    grupo.FinVinculoVertical,
                    18.0,
                    ref mejor);
            }

            // =====================================================
            // ACEROS ALEDAÑOS
            //
            // Permite que CREAR V 2 PTOS y el arrastre de extremos
            // se alineen con barras/grupos vecinos.
            // =====================================================
            EvaluarSnapAcerosAledanos(
                cursor,
                xLibre,
                zLibre,
                ref mejor);

            double medioEspesor =
                vistaSeccionActual.Espesor *
                0.5;

            double altura =
                vistaSeccionActual.Altura;

            EvaluarCandidatoSnap2P(
                cursor,
                -medioEspesor,
                0.0,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                18.0,
                ref mejor);

            EvaluarCandidatoSnap2P(
                cursor,
                medioEspesor,
                0.0,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                18.0,
                ref mejor);

            EvaluarCandidatoSnap2P(
                cursor,
                -medioEspesor,
                altura,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                18.0,
                ref mejor);

            EvaluarCandidatoSnap2P(
                cursor,
                medioEspesor,
                altura,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                18.0,
                ref mejor);

            foreach (
                System.Tuple<double, string> guia
                in guias)
            {
                if (guia == null)
                    continue;

                double distanciaPx =
                    System.Math.Abs(
                        cursor.X -
                        PantallaXSeccion(
                            guia.Item1));

                if (zLibre >=
                        System.Math.Min(
                            zInferior,
                            zSuperior) &&
                    zLibre <=
                        System.Math.Max(
                            zInferior,
                            zSuperior))
                {
                    EvaluarCandidatoSnap2PDistancia(
                        distanciaPx,
                        guia.Item1,
                        zLibre,
                        "CERCANO | " +
                            guia.Item2,
                        ObtenerTipoVinculoGuiaDesdeTexto(
                            guia.Item2),
                        AceroMuroVinculoVertical2P.Ninguno,
                        16.0,
                        ref mejor);
                }
            }

            if (tieneReferencia)
            {
                double dVerticalPx =
                    System.Math.Abs(
                        PantallaXSeccion(
                            referenciaX) -
                        cursor.X);

                EvaluarCandidatoSnap2PDistancia(
                    dVerticalPx,
                    referenciaX,
                    zLibre,
                    "ALINEADO VERTICAL",
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.Ninguno,
                    14.0,
                    ref mejor);

                double dHorizontalPx =
                    System.Math.Abs(
                        PantallaYSeccion(
                            referenciaZ) -
                        cursor.Y);

                EvaluarCandidatoSnap2PDistancia(
                    dHorizontalPx,
                    xLibre,
                    referenciaZ,
                    "ALINEADO HORIZONTAL",
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.Ninguno,
                    10.0,
                    ref mejor);

                double dInf =
                    System.Math.Abs(
                        cursor.Y -
                        PantallaYSeccion(
                            zInferior));

                EvaluarCandidatoSnap2PDistancia(
                    dInf,
                    referenciaX,
                    zInferior,
                    "PERPENDICULAR | LIMITE V INF",
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.LimiteInferior,
                    18.0,
                    ref mejor);

                double dSup =
                    System.Math.Abs(
                        cursor.Y -
                        PantallaYSeccion(
                            zSuperior));

                EvaluarCandidatoSnap2PDistancia(
                    dSup,
                    referenciaX,
                    zSuperior,
                    "PERPENDICULAR | LIMITE V SUP",
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.LimiteSuperior,
                    18.0,
                    ref mejor);
            }

            if (mejor.Valido)
            {
                snapSeccionVisible = true;
                snapSeccionPuntoValido = true;
                snapSeccionPuntoX = mejor.X;
                snapSeccionPuntoZ = mejor.Z;
                snapSeccionTexto = mejor.Texto ?? "";

                string t =
                    snapSeccionTexto.ToUpperInvariant();

                if (t.Contains("EXTREMO"))
                    snapSeccionModo = "EXTREMO";
                else if (t.Contains("PERPENDICULAR"))
                    snapSeccionModo = "PERPENDICULAR";
                else if (t.Contains("CERCANO"))
                    snapSeccionModo = "CERCANO";
                else if (t.Contains("ALINEADO HORIZONTAL"))
                    snapSeccionModo = "ALINEADO H";
                else if (t.Contains("ALINEADO VERTICAL"))
                    snapSeccionModo = "ALINEADO V";
                else
                    snapSeccionModo = "OSNAP";

                if (mejor.VinculoGuia !=
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno)
                {
                    snapSeccionVertical = true;
                    snapSeccionValor = mejor.X;
                }
                else
                {
                    snapSeccionVertical = false;
                    snapSeccionValor = mejor.Z;
                }
            }
            else
            {
                snapSeccionVisible = false;
                snapSeccionPuntoValido = false;
                snapSeccionTexto = "";
                snapSeccionModo = "";
            }

            return mejor;
        }

        private bool TryDetectarExtremoGrupoVertical2P(
            System.Drawing.Point punto,
            out string grupoId,
            out bool esInicio)
        {
            grupoId = "";
            esInicio = false;

            double mejor = 16.0;

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF am =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF bm =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(am.X),
                        PantallaYSeccion(am.Y));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(bm.X),
                        PantallaYSeccion(bm.Y));

                double da =
                    System.Math.Sqrt(
                        System.Math.Pow(
                            punto.X - a.X,
                            2.0) +
                        System.Math.Pow(
                            punto.Y - a.Y,
                            2.0));

                double db =
                    System.Math.Sqrt(
                        System.Math.Pow(
                            punto.X - b.X,
                            2.0) +
                        System.Math.Pow(
                            punto.Y - b.Y,
                            2.0));

                if (da <= mejor)
                {
                    mejor = da;
                    grupoId = grupo.Id;
                    esInicio = true;
                }

                if (db <= mejor)
                {
                    mejor = db;
                    grupoId = grupo.Id;
                    esInicio = false;
                }
            }

            return
                !string.IsNullOrWhiteSpace(
                    grupoId);
        }

        private bool TryDetectarGrupoVertical2P(
            System.Drawing.Point punto,
            out string grupoId)
        {
            grupoId = "";
            double mejor = 12.0;

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF am =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF bm =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(am.X),
                        PantallaYSeccion(am.Y));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(bm.X),
                        PantallaYSeccion(bm.Y));

                double d =
                    DistanciaPuntoSegmentoPx(
                        punto,
                        a,
                        b);

                if (d <= mejor)
                {
                    mejor = d;
                    grupoId = grupo.Id;
                }
            }

            return
                !string.IsNullOrWhiteSpace(
                    grupoId);
        }

        private void IniciarDistribucionVertical2P(
            System.Drawing.Point ubicacion)
        {
            AceroMuroSnapPunto2P snap =
                ResolverSnapInteligenteVertical2P(
                    ubicacion,
                    false,
                    0.0,
                    0.0);

            creandoVerticalDosPuntos = true;
            vertical2PEsperandoSegundoClic = true;

            vertical2PInicioPantalla =
                ubicacion;

            vertical2PInicioX = snap.X;
            vertical2PInicioZ = snap.Z;
            vertical2PFinX = snap.X;
            vertical2PFinZ = snap.Z;

            vertical2PInicioVinculoGuia =
                snap.Valido
                    ? snap.VinculoGuia
                    : AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            vertical2PInicioVinculoVertical =
                snap.Valido
                    ? snap.VinculoVertical
                    : AceroMuroVinculoVertical2P.Ninguno;

            vertical2PFinVinculoGuia =
                vertical2PInicioVinculoGuia;

            vertical2PFinVinculoVertical =
                vertical2PInicioVinculoVertical;

            grupoVertical2PSeleccionadoId = "";
            grupoHorizontal2PSeleccionadoId = "";

            pnlVistaSeccion.Capture = true;
            pnlVistaSeccion.Cursor =
                System.Windows.Forms.Cursors.Cross;

            pnlVistaSeccion.Invalidate();
        }

        private void ActualizarDistribucionVertical2P(
            System.Drawing.Point ubicacion)
        {
            if (!creandoVerticalDosPuntos)
                return;

            AceroMuroSnapPunto2P snap =
                ResolverSnapInteligenteVertical2P(
                    ubicacion,
                    true,
                    vertical2PInicioX,
                    vertical2PInicioZ);

            vertical2PFinX = snap.X;
            vertical2PFinZ = snap.Z;

            vertical2PFinVinculoGuia =
                snap.Valido
                    ? snap.VinculoGuia
                    : AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            vertical2PFinVinculoVertical =
                snap.Valido
                    ? snap.VinculoVertical
                    : AceroMuroVinculoVertical2P.Ninguno;

            pnlVistaSeccion.Invalidate();
        }

        private void FinalizarDistribucionVertical2P(
            System.Drawing.Point ubicacion)
        {
            if (!creandoVerticalDosPuntos)
                return;

            ActualizarDistribucionVertical2P(
                ubicacion);

            double dx =
                vertical2PFinX -
                vertical2PInicioX;

            double dz =
                vertical2PFinZ -
                vertical2PInicioZ;

            double longitud =
                System.Math.Sqrt(
                    dx * dx +
                    dz * dz);

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        1.0,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            if (longitud > tolerancia)
            {
                RegistrarDeshacer();

                System.Drawing.PointF p0 =
                    CrearPuntoNormalizadoSeccion2P(
                        vertical2PInicioX,
                        vertical2PInicioZ);

                System.Drawing.PointF p1 =
                    CrearPuntoNormalizadoSeccion2P(
                        vertical2PFinX,
                        vertical2PFinZ);

                AceroMuroGrupoVertical2Puntos grupo =
                    new AceroMuroGrupoVertical2Puntos
                    {
                        InicioU = p0.X,
                        InicioV = p0.Y,
                        FinU = p1.X,
                        FinV = p1.Y,
                        InicioVinculoGuia =
                            vertical2PInicioVinculoGuia,
                        InicioVinculoVertical =
                            vertical2PInicioVinculoVertical,
                        FinVinculoGuia =
                            vertical2PFinVinculoGuia,
                        FinVinculoVertical =
                            vertical2PFinVinculoVertical,
                        ReglaDistribucion =
                            AceroMuroReglaDistribucionGrupo.EspaciadoMaximo,
                        EspaciamientoMaximoCm =
                            System.Math.Max(
                                0.5,
                                ObtenerEspVerticalCmActual()),
                        Cantidad = 4,
                        TipoBarraId =
                            ObtenerTipoPorDefectoGrupo(true) != null
                                ? ObtenerTipoPorDefectoGrupo(true).Id.Value
                                : 0,
                        TipoBarraNombre =
                            ObtenerTipoPorDefectoGrupo(true) != null
                                ? ObtenerTipoPorDefectoGrupo(true).Name
                                : ""
                    };

                gruposVerticales2Puntos.Add(
                    grupo);

                SeleccionarSoloGrupoVertical(
                    grupo.Id);

                ActualizarPanelGrupoSeleccionado();
            }

            creandoVerticalDosPuntos = false;
            vertical2PEsperandoSegundoClic = false;

            vertical2PInicioVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            vertical2PInicioVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;
            vertical2PFinVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            vertical2PFinVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

            pnlVistaSeccion.Capture = false;
            pnlVistaSeccion.Cursor =
                System.Windows.Forms.Cursors.Cross;

            ActualizarAyudasHerramientas();
            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();
        }

        private void ActualizarArrastreExtremoVertical2P(
            System.Drawing.Point ubicacion)
        {
            if (!arrastrandoExtremoVertical2P)
                return;

            AceroMuroGrupoVertical2Puntos grupo =
                ObtenerGrupoVertical2PuntosPorId(
                    grupoVertical2PSeleccionadoId);

            if (grupo == null)
                return;

            System.Drawing.PointF otro =
                arrastrandoInicioVertical2P
                    ? ObtenerFinModeloGrupoVertical2P(
                        grupo)
                    : ObtenerInicioModeloGrupoVertical2P(
                        grupo);

            AceroMuroSnapPunto2P snap =
                ResolverSnapInteligenteVertical2P(
                    ubicacion,
                    true,
                    otro.X,
                    otro.Y);

            System.Drawing.PointF normalizado =
                CrearPuntoNormalizadoSeccion2P(
                    snap.X,
                    snap.Z);

            if (arrastrandoInicioVertical2P)
            {
                grupo.InicioU = normalizado.X;
                grupo.InicioV = normalizado.Y;
                grupo.InicioVinculoGuia =
                    snap.Valido
                        ? snap.VinculoGuia
                        : AceroMuroVinculoGuiaHorizontal2P.Ninguno;
                grupo.InicioVinculoVertical =
                    snap.Valido
                        ? snap.VinculoVertical
                        : AceroMuroVinculoVertical2P.Ninguno;
            }
            else
            {
                grupo.FinU = normalizado.X;
                grupo.FinV = normalizado.Y;
                grupo.FinVinculoGuia =
                    snap.Valido
                        ? snap.VinculoGuia
                        : AceroMuroVinculoGuiaHorizontal2P.Ninguno;
                grupo.FinVinculoVertical =
                    snap.Valido
                        ? snap.VinculoVertical
                        : AceroMuroVinculoVertical2P.Ninguno;
            }

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();
        }

        private void ActualizarGrupoVerticalVinculado(
            AceroMuroGrupoVertical2Puntos grupo,
            bool inicio)
        {
            if (grupo == null ||
                vistaSeccionActual == null)
            {
                return;
            }

            System.Drawing.PointF actual =
                inicio
                    ? ObtenerInicioModeloGrupoVertical2P(
                        grupo)
                    : ObtenerFinModeloGrupoVertical2P(
                        grupo);

            double x = actual.X;
            double z = actual.Y;

            AceroMuroVinculoGuiaHorizontal2P vg =
                inicio
                    ? grupo.InicioVinculoGuia
                    : grupo.FinVinculoGuia;

            AceroMuroVinculoVertical2P vz =
                inicio
                    ? grupo.InicioVinculoVertical
                    : grupo.FinVinculoVertical;

            double valor;

            if (TryObtenerXGuiaVerticalVinculada(
                grupo,
                vg,
                out valor))
            {
                x = valor;
            }

            if (TryObtenerZVerticalVinculado(
                grupo,
                vz,
                out valor))
            {
                z = valor;
            }

            System.Drawing.PointF normal =
                CrearPuntoNormalizadoSeccion2P(
                    x,
                    z);

            if (inicio)
            {
                grupo.InicioU = normal.X;
                grupo.InicioV = normal.Y;
            }
            else
            {
                grupo.FinU = normal.X;
                grupo.FinV = normal.Y;
            }
        }

        private void ActualizarGruposVerticalesVinculadosAGuias()
        {
            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                ActualizarGrupoVerticalVinculado(
                    grupo,
                    true);

                ActualizarGrupoVerticalVinculado(
                    grupo,
                    false);
            }
        }

        private bool EditarReglaGrupoVertical2P(
            string grupoId)
        {
            AceroMuroGrupoVertical2Puntos grupo =
                ObtenerGrupoVertical2PuntosPorId(
                    grupoId);

            if (grupo == null)
                return false;

            double longitudPies =
                ObtenerLongitudDistribucionVerticalEditorPies();

            double longitudCm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        longitudPies,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double esp =
                System.Math.Max(
                    0.10,
                    grupo.EspaciamientoMaximoCm > 0.0
                        ? grupo.EspaciamientoMaximoCm
                        : ObtenerEspVerticalCmActual());

            int cantidad =
                System.Math.Max(
                    2,
                    ObtenerCantidadGrupoVertical2P(
                        grupo));

            using (
                AceroMuroReglaGrupoHorizontalForm dialogo =
                    new AceroMuroReglaGrupoHorizontalForm(
                        longitudCm,
                        grupo.ReglaDistribucion,
                        esp,
                        cantidad))
            {
                dialogo.Text =
                    "MYG - Modificar distribución vertical";

                foreach (
                    System.Windows.Forms.Control control
                    in dialogo.Controls)
                {
                    System.Windows.Forms.Label lbl =
                        control as System.Windows.Forms.Label;

                    if (lbl != null &&
                        string.Equals(
                            lbl.Text,
                            "MODIFICAR GRUPO HORIZONTAL",
                            System.StringComparison.OrdinalIgnoreCase))
                    {
                        lbl.Text =
                            "MODIFICAR GRUPO VERTICAL";
                    }
                }

                bool topMostPrincipalAnterior =
                    this.TopMost;

                System.Windows.Forms.DialogResult dr;

                try
                {
                    this.TopMost = false;

                    dialogo.TopMost = true;
                    dialogo.StartPosition =
                        System.Windows.Forms.FormStartPosition.CenterParent;

                    dialogo.BringToFront();

                    dr =
                        dialogo.ShowDialog(
                            this);
                }
                finally
                {
                    try
                    {
                        this.TopMost =
                            topMostPrincipalAnterior;

                        this.BringToFront();
                        this.Activate();
                    }
                    catch
                    {
                    }
                }

                if (dr !=
                    System.Windows.Forms.DialogResult.OK)
                {
                    return true;
                }

                RegistrarDeshacer();

                grupo.ReglaDistribucion =
                    dialogo.ReglaSeleccionada;

                if (grupo.ReglaDistribucion ==
                    AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
                {
                    grupo.EspaciamientoMaximoCm =
                        System.Math.Max(
                            0.10,
                            dialogo.EspaciadoCm);

                    grupo.Cantidad =
                        System.Math.Max(
                            2,
                            (int)System.Math.Ceiling(
                                longitudCm /
                                grupo.EspaciamientoMaximoCm) +
                            1);
                }
                else
                {
                    grupo.Cantidad =
                        System.Math.Max(
                            2,
                            dialogo.Cantidad);
                }

                grupoVertical2PSeleccionadoId =
                    grupo.Id;

                pnlVistaSeccion.Invalidate();
                pnlVistaAlzado.Invalidate();

                return true;
            }
        }


        private AceroMuroGrupoHorizontal2Puntos
            ObtenerGrupoHorizontal2PuntosPorId(
                string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return null;

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo != null &&
                    string.Equals(
                        grupo.Id,
                        id,
                        System.StringComparison.Ordinal))
                {
                    return grupo;
                }
            }

            return null;
        }

        private System.Drawing.PointF
            CrearPuntoNormalizadoSeccion2P(
                double xLocal,
                double zLocal)
        {
            double espesor =
                vistaSeccionActual != null
                    ? vistaSeccionActual.Espesor
                    : seccionEspesorActual;

            double altura =
                vistaSeccionActual != null
                    ? vistaSeccionActual.Altura
                    : seccionAlturaActual;

            if (espesor <= 1e-9 ||
                altura <= 1e-9)
            {
                return new System.Drawing.PointF(
                    0.5F,
                    0.5F);
            }

            // NO CLAMP:
            // igual que el editor de vigas, el trazo exacto puede salir
            // del anfitrión. Guardamos la referencia relativa a la
            // sección real para poder reutilizarla en otra serie.
            return new System.Drawing.PointF(
                (float)(
                    (xLocal +
                     espesor * 0.5) /
                    espesor),
                (float)(
                    zLocal /
                    altura));
        }

        private System.Drawing.PointF
            ObtenerPuntoModeloSeccion2P(
                double u,
                double v)
        {
            double espesor =
                vistaSeccionActual != null
                    ? vistaSeccionActual.Espesor
                    : seccionEspesorActual;

            double altura =
                vistaSeccionActual != null
                    ? vistaSeccionActual.Altura
                    : seccionAlturaActual;

            return new System.Drawing.PointF(
                (float)(
                    -espesor * 0.5 +
                    u * espesor),
                (float)(
                    v * altura));
        }

        private System.Drawing.PointF
            ObtenerInicioModeloGrupoHorizontal2P(
                AceroMuroGrupoHorizontal2Puntos grupo)
        {
            return grupo == null
                ? System.Drawing.PointF.Empty
                : ObtenerPuntoModeloSeccion2P(
                    grupo.InicioU,
                    grupo.InicioV);
        }

        private System.Drawing.PointF
            ObtenerFinModeloGrupoHorizontal2P(
                AceroMuroGrupoHorizontal2Puntos grupo)
        {
            return grupo == null
                ? System.Drawing.PointF.Empty
                : ObtenerPuntoModeloSeccion2P(
                    grupo.FinU,
                    grupo.FinV);
        }

        private double DistanciaPuntoSegmentoPx(
            System.Drawing.Point p,
            System.Drawing.PointF a,
            System.Drawing.PointF b)
        {
            double vx = b.X - a.X;
            double vy = b.Y - a.Y;

            double wx = p.X - a.X;
            double wy = p.Y - a.Y;

            double vv =
                vx * vx +
                vy * vy;

            if (vv <= 1e-9)
            {
                double dx =
                    p.X - a.X;

                double dy =
                    p.Y - a.Y;

                return System.Math.Sqrt(
                    dx * dx +
                    dy * dy);
            }

            double t =
                (wx * vx +
                 wy * vy) /
                vv;

            t =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        1.0,
                        t));

            double qx =
                a.X +
                t * vx;

            double qy =
                a.Y +
                t * vy;

            double ddx =
                p.X - qx;

            double ddy =
                p.Y - qy;

            return System.Math.Sqrt(
                ddx * ddx +
                ddy * ddy);
        }

        private bool TryDetectarExtremoGrupoHorizontal2P(
            System.Drawing.Point punto,
            out string grupoId,
            out bool esInicio)
        {
            grupoId = "";
            esInicio = false;

            double mejor =
                16.0;

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF aModelo =
                    ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF bModelo =
                    ObtenerFinModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            aModelo.X),
                        PantallaYSeccion(
                            aModelo.Y));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            bModelo.X),
                        PantallaYSeccion(
                            bModelo.Y));

                double da =
                    System.Math.Sqrt(
                        System.Math.Pow(
                            punto.X - a.X,
                            2.0) +
                        System.Math.Pow(
                            punto.Y - a.Y,
                            2.0));

                double db =
                    System.Math.Sqrt(
                        System.Math.Pow(
                            punto.X - b.X,
                            2.0) +
                        System.Math.Pow(
                            punto.Y - b.Y,
                            2.0));

                if (da <= mejor)
                {
                    mejor = da;
                    grupoId = grupo.Id;
                    esInicio = true;
                }

                if (db <= mejor)
                {
                    mejor = db;
                    grupoId = grupo.Id;
                    esInicio = false;
                }
            }

            return
                !string.IsNullOrWhiteSpace(
                    grupoId);
        }

        private bool TryDetectarGrupoHorizontal2P(
            System.Drawing.Point punto,
            out string grupoId)
        {
            grupoId = "";

            double mejor =
                12.0;

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF aModelo =
                    ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF bModelo =
                    ObtenerFinModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            aModelo.X),
                        PantallaYSeccion(
                            aModelo.Y));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            bModelo.X),
                        PantallaYSeccion(
                            bModelo.Y));

                double d =
                    DistanciaPuntoSegmentoPx(
                        punto,
                        a,
                        b);

                if (d <= mejor)
                {
                    mejor = d;
                    grupoId = grupo.Id;
                }
            }

            return
                !string.IsNullOrWhiteSpace(
                    grupoId);
        }

        private AceroMuroVinculoGuiaHorizontal2P
            ObtenerTipoVinculoGuiaDesdeTexto(
                string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            if (texto.IndexOf(
                "MALLA A",
                System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return
                    AceroMuroVinculoGuiaHorizontal2P.MallaA;
            }

            if (texto.IndexOf(
                "MALLA B",
                System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return
                    AceroMuroVinculoGuiaHorizontal2P.MallaB;
            }

            if (texto.IndexOf(
                "UNA MALLA",
                System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return
                    AceroMuroVinculoGuiaHorizontal2P.UnaMalla;
            }

            return
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
        }

        private bool TryObtenerXGuiaVinculada(
            AceroMuroVinculoGuiaHorizontal2P tipo,
            out double x)
        {
            x = 0.0;

            if (tipo ==
                AceroMuroVinculoGuiaHorizontal2P.Ninguno)
            {
                return false;
            }

            System.Collections.Generic.List<
                System.Tuple<double, string>> guias =
                    ObtenerGuiasXHorizontalesSeccion();

            foreach (
                System.Tuple<double, string> guia
                in guias)
            {
                if (guia == null)
                    continue;

                if (ObtenerTipoVinculoGuiaDesdeTexto(
                        guia.Item2) == tipo)
                {
                    x = guia.Item1;
                    return true;
                }
            }

            return false;
        }

        private bool TryObtenerZVinculado(
            AceroMuroVinculoVertical2P tipo,
            out double z)
        {
            z = 0.0;

            if (tipo ==
                AceroMuroVinculoVertical2P.Ninguno)
            {
                return false;
            }

            double zInferior;
            double zSuperior;

            ObtenerRangoSeguroGuiasHorizontalesSeccion(
                out zInferior,
                out zSuperior);

            if (tipo ==
                AceroMuroVinculoVertical2P.LimiteInferior)
            {
                z = zInferior;
                return true;
            }

            if (tipo ==
                AceroMuroVinculoVertical2P.LimiteSuperior)
            {
                z = zSuperior;
                return true;
            }

            return false;
        }

        private void EvaluarCandidatoSnap2P(
            System.Drawing.Point cursor,
            double x,
            double z,
            string texto,
            AceroMuroVinculoGuiaHorizontal2P vinculoGuia,
            AceroMuroVinculoVertical2P vinculoVertical,
            double umbralPx,
            ref AceroMuroSnapPunto2P mejor)
        {
            double px =
                PantallaXSeccion(
                    x);

            double py =
                PantallaYSeccion(
                    z);

            double dx =
                cursor.X -
                px;

            double dy =
                cursor.Y -
                py;

            double distancia =
                System.Math.Sqrt(
                    dx * dx +
                    dy * dy);

            if (distancia > umbralPx)
                return;

            if (mejor == null ||
                !mejor.Valido ||
                distancia <
                    mejor.DistanciaPx)
            {
                mejor =
                    new AceroMuroSnapPunto2P
                    {
                        Valido = true,
                        X = x,
                        Z = z,
                        DistanciaPx = distancia,
                        Texto = texto ?? "",
                        VinculoGuia = vinculoGuia,
                        VinculoVertical = vinculoVertical
                    };
            }
        }

        private void EvaluarCandidatoSnap2PDistancia(
            double distanciaPx,
            double x,
            double z,
            string texto,
            AceroMuroVinculoGuiaHorizontal2P vinculoGuia,
            AceroMuroVinculoVertical2P vinculoVertical,
            double umbralPx,
            ref AceroMuroSnapPunto2P mejor)
        {
            if (distanciaPx > umbralPx)
                return;

            if (mejor == null ||
                !mejor.Valido ||
                distanciaPx <
                    mejor.DistanciaPx)
            {
                mejor =
                    new AceroMuroSnapPunto2P
                    {
                        Valido = true,
                        X = x,
                        Z = z,
                        DistanciaPx = distanciaPx,
                        Texto = texto ?? "",
                        VinculoGuia = vinculoGuia,
                        VinculoVertical = vinculoVertical
                    };
            }
        }

        private AceroMuroSnapPunto2P ResolverSnapInteligente2P(
            System.Drawing.Point cursor,
            bool tieneReferencia,
            double referenciaX,
            double referenciaZ)
        {
            double xLibre =
                ModeloXSeccionDesdePantalla(
                    cursor.X);

            double zLibre =
                ModeloYSeccionDesdePantalla(
                    cursor.Y);

            AceroMuroSnapPunto2P mejor =
                new AceroMuroSnapPunto2P
                {
                    Valido = false,
                    X = xLibre,
                    Z = zLibre
                };

            if (!osnapActivo ||
                vistaSeccionActual == null)
            {
                return mejor;
            }

            double zInferior;
            double zSuperior;

            ObtenerRangoSeguroGuiasHorizontalesSeccion(
                out zInferior,
                out zSuperior);

            System.Collections.Generic.List<
                System.Tuple<double, string>> guias =
                    ObtenerGuiasXHorizontalesSeccion();

            // =====================================================
            // 1. EXTREMOS DE GUIA
            // Máxima prioridad conceptual: si captura aquí, X e Y
            // quedan vinculados a la referencia paramétrica.
            // =====================================================
            foreach (
                System.Tuple<double, string> guia
                in guias)
            {
                if (guia == null)
                    continue;

                AceroMuroVinculoGuiaHorizontal2P tipo =
                    ObtenerTipoVinculoGuiaDesdeTexto(
                        guia.Item2);

                EvaluarCandidatoSnap2P(
                    cursor,
                    guia.Item1,
                    zInferior,
                    "EXTREMO GUIA INF | " +
                        guia.Item2,
                    tipo,
                    AceroMuroVinculoVertical2P.LimiteInferior,
                    22.0,
                    ref mejor);

                EvaluarCandidatoSnap2P(
                    cursor,
                    guia.Item1,
                    zSuperior,
                    "EXTREMO GUIA SUP | " +
                        guia.Item2,
                    tipo,
                    AceroMuroVinculoVertical2P.LimiteSuperior,
                    22.0,
                    ref mejor);
            }

            // =====================================================
            // 2. EXTREMOS DE GRUPOS YA CREADOS
            // Comportamiento tipo ENDPOINT.
            // Si el extremo original está vinculado a una guía,
            // propagamos ese vínculo.
            // =====================================================
            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                if (herramientaSeccion ==
                        AceroMuroHerramientaEdicion.MoverDosPuntos &&
                    EsGrupoHorizontalSeleccionado(
                        grupo.Id))
                {
                    continue;
                }

                System.Drawing.PointF a =
                    ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF b =
                    ObtenerFinModeloGrupoHorizontal2P(
                        grupo);

                EvaluarCandidatoSnap2P(
                    cursor,
                    a.X,
                    a.Y,
                    "EXTREMO ACERO",
                    grupo.InicioVinculoGuia,
                    grupo.InicioVinculoVertical,
                    18.0,
                    ref mejor);

                EvaluarCandidatoSnap2P(
                    cursor,
                    b.X,
                    b.Y,
                    "EXTREMO ACERO",
                    grupo.FinVinculoGuia,
                    grupo.FinVinculoVertical,
                    18.0,
                    ref mejor);
            }

            // =====================================================
            // 2B. ACEROS ALEDAÑOS
            //
            // Tracking magnético contra barras vecinas:
            // - misma cota Z;
            // - misma coordenada X;
            // - colineal con la barra/grupo;
            // - punto real de una distribución vecina.
            //
            // Se aplica tanto al crear como al extender extremos.
            // =====================================================
            EvaluarSnapAcerosAledanos(
                cursor,
                xLibre,
                zLibre,
                ref mejor);

            // =====================================================
            // 3. EXTREMOS DEL ANFITRIÓN
            // =====================================================
            double medioEspesor =
                vistaSeccionActual.Espesor * 0.5;

            double altura =
                vistaSeccionActual.Altura;

            EvaluarCandidatoSnap2P(
                cursor,
                -medioEspesor,
                0.0,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                12.0,
                ref mejor);

            EvaluarCandidatoSnap2P(
                cursor,
                medioEspesor,
                0.0,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                12.0,
                ref mejor);

            EvaluarCandidatoSnap2P(
                cursor,
                -medioEspesor,
                altura,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                12.0,
                ref mejor);

            EvaluarCandidatoSnap2P(
                cursor,
                medioEspesor,
                altura,
                "EXTREMO MURO",
                AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                AceroMuroVinculoVertical2P.Ninguno,
                12.0,
                ref mejor);

            // =====================================================
            // 4. PERPENDICULAR A GUIA DESDE EL PRIMER PUNTO
            //
            // Las guías son verticales, por tanto la perpendicular
            // es horizontal: Z = Z del primer punto.
            // =====================================================
            if (tieneReferencia)
            {
                foreach (
                    System.Tuple<double, string> guia
                    in guias)
                {
                    if (guia == null)
                        continue;

                    AceroMuroVinculoGuiaHorizontal2P tipo =
                        ObtenerTipoVinculoGuiaDesdeTexto(
                            guia.Item2);

                    EvaluarCandidatoSnap2P(
                        cursor,
                        guia.Item1,
                        referenciaZ,
                        "PERPENDICULAR | " +
                            guia.Item2,
                        tipo,
                        AceroMuroVinculoVertical2P.Ninguno,
                        20.0,
                        ref mejor);
                }
            }

            // =====================================================
            // 5. CERCANO SOBRE LA GUIA
            //
            // No obliga al extremo superior/inferior: conserva Z del
            // cursor, pero X queda asociado a la guía.
            // =====================================================
            foreach (
                System.Tuple<double, string> guia
                in guias)
            {
                if (guia == null)
                    continue;

                float xPantalla =
                    PantallaXSeccion(
                        guia.Item1);

                double distanciaPx =
                    System.Math.Abs(
                        cursor.X -
                        xPantalla);

                if (zLibre >=
                        System.Math.Min(
                            zInferior,
                            zSuperior) &&
                    zLibre <=
                        System.Math.Max(
                            zInferior,
                            zSuperior))
                {
                    EvaluarCandidatoSnap2PDistancia(
                        distanciaPx,
                        guia.Item1,
                        zLibre,
                        "CERCANO | " +
                            guia.Item2,
                        ObtenerTipoVinculoGuiaDesdeTexto(
                            guia.Item2),
                        AceroMuroVinculoVertical2P.Ninguno,
                        16.0,
                        ref mejor);
                }
            }

            // =====================================================
            // 6. ALINEADO H / V CON EL PRIMER PUNTO
            // =====================================================
            if (tieneReferencia)
            {
                double distanciaHorizontalPx =
                    System.Math.Abs(
                        PantallaYSeccion(
                            referenciaZ) -
                        cursor.Y);

                EvaluarCandidatoSnap2PDistancia(
                    distanciaHorizontalPx,
                    xLibre,
                    referenciaZ,
                    "ALINEADO HORIZONTAL",
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.Ninguno,
                    12.0,
                    ref mejor);

                double distanciaVerticalPx =
                    System.Math.Abs(
                        PantallaXSeccion(
                            referenciaX) -
                        cursor.X);

                EvaluarCandidatoSnap2PDistancia(
                    distanciaVerticalPx,
                    referenciaX,
                    zLibre,
                    "ALINEADO VERTICAL",
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno,
                    AceroMuroVinculoVertical2P.Ninguno,
                    12.0,
                    ref mejor);
            }

            if (mejor.Valido)
            {
                snapSeccionVisible = true;
                snapSeccionPuntoValido = true;

                snapSeccionPuntoX =
                    mejor.X;

                snapSeccionPuntoZ =
                    mejor.Z;

                snapSeccionTexto =
                    mejor.Texto ?? "";

                string textoUpper =
                    snapSeccionTexto.ToUpperInvariant();

                if (textoUpper.Contains(
                    "EXTREMO"))
                {
                    snapSeccionModo =
                        "EXTREMO";
                }
                else if (textoUpper.Contains(
                    "PERPENDICULAR"))
                {
                    snapSeccionModo =
                        "PERPENDICULAR";
                }
                else if (textoUpper.Contains(
                    "CERCANO"))
                {
                    snapSeccionModo =
                        "CERCANO";
                }
                else if (textoUpper.Contains(
                    "ALINEADO HORIZONTAL"))
                {
                    snapSeccionModo =
                        "ALINEADO H";
                }
                else if (textoUpper.Contains(
                    "ALINEADO VERTICAL"))
                {
                    snapSeccionModo =
                        "ALINEADO V";
                }
                else
                {
                    snapSeccionModo =
                        "OSNAP";
                }

                if (mejor.VinculoGuia !=
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno)
                {
                    snapSeccionVertical = true;
                    snapSeccionValor =
                        mejor.X;
                }
                else
                {
                    snapSeccionVertical = false;
                    snapSeccionValor =
                        mejor.Z;
                }
            }
            else
            {
                snapSeccionVisible = false;
                snapSeccionPuntoValido = false;
                snapSeccionTexto = "";
                snapSeccionModo = "";
            }

            return mejor;
        }

        private void ActualizarPuntoGrupoVinculado(
            AceroMuroGrupoHorizontal2Puntos grupo,
            bool inicio)
        {
            if (grupo == null ||
                vistaSeccionActual == null)
            {
                return;
            }

            System.Drawing.PointF actual =
                inicio
                    ? ObtenerPuntoModeloSeccion2P(
                        grupo.InicioU,
                        grupo.InicioV)
                    : ObtenerPuntoModeloSeccion2P(
                        grupo.FinU,
                        grupo.FinV);

            double x =
                actual.X;

            double z =
                actual.Y;

            AceroMuroVinculoGuiaHorizontal2P vinculoGuia =
                inicio
                    ? grupo.InicioVinculoGuia
                    : grupo.FinVinculoGuia;

            AceroMuroVinculoVertical2P vinculoVertical =
                inicio
                    ? grupo.InicioVinculoVertical
                    : grupo.FinVinculoVertical;

            double valor;

            if (TryObtenerXGuiaVinculada(
                vinculoGuia,
                out valor))
            {
                x = valor;
            }

            if (TryObtenerZVinculado(
                vinculoVertical,
                out valor))
            {
                z = valor;
            }

            System.Drawing.PointF normalizado =
                CrearPuntoNormalizadoSeccion2P(
                    x,
                    z);

            if (inicio)
            {
                grupo.InicioU =
                    normalizado.X;

                grupo.InicioV =
                    normalizado.Y;
            }
            else
            {
                grupo.FinU =
                    normalizado.X;

                grupo.FinV =
                    normalizado.Y;
            }
        }

        private void ActualizarGruposVinculadosAGuiasSeccion()
        {
            if (vistaSeccionActual == null ||
                gruposHorizontales2Puntos.Count == 0)
            {
                return;
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                ActualizarPuntoGrupoVinculado(
                    grupo,
                    true);

                ActualizarPuntoGrupoVinculado(
                    grupo,
                    false);
            }

            ActualizarResumenEditorGrupoHorizontal2P();
        }


        private void IniciarDistribucionHorizontal2P(
            System.Drawing.Point ubicacion)
        {
            AceroMuroSnapPunto2P snap =
                ResolverSnapInteligente2P(
                    ubicacion,
                    false,
                    0.0,
                    0.0);

            double x =
                snap.X;

            double z =
                snap.Z;

            creandoHorizontalDosPuntos =
                true;

            horizontal2PEsperandoSegundoClic =
                true;

            horizontal2PInicioPantalla =
                ubicacion;

            horizontal2PInicioX = x;
            horizontal2PInicioZ = z;
            horizontal2PFinX = x;
            horizontal2PFinZ = z;

            horizontal2PInicioVinculoGuia =
                snap.Valido
                    ? snap.VinculoGuia
                    : AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            horizontal2PInicioVinculoVertical =
                snap.Valido
                    ? snap.VinculoVertical
                    : AceroMuroVinculoVertical2P.Ninguno;

            horizontal2PFinVinculoGuia =
                horizontal2PInicioVinculoGuia;

            horizontal2PFinVinculoVertical =
                horizontal2PInicioVinculoVertical;

            grupoHorizontal2PSeleccionadoId = "";
            verticalesSeccionSeleccionados = false;

            pnlVistaSeccion.Capture = true;
            pnlVistaSeccion.Cursor =
                System.Windows.Forms.Cursors.Cross;

            pnlVistaSeccion.Invalidate();
        }

        private void ActualizarDistribucionHorizontal2P(
            System.Drawing.Point ubicacion)
        {
            if (!creandoHorizontalDosPuntos)
                return;

            AceroMuroSnapPunto2P snap =
                ResolverSnapInteligente2P(
                    ubicacion,
                    true,
                    horizontal2PInicioX,
                    horizontal2PInicioZ);

            horizontal2PFinX =
                snap.X;

            horizontal2PFinZ =
                snap.Z;

            horizontal2PFinVinculoGuia =
                snap.Valido
                    ? snap.VinculoGuia
                    : AceroMuroVinculoGuiaHorizontal2P.Ninguno;

            horizontal2PFinVinculoVertical =
                snap.Valido
                    ? snap.VinculoVertical
                    : AceroMuroVinculoVertical2P.Ninguno;

            pnlVistaSeccion.Invalidate();
        }

        private void FinalizarDistribucionHorizontal2P(
            System.Drawing.Point ubicacion)
        {
            if (!creandoHorizontalDosPuntos)
                return;

            ActualizarDistribucionHorizontal2P(
                ubicacion);

            double dx =
                horizontal2PFinX -
                horizontal2PInicioX;

            double dz =
                horizontal2PFinZ -
                horizontal2PInicioZ;

            double longitud =
                System.Math.Sqrt(
                    dx * dx +
                    dz * dz);

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        1.0,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            if (longitud > tolerancia)
            {
                RegistrarDeshacer();

                System.Drawing.PointF p0 =
                    CrearPuntoNormalizadoSeccion2P(
                        horizontal2PInicioX,
                        horizontal2PInicioZ);

                System.Drawing.PointF p1 =
                    CrearPuntoNormalizadoSeccion2P(
                        horizontal2PFinX,
                        horizontal2PFinZ);

                double espaciadoInicialCm =
                    System.Math.Max(
                        0.5,
                        ObtenerEspHorizontalCmActual());

                AceroMuroGrupoHorizontal2Puntos grupo =
                    new AceroMuroGrupoHorizontal2Puntos
                    {
                        InicioU = p0.X,
                        InicioV = p0.Y,
                        FinU = p1.X,
                        FinV = p1.Y,
                        InicioVinculoGuia =
                            horizontal2PInicioVinculoGuia,
                        InicioVinculoVertical =
                            horizontal2PInicioVinculoVertical,
                        FinVinculoGuia =
                            horizontal2PFinVinculoGuia,
                        FinVinculoVertical =
                            horizontal2PFinVinculoVertical,
                        ReglaDistribucion =
                            AceroMuroReglaDistribucionGrupo.EspaciadoMaximo,
                        EspaciamientoMaximoCm =
                            espaciadoInicialCm,
                        Cantidad = 4,
                        TipoBarraId =
                            ObtenerTipoPorDefectoGrupo(false) != null
                                ? ObtenerTipoPorDefectoGrupo(false).Id.Value
                                : 0,
                        TipoBarraNombre =
                            ObtenerTipoPorDefectoGrupo(false) != null
                                ? ObtenerTipoPorDefectoGrupo(false).Name
                                : ""
                    };

                gruposHorizontales2Puntos.Add(
                    grupo);

                SeleccionarSoloGrupoHorizontal(
                    grupo.Id);

                ActualizarPanelGrupoSeleccionado();
            }

            creandoHorizontalDosPuntos =
                false;

            horizontal2PEsperandoSegundoClic =
                false;

            horizontal2PInicioVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            horizontal2PInicioVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;
            horizontal2PFinVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            horizontal2PFinVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

            pnlVistaSeccion.Capture = false;
            pnlVistaSeccion.Cursor =
                System.Windows.Forms.Cursors.Cross;

            // La herramienta sigue activa para poder dibujar
            // otro grupo inmediatamente, igual que el editor de vigas.
            ActualizarAyudasHerramientas();

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();
        }

        private void ActualizarArrastreExtremoHorizontal2P(
            System.Drawing.Point ubicacion)
        {
            if (!arrastrandoExtremoHorizontal2P)
                return;

            AceroMuroGrupoHorizontal2Puntos grupo =
                ObtenerGrupoHorizontal2PuntosPorId(
                    grupoHorizontal2PSeleccionadoId);

            if (grupo == null)
                return;

            System.Drawing.PointF otro =
                arrastrandoInicioHorizontal2P
                    ? ObtenerFinModeloGrupoHorizontal2P(
                        grupo)
                    : ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

            AceroMuroSnapPunto2P snap =
                ResolverSnapInteligente2P(
                    ubicacion,
                    true,
                    otro.X,
                    otro.Y);

            System.Drawing.PointF normalizado =
                CrearPuntoNormalizadoSeccion2P(
                    snap.X,
                    snap.Z);

            if (arrastrandoInicioHorizontal2P)
            {
                grupo.InicioU =
                    normalizado.X;

                grupo.InicioV =
                    normalizado.Y;

                grupo.InicioVinculoGuia =
                    snap.Valido
                        ? snap.VinculoGuia
                        : AceroMuroVinculoGuiaHorizontal2P.Ninguno;

                grupo.InicioVinculoVertical =
                    snap.Valido
                        ? snap.VinculoVertical
                        : AceroMuroVinculoVertical2P.Ninguno;
            }
            else
            {
                grupo.FinU =
                    normalizado.X;

                grupo.FinV =
                    normalizado.Y;

                grupo.FinVinculoGuia =
                    snap.Valido
                        ? snap.VinculoGuia
                        : AceroMuroVinculoGuiaHorizontal2P.Ninguno;

                grupo.FinVinculoVertical =
                    snap.Valido
                        ? snap.VinculoVertical
                        : AceroMuroVinculoVertical2P.Ninguno;
            }

            ActualizarResumenEditorGrupoHorizontal2P();

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();
        }

        private void PnlVistaSeccion_MouseDown(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            // -----------------------------------------------------
            // PAN CON RUEDA / BOTÓN CENTRAL
            // -----------------------------------------------------
            if (e.Button ==
                System.Windows.Forms.MouseButtons.Middle)
            {
                if (editandoCotaInline)
                {
                    FinalizarEditorCotaInline(
                        true);
                }

                paneandoSeccion = true;
                ultimoMouseSeccion = e.Location;

                pnlVistaSeccion.Capture = true;
                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Hand;

                return;
            }

            if (e.Button !=
                System.Windows.Forms.MouseButtons.Left)
            {
                return;
            }

            if (vistaSeccionActual == null ||
                vistaSeccionActual.Espesor <= 1e-9 ||
                vistaSeccionActual.Altura <= 1e-9)
            {
                return;
            }

            bool ctrl =
                CtrlPresionado();

            // -----------------------------------------------------
            // CREAR VERTICALES CON DOS PUNTOS
            // -----------------------------------------------------
            if (herramientaSeccion ==
                AceroMuroHerramientaEdicion.DistribuirVerticalDosPuntos)
            {
                if (creandoVerticalDosPuntos &&
                    vertical2PEsperandoSegundoClic)
                {
                    FinalizarDistribucionVertical2P(
                        e.Location);

                    return;
                }

                IniciarDistribucionVertical2P(
                    e.Location);

                return;
            }

            // -----------------------------------------------------
            // DISTRIBUIR HORIZONTALES CON DOS PUNTOS
            // -----------------------------------------------------
            if (herramientaSeccion ==
                AceroMuroHerramientaEdicion.DistribuirHorizontalDosPuntos)
            {
                if (creandoHorizontalDosPuntos &&
                    horizontal2PEsperandoSegundoClic)
                {
                    FinalizarDistribucionHorizontal2P(
                        e.Location);

                    return;
                }

                IniciarDistribucionHorizontal2P(
                    e.Location);

                return;
            }

            // =====================================================
            // V8.55 - SELECCIÓN MÚLTIPLE CTRL
            //
            // Clic normal:
            //   limpia la selección anterior y selecciona solo 1.
            //
            // CTRL + clic:
            //   agrega o quita el grupo tocado.
            //
            // CTRL sobre una manija NO inicia arrastre; solo alterna
            // la selección para evitar mover accidentalmente grupos.
            // =====================================================
            if (herramientaSeccion ==
                AceroMuroHerramientaEdicion.SeleccionarMover)
            {
                string grupoVId;
                bool esInicioV;

                if (gruposVerticales2Puntos.Count > 0 &&
                    TryDetectarExtremoGrupoVertical2P(
                        e.Location,
                        out grupoVId,
                        out esInicioV))
                {
                    if (ctrl)
                    {
                        ActualizarSeleccionGrupoVerticalDesdeClick(
                            grupoVId,
                            true);

                        pnlVistaSeccion.Invalidate();
                        return;
                    }

                    RegistrarDeshacer();

                    ActualizarSeleccionGrupoVerticalDesdeClick(
                        grupoVId,
                        false);

                    arrastrandoExtremoVertical2P = true;
                    arrastrandoInicioVertical2P =
                        esInicioV;

                    pnlVistaSeccion.Capture = true;
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.SizeAll;

                    pnlVistaSeccion.Invalidate();
                    return;
                }

                if (gruposVerticales2Puntos.Count > 0 &&
                    TryDetectarGrupoVertical2P(
                        e.Location,
                        out grupoVId))
                {
                    ActualizarSeleccionGrupoVerticalDesdeClick(
                        grupoVId,
                        ctrl);

                    pnlVistaSeccion.Invalidate();
                    return;
                }

                string grupoHId;
                bool esInicioH;

                if (gruposHorizontales2Puntos.Count > 0 &&
                    TryDetectarExtremoGrupoHorizontal2P(
                        e.Location,
                        out grupoHId,
                        out esInicioH))
                {
                    if (ctrl)
                    {
                        ActualizarSeleccionGrupoHorizontalDesdeClick(
                            grupoHId,
                            true);

                        pnlVistaSeccion.Invalidate();
                        return;
                    }

                    RegistrarDeshacer();

                    ActualizarSeleccionGrupoHorizontalDesdeClick(
                        grupoHId,
                        false);

                    MostrarEditorGrupoHorizontal2P(
                        grupoHId);

                    verticalesSeccionSeleccionados = false;

                    arrastrandoExtremoHorizontal2P =
                        true;

                    arrastrandoInicioHorizontal2P =
                        esInicioH;

                    AceroMuroGrupoHorizontal2Puntos grupo =
                        ObtenerGrupoHorizontal2PuntosPorId(
                            grupoHId);

                    if (grupo != null &&
                        nudSecCantidadDosPuntos != null)
                    {
                        decimal valor =
                            System.Math.Max(
                                (int)nudSecCantidadDosPuntos.Minimum,
                                System.Math.Min(
                                    (int)nudSecCantidadDosPuntos.Maximum,
                                    grupo.Cantidad));

                        nudSecCantidadDosPuntos.Value =
                            valor;
                    }

                    pnlVistaSeccion.Capture = true;
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.SizeAll;

                    pnlVistaSeccion.Invalidate();
                    return;
                }

                if (gruposHorizontales2Puntos.Count > 0 &&
                    TryDetectarGrupoHorizontal2P(
                        e.Location,
                        out grupoHId))
                {
                    ActualizarSeleccionGrupoHorizontalDesdeClick(
                        grupoHId,
                        ctrl);

                    if (EsGrupoHorizontalSeleccionado(
                        grupoHId))
                    {
                        MostrarEditorGrupoHorizontal2P(
                            grupoHId);

                        AceroMuroGrupoHorizontal2Puntos grupo =
                            ObtenerGrupoHorizontal2PuntosPorId(
                                grupoHId);

                        if (grupo != null &&
                            nudSecCantidadDosPuntos != null)
                        {
                            decimal valor =
                                System.Math.Max(
                                    (int)nudSecCantidadDosPuntos.Minimum,
                                    System.Math.Min(
                                        (int)nudSecCantidadDosPuntos.Maximum,
                                        grupo.Cantidad));

                            nudSecCantidadDosPuntos.Value =
                                valor;
                        }
                    }
                    else
                    {
                        OcultarEditorGrupoHorizontal2P();
                    }

                    verticalesSeccionSeleccionados = false;

                    pnlVistaSeccion.Invalidate();
                    return;
                }

                // Clic en vacío:
                // con CTRL conserva la selección;
                // sin CTRL limpia los grupos seleccionados.
                if (!ctrl &&
                    ObtenerCantidadGruposSeleccionados() > 0)
                {
                    LimpiarSeleccionMultipleGrupos(
                        true);

                    OcultarEditorGrupoHorizontal2P();

                    if (pnlVistaSeccion != null)
                        pnlVistaSeccion.Invalidate();
                }
            }

            // -----------------------------------------------------
            // SELECCIÓN DIRECTA DE LOS ACEROS VERTICALES ANTIGUOS
            // -----------------------------------------------------
            if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.SeleccionarMover &&
                chkVerticales != null &&
                chkVerticales.Checked)
            {
                string handleVertical =
                    ObtenerHandleSeccionBajoCursor(
                        e.Location);

                if (!string.IsNullOrWhiteSpace(
                    handleVertical))
                {
                    if (!ctrl)
                    {
                        LimpiarSeleccionMultipleGrupos(
                            true);
                    }

                    RegistrarDeshacer();

                    verticalesSeccionSeleccionados = true;
                    OcultarEditorGrupoHorizontal2P();

                    seccionHandleSeleccionado =
                        handleVertical;

                    arrastrandoHandleSeccion = true;
                    seccionHandleActivo =
                        handleVertical;

                    pnlVistaSeccion.Capture = true;
                    pnlVistaSeccion.Cursor =
                        handleVertical == "IZQ" ||
                        handleVertical == "DER"
                            ? System.Windows.Forms.Cursors.SizeWE
                            : System.Windows.Forms.Cursors.SizeNS;

                    pnlVistaSeccion.Invalidate();
                    return;
                }

                if (TryDetectarVerticalesSeccion(
                    e.Location))
                {
                    if (!ctrl)
                    {
                        LimpiarSeleccionMultipleGrupos(
                            true);
                    }

                    verticalesSeccionSeleccionados = true;
                    seccionHandleSeleccionado = "";

                    pnlVistaSeccion.Invalidate();
                    ActualizarAyudasHerramientas();
                    return;
                }

                if (!ctrl)
                    verticalesSeccionSeleccionados = false;
            }

            // Selector de gancho directamente dentro de la vista.
            if (ProcesarClickSelectorGancho(
                e.Location))
            {
                return;
            }

            // La cota de extensión fuera del anfitrión se edita
            // directamente haciendo clic sobre su valor.
            if (ProcesarClickCotaExtensionVertical(
                e.Location))
            {
                return;
            }

            string handle =
                ObtenerHandleSeccionBajoCursor(
                    e.Location);

            if (herramientaSeccion ==
                AceroMuroHerramientaEdicion.MoverDosPuntos)
            {
                // =================================================
                // CASO PRINCIPAL V8.57:
                // mover uno o varios GRUPOS seleccionados como Revit.
                // =================================================
                if (ObtenerCantidadGruposSeleccionados() > 0)
                {
                    if (faseMoverDosPuntosSeccion == 0)
                    {
                        AceroMuroSnapPunto2P snap =
                            ResolverSnapMoverGruposDosPuntos(
                                e.Location,
                                false);

                        puntoBaseMoverGruposModelo =
                            new System.Drawing.PointF(
                                (float)snap.X,
                                (float)snap.Z);

                        puntoDestinoMoverGruposModelo =
                            puntoBaseMoverGruposModelo;

                        faseMoverDosPuntosSeccion = 1;

                        ActualizarAyudasHerramientas();
                        pnlVistaSeccion.Invalidate();

                        return;
                    }

                    AceroMuroSnapPunto2P snapDestino =
                        ResolverSnapMoverGruposDosPuntos(
                            e.Location,
                            true);

                    puntoDestinoMoverGruposModelo =
                        new System.Drawing.PointF(
                            (float)snapDestino.X,
                            (float)snapDestino.Z);

                    RegistrarDeshacer();

                    AplicarMoverGruposSeleccionadosDosPuntos(
                        puntoBaseMoverGruposModelo,
                        puntoDestinoMoverGruposModelo);

                    faseMoverDosPuntosSeccion = 0;

                    CambiarHerramientaSeccion(
                        AceroMuroHerramientaEdicion.SeleccionarMover);

                    return;
                }

                // =================================================
                // COMPATIBILIDAD:
                // si no hay grupo seleccionado conserva el antiguo
                // MOVER 2 PTOS de las manijas generales de sección.
                // =================================================
                if (string.IsNullOrWhiteSpace(
                    seccionHandleSeleccionado))
                {
                    if (!string.IsNullOrWhiteSpace(handle))
                    {
                        seccionHandleSeleccionado =
                            handle;

                        faseMoverDosPuntosSeccion = 0;
                        ActualizarAyudasHerramientas();
                        pnlVistaSeccion.Invalidate();
                    }

                    return;
                }

                if (faseMoverDosPuntosSeccion == 0)
                {
                    puntoBaseMoverDosPuntosSeccion =
                        new System.Drawing.PointF(
                            e.X,
                            e.Y);

                    faseMoverDosPuntosSeccion = 1;
                    ActualizarAyudasHerramientas();
                    return;
                }

                RegistrarDeshacer();

                AplicarMoverDosPuntosSeccion(
                    seccionHandleSeleccionado,
                    puntoBaseMoverDosPuntosSeccion,
                    new System.Drawing.PointF(
                        e.X,
                        e.Y));

                faseMoverDosPuntosSeccion = 0;

                CambiarHerramientaSeccion(
                    AceroMuroHerramientaEdicion.SeleccionarMover);

                return;
            }

            if (string.IsNullOrWhiteSpace(handle))
                return;

            RegistrarDeshacer();

            seccionHandleSeleccionado =
                handle;

            arrastrandoHandleSeccion = true;
            seccionHandleActivo = handle;

            pnlVistaSeccion.Cursor =
                handle == "IZQ" ||
                handle == "DER"
                    ? System.Windows.Forms.Cursors.SizeWE
                    : System.Windows.Forms.Cursors.SizeNS;

            pnlVistaSeccion.Invalidate();

        }

        private void PnlVistaSeccion_MouseMove(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            // -----------------------------------------------------
            // PAN: rueda/botón central presionado + arrastre
            // -----------------------------------------------------
            if (paneandoSeccion)
            {
                panSeccionX +=
                    e.X -
                    ultimoMouseSeccion.X;

                panSeccionY +=
                    e.Y -
                    ultimoMouseSeccion.Y;

                ultimoMouseSeccion =
                    e.Location;

                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Hand;

                pnlVistaSeccion.Invalidate();

                return;
            }

            // -----------------------------------------------------
            // V8.57 - MOVER GRUPOS CON 2 PUNTOS
            // -----------------------------------------------------
            if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos &&
                ObtenerCantidadGruposSeleccionados() > 0)
            {
                AceroMuroSnapPunto2P snapMover =
                    ResolverSnapMoverGruposDosPuntos(
                        e.Location,
                        faseMoverDosPuntosSeccion == 1);

                if (faseMoverDosPuntosSeccion == 1)
                {
                    puntoDestinoMoverGruposModelo =
                        new System.Drawing.PointF(
                            (float)snapMover.X,
                            (float)snapMover.Z);
                }

                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Cross;

                pnlVistaSeccion.Invalidate();

                return;
            }

            // -----------------------------------------------------
            // V8.50 - HOVER OSNAP VERTICAL ANTES DEL PRIMER CLIC
            // -----------------------------------------------------
            if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.DistribuirVerticalDosPuntos &&
                !creandoVerticalDosPuntos)
            {
                ResolverSnapInteligenteVertical2P(
                    e.Location,
                    false,
                    0.0,
                    0.0);

                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Cross;

                pnlVistaSeccion.Invalidate();

                return;
            }

            if (creandoVerticalDosPuntos)
            {
                ActualizarDistribucionVertical2P(
                    e.Location);

                return;
            }

            if (arrastrandoExtremoVertical2P)
            {
                if (e.Button ==
                    System.Windows.Forms.MouseButtons.Left)
                {
                    ActualizarArrastreExtremoVertical2P(
                        e.Location);
                }

                return;
            }

            // -----------------------------------------------------
            // V8.47 - HOVER OSNAP ANTES DEL PRIMER CLIC
            //
            // Esta era la razón principal por la que el OSNAP no se
            // sentía "tipo Autodesk": el motor solo se evaluaba después
            // de fijar el primer punto.
            //
            // Ahora, apenas CREAR H 2 PTOS está activo, mover el mouse
            // ya detecta EXTREMO / CERCANO sobre las referencias.
            // -----------------------------------------------------
            if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.DistribuirHorizontalDosPuntos &&
                !creandoHorizontalDosPuntos)
            {
                ResolverSnapInteligente2P(
                    e.Location,
                    false,
                    0.0,
                    0.0);

                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Cross;

                pnlVistaSeccion.Invalidate();

                return;
            }

            if (creandoHorizontalDosPuntos)
            {
                // Después del primer clic:
                // EXTREMO / CERCANO / PERPENDICULAR / ALINEADO.
                ActualizarDistribucionHorizontal2P(
                    e.Location);

                return;
            }

            if (arrastrandoExtremoHorizontal2P)
            {
                if (e.Button ==
                    System.Windows.Forms.MouseButtons.Left)
                {
                    ActualizarArrastreExtremoHorizontal2P(
                        e.Location);
                }

                return;
            }

            if (!arrastrandoHandleSeccion)
            {
                snapSeccionVisible = false;

                if (herramientaSeccion ==
                        AceroMuroHerramientaEdicion.SeleccionarMover &&
                    gruposVerticales2Puntos.Count > 0)
                {
                    string idV;
                    bool esInicioV;

                    if (TryDetectarExtremoGrupoVertical2P(
                            e.Location,
                            out idV,
                            out esInicioV) ||
                        TryDetectarGrupoVertical2P(
                            e.Location,
                            out idV))
                    {
                        pnlVistaSeccion.Cursor =
                            System.Windows.Forms.Cursors.Hand;

                        return;
                    }
                }

                if (herramientaSeccion ==
                        AceroMuroHerramientaEdicion.SeleccionarMover &&
                    gruposHorizontales2Puntos.Count > 0)
                {
                    string id;
                    bool esInicio;

                    if (TryDetectarExtremoGrupoHorizontal2P(
                        e.Location,
                        out id,
                        out esInicio))
                    {
                        pnlVistaSeccion.Cursor =
                            System.Windows.Forms.Cursors.Hand;

                        return;
                    }
                }

                if (herramientaSeccion ==
                        AceroMuroHerramientaEdicion.SeleccionarMover &&
                    chkVerticales != null &&
                    chkVerticales.Checked &&
                    (!string.IsNullOrWhiteSpace(
                        ObtenerHandleSeccionBajoCursor(e.Location)) ||
                     TryDetectarVerticalesSeccion(e.Location)))
                {
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Hand;
                }
                else if (PuntoSobreCotaExtensionVertical(
                    e.Location))
                {
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Hand;
                }
                else
                {
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Cross;
                }

                return;
            }

            seccionHandleSeleccionado =
                seccionHandleActivo;

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double baseLateral =
                ObtenerBaseVerticalDesdeCaraPiesVista();

            double baseVertical =
                rec + diamVert * 0.5;

            double minLibre =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        5.0,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            if (seccionHandleActivo == "IZQ")
            {
                double xLocal =
                    AplicarOsnapSeccionX(
                        ModeloXSeccionDesdePantalla(
                            e.X));

                double xDerActual =
                    seccionEspesorActual * 0.5 -
                    baseLateral -
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            ajusteSeccionDerechaCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double objetivo =
                    System.Math.Min(
                        xLocal,
                        xDerActual - minLibre);

                // SIGNADO: negativo permite sacar la barra fuera de la Cara A.
                ajusteSeccionIzquierdaCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            objetivo +
                            seccionEspesorActual * 0.5 -
                            baseLateral,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }
            else if (seccionHandleActivo == "DER")
            {
                double xLocal =
                    AplicarOsnapSeccionX(
                        ModeloXSeccionDesdePantalla(
                            e.X));

                double xIzqActual =
                    -seccionEspesorActual * 0.5 +
                    baseLateral +
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            ajusteSeccionIzquierdaCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double objetivo =
                    System.Math.Max(
                        xLocal,
                        xIzqActual + minLibre);

                ajusteSeccionDerechaCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            seccionEspesorActual * 0.5 -
                            baseLateral -
                            objetivo,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }
            else if (seccionHandleActivo == "INF")
            {
                double zLocal =
                    AplicarOsnapSeccionY(
                        ModeloYSeccionDesdePantalla(
                            e.Y));

                double zSupActual =
                    seccionAlturaActual -
                    baseVertical -
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            ajusteSeccionSuperiorCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double objetivo =
                    System.Math.Min(
                        zLocal,
                        zSupActual - minLibre);

                ajusteSeccionInferiorCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            objetivo - baseVertical,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }
            else if (seccionHandleActivo == "SUP")
            {
                double zLocal =
                    AplicarOsnapSeccionY(
                        ModeloYSeccionDesdePantalla(
                            e.Y));

                double zInfActual =
                    baseVertical +
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            ajusteSeccionInferiorCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double objetivo =
                    System.Math.Max(
                        zLocal,
                        zInfActual + minLibre);

                ajusteSeccionSuperiorCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            seccionAlturaActual -
                            baseVertical -
                            objetivo,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }

            ActualizarGruposVinculadosAGuiasSeccion();
            ActualizarGruposVerticalesVinculadosAGuias();

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();
        }

        private void PnlVistaSeccion_MouseUp(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button ==
                System.Windows.Forms.MouseButtons.Middle)
            {
                paneandoSeccion = false;
                pnlVistaSeccion.Capture = false;
                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Cross;

                return;
            }

            if (e.Button ==
                System.Windows.Forms.MouseButtons.Left)
            {
                if (creandoVerticalDosPuntos)
                {
                    ActualizarDistribucionVertical2P(
                        e.Location);

                    double dxPantalla =
                        e.X -
                        vertical2PInicioPantalla.X;

                    double dyPantalla =
                        e.Y -
                        vertical2PInicioPantalla.Y;

                    double recorridoPantalla =
                        System.Math.Sqrt(
                            dxPantalla * dxPantalla +
                            dyPantalla * dyPantalla);

                    if (recorridoPantalla >= 5.0)
                    {
                        FinalizarDistribucionVertical2P(
                            e.Location);
                    }
                    else
                    {
                        vertical2PEsperandoSegundoClic = true;
                        pnlVistaSeccion.Capture = false;
                        pnlVistaSeccion.Cursor =
                            System.Windows.Forms.Cursors.Cross;

                        ActualizarAyudasHerramientas();
                        pnlVistaSeccion.Invalidate();
                    }

                    return;
                }

                if (arrastrandoExtremoVertical2P)
                {
                    ActualizarArrastreExtremoVertical2P(
                        e.Location);

                    arrastrandoExtremoVertical2P = false;

                    pnlVistaSeccion.Capture = false;
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Cross;

                    return;
                }

                if (creandoHorizontalDosPuntos)
                {
                    ActualizarDistribucionHorizontal2P(
                        e.Location);

                    double dxPantalla =
                        e.X - horizontal2PInicioPantalla.X;

                    double dyPantalla =
                        e.Y - horizontal2PInicioPantalla.Y;

                    double recorridoPantalla =
                        System.Math.Sqrt(
                            dxPantalla * dxPantalla +
                            dyPantalla * dyPantalla);

                    // Si realmente arrastró, se confirma al soltar.
                    if (recorridoPantalla >= 5.0)
                    {
                        FinalizarDistribucionHorizontal2P(
                            e.Location);
                    }
                    else
                    {
                        // Clic simple: el primer punto queda fijado y se espera
                        // el segundo clic. Esto evita que la herramienta parezca
                        // no funcionar cuando el usuario no mantiene presionado.
                        horizontal2PEsperandoSegundoClic = true;
                        pnlVistaSeccion.Capture = false;
                        pnlVistaSeccion.Cursor =
                            System.Windows.Forms.Cursors.Cross;

                        ActualizarAyudasHerramientas();
                        pnlVistaSeccion.Invalidate();
                    }

                    return;
                }

                if (arrastrandoExtremoHorizontal2P)
                {
                    ActualizarArrastreExtremoHorizontal2P(
                        e.Location);

                    arrastrandoExtremoHorizontal2P =
                        false;

                    pnlVistaSeccion.Capture =
                        false;

                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Cross;

                    return;
                }

                arrastrandoHandleSeccion = false;
                seccionHandleActivo = "";
                snapSeccionVisible = false;

                pnlVistaSeccion.Cursor =
                    System.Windows.Forms.Cursors.Cross;
            }
        }


        private void CambiarHerramientaAlzado(
            AceroMuroHerramientaEdicion herramienta)
        {
            herramientaAlzado = herramienta;

            faseMoverDosPuntosAlzado = 0;
            faseCopiarDosPuntosAlzado = 0;

            arrastrandoHandleAlzado = false;

            ActualizarBotonesHerramienta();
            ActualizarAyudasHerramientas();
            pnlVistaAlzado.Invalidate();
        }

        private void CambiarHerramientaSeccion(
            AceroMuroHerramientaEdicion herramienta)
        {
            herramientaSeccion = herramienta;

            faseMoverDosPuntosSeccion = 0;

            puntoBaseMoverGruposModelo =
                System.Drawing.PointF.Empty;

            puntoDestinoMoverGruposModelo =
                System.Drawing.PointF.Empty;

            arrastrandoHandleSeccion = false;

            creandoHorizontalDosPuntos = false;
            horizontal2PEsperandoSegundoClic = false;
            arrastrandoExtremoHorizontal2P = false;

            creandoVerticalDosPuntos = false;
            vertical2PEsperandoSegundoClic = false;
            arrastrandoExtremoVertical2P = false;

            vertical2PInicioVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            vertical2PInicioVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;
            vertical2PFinVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            vertical2PFinVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

            horizontal2PInicioVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            horizontal2PInicioVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;
            horizontal2PFinVinculoGuia =
                AceroMuroVinculoGuiaHorizontal2P.Ninguno;
            horizontal2PFinVinculoVertical =
                AceroMuroVinculoVertical2P.Ninguno;

            snapSeccionVisible = false;
            snapSeccionPuntoValido = false;
            snapSeccionTexto = "";
            snapSeccionModo = "";

            if (herramienta !=
                AceroMuroHerramientaEdicion.SeleccionarMover)
            {
                verticalesSeccionSeleccionados = false;
            }

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Capture = false;

            ActualizarBotonesHerramienta();
            ActualizarAyudasHerramientas();
            pnlVistaSeccion.Invalidate();
        }

        private void ActualizarBotonesHerramienta()
        {
            MarcarBoton(
                btnAlzSeleccionar,
                herramientaAlzado ==
                    AceroMuroHerramientaEdicion.SeleccionarMover);

            MarcarBoton(
                btnAlzMoverDosPuntos,
                herramientaAlzado ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos);

            MarcarBoton(
                btnAlzCopiarDosPuntos,
                herramientaAlzado ==
                    AceroMuroHerramientaEdicion.CopiarDosPuntos);

            MarcarBoton(
                btnSecSeleccionar,
                herramientaSeccion ==
                    AceroMuroHerramientaEdicion.SeleccionarMover);

            MarcarBoton(
                btnSecMoverDosPuntos,
                herramientaSeccion ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos);

            MarcarBoton(
                btnSecDistribuirDosPuntos,
                herramientaSeccion ==
                    AceroMuroHerramientaEdicion.DistribuirHorizontalDosPuntos);

            MarcarBoton(
                btnSecCrearVerticalDosPuntos,
                herramientaSeccion ==
                    AceroMuroHerramientaEdicion.DistribuirVerticalDosPuntos);

            ActualizarBotonesBloqueo();
            ActualizarBotonesHistorialSeccion();
        }

        private void ActualizarAyudasHerramientas()
        {
            if (lblAyudaAlzado != null)
            {
                if (herramientaAlzado ==
                    AceroMuroHerramientaEdicion.SeleccionarMover)
                {
                    lblAyudaAlzado.Text =
                        "SELECCIONAR: jale los horizontales hasta BORDE o RECUBRIMIENTO del elemento extremo. " +
                        "Si el acero sale del anfitrión aparece COTA de desarrollo en metros; clic en el valor permite editarla inline. " +
                        "H-INICIO/H-FIN se conservan aunque cambie de 1 a 2 o más muros; BLOQ. tiene prioridad; GUARDAR/CARGAR DATA conserva ambos extremos.";
                }
                else if (herramientaAlzado ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos)
                {
                    lblAyudaAlzado.Text =
                        tramoSeleccionadoId == 0
                            ? "MOVER HORIZ.: seleccione primero el tramo/cadena horizontal."
                            : faseMoverDosPuntosAlzado == 0
                                ? "MOVER HORIZ.: indique punto base. Inicio y fin horizontales se moverán como un conjunto."
                                : "MOVER HORIZ.: indique punto destino. Puede quedar fuera del anfitrión.";
                }
                else
                {
                    lblAyudaAlzado.Text =
                        tramoSeleccionadoId == 0
                            ? "COPIAR AJUSTE: seleccione el tramo origen."
                            : faseCopiarDosPuntosAlzado == 0
                                ? "COPIAR AJUSTE: indique punto base."
                                : "COPIAR AJUSTE: indique un punto dentro del tramo destino.";
                }
            }

            if (lblAyudaSeccion != null)
            {
                if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.SeleccionarMover)
                {
                    lblAyudaSeccion.Text =
                        "SELECCIONAR: V/H editables. Si un vertical sale del anfitrión aparece COTA inferior/superior en metros; " +
                        "clic en el valor permite editar el desfase inline. DOBLE CLIC abre el editor de distribución.";
                }
                else if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.MoverDosPuntos)
                {
                    int cantidadSeleccionada =
                        ObtenerCantidadGruposSeleccionados();

                    if (cantidadSeleccionada > 0)
                    {
                        lblAyudaSeccion.Text =
                            faseMoverDosPuntosSeccion == 0
                                ? "MOVER 2 PTOS: " +
                                    cantidadSeleccionada +
                                    " grupo(s) seleccionado(s). Indique PUNTO BASE; OSNAP detecta guías, extremos y aceros aledaños."
                                : "MOVER 2 PTOS: indique PUNTO DESTINO. La vista previa gris muestra la nueva posición.";
                    }
                    else
                    {
                        lblAyudaSeccion.Text =
                            string.IsNullOrWhiteSpace(
                                seccionHandleSeleccionado)
                                ? "MOVER 2 PTOS: seleccione primero uno o varios grupos con CTRL; también admite las manijas generales."
                                : faseMoverDosPuntosSeccion == 0
                                    ? "MOVER 2 PTOS: indique punto base."
                                    : "MOVER 2 PTOS: indique punto destino.";
                    }
                }
                else if (herramientaSeccion ==
                    AceroMuroHerramientaEdicion.DistribuirVerticalDosPuntos)
                {
                    lblAyudaSeccion.Text =
                        creandoVerticalDosPuntos
                            ? "CREAR V 2 PTOS: primer punto fijado. OSNAP = EXTREMO / CERCANO / PERPENDICULAR / ALINEADO VERTICAL."
                            : "CREAR V 2 PTOS: por defecto no hay verticales. Dibuje cada grupo sobre GUIA V A/B/UNA MALLA.";
                }
                else
                {
                    lblAyudaSeccion.Text =
                        creandoHorizontalDosPuntos
                            ? horizontal2PEsperandoSegundoClic
                                ? "DISTRIBUIR 2 PTOS: primer punto fijado. Mueva el cursor y haga el SEGUNDO CLIC; también puede crear manteniendo clic y arrastrando."
                                : "DISTRIBUIR 2 PTOS: defina el segundo extremo. La línea exacta manda; OSNAP solo ayuda a capturar."
                            : "CREAR H 2 PTOS: acerque el cursor a guía/extremo ANTES de clicar. El símbolo verde confirma el snap; capturar GUIA H crea vínculo dinámico.";
                }
            }
        }

        private AceroMuroTramoVista ObtenerTramoPorId(
            long muroId)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return null;
            }

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                if (tramo.MuroId == muroId)
                    return tramo;
            }

            return null;
        }

        private AceroMuroTramoVista ObtenerTramoBajoCursorAlzado(
            System.Drawing.Point cursor)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return null;
            }

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                float x1 =
                    PantallaXAlzado(
                        tramo.XInicio);

                float x2 =
                    PantallaXAlzado(
                        tramo.XFin);

                float y1 =
                    PantallaYAlzado(
                        tramo.ZSuperior);

                float y2 =
                    PantallaYAlzado(
                        tramo.ZInferior);

                System.Drawing.RectangleF caja =
                    new System.Drawing.RectangleF(
                        System.Math.Min(
                            x1, x2),
                        System.Math.Min(
                            y1, y2),
                        System.Math.Abs(
                            x2 - x1),
                        System.Math.Abs(
                            y2 - y1));

                if (caja.Contains(
                    cursor.X,
                    cursor.Y))
                {
                    return tramo;
                }
            }

            return null;
        }

        private AceroMuroTramoVista ObtenerTramoMasCercanoX(
            double xModelo)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                vistaElevacionActual.Tramos.Count == 0)
            {
                return null;
            }

            AceroMuroTramoVista mejor = null;
            double mejorDistancia =
                double.MaxValue;

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                if (xModelo >= tramo.XInicio &&
                    xModelo <= tramo.XFin)
                {
                    return tramo;
                }

                double distancia =
                    System.Math.Min(
                        System.Math.Abs(
                            xModelo -
                            tramo.XInicio),
                        System.Math.Abs(
                            xModelo -
                            tramo.XFin));

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejor = tramo;
                }
            }

            return mejor;
        }


        private void EvaluarCandidatosOsnapAlzado(
            System.Collections.Generic.List<
                System.Tuple<double, string>> candidatos,
            double xModelo,
            ref double mejor,
            ref double mejorDistanciaPx,
            ref string mejorTexto)
        {
            if (candidatos == null)
                return;

            foreach (
                System.Tuple<double, string> candidato
                in candidatos)
            {
                if (candidato == null)
                    continue;

                double distanciaPx =
                    System.Math.Abs(
                        PantallaXAlzado(
                            candidato.Item1) -
                        PantallaXAlzado(
                            xModelo));

                if (distanciaPx <
                    mejorDistanciaPx)
                {
                    mejorDistanciaPx =
                        distanciaPx;

                    mejor =
                        candidato.Item1;

                    mejorTexto =
                        candidato.Item2;
                }
            }
        }

        private System.Collections.Generic.List<
            System.Tuple<double, string>>
            ObtenerCandidatosElementoExtremo(
                AceroMuroElementoExtremoVista extremo)
        {
            System.Collections.Generic.List<
                System.Tuple<double, string>> lista =
                    new System.Collections.Generic.List<
                        System.Tuple<double, string>>();

            if (extremo == null)
                return lista;

            double exterior =
                extremo.EsInicio
                    ? extremo.XInicio
                    : extremo.XFin;

            double interior =
                extremo.EsInicio
                    ? extremo.XFin
                    : extremo.XInicio;

            lista.Add(
                System.Tuple.Create(
                    exterior,
                    extremo.EsInicio
                        ? "BORDE EXT. INICIO"
                        : "BORDE EXT. FIN"));

            lista.Add(
                System.Tuple.Create(
                    interior,
                    extremo.EsInicio
                        ? "BORDE INT. INICIO"
                        : "BORDE INT. FIN"));

            if (extremo.RecubrimientoCm > 0.0)
            {
                double rec =
                    extremo.RecubrimientoCm /
                    30.48;

                double recExterior =
                    extremo.EsInicio
                        ? extremo.XInicio + rec
                        : extremo.XFin - rec;

                double recInterior =
                    extremo.EsInicio
                        ? extremo.XFin - rec
                        : extremo.XInicio + rec;

                lista.Add(
                    System.Tuple.Create(
                        recExterior,
                        extremo.EsInicio
                            ? "REC. EXT. INICIO"
                            : "REC. EXT. FIN"));

                lista.Add(
                    System.Tuple.Create(
                        recInterior,
                        extremo.EsInicio
                            ? "REC. INT. INICIO"
                            : "REC. INT. FIN"));
            }

            return lista;
        }

        private AceroMuroElementoExtremoVista
            ObtenerElementoExtremo(
                int cadena,
                bool esInicio)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.ElementosExtremos == null)
            {
                return null;
            }

            foreach (
                AceroMuroElementoExtremoVista extremo
                in vistaElevacionActual.ElementosExtremos)
            {
                if (extremo != null &&
                    extremo.Cadena == cadena &&
                    extremo.EsInicio == esInicio)
                {
                    return extremo;
                }
            }

            return null;
        }

        private bool TryObtenerXBloqueo(
            AceroMuroElementoExtremoVista extremo,
            AceroMuroTipoBloqueoExtremo tipo,
            out double x,
            out string descripcion)
        {
            x = 0.0;
            descripcion = "";

            if (extremo == null ||
                tipo ==
                AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                return false;
            }

            bool inicio =
                extremo.EsInicio;

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.BordeExteriorElemento)
            {
                x =
                    inicio
                        ? extremo.XInicio
                        : extremo.XFin;

                descripcion =
                    "BORDE EXTERIOR";

                return true;
            }

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.BordeInteriorElemento)
            {
                x =
                    inicio
                        ? extremo.XFin
                        : extremo.XInicio;

                descripcion =
                    "BORDE INTERIOR";

                return true;
            }

            if (extremo.RecubrimientoCm <= 0.0)
                return false;

            double rec =
                extremo.RecubrimientoCm /
                30.48;

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.RecubrimientoExteriorElemento)
            {
                x =
                    inicio
                        ? extremo.XInicio + rec
                        : extremo.XFin - rec;

                descripcion =
                    "RECUBRIMIENTO EXTERIOR";

                return true;
            }

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.RecubrimientoInteriorElemento)
            {
                x =
                    inicio
                        ? extremo.XFin - rec
                        : extremo.XInicio + rec;

                descripcion =
                    "RECUBRIMIENTO INTERIOR";

                return true;
            }

            return false;
        }

        private System.Collections.Generic.List<
            AceroMuroTramoVista>
            ObtenerTramosOrdenadosGlobal()
        {
            System.Collections.Generic.List<
                AceroMuroTramoVista> lista =
                    new System.Collections.Generic.List<
                        AceroMuroTramoVista>();

            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return lista;
            }

            lista.AddRange(
                vistaElevacionActual.Tramos);

            lista.Sort(
                (a, b) =>
                {
                    int c =
                        a.Cadena.CompareTo(
                            b.Cadena);

                    if (c != 0)
                        return c;

                    return a.XInicio.CompareTo(
                        b.XInicio);
                });

            return lista;
        }

        private System.Collections.Generic.List<int>
            ObtenerNumerosCadenas()
        {
            System.Collections.Generic.List<int> numeros =
                new System.Collections.Generic.List<int>();

            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return numeros;
            }

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                if (!numeros.Contains(
                    tramo.Cadena))
                {
                    numeros.Add(
                        tramo.Cadena);
                }
            }

            numeros.Sort();
            return numeros;
        }

        private void AplicarBloqueosATodasCadenas()
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return;
            }

            foreach (
                int cadena
                in ObtenerNumerosCadenas())
            {
                System.Collections.Generic.List<
                    AceroMuroTramoVista> tramos =
                        ObtenerTramosCadenaOrdenados(
                            cadena);

                if (tramos.Count == 0)
                    continue;

                if (bloqueoHorizontalInicio !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
                {
                    AceroMuroElementoExtremoVista extremo =
                        ObtenerElementoExtremo(
                            cadena,
                            true);

                    double xObjetivo;
                    string texto;

                    if (TryObtenerXBloqueo(
                        extremo,
                        bloqueoHorizontalInicio,
                        out xObjetivo,
                        out texto))
                    {
                        AceroMuroTramoVista primero =
                            tramos[0];

                        double recMuro =
                            ObtenerRecubrimientoCmActual() /
                            30.48;

                        double xBase =
                            primero.XInicio +
                            recMuro;

                        ajusteInicioTramoCm[
                            primero.MuroId] =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    xObjetivo -
                                    xBase,
                                    Autodesk.Revit.DB.UnitTypeId.Centimeters);
                    }
                }

                if (bloqueoHorizontalFin !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
                {
                    AceroMuroElementoExtremoVista extremo =
                        ObtenerElementoExtremo(
                            cadena,
                            false);

                    double xObjetivo;
                    string texto;

                    if (TryObtenerXBloqueo(
                        extremo,
                        bloqueoHorizontalFin,
                        out xObjetivo,
                        out texto))
                    {
                        AceroMuroTramoVista ultimo =
                            tramos[
                                tramos.Count - 1];

                        double recMuro =
                            ObtenerRecubrimientoCmActual() /
                            30.48;

                        double xBase =
                            ultimo.XFin -
                            recMuro;

                        ajusteFinTramoCm[
                            ultimo.MuroId] =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    xBase -
                                    xObjetivo,
                                    Autodesk.Revit.DB.UnitTypeId.Centimeters);
                    }
                }
            }

            pnlVistaAlzado.Invalidate();
        }

        private void EstablecerBloqueoExtremo(
            bool esInicio,
            AceroMuroTipoBloqueoExtremo tipo)
        {
            if (tipo !=
                AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                bool referenciaDisponible =
                    false;

                foreach (
                    int cadena
                    in ObtenerNumerosCadenas())
                {
                    AceroMuroElementoExtremoVista extremo =
                        ObtenerElementoExtremo(
                            cadena,
                            esInicio);

                    double x;
                    string texto;

                    if (TryObtenerXBloqueo(
                        extremo,
                        tipo,
                        out x,
                        out texto))
                    {
                        referenciaDisponible =
                            true;

                        break;
                    }
                }

                if (!referenciaDisponible)
                {
                    System.Windows.Forms.MessageBox.Show(
                        this,
                        "No se encontró una referencia válida para este candado.\n\n" +
                        "Seleccione una serie que tenga elemento estructural en el " +
                        (esInicio ? "INICIO" : "FIN") +
                        " y, para un candado de recubrimiento, asegúrese de que ese elemento tenga recubrimiento de armadura asignado.",
                        "MYG",
                        System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Information);

                    return;
                }
            }

            RegistrarDeshacer();

            if (esInicio)
                bloqueoHorizontalInicio = tipo;
            else
                bloqueoHorizontalFin = tipo;

            AplicarBloqueosATodasCadenas();
            ActualizarBotonesBloqueo();

            string lado =
                esInicio
                    ? "INICIO"
                    : "FIN";

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                ActualizarEstado(
                    lado +
                    " horizontal desbloqueado.");
            }
            else
            {
                ActualizarEstado(
                    lado +
                    " horizontal bloqueado a " +
                    ObtenerNombreBloqueo(tipo) +
                    ".");
            }
        }

        private string ObtenerNombreBloqueo(
            AceroMuroTipoBloqueoExtremo tipo)
        {
            if (tipo ==
                AceroMuroTipoBloqueoExtremo.BordeExteriorElemento)
            {
                return "BORDE EXTERIOR";
            }

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.RecubrimientoExteriorElemento)
            {
                return "RECUBRIMIENTO EXTERIOR";
            }

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.BordeInteriorElemento)
            {
                return "BORDE INTERIOR";
            }

            if (tipo ==
                AceroMuroTipoBloqueoExtremo.RecubrimientoInteriorElemento)
            {
                return "RECUBRIMIENTO INTERIOR";
            }

            return "SIN BLOQUEO";
        }

        private void MostrarMenuBloqueoExtremo(
            bool esInicio,
            System.Windows.Forms.Control control)
        {
            if (control == null)
                return;

            System.Windows.Forms.ContextMenuStrip menu =
                new System.Windows.Forms.ContextMenuStrip();

            System.Action<
                string,
                AceroMuroTipoBloqueoExtremo> agregar =
                (texto, tipo) =>
                {
                    System.Windows.Forms.ToolStripMenuItem item =
                        new System.Windows.Forms.ToolStripMenuItem(
                            texto);

                    AceroMuroTipoBloqueoExtremo actual =
                        esInicio
                            ? bloqueoHorizontalInicio
                            : bloqueoHorizontalFin;

                    item.Checked =
                        actual == tipo;

                    item.Click +=
                        (s, e) =>
                            EstablecerBloqueoExtremo(
                                esInicio,
                                tipo);

                    menu.Items.Add(item);
                };

            agregar(
                "Bloquear a RECUBRIMIENTO EXTERIOR",
                AceroMuroTipoBloqueoExtremo.RecubrimientoExteriorElemento);

            agregar(
                "Bloquear a BORDE EXTERIOR",
                AceroMuroTipoBloqueoExtremo.BordeExteriorElemento);

            agregar(
                "Bloquear a RECUBRIMIENTO INTERIOR",
                AceroMuroTipoBloqueoExtremo.RecubrimientoInteriorElemento);

            agregar(
                "Bloquear a BORDE INTERIOR",
                AceroMuroTipoBloqueoExtremo.BordeInteriorElemento);

            menu.Items.Add(
                new System.Windows.Forms.ToolStripSeparator());

            agregar(
                "DESBLOQUEAR",
                AceroMuroTipoBloqueoExtremo.Ninguno);

            menu.Show(
                control,
                new System.Drawing.Point(
                    0,
                    control.Height));
        }

        private void ActualizarBotonesBloqueo()
        {
            // Los controles BLOQ. INICIO / BLOQ. FIN ya no se muestran
            // en la barra. El estado se representa directamente mediante
            // el candado inline de la vista previa.
            if (pnlVistaAlzado != null)
                pnlVistaAlzado.Invalidate();
        }

        private void DibujarCandado(
            System.Drawing.Graphics g,
            float x,
            float y,
            bool cerrado)
        {
            if (g == null)
                return;

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        cerrado
                            ? System.Drawing.Color.FromArgb(
                                20, 92, 160)
                            : System.Drawing.Color.FromArgb(
                                0, 150, 215),
                        1.6F))
            using (
                System.Drawing.Brush brush =
                    new System.Drawing.SolidBrush(
                        cerrado
                            ? System.Drawing.Color.FromArgb(
                                198, 224, 247)
                            : System.Drawing.Color.FromArgb(
                                236, 248, 255)))
            {
                float w = 12F;
                float h = 9F;

                g.FillRectangle(
                    brush,
                    x,
                    y,
                    w,
                    h);

                g.DrawRectangle(
                    pen,
                    x,
                    y,
                    w,
                    h);

                if (cerrado)
                {
                    g.DrawArc(
                        pen,
                        x + 2F,
                        y - 7F,
                        w - 4F,
                        11F,
                        180F,
                        180F);
                }
                else
                {
                    // Candado ABIERTO: el arco queda desplazado hacia la derecha.
                    g.DrawArc(
                        pen,
                        x + 4F,
                        y - 7F,
                        w - 4F,
                        11F,
                        180F,
                        180F);

                    g.DrawLine(
                        pen,
                        x + 4F,
                        y - 2F,
                        x + 4F,
                        y + 1F);
                }

                // pequeño ojo central
                g.DrawEllipse(
                    pen,
                    x + w * 0.5F - 1.2F,
                    y + 3F,
                    2.4F,
                    2.4F);
            }
        }


        private bool TryDetectarReferenciaBloqueableActual(
            AceroMuroTramoVista tramo,
            bool esInicio,
            out AceroMuroTipoBloqueoExtremo tipo,
            out string descripcion)
        {
            tipo =
                AceroMuroTipoBloqueoExtremo.Ninguno;

            descripcion = "";

            if (tramo == null)
                return false;

            AceroMuroElementoExtremoVista extremo =
                ObtenerElementoExtremo(
                    tramo.Cadena,
                    esInicio);

            if (extremo == null)
                return false;

            double xActual =
                esInicio
                    ? ObtenerXInicioEditableTramo(
                        tramo)
                    : ObtenerXFinEditableTramo(
                        tramo);

            AceroMuroTipoBloqueoExtremo[] candidatos =
            {
            AceroMuroTipoBloqueoExtremo.RecubrimientoExteriorElemento,
            AceroMuroTipoBloqueoExtremo.BordeExteriorElemento,
            AceroMuroTipoBloqueoExtremo.RecubrimientoInteriorElemento,
            AceroMuroTipoBloqueoExtremo.BordeInteriorElemento
        };

            double toleranciaPx =
                4.5;

            foreach (
                AceroMuroTipoBloqueoExtremo candidato
                in candidatos)
            {
                double xReferencia;
                string texto;

                if (!TryObtenerXBloqueo(
                    extremo,
                    candidato,
                    out xReferencia,
                    out texto))
                {
                    continue;
                }

                double distanciaPx =
                    System.Math.Abs(
                        PantallaXAlzado(
                            xActual) -
                        PantallaXAlzado(
                            xReferencia));

                if (distanciaPx <=
                    toleranciaPx)
                {
                    tipo =
                        candidato;

                    descripcion =
                        texto;

                    return true;
                }
            }

            return false;
        }

        private System.Drawing.RectangleF
            ObtenerRectCandadoInline(
                float xHandle,
                float yHandle,
                bool esInicio)
        {
            float x =
                esInicio
                    ? xHandle + 14F
                    : xHandle - 28F;

            float y =
                yHandle + 8F;

            return new System.Drawing.RectangleF(
                x,
                y,
                14F,
                16F);
        }

        private bool TryObtenerCandadoInline(
            AceroMuroTramoVista tramo,
            bool esInicio,
            out System.Drawing.RectangleF rect,
            out AceroMuroTipoBloqueoExtremo tipo,
            out bool cerrado,
            out string descripcion)
        {
            rect =
                System.Drawing.RectangleF.Empty;

            tipo =
                AceroMuroTipoBloqueoExtremo.Ninguno;

            cerrado = false;
            descripcion = "";

            if (tramo == null)
                return false;

            AceroMuroTipoBloqueoExtremo bloqueoActual =
                esInicio
                    ? bloqueoHorizontalInicio
                    : bloqueoHorizontalFin;

            if (bloqueoActual !=
                AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                tipo =
                    bloqueoActual;

                descripcion =
                    ObtenerNombreBloqueo(
                        bloqueoActual);

                cerrado = true;
            }
            else
            {
                if (!TryDetectarReferenciaBloqueableActual(
                    tramo,
                    esInicio,
                    out tipo,
                    out descripcion))
                {
                    return false;
                }

                cerrado = false;
            }

            float xHandle =
                PantallaXAlzado(
                    esInicio
                        ? ObtenerXInicioEditableTramo(
                            tramo)
                        : ObtenerXFinEditableTramo(
                            tramo));

            float yHandle =
                ObtenerYHandleHorizontal(
                    tramo);

            rect =
                ObtenerRectCandadoInline(
                    xHandle,
                    yHandle,
                    esInicio);

            return true;
        }

        private bool ProcesarClickCandadoInline(
            System.Drawing.Point punto)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return false;
            }

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                bool mostrarInicio =
                    DebeMostrarHandleHorizontalInicio(
                        tramo);

                bool mostrarFin =
                    DebeMostrarHandleHorizontalFin(
                        tramo);

                if (mostrarInicio)
                {
                    System.Drawing.RectangleF rect;
                    AceroMuroTipoBloqueoExtremo tipo;
                    bool cerrado;
                    string descripcion;

                    if (TryObtenerCandadoInline(
                        tramo,
                        true,
                        out rect,
                        out tipo,
                        out cerrado,
                        out descripcion) &&
                        rect.Contains(
                            punto))
                    {
                        if (cerrado)
                        {
                            EstablecerBloqueoExtremo(
                                true,
                                AceroMuroTipoBloqueoExtremo.Ninguno);
                        }
                        else
                        {
                            EstablecerBloqueoExtremo(
                                true,
                                tipo);
                        }

                        tramoSeleccionadoId =
                            tramo.MuroId;

                        pnlVistaAlzado.Invalidate();

                        return true;
                    }
                }

                if (mostrarFin)
                {
                    System.Drawing.RectangleF rect;
                    AceroMuroTipoBloqueoExtremo tipo;
                    bool cerrado;
                    string descripcion;

                    if (TryObtenerCandadoInline(
                        tramo,
                        false,
                        out rect,
                        out tipo,
                        out cerrado,
                        out descripcion) &&
                        rect.Contains(
                            punto))
                    {
                        if (cerrado)
                        {
                            EstablecerBloqueoExtremo(
                                false,
                                AceroMuroTipoBloqueoExtremo.Ninguno);
                        }
                        else
                        {
                            EstablecerBloqueoExtremo(
                                false,
                                tipo);
                        }

                        tramoSeleccionadoId =
                            tramo.MuroId;

                        pnlVistaAlzado.Invalidate();

                        return true;
                    }
                }
            }

            return false;
        }

        private void GuardarDataDiseno()
        {
            AceroMuroDataGuardada data =
                CapturarDataGuardada();

            System.Windows.Forms.SaveFileDialog dialogo =
                new System.Windows.Forms.SaveFileDialog
                {
                    Title =
                        "Guardar Data - Acero en Muros",
                    Filter =
                        "MYG Acero Muros (*.mygmuros)|*.mygmuros|XML (*.xml)|*.xml",
                    DefaultExt =
                        "mygmuros",
                    AddExtension =
                        true,
                    FileName =
                        "AceroMuros_Data.mygmuros"
                };

            if (!string.IsNullOrWhiteSpace(
                ultimaRutaData))
            {
                try
                {
                    string carpeta =
                        System.IO.Path.GetDirectoryName(
                            ultimaRutaData);

                    if (!string.IsNullOrWhiteSpace(
                        carpeta) &&
                        System.IO.Directory.Exists(
                            carpeta))
                    {
                        dialogo.InitialDirectory =
                            carpeta;
                    }
                }
                catch
                {
                }
            }

            if (dialogo.ShowDialog(this) !=
                System.Windows.Forms.DialogResult.OK)
            {
                return;
            }

            try
            {
                GuardarDataXml(
                    dialogo.FileName,
                    data);

                ultimaRutaData =
                    dialogo.FileName;

                dataCargadaActiva =
                    data;

                ActualizarEstado(
                    "Data guardada. Los candados se conservarán como referencias semánticas.");
            }
            catch (
                System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    "No se pudo guardar la data.\n\n" +
                    ex.Message,
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);
            }
            finally
            {
                dialogo.Dispose();
            }
        }

        private void CargarDataDiseno()
        {
            System.Windows.Forms.OpenFileDialog dialogo =
                new System.Windows.Forms.OpenFileDialog
                {
                    Title =
                        "Cargar Data - Acero en Muros",
                    Filter =
                        "MYG Acero Muros (*.mygmuros)|*.mygmuros|XML (*.xml)|*.xml",
                    Multiselect =
                        false
                };

            if (!string.IsNullOrWhiteSpace(
                ultimaRutaData))
            {
                try
                {
                    string carpeta =
                        System.IO.Path.GetDirectoryName(
                            ultimaRutaData);

                    if (!string.IsNullOrWhiteSpace(
                        carpeta) &&
                        System.IO.Directory.Exists(
                            carpeta))
                    {
                        dialogo.InitialDirectory =
                            carpeta;
                    }
                }
                catch
                {
                }
            }

            if (dialogo.ShowDialog(this) !=
                System.Windows.Forms.DialogResult.OK)
            {
                return;
            }

            try
            {
                AceroMuroDataGuardada data =
                    CargarDataXml(
                        dialogo.FileName);

                if (data == null)
                    return;

                ultimaRutaData =
                    dialogo.FileName;

                dataCargadaActiva =
                    data;

                AplicarDataGuardadaControles(
                    data);

                AplicarDataGuardadaASeleccionActual(
                    data);

                ActualizarEstado(
                    "Data cargada. Si selecciona otra serie, los extremos bloqueados buscarán el recubrimiento/borde de sus nuevos elementos extremos.");
            }
            catch (
                System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    "No se pudo cargar la data.\n\n" +
                    ex.Message,
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);
            }
            finally
            {
                dialogo.Dispose();
            }
        }

        private AceroMuroDataGuardada
            CapturarDataGuardada()
        {
            // Asegurar que GUARDAR DATA capture la longitud visible actual
            // de ambos extremos antes de serializar.
            CapturarDesarrollosHorizontalesActuales();

            AceroMuroDataGuardada data =
                new AceroMuroDataGuardada
                {
                    TipoVertical =
                        cmbTipoVertical != null
                            ? cmbTipoVertical.Text.Trim()
                            : "",
                    TipoHorizontal =
                        cmbTipoHorizontal != null
                            ? cmbTipoHorizontal.Text.Trim()
                            : "",
                    Recubrimiento =
                        cmbRecubrimiento != null
                            ? cmbRecubrimiento.Text.Trim()
                            : "",
                    EspVertical =
                        txtEspVertical != null
                            ? txtEspVertical.Text.Trim()
                            : "",
                    EspHorizontal =
                        txtEspHorizontal != null
                            ? txtEspHorizontal.Text.Trim()
                            : "",
                    Caras =
                        cmbCaras != null
                            ? cmbCaras.Text.Trim()
                            : "",
                    CrearVertical =
                        chkVerticales != null &&
                        chkVerticales.Checked,
                    CrearHorizontal =
                        chkHorizontales != null &&
                        chkHorizontales.Checked,
                    Continuos =
                        chkContinuos != null &&
                        chkContinuos.Checked,
                    ConsiderarEmpalme =
                        chkConsiderarEmpalme != null &&
                        chkConsiderarEmpalme.Checked,
                    LongitudComercial =
                        txtLongitudComercial != null
                            ? txtLongitudComercial.Text.Trim()
                            : "",

                    CrearRefuerzoHuecos =
                        chkRefuerzoHuecos != null &&
                        chkRefuerzoHuecos.Checked,

                    TipoRefuerzoHuecos =
                        cmbRefuerzoHuecosDiametro != null
                            ? cmbRefuerzoHuecosDiametro.Text.Trim()
                            : "",

                    LongitudRefuerzoHuecos =
                        txtLongitudRefuerzoHuecos != null
                            ? txtLongitudRefuerzoHuecos.Text.Trim()
                            : "0.65",

                    VerElementosSinTapar =
                        chkVerSinTapar != null &&
                        chkVerSinTapar.Checked,

                    DesarrolloHorizontalInicioDefinido =
                        desarrolloHorizontalInicioRecordadoDefinido,

                    DesarrolloHorizontalFinDefinido =
                        desarrolloHorizontalFinRecordadoDefinido,

                    DesarrolloHorizontalInicioM =
                        desarrolloHorizontalInicioRecordadoM,

                    DesarrolloHorizontalFinM =
                        desarrolloHorizontalFinRecordadoM,

                    AjusteCaraACm =
                        ajusteSeccionIzquierdaCm,
                    AjusteCaraBCm =
                        ajusteSeccionDerechaCm,
                    AjusteInferiorCm =
                        ajusteSeccionInferiorCm,
                    AjusteSuperiorCm =
                        ajusteSeccionSuperiorCm,
                    GanchoInferior =
                        anguloGanchoInferior,
                    GanchoSuperior =
                        anguloGanchoSuperior,
                    GanchoInferiorManual =
                        chkLongGanchoInfManual != null &&
                        chkLongGanchoInfManual.Checked,
                    GanchoSuperiorManual =
                        chkLongGanchoSupManual != null &&
                        chkLongGanchoSupManual.Checked,
                    LongitudGanchoInferior =
                        txtLongGanchoInf != null
                            ? txtLongGanchoInf.Text.Trim()
                            : "",
                    LongitudGanchoSuperior =
                        txtLongGanchoSup != null
                            ? txtLongGanchoSup.Text.Trim()
                            : "",
                    BloqueoInicio =
                        bloqueoHorizontalInicio,
                    BloqueoFin =
                        bloqueoHorizontalFin
                };

            System.Collections.Generic.List<
                AceroMuroTramoVista> ordenados =
                    ObtenerTramosOrdenadosGlobal();

            AsegurarEmpalmesPorDiametroDisponibles();

            foreach (
                AceroMuroEmpalmeDiametroData item
                in empalmesPorDiametro)
            {
                if (item != null)
                    data.EmpalmesPorDiametro.Add(
                        item.Copiar());
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo != null)
                    data.GruposHorizontales2Puntos.Add(
                        grupo.Copiar());
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo != null)
                    data.GruposVerticales2Puntos.Add(
                        grupo.Copiar());
            }

            for (int i = 0;
                 i < ordenados.Count;
                 i++)
            {
                AceroMuroTramoVista tramo =
                    ordenados[i];

                data.Ajustes.Add(
                    new AceroMuroAjusteData
                    {
                        Indice = i,
                        InicioCm =
                            ObtenerAjusteInicioTramoCm(
                                tramo.MuroId),
                        FinCm =
                            ObtenerAjusteFinTramoCm(
                                tramo.MuroId)
                    });
            }

            return data;
        }

        private void AplicarDataGuardadaControles(
            AceroMuroDataGuardada data)
        {
            if (data == null)
                return;

            if (cmbTipoVertical != null)
                cmbTipoVertical.Text =
                    data.TipoVertical ?? "";

            if (cmbTipoHorizontal != null)
                cmbTipoHorizontal.Text =
                    data.TipoHorizontal ?? "";

            if (cmbRecubrimiento != null)
                cmbRecubrimiento.Text =
                    data.Recubrimiento ?? "";

            if (txtEspVertical != null)
                txtEspVertical.Text =
                    data.EspVertical ?? "";

            if (txtEspHorizontal != null)
                txtEspHorizontal.Text =
                    data.EspHorizontal ?? "";

            if (cmbCaras != null)
                cmbCaras.Text =
                    NormalizarTextoMalla(
                        data.Caras ?? "");

            if (chkVerticales != null)
                chkVerticales.Checked =
                    data.CrearVertical;

            if (chkHorizontales != null)
                chkHorizontales.Checked =
                    data.CrearHorizontal;

            if (chkContinuos != null)
                chkContinuos.Checked =
                    data.Continuos;

            if (chkConsiderarEmpalme != null)
                chkConsiderarEmpalme.Checked =
                    data.ConsiderarEmpalme;

            if (txtLongitudComercial != null)
            {
                txtLongitudComercial.Text =
                    data.LongitudComercial ?? "9.0";

                txtLongitudComercial.Enabled =
                    data.ConsiderarEmpalme &&
                    chkHorizontales != null &&
                    chkHorizontales.Checked;
            }

            if (data.EmpalmesPorDiametro != null &&
                data.EmpalmesPorDiametro.Count > 0)
            {
                empalmesPorDiametro.Clear();

                foreach (
                    AceroMuroEmpalmeDiametroData item
                    in data.EmpalmesPorDiametro)
                {
                    if (item != null &&
                        item.DiametroMm > 0.0 &&
                        item.LongitudEmpalmeCm > 0.0)
                    {
                        empalmesPorDiametro.Add(
                            item.Copiar());
                    }
                }
            }

            AsegurarEmpalmesPorDiametroDisponibles();

            if (btnConfigurarEmpalmes != null)
            {
                btnConfigurarEmpalmes.Visible =
                    data.ConsiderarEmpalme &&
                    chkHorizontales != null &&
                    chkHorizontales.Checked;

                btnConfigurarEmpalmes.Enabled =
                    btnConfigurarEmpalmes.Visible;
            }

            if (chkRefuerzoHuecos != null)
                chkRefuerzoHuecos.Checked =
                    data.CrearRefuerzoHuecos;

            if (cmbRefuerzoHuecosDiametro != null)
            {
                if (!SeleccionarTipoPorNombre(
                        cmbRefuerzoHuecosDiametro,
                        data.TipoRefuerzoHuecos ?? "") &&
                    !string.IsNullOrWhiteSpace(
                        data.TipoRefuerzoHuecos))
                {
                    cmbRefuerzoHuecosDiametro.Text =
                        data.TipoRefuerzoHuecos;
                }
            }

            if (txtLongitudRefuerzoHuecos != null)
                txtLongitudRefuerzoHuecos.Text =
                    string.IsNullOrWhiteSpace(
                        data.LongitudRefuerzoHuecos)
                        ? "0.65"
                        : data.LongitudRefuerzoHuecos;

            bool mostrarRefuerzoHuecos =
                data.CrearRefuerzoHuecos;

            if (lblRefuerzoHuecosDiametro != null)
                lblRefuerzoHuecosDiametro.Visible =
                    mostrarRefuerzoHuecos;

            if (cmbRefuerzoHuecosDiametro != null)
            {
                cmbRefuerzoHuecosDiametro.Visible =
                    mostrarRefuerzoHuecos;

                cmbRefuerzoHuecosDiametro.Enabled =
                    mostrarRefuerzoHuecos;
            }

            if (lblRefuerzoHuecosLongitud != null)
                lblRefuerzoHuecosLongitud.Visible =
                    mostrarRefuerzoHuecos;

            if (txtLongitudRefuerzoHuecos != null)
            {
                txtLongitudRefuerzoHuecos.Visible =
                    mostrarRefuerzoHuecos;

                txtLongitudRefuerzoHuecos.Enabled =
                    mostrarRefuerzoHuecos;
            }

            if (lblRefuerzoHuecosUnidad != null)
                lblRefuerzoHuecosUnidad.Visible =
                    mostrarRefuerzoHuecos;

            if (chkVerSinTapar != null)
                chkVerSinTapar.Checked =
                    data.VerElementosSinTapar;

            desarrolloHorizontalInicioRecordadoDefinido =
                data.DesarrolloHorizontalInicioDefinido;

            desarrolloHorizontalFinRecordadoDefinido =
                data.DesarrolloHorizontalFinDefinido;

            desarrolloHorizontalInicioRecordadoM =
                System.Math.Max(
                    0.0,
                    data.DesarrolloHorizontalInicioM);

            desarrolloHorizontalFinRecordadoM =
                System.Math.Max(
                    0.0,
                    data.DesarrolloHorizontalFinM);

            ajusteSeccionIzquierdaCm =
                data.AjusteCaraACm;

            ajusteSeccionDerechaCm =
                data.AjusteCaraBCm;

            ajusteSeccionInferiorCm =
                data.AjusteInferiorCm;

            ajusteSeccionSuperiorCm =
                data.AjusteSuperiorCm;

            anguloGanchoInferior =
                data.GanchoInferior;

            anguloGanchoSuperior =
                data.GanchoSuperior;

            if (chkLongGanchoInfManual != null)
                chkLongGanchoInfManual.Checked =
                    data.GanchoInferiorManual;

            if (chkLongGanchoSupManual != null)
                chkLongGanchoSupManual.Checked =
                    data.GanchoSuperiorManual;

            if (txtLongGanchoInf != null)
                txtLongGanchoInf.Text =
                    data.LongitudGanchoInferior ?? "";

            if (txtLongGanchoSup != null)
                txtLongGanchoSup.Text =
                    data.LongitudGanchoSuperior ?? "";

            ActualizarControlesLongitudGanchoManual(
                false);

            bloqueoHorizontalInicio =
                data.BloqueoInicio;

            bloqueoHorizontalFin =
                data.BloqueoFin;

            gruposHorizontales2Puntos.Clear();

            if (data.GruposHorizontales2Puntos != null)
            {
                foreach (
                    AceroMuroGrupoHorizontal2Puntos grupo
                    in data.GruposHorizontales2Puntos)
                {
                    if (grupo != null)
                        gruposHorizontales2Puntos.Add(
                            grupo.Copiar());
                }
            }

            gruposVerticales2Puntos.Clear();

            if (data.GruposVerticales2Puntos != null)
            {
                foreach (
                    AceroMuroGrupoVertical2Puntos grupo
                    in data.GruposVerticales2Puntos)
                {
                    if (grupo != null)
                        gruposVerticales2Puntos.Add(
                            grupo.Copiar());
                }
            }

            gruposHorizontales2PSeleccionados.Clear();
            gruposVerticales2PSeleccionados.Clear();
            grupoHorizontal2PSeleccionadoId = "";
            grupoVertical2PSeleccionadoId = "";
            ActualizarPanelGrupoSeleccionado();
            verticalesSeccionSeleccionados = false;
            creandoHorizontalDosPuntos = false;
            horizontal2PEsperandoSegundoClic = false;
            creandoVerticalDosPuntos = false;
            vertical2PEsperandoSegundoClic = false;

            ActualizarGruposVinculadosAGuiasSeccion();
            ActualizarGruposVerticalesVinculadosAGuias();

            GuardarValoresRecordados();
            ActualizarBotonesBloqueo();
        }

        private void AplicarDataGuardadaASeleccionActual(
            AceroMuroDataGuardada data)
        {
            if (data == null ||
                vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return;
            }

            ajusteInicioTramoCm.Clear();
            ajusteFinTramoCm.Clear();

            System.Collections.Generic.List<
                AceroMuroTramoVista> ordenados =
                    ObtenerTramosOrdenadosGlobal();

            if (data.Ajustes != null)
            {
                foreach (
                    AceroMuroAjusteData ajuste
                    in data.Ajustes)
                {
                    if (ajuste == null ||
                        ajuste.Indice < 0 ||
                        ajuste.Indice >=
                            ordenados.Count)
                    {
                        continue;
                    }

                    AceroMuroTramoVista tramo =
                        ordenados[
                            ajuste.Indice];

                    ajusteInicioTramoCm[
                        tramo.MuroId] =
                        ajuste.InicioCm;

                    ajusteFinTramoCm[
                        tramo.MuroId] =
                        ajuste.FinCm;
                }
            }

            bloqueoHorizontalInicio =
                data.BloqueoInicio;

            bloqueoHorizontalFin =
                data.BloqueoFin;

            // LOS CANDADOS TIENEN PRIORIDAD sobre los retiros numéricos.
            // Se recalculan usando los elementos extremos de la NUEVA serie.
            AplicarBloqueosATodasCadenas();

            // V8.71:
            // los desarrollos H guardados son PORTABLES entre selecciones.
            // Si no hay candado, se aplican al nuevo primer/último muro.
            AplicarDesarrollosHorizontalesRecordadosASeleccion();

            ActualizarBotonesBloqueo();

            pnlVistaAlzado.Invalidate();
            pnlVistaSeccion.Invalidate();
        }

        private void GuardarDataXml(
            string ruta,
            AceroMuroDataGuardada data)
        {
            System.Xml.XmlDocument doc =
                new System.Xml.XmlDocument();

            System.Xml.XmlElement raiz =
                doc.CreateElement(
                    "MYG_AceroMuros");

            raiz.SetAttribute(
                "Version",
                "8.78");

            doc.AppendChild(
                raiz);

            System.Xml.XmlElement cfg =
                doc.CreateElement(
                    "Configuracion");

            raiz.AppendChild(cfg);

            SetAtributoXml(
                cfg,
                "TipoVertical",
                data.TipoVertical);

            SetAtributoXml(
                cfg,
                "TipoHorizontal",
                data.TipoHorizontal);

            SetAtributoXml(
                cfg,
                "Recubrimiento",
                data.Recubrimiento);

            SetAtributoXml(
                cfg,
                "EspVertical",
                data.EspVertical);

            SetAtributoXml(
                cfg,
                "EspHorizontal",
                data.EspHorizontal);

            SetAtributoXml(
                cfg,
                "Caras",
                data.Caras);

            SetAtributoXml(
                cfg,
                "CrearVertical",
                data.CrearVertical.ToString());

            SetAtributoXml(
                cfg,
                "CrearHorizontal",
                data.CrearHorizontal.ToString());

            SetAtributoXml(
                cfg,
                "Continuos",
                data.Continuos.ToString());

            SetAtributoXml(
                cfg,
                "ConsiderarEmpalme",
                data.ConsiderarEmpalme.ToString());

            SetAtributoXml(
                cfg,
                "LongitudComercial",
                data.LongitudComercial ?? "");

            SetAtributoXml(
                cfg,
                "CrearRefuerzoHuecos",
                data.CrearRefuerzoHuecos.ToString());

            SetAtributoXml(
                cfg,
                "TipoRefuerzoHuecos",
                data.TipoRefuerzoHuecos ?? "");

            SetAtributoXml(
                cfg,
                "LongitudRefuerzoHuecos",
                data.LongitudRefuerzoHuecos ?? "0.65");

            SetAtributoXml(
                cfg,
                "VerElementosSinTapar",
                data.VerElementosSinTapar.ToString());

            SetAtributoXml(
                cfg,
                "DesarrolloHInicioDefinido",
                data.DesarrolloHorizontalInicioDefinido.ToString());

            SetAtributoXml(
                cfg,
                "DesarrolloHFinDefinido",
                data.DesarrolloHorizontalFinDefinido.ToString());

            SetAtributoXml(
                cfg,
                "DesarrolloHInicioM",
                ATextoInvariant(
                    data.DesarrolloHorizontalInicioM));

            SetAtributoXml(
                cfg,
                "DesarrolloHFinM",
                ATextoInvariant(
                    data.DesarrolloHorizontalFinM));

            System.Xml.XmlElement empalmes =
                doc.CreateElement(
                    "EmpalmesPorDiametro");

            raiz.AppendChild(
                empalmes);

            if (data.EmpalmesPorDiametro != null)
            {
                foreach (
                    AceroMuroEmpalmeDiametroData item
                    in data.EmpalmesPorDiametro)
                {
                    if (item == null ||
                        item.DiametroMm <= 0.0 ||
                        item.LongitudEmpalmeCm <= 0.0)
                    {
                        continue;
                    }

                    System.Xml.XmlElement nodo =
                        doc.CreateElement(
                            "Empalme");

                    SetAtributoXml(
                        nodo,
                        "DiametroMm",
                        ATextoInvariant(
                            item.DiametroMm));

                    SetAtributoXml(
                        nodo,
                        "Etiqueta",
                        item.Etiqueta ?? "");

                    SetAtributoXml(
                        nodo,
                        "LongitudCm",
                        ATextoInvariant(
                            item.LongitudEmpalmeCm));

                    empalmes.AppendChild(
                        nodo);
                }
            }

            System.Xml.XmlElement seccion =
                doc.CreateElement(
                    "Seccion");

            raiz.AppendChild(
                seccion);

            SetAtributoXml(
                seccion,
                "CaraA",
                ATextoInvariant(
                    data.AjusteCaraACm));

            SetAtributoXml(
                seccion,
                "CaraB",
                ATextoInvariant(
                    data.AjusteCaraBCm));

            SetAtributoXml(
                seccion,
                "Inferior",
                ATextoInvariant(
                    data.AjusteInferiorCm));

            SetAtributoXml(
                seccion,
                "Superior",
                ATextoInvariant(
                    data.AjusteSuperiorCm));

            SetAtributoXml(
                seccion,
                "GanchoInferior",
                data.GanchoInferior.ToString());

            SetAtributoXml(
                seccion,
                "GanchoSuperior",
                data.GanchoSuperior.ToString());

            SetAtributoXml(
                seccion,
                "GanchoInferiorManual",
                data.GanchoInferiorManual.ToString());

            SetAtributoXml(
                seccion,
                "GanchoSuperiorManual",
                data.GanchoSuperiorManual.ToString());

            SetAtributoXml(
                seccion,
                "LongitudGanchoInferior",
                data.LongitudGanchoInferior ?? "");

            SetAtributoXml(
                seccion,
                "LongitudGanchoSuperior",
                data.LongitudGanchoSuperior ?? "");

            System.Xml.XmlElement locks =
                doc.CreateElement(
                    "Bloqueos");

            raiz.AppendChild(
                locks);

            SetAtributoXml(
                locks,
                "Inicio",
                ((int)data.BloqueoInicio)
                    .ToString());

            SetAtributoXml(
                locks,
                "Fin",
                ((int)data.BloqueoFin)
                    .ToString());

            System.Xml.XmlElement ajustes =
                doc.CreateElement(
                    "AjustesTramos");

            raiz.AppendChild(
                ajustes);

            if (data.Ajustes != null)
            {
                foreach (
                    AceroMuroAjusteData ajuste
                    in data.Ajustes)
                {
                    if (ajuste == null)
                        continue;

                    System.Xml.XmlElement nodo =
                        doc.CreateElement(
                            "Tramo");

                    SetAtributoXml(
                        nodo,
                        "Indice",
                        ajuste.Indice.ToString());

                    SetAtributoXml(
                        nodo,
                        "InicioCm",
                        ATextoInvariant(
                            ajuste.InicioCm));

                    SetAtributoXml(
                        nodo,
                        "FinCm",
                        ATextoInvariant(
                            ajuste.FinCm));

                    ajustes.AppendChild(
                        nodo);
                }
            }

            System.Xml.XmlElement grupos2P =
                doc.CreateElement(
                    "GruposHorizontales2Puntos");

            raiz.AppendChild(
                grupos2P);

            if (data.GruposHorizontales2Puntos != null)
            {
                foreach (
                    AceroMuroGrupoHorizontal2Puntos grupo
                    in data.GruposHorizontales2Puntos)
                {
                    if (grupo == null)
                        continue;

                    System.Xml.XmlElement nodo =
                        doc.CreateElement(
                            "Grupo");

                    SetAtributoXml(
                        nodo,
                        "Id",
                        grupo.Id ?? "");

                    SetAtributoXml(
                        nodo,
                        "InicioU",
                        ATextoInvariant(
                            grupo.InicioU));

                    SetAtributoXml(
                        nodo,
                        "InicioV",
                        ATextoInvariant(
                            grupo.InicioV));

                    SetAtributoXml(
                        nodo,
                        "FinU",
                        ATextoInvariant(
                            grupo.FinU));

                    SetAtributoXml(
                        nodo,
                        "FinV",
                        ATextoInvariant(
                            grupo.FinV));

                    SetAtributoXml(
                        nodo,
                        "InicioVinculoGuia",
                        ((int)grupo.InicioVinculoGuia)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "InicioVinculoVertical",
                        ((int)grupo.InicioVinculoVertical)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "FinVinculoGuia",
                        ((int)grupo.FinVinculoGuia)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "FinVinculoVertical",
                        ((int)grupo.FinVinculoVertical)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "Regla",
                        ((int)grupo.ReglaDistribucion)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "EspaciadoMaximoCm",
                        ATextoInvariant(
                            grupo.EspaciamientoMaximoCm));

                    SetAtributoXml(
                        nodo,
                        "Cantidad",
                        System.Math.Max(
                            2,
                            grupo.Cantidad)
                        .ToString());

                    SetAtributoXml(
                        nodo,
                        "TipoBarraId",
                        grupo.TipoBarraId.ToString());

                    SetAtributoXml(
                        nodo,
                        "TipoBarraNombre",
                        grupo.TipoBarraNombre ?? "");

                    grupos2P.AppendChild(
                        nodo);
                }
            }

            System.Xml.XmlElement gruposV2P =
                doc.CreateElement(
                    "GruposVerticales2Puntos");

            raiz.AppendChild(
                gruposV2P);

            if (data.GruposVerticales2Puntos != null)
            {
                foreach (
                    AceroMuroGrupoVertical2Puntos grupo
                    in data.GruposVerticales2Puntos)
                {
                    if (grupo == null)
                        continue;

                    System.Xml.XmlElement nodo =
                        doc.CreateElement(
                            "Grupo");

                    SetAtributoXml(
                        nodo,
                        "Id",
                        grupo.Id ?? "");

                    SetAtributoXml(
                        nodo,
                        "InicioU",
                        ATextoInvariant(
                            grupo.InicioU));

                    SetAtributoXml(
                        nodo,
                        "InicioV",
                        ATextoInvariant(
                            grupo.InicioV));

                    SetAtributoXml(
                        nodo,
                        "FinU",
                        ATextoInvariant(
                            grupo.FinU));

                    SetAtributoXml(
                        nodo,
                        "FinV",
                        ATextoInvariant(
                            grupo.FinV));

                    SetAtributoXml(
                        nodo,
                        "InicioVinculoGuia",
                        ((int)grupo.InicioVinculoGuia)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "InicioVinculoVertical",
                        ((int)grupo.InicioVinculoVertical)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "FinVinculoGuia",
                        ((int)grupo.FinVinculoGuia)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "FinVinculoVertical",
                        ((int)grupo.FinVinculoVertical)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "Regla",
                        ((int)grupo.ReglaDistribucion)
                            .ToString());

                    SetAtributoXml(
                        nodo,
                        "EspaciadoMaximoCm",
                        ATextoInvariant(
                            grupo.EspaciamientoMaximoCm));

                    SetAtributoXml(
                        nodo,
                        "Cantidad",
                        System.Math.Max(
                            2,
                            grupo.Cantidad)
                        .ToString());

                    SetAtributoXml(
                        nodo,
                        "TipoBarraId",
                        grupo.TipoBarraId.ToString());

                    SetAtributoXml(
                        nodo,
                        "TipoBarraNombre",
                        grupo.TipoBarraNombre ?? "");

                    gruposV2P.AppendChild(
                        nodo);
                }
            }

            System.Xml.XmlWriterSettings settings =
                new System.Xml.XmlWriterSettings
                {
                    Indent = true,
                    Encoding =
                        new System.Text.UTF8Encoding(
                            false)
                };

            using (
                System.Xml.XmlWriter writer =
                    System.Xml.XmlWriter.Create(
                        ruta,
                        settings))
            {
                doc.Save(
                    writer);
            }
        }

        private AceroMuroDataGuardada
            CargarDataXml(
                string ruta)
        {
            System.Xml.XmlDocument doc =
                new System.Xml.XmlDocument();

            doc.Load(
                ruta);

            System.Xml.XmlElement raiz =
                doc.DocumentElement;

            if (raiz == null ||
                !string.Equals(
                    raiz.Name,
                    "MYG_AceroMuros",
                    System.StringComparison.OrdinalIgnoreCase))
            {
                throw new System.Exception(
                    "El archivo no corresponde a Data de Acero en Muros.");
            }

            AceroMuroDataGuardada data =
                new AceroMuroDataGuardada();

            System.Xml.XmlElement cfg =
                raiz.SelectSingleNode(
                    "Configuracion")
                as System.Xml.XmlElement;

            if (cfg != null)
            {
                data.TipoVertical =
                    cfg.GetAttribute(
                        "TipoVertical");

                data.TipoHorizontal =
                    cfg.GetAttribute(
                        "TipoHorizontal");

                data.Recubrimiento =
                    cfg.GetAttribute(
                        "Recubrimiento");

                data.EspVertical =
                    cfg.GetAttribute(
                        "EspVertical");

                data.EspHorizontal =
                    cfg.GetAttribute(
                        "EspHorizontal");

                data.Caras =
                    cfg.GetAttribute(
                        "Caras");

                data.CrearVertical =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "CrearVertical"),
                        true);

                data.CrearHorizontal =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "CrearHorizontal"),
                        true);

                data.Continuos =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "Continuos"),
                        true);

                data.ConsiderarEmpalme =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "ConsiderarEmpalme"),
                        false);

                data.LongitudComercial =
                    cfg.GetAttribute(
                        "LongitudComercial");

                if (string.IsNullOrWhiteSpace(
                    data.LongitudComercial))
                {
                    data.LongitudComercial =
                        "9.0";
                }

                string atributoCrearRefuerzoHuecos =
                    cfg.GetAttribute(
                        "CrearRefuerzoHuecos");

                data.CrearRefuerzoHuecos =
                    string.IsNullOrWhiteSpace(
                        atributoCrearRefuerzoHuecos)
                        ? true
                        : LeerBoolXml(
                            atributoCrearRefuerzoHuecos,
                            true);

                data.TipoRefuerzoHuecos =
                    cfg.GetAttribute(
                        "TipoRefuerzoHuecos");

                data.LongitudRefuerzoHuecos =
                    cfg.GetAttribute(
                        "LongitudRefuerzoHuecos");

                if (string.IsNullOrWhiteSpace(
                    data.LongitudRefuerzoHuecos))
                {
                    data.LongitudRefuerzoHuecos =
                        "0.65";
                }

                data.VerElementosSinTapar =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "VerElementosSinTapar"),
                        true);

                data.DesarrolloHorizontalInicioDefinido =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "DesarrolloHInicioDefinido"),
                        false);

                data.DesarrolloHorizontalFinDefinido =
                    LeerBoolXml(
                        cfg.GetAttribute(
                            "DesarrolloHFinDefinido"),
                        false);

                data.DesarrolloHorizontalInicioM =
                    LeerDoubleXml(
                        cfg.GetAttribute(
                            "DesarrolloHInicioM"));

                data.DesarrolloHorizontalFinM =
                    LeerDoubleXml(
                        cfg.GetAttribute(
                            "DesarrolloHFinM"));
            }

            System.Xml.XmlNodeList nodosEmpalmes =
                raiz.SelectNodes(
                    "EmpalmesPorDiametro/Empalme");

            if (nodosEmpalmes != null)
            {
                foreach (
                    System.Xml.XmlNode n
                    in nodosEmpalmes)
                {
                    System.Xml.XmlElement nodo =
                        n as System.Xml.XmlElement;

                    if (nodo == null)
                        continue;

                    double diametroMm =
                        LeerDoubleXml(
                            nodo.GetAttribute(
                                "DiametroMm"));

                    double longitudCm =
                        LeerDoubleXml(
                            nodo.GetAttribute(
                                "LongitudCm"));

                    if (diametroMm <= 0.0 ||
                        longitudCm <= 0.0)
                    {
                        continue;
                    }

                    data.EmpalmesPorDiametro.Add(
                        new AceroMuroEmpalmeDiametroData
                        {
                            DiametroMm =
                                diametroMm,
                            Etiqueta =
                                nodo.GetAttribute(
                                    "Etiqueta"),
                            LongitudEmpalmeCm =
                                longitudCm
                        });
                }
            }

            System.Xml.XmlElement seccion =
                raiz.SelectSingleNode(
                    "Seccion")
                as System.Xml.XmlElement;

            if (seccion != null)
            {
                data.AjusteCaraACm =
                    LeerDoubleXml(
                        seccion.GetAttribute(
                            "CaraA"));

                data.AjusteCaraBCm =
                    LeerDoubleXml(
                        seccion.GetAttribute(
                            "CaraB"));

                data.AjusteInferiorCm =
                    LeerDoubleXml(
                        seccion.GetAttribute(
                            "Inferior"));

                data.AjusteSuperiorCm =
                    LeerDoubleXml(
                        seccion.GetAttribute(
                            "Superior"));

                data.GanchoInferior =
                    LeerIntXml(
                        seccion.GetAttribute(
                            "GanchoInferior"));

                data.GanchoSuperior =
                    LeerIntXml(
                        seccion.GetAttribute(
                            "GanchoSuperior"));

                data.GanchoInferiorManual =
                    LeerBoolXml(
                        seccion.GetAttribute(
                            "GanchoInferiorManual"),
                        false);

                data.GanchoSuperiorManual =
                    LeerBoolXml(
                        seccion.GetAttribute(
                            "GanchoSuperiorManual"),
                        false);

                data.LongitudGanchoInferior =
                    seccion.GetAttribute(
                        "LongitudGanchoInferior");

                data.LongitudGanchoSuperior =
                    seccion.GetAttribute(
                        "LongitudGanchoSuperior");
            }

            System.Xml.XmlElement locks =
                raiz.SelectSingleNode(
                    "Bloqueos")
                as System.Xml.XmlElement;

            if (locks != null)
            {
                int valorInicio =
                    LeerIntXml(
                        locks.GetAttribute(
                            "Inicio"));

                int valorFin =
                    LeerIntXml(
                        locks.GetAttribute(
                            "Fin"));

                if (System.Enum.IsDefined(
                    typeof(
                        AceroMuroTipoBloqueoExtremo),
                    valorInicio))
                {
                    data.BloqueoInicio =
                        (AceroMuroTipoBloqueoExtremo)
                        valorInicio;
                }

                if (System.Enum.IsDefined(
                    typeof(
                        AceroMuroTipoBloqueoExtremo),
                    valorFin))
                {
                    data.BloqueoFin =
                        (AceroMuroTipoBloqueoExtremo)
                        valorFin;
                }
            }

            System.Xml.XmlNodeList nodos =
                raiz.SelectNodes(
                    "AjustesTramos/Tramo");

            if (nodos != null)
            {
                foreach (
                    System.Xml.XmlNode n
                    in nodos)
                {
                    System.Xml.XmlElement nodo =
                        n as
                        System.Xml.XmlElement;

                    if (nodo == null)
                        continue;

                    data.Ajustes.Add(
                        new AceroMuroAjusteData
                        {
                            Indice =
                                LeerIntXml(
                                    nodo.GetAttribute(
                                        "Indice")),
                            InicioCm =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "InicioCm")),
                            FinCm =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "FinCm"))
                        });
                }
            }

            System.Xml.XmlNodeList nodos2P =
                raiz.SelectNodes(
                    "GruposHorizontales2Puntos/Grupo");

            if (nodos2P != null)
            {
                foreach (
                    System.Xml.XmlNode n
                    in nodos2P)
                {
                    System.Xml.XmlElement nodo =
                        n as
                        System.Xml.XmlElement;

                    if (nodo == null)
                        continue;

                    data.GruposHorizontales2Puntos.Add(
                        new AceroMuroGrupoHorizontal2Puntos
                        {
                            Id =
                                string.IsNullOrWhiteSpace(
                                    nodo.GetAttribute("Id"))
                                    ? System.Guid.NewGuid().ToString("N")
                                    : nodo.GetAttribute("Id"),
                            InicioU =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "InicioU")),
                            InicioV =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "InicioV")),
                            FinU =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "FinU")),
                            FinV =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "FinV")),
                            InicioVinculoGuia =
                                (AceroMuroVinculoGuiaHorizontal2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "InicioVinculoGuia")),
                            InicioVinculoVertical =
                                (AceroMuroVinculoVertical2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "InicioVinculoVertical")),
                            FinVinculoGuia =
                                (AceroMuroVinculoGuiaHorizontal2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "FinVinculoGuia")),
                            FinVinculoVertical =
                                (AceroMuroVinculoVertical2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "FinVinculoVertical")),
                            ReglaDistribucion =
                                LeerIntXml(
                                    nodo.GetAttribute(
                                        "Regla")) == 1
                                    ? AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                                    : AceroMuroReglaDistribucionGrupo.NumeroFijo,
                            EspaciamientoMaximoCm =
                                System.Math.Max(
                                    0.5,
                                    LeerDoubleXml(
                                        nodo.GetAttribute(
                                            "EspaciadoMaximoCm")) > 0.0
                                        ? LeerDoubleXml(
                                            nodo.GetAttribute(
                                                "EspaciadoMaximoCm"))
                                        : 20.0),
                            Cantidad =
                                System.Math.Max(
                                    2,
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "Cantidad"))),
                            TipoBarraId =
                                LeerLongXml(
                                    nodo.GetAttribute(
                                        "TipoBarraId")),
                            TipoBarraNombre =
                                nodo.GetAttribute(
                                    "TipoBarraNombre")
                        });
                }
            }

            System.Xml.XmlNodeList nodosV2P =
                raiz.SelectNodes(
                    "GruposVerticales2Puntos/Grupo");

            if (nodosV2P != null)
            {
                foreach (
                    System.Xml.XmlNode n
                    in nodosV2P)
                {
                    System.Xml.XmlElement nodo =
                        n as System.Xml.XmlElement;

                    if (nodo == null)
                        continue;

                    data.GruposVerticales2Puntos.Add(
                        new AceroMuroGrupoVertical2Puntos
                        {
                            Id =
                                string.IsNullOrWhiteSpace(
                                    nodo.GetAttribute("Id"))
                                    ? System.Guid.NewGuid().ToString("N")
                                    : nodo.GetAttribute("Id"),
                            InicioU =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "InicioU")),
                            InicioV =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "InicioV")),
                            FinU =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "FinU")),
                            FinV =
                                LeerDoubleXml(
                                    nodo.GetAttribute(
                                        "FinV")),
                            InicioVinculoGuia =
                                (AceroMuroVinculoGuiaHorizontal2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "InicioVinculoGuia")),
                            InicioVinculoVertical =
                                (AceroMuroVinculoVertical2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "InicioVinculoVertical")),
                            FinVinculoGuia =
                                (AceroMuroVinculoGuiaHorizontal2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "FinVinculoGuia")),
                            FinVinculoVertical =
                                (AceroMuroVinculoVertical2P)
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "FinVinculoVertical")),
                            ReglaDistribucion =
                                LeerIntXml(
                                    nodo.GetAttribute(
                                        "Regla")) == 1
                                    ? AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                                    : AceroMuroReglaDistribucionGrupo.NumeroFijo,
                            EspaciamientoMaximoCm =
                                System.Math.Max(
                                    0.5,
                                    LeerDoubleXml(
                                        nodo.GetAttribute(
                                            "EspaciadoMaximoCm")) > 0.0
                                        ? LeerDoubleXml(
                                            nodo.GetAttribute(
                                                "EspaciadoMaximoCm"))
                                        : 20.0),
                            Cantidad =
                                System.Math.Max(
                                    2,
                                    LeerIntXml(
                                        nodo.GetAttribute(
                                            "Cantidad"))),
                            TipoBarraId =
                                LeerLongXml(
                                    nodo.GetAttribute(
                                        "TipoBarraId")),
                            TipoBarraNombre =
                                nodo.GetAttribute(
                                    "TipoBarraNombre")
                        });
                }
            }

            return data;
        }

        private void SetAtributoXml(
            System.Xml.XmlElement elemento,
            string nombre,
            string valor)
        {
            if (elemento == null)
                return;

            elemento.SetAttribute(
                nombre,
                valor ?? "");
        }

        private string ATextoInvariant(
            double valor)
        {
            return valor.ToString(
                "R",
                System.Globalization.CultureInfo.InvariantCulture);
        }

        private double LeerDoubleXml(
            string texto)
        {
            double valor;

            if (double.TryParse(
                texto,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor))
            {
                return valor;
            }

            return 0.0;
        }

        private long LeerLongXml(
            string texto)
        {
            long valor;

            if (long.TryParse(
                    texto,
                    out valor))
            {
                return valor;
            }

            return 0;
        }


        private int LeerIntXml(
            string texto)
        {
            int valor;

            if (int.TryParse(
                texto,
                out valor))
            {
                return valor;
            }

            return 0;
        }

        private bool LeerBoolXml(
            string texto,
            bool valorDefecto)
        {
            bool valor;

            if (bool.TryParse(
                texto,
                out valor))
            {
                return valor;
            }

            return valorDefecto;
        }

        private double AplicarOsnapAlzado(
            double xModelo,
            long ignorarMuroId = 0)
        {
            snapAlzadoVisible = false;
            snapAlzadoTexto = "";

            if (!osnapActivo ||
                vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return xModelo;
            }

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double mejor = xModelo;
            double mejorDistanciaPx = 18.0;
            string mejorTexto = "";

            // -----------------------------------------------------
            // 1) REFERENCIAS DE LOS MUROS
            // -----------------------------------------------------
            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                System.Collections.Generic.List<
                    System.Tuple<double, string>> candidatos =
                        new System.Collections.Generic.List<
                            System.Tuple<double, string>>();

                if (osnapExtremo)
                {
                    candidatos.Add(
                        System.Tuple.Create(
                            tramo.XInicio,
                            "EXTREMO MURO"));

                    candidatos.Add(
                        System.Tuple.Create(
                            tramo.XFin,
                            "EXTREMO MURO"));

                    candidatos.Add(
                        System.Tuple.Create(
                            tramo.XInicio + rec,
                            "RECUBRIMIENTO MURO"));

                    candidatos.Add(
                        System.Tuple.Create(
                            tramo.XFin - rec,
                            "RECUBRIMIENTO MURO"));
                }

                if (osnapPuntoMedio)
                {
                    candidatos.Add(
                        System.Tuple.Create(
                            (tramo.XInicio +
                             tramo.XFin) * 0.5,
                            "PUNTO MEDIO"));
                }

                EvaluarCandidatosOsnapAlzado(
                    candidatos,
                    xModelo,
                    ref mejor,
                    ref mejorDistanciaPx,
                    ref mejorTexto);
            }

            // -----------------------------------------------------
            // 2) REFERENCIAS DE LOS ELEMENTOS DE LOS EXTREMOS
            //
            // Durante el arrastre de INICIO solo se ofrecen referencias
            // del elemento extremo inicial de la misma cadena.
            // Para FIN, solamente las del extremo final.
            // -----------------------------------------------------
            if (vistaElevacionActual.ElementosExtremos != null)
            {
                AceroMuroTramoVista tramoDrag =
                    ignorarMuroId != 0
                        ? ObtenerTramoPorId(
                            ignorarMuroId)
                        : null;

                foreach (
                    AceroMuroElementoExtremoVista extremo
                    in vistaElevacionActual.ElementosExtremos)
                {
                    if (extremo == null)
                        continue;

                    if (tramoDrag != null &&
                        extremo.Cadena !=
                            tramoDrag.Cadena)
                    {
                        continue;
                    }

                    if (arrastrandoHandleAlzado)
                    {
                        if (tramoDragEsInicio &&
                            !extremo.EsInicio)
                        {
                            continue;
                        }

                        if (!tramoDragEsInicio &&
                            extremo.EsInicio)
                        {
                            continue;
                        }
                    }

                    System.Collections.Generic.List<
                        System.Tuple<double, string>> candidatosExt =
                            ObtenerCandidatosElementoExtremo(
                                extremo);

                    EvaluarCandidatosOsnapAlzado(
                        candidatosExt,
                        xModelo,
                        ref mejor,
                        ref mejorDistanciaPx,
                        ref mejorTexto);
                }
            }

            if (!string.IsNullOrWhiteSpace(
                mejorTexto))
            {
                snapAlzadoVisible = true;
                snapAlzadoX = mejor;
                snapAlzadoTexto = mejorTexto;
            }

            return mejor;
        }

        private void DibujarGuiaOsnapAlzado(
            System.Drawing.Graphics g,
            System.Func<double, float> sx)
        {
            if (!snapAlzadoVisible ||
                !osnapActivo)
            {
                return;
            }

            float x = sx(snapAlzadoX);

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0, 174, 239),
                        1.2F))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.5F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush brush =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            0, 120, 185)))
            {
                pen.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dot;

                g.DrawLine(
                    pen,
                    x,
                    34F,
                    x,
                    pnlVistaAlzado.ClientSize.Height - 34F);

                g.DrawString(
                    snapAlzadoTexto,
                    fuente,
                    brush,
                    x + 5F,
                    34F);
            }
        }

        private System.Collections.Generic.List<
            System.Tuple<double, string>>
            ObtenerGuiasXHorizontalesSeccion()
        {
            System.Collections.Generic.List<
                System.Tuple<double, string>> guias =
                    new System.Collections.Generic.List<
                        System.Tuple<double, string>>();

            if (vistaSeccionActual == null ||
                chkHorizontales == null ||
                !chkHorizontales.Checked)
            {
                return guias;
            }

            AceroMuroConfiguracion conf =
                ObtenerConfiguracionVisual();

            double espesor =
                vistaSeccionActual.Espesor;

            double nucleoMin =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMinDesdeCentro
                    : -espesor * 0.5;

            double nucleoMax =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMaxDesdeCentro
                    : espesor * 0.5;

            double diametroVertical =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double diametroHorizontal =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            // =====================================================
            // RECUBRIMIENTO ACTUAL
            //
            // IMPORTANTE:
            // se lee CADA VEZ QUE SE PINTA LA VISTA.
            // Por tanto la guía no almacena una posición antigua.
            // =====================================================
            double recubrimientoCm =
                ObtenerRecubrimientoCmActual();

            double recubrimiento =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        recubrimientoCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double radioVertical =
                diametroVertical * 0.5;

            double radioHorizontal =
                diametroHorizontal * 0.5;

            double minimoCentro =
                nucleoMin +
                radioHorizontal;

            double maximoCentro =
                nucleoMax -
                radioHorizontal;

            if (maximoCentro < minimoCentro)
            {
                minimoCentro =
                    nucleoMin;

                maximoCentro =
                    nucleoMax;
            }

            System.Collections.Generic.List<int> caras =
                ObtenerCarasVista(
                    conf.ModoCaras);

            // Separación real V/H:
            // radio V + radio H + holgura de 5 mm.
            //
            // Usamos el mismo método que usa la preview para que
            // la guía represente exactamente la posición segura.
            double separacionEjes =
                ObtenerSeparacionEjesVerticalHorizontalPiesVista();

            // =====================================================
            // DOBLE MALLA - CARA A
            //
            // La guía se calcula EXPLÍCITAMENTE desde:
            //
            // cara del núcleo
            // + recubrimiento ACTUAL
            // + radio vertical
            // + separación V/H
            //
            // Por tanto:
            // si Rec pasa 4 -> 5 cm,
            // la guía también se desplaza exactamente 1 cm.
            // =====================================================
            if (caras.Contains(1))
            {
                double ajusteA =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            ajusteSeccionIzquierdaCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double xVertical =
                    nucleoMin +
                    recubrimiento +
                    radioVertical +
                    ajusteA;

                double xHorizontal;

                if (conf.CrearVerticales &&
                    diametroVertical > 1e-9)
                {
                    xHorizontal =
                        xVertical +
                        separacionEjes;
                }
                else
                {
                    xHorizontal =
                        nucleoMin +
                        recubrimiento +
                        radioHorizontal;
                }

                xHorizontal =
                    System.Math.Min(
                        maximoCentro,
                        System.Math.Max(
                            minimoCentro,
                            xHorizontal));

                guias.Add(
                    System.Tuple.Create(
                        xHorizontal,
                        "GUIA H - MALLA A | REC " +
                        recubrimientoCm.ToString("0.#") +
                        " cm | V→H " +
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertFromInternalUnits(
                                separacionEjes,
                                Autodesk.Revit.DB.UnitTypeId.Centimeters)
                            .ToString("0.#") +
                        " cm"));
            }

            // =====================================================
            // DOBLE MALLA - CARA B
            // =====================================================
            if (caras.Contains(-1))
            {
                double ajusteB =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            ajusteSeccionDerechaCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double xVertical =
                    nucleoMax -
                    recubrimiento -
                    radioVertical -
                    ajusteB;

                double xHorizontal;

                if (conf.CrearVerticales &&
                    diametroVertical > 1e-9)
                {
                    xHorizontal =
                        xVertical -
                        separacionEjes;
                }
                else
                {
                    xHorizontal =
                        nucleoMax -
                        recubrimiento -
                        radioHorizontal;
                }

                xHorizontal =
                    System.Math.Min(
                        maximoCentro,
                        System.Math.Max(
                            minimoCentro,
                            xHorizontal));

                guias.Add(
                    System.Tuple.Create(
                        xHorizontal,
                        "GUIA H - MALLA B | REC " +
                        recubrimientoCm.ToString("0.#") +
                        " cm | V→H " +
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertFromInternalUnits(
                                separacionEjes,
                                Autodesk.Revit.DB.UnitTypeId.Centimeters)
                            .ToString("0.#") +
                        " cm"));
            }

            // =====================================================
            // UNA MALLA
            //
            // Una malla sigue gobernada por el centro del núcleo.
            // Si el vertical está exactamente en el centro, la guía H
            // se separa físicamente para evitar interferencia.
            // =====================================================
            if (caras.Contains(0))
            {
                double centroNucleo =
                    (nucleoMin +
                     nucleoMax) * 0.5;

                double xHorizontal =
                    centroNucleo;

                if (conf.CrearVerticales &&
                    diametroVertical > 1e-9)
                {
                    double xVertical =
                        ObtenerXVerticalLocalVista(
                            0);

                    double tolerancia =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertToInternalUnits(
                                1.0,
                                Autodesk.Revit.DB.UnitTypeId.Millimeters);

                    if (System.Math.Abs(
                            xVertical -
                            centroNucleo) <=
                        tolerancia)
                    {
                        double candidatoPositivo =
                            xVertical +
                            separacionEjes;

                        double candidatoNegativo =
                            xVertical -
                            separacionEjes;

                        bool cabePositivo =
                            candidatoPositivo <=
                                maximoCentro +
                                1e-9;

                        bool cabeNegativo =
                            candidatoNegativo >=
                                minimoCentro -
                                1e-9;

                        if (cabePositivo)
                        {
                            xHorizontal =
                                candidatoPositivo;
                        }
                        else if (cabeNegativo)
                        {
                            xHorizontal =
                                candidatoNegativo;
                        }
                    }
                    else
                    {
                        xHorizontal =
                            centroNucleo;
                    }
                }

                xHorizontal =
                    System.Math.Min(
                        maximoCentro,
                        System.Math.Max(
                            minimoCentro,
                            xHorizontal));

                guias.Add(
                    System.Tuple.Create(
                        xHorizontal,
                        "GUIA H - UNA MALLA"));
            }

            return
                guias;
        }

        private void ObtenerRangoSeguroGuiasHorizontalesSeccion(
            out double zInferior,
            out double zSuperior)
        {
            zInferior = 0.0;
            zSuperior = 0.0;

            if (vistaSeccionActual == null)
                return;

            double altura =
                vistaSeccionActual.Altura;

            double recubrimiento =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diametroHorizontal =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            double baseHorizontal =
                recubrimiento +
                diametroHorizontal * 0.5;

            double zonaGanchoInferior =
                ObtenerZonaGanchoHorizontalPiesVista(
                    false);

            double zonaGanchoSuperior =
                ObtenerZonaGanchoHorizontalPiesVista(
                    true);

            zInferior =
                baseHorizontal +
                zonaGanchoInferior;

            zSuperior =
                altura -
                baseHorizontal -
                zonaGanchoSuperior;

            zInferior =
                System.Math.Max(
                    -altura,
                    System.Math.Min(
                        altura * 2.0,
                        zInferior));

            zSuperior =
                System.Math.Max(
                    zInferior,
                    System.Math.Min(
                        altura * 2.0,
                        zSuperior));
        }

        private void DibujarGuiasCreacionHorizontalSeccion(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                vistaSeccionActual == null ||
                chkHorizontales == null ||
                !chkHorizontales.Checked)
            {
                return;
            }

            System.Collections.Generic.List<
                System.Tuple<double, string>> guiasX =
                    ObtenerGuiasXHorizontalesSeccion();

            if (guiasX.Count == 0)
                return;

            double zInferior;
            double zSuperior;

            ObtenerRangoSeguroGuiasHorizontalesSeccion(
                out zInferior,
                out zSuperior);

            double espesor =
                vistaSeccionActual.Espesor;

            double nucleoMin =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMinDesdeCentro
                    : -espesor * 0.5;

            double nucleoMax =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMaxDesdeCentro
                    : espesor * 0.5;

            using (
                System.Drawing.Pen penGuiaFondo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            245,
                            245,
                            245),
                        4.2F))
            using (
                System.Drawing.Pen penGuia =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0,
                            170,
                            220),
                        2.1F))
            using (
                System.Drawing.Pen penLimite =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            225,
                            125,
                            35),
                        1.05F))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush brushGuia =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            20,
                            125,
                            155)))
            using (
                System.Drawing.Brush brushLimite =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            190,
                            90,
                            20)))
            {
                penGuiaFondo.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Solid;

                penGuia.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                penGuia.DashPattern =
                    new float[]
                    {
                    5.0F,
                    3.0F
                    };

                penLimite.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dot;

                float yInf =
                    PantallaYSeccion(
                        zInferior);

                float ySup =
                    PantallaYSeccion(
                        zSuperior);

                foreach (
                    System.Tuple<double, string> guia
                    in guiasX)
                {
                    float x =
                        PantallaXSeccion(
                            guia.Item1);

                    // Fondo para que la guía sea visible incluso
                    // cuando quede muy cerca del vertical.
                    g.DrawLine(
                        penGuiaFondo,
                        x,
                        ySup,
                        x,
                        yInf);

                    g.DrawLine(
                        penGuia,
                        x,
                        ySup,
                        x,
                        yInf);

                    g.DrawString(
                        guia.Item2,
                        fuente,
                        brushGuia,
                        x + 4F,
                        System.Math.Min(
                            yInf,
                            ySup) + 4F);
                }

                float x1 =
                    PantallaXSeccion(
                        nucleoMin);

                float x2 =
                    PantallaXSeccion(
                        nucleoMax);

                g.DrawLine(
                    penLimite,
                    x1,
                    yInf,
                    x2,
                    yInf);

                g.DrawLine(
                    penLimite,
                    x1,
                    ySup,
                    x2,
                    ySup);

                g.DrawString(
                    anguloGanchoInferior != 0
                        ? "LIMITE H INF - CURVATURA GANCHO"
                        : "LIMITE H INF",
                    fuente,
                    brushLimite,
                    x2 + 5F,
                    yInf - 8F);

                g.DrawString(
                    anguloGanchoSuperior != 0
                        ? "LIMITE H SUP - CURVATURA GANCHO"
                        : "LIMITE H SUP",
                    fuente,
                    brushLimite,
                    x2 + 5F,
                    ySup - 8F);
            }
        }


        private double AplicarOsnapSeccionX(
            double xModelo)
        {
            snapSeccionVisible = false;
            snapSeccionTexto = "";

            if (!osnapActivo ||
                vistaSeccionActual == null)
            {
                return xModelo;
            }

            double espesor =
                vistaSeccionActual.Espesor;

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            System.Collections.Generic.List<
                System.Tuple<double, string>> candidatos =
                    new System.Collections.Generic.List<
                        System.Tuple<double, string>>
                    {
                    System.Tuple.Create(
                        -espesor * 0.5,
                        "CARA MURO"),
                    System.Tuple.Create(
                        espesor * 0.5,
                        "CARA MURO"),
                    System.Tuple.Create(
                        -espesor * 0.5 + rec,
                        "RECUBRIMIENTO"),
                    System.Tuple.Create(
                        espesor * 0.5 - rec,
                        "RECUBRIMIENTO"),
                    System.Tuple.Create(
                        0.0,
                        "EJE")
                    };

            System.Collections.Generic.List<
                System.Tuple<double, string>> guiasHorizontales =
                    ObtenerGuiasXHorizontalesSeccion();

            foreach (
                System.Tuple<double, string> guia
                in guiasHorizontales)
            {
                candidatos.Add(
                    guia);
            }

            double mejor = xModelo;
            double mejorPx = 15.0;
            string texto = "";

            foreach (
                System.Tuple<double, string> candidato
                in candidatos)
            {
                double d =
                    System.Math.Abs(
                        PantallaXSeccion(
                            candidato.Item1) -
                        PantallaXSeccion(
                            xModelo));

                if (d < mejorPx)
                {
                    mejorPx = d;
                    mejor = candidato.Item1;
                    texto = candidato.Item2;
                }
            }

            if (!string.IsNullOrWhiteSpace(texto))
            {
                snapSeccionVisible = true;
                snapSeccionVertical = true;
                snapSeccionValor = mejor;
                snapSeccionTexto = texto;
            }

            return mejor;
        }

        private double AplicarOsnapSeccionY(
            double zModelo)
        {
            snapSeccionVisible = false;
            snapSeccionTexto = "";

            if (!osnapActivo ||
                vistaSeccionActual == null)
            {
                return zModelo;
            }

            double altura =
                vistaSeccionActual.Altura;

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            System.Collections.Generic.List<
                System.Tuple<double, string>> candidatos =
                    new System.Collections.Generic.List<
                        System.Tuple<double, string>>
                    {
                    System.Tuple.Create(0.0, "BASE MURO"),
                    System.Tuple.Create(altura, "CORONACIÓN MURO"),
                    System.Tuple.Create(rec, "RECUBRIMIENTO"),
                    System.Tuple.Create(altura - rec, "RECUBRIMIENTO"),
                    System.Tuple.Create(altura * 0.5, "PUNTO MEDIO")
                    };

            double zGuiaInferior;
            double zGuiaSuperior;

            ObtenerRangoSeguroGuiasHorizontalesSeccion(
                out zGuiaInferior,
                out zGuiaSuperior);

            candidatos.Add(
                System.Tuple.Create(
                    zGuiaInferior,
                    anguloGanchoInferior != 0
                        ? "GUIA H INF - GANCHO"
                        : "GUIA H INF"));

            candidatos.Add(
                System.Tuple.Create(
                    zGuiaSuperior,
                    anguloGanchoSuperior != 0
                        ? "GUIA H SUP - GANCHO"
                        : "GUIA H SUP"));

            double mejor = zModelo;
            double mejorPx = 15.0;
            string texto = "";

            foreach (
                System.Tuple<double, string> candidato
                in candidatos)
            {
                double d =
                    System.Math.Abs(
                        PantallaYSeccion(
                            candidato.Item1) -
                        PantallaYSeccion(
                            zModelo));

                if (d < mejorPx)
                {
                    mejorPx = d;
                    mejor = candidato.Item1;
                    texto = candidato.Item2;
                }
            }

            if (!string.IsNullOrWhiteSpace(texto))
            {
                snapSeccionVisible = true;
                snapSeccionVertical = false;
                snapSeccionValor = mejor;
                snapSeccionTexto = texto;
            }

            return mejor;
        }

        private void DibujarGuiaOsnapSeccion(
            System.Drawing.Graphics g)
        {
            if (!snapSeccionVisible ||
                !osnapActivo ||
                g == null)
            {
                return;
            }

            using (
                System.Drawing.Pen penTracking =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0, 174, 239),
                        1.15F))
            using (
                System.Drawing.Pen penSimbolo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0, 155, 80),
                        2.0F))
            using (
                System.Drawing.Pen penFondo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.White,
                        4.0F))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8.0F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush brushTexto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            15, 95, 145)))
            using (
                System.Drawing.Brush brushFondo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            235, 250, 255)))
            {
                penTracking.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                penTracking.DashPattern =
                    new float[]
                    {
                    4.0F,
                    3.0F
                    };

                // -------------------------------------------------
                // TRACKING DE REFERENCIA
                // -------------------------------------------------
                if (snapSeccionPuntoValido)
                {
                    float sx =
                        PantallaXSeccion(
                            snapSeccionPuntoX);

                    float sy =
                        PantallaYSeccion(
                            snapSeccionPuntoZ);

                    // Si el segundo punto está en curso, mostrar la
                    // relación geométrica desde el primer punto.
                    // Funciona tanto para CREAR H 2 PTOS como para
                    // CREAR V 2 PTOS.
                    if (creandoHorizontalDosPuntos ||
                        creandoVerticalDosPuntos ||
                        arrastrandoExtremoHorizontal2P ||
                        arrastrandoExtremoVertical2P)
                    {
                        double inicioXModelo;
                        double inicioZModelo;

                        if (creandoVerticalDosPuntos)
                        {
                            inicioXModelo =
                                vertical2PInicioX;

                            inicioZModelo =
                                vertical2PInicioZ;
                        }
                        else if (creandoHorizontalDosPuntos)
                        {
                            inicioXModelo =
                                horizontal2PInicioX;

                            inicioZModelo =
                                horizontal2PInicioZ;
                        }
                        else if (arrastrandoExtremoVertical2P)
                        {
                            AceroMuroGrupoVertical2Puntos grupo =
                                ObtenerGrupoVertical2PuntosPorId(
                                    grupoVertical2PSeleccionadoId);

                            System.Drawing.PointF fijo =
                                System.Drawing.PointF.Empty;

                            if (grupo != null)
                            {
                                fijo =
                                    arrastrandoInicioVertical2P
                                        ? ObtenerFinModeloGrupoVertical2P(
                                            grupo)
                                        : ObtenerInicioModeloGrupoVertical2P(
                                            grupo);
                            }

                            inicioXModelo =
                                fijo.X;

                            inicioZModelo =
                                fijo.Y;
                        }
                        else
                        {
                            AceroMuroGrupoHorizontal2Puntos grupo =
                                ObtenerGrupoHorizontal2PuntosPorId(
                                    grupoHorizontal2PSeleccionadoId);

                            System.Drawing.PointF fijo =
                                System.Drawing.PointF.Empty;

                            if (grupo != null)
                            {
                                fijo =
                                    arrastrandoInicioHorizontal2P
                                        ? ObtenerFinModeloGrupoHorizontal2P(
                                            grupo)
                                        : ObtenerInicioModeloGrupoHorizontal2P(
                                            grupo);
                            }

                            inicioXModelo =
                                fijo.X;

                            inicioZModelo =
                                fijo.Y;
                        }

                        float x0 =
                            PantallaXSeccion(
                                inicioXModelo);

                        float y0 =
                            PantallaYSeccion(
                                inicioZModelo);

                        if (snapSeccionModo ==
                            "PERPENDICULAR")
                        {
                            // Tracking ortogonal tipo Autodesk.
                            // Para V se prioriza primero la vertical;
                            // para H se prioriza primero la horizontal.
                            if (creandoVerticalDosPuntos ||
                                arrastrandoExtremoVertical2P)
                            {
                                g.DrawLine(
                                    penTracking,
                                    x0,
                                    y0,
                                    x0,
                                    sy);

                                g.DrawLine(
                                    penTracking,
                                    x0,
                                    sy,
                                    sx,
                                    sy);
                            }
                            else
                            {
                                g.DrawLine(
                                    penTracking,
                                    x0,
                                    y0,
                                    sx,
                                    y0);

                                g.DrawLine(
                                    penTracking,
                                    sx,
                                    y0,
                                    sx,
                                    sy);
                            }
                        }
                        else if (snapSeccionModo ==
                            "ALINEADO H" ||
                            snapSeccionModo ==
                            "ALINEADO V")
                        {
                            g.DrawLine(
                                penTracking,
                                x0,
                                y0,
                                sx,
                                sy);
                        }
                    }

                    // ---------------------------------------------
                    // SÍMBOLO SEGÚN TIPO DE SNAP
                    // ---------------------------------------------
                    float r =
                        5.0F;

                    // Fondo blanco para legibilidad.
                    if (snapSeccionModo ==
                        "EXTREMO")
                    {
                        g.DrawRectangle(
                            penFondo,
                            sx - r,
                            sy - r,
                            r * 2.0F,
                            r * 2.0F);

                        g.DrawRectangle(
                            penSimbolo,
                            sx - r,
                            sy - r,
                            r * 2.0F,
                            r * 2.0F);
                    }
                    else if (snapSeccionModo ==
                        "CERCANO")
                    {
                        g.DrawEllipse(
                            penFondo,
                            sx - r,
                            sy - r,
                            r * 2.0F,
                            r * 2.0F);

                        g.DrawEllipse(
                            penSimbolo,
                            sx - r,
                            sy - r,
                            r * 2.0F,
                            r * 2.0F);
                    }
                    else if (snapSeccionModo ==
                        "PERPENDICULAR")
                    {
                        float q =
                            8.0F;

                        g.DrawLine(
                            penFondo,
                            sx - q,
                            sy,
                            sx,
                            sy);

                        g.DrawLine(
                            penFondo,
                            sx,
                            sy,
                            sx,
                            sy + q);

                        g.DrawLine(
                            penSimbolo,
                            sx - q,
                            sy,
                            sx,
                            sy);

                        g.DrawLine(
                            penSimbolo,
                            sx,
                            sy,
                            sx,
                            sy + q);

                        g.DrawLine(
                            penSimbolo,
                            sx - q,
                            sy + q,
                            sx,
                            sy + q);

                        g.DrawLine(
                            penSimbolo,
                            sx - q,
                            sy,
                            sx - q,
                            sy + q);
                    }
                    else if (snapSeccionModo ==
                             "ALINEADO H" ||
                             snapSeccionModo ==
                             "ALINEADO V")
                    {
                        float q =
                            6.0F;

                        g.DrawLine(
                            penFondo,
                            sx - q,
                            sy,
                            sx + q,
                            sy);

                        g.DrawLine(
                            penFondo,
                            sx,
                            sy - q,
                            sx,
                            sy + q);

                        g.DrawLine(
                            penSimbolo,
                            sx - q,
                            sy,
                            sx + q,
                            sy);

                        g.DrawLine(
                            penSimbolo,
                            sx,
                            sy - q,
                            sx,
                            sy + q);
                    }
                    else
                    {
                        g.DrawEllipse(
                            penSimbolo,
                            sx - 4F,
                            sy - 4F,
                            8F,
                            8F);
                    }

                    // ---------------------------------------------
                    // ETIQUETA AL LADO DEL PUNTO
                    // ---------------------------------------------
                    if (!string.IsNullOrWhiteSpace(
                        snapSeccionTexto))
                    {
                        string etiqueta =
                            snapSeccionModo +
                            " | " +
                            snapSeccionTexto;

                        System.Drawing.SizeF tam =
                            g.MeasureString(
                                etiqueta,
                                fuente);

                        float tx =
                            sx + 12F;

                        float ty =
                            sy - tam.Height - 6F;

                        if (tx + tam.Width + 8F >
                            pnlVistaSeccion.ClientSize.Width)
                        {
                            tx =
                                sx -
                                tam.Width -
                                16F;
                        }

                        if (ty < 4F)
                            ty = sy + 10F;

                        System.Drawing.RectangleF caja =
                            new System.Drawing.RectangleF(
                                tx - 3F,
                                ty - 2F,
                                tam.Width + 6F,
                                tam.Height + 4F);

                        g.FillRectangle(
                            brushFondo,
                            caja);

                        g.DrawString(
                            etiqueta,
                            fuente,
                            brushTexto,
                            tx,
                            ty);
                    }
                }

                // -------------------------------------------------
                // RESALTAR LA REFERENCIA ACTIVA
                // -------------------------------------------------
                if (snapSeccionVertical)
                {
                    float x =
                        PantallaXSeccion(
                            snapSeccionValor);

                    g.DrawLine(
                        penTracking,
                        x,
                        28F,
                        x,
                        pnlVistaSeccion.ClientSize.Height - 28F);
                }
                else if (!snapSeccionPuntoValido)
                {
                    float y =
                        PantallaYSeccion(
                            snapSeccionValor);

                    g.DrawLine(
                        penTracking,
                        28F,
                        y,
                        pnlVistaSeccion.ClientSize.Width - 28F,
                        y);
                }
            }
        }

        private void AplicarMoverDosPuntosAlTramo(
            long muroId,
            double deltaModelo)
        {
            AceroMuroTramoVista tramo =
                ObtenerTramoPorId(
                    muroId);

            if (tramo == null)
                return;

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double defaultInicio =
                tramo.XInicio + rec;

            double defaultFin =
                tramo.XFin - rec;

            double actualInicio =
                ObtenerXInicioEditableTramo(
                    tramo);

            double actualFin =
                ObtenerXFinEditableTramo(
                    tramo);

            double nuevaInicio =
                actualInicio + deltaModelo;

            double nuevaFin =
                actualFin + deltaModelo;

            // No se limita al anfitrión: puede quedar fuera del muro.
            ajusteInicioTramoCm[muroId] =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        nuevaInicio - defaultInicio,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            ajusteFinTramoCm[muroId] =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        defaultFin - nuevaFin,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            pnlVistaAlzado.Invalidate();
        }

        private void CopiarAjusteTramo(
            long origenId,
            long destinoId)
        {
            double inicio =
                ObtenerAjusteInicioTramoCm(
                    origenId);

            double fin =
                ObtenerAjusteFinTramoCm(
                    origenId);

            ajusteInicioTramoCm[
                destinoId] =
                inicio;

            ajusteFinTramoCm[
                destinoId] =
                fin;

            pnlVistaAlzado.Invalidate();
        }

        private string ObtenerHandleSeccionBajoCursor(
            System.Drawing.Point cursor)
        {
            // V8.50: no existen verticales automáticos ni sus manijas.
            // Los extremos editables pertenecen a grupos V 2 PTOS.
            return "";

            if (vistaSeccionActual == null ||
                vistaSeccionActual.Espesor <= 1e-9 ||
                vistaSeccionActual.Altura <= 1e-9)
            {
                return "";
            }

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double baseVertical =
                rec +
                diamVert * 0.5;

            double zInfLocal =
                baseVertical +
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionInferiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double zSupLocal =
                seccionAlturaActual -
                baseVertical -
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionSuperiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            float yi =
                PantallaYSeccion(
                    zInfLocal);

            float ys =
                PantallaYSeccion(
                    zSupLocal);

            const double tol = 12.0;

            System.Collections.Generic.List<int> caras =
                ObtenerCarasVista(
                    ObtenerModoCarasActual());

            // Los extremos se detectan EN CADA LÍNEA VERTICAL, no en el centro
            // de la sección. Así el gesto es igual al editor de vigas: se selecciona
            // el acero y luego se jala directamente su extremo visible.
            foreach (int signo in caras)
            {
                float x =
                    PantallaXSeccion(
                        ObtenerXVerticalLocalVista(signo));

                if (Distancia2D_Px(
                    cursor.X, cursor.Y,
                    x, yi) <= tol)
                {
                    return "INF";
                }

                if (Distancia2D_Px(
                    cursor.X, cursor.Y,
                    x, ys) <= tol)
                {
                    return "SUP";
                }
            }

            // Se conserva el control lateral de las cortinas para no perder
            // la edición anterior de Malla A / Malla B.
            if (ObtenerModoCarasActual() != 3)
            {
                double xIzqLocal =
                    ObtenerXVerticalLocalVista(1);

                double xDerLocal =
                    ObtenerXVerticalLocalVista(-1);

                float xi =
                    PantallaXSeccion(
                        xIzqLocal);

                float xd =
                    PantallaXSeccion(
                        xDerLocal);

                float cy =
                    (yi + ys) * 0.5F;

                if (Distancia2D_Px(
                    cursor.X, cursor.Y,
                    xi, cy) <= tol)
                {
                    return "IZQ";
                }

                if (Distancia2D_Px(
                    cursor.X, cursor.Y,
                    xd, cy) <= tol)
                {
                    return "DER";
                }
            }

            return "";
        }

        private bool TryDetectarVerticalesSeccion(
            System.Drawing.Point cursor)
        {
            // V8.50: la selección vertical automática está desactivada.
            return false;

            if (vistaSeccionActual == null ||
                chkVerticales == null ||
                !chkVerticales.Checked)
            {
                return false;
            }

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double baseVertical =
                rec +
                diamVert * 0.5;

            double zInfLocal =
                baseVertical +
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionInferiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double zSupLocal =
                seccionAlturaActual -
                baseVertical -
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionSuperiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            float yi = PantallaYSeccion(zInfLocal);
            float ys = PantallaYSeccion(zSupLocal);

            const double toleranciaPx = 10.0;

            foreach (int signo in
                ObtenerCarasVista(ObtenerModoCarasActual()))
            {
                float x =
                    PantallaXSeccion(
                        ObtenerXVerticalLocalVista(signo));

                double d =
                    DistanciaPuntoSegmentoPx(
                        cursor,
                        new System.Drawing.PointF(x, ys),
                        new System.Drawing.PointF(x, yi));

                if (d <= toleranciaPx)
                    return true;
            }

            return false;
        }

        private AceroMuroSnapPunto2P ResolverSnapMoverGruposDosPuntos(
            System.Drawing.Point cursor,
            bool tieneReferencia)
        {
            double referenciaX =
                tieneReferencia
                    ? puntoBaseMoverGruposModelo.X
                    : 0.0;

            double referenciaZ =
                tieneReferencia
                    ? puntoBaseMoverGruposModelo.Y
                    : 0.0;

            // Utilizamos el motor H porque ya integra:
            // GUIAS, EXTREMOS, MURO, ALINEACIÓN y ACEROS ALEDAÑOS.
            // Los grupos seleccionados se excluyen arriba para evitar
            // autosnap contra el propio conjunto que se mueve.
            return
                ResolverSnapInteligente2P(
                    cursor,
                    tieneReferencia,
                    referenciaX,
                    referenciaZ);
        }

        private void AplicarMoverGruposSeleccionadosDosPuntos(
            System.Drawing.PointF baseModelo,
            System.Drawing.PointF destinoModelo)
        {
            System.Collections.Generic.List<
                AceroMuroGrupoHorizontal2Puntos> gruposH =
                    ObtenerGruposHorizontalesSeleccionados();

            System.Collections.Generic.List<
                AceroMuroGrupoVertical2Puntos> gruposV =
                    ObtenerGruposVerticalesSeleccionados();

            if (gruposH.Count == 0 &&
                gruposV.Count == 0)
            {
                return;
            }

            double dx =
                destinoModelo.X -
                baseModelo.X;

            double dz =
                destinoModelo.Y -
                baseModelo.Y;

            if (System.Math.Abs(dx) <= 1e-10 &&
                System.Math.Abs(dz) <= 1e-10)
            {
                return;
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposH)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF a =
                    ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF b =
                    ObtenerFinModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF na =
                    CrearPuntoNormalizadoSeccion2P(
                        a.X + dx,
                        a.Y + dz);

                System.Drawing.PointF nb =
                    CrearPuntoNormalizadoSeccion2P(
                        b.X + dx,
                        b.Y + dz);

                grupo.InicioU = na.X;
                grupo.InicioV = na.Y;
                grupo.FinU = nb.X;
                grupo.FinV = nb.Y;

                // Si cambia X deja de seguir la guía lateral.
                if (System.Math.Abs(dx) > 1e-10)
                {
                    grupo.InicioVinculoGuia =
                        AceroMuroVinculoGuiaHorizontal2P.Ninguno;

                    grupo.FinVinculoGuia =
                        AceroMuroVinculoGuiaHorizontal2P.Ninguno;
                }

                // Si cambia Z deja de seguir límites SUP/INF.
                if (System.Math.Abs(dz) > 1e-10)
                {
                    grupo.InicioVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;

                    grupo.FinVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;
                }
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposV)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF a =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF b =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF na =
                    CrearPuntoNormalizadoSeccion2P(
                        a.X + dx,
                        a.Y + dz);

                System.Drawing.PointF nb =
                    CrearPuntoNormalizadoSeccion2P(
                        b.X + dx,
                        b.Y + dz);

                grupo.InicioU = na.X;
                grupo.InicioV = na.Y;
                grupo.FinU = nb.X;
                grupo.FinV = nb.Y;

                if (System.Math.Abs(dx) > 1e-10)
                {
                    grupo.InicioVinculoGuia =
                        AceroMuroVinculoGuiaHorizontal2P.Ninguno;

                    grupo.FinVinculoGuia =
                        AceroMuroVinculoGuiaHorizontal2P.Ninguno;
                }

                if (System.Math.Abs(dz) > 1e-10)
                {
                    grupo.InicioVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;

                    grupo.FinVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;
                }
            }

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Invalidate();

            if (pnlVistaAlzado != null)
                pnlVistaAlzado.Invalidate();

            ActualizarPanelGrupoSeleccionado();

            ActualizarEstado(
                "MOVER 2 PTOS: " +
                (gruposH.Count + gruposV.Count) +
                " grupo(s) desplazado(s).");
        }

        private void DibujarVistaPreviaMoverGruposDosPuntos(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                herramientaSeccion !=
                    AceroMuroHerramientaEdicion.MoverDosPuntos ||
                faseMoverDosPuntosSeccion != 1 ||
                ObtenerCantidadGruposSeleccionados() == 0)
            {
                return;
            }

            double dx =
                puntoDestinoMoverGruposModelo.X -
                puntoBaseMoverGruposModelo.X;

            double dz =
                puntoDestinoMoverGruposModelo.Y -
                puntoBaseMoverGruposModelo.Y;

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            180,
                            70,
                            70,
                            70),
                        1.8F))
            using (
                System.Drawing.SolidBrush punto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            175,
                            70,
                            70,
                            70)))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.5F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush texto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            70,
                            70,
                            70)))
            {
                pen.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                foreach (
                    AceroMuroGrupoVertical2Puntos grupo
                    in ObtenerGruposVerticalesSeleccionados())
                {
                    if (grupo == null)
                        continue;

                    System.Drawing.PointF a =
                        ObtenerInicioModeloGrupoVertical2P(
                            grupo);

                    System.Drawing.PointF b =
                        ObtenerFinModeloGrupoVertical2P(
                            grupo);

                    g.DrawLine(
                        pen,
                        PantallaXSeccion(
                            a.X + dx),
                        PantallaYSeccion(
                            a.Y + dz),
                        PantallaXSeccion(
                            b.X + dx),
                        PantallaYSeccion(
                            b.Y + dz));
                }

                foreach (
                    AceroMuroGrupoHorizontal2Puntos grupo
                    in ObtenerGruposHorizontalesSeleccionados())
                {
                    if (grupo == null)
                        continue;

                    System.Drawing.PointF a =
                        ObtenerInicioModeloGrupoHorizontal2P(
                            grupo);

                    System.Drawing.PointF b =
                        ObtenerFinModeloGrupoHorizontal2P(
                            grupo);

                    int cantidad =
                        System.Math.Max(
                            2,
                            ObtenerCantidadGrupoHorizontal2P(
                                grupo));

                    for (int i = 0;
                         i < cantidad;
                         i++)
                    {
                        double t =
                            (double)i /
                            (cantidad - 1);

                        double x =
                            a.X +
                            (b.X - a.X) *
                            t +
                            dx;

                        double z =
                            a.Y +
                            (b.Y - a.Y) *
                            t +
                            dz;

                        float px =
                            PantallaXSeccion(x);

                        float py =
                            PantallaYSeccion(z);

                        g.FillEllipse(
                            punto,
                            px - 3.6F,
                            py - 3.6F,
                            7.2F,
                            7.2F);
                    }

                    g.DrawLine(
                        pen,
                        PantallaXSeccion(
                            a.X + dx),
                        PantallaYSeccion(
                            a.Y + dz),
                        PantallaXSeccion(
                            b.X + dx),
                        PantallaYSeccion(
                            b.Y + dz));
                }

                float bx =
                    PantallaXSeccion(
                        puntoBaseMoverGruposModelo.X);

                float by =
                    PantallaYSeccion(
                        puntoBaseMoverGruposModelo.Y);

                float dxp =
                    PantallaXSeccion(
                        puntoDestinoMoverGruposModelo.X);

                float dyp =
                    PantallaYSeccion(
                        puntoDestinoMoverGruposModelo.Y);

                g.DrawLine(
                    pen,
                    bx,
                    by,
                    dxp,
                    dyp);

                g.DrawString(
                    "MOVER",
                    fuente,
                    texto,
                    dxp + 7F,
                    dyp + 5F);
            }
        }


        private void AplicarMoverDosPuntosSeccion(
            string handle,
            System.Drawing.PointF basePantalla,
            System.Drawing.PointF destinoPantalla)
        {
            if (string.IsNullOrWhiteSpace(
                handle))
            {
                return;
            }

            double delta;

            if (handle == "IZQ" ||
                handle == "DER")
            {
                double x0 =
                    ModeloXSeccionDesdePantalla(
                        basePantalla.X);

                double x1 =
                    ModeloXSeccionDesdePantalla(
                        destinoPantalla.X);

                delta =
                    x1 - x0;

                double deltaCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            delta,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                if (handle == "IZQ")
                {
                    ajusteSeccionIzquierdaCm =
                        ajusteSeccionIzquierdaCm +
                        deltaCm;
                }
                else
                {
                    ajusteSeccionDerechaCm =
                        ajusteSeccionDerechaCm -
                        deltaCm;
                }
            }
            else
            {
                double z0 =
                    ModeloYSeccionDesdePantalla(
                        basePantalla.Y);

                double z1 =
                    ModeloYSeccionDesdePantalla(
                        destinoPantalla.Y);

                delta =
                    z1 - z0;

                double deltaCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            delta,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                if (handle == "INF")
                {
                    ajusteSeccionInferiorCm =
                        ajusteSeccionInferiorCm +
                        deltaCm;
                }
                else
                {
                    ajusteSeccionSuperiorCm =
                        ajusteSeccionSuperiorCm -
                        deltaCm;
                }
            }

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();
        }

        private bool EliminarSeleccionEditorSeccion()
        {
            if (creandoVerticalDosPuntos)
            {
                creandoVerticalDosPuntos = false;
                vertical2PEsperandoSegundoClic = false;
                arrastrandoExtremoVertical2P = false;

                vertical2PInicioVinculoGuia =
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno;
                vertical2PInicioVinculoVertical =
                    AceroMuroVinculoVertical2P.Ninguno;
                vertical2PFinVinculoGuia =
                    AceroMuroVinculoGuiaHorizontal2P.Ninguno;
                vertical2PFinVinculoVertical =
                    AceroMuroVinculoVertical2P.Ninguno;

                if (pnlVistaSeccion != null)
                {
                    pnlVistaSeccion.Capture = false;
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Default;
                    pnlVistaSeccion.Invalidate();
                }

                snapSeccionVisible = false;
                snapSeccionPuntoValido = false;
                snapSeccionTexto = "";
                snapSeccionModo = "";

                ActualizarAyudasHerramientas();
                return true;
            }

            if (creandoHorizontalDosPuntos)
            {
                creandoHorizontalDosPuntos = false;
                horizontal2PEsperandoSegundoClic = false;
                arrastrandoExtremoHorizontal2P = false;

                if (pnlVistaSeccion != null)
                {
                    pnlVistaSeccion.Capture = false;
                    pnlVistaSeccion.Cursor =
                        System.Windows.Forms.Cursors.Default;
                    pnlVistaSeccion.Invalidate();
                }

                snapSeccionVisible = false;
                ActualizarAyudasHerramientas();
                return true;
            }

            System.Collections.Generic.List<
                AceroMuroGrupoVertical2Puntos> seleccionV =
                    ObtenerGruposVerticalesSeleccionados();

            System.Collections.Generic.List<
                AceroMuroGrupoHorizontal2Puntos> seleccionH =
                    ObtenerGruposHorizontalesSeleccionados();

            if (seleccionV.Count > 0 ||
                seleccionH.Count > 0)
            {
                RegistrarDeshacer();

                foreach (
                    AceroMuroGrupoVertical2Puntos grupoV
                    in seleccionV)
                {
                    if (grupoV != null)
                        gruposVerticales2Puntos.Remove(
                            grupoV);
                }

                foreach (
                    AceroMuroGrupoHorizontal2Puntos grupoH
                    in seleccionH)
                {
                    if (grupoH != null)
                        gruposHorizontales2Puntos.Remove(
                            grupoH);
                }

                int eliminados =
                    seleccionV.Count +
                    seleccionH.Count;

                LimpiarSeleccionMultipleGrupos(
                    true);

                OcultarEditorGrupoHorizontal2P();

                if (pnlVistaSeccion != null)
                    pnlVistaSeccion.Invalidate();

                if (pnlVistaAlzado != null)
                    pnlVistaAlzado.Invalidate();

                ActualizarAyudasHerramientas();

                ActualizarEstado(
                    eliminados <= 1
                        ? "Grupo eliminado."
                        : eliminados +
                            " grupos eliminados.");

                return true;
            }

            if (!string.IsNullOrWhiteSpace(
                seccionHandleSeleccionado))
            {
                RegistrarDeshacer();

                if (seccionHandleSeleccionado == "IZQ")
                    ajusteSeccionIzquierdaCm = 0.0;
                else if (seccionHandleSeleccionado == "DER")
                    ajusteSeccionDerechaCm = 0.0;
                else if (seccionHandleSeleccionado == "INF")
                    ajusteSeccionInferiorCm = 0.0;
                else if (seccionHandleSeleccionado == "SUP")
                    ajusteSeccionSuperiorCm = 0.0;

                seccionHandleSeleccionado = "";
                seccionHandleActivo = "";
                arrastrandoHandleSeccion = false;

                if (pnlVistaSeccion != null)
                    pnlVistaSeccion.Invalidate();

                if (pnlVistaAlzado != null)
                    pnlVistaAlzado.Invalidate();

                return true;
            }

            return false;
        }

        private void ActualizarBotonesHistorialSeccion()
        {
            if (btnSecDeshacer != null)
                btnSecDeshacer.Enabled =
                    pilaDeshacer.Count > 0;

            if (btnSecRehacer != null)
                btnSecRehacer.Enabled =
                    pilaRehacer.Count > 0;
        }


        private void RegistrarDeshacer()
        {
            if (restaurandoHistorial)
                return;

            pilaDeshacer.Push(
                CapturarEstadoEdicion());

            pilaRehacer.Clear();

            while (pilaDeshacer.Count > 50)
            {
                // Stack no permite quitar el más antiguo de forma directa.
                // 50 estados es suficientemente pequeño para esta ventana.
                break;
            }

            ActualizarBotonesHistorialSeccion();
        }

        private AceroMuroEstadoEdicion
            CapturarEstadoEdicion()
        {
            AceroMuroEstadoEdicion estado =
                new AceroMuroEstadoEdicion
                {
                    AjusteCaraACm =
                        ajusteSeccionIzquierdaCm,
                    AjusteCaraBCm =
                        ajusteSeccionDerechaCm,
                    AjusteInferiorCm =
                        ajusteSeccionInferiorCm,
                    AjusteSuperiorCm =
                        ajusteSeccionSuperiorCm,
                    GanchoInferior =
                        anguloGanchoInferior,
                    GanchoSuperior =
                        anguloGanchoSuperior,
                    GanchoInferiorManual =
                        chkLongGanchoInfManual != null &&
                        chkLongGanchoInfManual.Checked,
                    GanchoSuperiorManual =
                        chkLongGanchoSupManual != null &&
                        chkLongGanchoSupManual.Checked,
                    LongitudGanchoInferior =
                        txtLongGanchoInf != null
                            ? txtLongGanchoInf.Text
                            : "",
                    LongitudGanchoSuperior =
                        txtLongGanchoSup != null
                            ? txtLongGanchoSup.Text
                            : "",
                    BloqueoInicio =
                        bloqueoHorizontalInicio,
                    BloqueoFin =
                        bloqueoHorizontalFin
                };

            foreach (
                System.Collections.Generic.KeyValuePair<long, double> kv
                in ajusteInicioTramoCm)
            {
                estado.AjusteInicioCm[kv.Key] =
                    kv.Value;
            }

            foreach (
                System.Collections.Generic.KeyValuePair<long, double> kv
                in ajusteFinTramoCm)
            {
                estado.AjusteFinCm[kv.Key] =
                    kv.Value;
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo != null)
                    estado.GruposHorizontales2Puntos.Add(
                        grupo.Copiar());
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo != null)
                    estado.GruposVerticales2Puntos.Add(
                        grupo.Copiar());
            }

            return estado;
        }

        private void RestaurarEstadoEdicion(
            AceroMuroEstadoEdicion estado)
        {
            if (estado == null)
                return;

            restaurandoHistorial = true;

            try
            {
                ajusteInicioTramoCm.Clear();
                ajusteFinTramoCm.Clear();

                foreach (
                    System.Collections.Generic.KeyValuePair<long, double> kv
                    in estado.AjusteInicioCm)
                {
                    ajusteInicioTramoCm[kv.Key] =
                        kv.Value;
                }

                foreach (
                    System.Collections.Generic.KeyValuePair<long, double> kv
                    in estado.AjusteFinCm)
                {
                    ajusteFinTramoCm[kv.Key] =
                        kv.Value;
                }

                ajusteSeccionIzquierdaCm =
                    estado.AjusteCaraACm;

                ajusteSeccionDerechaCm =
                    estado.AjusteCaraBCm;

                ajusteSeccionInferiorCm =
                    estado.AjusteInferiorCm;

                ajusteSeccionSuperiorCm =
                    estado.AjusteSuperiorCm;

                anguloGanchoInferior =
                    estado.GanchoInferior;

                anguloGanchoSuperior =
                    estado.GanchoSuperior;

                if (chkLongGanchoInfManual != null)
                    chkLongGanchoInfManual.Checked =
                        estado.GanchoInferiorManual;

                if (chkLongGanchoSupManual != null)
                    chkLongGanchoSupManual.Checked =
                        estado.GanchoSuperiorManual;

                if (txtLongGanchoInf != null)
                    txtLongGanchoInf.Text =
                        estado.LongitudGanchoInferior ?? "";

                if (txtLongGanchoSup != null)
                    txtLongGanchoSup.Text =
                        estado.LongitudGanchoSuperior ?? "";

                ActualizarControlesLongitudGanchoManual(
                    false);

                bloqueoHorizontalInicio =
                    estado.BloqueoInicio;

                bloqueoHorizontalFin =
                    estado.BloqueoFin;

                gruposHorizontales2Puntos.Clear();

                foreach (
                    AceroMuroGrupoHorizontal2Puntos grupo
                    in estado.GruposHorizontales2Puntos)
                {
                    if (grupo != null)
                        gruposHorizontales2Puntos.Add(
                            grupo.Copiar());
                }

                gruposHorizontales2PSeleccionados.Clear();
                grupoHorizontal2PSeleccionadoId = "";

                gruposVerticales2Puntos.Clear();

                foreach (
                    AceroMuroGrupoVertical2Puntos grupo
                    in estado.GruposVerticales2Puntos)
                {
                    if (grupo != null)
                        gruposVerticales2Puntos.Add(
                            grupo.Copiar());
                }

                gruposVerticales2PSeleccionados.Clear();
                grupoVertical2PSeleccionadoId = "";
            }
            finally
            {
                restaurandoHistorial = false;
            }

            ActualizarBotonesBloqueo();
            ActualizarBotonesHistorialSeccion();

            pnlVistaAlzado.Invalidate();
            pnlVistaSeccion.Invalidate();
        }

        private void DeshacerDiseno()
        {
            if (pilaDeshacer.Count == 0)
            {
                ActualizarBotonesHistorialSeccion();
                return;
            }

            pilaRehacer.Push(
                CapturarEstadoEdicion());

            RestaurarEstadoEdicion(
                pilaDeshacer.Pop());

            ActualizarBotonesHistorialSeccion();
        }

        private void RehacerDiseno()
        {
            if (pilaRehacer.Count == 0)
            {
                ActualizarBotonesHistorialSeccion();
                return;
            }

            pilaDeshacer.Push(
                CapturarEstadoEdicion());

            RestaurarEstadoEdicion(
                pilaRehacer.Pop());

            ActualizarBotonesHistorialSeccion();
        }

        protected override bool ProcessCmdKey(
            ref System.Windows.Forms.Message msg,
            System.Windows.Forms.Keys keyData)
        {
            System.Windows.Forms.Control foco =
                ObtenerControlConFoco(
                    this);

            bool editandoCampo =
                foco is System.Windows.Forms.TextBoxBase ||
                foco is System.Windows.Forms.ComboBox ||
                foco is System.Windows.Forms.UpDownBase;

            if (!editandoCampo &&
                keyData ==
                    (System.Windows.Forms.Keys.Control |
                     System.Windows.Forms.Keys.Z))
            {
                DeshacerDiseno();
                return true;
            }

            if (!editandoCampo &&
                keyData ==
                    (System.Windows.Forms.Keys.Control |
                     System.Windows.Forms.Keys.Y))
            {
                RehacerDiseno();
                return true;
            }

            if (!editandoCampo &&
                keyData ==
                    System.Windows.Forms.Keys.F3)
            {
                osnapActivo =
                    !osnapActivo;

                if (!osnapActivo)
                {
                    snapSeccionVisible = false;
                    snapSeccionPuntoValido = false;
                    snapSeccionTexto = "";
                    snapSeccionModo = "";
                }

                ActualizarEstado(
                    osnapActivo
                        ? "OSNAP activado: EXTREMO / CERCANO / PERPENDICULAR / ALINEADO."
                        : "OSNAP desactivado.");

                if (pnlVistaSeccion != null)
                    pnlVistaSeccion.Invalidate();

                return true;
            }

            if (!editandoCampo &&
                keyData ==
                    System.Windows.Forms.Keys.Escape)
            {
                CambiarHerramientaAlzado(
                    AceroMuroHerramientaEdicion.SeleccionarMover);

                CambiarHerramientaSeccion(
                    AceroMuroHerramientaEdicion.SeleccionarMover);

                snapAlzadoVisible = false;
                snapSeccionVisible = false;

                return true;
            }

            if (!editandoCampo &&
                keyData ==
                    System.Windows.Forms.Keys.Delete)
            {
                if (EliminarSeleccionEditorSeccion())
                    return true;

                if (tramoSeleccionadoId != 0)
                {
                    RegistrarDeshacer();

                    ajusteInicioTramoCm.Remove(
                        tramoSeleccionadoId);

                    ajusteFinTramoCm.Remove(
                        tramoSeleccionadoId);

                    pnlVistaAlzado.Invalidate();

                    return true;
                }

            }

            return base.ProcessCmdKey(
                ref msg,
                keyData);
        }

        private System.Windows.Forms.Control
            ObtenerControlConFoco(
                System.Windows.Forms.Control contenedor)
        {
            if (contenedor == null)
                return null;

            if (contenedor.Focused)
                return contenedor;

            foreach (
                System.Windows.Forms.Control control
                in contenedor.Controls)
            {
                if (!control.ContainsFocus &&
                    !control.Focused)
                {
                    continue;
                }

                System.Windows.Forms.Control encontrado =
                    ObtenerControlConFoco(
                        control);

                return encontrado ??
                    control;
            }

            return null;
        }

        private void BtnSeleccionar_Click(
            object sender,
            System.EventArgs e)
        {
            if (Handler == null || ExternalEvent == null)
                return;

            if (ExternalEvent.IsPending)
            {
                ActualizarEstado(
                    "Revit todavía está procesando la solicitud anterior.");
                return;
            }

            Handler.Accion = AceroMuroAccion.Seleccionar;
            OcultarParaSeleccion();

            Autodesk.Revit.UI.ExternalEventRequest resultado =
                ExternalEvent.Raise();

            if (resultado != Autodesk.Revit.UI.ExternalEventRequest.Accepted)
            {
                MostrarDespuesSeleccion();
                ActualizarEstado(
                    "Revit no aceptó la solicitud de selección.");
            }
        }

        private void BtnSeleccionarYEjecutar_Click(
            object sender,
            System.EventArgs e)
        {
            if (Handler == null ||
                ExternalEvent == null)
            {
                return;
            }

            if (ExternalEvent.IsPending)
            {
                ActualizarEstado(
                    "Revit todavía está procesando la solicitud anterior.");
                return;
            }

            // Validamos primero los inputs actuales para no hacer perder
            // tiempo seleccionando si falta tipo, espaciamiento, cover, etc.
            AceroMuroConfiguracion configuracionValidacion;
            string error;

            if (!TryObtenerConfiguracion(
                out configuracionValidacion,
                out error))
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    error,
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            // NO guardamos configuracionValidacion como definitiva.
            // Tras seleccionar se vuelve a leer la configuración para que
            // AjustesTramos corresponda a los NUEVOS muros seleccionados.
            Handler.ConfiguracionPendiente = null;
            Handler.Accion =
                AceroMuroAccion.SeleccionarYCrear;

            EstablecerBotonesActivos(false);
            ActualizarEstado(
                "Modo continuo: seleccione una serie y pulse Finalizar para crear. Luego podrá seleccionar otra serie. Esc = terminar.");

            OcultarParaSeleccion();

            Autodesk.Revit.UI.ExternalEventRequest resultado =
                ExternalEvent.Raise();

            if (resultado !=
                Autodesk.Revit.UI.ExternalEventRequest.Accepted)
            {
                MostrarDespuesSeleccion();
                EstablecerBotonesActivos(true);

                ActualizarEstado(
                    "Revit no aceptó la solicitud de selección y ejecución.");
            }
        }

        private void BtnCrear_Click(
            object sender,
            System.EventArgs e)
        {
            if (Handler == null || ExternalEvent == null)
                return;

            if (ExternalEvent.IsPending)
            {
                ActualizarEstado(
                    "Revit todavía está procesando la solicitud anterior.");
                return;
            }

            AceroMuroConfiguracion configuracion;
            string error;

            if (!TryObtenerConfiguracion(
                out configuracion,
                out error))
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    error,
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            Handler.ConfiguracionPendiente = configuracion;
            Handler.Accion = AceroMuroAccion.Crear;

            EstablecerBotonesActivos(false);
            ActualizarEstado(
                "Enviando configuración de acero a Revit...");

            Autodesk.Revit.UI.ExternalEventRequest resultado =
                ExternalEvent.Raise();

            if (resultado != Autodesk.Revit.UI.ExternalEventRequest.Accepted)
            {
                EstablecerBotonesActivos(true);
                ActualizarEstado(
                    "Revit no aceptó la solicitud de creación.");
            }
        }

        public void CargarTiposArmadura(
            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarBarType> tipos)
        {
            tiposArmaduraDisponibles.Clear();

            cmbTipoVertical.Items.Clear();
            cmbTipoHorizontal.Items.Clear();
            cmbGrupoDiametro.Items.Clear();
            cmbRefuerzoHuecosDiametro.Items.Clear();

            cmbTipoVertical.DisplayMember = "Name";
            cmbTipoHorizontal.DisplayMember = "Name";
            cmbGrupoDiametro.DisplayMember = "Name";
            cmbRefuerzoHuecosDiametro.DisplayMember = "Name";

            if (tipos != null)
            {
                foreach (
                    Autodesk.Revit.DB.Structure.RebarBarType tipo
                    in tipos)
                {
                    if (tipo == null)
                        continue;

                    tiposArmaduraDisponibles.Add(
                        tipo);

                    cmbTipoVertical.Items.Add(
                        tipo);

                    cmbTipoHorizontal.Items.Add(
                        tipo);

                    cmbGrupoDiametro.Items.Add(
                        tipo);

                    cmbRefuerzoHuecosDiametro.Items.Add(
                        tipo);
                }
            }

            if (!SeleccionarTipoPorNombre(
                    cmbTipoVertical,
                    ultimoTipoVertical) &&
                cmbTipoVertical.Items.Count > 0)
            {
                cmbTipoVertical.SelectedIndex = 0;
            }

            if (!SeleccionarTipoPorNombre(
                    cmbTipoHorizontal,
                    ultimoTipoHorizontal) &&
                cmbTipoHorizontal.Items.Count > 0)
            {
                cmbTipoHorizontal.SelectedIndex =
                    cmbTipoHorizontal.Items.Count > 1
                        ? 1
                        : 0;
            }

            // El refuerzo de huecos usa un diámetro independiente.
            // Si todavía no hay uno recordado, preferimos el mismo tipo
            // que el último horizontal usado.
            bool seleccionRefuerzo =
                SeleccionarTipoPorNombre(
                    cmbRefuerzoHuecosDiametro,
                    ultimoTipoRefuerzoHuecos);

            if (!seleccionRefuerzo &&
                !string.IsNullOrWhiteSpace(
                    ultimoTipoHorizontal))
            {
                seleccionRefuerzo =
                    SeleccionarTipoPorNombre(
                        cmbRefuerzoHuecosDiametro,
                        ultimoTipoHorizontal);
            }

            if (!seleccionRefuerzo &&
                cmbRefuerzoHuecosDiametro.Items.Count > 0)
            {
                cmbRefuerzoHuecosDiametro.SelectedIndex =
                    cmbTipoHorizontal.SelectedIndex >= 0 &&
                    cmbTipoHorizontal.SelectedIndex <
                        cmbRefuerzoHuecosDiametro.Items.Count
                        ? cmbTipoHorizontal.SelectedIndex
                        : 0;
            }

            AsegurarEmpalmesPorDiametroDisponibles();

            ActualizarPanelGrupoSeleccionado();
        }

        public void CargarTiposGancho(
            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarHookType> tipos)
        {
            tiposGanchoDisponibles.Clear();
            tipoGancho90 = null;
            tipoGancho180 = null;

            if (tipos != null)
            {
                foreach (
                    Autodesk.Revit.DB.Structure.RebarHookType tipo
                    in tipos)
                {
                    if (tipo == null)
                        continue;

                    tiposGanchoDisponibles.Add(
                        tipo);

                    double angulo =
                        ObtenerAnguloGanchoGrados(
                            tipo);

                    if (tipoGancho90 == null &&
                        System.Math.Abs(
                            angulo - 90.0) <= 2.0)
                    {
                        tipoGancho90 =
                            tipo;
                    }

                    if (tipoGancho180 == null &&
                        System.Math.Abs(
                            angulo - 180.0) <= 2.0)
                    {
                        tipoGancho180 =
                            tipo;
                    }
                }
            }

            pnlVistaSeccion.Invalidate();
        }

        private double ObtenerAnguloGanchoGrados(
            Autodesk.Revit.DB.Structure.RebarHookType tipo)
        {
            if (tipo == null)
                return 0.0;

            // Revit ha cambiado algunos miembros de la API de armaduras
            // entre versiones. Usamos reflexión para leer el ángulo sin
            // acoplar el Form a un miembro concreto.
            try
            {
                System.Type t =
                    tipo.GetType();

                string[] propiedades =
                {
                "HookAngle",
                "Angle",
                "HookAngleRadians"
            };

                foreach (
                    string nombre
                    in propiedades)
                {
                    System.Reflection.PropertyInfo prop =
                        t.GetProperty(
                            nombre,
                            System.Reflection.BindingFlags.Public |
                            System.Reflection.BindingFlags.Instance);

                    if (prop == null)
                        continue;

                    object valorObj =
                        prop.GetValue(
                            tipo,
                            null);

                    if (valorObj == null)
                        continue;

                    double valor =
                        System.Convert.ToDouble(
                            valorObj,
                            System.Globalization.CultureInfo.InvariantCulture);

                    // Si viene en radianes.
                    if (System.Math.Abs(valor) <=
                        System.Math.PI * 2.0 + 0.01)
                    {
                        valor =
                            valor *
                            180.0 /
                            System.Math.PI;
                    }

                    if (valor > 1.0)
                        return valor;
                }
            }
            catch
            {
            }

            // Respaldo robusto: nombres habituales de Revit.
            string nombreTipo =
                tipo.Name ?? "";

            System.Text.RegularExpressions.Match match =
                System.Text.RegularExpressions.Regex.Match(
                    nombreTipo,
                    @"(?<!\d)(90|180)(?!\d)",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            if (match.Success)
            {
                double valor;

                if (double.TryParse(
                    match.Groups[1].Value,
                    out valor))
                {
                    return valor;
                }
            }

            return 0.0;
        }

        private Autodesk.Revit.DB.Structure.RebarHookType
            ObtenerTipoGanchoPorAngulo(
                int angulo)
        {
            if (angulo == 90)
                return tipoGancho90;

            if (angulo == 180)
                return tipoGancho180;

            return null;
        }

        public void CargarRecubrimientos(
            System.Collections.Generic.List<
                Autodesk.Revit.DB.Structure.RebarCoverType> tipos)
        {
            if (cmbRecubrimiento == null)
                return;

            string ultimoTexto =
                ultimoRecubrimientoTexto ?? "";

            cmbRecubrimiento.BeginUpdate();

            try
            {
                cmbRecubrimiento.Items.Clear();
                recubrimientosRevitPorTexto.Clear();

                System.Collections.Generic.HashSet<long> ids =
                    new System.Collections.Generic.HashSet<long>();

                string textoMasCercano4Cm = "";
                double mejorDistancia4Cm =
                    double.MaxValue;

                if (tipos != null)
                {
                    foreach (
                        Autodesk.Revit.DB.Structure.RebarCoverType tipo
                        in tipos)
                    {
                        if (tipo == null)
                            continue;

                        if (!ids.Add(
                            tipo.Id.Value))
                        {
                            continue;
                        }

                        double mm =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    tipo.CoverDistance,
                                    Autodesk.Revit.DB.UnitTypeId.Millimeters);

                        double cm =
                            mm / 10.0;

                        // Mismo concepto de la ventana de Revit:
                        // Descripción | Parámetro.
                        //
                        // Ejemplo:
                        // COLUMNAS Y VIGAS 4CM   |   40.0 mm
                        string texto =
                            (tipo.Name ?? "").Trim() +
                            "   |   " +
                            mm.ToString("0.0") +
                            " mm";

                        // Items = STRING.
                        // Esto evita definitivamente el desplegable en blanco.
                        cmbRecubrimiento.Items.Add(
                            texto);

                        recubrimientosRevitPorTexto[
                            texto] =
                            tipo;

                        double diferencia =
                            System.Math.Abs(
                                cm - 4.0);

                        if (diferencia <
                            mejorDistancia4Cm)
                        {
                            mejorDistancia4Cm =
                                diferencia;

                            textoMasCercano4Cm =
                                texto;
                        }
                    }
                }

                // ---------------------------------------------
                // RESTAURAR ÚLTIMO INPUT
                // ---------------------------------------------
                bool restaurado = false;

                if (!string.IsNullOrWhiteSpace(
                    ultimoTexto))
                {
                    // 1) Coincidencia exacta de lo guardado.
                    foreach (
                        object obj
                        in cmbRecubrimiento.Items)
                    {
                        string item =
                            obj != null
                                ? obj.ToString()
                                : "";

                        if (string.Equals(
                            item,
                            ultimoTexto,
                            System.StringComparison.OrdinalIgnoreCase))
                        {
                            cmbRecubrimiento.SelectedItem =
                                obj;

                            restaurado = true;
                            break;
                        }
                    }

                    // 2) Si antes guardamos solamente el nombre del cover,
                    // buscamos por el texto anterior a "|".
                    if (!restaurado)
                    {
                        foreach (
                            object obj
                            in cmbRecubrimiento.Items)
                        {
                            string item =
                                obj != null
                                    ? obj.ToString()
                                    : "";

                            string descripcion =
                                item.Split('|')[0]
                                    .Trim();

                            if (string.Equals(
                                descripcion,
                                ultimoTexto.Trim(),
                                System.StringComparison.OrdinalIgnoreCase))
                            {
                                cmbRecubrimiento.SelectedItem =
                                    obj;

                                restaurado = true;
                                break;
                            }
                        }
                    }
                }

                if (!restaurado)
                {
                    if (!string.IsNullOrWhiteSpace(
                        textoMasCercano4Cm))
                    {
                        cmbRecubrimiento.SelectedItem =
                            textoMasCercano4Cm;
                    }
                    else if (cmbRecubrimiento.Items.Count > 0)
                    {
                        cmbRecubrimiento.SelectedIndex =
                            0;
                    }
                    else
                    {
                        // Solo como respaldo si el documento realmente
                        // no tuviera ningún RebarCoverType.
                        cmbRecubrimiento.Text =
                            "4 cm";
                    }
                }
            }
            finally
            {
                cmbRecubrimiento.EndUpdate();

                // Estado base para detectar el siguiente cambio real.
                double recActual =
                    ObtenerRecubrimientoCmActual();

                if (recActual >= 0.0)
                {
                    ultimoRecubrimientoGuiasVerticalesCm =
                        recActual;
                }
            }
        }

        private bool SeleccionarTipoPorNombre(
            System.Windows.Forms.ComboBox combo,
            string nombre)
        {
            if (combo == null ||
                string.IsNullOrWhiteSpace(nombre))
            {
                return false;
            }

            foreach (object item in combo.Items)
            {
                Autodesk.Revit.DB.Structure.RebarBarType tipo =
                    item as Autodesk.Revit.DB.Structure.RebarBarType;

                if (tipo != null &&
                    string.Equals(
                        tipo.Name,
                        nombre,
                        System.StringComparison.OrdinalIgnoreCase))
                {
                    combo.SelectedItem = item;
                    return true;
                }
            }

            combo.Text = nombre;
            return false;
        }

        private Autodesk.Revit.DB.Structure.RebarBarType
            ResolverTipoBarra(
                System.Windows.Forms.ComboBox combo)
        {
            if (combo == null)
                return null;

            Autodesk.Revit.DB.Structure.RebarBarType seleccionado =
                combo.SelectedItem as
                Autodesk.Revit.DB.Structure.RebarBarType;

            if (seleccionado != null &&
                string.Equals(
                    seleccionado.Name,
                    combo.Text.Trim(),
                    System.StringComparison.OrdinalIgnoreCase))
            {
                return seleccionado;
            }

            foreach (object item in combo.Items)
            {
                Autodesk.Revit.DB.Structure.RebarBarType tipo =
                    item as Autodesk.Revit.DB.Structure.RebarBarType;

                if (tipo != null &&
                    string.Equals(
                        tipo.Name,
                        combo.Text.Trim(),
                        System.StringComparison.OrdinalIgnoreCase))
                {
                    return tipo;
                }
            }

            return null;
        }

        private bool TryLeerLongitudCm(
            string texto,
            out double valorCm)
        {
            valorCm = 0.0;

            if (string.IsNullOrWhiteSpace(texto))
                return false;

            string limpio =
                texto.Trim()
                    .ToLowerInvariant()
                    .Replace(',', '.');

            double factor = 1.0;

            if (limpio.EndsWith("mm"))
            {
                factor = 0.1;
                limpio = limpio.Substring(
                    0,
                    limpio.Length - 2).Trim();
            }
            else if (limpio.EndsWith("cm"))
            {
                factor = 1.0;
                limpio = limpio.Substring(
                    0,
                    limpio.Length - 2).Trim();
            }
            else if (limpio.EndsWith("in"))
            {
                factor = 2.54;
                limpio = limpio.Substring(
                    0,
                    limpio.Length - 2).Trim();
            }
            else if (limpio.EndsWith("\""))
            {
                factor = 2.54;
                limpio = limpio.Substring(
                    0,
                    limpio.Length - 1).Trim();
            }
            else if (limpio.EndsWith("m"))
            {
                factor = 100.0;
                limpio = limpio.Substring(
                    0,
                    limpio.Length - 1).Trim();
            }

            double numero;

            if (!double.TryParse(
                limpio,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out numero))
            {
                return false;
            }

            valorCm = numero * factor;
            return true;
        }

        private bool TryObtenerRecubrimientoCm(
            out double valorCm)
        {
            valorCm = 0.0;

            if (cmbRecubrimiento == null)
                return false;

            string texto =
                (cmbRecubrimiento.Text ?? "")
                    .Trim();

            if (string.IsNullOrWhiteSpace(
                texto))
            {
                return false;
            }

            // -----------------------------------------------------
            // 1) Coincidencia directa con uno de los recubrimientos
            //    configurados en Revit.
            // -----------------------------------------------------
            Autodesk.Revit.DB.Structure.RebarCoverType tipo;

            if (recubrimientosRevitPorTexto.TryGetValue(
                texto,
                out tipo))
            {
                valorCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            tipo.CoverDistance,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                return true;
            }

            // -----------------------------------------------------
            // 2) Si el usuario escribió solo la DESCRIPCIÓN
            //    (ej. "PLACAS 4CM"), encontrar ese cover.
            // -----------------------------------------------------
            foreach (
                System.Collections.Generic.KeyValuePair<
                    string,
                    Autodesk.Revit.DB.Structure.RebarCoverType> kv
                in recubrimientosRevitPorTexto)
            {
                string descripcion =
                    kv.Key.Split('|')[0]
                        .Trim();

                if (string.Equals(
                    descripcion,
                    texto,
                    System.StringComparison.OrdinalIgnoreCase))
                {
                    valorCm =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertFromInternalUnits(
                                kv.Value.CoverDistance,
                                Autodesk.Revit.DB.UnitTypeId.Centimeters);

                    return true;
                }
            }

            // -----------------------------------------------------
            // 3) Sigue siendo editable:
            //    4
            //    4 cm
            //    40 mm
            //    1.5"
            // -----------------------------------------------------
            return TryLeerLongitudCm(
                texto,
                out valorCm);
        }

        private double ObtenerRecubrimientoCmActual()
        {
            double cm;
            return TryObtenerRecubrimientoCm(out cm)
                ? cm
                : 4.0;
        }

        private double ObtenerEspVerticalCmActual()
        {
            double cm;
            return TryLeerLongitudCm(
                txtEspVertical != null
                    ? txtEspVertical.Text
                    : "20",
                out cm)
                ? cm
                : 20.0;
        }

        private double ObtenerEspHorizontalCmActual()
        {
            double cm;
            return TryLeerLongitudCm(
                txtEspHorizontal != null
                    ? txtEspHorizontal.Text
                    : "20",
                out cm)
                ? cm
                : 20.0;
        }

        private string NormalizarTextoMalla(
            string texto)
        {
            if (!string.IsNullOrWhiteSpace(texto) &&
                (texto.IndexOf(
                    "Una malla",
                    System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                 texto.IndexOf(
                    "centrada",
                    System.StringComparison.OrdinalIgnoreCase) >= 0))
            {
                return "Una malla (centrada)";
            }

            return "Doble malla";
        }

        private int ObtenerModoCarasActual()
        {
            string texto =
                cmbCaras != null
                    ? cmbCaras.Text.Trim()
                    : "";

            // 3 = una sola malla en el EJE del muro.
            if (texto.IndexOf(
                    "Una malla",
                    System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                texto.IndexOf(
                    "centrada",
                    System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return 3;
            }

            // Cualquier valor anterior (Ambas caras / Cara A / Cara B)
            // se migra de forma segura a DOBLE MALLA.
            return 0;
        }

        private void GuardarValoresRecordados()
        {
            if (cmbTipoVertical != null)
                ultimoTipoVertical = cmbTipoVertical.Text.Trim();

            if (cmbTipoHorizontal != null)
                ultimoTipoHorizontal = cmbTipoHorizontal.Text.Trim();

            if (cmbRecubrimiento != null)
                ultimoRecubrimientoTexto = cmbRecubrimiento.Text.Trim();

            if (txtEspVertical != null)
                ultimoEspVerticalTexto = txtEspVertical.Text.Trim();

            if (txtEspHorizontal != null)
                ultimoEspHorizontalTexto = txtEspHorizontal.Text.Trim();

            if (cmbCaras != null)
                ultimoCarasTexto = cmbCaras.Text.Trim();

            if (chkVerticales != null)
                ultimoCrearVertical = chkVerticales.Checked;

            if (chkHorizontales != null)
                ultimoCrearHorizontal = chkHorizontales.Checked;

            if (chkContinuos != null)
                ultimoContinuos = chkContinuos.Checked;

            if (chkConsiderarEmpalme != null)
                ultimoConsiderarEmpalme =
                    chkConsiderarEmpalme.Checked;

            if (txtLongitudComercial != null)
                ultimaLongitudComercialTexto =
                    txtLongitudComercial.Text.Trim();

            if (chkRefuerzoHuecos != null)
                ultimoCrearRefuerzoHuecos =
                    chkRefuerzoHuecos.Checked;

            if (cmbRefuerzoHuecosDiametro != null)
                ultimoTipoRefuerzoHuecos =
                    cmbRefuerzoHuecosDiametro.Text.Trim();

            if (txtLongitudRefuerzoHuecos != null)
                ultimaLongitudRefuerzoHuecosTexto =
                    txtLongitudRefuerzoHuecos.Text.Trim();

            ultimosEmpalmesPorDiametro.Clear();

            foreach (
                AceroMuroEmpalmeDiametroData item
                in empalmesPorDiametro)
            {
                if (item != null)
                    ultimosEmpalmesPorDiametro.Add(
                        item.Copiar());
            }

            if (chkVerSinTapar != null)
                ultimoVerSinTapar = chkVerSinTapar.Checked;

            ultimoGanchoInferior =
                anguloGanchoInferior;

            ultimoGanchoSuperior =
                anguloGanchoSuperior;

            ultimoGanchoInferiorManual =
                chkLongGanchoInfManual != null &&
                chkLongGanchoInfManual.Checked;

            ultimoGanchoSuperiorManual =
                chkLongGanchoSupManual != null &&
                chkLongGanchoSupManual.Checked;

            ultimoLongGanchoInferiorTexto =
                txtLongGanchoInf != null
                    ? txtLongGanchoInf.Text.Trim()
                    : "";

            ultimoLongGanchoSuperiorTexto =
                txtLongGanchoSup != null
                    ? txtLongGanchoSup.Text.Trim()
                    : "";
        }

        private bool TryLeerLongitudComercialCm(
            string texto,
            out double cm)
        {
            cm = 0.0;

            string valor =
                (texto ?? "").Trim();

            if (string.IsNullOrWhiteSpace(
                valor))
            {
                return false;
            }

            // =====================================================
            // V8.78 - PARSER DECIMAL INDEPENDIENTE DE LA REGIÓN
            //
            // PROBLEMA ANTERIOR:
            // En Windows/Revit con cultura es-PE, "." puede ser
            // separador de miles. Con NumberStyles.Any:
            //
            // 1.5 -> podía interpretarse como 15
            // 9.0 -> podía interpretarse como 90
            //
            // y la segunda lectura InvariantCulture nunca se ejecutaba
            // porque CurrentCulture devolvía "éxito".
            //
            // SOLUCIÓN:
            // - "." y "," se aceptan SIEMPRE como separador decimal;
            // - NO se permiten separadores de miles;
            // - internamente se normaliza todo a ".";
            // - se usa InvariantCulture + NumberStyles.Float.
            // =====================================================

            // Si el usuario escribió una unidad explícita,
            // reutilizamos TryLeerLongitudCm(), que ya normaliza
            // coma -> punto y usa InvariantCulture.
            bool tieneUnidad =
                valor.IndexOf(
                    "mm",
                    System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                valor.IndexOf(
                    "cm",
                    System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                valor.IndexOf(
                    "m",
                    System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                valor.Contains("\"") ||
                valor.Contains("'");

            if (tieneUnidad)
            {
                return
                    TryLeerLongitudCm(
                        valor,
                        out cm);
            }

            // Sin unidad, este input se interpreta en METROS.
            //
            // Válidos:
            // 9
            // 9.0
            // 9,0
            // 1.5
            // 1,5
            string normalizado =
                valor
                    .Replace(
                        ",",
                        ".")
                    .Trim();

            // Evitar valores ambiguos como "1.2.3".
            int cantidadPuntos =
                normalizado.Count(
                    c =>
                        c == '.');

            if (cantidadPuntos > 1)
            {
                return false;
            }

            double metros;

            if (!double.TryParse(
                    normalizado,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out metros))
            {
                return false;
            }

            if (double.IsNaN(
                    metros) ||
                double.IsInfinity(
                    metros) ||
                metros <= 0.0)
            {
                return false;
            }

            cm =
                metros * 100.0;

            return true;
        }


        internal bool TryObtenerConfiguracion(
            out AceroMuroConfiguracion configuracion,
            out string error)
        {
            configuracion = null;
            error = "";

            if (!chkVerticales.Checked &&
                !chkHorizontales.Checked)
            {
                error =
                    "Active al menos ACERO VERTICAL o ACERO HORIZONTAL.";
                return false;
            }

            // Tipos globales ocultos: solo fallback para datos antiguos.
            Autodesk.Revit.DB.Structure.RebarBarType tipoVertical =
                ResolverTipoBarra(
                    cmbTipoVertical);

            Autodesk.Revit.DB.Structure.RebarBarType tipoHorizontal =
                ResolverTipoBarra(
                    cmbTipoHorizontal);

            double recubrimientoCm;

            if (!TryObtenerRecubrimientoCm(
                    out recubrimientoCm) ||
                recubrimientoCm < 0.0)
            {
                error =
                    "Seleccione un recubrimiento del proyecto o escriba una longitud válida, por ejemplo 4 cm.";
                return false;
            }

            // Ya no se validan espaciamientos globales visibles.
            // Cada grupo H/V tiene su propia Regla + Diámetro + Valor.
            double espVerticalCm =
                ObtenerEspVerticalCmActual();

            double espHorizontalCm =
                ObtenerEspHorizontalCmActual();

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                Autodesk.Revit.DB.Structure.RebarBarType tipoGrupo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoVertical);

                if (tipoGrupo == null)
                {
                    error =
                        "Hay un grupo VERTICAL sin diámetro/tipo de barra válido. Selecciónelo y pulse APLICAR CAMBIOS.";
                    return false;
                }
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                Autodesk.Revit.DB.Structure.RebarBarType tipoGrupo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoHorizontal);

                if (tipoGrupo == null)
                {
                    error =
                        "Hay un grupo HORIZONTAL sin diámetro/tipo de barra válido. Selecciónelo y pulse APLICAR CAMBIOS.";
                    return false;
                }
            }

            bool considerarEmpalme =
                chkHorizontales.Checked &&
                chkConsiderarEmpalme != null &&
                chkConsiderarEmpalme.Checked;

            double longitudComercialCm =
                0.0;

            if (considerarEmpalme)
            {
                if (txtLongitudComercial == null ||
                    !TryLeerLongitudComercialCm(
                        txtLongitudComercial.Text,
                        out longitudComercialCm) ||
                    longitudComercialCm <= 0.0)
                {
                    error =
                        "La longitud comercial no es válida. Ejemplos: 9, 12, 9 m o 1200 cm.";
                    return false;
                }

                // Protección mínima para evitar piezas absurdamente cortas.
                if (longitudComercialCm < 100.0)
                {
                    error =
                        "La longitud comercial debe ser al menos 1.00 m.";
                    return false;
                }
            }

            // =====================================================
            // V8.77 - REFUERZO DIAGONAL DE HUECOS
            // =====================================================
            bool crearRefuerzoHuecos =
                chkRefuerzoHuecos != null &&
                chkRefuerzoHuecos.Checked;

            Autodesk.Revit.DB.Structure.RebarBarType tipoRefuerzoHuecos =
                null;

            double longitudRefuerzoHuecosCm =
                0.0;

            if (crearRefuerzoHuecos)
            {
                tipoRefuerzoHuecos =
                    ResolverTipoBarra(
                        cmbRefuerzoHuecosDiametro);

                if (tipoRefuerzoHuecos == null)
                {
                    error =
                        "Seleccione un diámetro válido para el refuerzo diagonal de huecos.";
                    return false;
                }

                if (txtLongitudRefuerzoHuecos == null ||
                    !TryLeerLongitudComercialCm(
                        txtLongitudRefuerzoHuecos.Text,
                        out longitudRefuerzoHuecosCm) ||
                    longitudRefuerzoHuecosCm <= 0.0)
                {
                    error =
                        "La longitud de la varilla diagonal no es válida. Ejemplos: 0.65, 65 cm o 650 mm.";
                    return false;
                }

                if (longitudRefuerzoHuecosCm <
                    20.0)
                {
                    error =
                        "La longitud de la varilla diagonal debe ser al menos 0.20 m.";
                    return false;
                }
            }

            int modoCaras =
                ObtenerModoCarasActual();

            Autodesk.Revit.DB.Structure.RebarHookType ganchoInferior =
                ObtenerTipoGanchoPorAngulo(
                    anguloGanchoInferior);

            Autodesk.Revit.DB.Structure.RebarHookType ganchoSuperior =
                ObtenerTipoGanchoPorAngulo(
                    anguloGanchoSuperior);

            if (chkVerticales.Checked &&
                anguloGanchoInferior != 0 &&
                ganchoInferior == null)
            {
                error =
                    "No se encontró un RebarHookType de " +
                    anguloGanchoInferior +
                    "° en el proyecto. Cree/cargue ese tipo de gancho en Revit.";

                return false;
            }

            if (chkVerticales.Checked &&
                anguloGanchoSuperior != 0 &&
                ganchoSuperior == null)
            {
                error =
                    "No se encontró un RebarHookType de " +
                    anguloGanchoSuperior +
                    "° en el proyecto. Cree/cargue ese tipo de gancho en Revit.";

                return false;
            }

            bool manualGanchoInferior =
                chkLongGanchoInfManual != null &&
                chkLongGanchoInfManual.Checked;

            bool manualGanchoSuperior =
                chkLongGanchoSupManual != null &&
                chkLongGanchoSupManual.Checked;

            double longitudGanchoInferiorCm =
                0.0;

            double longitudGanchoSuperiorCm =
                0.0;

            if (manualGanchoInferior)
            {
                if (anguloGanchoInferior == 0)
                {
                    error =
                        "Active primero un gancho inferior de 90° o 180°.";
                    return false;
                }

                if (txtLongGanchoInf == null ||
                    !TryLeerLongitudCm(
                        txtLongGanchoInf.Text,
                        out longitudGanchoInferiorCm) ||
                    longitudGanchoInferiorCm <= 0.0)
                {
                    error =
                        "La longitud manual del gancho inferior no es válida. Ejemplo: 10 cm.";
                    return false;
                }
            }

            if (manualGanchoSuperior)
            {
                if (anguloGanchoSuperior == 0)
                {
                    error =
                        "Active primero un gancho superior de 90° o 180°.";
                    return false;
                }

                if (txtLongGanchoSup == null ||
                    !TryLeerLongitudCm(
                        txtLongGanchoSup.Text,
                        out longitudGanchoSuperiorCm) ||
                    longitudGanchoSuperiorCm <= 0.0)
                {
                    error =
                        "La longitud manual del gancho superior no es válida. Ejemplo: 10 cm.";
                    return false;
                }
            }

            // Sincronización final de constraints 2P antes de ejecutar.
            ActualizarGruposVinculadosAGuiasSeccion();
            ActualizarGruposVerticalesVinculadosAGuias();

            configuracion = new AceroMuroConfiguracion
            {
                TipoVertical = tipoVertical,
                TipoHorizontal = tipoHorizontal,
                CrearVerticales = chkVerticales.Checked,
                CrearHorizontales = chkHorizontales.Checked,
                RecubrimientoCm = recubrimientoCm,
                EspaciamientoVerticalCm = espVerticalCm,
                EspaciamientoHorizontalCm = espHorizontalCm,
                ModoCaras = modoCaras,
                HorizontalesContinuosPorCadena =
                    chkContinuos.Checked,

                CrearRefuerzoHuecos =
                    crearRefuerzoHuecos,
                TipoRefuerzoHuecos =
                    tipoRefuerzoHuecos,
                LongitudRefuerzoHuecosCm =
                    longitudRefuerzoHuecosCm,

                ConsiderarEmpalmeHorizontal =
                    considerarEmpalme,
                LongitudComercialCm =
                    longitudComercialCm,
                VerElementosSinTapar =
                    chkVerSinTapar != null &&
                    chkVerSinTapar.Checked,
                UsarDisenoManual = true,
                AjusteCaraACm =
                    ajusteSeccionIzquierdaCm,
                AjusteCaraBCm =
                    ajusteSeccionDerechaCm,
                AjusteInferiorCm =
                    ajusteSeccionInferiorCm,
                AjusteSuperiorCm =
                    ajusteSeccionSuperiorCm,
                AnguloGanchoInferior =
                    anguloGanchoInferior,
                AnguloGanchoSuperior =
                    anguloGanchoSuperior,
                GanchoInferior =
                    ganchoInferior,
                GanchoSuperior =
                    ganchoSuperior,
                LongitudGanchoInferiorManual =
                    manualGanchoInferior,
                LongitudGanchoSuperiorManual =
                    manualGanchoSuperior,
                LongitudGanchoInferiorCm =
                    longitudGanchoInferiorCm,
                LongitudGanchoSuperiorCm =
                    longitudGanchoSuperiorCm
            };

            AsegurarEmpalmesPorDiametroDisponibles();

            foreach (
                AceroMuroEmpalmeDiametroData item
                in empalmesPorDiametro)
            {
                if (item != null)
                    configuracion.EmpalmesPorDiametro.Add(
                        item.Copiar());
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo != null)
                    configuracion.GruposHorizontales2Puntos.Add(
                        grupo.Copiar());
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo != null)
                    configuracion.GruposVerticales2Puntos.Add(
                        grupo.Copiar());
            }

            if (vistaElevacionActual != null &&
                vistaElevacionActual.Tramos != null)
            {
                foreach (
                    AceroMuroTramoVista tramo
                    in vistaElevacionActual.Tramos)
                {
                    configuracion.AjustesTramos.Add(
                        new AceroMuroAjusteTramo
                        {
                            MuroId =
                                tramo.MuroId,
                            RetiroInicioCm =
                                ObtenerAjusteInicioTramoCm(
                                    tramo.MuroId),
                            RetiroFinCm =
                                ObtenerAjusteFinTramoCm(
                                    tramo.MuroId)
                        });
                }
            }

            GuardarValoresRecordados();
            return true;
        }

        internal void ActualizarSeleccion(
            AceroMuroVistaElevacion vista,
            AceroMuroVistaSeccion vistaSeccion,
            System.Collections.Generic.List<string> descripciones,
            int cantidad)
        {
            if (IsDisposed)
                return;

            if (InvokeRequired)
            {
                BeginInvoke(new System.Action(() =>
                    ActualizarSeleccion(
                        vista,
                        vistaSeccion,
                        descripciones,
                        cantidad)));

                return;
            }

            FinalizarEditorCotaDesarrolloHorizontal(
                false);

            // V8.71:
            // antes de cambiar de 2 muros a 1, de 1 a 3, etc.,
            // capturamos la longitud REAL de los dos extremos actuales.
            CapturarDesarrollosHorizontalesActuales();

            vistaElevacionActual = vista;
            vistaSeccionActual = vistaSeccion;

            lblCantidad.Text =
                "Muros seleccionados: " + cantidad;

            lblCadenas.Text =
                "Cadenas continuas: " +
                (vista != null
                    ? vista.CantidadCadenas
                    : 0);

            lstMuros.Items.Clear();

            if (descripciones != null)
            {
                foreach (string descripcion in descripciones)
                    lstMuros.Items.Add(descripcion);
            }

            zoomVista = 1.0;
            panX = 0;
            panY = 0;

            ajusteInicioTramoCm.Clear();
            ajusteFinTramoCm.Clear();

            ajusteSeccionIzquierdaCm = 0.0;
            ajusteSeccionDerechaCm = 0.0;
            ajusteSeccionInferiorCm = 0.0;
            ajusteSeccionSuperiorCm = 0.0;

            gruposHorizontales2Puntos.Clear();
            grupoHorizontal2PSeleccionadoId = "";
            creandoHorizontalDosPuntos = false;
            arrastrandoExtremoHorizontal2P = false;

            tramoSeleccionadoId = 0;
            seccionHandleSeleccionado = "";

            pilaDeshacer.Clear();
            pilaRehacer.Clear();

            // Si hay una Data cargada, se aplica por índice a la nueva serie.
            // Después, los candados recalculan la posición usando los
            // elementos extremos REALES de esta nueva selección.
            if (dataCargadaActiva != null)
            {
                AplicarDataGuardadaControles(
                    dataCargadaActiva);

                AplicarDataGuardadaASeleccionActual(
                    dataCargadaActiva);
            }
            else
            {
                AplicarBloqueosATodasCadenas();
            }

            // Después de reconstruir la nueva selección, trasladar H-INICIO
            // y H-FIN al primer/último muro actual.
            //
            // Los candados continúan teniendo prioridad.
            AplicarDesarrollosHorizontalesRecordadosASeleccion();

            CambiarHerramientaAlzado(
                AceroMuroHerramientaEdicion.SeleccionarMover);

            CambiarHerramientaSeccion(
                AceroMuroHerramientaEdicion.SeleccionarMover);

            pnlVistaAlzado.Invalidate();
            pnlVistaSeccion.Invalidate();

            if (tabVistas != null)
                tabVistas.SelectedIndex = 0;

            if (vista != null &&
                vista.Avisos != null &&
                vista.Avisos.Count > 0)
            {
                ActualizarEstado(
                    "Selección completada. " +
                    vista.Avisos[0]);
            }
            else
            {
                ActualizarEstado(
                    cantidad > 0
                        ? "Selección completada. Revise primero la SECCIÓN DEL MURO; el alzado longitudinal queda en la segunda pestaña."
                        : "No se seleccionaron muros.");
            }
        }

        public void ActualizarEstado(string texto)
        {
            if (IsDisposed)
                return;

            if (InvokeRequired)
            {
                BeginInvoke(
                    new System.Action(
                        () => ActualizarEstado(texto)));

                return;
            }

            lblEstado.Text = texto ?? "";
        }

        public void OcultarParaSeleccion()
        {
            if (IsDisposed)
                return;

            TopMost = false;
            Hide();
        }

        public void MostrarDespuesSeleccion()
        {
            if (IsDisposed)
                return;

            if (InvokeRequired)
            {
                BeginInvoke(
                    new System.Action(
                        MostrarDespuesSeleccion));

                return;
            }

            Show();
            TopMost = true;
            BringToFront();
            Activate();
        }

        public void EstablecerBotonesActivos(bool activos)
        {
            if (IsDisposed)
                return;

            if (InvokeRequired)
            {
                BeginInvoke(
                    new System.Action(
                        () => EstablecerBotonesActivos(activos)));

                return;
            }

            btnSeleccionar.Enabled = activos;

            if (btnSeleccionarYEjecutar != null)
                btnSeleccionarYEjecutar.Enabled = activos;

            btnCrear.Enabled = activos;
        }

        private void PnlVista_MouseWheel(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            double factor =
                e.Delta > 0 ? 1.15 : 1.0 / 1.15;

            zoomVista *= factor;
            zoomVista =
                System.Math.Max(
                    0.35,
                    System.Math.Min(8.0, zoomVista));

            pnlVistaAlzado.Invalidate();
        }

        private void PnlVista_MouseDown(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button ==
                System.Windows.Forms.MouseButtons.Middle)
            {
                paneando = true;
                ultimoMouse = e.Location;
                pnlVistaAlzado.Cursor =
                    System.Windows.Forms.Cursors.Hand;
                return;
            }

            if (e.Button !=
                System.Windows.Forms.MouseButtons.Left)
            {
                return;
            }

            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return;
            }

            // -----------------------------------------------------
            // V8.70 - COTA INLINE DE DESARROLLO HORIZONTAL
            //
            // Tiene prioridad sobre candados, selección y arrastre.
            // Al hacer clic en "0.80 m", por ejemplo, se edita en la
            // propia vista previa sin abrir una ventana emergente.
            // -----------------------------------------------------
            foreach (
                System.Collections.Generic.KeyValuePair<
                    long,
                    System.Drawing.RectangleF> kv
                in rectCotaDesarrolloInicioPorMuro)
            {
                if (!kv.Value.Contains(
                        e.Location))
                {
                    continue;
                }

                if (bloqueoHorizontalInicio !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
                {
                    ActualizarEstado(
                        "El INICIO está bloqueado. Desbloquee el candado para editar la longitud de desarrollo.");

                    return;
                }

                IniciarEditorCotaDesarrolloHorizontal(
                    kv.Key,
                    true,
                    kv.Value);

                return;
            }

            foreach (
                System.Collections.Generic.KeyValuePair<
                    long,
                    System.Drawing.RectangleF> kv
                in rectCotaDesarrolloFinPorMuro)
            {
                if (!kv.Value.Contains(
                        e.Location))
                {
                    continue;
                }

                if (bloqueoHorizontalFin !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
                {
                    ActualizarEstado(
                        "El FIN está bloqueado. Desbloquee el candado para editar la longitud de desarrollo.");

                    return;
                }

                IniciarEditorCotaDesarrolloHorizontal(
                    kv.Key,
                    false,
                    kv.Value);

                return;
            }

            // El candado inline tiene prioridad sobre la selección/drag.
            if (ProcesarClickCandadoInline(
                e.Location))
            {
                return;
            }

            AceroMuroTramoVista tramoBajoCursor =
                ObtenerTramoBajoCursorAlzado(
                    e.Location);

            if (tramoBajoCursor != null)
            {
                tramoSeleccionadoId =
                    tramoBajoCursor.MuroId;
            }

            if (herramientaAlzado ==
                AceroMuroHerramientaEdicion.MoverDosPuntos)
            {
                if (tramoSeleccionadoId == 0)
                {
                    ActualizarAyudasHerramientas();
                    return;
                }

                double xModelo =
                    AplicarOsnapAlzado(
                        ModeloXAlzadoDesdePantalla(
                            e.X));

                if (faseMoverDosPuntosAlzado == 0)
                {
                    puntoBaseMoverDosPuntosAlzado =
                        xModelo;

                    faseMoverDosPuntosAlzado = 1;
                    ActualizarAyudasHerramientas();
                    return;
                }

                RegistrarDeshacer();

                AplicarMoverDosPuntosAlTramo(
                    tramoSeleccionadoId,
                    xModelo -
                    puntoBaseMoverDosPuntosAlzado);

                faseMoverDosPuntosAlzado = 0;

                CambiarHerramientaAlzado(
                    AceroMuroHerramientaEdicion.SeleccionarMover);

                return;
            }

            if (herramientaAlzado ==
                AceroMuroHerramientaEdicion.CopiarDosPuntos)
            {
                if (tramoSeleccionadoId == 0)
                {
                    ActualizarAyudasHerramientas();
                    return;
                }

                double xModelo =
                    AplicarOsnapAlzado(
                        ModeloXAlzadoDesdePantalla(
                            e.X));

                if (faseCopiarDosPuntosAlzado == 0)
                {
                    puntoBaseCopiarDosPuntosAlzado =
                        xModelo;

                    faseCopiarDosPuntosAlzado = 1;
                    ActualizarAyudasHerramientas();
                    return;
                }

                AceroMuroTramoVista destino =
                    ObtenerTramoMasCercanoX(
                        xModelo);

                if (destino != null &&
                    destino.MuroId !=
                        tramoSeleccionadoId)
                {
                    RegistrarDeshacer();

                    CopiarAjusteTramo(
                        tramoSeleccionadoId,
                        destino.MuroId);

                    tramoSeleccionadoId =
                        destino.MuroId;
                }

                faseCopiarDosPuntosAlzado = 0;

                CambiarHerramientaAlzado(
                    AceroMuroHerramientaEdicion.SeleccionarMover);

                return;
            }

            // -----------------------------------------------------
            // SELECCIONAR / ARRASTRAR:
            // ESTOS HANDLES REPRESENTAN EXCLUSIVAMENTE HORIZONTALES.
            // -----------------------------------------------------
            const double toleranciaPx = 11.0;

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                bool mostrarInicio =
                    DebeMostrarHandleHorizontalInicio(
                        tramo);

                bool mostrarFin =
                    DebeMostrarHandleHorizontalFin(
                        tramo);

                float yPx =
                    ObtenerYHandleHorizontal(
                        tramo);

                if (mostrarInicio)
                {
                    float xInicioPx =
                        PantallaXAlzado(
                            ObtenerXInicioEditableTramo(
                                tramo));

                    if (Distancia2D_Px(
                            e.X,
                            e.Y,
                            xInicioPx,
                            yPx) <= toleranciaPx)
                    {
                        if (bloqueoHorizontalInicio !=
                            AceroMuroTipoBloqueoExtremo.Ninguno &&
                            DebeMostrarHandleHorizontalInicio(tramo))
                        {
                            ActualizarEstado(
                                "El INICIO está bloqueado. Haga clic en el candado de la vista previa para desbloquearlo.");

                            return;
                        }

                        RegistrarDeshacer();

                        arrastrandoHandleAlzado = true;
                        tramoDragId =
                            tramo.MuroId;
                        tramoDragEsInicio = true;
                        tramoSeleccionadoId =
                            tramo.MuroId;

                        // Capture permite seguir recibiendo MouseMove aunque
                        // el cursor salga del panel mientras se mantiene pulsado.
                        pnlVistaAlzado.Capture = true;

                        pnlVistaAlzado.Cursor =
                            System.Windows.Forms.Cursors.SizeWE;

                        pnlVistaAlzado.Invalidate();
                        return;
                    }
                }

                if (mostrarFin)
                {
                    float xFinPx =
                        PantallaXAlzado(
                            ObtenerXFinEditableTramo(
                                tramo));

                    if (Distancia2D_Px(
                            e.X,
                            e.Y,
                            xFinPx,
                            yPx) <= toleranciaPx)
                    {
                        if (bloqueoHorizontalFin !=
                            AceroMuroTipoBloqueoExtremo.Ninguno &&
                            DebeMostrarHandleHorizontalFin(tramo))
                        {
                            ActualizarEstado(
                                "El FIN está bloqueado. Haga clic en el candado de la vista previa para desbloquearlo.");

                            return;
                        }

                        RegistrarDeshacer();

                        arrastrandoHandleAlzado = true;
                        tramoDragId =
                            tramo.MuroId;
                        tramoDragEsInicio = false;
                        tramoSeleccionadoId =
                            tramo.MuroId;

                        pnlVistaAlzado.Capture = true;

                        pnlVistaAlzado.Cursor =
                            System.Windows.Forms.Cursors.SizeWE;

                        pnlVistaAlzado.Invalidate();
                        return;
                    }
                }
            }

            pnlVistaAlzado.Invalidate();
        }

        private void PnlVista_MouseMove(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (paneando)
            {
                panX += e.X - ultimoMouse.X;
                panY += e.Y - ultimoMouse.Y;
                ultimoMouse = e.Location;
                pnlVistaAlzado.Invalidate();
                return;
            }

            if (!arrastrandoHandleAlzado)
            {
                snapAlzadoVisible = false;
                return;
            }

            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return;
            }

            AceroMuroTramoVista tramoObjetivo =
                ObtenerTramoPorId(
                    tramoDragId);

            if (tramoObjetivo == null)
                return;

            double modeloX =
                AplicarOsnapAlzado(
                    ModeloXAlzadoDesdePantalla(
                        e.X),
                    tramoObjetivo.MuroId);

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double defaultInicio =
                tramoObjetivo.XInicio +
                rec;

            double defaultFin =
                tramoObjetivo.XFin -
                rec;

            // Solo evita que un extremo atraviese al otro.
            // NO se limita a XInicio/XFin del anfitrión.
            double longitudMinima =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        5.0,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            if (tramoDragEsInicio)
            {
                double limiteDerecho =
                    ObtenerLimiteHorizontalOpuesto(
                        tramoObjetivo,
                        true) -
                    longitudMinima;

                double xEditable =
                    System.Math.Min(
                        modeloX,
                        limiteDerecho);

                // SIGNADO:
                //  > 0 = retirar hacia dentro
                //  < 0 = prolongar fuera del anfitrión
                ajusteInicioTramoCm[
                    tramoObjetivo.MuroId] =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            xEditable -
                            defaultInicio,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }
            else
            {
                double limiteIzquierdo =
                    ObtenerLimiteHorizontalOpuesto(
                        tramoObjetivo,
                        false) +
                    longitudMinima;

                double xEditable =
                    System.Math.Max(
                        modeloX,
                        limiteIzquierdo);

                ajusteFinTramoCm[
                    tramoObjetivo.MuroId] =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            defaultFin -
                            xEditable,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }

            pnlVistaAlzado.Invalidate();
        }

        private void PnlVista_MouseUp(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button ==
                System.Windows.Forms.MouseButtons.Middle)
            {
                paneando = false;

                pnlVistaAlzado.Cursor =
                    System.Windows.Forms.Cursors.Cross;
            }

            if (e.Button ==
                System.Windows.Forms.MouseButtons.Left)
            {
                arrastrandoHandleAlzado = false;
                tramoDragId = 0;

                pnlVistaAlzado.Capture = false;

                pnlVistaAlzado.Cursor =
                    System.Windows.Forms.Cursors.Cross;
            }
        }


        #endregion

        #region 02.4 - DIBUJO Y EDICIÓN DEL ALZADO

        private void PnlVista_Paint(
            object sender,
            System.Windows.Forms.PaintEventArgs e)
        {
            rectCotaDesarrolloInicioPorMuro.Clear();
            rectCotaDesarrolloFinPorMuro.Clear();

            System.Drawing.Graphics g = e.Graphics;

            g.SmoothingMode =
                System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            g.Clear(System.Drawing.Color.White);

            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                vistaElevacionActual.Tramos.Count == 0)
            {
                using (
                    System.Drawing.Font fuente =
                        new System.Drawing.Font("Segoe UI", 11F))
                using (
                    System.Drawing.Brush brush =
                        new System.Drawing.SolidBrush(
                            System.Drawing.Color.FromArgb(
                                105, 110, 118)))
                {
                    g.DrawString(
                        "Seleccione muros para mostrar el alzado longitudinal.",
                        fuente,
                        brush,
                        24F,
                        24F);

                    g.DrawString(
                        "Aquí se muestran muros, vacíos entre tramos y sus distancias.",
                        fuente,
                        brush,
                        24F,
                        48F);
                }

                return;
            }

            // IMPORTANTE: el encuadre base depende SOLO de los anfitriones.
            // Si un acero horizontal se extiende fuera del muro, NO recalculamos
            // escala ni centro. Así el zoom no se agranda/achica durante el arrastre.
            // Encuadre fijo: usa geometría de MUROS + ELEMENTOS DE EXTREMO.
            // Nunca usa los extremos editables del acero, así el zoom no cambia
            // al prolongar una barra fuera del anfitrión.
            double minX =
                System.Linq.Enumerable.Min(
                    vistaElevacionActual.Tramos,
                    x => x.XInicio);

            double maxX =
                System.Linq.Enumerable.Max(
                    vistaElevacionActual.Tramos,
                    x => x.XFin);

            double minZ =
                System.Linq.Enumerable.Min(
                    vistaElevacionActual.Tramos,
                    x => x.ZInferior);

            double maxZ =
                System.Linq.Enumerable.Max(
                    vistaElevacionActual.Tramos,
                    x => x.ZSuperior);

            if (vistaElevacionActual.ElementosExtremos != null &&
                vistaElevacionActual.ElementosExtremos.Count > 0)
            {
                minX = System.Math.Min(
                    minX,
                    System.Linq.Enumerable.Min(
                        vistaElevacionActual.ElementosExtremos,
                        x => x.XInicio));

                maxX = System.Math.Max(
                    maxX,
                    System.Linq.Enumerable.Max(
                        vistaElevacionActual.ElementosExtremos,
                        x => x.XFin));

                minZ = System.Math.Min(
                    minZ,
                    System.Linq.Enumerable.Min(
                        vistaElevacionActual.ElementosExtremos,
                        x => x.ZInferior));

                maxZ = System.Math.Max(
                    maxZ,
                    System.Linq.Enumerable.Max(
                        vistaElevacionActual.ElementosExtremos,
                        x => x.ZSuperior));
            }

            double anchoModelo =
                System.Math.Max(0.01, maxX - minX);

            double altoModelo =
                System.Math.Max(0.01, maxZ - minZ);

            float margenX = 54F;
            float margenYSuperior = 54F;
            float margenYInferior = 74F;

            float anchoPantalla =
                System.Math.Max(
                    20F,
                    pnlVistaAlzado.ClientSize.Width -
                    margenX * 2F);

            float altoPantalla =
                System.Math.Max(
                    20F,
                    pnlVistaAlzado.ClientSize.Height -
                    margenYSuperior -
                    margenYInferior);

            double escalaBase =
                System.Math.Min(
                    anchoPantalla / anchoModelo,
                    altoPantalla / altoModelo);

            double escala =
                escalaBase * zoomVista;

            float centroPanelX =
                pnlVistaAlzado.ClientSize.Width / 2F + panX;

            float centroPanelY =
                (pnlVistaAlzado.ClientSize.Height -
                 margenYInferior +
                 margenYSuperior) / 2F + panY;

            double centroModeloX =
                (minX + maxX) * 0.5;

            double centroModeloZ =
                (minZ + maxZ) * 0.5;

            System.Func<double, float> sx =
                x =>
                    centroPanelX +
                    (float)((x - centroModeloX) * escala);

            System.Func<double, float> sy =
                z =>
                    centroPanelY -
                    (float)((z - centroModeloZ) * escala);

            alzadoCentroModeloX = centroModeloX;
            alzadoEscala = escala;
            alzadoCentroPanelX = centroPanelX;

            AceroMuroConfiguracion confDibujo =
                ObtenerConfiguracionVisual();

            double recubrimientoDibujo =
                confDibujo.RecubrimientoCm / 30.48;

            using (
                System.Drawing.Pen penMuro =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            56, 78, 98),
                        1.8F))
            using (
                System.Drawing.Brush brushMuro =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            231, 236, 241)))
            using (
                System.Drawing.Pen penJunta =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            165, 172, 180),
                        1F))
            using (
                System.Drawing.Pen penVertical =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            36, 151, 91),
                        1.25F))
            using (
                System.Drawing.Pen penVerticalHalo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            95, 70, 245, 125),
                        8.0F))
            using (
                System.Drawing.Pen penVerticalBrillante =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            40, 225, 100),
                        3.0F))
            using (
                System.Drawing.Pen penHorizontal =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            25, 117, 188),
                        1.25F))
            using (
                System.Drawing.Pen penVacio =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            212, 123, 28),
                        1.3F))
            using (
                System.Drawing.Pen penRecubrimientoElemento =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0, 145, 215),
                        1.15F))
            using (
                System.Drawing.Brush brushVacio =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            255, 241, 220)))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.5F))
            using (
                System.Drawing.Font fuenteChica =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F))
            using (
                System.Drawing.Brush brushTexto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            60, 66, 72)))
            {
                penJunta.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                penVacio.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                penRecubrimientoElemento.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dot;

                // -------------------------------------------------
                // 0) VACÍOS / ELEMENTOS EN LOS EXTREMOS DE LA CADENA
                //
                // Se representan EXACTAMENTE igual que los vacíos centrales:
                // - mismo relleno
                // - mismo contorno
                // - sin hatch
                // - sin nombre, categoría, ID ni etiqueta
                // - solo se conserva la distancia/ancho como cota informativa
                // -------------------------------------------------
                if (vistaElevacionActual.ElementosExtremos != null)
                {
                    foreach (
                        AceroMuroElementoExtremoVista elementoExtremo
                        in vistaElevacionActual.ElementosExtremos)
                    {
                        float ex1 =
                            sx(
                                elementoExtremo.XInicio);

                        float ex2 =
                            sx(
                                elementoExtremo.XFin);

                        float ey1 =
                            sy(
                                elementoExtremo.ZSuperior);

                        float ey2 =
                            sy(
                                elementoExtremo.ZInferior);

                        System.Drawing.RectangleF rectElemento =
                            new System.Drawing.RectangleF(
                                System.Math.Min(
                                    ex1,
                                    ex2),
                                System.Math.Min(
                                    ey1,
                                    ey2),
                                System.Math.Abs(
                                    ex2 - ex1),
                                System.Math.Abs(
                                    ey2 - ey1));

                        // MISMO ASPECTO QUE EL VACÍO CENTRAL
                        g.FillRectangle(
                            brushVacio,
                            rectElemento);

                        g.DrawRectangle(
                            penVacio,
                            rectElemento.X,
                            rectElemento.Y,
                            rectElemento.Width,
                            rectElemento.Height);

                        // OFFSET PUNTEADO DEL RECUBRIMIENTO REAL DEL ELEMENTO.
                        if (elementoExtremo.RecubrimientoCm > 0.0)
                        {
                            double recPies =
                                elementoExtremo.RecubrimientoCm /
                                30.48;

                            double xIniRec =
                                elementoExtremo.XInicio +
                                recPies;

                            double xFinRec =
                                elementoExtremo.XFin -
                                recPies;

                            double zInfRec =
                                elementoExtremo.ZInferior +
                                recPies;

                            double zSupRec =
                                elementoExtremo.ZSuperior -
                                recPies;

                            if (xFinRec > xIniRec &&
                                zSupRec > zInfRec)
                            {
                                float rx1 =
                                    sx(xIniRec);

                                float rx2 =
                                    sx(xFinRec);

                                float ry1 =
                                    sy(zSupRec);

                                float ry2 =
                                    sy(zInfRec);

                                g.DrawRectangle(
                                    penRecubrimientoElemento,
                                    System.Math.Min(rx1, rx2),
                                    System.Math.Min(ry1, ry2),
                                    System.Math.Abs(rx2 - rx1),
                                    System.Math.Abs(ry2 - ry1));
                            }
                        }

                        double anchoExtremo =
                            System.Math.Abs(
                                elementoExtremo.XFin -
                                elementoExtremo.XInicio);

                        double anchoExtremoM =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    anchoExtremo,
                                    Autodesk.Revit.DB.UnitTypeId.Meters);

                        string textoMedida =
                            anchoExtremoM.ToString(
                                "0.00") +
                            " m";

                        System.Drawing.SizeF tamMedida =
                            g.MeasureString(
                                textoMedida,
                                fuenteChica);

                        float centroXElemento =
                            rectElemento.X +
                            rectElemento.Width * 0.5F;

                        // ÚNICO TEXTO: medida del tramo vacío.
                        g.DrawString(
                            textoMedida,
                            fuenteChica,
                            brushTexto,
                            centroXElemento -
                                tamMedida.Width * 0.5F,
                            rectElemento.Y - 15F);
                    }
                }

                // -------------------------------------------------
                // 1) VACÍOS ENTRE TRAMOS
                //
                // Mismo lenguaje gráfico que los vacíos de los extremos.
                // Sin hatch y sin etiquetas. Solo se muestra la distancia.
                // -------------------------------------------------
                if (vistaElevacionActual.Vacios != null)
                {
                    foreach (
                        AceroMuroVacioVista vacio
                        in vistaElevacionActual.Vacios)
                    {
                        float x1 =
                            sx(
                                vacio.XInicio);

                        float x2 =
                            sx(
                                vacio.XFin);

                        float y1 =
                            sy(
                                vacio.ZSuperior);

                        float y2 =
                            sy(
                                vacio.ZInferior);

                        System.Drawing.RectangleF rectVacio =
                            new System.Drawing.RectangleF(
                                System.Math.Min(
                                    x1,
                                    x2),
                                System.Math.Min(
                                    y1,
                                    y2),
                                System.Math.Abs(
                                    x2 - x1),
                                System.Math.Abs(
                                    y2 - y1));

                        g.FillRectangle(
                            brushVacio,
                            rectVacio);

                        g.DrawRectangle(
                            penVacio,
                            rectVacio.X,
                            rectVacio.Y,
                            rectVacio.Width,
                            rectVacio.Height);

                        // Si el hueco está realmente ocupado por una columna,
                        // pilar o elemento de borde, mostramos SU recubrimiento.
                        if (vacio.TieneElementoReal &&
                            vacio.RecubrimientoCm > 0.0)
                        {
                            double recPies =
                                vacio.RecubrimientoCm /
                                30.48;

                            double xIniRec =
                                vacio.XInicio +
                                recPies;

                            double xFinRec =
                                vacio.XFin -
                                recPies;

                            double zInfRec =
                                vacio.ZInferior +
                                recPies;

                            double zSupRec =
                                vacio.ZSuperior -
                                recPies;

                            if (xFinRec > xIniRec &&
                                zSupRec > zInfRec)
                            {
                                float rx1 =
                                    sx(xIniRec);

                                float rx2 =
                                    sx(xFinRec);

                                float ry1 =
                                    sy(zSupRec);

                                float ry2 =
                                    sy(zInfRec);

                                g.DrawRectangle(
                                    penRecubrimientoElemento,
                                    System.Math.Min(rx1, rx2),
                                    System.Math.Min(ry1, ry2),
                                    System.Math.Abs(rx2 - rx1),
                                    System.Math.Abs(ry2 - ry1));
                            }
                        }

                        double longitudVacio =
                            System.Math.Max(
                                0.0,
                                vacio.XFin -
                                vacio.XInicio);

                        double longitudVacioM =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    longitudVacio,
                                    Autodesk.Revit.DB.UnitTypeId.Meters);

                        string textoMedida =
                            longitudVacioM.ToString(
                                "0.00") +
                            " m";

                        System.Drawing.SizeF tamMedida =
                            g.MeasureString(
                                textoMedida,
                                fuenteChica);

                        float centroXVacio =
                            rectVacio.X +
                            rectVacio.Width * 0.5F;

                        g.DrawString(
                            textoMedida,
                            fuenteChica,
                            brushTexto,
                            centroXVacio -
                                tamMedida.Width * 0.5F,
                            rectVacio.Y - 15F);
                    }
                }

                // -------------------------------------------------
                // 2) MUROS / TRAMOS REALES
                // -------------------------------------------------
                foreach (
                    AceroMuroTramoVista tramo
                    in vistaElevacionActual.Tramos)
                {
                    float x1 = sx(tramo.XInicio);
                    float x2 = sx(tramo.XFin);
                    float y1 = sy(tramo.ZSuperior);
                    float y2 = sy(tramo.ZInferior);

                    System.Drawing.RectangleF rect =
                        new System.Drawing.RectangleF(
                            System.Math.Min(x1, x2),
                            System.Math.Min(y1, y2),
                            System.Math.Abs(x2 - x1),
                            System.Math.Abs(y2 - y1));

                    // El anfitrión nunca se ilumina por selección.
                    // La selección visual se aplica únicamente a los ACEROS.
                    bool seleccionado =
                        tramo.MuroId ==
                        tramoSeleccionadoId;

                    g.FillRectangle(
                        brushMuro,
                        rect);

                    g.DrawRectangle(
                        penMuro,
                        rect.X,
                        rect.Y,
                        rect.Width,
                        rect.Height);

                    // OFFSET DE RECUBRIMIENTO: referencia fija para dibujo y OSNAP.
                    if (recubrimientoDibujo > 1e-9 &&
                        tramo.XFin - tramo.XInicio >
                            recubrimientoDibujo * 2.0 &&
                        tramo.ZSuperior - tramo.ZInferior >
                            recubrimientoDibujo * 2.0)
                    {
                        using (
                            System.Drawing.Pen penCover =
                                new System.Drawing.Pen(
                                    System.Drawing.Color.FromArgb(
                                        118, 130, 142),
                                    1.1F))
                        {
                            penCover.DashStyle =
                                System.Drawing.Drawing2D.DashStyle.Dash;

                            float cx1 =
                                sx(
                                    tramo.XInicio +
                                    recubrimientoDibujo);

                            float cx2 =
                                sx(
                                    tramo.XFin -
                                    recubrimientoDibujo);

                            float cy1 =
                                sy(
                                    tramo.ZSuperior -
                                    recubrimientoDibujo);

                            float cy2 =
                                sy(
                                    tramo.ZInferior +
                                    recubrimientoDibujo);

                            g.DrawRectangle(
                                penCover,
                                System.Math.Min(cx1, cx2),
                                System.Math.Min(cy1, cy2),
                                System.Math.Abs(cx2 - cx1),
                                System.Math.Abs(cy2 - cy1));
                        }
                    }

                    g.DrawLine(
                        penJunta,
                        x2,
                        y1,
                        x2,
                        y2);

                    string etiqueta =
                        "ID " +
                        tramo.MuroId +
                        " | C" +
                        tramo.Cadena +
                        (tramo.EsCurvo
                            ? " | CURVO"
                            : "");

                    g.DrawString(
                        etiqueta,
                        fuente,
                        brushTexto,
                        rect.X + 3F,
                        rect.Y + 3F);

                    double longitudTramo =
                        System.Math.Max(
                            0.0,
                            tramo.XFin - tramo.XInicio);

                    double longitudTramoM =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertFromInternalUnits(
                                longitudTramo,
                                Autodesk.Revit.DB.UnitTypeId.Meters);

                    string textoLongitud =
                        "L = " +
                        System.Math.Round(
                            longitudTramoM,
                            2).ToString("0.00") +
                        " m";

                    g.DrawString(
                        textoLongitud,
                        fuenteChica,
                        brushTexto,
                        rect.X + 3F,
                        rect.Bottom + 2F);
                }

                AceroMuroConfiguracion conf =
                    confDibujo;

                double rec =
                    recubrimientoDibujo;

                double diametroHorizontalAlzado =
                    ObtenerDiametroBarraVista(
                        cmbTipoHorizontal);

                double centroHorizontalAlzado =
                    rec +
                    diametroHorizontalAlzado * 0.5;

                double zonaGanchoInferiorAlzado =
                    ObtenerZonaGanchoHorizontalPiesVista(
                        false);

                double zonaGanchoSuperiorAlzado =
                    ObtenerZonaGanchoHorizontalPiesVista(
                        true);

                double ajusteInfPies =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            conf.AjusteInferiorCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double ajusteSupPies =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            conf.AjusteSuperiorCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                // -------------------------------------------------
                // 3) VERTICALES SOLO EN MUROS
                // -------------------------------------------------
                if (conf.CrearVerticales &&
                    false)
                {
                    double sepV =
                        System.Math.Max(
                            0.01,
                            conf.EspaciamientoVerticalCm /
                            30.48);

                    foreach (
                        AceroMuroTramoVista tramo
                        in vistaElevacionActual.Tramos)
                    {
                        // IMPORTANTE:
                        // Las manijas del ALZADO son SOLO para los HORIZONTALES.
                        // La distribución vertical NO cambia al jalar esas manijas.
                        double inicio =
                            tramo.XInicio +
                            rec;

                        double fin =
                            tramo.XFin -
                            rec;

                        if (fin <= inicio)
                            continue;

                        int cantidad =
                            System.Math.Max(
                                1,
                                (int)System.Math.Floor(
                                    (fin - inicio) / sepV) + 1);

                        for (int i = 0; i < cantidad; i++)
                        {
                            double x =
                                System.Math.Min(
                                    fin,
                                    inicio + i * sepV);

                            if (VerticalesEnEdicion())
                            {
                                g.DrawLine(
                                    penVerticalHalo,
                                    sx(x),
                                    sy(tramo.ZInferior + rec + ajusteInfPies),
                                    sx(x),
                                    sy(tramo.ZSuperior - rec - ajusteSupPies));

                                g.DrawLine(
                                    penVerticalBrillante,
                                    sx(x),
                                    sy(tramo.ZInferior + rec + ajusteInfPies),
                                    sx(x),
                                    sy(tramo.ZSuperior - rec - ajusteSupPies));
                            }
                            else
                            {
                                g.DrawLine(
                                    penVertical,
                                    sx(x),
                                    sy(tramo.ZInferior + rec + ajusteInfPies),
                                    sx(x),
                                    sy(tramo.ZSuperior - rec - ajusteSupPies));
                            }
                        }

                        if (cantidad == 1 ||
                            inicio + (cantidad - 1) * sepV <
                            fin - sepV * 0.15)
                        {
                            if (VerticalesEnEdicion())
                            {
                                g.DrawLine(
                                    penVerticalHalo,
                                    sx(fin),
                                    sy(tramo.ZInferior + rec + ajusteInfPies),
                                    sx(fin),
                                    sy(tramo.ZSuperior - rec - ajusteSupPies));

                                g.DrawLine(
                                    penVerticalBrillante,
                                    sx(fin),
                                    sy(tramo.ZInferior + rec + ajusteInfPies),
                                    sx(fin),
                                    sy(tramo.ZSuperior - rec - ajusteSupPies));
                            }
                            else
                            {
                                g.DrawLine(
                                    penVertical,
                                    sx(fin),
                                    sy(tramo.ZInferior + rec + ajusteInfPies),
                                    sx(fin),
                                    sy(tramo.ZSuperior - rec - ajusteSupPies));
                            }
                        }
                    }
                }

                // -------------------------------------------------
                // 3.B) VERTICALES LIBRES CREADOS EN SECCIÓN
                //
                // La geometría vertical viene de InicioV/FinV.
                // La regla del grupo gobierna su distribución a lo largo
                // de cada tramo del muro.
                // -------------------------------------------------
                if (conf.CrearVerticales &&
                    gruposVerticales2Puntos.Count > 0)
                {
                    double diamV =
                        ObtenerDiametroBarraVista(
                            cmbTipoVertical);

                    double margenV =
                        rec +
                        diamV * 0.5;

                    foreach (
                        AceroMuroTramoVista tramo
                        in vistaElevacionActual.Tramos)
                    {
                        if (tramo == null)
                            continue;

                        double longitudDisponible =
                            (tramo.XFin -
                             tramo.XInicio) -
                            margenV * 2.0;

                        if (longitudDisponible <= 1e-9)
                            continue;

                        foreach (
                            AceroMuroGrupoVertical2Puntos grupoV
                            in gruposVerticales2Puntos)
                        {
                            if (grupoV == null)
                                continue;

                            int cantidadV;

                            if (grupoV.ReglaDistribucion ==
                                AceroMuroReglaDistribucionGrupo.NumeroFijo)
                            {
                                cantidadV =
                                    System.Math.Max(
                                        2,
                                        grupoV.Cantidad);
                            }
                            else
                            {
                                double espV =
                                    Autodesk.Revit.DB.UnitUtils
                                        .ConvertToInternalUnits(
                                            System.Math.Max(
                                                0.1,
                                                grupoV.EspaciamientoMaximoCm),
                                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                                cantidadV =
                                    System.Math.Max(
                                        2,
                                        (int)System.Math.Ceiling(
                                            longitudDisponible /
                                            espV) +
                                        1);
                            }

                            double alturaTramo =
                                tramo.ZSuperior -
                                tramo.ZInferior;

                            double z0 =
                                tramo.ZInferior +
                                grupoV.InicioV *
                                alturaTramo;

                            double z1 =
                                tramo.ZInferior +
                                grupoV.FinV *
                                alturaTramo;

                            bool seleccionadoV =
                                string.Equals(
                                    grupoV.Id,
                                    grupoVertical2PSeleccionadoId,
                                    System.StringComparison.Ordinal);

                            for (int i = 0;
                                 i < cantidadV;
                                 i++)
                            {
                                double t =
                                    cantidadV <= 1
                                        ? 0.0
                                        : (double)i /
                                            (cantidadV - 1);

                                double x =
                                    tramo.XInicio +
                                    margenV +
                                    longitudDisponible *
                                    t;

                                if (seleccionadoV)
                                {
                                    g.DrawLine(
                                        penVerticalHalo,
                                        sx(x),
                                        sy(z0),
                                        sx(x),
                                        sy(z1));

                                    g.DrawLine(
                                        penVerticalBrillante,
                                        sx(x),
                                        sy(z0),
                                        sx(x),
                                        sy(z1));
                                }
                                else
                                {
                                    g.DrawLine(
                                        penVertical,
                                        sx(x),
                                        sy(z0),
                                        sx(x),
                                        sy(z1));
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------
                // 4) HORIZONTALES
                // Si son continuos por cadena, atraviesan también los vacíos.
                // -------------------------------------------------
                if (conf.CrearHorizontales &&
                    gruposHorizontales2Puntos.Count > 0)
                {
                    System.Collections.Generic.IEnumerable<
                        System.Linq.IGrouping<
                            int,
                            AceroMuroTramoVista>> grupos =
                        System.Linq.Enumerable.GroupBy(
                            vistaElevacionActual.Tramos,
                            x => x.Cadena);

                    foreach (
                        System.Linq.IGrouping<
                            int,
                            AceroMuroTramoVista> grupoCadena
                        in grupos)
                    {
                        AceroMuroTramoVista primerTramo =
                            System.Linq.Enumerable.First(
                                System.Linq.Enumerable.OrderBy(
                                    grupoCadena,
                                    x => x.XInicio));

                        AceroMuroTramoVista ultimoTramo =
                            System.Linq.Enumerable.Last(
                                System.Linq.Enumerable.OrderBy(
                                    grupoCadena,
                                    x => x.XInicio));

                        double xInicio =
                            ObtenerXInicioEditableTramo(
                                primerTramo);

                        double xFin =
                            ObtenerXFinEditableTramo(
                                ultimoTramo);

                        double zBase =
                            System.Linq.Enumerable.Max(
                                grupoCadena,
                                x => x.ZInferior);

                        double zTope =
                            System.Linq.Enumerable.Min(
                                grupoCadena,
                                x => x.ZSuperior);

                        if (xFin <= xInicio ||
                            zTope <= zBase)
                        {
                            continue;
                        }

                        foreach (
                            AceroMuroGrupoHorizontal2Puntos grupo2P
                            in gruposHorizontales2Puntos)
                        {
                            if (grupo2P == null)
                                continue;

                            int cantidad =
                                ObtenerCantidadGrupoHorizontal2P(
                                    grupo2P);

                            for (int i = 0;
                                 i < cantidad;
                                 i++)
                            {
                                double t =
                                    cantidad <= 1
                                        ? 0.0
                                        : (double)i /
                                            (cantidad - 1);

                                double v =
                                    grupo2P.InicioV +
                                    (grupo2P.FinV -
                                     grupo2P.InicioV) *
                                    t;

                                double z =
                                    zBase +
                                    v *
                                    (zTope - zBase);

                                g.DrawLine(
                                    penHorizontal,
                                    sx(xInicio),
                                    sy(z),
                                    sx(xFin),
                                    sy(z));
                            }
                        }
                    }
                }
                else if (conf.CrearHorizontales &&
                    PermitirMallaHorizontalAutomatica())
                {
                    double sepH =
                        System.Math.Max(
                            0.01,
                            conf.EspaciamientoHorizontalCm /
                            30.48);

                    System.Collections.Generic.IEnumerable<
                        System.Linq.IGrouping<
                            int,
                            AceroMuroTramoVista>> grupos =
                        System.Linq.Enumerable.GroupBy(
                            vistaElevacionActual.Tramos,
                            x => x.Cadena);

                    foreach (
                        System.Linq.IGrouping<
                            int,
                            AceroMuroTramoVista> grupo
                        in grupos)
                    {
                        AceroMuroTramoVista primerTramo =
                            System.Linq.Enumerable.First(
                                System.Linq.Enumerable.OrderBy(
                                    grupo,
                                    x => x.XInicio));

                        AceroMuroTramoVista ultimoTramo =
                            System.Linq.Enumerable.Last(
                                System.Linq.Enumerable.OrderBy(
                                    grupo,
                                    x => x.XInicio));

                        double xInicio =
                            ObtenerXInicioEditableTramo(
                                primerTramo);

                        double xFin =
                            ObtenerXFinEditableTramo(
                                ultimoTramo);

                        // El ajuste INF/SUP pertenece solamente a
                        // los VERTICALES. Los horizontales no cambian
                        // cuando se prolonga/reduce la barra vertical.
                        double zInferior =
                            System.Linq.Enumerable.Max(
                                grupo,
                                x => x.ZInferior) +
                            centroHorizontalAlzado +
                            zonaGanchoInferiorAlzado;

                        double zSuperior =
                            System.Linq.Enumerable.Min(
                                grupo,
                                x => x.ZSuperior) -
                            centroHorizontalAlzado -
                            zonaGanchoSuperiorAlzado;

                        if (xFin <= xInicio ||
                            zSuperior <= zInferior)
                        {
                            continue;
                        }

                        if (!conf.HorizontalesContinuosPorCadena)
                        {
                            foreach (
                                AceroMuroTramoVista tramo
                                in grupo)
                            {
                                DibujarHorizontalesTramo(
                                    g,
                                    penHorizontal,
                                    sx,
                                    sy,
                                    ObtenerXInicioEditableTramo(
                                        tramo),
                                    ObtenerXFinEditableTramo(
                                        tramo),
                                    tramo.ZInferior +
                                        centroHorizontalAlzado +
                                        zonaGanchoInferiorAlzado,
                                    tramo.ZSuperior -
                                        centroHorizontalAlzado -
                                        zonaGanchoSuperiorAlzado,
                                    sepH,
                                    EsTramoHorizontalSeleccionado(
                                        tramo));
                            }
                        }
                        else
                        {
                            DibujarHorizontalesTramo(
                                g,
                                penHorizontal,
                                sx,
                                sy,
                                xInicio,
                                xFin,
                                zInferior,
                                zSuperior,
                                sepH,
                                EsCadenaHorizontalSeleccionada(
                                    primerTramo.Cadena));
                        }
                    }
                }
            }

            DibujarEstadoMallaAlzado(
                g);

            DibujarHandlesEdicionAlzado(
                g,
                sx,
                sy);

            DibujarGuiaOsnapAlzado(
                g,
                sx);

            using (
                System.Drawing.Font fuenteAyuda =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8F))
            using (
                System.Drawing.Brush brushAyuda =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            110, 116, 123)))
            {
                g.DrawString(
                    "Rueda = zoom  |  Botón central = paneo  |  Doble clic = ajustar  |  Gris = elemento extremo real  |  Naranja = vacío interior",
                    fuenteAyuda,
                    brushAyuda,
                    10F,
                    pnlVistaAlzado.ClientSize.Height - 24F);
            }
        }

        #endregion

        #region 02.5 - DIBUJO Y EDICIÓN DE LA SECCIÓN

        private void DibujarGuiasCreacionVerticalSeccion(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                vistaSeccionActual == null ||
                chkVerticales == null ||
                !chkVerticales.Checked)
            {
                return;
            }

            bool mostrarGuias =
                herramientaSeccion ==
                    AceroMuroHerramientaEdicion.DistribuirVerticalDosPuntos ||
                arrastrandoExtremoVertical2P ||
                !string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId);

            // Por defecto no se dibujan barras verticales automáticas.
            // La guía V aparece cuando:
            // - se activa CREAR V 2 PTOS;
            // - se arrastra un extremo V;
            // - se selecciona un grupo V existente.
            if (!mostrarGuias)
                return;

            System.Collections.Generic.List<
                System.Tuple<double, string>> guias =
                    ObtenerGuiasXVerticalesSeccion();

            if (guias == null ||
                guias.Count == 0)
            {
                return;
            }

            double zInf;
            double zSup;

            ObtenerRangoGuiasVerticalesSeccion(
                out zInf,
                out zSup);

            float yInf =
                PantallaYSeccion(
                    zInf);

            float ySup =
                PantallaYSeccion(
                    zSup);

            double xMinModelo =
                -vistaSeccionActual.Espesor *
                0.5;

            double xMaxModelo =
                vistaSeccionActual.Espesor *
                0.5;

            if (vistaSeccionActual.TieneNucleo)
            {
                xMinModelo =
                    vistaSeccionActual
                        .NucleoMinDesdeCentro;

                xMaxModelo =
                    vistaSeccionActual
                        .NucleoMaxDesdeCentro;
            }

            float xMin =
                PantallaXSeccion(
                    xMinModelo);

            float xMax =
                PantallaXSeccion(
                    xMaxModelo);

            using (
                System.Drawing.Pen penFondo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.White,
                        4.2F))
            using (
                System.Drawing.Pen penGuia =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0,
                            165,
                            90),
                        1.9F))
            using (
                System.Drawing.Pen penLimite =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            225,
                            125,
                            35),
                        1.05F))
            using (
                System.Drawing.Brush brushTextoGuia =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            20,
                            110,
                            60)))
            using (
                System.Drawing.Brush brushTextoLimite =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            190,
                            90,
                            20)))
            using (
                System.Drawing.Brush brushNodo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            0,
                            165,
                            90)))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F,
                        System.Drawing.FontStyle.Bold))
            {
                penGuia.DashStyle =
                    System.Drawing.Drawing2D
                        .DashStyle.Dash;

                penGuia.DashPattern =
                    new float[]
                    {
                    5.0F,
                    3.0F
                    };

                penLimite.DashStyle =
                    System.Drawing.Drawing2D
                        .DashStyle.Dot;

                // -------------------------------------------------
                // LIMITES DE CREACION DE LOS VERTICALES
                // -------------------------------------------------
                g.DrawLine(
                    penLimite,
                    xMin,
                    yInf,
                    xMax,
                    yInf);

                g.DrawLine(
                    penLimite,
                    xMin,
                    ySup,
                    xMax,
                    ySup);

                g.DrawString(
                    anguloGanchoInferior != 0
                        ? "LIMITE V INF - GANCHO"
                        : "LIMITE V INF",
                    fuente,
                    brushTextoLimite,
                    xMax + 5F,
                    yInf - 8F);

                g.DrawString(
                    anguloGanchoSuperior != 0
                        ? "LIMITE V SUP - GANCHO"
                        : "LIMITE V SUP",
                    fuente,
                    brushTextoLimite,
                    xMax + 5F,
                    ySup - 8F);

                // -------------------------------------------------
                // GUIAS V - MALLA A / MALLA B / UNA MALLA
                // -------------------------------------------------
                foreach (
                    System.Tuple<double, string> guia
                    in guias)
                {
                    if (guia == null)
                        continue;

                    float x =
                        PantallaXSeccion(
                            guia.Item1);

                    // Fondo claro para que la guía no se pierda
                    // cuando se superpone con otras referencias.
                    g.DrawLine(
                        penFondo,
                        x,
                        ySup,
                        x,
                        yInf);

                    // Guía real
                    g.DrawLine(
                        penGuia,
                        x,
                        ySup,
                        x,
                        yInf);

                    // Nodos en los extremos de la guía.
                    float r =
                        3.5F;

                    g.FillEllipse(
                        brushNodo,
                        x - r,
                        ySup - r,
                        r * 2F,
                        r * 2F);

                    g.FillEllipse(
                        brushNodo,
                        x - r,
                        yInf - r,
                        r * 2F,
                        r * 2F);

                    g.DrawString(
                        guia.Item2,
                        fuente,
                        brushTextoGuia,
                        x + 4F,
                        System.Math.Min(
                            yInf,
                            ySup) + 4F);
                }
            }
        }

        private System.Drawing.Color ObtenerColorDiametroDesdePies(
            double diametroPies)
        {
            // Paleta deliberadamente contrastada sobre fondo blanco.
            System.Drawing.Color[] paleta =
                new System.Drawing.Color[]
                {
                System.Drawing.Color.FromArgb(0, 110, 210),
                System.Drawing.Color.FromArgb(0, 145, 80),
                System.Drawing.Color.FromArgb(225, 105, 0),
                System.Drawing.Color.FromArgb(150, 70, 190),
                System.Drawing.Color.FromArgb(210, 45, 70),
                System.Drawing.Color.FromArgb(0, 145, 155),
                System.Drawing.Color.FromArgb(120, 85, 45),
                System.Drawing.Color.FromArgb(100, 120, 0),
                System.Drawing.Color.FromArgb(35, 75, 150),
                System.Drawing.Color.FromArgb(190, 75, 145),
                System.Drawing.Color.FromArgb(70, 110, 125),
                System.Drawing.Color.FromArgb(195, 135, 0)
                };

            double mm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        System.Math.Max(
                            0.0,
                            diametroPies),
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            int clave =
                (int)System.Math.Round(
                    mm * 10.0);

            if (clave < 0)
                clave = -clave;

            int indice =
                (clave * 37 + 11) %
                paleta.Length;

            return
                paleta[indice];
        }

        private System.Drawing.Color ObtenerColorTipoBarraGrupo(
            Autodesk.Revit.DB.Structure.RebarBarType tipo,
            double diametroFallback)
        {
            double diametro =
                tipo != null
                    ? ObtenerDiametroBarraVistaDesdeTipo(
                        tipo)
                    : diametroFallback;

            return
                ObtenerColorDiametroDesdePies(
                    diametro);
        }

        private string ObtenerTextoDiametroLeyenda(
            Autodesk.Revit.DB.Structure.RebarBarType tipo,
            double diametroPies)
        {
            if (tipo != null &&
                !string.IsNullOrWhiteSpace(
                    tipo.Name))
            {
                return
                    tipo.Name.Trim();
            }

            double mm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        diametroPies,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            return
                mm.ToString("0.#") +
                " mm";
        }

        private void AgregarDiametroLeyendaSiFalta(
            System.Collections.Generic.List<
                System.Tuple<
                    int,
                    double,
                    string,
                    System.Drawing.Color>> lista,
            Autodesk.Revit.DB.Structure.RebarBarType tipo,
            double diametroPies)
        {
            if (lista == null ||
                diametroPies <= 1e-9)
            {
                return;
            }

            double mm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        diametroPies,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            int clave =
                (int)System.Math.Round(
                    mm * 10.0);

            foreach (
                System.Tuple<
                    int,
                    double,
                    string,
                    System.Drawing.Color> item
                in lista)
            {
                if (item != null &&
                    item.Item1 == clave)
                {
                    return;
                }
            }

            lista.Add(
                System.Tuple.Create(
                    clave,
                    mm,
                    ObtenerTextoDiametroLeyenda(
                        tipo,
                        diametroPies),
                    ObtenerColorTipoBarraGrupo(
                        tipo,
                        diametroPies)));
        }

        private System.Collections.Generic.List<
            System.Tuple<
                int,
                double,
                string,
                System.Drawing.Color>>
            ObtenerDiametrosUsadosEnSeccion()
        {
            System.Collections.Generic.List<
                System.Tuple<
                    int,
                    double,
                    string,
                    System.Drawing.Color>> lista =
                        new System.Collections.Generic.List<
                            System.Tuple<
                                int,
                                double,
                                string,
                                System.Drawing.Color>>();

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                Autodesk.Revit.DB.Structure.RebarBarType tipo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoVertical);

                double diametro =
                    tipo != null
                        ? ObtenerDiametroBarraVistaDesdeTipo(
                            tipo)
                        : ObtenerDiametroBarraVista(
                            cmbTipoVertical);

                AgregarDiametroLeyendaSiFalta(
                    lista,
                    tipo,
                    diametro);
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                Autodesk.Revit.DB.Structure.RebarBarType tipo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoHorizontal);

                double diametro =
                    tipo != null
                        ? ObtenerDiametroBarraVistaDesdeTipo(
                            tipo)
                        : ObtenerDiametroBarraVista(
                            cmbTipoHorizontal);

                AgregarDiametroLeyendaSiFalta(
                    lista,
                    tipo,
                    diametro);
            }

            lista.Sort(
                (a, b) =>
                    a.Item2.CompareTo(
                        b.Item2));

            return lista;
        }

        private void DibujarLeyendaDiametrosAceros(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                pnlVistaSeccion == null)
            {
                return;
            }

            System.Collections.Generic.List<
                System.Tuple<
                    int,
                    double,
                    string,
                    System.Drawing.Color>> diametros =
                        ObtenerDiametrosUsadosEnSeccion();

            if (diametros == null ||
                diametros.Count == 0)
            {
                return;
            }

            int maxFilas =
                System.Math.Min(
                    10,
                    diametros.Count);

            float ancho =
                176F;

            float alto =
                31F +
                maxFilas * 22F +
                8F;

            float x =
                pnlVistaSeccion.ClientSize.Width -
                ancho -
                14F;

            // V8.58:
            // La leyenda se baja para no quedar pegada/recortada
            // contra la parte superior de la vista.
            float y =
                82F;

            if (x < 8F)
                x = 8F;

            using (
                System.Drawing.Brush fondo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            238,
                            255,
                            255,
                            255)))
            using (
                System.Drawing.Pen borde =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            155,
                            160,
                            170),
                        1F))
            using (
                System.Drawing.Font fuenteTitulo =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.8F,
                        System.Drawing.FontStyle.Regular))
            using (
                System.Drawing.Brush texto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            45,
                            50,
                            58)))
            {
                g.FillRectangle(
                    fondo,
                    x,
                    y,
                    ancho,
                    alto);

                g.DrawRectangle(
                    borde,
                    x,
                    y,
                    ancho,
                    alto);

                g.DrawString(
                    "LEYENDA DE DIÁMETROS",
                    fuenteTitulo,
                    texto,
                    x + 10F,
                    y + 7F);

                for (int i = 0;
                     i < maxFilas;
                     i++)
                {
                    System.Tuple<
                        int,
                        double,
                        string,
                        System.Drawing.Color> item =
                            diametros[i];

                    float filaY =
                        y +
                        31F +
                        i * 22F;

                    using (
                        System.Drawing.Pen penColor =
                            new System.Drawing.Pen(
                                item.Item4,
                                4F))
                    using (
                        System.Drawing.SolidBrush punto =
                            new System.Drawing.SolidBrush(
                                item.Item4))
                    {
                        g.DrawLine(
                            penColor,
                            x + 12F,
                            filaY + 8F,
                            x + 42F,
                            filaY + 8F);

                        g.FillEllipse(
                            punto,
                            x + 23F,
                            filaY + 3F,
                            10F,
                            10F);
                    }

                    g.DrawString(
                        "Ø " +
                        item.Item3,
                        fuente,
                        texto,
                        x + 50F,
                        filaY);
                }

                if (diametros.Count >
                    maxFilas)
                {
                    g.DrawString(
                        "+" +
                        (diametros.Count -
                         maxFilas) +
                        " diámetros",
                        fuente,
                        texto,
                        x + 50F,
                        y +
                        31F +
                        maxFilas * 22F);
                }
            }
        }


        private void DibujarGruposVerticales2PuntosSeccion(
            System.Drawing.Graphics g,
            double diametroVertical)
        {
            if (g == null)
                return;

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                bool seleccionado =
                    EsGrupoVerticalSeleccionado(
                        grupo.Id);

                bool grupoActivo =
                    string.Equals(
                        grupo.Id,
                        grupoVertical2PSeleccionadoId,
                        System.StringComparison.Ordinal);

                Autodesk.Revit.DB.Structure.RebarBarType tipoGrupo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoVertical);

                double diametroGrupo =
                    tipoGrupo != null
                        ? ObtenerDiametroBarraVistaDesdeTipo(
                            tipoGrupo)
                        : diametroVertical;

                float grosor =
                    System.Math.Max(
                        2.0F,
                        System.Math.Min(
                            5.0F,
                            (float)(
                                diametroGrupo *
                                seccionEscalaActual)));

                System.Drawing.Color colorDiametro =
                    ObtenerColorTipoBarraGrupo(
                        tipoGrupo,
                        diametroGrupo);

                System.Drawing.PointF am =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF bm =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(am.X),
                        PantallaYSeccion(am.Y));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(bm.X),
                        PantallaYSeccion(bm.Y));

                using (
                    System.Drawing.Pen halo =
                        new System.Drawing.Pen(
                            System.Drawing.Color.FromArgb(
                                70,
                                colorDiametro.R,
                                colorDiametro.G,
                                colorDiametro.B),
                            8F))
                using (
                    System.Drawing.Pen linea =
                        new System.Drawing.Pen(
                            colorDiametro,
                            seleccionado
                                ? grosor + 1.5F
                                : grosor))
                using (
                    System.Drawing.SolidBrush handle =
                        new System.Drawing.SolidBrush(
                            System.Drawing.Color.FromArgb(
                                220,
                                55,
                                55)))
                {
                    if (seleccionado)
                        g.DrawLine(
                            halo,
                            a,
                            b);

                    g.DrawLine(
                        linea,
                        a,
                        b);

                    if (grupoActivo)
                    {
                        const float s =
                            8F;

                        g.FillRectangle(
                            handle,
                            a.X - s * 0.5F,
                            a.Y - s * 0.5F,
                            s,
                            s);

                        g.FillRectangle(
                            handle,
                            b.X - s * 0.5F,
                            b.Y - s * 0.5F,
                            s,
                            s);
                    }
                }
            }

            if (creandoVerticalDosPuntos)
            {
                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            vertical2PInicioX),
                        PantallaYSeccion(
                            vertical2PInicioZ));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            vertical2PFinX),
                        PantallaYSeccion(
                            vertical2PFinZ));

                using (
                    System.Drawing.Pen pen =
                        new System.Drawing.Pen(
                            System.Drawing.Color.FromArgb(
                                235,
                                130,
                                0),
                            2.4F))
                {
                    pen.DashStyle =
                        System.Drawing.Drawing2D.DashStyle.Dash;

                    g.DrawLine(
                        pen,
                        a,
                        b);
                }
            }
        }


        private double ObtenerDistanciaFisicaPuntosSeccion(
            System.Drawing.PointF a,
            System.Drawing.PointF b)
        {
            if (vistaSeccionActual == null)
                return double.MaxValue;

            double espesor =
                vistaSeccionActual.Espesor;

            double altura =
                vistaSeccionActual.Altura;

            if (espesor <= 1e-9 ||
                altura <= 1e-9)
            {
                return double.MaxValue;
            }

            double dx =
                (a.X - b.X) *
                espesor;

            double dz =
                (a.Y - b.Y) *
                altura;

            return
                System.Math.Sqrt(
                    dx * dx +
                    dz * dz);
        }

        private bool SonGruposHorizontalesColineales(
            AceroMuroGrupoHorizontal2Puntos a,
            AceroMuroGrupoHorizontal2Puntos b)
        {
            if (a == null ||
                b == null ||
                vistaSeccionActual == null)
            {
                return false;
            }

            double espesor =
                vistaSeccionActual.Espesor;

            double altura =
                vistaSeccionActual.Altura;

            if (espesor <= 1e-9 ||
                altura <= 1e-9)
            {
                return false;
            }

            double ax =
                (a.FinU -
                 a.InicioU) *
                espesor;

            double az =
                (a.FinV -
                 a.InicioV) *
                altura;

            double bx =
                (b.FinU -
                 b.InicioU) *
                espesor;

            double bz =
                (b.FinV -
                 b.InicioV) *
                altura;

            double la =
                System.Math.Sqrt(
                    ax * ax +
                    az * az);

            double lb =
                System.Math.Sqrt(
                    bx * bx +
                    bz * bz);

            if (la <= 1e-9 ||
                lb <= 1e-9)
            {
                return false;
            }

            double seno =
                System.Math.Abs(
                    ax * bz -
                    az * bx) /
                (la * lb);

            // Aproximadamente < 1°.
            if (seno > 0.018)
                return false;

            System.Drawing.PointF a0 =
                ObtenerInicioModeloGrupoHorizontal2P(
                    a);

            System.Drawing.PointF a1 =
                ObtenerFinModeloGrupoHorizontal2P(
                    a);

            System.Drawing.PointF b0 =
                ObtenerInicioModeloGrupoHorizontal2P(
                    b);

            double vx =
                a1.X -
                a0.X;

            double vz =
                a1.Y -
                a0.Y;

            double len2 =
                vx * vx +
                vz * vz;

            if (len2 <= 1e-12)
                return false;

            double t =
                ((b0.X - a0.X) * vx +
                 (b0.Y - a0.Y) * vz) /
                len2;

            System.Drawing.PointF proyeccion =
                new System.Drawing.PointF(
                    (float)(
                        a0.X +
                        t * vx),
                    (float)(
                        a0.Y +
                        t * vz));

            double distanciaLinea =
                ObtenerDistanciaFisicaPuntosSeccion(
                    b0,
                    proyeccion);

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        2.0,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            return
                distanciaLinea <=
                tolerancia;
        }

        private System.Drawing.PointF
            ObtenerPuntoDistribucionHorizontalModelo(
                AceroMuroGrupoHorizontal2Puntos grupo,
                int indice,
                int cantidad)
        {
            if (grupo == null)
                return System.Drawing.PointF.Empty;

            double t =
                cantidad <= 1
                    ? 0.0
                    : (double)indice /
                        (cantidad - 1);

            double u =
                grupo.InicioU +
                (grupo.FinU -
                 grupo.InicioU) *
                t;

            double v =
                grupo.InicioV +
                (grupo.FinV -
                 grupo.InicioV) *
                t;

            return
                ObtenerPuntoModeloSeccion2P(
                    u,
                    v);
        }

        private bool DebeOcultarExtremoHorizontalDuplicadoPreview(
            AceroMuroGrupoHorizontal2Puntos grupoActual,
            int indiceBarra,
            int cantidadActual)
        {
            if (grupoActual == null ||
                cantidadActual < 2)
            {
                return false;
            }

            // Solo se ocultan los extremos del grupo creado después.
            if (indiceBarra != 0 &&
                indiceBarra != cantidadActual - 1)
            {
                return false;
            }

            int indiceGrupoActual =
                gruposHorizontales2Puntos.IndexOf(
                    grupoActual);

            if (indiceGrupoActual <= 0)
                return false;

            System.Drawing.PointF puntoActual =
                ObtenerPuntoDistribucionHorizontalModelo(
                    grupoActual,
                    indiceBarra,
                    cantidadActual);

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        2.0,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            for (int g = 0;
                 g < indiceGrupoActual;
                 g++)
            {
                AceroMuroGrupoHorizontal2Puntos anterior =
                    gruposHorizontales2Puntos[g];

                if (anterior == null ||
                    !SonGruposHorizontalesColineales(
                        anterior,
                        grupoActual))
                {
                    continue;
                }

                int cantidadAnterior =
                    System.Math.Max(
                        2,
                        ObtenerCantidadGrupoHorizontal2P(
                            anterior));

                for (int i = 0;
                     i < cantidadAnterior;
                     i++)
                {
                    System.Drawing.PointF puntoAnterior =
                        ObtenerPuntoDistribucionHorizontalModelo(
                            anterior,
                            i,
                            cantidadAnterior);

                    if (ObtenerDistanciaFisicaPuntosSeccion(
                            puntoActual,
                            puntoAnterior) <=
                        tolerancia)
                    {
                        return true;
                    }
                }
            }

            return false;
        }


        private void DibujarGruposHorizontales2PuntosSeccion(
            System.Drawing.Graphics g,
            double diametroHorizontal)
        {
            if (g == null)
                return;

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                bool seleccionado =
                    EsGrupoHorizontalSeleccionado(
                        grupo.Id);

                bool grupoActivo =
                    string.Equals(
                        grupo.Id,
                        grupoHorizontal2PSeleccionadoId,
                        System.StringComparison.Ordinal);

                Autodesk.Revit.DB.Structure.RebarBarType tipoGrupo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoHorizontal);

                double diametroGrupo =
                    tipoGrupo != null
                        ? ObtenerDiametroBarraVistaDesdeTipo(
                            tipoGrupo)
                        : diametroHorizontal;

                float radioBarra =
                    System.Math.Max(
                        3.5F,
                        (float)(
                            diametroGrupo *
                            seccionEscalaActual *
                            0.5));

                radioBarra =
                    System.Math.Min(
                        radioBarra,
                        7.0F);

                System.Drawing.Color colorDiametro =
                    ObtenerColorTipoBarraGrupo(
                        tipoGrupo,
                        diametroGrupo);

                System.Drawing.PointF aModelo =
                    ObtenerInicioModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF bModelo =
                    ObtenerFinModeloGrupoHorizontal2P(
                        grupo);

                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            aModelo.X),
                        PantallaYSeccion(
                            aModelo.Y));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            bModelo.X),
                        PantallaYSeccion(
                            bModelo.Y));

                using (
                    System.Drawing.Pen halo =
                        new System.Drawing.Pen(
                            System.Drawing.Color.FromArgb(
                                70,
                                colorDiametro.R,
                                colorDiametro.G,
                                colorDiametro.B),
                            7F))
                using (
                    System.Drawing.Pen linea =
                        new System.Drawing.Pen(
                            colorDiametro,
                            seleccionado
                                ? 2.8F
                                : 1.7F))
                using (
                    System.Drawing.SolidBrush punto =
                        new System.Drawing.SolidBrush(
                            colorDiametro))
                using (
                    System.Drawing.SolidBrush handle =
                        new System.Drawing.SolidBrush(
                            System.Drawing.Color.FromArgb(
                                220,
                                55,
                                55)))
                {
                    linea.DashStyle =
                        System.Drawing.Drawing2D.DashStyle.Dash;

                    if (seleccionado)
                        g.DrawLine(
                            halo,
                            a,
                            b);

                    g.DrawLine(
                        linea,
                        a,
                        b);

                    int cantidad =
                        ObtenerCantidadGrupoHorizontal2P(
                            grupo);

                    for (int i = 0;
                         i < cantidad;
                         i++)
                    {
                        // V8.58:
                        // Si este grupo fue creado después y uno de sus
                        // extremos coincide con una barra de un grupo
                        // colineal anterior, no se vuelve a dibujar.
                        if (DebeOcultarExtremoHorizontalDuplicadoPreview(
                                grupo,
                                i,
                                cantidad))
                        {
                            continue;
                        }

                        double t =
                            cantidad <= 1
                                ? 0.0
                                : (double)i /
                                    (cantidad - 1);

                        double u =
                            grupo.InicioU +
                            (grupo.FinU -
                             grupo.InicioU) *
                            t;

                        double v =
                            grupo.InicioV +
                            (grupo.FinV -
                             grupo.InicioV) *
                            t;

                        System.Drawing.PointF pModelo =
                            ObtenerPuntoModeloSeccion2P(
                                u,
                                v);

                        float x =
                            PantallaXSeccion(
                                pModelo.X);

                        float y =
                            PantallaYSeccion(
                                pModelo.Y);

                        if (seleccionado)
                        {
                            using (
                                System.Drawing.SolidBrush haloPunto =
                                    new System.Drawing.SolidBrush(
                                        System.Drawing.Color.FromArgb(
                                            55,
                                            colorDiametro.R,
                                            colorDiametro.G,
                                            colorDiametro.B)))
                            {
                                g.FillEllipse(
                                    haloPunto,
                                    x - radioBarra - 2.5F,
                                    y - radioBarra - 2.5F,
                                    (radioBarra + 2.5F) * 2F,
                                    (radioBarra + 2.5F) * 2F);
                            }
                        }

                        g.FillEllipse(
                            punto,
                            x - radioBarra,
                            y - radioBarra,
                            radioBarra * 2F,
                            radioBarra * 2F);
                    }

                    if (grupoActivo)
                    {
                        const float s =
                            8F;

                        g.FillRectangle(
                            handle,
                            a.X - s * 0.5F,
                            a.Y - s * 0.5F,
                            s,
                            s);

                        g.FillRectangle(
                            handle,
                            b.X - s * 0.5F,
                            b.Y - s * 0.5F,
                            s,
                            s);
                    }
                }
            }

            if (creandoHorizontalDosPuntos)
            {
                System.Drawing.PointF a =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            horizontal2PInicioX),
                        PantallaYSeccion(
                            horizontal2PInicioZ));

                System.Drawing.PointF b =
                    new System.Drawing.PointF(
                        PantallaXSeccion(
                            horizontal2PFinX),
                        PantallaYSeccion(
                            horizontal2PFinZ));

                using (
                    System.Drawing.Pen pen =
                        new System.Drawing.Pen(
                            System.Drawing.Color.FromArgb(
                                235,
                                130,
                                0),
                            2.2F))
                using (
                    System.Drawing.SolidBrush brush =
                        new System.Drawing.SolidBrush(
                            System.Drawing.Color.FromArgb(
                                235,
                                130,
                                0)))
                {
                    pen.DashStyle =
                        System.Drawing.Drawing2D.DashStyle.Dash;

                    g.DrawLine(
                        pen,
                        a,
                        b);

                    System.Drawing.PointF p0Norm =
                        CrearPuntoNormalizadoSeccion2P(
                            horizontal2PInicioX,
                            horizontal2PInicioZ);

                    System.Drawing.PointF p1Norm =
                        CrearPuntoNormalizadoSeccion2P(
                            horizontal2PFinX,
                            horizontal2PFinZ);

                    AceroMuroGrupoHorizontal2Puntos temporal =
                        new AceroMuroGrupoHorizontal2Puntos
                        {
                            InicioU = p0Norm.X,
                            InicioV = p0Norm.Y,
                            FinU = p1Norm.X,
                            FinV = p1Norm.Y,
                            ReglaDistribucion =
                                AceroMuroReglaDistribucionGrupo.EspaciadoMaximo,
                            EspaciamientoMaximoCm =
                                System.Math.Max(
                                    0.5,
                                    ObtenerEspHorizontalCmActual()),
                            Cantidad = 4
                        };

                    int cantidad =
                        ObtenerCantidadGrupoHorizontal2P(
                            temporal);

                    for (int i = 0;
                         i < cantidad;
                         i++)
                    {
                        double t =
                            cantidad <= 1
                                ? 0.0
                                : (double)i /
                                    (cantidad - 1);

                        float x =
                            (float)(
                                a.X +
                                (b.X - a.X) *
                                t);

                        float y =
                            (float)(
                                a.Y +
                                (b.Y - a.Y) *
                                t);

                        g.FillEllipse(
                            brush,
                            x - 4.2F,
                            y - 4.2F,
                            8.4F,
                            8.4F);
                    }
                }
            }
        }

        private void PnlVistaSeccion_Paint(
            object sender,
            System.Windows.Forms.PaintEventArgs e)
        {
            System.Drawing.Graphics g = e.Graphics;

            g.SmoothingMode =
                System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            g.Clear(System.Drawing.Color.White);

            if (vistaSeccionActual == null ||
                vistaSeccionActual.Espesor <= 1e-9 ||
                vistaSeccionActual.Altura <= 1e-9)
            {
                using (
                    System.Drawing.Font fuente =
                        new System.Drawing.Font(
                            "Segoe UI",
                            11F))
                using (
                    System.Drawing.Brush brush =
                        new System.Drawing.SolidBrush(
                            System.Drawing.Color.FromArgb(
                                100, 106, 114)))
                {
                    g.DrawString(
                        "Seleccione muros para mostrar la SECCIÓN perpendicular al eje.",
                        fuente,
                        brush,
                        28F,
                        28F);

                    g.DrawString(
                        "Aquí se verá ESPESOR × ALTURA, no la longitud del muro.",
                        fuente,
                        brush,
                        28F,
                        54F);
                }

                return;
            }

            double espesor =
                vistaSeccionActual.Espesor;

            double altura =
                vistaSeccionActual.Altura;

            AceroMuroConfiguracion conf =
                ObtenerConfiguracionVisual();

            double recubrimiento =
                conf.RecubrimientoCm / 30.48;

            double diametroVertical =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double diametroHorizontal =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            double centroVerticalDesdeCara =
                recubrimiento +
                diametroVertical * 0.5;

            double centroHorizontalDesdeCara =
                recubrimiento +
                diametroHorizontal * 0.5;

            // DOBLE MALLA:
            // vertical afuera + horizontal adentro.
            if (conf.CrearVerticales &&
                diametroVertical > 1e-9)
            {
                centroHorizontalDesdeCara =
                    recubrimiento +
                    diametroVertical +
                    diametroHorizontal * 0.5;
            }

            double ajusteCaraAPies =
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionIzquierdaCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double ajusteCaraBPies =
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionDerechaCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double ajusteInferiorPies =
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionInferiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double ajusteSuperiorPies =
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionSuperiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            // Márgenes para cotas y textos.
            float margenIzq = 105F;
            float margenDer = 105F;
            float margenSup = 64F;
            float margenInf = 58F;

            float anchoDisponible =
                System.Math.Max(
                    40F,
                    pnlVistaSeccion.ClientSize.Width -
                    margenIzq -
                    margenDer);

            float altoDisponible =
                System.Math.Max(
                    40F,
                    pnlVistaSeccion.ClientSize.Height -
                    margenSup -
                    margenInf);

            // Mantiene la proporción geométrica real.
            double escala =
                System.Math.Min(
                    anchoDisponible /
                        System.Math.Max(espesor, 0.001),
                    altoDisponible /
                        System.Math.Max(altura, 0.001));

            // Para muros muy delgados, mantenemos al menos 55 px de ancho
            // solo para que las dos cortinas puedan leerse. Las cotas muestran
            // el espesor REAL, por lo que esta amplificación es solo gráfica.
            double anchoRealPx =
                espesor * escala;

            double factorExageracionX = 1.0;

            if (anchoRealPx < 55.0)
            {
                factorExageracionX =
                    55.0 /
                    System.Math.Max(
                        anchoRealPx,
                        1.0);
            }

            // -----------------------------------------------------
            // TRANSFORMACIÓN DE LA SECCIÓN CON ZOOM MANUAL.
            //
            // El zoom se calcula SIEMPRE respecto al muro/anfitrión,
            // por lo que sacar el acero fuera NO altera automáticamente
            // el encuadre. La rueda del mouse es la única que cambia zoom.
            // -----------------------------------------------------
            float centroXBase =
                pnlVistaSeccion.ClientSize.Width * 0.50F;

            float ySuperiorBase =
                margenSup;

            float yInferiorBase =
                pnlVistaSeccion.ClientSize.Height -
                margenInf;

            float centroYBase =
                (ySuperiorBase +
                 yInferiorBase) * 0.5F;

            float centroX =
                centroXBase +
                panSeccionX;

            float centroY =
                centroYBase +
                panSeccionY;

            double escalaZoom =
                escala *
                zoomSeccion;

            float altoBasePx =
                yInferiorBase -
                ySuperiorBase;

            float altoPx =
                (float)(
                    altoBasePx *
                    zoomSeccion);

            float ySuperior =
                centroY -
                altoPx * 0.5F;

            float yInferior =
                centroY +
                altoPx * 0.5F;

            float anchoPx =
                (float)(
                    espesor *
                    escalaZoom *
                    factorExageracionX);

            float xIzquierda =
                centroX -
                anchoPx * 0.5F;

            float xDerecha =
                centroX +
                anchoPx * 0.5F;

            System.Func<double, float> XDesdeCentro =
                xLocal =>
                    centroX +
                    (float)(
                        xLocal *
                        escalaZoom *
                        factorExageracionX);

            System.Func<double, float> YDesdeBase =
                zLocal =>
                    yInferior -
                    (float)(
                        (zLocal / altura) *
                        altoPx);

            seccionEspesorActual = espesor;
            seccionAlturaActual = altura;
            seccionEscalaActual = escalaZoom;
            seccionFactorExageracionX = factorExageracionX;
            seccionCentroXActual = centroX;
            seccionYSuperiorActual = ySuperior;
            seccionYInferiorActual = yInferior;

            using (
                System.Drawing.Brush brushConcreto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            235, 239, 243)))
            using (
                System.Drawing.Pen penContorno =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            52, 72, 91),
                        2.0F))
            using (
                System.Drawing.Pen penRecubrimiento =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            168, 176, 184),
                        1.0F))
            using (
                System.Drawing.Pen penVertical =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            38, 151, 88),
                        2.4F))
            using (
                System.Drawing.Pen penVerticalHalo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            95, 70, 245, 125),
                        8.0F))
            using (
                System.Drawing.Pen penVerticalBrillante =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            40, 225, 100),
                        3.0F))
            using (
                System.Drawing.Brush brushHorizontal =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            26, 118, 190)))
            using (
                System.Drawing.Pen penCota =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            75, 82, 90),
                        1.0F))
            using (
                System.Drawing.Font fuenteTitulo =
                    new System.Drawing.Font(
                        "Segoe UI",
                        10F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8.5F))
            using (
                System.Drawing.Brush brushTexto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            55, 61, 67)))
            {
                penRecubrimiento.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                // Hormigón / muro en corte.
                System.Drawing.RectangleF rectMuro =
                    new System.Drawing.RectangleF(
                        xIzquierda,
                        ySuperior,
                        anchoPx,
                        altoPx);

                g.FillRectangle(
                    brushConcreto,
                    rectMuro);

                g.DrawRectangle(
                    penContorno,
                    rectMuro.X,
                    rectMuro.Y,
                    rectMuro.Width,
                    rectMuro.Height);

                // -------------------------------------------------
                // OFFSET COMPLETO DE RECUBRIMIENTO - BASE DE DIBUJO/OSNAP
                // -------------------------------------------------
                if (recubrimiento > 0.0 &&
                    recubrimiento * 2.0 < espesor &&
                    recubrimiento * 2.0 < altura)
                {
                    float xRecA =
                        XDesdeCentro(
                            -espesor * 0.5 +
                            recubrimiento);

                    float xRecB =
                        XDesdeCentro(
                            espesor * 0.5 -
                            recubrimiento);

                    float yRecSup =
                        YDesdeBase(
                            altura - recubrimiento);

                    float yRecInf =
                        YDesdeBase(
                            recubrimiento);

                    g.DrawRectangle(
                        penRecubrimiento,
                        System.Math.Min(xRecA, xRecB),
                        System.Math.Min(yRecSup, yRecInf),
                        System.Math.Abs(xRecB - xRecA),
                        System.Math.Abs(yRecInf - yRecSup));
                }

                System.Collections.Generic.List<int> caras =
                    ObtenerCarasVista(
                        conf.ModoCaras);

                // -------------------------------------------------
                // ACERO VERTICAL
                // En este corte aparece como línea vertical por cara.
                // -------------------------------------------------
                if (conf.CrearVerticales &&
                    false)
                {
                    double zIni =
                        centroVerticalDesdeCara +
                        ajusteInferiorPies;

                    double zFin =
                        altura -
                        centroVerticalDesdeCara -
                        ajusteSuperiorPies;

                    zIni =
                        System.Math.Max(
                            zIni,
                            -altura);

                    zFin =
                        System.Math.Max(
                            zFin,
                            zIni);

                    if (caras.Contains(1))
                    {
                        float x =
                            XDesdeCentro(
                                ObtenerXVerticalLocalVista(
                                    1));

                        if (VerticalesEnEdicion())
                        {
                            g.DrawLine(
                                penVerticalHalo,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));

                            g.DrawLine(
                                penVerticalBrillante,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));
                        }
                        else
                        {
                            g.DrawLine(
                                penVertical,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));
                        }
                    }

                    if (caras.Contains(-1))
                    {
                        float x =
                            XDesdeCentro(
                                ObtenerXVerticalLocalVista(
                                    -1));

                        if (VerticalesEnEdicion())
                        {
                            g.DrawLine(
                                penVerticalHalo,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));

                            g.DrawLine(
                                penVerticalBrillante,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));
                        }
                        else
                        {
                            g.DrawLine(
                                penVertical,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));
                        }
                    }

                    if (caras.Contains(0))
                    {
                        // UNA MALLA:
                        // sin gancho queda al eje; con gancho el fuste
                        // se desplaza automáticamente al lado opuesto.
                        float x =
                            XDesdeCentro(
                                ObtenerXVerticalLocalVista(
                                    0));

                        if (VerticalesEnEdicion())
                        {
                            g.DrawLine(
                                penVerticalHalo,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));

                            g.DrawLine(
                                penVerticalBrillante,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));
                        }
                        else
                        {
                            g.DrawLine(
                                penVertical,
                                x,
                                YDesdeBase(zIni),
                                x,
                                YDesdeBase(zFin));
                        }
                    }
                }

                // -------------------------------------------------
                // LÍMITES DEL NÚCLEO
                // -------------------------------------------------
                if (vistaSeccionActual != null &&
                    vistaSeccionActual.TieneNucleo)
                {
                    using (
                        System.Drawing.Pen penNucleo =
                            new System.Drawing.Pen(
                                System.Drawing.Color.FromArgb(
                                    115,
                                    90,
                                    90,
                                    90),
                                1.0F))
                    {
                        penNucleo.DashStyle =
                            System.Drawing.Drawing2D.DashStyle.Dash;

                        float xNucleo1 =
                            XDesdeCentro(
                                vistaSeccionActual.NucleoMinDesdeCentro);

                        float xNucleo2 =
                            XDesdeCentro(
                                vistaSeccionActual.NucleoMaxDesdeCentro);

                        g.DrawLine(
                            penNucleo,
                            xNucleo1,
                            YDesdeBase(0.0),
                            xNucleo1,
                            YDesdeBase(altura));

                        g.DrawLine(
                            penNucleo,
                            xNucleo2,
                            YDesdeBase(0.0),
                            xNucleo2,
                            YDesdeBase(altura));
                    }
                }

                // -------------------------------------------------
                // GUIAS INTELIGENTES PARA CREAR HORIZONTALES
                //
                // Celeste = capa horizontal interior.
                // Naranja = límites seguros, incluyendo curvatura de gancho.
                // Las mismas referencias forman parte del OSNAP.
                // -------------------------------------------------
                DibujarGuiasCreacionHorizontalSeccion(
                    g);

                DibujarGuiasCreacionVerticalSeccion(
                    g);

                if (conf.CrearVerticales)
                {
                    DibujarGruposVerticales2PuntosSeccion(
                        g,
                        diametroVertical);
                }

                // -------------------------------------------------
                // HORIZONTALES LIBRES CREADOS CON DOS PUNTOS.
                // Si existen, reemplazan la distribución automática.
                // -------------------------------------------------
                if (conf.CrearHorizontales &&
                    (gruposHorizontales2Puntos.Count > 0 ||
                     creandoHorizontalDosPuntos))
                {
                    DibujarGruposHorizontales2PuntosSeccion(
                        g,
                        diametroHorizontal);
                }

                // -------------------------------------------------
                // ACERO HORIZONTAL
                // Corre longitudinalmente por el muro.
                // En el corte perpendicular aparece como PUNTO/CÍRCULO.
                // -------------------------------------------------
                if (conf.CrearHorizontales &&
                    gruposHorizontales2Puntos.Count == 0 &&
                    PermitirMallaHorizontalAutomatica())
                {
                    double separacion =
                        System.Math.Max(
                            conf.EspaciamientoHorizontalCm /
                            30.48,
                            0.001);

                    // IMPORTANTE:
                    // Los handles INF/SUP editan exclusivamente la LONGITUD
                    // DE LOS ACEROS VERTICALES. Los horizontales conservan
                    // su distribución automática según recubrimiento.
                    double zonaGanchoInferior =
                        ObtenerZonaGanchoHorizontalPiesVista(
                            false);

                    double zonaGanchoSuperior =
                        ObtenerZonaGanchoHorizontalPiesVista(
                            true);

                    double zIni =
                        centroHorizontalDesdeCara +
                        zonaGanchoInferior;

                    double zFin =
                        altura -
                        centroHorizontalDesdeCara -
                        zonaGanchoSuperior;

                    zIni =
                        System.Math.Max(
                            zIni,
                            0.0);

                    zFin =
                        System.Math.Min(
                            altura,
                            System.Math.Max(
                                zFin,
                                zIni));

                    if (zFin >= zIni)
                    {
                        int cantidad =
                            System.Math.Max(
                                1,
                                (int)System.Math.Floor(
                                    (zFin - zIni) /
                                    separacion) + 1);

                        for (int i = 0;
                             i < cantidad;
                             i++)
                        {
                            double z =
                                System.Math.Min(
                                    zFin,
                                    zIni +
                                    i * separacion);

                            float y =
                                YDesdeBase(z);

                            float radio =
                                System.Math.Max(
                                    3.2F,
                                    (float)(
                                        diametroHorizontal *
                                        escala *
                                        0.5));

                            radio =
                                System.Math.Min(
                                    radio,
                                    6.5F);

                            double nucleoMin =
                                vistaSeccionActual != null &&
                                vistaSeccionActual.TieneNucleo
                                    ? vistaSeccionActual.NucleoMinDesdeCentro
                                    : -espesor * 0.5;

                            double nucleoMax =
                                vistaSeccionActual != null &&
                                vistaSeccionActual.TieneNucleo
                                    ? vistaSeccionActual.NucleoMaxDesdeCentro
                                    : espesor * 0.5;

                            if (caras.Contains(1))
                            {
                                // Cara izquierda de la preview:
                                // SIEMPRE dentro del límite del NÚCLEO.
                                double xLocal =
                                    nucleoMin +
                                    centroHorizontalDesdeCara +
                                    ajusteCaraAPies;

                                xLocal =
                                    System.Math.Min(
                                        nucleoMax,
                                        System.Math.Max(
                                            nucleoMin,
                                            xLocal));

                                float x =
                                    XDesdeCentro(
                                        xLocal);

                                g.FillEllipse(
                                    brushHorizontal,
                                    x - radio,
                                    y - radio,
                                    radio * 2F,
                                    radio * 2F);
                            }

                            if (caras.Contains(-1))
                            {
                                // Cara derecha de la preview:
                                // SIEMPRE dentro del límite del NÚCLEO.
                                double xLocal =
                                    nucleoMax -
                                    centroHorizontalDesdeCara -
                                    ajusteCaraBPies;

                                xLocal =
                                    System.Math.Min(
                                        nucleoMax,
                                        System.Math.Max(
                                            nucleoMin,
                                            xLocal));

                                float x =
                                    XDesdeCentro(
                                        xLocal);

                                g.FillEllipse(
                                    brushHorizontal,
                                    x - radio,
                                    y - radio,
                                    radio * 2F,
                                    radio * 2F);
                            }

                            if (caras.Contains(0))
                            {
                                // Una malla se centra en el NÚCLEO,
                                // no necesariamente en el centro del acabado total.
                                float x =
                                    XDesdeCentro(
                                        (nucleoMin +
                                         nucleoMax) * 0.5);

                                g.FillEllipse(
                                    brushHorizontal,
                                    x - radio,
                                    y - radio,
                                    radio * 2F,
                                    radio * 2F);
                            }
                        }
                    }
                }

                // -------------------------------------------------
                // COTAS Y ROTULACIÓN
                // -------------------------------------------------
                double espesorCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            espesor,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double alturaM =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            altura,
                            Autodesk.Revit.DB.UnitTypeId.Meters);

                string titulo =
                    "SECCIÓN PERPENDICULAR AL EJE DEL MURO";

                g.DrawString(
                    titulo,
                    fuenteTitulo,
                    brushTexto,
                    16F,
                    14F);

                string referencia =
                    string.IsNullOrWhiteSpace(
                        vistaSeccionActual.NombreReferencia)
                        ? "Muro"
                        : vistaSeccionActual.NombreReferencia;

                g.DrawString(
                    referencia,
                    fuente,
                    brushTexto,
                    16F,
                    38F);

                if (conf.ModoCaras == 3)
                {
                    string txtMalla =
                        "UNA MALLA - EJE DEL MURO";

                    System.Drawing.SizeF tamMalla =
                        g.MeasureString(
                            txtMalla,
                            fuente);

                    g.DrawString(
                        txtMalla,
                        fuente,
                        brushTexto,
                        centroX - tamMalla.Width * 0.5F,
                        ySuperior + 4F);
                }
                else
                {
                    g.DrawString(
                        "MALLA A",
                        fuente,
                        brushTexto,
                        xIzquierda - 62F,
                        ySuperior + 4F);

                    g.DrawString(
                        "MALLA B",
                        fuente,
                        brushTexto,
                        xDerecha + 8F,
                        ySuperior + 4F);
                }

                // Cota inferior de espesor.
                float yCotaEspesor =
                    yInferior + 28F;

                g.DrawLine(
                    penCota,
                    xIzquierda,
                    yCotaEspesor,
                    xDerecha,
                    yCotaEspesor);

                g.DrawLine(
                    penCota,
                    xIzquierda,
                    yCotaEspesor - 5F,
                    xIzquierda,
                    yCotaEspesor + 5F);

                g.DrawLine(
                    penCota,
                    xDerecha,
                    yCotaEspesor - 5F,
                    xDerecha,
                    yCotaEspesor + 5F);

                string txtEspesor =
                    "e = " +
                    System.Math.Round(
                        espesorCm,
                        1) +
                    " cm";

                System.Drawing.SizeF tamEsp =
                    g.MeasureString(
                        txtEspesor,
                        fuente);

                g.DrawString(
                    txtEspesor,
                    fuente,
                    brushTexto,
                    centroX -
                        tamEsp.Width * 0.5F,
                    yCotaEspesor - 21F);

                // Cota lateral de altura.
                float xCotaAltura =
                    xDerecha + 68F;

                g.DrawLine(
                    penCota,
                    xCotaAltura,
                    ySuperior,
                    xCotaAltura,
                    yInferior);

                g.DrawLine(
                    penCota,
                    xCotaAltura - 5F,
                    ySuperior,
                    xCotaAltura + 5F,
                    ySuperior);

                g.DrawLine(
                    penCota,
                    xCotaAltura - 5F,
                    yInferior,
                    xCotaAltura + 5F,
                    yInferior);

                string txtAltura =
                    "H = " +
                    System.Math.Round(
                        alturaM,
                        2) +
                    " m";

                g.DrawString(
                    txtAltura,
                    fuente,
                    brushTexto,
                    xCotaAltura + 8F,
                    (ySuperior + yInferior) * 0.5F - 8F);

                string leyenda =
                    "Verde: verticales  |  Azul: horizontales vistos en corte  |  " +
                    "Recubrimiento: " +
                    conf.RecubrimientoCm.ToString("0.0") +
                    " cm";

                g.DrawString(
                    leyenda,
                    fuente,
                    brushTexto,
                    16F,
                    pnlVistaSeccion.ClientSize.Height - 26F);

                if (factorExageracionX > 1.01)
                {
                    g.DrawString(
                        "Nota: el espesor se amplía gráficamente para poder leer las dos caras; la cota indicada es la real.",
                        fuente,
                        brushTexto,
                        16F,
                        pnlVistaSeccion.ClientSize.Height - 46F);
                }

                if (!string.IsNullOrWhiteSpace(
                    vistaSeccionActual.Observacion))
                {
                    g.DrawString(
                        vistaSeccionActual.Observacion,
                        fuente,
                        brushTexto,
                        16F,
                        pnlVistaSeccion.ClientSize.Height - 66F);
                }
            }

            DibujarHandlesEdicionSeccion(
                g);

            DibujarGanchosVerticales(
                g);

            DibujarLimitesHorizontalesPorGancho(
                g);

            // V8.59:
            // Si el vertical sale fuera del anfitrión y existe gancho,
            // también mostramos en la extensión la línea de referencia
            // correspondiente al centro real de curvatura.
            DibujarLimitesCurvaturaGanchoEnExtensiones(
                g);

            DibujarSelectoresGancho(
                g);

            // Si el vertical sale por encima o por debajo del muro,
            // mostramos una cota real. Su valor es clickeable.
            DibujarCotasExtensionVertical(
                g);

            // Leyenda gráfica de los diámetros realmente usados.
            // Cada diámetro tiene el mismo color en H y V.
            DibujarLeyendaDiametrosAceros(
                g);

            // Vista previa gris del conjunto trasladado antes del
            // segundo clic de MOVER 2 PTOS.
            DibujarVistaPreviaMoverGruposDosPuntos(
                g);

            DibujarGuiaOsnapSeccion(
                g);
        }


        private bool HayGanchoVerticalActivo()
        {
            return
                anguloGanchoInferior != 0 ||
                anguloGanchoSuperior != 0;
        }

        private bool DebeSepararCapasPorGancho()
        {
            return
                HayGanchoVerticalActivo() &&
                chkVerticales != null &&
                chkVerticales.Checked &&
                chkHorizontales != null &&
                chkHorizontales.Checked;
        }

        private double ObtenerSeparacionEjesVerticalHorizontalPiesVista()
        {
            // =====================================================
            // SEPARACIÓN REAL ENTRE CAPA VERTICAL Y HORIZONTAL
            //
            // Esta separación NO depende de que exista gancho.
            //
            // Vertical = capa exterior.
            // Horizontal = capa interior.
            //
            // Distancia entre ejes:
            // ØV/2 + ØH/2 + 5 mm de holgura.
            //
            // En V8.44 se estaba reutilizando
            // ObtenerSeparacionEjesCapasPiesVista(), pero ese método
            // devuelve 0 cuando no hay gancho. Por eso la GUIA H
            // quedaba exactamente encima del vertical y parecía
            // desaparecer.
            // =====================================================
            if (chkVerticales == null ||
                !chkVerticales.Checked ||
                chkHorizontales == null ||
                !chkHorizontales.Checked)
            {
                return 0.0;
            }

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double diamHor =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            double holgura =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        0.5,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            return
                diamVert * 0.5 +
                diamHor * 0.5 +
                holgura;
        }


        private double ObtenerSeparacionEjesCapasPiesVista()
        {
            if (!DebeSepararCapasPorGancho())
                return 0.0;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double diamHor =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            // Distancia libre entre superficies = 5 mm.
            // Separación entre ejes =
            // radio V + radio H + 5 mm.
            double holgura =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        0.5,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            return
                (diamVert + diamHor) * 0.5 +
                holgura;
        }

        private double ObtenerBaseVerticalDesdeCaraPiesVista()
        {
            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            // El vertical es SIEMPRE la capa exterior.
            // La interferencia con horizontales se resuelve colocando
            // el horizontal por dentro del núcleo, no desplazando el
            // vertical hacia el centro.
            return
                rec +
                diamVert * 0.5;
        }

        private double ObtenerXVerticalLocalVista(
            int cara)
        {
            if (vistaSeccionActual == null)
                return 0.0;

            double ajusteA =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteSeccionIzquierdaCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double ajusteB =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteSeccionDerechaCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double baseVertical =
                ObtenerBaseVerticalDesdeCaraPiesVista();

            double nucleoMin =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMinDesdeCentro
                    : -seccionEspesorActual * 0.5;

            double nucleoMax =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMaxDesdeCentro
                    : seccionEspesorActual * 0.5;

            if (cara == 0)
            {
                double centroNucleo =
                    (nucleoMin +
                     nucleoMax) * 0.5;

                if (!DebeSepararCapasPorGancho())
                    return centroNucleo;

                // UNA MALLA:
                // conserva el desplazamiento opuesto al gancho.
                double desplazamiento =
                    ObtenerSeparacionEjesCapasPiesVista();

                return
                    System.Math.Max(
                        nucleoMin,
                        centroNucleo -
                        desplazamiento);
            }

            if (cara == 1)
            {
                // Lado izquierdo de la preview:
                // vertical pegado a la cara EXTERNA del núcleo.
                double x =
                    nucleoMin +
                    baseVertical +
                    ajusteA;

                return
                    System.Math.Min(
                        nucleoMax,
                        System.Math.Max(
                            nucleoMin,
                            x));
            }

            if (cara == -1)
            {
                // Lado derecho de la preview:
                // vertical pegado a la cara EXTERNA del núcleo.
                double x =
                    nucleoMax -
                    baseVertical -
                    ajusteB;

                return
                    System.Math.Min(
                        nucleoMax,
                        System.Math.Max(
                            nucleoMin,
                            x));
            }

            return
                (nucleoMin +
                 nucleoMax) * 0.5;
        }

        private int ObtenerDireccionGanchoPreview(
            int cara)
        {
            // En doble malla el gancho apunta hacia la cara exterior,
            // mientras el fuste vertical se desplaza hacia el centro.
            if (cara == 1)
                return -1;

            if (cara == -1)
                return 1;

            // Una malla centrada:
            // gancho hacia +X y fuste hacia -X.
            return 1;
        }

        private double ObtenerValorDoublePorReflexion(
            object objeto,
            string nombrePropiedad)
        {
            if (objeto == null ||
                string.IsNullOrWhiteSpace(
                    nombrePropiedad))
            {
                return 0.0;
            }

            try
            {
                System.Reflection.PropertyInfo prop =
                    objeto.GetType().GetProperty(
                        nombrePropiedad,
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.Instance);

                if (prop == null)
                    return 0.0;

                object valor =
                    prop.GetValue(
                        objeto,
                        null);

                if (valor == null)
                    return 0.0;

                return
                    System.Convert.ToDouble(
                        valor,
                        System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                return 0.0;
            }
        }

        private double ObtenerLongitudTangenteGanchoVista(
            Autodesk.Revit.DB.Structure.RebarBarType tipoBarra,
            Autodesk.Revit.DB.Structure.RebarHookType tipoGancho)
        {
            if (tipoBarra == null ||
                tipoGancho == null)
            {
                return 0.0;
            }

            try
            {
                foreach (
                    System.Reflection.MethodInfo metodo
                    in tipoBarra.GetType().GetMethods(
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.Instance))
                {
                    if (!string.Equals(
                        metodo.Name,
                        "GetHookTangentLength",
                        System.StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    System.Reflection.ParameterInfo[] p =
                        metodo.GetParameters();

                    if (p.Length != 1)
                        continue;

                    object argumento = null;

                    if (p[0].ParameterType.IsAssignableFrom(
                        typeof(
                            Autodesk.Revit.DB.Structure.RebarHookType)))
                    {
                        argumento =
                            tipoGancho;
                    }
                    else if (p[0].ParameterType ==
                        typeof(
                            Autodesk.Revit.DB.ElementId))
                    {
                        argumento =
                            tipoGancho.Id;
                    }
                    else
                    {
                        continue;
                    }

                    object resultado =
                        metodo.Invoke(
                            tipoBarra,
                            new object[]
                            {
                            argumento
                            });

                    if (resultado != null)
                    {
                        return
                            System.Convert.ToDouble(
                                resultado,
                                System.Globalization.CultureInfo.InvariantCulture);
                    }
                }
            }
            catch
            {
            }

            return 0.0;
        }

        private double ObtenerZonaGanchoHorizontalPiesVista(
            bool superior)
        {
            if (!chkHorizontales.Checked ||
                !chkVerticales.Checked)
            {
                return 0.0;
            }

            int angulo =
                superior
                    ? anguloGanchoSuperior
                    : anguloGanchoInferior;

            if (angulo == 0)
                return 0.0;

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double diamHor =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            Autodesk.Revit.DB.Structure.RebarBarType barraVertical =
                cmbTipoVertical != null
                    ? cmbTipoVertical.SelectedItem as
                        Autodesk.Revit.DB.Structure.RebarBarType
                    : null;

            double diametroCurvado =
                ObtenerValorDoublePorReflexion(
                    barraVertical,
                    "StandardHookBendDiameter");

            if (diametroCurvado <= 1e-9)
            {
                diametroCurvado =
                    ObtenerValorDoublePorReflexion(
                        barraVertical,
                        "StandardBendDiameter");
            }

            // Si Revit no devuelve el diámetro de curvado,
            // usamos como respaldo un doblado típico ≈ 4db.
            if (diametroCurvado <= 1e-9)
            {
                diametroCurvado =
                    diamVert * 4.0;
            }

            double radioCurvado =
                diametroCurvado * 0.5;

            double centroHorizontalDesdeCara =
                rec +
                diamHor * 0.5;

            // Centro REAL de curvatura del gancho:
            // recubrimiento + radio de barra + radio de doblado.
            double centroCurvaturaDesdeCara =
                rec +
                diamVert * 0.5 +
                radioCurvado;

            double ajusteCm =
                superior
                    ? ajusteSeccionSuperiorCm
                    : ajusteSeccionInferiorCm;

            centroCurvaturaDesdeCara +=
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ajusteCm,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            return
                System.Math.Max(
                    0.0,
                    centroCurvaturaDesdeCara -
                    centroHorizontalDesdeCara);
        }

        private void DibujarLimitesHorizontalesPorGancho(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                vistaSeccionActual == null ||
                !chkHorizontales.Checked)
            {
                return;
            }

            double zonaInf =
                ObtenerZonaGanchoHorizontalPiesVista(
                    false);

            double zonaSup =
                ObtenerZonaGanchoHorizontalPiesVista(
                    true);

            if (zonaInf <= 1e-9 &&
                zonaSup <= 1e-9)
            {
                return;
            }

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamHor =
                ObtenerDiametroBarraVista(
                    cmbTipoHorizontal);

            double baseHorizontal =
                rec +
                diamHor * 0.5;

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            225, 125, 35),
                        1.1F))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush brush =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            190, 90, 20)))
            {
                pen.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                float x1 =
                    PantallaXSeccion(
                        -seccionEspesorActual * 0.5);

                float x2 =
                    PantallaXSeccion(
                        seccionEspesorActual * 0.5);

                if (zonaInf > 1e-9)
                {
                    double z =
                        baseHorizontal +
                        zonaInf;

                    float y =
                        PantallaYSeccion(z);

                    g.DrawLine(
                        pen,
                        x1,
                        y,
                        x2,
                        y);

                    g.DrawString(
                        "H inferior = centro real curvatura",
                        fuente,
                        brush,
                        x2 + 7F,
                        y - 8F);
                }

                if (zonaSup > 1e-9)
                {
                    double z =
                        seccionAlturaActual -
                        baseHorizontal -
                        zonaSup;

                    float y =
                        PantallaYSeccion(z);

                    g.DrawLine(
                        pen,
                        x1,
                        y,
                        x2,
                        y);

                    g.DrawString(
                        "H superior = centro real curvatura",
                        fuente,
                        brush,
                        x2 + 7F,
                        y - 8F);
                }
            }
        }

        private void AgregarCotaExtensionGanchoSiNoExiste(
            System.Collections.Generic.List<double> cotas,
            double z)
        {
            if (cotas == null)
                return;

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        2.0,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            foreach (
                double existente
                in cotas)
            {
                if (System.Math.Abs(
                        existente -
                        z) <=
                    tolerancia)
                {
                    return;
                }
            }

            cotas.Add(z);
        }

        private void ObtenerCotasLimiteCurvaturaGanchoEnExtensiones(
            out System.Collections.Generic.List<double> inferiores,
            out System.Collections.Generic.List<double> superiores)
        {
            inferiores =
                new System.Collections.Generic.List<double>();

            superiores =
                new System.Collections.Generic.List<double>();

            if (vistaSeccionActual == null ||
                chkVerticales == null ||
                !chkVerticales.Checked)
            {
                return;
            }

            double altura =
                vistaSeccionActual.Altura;

            double tolerancia =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        0.5,
                        Autodesk.Revit.DB.UnitTypeId.Millimeters);

            // -----------------------------------------------------
            // GRUPOS VERTICALES YA CREADOS
            // -----------------------------------------------------
            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                System.Drawing.PointF inicio =
                    ObtenerInicioModeloGrupoVertical2P(
                        grupo);

                System.Drawing.PointF fin =
                    ObtenerFinModeloGrupoVertical2P(
                        grupo);

                double zInf =
                    System.Math.Min(
                        inicio.Y,
                        fin.Y);

                double zSup =
                    System.Math.Max(
                        inicio.Y,
                        fin.Y);

                // El centro REAL de la curvatura del gancho queda
                // sobre la misma cota Z del punto de tangencia del
                // vertical. En la preview ese punto es precisamente
                // el extremo inferior/superior del grupo.
                if (anguloGanchoInferior != 0 &&
                    zInf < -tolerancia)
                {
                    AgregarCotaExtensionGanchoSiNoExiste(
                        inferiores,
                        zInf);
                }

                if (anguloGanchoSuperior != 0 &&
                    zSup > altura + tolerancia)
                {
                    AgregarCotaExtensionGanchoSiNoExiste(
                        superiores,
                        zSup);
                }
            }

            // -----------------------------------------------------
            // DURANTE CREAR V 2 PTOS
            // -----------------------------------------------------
            if (creandoVerticalDosPuntos)
            {
                double zInf =
                    System.Math.Min(
                        vertical2PInicioZ,
                        vertical2PFinZ);

                double zSup =
                    System.Math.Max(
                        vertical2PInicioZ,
                        vertical2PFinZ);

                if (anguloGanchoInferior != 0 &&
                    zInf < -tolerancia)
                {
                    AgregarCotaExtensionGanchoSiNoExiste(
                        inferiores,
                        zInf);
                }

                if (anguloGanchoSuperior != 0 &&
                    zSup > altura + tolerancia)
                {
                    AgregarCotaExtensionGanchoSiNoExiste(
                        superiores,
                        zSup);
                }
            }
        }

        private void DibujarLimitesCurvaturaGanchoEnExtensiones(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                vistaSeccionActual == null ||
                chkVerticales == null ||
                !chkVerticales.Checked)
            {
                return;
            }

            if (anguloGanchoInferior == 0 &&
                anguloGanchoSuperior == 0)
            {
                return;
            }

            System.Collections.Generic.List<double> inferiores;
            System.Collections.Generic.List<double> superiores;

            ObtenerCotasLimiteCurvaturaGanchoEnExtensiones(
                out inferiores,
                out superiores);

            if (inferiores.Count == 0 &&
                superiores.Count == 0)
            {
                return;
            }

            double espesor =
                vistaSeccionActual.Espesor;

            double nucleoMin =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMinDesdeCentro
                    : -espesor * 0.5;

            double nucleoMax =
                vistaSeccionActual.TieneNucleo
                    ? vistaSeccionActual.NucleoMaxDesdeCentro
                    : espesor * 0.5;

            float x1 =
                PantallaXSeccion(
                    nucleoMin);

            float x2 =
                PantallaXSeccion(
                    nucleoMax);

            // La línea se prolonga un poco hacia ambos lados para que
            // siga siendo legible aun cuando coincida con el gancho.
            float extensionGrafica =
                10F;

            x1 -= extensionGrafica;
            x2 += extensionGrafica;

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            225,
                            125,
                            35),
                        1.15F))
            using (
                System.Drawing.Brush brush =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            190,
                            90,
                            20)))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F,
                        System.Drawing.FontStyle.Bold))
            {
                pen.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                pen.DashPattern =
                    new float[]
                    {
                    5F,
                    3F
                    };

                foreach (
                    double z
                    in inferiores)
                {
                    float y =
                        PantallaYSeccion(z);

                    g.DrawLine(
                        pen,
                        x1,
                        y,
                        x2,
                        y);

                    g.DrawString(
                        "LIMITE H INF EXT. - CURVATURA GANCHO",
                        fuente,
                        brush,
                        x2 + 7F,
                        y - 8F);
                }

                foreach (
                    double z
                    in superiores)
                {
                    float y =
                        PantallaYSeccion(z);

                    g.DrawLine(
                        pen,
                        x1,
                        y,
                        x2,
                        y);

                    g.DrawString(
                        "LIMITE H SUP EXT. - CURVATURA GANCHO",
                        fuente,
                        brush,
                        x2 + 7F,
                        y - 8F);
                }
            }
        }


        private void ActualizarControlesLongitudGanchoManual(
            bool completarValorAutomatico)
        {
            if (chkLongGanchoSupManual == null ||
                chkLongGanchoInfManual == null ||
                txtLongGanchoSup == null ||
                txtLongGanchoInf == null)
            {
                return;
            }

            bool haySup =
                anguloGanchoSuperior != 0;

            bool hayInf =
                anguloGanchoInferior != 0;

            chkLongGanchoSupManual.Enabled =
                haySup;

            chkLongGanchoInfManual.Enabled =
                hayInf;

            if (!haySup)
                chkLongGanchoSupManual.Checked = false;

            if (!hayInf)
                chkLongGanchoInfManual.Checked = false;

            txtLongGanchoSup.Enabled =
                haySup &&
                chkLongGanchoSupManual.Checked;

            txtLongGanchoInf.Enabled =
                hayInf &&
                chkLongGanchoInfManual.Checked;

            if (completarValorAutomatico)
            {
                if (txtLongGanchoSup.Enabled &&
                    string.IsNullOrWhiteSpace(
                        txtLongGanchoSup.Text))
                {
                    double cm =
                        ObtenerLongitudGanchoActualCm(
                            true);

                    txtLongGanchoSup.Text =
                        cm.ToString("0.0");
                }

                if (txtLongGanchoInf.Enabled &&
                    string.IsNullOrWhiteSpace(
                        txtLongGanchoInf.Text))
                {
                    double cm =
                        ObtenerLongitudGanchoActualCm(
                            false);

                    txtLongGanchoInf.Text =
                        cm.ToString("0.0");
                }
            }
        }

        private double ObtenerLongitudGanchoActualCm(
            bool superior)
        {
            Autodesk.Revit.DB.Structure.RebarBarType barra =
                ResolverTipoBarra(
                    cmbTipoVertical);

            Autodesk.Revit.DB.Structure.RebarHookType hook =
                ObtenerTipoGanchoPorAngulo(
                    superior
                        ? anguloGanchoSuperior
                        : anguloGanchoInferior);

            if (barra == null ||
                hook == null)
            {
                return 10.0;
            }

            try
            {
                System.Reflection.MethodInfo metodo =
                    barra.GetType().GetMethod(
                        "GetHookLength",
                        new System.Type[]
                        {
                        typeof(
                            Autodesk.Revit.DB.ElementId)
                        });

                if (metodo != null)
                {
                    object resultado =
                        metodo.Invoke(
                            barra,
                            new object[]
                            {
                            hook.Id
                            });

                    if (resultado != null)
                    {
                        double pies =
                            System.Convert.ToDouble(
                                resultado,
                                System.Globalization.CultureInfo.InvariantCulture);

                        double cm =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    pies,
                                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

                        if (cm > 0.01)
                            return cm;
                    }
                }
            }
            catch
            {
            }

            return 10.0;
        }

        private double ObtenerLongitudGanchoPreviewCm(
            bool superior)
        {
            System.Windows.Forms.CheckBox chk =
                superior
                    ? chkLongGanchoSupManual
                    : chkLongGanchoInfManual;

            System.Windows.Forms.TextBox txt =
                superior
                    ? txtLongGanchoSup
                    : txtLongGanchoInf;

            if (chk != null &&
                chk.Checked &&
                txt != null)
            {
                double cm;

                if (TryLeerLongitudCm(
                    txt.Text,
                    out cm) &&
                    cm > 0.0)
                {
                    return cm;
                }
            }

            return
                ObtenerLongitudGanchoActualCm(
                    superior);
        }

        private float ConvertirLongitudGanchoAPixeles(
            double longitudCm,
            bool horizontal)
        {
            double pies =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        System.Math.Max(
                            0.1,
                            longitudCm),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double pxPorPie =
                seccionEscalaActual;

            if (horizontal)
            {
                pxPorPie *=
                    seccionFactorExageracionX;
            }

            float px =
                (float)(
                    pies *
                    pxPorPie);

            return
                System.Math.Max(
                    12F,
                    System.Math.Min(
                        180F,
                        px));
        }


        private void DibujarSelectoresGancho(
            System.Drawing.Graphics g)
        {
            rectSelectorGanchoInferior =
                System.Drawing.RectangleF.Empty;

            rectSelectorGanchoSuperior =
                System.Drawing.RectangleF.Empty;

            if (g == null ||
                vistaSeccionActual == null ||
                !chkVerticales.Checked)
            {
                return;
            }

            string txtSup =
                "GANCHO SUP: " +
                TextoAnguloGancho(
                    anguloGanchoSuperior) +
                (chkLongGanchoSupManual != null &&
                 chkLongGanchoSupManual.Checked
                    ? " | L MANUAL"
                    : "");

            string txtInf =
                "GANCHO INF: " +
                TextoAnguloGancho(
                    anguloGanchoInferior) +
                (chkLongGanchoInfManual != null &&
                 chkLongGanchoInfManual.Checked
                    ? " | L MANUAL"
                    : "");

            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.5F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush fondo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            242, 247, 252)))
            using (
                System.Drawing.Brush fondoActivo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            215, 235, 252)))
            using (
                System.Drawing.Pen borde =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            75, 125, 175),
                        1.0F))
            using (
                System.Drawing.Brush texto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            30, 80, 130)))
            {
                System.Drawing.SizeF tamSup =
                    g.MeasureString(
                        txtSup,
                        fuente);

                System.Drawing.SizeF tamInf =
                    g.MeasureString(
                        txtInf,
                        fuente);

                float x =
                    16F;

                float ySup =
                    68F;

                rectSelectorGanchoSuperior =
                    new System.Drawing.RectangleF(
                        x,
                        ySup,
                        System.Math.Max(
                            120F,
                            tamSup.Width + 16F),
                        23F);

                rectSelectorGanchoInferior =
                    new System.Drawing.RectangleF(
                        x,
                        ySup + 27F,
                        System.Math.Max(
                            120F,
                            tamInf.Width + 16F),
                        23F);

                g.FillRectangle(
                    anguloGanchoSuperior == 0
                        ? fondo
                        : fondoActivo,
                    rectSelectorGanchoSuperior);

                g.DrawRectangle(
                    borde,
                    rectSelectorGanchoSuperior.X,
                    rectSelectorGanchoSuperior.Y,
                    rectSelectorGanchoSuperior.Width,
                    rectSelectorGanchoSuperior.Height);

                g.DrawString(
                    txtSup,
                    fuente,
                    texto,
                    rectSelectorGanchoSuperior.X + 7F,
                    rectSelectorGanchoSuperior.Y + 4F);

                g.FillRectangle(
                    anguloGanchoInferior == 0
                        ? fondo
                        : fondoActivo,
                    rectSelectorGanchoInferior);

                g.DrawRectangle(
                    borde,
                    rectSelectorGanchoInferior.X,
                    rectSelectorGanchoInferior.Y,
                    rectSelectorGanchoInferior.Width,
                    rectSelectorGanchoInferior.Height);

                g.DrawString(
                    txtInf,
                    fuente,
                    texto,
                    rectSelectorGanchoInferior.X + 7F,
                    rectSelectorGanchoInferior.Y + 4F);
            }
        }

        private string TextoAnguloGancho(
            int angulo)
        {
            if (angulo == 90)
                return "90°";

            if (angulo == 180)
                return "180°";

            return "NINGUNO";
        }

        private bool ProcesarClickSelectorGancho(
            System.Drawing.Point punto)
        {
            if (rectSelectorGanchoSuperior.Contains(
                punto))
            {
                MostrarMenuGancho(
                    true,
                    punto);

                return true;
            }

            if (rectSelectorGanchoInferior.Contains(
                punto))
            {
                MostrarMenuGancho(
                    false,
                    punto);

                return true;
            }

            return false;
        }

        private void MostrarMenuGancho(
            bool superior,
            System.Drawing.Point punto)
        {
            System.Windows.Forms.ContextMenuStrip menu =
                new System.Windows.Forms.ContextMenuStrip();

            System.Action<string, int> agregar =
                (texto, angulo) =>
                {
                    System.Windows.Forms.ToolStripMenuItem item =
                        new System.Windows.Forms.ToolStripMenuItem(
                            texto);

                    int actual =
                        superior
                            ? anguloGanchoSuperior
                            : anguloGanchoInferior;

                    item.Checked =
                        actual == angulo;

                    item.Click +=
                        (s, e) =>
                            EstablecerGanchoVertical(
                                superior,
                                angulo);

                    menu.Items.Add(
                        item);
                };

            agregar(
                "Sin gancho",
                0);

            agregar(
                "Gancho 90°",
                90);

            agregar(
                "Gancho 180°",
                180);

            menu.Show(
                pnlVistaSeccion,
                punto);
        }

        private void EstablecerGanchoVertical(
            bool superior,
            int angulo)
        {
            if (angulo != 0 &&
                angulo != 90 &&
                angulo != 180)
            {
                return;
            }

            RegistrarDeshacer();

            if (superior)
                anguloGanchoSuperior = angulo;
            else
                anguloGanchoInferior = angulo;

            ActualizarControlesLongitudGanchoManual(
                true);

            GuardarValoresRecordados();

            ActualizarGruposVinculadosAGuiasSeccion();
            ActualizarGruposVerticalesVinculadosAGuias();

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();

            ActualizarEstado(
                (superior
                    ? "Gancho superior: "
                    : "Gancho inferior: ") +
                TextoAnguloGancho(
                    angulo));
        }

        private void DibujarGanchosVerticales(
            System.Drawing.Graphics g)
        {
            if (g == null ||
                vistaSeccionActual == null ||
                !chkVerticales.Checked ||
                gruposVerticales2Puntos.Count == 0)
            {
                return;
            }

            if (anguloGanchoInferior == 0 &&
                anguloGanchoSuperior == 0)
            {
                return;
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo == null)
                    continue;

                Autodesk.Revit.DB.Structure.RebarBarType tipoGrupo =
                    ResolverTipoBarraGrupo(
                        grupo.TipoBarraId,
                        grupo.TipoBarraNombre,
                        cmbTipoVertical);

                double diametroGrupo =
                    tipoGrupo != null
                        ? ObtenerDiametroBarraVistaDesdeTipo(
                            tipoGrupo)
                        : ObtenerDiametroBarraVista(
                            cmbTipoVertical);

                System.Drawing.Color colorDiametro =
                    ObtenerColorTipoBarraGrupo(
                        tipoGrupo,
                        diametroGrupo);

                bool seleccionado =
                    EsGrupoVerticalSeleccionado(
                        grupo.Id);

                float grosor =
                    seleccionado
                        ? 3.2F
                        : 2.4F;

                using (
                    System.Drawing.Pen pen =
                        new System.Drawing.Pen(
                            colorDiametro,
                            grosor))
                using (
                    System.Drawing.Pen halo =
                        new System.Drawing.Pen(
                            System.Drawing.Color.FromArgb(
                                65,
                                colorDiametro.R,
                                colorDiametro.G,
                                colorDiametro.B),
                            7.0F))
                {
                    System.Drawing.PointF a =
                        ObtenerInicioModeloGrupoVertical2P(
                            grupo);

                    System.Drawing.PointF b =
                        ObtenerFinModeloGrupoVertical2P(
                            grupo);

                    System.Drawing.PointF inferior =
                        a.Y <= b.Y
                            ? a
                            : b;

                    System.Drawing.PointF superior =
                        a.Y <= b.Y
                            ? b
                            : a;

                    double uMedio =
                        (grupo.InicioU +
                         grupo.FinU) * 0.5;

                    int cara =
                        uMedio < 0.49
                            ? 1
                            : uMedio > 0.51
                                ? -1
                                : 0;

                    int direccion =
                        ObtenerDireccionGanchoPreview(
                            cara);

                    if (anguloGanchoSuperior != 0)
                    {
                        if (seleccionado)
                        {
                            DibujarGanchoPreview(
                                g,
                                halo,
                                PantallaXSeccion(
                                    superior.X),
                                PantallaYSeccion(
                                    superior.Y),
                                direccion,
                                true,
                                anguloGanchoSuperior,
                                ObtenerLongitudGanchoPreviewCm(
                                    true));
                        }

                        DibujarGanchoPreview(
                            g,
                            pen,
                            PantallaXSeccion(
                                superior.X),
                            PantallaYSeccion(
                                superior.Y),
                            direccion,
                            true,
                            anguloGanchoSuperior,
                            ObtenerLongitudGanchoPreviewCm(
                                true));
                    }

                    if (anguloGanchoInferior != 0)
                    {
                        if (seleccionado)
                        {
                            DibujarGanchoPreview(
                                g,
                                halo,
                                PantallaXSeccion(
                                    inferior.X),
                                PantallaYSeccion(
                                    inferior.Y),
                                direccion,
                                false,
                                anguloGanchoInferior,
                                ObtenerLongitudGanchoPreviewCm(
                                    false));
                        }

                        DibujarGanchoPreview(
                            g,
                            pen,
                            PantallaXSeccion(
                                inferior.X),
                            PantallaYSeccion(
                                inferior.Y),
                            direccion,
                            false,
                            anguloGanchoInferior,
                            ObtenerLongitudGanchoPreviewCm(
                                false));
                    }
                }
            }
        }

        private void DibujarGanchoPreview(
            System.Drawing.Graphics g,
            System.Drawing.Pen pen,
            float x,
            float y,
            int direccion,
            bool superior,
            int angulo,
            double longitudGanchoCm)
        {
            float dir =
                direccion >= 0
                    ? 1F
                    : -1F;

            float radio =
                8F;

            if (angulo == 90)
            {
                float largo90 =
                    ConvertirLongitudGanchoAPixeles(
                        longitudGanchoCm,
                        true);

                // Representación sencilla:
                // la longitud visual responde al valor real/manual.
                g.DrawLine(
                    pen,
                    x,
                    y,
                    x + dir * largo90,
                    y);

                return;
            }

            if (angulo == 180)
            {
                float longitudTotalPx =
                    ConvertirLongitudGanchoAPixeles(
                        longitudGanchoCm,
                        false);

                // El arco consume una parte de la longitud total.
                // El resto se representa como cola recta.
                float cola =
                    System.Math.Max(
                        8F,
                        longitudTotalPx -
                        (float)(
                            System.Math.PI *
                            radio));

                if (dir > 0F)
                {
                    System.Drawing.RectangleF rect =
                        new System.Drawing.RectangleF(
                            x,
                            y - radio,
                            radio * 2F,
                            radio * 2F);

                    g.DrawArc(
                        pen,
                        rect,
                        180F,
                        -180F);

                    float xFin =
                        x + radio * 2F;

                    g.DrawLine(
                        pen,
                        xFin,
                        y,
                        xFin,
                        superior
                            ? y + cola
                            : y - cola);
                }
                else
                {
                    System.Drawing.RectangleF rect =
                        new System.Drawing.RectangleF(
                            x - radio * 2F,
                            y - radio,
                            radio * 2F,
                            radio * 2F);

                    g.DrawArc(
                        pen,
                        rect,
                        0F,
                        -180F);

                    float xFin =
                        x - radio * 2F;

                    g.DrawLine(
                        pen,
                        xFin,
                        y,
                        xFin,
                        superior
                            ? y + cola
                            : y - cola);
                }

                return;
            }
        }

        private bool TryObtenerExtremosVerticalManualParaCota(
            out double zInferior,
            out double zSuperior,
            out bool inferiorEsInicio,
            out bool superiorEsInicio)
        {
            zInferior = 0.0;
            zSuperior = 0.0;
            inferiorEsInicio = true;
            superiorEsInicio = false;

            if (vistaSeccionActual == null)
                return false;

            // -----------------------------------------------------
            // 1. DURANTE CREAR V 2 PTOS
            // -----------------------------------------------------
            if (creandoVerticalDosPuntos)
            {
                double z0 =
                    vertical2PInicioZ;

                double z1 =
                    vertical2PFinZ;

                if (z0 <= z1)
                {
                    zInferior = z0;
                    zSuperior = z1;
                    inferiorEsInicio = true;
                    superiorEsInicio = false;
                }
                else
                {
                    zInferior = z1;
                    zSuperior = z0;
                    inferiorEsInicio = false;
                    superiorEsInicio = true;
                }

                return true;
            }

            // -----------------------------------------------------
            // 2. GRUPO VERTICAL MANUAL SELECCIONADO
            // -----------------------------------------------------
            if (!string.IsNullOrWhiteSpace(
                grupoVertical2PSeleccionadoId))
            {
                AceroMuroGrupoVertical2Puntos grupo =
                    ObtenerGrupoVertical2PuntosPorId(
                        grupoVertical2PSeleccionadoId);

                if (grupo != null)
                {
                    System.Drawing.PointF inicio =
                        ObtenerInicioModeloGrupoVertical2P(
                            grupo);

                    System.Drawing.PointF fin =
                        ObtenerFinModeloGrupoVertical2P(
                            grupo);

                    if (inicio.Y <= fin.Y)
                    {
                        zInferior = inicio.Y;
                        zSuperior = fin.Y;
                        inferiorEsInicio = true;
                        superiorEsInicio = false;
                    }
                    else
                    {
                        zInferior = fin.Y;
                        zSuperior = inicio.Y;
                        inferiorEsInicio = false;
                        superiorEsInicio = true;
                    }

                    return true;
                }
            }

            return false;
        }

        private bool HayGrupoVerticalManualActivoParaCota()
        {
            if (creandoVerticalDosPuntos)
                return true;

            if (string.IsNullOrWhiteSpace(
                grupoVertical2PSeleccionadoId))
            {
                return false;
            }

            return
                ObtenerGrupoVertical2PuntosPorId(
                    grupoVertical2PSeleccionadoId) != null;
        }

        private void AplicarExtensionGrupoVerticalManualMetros(
            bool superior,
            double extensionM)
        {
            if (vistaSeccionActual == null)
                return;

            AceroMuroGrupoVertical2Puntos grupo =
                ObtenerGrupoVertical2PuntosPorId(
                    grupoVertical2PSeleccionadoId);

            if (grupo == null)
                return;

            extensionM =
                System.Math.Max(
                    0.0,
                    extensionM);

            double extensionPies =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        extensionM,
                        Autodesk.Revit.DB.UnitTypeId.Meters);

            System.Drawing.PointF inicio =
                ObtenerInicioModeloGrupoVertical2P(
                    grupo);

            System.Drawing.PointF fin =
                ObtenerFinModeloGrupoVertical2P(
                    grupo);

            bool inferiorEsInicio =
                inicio.Y <= fin.Y;

            bool superiorEsInicio =
                inicio.Y > fin.Y;

            double zObjetivo =
                superior
                    ? vistaSeccionActual.Altura +
                        extensionPies
                    : -extensionPies;

            RegistrarDeshacer();

            if (superior)
            {
                if (superiorEsInicio)
                {
                    System.Drawing.PointF normal =
                        CrearPuntoNormalizadoSeccion2P(
                            inicio.X,
                            zObjetivo);

                    grupo.InicioU =
                        normal.X;

                    grupo.InicioV =
                        normal.Y;

                    // La cota manual pasa a gobernar Z.
                    grupo.InicioVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;
                }
                else
                {
                    System.Drawing.PointF normal =
                        CrearPuntoNormalizadoSeccion2P(
                            fin.X,
                            zObjetivo);

                    grupo.FinU =
                        normal.X;

                    grupo.FinV =
                        normal.Y;

                    grupo.FinVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;
                }
            }
            else
            {
                if (inferiorEsInicio)
                {
                    System.Drawing.PointF normal =
                        CrearPuntoNormalizadoSeccion2P(
                            inicio.X,
                            zObjetivo);

                    grupo.InicioU =
                        normal.X;

                    grupo.InicioV =
                        normal.Y;

                    grupo.InicioVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;
                }
                else
                {
                    System.Drawing.PointF normal =
                        CrearPuntoNormalizadoSeccion2P(
                            fin.X,
                            zObjetivo);

                    grupo.FinU =
                        normal.X;

                    grupo.FinV =
                        normal.Y;

                    grupo.FinVinculoVertical =
                        AceroMuroVinculoVertical2P.Ninguno;
                }
            }

            if (pnlVistaSeccion != null)
                pnlVistaSeccion.Invalidate();

            if (pnlVistaAlzado != null)
                pnlVistaAlzado.Invalidate();

            ActualizarEstado(
                superior
                    ? "Desfase superior del vertical: " +
                        extensionM.ToString("0.###") +
                        " m fuera del anfitrión."
                    : "Desfase inferior del vertical: " +
                        extensionM.ToString("0.###") +
                        " m fuera del anfitrión.");
        }


        private double ObtenerBaseVerticalCm()
        {
            double recCm =
                ObtenerRecubrimientoCmActual();

            double diamPies =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double diamCm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        diamPies,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            return recCm +
                diamCm * 0.5;
        }

        private double ObtenerExtensionVerticalInferiorCm()
        {
            if (vistaSeccionActual == null)
                return 0.0;

            // -----------------------------------------------------
            // V8.52:
            // Para grupos V 2 PTOS, la cota se obtiene de la
            // geometría REAL que el usuario dibujó.
            // -----------------------------------------------------
            double zInf;
            double zSup;
            bool infInicio;
            bool supInicio;

            if (TryObtenerExtremosVerticalManualParaCota(
                out zInf,
                out zSup,
                out infInicio,
                out supInicio))
            {
                if (zInf >= -1e-9)
                    return 0.0;

                double extensionPies =
                    -zInf;

                return
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            extensionPies,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }

            // Compatibilidad con la lógica vertical antigua.
            double baseCm =
                ObtenerBaseVerticalCm();

            double zInferiorCm =
                baseCm +
                ajusteSeccionInferiorCm;

            return
                System.Math.Max(
                    0.0,
                    -zInferiorCm);
        }

        private double ObtenerExtensionVerticalSuperiorCm()
        {
            if (vistaSeccionActual == null)
                return 0.0;

            double zInf;
            double zSup;
            bool infInicio;
            bool supInicio;

            if (TryObtenerExtremosVerticalManualParaCota(
                out zInf,
                out zSup,
                out infInicio,
                out supInicio))
            {
                double exceso =
                    zSup -
                    vistaSeccionActual.Altura;

                if (exceso <= 1e-9)
                    return 0.0;

                return
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            exceso,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }

            // Compatibilidad con la lógica vertical antigua.
            double alturaCm =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        vistaSeccionActual.Altura,
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double baseCm =
                ObtenerBaseVerticalCm();

            double zSuperiorCm =
                alturaCm -
                baseCm -
                ajusteSeccionSuperiorCm;

            return
                System.Math.Max(
                    0.0,
                    zSuperiorCm -
                    alturaCm);
        }

        private void DibujarCotasExtensionVertical(
            System.Drawing.Graphics g)
        {
            cotaExtensionInferiorVisible = false;
            cotaExtensionSuperiorVisible = false;

            rectCotaExtensionInferior =
                System.Drawing.RectangleF.Empty;

            rectCotaExtensionSuperior =
                System.Drawing.RectangleF.Empty;

            if (g == null ||
                vistaSeccionActual == null ||
                chkVerticales == null ||
                !chkVerticales.Checked)
            {
                return;
            }

            double extensionInfCm =
                ObtenerExtensionVerticalInferiorCm();

            double extensionSupCm =
                ObtenerExtensionVerticalSuperiorCm();

            if (extensionInfCm <= 0.001 &&
                extensionSupCm <= 0.001)
            {
                return;
            }

            double altura =
                vistaSeccionActual.Altura;

            // -----------------------------------------------------
            // Coordenadas REALES del vertical manual.
            // -----------------------------------------------------
            double zInfPies;
            double zSupPies;

            double zInfManual;
            double zSupManual;
            bool infInicio;
            bool supInicio;

            bool manual =
                TryObtenerExtremosVerticalManualParaCota(
                    out zInfManual,
                    out zSupManual,
                    out infInicio,
                    out supInicio);

            if (manual)
            {
                zInfPies =
                    zInfManual;

                zSupPies =
                    zSupManual;
            }
            else
            {
                double baseCm =
                    ObtenerBaseVerticalCm();

                double zInfCm =
                    baseCm +
                    ajusteSeccionInferiorCm;

                double alturaCm =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            altura,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                double zSupCm =
                    alturaCm -
                    baseCm -
                    ajusteSeccionSuperiorCm;

                zInfPies =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            zInfCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);

                zSupPies =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertToInternalUnits(
                            zSupCm,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
            }

            // -----------------------------------------------------
            // Ubicación horizontal de la cota.
            //
            // Para un grupo manual la colocamos a la derecha del
            // vertical seleccionado, pero nunca dentro del muro.
            // -----------------------------------------------------
            double xReferenciaModelo =
                seccionEspesorActual *
                0.5;

            if (manual &&
                !creandoVerticalDosPuntos)
            {
                AceroMuroGrupoVertical2Puntos grupo =
                    ObtenerGrupoVertical2PuntosPorId(
                        grupoVertical2PSeleccionadoId);

                if (grupo != null)
                {
                    System.Drawing.PointF pi =
                        ObtenerInicioModeloGrupoVertical2P(
                            grupo);

                    System.Drawing.PointF pf =
                        ObtenerFinModeloGrupoVertical2P(
                            grupo);

                    xReferenciaModelo =
                        System.Math.Max(
                            xReferenciaModelo,
                            System.Math.Max(
                                pi.X,
                                pf.X));
                }
            }
            else if (manual &&
                     creandoVerticalDosPuntos)
            {
                xReferenciaModelo =
                    System.Math.Max(
                        xReferenciaModelo,
                        System.Math.Max(
                            vertical2PInicioX,
                            vertical2PFinX));
            }

            float xReferencia =
                PantallaXSeccion(
                    xReferenciaModelo);

            float xCota =
                xReferencia +
                32F;

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            55,
                            105,
                            160),
                        1.2F))
            using (
                System.Drawing.Pen penAux =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            120,
                            155,
                            190),
                        0.9F))
            using (
                System.Drawing.Brush brushTexto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            25,
                            80,
                            140)))
            using (
                System.Drawing.Brush brushFondo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            245,
                            250,
                            255)))
            using (
                System.Drawing.Pen penCaja =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            115,
                            165,
                            210),
                        1.0F))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8F,
                        System.Drawing.FontStyle.Bold))
            {
                penAux.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dot;

                // =================================================
                // DESFASE INFERIOR
                // =================================================
                if (extensionInfCm > 0.001)
                {
                    float yAnfitrion =
                        PantallaYSeccion(
                            0.0);

                    float yAcero =
                        PantallaYSeccion(
                            zInfPies);

                    // Proyección desde el anfitrión hasta la cota.
                    g.DrawLine(
                        penAux,
                        xReferencia,
                        yAnfitrion,
                        xCota,
                        yAnfitrion);

                    g.DrawLine(
                        penAux,
                        xReferencia,
                        yAcero,
                        xCota,
                        yAcero);

                    // Línea de dimensión.
                    g.DrawLine(
                        pen,
                        xCota,
                        yAnfitrion,
                        xCota,
                        yAcero);

                    g.DrawLine(
                        pen,
                        xCota - 5F,
                        yAnfitrion,
                        xCota + 5F,
                        yAnfitrion);

                    g.DrawLine(
                        pen,
                        xCota - 5F,
                        yAcero,
                        xCota + 5F,
                        yAcero);

                    double extensionInfM =
                        extensionInfCm /
                        100.0;

                    string texto =
                        extensionInfM
                            .ToString("0.###") +
                        " m";

                    System.Drawing.SizeF tam =
                        g.MeasureString(
                            texto,
                            fuente);

                    float xTexto =
                        xCota +
                        8F;

                    float yTexto =
                        (yAnfitrion +
                         yAcero) *
                        0.5F -
                        tam.Height *
                        0.5F;

                    rectCotaExtensionInferior =
                        new System.Drawing.RectangleF(
                            xTexto - 3F,
                            yTexto - 2F,
                            tam.Width + 6F,
                            tam.Height + 4F);

                    g.FillRectangle(
                        brushFondo,
                        rectCotaExtensionInferior);

                    g.DrawRectangle(
                        penCaja,
                        rectCotaExtensionInferior.X,
                        rectCotaExtensionInferior.Y,
                        rectCotaExtensionInferior.Width,
                        rectCotaExtensionInferior.Height);

                    g.DrawString(
                        texto,
                        fuente,
                        brushTexto,
                        xTexto,
                        yTexto);

                    cotaExtensionInferiorVisible =
                        true;
                }

                // =================================================
                // DESFASE SUPERIOR
                // =================================================
                if (extensionSupCm > 0.001)
                {
                    float yAnfitrion =
                        PantallaYSeccion(
                            altura);

                    float yAcero =
                        PantallaYSeccion(
                            zSupPies);

                    g.DrawLine(
                        penAux,
                        xReferencia,
                        yAnfitrion,
                        xCota,
                        yAnfitrion);

                    g.DrawLine(
                        penAux,
                        xReferencia,
                        yAcero,
                        xCota,
                        yAcero);

                    g.DrawLine(
                        pen,
                        xCota,
                        yAnfitrion,
                        xCota,
                        yAcero);

                    g.DrawLine(
                        pen,
                        xCota - 5F,
                        yAnfitrion,
                        xCota + 5F,
                        yAnfitrion);

                    g.DrawLine(
                        pen,
                        xCota - 5F,
                        yAcero,
                        xCota + 5F,
                        yAcero);

                    double extensionSupM =
                        extensionSupCm /
                        100.0;

                    string texto =
                        extensionSupM
                            .ToString("0.###") +
                        " m";

                    System.Drawing.SizeF tam =
                        g.MeasureString(
                            texto,
                            fuente);

                    float xTexto =
                        xCota +
                        8F;

                    float yTexto =
                        (yAnfitrion +
                         yAcero) *
                        0.5F -
                        tam.Height *
                        0.5F;

                    rectCotaExtensionSuperior =
                        new System.Drawing.RectangleF(
                            xTexto - 3F,
                            yTexto - 2F,
                            tam.Width + 6F,
                            tam.Height + 4F);

                    g.FillRectangle(
                        brushFondo,
                        rectCotaExtensionSuperior);

                    g.DrawRectangle(
                        penCaja,
                        rectCotaExtensionSuperior.X,
                        rectCotaExtensionSuperior.Y,
                        rectCotaExtensionSuperior.Width,
                        rectCotaExtensionSuperior.Height);

                    g.DrawString(
                        texto,
                        fuente,
                        brushTexto,
                        xTexto,
                        yTexto);

                    cotaExtensionSuperiorVisible =
                        true;
                }
            }
        }

        private bool PuntoSobreCotaExtensionVertical(
            System.Drawing.Point punto)
        {
            if (cotaExtensionInferiorVisible &&
                rectCotaExtensionInferior.Contains(
                    punto))
            {
                return true;
            }

            if (cotaExtensionSuperiorVisible &&
                rectCotaExtensionSuperior.Contains(
                    punto))
            {
                return true;
            }

            return false;
        }

        private bool ProcesarClickCotaExtensionVertical(
            System.Drawing.Point punto)
        {
            if (cotaExtensionInferiorVisible &&
                rectCotaExtensionInferior.Contains(
                    punto))
            {
                IniciarEditorCotaInline(
                    false,
                    rectCotaExtensionInferior);

                return true;
            }

            if (cotaExtensionSuperiorVisible &&
                rectCotaExtensionSuperior.Contains(
                    punto))
            {
                IniciarEditorCotaInline(
                    true,
                    rectCotaExtensionSuperior);

                return true;
            }

            return false;
        }

        private void IniciarEditorCotaInline(
            bool superior,
            System.Drawing.RectangleF rectCota)
        {
            FinalizarEditorCotaInline(
                false);

            editandoCotaInline = true;
            editandoCotaSuperiorInline = superior;

            double extensionCm =
                superior
                    ? ObtenerExtensionVerticalSuperiorCm()
                    : ObtenerExtensionVerticalInferiorCm();

            double extensionM =
                extensionCm / 100.0;

            txtCotaInline =
                new System.Windows.Forms.TextBox
                {
                    BorderStyle =
                        System.Windows.Forms.BorderStyle.FixedSingle,
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            8.5F,
                            System.Drawing.FontStyle.Bold),
                    TextAlign =
                        System.Windows.Forms.HorizontalAlignment.Center,
                    Text =
                        extensionM.ToString("0.###"),
                    Width =
                        System.Math.Max(
                            64,
                            (int)rectCota.Width + 14),
                    Height = 23,
                    Left =
                        System.Math.Max(
                            2,
                            (int)rectCota.X - 4),
                    Top =
                        System.Math.Max(
                            2,
                            (int)rectCota.Y - 2)
                };

            txtCotaInline.KeyDown +=
                TxtCotaInline_KeyDown;

            txtCotaInline.LostFocus +=
                (s, e) =>
                {
                    if (editandoCotaInline)
                    {
                        FinalizarEditorCotaInline(
                            true);
                    }
                };

            pnlVistaSeccion.Controls.Add(
                txtCotaInline);

            txtCotaInline.BringToFront();
            txtCotaInline.Focus();
            txtCotaInline.SelectAll();
        }

        private void TxtCotaInline_KeyDown(
            object sender,
            System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode ==
                System.Windows.Forms.Keys.Enter)
            {
                e.SuppressKeyPress = true;

                FinalizarEditorCotaInline(
                    true);

                return;
            }

            if (e.KeyCode ==
                System.Windows.Forms.Keys.Escape)
            {
                e.SuppressKeyPress = true;

                FinalizarEditorCotaInline(
                    false);
            }
        }

        private void FinalizarEditorCotaInline(
            bool aplicar)
        {
            if (!editandoCotaInline)
                return;

            System.Windows.Forms.TextBox editor =
                txtCotaInline;

            bool superior =
                editandoCotaSuperiorInline;

            editandoCotaInline = false;
            txtCotaInline = null;

            if (editor == null)
                return;

            string texto =
                editor.Text ?? "";

            try
            {
                if (editor.Parent != null)
                {
                    editor.Parent.Controls.Remove(
                        editor);
                }
            }
            catch
            {
            }

            editor.Dispose();

            if (!aplicar)
            {
                pnlVistaSeccion.Focus();
                pnlVistaSeccion.Invalidate();
                return;
            }

            double valorM;

            if (!TryLeerMetrosInline(
                texto,
                out valorM))
            {
                ActualizarEstado(
                    "Cota no válida. Escriba un valor en metros, por ejemplo 0.25.");

                pnlVistaSeccion.Focus();
                pnlVistaSeccion.Invalidate();
                return;
            }

            AplicarExtensionVerticalMetros(
                superior,
                valorM);

            pnlVistaSeccion.Focus();
        }

        private bool TryLeerMetrosInline(
            string texto,
            out double valorM)
        {
            valorM = 0.0;

            if (string.IsNullOrWhiteSpace(
                texto))
            {
                return false;
            }

            string limpio =
                texto.Trim()
                    .ToLowerInvariant()
                    .Replace(
                        "metros",
                        "")
                    .Replace(
                        "metro",
                        "")
                    .Replace(
                        "m",
                        "")
                    .Trim()
                    .Replace(
                        ",",
                        ".");

            double valor;

            if (!double.TryParse(
                limpio,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor))
            {
                return false;
            }

            if (valor < 0.0)
                return false;

            valorM = valor;
            return true;
        }

        private void AplicarExtensionVerticalMetros(
            bool superior,
            double extensionM)
        {
            extensionM =
                System.Math.Max(
                    0.0,
                    extensionM);

            // -----------------------------------------------------
            // V8.52:
            // Un grupo V 2 PTOS seleccionado tiene prioridad.
            // La cota modifica directamente su extremo real.
            // -----------------------------------------------------
            if (!creandoVerticalDosPuntos &&
                !string.IsNullOrWhiteSpace(
                    grupoVertical2PSeleccionadoId))
            {
                AceroMuroGrupoVertical2Puntos grupo =
                    ObtenerGrupoVertical2PuntosPorId(
                        grupoVertical2PSeleccionadoId);

                if (grupo != null)
                {
                    AplicarExtensionGrupoVerticalManualMetros(
                        superior,
                        extensionM);

                    return;
                }
            }

            // -----------------------------------------------------
            // Compatibilidad con la lógica vertical antigua.
            // -----------------------------------------------------
            double extensionCm =
                extensionM *
                100.0;

            RegistrarDeshacer();

            double baseCm =
                ObtenerBaseVerticalCm();

            if (superior)
            {
                ajusteSeccionSuperiorCm =
                    -baseCm -
                    extensionCm;

                seccionHandleSeleccionado =
                    "SUP";
            }
            else
            {
                ajusteSeccionInferiorCm =
                    -baseCm -
                    extensionCm;

                seccionHandleSeleccionado =
                    "INF";
            }

            pnlVistaSeccion.Invalidate();
            pnlVistaAlzado.Invalidate();

            ActualizarEstado(
                (superior
                    ? "Extensión superior vertical: "
                    : "Extensión inferior vertical: ") +
                extensionM.ToString("0.###") +
                " m fuera del anfitrión.");
        }



        private double ObtenerDiametroBarraVistaDesdeTipo(
            Autodesk.Revit.DB.Structure.RebarBarType tipo)
        {
            if (tipo == null)
                return 0.0;

            try
            {
                Autodesk.Revit.DB.Parameter p =
                    tipo.get_Parameter(
                        Autodesk.Revit.DB.BuiltInParameter.REBAR_BAR_DIAMETER);

                if (p != null)
                    return p.AsDouble();
            }
            catch
            {
            }

            return 0.0;
        }


        private double ObtenerDiametroBarraVista(
            System.Windows.Forms.ComboBox combo)
        {
            if (combo == null)
                return 0.0;

            Autodesk.Revit.DB.Structure.RebarBarType tipo =
                combo.SelectedItem
                as Autodesk.Revit.DB.Structure.RebarBarType;

            if (tipo == null)
                return 0.0;

            Autodesk.Revit.DB.Parameter parametro =
                tipo.get_Parameter(
                    Autodesk.Revit.DB.BuiltInParameter.REBAR_BAR_DIAMETER);

            if (parametro != null &&
                parametro.StorageType ==
                Autodesk.Revit.DB.StorageType.Double)
            {
                return parametro.AsDouble();
            }

            parametro =
                tipo.LookupParameter(
                    "Diámetro de barra");

            if (parametro != null &&
                parametro.StorageType ==
                Autodesk.Revit.DB.StorageType.Double)
            {
                return parametro.AsDouble();
            }

            parametro =
                tipo.LookupParameter(
                    "Bar Diameter");

            if (parametro != null &&
                parametro.StorageType ==
                Autodesk.Revit.DB.StorageType.Double)
            {
                return parametro.AsDouble();
            }

            return 0.0;
        }

        private System.Collections.Generic.List<int>
            ObtenerCarasVista(
                int modoCaras)
        {
            System.Collections.Generic.List<int> caras =
                new System.Collections.Generic.List<int>();

            // 3 = UNA MALLA exactamente en el centro del espesor.
            if (modoCaras == 3)
            {
                caras.Add(0);
                return caras;
            }

            // 0 = DOBLE MALLA, una cortina por cada cara.
            caras.Add(1);
            caras.Add(-1);

            return caras;
        }

        private bool EsCadenaHorizontalSeleccionada(
            int cadena)
        {
            if (tramoSeleccionadoId == 0 ||
                vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return false;
            }

            AceroMuroTramoVista seleccionado =
                ObtenerTramoPorId(
                    tramoSeleccionadoId);

            return seleccionado != null &&
                seleccionado.Cadena == cadena;
        }

        private bool EsTramoHorizontalSeleccionado(
            AceroMuroTramoVista tramo)
        {
            if (tramo == null ||
                tramoSeleccionadoId == 0)
            {
                return false;
            }

            if (chkContinuos.Checked)
            {
                return EsCadenaHorizontalSeleccionada(
                    tramo.Cadena);
            }

            return tramo.MuroId ==
                tramoSeleccionadoId;
        }

        private bool VerticalesEnEdicion()
        {
            string handle =
                !string.IsNullOrWhiteSpace(
                    seccionHandleActivo)
                    ? seccionHandleActivo
                    : seccionHandleSeleccionado;

            return verticalesSeccionSeleccionados ||
                handle == "INF" ||
                handle == "SUP" ||
                handle == "IZQ" ||
                handle == "DER";
        }

        private void DibujarHorizontalesTramo(
            System.Drawing.Graphics g,
            System.Drawing.Pen pen,
            System.Func<double, float> sx,
            System.Func<double, float> sy,
            double xInicio,
            double xFin,
            double zInferior,
            double zSuperior,
            double separacion,
            bool resaltado = false)
        {
            if (xFin <= xInicio ||
                zSuperior <= zInferior)
            {
                return;
            }

            int cantidad =
                System.Math.Max(
                    1,
                    (int)System.Math.Floor(
                        (zSuperior - zInferior) /
                        separacion) + 1);

            using (
                System.Drawing.Pen penHalo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            90, 0, 205, 255),
                        8.0F))
            using (
                System.Drawing.Pen penBrillante =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            0, 185, 245),
                        2.6F))
            {
                for (int i = 0; i < cantidad; i++)
                {
                    double z =
                        System.Math.Min(
                            zSuperior,
                            zInferior + i * separacion);

                    float x1 = sx(xInicio);
                    float x2 = sx(xFin);
                    float y = sy(z);

                    if (resaltado)
                    {
                        // Primero halo ancho y luego línea brillante.
                        // El muro/anfitrión queda completamente sin resaltado.
                        g.DrawLine(
                            penHalo,
                            x1,
                            y,
                            x2,
                            y);

                        g.DrawLine(
                            penBrillante,
                            x1,
                            y,
                            x2,
                            y);
                    }
                    else
                    {
                        g.DrawLine(
                            pen,
                            x1,
                            y,
                            x2,
                            y);
                    }
                }

                if (cantidad == 1 ||
                    zInferior + (cantidad - 1) * separacion <
                    zSuperior - separacion * 0.15)
                {
                    float x1 = sx(xInicio);
                    float x2 = sx(xFin);
                    float y = sy(zSuperior);

                    if (resaltado)
                    {
                        g.DrawLine(
                            penHalo,
                            x1,
                            y,
                            x2,
                            y);

                        g.DrawLine(
                            penBrillante,
                            x1,
                            y,
                            x2,
                            y);
                    }
                    else
                    {
                        g.DrawLine(
                            pen,
                            x1,
                            y,
                            x2,
                            y);
                    }
                }
            }
        }


        private float PantallaXAlzado(
            double xModelo)
        {
            return alzadoCentroPanelX +
                (float)(
                    (xModelo -
                     alzadoCentroModeloX) *
                    alzadoEscala);
        }

        private float PantallaYAlzado(
            double zModelo)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                vistaElevacionActual.Tramos.Count == 0)
            {
                return 0F;
            }

            double minZ =
                System.Linq.Enumerable.Min(
                    vistaElevacionActual.Tramos,
                    x => x.ZInferior);

            double maxZ =
                System.Linq.Enumerable.Max(
                    vistaElevacionActual.Tramos,
                    x => x.ZSuperior);

            double centroModeloZ =
                (minZ + maxZ) * 0.5;

            float margenYSuperior = 54F;
            float margenYInferior = 74F;

            float centroPanelY =
                (pnlVistaAlzado.ClientSize.Height -
                 margenYInferior +
                 margenYSuperior) / 2F + panY;

            return centroPanelY -
                (float)(
                    (zModelo -
                     centroModeloZ) *
                    alzadoEscala);
        }

        private double ModeloXAlzadoDesdePantalla(
            float xPantalla)
        {
            if (System.Math.Abs(alzadoEscala) < 1e-9)
                return 0.0;

            return ((xPantalla -
                     alzadoCentroPanelX) /
                    alzadoEscala) +
                alzadoCentroModeloX;
        }

        private System.Collections.Generic.List<
            AceroMuroTramoVista> ObtenerTramosCadenaOrdenados(
                int cadena)
        {
            System.Collections.Generic.List<
                AceroMuroTramoVista> lista =
                    new System.Collections.Generic.List<
                        AceroMuroTramoVista>();

            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null)
            {
                return lista;
            }

            foreach (
                AceroMuroTramoVista tramo
                in vistaElevacionActual.Tramos)
            {
                if (tramo.Cadena ==
                    cadena)
                {
                    lista.Add(tramo);
                }
            }

            lista.Sort(
                (a, b) =>
                    a.XInicio.CompareTo(
                        b.XInicio));

            return lista;
        }

        private bool DebeMostrarHandleHorizontalInicio(
            AceroMuroTramoVista tramo)
        {
            if (tramo == null)
                return false;

            if (!chkHorizontales.Checked)
                return false;

            if (!chkContinuos.Checked)
                return true;

            System.Collections.Generic.List<
                AceroMuroTramoVista> cadena =
                    ObtenerTramosCadenaOrdenados(
                        tramo.Cadena);

            return cadena.Count > 0 &&
                cadena[0].MuroId ==
                tramo.MuroId;
        }

        private bool DebeMostrarHandleHorizontalFin(
            AceroMuroTramoVista tramo)
        {
            if (tramo == null)
                return false;

            if (!chkHorizontales.Checked)
                return false;

            if (!chkContinuos.Checked)
                return true;

            System.Collections.Generic.List<
                AceroMuroTramoVista> cadena =
                    ObtenerTramosCadenaOrdenados(
                        tramo.Cadena);

            return cadena.Count > 0 &&
                cadena[cadena.Count - 1]
                    .MuroId ==
                tramo.MuroId;
        }

        private float ObtenerYHandleHorizontal(
            AceroMuroTramoVista tramo)
        {
            if (tramo == null)
                return 0F;

            // Se coloca sobre una línea horizontal real del set,
            // no sobre los verticales.
            return
                (PantallaYAlzado(
                    tramo.ZInferior) +
                 PantallaYAlzado(
                    tramo.ZSuperior)) * 0.5F;
        }

        private double ObtenerLimiteHorizontalOpuesto(
            AceroMuroTramoVista tramo,
            bool moviendoInicio)
        {
            if (tramo == null)
                return 0.0;

            if (!chkContinuos.Checked)
            {
                return moviendoInicio
                    ? ObtenerXFinEditableTramo(
                        tramo)
                    : ObtenerXInicioEditableTramo(
                        tramo);
            }

            System.Collections.Generic.List<
                AceroMuroTramoVista> cadena =
                    ObtenerTramosCadenaOrdenados(
                        tramo.Cadena);

            if (cadena.Count == 0)
            {
                return moviendoInicio
                    ? ObtenerXFinEditableTramo(
                        tramo)
                    : ObtenerXInicioEditableTramo(
                        tramo);
            }

            AceroMuroTramoVista primero =
                cadena[0];

            AceroMuroTramoVista ultimo =
                cadena[cadena.Count - 1];

            return moviendoInicio
                ? ObtenerXFinEditableTramo(
                    ultimo)
                : ObtenerXInicioEditableTramo(
                    primero);
        }

        private double ObtenerAjusteInicioTramoCm(
            long muroId)
        {
            return ajusteInicioTramoCm.ContainsKey(muroId)
                ? ajusteInicioTramoCm[muroId]
                : 0.0;
        }

        private double ObtenerAjusteFinTramoCm(
            long muroId)
        {
            return ajusteFinTramoCm.ContainsKey(muroId)
                ? ajusteFinTramoCm[muroId]
                : 0.0;
        }

        private double ObtenerXInicioEditableTramo(
            AceroMuroTramoVista tramo)
        {
            double rec =
                ObtenerRecubrimientoCmActual() / 30.48;

            return tramo.XInicio +
                rec +
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ObtenerAjusteInicioTramoCm(
                            tramo.MuroId),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);
        }

        private double ObtenerXFinEditableTramo(
            AceroMuroTramoVista tramo)
        {
            double rec =
                ObtenerRecubrimientoCmActual() / 30.48;

            return tramo.XFin -
                rec -
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        ObtenerAjusteFinTramoCm(
                            tramo.MuroId),
                        Autodesk.Revit.DB.UnitTypeId.Centimeters);
        }

        private double Distancia2D_Px(
            float x1,
            float y1,
            float x2,
            float y2)
        {
            double dx = x1 - x2;
            double dy = y1 - y2;
            return System.Math.Sqrt(dx * dx + dy * dy);
        }

        private void DibujarEstadoMallaAlzado(
            System.Drawing.Graphics g)
        {
            if (g == null)
                return;

            string modo =
                ObtenerModoCarasActual() == 3
                    ? "UNA MALLA CENTRADA"
                    : "DOBLE MALLA";

            string texto =
                modo +
                "  |  Vertical Inf: " +
                ajusteSeccionInferiorCm.ToString("0.0") +
                " cm  |  Vertical Sup: " +
                ajusteSeccionSuperiorCm.ToString("0.0") +
                " cm";

            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush brush =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            40, 80, 120)))
            {
                g.DrawString(
                    texto,
                    fuente,
                    brush,
                    12F,
                    10F);
            }
        }

        private void DibujarHandlesEdicionAlzado(
            System.Drawing.Graphics g,
            System.Func<double, float> sx,
            System.Func<double, float> sy)
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                !chkHorizontales.Checked)
            {
                return;
            }

            using (
                System.Drawing.Brush brushHandle =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            214, 50, 54)))
            using (
                System.Drawing.Pen penHandle =
                    new System.Drawing.Pen(
                        System.Drawing.Color.White,
                        1.2F))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F,
                        System.Drawing.FontStyle.Bold))
            using (
                System.Drawing.Brush brushTexto =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            214, 50, 54)))
            using (
                System.Drawing.Brush brushCandado =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            20, 92, 160)))
            using (
                System.Drawing.Pen penCotaDesarrollo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            32, 112, 190),
                        1.0F))
            using (
                System.Drawing.Pen penCajaCotaDesarrollo =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            70, 135, 205),
                        1.0F))
            using (
                System.Drawing.Brush brushFondoCotaDesarrollo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            250, 253, 255)))
            using (
                System.Drawing.Brush brushTextoCotaDesarrollo =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            20, 88, 165)))
            {
                foreach (
                    AceroMuroTramoVista tramo
                    in vistaElevacionActual.Tramos)
                {
                    bool mostrarInicio =
                        DebeMostrarHandleHorizontalInicio(
                            tramo);

                    bool mostrarFin =
                        DebeMostrarHandleHorizontalFin(
                            tramo);

                    if (!mostrarInicio &&
                        !mostrarFin)
                    {
                        continue;
                    }

                    float y =
                        ObtenerYHandleHorizontal(
                            tramo);

                    bool seleccionado =
                        tramo.MuroId ==
                        tramoSeleccionadoId;

                    float s =
                        seleccionado
                            ? 12F
                            : 9F;

                    if (mostrarInicio)
                    {
                        float x1 =
                            sx(
                                ObtenerXInicioEditableTramo(
                                    tramo));

                        g.FillRectangle(
                            brushHandle,
                            x1 - s * 0.5F,
                            y - s * 0.5F,
                            s,
                            s);

                        g.DrawRectangle(
                            penHandle,
                            x1 - s * 0.5F,
                            y - s * 0.5F,
                            s,
                            s);

                        string txtIni =
                            "H inicio: " +
                            ObtenerAjusteInicioTramoCm(
                                tramo.MuroId)
                                .ToString("0.0") +
                            " cm";

                        g.DrawString(
                            txtIni,
                            fuente,
                            brushTexto,
                            x1 + 5F,
                            y - 18F);

                        System.Drawing.RectangleF rectLock;
                        AceroMuroTipoBloqueoExtremo tipoLock;
                        bool cerrado;
                        string descripcion;

                        if (TryObtenerCandadoInline(
                            tramo,
                            true,
                            out rectLock,
                            out tipoLock,
                            out cerrado,
                            out descripcion))
                        {
                            DibujarCandado(
                                g,
                                rectLock.X + 1F,
                                rectLock.Y + 4F,
                                cerrado);

                            g.DrawString(
                                cerrado
                                    ? "BLOQ."
                                    : "CLIC",
                                fuente,
                                brushCandado,
                                rectLock.X + 16F,
                                rectLock.Y + 2F);
                        }

                        // =============================================
                        // COTA DE DESARROLLO HORIZONTAL - INICIO
                        //
                        // Se mide desde la cara física del muro anfitrión
                        // hasta el extremo REAL del acero.
                        // Solo aparece cuando el acero sale del anfitrión.
                        // =============================================
                        double xInicioReal =
                            ObtenerXInicioEditableTramo(
                                tramo);

                        double desarrolloInicioPies =
                            tramo.XInicio -
                            xInicioReal;

                        double toleranciaDesarrollo =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertToInternalUnits(
                                    1.0,
                                    Autodesk.Revit.DB.UnitTypeId.Millimeters);

                        if (desarrolloInicioPies >
                            toleranciaDesarrollo)
                        {
                            float xAcero =
                                sx(
                                    xInicioReal);

                            float xCara =
                                sx(
                                    tramo.XInicio);

                            float yReferencia =
                                sy(
                                    tramo.ZInferior);

                            float yCota =
                                yReferencia +
                                31F;

                            g.DrawLine(
                                penCotaDesarrollo,
                                xAcero,
                                yReferencia,
                                xAcero,
                                yCota + 4F);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xCara,
                                yReferencia,
                                xCara,
                                yCota + 4F);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xAcero,
                                yCota,
                                xCara,
                                yCota);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xAcero,
                                yCota - 4F,
                                xAcero,
                                yCota + 4F);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xCara,
                                yCota - 4F,
                                xCara,
                                yCota + 4F);

                            double desarrolloInicioM =
                                Autodesk.Revit.DB.UnitUtils
                                    .ConvertFromInternalUnits(
                                        desarrolloInicioPies,
                                        Autodesk.Revit.DB.UnitTypeId.Meters);

                            string textoCota =
                                desarrolloInicioM.ToString(
                                    "0.###") +
                                " m";

                            System.Drawing.SizeF tamCota =
                                g.MeasureString(
                                    textoCota,
                                    fuente);

                            float xTextoCota =
                                (xAcero +
                                 xCara) *
                                0.5F -
                                tamCota.Width *
                                0.5F;

                            float yTextoCota =
                                yCota -
                                tamCota.Height -
                                5F;

                            System.Drawing.RectangleF rectCota =
                                new System.Drawing.RectangleF(
                                    xTextoCota - 4F,
                                    yTextoCota - 2F,
                                    tamCota.Width + 8F,
                                    tamCota.Height + 4F);

                            g.FillRectangle(
                                brushFondoCotaDesarrollo,
                                rectCota);

                            g.DrawRectangle(
                                penCajaCotaDesarrollo,
                                rectCota.X,
                                rectCota.Y,
                                rectCota.Width,
                                rectCota.Height);

                            g.DrawString(
                                textoCota,
                                fuente,
                                brushTextoCotaDesarrollo,
                                xTextoCota,
                                yTextoCota);

                            rectCotaDesarrolloInicioPorMuro[
                                tramo.MuroId] =
                                    rectCota;
                        }
                    }

                    if (mostrarFin)
                    {
                        float x2 =
                            sx(
                                ObtenerXFinEditableTramo(
                                    tramo));

                        g.FillRectangle(
                            brushHandle,
                            x2 - s * 0.5F,
                            y - s * 0.5F,
                            s,
                            s);

                        g.DrawRectangle(
                            penHandle,
                            x2 - s * 0.5F,
                            y - s * 0.5F,
                            s,
                            s);

                        string txtFin =
                            "H fin: " +
                            ObtenerAjusteFinTramoCm(
                                tramo.MuroId)
                                .ToString("0.0") +
                            " cm";

                        System.Drawing.SizeF tam =
                            g.MeasureString(
                                txtFin,
                                fuente);

                        g.DrawString(
                            txtFin,
                            fuente,
                            brushTexto,
                            x2 - tam.Width - 5F,
                            y - 18F);

                        System.Drawing.RectangleF rectLock;
                        AceroMuroTipoBloqueoExtremo tipoLock;
                        bool cerrado;
                        string descripcion;

                        if (TryObtenerCandadoInline(
                            tramo,
                            false,
                            out rectLock,
                            out tipoLock,
                            out cerrado,
                            out descripcion))
                        {
                            DibujarCandado(
                                g,
                                rectLock.X + 1F,
                                rectLock.Y + 4F,
                                cerrado);

                            string label =
                                cerrado
                                    ? "BLOQ."
                                    : "CLIC";

                            System.Drawing.SizeF tamLock =
                                g.MeasureString(
                                    label,
                                    fuente);

                            g.DrawString(
                                label,
                                fuente,
                                brushCandado,
                                rectLock.X -
                                    tamLock.Width - 2F,
                                rectLock.Y + 2F);
                        }

                        // =============================================
                        // COTA DE DESARROLLO HORIZONTAL - FIN
                        // =============================================
                        double xFinReal =
                            ObtenerXFinEditableTramo(
                                tramo);

                        double desarrolloFinPies =
                            xFinReal -
                            tramo.XFin;

                        double toleranciaDesarrollo =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertToInternalUnits(
                                    1.0,
                                    Autodesk.Revit.DB.UnitTypeId.Millimeters);

                        if (desarrolloFinPies >
                            toleranciaDesarrollo)
                        {
                            float xCara =
                                sx(
                                    tramo.XFin);

                            float xAcero =
                                sx(
                                    xFinReal);

                            float yReferencia =
                                sy(
                                    tramo.ZInferior);

                            float yCota =
                                yReferencia +
                                31F;

                            g.DrawLine(
                                penCotaDesarrollo,
                                xCara,
                                yReferencia,
                                xCara,
                                yCota + 4F);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xAcero,
                                yReferencia,
                                xAcero,
                                yCota + 4F);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xCara,
                                yCota,
                                xAcero,
                                yCota);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xCara,
                                yCota - 4F,
                                xCara,
                                yCota + 4F);

                            g.DrawLine(
                                penCotaDesarrollo,
                                xAcero,
                                yCota - 4F,
                                xAcero,
                                yCota + 4F);

                            double desarrolloFinM =
                                Autodesk.Revit.DB.UnitUtils
                                    .ConvertFromInternalUnits(
                                        desarrolloFinPies,
                                        Autodesk.Revit.DB.UnitTypeId.Meters);

                            string textoCota =
                                desarrolloFinM.ToString(
                                    "0.###") +
                                " m";

                            System.Drawing.SizeF tamCota =
                                g.MeasureString(
                                    textoCota,
                                    fuente);

                            float xTextoCota =
                                (xCara +
                                 xAcero) *
                                0.5F -
                                tamCota.Width *
                                0.5F;

                            float yTextoCota =
                                yCota -
                                tamCota.Height -
                                5F;

                            System.Drawing.RectangleF rectCota =
                                new System.Drawing.RectangleF(
                                    xTextoCota - 4F,
                                    yTextoCota - 2F,
                                    tamCota.Width + 8F,
                                    tamCota.Height + 4F);

                            g.FillRectangle(
                                brushFondoCotaDesarrollo,
                                rectCota);

                            g.DrawRectangle(
                                penCajaCotaDesarrollo,
                                rectCota.X,
                                rectCota.Y,
                                rectCota.Width,
                                rectCota.Height);

                            g.DrawString(
                                textoCota,
                                fuente,
                                brushTextoCotaDesarrollo,
                                xTextoCota,
                                yTextoCota);

                            rectCotaDesarrolloFinPorMuro[
                                tramo.MuroId] =
                                    rectCota;
                        }
                    }
                }
            }
        }

        private void CapturarDesarrollosHorizontalesActuales()
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                vistaElevacionActual.Tramos.Count == 0)
            {
                return;
            }

            System.Collections.Generic.List<
                AceroMuroTramoVista> ordenados =
                    ObtenerTramosOrdenadosGlobal();

            if (ordenados == null ||
                ordenados.Count == 0)
            {
                return;
            }

            // INICIO global de la selección actual.
            AceroMuroTramoVista primero =
                ordenados[0];

            if (primero != null)
            {
                double desarrolloPies =
                    primero.XInicio -
                    ObtenerXInicioEditableTramo(
                        primero);

                desarrolloPies =
                    System.Math.Max(
                        0.0,
                        desarrolloPies);

                desarrolloHorizontalInicioRecordadoM =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            desarrolloPies,
                            Autodesk.Revit.DB.UnitTypeId.Meters);

                desarrolloHorizontalInicioRecordadoDefinido =
                    true;
            }

            // FIN global de la selección actual.
            AceroMuroTramoVista ultimo =
                ordenados[
                    ordenados.Count - 1];

            if (ultimo != null)
            {
                double desarrolloPies =
                    ObtenerXFinEditableTramo(
                        ultimo) -
                    ultimo.XFin;

                desarrolloPies =
                    System.Math.Max(
                        0.0,
                        desarrolloPies);

                desarrolloHorizontalFinRecordadoM =
                    Autodesk.Revit.DB.UnitUtils
                        .ConvertFromInternalUnits(
                            desarrolloPies,
                            Autodesk.Revit.DB.UnitTypeId.Meters);

                desarrolloHorizontalFinRecordadoDefinido =
                    true;
            }
        }


        private void AplicarDesarrollosHorizontalesRecordadosASeleccion()
        {
            if (vistaElevacionActual == null ||
                vistaElevacionActual.Tramos == null ||
                vistaElevacionActual.Tramos.Count == 0)
            {
                return;
            }

            double recubrimientoPies =
                ObtenerRecubrimientoCmActual() /
                30.48;

            // Se aplica a CADA cadena continua presente.
            //
            // Si se selecciona 1 muro, ese muro es primero y último.
            // Si se seleccionan 2, 3 o más, solo actúa sobre los muros
            // extremos de cada cadena.
            foreach (
                int numeroCadena
                in ObtenerNumerosCadenas())
            {
                System.Collections.Generic.List<
                    AceroMuroTramoVista> tramos =
                        ObtenerTramosCadenaOrdenados(
                            numeroCadena);

                if (tramos == null ||
                    tramos.Count == 0)
                {
                    continue;
                }

                if (desarrolloHorizontalInicioRecordadoDefinido &&
                    bloqueoHorizontalInicio ==
                        AceroMuroTipoBloqueoExtremo.Ninguno)
                {
                    AceroMuroTramoVista primero =
                        tramos[0];

                    double extensionPies =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertToInternalUnits(
                                System.Math.Max(
                                    0.0,
                                    desarrolloHorizontalInicioRecordadoM),
                                Autodesk.Revit.DB.UnitTypeId.Meters);

                    double xDeseado =
                        primero.XInicio -
                        extensionPies;

                    double xBase =
                        primero.XInicio +
                        recubrimientoPies;

                    ajusteInicioTramoCm[
                        primero.MuroId] =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    xDeseado -
                                    xBase,
                                    Autodesk.Revit.DB.UnitTypeId.Centimeters);
                }

                if (desarrolloHorizontalFinRecordadoDefinido &&
                    bloqueoHorizontalFin ==
                        AceroMuroTipoBloqueoExtremo.Ninguno)
                {
                    AceroMuroTramoVista ultimo =
                        tramos[
                            tramos.Count - 1];

                    double extensionPies =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertToInternalUnits(
                                System.Math.Max(
                                    0.0,
                                    desarrolloHorizontalFinRecordadoM),
                                Autodesk.Revit.DB.UnitTypeId.Meters);

                    double xDeseado =
                        ultimo.XFin +
                        extensionPies;

                    double xBase =
                        ultimo.XFin -
                        recubrimientoPies;

                    ajusteFinTramoCm[
                        ultimo.MuroId] =
                            Autodesk.Revit.DB.UnitUtils
                                .ConvertFromInternalUnits(
                                    xBase -
                                    xDeseado,
                                    Autodesk.Revit.DB.UnitTypeId.Centimeters);
                }
            }
        }


        private void IniciarEditorCotaDesarrolloHorizontal(
            long muroId,
            bool esInicio,
            System.Drawing.RectangleF rectCota)
        {
            FinalizarEditorCotaDesarrolloHorizontal(
                false);

            AceroMuroTramoVista tramo =
                ObtenerTramoPorId(
                    muroId);

            if (tramo == null)
                return;

            double desarrolloPies =
                esInicio
                    ? tramo.XInicio -
                        ObtenerXInicioEditableTramo(
                            tramo)
                    : ObtenerXFinEditableTramo(
                            tramo) -
                        tramo.XFin;

            desarrolloPies =
                System.Math.Max(
                    0.0,
                    desarrolloPies);

            double desarrolloM =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertFromInternalUnits(
                        desarrolloPies,
                        Autodesk.Revit.DB.UnitTypeId.Meters);

            editandoCotaDesarrolloHorizontal =
                true;

            editandoCotaDesarrolloEsInicio =
                esInicio;

            editandoCotaDesarrolloMuroId =
                muroId;

            txtCotaDesarrolloHorizontalInline =
                new System.Windows.Forms.TextBox
                {
                    BorderStyle =
                        System.Windows.Forms.BorderStyle.FixedSingle,
                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            8.5F,
                            System.Drawing.FontStyle.Bold),
                    TextAlign =
                        System.Windows.Forms.HorizontalAlignment.Center,
                    Text =
                        desarrolloM.ToString(
                            "0.###"),
                    Width =
                        System.Math.Max(
                            64,
                            (int)rectCota.Width + 14),
                    Height = 23,
                    Left =
                        System.Math.Max(
                            2,
                            (int)rectCota.X - 5),
                    Top =
                        System.Math.Max(
                            2,
                            (int)rectCota.Y - 2)
                };

            txtCotaDesarrolloHorizontalInline.KeyDown +=
                (s, e) =>
                {
                    if (e.KeyCode ==
                        System.Windows.Forms.Keys.Enter)
                    {
                        e.SuppressKeyPress =
                            true;

                        FinalizarEditorCotaDesarrolloHorizontal(
                            true);

                        return;
                    }

                    if (e.KeyCode ==
                        System.Windows.Forms.Keys.Escape)
                    {
                        e.SuppressKeyPress =
                            true;

                        FinalizarEditorCotaDesarrolloHorizontal(
                            false);
                    }
                };

            txtCotaDesarrolloHorizontalInline.LostFocus +=
                (s, e) =>
                {
                    if (editandoCotaDesarrolloHorizontal)
                    {
                        FinalizarEditorCotaDesarrolloHorizontal(
                            true);
                    }
                };

            pnlVistaAlzado.Controls.Add(
                txtCotaDesarrolloHorizontalInline);

            txtCotaDesarrolloHorizontalInline.BringToFront();
            txtCotaDesarrolloHorizontalInline.Focus();
            txtCotaDesarrolloHorizontalInline.SelectAll();
        }


        private void FinalizarEditorCotaDesarrolloHorizontal(
            bool aplicar)
        {
            if (!editandoCotaDesarrolloHorizontal)
                return;

            System.Windows.Forms.TextBox editor =
                txtCotaDesarrolloHorizontalInline;

            bool esInicio =
                editandoCotaDesarrolloEsInicio;

            long muroId =
                editandoCotaDesarrolloMuroId;

            editandoCotaDesarrolloHorizontal =
                false;

            editandoCotaDesarrolloMuroId =
                0;

            txtCotaDesarrolloHorizontalInline =
                null;

            if (editor == null)
                return;

            string texto =
                editor.Text ?? "";

            try
            {
                if (editor.Parent != null)
                {
                    editor.Parent.Controls.Remove(
                        editor);
                }
            }
            catch
            {
            }

            editor.Dispose();

            if (!aplicar)
            {
                pnlVistaAlzado.Focus();
                pnlVistaAlzado.Invalidate();
                return;
            }

            double valorM;

            if (!TryLeerMetrosInline(
                    texto,
                    out valorM))
            {
                ActualizarEstado(
                    "Longitud de desarrollo no válida. Escriba un valor en metros, por ejemplo 0.80.");

                pnlVistaAlzado.Focus();
                pnlVistaAlzado.Invalidate();
                return;
            }

            AplicarExtensionHorizontalMetros(
                muroId,
                esInicio,
                valorM);

            pnlVistaAlzado.Focus();
        }


        private void AplicarExtensionHorizontalMetros(
            long muroId,
            bool esInicio,
            double extensionM)
        {
            AceroMuroTramoVista tramo =
                ObtenerTramoPorId(
                    muroId);

            if (tramo == null)
                return;

            extensionM =
                System.Math.Max(
                    0.0,
                    extensionM);

            // V8.71:
            // guardar el valor como propiedad del EXTREMO, no del muro.
            if (esInicio)
            {
                desarrolloHorizontalInicioRecordadoM =
                    extensionM;

                desarrolloHorizontalInicioRecordadoDefinido =
                    true;
            }
            else
            {
                desarrolloHorizontalFinRecordadoM =
                    extensionM;

                desarrolloHorizontalFinRecordadoDefinido =
                    true;
            }

            if (esInicio &&
                bloqueoHorizontalInicio !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                ActualizarEstado(
                    "El INICIO está bloqueado. Desbloquee el candado antes de editar la longitud de desarrollo.");

                return;
            }

            if (!esInicio &&
                bloqueoHorizontalFin !=
                    AceroMuroTipoBloqueoExtremo.Ninguno)
            {
                ActualizarEstado(
                    "El FIN está bloqueado. Desbloquee el candado antes de editar la longitud de desarrollo.");

                return;
            }

            RegistrarDeshacer();

            double extensionPies =
                Autodesk.Revit.DB.UnitUtils
                    .ConvertToInternalUnits(
                        extensionM,
                        Autodesk.Revit.DB.UnitTypeId.Meters);

            double recubrimientoPies =
                ObtenerRecubrimientoCmActual() /
                30.48;

            if (esInicio)
            {
                // Longitud de desarrollo medida desde la CARA física
                // del muro hacia afuera.
                double xDeseado =
                    tramo.XInicio -
                    extensionPies;

                double xBase =
                    tramo.XInicio +
                    recubrimientoPies;

                ajusteInicioTramoCm[
                    muroId] =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertFromInternalUnits(
                                xDeseado -
                                xBase,
                                Autodesk.Revit.DB.UnitTypeId.Centimeters);

                tramoSeleccionadoId =
                    muroId;
            }
            else
            {
                double xDeseado =
                    tramo.XFin +
                    extensionPies;

                double xBase =
                    tramo.XFin -
                    recubrimientoPies;

                ajusteFinTramoCm[
                    muroId] =
                        Autodesk.Revit.DB.UnitUtils
                            .ConvertFromInternalUnits(
                                xBase -
                                xDeseado,
                                Autodesk.Revit.DB.UnitTypeId.Centimeters);

                tramoSeleccionadoId =
                    muroId;
            }

            GuardarValoresRecordados();

            pnlVistaAlzado.Invalidate();

            ActualizarEstado(
                (esInicio
                    ? "Desarrollo horizontal de inicio: "
                    : "Desarrollo horizontal de fin: ") +
                extensionM.ToString(
                    "0.###") +
                " m fuera del anfitrión.");
        }


        private float PantallaXSeccion(
            double xLocal)
        {
            return seccionCentroXActual +
                (float)(
                    xLocal *
                    seccionEscalaActual *
                    seccionFactorExageracionX);
        }

        private float PantallaYSeccion(
            double zLocal)
        {
            double altoPx =
                seccionYInferiorActual -
                seccionYSuperiorActual;

            return seccionYInferiorActual -
                (float)(
                    (zLocal /
                     seccionAlturaActual) *
                    altoPx);
        }

        private double ModeloXSeccionDesdePantalla(
            float xPantalla)
        {
            return (xPantalla -
                    seccionCentroXActual) /
                (seccionEscalaActual *
                 seccionFactorExageracionX);
        }

        private double ModeloYSeccionDesdePantalla(
            float yPantalla)
        {
            double altoPx =
                seccionYInferiorActual -
                seccionYSuperiorActual;

            return ((seccionYInferiorActual -
                     yPantalla) / altoPx) *
                seccionAlturaActual;
        }

        private void DibujarHandlesEdicionSeccion(
            System.Drawing.Graphics g)
        {
            if (vistaSeccionActual == null ||
                vistaSeccionActual.Espesor <= 1e-9 ||
                vistaSeccionActual.Altura <= 1e-9)
            {
                return;
            }

            // En SELECCIONAR las manijas aparecen únicamente después de hacer
            // clic sobre los verticales. En MOVER 2 PTOS permanecen visibles para
            // conservar el flujo anterior del editor.
            if (!verticalesSeccionSeleccionados &&
                herramientaSeccion !=
                    AceroMuroHerramientaEdicion.MoverDosPuntos)
            {
                return;
            }

            double rec =
                ObtenerRecubrimientoCmActual() /
                30.48;

            double diamVert =
                ObtenerDiametroBarraVista(
                    cmbTipoVertical);

            double basePosVertical =
                rec +
                diamVert * 0.5;

            double xIzqLocal =
                ObtenerXVerticalLocalVista(
                    1);

            double xDerLocal =
                ObtenerXVerticalLocalVista(
                    -1);

            double xCentroLocal =
                ObtenerXVerticalLocalVista(
                    0);

            double zInfLocal =
                basePosVertical +
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionInferiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            double zSupLocal =
                seccionAlturaActual -
                basePosVertical -
                Autodesk.Revit.DB.UnitUtils.ConvertToInternalUnits(
                    ajusteSeccionSuperiorCm,
                    Autodesk.Revit.DB.UnitTypeId.Centimeters);

            using (
                System.Drawing.Pen pen =
                    new System.Drawing.Pen(
                        System.Drawing.Color.FromArgb(
                            214, 50, 54),
                        1.2F))
            using (
                System.Drawing.Brush brush =
                    new System.Drawing.SolidBrush(
                        System.Drawing.Color.FromArgb(
                            214, 50, 54)))
            using (
                System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Segoe UI",
                        7.0F,
                        System.Drawing.FontStyle.Bold))
            {
                pen.DashStyle =
                    System.Drawing.Drawing2D.DashStyle.Dash;

                float xi =
                    PantallaXSeccion(
                        xIzqLocal);

                float xd =
                    PantallaXSeccion(
                        xDerLocal);

                float xc =
                    PantallaXSeccion(
                        xCentroLocal);

                float yi =
                    PantallaYSeccion(
                        zInfLocal);

                float ys =
                    PantallaYSeccion(
                        zSupLocal);

                float s = 8F;

                if (ObtenerModoCarasActual() == 3)
                {
                    g.DrawLine(
                        pen,
                        xc, ys,
                        xc, yi);

                    g.FillRectangle(
                        brush,
                        xc - s * 0.5F,
                        yi - s * 0.5F,
                        s, s);

                    g.FillRectangle(
                        brush,
                        xc - s * 0.5F,
                        ys - s * 0.5F,
                        s, s);

                    g.DrawString(
                        "UNA MALLA: el vertical se desplaza al lado opuesto del gancho. El H extremo se ajusta al centro REAL de la curvatura.",
                        fuente,
                        brush,
                        14F,
                        46F);
                }
                else
                {
                    float cx =
                        (xi + xd) * 0.5F;

                    float cy =
                        (yi + ys) * 0.5F;

                    g.DrawRectangle(
                        pen,
                        System.Math.Min(xi, xd),
                        System.Math.Min(ys, yi),
                        System.Math.Abs(xd - xi),
                        System.Math.Abs(yi - ys));

                    // Manijas laterales: desplazan la cortina A/B.
                    g.FillRectangle(
                        brush,
                        xi - s * 0.5F,
                        cy - s * 0.5F,
                        s, s);

                    g.FillRectangle(
                        brush,
                        xd - s * 0.5F,
                        cy - s * 0.5F,
                        s, s);

                    // Manijas de EXTREMOS directamente sobre cada vertical.
                    // INF/SUP siguen editando el conjunto completo para que ambas
                    // cortinas mantengan la misma longitud de ejecución.
                    g.FillRectangle(
                        brush,
                        xi - s * 0.5F,
                        yi - s * 0.5F,
                        s, s);

                    g.FillRectangle(
                        brush,
                        xi - s * 0.5F,
                        ys - s * 0.5F,
                        s, s);

                    g.FillRectangle(
                        brush,
                        xd - s * 0.5F,
                        yi - s * 0.5F,
                        s, s);

                    g.FillRectangle(
                        brush,
                        xd - s * 0.5F,
                        ys - s * 0.5F,
                        s, s);

                    g.DrawString(
                        "DOBLE MALLA: verticales se separan del horizontal. El primer/último H queda exactamente en el centro REAL de la curvatura del gancho.",
                        fuente,
                        brush,
                        14F,
                        46F);
                }
            }
        }

        #endregion

        #region 02.6 - CONFIGURACIÓN FINAL Y ENVÍO AL HANDLER

        private AceroMuroConfiguracion ObtenerConfiguracionVisual()
        {
            AceroMuroConfiguracion conf =
                new AceroMuroConfiguracion
                {
                    CrearVerticales =
                        chkVerticales.Checked,
                    CrearHorizontales =
                        chkHorizontales.Checked,
                    RecubrimientoCm =
                        ObtenerRecubrimientoCmActual(),
                    EspaciamientoVerticalCm =
                        ObtenerEspVerticalCmActual(),
                    EspaciamientoHorizontalCm =
                        ObtenerEspHorizontalCmActual(),
                    ModoCaras =
                        ObtenerModoCarasActual(),
                    HorizontalesContinuosPorCadena =
                        chkContinuos.Checked,

                    CrearRefuerzoHuecos =
                        chkRefuerzoHuecos != null &&
                        chkRefuerzoHuecos.Checked,

                    TipoRefuerzoHuecos =
                        cmbRefuerzoHuecosDiametro != null
                            ? ResolverTipoBarra(
                                cmbRefuerzoHuecosDiametro)
                            : null,

                    LongitudRefuerzoHuecosCm =
                        0.0,

                    VerElementosSinTapar =
                        chkVerSinTapar != null &&
                        chkVerSinTapar.Checked,
                    AjusteCaraACm =
                        ajusteSeccionIzquierdaCm,
                    AjusteCaraBCm =
                        ajusteSeccionDerechaCm,
                    AjusteInferiorCm =
                        ajusteSeccionInferiorCm,
                    AjusteSuperiorCm =
                        ajusteSeccionSuperiorCm
                };

            AsegurarEmpalmesPorDiametroDisponibles();

            foreach (
                AceroMuroEmpalmeDiametroData item
                in empalmesPorDiametro)
            {
                if (item != null)
                    conf.EmpalmesPorDiametro.Add(
                        item.Copiar());
            }

            foreach (
                AceroMuroGrupoHorizontal2Puntos grupo
                in gruposHorizontales2Puntos)
            {
                if (grupo != null)
                    conf.GruposHorizontales2Puntos.Add(
                        grupo.Copiar());
            }

            foreach (
                AceroMuroGrupoVertical2Puntos grupo
                in gruposVerticales2Puntos)
            {
                if (grupo != null)
                    conf.GruposVerticales2Puntos.Add(
                        grupo.Copiar());
            }

            return conf;
        }

        #endregion

        #endregion
    }

}
