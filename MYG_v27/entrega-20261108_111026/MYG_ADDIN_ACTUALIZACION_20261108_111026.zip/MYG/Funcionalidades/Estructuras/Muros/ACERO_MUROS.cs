﻿// ==========================================
// ÚNICO HANDLER EXTERNO 3.8 - ACERO EN MUROS
// SELECCIÓN + H/V + DESARROLLO H EXACTO + SOLO BOCETO + DIAGONALES + EMPALMES
// REVIT 2027
// ==========================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

public enum AceroMuroAccion
{
    Ninguna,
    Seleccionar,
    SeleccionarYCrear,
    Crear
}

public class AceroMuroSelectionFilter : ISelectionFilter
{
    public bool AllowElement(Element elem)
    {
        if (elem == null ||
            elem.Category == null)
        {
            return false;
        }

        if (elem.Category.Id.Value !=
            (long)BuiltInCategory.OST_Walls)
        {
            return false;
        }

        Wall muro = elem as Wall;

        if (muro == null)
            return false;

        LocationCurve ubicacion =
            muro.Location as LocationCurve;

        if (ubicacion == null)
            return false;

        Curve curva =
            ubicacion.Curve;

        // V8.26:
        // admite muros rectos y muros curvos circulares.
        if (!(curva is Line) &&
            !(curva is Arc))
        {
            return false;
        }

        try
        {
            return RebarHostData.GetRebarHostData(muro) != null;
        }
        catch
        {
            return false;
        }
    }

    public bool AllowReference(
        Reference reference,
        XYZ position)
    {
        return false;
    }
}

public class AceroMuroHandler : IExternalEventHandler
{
    private const double Tol = 1e-8;

    public UIDocument UiDoc;
    public AceroMuroForm Form;

    public AceroMuroAccion Accion =
        AceroMuroAccion.Ninguna;

    internal AceroMuroForm.AceroMuroConfiguracion ConfiguracionPendiente;

    public List<ElementId> MurosSeleccionados =
        new List<ElementId>();

    private sealed class SuprimirAdvertenciasNoCriticas :
        IFailuresPreprocessor
    {
        public FailureProcessingResult PreprocessFailures(
            FailuresAccessor failuresAccessor)
        {
            if (failuresAccessor == null)
                return FailureProcessingResult.Continue;

            IList<FailureMessageAccessor> mensajes =
                failuresAccessor.GetFailureMessages();

            if (mensajes == null ||
                mensajes.Count == 0)
            {
                return FailureProcessingResult.Continue;
            }

            foreach (
                FailureMessageAccessor mensaje
                in mensajes)
            {
                if (mensaje == null)
                    continue;

                if (mensaje.GetSeverity() ==
                    FailureSeverity.Warning)
                {
                    failuresAccessor.DeleteWarning(mensaje);
                }
            }

            return FailureProcessingResult.Continue;
        }
    }

    private class DatosMuro
    {
        public Wall Muro;
        public XYZ P0;
        public XYZ P1;
        public XYZ Direccion;
        public XYZ Normal;

        // Curva real de ubicación del muro.
        // Puede ser Line o Arc.
        public Curve CurvaBase;
        public bool EsCurvo;

        // Para muros curvos:
        // desplazamiento firmado desde LocationCurve hacia el
        // centro geométrico real del espesor, medido con la
        // normal izquierda de la curva.
        //
        // 0 = LocationCurve ya coincide con el centro del muro.
        public double DesfaseCentroGeometrico;

        // =====================================================
        // GEOMETRÍA REAL DEL MURO CURVO
        //
        // Se obtiene de las dos caras cilíndricas principales
        // del sólido del Wall, NO de LocationCurve.
        // =====================================================
        public bool TieneGeometriaRadialReal;
        public XYZ CentroCurvaturaReal;
        public double RadioInteriorReal;
        public double RadioExteriorReal;
        public double RadioCentroReal;

        // Longitud REAL de la curva, no la cuerda entre extremos.
        public double Longitud;

        public double Espesor;
        public double ZInferior;
        public double ZSuperior;
    }

    private class TramoCadena
    {
        public DatosMuro Datos;
        public XYZ Inicio;
        public XYZ Fin;
    }

    private class CadenaMuros
    {
        public int Numero;
        public List<TramoCadena> Tramos =
            new List<TramoCadena>();

        public double ZInferior
        {
            get
            {
                if (Tramos.Count == 0)
                    return 0.0;

                return Tramos.Max(
                    x => x.Datos.ZInferior);
            }
        }

        public double ZSuperior
        {
            get
            {
                if (Tramos.Count == 0)
                    return 0.0;

                return Tramos.Min(
                    x => x.Datos.ZSuperior);
            }
        }

        public bool EsCadenaReal
        {
            get { return Tramos.Count > 1; }
        }
    }

    private class DatosElementoExtremo
    {
        public Element Elemento;

        // Ancho REAL ocupado por el elemento sobre el eje de la cadena.
        public double AnchoProyectado;

        // Distancia desde el extremo anterior del muro/hueco hasta
        // donde realmente empieza el sólido detectado.
        // En elementos de extremo normalmente vale 0.
        public double DistanciaInicioProyectada;

        public double ZInferior;
        public double ZSuperior;
        public string Categoria;
        public string Nombre;

        public double RecubrimientoCm;
        public string NombreRecubrimiento;
    }

    private class ResultadoCreacion
    {
        public int Verticales;
        public int Horizontales;
        public List<ElementId> Ids =
            new List<ElementId>();
        public List<string> Errores =
            new List<string>();
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc =
            UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
            return;

        try
        {
            if (Accion == AceroMuroAccion.Seleccionar)
            {
                SeleccionarMuros(
                    uidoc,
                    true);
            }
            else if (Accion == AceroMuroAccion.SeleccionarYCrear)
            {
                // =====================================================
                // MODO CONTINUO:
                //
                // 1. Seleccionar una serie.
                // 2. Pulsar Finalizar/check verde.
                // 3. Crear el acero automáticamente.
                // 4. Volver INMEDIATAMENTE al modo selección.
                // 5. Repetir todas las veces necesarias.
                //
                // ESC dentro de la selección termina el modo continuo
                // y devuelve la ventana del add-in.
                // =====================================================
                SeleccionarYCrearContinuamente(
                    uidoc);
            }
            else if (Accion == AceroMuroAccion.Crear)
            {
                CrearAcero(uidoc);
            }
        }
        catch (
            Autodesk.Revit.Exceptions
                .OperationCanceledException)
        {
            Form?.ActualizarEstado(
                "Selección cancelada.");
            Form?.MostrarDespuesSeleccion();
        }
        catch (Exception ex)
        {
            Form?.MostrarDespuesSeleccion();
            Form?.ActualizarEstado(
                "Se produjo un error.");

            TaskDialog.Show(
                "MYG - Acero en Muros",
                "Se produjo un error:\n\n" +
                ex.Message);
        }
        finally
        {
            Accion = AceroMuroAccion.Ninguna;
            Form?.EstablecerBotonesActivos(true);
        }
    }

    public string GetName()
    {
        return "MYG - Acero en Muros";
    }

    private void SeleccionarYCrearContinuamente(
        UIDocument uidoc)
    {
        if (uidoc == null ||
            Form == null ||
            Form.IsDisposed)
        {
            return;
        }

        int seriesEjecutadas =
            0;

        bool continuar =
            true;

        while (continuar &&
               Form != null &&
               !Form.IsDisposed)
        {
            try
            {
                Form.ActualizarEstado(
                    "Modo continuo - Serie " +
                    (seriesEjecutadas + 1) +
                    ": seleccione muros. Finalizar = crear y continuar | Esc = terminar.");

                // La ventana permanece oculta mientras dura todo
                // el modo continuo. Solo reaparece al pulsar Esc.
                SeleccionarMuros(
                    uidoc,
                    false,
                    "Seleccione una serie de muros rectos o curvos. Finalizar = CREAR Y CONTINUAR | Esc = TERMINAR");

                if (MurosSeleccionados == null ||
                    MurosSeleccionados.Count == 0)
                {
                    // Si por alguna razón Revit devuelve una selección
                    // vacía, simplemente volvemos a pedir la siguiente.
                    continue;
                }

                // Muy importante:
                // la configuración se vuelve a leer DESPUÉS de actualizar
                // la selección/preview. Así AjustesTramos pertenece a la
                // serie recién seleccionada, no a la anterior.
                ConfiguracionPendiente =
                    null;

                Form.ActualizarEstado(
                    "Serie " +
                    (seriesEjecutadas + 1) +
                    ": creando acero automáticamente...");

                CrearAcero(
                    uidoc);

                seriesEjecutadas++;

                Form.ActualizarEstado(
                    "Serie " +
                    seriesEjecutadas +
                    " creada. Seleccione la siguiente serie. Finalizar = crear | Esc = terminar.");

                // No mostramos el Form aquí.
                // El siguiente ciclo entra directamente otra vez
                // a PickObjects para continuar seleccionando.
            }
            catch (
                Autodesk.Revit.Exceptions
                    .OperationCanceledException)
            {
                continuar =
                    false;
            }
        }

        Form?.MostrarDespuesSeleccion();

        if (seriesEjecutadas > 0)
        {
            Form?.ActualizarEstado(
                "Modo continuo finalizado. Series ejecutadas: " +
                seriesEjecutadas +
                ".");
        }
        else
        {
            Form?.ActualizarEstado(
                "Modo continuo finalizado sin ejecutar series.");
        }
    }


    private void SeleccionarMuros(
        UIDocument uidoc,
        bool mostrarFormularioDespues,
        string mensajePick = null)
    {
        if (Form == null ||
            Form.IsDisposed)
        {
            return;
        }

        Form.ActualizarEstado(
            "Seleccione muros estructurales rectos y pulse Finalizar.");

        IList<Reference> referencias =
            uidoc.Selection.PickObjects(
                ObjectType.Element,
                new AceroMuroSelectionFilter(),
                string.IsNullOrWhiteSpace(
                    mensajePick)
                    ? "Seleccione muros estructurales rectos o curvos de concreto"
                    : mensajePick);

        List<ElementId> nuevosIds =
            new List<ElementId>();

        foreach (Reference referencia in referencias)
        {
            if (referencia == null)
                continue;

            ElementId id =
                referencia.ElementId;

            if (id == null ||
                id == ElementId.InvalidElementId)
            {
                continue;
            }

            if (!nuevosIds.Contains(id))
                nuevosIds.Add(id);
        }

        MurosSeleccionados.Clear();
        MurosSeleccionados.AddRange(nuevosIds);

        uidoc.Selection.SetElementIds(
            MurosSeleccionados);

        Document doc = uidoc.Document;

        List<DatosMuro> datos =
            ObtenerDatosSeleccionados(
                doc,
                false);

        List<string> avisos =
            new List<string>();

        List<CadenaMuros> cadenas =
            ConstruirCadenas(
                datos,
                avisos);

        AceroMuroForm.AceroMuroVistaElevacion vista =
            CrearVistaElevacion(
                doc,
                cadenas,
                avisos);

        AceroMuroForm.AceroMuroVistaSeccion vistaSeccion =
            CrearVistaSeccion(
                datos);

        List<string> descripciones =
            datos
                .Select(DescribirMuro)
                .ToList();

        Form.ActualizarSeleccion(
            vista,
            vistaSeccion,
            descripciones,
            MurosSeleccionados.Count);

        if (mostrarFormularioDespues)
        {
            Form.MostrarDespuesSeleccion();
        }
    }

    private void CrearAcero(
        UIDocument uidoc)
    {
        Document doc = uidoc.Document;

        if (Form == null ||
            Form.IsDisposed)
        {
            return;
        }

        if (MurosSeleccionados == null ||
            MurosSeleccionados.Count == 0)
        {
            TaskDialog.Show(
                "MYG",
                "Primero debe pulsar SELECCIONAR MUROS y seleccionar uno o más muros.");
            return;
        }

        AceroMuroForm.AceroMuroConfiguracion configuracion =
            ConfiguracionPendiente;

        if (configuracion == null)
        {
            string error;

            if (!Form.TryObtenerConfiguracion(
                out configuracion,
                out error))
            {
                TaskDialog.Show(
                    "MYG",
                    error);

                return;
            }
        }

        List<DatosMuro> datos =
            ObtenerDatosSeleccionados(
                doc,
                true);

        if (datos.Count == 0)
        {
            TaskDialog.Show(
                "MYG",
                "No se encontraron muros válidos para reforzar.");
            return;
        }

        List<string> avisos =
            new List<string>();

        List<CadenaMuros> cadenas =
            ConstruirCadenas(
                datos,
                avisos);

        ResultadoCreacion resultado =
            new ResultadoCreacion();

        Form.EstablecerBotonesActivos(false);
        Form.ActualizarEstado(
            "Creando acero vertical y horizontal...");

        using (
            TransactionGroup grupo =
                new TransactionGroup(
                    doc,
                    "MYG - Acero en Muros"))
        {
            grupo.Start();

            using (
                Transaction transaccion =
                    new Transaction(
                        doc,
                        "MYG - Crear acero en muros"))
            {
                transaccion.Start();
                ConfigurarManejoSilenciosoDeAdvertencias(
                    transaccion);

                try
                {
                    string errorGanchoManual = "";

                    bool ganchosManualesOk =
                        PrepararConfiguracionLongitudGanchoManual(
                            doc,
                            configuracion,
                            out errorGanchoManual);

                    if (!ganchosManualesOk)
                    {
                        resultado.Errores.Add(
                            errorGanchoManual);
                    }
                    else if (configuracion.CrearVerticales)
                    {
                        // V8.50: sin grupos V 2 PTOS no se crea ningún
                        // vertical por defecto.
                        if (configuracion.GruposVerticales2Puntos != null &&
                            configuracion.GruposVerticales2Puntos.Count > 0)
                        {
                            foreach (
                                CadenaMuros cadena
                                in cadenas)
                            {
                                foreach (
                                    TramoCadena tramo
                                    in cadena.Tramos)
                                {
                                    CrearVerticalesTramoDesdeGruposDosPuntos(
                                        doc,
                                        tramo,
                                        configuracion,
                                        resultado);
                                }
                            }
                        }
                    }

                    if (ganchosManualesOk &&
                        configuracion.CrearHorizontales)
                    {
                        if (configuracion
                            .HorizontalesContinuosPorCadena)
                        {
                            foreach (
                                CadenaMuros cadena
                                in cadenas)
                            {
                                CrearHorizontalesCadena(
                                    doc,
                                    cadena,
                                    configuracion,
                                    resultado);
                            }
                        }
                        else
                        {
                            int numeroTemporal = 1;

                            foreach (DatosMuro dato in datos)
                            {
                                CadenaMuros cadenaIndividual =
                                    new CadenaMuros
                                    {
                                        Numero =
                                            numeroTemporal++
                                    };

                                cadenaIndividual.Tramos.Add(
                                    new TramoCadena
                                    {
                                        Datos = dato,
                                        Inicio = dato.P0,
                                        Fin = dato.P1
                                    });

                                CrearHorizontalesCadena(
                                    doc,
                                    cadenaIndividual,
                                    configuracion,
                                    resultado);
                            }
                        }
                    }

                    // =================================================
                    // V8.76 - REFUERZO DIAGONAL AUTOMÁTICO EN HUECOS
                    //
                    // Después de recortar la malla H/V contra el hueco:
                    // - 1 diagonal por cada esquina;
                    // - 4 diagonales por cara;
                    // - en DOBLE MALLA se repiten en ambas caras = 8.
                    //
                    // Ø y LONGITUD salen de los controles V8.77.
                    // =================================================
                    if (configuracion.CrearRefuerzoHuecos)
                    {
                        foreach (
                            CadenaMuros cadena
                            in cadenas)
                        {
                            if (cadena == null ||
                                cadena.Tramos == null)
                            {
                                continue;
                            }

                            foreach (
                                TramoCadena tramo
                                in cadena.Tramos)
                            {
                                CrearRefuerzoAutomaticoHuecosTramo(
                                    doc,
                                    tramo,
                                    configuracion,
                                    resultado);
                            }
                        }
                    }

                    if (resultado.Verticales > 0 ||
                        resultado.Horizontales > 0)
                    {
                        if (configuracion.VerElementosSinTapar)
                        {
                            AplicarVerElementosSinTapar(
                                doc,
                                uidoc.ActiveView,
                                resultado.Ids);
                        }

                        transaccion.Commit();
                    }
                    else
                    {
                        transaccion.RollBack();
                    }
                }
                catch
                {
                    if (transaccion.GetStatus() ==
                        TransactionStatus.Started)
                    {
                        transaccion.RollBack();
                    }

                    throw;
                }
            }

            grupo.Assimilate();
        }

        ConfiguracionPendiente = null;

        if (resultado.Ids.Count > 0)
        {
            uidoc.Selection.SetElementIds(
                resultado.Ids);
        }

        Form.ActualizarEstado(
            "Creados: " +
            resultado.Verticales +
            " conjuntos verticales y " +
            resultado.Horizontales +
            " conjuntos horizontales.");

        if (resultado.Errores.Count > 0)
        {
            TaskDialog.Show(
                "MYG - Acero en Muros",
                "El proceso terminó con observaciones.\n\n" +
                string.Join(
                    "\n",
                    resultado.Errores.Take(10)));
        }
    }

    private void AplicarVerElementosSinTapar(
        Document doc,
        View vista,
        ICollection<ElementId> ids)
    {
        if (doc == null ||
            vista == null ||
            vista.IsTemplate ||
            ids == null ||
            ids.Count == 0)
        {
            return;
        }

        foreach (
            ElementId id
            in ids)
        {
            if (id == null ||
                id ==
                    ElementId.InvalidElementId)
            {
                continue;
            }

            try
            {
                Rebar rebar =
                    doc.GetElement(id)
                    as Rebar;

                if (rebar == null)
                    continue;

                // Equivale al check:
                // "Ver elementos sin tapar"
                // para este Rebar en la vista activa.
                rebar.SetUnobscuredInView(
                    vista,
                    true);
            }
            catch
            {
                // Algunas vistas especiales pueden no admitir
                // esta configuración. No detenemos la creación.
            }
        }
    }


    private void ConfigurarManejoSilenciosoDeAdvertencias(
        Transaction transaccion)
    {
        if (transaccion == null)
            return;

        FailureHandlingOptions opciones =
            transaccion.GetFailureHandlingOptions();

        opciones.SetFailuresPreprocessor(
            new SuprimirAdvertenciasNoCriticas());

        opciones.SetClearAfterRollback(true);

        transaccion.SetFailureHandlingOptions(
            opciones);
    }

    private List<DatosMuro> ObtenerDatosSeleccionados(
        Document doc,
        bool reportarInvalidos)
    {
        List<DatosMuro> resultado =
            new List<DatosMuro>();

        foreach (ElementId id in MurosSeleccionados)
        {
            Wall muro =
                doc.GetElement(id) as Wall;

            if (muro == null)
                continue;

            DatosMuro datos =
                ObtenerDatosMuro(muro);

            if (datos != null)
            {
                resultado.Add(datos);
            }
            else if (reportarInvalidos)
            {
                Form?.ActualizarEstado(
                    "Uno o más muros no son rectos/curvos circulares compatibles o no admiten armadura.");
            }
        }

        return resultado;
    }

    private DatosMuro ObtenerDatosMuro(
        Wall muro)
    {
        if (muro == null)
            return null;

        try
        {
            using (
                RebarHostData hostData =
                    RebarHostData.GetRebarHostData(
                        muro))
            {
                if (hostData == null)
                    return null;
            }
        }
        catch
        {
            return null;
        }

        LocationCurve ubicacion =
            muro.Location as LocationCurve;

        if (ubicacion == null ||
            ubicacion.Curve == null)
        {
            return null;
        }

        Curve curva =
            ubicacion.Curve;

        // En esta versión soportamos:
        // - Line
        // - Arc
        //
        // No aproximamos spline/elipse porque una aproximación
        // silenciosa podría generar acero fuera del anfitrión.
        if (!(curva is Line) &&
            !(curva is Arc))
        {
            return null;
        }

        XYZ p0 =
            ProyectarXY(
                curva.GetEndPoint(0));

        XYZ p1 =
            ProyectarXY(
                curva.GetEndPoint(1));

        double longitud;

        try
        {
            longitud =
                curva.Length;
        }
        catch
        {
            longitud =
                Distancia2D(
                    p0,
                    p1);
        }

        if (longitud <= Tol)
            return null;

        // Dirección de referencia:
        // tangente REAL en la mitad de la curva.
        XYZ direccion =
            null;

        try
        {
            Transform der =
                curva.ComputeDerivatives(
                    0.5,
                    true);

            if (der != null &&
                der.BasisX != null)
            {
                XYZ t =
                    new XYZ(
                        der.BasisX.X,
                        der.BasisX.Y,
                        0.0);

                if (t.GetLength() > Tol)
                {
                    direccion =
                        t.Normalize();
                }
            }
        }
        catch
        {
        }

        if (direccion == null ||
            direccion.GetLength() <= Tol)
        {
            direccion =
                Direccion2D(
                    p0,
                    p1);
        }

        XYZ normal =
            muro.Orientation;

        if (normal != null)
        {
            normal =
                new XYZ(
                    normal.X,
                    normal.Y,
                    0.0);
        }

        if (normal == null ||
            normal.GetLength() <= Tol)
        {
            normal =
                new XYZ(
                    -direccion.Y,
                    direccion.X,
                    0.0);
        }
        else
        {
            normal =
                normal.Normalize();
        }

        BoundingBoxXYZ caja =
            muro.get_BoundingBox(null);

        if (caja == null)
            return null;

        double zInferior =
            caja.Min.Z;

        double zSuperior =
            caja.Max.Z;

        if (zSuperior -
            zInferior <= Tol)
        {
            return null;
        }

        double espesor =
            muro.Width;

        if (espesor <= Tol)
            return null;

        double desfaseCentroGeometrico =
            0.0;

        bool tieneGeometriaRadialReal =
            false;

        XYZ centroCurvaturaReal =
            null;

        double radioInteriorReal =
            0.0;

        double radioExteriorReal =
            0.0;

        double radioCentroReal =
            0.0;

        Arc arcoMuro =
            curva as Arc;

        if (arcoMuro != null)
        {
            tieneGeometriaRadialReal =
                TryObtenerGeometriaRadialRealMuroCurvo(
                    muro,
                    arcoMuro,
                    espesor,
                    out centroCurvaturaReal,
                    out radioInteriorReal,
                    out radioExteriorReal,
                    out radioCentroReal);

            // Se conserva como respaldo el método anterior,
            // pero SOLO si no fue posible leer las caras
            // cilíndricas reales del sólido.
            if (!tieneGeometriaRadialReal)
            {
                desfaseCentroGeometrico =
                    CalcularDesfaseCentroGeometricoMuroCurvo(
                        muro,
                        arcoMuro,
                        zInferior,
                        zSuperior,
                        espesor);
            }
        }
        else
        {
            // En muros rectos también corregimos una Location Line
            // que no coincida con el centro geométrico real.
            desfaseCentroGeometrico =
                CalcularDesfaseCentroGeometricoMuroRecto(
                    muro,
                    curva,
                    zInferior,
                    zSuperior,
                    espesor);
        }

        return new DatosMuro
        {
            Muro =
                muro,
            P0 =
                p0,
            P1 =
                p1,
            Direccion =
                direccion,
            Normal =
                normal,
            CurvaBase =
                curva,
            EsCurvo =
                curva is Arc,
            DesfaseCentroGeometrico =
                desfaseCentroGeometrico,
            TieneGeometriaRadialReal =
                tieneGeometriaRadialReal,
            CentroCurvaturaReal =
                centroCurvaturaReal,
            RadioInteriorReal =
                radioInteriorReal,
            RadioExteriorReal =
                radioExteriorReal,
            RadioCentroReal =
                radioCentroReal,
            Longitud =
                longitud,
            Espesor =
                espesor,
            ZInferior =
                zInferior,
            ZSuperior =
                zSuperior
        };
    }

    private List<CadenaMuros> ConstruirCadenas(
        List<DatosMuro> datos,
        List<string> avisos)
    {
        List<CadenaMuros> cadenas =
            new List<CadenaMuros>();

        if (datos == null ||
            datos.Count == 0)
        {
            return cadenas;
        }

        // Distancia máxima que todavía puede atravesar un pilar,
        // columneta o elemento de borde entre dos muros.
        double toleranciaPunto =
            UnitUtils.ConvertToInternalUnits(
                1.50,
                UnitTypeId.Meters);

        double toleranciaCota =
            UnitUtils.ConvertToInternalUnits(
                10.0,
                UnitTypeId.Centimeters);

        List<DatosMuro> pendientes =
            new List<DatosMuro>(
                datos);

        int numeroCadena =
            1;

        while (pendientes.Count > 0)
        {
            DatosMuro semilla =
                pendientes[0];

            pendientes.RemoveAt(0);

            CadenaMuros cadena =
                new CadenaMuros
                {
                    Numero =
                        numeroCadena++
                };

            // La orientación inicial de la semilla puede ser cualquiera.
            // Por eso NO extendemos primero un lado de forma ciega.
            // En cada iteración comparamos simultáneamente ambos extremos
            // de la cadena y elegimos LA CONEXIÓN GLOBAL MÁS CERCANA.
            cadena.Tramos.Add(
                new TramoCadena
                {
                    Datos =
                        semilla,
                    Inicio =
                        semilla.P0,
                    Fin =
                        semilla.P1
                });

            while (pendientes.Count > 0)
            {
                TramoCadena primero =
                    cadena.Tramos[0];

                TramoCadena ultimo =
                    cadena.Tramos[
                        cadena.Tramos.Count - 1];

                DatosMuro mejorCandidato =
                    null;

                bool agregarAlFinal =
                    true;

                // Si se agrega al final:
                // true  => P0 del candidato se conecta al final.
                // false => P1 del candidato se conecta al final.
                //
                // Si se agrega al inicio:
                // true  => P0 del candidato se conecta al inicio
                //          y por tanto P0 debe convertirse en FIN.
                // false => P1 del candidato se conecta al inicio.
                bool conectaConP0 =
                    true;

                double mejorDistancia =
                    double.MaxValue;

                foreach (
                    DatosMuro candidato
                    in pendientes)
                {
                    if (candidato == null)
                        continue;

                    // ---------------------------------------------
                    // CONEXIONES CONTRA EL FINAL ACTUAL
                    // ---------------------------------------------
                    if (SonCompatiblesEnCotaCadena(
                        ultimo.Datos,
                        candidato,
                        toleranciaCota))
                    {
                        double dFinP0 =
                            Distancia2D(
                                ultimo.Fin,
                                candidato.P0);

                        if (dFinP0 <=
                                toleranciaPunto &&
                            dFinP0 <
                                mejorDistancia)
                        {
                            mejorDistancia =
                                dFinP0;

                            mejorCandidato =
                                candidato;

                            agregarAlFinal =
                                true;

                            conectaConP0 =
                                true;
                        }

                        double dFinP1 =
                            Distancia2D(
                                ultimo.Fin,
                                candidato.P1);

                        if (dFinP1 <=
                                toleranciaPunto &&
                            dFinP1 <
                                mejorDistancia)
                        {
                            mejorDistancia =
                                dFinP1;

                            mejorCandidato =
                                candidato;

                            agregarAlFinal =
                                true;

                            conectaConP0 =
                                false;
                        }
                    }

                    // ---------------------------------------------
                    // CONEXIONES CONTRA EL INICIO ACTUAL
                    // ---------------------------------------------
                    if (SonCompatiblesEnCotaCadena(
                        primero.Datos,
                        candidato,
                        toleranciaCota))
                    {
                        double dIniP0 =
                            Distancia2D(
                                primero.Inicio,
                                candidato.P0);

                        if (dIniP0 <=
                                toleranciaPunto &&
                            dIniP0 <
                                mejorDistancia)
                        {
                            mejorDistancia =
                                dIniP0;

                            mejorCandidato =
                                candidato;

                            agregarAlFinal =
                                false;

                            conectaConP0 =
                                true;
                        }

                        double dIniP1 =
                            Distancia2D(
                                primero.Inicio,
                                candidato.P1);

                        if (dIniP1 <=
                                toleranciaPunto &&
                            dIniP1 <
                                mejorDistancia)
                        {
                            mejorDistancia =
                                dIniP1;

                            mejorCandidato =
                                candidato;

                            agregarAlFinal =
                                false;

                            conectaConP0 =
                                false;
                        }
                    }
                }

                if (mejorCandidato == null)
                    break;

                TramoCadena nuevoTramo;

                if (agregarAlFinal)
                {
                    // El extremo que se conecta debe ser el INICIO
                    // del nuevo tramo.
                    nuevoTramo =
                        new TramoCadena
                        {
                            Datos =
                                mejorCandidato,
                            Inicio =
                                conectaConP0
                                    ? mejorCandidato.P0
                                    : mejorCandidato.P1,
                            Fin =
                                conectaConP0
                                    ? mejorCandidato.P1
                                    : mejorCandidato.P0
                        };

                    cadena.Tramos.Add(
                        nuevoTramo);
                }
                else
                {
                    // El extremo que se conecta debe ser el FIN
                    // del nuevo tramo insertado delante.
                    nuevoTramo =
                        new TramoCadena
                        {
                            Datos =
                                mejorCandidato,
                            Inicio =
                                conectaConP0
                                    ? mejorCandidato.P1
                                    : mejorCandidato.P0,
                            Fin =
                                conectaConP0
                                    ? mejorCandidato.P0
                                    : mejorCandidato.P1
                        };

                    cadena.Tramos.Insert(
                        0,
                        nuevoTramo);
                }

                pendientes.Remove(
                    mejorCandidato);
            }

            cadenas.Add(
                cadena);
        }

        if (avisos != null &&
            cadenas.Count > 1)
        {
            avisos.Add(
                "Se detectaron " +
                cadenas.Count +
                " cadenas geométricamente independientes. " +
                "La vista previa las separa solo 5 cm.");
        }

        return cadenas;
    }

    private bool SonCompatiblesEnCotaCadena(
        DatosMuro a,
        DatosMuro b,
        double toleranciaCota)
    {
        if (a == null ||
            b == null)
        {
            return false;
        }

        // Caso normal: cotas prácticamente iguales.
        bool cotasCercanas =
            Math.Abs(
                a.ZInferior -
                b.ZInferior) <=
                toleranciaCota &&
            Math.Abs(
                a.ZSuperior -
                b.ZSuperior) <=
                toleranciaCota;

        if (cotasCercanas)
            return true;

        // Respaldo:
        // si existe un solape vertical importante, seguimos
        // considerando que pueden pertenecer a la misma serie.
        double alturaA =
            a.ZSuperior -
            a.ZInferior;

        double alturaB =
            b.ZSuperior -
            b.ZInferior;

        double alturaMinima =
            Math.Min(
                alturaA,
                alturaB);

        if (alturaMinima <= Tol)
            return false;

        double solape =
            Math.Min(
                a.ZSuperior,
                b.ZSuperior) -
            Math.Max(
                a.ZInferior,
                b.ZInferior);

        return solape >=
            alturaMinima * 0.80;
    }

    private bool SonConectables(
        DatosMuro a,
        DatosMuro b,
        double toleranciaPunto,
        double toleranciaCota)
    {
        if (a == null || b == null)
            return false;

        bool cotaCompatible =
            Math.Abs(
                a.ZInferior -
                b.ZInferior) <= toleranciaCota &&
            Math.Abs(
                a.ZSuperior -
                b.ZSuperior) <= toleranciaCota;

        if (!cotaCompatible)
            return false;

        return
            Distancia2D(
                a.P0,
                b.P0) <= toleranciaPunto ||
            Distancia2D(
                a.P0,
                b.P1) <= toleranciaPunto ||
            Distancia2D(
                a.P1,
                b.P0) <= toleranciaPunto ||
            Distancia2D(
                a.P1,
                b.P1) <= toleranciaPunto;
    }

    private XYZ ObtenerExtremoLibre(
        DatosMuro muro,
        List<DatosMuro> componente,
        double toleranciaPunto,
        double toleranciaCota)
    {
        bool p0Conectado = false;
        bool p1Conectado = false;

        foreach (DatosMuro otro in componente)
        {
            if (otro.Muro.Id == muro.Muro.Id)
                continue;

            if (!SonConectables(
                muro,
                otro,
                toleranciaPunto,
                toleranciaCota))
            {
                continue;
            }

            if (Distancia2D(
                muro.P0,
                otro.P0) <= toleranciaPunto ||
                Distancia2D(
                    muro.P0,
                    otro.P1) <= toleranciaPunto)
            {
                p0Conectado = true;
            }

            if (Distancia2D(
                muro.P1,
                otro.P0) <= toleranciaPunto ||
                Distancia2D(
                    muro.P1,
                    otro.P1) <= toleranciaPunto)
            {
                p1Conectado = true;
            }
        }

        if (!p0Conectado)
            return muro.P0;

        if (!p1Conectado)
            return muro.P1;

        return muro.P0;
    }


    private AceroMuroForm.AceroMuroVistaSeccion CrearVistaSeccion(
        List<DatosMuro> datos)
    {
        AceroMuroForm.AceroMuroVistaSeccion vista =
            new AceroMuroForm.AceroMuroVistaSeccion();

        if (datos == null ||
            datos.Count == 0)
        {
            return vista;
        }

        DatosMuro referencia =
            datos[0];

        vista.NombreReferencia =
            ObtenerNombreMuro(
                referencia.Muro);

        vista.Espesor =
            referencia.Espesor;

        vista.Altura =
            referencia.ZSuperior -
            referencia.ZInferior;

        vista.CantidadMuros =
            datos.Count;

        double nucleoMin;
        double nucleoMax;

        if (TryObtenerLimitesNucleoDesdeCentro(
            referencia.Muro,
            out nucleoMin,
            out nucleoMax))
        {
            vista.TieneNucleo =
                true;

            vista.NucleoMinDesdeCentro =
                nucleoMin;

            vista.NucleoMaxDesdeCentro =
                nucleoMax;
        }
        else
        {
            vista.TieneNucleo =
                false;

            vista.NucleoMinDesdeCentro =
                -referencia.Espesor * 0.5;

            vista.NucleoMaxDesdeCentro =
                referencia.Espesor * 0.5;
        }

        double toleranciaEspesor =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

        double toleranciaAltura =
            UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters);

        int variantes = 0;

        foreach (DatosMuro dato in datos)
        {
            bool distinto =
                Math.Abs(
                    dato.Espesor -
                    referencia.Espesor) >
                    toleranciaEspesor ||
                Math.Abs(
                    (dato.ZSuperior -
                     dato.ZInferior) -
                    vista.Altura) >
                    toleranciaAltura;

            if (distinto)
                variantes++;
        }

        vista.CantidadVariantes =
            variantes;

        if (variantes > 0)
        {
            vista.Observacion =
                "Se muestra la sección del primer muro seleccionado; existen muros con distinto espesor o altura.";
        }
        else
        {
            vista.Observacion =
                "La sección mostrada representa la selección actual.";
        }

        return vista;
    }

    private void ObtenerRecubrimientoElemento(
        Element elemento,
        out double recubrimientoCm,
        out string nombreRecubrimiento)
    {
        recubrimientoCm = 0.0;
        nombreRecubrimiento = "";

        if (elemento == null)
            return;

        RebarHostData hostData =
            null;

        try
        {
            hostData =
                RebarHostData.GetRebarHostData(
                    elemento);

            if (hostData == null)
                return;

            // Si todas las caras expuestas tienen el mismo cover,
            // éste es el caso ideal.
            RebarCoverType comun =
                hostData.GetCommonCoverType();

            if (comun != null)
            {
                recubrimientoCm =
                    UnitUtils.ConvertFromInternalUnits(
                        comun.CoverDistance,
                        UnitTypeId.Centimeters);

                nombreRecubrimiento =
                    comun.Name ?? "";

                return;
            }

            // Si hay distintos covers por cara, para la vista previa
            // tomamos el MENOR de los covers expuestos. De esta forma
            // la línea punteada nunca representa un recubrimiento mayor
            // que el realmente asignado a alguna cara.
            IList<Reference> caras =
                hostData.GetExposedFaces();

            RebarCoverType mejor =
                null;

            if (caras != null)
            {
                foreach (
                    Reference cara
                    in caras)
                {
                    if (cara == null)
                        continue;

                    RebarCoverType tipo =
                        null;

                    try
                    {
                        tipo =
                            hostData.GetCoverType(
                                cara);
                    }
                    catch
                    {
                    }

                    if (tipo == null)
                        continue;

                    if (mejor == null ||
                        tipo.CoverDistance <
                        mejor.CoverDistance)
                    {
                        mejor = tipo;
                    }
                }
            }

            if (mejor != null)
            {
                recubrimientoCm =
                    UnitUtils.ConvertFromInternalUnits(
                        mejor.CoverDistance,
                        UnitTypeId.Centimeters);

                nombreRecubrimiento =
                    mejor.Name ?? "";
            }
        }
        catch
        {
            recubrimientoCm = 0.0;
            nombreRecubrimiento = "";
        }
        finally
        {
            if (hostData != null)
                hostData.Dispose();
        }
    }

    private DatosElementoExtremo BuscarElementoEntreTramos(
        Document doc,
        CadenaMuros cadena,
        TramoCadena tramoA,
        TramoCadena tramoB)
    {
        if (doc == null ||
            cadena == null ||
            tramoA == null ||
            tramoB == null ||
            tramoA.Datos == null ||
            tramoB.Datos == null)
        {
            return null;
        }

        XYZ pA =
            tramoA.Fin;

        XYZ pB =
            tramoB.Inicio;

        double distanciaHueco =
            Distancia2D(
                pA,
                pB);

        if (distanciaHueco <= Tol)
            return null;

        XYZ direccionHueco =
            Direccion2D(
                pA,
                pB);

        XYZ puntoMedio =
            new XYZ(
                (pA.X + pB.X) * 0.5,
                (pA.Y + pB.Y) * 0.5,
                0.0);

        HashSet<long> idsMurosCadena =
            new HashSet<long>(
                cadena.Tramos
                    .Where(x =>
                        x != null &&
                        x.Datos != null &&
                        x.Datos.Muro != null)
                    .Select(x =>
                        x.Datos.Muro.Id.Value));

        BuiltInCategory[] categorias =
        {
            BuiltInCategory.OST_StructuralColumns,
            BuiltInCategory.OST_Columns,
            BuiltInCategory.OST_StructuralFraming,
            BuiltInCategory.OST_Walls
        };

        // =====================================================
        // PASADA PRINCIPAL: SÓLIDO REAL DENTRO DEL HUECO
        // =====================================================
        //
        // Se lanza el mismo análisis sólido/rayo utilizado para
        // los extremos, pero esta vez desde el FIN del muro A
        // hacia el INICIO del muro B.
        //
        // Resultado:
        // - DistanciaInicioProyectada = cuánto vacío real hay antes
        //   de tocar la columneta/pilar.
        // - AnchoProyectado = ancho REAL del sólido atravesado.
        //
        // Esto evita dibujar TODO el hueco como si fuera una placa.
        // =====================================================

        DatosElementoExtremo mejorReal =
            null;

        double mejorInicio =
            double.MaxValue;

        double mejorPrioridad =
            double.MaxValue;

        double mejorAncho =
            double.MaxValue;

        foreach (
            BuiltInCategory bic
            in categorias)
        {
            IEnumerable<Element> elementos;

            try
            {
                elementos =
                    new FilteredElementCollector(doc)
                        .OfCategory(bic)
                        .WhereElementIsNotElementType()
                        .Cast<Element>();
            }
            catch
            {
                continue;
            }

            foreach (
                Element elemento
                in elementos)
            {
                if (elemento == null ||
                    idsMurosCadena.Contains(
                        elemento.Id.Value))
                {
                    continue;
                }

                BoundingBoxXYZ caja =
                    elemento.get_BoundingBox(null);

                if (caja == null)
                    continue;

                // Prefiltro: la caja debe estar cerca del segmento
                // real que existe entre ambos extremos.
                double distanciaCentro =
                    DistanciaPuntoCajaXY(
                        puntoMedio,
                        caja);

                double toleranciaPrefiltro =
                    System.Math.Max(
                        UnitUtils.ConvertToInternalUnits(
                            25.0,
                            UnitTypeId.Centimeters),
                        distanciaHueco * 0.75);

                if (distanciaCentro >
                    toleranciaPrefiltro)
                {
                    continue;
                }

                double inicioReal;
                double anchoReal;

                if (!TryObtenerInterseccionRealExtremo(
                    elemento,
                    pA,
                    direccionHueco,
                    tramoA.Datos,
                    distanciaHueco,
                    out inicioReal,
                    out anchoReal))
                {
                    continue;
                }

                if (anchoReal <= Tol)
                    continue;

                inicioReal =
                    System.Math.Max(
                        0.0,
                        inicioReal);

                if (inicioReal >=
                    distanciaHueco - Tol)
                {
                    continue;
                }

                anchoReal =
                    System.Math.Min(
                        anchoReal,
                        distanciaHueco -
                        inicioReal);

                if (anchoReal <= Tol)
                    continue;

                double prioridad =
                    ObtenerPrioridadCategoriaExtremo(
                        bic);

                double tolEmpate =
                    UnitUtils.ConvertToInternalUnits(
                        2.0,
                        UnitTypeId.Millimeters);

                bool esMejor =
                    false;

                if (inicioReal <
                    mejorInicio -
                    tolEmpate)
                {
                    esMejor = true;
                }
                else if (System.Math.Abs(
                    inicioReal -
                    mejorInicio) <=
                    tolEmpate)
                {
                    if (prioridad <
                        mejorPrioridad - Tol)
                    {
                        esMejor = true;
                    }
                    else if (System.Math.Abs(
                        prioridad -
                        mejorPrioridad) <= Tol &&
                        anchoReal <
                        mejorAncho)
                    {
                        // Si empiezan en el mismo sitio,
                        // preferimos la columneta/pilar pequeño.
                        esMejor = true;
                    }
                }

                if (!esMejor)
                    continue;

                double recCm;
                string nombreRec;

                ObtenerRecubrimientoElemento(
                    elemento,
                    out recCm,
                    out nombreRec);

                mejorInicio =
                    inicioReal;

                mejorPrioridad =
                    prioridad;

                mejorAncho =
                    anchoReal;

                mejorReal =
                    new DatosElementoExtremo
                    {
                        Elemento =
                            elemento,
                        DistanciaInicioProyectada =
                            inicioReal,
                        AnchoProyectado =
                            anchoReal,
                        ZInferior =
                            caja.Min.Z,
                        ZSuperior =
                            caja.Max.Z,
                        Categoria =
                            elemento.Category != null
                                ? elemento.Category.Name
                                : "Elemento",
                        Nombre =
                            elemento.Name ??
                            "Elemento",
                        RecubrimientoCm =
                            recCm,
                        NombreRecubrimiento =
                            nombreRec
                    };
            }
        }

        if (mejorReal != null)
            return mejorReal;

        // =====================================================
        // RESPALDO: INTERVALO DE BOUNDING BOX RECORTADO AL HUECO
        // =====================================================
        // Solo se usa si el elemento no expone sólidos analizables.
        // A diferencia de versiones anteriores, la caja ya NO ocupa
        // automáticamente todo el hueco: calculamos su intervalo real
        // proyectado sobre el segmento A->B y lo recortamos.
        // =====================================================

        DatosElementoExtremo mejorCaja =
            null;

        double mejorInicioCaja =
            double.MaxValue;

        double mejorPrioridadCaja =
            double.MaxValue;

        double mejorAnchoCaja =
            double.MaxValue;

        foreach (
            BuiltInCategory bic
            in categorias)
        {
            IEnumerable<Element> elementos;

            try
            {
                elementos =
                    new FilteredElementCollector(doc)
                        .OfCategory(bic)
                        .WhereElementIsNotElementType()
                        .Cast<Element>();
            }
            catch
            {
                continue;
            }

            foreach (
                Element elemento
                in elementos)
            {
                if (elemento == null ||
                    idsMurosCadena.Contains(
                        elemento.Id.Value))
                {
                    continue;
                }

                BoundingBoxXYZ caja =
                    elemento.get_BoundingBox(null);

                if (caja == null)
                    continue;

                double inicioCaja;
                double anchoCaja;

                if (!TryObtenerIntervaloCajaEnHueco(
                    caja,
                    pA,
                    direccionHueco,
                    distanciaHueco,
                    out inicioCaja,
                    out anchoCaja))
                {
                    continue;
                }

                double prioridad =
                    ObtenerPrioridadCategoriaExtremo(
                        bic);

                double tolEmpate =
                    UnitUtils.ConvertToInternalUnits(
                        2.0,
                        UnitTypeId.Millimeters);

                bool esMejor =
                    false;

                if (inicioCaja <
                    mejorInicioCaja -
                    tolEmpate)
                {
                    esMejor = true;
                }
                else if (System.Math.Abs(
                    inicioCaja -
                    mejorInicioCaja) <=
                    tolEmpate)
                {
                    if (prioridad <
                        mejorPrioridadCaja - Tol)
                    {
                        esMejor = true;
                    }
                    else if (System.Math.Abs(
                        prioridad -
                        mejorPrioridadCaja) <= Tol &&
                        anchoCaja <
                        mejorAnchoCaja)
                    {
                        esMejor = true;
                    }
                }

                if (!esMejor)
                    continue;

                double recCm;
                string nombreRec;

                ObtenerRecubrimientoElemento(
                    elemento,
                    out recCm,
                    out nombreRec);

                mejorInicioCaja =
                    inicioCaja;

                mejorPrioridadCaja =
                    prioridad;

                mejorAnchoCaja =
                    anchoCaja;

                mejorCaja =
                    new DatosElementoExtremo
                    {
                        Elemento =
                            elemento,
                        DistanciaInicioProyectada =
                            inicioCaja,
                        AnchoProyectado =
                            anchoCaja,
                        ZInferior =
                            caja.Min.Z,
                        ZSuperior =
                            caja.Max.Z,
                        Categoria =
                            elemento.Category != null
                                ? elemento.Category.Name
                                : "Elemento",
                        Nombre =
                            elemento.Name ??
                            "Elemento",
                        RecubrimientoCm =
                            recCm,
                        NombreRecubrimiento =
                            nombreRec
                    };
            }
        }

        return mejorCaja;
    }


    private bool TryObtenerIntervaloCajaEnHueco(
        BoundingBoxXYZ caja,
        XYZ origenHueco,
        XYZ direccionHueco,
        double longitudHueco,
        out double inicio,
        out double ancho)
    {
        inicio =
            0.0;

        ancho =
            0.0;

        if (caja == null ||
            origenHueco == null ||
            direccionHueco == null ||
            direccionHueco.GetLength() <= Tol ||
            longitudHueco <= Tol)
        {
            return false;
        }

        XYZ d =
            new XYZ(
                direccionHueco.X,
                direccionHueco.Y,
                0.0).Normalize();

        XYZ[] esquinas =
        {
            new XYZ(caja.Min.X, caja.Min.Y, 0.0),
            new XYZ(caja.Min.X, caja.Max.Y, 0.0),
            new XYZ(caja.Max.X, caja.Min.Y, 0.0),
            new XYZ(caja.Max.X, caja.Max.Y, 0.0)
        };

        double tMin =
            double.MaxValue;

        double tMax =
            double.MinValue;

        foreach (
            XYZ esquina
            in esquinas)
        {
            double t =
                (esquina - origenHueco)
                    .DotProduct(d);

            tMin =
                System.Math.Min(
                    tMin,
                    t);

            tMax =
                System.Math.Max(
                    tMax,
                    t);
        }

        double recortadoInicio =
            System.Math.Max(
                0.0,
                tMin);

        double recortadoFin =
            System.Math.Min(
                longitudHueco,
                tMax);

        if (recortadoFin -
            recortadoInicio <= Tol)
        {
            return false;
        }

        inicio =
            recortadoInicio;

        ancho =
            recortadoFin -
            recortadoInicio;

        return true;
    }


    private DatosElementoExtremo BuscarElementoExtremoCadena(
        Document doc,
        CadenaMuros cadena,
        bool esInicio)
    {
        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return null;
        }

        TramoCadena tramoExtremo =
            esInicio
                ? cadena.Tramos[0]
                : cadena.Tramos[
                    cadena.Tramos.Count - 1];

        XYZ puntoExtremo =
            esInicio
                ? tramoExtremo.Inicio
                : tramoExtremo.Fin;

        XYZ direccion =
            ObtenerTangenteTramoEnExtremo(
                tramoExtremo,
                esInicio);

        // Hacia AFUERA de la cadena:
        // inicio = tangente invertida
        // fin    = tangente directa
        if (esInicio)
        {
            direccion =
                direccion.Multiply(
                    -1.0);
        }

        double toleranciaBusqueda =
            UnitUtils.ConvertToInternalUnits(
                80.0,
                UnitTypeId.Centimeters);

        HashSet<long> idsMurosCadena =
            new HashSet<long>(
                cadena.Tramos
                    .Where(x =>
                        x != null &&
                        x.Datos != null &&
                        x.Datos.Muro != null)
                    .Select(x =>
                        x.Datos.Muro.Id.Value));

        List<BuiltInCategory> categorias =
            new List<BuiltInCategory>
            {
                BuiltInCategory.OST_StructuralColumns,
                BuiltInCategory.OST_Columns,
                BuiltInCategory.OST_StructuralFraming,
                BuiltInCategory.OST_Walls
            };

        // =====================================================
        // PRIMERA PASADA: GEOMETRÍA REAL
        // =====================================================
        // Antes se elegía el elemento con BoundingBox más cercano.
        // En elementos inclinados o placas grandes, la caja puede
        // alcanzar el extremo aunque el sólido real esté más lejos.
        //
        // Ahora lanzamos rayos cortos desde el extremo del muro y
        // buscamos la PRIMERA intersección con el SÓLIDO REAL.
        // El ancho mostrado en la preview es la longitud REAL del
        // sólido atravesado por el rayo, no el ancho del BoundingBox.
        // =====================================================

        DatosElementoExtremo mejorReal =
            null;

        double mejorInicioReal =
            double.MaxValue;

        double mejorPrioridadReal =
            double.MaxValue;

        double mejorAnchoReal =
            double.MaxValue;

        foreach (BuiltInCategory bic in categorias)
        {
            IEnumerable<Element> elementos;

            try
            {
                elementos =
                    new FilteredElementCollector(doc)
                        .OfCategory(bic)
                        .WhereElementIsNotElementType()
                        .Cast<Element>();
            }
            catch
            {
                continue;
            }

            foreach (Element elemento in elementos)
            {
                if (elemento == null ||
                    idsMurosCadena.Contains(
                        elemento.Id.Value))
                {
                    continue;
                }

                // Pre-filtro barato por caja para no recorrer sólidos
                // de elementos claramente lejanos.
                BoundingBoxXYZ caja =
                    elemento.get_BoundingBox(null);

                if (caja == null)
                    continue;

                double distanciaCaja =
                    DistanciaPuntoCajaXY(
                        puntoExtremo,
                        caja);

                if (distanciaCaja >
                    toleranciaBusqueda)
                {
                    continue;
                }

                double distanciaInicioReal;
                double anchoReal;

                if (!TryObtenerInterseccionRealExtremo(
                    elemento,
                    puntoExtremo,
                    direccion,
                    tramoExtremo.Datos,
                    toleranciaBusqueda,
                    out distanciaInicioReal,
                    out anchoReal))
                {
                    continue;
                }

                if (anchoReal <= Tol)
                    continue;

                double prioridadCategoria =
                    ObtenerPrioridadCategoriaExtremo(
                        bic);

                bool esMejor =
                    false;

                double toleranciaEmpate =
                    UnitUtils.ConvertToInternalUnits(
                        2.0,
                        UnitTypeId.Millimeters);

                if (distanciaInicioReal <
                    mejorInicioReal -
                    toleranciaEmpate)
                {
                    esMejor = true;
                }
                else if (System.Math.Abs(
                    distanciaInicioReal -
                    mejorInicioReal) <=
                    toleranciaEmpate)
                {
                    if (prioridadCategoria <
                        mejorPrioridadReal - Tol)
                    {
                        esMejor = true;
                    }
                    else if (System.Math.Abs(
                        prioridadCategoria -
                        mejorPrioridadReal) <= Tol &&
                        anchoReal <
                        mejorAnchoReal)
                    {
                        // Si dos elementos empiezan prácticamente
                        // en el mismo sitio, preferimos el más pequeño.
                        // Esto favorece la columneta/pilar de borde y
                        // evita que una placa grande se coma la preview.
                        esMejor = true;
                    }
                }

                if (!esMejor)
                    continue;

                string categoria =
                    elemento.Category != null
                        ? elemento.Category.Name
                        : "Elemento";

                string nombre =
                    elemento.Name ??
                    categoria;

                double recCm;
                string nombreRec;

                ObtenerRecubrimientoElemento(
                    elemento,
                    out recCm,
                    out nombreRec);

                mejorInicioReal =
                    distanciaInicioReal;

                mejorPrioridadReal =
                    prioridadCategoria;

                mejorAnchoReal =
                    anchoReal;

                mejorReal =
                    new DatosElementoExtremo
                    {
                        Elemento =
                            elemento,
                        AnchoProyectado =
                            anchoReal,
                        ZInferior =
                            caja.Min.Z,
                        ZSuperior =
                            caja.Max.Z,
                        Categoria =
                            categoria,
                        Nombre =
                            nombre,
                        RecubrimientoCm =
                            recCm,
                        NombreRecubrimiento =
                            nombreRec
                    };
            }
        }

        if (mejorReal != null)
            return mejorReal;

        // =====================================================
        // RESPALDO: BOUNDING BOX
        // =====================================================
        // Se usa únicamente si ningún candidato pudo analizarse
        // mediante sólido real (familias sin sólido, geometría rara,
        // etc.). Conservamos la compatibilidad con el comportamiento
        // anterior, pero con una pequeña preferencia por columnas.
        // =====================================================

        DatosElementoExtremo mejor =
            null;

        double mejorPuntaje =
            double.MaxValue;

        foreach (BuiltInCategory bic in categorias)
        {
            IEnumerable<Element> elementos;

            try
            {
                elementos =
                    new FilteredElementCollector(doc)
                        .OfCategory(bic)
                        .WhereElementIsNotElementType()
                        .Cast<Element>();
            }
            catch
            {
                continue;
            }

            foreach (Element elemento in elementos)
            {
                if (elemento == null ||
                    idsMurosCadena.Contains(
                        elemento.Id.Value))
                {
                    continue;
                }

                BoundingBoxXYZ caja =
                    elemento.get_BoundingBox(null);

                if (caja == null)
                    continue;

                double distanciaXY =
                    DistanciaPuntoCajaXY(
                        puntoExtremo,
                        caja);

                if (distanciaXY >
                    toleranciaBusqueda)
                {
                    continue;
                }

                double anchoProyectado =
                    ObtenerAnchoCajaProyectado(
                        caja,
                        direccion);

                if (anchoProyectado <= Tol)
                    continue;

                XYZ centroCaja =
                    new XYZ(
                        (caja.Min.X + caja.Max.X) * 0.5,
                        (caja.Min.Y + caja.Max.Y) * 0.5,
                        (caja.Min.Z + caja.Max.Z) * 0.5);

                XYZ vectorCentro =
                    new XYZ(
                        centroCaja.X - puntoExtremo.X,
                        centroCaja.Y - puntoExtremo.Y,
                        0.0);

                double haciaAfuera =
                    vectorCentro.DotProduct(
                        direccion);

                double penalizacionLado =
                    haciaAfuera >=
                    -UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Centimeters)
                        ? 0.0
                        : toleranciaBusqueda * 5.0;

                double prioridadCategoria =
                    ObtenerPrioridadCategoriaExtremo(
                        bic);

                double puntaje =
                    distanciaXY +
                    penalizacionLado +
                    prioridadCategoria +
                    anchoProyectado * 0.001;

                if (puntaje >=
                    mejorPuntaje)
                {
                    continue;
                }

                string categoria =
                    elemento.Category != null
                        ? elemento.Category.Name
                        : "Elemento";

                string nombre =
                    elemento.Name ??
                    categoria;

                double recCm;
                string nombreRec;

                ObtenerRecubrimientoElemento(
                    elemento,
                    out recCm,
                    out nombreRec);

                mejorPuntaje =
                    puntaje;

                mejor =
                    new DatosElementoExtremo
                    {
                        Elemento =
                            elemento,
                        AnchoProyectado =
                            anchoProyectado,
                        ZInferior =
                            caja.Min.Z,
                        ZSuperior =
                            caja.Max.Z,
                        Categoria =
                            categoria,
                        Nombre =
                            nombre,
                        RecubrimientoCm =
                            recCm,
                        NombreRecubrimiento =
                            nombreRec
                    };
            }
        }

        return mejor;
    }

    private double ObtenerPrioridadCategoriaExtremo(
        BuiltInCategory categoria)
    {
        // Penalizaciones pequeñas. La distancia REAL manda;
        // la categoría solo resuelve empates muy cercanos.
        if (categoria ==
            BuiltInCategory.OST_StructuralColumns ||
            categoria ==
            BuiltInCategory.OST_Columns)
        {
            return 0.0;
        }

        if (categoria ==
            BuiltInCategory.OST_StructuralFraming)
        {
            return
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters);
        }

        if (categoria ==
            BuiltInCategory.OST_Walls)
        {
            return
                UnitUtils.ConvertToInternalUnits(
                    3.0,
                    UnitTypeId.Millimeters);
        }

        return
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Millimeters);
    }

    private bool TryObtenerInterseccionRealExtremo(
        Element elemento,
        XYZ puntoExtremo,
        XYZ direccionExterior,
        DatosMuro datosMuro,
        double longitudBusqueda,
        out double distanciaInicio,
        out double anchoReal)
    {
        distanciaInicio =
            double.MaxValue;

        anchoReal =
            0.0;

        if (elemento == null ||
            puntoExtremo == null ||
            direccionExterior == null ||
            direccionExterior.GetLength() <= Tol ||
            datosMuro == null ||
            longitudBusqueda <= Tol)
        {
            return false;
        }

        List<Solid> solidos =
            ObtenerSolidosElementoExtremo(
                elemento);

        if (solidos.Count == 0)
            return false;

        XYZ d =
            new XYZ(
                direccionExterior.X,
                direccionExterior.Y,
                0.0).Normalize();

        XYZ n =
            new XYZ(
                -d.Y,
                d.X,
                0.0);

        double espesor =
            System.Math.Max(
                datosMuro.Espesor,
                UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Centimeters));

        double[] offsetsLaterales =
        {
            0.0,
            espesor * 0.20,
            -espesor * 0.20,
            espesor * 0.40,
            -espesor * 0.40
        };

        double altura =
            datosMuro.ZSuperior -
            datosMuro.ZInferior;

        if (altura <= Tol)
            return false;

        double[] factoresZ =
        {
            0.25,
            0.50,
            0.75
        };

        bool encontrado =
            false;

        // Empezamos 2 mm detrás del extremo para que una cara
        // coincidente con el extremo también sea reconocida.
        double retroceso =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        double longitudRayo =
            longitudBusqueda +
            retroceso;

        using (
            SolidCurveIntersectionOptions opciones =
                new SolidCurveIntersectionOptions())
        {
            foreach (double factorZ in factoresZ)
            {
                double z =
                    datosMuro.ZInferior +
                    altura * factorZ;

                foreach (double offset in offsetsLaterales)
                {
                    XYZ baseXY =
                        puntoExtremo +
                        n.Multiply(offset) -
                        d.Multiply(retroceso);

                    XYZ inicioRayo =
                        new XYZ(
                            baseXY.X,
                            baseXY.Y,
                            z);

                    XYZ finRayo =
                        inicioRayo +
                        d.Multiply(
                            longitudRayo);

                    Line rayo;

                    try
                    {
                        rayo =
                            Line.CreateBound(
                                inicioRayo,
                                finRayo);
                    }
                    catch
                    {
                        continue;
                    }

                    foreach (Solid solid in solidos)
                    {
                        if (solid == null)
                            continue;

                        SolidCurveIntersection interseccion =
                            null;

                        try
                        {
                            interseccion =
                                solid.IntersectWithCurve(
                                    rayo,
                                    opciones);

                            if (interseccion == null ||
                                interseccion.SegmentCount == 0)
                            {
                                continue;
                            }

                            for (int i = 0;
                                 i < interseccion.SegmentCount;
                                 i++)
                            {
                                Curve segmento =
                                    interseccion.GetCurveSegment(i);

                                if (segmento == null ||
                                    segmento.Length <= Tol)
                                {
                                    continue;
                                }

                                XYZ a =
                                    segmento.GetEndPoint(0);

                                XYZ b =
                                    segmento.GetEndPoint(1);

                                double ta =
                                    (a - puntoExtremo)
                                        .DotProduct(d);

                                double tb =
                                    (b - puntoExtremo)
                                        .DotProduct(d);

                                double t0 =
                                    System.Math.Min(
                                        ta,
                                        tb);

                                double t1 =
                                    System.Math.Max(
                                        ta,
                                        tb);

                                // Recortamos cualquier pequeño tramo
                                // que haya quedado detrás del extremo.
                                t0 =
                                    System.Math.Max(
                                        0.0,
                                        t0);

                                if (t1 <= Tol ||
                                    t0 > longitudBusqueda)
                                {
                                    continue;
                                }

                                t1 =
                                    System.Math.Min(
                                        longitudBusqueda,
                                        t1);

                                double ancho =
                                    t1 - t0;

                                if (ancho <= Tol)
                                    continue;

                                double toleranciaEmpate =
                                    UnitUtils.ConvertToInternalUnits(
                                        1.0,
                                        UnitTypeId.Millimeters);

                                if (!encontrado ||
                                    t0 < distanciaInicio -
                                    toleranciaEmpate ||
                                    (System.Math.Abs(
                                        t0 - distanciaInicio) <=
                                        toleranciaEmpate &&
                                     ancho < anchoReal))
                                {
                                    encontrado = true;
                                    distanciaInicio = t0;
                                    anchoReal = ancho;
                                }
                            }
                        }
                        catch
                        {
                            // Sólidos degenerados o familias especiales:
                            // simplemente probamos el siguiente sólido/rayo.
                        }
                        finally
                        {
                            if (interseccion != null)
                                interseccion.Dispose();
                        }
                    }
                }
            }
        }

        return
            encontrado &&
            anchoReal > Tol;
    }

    private List<Solid> ObtenerSolidosElementoExtremo(
        Element elemento)
    {
        List<Solid> resultado =
            new List<Solid>();

        if (elemento == null)
            return resultado;

        try
        {
            Options opciones =
                new Options
                {
                    ComputeReferences = false,
                    IncludeNonVisibleObjects = false,
                    DetailLevel =
                        ViewDetailLevel.Fine
                };

            GeometryElement geometria =
                elemento.get_Geometry(
                    opciones);

            AgregarSolidosElementoExtremo(
                geometria,
                resultado);
        }
        catch
        {
        }

        return resultado;
    }

    private void AgregarSolidosElementoExtremo(
        GeometryElement geometria,
        List<Solid> resultado)
    {
        if (geometria == null ||
            resultado == null)
        {
            return;
        }

        foreach (GeometryObject objeto in geometria)
        {
            if (objeto == null)
                continue;

            Solid solid =
                objeto as Solid;

            if (solid != null)
            {
                try
                {
                    if (solid.Faces != null &&
                        solid.Faces.Size > 0 &&
                        solid.Edges != null &&
                        solid.Edges.Size > 0)
                    {
                        resultado.Add(
                            solid);
                    }
                }
                catch
                {
                }

                continue;
            }

            GeometryInstance instancia =
                objeto as GeometryInstance;

            if (instancia != null)
            {
                try
                {
                    GeometryElement geometriaInstancia =
                        instancia.GetInstanceGeometry();

                    AgregarSolidosElementoExtremo(
                        geometriaInstancia,
                        resultado);
                }
                catch
                {
                }
            }
        }
    }


    private double DistanciaPuntoCajaXY(
        XYZ punto,
        BoundingBoxXYZ caja)
    {
        if (punto == null ||
            caja == null)
        {
            return double.MaxValue;
        }

        double x =
            Math.Max(
                caja.Min.X,
                Math.Min(
                    punto.X,
                    caja.Max.X));

        double y =
            Math.Max(
                caja.Min.Y,
                Math.Min(
                    punto.Y,
                    caja.Max.Y));

        double dx =
            punto.X - x;

        double dy =
            punto.Y - y;

        return Math.Sqrt(
            dx * dx +
            dy * dy);
    }

    private double ObtenerAnchoCajaProyectado(
        BoundingBoxXYZ caja,
        XYZ direccion)
    {
        if (caja == null ||
            direccion == null ||
            direccion.GetLength() <= Tol)
        {
            return 0.0;
        }

        XYZ d =
            new XYZ(
                direccion.X,
                direccion.Y,
                0.0).Normalize();

        XYZ[] esquinas =
        {
            new XYZ(caja.Min.X, caja.Min.Y, 0.0),
            new XYZ(caja.Min.X, caja.Max.Y, 0.0),
            new XYZ(caja.Max.X, caja.Min.Y, 0.0),
            new XYZ(caja.Max.X, caja.Max.Y, 0.0)
        };

        double min =
            double.MaxValue;

        double max =
            double.MinValue;

        foreach (XYZ esquina in esquinas)
        {
            double t =
                esquina.DotProduct(d);

            min = Math.Min(min, t);
            max = Math.Max(max, t);
        }

        return Math.Max(
            0.0,
            max - min);
    }

    private AceroMuroForm.AceroMuroVistaElevacion CrearVistaElevacion(
        Document doc,
        List<CadenaMuros> cadenas,
        List<string> avisos)
    {
        AceroMuroForm.AceroMuroVistaElevacion vista =
            new AceroMuroForm.AceroMuroVistaElevacion();

        vista.CantidadCadenas =
            cadenas != null
                ? cadenas.Count
                : 0;

        if (avisos != null)
            vista.Avisos.AddRange(avisos);

        if (cadenas == null)
            return vista;

        // Separación SOLO GRÁFICA entre cadenas que de verdad
        // no se pudieron unir. Antes eran 50 cm y por eso la
        // preview se veía artificialmente muy separada.
        double separacionCadenas =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        double toleranciaVacioVisible =
            UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters);

        double cursor = 0.0;

        foreach (CadenaMuros cadena in cadenas)
        {
            if (cadena == null ||
                cadena.Tramos == null ||
                cadena.Tramos.Count == 0)
            {
                continue;
            }

            double xInicioCadena =
                cursor;

            // -------------------------------------------------
            // ELEMENTO REAL EN EL EXTREMO INICIAL
            // -------------------------------------------------
            DatosElementoExtremo elementoInicio =
                BuscarElementoExtremoCadena(
                    doc,
                    cadena,
                    true);

            if (elementoInicio != null &&
                elementoInicio.AnchoProyectado > Tol)
            {
                vista.ElementosExtremos.Add(
                    new AceroMuroForm.AceroMuroElementoExtremoVista
                    {
                        ElementoId =
                            elementoInicio.Elemento.Id.Value,
                        Cadena =
                            cadena.Numero,
                        EsInicio = true,
                        Categoria =
                            elementoInicio.Categoria,
                        Nombre =
                            elementoInicio.Nombre,
                        RecubrimientoCm =
                            elementoInicio.RecubrimientoCm,
                        NombreRecubrimiento =
                            elementoInicio.NombreRecubrimiento,
                        XInicio =
                            xInicioCadena -
                            elementoInicio.AnchoProyectado,
                        XFin =
                            xInicioCadena,
                        // Visualmente el elemento de extremo se muestra
                        // con la MISMA altura del tramo de muro adyacente.
                        // Así no sobresale hacia arriba/abajo como una columna real.
                        ZInferior =
                            cadena.Tramos[0]
                                .Datos.ZInferior,
                        ZSuperior =
                            cadena.Tramos[0]
                                .Datos.ZSuperior
                    });
            }

            for (int i = 0;
                 i < cadena.Tramos.Count;
                 i++)
            {
                TramoCadena tramo =
                    cadena.Tramos[i];

                if (tramo == null ||
                    tramo.Datos == null)
                {
                    continue;
                }

                double longitud =
                    ObtenerLongitudTramo(
                        tramo);

                double xInicioTramo =
                    cursor;

                double xFinTramo =
                    cursor + longitud;

                vista.Tramos.Add(
                    new AceroMuroForm.AceroMuroTramoVista
                    {
                        MuroId =
                            tramo.Datos.Muro.Id.Value,
                        Nombre =
                            ObtenerNombreMuro(
                                tramo.Datos.Muro),
                        Cadena =
                            cadena.Numero,
                        EsCurvo =
                            tramo.Datos.EsCurvo,
                        XInicio =
                            xInicioTramo,
                        XFin =
                            xFinTramo,
                        ZInferior =
                            tramo.Datos.ZInferior,
                        ZSuperior =
                            tramo.Datos.ZSuperior
                    });

                cursor =
                    xFinTramo;

                if (i < cadena.Tramos.Count - 1)
                {
                    TramoCadena siguiente =
                        cadena.Tramos[i + 1];

                    if (siguiente != null &&
                        siguiente.Datos != null)
                    {
                        double distanciaVacia =
                            Distancia2D(
                                tramo.Fin,
                                siguiente.Inicio);

                        if (distanciaVacia >
                            toleranciaVacioVisible)
                        {
                            // El hueco geométrico completo se mantiene para
                            // posicionar correctamente el siguiente muro.
                            double xInicioHuecoTotal =
                                cursor;

                            double xFinHuecoTotal =
                                cursor +
                                distanciaVacia;

                            double xInicioVacio =
                                xInicioHuecoTotal;

                            double xFinVacio =
                                xFinHuecoTotal;

                            double zInferiorVacio =
                                Math.Max(
                                    tramo.Datos.ZInferior,
                                    siguiente.Datos.ZInferior);

                            double zSuperiorVacio =
                                Math.Min(
                                    tramo.Datos.ZSuperior,
                                    siguiente.Datos.ZSuperior);

                            if (zSuperiorVacio <=
                                zInferiorVacio)
                            {
                                zInferiorVacio =
                                    Math.Min(
                                        tramo.Datos.ZInferior,
                                        siguiente.Datos.ZInferior);

                                zSuperiorVacio =
                                    Math.Max(
                                        tramo.Datos.ZSuperior,
                                        siguiente.Datos.ZSuperior);
                            }

                            DatosElementoExtremo
                                elementoEnHueco =
                                    BuscarElementoEntreTramos(
                                        doc,
                                        cadena,
                                        tramo,
                                        siguiente);

                            if (elementoEnHueco != null &&
                                elementoEnHueco.Elemento != null &&
                                elementoEnHueco.AnchoProyectado > Tol)
                            {
                                // IMPORTANTE:
                                // Dibujamos SOLO el sólido real detectado.
                                // El espacio vacío antes/después queda blanco.
                                double inicioReal =
                                    System.Math.Max(
                                        0.0,
                                        System.Math.Min(
                                            distanciaVacia,
                                            elementoEnHueco
                                                .DistanciaInicioProyectada));

                                double anchoReal =
                                    System.Math.Max(
                                        0.0,
                                        System.Math.Min(
                                            elementoEnHueco
                                                .AnchoProyectado,
                                            distanciaVacia -
                                            inicioReal));

                                if (anchoReal > Tol)
                                {
                                    xInicioVacio =
                                        xInicioHuecoTotal +
                                        inicioReal;

                                    xFinVacio =
                                        xInicioVacio +
                                        anchoReal;
                                }
                            }

                            vista.Vacios.Add(
                                new AceroMuroForm.AceroMuroVacioVista
                                {
                                    ElementoId =
                                        elementoEnHueco != null &&
                                        elementoEnHueco.Elemento != null
                                            ? elementoEnHueco.Elemento.Id.Value
                                            : 0,
                                    TieneElementoReal =
                                        elementoEnHueco != null &&
                                        elementoEnHueco.Elemento != null,
                                    Cadena =
                                        cadena.Numero,
                                    XInicio =
                                        xInicioVacio,
                                    XFin =
                                        xFinVacio,
                                    ZInferior =
                                        zInferiorVacio,
                                    ZSuperior =
                                        zSuperiorVacio,
                                    RecubrimientoCm =
                                        elementoEnHueco != null
                                            ? elementoEnHueco.RecubrimientoCm
                                            : 0.0,
                                    NombreRecubrimiento =
                                        elementoEnHueco != null
                                            ? elementoEnHueco.NombreRecubrimiento
                                            : "",
                                    Descripcion =
                                        "Vacío / pilar / columna"
                                });

                            // El siguiente muro conserva su posición REAL.
                            // Aunque solo dibujemos la columneta, avanzamos
                            // todo el hueco geométrico.
                            cursor =
                                xFinHuecoTotal;
                        }
                    }
                }
            }

            // -------------------------------------------------
            // ELEMENTO REAL EN EL EXTREMO FINAL
            // -------------------------------------------------
            DatosElementoExtremo elementoFin =
                BuscarElementoExtremoCadena(
                    doc,
                    cadena,
                    false);

            if (elementoFin != null &&
                elementoFin.AnchoProyectado > Tol)
            {
                vista.ElementosExtremos.Add(
                    new AceroMuroForm.AceroMuroElementoExtremoVista
                    {
                        ElementoId =
                            elementoFin.Elemento.Id.Value,
                        Cadena =
                            cadena.Numero,
                        EsInicio = false,
                        Categoria =
                            elementoFin.Categoria,
                        Nombre =
                            elementoFin.Nombre,
                        RecubrimientoCm =
                            elementoFin.RecubrimientoCm,
                        NombreRecubrimiento =
                            elementoFin.NombreRecubrimiento,
                        XInicio =
                            cursor,
                        XFin =
                            cursor +
                            elementoFin.AnchoProyectado,
                        // Visualmente el elemento de extremo se muestra
                        // con la MISMA altura del último muro de la cadena.
                        ZInferior =
                            cadena.Tramos[
                                cadena.Tramos.Count - 1]
                                .Datos.ZInferior,
                        ZSuperior =
                            cadena.Tramos[
                                cadena.Tramos.Count - 1]
                                .Datos.ZSuperior
                    });

                // Para que la siguiente cadena no se monte gráficamente
                // sobre el elemento final.
                cursor +=
                    elementoFin.AnchoProyectado;
            }

            cursor +=
                separacionCadenas;
        }

        vista.CantidadMuros =
            vista.Tramos.Count;

        return vista;
    }


    private AceroMuroForm.AceroMuroAjusteTramo
        ObtenerAjusteTramo(
            AceroMuroForm.AceroMuroConfiguracion conf,
            long muroId)
    {
        if (conf == null ||
            conf.AjustesTramos == null)
        {
            return null;
        }

        foreach (
            AceroMuroForm.AceroMuroAjusteTramo ajuste
            in conf.AjustesTramos)
        {
            if (ajuste != null &&
                ajuste.MuroId == muroId)
            {
                return ajuste;
            }
        }

        return null;
    }

    private double ObtenerAjusteCaraPies(
        AceroMuroForm.AceroMuroConfiguracion conf,
        int signo)
    {
        if (conf == null ||
            signo == 0)
        {
            return 0.0;
        }

        double cm =
            signo > 0
                ? conf.AjusteCaraACm
                : conf.AjusteCaraBCm;

        return ConvertirCm(cm);
    }

    // ================================================================
    // LONGITUD MANUAL DE GANCHO
    //
    // Revit guarda la longitud del gancho en RebarBarType para un
    // RebarHookType determinado. Para NO modificar el tipo original
    // del proyecto, MYG crea/reutiliza:
    //
    // - un RebarHookType MYG por extremo manual;
    // - un RebarBarType MYG derivado del tipo vertical seleccionado.
    //
    // Así SUP e INF pueden tener longitudes distintas incluso cuando
    // ambos usan el mismo ángulo.
    // ================================================================
    private bool PrepararConfiguracionLongitudGanchoManual(
        Document doc,
        AceroMuroForm.AceroMuroConfiguracion conf,
        out string error)
    {
        error = "";

        if (doc == null ||
            conf == null ||
            conf.TipoVertical == null)
        {
            error =
                "No se pudo preparar la longitud manual de gancho: configuración inválida.";
            return false;
        }

        bool manualInf =
            conf.LongitudGanchoInferiorManual &&
            conf.GanchoInferior != null;

        bool manualSup =
            conf.LongitudGanchoSuperiorManual &&
            conf.GanchoSuperior != null;

        if (!manualInf &&
            !manualSup)
        {
            return true;
        }

        try
        {
            RebarHookType hookInf =
                conf.GanchoInferior;

            RebarHookType hookSup =
                conf.GanchoSuperior;

            if (manualInf)
            {
                hookInf =
                    ObtenerOCrearGanchoManualMYG(
                        doc,
                        conf.GanchoInferior,
                        false,
                        conf.AnguloGanchoInferior,
                        conf.LongitudGanchoInferiorCm);
            }

            if (manualSup)
            {
                hookSup =
                    ObtenerOCrearGanchoManualMYG(
                        doc,
                        conf.GanchoSuperior,
                        true,
                        conf.AnguloGanchoSuperior,
                        conf.LongitudGanchoSuperiorCm);
            }

            if (manualInf &&
                hookInf == null)
            {
                error =
                    "No se pudo crear/reutilizar el tipo de gancho manual inferior.";
                return false;
            }

            if (manualSup &&
                hookSup == null)
            {
                error =
                    "No se pudo crear/reutilizar el tipo de gancho manual superior.";
                return false;
            }

            RebarBarType tipoManual =
                ObtenerOCrearTipoBarraGanchoManualMYG(
                    doc,
                    conf.TipoVertical,
                    hookInf,
                    hookSup,
                    conf,
                    out error);

            if (tipoManual == null)
                return false;

            conf.TipoVertical =
                tipoManual;

            if (manualInf)
                conf.GanchoInferior =
                    hookInf;

            if (manualSup)
                conf.GanchoSuperior =
                    hookSup;

            return true;
        }
        catch (Exception ex)
        {
            error =
                "No se pudo preparar la longitud manual de gancho. " +
                ex.Message;

            return false;
        }
    }

    private RebarHookType ObtenerOCrearGanchoManualMYG(
        Document doc,
        RebarHookType original,
        bool superior,
        int angulo,
        double longitudCm)
    {
        if (doc == null ||
            original == null)
        {
            return null;
        }

        int longitudMm =
            (int)Math.Round(
                longitudCm * 10.0);

        string nombre =
            "MYG_GANCHO_" +
            (superior ? "SUP_" : "INF_") +
            angulo +
            "_L" +
            longitudMm +
            "mm_ID" +
            original.Id.Value;

        RebarHookType existente =
            new FilteredElementCollector(doc)
                .OfClass(
                    typeof(RebarHookType))
                .Cast<RebarHookType>()
                .FirstOrDefault(
                    x =>
                        string.Equals(
                            x.Name,
                            nombre,
                            StringComparison.OrdinalIgnoreCase));

        if (existente != null)
            return existente;

        ElementType duplicado =
            original.Duplicate(
                nombre);

        return
            duplicado as RebarHookType;
    }

    private RebarBarType ObtenerOCrearTipoBarraGanchoManualMYG(
        Document doc,
        RebarBarType original,
        RebarHookType hookInf,
        RebarHookType hookSup,
        AceroMuroForm.AceroMuroConfiguracion conf,
        out string error)
    {
        error = "";

        if (doc == null ||
            original == null ||
            conf == null)
        {
            error =
                "No existe un tipo de barra vertical válido.";
            return null;
        }

        string sufijoInf =
            conf.LongitudGanchoInferiorManual
                ? "_I" +
                    conf.AnguloGanchoInferior +
                    "_" +
                    ((int)Math.Round(
                        conf.LongitudGanchoInferiorCm * 10.0)) +
                    "mm"
                : "_IAUTO";

        string sufijoSup =
            conf.LongitudGanchoSuperiorManual
                ? "_S" +
                    conf.AnguloGanchoSuperior +
                    "_" +
                    ((int)Math.Round(
                        conf.LongitudGanchoSuperiorCm * 10.0)) +
                    "mm"
                : "_SAUTO";

        string nombre =
            LimpiarNombreTipoMYG(
                "MYG_GH_" +
                original.Name +
                sufijoInf +
                sufijoSup);

        RebarBarType tipo =
            new FilteredElementCollector(doc)
                .OfClass(
                    typeof(RebarBarType))
                .Cast<RebarBarType>()
                .FirstOrDefault(
                    x =>
                        string.Equals(
                            x.Name,
                            nombre,
                            StringComparison.OrdinalIgnoreCase));

        if (tipo == null)
        {
            tipo =
                original.Duplicate(
                    nombre)
                as RebarBarType;
        }

        if (tipo == null)
        {
            error =
                "No se pudo duplicar el tipo de barra para la longitud manual de gancho.";
            return null;
        }

        if (conf.LongitudGanchoInferiorManual &&
            hookInf != null)
        {
            if (!ConfigurarLongitudGanchoEnTipoBarra(
                tipo,
                hookInf,
                conf.LongitudGanchoInferiorCm,
                out error))
            {
                return null;
            }
        }

        if (conf.LongitudGanchoSuperiorManual &&
            hookSup != null)
        {
            if (!ConfigurarLongitudGanchoEnTipoBarra(
                tipo,
                hookSup,
                conf.LongitudGanchoSuperiorCm,
                out error))
            {
                return null;
            }
        }

        return tipo;
    }

    private bool ConfigurarLongitudGanchoEnTipoBarra(
        RebarBarType tipoBarra,
        RebarHookType tipoGancho,
        double longitudCm,
        out string error)
    {
        error = "";

        if (tipoBarra == null ||
            tipoGancho == null ||
            longitudCm <= 0.0)
        {
            error =
                "La configuración manual del gancho no es válida.";
            return false;
        }

        double longitudPies =
            UnitUtils.ConvertToInternalUnits(
                longitudCm,
                UnitTypeId.Centimeters);

        try
        {
            // Permitir el hook en el tipo duplicado.
            System.Reflection.MethodInfo setPermission =
                tipoBarra.GetType().GetMethod(
                    "SetHookPermission",
                    new Type[]
                    {
                        typeof(ElementId),
                        typeof(bool)
                    });

            if (setPermission != null)
            {
                setPermission.Invoke(
                    tipoBarra,
                    new object[]
                    {
                        tipoGancho.Id,
                        true
                    });
            }

            // Desactivar cálculo automático para este HookType.
            System.Reflection.MethodInfo setAuto =
                tipoBarra.GetType().GetMethod(
                    "SetAutoCalcHookLengths",
                    new Type[]
                    {
                        typeof(ElementId),
                        typeof(bool)
                    });

            if (setAuto != null)
            {
                setAuto.Invoke(
                    tipoBarra,
                    new object[]
                    {
                        tipoGancho.Id,
                        false
                    });
            }

            // Longitud total del gancho definida por el usuario.
            System.Reflection.MethodInfo setLength =
                tipoBarra.GetType().GetMethod(
                    "SetHookLength",
                    new Type[]
                    {
                        typeof(ElementId),
                        typeof(double)
                    });

            if (setLength == null)
            {
                error =
                    "La versión de Revit no expone SetHookLength para RebarBarType.";
                return false;
            }

            setLength.Invoke(
                tipoBarra,
                new object[]
                {
                    tipoGancho.Id,
                    longitudPies
                });

            return true;
        }
        catch (System.Reflection.TargetInvocationException ex)
        {
            string detalle =
                ex.InnerException != null
                    ? ex.InnerException.Message
                    : ex.Message;

            error =
                "Revit rechazó la longitud manual de " +
                longitudCm.ToString("0.0") +
                " cm para el gancho " +
                tipoGancho.Name +
                ". " +
                detalle;

            return false;
        }
        catch (Exception ex)
        {
            error =
                "No se pudo establecer la longitud manual del gancho. " +
                ex.Message;

            return false;
        }
    }

    private string LimpiarNombreTipoMYG(
        string texto)
    {
        string valor =
            texto ?? "MYG_GH";

        char[] invalidos =
        {
            '\\',
            ':',
            '{',
            '}',
            '[',
            ']',
            '|',
            ';',
            '<',
            '>',
            '?',
            '`',
            '~'
        };

        foreach (char c in invalidos)
        {
            valor =
                valor.Replace(
                    c,
                    '_');
        }

        valor =
            valor.Trim();

        if (valor.Length > 180)
        {
            valor =
                valor.Substring(
                    0,
                    180);
        }

        return valor;
    }


    private bool HayGanchoVertical(
        AceroMuroForm.AceroMuroConfiguracion conf)
    {
        return
            conf != null &&
            (conf.GanchoInferior != null ||
             conf.GanchoSuperior != null);
    }

    private double ObtenerSeparacionEjesCapasGancho(
        AceroMuroForm.AceroMuroConfiguracion conf)
    {
        if (conf == null ||
            !conf.CrearVerticales ||
            !conf.CrearHorizontales ||
            conf.TipoVertical == null ||
            conf.TipoHorizontal == null ||
            !HayGanchoVertical(conf))
        {
            return 0.0;
        }

        double diamVert =
            ObtenerDiametroBarra(
                conf.TipoVertical);

        double diamHor =
            ObtenerDiametroBarra(
                conf.TipoHorizontal);

        double holgura =
            ConvertirCm(
                0.5);

        return
            (diamVert + diamHor) * 0.5 +
            holgura;
    }

    private double ObtenerDoublePropiedadReflexion(
        object objeto,
        string propiedad)
    {
        if (objeto == null ||
            string.IsNullOrWhiteSpace(
                propiedad))
        {
            return 0.0;
        }

        try
        {
            System.Reflection.PropertyInfo prop =
                objeto.GetType().GetProperty(
                    propiedad,
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

            if (prop == null)
                return 0.0;

            object valor =
                prop.GetValue(
                    objeto,
                    null);

            if (valor == null)
                return 0.0;

            return
                Convert.ToDouble(
                    valor,
                    System.Globalization.CultureInfo.InvariantCulture);
        }
        catch
        {
            return 0.0;
        }
    }

    private double ObtenerLongitudTangenteGancho(
        RebarBarType tipoBarra,
        RebarHookType tipoGancho)
    {
        if (tipoBarra == null ||
            tipoGancho == null)
        {
            return 0.0;
        }

        try
        {
            foreach (
                System.Reflection.MethodInfo metodo
                in tipoBarra.GetType().GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance))
            {
                if (!string.Equals(
                    metodo.Name,
                    "GetHookTangentLength",
                    StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                System.Reflection.ParameterInfo[] p =
                    metodo.GetParameters();

                if (p.Length != 1)
                    continue;

                object argumento;

                if (p[0].ParameterType.IsAssignableFrom(
                    typeof(RebarHookType)))
                {
                    argumento =
                        tipoGancho;
                }
                else if (p[0].ParameterType ==
                    typeof(ElementId))
                {
                    argumento =
                        tipoGancho.Id;
                }
                else
                {
                    continue;
                }

                object resultado =
                    metodo.Invoke(
                        tipoBarra,
                        new object[]
                        {
                            argumento
                        });

                if (resultado != null)
                {
                    return
                        Convert.ToDouble(
                            resultado,
                            System.Globalization.CultureInfo.InvariantCulture);
                }
            }
        }
        catch
        {
        }

        return 0.0;
    }

    private double ObtenerZonaGanchoHorizontal(
        AceroMuroForm.AceroMuroConfiguracion conf,
        bool superior)
    {
        if (conf == null ||
            !conf.CrearVerticales ||
            !conf.CrearHorizontales ||
            conf.TipoVertical == null ||
            conf.TipoHorizontal == null)
        {
            return 0.0;
        }

        RebarHookType hook =
            superior
                ? conf.GanchoSuperior
                : conf.GanchoInferior;

        int angulo =
            superior
                ? conf.AnguloGanchoSuperior
                : conf.AnguloGanchoInferior;

        if (hook == null ||
            angulo == 0)
        {
            return 0.0;
        }

        double rec =
            ConvertirCm(
                conf.RecubrimientoCm);

        double diamVert =
            ObtenerDiametroBarra(
                conf.TipoVertical);

        double diamHor =
            ObtenerDiametroBarra(
                conf.TipoHorizontal);

        double diametroCurvado =
            ObtenerDoublePropiedadReflexion(
                conf.TipoVertical,
                "StandardHookBendDiameter");

        if (diametroCurvado <= Tol)
        {
            diametroCurvado =
                ObtenerDoublePropiedadReflexion(
                    conf.TipoVertical,
                    "StandardBendDiameter");
        }

        if (diametroCurvado <= Tol)
        {
            diametroCurvado =
                diamVert * 4.0;
        }

        double radioCurvado =
            diametroCurvado * 0.5;

        double centroHorizontalDesdeCara =
            rec +
            diamHor * 0.5;

        // Centro REAL de curvatura en la ejecución.
        double centroCurvaturaDesdeCara =
            rec +
            diamVert * 0.5 +
            radioCurvado;

        double ajuste =
            ConvertirCm(
                superior
                    ? conf.AjusteSuperiorCm
                    : conf.AjusteInferiorCm);

        centroCurvaturaDesdeCara +=
            ajuste;

        return
            Math.Max(
                0.0,
                centroCurvaturaDesdeCara -
                centroHorizontalDesdeCara);
    }

    private int ObtenerDireccionGanchoPorMalla(
        int signo)
    {
        if (signo == 1)
            return -1;

        if (signo == -1)
            return 1;

        return 1;
    }

    private RebarBarType ResolverTipoBarraGrupo(
        Document doc,
        long tipoId,
        string tipoNombre,
        RebarBarType fallback)
    {
        if (doc == null)
            return fallback;

        if (tipoId > 0)
        {
            try
            {
                foreach (
                    RebarBarType tipo
                    in new FilteredElementCollector(doc)
                        .OfClass(typeof(RebarBarType))
                        .Cast<RebarBarType>())
                {
                    if (tipo != null &&
                        tipo.Id != null &&
                        tipo.Id.Value == tipoId)
                    {
                        return tipo;
                    }
                }
            }
            catch
            {
            }
        }

        if (!string.IsNullOrWhiteSpace(
                tipoNombre))
        {
            try
            {
                foreach (
                    RebarBarType tipo
                    in new FilteredElementCollector(doc)
                        .OfClass(typeof(RebarBarType))
                        .Cast<RebarBarType>())
                {
                    if (tipo != null &&
                        string.Equals(
                            tipo.Name,
                            tipoNombre.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return tipo;
                    }
                }
            }
            catch
            {
            }
        }

        return fallback;
    }


    private int ObtenerCantidadGrupoVertical2Puntos(
        AceroMuroForm.AceroMuroGrupoVertical2Puntos grupo,
        double longitudDistribucion)
    {
        if (grupo == null)
            return 0;

        if (grupo.ReglaDistribucion ==
            AceroMuroForm.AceroMuroReglaDistribucionGrupo.NumeroFijo)
        {
            return
                System.Math.Max(
                    2,
                    grupo.Cantidad);
        }

        double espaciado =
            ConvertirCm(
                System.Math.Max(
                    0.1,
                    grupo.EspaciamientoMaximoCm));

        if (longitudDistribucion <= Tol ||
            espaciado <= Tol)
        {
            return 2;
        }

        return
            System.Math.Max(
                2,
                (int)System.Math.Ceiling(
                    longitudDistribucion /
                    espaciado) +
                1);
    }

    private int CrearVerticalesTramoDesdeGruposDosPuntos(
        Document doc,
        TramoCadena tramo,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            tramo == null ||
            tramo.Datos == null ||
            conf == null ||
            conf.GruposVerticales2Puntos == null ||
            conf.GruposVerticales2Puntos.Count == 0 ||
            resultado == null)
        {
            return 0;
        }

        DatosMuro datos =
            tramo.Datos;

        double recubrimiento =
            ConvertirCm(
                conf.RecubrimientoCm);

        double longitudTramo =
            ObtenerLongitudTramo(
                tramo);

        Dictionary<long, List<Solid>> cacheSolidos =
            new Dictionary<long, List<Solid>>();

        int totalGrupos = 0;
        int indiceGrupo = 0;

        foreach (
            AceroMuroForm.AceroMuroGrupoVertical2Puntos grupo
            in conf.GruposVerticales2Puntos)
        {
            indiceGrupo++;

            if (grupo == null)
                continue;

            RebarBarType tipoGrupo =
                ResolverTipoBarraGrupo(
                    doc,
                    grupo.TipoBarraId,
                    grupo.TipoBarraNombre,
                    conf.TipoVertical);

            if (tipoGrupo == null)
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    datos.Muro.Id.Value +
                    ", grupo vertical " +
                    indiceGrupo +
                    ": no se encontró el tipo/diámetro de barra configurado.");

                continue;
            }

            double diametro =
                ObtenerDiametroBarra(
                    tipoGrupo);

            double margenLongitudinal =
                recubrimiento +
                diametro * 0.5;

            double longitudDistribucion =
                longitudTramo -
                margenLongitudinal * 2.0;

            if (longitudDistribucion <= Tol)
                continue;

            int cantidad =
                ObtenerCantidadGrupoVertical2Puntos(
                    grupo,
                    longitudDistribucion);

            int intervalosDistribucion =
                System.Math.Max(
                    1,
                    cantidad - 1);

            double pasoDistribucion =
                longitudDistribucion /
                intervalosDistribucion;

            double uMedio =
                (grupo.InicioU +
                 grupo.FinU) * 0.5;

            int signoGancho =
                uMedio < 0.49
                    ? 1
                    : uMedio > 0.51
                        ? -1
                        : 0;

            int direccionGancho =
                ObtenerDireccionGanchoPorMalla(
                    signoGancho);

            double offset0 =
                ObtenerOffsetDesdeUSeccionManual(
                    tramo,
                    grupo.InicioU);

            double offset1 =
                ObtenerOffsetDesdeUSeccionManual(
                    tramo,
                    grupo.FinU);

            double altura =
                datos.ZSuperior -
                datos.ZInferior;

            double z0 =
                datos.ZInferior +
                grupo.InicioV *
                altura;

            double z1 =
                datos.ZInferior +
                grupo.FinV *
                altura;

            if (!datos.EsCurvo)
            {
                XYZ direccionTramo =
                    Direccion2D(
                        tramo.Inicio,
                        tramo.Fin);

                if (direccionTramo == null ||
                    direccionTramo.GetLength() <= Tol)
                {
                    continue;
                }

                direccionTramo =
                    direccionTramo.Normalize();

                XYZ normalCadena =
                    new XYZ(
                        -direccionTramo.Y,
                        direccionTramo.X,
                        0.0);

                // =================================================
                // V8.73 - PRIMERA PASADA:
                // construir la barra REAL de cada posición y recortarla
                // contra el sólido del mismo Wall.
                // =================================================
                List<Curve> originales =
                    new List<Curve>();

                List<List<Curve>> patrones =
                    new List<List<Curve>>();

                bool huboHuecoGlobal =
                    false;

                for (int i = 0;
                     i < cantidad;
                     i++)
                {
                    double distancia =
                        margenLongitudinal +
                        pasoDistribucion *
                        i;

                    XYZ estacion =
                        tramo.Inicio +
                        direccionTramo.Multiply(
                            distancia);

                    XYZ p0 =
                        new XYZ(
                            estacion.X +
                                normalCadena.X *
                                offset0,
                            estacion.Y +
                                normalCadena.Y *
                                offset0,
                            z0);

                    XYZ p1 =
                        new XYZ(
                            estacion.X +
                                normalCadena.X *
                                offset1,
                            estacion.Y +
                                normalCadena.Y *
                                offset1,
                            z1);

                    if (p0.DistanceTo(p1) <= Tol)
                    {
                        originales.Add(
                            null);

                        patrones.Add(
                            new List<Curve>());

                        continue;
                    }

                    Curve original =
                        Line.CreateBound(
                            p0,
                            p1);

                    bool huboHuecoBarra;

                    List<Curve> partes =
                        RecortarCurvaVerticalPorHuecosInternosMuro(
                            original,
                            datos.Muro,
                            datos.ZInferior,
                            datos.ZSuperior,
                            margenLongitudinal,
                            cacheSolidos,
                            out huboHuecoBarra);

                    originales.Add(
                        original);

                    patrones.Add(
                        partes ??
                        new List<Curve>());

                    if (huboHuecoBarra)
                    {
                        huboHuecoGlobal =
                            true;
                    }
                }

                // =================================================
                // SIN HUECO:
                // conservar EXACTAMENTE el motor anterior Shape Driven.
                // =================================================
                if (!huboHuecoGlobal)
                {
                    XYZ estacion =
                        tramo.Inicio +
                        direccionTramo.Multiply(
                            margenLongitudinal);

                    XYZ p0 =
                        new XYZ(
                            estacion.X +
                                normalCadena.X *
                                offset0,
                            estacion.Y +
                                normalCadena.Y *
                                offset0,
                            z0);

                    XYZ p1 =
                        new XYZ(
                            estacion.X +
                                normalCadena.X *
                                offset1,
                            estacion.Y +
                                normalCadena.Y *
                                offset1,
                            z1);

                    if (p0.DistanceTo(p1) <= Tol)
                        continue;

                    Rebar rebar =
                        CrearRebarDesdeCurvas(
                            doc,
                            datos.Muro,
                            tipoGrupo,
                            direccionTramo,
                            new List<Curve>
                            {
                                Line.CreateBound(
                                    p0,
                                    p1)
                            },
                            conf.GanchoInferior,
                            conf.GanchoSuperior,
                            conf.GanchoInferior != null
                                ? direccionGancho
                                : 0,
                            conf.GanchoSuperior != null
                                ? direccionGancho
                                : 0);

                    if (rebar == null)
                    {
                        resultado.Errores.Add(
                            "Muro ID " +
                            datos.Muro.Id.Value +
                            ", grupo vertical " +
                            indiceGrupo +
                            ": no se pudo crear la barra base.");

                        continue;
                    }

                    if (grupo.ReglaDistribucion ==
                        AceroMuroForm.AceroMuroReglaDistribucionGrupo.NumeroFijo)
                    {
                        AplicarDistribucionNumeroFijo(
                            rebar,
                            cantidad,
                            longitudDistribucion);
                    }
                    else
                    {
                        AplicarDistribucionMaxima(
                            rebar,
                            ConvertirCm(
                                System.Math.Max(
                                    0.1,
                                    grupo.EspaciamientoMaximoCm)),
                            longitudDistribucion);
                    }

                    CompletarParametrosMYGMuro(
                        rebar,
                        datos.Muro,
                        "Acero vertical LIBRE 2 PUNTOS - " +
                            (grupo.ReglaDistribucion ==
                                AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                                    ? "Espaciado máximo"
                                    : "Número fijo"),
                        "MUR-VERT-2P-G" +
                            indiceGrupo);

                    resultado.Verticales++;
                    resultado.Ids.Add(
                        rebar.Id);

                    totalGrupos++;
                    continue;
                }

                // =================================================
                // CON HUECO:
                //
                // Agrupar solamente barras CONSECUTIVAS que tengan la
                // misma silueta vertical. Así:
                //
                // muro completo | hueco | muro completo
                //
                // se convierte normalmente en 3 runs, y una ventana
                // interna puede generar 2 sets (inferior/superior) en
                // el run que atraviesa el vacío.
                // =================================================
                int creadosGrupo =
                    0;

                int inicioRun =
                    0;

                while (inicioRun <
                       patrones.Count)
                {
                    int finRun =
                        inicioRun;

                    while (finRun + 1 <
                           patrones.Count &&
                           SonPatronesVerticalesConHuecosEquivalentes(
                               patrones[inicioRun],
                               patrones[finRun + 1]))
                    {
                        finRun++;
                    }

                    List<Curve> patronBase =
                        patrones[inicioRun];

                    Curve originalBase =
                        originales[inicioRun];

                    int cantidadRun =
                        finRun -
                        inicioRun +
                        1;

                    double longitudRun =
                        cantidadRun <= 1
                            ? 0.0
                            : pasoDistribucion *
                                (cantidadRun - 1);

                    if (patronBase != null &&
                        patronBase.Count > 0 &&
                        originalBase != null)
                    {
                        for (int s = 0;
                             s < patronBase.Count;
                             s++)
                        {
                            Curve segmento =
                                patronBase[s];

                            if (segmento == null ||
                                !segmento.IsBound ||
                                segmento.Length <= Tol)
                            {
                                continue;
                            }

                            double tolExtremo =
                                UnitUtils.ConvertToInternalUnits(
                                    2.0,
                                    UnitTypeId.Millimeters);

                            bool conservaInicio =
                                segmento
                                    .GetEndPoint(0)
                                    .DistanceTo(
                                        originalBase.GetEndPoint(0)) <=
                                tolExtremo;

                            bool conservaFin =
                                segmento
                                    .GetEndPoint(1)
                                    .DistanceTo(
                                        originalBase.GetEndPoint(1)) <=
                                tolExtremo;

                            // V8.74:
                            // Los tramos generados por el RECORTE también
                            // reciben el gancho configurado por defecto.
                            //
                            // Ejemplo: una barra que termina debajo de un
                            // notch recibe GANCHO SUPERIOR en ese nuevo extremo.
                            RebarHookType ganchoInicio =
                                conf.GanchoInferior;

                            RebarHookType ganchoFin =
                                conf.GanchoSuperior;

                            Rebar rebar =
                                CrearRebarDesdeCurvas(
                                    doc,
                                    datos.Muro,
                                    tipoGrupo,
                                    direccionTramo,
                                    new List<Curve>
                                    {
                                        segmento
                                    },
                                    ganchoInicio,
                                    ganchoFin,
                                    ganchoInicio != null
                                        ? direccionGancho
                                        : 0,
                                    ganchoFin != null
                                        ? direccionGancho
                                        : 0);

                            if (rebar == null)
                            {
                                resultado.Errores.Add(
                                    "Muro ID " +
                                    datos.Muro.Id.Value +
                                    ", grupo vertical " +
                                    indiceGrupo +
                                    ": se detectó el hueco, pero no se pudo crear un tramo vertical recortado.");

                                continue;
                            }

                            if (cantidadRun <= 1 ||
                                longitudRun <= Tol)
                            {
                                try
                                {
                                    RebarShapeDrivenAccessor accessor =
                                        rebar.GetShapeDrivenAccessor();

                                    if (accessor != null)
                                    {
                                        accessor.SetLayoutAsSingle();
                                    }
                                }
                                catch
                                {
                                }
                            }
                            else if (grupo.ReglaDistribucion ==
                                AceroMuroForm.AceroMuroReglaDistribucionGrupo.NumeroFijo)
                            {
                                AplicarDistribucionNumeroFijo(
                                    rebar,
                                    cantidadRun,
                                    longitudRun);
                            }
                            else
                            {
                                AplicarDistribucionMaxima(
                                    rebar,
                                    ConvertirCm(
                                        System.Math.Max(
                                            0.1,
                                            grupo.EspaciamientoMaximoCm)),
                                    longitudRun);
                            }

                            CompletarParametrosMYGMuro(
                                rebar,
                                datos.Muro,
                                "Acero vertical LIBRE 2 PUNTOS recortado por HUECO INTERNO - " +
                                    (grupo.ReglaDistribucion ==
                                        AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                                            ? "Espaciado máximo"
                                            : "Número fijo"),
                                "MUR-VERT-HUECO-G" +
                                    indiceGrupo +
                                    "-R" +
                                    (inicioRun + 1) +
                                    "-S" +
                                    (s + 1));

                            resultado.Verticales++;
                            resultado.Ids.Add(
                                rebar.Id);

                            creadosGrupo++;
                        }
                    }

                    inicioRun =
                        finRun + 1;
                }

                if (creadosGrupo == 0)
                {
                    resultado.Errores.Add(
                        "Muro ID " +
                        datos.Muro.Id.Value +
                        ", grupo vertical " +
                        indiceGrupo +
                        ": el grupo coincide completamente con un hueco y no quedó ningún tramo vertical válido.");
                }
                else
                {
                    totalGrupos++;
                }

                continue;
            }

            // =====================================================
            // MURO CURVO:
            //
            // El motor previo ya crea una barra individual por estación.
            // Se mantiene exactamente esa metodología, pero cada barra
            // se recorta primero contra los huecos reales del Wall.
            // =====================================================
            int creadas =
                0;

            bool huboHuecoCurvo =
                false;

            for (int i = 0;
                 i < cantidad;
                 i++)
            {
                double distancia =
                    margenLongitudinal +
                    pasoDistribucion *
                    i;

                XYZ puntoEje =
                    ObtenerPuntoTramoPorDistancia(
                        tramo,
                        distancia);

                XYZ tangente =
                    ObtenerTangenteTramoPorDistancia(
                        tramo,
                        distancia);

                if (puntoEje == null ||
                    tangente == null ||
                    tangente.GetLength() <= Tol)
                {
                    continue;
                }

                tangente =
                    tangente.Normalize();

                XYZ normalLocal =
                    new XYZ(
                        -tangente.Y,
                        tangente.X,
                        0.0);

                if (normalLocal.GetLength() <= Tol)
                    continue;

                normalLocal =
                    normalLocal.Normalize();

                XYZ p0 =
                    new XYZ(
                        puntoEje.X +
                            normalLocal.X *
                            offset0,
                        puntoEje.Y +
                            normalLocal.Y *
                            offset0,
                        z0);

                XYZ p1 =
                    new XYZ(
                        puntoEje.X +
                            normalLocal.X *
                            offset1,
                        puntoEje.Y +
                            normalLocal.Y *
                            offset1,
                        z1);

                if (p0.DistanceTo(p1) <= Tol)
                    continue;

                Curve original =
                    Line.CreateBound(
                        p0,
                        p1);

                bool huboHuecoBarra;

                List<Curve> partes =
                    RecortarCurvaVerticalPorHuecosInternosMuro(
                        original,
                        datos.Muro,
                        datos.ZInferior,
                        datos.ZSuperior,
                        margenLongitudinal,
                        cacheSolidos,
                        out huboHuecoBarra);

                if (huboHuecoBarra)
                {
                    huboHuecoCurvo =
                        true;
                }

                if (partes == null ||
                    partes.Count == 0)
                {
                    continue;
                }

                for (int s = 0;
                     s < partes.Count;
                     s++)
                {
                    Curve segmento =
                        partes[s];

                    if (segmento == null ||
                        !segmento.IsBound ||
                        segmento.Length <= Tol)
                    {
                        continue;
                    }

                    double tolExtremo =
                        UnitUtils.ConvertToInternalUnits(
                            2.0,
                            UnitTypeId.Millimeters);

                    bool conservaInicio =
                        segmento
                            .GetEndPoint(0)
                            .DistanceTo(
                                original.GetEndPoint(0)) <=
                        tolExtremo;

                    bool conservaFin =
                        segmento
                            .GetEndPoint(1)
                            .DistanceTo(
                                original.GetEndPoint(1)) <=
                        tolExtremo;

                    // V8.74:
                    // Igual que en muro recto, un extremo generado por un
                    // hueco usa el gancho inferior/superior configurado.
                    RebarHookType ganchoInicio =
                        conf.GanchoInferior;

                    RebarHookType ganchoFin =
                        conf.GanchoSuperior;

                    Rebar rebar =
                        CrearRebarDesdeCurvas(
                            doc,
                            datos.Muro,
                            tipoGrupo,
                            tangente,
                            new List<Curve>
                            {
                                segmento
                            },
                            ganchoInicio,
                            ganchoFin,
                            ganchoInicio != null
                                ? direccionGancho
                                : 0,
                            ganchoFin != null
                                ? direccionGancho
                                : 0);

                    if (rebar == null)
                        continue;

                    CompletarParametrosMYGMuro(
                        rebar,
                        datos.Muro,
                        huboHuecoBarra
                            ? "Acero vertical LIBRE 2 PUNTOS curvo recortado por HUECO INTERNO"
                            : "Acero vertical LIBRE 2 PUNTOS curvo",
                        huboHuecoBarra
                            ? "MUR-CURVO-VERT-HUECO-2P-G" +
                                indiceGrupo +
                                "-B" +
                                (i + 1) +
                                "-S" +
                                (s + 1)
                            : "MUR-CURVO-VERT-2P-G" +
                                indiceGrupo +
                                "-B" +
                                (i + 1));

                    resultado.Verticales++;
                    resultado.Ids.Add(
                        rebar.Id);

                    creadas++;
                }
            }

            if (creadas > 0)
            {
                totalGrupos++;
            }
            else if (huboHuecoCurvo)
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    datos.Muro.Id.Value +
                    ", grupo vertical " +
                    indiceGrupo +
                    ": las barras coinciden con el hueco y no quedó geometría vertical válida.");
            }
        }

        return totalGrupos;
    }


    private void CrearVerticalesTramo(
        Document doc,
        TramoCadena tramo,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (tramo == null ||
            tramo.Datos == null ||
            conf == null ||
            conf.TipoVertical == null)
        {
            return;
        }

        if (tramo.Datos.EsCurvo)
        {
            CrearVerticalesTramoCurvo(
                doc,
                tramo,
                conf,
                resultado);

            return;
        }

        DatosMuro datos =
            tramo.Datos;

        double diametro =
            ObtenerDiametroBarra(
                conf.TipoVertical);

        double recubrimiento =
            ConvertirCm(
                conf.RecubrimientoCm);

        double margenBase =
            recubrimiento +
            diametro * 0.5;

        double inicioDistribucion =
            margenBase;

        double finDistribucion =
            margenBase;

        double ajusteInferior =
            ConvertirCm(
                conf.AjusteInferiorCm);

        double ajusteSuperior =
            ConvertirCm(
                conf.AjusteSuperiorCm);

        double espaciamiento =
            ConvertirCm(
                conf.EspaciamientoVerticalCm);

        double longitudTramo =
            ObtenerLongitudTramo(
                tramo);

        double longitudDistribucion =
            longitudTramo -
            inicioDistribucion -
            finDistribucion;

        double zInferior =
            datos.ZInferior +
            margenBase +
            ajusteInferior;

        double zSuperior =
            datos.ZSuperior -
            margenBase -
            ajusteSuperior;

        if (longitudDistribucion <= Tol ||
            zSuperior <= zInferior)
        {
            resultado.Errores.Add(
                "Muro ID " +
                datos.Muro.Id.Value +
                ": no hay longitud/altura suficiente para el acero vertical.");

            return;
        }

        XYZ direccionTramo =
            Direccion2D(
                tramo.Inicio,
                tramo.Fin);

        XYZ normalCadena =
            new XYZ(
                -direccionTramo.Y,
                direccionTramo.X,
                0.0);

        List<int> caras =
            ObtenerSignosCaras(
                conf.ModoCaras);

        foreach (int signo in caras)
        {
            double ajusteCara =
                ObtenerAjusteCaraPies(
                    conf,
                    signo);

            double desplazamientoNormal;

            if (!TryObtenerOffsetVerticalCaraExterna(
                tramo,
                signo,
                recubrimiento,
                diametro,
                ajusteCara,
                out desplazamientoNormal))
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    datos.Muro.Id.Value +
                    ": no se pudo posicionar el acero vertical sobre la capa externa del núcleo.");

                continue;
            }

            // UNA MALLA conserva el comportamiento del gancho:
            // si hay gancho, el fuste puede desplazarse al lado
            // opuesto para evitar interferencia.
            if (signo == 0)
            {
                double separacionCapas =
                    ObtenerSeparacionEjesCapasGancho(
                        conf);

                if (separacionCapas > Tol)
                {
                    double nucleoMin;
                    double nucleoMax;

                    if (TryObtenerIntervaloNucleoEnNormalTramo(
                        tramo,
                        out nucleoMin,
                        out nucleoMax))
                    {
                        desplazamientoNormal =
                            System.Math.Max(
                                nucleoMin,
                                desplazamientoNormal -
                                separacionCapas);
                    }
                }
            }

            XYZ puntoInicioPlano =
                tramo.Inicio +
                direccionTramo.Multiply(
                    inicioDistribucion) +
                normalCadena.Multiply(
                    desplazamientoNormal);

            XYZ inferior =
                new XYZ(
                    puntoInicioPlano.X,
                    puntoInicioPlano.Y,
                    zInferior);

            XYZ superior =
                new XYZ(
                    puntoInicioPlano.X,
                    puntoInicioPlano.Y,
                    zSuperior);

            List<Curve> curvas =
                new List<Curve>
                {
                    Line.CreateBound(
                        inferior,
                        superior)
                };

            XYZ normalPlano =
                direccionTramo.Normalize();

            int direccionGancho =
                ObtenerDireccionGanchoPorMalla(
                    signo);

            Rebar rebar =
                CrearRebarDesdeCurvas(
                    doc,
                    datos.Muro,
                    conf.TipoVertical,
                    normalPlano,
                    curvas,
                    conf.GanchoInferior,
                    conf.GanchoSuperior,
                    conf.GanchoInferior != null
                        ? direccionGancho
                        : 0,
                    conf.GanchoSuperior != null
                        ? direccionGancho
                        : 0);

            if (rebar == null)
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    datos.Muro.Id.Value +
                    ": no se pudo crear el acero vertical.");

                continue;
            }

            AplicarDistribucionMaxima(
                rebar,
                espaciamiento,
                longitudDistribucion);

            // =================================================
            // PARÁMETROS DE INSTANCIA - ACERO VERTICAL DE MURO
            // =================================================
            string caraTextoVertical =
                signo == 0
                    ? "Una malla centrada"
                    : signo > 0
                        ? "Cara A"
                        : "Cara B";

            CompletarParametrosMYGMuro(
                rebar,
                datos.Muro,
                "Acero vertical de alma de muro - " +
                    caraTextoVertical,
                "MUR-ALMA-VERT-" +
                    (signo == 0
                        ? "CENTRO"
                        : signo > 0
                            ? "A"
                            : "B"));

            resultado.Verticales++;
            resultado.Ids.Add(
                rebar.Id);
        }
    }

    private double CalcularDesfaseCentroGeometricoMuroRecto(
        Wall muro,
        Curve curva,
        double zInferior,
        double zSuperior,
        double espesor)
    {
        if (muro == null ||
            curva == null ||
            espesor <= Tol)
        {
            return 0.0;
        }

        List<Solid> solidos =
            ObtenerSolidosElementoExtremo(
                muro);

        if (solidos == null ||
            solidos.Count == 0)
        {
            return 0.0;
        }

        XYZ p0 =
            curva.GetEndPoint(0);

        XYZ p1 =
            curva.GetEndPoint(1);

        XYZ punto =
            (p0 + p1) * 0.5;

        XYZ tangente =
            new XYZ(
                p1.X - p0.X,
                p1.Y - p0.Y,
                0.0);

        if (tangente.GetLength() <= Tol)
            return 0.0;

        tangente =
            tangente.Normalize();

        XYZ normalIzquierda =
            new XYZ(
                -tangente.Y,
                tangente.X,
                0.0);

        if (normalIzquierda.GetLength() <= Tol)
            return 0.0;

        normalIzquierda =
            normalIzquierda.Normalize();

        double z =
            (zInferior + zSuperior) * 0.5;

        XYZ centroSeccion =
            new XYZ(
                punto.X,
                punto.Y,
                z);

        double alcance =
            System.Math.Max(
                espesor * 2.5,
                UnitUtils.ConvertToInternalUnits(
                    50.0,
                    UnitTypeId.Centimeters));

        Line rayo =
            Line.CreateBound(
                centroSeccion -
                    normalIzquierda.Multiply(
                        alcance),
                centroSeccion +
                    normalIzquierda.Multiply(
                        alcance));

        bool encontrado =
            false;

        double mejorCentro =
            0.0;

        double mejorError =
            double.MaxValue;

        using (
            SolidCurveIntersectionOptions opciones =
                new SolidCurveIntersectionOptions())
        {
            foreach (
                Solid solid
                in solidos)
            {
                if (solid == null ||
                    solid.Volume <= Tol)
                {
                    continue;
                }

                SolidCurveIntersection inter =
                    null;

                try
                {
                    inter =
                        solid.IntersectWithCurve(
                            rayo,
                            opciones);

                    if (inter == null)
                        continue;

                    for (int i = 0;
                         i < inter.SegmentCount;
                         i++)
                    {
                        Curve seg =
                            inter.GetCurveSegment(i);

                        if (seg == null ||
                            seg.Length <= Tol)
                        {
                            continue;
                        }

                        XYZ a =
                            seg.GetEndPoint(0);

                        XYZ b =
                            seg.GetEndPoint(1);

                        double ta =
                            (a - centroSeccion)
                                .DotProduct(
                                    normalIzquierda);

                        double tb =
                            (b - centroSeccion)
                                .DotProduct(
                                    normalIzquierda);

                        double ancho =
                            System.Math.Abs(
                                tb - ta);

                        double centro =
                            (ta + tb) * 0.5;

                        double error =
                            System.Math.Abs(
                                ancho -
                                espesor);

                        if (!encontrado ||
                            error <
                            mejorError)
                        {
                            encontrado =
                                true;

                            mejorError =
                                error;

                            mejorCentro =
                                centro;
                        }
                    }
                }
                catch
                {
                }
                finally
                {
                    if (inter != null)
                        inter.Dispose();
                }
            }
        }

        return
            encontrado
                ? mejorCentro
                : 0.0;
    }

    private bool TryObtenerLimitesNucleoDesdeCentro(
        Wall muro,
        out double minimo,
        out double maximo)
    {
        minimo = 0.0;
        maximo = 0.0;

        if (muro == null ||
            muro.WallType == null)
        {
            return false;
        }

        CompoundStructure estructura =
            null;

        try
        {
            estructura =
                muro.WallType
                    .GetCompoundStructure();
        }
        catch
        {
        }

        if (estructura == null)
            return false;

        IList<CompoundStructureLayer> capas =
            null;

        try
        {
            capas =
                estructura.GetLayers();
        }
        catch
        {
        }

        if (capas == null ||
            capas.Count == 0)
        {
            return false;
        }

        int primero =
            -1;

        int ultimo =
            -1;

        // Preferencia: límites de núcleo definidos por Revit.
        try
        {
            System.Reflection.MethodInfo miPrimero =
                estructura.GetType().GetMethod(
                    "GetFirstCoreLayerIndex",
                    System.Type.EmptyTypes);

            System.Reflection.MethodInfo miUltimo =
                estructura.GetType().GetMethod(
                    "GetLastCoreLayerIndex",
                    System.Type.EmptyTypes);

            if (miPrimero != null)
            {
                object v =
                    miPrimero.Invoke(
                        estructura,
                        null);

                if (v != null)
                    primero =
                        System.Convert.ToInt32(v);
            }

            if (miUltimo != null)
            {
                object v =
                    miUltimo.Invoke(
                        estructura,
                        null);

                if (v != null)
                    ultimo =
                        System.Convert.ToInt32(v);
            }
        }
        catch
        {
            primero = -1;
            ultimo = -1;
        }

        // Respaldo: capas cuya función es Structure.
        if (primero < 0 ||
            ultimo < primero ||
            ultimo >= capas.Count)
        {
            for (int i = 0;
                 i < capas.Count;
                 i++)
            {
                if (capas[i] != null &&
                    capas[i].Function ==
                        MaterialFunctionAssignment.Structure)
                {
                    if (primero < 0)
                        primero = i;

                    ultimo = i;
                }
            }
        }

        if (primero < 0 ||
            ultimo < primero)
        {
            return false;
        }

        double anchoTotal =
            0.0;

        double antes =
            0.0;

        double nucleo =
            0.0;

        double despues =
            0.0;

        for (int i = 0;
             i < capas.Count;
             i++)
        {
            double ancho =
                capas[i] != null
                    ? capas[i].Width
                    : 0.0;

            anchoTotal +=
                ancho;

            if (i < primero)
                antes += ancho;
            else if (i <= ultimo)
                nucleo += ancho;
            else
                despues += ancho;
        }

        if (anchoTotal <= Tol ||
            nucleo <= Tol)
        {
            return false;
        }

        // Capas Revit: exterior -> interior.
        // Coordenada local sobre Wall.Orientation:
        // exterior = +, interior = -.
        double caraNucleoExterior =
            anchoTotal * 0.5 -
            antes;

        double caraNucleoInterior =
            -anchoTotal * 0.5 +
            despues;

        minimo =
            System.Math.Min(
                caraNucleoInterior,
                caraNucleoExterior);

        maximo =
            System.Math.Max(
                caraNucleoInterior,
                caraNucleoExterior);

        return
            maximo -
            minimo >
            Tol;
    }

    private bool TryObtenerIntervaloNucleoEnNormalTramo(
        TramoCadena tramo,
        out double minimo,
        out double maximo)
    {
        minimo = 0.0;
        maximo = 0.0;

        if (tramo == null ||
            tramo.Datos == null ||
            tramo.Datos.Muro == null)
        {
            return false;
        }

        double minOrientacion;
        double maxOrientacion;

        bool tieneNucleo =
            TryObtenerLimitesNucleoDesdeCentro(
                tramo.Datos.Muro,
                out minOrientacion,
                out maxOrientacion);

        if (!tieneNucleo)
        {
            minOrientacion =
                -tramo.Datos.Espesor * 0.5;

            maxOrientacion =
                tramo.Datos.Espesor * 0.5;
        }

        double longitud =
            ObtenerLongitudTramo(
                tramo);

        XYZ tangente =
            ObtenerTangenteTramoPorDistancia(
                tramo,
                longitud * 0.5);

        XYZ normalIzquierda =
            new XYZ(
                -tangente.Y,
                tangente.X,
                0.0);

        if (normalIzquierda.GetLength() <= Tol)
            return false;

        normalIzquierda =
            normalIzquierda.Normalize();

        XYZ orientacion =
            tramo.Datos.Muro.Orientation;

        if (orientacion == null ||
            orientacion.GetLength() <= Tol)
        {
            orientacion =
                normalIzquierda;
        }
        else
        {
            orientacion =
                new XYZ(
                    orientacion.X,
                    orientacion.Y,
                    0.0);

            if (orientacion.GetLength() <= Tol)
                orientacion =
                    normalIzquierda;
            else
                orientacion =
                    orientacion.Normalize();
        }

        double alineacion =
            orientacion.DotProduct(
                normalIzquierda);

        if (System.Math.Abs(
                alineacion) < 0.5)
        {
            alineacion =
                alineacion >= 0.0
                    ? 1.0
                    : -1.0;
        }
        else
        {
            alineacion =
                alineacion >= 0.0
                    ? 1.0
                    : -1.0;
        }

        double desplazamientoCentro =
            tramo.Datos.EsCurvo &&
            tramo.Datos.TieneGeometriaRadialReal
                ? 0.0
                : tramo.Datos.DesfaseCentroGeometrico;

        double a =
            desplazamientoCentro +
            minOrientacion *
            alineacion;

        double b =
            desplazamientoCentro +
            maxOrientacion *
            alineacion;

        minimo =
            System.Math.Min(
                a,
                b);

        maximo =
            System.Math.Max(
                a,
                b);

        return
            maximo -
            minimo >
            Tol;
    }

    private bool TryObtenerOffsetVerticalCaraExterna(
        TramoCadena tramo,
        int signo,
        double recubrimiento,
        double diametroVertical,
        double ajusteCara,
        out double offset)
    {
        offset = 0.0;

        double nucleoMin;
        double nucleoMax;

        if (!TryObtenerIntervaloNucleoEnNormalTramo(
            tramo,
            out nucleoMin,
            out nucleoMax))
        {
            return false;
        }

        // UNA MALLA:
        // el vertical permanece en el centro del núcleo.
        if (signo == 0)
        {
            offset =
                (nucleoMin +
                 nucleoMax) * 0.5;

            return true;
        }

        double margen =
            recubrimiento +
            diametroVertical * 0.5 +
            ajusteCara;

        if (signo > 0)
        {
            offset =
                nucleoMax -
                margen;
        }
        else
        {
            offset =
                nucleoMin +
                margen;
        }

        offset =
            System.Math.Min(
                nucleoMax,
                System.Math.Max(
                    nucleoMin,
                    offset));

        return true;
    }

    private bool TryObtenerOffsetHorizontalDentroNucleo(
        TramoCadena tramo,
        int signo,
        double recubrimiento,
        double diametroVertical,
        double diametroHorizontal,
        double ajusteCara,
        bool hayVerticales,
        out double offset)
    {
        offset = 0.0;

        double nucleoMin;
        double nucleoMax;

        if (!TryObtenerIntervaloNucleoEnNormalTramo(
            tramo,
            out nucleoMin,
            out nucleoMax))
        {
            return false;
        }

        // UNA MALLA:
        // ambas direcciones quedan en el centro del núcleo.
        if (signo == 0)
        {
            offset =
                (nucleoMin +
                 nucleoMax) * 0.5;

            return true;
        }

        // =====================================================
        // ORDEN DE CAPAS EN DOBLE MALLA
        //
        // CARA DEL NÚCLEO
        //   | recubrimiento
        //   | [ VERTICAL ]   <- CAPA EXTERNA
        //   | [ HORIZONTAL ] <- CAPA INTERNA
        //   | centro muro
        //
        // Si no se están creando verticales, el horizontal toma
        // directamente la primera capa de recubrimiento.
        // =====================================================
        double distanciaDesdeCara =
            recubrimiento +
            diametroHorizontal * 0.5 +
            ajusteCara;

        if (hayVerticales &&
            diametroVertical > Tol)
        {
            // Las caras de ambas barras quedan tangentes.
            // Distancia del centro horizontal a la cara del núcleo:
            //
            // rec + ØV/2 + (ØV+ØH)/2
            // = rec + ØV + ØH/2
            distanciaDesdeCara =
                recubrimiento +
                diametroVertical +
                diametroHorizontal * 0.5 +
                ajusteCara;
        }

        if (signo > 0)
        {
            offset =
                nucleoMax -
                distanciaDesdeCara;
        }
        else
        {
            offset =
                nucleoMin +
                distanciaDesdeCara;
        }

        // El centro horizontal jamás sale del núcleo.
        offset =
            System.Math.Min(
                nucleoMax,
                System.Math.Max(
                    nucleoMin,
                    offset));

        return true;
    }


    private class CaraCilindricaMuroMYG
    {
        public XYZ Centro;
        public XYZ Eje;
        public double Radio;
        public double Area;
    }

    private bool TryObtenerGeometriaRadialRealMuroCurvo(
        Wall muro,
        Arc arcoLocation,
        double espesor,
        out XYZ centroReal,
        out double radioInterior,
        out double radioExterior,
        out double radioCentro)
    {
        centroReal = null;
        radioInterior = 0.0;
        radioExterior = 0.0;
        radioCentro = 0.0;

        if (muro == null ||
            arcoLocation == null ||
            espesor <= Tol)
        {
            return false;
        }

        List<Solid> solidos =
            ObtenerSolidosElementoExtremo(
                muro);

        if (solidos == null ||
            solidos.Count == 0)
        {
            return false;
        }

        List<CaraCilindricaMuroMYG> caras =
            new List<CaraCilindricaMuroMYG>();

        foreach (
            Solid solid
            in solidos)
        {
            if (solid == null ||
                solid.Volume <= Tol)
            {
                continue;
            }

            foreach (
                Face face
                in solid.Faces)
            {
                CylindricalFace cilindrica =
                    face as CylindricalFace;

                if (cilindrica == null)
                    continue;

                XYZ origen =
                    ObtenerXYZPropiedadReflexionMYG(
                        cilindrica,
                        "Origin");

                XYZ eje =
                    ObtenerXYZPropiedadReflexionMYG(
                        cilindrica,
                        "Axis");

                double radio =
                    ObtenerRadioCaraCilindricaMYG(
                        cilindrica);

                if (origen == null ||
                    eje == null ||
                    radio <= Tol)
                {
                    continue;
                }

                XYZ ejeNorm =
                    eje.Normalize();

                // Muros verticales: la cara cilíndrica principal
                // debe tener eje prácticamente vertical.
                if (System.Math.Abs(
                    ejeNorm.Z) < 0.95)
                {
                    continue;
                }

                XYZ centroXY =
                    new XYZ(
                        origen.X,
                        origen.Y,
                        arcoLocation.Center.Z);

                // Filtrar cilindros no relacionados con el radio
                // principal del muro (joins, insertos, etc.).
                double distanciaCentro =
                    Distancia2D(
                        centroXY,
                        arcoLocation.Center);

                double toleranciaCentro =
                    System.Math.Max(
                        espesor * 2.0,
                        UnitUtils.ConvertToInternalUnits(
                            10.0,
                            UnitTypeId.Centimeters));

                if (distanciaCentro >
                    toleranciaCentro)
                {
                    continue;
                }

                double area =
                    0.0;

                try
                {
                    area =
                        face.Area;
                }
                catch
                {
                }

                caras.Add(
                    new CaraCilindricaMuroMYG
                    {
                        Centro =
                            centroXY,
                        Eje =
                            ejeNorm,
                        Radio =
                            radio,
                        Area =
                            area
                    });
            }
        }

        if (caras.Count == 0)
            return false;

        // -----------------------------------------------------
        // BUSCAR EL PAR INTERIOR / EXTERIOR
        //
        // El par correcto:
        // - comparte centro;
        // - diferencia de radios ≈ Wall.Width;
        // - radios próximos al radio de LocationCurve.
        // -----------------------------------------------------
        CaraCilindricaMuroMYG mejorA =
            null;

        CaraCilindricaMuroMYG mejorB =
            null;

        double mejorPuntaje =
            double.MaxValue;

        for (int i = 0;
             i < caras.Count;
             i++)
        {
            for (int j = i + 1;
                 j < caras.Count;
                 j++)
            {
                CaraCilindricaMuroMYG a =
                    caras[i];

                CaraCilindricaMuroMYG b =
                    caras[j];

                double diferencia =
                    System.Math.Abs(
                        a.Radio -
                        b.Radio);

                double errorEspesor =
                    System.Math.Abs(
                        diferencia -
                        espesor);

                double distanciaCentros =
                    Distancia2D(
                        a.Centro,
                        b.Centro);

                double radioMedio =
                    (a.Radio +
                     b.Radio) * 0.5;

                double errorLocation =
                    System.Math.Abs(
                        radioMedio -
                        arcoLocation.Radius);

                // Las áreas grandes tienen prioridad frente a
                // cilindros pequeños producidos por joins.
                double areaTotal =
                    System.Math.Max(
                        0.0,
                        a.Area) +
                    System.Math.Max(
                        0.0,
                        b.Area);

                double premioArea =
                    areaTotal > Tol
                        ? -System.Math.Min(
                            areaTotal,
                            1000.0) * 1e-6
                        : 0.0;

                double puntaje =
                    errorEspesor * 8.0 +
                    distanciaCentros * 12.0 +
                    errorLocation +
                    premioArea;

                if (puntaje <
                    mejorPuntaje)
                {
                    mejorPuntaje =
                        puntaje;

                    mejorA =
                        a;

                    mejorB =
                        b;
                }
            }
        }

        if (mejorA != null &&
            mejorB != null)
        {
            double diferencia =
                System.Math.Abs(
                    mejorA.Radio -
                    mejorB.Radio);

            // Tolerancia razonable frente a joins/tolerancias.
            double toleranciaEspesor =
                System.Math.Max(
                    espesor * 0.20,
                    UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Millimeters));

            double distanciaCentros =
                Distancia2D(
                    mejorA.Centro,
                    mejorB.Centro);

            double toleranciaCentro =
                UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Millimeters);

            if (System.Math.Abs(
                    diferencia -
                    espesor) <=
                    toleranciaEspesor &&
                distanciaCentros <=
                    toleranciaCentro)
            {
                radioInterior =
                    System.Math.Min(
                        mejorA.Radio,
                        mejorB.Radio);

                radioExterior =
                    System.Math.Max(
                        mejorA.Radio,
                        mejorB.Radio);

                radioCentro =
                    (radioInterior +
                     radioExterior) * 0.5;

                centroReal =
                    new XYZ(
                        (mejorA.Centro.X +
                         mejorB.Centro.X) * 0.5,
                        (mejorA.Centro.Y +
                         mejorB.Centro.Y) * 0.5,
                        arcoLocation.Center.Z);

                return
                    radioCentro > Tol;
            }
        }

        // -----------------------------------------------------
        // RESPALDO CON UNA SOLA CARA CILÍNDRICA
        //
        // Elegimos la cara grande cuyo radio sea compatible con
        // que la LocationCurve esté aproximadamente dentro del muro.
        // -----------------------------------------------------
        CaraCilindricaMuroMYG mejorCara =
            caras
                .OrderByDescending(
                    x => x.Area)
                .ThenBy(
                    x =>
                        System.Math.Abs(
                            x.Radio -
                            arcoLocation.Radius))
                .FirstOrDefault();

        if (mejorCara == null)
            return false;

        double candidatoMas =
            mejorCara.Radio +
            espesor * 0.5;

        double candidatoMenos =
            System.Math.Max(
                Tol,
                mejorCara.Radio -
                espesor * 0.5);

        double errorMas =
            System.Math.Abs(
                candidatoMas -
                arcoLocation.Radius);

        double errorMenos =
            System.Math.Abs(
                candidatoMenos -
                arcoLocation.Radius);

        radioCentro =
            errorMas <= errorMenos
                ? candidatoMas
                : candidatoMenos;

        radioInterior =
            System.Math.Max(
                Tol,
                radioCentro -
                espesor * 0.5);

        radioExterior =
            radioCentro +
            espesor * 0.5;

        centroReal =
            mejorCara.Centro;

        return
            radioCentro > Tol;
    }

    private XYZ ObtenerXYZPropiedadReflexionMYG(
        object objeto,
        string nombrePropiedad)
    {
        if (objeto == null ||
            string.IsNullOrWhiteSpace(
                nombrePropiedad))
        {
            return null;
        }

        try
        {
            System.Reflection.PropertyInfo prop =
                objeto.GetType().GetProperty(
                    nombrePropiedad,
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

            if (prop == null)
                return null;

            return
                prop.GetValue(
                    objeto,
                    null)
                as XYZ;
        }
        catch
        {
            return null;
        }
    }

    private double ObtenerRadioCaraCilindricaMYG(
        CylindricalFace cara)
    {
        if (cara == null)
            return 0.0;

        try
        {
            System.Reflection.PropertyInfo prop =
                cara.GetType().GetProperty(
                    "Radius",
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

            if (prop != null)
            {
                object valor =
                    prop.GetValue(
                        cara,
                        null);

                if (valor is double)
                {
                    double d =
                        (double)valor;

                    if (d > Tol)
                        return d;
                }

                XYZ vector =
                    valor as XYZ;

                if (vector != null &&
                    vector.GetLength() > Tol)
                {
                    return
                        vector.GetLength();
                }
            }
        }
        catch
        {
        }

        // Algunas versiones exponen los vectores de radio.
        string[] nombres =
        {
            "XVector",
            "YVector"
        };

        foreach (
            string nombre
            in nombres)
        {
            XYZ vector =
                ObtenerXYZPropiedadReflexionMYG(
                    cara,
                    nombre);

            if (vector != null &&
                vector.GetLength() > Tol)
            {
                return
                    vector.GetLength();
            }
        }

        return 0.0;
    }


    private double CalcularDesfaseCentroGeometricoMuroCurvo(
        Wall muro,
        Arc arco,
        double zInferior,
        double zSuperior,
        double espesor)
    {
        if (muro == null ||
            arco == null ||
            espesor <= Tol ||
            zSuperior - zInferior <= Tol)
        {
            return 0.0;
        }

        List<Solid> solidos =
            ObtenerSolidosElementoExtremo(
                muro);

        if (solidos == null ||
            solidos.Count == 0)
        {
            return 0.0;
        }

        XYZ puntoEje;

        XYZ tangente;

        try
        {
            puntoEje =
                arco.Evaluate(
                    0.5,
                    true);

            Transform der =
                arco.ComputeDerivatives(
                    0.5,
                    true);

            tangente =
                new XYZ(
                    der.BasisX.X,
                    der.BasisX.Y,
                    0.0);
        }
        catch
        {
            return 0.0;
        }

        if (tangente == null ||
            tangente.GetLength() <= Tol)
        {
            return 0.0;
        }

        tangente =
            tangente.Normalize();

        XYZ normalIzquierda =
            new XYZ(
                -tangente.Y,
                tangente.X,
                0.0);

        if (normalIzquierda.GetLength() <= Tol)
            return 0.0;

        normalIzquierda =
            normalIzquierda.Normalize();

        double z =
            (zInferior +
             zSuperior) * 0.5;

        XYZ centroSeccion =
            new XYZ(
                puntoEje.X,
                puntoEje.Y,
                z);

        // Longitud holgada para atravesar completamente
        // el espesor aunque LocationCurve esté en una cara.
        double alcance =
            System.Math.Max(
                espesor * 2.5,
                UnitUtils.ConvertToInternalUnits(
                    50.0,
                    UnitTypeId.Centimeters));

        XYZ inicio =
            centroSeccion -
            normalIzquierda.Multiply(
                alcance);

        XYZ fin =
            centroSeccion +
            normalIzquierda.Multiply(
                alcance);

        Line rayo;

        try
        {
            rayo =
                Line.CreateBound(
                    inicio,
                    fin);
        }
        catch
        {
            return 0.0;
        }

        bool encontrado =
            false;

        double mejorDesfase =
            0.0;

        double mejorPuntaje =
            double.MaxValue;

        using (
            SolidCurveIntersectionOptions opciones =
                new SolidCurveIntersectionOptions())
        {
            foreach (
                Solid solid
                in solidos)
            {
                if (solid == null ||
                    solid.Volume <= Tol)
                {
                    continue;
                }

                SolidCurveIntersection interseccion =
                    null;

                try
                {
                    interseccion =
                        solid.IntersectWithCurve(
                            rayo,
                            opciones);

                    if (interseccion == null ||
                        interseccion.SegmentCount == 0)
                    {
                        continue;
                    }

                    for (int i = 0;
                         i < interseccion.SegmentCount;
                         i++)
                    {
                        Curve segmento =
                            interseccion.GetCurveSegment(i);

                        if (segmento == null ||
                            segmento.Length <= Tol)
                        {
                            continue;
                        }

                        XYZ a =
                            segmento.GetEndPoint(0);

                        XYZ b =
                            segmento.GetEndPoint(1);

                        double ta =
                            (a - centroSeccion)
                                .DotProduct(
                                    normalIzquierda);

                        double tb =
                            (b - centroSeccion)
                                .DotProduct(
                                    normalIzquierda);

                        double t0 =
                            System.Math.Min(
                                ta,
                                tb);

                        double t1 =
                            System.Math.Max(
                                ta,
                                tb);

                        double ancho =
                            t1 - t0;

                        if (ancho <= Tol)
                            continue;

                        double centro =
                            (t0 + t1) * 0.5;

                        // Elegimos preferentemente el segmento cuyo
                        // ancho coincide con Wall.Width y cuya sección
                        // está más próxima a la LocationCurve.
                        double errorAncho =
                            System.Math.Abs(
                                ancho -
                                espesor);

                        double puntaje =
                            errorAncho * 4.0 +
                            System.Math.Abs(
                                centro);

                        if (!encontrado ||
                            puntaje <
                            mejorPuntaje)
                        {
                            encontrado =
                                true;

                            mejorPuntaje =
                                puntaje;

                            mejorDesfase =
                                centro;
                        }
                    }
                }
                catch
                {
                }
                finally
                {
                    if (interseccion != null)
                        interseccion.Dispose();
                }
            }
        }

        if (!encontrado)
            return 0.0;

        // Protección frente a sólidos inesperados:
        // el centro físico de un muro normal no debería quedar
        // a más de aproximadamente un espesor de la LocationCurve.
        double limite =
            espesor * 1.25;

        mejorDesfase =
            System.Math.Max(
                -limite,
                System.Math.Min(
                    limite,
                    mejorDesfase));

        return
            mejorDesfase;
    }


    private void CrearVerticalesTramoCurvo(
        Document doc,
        TramoCadena tramo,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            tramo == null ||
            tramo.Datos == null ||
            !tramo.Datos.EsCurvo ||
            conf == null ||
            conf.TipoVertical == null ||
            resultado == null)
        {
            return;
        }

        DatosMuro datos =
            tramo.Datos;

        double diametro =
            ObtenerDiametroBarra(
                conf.TipoVertical);

        double recubrimiento =
            ConvertirCm(
                conf.RecubrimientoCm);

        double margenBase =
            recubrimiento +
            diametro * 0.5;

        double ajusteInferior =
            ConvertirCm(
                conf.AjusteInferiorCm);

        double ajusteSuperior =
            ConvertirCm(
                conf.AjusteSuperiorCm);

        double espaciamiento =
            ConvertirCm(
                conf.EspaciamientoVerticalCm);

        double longitudTramo =
            ObtenerLongitudTramo(
                tramo);

        double longitudDistribucion =
            longitudTramo -
            margenBase -
            margenBase;

        double zInferior =
            datos.ZInferior +
            margenBase +
            ajusteInferior;

        double zSuperior =
            datos.ZSuperior -
            margenBase -
            ajusteSuperior;

        if (longitudDistribucion <= Tol ||
            zSuperior <= zInferior)
        {
            resultado.Errores.Add(
                "Muro curvo ID " +
                datos.Muro.Id.Value +
                ": no hay longitud/altura suficiente para el acero vertical.");

            return;
        }

        if (espaciamiento <= Tol)
        {
            resultado.Errores.Add(
                "Muro curvo ID " +
                datos.Muro.Id.Value +
                ": el espaciamiento vertical debe ser mayor que cero.");

            return;
        }

        // Misma lógica conceptual de Maximum Spacing:
        // elegimos el número de intervalos necesario para que
        // el espaciamiento REAL nunca supere el valor indicado.
        int intervalos =
            System.Math.Max(
                1,
                (int)System.Math.Ceiling(
                    longitudDistribucion /
                    espaciamiento));

        int cantidadBarras =
            intervalos + 1;

        double pasoReal =
            longitudDistribucion /
            intervalos;

        List<int> caras =
            ObtenerSignosCaras(
                conf.ModoCaras);

        foreach (
            int signo
            in caras)
        {
            double ajusteCara =
                ObtenerAjusteCaraPies(
                    conf,
                    signo);

            double desplazamientoNormal;

            if (!TryObtenerOffsetVerticalCaraExterna(
                tramo,
                signo,
                recubrimiento,
                diametro,
                ajusteCara,
                out desplazamientoNormal))
            {
                resultado.Errores.Add(
                    "Muro curvo ID " +
                    datos.Muro.Id.Value +
                    ": no se pudo posicionar el vertical sobre la capa externa del núcleo.");

                continue;
            }

            if (signo == 0)
            {
                double separacionCapas =
                    ObtenerSeparacionEjesCapasGancho(
                        conf);

                if (separacionCapas > Tol)
                {
                    double nucleoMin;
                    double nucleoMax;

                    if (TryObtenerIntervaloNucleoEnNormalTramo(
                        tramo,
                        out nucleoMin,
                        out nucleoMax))
                    {
                        desplazamientoNormal =
                            System.Math.Max(
                                nucleoMin,
                                desplazamientoNormal -
                                separacionCapas);
                    }
                }
            }

            string caraTextoVertical =
                signo == 0
                    ? "Una malla centrada"
                    : signo > 0
                        ? "Cara A"
                        : "Cara B";

            int direccionGancho =
                ObtenerDireccionGanchoPorMalla(
                    signo);

            for (int i = 0;
                 i < cantidadBarras;
                 i++)
            {
                double distanciaSobreArco =
                    margenBase +
                    pasoReal * i;

                XYZ puntoEje =
                    ObtenerPuntoTramoPorDistancia(
                        tramo,
                        distanciaSobreArco);

                XYZ tangente =
                    ObtenerTangenteTramoPorDistancia(
                        tramo,
                        distanciaSobreArco);

                XYZ normalIzquierda =
                    new XYZ(
                        -tangente.Y,
                        tangente.X,
                        0.0);

                if (normalIzquierda.GetLength() <= Tol)
                    continue;

                normalIzquierda =
                    normalIzquierda.Normalize();

                XYZ puntoBarra =
                    puntoEje +
                    normalIzquierda.Multiply(
                        desplazamientoNormal);

                XYZ inferior =
                    new XYZ(
                        puntoBarra.X,
                        puntoBarra.Y,
                        zInferior);

                XYZ superior =
                    new XYZ(
                        puntoBarra.X,
                        puntoBarra.Y,
                        zSuperior);

                List<Curve> curvas =
                    new List<Curve>
                    {
                        Line.CreateBound(
                            inferior,
                            superior)
                    };

                // Para una barra vertical sobre un muro curvo,
                // el plano de la barra debe ser perpendicular
                // al recorrido local del muro.
                XYZ normalPlano =
                    tangente.Normalize();

                Rebar rebar =
                    CrearRebarDesdeCurvas(
                        doc,
                        datos.Muro,
                        conf.TipoVertical,
                        normalPlano,
                        curvas,
                        conf.GanchoInferior,
                        conf.GanchoSuperior,
                        conf.GanchoInferior != null
                            ? direccionGancho
                            : 0,
                        conf.GanchoSuperior != null
                            ? direccionGancho
                            : 0);

                if (rebar == null)
                {
                    resultado.Errores.Add(
                        "Muro curvo ID " +
                        datos.Muro.Id.Value +
                        ": no se pudo crear una barra vertical en la estación " +
                        (i + 1) +
                        ".");

                    continue;
                }

                CompletarParametrosMYGMuro(
                    rebar,
                    datos.Muro,
                    "Acero vertical de alma de muro curvo - " +
                        caraTextoVertical,
                    "MUR-CURVO-ALMA-VERT-" +
                        (signo == 0
                            ? "CENTRO"
                            : signo > 0
                                ? "A"
                                : "B"));

                resultado.Verticales++;

                resultado.Ids.Add(
                    rebar.Id);
            }
        }
    }


    private double ObtenerOffsetDesdeUSeccionManual(
        TramoCadena tramo,
        double u)
    {
        if (tramo == null ||
            tramo.Datos == null)
        {
            return 0.0;
        }

        double centroGeom =
            tramo.Datos.EsCurvo &&
            tramo.Datos.TieneGeometriaRadialReal
                ? 0.0
                : tramo.Datos.DesfaseCentroGeometrico;

        // U = 0   -> cara - del espesor real
        // U = 0.5 -> centro geométrico real
        // U = 1   -> cara + del espesor real
        //
        // NO se limita U: el editor permite sacar las barras
        // fuera del anfitrión.
        return
            centroGeom +
            (u - 0.5) *
            tramo.Datos.Espesor;
    }

    private List<Curve> ConstruirTrayectoriaHorizontalManual2P(
        CadenaMuros cadena,
        double u,
        double elevacion,
        double margenBase,
        AceroMuroForm.AceroMuroConfiguracion conf)
    {
        List<Curve> curvas =
            new List<Curve>();

        if (cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return curvas;
        }

        double toleranciaUnion =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Millimeters);

        Curve anterior =
            null;

        for (int i = 0;
             i < cadena.Tramos.Count;
             i++)
        {
            TramoCadena tramo =
                cadena.Tramos[i];

            if (tramo == null ||
                tramo.Datos == null)
            {
                continue;
            }

            AceroMuroForm.AceroMuroAjusteTramo ajuste =
                ObtenerAjusteTramo(
                    conf,
                    tramo.Datos.Muro.Id.Value);

            double ajusteInicio =
                ajuste != null
                    ? ConvertirCm(
                        ajuste.RetiroInicioCm)
                    : 0.0;

            double ajusteFin =
                ajuste != null
                    ? ConvertirCm(
                        ajuste.RetiroFinCm)
                    : 0.0;

            double retiroInicio =
                0.0;

            double retiroFin =
                0.0;

            // =================================================
            // V8.80 - LONGITUD DE DESARROLLO H EXACTA
            //
            // El editor guarda RetiroInicioCm / RetiroFinCm respecto
            // de la línea de RECUBRIMIENTO, no respecto de:
            //
            //     recubrimiento + Ø/2
            //
            // Por ello distinguimos dos situaciones:
            //
            // A) EXTREMO DENTRO DEL MURO:
            //      conservar la lógica normal del centro de barra:
            //      margenBase + ajuste
            //
            // B) EXTREMO EN LA CARA O FUERA DEL MURO:
            //      obedecer EXACTAMENTE la cota H del alzado:
            //      recubrimiento + ajuste
            //
            // Ejemplo:
            // Rec = 5 cm
            // Desarrollo = 50 cm
            // Ajuste guardado = -55 cm
            //
            // retiro exacto = 5 - 55 = -50 cm
            //
            // independientemente de que el grupo sea Ø1/2", Ø5/8",
            // Ø3/4", etc.
            // =================================================
            double recubrimientoBase =
                conf != null
                    ? ConvertirCm(
                        conf.RecubrimientoCm)
                    : System.Math.Max(
                        0.0,
                        margenBase);

            double retiroInicioEditor =
                recubrimientoBase +
                ajusteInicio;

            double retiroFinEditor =
                recubrimientoBase +
                ajusteFin;

            bool inicioEsDesarrolloExterior =
                retiroInicioEditor <= Tol;

            bool finEsDesarrolloExterior =
                retiroFinEditor <= Tol;

            double retiroInicioExacto =
                inicioEsDesarrolloExterior
                    ? retiroInicioEditor
                    : margenBase +
                        ajusteInicio;

            double retiroFinExacto =
                finEsDesarrolloExterior
                    ? retiroFinEditor
                    : margenBase +
                        ajusteFin;

            // =================================================
            // CONTINUOS:
            // H INICIO gobierna el primer muro de la cadena y
            // H FIN gobierna el último.
            //
            // NO CONTINUOS:
            // cada tramo conserva sus ajustes propios.
            // =================================================
            if (conf != null &&
                conf.HorizontalesContinuosPorCadena)
            {
                if (i == 0)
                {
                    retiroInicio =
                        retiroInicioExacto;
                }

                if (i ==
                    cadena.Tramos.Count - 1)
                {
                    retiroFin =
                        retiroFinExacto;
                }
            }
            else
            {
                retiroInicio =
                    retiroInicioExacto;

                retiroFin =
                    retiroFinExacto;
            }

            double offset =
                ObtenerOffsetDesdeUSeccionManual(
                    tramo,
                    u);

            Curve actual =
                CrearCurvaHorizontalOffsetTramo(
                    tramo,
                    offset,
                    elevacion,
                    retiroInicio,
                    retiroFin);

            if (actual == null ||
                actual.Length <= Tol)
            {
                continue;
            }

            // En modo continuo se crea el puente entre muros para
            // conservar una sola trayectoria a través de la cadena.
            if (conf != null &&
                conf.HorizontalesContinuosPorCadena &&
                anterior != null)
            {
                XYZ finAnterior =
                    anterior.GetEndPoint(1);

                XYZ inicioActual =
                    actual.GetEndPoint(0);

                double separacion =
                    finAnterior.DistanceTo(
                        inicioActual);

                if (separacion >
                    toleranciaUnion)
                {
                    try
                    {
                        curvas.Add(
                            Line.CreateBound(
                                finAnterior,
                                inicioActual));
                    }
                    catch
                    {
                    }
                }
            }

            curvas.Add(
                actual);

            anterior =
                actual;
        }

        return curvas;
    }

    private double ObtenerLongitudTotalCurvas(
        IList<Curve> curvas)
    {
        if (curvas == null)
            return 0.0;

        double total =
            0.0;

        foreach (
            Curve curva
            in curvas)
        {
            if (curva != null &&
                curva.IsBound &&
                curva.Length > Tol)
            {
                total +=
                    curva.Length;
            }
        }

        return total;
    }

    private List<Curve> ExtraerSubTrayectoriaPorDistancia(
        IList<Curve> trayectoria,
        double inicio,
        double fin)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (trayectoria == null ||
            trayectoria.Count == 0)
        {
            return resultado;
        }

        double longitudTotal =
            ObtenerLongitudTotalCurvas(
                trayectoria);

        if (longitudTotal <= Tol)
            return resultado;

        inicio =
            System.Math.Max(
                0.0,
                System.Math.Min(
                    longitudTotal,
                    inicio));

        fin =
            System.Math.Max(
                0.0,
                System.Math.Min(
                    longitudTotal,
                    fin));

        if (fin -
            inicio <= Tol)
        {
            return resultado;
        }

        double acumulado =
            0.0;

        foreach (
            Curve curva
            in trayectoria)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            double l =
                curva.Length;

            double tramoInicio =
                acumulado;

            double tramoFin =
                acumulado +
                l;

            double localInicio =
                System.Math.Max(
                    inicio,
                    tramoInicio) -
                tramoInicio;

            double localFin =
                System.Math.Min(
                    fin,
                    tramoFin) -
                tramoInicio;

            if (localFin -
                localInicio >
                Tol)
            {
                Curve sub =
                    ExtraerSubCurvaPorDistancia(
                        curva,
                        localInicio,
                        localFin);

                if (sub != null &&
                    sub.IsBound &&
                    sub.Length > Tol)
                {
                    resultado.Add(
                        sub);
                }
            }

            acumulado =
                tramoFin;

            if (acumulado >=
                fin -
                Tol)
            {
                break;
            }
        }

        return resultado;
    }

    private List<List<Curve>> DividirTrayectoriaConEmpalmeComercial(
        IList<Curve> trayectoria,
        CadenaMuros cadena,
        double u,
        double elevacion,
        double margenBase,
        AceroMuroForm.AceroMuroConfiguracion conf,
        double longitudComercialEje,
        double longitudEmpalme)
    {
        List<List<Curve>> piezas =
            new List<List<Curve>>();

        double longitudTotal =
            ObtenerLongitudTotalCurvas(
                trayectoria);

        if (longitudTotal <= Tol)
            return piezas;

        if (longitudComercialEje <= Tol ||
            longitudTotal <=
                longitudComercialEje +
                Tol)
        {
            piezas.Add(
                trayectoria
                    .Where(
                        x =>
                            x != null &&
                            x.IsBound &&
                            x.Length > Tol)
                    .ToList());

            return piezas;
        }

        double avanceNominal =
            longitudComercialEje -
            longitudEmpalme;

        double minimoAvance =
            UnitUtils.ConvertToInternalUnits(
                10.0,
                UnitTypeId.Centimeters);

        if (avanceNominal <=
            minimoAvance)
        {
            return piezas;
        }

        if (cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            conf == null)
        {
            return piezas;
        }

        // =====================================================
        // V8.69 - ZONAS DE EMPALME EN EL TERCIO CENTRAL
        //
        // Cada double[] representa el rango permitido para FIN:
        //
        // [0] = FIN mínimo permitido
        // [1] = FIN máximo permitido
        //
        // Recuerde que el traslape de dos piezas es:
        //
        // [FIN - Lt ................ FIN]
        //
        // y el quiebre de la segunda pieza se produce en FIN.
        // =====================================================
        List<double[]> zonasPrimarias =
            new List<double[]>();

        List<double[]> zonasSecundarias =
            new List<double[]>();

        List<double[]> zonasTerciarias =
            new List<double[]>();

        double acumuladoTrayectoria =
            0.0;

        double toleranciaUnion =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Millimeters);

        Curve anterior =
            null;

        for (int i = 0;
             i < cadena.Tramos.Count;
             i++)
        {
            TramoCadena tramo =
                cadena.Tramos[i];

            if (tramo == null ||
                tramo.Datos == null)
            {
                continue;
            }

            double longitudMuro =
                ObtenerLongitudTramo(
                    tramo);

            if (longitudMuro <= Tol)
                continue;

            AceroMuroForm.AceroMuroAjusteTramo ajuste =
                ObtenerAjusteTramo(
                    conf,
                    tramo.Datos.Muro.Id.Value);

            double ajusteInicio =
                ajuste != null
                    ? ConvertirCm(
                        ajuste.RetiroInicioCm)
                    : 0.0;

            double ajusteFin =
                ajuste != null
                    ? ConvertirCm(
                        ajuste.RetiroFinCm)
                    : 0.0;

            double retiroInicio =
                0.0;

            double retiroFin =
                0.0;

            // V8.80:
            // usar el MISMO retiro exacto que la trayectoria H real.
            // Esto mantiene sincronizados:
            // - H inicio / H fin;
            // - longitud comercial;
            // - posiciones de empalme;
            // - tercios centrales.
            double recubrimientoBase =
                ConvertirCm(
                    conf.RecubrimientoCm);

            double retiroInicioEditor =
                recubrimientoBase +
                ajusteInicio;

            double retiroFinEditor =
                recubrimientoBase +
                ajusteFin;

            double retiroInicioExacto =
                retiroInicioEditor <= Tol
                    ? retiroInicioEditor
                    : margenBase +
                        ajusteInicio;

            double retiroFinExacto =
                retiroFinEditor <= Tol
                    ? retiroFinEditor
                    : margenBase +
                        ajusteFin;

            if (conf.HorizontalesContinuosPorCadena)
            {
                if (i == 0)
                {
                    retiroInicio =
                        retiroInicioExacto;
                }

                if (i ==
                    cadena.Tramos.Count - 1)
                {
                    retiroFin =
                        retiroFinExacto;
                }
            }
            else
            {
                retiroInicio =
                    retiroInicioExacto;

                retiroFin =
                    retiroFinExacto;
            }

            double offset =
                ObtenerOffsetDesdeUSeccionManual(
                    tramo,
                    u);

            Curve actual =
                CrearCurvaHorizontalOffsetTramo(
                    tramo,
                    offset,
                    elevacion,
                    retiroInicio,
                    retiroFin);

            if (actual == null ||
                actual.Length <= Tol)
            {
                continue;
            }

            // Reproducir exactamente el mismo puente que utiliza
            // ConstruirTrayectoriaHorizontalManual2P().
            if (conf.HorizontalesContinuosPorCadena &&
                anterior != null)
            {
                XYZ finAnterior =
                    anterior.GetEndPoint(1);

                XYZ inicioActual =
                    actual.GetEndPoint(0);

                double separacion =
                    finAnterior.DistanceTo(
                        inicioActual);

                if (separacion >
                    toleranciaUnion)
                {
                    acumuladoTrayectoria +=
                        separacion;
                }
            }

            double inicioCurvaGlobal =
                acumuladoTrayectoria;

            double longitudCurva =
                actual.Length;

            // La curva generada corresponde a las estaciones:
            //
            // s0 = retiroInicio
            // s1 = Lmuro - retiroFin
            //
            // retiro negativo = extensión fuera del muro.
            double s0 =
                retiroInicio;

            double s1 =
                longitudMuro -
                retiroFin;

            double rangoEstaciones =
                s1 -
                s0;

            if (rangoEstaciones > Tol)
            {
                // ---------------------------------------------
                // Intervalo físico del muro que realmente está
                // contenido en esta curva.
                // ---------------------------------------------
                double muroS0 =
                    System.Math.Max(
                        0.0,
                        s0);

                double muroS1 =
                    System.Math.Min(
                        longitudMuro,
                        s1);

                // ---------------------------------------------
                // Tercio central REAL del tramo de muro.
                // ---------------------------------------------
                double tercioS0 =
                    System.Math.Max(
                        longitudMuro /
                            3.0,
                        muroS0);

                double tercioS1 =
                    System.Math.Min(
                        longitudMuro *
                            2.0 /
                            3.0,
                        muroS1);

                if (muroS1 -
                        muroS0 >
                        Tol &&
                    tercioS1 -
                        tercioS0 >
                        Tol)
                {
                    // Para Line y Arc el parámetro de estación del
                    // muro se transforma linealmente a longitud de
                    // la curva de acero offset.
                    double localMuro0 =
                        longitudCurva *
                        ((muroS0 -
                          s0) /
                         rangoEstaciones);

                    double localMuro1 =
                        longitudCurva *
                        ((muroS1 -
                          s0) /
                         rangoEstaciones);

                    double localTercio0 =
                        longitudCurva *
                        ((tercioS0 -
                          s0) /
                         rangoEstaciones);

                    double localTercio1 =
                        longitudCurva *
                        ((tercioS1 -
                          s0) /
                         rangoEstaciones);

                    localMuro0 =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                longitudCurva,
                                localMuro0));

                    localMuro1 =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                longitudCurva,
                                localMuro1));

                    localTercio0 =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                longitudCurva,
                                localTercio0));

                    localTercio1 =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                longitudCurva,
                                localTercio1));

                    double muroGlobal0 =
                        inicioCurvaGlobal +
                        System.Math.Min(
                            localMuro0,
                            localMuro1);

                    double muroGlobal1 =
                        inicioCurvaGlobal +
                        System.Math.Max(
                            localMuro0,
                            localMuro1);

                    double tercioGlobal0 =
                        inicioCurvaGlobal +
                        System.Math.Min(
                            localTercio0,
                            localTercio1);

                    double tercioGlobal1 =
                        inicioCurvaGlobal +
                        System.Math.Max(
                            localTercio0,
                            localTercio1);

                    // =========================================
                    // PRIORIDAD 1
                    //
                    // TODO el traslape Lt dentro del tercio:
                    //
                    // tercio0 <= FIN-Lt
                    // FIN       <= tercio1
                    // =========================================
                    double finPrimarioMin =
                        tercioGlobal0 +
                        longitudEmpalme;

                    double finPrimarioMax =
                        tercioGlobal1;

                    if (finPrimarioMax -
                        finPrimarioMin >
                        -Tol)
                    {
                        zonasPrimarias.Add(
                            new double[]
                            {
                                finPrimarioMin,
                                finPrimarioMax
                            });
                    }

                    // =========================================
                    // PRIORIDAD 2
                    //
                    // El CENTRO del Lt cae en el tercio central
                    // y el traslape completo permanece dentro
                    // del mismo tramo de muro.
                    // =========================================
                    double finSecundarioMin =
                        System.Math.Max(
                            muroGlobal0 +
                                longitudEmpalme,
                            tercioGlobal0 +
                                longitudEmpalme *
                                0.5);

                    double finSecundarioMax =
                        System.Math.Min(
                            muroGlobal1,
                            tercioGlobal1 +
                                longitudEmpalme *
                                0.5);

                    if (finSecundarioMax -
                        finSecundarioMin >
                        -Tol)
                    {
                        zonasSecundarias.Add(
                            new double[]
                            {
                                finSecundarioMin,
                                finSecundarioMax
                            });
                    }

                    // =========================================
                    // PRIORIDAD 3
                    //
                    // Si el muro es demasiado corto para alojar
                    // Lt completo dentro del tercio, por lo menos
                    // el QUIEBRE / final del empalme debe quedar
                    // en el tercio central.
                    // =========================================
                    zonasTerciarias.Add(
                        new double[]
                        {
                            tercioGlobal0,
                            tercioGlobal1
                        });
                }
            }

            acumuladoTrayectoria +=
                longitudCurva;

            anterior =
                actual;
        }

        if (zonasPrimarias.Count == 0 &&
            zonasSecundarias.Count == 0 &&
            zonasTerciarias.Count == 0)
        {
            return piezas;
        }

        double inicio =
            0.0;

        int seguridad =
            0;

        while (inicio <
               longitudTotal -
               Tol &&
               seguridad < 500)
        {
            seguridad++;

            // Si lo que queda ya cabe dentro de la barra comercial,
            // no se necesita otro empalme.
            if (longitudTotal -
                    inicio <=
                longitudComercialEje +
                Tol)
            {
                List<Curve> ultima =
                    ExtraerSubTrayectoriaPorDistancia(
                        trayectoria,
                        inicio,
                        longitudTotal);

                if (ultima != null &&
                    ultima.Count > 0)
                {
                    piezas.Add(
                        ultima);
                }

                break;
            }

            // FIN natural según longitud comercial.
            double finMaximo =
                System.Math.Min(
                    longitudTotal,
                    inicio +
                    longitudComercialEje);

            // Para que la siguiente pieza realmente avance después
            // de descontar el traslape.
            double finMinimo =
                inicio +
                longitudEmpalme +
                minimoAvance;

            if (finMaximo -
                finMinimo <=
                Tol)
            {
                piezas.Clear();

                return piezas;
            }

            double finElegido =
                double.NaN;

            // =================================================
            // Buscar la posición MÁS ADELANTADA posible dentro
            // del tercio central, pero SIN superar L. comercial.
            //
            // Al escoger la más adelantada se modifica lo mínimo
            // posible respecto al corte comercial natural.
            // =================================================
            foreach (
                double[] zona
                in zonasPrimarias)
            {
                if (zona == null ||
                    zona.Length < 2)
                {
                    continue;
                }

                double candidato =
                    System.Math.Min(
                        finMaximo,
                        zona[1]);

                double minimoZona =
                    System.Math.Max(
                        finMinimo,
                        zona[0]);

                if (candidato >=
                        minimoZona -
                        Tol &&
                    (double.IsNaN(finElegido) ||
                     candidato >
                        finElegido))
                {
                    finElegido =
                        candidato;
                }
            }

            if (double.IsNaN(
                    finElegido))
            {
                foreach (
                    double[] zona
                    in zonasSecundarias)
                {
                    if (zona == null ||
                        zona.Length < 2)
                    {
                        continue;
                    }

                    double candidato =
                        System.Math.Min(
                            finMaximo,
                            zona[1]);

                    double minimoZona =
                        System.Math.Max(
                            finMinimo,
                            zona[0]);

                    if (candidato >=
                            minimoZona -
                            Tol &&
                        (double.IsNaN(finElegido) ||
                         candidato >
                            finElegido))
                    {
                        finElegido =
                            candidato;
                    }
                }
            }

            if (double.IsNaN(
                    finElegido))
            {
                foreach (
                    double[] zona
                    in zonasTerciarias)
                {
                    if (zona == null ||
                        zona.Length < 2)
                    {
                        continue;
                    }

                    double candidato =
                        System.Math.Min(
                            finMaximo,
                            zona[1]);

                    double minimoZona =
                        System.Math.Max(
                            finMinimo,
                            zona[0]);

                    if (candidato >=
                            minimoZona -
                            Tol &&
                        (double.IsNaN(finElegido) ||
                         candidato >
                            finElegido))
                    {
                        finElegido =
                            candidato;
                    }
                }
            }

            // Si no existe ningún tercio central alcanzable antes de
            // superar la longitud comercial, NO se deja el empalme
            // afuera. Se devuelve vacío para que la ejecución avise
            // y no cree una solución incorrecta.
            if (double.IsNaN(
                    finElegido))
            {
                piezas.Clear();

                return piezas;
            }

            List<Curve> pieza =
                ExtraerSubTrayectoriaPorDistancia(
                    trayectoria,
                    inicio,
                    finElegido);

            if (pieza == null ||
                pieza.Count == 0)
            {
                piezas.Clear();

                return piezas;
            }

            piezas.Add(
                pieza);

            if (finElegido >=
                longitudTotal -
                Tol)
            {
                break;
            }

            double nuevoInicio =
                finElegido -
                longitudEmpalme;

            if (nuevoInicio <=
                inicio +
                minimoAvance -
                Tol)
            {
                piezas.Clear();

                return piezas;
            }

            inicio =
                System.Math.Max(
                    0.0,
                    nuevoInicio);
        }

        if (seguridad >= 500)
        {
            piezas.Clear();
        }

        return piezas;
    }

    private TramoCadena ObtenerTramoMasCercanoACurva(
        CadenaMuros cadena,
        Curve curva)
    {
        if (cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            curva == null)
        {
            return null;
        }

        XYZ medioCurva;

        try
        {
            medioCurva =
                curva.Evaluate(
                    0.5,
                    true);
        }
        catch
        {
            medioCurva =
                curva.GetEndPoint(0);
        }

        TramoCadena mejor =
            null;

        double mejorDistancia =
            double.MaxValue;

        foreach (
            TramoCadena tramo
            in cadena.Tramos)
        {
            if (tramo == null ||
                tramo.Datos == null)
            {
                continue;
            }

            double longitud =
                ObtenerLongitudTramo(
                    tramo);

            XYZ medioTramo =
                ObtenerPuntoTramoPorDistancia(
                    tramo,
                    longitud * 0.5);

            double d =
                Distancia2D(
                    medioCurva,
                    medioTramo);

            if (d <
                mejorDistancia)
            {
                mejorDistancia =
                    d;

                mejor =
                    tramo;
            }
        }

        return mejor;
    }

    private Curve CrearCurvaTraslapeManualHaciaCentroMuro(
        CadenaMuros cadena,
        Curve curva,
        double u,
        double desfase)
    {
        if (curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol ||
            desfase <= Tol)
        {
            return null;
        }

        int signoCara =
            u > 0.5001
                ? 1
                : u < 0.4999
                    ? -1
                    : 0;

        TramoCadena tramo =
            ObtenerTramoMasCercanoACurva(
                cadena,
                curva);

        return
            CrearCurvaTraslapeHaciaCentroMuro(
                tramo,
                curva,
                signoCara,
                desfase);
    }

    private List<Curve> ConectarCurvasSecuenciales(
        IList<Curve> curvas)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (curvas == null ||
            curvas.Count == 0)
        {
            return resultado;
        }

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Millimeters);

        Curve anterior =
            null;

        foreach (
            Curve curva
            in curvas)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            if (anterior != null)
            {
                XYZ a =
                    anterior.GetEndPoint(1);

                XYZ b =
                    curva.GetEndPoint(0);

                if (a.DistanceTo(
                        b) >
                    tolerancia)
                {
                    try
                    {
                        resultado.Add(
                            Line.CreateBound(
                                a,
                                b));
                    }
                    catch
                    {
                    }
                }
            }

            resultado.Add(
                curva);

            anterior =
                curva;
        }

        return resultado;
    }

    private List<Curve> ConstruirBocetoPiezaHorizontalManualConQuiebre(
        CadenaMuros cadena,
        IList<Curve> pieza,
        double u,
        bool tieneEmpalmeInicio,
        double longitudEmpalme,
        double diametro)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (pieza == null ||
            pieza.Count == 0)
        {
            return resultado;
        }

        double longitudPieza =
            ObtenerLongitudTotalCurvas(
                pieza);

        if (longitudPieza <= Tol)
            return resultado;

        // =====================================================
        // PIEZA 1:
        //
        // Primero conectar y luego CONSOLIDAR.
        //
        // Antes V8.66 podía enviar:
        // Line + Line + Line totalmente colineales.
        // Revit rechazaba esa "forma exacta" porque internamente
        // representa giros de 180° innecesarios.
        //
        // Ahora, si todo está en una misma recta:
        // Line + Line + Line -> UNA sola Line.
        // =====================================================
        if (!tieneEmpalmeInicio)
        {
            List<Curve> baseConectada =
                ConectarCurvasSecuenciales(
                    pieza);

            baseConectada =
                ConsolidarCurvasHorizontalesColineales(
                    baseConectada);

            return
                baseConectada;
        }

        if (longitudEmpalme <= Tol ||
            diametro <= Tol)
        {
            return resultado;
        }

        double xEmpalmeFin =
            System.Math.Min(
                longitudEmpalme,
                longitudPieza);

        double espacioDespuesEmpalme =
            longitudPieza -
            xEmpalmeFin;

        double desfaseEmpalme =
            ObtenerDesfaseEmpalmeCaraACaraMuro(
                diametro);

        double longitudDiagonal;

        if (!TryObtenerLongitudDiagonalQuiebreSeguraMuro(
                espacioDespuesEmpalme,
                desfaseEmpalme,
                out longitudDiagonal) ||
            longitudDiagonal <= Tol)
        {
            return resultado;
        }

        double xDiagonalFin =
            System.Math.Min(
                xEmpalmeFin +
                longitudDiagonal,
                longitudPieza);

        // =====================================================
        // 1. TRASLAPE DESPLAZADO
        // =====================================================
        List<Curve> traslapeBase =
            ExtraerSubTrayectoriaPorDistancia(
                pieza,
                0.0,
                xEmpalmeFin);

        if (traslapeBase.Count == 0)
            return resultado;

        List<Curve> traslapeMovido =
            new List<Curve>();

        foreach (
            Curve c
            in traslapeBase)
        {
            Curve movida =
                CrearCurvaTraslapeManualHaciaCentroMuro(
                    cadena,
                    c,
                    u,
                    desfaseEmpalme);

            if (movida == null)
                return new List<Curve>();

            traslapeMovido.Add(
                movida);
        }

        traslapeMovido =
            ConectarCurvasSecuenciales(
                traslapeMovido);

        // IMPORTANTE:
        // si el traslape atravesó varios muros rectos/puentes,
        // colapsar todos los segmentos colineales en uno solo.
        traslapeMovido =
            ConsolidarCurvasHorizontalesColineales(
                traslapeMovido);

        if (traslapeMovido.Count == 0)
            return resultado;

        double desplazamientoReal =
            ObtenerDesplazamientoRealTraslapeManual(
                traslapeBase,
                traslapeMovido);

        if (desplazamientoReal <
            diametro * 0.50)
        {
            return new List<Curve>();
        }

        // =====================================================
        // 2. DIAGONAL DE RETORNO
        // =====================================================
        List<Curve> sondaBase =
            ExtraerSubTrayectoriaPorDistancia(
                pieza,
                xEmpalmeFin,
                xDiagonalFin);

        if (sondaBase.Count == 0)
            return resultado;

        XYZ pInicioDiagonal =
            traslapeMovido[
                traslapeMovido.Count - 1]
            .GetEndPoint(1);

        XYZ pFinDiagonal =
            sondaBase[
                sondaBase.Count - 1]
            .GetEndPoint(1);

        if (pInicioDiagonal == null ||
            pFinDiagonal == null ||
            pInicioDiagonal.DistanceTo(
                pFinDiagonal) <= Tol)
        {
            return resultado;
        }

        Line diagonal;

        try
        {
            diagonal =
                Line.CreateBound(
                    pInicioDiagonal,
                    pFinDiagonal);
        }
        catch
        {
            return resultado;
        }

        resultado.AddRange(
            traslapeMovido);

        resultado.Add(
            diagonal);

        // =====================================================
        // 3. CONTINUACIÓN SOBRE EL EJE ORIGINAL
        // =====================================================
        if (longitudPieza >
            xDiagonalFin +
            Tol)
        {
            List<Curve> posterior =
                ExtraerSubTrayectoriaPorDistancia(
                    pieza,
                    xDiagonalFin,
                    longitudPieza);

            posterior =
                ConectarCurvasSecuenciales(
                    posterior);

            // Igual que en el traslape: quitar subdivisiones
            // colineales heredadas de los distintos muros.
            posterior =
                ConsolidarCurvasHorizontalesColineales(
                    posterior);

            if (posterior.Count == 0)
                return new List<Curve>();

            XYZ inicioPosterior =
                posterior[0]
                    .GetEndPoint(0);

            double tolerancia =
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Millimeters);

            if (diagonal.GetEndPoint(1)
                    .DistanceTo(
                        inicioPosterior) >
                tolerancia)
            {
                return new List<Curve>();
            }

            resultado.AddRange(
                posterior);
        }

        // =====================================================
        // VALIDACIÓN FINAL:
        // una pieza empalmada debe tener un cambio REAL de dirección.
        // =====================================================
        if (!BocetoHorizontalTieneQuiebreGeometrico(
                resultado))
        {
            resultado.Clear();
        }

        return
            resultado;
    }


    private bool BocetoHorizontalTieneQuiebreGeometrico(
        IList<Curve> boceto)
    {
        if (boceto == null ||
            boceto.Count < 2)
        {
            return false;
        }

        List<XYZ> direcciones =
            new List<XYZ>();

        foreach (
            Curve curva
            in boceto)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            Arc arco =
                curva as Arc;

            if (arco != null)
            {
                // Un arco ya aporta cambio geométrico de dirección.
                // Añadimos dos referencias no colineales para que
                // la validación reconozca el quiebre cuando la pieza
                // atraviesa un tramo curvo.
                direcciones.Add(
                    XYZ.BasisX);

                direcciones.Add(
                    XYZ.BasisY);

                continue;
            }

            Line linea =
                curva as Line;

            if (linea == null)
                continue;

            XYZ p0 =
                linea.GetEndPoint(0);

            XYZ p1 =
                linea.GetEndPoint(1);

            XYZ d =
                new XYZ(
                    p1.X - p0.X,
                    p1.Y - p0.Y,
                    0.0);

            if (d.GetLength() <= Tol)
                continue;

            direcciones.Add(
                d.Normalize());
        }

        if (direcciones.Count < 2)
            return false;

        // 0.25° evita que ruido numérico mínimo sea interpretado
        // como un quiebre real.
        double senoMinimo =
            System.Math.Sin(
                0.25 *
                System.Math.PI /
                180.0);

        for (int i = 0;
             i < direcciones.Count;
             i++)
        {
            for (int j = i + 1;
                 j < direcciones.Count;
                 j++)
            {
                XYZ a =
                    direcciones[i];

                XYZ b =
                    direcciones[j];

                double cruzZ =
                    System.Math.Abs(
                        a.X * b.Y -
                        a.Y * b.X);

                if (cruzZ >
                    senoMinimo)
                {
                    return true;
                }
            }
        }

        return false;
    }

    private double ObtenerDesplazamientoRealTraslapeManual(
        IList<Curve> traslapeBase,
        IList<Curve> traslapeMovido)
    {
        if (traslapeBase == null ||
            traslapeMovido == null ||
            traslapeBase.Count == 0 ||
            traslapeMovido.Count == 0)
        {
            return 0.0;
        }

        Curve base0 =
            traslapeBase[0];

        Curve movida0 =
            traslapeMovido[0];

        if (base0 == null ||
            movida0 == null)
        {
            return 0.0;
        }

        try
        {
            XYZ pBase =
                base0.GetEndPoint(0);

            XYZ pMovido =
                movida0.GetEndPoint(0);

            if (pBase == null ||
                pMovido == null)
            {
                return 0.0;
            }

            return
                pBase.DistanceTo(
                    pMovido);
        }
        catch
        {
            return 0.0;
        }
    }





    private int CrearGrupoHorizontalManualConEmpalmesPorLongitudComercial(
        Document doc,
        CadenaMuros cadena,
        Element host,
        RebarBarType tipoGrupo,
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo,
        int indiceGrupo,
        int indiceGrupoCeroBased,
        int cantidad,
        double margenBase,
        double alturaCadena,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            host == null ||
            tipoGrupo == null ||
            grupo == null ||
            conf == null ||
            resultado == null ||
            !conf.ConsiderarEmpalmeHorizontal)
        {
            return 0;
        }

        double longitudComercial =
            ConvertirCm(
                conf.LongitudComercialCm);

        if (longitudComercial <= Tol)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": L. comercial inválida.");

            return 0;
        }

        double espesor =
            cadena.Tramos[0] != null &&
            cadena.Tramos[0].Datos != null
                ? cadena.Tramos[0].Datos.Espesor
                : 0.0;

        if (espesor <= Tol ||
            alturaCadena <= Tol)
        {
            return 0;
        }

        // =====================================================
        // MOTOR ÚNICO V8.66
        //
        // Un conjunto H con Espaciado máximo / Número fijo debe
        // seguir siendo Shape Driven. Por eso NO se crean 51, 52,
        // etc. trayectorias Free Form individuales.
        //
        // El grupo se representa mediante UNA barra base y Revit
        // distribuye el set en Z usando la regla configurada.
        // =====================================================
        double deltaUReal =
            System.Math.Abs(
                grupo.FinU -
                grupo.InicioU) *
            espesor;

        double toleranciaGuia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        if (deltaUReal >
            toleranciaGuia)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": el grupo es oblicuo en la sección. " +
                "Para conservar Espaciado máximo/Número fijo y empalmes comerciales, " +
                "los dos puntos H deben pertenecer a la misma guía/cara.");

            return 0;
        }

        double vMin =
            System.Math.Min(
                grupo.InicioV,
                grupo.FinV);

        double vMax =
            System.Math.Max(
                grupo.InicioV,
                grupo.FinV);

        double longitudDistribucionOriginal =
            (vMax - vMin) *
            alturaCadena;

        if (longitudDistribucionOriginal <= Tol)
            return 0;

        int cantidadOriginal =
            System.Math.Max(
                2,
                cantidad);

        bool inicioEsInferior =
            grupo.InicioV <=
            grupo.FinV;

        bool ocultarIndice0 =
            DebeOmitirExtremoHorizontalDuplicadoEjecucion(
                conf,
                cadena,
                grupo,
                indiceGrupoCeroBased,
                0,
                cantidadOriginal);

        bool ocultarIndiceFinal =
            DebeOmitirExtremoHorizontalDuplicadoEjecucion(
                conf,
                cadena,
                grupo,
                indiceGrupoCeroBased,
                cantidadOriginal - 1,
                cantidadOriginal);

        bool ocultarInferior =
            inicioEsInferior
                ? ocultarIndice0
                : ocultarIndiceFinal;

        bool ocultarSuperior =
            inicioEsInferior
                ? ocultarIndiceFinal
                : ocultarIndice0;

        double pasoReferencia;

        if (grupo.ReglaDistribucion ==
            AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
        {
            pasoReferencia =
                ConvertirCm(
                    System.Math.Max(
                        0.1,
                        grupo.EspaciamientoMaximoCm));
        }
        else
        {
            pasoReferencia =
                cantidadOriginal > 1
                    ? longitudDistribucionOriginal /
                        (cantidadOriginal - 1)
                    : longitudDistribucionOriginal;
        }

        int cantidadFinal =
            cantidadOriginal -
            (ocultarInferior ? 1 : 0) -
            (ocultarSuperior ? 1 : 0);

        if (cantidadFinal < 2)
        {
            ocultarInferior = false;
            ocultarSuperior = false;
            cantidadFinal = cantidadOriginal;
        }

        double zBase =
            cadena.ZInferior +
            vMin *
            alturaCadena;

        if (ocultarInferior)
        {
            zBase +=
                pasoReferencia;
        }

        double longitudDistribucion =
            longitudDistribucionOriginal -
            (ocultarInferior
                ? pasoReferencia
                : 0.0) -
            (ocultarSuperior
                ? pasoReferencia
                : 0.0);

        if (longitudDistribucion <= Tol)
            return 0;

        double u =
            (grupo.InicioU +
             grupo.FinU) *
            0.5;

        // Trayectoria COMPLETA real del grupo, incluyendo:
        // - todos los muros de la cadena;
        // - curvas;
        // - puentes entre tramos;
        // - H inicio / H fin.
        List<Curve> trayectoriaCompleta =
            ConstruirTrayectoriaHorizontalManual2P(
                cadena,
                u,
                zBase,
                margenBase,
                conf);

        if (trayectoriaCompleta == null ||
            trayectoriaCompleta.Count == 0)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": no se pudo construir la trayectoria longitudinal completa.");

            return 0;
        }

        double longitudTotal =
            ObtenerLongitudTotalCurvas(
                trayectoriaCompleta);

        if (longitudTotal <= Tol)
            return 0;

        double longitudEmpalme =
            ObtenerLongitudEmpalmeGeometrica(
                tipoGrupo,
                conf);

        double diametro =
            ObtenerDiametroBarra(
                tipoGrupo);

        double longitudEjeComercial =
            CalcularLongitudEjeComercialMuro(
                longitudComercial,
                longitudEmpalme,
                diametro);

        List<List<Curve>> piezas =
            DividirTrayectoriaConEmpalmeComercial(
                trayectoriaCompleta,
                cadena,
                u,
                zBase,
                margenBase,
                conf,
                longitudEjeComercial,
                longitudEmpalme);

        double toleranciaLongitud =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        // Protección explícita para el caso que muestras:
        // si la ruta mide más de 9 m, DEBE existir más de una pieza.
        if (longitudTotal >
                longitudComercial +
                toleranciaLongitud &&
            (piezas == null ||
             piezas.Count < 2))
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": la trayectoria mide " +
                UnitUtils.ConvertFromInternalUnits(
                    longitudTotal,
                    UnitTypeId.Meters)
                    .ToString("0.###") +
                " m, supera L. comercial = " +
                (conf.LongitudComercialCm / 100.0)
                    .ToString("0.###") +
                " m, pero el divisor no generó al menos 2 piezas. " +
                "No se creó una barra continua incorrecta.");

            return 0;
        }

        if (piezas == null ||
            piezas.Count == 0)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": no se pudieron obtener las piezas comerciales.");

            return 0;
        }

        List<ElementId> idsLocales =
            new List<ElementId>();

        int creados =
            0;

        for (int p = 0;
             p < piezas.Count;
             p++)
        {
            bool tieneEmpalmeInicio =
                p > 0;

            List<Curve> boceto =
                ConstruirBocetoPiezaHorizontalManualConQuiebre(
                    cadena,
                    piezas[p],
                    u,
                    tieneEmpalmeInicio,
                    longitudEmpalme,
                    diametro);

            if (boceto == null ||
                boceto.Count == 0)
            {
                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": no se pudo construir el boceto comercial con quiebre.");

                return 0;
            }

            double longitudBoceto =
                ObtenerLongitudTotalCurvas(
                    boceto);

            if (longitudBoceto <= Tol ||
                longitudBoceto >
                    longitudComercial +
                    toleranciaLongitud)
            {
                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": el boceto mide " +
                    UnitUtils.ConvertFromInternalUnits(
                        longitudBoceto,
                        UnitTypeId.Meters)
                        .ToString("0.###") +
                    " m > L. comercial " +
                    (conf.LongitudComercialCm / 100.0)
                        .ToString("0.###") +
                    " m.");

                return 0;
            }

            if (tieneEmpalmeInicio &&
                !BocetoHorizontalTieneQuiebreGeometrico(
                    boceto))
            {
                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": el empalme quedó colineal antes de crear el Rebar.");

                return 0;
            }

            // =================================================
            // CADA PIEZA COMERCIAL ES UN SET SHAPE DRIVEN.
            //
            // Esto es lo importante que evita los dos errores
            // acumulados de versiones anteriores:
            // - barra completa > L. comercial;
            // - FreeForm interpretado como Número fijo.
            // =================================================
            Rebar rebar =
                CrearRebarDesdeCurvasNuevaFormaExacta(
                    doc,
                    host,
                    tipoGrupo,
                    XYZ.BasisZ,
                    boceto);

            if (rebar == null)
            {
                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": Revit no pudo crear la forma exacta. " +
                    "No se usó un FreeForm/Individual como respaldo.");

                return 0;
            }

            string detalleRegla =
                "";

            bool reglaOk =
                AplicarReglaGrupoHorizontalShapeDrivenExacta(
                    rebar,
                    grupo,
                    cantidadFinal,
                    longitudDistribucion,
                    out detalleRegla);

            if (!reglaOk)
            {
                try { doc.Delete(rebar.Id); } catch { }

                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": no se pudo aplicar la regla " +
                    (grupo.ReglaDistribucion ==
                        AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                            ? "Espaciado máximo"
                            : "Número fijo") +
                    ". " +
                    detalleRegla);

                return 0;
            }

            // Forzar actualización de forma/constraints antes de medir.
            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            if (tieneEmpalmeInicio &&
                !RebarTieneQuiebreVisible(
                    rebar))
            {
                try { doc.Delete(rebar.Id); } catch { }

                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": Revit eliminó/normalizó el quiebre. " +
                    "La pieza fue eliminada.");

                return 0;
            }

            double longitudReal;

            if (!ValidarLongitudComercialRealRebar(
                    rebar,
                    longitudComercial,
                    out longitudReal))
            {
                try { doc.Delete(rebar.Id); } catch { }

                foreach (ElementId id in idsLocales)
                {
                    try { doc.Delete(id); } catch { }
                    resultado.Ids.Remove(id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo H " +
                    indiceGrupo +
                    ", pieza " +
                    (p + 1) +
                    ": longitud REAL creada = " +
                    UnitUtils.ConvertFromInternalUnits(
                        longitudReal,
                        UnitTypeId.Meters)
                        .ToString("0.###") +
                    " m; L. comercial máxima = " +
                    (conf.LongitudComercialCm / 100.0)
                        .ToString("0.###") +
                    " m. La pieza fue eliminada.");

                return 0;
            }

            string reglaTexto =
                grupo.ReglaDistribucion ==
                    AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                        ? "Espaciado máximo " +
                            grupo.EspaciamientoMaximoCm.ToString("0.###") +
                            " cm"
                        : "Número fijo " +
                            cantidadFinal;

            string descripcion =
                "Acero horizontal 2P EMPALMADO - " +
                "Pieza " +
                (p + 1) +
                "/" +
                piezas.Count +
                " | Lmax " +
                (conf.LongitudComercialCm / 100.0)
                    .ToString("0.###") +
                " m | Lt " +
                UnitUtils.ConvertFromInternalUnits(
                    longitudEmpalme,
                    UnitTypeId.Centimeters)
                    .ToString("0.###") +
                " cm | Empalme en tercio central | " +
                reglaTexto +
                " | Cadena " +
                cadena.Numero +
                " | Grupo " +
                indiceGrupo;

            string marca =
                "MUR-HOR-2P-EMP-CAD-" +
                cadena.Numero +
                "-G" +
                indiceGrupo +
                "-P" +
                (p + 1);

            CompletarParametrosMYGMuro(
                rebar,
                host,
                descripcion,
                marca);

            resultado.Horizontales++;
            resultado.Ids.Add(rebar.Id);
            idsLocales.Add(rebar.Id);
            creados++;
        }

        // Si la ruta supera Lmax, el resultado final no puede ser una sola pieza.
        if (longitudTotal >
                longitudComercial +
                toleranciaLongitud &&
            creados < 2)
        {
            foreach (ElementId id in idsLocales)
            {
                try { doc.Delete(id); } catch { }
                resultado.Ids.Remove(id);
            }

            resultado.Horizontales =
                System.Math.Max(
                    0,
                    resultado.Horizontales -
                    creados);

            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": la ruta supera L. comercial, pero no quedaron al menos 2 piezas. " +
                "Se eliminó el resultado para no dejar una barra continua incorrecta.");

            return 0;
        }

        return creados;
    }



    private int ObtenerCantidadGrupoHorizontal2Puntos(
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo,
        CadenaMuros cadena)
    {
        if (grupo == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return 0;
        }

        if (grupo.ReglaDistribucion ==
            AceroMuroForm.AceroMuroReglaDistribucionGrupo.NumeroFijo)
        {
            return
                System.Math.Max(
                    2,
                    grupo.Cantidad);
        }

        double espesor =
            cadena.Tramos[0] != null &&
            cadena.Tramos[0].Datos != null
                ? cadena.Tramos[0].Datos.Espesor
                : 0.0;

        double altura =
            cadena.ZSuperior -
            cadena.ZInferior;

        if (espesor <= Tol ||
            altura <= Tol)
        {
            return 2;
        }

        double dx =
            (grupo.FinU -
             grupo.InicioU) *
            espesor;

        double dz =
            (grupo.FinV -
             grupo.InicioV) *
            altura;

        double longitud =
            System.Math.Sqrt(
                dx * dx +
                dz * dz);

        double espaciado =
            ConvertirCm(
                System.Math.Max(
                    0.1,
                    grupo.EspaciamientoMaximoCm));

        if (longitud <= Tol ||
            espaciado <= Tol)
        {
            return 2;
        }

        int intervalos =
            System.Math.Max(
                1,
                (int)System.Math.Ceiling(
                    longitud /
                    espaciado));

        return
            System.Math.Min(
                500,
                intervalos + 1);
    }


    private bool SonGruposHorizontalesColinealesEjecucion(
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos a,
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos b,
        CadenaMuros cadena)
    {
        if (a == null ||
            b == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return false;
        }

        double espesor =
            cadena.Tramos[0] != null &&
            cadena.Tramos[0].Datos != null
                ? cadena.Tramos[0].Datos.Espesor
                : 0.0;

        double altura =
            cadena.ZSuperior -
            cadena.ZInferior;

        if (espesor <= Tol ||
            altura <= Tol)
        {
            return false;
        }

        double ax =
            (a.FinU -
             a.InicioU) *
            espesor;

        double az =
            (a.FinV -
             a.InicioV) *
            altura;

        double bx =
            (b.FinU -
             b.InicioU) *
            espesor;

        double bz =
            (b.FinV -
             b.InicioV) *
            altura;

        double la =
            System.Math.Sqrt(
                ax * ax +
                az * az);

        double lb =
            System.Math.Sqrt(
                bx * bx +
                bz * bz);

        if (la <= Tol ||
            lb <= Tol)
        {
            return false;
        }

        double seno =
            System.Math.Abs(
                ax * bz -
                az * bx) /
            (la * lb);

        if (seno > 0.018)
            return false;

        // Distancia del inicio de B a la recta de A,
        // medida en el plano físico de la sección.
        double a0x =
            a.InicioU *
            espesor;

        double a0z =
            a.InicioV *
            altura;

        double a1x =
            a.FinU *
            espesor;

        double a1z =
            a.FinV *
            altura;

        double b0x =
            b.InicioU *
            espesor;

        double b0z =
            b.InicioV *
            altura;

        double vx =
            a1x -
            a0x;

        double vz =
            a1z -
            a0z;

        double len2 =
            vx * vx +
            vz * vz;

        if (len2 <= Tol * Tol)
            return false;

        double t =
            ((b0x - a0x) * vx +
             (b0z - a0z) * vz) /
            len2;

        double qx =
            a0x +
            t * vx;

        double qz =
            a0z +
            t * vz;

        double dx =
            b0x -
            qx;

        double dz =
            b0z -
            qz;

        double distancia =
            System.Math.Sqrt(
                dx * dx +
                dz * dz);

        return
            distancia <=
            ConvertirMm(2.0);
    }

    private void ObtenerPuntoGrupoHorizontalNormalizado(
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo,
        int indice,
        int cantidad,
        out double u,
        out double v)
    {
        u = 0.0;
        v = 0.0;

        if (grupo == null)
            return;

        double t =
            cantidad <= 1
                ? 0.0
                : (double)indice /
                    (cantidad - 1);

        u =
            grupo.InicioU +
            (grupo.FinU -
             grupo.InicioU) *
            t;

        v =
            grupo.InicioV +
            (grupo.FinV -
             grupo.InicioV) *
            t;
    }

    private bool DebeOmitirExtremoHorizontalDuplicadoEjecucion(
        AceroMuroForm.AceroMuroConfiguracion conf,
        CadenaMuros cadena,
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupoActual,
        int indiceGrupoActual,
        int indiceBarra,
        int cantidadActual)
    {
        if (conf == null ||
            conf.GruposHorizontales2Puntos == null ||
            cadena == null ||
            grupoActual == null ||
            cantidadActual < 2)
        {
            return false;
        }

        // Solo extremos del grupo creado DESPUÉS.
        if (indiceBarra != 0 &&
            indiceBarra != cantidadActual - 1)
        {
            return false;
        }

        if (indiceGrupoActual <= 0)
            return false;

        double espesor =
            cadena.Tramos[0] != null &&
            cadena.Tramos[0].Datos != null
                ? cadena.Tramos[0].Datos.Espesor
                : 0.0;

        double altura =
            cadena.ZSuperior -
            cadena.ZInferior;

        if (espesor <= Tol ||
            altura <= Tol)
        {
            return false;
        }

        double uActual;
        double vActual;

        ObtenerPuntoGrupoHorizontalNormalizado(
            grupoActual,
            indiceBarra,
            cantidadActual,
            out uActual,
            out vActual);

        double tolerancia =
            ConvertirMm(
                2.0);

        int limite =
            System.Math.Min(
                indiceGrupoActual,
                conf.GruposHorizontales2Puntos.Count);

        for (int g = 0;
             g < limite;
             g++)
        {
            AceroMuroForm.AceroMuroGrupoHorizontal2Puntos anterior =
                conf.GruposHorizontales2Puntos[g];

            if (anterior == null ||
                !SonGruposHorizontalesColinealesEjecucion(
                    anterior,
                    grupoActual,
                    cadena))
            {
                continue;
            }

            int cantidadAnterior =
                ObtenerCantidadGrupoHorizontal2Puntos(
                    anterior,
                    cadena);

            cantidadAnterior =
                System.Math.Max(
                    2,
                    cantidadAnterior);

            for (int i = 0;
                 i < cantidadAnterior;
                 i++)
            {
                double uAnterior;
                double vAnterior;

                ObtenerPuntoGrupoHorizontalNormalizado(
                    anterior,
                    i,
                    cantidadAnterior,
                    out uAnterior,
                    out vAnterior);

                double dx =
                    (uActual -
                     uAnterior) *
                    espesor;

                double dz =
                    (vActual -
                     vAnterior) *
                    altura;

                double distancia =
                    System.Math.Sqrt(
                        dx * dx +
                        dz * dz);

                if (distancia <=
                    tolerancia)
                {
                    return true;
                }
            }
        }

        return false;
    }



    private int CrearGrupoHorizontal2PSinEmpalmeShapeDriven(
        Document doc,
        CadenaMuros cadena,
        Element host,
        RebarBarType tipoGrupo,
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo,
        int indiceGrupo,
        int indiceGrupoCeroBased,
        double margenBase,
        double alturaCadena,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        // Retorno:
        // -1 = geometría no compatible con distribución Shape Driven;
        //  0 = compatible pero falló;
        // >0 = conjunto creado correctamente.
        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            host == null ||
            tipoGrupo == null ||
            grupo == null ||
            conf == null ||
            resultado == null)
        {
            return -1;
        }

        double espesor =
            cadena.Tramos[0] != null &&
            cadena.Tramos[0].Datos != null
                ? cadena.Tramos[0].Datos.Espesor
                : 0.0;

        if (espesor <= Tol ||
            alturaCadena <= Tol)
        {
            return -1;
        }

        // El conjunto Shape Driven se distribuye perpendicular al
        // plano de la barra base, que aquí corresponde al eje Z.
        // Por eso esta ruta aplica cuando H inicio/fin están sobre
        // la misma guía/cara (caso normal del editor).
        double deltaUReal =
            System.Math.Abs(
                grupo.FinU -
                grupo.InicioU) *
            espesor;

        double toleranciaU =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        if (deltaUReal >
            toleranciaU)
        {
            return -1;
        }

        double vMin =
            System.Math.Min(
                grupo.InicioV,
                grupo.FinV);

        double vMax =
            System.Math.Max(
                grupo.InicioV,
                grupo.FinV);

        double longitudDistribucionOriginal =
            (vMax -
             vMin) *
            alturaCadena;

        if (longitudDistribucionOriginal <= Tol)
            return -1;

        int cantidadOriginal =
            ObtenerCantidadGrupoHorizontal2Puntos(
                grupo,
                cadena);

        cantidadOriginal =
            System.Math.Max(
                2,
                cantidadOriginal);

        bool inicioEsInferior =
            grupo.InicioV <=
            grupo.FinV;

        bool ocultarIndice0 =
            DebeOmitirExtremoHorizontalDuplicadoEjecucion(
                conf,
                cadena,
                grupo,
                indiceGrupoCeroBased,
                0,
                cantidadOriginal);

        bool ocultarIndiceFinal =
            DebeOmitirExtremoHorizontalDuplicadoEjecucion(
                conf,
                cadena,
                grupo,
                indiceGrupoCeroBased,
                cantidadOriginal - 1,
                cantidadOriginal);

        bool ocultarInferior =
            inicioEsInferior
                ? ocultarIndice0
                : ocultarIndiceFinal;

        bool ocultarSuperior =
            inicioEsInferior
                ? ocultarIndiceFinal
                : ocultarIndice0;

        double pasoReferencia;

        if (grupo.ReglaDistribucion ==
            AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo)
        {
            // Para MaxSpacing el paso de referencia ES EL INPUT.
            pasoReferencia =
                ConvertirCm(
                    System.Math.Max(
                        0.1,
                        grupo.EspaciamientoMaximoCm));
        }
        else
        {
            pasoReferencia =
                cantidadOriginal > 1
                    ? longitudDistribucionOriginal /
                        (cantidadOriginal - 1)
                    : longitudDistribucionOriginal;
        }

        int cantidadFinal =
            cantidadOriginal -
            (ocultarInferior ? 1 : 0) -
            (ocultarSuperior ? 1 : 0);

        if (cantidadFinal < 2)
        {
            ocultarInferior =
                false;

            ocultarSuperior =
                false;

            cantidadFinal =
                cantidadOriginal;
        }

        double zBase =
            cadena.ZInferior +
            vMin *
            alturaCadena;

        if (ocultarInferior)
        {
            zBase +=
                pasoReferencia;
        }

        double longitudDistribucion =
            longitudDistribucionOriginal -
            (ocultarInferior
                ? pasoReferencia
                : 0.0) -
            (ocultarSuperior
                ? pasoReferencia
                : 0.0);

        if (longitudDistribucion <= Tol)
            return -1;

        double u =
            (grupo.InicioU +
             grupo.FinU) *
            0.5;

        List<Curve> bocetoBase =
            ConstruirTrayectoriaHorizontalManual2P(
                cadena,
                u,
                zBase,
                margenBase,
                conf);

        if (bocetoBase == null ||
            bocetoBase.Count == 0)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": no se pudo construir la barra base.");

            return 0;
        }

        // Reducir segmentos colineales, pero conservar Line+Arc reales.
        bocetoBase =
            ConsolidarCurvasHorizontalesColineales(
                bocetoBase);

        if (bocetoBase == null ||
            bocetoBase.Count == 0)
        {
            return -1;
        }

        Rebar rebar =
            CrearRebarDesdeCurvasNuevaFormaExacta(
                doc,
                host,
                tipoGrupo,
                XYZ.BasisZ,
                bocetoBase);

        if (rebar == null)
        {
            // Para un grupo estándar NO queremos degradarlo
            // silenciosamente a FreeForm/Número fijo.
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": Revit no pudo crear el conjunto Shape Driven. " +
                "No se cambió silenciosamente a Número fijo.");

            return 0;
        }

        string detalleRegla =
            "";

        bool reglaOk =
            AplicarReglaGrupoHorizontalShapeDrivenExacta(
                rebar,
                grupo,
                cantidadFinal,
                longitudDistribucion,
                out detalleRegla);

        if (!reglaOk)
        {
            try
            {
                doc.Delete(
                    rebar.Id);
            }
            catch
            {
            }

            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": no se pudo aplicar la regla '" +
                (grupo.ReglaDistribucion ==
                    AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                        ? "Espaciado máximo"
                        : "Número fijo") +
                "'. " +
                detalleRegla);

            return 0;
        }

        CompletarParametrosMYGMuro(
            rebar,
            host,
            "Acero horizontal LIBRE 2 PUNTOS - " +
                (grupo.ReglaDistribucion ==
                    AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                        ? "Espaciado máximo " +
                            grupo.EspaciamientoMaximoCm.ToString("0.###") +
                            " cm"
                        : "Número fijo " +
                            cantidadFinal) +
                " - Cadena " +
                cadena.Numero +
                " - Grupo " +
                indiceGrupo,
            "MUR-HOR-2P-CAD-" +
                cadena.Numero +
                "-G" +
                indiceGrupo);

        resultado.Horizontales++;

        resultado.Ids.Add(
            rebar.Id);

        return 1;
    }



    // =========================================================
    // V8.74 - HUECOS INTERNOS + FRANJA DE RECUBRIMIENTO
    //
    // Capa geométrica compartida H/V previa a la creación de armadura.
    // Además del vacío real, protege la franja:
    // RECUBRIMIENTO + Ø/2 alrededor del perímetro de la abertura.
    // Horizontales y verticales consultan el mismo sólido REAL del Wall.
    // No sustituye el motor de empalmes ni crea un segundo motor:
    // solamente recorta las trayectorias que atraviesan VACÍOS
    // REALES del sólido del Wall.
    //
    // Solid.IntersectWithCurve() devuelve los tramos que realmente
    // permanecen dentro del sólido. Cuando una curva atraviesa un
    // hueco interno aparecen dos o más intervalos sobre EL MISMO Wall.
    // =========================================================
    private sealed class HuecoPerfilMuroMYG
    {
        // Distancias medidas sobre el eje REAL del tramo.
        public double EstacionInicio;
        public double EstacionFin;

        public double ZInferior;
        public double ZSuperior;
    }


    private double ObtenerEstacionTramoDesdePunto(
        TramoCadena tramo,
        XYZ punto)
    {
        if (tramo == null ||
            tramo.Datos == null ||
            tramo.Datos.CurvaBase == null ||
            punto == null)
        {
            return 0.0;
        }

        Curve curva =
            tramo.Datos.CurvaBase;

        double longitud =
            ObtenerLongitudTramo(
                tramo);

        if (longitud <= Tol)
            return 0.0;

        try
        {
            IntersectionResult proyeccion =
                curva.Project(
                    punto);

            if (proyeccion == null)
                return 0.0;

            double p0 =
                curva.GetEndParameter(0);

            double p1 =
                curva.GetEndParameter(1);

            double dp =
                p1 - p0;

            if (System.Math.Abs(dp) <= Tol)
                return 0.0;

            double u =
                (proyeccion.Parameter -
                 p0) /
                dp;

            u =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        1.0,
                        u));

            if (TramoEstaInvertido(
                tramo))
            {
                u =
                    1.0 -
                    u;
            }

            return
                longitud *
                u;
        }
        catch
        {
            return 0.0;
        }
    }


    private List<Solid> ObtenerSolidosSoloBocetoMuro(
        Wall muro)
    {
        List<Solid> resultado =
            new List<Solid>();

        if (muro == null ||
            muro.Document == null)
        {
            return resultado;
        }

        // =====================================================
        // V8.79 - SOLO EL BOCETO DEL WALL
        //
        // Se accede a SketchId mediante reflexión para mantener
        // compatibilidad binaria con distintas revisiones de API.
        //
        // Si el Wall NO tiene boceto editable:
        // - no se devuelve ningún sólido;
        // - el llamador interpreta que NO hay recorte de boceto;
        // - por lo tanto se ignoran por completo los cortes del Solid.
        // =====================================================
        ElementId sketchId =
            ElementId.InvalidElementId;

        try
        {
            System.Reflection.PropertyInfo propiedadSketchId =
                muro
                    .GetType()
                    .GetProperty(
                        "SketchId");

            if (propiedadSketchId != null)
            {
                object valor =
                    propiedadSketchId.GetValue(
                        muro,
                        null);

                ElementId id =
                    valor as ElementId;

                if (id != null)
                {
                    sketchId =
                        id;
                }
            }
        }
        catch
        {
            sketchId =
                ElementId.InvalidElementId;
        }

        if (sketchId == null ||
            sketchId ==
                ElementId.InvalidElementId ||
            sketchId.Value < 0)
        {
            return resultado;
        }

        Autodesk.Revit.DB.Sketch sketch =
            null;

        try
        {
            sketch =
                muro.Document.GetElement(
                    sketchId)
                as Autodesk.Revit.DB.Sketch;
        }
        catch
        {
            sketch =
                null;
        }

        if (sketch == null ||
            sketch.SketchPlane == null)
        {
            return resultado;
        }

        CurveArrArray perfil =
            null;

        try
        {
            perfil =
                sketch.Profile;
        }
        catch
        {
            perfil =
                null;
        }

        if (perfil == null ||
            perfil.Size == 0)
        {
            return resultado;
        }

        Plane plano =
            null;

        try
        {
            plano =
                sketch.SketchPlane.GetPlane();
        }
        catch
        {
            plano =
                null;
        }

        if (plano == null ||
            plano.Normal == null ||
            plano.Normal.GetLength() <= Tol)
        {
            return resultado;
        }

        XYZ normal =
            plano.Normal.Normalize();

        // El SketchPlane puede encontrarse en la cara o en el eje.
        // Se extruye de forma generosa a ambos lados para cubrir
        // una o dos mallas sin depender de la posición exacta del plano.
        double anchoMuro =
            0.0;

        try
        {
            anchoMuro =
                muro.Width;
        }
        catch
        {
            anchoMuro =
                0.0;
        }

        if (anchoMuro <= Tol)
        {
            anchoMuro =
                UnitUtils.ConvertToInternalUnits(
                    20.0,
                    UnitTypeId.Centimeters);
        }

        double profundidadCadaLado =
            System.Math.Max(
                anchoMuro * 2.0,
                UnitUtils.ConvertToInternalUnits(
                    30.0,
                    UnitTypeId.Centimeters));

        double profundidadTotal =
            profundidadCadaLado * 2.0;

        Transform moverInicio =
            Transform.CreateTranslation(
                normal.Multiply(
                    -profundidadCadaLado));

        List<CurveLoop> loops =
            new List<CurveLoop>();

        try
        {
            foreach (
                CurveArray arreglo
                in perfil)
            {
                if (arreglo == null ||
                    arreglo.Size == 0)
                {
                    continue;
                }

                CurveLoop loop =
                    new CurveLoop();

                foreach (
                    Curve curvaPerfil
                    in arreglo)
                {
                    if (curvaPerfil == null ||
                        !curvaPerfil.IsBound ||
                        curvaPerfil.Length <= Tol)
                    {
                        continue;
                    }

                    Curve copia =
                        curvaPerfil.CreateTransformed(
                            moverInicio);

                    if (copia != null &&
                        copia.IsBound &&
                        copia.Length > Tol)
                    {
                        loop.Append(
                            copia);
                    }
                }

                if (loop != null &&
                    loop.Count() > 0)
                {
                    loops.Add(
                        loop);
                }
            }
        }
        catch
        {
            loops.Clear();
        }

        if (loops.Count == 0)
        {
            return resultado;
        }

        Solid solidoBoceto =
            null;

        try
        {
            // Se genera geometría temporal de análisis desde el perfil.
            // Este sólido NO proviene de la geometría final cortada del Wall.
            solidoBoceto =
                GeometryCreationUtilities
                    .CreateExtrusionGeometry(
                        loops,
                        normal,
                        profundidadTotal);
        }
        catch
        {
            solidoBoceto =
                null;
        }

        if (solidoBoceto != null)
        {
            try
            {
                if (solidoBoceto.Volume > Tol)
                {
                    resultado.Add(
                        solidoBoceto);
                }
            }
            catch
            {
                resultado.Add(
                    solidoBoceto);
            }
        }

        return resultado;
    }


    private List<HuecoPerfilMuroMYG> ObtenerHuecosInternosPerfilMuro(
        TramoCadena tramo)
    {
        List<HuecoPerfilMuroMYG> resultado =
            new List<HuecoPerfilMuroMYG>();

        if (tramo == null ||
            tramo.Datos == null ||
            tramo.Datos.Muro == null)
        {
            return resultado;
        }

        Wall muro =
            tramo.Datos.Muro;

        // V8.79:
        // Los refuerzos de hueco se disparan únicamente por huecos
        // pertenecientes al Sketch.Profile del Wall.
        List<Solid> solidos =
            ObtenerSolidosSoloBocetoMuro(
                muro);

        if (solidos == null ||
            solidos.Count == 0)
        {
            return resultado;
        }

        double longitud =
            ObtenerLongitudTramo(
                tramo);

        if (longitud <= Tol)
            return resultado;

        XYZ tangenteMedia =
            ObtenerTangenteTramoPorDistancia(
                tramo,
                longitud * 0.5);

        if (tangenteMedia != null &&
            tangenteMedia.GetLength() > Tol)
        {
            tangenteMedia =
                tangenteMedia.Normalize();
        }

        double minHueco =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        double tolBorde =
            UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters);

        // La misma abertura aparece normalmente en las dos caras
        // principales del muro. Se deduplica por sus 4 cotas.
        Dictionary<string, HuecoPerfilMuroMYG> unicos =
            new Dictionary<string, HuecoPerfilMuroMYG>();

        foreach (
            Solid solid
            in solidos)
        {
            if (solid == null)
                continue;

            foreach (
                Face face
                in solid.Faces)
            {
                if (face == null)
                    continue;

                // ------------------------------------------------
                // Solo caras laterales principales.
                // Se descartan:
                // - cara superior/inferior;
                // - testeros;
                // - caras verticales del propio hueco.
                // ------------------------------------------------
                XYZ normal =
                    null;

                try
                {
                    BoundingBoxUV bb =
                        face.GetBoundingBox();

                    if (bb == null)
                        continue;

                    UV uv =
                        new UV(
                            (bb.Min.U +
                             bb.Max.U) *
                            0.5,
                            (bb.Min.V +
                             bb.Max.V) *
                            0.5);

                    normal =
                        face.ComputeNormal(
                            uv);
                }
                catch
                {
                    normal =
                        null;
                }

                if (normal == null ||
                    normal.GetLength() <= Tol)
                {
                    continue;
                }

                normal =
                    normal.Normalize();

                if (System.Math.Abs(
                        normal.Z) >
                    0.35)
                {
                    continue;
                }

                if (tangenteMedia != null &&
                    tangenteMedia.GetLength() > Tol &&
                    System.Math.Abs(
                        normal.DotProduct(
                            tangenteMedia)) >
                    0.45)
                {
                    continue;
                }

                EdgeArrayArray loops;

                try
                {
                    loops =
                        face.EdgeLoops;
                }
                catch
                {
                    continue;
                }

                if (loops == null ||
                    loops.Size < 2)
                {
                    continue;
                }

                List<double[]> cajas =
                    new List<double[]>();

                foreach (
                    EdgeArray loop
                    in loops)
                {
                    if (loop == null ||
                        loop.Size == 0)
                    {
                        continue;
                    }

                    double sMin =
                        double.MaxValue;

                    double sMax =
                        double.MinValue;

                    double zMin =
                        double.MaxValue;

                    double zMax =
                        double.MinValue;

                    bool tienePuntos =
                        false;

                    foreach (
                        Edge edge
                        in loop)
                    {
                        if (edge == null)
                            continue;

                        IList<XYZ> puntos =
                            null;

                        try
                        {
                            puntos =
                                edge.Tessellate();
                        }
                        catch
                        {
                            puntos =
                                null;
                        }

                        if (puntos == null ||
                            puntos.Count == 0)
                        {
                            continue;
                        }

                        foreach (
                            XYZ p
                            in puntos)
                        {
                            if (p == null)
                                continue;

                            double s =
                                ObtenerEstacionTramoDesdePunto(
                                    tramo,
                                    p);

                            sMin =
                                System.Math.Min(
                                    sMin,
                                    s);

                            sMax =
                                System.Math.Max(
                                    sMax,
                                    s);

                            zMin =
                                System.Math.Min(
                                    zMin,
                                    p.Z);

                            zMax =
                                System.Math.Max(
                                    zMax,
                                    p.Z);

                            tienePuntos =
                                true;
                        }
                    }

                    if (!tienePuntos ||
                        sMax - sMin <= Tol ||
                        zMax - zMin <= Tol)
                    {
                        continue;
                    }

                    cajas.Add(
                        new double[]
                        {
                            sMin,
                            sMax,
                            zMin,
                            zMax
                        });
                }

                if (cajas.Count < 2)
                    continue;

                // El loop con mayor área proyectada es el perfil
                // exterior de esta cara. Los demás son huecos internos.
                int indiceExterior =
                    -1;

                double areaExterior =
                    double.MinValue;

                for (int i = 0;
                     i < cajas.Count;
                     i++)
                {
                    double area =
                        (cajas[i][1] -
                         cajas[i][0]) *
                        (cajas[i][3] -
                         cajas[i][2]);

                    if (area >
                        areaExterior)
                    {
                        areaExterior =
                            area;

                        indiceExterior =
                            i;
                    }
                }

                if (indiceExterior < 0)
                    continue;

                double[] exterior =
                    cajas[indiceExterior];

                for (int i = 0;
                     i < cajas.Count;
                     i++)
                {
                    if (i ==
                        indiceExterior)
                    {
                        continue;
                    }

                    double[] caja =
                        cajas[i];

                    double ancho =
                        caja[1] -
                        caja[0];

                    double alto =
                        caja[3] -
                        caja[2];

                    if (ancho <
                            minHueco ||
                        alto <
                            minHueco)
                    {
                        continue;
                    }

                    // Solo huecos realmente internos.
                    // Un notch que toca el borde exterior sigue siendo
                    // atendido por el recorte H/V, pero no se confunde
                    // con una abertura cerrada de cuatro lados.
                    if (caja[0] <=
                            exterior[0] +
                            tolBorde ||
                        caja[1] >=
                            exterior[1] -
                            tolBorde ||
                        caja[2] <=
                            exterior[2] +
                            tolBorde ||
                        caja[3] >=
                            exterior[3] -
                            tolBorde)
                    {
                        continue;
                    }

                    double s0 =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                longitud,
                                caja[0]));

                    double s1 =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                longitud,
                                caja[1]));

                    double z0 =
                        System.Math.Max(
                            tramo.Datos.ZInferior,
                            caja[2]);

                    double z1 =
                        System.Math.Min(
                            tramo.Datos.ZSuperior,
                            caja[3]);

                    if (s1 - s0 <
                            minHueco ||
                        z1 - z0 <
                            minHueco)
                    {
                        continue;
                    }

                    double s0Mm =
                        UnitUtils.ConvertFromInternalUnits(
                            s0,
                            UnitTypeId.Millimeters);

                    double s1Mm =
                        UnitUtils.ConvertFromInternalUnits(
                            s1,
                            UnitTypeId.Millimeters);

                    double z0Mm =
                        UnitUtils.ConvertFromInternalUnits(
                            z0,
                            UnitTypeId.Millimeters);

                    double z1Mm =
                        UnitUtils.ConvertFromInternalUnits(
                            z1,
                            UnitTypeId.Millimeters);

                    // Redondeo a 5 mm para deduplicar cara A / cara B.
                    string clave =
                        System.Math.Round(
                            s0Mm / 5.0)
                            .ToString() +
                        "|" +
                        System.Math.Round(
                            s1Mm / 5.0)
                            .ToString() +
                        "|" +
                        System.Math.Round(
                            z0Mm / 5.0)
                            .ToString() +
                        "|" +
                        System.Math.Round(
                            z1Mm / 5.0)
                            .ToString();

                    if (!unicos.ContainsKey(
                        clave))
                    {
                        unicos[
                            clave] =
                            new HuecoPerfilMuroMYG
                            {
                                EstacionInicio =
                                    s0,
                                EstacionFin =
                                    s1,
                                ZInferior =
                                    z0,
                                ZSuperior =
                                    z1
                            };
                    }
                }
            }
        }

        resultado =
            unicos.Values
                .OrderBy(
                    x =>
                        x.EstacionInicio)
                .ThenBy(
                    x =>
                        x.ZInferior)
                .ToList();

        return resultado;
    }


    private int CrearRefuerzoAutomaticoHuecosTramo(
        Document doc,
        TramoCadena tramo,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            tramo == null ||
            tramo.Datos == null ||
            tramo.Datos.Muro == null ||
            conf == null ||
            resultado == null ||
            !conf.CrearRefuerzoHuecos ||
            conf.TipoRefuerzoHuecos == null ||
            conf.LongitudRefuerzoHuecosCm <= 0.0)
        {
            return 0;
        }

        List<HuecoPerfilMuroMYG> huecos =
            ObtenerHuecosInternosPerfilMuro(
                tramo);

        if (huecos == null ||
            huecos.Count == 0)
        {
            return 0;
        }

        RebarBarType tipoRefuerzo =
            conf.TipoRefuerzoHuecos;

        double diametro =
            ObtenerDiametroBarra(
                tipoRefuerzo);

        if (diametro <= Tol)
            return 0;

        // Longitud TOTAL indicada directamente por el usuario.
        double longitudDiagonal =
            ConvertirCm(
                conf.LongitudRefuerzoHuecosCm);

        if (longitudDiagonal <= Tol)
            return 0;

        // =====================================================
        // CAPAS / CARAS
        //
        // La posición en el espesor sigue la misma malla H:
        //
        // UNA MALLA:
        //      1 capa -> 4 diagonales.
        //
        // DOBLE MALLA:
        //      cara A + cara B -> 8 diagonales.
        //
        // El DIÁMETRO ya NO depende del grupo H:
        // todas usan conf.TipoRefuerzoHuecos.
        // =====================================================
        List<Tuple<
            double,
            int>> capas =
                new List<Tuple<
                    double,
                    int>>();

        double toleranciaCapa =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        if (conf.GruposHorizontales2Puntos != null &&
            conf.GruposHorizontales2Puntos.Count > 0)
        {
            foreach (
                AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo
                in conf.GruposHorizontales2Puntos)
            {
                if (grupo == null)
                    continue;

                double u =
                    (grupo.InicioU +
                     grupo.FinU) *
                    0.5;

                int signo =
                    u > 0.55
                        ? 1
                        : u < 0.45
                            ? -1
                            : 0;

                double offsetCara =
                    ObtenerOffsetDesdeUSeccionManual(
                        tramo,
                        u);

                bool duplicada =
                    capas.Any(
                        x =>
                            x != null &&
                            System.Math.Abs(
                                x.Item1 -
                                offsetCara) <=
                                toleranciaCapa);

                if (!duplicada)
                {
                    capas.Add(
                        Tuple.Create(
                            offsetCara,
                            signo));
                }
            }
        }

        // Si todavía no hay grupos H explícitos, calcular directamente
        // las capas según UNA/DOBLE MALLA.
        if (capas.Count == 0)
        {
            double diametroV =
                conf.TipoVertical != null
                    ? ObtenerDiametroBarra(
                        conf.TipoVertical)
                    : 0.0;

            foreach (
                int signo
                in ObtenerSignosCaras(
                    conf.ModoCaras))
            {
                double ajusteCara =
                    ObtenerAjusteCaraPies(
                        conf,
                        signo);

                double offsetH;

                bool okH =
                    TryObtenerOffsetHorizontalDentroNucleo(
                        tramo,
                        signo,
                        ConvertirCm(
                            conf.RecubrimientoCm),
                        diametroV,
                        diametro,
                        ajusteCara,
                        conf.CrearVerticales,
                        out offsetH);

                if (!okH)
                    continue;

                bool duplicada =
                    capas.Any(
                        x =>
                            x != null &&
                            System.Math.Abs(
                                x.Item1 -
                                offsetH) <=
                                toleranciaCapa);

                if (!duplicada)
                {
                    capas.Add(
                        Tuple.Create(
                            offsetH,
                            signo));
                }
            }
        }

        if (capas.Count == 0)
            return 0;

        double recubrimiento =
            ConvertirCm(
                conf.RecubrimientoCm);

        double longitudTramo =
            ObtenerLongitudTramo(
                tramo);

        if (longitudTramo <= Tol)
            return 0;

        int total =
            0;

        Dictionary<long, List<Solid>> cacheSolidos =
            new Dictionary<long, List<Solid>>();

        int numeroHueco =
            0;

        foreach (
            HuecoPerfilMuroMYG hueco
            in huecos)
        {
            numeroHueco++;

            if (hueco == null)
                continue;

            int numeroCapa =
                0;

            foreach (
                Tuple<
                    double,
                    int> capa
                in capas)
            {
                numeroCapa++;

                if (capa == null)
                    continue;

                double offsetCara =
                    capa.Item1;

                // Distancia mínima del EJE de la diagonal a la esquina.
                double margenEsquina =
                    recubrimiento +
                    diametro * 0.5;

                double mitadDeseada =
                    longitudDiagonal *
                    0.5;

                // Límites físicos de la capa de acero dentro del muro.
                double sMin =
                    margenEsquina;

                double sMax =
                    longitudTramo -
                    margenEsquina;

                double zMin =
                    tramo.Datos.ZInferior +
                    margenEsquina;

                double zMax =
                    tramo.Datos.ZSuperior -
                    margenEsquina;

                if (sMax -
                        sMin <=
                        Tol ||
                    zMax -
                        zMin <=
                        Tol)
                {
                    continue;
                }

                double raiz2 =
                    System.Math.Sqrt(
                        2.0);

                double componenteMargen =
                    margenEsquina /
                    raiz2;

                double componenteDir =
                    1.0 /
                    raiz2;

                // =================================================
                // UNA SOLA DIAGONAL POR ESQUINA.
                //
                // 0 = SUP-IZQ   /
                // 1 = SUP-DER   \
                // 2 = INF-IZQ   \
                // 3 = INF-DER   /
                // =================================================
                for (int esquina = 0;
                     esquina < 4;
                     esquina++)
                {
                    bool izquierda =
                        esquina == 0 ||
                        esquina == 2;

                    bool superior =
                        esquina == 0 ||
                        esquina == 1;

                    int signoDirS =
                        1;

                    int signoDirZ =
                        (esquina == 0 ||
                         esquina == 3)
                            ? 1
                            : -1;

                    int signoNormalS =
                        izquierda
                            ? -1
                            : 1;

                    int signoNormalZ =
                        superior
                            ? 1
                            : -1;

                    double sEsquina =
                        izquierda
                            ? hueco.EstacionInicio
                            : hueco.EstacionFin;

                    double zEsquina =
                        superior
                            ? hueco.ZSuperior
                            : hueco.ZInferior;

                    double sCentro =
                        sEsquina +
                        signoNormalS *
                        componenteMargen;

                    double zCentro =
                        zEsquina +
                        signoNormalZ *
                        componenteMargen;

                    double vS =
                        signoDirS *
                        componenteDir;

                    double vZ =
                        signoDirZ *
                        componenteDir;

                    double disponiblePosS =
                        vS > 0.0
                            ? (sMax -
                               sCentro) /
                                vS
                            : (sCentro -
                               sMin) /
                                (-vS);

                    double disponiblePosZ =
                        vZ > 0.0
                            ? (zMax -
                               zCentro) /
                                vZ
                            : (zCentro -
                               zMin) /
                                (-vZ);

                    double largoPositivo =
                        System.Math.Min(
                            mitadDeseada,
                            System.Math.Min(
                                disponiblePosS,
                                disponiblePosZ));

                    double disponibleNegS =
                        vS > 0.0
                            ? (sCentro -
                               sMin) /
                                vS
                            : (sMax -
                               sCentro) /
                                (-vS);

                    double disponibleNegZ =
                        vZ > 0.0
                            ? (zCentro -
                               zMin) /
                                vZ
                            : (zMax -
                               zCentro) /
                                (-vZ);

                    double largoNegativo =
                        System.Math.Min(
                            mitadDeseada,
                            System.Math.Min(
                                disponibleNegS,
                                disponibleNegZ));

                    double minimoBrazo =
                        ConvertirCm(
                            10.0);

                    if (largoPositivo <
                            minimoBrazo ||
                        largoNegativo <
                            minimoBrazo)
                    {
                        continue;
                    }

                    double sA =
                        sCentro -
                        vS *
                        largoNegativo;

                    double zA =
                        zCentro -
                        vZ *
                        largoNegativo;

                    double sB =
                        sCentro +
                        vS *
                        largoPositivo;

                    double zB =
                        zCentro +
                        vZ *
                        largoPositivo;

                    sA =
                        System.Math.Max(
                            sMin,
                            System.Math.Min(
                                sMax,
                                sA));

                    sB =
                        System.Math.Max(
                            sMin,
                            System.Math.Min(
                                sMax,
                                sB));

                    zA =
                        System.Math.Max(
                            zMin,
                            System.Math.Min(
                                zMax,
                                zA));

                    zB =
                        System.Math.Max(
                            zMin,
                            System.Math.Min(
                                zMax,
                                zB));

                    XYZ ejeA =
                        ObtenerPuntoTramoPorDistancia(
                            tramo,
                            sA);

                    XYZ ejeB =
                        ObtenerPuntoTramoPorDistancia(
                            tramo,
                            sB);

                    XYZ tangenteA =
                        ObtenerTangenteTramoPorDistancia(
                            tramo,
                            sA);

                    XYZ tangenteB =
                        ObtenerTangenteTramoPorDistancia(
                            tramo,
                            sB);

                    if (ejeA == null ||
                        ejeB == null ||
                        tangenteA == null ||
                        tangenteB == null ||
                        tangenteA.GetLength() <= Tol ||
                        tangenteB.GetLength() <= Tol)
                    {
                        continue;
                    }

                    tangenteA =
                        tangenteA.Normalize();

                    tangenteB =
                        tangenteB.Normalize();

                    XYZ normalA =
                        new XYZ(
                            -tangenteA.Y,
                            tangenteA.X,
                            0.0);

                    XYZ normalB =
                        new XYZ(
                            -tangenteB.Y,
                            tangenteB.X,
                            0.0);

                    if (normalA.GetLength() <= Tol ||
                        normalB.GetLength() <= Tol)
                    {
                        continue;
                    }

                    normalA =
                        normalA.Normalize();

                    normalB =
                        normalB.Normalize();

                    XYZ pA =
                        ejeA +
                        normalA.Multiply(
                            offsetCara);

                    XYZ pB =
                        ejeB +
                        normalB.Multiply(
                            offsetCara);

                    pA =
                        new XYZ(
                            pA.X,
                            pA.Y,
                            zA);

                    pB =
                        new XYZ(
                            pB.X,
                            pB.Y,
                            zB);

                    if (pA.DistanceTo(
                            pB) <=
                        Tol)
                    {
                        continue;
                    }

                    Curve diagonal;

                    try
                    {
                        diagonal =
                            Line.CreateBound(
                                pA,
                                pB);
                    }
                    catch
                    {
                        continue;
                    }

                    // Toda la diagonal debe permanecer en concreto.
                    List<double[]> intervalosDentro =
                        ObtenerIntervalosCurvaDentroMuro(
                            diagonal,
                            tramo.Datos.Muro,
                            cacheSolidos);

                    double toleranciaSolido =
                        UnitUtils.ConvertToInternalUnits(
                            5.0,
                            UnitTypeId.Millimeters);

                    bool completamenteDentro =
                        intervalosDentro != null &&
                        intervalosDentro.Any(
                            x =>
                                x != null &&
                                x.Length >= 2 &&
                                x[0] <=
                                    toleranciaSolido &&
                                x[1] >=
                                    diagonal.Length -
                                    toleranciaSolido);

                    if (!completamenteDentro)
                        continue;

                    double sMedio =
                        (sA +
                         sB) *
                        0.5;

                    XYZ tangenteMedia =
                        ObtenerTangenteTramoPorDistancia(
                            tramo,
                            sMedio);

                    if (tangenteMedia == null ||
                        tangenteMedia.GetLength() <= Tol)
                    {
                        continue;
                    }

                    tangenteMedia =
                        tangenteMedia.Normalize();

                    XYZ normalPlano =
                        new XYZ(
                            -tangenteMedia.Y,
                            tangenteMedia.X,
                            0.0);

                    if (normalPlano.GetLength() <= Tol)
                        continue;

                    normalPlano =
                        normalPlano.Normalize();

                    Rebar rebar =
                        CrearRebarDesdeCurvas(
                            doc,
                            tramo.Datos.Muro,
                            tipoRefuerzo,
                            normalPlano,
                            new List<Curve>
                            {
                                diagonal
                            });

                    if (rebar == null)
                        continue;

                    string nombreEsquina =
                        esquina == 0
                            ? "SUP-IZQ"
                            : esquina == 1
                                ? "SUP-DER"
                                : esquina == 2
                                    ? "INF-IZQ"
                                    : "INF-DER";

                    CompletarParametrosMYGMuro(
                        rebar,
                        tramo.Datos.Muro,
                        "Refuerzo HORIZONTAL diagonal automático de hueco - " +
                            nombreEsquina +
                            " - Ø CONFIGURABLE",
                        "MUR-HUECO-HOR-DIAG-" +
                            numeroHueco +
                            "-C" +
                            numeroCapa +
                            "-" +
                            nombreEsquina);

                    resultado.Horizontales++;
                    resultado.Ids.Add(
                        rebar.Id);

                    total++;
                }
            }
        }

        return total;
    }


    private sealed class FilaHorizontalConHuecos
    {
        public double Z;
        public double U;
        public bool HuboHueco;

        public List<List<Curve>> Cadenas =
            new List<List<Curve>>();
    }


    private double ObtenerDistanciaSobreCurva(
        Curve curva,
        XYZ punto)
    {
        if (curva == null ||
            punto == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return 0.0;
        }

        try
        {
            IntersectionResult proyeccion =
                curva.Project(
                    punto);

            if (proyeccion == null)
                return 0.0;

            double p0 =
                curva.GetEndParameter(0);

            double p1 =
                curva.GetEndParameter(1);

            double dp =
                p1 - p0;

            if (System.Math.Abs(dp) <= Tol)
                return 0.0;

            double t =
                (proyeccion.Parameter - p0) /
                dp;

            t =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        1.0,
                        t));

            return
                curva.Length *
                t;
        }
        catch
        {
            return 0.0;
        }
    }


    private List<double[]> ObtenerIntervalosCurvaDentroMuro(
        Curve curva,
        Wall muro,
        Dictionary<long, List<Solid>> cacheSolidos)
    {
        List<double[]> intervalos =
            new List<double[]>();

        if (curva == null ||
            muro == null ||
            cacheSolidos == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return intervalos;
        }

        long id =
            muro.Id.Value;

        List<Solid> solidos;

        if (!cacheSolidos.TryGetValue(
                id,
                out solidos))
        {
            // V8.79:
            // El cache guarda exclusivamente la extrusión de Sketch.Profile.
            solidos =
                ObtenerSolidosSoloBocetoMuro(
                    muro);

            cacheSolidos[id] =
                solidos ??
                new List<Solid>();
        }

        if (solidos == null ||
            solidos.Count == 0)
        {
            // Sin Sketch/Profile editable no hay una modificación DE BOCETO
            // que deba recortar la armadura.
            //
            // La trayectoria se conserva completa aunque el Wall tenga
            // cortes posteriores realizados por otras herramientas.
            intervalos.Add(
                new double[]
                {
                    0.0,
                    curva.Length
                });

            return intervalos;
        }

        using (
            SolidCurveIntersectionOptions opciones =
                new SolidCurveIntersectionOptions())
        {
            foreach (
                Solid solid
                in solidos)
            {
                if (solid == null)
                    continue;

                try
                {
                    if (solid.Volume <= Tol)
                        continue;
                }
                catch
                {
                }

                SolidCurveIntersection inter =
                    null;

                try
                {
                    inter =
                        solid.IntersectWithCurve(
                            curva,
                            opciones);

                    if (inter == null ||
                        inter.SegmentCount == 0)
                    {
                        continue;
                    }

                    for (int i = 0;
                         i < inter.SegmentCount;
                         i++)
                    {
                        Curve segmento =
                            inter.GetCurveSegment(
                                i);

                        if (segmento == null ||
                            !segmento.IsBound ||
                            segmento.Length <= Tol)
                        {
                            continue;
                        }

                        double d0 =
                            ObtenerDistanciaSobreCurva(
                                curva,
                                segmento.GetEndPoint(0));

                        double d1 =
                            ObtenerDistanciaSobreCurva(
                                curva,
                                segmento.GetEndPoint(1));

                        double a =
                            System.Math.Min(
                                d0,
                                d1);

                        double b =
                            System.Math.Max(
                                d0,
                                d1);

                        if (b - a > Tol)
                        {
                            intervalos.Add(
                                new double[]
                                {
                                    a,
                                    b
                                });
                        }
                    }
                }
                catch
                {
                }
                finally
                {
                    if (inter != null)
                        inter.Dispose();
                }
            }
        }

        if (intervalos.Count <= 1)
            return intervalos;

        intervalos =
            intervalos
                .OrderBy(x => x[0])
                .ThenBy(x => x[1])
                .ToList();

        double toleranciaUnion =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        List<double[]> unidos =
            new List<double[]>();

        foreach (
            double[] intervalo
            in intervalos)
        {
            if (intervalo == null ||
                intervalo.Length < 2)
            {
                continue;
            }

            if (unidos.Count == 0)
            {
                unidos.Add(
                    new double[]
                    {
                        intervalo[0],
                        intervalo[1]
                    });

                continue;
            }

            double[] ultimo =
                unidos[unidos.Count - 1];

            if (intervalo[0] <=
                ultimo[1] +
                toleranciaUnion)
            {
                ultimo[1] =
                    System.Math.Max(
                        ultimo[1],
                        intervalo[1]);
            }
            else
            {
                unidos.Add(
                    new double[]
                    {
                        intervalo[0],
                        intervalo[1]
                    });
            }
        }

        return unidos;
    }



    private List<Curve> RecortarCurvaVerticalPorHuecosInternosMuro(
        Curve curva,
        Wall muro,
        double zMuroInferior,
        double zMuroSuperior,
        double margenHueco,
        Dictionary<long, List<Solid>> cacheSolidos,
        out bool huboHueco)
    {
        huboHueco =
            false;

        List<Curve> resultado =
            new List<Curve>();

        if (curva == null ||
            muro == null ||
            cacheSolidos == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return resultado;
        }

        XYZ p0 =
            curva.GetEndPoint(0);

        XYZ p1 =
            curva.GetEndPoint(1);

        double dz =
            p1.Z -
            p0.Z;

        if (System.Math.Abs(dz) <= Tol)
        {
            resultado.Add(
                curva);

            return resultado;
        }

        double longitud =
            curva.Length;

        // -----------------------------------------------------
        // Intervalo de la propia barra que corresponde al rango
        // vertical FÍSICO del anfitrión.
        // -----------------------------------------------------
        double tZ0 =
            (zMuroInferior -
             p0.Z) /
            dz;

        double tZ1 =
            (zMuroSuperior -
             p0.Z) /
            dz;

        double dZ0 =
            longitud *
            tZ0;

        double dZ1 =
            longitud *
            tZ1;

        double esperado0 =
            System.Math.Max(
                0.0,
                System.Math.Min(
                    longitud,
                    System.Math.Min(
                        dZ0,
                        dZ1)));

        double esperado1 =
            System.Math.Max(
                0.0,
                System.Math.Min(
                    longitud,
                    System.Math.Max(
                        dZ0,
                        dZ1)));

        // Si el grupo manual está completamente fuera del rango Z
        // físico del muro, no interpretar eso como hueco.
        if (esperado1 -
                esperado0 <=
            Tol)
        {
            resultado.Add(
                curva);

            return resultado;
        }

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        // =====================================================
        // V8.79 - RECUBRIMIENTO 2D ALREDEDOR DEL HUECO DE BOCETO
        //
        // Primero leemos la región de Sketch.Profile atravesada por
        // la curva. No se consulta el sólido final cortado del Wall.
        // Luego hacemos dos sondas paralelas a +/- margenHueco en
        // la dirección longitudinal local del Wall.
        //
        // Si cualquiera de esas sondas entra en el vacío, la barra
        // real está dentro de la franja de recubrimiento del hueco.
        // =====================================================
        List<double[]> intervalosEfectivos =
            ObtenerIntervalosCurvaDentroMuro(
                curva,
                muro,
                cacheSolidos);

        double margen =
            System.Math.Max(
                0.0,
                margenHueco);

        double margenSonda =
            System.Math.Max(
                0.0,
                margen -
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters));

        if (margenSonda > tolerancia)
        {
            XYZ tangenteLocal =
                null;

            try
            {
                LocationCurve ubicacion =
                    muro.Location as LocationCurve;

                Curve eje =
                    ubicacion != null
                        ? ubicacion.Curve
                        : null;

                if (eje != null &&
                    eje.IsBound &&
                    eje.Length > Tol)
                {
                    XYZ centro =
                        (p0 + p1) *
                        0.5;

                    IntersectionResult proyeccion =
                        eje.Project(
                            centro);

                    Transform derivadas =
                        proyeccion != null
                            ? eje.ComputeDerivatives(
                                proyeccion.Parameter,
                                false)
                            : eje.ComputeDerivatives(
                                0.5,
                                true);

                    if (derivadas != null &&
                        derivadas.BasisX != null)
                    {
                        XYZ t =
                            new XYZ(
                                derivadas.BasisX.X,
                                derivadas.BasisX.Y,
                                0.0);

                        if (t.GetLength() > Tol)
                        {
                            tangenteLocal =
                                t.Normalize();
                        }
                    }
                }
            }
            catch
            {
                tangenteLocal =
                    null;
            }

            if (tangenteLocal != null &&
                tangenteLocal.GetLength() > Tol)
            {
                for (int signo = -1;
                     signo <= 1;
                     signo += 2)
                {
                    XYZ desplazamiento =
                        tangenteLocal.Multiply(
                            margenSonda *
                            signo);

                    Curve sonda =
                        null;

                    try
                    {
                        sonda =
                            Line.CreateBound(
                                p0 + desplazamiento,
                                p1 + desplazamiento);
                    }
                    catch
                    {
                        sonda =
                            null;
                    }

                    if (sonda == null)
                        continue;

                    List<double[]> intervalosSonda =
                        ObtenerIntervalosCurvaDentroMuro(
                            sonda,
                            muro,
                            cacheSolidos);

                    // La sonda a distancia menor que el margen debe
                    // permanecer dentro del concreto exterior del Wall.
                    // Si no encuentra concreto, se considera zona inválida.
                    if (intervalosSonda == null ||
                        intervalosSonda.Count == 0)
                    {
                        intervalosEfectivos.Clear();
                        break;
                    }

                    List<double[]> interseccion =
                        new List<double[]>();

                    foreach (
                        double[] a
                        in intervalosEfectivos)
                    {
                        if (a == null ||
                            a.Length < 2)
                        {
                            continue;
                        }

                        foreach (
                            double[] b
                            in intervalosSonda)
                        {
                            if (b == null ||
                                b.Length < 2)
                            {
                                continue;
                            }

                            double inicio =
                                System.Math.Max(
                                    a[0],
                                    b[0]);

                            double fin =
                                System.Math.Min(
                                    a[1],
                                    b[1]);

                            if (fin - inicio >
                                tolerancia)
                            {
                                interseccion.Add(
                                    new double[]
                                    {
                                        inicio,
                                        fin
                                    });
                            }
                        }
                    }

                    intervalosEfectivos =
                        interseccion
                            .OrderBy(x => x[0])
                            .ThenBy(x => x[1])
                            .ToList();

                    if (intervalosEfectivos.Count == 0)
                        break;

                    // Unir pequeños contactos numéricos.
                    List<double[]> unidos =
                        new List<double[]>();

                    foreach (
                        double[] intervalo
                        in intervalosEfectivos)
                    {
                        if (intervalo == null ||
                            intervalo.Length < 2)
                        {
                            continue;
                        }

                        if (unidos.Count == 0)
                        {
                            unidos.Add(
                                new double[]
                                {
                                    intervalo[0],
                                    intervalo[1]
                                });

                            continue;
                        }

                        double[] ultimo =
                            unidos[
                                unidos.Count - 1];

                        if (intervalo[0] <=
                            ultimo[1] +
                            tolerancia)
                        {
                            ultimo[1] =
                                System.Math.Max(
                                    ultimo[1],
                                    intervalo[1]);
                        }
                        else
                        {
                            unidos.Add(
                                new double[]
                                {
                                    intervalo[0],
                                    intervalo[1]
                                });
                        }
                    }

                    intervalosEfectivos =
                        unidos;
                }
            }
        }

        List<double[]> utiles =
            new List<double[]>();

        if (intervalosEfectivos != null)
        {
            foreach (
                double[] intervalo
                in intervalosEfectivos)
            {
                if (intervalo == null ||
                    intervalo.Length < 2)
                {
                    continue;
                }

                double a =
                    System.Math.Max(
                        esperado0,
                        intervalo[0]);

                double b =
                    System.Math.Min(
                        esperado1,
                        intervalo[1]);

                if (b - a >
                    tolerancia)
                {
                    utiles.Add(
                        new double[]
                        {
                            a,
                            b
                        });
                }
            }
        }

        // La barra no invade ningún hueco NI la franja lateral de cover.
        bool cubreTodo =
            utiles.Count == 1 &&
            utiles[0][0] <=
                esperado0 +
                tolerancia &&
            utiles[0][1] >=
                esperado1 -
                tolerancia;

        if (cubreTodo)
        {
            resultado.Add(
                curva);

            return resultado;
        }

        huboHueco =
            true;

        // Si no hay concreto suficiente en la posición de esa barra,
        // se omite por completo.
        if (utiles.Count == 0)
            return resultado;

        for (int i = 0;
             i < utiles.Count;
             i++)
        {
            double inicio =
                utiles[i][0];

            double fin =
                utiles[i][1];

            bool tocaLimiteInicial =
                inicio <=
                esperado0 +
                tolerancia;

            bool tocaLimiteFinal =
                fin >=
                esperado1 -
                tolerancia;

            // -------------------------------------------------
            // MARGEN EN DIRECCIÓN DE LA BARRA:
            // además de las sondas laterales anteriores, el centro
            // de la barra también queda a:
            // recubrimiento + Ø/2
            // de la cara horizontal del hueco.
            // -------------------------------------------------
            if (!tocaLimiteInicial)
            {
                inicio +=
                    margen;
            }
            else
            {
                // Conservar una extensión manual fuera del anfitrión.
                inicio =
                    0.0;
            }

            if (!tocaLimiteFinal)
            {
                fin -=
                    margen;
            }
            else
            {
                // Conservar una extensión manual fuera del anfitrión.
                fin =
                    longitud;
            }

            inicio =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        longitud,
                        inicio));

            fin =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        longitud,
                        fin));

            if (fin - inicio <=
                tolerancia)
            {
                continue;
            }

            Curve sub =
                ExtraerSubCurvaPorDistancia(
                    curva,
                    inicio,
                    fin);

            if (sub != null &&
                sub.IsBound &&
                sub.Length > Tol)
            {
                resultado.Add(
                    sub);
            }
        }

        return resultado;
    }


    private bool SonPatronesVerticalesConHuecosEquivalentes(
        IList<Curve> a,
        IList<Curve> b)
    {
        if (a == null ||
            b == null ||
            a.Count != b.Count)
        {
            return false;
        }

        if (a.Count == 0)
            return true;

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        for (int i = 0;
             i < a.Count;
             i++)
        {
            Curve ca =
                a[i];

            Curve cb =
                b[i];

            if (ca == null ||
                cb == null)
            {
                if (ca != cb)
                    return false;

                continue;
            }

            if (System.Math.Abs(
                    ca.Length -
                    cb.Length) >
                tolerancia)
            {
                return false;
            }

            XYZ a0 =
                ca.GetEndPoint(0);

            XYZ a1 =
                ca.GetEndPoint(1);

            XYZ b0 =
                cb.GetEndPoint(0);

            XYZ b1 =
                cb.GetEndPoint(1);

            // Las barras de un mismo run se trasladan a lo largo
            // del muro. Para decidir si comparten forma basta comparar
            // sus cotas Z y longitudes.
            if (System.Math.Abs(
                    a0.Z -
                    b0.Z) >
                    tolerancia ||
                System.Math.Abs(
                    a1.Z -
                    b1.Z) >
                    tolerancia)
            {
                return false;
            }
        }

        return true;
    }


    private List<Curve> RecortarCurvaPorHuecosInternosMuro(
        Curve curva,
        Wall muro,
        double margenHueco,
        Dictionary<long, List<Solid>> cacheSolidos,
        out bool huboHueco)
    {
        huboHueco =
            false;

        List<Curve> resultado =
            new List<Curve>();

        if (curva == null ||
            muro == null ||
            cacheSolidos == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return resultado;
        }

        double longitud =
            curva.Length;

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        double toleranciaHueco =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Millimeters);

        double margen =
            System.Math.Max(
                0.0,
                margenHueco);

        // =====================================================
        // V8.79 - RECUBRIMIENTO 2D ALREDEDOR DEL HUECO DE BOCETO
        //
        // Solo cuentan huecos/perfiles existentes en Sketch.Profile.
        // Los cortes geométricos externos se ignoran.
        //
        // La V8.72 ya retraía el extremo horizontal:
        // recubrimiento + Ø/2
        // respecto a los COSTADOS del hueco.
        //
        // Faltaba evitar que una FILA H situada justo debajo/arriba
        // de una abertura quedara dentro de la franja de cover.
        //
        // Para eso se intersectan:
        // - la curva real;
        // - una sonda Z + margen;
        // - una sonda Z - margen.
        //
        // Si una de las sondas entra al vacío, esa parte deja de ser
        // válida para el centro del acero horizontal.
        // =====================================================
        List<double[]> intervalosEfectivos =
            ObtenerIntervalosCurvaDentroMuro(
                curva,
                muro,
                cacheSolidos);

        double margenSonda =
            System.Math.Max(
                0.0,
                margen -
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters));

        if (margenSonda > tolerancia)
        {
            for (int signo = -1;
                 signo <= 1;
                 signo += 2)
            {
                Curve sonda =
                    null;

                try
                {
                    Transform mover =
                        Transform.CreateTranslation(
                            new XYZ(
                                0.0,
                                0.0,
                                margenSonda *
                                signo));

                    sonda =
                        curva.CreateTransformed(
                            mover);
                }
                catch
                {
                    sonda =
                        null;
                }

                if (sonda == null)
                    continue;

                List<double[]> intervalosSonda =
                    ObtenerIntervalosCurvaDentroMuro(
                        sonda,
                        muro,
                        cacheSolidos);

                if (intervalosSonda == null ||
                    intervalosSonda.Count == 0)
                {
                    intervalosEfectivos.Clear();
                    break;
                }

                List<double[]> interseccion =
                    new List<double[]>();

                foreach (
                    double[] a
                    in intervalosEfectivos)
                {
                    if (a == null ||
                        a.Length < 2)
                    {
                        continue;
                    }

                    foreach (
                        double[] b
                        in intervalosSonda)
                    {
                        if (b == null ||
                            b.Length < 2)
                        {
                            continue;
                        }

                        double inicio =
                            System.Math.Max(
                                a[0],
                                b[0]);

                        double fin =
                            System.Math.Min(
                                a[1],
                                b[1]);

                        if (fin - inicio >
                            tolerancia)
                        {
                            interseccion.Add(
                                new double[]
                                {
                                    inicio,
                                    fin
                                });
                        }
                    }
                }

                intervalosEfectivos =
                    interseccion
                        .OrderBy(x => x[0])
                        .ThenBy(x => x[1])
                        .ToList();

                if (intervalosEfectivos.Count == 0)
                    break;

                List<double[]> unidos =
                    new List<double[]>();

                foreach (
                    double[] intervalo
                    in intervalosEfectivos)
                {
                    if (intervalo == null ||
                        intervalo.Length < 2)
                    {
                        continue;
                    }

                    if (unidos.Count == 0)
                    {
                        unidos.Add(
                            new double[]
                            {
                                intervalo[0],
                                intervalo[1]
                            });

                        continue;
                    }

                    double[] ultimo =
                        unidos[
                            unidos.Count - 1];

                    if (intervalo[0] <=
                        ultimo[1] +
                        tolerancia)
                    {
                        ultimo[1] =
                            System.Math.Max(
                                ultimo[1],
                                intervalo[1]);
                    }
                    else
                    {
                        unidos.Add(
                            new double[]
                            {
                                intervalo[0],
                                intervalo[1]
                            });
                    }
                }

                intervalosEfectivos =
                    unidos;
            }
        }

        if (intervalosEfectivos == null ||
            intervalosEfectivos.Count == 0)
        {
            // En este Wall no queda una franja de concreto suficientemente
            // ancha para alojar el centro de esta barra.
            //
            // No se considera automáticamente un hueco si la curva es un
            // puente entre dos muros: RecortarBoceto... seguirá probando
            // los otros Wall. Para un tramo perteneciente a este muro sí
            // terminará siendo recortado por la evaluación correspondiente.
            return resultado;
        }

        bool existeSeparacionReal =
            false;

        for (int i = 0;
             i < intervalosEfectivos.Count - 1;
             i++)
        {
            double hueco =
                intervalosEfectivos[i + 1][0] -
                intervalosEfectivos[i][1];

            if (hueco >
                toleranciaHueco)
            {
                existeSeparacionReal =
                    true;

                break;
            }
        }

        // Si las sondas no generaron separación, esta curva no cruza
        // una abertura interior en esta cota.
        if (!existeSeparacionReal)
        {
            resultado.Add(
                curva);

            return resultado;
        }

        huboHueco =
            true;

        // El primer/último extremo exterior se conserva para no perder
        // H-INICIO / H-FIN. Únicamente los extremos que miran al hueco
        // se retraen el margen del centro de barra.
        for (int i = 0;
             i < intervalosEfectivos.Count;
             i++)
        {
            double inicio =
                i == 0
                    ? 0.0
                    : intervalosEfectivos[i][0] +
                        margen;

            double fin =
                i ==
                    intervalosEfectivos.Count - 1
                    ? longitud
                    : intervalosEfectivos[i][1] -
                        margen;

            inicio =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        longitud,
                        inicio));

            fin =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        longitud,
                        fin));

            if (fin - inicio <=
                toleranciaHueco)
            {
                continue;
            }

            Curve sub =
                ExtraerSubCurvaPorDistancia(
                    curva,
                    inicio,
                    fin);

            if (sub != null &&
                sub.IsBound &&
                sub.Length > Tol)
            {
                resultado.Add(
                    sub);
            }
        }

        return resultado;
    }


    private List<List<Curve>> RecortarBocetoHorizontalPorHuecosInternos(
        IList<Curve> boceto,
        CadenaMuros cadena,
        double margenHueco,
        Dictionary<long, List<Solid>> cacheSolidos,
        out bool huboHueco)
    {
        huboHueco =
            false;

        List<List<Curve>> cadenasResultado =
            new List<List<Curve>>();

        if (boceto == null ||
            boceto.Count == 0 ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return cadenasResultado;
        }

        List<Curve> actual =
            new List<Curve>();

        foreach (
            Curve curva
            in boceto)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            List<Curve> partesElegidas =
                null;

            bool curvaCortada =
                false;

            // Una curva de un puente entre muros puede tocar dos sólidos,
            // pero ningún Wall individual tendrá DOS intervalos separados.
            // Por eso la evaluación se hace muro por muro.
            foreach (
                TramoCadena tramo
                in cadena.Tramos)
            {
                if (tramo == null ||
                    tramo.Datos == null ||
                    tramo.Datos.Muro == null)
                {
                    continue;
                }

                bool cortadaEnEsteMuro;

                List<Curve> partes =
                    RecortarCurvaPorHuecosInternosMuro(
                        curva,
                        tramo.Datos.Muro,
                        margenHueco,
                        cacheSolidos,
                        out cortadaEnEsteMuro);

                if (!cortadaEnEsteMuro)
                    continue;

                curvaCortada =
                    true;

                partesElegidas =
                    partes;

                break;
            }

            if (!curvaCortada)
            {
                actual.Add(
                    curva);

                continue;
            }

            huboHueco =
                true;

            if (partesElegidas == null ||
                partesElegidas.Count == 0)
            {
                if (actual.Count > 0)
                {
                    cadenasResultado.Add(
                        actual);

                    actual =
                        new List<Curve>();
                }

                continue;
            }

            for (int i = 0;
                 i < partesElegidas.Count;
                 i++)
            {
                Curve parte =
                    partesElegidas[i];

                if (parte == null ||
                    parte.Length <= Tol)
                {
                    continue;
                }

                actual.Add(
                    parte);

                // La separación entre dos partes es el hueco.
                if (i <
                    partesElegidas.Count - 1)
                {
                    cadenasResultado.Add(
                        actual);

                    actual =
                        new List<Curve>();
                }
            }
        }

        if (actual.Count > 0)
        {
            cadenasResultado.Add(
                actual);
        }

        return cadenasResultado;
    }


    private bool SonPatronesHorizontalesConHuecosEquivalentes(
        FilaHorizontalConHuecos a,
        FilaHorizontalConHuecos b)
    {
        if (a == null ||
            b == null ||
            a.Cadenas == null ||
            b.Cadenas == null ||
            a.Cadenas.Count !=
                b.Cadenas.Count)
        {
            return false;
        }

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        for (int i = 0;
             i < a.Cadenas.Count;
             i++)
        {
            List<Curve> ca =
                a.Cadenas[i];

            List<Curve> cb =
                b.Cadenas[i];

            if (ca == null ||
                cb == null ||
                ca.Count == 0 ||
                cb.Count == 0)
            {
                if ((ca == null || ca.Count == 0) !=
                    (cb == null || cb.Count == 0))
                {
                    return false;
                }

                continue;
            }

            if (ca.Count != cb.Count)
                return false;

            double la =
                ObtenerLongitudTotalCurvas(
                    ca);

            double lb =
                ObtenerLongitudTotalCurvas(
                    cb);

            if (System.Math.Abs(
                    la - lb) >
                tolerancia)
            {
                return false;
            }

            XYZ a0 =
                ca[0].GetEndPoint(0);

            XYZ a1 =
                ca[ca.Count - 1]
                    .GetEndPoint(1);

            XYZ b0 =
                cb[0].GetEndPoint(0);

            XYZ b1 =
                cb[cb.Count - 1]
                    .GetEndPoint(1);

            double inicioXY =
                System.Math.Sqrt(
                    (a0.X - b0.X) *
                    (a0.X - b0.X) +
                    (a0.Y - b0.Y) *
                    (a0.Y - b0.Y));

            double finXY =
                System.Math.Sqrt(
                    (a1.X - b1.X) *
                    (a1.X - b1.X) +
                    (a1.Y - b1.Y) *
                    (a1.Y - b1.Y));

            if (inicioXY > tolerancia ||
                finXY > tolerancia)
            {
                return false;
            }
        }

        return true;
    }


    private int CrearGrupoHorizontal2PRespetandoHuecosInternos(
        Document doc,
        CadenaMuros cadena,
        Element host,
        RebarBarType tipoGrupo,
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo,
        int indiceGrupo,
        int indiceGrupoCeroBased,
        int cantidadReferencia,
        double margenBase,
        double alturaCadena,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        // Retorno:
        // -1 = no se detectó ningún hueco interno: usar motor normal.
        // >=0 = el grupo fue gestionado aquí.
        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            host == null ||
            tipoGrupo == null ||
            grupo == null ||
            conf == null ||
            resultado == null ||
            alturaCadena <= Tol)
        {
            return -1;
        }

        Dictionary<long, List<Solid>> cacheSolidos =
            new Dictionary<long, List<Solid>>();

        double espesor =
            cadena.Tramos[0] != null &&
            cadena.Tramos[0].Datos != null
                ? cadena.Tramos[0].Datos.Espesor
                : 0.0;

        if (espesor <= Tol)
            return -1;

        double deltaUReal =
            System.Math.Abs(
                grupo.FinU -
                grupo.InicioU) *
            espesor;

        double toleranciaGuia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        bool grupoVerticalEnSeccion =
            deltaUReal <=
            toleranciaGuia;

        List<double> ts =
            new List<double>();

        if (grupoVerticalEnSeccion)
        {
            double vMin =
                System.Math.Min(
                    grupo.InicioV,
                    grupo.FinV);

            double vMax =
                System.Math.Max(
                    grupo.InicioV,
                    grupo.FinV);

            double longitudZ =
                (vMax - vMin) *
                alturaCadena;

            if (longitudZ <= Tol)
                return -1;

            if (grupo.ReglaDistribucion ==
                AceroMuroForm.AceroMuroReglaDistribucionGrupo.NumeroFijo)
            {
                int n =
                    System.Math.Max(
                        2,
                        grupo.Cantidad);

                for (int i = 0;
                     i < n;
                     i++)
                {
                    double v =
                        vMin +
                        (vMax - vMin) *
                        ((double)i /
                         (n - 1));

                    double t =
                        System.Math.Abs(
                            grupo.FinV -
                            grupo.InicioV) <= Tol
                                ? 0.0
                                : (v -
                                   grupo.InicioV) /
                                  (grupo.FinV -
                                   grupo.InicioV);

                    ts.Add(
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                1.0,
                                t)));
                }
            }
            else
            {
                double espaciado =
                    ConvertirCm(
                        System.Math.Max(
                            0.1,
                            grupo.EspaciamientoMaximoCm));

                int intervalos =
                    System.Math.Max(
                        1,
                        (int)System.Math.Floor(
                            (longitudZ + Tol) /
                            espaciado));

                int n =
                    intervalos + 1;

                double signoV =
                    grupo.FinV >=
                    grupo.InicioV
                        ? 1.0
                        : -1.0;

                for (int i = 0;
                     i < n;
                     i++)
                {
                    double distanciaZ =
                        i *
                        espaciado;

                    double t =
                        longitudZ <= Tol
                            ? 0.0
                            : distanciaZ /
                                longitudZ;

                    t =
                        System.Math.Max(
                            0.0,
                            System.Math.Min(
                                1.0,
                                t));

                    // t siempre recorre Inicio -> Fin.
                    ts.Add(t);
                }
            }
        }
        else
        {
            int n =
                System.Math.Max(
                    2,
                    cantidadReferencia);

            for (int i = 0;
                 i < n;
                 i++)
            {
                ts.Add(
                    (double)i /
                    (n - 1));
            }
        }

        if (ts.Count == 0)
            return -1;

        double longitudComercial =
            conf.ConsiderarEmpalmeHorizontal
                ? ConvertirCm(
                    conf.LongitudComercialCm)
                : 0.0;

        double longitudEmpalme =
            conf.ConsiderarEmpalmeHorizontal
                ? ObtenerLongitudEmpalmeGeometrica(
                    tipoGrupo,
                    conf)
                : 0.0;

        double diametro =
            ObtenerDiametroBarra(
                tipoGrupo);

        double longitudEjeComercial =
            conf.ConsiderarEmpalmeHorizontal
                ? CalcularLongitudEjeComercialMuro(
                    longitudComercial,
                    longitudEmpalme,
                    diametro)
                : 0.0;

        List<FilaHorizontalConHuecos> filas =
            new List<FilaHorizontalConHuecos>();

        bool huboHuecoGlobal =
            false;

        for (int i = 0;
             i < ts.Count;
             i++)
        {
            if (DebeOmitirExtremoHorizontalDuplicadoEjecucion(
                    conf,
                    cadena,
                    grupo,
                    indiceGrupoCeroBased,
                    i,
                    ts.Count))
            {
                continue;
            }

            double t =
                ts[i];

            double u =
                grupo.InicioU +
                (grupo.FinU -
                 grupo.InicioU) *
                t;

            double v =
                grupo.InicioV +
                (grupo.FinV -
                 grupo.InicioV) *
                t;

            double elevacion =
                cadena.ZInferior +
                v *
                alturaCadena;

            List<Curve> trayectoria =
                ConstruirTrayectoriaHorizontalManual2P(
                    cadena,
                    u,
                    elevacion,
                    margenBase,
                    conf);

            if (trayectoria == null ||
                trayectoria.Count == 0)
            {
                continue;
            }

            List<List<Curve>> bocetosAntesHueco =
                new List<List<Curve>>();

            if (conf.ConsiderarEmpalmeHorizontal)
            {
                if (longitudComercial <= Tol ||
                    longitudEmpalme <= Tol ||
                    longitudEjeComercial <= Tol)
                {
                    resultado.Errores.Add(
                        "Cadena " +
                        cadena.Numero +
                        ", grupo H " +
                        indiceGrupo +
                        ": configuración comercial/empalme inválida para resolver huecos internos.");

                    return 0;
                }

                List<List<Curve>> piezas =
                    DividirTrayectoriaConEmpalmeComercial(
                        trayectoria,
                        cadena,
                        u,
                        elevacion,
                        margenBase,
                        conf,
                        longitudEjeComercial,
                        longitudEmpalme);

                if (piezas == null ||
                    piezas.Count == 0)
                {
                    return 0;
                }

                for (int p = 0;
                     p < piezas.Count;
                     p++)
                {
                    List<Curve> boceto =
                        ConstruirBocetoPiezaHorizontalManualConQuiebre(
                            cadena,
                            piezas[p],
                            u,
                            p > 0,
                            longitudEmpalme,
                            diametro);

                    if (boceto == null ||
                        boceto.Count == 0)
                    {
                        continue;
                    }

                    bocetosAntesHueco.Add(
                        boceto);
                }
            }
            else
            {
                bocetosAntesHueco.Add(
                    trayectoria);
            }

            FilaHorizontalConHuecos fila =
                new FilaHorizontalConHuecos
                {
                    Z = elevacion,
                    U = u
                };

            foreach (
                List<Curve> boceto
                in bocetosAntesHueco)
            {
                bool huboHuecoBoceto;

                List<List<Curve>> cadenasRecortadas =
                    RecortarBocetoHorizontalPorHuecosInternos(
                        boceto,
                        cadena,
                        margenBase,
                        cacheSolidos,
                        out huboHuecoBoceto);

                if (huboHuecoBoceto)
                {
                    fila.HuboHueco =
                        true;

                    huboHuecoGlobal =
                        true;
                }

                if (cadenasRecortadas == null)
                    continue;

                foreach (
                    List<Curve> cadenaRecortada
                    in cadenasRecortadas)
                {
                    if (cadenaRecortada == null ||
                        cadenaRecortada.Count == 0)
                    {
                        continue;
                    }

                    fila.Cadenas.Add(
                        cadenaRecortada);
                }
            }

            filas.Add(
                fila);
        }

        // Ninguna barra del grupo cruza un hueco: NO tocar el motor
        // normal para conservar exactamente el comportamiento previo.
        if (!huboHuecoGlobal)
            return -1;

        if (filas.Count == 0)
            return 0;

        // Ordenar de abajo hacia arriba para poder reconstruir sets
        // Shape Driven en las franjas donde la geometría es idéntica.
        filas =
            filas
                .OrderBy(x => x.Z)
                .ToList();

        int creados =
            0;

        int inicioRun =
            0;

        while (inicioRun <
               filas.Count)
        {
            int finRun =
                inicioRun;

            while (finRun + 1 <
                   filas.Count &&
                   SonPatronesHorizontalesConHuecosEquivalentes(
                       filas[inicioRun],
                       filas[finRun + 1]))
            {
                finRun++;
            }

            FilaHorizontalConHuecos baseFila =
                filas[inicioRun];

            int cantidadRun =
                finRun -
                inicioRun +
                1;

            double longitudDistribucion =
                cantidadRun <= 1
                    ? 0.0
                    : filas[finRun].Z -
                        filas[inicioRun].Z;

            if (baseFila.Cadenas != null)
            {
                for (int c = 0;
                     c < baseFila.Cadenas.Count;
                     c++)
                {
                    List<Curve> bocetoBase =
                        baseFila.Cadenas[c];

                    if (bocetoBase == null ||
                        bocetoBase.Count == 0)
                    {
                        continue;
                    }

                    Rebar rebar =
                        CrearRebarDesdeCurvasNuevaFormaExacta(
                            doc,
                            host,
                            tipoGrupo,
                            XYZ.BasisZ,
                            bocetoBase);

                    if (rebar == null)
                    {
                        resultado.Errores.Add(
                            "Cadena " +
                            cadena.Numero +
                            ", grupo H " +
                            indiceGrupo +
                            ": Revit no pudo crear un tramo horizontal recortado por hueco.");

                        continue;
                    }

                    bool reglaOk =
                        true;

                    string detalle =
                        "";

                    if (cantidadRun <= 1 ||
                        longitudDistribucion <= Tol)
                    {
                        try
                        {
                            RebarShapeDrivenAccessor accessor =
                                rebar.GetShapeDrivenAccessor();

                            if (accessor != null)
                                accessor.SetLayoutAsSingle();
                        }
                        catch
                        {
                        }
                    }
                    else
                    {
                        reglaOk =
                            AplicarReglaGrupoHorizontalShapeDrivenExacta(
                                rebar,
                                grupo,
                                cantidadRun,
                                longitudDistribucion,
                                out detalle);
                    }

                    if (!reglaOk)
                    {
                        try
                        {
                            doc.Delete(
                                rebar.Id);
                        }
                        catch
                        {
                        }

                        resultado.Errores.Add(
                            "Cadena " +
                            cadena.Numero +
                            ", grupo H " +
                            indiceGrupo +
                            ": se recortó por hueco, pero Revit no conservó la regla del grupo. " +
                            detalle);

                        continue;
                    }

                    CompletarParametrosMYGMuro(
                        rebar,
                        host,
                        "Acero horizontal recortado por HUECO INTERNO - " +
                            (grupo.ReglaDistribucion ==
                                AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                                    ? "Espaciado máximo " +
                                        grupo.EspaciamientoMaximoCm.ToString("0.###") +
                                        " cm"
                                    : "Número fijo") +
                            (conf.ConsiderarEmpalmeHorizontal
                                ? " - empalme comercial activo"
                                : "") +
                            " - Cadena " +
                            cadena.Numero +
                            " - Grupo " +
                            indiceGrupo,
                        "MUR-HOR-HUECO-CAD-" +
                            cadena.Numero +
                            "-G" +
                            indiceGrupo +
                            "-R" +
                            (inicioRun + 1) +
                            "-C" +
                            (c + 1));

                    resultado.Horizontales++;
                    resultado.Ids.Add(
                        rebar.Id);

                    creados++;
                }
            }

            inicioRun =
                finRun + 1;
        }

        if (creados == 0)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ", grupo H " +
                indiceGrupo +
                ": se detectó un hueco interno, pero no quedó ningún tramo de acero horizontal válido.");
        }

        return creados;
    }


    private int CrearHorizontalesDesdeGruposDosPuntos(
        Document doc,
        CadenaMuros cadena,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            conf == null ||
            conf.GruposHorizontales2Puntos == null ||
            conf.GruposHorizontales2Puntos.Count == 0)
        {
            return 0;
        }

        Element host =
            cadena.Tramos[0]
                .Datos.Muro;

        double recubrimiento =
            ConvertirCm(
                conf.RecubrimientoCm);

        double alturaCadena =
            cadena.ZSuperior -
            cadena.ZInferior;

        if (alturaCadena <= Tol)
            return 0;

        int total =
            0;

        int indiceGrupo =
            0;

        foreach (
            AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo
            in conf.GruposHorizontales2Puntos)
        {
            int indiceGrupoCeroBased =
                indiceGrupo;

            indiceGrupo++;

            if (grupo == null)
                continue;

            RebarBarType tipoGrupo =
                ResolverTipoBarraGrupo(
                    doc,
                    grupo.TipoBarraId,
                    grupo.TipoBarraNombre,
                    conf.TipoHorizontal);

            if (tipoGrupo == null)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo horizontal " +
                    indiceGrupo +
                    ": no se encontró el tipo/diámetro de barra configurado.");

                continue;
            }

            double diametro =
                ObtenerDiametroBarra(
                    tipoGrupo);

            double margenBase =
                recubrimiento +
                diametro * 0.5;

            int cantidad =
                ObtenerCantidadGrupoHorizontal2Puntos(
                    grupo,
                    cadena);

            // =================================================
            // V8.72 - HUECOS INTERNOS DEL BOCETO / SÓLIDO DEL MURO
            //
            // Si alguna fila del grupo atraviesa un vacío interno real,
            // se recorta y se reconstruyen sets por franjas verticales.
            // Si NO existe hueco, retorna -1 y el flujo anterior queda
            // completamente intacto.
            // =================================================
            int creadosConHuecos =
                CrearGrupoHorizontal2PRespetandoHuecosInternos(
                    doc,
                    cadena,
                    host,
                    tipoGrupo,
                    grupo,
                    indiceGrupo,
                    indiceGrupoCeroBased,
                    cantidad,
                    margenBase,
                    alturaCadena,
                    conf,
                    resultado);

            if (creadosConHuecos >= 0)
            {
                total +=
                    creadosConHuecos;

                continue;
            }

            // =================================================
            // EMPALMES ACTIVADOS
            //
            // En las versiones anteriores los grupos H creados
            // desde la sección entraban directamente a un único
            // CreateFreeForm y SALTABAN por completo el método de
            // empalmes. V8.60 restaura el comportamiento:
            //
            // - respeta la longitud comercial del input;
            // - el corte se mide a lo largo de TODA la trayectoria;
            // - las piezas se traslapan;
            // - cada pieza posterior tiene quiebre REAL de 1Ø;
            // - cada empalme se reubica al TERCIO CENTRAL de un tramo;
            // - nunca se supera L. comercial para conseguir esa reubicación.
            // =================================================
            if (conf.ConsiderarEmpalmeHorizontal)
            {
                // =================================================
                // V8.66 - UN SOLO MOTOR DE EMPALMES PARA H 2P.
                // No hay legacy + fallback + FreeForm en cascada.
                // =================================================
                int creadosEmpalme =
                    CrearGrupoHorizontalManualConEmpalmesPorLongitudComercial(
                        doc,
                        cadena,
                        host,
                        tipoGrupo,
                        grupo,
                        indiceGrupo,
                        indiceGrupoCeroBased,
                        cantidad,
                        margenBase,
                        alturaCadena,
                        conf,
                        resultado);

                total +=
                    creadosEmpalme;

                continue;
            }

            // =================================================
            // SIN EMPALME - PRIMER INTENTO V8.65:
            //
            // Crear Shape Driven para que Revit conserve realmente
            // la regla del grupo. Esto evita el problema observado:
            //
            // UI:    Espaciado máximo = 10 cm
            // Revit: Número fijo = 52
            //
            // que ocurría porque CreateFreeForm recibía 52 trayectorias
            // físicas y Revit las interpretaba como un conjunto fijo.
            // =================================================
            int creadoShapeDriven =
                CrearGrupoHorizontal2PSinEmpalmeShapeDriven(
                    doc,
                    cadena,
                    host,
                    tipoGrupo,
                    grupo,
                    indiceGrupo,
                    indiceGrupoCeroBased,
                    margenBase,
                    alturaCadena,
                    conf,
                    resultado);

            if (creadoShapeDriven >= 0)
            {
                total +=
                    creadoShapeDriven;

                continue;
            }

            // =================================================
            // FALLBACK SOLO PARA GEOMETRÍA OBLICUA/NO SHAPE-DRIVEN.
            // =================================================
            IList<IList<Curve>> curvasPorBarra =
                new List<IList<Curve>>();

            for (int i = 0;
                 i < cantidad;
                 i++)
            {
                if (DebeOmitirExtremoHorizontalDuplicadoEjecucion(
                        conf,
                        cadena,
                        grupo,
                        indiceGrupoCeroBased,
                        i,
                        cantidad))
                {
                    continue;
                }

                double t =
                    cantidad <= 1
                        ? 0.0
                        : (double)i /
                            (cantidad - 1);

                double u =
                    grupo.InicioU +
                    (grupo.FinU -
                     grupo.InicioU) *
                    t;

                double v =
                    grupo.InicioV +
                    (grupo.FinV -
                     grupo.InicioV) *
                    t;

                double elevacion =
                    cadena.ZInferior +
                    v *
                    alturaCadena;

                List<Curve> trayectoria =
                    ConstruirTrayectoriaHorizontalManual2P(
                        cadena,
                        u,
                        elevacion,
                        margenBase,
                        conf);

                if (trayectoria == null ||
                    trayectoria.Count == 0)
                {
                    continue;
                }

                curvasPorBarra.Add(
                    trayectoria);
            }

            if (curvasPorBarra.Count == 0)
                continue;

            Rebar rebar =
                null;

            string error =
                "";

            try
            {
                using (
                    RebarFreeFormCreationResult r =
                        Rebar.CreateFreeForm(
                            doc,
                            tipoGrupo,
                            host,
                            curvasPorBarra,
                            RebarStyle.Standard))
                {
                    if (r == null)
                    {
                        error =
                            "CreateFreeForm devolvió null.";
                    }
                    else if (r.Error !=
                        RebarFreeFormValidationResult.Success)
                    {
                        error =
                            r.Error.ToString();
                    }
                    else
                    {
                        rebar =
                            r.Rebar;
                    }
                }
            }
            catch (Exception ex)
            {
                error =
                    ex.Message;
            }

            if (rebar == null)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", grupo 2 puntos " +
                    indiceGrupo +
                    ": Revit no pudo crear el Free Form. " +
                    error);

                continue;
            }

            CompletarParametrosMYGMuro(
                rebar,
                host,
                "Acero horizontal LIBRE 2 PUNTOS - " +
                    (grupo.ReglaDistribucion ==
                        AceroMuroForm.AceroMuroReglaDistribucionGrupo.EspaciadoMaximo
                            ? "Espaciado máximo "
                            : "Número fijo ") +
                    "- Cadena " +
                    cadena.Numero +
                    " - Grupo " +
                    indiceGrupo,
                "MUR-HOR-2P-CAD-" +
                    cadena.Numero +
                    "-G" +
                    indiceGrupo);

            resultado.Horizontales++;

            resultado.Ids.Add(
                rebar.Id);

            total++;
        }

        return total;
    }


    private void CrearHorizontalesCadena(
        Document doc,
        CadenaMuros cadena,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            conf == null ||
            conf.TipoHorizontal == null)
        {
            return;
        }

        // =====================================================
        // DISEÑO LIBRE DESDE LA SECCIÓN - DISTRIBUIR 2 PUNTOS
        //
        // Si existen grupos manuales, estos reemplazan la malla
        // horizontal automática. La ejecución usa exactamente U/V
        // definidos en el editor, igual que el editor de vigas.
        // =====================================================
        if (conf.GruposHorizontales2Puntos != null &&
            conf.GruposHorizontales2Puntos.Count > 0)
        {
            int creadosManuales =
                CrearHorizontalesDesdeGruposDosPuntos(
                    doc,
                    cadena,
                    conf,
                    resultado);

            if (creadosManuales == 0)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ": no se pudo crear ningún grupo horizontal definido con 2 puntos.");
            }

            return;
        }

        // V8.43:
        // SIN GRUPOS 2 PUNTOS NO SE CREA NINGÚN HORIZONTAL.
        // Esto permite que Cara A y Cara B tengan diseños totalmente
        // independientes. El checkbox solo habilita la disciplina H;
        // la geometría la define exclusivamente el editor de sección.
        return;

        double diametro =
            ObtenerDiametroBarra(
                conf.TipoHorizontal);

        double recubrimiento =
            ConvertirCm(
                conf.RecubrimientoCm);

        double margenBase =
            recubrimiento +
            diametro * 0.5;

        double espaciamiento =
            ConvertirCm(
                conf.EspaciamientoHorizontalCm);

        double zonaGanchoInferior =
            ObtenerZonaGanchoHorizontal(
                conf,
                false);

        double zonaGanchoSuperior =
            ObtenerZonaGanchoHorizontal(
                conf,
                true);

        double zInferior =
            cadena.ZInferior +
            margenBase +
            zonaGanchoInferior;

        double zSuperior =
            cadena.ZSuperior -
            margenBase -
            zonaGanchoSuperior;

        double longitudDistribucion =
            zSuperior -
            zInferior;

        if (longitudDistribucion <= Tol)
        {
            resultado.Errores.Add(
                "Cadena " +
                cadena.Numero +
                ": no hay altura suficiente para el acero horizontal después de ajustar los extremos al centro REAL de curvatura de los ganchos verticales.");

            return;
        }

        bool contieneCurvos =
            cadena.Tramos.Any(
                x =>
                    x != null &&
                    x.Datos != null &&
                    x.Datos.EsCurvo);

        List<int> caras =
            ObtenerSignosCaras(
                conf.ModoCaras);

        foreach (int signo in caras)
        {
            Element host =
                cadena.Tramos[0]
                    .Datos.Muro;

            // =====================================================
            // EMPALMES + LONGITUD COMERCIAL
            //
            // Cuando está activo, cada Line/Arc se divide en piezas
            // comerciales con traslape. Se crean por tramos para
            // conservar:
            // - radio real;
            // - anfitrión correcto;
            // - ESPACIADO MÁXIMO nativo.
            // =====================================================
            if (conf.ConsiderarEmpalmeHorizontal)
            {
                int creadosEmpalme =
                    CrearHorizontalesCadenaMixtaPorTramos(
                        doc,
                        cadena,
                        signo,
                        margenBase,
                        zInferior,
                        longitudDistribucion,
                        espaciamiento,
                        conf,
                        resultado);

                if (creadosEmpalme > 0)
                {
                    continue;
                }

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ": no se pudo crear el acero horizontal con empalmes.");

                continue;
            }

            // =====================================================
            // CADENA CON ARC:
            // FREE FORM OBLIGATORIO
            //
            // No hacemos primero CreateFromCurves porque Revit
            // convertiría Line + Arc + Line en una RebarShape y el
            // arco de radio grande puede terminar tratado como un
            // doblado normal de la forma.
            // =====================================================
            if (contieneCurvos)
            {
                string errorFreeForm =
                    "";

                Rebar rebarFreeForm =
                    CrearHorizontalesFreeFormCadenaCurva(
                        doc,
                        cadena,
                        signo,
                        margenBase,
                        zInferior,
                        zSuperior,
                        espaciamiento,
                        conf,
                        resultado,
                        out errorFreeForm);

                if (rebarFreeForm != null)
                {
                    string caraTextoHorizontal =
                        signo == 0
                            ? "Una malla centrada"
                            : signo > 0
                                ? "Cara A"
                                : "Cara B";

                    CompletarParametrosMYGMuro(
                        rebarFreeForm,
                        host,
                        "Acero horizontal FREE FORM de alma de muro - " +
                            caraTextoHorizontal +
                            " - Cadena " +
                            cadena.Numero,
                        "MUR-FF-HOR-CAD-" +
                            cadena.Numero +
                            "-" +
                            (signo == 0
                                ? "CENTRO"
                                : signo > 0
                                    ? "A"
                                    : "B"));

                    resultado.Horizontales++;

                    resultado.Ids.Add(
                        rebarFreeForm.Id);

                    continue;
                }

                // -------------------------------------------------
                // RESPALDO:
                // si Free Form no es aceptado por Revit para esa
                // geometría concreta, crear por tramos separados.
                // Esto es preferible a volver a crear una única
                // RebarShape con radio incorrecto.
                // -------------------------------------------------
                int creadosFallback =
                    CrearHorizontalesCadenaMixtaPorTramos(
                        doc,
                        cadena,
                        signo,
                        margenBase,
                        zInferior,
                        longitudDistribucion,
                        espaciamiento,
                        conf,
                        resultado);

                if (creadosFallback > 0)
                {
                    continue;
                }

                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ": no se pudo crear el horizontal Free Form. " +
                    errorFreeForm);

                continue;
            }

            // =====================================================
            // CADENA TOTALMENTE RECTA:
            // conservar el flujo Shape Driven existente.
            // =====================================================
            List<Curve> curvas =
                ConstruirCurvasHorizontales(
                    cadena,
                    signo,
                    margenBase,
                    zInferior,
                    conf,
                    resultado);

            if (curvas == null ||
                curvas.Count == 0)
            {
                continue;
            }

            List<Curve> curvasIntento =
                ConsolidarCurvasHorizontalesColineales(
                    curvas);

            Rebar rebar =
                CrearRebarDesdeCurvas(
                    doc,
                    host,
                    conf.TipoHorizontal,
                    XYZ.BasisZ,
                    curvasIntento);

            if (rebar == null)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ": no se pudo crear el acero horizontal recto.");

                continue;
            }

            AplicarDistribucionMaxima(
                rebar,
                espaciamiento,
                longitudDistribucion);

            string caraTexto =
                signo == 0
                    ? "Una malla centrada"
                    : signo > 0
                        ? "Cara A"
                        : "Cara B";

            CompletarParametrosMYGMuro(
                rebar,
                host,
                "Acero horizontal de alma de muro - " +
                    caraTexto +
                    " - Cadena " +
                    cadena.Numero,
                "MUR-ALMA-HOR-CAD-" +
                    cadena.Numero +
                    "-" +
                    (signo == 0
                        ? "CENTRO"
                        : signo > 0
                            ? "A"
                            : "B"));

            resultado.Horizontales++;

            resultado.Ids.Add(
                rebar.Id);
        }
    }

    private Rebar CrearHorizontalesFreeFormCadenaCurva(
        Document doc,
        CadenaMuros cadena,
        int signo,
        double margenBase,
        double zInferior,
        double zSuperior,
        double espaciamientoMaximo,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado,
        out string error)
    {
        error =
            "";

        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            conf == null ||
            conf.TipoHorizontal == null)
        {
            error =
                "Datos incompletos para Free Form.";

            return null;
        }

        double alturaDistribucion =
            zSuperior -
            zInferior;

        if (alturaDistribucion <= Tol)
        {
            error =
                "La altura de distribución es cero.";

            return null;
        }

        double esp =
            System.Math.Max(
                espaciamientoMaximo,
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters));

        // -----------------------------------------------------
        // El input se interpreta como ESPACIAMIENTO MÁXIMO.
        // Para Free Form calculamos explícitamente:
        //
        // N intervalos = ceil(altura / espMax)
        // paso real    = altura / N
        //
        // El paso real nunca supera el input del usuario.
        //
        // Después de crear el Free Form, el layout nativo se
        // cambia de "Número fijo" a "Número con espaciado".
        // -----------------------------------------------------
        int intervalos =
            System.Math.Max(
                1,
                (int)System.Math.Ceiling(
                    alturaDistribucion /
                    esp));

        int cantidadBarras =
            intervalos + 1;

        double pasoReal =
            alturaDistribucion /
            intervalos;

        // -----------------------------------------------------
        // Construir SOLO una vez la geometría base.
        // Luego copiarla verticalmente para cada horizontal.
        // Así todas las barras tienen exactamente:
        // - mismo centro de arco;
        // - mismo radio;
        // - mismos puntos de unión recto/curvo.
        // -----------------------------------------------------
        List<Curve> curvasBase =
            ConstruirCurvasHorizontales(
                cadena,
                signo,
                margenBase,
                zInferior,
                conf,
                resultado);

        if (curvasBase == null ||
            curvasBase.Count == 0)
        {
            error =
                "No se obtuvo la trayectoria base.";

            return null;
        }

        curvasBase =
            ConsolidarCurvasHorizontalesColineales(
                curvasBase);

        if (!ValidarSecuenciaCurvasFreeForm(
            curvasBase,
            out error))
        {
            return null;
        }

        List<CurveLoop> barras =
            new List<CurveLoop>();

        for (int i = 0;
             i < cantidadBarras;
             i++)
        {
            double dz =
                pasoReal * i;

            Transform mover =
                Transform.CreateTranslation(
                    new XYZ(
                        0.0,
                        0.0,
                        dz));

            CurveLoop loop =
                new CurveLoop();

            foreach (
                Curve curva
                in curvasBase)
            {
                if (curva == null)
                    continue;

                Curve copia =
                    curva.CreateTransformed(
                        mover);

                loop.Append(
                    copia);
            }

            barras.Add(
                loop);
        }

        Element host =
            cadena.Tramos[0]
                .Datos.Muro;

        Rebar rebar =
            CrearRebarFreeForm2027(
                doc,
                conf.TipoHorizontal,
                host,
                barras,
                out error);

        if (rebar == null)
            return null;

        // =====================================================
        // V8.33 - REGLA NATIVA "ESPACIADO MÁXIMO"
        //
        // El input "Esp. horizontal" NO debe convertirse en
        // "Número fijo" ni en "Número con espaciado".
        //
        // Intentamos aplicar directamente la regla nativa:
        //
        //     SetLayoutAsMaximumSpacing(espaciamientoMaximo)
        //
        // Si Revit bloquea el cambio porque este Free Form fue
        // creado con varios CurveLoop explícitos, NO dejamos el
        // elemento incorrecto en el modelo:
        //
        // 1. se elimina este Free Form;
        // 2. se devuelve null;
        // 3. el caller entra al fallback recto/curvo por tramos;
        // 4. cada tramo usa AplicarDistribucionMaxima(), que sí
        //    queda como "Espaciado máximo" nativo en Propiedades.
        // =====================================================
        string errorLayout =
            "";

        bool layoutOk =
            AplicarDistribucionFreeFormComoEspaciadoMaximo(
                rebar,
                espaciamientoMaximo,
                out errorLayout);

        if (!layoutOk)
        {
            try
            {
                if (rebar != null &&
                    rebar.Id != null &&
                    rebar.Id != ElementId.InvalidElementId)
                {
                    doc.Delete(
                        rebar.Id);
                }
            }
            catch
            {
            }

            error =
                "El Free Form continuo no permitió usar la regla " +
                "'Espaciado máximo'. Se usará el respaldo por tramos. " +
                errorLayout;

            return null;
        }

        return rebar;
    }

    private bool AplicarDistribucionFreeFormComoEspaciadoMaximo(
        Rebar rebar,
        double espaciamientoMaximo,
        out string error)
    {
        error =
            "";

        if (rebar == null)
        {
            error =
                "El Rebar Free Form es nulo.";

            return false;
        }

        if (espaciamientoMaximo <= Tol)
        {
            error =
                "El espaciamiento máximo debe ser mayor que cero.";

            return false;
        }

        object accessor =
            null;

        try
        {
            // -------------------------------------------------
            // Obtener RebarFreeFormAccessor
            // -------------------------------------------------
            System.Reflection.MethodInfo getAccessor =
                rebar.GetType().GetMethod(
                    "GetFreeFormAccessor",
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance,
                    null,
                    System.Type.EmptyTypes,
                    null);

            if (getAccessor == null)
            {
                error =
                    "Revit no expone GetFreeFormAccessor para este elemento.";

                return false;
            }

            accessor =
                getAccessor.Invoke(
                    rebar,
                    null);

            if (accessor == null)
            {
                error =
                    "No se pudo obtener RebarFreeFormAccessor.";

                return false;
            }

            // -------------------------------------------------
            // REGLA SOLICITADA:
            // SetLayoutAsMaximumSpacing(double spacing)
            // -------------------------------------------------
            System.Reflection.MethodInfo setLayout =
                accessor.GetType().GetMethod(
                    "SetLayoutAsMaximumSpacing",
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance,
                    null,
                    new System.Type[]
                    {
                        typeof(double)
                    },
                    null);

            if (setLayout == null)
            {
                error =
                    "Esta versión de Revit no expone " +
                    "SetLayoutAsMaximumSpacing en RebarFreeFormAccessor.";

                return false;
            }

            setLayout.Invoke(
                accessor,
                new object[]
                {
                    espaciamientoMaximo
                });

            // -------------------------------------------------
            // Verificación:
            // no basta con que Invoke no lance excepción.
            // Comprobamos LayoutRule si la API lo expone.
            // -------------------------------------------------
            System.Reflection.PropertyInfo propLayoutRule =
                accessor.GetType().GetProperty(
                    "LayoutRule",
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

            if (propLayoutRule != null)
            {
                object valor =
                    null;

                try
                {
                    valor =
                        propLayoutRule.GetValue(
                            accessor,
                            null);
                }
                catch
                {
                }

                if (valor != null)
                {
                    string texto =
                        valor.ToString() ?? "";

                    string normalizado =
                        texto
                            .Replace(
                                " ",
                                "")
                            .Replace(
                                "_",
                                "")
                            .ToUpperInvariant();

                    bool esMaximo =
                        normalizado.Contains(
                            "MAXIMUMSPACING") ||
                        normalizado.Contains(
                            "MAXSPACING") ||
                        normalizado.Contains(
                            "ESPACIADOMAXIMO");

                    if (!esMaximo)
                    {
                        error =
                            "Revit conservó la regla '" +
                            texto +
                            "' después de solicitar Espaciado máximo.";

                        return false;
                    }
                }
            }

            return true;
        }
        catch (
            System.Reflection.TargetInvocationException ex)
        {
            string detalle =
                ex.InnerException != null
                    ? ex.InnerException.Message
                    : ex.Message;

            error =
                "Revit rechazó SetLayoutAsMaximumSpacing: " +
                detalle;

            return false;
        }
        catch (System.Exception ex)
        {
            error =
                "No se pudo aplicar Espaciado máximo al Free Form: " +
                ex.Message;

            return false;
        }
        finally
        {
            System.IDisposable disposable =
                accessor as System.IDisposable;

            if (disposable != null)
            {
                try
                {
                    disposable.Dispose();
                }
                catch
                {
                }
            }
        }
    }


    private bool ValidarSecuenciaCurvasFreeForm(
        IList<Curve> curvas,
        out string error)
    {
        error =
            "";

        if (curvas == null ||
            curvas.Count == 0)
        {
            error =
                "La trayectoria Free Form está vacía.";

            return false;
        }

        Curve anterior =
            null;

        foreach (
            Curve curva
            in curvas)
        {
            if (curva == null)
                continue;

            if (!curva.IsBound)
            {
                error =
                    "La trayectoria contiene una curva no limitada.";

                return false;
            }

            if (curva.Length <= Tol)
            {
                error =
                    "La trayectoria contiene un segmento de longitud cero.";

                return false;
            }

            if (anterior != null)
            {
                XYZ finAnterior =
                    anterior.GetEndPoint(1);

                XYZ inicioActual =
                    curva.GetEndPoint(0);

                double separacion =
                    finAnterior.DistanceTo(
                        inicioActual);

                // Una holgura muy pequeña puede provenir de
                // tolerancias numéricas en un join.
                double tolerancia =
                    UnitUtils.ConvertToInternalUnits(
                        0.5,
                        UnitTypeId.Millimeters);

                if (separacion >
                    tolerancia)
                {
                    error =
                        "Hay una discontinuidad de " +
                        UnitUtils.ConvertFromInternalUnits(
                            separacion,
                            UnitTypeId.Millimeters)
                            .ToString("0.0") +
                        " mm entre dos segmentos de la trayectoria.";

                    return false;
                }
            }

            anterior =
                curva;
        }

        return true;
    }

    private Rebar CrearRebarFreeForm2027(
        Document doc,
        RebarBarType tipo,
        Element host,
        IList<CurveLoop> barras,
        out string error)
    {
        error =
            "";

        if (doc == null ||
            tipo == null ||
            host == null ||
            barras == null ||
            barras.Count == 0)
        {
            error =
                "Argumentos inválidos para crear Free Form.";

            return null;
        }

        // -----------------------------------------------------
        // REVIT 2027:
        //
        // El overload antiguo de CreateFreeForm fue retirado.
        // Para mantener este Handler resistente a cambios menores
        // del API 2027.x, localizamos por reflexión el overload:
        //
        // Document
        // RebarBarType
        // Element
        // IList<CurveLoop>
        // RebarStyle
        //
        // El resultado 2027 es un objeto de creación que contiene
        // el Rebar y un código de error.
        // -----------------------------------------------------
        try
        {
            System.Reflection.MethodInfo metodo =
                typeof(Rebar)
                    .GetMethods(
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.Static)
                    .FirstOrDefault(
                        m =>
                        {
                            if (!string.Equals(
                                m.Name,
                                "CreateFreeForm",
                                StringComparison.Ordinal))
                            {
                                return false;
                            }

                            System.Reflection.ParameterInfo[] p =
                                m.GetParameters();

                            if (p.Length != 5)
                                return false;

                            return
                                p[0].ParameterType ==
                                    typeof(Document) &&
                                p[1].ParameterType ==
                                    typeof(RebarBarType) &&
                                p[2].ParameterType ==
                                    typeof(Element) &&
                                p[4].ParameterType ==
                                    typeof(RebarStyle);
                        });

            if (metodo == null)
            {
                error =
                    "No se encontró el overload Free Form de Revit 2027.";

                return null;
            }

            object resultadoCreacion =
                metodo.Invoke(
                    null,
                    new object[]
                    {
                        doc,
                        tipo,
                        host,
                        barras,
                        RebarStyle.Standard
                    });

            if (resultadoCreacion == null)
            {
                error =
                    "Revit devolvió un resultado Free Form nulo.";

                return null;
            }

            Rebar rebarDirecto =
                resultadoCreacion as Rebar;

            if (rebarDirecto != null)
                return rebarDirecto;

            Rebar rebar =
                null;

            // No dependemos del nombre de la propiedad del wrapper:
            // tomamos la primera propiedad pública cuyo tipo sea Rebar.
            foreach (
                System.Reflection.PropertyInfo prop
                in resultadoCreacion
                    .GetType()
                    .GetProperties(
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.Instance))
            {
                if (!typeof(Rebar)
                    .IsAssignableFrom(
                        prop.PropertyType))
                {
                    continue;
                }

                try
                {
                    rebar =
                        prop.GetValue(
                            resultadoCreacion,
                            null)
                        as Rebar;
                }
                catch
                {
                }

                if (rebar != null)
                    break;
            }

            // Respaldo por método público sin argumentos
            // que retorne un Rebar.
            if (rebar == null)
            {
                foreach (
                    System.Reflection.MethodInfo m
                    in resultadoCreacion
                        .GetType()
                        .GetMethods(
                            System.Reflection.BindingFlags.Public |
                            System.Reflection.BindingFlags.Instance))
                {
                    if (m.GetParameters().Length != 0 ||
                        !typeof(Rebar)
                            .IsAssignableFrom(
                                m.ReturnType))
                    {
                        continue;
                    }

                    try
                    {
                        rebar =
                            m.Invoke(
                                resultadoCreacion,
                                null)
                            as Rebar;
                    }
                    catch
                    {
                    }

                    if (rebar != null)
                        break;
                }
            }

            if (rebar == null)
            {
                // Intentar recuperar alguna descripción del error
                // del objeto RebarFreeFormCreationResult.
                foreach (
                    System.Reflection.PropertyInfo prop
                    in resultadoCreacion
                        .GetType()
                        .GetProperties(
                            System.Reflection.BindingFlags.Public |
                            System.Reflection.BindingFlags.Instance))
                {
                    string nombre =
                        prop.Name ?? "";

                    if (nombre.IndexOf(
                        "Error",
                        StringComparison.OrdinalIgnoreCase) < 0 &&
                        nombre.IndexOf(
                        "Result",
                        StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        continue;
                    }

                    try
                    {
                        object valor =
                            prop.GetValue(
                                resultadoCreacion,
                                null);

                        if (valor != null)
                        {
                            error =
                                "Revit Free Form: " +
                                valor.ToString();

                            break;
                        }
                    }
                    catch
                    {
                    }
                }
            }

            IDisposable disposable =
                resultadoCreacion as IDisposable;

            if (disposable != null)
            {
                try
                {
                    disposable.Dispose();
                }
                catch
                {
                }
            }

            if (rebar == null &&
                string.IsNullOrWhiteSpace(
                    error))
            {
                error =
                    "Revit no devolvió el elemento Rebar Free Form.";
            }

            return rebar;
        }
        catch (
            System.Reflection.TargetInvocationException ex)
        {
            string detalle =
                ex.InnerException != null
                    ? ex.InnerException.Message
                    : ex.Message;

            error =
                "CreateFreeForm fue rechazado: " +
                detalle;

            return null;
        }
        catch (Exception ex)
        {
            error =
                "Error creando Free Form: " +
                ex.Message;

            return null;
        }
    }


    // ================================================================
    // QUIEBRE DE EMPALME - MISMO CRITERIO DEL MÓDULO DE VIGAS
    // ================================================================
    private double ObtenerDesfaseEmpalmeCaraACaraMuro(
        double diametro)
    {
        // Igual que en acero de vigas:
        // durante el traslape la segunda pieza se desplaza
        // exactamente UN DIÁMETRO de barra.
        double separacionLibreCaraACara =
            UnitUtils.ConvertToInternalUnits(
                0.0,
                UnitTypeId.Centimeters);

        if (diametro <= Tol)
            return separacionLibreCaraACara;

        return
            diametro +
            separacionLibreCaraACara;
    }

    private bool TryObtenerLongitudDiagonalQuiebreSeguraMuro(
        double espacioDespuesEmpalme,
        double desfaseEmpalme,
        out double longitudDiagonal)
    {
        longitudDiagonal =
            0.0;

        if (espacioDespuesEmpalme <= Tol ||
            desfaseEmpalme <= Tol)
        {
            return false;
        }

        // MISMO QUIEBRE DE VIGAS:
        // diagonal objetivo = 20 cm.
        double diagonalObjetivo =
            UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

        double diagonalMinima =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        double rectoSalidaMinimo =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        // Para diámetros grandes se escala la reserva,
        // exactamente con el criterio del módulo de vigas.
        diagonalMinima =
            System.Math.Max(
                diagonalMinima,
                desfaseEmpalme * 4.0);

        rectoSalidaMinimo =
            System.Math.Max(
                rectoSalidaMinimo,
                desfaseEmpalme * 2.0);

        double disponibleDiagonal =
            espacioDespuesEmpalme -
            rectoSalidaMinimo;

        if (disponibleDiagonal <
            diagonalMinima -
            Tol)
        {
            return false;
        }

        longitudDiagonal =
            System.Math.Min(
                diagonalObjetivo,
                disponibleDiagonal);

        return
            longitudDiagonal >=
            diagonalMinima -
            Tol;
    }

    private Curve CrearCurvaTraslapeHaciaCentroMuro(
        TramoCadena tramo,
        Curve curva,
        int signoCara,
        double desfase)
    {
        if (curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol ||
            desfase <= Tol)
        {
            return null;
        }

        // =====================================================
        // RECTA:
        // no necesitamos buscar el centro geométrico del tramo.
        // La propia dirección de la barra define su normal.
        // =====================================================
        Line linea =
            curva as Line;

        if (linea != null)
        {
            XYZ p0 =
                linea.GetEndPoint(0);

            XYZ p1 =
                linea.GetEndPoint(1);

            XYZ tangente =
                new XYZ(
                    p1.X - p0.X,
                    p1.Y - p0.Y,
                    0.0);

            if (tangente.GetLength() <= Tol)
                return null;

            tangente =
                tangente.Normalize();

            XYZ normalIzquierda =
                new XYZ(
                    -tangente.Y,
                    tangente.X,
                    0.0);

            if (normalIzquierda.GetLength() <= Tol)
                return null;

            normalIzquierda =
                normalIzquierda.Normalize();

            double sentidoHaciaCentro;

            if (signoCara > 0)
            {
                // Cara A se encuentra en +normal.
                // Para ir al centro movemos hacia -normal.
                sentidoHaciaCentro =
                    -1.0;
            }
            else if (signoCara < 0)
            {
                // Cara B se encuentra en -normal.
                // Para ir al centro movemos hacia +normal.
                sentidoHaciaCentro =
                    1.0;
            }
            else
            {
                // Una malla centrada:
                // elegir un lado fijo para que el empalme
                // siempre tenga quiebre visible.
                sentidoHaciaCentro =
                    -1.0;
            }

            XYZ vectorDesfase =
                normalIzquierda.Multiply(
                    sentidoHaciaCentro *
                    desfase);

            try
            {
                return
                    Line.CreateBound(
                        p0 + vectorDesfase,
                        p1 + vectorDesfase);
            }
            catch
            {
                return null;
            }
        }

        // =====================================================
        // CURVA:
        // Curve.CreateOffset conserva la geometría del Arc.
        //
        // Para determinar cuál de los dos signos va hacia el
        // centro probamos +d y -d y escogemos el que se aproxima
        // al centro real del núcleo del tramo.
        // =====================================================
        Arc arco =
            curva as Arc;

        if (arco != null)
        {
            Curve candidatoPos =
                null;

            Curve candidatoNeg =
                null;

            try
            {
                candidatoPos =
                    curva.CreateOffset(
                        desfase,
                        XYZ.BasisZ);
            }
            catch
            {
            }

            try
            {
                candidatoNeg =
                    curva.CreateOffset(
                        -desfase,
                        XYZ.BasisZ);
            }
            catch
            {
            }

            if (candidatoPos == null &&
                candidatoNeg == null)
            {
                return null;
            }

            // Si por cualquier razón no tenemos el tramo,
            // usar el signo de cara directamente.
            if (tramo == null)
            {
                if (signoCara > 0)
                    return candidatoPos ?? candidatoNeg;

                if (signoCara < 0)
                    return candidatoNeg ?? candidatoPos;

                return candidatoPos ?? candidatoNeg;
            }

            double nucleoMin;
            double nucleoMax;

            if (!TryObtenerIntervaloNucleoEnNormalTramo(
                tramo,
                out nucleoMin,
                out nucleoMax))
            {
                if (signoCara > 0)
                    return candidatoPos ?? candidatoNeg;

                if (signoCara < 0)
                    return candidatoNeg ?? candidatoPos;

                return candidatoPos ?? candidatoNeg;
            }

            double longitudTramo =
                ObtenerLongitudTramo(
                    tramo);

            XYZ puntoEje =
                ObtenerPuntoTramoPorDistancia(
                    tramo,
                    longitudTramo * 0.5);

            XYZ tangenteTramo =
                ObtenerTangenteTramoPorDistancia(
                    tramo,
                    longitudTramo * 0.5);

            if (puntoEje == null ||
                tangenteTramo == null ||
                tangenteTramo.GetLength() <= Tol)
            {
                return candidatoPos ?? candidatoNeg;
            }

            tangenteTramo =
                tangenteTramo.Normalize();

            XYZ normalIzquierdaTramo =
                new XYZ(
                    -tangenteTramo.Y,
                    tangenteTramo.X,
                    0.0);

            if (normalIzquierdaTramo.GetLength() <= Tol)
                return candidatoPos ?? candidatoNeg;

            normalIzquierdaTramo =
                normalIzquierdaTramo.Normalize();

            double centroNucleo =
                (nucleoMin +
                 nucleoMax) * 0.5;

            XYZ puntoCentroNucleo =
                puntoEje +
                normalIzquierdaTramo.Multiply(
                    centroNucleo);

            double dPos =
                double.MaxValue;

            double dNeg =
                double.MaxValue;

            if (candidatoPos != null)
            {
                XYZ pm =
                    candidatoPos.Evaluate(
                        0.5,
                        true);

                dPos =
                    new XYZ(
                        pm.X - puntoCentroNucleo.X,
                        pm.Y - puntoCentroNucleo.Y,
                        0.0)
                    .GetLength();
            }

            if (candidatoNeg != null)
            {
                XYZ pm =
                    candidatoNeg.Evaluate(
                        0.5,
                        true);

                dNeg =
                    new XYZ(
                        pm.X - puntoCentroNucleo.X,
                        pm.Y - puntoCentroNucleo.Y,
                        0.0)
                    .GetLength();
            }

            return
                dPos <= dNeg
                    ? candidatoPos
                    : candidatoNeg;
        }

        return null;
    }

    private List<Curve> ConstruirBocetoPiezaHorizontalConQuiebreMuro(
        TramoCadena tramo,
        Curve pieza,
        int signoCara,
        bool tieneEmpalmeInicio,
        double longitudEmpalme,
        double diametro)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (pieza == null ||
            !pieza.IsBound ||
            pieza.Length <= Tol)
        {
            return resultado;
        }

        if (!tieneEmpalmeInicio)
        {
            resultado.Add(
                pieza);

            return resultado;
        }

        // =====================================================
        // EMPALME = QUIEBRE OBLIGATORIO
        //
        // No existe respaldo colineal.
        //
        // PIEZA NUEVA:
        //
        // 1) traslape desplazado 1Ø hacia el centro,
        // 2) diagonal de retorno,
        // 3) continuación exactamente sobre el eje original.
        // =====================================================
        if (longitudEmpalme <= Tol ||
            diametro <= Tol)
        {
            return resultado;
        }

        double longitudPieza =
            pieza.Length;

        double xEmpalmeFin =
            System.Math.Min(
                longitudEmpalme,
                longitudPieza);

        double espacioDespuesEmpalme =
            longitudPieza -
            xEmpalmeFin;

        double desfaseEmpalme =
            ObtenerDesfaseEmpalmeCaraACaraMuro(
                diametro);

        double longitudDiagonal;

        bool cabeQuiebre =
            TryObtenerLongitudDiagonalQuiebreSeguraMuro(
                espacioDespuesEmpalme,
                desfaseEmpalme,
                out longitudDiagonal);

        // V11.8 del módulo de vigas:
        // si no puede resolverse el quiebre completo,
        // NO se crea una pieza colineal falsa.
        if (!cabeQuiebre ||
            longitudDiagonal <= Tol)
        {
            return resultado;
        }

        double xDiagonalFin =
            System.Math.Min(
                xEmpalmeFin +
                longitudDiagonal,
                longitudPieza);

        Curve tramoTraslapado =
            ExtraerSubCurvaPorDistancia(
                pieza,
                0.0,
                xEmpalmeFin);

        if (tramoTraslapado == null)
            return resultado;

        Curve tramoTraslapadoDesplazado =
            CrearCurvaTraslapeHaciaCentroMuro(
                tramo,
                tramoTraslapado,
                signoCara,
                desfaseEmpalme);

        if (tramoTraslapadoDesplazado == null)
            return resultado;

        // Protección:
        // no aceptar silenciosamente una "curva desplazada"
        // que en realidad haya quedado sobre el mismo eje.
        double desplazamientoReal =
            tramoTraslapadoDesplazado
                .GetEndPoint(0)
                .DistanceTo(
                    tramoTraslapado
                        .GetEndPoint(0));

        if (desplazamientoReal <
            diametro * 0.50)
        {
            return resultado;
        }

        XYZ pInicioDiagonal =
            tramoTraslapadoDesplazado
                .GetEndPoint(1);

        Curve sondaBase =
            ExtraerSubCurvaPorDistancia(
                pieza,
                xEmpalmeFin,
                xDiagonalFin);

        if (sondaBase == null)
            return resultado;

        XYZ pFinDiagonal =
            sondaBase.GetEndPoint(1);

        if (pInicioDiagonal == null ||
            pFinDiagonal == null ||
            pInicioDiagonal.DistanceTo(
                pFinDiagonal) <= Tol)
        {
            return resultado;
        }

        Line diagonal;

        try
        {
            diagonal =
                Line.CreateBound(
                    pInicioDiagonal,
                    pFinDiagonal);
        }
        catch
        {
            return resultado;
        }

        resultado.Add(
            tramoTraslapadoDesplazado);

        resultado.Add(
            diagonal);

        if (longitudPieza >
            xDiagonalFin +
            Tol)
        {
            Curve tramoPosterior =
                ExtraerSubCurvaPorDistancia(
                    pieza,
                    xDiagonalFin,
                    longitudPieza);

            if (tramoPosterior == null)
            {
                resultado.Clear();
                return resultado;
            }

            // Debe iniciar exactamente en el final de la diagonal.
            double discontinuidad =
                tramoPosterior
                    .GetEndPoint(0)
                    .DistanceTo(
                        diagonal.GetEndPoint(1));

            double tolerancia =
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Millimeters);

            if (discontinuidad >
                tolerancia)
            {
                resultado.Clear();
                return resultado;
            }

            resultado.Add(
                tramoPosterior);
        }

        // Una pieza empalmada válida debe tener al menos:
        // traslape desplazado + diagonal.
        if (resultado.Count < 2)
        {
            resultado.Clear();
        }

        return
            resultado;
    }


    private double CalcularLongitudEjeComercialMuro(
        double longitudComercial,
        double longitudEmpalme,
        double diametro)
    {
        if (longitudComercial <= Tol)
            return longitudComercial;

        // =====================================================
        // SOLO COMPENSACIÓN DEL QUIEBRE
        //
        // El input de longitud comercial es la LONGITUD MÁXIMA
        // de la pieza terminada.
        //
        // El quiebre reemplaza 20 cm rectos por una diagonal.
        // Esa diagonal es ligeramente más larga.
        //
        // Para que la pieza terminada no supere, por ejemplo,
        // 9.00 m, se descuenta solamente ese exceso.
        //
        // La ubicación en tercio central se resuelve posteriormente
        // en DividirTrayectoriaConEmpalmeComercial().
        // =====================================================
        if (longitudEmpalme <= Tol ||
            diametro <= Tol)
        {
            return longitudComercial;
        }

        double longitudDiagonal =
            UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

        double desfase =
            ObtenerDesfaseEmpalmeCaraACaraMuro(
                diametro);

        if (longitudDiagonal <= Tol ||
            desfase <= Tol)
        {
            return longitudComercial;
        }

        double diagonalReal =
            System.Math.Sqrt(
                longitudDiagonal *
                longitudDiagonal +
                desfase *
                desfase);

        double excesoDiagonal =
            System.Math.Max(
                0.0,
                diagonalReal -
                longitudDiagonal);

        double longitudEje =
            longitudComercial -
            excesoDiagonal;

        double minimo =
            longitudEmpalme +
            UnitUtils.ConvertToInternalUnits(
                10.0,
                UnitTypeId.Centimeters);

        if (longitudEje < minimo)
            longitudEje = minimo;

        return
            System.Math.Min(
                longitudComercial,
                longitudEje);
    }


    private double ObtenerLongitudEmpalmeGeometrica(
        RebarBarType tipoBarra,
        AceroMuroForm.AceroMuroConfiguracion conf)
    {
        double diametroPies =
            ObtenerDiametroBarra(
                tipoBarra);

        double diametroMm =
            UnitUtils.ConvertFromInternalUnits(
                diametroPies,
                UnitTypeId.Millimeters);

        // =====================================================
        // V8.68 - PRIMERA PRIORIDAD:
        // TABLA EDITABLE DE LA VENTANA.
        //
        // Se compara por diámetro REAL, no por nombre del tipo.
        // 12.0 mm y 12.7 mm siguen siendo diámetros distintos.
        // =====================================================
        if (conf != null &&
            conf.EmpalmesPorDiametro != null)
        {
            AceroMuroForm.AceroMuroEmpalmeDiametroData mejor =
                null;

            double mejorDiferencia =
                double.MaxValue;

            foreach (
                AceroMuroForm.AceroMuroEmpalmeDiametroData item
                in conf.EmpalmesPorDiametro)
            {
                if (item == null ||
                    item.DiametroMm <= 0.0 ||
                    item.LongitudEmpalmeCm <= 0.0)
                {
                    continue;
                }

                double diferencia =
                    System.Math.Abs(
                        item.DiametroMm -
                        diametroMm);

                if (diferencia <
                    mejorDiferencia)
                {
                    mejorDiferencia =
                        diferencia;

                    mejor =
                        item;
                }
            }

            if (mejor != null &&
                mejorDiferencia <= 0.25)
            {
                return
                    UnitUtils.ConvertToInternalUnits(
                        mejor.LongitudEmpalmeCm,
                        UnitTypeId.Centimeters);
            }
        }

        // =====================================================
        // RESPALDO:
        // tabla indicada + 5 cm.
        //
        // 3/8"  -> 50 cm
        // 12 mm -> 60 cm
        // 1/2"  -> 65 cm
        // 5/8"  -> 80 cm
        // 3/4"  -> 90 cm
        // =====================================================
        double longitudCm;

        if (System.Math.Abs(
                diametroMm -
                9.525) <=
            0.25)
        {
            longitudCm =
                50.0;
        }
        else if (System.Math.Abs(
                     diametroMm -
                     12.0) <=
                 0.20)
        {
            longitudCm =
                60.0;
        }
        else if (System.Math.Abs(
                     diametroMm -
                     12.7) <=
                 0.20)
        {
            longitudCm =
                65.0;
        }
        else if (System.Math.Abs(
                     diametroMm -
                     15.875) <=
                 0.25)
        {
            longitudCm =
                80.0;
        }
        else if (System.Math.Abs(
                     diametroMm -
                     19.05) <=
                 0.25)
        {
            longitudCm =
                90.0;
        }
        else
        {
            // Otros diámetros:
            // criterio anterior 60db, mínimo 30 cm, también +5 cm.
            longitudCm =
                System.Math.Max(
                    diametroMm * 6.0,
                    30.0) +
                5.0;
        }

        return
            UnitUtils.ConvertToInternalUnits(
                longitudCm,
                UnitTypeId.Centimeters);
    }

    // =========================================================
    // DIVISIÓN PURA POR LONGITUD COMERCIAL
    //
    // NO usa tercios.
    // NO usa zonas.
    // NO usa RNE para decidir dónde empalmar.
    //
    // Cada pieza avanza:
    // longitud comercial - longitud de traslape
    //
    // El quiebre se modela posteriormente.
    // =========================================================
    private List<Curve> DividirCurvaConEmpalmeComercial(
        Curve curva,
        double longitudComercial,
        double longitudEmpalme)
    {
        List<Curve> piezas =
            new List<Curve>();

        if (curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return piezas;
        }

        double longitud =
            curva.Length;

        if (longitud <=
            longitudComercial +
            Tol)
        {
            piezas.Add(
                curva);

            return piezas;
        }

        double avance =
            longitudComercial -
            longitudEmpalme;

        double minimoAvance =
            UnitUtils.ConvertToInternalUnits(
                10.0,
                UnitTypeId.Centimeters);

        if (avance <=
            minimoAvance)
        {
            return piezas;
        }

        double inicio =
            0.0;

        int seguridad =
            0;

        while (inicio <
               longitud -
               Tol &&
               seguridad < 500)
        {
            seguridad++;

            double fin =
                System.Math.Min(
                    longitud,
                    inicio +
                    longitudComercial);

            Curve pieza =
                ExtraerSubCurvaPorDistancia(
                    curva,
                    inicio,
                    fin);

            if (pieza != null &&
                pieza.Length > Tol)
            {
                piezas.Add(
                    pieza);
            }

            if (fin >=
                longitud -
                Tol)
            {
                break;
            }

            inicio =
                fin -
                longitudEmpalme;

            inicio =
                System.Math.Max(
                    0.0,
                    inicio);
        }

        return piezas;
    }

    private Curve ExtraerSubCurvaPorDistancia(
        Curve curva,
        double inicio,
        double fin)
    {
        if (curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return null;
        }

        double longitud =
            curva.Length;

        inicio =
            System.Math.Max(
                0.0,
                System.Math.Min(
                    longitud,
                    inicio));

        fin =
            System.Math.Max(
                inicio,
                System.Math.Min(
                    longitud,
                    fin));

        if (fin -
            inicio <= Tol)
        {
            return null;
        }

        double t0 =
            inicio /
            longitud;

        double t1 =
            fin /
            longitud;

        XYZ p0 =
            curva.Evaluate(
                t0,
                true);

        XYZ p1 =
            curva.Evaluate(
                t1,
                true);

        if (p0.DistanceTo(
            p1) <= Tol)
        {
            return null;
        }

        if (curva is Line)
        {
            return
                Line.CreateBound(
                    p0,
                    p1);
        }

        if (curva is Arc)
        {
            double tm =
                (t0 + t1) * 0.5;

            XYZ pm =
                curva.Evaluate(
                    tm,
                    true);

            try
            {
                return
                    Arc.Create(
                        p0,
                        p1,
                        pm);
            }
            catch
            {
                return null;
            }
        }

        return null;
    }

    private Rebar CrearRebarFreeFormExactoHorizontalConQuiebre(
        Document doc,
        Element host,
        RebarBarType tipo,
        IList<Curve> bocetoBase,
        double longitudDistribucion,
        double espaciamientoMaximo,
        out string error)
    {
        error =
            "";

        if (doc == null ||
            host == null ||
            tipo == null ||
            bocetoBase == null ||
            bocetoBase.Count < 2 ||
            longitudDistribucion <= Tol ||
            espaciamientoMaximo <= Tol)
        {
            error =
                "Datos inválidos para crear el Free Form exacto del quiebre.";

            return null;
        }

        // =====================================================
        // El input sigue comportándose como ESPACIAMIENTO MÁXIMO:
        //
        // intervalos = ceil(L / Smax)
        // pasoReal   = L / intervalos
        //
        // por tanto:
        // pasoReal <= Smax
        // =====================================================
        int intervalos =
            System.Math.Max(
                1,
                (int)System.Math.Ceiling(
                    longitudDistribucion /
                    espaciamientoMaximo));

        int cantidadBarras =
            intervalos + 1;

        double pasoReal =
            longitudDistribucion /
            intervalos;

        IList<IList<Curve>> curvasPorBarra =
            new List<IList<Curve>>();

        for (int i = 0;
             i < cantidadBarras;
             i++)
        {
            double dz =
                pasoReal * i;

            Transform mover =
                Transform.CreateTranslation(
                    new XYZ(
                        0.0,
                        0.0,
                        dz));

            IList<Curve> cadena =
                new List<Curve>();

            foreach (
                Curve curvaBase
                in bocetoBase)
            {
                if (curvaBase == null)
                    continue;

                Curve copia;

                try
                {
                    copia =
                        curvaBase.CreateTransformed(
                            mover);
                }
                catch
                {
                    error =
                        "No se pudo trasladar una curva del quiebre Free Form.";

                    return null;
                }

                if (copia != null)
                    cadena.Add(
                        copia);
            }

            if (cadena.Count !=
                bocetoBase.Count)
            {
                error =
                    "La cadena Free Form quedó incompleta.";

                return null;
            }

            curvasPorBarra.Add(
                cadena);
        }

        Rebar rebar =
            null;

        try
        {
            // MISMO flujo usado por el módulo de vigas:
            // una entrada de curvasPorBarra = una barra física completa.
            using (
                RebarFreeFormCreationResult resultadoFree =
                    Rebar.CreateFreeForm(
                        doc,
                        tipo,
                        host,
                        curvasPorBarra,
                        RebarStyle.Standard))
            {
                if (resultadoFree == null)
                {
                    error =
                        "Rebar.CreateFreeForm devolvió null.";

                    return null;
                }

                if (resultadoFree.Error !=
                    RebarFreeFormValidationResult.Success)
                {
                    error =
                        "Rebar.CreateFreeForm devolvió: " +
                        resultadoFree.Error.ToString();

                    return null;
                }

                rebar =
                    resultadoFree.Rebar;
            }
        }
        catch (Exception ex)
        {
            error =
                "Rebar.CreateFreeForm rechazó el quiebre: " +
                ex.Message;

            return null;
        }

        if (rebar == null)
        {
            error =
                "Revit no devolvió el Rebar Free Form.";

            return null;
        }

        // -----------------------------------------------------
        // Revit Free Form no expone la misma regla
        // SetLayoutAsMaximumSpacing del ShapeDrivenAccessor.
        //
        // Intentamos dejar el conjunto como:
        // NÚMERO CON ESPACIADO
        //
        // usando el pasoReal ya calculado <= espaciado máximo.
        //
        // Si Revit no permite cambiar la regla, NO destruimos
        // el quiebre: la geometría exacta tiene prioridad.
        // -----------------------------------------------------
        try
        {
            using (
                RebarFreeFormAccessor accessor =
                    rebar.GetFreeFormAccessor())
            {
                if (accessor != null)
                {
                    accessor.SetLayoutAsNumberWithSpacing(
                        cantidadBarras,
                        pasoReal);
                }
            }
        }
        catch
        {
            // Se conserva el Free Form exacto.
        }

        return
            rebar;
    }


    private int CrearRebarsHorizontalesDeCurva(
        Document doc,
        Curve curva,
        Element host,
        CadenaMuros cadena,
        int indiceTramo,
        int signo,
        double longitudDistribucion,
        double espaciamiento,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            curva == null ||
            host == null ||
            cadena == null ||
            conf == null ||
            conf.TipoHorizontal == null ||
            resultado == null)
        {
            return 0;
        }

        List<Curve> piezas =
            new List<Curve>();

        double longitudEmpalme =
            0.0;

        if (conf.ConsiderarEmpalmeHorizontal)
        {
            double longitudComercial =
                ConvertirCm(
                    conf.LongitudComercialCm);

            longitudEmpalme =
                ObtenerLongitudEmpalmeGeometrica(
                    conf.TipoHorizontal,
                    conf);

            double diametroParaLongitud =
                ObtenerDiametroBarra(
                    conf.TipoHorizontal);

            double longitudEjeComercial =
                CalcularLongitudEjeComercialMuro(
                    longitudComercial,
                    longitudEmpalme,
                    diametroParaLongitud);

            piezas =
                DividirCurvaConEmpalmeComercial(
                    curva,
                    longitudEjeComercial,
                    longitudEmpalme);

            if (piezas.Count == 0)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ": no se pudieron dividir las piezas por longitud comercial.");

                return 0;
            }
        }
        else
        {
            piezas.Add(
                curva);
        }

        TramoCadena tramoActual =
            cadena.Tramos != null &&
            indiceTramo >= 0 &&
            indiceTramo <
                cadena.Tramos.Count
                ? cadena.Tramos[
                    indiceTramo]
                : null;

        double diametro =
            ObtenerDiametroBarra(
                conf.TipoHorizontal);

        // -----------------------------------------------------
        // PRECALCULAR TODOS LOS BOCETOS.
        // -----------------------------------------------------
        List<List<Curve>> bocetos =
            new List<List<Curve>>();

        for (int p = 0;
             p < piezas.Count;
             p++)
        {
            Curve pieza =
                piezas[p];

            if (pieza == null)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ": se encontró una pieza nula.");

                return 0;
            }

            bool tieneEmpalmeInicio =
                conf.ConsiderarEmpalmeHorizontal &&
                p > 0;

            List<Curve> boceto =
                ConstruirBocetoPiezaHorizontalConQuiebreMuro(
                    tramoActual,
                    pieza,
                    signo,
                    tieneEmpalmeInicio,
                    longitudEmpalme,
                    diametro);

            if (boceto == null ||
                boceto.Count == 0)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", pieza " +
                    (p + 1) +
                    ": no se pudo construir la geometría del empalme.");

                return 0;
            }

            if (tieneEmpalmeInicio &&
                boceto.Count < 2)
            {
                resultado.Errores.Add(
                    "Cadena " +
                    cadena.Numero +
                    ", pieza " +
                    (p + 1) +
                    ": el empalme quedó colineal antes de enviarlo a Revit.");

                return 0;
            }

            if (conf.ConsiderarEmpalmeHorizontal)
            {
                double longitudComercialMaxima =
                    ConvertirCm(
                        conf.LongitudComercialCm);

                double longitudBoceto =
                    ObtenerLongitudTotalCurvas(
                        boceto);

                double toleranciaLongitud =
                    UnitUtils.ConvertToInternalUnits(
                        2.0,
                        UnitTypeId.Millimeters);

                if (longitudBoceto <= Tol ||
                    longitudBoceto >
                        longitudComercialMaxima +
                        toleranciaLongitud)
                {
                    resultado.Errores.Add(
                        "Cadena " +
                        cadena.Numero +
                        ", pieza " +
                        (p + 1) +
                        ": el boceto calculado mide " +
                        UnitUtils.ConvertFromInternalUnits(
                            longitudBoceto,
                            UnitTypeId.Meters)
                            .ToString("0.###") +
                        " m y supera L. comercial = " +
                        (conf.LongitudComercialCm / 100.0)
                            .ToString("0.###") +
                        " m.");

                    return 0;
                }
            }

            bocetos.Add(
                boceto);
        }

        List<ElementId> idsLocales =
            new List<ElementId>();

        int creados =
            0;

        for (int p = 0;
             p < piezas.Count;
             p++)
        {
            List<Curve> boceto =
                bocetos[p];

            bool tieneEmpalmeInicio =
                conf.ConsiderarEmpalmeHorizontal &&
                p > 0;

            Rebar rebar =
                null;

            // =================================================
            // PIEZA SIN EMPALME
            // =================================================
            if (!tieneEmpalmeInicio)
            {
                // V8.64:
                // Aunque sea la PIEZA 1 y solo tenga una Line/Arc, si el
                // modo empalme está activo NO reutilizamos una forma vieja.
                // Se crea una forma NUEVA EXACTA con la longitud comercial
                // ya calculada.
                if (conf.ConsiderarEmpalmeHorizontal)
                {
                    rebar =
                        CrearRebarDesdeCurvasNuevaFormaExacta(
                            doc,
                            host,
                            conf.TipoHorizontal,
                            XYZ.BasisZ,
                            boceto);
                }
                else
                {
                    rebar =
                        CrearRebarDesdeCurvas(
                            doc,
                            host,
                            conf.TipoHorizontal,
                            XYZ.BasisZ,
                            boceto);
                }

                if (rebar != null)
                {
                    AplicarDistribucionMaximaExactaInput(
                        rebar,
                        espaciamiento,
                        longitudDistribucion);
                }
            }
            else
            {
                // =================================================
                // PIEZA CON EMPALME:
                //
                // NO usar CrearRebarDesdeCurvas() genérico.
                //
                // Ese método intenta primero:
                // useExistingShapeIfPossible = true
                //
                // y Revit estaba encontrando "Forma 00", por eso
                // convertía nuevamente el quiebre en una recta.
                //
                // A partir de V8.38:
                //
                // 1) false,true -> FORMA NUEVA EXACTA.
                // 2) si falla -> FREE FORM EXACTO.
                // =================================================
                rebar =
                    CrearRebarDesdeCurvasNuevaFormaExacta(
                        doc,
                        host,
                        conf.TipoHorizontal,
                        XYZ.BasisZ,
                        boceto);

                if (rebar != null)
                {
                    // Revit puede devolver un elemento válido y aun así
                    // normalizar las tres curvas como una barra recta.
                    // Verificamos la geometría REAL del Rebar creado.
                    if (!RebarTieneQuiebreVisible(
                        rebar))
                    {
                        try
                        {
                            doc.Delete(
                                rebar.Id);
                        }
                        catch
                        {
                        }

                        rebar =
                            null;
                    }
                    else
                    {
                        AplicarDistribucionMaximaExactaInput(
                            rebar,
                            espaciamiento,
                            longitudDistribucion);
                    }
                }

                if (rebar == null)
                {
                    string errorFree =
                        "";

                    // El Shape Driven no conservó el quiebre.
                    // Crear directamente la cadena exacta como Free Form.
                    rebar =
                        CrearRebarFreeFormExactoHorizontalConQuiebre(
                            doc,
                            host,
                            conf.TipoHorizontal,
                            boceto,
                            longitudDistribucion,
                            espaciamiento,
                            out errorFree);

                    if (rebar != null &&
                        !RebarTieneQuiebreVisible(
                            rebar))
                    {
                        try
                        {
                            doc.Delete(
                                rebar.Id);
                        }
                        catch
                        {
                        }

                        rebar =
                            null;

                        errorFree =
                            "Revit creó el Free Form, pero la geometría resultante quedó colineal.";
                    }

                    if (rebar == null)
                    {
                        foreach (
                            ElementId id
                            in idsLocales)
                        {
                            try
                            {
                                doc.Delete(
                                    id);
                            }
                            catch
                            {
                            }

                            resultado.Ids.Remove(
                                id);
                        }

                        resultado.Horizontales =
                            System.Math.Max(
                                0,
                                resultado.Horizontales -
                                creados);

                        resultado.Errores.Add(
                            "Cadena " +
                            cadena.Numero +
                            ", pieza " +
                            (p + 1) +
                            ": Revit rechazó la forma nueva exacta y el Free Form. " +
                            "No se creó un empalme colineal. " +
                            errorFree);

                        return 0;
                    }
                }
            }

            if (rebar == null)
            {
                foreach (
                    ElementId id
                    in idsLocales)
                {
                    try
                    {
                        doc.Delete(
                            id);
                    }
                    catch
                    {
                    }

                    resultado.Ids.Remove(
                        id);
                }

                resultado.Horizontales =
                    System.Math.Max(
                        0,
                        resultado.Horizontales -
                        creados);

                return 0;
            }

            // -------------------------------------------------
            // V8.64 - VALIDAR LA GEOMETRÍA REAL QUE CREÓ REVIT
            // -------------------------------------------------
            if (conf.ConsiderarEmpalmeHorizontal)
            {
                double longitudComercialMaxima =
                    ConvertirCm(
                        conf.LongitudComercialCm);

                double longitudReal;

                bool cumpleLongitud =
                    ValidarLongitudComercialRealRebar(
                        rebar,
                        longitudComercialMaxima,
                        out longitudReal);

                if (!cumpleLongitud)
                {
                    try
                    {
                        doc.Delete(
                            rebar.Id);
                    }
                    catch
                    {
                    }

                    foreach (
                        ElementId id
                        in idsLocales)
                    {
                        try
                        {
                            doc.Delete(
                                id);
                        }
                        catch
                        {
                        }

                        resultado.Ids.Remove(
                            id);
                    }

                    resultado.Horizontales =
                        System.Math.Max(
                            0,
                            resultado.Horizontales -
                            creados);

                    resultado.Errores.Add(
                        "Cadena " +
                        cadena.Numero +
                        ", pieza " +
                        (p + 1) +
                        ": Revit creó una longitud real de " +
                        UnitUtils.ConvertFromInternalUnits(
                            longitudReal,
                            UnitTypeId.Meters)
                            .ToString("0.###") +
                        " m; L. comercial máxima = " +
                        (conf.LongitudComercialCm / 100.0)
                            .ToString("0.###") +
                        " m. La pieza fue eliminada.");

                    return 0;
                }
            }

            string caraTexto =
                signo == 0
                    ? "Una malla centrada"
                    : signo > 0
                        ? "Cara A"
                        : "Cara B";

            string descripcion =
                conf.ConsiderarEmpalmeHorizontal
                    ? "Acero horizontal con empalme y QUIEBRE REAL - " +
                        caraTexto +
                        " - Cadena " +
                        cadena.Numero +
                        " - Pieza " +
                        (p + 1) +
                        "/" +
                        piezas.Count
                    : "Acero horizontal de alma de muro - " +
                        caraTexto +
                        " - Cadena " +
                        cadena.Numero;

            string marca =
                "MUR-ALMA-HOR-CAD-" +
                cadena.Numero +
                "-T" +
                (indiceTramo + 1) +
                "-P" +
                (p + 1) +
                "-" +
                (signo == 0
                    ? "CENTRO"
                    : signo > 0
                        ? "A"
                        : "B");

            CompletarParametrosMYGMuro(
                rebar,
                host,
                descripcion,
                marca);

            resultado.Horizontales++;

            resultado.Ids.Add(
                rebar.Id);

            idsLocales.Add(
                rebar.Id);

            creados++;
        }

        return
            creados;
    }


    private int CrearHorizontalesCadenaRectaConEmpalmeGlobal(
        Document doc,
        CadenaMuros cadena,
        int signo,
        double margenBase,
        double elevacion,
        double longitudDistribucion,
        double espaciamiento,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            conf == null ||
            conf.TipoHorizontal == null ||
            resultado == null ||
            !conf.ConsiderarEmpalmeHorizontal)
        {
            return 0;
        }

        // =====================================================
        // IMPORTANTE:
        // La longitud comercial se mide sobre TODA LA CADENA.
        //
        // Ejemplo:
        // muro 1 = 3.00 m
        // muro 2 = 4.00 m
        // muro 3 = 5.00 m
        // L comercial = 9.00 m
        //
        // El empalme NO se reinicia al entrar al muro 2.
        // El primer corte comercial se calcula a partir del
        // inicio de toda la cadena.
        //
        // NO EXISTEN:
        // - tercio central;
        // - tercio extremo;
        // - zona permitida;
        // - regla RNE de ubicación del empalme.
        // =====================================================

        bool tieneCurvos =
            cadena.Tramos.Any(
                x =>
                    x != null &&
                    x.Datos != null &&
                    x.Datos.EsCurvo);

        // Esta ruta global Shape Driven se usa cuando la cadena
        // completa es recta. En curvas se conserva el creador por
        // tramos para respetar el radio real de cada anfitrión.
        if (tieneCurvos)
            return 0;

        List<Curve> ruta =
            ConstruirCurvasHorizontales(
                cadena,
                signo,
                margenBase,
                elevacion,
                conf,
                resultado);

        if (ruta == null ||
            ruta.Count == 0)
        {
            return 0;
        }

        ruta =
            ConsolidarCurvasHorizontalesColineales(
                ruta);

        // Para una cadena recta correctamente alineada debe quedar
        // una única Line después de consolidar. Si no ocurre, no
        // forzamos una forma: dejamos actuar el respaldo por tramos.
        if (ruta.Count != 1 ||
            !(ruta[0] is Line))
        {
            return 0;
        }

        Curve curvaGlobal =
            ruta[0];

        Element host =
            cadena.Tramos[0]
                .Datos.Muro;

        return
            CrearRebarsHorizontalesDeCurva(
                doc,
                curvaGlobal,
                host,
                cadena,
                0,
                signo,
                longitudDistribucion,
                espaciamiento,
                conf,
                resultado);
    }


    private int CrearHorizontalesCadenaMixtaPorTramos(
        Document doc,
        CadenaMuros cadena,
        int signo,
        double margenBase,
        double elevacion,
        double longitudDistribucion,
        double espaciamiento,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        double recubrimiento =
            conf != null
                ? ConvertirCm(conf.RecubrimientoCm)
                : 0.0;

        if (doc == null ||
            cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0 ||
            conf == null ||
            conf.TipoHorizontal == null ||
            resultado == null)
        {
            return 0;
        }

        // =====================================================
        // EMPALME LIBRE POR LONGITUD COMERCIAL
        //
        // Primero se intenta una sola ruta de toda la cadena
        // recta. De este modo 9 m significan 9 m desde el inicio
        // de la CADENA, no 9 m desde el inicio de cada muro.
        //
        // Aquí no existe ninguna restricción por tercios.
        // =====================================================
        if (conf.ConsiderarEmpalmeHorizontal)
        {
            int creadosGlobal =
                CrearHorizontalesCadenaRectaConEmpalmeGlobal(
                    doc,
                    cadena,
                    signo,
                    margenBase,
                    elevacion,
                    longitudDistribucion,
                    espaciamiento,
                    conf,
                    resultado);

            if (creadosGlobal > 0)
                return creadosGlobal;
        }

        double ajusteCara =
            ObtenerAjusteCaraPies(
                conf,
                signo);

        double margenCara =
            margenBase +
            ajusteCara;

        TramoCadena primerTramo =
            cadena.Tramos[0];

        TramoCadena ultimoTramo =
            cadena.Tramos[
                cadena.Tramos.Count - 1];

        AceroMuroForm.AceroMuroAjusteTramo
            ajustePrimerTramo =
                ObtenerAjusteTramo(
                    conf,
                    primerTramo.Datos.Muro.Id.Value);

        AceroMuroForm.AceroMuroAjusteTramo
            ajusteUltimoTramo =
                ObtenerAjusteTramo(
                    conf,
                    ultimoTramo.Datos.Muro.Id.Value);

        double retiroInicio =
            margenBase +
            (ajustePrimerTramo != null
                ? ConvertirCm(
                    ajustePrimerTramo.RetiroInicioCm)
                : 0.0);

        double retiroFin =
            margenBase +
            (ajusteUltimoTramo != null
                ? ConvertirCm(
                    ajusteUltimoTramo.RetiroFinCm)
                : 0.0);

        int totalCreados =
            0;

        Curve curvaAnterior =
            null;

        Element hostAnterior =
            null;

        for (int i = 0;
             i < cadena.Tramos.Count;
             i++)
        {
            TramoCadena tramo =
                cadena.Tramos[i];

            if (tramo == null ||
                tramo.Datos == null ||
                tramo.Datos.Muro == null)
            {
                continue;
            }

            double offsetCara;

            if (!TryObtenerOffsetHorizontalDentroNucleo(
                tramo,
                signo,
                recubrimiento,
                conf.CrearVerticales && conf.TipoVertical != null
                    ? ObtenerDiametroBarra(conf.TipoVertical)
                    : 0.0,
                ObtenerDiametroBarra(conf.TipoHorizontal),
                ajusteCara,
                conf.CrearVerticales,
                out offsetCara))
            {
                continue;
            }

            double recorteInicioTramo =
                i == 0
                    ? retiroInicio
                    : 0.0;

            double recorteFinTramo =
                i ==
                    cadena.Tramos.Count - 1
                        ? retiroFin
                        : 0.0;

            // offsetCara ya está referido al núcleo y a la
            // base geométrica usada por CrearCurvaHorizontalOffsetTramo.
            double offsetReal =
                offsetCara;

            Curve curvaActual =
                CrearCurvaHorizontalOffsetTramo(
                    tramo,
                    offsetReal,
                    elevacion,
                    recorteInicioTramo,
                    recorteFinTramo);

            if (curvaActual == null)
                continue;

            // -------------------------------------------------
            // PUENTE ENTRE TRAMOS
            // -------------------------------------------------
            if (curvaAnterior != null)
            {
                XYZ finAnterior =
                    curvaAnterior.GetEndPoint(1);

                XYZ inicioActual =
                    curvaActual.GetEndPoint(0);

                double distancia =
                    finAnterior.DistanceTo(
                        inicioActual);

                // Evita microsegmentos por tolerancias numéricas.
                double minimoPuente =
                    UnitUtils.ConvertToInternalUnits(
                        0.5,
                        UnitTypeId.Millimeters);

                if (distancia >
                    minimoPuente)
                {
                    try
                    {
                        Line puente =
                            Line.CreateBound(
                                finAnterior,
                                inicioActual);

                        Element hostPuente =
                            hostAnterior ??
                            tramo.Datos.Muro;

                        Rebar rebarPuente =
                            CrearRebarDesdeCurvas(
                                doc,
                                hostPuente,
                                conf.TipoHorizontal,
                                XYZ.BasisZ,
                                new List<Curve>
                                {
                                    puente
                                });

                        if (rebarPuente != null)
                        {
                            // Regla nativa de Revit:
                            // ESPACIADO MÁXIMO.
                            AplicarDistribucionMaxima(
                                rebarPuente,
                                espaciamiento,
                                longitudDistribucion);

                            CompletarParametrosMYGMuro(
                                rebarPuente,
                                hostPuente,
                                "Acero horizontal de alma de muro - " +
                                    "Puente de cadena " +
                                    cadena.Numero,
                                "MUR-ALMA-HOR-PUENTE-CAD-" +
                                    cadena.Numero +
                                    "-" +
                                    i);

                            resultado.Horizontales++;
                            resultado.Ids.Add(
                                rebarPuente.Id);

                            totalCreados++;
                        }
                    }
                    catch
                    {
                        // El puente es auxiliar.
                        // Si Revit no lo acepta, seguimos creando
                        // los tramos principales.
                    }
                }
            }

            // -------------------------------------------------
            // TRAMO PRINCIPAL
            //
            // Sin empalme: una sola pieza.
            // Con empalme: se divide por LONGITUD COMERCIAL,
            // manteniendo un traslape geométrico entre piezas.
            // Cada pieza conserva ESPACIADO MÁXIMO en vertical.
            // -------------------------------------------------
            totalCreados +=
                CrearRebarsHorizontalesDeCurva(
                    doc,
                    curvaActual,
                    tramo.Datos.Muro,
                    cadena,
                    i,
                    signo,
                    longitudDistribucion,
                    espaciamiento,
                    conf,
                    resultado);

            curvaAnterior =
                curvaActual;

            hostAnterior =
                tramo.Datos.Muro;
        }

        return totalCreados;
    }


    private List<Curve> ConstruirCurvasHorizontales(
        CadenaMuros cadena,
        int signo,
        double margenBase,
        double elevacion,
        AceroMuroForm.AceroMuroConfiguracion conf,
        ResultadoCreacion resultado)
    {
        double recubrimiento =
            conf != null
                ? ConvertirCm(conf.RecubrimientoCm)
                : 0.0;

        List<Curve> curvas =
            new List<Curve>();

        if (cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return curvas;
        }

        // Si existe al menos un muro curvo, construimos
        // la trayectoria usando la geometría REAL Line/Arc.
        // La vista longitudinal sigue "desenrollada", pero el Rebar
        // en el modelo conserva la curvatura.
        bool contieneCurvos =
            cadena.Tramos.Any(
                x =>
                    x != null &&
                    x.Datos != null &&
                    x.Datos.EsCurvo);

        if (contieneCurvos)
        {
            return ConstruirCurvasHorizontalesConMurosCurvos(
                cadena,
                signo,
                margenBase,
                elevacion,
                conf,
                resultado);
        }

        double ajusteCara =
            ObtenerAjusteCaraPies(
                conf,
                signo);

        double margenCara =
            margenBase +
            ajusteCara;

        List<Tuple<XYZ, XYZ>>
            segmentosOffset =
                new List<Tuple<XYZ, XYZ>>();

        foreach (
            TramoCadena tramo
            in cadena.Tramos)
        {
            double offsetCara;

            if (!TryObtenerOffsetHorizontalDentroNucleo(
                tramo,
                signo,
                recubrimiento,
                conf.CrearVerticales && conf.TipoVertical != null
                    ? ObtenerDiametroBarra(conf.TipoVertical)
                    : 0.0,
                ObtenerDiametroBarra(conf.TipoHorizontal),
                ajusteCara,
                conf.CrearVerticales,
                out offsetCara))
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    tramo.Datos.Muro.Id.Value +
                    ": no se pudo determinar el núcleo para posicionar el acero horizontal.");

                return curvas;
            }

            XYZ direccionTramo =
                Direccion2D(
                    tramo.Inicio,
                    tramo.Fin);

            XYZ normalCadena =
                new XYZ(
                    -direccionTramo.Y,
                    direccionTramo.X,
                    0.0);

            XYZ desplazamiento =
                normalCadena.Multiply(
                    offsetCara);

            XYZ a =
                tramo.Inicio +
                desplazamiento;

            XYZ b =
                tramo.Fin +
                desplazamiento;

            segmentosOffset.Add(
                Tuple.Create(
                    a,
                    b));
        }

        List<XYZ> puntos =
            new List<XYZ>();

        TramoCadena primerTramo =
            cadena.Tramos[0];

        TramoCadena ultimoTramo =
            cadena.Tramos[
                cadena.Tramos.Count - 1];

        AceroMuroForm.AceroMuroAjusteTramo
            ajustePrimerTramo =
                ObtenerAjusteTramo(
                    conf,
                    primerTramo.Datos.Muro.Id.Value);

        AceroMuroForm.AceroMuroAjusteTramo
            ajusteUltimoTramo =
                ObtenerAjusteTramo(
                    conf,
                    ultimoTramo.Datos.Muro.Id.Value);

        double retiroInicio =
            margenBase +
            (ajustePrimerTramo != null
                ? ConvertirCm(
                    ajustePrimerTramo.RetiroInicioCm)
                : 0.0);

        double retiroFin =
            margenBase +
            (ajusteUltimoTramo != null
                ? ConvertirCm(
                    ajusteUltimoTramo.RetiroFinCm)
                : 0.0);

        XYZ primeraDireccion =
            Direccion2D(
                segmentosOffset[0].Item1,
                segmentosOffset[0].Item2);

        XYZ puntoInicial =
            segmentosOffset[0].Item1 +
            primeraDireccion.Multiply(
                retiroInicio);

        puntos.Add(
            new XYZ(
                puntoInicial.X,
                puntoInicial.Y,
                elevacion));

        for (int i = 0;
             i < segmentosOffset.Count - 1;
             i++)
        {
            XYZ interseccion;

            bool ok =
                IntersectarLineasInfinitas2D(
                    segmentosOffset[i].Item1,
                    segmentosOffset[i].Item2,
                    segmentosOffset[i + 1].Item1,
                    segmentosOffset[i + 1].Item2,
                    out interseccion);

            if (!ok)
            {
                XYZ finA =
                    segmentosOffset[i].Item2;

                XYZ inicioB =
                    segmentosOffset[i + 1].Item1;

                interseccion =
                    new XYZ(
                        (finA.X +
                         inicioB.X) * 0.5,
                        (finA.Y +
                         inicioB.Y) * 0.5,
                        0.0);
            }

            XYZ conexionReal =
                ObtenerPuntoConexionCentro(
                    cadena.Tramos[i],
                    cadena.Tramos[i + 1]);

            double distanciaMiter =
                conexionReal != null
                    ? Distancia2D(
                        interseccion,
                        conexionReal)
                    : 0.0;

            double limiteMiter =
                Math.Max(
                    cadena.Tramos[i]
                        .Datos.Espesor,
                    cadena.Tramos[i + 1]
                        .Datos.Espesor) *
                6.0;

            if (conexionReal != null &&
                distanciaMiter >
                    limiteMiter)
            {
                XYZ finA =
                    segmentosOffset[i].Item2;

                XYZ inicioB =
                    segmentosOffset[i + 1].Item1;

                interseccion =
                    new XYZ(
                        (finA.X +
                         inicioB.X) * 0.5,
                        (finA.Y +
                         inicioB.Y) * 0.5,
                        0.0);
            }

            puntos.Add(
                new XYZ(
                    interseccion.X,
                    interseccion.Y,
                    elevacion));
        }

        Tuple<XYZ, XYZ> ultimo =
            segmentosOffset[
                segmentosOffset.Count - 1];

        XYZ ultimaDireccion =
            Direccion2D(
                ultimo.Item1,
                ultimo.Item2);

        XYZ puntoFinal =
            ultimo.Item2 -
            ultimaDireccion.Multiply(
                retiroFin);

        puntos.Add(
            new XYZ(
                puntoFinal.X,
                puntoFinal.Y,
                elevacion));

        puntos =
            SimplificarPuntosCadenaHorizontal(
                puntos);

        for (int i = 0;
             i < puntos.Count - 1;
             i++)
        {
            if (puntos[i].DistanceTo(
                puntos[i + 1]) <= Tol)
            {
                continue;
            }

            curvas.Add(
                Line.CreateBound(
                    puntos[i],
                    puntos[i + 1]));
        }

        return curvas;
    }

    // ---------------------------------------------------------
    // Elimina duplicados y puntos intermedios colineales.
    // Ejemplo:
    //
    // muro 1 ----- [columna] ----- muro 2 ----- [columna] ----- muro 3
    //
    // se convierte en UNA trayectoria continua desde el inicio
    // del primer muro hasta el final del último muro.
    // ---------------------------------------------------------
    private List<Curve>
        ConstruirCurvasHorizontalesConMurosCurvos(
            CadenaMuros cadena,
            int signo,
            double margenBase,
            double elevacion,
            AceroMuroForm.AceroMuroConfiguracion conf,
            ResultadoCreacion resultado)
    {
        double recubrimiento =
            conf != null
                ? ConvertirCm(conf.RecubrimientoCm)
                : 0.0;

        List<Curve> resultadoCurvas =
            new List<Curve>();

        if (cadena == null ||
            cadena.Tramos == null ||
            cadena.Tramos.Count == 0)
        {
            return resultadoCurvas;
        }

        double ajusteCara =
            ObtenerAjusteCaraPies(
                conf,
                signo);

        double margenCara =
            margenBase +
            ajusteCara;

        TramoCadena primerTramo =
            cadena.Tramos[0];

        TramoCadena ultimoTramo =
            cadena.Tramos[
                cadena.Tramos.Count - 1];

        AceroMuroForm.AceroMuroAjusteTramo
            ajustePrimerTramo =
                ObtenerAjusteTramo(
                    conf,
                    primerTramo.Datos.Muro.Id.Value);

        AceroMuroForm.AceroMuroAjusteTramo
            ajusteUltimoTramo =
                ObtenerAjusteTramo(
                    conf,
                    ultimoTramo.Datos.Muro.Id.Value);

        double retiroInicio =
            margenBase +
            (ajustePrimerTramo != null
                ? ConvertirCm(
                    ajustePrimerTramo.RetiroInicioCm)
                : 0.0);

        double retiroFin =
            margenBase +
            (ajusteUltimoTramo != null
                ? ConvertirCm(
                    ajusteUltimoTramo.RetiroFinCm)
                : 0.0);

        Curve curvaAnterior =
            null;

        for (int i = 0;
             i < cadena.Tramos.Count;
             i++)
        {
            TramoCadena tramo =
                cadena.Tramos[i];

            if (tramo == null ||
                tramo.Datos == null)
            {
                continue;
            }

            double offsetCara;

            if (!TryObtenerOffsetHorizontalDentroNucleo(
                tramo,
                signo,
                recubrimiento,
                conf.CrearVerticales && conf.TipoVertical != null
                    ? ObtenerDiametroBarra(conf.TipoVertical)
                    : 0.0,
                ObtenerDiametroBarra(conf.TipoHorizontal),
                ajusteCara,
                conf.CrearVerticales,
                out offsetCara))
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    tramo.Datos.Muro.Id.Value +
                    ": no se pudo determinar el núcleo para posicionar el horizontal curvo.");

                return new List<Curve>();
            }

            double recorteInicioTramo =
                i == 0
                    ? retiroInicio
                    : 0.0;

            double recorteFinTramo =
                i ==
                    cadena.Tramos.Count - 1
                        ? retiroFin
                        : 0.0;

            // offsetCara ya está referido al núcleo y a la
            // base geométrica usada por CrearCurvaHorizontalOffsetTramo.
            double offsetReal =
                offsetCara;

            Curve curvaActual =
                CrearCurvaHorizontalOffsetTramo(
                    tramo,
                    offsetReal,
                    elevacion,
                    recorteInicioTramo,
                    recorteFinTramo);

            if (curvaActual == null)
            {
                resultado.Errores.Add(
                    "Muro ID " +
                    tramo.Datos.Muro.Id.Value +
                    ": no se pudo construir la trayectoria horizontal sobre el muro curvo.");

                return new List<Curve>();
            }

            if (curvaAnterior != null)
            {
                XYZ finAnterior =
                    curvaAnterior.GetEndPoint(1);

                XYZ inicioActual =
                    curvaActual.GetEndPoint(0);

                double distanciaConexion =
                    finAnterior.DistanceTo(
                        inicioActual);

                if (distanciaConexion > Tol)
                {
                    // Atraviesa la columneta/pilar/vacío entre
                    // dos tramos mediante una conexión continua.
                    resultadoCurvas.Add(
                        Line.CreateBound(
                            finAnterior,
                            inicioActual));
                }
            }

            resultadoCurvas.Add(
                curvaActual);

            curvaAnterior =
                curvaActual;
        }

        return resultadoCurvas;
    }


    private List<Curve> ConsolidarCurvasHorizontalesColineales(
        List<Curve> curvas)
    {
        if (curvas == null ||
            curvas.Count <= 1)
        {
            return curvas ??
                new List<Curve>();
        }

        List<Line> lineas =
            curvas
                .OfType<Line>()
                .ToList();

        if (lineas.Count !=
            curvas.Count)
        {
            return curvas;
        }

        XYZ inicio =
            lineas[0]
                .GetEndPoint(0);

        XYZ fin =
            lineas[lineas.Count - 1]
                .GetEndPoint(1);

        XYZ vectorTotal =
            fin - inicio;

        double longitudTotal =
            Longitud2D(
                vectorTotal);

        if (longitudTotal <= Tol)
            return curvas;

        XYZ direccion =
            new XYZ(
                vectorTotal.X / longitudTotal,
                vectorTotal.Y / longitudTotal,
                0.0);

        double toleranciaDistancia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        foreach (
            Line linea
            in lineas)
        {
            XYZ a =
                linea.GetEndPoint(0);

            XYZ b =
                linea.GetEndPoint(1);

            XYZ va =
                a - inicio;

            XYZ vb =
                b - inicio;

            double cruzA =
                System.Math.Abs(
                    va.X * direccion.Y -
                    va.Y * direccion.X);

            double cruzB =
                System.Math.Abs(
                    vb.X * direccion.Y -
                    vb.Y * direccion.X);

            if (cruzA >
                    toleranciaDistancia ||
                cruzB >
                    toleranciaDistancia)
            {
                return curvas;
            }
        }

        try
        {
            return new List<Curve>
            {
                Line.CreateBound(
                    inicio,
                    fin)
            };
        }
        catch
        {
            return curvas;
        }
    }


    private List<XYZ> SimplificarPuntosCadenaHorizontal(
        List<XYZ> puntos)
    {
        List<XYZ> limpios =
            new List<XYZ>();

        if (puntos == null ||
            puntos.Count == 0)
        {
            return limpios;
        }

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            if (limpios.Count == 0 ||
                limpios[limpios.Count - 1]
                    .DistanceTo(p) >
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Millimeters))
            {
                limpios.Add(p);
            }
        }

        if (limpios.Count <= 2)
            return limpios;

        List<XYZ> resultado =
            new List<XYZ>();

        resultado.Add(limpios[0]);

        double toleranciaAngular =
            1e-5;

        for (int i = 1;
             i < limpios.Count - 1;
             i++)
        {
            XYZ anterior =
                resultado[resultado.Count - 1];

            XYZ actual =
                limpios[i];

            XYZ siguiente =
                limpios[i + 1];

            XYZ v1 =
                actual - anterior;

            XYZ v2 =
                siguiente - actual;

            double l1 =
                Longitud2D(v1);

            double l2 =
                Longitud2D(v2);

            if (l1 <= Tol ||
                l2 <= Tol)
            {
                continue;
            }

            XYZ d1 =
                new XYZ(
                    v1.X / l1,
                    v1.Y / l1,
                    0.0);

            XYZ d2 =
                new XYZ(
                    v2.X / l2,
                    v2.Y / l2,
                    0.0);

            double cruz =
                Math.Abs(
                    d1.X * d2.Y -
                    d1.Y * d2.X);

            double punto =
                d1.X * d2.X +
                d1.Y * d2.Y;

            bool colinealesMismoSentido =
                cruz <= toleranciaAngular &&
                punto > 0.9999;

            if (!colinealesMismoSentido)
                resultado.Add(actual);
        }

        resultado.Add(
            limpios[limpios.Count - 1]);

        return resultado;
    }

    private XYZ ObtenerPuntoConexionCentro(
        TramoCadena a,
        TramoCadena b)
    {
        if (a == null || b == null)
            return null;

        XYZ[] aa =
        {
            a.Inicio,
            a.Fin
        };

        XYZ[] bb =
        {
            b.Inicio,
            b.Fin
        };

        double mejor =
            double.MaxValue;

        XYZ mejorA = null;
        XYZ mejorB = null;

        foreach (XYZ pa in aa)
        {
            foreach (XYZ pb in bb)
            {
                double d =
                    Distancia2D(pa, pb);

                if (d < mejor)
                {
                    mejor = d;
                    mejorA = pa;
                    mejorB = pb;
                }
            }
        }

        if (mejorA == null ||
            mejorB == null)
        {
            return null;
        }

        return new XYZ(
            (mejorA.X + mejorB.X) * 0.5,
            (mejorA.Y + mejorB.Y) * 0.5,
            0.0);
    }


    private double ObtenerLongitudCentroRealRebar(
        Rebar rebar)
    {
        if (rebar == null)
            return 0.0;

        IList<Curve> curvas =
            null;

        try
        {
            curvas =
                rebar.GetCenterlineCurves(
                    false,
                    false,
                    false,
                    MultiplanarOption.IncludeOnlyPlanarCurves,
                    0);
        }
        catch
        {
            curvas =
                null;
        }

        if (curvas == null ||
            curvas.Count == 0)
        {
            return 0.0;
        }

        double total =
            0.0;

        foreach (
            Curve curva
            in curvas)
        {
            if (curva != null &&
                curva.IsBound &&
                curva.Length > Tol)
            {
                total +=
                    curva.Length;
            }
        }

        return total;
    }

    private bool ValidarLongitudComercialRealRebar(
        Rebar rebar,
        double longitudComercialMaxima,
        out double longitudReal)
    {
        longitudReal =
            ObtenerLongitudCentroRealRebar(
                rebar);

        if (rebar == null ||
            longitudComercialMaxima <= Tol)
        {
            return false;
        }

        // Si Revit no devolvió centerline no dejamos pasar una pieza
        // sin poder verificarla.
        if (longitudReal <= Tol)
            return false;

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Millimeters);

        return
            longitudReal <=
            longitudComercialMaxima +
            tolerancia;
    }


    private bool RebarTieneQuiebreVisible(
        Rebar rebar)
    {
        if (rebar == null)
            return false;

        IList<Curve> curvas =
            null;

        try
        {
            curvas =
                rebar.GetCenterlineCurves(
                    false,
                    false,
                    false,
                    MultiplanarOption.IncludeOnlyPlanarCurves,
                    0);
        }
        catch
        {
            return false;
        }

        if (curvas == null ||
            curvas.Count < 2)
        {
            return false;
        }

        List<XYZ> direcciones =
            new List<XYZ>();

        foreach (
            Curve curva
            in curvas)
        {
            if (curva == null)
                continue;

            Arc arco =
                curva as Arc;

            if (arco != null &&
                arco.Length > Tol)
            {
                // Una curva real en medio del boceto ya demuestra
                // que Revit no lo convirtió en una única recta.
                return true;
            }

            Line linea =
                curva as Line;

            if (linea == null ||
                linea.Length <= Tol)
            {
                continue;
            }

            XYZ a =
                linea.GetEndPoint(0);

            XYZ b =
                linea.GetEndPoint(1);

            XYZ d =
                new XYZ(
                    b.X - a.X,
                    b.Y - a.Y,
                    0.0);

            if (d.GetLength() <= Tol)
                continue;

            direcciones.Add(
                d.Normalize());
        }

        if (direcciones.Count < 2)
            return false;

        // Buscar al menos dos tramos con direcciones diferentes.
        // Con Ø1/2" y diagonal de 20 cm el ángulo es claramente
        // superior a esta tolerancia.
        double senoMinimo =
            System.Math.Sin(
                0.25 *
                System.Math.PI /
                180.0);

        for (int i = 0;
             i < direcciones.Count;
             i++)
        {
            for (int j = i + 1;
                 j < direcciones.Count;
                 j++)
            {
                XYZ a =
                    direcciones[i];

                XYZ b =
                    direcciones[j];

                double cruzZ =
                    System.Math.Abs(
                        a.X * b.Y -
                        a.Y * b.X);

                if (cruzZ >
                    senoMinimo)
                {
                    return true;
                }
            }
        }

        return false;
    }


    private Rebar CrearRebarDesdeCurvasNuevaFormaExacta(
        Document doc,
        Element host,
        RebarBarType tipo,
        XYZ normal,
        IList<Curve> curvas)
    {
        if (doc == null ||
            host == null ||
            tipo == null ||
            normal == null ||
            normal.GetLength() <= Tol ||
            curvas == null ||
            curvas.Count == 0)
        {
            return null;
        }

        // =====================================================
        // INTENTO 1:
        // FORMA NUEVA EXACTA.
        //
        // Obligatorio para piezas con quiebre.
        // =====================================================
        using (
            SubTransaction sub =
                new SubTransaction(doc))
        {
            sub.Start();

            try
            {
                Rebar rebar;

                using (
                    BarTerminationsData terminaciones =
                        new BarTerminationsData(doc))
                {
                    rebar =
                        Rebar.CreateFromCurves(
                            doc,
                            RebarStyle.Standard,
                            tipo,
                            host,
                            normal.Normalize(),
                            curvas,
                            terminaciones,
                            false,
                            true);
                }

                if (rebar != null)
                {
                    sub.Commit();

                    return rebar;
                }

                sub.RollBack();
            }
            catch
            {
                try
                {
                    if (sub.GetStatus() ==
                        TransactionStatus.Started)
                    {
                        sub.RollBack();
                    }
                }
                catch
                {
                }
            }
        }

        // =====================================================
        // INTENTO 2 SOLO PARA UNA CURVA:
        //
        // PIEZA 1 normalmente queda como una única Line/Arc después
        // de limpiar los segmentos colineales.
        //
        // En ese caso reutilizar una forma existente es SEGURO:
        // no hay diagonal ni quiebre que pueda ser eliminado.
        //
        // Para 2+ curvas NO existe este respaldo; el quiebre debe
        // conservar su forma nueva exacta.
        // =====================================================
        if (curvas.Count != 1)
            return null;

        using (
            SubTransaction sub =
                new SubTransaction(doc))
        {
            sub.Start();

            try
            {
                Rebar rebar;

                using (
                    BarTerminationsData terminaciones =
                        new BarTerminationsData(doc))
                {
                    rebar =
                        Rebar.CreateFromCurves(
                            doc,
                            RebarStyle.Standard,
                            tipo,
                            host,
                            normal.Normalize(),
                            curvas,
                            terminaciones,
                            true,
                            false);
                }

                if (rebar == null)
                {
                    sub.RollBack();

                    return null;
                }

                sub.Commit();

                return rebar;
            }
            catch
            {
                try
                {
                    if (sub.GetStatus() ==
                        TransactionStatus.Started)
                    {
                        sub.RollBack();
                    }
                }
                catch
                {
                }

                return null;
            }
        }
    }


    private Rebar CrearRebarDesdeCurvas(
        Document doc,
        Element host,
        RebarBarType tipo,
        XYZ normal,
        IList<Curve> curvas,
        RebarHookType ganchoInicio = null,
        RebarHookType ganchoFin = null,
        int orientacionGanchoInicio = 0,
        int orientacionGanchoFin = 0)
    {
        if (doc == null ||
            host == null ||
            tipo == null ||
            normal == null ||
            normal.GetLength() <= Tol ||
            curvas == null ||
            curvas.Count == 0)
        {
            return null;
        }

        bool requiereGanchos =
            ganchoInicio != null ||
            ganchoFin != null;

        bool[] usarExistente =
            new bool[]
            {
                true,
                false
            };

        foreach (bool reutilizar in usarExistente)
        {
            using (
                SubTransaction sub =
                    new SubTransaction(doc))
            {
                sub.Start();

                try
                {
                    Rebar rebar;

                    using (
                        BarTerminationsData terminaciones =
                            new BarTerminationsData(doc))
                    {
                        bool okTerminaciones =
                            ConfigurarTerminacionesGanchos(
                                terminaciones,
                                ganchoInicio,
                                ganchoFin,
                                orientacionGanchoInicio,
                                orientacionGanchoFin);

                        if (requiereGanchos &&
                            !okTerminaciones)
                        {
                            throw new InvalidOperationException(
                                "No se pudo configurar el RebarHookType en BarTerminationsData.");
                        }

                        rebar =
                            Rebar.CreateFromCurves(
                                doc,
                                RebarStyle.Standard,
                                tipo,
                                host,
                                normal.Normalize(),
                                curvas,
                                terminaciones,
                                reutilizar,
                                !reutilizar);
                    }

                    if (rebar != null)
                    {
                        sub.Commit();
                        return rebar;
                    }

                    sub.RollBack();
                }
                catch
                {
                    try
                    {
                        if (sub.GetStatus() ==
                            TransactionStatus.Started)
                        {
                            sub.RollBack();
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        if (requiereGanchos)
        {
            Rebar reflejado =
                CrearRebarConGanchosPorReflexion(
                    doc,
                    host,
                    tipo,
                    normal,
                    curvas,
                    ganchoInicio,
                    ganchoFin,
                    orientacionGanchoInicio,
                    orientacionGanchoFin);

            if (reflejado != null)
                return reflejado;
        }

        return null;
    }

    private bool ConfigurarTerminacionesGanchos(
        BarTerminationsData datos,
        RebarHookType ganchoInicio,
        RebarHookType ganchoFin,
        int orientacionInicio,
        int orientacionFin)
    {
        if (datos == null)
            return false;

        bool okInicio =
            ganchoInicio == null ||
            ConfigurarGanchoTerminacion(
                datos,
                true,
                ganchoInicio);

        bool okFin =
            ganchoFin == null ||
            ConfigurarGanchoTerminacion(
                datos,
                false,
                ganchoFin);

        if (ganchoInicio != null &&
            orientacionInicio != 0)
        {
            ConfigurarOrientacionGanchoPorReflexion(
                datos,
                true,
                orientacionInicio);
        }

        if (ganchoFin != null &&
            orientacionFin != 0)
        {
            ConfigurarOrientacionGanchoPorReflexion(
                datos,
                false,
                orientacionFin);
        }

        return
            okInicio &&
            okFin;
    }

    private bool ConfigurarOrientacionGanchoPorReflexion(
        BarTerminationsData datos,
        bool inicio,
        int signo)
    {
        if (datos == null ||
            signo == 0)
        {
            return false;
        }

        System.Type tipo =
            datos.GetType();

        // Propiedades START/END + Orientation.
        try
        {
            foreach (
                System.Reflection.PropertyInfo prop
                in tipo.GetProperties(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance))
            {
                if (!prop.CanWrite ||
                    !prop.PropertyType.IsEnum)
                {
                    continue;
                }

                string nombre =
                    prop.Name ?? "";

                if (nombre.IndexOf(
                        "Orientation",
                        StringComparison.OrdinalIgnoreCase) < 0)
                {
                    continue;
                }

                bool corresponde =
                    inicio
                        ? nombre.IndexOf(
                            "Start",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                          nombre.IndexOf(
                            "Begin",
                            StringComparison.OrdinalIgnoreCase) >= 0
                        : nombre.IndexOf(
                            "End",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                          nombre.IndexOf(
                            "Finish",
                            StringComparison.OrdinalIgnoreCase) >= 0;

                if (!corresponde)
                    continue;

                object valor;

                if (TryObtenerEnumOrientacionGancho(
                    prop.PropertyType,
                    signo,
                    out valor))
                {
                    prop.SetValue(
                        datos,
                        valor,
                        null);

                    return true;
                }
            }
        }
        catch
        {
        }

        // Métodos Set...Hook...Orientation.
        foreach (
            System.Reflection.MethodInfo metodo
            in tipo.GetMethods(
                System.Reflection.BindingFlags.Public |
                System.Reflection.BindingFlags.Instance))
        {
            string nombre =
                metodo.Name ?? "";

            if (nombre.IndexOf(
                    "Set",
                    StringComparison.OrdinalIgnoreCase) < 0 ||
                nombre.IndexOf(
                    "Hook",
                    StringComparison.OrdinalIgnoreCase) < 0 ||
                nombre.IndexOf(
                    "Orientation",
                    StringComparison.OrdinalIgnoreCase) < 0)
            {
                continue;
            }

            System.Reflection.ParameterInfo[] p =
                metodo.GetParameters();

            object[] args =
                new object[p.Length];

            bool tieneOrientacion =
                false;

            bool valido =
                true;

            for (int i = 0;
                 i < p.Length;
                 i++)
            {
                System.Type pt =
                    p[i].ParameterType;

                if (pt.IsEnum)
                {
                    object valor;

                    string nombreParametro =
                        p[i].Name ?? "";

                    if (nombreParametro.IndexOf(
                        "orient",
                        StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        if (!TryObtenerEnumOrientacionGancho(
                            pt,
                            signo,
                            out valor))
                        {
                            valido = false;
                            break;
                        }

                        tieneOrientacion = true;
                    }
                    else
                    {
                        if (!TryObtenerEnumExtremo(
                            pt,
                            inicio,
                            out valor))
                        {
                            if (!TryObtenerEnumOrientacionGancho(
                                pt,
                                signo,
                                out valor))
                            {
                                valido = false;
                                break;
                            }

                            tieneOrientacion = true;
                        }
                    }

                    args[i] = valor;
                }
                else if (pt == typeof(int))
                {
                    args[i] =
                        inicio ? 0 : 1;
                }
                else if (pt == typeof(bool))
                {
                    args[i] =
                        inicio;
                }
                else
                {
                    valido = false;
                    break;
                }
            }

            if (!valido ||
                !tieneOrientacion)
            {
                continue;
            }

            try
            {
                metodo.Invoke(
                    datos,
                    args);

                return true;
            }
            catch
            {
            }
        }

        return false;
    }

    private bool TryObtenerEnumOrientacionGancho(
        System.Type tipoEnum,
        int signo,
        out object valor)
    {
        valor = null;

        if (tipoEnum == null ||
            !tipoEnum.IsEnum ||
            signo == 0)
        {
            return false;
        }

        string[] nombres =
            Enum.GetNames(
                tipoEnum);

        string[] preferidos =
            signo < 0
                ? new string[]
                {
                    "Left",
                    "Negative",
                    "Minus"
                }
                : new string[]
                {
                    "Right",
                    "Positive",
                    "Plus"
                };

        foreach (
            string preferido
            in preferidos)
        {
            foreach (
                string nombre
                in nombres)
            {
                if (nombre.IndexOf(
                    preferido,
                    StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        valor =
                            Enum.Parse(
                                tipoEnum,
                                nombre);

                        return true;
                    }
                    catch
                    {
                    }
                }
            }
        }

        Array valores =
            Enum.GetValues(
                tipoEnum);

        if (valores.Length >= 2)
        {
            valor =
                valores.GetValue(
                    signo < 0
                        ? 0
                        : 1);

            return valor != null;
        }

        return false;
    }

    private bool ConfigurarGanchoTerminacion(
        BarTerminationsData datos,
        bool inicio,
        RebarHookType gancho)
    {
        if (datos == null ||
            gancho == null)
        {
            return true;
        }

        System.Type tipoDatos =
            datos.GetType();

        // -----------------------------------------------------
        // 1) PROPIEDADES ESPECÍFICAS START / END
        // -----------------------------------------------------
        try
        {
            foreach (
                System.Reflection.PropertyInfo prop
                in tipoDatos.GetProperties(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance))
            {
                if (!prop.CanWrite)
                    continue;

                string nombre =
                    prop.Name ?? "";

                if (nombre.IndexOf(
                        "Hook",
                        StringComparison.OrdinalIgnoreCase) < 0)
                {
                    continue;
                }

                bool corresponde =
                    inicio
                        ? nombre.IndexOf(
                            "Start",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                          nombre.IndexOf(
                            "Begin",
                            StringComparison.OrdinalIgnoreCase) >= 0
                        : nombre.IndexOf(
                            "End",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                          nombre.IndexOf(
                            "Finish",
                            StringComparison.OrdinalIgnoreCase) >= 0;

                if (!corresponde)
                    continue;

                if (prop.PropertyType ==
                    typeof(ElementId))
                {
                    prop.SetValue(
                        datos,
                        gancho.Id,
                        null);

                    return true;
                }

                if (prop.PropertyType.IsAssignableFrom(
                    typeof(RebarHookType)))
                {
                    prop.SetValue(
                        datos,
                        gancho,
                        null);

                    return true;
                }
            }
        }
        catch
        {
        }

        // -----------------------------------------------------
        // 2) MÉTODOS SET...HOOK... genéricos o START / END
        // -----------------------------------------------------
        foreach (
            System.Reflection.MethodInfo metodo
            in tipoDatos.GetMethods(
                System.Reflection.BindingFlags.Public |
                System.Reflection.BindingFlags.Instance))
        {
            string nombre =
                metodo.Name ?? "";

            if (nombre.IndexOf(
                    "Set",
                    StringComparison.OrdinalIgnoreCase) < 0 ||
                nombre.IndexOf(
                    "Hook",
                    StringComparison.OrdinalIgnoreCase) < 0 ||
                nombre.IndexOf(
                    "Type",
                    StringComparison.OrdinalIgnoreCase) < 0)
            {
                continue;
            }

            bool nombreStart =
                nombre.IndexOf(
                    "Start",
                    StringComparison.OrdinalIgnoreCase) >= 0 ||
                nombre.IndexOf(
                    "Begin",
                    StringComparison.OrdinalIgnoreCase) >= 0;

            bool nombreEnd =
                nombre.IndexOf(
                    "End",
                    StringComparison.OrdinalIgnoreCase) >= 0 ||
                nombre.IndexOf(
                    "Finish",
                    StringComparison.OrdinalIgnoreCase) >= 0;

            if (nombreStart &&
                !inicio)
            {
                continue;
            }

            if (nombreEnd &&
                inicio)
            {
                continue;
            }

            object[] argumentos;

            if (!ConstruirArgumentosSetterGancho(
                metodo,
                inicio,
                gancho,
                out argumentos))
            {
                continue;
            }

            try
            {
                metodo.Invoke(
                    datos,
                    argumentos);

                return true;
            }
            catch
            {
            }
        }

        return false;
    }

    private bool ConstruirArgumentosSetterGancho(
        System.Reflection.MethodInfo metodo,
        bool inicio,
        RebarHookType gancho,
        out object[] argumentos)
    {
        argumentos = null;

        if (metodo == null ||
            gancho == null)
        {
            return false;
        }

        System.Reflection.ParameterInfo[] parametros =
            metodo.GetParameters();

        object[] args =
            new object[
                parametros.Length];

        bool contieneGancho =
            false;

        for (int i = 0;
             i < parametros.Length;
             i++)
        {
            System.Type pt =
                parametros[i].ParameterType;

            if (pt ==
                typeof(ElementId))
            {
                args[i] =
                    gancho.Id;

                contieneGancho =
                    true;

                continue;
            }

            if (pt.IsAssignableFrom(
                typeof(RebarHookType)))
            {
                args[i] =
                    gancho;

                contieneGancho =
                    true;

                continue;
            }

            if (pt ==
                typeof(int))
            {
                args[i] =
                    inicio
                        ? 0
                        : 1;

                continue;
            }

            if (pt ==
                typeof(bool))
            {
                args[i] =
                    inicio;

                continue;
            }

            if (pt.IsEnum)
            {
                object enumExtremo;

                if (!TryObtenerEnumExtremo(
                    pt,
                    inicio,
                    out enumExtremo))
                {
                    return false;
                }

                args[i] =
                    enumExtremo;

                continue;
            }

            return false;
        }

        if (!contieneGancho)
            return false;

        argumentos =
            args;

        return true;
    }

    private bool TryObtenerEnumExtremo(
        System.Type tipoEnum,
        bool inicio,
        out object valor)
    {
        valor = null;

        if (tipoEnum == null ||
            !tipoEnum.IsEnum)
        {
            return false;
        }

        string[] nombres =
            Enum.GetNames(
                tipoEnum);

        string[] preferidos =
            inicio
                ? new string[]
                {
                    "Start",
                    "Begin",
                    "First",
                    "StartBar",
                    "StartEnd",
                    "BarStart"
                }
                : new string[]
                {
                    "End",
                    "Finish",
                    "Second",
                    "EndBar",
                    "EndEnd",
                    "BarEnd"
                };

        foreach (
            string preferido
            in preferidos)
        {
            foreach (
                string nombre
                in nombres)
            {
                if (nombre.IndexOf(
                    preferido,
                    StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        valor =
                            Enum.Parse(
                                tipoEnum,
                                nombre);

                        return true;
                    }
                    catch
                    {
                    }
                }
            }
        }

        // Respaldo por valor ordinal.
        Array valores =
            Enum.GetValues(
                tipoEnum);

        if (valores.Length >= 2)
        {
            valor =
                valores.GetValue(
                    inicio
                        ? 0
                        : 1);

            return valor != null;
        }

        return false;
    }

    private Rebar CrearRebarConGanchosPorReflexion(
        Document doc,
        Element host,
        RebarBarType tipo,
        XYZ normal,
        IList<Curve> curvas,
        RebarHookType ganchoInicio,
        RebarHookType ganchoFin,
        int orientacionGanchoInicio,
        int orientacionGanchoFin)
    {
        try
        {
            foreach (
                System.Reflection.MethodInfo metodo
                in typeof(Rebar).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Static))
            {
                if (!string.Equals(
                    metodo.Name,
                    "CreateFromCurves",
                    StringComparison.Ordinal))
                {
                    continue;
                }

                System.Reflection.ParameterInfo[] p =
                    metodo.GetParameters();

                int cantidadHookType =
                    p.Count(x =>
                        x.ParameterType ==
                        typeof(RebarHookType));

                if (cantidadHookType < 2)
                    continue;

                object[] args =
                    new object[
                        p.Length];

                int indiceHook = 0;
                int indiceOrientacionHook = 0;
                bool valido = true;

                for (int i = 0;
                     i < p.Length;
                     i++)
                {
                    System.Type pt =
                        p[i].ParameterType;

                    if (pt ==
                        typeof(Document))
                    {
                        args[i] = doc;
                    }
                    else if (pt ==
                        typeof(RebarStyle))
                    {
                        args[i] =
                            RebarStyle.Standard;
                    }
                    else if (pt ==
                        typeof(RebarBarType))
                    {
                        args[i] = tipo;
                    }
                    else if (pt ==
                        typeof(RebarHookType))
                    {
                        args[i] =
                            indiceHook++ == 0
                                ? ganchoInicio
                                : ganchoFin;
                    }
                    else if (pt ==
                        typeof(Element))
                    {
                        args[i] = host;
                    }
                    else if (pt ==
                        typeof(XYZ))
                    {
                        args[i] =
                            normal.Normalize();
                    }
                    else if (
                        typeof(IList<Curve>)
                            .IsAssignableFrom(pt) ||
                        pt.IsAssignableFrom(
                            curvas.GetType()))
                    {
                        args[i] = curvas;
                    }
                    else if (pt ==
                        typeof(bool))
                    {
                        // useExistingShapeIfPossible / createNewShape
                        args[i] =
                            i ==
                            p.Length - 2;
                    }
                    else if (pt ==
                        typeof(double))
                    {
                        args[i] = 0.0;
                    }
                    else if (pt ==
                        typeof(ElementId))
                    {
                        args[i] =
                            ElementId.InvalidElementId;
                    }
                    else if (pt.IsEnum)
                    {
                        string nombreParametro =
                            p[i].Name ?? "";

                        if (nombreParametro.IndexOf(
                            "orient",
                            StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            int signo =
                                indiceOrientacionHook++ == 0
                                    ? orientacionGanchoInicio
                                    : orientacionGanchoFin;

                            object valorOrientacion;

                            if (!TryObtenerEnumOrientacionGancho(
                                pt,
                                signo == 0 ? 1 : signo,
                                out valorOrientacion))
                            {
                                Array valores =
                                    Enum.GetValues(
                                        pt);

                                valorOrientacion =
                                    valores.Length > 0
                                        ? valores.GetValue(0)
                                        : null;
                            }

                            args[i] =
                                valorOrientacion;
                        }
                        else
                        {
                            Array valores =
                                Enum.GetValues(
                                    pt);

                            args[i] =
                                valores.Length > 0
                                    ? valores.GetValue(0)
                                    : null;
                        }
                    }
                    else
                    {
                        valido = false;
                        break;
                    }
                }

                if (!valido)
                    continue;

                object resultado =
                    metodo.Invoke(
                        null,
                        args);

                Rebar rebar =
                    resultado as Rebar;

                if (rebar != null)
                    return rebar;
            }
        }
        catch
        {
        }

        return null;
    }



    private bool AplicarReglaGrupoHorizontalShapeDrivenExacta(
        Rebar rebar,
        AceroMuroForm.AceroMuroGrupoHorizontal2Puntos grupo,
        int cantidad,
        double longitudDistribucion,
        out string detalle)
    {
        detalle =
            "";

        if (rebar == null ||
            grupo == null)
        {
            detalle =
                "Rebar o grupo nulo.";

            return false;
        }

        try
        {
            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            if (accessor == null)
            {
                detalle =
                    "No se pudo obtener RebarShapeDrivenAccessor.";

                return false;
            }

            if (longitudDistribucion <= Tol)
            {
                accessor.SetLayoutAsSingle();

                detalle =
                    "Longitud de distribución nula.";

                return false;
            }

            if (grupo.ReglaDistribucion ==
                AceroMuroForm.AceroMuroReglaDistribucionGrupo.NumeroFijo)
            {
                accessor.SetLayoutAsFixedNumber(
                    System.Math.Max(
                        2,
                        cantidad),
                    longitudDistribucion,
                    true,
                    true,
                    true);

                return true;
            }

            // =================================================
            // ESPACIADO MÁXIMO = INPUT EXACTO DEL GRUPO
            //
            // No usamos cantidad para volver a calcular el paso.
            // Si el input es 10 cm, a la API se le pasa 0.100 m.
            //
            // Para que la propiedad "Espaciado" de Revit no termine
            // como 0.0983 m por repartir el remanente, hacemos que
            // ArrayLength sea un múltiplo entero del input.
            // =================================================
            double espaciadoInput =
                ConvertirCm(
                    System.Math.Max(
                        0.1,
                        grupo.EspaciamientoMaximoCm));

            if (espaciadoInput <= Tol)
            {
                detalle =
                    "Espaciado máximo inválido.";

                return false;
            }

            int intervalos =
                System.Math.Max(
                    1,
                    (int)System.Math.Floor(
                        (longitudDistribucion + Tol) /
                        espaciadoInput));

            double longitudExacta =
                intervalos *
                espaciadoInput;

            if (longitudExacta >
                longitudDistribucion +
                Tol)
            {
                intervalos =
                    System.Math.Max(
                        1,
                        intervalos - 1);

                longitudExacta =
                    intervalos *
                    espaciadoInput;
            }

            if (longitudExacta <= Tol)
            {
                detalle =
                    "No cabe un intervalo completo del espaciado solicitado.";

                return false;
            }

            accessor.SetLayoutAsMaximumSpacing(
                espaciadoInput,
                longitudExacta,
                true,
                true,
                true);

            return true;
        }
        catch (Exception ex)
        {
            detalle =
                ex.Message;

            return false;
        }
    }


    private void AplicarDistribucionNumeroFijo(
        Rebar rebar,
        int cantidad,
        double longitudDistribucion)
    {
        if (rebar == null)
            return;

        try
        {
            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            if (accessor == null)
                return;

            if (longitudDistribucion <= Tol ||
                cantidad <= 1)
            {
                accessor.SetLayoutAsSingle();
                return;
            }

            accessor.SetLayoutAsFixedNumber(
                System.Math.Max(
                    2,
                    cantidad),
                longitudDistribucion,
                true,
                true,
                true);
        }
        catch
        {
        }
    }



    private void AplicarDistribucionMaximaExactaInput(
        Rebar rebar,
        double espaciamientoInput,
        double longitudDistribucionDisponible)
    {
        if (rebar == null)
            return;

        try
        {
            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            if (accessor == null)
                return;

            double esp =
                System.Math.Max(
                    espaciamientoInput,
                    UnitUtils.ConvertToInternalUnits(
                        1.0,
                        UnitTypeId.Millimeters));

            if (longitudDistribucionDisponible <= Tol)
            {
                accessor.SetLayoutAsSingle();
                return;
            }

            // Número de intervalos completos de exactamente "esp".
            //
            // Ejemplo:
            // L disponible = 5.013 m
            // input        = 0.100 m
            //
            // intervalos = floor(5.013 / 0.100) = 50
            // arrayLength = 5.000 m
            //
            // Revit mantiene "Espaciado máximo" y el valor configurado
            // queda exactamente en 0.100 m. El pequeño remanente queda
            // libre en el extremo superior del rango, en lugar de reducir
            // todos los intervalos a 0.0983 m.
            int intervalos =
                System.Math.Max(
                    1,
                    (int)System.Math.Floor(
                        (longitudDistribucionDisponible + Tol) /
                        esp));

            double longitudExacta =
                intervalos *
                esp;

            if (longitudExacta >
                longitudDistribucionDisponible +
                Tol)
            {
                intervalos =
                    System.Math.Max(
                        1,
                        intervalos - 1);

                longitudExacta =
                    intervalos *
                    esp;
            }

            if (longitudExacta <= Tol)
            {
                accessor.SetLayoutAsSingle();
                return;
            }

            accessor.SetLayoutAsMaximumSpacing(
                esp,
                longitudExacta,
                true,
                true,
                true);
        }
        catch
        {
            // Si Revit rechaza el ajuste exacto, no se destruye el Rebar.
        }
    }


    private void AplicarDistribucionMaxima(
        Rebar rebar,
        double espaciamiento,
        double longitudDistribucion)
    {
        if (rebar == null)
            return;

        try
        {
            RebarShapeDrivenAccessor accessor =
                rebar.GetShapeDrivenAccessor();

            if (accessor == null)
                return;

            if (longitudDistribucion <= Tol)
            {
                accessor.SetLayoutAsSingle();
                return;
            }

            double esp =
                Math.Max(
                    espaciamiento,
                    UnitUtils.ConvertToInternalUnits(
                        1.0,
                        UnitTypeId.Millimeters));

            accessor.SetLayoutAsMaximumSpacing(
                esp,
                longitudDistribucion,
                true,
                true,
                true);
        }
        catch
        {
            // Si la forma queda como barra única, se conserva la creación.
        }
    }

    private List<int> ObtenerSignosCaras(
        int modoCaras)
    {
        // 3 = UNA MALLA CENTRADA. Signo 0 significa que no existe
        // desplazamiento respecto al eje central del muro.
        if (modoCaras == 3)
        {
            return new List<int>
            {
                0
            };
        }

        // 0 = DOBLE MALLA, una cortina junto a cada cara.
        return new List<int>
        {
            1,
            -1
        };
    }

    private double ObtenerDiametroBarra(
        RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        Parameter parametro =
            tipo.get_Parameter(
                BuiltInParameter.REBAR_BAR_DIAMETER);

        if (parametro != null &&
            parametro.StorageType ==
            StorageType.Double)
        {
            return parametro.AsDouble();
        }

        parametro =
            tipo.LookupParameter(
                "Diámetro de barra");

        if (parametro != null &&
            parametro.StorageType ==
            StorageType.Double)
        {
            return parametro.AsDouble();
        }

        parametro =
            tipo.LookupParameter(
                "Bar Diameter");

        if (parametro != null &&
            parametro.StorageType ==
            StorageType.Double)
        {
            return parametro.AsDouble();
        }

        return 0.0;
    }

    private string DescribirMuro(
        DatosMuro datos)
    {
        if (datos == null ||
            datos.Muro == null)
        {
            return "";
        }

        return
            "ID " +
            datos.Muro.Id.Value +
            " | " +
            ObtenerNombreMuro(
                datos.Muro) +
            (datos.EsCurvo
                ? " | CURVO"
                : " | RECTO") +
            " | L=" +
            Math.Round(
                UnitUtils.ConvertFromInternalUnits(
                    datos.Longitud,
                    UnitTypeId.Meters),
                2) +
            " m";
    }

    private string ObtenerNombreMuro(
        Wall muro)
    {
        if (muro == null)
            return "Muro";

        Document doc =
            muro.Document;

        WallType tipo =
            doc.GetElement(
                muro.GetTypeId())
            as WallType;

        return tipo != null
            ? tipo.Name
            : "Muro";
    }

    // ================================================================
    // PARÁMETROS DE INSTANCIA MYG - ACERO EN MUROS
    // ================================================================

    private void CompletarParametrosMYGMuro(
        Rebar rebar,
        Element host,
        string tipoAcero,
        string prefijoMarca)
    {
        if (rebar == null)
            return;

        Document doc =
            rebar.Document;

        string clasificacion =
            ObtenerClasificacionAceroMuroMYG(
                tipoAcero,
                prefijoMarca);

        string descripcionHost =
            ObtenerDescripcionTipoHostMYG(
                host);

        string ubicacionHost =
            ObtenerValorParametroMYG(
                host,
                "STR_Ubicación",
                "STR_Ubicacion",
                "STR Ubicación",
                "STR Ubicacion");

        // --------------------------------------------------------
        // GEN_Nivel
        // Se copia EXCLUSIVAMENTE desde el mismo parámetro
        // del elemento anfitrión.
        //
        // No se calcula desde Level, restricción base ni geometría.
        // Si el anfitrión tiene GEN_Nivel vacío, el acero también
        // queda vacío en GEN_Nivel.
        // --------------------------------------------------------
        string nivelHost =
            ObtenerValorParametroMYG(
                host,
                "GEN_Nivel",
                "GEN Nivel");

        // --------------------------------------------------------
        // COMENTARIOS
        // --------------------------------------------------------
        Parameter comentarios =
            rebar.get_Parameter(
                BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

        if (comentarios != null &&
            !comentarios.IsReadOnly)
        {
            TrySetParametroMYG(
                comentarios,
                tipoAcero ?? "",
                doc);
        }

        // --------------------------------------------------------
        // MARCA
        // --------------------------------------------------------
        Parameter marca =
            rebar.get_Parameter(
                BuiltInParameter.ALL_MODEL_MARK);

        if (marca != null &&
            !marca.IsReadOnly)
        {
            string idHost =
                host != null
                    ? host.Id.Value.ToString()
                    : "SIN-HOST";

            TrySetParametroMYG(
                marca,
                (prefijoMarca ?? "MUR-ACERO") +
                    "-" +
                    idHost,
                doc);
        }

        // --------------------------------------------------------
        // EST_Tipo Refuerzo
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "EST_Tipo Refuerzo"
            },
            tipoAcero ?? "");

        // --------------------------------------------------------
        // STR_AnfitriónAcero
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_AnfitriónAcero",
                "STR_AnfitrionAcero",
                "STR_Anfitrión Acero",
                "STR_Anfitrion Acero"
            },
            descripcionHost);

        // --------------------------------------------------------
        // STR_Materialidad
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_Materialidad",
                "STR Materialidad"
            },
            "Acero corrugado");

        // --------------------------------------------------------
        // STR_Resistencia
        //
        // Se conserva exactamente el mismo valor empleado en el
        // Handler de columnas proporcionado por el usuario.
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_Resistencia",
                "STR Resistencia"
            },
            "Fy=4200 kg/cm²");

        // --------------------------------------------------------
        // STR_TipoDeElemento (V/H)
        //
        // Este parámetro recibe únicamente:
        // - "Vertical"
        // - "Horizontal"
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_TipoDeElemento (V/H)",
                "STR_TipoDeElemento",
                "STR TipoDeElemento (V/H)",
                "STR TipoDeElemento"
            },
            clasificacion);

        // --------------------------------------------------------
        // STR_Ubicación
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "STR_Ubicación",
                "STR_Ubicacion",
                "STR Ubicación",
                "STR Ubicacion"
            },
            ubicacionHost);

        // --------------------------------------------------------
        // GEN_Disciplina
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "GEN_Disciplina",
                "GEN Disciplina"
            },
            "Estructuras");

        // --------------------------------------------------------
        // GEN_ID Elemento
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "GEN_ID Elemento",
                "GEN_IDElemento",
                "GEN ID Elemento"
            },
            rebar.Id.Value.ToString());

        // --------------------------------------------------------
        // GEN_Nivel
        // --------------------------------------------------------
        AsignarTodosMYG(
            rebar,
            new string[]
            {
                "GEN_Nivel",
                "GEN Nivel"
            },
            nivelHost);
    }

    private string ObtenerClasificacionAceroMuroMYG(
        string tipoAcero,
        string prefijoMarca)
    {
        string texto =
            ((tipoAcero ?? "") +
             " " +
             (prefijoMarca ?? ""))
                .ToUpperInvariant();

        if (texto.Contains(
            "HORIZONTAL"))
        {
            return "Horizontal";
        }

        if (texto.Contains(
            "VERTICAL"))
        {
            return "Vertical";
        }

        // Respaldo por prefijo usado por este mismo módulo.
        if (texto.Contains(
            "MUR-ALMA-HOR"))
        {
            return "Horizontal";
        }

        if (texto.Contains(
            "MUR-ALMA-VERT"))
        {
            return "Vertical";
        }

        return "";
    }

    private string ObtenerDescripcionTipoHostMYG(
        Element host)
    {
        if (host == null ||
            host.Document == null)
        {
            return "";
        }

        try
        {
            ElementId tipoId =
                host.GetTypeId();

            if (tipoId == null ||
                tipoId ==
                    ElementId.InvalidElementId)
            {
                return "";
            }

            Element tipo =
                host.Document.GetElement(
                    tipoId);

            if (tipo == null)
                return "";

            string descripcion =
                ObtenerValorParametroMYG(
                    tipo,
                    "Descripción",
                    "Descripcion",
                    "Description",
                    "Descripción de la cimentación",
                    "Descripcion de la cimentacion");

            if (!string.IsNullOrWhiteSpace(
                descripcion))
            {
                return
                    descripcion.Trim();
            }

            return
                tipo.Name ?? "";
        }
        catch
        {
            return "";
        }
    }



    private string ObtenerValorParametroMYG(
        Element elemento,
        params string[] nombres)
    {
        if (elemento == null ||
            nombres == null)
        {
            return "";
        }

        HashSet<string> buscados =
            new HashSet<string>(
                nombres.Where(
                    x =>
                        !string.IsNullOrWhiteSpace(
                            x)),
                StringComparer.OrdinalIgnoreCase);

        foreach (
            Parameter p
            in elemento.Parameters)
        {
            if (p == null ||
                p.Definition == null)
            {
                continue;
            }

            if (!buscados.Contains(
                p.Definition.Name))
            {
                continue;
            }

            string valor =
                "";

            try
            {
                valor =
                    p.AsValueString();
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(
                valor))
            {
                try
                {
                    if (p.StorageType ==
                        StorageType.String)
                    {
                        valor =
                            p.AsString();
                    }
                    else if (
                        p.StorageType ==
                        StorageType.Integer)
                    {
                        valor =
                            p.AsInteger()
                                .ToString();
                    }
                    else if (
                        p.StorageType ==
                        StorageType.Double)
                    {
                        valor =
                            p.AsDouble()
                                .ToString(
                                    System.Globalization
                                        .CultureInfo
                                        .InvariantCulture);
                    }
                    else if (
                        p.StorageType ==
                        StorageType.ElementId)
                    {
                        valor =
                            p.AsElementId()
                                .Value
                                .ToString();
                    }
                }
                catch
                {
                    valor =
                        "";
                }
            }

            if (!string.IsNullOrWhiteSpace(
                valor))
            {
                return
                    valor.Trim();
            }
        }

        return "";
    }

    private void AsignarTodosMYG(
        Element elemento,
        IEnumerable<string> nombres,
        string valor)
    {
        if (elemento == null ||
            nombres == null)
        {
            return;
        }

        HashSet<string> buscados =
            new HashSet<string>(
                nombres.Where(
                    x =>
                        !string.IsNullOrWhiteSpace(
                            x)),
                StringComparer.OrdinalIgnoreCase);

        // IMPORTANTE:
        // se recorren TODOS los parámetros del elemento.
        // Si existen parámetros duplicados con el mismo nombre,
        // se llenan todos, igual que en el Handler de columnas.
        foreach (
            Parameter p
            in elemento.Parameters)
        {
            if (p == null ||
                p.Definition == null ||
                p.IsReadOnly ||
                !buscados.Contains(
                    p.Definition.Name))
            {
                continue;
            }

            TrySetParametroMYG(
                p,
                valor ?? "",
                elemento.Document);
        }
    }

    private bool TrySetParametroMYG(
        Parameter parametro,
        string valor,
        Document doc)
    {
        if (parametro == null ||
            parametro.IsReadOnly)
        {
            return false;
        }

        try
        {
            if (parametro.StorageType ==
                StorageType.String)
            {
                return
                    parametro.Set(
                        valor ?? "");
            }

            if (parametro.StorageType ==
                StorageType.Integer)
            {
                int entero;

                return
                    int.TryParse(
                        valor,
                        out entero) &&
                    parametro.Set(
                        entero);
            }

            if (parametro.StorageType ==
                StorageType.Double)
            {
                double numero;

                if (double.TryParse(
                    valor,
                    System.Globalization
                        .NumberStyles.Any,
                    System.Globalization
                        .CultureInfo.CurrentCulture,
                    out numero) ||
                    double.TryParse(
                    valor,
                    System.Globalization
                        .NumberStyles.Any,
                    System.Globalization
                        .CultureInfo.InvariantCulture,
                    out numero))
                {
                    return
                        parametro.Set(
                            numero);
                }

                try
                {
                    return
                        parametro.SetValueString(
                            valor);
                }
                catch
                {
                    return false;
                }
            }

            if (parametro.StorageType ==
                StorageType.ElementId)
            {
                long id;

                return
                    long.TryParse(
                        valor,
                        out id) &&
                    parametro.Set(
                        new ElementId(id));
            }
        }
        catch
        {
        }

        return false;
    }


    private double ConvertirCm(
        double centimetros)
    {
        return UnitUtils.ConvertToInternalUnits(
            centimetros,
            UnitTypeId.Centimeters);
    }

    private double ConvertirMm(
        double milimetros)
    {
        return UnitUtils.ConvertToInternalUnits(
            milimetros,
            UnitTypeId.Millimeters);
    }

    private XYZ ProyectarXY(
        XYZ p)
    {
        return new XYZ(
            p.X,
            p.Y,
            0.0);
    }

    private double Longitud2D(
        XYZ v)
    {
        if (v == null)
            return 0.0;

        return Math.Sqrt(
            v.X * v.X +
            v.Y * v.Y);
    }

    // ================================================================
    // GEOMETRÍA DE TRAMOS RECTOS / CURVOS
    // ================================================================

    private bool TramoEstaInvertido(
        TramoCadena tramo)
    {
        if (tramo == null ||
            tramo.Datos == null)
        {
            return false;
        }

        double dP0 =
            Distancia2D(
                tramo.Inicio,
                tramo.Datos.P0);

        double dP1 =
            Distancia2D(
                tramo.Inicio,
                tramo.Datos.P1);

        return
            dP1 < dP0;
    }

    private double ObtenerLongitudTramo(
        TramoCadena tramo)
    {
        if (tramo == null ||
            tramo.Datos == null)
        {
            return 0.0;
        }

        if (tramo.Datos.Longitud > Tol)
        {
            return
                tramo.Datos.Longitud;
        }

        return
            Distancia2D(
                tramo.Inicio,
                tramo.Fin);
    }

    private double ObtenerParametroNormalizadoTramo(
        TramoCadena tramo,
        double distanciaDesdeInicio)
    {
        double longitud =
            ObtenerLongitudTramo(
                tramo);

        if (longitud <= Tol)
            return 0.0;

        double u =
            distanciaDesdeInicio /
            longitud;

        u =
            System.Math.Max(
                0.0,
                System.Math.Min(
                    1.0,
                    u));

        if (TramoEstaInvertido(
            tramo))
        {
            u =
                1.0 - u;
        }

        return u;
    }

    private XYZ ObtenerPuntoTramoPorDistancia(
        TramoCadena tramo,
        double distanciaDesdeInicio)
    {
        if (tramo == null ||
            tramo.Datos == null ||
            tramo.Datos.CurvaBase == null)
        {
            return
                tramo != null
                    ? tramo.Inicio
                    : XYZ.Zero;
        }

        double parametro =
            ObtenerParametroNormalizadoTramo(
                tramo,
                distanciaDesdeInicio);

        XYZ p;

        try
        {
            p =
                tramo.Datos.CurvaBase.Evaluate(
                    parametro,
                    true);
        }
        catch
        {
            double longitud =
                ObtenerLongitudTramo(
                    tramo);

            double t =
                longitud > Tol
                    ? distanciaDesdeInicio /
                        longitud
                    : 0.0;

            t =
                System.Math.Max(
                    0.0,
                    System.Math.Min(
                        1.0,
                        t));

            p =
                tramo.Inicio +
                (tramo.Fin -
                 tramo.Inicio)
                    .Multiply(t);
        }

        p =
            ProyectarXY(p);

        // -----------------------------------------------------
        // ARC:
        // si conocemos las caras cilíndricas reales, devolvemos
        // el punto sobre el CENTRO GEOMÉTRICO REAL del muro,
        // manteniendo únicamente el ángulo del LocationCurve.
        // -----------------------------------------------------
        if (tramo.Datos.EsCurvo &&
            tramo.Datos.TieneGeometriaRadialReal &&
            tramo.Datos.CentroCurvaturaReal != null &&
            tramo.Datos.RadioCentroReal > Tol)
        {
            XYZ radial =
                new XYZ(
                    p.X -
                        tramo.Datos.CentroCurvaturaReal.X,
                    p.Y -
                        tramo.Datos.CentroCurvaturaReal.Y,
                    0.0);

            if (radial.GetLength() > Tol)
            {
                radial =
                    radial.Normalize();

                return
                    new XYZ(
                        tramo.Datos.CentroCurvaturaReal.X +
                            radial.X *
                            tramo.Datos.RadioCentroReal,
                        tramo.Datos.CentroCurvaturaReal.Y +
                            radial.Y *
                            tramo.Datos.RadioCentroReal,
                        0.0);
            }
        }

        return p;
    }

    private XYZ ObtenerTangenteTramoPorDistancia(
        TramoCadena tramo,
        double distanciaDesdeInicio)
    {
        if (tramo == null ||
            tramo.Datos == null)
        {
            return XYZ.BasisX;
        }

        Curve curva =
            tramo.Datos.CurvaBase;

        if (curva != null)
        {
            try
            {
                double parametro =
                    ObtenerParametroNormalizadoTramo(
                        tramo,
                        distanciaDesdeInicio);

                Transform der =
                    curva.ComputeDerivatives(
                        parametro,
                        true);

                if (der != null &&
                    der.BasisX != null)
                {
                    XYZ t =
                        new XYZ(
                            der.BasisX.X,
                            der.BasisX.Y,
                            0.0);

                    if (TramoEstaInvertido(
                        tramo))
                    {
                        t =
                            t.Multiply(
                                -1.0);
                    }

                    if (t.GetLength() > Tol)
                    {
                        return
                            t.Normalize();
                    }
                }
            }
            catch
            {
            }
        }

        return
            Direccion2D(
                tramo.Inicio,
                tramo.Fin);
    }

    private XYZ ObtenerTangenteTramoEnExtremo(
        TramoCadena tramo,
        bool esInicio)
    {
        double longitud =
            ObtenerLongitudTramo(
                tramo);

        return
            ObtenerTangenteTramoPorDistancia(
                tramo,
                esInicio
                    ? 0.0
                    : longitud);
    }

    private XYZ ObtenerPuntoOffsetTramo(
        TramoCadena tramo,
        double distanciaDesdeInicio,
        double offsetIzquierda,
        double elevacion)
    {
        XYZ p =
            ObtenerPuntoTramoPorDistancia(
                tramo,
                distanciaDesdeInicio);

        XYZ tangente =
            ObtenerTangenteTramoPorDistancia(
                tramo,
                distanciaDesdeInicio);

        XYZ normalIzquierda =
            new XYZ(
                -tangente.Y,
                tangente.X,
                0.0);

        if (normalIzquierda.GetLength() > Tol)
        {
            normalIzquierda =
                normalIzquierda.Normalize();
        }

        XYZ q =
            p +
            normalIzquierda.Multiply(
                offsetIzquierda);

        return
            new XYZ(
                q.X,
                q.Y,
                elevacion);
    }

    private XYZ ObtenerPuntoOffsetTramoExtendido(
        TramoCadena tramo,
        double distanciaDesdeInicio,
        double offsetIzquierda,
        double elevacion)
    {
        if (tramo == null ||
            tramo.Datos == null)
        {
            return XYZ.Zero;
        }

        double longitud =
            ObtenerLongitudTramo(
                tramo);

        if (longitud <= Tol)
        {
            return
                ObtenerPuntoOffsetTramo(
                    tramo,
                    0.0,
                    offsetIzquierda,
                    elevacion);
        }

        if (distanciaDesdeInicio >=
                -Tol &&
            distanciaDesdeInicio <=
                longitud +
                Tol)
        {
            return
                ObtenerPuntoOffsetTramo(
                    tramo,
                    System.Math.Max(
                        0.0,
                        System.Math.Min(
                            longitud,
                            distanciaDesdeInicio)),
                    offsetIzquierda,
                    elevacion);
        }

        bool antes =
            distanciaDesdeInicio <
            0.0;

        double sExtremo =
            antes
                ? 0.0
                : longitud;

        XYZ puntoExtremo =
            ObtenerPuntoOffsetTramo(
                tramo,
                sExtremo,
                offsetIzquierda,
                elevacion);

        XYZ tangente =
            ObtenerTangenteTramoPorDistancia(
                tramo,
                sExtremo);

        if (tangente == null ||
            tangente.GetLength() <= Tol)
        {
            tangente =
                Direccion2D(
                    tramo.Inicio,
                    tramo.Fin);
        }

        tangente =
            tangente.Normalize();

        double delta =
            antes
                ? distanciaDesdeInicio
                : distanciaDesdeInicio -
                    longitud;

        return
            puntoExtremo +
            tangente.Multiply(
                delta);
    }

    private XYZ ObtenerRadialCentroTramoExtendido(
        TramoCadena tramo,
        XYZ centro,
        double radioBase,
        double distanciaDesdeInicio)
    {
        if (tramo == null ||
            centro == null ||
            radioBase <= Tol)
        {
            return XYZ.BasisX;
        }

        XYZ pInicio =
            ObtenerPuntoTramoPorDistancia(
                tramo,
                0.0);

        XYZ radialInicio =
            new XYZ(
                pInicio.X -
                    centro.X,
                pInicio.Y -
                    centro.Y,
                0.0);

        if (radialInicio.GetLength() <= Tol)
            return XYZ.BasisX;

        radialInicio =
            radialInicio.Normalize();

        XYZ tangenteInicio =
            ObtenerTangenteTramoPorDistancia(
                tramo,
                0.0);

        if (tangenteInicio == null ||
            tangenteInicio.GetLength() <= Tol)
        {
            return radialInicio;
        }

        tangenteInicio =
            tangenteInicio.Normalize();

        double cruzZ =
            radialInicio.X *
                tangenteInicio.Y -
            radialInicio.Y *
                tangenteInicio.X;

        double sentido =
            cruzZ >= 0.0
                ? 1.0
                : -1.0;

        double angulo =
            sentido *
            distanciaDesdeInicio /
            radioBase;

        double c =
            System.Math.Cos(
                angulo);

        double s =
            System.Math.Sin(
                angulo);

        XYZ radial =
            new XYZ(
                radialInicio.X * c -
                    radialInicio.Y * s,
                radialInicio.X * s +
                    radialInicio.Y * c,
                0.0);

        if (radial.GetLength() <= Tol)
            return radialInicio;

        return
            radial.Normalize();
    }


    private Curve CrearCurvaHorizontalOffsetTramo(
        TramoCadena tramo,
        double offsetIzquierda,
        double elevacion,
        double retiroInicio,
        double retiroFin)
    {
        if (tramo == null ||
            tramo.Datos == null ||
            tramo.Datos.CurvaBase == null)
        {
            return null;
        }

        double longitud =
            ObtenerLongitudTramo(
                tramo);

        if (longitud <= Tol)
            return null;

        // =====================================================
        // V8.60 - NO CLAMP DE RETIROS
        //
        // Antes:
        // Max(0, retiroInicio) / Max(0, retiroFin)
        //
        // Eso eliminaba cualquier valor negativo proveniente de
        // H inicio / H fin. Por eso la preview sí se extendía,
        // pero la ejecución regresaba al borde del anfitrión.
        //
        // Ahora:
        // retiro < 0  => PROLONGACIÓN real.
        // retiro > 0  => RECORTE real.
        // =====================================================
        double s0 =
            retiroInicio;

        double s1 =
            longitud -
            retiroFin;

        if (s1 -
            s0 <= Tol)
        {
            return null;
        }

        if (!tramo.Datos.EsCurvo)
        {
            XYZ p0 =
                ObtenerPuntoOffsetTramoExtendido(
                    tramo,
                    s0,
                    offsetIzquierda,
                    elevacion);

            XYZ p1 =
                ObtenerPuntoOffsetTramoExtendido(
                    tramo,
                    s1,
                    offsetIzquierda,
                    elevacion);

            if (p0 == null ||
                p1 == null ||
                p0.DistanceTo(
                    p1) <= Tol)
            {
                return null;
            }

            return
                Line.CreateBound(
                    p0,
                    p1);
        }

        Arc arcoOriginal =
            tramo.Datos.CurvaBase
            as Arc;

        if (arcoOriginal == null)
            return null;

        XYZ centro =
            tramo.Datos.TieneGeometriaRadialReal &&
            tramo.Datos.CentroCurvaturaReal != null
                ? tramo.Datos.CentroCurvaturaReal
                : arcoOriginal.Center;

        double radioBase =
            tramo.Datos.TieneGeometriaRadialReal &&
            tramo.Datos.RadioCentroReal > Tol
                ? tramo.Datos.RadioCentroReal
                : arcoOriginal.Radius;

        if (centro == null ||
            radioBase <= Tol)
        {
            return null;
        }

        // Determinar si +offsetIzquierda aumenta o reduce el radio.
        XYZ radialInicio =
            ObtenerRadialCentroTramoExtendido(
                tramo,
                centro,
                radioBase,
                0.0);

        XYZ tangenteInicio =
            ObtenerTangenteTramoPorDistancia(
                tramo,
                0.0);

        XYZ normalIzquierda =
            new XYZ(
                -tangenteInicio.Y,
                tangenteInicio.X,
                0.0);

        if (normalIzquierda.GetLength() <= Tol ||
            radialInicio.GetLength() <= Tol)
        {
            return null;
        }

        normalIzquierda =
            normalIzquierda.Normalize();

        radialInicio =
            radialInicio.Normalize();

        double signoRadial =
            normalIzquierda.DotProduct(
                radialInicio);

        signoRadial =
            signoRadial >= 0.0
                ? 1.0
                : -1.0;

        double radioObjetivo =
            radioBase +
            offsetIzquierda *
            signoRadial;

        if (radioObjetivo <= Tol)
            return null;

        double sMedio =
            (s0 + s1) *
            0.5;

        XYZ radial0 =
            ObtenerRadialCentroTramoExtendido(
                tramo,
                centro,
                radioBase,
                s0);

        XYZ radial1 =
            ObtenerRadialCentroTramoExtendido(
                tramo,
                centro,
                radioBase,
                s1);

        XYZ radialM =
            ObtenerRadialCentroTramoExtendido(
                tramo,
                centro,
                radioBase,
                sMedio);

        XYZ q0 =
            new XYZ(
                centro.X +
                    radial0.X *
                    radioObjetivo,
                centro.Y +
                    radial0.Y *
                    radioObjetivo,
                elevacion);

        XYZ q1 =
            new XYZ(
                centro.X +
                    radial1.X *
                    radioObjetivo,
                centro.Y +
                    radial1.Y *
                    radioObjetivo,
                elevacion);

        XYZ qMedio =
            new XYZ(
                centro.X +
                    radialM.X *
                    radioObjetivo,
                centro.Y +
                    radialM.Y *
                    radioObjetivo,
                elevacion);

        try
        {
            return
                Arc.Create(
                    q0,
                    q1,
                    qMedio);
        }
        catch
        {
            return null;
        }
    }


    private double Distancia2D(
        XYZ a,
        XYZ b)
    {
        if (a == null ||
            b == null)
        {
            return double.MaxValue;
        }

        double dx =
            a.X - b.X;

        double dy =
            a.Y - b.Y;

        return Math.Sqrt(
            dx * dx +
            dy * dy);
    }

    private XYZ Direccion2D(
        XYZ a,
        XYZ b)
    {
        XYZ v =
            b - a;

        double l =
            Longitud2D(v);

        if (l <= Tol)
            return XYZ.BasisX;

        return new XYZ(
            v.X / l,
            v.Y / l,
            0.0);
    }

    private bool IntersectarLineasInfinitas2D(
        XYZ p1,
        XYZ p2,
        XYZ q1,
        XYZ q2,
        out XYZ interseccion)
    {
        interseccion = null;

        double rx =
            p2.X - p1.X;

        double ry =
            p2.Y - p1.Y;

        double sx =
            q2.X - q1.X;

        double sy =
            q2.Y - q1.Y;

        double cruz =
            rx * sy -
            ry * sx;

        if (Math.Abs(cruz) <= 1e-10)
            return false;

        double qpx =
            q1.X - p1.X;

        double qpy =
            q1.Y - p1.Y;

        double t =
            (qpx * sy -
             qpy * sx) /
            cruz;

        interseccion =
            new XYZ(
                p1.X + t * rx,
                p1.Y + t * ry,
                0.0);

        return true;
    }
}
