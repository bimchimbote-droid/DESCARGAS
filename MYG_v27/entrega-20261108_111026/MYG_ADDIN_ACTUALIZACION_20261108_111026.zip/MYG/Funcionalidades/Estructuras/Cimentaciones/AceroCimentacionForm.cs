using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{




    // =====================================
    // VENTANA EMERGENTE 3.3 (ACERO CIMENTACIÓN)
    // =====================================
    public class AceroCimentacionForm : WinForms.Form
    {
        public WinForms.ComboBox cmbTipoArmadura;

        WinForms.ComboBox cmbMallaRefuerzo;

        WinForms.TextBox txtEspaciamiento;
        public WinForms.ComboBox cmbRecubrimiento;

        WinForms.CheckBox chkColocarGancho;
        WinForms.Label lblLongitudGancho;
        WinForms.TextBox txtLongitudGancho;
        WinForms.Label lblCmGancho;

        WinForms.CheckBox chkConsiderarEmpalme;

        WinForms.Label lblLongitudBarra;
        WinForms.TextBox txtLongitudBarra;
        WinForms.Label lblMBarra;

        WinForms.Label lblLongitudEmpalme;
        WinForms.TextBox txtLongitudEmpalme;
        WinForms.Label lblMEmpalme;

        WinForms.CheckBox chkUsarRne;
        WinForms.Label lblFc;
        WinForms.TextBox txtFc;
        WinForms.Label lblKgCm2;
        WinForms.Label lblFy;
        WinForms.TextBox txtFy;
        WinForms.Label lblMpa;
        WinForms.Label lblEmpalmeInferiorRne;
        WinForms.TextBox txtEmpalmeInferiorRne;
        WinForms.Label lblMInfRne;
        WinForms.Label lblEmpalmeSuperiorRne;
        WinForms.TextBox txtEmpalmeSuperiorRne;
        WinForms.Label lblMSupRne;

        WinForms.CheckBox chkCapaSuperiorDiferente;
        WinForms.ComboBox cmbTipoArmaduraSuperior;
        WinForms.Label lblEspaciamientoSuperior;
        WinForms.TextBox txtEspaciamientoSuperior;
        WinForms.Label lblCmSuperior;

        WinForms.Label lblTitulo;
        WinForms.Label lblRecubrimiento;
        WinForms.Label lblMallaRefuerzo;
        WinForms.Label lblTipo;
        WinForms.Label lblEspaciamiento;
        WinForms.Label lblCmInferior;
        WinForms.Label lblCantidad;

        public WinForms.Button btnSeleccionar;
        public WinForms.Button btnEjecutar;

        public ExternalEvent SeleccionarEvent;
        public SeleccionarCimentacionesAceroHandler SeleccionarHandler;

        public ExternalEvent EjecutarEvent;
        public EjecutarAceroCimentacionHandler EjecutarHandler;

        private bool cargandoValores = true;

        // Se recuerdan durante la sesión sin agregar nuevas propiedades a Settings.
        private static bool ultimoConsiderarEmpalme = false;
        private static string ultimaLongitudBarra = "9";
        private static string ultimaLongitudEmpalme = "3";
        private static bool ultimoUsarRne = false;
        private static string ultimoFc = "210";
        private static string ultimoFy = "420";
        private static string ultimoRecubrimientoNombre = "";

        // =====================================
        // ITEMS DE COMBO
        // Se usan wrappers de texto para que WinForms muestre siempre
        // correctamente los elementos y permita búsqueda mientras se escribe.
        // =====================================
        private class ItemTipoArmadura
        {
            public RebarBarType Tipo;
            public string Texto;

            public override string ToString()
            {
                return Texto ?? "";
            }
        }

        private class ItemRecubrimiento
        {
            public RebarCoverType Tipo;
            public string Texto;

            public override string ToString()
            {
                return Texto ?? "";
            }
        }

        public RebarBarType TipoArmaduraSeleccionado
        {
            get { return ObtenerTipoArmaduraDesdeCombo(cmbTipoArmadura); }
        }

        public RebarBarType TipoArmaduraSuperiorSeleccionado
        {
            get
            {
                if (!EsDosMallas)
                    return TipoArmaduraSeleccionado;

                if (!CapaSuperiorDiferente)
                    return TipoArmaduraSeleccionado;

                return ObtenerTipoArmaduraDesdeCombo(cmbTipoArmaduraSuperior);
            }
        }

        public string EspaciamientoTexto
        {
            get { return txtEspaciamiento.Text.Trim(); }
        }

        public RebarCoverType RecubrimientoSeleccionado
        {
            get { return ObtenerRecubrimientoDesdeCombo(); }
        }

        // Se mantiene esta propiedad por compatibilidad con cualquier código externo
        // que todavía consulte el recubrimiento como texto en centímetros.
        public string RecubrimientoTexto
        {
            get
            {
                double cm = ObtenerRecubrimientoSeleccionadoCm();

                if (cm <= 0.0)
                    return "";

                return cm.ToString(
                    "0.###",
                    System.Globalization.CultureInfo.InvariantCulture);
            }
        }

        public bool EsDosMallas
        {
            get
            {
                return cmbMallaRefuerzo != null &&
                       string.Equals(
                           cmbMallaRefuerzo.Text.Trim(),
                           "2 Capas",
                           System.StringComparison.OrdinalIgnoreCase);
            }
        }

        public string MallaRefuerzoTexto
        {
            get
            {
                if (cmbMallaRefuerzo == null ||
                    string.IsNullOrWhiteSpace(cmbMallaRefuerzo.Text))
                {
                    return "1 Capa";
                }

                return cmbMallaRefuerzo.Text.Trim();
            }
        }

        public bool ColocarGancho
        {
            get { return chkColocarGancho.Checked; }
        }

        public string LongitudGanchoTexto
        {
            get { return txtLongitudGancho.Text.Trim(); }
        }

        public bool ConsiderarEmpalme
        {
            get { return chkConsiderarEmpalme.Checked; }
        }

        public string LongitudBarraTexto
        {
            get { return txtLongitudBarra.Text.Trim(); }
        }

        public string LongitudEmpalmeTexto
        {
            get { return txtLongitudEmpalme.Text.Trim(); }
        }

        public bool UsarRNE
        {
            get { return chkUsarRne.Checked && ConsiderarEmpalme; }
        }

        public string FcTexto
        {
            get { return txtFc.Text.Trim(); }
        }

        public string FyTexto
        {
            get { return txtFy.Text.Trim(); }
        }

        public string LongitudEmpalmeInferiorRNETexto
        {
            get { return txtEmpalmeInferiorRne.Text.Trim(); }
        }

        public string LongitudEmpalmeSuperiorRNETexto
        {
            get
            {
                if (!EsDosMallas)
                    return txtEmpalmeInferiorRne.Text.Trim();

                return txtEmpalmeSuperiorRne.Text.Trim();
            }
        }

        public bool CapaSuperiorDiferente
        {
            get { return chkCapaSuperiorDiferente.Checked && EsDosMallas; }
        }

        public string EspaciamientoSuperiorTexto
        {
            get
            {
                if (!EsDosMallas)
                    return txtEspaciamiento.Text.Trim();

                if (!CapaSuperiorDiferente)
                    return txtEspaciamiento.Text.Trim();

                return txtEspaciamientoSuperior.Text.Trim();
            }
        }

        public AceroCimentacionForm()
        {
            this.Text = "MYG - Acero en Cimentación";
            this.Width = 420;
            this.Height = 430;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // ===== AUTOR =====
            lblTitulo = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 12,
                Width = 360,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            // ===== RECUBRIMIENTO =====
            lblRecubrimiento = new WinForms.Label()
            {
                Text = "Recubrimiento:",
                Width = 115,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            cmbRecubrimiento = new WinForms.ComboBox()
            {
                Width = 240,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = WinForms.AutoCompleteSource.ListItems,
                MaxDropDownItems = 12,
                IntegralHeight = false
            };

            cmbRecubrimiento.SelectedIndexChanged += (s, e) =>
            {
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            // Al salir del campo, si el usuario escribió el nombre completo,
            // se fuerza la selección del elemento real.
            cmbRecubrimiento.Leave += (s, e) =>
            {
                ResolverTextoRecubrimiento();
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            // ===== MALLA REFUERZO =====
            lblMallaRefuerzo = new WinForms.Label()
            {
                Text = "Malla Refuerzo:",
                Width = 115,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            cmbMallaRefuerzo = new WinForms.ComboBox()
            {
                Width = 240,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = WinForms.AutoCompleteSource.ListItems,
                MaxDropDownItems = 2,
                IntegralHeight = false
            };

            cmbMallaRefuerzo.Items.Add("1 Capa");
            cmbMallaRefuerzo.Items.Add("2 Capas");

            if (!SeleccionarComboPorTexto(cmbMallaRefuerzo, MYG.Properties.Settings.Default.V33MallaRefuerzo))
                cmbMallaRefuerzo.SelectedIndex = 0;

            cmbMallaRefuerzo.SelectedIndexChanged += (s, e) =>
            {
                ActualizarEstadoCapaSuperior();
                ActualizarVisibilidadEmpalme();
                ActualizarResultadosRne();
                ReubicarControles();
                GuardarValoresRecordados();
            };

            // ===== TIPO DE ARMADURA =====
            lblTipo = new WinForms.Label()
            {
                Text = "Tipo Barra:",
                Width = 115,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            cmbTipoArmadura = new WinForms.ComboBox()
            {
                Width = 240,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = WinForms.AutoCompleteSource.ListItems,
                MaxDropDownItems = 10,
                IntegralHeight = false
            };

            cmbTipoArmadura.SelectedIndexChanged += (s, e) =>
            {
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            // ===== GANCHO =====
            chkColocarGancho = new WinForms.CheckBox()
            {
                Text = "Colocar Gancho",
                Width = 150,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Checked = MYG.Properties.Settings.Default.V33ColocarGancho
            };

            chkColocarGancho.CheckedChanged += (s, e) =>
            {
                lblLongitudGancho.Visible = chkColocarGancho.Checked;
                txtLongitudGancho.Visible = chkColocarGancho.Checked;
                lblCmGancho.Visible = chkColocarGancho.Checked;
                ReubicarControles();
                GuardarValoresRecordados();
            };

            lblLongitudGancho = new WinForms.Label()
            {
                Text = "Long. Gancho:",
                Width = 115,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                Visible = chkColocarGancho.Checked
            };

            txtLongitudGancho = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = MYG.Properties.Settings.Default.V33LongitudGancho,
                Visible = chkColocarGancho.Checked
            };

            txtLongitudGancho.TextChanged += (s, e) =>
            {
                GuardarValoresRecordados();
            };

            lblCmGancho = new WinForms.Label()
            {
                Text = "cm",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray,
                Visible = chkColocarGancho.Checked
            };

            // ===== EMPALME =====
            chkConsiderarEmpalme = new WinForms.CheckBox()
            {
                Text = "Considerar empalme",
                Width = 175,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Checked = ultimoConsiderarEmpalme
            };

            chkConsiderarEmpalme.CheckedChanged += (s, e) =>
            {
                ActualizarVisibilidadEmpalme();
                ActualizarResultadosRne();
                ReubicarControles();
                GuardarValoresRecordados();
            };

            // ===== LONGITUD COMERCIAL DE BARRA =====
            lblLongitudBarra = new WinForms.Label()
            {
                Text = "Longitud de barra:",
                Width = 155,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                Visible = chkConsiderarEmpalme.Checked
            };

            txtLongitudBarra = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = string.IsNullOrWhiteSpace(ultimaLongitudBarra)
                    ? "9"
                    : ultimaLongitudBarra,
                Visible = chkConsiderarEmpalme.Checked
            };

            txtLongitudBarra.TextChanged += (s, e) =>
            {
                GuardarValoresRecordados();
            };

            lblMBarra = new WinForms.Label()
            {
                Text = "m",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray,
                Visible = chkConsiderarEmpalme.Checked
            };

            // ===== LONGITUD DE TRASLAPE =====
            lblLongitudEmpalme = new WinForms.Label()
            {
                Text = "Longitud de empalme:",
                Width = 155,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                Visible = chkConsiderarEmpalme.Checked
            };

            txtLongitudEmpalme = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = string.IsNullOrWhiteSpace(ultimaLongitudEmpalme)
                    ? "3"
                    : ultimaLongitudEmpalme,
                Visible = chkConsiderarEmpalme.Checked
            };

            txtLongitudEmpalme.TextChanged += (s, e) =>
            {
                GuardarValoresRecordados();
            };

            lblMEmpalme = new WinForms.Label()
            {
                Text = "m",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray,
                Visible = chkConsiderarEmpalme.Checked
            };

            // ===== USAR RNE E.060 =====
            chkUsarRne = new WinForms.CheckBox()
            {
                Text = "Usar RNE E.060",
                Width = 175,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 100, 175),
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Checked = ultimoUsarRne,
                Visible = chkConsiderarEmpalme.Checked
            };

            chkUsarRne.CheckedChanged += (s, e) =>
            {
                ActualizarVisibilidadEmpalme();
                ActualizarResultadosRne();
                ReubicarControles();
                GuardarValoresRecordados();
            };

            lblFc = new WinForms.Label()
            {
                Text = "f'c:",
                Width = 155,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtFc = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = string.IsNullOrWhiteSpace(ultimoFc) ? "210" : ultimoFc
            };

            txtFc.TextChanged += (s, e) =>
            {
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            lblKgCm2 = new WinForms.Label()
            {
                Text = "kg/cm²",
                Width = 60,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray
            };

            lblFy = new WinForms.Label()
            {
                Text = "fy:",
                Width = 155,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtFy = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = string.IsNullOrWhiteSpace(ultimoFy) ? "420" : ultimoFy
            };

            txtFy.TextChanged += (s, e) =>
            {
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            lblMpa = new WinForms.Label()
            {
                Text = "MPa",
                Width = 45,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray
            };

            lblEmpalmeInferiorRne = new WinForms.Label()
            {
                Text = "Empalme inferior RNE:",
                Width = 155,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtEmpalmeInferiorRne = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                ReadOnly = true,
                BackColor = Drawing.Color.White,
                TextAlign = WinForms.HorizontalAlignment.Center
            };

            lblMInfRne = new WinForms.Label()
            {
                Text = "m",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray
            };

            lblEmpalmeSuperiorRne = new WinForms.Label()
            {
                Text = "Empalme superior RNE:",
                Width = 155,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtEmpalmeSuperiorRne = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                ReadOnly = true,
                BackColor = Drawing.Color.White,
                TextAlign = WinForms.HorizontalAlignment.Center
            };

            lblMSupRne = new WinForms.Label()
            {
                Text = "m",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray
            };

            // ===== ESPACIAMIENTO INFERIOR =====
            lblEspaciamiento = new WinForms.Label()
            {
                Text = "Espaciado:",
                Width = 115,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtEspaciamiento = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = MYG.Properties.Settings.Default.V33EspaciadoInferior
            };

            txtEspaciamiento.TextChanged += (s, e) =>
            {
                if (!CapaSuperiorDiferente)
                    txtEspaciamientoSuperior.Text = txtEspaciamiento.Text;

                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            lblCmInferior = new WinForms.Label()
            {
                Text = "cm",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray
            };

            // ===== CAPA SUPERIOR DIFERENTE =====
            chkCapaSuperiorDiferente = new WinForms.CheckBox()
            {
                Text = "Capa Superior Diferente",
                Width = 170,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.3F),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Checked = MYG.Properties.Settings.Default.V33CapaSupDiferente,
                Enabled = false
            };

            chkCapaSuperiorDiferente.CheckedChanged += (s, e) =>
            {
                ActualizarEstadoCapaSuperior();
                ActualizarResultadosRne();
                ReubicarControles();
                GuardarValoresRecordados();
            };

            lblEspaciamientoSuperior = new WinForms.Label()
            {
                Text = "Espaciado:",
                Width = 75,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                Enabled = false
            };

            txtEspaciamientoSuperior = new WinForms.TextBox()
            {
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = MYG.Properties.Settings.Default.V33EspaciadoSuperior,
                Enabled = false
            };

            txtEspaciamientoSuperior.TextChanged += (s, e) =>
            {
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            lblCmSuperior = new WinForms.Label()
            {
                Text = "cm",
                Width = 35,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray,
                Enabled = false
            };

            cmbTipoArmaduraSuperior = new WinForms.ComboBox()
            {
                Width = 360,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = WinForms.AutoCompleteSource.ListItems,
                MaxDropDownItems = 10,
                IntegralHeight = false,
                Enabled = false
            };

            cmbTipoArmaduraSuperior.SelectedIndexChanged += (s, e) =>
            {
                ActualizarResultadosRne();
                GuardarValoresRecordados();
            };

            // ===== BOTON SELECCIONAR =====
            btnSeleccionar = new WinForms.Button()
            {
                Text = "SELECCIONAR CIMENTACIONES",
                Width = 360,
                Height = 32,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionar.FlatAppearance.BorderSize = 0;

            btnSeleccionar.Click += (s, e) =>
            {
                GuardarValoresRecordados();
                SeleccionarEvent?.Raise();
            };

            // ===== CANTIDAD =====
            lblCantidad = new WinForms.Label()
            {
                Text = "Cimentaciones seleccionadas: 0",
                Width = 360,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            // ===== BOTON EJECUTAR =====
            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Width = 180,
                Height = 32,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;
            btnEjecutar.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnEjecutar.Click += (s, e) =>
            {
                if (cmbTipoArmadura.SelectedItem == null)
                {
                    WinForms.MessageBox.Show(
                        "Debe seleccionar un tipo de armadura estructural.",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);

                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEspaciamiento.Text))
                {
                    WinForms.MessageBox.Show(
                        "Debe ingresar el espaciamiento de la malla inferior en centímetros.",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);

                    return;
                }

                if (cmbRecubrimiento.SelectedItem == null)
                {
                    WinForms.MessageBox.Show(
                        "Debe seleccionar un recubrimiento de armadura configurado en Revit.",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);

                    return;
                }

                if (chkColocarGancho.Checked && string.IsNullOrWhiteSpace(txtLongitudGancho.Text))
                {
                    WinForms.MessageBox.Show(
                        "Debe ingresar la longitud del gancho en centímetros.",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);

                    return;
                }

                if (chkConsiderarEmpalme.Checked)
                {
                    if (string.IsNullOrWhiteSpace(txtLongitudBarra.Text))
                    {
                        WinForms.MessageBox.Show(
                            "Debe ingresar la longitud de barra en metros.",
                            "MYG",
                            WinForms.MessageBoxButtons.OK,
                            WinForms.MessageBoxIcon.Warning);

                        return;
                    }

                    if (chkUsarRne.Checked)
                    {
                        ActualizarResultadosRne();

                        if (string.IsNullOrWhiteSpace(txtFc.Text) ||
                            string.IsNullOrWhiteSpace(txtFy.Text) ||
                            string.IsNullOrWhiteSpace(txtEmpalmeInferiorRne.Text) ||
                            (EsDosMallas && string.IsNullOrWhiteSpace(txtEmpalmeSuperiorRne.Text)))
                        {
                            WinForms.MessageBox.Show(
                                "No se pudo calcular el empalme según RNE E.060. Revise f'c, fy, recubrimiento, espaciamientos y tipos de barra.",
                                "MYG",
                                WinForms.MessageBoxButtons.OK,
                                WinForms.MessageBoxIcon.Warning);

                            return;
                        }
                    }
                    else if (string.IsNullOrWhiteSpace(txtLongitudEmpalme.Text))
                    {
                        WinForms.MessageBox.Show(
                            "Debe ingresar la longitud de empalme en metros.",
                            "MYG",
                            WinForms.MessageBoxButtons.OK,
                            WinForms.MessageBoxIcon.Warning);

                        return;
                    }
                }

                if (EsDosMallas && CapaSuperiorDiferente)
                {
                    if (cmbTipoArmaduraSuperior.SelectedItem == null)
                    {
                        WinForms.MessageBox.Show(
                            "Debe seleccionar el tipo de armadura para la capa superior.",
                            "MYG",
                            WinForms.MessageBoxButtons.OK,
                            WinForms.MessageBoxIcon.Warning);

                        return;
                    }

                    if (string.IsNullOrWhiteSpace(txtEspaciamientoSuperior.Text))
                    {
                        WinForms.MessageBox.Show(
                            "Debe ingresar el espaciamiento de la capa superior en centímetros.",
                            "MYG",
                            WinForms.MessageBoxButtons.OK,
                            WinForms.MessageBoxIcon.Warning);

                        return;
                    }
                }

                GuardarValoresRecordados();
                EjecutarEvent?.Raise();
            };

            this.FormClosing += (s, e) =>
            {
                GuardarValoresRecordados();
            };

            this.AcceptButton = btnEjecutar;

            // ===== AGREGAR CONTROLES =====
            Controls.Add(lblTitulo);

            Controls.Add(lblRecubrimiento);
            Controls.Add(cmbRecubrimiento);

            Controls.Add(lblMallaRefuerzo);
            Controls.Add(cmbMallaRefuerzo);

            Controls.Add(lblTipo);
            Controls.Add(cmbTipoArmadura);

            Controls.Add(chkColocarGancho);

            Controls.Add(lblLongitudGancho);
            Controls.Add(txtLongitudGancho);
            Controls.Add(lblCmGancho);

            Controls.Add(chkConsiderarEmpalme);

            Controls.Add(lblLongitudBarra);
            Controls.Add(txtLongitudBarra);
            Controls.Add(lblMBarra);

            Controls.Add(lblLongitudEmpalme);
            Controls.Add(txtLongitudEmpalme);
            Controls.Add(lblMEmpalme);

            Controls.Add(chkUsarRne);
            Controls.Add(lblFc);
            Controls.Add(txtFc);
            Controls.Add(lblKgCm2);
            Controls.Add(lblFy);
            Controls.Add(txtFy);
            Controls.Add(lblMpa);
            Controls.Add(lblEmpalmeInferiorRne);
            Controls.Add(txtEmpalmeInferiorRne);
            Controls.Add(lblMInfRne);
            Controls.Add(lblEmpalmeSuperiorRne);
            Controls.Add(txtEmpalmeSuperiorRne);
            Controls.Add(lblMSupRne);

            Controls.Add(lblEspaciamiento);
            Controls.Add(txtEspaciamiento);
            Controls.Add(lblCmInferior);

            Controls.Add(chkCapaSuperiorDiferente);
            Controls.Add(lblEspaciamientoSuperior);
            Controls.Add(txtEspaciamientoSuperior);
            Controls.Add(lblCmSuperior);
            Controls.Add(cmbTipoArmaduraSuperior);

            Controls.Add(btnSeleccionar);
            Controls.Add(lblCantidad);
            Controls.Add(btnEjecutar);

            cargandoValores = false;

            ActualizarEstadoCapaSuperior();
            ActualizarVisibilidadEmpalme();
            ActualizarResultadosRne();
            ReubicarControles();
        }

        private void ReubicarControles()
        {
            int labelX = 20;
            int controlX = 140;
            int y = 14;
            int row = 29;

            lblTitulo.Left = labelX;
            lblTitulo.Top = y;
            y += 28;

            lblRecubrimiento.Left = labelX;
            lblRecubrimiento.Top = y + 3;
            cmbRecubrimiento.Left = controlX;
            cmbRecubrimiento.Top = y;
            y += row;

            lblMallaRefuerzo.Left = labelX;
            lblMallaRefuerzo.Top = y + 3;
            cmbMallaRefuerzo.Left = controlX;
            cmbMallaRefuerzo.Top = y;
            y += row;

            lblTipo.Left = labelX;
            lblTipo.Top = y + 3;
            cmbTipoArmadura.Left = controlX;
            cmbTipoArmadura.Top = y;
            y += row;

            chkColocarGancho.Left = labelX;
            chkColocarGancho.Top = y + 1;
            y += row;

            if (chkColocarGancho.Checked)
            {
                lblLongitudGancho.Left = labelX;
                lblLongitudGancho.Top = y + 3;

                txtLongitudGancho.Left = controlX;
                txtLongitudGancho.Top = y;

                lblCmGancho.Left = controlX + 62;
                lblCmGancho.Top = y + 4;

                y += row;
            }

            chkConsiderarEmpalme.Left = labelX;
            chkConsiderarEmpalme.Top = y + 1;
            y += row;

            if (chkConsiderarEmpalme.Checked)
            {
                lblLongitudBarra.Left = labelX;
                lblLongitudBarra.Top = y + 3;

                txtLongitudBarra.Left = 180;
                txtLongitudBarra.Top = y;

                lblMBarra.Left = 242;
                lblMBarra.Top = y + 4;

                y += row;

                chkUsarRne.Left = labelX;
                chkUsarRne.Top = y + 1;
                y += row;

                if (chkUsarRne.Checked)
                {
                    lblFc.Left = labelX;
                    lblFc.Top = y + 3;
                    txtFc.Left = 180;
                    txtFc.Top = y;
                    lblKgCm2.Left = 242;
                    lblKgCm2.Top = y + 4;
                    y += row;

                    lblFy.Left = labelX;
                    lblFy.Top = y + 3;
                    txtFy.Left = 180;
                    txtFy.Top = y;
                    lblMpa.Left = 242;
                    lblMpa.Top = y + 4;
                    y += row;

                    lblEmpalmeInferiorRne.Left = labelX;
                    lblEmpalmeInferiorRne.Top = y + 3;
                    txtEmpalmeInferiorRne.Left = 180;
                    txtEmpalmeInferiorRne.Top = y;
                    lblMInfRne.Left = 242;
                    lblMInfRne.Top = y + 4;
                    y += row;

                    if (EsDosMallas)
                    {
                        lblEmpalmeSuperiorRne.Left = labelX;
                        lblEmpalmeSuperiorRne.Top = y + 3;
                        txtEmpalmeSuperiorRne.Left = 180;
                        txtEmpalmeSuperiorRne.Top = y;
                        lblMSupRne.Left = 242;
                        lblMSupRne.Top = y + 4;
                        y += row;
                    }
                }
                else
                {
                    lblLongitudEmpalme.Left = labelX;
                    lblLongitudEmpalme.Top = y + 3;

                    txtLongitudEmpalme.Left = 180;
                    txtLongitudEmpalme.Top = y;

                    lblMEmpalme.Left = 242;
                    lblMEmpalme.Top = y + 4;

                    y += row;
                }
            }

            lblEspaciamiento.Left = labelX;
            lblEspaciamiento.Top = y + 3;

            txtEspaciamiento.Left = controlX;
            txtEspaciamiento.Top = y;

            lblCmInferior.Left = controlX + 62;
            lblCmInferior.Top = y + 4;

            y += row;

            chkCapaSuperiorDiferente.Left = labelX;
            chkCapaSuperiorDiferente.Top = y + 1;

            lblEspaciamientoSuperior.Left = 205;
            lblEspaciamientoSuperior.Top = y + 3;

            txtEspaciamientoSuperior.Left = 285;
            txtEspaciamientoSuperior.Top = y;

            lblCmSuperior.Left = 345;
            lblCmSuperior.Top = y + 4;

            y += row;

            cmbTipoArmaduraSuperior.Left = labelX;
            cmbTipoArmaduraSuperior.Top = y;
            y += row + 10;

            btnSeleccionar.Left = labelX;
            btnSeleccionar.Top = y;
            y += 39;

            lblCantidad.Left = labelX;
            lblCantidad.Top = y + 2;
            y += 28;

            btnEjecutar.Left = 110;
            btnEjecutar.Top = y;
            y += 48;

            this.ClientSize = new Drawing.Size(400, y);
        }

        private void ActualizarEstadoCapaSuperior()
        {
            bool esDosMallas = EsDosMallas;

            chkCapaSuperiorDiferente.Enabled = esDosMallas;

            if (!esDosMallas)
            {
                chkCapaSuperiorDiferente.Checked = false;
            }

            bool habilitarSuperior = esDosMallas && chkCapaSuperiorDiferente.Checked;

            lblEspaciamientoSuperior.Enabled = habilitarSuperior;
            txtEspaciamientoSuperior.Enabled = habilitarSuperior;
            lblCmSuperior.Enabled = habilitarSuperior;
            cmbTipoArmaduraSuperior.Enabled = habilitarSuperior;

            if (!habilitarSuperior)
            {
                txtEspaciamientoSuperior.Text = txtEspaciamiento.Text;
            }

            ActualizarVisibilidadEmpalme();
            ActualizarResultadosRne();
        }

        // =====================================
        // CARGAR RECUBRIMIENTOS CONFIGURADOS EN REVIT
        // =====================================
        public void CargarRecubrimientos(List<RebarCoverType> tipos)
        {
            bool estabaCargando = cargandoValores;
            cargandoValores = true;

            cmbRecubrimiento.Items.Clear();

            if (tipos != null)
            {
                foreach (RebarCoverType tipo in tipos)
                {
                    double mm = ObtenerDistanciaRecubrimientoMm(tipo);

                    string texto = mm > 0.0
                        ? tipo.Name + "  <" + mm.ToString(
                            "0.##",
                            System.Globalization.CultureInfo.InvariantCulture) + " mm>"
                        : tipo.Name;

                    cmbRecubrimiento.Items.Add(new ItemRecubrimiento()
                    {
                        Tipo = tipo,
                        Texto = texto
                    });
                }
            }

            string nombreRecordado = ultimoRecubrimientoNombre;

            if (string.IsNullOrWhiteSpace(nombreRecordado))
            {
                try
                {
                    nombreRecordado = MYG.Properties.Settings.Default.V33Recubrimiento;
                }
                catch
                {
                    nombreRecordado = "";
                }
            }

            if (!SeleccionarComboPorTexto(cmbRecubrimiento, nombreRecordado))
            {
                if (cmbRecubrimiento.Items.Count > 0)
                    cmbRecubrimiento.SelectedIndex = 0;
            }

            cargandoValores = estabaCargando;

            ActualizarResultadosRne();
            ReubicarControles();
        }

        public void CargarTiposArmadura(List<RebarBarType> tipos)
        {
            bool estabaCargando = cargandoValores;
            cargandoValores = true;

            cmbTipoArmadura.Items.Clear();
            cmbTipoArmaduraSuperior.Items.Clear();

            if (tipos != null)
            {
                foreach (RebarBarType tipo in tipos)
                {
                    ItemTipoArmadura itemInferior = new ItemTipoArmadura()
                    {
                        Tipo = tipo,
                        Texto = tipo.Name
                    };

                    ItemTipoArmadura itemSuperior = new ItemTipoArmadura()
                    {
                        Tipo = tipo,
                        Texto = tipo.Name
                    };

                    cmbTipoArmadura.Items.Add(itemInferior);
                    cmbTipoArmaduraSuperior.Items.Add(itemSuperior);
                }
            }

            string ultimoTipoInferior = MYG.Properties.Settings.Default.V33TipoInferior;
            string ultimoTipoSuperior = MYG.Properties.Settings.Default.V33TipoSuperior;

            if (!SeleccionarComboPorTexto(cmbTipoArmadura, ultimoTipoInferior))
            {
                if (cmbTipoArmadura.Items.Count > 0)
                    cmbTipoArmadura.SelectedIndex = 0;
            }

            if (!SeleccionarComboPorTexto(cmbTipoArmaduraSuperior, ultimoTipoSuperior))
            {
                if (cmbTipoArmaduraSuperior.Items.Count > 0)
                    cmbTipoArmaduraSuperior.SelectedIndex = 0;
            }

            cargandoValores = estabaCargando;

            ActualizarEstadoCapaSuperior();
            ActualizarVisibilidadEmpalme();
            ActualizarResultadosRne();
            ReubicarControles();
        }

        public void ActualizarCantidad(int cantidad)
        {
            lblCantidad.Text = $"Cimentaciones seleccionadas: {cantidad}";
        }

        // =====================================
        // VISIBILIDAD DE CONTROLES DE EMPALME
        // =====================================
        private void ActualizarVisibilidadEmpalme()
        {
            if (chkConsiderarEmpalme == null)
                return;

            bool considerar = chkConsiderarEmpalme.Checked;
            bool usarRne = considerar && chkUsarRne != null && chkUsarRne.Checked;

            lblLongitudBarra.Visible = considerar;
            txtLongitudBarra.Visible = considerar;
            lblMBarra.Visible = considerar;

            chkUsarRne.Visible = considerar;

            lblLongitudEmpalme.Visible = considerar && !usarRne;
            txtLongitudEmpalme.Visible = considerar && !usarRne;
            lblMEmpalme.Visible = considerar && !usarRne;

            lblFc.Visible = usarRne;
            txtFc.Visible = usarRne;
            lblKgCm2.Visible = usarRne;

            lblFy.Visible = usarRne;
            txtFy.Visible = usarRne;
            lblMpa.Visible = usarRne;

            lblEmpalmeInferiorRne.Visible = usarRne;
            txtEmpalmeInferiorRne.Visible = usarRne;
            lblMInfRne.Visible = usarRne;

            bool mostrarSuperior = usarRne && EsDosMallas;

            lblEmpalmeSuperiorRne.Visible = mostrarSuperior;
            txtEmpalmeSuperiorRne.Visible = mostrarSuperior;
            lblMSupRne.Visible = mostrarSuperior;
        }

        // =====================================
        // CÁLCULO AUTOMÁTICO RNE E.060
        // Empalme Clase B: 1.3 ld.
        // La capa superior se calcula conservadoramente
        // como barra superior: Psi_t = 1.3.
        // =====================================
        private void ActualizarResultadosRne()
        {
            if (txtEmpalmeInferiorRne == null ||
                txtEmpalmeSuperiorRne == null)
            {
                return;
            }

            txtEmpalmeInferiorRne.Text = "";
            txtEmpalmeSuperiorRne.Text = "";

            if (chkUsarRne == null || !chkUsarRne.Checked)
                return;

            if (!TryLeerDoubleVentana(txtFc.Text, out double fcKgCm2) || fcKgCm2 <= 0.0)
                return;

            if (!TryLeerDoubleVentana(txtFy.Text, out double fyMpa) || fyMpa <= 0.0)
                return;

            double recubrimientoCm = ObtenerRecubrimientoSeleccionadoCm();

            if (recubrimientoCm <= 0.0)
                return;

            if (!TryLeerDoubleVentana(txtEspaciamiento.Text, out double espaciamientoInferiorCm) ||
                espaciamientoInferiorCm <= 0.0)
            {
                return;
            }

            RebarBarType tipoInferior = TipoArmaduraSeleccionado;
            double diametroInferiorMm = ObtenerDiametroBarraMm(tipoInferior);

            if (diametroInferiorMm <= 0.0)
                return;

            double empalmeInferiorM = CalcularEmpalmeRneM(
                diametroInferiorMm,
                fyMpa,
                fcKgCm2,
                recubrimientoCm,
                espaciamientoInferiorCm,
                false);

            if (empalmeInferiorM <= 0.0)
                return;

            txtEmpalmeInferiorRne.Text = empalmeInferiorM.ToString(
                "0.00",
                System.Globalization.CultureInfo.InvariantCulture);

            if (!EsDosMallas)
                return;

            if (!TryLeerDoubleVentana(EspaciamientoSuperiorTexto, out double espaciamientoSuperiorCm) ||
                espaciamientoSuperiorCm <= 0.0)
            {
                return;
            }

            RebarBarType tipoSuperior = TipoArmaduraSuperiorSeleccionado;
            double diametroSuperiorMm = ObtenerDiametroBarraMm(tipoSuperior);

            if (diametroSuperiorMm <= 0.0)
                return;

            double empalmeSuperiorM = CalcularEmpalmeRneM(
                diametroSuperiorMm,
                fyMpa,
                fcKgCm2,
                recubrimientoCm,
                espaciamientoSuperiorCm,
                true);

            if (empalmeSuperiorM <= 0.0)
                return;

            txtEmpalmeSuperiorRne.Text = empalmeSuperiorM.ToString(
                "0.00",
                System.Globalization.CultureInfo.InvariantCulture);
        }

        private double CalcularEmpalmeRneM(
            double diametroMm,
            double fyMpa,
            double fcKgCm2,
            double recubrimientoCm,
            double espaciamientoEjesCm,
            bool esBarraSuperior)
        {
            if (diametroMm <= 0.0 ||
                fyMpa <= 0.0 ||
                fcKgCm2 <= 0.0 ||
                recubrimientoCm <= 0.0 ||
                espaciamientoEjesCm <= 0.0)
            {
                return 0.0;
            }

            // Conversión de kg/cm² a MPa.
            double fcMpa = fcKgCm2 * 0.0980665;
            double recubrimientoLibreMm = recubrimientoCm * 10.0;
            double espaciamientoEjesMm = espaciamientoEjesCm * 10.0;
            double espaciamientoLibreMm = espaciamientoEjesMm - diametroMm;

            if (fcMpa <= 0.0 || espaciamientoLibreMm <= 0.0)
                return 0.0;

            double psiT = esBarraSuperior ? 1.3 : 1.0;
            double psiE = 1.0;   // Barra sin recubrimiento epóxico.
            double lambda = 1.0; // Concreto de peso normal.
            double ldMm;

            // Tabla 12.1: se usa la condición sin necesidad de estribos,
            // con separación libre >= 2db y recubrimiento libre >= db.
            bool cumpleTablaSimplificada =
                recubrimientoLibreMm >= diametroMm &&
                espaciamientoLibreMm >= 2.0 * diametroMm;

            if (cumpleTablaSimplificada)
            {
                double divisor = diametroMm <= 19.05 ? 2.6 : 2.1;

                ldMm =
                    (fyMpa * psiT * psiE * lambda /
                    (divisor * System.Math.Sqrt(fcMpa))) * diametroMm;
            }
            else
            {
                // Numeral 12.2.3, usando Ktr = 0 como simplificación conservadora.
                double psiS = diametroMm <= 19.05 ? 0.8 : 1.0;

                double distanciaCentroASuperficieMm =
                    recubrimientoLibreMm + (diametroMm / 2.0);

                double cbMm = System.Math.Min(
                    distanciaCentroASuperficieMm,
                    espaciamientoEjesMm / 2.0);

                double relacionCb = cbMm / diametroMm;
                relacionCb = System.Math.Min(relacionCb, 2.5);

                if (relacionCb <= 0.0)
                    return 0.0;

                ldMm =
                    (fyMpa * psiT * psiE * psiS * lambda /
                    (1.1 * System.Math.Sqrt(fcMpa) * relacionCb)) * diametroMm;
            }

            // 12.2.1: ld no menor de 300 mm.
            ldMm = System.Math.Max(ldMm, 300.0);

            // 12.15.1 y Tabla 12.3:
            // Se adopta Clase B porque la rutina empalma el 100 %
            // de las barras en la misma zona.
            double longitudEmpalmeMm = System.Math.Max(1.3 * ldMm, 300.0);

            // Redondeo conservador hacia arriba cada 50 mm.
            longitudEmpalmeMm = System.Math.Ceiling(longitudEmpalmeMm / 50.0) * 50.0;

            return longitudEmpalmeMm / 1000.0;
        }

        private double ObtenerDiametroBarraMm(RebarBarType tipo)
        {
            if (tipo == null)
                return 0.0;

            Autodesk.Revit.DB.Parameter p = tipo.get_Parameter(
                Autodesk.Revit.DB.BuiltInParameter.REBAR_BAR_DIAMETER);

            if (p == null ||
                p.StorageType != Autodesk.Revit.DB.StorageType.Double)
            {
                p = tipo.LookupParameter("Diámetro de barra");
            }

            if (p == null ||
                p.StorageType != Autodesk.Revit.DB.StorageType.Double)
            {
                p = tipo.LookupParameter("Bar Diameter");
            }

            if (p == null ||
                p.StorageType != Autodesk.Revit.DB.StorageType.Double)
            {
                return 0.0;
            }

            return Autodesk.Revit.DB.UnitUtils.ConvertFromInternalUnits(
                p.AsDouble(),
                Autodesk.Revit.DB.UnitTypeId.Millimeters);
        }

        private bool TryLeerDoubleVentana(string texto, out double valor)
        {
            valor = 0.0;

            if (string.IsNullOrWhiteSpace(texto))
                return false;

            texto = texto.Trim().Replace(",", ".");

            return double.TryParse(
                texto,
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor);
        }

        // =====================================
        // DISTANCIA DEL RECUBRIMIENTO SELECCIONADO
        // =====================================
        private double ObtenerRecubrimientoSeleccionadoCm()
        {
            RebarCoverType tipo = RecubrimientoSeleccionado;

            if (tipo == null)
                return 0.0;

            try
            {
                Parameter p = tipo.get_Parameter(BuiltInParameter.COVER_TYPE_LENGTH);

                if (p == null || p.StorageType != StorageType.Double)
                    return 0.0;

                return UnitUtils.ConvertFromInternalUnits(
                    p.AsDouble(),
                    UnitTypeId.Centimeters);
            }
            catch
            {
                return 0.0;
            }
        }

        private double ObtenerDistanciaRecubrimientoMm(RebarCoverType tipo)
        {
            if (tipo == null)
                return 0.0;

            try
            {
                Parameter p = tipo.get_Parameter(BuiltInParameter.COVER_TYPE_LENGTH);

                if (p == null || p.StorageType != StorageType.Double)
                    return 0.0;

                return UnitUtils.ConvertFromInternalUnits(
                    p.AsDouble(),
                    UnitTypeId.Millimeters);
            }
            catch
            {
                return 0.0;
            }
        }

        // =====================================
        // GUARDAR VALORES EN SETTINGS
        // =====================================
        private void GuardarValoresRecordados()
        {
            if (cargandoValores)
                return;

            try
            {
                RebarCoverType recubrimientoActual = RecubrimientoSeleccionado;

                ultimoRecubrimientoNombre =
                    recubrimientoActual != null ? recubrimientoActual.Name : "";

                // Reutilizamos el setting existente para recordar el NOMBRE del
                // recubrimiento seleccionado, no una distancia escrita manualmente.
                MYG.Properties.Settings.Default.V33Recubrimiento =
                    ultimoRecubrimientoNombre;

                MYG.Properties.Settings.Default.V33MallaRefuerzo =
                    cmbMallaRefuerzo != null &&
                    !string.IsNullOrWhiteSpace(cmbMallaRefuerzo.Text)
                    ? cmbMallaRefuerzo.Text.Trim()
                    : "1 Capa";

                MYG.Properties.Settings.Default.V33TipoInferior =
                    ObtenerTextoCombo(cmbTipoArmadura);

                MYG.Properties.Settings.Default.V33ColocarGancho =
                    chkColocarGancho != null && chkColocarGancho.Checked;

                MYG.Properties.Settings.Default.V33LongitudGancho =
                    txtLongitudGancho != null ? txtLongitudGancho.Text.Trim() : "15";

                ultimoConsiderarEmpalme =
                    chkConsiderarEmpalme != null && chkConsiderarEmpalme.Checked;

                ultimaLongitudBarra =
                    txtLongitudBarra != null &&
                    !string.IsNullOrWhiteSpace(txtLongitudBarra.Text)
                    ? txtLongitudBarra.Text.Trim()
                    : "9";

                ultimaLongitudEmpalme =
                    txtLongitudEmpalme != null &&
                    !string.IsNullOrWhiteSpace(txtLongitudEmpalme.Text)
                    ? txtLongitudEmpalme.Text.Trim()
                    : "3";

                ultimoUsarRne =
                    chkUsarRne != null && chkUsarRne.Checked;

                ultimoFc =
                    txtFc != null && !string.IsNullOrWhiteSpace(txtFc.Text)
                    ? txtFc.Text.Trim()
                    : "210";

                ultimoFy =
                    txtFy != null && !string.IsNullOrWhiteSpace(txtFy.Text)
                    ? txtFy.Text.Trim()
                    : "420";

                MYG.Properties.Settings.Default.V33EspaciadoInferior =
                    txtEspaciamiento != null ? txtEspaciamiento.Text.Trim() : "20";

                MYG.Properties.Settings.Default.V33CapaSupDiferente =
                    chkCapaSuperiorDiferente != null && chkCapaSuperiorDiferente.Checked;

                MYG.Properties.Settings.Default.V33EspaciadoSuperior =
                    txtEspaciamientoSuperior != null ? txtEspaciamientoSuperior.Text.Trim() : "20";

                MYG.Properties.Settings.Default.V33TipoSuperior =
                    ObtenerTextoCombo(cmbTipoArmaduraSuperior);

                MYG.Properties.Settings.Default.Save();
            }
            catch
            {
                // No mostrar error para no interrumpir Revit.
            }
        }

        private string ObtenerTextoCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return "";

            ItemTipoArmadura itemTipo = combo.SelectedItem as ItemTipoArmadura;

            if (itemTipo != null && itemTipo.Tipo != null)
                return itemTipo.Tipo.Name;

            ItemRecubrimiento itemRec = combo.SelectedItem as ItemRecubrimiento;

            if (itemRec != null && itemRec.Tipo != null)
                return itemRec.Tipo.Name;

            return combo.Text != null ? combo.Text.Trim() : "";
        }

        private RebarBarType ObtenerTipoArmaduraDesdeCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return null;

            ItemTipoArmadura seleccionado = combo.SelectedItem as ItemTipoArmadura;

            if (seleccionado != null && seleccionado.Tipo != null)
                return seleccionado.Tipo;

            string texto = combo.Text != null ? combo.Text.Trim() : "";

            if (string.IsNullOrWhiteSpace(texto))
                return null;

            foreach (object obj in combo.Items)
            {
                ItemTipoArmadura item = obj as ItemTipoArmadura;

                if (item == null || item.Tipo == null)
                    continue;

                if (string.Equals(item.Tipo.Name, texto, System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(item.Texto, texto, System.StringComparison.OrdinalIgnoreCase))
                {
                    return item.Tipo;
                }
            }

            return null;
        }

        private RebarCoverType ObtenerRecubrimientoDesdeCombo()
        {
            if (cmbRecubrimiento == null)
                return null;

            ItemRecubrimiento seleccionado =
                cmbRecubrimiento.SelectedItem as ItemRecubrimiento;

            if (seleccionado != null && seleccionado.Tipo != null)
                return seleccionado.Tipo;

            string texto = cmbRecubrimiento.Text != null
                ? cmbRecubrimiento.Text.Trim()
                : "";

            if (string.IsNullOrWhiteSpace(texto))
                return null;

            foreach (object obj in cmbRecubrimiento.Items)
            {
                ItemRecubrimiento item = obj as ItemRecubrimiento;

                if (item == null || item.Tipo == null)
                    continue;

                if (string.Equals(item.Tipo.Name, texto, System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(item.Texto, texto, System.StringComparison.OrdinalIgnoreCase))
                {
                    return item.Tipo;
                }
            }

            return null;
        }

        private void ResolverTextoRecubrimiento()
        {
            if (cmbRecubrimiento == null || cmbRecubrimiento.SelectedItem != null)
                return;

            string texto = cmbRecubrimiento.Text != null
                ? cmbRecubrimiento.Text.Trim()
                : "";

            if (string.IsNullOrWhiteSpace(texto))
                return;

            for (int i = 0; i < cmbRecubrimiento.Items.Count; i++)
            {
                ItemRecubrimiento item = cmbRecubrimiento.Items[i] as ItemRecubrimiento;

                if (item == null || item.Tipo == null)
                    continue;

                if (string.Equals(item.Tipo.Name, texto, System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(item.Texto, texto, System.StringComparison.OrdinalIgnoreCase))
                {
                    cmbRecubrimiento.SelectedIndex = i;
                    return;
                }
            }
        }

        private bool SeleccionarComboPorTexto(WinForms.ComboBox combo, string texto)
        {
            if (combo == null || string.IsNullOrWhiteSpace(texto))
                return false;

            for (int i = 0; i < combo.Items.Count; i++)
            {
                object obj = combo.Items[i];
                string nombre = "";
                string textoVisible = obj != null ? obj.ToString() : "";

                ItemTipoArmadura itemTipo = obj as ItemTipoArmadura;
                if (itemTipo != null && itemTipo.Tipo != null)
                    nombre = itemTipo.Tipo.Name;

                ItemRecubrimiento itemRec = obj as ItemRecubrimiento;
                if (itemRec != null && itemRec.Tipo != null)
                    nombre = itemRec.Tipo.Name;

                if (string.IsNullOrWhiteSpace(nombre))
                    nombre = textoVisible;

                if (nombre.Equals(texto, System.StringComparison.OrdinalIgnoreCase) ||
                    textoVisible.Equals(texto, System.StringComparison.OrdinalIgnoreCase))
                {
                    combo.SelectedIndex = i;
                    return true;
                }
            }

            return false;
        }

    }

}
