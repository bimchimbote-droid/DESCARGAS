﻿// =====================================
// HANDLER - EJECUTAR ACERO EN CIMENTACIÓN
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

public class EjecutarAceroCimentacionHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public AceroCimentacionForm Form;
    public SeleccionarCimentacionesAceroHandler SeleccionHandler;

    private const double Tol = 1e-6;

    // Identifica la capa que se está creando para completar
    // los parámetros de cada objeto Rebar generado.
    private string tipoAceroActual = "Acero inferior";

    private class DatosCaraInferior
    {
        public XYZ Origin;
        public XYZ XAxis;
        public XYZ YAxis;
        public XYZ Up;

        public double Espesor;

        public List<XYZ> Puntos3D;
        public List<List<XYZ>> LoopsPuntos3D;
    }

    private class Barra2D
    {
        public double Posicion;
        public double A1;
        public double A2;
    }

    private class ResultadoTramoEmpalme
    {
        public Rebar Rebar;
        public double EstacionFin;
        public double LongitudReal;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
            return;

        Document doc = uidoc.Document;

        if (Form == null)
            return;

        if (SeleccionHandler == null)
            return;

        RebarBarType barTypeInferior = Form.TipoArmaduraSeleccionado;

        if (barTypeInferior == null)
        {
            TaskDialog.Show("MYG", "Debe seleccionar un tipo de armadura.");
            return;
        }

        if (!TryLeerDouble(Form.EspaciamientoTexto, out double espaciamientoInferiorCm))
        {
            TaskDialog.Show("MYG", "El espaciamiento inferior ingresado no es válido.");
            return;
        }

        RebarCoverType recubrimientoSeleccionado =
            Form.RecubrimientoSeleccionado;

        if (recubrimientoSeleccionado == null)
        {
            TaskDialog.Show(
                "MYG",
                "Debe seleccionar un recubrimiento de armadura configurado en Revit.");
            return;
        }

        double recubrimiento =
            ObtenerDistanciaRecubrimiento(recubrimientoSeleccionado);

        if (espaciamientoInferiorCm <= 0)
        {
            TaskDialog.Show("MYG", "El espaciamiento inferior debe ser mayor que cero.");
            return;
        }

        if (recubrimiento <= Tol)
        {
            TaskDialog.Show(
                "MYG",
                "No se pudo obtener la distancia del recubrimiento seleccionado.");
            return;
        }

        bool crearMallaSuperior = Form.EsDosMallas;

        RebarBarType barTypeSuperior = barTypeInferior;
        double espaciamientoSuperiorCm = espaciamientoInferiorCm;

        if (crearMallaSuperior)
        {
            barTypeSuperior = Form.TipoArmaduraSuperiorSeleccionado ?? barTypeInferior;

            if (Form.CapaSuperiorDiferente)
            {
                if (barTypeSuperior == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar un tipo de armadura para la capa superior.");
                    return;
                }

                if (!TryLeerDouble(Form.EspaciamientoSuperiorTexto, out espaciamientoSuperiorCm))
                {
                    TaskDialog.Show("MYG", "El espaciamiento superior ingresado no es válido.");
                    return;
                }

                if (espaciamientoSuperiorCm <= 0)
                {
                    TaskDialog.Show("MYG", "El espaciamiento superior debe ser mayor que cero.");
                    return;
                }
            }
        }

        bool colocarGancho = Form.ColocarGancho;
        double longitudGanchoCm = 0.0;

        if (colocarGancho)
        {
            if (!TryLeerDouble(Form.LongitudGanchoTexto, out longitudGanchoCm))
            {
                TaskDialog.Show("MYG", "La longitud del gancho ingresada no es válida.");
                return;
            }

            if (longitudGanchoCm <= 0)
            {
                TaskDialog.Show("MYG", "La longitud del gancho debe ser mayor que cero.");
                return;
            }
        }

        bool considerarEmpalme = Form.ConsiderarEmpalme;
        bool usarRne = considerarEmpalme && Form.UsarRNE;

        double longitudBarraM = 9.0;
        double longitudEmpalmeInferiorM = 3.0;
        double longitudEmpalmeSuperiorM = 3.0;

        if (considerarEmpalme)
        {
            if (!TryLeerDouble(Form.LongitudBarraTexto, out longitudBarraM))
            {
                TaskDialog.Show(
                    "MYG",
                    "La longitud de barra ingresada no es válida. Ingrésela en metros.");
                return;
            }

            if (longitudBarraM <= 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "La longitud de barra debe ser mayor que cero.");
                return;
            }

            if (usarRne)
            {
                if (!TryLeerDouble(
                    Form.LongitudEmpalmeInferiorRNETexto,
                    out longitudEmpalmeInferiorM))
                {
                    TaskDialog.Show(
                        "MYG",
                        "No se pudo leer la longitud de empalme inferior calculada según RNE E.060.");
                    return;
                }

                if (crearMallaSuperior)
                {
                    if (!TryLeerDouble(
                        Form.LongitudEmpalmeSuperiorRNETexto,
                        out longitudEmpalmeSuperiorM))
                    {
                        TaskDialog.Show(
                            "MYG",
                            "No se pudo leer la longitud de empalme superior calculada según RNE E.060.");
                        return;
                    }
                }
                else
                {
                    longitudEmpalmeSuperiorM = longitudEmpalmeInferiorM;
                }
            }
            else
            {
                if (!TryLeerDouble(Form.LongitudEmpalmeTexto, out longitudEmpalmeInferiorM))
                {
                    TaskDialog.Show(
                        "MYG",
                        "La longitud de empalme ingresada no es válida. Ingrésela en metros.");
                    return;
                }

                longitudEmpalmeSuperiorM = longitudEmpalmeInferiorM;
            }

            if (longitudEmpalmeInferiorM <= 0 ||
                longitudEmpalmeSuperiorM <= 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "Las longitudes de empalme deben ser mayores que cero.");
                return;
            }

            double longitudEmpalmeMayorM = Math.Max(
                longitudEmpalmeInferiorM,
                longitudEmpalmeSuperiorM);

            if (longitudEmpalmeMayorM >= longitudBarraM)
            {
                TaskDialog.Show(
                    "MYG",
                    "La longitud de empalme calculada debe ser menor que la longitud comercial de barra.");
                return;
            }
        }

        if (SeleccionHandler.CimentacionesSeleccionadas == null ||
            SeleccionHandler.CimentacionesSeleccionadas.Count == 0)
        {
            TaskDialog.Show("MYG", "Primero debe seleccionar una o más cimentaciones estructurales.");
            return;
        }

        double espaciamientoInferior = UnitUtils.ConvertToInternalUnits(
            espaciamientoInferiorCm,
            UnitTypeId.Centimeters);

        double espaciamientoSuperior = UnitUtils.ConvertToInternalUnits(
            espaciamientoSuperiorCm,
            UnitTypeId.Centimeters);

        double longitudGancho = UnitUtils.ConvertToInternalUnits(
            longitudGanchoCm,
            UnitTypeId.Centimeters);

        double longitudBarra = UnitUtils.ConvertToInternalUnits(
            longitudBarraM,
            UnitTypeId.Meters);

        double longitudEmpalmeInferior = UnitUtils.ConvertToInternalUnits(
            longitudEmpalmeInferiorM,
            UnitTypeId.Meters);

        double longitudEmpalmeSuperior = UnitUtils.ConvertToInternalUnits(
            longitudEmpalmeSuperiorM,
            UnitTypeId.Meters);

        double diametroInferior = ObtenerDiametroBarra(barTypeInferior);
        double diametroSuperior = ObtenerDiametroBarra(barTypeSuperior);

        if (considerarEmpalme)
        {
            double diametroMayor = Math.Max(diametroInferior, diametroSuperior);

            double longitudEmpalmeMayor = Math.Max(
                longitudEmpalmeInferior,
                longitudEmpalmeSuperior);

            double longitudMinimaBarra =
                longitudEmpalmeMayor +
                (colocarGancho ? longitudGancho : 0.0) +
                Math.Max(
                    diametroMayor * 6.0,
                    UnitUtils.ConvertToInternalUnits(10.0, UnitTypeId.Centimeters));

            if (longitudBarra <= longitudMinimaBarra)
            {
                TaskDialog.Show(
                    "MYG",
                    "La longitud de barra debe ser mayor que la longitud de empalme, " +
                    "el gancho exterior y la zona de quiebre.");
                return;
            }
        }

        double diametroCurvaturaInferior = ObtenerDiametroCurvaturaEstandar(barTypeInferior);
        double diametroCurvaturaSuperior = ObtenerDiametroCurvaturaEstandar(barTypeSuperior);

        int cimentacionesOk = 0;
        int cimentacionesFallidas = 0;
        int objetosAceroCreados = 0;

        using (Transaction t = new Transaction(doc, "MYG - Acero en cimentación"))
        {
            t.Start();

            foreach (ElementId id in SeleccionHandler.CimentacionesSeleccionadas)
            {
                Element cimentacion = doc.GetElement(id);

                if (cimentacion == null)
                {
                    cimentacionesFallidas++;
                    continue;
                }

                RebarHostData hostData = RebarHostData.GetRebarHostData(cimentacion);

                if (hostData == null)
                {
                    cimentacionesFallidas++;
                    continue;
                }

                // Asignar el recubrimiento seleccionado al propio anfitrión.
                // Se intenta completar Cara superior, Cara inferior y Otras caras
                // (además de variantes disponibles en otras familias anfitrionas).
                AsignarRecubrimientoAlAnfitrion(
                    cimentacion,
                    recubrimientoSeleccionado);

                int creadas = CrearAceroEnCimentacion(
                    doc,
                    cimentacion,
                    barTypeInferior,
                    espaciamientoInferior,
                    diametroInferior,
                    diametroCurvaturaInferior,
                    barTypeSuperior,
                    espaciamientoSuperior,
                    diametroSuperior,
                    diametroCurvaturaSuperior,
                    recubrimiento,
                    colocarGancho,
                    longitudGancho,
                    crearMallaSuperior,
                    considerarEmpalme,
                    longitudBarra,
                    longitudEmpalmeInferior,
                    longitudEmpalmeSuperior);

                if (creadas > 0)
                {
                    cimentacionesOk++;
                    objetosAceroCreados += creadas;
                }
                else
                {
                    cimentacionesFallidas++;
                }
            }

            t.Commit();
        }


    }

    // =====================================
    // OBTENER DISTANCIA DEL TIPO DE RECUBRIMIENTO
    // =====================================
    private double ObtenerDistanciaRecubrimiento(
        RebarCoverType tipoRecubrimiento)
    {
        if (tipoRecubrimiento == null)
            return 0.0;

        try
        {
            Parameter p = tipoRecubrimiento.get_Parameter(
                BuiltInParameter.COVER_TYPE_LENGTH);

            if (p == null || p.StorageType != StorageType.Double)
                return 0.0;

            return p.AsDouble();
        }
        catch
        {
            return 0.0;
        }
    }

    // =====================================
    // ASIGNAR RECUBRIMIENTO A LA CIMENTACIÓN
    // =====================================
    private void AsignarRecubrimientoAlAnfitrion(
        Element anfitrion,
        RebarCoverType tipoRecubrimiento)
    {
        if (anfitrion == null || tipoRecubrimiento == null)
            return;

        ElementId idRecubrimiento = tipoRecubrimiento.Id;

        if (idRecubrimiento == null ||
            idRecubrimiento == ElementId.InvalidElementId)
        {
            return;
        }

        BuiltInParameter[] parametrosRecubrimiento =
        {
            BuiltInParameter.CLEAR_COVER_TOP,
            BuiltInParameter.CLEAR_COVER_BOTTOM,
            BuiltInParameter.CLEAR_COVER_OTHER,
            BuiltInParameter.CLEAR_COVER_EXTERIOR,
            BuiltInParameter.CLEAR_COVER_INTERIOR,
            BuiltInParameter.CLEAR_COVER
        };

        foreach (BuiltInParameter bip in parametrosRecubrimiento)
        {
            try
            {
                Parameter p = anfitrion.get_Parameter(bip);

                if (p == null || p.IsReadOnly)
                    continue;

                if (p.StorageType != StorageType.ElementId)
                    continue;

                p.Set(idRecubrimiento);
            }
            catch
            {
                // Si una cara/parámetro no existe para este anfitrión,
                // se continúa con los demás sin interrumpir la rutina.
            }
        }
    }

    public string GetName()
    {
        return "Crear acero en cimentación estructural";
    }

    // =====================================
    // CREAR ACERO EN CIMENTACIÓN
    // 1 CAPA: solo inferior
    // 2 CAPAS: inferior + superior
    // =====================================
    private int CrearAceroEnCimentacion(
        Document doc,
        Element cimentacion,
        RebarBarType barTypeInferior,
        double espaciamientoInferior,
        double diametroInferior,
        double diametroCurvaturaInferior,
        RebarBarType barTypeSuperior,
        double espaciamientoSuperior,
        double diametroSuperior,
        double diametroCurvaturaSuperior,
        double recubrimiento,
        bool colocarGancho,
        double longitudGancho,
        bool crearMallaSuperior,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalmeInferior,
        double longitudEmpalmeSuperior)
    {
        DatosCaraInferior datos = ObtenerDatosCaraInferior(cimentacion);

        if (datos == null)
            return 0;

        if (datos.Puntos3D == null || datos.Puntos3D.Count < 3)
            return 0;

        if (datos.Espesor <= Tol)
            return 0;

        int contador = 0;

        double longitudMinima = UnitUtils.ConvertToInternalUnits(
            5.0,
            UnitTypeId.Centimeters);

        // =================================================
        // MALLA INFERIOR
        // Ganchos hacia arriba
        // =================================================
        double offsetInferiorPrimeraDireccion = recubrimiento;

        // La segunda dirección se desplaza medio diámetro adicional
        // hacia el núcleo para evitar superposición con la primera.
        // Separación entre ejes: 1.5Ø.
        double offsetInferiorSegundaDireccion =
            recubrimiento + (1.5 * diametroInferior);

        tipoAceroActual = "Acero inferior";

        contador += CrearMallaEnCapa(
            doc,
            cimentacion,
            barTypeInferior,
            datos,
            espaciamientoInferior,
            recubrimiento,
            offsetInferiorPrimeraDireccion,
            offsetInferiorSegundaDireccion,
            longitudMinima,
            colocarGancho,
            longitudGancho,
            diametroCurvaturaInferior,
            datos.Up,
            considerarEmpalme,
            longitudBarra,
            longitudEmpalmeInferior,
            diametroInferior);

        // =================================================
        // MALLA SUPERIOR
        // Ganchos hacia abajo
        // =================================================
        if (crearMallaSuperior)
        {
            double offsetSuperiorPrimeraDireccion = datos.Espesor - recubrimiento;

            // En la malla superior el desplazamiento adicional se realiza
            // hacia abajo, es decir, hacia el núcleo de la cimentación.
            // Separación entre ejes: 1.5Ø.
            double offsetSuperiorSegundaDireccion =
                datos.Espesor - recubrimiento - (1.5 * diametroSuperior);

            if (offsetSuperiorPrimeraDireccion > Tol &&
                offsetSuperiorSegundaDireccion > Tol)
            {
                tipoAceroActual = "Acero superior";

                contador += CrearMallaEnCapa(
                    doc,
                    cimentacion,
                    barTypeSuperior,
                    datos,
                    espaciamientoSuperior,
                    recubrimiento,
                    offsetSuperiorPrimeraDireccion,
                    offsetSuperiorSegundaDireccion,
                    longitudMinima,
                    colocarGancho,
                    longitudGancho,
                    diametroCurvaturaSuperior,
                    datos.Up.Multiply(-1.0),
                    considerarEmpalme,
                    longitudBarra,
                    longitudEmpalmeSuperior,
                    diametroSuperior);
            }
        }

        return contador;
    }

    // =====================================
    // CREAR MALLA EN UNA CAPA
    // =====================================
    private int CrearMallaEnCapa(
        Document doc,
        Element cimentacion,
        RebarBarType barType,
        DatosCaraInferior datos,
        double espaciamiento,
        double recubrimiento,
        double offsetPrimeraDireccion,
        double offsetSegundaDireccion,
        double longitudMinima,
        bool colocarGancho,
        double longitudGancho,
        double diametroCurvaturaEstandar,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra)
    {
        if (barType == null)
            return 0;

        if (offsetPrimeraDireccion <= Tol || offsetSegundaDireccion <= Tol)
            return 0;

        List<List<UV>> loops2D = ConstruirLoops2D(datos);

        if (loops2D == null || loops2D.Count == 0)
            return 0;

        List<UV> poligonoExterior = loops2D[0];

        if (poligonoExterior.Count < 3)
            return 0;

        double minX = poligonoExterior.Min(p => p.U);
        double maxX = poligonoExterior.Max(p => p.U);
        double minY = poligonoExterior.Min(p => p.V);
        double maxY = poligonoExterior.Max(p => p.V);

        int contador = 0;

        double reduccionDistribucion = (colocarGancho && diametroCurvaturaEstandar > Tol)
            ? diametroCurvaturaEstandar / 2.0
            : 0.0;

        // ==============================================================
        // DESFASES DE LOS DOS EMPALMES COMO UN SOLO PAR
        // ==============================================================
        // Ambos empalmes se calculan respecto de un mismo nivel de referencia
        // hacia el núcleo. De esta manera la separación final no depende de
        // cuál dirección se creó primero ni de la separación base entre capas.
        //
        // Para barras del mismo diámetro:
        // distancia entre ejes = 0.5Ø + 1Ø libre + 0.5Ø = 2Ø.
        double factorSeparacionLibreEntreEmpalmes = 1.0;
        double factorDesplazamientoInicialHaciaNucleo = 1.0;

        double signoHaciaNucleo = 1.0;

        if (datos.Up != null &&
            datos.Up.GetLength() > Tol &&
            direccionGancho != null &&
            direccionGancho.GetLength() > Tol)
        {
            double producto = direccionGancho
                .Normalize()
                .DotProduct(datos.Up.Normalize());

            signoHaciaNucleo = producto < 0.0 ? -1.0 : 1.0;
        }

        // Coordenadas de los ejes originales medidas positivamente hacia el núcleo.
        double posicionNucleoPrimera =
            offsetPrimeraDireccion * signoHaciaNucleo;

        double posicionNucleoSegunda =
            offsetSegundaDireccion * signoHaciaNucleo;

        double posicionBaseMasInterior = Math.Max(
            posicionNucleoPrimera,
            posicionNucleoSegunda);

        double separacionLibreCaraACara =
            factorSeparacionLibreEntreEmpalmes * diametroBarra;

        double separacionEntreEjesEmpalmes =
            diametroBarra + separacionLibreCaraACara;

        // El primer empalme queda un diámetro hacia el núcleo respecto del
        // eje base más interior. El segundo se coloca a la separación exacta
        // entre ejes requerida respecto del primero.
        double posicionObjetivoPrimera =
            posicionBaseMasInterior +
            (factorDesplazamientoInicialHaciaNucleo * diametroBarra);

        double posicionObjetivoSegunda =
            posicionObjetivoPrimera + separacionEntreEjesEmpalmes;

        double desfaseEmpalmePrimeraDireccion =
            posicionObjetivoPrimera - posicionNucleoPrimera;

        double desfaseEmpalmeSegundaDireccion =
            posicionObjetivoSegunda - posicionNucleoSegunda;

        if (desfaseEmpalmePrimeraDireccion < 0.0)
            desfaseEmpalmePrimeraDireccion = 0.0;

        if (desfaseEmpalmeSegundaDireccion < 0.0)
            desfaseEmpalmeSegundaDireccion = 0.0;

        // =================================================
        // BARRAS EN DIRECCIÓN X
        // Se distribuyen en Y
        // =================================================
        double espaciamientoRealX;

        List<Barra2D> barrasX = ConstruirBarrasX(
            loops2D,
            minY,
            maxY,
            recubrimiento,
            espaciamiento,
            reduccionDistribucion,
            out espaciamientoRealX);

        contador += CrearBarrasXPorGrupos(
            doc,
            cimentacion,
            barType,
            datos,
            barrasX,
            espaciamientoRealX,
            espaciamiento,
            offsetPrimeraDireccion,
            longitudMinima,
            colocarGancho,
            longitudGancho,
            direccionGancho,
            considerarEmpalme,
            longitudBarra,
            longitudEmpalme,
            diametroBarra,
            desfaseEmpalmePrimeraDireccion);

        // =================================================
        // BARRAS EN DIRECCIÓN Y
        // Se distribuyen en X
        // =================================================
        double espaciamientoRealY;

        List<Barra2D> barrasY = ConstruirBarrasY(
            loops2D,
            minX,
            maxX,
            recubrimiento,
            espaciamiento,
            reduccionDistribucion,
            out espaciamientoRealY);

        contador += CrearBarrasYPorGrupos(
            doc,
            cimentacion,
            barType,
            datos,
            barrasY,
            espaciamientoRealY,
            espaciamiento,
            offsetSegundaDireccion,
            longitudMinima,
            colocarGancho,
            longitudGancho,
            direccionGancho,
            considerarEmpalme,
            longitudBarra,
            longitudEmpalme,
            diametroBarra,
            desfaseEmpalmeSegundaDireccion);

        return contador;
    }

    // =====================================
    // CONSTRUIR LOOPS 2D
    // =====================================
    private List<List<UV>> ConstruirLoops2D(DatosCaraInferior datos)
    {
        List<List<UV>> loops2D = new List<List<UV>>();

        if (datos.LoopsPuntos3D != null && datos.LoopsPuntos3D.Count > 0)
        {
            foreach (List<XYZ> loop3D in datos.LoopsPuntos3D)
            {
                if (loop3D == null || loop3D.Count < 3)
                    continue;

                List<UV> loop2D = loop3D
                    .Select(p => ToUV(p, datos.Origin, datos.XAxis, datos.YAxis))
                    .ToList();

                LimpiarPoligono(loop2D);

                if (loop2D.Count < 3)
                    continue;

                if (Math.Abs(AreaPoligono(loop2D)) <= Tol)
                    continue;

                loops2D.Add(loop2D);
            }
        }

        if (loops2D.Count == 0 && datos.Puntos3D != null && datos.Puntos3D.Count >= 3)
        {
            List<UV> exterior = datos.Puntos3D
                .Select(p => ToUV(p, datos.Origin, datos.XAxis, datos.YAxis))
                .ToList();

            LimpiarPoligono(exterior);

            if (exterior.Count >= 3)
                loops2D.Add(exterior);
        }

        loops2D = loops2D
            .OrderByDescending(l => Math.Abs(AreaPoligono(l)))
            .ToList();

        return loops2D;
    }

    // =====================================
    // CREAR BARRA INDIVIDUAL
    // DEVUELVE LA CANTIDAD DE OBJETOS REBAR CREADOS
    // =====================================
    private int CrearBarraIndividual(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        XYZ p1,
        XYZ p2,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        List<Rebar> rebars = CrearRebarsConEmpalme(
            doc,
            host,
            barType,
            normal,
            p1,
            p2,
            colocarGancho,
            longitudGancho,
            direccionGancho,
            considerarEmpalme,
            longitudBarra,
            longitudEmpalme,
            diametroBarra,
            desfaseEmpalme);

        return rebars.Count;
    }

    // =====================================
    // CREAR BARRA CON ESPACIADO MÁXIMO
    // Cada pieza del empalme conserva el mismo layout.
    // =====================================
    private int CrearBarraConEspaciadoMaximo(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normalDistribucion,
        XYZ p1,
        XYZ p2,
        double espaciamientoMaximo,
        double espaciamientoEtiqueta,
        double longitudDistribucion,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        if (longitudDistribucion <= Tol)
            return 0;

        List<ElementId> idsCreados = new List<ElementId>();

        try
        {
            List<Rebar> rebars = CrearRebarsConEmpalme(
                doc,
                host,
                barType,
                normalDistribucion,
                p1,
                p2,
                colocarGancho,
                longitudGancho,
                direccionGancho,
                considerarEmpalme,
                longitudBarra,
                longitudEmpalme,
                diametroBarra,
                desfaseEmpalme);

            if (rebars.Count == 0)
                return 0;

            foreach (Rebar rebar in rebars)
            {
                idsCreados.Add(rebar.Id);

                RebarShapeDrivenAccessor accessor = rebar.GetShapeDrivenAccessor();

                accessor.SetLayoutAsMaximumSpacing(
                    espaciamientoMaximo,
                    longitudDistribucion,
                    true,
                    true,
                    true);

                AplicarEspaciamientoIngresadoParaEtiqueta(
                    rebar,
                    espaciamientoEtiqueta);
            }

            return rebars.Count;
        }
        catch
        {
            foreach (ElementId id in idsCreados)
            {
                EliminarElementoSeguro(doc, id);
            }

            return 0;
        }
    }

    // =====================================
    // CREAR REBARS CON O SIN EMPALME
    //
    // LONGITUD DE BARRA:
    // Longitud comercial máxima de cada pieza.
    //
    // LONGITUD DE EMPALME:
    // Longitud de desarrollo o traslape medida sobre
    // la proyección longitudinal de la barra.
    //
    // IMPORTANTE:
    // El empalme NO se modela como un acero aparte.
    // El boceto de la propia pieza termina con un
    // quiebre que sube y continúa paralela por encima
    // de la siguiente pieza durante la longitud de
    // empalme, exactamente como en el croquis del usuario.
    // =====================================
    private List<Rebar> CrearRebarsConEmpalme(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        XYZ p1,
        XYZ p2,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        List<Rebar> resultado = new List<Rebar>();
        List<ElementId> idsCreados = new List<ElementId>();

        if (doc == null ||
            host == null ||
            barType == null ||
            p1 == null ||
            p2 == null)
        {
            return resultado;
        }

        double longitudRectaTotal = p1.DistanceTo(p2);

        if (longitudRectaTotal <= Tol)
            return resultado;

        try
        {
            XYZ direccionPrincipal = p2.Subtract(p1).Normalize();

            XYZ direccionEmpalme = ObtenerDireccionEmpalme(
                direccionPrincipal,
                direccionGancho,
                normal);

            // El valor ya viene calculado para esta dirección concreta.
            // Se mide desde el eje original hacia el núcleo de la cimentación.
            // Para la dirección exterior suele ser 2Ø; para la interior, 1Ø.
            if (desfaseEmpalme <= Tol)
            {
                desfaseEmpalme = diametroBarra;
            }

            if (desfaseEmpalme <= Tol)
            {
                // Respaldo únicamente si Revit no permite leer el diámetro.
                desfaseEmpalme = UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Centimeters);
            }

            double longitudQuiebre = Math.Max(
                diametroBarra * 6.0,
                UnitUtils.ConvertToInternalUnits(
                    10.0,
                    UnitTypeId.Centimeters));

            double toleranciaLongitud = UnitUtils.ConvertToInternalUnits(
                0.1,
                UnitTypeId.Millimeters);

            // Sin empalme: comportamiento directo.
            if (!considerarEmpalme ||
                longitudBarra <= Tol ||
                longitudEmpalme <= Tol)
            {
                List<XYZ> puntos = new List<XYZ>() { p1, p2 };

                Rebar unico = CrearRebarBase(
                    doc,
                    host,
                    barType,
                    normal,
                    puntos,
                    colocarGancho,
                    colocarGancho,
                    longitudGancho,
                    direccionGancho);

                if (unico != null)
                    resultado.Add(unico);

                return resultado;
            }

            // Verificar si toda la barra cabe sin necesidad de dividirla.
            List<XYZ> puntosCompletos = new List<XYZ>() { p1, p2 };

            Rebar barraCompleta = CrearRebarBase(
                doc,
                host,
                barType,
                normal,
                puntosCompletos,
                colocarGancho,
                colocarGancho,
                longitudGancho,
                direccionGancho);

            if (barraCompleta == null)
                return resultado;

            doc.Regenerate();

            double longitudRealCompleta = ObtenerLongitudRealBarra(barraCompleta);

            if (longitudRealCompleta <= longitudBarra + toleranciaLongitud)
            {
                resultado.Add(barraCompleta);
                return resultado;
            }

            EliminarElementoSeguro(doc, barraCompleta.Id);

            double inicioActual = 0.0;
            bool esPrimera = true;
            int seguridad = 0;

            while (inicioActual < longitudRectaTotal - Tol && seguridad < 500)
            {
                seguridad++;

                // Primero intentar que el tramo restante sea la última pieza.
                List<XYZ> puntosUltimos = ConstruirPuntosTramo(
                    p1,
                    direccionPrincipal,
                    direccionEmpalme,
                    inicioActual,
                    longitudRectaTotal,
                    false,
                    longitudEmpalme,
                    desfaseEmpalme,
                    longitudQuiebre);

                Rebar ultimaCandidata = CrearRebarBase(
                    doc,
                    host,
                    barType,
                    normal,
                    puntosUltimos,
                    esPrimera && colocarGancho,
                    colocarGancho,
                    longitudGancho,
                    direccionGancho);

                if (ultimaCandidata != null)
                {
                    doc.Regenerate();

                    double longitudUltima = ObtenerLongitudRealBarra(ultimaCandidata);

                    if (longitudUltima <= longitudBarra + toleranciaLongitud)
                    {
                        resultado.Add(ultimaCandidata);
                        idsCreados.Add(ultimaCandidata.Id);
                        return resultado;
                    }

                    EliminarElementoSeguro(doc, ultimaCandidata.Id);
                }

                double longitudMinimaGeometrica = UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Centimeters);

                double estacionMinimaFin = inicioActual +
                    longitudQuiebre +
                    longitudEmpalme +
                    longitudMinimaGeometrica;

                // Debe dejar al menos un tramo mínimo para que la siguiente
                // pieza pueda continuar sobre el eje normal.
                double estacionMaximaFin = longitudRectaTotal -
                    longitudMinimaGeometrica;

                if (estacionMaximaFin <= estacionMinimaFin + Tol)
                {
                    throw new InvalidOperationException(
                        "No existe longitud suficiente para crear una nueva pieza con empalme al final.");
                }

                ResultadoTramoEmpalme tramo = CrearTramoAjustadoALongitud(
                    doc,
                    host,
                    barType,
                    normal,
                    p1,
                    direccionPrincipal,
                    direccionEmpalme,
                    inicioActual,
                    estacionMinimaFin,
                    estacionMaximaFin,
                    true,
                    esPrimera && colocarGancho,
                    false,
                    longitudGancho,
                    direccionGancho,
                    longitudBarra,
                    longitudEmpalme,
                    desfaseEmpalme,
                    longitudQuiebre);

                if (tramo == null || tramo.Rebar == null)
                {
                    throw new InvalidOperationException(
                        "No se pudo ajustar una pieza empalmada a la longitud comercial.");
                }

                if (tramo.EstacionFin <= inicioActual + longitudEmpalme + Tol)
                {
                    EliminarElementoSeguro(doc, tramo.Rebar.Id);
                    throw new InvalidOperationException(
                        "La pieza generada no produce avance suficiente.");
                }

                resultado.Add(tramo.Rebar);
                idsCreados.Add(tramo.Rebar.Id);

                double siguienteInicio = tramo.EstacionFin - longitudEmpalme;

                if (siguienteInicio <= inicioActual + Tol)
                {
                    throw new InvalidOperationException(
                        "No se pudo avanzar al siguiente tramo de armadura.");
                }

                inicioActual = siguienteInicio;
                esPrimera = false;
            }

            if (seguridad >= 500)
                throw new InvalidOperationException(
                    "Se alcanzó el límite de seguridad al generar empalmes.");

            return resultado;
        }
        catch
        {
            foreach (ElementId id in idsCreados)
            {
                EliminarElementoSeguro(doc, id);
            }

            resultado.Clear();
            return resultado;
        }
    }

    // =====================================
    // CREAR UNA PIEZA AJUSTADA A LA LONGITUD
    // COMERCIAL REAL REPORTADA POR REVIT.
    // Si tiene empalme, el empalme va al FINAL de la pieza.
    // =====================================
    private ResultadoTramoEmpalme CrearTramoAjustadoALongitud(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        XYZ origen,
        XYZ direccionPrincipal,
        XYZ direccionEmpalme,
        double estacionInicio,
        double estacionMinimaFin,
        double estacionMaximaFin,
        bool tieneEmpalmeFinal,
        bool ganchoInicio,
        bool ganchoFin,
        double longitudGancho,
        XYZ direccionGancho,
        double longitudObjetivo,
        double longitudEmpalme,
        double desfaseEmpalme,
        double longitudQuiebre)
    {
        double toleranciaLongitud = UnitUtils.ConvertToInternalUnits(
            0.1,
            UnitTypeId.Millimeters);

        if (estacionMaximaFin <= estacionMinimaFin + Tol)
            return null;

        double mejorEstacion = estacionMinimaFin;
        double mejorDiferencia = double.MaxValue;

        double inferior = estacionMinimaFin;
        double superior = estacionMaximaFin;

        for (int i = 0; i < 18; i++)
        {
            double estacionEvaluada = (inferior + superior) / 2.0;

            List<XYZ> puntos = ConstruirPuntosTramo(
                origen,
                direccionPrincipal,
                direccionEmpalme,
                estacionInicio,
                estacionEvaluada,
                tieneEmpalmeFinal,
                longitudEmpalme,
                desfaseEmpalme,
                longitudQuiebre);

            Rebar candidato = CrearRebarBase(
                doc,
                host,
                barType,
                normal,
                puntos,
                ganchoInicio,
                ganchoFin,
                longitudGancho,
                direccionGancho);

            if (candidato == null)
            {
                superior = estacionEvaluada;
                continue;
            }

            doc.Regenerate();

            double longitudReal = ObtenerLongitudRealBarra(candidato);
            double diferencia = Math.Abs(longitudReal - longitudObjetivo);

            if (diferencia < mejorDiferencia)
            {
                mejorDiferencia = diferencia;
                mejorEstacion = estacionEvaluada;
            }

            EliminarElementoSeguro(doc, candidato.Id);

            if (longitudReal < longitudObjetivo)
                inferior = estacionEvaluada;
            else
                superior = estacionEvaluada;

            if (diferencia <= toleranciaLongitud)
                break;
        }

        List<XYZ> puntosFinales = ConstruirPuntosTramo(
            origen,
            direccionPrincipal,
            direccionEmpalme,
            estacionInicio,
            mejorEstacion,
            tieneEmpalmeFinal,
            longitudEmpalme,
            desfaseEmpalme,
            longitudQuiebre);

        Rebar rebarFinal = CrearRebarBase(
            doc,
            host,
            barType,
            normal,
            puntosFinales,
            ganchoInicio,
            ganchoFin,
            longitudGancho,
            direccionGancho);

        if (rebarFinal == null)
            return null;

        doc.Regenerate();

        double longitudRealFinal = ObtenerLongitudRealBarra(rebarFinal);
        int correcciones = 0;

        while (longitudRealFinal > longitudObjetivo + toleranciaLongitud &&
               correcciones < 6)
        {
            correcciones++;

            double exceso = longitudRealFinal - longitudObjetivo;
            mejorEstacion -= exceso;

            if (mejorEstacion <= estacionMinimaFin)
                mejorEstacion = estacionMinimaFin;

            EliminarElementoSeguro(doc, rebarFinal.Id);

            puntosFinales = ConstruirPuntosTramo(
                origen,
                direccionPrincipal,
                direccionEmpalme,
                estacionInicio,
                mejorEstacion,
                tieneEmpalmeFinal,
                longitudEmpalme,
                desfaseEmpalme,
                longitudQuiebre);

            rebarFinal = CrearRebarBase(
                doc,
                host,
                barType,
                normal,
                puntosFinales,
                ganchoInicio,
                ganchoFin,
                longitudGancho,
                direccionGancho);

            if (rebarFinal == null)
                return null;

            doc.Regenerate();
            longitudRealFinal = ObtenerLongitudRealBarra(rebarFinal);
        }

        if (longitudRealFinal > longitudObjetivo + toleranciaLongitud)
        {
            EliminarElementoSeguro(doc, rebarFinal.Id);
            return null;
        }

        return new ResultadoTramoEmpalme()
        {
            Rebar = rebarFinal,
            EstacionFin = mejorEstacion,
            LongitudReal = longitudRealFinal
        };
    }

    // =====================================
    // CONSTRUIR GEOMETRÍA DE UNA PIEZA
    //
    // Sin empalme al final:
    //     -------------------------------
    //
    // Con empalme al final:
    //     -------------/================
    //                  ^<--empalme--->^
    //
    // El tramo elevado y paralelo mide exactamente la
    // longitud de empalme ingresada y pertenece al mismo
    // boceto de la pieza, no a un acero auxiliar.
    // =====================================
    private List<XYZ> ConstruirPuntosTramo(
        XYZ origen,
        XYZ direccionPrincipal,
        XYZ direccionEmpalme,
        double estacionInicio,
        double estacionFin,
        bool tieneEmpalmeFinal,
        double longitudEmpalme,
        double desfaseEmpalme,
        double longitudQuiebre)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (!tieneEmpalmeFinal)
        {
            AgregarPuntoSiDistinto(
                puntos,
                origen.Add(direccionPrincipal.Multiply(estacionInicio)));

            AgregarPuntoSiDistinto(
                puntos,
                origen.Add(direccionPrincipal.Multiply(estacionFin)));

            return puntos;
        }

        double estacionInicioEmpalme = estacionFin - longitudEmpalme;
        double estacionInicioQuiebre = estacionInicioEmpalme - longitudQuiebre;

        if (estacionInicioQuiebre < estacionInicio)
            estacionInicioQuiebre = estacionInicio;

        if (estacionInicioEmpalme < estacionInicioQuiebre)
            estacionInicioEmpalme = estacionInicioQuiebre;

        XYZ pInicio = origen.Add(direccionPrincipal.Multiply(estacionInicio));
        XYZ pInicioQuiebre = origen.Add(direccionPrincipal.Multiply(estacionInicioQuiebre));
        XYZ pInicioEmpalme = origen
            .Add(direccionPrincipal.Multiply(estacionInicioEmpalme))
            .Add(direccionEmpalme.Multiply(desfaseEmpalme));
        XYZ pFinEmpalme = origen
            .Add(direccionPrincipal.Multiply(estacionFin))
            .Add(direccionEmpalme.Multiply(desfaseEmpalme));

        AgregarPuntoSiDistinto(puntos, pInicio);
        AgregarPuntoSiDistinto(puntos, pInicioQuiebre);
        AgregarPuntoSiDistinto(puntos, pInicioEmpalme);
        AgregarPuntoSiDistinto(puntos, pFinEmpalme);

        return puntos;
    }

    private void AgregarPuntoSiDistinto(
        List<XYZ> puntos,
        XYZ punto)
    {
        if (puntos == null || punto == null)
            return;

        if (puntos.Count == 0)
        {
            puntos.Add(punto);
            return;
        }

        if (puntos[puntos.Count - 1].DistanceTo(punto) > Tol)
            puntos.Add(punto);
    }

    // =====================================
    // DIRECCIÓN DEL DESFASE DEL EMPALME
    //
    // Se desplaza en la dirección perpendicular al plano
    // de la malla (hacia arriba en la capa inferior y hacia
    // abajo en la capa superior), usando como prioridad la
    // misma dirección del gancho / capa.
    // =====================================
    private XYZ ObtenerDireccionEmpalme(
        XYZ direccionPrincipal,
        XYZ direccionGancho,
        XYZ normal)
    {
        XYZ direccion = null;

        if (direccionGancho != null &&
            direccionGancho.GetLength() > Tol)
        {
            direccion = direccionGancho.Normalize();
        }
        else if (normal != null &&
                 normal.GetLength() > Tol)
        {
            direccion = normal.Normalize();
        }
        else
        {
            direccion = XYZ.BasisZ;
        }

        return direccion;
    }

    // =====================================
    // LONGITUD DESARROLLADA REAL DE REVIT
    // Incluye los descuentos/aportes por curvaturas y ganchos.
    // =====================================
    private double ObtenerLongitudRealBarra(
        Rebar rebar)
    {
        if (rebar == null)
            return 0.0;

        try
        {
            Parameter p = rebar.get_Parameter(
                BuiltInParameter.REBAR_ELEM_LENGTH);

            if (p != null &&
                p.StorageType == StorageType.Double)
            {
                return p.AsDouble();
            }

            string[] nombres =
            {
                "Longitud de barra",
                "Bar Length",
                "Longitud"
            };

            foreach (string nombre in nombres)
            {
                Parameter px = rebar.LookupParameter(nombre);

                if (px != null &&
                    px.StorageType == StorageType.Double)
                {
                    return px.AsDouble();
                }
            }
        }
        catch
        {
        }

        return 0.0;
    }

    private void EliminarElementoSeguro(
        Document doc,
        ElementId id)
    {
        if (doc == null ||
            id == null ||
            id == ElementId.InvalidElementId)
        {
            return;
        }

        try
        {
            doc.Delete(id);
        }
        catch
        {
        }
    }

    // =====================================
    // APLICAR ESPACIAMIENTO INGRESADO
    // PARA QUE APAREZCA EN ETIQUETA
    // =====================================
    private void AplicarEspaciamientoIngresadoParaEtiqueta(
        Rebar rebar,
        double espaciamientoIngresado)
    {
        if (rebar == null)
            return;

        if (espaciamientoIngresado <= Tol)
            return;

        try
        {
            Parameter p = rebar.get_Parameter(
                BuiltInParameter.REBAR_ELEM_BAR_SPACING);

            if (SetearParametroDouble(p, espaciamientoIngresado))
                return;

            string[] nombres =
            {
                "Espaciado",
                "Spacing",
                "Bar Spacing"
            };

            foreach (string nombre in nombres)
            {
                Parameter px = rebar.LookupParameter(nombre);

                if (SetearParametroDouble(px, espaciamientoIngresado))
                    return;
            }
        }
        catch
        {
            // No interrumpir Revit si el parámetro no se puede escribir.
        }
    }

    private bool SetearParametroDouble(
        Parameter p,
        double valor)
    {
        if (p == null)
            return false;

        if (p.IsReadOnly)
            return false;

        if (p.StorageType != StorageType.Double)
            return false;

        p.Set(valor);
        return true;
    }

    // =====================================
    // CREAR REBAR BASE
    // Ganchos independientes en inicio y fin.
    // Los puntos centrales permiten crear el quiebre del empalme.
    // =====================================
    private Rebar CrearRebarBase(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        IList<XYZ> puntosCentro,
        bool colocarGanchoInicio,
        bool colocarGanchoFin,
        double longitudGancho,
        XYZ direccionGancho)
    {
        if (doc == null ||
            host == null ||
            barType == null ||
            normal == null ||
            puntosCentro == null ||
            puntosCentro.Count < 2)
        {
            return null;
        }

        IList<Curve> curvas = new List<Curve>();

        bool direccionGanchoValida =
            direccionGancho != null &&
            direccionGancho.GetLength() > Tol &&
            longitudGancho > Tol;

        XYZ dirGancho = direccionGanchoValida
            ? direccionGancho.Normalize()
            : null;

        XYZ primerPunto = puntosCentro[0];

        if (colocarGanchoInicio && direccionGanchoValida)
        {
            XYZ pGanchoInicio =
                primerPunto.Add(
                    dirGancho.Multiply(longitudGancho));

            if (pGanchoInicio.DistanceTo(primerPunto) > Tol)
            {
                curvas.Add(
                    Line.CreateBound(
                        pGanchoInicio,
                        primerPunto));
            }
        }

        for (int i = 0; i < puntosCentro.Count - 1; i++)
        {
            XYZ pInicio = puntosCentro[i];
            XYZ pFin = puntosCentro[i + 1];

            if (pInicio == null || pFin == null)
                continue;

            if (pInicio.DistanceTo(pFin) <= Tol)
                continue;

            curvas.Add(
                Line.CreateBound(
                    pInicio,
                    pFin));
        }

        XYZ ultimoPunto =
            puntosCentro[puntosCentro.Count - 1];

        if (colocarGanchoFin && direccionGanchoValida)
        {
            XYZ pGanchoFin =
                ultimoPunto.Add(
                    dirGancho.Multiply(longitudGancho));

            if (ultimoPunto.DistanceTo(pGanchoFin) > Tol)
            {
                curvas.Add(
                    Line.CreateBound(
                        ultimoPunto,
                        pGanchoFin));
            }
        }

        if (curvas.Count == 0)
            return null;

        using (BarTerminationsData terminaciones =
            new BarTerminationsData(doc))
        {
            terminaciones.HookTypeIdAtStart =
                ElementId.InvalidElementId;

            terminaciones.HookTypeIdAtEnd =
                ElementId.InvalidElementId;

            terminaciones.CrankTypeIdAtStart =
                ElementId.InvalidElementId;

            terminaciones.CrankTypeIdAtEnd =
                ElementId.InvalidElementId;

            terminaciones.EndTreatmentTypeIdAtStart =
                ElementId.InvalidElementId;

            terminaciones.EndTreatmentTypeIdAtEnd =
                ElementId.InvalidElementId;

            terminaciones.TerminationOrientationAtStart =
                RebarTerminationOrientation.Left;

            terminaciones.TerminationOrientationAtEnd =
                RebarTerminationOrientation.Right;

            Rebar rebarCreado = Rebar.CreateFromCurves(
                doc,
                RebarStyle.Standard,
                barType,
                host,
                normal,
                curvas,
                terminaciones,
                true,
                true);

            if (rebarCreado != null)
            {
                CompletarParametrosAceroCreado(
                    rebarCreado,
                    host,
                    tipoAceroActual);
            }

            return rebarCreado;
        }
    }

    // =====================================
    // COMPLETAR PARÁMETROS DEL ACERO CREADO
    // =====================================
    private void CompletarParametrosAceroCreado(
        Rebar rebar,
        Element cimentacion,
        string tipoAcero)
    {
        if (rebar == null || cimentacion == null)
            return;

        try
        {
            // 1. Descripción del TIPO de la cimentación estructural.
            string descripcionCimentacion =
                ObtenerDescripcionTipoCimentacion(cimentacion);

            if (!string.IsNullOrWhiteSpace(descripcionCimentacion))
            {
                SetearTodosLosParametrosTexto(
                    rebar,
                    descripcionCimentacion,
                    "STR_AnfitriónAcero",
                    "STR_AnfitrionAcero");
            }

            // 2. Resistencia del acero.
            SetearTodosLosParametrosTexto(
                rebar,
                "F'y=4200 kg/cm²",
                "STR_Resistencia");

            // 3. Clasificación según la capa creada.
            SetearTodosLosParametrosTexto(
                rebar,
                string.IsNullOrWhiteSpace(tipoAcero)
                    ? "Acero inferior"
                    : tipoAcero,
                "STR_TipoDeElemento (V/H)",
                "STR_TipoDeElemento(V/H)");

            // 4. Copiar STR_Ubicación desde la INSTANCIA de la cimentación.
            // Si el anfitrión no tiene valor, no se modifica el acero.
            string ubicacion = ObtenerPrimerValorTexto(
                cimentacion,
                "STR_Ubicación",
                "STR_Ubicacion");

            if (!string.IsNullOrWhiteSpace(ubicacion))
            {
                SetearTodosLosParametrosTexto(
                    rebar,
                    ubicacion,
                    "STR_Ubicación",
                    "STR_Ubicacion");
            }

            // 5. Materialidad.
            SetearTodosLosParametrosTexto(
                rebar,
                "Acero de refuerzo corrugado",
                "STR_Materialidad");

            // 6. Disciplina.
            SetearTodosLosParametrosTexto(
                rebar,
                "Estructuras",
                "GEN_Disciplina");

            // 7. ID del objeto Rebar creado.
            string idCreado = rebar.Id.Value.ToString(
                System.Globalization.CultureInfo.InvariantCulture);

            SetearTodosLosParametrosTexto(
                rebar,
                idCreado,
                "GEN_ID Elemento",
                "GEN_ID_Elemento");

            // 8. Copiar GEN_Nivel desde la INSTANCIA de la cimentación.
            // Si el anfitrión no tiene valor, no se modifica el acero.
            string nivel = ObtenerPrimerValorTexto(
                cimentacion,
                "GEN_Nivel");

            if (!string.IsNullOrWhiteSpace(nivel))
            {
                SetearTodosLosParametrosTexto(
                    rebar,
                    nivel,
                    "GEN_Nivel");
            }
        }
        catch
        {
            // Los parámetros no deben interrumpir la creación del acero.
        }
    }

    // =====================================
    // OBTENER DESCRIPCIÓN DEL TIPO DEL HOST
    // =====================================
    private string ObtenerDescripcionTipoCimentacion(
        Element cimentacion)
    {
        if (cimentacion == null || cimentacion.Document == null)
            return "";

        try
        {
            ElementId tipoId = cimentacion.GetTypeId();

            if (tipoId == null ||
                tipoId == ElementId.InvalidElementId)
            {
                return "";
            }

            Element tipo = cimentacion.Document.GetElement(tipoId);

            if (tipo == null)
                return "";

            Parameter descripcionBuiltIn = tipo.get_Parameter(
                BuiltInParameter.ALL_MODEL_DESCRIPTION);

            string valorBuiltIn = ObtenerTextoParametro(descripcionBuiltIn);

            if (!string.IsNullOrWhiteSpace(valorBuiltIn))
                return valorBuiltIn;

            return ObtenerPrimerValorTexto(
                tipo,
                "Descripción",
                "Descripcion",
                "Description");
        }
        catch
        {
            return "";
        }
    }

    // =====================================
    // LEER EL PRIMER VALOR NO VACÍO
    // ENTRE TODOS LOS PARÁMETROS DUPLICADOS
    // =====================================
    private string ObtenerPrimerValorTexto(
        Element elemento,
        params string[] nombres)
    {
        if (elemento == null || nombres == null)
            return "";

        foreach (string nombre in nombres)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                continue;

            try
            {
                IList<Parameter> parametros = elemento.GetParameters(nombre);

                if (parametros == null)
                    continue;

                foreach (Parameter parametro in parametros)
                {
                    string valor = ObtenerTextoParametro(parametro);

                    if (!string.IsNullOrWhiteSpace(valor))
                        return valor.Trim();
                }
            }
            catch
            {
            }
        }

        return "";
    }

    private string ObtenerTextoParametro(
        Parameter parametro)
    {
        if (parametro == null || !parametro.HasValue)
            return "";

        try
        {
            switch (parametro.StorageType)
            {
                case StorageType.String:
                    return parametro.AsString() ?? "";

                case StorageType.Integer:
                    return parametro.AsInteger().ToString(
                        System.Globalization.CultureInfo.InvariantCulture);

                case StorageType.Double:
                    string valorFormateado = parametro.AsValueString();

                    if (!string.IsNullOrWhiteSpace(valorFormateado))
                        return valorFormateado;

                    return parametro.AsDouble().ToString(
                        System.Globalization.CultureInfo.InvariantCulture);

                case StorageType.ElementId:
                    ElementId id = parametro.AsElementId();

                    if (id == null || id == ElementId.InvalidElementId)
                        return "";

                    Element elementoReferenciado =
                        parametro.Element.Document.GetElement(id);

                    if (elementoReferenciado != null &&
                        !string.IsNullOrWhiteSpace(elementoReferenciado.Name))
                    {
                        return elementoReferenciado.Name;
                    }

                    return id.Value.ToString(
                        System.Globalization.CultureInfo.InvariantCulture);
            }
        }
        catch
        {
        }

        return "";
    }

    // =====================================
    // ESCRIBIR EN TODOS LOS PARÁMETROS
    // QUE TENGAN EL MISMO NOMBRE
    // =====================================
    private void SetearTodosLosParametrosTexto(
        Element elemento,
        string valor,
        params string[] nombres)
    {
        if (elemento == null ||
            string.IsNullOrWhiteSpace(valor) ||
            nombres == null)
        {
            return;
        }

        foreach (string nombre in nombres)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                continue;

            try
            {
                IList<Parameter> parametros = elemento.GetParameters(nombre);

                if (parametros == null)
                    continue;

                foreach (Parameter parametro in parametros)
                {
                    SetearParametroTextoSeguro(parametro, valor);
                }
            }
            catch
            {
            }
        }
    }

    private bool SetearParametroTextoSeguro(
        Parameter parametro,
        string valor)
    {
        if (parametro == null ||
            parametro.IsReadOnly ||
            valor == null)
        {
            return false;
        }

        try
        {
            switch (parametro.StorageType)
            {
                case StorageType.String:
                    parametro.Set(valor);
                    return true;

                case StorageType.Integer:
                    if (int.TryParse(
                        valor,
                        System.Globalization.NumberStyles.Integer,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out int valorEntero))
                    {
                        parametro.Set(valorEntero);
                        return true;
                    }
                    break;

                case StorageType.ElementId:
                    if (long.TryParse(
                        valor,
                        System.Globalization.NumberStyles.Integer,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out long valorId))
                    {
                        parametro.Set(new ElementId(valorId));
                        return true;
                    }
                    break;

                case StorageType.Double:
                    // Los parámetros indicados por el usuario son de texto.
                    // Se intenta SetValueString únicamente como respaldo.
                    return parametro.SetValueString(valor);
            }
        }
        catch
        {
        }

        return false;
    }

    // =====================================
    // CONSTRUIR BARRAS EN DIRECCIÓN X
    // RESPETA HUECOS, RECUBRIMIENTO Y AJUSTA POSICIONES
    // =====================================
    private List<Barra2D> ConstruirBarrasX(
        List<List<UV>> loops2D,
        double minY,
        double maxY,
        double recubrimiento,
        double espaciamientoMaximo,
        double reduccionDistribucion,
        out double espaciamientoReal)
    {
        List<Barra2D> barras = new List<Barra2D>();

        List<double> posicionesY = ObtenerPosicionesDistribuidas(
            minY + recubrimiento + reduccionDistribucion,
            maxY - recubrimiento - reduccionDistribucion,
            espaciamientoMaximo,
            out espaciamientoReal);

        foreach (double y in posicionesY)
        {
            List<Tuple<double, double>> intervalos = ObtenerIntervalosX(loops2D, y);

            foreach (Tuple<double, double> intervalo in intervalos)
            {
                double x1 = intervalo.Item1 + recubrimiento;
                double x2 = intervalo.Item2 - recubrimiento;

                if (x2 <= x1)
                    continue;

                barras.Add(new Barra2D()
                {
                    Posicion = y,
                    A1 = x1,
                    A2 = x2
                });
            }
        }

        return barras;
    }

    // =====================================
    // CONSTRUIR BARRAS EN DIRECCIÓN Y
    // RESPETA HUECOS, RECUBRIMIENTO Y AJUSTA POSICIONES
    // =====================================
    private List<Barra2D> ConstruirBarrasY(
        List<List<UV>> loops2D,
        double minX,
        double maxX,
        double recubrimiento,
        double espaciamientoMaximo,
        double reduccionDistribucion,
        out double espaciamientoReal)
    {
        List<Barra2D> barras = new List<Barra2D>();

        List<double> posicionesX = ObtenerPosicionesDistribuidas(
            minX + recubrimiento + reduccionDistribucion,
            maxX - recubrimiento - reduccionDistribucion,
            espaciamientoMaximo,
            out espaciamientoReal);

        foreach (double x in posicionesX)
        {
            List<Tuple<double, double>> intervalos = ObtenerIntervalosY(loops2D, x);

            foreach (Tuple<double, double> intervalo in intervalos)
            {
                double y1 = intervalo.Item1 + recubrimiento;
                double y2 = intervalo.Item2 - recubrimiento;

                if (y2 <= y1)
                    continue;

                barras.Add(new Barra2D()
                {
                    Posicion = x,
                    A1 = y1,
                    A2 = y2
                });
            }
        }

        return barras;
    }

    // =====================================
    // OBTENER POSICIONES DISTRIBUIDAS
    // =====================================
    private List<double> ObtenerPosicionesDistribuidas(
        double inicio,
        double fin,
        double espaciamientoMaximo,
        out double espaciamientoReal)
    {
        List<double> posiciones = new List<double>();
        espaciamientoReal = espaciamientoMaximo;

        if (espaciamientoMaximo <= Tol)
            return posiciones;

        if (fin < inicio - Tol)
            return posiciones;

        double longitudUtil = fin - inicio;

        if (longitudUtil <= Tol)
        {
            posiciones.Add(inicio);
            espaciamientoReal = 0.0;
            return posiciones;
        }

        int numeroEspacios = Math.Max(
            1,
            (int)Math.Ceiling(longitudUtil / espaciamientoMaximo));

        espaciamientoReal = longitudUtil / numeroEspacios;

        for (int i = 0; i <= numeroEspacios; i++)
        {
            double pos = inicio + i * espaciamientoReal;

            if (i == numeroEspacios)
                pos = fin;

            posiciones.Add(pos);
        }

        return posiciones;
    }

    // =====================================
    // CALCULAR DESFASE DEL EMPALME HACIA EL NÚCLEO
    // =====================================
    private double CalcularDesfaseEmpalmeHaciaNucleo(
        double offsetActual,
        double offsetOtraDireccion,
        double diametroBarra,
        XYZ direccionUpElemento,
        XYZ direccionHaciaNucleo)
    {
        if (diametroBarra <= Tol)
            return 0.0;

        double signoHaciaNucleo = 1.0;

        if (direccionUpElemento != null &&
            direccionUpElemento.GetLength() > Tol &&
            direccionHaciaNucleo != null &&
            direccionHaciaNucleo.GetLength() > Tol)
        {
            double producto = direccionHaciaNucleo
                .Normalize()
                .DotProduct(direccionUpElemento.Normalize());

            signoHaciaNucleo = producto < 0.0 ? -1.0 : 1.0;
        }

        // Separación del eje de la barra actual hasta el eje de la barra
        // ortogonal, medida en el sentido hacia el núcleo.
        double separacionOtraHaciaNucleo =
            (offsetOtraDireccion - offsetActual) * signoHaciaNucleo;

        // ==============================================================
        // CONTROL MANUAL DE LA SEPARACIÓN ENTRE LOS DOS EMPALMES
        // ==============================================================
        // 1.0 significa que la separación libre CARA A CARA entre el
        // empalme longitudinal y el empalme transversal será exactamente
        // igual a 1 diámetro de la barra de la dirección opuesta.
        //
        // Ejemplos:
        // 0.5 = separación libre de medio diámetro.
        // 1.0 = separación libre de un diámetro.
        // 1.5 = separación libre de un diámetro y medio.
        double factorSeparacionLibreEmpalmes = 1.0;

        double separacionLibreEmpalmes =
            factorSeparacionLibreEmpalmes * diametroBarra;

        // Como las dos direcciones de una misma capa usan actualmente el
        // mismo tipo de barra, la separación requerida entre ejes es:
        // 0.5Ø + separación libre + 0.5Ø.
        double separacionEjesEmpalmes =
            diametroBarra + separacionLibreEmpalmes;

        double desfase;

        if (separacionOtraHaciaNucleo > Tol)
        {
            // Esta es la dirección más próxima al recubrimiento.
            // Su empalme queda como el más interior y se coloca a la
            // separación entre ejes requerida respecto del empalme de
            // la dirección opuesta.
            desfase =
                (2.0 * diametroBarra) + separacionEjesEmpalmes;
        }
        else
        {
            // Esta es la dirección que ya se encuentra más hacia el núcleo.
            // Se mantiene como el empalme inferior/interior de referencia.
            desfase =
                (2.0 * diametroBarra) + separacionOtraHaciaNucleo;
        }

        // El doblez nunca debe desplazarse hacia el recubrimiento.
        if (desfase < 0.0)
            desfase = 0.0;

        return desfase;
    }

    // =====================================
    // CREAR BARRAS X POR GRUPOS
    // =====================================
    private int CrearBarrasXPorGrupos(
        Document doc,
        Element cimentacion,
        RebarBarType barType,
        DatosCaraInferior datos,
        List<Barra2D> barras,
        double espaciamiento,
        double espaciamientoEtiqueta,
        double offsetVertical,
        double longitudMinima,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        int contador = 0;

        if (barras == null || barras.Count == 0)
            return contador;

        barras = barras
            .OrderBy(b => Math.Round(b.A1, 6))
            .ThenBy(b => Math.Round(b.A2, 6))
            .ThenBy(b => b.Posicion)
            .ToList();

        List<Barra2D> grupo = new List<Barra2D>();
        grupo.Add(barras[0]);

        for (int i = 1; i < barras.Count; i++)
        {
            Barra2D anterior = grupo[grupo.Count - 1];
            Barra2D actual = barras[i];

            if (EsMismoTramo(anterior, actual, espaciamiento))
            {
                grupo.Add(actual);
            }
            else
            {
                contador += ProcesarGrupoX(
                    doc,
                    cimentacion,
                    barType,
                    datos,
                    grupo,
                    espaciamiento,
                    espaciamientoEtiqueta,
                    offsetVertical,
                    longitudMinima,
                    colocarGancho,
                    longitudGancho,
                    direccionGancho,
                    considerarEmpalme,
                    longitudBarra,
                    longitudEmpalme,
                    diametroBarra,
                    desfaseEmpalme);

                grupo.Clear();
                grupo.Add(actual);
            }
        }

        contador += ProcesarGrupoX(
            doc,
            cimentacion,
            barType,
            datos,
            grupo,
            espaciamiento,
            espaciamientoEtiqueta,
            offsetVertical,
            longitudMinima,
            colocarGancho,
            longitudGancho,
            direccionGancho,
            considerarEmpalme,
            longitudBarra,
            longitudEmpalme,
            diametroBarra,
            desfaseEmpalme);

        return contador;
    }

    // =====================================
    // CREAR BARRAS Y POR GRUPOS
    // =====================================
    private int CrearBarrasYPorGrupos(
        Document doc,
        Element cimentacion,
        RebarBarType barType,
        DatosCaraInferior datos,
        List<Barra2D> barras,
        double espaciamiento,
        double espaciamientoEtiqueta,
        double offsetVertical,
        double longitudMinima,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        int contador = 0;

        if (barras == null || barras.Count == 0)
            return contador;

        barras = barras
            .OrderBy(b => Math.Round(b.A1, 6))
            .ThenBy(b => Math.Round(b.A2, 6))
            .ThenBy(b => b.Posicion)
            .ToList();

        List<Barra2D> grupo = new List<Barra2D>();
        grupo.Add(barras[0]);

        for (int i = 1; i < barras.Count; i++)
        {
            Barra2D anterior = grupo[grupo.Count - 1];
            Barra2D actual = barras[i];

            if (EsMismoTramo(anterior, actual, espaciamiento))
            {
                grupo.Add(actual);
            }
            else
            {
                contador += ProcesarGrupoY(
                    doc,
                    cimentacion,
                    barType,
                    datos,
                    grupo,
                    espaciamiento,
                    espaciamientoEtiqueta,
                    offsetVertical,
                    longitudMinima,
                    colocarGancho,
                    longitudGancho,
                    direccionGancho,
                    considerarEmpalme,
                    longitudBarra,
                    longitudEmpalme,
                    diametroBarra,
                    desfaseEmpalme);

                grupo.Clear();
                grupo.Add(actual);
            }
        }

        contador += ProcesarGrupoY(
            doc,
            cimentacion,
            barType,
            datos,
            grupo,
            espaciamiento,
            espaciamientoEtiqueta,
            offsetVertical,
            longitudMinima,
            colocarGancho,
            longitudGancho,
            direccionGancho,
            considerarEmpalme,
            longitudBarra,
            longitudEmpalme,
            diametroBarra,
            desfaseEmpalme);

        return contador;
    }

    // =====================================
    // PROCESAR GRUPO X
    // =====================================
    private int ProcesarGrupoX(
        Document doc,
        Element cimentacion,
        RebarBarType barType,
        DatosCaraInferior datos,
        List<Barra2D> grupo,
        double espaciamiento,
        double espaciamientoEtiqueta,
        double offsetVertical,
        double longitudMinima,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        if (grupo == null || grupo.Count == 0)
            return 0;

        grupo = grupo.OrderBy(b => b.Posicion).ToList();

        Barra2D primera = grupo.First();
        Barra2D ultima = grupo.Last();

        XYZ p1 = FromUV(new UV(primera.A1, primera.Posicion), datos, offsetVertical);
        XYZ p2 = FromUV(new UV(primera.A2, primera.Posicion), datos, offsetVertical);

        if (p1.DistanceTo(p2) < longitudMinima)
            return 0;

        if (grupo.Count >= 2 && espaciamiento > Tol)
        {
            double longitudDistribucion = Math.Abs(ultima.Posicion - primera.Posicion);

            int creados = CrearBarraConEspaciadoMaximo(
                doc,
                cimentacion,
                barType,
                datos.YAxis,
                p1,
                p2,
                espaciamiento,
                espaciamientoEtiqueta,
                longitudDistribucion,
                colocarGancho,
                longitudGancho,
                direccionGancho,
                considerarEmpalme,
                longitudBarra,
                longitudEmpalme,
                diametroBarra,
                desfaseEmpalme);

            if (creados > 0)
                return creados;
        }

        int contador = 0;

        foreach (Barra2D barra in grupo)
        {
            XYZ pi = FromUV(new UV(barra.A1, barra.Posicion), datos, offsetVertical);
            XYZ pf = FromUV(new UV(barra.A2, barra.Posicion), datos, offsetVertical);

            if (pi.DistanceTo(pf) < longitudMinima)
                continue;

            contador += CrearBarraIndividual(
                doc,
                cimentacion,
                barType,
                datos.YAxis,
                pi,
                pf,
                colocarGancho,
                longitudGancho,
                direccionGancho,
                considerarEmpalme,
                longitudBarra,
                longitudEmpalme,
                diametroBarra,
                desfaseEmpalme);
        }

        return contador;
    }

    // =====================================
    // PROCESAR GRUPO Y
    // =====================================
    private int ProcesarGrupoY(
        Document doc,
        Element cimentacion,
        RebarBarType barType,
        DatosCaraInferior datos,
        List<Barra2D> grupo,
        double espaciamiento,
        double espaciamientoEtiqueta,
        double offsetVertical,
        double longitudMinima,
        bool colocarGancho,
        double longitudGancho,
        XYZ direccionGancho,
        bool considerarEmpalme,
        double longitudBarra,
        double longitudEmpalme,
        double diametroBarra,
        double desfaseEmpalme)
    {
        if (grupo == null || grupo.Count == 0)
            return 0;

        grupo = grupo.OrderBy(b => b.Posicion).ToList();

        Barra2D primera = grupo.First();
        Barra2D ultima = grupo.Last();

        XYZ p1 = FromUV(new UV(primera.Posicion, primera.A1), datos, offsetVertical);
        XYZ p2 = FromUV(new UV(primera.Posicion, primera.A2), datos, offsetVertical);

        if (p1.DistanceTo(p2) < longitudMinima)
            return 0;

        if (grupo.Count >= 2 && espaciamiento > Tol)
        {
            double longitudDistribucion = Math.Abs(ultima.Posicion - primera.Posicion);

            int creados = CrearBarraConEspaciadoMaximo(
                doc,
                cimentacion,
                barType,
                datos.XAxis,
                p1,
                p2,
                espaciamiento,
                espaciamientoEtiqueta,
                longitudDistribucion,
                colocarGancho,
                longitudGancho,
                direccionGancho,
                considerarEmpalme,
                longitudBarra,
                longitudEmpalme,
                diametroBarra,
                desfaseEmpalme);

            if (creados > 0)
                return creados;
        }

        int contador = 0;

        foreach (Barra2D barra in grupo)
        {
            XYZ pi = FromUV(new UV(barra.Posicion, barra.A1), datos, offsetVertical);
            XYZ pf = FromUV(new UV(barra.Posicion, barra.A2), datos, offsetVertical);

            if (pi.DistanceTo(pf) < longitudMinima)
                continue;

            contador += CrearBarraIndividual(
                doc,
                cimentacion,
                barType,
                datos.XAxis,
                pi,
                pf,
                colocarGancho,
                longitudGancho,
                direccionGancho,
                considerarEmpalme,
                longitudBarra,
                longitudEmpalme,
                diametroBarra,
                desfaseEmpalme);
        }

        return contador;
    }

    // =====================================
    // VERIFICAR SI DOS BARRAS PERTENECEN AL MISMO TRAMO
    // =====================================
    private bool EsMismoTramo(
        Barra2D anterior,
        Barra2D actual,
        double espaciamiento)
    {
        double tolerancia = UnitUtils.ConvertToInternalUnits(
            0.5,
            UnitTypeId.Centimeters);

        bool mismaSeparacion =
            Math.Abs((actual.Posicion - anterior.Posicion) - espaciamiento) <= tolerancia;

        bool mismoInicio =
            Math.Abs(actual.A1 - anterior.A1) <= tolerancia;

        bool mismoFin =
            Math.Abs(actual.A2 - anterior.A2) <= tolerancia;

        return mismaSeparacion && mismoInicio && mismoFin;
    }

    // =====================================
    // OBTENER DATOS DE LA CARA INFERIOR
    // =====================================
    private DatosCaraInferior ObtenerDatosCaraInferior(Element elem)
    {
        PlanarFace caraInferior = ObtenerCaraInferior(elem);

        if (caraInferior == null)
            return null;

        CurveLoop loopExterior = ObtenerLoopExterior(caraInferior);

        if (loopExterior == null)
            return null;

        List<XYZ> puntosExterior = ObtenerPuntosLoop(loopExterior);

        if (puntosExterior.Count < 3)
            return null;

        XYZ normal = caraInferior.FaceNormal.Normalize();

        XYZ up = normal.Z < 0
            ? normal.Multiply(-1.0)
            : normal;

        XYZ xAxis = ObtenerEjeXPrincipal(puntosExterior, up);

        if (xAxis == null || xAxis.GetLength() < Tol)
            return null;

        xAxis = xAxis.Normalize();

        XYZ yAxis = up.CrossProduct(xAxis).Normalize();

        List<List<XYZ>> todosLosLoops = ObtenerTodosLosLoopsDeCara(
            caraInferior,
            caraInferior.Origin,
            xAxis,
            yAxis);

        if (todosLosLoops == null || todosLosLoops.Count == 0)
        {
            todosLosLoops = new List<List<XYZ>>();
            todosLosLoops.Add(puntosExterior);
        }

        double espesor = ObtenerEspesorElemento(elem, caraInferior.Origin, up);

        return new DatosCaraInferior()
        {
            Origin = caraInferior.Origin,
            XAxis = xAxis,
            YAxis = yAxis,
            Up = up,
            Espesor = espesor,
            Puntos3D = puntosExterior,
            LoopsPuntos3D = todosLosLoops
        };
    }

    // =====================================
    // OBTENER ESPESOR DEL ELEMENTO
    // =====================================
    private double ObtenerEspesorElemento(
        Element elem,
        XYZ origin,
        XYZ up)
    {
        Options opt = new Options();
        opt.ComputeReferences = true;
        opt.IncludeNonVisibleObjects = false;
        opt.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = elem.get_Geometry(opt);

        if (geo == null)
            return 0.0;

        double max = double.MinValue;

        foreach (Solid solid in ObtenerSolidos(geo))
        {
            if (solid == null || solid.Volume <= Tol)
                continue;

            foreach (Face face in solid.Faces)
            {
                IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

                if (loops == null)
                    continue;

                foreach (CurveLoop loop in loops)
                {
                    foreach (Curve c in loop)
                    {
                        IList<XYZ> pts = c.Tessellate();

                        foreach (XYZ p in pts)
                        {
                            double d = (p - origin).DotProduct(up);

                            if (d > max)
                                max = d;
                        }
                    }
                }
            }
        }

        if (max == double.MinValue)
            return 0.0;

        return max;
    }

    // =====================================
    // BUSCAR CARA INFERIOR MÁS GRANDE
    // =====================================
    private PlanarFace ObtenerCaraInferior(Element elem)
    {
        Options opt = new Options();
        opt.ComputeReferences = true;
        opt.IncludeNonVisibleObjects = false;
        opt.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = elem.get_Geometry(opt);

        if (geo == null)
            return null;

        PlanarFace mejorCara = null;
        double mayorArea = 0.0;

        foreach (Solid solid in ObtenerSolidos(geo))
        {
            if (solid == null)
                continue;

            if (solid.Volume <= Tol)
                continue;

            foreach (Face face in solid.Faces)
            {
                PlanarFace pf = face as PlanarFace;

                if (pf == null)
                    continue;

                XYZ n = pf.FaceNormal.Normalize();

                if (n.Z > -0.70)
                    continue;

                if (pf.Area > mayorArea)
                {
                    mayorArea = pf.Area;
                    mejorCara = pf;
                }
            }
        }

        return mejorCara;
    }

    // =====================================
    // OBTENER SÓLIDOS, INCLUYE GEOMETRYINSTANCE
    // =====================================
    private IEnumerable<Solid> ObtenerSolidos(GeometryElement geo)
    {
        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null && solid.Volume > Tol)
            {
                yield return solid;
                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                GeometryElement geoInst = gi.GetInstanceGeometry();

                if (geoInst == null)
                    continue;

                foreach (Solid s in ObtenerSolidos(geoInst))
                    yield return s;
            }
        }
    }

    // =====================================
    // OBTENER LOOP EXTERIOR DE MAYOR ÁREA
    // =====================================
    private CurveLoop ObtenerLoopExterior(PlanarFace face)
    {
        IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

        if (loops == null || loops.Count == 0)
            return null;

        CurveLoop mejorLoop = null;
        double mayorArea = 0.0;

        XYZ normal = face.FaceNormal.Normalize();

        XYZ up = normal.Z < 0
            ? normal.Multiply(-1.0)
            : normal;

        foreach (CurveLoop loop in loops)
        {
            List<XYZ> puntos = ObtenerPuntosLoop(loop);

            if (puntos.Count < 3)
                continue;

            XYZ xAxis = ObtenerEjeXPrincipal(puntos, up);

            if (xAxis == null || xAxis.GetLength() < Tol)
                continue;

            xAxis = xAxis.Normalize();

            XYZ yAxis = up.CrossProduct(xAxis).Normalize();

            List<UV> pts2D = puntos
                .Select(p => ToUV(p, face.Origin, xAxis, yAxis))
                .ToList();

            double area = Math.Abs(AreaPoligono(pts2D));

            if (area > mayorArea)
            {
                mayorArea = area;
                mejorLoop = loop;
            }
        }

        return mejorLoop;
    }

    // =====================================
    // OBTENER TODOS LOS LOOPS DE LA CARA
    // =====================================
    private List<List<XYZ>> ObtenerTodosLosLoopsDeCara(
        PlanarFace face,
        XYZ origin,
        XYZ xAxis,
        XYZ yAxis)
    {
        List<List<XYZ>> resultado = new List<List<XYZ>>();

        IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

        if (loops == null || loops.Count == 0)
            return resultado;

        foreach (CurveLoop loop in loops)
        {
            List<XYZ> puntos = ObtenerPuntosLoop(loop);

            if (puntos == null || puntos.Count < 3)
                continue;

            List<UV> puntos2D = puntos
                .Select(p => ToUV(p, origin, xAxis, yAxis))
                .ToList();

            LimpiarPoligono(puntos2D);

            if (puntos2D.Count < 3)
                continue;

            double area = Math.Abs(AreaPoligono(puntos2D));

            if (area <= Tol)
                continue;

            resultado.Add(puntos);
        }

        resultado = resultado
            .OrderByDescending(loop =>
            {
                List<UV> pts2D = loop
                    .Select(p => ToUV(p, origin, xAxis, yAxis))
                    .ToList();

                LimpiarPoligono(pts2D);

                return Math.Abs(AreaPoligono(pts2D));
            })
            .ToList();

        return resultado;
    }

    // =====================================
    // CONVERTIR LOOP A PUNTOS
    // =====================================
    private List<XYZ> ObtenerPuntosLoop(CurveLoop loop)
    {
        List<XYZ> puntos = new List<XYZ>();

        foreach (Curve c in loop)
        {
            IList<XYZ> pts = c.Tessellate();

            foreach (XYZ p in pts)
            {
                if (puntos.Count == 0 || puntos.Last().DistanceTo(p) > 0.001)
                    puntos.Add(p);
            }
        }

        if (puntos.Count > 1 && puntos.First().DistanceTo(puntos.Last()) < 0.001)
            puntos.RemoveAt(puntos.Count - 1);

        return puntos;
    }

    // =====================================
    // EJE PRINCIPAL DE LA CIMENTACIÓN
    // =====================================
    private XYZ ObtenerEjeXPrincipal(List<XYZ> puntos, XYZ normal)
    {
        XYZ mejor = null;
        double mayor = 0.0;

        for (int i = 0; i < puntos.Count; i++)
        {
            XYZ p1 = puntos[i];
            XYZ p2 = puntos[(i + 1) % puntos.Count];

            XYZ v = p2 - p1;

            v = v - normal.Multiply(v.DotProduct(normal));

            double len = v.GetLength();

            if (len > mayor)
            {
                mayor = len;
                mejor = v;
            }
        }

        if (mejor == null || mejor.GetLength() < Tol)
        {
            XYZ baseX = XYZ.BasisX;

            if (Math.Abs(baseX.DotProduct(normal)) > 0.90)
                baseX = XYZ.BasisY;

            mejor = baseX - normal.Multiply(baseX.DotProduct(normal));
        }

        return mejor;
    }

    // =====================================
    // XYZ A UV LOCAL
    // =====================================
    private UV ToUV(
        XYZ p,
        XYZ origin,
        XYZ xAxis,
        XYZ yAxis)
    {
        XYZ v = p - origin;

        return new UV(
            v.DotProduct(xAxis),
            v.DotProduct(yAxis));
    }

    // =====================================
    // UV LOCAL A XYZ
    // =====================================
    private XYZ FromUV(
        UV p,
        DatosCaraInferior datos,
        double offsetVertical)
    {
        return datos.Origin
            .Add(datos.XAxis.Multiply(p.U))
            .Add(datos.YAxis.Multiply(p.V))
            .Add(datos.Up.Multiply(offsetVertical));
    }

    // =====================================
    // LIMPIAR PUNTOS REPETIDOS
    // =====================================
    private void LimpiarPoligono(List<UV> puntos)
    {
        for (int i = puntos.Count - 1; i > 0; i--)
        {
            if (DistanciaUV(puntos[i], puntos[i - 1]) < 0.001)
                puntos.RemoveAt(i);
        }

        if (puntos.Count > 1 &&
            DistanciaUV(puntos[0], puntos[puntos.Count - 1]) < 0.001)
        {
            puntos.RemoveAt(puntos.Count - 1);
        }
    }

    private double DistanciaUV(UV a, UV b)
    {
        double dx = a.U - b.U;
        double dy = a.V - b.V;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    // =====================================
    // ÁREA DE POLÍGONO 2D
    // =====================================
    private double AreaPoligono(List<UV> pts)
    {
        double area = 0.0;

        for (int i = 0; i < pts.Count; i++)
        {
            UV p1 = pts[i];
            UV p2 = pts[(i + 1) % pts.Count];

            area += p1.U * p2.V - p2.U * p1.V;
        }

        return area / 2.0;
    }

    // =====================================
    // INTERVALOS PARA BARRAS EN X
    // =====================================
    private List<Tuple<double, double>> ObtenerIntervalosX(
        List<List<UV>> loops2D,
        double y)
    {
        List<double> cortes = new List<double>();

        foreach (List<UV> poligono in loops2D)
        {
            if (poligono == null || poligono.Count < 3)
                continue;

            for (int i = 0; i < poligono.Count; i++)
            {
                UV p1 = poligono[i];
                UV p2 = poligono[(i + 1) % poligono.Count];

                if (Math.Abs(p2.V - p1.V) < Tol)
                    continue;

                bool cruza =
                    (p1.V <= y && p2.V > y) ||
                    (p2.V <= y && p1.V > y);

                if (!cruza)
                    continue;

                double t = (y - p1.V) / (p2.V - p1.V);
                double x = p1.U + t * (p2.U - p1.U);

                cortes.Add(x);
            }
        }

        LimpiarCortes(cortes);

        List<Tuple<double, double>> intervalos =
            new List<Tuple<double, double>>();

        for (int i = 0; i + 1 < cortes.Count; i += 2)
        {
            double a = cortes[i];
            double b = cortes[i + 1];

            if (b - a > Tol)
                intervalos.Add(Tuple.Create(a, b));
        }

        return intervalos;
    }

    // =====================================
    // INTERVALOS PARA BARRAS EN Y
    // =====================================
    private List<Tuple<double, double>> ObtenerIntervalosY(
        List<List<UV>> loops2D,
        double x)
    {
        List<double> cortes = new List<double>();

        foreach (List<UV> poligono in loops2D)
        {
            if (poligono == null || poligono.Count < 3)
                continue;

            for (int i = 0; i < poligono.Count; i++)
            {
                UV p1 = poligono[i];
                UV p2 = poligono[(i + 1) % poligono.Count];

                if (Math.Abs(p2.U - p1.U) < Tol)
                    continue;

                bool cruza =
                    (p1.U <= x && p2.U > x) ||
                    (p2.U <= x && p1.U > x);

                if (!cruza)
                    continue;

                double t = (x - p1.U) / (p2.U - p1.U);
                double y = p1.V + t * (p2.V - p1.V);

                cortes.Add(y);
            }
        }

        LimpiarCortes(cortes);

        List<Tuple<double, double>> intervalos =
            new List<Tuple<double, double>>();

        for (int i = 0; i + 1 < cortes.Count; i += 2)
        {
            double a = cortes[i];
            double b = cortes[i + 1];

            if (b - a > Tol)
                intervalos.Add(Tuple.Create(a, b));
        }

        return intervalos;
    }

    // =====================================
    // LIMPIAR CORTES CASI DUPLICADOS
    // =====================================
    private void LimpiarCortes(List<double> cortes)
    {
        if (cortes == null || cortes.Count == 0)
            return;

        cortes.Sort();

        double tolerancia = UnitUtils.ConvertToInternalUnits(
            0.05,
            UnitTypeId.Centimeters);

        List<double> limpios = new List<double>();

        foreach (double c in cortes)
        {
            if (limpios.Count == 0)
            {
                limpios.Add(c);
                continue;
            }

            double ultimo = limpios[limpios.Count - 1];

            if (Math.Abs(c - ultimo) > tolerancia)
            {
                limpios.Add(c);
            }
        }

        cortes.Clear();
        cortes.AddRange(limpios);
    }

    // =====================================
    // OBTENER DIÁMETRO DE BARRA
    // =====================================
    private double ObtenerDiametroBarra(RebarBarType barType)
    {
        Parameter p = barType.get_Parameter(
            BuiltInParameter.REBAR_BAR_DIAMETER);

        if (p != null && p.StorageType == StorageType.Double)
            return p.AsDouble();

        Parameter p2 = barType.LookupParameter("Diámetro de barra");

        if (p2 != null && p2.StorageType == StorageType.Double)
            return p2.AsDouble();

        Parameter p3 = barType.LookupParameter("Bar Diameter");

        if (p3 != null && p3.StorageType == StorageType.Double)
            return p3.AsDouble();

        return 0.0;
    }

    // =====================================
    // OBTENER DIÁMETRO DE CURVATURA ESTÁNDAR
    // =====================================
    private double ObtenerDiametroCurvaturaEstandar(RebarBarType barType)
    {
        string[] nombres =
        {
            "Diámetro de curvatura estándar",
            "Diametro de curvatura estándar",
            "Diámetro de curvatura estandar",
            "Diametro de curvatura estandar",
            "Standard Bend Diameter"
        };

        foreach (string nombre in nombres)
        {
            Parameter p = barType.LookupParameter(nombre);

            if (p != null && p.StorageType == StorageType.Double)
            {
                double valor = p.AsDouble();

                if (valor > Tol)
                    return valor;
            }
        }

        return 0.0;
    }

    // =====================================
    // LEER NÚMERO DECIMAL
    // =====================================
    private bool TryLeerDouble(
        string texto,
        out double valor)
    {
        valor = 0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        texto = texto.Trim().Replace(",", ".");

        return double.TryParse(
            texto,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor);
    }
}