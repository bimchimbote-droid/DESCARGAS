﻿// =====================================
// FILTRO DE SELECCIÓN - CIMENTACIÓN ESTRUCTURAL
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System.Collections.Generic;

public class CimentacionEstructuralSelectionFilter : ISelectionFilter
{
    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        if (elem.Category == null)
            return false;

        // Revit 2027: usar Value, no IntegerValue
        return elem.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFoundation;
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        return false;
    }
}

// =====================================
// HANDLER - SELECCIONAR CIMENTACIONES
// =====================================
public class SeleccionarCimentacionesAceroHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public AceroCimentacionForm Form;

    public List<ElementId> CimentacionesSeleccionadas = new List<ElementId>();

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
            return;

        try
        {
            IList<Reference> refs = uidoc.Selection.PickObjects(
                ObjectType.Element,
                new CimentacionEstructuralSelectionFilter(),
                "Seleccione cimentaciones estructurales");

            CimentacionesSeleccionadas.Clear();

            foreach (Reference r in refs)
            {
                if (r == null)
                    continue;

                ElementId id = r.ElementId;

                if (id == null || id == ElementId.InvalidElementId)
                    continue;

                if (!CimentacionesSeleccionadas.Contains(id))
                {
                    CimentacionesSeleccionadas.Add(id);
                }
            }

            uidoc.Selection.SetElementIds(CimentacionesSeleccionadas);

            Form?.ActualizarCantidad(CimentacionesSeleccionadas.Count);
        }
        catch
        {
            // Se cancela con ESC sin mostrar error
        }
    }

    public string GetName()
    {
        return "Seleccionar cimentaciones estructurales";
    }
}
