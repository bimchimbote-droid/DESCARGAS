using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{




    // ===============================
    // COMANDO 3.3 (ACERO CIMENTACIÓN)
    // ===============================
    [Transaction(TransactionMode.Manual)]
    public class AceroCimentacionCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
            {
                message = "No hay documento activo.";
                return Result.Failed;
            }

            Document doc = uidoc.Document;

            //-------------------------------------------------
            // MOSTRAR VENTANA
            //-------------------------------------------------
            AceroCimentacionForm form = new AceroCimentacionForm();

            //-------------------------------------------------
            // LLENAR COMBO DE TIPOS DE ARMADURA ESTRUCTURAL
            //-------------------------------------------------
            List<RebarBarType> tiposArmadura = new FilteredElementCollector(doc)
                .OfClass(typeof(RebarBarType))
                .Cast<RebarBarType>()
                .OrderBy(x => x.Name)
                .ToList();

            if (tiposArmadura.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "No se encontraron tipos de armadura estructural en el proyecto.");

                return Result.Cancelled;
            }

            form.CargarTiposArmadura(tiposArmadura);

            //-------------------------------------------------
            // LLENAR COMBO DE RECUBRIMIENTOS CONFIGURADOS
            //-------------------------------------------------
            // RebarCoverType es un ElementType. Se recogen primero todos los
            // ElementType del documento y después se filtran en .NET. Este método
            // es más robusto para RebarCoverType que depender únicamente de OfClass.
            List<RebarCoverType> tiposRecubrimiento = new FilteredElementCollector(doc)
                .WhereElementIsElementType()
                .ToElements()
                .OfType<RebarCoverType>()
                .Where(x => x != null)
                .OrderBy(x => x.Name)
                .ToList();

            // Respaldo para versiones/proyectos donde el filtro por ElementType
            // no devuelva directamente los tipos de recubrimiento.
            if (tiposRecubrimiento.Count == 0)
            {
                try
                {
                    tiposRecubrimiento = new FilteredElementCollector(doc)
                        .OfClass(typeof(RebarCoverType))
                        .Cast<RebarCoverType>()
                        .Where(x => x != null)
                        .OrderBy(x => x.Name)
                        .ToList();
                }
                catch
                {
                    tiposRecubrimiento = new List<RebarCoverType>();
                }
            }

            if (tiposRecubrimiento.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "No se encontraron configuraciones de recubrimiento de armadura en el proyecto.");

                return Result.Cancelled;
            }

            form.CargarRecubrimientos(tiposRecubrimiento);

            //-------------------------------------------------
            // HANDLER SELECCIONAR CIMENTACIONES
            //-------------------------------------------------
            var seleccionarHandler = new SeleccionarCimentacionesAceroHandler();
            seleccionarHandler.UiDoc = uidoc;
            seleccionarHandler.Form = form;

            ExternalEvent seleccionarEvent = ExternalEvent.Create(seleccionarHandler);

            form.SeleccionarHandler = seleccionarHandler;
            form.SeleccionarEvent = seleccionarEvent;

            //-------------------------------------------------
            // HANDLER EJECUTAR ACERO
            //-------------------------------------------------
            var ejecutarHandler = new EjecutarAceroCimentacionHandler();
            ejecutarHandler.UiDoc = uidoc;
            ejecutarHandler.Form = form;
            ejecutarHandler.SeleccionHandler = seleccionarHandler;

            ExternalEvent ejecutarEvent = ExternalEvent.Create(ejecutarHandler);

            form.EjecutarHandler = ejecutarHandler;
            form.EjecutarEvent = ejecutarEvent;

            //-------------------------------------------------
            // MOSTRAR VENTANA MODELESS
            //-------------------------------------------------
            form.Show();

            return Result.Succeeded;
        }
    }

}
