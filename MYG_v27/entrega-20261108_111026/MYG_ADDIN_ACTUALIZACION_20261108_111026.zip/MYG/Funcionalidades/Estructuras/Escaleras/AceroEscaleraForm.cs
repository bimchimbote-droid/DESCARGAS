using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA EMERGENTE 3.6
    // ACERO EN ESCALERA
    // SIN USING NI NAMESPACE
    // =====================================
    public class AceroEscaleraForm : WinForms.Form
    {
        public WinForms.ComboBox cmbTipoPrincipal;
        public WinForms.ComboBox cmbTipoReparticion;

        WinForms.TextBox txtEspaciamientoPrincipal;
        WinForms.TextBox txtEspaciamientoReparticion;
        WinForms.TextBox txtRecubrimientoInferior;
        WinForms.TextBox txtRecubrimientoLateral;

        WinForms.CheckBox chkCrearPrincipal;
        WinForms.CheckBox chkCrearReparticion;
        WinForms.CheckBox chkCompletarParametros;

        WinForms.Label lblCantidad;
        WinForms.Label lblEstado;

        public WinForms.Button btnSeleccionar;
        public WinForms.Button btnEjecutar;

        public ExternalEvent ExternalEvent;
        public AceroEscaleraHandler Handler;

        private static string ultimoTipoPrincipal = "";
        private static string ultimoTipoReparticion = "";
        private static string ultimoEspaciamientoPrincipal = "15";
        private static string ultimoEspaciamientoReparticion = "20";
        private static string ultimoRecubrimientoInferior = "2.5";
        private static string ultimoRecubrimientoLateral = "2.5";
        private static bool ultimoCrearPrincipal = true;
        private static bool ultimoCrearReparticion = true;
        private static bool ultimoCompletarParametros = true;

        public RebarBarType TipoPrincipalSeleccionado
        {
            get { return cmbTipoPrincipal.SelectedItem as RebarBarType; }
        }

        public RebarBarType TipoReparticionSeleccionado
        {
            get { return cmbTipoReparticion.SelectedItem as RebarBarType; }
        }

        public string EspaciamientoPrincipalTexto
        {
            get { return txtEspaciamientoPrincipal.Text.Trim(); }
        }

        public string EspaciamientoReparticionTexto
        {
            get { return txtEspaciamientoReparticion.Text.Trim(); }
        }

        public string RecubrimientoInferiorTexto
        {
            get { return txtRecubrimientoInferior.Text.Trim(); }
        }

        public string RecubrimientoLateralTexto
        {
            get { return txtRecubrimientoLateral.Text.Trim(); }
        }

        public bool CrearPrincipal
        {
            get { return chkCrearPrincipal.Checked; }
        }

        public bool CrearReparticion
        {
            get { return chkCrearReparticion.Checked; }
        }

        public bool CompletarParametros
        {
            get { return chkCompletarParametros.Checked; }
        }

        public AceroEscaleraForm()
        {
            this.Text = "MYG - Acero en Escalera";
            this.Width = 440;
            this.Height = 535;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            WinForms.Label lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 12,
                Width = 385,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "REFUERZO DE TRAMOS DE ESCALERA",
                Left = 20,
                Top = 42,
                Width = 385,
                Height = 24,
                TextAlign = Drawing.ContentAlignment.MiddleCenter,
                Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 90, 160)
            };

            WinForms.Label lblRecubrimientoInferior =
                CrearLabel("Recubrimiento inferior:", 20, 80, 175);

            txtRecubrimientoInferior =
                CrearTextBox(ultimoRecubrimientoInferior, 200, 78, 75);

            WinForms.Label lblCmRecubrimientoInferior =
                CrearLabelUnidad("cm", 285, 80);

            WinForms.Label lblRecubrimientoLateral =
                CrearLabel("Recubrimiento lateral:", 20, 112, 175);

            txtRecubrimientoLateral =
                CrearTextBox(ultimoRecubrimientoLateral, 200, 110, 75);

            WinForms.Label lblCmRecubrimientoLateral =
                CrearLabelUnidad("cm", 285, 112);

            WinForms.Label linea1 = new WinForms.Label()
            {
                Left = 20,
                Top = 145,
                Width = 385,
                Height = 1,
                BackColor = Drawing.Color.FromArgb(210, 210, 210)
            };

            chkCrearPrincipal = new WinForms.CheckBox()
            {
                Text = "Crear acero principal inferior",
                Left = 20,
                Top = 158,
                Width = 260,
                Height = 24,
                Checked = ultimoCrearPrincipal,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(40, 40, 40),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            WinForms.Label lblTipoPrincipal =
                CrearLabel("Tipo de barra:", 20, 190, 120);

            cmbTipoPrincipal = CrearCombo(145, 187, 260);

            WinForms.Label lblEspaciamientoPrincipal =
                CrearLabel("Espaciamiento:", 20, 222, 120);

            txtEspaciamientoPrincipal =
                CrearTextBox(ultimoEspaciamientoPrincipal, 145, 220, 75);

            WinForms.Label lblCmPrincipal =
                CrearLabelUnidad("cm", 230, 222);

            chkCrearReparticion = new WinForms.CheckBox()
            {
                Text = "Crear acero de repartición",
                Left = 20,
                Top = 260,
                Width = 260,
                Height = 24,
                Checked = ultimoCrearReparticion,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(40, 40, 40),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            WinForms.Label lblTipoReparticion =
                CrearLabel("Tipo de barra:", 20, 292, 120);

            cmbTipoReparticion = CrearCombo(145, 289, 260);

            WinForms.Label lblEspaciamientoReparticion =
                CrearLabel("Espaciamiento:", 20, 324, 120);

            txtEspaciamientoReparticion =
                CrearTextBox(ultimoEspaciamientoReparticion, 145, 322, 75);

            WinForms.Label lblCmReparticion =
                CrearLabelUnidad("cm", 230, 324);

            chkCompletarParametros = new WinForms.CheckBox()
            {
                Text = "Completar Comentarios y Marca",
                Left = 20,
                Top = 358,
                Width = 280,
                Height = 24,
                Checked = ultimoCompletarParametros,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            btnSeleccionar = new WinForms.Button()
            {
                Text = "SELECCIONAR TRAMOS DE ESCALERA",
                Left = 20,
                Top = 392,
                Width = 385,
                Height = 32,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionar.FlatAppearance.BorderSize = 0;

            lblCantidad = new WinForms.Label()
            {
                Text = "Tramos seleccionados: 0",
                Left = 20,
                Top = 430,
                Width = 385,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            lblEstado = new WinForms.Label()
            {
                Text = "",
                Left = 20,
                Top = 452,
                Width = 235,
                Height = 24,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.FromArgb(0, 100, 175)
            };

            btnEjecutar = new WinForms.Button()
            {
                Text = "CREAR ACERO",
                Left = 275,
                Top = 448,
                Width = 130,
                Height = 32,
                BackColor = Drawing.Color.FromArgb(0, 120, 190),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;

            chkCrearPrincipal.CheckedChanged += (s, e) =>
            {
                ActualizarEstadoControles();
                GuardarValoresRecordados();
            };

            chkCrearReparticion.CheckedChanged += (s, e) =>
            {
                ActualizarEstadoControles();
                GuardarValoresRecordados();
            };

            cmbTipoPrincipal.SelectedIndexChanged += (s, e) => GuardarValoresRecordados();
            cmbTipoReparticion.SelectedIndexChanged += (s, e) => GuardarValoresRecordados();
            txtEspaciamientoPrincipal.TextChanged += (s, e) => GuardarValoresRecordados();
            txtEspaciamientoReparticion.TextChanged += (s, e) => GuardarValoresRecordados();
            txtRecubrimientoInferior.TextChanged += (s, e) => GuardarValoresRecordados();
            txtRecubrimientoLateral.TextChanged += (s, e) => GuardarValoresRecordados();
            chkCompletarParametros.CheckedChanged += (s, e) => GuardarValoresRecordados();

            btnSeleccionar.Click += (s, e) =>
            {
                if (Handler == null || ExternalEvent == null)
                    return;

                GuardarValoresRecordados();
                Handler.Accion = AceroEscaleraAccion.Seleccionar;
                ExternalEvent.Raise();
            };

            btnEjecutar.Click += (s, e) =>
            {
                if (Handler == null || ExternalEvent == null)
                    return;

                GuardarValoresRecordados();
                Handler.Accion = AceroEscaleraAccion.Ejecutar;
                ExternalEvent.Raise();
            };

            this.FormClosed += (s, e) =>
            {
                GuardarValoresRecordados();

                if (Handler != null)
                    Handler.Form = null;
            };

            this.Controls.Add(lblAutor);
            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblRecubrimientoInferior);
            this.Controls.Add(txtRecubrimientoInferior);
            this.Controls.Add(lblCmRecubrimientoInferior);
            this.Controls.Add(lblRecubrimientoLateral);
            this.Controls.Add(txtRecubrimientoLateral);
            this.Controls.Add(lblCmRecubrimientoLateral);
            this.Controls.Add(linea1);
            this.Controls.Add(chkCrearPrincipal);
            this.Controls.Add(lblTipoPrincipal);
            this.Controls.Add(cmbTipoPrincipal);
            this.Controls.Add(lblEspaciamientoPrincipal);
            this.Controls.Add(txtEspaciamientoPrincipal);
            this.Controls.Add(lblCmPrincipal);
            this.Controls.Add(chkCrearReparticion);
            this.Controls.Add(lblTipoReparticion);
            this.Controls.Add(cmbTipoReparticion);
            this.Controls.Add(lblEspaciamientoReparticion);
            this.Controls.Add(txtEspaciamientoReparticion);
            this.Controls.Add(lblCmReparticion);
            this.Controls.Add(chkCompletarParametros);
            this.Controls.Add(btnSeleccionar);
            this.Controls.Add(lblCantidad);
            this.Controls.Add(lblEstado);
            this.Controls.Add(btnEjecutar);

            ActualizarEstadoControles();
        }

        private WinForms.Label CrearLabel(
            string texto,
            int left,
            int top,
            int width)
        {
            return new WinForms.Label()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };
        }

        private WinForms.Label CrearLabelUnidad(
            string texto,
            int left,
            int top)
        {
            return new WinForms.Label()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = 40,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8F),
                ForeColor = Drawing.Color.Gray
            };
        }

        private WinForms.TextBox CrearTextBox(
            string texto,
            int left,
            int top,
            int width)
        {
            return new WinForms.TextBox()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };
        }

        private WinForms.ComboBox CrearCombo(
            int left,
            int top,
            int width)
        {
            WinForms.ComboBox combo = new WinForms.ComboBox()
            {
                Left = left,
                Top = top,
                Width = width,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                MaxDropDownItems = 12,
                IntegralHeight = false,
                FormattingEnabled = true
            };

            //-------------------------------------------------
            // MOSTRAR EL NOMBRE REAL DEL TIPO DE BARRA
            // EN LUGAR DE:
            // Autodesk.Revit.DB.Structure.RebarBarType
            //-------------------------------------------------
            combo.Format += (s, e) =>
            {
                RebarBarType tipo = e.ListItem as RebarBarType;

                if (tipo != null)
                    e.Value = tipo.Name;
            };

            return combo;
        }

        public void CargarTiposArmadura(List<RebarBarType> tipos)
        {
            cmbTipoPrincipal.Items.Clear();
            cmbTipoReparticion.Items.Clear();

            foreach (RebarBarType tipo in tipos)
            {
                cmbTipoPrincipal.Items.Add(tipo);
                cmbTipoReparticion.Items.Add(tipo);
            }

            if (!SeleccionarComboPorNombre(cmbTipoPrincipal, ultimoTipoPrincipal))
            {
                if (cmbTipoPrincipal.Items.Count > 0)
                    cmbTipoPrincipal.SelectedIndex = 0;
            }

            if (!SeleccionarComboPorNombre(cmbTipoReparticion, ultimoTipoReparticion))
            {
                if (cmbTipoReparticion.Items.Count > 0)
                    cmbTipoReparticion.SelectedIndex =
                        cmbTipoReparticion.Items.Count > 1 ? 1 : 0;
            }
        }

        public void ActualizarCantidad(int cantidad)
        {
            if (this.IsDisposed)
                return;

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => ActualizarCantidad(cantidad)));
                return;
            }

            lblCantidad.Text = "Tramos seleccionados: " + cantidad;
        }

        public void ActualizarEstado(string texto)
        {
            if (this.IsDisposed)
                return;

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => ActualizarEstado(texto)));
                return;
            }

            lblEstado.Text = texto ?? "";
        }

        private void ActualizarEstadoControles()
        {
            cmbTipoPrincipal.Enabled = chkCrearPrincipal.Checked;
            txtEspaciamientoPrincipal.Enabled = chkCrearPrincipal.Checked;
            cmbTipoReparticion.Enabled = chkCrearReparticion.Checked;
            txtEspaciamientoReparticion.Enabled = chkCrearReparticion.Checked;
        }

        private void GuardarValoresRecordados()
        {
            ultimoTipoPrincipal = ObtenerNombreTipo(cmbTipoPrincipal);
            ultimoTipoReparticion = ObtenerNombreTipo(cmbTipoReparticion);

            ultimoEspaciamientoPrincipal =
                txtEspaciamientoPrincipal != null
                ? txtEspaciamientoPrincipal.Text.Trim()
                : "15";

            ultimoEspaciamientoReparticion =
                txtEspaciamientoReparticion != null
                ? txtEspaciamientoReparticion.Text.Trim()
                : "20";

            ultimoRecubrimientoInferior =
                txtRecubrimientoInferior != null
                ? txtRecubrimientoInferior.Text.Trim()
                : "2.5";

            ultimoRecubrimientoLateral =
                txtRecubrimientoLateral != null
                ? txtRecubrimientoLateral.Text.Trim()
                : "2.5";

            ultimoCrearPrincipal =
                chkCrearPrincipal != null && chkCrearPrincipal.Checked;

            ultimoCrearReparticion =
                chkCrearReparticion != null && chkCrearReparticion.Checked;

            ultimoCompletarParametros =
                chkCompletarParametros != null && chkCompletarParametros.Checked;
        }

        private string ObtenerNombreTipo(WinForms.ComboBox combo)
        {
            if (combo == null || combo.SelectedItem == null)
                return "";

            RebarBarType tipo = combo.SelectedItem as RebarBarType;

            if (tipo != null)
                return tipo.Name;

            return combo.SelectedItem.ToString();
        }

        private bool SeleccionarComboPorNombre(
            WinForms.ComboBox combo,
            string nombre)
        {
            if (combo == null || string.IsNullOrWhiteSpace(nombre))
                return false;

            for (int i = 0; i < combo.Items.Count; i++)
            {
                RebarBarType tipo = combo.Items[i] as RebarBarType;

                if (tipo == null)
                    continue;

                if (tipo.Name.Equals(
                    nombre,
                    System.StringComparison.OrdinalIgnoreCase))
                {
                    combo.SelectedIndex = i;
                    return true;
                }
            }

            return false;
        }
    }

}
