using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // ===============================
    // COMANDO 3.6 (ACERO ESCALERA)
    // SIN USING NI NAMESPACE
    // ===============================
    [Transaction(TransactionMode.Manual)]
    public class AceroEscaleraCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null)
                return Result.Cancelled;

            Document doc = uidoc.Document;

            //-------------------------------------------------
            // BUSCAR TIPOS DE ARMADURA
            //-------------------------------------------------
            List<RebarBarType> tiposArmadura = new FilteredElementCollector(doc)
                .OfClass(typeof(RebarBarType))
                .Cast<RebarBarType>()
                .OrderBy(x => x.Name)
                .ToList();

            if (tiposArmadura.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "No se encontraron tipos de armadura estructural en el proyecto.");

                return Result.Cancelled;
            }

            //-------------------------------------------------
            // CREAR VENTANA
            //-------------------------------------------------
            AceroEscaleraForm form = new AceroEscaleraForm();
            form.CargarTiposArmadura(tiposArmadura);

            //-------------------------------------------------
            // UN SOLO HANDLER PARA SELECCIÓN Y EJECUCIÓN
            //-------------------------------------------------
            AceroEscaleraHandler handler = new AceroEscaleraHandler
            {
                UiDoc = uidoc,
                Form = form
            };

            ExternalEvent externalEvent = ExternalEvent.Create(handler);

            form.Handler = handler;
            form.ExternalEvent = externalEvent;

            //-------------------------------------------------
            // MOSTRAR VENTANA MODELESS
            //-------------------------------------------------
            form.Show();

            return Result.Succeeded;
        }
    }

}
