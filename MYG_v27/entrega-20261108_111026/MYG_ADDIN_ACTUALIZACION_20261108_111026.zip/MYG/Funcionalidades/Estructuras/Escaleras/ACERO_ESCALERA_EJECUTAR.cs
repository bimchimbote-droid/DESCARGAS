﻿// =====================================
// ÚNICO HANDLER 3.6
// ACERO EN ESCALERA NATIVA - REVIT 2027
//
// FUNCIONES:
// 1. Selecciona StairsRun.
// 2. Analiza únicamente la geometría del tramo.
// 3. Resuelve el anfitrión válido de la armadura.
// 4. Crea acero principal con:
//    - Anclaje horizontal inferior.
//    - Tramo inclinado.
//    - Anclaje horizontal superior.
// 5. Crea barras transversales de repartición
//    siguiendo las tres zonas del perfil.
//
// CON USING - SIN NAMESPACE
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

public enum AceroEscaleraAccion
{
    Ninguna,
    Seleccionar,
    Ejecutar
}

// =====================================
// FILTRO DE SELECCIÓN
// =====================================
public class AceroEscaleraSelectionFilter : ISelectionFilter
{
    public bool AllowElement(Element elem)
    {
        if (elem == null || elem.Category == null)
            return false;

        long categoria = elem.Category.Id.Value;

        // Tramo de escalera nativo
        if (categoria == (long)BuiltInCategory.OST_StairsRuns)
            return true;

        // Se mantiene soporte para suelos estructurales inclinados.
        if (categoria == (long)BuiltInCategory.OST_Floors)
        {
            Floor floor = elem as Floor;

            if (floor == null)
                return false;

            Parameter parametroEstructural =
                floor.get_Parameter(
                    BuiltInParameter.FLOOR_PARAM_IS_STRUCTURAL);

            return parametroEstructural != null &&
                   parametroEstructural.StorageType == StorageType.Integer &&
                   parametroEstructural.AsInteger() == 1;
        }

        return false;
    }

    public bool AllowReference(
        Reference reference,
        XYZ position)
    {
        return false;
    }
}

// =====================================
// HANDLER PRINCIPAL
// =====================================
public class AceroEscaleraHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public AceroEscaleraForm Form;

    public AceroEscaleraAccion Accion =
        AceroEscaleraAccion.Ninguna;

    public List<ElementId> TramosSeleccionados =
        new List<ElementId>();

    private const double Tol = 1e-7;

    // Longitud automática de ingreso en descansos/apoyos.
    // Se utiliza mientras la ventana no tenga campos específicos.
    private const double LongitudAnclajeAutomaticaCm = 60.0;

    // =====================================
    // DATOS GEOMÉTRICOS DEL TRAMO
    // =====================================
    private class DatosTramoEscalera
    {
        public Element Tramo;
        public Element HostAcero;

        public PlanarFace CaraInferior;

        // Normal exterior de la cara inferior.
        public XYZ NormalCaraInferior;

        // Dirección desde la cara inferior hacia el concreto.
        public XYZ DireccionInterior;

        // Dirección real de subida del tramo.
        public XYZ DireccionPendiente;

        // Proyección horizontal de la dirección de subida.
        public XYZ DireccionHorizontal;

        // Dirección transversal del ancho.
        public XYZ DireccionTransversal;

        // Normal del plano vertical donde se dibuja la barra principal.
        public XYZ NormalPlanoPrincipal;

        public XYZ Origen;

        public double MinU;
        public double MaxU;
        public double MinV;
        public double MaxV;

        public double LongitudInclinada;
        public double Ancho;

        public List<XYZ> PuntosCara =
            new List<XYZ>();
    }

    // =====================================
    // PERFIL DE LA BARRA PRINCIPAL
    // =====================================
    private class PerfilPrincipal
    {
        public XYZ PuntoInicioHorizontal;
        public XYZ PuntoInicioPendiente;
        public XYZ PuntoFinPendiente;
        public XYZ PuntoFinHorizontal;

        public XYZ DireccionHorizontal;
        public XYZ DireccionPendiente;

        public double LongitudHorizontalInferior;
        public double LongitudPendiente;
        public double LongitudHorizontalSuperior;

        public List<Curve> Curvas =
            new List<Curve>();
    }

    // =====================================
    // RESULTADO DE CREACIÓN
    // =====================================
    private class ResultadoCreacion
    {
        public int CantidadObjetos;
        public List<ElementId> Ids =
            new List<ElementId>();
    }

    // =====================================
    // EXECUTE
    // =====================================
    public void Execute(UIApplication app)
    {
        UIDocument uidoc =
            UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
            return;

        try
        {
            if (Accion == AceroEscaleraAccion.Seleccionar)
            {
                SeleccionarTramos(uidoc);
            }
            else if (Accion == AceroEscaleraAccion.Ejecutar)
            {
                EjecutarAcero(uidoc);
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            Form?.ActualizarEstado("Selección cancelada.");
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG",
                "Se produjo un error:\n\n" +
                ex.Message);
        }
        finally
        {
            Accion = AceroEscaleraAccion.Ninguna;
        }
    }

    // =====================================
    // SELECCIONAR TRAMOS
    // =====================================
    private void SeleccionarTramos(
        UIDocument uidoc)
    {
        if (Form == null || Form.IsDisposed)
            return;

        Form.ActualizarEstado(
            "Seleccione uno o varios tramos.");

        IList<Reference> referencias =
            uidoc.Selection.PickObjects(
                ObjectType.Element,
                new AceroEscaleraSelectionFilter(),
                "Seleccione tramos nativos de escalera");

        List<ElementId> nuevosIds =
            new List<ElementId>();

        foreach (Reference referencia in referencias)
        {
            if (referencia == null)
                continue;

            ElementId id = referencia.ElementId;

            if (id == null ||
                id == ElementId.InvalidElementId)
            {
                continue;
            }

            if (!nuevosIds.Contains(id))
                nuevosIds.Add(id);
        }

        TramosSeleccionados.Clear();
        TramosSeleccionados.AddRange(nuevosIds);

        uidoc.Selection.SetElementIds(
            TramosSeleccionados);

        Form.ActualizarCantidad(
            TramosSeleccionados.Count);

        Form.ActualizarEstado(
            TramosSeleccionados.Count > 0
                ? "Selección completada."
                : "No se seleccionaron tramos.");
    }

    // =====================================
    // EJECUTAR ACERO
    // =====================================
    private void EjecutarAcero(
        UIDocument uidoc)
    {
        Document doc = uidoc.Document;

        if (Form == null || Form.IsDisposed)
            return;

        if (TramosSeleccionados == null ||
            TramosSeleccionados.Count == 0)
        {
            TaskDialog.Show(
                "MYG",
                "Primero debe seleccionar uno o más tramos de escalera.");

            return;
        }

        if (!Form.CrearPrincipal &&
            !Form.CrearReparticion)
        {
            TaskDialog.Show(
                "MYG",
                "Debe activar por lo menos un tipo de refuerzo.");

            return;
        }

        RebarBarType tipoPrincipal =
            Form.TipoPrincipalSeleccionado;

        RebarBarType tipoReparticion =
            Form.TipoReparticionSeleccionado;

        if (Form.CrearPrincipal &&
            tipoPrincipal == null)
        {
            TaskDialog.Show(
                "MYG",
                "Debe seleccionar el tipo de barra principal.");

            return;
        }

        if (Form.CrearReparticion &&
            tipoReparticion == null)
        {
            TaskDialog.Show(
                "MYG",
                "Debe seleccionar el tipo de barra de repartición.");

            return;
        }

        if (!TryLeerDouble(
            Form.RecubrimientoInferiorTexto,
            out double recubrimientoInferiorCm))
        {
            TaskDialog.Show(
                "MYG",
                "El recubrimiento inferior no es válido.");

            return;
        }

        if (!TryLeerDouble(
            Form.RecubrimientoLateralTexto,
            out double recubrimientoLateralCm))
        {
            TaskDialog.Show(
                "MYG",
                "El recubrimiento lateral no es válido.");

            return;
        }

        if (recubrimientoInferiorCm < 0 ||
            recubrimientoLateralCm < 0)
        {
            TaskDialog.Show(
                "MYG",
                "Los recubrimientos no pueden ser negativos.");

            return;
        }

        double espaciamientoPrincipalCm = 0.0;
        double espaciamientoReparticionCm = 0.0;

        if (Form.CrearPrincipal)
        {
            if (!TryLeerDouble(
                Form.EspaciamientoPrincipalTexto,
                out espaciamientoPrincipalCm) ||
                espaciamientoPrincipalCm <= 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "El espaciamiento del acero principal no es válido.");

                return;
            }
        }

        if (Form.CrearReparticion)
        {
            if (!TryLeerDouble(
                Form.EspaciamientoReparticionTexto,
                out espaciamientoReparticionCm) ||
                espaciamientoReparticionCm <= 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "El espaciamiento del acero de repartición no es válido.");

                return;
            }
        }

        double recubrimientoInferior =
            UnitUtils.ConvertToInternalUnits(
                recubrimientoInferiorCm,
                UnitTypeId.Centimeters);

        double recubrimientoLateral =
            UnitUtils.ConvertToInternalUnits(
                recubrimientoLateralCm,
                UnitTypeId.Centimeters);

        double espaciamientoPrincipal =
            UnitUtils.ConvertToInternalUnits(
                espaciamientoPrincipalCm,
                UnitTypeId.Centimeters);

        double espaciamientoReparticion =
            UnitUtils.ConvertToInternalUnits(
                espaciamientoReparticionCm,
                UnitTypeId.Centimeters);

        double longitudAnclaje =
            UnitUtils.ConvertToInternalUnits(
                LongitudAnclajeAutomaticaCm,
                UnitTypeId.Centimeters);

        int tramosCorrectos = 0;
        int tramosFallidos = 0;
        int objetosRebarCreados = 0;

        List<ElementId> todosIdsCreados =
            new List<ElementId>();

        List<string> errores =
            new List<string>();

        Form.ActualizarEstado(
            "Analizando geometría del tramo...");

        using (TransactionGroup grupo =
            new TransactionGroup(
                doc,
                "MYG - Acero en escalera"))
        {
            grupo.Start();

            foreach (ElementId id in TramosSeleccionados)
            {
                Element tramo = doc.GetElement(id);

                if (tramo == null)
                {
                    tramosFallidos++;

                    errores.Add(
                        "ID " + id.Value +
                        ": el elemento ya no existe.");

                    continue;
                }

                using (Transaction transaccion =
                    new Transaction(
                        doc,
                        "Acero tramo " + id.Value))
                {
                    transaccion.Start();

                    try
                    {
                        ResultadoCreacion resultado =
                            CrearAceroEnTramo(
                                doc,
                                tramo,
                                tipoPrincipal,
                                tipoReparticion,
                                Form.CrearPrincipal,
                                Form.CrearReparticion,
                                espaciamientoPrincipal,
                                espaciamientoReparticion,
                                recubrimientoInferior,
                                recubrimientoLateral,
                                longitudAnclaje,
                                Form.CompletarParametros);

                        if (resultado == null ||
                            resultado.CantidadObjetos <= 0)
                        {
                            throw new InvalidOperationException(
                                "No se creó ningún objeto Rebar.");
                        }

                        transaccion.Commit();

                        objetosRebarCreados +=
                            resultado.CantidadObjetos;

                        todosIdsCreados.AddRange(
                            resultado.Ids);

                        tramosCorrectos++;
                    }
                    catch (Exception ex)
                    {
                        transaccion.RollBack();
                        tramosFallidos++;

                        errores.Add(
                            "Tramo ID " +
                            id.Value +
                            ":\n" +
                            ex.Message);
                    }
                }
            }

            grupo.Assimilate();
        }

        if (todosIdsCreados.Count > 0)
        {
            uidoc.Selection.SetElementIds(
                todosIdsCreados);
        }

        Form.ActualizarEstado(
            "Acero creado: " +
            objetosRebarCreados +
            " objetos.");

        if (tramosFallidos > 0)
        {
            StringBuilder texto =
                new StringBuilder();

            texto.AppendLine("Proceso completado.");
            texto.AppendLine();
            texto.AppendLine(
                "Tramos correctos: " +
                tramosCorrectos);

            texto.AppendLine(
                "Tramos no procesados: " +
                tramosFallidos);

            texto.AppendLine(
                "Objetos Rebar creados: " +
                objetosRebarCreados);

            texto.AppendLine();
            texto.AppendLine("DETALLE:");

            int maxErrores = Math.Min(
                errores.Count,
                8);

            for (int i = 0;
                 i < maxErrores;
                 i++)
            {
                texto.AppendLine();
                texto.AppendLine(
                    errores[i]);
            }

            TaskDialog.Show(
                "MYG",
                texto.ToString());
        }
    }

    // =====================================
    // CREAR ACERO EN UN TRAMO
    // =====================================
    private ResultadoCreacion CrearAceroEnTramo(
        Document doc,
        Element tramo,
        RebarBarType tipoPrincipal,
        RebarBarType tipoReparticion,
        bool crearPrincipal,
        bool crearReparticion,
        double espaciamientoPrincipal,
        double espaciamientoReparticion,
        double recubrimientoInferior,
        double recubrimientoLateral,
        double longitudAnclaje,
        bool completarParametros)
    {
        ResultadoCreacion resultado =
            new ResultadoCreacion();

        Element hostAcero =
            ResolverHostAceroEscalera(
                doc,
                tramo);

        if (hostAcero == null)
        {
            throw new InvalidOperationException(
                "No se encontró un anfitrión válido para la armadura.");
        }

        DatosTramoEscalera datos =
            ObtenerDatosTramo(
                tramo,
                hostAcero);

        if (datos == null)
        {
            throw new InvalidOperationException(
                "No se pudo obtener la cara inferior inclinada " +
                "del tramo seleccionado.");
        }

        double diametroPrincipal =
            ObtenerDiametroBarra(
                tipoPrincipal);

        double diametroReparticion =
            ObtenerDiametroBarra(
                tipoReparticion);

        if (crearPrincipal &&
            diametroPrincipal <= Tol)
        {
            throw new InvalidOperationException(
                "No se pudo leer el diámetro de la barra principal.");
        }

        if (crearReparticion &&
            diametroReparticion <= Tol)
        {
            throw new InvalidOperationException(
                "No se pudo leer el diámetro de la barra de repartición.");
        }

        PerfilPrincipal perfilBase =
            ConstruirPerfilPrincipal(
                datos,
                recubrimientoInferior,
                recubrimientoLateral,
                diametroPrincipal,
                longitudAnclaje);

        if (perfilBase == null ||
            perfilBase.Curvas.Count == 0)
        {
            throw new InvalidOperationException(
                "No se pudo construir el perfil longitudinal " +
                "del acero principal.");
        }

        // =====================================
        // ACERO PRINCIPAL
        // =====================================
        if (crearPrincipal)
        {
            Rebar rebarPrincipal =
                CrearConjuntoPrincipal(
                    doc,
                    datos,
                    perfilBase,
                    tipoPrincipal,
                    espaciamientoPrincipal,
                    recubrimientoLateral,
                    diametroPrincipal);

            if (rebarPrincipal == null)
            {
                throw new InvalidOperationException(
                    "Revit no pudo crear el acero principal doblado.");
            }

            resultado.CantidadObjetos++;
            resultado.Ids.Add(
                rebarPrincipal.Id);

            if (completarParametros)
            {
                CompletarParametros(
                    rebarPrincipal,
                    tramo,
                    "Acero principal inferior de escalera",
                    "ESC-PRI");
            }
        }

        // =====================================
        // ACERO DE REPARTICIÓN
        // =====================================
        if (crearReparticion)
        {
            List<Rebar> reparticiones =
                CrearReparticionPorPerfil(
                    doc,
                    datos,
                    perfilBase,
                    tipoReparticion,
                    espaciamientoReparticion,
                    recubrimientoLateral,
                    diametroPrincipal,
                    diametroReparticion,
                    crearPrincipal);

            foreach (Rebar rebar in reparticiones)
            {
                if (rebar == null)
                    continue;

                resultado.CantidadObjetos++;
                resultado.Ids.Add(
                    rebar.Id);

                if (completarParametros)
                {
                    CompletarParametros(
                        rebar,
                        tramo,
                        "Acero de repartición de escalera",
                        "ESC-REP");
                }
            }

            if (reparticiones.Count == 0)
            {
                throw new InvalidOperationException(
                    "Revit no pudo crear el acero transversal de repartición.");
            }
        }

        return resultado;
    }

    // =====================================
    // RESOLVER ANFITRIÓN DE ACERO
    // =====================================
    private Element ResolverHostAceroEscalera(
        Document doc,
        Element tramo)
    {
        if (doc == null || tramo == null)
            return null;

        // 1. Probar el propio elemento seleccionado.
        try
        {
            RebarHostData datosHost =
                RebarHostData.GetRebarHostData(
                    tramo);

            if (datosHost != null)
                return tramo;
        }
        catch
        {
        }

        // 2. Para StairsRun, probar la escalera padre.
        StairsRun run =
            tramo as StairsRun;

        if (run != null)
        {
            Stairs stairsPadre =
                ObtenerEscaleraPadre(
                    doc,
                    run.Id);

            if (stairsPadre != null)
            {
                try
                {
                    RebarHostData datosHostPadre =
                        RebarHostData.GetRebarHostData(
                            stairsPadre);

                    if (datosHostPadre != null)
                        return stairsPadre;
                }
                catch
                {
                }
            }
        }

        return null;
    }

    // =====================================
    // OBTENER ESCALERA PADRE
    // =====================================
    private Stairs ObtenerEscaleraPadre(
        Document doc,
        ElementId runId)
    {
        if (doc == null ||
            runId == null ||
            runId == ElementId.InvalidElementId)
        {
            return null;
        }

        IEnumerable<Stairs> escaleras =
            new FilteredElementCollector(doc)
                .OfClass(typeof(Stairs))
                .Cast<Stairs>();

        foreach (Stairs stairs in escaleras)
        {
            ICollection<ElementId> idsTramos =
                stairs.GetStairsRuns();

            if (idsTramos != null &&
                idsTramos.Contains(runId))
            {
                return stairs;
            }
        }

        return null;
    }

    // =====================================
    // OBTENER GEOMETRÍA DEL TRAMO
    // =====================================
    private DatosTramoEscalera ObtenerDatosTramo(
        Element tramo,
        Element hostAcero)
    {
        Options opciones =
            new Options()
            {
                ComputeReferences = true,
                IncludeNonVisibleObjects = true,
                DetailLevel = ViewDetailLevel.Fine
            };

        GeometryElement geometria =
            tramo.get_Geometry(
                opciones);

        if (geometria == null)
            return null;

        List<Solid> solidos =
            ObtenerSolidos(
                geometria);

        if (solidos.Count == 0)
            return null;

        PlanarFace mejorCara =
            null;

        double mejorPuntaje =
            double.MinValue;

        // Se elige la mayor cara inferior que tenga
        // componente horizontal y vertical.
        foreach (Solid solid in solidos)
        {
            foreach (Face face in solid.Faces)
            {
                PlanarFace cara =
                    face as PlanarFace;

                if (cara == null)
                    continue;

                XYZ normal =
                    cara.FaceNormal.Normalize();

                // Debe apuntar hacia abajo.
                if (normal.Z >= -0.01)
                    continue;

                // Se descartan caras casi verticales.
                if (Math.Abs(normal.Z) < 0.10)
                    continue;

                List<XYZ> puntosCara =
                    ObtenerPuntosCara(
                        cara);

                if (puntosCara.Count < 3)
                    continue;

                XYZ posiblePendiente =
                    ObtenerDireccionPendiente(
                        cara);

                if (posiblePendiente == null ||
                    posiblePendiente.GetLength() <= Tol)
                {
                    continue;
                }

                // Se prefiere una cara grande y con
                // dirección realmente inclinada.
                double inclinacion =
                    Math.Abs(
                        posiblePendiente.Normalize().Z);

                double puntaje =
                    cara.Area *
                    (1.0 + inclinacion);

                if (puntaje > mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejorCara = cara;
                }
            }
        }

        if (mejorCara == null)
            return null;

        List<XYZ> puntos =
            ObtenerPuntosCara(
                mejorCara);

        if (puntos.Count < 3)
            return null;

        XYZ normalCara =
            mejorCara.FaceNormal.Normalize();

        XYZ interior =
            normalCara.Negate();

        XYZ pendiente =
            ObtenerDireccionPendiente(
                mejorCara);

        if (pendiente == null ||
            pendiente.GetLength() <= Tol)
        {
            return null;
        }

        pendiente =
            pendiente.Normalize();

        // Dirección de abajo hacia arriba.
        if (pendiente.Z < 0.0)
            pendiente = pendiente.Negate();

        XYZ horizontal =
            new XYZ(
                pendiente.X,
                pendiente.Y,
                0.0);

        if (horizontal.GetLength() <= Tol)
            return null;

        horizontal =
            horizontal.Normalize();

        XYZ transversal =
            horizontal.CrossProduct(
                XYZ.BasisZ);

        if (transversal.GetLength() <= Tol)
            return null;

        transversal =
            transversal.Normalize();

        // Se corrige el sentido para mantener coherencia
        // con la cara inferior.
        XYZ normalPlano =
            transversal;

        XYZ productoPlano =
            pendiente.CrossProduct(
                transversal);

        if (productoPlano.DotProduct(
            normalCara) < 0.0)
        {
            transversal =
                transversal.Negate();

            normalPlano =
                transversal;
        }

        XYZ origen =
            puntos[0];

        double minU =
            double.MaxValue;

        double maxU =
            double.MinValue;

        double minV =
            double.MaxValue;

        double maxV =
            double.MinValue;

        foreach (XYZ punto in puntos)
        {
            XYZ vector =
                punto.Subtract(
                    origen);

            double u =
                vector.DotProduct(
                    pendiente);

            double v =
                vector.DotProduct(
                    transversal);

            minU =
                Math.Min(
                    minU,
                    u);

            maxU =
                Math.Max(
                    maxU,
                    u);

            minV =
                Math.Min(
                    minV,
                    v);

            maxV =
                Math.Max(
                    maxV,
                    v);
        }

        double longitud =
            maxU - minU;

        double ancho =
            maxV - minV;

        if (longitud <= Tol ||
            ancho <= Tol)
        {
            return null;
        }

        return new DatosTramoEscalera()
        {
            Tramo = tramo,
            HostAcero = hostAcero,
            CaraInferior = mejorCara,
            NormalCaraInferior = normalCara,
            DireccionInterior = interior,
            DireccionPendiente = pendiente,
            DireccionHorizontal = horizontal,
            DireccionTransversal = transversal,
            NormalPlanoPrincipal = normalPlano,
            Origen = origen,
            MinU = minU,
            MaxU = maxU,
            MinV = minV,
            MaxV = maxV,
            LongitudInclinada = longitud,
            Ancho = ancho,
            PuntosCara = puntos
        };
    }

    // =====================================
    // CONSTRUIR PERFIL PRINCIPAL
    // =====================================
    private PerfilPrincipal ConstruirPerfilPrincipal(
        DatosTramoEscalera datos,
        double recubrimientoInferior,
        double recubrimientoLateral,
        double diametroPrincipal,
        double longitudAnclaje)
    {
        if (datos == null)
            return null;

        double radio =
            diametroPrincipal / 2.0;

        double offsetInterior =
            recubrimientoInferior +
            radio;

        double retiroLateral =
            recubrimientoLateral +
            radio;

        double vBarra =
            datos.MinV +
            retiroLateral;

        if (vBarra >=
            datos.MaxV - retiroLateral)
        {
            return null;
        }

        double retiroExtremo =
            Math.Max(
                radio,
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Centimeters));

        double uInicio =
            datos.MinU +
            retiroExtremo;

        double uFin =
            datos.MaxU -
            retiroExtremo;

        if (uFin <= uInicio + Tol)
            return null;

        XYZ puntoInicioPendiente =
            PuntoLocal(
                datos,
                uInicio,
                vBarra,
                offsetInterior);

        XYZ puntoFinPendiente =
            PuntoLocal(
                datos,
                uFin,
                vBarra,
                offsetInterior);

        // Los anclajes se dibujan horizontalmente
        // dentro de los descansos/apoyos.
        XYZ puntoInicioHorizontal =
            puntoInicioPendiente.Subtract(
                datos.DireccionHorizontal.Multiply(
                    longitudAnclaje));

        XYZ puntoFinHorizontal =
            puntoFinPendiente.Add(
                datos.DireccionHorizontal.Multiply(
                    longitudAnclaje));

        // Se fuerza que los anclajes sean horizontales.
        puntoInicioHorizontal =
            new XYZ(
                puntoInicioHorizontal.X,
                puntoInicioHorizontal.Y,
                puntoInicioPendiente.Z);

        puntoFinHorizontal =
            new XYZ(
                puntoFinHorizontal.X,
                puntoFinHorizontal.Y,
                puntoFinPendiente.Z);

        List<Curve> curvas =
            new List<Curve>();

        if (puntoInicioHorizontal.DistanceTo(
            puntoInicioPendiente) > Tol)
        {
            curvas.Add(
                Line.CreateBound(
                    puntoInicioHorizontal,
                    puntoInicioPendiente));
        }

        curvas.Add(
            Line.CreateBound(
                puntoInicioPendiente,
                puntoFinPendiente));

        if (puntoFinPendiente.DistanceTo(
            puntoFinHorizontal) > Tol)
        {
            curvas.Add(
                Line.CreateBound(
                    puntoFinPendiente,
                    puntoFinHorizontal));
        }

        return new PerfilPrincipal()
        {
            PuntoInicioHorizontal =
                puntoInicioHorizontal,

            PuntoInicioPendiente =
                puntoInicioPendiente,

            PuntoFinPendiente =
                puntoFinPendiente,

            PuntoFinHorizontal =
                puntoFinHorizontal,

            DireccionHorizontal =
                datos.DireccionHorizontal,

            DireccionPendiente =
                datos.DireccionPendiente,

            LongitudHorizontalInferior =
                puntoInicioHorizontal.DistanceTo(
                    puntoInicioPendiente),

            LongitudPendiente =
                puntoInicioPendiente.DistanceTo(
                    puntoFinPendiente),

            LongitudHorizontalSuperior =
                puntoFinPendiente.DistanceTo(
                    puntoFinHorizontal),

            Curvas = curvas
        };
    }

    // =====================================
    // CREAR CONJUNTO PRINCIPAL
    // =====================================
    private Rebar CrearConjuntoPrincipal(
        Document doc,
        DatosTramoEscalera datos,
        PerfilPrincipal perfil,
        RebarBarType barType,
        double espaciamiento,
        double recubrimientoLateral,
        double diametro)
    {
        if (doc == null ||
            datos == null ||
            perfil == null ||
            barType == null)
        {
            return null;
        }

        double radio =
            diametro / 2.0;

        double retiro =
            recubrimientoLateral +
            radio;

        double longitudDistribucion =
            datos.Ancho -
            (2.0 * retiro);

        if (longitudDistribucion <= Tol)
            return null;

        Rebar rebar;

        using (BarTerminationsData terminaciones =
            new BarTerminationsData(doc))
        {
            rebar =
                Rebar.CreateFromCurves(
                    doc,
                    RebarStyle.Standard,
                    barType,
                    datos.HostAcero,
                    datos.NormalPlanoPrincipal,
                    perfil.Curvas,
                    terminaciones,
                    true,
                    true);
        }

        if (rebar == null)
            return null;

        RebarShapeDrivenAccessor accessor =
            rebar.GetShapeDrivenAccessor();

        accessor.SetLayoutAsMaximumSpacing(
            espaciamiento,
            longitudDistribucion,
            true,
            true,
            true);

        return rebar;
    }

    // =====================================
    // CREAR REPARTICIÓN SIGUIENDO EL PERFIL
    // =====================================
    private List<Rebar> CrearReparticionPorPerfil(
        Document doc,
        DatosTramoEscalera datos,
        PerfilPrincipal perfil,
        RebarBarType barType,
        double espaciamiento,
        double recubrimientoLateral,
        double diametroPrincipal,
        double diametroReparticion,
        bool existePrincipal)
    {
        List<Rebar> resultado =
            new List<Rebar>();

        if (doc == null ||
            datos == null ||
            perfil == null ||
            barType == null ||
            espaciamiento <= Tol)
        {
            return resultado;
        }

        double radioRep =
            diametroReparticion / 2.0;

        double retiroLateral =
            recubrimientoLateral +
            radioRep;

        double anchoUtil =
            datos.Ancho -
            (2.0 * retiroLateral);

        if (anchoUtil <= Tol)
            return resultado;

        // La repartición se coloca hacia el núcleo
        // respecto del acero principal.
        double desplazamientoInterior =
            existePrincipal
                ? diametroPrincipal +
                  radioRep
                : 0.0;

        // ZONA 1: anclaje horizontal inferior
        resultado.AddRange(
            CrearBarrasTransversalesEnSegmento(
                doc,
                datos,
                barType,
                perfil.PuntoInicioHorizontal,
                perfil.PuntoInicioPendiente,
                datos.DireccionHorizontal,
                espaciamiento,
                retiroLateral,
                anchoUtil,
                desplazamientoInterior,
                "Inferior"));

        // ZONA 2: tramo inclinado
        resultado.AddRange(
            CrearBarrasTransversalesEnSegmento(
                doc,
                datos,
                barType,
                perfil.PuntoInicioPendiente,
                perfil.PuntoFinPendiente,
                datos.DireccionPendiente,
                espaciamiento,
                retiroLateral,
                anchoUtil,
                desplazamientoInterior,
                "Pendiente"));

        // ZONA 3: anclaje horizontal superior
        resultado.AddRange(
            CrearBarrasTransversalesEnSegmento(
                doc,
                datos,
                barType,
                perfil.PuntoFinPendiente,
                perfil.PuntoFinHorizontal,
                datos.DireccionHorizontal,
                espaciamiento,
                retiroLateral,
                anchoUtil,
                desplazamientoInterior,
                "Superior"));

        return resultado;
    }

    // =====================================
    // CREAR BARRAS TRANSVERSALES EN SEGMENTO
    // =====================================
    private List<Rebar> CrearBarrasTransversalesEnSegmento(
        Document doc,
        DatosTramoEscalera datos,
        RebarBarType barType,
        XYZ inicio,
        XYZ fin,
        XYZ direccionSegmento,
        double espaciamiento,
        double retiroLateral,
        double anchoUtil,
        double desplazamientoInterior,
        string zona)
    {
        List<Rebar> resultado =
            new List<Rebar>();

        if (inicio == null ||
            fin == null ||
            direccionSegmento == null)
        {
            return resultado;
        }

        double longitud =
            inicio.DistanceTo(fin);

        if (longitud <= Tol)
            return resultado;

        int cantidadIntervalos =
            Math.Max(
                1,
                (int)Math.Ceiling(
                    longitud /
                    espaciamiento));

        double espaciamientoReal =
            longitud /
            cantidadIntervalos;

        // Se incluyen ambos extremos.
        for (int i = 0;
             i <= cantidadIntervalos;
             i++)
        {
            double estacion =
                Math.Min(
                    longitud,
                    i * espaciamientoReal);

            double parametro =
                longitud <= Tol
                    ? 0.0
                    : estacion / longitud;

            XYZ centro =
                inicio.Add(
                    fin.Subtract(inicio)
                        .Multiply(parametro));

            if (desplazamientoInterior > Tol)
            {
                centro =
                    centro.Add(
                        datos.DireccionInterior
                            .Multiply(
                                desplazamientoInterior));
            }

            XYZ punto1 =
                centro.Subtract(
                    datos.DireccionTransversal
                        .Multiply(
                            anchoUtil / 2.0));

            XYZ punto2 =
                centro.Add(
                    datos.DireccionTransversal
                        .Multiply(
                            anchoUtil / 2.0));

            // Normal válida para una barra transversal.
            XYZ normal =
                direccionSegmento.Normalize();

            if (Math.Abs(
                normal.DotProduct(
                    datos.DireccionTransversal)) > 0.999)
            {
                normal =
                    datos.NormalCaraInferior;
            }

            Rebar rebar =
                CrearBarraRecta(
                    doc,
                    datos.HostAcero,
                    barType,
                    normal,
                    punto1,
                    punto2);

            if (rebar != null)
                resultado.Add(rebar);
        }

        return resultado;
    }

    // =====================================
    // CREAR BARRA RECTA
    // =====================================
    private Rebar CrearBarraRecta(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        XYZ punto1,
        XYZ punto2)
    {
        if (doc == null ||
            host == null ||
            barType == null ||
            normal == null ||
            punto1 == null ||
            punto2 == null)
        {
            return null;
        }

        if (punto1.DistanceTo(
            punto2) <= Tol)
        {
            return null;
        }

        List<Curve> curvas =
            new List<Curve>()
            {
                Line.CreateBound(
                    punto1,
                    punto2)
            };

        Rebar rebar;

        using (BarTerminationsData terminaciones =
            new BarTerminationsData(doc))
        {
            rebar =
                Rebar.CreateFromCurves(
                    doc,
                    RebarStyle.Standard,
                    barType,
                    host,
                    normal.Normalize(),
                    curvas,
                    terminaciones,
                    true,
                    true);
        }

        return rebar;
    }

    // =====================================
    // PUNTO LOCAL SOBRE CARA INFERIOR
    // =====================================
    private XYZ PuntoLocal(
        DatosTramoEscalera datos,
        double u,
        double v,
        double offsetInterior)
    {
        return datos.Origen
            .Add(
                datos.DireccionPendiente
                    .Multiply(u))
            .Add(
                datos.DireccionTransversal
                    .Multiply(v))
            .Add(
                datos.DireccionInterior
                    .Multiply(offsetInterior));
    }

    // =====================================
    // OBTENER DIRECCIÓN DE PENDIENTE
    // =====================================
    private XYZ ObtenerDireccionPendiente(
        PlanarFace cara)
    {
        if (cara == null)
            return null;

        XYZ mejorDireccion =
            null;

        double mejorPuntaje =
            double.MinValue;

        foreach (EdgeArray loop in cara.EdgeLoops)
        {
            foreach (Edge edge in loop)
            {
                IList<XYZ> puntos =
                    edge.Tessellate();

                for (int i = 0;
                     i < puntos.Count - 1;
                     i++)
                {
                    XYZ vector =
                        puntos[i + 1]
                            .Subtract(
                                puntos[i]);

                    double longitud =
                        vector.GetLength();

                    if (longitud <= Tol)
                        continue;

                    XYZ direccion =
                        vector.Normalize();

                    // Se prefiere una arista larga
                    // con componente vertical.
                    double puntaje =
                        longitud *
                        (1.0 +
                         5.0 *
                         Math.Abs(
                             direccion.Z));

                    if (puntaje >
                        mejorPuntaje)
                    {
                        mejorPuntaje =
                            puntaje;

                        mejorDireccion =
                            direccion;
                    }
                }
            }
        }

        if (mejorDireccion == null)
        {
            XYZ x =
                cara.XVector.Normalize();

            XYZ y =
                cara.YVector.Normalize();

            mejorDireccion =
                Math.Abs(x.Z) >=
                Math.Abs(y.Z)
                    ? x
                    : y;
        }

        return mejorDireccion;
    }

    // =====================================
    // OBTENER PUNTOS DE CARA
    // =====================================
    private List<XYZ> ObtenerPuntosCara(
        PlanarFace cara)
    {
        List<XYZ> puntos =
            new List<XYZ>();

        if (cara == null)
            return puntos;

        foreach (EdgeArray loop in cara.EdgeLoops)
        {
            foreach (Edge edge in loop)
            {
                IList<XYZ> puntosBorde =
                    edge.Tessellate();

                foreach (XYZ punto in puntosBorde)
                {
                    if (!ContienePunto(
                        puntos,
                        punto))
                    {
                        puntos.Add(punto);
                    }
                }
            }
        }

        return puntos;
    }

    // =====================================
    // OBTENER SÓLIDOS
    // =====================================
    private List<Solid> ObtenerSolidos(
        GeometryElement geometria)
    {
        List<Solid> resultado =
            new List<Solid>();

        if (geometria == null)
            return resultado;

        foreach (GeometryObject objeto in geometria)
        {
            Solid solid =
                objeto as Solid;

            if (solid != null &&
                solid.Volume > Tol &&
                solid.Faces.Size > 0)
            {
                resultado.Add(solid);
                continue;
            }

            GeometryInstance instancia =
                objeto as GeometryInstance;

            if (instancia == null)
                continue;

            GeometryElement geometriaInstancia =
                instancia.GetInstanceGeometry();

            if (geometriaInstancia == null)
                continue;

            resultado.AddRange(
                ObtenerSolidos(
                    geometriaInstancia));
        }

        return resultado;
    }

    // =====================================
    // DIÁMETRO DE BARRA
    // =====================================
    private double ObtenerDiametroBarra(
        RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        Parameter parametro =
            tipo.get_Parameter(
                BuiltInParameter.REBAR_BAR_DIAMETER);

        if (parametro != null &&
            parametro.StorageType ==
                StorageType.Double)
        {
            return parametro.AsDouble();
        }

        parametro =
            tipo.LookupParameter(
                "Diámetro de barra");

        if (parametro != null &&
            parametro.StorageType ==
                StorageType.Double)
        {
            return parametro.AsDouble();
        }

        parametro =
            tipo.LookupParameter(
                "Bar Diameter");

        if (parametro != null &&
            parametro.StorageType ==
                StorageType.Double)
        {
            return parametro.AsDouble();
        }

        return 0.0;
    }

    // =====================================
    // COMPLETAR PARÁMETROS
    // =====================================
    private void CompletarParametros(
        Rebar rebar,
        Element tramo,
        string tipoAcero,
        string prefijoMarca)
    {
        if (rebar == null ||
            tramo == null)
        {
            return;
        }

        Parameter comentarios =
            rebar.get_Parameter(
                BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

        if (comentarios != null &&
            !comentarios.IsReadOnly)
        {
            comentarios.Set(
                tipoAcero);
        }

        Parameter marca =
            rebar.get_Parameter(
                BuiltInParameter.ALL_MODEL_MARK);

        if (marca != null &&
            !marca.IsReadOnly)
        {
            marca.Set(
                prefijoMarca +
                "-" +
                tramo.Id.Value);
        }

        AsignarParametroTexto(
            rebar,
            "EST_Tipo Refuerzo",
            tipoAcero);

        AsignarParametroTexto(
            rebar,
            "GEN_ID Elemento",
            tramo.Id.Value.ToString());
    }

    // =====================================
    // ASIGNAR PARÁMETRO TEXTO
    // =====================================
    private void AsignarParametroTexto(
        Element elemento,
        string nombre,
        string valor)
    {
        if (elemento == null ||
            string.IsNullOrWhiteSpace(
                nombre))
        {
            return;
        }

        Parameter parametro =
            elemento.LookupParameter(
                nombre);

        if (parametro == null ||
            parametro.IsReadOnly ||
            parametro.StorageType !=
                StorageType.String)
        {
            return;
        }

        parametro.Set(
            valor ?? "");
    }

    // =====================================
    // CONTIENE PUNTO
    // =====================================
    private bool ContienePunto(
        List<XYZ> puntos,
        XYZ punto)
    {
        foreach (XYZ existente in puntos)
        {
            if (existente.DistanceTo(
                punto) <= Tol)
            {
                return true;
            }
        }

        return false;
    }

    // =====================================
    // LEER DOUBLE
    // =====================================
    private bool TryLeerDouble(
        string texto,
        out double valor)
    {
        valor = 0.0;

        if (string.IsNullOrWhiteSpace(
            texto))
        {
            return false;
        }

        texto =
            texto.Trim()
                 .Replace(",", ".");

        return double.TryParse(
            texto,
            NumberStyles.Any,
            CultureInfo.InvariantCulture,
            out valor);
    }

    // =====================================
    // NOMBRE DEL HANDLER
    // =====================================
    public string GetName()
    {
        return "Seleccionar y crear acero por tramo de escalera";
    }
}
