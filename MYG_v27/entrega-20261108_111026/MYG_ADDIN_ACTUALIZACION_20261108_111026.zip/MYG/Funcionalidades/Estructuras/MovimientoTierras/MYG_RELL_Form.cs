using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    public class MYG_RELL_Form : WinForms.Form
    {
        // Datos de tipo para soportar tipos del anfitrión y de vínculos RVT.
        // Está anidado en el Form para no crear otra clase global en tu proyecto.
        public class TipoData
        {
            public Document Documento;
            public ElementId TipoId;
            public string DocumentoTitulo;
            public string NombreTipo;
        }

        public Document Doc;

        // El mismo checkbox sirve para BOTTOM y TOP.
        // Puedes cambiarlo antes de cada selección.
        public WinForms.CheckBox chkSeleccionarVinculos;

        // 🔽 BOTTOM
        public WinForms.DataGridView dgvBottom;
        public WinForms.Button btnSelBottom;
        public WinForms.Label lblCantidadBottom;
        public WinForms.RadioButton rbSuelosBottom;
        public WinForms.RadioButton rbCimentacionBottom;
        public WinForms.RadioButton rbMurosBottom;
        private WinForms.TextBox txtBuscarBottom;

        // 🔼 TOP
        public WinForms.DataGridView dgvTop;
        public WinForms.Button btnSelTop;
        public WinForms.Label lblCantidadTop;
        public WinForms.RadioButton rbSuelosTop;
        public WinForms.RadioButton rbCimentacionTop;
        public WinForms.RadioButton rbMurosTop;
        private WinForms.TextBox txtBuscarTop;

        public ExternalEvent SeleccionarEvent;
        public ExternalEvent EjecutarEvent;
        public string ModoSeleccion = "";

        public WinForms.Button btnEjecutar;

        private WinForms.CheckBox chkBottomHeader;
        private WinForms.CheckBox chkTopHeader;

        public MYG_RELL_Form()
        {
            this.Text = "⛏️ MYG RELLENO";
            this.Width = 400;
            this.Height = 790; // 👈 espacio para checkbox de vínculos
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.TopMost = true;

            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);

            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            chkSeleccionarVinculos = new WinForms.CheckBox()
            {
                Text = "Seleccionar elementos de vínculos RVT",
                Left = 20,
                Top = 31,
                Width = 320,
                Height = 22,
                Checked = false,
                ForeColor = Drawing.Color.FromArgb(0, 70, 140)
            };

            chkSeleccionarVinculos.CheckedChanged += (s, e) =>
            {
                CargarTiposBottom();
                CargarTiposTop();
            };

            // ================= BOTTOM =================

            lblCantidadBottom = new WinForms.Label()
            {
                Text = "Bottom seleccionados: 0",
                Left = 20,
                Top = 58,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold)
            };

            var grpBottom = new WinForms.GroupBox()
            {
                Text = "BOTTOM",
                Left = 20,
                Top = 78,
                Width = 340,
                Height = 60
            };

            grpBottom.Paint += (s, e) =>
            {
                var g = e.Graphics;
                var rect = grpBottom.ClientRectangle;

                rect.Y += 7;
                rect.Height -= 7;

                WinForms.ControlPaint.DrawBorder(g, rect,
                    Drawing.Color.Gray, WinForms.ButtonBorderStyle.Solid);

                string text = "BOTTOM";

                using (var font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold))
                {
                    var textSize = g.MeasureString(text, font);

                    var textRect = new Drawing.RectangleF(10, 0, textSize.Width, textSize.Height);
                    using (var backBrush = new Drawing.SolidBrush(this.BackColor))
                    {
                        g.FillRectangle(backBrush, textRect);
                    }

                    using (var textBrush = new Drawing.SolidBrush(Drawing.Color.FromArgb(0, 32, 96)))
                    {
                        g.DrawString(text, font, textBrush, 10, 0);
                    }
                }
            };

            rbSuelosBottom = new WinForms.RadioButton() { Text = "Suelos", Left = 20, Top = 25, Width = 85 };
            rbCimentacionBottom = new WinForms.RadioButton() { Text = "Cimentación", Left = 115, Top = 25, Width = 120 };
            rbMurosBottom = new WinForms.RadioButton() { Text = "Muros", Left = 245, Top = 25, Width = 75 };

            rbSuelosBottom.CheckedChanged += (s, e) => CargarTiposBottom();
            rbCimentacionBottom.CheckedChanged += (s, e) => CargarTiposBottom();
            rbMurosBottom.CheckedChanged += (s, e) => CargarTiposBottom();

            grpBottom.Controls.Add(rbSuelosBottom);
            grpBottom.Controls.Add(rbCimentacionBottom);
            grpBottom.Controls.Add(rbMurosBottom);

            var lblBuscarBottom = new WinForms.Label()
            {
                Text = "🔍",
                Left = 25,
                Top = 145,
                Width = 30,
                Font = new Drawing.Font("Segoe UI Emoji", 10F)
            };

            var panelBuscarBottom = new WinForms.Panel()
            {
                Left = 60,
                Top = 145,
                Width = 300,
                Height = 23,
                BackColor = Drawing.Color.White
            };

            panelBuscarBottom.Paint += (s, e) =>
            {
                WinForms.ControlPaint.DrawBorder(e.Graphics, panelBuscarBottom.ClientRectangle,
                    Drawing.Color.FromArgb(200, 200, 200), WinForms.ButtonBorderStyle.Solid);
            };

            txtBuscarBottom = new WinForms.TextBox()
            {
                BorderStyle = WinForms.BorderStyle.None,
                Left = 5,
                Top = 3,
                Width = 290
            };

            txtBuscarBottom.TextChanged += (s, e) => Filtrar(dgvBottom, txtBuscarBottom.Text);

            panelBuscarBottom.Controls.Add(txtBuscarBottom);

            dgvBottom = new WinForms.DataGridView()
            {
                Left = 20,
                Top = 175,
                Width = 340,
                Height = 150,
                AllowUserToAddRows = false,
                RowHeadersVisible = false
            };

            dgvBottom.Columns.Add(new WinForms.DataGridViewCheckBoxColumn() { Width = 40 });
            dgvBottom.Columns.Add("Tipo", "Tipo");
            dgvBottom.Columns.Add("Id", "Id");
            dgvBottom.Columns[2].Visible = false;
            dgvBottom.Columns["Tipo"].AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill;

            chkBottomHeader = new WinForms.CheckBox();
            chkBottomHeader.Size = new Drawing.Size(15, 15);

            dgvBottom.Controls.Add(chkBottomHeader);
            dgvBottom.ColumnWidthChanged += (s, e) => AjustarCheckHeader(dgvBottom, chkBottomHeader);
            dgvBottom.Scroll += (s, e) => AjustarCheckHeader(dgvBottom, chkBottomHeader);

            chkBottomHeader.CheckedChanged += (s, e) =>
            {
                foreach (WinForms.DataGridViewRow row in dgvBottom.Rows)
                    if (row.Visible)
                        row.Cells[0].Value = chkBottomHeader.Checked;
            };

            btnSelBottom = new WinForms.Button()
            {
                Text = "Seleccionar Bottom",
                Width = 340,
                Height = 32,
                Left = 20,
                Top = 335, // 👈 ajustado
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSelBottom.Click += (s, e) =>
            {
                ModoSeleccion = "BOTTOM";
                SeleccionarEvent?.Raise();
            };

            // ================= TOP =================

            lblCantidadTop = new WinForms.Label()
            {
                Text = "Top seleccionados: 0",
                Left = 20,
                Top = 375,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold)
            };

            var grpTop = new WinForms.GroupBox()
            {
                Text = "TOP",
                Left = 20,
                Top = 395,
                Width = 340,
                Height = 60
            };

            grpTop.Paint += (s, e) =>
            {
                var g = e.Graphics;
                var rect = grpTop.ClientRectangle;

                rect.Y += 7;
                rect.Height -= 7;

                WinForms.ControlPaint.DrawBorder(g, rect,
                    Drawing.Color.Gray, WinForms.ButtonBorderStyle.Solid);

                string text = "TOP";

                using (var font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold))
                {
                    var textSize = g.MeasureString(text, font);

                    var textRect = new Drawing.RectangleF(10, 0, textSize.Width, textSize.Height);
                    using (var backBrush = new Drawing.SolidBrush(this.BackColor))
                    {
                        g.FillRectangle(backBrush, textRect);
                    }

                    using (var textBrush = new Drawing.SolidBrush(Drawing.Color.FromArgb(0, 32, 96)))
                    {
                        g.DrawString(text, font, textBrush, 10, 0);
                    }
                }
            };

            rbSuelosTop = new WinForms.RadioButton() { Text = "Suelos", Left = 20, Top = 30, Width = 85 };
            rbCimentacionTop = new WinForms.RadioButton() { Text = "Cimentación", Left = 115, Top = 30, Width = 120 };
            rbMurosTop = new WinForms.RadioButton() { Text = "Muros", Left = 245, Top = 30, Width = 75 };

            rbSuelosTop.CheckedChanged += (s, e) => CargarTiposTop();
            rbCimentacionTop.CheckedChanged += (s, e) => CargarTiposTop();
            rbMurosTop.CheckedChanged += (s, e) => CargarTiposTop();

            grpTop.Controls.Add(rbSuelosTop);
            grpTop.Controls.Add(rbCimentacionTop);
            grpTop.Controls.Add(rbMurosTop);

            var lblBuscarTop = new WinForms.Label()
            {
                Text = "🔍",
                Left = 25,
                Top = 460,
                Width = 30,
                Font = new Drawing.Font("Segoe UI Emoji", 10F)
            };

            var panelBuscarTop = new WinForms.Panel()
            {
                Left = 60,
                Top = 460,
                Width = 300,
                Height = 22,
                BackColor = Drawing.Color.White
            };

            panelBuscarTop.Paint += (s, e) =>
            {
                WinForms.ControlPaint.DrawBorder(e.Graphics, panelBuscarTop.ClientRectangle,
                    Drawing.Color.FromArgb(200, 200, 200), WinForms.ButtonBorderStyle.Solid);
            };

            txtBuscarTop = new WinForms.TextBox()
            {
                BorderStyle = WinForms.BorderStyle.None,
                Left = 5,
                Top = 3,
                Width = 290
            };

            txtBuscarTop.TextChanged += (s, e) => Filtrar(dgvTop, txtBuscarTop.Text);

            panelBuscarTop.Controls.Add(txtBuscarTop);

            dgvTop = new WinForms.DataGridView()
            {
                Left = 20,
                Top = 490,
                Width = 340,
                Height = 150,
                AllowUserToAddRows = false,
                RowHeadersVisible = false
            };

            dgvTop.Columns.Add(new WinForms.DataGridViewCheckBoxColumn() { Width = 40 });
            dgvTop.Columns.Add("Tipo", "Tipo");
            dgvTop.Columns.Add("Id", "Id");
            dgvTop.Columns[2].Visible = false;
            dgvTop.Columns["Tipo"].AutoSizeMode = WinForms.DataGridViewAutoSizeColumnMode.Fill;

            chkTopHeader = new WinForms.CheckBox();
            chkTopHeader.Size = new Drawing.Size(15, 15);

            dgvTop.Controls.Add(chkTopHeader);
            dgvTop.ColumnWidthChanged += (s, e) => AjustarCheckHeader(dgvTop, chkTopHeader);
            dgvTop.Scroll += (s, e) => AjustarCheckHeader(dgvTop, chkTopHeader);

            chkTopHeader.CheckedChanged += (s, e) =>
            {
                foreach (WinForms.DataGridViewRow row in dgvTop.Rows)
                    if (row.Visible)
                        row.Cells[0].Value = chkTopHeader.Checked;
            };

            btnSelTop = new WinForms.Button()
            {
                Text = "Seleccionar Top",
                Width = 340,
                Height = 32,
                Left = 20,
                Top = 650,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSelTop.Click += (s, e) =>
            {
                ModoSeleccion = "TOP";
                SeleccionarEvent?.Raise();
            };

            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Width = 340,
                Height = 34,
                Left = 20,
                Top = 690,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.Click += (s, e) => EjecutarEvent?.Raise();

            Controls.Add(lblAutor);
            Controls.Add(chkSeleccionarVinculos);

            Controls.Add(lblCantidadBottom);
            Controls.Add(grpBottom);
            Controls.Add(lblBuscarBottom);
            Controls.Add(panelBuscarBottom);
            Controls.Add(dgvBottom);
            Controls.Add(btnSelBottom);

            Controls.Add(lblCantidadTop);
            Controls.Add(grpTop);
            Controls.Add(lblBuscarTop);
            Controls.Add(panelBuscarTop);
            Controls.Add(dgvTop);
            Controls.Add(btnSelTop);

            Controls.Add(btnEjecutar);
        }

        private void Filtrar(WinForms.DataGridView dgv, string texto)
        {
            texto = texto.ToLower();

            foreach (WinForms.DataGridViewRow row in dgv.Rows)
            {
                if (row.Cells[1].Value == null) continue;

                string valor = row.Cells[1].Value.ToString().ToLower();

                row.Visible = valor.Contains(texto);
            }
        }

        private void AjustarCheckHeader(WinForms.DataGridView dgv, WinForms.CheckBox chk)
        {
            var rect = dgv.GetCellDisplayRectangle(0, -1, true);
            chk.Location = new Drawing.Point(
                rect.Location.X + (rect.Width - chk.Width) / 2,
                rect.Location.Y + (rect.Height - chk.Height) / 2);
        }

        public void ActualizarBottom(int n) => lblCantidadBottom.Text = $"Bottom seleccionados: {n}";
        public void ActualizarTop(int n) => lblCantidadTop.Text = $"Top seleccionados: {n}";

        private void CargarTiposBottom()
        {
            dgvBottom.Rows.Clear();
            if (Doc == null) return;

            BuiltInCategory cat;

            if (rbSuelosBottom.Checked)
                cat = BuiltInCategory.OST_Floors;
            else if (rbCimentacionBottom.Checked)
                cat = BuiltInCategory.OST_StructuralFoundation;
            else if (rbMurosBottom.Checked)
                cat = BuiltInCategory.OST_Walls;
            else
                return;

            CargarTiposEnGrid(dgvBottom, cat);
        }

        private void CargarTiposTop()
        {
            dgvTop.Rows.Clear();
            if (Doc == null) return;

            BuiltInCategory cat;

            if (rbSuelosTop.Checked)
                cat = BuiltInCategory.OST_Floors;
            else if (rbCimentacionTop.Checked)
                cat = BuiltInCategory.OST_StructuralFoundation;
            else if (rbMurosTop.Checked)
                cat = BuiltInCategory.OST_Walls;
            else
                return;

            CargarTiposEnGrid(dgvTop, cat);
        }

        private void CargarTiposEnGrid(
            WinForms.DataGridView dgv,
            BuiltInCategory categoria)
        {
            // =====================================================
            // MODELO ANFITRIÓN
            // =====================================================
            if (!chkSeleccionarVinculos.Checked)
            {
                AgregarTiposDocumento(dgv, Doc, categoria, false);
                return;
            }

            // =====================================================
            // VÍNCULOS RVT CARGADOS
            // =====================================================
            var documentosAgregados =
                new System.Collections.Generic.HashSet<Document>();

            var links = new FilteredElementCollector(Doc)
                .OfClass(typeof(RevitLinkInstance))
                .Cast<RevitLinkInstance>()
                .ToList();

            foreach (var link in links)
            {
                Document linkDoc = link.GetLinkDocument();
                if (linkDoc == null) continue;

                if (!documentosAgregados.Add(linkDoc))
                    continue;

                AgregarTiposDocumento(dgv, linkDoc, categoria, true);
            }
        }

        private void AgregarTiposDocumento(
            WinForms.DataGridView dgv,
            Document sourceDoc,
            BuiltInCategory categoria,
            bool esVinculo)
        {
            if (sourceDoc == null) return;

            var typeIds = new FilteredElementCollector(sourceDoc)
                .OfCategory(categoria)
                .WhereElementIsNotElementType()
                .Select(e => e.GetTypeId())
                .Where(id => id != null && id.Value >= 0)
                .Distinct()
                .ToList();

            foreach (var id in typeIds)
            {
                Element tipo = sourceDoc.GetElement(id);
                if (tipo == null) continue;

                string nombreMostrar = esVinculo
                    ? "[" + sourceDoc.Title + "]  " + tipo.Name
                    : tipo.Name;

                var info = new TipoData()
                {
                    Documento = sourceDoc,
                    TipoId = tipo.Id,
                    DocumentoTitulo = sourceDoc.Title,
                    NombreTipo = tipo.Name
                };

                dgv.Rows.Add(false, nombreMostrar, info);
            }
        }
    }

}
