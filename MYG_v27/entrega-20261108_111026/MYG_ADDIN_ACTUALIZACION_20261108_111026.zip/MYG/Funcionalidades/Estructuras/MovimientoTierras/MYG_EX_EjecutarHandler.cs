﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Structure;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Autodesk.Revit.ApplicationServices;

public class MYG_EX_EjecutarHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public MYG_EX_SeleccionarHandler HandlerSeleccion;

    public void Execute(UIApplication app)
    {
        Document doc = UiDoc.Document;

        if (HandlerSeleccion.Elementos == null || !HandlerSeleccion.Elementos.Any())
        {
            TaskDialog.Show("MYG_EX", "No hay elementos seleccionados.");
            return;
        }

        using (Transaction t = new Transaction(doc, "MYG_EX Crear Masa PRO"))
        {
            t.Start();

            var topoSurfaces = new FilteredElementCollector(doc)
                .OfClass(typeof(TopographySurface))
                .Cast<Element>();

            var topoSolids = new FilteredElementCollector(doc)
                .OfClass(typeof(Toposolid))
                .Cast<Element>();

            var topos = topoSurfaces.Concat(topoSolids).ToList();

            if (!topos.Any())
            {
                TaskDialog.Show("MYG_EX", "No se encontró topografía.");
                return;
            }

            foreach (var seleccionado in HandlerSeleccion.Elementos)
            {
                if (seleccionado == null || seleccionado.Elemento == null)
                    continue;

                Element elem = seleccionado.Elemento;
                Document sourceDoc = seleccionado.Documento ?? doc;
                Transform transformacion = seleccionado.Transformacion ?? Transform.Identity;

                Solid solidBase = ObtenerSolid(elem, transformacion);
                if (solidBase == null) continue;

                var perfiles = ObtenerPerfilesSuperiores(solidBase);
                if (perfiles == null || !perfiles.Any()) continue;

                PlanarFace caraInferior = ObtenerCaraInferior(solidBase);
                if (caraInferior == null) continue;

                Solid extruido = GeometryCreationUtilities.CreateExtrusionGeometry(
                    caraInferior.GetEdgesAsCurveLoops(),
                    XYZ.BasisZ,
                    100
                );

                foreach (var topo in topos)
                {
                    Solid solidTopo = ObtenerSolid(topo, Transform.Identity);
                    if (solidTopo == null) continue;

                    try
                    {
                        Solid interseccion =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                extruido,
                                solidTopo,
                                BooleanOperationsType.Intersect);

                        if (interseccion != null && interseccion.Volume > 0)
                        {
                            FamilyInstance instancia = CrearFamiliaVoid(doc, interseccion);

                            if (instancia != null)
                            {
                                string descripcionFinal = "Excavación";

                                Element tipoBase = sourceDoc.GetElement(elem.GetTypeId());
                                if (tipoBase != null)
                                {
                                    Parameter pBase = tipoBase.LookupParameter("Descripción");
                                    if (pBase != null && pBase.HasValue)
                                    {
                                        string valor = pBase.AsString();

                                        if (!string.IsNullOrWhiteSpace(valor))
                                        {
                                            descripcionFinal = "Excavación en " + valor;
                                        }
                                    }
                                }

                                FamilySymbol tipo = instancia.Symbol;

                                Parameter pDesc = tipo.LookupParameter("Descripción");

                                if (pDesc != null && !pDesc.IsReadOnly)
                                {
                                    pDesc.Set(descripcionFinal);
                                }

                                doc.Regenerate();

                                try
                                {
                                    if (!JoinGeometryUtils.AreElementsJoined(doc, instancia, topo))
                                    {
                                        JoinGeometryUtils.JoinGeometry(doc, instancia, topo);
                                    }
                                }
                                catch (System.Exception ex)
                                {
                                    TaskDialog.Show("Error unión", ex.Message);
                                }
                            }

                            break;
                        }
                    }
                    catch { }
                }
            }

            // 🔥 CREAR FILTROS EN LA VISTA ACTIVA
            CrearFiltros(doc, doc.ActiveView);

            t.Commit();
        }
    }

    public string GetName() => "MYG_EX Ejecutar";

    // ==================================================
    // 🔥 FILTROS
    // ==================================================
    private void CrearFiltros(Document doc, View view)
    {
        List<ElementId> categorias = new List<ElementId>()
        {
            new ElementId(BuiltInCategory.OST_Mass)
        };

        CrearFiltro(doc, view, "MYG_Excavación", categorias, "MYG_EXCAVACION");
        CrearFiltro(doc, view, "MYG_Relleno", categorias, "MYG_RELLENO");
    }

    private void CrearFiltro(Document doc, View view, string nombreFiltro, List<ElementId> categorias, string valorEmpieza)
    {
        ElementId paramId = new ElementId(BuiltInParameter.SYMBOL_NAME_PARAM);

        FilterRule regla = ParameterFilterRuleFactory.CreateBeginsWithRule(
            paramId,
            valorEmpieza
        );

        ElementParameterFilter filtroRegla = new ElementParameterFilter(regla);

        ParameterFilterElement filtroExistente =
            new FilteredElementCollector(doc)
            .OfClass(typeof(ParameterFilterElement))
            .Cast<ParameterFilterElement>()
            .FirstOrDefault(f => f.Name == nombreFiltro);

        ParameterFilterElement filtro;

        if (filtroExistente != null)
        {
            filtro = filtroExistente;
        }
        else
        {
            filtro = ParameterFilterElement.Create(doc, nombreFiltro, categorias);
            filtro.SetElementFilter(filtroRegla);
        }

        if (!view.GetFilters().Contains(filtro.Id))
        {
            view.AddFilter(filtro.Id);
            view.SetFilterVisibility(filtro.Id, true);
        }

        // 🔥 SOLO MYG_Relleno → patrón sólido
        if (nombreFiltro == "MYG_Relleno")
        {
            OverrideGraphicSettings ogs = new OverrideGraphicSettings();

            FillPatternElement solidFill =
                new FilteredElementCollector(doc)
                .OfClass(typeof(FillPatternElement))
                .Cast<FillPatternElement>()
                .FirstOrDefault(fp => fp.GetFillPattern().IsSolidFill);

            if (solidFill != null)
            {
                Color color = new Color(128, 128, 0);

                ogs.SetCutForegroundPatternId(solidFill.Id);
                ogs.SetCutForegroundPatternColor(color);

                ogs.SetCutBackgroundPatternId(solidFill.Id);
                ogs.SetCutBackgroundPatternColor(color);

                ogs.SetSurfaceForegroundPatternId(solidFill.Id);
                ogs.SetSurfaceForegroundPatternColor(color);

                ogs.SetSurfaceBackgroundPatternId(solidFill.Id);
                ogs.SetSurfaceBackgroundPatternColor(color);

                view.SetFilterOverrides(filtro.Id, ogs);
            }
        }
    }

    private FamilyInstance CrearFamiliaVoid(Document doc, Solid solid)
    {
        Application app = doc.Application;

        string plantilla = @"C:\ProgramData\Autodesk\RVT 2027\Family Templates\English\Conceptual Mass\Metric Mass.rft";

        if (!File.Exists(plantilla))
        {
            TaskDialog.Show("MYG_REX", "No se encontró la plantilla Metric Mass.");
            return null;
        }

        XYZ centro = solid.ComputeCentroid();

        Transform t = Transform.CreateTranslation(-centro);
        Solid solidLocal = SolidUtils.CreateTransformed(solid, t);

        Document famDoc = app.NewFamilyDocument(plantilla);

        using (Transaction tf = new Transaction(famDoc, "Crear Solido"))
        {
            tf.Start();

            FreeFormElement solidForm = FreeFormElement.Create(famDoc, solidLocal);

            tf.Commit();
        }

        string ruta = Path.Combine(Path.GetTempPath(), "MYG_EXCAVACION_" + System.Guid.NewGuid() + ".rfa");
        famDoc.SaveAs(ruta);
        famDoc.Close(false);

        Family fam;
        if (!doc.LoadFamily(ruta, out fam))
            return null;

        FamilySymbol symbol = doc.GetElement(
            fam.GetFamilySymbolIds().First()) as FamilySymbol;

        if (!symbol.IsActive)
        {
            symbol.Activate();
            doc.Regenerate();
        }

        FamilyInstance inst = doc.Create.NewFamilyInstance(
            centro,
            symbol,
            StructuralType.NonStructural);

        return inst;
    }

    private Solid ObtenerSolid(Element elem, Transform transformacion)
    {
        if (elem == null)
            return null;

        Options opt = new Options();
        GeometryElement geo = elem.get_Geometry(opt);

        if (geo == null)
            return null;

        Solid solid = BuscarSolid(geo);

        if (solid == null)
            return null;

        if (transformacion == null || transformacion.IsIdentity)
            return solid;

        try
        {
            return SolidUtils.CreateTransformed(solid, transformacion);
        }
        catch
        {
            return null;
        }
    }

    private Solid BuscarSolid(GeometryElement geo)
    {
        if (geo == null)
            return null;

        foreach (GeometryObject obj in geo)
        {
            if (obj is Solid s && s.Volume > 0)
                return s;

            if (obj is GeometryInstance gi)
            {
                GeometryElement instGeo = gi.GetInstanceGeometry();
                Solid nested = BuscarSolid(instGeo);

                if (nested != null)
                    return nested;
            }
        }

        return null;
    }

    private List<CurveLoop> ObtenerPerfilesSuperiores(Solid solid)
    {
        foreach (Face face in solid.Faces)
        {
            if (face is PlanarFace pf && pf.FaceNormal.Z > 0.9)
            {
                return pf.GetEdgesAsCurveLoops().ToList();
            }
        }
        return null;
    }

    private PlanarFace ObtenerCaraInferior(Solid solid)
    {
        PlanarFace caraInferior = null;
        double minZ = double.MaxValue;

        foreach (Face face in solid.Faces)
        {
            if (face is PlanarFace pf && pf.FaceNormal.Z < -0.9)
            {
                double z = pf.Origin.Z;

                if (z < minZ)
                {
                    minZ = z;
                    caraInferior = pf;
                }
            }
        }

        return caraInferior;
    }
}