﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

// ============================================================
// HANDLER SELECCIÓN RELLENO
// ============================================================
public class MYG_RELL_SeleccionarHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public MYG_RELL_Form Form;

    // ========================================================
    // REGISTRO DE SELECCIÓN
    // ========================================================
    public class SeleccionItem
    {
        public Element Elemento;
        public Document Documento;
        public Transform Transformacion = Transform.Identity;
        public RevitLinkInstance Vinculo;

        public bool EsVinculado
        {
            get { return Vinculo != null; }
        }
    }

    // BOTTOM puede ser HOST o vínculo.
    public List<SeleccionItem> Bottom =
        new List<SeleccionItem>();

    // TOP puede ser HOST o vínculo.
    public List<SeleccionItem> Top =
        new List<SeleccionItem>();

    // ========================================================
    // FILTRO INTERNO
    // No crea RELL_FiltroSeleccion global, así que no choca
    // con la clase que ya existe en tu proyecto.
    // ========================================================
    private class FiltroSeleccionVinculo : ISelectionFilter
    {
        private readonly Document docHost;
        private readonly BuiltInCategory categoria;
        private readonly List<MYG_RELL_Form.TipoData> tipos;
        private readonly bool seleccionarVinculos;

        private RevitLinkInstance currentLink;

        public FiltroSeleccionVinculo(
            Document docHost,
            BuiltInCategory categoria,
            List<MYG_RELL_Form.TipoData> tipos,
            bool seleccionarVinculos)
        {
            this.docHost = docHost;
            this.categoria = categoria;
            this.tipos = tipos ?? new List<MYG_RELL_Form.TipoData>();
            this.seleccionarVinculos = seleccionarVinculos;
        }

        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            if (seleccionarVinculos)
            {
                currentLink = elem as RevitLinkInstance;
                return currentLink != null;
            }

            if (elem.Category == null)
                return false;

            if (elem.Category.Id.Value != (long)categoria)
                return false;

            return TipoPermitido(elem, docHost);
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            if (!seleccionarVinculos)
                return false;

            if (reference == null || currentLink == null)
                return false;

            try
            {
                Document linkDoc = currentLink.GetLinkDocument();

                if (linkDoc == null)
                    return false;

                ElementId linkedId = reference.LinkedElementId;

                if (linkedId == null ||
                    linkedId.Value < 0)
                    return false;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null || linkedElem.Category == null)
                    return false;

                if (linkedElem.Category.Id.Value != (long)categoria)
                    return false;

                return TipoPermitido(linkedElem, linkDoc);
            }
            catch
            {
                return false;
            }
        }

        private bool TipoPermitido(Element elem, Document sourceDoc)
        {
            if (elem == null || sourceDoc == null)
                return false;

            if (tipos == null || tipos.Count == 0)
                return true;

            ElementId tipoId = elem.GetTypeId();

            if (tipoId == null ||
                tipoId.Value < 0)
                return false;

            return tipos.Any(x =>
                x != null &&
                x.Documento != null &&
                x.TipoId != null &&
                x.TipoId.Value == tipoId.Value &&
                MismoDocumento(x.Documento, sourceDoc));
        }

        private static bool MismoDocumento(Document a, Document b)
        {
            if (a == null || b == null)
                return false;

            if (object.ReferenceEquals(a, b))
                return true;

            try
            {
                if (!string.IsNullOrWhiteSpace(a.PathName) &&
                    !string.IsNullOrWhiteSpace(b.PathName))
                {
                    return string.Equals(
                        a.PathName,
                        b.PathName,
                        StringComparison.OrdinalIgnoreCase);
                }
            }
            catch
            {
            }

            return string.Equals(
                a.Title ?? "",
                b.Title ?? "",
                StringComparison.OrdinalIgnoreCase);
        }
    }

    // ========================================================
    // EXECUTE
    // ========================================================
    public void Execute(UIApplication app)
    {
        Document doc = UiDoc.Document;

        try
        {
            if (Form.ModoSeleccion == "BOTTOM")
            {
                SeleccionarBottom(doc);
            }
            else if (Form.ModoSeleccion == "TOP")
            {
                SeleccionarTop(doc);
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            // Si cancela, conservar selección anterior.
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG_RELL",
                "Error al seleccionar elementos:\n\n" +
                ex.Message);
        }
    }

    // ========================================================
    // BOTTOM
    // ========================================================
    private void SeleccionarBottom(Document doc)
    {
        BuiltInCategory categoria;

        if (Form.rbSuelosBottom.Checked)
            categoria = BuiltInCategory.OST_Floors;
        else if (Form.rbCimentacionBottom.Checked)
            categoria = BuiltInCategory.OST_StructuralFoundation;
        else if (Form.rbMurosBottom.Checked)
            categoria = BuiltInCategory.OST_Walls;
        else
        {
            TaskDialog.Show(
                "MYG_RELL",
                "Seleccione categoría para BOTTOM.");
            return;
        }

        var tiposSeleccionados =
            ObtenerTiposMarcados(Form.dgvBottom);

        if (!tiposSeleccionados.Any())
        {
            TaskDialog.Show(
                "MYG_RELL",
                "Seleccione al menos un tipo en BOTTOM.");
            return;
        }

        bool desdeVinculo =
            Form.chkSeleccionarVinculos.Checked;

        List<SeleccionItem> seleccion =
            Seleccionar(
                doc,
                categoria,
                tiposSeleccionados,
                desdeVinculo,
                "Seleccione elementos BOTTOM");

        Bottom = seleccion;

        Form.ActualizarBottom(Bottom.Count);
    }

    // ========================================================
    // TOP
    // ========================================================
    private void SeleccionarTop(Document doc)
    {
        BuiltInCategory categoria;

        if (Form.rbSuelosTop.Checked)
            categoria = BuiltInCategory.OST_Floors;
        else if (Form.rbCimentacionTop.Checked)
            categoria = BuiltInCategory.OST_StructuralFoundation;
        else if (Form.rbMurosTop.Checked)
            categoria = BuiltInCategory.OST_Walls;
        else
        {
            TaskDialog.Show(
                "MYG_RELL",
                "Seleccione categoría para TOP.");
            return;
        }

        var tiposSeleccionados =
            ObtenerTiposMarcados(Form.dgvTop);

        if (!tiposSeleccionados.Any())
        {
            TaskDialog.Show(
                "MYG_RELL",
                "Seleccione al menos un tipo en TOP.");
            return;
        }

        bool desdeVinculo =
            Form.chkSeleccionarVinculos.Checked;

        List<SeleccionItem> seleccion =
            Seleccionar(
                doc,
                categoria,
                tiposSeleccionados,
                desdeVinculo,
                "Seleccione elementos TOP");

        Top = seleccion;

        Form.ActualizarTop(Top.Count);
    }

    // ========================================================
    // TIPOS MARCADOS
    // ========================================================
    private List<MYG_RELL_Form.TipoData> ObtenerTiposMarcados(
        System.Windows.Forms.DataGridView dgv)
    {
        var resultado =
            new List<MYG_RELL_Form.TipoData>();

        foreach (System.Windows.Forms.DataGridViewRow row in dgv.Rows)
        {
            bool seleccionado =
                row.Cells[0].Value != null &&
                Convert.ToBoolean(row.Cells[0].Value);

            if (!seleccionado)
                continue;

            MYG_RELL_Form.TipoData info =
                row.Cells[2].Value as MYG_RELL_Form.TipoData;

            if (info != null)
                resultado.Add(info);
        }

        return resultado;
    }

    // ========================================================
    // SELECCIONAR HOST / VÍNCULO
    // ========================================================
    private List<SeleccionItem> Seleccionar(
        Document doc,
        BuiltInCategory categoria,
        List<MYG_RELL_Form.TipoData> tiposSeleccionados,
        bool desdeVinculo,
        string mensaje)
    {
        var resultado =
            new List<SeleccionItem>();

        // HOST
        if (!desdeVinculo)
        {
            var refs = UiDoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroSeleccionVinculo(
                    doc,
                    categoria,
                    tiposSeleccionados,
                    false),
                mensaje);

            foreach (Reference r in refs)
            {
                Element elem = doc.GetElement(r);

                if (elem == null)
                    continue;

                resultado.Add(
                    new SeleccionItem()
                    {
                        Elemento = elem,
                        Documento = doc,
                        Transformacion = Transform.Identity,
                        Vinculo = null
                    });
            }
        }
        // VÍNCULO RVT
        else
        {
            var refs = UiDoc.Selection.PickObjects(
                ObjectType.LinkedElement,
                new FiltroSeleccionVinculo(
                    doc,
                    categoria,
                    tiposSeleccionados,
                    true),
                mensaje + " dentro de vínculos RVT");

            foreach (Reference r in refs)
            {
                RevitLinkInstance link =
                    doc.GetElement(r.ElementId) as RevitLinkInstance;

                if (link == null)
                    continue;

                Document linkDoc = link.GetLinkDocument();

                if (linkDoc == null)
                    continue;

                ElementId linkedId = r.LinkedElementId;

                if (linkedId == null ||
                    linkedId.Value < 0)
                    continue;

                Element elem = linkDoc.GetElement(linkedId);

                if (elem == null)
                    continue;

                resultado.Add(
                    new SeleccionItem()
                    {
                        Elemento = elem,
                        Documento = linkDoc,
                        Transformacion = link.GetTotalTransform(),
                        Vinculo = link
                    });
            }
        }

        return resultado;
    }

    public string GetName() => "MYG_RELL Seleccionar";
}
