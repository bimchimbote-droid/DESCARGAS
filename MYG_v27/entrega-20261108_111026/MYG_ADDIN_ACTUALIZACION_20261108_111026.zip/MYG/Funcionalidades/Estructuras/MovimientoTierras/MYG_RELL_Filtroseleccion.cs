﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using System.Collections.Generic;
using System.Linq;

public class RELL_FiltroSeleccion : ISelectionFilter
{
    Document doc;
    BuiltInCategory categoria;
    List<ElementId> tipos;

    public RELL_FiltroSeleccion(Document doc, BuiltInCategory cat, List<ElementId> tipos)
    {
        this.doc = doc;
        this.categoria = cat;
        this.tipos = tipos ?? new List<ElementId>();
    }

    public bool AllowElement(Element elem)
    {
        if (elem.Category == null)
            return false;

        // validar categoría
        if (elem.Category.Id != new ElementId((int)categoria))
            return false;

        // si no hay filtros de tipo, dejar pasar todo de la categoría
        if (tipos.Count == 0)
            return true;

        // validar tipo dentro de la lista
        return tipos.Contains(elem.GetTypeId());
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        return false;
    }
}