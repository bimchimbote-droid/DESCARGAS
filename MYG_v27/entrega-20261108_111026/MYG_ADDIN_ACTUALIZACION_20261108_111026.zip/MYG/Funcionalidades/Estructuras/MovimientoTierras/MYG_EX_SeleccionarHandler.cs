﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

// ============================================================
// HANDLER SELECCIÓN EXCAVACIÓN
// ============================================================
public class MYG_EX_SeleccionarHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public MYG_EX_Form Form;

    // ========================================================
    // REGISTRO DE SELECCIÓN
    // ========================================================
    public class SeleccionItem
    {
        public Element Elemento;
        public Document Documento;
        public Transform Transformacion = Transform.Identity;
        public RevitLinkInstance Vinculo;

        public bool EsVinculado
        {
            get { return Vinculo != null; }
        }
    }

    public List<SeleccionItem> Elementos =
        new List<SeleccionItem>();

    // ========================================================
    // FILTRO INTERNO
    // No crea una clase global FiltroSeleccion y por eso
    // NO choca con el FiltroSeleccion que ya tienes.
    // ========================================================
    private class FiltroSeleccionVinculo : ISelectionFilter
    {
        private readonly Document docHost;
        private readonly BuiltInCategory categoria;
        private readonly List<MYG_EX_Form.TipoData> tipos;
        private readonly bool seleccionarVinculos;

        private RevitLinkInstance currentLink;

        public FiltroSeleccionVinculo(
            Document docHost,
            BuiltInCategory categoria,
            List<MYG_EX_Form.TipoData> tipos,
            bool seleccionarVinculos)
        {
            this.docHost = docHost;
            this.categoria = categoria;
            this.tipos = tipos ?? new List<MYG_EX_Form.TipoData>();
            this.seleccionarVinculos = seleccionarVinculos;
        }

        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            // MODO VÍNCULO:
            // Revit entrega primero la RevitLinkInstance.
            if (seleccionarVinculos)
            {
                currentLink = elem as RevitLinkInstance;
                return currentLink != null;
            }

            // MODO HOST
            if (elem.Category == null)
                return false;

            if (elem.Category.Id.Value != (long)categoria)
                return false;

            return TipoPermitido(elem, docHost);
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            if (!seleccionarVinculos)
                return false;

            if (reference == null || currentLink == null)
                return false;

            try
            {
                Document linkDoc = currentLink.GetLinkDocument();
                if (linkDoc == null)
                    return false;

                ElementId linkedId = reference.LinkedElementId;
                if (linkedId == null ||
                    linkedId.Value < 0)
                    return false;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null || linkedElem.Category == null)
                    return false;

                if (linkedElem.Category.Id.Value != (long)categoria)
                    return false;

                return TipoPermitido(linkedElem, linkDoc);
            }
            catch
            {
                return false;
            }
        }

        private bool TipoPermitido(Element elem, Document sourceDoc)
        {
            if (elem == null || sourceDoc == null)
                return false;

            if (tipos == null || tipos.Count == 0)
                return true;

            ElementId tipoId = elem.GetTypeId();

            if (tipoId == null ||
                tipoId.Value < 0)
                return false;

            return tipos.Any(x =>
                x != null &&
                x.Documento != null &&
                x.TipoId != null &&
                x.TipoId.Value == tipoId.Value &&
                MismoDocumento(x.Documento, sourceDoc));
        }

        private static bool MismoDocumento(Document a, Document b)
        {
            if (a == null || b == null)
                return false;

            if (object.ReferenceEquals(a, b))
                return true;

            try
            {
                if (!string.IsNullOrWhiteSpace(a.PathName) &&
                    !string.IsNullOrWhiteSpace(b.PathName))
                {
                    return string.Equals(
                        a.PathName,
                        b.PathName,
                        StringComparison.OrdinalIgnoreCase);
                }
            }
            catch
            {
            }

            return string.Equals(
                a.Title ?? "",
                b.Title ?? "",
                StringComparison.OrdinalIgnoreCase);
        }
    }

    // ========================================================
    // EXECUTE
    // ========================================================
    public void Execute(UIApplication app)
    {
        Document doc = UiDoc.Document;

        try
        {
            BuiltInCategory categoria;

            if (Form.rbSuelos.Checked)
                categoria = BuiltInCategory.OST_Floors;
            else if (Form.rbCimentacion.Checked)
                categoria = BuiltInCategory.OST_StructuralFoundation;
            else if (Form.rbMuros.Checked)
                categoria = BuiltInCategory.OST_Walls;
            else
            {
                TaskDialog.Show(
                    "MYG_REX",
                    "Seleccione Suelos, Cimentación o Muros.");
                return;
            }

            // =================================================
            // TIPOS MARCADOS EN EL GRID
            // =================================================
            var tiposSeleccionados =
                new List<MYG_EX_Form.TipoData>();

            foreach (System.Windows.Forms.DataGridViewRow row in Form.dgvTipos.Rows)
            {
                bool seleccionado =
                    row.Cells[0].Value != null &&
                    Convert.ToBoolean(row.Cells[0].Value);

                if (!seleccionado)
                    continue;

                MYG_EX_Form.TipoData info =
                    row.Cells[2].Value as MYG_EX_Form.TipoData;

                if (info != null)
                    tiposSeleccionados.Add(info);
            }

            if (!tiposSeleccionados.Any())
            {
                TaskDialog.Show(
                    "MYG_REX",
                    "Seleccione al menos un tipo en la lista.");
                return;
            }

            bool desdeVinculo =
                Form.chkSeleccionarVinculos.Checked;

            var nuevaSeleccion =
                new List<SeleccionItem>();

            // =================================================
            // HOST
            // =================================================
            if (!desdeVinculo)
            {
                var refs = UiDoc.Selection.PickObjects(
                    ObjectType.Element,
                    new FiltroSeleccionVinculo(
                        doc,
                        categoria,
                        tiposSeleccionados,
                        false),
                    "Seleccione elementos");

                foreach (Reference r in refs)
                {
                    Element elem = doc.GetElement(r);

                    if (elem == null)
                        continue;

                    nuevaSeleccion.Add(
                        new SeleccionItem()
                        {
                            Elemento = elem,
                            Documento = doc,
                            Transformacion = Transform.Identity,
                            Vinculo = null
                        });
                }
            }
            // =================================================
            // VÍNCULO RVT
            // =================================================
            else
            {
                var refs = UiDoc.Selection.PickObjects(
                    ObjectType.LinkedElement,
                    new FiltroSeleccionVinculo(
                        doc,
                        categoria,
                        tiposSeleccionados,
                        true),
                    "Seleccione elementos dentro de vínculos RVT");

                foreach (Reference r in refs)
                {
                    RevitLinkInstance link =
                        doc.GetElement(r.ElementId) as RevitLinkInstance;

                    if (link == null)
                        continue;

                    Document linkDoc = link.GetLinkDocument();

                    if (linkDoc == null)
                        continue;

                    ElementId linkedId = r.LinkedElementId;

                    if (linkedId == null ||
                        linkedId == ElementId.InvalidElementId ||
                        linkedId.Value < 0)
                        continue;

                    Element elem = linkDoc.GetElement(linkedId);

                    if (elem == null)
                        continue;

                    nuevaSeleccion.Add(
                        new SeleccionItem()
                        {
                            Elemento = elem,
                            Documento = linkDoc,
                            Transformacion = link.GetTotalTransform(),
                            Vinculo = link
                        });
                }
            }

            // Solo cambia la selección si PickObjects terminó correctamente.
            Elementos = nuevaSeleccion;

            Form.ActualizarCantidad(Elementos.Count);
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            // Si el usuario cancela, conserva la selección anterior.
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG_REX",
                "Error al seleccionar elementos:\n\n" +
                ex.Message);
        }
    }

    public string GetName() => "MYG_REX Seleccionar";
}
