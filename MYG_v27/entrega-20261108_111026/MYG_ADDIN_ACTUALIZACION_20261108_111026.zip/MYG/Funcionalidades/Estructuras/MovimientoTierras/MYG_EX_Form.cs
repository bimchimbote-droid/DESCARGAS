using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    public class MYG_EX_Form : WinForms.Form
    {
        // Datos de tipo para soportar tipos del anfitrión y de vínculos RVT.
        // Está anidado en el Form para no crear otra clase global en tu proyecto.
        public class TipoData
        {
            public Document Documento;
            public ElementId TipoId;
            public string DocumentoTitulo;
            public string NombreTipo;
        }

        WinForms.Label lblCantidad;

        public Document Doc;
        public WinForms.Button btnSeleccionar;
        public WinForms.Button btnEjecutar;

        public WinForms.RadioButton rbSuelos;
        public WinForms.RadioButton rbCimentacion;
        public WinForms.RadioButton rbMuros;

        // Permite alternar selección en modelo anfitrión / RVT vinculado.
        public WinForms.CheckBox chkSeleccionarVinculos;

        public WinForms.DataGridView dgvTipos;

        public ExternalEvent SeleccionarEvent;
        public ExternalEvent EjecutarEvent;

        public MYG_EX_SeleccionarHandler HandlerSeleccion;

        private WinForms.CheckBox chkHeader;
        private WinForms.TextBox txtBuscar;

        public MYG_EX_Form()
        {
            this.Text = "⛏️ MYG EXCAVACIÓN";
            this.Width = 380;
            this.Height = 530;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.TopMost = true;

            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);

            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            lblCantidad = new WinForms.Label()
            {
                Text = "Elementos seleccionados: 0",
                Left = 20,
                Top = 30,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            rbSuelos = new WinForms.RadioButton()
            {
                Text = "Suelos",
                Left = 50,
                Top = 60,
                Width = 85
            };

            rbCimentacion = new WinForms.RadioButton()
            {
                Text = "Cimentación",
                Left = 145,
                Top = 60,
                Width = 120
            };

            rbMuros = new WinForms.RadioButton()
            {
                Text = "Muros",
                Left = 275,
                Top = 60,
                Width = 75
            };

            chkSeleccionarVinculos = new WinForms.CheckBox()
            {
                Text = "Seleccionar elementos de vínculos RVT",
                Left = 50,
                Top = 87,
                Width = 280,
                Height = 22,
                Checked = false,
                ForeColor = Drawing.Color.FromArgb(0, 70, 140)
            };

            rbSuelos.CheckedChanged += (s, e) => CargarTipos();
            rbCimentacion.CheckedChanged += (s, e) => CargarTipos();
            rbMuros.CheckedChanged += (s, e) => CargarTipos();
            chkSeleccionarVinculos.CheckedChanged += (s, e) => CargarTipos();

            var lblBuscar = new WinForms.Label()
            {
                Text = "🔍",
                Left = 25,
                Top = 120,
                Width = 30,
                Font = new Drawing.Font("Segoe UI Emoji", 10F)
            };

            var panelBuscar = new WinForms.Panel()
            {
                Left = 60,
                Top = 120,
                Width = 285,
                Height = 22,
                BackColor = Drawing.Color.White
            };

            panelBuscar.Paint += (s, e) =>
            {
                WinForms.ControlPaint.DrawBorder(e.Graphics, panelBuscar.ClientRectangle,
                    Drawing.Color.FromArgb(200, 200, 200), WinForms.ButtonBorderStyle.Solid);
            };

            txtBuscar = new WinForms.TextBox()
            {
                BorderStyle = WinForms.BorderStyle.None,
                Left = 5,
                Top = 3,
                Width = 275
            };

            txtBuscar.TextChanged += (s, e) => Filtrar(txtBuscar.Text);

            panelBuscar.Controls.Add(txtBuscar);

            // ================= GRID =================
            dgvTipos = new WinForms.DataGridView()
            {
                Left = 20,
                Top = 150,
                Width = 325,
                Height = this.ClientSize.Height - 265, // 👈 dinámico
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                SelectionMode = WinForms.DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                BackgroundColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            dgvTipos.Columns.Add(new WinForms.DataGridViewCheckBoxColumn()
            {
                Name = "",
                Width = 40
            });

            dgvTipos.Columns.Add(new WinForms.DataGridViewTextBoxColumn()
            {
                Name = "Tipo",
                Width = 285
            });

            dgvTipos.Columns.Add(new WinForms.DataGridViewTextBoxColumn()
            {
                Name = "Id",
                Visible = false
            });

            dgvTipos.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    var cell = dgvTipos.Rows[e.RowIndex].Cells[0];
                    cell.Value = !(cell.Value != null && (bool)cell.Value);
                }
            };

            // ================= CHECK HEADER =================
            chkHeader = new WinForms.CheckBox();
            chkHeader.Size = new Drawing.Size(15, 15);

            dgvTipos.Controls.Add(chkHeader);

            this.Shown += (s, e) => AjustarCheckHeader();

            dgvTipos.ColumnWidthChanged += (s, e) => AjustarCheckHeader();
            dgvTipos.Scroll += (s, e) => AjustarCheckHeader();

            chkHeader.CheckedChanged += (s, e) =>
            {
                foreach (WinForms.DataGridViewRow row in dgvTipos.Rows)
                    if (row.Visible)
                        row.Cells[0].Value = chkHeader.Checked;
            };

            // ================= BOTONES =================
            btnSeleccionar = new WinForms.Button()
            {
                Text = "SELECCIONAR ELEMENTOS",
                Width = 320,
                Height = 34,
                Left = 20,
                Top = this.ClientSize.Height - 90, // 👈 dinámico
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionar.FlatAppearance.BorderSize = 0;
            btnSeleccionar.Click += (s, e) => SeleccionarEvent?.Raise();

            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Width = 320,
                Height = 34,
                Left = 20,
                Top = this.ClientSize.Height - 45, // 👈 dinámico
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;
            btnEjecutar.Click += (s, e) => EjecutarEvent?.Raise();

            // ================= CONTROLES =================
            Controls.Add(lblAutor);
            Controls.Add(lblCantidad);
            Controls.Add(rbSuelos);
            Controls.Add(rbCimentacion);
            Controls.Add(rbMuros);
            Controls.Add(chkSeleccionarVinculos);
            Controls.Add(lblBuscar);
            Controls.Add(panelBuscar);
            Controls.Add(dgvTipos);
            Controls.Add(btnSeleccionar);
            Controls.Add(btnEjecutar);

            // ================= RESIZE =================
            this.Resize += (s, e) =>
            {
                dgvTipos.Height = this.ClientSize.Height - 265;

                btnSeleccionar.Top = this.ClientSize.Height - 90;
                btnEjecutar.Top = this.ClientSize.Height - 45;
            };
        }

        private void AjustarCheckHeader()
        {
            var rect = dgvTipos.GetCellDisplayRectangle(0, -1, true);

            int offsetX = 3;
            int offsetY = 3;

            chkHeader.Location = new Drawing.Point(
                rect.X + (rect.Width - chkHeader.Width) / 2 + offsetX,
                rect.Y + (rect.Height - chkHeader.Height) / 2 + offsetY);
        }

        private void Filtrar(string texto)
        {
            texto = texto.ToLower();

            foreach (WinForms.DataGridViewRow row in dgvTipos.Rows)
            {
                if (row.Cells[1].Value == null) continue;

                string valor = row.Cells[1].Value.ToString().ToLower();
                row.Visible = valor.Contains(texto);
            }
        }

        public void ActualizarCantidad(int cantidad)
        {
            lblCantidad.Text = $"Elementos seleccionados: {cantidad}";
        }

        private void CargarTipos()
        {
            dgvTipos.Rows.Clear();

            if (Doc == null) return;

            BuiltInCategory categoria;

            if (rbSuelos.Checked)
                categoria = BuiltInCategory.OST_Floors;
            else if (rbCimentacion.Checked)
                categoria = BuiltInCategory.OST_StructuralFoundation;
            else if (rbMuros.Checked)
                categoria = BuiltInCategory.OST_Walls;
            else
                return;

            // =====================================================
            // MODELO ANFITRIÓN
            // =====================================================
            if (!chkSeleccionarVinculos.Checked)
            {
                AgregarTiposDocumento(Doc, categoria, false);
                return;
            }

            // =====================================================
            // VÍNCULOS RVT CARGADOS
            // =====================================================
            var documentosAgregados =
                new System.Collections.Generic.HashSet<Document>();

            var links = new FilteredElementCollector(Doc)
                .OfClass(typeof(RevitLinkInstance))
                .Cast<RevitLinkInstance>()
                .ToList();

            foreach (var link in links)
            {
                Document linkDoc = link.GetLinkDocument();
                if (linkDoc == null) continue;

                // Si el mismo RVT está colocado varias veces,
                // sus tipos se muestran una sola vez.
                if (!documentosAgregados.Add(linkDoc))
                    continue;

                AgregarTiposDocumento(linkDoc, categoria, true);
            }
        }

        private void AgregarTiposDocumento(
            Document sourceDoc,
            BuiltInCategory categoria,
            bool esVinculo)
        {
            if (sourceDoc == null) return;

            var typeIds = new FilteredElementCollector(sourceDoc)
                .OfCategory(categoria)
                .WhereElementIsNotElementType()
                .Select(e => e.GetTypeId())
                .Where(id => id != null && id.Value >= 0)
                .Distinct()
                .ToList();

            foreach (var id in typeIds)
            {
                Element tipo = sourceDoc.GetElement(id);
                if (tipo == null) continue;

                string nombreMostrar = esVinculo
                    ? "[" + sourceDoc.Title + "]  " + tipo.Name
                    : tipo.Name;

                var info = new TipoData()
                {
                    Documento = sourceDoc,
                    TipoId = tipo.Id,
                    DocumentoTitulo = sourceDoc.Title,
                    NombreTipo = tipo.Name
                };

                dgvTipos.Rows.Add(false, nombreMostrar, info);
            }
        }
    }

}
