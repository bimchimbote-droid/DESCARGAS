using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{
















    // =====================================
    // VENTANA EMERGENTE 3.1 (MYG_REX PRO)
    // =====================================
    public class MYG_REX_Form : WinForms.Form
    {
        public Action OnRex;
        public Action OnRell;

        public MYG_REX_Form(string assemblyPath)
        {
            this.Text = "MYG REX";
            this.Width = 420;
            this.Height = 260;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.TopMost = true;
            this.BackColor = System.Drawing.Color.White;

            // =========================================================
            // RUTA DE ICONOS
            // =========================================================
            // En ejecución normal Assembly.Location contiene la ruta.
            // Add-in Manager puede cargar la DLL de forma que Location
            // llegue vacío. En ese caso usamos la carpeta estándar de MYG.
            string folderPath = null;

            if (!string.IsNullOrWhiteSpace(assemblyPath))
            {
                try
                {
                    folderPath = System.IO.Path.GetDirectoryName(assemblyPath);
                }
                catch
                {
                    folderPath = null;
                }
            }

            // FALLBACK PARA ADD-IN MANAGER
            if (string.IsNullOrWhiteSpace(folderPath))
            {
                string appData = System.Environment.GetFolderPath(
                    System.Environment.SpecialFolder.ApplicationData);

                folderPath = System.IO.Path.Combine(
                    appData,
                    "Autodesk",
                    "Revit",
                    "Addins",
                    "2027",
                    "MYG");
            }

            string imgRexPath = System.IO.Path.Combine(
                folderPath,
                "iconos",
                "excavacion.png");

            string imgRellPath = System.IO.Path.Combine(
                folderPath,
                "iconos",
                "relleno.png");

            // =========================================================
            // CREAR BOTÓN
            // =========================================================
            WinForms.Button CrearBoton(string rutaImagen, int left, int top)
            {
                var btn = new WinForms.Button()
                {
                    Width = 170,
                    Height = 130,
                    Left = left,
                    Top = top,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    Cursor = WinForms.Cursors.Hand,
                    BackColor = System.Drawing.Color.White
                };

                btn.FlatAppearance.BorderSize = 0;

                // El icono nunca debe impedir que se abra MYG REX.
                try
                {
                    if (!string.IsNullOrWhiteSpace(rutaImagen) &&
                        System.IO.File.Exists(rutaImagen))
                    {
                        btn.BackgroundImage =
                            System.Drawing.Image.FromFile(rutaImagen);

                        btn.BackgroundImageLayout =
                            WinForms.ImageLayout.Stretch;
                    }
                }
                catch
                {
                    // Ignorar únicamente errores de carga del icono.
                }

                // HOVER
                btn.MouseEnter += (s, e) =>
                {
                    btn.FlatAppearance.BorderSize = 2;
                    btn.FlatAppearance.BorderColor =
                        System.Drawing.Color.DodgerBlue;
                };

                btn.MouseLeave += (s, e) =>
                {
                    btn.FlatAppearance.BorderSize = 0;
                };

                btn.MouseDown += (s, e) =>
                {
                    btn.BackColor = System.Drawing.Color.LightGray;
                };

                btn.MouseUp += (s, e) =>
                {
                    btn.BackColor = System.Drawing.Color.White;
                };

                return btn;
            }

            // =========================================================
            // BOTONES
            // =========================================================
            var btnRex = CrearBoton(imgRexPath, 30, 30);
            var btnRell = CrearBoton(imgRellPath, 210, 30);

            // =========================================================
            // EVENTOS
            // =========================================================
            btnRex.Click += (s, e) =>
            {
                this.Close();
                OnRex?.Invoke();
            };

            btnRell.Click += (s, e) =>
            {
                this.Close();
                OnRell?.Invoke();
            };

            Controls.Add(btnRex);
            Controls.Add(btnRell);
        }
    }

}
