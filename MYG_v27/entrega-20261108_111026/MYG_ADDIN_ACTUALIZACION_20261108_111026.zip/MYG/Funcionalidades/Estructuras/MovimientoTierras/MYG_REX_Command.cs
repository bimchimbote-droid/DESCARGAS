using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // COMANDO 6.7 - MYG_REX
    // =====================================

    [Transaction(TransactionMode.Manual)]
    public class MYG_REX_Command : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            try
            {
                string assemblyPath = System.Reflection.Assembly
                    .GetExecutingAssembly()
                    .Location;

                var selector = new MYG_REX_Form(assemblyPath);

                // =========================================
                // 👉 MYG REX (EXCAVACIÓN)
                // =========================================
                selector.OnRex = () =>
                {
                    var form = new MYG_EX_Form();
                    form.Doc = doc;

                    // 🔹 SELECCIÓN (IGUAL QUE TU COMANDO ORIGINAL)
                    var hSel = new MYG_EX_SeleccionarHandler()
                    {
                        UiDoc = uidoc,
                        Form = form
                    };

                    form.SeleccionarEvent = ExternalEvent.Create(hSel);

                    // 🔹 EJECUCIÓN (RESPETANDO TU LÓGICA REAL)
                    var hExe = new MYG_EX_EjecutarHandler()
                    {
                        UiDoc = uidoc,
                        HandlerSeleccion = hSel // 🔴 CLAVE (esto es tu patrón real)
                    };

                    form.EjecutarEvent = ExternalEvent.Create(hExe);

                    form.Show();
                };

                // =========================================
                // 👉 MYG RELL (RELLENO)
                // =========================================
                selector.OnRell = () =>
                {
                    var form = new MYG_RELL_Form();
                    form.Doc = doc;

                    // 🔹 SELECCIÓN
                    var hSel = new MYG_RELL_SeleccionarHandler()
                    {
                        UiDoc = uidoc,
                        Form = form
                    };

                    form.SeleccionarEvent = ExternalEvent.Create(hSel);

                    // 🔹 EJECUCIÓN
                    var hExe = new MYG_RELL_EjecutarHandler()
                    {
                        UiDoc = uidoc,
                        HandlerSeleccion = hSel // 🔴 MISMO PATRÓN
                    };

                    form.EjecutarEvent = ExternalEvent.Create(hExe);

                    form.Show();
                };

                selector.ShowDialog();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }
    }

}
