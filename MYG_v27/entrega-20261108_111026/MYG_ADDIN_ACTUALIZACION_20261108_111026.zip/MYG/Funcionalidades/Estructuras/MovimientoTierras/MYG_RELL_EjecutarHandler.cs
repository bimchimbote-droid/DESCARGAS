﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.ApplicationServices;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

// =============================================================
// MYG_RELL - EJECUTAR
// Revit 2027
//
// CORRECCIÓN PRINCIPAL:
// - La cara inferior del TOP limita realmente el relleno.
// - La cara superior del BOTTOM inicia realmente el relleno.
// - No se calcula una sola altura Z.
// - Se construye el volumen entre caras mediante intersección
//   de prismas verticales, por lo que funciona con:
//      * BOTTOM horizontal
//      * BOTTOM inclinado
//      * TOP horizontal
//      * TOP inclinado
//      * superficies mixtas / facetadas
//      * elementos del host y de vínculos RVT
// - V3: corte forzado entre masas MYG_RELLENO ya creadas.
// =============================================================
public class MYG_RELL_EjecutarHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public MYG_RELL_SeleccionarHandler HandlerSeleccion;

    // Tolerancias geométricas internas en pies/unidades internas de Revit.
    private const double TOL_VOLUME = 1e-8;
    private const double TOL_NORMAL_Z = 0.01;

    public void Execute(UIApplication app)
    {
        Document doc = UiDoc.Document;

        if (HandlerSeleccion == null)
        {
            TaskDialog.Show("MYG_RELL", "No se encontró el Handler de selección.");
            return;
        }

        if (HandlerSeleccion.Bottom == null || !HandlerSeleccion.Bottom.Any())
        {
            TaskDialog.Show("MYG_RELL", "No hay elementos BOTTOM.");
            return;
        }

        if (HandlerSeleccion.Top == null || !HandlerSeleccion.Top.Any())
        {
            TaskDialog.Show("MYG_RELL", "No hay elementos TOP.");
            return;
        }

        int creados = 0;
        int omitidos = 0;
        List<string> errores = new List<string>();

        using (Transaction t = new Transaction(doc, "MYG_RELL Crear Masa PRO"))
        {
            t.Start();

            bool incluirVinculosDescuento =
                HandlerSeleccion.Bottom.Any(x => x != null && x.EsVinculado) ||
                HandlerSeleccion.Top.Any(x => x != null && x.EsVinculado);

            // =========================================================
            // MASAS DE RELLENO YA CREADAS POR EL ADD-IN
            //
            // Se manejan en una lista SEPARADA y se cortan ANTES que
            // cualquier otro elemento. Esto evita clashes entre masas
            // MYG_RELLENO de ejecuciones anteriores y de esta ejecución.
            // =========================================================
            var masasRellenoDescontar =
                ObtenerMasasRellenoExistentes(
                    doc,
                    incluirVinculosDescuento);

            // Elementos estructurales/arquitectónicos normales.
            // Las masas MYG_RELLENO ya NO se mezclan aquí.
            var elementosDescontar =
                ObtenerElementosDescontar(doc, incluirVinculosDescuento);

            foreach (var baseSeleccion in HandlerSeleccion.Bottom)
            {
                if (baseSeleccion == null || baseSeleccion.Elemento == null)
                {
                    omitidos++;
                    continue;
                }

                Element baseElem = baseSeleccion.Elemento;
                Document baseDoc = baseSeleccion.Documento ?? doc;

                try
                {
                    // =========================================================
                    // 1. OBTENER TODOS LOS SÓLIDOS DEL BOTTOM
                    // =========================================================
                    List<Solid> solidsBottom = ObtenerSolids(
                        baseElem,
                        baseSeleccion.Transformacion ?? Transform.Identity);

                    if (solidsBottom.Count == 0)
                    {
                        omitidos++;
                        errores.Add(
                            "BOTTOM Id " + baseElem.Id.Value +
                            ": no se encontraron sólidos válidos.");
                        continue;
                    }

                    // =========================================================
                    // 2. BUSCAR EL TOP MÁS CERCANO QUE REALMENTE SE SUPERPONGA
                    //    EN PLANTA CON EL BOTTOM.
                    //
                    //    IMPORTANTE:
                    //    ya no se compara Face.Origin.Z.
                    //    Se crea el volumen real entre:
                    //       cara SUPERIOR del BOTTOM
                    //       cara INFERIOR del TOP
                    // =========================================================
                    MYG_RELL_SeleccionarHandler.SeleccionItem topMasCercano = null;
                    List<Solid> piezasMejorTop = null;
                    double mejorEspesorMedio = double.MaxValue;

                    foreach (var topSeleccion in HandlerSeleccion.Top)
                    {
                        if (topSeleccion == null || topSeleccion.Elemento == null)
                            continue;

                        List<Solid> solidsTop = ObtenerSolids(
                            topSeleccion.Elemento,
                            topSeleccion.Transformacion ?? Transform.Identity);

                        if (solidsTop.Count == 0)
                            continue;

                        List<Solid> piezasEntre = CrearSolidosEntreSuperficies(
                            solidsBottom,
                            solidsTop);

                        if (piezasEntre.Count == 0)
                            continue;

                        double espesorMedio =
                            CalcularEspesorMedioVertical(piezasEntre);

                        if (double.IsNaN(espesorMedio) ||
                            double.IsInfinity(espesorMedio) ||
                            espesorMedio <= 0)
                            continue;

                        if (espesorMedio < mejorEspesorMedio)
                        {
                            mejorEspesorMedio = espesorMedio;
                            topMasCercano = topSeleccion;
                            piezasMejorTop = piezasEntre;
                        }
                    }

                    if (topMasCercano == null ||
                        piezasMejorTop == null ||
                        piezasMejorTop.Count == 0)
                    {
                        omitidos++;
                        errores.Add(
                            "BOTTOM Id " + baseElem.Id.Value +
                            ": no se encontró un TOP válido por encima " +
                            "con superposición geométrica.");
                        continue;
                    }

                    // =========================================================
                    // 3A. CORTAR PRIMERO CON TODAS LAS MASAS MYG_RELLENO
                    //     YA EXISTENTES.
                    //
                    // Esto es intencionalmente independiente del resto de
                    // descuentos para garantizar que nunca se cree una masa
                    // nueva invadiendo otra masa de relleno del add-in.
                    // =========================================================
                    List<Solid> piezasFinales =
                        AplicarDescuentosMasasRelleno(
                            piezasMejorTop,
                            masasRellenoDescontar,
                            baseElem.Id.Value,
                            errores);

                    // Si una masa existente ocupa todo el volumen candidato,
                    // no hay nada nuevo que crear.
                    if (piezasFinales.Count == 0)
                    {
                        omitidos++;
                        continue;
                    }

                    // =========================================================
                    // 3B. DESCONTAR COLUMNAS, VIGAS, SUELOS, MUROS, ETC.
                    // =========================================================
                    piezasFinales =
                        AplicarDescuentos(
                            piezasFinales,
                            elementosDescontar,
                            baseSeleccion,
                            topMasCercano);

                    piezasFinales =
                        piezasFinales
                        .Where(s => EsSolidValido(s))
                        .ToList();

                    if (piezasFinales.Count == 0)
                    {
                        omitidos++;
                        errores.Add(
                            "BOTTOM Id " + baseElem.Id.Value +
                            ": el relleno quedó sin volumen luego de descuentos.");
                        continue;
                    }

                    // =========================================================
                    // 4. CREAR UNA SOLA FAMILIA DE MASA, AUNQUE EL RELLENO
                    //    ESTÉ COMPUESTO POR VARIAS PIEZAS/FACETAS.
                    // =========================================================
                    FamilyInstance instancia =
                        CrearFamiliaVoid(doc, piezasFinales);

                    if (instancia == null)
                    {
                        omitidos++;
                        errores.Add(
                            "BOTTOM Id " + baseElem.Id.Value +
                            ": no se pudo crear la familia de relleno.");
                        continue;
                    }

                    // =========================================================
                    // 5. DESCRIPCIÓN
                    // =========================================================
                    string descripcionFinal = "Relleno";

                    try
                    {
                        Element tipoBase =
                            baseDoc.GetElement(baseElem.GetTypeId());

                        if (tipoBase != null)
                        {
                            Parameter pBase =
                                tipoBase.LookupParameter("Descripción");

                            if (pBase != null && pBase.HasValue)
                            {
                                string valor = pBase.AsString();

                                if (!string.IsNullOrWhiteSpace(valor))
                                    descripcionFinal = "Relleno en " + valor;
                            }
                        }
                    }
                    catch
                    {
                        // Si no existe descripción, conservar "Relleno".
                    }

                    try
                    {
                        Parameter pDesc =
                            instancia.Symbol.LookupParameter("Descripción");

                        if (pDesc != null && !pDesc.IsReadOnly)
                            pDesc.Set(descripcionFinal);
                    }
                    catch
                    {
                    }

                    doc.Regenerate();

                    // =========================================================
                    // 6. MARCAR LA INSTANCIA COMO MYG_RELLENO.
                    //    El nombre de la familia ya comienza con MYG_RELLENO,
                    //    pero Comentarios queda como respaldo para futuras
                    //    ejecuciones/versiones del add-in.
                    // =========================================================
                    MarcarComoRellenoMYG(instancia);

                    doc.Regenerate();

                    // =========================================================
                    // 7. EL RELLENO RECIÉN CREADO SE AGREGA INMEDIATAMENTE
                    //    A LA LISTA DE CORTADORES.
                    //
                    // Por eso, si en esta MISMA ejecución se generan A, B y C:
                    //   B se corta con A
                    //   C se corta con A y B
                    // evitando clashes también dentro del mismo proceso.
                    // =========================================================
                    masasRellenoDescontar.Add(
                        new MYG_RELL_SeleccionarHandler.SeleccionItem()
                        {
                            Elemento = instancia,
                            Documento = doc,
                            Transformacion = Transform.Identity,
                            Vinculo = null
                        });

                    creados++;
                }
                catch (Exception ex)
                {
                    omitidos++;

                    errores.Add(
                        "BOTTOM Id " + baseElem.Id.Value +
                        ": " + ex.Message);
                }
            }

            // Crear/asegurar filtros en la vista activa.
            CrearFiltros(doc, doc.ActiveView);

            t.Commit();
        }

        // Mostrar reporte únicamente cuando haya algo que informar.
        if (errores.Count > 0)
        {
            string detalle = string.Join(
                "\n",
                errores.Take(15).Select(x => "• " + x));

            if (errores.Count > 15)
                detalle += "\n• ... " + (errores.Count - 15) + " incidencias adicionales.";

            TaskDialog.Show(
                "MYG_RELL",
                "Proceso terminado.\n\n" +
                "Rellenos creados: " + creados + "\n" +
                "BOTTOM omitidos: " + omitidos + "\n\n" +
                detalle);
        }
    }

    public string GetName()
    {
        return "MYG_RELL Ejecutar";
    }

    // =============================================================
    // CREAR VOLUMEN REAL ENTRE SUPERFICIES
    // =============================================================
    private List<Solid> CrearSolidosEntreSuperficies(
        List<Solid> solidsBottom,
        List<Solid> solidsTop)
    {
        List<Solid> resultado = new List<Solid>();

        if (solidsBottom == null || solidsBottom.Count == 0)
            return resultado;

        if (solidsTop == null || solidsTop.Count == 0)
            return resultado;

        List<PlanarFace> carasSuperioresBottom =
            ObtenerCarasPorOrientacion(solidsBottom, true);

        List<PlanarFace> carasInferioresTop =
            ObtenerCarasPorOrientacion(solidsTop, false);

        if (carasSuperioresBottom.Count == 0 ||
            carasInferioresTop.Count == 0)
            return resultado;

        double distanciaExtrusion =
            CalcularDistanciaExtrusion(solidsBottom, solidsTop);

        // Crear una vez los prismas superiores e inferiores.
        List<Solid> prismasBottom = new List<Solid>();
        List<Solid> prismasTop = new List<Solid>();

        foreach (PlanarFace cara in carasSuperioresBottom)
        {
            Solid prisma = CrearPrismaDesdeCara(
                cara,
                XYZ.BasisZ,
                distanciaExtrusion);

            if (EsSolidValido(prisma))
                prismasBottom.Add(prisma);
        }

        foreach (PlanarFace cara in carasInferioresTop)
        {
            Solid prisma = CrearPrismaDesdeCara(
                cara,
                -XYZ.BasisZ,
                distanciaExtrusion);

            if (EsSolidValido(prisma))
                prismasTop.Add(prisma);
        }

        // La intersección entre:
        // - prisma hacia ARRIBA desde BOTTOM
        // - prisma hacia ABAJO desde TOP
        //
        // produce exactamente el volumen comprendido entre ambas caras.
        foreach (Solid prismaBottom in prismasBottom)
        {
            foreach (Solid prismaTop in prismasTop)
            {
                try
                {
                    Solid interseccion =
                        BooleanOperationsUtils.ExecuteBooleanOperation(
                            prismaBottom,
                            prismaTop,
                            BooleanOperationsType.Intersect);

                    if (EsSolidValido(interseccion))
                        resultado.Add(interseccion);
                }
                catch
                {
                    // Dos caras sin intersección o caso booleano degenerado.
                }
            }
        }

        return resultado;
    }

    // =============================================================
    // CARAS SUPERIORES / INFERIORES
    //
    // superior = normal Z positiva
    // inferior = normal Z negativa
    //
    // Se admiten caras inclinadas. No se exige Z > 0.9.
    // =============================================================
    private List<PlanarFace> ObtenerCarasPorOrientacion(
        List<Solid> solids,
        bool superiores)
    {
        List<PlanarFace> resultado = new List<PlanarFace>();

        foreach (Solid solid in solids)
        {
            if (!EsSolidValido(solid))
                continue;

            foreach (Face face in solid.Faces)
            {
                PlanarFace pf = face as PlanarFace;

                if (pf == null)
                    continue;

                double nz = pf.FaceNormal.Z;

                if (superiores)
                {
                    if (nz > TOL_NORMAL_Z)
                        resultado.Add(pf);
                }
                else
                {
                    if (nz < -TOL_NORMAL_Z)
                        resultado.Add(pf);
                }
            }
        }

        return resultado;
    }

    // =============================================================
    // EXTRUIR UNA CARA EN DIRECCIÓN VERTICAL
    // =============================================================
    private Solid CrearPrismaDesdeCara(
        PlanarFace cara,
        XYZ direccion,
        double distancia)
    {
        if (cara == null)
            return null;

        if (distancia <= 0)
            return null;

        try
        {
            IList<CurveLoop> loops =
                cara.GetEdgesAsCurveLoops();

            if (loops == null || loops.Count == 0)
                return null;

            return GeometryCreationUtilities.CreateExtrusionGeometry(
                loops,
                direccion,
                distancia);
        }
        catch
        {
            return null;
        }
    }

    // =============================================================
    // DISTANCIA SEGURA DE EXTRUSIÓN
    // =============================================================
    private double CalcularDistanciaExtrusion(
        List<Solid> solidsA,
        List<Solid> solidsB)
    {
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;

        AcumularRangoZ(solidsA, ref minZ, ref maxZ);
        AcumularRangoZ(solidsB, ref minZ, ref maxZ);

        if (minZ == double.MaxValue || maxZ == double.MinValue)
            return 1000.0;

        double rango = Math.Abs(maxZ - minZ);

        // 100 pies de margen para asegurar que ambos prismas se crucen.
        return Math.Max(100.0, rango + 100.0);
    }

    private void AcumularRangoZ(
        IEnumerable<Solid> solids,
        ref double minZ,
        ref double maxZ)
    {
        if (solids == null)
            return;

        foreach (Solid solid in solids)
        {
            if (!EsSolidValido(solid))
                continue;

            foreach (Edge edge in solid.Edges)
            {
                try
                {
                    IList<XYZ> puntos = edge.Tessellate();

                    foreach (XYZ p in puntos)
                    {
                        if (p == null)
                            continue;

                        if (p.Z < minZ) minZ = p.Z;
                        if (p.Z > maxZ) maxZ = p.Z;
                    }
                }
                catch
                {
                }
            }
        }
    }

    // =============================================================
    // ESPESOR MEDIO VERTICAL
    //
    // Se usa para escoger el TOP realmente más cercano.
    // Volumen / área proyectada XY = espesor vertical medio.
    // =============================================================
    private double CalcularEspesorMedioVertical(
        List<Solid> solids)
    {
        double volumen = 0.0;
        double areaXY = 0.0;

        foreach (Solid solid in solids)
        {
            if (!EsSolidValido(solid))
                continue;

            volumen += solid.Volume;
            areaXY += CalcularAreaProyectadaXY(solid);
        }

        if (volumen <= TOL_VOLUME || areaXY <= TOL_VOLUME)
            return double.MaxValue;

        return volumen / areaXY;
    }

    private double CalcularAreaProyectadaXY(Solid solid)
    {
        if (!EsSolidValido(solid))
            return 0.0;

        double area = 0.0;

        foreach (Face face in solid.Faces)
        {
            PlanarFace pf = face as PlanarFace;

            if (pf == null)
                continue;

            // Sólo caras que miran hacia arriba.
            // Las caras laterales de prismas verticales tienen nz ~ 0.
            double nz = pf.FaceNormal.Z;

            if (nz > TOL_NORMAL_Z)
                area += face.Area * nz;
        }

        return area;
    }

    // =============================================================
    // CORTE PRIORITARIO CONTRA MASAS MYG_RELLENO
    //
    // V3:
    // - NO usa Intersect como condición previa.
    // - Intenta Difference directamente.
    // - Si Revit falla por caras coincidentes, usa cortadores desplazados
    //   en una envolvente de tolerancia para eliminar el clash residual.
    // =============================================================
    private List<Solid> AplicarDescuentosMasasRelleno(
        List<Solid> piezasIniciales,
        List<MYG_RELL_SeleccionarHandler.SeleccionItem> masasRelleno,
        long bottomId,
        List<string> errores)
    {
        List<Solid> piezas =
            piezasIniciales
            .Where(s => EsSolidValido(s))
            .ToList();

        if (piezas.Count == 0)
            return piezas;

        if (masasRelleno == null || masasRelleno.Count == 0)
            return piezas;

        foreach (var masa in masasRelleno)
        {
            if (masa == null || masa.Elemento == null)
                continue;

            List<Solid> cortadores =
                ObtenerSolids(
                    masa.Elemento,
                    masa.Transformacion ?? Transform.Identity);

            if (cortadores.Count == 0)
            {
                if (errores != null)
                {
                    errores.Add(
                        "BOTTOM Id " + bottomId +
                        ": se detectó MYG_RELLENO Id " +
                        masa.Elemento.Id.Value +
                        " pero no se pudo leer su geometría sólida.");
                }

                continue;
            }

            foreach (Solid cortador in cortadores)
            {
                if (!EsSolidValido(cortador))
                    continue;

                List<Solid> nuevasPiezas = new List<Solid>();

                foreach (Solid pieza in piezas)
                {
                    if (!EsSolidValido(pieza))
                        continue;

                    bool huboCorte;
                    bool corteFallido;

                    Solid diferencia =
                        RestarSolidForzado(
                            pieza,
                            cortador,
                            out huboCorte,
                            out corteFallido);

                    if (corteFallido && errores != null)
                    {
                        errores.Add(
                            "BOTTOM Id " + bottomId +
                            ": quedó una incidencia geométrica al cortar " +
                            "contra MYG_RELLENO Id " +
                            masa.Elemento.Id.Value + ".");
                    }

                    // null = el relleno existente consumió toda la pieza.
                    if (EsSolidValido(diferencia))
                        nuevasPiezas.Add(diferencia);
                }

                piezas = nuevasPiezas;

                if (piezas.Count == 0)
                    return piezas;
            }
        }

        return piezas;
    }

    // =============================================================
    // DIFFERENCE FORZADO / SIN CLASH
    //
    // El fallo de la versión anterior estaba aquí:
    // primero se llamaba a Intersect y, si ese booleano fallaba,
    // se interpretaba como "no hay solape". En caras coplanares Revit
    // puede fallar precisamente en Intersect, por lo que nunca se llegaba
    // a ejecutar Difference.
    //
    // Esta versión:
    // 1) filtra sólo por caja envolvente;
    // 2) intenta Difference directamente;
    // 3) si falla por coincidencia de caras, crea una envolvente de
    //    tolerancia con copias desplazadas del cortador;
    // 4) vuelve a verificar y reintenta con una tolerancia mayor sólo
    //    cuando todavía queda intersección real.
    // =============================================================
    private Solid RestarSolidForzado(
        Solid pieza,
        Solid cortador,
        out bool huboCorte,
        out bool corteFallido)
    {
        huboCorte = false;
        corteFallido = false;

        if (!EsSolidValido(pieza) || !EsSolidValido(cortador))
            return pieza;

        double tolCaja = UnitUtils.ConvertToInternalUnits(
            0.5,
            UnitTypeId.Millimeters);

        if (!CajasSeSolapan(pieza, cortador, tolCaja))
            return pieza;

        double volumenOriginal = 0.0;

        try
        {
            volumenOriginal = pieza.Volume;
        }
        catch
        {
            return pieza;
        }

        // ---------------------------------------------------------
        // A. DIFFERENCE EXACTO. NO HACER INTERSECT ANTES.
        // ---------------------------------------------------------
        try
        {
            Solid exacta =
                BooleanOperationsUtils.ExecuteBooleanOperation(
                    pieza,
                    cortador,
                    BooleanOperationsType.Difference);

            if (!EsSolidValido(exacta))
            {
                // Si las cajas se solapan y Difference devuelve vacío,
                // considerar que el cortador consumió la pieza.
                huboCorte = true;
                return null;
            }

            double reduccion = volumenOriginal - exacta.Volume;
            double tolReduccion = Math.Max(
                TOL_VOLUME,
                volumenOriginal * 1e-10);

            if (reduccion > tolReduccion)
            {
                huboCorte = true;

                // Verificar si quedó intersección residual.
                double residual;
                bool verificacionValida =
                    TryVolumenInterseccion(exacta, cortador, out residual);

                if (!verificacionValida || residual <= TOL_VOLUME)
                    return exacta;

                // Difference funcionó pero quedó residuo numérico:
                // seguir con exacta como pieza de trabajo.
                pieza = exacta;
                volumenOriginal = exacta.Volume;
            }
            else
            {
                // Difference exacto no cambió el sólido.
                // Si Intersect puede demostrar que no hay volumen común,
                // no hay nada que cortar.
                double vInter;
                bool pudoVerificar =
                    TryVolumenInterseccion(pieza, cortador, out vInter);

                if (pudoVerificar && vInter <= TOL_VOLUME)
                    return pieza;

                // Si Intersect falla, NO asumir que no hay clash.
                // Pasar a recuperación por tolerancia.
            }
        }
        catch
        {
            // Caras coplanares/coincidentes: pasar a recuperación.
        }

        // ---------------------------------------------------------
        // B. RECUPERACIÓN: "ENGROSAR" NUMÉRICAMENTE EL CORTADOR.
        //
        // No existe un OffsetSolid genérico en la API para este caso.
        // Se consigue el mismo objetivo restando copias desplazadas del
        // cortador alrededor de su posición original.
        // ---------------------------------------------------------
        Solid trabajo = pieza;

        double eps1 = UnitUtils.ConvertToInternalUnits(
            1.0,
            UnitTypeId.Millimeters);

        trabajo = RestarConEnvolventeDesplazada(
            trabajo,
            cortador,
            eps1,
            ref huboCorte);

        if (!EsSolidValido(trabajo))
            return null;

        // ---------------------------------------------------------
        // C. VERIFICACIÓN CONTRA EL CORTADOR ORIGINAL.
        // ---------------------------------------------------------
        double residual1;
        bool check1 =
            TryVolumenInterseccion(
                trabajo,
                cortador,
                out residual1);

        if (check1 && residual1 <= TOL_VOLUME)
            return trabajo;

        // Si la comprobación no pudo resolverse o todavía queda residual,
        // hacer una segunda recuperación de 2 mm.
        double eps2 = UnitUtils.ConvertToInternalUnits(
            2.0,
            UnitTypeId.Millimeters);

        trabajo = RestarConEnvolventeDesplazada(
            trabajo,
            cortador,
            eps2,
            ref huboCorte);

        if (!EsSolidValido(trabajo))
            return null;

        // Último intento exacto después de limpiar caras coincidentes.
        try
        {
            Solid finalExacto =
                BooleanOperationsUtils.ExecuteBooleanOperation(
                    trabajo,
                    cortador,
                    BooleanOperationsType.Difference);

            if (!EsSolidValido(finalExacto))
            {
                huboCorte = true;
                return null;
            }

            if (finalExacto.Volume < trabajo.Volume - TOL_VOLUME)
                huboCorte = true;

            trabajo = finalExacto;
        }
        catch
        {
        }

        // Verificación final. Si Revit puede calcular la intersección y
        // todavía existe volumen compartido, reportarlo.
        double residualFinal;
        bool checkFinal =
            TryVolumenInterseccion(
                trabajo,
                cortador,
                out residualFinal);

        if (checkFinal && residualFinal > TOL_VOLUME)
            corteFallido = true;

        return trabajo;
    }

    // =============================================================
    // RESTAR UNA ENVOLVENTE DE COPIAS DESPLAZADAS
    //
    // Se usan las 26 posiciones vecinas de un cubo +/- epsilon.
    // Esto evita que una cara exactamente coincidente impida el booleano.
    // Sólo se ejecuta cuando Difference exacto no resolvió el caso.
    // =============================================================
    private Solid RestarConEnvolventeDesplazada(
        Solid pieza,
        Solid cortador,
        double epsilon,
        ref bool huboCorte)
    {
        if (!EsSolidValido(pieza) || !EsSolidValido(cortador))
            return pieza;

        Solid trabajo = pieza;

        int[] signos = new int[] { -1, 0, 1 };

        foreach (int ix in signos)
        {
            foreach (int iy in signos)
            {
                foreach (int iz in signos)
                {
                    if (ix == 0 && iy == 0 && iz == 0)
                        continue;

                    if (!EsSolidValido(trabajo))
                        return null;

                    XYZ vector = new XYZ(
                        ix * epsilon,
                        iy * epsilon,
                        iz * epsilon);

                    Solid cortadorMovido = null;

                    try
                    {
                        Transform tr =
                            Transform.CreateTranslation(vector);

                        cortadorMovido =
                            SolidUtils.CreateTransformed(
                                cortador,
                                tr);
                    }
                    catch
                    {
                        continue;
                    }

                    if (!EsSolidValido(cortadorMovido))
                        continue;

                    // Caja envolvente primero: mucho más barato que booleanos.
                    if (!CajasSeSolapan(
                        trabajo,
                        cortadorMovido,
                        epsilon * 0.25))
                        continue;

                    double antes = 0.0;

                    try
                    {
                        antes = trabajo.Volume;
                    }
                    catch
                    {
                        continue;
                    }

                    try
                    {
                        Solid d =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                trabajo,
                                cortadorMovido,
                                BooleanOperationsType.Difference);

                        if (!EsSolidValido(d))
                        {
                            huboCorte = true;
                            return null;
                        }

                        if (d.Volume < antes - TOL_VOLUME)
                        {
                            trabajo = d;
                            huboCorte = true;
                        }
                    }
                    catch
                    {
                        // Probar la siguiente copia desplazada.
                    }
                }
            }
        }

        return trabajo;
    }

    // =============================================================
    // INTERSECCIÓN SEGURA.
    // A diferencia de la versión anterior, un fallo devuelve FALSE
    // (estado desconocido), no volumen cero.
    // =============================================================
    private bool TryVolumenInterseccion(
        Solid a,
        Solid b,
        out double volumen)
    {
        volumen = 0.0;

        if (!EsSolidValido(a) || !EsSolidValido(b))
            return true;

        try
        {
            Solid inter =
                BooleanOperationsUtils.ExecuteBooleanOperation(
                    a,
                    b,
                    BooleanOperationsType.Intersect);

            if (!EsSolidValido(inter))
            {
                volumen = 0.0;
                return true;
            }

            volumen = inter.Volume;
            return true;
        }
        catch
        {
            volumen = 0.0;
            return false;
        }
    }

    // =============================================================
    // TEST DE CAJAS ENVOLVENTES DE DOS SÓLIDOS
    // =============================================================
    private bool CajasSeSolapan(
        Solid a,
        Solid b,
        double tolerancia)
    {
        XYZ minA, maxA, minB, maxB;

        if (!ObtenerLimitesSolid(a, out minA, out maxA))
            return true;

        if (!ObtenerLimitesSolid(b, out minB, out maxB))
            return true;

        return
            maxA.X >= minB.X - tolerancia &&
            minA.X <= maxB.X + tolerancia &&
            maxA.Y >= minB.Y - tolerancia &&
            minA.Y <= maxB.Y + tolerancia &&
            maxA.Z >= minB.Z - tolerancia &&
            minA.Z <= maxB.Z + tolerancia;
    }

    private bool ObtenerLimitesSolid(
        Solid solid,
        out XYZ min,
        out XYZ max)
    {
        min = null;
        max = null;

        if (!EsSolidValido(solid))
            return false;

        double minX = double.MaxValue;
        double minY = double.MaxValue;
        double minZ = double.MaxValue;
        double maxX = double.MinValue;
        double maxY = double.MinValue;
        double maxZ = double.MinValue;

        bool encontro = false;

        foreach (Edge edge in solid.Edges)
        {
            IList<XYZ> pts = null;

            try
            {
                pts = edge.Tessellate();
            }
            catch
            {
                continue;
            }

            if (pts == null)
                continue;

            foreach (XYZ p in pts)
            {
                if (p == null)
                    continue;

                encontro = true;

                if (p.X < minX) minX = p.X;
                if (p.Y < minY) minY = p.Y;
                if (p.Z < minZ) minZ = p.Z;

                if (p.X > maxX) maxX = p.X;
                if (p.Y > maxY) maxY = p.Y;
                if (p.Z > maxZ) maxZ = p.Z;
            }
        }

        if (!encontro)
            return false;

        min = new XYZ(minX, minY, minZ);
        max = new XYZ(maxX, maxY, maxZ);

        return true;
    }

    // =============================================================
    // DESCUENTOS GENERALES
    // =============================================================
    private List<Solid> AplicarDescuentos(
        List<Solid> piezasIniciales,
        List<MYG_RELL_SeleccionarHandler.SeleccionItem> elementosDescontar,
        MYG_RELL_SeleccionarHandler.SeleccionItem bottomLimite,
        MYG_RELL_SeleccionarHandler.SeleccionItem topLimite)
    {
        List<Solid> piezas =
            piezasIniciales
            .Where(s => EsSolidValido(s))
            .ToList();

        if (piezas.Count == 0)
            return piezas;

        foreach (var e in elementosDescontar)
        {
            if (e == null || e.Elemento == null)
                continue;

            // No descontar los dos elementos que generan los límites.
            // Sus caras ya son exactamente el BOTTOM/TOP del relleno.
            if (EsMismoElemento(e, bottomLimite) ||
                EsMismoElemento(e, topLimite))
                continue;

            List<Solid> solidsDescuento =
                ObtenerSolids(
                    e.Elemento,
                    e.Transformacion ?? Transform.Identity);

            if (solidsDescuento.Count == 0)
                continue;

            foreach (Solid sDescuento in solidsDescuento)
            {
                if (!EsSolidValido(sDescuento))
                    continue;

                for (int i = 0; i < piezas.Count; i++)
                {
                    Solid actual = piezas[i];

                    if (!EsSolidValido(actual))
                        continue;

                    try
                    {
                        Solid diferencia =
                            BooleanOperationsUtils.ExecuteBooleanOperation(
                                actual,
                                sDescuento,
                                BooleanOperationsType.Difference);

                        if (EsSolidValido(diferencia))
                            piezas[i] = diferencia;
                        else
                            piezas[i] = null;
                    }
                    catch
                    {
                        // Si el booleano falla, conservar la pieza actual.
                    }
                }

                piezas =
                    piezas
                    .Where(s => EsSolidValido(s))
                    .ToList();

                if (piezas.Count == 0)
                    return piezas;
            }
        }

        return piezas;
    }

    private bool EsMismoElemento(
        MYG_RELL_SeleccionarHandler.SeleccionItem a,
        MYG_RELL_SeleccionarHandler.SeleccionItem b)
    {
        if (a == null || b == null)
            return false;

        if (a.Elemento == null || b.Elemento == null)
            return false;

        if (a.Elemento.Id.Value != b.Elemento.Id.Value)
            return false;

        if (!MismoDocumento(a.Documento, b.Documento))
            return false;

        // Si ambos son de vínculo, también debe ser la misma instancia.
        if (a.Vinculo != null || b.Vinculo != null)
        {
            if (a.Vinculo == null || b.Vinculo == null)
                return false;

            return a.Vinculo.Id.Value == b.Vinculo.Id.Value;
        }

        return true;
    }

    private bool MismoDocumento(Document a, Document b)
    {
        if (a == null || b == null)
            return false;

        if (object.ReferenceEquals(a, b))
            return true;

        try
        {
            if (!string.IsNullOrWhiteSpace(a.PathName) &&
                !string.IsNullOrWhiteSpace(b.PathName))
            {
                return string.Equals(
                    a.PathName,
                    b.PathName,
                    StringComparison.OrdinalIgnoreCase);
            }
        }
        catch
        {
        }

        return string.Equals(
            a.Title ?? "",
            b.Title ?? "",
            StringComparison.OrdinalIgnoreCase);
    }

    // =============================================================
    // FILTROS
    // =============================================================
    private void CrearFiltros(Document doc, View view)
    {
        if (doc == null || view == null)
            return;

        List<ElementId> categorias = new List<ElementId>()
        {
            new ElementId(BuiltInCategory.OST_Mass)
        };

        CrearFiltro(
            doc,
            view,
            "MYG_Excavación",
            categorias,
            "MYG_EXCAVACION");

        CrearFiltro(
            doc,
            view,
            "MYG_Relleno",
            categorias,
            "MYG_RELLENO");
    }

    private void CrearFiltro(
        Document doc,
        View view,
        string nombreFiltro,
        List<ElementId> categorias,
        string valorEmpieza)
    {
        ElementId paramId =
            new ElementId(BuiltInParameter.SYMBOL_NAME_PARAM);

        FilterRule regla =
            ParameterFilterRuleFactory.CreateBeginsWithRule(
                paramId,
                valorEmpieza);

        ElementParameterFilter filtroRegla =
            new ElementParameterFilter(regla);

        ParameterFilterElement filtroExistente =
            new FilteredElementCollector(doc)
            .OfClass(typeof(ParameterFilterElement))
            .Cast<ParameterFilterElement>()
            .FirstOrDefault(f => f.Name == nombreFiltro);

        ParameterFilterElement filtro;

        if (filtroExistente != null)
        {
            filtro = filtroExistente;

            // Asegura que un filtro ya existente también quede actualizado.
            try
            {
                filtro.SetElementFilter(filtroRegla);
            }
            catch
            {
            }
        }
        else
        {
            filtro =
                ParameterFilterElement.Create(
                    doc,
                    nombreFiltro,
                    categorias);

            filtro.SetElementFilter(filtroRegla);
        }

        if (!view.GetFilters().Contains(filtro.Id))
        {
            view.AddFilter(filtro.Id);
            view.SetFilterVisibility(filtro.Id, true);
        }

        // Override sólo para MYG_Relleno.
        if (nombreFiltro == "MYG_Relleno")
        {
            OverrideGraphicSettings ogs =
                new OverrideGraphicSettings();

            FillPatternElement solidFill =
                new FilteredElementCollector(doc)
                .OfClass(typeof(FillPatternElement))
                .Cast<FillPatternElement>()
                .FirstOrDefault(
                    fp => fp.GetFillPattern().IsSolidFill);

            if (solidFill != null)
            {
                Color color = new Color(128, 128, 0);

                ogs.SetCutForegroundPatternId(solidFill.Id);
                ogs.SetCutForegroundPatternColor(color);

                ogs.SetCutBackgroundPatternId(solidFill.Id);
                ogs.SetCutBackgroundPatternColor(color);

                ogs.SetSurfaceForegroundPatternId(solidFill.Id);
                ogs.SetSurfaceForegroundPatternColor(color);

                ogs.SetSurfaceBackgroundPatternId(solidFill.Id);
                ogs.SetSurfaceBackgroundPatternColor(color);

                view.SetFilterOverrides(filtro.Id, ogs);
            }
        }
    }

    // =============================================================
    // CREAR FAMILIA DE MASA A PARTIR DE UNA O VARIAS PIEZAS
    // =============================================================
    private FamilyInstance CrearFamiliaVoid(
        Document doc,
        IList<Solid> solids)
    {
        if (doc == null || solids == null)
            return null;

        List<Solid> validos =
            solids
            .Where(s => EsSolidValido(s))
            .ToList();

        if (validos.Count == 0)
            return null;

        Application app = doc.Application;

        string plantilla =
            @"C:\ProgramData\Autodesk\RVT 2027\Family Templates\English\Conceptual Mass\Metric Mass.rft";

        if (!File.Exists(plantilla))
        {
            TaskDialog.Show(
                "MYG_RELL",
                "No se encontró la plantilla:\n\n" +
                plantilla);

            return null;
        }

        XYZ centro = CalcularCentroPonderado(validos);

        Transform traslacion =
            Transform.CreateTranslation(
                new XYZ(
                    -centro.X,
                    -centro.Y,
                    -centro.Z));

        List<Solid> solidsLocales =
            new List<Solid>();

        foreach (Solid solid in validos)
        {
            try
            {
                Solid local =
                    SolidUtils.CreateTransformed(
                        solid,
                        traslacion);

                if (EsSolidValido(local))
                    solidsLocales.Add(local);
            }
            catch
            {
            }
        }

        if (solidsLocales.Count == 0)
            return null;

        Document famDoc = null;
        string ruta = null;

        try
        {
            famDoc = app.NewFamilyDocument(plantilla);

            int formasCreadas = 0;

            using (Transaction tf =
                new Transaction(famDoc, "Crear Sólidos"))
            {
                tf.Start();

                foreach (Solid solidLocal in solidsLocales)
                {
                    try
                    {
                        FreeFormElement.Create(
                            famDoc,
                            solidLocal);

                        formasCreadas++;
                    }
                    catch
                    {
                        // Si una faceta puntual falla,
                        // intentar crear las demás.
                    }
                }

                if (formasCreadas == 0)
                {
                    tf.RollBack();
                    famDoc.Close(false);
                    famDoc = null;
                    return null;
                }

                tf.Commit();
            }

            ruta = Path.Combine(
                Path.GetTempPath(),
                "MYG_RELLENO_" +
                Guid.NewGuid().ToString("N") +
                ".rfa");

            famDoc.SaveAs(ruta);
            famDoc.Close(false);
            famDoc = null;

            Family fam;

            if (!doc.LoadFamily(ruta, out fam) || fam == null)
                return null;

            ElementId symbolId =
                fam.GetFamilySymbolIds().FirstOrDefault();

            if (symbolId == null ||
                symbolId == ElementId.InvalidElementId)
                return null;

            FamilySymbol symbol =
                doc.GetElement(symbolId) as FamilySymbol;

            if (symbol == null)
                return null;

            if (!symbol.IsActive)
            {
                symbol.Activate();
                doc.Regenerate();
            }

            return doc.Create.NewFamilyInstance(
                centro,
                symbol,
                StructuralType.NonStructural);
        }
        catch
        {
            if (famDoc != null)
            {
                try
                {
                    famDoc.Close(false);
                }
                catch
                {
                }
            }

            return null;
        }
        finally
        {
            if (!string.IsNullOrWhiteSpace(ruta))
            {
                try
                {
                    if (File.Exists(ruta))
                        File.Delete(ruta);
                }
                catch
                {
                }
            }
        }
    }

    private XYZ CalcularCentroPonderado(
        IList<Solid> solids)
    {
        double sx = 0.0;
        double sy = 0.0;
        double sz = 0.0;
        double total = 0.0;

        foreach (Solid solid in solids)
        {
            if (!EsSolidValido(solid))
                continue;

            try
            {
                XYZ c = solid.ComputeCentroid();
                double v = solid.Volume;

                sx += c.X * v;
                sy += c.Y * v;
                sz += c.Z * v;
                total += v;
            }
            catch
            {
            }
        }

        if (total <= TOL_VOLUME)
            return XYZ.Zero;

        return new XYZ(
            sx / total,
            sy / total,
            sz / total);
    }

    // =============================================================
    // MASAS MYG_RELLENO YA EXISTENTES
    //
    // V3: se recolectan PRIMERO por categoría OST_Mass.
    // En la captura del usuario la instancia aparece como categoría "Masa",
    // por lo que este método evita depender de OfClass(FamilyInstance), que
    // puede dejar fuera ciertos casos de familias de masa según la geometría.
    // Luego se aplica la identificación MYG_RELLENO por familia/tipo/comentario.
    // =============================================================
    private List<MYG_RELL_SeleccionarHandler.SeleccionItem>
        ObtenerMasasRellenoExistentes(
            Document doc,
            bool incluirVinculos)
    {
        var resultado =
            new List<MYG_RELL_SeleccionarHandler.SeleccionItem>();

        if (doc == null)
            return resultado;

        // ---------------------------------------------------------
        // HOST: categoría Masa.
        // ---------------------------------------------------------
        var hostMasses =
            new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_Mass)
            .WhereElementIsNotElementType()
            .ToElements()
            .Where(e => EsMasaRellenoMYG(e))
            .ToList();

        foreach (Element e in hostMasses)
        {
            resultado.Add(
                new MYG_RELL_SeleccionarHandler.SeleccionItem()
                {
                    Elemento = e,
                    Documento = doc,
                    Transformacion = Transform.Identity,
                    Vinculo = null
                });
        }

        // ---------------------------------------------------------
        // FALLBACK HOST:
        // por si alguna versión anterior quedó en otra categoría pero
        // conserva MYG_RELLENO en familia/tipo/comentario.
        // ---------------------------------------------------------
        var fallbackHost =
            new FilteredElementCollector(doc)
            .WhereElementIsNotElementType()
            .OfClass(typeof(FamilyInstance))
            .ToElements()
            .Where(e => EsMasaRellenoMYG(e))
            .ToList();

        foreach (Element e in fallbackHost)
        {
            bool existe = resultado.Any(x =>
                x != null &&
                x.Elemento != null &&
                x.Elemento.Id.Value == e.Id.Value &&
                MismoDocumento(x.Documento, doc));

            if (!existe)
            {
                resultado.Add(
                    new MYG_RELL_SeleccionarHandler.SeleccionItem()
                    {
                        Elemento = e,
                        Documento = doc,
                        Transformacion = Transform.Identity,
                        Vinculo = null
                    });
            }
        }

        if (!incluirVinculos)
            return resultado;

        // ---------------------------------------------------------
        // VÍNCULOS RVT.
        // ---------------------------------------------------------
        var links =
            new FilteredElementCollector(doc)
            .OfClass(typeof(RevitLinkInstance))
            .Cast<RevitLinkInstance>()
            .ToList();

        foreach (RevitLinkInstance link in links)
        {
            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                continue;

            Transform tr = link.GetTotalTransform();

            var linkedMasses =
                new FilteredElementCollector(linkDoc)
                .OfCategory(BuiltInCategory.OST_Mass)
                .WhereElementIsNotElementType()
                .ToElements()
                .Where(e => EsMasaRellenoMYG(e))
                .ToList();

            foreach (Element e in linkedMasses)
            {
                resultado.Add(
                    new MYG_RELL_SeleccionarHandler.SeleccionItem()
                    {
                        Elemento = e,
                        Documento = linkDoc,
                        Transformacion = tr,
                        Vinculo = link
                    });
            }

            var fallbackLink =
                new FilteredElementCollector(linkDoc)
                .WhereElementIsNotElementType()
                .OfClass(typeof(FamilyInstance))
                .ToElements()
                .Where(e => EsMasaRellenoMYG(e))
                .ToList();

            foreach (Element e in fallbackLink)
            {
                bool existe = resultado.Any(x =>
                    x != null &&
                    x.Elemento != null &&
                    x.Elemento.Id.Value == e.Id.Value &&
                    x.Vinculo != null &&
                    x.Vinculo.Id.Value == link.Id.Value &&
                    MismoDocumento(x.Documento, linkDoc));

                if (!existe)
                {
                    resultado.Add(
                        new MYG_RELL_SeleccionarHandler.SeleccionItem()
                        {
                            Elemento = e,
                            Documento = linkDoc,
                            Transformacion = tr,
                            Vinculo = link
                        });
                }
            }
        }

        return resultado;
    }

    // =============================================================
    // ELEMENTOS NORMALES A DESCONTAR
    // =============================================================
    private List<MYG_RELL_SeleccionarHandler.SeleccionItem>
        ObtenerElementosDescontar(
            Document doc,
            bool incluirVinculos)
    {
        var resultado =
            new List<MYG_RELL_SeleccionarHandler.SeleccionItem>();

        // HOST
        var hostElements =
            new FilteredElementCollector(doc)
            .WhereElementIsNotElementType()
            .Where(EsCategoriaDescuento)
            .ToList();

        foreach (Element elem in hostElements)
        {
            resultado.Add(
                new MYG_RELL_SeleccionarHandler.SeleccionItem()
                {
                    Elemento = elem,
                    Documento = doc,
                    Transformacion = Transform.Identity,
                    Vinculo = null
                });
        }

        if (!incluirVinculos)
            return resultado;

        // VÍNCULOS
        var links =
            new FilteredElementCollector(doc)
            .OfClass(typeof(RevitLinkInstance))
            .Cast<RevitLinkInstance>()
            .ToList();

        foreach (RevitLinkInstance link in links)
        {
            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                continue;

            Transform tr = link.GetTotalTransform();

            var linkedElements =
                new FilteredElementCollector(linkDoc)
                .WhereElementIsNotElementType()
                .Where(EsCategoriaDescuento)
                .ToList();

            foreach (Element elem in linkedElements)
            {
                resultado.Add(
                    new MYG_RELL_SeleccionarHandler.SeleccionItem()
                    {
                        Elemento = elem,
                        Documento = linkDoc,
                        Transformacion = tr,
                        Vinculo = link
                    });
            }
        }

        return resultado;
    }

    private bool EsCategoriaDescuento(Element e)
    {
        if (e == null || e.Category == null)
            return false;

        // Cualquier relleno MYG se maneja EXCLUSIVAMENTE en el paso
        // prioritario, incluso si una versión antigua de la familia tuviera
        // una categoría distinta de OST_Mass.
        if (EsMasaRellenoMYG(e))
            return false;

        long id = e.Category.Id.Value;

        // No descontar otras masas ajenas al add-in.
        if (id == (long)BuiltInCategory.OST_Mass)
            return false;

        return
            id == (long)BuiltInCategory.OST_StructuralColumns ||
            id == (long)BuiltInCategory.OST_Columns ||
            id == (long)BuiltInCategory.OST_StructuralFraming ||
            id == (long)BuiltInCategory.OST_Floors ||
            id == (long)BuiltInCategory.OST_StructuralFoundation ||
            id == (long)BuiltInCategory.OST_Walls ||
            id == (long)BuiltInCategory.OST_EdgeSlab ||
            id == (long)BuiltInCategory.OST_GenericModel;
    }

    // =============================================================
    // MARCAR MASA NUEVA
    // =============================================================
    private void MarcarComoRellenoMYG(FamilyInstance fi)
    {
        if (fi == null)
            return;

        try
        {
            Parameter pComentarios =
                fi.get_Parameter(
                    BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

            if (pComentarios != null && !pComentarios.IsReadOnly)
                pComentarios.Set("MYG_RELLENO");
        }
        catch
        {
        }
    }

    // =============================================================
    // DETECTAR ÚNICAMENTE MASAS MYG_RELLENO
    // =============================================================
    private bool EsMasaRellenoMYG(Element e)
    {
        if (e == null)
            return false;

        FamilyInstance fi = e as FamilyInstance;

        if (fi == null)
            return false;

        // 0. MARCA EXPLÍCITA EN COMENTARIOS (versiones nuevas).
        try
        {
            Parameter pComentarios =
                fi.get_Parameter(
                    BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

            if (pComentarios != null)
            {
                string comentario = pComentarios.AsString();

                if (!string.IsNullOrWhiteSpace(comentario) &&
                    comentario.IndexOf(
                        "MYG_RELLENO",
                        StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }
        }
        catch
        {
        }

        // 1. Nombre de familia.
        try
        {
            if (fi.Symbol != null &&
                fi.Symbol.Family != null)
            {
                string familyName =
                    fi.Symbol.Family.Name;

                if (!string.IsNullOrWhiteSpace(familyName) &&
                    familyName.StartsWith(
                        "MYG_RELLENO",
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
        }
        catch
        {
        }

        // 2. Nombre del tipo.
        try
        {
            if (fi.Symbol != null)
            {
                string symbolName = fi.Symbol.Name;

                if (!string.IsNullOrWhiteSpace(symbolName) &&
                    symbolName.StartsWith(
                        "MYG_RELLENO",
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
        }
        catch
        {
        }

        // 3. SYMBOL_NAME_PARAM como respaldo.
        try
        {
            if (fi.Symbol != null)
            {
                Parameter pNombre =
                    fi.Symbol.get_Parameter(
                        BuiltInParameter.SYMBOL_NAME_PARAM);

                if (pNombre != null)
                {
                    string nombre = pNombre.AsString();

                    if (!string.IsNullOrWhiteSpace(nombre) &&
                        nombre.StartsWith(
                            "MYG_RELLENO",
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
        }
        catch
        {
        }

        return false;
    }

    // =============================================================
    // OBTENER TODOS LOS SÓLIDOS DEL ELEMENTO
    //
    // A diferencia del código anterior, NO devuelve únicamente
    // el primer Solid. Esto es importante en familias, elementos
    // facetados y geometrías mixtas.
    // =============================================================
    private List<Solid> ObtenerSolids(
        Element elem,
        Transform transformacion)
    {
        List<Solid> resultado = new List<Solid>();

        if (elem == null)
            return resultado;

        Options opt = new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            return resultado;
        }

        if (geo == null)
            return resultado;

        BuscarSolidsRecursivo(
            geo,
            resultado);

        if (resultado.Count == 0)
            return resultado;

        if (transformacion == null ||
            transformacion.IsIdentity)
        {
            return resultado
                .Where(s => EsSolidValido(s))
                .ToList();
        }

        List<Solid> transformados =
            new List<Solid>();

        foreach (Solid solid in resultado)
        {
            try
            {
                Solid st =
                    SolidUtils.CreateTransformed(
                        solid,
                        transformacion);

                if (EsSolidValido(st))
                    transformados.Add(st);
            }
            catch
            {
            }
        }

        return transformados;
    }

    private void BuscarSolidsRecursivo(
        GeometryElement geo,
        List<Solid> resultado)
    {
        if (geo == null || resultado == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            Solid s = obj as Solid;

            if (EsSolidValido(s))
            {
                resultado.Add(s);
                continue;
            }

            GeometryInstance gi =
                obj as GeometryInstance;

            if (gi != null)
            {
                try
                {
                    GeometryElement instGeo =
                        gi.GetInstanceGeometry();

                    BuscarSolidsRecursivo(
                        instGeo,
                        resultado);
                }
                catch
                {
                }
            }
        }
    }

    private bool EsSolidValido(Solid solid)
    {
        if (solid == null)
            return false;

        try
        {
            return
                solid.Faces != null &&
                solid.Faces.Size > 0 &&
                solid.Edges != null &&
                solid.Edges.Size > 0 &&
                solid.Volume > TOL_VOLUME;
        }
        catch
        {
            return false;
        }
    }
}
