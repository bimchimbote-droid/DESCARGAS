﻿// =====================================
// HANDLERS - ACERO LONGITUDINAL EN VIGAS
// DETECTA LUZ LIBRE ENTRE CARAS DE COLUMNAS
// SELECCIÓN + EJECUCIÓN COMPLETA
// MODIFICADO: CREA ACERO CENTRAL SI EL CHECK ESTÁ ACTIVADO
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;


// =====================================
// HANDLER - EJECUTAR ACERO LONGITUDINAL
// =====================================
// V10.4: referencia de guía + plano 3D completo de la cara
public class EjecutarAceroLongitudinalVigasHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public AceroLongitudinalVigasForm Form;
    public SeleccionarVigasAceroLongitudinalHandler SeleccionHandler;

    private const double Tol = 1e-6;
    private string ultimoErrorCurvaMYG = string.Empty;

    // Acumula los errores reales de la rama curva. Una tentativa posterior no
    // debe borrar el diagnóstico de una barra o un anfitrión que ya falló.
    private readonly List<string> erroresCurvaAcumuladosMYG =
        new List<string>();

    // =========================================================
    // V11.12 - DIAGNÓSTICO DE FALLAS EN LONGITUDINALES RECTOS
    // =========================================================
    // Se guarda únicamente el último error de las tentativas internas.
    // Ese error solo se publica si el GRUPO completo termina fallando,
    // evitando mostrar falsos positivos cuando una normal/host falla pero
    // una tentativa posterior sí consigue crear el set.
    private string ultimoErrorLongitudinalMYG = string.Empty;

    private readonly List<string> erroresLongitudinalAcumuladosMYG =
        new List<string>();

    private int secuenciaErrorLongitudinalMYG = 0;

    // Separación libre cara a cara entre capas longitudinales.
    // Se lee una sola vez por ejecución y se aplica a capas superiores e inferiores.
    private double separacionLibreCapasActualMYG =
        UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Inches);

    private sealed class PlanoCaraPrincipal3DMYG
    {
        public XYZ Origen;
        public XYZ NormalExterior;
        public double XMin;
        public double XMax;
        public double YMin;
        public double YMax;
        public double ZPromedio;
    }

    private class DatosViga
    {
        public Element Elemento;

        public XYZ P0;
        public XYZ P1;

        public XYZ XAxis;
        public XYZ YAxis;
        public XYZ ZAxis;

        public double Longitud;

        public double SolidoMin;
        public double SolidoMax;

        public double YMin;
        public double YMax;

        public double ZMin;
        public double ZMax;

        // PERFIL LIMPIO DE SECCIÓN VARIABLE POR TRAMO.
        // Se usan solo las caras de inicio y fin del sólido.
        public bool TienePerfilSeccionVariable;
        public double ZSuperiorInicio;
        public double ZSuperiorFin;
        public double ZInferiorInicio;
        public double ZInferiorFin;

        // NUEVO V7:
        // Perfil real por caras obtenido del sólido.
        // Cada segmento representa una línea de cara superior/inferior en el plano local X-Z de la viga.
        // El acero se genera como líneas paralelas a estos segmentos y los quiebres se calculan
        // por intersección de esas líneas proyectadas, no por el punto donde empieza el tramo.
        public List<SegmentoPerfilCara> PerfilSuperiorDetallado;
        public List<SegmentoPerfilCara> PerfilInferiorDetallado;

        public double Ancho;
        public double Alto;

        // Puntos reales del sólido para reconstruir la sección transversal Y-Z.
        public List<XYZ> PuntosSolidoGlobal;

        // Sólidos reales de la propia viga. Se usan únicamente para comprobar
        // que el paquete longitudinal permanezca dentro del concreto.
        public List<Solid> SolidosGlobales;

        // Planos reales de las caras principales. A diferencia del perfil X-Z,
        // conservan también la componente transversal Y de la inclinación.
        public List<PlanoCaraPrincipal3DMYG> PlanosSuperiores3D;
        public List<PlanoCaraPrincipal3DMYG> PlanosInferiores3D;
    }

    private class IntervaloColumnaSerie
    {
        public double Min;
        public double Max;

        public double Center
        {
            get { return (Min + Max) / 2.0; }
        }

        public double Width
        {
            get { return Max - Min; }
        }

        public IntervaloColumnaSerie(double min, double max)
        {
            Min = min;
            Max = max;
        }
    }

    private class DatosSerieVigas
    {
        public Element Host;

        public XYZ PInicio;
        public XYZ PFin;

        public XYZ XAxis;
        public XYZ YAxis;
        public XYZ ZAxis;

        public double LongitudTotal;
        public double Ancho;
        public double Alto;
        public double CentroY;
        public double CentroZ;

        public double SolidoMinGlobal;
        public double SolidoMaxGlobal;
        public double LuzLibreInicioGlobal;
        public double LuzLibreFinGlobal;

        // NUEVO: geometría real por tramo de viga/armazón.
        // Esto solo se usa para proyectar el recorrido del acero en vigas con quiebres,
        // sin tocar la lógica original de empalmes, longitud de barra, desarrollo ni ganchos.
        public XYZ OrigenGlobal;
        public List<DatosViga> Vigas;

        // NUEVO: recorrido real acumulado por tramo.
        // XInicioSerie/XFinSerie ya no dependen solo de la proyección horizontal,
        // sino de la longitud real de cada tramo de viga.
        public List<TramoRecorridoSerie> TramosRecorrido;

        // Columnas/apoyos detectados en la serie.
        // Se usa para calcular automáticamente la longitud de desarrollo:
        // ancho del apoyo - recubrimiento.
        public List<IntervaloColumnaSerie> Columnas;

        // Intervalo útil común de todo el paquete de acero.
        // Se mide sobre el recorrido acumulado de la serie.
        public double InicioUtilArmaduraSerie;
        public double FinUtilArmaduraSerie;
    }

    private class TramoRecorridoSerie
    {
        public DatosViga Viga;

        public double XInicioSerie;
        public double XFinSerie;

        public double EstacionInicioViga;
        public double EstacionFinViga;

        public XYZ Direccion;

        public double Longitud
        {
            get { return Math.Abs(XFinSerie - XInicioSerie); }
        }

        public TramoRecorridoSerie(
            DatosViga viga,
            double xInicioSerie,
            double xFinSerie,
            double estacionInicioViga,
            double estacionFinViga)
        {
            Viga = viga;
            XInicioSerie = xInicioSerie;
            XFinSerie = xFinSerie;
            EstacionInicioViga = estacionInicioViga;
            EstacionFinViga = estacionFinViga;

            if (viga != null && viga.XAxis != null && viga.XAxis.GetLength() > Tol)
            {
                double sentido = estacionFinViga >= estacionInicioViga ? 1.0 : -1.0;
                Direccion = viga.XAxis.Normalize().Multiply(sentido);
            }
            else
            {
                Direccion = XYZ.BasisX;
            }
        }
    }

    private class SegmentoAceroLongitudinal
    {
        public double XInicio;
        public double XFin;
        public bool EsPrimero;
        public bool EsUltimo;
        public bool TieneEmpalmeInicio;
        public bool TieneEmpalmeFin;

        // Campo conservado únicamente por compatibilidad con versiones
        // anteriores. Desde V11.8 SIEMPRE permanece en false:
        // un empalme nunca se degrada a una pieza colineal.
        public bool EmpalmeInicioColinealSeguro;

        public SegmentoAceroLongitudinal(double xInicio, double xFin)
        {
            XInicio = xInicio;
            XFin = xFin;
            EsPrimero = false;
            EsUltimo = false;
            TieneEmpalmeInicio = false;
            TieneEmpalmeFin = false;
            EmpalmeInicioColinealSeguro = false;
        }
    }

    private class ConfiguracionCapaLongitudinal
    {
        public int NumeroCapa;
        public RebarBarType TipoBarra;
        public int Cantidad;
        public double Diametro;
        public double OffsetCentroDesdeCara;
        public bool Superior;
        public string TipoElementoTexto;
    }


    // =========================================================
    // DATOS ESPECÍFICOS PARA VIGAS CURVAS
    // =========================================================
    // La lógica recta original se conserva sin cambios. Esta clase solo se usa
    // cuando la LocationCurve de la viga es un Arc plano y horizontal.
    private class DatosVigaCurvaLongitudinalMYG
    {
        public Element Host;
        public Arc Eje;
        public double Longitud;

        public XYZ PuntoMedio;
        public XYZ TangenteMedio;
        public XYZ EjeYMedio;
        public XYZ EjeZ;

        public double YMin;
        public double YMax;
        public double ZMin;
        public double ZMax;

        public List<XYZ> PuntosGeometria;
        public List<IntervaloColumnaSerie> Apoyos;
    }


    // =========================================================
    // SERIE CONTINUA DE VIGAS CURVAS / MIXTAS
    // =========================================================
    // Cada tramo conserva su propio anfitrión, su LocationCurve y su sección.
    // Las piezas comerciales se calculan sobre una ruta global que incluye los
    // vacíos; la geometría se materializa mediante Rebar independientes por host.
    private class TramoSerieCurvaLongitudinalMYG
    {
        public Element Host;
        public Curve Eje;
        public double Longitud;
        public double InicioSerie;
        public double FinSerie;

        public XYZ PuntoMedio;
        public XYZ TangenteMedio;
        public XYZ EjeYMedio;
        public XYZ EjeZ;

        public double YMin;
        public double YMax;
        public double ZMin;
        public double ZMax;

        public List<XYZ> PuntosGeometria;

        // Sólidos reales del anfitrión. Se usan para recalcular el ancho y el
        // peralte en cada estación de una viga curva, evitando reutilizar la
        // sección transversal obtenida únicamente en el punto medio.
        public List<Solid> SolidosGlobales;

        // Distancia real desde el extremo del tramo anterior hasta el inicio de
        // este tramo. Forma parte de la longitud comercial, aunque no exista
        // concreto entre ambas vigas.
        public double HuecoAntes;

        // Mantiene la correspondencia física de las barras entre tramos.
        // Cuando es true, el índice lógico 0 se materializa en el extremo
        // lateral opuesto de la sección local. Esto evita que las barras se
        // crucen cuando el eje Y local cambia de sentido entre dos vigas.
        public bool InvertirOrdenLateral;
    }

    private class DatosSerieCurvaLongitudinalMYG
    {
        public Element HostPrincipal;
        public List<TramoSerieCurvaLongitudinalMYG> Tramos;
        public double LongitudTotal;
        public XYZ EjeZ;

        // Campos conservados por compatibilidad con versiones anteriores.
        // La versión actual NO reconstruye un arco maestro: crea un offset por
        // cada tramo y une los bocetos consecutivos mediante líneas rectas.
        public bool UsaArcoMaestro;
        public Arc ArcoMaestro;
    }

    private class ResultadoTramoBarraCurvaMYG
    {
        public TramoSerieCurvaLongitudinalMYG Tramo;
        public bool RequeridoPorSegmento;
        public bool Creado;
        public double GlobalInicio;
        public double GlobalFin;
        public Curve CurvaCompletaTeorica;
        public Curve SubCurvaTeorica;
        public List<Curve> CurvasDentroDelHost;
        public List<Curve> CurvasConRebar;

        public ResultadoTramoBarraCurvaMYG()
        {
            GlobalInicio = 0.0;
            GlobalFin = 0.0;
            CurvasDentroDelHost = new List<Curve>();
            CurvasConRebar = new List<Curve>();
        }

        public Curve PrimeraCurvaCreada
        {
            get
            {
                return CurvasConRebar != null && CurvasConRebar.Count > 0
                    ? CurvasConRebar[0]
                    : null;
            }
        }

        public Curve UltimaCurvaCreada
        {
            get
            {
                return CurvasConRebar != null && CurvasConRebar.Count > 0
                    ? CurvasConRebar[CurvasConRebar.Count - 1]
                    : null;
            }
        }
    }


    private class ResultadoPiezaBarraCurvaMYG
    {
        public SegmentoAceroLongitudinal Segmento;
        public int IndicePieza;
        public int Creadas;
        public List<ResultadoTramoBarraCurvaMYG> ResultadosTramo;

        public ResultadoPiezaBarraCurvaMYG()
        {
            ResultadosTramo = new List<ResultadoTramoBarraCurvaMYG>();
        }
    }


    // Ajuste geométrico tolerante de un círculo maestro. No exige que los
    // centros/radios nativos de todos los tramos coincidan exactamente.
    private class AjusteCirculoMaestroLongitudinalMYG
    {
        public XYZ Centro;
        public double Radio;
        public XYZ Normal;
        public double ErrorRadialMaximo;
        public double VariacionZ;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
            return;

        Document doc = uidoc.Document;

        if (Form == null)
            return;

        if (SeleccionHandler == null)
            return;

        if (SeleccionHandler.VigasSeleccionadas == null ||
            SeleccionHandler.VigasSeleccionadas.Count == 0)
        {
            TaskDialog.Show("MYG", "Primero debe seleccionar una o más vigas o armazones estructurales.");
            return;
        }

        // Cada ejecución comienza con un diagnóstico limpio.
        ultimoErrorLongitudinalMYG = string.Empty;
        erroresLongitudinalAcumuladosMYG.Clear();
        secuenciaErrorLongitudinalMYG = 0;

        AceroVigaDisenoSeccion disenoManualSeccion =
            AceroVigaDisenoSeccionCompartido.ObtenerCopia();
        bool usarDisenoManualSeccion =
            disenoManualSeccion != null &&
            disenoManualSeccion.TieneLongitudinales;

        RebarBarType tipoSuperior = Form.TipoSuperiorSeleccionado;
        RebarBarType tipoInferior = Form.TipoInferiorSeleccionado;

        bool crearAceroCentral = Form.AceroCentral;
        RebarBarType tipoCentral = Form.TipoCentralSeleccionado;

        int cantidadSuperior = 1;
        int cantidadInferior = 1;
        int capasSuperiores = 1;
        int capasInferiores = 1;

        separacionLibreCapasActualMYG =
            UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Inches);

        if (usarDisenoManualSeccion)
        {
            // En modo editor 2D la sección es la fuente de verdad. Cada punto
            // longitudinal conserva su propio RebarBarType, por lo que los combos,
            // cantidades y capas automáticas de la ventana dejan de bloquear la
            // ejecución. Solo se conserva un tipo de respaldo para diseños antiguos
            // que se hubieran guardado sin tipo individual.
            RebarBarType tipoRespaldoManual =
                disenoManualSeccion.Longitudinales
                    .Where(x => x != null && x.TipoBarra != null)
                    .Select(x => x.TipoBarra)
                    .FirstOrDefault();

            tipoSuperior = tipoSuperior ?? tipoRespaldoManual;
            tipoInferior = tipoInferior ?? tipoRespaldoManual;
            tipoCentral = tipoCentral ?? tipoRespaldoManual;

            if (tipoRespaldoManual == null &&
                (tipoSuperior == null || tipoInferior == null))
            {
                TaskDialog.Show(
                    "MYG",
                    "El diseño manual contiene barras longitudinales sin un tipo de barra válido.\n\n" +
                    "Abra EDITAR ACERO EN SECCIÓN y asigne un diámetro a cada barra.");
                return;
            }

            // Las posiciones y cantidades provienen del editor. Estos valores solo
            // quedan inicializados para mantener compatibles las firmas históricas.
            cantidadSuperior = 1;
            cantidadInferior = 1;
            capasSuperiores = 1;
            capasInferiores = 1;
            crearAceroCentral = false;
        }
        else
        {
            if (tipoSuperior == null)
            {
                TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra superior.");
                return;
            }

            if (tipoInferior == null)
            {
                TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra inferior.");
                return;
            }

            if (crearAceroCentral && tipoCentral == null)
            {
                TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra central.");
                return;
            }

            if (!TryLeerEntero(Form.CantidadSuperiorTexto, out cantidadSuperior))
            {
                TaskDialog.Show("MYG", "La cantidad de barras superiores no es válida.");
                return;
            }

            if (!TryLeerEntero(Form.CantidadInferiorTexto, out cantidadInferior))
            {
                TaskDialog.Show("MYG", "La cantidad de barras inferiores no es válida.");
                return;
            }

            if (cantidadSuperior <= 0)
            {
                TaskDialog.Show("MYG", "La cantidad de barras superiores debe ser mayor que cero.");
                return;
            }

            if (cantidadInferior <= 0)
            {
                TaskDialog.Show("MYG", "La cantidad de barras inferiores debe ser mayor que cero.");
                return;
            }

            capasSuperiores = Math.Max(1, Math.Min(4, Form.CapasSuperiores));
            capasInferiores = Math.Max(1, Math.Min(4, Form.CapasInferiores));

            if (capasSuperiores >= 2)
            {
                if (Form.TipoSuperiorCapa2Seleccionado == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra superior de la capa 2.");
                    return;
                }

                int cantidadSuperiorCapa2;
                if (!TryLeerEntero(Form.CantidadSuperiorCapa2Texto, out cantidadSuperiorCapa2) || cantidadSuperiorCapa2 <= 0)
                {
                    TaskDialog.Show("MYG", "La cantidad de barras superiores de la capa 2 no es válida.");
                    return;
                }
            }

            if (capasSuperiores >= 3)
            {
                if (Form.TipoSuperiorCapa3Seleccionado == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra superior de la capa 3.");
                    return;
                }

                int cantidadSuperiorCapa3;
                if (!TryLeerEntero(Form.CantidadSuperiorCapa3Texto, out cantidadSuperiorCapa3) || cantidadSuperiorCapa3 <= 0)
                {
                    TaskDialog.Show("MYG", "La cantidad de barras superiores de la capa 3 no es válida.");
                    return;
                }
            }

            if (capasSuperiores >= 4)
            {
                if (Form.TipoSuperiorCapa4Seleccionado == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra superior de la capa 4.");
                    return;
                }

                int cantidadSuperiorCapa4;
                if (!TryLeerEntero(Form.CantidadSuperiorCapa4Texto, out cantidadSuperiorCapa4) || cantidadSuperiorCapa4 <= 0)
                {
                    TaskDialog.Show("MYG", "La cantidad de barras superiores de la capa 4 no es válida.");
                    return;
                }
            }

            if (capasInferiores >= 2)
            {
                if (Form.TipoInferiorCapa2Seleccionado == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra inferior de la capa 2.");
                    return;
                }

                int cantidadInferiorCapa2;
                if (!TryLeerEntero(Form.CantidadInferiorCapa2Texto, out cantidadInferiorCapa2) || cantidadInferiorCapa2 <= 0)
                {
                    TaskDialog.Show("MYG", "La cantidad de barras inferiores de la capa 2 no es válida.");
                    return;
                }
            }

            if (capasInferiores >= 3)
            {
                if (Form.TipoInferiorCapa3Seleccionado == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra inferior de la capa 3.");
                    return;
                }

                int cantidadInferiorCapa3;
                if (!TryLeerEntero(Form.CantidadInferiorCapa3Texto, out cantidadInferiorCapa3) || cantidadInferiorCapa3 <= 0)
                {
                    TaskDialog.Show("MYG", "La cantidad de barras inferiores de la capa 3 no es válida.");
                    return;
                }
            }

            if (capasInferiores >= 4)
            {
                if (Form.TipoInferiorCapa4Seleccionado == null)
                {
                    TaskDialog.Show("MYG", "Debe seleccionar el tipo de barra inferior de la capa 4.");
                    return;
                }

                int cantidadInferiorCapa4;
                if (!TryLeerEntero(Form.CantidadInferiorCapa4Texto, out cantidadInferiorCapa4) || cantidadInferiorCapa4 <= 0)
                {
                    TaskDialog.Show("MYG", "La cantidad de barras inferiores de la capa 4 no es válida.");
                    return;
                }
            }

            if (capasSuperiores >= 2 || capasInferiores >= 2)
            {
                if (!TryLeerLongitudConUnidadesRevitMYG(
                    doc,
                    Form.SeparacionCapasTexto,
                    out separacionLibreCapasActualMYG) ||
                    separacionLibreCapasActualMYG <= Tol)
                {
                    TaskDialog.Show(
                        "MYG",
                        "La separación entre capas no es válida.\n\n" +
                        "Puede ingresar valores como: 2in, 2\", 5cm, 50mm o 0.05m.");

                    return;
                }

                try
                {
                    Form.EstablecerSeparacionCapasDesdeValorInterno(
                        separacionLibreCapasActualMYG);
                }
                catch
                {
                }
            }
        }

        double recubrimientoCm;

        double recubrimientoManualLongitudinal =
            disenoManualSeccion != null &&
            disenoManualSeccion.RecubrimientoLongitudinalCm > 0.0
                ? disenoManualSeccion.RecubrimientoLongitudinalCm
                : disenoManualSeccion != null
                    ? disenoManualSeccion.RecubrimientoCm
                    : 0.0;

        if (usarDisenoManualSeccion &&
            recubrimientoManualLongitudinal > 0.0)
        {
            // La pestaña Longitudinal conserva su propio recubrimiento.
            recubrimientoCm = recubrimientoManualLongitudinal;
        }
        else if (!TryLeerDouble(Form.RecubrimientoTexto, out recubrimientoCm))
        {
            TaskDialog.Show("MYG", "El recubrimiento ingresado no es válido.");
            return;
        }

        if (recubrimientoCm < 0)
        {
            TaskDialog.Show("MYG", "El recubrimiento no puede ser negativo.");
            return;
        }

        bool ganchoInicio = Form.GanchoInicio;
        bool ganchoFin = Form.GanchoFin;

        bool desarrolloInicioHabilitado = Form.LongitudDesarrolloInicioHabilitada;
        bool desarrolloFinHabilitado = Form.LongitudDesarrolloFinHabilitada;

        double longitudGanchoInicioCm = 0.0;
        double longitudGanchoFinCm = 0.0;

        if (ganchoInicio)
        {
            if (!TryLeerDouble(Form.LongitudGanchoInicioTexto, out longitudGanchoInicioCm))
            {
                TaskDialog.Show("MYG", "La longitud de gancho del extremo inicial no es válida.");
                return;
            }

            if (longitudGanchoInicioCm <= 0)
            {
                TaskDialog.Show("MYG", "La longitud de gancho del extremo inicial debe ser mayor que cero.");
                return;
            }
        }

        if (ganchoFin)
        {
            if (!TryLeerDouble(Form.LongitudGanchoFinTexto, out longitudGanchoFinCm))
            {
                TaskDialog.Show("MYG", "La longitud de gancho del extremo final no es válida.");
                return;
            }

            if (longitudGanchoFinCm <= 0)
            {
                TaskDialog.Show("MYG", "La longitud de gancho del extremo final debe ser mayor que cero.");
                return;
            }
        }

        double longitudDesarrolloInicioCm = 0.0;
        double longitudDesarrolloFinCm = 0.0;

        if (desarrolloInicioHabilitado)
        {
            if (!TryLeerDouble(Form.LongitudDesarrolloInicioTexto, out longitudDesarrolloInicioCm))
            {
                TaskDialog.Show("MYG", "La longitud de desarrollo del extremo inicial no es válida.");
                return;
            }

            if (longitudDesarrolloInicioCm < 0)
            {
                TaskDialog.Show("MYG", "La longitud de desarrollo del extremo inicial no puede ser negativa.");
                return;
            }
        }

        if (desarrolloFinHabilitado)
        {
            if (!TryLeerDouble(Form.LongitudDesarrolloFinTexto, out longitudDesarrolloFinCm))
            {
                TaskDialog.Show("MYG", "La longitud de desarrollo del extremo final no es válida.");
                return;
            }

            if (longitudDesarrolloFinCm < 0)
            {
                TaskDialog.Show("MYG", "La longitud de desarrollo del extremo final no puede ser negativa.");
                return;
            }
        }

        bool crearEmpalmes = Form.CrearEmpalmes;
        bool usarRNE = Form.UsarRNE;

        double longitudEmpalmeSuperiorCm = 0.0;
        double longitudEmpalmeInferiorCm = 0.0;
        double longitudEmpalmeCentralCm = 0.0;
        double longitudBarraM = 0.0;

        if (crearEmpalmes)
        {
            if (usarRNE)
            {
                if (!TryLeerDouble(Form.LongitudEmpalmeSuperiorTexto, out longitudEmpalmeSuperiorCm) ||
                    longitudEmpalmeSuperiorCm <= 0)
                {
                    TaskDialog.Show("MYG", "La longitud de empalme RNE del acero superior no es válida.");
                    return;
                }

                if (!TryLeerDouble(Form.LongitudEmpalmeInferiorTexto, out longitudEmpalmeInferiorCm) ||
                    longitudEmpalmeInferiorCm <= 0)
                {
                    TaskDialog.Show("MYG", "La longitud de empalme RNE del acero inferior no es válida.");
                    return;
                }

                if (crearAceroCentral)
                {
                    if (!TryLeerDouble(Form.LongitudEmpalmeCentralTexto, out longitudEmpalmeCentralCm) ||
                        longitudEmpalmeCentralCm <= 0)
                    {
                        TaskDialog.Show("MYG", "La longitud de empalme RNE del acero central no es válida.");
                        return;
                    }
                }
                else
                {
                    longitudEmpalmeCentralCm = longitudEmpalmeInferiorCm;
                }
            }
            else
            {
                double longitudEmpalmeCm = 0.0;

                if (!TryLeerDouble(Form.LongitudEmpalmeTexto, out longitudEmpalmeCm))
                {
                    TaskDialog.Show("MYG", "La longitud de empalme no es válida.");
                    return;
                }

                if (longitudEmpalmeCm <= 0)
                {
                    TaskDialog.Show("MYG", "La longitud de empalme debe ser mayor que cero.");
                    return;
                }

                longitudEmpalmeSuperiorCm = longitudEmpalmeCm;
                longitudEmpalmeInferiorCm = longitudEmpalmeCm;
                longitudEmpalmeCentralCm = longitudEmpalmeCm;
            }

            if (!TryLeerDouble(Form.LongitudBarraTexto, out longitudBarraM))
            {
                TaskDialog.Show("MYG", "La longitud de barra no es válida.");
                return;
            }

            if (longitudBarraM <= 0)
            {
                TaskDialog.Show("MYG", "La longitud de barra debe ser mayor que cero.");
                return;
            }
        }

        double recubrimiento = UnitUtils.ConvertToInternalUnits(
            recubrimientoCm,
            UnitTypeId.Centimeters);

        double longitudGanchoInicio = UnitUtils.ConvertToInternalUnits(
            longitudGanchoInicioCm,
            UnitTypeId.Centimeters);

        double longitudGanchoFin = UnitUtils.ConvertToInternalUnits(
            longitudGanchoFinCm,
            UnitTypeId.Centimeters);

        double longitudDesarrolloInicio = UnitUtils.ConvertToInternalUnits(
            longitudDesarrolloInicioCm,
            UnitTypeId.Centimeters);

        double longitudDesarrolloFin = UnitUtils.ConvertToInternalUnits(
            longitudDesarrolloFinCm,
            UnitTypeId.Centimeters);

        double longitudEmpalmeSuperior = UnitUtils.ConvertToInternalUnits(
            longitudEmpalmeSuperiorCm,
            UnitTypeId.Centimeters);

        double longitudEmpalmeInferior = UnitUtils.ConvertToInternalUnits(
            longitudEmpalmeInferiorCm,
            UnitTypeId.Centimeters);

        double longitudEmpalmeCentral = UnitUtils.ConvertToInternalUnits(
            longitudEmpalmeCentralCm,
            UnitTypeId.Centimeters);

        double longitudBarra = UnitUtils.ConvertToInternalUnits(
            longitudBarraM,
            UnitTypeId.Meters);

        double longitudEmpalmeMaxima = Math.Max(
            longitudEmpalmeSuperior,
            Math.Max(longitudEmpalmeInferior, longitudEmpalmeCentral));

        if (crearEmpalmes && longitudBarra <= longitudEmpalmeMaxima + Tol)
        {
            TaskDialog.Show(
                "MYG",
                "La longitud de barra debe ser mayor que la mayor longitud de empalme.\n\n" +
                "Ejemplo correcto:\n" +
                "Longitud de barra: 9 m\n" +
                "Empalme superior/inferior/central menor que la longitud de barra.");
            return;
        }

        List<Element> vigasSerie = ObtenerVigasOrdenadas(
            doc,
            SeleccionHandler.VigasSeleccionadas);

        if (vigasSerie == null || vigasSerie.Count == 0)
        {
            TaskDialog.Show("MYG", "No se pudo ordenar la serie de vigas seleccionadas.");
            return;
        }

        // =========================================================
        // VIGAS CURVAS / MIXTAS: CREACIÓN POR ANFITRIÓN
        // =========================================================
        // Cada viga conserva su LocationCurve y su sólido. La ruta global cuenta
        // también los vacíos para respetar la longitud comercial, pero cada Rebar
        // se crea únicamente en un anfitrión válido. Los vacíos se representan
        // mediante conectores independientes para no forzar un host múltiple.
        bool hayVigasCurvasMYG = vigasSerie.Any(v => EsElementoVigaCurvaMYG(v));

        if (hayVigasCurvasMYG)
        {
            if (usarDisenoManualSeccion &&
                Form != null &&
                Form.ModoDistribucionLongitudinalActualMYG !=
                    AceroLongitudinalVigasForm
                        .ModoDistribucionLongitudinalMYG.Continuo)
            {
                TaskDialog.Show(
                    "MYG - Estaciones",
                    "El modo por estaciones de esta versión trabaja con series " +
                    "de tramos rectos. Para vigas curvas use temporalmente " +
                    "CONTINUO (ACTUAL). La lógica continua no ha sido modificada.");
                return;
            }

            int creadasSerieCurvaMYG = 0;
            ultimoErrorCurvaMYG = string.Empty;
            erroresCurvaAcumuladosMYG.Clear();

            using (Transaction txCurvasMYG = new Transaction(
                doc,
                "MYG - Acero longitudinal continuo en vigas curvas"))
            {
                txCurvasMYG.Start();

                if (usarDisenoManualSeccion)
                {
                    creadasSerieCurvaMYG = CrearAceroLongitudinalManualEnVigasCurvasMYG(
                        doc,
                        vigasSerie,
                        disenoManualSeccion,
                        recubrimiento,
                        desarrolloInicioHabilitado,
                        longitudDesarrolloInicio,
                        desarrolloFinHabilitado,
                        longitudDesarrolloFin,
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra);
                }
                else
                {
                    creadasSerieCurvaMYG = CrearAceroLongitudinalEnSerieCurvaContinuaMYG(
                        doc,
                        vigasSerie,
                        tipoSuperior,
                        cantidadSuperior,
                        tipoInferior,
                        cantidadInferior,
                        crearAceroCentral,
                        tipoCentral,
                        recubrimiento,
                        desarrolloInicioHabilitado,
                        longitudDesarrolloInicio,
                        desarrolloFinHabilitado,
                        longitudDesarrolloFin,
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra);
                }

                if (creadasSerieCurvaMYG > 0)
                    txCurvasMYG.Commit();
                else
                    txCurvasMYG.RollBack();
            }

            if (creadasSerieCurvaMYG <= 0)
            {
                List<string> detallesCurvaMYG =
                    erroresCurvaAcumuladosMYG
                        .Where(x => !string.IsNullOrWhiteSpace(x))
                        .Distinct()
                        .Take(30)
                        .ToList();

                if (!string.IsNullOrWhiteSpace(ultimoErrorCurvaMYG) &&
                    !detallesCurvaMYG.Contains(ultimoErrorCurvaMYG))
                {
                    detallesCurvaMYG.Add(ultimoErrorCurvaMYG);
                }

                string detalleError = detallesCurvaMYG.Count == 0
                    ? "\n\nDetalle técnico:\nLa ejecución terminó con cero armaduras sin devolver una excepción."
                    : "\n\nDetalle técnico:\n" + string.Join("\n", detallesCurvaMYG);

                TaskDialog.Show(
                    "MYG - Vigas curvas",
                    "No se pudo crear ningún acero longitudinal en la ruta seleccionada.\n\n" +
                    "La rutina trabaja por anfitrión, admite líneas y curvas con centros " +
                    "o radios diferentes, incluye los vacíos en la longitud comercial y " +
                    "recalcula el recubrimiento lateral con el sólido real de cada viga." +
                    detalleError);
            }

            return;
        }

        DatosSerieVigas datosSerie = ObtenerDatosSerieVigas(doc, vigasSerie);

        if (datosSerie == null)
        {
            TaskDialog.Show(
                "MYG",
                "No se pudo construir la serie continua.\n\n" +
                "Verifique que las vigas seleccionadas estén alineadas y tengan geometría válida.");
            return;
        }

        // La ventana ya entrega la longitud correcta para cada extremo:
        // - Auto: ancho real de la columna - recubrimiento.
        // - Manual: valor digitado por el usuario.
        // Si Auto no encontró columna, el check queda deshabilitado y ese extremo
        // no entra en modo automático. No se reemplaza aquí el valor por cero.

        int barrasCreadas = 0;

        using (Transaction t = new Transaction(doc, "MYG - Acero longitudinal continuo en vigas"))
        {
            t.Start();

            if (usarDisenoManualSeccion)
            {
                AceroLongitudinalVigasForm.ModoDistribucionLongitudinalMYG
                    modoEstacionesMYG =
                        Form != null
                            ? Form.ModoDistribucionLongitudinalActualMYG
                            : AceroLongitudinalVigasForm
                                .ModoDistribucionLongitudinalMYG.Continuo;

                if (modoEstacionesMYG ==
                    AceroLongitudinalVigasForm
                        .ModoDistribucionLongitudinalMYG.Continuo)
                {
                    barrasCreadas = CrearAceroLongitudinalManualEnSerieMYG(
                        doc,
                        datosSerie,
                        disenoManualSeccion,
                        recubrimiento,
                        ganchoInicio,
                        longitudGanchoInicio,
                        ganchoFin,
                        longitudGanchoFin,
                        desarrolloInicioHabilitado,
                        longitudDesarrolloInicio,
                        desarrolloFinHabilitado,
                        longitudDesarrolloFin,
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra);
                }
                else
                {
                    barrasCreadas = CrearAceroLongitudinalManualPorEstacionesMYG(
                        doc,
                        datosSerie,
                        disenoManualSeccion,
                        recubrimiento,
                        ganchoInicio,
                        longitudGanchoInicio,
                        ganchoFin,
                        longitudGanchoFin,
                        desarrolloInicioHabilitado,
                        longitudDesarrolloInicio,
                        desarrolloFinHabilitado,
                        longitudDesarrolloFin,
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra,
                        modoEstacionesMYG);
                }
            }
            else
            {
                // =========================================================
                // NUEVA LÓGICA: LA EJECUCIÓN DEPENDE DEL MODELO DE LA VISTA PRELIMINAR
                // =========================================================
                // La ventana AceroLongitudinalVigasForm ahora construye un único modelo
                // de rutas mediante ObtenerModeloPreviewActual(). Este handler ya no
                // vuelve a decidir la forma del acero por su cuenta cuando el modelo
                // está disponible: toma las rutas que la ventana dibuja y las convierte
                // a coordenadas XYZ para Revit.
                AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modeloPreview = null;

                try
                {
                    modeloPreview = Form.ObtenerModeloPreviewActual();
                }
                catch
                {
                    modeloPreview = null;
                }

                int resultadoDesdePreview = -1;
                bool usarModeloPreviewParaEjecutar = false;

                // IMPORTANTE:
                // No se usa el modelo preview cuando hay viga de sección variable,
                // porque la versión anterior podía convertir puntos de dibujo en
                // zig-zag y además podía devolver 0 barras, bloqueando el respaldo.
                // En esos casos se usa la geometría original del handler, que lee
                // directamente los sólidos y ya venía funcionando mejor.
                if (usarModeloPreviewParaEjecutar &&
                    modeloPreview != null &&
                    modeloPreview.Valido &&
                    !modeloPreview.TienePerfilVariable &&
                    !desarrolloInicioHabilitado &&
                    !desarrolloFinHabilitado)
                {
                    resultadoDesdePreview = CrearAceroLongitudinalDesdeModeloPreview(
                        doc,
                        datosSerie,
                        modeloPreview,
                        tipoSuperior,
                        cantidadSuperior,
                        tipoInferior,
                        cantidadInferior,
                        crearAceroCentral,
                        tipoCentral,
                        recubrimiento,
                        ganchoInicio,
                        longitudGanchoInicio,
                        ganchoFin,
                        longitudGanchoFin);
                }

                if (resultadoDesdePreview > 0)
                {
                    barrasCreadas = resultadoDesdePreview;
                }
                else
                {
                    // Respaldo obligatorio:
                    // si el modelo preview es inválido, tiene sección variable,
                    // o Revit no crea ninguna barra desde ese modelo, se regresa
                    // a la lógica original de creación por geometría real.
                    barrasCreadas = CrearAceroLongitudinalEnSerie(
                        doc,
                        datosSerie,
                        tipoSuperior,
                        cantidadSuperior,
                        tipoInferior,
                        cantidadInferior,
                        crearAceroCentral,
                        tipoCentral,
                        recubrimiento,
                        ganchoInicio,
                        longitudGanchoInicio,
                        ganchoFin,
                        longitudGanchoFin,
                        desarrolloInicioHabilitado,
                        longitudDesarrolloInicio,
                        desarrolloFinHabilitado,
                        longitudDesarrolloFin,
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra);
                }
            }

            if (barrasCreadas > 0)
                t.Commit();
            else
                t.RollBack();
        }

        // V11.12: el diagnóstico también se muestra cuando solo FALLÓ una
        // capa/grupo y otras sí pudieron crearse. Esto es importante para los
        // casos donde, por ejemplo, desaparece Superior 2 o Superior 3 pero el
        // resto del armado sí queda modelado.
        if (erroresLongitudinalAcumuladosMYG.Count > 0)
        {
            MostrarDiagnosticoLongitudinalMYG(
                doc,
                barrasCreadas,
                usarDisenoManualSeccion,
                crearEmpalmes,
                longitudBarra,
                longitudEmpalmeSuperior,
                longitudEmpalmeInferior,
                longitudEmpalmeCentral);
        }
        else if (barrasCreadas <= 0)
        {
            TaskDialog.Show(
                "MYG",
                usarDisenoManualSeccion
                    ? "No se creó ninguna barra desde el diseño manual de sección.\n\n" +
                      "Revise el recubrimiento, los diámetros y que las posiciones estén dentro del contorno útil."
                    : "No se creó ninguna barra longitudinal con la configuración actual.");
        }

    }


    private void RegistrarErrorCurvaMYG(string mensaje)
    {
        if (string.IsNullOrWhiteSpace(mensaje))
            return;

        string limpio = mensaje.Trim();
        ultimoErrorCurvaMYG = limpio;

        if (!erroresCurvaAcumuladosMYG.Contains(limpio))
            erroresCurvaAcumuladosMYG.Add(limpio);
    }


    // =========================================================
    // V11.12 - DIAGNÓSTICO COPIABLE DE LONGITUDINALES
    // =========================================================
    private void MarcarUltimoErrorLongitudinalMYG(
        string etapa,
        string detalle,
        Exception ex = null)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();

        if (!string.IsNullOrWhiteSpace(etapa))
            sb.Append("Etapa: ").Append(etapa.Trim());

        if (!string.IsNullOrWhiteSpace(detalle))
        {
            if (sb.Length > 0) sb.Append(" | ");
            sb.Append(detalle.Trim());
        }

        if (ex != null)
        {
            if (sb.Length > 0) sb.AppendLine();
            sb.Append("Excepción: ").Append(ex.GetType().FullName);
            sb.AppendLine();
            sb.Append("Mensaje: ").Append(ex.Message ?? string.Empty);
            if (!string.IsNullOrWhiteSpace(ex.StackTrace))
            {
                sb.AppendLine();
                sb.Append("Stack: ").Append(ex.StackTrace);
            }
        }

        ultimoErrorLongitudinalMYG = sb.ToString();
    }

    private string FormatearLongitudDiagnosticoMYG(double valorInterno)
    {
        try
        {
            double cm = UnitUtils.ConvertFromInternalUnits(
                valorInterno,
                UnitTypeId.Centimeters);

            double m = UnitUtils.ConvertFromInternalUnits(
                valorInterno,
                UnitTypeId.Meters);

            return cm.ToString(
                    "0.###",
                    System.Globalization.CultureInfo.InvariantCulture) +
                " cm (" +
                m.ToString(
                    "0.####",
                    System.Globalization.CultureInfo.InvariantCulture) +
                " m)";
        }
        catch
        {
            return valorInterno.ToString(
                "0.########",
                System.Globalization.CultureInfo.InvariantCulture) +
                " ft internos";
        }
    }

    private string FormatearXYZDiagnosticoMYG(XYZ p)
    {
        if (p == null)
            return "null";

        try
        {
            double x = UnitUtils.ConvertFromInternalUnits(p.X, UnitTypeId.Meters);
            double y = UnitUtils.ConvertFromInternalUnits(p.Y, UnitTypeId.Meters);
            double z = UnitUtils.ConvertFromInternalUnits(p.Z, UnitTypeId.Meters);

            return "(" +
                x.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture) + ", " +
                y.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture) + ", " +
                z.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture) +
                ") m";
        }
        catch
        {
            return p.ToString();
        }
    }

    private void RegistrarFalloGrupoLongitudinalMYG(
        AceroVigaGrupoLongitudinal2D grupo,
        List<AceroVigaBarraLongitudinal2D> definiciones,
        DatosSerieVigas datos,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        secuenciaErrorLongitudinalMYG++;

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.AppendLine("============================================================");
        sb.Append("ERROR LONGITUDINAL #").AppendLine(
            secuenciaErrorLongitudinalMYG.ToString());

        if (grupo != null)
        {
            sb.Append("Grupo ID: ").AppendLine(grupo.Id ?? "(sin id)");
            sb.Append("Capa: ").Append(grupo.TipoCapa).Append(" ")
                .AppendLine(grupo.NumeroCapa.ToString());
            sb.Append("Guía ID: ").AppendLine(grupo.GuiaCapaId ?? "");
            sb.Append("Regla solicitada: ").AppendLine(grupo.Regla.ToString());
            sb.Append("Cantidad solicitada: ").AppendLine(
                grupo.Cantidad.ToString());
            sb.Append("Espaciado guardado: ")
                .Append(grupo.EspaciadoCm.ToString(
                    "0.###",
                    System.Globalization.CultureInfo.InvariantCulture))
                .AppendLine(" cm");
            sb.Append("Omitir primera/última: ")
                .Append(grupo.OmitirPrimeraBarra)
                .Append(" / ")
                .AppendLine(grupo.OmitirUltimaBarra.ToString());
            sb.Append("Trazo 2 puntos: ")
                .AppendLine(grupo.RespetarTrazoDosPuntos.ToString());

            RebarBarType tipo = grupo.TipoBarra;
            if (tipo == null && definiciones != null)
            {
                tipo = definiciones
                    .Where(x => x != null && x.TipoBarra != null)
                    .Select(x => x.TipoBarra)
                    .FirstOrDefault();
            }

            if (tipo != null)
            {
                sb.Append("Tipo de barra: ").AppendLine(tipo.Name ?? "");
                sb.Append("Diámetro: ")
                    .Append(
                        UnitUtils.ConvertFromInternalUnits(
                            ObtenerDiametroBarra(tipo),
                            UnitTypeId.Millimeters)
                        .ToString(
                            "0.###",
                            System.Globalization.CultureInfo.InvariantCulture))
                    .AppendLine(" mm");
            }
        }

        sb.Append("Definiciones encontradas: ")
            .AppendLine((definiciones != null ? definiciones.Count : 0).ToString());

        sb.Append("Crear empalmes: ").AppendLine(crearEmpalmes.ToString());
        sb.Append("Longitud comercial: ")
            .AppendLine(FormatearLongitudDiagnosticoMYG(longitudBarra));
        sb.Append("Empalme superior: ")
            .AppendLine(FormatearLongitudDiagnosticoMYG(longitudEmpalmeSuperior));
        sb.Append("Empalme inferior: ")
            .AppendLine(FormatearLongitudDiagnosticoMYG(longitudEmpalmeInferior));
        sb.Append("Empalme central: ")
            .AppendLine(FormatearLongitudDiagnosticoMYG(longitudEmpalmeCentral));

        if (datos != null)
        {
            sb.Append("Longitud total serie: ")
                .AppendLine(FormatearLongitudDiagnosticoMYG(datos.LongitudTotal));
            sb.Append("Inicio útil: ")
                .AppendLine(FormatearLongitudDiagnosticoMYG(
                    datos.InicioUtilArmaduraSerie));
            sb.Append("Fin útil: ")
                .AppendLine(FormatearLongitudDiagnosticoMYG(
                    datos.FinUtilArmaduraSerie));
            sb.Append("Host base: ")
                .Append(datos.Host != null ? datos.Host.Id.ToString() : "null")
                .Append(" | ")
                .AppendLine(datos.Host != null ? datos.Host.Name : "");

            if (datos.Vigas != null)
            {
                sb.Append("Hosts de la serie: ");
                sb.AppendLine(string.Join(
                    ", ",
                    datos.Vigas
                        .Where(x => x != null && x.Elemento != null)
                        .Select(x => x.Elemento.Id.ToString())
                        .ToArray()));
            }
        }

        sb.AppendLine("--- ÚLTIMO ERROR INTERNO ---");
        sb.AppendLine(
            string.IsNullOrWhiteSpace(ultimoErrorLongitudinalMYG)
                ? "La rama devolvió 0 sin una excepción capturada. Revisar geometría/segmentación."
                : ultimoErrorLongitudinalMYG);

        string texto = sb.ToString();
        if (!erroresLongitudinalAcumuladosMYG.Contains(texto))
            erroresLongitudinalAcumuladosMYG.Add(texto);
    }

    private void MostrarDiagnosticoLongitudinalMYG(
        Document doc,
        int barrasCreadas,
        bool usarDisenoManualSeccion,
        bool crearEmpalmes,
        double longitudBarra,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.AppendLine("MYG - DIAGNÓSTICO ACERO LONGITUDINAL V11.12");
        sb.AppendLine("Copie TODO este texto y péguelo en el chat para revisar la causa.");
        sb.AppendLine();
        sb.Append("Documento: ").AppendLine(doc != null ? doc.Title : "(sin documento)");
        sb.Append("Modo editor manual: ").AppendLine(usarDisenoManualSeccion.ToString());
        sb.Append("Barras creadas reportadas: ").AppendLine(barrasCreadas.ToString());
        sb.Append("Empalmes activos: ").AppendLine(crearEmpalmes.ToString());
        sb.Append("Longitud comercial: ").AppendLine(
            FormatearLongitudDiagnosticoMYG(longitudBarra));
        sb.Append("Empalme superior: ").AppendLine(
            FormatearLongitudDiagnosticoMYG(longitudEmpalmeSuperior));
        sb.Append("Empalme inferior: ").AppendLine(
            FormatearLongitudDiagnosticoMYG(longitudEmpalmeInferior));
        sb.Append("Empalme central: ").AppendLine(
            FormatearLongitudDiagnosticoMYG(longitudEmpalmeCentral));
        sb.Append("Cantidad de grupos con fallo: ")
            .AppendLine(erroresLongitudinalAcumuladosMYG.Count.ToString());
        sb.AppendLine();

        foreach (string error in erroresLongitudinalAcumuladosMYG)
        {
            if (!string.IsNullOrWhiteSpace(error))
                sb.AppendLine(error);
        }

        string diagnostico = sb.ToString();

        try
        {
            using (System.Windows.Forms.Form ventana =
                new System.Windows.Forms.Form())
            {
                ventana.Text = "MYG - Diagnóstico de acero longitudinal";
                ventana.Width = 1050;
                ventana.Height = 720;
                ventana.StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterScreen;
                ventana.MinimizeBox = false;
                ventana.MaximizeBox = true;

                System.Windows.Forms.Label lbl =
                    new System.Windows.Forms.Label();
                lbl.Dock = System.Windows.Forms.DockStyle.Top;
                lbl.Height = 48;
                lbl.Padding = new System.Windows.Forms.Padding(10, 8, 10, 4);
                lbl.Text =
                    "Se detectó al menos un grupo longitudinal que Revit no pudo crear. " +
                    "Pulse COPIAR TODO y pégueme el diagnóstico completo.";

                System.Windows.Forms.TextBox txt =
                    new System.Windows.Forms.TextBox();
                txt.Dock = System.Windows.Forms.DockStyle.Fill;
                txt.Multiline = true;
                txt.ReadOnly = true;
                txt.WordWrap = false;
                txt.ScrollBars = System.Windows.Forms.ScrollBars.Both;
                txt.Font = new System.Drawing.Font("Consolas", 9.0F);
                txt.Text = diagnostico;

                System.Windows.Forms.FlowLayoutPanel botones =
                    new System.Windows.Forms.FlowLayoutPanel();
                botones.Dock = System.Windows.Forms.DockStyle.Bottom;
                botones.Height = 48;
                botones.FlowDirection =
                    System.Windows.Forms.FlowDirection.RightToLeft;
                botones.Padding = new System.Windows.Forms.Padding(8);

                System.Windows.Forms.Button cerrar =
                    new System.Windows.Forms.Button();
                cerrar.Text = "CERRAR";
                cerrar.Width = 110;
                cerrar.Height = 28;
                cerrar.Click += (sender, e) => ventana.Close();

                System.Windows.Forms.Button copiar =
                    new System.Windows.Forms.Button();
                copiar.Text = "COPIAR TODO";
                copiar.Width = 130;
                copiar.Height = 28;
                copiar.Click += (sender, e) =>
                {
                    try
                    {
                        System.Windows.Forms.Clipboard.SetText(diagnostico);
                        copiar.Text = "COPIADO";
                    }
                    catch (Exception ex)
                    {
                        System.Windows.Forms.MessageBox.Show(
                            "No se pudo copiar automáticamente.\n\n" + ex.Message,
                            "MYG",
                            System.Windows.Forms.MessageBoxButtons.OK,
                            System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                };

                botones.Controls.Add(cerrar);
                botones.Controls.Add(copiar);
                ventana.Controls.Add(txt);
                ventana.Controls.Add(lbl);
                ventana.Controls.Add(botones);
                ventana.ShowDialog();
            }
        }
        catch
        {
            TaskDialog dialogo = new TaskDialog(
                "MYG - Diagnóstico longitudinal");
            dialogo.MainInstruction =
                "Se detectaron errores creando uno o más grupos longitudinales.";
            dialogo.MainContent =
                "No se pudo abrir la ventana copiable. Revise el contenido expandido.";
            dialogo.ExpandedContent = diagnostico;
            dialogo.Show();
        }
    }


    // =========================================================
    // SERIE CURVA CONTINUA - CREACIÓN PRINCIPAL
    // =========================================================
    private int CrearAceroLongitudinalEnSerieCurvaContinuaMYG(
        Document doc,
        List<Element> vigas,
        RebarBarType tipoSuperior,
        int cantidadSuperior,
        RebarBarType tipoInferior,
        int cantidadInferior,
        bool crearAceroCentral,
        RebarBarType tipoCentral,
        double recubrimiento,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        if (doc == null || vigas == null || vigas.Count == 0)
        {
            RegistrarErrorCurvaMYG(
                "La rama curva no recibió elementos seleccionados válidos.");

            return 0;
        }

        DatosSerieCurvaLongitudinalMYG serie =
            ObtenerDatosSerieCurvaContinuaMYG(doc, vigas);

        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            serie.LongitudTotal <= Tol)
        {
            RegistrarErrorCurvaMYG(
                "No se pudo construir la ruta curva/mixta a partir de las LocationCurve seleccionadas.");

            return 0;
        }

        if (serie.HostPrincipal == null)
        {
            RegistrarErrorCurvaMYG(
                "La ruta curva no contiene ningún anfitrión válido.");

            return 0;
        }

        DatosSerieVigas serieLogica =
            CrearDatosSerieLogicaCurvaContinuaMYG(serie);

        if (serieLogica == null)
        {
            RegistrarErrorCurvaMYG(
                "No se pudo construir la serie lógica para calcular piezas comerciales y empalmes.");

            return 0;
        }

        // La longitud global incluye:
        // - la longitud real de cada LocationCurve;
        // - la distancia entre vigas consecutivas;
        // - los desarrollos de los extremos, cuando están habilitados.
        double estacionInicio = desarrolloInicioHabilitado
            ? -Math.Max(0.0, longitudDesarrolloInicio)
            : recubrimiento;

        double estacionFin = desarrolloFinHabilitado
            ? serie.LongitudTotal + Math.Max(0.0, longitudDesarrolloFin)
            : serie.LongitudTotal - recubrimiento;

        if (estacionFin <= estacionInicio + Tol)
        {
            RegistrarErrorCurvaMYG(
                "El intervalo útil de la ruta curva quedó sin longitud.");

            return 0;
        }

        int contador = 0;

        List<ConfiguracionCapaLongitudinal> capasSuperiores =
            ConstruirConfiguracionCapasLongitudinales(
                true,
                tipoSuperior,
                cantidadSuperior,
                recubrimiento,
                crearEmpalmes);

        List<ConfiguracionCapaLongitudinal> capasInferiores =
            ConstruirConfiguracionCapasLongitudinales(
                false,
                tipoInferior,
                cantidadInferior,
                recubrimiento,
                crearEmpalmes);

        foreach (ConfiguracionCapaLongitudinal capa in capasSuperiores)
        {
            if (capa == null)
                continue;

            contador += CrearCapaLongitudinalSerieCurvaMYG(
                doc,
                serie,
                serieLogica,
                capa.TipoBarra,
                capa.Cantidad,
                capa.Diametro,
                capa.OffsetCentroDesdeCara,
                true,
                estacionInicio,
                estacionFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudBarra,
                capa.TipoElementoTexto,
                1);
        }

        foreach (ConfiguracionCapaLongitudinal capa in capasInferiores)
        {
            if (capa == null)
                continue;

            contador += CrearCapaLongitudinalSerieCurvaMYG(
                doc,
                serie,
                serieLogica,
                capa.TipoBarra,
                capa.Cantidad,
                capa.Diametro,
                capa.OffsetCentroDesdeCara,
                false,
                estacionInicio,
                estacionFin,
                crearEmpalmes,
                longitudEmpalmeInferior,
                longitudBarra,
                capa.TipoElementoTexto,
                -1);
        }

        if (crearAceroCentral && tipoCentral != null)
        {
            double diametroCentral =
                ObtenerDiametroBarra(tipoCentral);

            // La correspondencia lateral del acero central se calcula con las
            // dos barras centrales reales, no con los extremos globales de la
            // sección. Esto evita que izquierda/derecha se intercambien entre
            // anfitriones y que las dos uniones centrales se crucen.
            ActualizarCorrespondenciaLateralConfiguracionMYG(
                serie,
                2,
                diametroCentral,
                0.0,
                false,
                true);

            for (int indiceCentral = 0;
                 indiceCentral < 2;
                 indiceCentral++)
            {
                double factorLongitud =
                    CalcularFactorLongitudCurvaSeguroMYG(
                        serie,
                        2,
                        indiceCentral,
                        diametroCentral,
                        0.0,
                        false,
                        true);

                double longitudBarraEje =
                    CalcularLongitudEjeComercialCurvaMYG(
                        longitudBarra,
                        factorLongitud,
                        longitudEmpalmeCentral,
                        diametroCentral);

                List<SegmentoAceroLongitudinal> segmentosCentrales =
                    ConstruirSegmentosLongitudinales(
                        serieLogica,
                        0,
                        estacionInicio,
                        estacionFin,
                        crearEmpalmes,
                        longitudBarraEje,
                        longitudEmpalmeCentral,
                        0.0,
                        0.0,
                        diametroCentral,
                        tipoCentral);

                contador += CrearBarraSerieCurvaPorSegmentosMYG(
                    doc,
                    serie,
                    tipoCentral,
                    2,
                    indiceCentral,
                    diametroCentral,
                    0.0,
                    false,
                    true,
                    segmentosCentrales,
                    longitudBarra,
                    "Acero longitudinal - Central");
            }
        }

        if (contador <= 0)
        {
            RegistrarErrorCurvaMYG(
                "La ruta fue construida, pero ninguna capa produjo armadura.");
        }

        return contador;
    }


    private int CrearCapaLongitudinalSerieCurvaMYG(
        Document doc,
        DatosSerieCurvaLongitudinalMYG serie,
        DatosSerieVigas serieLogica,
        RebarBarType tipoBarra,
        int cantidad,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        double estacionInicio,
        double estacionFin,
        bool crearEmpalmes,
        double longitudEmpalme,
        double longitudBarra,
        string tipoElementoTexto,
        int tipoRutaEmpalme)
    {
        if (doc == null ||
            serie == null ||
            serieLogica == null ||
            tipoBarra == null ||
            cantidad <= 0)
        {
            RegistrarErrorCurvaMYG(
                "Una capa curva llegó con datos incompletos.");

            return 0;
        }

        // Cada capa calcula su propia correspondencia de barras usando las
        // posiciones realmente creadas para su diámetro, recubrimiento vertical
        // y cantidad. Las capas 2, 3 y 4 ya no heredan una inversión lateral
        // calculada con la primera capa.
        ActualizarCorrespondenciaLateralConfiguracionMYG(
            serie,
            cantidad,
            diametro,
            offsetVerticalDesdeCara,
            superior,
            false);

        int contador = 0;

        // Cada posición lateral puede tener un radio efectivo diferente.
        // Por eso la reducción conservadora de la longitud comercial se calcula
        // por barra y no una sola vez para toda la capa.
        for (int indiceBarra = 0;
             indiceBarra < cantidad;
             indiceBarra++)
        {
            double factorLongitud =
                CalcularFactorLongitudCurvaSeguroMYG(
                    serie,
                    cantidad,
                    indiceBarra,
                    diametro,
                    offsetVerticalDesdeCara,
                    superior,
                    false);

            double longitudBarraEje =
                CalcularLongitudEjeComercialCurvaMYG(
                    longitudBarra,
                    factorLongitud,
                    longitudEmpalme,
                    diametro);

            List<SegmentoAceroLongitudinal> segmentos =
                ConstruirSegmentosLongitudinales(
                    serieLogica,
                    tipoRutaEmpalme,
                    estacionInicio,
                    estacionFin,
                    crearEmpalmes,
                    longitudBarraEje,
                    longitudEmpalme,
                    0.0,
                    0.0,
                    diametro,
                    tipoBarra);

            if (segmentos == null || segmentos.Count == 0)
            {
                RegistrarErrorCurvaMYG(
                    "No se generaron piezas comerciales para " +
                    tipoElementoTexto +
                    ", barra " +
                    (indiceBarra + 1).ToString() +
                    ".");

                continue;
            }

            contador += CrearBarraSerieCurvaPorSegmentosMYG(
                doc,
                serie,
                tipoBarra,
                cantidad,
                indiceBarra,
                diametro,
                offsetVerticalDesdeCara,
                superior,
                false,
                segmentos,
                longitudBarra,
                tipoElementoTexto);
        }

        return contador;
    }


    private int CrearBarraSerieCurvaPorSegmentosMYG(
        Document doc,
        DatosSerieCurvaLongitudinalMYG serie,
        RebarBarType tipoBarra,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central,
        List<SegmentoAceroLongitudinal> segmentos,
        double longitudBarraMaxima,
        string tipoElementoTexto)
    {
        if (doc == null ||
            serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            tipoBarra == null ||
            segmentos == null ||
            segmentos.Count == 0)
        {
            RegistrarErrorCurvaMYG(
                "Una barra curva llegó con datos incompletos.");

            return 0;
        }

        List<SegmentoAceroLongitudinal> piezas = segmentos
            .Where(s =>
                s != null &&
                s.XFin > s.XInicio + Tol)
            .OrderBy(s => s.XInicio)
            .ThenBy(s => s.XFin)
            .ToList();

        if (piezas.Count == 0)
            return 0;

        // =========================================================
        // UNA RUTA CANÓNICA POR TRAMO Y BARRA LÓGICA
        // =========================================================
        // El input de longitud comercial ya fue leído de la ventana y utilizado
        // por ConstruirSegmentosLongitudinales(). Cada elemento de "piezas"
        // representa una pieza comercial independiente.
        //
        // Se construye un único boceto por pieza. Cuando la pieza empieza en un
        // empalme, el tramo traslapado se desplaza en Z y retorna a la trayectoria
        // principal mediante la misma diagonal de 20 cm utilizada en las vigas
        // rectas.
        List<Curve> rutasCanonicasPorTramo =
            ConstruirRutasCanonicasPorTramoBarraMYG(
                serie,
                cantidad,
                indiceBarra,
                diametro,
                offsetVerticalDesdeCara,
                superior,
                central);

        if (rutasCanonicasPorTramo == null ||
            rutasCanonicasPorTramo.Count != serie.Tramos.Count)
        {
            RegistrarErrorCurvaMYG(
                "No se pudieron construir las rutas canónicas de la barra lógica " +
                (indiceBarra + 1).ToString() + ".");

            return 0;
        }

        int creadas = 0;

        for (int indicePieza = 0;
             indicePieza < piezas.Count;
             indicePieza++)
        {
            SegmentoAceroLongitudinal pieza =
                piezas[indicePieza];

            if (pieza == null ||
                pieza.XFin <= pieza.XInicio + Tol)
            {
                continue;
            }

            double longitudEmpalmePieza =
                0.0;

            if (pieza.TieneEmpalmeInicio &&
                indicePieza > 0)
            {
                SegmentoAceroLongitudinal anterior =
                    piezas[indicePieza - 1];

                if (anterior != null)
                {
                    longitudEmpalmePieza =
                        Math.Max(
                            0.0,
                            Math.Min(
                                anterior.XFin,
                                pieza.XFin) -
                            pieza.XInicio);
                }
            }

            SegmentoAceroLongitudinal piezaCreacion;

            IList<Curve> bocetoCompleto =
                ConstruirBocetoCurvoRespetandoLongitudMaximaMYG(
                    serie,
                    rutasCanonicasPorTramo,
                    pieza,
                    longitudEmpalmePieza,
                    diametro,
                    superior,
                    central,
                    longitudBarraMaxima,
                    out piezaCreacion);

            if (bocetoCompleto == null ||
                bocetoCompleto.Count == 0)
            {
                RegistrarErrorCurvaMYG(
                    "La pieza comercial comprendida entre " +
                    UnitUtils.ConvertFromInternalUnits(
                        pieza.XInicio,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m y " +
                    UnitUtils.ConvertFromInternalUnits(
                        pieza.XFin,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m quedó sin boceto.");

                continue;
            }

            double longitudRealPieza =
                CalcularLongitudBocetoCurvoMYG(
                    bocetoCompleto);

            double toleranciaLongitud =
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Millimeters);

            if (longitudBarraMaxima > Tol &&
                longitudRealPieza >
                longitudBarraMaxima +
                toleranciaLongitud)
            {
                RegistrarErrorCurvaMYG(
                    "Se omitió una pieza porque su longitud real sería " +
                    UnitUtils.ConvertFromInternalUnits(
                        longitudRealPieza,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m, mayor que el máximo ingresado de " +
                    UnitUtils.ConvertFromInternalUnits(
                        longitudBarraMaxima,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m.");

                continue;
            }

            // Una sola llamada de creación por pieza comercial.
            Rebar rb = CrearRebarLongitudinalCurvoSerieMYG(
                doc,
                serie,
                tipoBarra,
                serie.EjeZ,
                bocetoCompleto);

            if (rb == null)
            {
                RegistrarErrorCurvaMYG(
                    "Revit rechazó el boceto único de la pieza comercial entre " +
                    UnitUtils.ConvertFromInternalUnits(
                        piezaCreacion.XInicio,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m y " +
                    UnitUtils.ConvertFromInternalUnits(
                        piezaCreacion.XFin,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m. " +
                    (string.IsNullOrWhiteSpace(ultimoErrorCurvaMYG)
                        ? string.Empty
                        : ultimoErrorCurvaMYG));

                continue;
            }

            double longitudRevit =
                ObtenerParametroDoublePorNombre(
                    rb,
                    "Longitud de barra",
                    "Bar Length");

            double toleranciaLongitudRevit =
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters);

            if (longitudBarraMaxima > Tol &&
                longitudRevit > Tol &&
                longitudRevit >
                longitudBarraMaxima +
                toleranciaLongitudRevit)
            {
                try
                {
                    doc.Delete(
                        rb.Id);
                }
                catch
                {
                }

                RegistrarErrorCurvaMYG(
                    "Revit generó una pieza de " +
                    UnitUtils.ConvertFromInternalUnits(
                        longitudRevit,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m, mayor que el máximo ingresado de " +
                    UnitUtils.ConvertFromInternalUnits(
                        longitudBarraMaxima,
                        UnitTypeId.Meters).ToString("0.###") +
                    " m. La pieza fue eliminada.");

                continue;
            }

            Element hostParametros =
                ObtenerHostRealRebarLongitudinalMYG(
                    doc,
                    rb,
                    ObtenerHostPrincipalPiezaComercialCurvaMYG(
                        serie,
                        piezaCreacion));

            AplicarParametrosInstanciaAceroLongitudinal(
                doc,
                rb,
                hostParametros,
                tipoElementoTexto);

            creadas++;
        }

        return creadas;
    }




    // =========================================================
    // BOCETO ÚNICO POR PIEZA COMERCIAL
    // =========================================================
    private IList<Curve> ConstruirBocetoUnicoPiezaComercialCurvaMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        List<Curve> rutasCanonicasPorTramo,
        SegmentoAceroLongitudinal pieza,
        double longitudEmpalme,
        double diametro,
        bool superior,
        bool central)
    {
        if (pieza == null)
            return new List<Curve>();

        double desfaseEmpalme =
            ObtenerDesfaseEmpalmeCaraACara(
                diametro);

        bool crearQuiebre =
            pieza.TieneEmpalmeInicio &&
            longitudEmpalme > Tol &&
            desfaseEmpalme > Tol;

        if (!crearQuiebre)
        {
            return ConstruirBocetoBasePiezaComercialCurvaMYG(
                serie,
                rutasCanonicasPorTramo,
                pieza);
        }

        XYZ ejeZ =
            serie != null &&
            serie.EjeZ != null &&
            serie.EjeZ.GetLength() > Tol
                ? serie.EjeZ.Normalize()
                : XYZ.BasisZ;

        // Misma lógica utilizada en vigas rectas:
        // - superior: el inicio del segundo acero baja;
        // - inferior: el inicio del segundo acero sube;
        // - central: se desplaza hacia +Z.
        XYZ direccionDesfase =
            central
                ? ejeZ
                : superior
                    ? ejeZ.Multiply(-1.0)
                    : ejeZ;

        XYZ offset =
            direccionDesfase.Multiply(
                desfaseEmpalme);

        double xEmpalmeFin =
            Math.Min(
                pieza.XInicio +
                longitudEmpalme,
                pieza.XFin);

        double espacioDespuesEmpalme =
            pieza.XFin -
            xEmpalmeFin;

        double longitudDiagonal;

        if (!TryObtenerLongitudDiagonalQuiebreSeguraMYG(
                espacioDespuesEmpalme,
                desfaseEmpalme,
                out longitudDiagonal))
        {
            // No crear una pieza recta colineal ni un conector separado.
            return new List<Curve>();
        }

        double xDiagonalFin =
            Math.Min(
                xEmpalmeFin +
                longitudDiagonal,
                pieza.XFin);

        List<Curve> resultado =
            new List<Curve>();

        SegmentoAceroLongitudinal parteTraslapada =
            new SegmentoAceroLongitudinal(
                pieza.XInicio,
                xEmpalmeFin);

        IList<Curve> curvasTraslapadas =
            ConstruirBocetoBasePiezaComercialCurvaMYG(
                serie,
                rutasCanonicasPorTramo,
                parteTraslapada);

        Transform traslado =
            Transform.CreateTranslation(
                offset);

        if (curvasTraslapadas != null)
        {
            foreach (Curve curva in curvasTraslapadas)
            {
                if (curva == null ||
                    !curva.IsBound ||
                    curva.Length <= Tol)
                {
                    continue;
                }

                Curve desplazada = null;

                try
                {
                    desplazada =
                        curva.CreateTransformed(
                            traslado);
                }
                catch
                {
                    desplazada = null;
                }

                AgregarCurvaBocetoUnicoMYG(
                    resultado,
                    desplazada);
            }
        }

        if (xDiagonalFin >
            xEmpalmeFin + Tol)
        {
            SegmentoAceroLongitudinal partePosterior =
                new SegmentoAceroLongitudinal(
                    xDiagonalFin,
                    pieza.XFin);

            IList<Curve> curvasPosteriores =
                ConstruirBocetoBasePiezaComercialCurvaMYG(
                    serie,
                    rutasCanonicasPorTramo,
                    partePosterior);

            if (curvasPosteriores != null)
            {
                // AgregarCurvaBocetoUnicoMYG inserta automáticamente la línea
                // diagonal entre el final desplazado del traslape y el inicio
                // normal de la trayectoria en xDiagonalFin.
                foreach (Curve curva in curvasPosteriores)
                {
                    AgregarCurvaBocetoUnicoMYG(
                        resultado,
                        curva);
                }
            }
        }
        else
        {
            // Respaldo para una pieza que termina inmediatamente después del
            // traslape: retorna al punto final canónico mediante una diagonal.
            double longitudSonda =
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Centimeters);

            double inicioSonda =
                Math.Max(
                    pieza.XInicio,
                    pieza.XFin -
                    longitudSonda);

            SegmentoAceroLongitudinal sondaFinal =
                new SegmentoAceroLongitudinal(
                    inicioSonda,
                    pieza.XFin);

            IList<Curve> curvasFinales =
                ConstruirBocetoBasePiezaComercialCurvaMYG(
                    serie,
                    rutasCanonicasPorTramo,
                    sondaFinal);

            Curve ultima =
                curvasFinales != null
                    ? curvasFinales.LastOrDefault(
                        c =>
                            c != null &&
                            c.IsBound &&
                            c.Length > Tol)
                    : null;

            XYZ puntoFinalCanonico =
                ultima != null
                    ? ultima.GetEndPoint(1)
                    : null;

            Curve ultimaResultado =
                resultado.LastOrDefault(
                    c =>
                        c != null &&
                        c.IsBound &&
                        c.Length > Tol);

            XYZ puntoFinalDesplazado =
                ultimaResultado != null
                    ? ultimaResultado.GetEndPoint(1)
                    : null;

            if (puntoFinalDesplazado != null &&
                puntoFinalCanonico != null &&
                puntoFinalDesplazado.DistanceTo(
                    puntoFinalCanonico) > Tol)
            {
                try
                {
                    AgregarCurvaBocetoUnicoMYG(
                        resultado,
                        Line.CreateBound(
                            puntoFinalDesplazado,
                            puntoFinalCanonico));
                }
                catch
                {
                }
            }
        }

        IList<Curve> limpias =
            LimpiarCurvasCadenaMYG(
                resultado);

        return limpias ??
            new List<Curve>();
    }


    private IList<Curve> ConstruirBocetoCurvoRespetandoLongitudMaximaMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        List<Curve> rutasCanonicasPorTramo,
        SegmentoAceroLongitudinal piezaOriginal,
        double longitudEmpalmeOriginal,
        double diametro,
        bool superior,
        bool central,
        double longitudBarraMaxima,
        out SegmentoAceroLongitudinal piezaCreacion)
    {
        piezaCreacion =
            ClonarSegmentoAceroLongitudinalMYG(
                piezaOriginal);

        if (piezaCreacion == null)
            return new List<Curve>();

        double longitudEmpalme =
            Math.Max(
                0.0,
                longitudEmpalmeOriginal);

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Millimeters);

        for (int intento = 0;
             intento < 8;
             intento++)
        {
            IList<Curve> boceto =
                ConstruirBocetoUnicoPiezaComercialCurvaMYG(
                    serie,
                    rutasCanonicasPorTramo,
                    piezaCreacion,
                    longitudEmpalme,
                    diametro,
                    superior,
                    central);

            if (boceto == null ||
                boceto.Count == 0)
            {
                return boceto ??
                    new List<Curve>();
            }

            double longitudReal =
                CalcularLongitudBocetoCurvoMYG(
                    boceto);

            if (longitudBarraMaxima <= Tol ||
                longitudReal <=
                longitudBarraMaxima +
                tolerancia)
            {
                return boceto;
            }

            double exceso =
                longitudReal -
                longitudBarraMaxima +
                tolerancia;

            double ajuste =
                Math.Max(
                    UnitUtils.ConvertToInternalUnits(
                        0.2,
                        UnitTypeId.Centimeters),
                    exceso * 1.10);

            // Si es la última pieza, se conserva el extremo final y se consume
            // parte del traslape inicial. En las demás piezas se conserva el
            // inicio y se reduce el extremo final. Así nunca se supera el input.
            if (piezaCreacion.EsUltimo &&
                piezaCreacion.TieneEmpalmeInicio)
            {
                piezaCreacion.XInicio +=
                    ajuste;

                longitudEmpalme =
                    Math.Max(
                        0.0,
                        longitudEmpalme -
                        ajuste);
            }
            else
            {
                piezaCreacion.XFin -=
                    ajuste;
            }

            if (piezaCreacion.XFin <=
                piezaCreacion.XInicio + Tol)
            {
                return new List<Curve>();
            }
        }

        return ConstruirBocetoUnicoPiezaComercialCurvaMYG(
            serie,
            rutasCanonicasPorTramo,
            piezaCreacion,
            longitudEmpalme,
            diametro,
            superior,
            central);
    }


    private SegmentoAceroLongitudinal
        ClonarSegmentoAceroLongitudinalMYG(
            SegmentoAceroLongitudinal origen)
    {
        if (origen == null)
            return null;

        SegmentoAceroLongitudinal copia =
            new SegmentoAceroLongitudinal(
                origen.XInicio,
                origen.XFin);

        copia.EsPrimero =
            origen.EsPrimero;

        copia.EsUltimo =
            origen.EsUltimo;

        copia.TieneEmpalmeInicio =
            origen.TieneEmpalmeInicio;

        copia.TieneEmpalmeFin =
            origen.TieneEmpalmeFin;

        // V11.8: se conserva el campo solo por compatibilidad binaria,
        // pero nunca se propaga el antiguo respaldo colineal.
        copia.EmpalmeInicioColinealSeguro = false;

        return copia;
    }


    private double CalcularLongitudBocetoCurvoMYG(
        IList<Curve> curvas)
    {
        if (curvas == null)
            return 0.0;

        double longitud =
            0.0;

        foreach (Curve curva in curvas)
        {
            if (curva == null ||
                !curva.IsBound)
            {
                continue;
            }

            try
            {
                longitud +=
                    Math.Max(
                        0.0,
                        curva.Length);
            }
            catch
            {
            }
        }

        return longitud;
    }

    // =========================================================
    // PROYECCIÓN RECTA DE LOS DESARROLLOS EXTERIORES
    // =========================================================
    // La longitud de desarrollo no toma la tangente de la ruta adaptada de
    // cada barra, porque esa ruta puede contener pequeñas correcciones contra
    // el sólido y producir direcciones distintas entre barras (efecto abanico).
    //
    // Todas las barras usan la dirección del eje real del primer o último tramo,
    // orientada en el sentido de la serie. De esta manera los desarrollos son
    // rectos, paralelos y continúan la proyección del tramo anfitrión.
    // =========================================================
    // PROYECCIÓN PURA DE LOS DESARROLLOS EXTERIORES
    // =========================================================
    // La longitud de desarrollo debe ser únicamente la prolongación recta de
    // la propia barra longitudinal en su extremo.
    //
    // No se usa primero la tangente de la LocationCurve del anfitrión porque
    // puede diferir de la tangente real de la ruta canónica/ajustada de la
    // barra. Esa diferencia obliga a Revit a insertar un doblez lateral.
    //
    // Prioridad:
    // 1. Tangente exacta de la ruta canónica de ESA barra.
    // 2. Dirección del último/primer segmento recto de la ruta.
    // 3. Tangente del eje del anfitrión solo como respaldo.
    // =========================================================
    // DIRECCIÓN COMÚN DE PROYECCIÓN DEL PRIMER / ÚLTIMO TRAMO
    // =========================================================
    // Todos los longitudinales del mismo extremo deben proyectarse con un
    // único vector común tomado del eje real del primer o último anfitrión.
    //
    // La dirección NO se obtiene de cada spline o ruta adaptada de la barra,
    // porque pequeñas diferencias entre esas curvas producen el efecto abanico.
    //
    // El punto de inicio sí permanece individual: cada desarrollo comienza en
    // el extremo real de su propia barra. Solamente se comparte la dirección.
    //
    // Para evitar que una LocationCurve orientada al revés mande los desarrollos
    // hacia el lado equivocado, el vector del eje se compara con el sentido real
    // del primer/último segmento del boceto y se invierte cuando corresponde.
    private XYZ ObtenerDireccionProyeccionExtremoSerieCurvaMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        IList<Curve> cuerpoReal,
        bool extremoInicial)
    {
        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0)
        {
            return null;
        }

        int indiceTramo =
            extremoInicial
                ? 0
                : serie.Tramos.Count - 1;

        TramoSerieCurvaLongitudinalMYG tramo =
            serie.Tramos[indiceTramo];

        if (tramo == null ||
            tramo.Eje == null ||
            !tramo.Eje.IsBound ||
            tramo.Eje.Length <= Tol)
        {
            return null;
        }

        XYZ direccionComun =
            ObtenerTangenteCurvaMYG(
                tramo.Eje,
                extremoInicial ? 0.0 : 1.0);

        if (direccionComun == null ||
            direccionComun.GetLength() <= Tol)
        {
            XYZ eje0 = tramo.Eje.GetEndPoint(0);
            XYZ eje1 = tramo.Eje.GetEndPoint(1);

            if (eje0 != null && eje1 != null)
                direccionComun = eje1 - eje0;
        }

        if (direccionComun == null ||
            direccionComun.GetLength() <= Tol)
        {
            return null;
        }

        direccionComun =
            direccionComun.Normalize();

        Curve curvaBorde = null;

        if (cuerpoReal != null &&
            cuerpoReal.Count > 0)
        {
            int indice =
                extremoInicial
                    ? 0
                    : cuerpoReal.Count - 1;

            int paso =
                extremoInicial
                    ? 1
                    : -1;

            while (indice >= 0 &&
                   indice < cuerpoReal.Count)
            {
                Curve candidata =
                    cuerpoReal[indice];

                if (candidata != null &&
                    candidata.IsBound &&
                    candidata.Length > Tol)
                {
                    curvaBorde = candidata;
                    break;
                }

                indice += paso;
            }
        }

        if (curvaBorde != null)
        {
            XYZ p0 = curvaBorde.GetEndPoint(0);
            XYZ p1 = curvaBorde.GetEndPoint(1);

            if (p0 != null && p1 != null)
            {
                XYZ sentidoReal = p1 - p0;

                if (sentidoReal.GetLength() > Tol &&
                    direccionComun.DotProduct(
                        sentidoReal.Normalize()) < 0.0)
                {
                    direccionComun =
                        direccionComun.Multiply(-1.0);
                }
            }
        }

        return direccionComun;
    }





    // =========================================================
    // DIRECCIÓN DEL TRAMO INMEDIATAMENTE ADYACENTE
    // =========================================================
    // Para el desarrollo exterior no se recalcula una tangente independiente
    // ni se usa el eje central del anfitrión. Se toma la dirección que ya lleva
    // el primer o último tramo del boceto real de ESA barra.
    //
    // Si el tramo es una línea, la prolongación es exactamente colineal.
    // Si es una curva adaptada, se usa una cuerda de hasta 50 cm próxima al
    // extremo para evitar que pequeñas oscilaciones locales produzcan abanicos.
    private XYZ ObtenerDireccionTramoInmediatoBocetoMYG(
        IList<Curve> curvas,
        bool extremoInicial)
    {
        if (curvas == null ||
            curvas.Count == 0)
        {
            return null;
        }

        int indice =
            extremoInicial
                ? 0
                : curvas.Count - 1;

        int paso =
            extremoInicial
                ? 1
                : -1;

        Curve curvaBorde = null;

        while (indice >= 0 &&
               indice < curvas.Count)
        {
            Curve candidata =
                curvas[indice];

            if (candidata != null &&
                candidata.IsBound &&
                candidata.Length > Tol)
            {
                curvaBorde = candidata;
                break;
            }

            indice += paso;
        }

        if (curvaBorde == null)
            return null;

        XYZ p0 =
            curvaBorde.GetEndPoint(0);

        XYZ p1 =
            curvaBorde.GetEndPoint(1);

        if (p0 == null || p1 == null)
            return null;

        // Caso principal: el tramo anterior ya es recto.
        if (curvaBorde is Line)
        {
            XYZ direccionLinea =
                p1 - p0;

            return direccionLinea.GetLength() > Tol
                ? direccionLinea.Normalize()
                : null;
        }

        // Curva o spline: se obtiene una dirección estable usando una cuerda
        // próxima al extremo, no la derivada puntual.
        double longitudReferencia =
            UnitUtils.ConvertToInternalUnits(
                50.0,
                UnitTypeId.Centimeters);

        double fraccion =
            curvaBorde.Length > Tol
                ? longitudReferencia /
                  curvaBorde.Length
                : 0.10;

        fraccion = Math.Max(
            0.02,
            Math.Min(0.25, fraccion));

        double parametroInterior =
            extremoInicial
                ? fraccion
                : 1.0 - fraccion;

        XYZ puntoInterior = null;

        try
        {
            puntoInterior =
                curvaBorde.Evaluate(
                    parametroInterior,
                    true);
        }
        catch
        {
            puntoInterior = null;
        }

        XYZ direccion = null;

        if (puntoInterior != null)
        {
            direccion =
                extremoInicial
                    ? puntoInterior - p0
                    : p1 - puntoInterior;
        }

        if (direccion == null ||
            direccion.GetLength() <= Tol)
        {
            direccion = p1 - p0;
        }

        return direccion != null &&
               direccion.GetLength() > Tol
            ? direccion.Normalize()
            : null;
    }


    // =========================================================
    // UTILIDADES DE PROYECCIÓN SIN CONVERGENCIA
    // =========================================================
    // Los extremos adaptados de una viga curva pueden converger debido a la
    // geometría del sólido, uniones o cuchillas. Para que el desarrollo no se
    // abra desde un punto común, se reemplaza una pequeña cola de la barra por
    // la proyección recta del tramo inmediatamente anterior.
    private XYZ ObtenerPuntoEnLongitudCadenaMYG(
        IList<Curve> curvas,
        double longitudObjetivo)
    {
        if (curvas == null || curvas.Count == 0)
            return null;

        double longitudTotal =
            CalcularLongitudBocetoCurvoMYG(curvas);

        if (longitudTotal <= Tol)
            return null;

        longitudObjetivo = Math.Max(
            0.0,
            Math.Min(longitudTotal, longitudObjetivo));

        double acumulado = 0.0;

        foreach (Curve curva in curvas)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            double siguiente =
                acumulado + curva.Length;

            if (longitudObjetivo <= siguiente + Tol)
            {
                double local =
                    longitudObjetivo - acumulado;

                double fraccion =
                    curva.Length > Tol
                        ? local / curva.Length
                        : 0.0;

                fraccion = Math.Max(
                    0.0,
                    Math.Min(1.0, fraccion));

                try
                {
                    return curva.Evaluate(
                        fraccion,
                        true);
                }
                catch
                {
                    return curva.GetEndPoint(
                        fraccion < 0.5 ? 0 : 1);
                }
            }

            acumulado = siguiente;
        }

        Curve ultima =
            curvas.LastOrDefault(
                c =>
                    c != null &&
                    c.IsBound &&
                    c.Length > Tol);

        return ultima != null
            ? ultima.GetEndPoint(1)
            : null;
    }

    private List<Curve> RecortarCadenaPorLongitudMYG(
        IList<Curve> curvas,
        double inicio,
        double fin)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (curvas == null ||
            curvas.Count == 0 ||
            fin <= inicio + Tol)
        {
            return resultado;
        }

        double longitudTotal =
            CalcularLongitudBocetoCurvoMYG(curvas);

        inicio = Math.Max(
            0.0,
            Math.Min(longitudTotal, inicio));

        fin = Math.Max(
            0.0,
            Math.Min(longitudTotal, fin));

        if (fin <= inicio + Tol)
            return resultado;

        double acumulado = 0.0;

        foreach (Curve curva in curvas)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            double curvaInicio =
                acumulado;

            double curvaFin =
                acumulado + curva.Length;

            double interInicio =
                Math.Max(inicio, curvaInicio);

            double interFin =
                Math.Min(fin, curvaFin);

            if (interFin > interInicio + Tol)
            {
                Curve subCurva =
                    CrearSubCurvaPorLongitudMYG(
                        curva,
                        curva.Length,
                        interInicio - curvaInicio,
                        interFin - curvaInicio);

                AgregarCurvaBocetoUnicoMYG(
                    resultado,
                    subCurva);
            }

            acumulado = curvaFin;

            if (acumulado >= fin - Tol)
                break;
        }

        return resultado;
    }

    // =========================================================
    // DIRECCIÓN ESTABLE DEL DESARROLLO DESDE EL TRAMO ANFITRIÓN
    // =========================================================
    // El problema de las barras que todavía se doblaban era que la dirección
    // se calculaba leyendo la propia cola adaptada de cada barra. En algunas
    // capas esa cola ya contenía una desviación producida por el sólido.
    //
    // Esta versión combina las dos condiciones necesarias:
    // 1. Cada barra conserva su propio punto lateral de arranque.
    // 2. Todas las barras del mismo extremo usan la tangente estable del eje
    //    real del primer/último tramo, evaluada antes de la zona distorsionada.
    //
    // También se elimina una cola suficiente de la ruta antes de proyectar,
    // de modo que la línea nueva no nazca después del doblez existente.
    private XYZ ObtenerDireccionEstableAntesDelExtremoMYG(
        IList<Curve> curvas,
        DatosSerieCurvaLongitudinalMYG serie,
        bool extremoInicial,
        out XYZ puntoArranque,
        out double longitudReemplazada)
    {
        puntoArranque = null;
        longitudReemplazada = 0.0;

        if (curvas == null ||
            curvas.Count == 0 ||
            serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0)
        {
            return null;
        }

        double longitudTotal =
            CalcularLongitudBocetoCurvoMYG(curvas);

        if (longitudTotal <= Tol)
            return null;

        TramoSerieCurvaLongitudinalMYG tramoExtremo =
            extremoInicial
                ? serie.Tramos[0]
                : serie.Tramos[serie.Tramos.Count - 1];

        Curve ejeReferencia =
            tramoExtremo != null
                ? tramoExtremo.Eje
                : null;

        double longitudEje =
            ejeReferencia != null &&
            ejeReferencia.IsBound
                ? ejeReferencia.Length
                : 0.0;

        double retiroMinimo =
            UnitUtils.ConvertToInternalUnits(
                40.0,
                UnitTypeId.Centimeters);

        double retiroMaximo =
            UnitUtils.ConvertToInternalUnits(
                80.0,
                UnitTypeId.Centimeters);

        double retiroObjetivo =
            longitudEje > Tol
                ? longitudEje * 0.12
                : retiroMinimo;

        retiroObjetivo =
            Math.Max(
                retiroMinimo,
                Math.Min(
                    retiroMaximo,
                    retiroObjetivo));

        double retiro =
            Math.Min(
                retiroObjetivo,
                longitudTotal * 0.45);

        double retiroAbsolutoMinimo =
            UnitUtils.ConvertToInternalUnits(
                10.0,
                UnitTypeId.Centimeters);

        if (retiro <= retiroAbsolutoMinimo)
            retiro = Math.Min(
                longitudTotal * 0.35,
                retiroAbsolutoMinimo);

        if (retiro <= Tol)
            return null;

        double estacionArranque =
            extremoInicial
                ? retiro
                : longitudTotal - retiro;

        XYZ pArranque =
            ObtenerPuntoEnLongitudCadenaMYG(
                curvas,
                estacionArranque);

        if (pArranque == null)
            return null;

        // Sentido local real de la barra, usado únicamente para orientar
        // correctamente el vector común del anfitrión.
        double longitudReferenciaLocal =
            Math.Min(
                UnitUtils.ConvertToInternalUnits(
                    20.0,
                    UnitTypeId.Centimeters),
                Math.Max(
                    UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Centimeters),
                    retiro * 0.40));

        double estacionLocal =
            extremoInicial
                ? Math.Min(
                    longitudTotal,
                    estacionArranque +
                    longitudReferenciaLocal)
                : Math.Max(
                    0.0,
                    estacionArranque -
                    longitudReferenciaLocal);

        XYZ pLocal =
            ObtenerPuntoEnLongitudCadenaMYG(
                curvas,
                estacionLocal);

        XYZ sentidoLocal = null;

        if (pLocal != null)
        {
            sentidoLocal =
                extremoInicial
                    ? pLocal - pArranque
                    : pArranque - pLocal;
        }

        XYZ direccion = null;

        if (ejeReferencia != null &&
            ejeReferencia.IsBound &&
            longitudEje > Tol)
        {
            double fraccionRetiro =
                retiro / longitudEje;

            fraccionRetiro =
                Math.Max(
                    0.02,
                    Math.Min(
                        0.35,
                        fraccionRetiro));

            double parametro =
                extremoInicial
                    ? fraccionRetiro
                    : 1.0 - fraccionRetiro;

            direccion =
                ObtenerTangenteCurvaMYG(
                    ejeReferencia,
                    parametro);

            if ((direccion == null ||
                 direccion.GetLength() <= Tol))
            {
                XYZ eje0 =
                    ejeReferencia.GetEndPoint(0);

                XYZ eje1 =
                    ejeReferencia.GetEndPoint(1);

                if (eje0 != null && eje1 != null)
                    direccion = eje1 - eje0;
            }
        }

        // Respaldo: si el eje no entrega una dirección válida, se usa el tramo
        // local de la propia barra, pero nunca su cola final deformada.
        if ((direccion == null ||
             direccion.GetLength() <= Tol) &&
            sentidoLocal != null &&
            sentidoLocal.GetLength() > Tol)
        {
            direccion = sentidoLocal;
        }

        if (direccion == null ||
            direccion.GetLength() <= Tol)
        {
            return null;
        }

        direccion =
            direccion.Normalize();

        if (sentidoLocal != null &&
            sentidoLocal.GetLength() > Tol &&
            direccion.DotProduct(
                sentidoLocal.Normalize()) < 0.0)
        {
            direccion =
                direccion.Multiply(-1.0);
        }

        puntoArranque = pArranque;
        longitudReemplazada = retiro;

        return direccion;
    }



    private IList<Curve> ConstruirBocetoBasePiezaComercialCurvaMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        List<Curve> rutasCanonicasPorTramo,
        SegmentoAceroLongitudinal pieza)
    {
        List<Curve> resultado = new List<Curve>();

        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            rutasCanonicasPorTramo == null ||
            rutasCanonicasPorTramo.Count != serie.Tramos.Count ||
            pieza == null ||
            pieza.XFin <= pieza.XInicio + Tol)
        {
            return resultado;
        }

        // Primero se construye únicamente el recorrido real de la pieza.
        for (int iTramo = 0;
             iTramo < serie.Tramos.Count;
             iTramo++)
        {
            TramoSerieCurvaLongitudinalMYG tramo =
                serie.Tramos[iTramo];

            Curve ruta =
                rutasCanonicasPorTramo[iTramo];

            if (tramo == null ||
                ruta == null ||
                !ruta.IsBound ||
                ruta.Length <= Tol ||
                tramo.Longitud <= Tol)
            {
                continue;
            }

            // Vacío anterior al tramo.
            if (iTramo > 0)
            {
                TramoSerieCurvaLongitudinalMYG anterior =
                    serie.Tramos[iTramo - 1];

                Curve rutaAnterior =
                    rutasCanonicasPorTramo[iTramo - 1];

                if (anterior != null &&
                    rutaAnterior != null &&
                    rutaAnterior.IsBound &&
                    rutaAnterior.Length > Tol)
                {
                    double huecoInicio =
                        anterior.FinSerie;

                    double huecoFin =
                        tramo.InicioSerie;

                    double longitudHueco =
                        huecoFin - huecoInicio;

                    double globalHueco0 =
                        Math.Max(
                            pieza.XInicio,
                            huecoInicio);

                    double globalHueco1 =
                        Math.Min(
                            pieza.XFin,
                            huecoFin);

                    if (longitudHueco > Tol &&
                        globalHueco1 >
                        globalHueco0 + Tol)
                    {
                        Curve conectorCompleto =
                            CrearConectorRectoOrdenadoMYG(
                                rutaAnterior,
                                ruta);

                        if (conectorCompleto == null ||
                            !conectorCompleto.IsBound ||
                            conectorCompleto.Length <= Tol)
                        {
                            XYZ a =
                                rutaAnterior.GetEndPoint(1);

                            XYZ b =
                                ruta.GetEndPoint(0);

                            if (a != null &&
                                b != null &&
                                a.DistanceTo(b) > Tol)
                            {
                                try
                                {
                                    conectorCompleto =
                                        Line.CreateBound(a, b);
                                }
                                catch
                                {
                                    conectorCompleto = null;
                                }
                            }
                        }

                        if (conectorCompleto != null &&
                            conectorCompleto.IsBound &&
                            conectorCompleto.Length > Tol)
                        {
                            double factor0 =
                                (globalHueco0 - huecoInicio) /
                                longitudHueco;

                            double factor1 =
                                (globalHueco1 - huecoInicio) /
                                longitudHueco;

                            factor0 = Math.Max(
                                0.0,
                                Math.Min(1.0, factor0));

                            factor1 = Math.Max(
                                0.0,
                                Math.Min(1.0, factor1));

                            Curve conectorParcial =
                                CrearSubCurvaPorLongitudMYG(
                                    conectorCompleto,
                                    conectorCompleto.Length,
                                    conectorCompleto.Length * factor0,
                                    conectorCompleto.Length * factor1);

                            AgregarCurvaBocetoUnicoMYG(
                                resultado,
                                conectorParcial);
                        }
                    }
                }
            }

            // Parte de la pieza dentro del anfitrión.
            double global0 =
                Math.Max(
                    pieza.XInicio,
                    tramo.InicioSerie);

            double global1 =
                Math.Min(
                    pieza.XFin,
                    tramo.FinSerie);

            if (global1 <= global0 + Tol)
                continue;

            double factorTramo0 =
                (global0 - tramo.InicioSerie) /
                tramo.Longitud;

            double factorTramo1 =
                (global1 - tramo.InicioSerie) /
                tramo.Longitud;

            factorTramo0 = Math.Max(
                0.0,
                Math.Min(1.0, factorTramo0));

            factorTramo1 = Math.Max(
                0.0,
                Math.Min(1.0, factorTramo1));

            Curve subRuta =
                CrearSubCurvaPorLongitudMYG(
                    ruta,
                    ruta.Length,
                    ruta.Length * factorTramo0,
                    ruta.Length * factorTramo1);

            AgregarCurvaBocetoUnicoMYG(
                resultado,
                subRuta);
        }

        IList<Curve> cuerpo =
            LimpiarCurvasCadenaMYG(resultado);

        if (cuerpo == null ||
            cuerpo.Count == 0)
        {
            return new List<Curve>();
        }

        // =========================================================
        // DESARROLLO EXTERIOR INICIAL SIN CONVERGENCIA
        // =========================================================
        if (pieza.XInicio < 0.0)
        {
            double longitudExterior =
                Math.Min(0.0, pieza.XFin) -
                pieza.XInicio;

            if (longitudExterior > Tol)
            {
                XYZ puntoArranque;
                double longitudReemplazada;

                XYZ direccion =
                    ObtenerDireccionEstableAntesDelExtremoMYG(
                        cuerpo,
                        serie,
                        true,
                        out puntoArranque,
                        out longitudReemplazada);

                if (direccion != null &&
                    direccion.GetLength() > Tol &&
                    puntoArranque != null)
                {
                    double longitudCuerpo =
                        CalcularLongitudBocetoCurvoMYG(
                            cuerpo);

                    List<Curve> cuerpoRecortado =
                        RecortarCadenaPorLongitudMYG(
                            cuerpo,
                            longitudReemplazada,
                            longitudCuerpo);

                    XYZ inicio =
                        puntoArranque.Subtract(
                            direccion.Multiply(
                                longitudReemplazada +
                                longitudExterior));

                    Line proyeccion =
                        Line.CreateBound(
                            inicio,
                            puntoArranque);

                    List<Curve> reconstruido =
                        new List<Curve>();

                    AgregarCurvaBocetoUnicoMYG(
                        reconstruido,
                        proyeccion);

                    foreach (Curve curva
                        in cuerpoRecortado)
                    {
                        AgregarCurvaBocetoUnicoMYG(
                            reconstruido,
                            curva);
                    }

                    cuerpo = reconstruido;
                }
            }
        }

        // =========================================================
        // DESARROLLO EXTERIOR FINAL SIN CONVERGENCIA
        // =========================================================
        if (pieza.XFin > serie.LongitudTotal)
        {
            double longitudExterior =
                pieza.XFin -
                Math.Max(
                    serie.LongitudTotal,
                    pieza.XInicio);

            if (longitudExterior > Tol)
            {
                XYZ puntoArranque;
                double longitudReemplazada;

                XYZ direccion =
                    ObtenerDireccionEstableAntesDelExtremoMYG(
                        cuerpo,
                        serie,
                        false,
                        out puntoArranque,
                        out longitudReemplazada);

                if (direccion != null &&
                    direccion.GetLength() > Tol &&
                    puntoArranque != null)
                {
                    double longitudCuerpo =
                        CalcularLongitudBocetoCurvoMYG(
                            cuerpo);

                    double finRecorte =
                        Math.Max(
                            0.0,
                            longitudCuerpo -
                            longitudReemplazada);

                    List<Curve> cuerpoRecortado =
                        RecortarCadenaPorLongitudMYG(
                            cuerpo,
                            0.0,
                            finRecorte);

                    XYZ fin =
                        puntoArranque.Add(
                            direccion.Multiply(
                                longitudReemplazada +
                                longitudExterior));

                    Line proyeccion =
                        Line.CreateBound(
                            puntoArranque,
                            fin);

                    List<Curve> reconstruido =
                        new List<Curve>();

                    foreach (Curve curva
                        in cuerpoRecortado)
                    {
                        AgregarCurvaBocetoUnicoMYG(
                            reconstruido,
                            curva);
                    }

                    AgregarCurvaBocetoUnicoMYG(
                        reconstruido,
                        proyeccion);

                    cuerpo = reconstruido;
                }
            }
        }

        IList<Curve> limpias =
            LimpiarCurvasCadenaMYG(cuerpo);

        return limpias ?? new List<Curve>();
    }



    private void AgregarCurvaBocetoUnicoMYG(
        List<Curve> destino,
        Curve curva)
    {
        if (destino == null ||
            curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return;
        }

        Curve actual = curva;

        if (destino.Count > 0)
        {
            Curve anterior = destino[destino.Count - 1];

            if (anterior != null &&
                anterior.IsBound &&
                anterior.Length > Tol)
            {
                XYZ finAnterior = anterior.GetEndPoint(1);
                XYZ inicioActual = actual.GetEndPoint(0);
                XYZ finActual = actual.GetEndPoint(1);

                if (finAnterior != null &&
                    inicioActual != null &&
                    finActual != null &&
                    finAnterior.DistanceTo(finActual) <
                    finAnterior.DistanceTo(inicioActual))
                {
                    try
                    {
                        actual = actual.CreateReversed();
                        inicioActual = actual.GetEndPoint(0);
                    }
                    catch
                    {
                    }
                }

                if (finAnterior != null &&
                    inicioActual != null)
                {
                    double distancia =
                        finAnterior.DistanceTo(inicioActual);

                    double tolerancia =
                        UnitUtils.ConvertToInternalUnits(
                            0.05,
                            UnitTypeId.Centimeters);

                    if (distancia > tolerancia)
                    {
                        try
                        {
                            destino.Add(
                                Line.CreateBound(
                                    finAnterior,
                                    inicioActual));
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        destino.Add(actual);
    }


    private Element ObtenerHostPrincipalPiezaComercialCurvaMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        SegmentoAceroLongitudinal pieza)
    {
        if (serie == null ||
            serie.Tramos == null ||
            pieza == null)
        {
            return serie != null
                ? serie.HostPrincipal
                : null;
        }

        Element mejorHost = null;
        double mayorLongitud = -1.0;

        foreach (TramoSerieCurvaLongitudinalMYG tramo
            in serie.Tramos)
        {
            if (tramo == null ||
                tramo.Host == null)
            {
                continue;
            }

            double coincidencia = Math.Max(
                0.0,
                Math.Min(
                    pieza.XFin,
                    tramo.FinSerie) -
                Math.Max(
                    pieza.XInicio,
                    tramo.InicioSerie));

            if (coincidencia > mayorLongitud + Tol)
            {
                mayorLongitud = coincidencia;
                mejorHost = tramo.Host;
            }
        }

        return mejorHost ?? serie.HostPrincipal;
    }


    // =========================================================
    // RUTA CANÓNICA ÚNICA POR TRAMO Y BARRA LÓGICA
    // =========================================================
    private List<Curve> ConstruirRutasCanonicasPorTramoBarraMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (serie == null ||
            serie.Tramos == null)
        {
            return resultado;
        }

        Curve anteriorElegida = null;

        foreach (TramoSerieCurvaLongitudinalMYG tramo
            in serie.Tramos)
        {
            if (tramo == null ||
                tramo.Eje == null ||
                tramo.Longitud <= Tol)
            {
                resultado.Add(null);
                anteriorElegida = null;
                continue;
            }

            List<Curve> candidatas =
                new List<Curve>();

            Curve offset =
                CrearCurvaOffsetTramoSerieMYG(
                    tramo,
                    cantidad,
                    indiceBarra,
                    diametro,
                    offsetVerticalDesdeCara,
                    superior,
                    central);

            offset =
                OrientarCurvaSegunEjeTramoMYG(
                    tramo,
                    offset);

            if (offset != null &&
                offset.IsBound &&
                offset.Length > Tol)
            {
                candidatas.Add(offset);
            }

            Curve adaptada =
                CrearTrayectoriaLongitudinalAdaptadaAlSolidoMYG(
                    tramo,
                    cantidad,
                    indiceBarra,
                    diametro,
                    offsetVerticalDesdeCara,
                    superior,
                    central);

            adaptada =
                OrientarCurvaSegunEjeTramoMYG(
                    tramo,
                    adaptada);

            if (adaptada != null &&
                adaptada.IsBound &&
                adaptada.Length > Tol)
            {
                bool duplicada =
                    candidatas.Any(c =>
                        c != null &&
                        c.GetEndPoint(0).DistanceTo(
                            adaptada.GetEndPoint(0)) <=
                        UnitUtils.ConvertToInternalUnits(
                            0.2,
                            UnitTypeId.Centimeters) &&
                        c.GetEndPoint(1).DistanceTo(
                            adaptada.GetEndPoint(1)) <=
                        UnitUtils.ConvertToInternalUnits(
                            0.2,
                            UnitTypeId.Centimeters));

                if (!duplicada)
                    candidatas.Add(adaptada);
            }

            Curve elegida = null;
            double mejorCobertura = double.MinValue;
            double menorCostoContinuidad = double.MaxValue;

            foreach (Curve candidata in candidatas)
            {
                if (candidata == null)
                    continue;

                double cobertura =
                    CalcularCoberturaCurvaEnSolidoTramoMYG(
                        tramo,
                        candidata);

                double costoContinuidad = 0.0;

                if (anteriorElegida != null)
                {
                    XYZ finAnterior =
                        anteriorElegida.GetEndPoint(1);

                    XYZ inicioActual =
                        candidata.GetEndPoint(0);

                    if (finAnterior != null &&
                        inicioActual != null)
                    {
                        costoContinuidad =
                            finAnterior.DistanceTo(
                                inicioActual);
                    }
                }

                bool mejoraCobertura =
                    cobertura >
                    mejorCobertura + 1e-6;

                bool empateCobertura =
                    Math.Abs(
                        cobertura -
                        mejorCobertura) <= 1e-6;

                if (mejoraCobertura ||
                    (empateCobertura &&
                     costoContinuidad <
                     menorCostoContinuidad - Tol))
                {
                    elegida = candidata;
                    mejorCobertura = cobertura;
                    menorCostoContinuidad = costoContinuidad;
                }
            }

            if (elegida == null &&
                candidatas.Count > 0)
            {
                elegida = candidatas[0];
            }

            resultado.Add(elegida);

            if (elegida != null)
                anteriorElegida = elegida;
        }

        return resultado;
    }

    private double CalcularCoberturaCurvaEnSolidoTramoMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        Curve curva)
    {
        if (tramo == null ||
            curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return 0.0;
        }

        List<Curve> dentro =
            ObtenerCurvasDentroDelSolidoTramoMYG(
                tramo,
                curva);

        if (dentro == null ||
            dentro.Count == 0)
        {
            return 0.0;
        }

        double longitudDentro =
            dentro
                .Where(c =>
                    c != null &&
                    c.IsBound &&
                    c.Length > Tol)
                .Sum(c => c.Length);

        if (longitudDentro <= Tol)
            return 0.0;

        return longitudDentro /
               Math.Max(curva.Length, Tol);
    }

    private Curve OrientarCurvaSegunEjeTramoMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        Curve curva)
    {
        if (tramo == null ||
            tramo.Eje == null ||
            curva == null ||
            !curva.IsBound)
        {
            return curva;
        }

        XYZ ejeInicio =
            tramo.Eje.GetEndPoint(0);

        XYZ ejeFin =
            tramo.Eje.GetEndPoint(1);

        XYZ curvaInicio =
            curva.GetEndPoint(0);

        XYZ curvaFin =
            curva.GetEndPoint(1);

        if (ejeInicio == null ||
            ejeFin == null ||
            curvaInicio == null ||
            curvaFin == null)
        {
            return curva;
        }

        double costoMismo =
            curvaInicio.DistanceTo(ejeInicio) +
            curvaFin.DistanceTo(ejeFin);

        double costoInvertido =
            curvaFin.DistanceTo(ejeInicio) +
            curvaInicio.DistanceTo(ejeFin);

        if (costoInvertido + Tol <
            costoMismo)
        {
            try
            {
                return curva.CreateReversed();
            }
            catch
            {
                return curva;
            }
        }

        return curva;
    }

    private Curve OrientarCurvaSegunReferenciaMYG(
        Curve referencia,
        Curve curva)
    {
        if (referencia == null ||
            curva == null ||
            !referencia.IsBound ||
            !curva.IsBound)
        {
            return curva;
        }

        double p0 =
            ObtenerParametroNormalizadoSobreCurvaMYG(
                referencia,
                curva.GetEndPoint(0));

        double p1 =
            ObtenerParametroNormalizadoSobreCurvaMYG(
                referencia,
                curva.GetEndPoint(1));

        if (p1 < p0)
        {
            try
            {
                return curva.CreateReversed();
            }
            catch
            {
                return curva;
            }
        }

        return curva;
    }


    private int CrearLongitudinalPrincipalEnTramoMYG(
        Document doc,
        TramoSerieCurvaLongitudinalMYG tramo,
        SegmentoAceroLongitudinal segmento,
        ResultadoTramoBarraCurvaMYG resultado,
        Curve rutaCanonicaTramo,
        RebarBarType tipoBarra,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central,
        string tipoElementoTexto)
    {
        if (doc == null ||
            tramo == null ||
            segmento == null ||
            resultado == null ||
            tramo.Host == null ||
            tramo.Eje == null ||
            tramo.Longitud <= Tol ||
            tipoBarra == null)
        {
            return 0;
        }

        double global0 = Math.Max(
            segmento.XInicio,
            tramo.InicioSerie);

        double global1 = Math.Min(
            segmento.XFin,
            tramo.FinSerie);

        if (global1 <= global0 + Tol)
            return 0;

        resultado.RequeridoPorSegmento = true;
        resultado.GlobalInicio = global0;
        resultado.GlobalFin = global1;

        double local0 = global0 - tramo.InicioSerie;
        double local1 = global1 - tramo.InicioSerie;

        // Todas las piezas de esta barra lógica utilizan exactamente la misma
        // trayectoria completa del anfitrión. Solo cambia el intervalo recortado.
        Curve candidataCompleta =
            OrientarCurvaSegunEjeTramoMYG(
                tramo,
                rutaCanonicaTramo);

        if (candidataCompleta == null ||
            !candidataCompleta.IsBound ||
            candidataCompleta.Length <= Tol)
        {
            RegistrarErrorCurvaMYG(
                "Host " +
                tramo.Host.Id.Value.ToString() +
                ": no existe una ruta canónica válida para el longitudinal.");

            return 0;
        }

        Curve subCurvaTeorica =
            CrearSubCurvaPorLongitudMYG(
                candidataCompleta,
                tramo.Longitud,
                local0,
                local1);

        if (subCurvaTeorica == null ||
            !subCurvaTeorica.IsBound ||
            subCurvaTeorica.Length <= Tol)
        {
            RegistrarErrorCurvaMYG(
                "Host " +
                tramo.Host.Id.Value.ToString() +
                ": no se pudo recortar la ruta canónica entre " +
                UnitUtils.ConvertFromInternalUnits(
                    global0,
                    UnitTypeId.Meters).ToString("0.###") +
                " m y " +
                UnitUtils.ConvertFromInternalUnits(
                    global1,
                    UnitTypeId.Meters).ToString("0.###") +
                " m.");

            return 0;
        }

        List<Curve> curvasDentro =
            ObtenerCurvasDentroDelSolidoTramoMYG(
                tramo,
                subCurvaTeorica);

        if (curvasDentro == null ||
            curvasDentro.Count == 0)
        {
            RegistrarErrorCurvaMYG(
                "Host " +
                tramo.Host.Id.Value.ToString() +
                ": la ruta canónica no intersectó el sólido real del tramo.");

            return 0;
        }

        List<Rebar> temporales =
            new List<Rebar>();

        List<Curve> curvasCreadas =
            new List<Curve>();

        bool completa = true;

        foreach (Curve curvaDentro in curvasDentro)
        {
            if (curvaDentro == null ||
                !curvaDentro.IsBound ||
                curvaDentro.Length <= Tol)
            {
                completa = false;
                break;
            }

            Curve curvaOrientada =
                OrientarCurvaSegunReferenciaMYG(
                    subCurvaTeorica,
                    curvaDentro);

            if (curvaOrientada == null)
                curvaOrientada = curvaDentro;

            Curve curvaReal;

            Rebar rb =
                CrearRebarTramoCurvoRobustoMYG(
                    doc,
                    tramo.Host,
                    tipoBarra,
                    ObtenerNormalParaCurvaSimpleMYG(
                        curvaOrientada,
                        tramo.EjeZ),
                    curvaOrientada,
                    tipoElementoTexto,
                    out curvaReal);

            if (rb == null)
            {
                completa = false;
                break;
            }

            temporales.Add(rb);

            curvasCreadas.Add(
                curvaReal ??
                curvaOrientada);
        }

        if (!completa ||
            temporales.Count == 0)
        {
            foreach (Rebar temporal in temporales)
            {
                if (temporal == null)
                    continue;

                try
                {
                    doc.Delete(temporal.Id);
                }
                catch
                {
                }
            }

            RegistrarErrorCurvaMYG(
                "Host " +
                tramo.Host.Id.Value.ToString() +
                ": Revit no pudo crear todas las partes de la ruta canónica.");

            return 0;
        }

        resultado.CurvaCompletaTeorica =
            candidataCompleta;

        resultado.SubCurvaTeorica =
            subCurvaTeorica;

        resultado.CurvasDentroDelHost =
            curvasDentro;

        resultado.CurvasConRebar =
            OrdenarCurvasCreadasSegunReferenciaMYG(
                subCurvaTeorica,
                curvasCreadas);

        resultado.Creado =
            resultado.CurvasConRebar != null &&
            resultado.CurvasConRebar.Count > 0;

        return resultado.Creado
            ? temporales.Count
            : 0;
    }

    private List<Curve> OrdenarCurvasCreadasSegunReferenciaMYG(
        Curve referencia,
        List<Curve> curvas)
    {
        if (curvas == null)
            return new List<Curve>();

        if (referencia == null)
        {
            return curvas
                .Where(c => c != null && c.IsBound && c.Length > Tol)
                .ToList();
        }

        List<Curve> orientadas = new List<Curve>();

        foreach (Curve curva in curvas)
        {
            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                continue;
            }

            Curve actual = curva;

            double p0 = ObtenerParametroNormalizadoSobreCurvaMYG(
                referencia,
                curva.GetEndPoint(0));

            double p1 = ObtenerParametroNormalizadoSobreCurvaMYG(
                referencia,
                curva.GetEndPoint(1));

            if (p1 < p0)
            {
                try
                {
                    actual = curva.CreateReversed();
                }
                catch
                {
                    actual = curva;
                }
            }

            orientadas.Add(actual);
        }

        return orientadas
            .OrderBy(c =>
                ObtenerParametroNormalizadoSobreCurvaMYG(
                    referencia,
                    c.Evaluate(0.5, true)))
            .ToList();
    }

    private int CrearUnionesInternasResultadoTramoMYG(
        Document doc,
        ResultadoTramoBarraCurvaMYG resultado,
        RebarBarType tipoBarra,
        string tipoElementoTexto)
    {
        if (doc == null ||
            resultado == null ||
            resultado.Tramo == null ||
            resultado.Tramo.Host == null ||
            tipoBarra == null ||
            resultado.CurvasConRebar == null ||
            resultado.CurvasConRebar.Count < 2)
        {
            return 0;
        }

        int creadas = 0;

        for (int i = 0;
             i < resultado.CurvasConRebar.Count - 1;
             i++)
        {
            Curve anterior = resultado.CurvasConRebar[i];
            Curve siguiente = resultado.CurvasConRebar[i + 1];

            if (anterior == null || siguiente == null)
                continue;

            XYZ a = anterior.GetEndPoint(1);
            XYZ b = siguiente.GetEndPoint(0);

            if (a == null || b == null)
                continue;

            double tolerancia = UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

            if (a.DistanceTo(b) <= tolerancia)
                continue;

            Curve conector = CrearConectorSuaveEntreTramosMYG(
                anterior,
                siguiente);

            if (conector == null || conector.Length <= Tol)
            {
                try
                {
                    conector = Line.CreateBound(a, b);
                }
                catch
                {
                    conector = null;
                }
            }

            if (conector == null || conector.Length <= Tol)
                continue;

            Curve curvaReal;
            Rebar rb = CrearRebarTramoCurvoRobustoMYG(
                doc,
                resultado.Tramo.Host,
                tipoBarra,
                ObtenerNormalParaCurvaSimpleMYG(
                    conector,
                    resultado.Tramo.EjeZ),
                conector,
                tipoElementoTexto,
                out curvaReal);

            if (rb != null)
                creadas++;
        }

        return creadas;
    }

    private Curve ObtenerCurvaCanonicaLimiteHuecoMYG(
        List<ResultadoPiezaBarraCurvaMYG> planes,
        int indiceTramo,
        bool usarFinal)
    {
        if (planes == null || indiceTramo < 0)
            return null;

        List<ResultadoTramoBarraCurvaMYG> candidatas = planes
            .Where(p =>
                p != null &&
                p.ResultadosTramo != null &&
                indiceTramo < p.ResultadosTramo.Count)
            .Select(p => p.ResultadosTramo[indiceTramo])
            .Where(r =>
                r != null &&
                r.Creado &&
                r.CurvasConRebar != null &&
                r.CurvasConRebar.Count > 0)
            .ToList();

        if (candidatas.Count == 0)
            return null;

        ResultadoTramoBarraCurvaMYG elegida = usarFinal
            ? candidatas
                .OrderByDescending(r => r.GlobalFin)
                .ThenByDescending(r => r.GlobalInicio)
                .FirstOrDefault()
            : candidatas
                .OrderBy(r => r.GlobalInicio)
                .ThenBy(r => r.GlobalFin)
                .FirstOrDefault();

        if (elegida == null)
            return null;

        return usarFinal
            ? elegida.UltimaCurvaCreada
            : elegida.PrimeraCurvaCreada;
    }

    private Rebar CrearConectorLongitudinalEntreHostsMYG(
        Document doc,
        Element hostPrimario,
        Element hostSecundario,
        RebarBarType tipoBarra,
        Curve conector,
        XYZ normalPreferida,
        string tipoElementoTexto)
    {
        if (doc == null ||
            tipoBarra == null ||
            conector == null ||
            !conector.IsBound ||
            conector.Length <= Tol)
        {
            return null;
        }

        XYZ normal = ObtenerNormalParaCurvaSimpleMYG(
            conector,
            normalPreferida);

        Rebar rb = null;

        if (hostPrimario != null)
        {
            rb = CrearRebarCurvoCadenaConParametrosMYG(
                doc,
                hostPrimario,
                tipoBarra,
                normal,
                new List<Curve>() { conector },
                tipoElementoTexto);
        }

        if (rb == null &&
            hostSecundario != null &&
            (hostPrimario == null ||
             hostSecundario.Id.Value != hostPrimario.Id.Value))
        {
            rb = CrearRebarCurvoCadenaConParametrosMYG(
                doc,
                hostSecundario,
                tipoBarra,
                normal,
                new List<Curve>() { conector },
                tipoElementoTexto);
        }

        if (rb != null)
            return rb;

        XYZ a = conector.GetEndPoint(0);
        XYZ b = conector.GetEndPoint(1);

        if (a == null || b == null || a.DistanceTo(b) <= Tol)
            return null;

        Line linea = null;

        try
        {
            linea = Line.CreateBound(a, b);
        }
        catch
        {
            linea = null;
        }

        if (linea == null)
            return null;

        Curve curvaReal;

        if (hostPrimario != null)
        {
            rb = CrearRebarTramoCurvoRobustoMYG(
                doc,
                hostPrimario,
                tipoBarra,
                ObtenerNormalParaCurvaSimpleMYG(
                    linea,
                    normalPreferida),
                linea,
                tipoElementoTexto,
                out curvaReal);
        }

        if (rb == null &&
            hostSecundario != null &&
            (hostPrimario == null ||
             hostSecundario.Id.Value != hostPrimario.Id.Value))
        {
            rb = CrearRebarTramoCurvoRobustoMYG(
                doc,
                hostSecundario,
                tipoBarra,
                ObtenerNormalParaCurvaSimpleMYG(
                    linea,
                    normalPreferida),
                linea,
                tipoElementoTexto,
                out curvaReal);
        }

        return rb;
    }

    private int CrearDesarrollosExterioresPiezaCurvaMYG(
        Document doc,
        DatosSerieCurvaLongitudinalMYG serie,
        ResultadoPiezaBarraCurvaMYG plan,
        RebarBarType tipoBarra,
        string tipoElementoTexto)
    {
        if (doc == null ||
            serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            plan == null ||
            plan.Segmento == null ||
            plan.ResultadosTramo == null ||
            tipoBarra == null)
        {
            return 0;
        }

        int creadas = 0;

        if (plan.Segmento.XInicio < 0.0)
        {
            ResultadoTramoBarraCurvaMYG primero =
                plan.ResultadosTramo.FirstOrDefault(r =>
                    r != null &&
                    r.Creado &&
                    r.PrimeraCurvaCreada != null);

            if (primero != null && primero.Tramo != null)
            {
                Curve curva = primero.PrimeraCurvaCreada;
                XYZ p = curva.GetEndPoint(0);
                // Prolongación pura de la barra realmente creada.
                // El eje del anfitrión se usa únicamente como respaldo.
                XYZ tangente =
                    ObtenerTangenteCurvaMYG(
                        curva,
                        0.0);

                if ((tangente == null ||
                     tangente.GetLength() <= Tol) &&
                    primero.Tramo.Eje != null)
                {
                    tangente =
                        ObtenerTangenteCurvaMYG(
                            primero.Tramo.Eje,
                            0.0);
                }

                if (tangente != null &&
                    tangente.GetLength() > Tol)
                {
                    XYZ sentidoCurva =
                        curva.GetEndPoint(1) -
                        curva.GetEndPoint(0);

                    if (sentidoCurva.GetLength() > Tol &&
                        tangente.Normalize().DotProduct(
                            sentidoCurva.Normalize()) < 0.0)
                    {
                        tangente =
                            tangente.Multiply(-1.0);
                    }
                }

                double ext0 = plan.Segmento.XInicio;
                double ext1 = Math.Min(0.0, plan.Segmento.XFin);

                if (p != null &&
                    tangente != null &&
                    tangente.GetLength() > Tol &&
                    ext1 > ext0 + Tol)
                {
                    tangente = tangente.Normalize();

                    XYZ a = p.Add(tangente.Multiply(ext0));
                    XYZ b = p.Add(tangente.Multiply(ext1));

                    if (a.DistanceTo(b) > Tol)
                    {
                        Curve curvaReal;
                        Rebar rb = CrearRebarTramoCurvoRobustoMYG(
                            doc,
                            primero.Tramo.Host,
                            tipoBarra,
                            ObtenerNormalParaCurvaSimpleMYG(
                                Line.CreateBound(a, b),
                                primero.Tramo.EjeZ),
                            Line.CreateBound(a, b),
                            tipoElementoTexto,
                            out curvaReal);

                        if (rb != null)
                            creadas++;
                    }
                }
            }
        }

        if (plan.Segmento.XFin > serie.LongitudTotal)
        {
            ResultadoTramoBarraCurvaMYG ultimo =
                plan.ResultadosTramo.LastOrDefault(r =>
                    r != null &&
                    r.Creado &&
                    r.UltimaCurvaCreada != null);

            if (ultimo != null && ultimo.Tramo != null)
            {
                Curve curva = ultimo.UltimaCurvaCreada;
                XYZ p = curva.GetEndPoint(1);
                // Prolongación pura de la barra realmente creada.
                // El eje del anfitrión se usa únicamente como respaldo.
                XYZ tangente =
                    ObtenerTangenteCurvaMYG(
                        curva,
                        1.0);

                if ((tangente == null ||
                     tangente.GetLength() <= Tol) &&
                    ultimo.Tramo.Eje != null)
                {
                    tangente =
                        ObtenerTangenteCurvaMYG(
                            ultimo.Tramo.Eje,
                            1.0);
                }

                if (tangente != null &&
                    tangente.GetLength() > Tol)
                {
                    XYZ sentidoCurva =
                        curva.GetEndPoint(1) -
                        curva.GetEndPoint(0);

                    if (sentidoCurva.GetLength() > Tol &&
                        tangente.Normalize().DotProduct(
                            sentidoCurva.Normalize()) < 0.0)
                    {
                        tangente =
                            tangente.Multiply(-1.0);
                    }
                }

                double ext0 = Math.Max(
                    serie.LongitudTotal,
                    plan.Segmento.XInicio) -
                    serie.LongitudTotal;

                double ext1 =
                    plan.Segmento.XFin -
                    serie.LongitudTotal;

                if (p != null &&
                    tangente != null &&
                    tangente.GetLength() > Tol &&
                    ext1 > ext0 + Tol)
                {
                    tangente = tangente.Normalize();

                    XYZ a = p.Add(tangente.Multiply(ext0));
                    XYZ b = p.Add(tangente.Multiply(ext1));

                    if (a.DistanceTo(b) > Tol)
                    {
                        Line linea = Line.CreateBound(a, b);
                        Curve curvaReal;
                        Rebar rb = CrearRebarTramoCurvoRobustoMYG(
                            doc,
                            ultimo.Tramo.Host,
                            tipoBarra,
                            ObtenerNormalParaCurvaSimpleMYG(
                                linea,
                                ultimo.Tramo.EjeZ),
                            linea,
                            tipoElementoTexto,
                            out curvaReal);

                        if (rb != null)
                            creadas++;
                    }
                }
            }
        }

        return creadas;
    }



    // =========================================================
    // TRAYECTORIA LONGITUDINAL ADAPTADA AL SÓLIDO REAL
    // =========================================================
    // La LocationCurve y su offset pueden atravesar zonas que ya no pertenecen
    // al sólido efectivo por uniones, cortes o extremos oblicuos. Esta rutina
    // recalcula la posición de la barra en varias estaciones, usando el ancho y
    // el peralte reales de la sección local, igual que la corrección aplicada a
    // los estribos curvos.
    private Curve CrearTrayectoriaLongitudinalAdaptadaAlSolidoMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central)
    {
        if (tramo == null ||
            tramo.Eje == null ||
            tramo.Longitud <= Tol)
        {
            return null;
        }

        double radio =
            Math.Max(0.0, diametro) / 2.0;

        double diametroEstribo =
            ObtenerDiametroEstriboReferenciaDesdeForm();

        double recubrimiento = 0.0;

        if (Form != null)
        {
            double recCm;

            if (TryLeerDouble(
                Form.RecubrimientoTexto,
                out recCm))
            {
                recubrimiento =
                    UnitUtils.ConvertToInternalUnits(
                        recCm,
                        UnitTypeId.Centimeters);
            }
        }

        double margenLateral =
            recubrimiento +
            diametroEstribo +
            radio;

        int n =
            Math.Max(1, cantidad);

        int iLogico =
            Math.Max(
                0,
                Math.Min(
                    n - 1,
                    indiceBarra));

        int indiceFisico =
            ObtenerIndiceFisicoBarraCurvaMYG(
                tramo,
                n,
                iLogico);

        double pasoObjetivo =
            UnitUtils.ConvertToInternalUnits(
                30.0,
                UnitTypeId.Centimeters);

        int muestras =
            Math.Max(
                9,
                Math.Min(
                    41,
                    (int)Math.Ceiling(
                        tramo.Longitud /
                        Math.Max(pasoObjetivo, Tol)) +
                    1));

        double margenExtremo =
            Math.Min(
                UnitUtils.ConvertToInternalUnits(
                    2.0,
                    UnitTypeId.Centimeters),
                tramo.Longitud * 0.01);

        double estacionInicial =
            margenExtremo;

        double estacionFinal =
            tramo.Longitud -
            margenExtremo;

        if (estacionFinal <= estacionInicial + Tol)
        {
            estacionInicial = 0.0;
            estacionFinal = tramo.Longitud;
        }

        List<XYZ> puntos =
            new List<XYZ>();

        for (int iMuestra = 0;
             iMuestra < muestras;
             iMuestra++)
        {
            double fraccion =
                muestras <= 1
                    ? 0.5
                    : (double)iMuestra /
                      (double)(muestras - 1);

            double estacion =
                estacionInicial +
                (estacionFinal - estacionInicial) *
                fraccion;

            XYZ centro;
            XYZ tangente;
            XYZ ejeY;
            XYZ ejeZ;

            if (!ObtenerMarcoCurvaLongitudinalMYG(
                tramo.Eje,
                estacion,
                out centro,
                out tangente,
                out ejeY,
                out ejeZ))
            {
                continue;
            }

            double yMinLocal;
            double yMaxLocal;
            double zMinLocal;
            double zMaxLocal;

            if (!TryObtenerRangoSeccionLocalTramoCurvoMYG(
                tramo,
                estacion,
                out yMinLocal,
                out yMaxLocal,
                out zMinLocal,
                out zMaxLocal))
            {
                yMinLocal = tramo.YMin;
                yMaxLocal = tramo.YMax;
                zMinLocal = tramo.ZMin;
                zMaxLocal = tramo.ZMax;
            }

            double yInicial =
                yMinLocal +
                margenLateral;

            double yFinal =
                yMaxLocal -
                margenLateral;

            if (yFinal < yInicial - Tol)
                continue;

            double y =
                n == 1 ||
                Math.Abs(yFinal - yInicial) <= Tol
                    ? (yInicial + yFinal) / 2.0
                    : yInicial +
                      (yFinal - yInicial) *
                      ((double)indiceFisico /
                       (double)(n - 1));

            double z =
                central
                    ? (zMinLocal + zMaxLocal) / 2.0
                    : superior
                        ? zMaxLocal -
                          offsetVerticalDesdeCara
                        : zMinLocal +
                          offsetVerticalDesdeCara;

            if (!central &&
                (z <= zMinLocal + Tol ||
                 z >= zMaxLocal - Tol))
            {
                continue;
            }

            XYZ punto =
                centro
                    .Add(
                        ejeY.Normalize().Multiply(y))
                    .Add(
                        ejeZ.Normalize().Multiply(z));

            // Si una tolerancia geométrica deja el punto exactamente fuera del
            // sólido, se desplaza únicamente hacia el centro de la sección.
            // Esto aumenta el recubrimiento; nunca lo reduce.
            if (tramo.SolidosGlobales != null &&
                tramo.SolidosGlobales.Count > 0 &&
                !PuntoDentroDeSolidosMYG(
                    tramo.SolidosGlobales,
                    punto,
                    tangente))
            {
                double centroY =
                    (yMinLocal + yMaxLocal) / 2.0;

                double centroZ =
                    (zMinLocal + zMaxLocal) / 2.0;

                bool encontrado =
                    false;

                for (int intento = 1;
                     intento <= 6;
                     intento++)
                {
                    double factor =
                        1.0 -
                        intento * 0.08;

                    double yAjustado =
                        centroY +
                        (y - centroY) *
                        factor;

                    double zAjustado =
                        centroZ +
                        (z - centroZ) *
                        factor;

                    XYZ candidato =
                        centro
                            .Add(
                                ejeY.Normalize().Multiply(
                                    yAjustado))
                            .Add(
                                ejeZ.Normalize().Multiply(
                                    zAjustado));

                    if (PuntoDentroDeSolidosMYG(
                        tramo.SolidosGlobales,
                        candidato,
                        tangente))
                    {
                        punto = candidato;
                        encontrado = true;
                        break;
                    }
                }

                if (!encontrado)
                    continue;
            }

            double toleranciaDuplicado =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            if (puntos.Count == 0 ||
                puntos[puntos.Count - 1]
                    .DistanceTo(punto) >
                toleranciaDuplicado)
            {
                puntos.Add(punto);
            }
        }

        if (puntos.Count < 2)
            return null;

        if (puntos.Count == 2)
        {
            try
            {
                return Line.CreateBound(
                    puntos[0],
                    puntos[1]);
            }
            catch
            {
                return null;
            }
        }

        XYZ inicio =
            puntos[0];

        XYZ fin =
            puntos[puntos.Count - 1];

        XYZ direccion =
            fin - inicio;

        if (direccion.GetLength() > Tol)
        {
            direccion =
                direccion.Normalize();

            double desviacionMaxima =
                0.0;

            foreach (XYZ p in puntos)
            {
                double desviacion =
                    (p - inicio)
                        .CrossProduct(direccion)
                        .GetLength();

                desviacionMaxima =
                    Math.Max(
                        desviacionMaxima,
                        desviacion);
            }

            double toleranciaRecta =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            if (desviacionMaxima <= toleranciaRecta)
            {
                try
                {
                    return Line.CreateBound(
                        inicio,
                        fin);
                }
                catch
                {
                }
            }
        }

        try
        {
            HermiteSpline hermite =
                HermiteSpline.Create(
                    puntos,
                    false);

            if (hermite != null &&
                hermite.IsBound &&
                hermite.Length > Tol)
            {
                try
                {
                    Curve nurbs =
                        NurbSpline.CreateCurve(
                            hermite);

                    if (nurbs != null &&
                        nurbs.IsBound &&
                        nurbs.Length > Tol)
                    {
                        return nurbs;
                    }
                }
                catch
                {
                }

                return hermite;
            }
        }
        catch
        {
        }

        return null;
    }


    // Recorta la curva longitudinal contra los sólidos reales del anfitrión.
    // Una viga corta o unida puede tener una LocationCurve mayor que el concreto
    // visible; crear el Rebar con esa curva completa provoca que Revit la rechace.
    private List<Curve> ObtenerCurvasDentroDelSolidoTramoMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        Curve curva)
    {
        List<Curve> resultado =
            new List<Curve>();

        if (tramo == null ||
            curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return resultado;
        }

        if (tramo.SolidosGlobales == null ||
            tramo.SolidosGlobales.Count == 0)
        {
            resultado.Add(curva);
            return resultado;
        }

        foreach (Solid solido in tramo.SolidosGlobales)
        {
            if (solido == null)
                continue;

            try
            {
                using (SolidCurveIntersectionOptions opciones =
                    new SolidCurveIntersectionOptions())
                {
                    opciones.ResultType =
                        SolidCurveIntersectionMode.CurveSegmentsInside;

                    using (SolidCurveIntersection interseccion =
                        solido.IntersectWithCurve(
                            curva,
                            opciones))
                    {
                        for (int i = 0;
                             i < interseccion.SegmentCount;
                             i++)
                        {
                            Curve segmento =
                                interseccion.GetCurveSegment(i);

                            if (segmento == null ||
                                !segmento.IsBound ||
                                segmento.Length <= Tol)
                            {
                                continue;
                            }

                            resultado.Add(segmento);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        double toleranciaLongitud =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        // Algunos sólidos devuelven cero segmentos cuando la curva está casi
        // coincidente con una cara. Se valida entonces por puntos interiores.
        if (resultado.Count == 0)
        {
            int dentro =
                0;

            int muestras =
                9;

            for (int i = 0;
                 i < muestras;
                 i++)
            {
                double u =
                    muestras <= 1
                        ? 0.5
                        : (double)i /
                          (double)(muestras - 1);

                XYZ p = null;

                try
                {
                    p = curva.Evaluate(
                        u,
                        true);
                }
                catch
                {
                    p = null;
                }

                if (p == null)
                    continue;

                XYZ tangente =
                    ObtenerTangenteCurvaMYG(
                        curva,
                        u);

                if (PuntoDentroDeSolidosMYG(
                    tramo.SolidosGlobales,
                    p,
                    tangente))
                {
                    dentro++;
                }
            }

            if (dentro >= 5)
            {
                resultado.Add(curva);
                return resultado;
            }

            return resultado;
        }

        // Ordena las partes según la dirección de la curva original.
        resultado = resultado
            .Where(c =>
                c != null &&
                c.IsBound &&
                c.Length > toleranciaLongitud)
            .Select(c =>
            {
                Curve orientada = c;

                double p0 =
                    ObtenerParametroNormalizadoSobreCurvaMYG(
                        curva,
                        c.GetEndPoint(0));

                double p1 =
                    ObtenerParametroNormalizadoSobreCurvaMYG(
                        curva,
                        c.GetEndPoint(1));

                if (p1 < p0)
                {
                    try
                    {
                        orientada =
                            c.CreateReversed();
                    }
                    catch
                    {
                        orientada = c;
                    }
                }

                return orientada;
            })
            .OrderBy(c =>
                ObtenerParametroNormalizadoSobreCurvaMYG(
                    curva,
                    c.Evaluate(0.5, true)))
            .ToList();

        List<Curve> depuradas =
            new List<Curve>();

        double toleranciaPunto =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        foreach (Curve candidata in resultado)
        {
            if (candidata == null)
                continue;

            bool duplicada =
                depuradas.Any(existente =>
                    existente != null &&
                    Math.Abs(
                        existente.Length -
                        candidata.Length) <=
                        toleranciaLongitud &&
                    existente.Evaluate(
                        0.5,
                        true).DistanceTo(
                            candidata.Evaluate(
                                0.5,
                                true)) <=
                        toleranciaPunto);

            if (!duplicada)
                depuradas.Add(candidata);
        }

        return depuradas;
    }


    private double ObtenerParametroNormalizadoSobreCurvaMYG(
        Curve curva,
        XYZ punto)
    {
        if (curva == null ||
            punto == null)
        {
            return 0.0;
        }

        try
        {
            IntersectionResult proyeccion =
                curva.Project(punto);

            if (proyeccion == null)
                return 0.0;

            double raw0 =
                curva.GetEndParameter(0);

            double raw1 =
                curva.GetEndParameter(1);

            double denominador =
                raw1 - raw0;

            if (Math.Abs(denominador) <= 1e-12)
                return 0.0;

            return Math.Max(
                0.0,
                Math.Min(
                    1.0,
                    (proyeccion.Parameter - raw0) /
                    denominador));
        }
        catch
        {
            return 0.0;
        }
    }


    private Rebar CrearRebarTramoCurvoRobustoMYG(
        Document doc,
        Element host,
        RebarBarType tipoBarra,
        XYZ normal,
        Curve curva,
        string tipoElementoTexto,
        out Curve curvaRealmenteCreada)
    {
        curvaRealmenteCreada =
            null;

        if (doc == null ||
            host == null ||
            tipoBarra == null ||
            curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return null;
        }

        Rebar rb =
            CrearRebarCurvoSimpleConParametrosMYG(
                doc,
                host,
                tipoBarra,
                normal,
                curva,
                tipoElementoTexto);

        if (rb != null)
        {
            curvaRealmenteCreada = curva;
            return rb;
        }

        XYZ a =
            curva.GetEndPoint(0);

        XYZ b =
            curva.GetEndPoint(1);

        XYZ m = null;

        try
        {
            m =
                curva.Evaluate(
                    0.5,
                    true);
        }
        catch
        {
            m = null;
        }

        if (a == null ||
            b == null ||
            m == null ||
            a.DistanceTo(b) <= Tol)
        {
            return null;
        }

        Curve alternativa =
            null;

        XYZ directa =
            b - a;

        if (directa.GetLength() > Tol)
        {
            double desviacion =
                (m - a)
                    .CrossProduct(
                        directa.Normalize())
                    .GetLength();

            double toleranciaRecta =
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Centimeters);

            if (desviacion <= toleranciaRecta)
            {
                try
                {
                    alternativa =
                        Line.CreateBound(
                            a,
                            b);
                }
                catch
                {
                    alternativa = null;
                }
            }
        }

        if (alternativa == null)
        {
            try
            {
                alternativa =
                    Arc.Create(
                        a,
                        b,
                        m);
            }
            catch
            {
                alternativa = null;
            }
        }

        if (alternativa == null ||
            alternativa.Length <= Tol)
        {
            return null;
        }

        rb =
            CrearRebarCurvoSimpleConParametrosMYG(
                doc,
                host,
                tipoBarra,
                ObtenerNormalParaCurvaSimpleMYG(
                    alternativa,
                    normal),
                alternativa,
                tipoElementoTexto);

        if (rb != null)
            curvaRealmenteCreada = alternativa;

        return rb;
    }


    // =========================================================
    // CONECTOR SUAVE ENTRE DOS TRAMOS ARBITRARIOS
    // =========================================================
    // Se genera una única HermiteSpline con tangencias aproximadas en ambos
    // extremos. Si la spline no puede construirse, se conserva la línea recta
    // como respaldo. La correspondencia lateral ya fue resuelta antes, por lo
    // que los conectores no forman abanicos ni se cruzan.
    private Curve CrearConectorSuaveEntreTramosMYG(
        Curve curvaAnterior,
        Curve curvaSiguiente)
    {
        if (curvaAnterior == null || curvaSiguiente == null)
            return null;

        XYZ p0 = curvaAnterior.GetEndPoint(1);
        XYZ p1 = curvaSiguiente.GetEndPoint(0);

        if (p0 == null || p1 == null)
            return null;

        double distancia = p0.DistanceTo(p1);

        if (distancia <= Tol)
            return null;

        XYZ directa = p1.Subtract(p0);

        if (directa.GetLength() <= Tol)
            return null;

        directa = directa.Normalize();

        XYZ t0 = ObtenerTangenteCurvaMYG(
            curvaAnterior,
            1.0);

        XYZ t1 = ObtenerTangenteCurvaMYG(
            curvaSiguiente,
            0.0);

        if (t0 == null || t0.GetLength() <= Tol)
            t0 = directa;

        if (t1 == null || t1.GetLength() <= Tol)
            t1 = directa;

        t0 = t0.Normalize();
        t1 = t1.Normalize();

        // Evita bucles cuando la tangente local apunta en sentido opuesto al
        // vacío. Se mezcla con la dirección directa sin perder la continuidad.
        if (t0.DotProduct(directa) < 0.10)
        {
            XYZ mezclada = t0.Add(directa.Multiply(2.0));

            if (mezclada.GetLength() > Tol)
                t0 = mezclada.Normalize();
            else
                t0 = directa;
        }

        if (t1.DotProduct(directa) < 0.10)
        {
            XYZ mezclada = t1.Add(directa.Multiply(2.0));

            if (mezclada.GetLength() > Tol)
                t1 = mezclada.Normalize();
            else
                t1 = directa;
        }

        double longitudControl = Math.Min(
            distancia * 0.35,
            UnitUtils.ConvertToInternalUnits(
                120.0,
                UnitTypeId.Centimeters));

        longitudControl = Math.Max(
            longitudControl,
            Math.Min(
                distancia * 0.15,
                UnitUtils.ConvertToInternalUnits(
                    10.0,
                    UnitTypeId.Centimeters)));

        XYZ m0 = t0.Multiply(longitudControl);
        XYZ m1 = t1.Multiply(longitudControl);

        List<XYZ> puntos = new List<XYZ>();
        int divisiones = 12;

        for (int i = 0; i <= divisiones; i++)
        {
            double u = (double)i / (double)divisiones;
            double u2 = u * u;
            double u3 = u2 * u;

            double h00 = 2.0 * u3 - 3.0 * u2 + 1.0;
            double h10 = u3 - 2.0 * u2 + u;
            double h01 = -2.0 * u3 + 3.0 * u2;
            double h11 = u3 - u2;

            XYZ punto = new XYZ(
                h00 * p0.X + h10 * m0.X + h01 * p1.X + h11 * m1.X,
                h00 * p0.Y + h10 * m0.Y + h01 * p1.Y + h11 * m1.Y,
                h00 * p0.Z + h10 * m0.Z + h01 * p1.Z + h11 * m1.Z);

            if (puntos.Count == 0 ||
                puntos[puntos.Count - 1].DistanceTo(punto) >
                UnitUtils.ConvertToInternalUnits(
                    0.1,
                    UnitTypeId.Millimeters))
            {
                puntos.Add(punto);
            }
        }

        if (puntos.Count >= 3)
        {
            try
            {
                Curve spline =
                    HermiteSpline.Create(
                        puntos,
                        false);

                if (spline != null &&
                    spline.IsBound &&
                    spline.Length > Tol)
                {
                    return spline;
                }
            }
            catch
            {
            }
        }

        try
        {
            return Line.CreateBound(
                p0,
                p1);
        }
        catch
        {
            return null;
        }
    }

    private Rebar CrearRebarCurvoCadenaConParametrosMYG(
        Document doc,
        Element host,
        RebarBarType tipoBarra,
        XYZ normal,
        IList<Curve> curvas,
        string tipoElementoTexto)
    {
        if (doc == null ||
            host == null ||
            tipoBarra == null ||
            curvas == null ||
            curvas.Count == 0)
        {
            return null;
        }

        List<Curve> validas = curvas
            .Where(c =>
                c != null &&
                c.IsBound &&
                c.Length > Tol)
            .ToList();

        if (validas.Count == 0)
            return null;

        Rebar rb = CrearRebarLongitudinalCurvoMYG(
            doc,
            host,
            tipoBarra,
            normal,
            validas);

        if (rb == null)
            return null;

        AplicarParametrosInstanciaAceroLongitudinal(
            doc,
            rb,
            host,
            tipoElementoTexto);

        return rb;
    }


    private Rebar CrearRebarCurvoSimpleConParametrosMYG(
        Document doc,
        Element host,
        RebarBarType tipoBarra,
        XYZ normal,
        Curve curva,
        string tipoElementoTexto)
    {
        if (doc == null ||
            host == null ||
            tipoBarra == null ||
            curva == null ||
            !curva.IsBound ||
            curva.Length <= Tol)
        {
            return null;
        }

        try
        {
            if (RebarHostData.GetRebarHostData(host) == null)
            {
                RegistrarErrorCurvaMYG(
                    "El host " +
                    host.Id.Value.ToString() +
                    " no admite armadura.");

                return null;
            }
        }
        catch (Exception ex)
        {
            RegistrarErrorCurvaMYG(
                "No se pudo validar el host " +
                host.Id.Value.ToString() +
                ": " +
                ex.Message);

            return null;
        }

        ultimoErrorCurvaMYG =
            string.Empty;

        Rebar rb =
            CrearRebarLongitudinalCurvoMYG(
                doc,
                host,
                tipoBarra,
                normal,
                new List<Curve>()
                {
                    curva
                });

        if (rb == null)
        {
            RegistrarErrorCurvaMYG(
                "Host " +
                host.Id.Value.ToString() +
                ", " +
                curva.GetType().Name +
                " de " +
                UnitUtils.ConvertFromInternalUnits(
                    curva.Length,
                    UnitTypeId.Meters).ToString("0.###") +
                " m: " +
                (string.IsNullOrWhiteSpace(ultimoErrorCurvaMYG)
                    ? "Revit devolvió null sin detalle."
                    : ultimoErrorCurvaMYG));

            return null;
        }

        AplicarParametrosInstanciaAceroLongitudinal(
            doc,
            rb,
            host,
            tipoElementoTexto);

        return rb;
    }

    private XYZ ObtenerNormalParaCurvaSimpleMYG(
        Curve curva,
        XYZ normalPreferida)
    {
        if (curva == null)
            return XYZ.BasisZ;

        XYZ tangente =
            ObtenerTangenteCurvaMYG(
                curva,
                0.5);

        if (tangente == null ||
            tangente.GetLength() <= Tol)
        {
            return normalPreferida != null &&
                   normalPreferida.GetLength() > Tol
                ? normalPreferida.Normalize()
                : XYZ.BasisZ;
        }

        tangente =
            tangente.Normalize();

        if (normalPreferida != null &&
            normalPreferida.GetLength() > Tol)
        {
            XYZ n =
                normalPreferida.Normalize();

            XYZ proyectada =
                n.Subtract(
                    tangente.Multiply(
                        n.DotProduct(tangente)));

            if (proyectada.GetLength() > Tol)
                return proyectada.Normalize();
        }

        XYZ normal =
            tangente.CrossProduct(
                XYZ.BasisZ);

        if (normal.GetLength() <= Tol)
            normal = tangente.CrossProduct(XYZ.BasisX);

        if (normal.GetLength() <= Tol)
            normal = XYZ.BasisY;

        return normal.Normalize();
    }


    private IList<Curve> CrearCadenaSerieCurvaPorEstacionesMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central,
        double estacionInicio,
        double estacionFin)
    {
        List<Curve> resultado = new List<Curve>();

        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            serie.LongitudTotal <= Tol ||
            estacionFin <= estacionInicio + Tol)
        {
            return resultado;
        }

        // IMPORTANTE:
        // En vigas curvas NO se reconstruye un arco maestro.
        // Se conserva el boceto real de cada tramo y se añaden conectores rectos
        // entre los offsets consecutivos para formar una sola cadena.
        TramoSerieCurvaLongitudinalMYG primero = serie.Tramos.First();
        TramoSerieCurvaLongitudinalMYG ultimo = serie.Tramos.Last();

        Curve curvaPrimeraCompleta = CrearCurvaOffsetTramoSerieMYG(
            primero,
            cantidad,
            indiceBarra,
            diametro,
            offsetVerticalDesdeCara,
            superior,
            central);

        Curve curvaUltimaCompleta = CrearCurvaOffsetTramoSerieMYG(
            ultimo,
            cantidad,
            indiceBarra,
            diametro,
            offsetVerticalDesdeCara,
            superior,
            central);

        if (curvaPrimeraCompleta == null || curvaUltimaCompleta == null)
            return resultado;

        // Todas las curvas de una única barra deben quedar en un plano común.
        // Las uniones/recortes de Revit pueden dejar diferencias milimétricas de Z
        // entre tramos que visualmente son coplanares. Se toma el plano del primer
        // boceto y se trasladan los demás bocetos paralelos a ese mismo plano.
        XYZ origenPlanoSerieMYG = curvaPrimeraCompleta.GetEndPoint(0);
        XYZ normalPlanoSerieMYG = serie.EjeZ != null && serie.EjeZ.GetLength() > Tol
            ? serie.EjeZ.Normalize()
            : XYZ.BasisZ;

        curvaPrimeraCompleta = AlinearCurvaAPlanoSerieMYG(
            curvaPrimeraCompleta,
            origenPlanoSerieMYG,
            normalPlanoSerieMYG);

        curvaUltimaCompleta = AlinearCurvaAPlanoSerieMYG(
            curvaUltimaCompleta,
            origenPlanoSerieMYG,
            normalPlanoSerieMYG);

        if (curvaPrimeraCompleta == null || curvaUltimaCompleta == null)
            return resultado;

        // Desarrollo fuera del inicio de la serie: prolongación tangencial.
        if (estacionInicio < 0.0)
        {
            XYZ p0 = curvaPrimeraCompleta.GetEndPoint(0);
            XYZ tangente0 = ObtenerTangenteCurvaMYG(curvaPrimeraCompleta, 0.0);

            if (p0 != null && tangente0 != null)
            {
                XYZ pExt = p0.Add(tangente0.Multiply(estacionInicio));
                AgregarCurvaContinuaMYG(resultado, Line.CreateBound(pExt, p0));
            }
        }

        foreach (TramoSerieCurvaLongitudinalMYG tramo in serie.Tramos)
        {
            if (tramo == null || tramo.Eje == null || tramo.Longitud <= Tol)
                continue;

            double global0 = Math.Max(estacionInicio, tramo.InicioSerie);
            double global1 = Math.Min(estacionFin, tramo.FinSerie);

            if (global1 <= global0 + Tol)
                continue;

            Curve curvaOffset = CrearCurvaOffsetTramoSerieMYG(
                tramo,
                cantidad,
                indiceBarra,
                diametro,
                offsetVerticalDesdeCara,
                superior,
                central);

            if (curvaOffset == null)
                continue;

            curvaOffset = AlinearCurvaAPlanoSerieMYG(
                curvaOffset,
                origenPlanoSerieMYG,
                normalPlanoSerieMYG);

            if (curvaOffset == null)
                continue;

            double local0 = global0 - tramo.InicioSerie;
            double local1 = global1 - tramo.InicioSerie;

            Curve subCurva = CrearSubCurvaPorLongitudMYG(
                curvaOffset,
                tramo.Longitud,
                local0,
                local1);

            if (subCurva == null)
                continue;

            AgregarCurvaContinuaMYG(resultado, subCurva);
        }

        // Desarrollo fuera del final de la serie: prolongación tangencial.
        if (estacionFin > serie.LongitudTotal)
        {
            XYZ p1 = curvaUltimaCompleta.GetEndPoint(1);
            XYZ tangente1 = ObtenerTangenteCurvaMYG(curvaUltimaCompleta, 1.0);

            if (p1 != null && tangente1 != null)
            {
                XYZ pExt = p1.Add(
                    tangente1.Multiply(estacionFin - serie.LongitudTotal));

                AgregarCurvaContinuaMYG(resultado, Line.CreateBound(p1, pExt));
            }
        }

        return LimpiarCurvasCadenaMYG(resultado);
    }


    // =========================================================
    // ARCO MAESTRO PARA VIGAS DIVIDIDAS / RECORTADAS
    // =========================================================
    private IList<Curve> CrearCadenaArcoMaestroPorEstacionesMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central,
        double estacionInicio,
        double estacionFin)
    {
        List<Curve> resultado = new List<Curve>();

        if (serie == null ||
            serie.ArcoMaestro == null ||
            serie.LongitudTotal <= Tol ||
            estacionFin <= estacionInicio + Tol)
        {
            return resultado;
        }

        Curve curvaOffset = CrearCurvaOffsetArcoMaestroMYG(
            serie,
            cantidad,
            indiceBarra,
            diametro,
            offsetVerticalDesdeCara,
            superior,
            central);

        if (curvaOffset == null || curvaOffset.Length <= Tol)
        {
            ultimoErrorCurvaMYG =
                "No se pudo crear el offset del arco maestro para una de las barras.";
            return resultado;
        }

        // Desarrollo inicial medido sobre la tangente exacta del arco offset.
        if (estacionInicio < 0.0)
        {
            XYZ p0 = curvaOffset.GetEndPoint(0);
            XYZ tangente0 = ObtenerTangenteCurvaMYG(curvaOffset, 0.0);

            if (p0 != null && tangente0 != null && tangente0.GetLength() > Tol)
            {
                XYZ pExt = p0.Add(
                    tangente0.Normalize().Multiply(estacionInicio));

                if (pExt.DistanceTo(p0) > Tol)
                    resultado.Add(Line.CreateBound(pExt, p0));
            }
        }

        double interiorInicio = Math.Max(0.0, estacionInicio);
        double interiorFin = Math.Min(serie.LongitudTotal, estacionFin);

        if (interiorFin > interiorInicio + Tol)
        {
            Curve subCurva = CrearSubCurvaPorLongitudMYG(
                curvaOffset,
                serie.LongitudTotal,
                interiorInicio,
                interiorFin);

            if (subCurva != null && subCurva.Length > Tol)
                resultado.Add(subCurva);
        }

        // Desarrollo final medido sobre la tangente exacta del arco offset.
        if (estacionFin > serie.LongitudTotal)
        {
            XYZ p1 = curvaOffset.GetEndPoint(1);
            XYZ tangente1 = ObtenerTangenteCurvaMYG(curvaOffset, 1.0);

            if (p1 != null && tangente1 != null && tangente1.GetLength() > Tol)
            {
                XYZ pExt = p1.Add(
                    tangente1.Normalize().Multiply(
                        estacionFin - serie.LongitudTotal));

                if (p1.DistanceTo(pExt) > Tol)
                    resultado.Add(Line.CreateBound(p1, pExt));
            }
        }

        return LimpiarCurvasCadenaMYG(resultado);
    }

    private Curve CrearCurvaOffsetArcoMaestroMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central)
    {
        if (serie == null ||
            serie.ArcoMaestro == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0)
        {
            return null;
        }

        // Los tramos proceden de una misma viga original, pero las uniones y
        // recortes pueden introducir pequeñas variaciones numéricas. Se toma
        // una sección representativa promedio para que el offset sea único.
        List<TramoSerieCurvaLongitudinalMYG> validos = serie.Tramos
            .Where(t => t != null)
            .ToList();

        if (validos.Count == 0)
            return null;

        TramoSerieCurvaLongitudinalMYG referencia = validos[0];

        XYZ puntoMedio;
        XYZ tangenteMedio;
        XYZ ejeYMedio;
        XYZ ejeZ;

        if (!ObtenerMarcoCurvaLongitudinalMYG(
            serie.ArcoMaestro,
            serie.ArcoMaestro.Length * 0.5,
            out puntoMedio,
            out tangenteMedio,
            out ejeYMedio,
            out ejeZ))
        {
            return null;
        }

        TramoSerieCurvaLongitudinalMYG maestro =
            new TramoSerieCurvaLongitudinalMYG();

        maestro.Host = serie.HostPrincipal;
        maestro.Eje = serie.ArcoMaestro;
        maestro.Longitud = serie.ArcoMaestro.Length;
        maestro.InicioSerie = 0.0;
        maestro.FinSerie = maestro.Longitud;
        maestro.PuntoMedio = puntoMedio;
        maestro.TangenteMedio = tangenteMedio;
        maestro.EjeYMedio = ejeYMedio;
        maestro.EjeZ = ejeZ;

        maestro.YMin = validos.Average(t => t.YMin);
        maestro.YMax = validos.Average(t => t.YMax);
        maestro.ZMin = validos.Average(t => t.ZMin);
        maestro.ZMax = validos.Average(t => t.ZMax);
        maestro.PuntosGeometria = referencia.PuntosGeometria;

        return CrearCurvaOffsetTramoSerieMYG(
            maestro,
            cantidad,
            indiceBarra,
            diametro,
            offsetVerticalDesdeCara,
            superior,
            central);
    }

    private Curve CrearCurvaOffsetTramoSerieMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central)
    {
        if (tramo == null ||
            tramo.Eje == null ||
            tramo.Longitud <= Tol)
        {
            return null;
        }

        double radio =
            Math.Max(0.0, diametro) / 2.0;

        double diametroEstribo =
            ObtenerDiametroEstriboReferenciaDesdeForm();

        double recubrimiento = 0.0;

        if (Form != null)
        {
            double recCm;

            if (TryLeerDouble(
                Form.RecubrimientoTexto,
                out recCm))
            {
                recubrimiento =
                    UnitUtils.ConvertToInternalUnits(
                        recCm,
                        UnitTypeId.Centimeters);
            }
        }

        // =========================================================
        // RECUBRIMIENTO REAL POR ESTACIONES
        // =========================================================
        // YMin/YMax y ZMin/ZMax del tramo se obtuvieron inicialmente en la
        // sección media. En una viga curva, una unión, una cuchilla o un eje
        // familiar excéntrico pueden hacer que esos límites no representen toda
        // la longitud. Se obtiene entonces el intervalo común seguro leyendo
        // los sólidos reales en varias estaciones.
        double yMinSeguro =
            tramo.YMin;

        double yMaxSeguro =
            tramo.YMax;

        double zMinSeguro =
            tramo.ZMin;

        double zMaxSeguro =
            tramo.ZMax;

        ObtenerLimitesComunesSeccionTramoCurvoMYG(
            tramo,
            out yMinSeguro,
            out yMaxSeguro,
            out zMinSeguro,
            out zMaxSeguro);

        // Distancia desde la cara de concreto hasta el eje longitudinal:
        // recubrimiento + diámetro del estribo + radio de la barra.
        double margenLateral =
            recubrimiento +
            diametroEstribo +
            radio;

        double yInicial =
            yMinSeguro +
            margenLateral;

        double yFinal =
            yMaxSeguro -
            margenLateral;

        if (yFinal < yInicial - Tol)
        {
            RegistrarErrorCurvaMYG(
                "Host " +
                (tramo.Host != null
                    ? tramo.Host.Id.Value.ToString()
                    : "?") +
                ": el ancho útil quedó menor que el paquete longitudinal.");

            return null;
        }

        int n =
            Math.Max(1, cantidad);

        int iLogico =
            Math.Max(
                0,
                Math.Min(
                    n - 1,
                    indiceBarra));

        int i =
            ObtenerIndiceFisicoBarraCurvaMYG(
                tramo,
                n,
                iLogico);

        double offsetY =
            n == 1 ||
            Math.Abs(yFinal - yInicial) <= Tol
                ? (yInicial + yFinal) / 2.0
                : yInicial +
                  (yFinal - yInicial) *
                  ((double)i / (double)(n - 1));

        double offsetZ;

        if (central)
        {
            offsetZ =
                (zMinSeguro + zMaxSeguro) / 2.0;
        }
        else
        {
            offsetZ =
                superior
                    ? zMaxSeguro -
                      offsetVerticalDesdeCara
                    : zMinSeguro +
                      offsetVerticalDesdeCara;
        }

        if (!central &&
            (offsetZ <= zMinSeguro + Tol ||
             offsetZ >= zMaxSeguro - Tol))
        {
            RegistrarErrorCurvaMYG(
                "Host " +
                (tramo.Host != null
                    ? tramo.Host.Id.Value.ToString()
                    : "?") +
                ": el peralte útil no admite la capa solicitada.");

            return null;
        }

        Curve offset = null;

        if (Math.Abs(offsetY) <= Tol)
        {
            try
            {
                offset =
                    tramo.Eje.Clone();
            }
            catch
            {
                offset = null;
            }
        }

        try
        {
            if (offset == null)
            {
                offset =
                    tramo.Eje.CreateOffset(
                        offsetY,
                        tramo.EjeZ);
            }
        }
        catch
        {
            offset = null;
        }

        if (offset == null)
        {
            try
            {
                offset =
                    tramo.Eje.CreateOffset(
                        -offsetY,
                        tramo.EjeZ);
            }
            catch
            {
                offset = null;
            }
        }

        if (offset == null)
            return null;

        // CreateOffset cambia de signo según el sentido de la curva.
        // Se comprueba el lado en el marco transversal del propio tramo.
        try
        {
            XYZ pBase =
                tramo.Eje.Evaluate(
                    0.5,
                    true);

            XYZ pOff =
                offset.Evaluate(
                    0.5,
                    true);

            double lado =
                (pOff - pBase)
                    .DotProduct(
                        tramo.EjeYMedio);

            if ((offsetY > Tol &&
                 lado < -Tol) ||
                (offsetY < -Tol &&
                 lado > Tol))
            {
                Curve opuesto =
                    tramo.Eje.CreateOffset(
                        -offsetY,
                        tramo.EjeZ);

                if (opuesto != null)
                    offset = opuesto;
            }
        }
        catch
        {
        }

        if (Math.Abs(offsetZ) > Tol)
        {
            try
            {
                Transform tr =
                    Transform.CreateTranslation(
                        tramo.EjeZ.Multiply(
                            offsetZ));

                offset =
                    offset.CreateTransformed(
                        tr);
            }
            catch
            {
                return null;
            }
        }

        return offset;
    }

    private bool ObtenerLimitesComunesSeccionTramoCurvoMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        out double yMinSeguro,
        out double yMaxSeguro,
        out double zMinSeguro,
        out double zMaxSeguro)
    {
        yMinSeguro =
            tramo != null
                ? tramo.YMin
                : 0.0;

        yMaxSeguro =
            tramo != null
                ? tramo.YMax
                : 0.0;

        zMinSeguro =
            tramo != null
                ? tramo.ZMin
                : 0.0;

        zMaxSeguro =
            tramo != null
                ? tramo.ZMax
                : 0.0;

        if (tramo == null ||
            tramo.Eje == null ||
            tramo.Longitud <= Tol ||
            tramo.SolidosGlobales == null ||
            tramo.SolidosGlobales.Count == 0)
        {
            return false;
        }

        double margenExtremos =
            Math.Min(
                tramo.Longitud * 0.10,
                UnitUtils.ConvertToInternalUnits(
                    10.0,
                    UnitTypeId.Centimeters));

        margenExtremos =
            Math.Max(
                0.0,
                margenExtremos);

        double s0 =
            margenExtremos;

        double s1 =
            tramo.Longitud -
            margenExtremos;

        if (s1 <= s0 + Tol)
        {
            s0 = 0.0;
            s1 = tramo.Longitud;
        }

        List<double> yMinimos =
            new List<double>();

        List<double> yMaximos =
            new List<double>();

        List<double> zMinimos =
            new List<double>();

        List<double> zMaximos =
            new List<double>();

        int muestras = 9;

        for (int i = 0;
             i < muestras;
             i++)
        {
            double fraccion =
                muestras <= 1
                    ? 0.5
                    : (double)i /
                      (double)(muestras - 1);

            double estacion =
                s0 +
                (s1 - s0) *
                fraccion;

            double yMinLocal;
            double yMaxLocal;
            double zMinLocal;
            double zMaxLocal;

            if (TryObtenerRangoSeccionLocalTramoCurvoMYG(
                tramo,
                estacion,
                out yMinLocal,
                out yMaxLocal,
                out zMinLocal,
                out zMaxLocal))
            {
                yMinimos.Add(yMinLocal);
                yMaximos.Add(yMaxLocal);
                zMinimos.Add(zMinLocal);
                zMaximos.Add(zMaxLocal);
            }
        }

        if (yMinimos.Count == 0)
            return false;

        double candidatoYMin =
            yMinimos.Max();

        double candidatoYMax =
            yMaximos.Min();

        double candidatoZMin =
            zMinimos.Max();

        double candidatoZMax =
            zMaximos.Min();

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        if (candidatoYMax <=
            candidatoYMin + tolerancia)
        {
            // Si la intersección común de todas las estaciones se cierra por
            // una singularidad puntual, se usa el 20 % más conservador de los
            // límites y no la envolvente más ancha.
            candidatoYMin =
                PercentilSeguroMYG(
                    yMinimos,
                    0.80);

            candidatoYMax =
                PercentilSeguroMYG(
                    yMaximos,
                    0.20);
        }

        if (candidatoZMax <=
            candidatoZMin + tolerancia)
        {
            candidatoZMin =
                PercentilSeguroMYG(
                    zMinimos,
                    0.80);

            candidatoZMax =
                PercentilSeguroMYG(
                    zMaximos,
                    0.20);
        }

        if (candidatoYMax <=
                candidatoYMin + tolerancia ||
            candidatoZMax <=
                candidatoZMin + tolerancia)
        {
            return false;
        }

        yMinSeguro =
            candidatoYMin;

        yMaxSeguro =
            candidatoYMax;

        zMinSeguro =
            candidatoZMin;

        zMaxSeguro =
            candidatoZMax;

        return true;
    }

    private double PercentilSeguroMYG(
        List<double> valores,
        double fraccion)
    {
        if (valores == null ||
            valores.Count == 0)
        {
            return 0.0;
        }

        List<double> ordenados =
            valores
                .OrderBy(x => x)
                .ToList();

        fraccion =
            Math.Max(
                0.0,
                Math.Min(
                    1.0,
                    fraccion));

        double posicion =
            fraccion *
            (ordenados.Count - 1);

        int inferior =
            (int)Math.Floor(
                posicion);

        int superior =
            (int)Math.Ceiling(
                posicion);

        if (inferior == superior)
            return ordenados[inferior];

        double t =
            posicion - inferior;

        return ordenados[inferior] +
               (ordenados[superior] -
                ordenados[inferior]) *
               t;
    }

    private bool TryObtenerRangoSeccionLocalTramoCurvoMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        double estacion,
        out double yMin,
        out double yMax,
        out double zMin,
        out double zMax)
    {
        yMin =
            double.MaxValue;

        yMax =
            double.MinValue;

        zMin =
            double.MaxValue;

        zMax =
            double.MinValue;

        if (tramo == null ||
            tramo.Eje == null ||
            tramo.SolidosGlobales == null ||
            tramo.SolidosGlobales.Count == 0)
        {
            return false;
        }

        XYZ centro;
        XYZ tangente;
        XYZ ejeY;
        XYZ ejeZ;

        if (!ObtenerMarcoCurvaLongitudinalMYG(
            tramo.Eje,
            estacion,
            out centro,
            out tangente,
            out ejeY,
            out ejeZ))
        {
            return false;
        }

        if (centro == null ||
            ejeY == null ||
            ejeY.GetLength() <= Tol ||
            ejeZ == null ||
            ejeZ.GetLength() <= Tol)
        {
            return false;
        }

        ejeY =
            ejeY.Normalize();

        ejeZ =
            ejeZ.Normalize();

        // Primera sonda lateral en la cota del eje. Sirve para localizar un
        // punto interior aunque el eje de la familia sea excéntrico.
        double yMinEje;
        double yMaxEje;

        bool tieneYEnEje =
            TryObtenerIntervaloSolidoPorSondaLongitudinalMYG(
                tramo.SolidosGlobales,
                centro,
                centro,
                ejeY,
                ejeY,
                out yMinEje,
                out yMaxEje);

        double yMedio =
            tieneYEnEje
                ? (yMinEje + yMaxEje) / 2.0
                : (tramo.YMin + tramo.YMax) / 2.0;

        XYZ origenVertical =
            centro.Add(
                ejeY.Multiply(
                    yMedio));

        if (!TryObtenerIntervaloSolidoPorSondaLongitudinalMYG(
            tramo.SolidosGlobales,
            centro,
            origenVertical,
            ejeZ,
            ejeZ,
            out zMin,
            out zMax))
        {
            zMin = tramo.ZMin;
            zMax = tramo.ZMax;
        }

        if (zMax <= zMin + Tol)
            return false;

        List<IntervaloColumnaSerie> intervalosY =
            new List<IntervaloColumnaSerie>();

        double alto =
            zMax - zMin;

        double[] fraccionesZ =
            new double[]
            {
                0.25,
                0.50,
                0.75
            };

        foreach (double f in fraccionesZ)
        {
            double z =
                zMin +
                alto * f;

            XYZ origenLateral =
                centro.Add(
                    ejeZ.Multiply(
                        z));

            double y0;
            double y1;

            if (TryObtenerIntervaloSolidoPorSondaLongitudinalMYG(
                tramo.SolidosGlobales,
                centro,
                origenLateral,
                ejeY,
                ejeY,
                out y0,
                out y1))
            {
                intervalosY.Add(
                    new IntervaloColumnaSerie(
                        y0,
                        y1));
            }
        }

        if (intervalosY.Count == 0)
        {
            if (!tieneYEnEje)
                return false;

            yMin = yMinEje;
            yMax = yMaxEje;
        }
        else
        {
            yMin =
                intervalosY.Max(
                    x => x.Min);

            yMax =
                intervalosY.Min(
                    x => x.Max);

            if (yMax <= yMin + Tol)
            {
                IntervaloColumnaSerie mejor =
                    intervalosY
                        .OrderByDescending(
                            x => x.Width)
                        .FirstOrDefault();

                if (mejor == null)
                    return false;

                yMin = mejor.Min;
                yMax = mejor.Max;
            }
        }

        return yMax > yMin + Tol &&
               zMax > zMin + Tol;
    }

    private bool TryObtenerIntervaloSolidoPorSondaLongitudinalMYG(
        List<Solid> solidos,
        XYZ origenMarco,
        XYZ origenSonda,
        XYZ direccionSonda,
        XYZ ejeCoordenada,
        out double valorMin,
        out double valorMax)
    {
        valorMin =
            double.MaxValue;

        valorMax =
            double.MinValue;

        if (solidos == null ||
            solidos.Count == 0 ||
            origenMarco == null ||
            origenSonda == null ||
            direccionSonda == null ||
            direccionSonda.GetLength() <= Tol ||
            ejeCoordenada == null ||
            ejeCoordenada.GetLength() <= Tol)
        {
            return false;
        }

        XYZ direccion =
            direccionSonda.Normalize();

        XYZ eje =
            ejeCoordenada.Normalize();

        double semilongitud =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Meters);

        Line sonda = null;

        try
        {
            sonda =
                Line.CreateBound(
                    origenSonda.Subtract(
                        direccion.Multiply(
                            semilongitud)),
                    origenSonda.Add(
                        direccion.Multiply(
                            semilongitud)));
        }
        catch
        {
            sonda = null;
        }

        if (sonda == null)
            return false;

        List<IntervaloColumnaSerie> intervalos =
            new List<IntervaloColumnaSerie>();

        foreach (Solid solido in solidos)
        {
            if (solido == null)
                continue;

            try
            {
                using (SolidCurveIntersectionOptions opciones =
                    new SolidCurveIntersectionOptions())
                {
                    opciones.ResultType =
                        SolidCurveIntersectionMode.CurveSegmentsInside;

                    using (SolidCurveIntersection interseccion =
                        solido.IntersectWithCurve(
                            sonda,
                            opciones))
                    {
                        for (int i = 0;
                             i < interseccion.SegmentCount;
                             i++)
                        {
                            Curve segmento =
                                interseccion.GetCurveSegment(i);

                            if (segmento == null ||
                                segmento.Length <= Tol)
                            {
                                continue;
                            }

                            XYZ p0 =
                                segmento.GetEndPoint(0);

                            XYZ p1 =
                                segmento.GetEndPoint(1);

                            if (p0 == null || p1 == null)
                                continue;

                            double a =
                                (p0 - origenMarco)
                                    .DotProduct(eje);

                            double b =
                                (p1 - origenMarco)
                                    .DotProduct(eje);

                            if (Math.Abs(b - a) <= Tol)
                                continue;

                            intervalos.Add(
                                new IntervaloColumnaSerie(
                                    Math.Min(a, b),
                                    Math.Max(a, b)));
                        }
                    }
                }
            }
            catch
            {
            }
        }

        if (intervalos.Count == 0)
            return false;

        intervalos =
            FusionarIntervalosSondaLongitudinalMYG(
                intervalos);

        double coordenadaOrigen =
            (origenSonda - origenMarco)
                .DotProduct(eje);

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

        IntervaloColumnaSerie elegido =
            intervalos
                .Where(x =>
                    coordenadaOrigen >=
                        x.Min - tolerancia &&
                    coordenadaOrigen <=
                        x.Max + tolerancia)
                .OrderByDescending(
                    x => x.Width)
                .FirstOrDefault();

        if (elegido == null)
        {
            elegido =
                intervalos
                    .OrderByDescending(
                        x => x.Width)
                    .FirstOrDefault();
        }

        if (elegido == null ||
            elegido.Width <= Tol)
        {
            return false;
        }

        valorMin =
            elegido.Min;

        valorMax =
            elegido.Max;

        return true;
    }

    private List<IntervaloColumnaSerie>
        FusionarIntervalosSondaLongitudinalMYG(
            List<IntervaloColumnaSerie> intervalos)
    {
        List<IntervaloColumnaSerie> resultado =
            new List<IntervaloColumnaSerie>();

        if (intervalos == null ||
            intervalos.Count == 0)
        {
            return resultado;
        }

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

        foreach (IntervaloColumnaSerie actual in
            intervalos
                .Where(x => x != null)
                .OrderBy(x => x.Min))
        {
            if (resultado.Count == 0)
            {
                resultado.Add(
                    new IntervaloColumnaSerie(
                        actual.Min,
                        actual.Max));

                continue;
            }

            IntervaloColumnaSerie ultimo =
                resultado[
                    resultado.Count - 1];

            if (actual.Min <=
                ultimo.Max + tolerancia)
            {
                ultimo.Max =
                    Math.Max(
                        ultimo.Max,
                        actual.Max);
            }
            else
            {
                resultado.Add(
                    new IntervaloColumnaSerie(
                        actual.Min,
                        actual.Max));
            }
        }

        return resultado;
    }

    private double CalcularFactorLongitudCurvaSeguroMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        int cantidad,
        int indiceBarra,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central)
    {
        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            serie.LongitudTotal <= Tol)
        {
            return 1.0;
        }

        double longitudReal =
            0.0;

        double factorMaximo =
            1.0;

        Curve curvaAnterior =
            null;

        foreach (TramoSerieCurvaLongitudinalMYG tramo
            in serie.Tramos)
        {
            if (tramo == null ||
                tramo.Longitud <= Tol)
            {
                continue;
            }

            List<Curve> candidatas =
                new List<Curve>();

            Curve offset =
                CrearCurvaOffsetTramoSerieMYG(
                    tramo,
                    cantidad,
                    indiceBarra,
                    diametro,
                    offsetVerticalDesdeCara,
                    superior,
                    central);

            if (offset != null &&
                offset.IsBound &&
                offset.Length > Tol)
            {
                candidatas.Add(offset);
            }

            Curve adaptada =
                CrearTrayectoriaLongitudinalAdaptadaAlSolidoMYG(
                    tramo,
                    cantidad,
                    indiceBarra,
                    diametro,
                    offsetVerticalDesdeCara,
                    superior,
                    central);

            if (adaptada != null &&
                adaptada.IsBound &&
                adaptada.Length > Tol)
            {
                candidatas.Add(adaptada);
            }

            Curve primeraActual =
                null;

            Curve ultimaActual =
                null;

            double longitudTramoReal =
                0.0;

            foreach (Curve candidata in candidatas)
            {
                List<Curve> dentro =
                    ObtenerCurvasDentroDelSolidoTramoMYG(
                        tramo,
                        candidata);

                if (dentro == null ||
                    dentro.Count == 0)
                {
                    continue;
                }

                longitudTramoReal =
                    dentro.Sum(c =>
                        c != null
                            ? c.Length
                            : 0.0);

                primeraActual =
                    dentro.FirstOrDefault();

                ultimaActual =
                    dentro.LastOrDefault();

                if (longitudTramoReal > Tol)
                    break;
            }

            if (longitudTramoReal <= Tol)
            {
                longitudReal +=
                    tramo.Longitud;

                curvaAnterior =
                    null;

                continue;
            }

            longitudReal +=
                longitudTramoReal;

            factorMaximo =
                Math.Max(
                    factorMaximo,
                    longitudTramoReal /
                    tramo.Longitud);

            if (curvaAnterior != null &&
                primeraActual != null)
            {
                Curve conector =
                    CrearConectorSuaveEntreTramosMYG(
                        curvaAnterior,
                        primeraActual);

                if (conector != null &&
                    conector.Length > Tol)
                {
                    longitudReal +=
                        conector.Length;
                }
                else
                {
                    XYZ a =
                        curvaAnterior.GetEndPoint(1);

                    XYZ b =
                        primeraActual.GetEndPoint(0);

                    if (a != null &&
                        b != null)
                    {
                        longitudReal +=
                            a.DistanceTo(b);
                    }
                }
            }

            curvaAnterior =
                ultimaActual;
        }

        double factorGlobal =
            longitudReal > Tol
                ? longitudReal /
                  serie.LongitudTotal
                : 1.0;

        // Margen de 1 % para recortes, aproximación de splines y tolerancias.
        // La longitud comercial sigue incluyendo tramos vacíos y conectores.
        return Math.Max(
            1.0,
            Math.Max(
                factorMaximo,
                factorGlobal) *
            1.01);
    }

    private double CalcularLongitudEjeComercialCurvaMYG(
        double longitudBarraMaxima,
        double factorLongitud,
        double longitudEmpalme,
        double diametro)
    {
        if (longitudBarraMaxima <= Tol)
            return longitudBarraMaxima;

        double longitudDiagonal =
            UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

        double desfase =
            ObtenerDesfaseEmpalmeCaraACara(
                diametro);

        double extraDiagonal =
            0.0;

        if (longitudEmpalme > Tol &&
            longitudDiagonal > Tol &&
            desfase > Tol)
        {
            extraDiagonal =
                Math.Sqrt(
                    longitudDiagonal *
                    longitudDiagonal +
                    desfase *
                    desfase) -
                longitudDiagonal;
        }

        // Reserva adicional para redondeos de Revit, conectores y diferencias
        // entre la longitud del eje del anfitrión y la trayectoria offset real.
        double margenSeguridad =
            UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters);

        double longitudUtil =
            longitudBarraMaxima -
            extraDiagonal -
            margenSeguridad;

        double minimoUtil =
            longitudEmpalme > Tol
                ? longitudEmpalme +
                  UnitUtils.ConvertToInternalUnits(
                      25.0,
                      UnitTypeId.Centimeters)
                : UnitUtils.ConvertToInternalUnits(
                      25.0,
                      UnitTypeId.Centimeters);

        if (longitudUtil < minimoUtil)
            longitudUtil = Math.Min(
                longitudBarraMaxima,
                minimoUtil);

        return longitudUtil /
            Math.Max(
                1.0,
                factorLongitud);
    }





    private void AgregarCurvaContinuaMYG(
        List<Curve> destino,
        Curve curva)
    {
        if (destino == null || curva == null || curva.Length <= Tol)
            return;

        if (destino.Count == 0)
        {
            destino.Add(curva);
            return;
        }

        Curve anterior = destino[destino.Count - 1];

        if (anterior == null || anterior.Length <= Tol)
        {
            destino.Add(curva);
            return;
        }

        XYZ finAnterior = anterior.GetEndPoint(1);
        XYZ inicioNueva = curva.GetEndPoint(0);

        if (finAnterior == null || inicioNueva == null)
        {
            destino.Add(curva);
            return;
        }

        double distancia = finAnterior.DistanceTo(inicioNueva);
        double toleranciaPunto = UnitUtils.ConvertToInternalUnits(
            0.20,
            UnitTypeId.Centimeters);

        if (distancia <= toleranciaPunto)
        {
            destino.Add(curva);
            return;
        }

        // =========================================================
        // CONECTOR TANGENCIAL ENTRE DOS BOCETOS INDEPENDIENTES
        // =========================================================
        // No se une directamente finAnterior -> inicioNueva, porque esa línea
        // casi nunca es tangente a ambos arcos y Revit rechaza la barra.
        // Se generan uno o dos tramos rectos:
        //   curva anterior -- línea tangente -- quiebre -- línea tangente -- curva siguiente
        // El único quiebre queda entre dos líneas, que Revit puede resolver con
        // el radio de doblado del tipo de barra.
        XYZ tangenteAnterior = ObtenerTangenteCurvaMYG(anterior, 1.0);
        XYZ tangenteNueva = ObtenerTangenteCurvaMYG(curva, 0.0);

        if (tangenteAnterior == null || tangenteNueva == null ||
            tangenteAnterior.GetLength() <= Tol || tangenteNueva.GetLength() <= Tol)
        {
            destino.Add(Line.CreateBound(finAnterior, inicioNueva));
            destino.Add(curva);
            return;
        }

        tangenteAnterior = tangenteAnterior.Normalize();
        tangenteNueva = tangenteNueva.Normalize();

        XYZ vectorDirecto = inicioNueva - finAnterior;
        XYZ direccionDirecta = vectorDirecto.GetLength() > Tol
            ? vectorDirecto.Normalize()
            : tangenteAnterior;

        double cosAnterior = Math.Abs(direccionDirecta.DotProduct(tangenteAnterior));
        double cosNueva = Math.Abs(direccionDirecta.DotProduct(tangenteNueva));

        // Si el hueco ya está prácticamente alineado con las dos tangentes,
        // basta una única recta.
        if (cosAnterior >= 0.985 && cosNueva >= 0.985)
        {
            destino.Add(Line.CreateBound(finAnterior, inicioNueva));
            destino.Add(curva);
            return;
        }

        XYZ normalPlano = tangenteAnterior.CrossProduct(tangenteNueva);

        if (normalPlano.GetLength() <= Tol)
            normalPlano = XYZ.BasisZ;
        else
            normalPlano = normalPlano.Normalize();

        if (normalPlano.DotProduct(XYZ.BasisZ) < 0.0)
            normalPlano = normalPlano.Multiply(-1.0);

        XYZ puntoInterseccion;
        double avanceAnterior;
        double retrocesoNueva;

        bool tieneInterseccion = TryIntersecarRayosTangentesMYG(
            finAnterior,
            tangenteAnterior,
            inicioNueva,
            tangenteNueva,
            normalPlano,
            out puntoInterseccion,
            out avanceAnterior,
            out retrocesoNueva);

        double longitudMinimaTramo = UnitUtils.ConvertToInternalUnits(
            8.0,
            UnitTypeId.Centimeters);

        double longitudMaximaInterseccion = Math.Max(
            UnitUtils.ConvertToInternalUnits(250.0, UnitTypeId.Centimeters),
            distancia * 4.0);

        if (tieneInterseccion &&
            puntoInterseccion != null &&
            avanceAnterior >= -toleranciaPunto &&
            retrocesoNueva >= -toleranciaPunto &&
            finAnterior.DistanceTo(puntoInterseccion) <= longitudMaximaInterseccion &&
            puntoInterseccion.DistanceTo(inicioNueva) <= longitudMaximaInterseccion)
        {
            double l1 = finAnterior.DistanceTo(puntoInterseccion);
            double l2 = puntoInterseccion.DistanceTo(inicioNueva);

            if (l1 > toleranciaPunto && l2 > toleranciaPunto)
            {
                destino.Add(Line.CreateBound(finAnterior, puntoInterseccion));
                destino.Add(Line.CreateBound(puntoInterseccion, inicioNueva));
                destino.Add(curva);
                return;
            }

            if (l1 > toleranciaPunto)
            {
                destino.Add(Line.CreateBound(finAnterior, puntoInterseccion));
                destino.Add(curva);
                return;
            }

            if (l2 > toleranciaPunto)
            {
                destino.Add(Line.CreateBound(puntoInterseccion, inicioNueva));
                destino.Add(curva);
                return;
            }
        }

        // Respaldo para tangentes paralelas o divergentes: dos patas tangentes
        // y una recta central. Los encuentros con los arcos siguen siendo tangentes;
        // los quiebres quedan solo entre líneas rectas.
        double pata = Math.Max(
            longitudMinimaTramo,
            Math.Min(
                UnitUtils.ConvertToInternalUnits(60.0, UnitTypeId.Centimeters),
                distancia * 0.30));

        XYZ pA = finAnterior.Add(tangenteAnterior.Multiply(pata));
        XYZ pB = inicioNueva.Subtract(tangenteNueva.Multiply(pata));

        if (finAnterior.DistanceTo(pA) > toleranciaPunto)
            destino.Add(Line.CreateBound(finAnterior, pA));

        if (pA.DistanceTo(pB) > toleranciaPunto)
            destino.Add(Line.CreateBound(pA, pB));

        if (pB.DistanceTo(inicioNueva) > toleranciaPunto)
            destino.Add(Line.CreateBound(pB, inicioNueva));

        destino.Add(curva);
    }

    private bool TryIntersecarRayosTangentesMYG(
        XYZ p0,
        XYZ t0,
        XYZ p1,
        XYZ t1,
        XYZ normalPlano,
        out XYZ interseccion,
        out double avanceDesdeP0,
        out double retrocesoDesdeP1)
    {
        interseccion = null;
        avanceDesdeP0 = 0.0;
        retrocesoDesdeP1 = 0.0;

        if (p0 == null || p1 == null || t0 == null || t1 == null ||
            normalPlano == null || t0.GetLength() <= Tol ||
            t1.GetLength() <= Tol || normalPlano.GetLength() <= Tol)
        {
            return false;
        }

        XYZ u = t0.Normalize();
        XYZ v = t1.Normalize().Multiply(-1.0);
        XYZ n = normalPlano.Normalize();
        XYZ d = p1 - p0;

        double denominador = u.CrossProduct(v).DotProduct(n);

        if (Math.Abs(denominador) <= 1e-9)
            return false;

        avanceDesdeP0 = d.CrossProduct(v).DotProduct(n) / denominador;
        retrocesoDesdeP1 = d.CrossProduct(u).DotProduct(n) / denominador;
        interseccion = p0.Add(u.Multiply(avanceDesdeP0));

        return interseccion != null;
    }

    private Curve AlinearCurvaAPlanoSerieMYG(
        Curve curva,
        XYZ origenPlano,
        XYZ normalPlano)
    {
        if (curva == null || origenPlano == null || normalPlano == null ||
            normalPlano.GetLength() <= Tol)
        {
            return curva;
        }

        XYZ n = normalPlano.Normalize();
        XYZ p0 = curva.GetEndPoint(0);
        XYZ p1 = curva.GetEndPoint(1);
        XYZ pm = null;

        try
        {
            pm = curva.Evaluate(0.5, true);
        }
        catch
        {
            pm = (p0 + p1).Multiply(0.5);
        }

        double d0 = (p0 - origenPlano).DotProduct(n);
        double d1 = (p1 - origenPlano).DotProduct(n);
        double dm = (pm - origenPlano).DotProduct(n);
        double promedio = (d0 + d1 + dm) / 3.0;
        double variacion = Math.Max(
            Math.Abs(d0 - promedio),
            Math.Max(Math.Abs(d1 - promedio), Math.Abs(dm - promedio)));

        double toleranciaNoParalela = UnitUtils.ConvertToInternalUnits(
            2.0,
            UnitTypeId.Centimeters);

        if (variacion > toleranciaNoParalela)
        {
            ultimoErrorCurvaMYG =
                "Los tramos seleccionados no son suficientemente coplanares para formar una sola barra. " +
                "Variación fuera del plano: " +
                UnitUtils.ConvertFromInternalUnits(variacion, UnitTypeId.Centimeters).ToString("0.##") +
                " cm.";
            return null;
        }

        if (Math.Abs(promedio) <= Tol)
            return curva;

        try
        {
            Transform traslado = Transform.CreateTranslation(n.Multiply(-promedio));
            return curva.CreateTransformed(traslado);
        }
        catch
        {
            return null;
        }
    }

    private IList<Curve> LimpiarCurvasCadenaMYG(
        IList<Curve> curvas)
    {
        List<Curve> resultado = new List<Curve>();

        if (curvas == null)
            return resultado;

        double longitudMinima = UnitUtils.ConvertToInternalUnits(
            0.05,
            UnitTypeId.Centimeters);

        foreach (Curve curva in curvas)
        {
            if (curva == null || curva.Length <= longitudMinima)
                continue;

            resultado.Add(curva);
        }

        return resultado;
    }


    // =========================================================
    // CORRESPONDENCIA LATERAL ESPECÍFICA POR CAPA
    // =========================================================
    // La orientación izquierda/derecha se resuelve nuevamente para cada capa.
    // Se utilizan los puntos extremos de las barras que esa capa realmente
    // intentará crear, incluyendo diámetro, recubrimiento, altura y adaptación
    // al sólido. Esto es especialmente importante para:
    // - acero central, que solo tiene dos barras;
    // - capas 2, 3 y 4, cuyos diámetros y alturas pueden ser distintos;
    // - vigas con ejes locales Y invertidos entre anfitriones.
    private void ActualizarCorrespondenciaLateralConfiguracionMYG(
        DatosSerieCurvaLongitudinalMYG serie,
        int cantidad,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central)
    {
        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0)
        {
            return;
        }

        int n = Math.Max(1, cantidad);

        serie.Tramos[0].InvertirOrdenLateral = false;

        for (int iTramo = 1;
             iTramo < serie.Tramos.Count;
             iTramo++)
        {
            TramoSerieCurvaLongitudinalMYG anterior =
                serie.Tramos[iTramo - 1];

            TramoSerieCurvaLongitudinalMYG actual =
                serie.Tramos[iTramo];

            if (anterior == null ||
                actual == null ||
                anterior.Eje == null ||
                actual.Eje == null)
            {
                if (actual != null)
                    actual.InvertirOrdenLateral = false;

                continue;
            }

            double costoSinInvertir = 0.0;
            double costoInvertido = 0.0;
            int paresValidos = 0;

            for (int indiceLogico = 0;
                 indiceLogico < n;
                 indiceLogico++)
            {
                XYZ puntoAnterior =
                    ObtenerPuntoExtremoConfiguracionLateralMYG(
                        anterior,
                        n,
                        indiceLogico,
                        diametro,
                        offsetVerticalDesdeCara,
                        superior,
                        central,
                        true,
                        anterior.InvertirOrdenLateral);

                XYZ puntoActualSinInvertir =
                    ObtenerPuntoExtremoConfiguracionLateralMYG(
                        actual,
                        n,
                        indiceLogico,
                        diametro,
                        offsetVerticalDesdeCara,
                        superior,
                        central,
                        false,
                        false);

                XYZ puntoActualInvertido =
                    ObtenerPuntoExtremoConfiguracionLateralMYG(
                        actual,
                        n,
                        indiceLogico,
                        diametro,
                        offsetVerticalDesdeCara,
                        superior,
                        central,
                        false,
                        true);

                if (puntoAnterior == null ||
                    puntoActualSinInvertir == null ||
                    puntoActualInvertido == null)
                {
                    continue;
                }

                costoSinInvertir +=
                    puntoAnterior.DistanceTo(
                        puntoActualSinInvertir);

                costoInvertido +=
                    puntoAnterior.DistanceTo(
                        puntoActualInvertido);

                paresValidos++;
            }

            double toleranciaCosto =
                UnitUtils.ConvertToInternalUnits(
                    0.1,
                    UnitTypeId.Centimeters);

            if (paresValidos > 0 &&
                Math.Abs(costoSinInvertir - costoInvertido) >
                toleranciaCosto)
            {
                actual.InvertirOrdenLateral =
                    costoInvertido <
                    costoSinInvertir;

                continue;
            }

            // Empate o imposibilidad de reconstruir algún punto:
            // se transporta la dirección lateral efectiva del tramo anterior.
            XYZ centroAnterior;
            XYZ tangenteAnterior;
            XYZ ejeYAnterior;
            XYZ ejeZAnterior;

            XYZ centroActual;
            XYZ tangenteActual;
            XYZ ejeYActual;
            XYZ ejeZActual;

            bool okAnterior =
                ObtenerMarcoCurvaLongitudinalMYG(
                    anterior.Eje,
                    anterior.Longitud,
                    out centroAnterior,
                    out tangenteAnterior,
                    out ejeYAnterior,
                    out ejeZAnterior);

            bool okActual =
                ObtenerMarcoCurvaLongitudinalMYG(
                    actual.Eje,
                    0.0,
                    out centroActual,
                    out tangenteActual,
                    out ejeYActual,
                    out ejeZActual);

            if (!okAnterior ||
                !okActual ||
                ejeYAnterior == null ||
                ejeYActual == null ||
                ejeYAnterior.GetLength() <= Tol ||
                ejeYActual.GetLength() <= Tol)
            {
                actual.InvertirOrdenLateral =
                    anterior.InvertirOrdenLateral;

                continue;
            }

            XYZ direccionLogicaAnterior =
                ejeYAnterior.Normalize();

            if (anterior.InvertirOrdenLateral)
            {
                direccionLogicaAnterior =
                    direccionLogicaAnterior.Multiply(-1.0);
            }

            double producto =
                direccionLogicaAnterior.DotProduct(
                    ejeYActual.Normalize());

            actual.InvertirOrdenLateral =
                producto < 0.0;
        }
    }

    private XYZ ObtenerPuntoExtremoConfiguracionLateralMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        int cantidad,
        int indiceLogico,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        bool central,
        bool usarFinal,
        bool inversionForzada)
    {
        if (tramo == null ||
            tramo.Eje == null ||
            tramo.Longitud <= Tol)
        {
            return null;
        }

        bool inversionOriginal =
            tramo.InvertirOrdenLateral;

        try
        {
            tramo.InvertirOrdenLateral =
                inversionForzada;

            Curve curva =
                CrearTrayectoriaLongitudinalAdaptadaAlSolidoMYG(
                    tramo,
                    cantidad,
                    indiceLogico,
                    diametro,
                    offsetVerticalDesdeCara,
                    superior,
                    central);

            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                curva =
                    CrearCurvaOffsetTramoSerieMYG(
                        tramo,
                        cantidad,
                        indiceLogico,
                        diametro,
                        offsetVerticalDesdeCara,
                        superior,
                        central);
            }

            if (curva == null ||
                !curva.IsBound ||
                curva.Length <= Tol)
            {
                return null;
            }

            XYZ ejeInicio =
                tramo.Eje.GetEndPoint(0);

            XYZ ejeFin =
                tramo.Eje.GetEndPoint(1);

            XYZ curvaInicio =
                curva.GetEndPoint(0);

            XYZ curvaFin =
                curva.GetEndPoint(1);

            if (ejeInicio == null ||
                ejeFin == null ||
                curvaInicio == null ||
                curvaFin == null)
            {
                return null;
            }

            double costoMismoSentido =
                curvaInicio.DistanceTo(ejeInicio) +
                curvaFin.DistanceTo(ejeFin);

            double costoSentidoOpuesto =
                curvaFin.DistanceTo(ejeInicio) +
                curvaInicio.DistanceTo(ejeFin);

            if (costoSentidoOpuesto + Tol <
                costoMismoSentido)
            {
                XYZ temporal = curvaInicio;
                curvaInicio = curvaFin;
                curvaFin = temporal;
            }

            return usarFinal
                ? curvaFin
                : curvaInicio;
        }
        catch
        {
            return null;
        }
        finally
        {
            tramo.InvertirOrdenLateral =
                inversionOriginal;
        }
    }


    // =========================================================
    // CONECTOR ORDENADO ENTRE DOS LONGITUDINALES REALES
    // =========================================================
    // Los conectores entre anfitriones se crean como Rebar independientes.
    // Una recta entre los extremos reales conserva el orden de carriles y no
    // puede desarrollar el abombamiento lateral de una HermiteSpline calculada
    // independientemente para cada capa.
    private Curve CrearConectorRectoOrdenadoMYG(
        Curve curvaAnterior,
        Curve curvaSiguiente)
    {
        if (curvaAnterior == null ||
            curvaSiguiente == null)
        {
            return null;
        }

        XYZ inicio =
            curvaAnterior.GetEndPoint(1);

        XYZ fin =
            curvaSiguiente.GetEndPoint(0);

        if (inicio == null ||
            fin == null ||
            inicio.DistanceTo(fin) <= Tol)
        {
            return null;
        }

        try
        {
            return Line.CreateBound(
                inicio,
                fin);
        }
        catch
        {
            return null;
        }
    }


    // =========================================================
    // CORRESPONDENCIA LATERAL ENTRE VIGAS CON EJES DIFERENTES
    // =========================================================
    // La barra lógica 1 debe continuar con la barra físicamente más próxima
    // del siguiente tramo. No se asume que los ejes Y locales tengan el mismo
    // sentido, ni que las vigas pertenezcan a un mismo arco.
    private void ActualizarCorrespondenciaLateralSerieMYG(
        List<TramoSerieCurvaLongitudinalMYG> tramos)
    {
        if (tramos == null || tramos.Count == 0)
            return;

        tramos[0].InvertirOrdenLateral = false;

        for (int i = 1; i < tramos.Count; i++)
        {
            TramoSerieCurvaLongitudinalMYG anterior = tramos[i - 1];
            TramoSerieCurvaLongitudinalMYG actual = tramos[i];

            if (anterior == null ||
                actual == null ||
                anterior.Eje == null ||
                actual.Eje == null)
            {
                if (actual != null)
                    actual.InvertirOrdenLateral = false;

                continue;
            }

            XYZ centroAnterior;
            XYZ tangenteAnterior;
            XYZ yAnterior;
            XYZ zAnterior;

            XYZ centroActual;
            XYZ tangenteActual;
            XYZ yActual;
            XYZ zActual;

            bool okAnterior = ObtenerMarcoCurvaLongitudinalMYG(
                anterior.Eje,
                anterior.Longitud,
                out centroAnterior,
                out tangenteAnterior,
                out yAnterior,
                out zAnterior);

            bool okActual = ObtenerMarcoCurvaLongitudinalMYG(
                actual.Eje,
                0.0,
                out centroActual,
                out tangenteActual,
                out yActual,
                out zActual);

            if (!okAnterior || !okActual)
            {
                actual.InvertirOrdenLateral =
                    anterior.InvertirOrdenLateral;

                continue;
            }

            double yMinAnterior = anterior.YMin;
            double yMaxAnterior = anterior.YMax;
            double zMinAnterior = anterior.ZMin;
            double zMaxAnterior = anterior.ZMax;

            double yMinActual = actual.YMin;
            double yMaxActual = actual.YMax;
            double zMinActual = actual.ZMin;
            double zMaxActual = actual.ZMax;

            ObtenerLimitesComunesSeccionTramoCurvoMYG(
                anterior,
                out yMinAnterior,
                out yMaxAnterior,
                out zMinAnterior,
                out zMaxAnterior);

            ObtenerLimitesComunesSeccionTramoCurvoMYG(
                actual,
                out yMinActual,
                out yMaxActual,
                out zMinActual,
                out zMaxActual);

            // Extremos lógicos del tramo anterior, considerando la inversión
            // que ya fue decidida para mantener continuidad desde el inicio.
            double anteriorLogico0 = anterior.InvertirOrdenLateral
                ? yMaxAnterior
                : yMinAnterior;

            double anteriorLogico1 = anterior.InvertirOrdenLateral
                ? yMinAnterior
                : yMaxAnterior;

            XYZ pAnterior0 = centroAnterior.Add(
                yAnterior.Multiply(anteriorLogico0));

            XYZ pAnterior1 = centroAnterior.Add(
                yAnterior.Multiply(anteriorLogico1));

            XYZ pActual0 = centroActual.Add(
                yActual.Multiply(yMinActual));

            XYZ pActual1 = centroActual.Add(
                yActual.Multiply(yMaxActual));

            double costoMismoOrden =
                pAnterior0.DistanceTo(pActual0) +
                pAnterior1.DistanceTo(pActual1);

            double costoOrdenInvertido =
                pAnterior0.DistanceTo(pActual1) +
                pAnterior1.DistanceTo(pActual0);

            double tolerancia =
                UnitUtils.ConvertToInternalUnits(
                    0.1,
                    UnitTypeId.Centimeters);

            actual.InvertirOrdenLateral =
                costoOrdenInvertido + tolerancia <
                costoMismoOrden;
        }
    }

    private int ObtenerIndiceFisicoBarraCurvaMYG(
        TramoSerieCurvaLongitudinalMYG tramo,
        int cantidad,
        int indiceLogico)
    {
        int n = Math.Max(1, cantidad);
        int i = Math.Max(0, Math.Min(n - 1, indiceLogico));

        if (tramo != null && tramo.InvertirOrdenLateral)
            return n - 1 - i;

        return i;
    }


    private DatosSerieCurvaLongitudinalMYG ObtenerDatosSerieCurvaContinuaMYG(
        Document doc,
        List<Element> vigas)
    {
        if (doc == null ||
            vigas == null ||
            vigas.Count == 0)
        {
            return null;
        }

        List<TramoSerieCurvaLongitudinalMYG> tramos =
            new List<TramoSerieCurvaLongitudinalMYG>();

        foreach (Element viga in vigas)
        {
            TramoSerieCurvaLongitudinalMYG tramo =
                ObtenerTramoSerieCurvaLongitudinalMYG(
                    doc,
                    viga);

            if (tramo != null)
                tramos.Add(tramo);
        }

        if (tramos.Count == 0)
            return null;

        tramos =
            OrdenarTramosSerieCurvaPorContinuidadMYG(
                tramos);

        if (tramos == null ||
            tramos.Count == 0)
        {
            return null;
        }

        // Determina una única correspondencia física de izquierda a derecha
        // para toda la serie antes de crear cualquier capa o barra.
        ActualizarCorrespondenciaLateralSerieMYG(
            tramos);

        double cursor =
            0.0;

        XYZ extremoAnterior =
            null;

        foreach (TramoSerieCurvaLongitudinalMYG tramo
            in tramos)
        {
            if (tramo == null ||
                tramo.Eje == null)
            {
                continue;
            }

            XYZ inicio =
                tramo.Eje.GetEndPoint(0);

            XYZ fin =
                tramo.Eje.GetEndPoint(1);

            tramo.HuecoAntes =
                0.0;

            if (extremoAnterior != null &&
                inicio != null)
            {
                double hueco =
                    extremoAnterior.DistanceTo(
                        inicio);

                double tolerancia =
                    UnitUtils.ConvertToInternalUnits(
                        0.2,
                        UnitTypeId.Centimeters);

                if (hueco > tolerancia)
                {
                    tramo.HuecoAntes =
                        hueco;

                    cursor +=
                        hueco;
                }
            }

            tramo.InicioSerie =
                cursor;

            tramo.FinSerie =
                cursor +
                tramo.Longitud;

            cursor =
                tramo.FinSerie;

            extremoAnterior =
                fin;
        }

        TramoSerieCurvaLongitudinalMYG tramoHostPrincipal =
            tramos
                .Where(t =>
                    t != null &&
                    t.Host != null)
                .OrderByDescending(
                    t => t.Longitud)
                .FirstOrDefault();

        DatosSerieCurvaLongitudinalMYG serie =
            new DatosSerieCurvaLongitudinalMYG();

        serie.HostPrincipal =
            tramoHostPrincipal != null
                ? tramoHostPrincipal.Host
                : tramos[0].Host;

        serie.Tramos =
            tramos;

        serie.UsaArcoMaestro =
            false;

        serie.ArcoMaestro =
            null;

        serie.LongitudTotal =
            cursor;

        serie.EjeZ =
            tramos[0].EjeZ;

        if (serie.EjeZ == null ||
            serie.EjeZ.GetLength() <= Tol)
        {
            serie.EjeZ =
                XYZ.BasisZ;
        }
        else
        {
            serie.EjeZ =
                serie.EjeZ.Normalize();
        }

        if (serie.EjeZ.DotProduct(
            XYZ.BasisZ) < 0.0)
        {
            serie.EjeZ =
                serie.EjeZ.Multiply(
                    -1.0);
        }

        return serie;
    }


    private bool IntentarReconstruirArcoMaestroMYG(
        List<TramoSerieCurvaLongitudinalMYG> tramos,
        out Arc arcoMaestro)
    {
        arcoMaestro = null;

        if (tramos == null || tramos.Count == 0)
            return false;

        List<Curve> ejes = tramos
            .Where(t => t != null && t.Eje != null && t.Eje.IsBound && t.Eje.Length > Tol)
            .Select(t => t.Eje)
            .ToList();

        if (ejes.Count != tramos.Count || ejes.Count == 0)
            return false;

        // Al menos uno de los tramos debe aportar curvatura real. Esto evita
        // interpretar accidentalmente una serie completamente recta como círculo.
        if (!ejes.Any(c => !(c is Line)))
            return false;

        AjusteCirculoMaestroLongitudinalMYG ajuste = null;

        if (!IntentarAjustarCirculoMaestroLongitudinalMYG(ejes, out ajuste) ||
            ajuste == null ||
            ajuste.Centro == null ||
            ajuste.Normal == null ||
            ajuste.Radio <= Tol)
        {
            return false;
        }

        XYZ inicioOriginal = ejes[0].GetEndPoint(0);
        XYZ finOriginal = ejes[ejes.Count - 1].GetEndPoint(1);

        XYZ inicio = ProyectarPuntoSobreCirculoMYG(
            inicioOriginal,
            ajuste.Centro,
            ajuste.Normal,
            ajuste.Radio);

        XYZ fin = ProyectarPuntoSobreCirculoMYG(
            finOriginal,
            ajuste.Centro,
            ajuste.Normal,
            ajuste.Radio);

        XYZ medioCadena = ObtenerPuntoMedioCadenaCurvasMYG(ejes);

        XYZ medio = ProyectarPuntoSobreCirculoMYG(
            medioCadena,
            ajuste.Centro,
            ajuste.Normal,
            ajuste.Radio);

        if (inicio == null || fin == null || medio == null)
            return false;

        double toleranciaCoincidencia = UnitUtils.ConvertToInternalUnits(
            0.5,
            UnitTypeId.Centimeters);

        if (inicio.DistanceTo(fin) <= toleranciaCoincidencia)
            return false;

        XYZ vInicio = inicio - ajuste.Centro;
        XYZ vMedio = medio - ajuste.Centro;

        if (vInicio.GetLength() <= Tol || vMedio.GetLength() <= Tol)
            return false;

        if (vInicio.CrossProduct(vMedio).GetLength() <= Tol)
        {
            // El punto exactamente medio puede ser casi diametral. Se prueba un
            // punto situado al 35 % de la cadena para resolver la ambigüedad.
            XYZ puntoAlternativo = ObtenerPuntoEnFraccionCadenaCurvasMYG(ejes, 0.35);
            medio = ProyectarPuntoSobreCirculoMYG(
                puntoAlternativo,
                ajuste.Centro,
                ajuste.Normal,
                ajuste.Radio);

            if (medio == null)
                return false;

            vMedio = medio - ajuste.Centro;

            if (vMedio.GetLength() <= Tol ||
                vInicio.CrossProduct(vMedio).GetLength() <= Tol)
            {
                return false;
            }
        }

        Arc candidato = null;

        try
        {
            candidato = Arc.Create(inicio, fin, medio);
        }
        catch (Exception ex)
        {
            ultimoErrorCurvaMYG =
                "Arc.Create no pudo reconstruir el arco maestro tolerante: " + ex.Message;
            candidato = null;
        }

        if (candidato == null || candidato.Length <= Tol)
            return false;

        XYZ normalCandidato = candidato.Normal;

        if (normalCandidato == null || normalCandidato.GetLength() <= Tol)
            return false;

        normalCandidato = normalCandidato.Normalize();

        // Margen angular de aproximadamente 14°. Permite pequeñas diferencias
        // de plano introducidas al dividir, recortar o volver a unir las vigas.
        if (Math.Abs(normalCandidato.DotProduct(ajuste.Normal.Normalize())) < 0.97)
            return false;

        double longitudEsperada = ejes.Sum(c => c != null ? c.Length : 0.0);
        double toleranciaLongitud = Math.Max(
            UnitUtils.ConvertToInternalUnits(100.0, UnitTypeId.Centimeters),
            longitudEsperada * 0.25);

        if (Math.Abs(candidato.Length - longitudEsperada) > toleranciaLongitud)
        {
            ultimoErrorCurvaMYG =
                "El círculo fue reconocido, pero el arco reconstruido difiere demasiado " +
                "de la longitud acumulada. Esperada: " +
                UnitUtils.ConvertFromInternalUnits(
                    longitudEsperada,
                    UnitTypeId.Meters).ToString("0.###") +
                " m; reconstruida: " +
                UnitUtils.ConvertFromInternalUnits(
                    candidato.Length,
                    UnitTypeId.Meters).ToString("0.###") +
                " m; error radial máximo del ajuste: " +
                UnitUtils.ConvertFromInternalUnits(
                    ajuste.ErrorRadialMaximo,
                    UnitTypeId.Centimeters).ToString("0.#") +
                " cm.";

            return false;
        }

        // Mantiene el sentido de la cadena ordenada.
        if (candidato.GetEndPoint(0).DistanceTo(inicio) >
            candidato.GetEndPoint(1).DistanceTo(inicio))
        {
            try
            {
                candidato = candidato.CreateReversed() as Arc;
            }
            catch
            {
            }
        }

        arcoMaestro = candidato;
        return arcoMaestro != null;
    }

    private bool IntentarAjustarCirculoMaestroLongitudinalMYG(
        List<Curve> ejes,
        out AjusteCirculoMaestroLongitudinalMYG ajuste)
    {
        ajuste = null;

        if (ejes == null || ejes.Count == 0)
            return false;

        List<XYZ> puntos = new List<XYZ>();
        XYZ sumaNormal = new XYZ(0.0, 0.0, 0.0);
        XYZ normalReferencia = XYZ.BasisZ;
        bool tieneNormal = false;

        foreach (Curve eje in ejes)
        {
            if (eje == null || !eje.IsBound || eje.Length <= Tol)
                continue;

            Arc arco = eje as Arc;

            if (arco != null && arco.Normal != null && arco.Normal.GetLength() > Tol)
            {
                XYZ n = arco.Normal.Normalize();

                if (!tieneNormal)
                {
                    normalReferencia = n;
                    tieneNormal = true;
                }

                if (n.DotProduct(normalReferencia) < 0.0)
                    n = n.Multiply(-1.0);

                // Se admite una diferencia de plano moderada. El ajuste final se
                // hace en planta y absorbe las pequeñas imprecisiones del recorte.
                if (Math.Abs(n.DotProduct(normalReferencia)) < 0.94)
                    return false;

                sumaNormal = sumaNormal.Add(n);
            }

            double[] parametros = new double[] { 0.0, 0.25, 0.50, 0.75, 1.0 };

            foreach (double u in parametros)
            {
                try
                {
                    XYZ p = eje.Evaluate(u, true);
                    if (p != null)
                        puntos.Add(p);
                }
                catch
                {
                }
            }
        }

        if (puntos.Count < 3)
            return false;

        double promedioX = puntos.Average(p => p.X);
        double promedioY = puntos.Average(p => p.Y);
        double promedioZ = puntos.Average(p => p.Z);

        double sXX = 0.0;
        double sXY = 0.0;
        double sX = 0.0;
        double sYY = 0.0;
        double sY = 0.0;
        double sQX = 0.0;
        double sQY = 0.0;
        double sQ = 0.0;

        foreach (XYZ p in puntos)
        {
            double x = p.X - promedioX;
            double y = p.Y - promedioY;
            double q = (x * x) + (y * y);

            sXX += x * x;
            sXY += x * y;
            sX += x;
            sYY += y * y;
            sY += y;
            sQX += q * x;
            sQY += q * y;
            sQ += q;
        }

        double d;
        double e;
        double f;

        if (!ResolverSistema3x3LongitudinalMYG(
            sXX, sXY, sX,
            sXY, sYY, sY,
            sX, sY, puntos.Count,
            -sQX, -sQY, -sQ,
            out d, out e, out f))
        {
            return false;
        }

        double centroLocalX = -d / 2.0;
        double centroLocalY = -e / 2.0;
        double radioCuadrado =
            (centroLocalX * centroLocalX) +
            (centroLocalY * centroLocalY) - f;

        if (radioCuadrado <= Tol)
            return false;

        double radio = Math.Sqrt(radioCuadrado);

        // Evita ajustes degenerados de radios desproporcionadamente grandes.
        double radioMaximo = UnitUtils.ConvertToInternalUnits(
            10000.0,
            UnitTypeId.Meters);

        if (radio <= Tol || radio > radioMaximo)
            return false;

        XYZ centro = new XYZ(
            promedioX + centroLocalX,
            promedioY + centroLocalY,
            promedioZ);

        double errorMaximo = 0.0;
        double zMin = puntos.Min(p => p.Z);
        double zMax = puntos.Max(p => p.Z);

        foreach (XYZ p in puntos)
        {
            double distanciaRadial = Math.Sqrt(
                ((p.X - centro.X) * (p.X - centro.X)) +
                ((p.Y - centro.Y) * (p.Y - centro.Y)));

            errorMaximo = Math.Max(
                errorMaximo,
                Math.Abs(distanciaRadial - radio));
        }

        double toleranciaResidual = Math.Max(
            UnitUtils.ConvertToInternalUnits(25.0, UnitTypeId.Centimeters),
            Math.Min(
                UnitUtils.ConvertToInternalUnits(75.0, UnitTypeId.Centimeters),
                radio * 0.03));

        double toleranciaZ = UnitUtils.ConvertToInternalUnits(
            30.0,
            UnitTypeId.Centimeters);

        if (errorMaximo > toleranciaResidual || zMax - zMin > toleranciaZ)
        {
            ultimoErrorCurvaMYG =
                "Los tramos no superaron el ajuste circular tolerante. Error radial máximo: " +
                UnitUtils.ConvertFromInternalUnits(
                    errorMaximo,
                    UnitTypeId.Centimeters).ToString("0.#") +
                " cm; tolerancia: " +
                UnitUtils.ConvertFromInternalUnits(
                    toleranciaResidual,
                    UnitTypeId.Centimeters).ToString("0.#") +
                " cm; variación Z: " +
                UnitUtils.ConvertFromInternalUnits(
                    zMax - zMin,
                    UnitTypeId.Centimeters).ToString("0.#") +
                " cm.";

            return false;
        }

        XYZ normal = sumaNormal.GetLength() > Tol
            ? sumaNormal.Normalize()
            : XYZ.BasisZ;

        if (normal.DotProduct(XYZ.BasisZ) < 0.0)
            normal = normal.Multiply(-1.0);

        ajuste = new AjusteCirculoMaestroLongitudinalMYG();
        ajuste.Centro = centro;
        ajuste.Radio = radio;
        ajuste.Normal = normal;
        ajuste.ErrorRadialMaximo = errorMaximo;
        ajuste.VariacionZ = zMax - zMin;

        return true;
    }

    private bool ResolverSistema3x3LongitudinalMYG(
        double a11, double a12, double a13,
        double a21, double a22, double a23,
        double a31, double a32, double a33,
        double b1, double b2, double b3,
        out double x1, out double x2, out double x3)
    {
        x1 = 0.0;
        x2 = 0.0;
        x3 = 0.0;

        double det =
            a11 * ((a22 * a33) - (a23 * a32)) -
            a12 * ((a21 * a33) - (a23 * a31)) +
            a13 * ((a21 * a32) - (a22 * a31));

        if (Math.Abs(det) <= 1e-12)
            return false;

        double det1 =
            b1 * ((a22 * a33) - (a23 * a32)) -
            a12 * ((b2 * a33) - (a23 * b3)) +
            a13 * ((b2 * a32) - (a22 * b3));

        double det2 =
            a11 * ((b2 * a33) - (a23 * b3)) -
            b1 * ((a21 * a33) - (a23 * a31)) +
            a13 * ((a21 * b3) - (b2 * a31));

        double det3 =
            a11 * ((a22 * b3) - (b2 * a32)) -
            a12 * ((a21 * b3) - (b2 * a31)) +
            b1 * ((a21 * a32) - (a22 * a31));

        x1 = det1 / det;
        x2 = det2 / det;
        x3 = det3 / det;

        return !(double.IsNaN(x1) || double.IsInfinity(x1) ||
                 double.IsNaN(x2) || double.IsInfinity(x2) ||
                 double.IsNaN(x3) || double.IsInfinity(x3));
    }

    private XYZ ObtenerPuntoMedioCadenaCurvasMYG(
        List<Curve> curvas)
    {
        return ObtenerPuntoEnFraccionCadenaCurvasMYG(curvas, 0.50);
    }

    private XYZ ObtenerPuntoEnFraccionCadenaCurvasMYG(
        List<Curve> curvas,
        double fraccion)
    {
        if (curvas == null || curvas.Count == 0)
            return null;

        fraccion = Math.Max(0.0, Math.Min(1.0, fraccion));
        double longitudTotal = curvas.Sum(c => c != null ? c.Length : 0.0);

        if (longitudTotal <= Tol)
            return null;

        double objetivo = longitudTotal * fraccion;
        double acumulado = 0.0;

        foreach (Curve curva in curvas)
        {
            if (curva == null || curva.Length <= Tol)
                continue;

            if (acumulado + curva.Length >= objetivo - Tol)
            {
                double local = objetivo - acumulado;
                double u = Math.Max(0.0, Math.Min(1.0, local / curva.Length));

                try
                {
                    return curva.Evaluate(u, true);
                }
                catch
                {
                    return curva.Evaluate(0.5, true);
                }
            }

            acumulado += curva.Length;
        }

        return curvas[curvas.Count - 1].Evaluate(1.0, true);
    }

    private XYZ ObtenerPuntoMedioCadenaArcosMYG(
        List<Arc> arcos)
    {
        if (arcos == null || arcos.Count == 0)
            return null;

        double longitudTotal = arcos.Sum(a => a != null ? a.Length : 0.0);

        if (longitudTotal <= Tol)
            return null;

        double objetivo = longitudTotal * 0.5;
        double acumulado = 0.0;

        foreach (Arc arco in arcos)
        {
            if (arco == null || arco.Length <= Tol)
                continue;

            if (acumulado + arco.Length >= objetivo - Tol)
            {
                double local = objetivo - acumulado;
                double u = Math.Max(
                    0.0,
                    Math.Min(
                        1.0,
                        local / arco.Length));

                try
                {
                    return arco.Evaluate(u, true);
                }
                catch
                {
                    return arco.Evaluate(0.5, true);
                }
            }

            acumulado += arco.Length;
        }

        return arcos[arcos.Count - 1].Evaluate(0.5, true);
    }

    private XYZ ProyectarPuntoSobreCirculoMYG(
        XYZ punto,
        XYZ centro,
        XYZ normal,
        double radio)
    {
        if (punto == null ||
            centro == null ||
            normal == null ||
            normal.GetLength() <= Tol ||
            radio <= Tol)
        {
            return null;
        }

        XYZ n = normal.Normalize();
        XYZ vector = punto - centro;
        XYZ vectorPlano = vector - n.Multiply(vector.DotProduct(n));

        if (vectorPlano.GetLength() <= Tol)
            return null;

        return centro.Add(
            vectorPlano.Normalize().Multiply(radio));
    }

    private TramoSerieCurvaLongitudinalMYG ObtenerTramoSerieCurvaLongitudinalMYG(
        Document doc,
        Element host)
    {
        if (doc == null || host == null)
            return null;

        LocationCurve lc = host.Location as LocationCurve;

        if (lc == null || lc.Curve == null || !lc.Curve.IsBound)
            return null;

        Curve eje = null;

        try
        {
            eje = lc.Curve.Clone();
        }
        catch
        {
            eje = lc.Curve;
        }

        if (eje == null || eje.Length <= Tol)
            return null;

        XYZ ejeZ = XYZ.BasisZ;

        Arc arco = eje as Arc;

        if (arco != null)
        {
            if (arco.Normal == null || arco.Normal.GetLength() <= Tol)
                return null;

            ejeZ = arco.Normal.Normalize();

            if (ejeZ.DotProduct(XYZ.BasisZ) < 0.0)
                ejeZ = ejeZ.Multiply(-1.0);

            if (Math.Abs(ejeZ.DotProduct(XYZ.BasisZ)) < 0.95)
                return null;
        }
        else
        {
            XYZ a = eje.GetEndPoint(0);
            XYZ b = eje.GetEndPoint(1);

            if (Math.Abs(b.Z - a.Z) > UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters))
            {
                return null;
            }
        }

        XYZ puntoMedio;
        XYZ tangenteMedio;
        XYZ ejeY;
        XYZ zLocal;

        if (!ObtenerMarcoCurvaLongitudinalMYG(
            eje,
            eje.Length * 0.5,
            out puntoMedio,
            out tangenteMedio,
            out ejeY,
            out zLocal))
        {
            return null;
        }

        // En líneas, el método anterior usa BasisZ; en arcos conserva la normal.
        ejeZ = zLocal;

        List<XYZ> puntos = ObtenerPuntosGeometriaTeseladosLongMYG(host);

        if (puntos == null || puntos.Count < 4)
            puntos = ObtenerPuntosBoundingBoxElemento(host);

        if (puntos == null || puntos.Count < 4)
            return null;

        double ventana = Math.Max(
            UnitUtils.ConvertToInternalUnits(12.0, UnitTypeId.Centimeters),
            Math.Min(
                UnitUtils.ConvertToInternalUnits(45.0, UnitTypeId.Centimeters),
                eje.Length * 0.03));

        List<XYZ> cercanos = puntos
            .Where(p => p != null)
            .Where(p => Math.Abs((p - puntoMedio).DotProduct(tangenteMedio)) <= ventana)
            .ToList();

        if (cercanos.Count < 4)
        {
            cercanos = puntos
                .Where(p => p != null)
                .OrderBy(p => Math.Abs((p - puntoMedio).DotProduct(tangenteMedio)))
                .Take(Math.Min(80, puntos.Count))
                .ToList();
        }

        double yMin = double.MaxValue;
        double yMax = double.MinValue;
        double zMin = double.MaxValue;
        double zMax = double.MinValue;

        foreach (XYZ p in cercanos)
        {
            XYZ v = p - puntoMedio;
            double y = v.DotProduct(ejeY);
            double z = v.DotProduct(ejeZ);

            if (y < yMin) yMin = y;
            if (y > yMax) yMax = y;
            if (z < zMin) zMin = z;
            if (z > zMax) zMax = z;
        }

        if (yMax <= yMin + Tol || zMax <= zMin + Tol)
            return null;

        TramoSerieCurvaLongitudinalMYG tramo =
            new TramoSerieCurvaLongitudinalMYG();

        tramo.Host = host;
        tramo.Eje = eje;
        tramo.Longitud = eje.Length;
        tramo.PuntoMedio = puntoMedio;
        tramo.TangenteMedio = tangenteMedio;
        tramo.EjeYMedio = ejeY;
        tramo.EjeZ = ejeZ;
        tramo.YMin = yMin;
        tramo.YMax = yMax;
        tramo.ZMin = zMin;
        tramo.ZMax = zMax;
        // Solo se conserva la banda transversal cercana al punto medio.
        // Guardar toda la geometría del arco ensancha artificialmente el hull Y-Z.
        tramo.PuntosGeometria = cercanos;
        tramo.SolidosGlobales =
            ObtenerSolidosElementoParaValidacionMYG(
                host);
        tramo.HuecoAntes = 0.0;

        return tramo;
    }

    private List<TramoSerieCurvaLongitudinalMYG> OrdenarTramosSerieCurvaPorContinuidadMYG(
        List<TramoSerieCurvaLongitudinalMYG> entrada)
    {
        List<TramoSerieCurvaLongitudinalMYG> pendientes = entrada
            .Where(t => t != null && t.Eje != null && t.Longitud > Tol)
            .ToList();

        List<TramoSerieCurvaLongitudinalMYG> resultado =
            new List<TramoSerieCurvaLongitudinalMYG>();

        if (pendientes.Count == 0)
            return resultado;

        double toleranciaUnion = UnitUtils.ConvertToInternalUnits(
            35.0,
            UnitTypeId.Centimeters);

        // Busca un extremo libre para iniciar la cadena. Si todos están cerrados,
        // se conserva el primer tramo de la selección.
        TramoSerieCurvaLongitudinalMYG inicial = pendientes[0];
        bool invertirInicial = false;
        int mejorVecinos = int.MaxValue;

        foreach (TramoSerieCurvaLongitudinalMYG candidato in pendientes)
        {
            for (int extremo = 0; extremo < 2; extremo++)
            {
                XYZ p = candidato.Eje.GetEndPoint(extremo);
                int vecinos = 0;

                foreach (TramoSerieCurvaLongitudinalMYG otro in pendientes)
                {
                    if (ReferenceEquals(candidato, otro))
                        continue;

                    double d0 = p.DistanceTo(otro.Eje.GetEndPoint(0));
                    double d1 = p.DistanceTo(otro.Eje.GetEndPoint(1));

                    if (Math.Min(d0, d1) <= toleranciaUnion)
                        vecinos++;
                }

                if (vecinos < mejorVecinos)
                {
                    mejorVecinos = vecinos;
                    inicial = candidato;
                    invertirInicial = extremo == 1;
                }
            }
        }

        pendientes.Remove(inicial);

        if (invertirInicial)
            InvertirTramoSerieCurvaMYG(inicial);

        resultado.Add(inicial);

        while (pendientes.Count > 0)
        {
            XYZ extremoActual = resultado[resultadosLastIndexMYG(resultado)].Eje.GetEndPoint(1);
            TramoSerieCurvaLongitudinalMYG mejor = null;
            bool invertir = false;
            double mejorDistancia = double.MaxValue;

            foreach (TramoSerieCurvaLongitudinalMYG candidato in pendientes)
            {
                double d0 = extremoActual.DistanceTo(candidato.Eje.GetEndPoint(0));
                double d1 = extremoActual.DistanceTo(candidato.Eje.GetEndPoint(1));

                if (d0 < mejorDistancia)
                {
                    mejorDistancia = d0;
                    mejor = candidato;
                    invertir = false;
                }

                if (d1 < mejorDistancia)
                {
                    mejorDistancia = d1;
                    mejor = candidato;
                    invertir = true;
                }
            }

            if (mejor == null)
                break;

            // No se impone una distancia máxima entre los elementos seleccionados.
            // La selección puede contener vigas con centros/radios diferentes,
            // apoyos intermedios o vacíos amplios. La distancia real hasta el
            // siguiente tramo se incorpora después a la longitud comercial.
            pendientes.Remove(mejor);

            if (invertir)
                InvertirTramoSerieCurvaMYG(mejor);

            resultado.Add(mejor);
        }

        return resultado;
    }

    // Método mínimo para evitar indexadores complejos dentro de expresiones largas.
    private int resultadosLastIndexMYG(
        List<TramoSerieCurvaLongitudinalMYG> tramos)
    {
        return tramos == null || tramos.Count == 0 ? 0 : tramos.Count - 1;
    }

    private void InvertirTramoSerieCurvaMYG(
        TramoSerieCurvaLongitudinalMYG tramo)
    {
        if (tramo == null || tramo.Eje == null)
            return;

        try
        {
            tramo.Eje = tramo.Eje.CreateReversed();
        }
        catch
        {
            return;
        }

        tramo.Longitud = tramo.Eje.Length;

        XYZ punto;
        XYZ tangente;
        XYZ ejeY;
        XYZ ejeZ;

        if (ObtenerMarcoCurvaLongitudinalMYG(
            tramo.Eje,
            tramo.Longitud * 0.5,
            out punto,
            out tangente,
            out ejeY,
            out ejeZ))
        {
            // Al invertir la tangente, el eje Y también cambia de signo.
            double yMinAnterior = tramo.YMin;
            double yMaxAnterior = tramo.YMax;

            tramo.PuntoMedio = punto;
            tramo.TangenteMedio = tangente;
            tramo.EjeYMedio = ejeY;
            tramo.EjeZ = ejeZ;
            tramo.YMin = -yMaxAnterior;
            tramo.YMax = -yMinAnterior;
        }
    }

    private DatosSerieVigas CrearDatosSerieLogicaCurvaContinuaMYG(
        DatosSerieCurvaLongitudinalMYG serie)
    {
        if (serie == null ||
            serie.Tramos == null ||
            serie.Tramos.Count == 0 ||
            serie.HostPrincipal == null)
        {
            return null;
        }

        TramoSerieCurvaLongitudinalMYG primero =
            serie.Tramos.First();

        TramoSerieCurvaLongitudinalMYG ultimo =
            serie.Tramos.Last();

        DatosSerieVigas datos =
            new DatosSerieVigas();

        datos.Host =
            serie.HostPrincipal;

        datos.PInicio =
            primero.Eje.GetEndPoint(0);

        datos.PFin =
            ultimo.Eje.GetEndPoint(1);

        datos.XAxis =
            ObtenerTangenteCurvaMYG(
                primero.Eje,
                0.0) ??
            primero.TangenteMedio;

        datos.YAxis =
            primero.EjeYMedio;

        datos.ZAxis =
            serie.EjeZ;

        datos.LongitudTotal =
            serie.LongitudTotal;

        datos.Ancho =
            primero.YMax -
            primero.YMin;

        datos.Alto =
            primero.ZMax -
            primero.ZMin;

        datos.CentroY =
            (primero.YMin +
             primero.YMax) /
            2.0;

        datos.CentroZ =
            (primero.ZMin +
             primero.ZMax) /
            2.0;

        datos.SolidoMinGlobal =
            0.0;

        datos.SolidoMaxGlobal =
            serie.LongitudTotal;

        datos.LuzLibreInicioGlobal =
            0.0;

        datos.LuzLibreFinGlobal =
            serie.LongitudTotal;

        datos.InicioUtilArmaduraSerie =
            0.0;

        datos.FinUtilArmaduraSerie =
            serie.LongitudTotal;

        datos.Columnas =
            new List<IntervaloColumnaSerie>();

        datos.OrigenGlobal =
            datos.PInicio;

        datos.Vigas =
            new List<DatosViga>();

        datos.TramosRecorrido =
            new List<TramoRecorridoSerie>();

        // Se registran exclusivamente los intervalos con concreto. Los vacíos
        // permanecen fuera de TramosRecorrido, pero sí forman parte de
        // LongitudTotal. Esto permite que el cálculo de piezas comerciales
        // cuente el vacío y, al mismo tiempo, evite ubicar una pieza completa
        // únicamente dentro del aire.
        foreach (TramoSerieCurvaLongitudinalMYG tramo
            in serie.Tramos)
        {
            if (tramo == null ||
                tramo.Host == null ||
                tramo.Eje == null ||
                tramo.Longitud <= Tol)
            {
                continue;
            }

            DatosViga vigaLogica =
                new DatosViga();

            vigaLogica.Elemento =
                tramo.Host;

            vigaLogica.P0 =
                tramo.Eje.GetEndPoint(0);

            vigaLogica.P1 =
                tramo.Eje.GetEndPoint(1);

            vigaLogica.XAxis =
                ObtenerTangenteCurvaMYG(
                    tramo.Eje,
                    0.5) ??
                tramo.TangenteMedio;

            vigaLogica.YAxis =
                tramo.EjeYMedio;

            vigaLogica.ZAxis =
                tramo.EjeZ;

            vigaLogica.Longitud =
                tramo.Longitud;

            vigaLogica.SolidoMin =
                0.0;

            vigaLogica.SolidoMax =
                tramo.Longitud;

            vigaLogica.YMin =
                tramo.YMin;

            vigaLogica.YMax =
                tramo.YMax;

            vigaLogica.ZMin =
                tramo.ZMin;

            vigaLogica.ZMax =
                tramo.ZMax;

            vigaLogica.Ancho =
                tramo.YMax -
                tramo.YMin;

            vigaLogica.Alto =
                tramo.ZMax -
                tramo.ZMin;

            vigaLogica.PuntosSolidoGlobal =
                tramo.PuntosGeometria;

            vigaLogica.SolidosGlobales =
                tramo.SolidosGlobales;

            datos.Vigas.Add(
                vigaLogica);

            datos.TramosRecorrido.Add(
                new TramoRecorridoSerie(
                    vigaLogica,
                    tramo.InicioSerie,
                    tramo.FinSerie,
                    0.0,
                    tramo.Longitud));
        }

        return datos;
    }


    // =========================================================
    // VIGAS CURVAS - ACERO LONGITUDINAL
    // =========================================================
    private bool EsElementoVigaCurvaMYG(Element elemento)
    {
        if (elemento == null)
            return false;

        LocationCurve lc = elemento.Location as LocationCurve;

        if (lc == null || lc.Curve == null)
            return false;

        return !(lc.Curve is Line);
    }

    private int CrearAceroLongitudinalEnVigaCurvaMYG(
        Document doc,
        Element host,
        RebarBarType tipoSuperior,
        int cantidadSuperior,
        RebarBarType tipoInferior,
        int cantidadInferior,
        bool crearAceroCentral,
        RebarBarType tipoCentral,
        double recubrimiento,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        if (doc == null || host == null)
            return 0;

        RebarHostData hostData = RebarHostData.GetRebarHostData(host);

        if (hostData == null)
            return 0;

        DatosVigaCurvaLongitudinalMYG datos = ObtenerDatosVigaCurvaLongitudinalMYG(
            doc,
            host);

        if (datos == null || datos.Eje == null || datos.Longitud <= Tol)
            return 0;

        DatosSerieVigas serieRNE = CrearDatosSerieParaCurvaLongitudinalMYG(datos);

        if (serieRNE == null)
            return 0;

        double longitudDesarrolloInicioCurva = longitudDesarrolloInicio;
        double longitudDesarrolloFinCurva = longitudDesarrolloFin;

        IntervaloColumnaSerie apoyoInicio = ObtenerApoyoCurvoInicioMYG(datos.Apoyos);
        IntervaloColumnaSerie apoyoFin = ObtenerApoyoCurvoFinMYG(datos.Apoyos, datos.Longitud);

        double caraLibreInicio = apoyoInicio != null
            ? Math.Max(0.0, Math.Min(datos.Longitud, apoyoInicio.Max))
            : 0.0;

        double caraLibreFin = apoyoFin != null
            ? Math.Max(0.0, Math.Min(datos.Longitud, apoyoFin.Min))
            : datos.Longitud;

        // En modo Auto se conserva el valor entregado por la ventana.
        // La columna se detecta al seleccionar las vigas, pero no se agrega
        // a la geometría ni a la vista preliminar.

        double estacionInicio = desarrolloInicioHabilitado
            ? caraLibreInicio - longitudDesarrolloInicioCurva
            : recubrimiento;

        double estacionFin = desarrolloFinHabilitado
            ? caraLibreFin + longitudDesarrolloFinCurva
            : datos.Longitud - recubrimiento;

        if (estacionFin <= estacionInicio + Tol)
            return 0;

        int contador = 0;

        List<ConfiguracionCapaLongitudinal> capasSuperiores =
            ConstruirConfiguracionCapasLongitudinales(
                true,
                tipoSuperior,
                cantidadSuperior,
                recubrimiento,
                crearEmpalmes);

        List<ConfiguracionCapaLongitudinal> capasInferiores =
            ConstruirConfiguracionCapasLongitudinales(
                false,
                tipoInferior,
                cantidadInferior,
                recubrimiento,
                crearEmpalmes);

        foreach (ConfiguracionCapaLongitudinal capa in capasSuperiores)
        {
            if (capa == null)
                continue;

            contador += CrearCapaLongitudinalCurvaMYG(
                doc,
                datos,
                serieRNE,
                capa.TipoBarra,
                capa.Cantidad,
                capa.Diametro,
                capa.OffsetCentroDesdeCara,
                true,
                estacionInicio,
                estacionFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudBarra,
                capa.TipoElementoTexto,
                1);
        }

        foreach (ConfiguracionCapaLongitudinal capa in capasInferiores)
        {
            if (capa == null)
                continue;

            contador += CrearCapaLongitudinalCurvaMYG(
                doc,
                datos,
                serieRNE,
                capa.TipoBarra,
                capa.Cantidad,
                capa.Diametro,
                capa.OffsetCentroDesdeCara,
                false,
                estacionInicio,
                estacionFin,
                crearEmpalmes,
                longitudEmpalmeInferior,
                longitudBarra,
                capa.TipoElementoTexto,
                -1);
        }

        if (crearAceroCentral && tipoCentral != null)
        {
            double diametroCentral = ObtenerDiametroBarra(tipoCentral);
            double radioCentral = diametroCentral / 2.0;
            double diametroEstribo = ObtenerDiametroEstriboReferenciaDesdeForm();
            double margenLateral = recubrimiento + diametroEstribo + radioCentral;

            double y1 = datos.YMin + margenLateral;
            double y2 = datos.YMax - margenLateral;
            double zCentral = (datos.ZMin + datos.ZMax) / 2.0;

            if (y2 >= y1 - Tol)
            {
                List<double> posicionesCentrales = new List<double>();

                if (Math.Abs(y2 - y1) <= Tol)
                    posicionesCentrales.Add((y1 + y2) / 2.0);
                else
                {
                    posicionesCentrales.Add(y1);
                    posicionesCentrales.Add(y2);
                }

                List<SegmentoAceroLongitudinal> segmentosCentrales =
                    ConstruirSegmentosLongitudinales(
                        serieRNE,
                        0,
                        estacionInicio,
                        estacionFin,
                        crearEmpalmes,
                        longitudBarra,
                        longitudEmpalmeCentral,
                        0.0,
                        0.0,
                        diametroCentral,
                        tipoCentral);

                foreach (double y in posicionesCentrales)
                {
                    contador += CrearBarraCurvaPorSegmentosMYG(
                        doc,
                        datos,
                        tipoCentral,
                        y,
                        zCentral,
                        segmentosCentrales,
                        "Acero longitudinal - Central");
                }
            }
        }

        return contador;
    }

    private int CrearCapaLongitudinalCurvaMYG(
        Document doc,
        DatosVigaCurvaLongitudinalMYG datos,
        DatosSerieVigas serieRNE,
        RebarBarType tipoBarra,
        int cantidad,
        double diametro,
        double offsetVerticalDesdeCara,
        bool superior,
        double estacionInicio,
        double estacionFin,
        bool crearEmpalmes,
        double longitudEmpalme,
        double longitudBarra,
        string tipoElementoTexto,
        int tipoRutaEmpalme)
    {
        if (doc == null || datos == null || tipoBarra == null || cantidad <= 0)
            return 0;

        double radio = diametro / 2.0;
        double diametroEstribo = ObtenerDiametroEstriboReferenciaDesdeForm();
        double margenLateral =
            UnitUtils.ConvertToInternalUnits(
                0.0,
                UnitTypeId.Centimeters);

        // El recubrimiento lateral real es el mismo de la primera capa:
        // recubrimiento + diámetro de estribo + radio longitudinal.
        // Se obtiene desde el offset de capa 1 cuando está disponible.
        double recubrimientoForm = 0.0;

        if (Form != null)
        {
            double recCm;
            if (TryLeerDouble(Form.RecubrimientoTexto, out recCm))
            {
                recubrimientoForm = UnitUtils.ConvertToInternalUnits(
                    recCm,
                    UnitTypeId.Centimeters);
            }
        }

        margenLateral = recubrimientoForm + diametroEstribo + radio;

        double yInicial = datos.YMin + margenLateral;
        double yFinal = datos.YMax - margenLateral;

        if (yFinal < yInicial - Tol)
            return 0;

        double z = superior
            ? datos.ZMax - offsetVerticalDesdeCara
            : datos.ZMin + offsetVerticalDesdeCara;

        List<double> posicionesY = new List<double>();

        if (cantidad == 1 || Math.Abs(yFinal - yInicial) <= Tol)
        {
            posicionesY.Add((yInicial + yFinal) / 2.0);
        }
        else
        {
            double paso = (yFinal - yInicial) / (cantidad - 1);

            for (int i = 0; i < cantidad; i++)
                posicionesY.Add(yInicial + (i * paso));
        }

        List<SegmentoAceroLongitudinal> segmentos =
            ConstruirSegmentosLongitudinales(
                serieRNE,
                tipoRutaEmpalme,
                estacionInicio,
                estacionFin,
                crearEmpalmes,
                longitudBarra,
                longitudEmpalme,
                0.0,
                0.0,
                diametro,
                tipoBarra);

        if (segmentos == null || segmentos.Count == 0)
            return 0;

        int contador = 0;

        foreach (double y in posicionesY)
        {
            contador += CrearBarraCurvaPorSegmentosMYG(
                doc,
                datos,
                tipoBarra,
                y,
                z,
                segmentos,
                tipoElementoTexto);
        }

        return contador;
    }

    private int CrearBarraCurvaPorSegmentosMYG(
        Document doc,
        DatosVigaCurvaLongitudinalMYG datos,
        RebarBarType tipoBarra,
        double offsetY,
        double offsetZ,
        List<SegmentoAceroLongitudinal> segmentos,
        string tipoElementoTexto)
    {
        if (doc == null || datos == null || datos.Host == null || datos.Eje == null)
            return 0;

        if (tipoBarra == null || segmentos == null || segmentos.Count == 0)
            return 0;

        Curve curvaBase = CrearCurvaLongitudinalOffsetMYG(
            datos,
            offsetY,
            offsetZ);

        if (curvaBase == null)
            return 0;

        int creadas = 0;

        foreach (SegmentoAceroLongitudinal segmento in segmentos)
        {
            if (segmento == null || segmento.XFin <= segmento.XInicio + Tol)
                continue;

            IList<Curve> curvas = CrearCadenaCurvaPorEstacionesMYG(
                curvaBase,
                datos.Longitud,
                segmento.XInicio,
                segmento.XFin);

            if (curvas == null || curvas.Count == 0)
                continue;

            Rebar rb = CrearRebarLongitudinalCurvoMYG(
                doc,
                datos.Host,
                tipoBarra,
                datos.EjeZ,
                curvas);

            if (rb == null)
                continue;

            AplicarParametrosInstanciaAceroLongitudinal(
                doc,
                rb,
                datos.Host,
                tipoElementoTexto);

            creadas++;
        }

        return creadas;
    }

    private Curve CrearCurvaLongitudinalOffsetMYG(
        DatosVigaCurvaLongitudinalMYG datos,
        double offsetY,
        double offsetZ)
    {
        if (datos == null || datos.Eje == null)
            return null;

        Curve offset = null;

        if (Math.Abs(offsetY) <= Tol)
        {
            try
            {
                offset = datos.Eje.Clone();
            }
            catch
            {
                offset = null;
            }
        }

        try
        {
            if (offset == null)
                offset = datos.Eje.CreateOffset(offsetY, datos.EjeZ);
        }
        catch
        {
            offset = null;
        }

        if (offset == null)
        {
            try
            {
                offset = datos.Eje.CreateOffset(-offsetY, datos.EjeZ);
            }
            catch
            {
                offset = null;
            }
        }

        if (offset == null)
            return null;

        // Verifica el lado del offset porque el signo de CreateOffset depende
        // de la orientación interna del arco/familia.
        try
        {
            XYZ pBase = datos.Eje.Evaluate(0.5, true);
            XYZ pOff = offset.Evaluate(0.5, true);
            double ladoObtenido = (pOff - pBase).DotProduct(datos.EjeYMedio);

            if ((offsetY > Tol && ladoObtenido < -Tol) ||
                (offsetY < -Tol && ladoObtenido > Tol))
            {
                Curve opuesto = datos.Eje.CreateOffset(-offsetY, datos.EjeZ);

                if (opuesto != null)
                    offset = opuesto;
            }
        }
        catch
        {
        }

        if (Math.Abs(offsetZ) > Tol)
        {
            try
            {
                Transform tr = Transform.CreateTranslation(
                    datos.EjeZ.Multiply(offsetZ));

                offset = offset.CreateTransformed(tr);
            }
            catch
            {
                return null;
            }
        }

        return offset;
    }

    private IList<Curve> CrearCadenaCurvaPorEstacionesMYG(
        Curve curvaBase,
        double longitudEjeReferencia,
        double estacionInicio,
        double estacionFin)
    {
        List<Curve> resultado = new List<Curve>();

        if (curvaBase == null || curvaBase.Length <= Tol)
            return resultado;

        if (longitudEjeReferencia <= Tol)
            return resultado;

        if (estacionFin <= estacionInicio + Tol)
            return resultado;

        double longitud = longitudEjeReferencia;
        XYZ pInicio = curvaBase.GetEndPoint(0);
        XYZ pFin = curvaBase.GetEndPoint(1);

        XYZ tangenteInicio = ObtenerTangenteCurvaMYG(curvaBase, 0.0);
        XYZ tangenteFin = ObtenerTangenteCurvaMYG(curvaBase, 1.0);

        if (estacionInicio < 0.0 && tangenteInicio != null)
        {
            XYZ pExteriorInicio = pInicio.Add(
                tangenteInicio.Multiply(estacionInicio));

            if (pExteriorInicio.DistanceTo(pInicio) > Tol)
                resultado.Add(Line.CreateBound(pExteriorInicio, pInicio));
        }

        double s0 = Math.Max(0.0, estacionInicio);
        double s1 = Math.Min(longitud, estacionFin);

        if (s1 > s0 + Tol)
        {
            Curve subCurva = CrearSubCurvaPorLongitudMYG(
                curvaBase,
                longitudEjeReferencia,
                s0,
                s1);

            if (subCurva != null)
                resultado.Add(subCurva);
        }

        if (estacionFin > longitud && tangenteFin != null)
        {
            XYZ pExteriorFin = pFin.Add(
                tangenteFin.Multiply(estacionFin - longitud));

            if (pFin.DistanceTo(pExteriorFin) > Tol)
                resultado.Add(Line.CreateBound(pFin, pExteriorFin));
        }

        return resultado;
    }

    private Curve CrearSubCurvaPorLongitudMYG(
        Curve curva,
        double longitudEjeReferencia,
        double estacionInicio,
        double estacionFin)
    {
        if (curva == null || curva.Length <= Tol)
            return null;

        if (longitudEjeReferencia <= Tol)
            return null;

        double u0 = Math.Max(0.0, Math.Min(1.0, estacionInicio / longitudEjeReferencia));
        double u1 = Math.Max(0.0, Math.Min(1.0, estacionFin / longitudEjeReferencia));

        if (u1 <= u0 + 1e-9)
            return null;

        try
        {
            Curve copia = curva.Clone();
            double raw0 = curva.GetEndParameter(0);
            double raw1 = curva.GetEndParameter(1);
            double p0 = raw0 + ((raw1 - raw0) * u0);
            double p1 = raw0 + ((raw1 - raw0) * u1);
            copia.MakeBound(p0, p1);
            return copia;
        }
        catch
        {
            try
            {
                XYZ a = curva.Evaluate(u0, true);
                XYZ b = curva.Evaluate(u1, true);
                XYZ m = curva.Evaluate((u0 + u1) / 2.0, true);
                return Arc.Create(a, b, m);
            }
            catch
            {
                return null;
            }
        }
    }

    private XYZ ObtenerTangenteCurvaMYG(Curve curva, double parametroNormalizado)
    {
        if (curva == null)
            return null;

        double u = Math.Max(0.0, Math.Min(1.0, parametroNormalizado));

        try
        {
            Transform d = curva.ComputeDerivatives(u, true);

            if (d != null && d.BasisX != null && d.BasisX.GetLength() > Tol)
                return d.BasisX.Normalize();
        }
        catch
        {
        }

        try
        {
            double du = 1e-5;
            double ua = Math.Max(0.0, u - du);
            double ub = Math.Min(1.0, u + du);
            XYZ a = curva.Evaluate(ua, true);
            XYZ b = curva.Evaluate(ub, true);
            XYZ dir = b - a;

            if (dir.GetLength() > Tol)
                return dir.Normalize();
        }
        catch
        {
        }

        return null;
    }

    // =========================================================
    // CREACIÓN CURVA CONTINUA CON RESPALDOS ROBUSTOS
    // =========================================================
    // 1) Prueba la cadena original en todos los anfitriones seleccionados.
    // 2) Si Revit rechaza las uniones arco/línea, convierte toda la ruta en una
    //    única spline suave y vuelve a probar. Al ser una sola Curve no quedan
    //    pequeñas separaciones ni quiebres de radio cero entre tramos.
    private Rebar CrearRebarLongitudinalCurvoSerieMYG(
        Document doc,
        DatosSerieCurvaLongitudinalMYG serie,
        RebarBarType tipoBarra,
        XYZ normal,
        IList<Curve> curvas)
    {
        if (doc == null || serie == null || tipoBarra == null ||
            curvas == null || curvas.Count == 0)
        {
            ultimoErrorCurvaMYG = "La cadena longitudinal curva llegó vacía a la creación.";
            return null;
        }

        List<Element> hosts = new List<Element>();

        if (serie.HostPrincipal != null)
            hosts.Add(serie.HostPrincipal);

        if (serie.Tramos != null)
        {
            foreach (TramoSerieCurvaLongitudinalMYG tramo in serie.Tramos
                .Where(t => t != null && t.Host != null)
                .OrderByDescending(t => t.Longitud))
            {
                if (!hosts.Any(h => h != null && h.Id.Value == tramo.Host.Id.Value))
                    hosts.Add(tramo.Host);
            }
        }

        List<string> errores = new List<string>();

        foreach (Element host in hosts)
        {
            if (host == null)
                continue;

            if (RebarHostData.GetRebarHostData(host) == null)
            {
                errores.Add("Host " + host.Id.Value.ToString() + ": no admite armadura.");
                continue;
            }

            string errorAnterior = ultimoErrorCurvaMYG;
            ultimoErrorCurvaMYG = string.Empty;

            Rebar rb = CrearRebarLongitudinalCurvoMYG(
                doc,
                host,
                tipoBarra,
                normal,
                curvas);

            if (rb != null)
                return rb;

            if (!string.IsNullOrWhiteSpace(ultimoErrorCurvaMYG))
            {
                errores.Add(
                    "Host " + host.Id.Value.ToString() +
                    " / cadena original: " + ultimoErrorCurvaMYG);
            }

            ultimoErrorCurvaMYG = errorAnterior;
        }

        Curve splineContinua = CrearSplineContinuaDesdeCadenaMYG(
            curvas,
            normal);

        if (splineContinua != null && splineContinua.IsBound && splineContinua.Length > Tol)
        {
            IList<Curve> cadenaSpline = new List<Curve>() { splineContinua };

            foreach (Element host in hosts)
            {
                if (host == null || RebarHostData.GetRebarHostData(host) == null)
                    continue;

                string errorAnterior = ultimoErrorCurvaMYG;
                ultimoErrorCurvaMYG = string.Empty;

                Rebar rb = CrearRebarLongitudinalCurvoMYG(
                    doc,
                    host,
                    tipoBarra,
                    normal,
                    cadenaSpline);

                if (rb != null)
                    return rb;

                if (!string.IsNullOrWhiteSpace(ultimoErrorCurvaMYG))
                {
                    errores.Add(
                        "Host " + host.Id.Value.ToString() +
                        " / spline continua: " + ultimoErrorCurvaMYG);
                }

                ultimoErrorCurvaMYG = errorAnterior;
            }
        }
        else
        {
            errores.Add("No se pudo construir la spline continua de respaldo.");
        }

        ultimoErrorCurvaMYG = errores.Count > 0
            ? string.Join("\n", errores.Take(12))
            : "Revit rechazó la cadena curva sin devolver un detalle adicional.";

        return null;
    }

    private Curve CrearSplineContinuaDesdeCadenaMYG(
        IList<Curve> curvas,
        XYZ normalPlano)
    {
        if (curvas == null || curvas.Count == 0)
            return null;

        List<Curve> validas = curvas
            .Where(c => c != null && c.IsBound && c.Length > Tol)
            .ToList();

        if (validas.Count == 0)
            return null;

        XYZ normal = normalPlano != null && normalPlano.GetLength() > Tol
            ? normalPlano.Normalize()
            : XYZ.BasisZ;

        XYZ origenPlano = validas[0].GetEndPoint(0);
        List<XYZ> puntos = new List<XYZ>();

        double pasoObjetivo = UnitUtils.ConvertToInternalUnits(
            35.0,
            UnitTypeId.Centimeters);

        double toleranciaDuplicado = UnitUtils.ConvertToInternalUnits(
            0.10,
            UnitTypeId.Centimeters);

        foreach (Curve curva in validas)
        {
            int divisiones = Math.Max(
                1,
                Math.Min(40, (int)Math.Ceiling(curva.Length / pasoObjetivo)));

            for (int i = 0; i <= divisiones; i++)
            {
                double u = divisiones <= 0 ? 0.0 : (double)i / (double)divisiones;
                XYZ p = null;

                try
                {
                    p = curva.Evaluate(u, true);
                }
                catch
                {
                    p = null;
                }

                if (p == null)
                    continue;

                double fueraPlano = (p - origenPlano).DotProduct(normal);
                p = p.Subtract(normal.Multiply(fueraPlano));

                if (puntos.Count == 0 ||
                    puntos[puntos.Count - 1].DistanceTo(p) > toleranciaDuplicado)
                {
                    puntos.Add(p);
                }
            }
        }

        if (puntos.Count < 3)
            return null;

        // Reduce puntos casi colineales para evitar ondulaciones y segmentos
        // demasiado cortos en la spline interpolada.
        puntos = SimplificarPuntosSplineMYG(puntos, normal);

        if (puntos.Count < 3)
            return null;

        XYZ tangenteInicio = ObtenerTangenteCurvaMYG(validas[0], 0.0);
        XYZ tangenteFin = ObtenerTangenteCurvaMYG(validas[validas.Count - 1], 1.0);

        HermiteSpline hermite = null;

        try
        {
            using (HermiteSplineTangents tangentes = new HermiteSplineTangents())
            {
                if (tangenteInicio != null && tangenteInicio.GetLength() > Tol)
                    tangentes.StartTangent = tangenteInicio.Normalize();

                if (tangenteFin != null && tangenteFin.GetLength() > Tol)
                    tangentes.EndTangent = tangenteFin.Normalize();

                hermite = HermiteSpline.Create(
                    puntos,
                    false,
                    tangentes);
            }
        }
        catch
        {
            hermite = null;
        }

        if (hermite == null)
        {
            try
            {
                hermite = HermiteSpline.Create(puntos, false);
            }
            catch
            {
                hermite = null;
            }
        }

        if (hermite == null)
            return null;

        try
        {
            Curve nurbsOSimple = NurbSpline.CreateCurve(hermite);

            if (nurbsOSimple != null && nurbsOSimple.IsBound && nurbsOSimple.Length > Tol)
                return nurbsOSimple;
        }
        catch
        {
        }

        return hermite;
    }

    private List<XYZ> SimplificarPuntosSplineMYG(
        List<XYZ> puntos,
        XYZ normalPlano)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (puntos == null || puntos.Count == 0)
            return resultado;

        double distanciaMinima = UnitUtils.ConvertToInternalUnits(
            8.0,
            UnitTypeId.Centimeters);

        double senoMinimo = Math.Sin(0.35 * Math.PI / 180.0);

        resultado.Add(puntos[0]);

        for (int i = 1; i < puntos.Count - 1; i++)
        {
            XYZ anterior = resultado[resultado.Count - 1];
            XYZ actual = puntos[i];
            XYZ siguiente = puntos[i + 1];

            if (anterior == null || actual == null || siguiente == null)
                continue;

            if (anterior.DistanceTo(actual) < distanciaMinima)
                continue;

            XYZ a = actual - anterior;
            XYZ b = siguiente - actual;

            if (a.GetLength() <= Tol || b.GetLength() <= Tol)
                continue;

            double seno = a.Normalize().CrossProduct(b.Normalize()).GetLength();

            if (seno < senoMinimo && anterior.DistanceTo(siguiente) < distanciaMinima * 4.0)
                continue;

            resultado.Add(actual);
        }

        XYZ ultimo = puntos[puntos.Count - 1];

        if (resultado.Count == 0 || resultado[resultado.Count - 1].DistanceTo(ultimo) > Tol)
            resultado.Add(ultimo);

        return resultado;
    }

    private Rebar CrearRebarLongitudinalCurvoMYG(
        Document doc,
        Element host,
        RebarBarType tipoBarra,
        XYZ normal,
        IList<Curve> curvas)
    {
        if (doc == null || host == null || tipoBarra == null)
            return null;

        if (curvas == null || curvas.Count == 0)
            return null;

        List<Curve> cadena = curvas
            .Where(c => c != null && c.IsBound && c.Length > Tol)
            .ToList();

        if (cadena.Count == 0)
            return null;

        // =========================================================
        // PRIMER INTENTO: FREE FORM REBAR
        // =========================================================
        // Una cadena con varios arcos/líneas no debe depender de una forma
        // existente de Revit. Free Form conserva toda la cadena como UN solo
        // Rebar, incluso cuando atraviesa varios tramos seleccionados.
        try
        {
            IList<IList<Curve>> barras = new List<IList<Curve>>()
            {
                cadena.Cast<Curve>().ToList()
            };

            using (RebarFreeFormCreationResult resultado = Rebar.CreateFreeForm(
                doc,
                tipoBarra,
                host,
                barras,
                RebarStyle.Standard))
            {
                if (resultado != null &&
                    resultado.Error == RebarFreeFormValidationResult.Success &&
                    resultado.Rebar != null)
                {
                    return resultado.Rebar;
                }

                if (resultado != null)
                {
                    ultimoErrorCurvaMYG =
                        "Rebar.CreateFreeForm devolvió: " +
                        resultado.Error.ToString();
                }
            }
        }
        catch (Exception ex)
        {
            ultimoErrorCurvaMYG =
                "Rebar.CreateFreeForm lanzó una excepción: " + ex.Message;
            // Se mantiene el respaldo Shape Driven para casos simples.
        }

        if (normal == null || normal.GetLength() <= Tol)
            return null;

        // =========================================================
        // RESPALDO: SHAPE DRIVEN
        // =========================================================
        try
        {
            using (BarTerminationsData terminaciones = new BarTerminationsData(doc))
            {
                terminaciones.HookTypeIdAtStart = ElementId.InvalidElementId;
                terminaciones.HookTypeIdAtEnd = ElementId.InvalidElementId;
                terminaciones.CrankTypeIdAtStart = ElementId.InvalidElementId;
                terminaciones.CrankTypeIdAtEnd = ElementId.InvalidElementId;
                terminaciones.EndTreatmentTypeIdAtStart = ElementId.InvalidElementId;
                terminaciones.EndTreatmentTypeIdAtEnd = ElementId.InvalidElementId;
                terminaciones.TerminationOrientationAtStart = RebarTerminationOrientation.Left;
                terminaciones.TerminationOrientationAtEnd = RebarTerminationOrientation.Right;

                return Rebar.CreateFromCurves(
                    doc,
                    RebarStyle.Standard,
                    tipoBarra,
                    host,
                    normal.Normalize(),
                    cadena,
                    terminaciones,
                    true,
                    true);
            }
        }
        catch (Exception ex)
        {
            ultimoErrorCurvaMYG =
                "Rebar.CreateFromCurves lanzó una excepción: " + ex.Message;
            return null;
        }
    }

    private DatosVigaCurvaLongitudinalMYG ObtenerDatosVigaCurvaLongitudinalMYG(
        Document doc,
        Element host)
    {
        if (doc == null || host == null)
            return null;

        LocationCurve lc = host.Location as LocationCurve;

        if (lc == null)
            return null;

        Arc arco = lc.Curve as Arc;

        if (arco == null || !arco.IsBound || arco.Length <= Tol)
            return null;

        XYZ normal = arco.Normal;

        if (normal == null || normal.GetLength() <= Tol)
            return null;

        normal = normal.Normalize();

        if (normal.DotProduct(XYZ.BasisZ) < 0.0)
            normal = normal.Multiply(-1.0);

        // La generación shape-driven de esta versión trabaja con arcos planos
        // horizontales. Para arcos inclinados se requeriría Free Form Rebar 3D.
        if (Math.Abs(normal.DotProduct(XYZ.BasisZ)) < 0.95)
            return null;

        XYZ puntoMedio;
        XYZ tangenteMedio;
        XYZ ejeY;
        XYZ ejeZ;

        if (!ObtenerMarcoCurvaLongitudinalMYG(
            arco,
            arco.Length * 0.5,
            out puntoMedio,
            out tangenteMedio,
            out ejeY,
            out ejeZ))
        {
            return null;
        }

        List<XYZ> puntos = ObtenerPuntosGeometriaTeseladosLongMYG(host);

        if (puntos == null || puntos.Count < 4)
            puntos = ObtenerPuntosBoundingBoxElemento(host);

        if (puntos == null || puntos.Count < 4)
            return null;

        double ventana = Math.Max(
            UnitUtils.ConvertToInternalUnits(12.0, UnitTypeId.Centimeters),
            Math.Min(
                UnitUtils.ConvertToInternalUnits(45.0, UnitTypeId.Centimeters),
                arco.Length * 0.03));

        List<XYZ> cercanos = puntos
            .Where(p => p != null)
            .Where(p => Math.Abs((p - puntoMedio).DotProduct(tangenteMedio)) <= ventana)
            .ToList();

        if (cercanos.Count < 4)
        {
            cercanos = puntos
                .Where(p => p != null)
                .OrderBy(p => Math.Abs((p - puntoMedio).DotProduct(tangenteMedio)))
                .Take(Math.Min(80, puntos.Count))
                .ToList();
        }

        double yMin = double.MaxValue;
        double yMax = double.MinValue;
        double zMin = double.MaxValue;
        double zMax = double.MinValue;

        foreach (XYZ p in cercanos)
        {
            XYZ v = p - puntoMedio;
            double y = v.DotProduct(ejeY);
            double z = v.DotProduct(ejeZ);

            if (y < yMin) yMin = y;
            if (y > yMax) yMax = y;
            if (z < zMin) zMin = z;
            if (z > zMax) zMax = z;
        }

        if (yMax <= yMin + Tol || zMax <= zMin + Tol)
            return null;

        DatosVigaCurvaLongitudinalMYG datos =
            new DatosVigaCurvaLongitudinalMYG();

        datos.Host = host;
        datos.Eje = arco;
        datos.Longitud = arco.Length;
        datos.PuntoMedio = puntoMedio;
        datos.TangenteMedio = tangenteMedio;
        datos.EjeYMedio = ejeY;
        datos.EjeZ = ejeZ;
        datos.YMin = yMin;
        datos.YMax = yMax;
        datos.ZMin = zMin;
        datos.ZMax = zMax;
        // La sección 2D se reconstruye con la banda transversal cercana al
        // punto medio, no con todos los vértices distribuidos a lo largo del arco.
        datos.PuntosGeometria = cercanos;
        // No se leen columnas, zapatas ni elementos del entorno.
        datos.Apoyos = new List<IntervaloColumnaSerie>();

        return datos;
    }

    private bool ObtenerMarcoCurvaLongitudinalMYG(
        Curve eje,
        double estacion,
        out XYZ punto,
        out XYZ tangente,
        out XYZ ejeY,
        out XYZ ejeZ)
    {
        punto = null;
        tangente = null;
        ejeY = null;
        ejeZ = null;

        if (eje == null || eje.Length <= Tol)
            return false;

        double u = Math.Max(0.0, Math.Min(1.0, estacion / eje.Length));

        try
        {
            punto = eje.Evaluate(u, true);
            Transform derivadas = eje.ComputeDerivatives(u, true);
            tangente = derivadas.BasisX.Normalize();
        }
        catch
        {
            return false;
        }

        Arc arco = eje as Arc;
        ejeZ = arco != null && arco.Normal != null
            ? arco.Normal.Normalize()
            : XYZ.BasisZ;

        if (ejeZ.DotProduct(XYZ.BasisZ) < 0.0)
            ejeZ = ejeZ.Multiply(-1.0);

        ejeY = ejeZ.CrossProduct(tangente);

        if (ejeY.GetLength() <= Tol)
            return false;

        ejeY = ejeY.Normalize();
        tangente = tangente.Normalize();

        return true;
    }

    private DatosSerieVigas CrearDatosSerieParaCurvaLongitudinalMYG(
        DatosVigaCurvaLongitudinalMYG datos)
    {
        if (datos == null || datos.Host == null || datos.Eje == null)
            return null;

        DatosSerieVigas serie = new DatosSerieVigas();
        serie.Host = datos.Host;
        serie.PInicio = datos.Eje.GetEndPoint(0);
        serie.PFin = datos.Eje.GetEndPoint(1);
        serie.XAxis = ObtenerTangenteCurvaMYG(datos.Eje, 0.0) ?? datos.TangenteMedio;
        serie.YAxis = datos.EjeYMedio;
        serie.ZAxis = datos.EjeZ;
        serie.LongitudTotal = datos.Longitud;
        serie.Ancho = datos.YMax - datos.YMin;
        serie.Alto = datos.ZMax - datos.ZMin;
        serie.CentroY = (datos.YMin + datos.YMax) / 2.0;
        serie.CentroZ = (datos.ZMin + datos.ZMax) / 2.0;
        serie.SolidoMinGlobal = 0.0;
        serie.SolidoMaxGlobal = datos.Longitud;
        serie.Columnas = datos.Apoyos ?? new List<IntervaloColumnaSerie>();
        // Para la sección transversal de una viga curva se usa el marco local
        // del punto medio. De esta forma el editor 2D y la creación en Revit
        // reconstruyen el mismo polígono Y-Z y aplican el offset real del
        // recubrimiento, en lugar de limitarse a una caja rectangular.
        serie.OrigenGlobal = datos.PuntoMedio ?? serie.PInicio;
        serie.Vigas = new List<DatosViga>();
        serie.Vigas.Add(new DatosViga
        {
            Elemento = datos.Host,
            P0 = serie.PInicio,
            P1 = serie.PFin,
            XAxis = datos.TangenteMedio,
            YAxis = datos.EjeYMedio,
            ZAxis = datos.EjeZ,
            Longitud = datos.Longitud,
            YMin = datos.YMin,
            YMax = datos.YMax,
            ZMin = datos.ZMin,
            ZMax = datos.ZMax,
            Ancho = datos.YMax - datos.YMin,
            Alto = datos.ZMax - datos.ZMin,
            PuntosSolidoGlobal = datos.PuntosGeometria != null
                ? new List<XYZ>(datos.PuntosGeometria)
                : new List<XYZ>()
        });
        serie.TramosRecorrido = new List<TramoRecorridoSerie>();

        double inicioLibre;
        double finLibre;

        CalcularExtremosLuzLibre(
            serie.Columnas,
            0.0,
            datos.Longitud,
            out inicioLibre,
            out finLibre);

        serie.LuzLibreInicioGlobal = inicioLibre;
        serie.LuzLibreFinGlobal = finLibre;

        return serie;
    }

    private IntervaloColumnaSerie ObtenerApoyoCurvoInicioMYG(
        List<IntervaloColumnaSerie> apoyos)
    {
        if (apoyos == null || apoyos.Count == 0)
            return null;

        return apoyos
            .Where(a => a != null && a.Max >= -Tol)
            .OrderBy(a => Math.Abs(a.Center))
            .FirstOrDefault();
    }

    private IntervaloColumnaSerie ObtenerApoyoCurvoFinMYG(
        List<IntervaloColumnaSerie> apoyos,
        double longitud)
    {
        if (apoyos == null || apoyos.Count == 0)
            return null;

        return apoyos
            .Where(a => a != null && a.Min <= longitud + Tol)
            .OrderBy(a => Math.Abs(a.Center - longitud))
            .FirstOrDefault();
    }

    private List<XYZ> ObtenerPuntosGeometriaTeseladosLongMYG(Element elemento)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elemento == null)
            return puntos;

        Options opciones = new Options();
        opciones.DetailLevel = ViewDetailLevel.Fine;
        opciones.IncludeNonVisibleObjects = false;
        opciones.ComputeReferences = false;

        GeometryElement geometria = null;

        try
        {
            geometria = elemento.get_Geometry(opciones);
        }
        catch
        {
            geometria = null;
        }

        if (geometria == null)
            return puntos;

        RecolectarPuntosTeseladosLongMYG(
            geometria,
            Transform.Identity,
            puntos);

        return puntos;
    }

    private void RecolectarPuntosTeseladosLongMYG(
        GeometryElement geometria,
        Transform transformacion,
        List<XYZ> puntos)
    {
        if (geometria == null || puntos == null)
            return;

        foreach (GeometryObject obj in geometria)
        {
            if (obj == null)
                continue;

            Solid solido = obj as Solid;

            if (solido != null)
            {
                if (solido.Edges == null)
                    continue;

                foreach (Edge arista in solido.Edges)
                {
                    Curve curva = null;

                    try
                    {
                        curva = arista.AsCurve();
                    }
                    catch
                    {
                        curva = null;
                    }

                    if (curva == null)
                        continue;

                    IList<XYZ> teselado = null;

                    try
                    {
                        teselado = curva.Tessellate();
                    }
                    catch
                    {
                        teselado = null;
                    }

                    if (teselado == null || teselado.Count == 0)
                    {
                        teselado = new List<XYZ>()
                        {
                            curva.GetEndPoint(0),
                            curva.GetEndPoint(1)
                        };
                    }

                    foreach (XYZ p in teselado)
                    {
                        if (p == null)
                            continue;

                        XYZ q = transformacion != null && !transformacion.IsIdentity
                            ? transformacion.OfPoint(p)
                            : p;

                        puntos.Add(q);
                    }
                }

                continue;
            }

            GeometryInstance instancia = obj as GeometryInstance;

            if (instancia == null)
                continue;

            try
            {
                GeometryElement simbolo = instancia.GetSymbolGeometry();

                if (simbolo != null)
                {
                    Transform t = transformacion;

                    try
                    {
                        t = transformacion.Multiply(instancia.Transform);
                    }
                    catch
                    {
                        t = instancia.Transform;
                    }

                    RecolectarPuntosTeseladosLongMYG(simbolo, t, puntos);
                }
            }
            catch
            {
            }
        }
    }

    public string GetName()
    {
        return "Crear acero longitudinal continuo en vigas";
    }

    private double ObtenerDiametroEstriboReferenciaDesdeForm()
    {
        try
        {
            if (Form == null)
                return 0.0;

            System.Reflection.PropertyInfo prop = Form.GetType().GetProperty(
                "DiametroEstriboReferenciaFt",
                System.Reflection.BindingFlags.Instance |
                System.Reflection.BindingFlags.Public |
                System.Reflection.BindingFlags.NonPublic);

            if (prop == null)
                return 0.0;

            object valor = prop.GetValue(Form, null);

            if (valor == null)
                return 0.0;

            double diametro = Convert.ToDouble(
                valor,
                System.Globalization.CultureInfo.InvariantCulture);

            if (diametro < 0.0)
                diametro = 0.0;

            return diametro;
        }
        catch
        {
            return 0.0;
        }
    }


    // =========================================================
    // CREACIÓN DESDE MODELO COMPARTIDO DE LA VISTA PRELIMINAR
    // =========================================================
    // Esta sección es la clave del cambio:
    // - La ventana calcula y dibuja las rutas.
    // - El handler toma esas mismas rutas.
    // - Revit crea el acero con los mismos puntos lógicos que se ven en preview.
    private int CrearAceroLongitudinalDesdeModeloPreview(
        Document doc,
        DatosSerieVigas datos,
        AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modelo,
        RebarBarType tipoSuperior,
        int cantidadSuperior,
        RebarBarType tipoInferior,
        int cantidadInferior,
        bool crearAceroCentral,
        RebarBarType tipoCentral,
        double recubrimiento,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin)
    {
        if (doc == null || datos == null || datos.Host == null)
            return -1;

        if (modelo == null || !modelo.Valido || modelo.Rutas == null || modelo.Rutas.Count == 0)
            return -1;

        if (datos.LongitudTotal <= Tol || datos.Ancho <= Tol || datos.Alto <= Tol)
            return -1;

        RebarHostData hostData = RebarHostData.GetRebarHostData(datos.Host);

        if (hostData == null)
            return -1;

        double diametroSuperior = ObtenerDiametroBarra(tipoSuperior);
        double diametroInferior = ObtenerDiametroBarra(tipoInferior);
        double diametroCentral = ObtenerDiametroBarra(tipoCentral);

        int contador = 0;

        foreach (AceroLongitudinalVigasForm.RutaAceroLongitudinalPreview ruta in modelo.Rutas)
        {
            if (ruta == null || !ruta.Activa)
                continue;

            if (ruta.Segmentos == null || ruta.Segmentos.Count == 0)
                continue;

            if (ruta.TipoRuta > 0)
            {
                contador += CrearGrupoBarrasDesdeRutaPreview(
                    doc,
                    datos,
                    modelo,
                    ruta,
                    tipoSuperior,
                    cantidadSuperior,
                    recubrimiento,
                    diametroSuperior,
                    true,
                    false,
                    ganchoInicio,
                    longitudGanchoInicio,
                    ganchoFin,
                    longitudGanchoFin);
            }
            else if (ruta.TipoRuta < 0)
            {
                contador += CrearGrupoBarrasDesdeRutaPreview(
                    doc,
                    datos,
                    modelo,
                    ruta,
                    tipoInferior,
                    cantidadInferior,
                    recubrimiento,
                    diametroInferior,
                    false,
                    false,
                    ganchoInicio,
                    longitudGanchoInicio,
                    ganchoFin,
                    longitudGanchoFin);
            }
            else if (crearAceroCentral)
            {
                contador += CrearGrupoBarrasDesdeRutaPreview(
                    doc,
                    datos,
                    modelo,
                    ruta,
                    tipoCentral,
                    2,
                    recubrimiento,
                    diametroCentral,
                    false,
                    true,
                    false,
                    0.0,
                    false,
                    0.0);
            }
        }

        return contador;
    }

    private int CrearGrupoBarrasDesdeRutaPreview(
        Document doc,
        DatosSerieVigas datos,
        AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modelo,
        AceroLongitudinalVigasForm.RutaAceroLongitudinalPreview ruta,
        RebarBarType barType,
        int cantidad,
        double recubrimiento,
        double diametro,
        bool superior,
        bool central,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin)
    {
        if (doc == null || datos == null || modelo == null || ruta == null)
            return 0;

        if (barType == null || cantidad <= 0)
            return 0;

        if (ruta.Segmentos == null || ruta.Segmentos.Count == 0)
            return 0;

        double radioBarra = diametro / 2.0;

        double yMin = -datos.Ancho / 2.0 + recubrimiento + radioBarra;
        double yMax = datos.Ancho / 2.0 - recubrimiento - radioBarra;

        if (yMax < yMin)
            return 0;

        double yInicial = yMin;
        double longitudDistribucion = yMax - yMin;

        double zBase;

        if (central)
        {
            zBase = 0.0;
        }
        else if (superior)
        {
            zBase = datos.Alto / 2.0 - recubrimiento - radioBarra;
        }
        else
        {
            zBase = -datos.Alto / 2.0 + recubrimiento + radioBarra;
        }

        XYZ direccionGancho = superior
            ? datos.ZAxis.Multiply(-1.0)
            : datos.ZAxis;

        List<AceroLongitudinalVigasForm.SegmentoRutaAceroPreview> segmentosBase = ruta.Segmentos
            .Where(s => s != null && !s.EsEmpalme && s.Puntos != null && s.Puntos.Count >= 2)
            .OrderBy(s => s.StartMm)
            .ToList();

        if (segmentosBase.Count == 0)
            return 0;

        int contador = 0;

        for (int i = 0; i < segmentosBase.Count; i++)
        {
            AceroLongitudinalVigasForm.SegmentoRutaAceroPreview segmento = segmentosBase[i];

            List<XYZ> puntosRevit = ConvertirSegmentoPreviewAPuntosRevit(
                datos,
                modelo,
                ruta,
                segmento,
                yInicial,
                zBase,
                radioBarra);

            if (puntosRevit == null || puntosRevit.Count < 2)
                continue;

            bool usarGanchoInicio = ganchoInicio && i == 0;
            bool usarGanchoFin = ganchoFin && i == segmentosBase.Count - 1;

            int creadas = CrearRebarLongitudinalConNumeroFijo(
                doc,
                datos.Host,
                barType,
                datos.YAxis,
                puntosRevit,
                usarGanchoInicio,
                longitudGanchoInicio,
                usarGanchoFin,
                longitudGanchoFin,
                direccionGancho,
                cantidad,
                longitudDistribucion);

            if (creadas == 0)
            {
                // Algunos perfiles con quiebre pueden fallar por el sentido de la normal.
                // Se prueba la normal contraria sin cambiar los puntos del trazo.
                creadas = CrearRebarLongitudinalConNumeroFijo(
                    doc,
                    datos.Host,
                    barType,
                    datos.YAxis.Multiply(-1.0),
                    puntosRevit,
                    usarGanchoInicio,
                    longitudGanchoInicio,
                    usarGanchoFin,
                    longitudGanchoFin,
                    direccionGancho,
                    cantidad,
                    longitudDistribucion);
            }

            contador += creadas;
        }

        return contador;
    }

    private List<XYZ> ConvertirSegmentoPreviewAPuntosRevit(
        DatosSerieVigas datos,
        AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modelo,
        AceroLongitudinalVigasForm.RutaAceroLongitudinalPreview ruta,
        AceroLongitudinalVigasForm.SegmentoRutaAceroPreview segmento,
        double y,
        double zBase,
        double radioBarra)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (datos == null || modelo == null || ruta == null || segmento == null)
            return resultado;

        if (segmento.Puntos == null || segmento.Puntos.Count < 2)
            return resultado;

        bool usarZModelo = ModeloPreviewTieneZUtil(modelo, segmento);
        double radioBarraMm = UnitUtils.ConvertFromInternalUnits(
            radioBarra,
            UnitTypeId.Millimeters);

        foreach (AceroLongitudinalVigasForm.PuntoRutaAceroPreview puntoModelo in segmento.Puntos.OrderBy(p => p.XMm))
        {
            if (puntoModelo == null)
                continue;

            double xInterno = ConvertirXModeloPreviewAInterno(
                modelo,
                datos,
                puntoModelo.XMm);

            double zInterno = zBase;

            if (usarZModelo)
            {
                double zMm = puntoModelo.ZMm;

                // La ventana dibuja el trazo a recubrimiento. Revit necesita
                // la línea de centro de barra; por eso se agrega medio diámetro.
                if (ruta.TipoRuta > 0)
                    zMm -= radioBarraMm;
                else if (ruta.TipoRuta < 0)
                    zMm += radioBarraMm;

                zInterno = UnitUtils.ConvertToInternalUnits(
                    zMm,
                    UnitTypeId.Millimeters);
            }

            XYZ p = PuntoModeloPreviewARevit(
                datos,
                xInterno,
                y,
                zInterno);

            AgregarPuntoSiValido(resultado, p);
        }

        return LimpiarPuntosConsecutivos(resultado);
    }

    private bool ModeloPreviewTieneZUtil(
        AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modelo,
        AceroLongitudinalVigasForm.SegmentoRutaAceroPreview segmento)
    {
        if (modelo == null || segmento == null || segmento.Puntos == null)
            return false;

        if (!modelo.TienePerfilVariable && !segmento.UsaPerfilVariable)
            return false;

        foreach (AceroLongitudinalVigasForm.PuntoRutaAceroPreview p in segmento.Puntos)
        {
            if (p != null && Math.Abs(p.ZMm) > 0.001)
                return true;
        }

        return false;
    }

    private double ConvertirXModeloPreviewAInterno(
        AceroLongitudinalVigasForm.ModeloAceroLongitudinalPreview modelo,
        DatosSerieVigas datos,
        double xModeloMm)
    {
        if (modelo == null || datos == null)
            return 0.0;

        double rangoModeloMm = modelo.EndGlobalMm - modelo.StartGlobalMm;

        if (Math.Abs(rangoModeloMm) <= 0.001)
            return 0.0;

        double t = (xModeloMm - modelo.StartGlobalMm) / rangoModeloMm;

        return datos.LongitudTotal * t;
    }

    private XYZ PuntoModeloPreviewARevit(
        DatosSerieVigas datos,
        double x,
        double y,
        double z)
    {
        if (datos == null)
            return null;

        XYZ origen = datos.PInicio;

        if (origen == null)
            return null;

        return origen
            .Add(datos.XAxis.Multiply(x))
            .Add(datos.YAxis.Multiply(y))
            .Add(datos.ZAxis.Multiply(z));
    }

    private double CalcularDesarrolloAutomaticoInicio(
        DatosSerieVigas datos,
        double recubrimiento)
    {
        if (datos == null)
            return 0.0;

        double desarrolloProyectado = 0.0;

        IntervaloColumnaSerie apoyo = ObtenerApoyoInicio(datos);

        if (apoyo != null)
        {
            // El ancho del apoyo se detecta proyectado sobre el eje global de la serie.
            // Para vigas inclinadas, esa distancia proyectada debe convertirse a longitud
            // real sobre el recorrido inclinado de la barra.
            desarrolloProyectado = apoyo.Width - recubrimiento;
        }
        else
        {
            // Respaldo: distancia entre el inicio físico de la serie
            // y la cara libre inicial de la viga.
            desarrolloProyectado = datos.LuzLibreInicioGlobal -
                                   datos.SolidoMinGlobal -
                                   recubrimiento;
        }

        desarrolloProyectado = Math.Max(0.0, desarrolloProyectado);

        return AjustarDesarrolloAutomaticoARecorridoReal(
            datos,
            desarrolloProyectado,
            true);
    }

    private double CalcularDesarrolloAutomaticoFin(
        DatosSerieVigas datos,
        double recubrimiento)
    {
        if (datos == null)
            return 0.0;

        double desarrolloProyectado = 0.0;

        IntervaloColumnaSerie apoyo = ObtenerApoyoFin(datos);

        if (apoyo != null)
        {
            // El ancho del apoyo se detecta proyectado sobre el eje global de la serie.
            // Para vigas inclinadas, esa distancia proyectada debe convertirse a longitud
            // real sobre el recorrido inclinado de la barra.
            desarrolloProyectado = apoyo.Width - recubrimiento;
        }
        else
        {
            // Respaldo: distancia entre la cara libre final de la viga
            // y el final físico de la serie.
            desarrolloProyectado = datos.SolidoMaxGlobal -
                                   datos.LuzLibreFinGlobal -
                                   recubrimiento;
        }

        desarrolloProyectado = Math.Max(0.0, desarrolloProyectado);

        return AjustarDesarrolloAutomaticoARecorridoReal(
            datos,
            desarrolloProyectado,
            false);
    }

    private double AjustarDesarrolloAutomaticoARecorridoReal(
        DatosSerieVigas datos,
        double desarrolloProyectado,
        bool inicio)
    {
        if (datos == null)
            return 0.0;

        if (desarrolloProyectado <= Tol)
            return 0.0;

        if (datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return desarrolloProyectado;

        if (datos.XAxis == null || datos.XAxis.GetLength() <= Tol)
            return desarrolloProyectado;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Direccion != null && t.Direccion.GetLength() > Tol)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        if (tramos == null || tramos.Count == 0)
            return desarrolloProyectado;

        TramoRecorridoSerie tramoExtremo = inicio
            ? tramos.FirstOrDefault()
            : tramos.LastOrDefault();

        if (tramoExtremo == null || tramoExtremo.Direccion == null || tramoExtremo.Direccion.GetLength() <= Tol)
            return desarrolloProyectado;

        XYZ ejeSerie = datos.XAxis.Normalize();
        XYZ ejeTramo = tramoExtremo.Direccion.Normalize();

        double factorProyeccion = Math.Abs(ejeTramo.DotProduct(ejeSerie));

        if (double.IsNaN(factorProyeccion) || double.IsInfinity(factorProyeccion))
            return desarrolloProyectado;

        if (factorProyeccion > 1.0)
            factorProyeccion = 1.0;

        // Si el tramo es prácticamente perpendicular al eje de referencia,
        // no se fuerza una longitud exagerada. En vigas normales inclinadas,
        // este factor convierte: distancia proyectada del apoyo -> longitud real de barra.
        if (factorProyeccion <= 0.10)
            return desarrolloProyectado;

        return desarrolloProyectado / factorProyeccion;
    }

    private double ObtenerFactorProyeccionDesarrolloAutomatico(
        DatosSerieVigas datos,
        bool inicio)
    {
        if (datos == null)
            return 1.0;

        if (datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return 1.0;

        if (datos.XAxis == null || datos.XAxis.GetLength() <= Tol)
            return 1.0;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Direccion != null && t.Direccion.GetLength() > Tol)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        if (tramos == null || tramos.Count == 0)
            return 1.0;

        TramoRecorridoSerie tramoExtremo = inicio
            ? tramos.FirstOrDefault()
            : tramos.LastOrDefault();

        if (tramoExtremo == null || tramoExtremo.Direccion == null || tramoExtremo.Direccion.GetLength() <= Tol)
            return 1.0;

        XYZ ejeSerie = datos.XAxis.Normalize();
        XYZ ejeTramo = tramoExtremo.Direccion.Normalize();

        double factorProyeccion = Math.Abs(ejeTramo.DotProduct(ejeSerie));

        if (double.IsNaN(factorProyeccion) || double.IsInfinity(factorProyeccion))
            return 1.0;

        if (factorProyeccion > 1.0)
            factorProyeccion = 1.0;

        if (factorProyeccion <= 0.10)
            return 1.0;

        return factorProyeccion;
    }

    // =========================================================
    // AUTO - DESARROLLO MEDIDO A CARA REAL DEL ACERO
    // =========================================================
    // En vigas inclinadas el punto de la barra no coincide solo con la estación X,
    // porque el offset perpendicular a la cara superior/inferior también desplaza
    // el eje de la barra en la dirección longitudinal. Por eso el Auto no debe ser:
    //      ancho apoyo - recubrimiento - radio
    // aplicado directamente a X.
    //
    // Se resuelve la estación para que la CARA del acero quede a recubrimiento
    // de la cara exterior de la columna, sin tocar la lógica de quiebres.
    private double CalcularDesarrolloAutomaticoExtremoParaEjeCaraAcero(
        DatosSerieVigas datos,
        bool inicio,
        bool superior,
        double recubrimiento,
        double radioBarra,
        double margenCara)
    {
        if (datos == null)
            return -1.0;

        // El valor que se ve en la ventana cuando está activo Auto es el dato
        // confiable que espera el usuario: ancho del apoyo - recubrimiento.
        // Ejemplo: columna 45 cm y recubrimiento 4 cm => 41 cm.
        // Para que ese 4 cm quede a CARA del acero, el eje debe quedar:
        //      41 cm - radio de barra.
        double desarrolloMostrado = ObtenerDesarrolloAutomaticoMostradoInterno(inicio);
        double objetivoProyectadoCaraAcero = desarrolloMostrado > Tol
            ? desarrolloMostrado - radioBarra
            : -1.0;

        if (objetivoProyectadoCaraAcero < 0.0)
        {
            IntervaloColumnaSerie apoyo = inicio
                ? ObtenerApoyoInicio(datos)
                : ObtenerApoyoFin(datos);

            if (apoyo == null || apoyo.Width <= Tol)
                return -1.0;

            objetivoProyectadoCaraAcero = apoyo.Width - recubrimiento - radioBarra;
        }

        if (objetivoProyectadoCaraAcero <= Tol)
            return 0.0;

        XYZ ejeReferencia = ObtenerEjeReferenciaRecubrimientoColumna(datos, inicio);

        if (ejeReferencia == null || ejeReferencia.GetLength() <= Tol)
            ejeReferencia = datos.XAxis;

        if (ejeReferencia == null || ejeReferencia.GetLength() <= Tol)
            return -1.0;

        ejeReferencia = ejeReferencia.Normalize();

        double factor = ObtenerFactorProyeccionSobreEjeReferencia(datos, inicio, ejeReferencia);

        if (double.IsNaN(factor) || double.IsInfinity(factor) || factor <= 0.10)
            factor = 1.0;

        double desplazamientoOffset = ObtenerDesplazamientoOffsetCaraEnEjeSerie(
            datos,
            inicio,
            superior,
            margenCara,
            ejeReferencia);

        // Inicio:
        //   proyección punto = -L * factor + desplazamientoOffset
        //   objetivo         = -(desarrolloAuto - radio)
        //   L = (objetivoProyectado + desplazamientoOffset) / factor
        // Fin:
        //   proyección punto =  L * factor + desplazamientoOffset
        //   objetivo         =  (desarrolloAuto - radio)
        //   L = (objetivoProyectado - desplazamientoOffset) / factor
        double longitud = inicio
            ? (objetivoProyectadoCaraAcero + desplazamientoOffset) / factor
            : (objetivoProyectadoCaraAcero - desplazamientoOffset) / factor;

        if (double.IsNaN(longitud) || double.IsInfinity(longitud))
            return -1.0;

        return Math.Max(0.0, longitud);
    }

    private double ObtenerDesarrolloAutomaticoMostradoInterno(bool inicio)
    {
        try
        {
            if (Form == null)
                return -1.0;

            string texto = inicio
                ? Form.LongitudDesarrolloInicioTexto
                : Form.LongitudDesarrolloFinTexto;

            double valorCm = 0.0;

            if (!TryLeerDouble(texto, out valorCm))
                return -1.0;

            if (valorCm <= 0.0)
                return -1.0;

            return UnitUtils.ConvertToInternalUnits(
                valorCm,
                UnitTypeId.Centimeters);
        }
        catch
        {
            return -1.0;
        }
    }

    private XYZ ObtenerEjeReferenciaRecubrimientoColumna(
        DatosSerieVigas datos,
        bool inicio)
    {
        if (datos == null)
            return null;

        TramoRecorridoSerie tramo = ObtenerTramoExtremoDesarrollo(datos, inicio);

        XYZ direccion = null;

        if (tramo != null && tramo.Direccion != null && tramo.Direccion.GetLength() > Tol)
            direccion = tramo.Direccion.Normalize();
        else if (datos.XAxis != null && datos.XAxis.GetLength() > Tol)
            direccion = datos.XAxis.Normalize();

        if (direccion == null || direccion.GetLength() <= Tol)
            return null;

        // Para el recubrimiento en la cara de columna se usa la proyección
        // horizontal de la viga. En elevación, una viga inclinada se mueve en Z,
        // pero la cara de columna sigue siendo vertical; por eso medir sobre el
        // eje inclinado genera el desfase que se veía en pantalla.
        XYZ horizontal = new XYZ(direccion.X, direccion.Y, 0.0);

        if (horizontal.GetLength() <= Tol)
            horizontal = direccion;

        horizontal = horizontal.Normalize();

        if (datos.XAxis != null && datos.XAxis.GetLength() > Tol)
        {
            XYZ refGlobal = new XYZ(datos.XAxis.X, datos.XAxis.Y, 0.0);

            if (refGlobal.GetLength() > Tol)
            {
                refGlobal = refGlobal.Normalize();

                if (horizontal.DotProduct(refGlobal) < 0.0)
                    horizontal = horizontal.Multiply(-1.0);
            }
        }

        return horizontal;
    }

    private TramoRecorridoSerie ObtenerTramoExtremoDesarrollo(
        DatosSerieVigas datos,
        bool inicio)
    {
        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return null;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Viga != null)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        if (tramos.Count == 0)
            return null;

        return inicio ? tramos.FirstOrDefault() : tramos.LastOrDefault();
    }

    private double ObtenerFactorProyeccionSobreEjeReferencia(
        DatosSerieVigas datos,
        bool inicio,
        XYZ ejeReferencia)
    {
        if (datos == null || ejeReferencia == null || ejeReferencia.GetLength() <= Tol)
            return 1.0;

        TramoRecorridoSerie tramo = ObtenerTramoExtremoDesarrollo(datos, inicio);

        if (tramo == null || tramo.Direccion == null || tramo.Direccion.GetLength() <= Tol)
            return 1.0;

        double factor = Math.Abs(tramo.Direccion.Normalize().DotProduct(ejeReferencia.Normalize()));

        if (double.IsNaN(factor) || double.IsInfinity(factor))
            return 1.0;

        if (factor > 1.0)
            factor = 1.0;

        if (factor <= 0.10)
            return 1.0;

        return factor;
    }

    private double ObtenerDesplazamientoOffsetCaraEnEjeSerie(
        DatosSerieVigas datos,
        bool inicio,
        bool superior,
        double margenCara,
        XYZ ejeReferencia)
    {
        if (datos == null || margenCara <= Tol)
            return 0.0;

        if (ejeReferencia == null || ejeReferencia.GetLength() <= Tol)
            return 0.0;

        TramoRecorridoSerie tramo = ObtenerTramoExtremoDesarrollo(datos, inicio);

        if (tramo == null || tramo.Viga == null)
            return 0.0;

        DatosViga viga = tramo.Viga;

        double estacion = inicio
            ? tramo.EstacionInicioViga
            : tramo.EstacionFinViga;

        List<SegmentoPerfilCara> perfil = superior
            ? viga.PerfilSuperiorDetallado
            : viga.PerfilInferiorDetallado;

        if (perfil == null || perfil.Count == 0)
            perfil = CrearPerfilSimpleCara(viga, superior);

        if (perfil == null || perfil.Count == 0)
            return 0.0;

        SegmentoPerfilCara segCara = perfil
            .Where(s => s != null)
            .OrderBy(s => DistanciaEstacionASegmentoPerfil(estacion, s))
            .FirstOrDefault();

        if (segCara == null)
            return 0.0;

        double dx = segCara.X1 - segCara.X0;
        double dz = segCara.Z1 - segCara.Z0;
        double len = Math.Sqrt(dx * dx + dz * dz);

        if (len <= Tol)
            return 0.0;

        double nx = -dz / len;
        double nz = dx / len;

        if (superior)
        {
            if (nz > 0.0)
            {
                nx = -nx;
                nz = -nz;
            }
        }
        else
        {
            if (nz < 0.0)
            {
                nx = -nx;
                nz = -nz;
            }
        }

        if (viga.XAxis == null || viga.ZAxis == null)
            return 0.0;

        XYZ vectorOffset = viga.XAxis.Multiply(nx * margenCara)
            .Add(viga.ZAxis.Multiply(nz * margenCara));

        return vectorOffset.DotProduct(ejeReferencia.Normalize());
    }

    private IntervaloColumnaSerie ObtenerApoyoInicio(DatosSerieVigas datos)
    {
        if (datos == null ||
            datos.Columnas == null ||
            datos.Columnas.Count == 0)
        {
            return null;
        }

        double tolApoyo = UnitUtils.ConvertToInternalUnits(
            3.0,
            UnitTypeId.Centimeters);

        double caraLibreInicio = datos.LuzLibreInicioGlobal;

        return datos.Columnas
            .Where(c =>
                c != null &&
                (
                    Math.Abs(c.Max - caraLibreInicio) <= tolApoyo ||
                    (c.Min <= caraLibreInicio && c.Max >= caraLibreInicio)
                ))
            .OrderBy(c => Math.Abs(c.Max - caraLibreInicio))
            .FirstOrDefault();
    }

    private IntervaloColumnaSerie ObtenerApoyoFin(DatosSerieVigas datos)
    {
        if (datos == null ||
            datos.Columnas == null ||
            datos.Columnas.Count == 0)
        {
            return null;
        }

        double tolApoyo = UnitUtils.ConvertToInternalUnits(
            3.0,
            UnitTypeId.Centimeters);

        double caraLibreFin = datos.LuzLibreFinGlobal;

        return datos.Columnas
            .Where(c =>
                c != null &&
                (
                    Math.Abs(c.Min - caraLibreFin) <= tolApoyo ||
                    (c.Min <= caraLibreFin && c.Max >= caraLibreFin)
                ))
            .OrderBy(c => Math.Abs(c.Min - caraLibreFin))
            .FirstOrDefault();
    }

    // =========================================================
    // ACERO LONGITUDINAL DESDE EL EDITOR 2D DE SECCIÓN
    // =========================================================
    private double ObtenerDiametroEstriboReferenciaDisenoManualMYG(
        AceroVigaDisenoSeccion diseno)
    {
        if (diseno != null && diseno.Estribos != null)
        {
            AceroVigaEstribo2D referencia = diseno.Estribos
                .Where(x => x != null && x.TipoBarra != null)
                .OrderByDescending(x => x.UsarContornoOffsetAutomatico)
                .ThenByDescending(x => x.Cerrado)
                .FirstOrDefault();

            if (referencia != null && referencia.TipoBarra != null)
            {
                double diametro = ObtenerDiametroBarra(referencia.TipoBarra);
                if (diametro > Tol)
                    return diametro;
            }
        }

        return ObtenerDiametroEstriboReferenciaDesdeForm();
    }

    private void ObtenerClasificacionCapaManualMYG(
        AceroVigaBarraLongitudinal2D definicion,
        out int tipoRuta,
        out string textoTipo)
    {
        tipoRuta = 0;
        textoTipo = "Longitudinal";

        if (definicion == null)
            return;

        if (definicion.TipoCapa ==
                AceroVigaTipoCapaLongitudinal.Superior &&
            definicion.NumeroCapa > 0)
        {
            tipoRuta = 1;
            textoTipo = "Longitudinal - Superior - Capa " +
                Math.Max(1, Math.Min(4, definicion.NumeroCapa));
            return;
        }

        if (definicion.TipoCapa ==
                AceroVigaTipoCapaLongitudinal.Inferior &&
            definicion.NumeroCapa > 0)
        {
            tipoRuta = -1;
            textoTipo = "Longitudinal - Inferior - Capa " +
                Math.Max(1, Math.Min(4, definicion.NumeroCapa));
            return;
        }

        if (definicion.TipoCapa ==
            AceroVigaTipoCapaLongitudinal.Central)
        {
            tipoRuta = 0;
            textoTipo = "Longitudinal - Central";
            return;
        }

        // Sin una guía detectada se mantiene únicamente LONGITUDINAL.
        // La posición geométrica se usa para seleccionar la longitud de
        // desarrollo correspondiente, pero nunca se escribe "Sin capa".
        double v = definicion.Punto != null
            ? Math.Max(0.0, Math.Min(1.0, definicion.Punto.V))
            : 0.5;
        tipoRuta = v >= 0.66 ? 1 : (v <= 0.34 ? -1 : 0);
        textoTipo = "Longitudinal";
    }

    private sealed class PosicionGrupoLongitudinalManualMYG
    {
        public AceroVigaBarraLongitudinal2D Definicion;
        public double Y;
        public double Z;
    }


    // =========================================================
    // V11.4 - INTERVALO LONGITUDINAL MANUAL CON ANCLAJES
    // =========================================================
    // En el editor manual los campos "Anclaje inicial" y
    // "Prolongación final" pertenecen a la geometría longitudinal,
    // no a la sección Y-Z. Por eso deben extender el intervalo
    // longitudinal real usado por grupos, barras individuales y
    // respaldos Free Form.
    private void ObtenerIntervaloLongitudinalManualConDesarrollosMYG(
        DatosSerieVigas datos,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        out double xInicio,
        out double xFin)
    {
        xInicio = 0.0;
        xFin = 0.0;

        if (datos == null)
            return;

        double inicioUtil = Math.Max(
            0.0,
            datos.InicioUtilArmaduraSerie);

        double finUtil =
            datos.FinUtilArmaduraSerie > inicioUtil + Tol
                ? Math.Min(
                    datos.LongitudTotal,
                    datos.FinUtilArmaduraSerie)
                : datos.LongitudTotal;

        xInicio = desarrolloInicioHabilitado
            ? inicioUtil - Math.Max(
                0.0,
                longitudDesarrolloInicio)
            : inicioUtil;

        xFin = desarrolloFinHabilitado
            ? finUtil + Math.Max(
                0.0,
                longitudDesarrolloFin)
            : finUtil;
    }


    // =========================================================
    // V11.20 - MOTOR ALTERNO POR ESTACIONES
    // =========================================================
    private sealed class RegionCantidadEstacionMYG
    {
        public double Inicio;
        public double Fin;
        public int Cantidad;
        public HashSet<int> IndicesActivos =
            new HashSet<int>();

        public RegionCantidadEstacionMYG(
            double inicio,
            double fin,
            IEnumerable<int> indicesActivos)
        {
            Inicio = inicio;
            Fin = fin;

            IndicesActivos = new HashSet<int>(
                (indicesActivos ?? Enumerable.Empty<int>())
                    .Where(x => x >= 0));

            Cantidad = IndicesActivos.Count;
        }
    }

    private sealed class IntervaloActivoBarraEstacionMYG
    {
        public double Inicio;
        public double Fin;
        public int IndiceDefinicion;

        public IntervaloActivoBarraEstacionMYG(
            double inicio,
            double fin,
            int indiceDefinicion)
        {
            Inicio = inicio;
            Fin = fin;
            IndiceDefinicion = indiceDefinicion;
        }
    }

    private enum TipoLoteEspecialEstacionMYG
    {
        Normal = 0,
        Baston = 1,
        Balancin = 2
    }

    private sealed class LoteIntervaloEstacionMYG
    {
        public double Inicio;
        public double Fin;
        public List<int> Indices = new List<int>();

        // V11.44 - tipo especial para poder identificar los bastones durante
        // la creación y asignarles el parámetro de empalme solicitado.
        public TipoLoteEspecialEstacionMYG TipoEspecial =
            TipoLoteEspecialEstacionMYG.Normal;

        // V11.44 - plan COMERCIAL lógico acumulado. El lote puede seguir
        // materializándose como un Rebar independiente por tramo/host, pero
        // los 9 m (o la longitud comercial indicada) NO se reinician en cada
        // tramo cuando la misma barra continúa físicamente al siguiente.
        public List<SegmentoAceroLongitudinal> SegmentosEmpalmeAcumulados = null;
    }

    private List<List<int>> ParticionarIndicesEquiespaciadosEstacionesMYG(
        IEnumerable<int> indicesEntrada)
    {
        List<int> indices = (indicesEntrada ?? Enumerable.Empty<int>())
            .Where(x => x >= 0)
            .Distinct()
            .OrderBy(x => x)
            .ToList();

        List<List<int>> resultado = new List<List<int>>();

        if (indices.Count == 0)
            return resultado;

        if (indices.Count <= 2)
        {
            resultado.Add(indices);
            return resultado;
        }

        int pasoGlobal = indices[1] - indices[0];
        bool todosEquiespaciados = pasoGlobal > 0;

        for (int i = 2; i < indices.Count && todosEquiespaciados; i++)
        {
            if (indices[i] - indices[i - 1] != pasoGlobal)
                todosEquiespaciados = false;
        }

        if (todosEquiespaciados)
        {
            resultado.Add(indices);
            return resultado;
        }

        // Para selecciones arbitrarias se preserva exactitud por encima de
        // intentar forzar un único Número fijo. Los tramos consecutivos sí
        // pueden seguir siendo sets nativos; los huecos irregulares se separan.
        List<int> actual = new List<int> { indices[0] };

        for (int i = 1; i < indices.Count; i++)
        {
            if (indices[i] == indices[i - 1] + 1)
            {
                actual.Add(indices[i]);
            }
            else
            {
                resultado.Add(actual);
                actual = new List<int> { indices[i] };
            }
        }

        if (actual.Count > 0)
            resultado.Add(actual);

        return resultado;
    }

    private List<int> ConstruirOrdenPrioridadSimetricaEstacionesMYG(int cantidad)
    {
        List<int> resultado = new List<int>();
        int izquierda = 0;
        int derecha = cantidad - 1;

        while (izquierda <= derecha)
        {
            if (!resultado.Contains(izquierda))
                resultado.Add(izquierda);

            if (derecha != izquierda && !resultado.Contains(derecha))
                resultado.Add(derecha);

            izquierda++;
            derecha--;
        }

        return resultado;
    }

    private List<int> SanitizarIndicesActivosEstacionesMYG(
        IEnumerable<int> indices,
        int cantidadMaxima)
    {
        cantidadMaxima = Math.Max(0, cantidadMaxima);

        return (indices ?? Enumerable.Empty<int>())
            .Where(x => x >= 0 && x < cantidadMaxima)
            .Distinct()
            .OrderBy(x => x)
            .ToList();
    }

    private List<int> ConstruirIndicesSimetricosEstacionesMYG(
        int cantidadMaxima,
        int cantidad)
    {
        cantidadMaxima = Math.Max(0, cantidadMaxima);
        cantidad = Math.Max(0, Math.Min(cantidadMaxima, cantidad));

        return ConstruirOrdenPrioridadSimetricaEstacionesMYG(
                cantidadMaxima)
            .Take(cantidad)
            .Distinct()
            .OrderBy(x => x)
            .ToList();
    }

    private List<int> ObtenerIndicesActivosFilaEstacionesMYG(
        AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG fila,
        int zona,
        bool avanzado,
        int cantidadMaxima)
    {
        if (fila == null)
            return Enumerable.Range(0, Math.Max(0, cantidadMaxima)).ToList();

        if (!avanzado)
        {
            if (fila.SeleccionExplicitaCentro)
            {
                return SanitizarIndicesActivosEstacionesMYG(
                    fila.IndicesActivosCentro,
                    cantidadMaxima);
            }

            return ConstruirIndicesSimetricosEstacionesMYG(
                cantidadMaxima,
                fila.CantidadCentro);
        }

        if (zona <= 0)
        {
            if (fila.SeleccionExplicitaIzquierda)
            {
                return SanitizarIndicesActivosEstacionesMYG(
                    fila.IndicesActivosIzquierda,
                    cantidadMaxima);
            }

            return ConstruirIndicesSimetricosEstacionesMYG(
                cantidadMaxima,
                fila.CantidadIzquierda);
        }

        if (zona >= 2)
        {
            if (fila.SeleccionExplicitaDerecha)
            {
                return SanitizarIndicesActivosEstacionesMYG(
                    fila.IndicesActivosDerecha,
                    cantidadMaxima);
            }

            return ConstruirIndicesSimetricosEstacionesMYG(
                cantidadMaxima,
                fila.CantidadDerecha);
        }

        if (fila.SeleccionExplicitaCentro)
        {
            return SanitizarIndicesActivosEstacionesMYG(
                fila.IndicesActivosCentro,
                cantidadMaxima);
        }

        return ConstruirIndicesSimetricosEstacionesMYG(
            cantidadMaxima,
            fila.CantidadCentro);
    }

    private bool MismosIndicesActivosEstacionesMYG(
        HashSet<int> a,
        IEnumerable<int> b)
    {
        HashSet<int> bb = new HashSet<int>(
            b ?? Enumerable.Empty<int>());

        if (a == null)
            return bb.Count == 0;

        return a.SetEquals(bb);
    }

    private List<AceroVigaBarraLongitudinal2D>
        OrdenarDefinicionesGrupoEstacionesMYG(
            AceroVigaGrupoLongitudinal2D grupo,
            List<AceroVigaBarraLongitudinal2D> definiciones)
    {
        List<AceroVigaBarraLongitudinal2D> lista = definiciones != null
            ? definiciones.Where(x => x != null).ToList()
            : new List<AceroVigaBarraLongitudinal2D>();

        if (lista.Count <= 1)
            return lista;

        if (lista.All(x => x.ParametroSobreGuia >= 0.0))
        {
            bool ascendente = grupo == null ||
                grupo.ParametroFinGuia >= grupo.ParametroInicioGuia;

            return ascendente
                ? lista.OrderBy(x => x.ParametroSobreGuia).ToList()
                : lista.OrderByDescending(x => x.ParametroSobreGuia).ToList();
        }

        // V11.23: mismo orden de respaldo que usa el configurador visual.
        // Esto hace que el índice clicado corresponda exactamente con la barra
        // creada por el handler.
        return lista
            .Where(x => x != null && x.Punto != null)
            .OrderBy(x => x.Punto.U)
            .ThenByDescending(x => x.Punto.V)
            .ToList();
    }

    private void AgregarRegionCantidadEstacionMYG(
        List<RegionCantidadEstacionMYG> regiones,
        double inicio,
        double fin,
        IEnumerable<int> indicesActivos)
    {
        if (regiones == null || fin <= inicio + Tol)
            return;

        List<int> indices = (indicesActivos ?? Enumerable.Empty<int>())
            .Where(x => x >= 0)
            .Distinct()
            .OrderBy(x => x)
            .ToList();

        if (regiones.Count > 0)
        {
            RegionCantidadEstacionMYG ultima = regiones[regiones.Count - 1];
            if (ultima != null &&
                Math.Abs(ultima.Fin - inicio) <= Tol &&
                MismosIndicesActivosEstacionesMYG(
                    ultima.IndicesActivos,
                    indices))
            {
                ultima.Fin = fin;
                ultima.Cantidad = ultima.IndicesActivos.Count;
                return;
            }
        }

        regiones.Add(
            new RegionCantidadEstacionMYG(
                inicio,
                fin,
                indices));
    }

    private List<RegionCantidadEstacionMYG>
        ConstruirRegionesCantidadGrupoEstacionesMYG(
            DatosSerieVigas datos,
            List<AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG> filas,
            string grupoId,
            int cantidadMaxima,
            AceroLongitudinalVigasForm.ModoDistribucionLongitudinalMYG modo)
    {
        List<RegionCantidadEstacionMYG> regiones =
            new List<RegionCantidadEstacionMYG>();

        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0)
        {
            return regiones;
        }

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(x => x != null)
            .OrderBy(x => Math.Min(x.XInicioSerie, x.XFinSerie))
            .ToList();

        for (int i = 0; i < tramos.Count; i++)
        {
            TramoRecorridoSerie tramo = tramos[i];
            double inicio = Math.Min(tramo.XInicioSerie, tramo.XFinSerie);
            double fin = Math.Max(tramo.XInicioSerie, tramo.XFinSerie);
            if (fin <= inicio + Tol)
                continue;

            AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG fila =
                filas != null
                    ? filas.FirstOrDefault(x =>
                        x != null &&
                        x.TramoIndice == i &&
                        string.Equals(
                            x.GrupoId,
                            grupoId,
                            StringComparison.Ordinal))
                    : null;

            bool avanzado =
                modo ==
                AceroLongitudinalVigasForm
                    .ModoDistribucionLongitudinalMYG.EstacionesAvanzado;

            List<int> indicesIzq =
                ObtenerIndicesActivosFilaEstacionesMYG(
                    fila,
                    0,
                    avanzado,
                    cantidadMaxima);
            List<int> indicesCentro =
                ObtenerIndicesActivosFilaEstacionesMYG(
                    fila,
                    1,
                    avanzado,
                    cantidadMaxima);
            List<int> indicesDer =
                ObtenerIndicesActivosFilaEstacionesMYG(
                    fila,
                    2,
                    avanzado,
                    cantidadMaxima);

            if (modo ==
                AceroLongitudinalVigasForm
                    .ModoDistribucionLongitudinalMYG.EstacionesIntermedio)
            {
                AgregarRegionCantidadEstacionMYG(
                    regiones,
                    inicio,
                    fin,
                    indicesCentro);
                continue;
            }

            double tercio1 = inicio + (fin - inicio) / 3.0;
            double tercio2 = inicio + 2.0 * (fin - inicio) / 3.0;

            AgregarRegionCantidadEstacionMYG(
                regiones,
                inicio,
                tercio1,
                indicesIzq);
            AgregarRegionCantidadEstacionMYG(
                regiones,
                tercio1,
                tercio2,
                indicesCentro);
            AgregarRegionCantidadEstacionMYG(
                regiones,
                tercio2,
                fin,
                indicesDer);
        }

        return regiones;
    }


    // =========================================================
    // V11.36 - JERARQUÍA DE CONSERVACIÓN DEL EDITOR MAESTRO
    // =========================================================
    // Si un grupo NO fue alterado por INTERMEDIO/AVANZADO, no se debe
    // reconstruir barra por barra ni por lotes. Se ejecuta exactamente el
    // grupo maestro con su Regla, Cantidad, Espaciado y geometría original.
    //
    // Esta comprobación ignora los huecos longitudinales entre hosts/apoyos:
    // para decidir si el usuario modificó el grupo solo importa si TODAS las
    // regiones conservan TODAS las posiciones originales.
    private bool GrupoSinModificacionEstacionesMYG(
        List<RegionCantidadEstacionMYG> regiones,
        int cantidadMaxima)
    {
        if (regiones == null || regiones.Count == 0 || cantidadMaxima <= 0)
            return false;

        HashSet<int> todos = new HashSet<int>(
            Enumerable.Range(0, cantidadMaxima));

        bool encontroRegionValida = false;

        foreach (RegionCantidadEstacionMYG region in regiones)
        {
            if (region == null || region.Fin <= region.Inicio + Tol)
                continue;

            encontroRegionValida = true;

            if (region.IndicesActivos == null ||
                !region.IndicesActivos.SetEquals(todos))
            {
                return false;
            }
        }

        return encontroRegionValida;
    }

    private bool SubconjuntoEsGrupoCompletoEstacionesMYG(
        IEnumerable<int> indices,
        int cantidadMaxima)
    {
        if (cantidadMaxima <= 0)
            return false;

        HashSet<int> actual = new HashSet<int>(
            (indices ?? Enumerable.Empty<int>())
                .Where(i => i >= 0 && i < cantidadMaxima));

        return actual.SetEquals(
            Enumerable.Range(0, cantidadMaxima));
    }

    private List<IntervaloActivoBarraEstacionMYG>
        ConstruirIntervalosActivosBarraEstacionesMYG(
            List<RegionCantidadEstacionMYG> regiones,
            int rangoPrioridad,
            int indiceDefinicion,
            double extensionAlAparecer,
            double desarrolloAlDesaparecer,
            double limiteInicio,
            double limiteFin)
    {
        List<IntervaloActivoBarraEstacionMYG> baseActivos =
            new List<IntervaloActivoBarraEstacionMYG>();

        if (regiones == null || regiones.Count == 0)
            return baseActivos;

        extensionAlAparecer = Math.Max(0.0, extensionAlAparecer);
        desarrolloAlDesaparecer = Math.Max(0.0, desarrolloAlDesaparecer);

        // V11.33:
        // El DESARROLLO POR DIÁMETRO se aplica SIMÉTRICAMENTE en los dos
        // extremos de cada intervalo local de una barra:
        // - si NO existe en la región/tramo anterior, su inicio se prolonga
        //   hacia atrás la longitud de desarrollo de SU diámetro;
        // - si NO existe en la región/tramo siguiente, su final se prolonga
        //   hacia adelante la misma longitud de desarrollo de SU diámetro.
        // Si la barra continúa en la región vecina, no se introduce ningún corte.
        // En los extremos físicos de toda la serie se conservan las reglas
        // Desarrollo inicial / Desarrollo final del formulario principal.
        for (int i = 0; i < regiones.Count; i++)
        {
            RegionCantidadEstacionMYG region = regiones[i];
            bool activoActual =
                region != null &&
                region.Fin > region.Inicio + Tol &&
                region.IndicesActivos != null &&
                region.IndicesActivos.Contains(indiceDefinicion);

            if (!activoActual)
                continue;

            bool activoAnterior = false;
            if (i > 0)
            {
                RegionCantidadEstacionMYG anterior = regiones[i - 1];
                activoAnterior = anterior != null &&
                    anterior.IndicesActivos != null &&
                    anterior.IndicesActivos.Contains(indiceDefinicion) &&
                    Math.Abs(anterior.Fin - region.Inicio) <= Tol;
            }

            bool activoSiguiente = false;
            if (i + 1 < regiones.Count)
            {
                RegionCantidadEstacionMYG siguiente = regiones[i + 1];
                activoSiguiente = siguiente != null &&
                    siguiente.IndicesActivos != null &&
                    siguiente.IndicesActivos.Contains(indiceDefinicion) &&
                    Math.Abs(region.Fin - siguiente.Inicio) <= Tol;
            }

            double inicio = region.Inicio;
            double fin = region.Fin;

            // V11.33 - desarrollo de corte por diámetro en AMBOS extremos.
            // Una barra que nace dentro de la serie es, geométricamente, una
            // barra que termina hacia el tramo anterior; por eso necesita la
            // misma longitud de desarrollo que cuando desaparece hacia adelante.
            if (!activoAnterior && inicio > limiteInicio + Tol)
                inicio -= desarrolloAlDesaparecer;

            if (!activoSiguiente && fin < limiteFin - Tol)
                fin += desarrolloAlDesaparecer;

            inicio = Math.Max(limiteInicio, inicio);
            fin = Math.Min(limiteFin, fin);

            if (fin <= inicio + Tol)
                continue;

            if (baseActivos.Count > 0)
            {
                IntervaloActivoBarraEstacionMYG ultimo =
                    baseActivos[baseActivos.Count - 1];

                if (ultimo != null && inicio <= ultimo.Fin + Tol)
                {
                    ultimo.Fin = Math.Max(ultimo.Fin, fin);
                    continue;
                }
            }

            baseActivos.Add(
                new IntervaloActivoBarraEstacionMYG(
                    inicio,
                    fin,
                    indiceDefinicion));
        }

        return baseActivos;
    }

    private string ClaveIntervaloEstacionMYG(double inicio, double fin)
    {
        double toleranciaClave = UnitUtils.ConvertToInternalUnits(
            0.1,
            UnitTypeId.Centimeters);

        if (toleranciaClave <= Tol)
            toleranciaClave = 0.001;

        long a = (long)Math.Round(inicio / toleranciaClave);
        long b = (long)Math.Round(fin / toleranciaClave);
        return a.ToString() + "|" + b.ToString();
    }



    // =========================================================
    // V11.44 - EMPALMES CON LONGITUD COMERCIAL ACUMULADA
    // =========================================================
    // En modo por estaciones un mismo acero lógico puede materializarse como
    // varios Rebar (por tramo/host), pero el contador de longitud comercial NO
    // debe reiniciarse al cambiar de viga. Estas rutinas construyen primero un
    // plan de piezas comerciales sobre la estación GLOBAL y después cada lote
    // físico recorta ese plan a su propio intervalo.
    private string ClaveIndicesLoteEstacionesMYG(
        LoteIntervaloEstacionMYG lote)
    {
        if (lote == null || lote.Indices == null)
            return string.Empty;

        return string.Join(",",
            lote.Indices
                .Where(i => i >= 0)
                .Distinct()
                .OrderBy(i => i));
    }

    private bool LotesTienenMismosIndicesEstacionesMYG(
        LoteIntervaloEstacionMYG a,
        LoteIntervaloEstacionMYG b)
    {
        if (a == null || b == null)
            return false;

        HashSet<int> aa = new HashSet<int>(
            a.Indices ?? new List<int>());
        HashSet<int> bb = new HashSet<int>(
            b.Indices ?? new List<int>());

        return aa.SetEquals(bb);
    }

    private bool LotesSonContinuosLogicamenteEntreTramosMYG(
        LoteIntervaloEstacionMYG anterior,
        LoteIntervaloEstacionMYG siguiente,
        DatosSerieVigas datos)
    {
        if (anterior == null || siguiente == null || datos == null)
            return false;

        if (!LotesTienenMismosIndicesEstacionesMYG(anterior, siguiente))
            return false;

        // Si ya se tocan/solapan, son una sola continuidad lógica.
        if (siguiente.Inicio <= anterior.Fin + Tol)
            return true;

        if (datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count < 2)
        {
            return false;
        }

        double toleranciaCara = UnitUtils.ConvertToInternalUnits(
            1.0,
            UnitTypeId.Centimeters);

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Longitud > Tol)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        for (int i = 0; i < tramos.Count - 1; i++)
        {
            double finIzquierdo = Math.Max(
                tramos[i].XInicioSerie,
                tramos[i].XFinSerie);
            double inicioDerecho = Math.Min(
                tramos[i + 1].XInicioSerie,
                tramos[i + 1].XFinSerie);

            bool anteriorLlegaAlBorde =
                anterior.Inicio <= finIzquierdo + toleranciaCara &&
                anterior.Fin >= finIzquierdo - toleranciaCara;

            bool siguienteNaceEnBorde =
                siguiente.Inicio <= inicioDerecho + toleranciaCara &&
                siguiente.Fin >= inicioDerecho - toleranciaCara;

            if (anteriorLlegaAlBorde && siguienteNaceEnBorde)
                return true;
        }

        return false;
    }

    private List<SegmentoAceroLongitudinal>
        ClonarSegmentosLongitudinalesMYG(
            IEnumerable<SegmentoAceroLongitudinal> origen)
    {
        List<SegmentoAceroLongitudinal> resultado =
            new List<SegmentoAceroLongitudinal>();

        foreach (SegmentoAceroLongitudinal seg in
            origen ?? Enumerable.Empty<SegmentoAceroLongitudinal>())
        {
            if (seg == null || seg.XFin <= seg.XInicio + Tol)
                continue;

            SegmentoAceroLongitudinal copia =
                new SegmentoAceroLongitudinal(seg.XInicio, seg.XFin)
                {
                    EsPrimero = seg.EsPrimero,
                    EsUltimo = seg.EsUltimo,
                    TieneEmpalmeInicio = seg.TieneEmpalmeInicio,
                    TieneEmpalmeFin = seg.TieneEmpalmeFin,
                    EmpalmeInicioColinealSeguro =
                        seg.EmpalmeInicioColinealSeguro
                };

            resultado.Add(copia);
        }

        return resultado;
    }

    private List<SegmentoAceroLongitudinal>
        RecortarSegmentosAcumuladosAlLoteMYG(
            IEnumerable<SegmentoAceroLongitudinal> segmentosGlobales,
            double inicioLote,
            double finLote)
    {
        List<SegmentoAceroLongitudinal> resultado =
            new List<SegmentoAceroLongitudinal>();

        if (finLote <= inicioLote + Tol)
            return resultado;

        foreach (SegmentoAceroLongitudinal global in
            segmentosGlobales ?? Enumerable.Empty<SegmentoAceroLongitudinal>())
        {
            if (global == null || global.XFin <= global.XInicio + Tol)
                continue;

            double inicio = Math.Max(inicioLote, global.XInicio);
            double fin = Math.Min(finLote, global.XFin);

            if (fin <= inicio + Tol)
                continue;

            bool conservaInicioGlobal =
                Math.Abs(inicio - global.XInicio) <= Tol;
            bool conservaFinGlobal =
                Math.Abs(fin - global.XFin) <= Tol;

            SegmentoAceroLongitudinal recortado =
                new SegmentoAceroLongitudinal(inicio, fin)
                {
                    // El corte entre hosts NO es un empalme físico. Por eso
                    // solo se conservan las banderas cuando el punto real del
                    // empalme está dentro de este lote.
                    EsPrimero =
                        global.EsPrimero && conservaInicioGlobal,
                    EsUltimo =
                        global.EsUltimo && conservaFinGlobal,
                    TieneEmpalmeInicio =
                        global.TieneEmpalmeInicio && conservaInicioGlobal,
                    TieneEmpalmeFin =
                        global.TieneEmpalmeFin && conservaFinGlobal,
                    EmpalmeInicioColinealSeguro = false
                };

            resultado.Add(recortado);
        }

        return resultado;
    }

    private void PrepararEmpalmesAcumuladosLotesEstacionesMYG(
        DatosSerieVigas datos,
        IEnumerable<LoteIntervaloEstacionMYG> lotesEntrada,
        List<AceroVigaBarraLongitudinal2D> definicionesOrdenadas,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        double limiteInicioGlobal,
        double limiteFinGlobal)
    {
        if (!crearEmpalmes || datos == null || longitudBarra <= Tol ||
            definicionesOrdenadas == null ||
            definicionesOrdenadas.Count == 0)
        {
            return;
        }

        List<LoteIntervaloEstacionMYG> normales =
            (lotesEntrada ?? Enumerable.Empty<LoteIntervaloEstacionMYG>())
                .Where(l =>
                    l != null &&
                    l.TipoEspecial == TipoLoteEspecialEstacionMYG.Normal &&
                    l.Indices != null &&
                    l.Indices.Count > 0 &&
                    l.Fin > l.Inicio + Tol)
                .ToList();

        if (normales.Count == 0)
            return;

        AceroVigaBarraLongitudinal2D definicionBase =
            definicionesOrdenadas.FirstOrDefault(d => d != null);
        if (definicionBase == null || definicionBase.TipoBarra == null)
            return;

        int tipoRuta;
        string textoIgnorado;
        ObtenerClasificacionCapaManualMYG(
            definicionBase,
            out tipoRuta,
            out textoIgnorado);

        double longitudEmpalme = tipoRuta > 0
            ? longitudEmpalmeSuperior
            : (tipoRuta < 0
                ? longitudEmpalmeInferior
                : longitudEmpalmeCentral);

        if (longitudEmpalme <= Tol)
            return;

        double diametro = ObtenerDiametroBarra(definicionBase.TipoBarra);

        foreach (IGrouping<string, LoteIntervaloEstacionMYG> grupoFirma in
            normales.GroupBy(ClaveIndicesLoteEstacionesMYG))
        {
            List<LoteIntervaloEstacionMYG> ordenados = grupoFirma
                .OrderBy(l => l.Inicio)
                .ThenBy(l => l.Fin)
                .ToList();

            List<LoteIntervaloEstacionMYG> cadena =
                new List<LoteIntervaloEstacionMYG>();

            Action finalizarCadena = () =>
            {
                if (cadena.Count == 0)
                    return;

                double inicioCadena = cadena.Min(l => l.Inicio);
                double finCadena = cadena.Max(l => l.Fin);

                bool tocaInicioSerie =
                    inicioCadena <= limiteInicioGlobal + Tol;
                bool tocaFinSerie =
                    finCadena >= limiteFinGlobal - Tol;

                double inicioPlan = inicioCadena;
                double finPlan = finCadena;

                if (tocaInicioSerie && desarrolloInicioHabilitado)
                    inicioPlan -= Math.Max(0.0, longitudDesarrolloInicio);

                if (tocaFinSerie && desarrolloFinHabilitado)
                    finPlan += Math.Max(0.0, longitudDesarrolloFin);

                List<SegmentoAceroLongitudinal> plan =
                    ConstruirSegmentosLongitudinales(
                        datos,
                        tipoRuta,
                        inicioPlan,
                        finPlan,
                        true,
                        longitudBarra,
                        longitudEmpalme,
                        0.0,
                        0.0,
                        diametro,
                        definicionBase.TipoBarra);

                if (plan != null && plan.Count > 0)
                {
                    foreach (LoteIntervaloEstacionMYG lote in cadena)
                    {
                        lote.SegmentosEmpalmeAcumulados =
                            ClonarSegmentosLongitudinalesMYG(plan);
                    }
                }

                cadena.Clear();
            };

            foreach (LoteIntervaloEstacionMYG lote in ordenados)
            {
                if (cadena.Count == 0)
                {
                    cadena.Add(lote);
                    continue;
                }

                LoteIntervaloEstacionMYG anterior =
                    cadena[cadena.Count - 1];

                if (LotesSonContinuosLogicamenteEntreTramosMYG(
                        anterior,
                        lote,
                        datos))
                {
                    cadena.Add(lote);
                }
                else
                {
                    finalizarCadena();
                    cadena.Add(lote);
                }
            }

            finalizarCadena();
        }
    }

    private string ObtenerTextoTipoEspecialLoteMYG(
        LoteIntervaloEstacionMYG lote,
        AceroVigaBarraLongitudinal2D definicion)
    {
        if (lote == null || definicion == null)
            return null;

        // V11.45 - jerarquía corregida:
        // BASTÓN   = refuerzo SUPERIOR.
        // BALANCÍN = refuerzo INFERIOR.
        if (lote.TipoEspecial == TipoLoteEspecialEstacionMYG.Baston)
            return "Longitudinal - Balancin";

        if (lote.TipoEspecial == TipoLoteEspecialEstacionMYG.Balancin)
            return "Longitudinal - Bastidor";

        return null;
    }

    // =========================================================
    // V11.45 - BASTONES SUPERIORES Y BALANCINES INFERIORES
    // =========================================================
    // BASTÓN: acero superior localizado en los APOYOS EXTREMOS.
    // - desde la cara extrema del tramo hasta L/3 dentro de la luz;
    // - en la esquina exterior se agrega el desarrollo configurado por Ø.
    //
    // BALANCÍN: acero INFERIOR localizado sobre APOYOS INTERIORES.
    // - L_izq/3 desde la cara del apoyo hacia el tramo izquierdo;
    // - L_der/3 desde la cara del apoyo hacia el tramo derecho.
    //
    // Ambos respetan la posición exacta seleccionada en el editor maestro.
    private bool IndiceActivoEnBordeTramoEspecialMYG(
        List<AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG> filas,
        string grupoId,
        int tramoIndice,
        bool bordeDerecho,
        int indiceDefinicion,
        int cantidadMaxima,
        AceroLongitudinalVigasForm.ModoDistribucionLongitudinalMYG modo)
    {
        AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG fila =
            filas != null
                ? filas.FirstOrDefault(f =>
                    f != null &&
                    f.TramoIndice == tramoIndice &&
                    string.Equals(
                        f.GrupoId,
                        grupoId,
                        StringComparison.Ordinal))
                : null;

        bool avanzado =
            modo ==
            AceroLongitudinalVigasForm
                .ModoDistribucionLongitudinalMYG.EstacionesAvanzado;

        int zona = avanzado
            ? (bordeDerecho ? 2 : 0)
            : 1;

        List<int> activos =
            ObtenerIndicesActivosFilaEstacionesMYG(
                fila,
                zona,
                avanzado,
                cantidadMaxima);

        return activos.Contains(indiceDefinicion);
    }

    private void AgregarLoteEspecialEstacionesMYG(
        Dictionary<string, LoteIntervaloEstacionMYG> lotes,
        double inicio,
        double fin,
        int indice,
        TipoLoteEspecialEstacionMYG tipoEspecial)
    {
        if (lotes == null ||
            indice < 0 ||
            fin <= inicio + Tol)
        {
            return;
        }

        string clave =
            ((int)tipoEspecial).ToString() + "|" +
            ClaveIntervaloEstacionMYG(inicio, fin);

        LoteIntervaloEstacionMYG lote;
        if (!lotes.TryGetValue(clave, out lote))
        {
            lote = new LoteIntervaloEstacionMYG
            {
                Inicio = inicio,
                Fin = fin,
                TipoEspecial = tipoEspecial
            };
            lotes.Add(clave, lote);
        }

        if (!lote.Indices.Contains(indice))
            lote.Indices.Add(indice);
    }

    private List<LoteIntervaloEstacionMYG>
        ConstruirLotesEspecialesBastonBalancinMYG(
            DatosSerieVigas datos,
            List<AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG> filas,
            string grupoId,
            List<AceroVigaBarraLongitudinal2D> definiciones,
            AceroLongitudinalVigasForm.ModoDistribucionLongitudinalMYG modo)
    {
        Dictionary<string, LoteIntervaloEstacionMYG> lotes =
            new Dictionary<string, LoteIntervaloEstacionMYG>();

        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0 ||
            definiciones == null ||
            definiciones.Count == 0 ||
            string.IsNullOrWhiteSpace(grupoId) ||
            Form == null)
        {
            return lotes.Values.ToList();
        }

        int cantidadMaxima = definiciones.Count;

        // V11.45 - validar la familia resistente del grupo antes de construir
        // refuerzos especiales. Esto también protege archivos guardados con
        // versiones anteriores donde BALANCÍN podía haberse marcado arriba.
        int tipoRutaEspecial = 0;
        string textoRutaEspecial = string.Empty;
        ObtenerClasificacionCapaManualMYG(
            definiciones.FirstOrDefault(),
            out tipoRutaEspecial,
            out textoRutaEspecial);

        bool grupoEsSuperiorEspecial = tipoRutaEspecial > 0;
        bool grupoEsInferiorEspecial = tipoRutaEspecial < 0;

        List<TramoRecorridoSerie> tramos =
            datos.TramosRecorrido
                .Where(t => t != null && t.Longitud > Tol)
                .OrderBy(t =>
                    Math.Min(
                        t.XInicioSerie,
                        t.XFinSerie))
                .ToList();

        if (tramos.Count == 0)
            return lotes.Values.ToList();

        Func<int, HashSet<int>> obtenerBastonesTramo = (tramoIndice) =>
            grupoEsSuperiorEspecial
                ? new HashSet<int>(
                    Form.ObtenerIndicesBastonGrupoTramoMYG(
                            grupoId,
                            tramoIndice)
                        .Where(i => i >= 0 && i < cantidadMaxima))
                : new HashSet<int>();

        Func<int, HashSet<int>> obtenerBalancinesTramo = (tramoIndice) =>
            grupoEsInferiorEspecial
                ? new HashSet<int>(
                    Form.ObtenerIndicesBalancinGrupoTramoMYG(
                            grupoId,
                            tramoIndice)
                        .Where(i => i >= 0 && i < cantidadMaxima))
                : new HashSet<int>();

        // ---------------------------------------------------------
        // V11.41 - BASTONES POR TRAMO.
        // ---------------------------------------------------------
        // Una posición marcada como BASTÓN deja de ser una barra continua
        // dentro de ESE tramo y se convierte en DOS piezas locales:
        //
        //   cara izquierda -> L/3     [ tercio central VACÍO ]
        //                         L/3 <- cara derecha
        //
        // Por eso se generan los dos tercios extremos de CADA tramo marcado,
        // no solamente los extremos físicos de toda la serie.
        //
        // El desarrollo/gancho de los extremos EXTERIORES de la serie NO se
        // incluye aquí. Se aplica después, durante la creación, usando los
        // inputs generales Desarrollo inicial/final + AUTO + GANCHO. De esta
        // forma la geometría especial obedece exactamente a la ventana principal.
        // ---------------------------------------------------------
        for (int i = 0; i < tramos.Count; i++)
        {
            HashSet<int> bastonesTramo = obtenerBastonesTramo(i);
            if (bastonesTramo.Count == 0)
                continue;

            TramoRecorridoSerie tramo = tramos[i];
            double a = Math.Min(tramo.XInicioSerie, tramo.XFinSerie);
            double b = Math.Max(tramo.XInicioSerie, tramo.XFinSerie);
            double tercio = Math.Max(0.0, b - a) / 3.0;

            if (tercio <= Tol)
                continue;

            foreach (int indice in bastonesTramo.OrderBy(x => x))
            {
                bool activoIzquierda =
                    IndiceActivoEnBordeTramoEspecialMYG(
                        filas,
                        grupoId,
                        i,
                        false,
                        indice,
                        cantidadMaxima,
                        modo);

                bool activoDerecha =
                    IndiceActivoEnBordeTramoEspecialMYG(
                        filas,
                        grupoId,
                        i,
                        true,
                        indice,
                        cantidadMaxima,
                        modo);

                if (activoIzquierda)
                {
                    AgregarLoteEspecialEstacionesMYG(
                        lotes,
                        a,
                        Math.Min(b, a + tercio),
                        indice,
                        TipoLoteEspecialEstacionMYG.Baston);
                }

                if (activoDerecha)
                {
                    AgregarLoteEspecialEstacionesMYG(
                        lotes,
                        Math.Max(a, b - tercio),
                        b,
                        indice,
                        TipoLoteEspecialEstacionMYG.Baston);
                }
            }
        }

        // ---------------------------------------------------------
        // BALANCINES POR TRAMO.
        // En cada apoyo interior se toma la UNIÓN de la selección especial
        // hecha en los dos tramos vecinos. Así una selección hecha en T1
        // solo afecta los apoyos pertenecientes a T1 y no se replica en T2.
        // Geométricamente el balancín cruza el apoyo y entra L/3 en ambos
        // tramos, como exige su propia definición.
        // ---------------------------------------------------------
        if (tramos.Count >= 2)
        {
            for (int i = 0; i < tramos.Count - 1; i++)
            {
                TramoRecorridoSerie izquierdo = tramos[i];
                TramoRecorridoSerie derecho = tramos[i + 1];

                double caraIzquierda =
                    Math.Max(
                        Math.Min(izquierdo.XInicioSerie, izquierdo.XFinSerie),
                        Math.Min(derecho.XInicioSerie, derecho.XFinSerie));
                double caraDerecha =
                    Math.Min(
                        Math.Max(izquierdo.XInicioSerie, izquierdo.XFinSerie),
                        Math.Max(derecho.XInicioSerie, derecho.XFinSerie));

                // Si existe un apoyo/vacío real entre vigas, las caras quedan
                // separadas. Cuando se tocan, ambas coordenadas coinciden.
                double finIzquierdo =
                    Math.Max(izquierdo.XInicioSerie, izquierdo.XFinSerie);
                double inicioDerecho =
                    Math.Min(derecho.XInicioSerie, derecho.XFinSerie);
                caraIzquierda = finIzquierdo;
                caraDerecha = inicioDerecho;

                double tercioIzquierdo =
                    Math.Max(0.0, izquierdo.Longitud) / 3.0;
                double tercioDerecho =
                    Math.Max(0.0, derecho.Longitud) / 3.0;

                HashSet<int> seleccionados = obtenerBalancinesTramo(i);
                seleccionados.UnionWith(obtenerBalancinesTramo(i + 1));

                foreach (int indice in seleccionados)
                {
                    bool activoIzq =
                        IndiceActivoEnBordeTramoEspecialMYG(
                            filas,
                            grupoId,
                            i,
                            true,
                            indice,
                            cantidadMaxima,
                            modo);

                    bool activoDer =
                        IndiceActivoEnBordeTramoEspecialMYG(
                            filas,
                            grupoId,
                            i + 1,
                            false,
                            indice,
                            cantidadMaxima,
                            modo);

                    if (!activoIzq || !activoDer)
                        continue;

                    AgregarLoteEspecialEstacionesMYG(
                        lotes,
                        caraIzquierda - tercioIzquierdo,
                        caraDerecha + tercioDerecho,
                        indice,
                        TipoLoteEspecialEstacionMYG.Balancin);
                }
            }
        }

        List<LoteIntervaloEstacionMYG> resultadoEspecial =
            lotes.Values
                .Where(l =>
                    l != null &&
                    l.Indices != null &&
                    l.Indices.Count > 0 &&
                    l.Fin > l.Inicio + Tol)
                .OrderBy(l => l.Inicio)
                .ThenByDescending(l => l.Indices.Count)
                .ToList();

        // =========================================================
        // V11.47 - CONTINUIDAD FÍSICA DE BASTÓN / BALANCÍN ENTRE TRAMOS
        // =========================================================
        // Si una MISMA posición especial llega hasta la cara final de un tramo
        // y vuelve a arrancar en la cara inicial del tramo consecutivo, no son
        // dos armaduras independientes. Es UNA sola barra lógica que atraviesa
        // el apoyo/vacío entre hosts.
        //
        // Se fusiona POR POSICIÓN EXACTA para no mezclar barras diferentes.
        // Luego se vuelven a agrupar posiciones que comparten exactamente el
        // mismo recorrido, preservando Número fijo cuando corresponda.
        resultadoEspecial = FusionarLotesEspecialesContinuosEntreTramosMYG(
            datos,
            resultadoEspecial);

        return resultadoEspecial;
    }

    private sealed class IntervaloEspecialIndiceMYG
    {
        public TipoLoteEspecialEstacionMYG TipoEspecial;
        public int Indice;
        public double Inicio;
        public double Fin;
    }

    private List<LoteIntervaloEstacionMYG>
        FusionarLotesEspecialesContinuosEntreTramosMYG(
            DatosSerieVigas datos,
            List<LoteIntervaloEstacionMYG> lotesEntrada)
    {
        List<LoteIntervaloEstacionMYG> vacio =
            new List<LoteIntervaloEstacionMYG>();

        if (lotesEntrada == null || lotesEntrada.Count == 0)
            return vacio;

        // Expandir cada lote por índice. Esto permite fusionar únicamente la
        // barra que realmente continúa, aunque un set tenga otras posiciones
        // que terminen en ese mismo tramo.
        List<IntervaloEspecialIndiceMYG> porIndice =
            new List<IntervaloEspecialIndiceMYG>();

        foreach (LoteIntervaloEstacionMYG lote in lotesEntrada)
        {
            if (lote == null ||
                lote.Indices == null ||
                lote.Indices.Count == 0 ||
                lote.Fin <= lote.Inicio + Tol ||
                lote.TipoEspecial == TipoLoteEspecialEstacionMYG.Normal)
            {
                continue;
            }

            foreach (int indice in lote.Indices.Distinct())
            {
                if (indice < 0)
                    continue;

                porIndice.Add(
                    new IntervaloEspecialIndiceMYG
                    {
                        TipoEspecial = lote.TipoEspecial,
                        Indice = indice,
                        Inicio = Math.Min(lote.Inicio, lote.Fin),
                        Fin = Math.Max(lote.Inicio, lote.Fin)
                    });
            }
        }

        if (porIndice.Count == 0)
            return lotesEntrada;

        List<IntervaloEspecialIndiceMYG> fusionados =
            new List<IntervaloEspecialIndiceMYG>();

        foreach (IGrouping<string, IntervaloEspecialIndiceMYG> grupo in
            porIndice.GroupBy(x =>
                ((int)x.TipoEspecial).ToString() + "|" + x.Indice.ToString()))
        {
            List<IntervaloEspecialIndiceMYG> ordenados =
                grupo
                    .Where(x => x != null && x.Fin > x.Inicio + Tol)
                    .OrderBy(x => x.Inicio)
                    .ThenBy(x => x.Fin)
                    .ToList();

            if (ordenados.Count == 0)
                continue;

            IntervaloEspecialIndiceMYG actual =
                new IntervaloEspecialIndiceMYG
                {
                    TipoEspecial = ordenados[0].TipoEspecial,
                    Indice = ordenados[0].Indice,
                    Inicio = ordenados[0].Inicio,
                    Fin = ordenados[0].Fin
                };

            for (int i = 1; i < ordenados.Count; i++)
            {
                IntervaloEspecialIndiceMYG siguiente = ordenados[i];

                bool seTocanOSolapan =
                    siguiente.Inicio <= actual.Fin + Tol;

                bool soloHayApoyoEntreAmbas =
                    !seTocanOSolapan &&
                    EsSaltoSoloEntreCarasDeTramosConsecutivosMYG(
                        datos,
                        actual.Fin,
                        siguiente.Inicio);

                if (seTocanOSolapan || soloHayApoyoEntreAmbas)
                {
                    actual.Fin = Math.Max(actual.Fin, siguiente.Fin);
                }
                else
                {
                    fusionados.Add(actual);
                    actual =
                        new IntervaloEspecialIndiceMYG
                        {
                            TipoEspecial = siguiente.TipoEspecial,
                            Indice = siguiente.Indice,
                            Inicio = siguiente.Inicio,
                            Fin = siguiente.Fin
                        };
                }
            }

            fusionados.Add(actual);
        }

        // Volver a agrupar posiciones que ahora comparten exactamente el mismo
        // intervalo. Así un Número fijo = 2 sigue siendo UN Rebar Set de 2 y no
        // dos elementos individuales.
        Dictionary<string, LoteIntervaloEstacionMYG> reagrupados =
            new Dictionary<string, LoteIntervaloEstacionMYG>();

        foreach (IntervaloEspecialIndiceMYG pieza in fusionados)
        {
            if (pieza == null || pieza.Fin <= pieza.Inicio + Tol)
                continue;

            string clave =
                ((int)pieza.TipoEspecial).ToString() + "|" +
                ClaveIntervaloEstacionMYG(pieza.Inicio, pieza.Fin);

            LoteIntervaloEstacionMYG lote;
            if (!reagrupados.TryGetValue(clave, out lote))
            {
                lote = new LoteIntervaloEstacionMYG
                {
                    Inicio = pieza.Inicio,
                    Fin = pieza.Fin,
                    TipoEspecial = pieza.TipoEspecial
                };
                reagrupados.Add(clave, lote);
            }

            if (!lote.Indices.Contains(pieza.Indice))
                lote.Indices.Add(pieza.Indice);
        }

        return reagrupados.Values
            .Where(l =>
                l != null &&
                l.Indices != null &&
                l.Indices.Count > 0 &&
                l.Fin > l.Inicio + Tol)
            .OrderBy(l => l.Inicio)
            .ThenBy(l => l.TipoEspecial)
            .ThenByDescending(l => l.Indices.Count)
            .ToList();
    }

    private bool EsSaltoSoloEntreCarasDeTramosConsecutivosMYG(
        DatosSerieVigas datos,
        double finIzquierda,
        double inicioDerecha)
    {
        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count < 2 ||
            inicioDerecha < finIzquierda - Tol)
        {
            return false;
        }

        List<TramoRecorridoSerie> tramos =
            datos.TramosRecorrido
                .Where(t => t != null && t.Longitud > Tol)
                .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
                .ToList();

        // Tolerancia geométrica únicamente para reconocer la cara. No se usa
        // para saltar una zona de acero real dentro de una viga.
        double toleranciaCara = UnitUtils.ConvertToInternalUnits(
            0.5,
            UnitTypeId.Centimeters);

        for (int i = 0; i < tramos.Count - 1; i++)
        {
            double finTramo = Math.Max(
                tramos[i].XInicioSerie,
                tramos[i].XFinSerie);

            double inicioTramoSiguiente = Math.Min(
                tramos[i + 1].XInicioSerie,
                tramos[i + 1].XFinSerie);

            if (Math.Abs(finIzquierda - finTramo) <= toleranciaCara &&
                Math.Abs(inicioDerecha - inicioTramoSiguiente) <= toleranciaCara)
            {
                return true;
            }
        }

        return false;
    }

    // V11.39 - quita de los recorridos normales únicamente el tramo de una
    // barra que ya será reemplazado por un BASTÓN/BALANCÍN. Esto evita tanto
    // la superposición como la desaparición de esa misma barra en otros tramos.
    private List<IntervaloActivoBarraEstacionMYG>
        RestarLotesEspecialesDeIntervalosNormalesMYG(
            List<IntervaloActivoBarraEstacionMYG> intervalosNormales,
            List<LoteIntervaloEstacionMYG> lotesEspeciales,
            int indiceDefinicion)
    {
        List<IntervaloActivoBarraEstacionMYG> resultado =
            new List<IntervaloActivoBarraEstacionMYG>();

        if (intervalosNormales == null || intervalosNormales.Count == 0)
            return resultado;

        List<Tuple<double, double>> cortes =
            (lotesEspeciales ?? new List<LoteIntervaloEstacionMYG>())
                .Where(l =>
                    l != null &&
                    l.Indices != null &&
                    l.Indices.Contains(indiceDefinicion) &&
                    l.Fin > l.Inicio + Tol)
                .Select(l => Tuple.Create(l.Inicio, l.Fin))
                .OrderBy(x => x.Item1)
                .ToList();

        if (cortes.Count == 0)
            return intervalosNormales
                .Where(x => x != null)
                .Select(x => new IntervaloActivoBarraEstacionMYG(
                    x.Inicio,
                    x.Fin,
                    x.IndiceDefinicion))
                .ToList();

        foreach (IntervaloActivoBarraEstacionMYG original in intervalosNormales)
        {
            if (original == null || original.Fin <= original.Inicio + Tol)
                continue;

            List<Tuple<double, double>> fragmentos =
                new List<Tuple<double, double>>
                {
                    Tuple.Create(original.Inicio, original.Fin)
                };

            foreach (Tuple<double, double> corte in cortes)
            {
                List<Tuple<double, double>> siguientes =
                    new List<Tuple<double, double>>();

                foreach (Tuple<double, double> frag in fragmentos)
                {
                    double a = frag.Item1;
                    double b = frag.Item2;
                    double c = corte.Item1;
                    double d = corte.Item2;

                    if (d <= a + Tol || c >= b - Tol)
                    {
                        siguientes.Add(frag);
                        continue;
                    }

                    if (c > a + Tol)
                        siguientes.Add(Tuple.Create(a, Math.Min(c, b)));
                    if (d < b - Tol)
                        siguientes.Add(Tuple.Create(Math.Max(d, a), b));
                }

                fragmentos = siguientes;
                if (fragmentos.Count == 0)
                    break;
            }

            foreach (Tuple<double, double> frag in fragmentos)
            {
                if (frag.Item2 <= frag.Item1 + Tol)
                    continue;

                resultado.Add(
                    new IntervaloActivoBarraEstacionMYG(
                        frag.Item1,
                        frag.Item2,
                        indiceDefinicion));
            }
        }

        return resultado;
    }

    // =========================================================
    // V11.41 - UN BASTÓN REEMPLAZA LA BARRA NORMAL EN TODO SU TRAMO
    // =========================================================
    // La selección BASTÓN no es un refuerzo adicional encima de una barra
    // continua. Para esa posición concreta, en ese tramo, la barra normal se
    // elimina por completo y luego se crean únicamente los dos tercios extremos.
    // Así el tercio central queda realmente VACÍO, tanto en Revit como en la
    // lógica de continuidad del motor por estaciones.
    private List<IntervaloActivoBarraEstacionMYG>
        RestarTramosBastonDeIntervalosNormalesMYG(
            List<IntervaloActivoBarraEstacionMYG> intervalosNormales,
            DatosSerieVigas datos,
            List<AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG> filas,
            string grupoId,
            int indiceDefinicion,
            int cantidadMaxima,
            AceroLongitudinalVigasForm.ModoDistribucionLongitudinalMYG modo)
    {
        List<IntervaloActivoBarraEstacionMYG> resultado =
            new List<IntervaloActivoBarraEstacionMYG>();

        if (intervalosNormales == null || intervalosNormales.Count == 0)
            return resultado;

        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0 ||
            Form == null ||
            string.IsNullOrWhiteSpace(grupoId))
        {
            return intervalosNormales
                .Where(x => x != null)
                .Select(x => new IntervaloActivoBarraEstacionMYG(
                    x.Inicio,
                    x.Fin,
                    x.IndiceDefinicion))
                .ToList();
        }

        List<TramoRecorridoSerie> tramos =
            datos.TramosRecorrido
                .Where(t => t != null && t.Longitud > Tol)
                .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
                .ToList();

        List<Tuple<double, double>> cortes =
            new List<Tuple<double, double>>();

        for (int i = 0; i < tramos.Count; i++)
        {
            List<int> bastones =
                Form.ObtenerIndicesBastonGrupoTramoMYG(grupoId, i);

            if (bastones == null || !bastones.Contains(indiceDefinicion))
                continue;

            bool activoIzq =
                IndiceActivoEnBordeTramoEspecialMYG(
                    filas,
                    grupoId,
                    i,
                    false,
                    indiceDefinicion,
                    cantidadMaxima,
                    modo);

            bool activoDer =
                IndiceActivoEnBordeTramoEspecialMYG(
                    filas,
                    grupoId,
                    i,
                    true,
                    indiceDefinicion,
                    cantidadMaxima,
                    modo);

            // Si la clasificación quedó obsoleta porque el usuario apagó esa
            // barra en todas las zonas, no se corta nada.
            if (!activoIzq && !activoDer)
                continue;

            double a = Math.Min(
                tramos[i].XInicioSerie,
                tramos[i].XFinSerie);
            double b = Math.Max(
                tramos[i].XInicioSerie,
                tramos[i].XFinSerie);

            if (b > a + Tol)
                cortes.Add(Tuple.Create(a, b));
        }

        if (cortes.Count == 0)
        {
            return intervalosNormales
                .Where(x => x != null)
                .Select(x => new IntervaloActivoBarraEstacionMYG(
                    x.Inicio,
                    x.Fin,
                    x.IndiceDefinicion))
                .ToList();
        }

        cortes = cortes
            .OrderBy(x => x.Item1)
            .ToList();

        foreach (IntervaloActivoBarraEstacionMYG original in intervalosNormales)
        {
            if (original == null || original.Fin <= original.Inicio + Tol)
                continue;

            List<Tuple<double, double>> fragmentos =
                new List<Tuple<double, double>>
                {
                    Tuple.Create(original.Inicio, original.Fin)
                };

            foreach (Tuple<double, double> corte in cortes)
            {
                List<Tuple<double, double>> siguientes =
                    new List<Tuple<double, double>>();

                foreach (Tuple<double, double> frag in fragmentos)
                {
                    double a = frag.Item1;
                    double b = frag.Item2;
                    double c = corte.Item1;
                    double d = corte.Item2;

                    if (d <= a + Tol || c >= b - Tol)
                    {
                        siguientes.Add(frag);
                        continue;
                    }

                    if (c > a + Tol)
                        siguientes.Add(Tuple.Create(a, Math.Min(c, b)));
                    if (d < b - Tol)
                        siguientes.Add(Tuple.Create(Math.Max(d, a), b));
                }

                fragmentos = siguientes;
                if (fragmentos.Count == 0)
                    break;
            }

            foreach (Tuple<double, double> frag in fragmentos)
            {
                if (frag.Item2 <= frag.Item1 + Tol)
                    continue;

                resultado.Add(
                    new IntervaloActivoBarraEstacionMYG(
                        frag.Item1,
                        frag.Item2,
                        indiceDefinicion));
            }
        }

        return resultado;
    }

    private int CrearLoteGrupoEstacionesMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaGrupoLongitudinal2D grupoBase,
        List<AceroVigaBarraLongitudinal2D> definicionesOrdenadas,
        LoteIntervaloEstacionMYG lote,
        double recubrimiento,
        double diametroEstribo,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra,
        double limiteInicioGlobal,
        double limiteFinGlobal)
    {
        if (doc == null || datos == null || grupoBase == null ||
            lote == null || lote.Indices == null || lote.Indices.Count == 0)
        {
            return 0;
        }

        List<int> indices = lote.Indices
            .Distinct()
            .Where(i => i >= 0 && i < definicionesOrdenadas.Count)
            .OrderBy(i => i)
            .ToList();

        if (indices.Count == 0)
            return 0;

        double inicioAnterior = datos.InicioUtilArmaduraSerie;
        double finAnterior = datos.FinUtilArmaduraSerie;

        bool tocaInicioGlobal = lote.Inicio <= limiteInicioGlobal + Tol;
        bool tocaFinGlobal = lote.Fin >= limiteFinGlobal - Tol;

        datos.InicioUtilArmaduraSerie = lote.Inicio;
        datos.FinUtilArmaduraSerie = lote.Fin;

        try
        {
            int totalCreado = 0;

            // V11.23:
            // Una selección por clic puede ser NO uniforme, por ejemplo
            // [0,1,4,5]. Forzar esas cuatro posiciones dentro de un único
            // Número fijo movería las barras interiores. Se separan en
            // subconjuntos equiespaciados para conservar EXACTAMENTE las
            // posiciones seleccionadas; cada subconjunto de 2+ barras sigue
            // siendo un set nativo Número fijo.
            List<List<int>> subconjuntos =
                ParticionarIndicesEquiespaciadosEstacionesMYG(indices);

            foreach (List<int> subconjunto in subconjuntos)
            {
                if (subconjunto == null || subconjunto.Count == 0)
                    continue;

                List<AceroVigaBarraLongitudinal2D> defsSub =
                    subconjunto
                        .Where(i =>
                            i >= 0 &&
                            i < definicionesOrdenadas.Count)
                        .Select(i => definicionesOrdenadas[i])
                        .Where(x => x != null)
                        .ToList();

                if (defsSub.Count == 0)
                    continue;

                int creadasSub = 0;

                if (defsSub.Count >= 2)
                {
                    AceroVigaGrupoLongitudinal2D grupo =
                        grupoBase.Copiar();
                    grupo.Id = Guid.NewGuid().ToString("N");

                    // V11.34 - jerarquía:
                    // 1) Si el subconjunto conserva TODAS las barras originales
                    //    del grupo, conserva también la REGLA maestra.
                    // 2) Si el usuario apagó barras y quedó un subconjunto
                    //    equiespaciado de 2+, se usa Número fijo para respetar
                    //    exactamente esas posiciones sin crear individuales.
                    bool conservaGrupoCompleto =
                        SubconjuntoEsGrupoCompletoEstacionesMYG(
                            subconjunto,
                            definicionesOrdenadas.Count);

                    if (conservaGrupoCompleto)
                    {
                        grupo.Regla = grupoBase.Regla;

                        grupo.Cantidad =
                            grupoBase.Regla ==
                                AceroVigaReglaGrupoLongitudinal.NumeroFijo
                                ? Math.Max(1, grupoBase.Cantidad)
                                : defsSub.Count;

                        grupo.EspaciadoCm = grupoBase.EspaciadoCm;
                    }
                    else
                    {
                        grupo.Regla =
                            AceroVigaReglaGrupoLongitudinal.NumeroFijo;
                        grupo.Cantidad = defsSub.Count;
                    }

                    // Las definiciones suministradas ya son exactamente las que
                    // deben existir en este lote. No volver a omitir extremos.
                    grupo.OmitirPrimeraBarra = false;
                    grupo.OmitirUltimaBarra = false;

                    creadasSub =
                        CrearGrupoLongitudinalParametricoManualMYG(
                            doc,
                            datos,
                            diseno,
                            grupo,
                            defsSub,
                            recubrimiento,
                            diametroEstribo,
                            ganchoInicio && tocaInicioGlobal,
                            longitudGanchoInicio,
                            ganchoFin && tocaFinGlobal,
                            longitudGanchoFin,
                            desarrolloInicioHabilitado &&
                                tocaInicioGlobal,
                            longitudDesarrolloInicio,
                            desarrolloFinHabilitado &&
                                tocaFinGlobal,
                            longitudDesarrolloFin,
                            crearEmpalmes,
                            longitudEmpalmeSuperior,
                            longitudEmpalmeInferior,
                            longitudEmpalmeCentral,
                            longitudBarra,
                            lote.SegmentosEmpalmeAcumulados,
                            ObtenerTextoTipoEspecialLoteMYG(
                                lote,
                                defsSub.FirstOrDefault()));

                    // V11.37 - NO DEGRADAR TODO EL SUBCONJUNTO A INDIVIDUALES.
                    // CrearGrupoLongitudinalParametricoManualMYG ya resuelve cada
                    // pieza comercial con esta jerarquía:
                    //   1) Set Shape-Driven (Número fijo / Espaciado máximo).
                    //   2) FreeForm SET conservando la misma regla.
                    //   3) Solo si ESA pieza concreta no admite set, individuales
                    //      únicamente para esa pieza, conservando el empalme.
                    //
                    // Antes, si una pieza posterior fallaba, este bloque volvía a
                    // crear TODO el recorrido de defsSub como Individual. Las piezas
                    // Número fijo que ya se habían creado quedaban debajo y aparecía
                    // exactamente el solape Set + Individual reportado en Revit.
                    // Si el método devuelve 0, se deja que la SubTransaction del lote
                    // haga ROLLBACK completo; nunca se superpone un segundo juego.
                    if (creadasSub <= 0)
                        return 0;
                }
                else
                {
                    creadasSub =
                        CrearBarraLongitudinalManualIndividualMYG(
                            doc,
                            datos,
                            diseno,
                            defsSub[0],
                            recubrimiento,
                            diametroEstribo,
                            ganchoInicio && tocaInicioGlobal,
                            longitudGanchoInicio,
                            ganchoFin && tocaFinGlobal,
                            longitudGanchoFin,
                            desarrolloInicioHabilitado &&
                                tocaInicioGlobal,
                            longitudDesarrolloInicio,
                            desarrolloFinHabilitado &&
                                tocaFinGlobal,
                            longitudDesarrolloFin,
                            crearEmpalmes,
                            longitudEmpalmeSuperior,
                            longitudEmpalmeInferior,
                            longitudEmpalmeCentral,
                            longitudBarra,
                            lote.SegmentosEmpalmeAcumulados,
                            ObtenerTextoTipoEspecialLoteMYG(
                                lote,
                                defsSub[0]));
                }

                if (creadasSub <= 0)
                    return 0;

                totalCreado += creadasSub;
            }

            return totalCreado;
        }
        finally
        {
            datos.InicioUtilArmaduraSerie = inicioAnterior;
            datos.FinUtilArmaduraSerie = finAnterior;
        }
    }

    private int CrearBarraIndividualIntervaloEstacionesMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaBarraLongitudinal2D definicion,
        double inicio,
        double fin,
        double recubrimiento,
        double diametroEstribo,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra,
        double limiteInicioGlobal,
        double limiteFinGlobal,
        List<SegmentoAceroLongitudinal> segmentosAcumuladosEstacionesMYG = null,
        string textoTipoForzadoMYG = null)
    {
        if (doc == null ||
            datos == null ||
            definicion == null ||
            fin <= inicio + Tol)
        {
            return 0;
        }

        double inicioAnterior = datos.InicioUtilArmaduraSerie;
        double finAnterior = datos.FinUtilArmaduraSerie;

        bool tocaInicioGlobal =
            inicio <= limiteInicioGlobal + Tol;
        bool tocaFinGlobal =
            fin >= limiteFinGlobal - Tol;

        datos.InicioUtilArmaduraSerie = inicio;
        datos.FinUtilArmaduraSerie = fin;

        try
        {
            return CrearBarraLongitudinalManualIndividualMYG(
                doc,
                datos,
                diseno,
                definicion,
                recubrimiento,
                diametroEstribo,
                ganchoInicio && tocaInicioGlobal,
                longitudGanchoInicio,
                ganchoFin && tocaFinGlobal,
                longitudGanchoFin,
                desarrolloInicioHabilitado && tocaInicioGlobal,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado && tocaFinGlobal,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudEmpalmeInferior,
                longitudEmpalmeCentral,
                longitudBarra,
                segmentosAcumuladosEstacionesMYG,
                textoTipoForzadoMYG);
        }
        finally
        {
            datos.InicioUtilArmaduraSerie = inicioAnterior;
            datos.FinUtilArmaduraSerie = finAnterior;
        }
    }

    private int CrearAceroLongitudinalManualPorEstacionesMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        double recubrimiento,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra,
        AceroLongitudinalVigasForm.ModoDistribucionLongitudinalMYG modo)
    {
        if (doc == null || datos == null || datos.Host == null ||
            diseno == null || diseno.Longitudinales == null)
        {
            return 0;
        }

        if (datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
        {
            return CrearAceroLongitudinalManualEnSerieMYG(
                doc,
                datos,
                diseno,
                recubrimiento,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                desarrolloInicioHabilitado,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudEmpalmeInferior,
                longitudEmpalmeCentral,
                longitudBarra);
        }

        List<AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG> filas =
            Form != null
                ? Form.ObtenerConfiguracionEstacionesLongitudinalMYG()
                : new List<AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG>();

        double extension = UnitUtils.ConvertToInternalUnits(
            Form != null ? Form.ExtensionCambiosEstacionesCmMYG : 60.0,
            UnitTypeId.Centimeters);

        double limiteInicioGlobal = Math.Max(
            0.0,
            datos.InicioUtilArmaduraSerie);
        double limiteFinGlobal =
            datos.FinUtilArmaduraSerie > limiteInicioGlobal + Tol
                ? Math.Min(datos.LongitudTotal, datos.FinUtilArmaduraSerie)
                : datos.LongitudTotal;

        // V11.41 - para BASTONES, el extremo global que activa Desarrollo/AUTO/
        // GANCHO es la CARA de la primera/última viga, no el comienzo de la
        // columna ni el límite general de la serie. Desde esa cara, el motor
        // agrega el desarrollo general hacia el apoyo exterior.
        List<TramoRecorridoSerie> tramosEspecialesOrdenados =
            datos.TramosRecorrido
                .Where(t => t != null && t.Longitud > Tol)
                .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
                .ToList();

        double limiteInicioEspecial =
            tramosEspecialesOrdenados.Count > 0
                ? Math.Min(
                    tramosEspecialesOrdenados.First().XInicioSerie,
                    tramosEspecialesOrdenados.First().XFinSerie)
                : limiteInicioGlobal;

        double limiteFinEspecial =
            tramosEspecialesOrdenados.Count > 0
                ? Math.Max(
                    tramosEspecialesOrdenados.Last().XInicioSerie,
                    tramosEspecialesOrdenados.Last().XFinSerie)
                : limiteFinGlobal;

        int contador = 0;
        double diametroEstribo =
            ObtenerDiametroEstriboReferenciaDisenoManualMYG(diseno);

        HashSet<string> gruposProcesados =
            new HashSet<string>(StringComparer.Ordinal);

        if (diseno.GruposLongitudinales != null)
        {
            foreach (AceroVigaGrupoLongitudinal2D grupo in
                diseno.GruposLongitudinales.Where(x => x != null))
            {
                if (string.IsNullOrWhiteSpace(grupo.Id))
                    continue;

                List<AceroVigaBarraLongitudinal2D> definiciones =
                    diseno.Longitudinales
                        .Where(x =>
                            x != null &&
                            x.Punto != null &&
                            x.TipoBarra != null &&
                            !x.OcultaPorSuperposicion &&
                            string.Equals(
                                x.GrupoDistribucionId,
                                grupo.Id,
                                StringComparison.Ordinal))
                        .ToList();

                definiciones = OrdenarDefinicionesGrupoEstacionesMYG(
                    grupo,
                    definiciones);

                if (definiciones.Count == 0)
                    continue;

                int cantidadMaxima = definiciones.Count;
                List<RegionCantidadEstacionMYG> regiones =
                    ConstruirRegionesCantidadGrupoEstacionesMYG(
                        datos,
                        filas,
                        grupo.Id,
                        cantidadMaxima,
                        modo);

                if (regiones.Count == 0)
                    continue;

                // V11.39 - la clasificación BASTÓN/BALANCÍN es POR TRAMO.
                // Los lotes especiales se construyen solo donde el usuario los
                // marcó. El recorrido normal se recorta posteriormente únicamente
                // en la longitud ocupada por esos lotes, no en toda la serie.
                List<LoteIntervaloEstacionMYG> lotesEspeciales =
                    ConstruirLotesEspecialesBastonBalancinMYG(
                        datos,
                        filas,
                        grupo.Id,
                        definiciones,
                        modo);

                HashSet<int> indicesEspeciales =
                    new HashSet<int>(
                        lotesEspeciales
                            .Where(l => l != null && l.Indices != null)
                            .SelectMany(l => l.Indices)
                            .Where(i => i >= 0 && i < cantidadMaxima));

                // =====================================================
                // V11.34 - PRIORIDAD ABSOLUTA AL EDITOR MAESTRO
                // =====================================================
                // Si INTERMEDIO/AVANZADO no modificó ninguna posición de este
                // grupo, se crea el grupo maestro DIRECTAMENTE, exactamente
                // como fue definido en el editor de sección:
                //   - Número fijo sigue siendo Número fijo.
                //   - Espaciado máximo sigue siendo Espaciado máximo.
                //   - se conserva Cantidad / Espaciado / guía / tipo de barra.
                // Esto evita fragmentar innecesariamente un set continuo en
                // varios Rebar Individual y reduce drásticamente el peso del modelo.
                if (indicesEspeciales.Count == 0 &&
                    GrupoSinModificacionEstacionesMYG(
                        regiones,
                        cantidadMaxima))
                {
                    int creadasMaestro = 0;
                    ultimoErrorLongitudinalMYG = string.Empty;

                    using (SubTransaction subMaestro =
                        new SubTransaction(doc))
                    {
                        subMaestro.Start();

                        try
                        {
                            creadasMaestro =
                                CrearGrupoLongitudinalParametricoManualMYG(
                                    doc,
                                    datos,
                                    diseno,
                                    grupo,
                                    definiciones,
                                    recubrimiento,
                                    diametroEstribo,
                                    ganchoInicio,
                                    longitudGanchoInicio,
                                    ganchoFin,
                                    longitudGanchoFin,
                                    desarrolloInicioHabilitado,
                                    longitudDesarrolloInicio,
                                    desarrolloFinHabilitado,
                                    longitudDesarrolloFin,
                                    crearEmpalmes,
                                    longitudEmpalmeSuperior,
                                    longitudEmpalmeInferior,
                                    longitudEmpalmeCentral,
                                    longitudBarra);
                        }
                        catch (Exception ex)
                        {
                            MarcarUltimoErrorLongitudinalMYG(
                                "Modo por estaciones - grupo maestro sin cambios",
                                "Falló el intento de conservar intacto el grupo " +
                                grupo.Id + "; regla=" + grupo.Regla +
                                "; cantidad=" + grupo.Cantidad + ".",
                                ex);
                            creadasMaestro = 0;
                        }

                        if (creadasMaestro > 0)
                            subMaestro.Commit();
                        else
                            subMaestro.RollBack();
                    }

                    if (creadasMaestro > 0)
                    {
                        contador += creadasMaestro;
                        gruposProcesados.Add(grupo.Id);
                        continue;
                    }

                    // Si Revit no pudo aceptar el grupo maestro completo,
                    // se continúa con el motor por lotes; este todavía intentará
                    // sets nativos y FreeForm SET antes de usar individuales.
                }

                List<int> prioridad =
                    ConstruirOrdenPrioridadSimetricaEstacionesMYG(
                        cantidadMaxima);

                Dictionary<string, LoteIntervaloEstacionMYG> lotes =
                    new Dictionary<string, LoteIntervaloEstacionMYG>();

                for (int rango = 0; rango < prioridad.Count; rango++)
                {
                    int indiceDefinicion = prioridad[rango];

                    double desarrolloCorte = extension;
                    if (Form != null &&
                        indiceDefinicion >= 0 &&
                        indiceDefinicion < definiciones.Count)
                    {
                        double desarrolloCm =
                            Form.ObtenerDesarrolloCortePorDiametroCmMYG(
                                definiciones[indiceDefinicion].TipoBarra);
                        desarrolloCorte = UnitUtils.ConvertToInternalUnits(
                            Math.Max(0.0, desarrolloCm),
                            UnitTypeId.Centimeters);
                    }

                    List<IntervaloActivoBarraEstacionMYG> activos =
                        ConstruirIntervalosActivosBarraEstacionesMYG(
                            regiones,
                            rango,
                            indiceDefinicion,
                            extension,
                            desarrolloCorte,
                            limiteInicioGlobal,
                            limiteFinGlobal);

                    // V11.41 - si esta posición fue declarada BASTÓN en
                    // un tramo, se elimina la barra normal de TODO ese tramo.
                    // Luego se reponen solo sus tercios extremos como bastones.
                    activos = RestarTramosBastonDeIntervalosNormalesMYG(
                        activos,
                        datos,
                        filas,
                        grupo.Id,
                        indiceDefinicion,
                        cantidadMaxima,
                        modo);

                    activos = RestarLotesEspecialesDeIntervalosNormalesMYG(
                        activos,
                        lotesEspeciales,
                        indiceDefinicion);

                    foreach (IntervaloActivoBarraEstacionMYG activo in activos)
                    {
                        if (activo == null || activo.Fin <= activo.Inicio + Tol)
                            continue;

                        string clave = ClaveIntervaloEstacionMYG(
                            activo.Inicio,
                            activo.Fin);

                        LoteIntervaloEstacionMYG lote;
                        if (!lotes.TryGetValue(clave, out lote))
                        {
                            lote = new LoteIntervaloEstacionMYG
                            {
                                Inicio = activo.Inicio,
                                Fin = activo.Fin
                            };
                            lotes.Add(clave, lote);
                        }

                        if (!lote.Indices.Contains(activo.IndiceDefinicion))
                            lote.Indices.Add(activo.IndiceDefinicion);
                    }
                }

                // V11.44 - antes de materializar cada tramo/host, se calcula
                // UNA SOLA secuencia comercial acumulada para las barras que
                // continúan de un tramo al siguiente. Así el corte de 9 m no
                // se reinicia en T2, T3, etc., aunque Revit termine teniendo
                // varios elementos Rebar físicos.
                PrepararEmpalmesAcumuladosLotesEstacionesMYG(
                    datos,
                    lotes.Values,
                    definiciones,
                    crearEmpalmes,
                    longitudEmpalmeSuperior,
                    longitudEmpalmeInferior,
                    longitudEmpalmeCentral,
                    longitudBarra,
                    desarrolloInicioHabilitado,
                    longitudDesarrolloInicio,
                    desarrolloFinHabilitado,
                    longitudDesarrolloFin,
                    limiteInicioGlobal,
                    limiteFinGlobal);

                foreach (LoteIntervaloEstacionMYG lote in lotes.Values
                    .OrderBy(x => x.Inicio)
                    .ThenByDescending(x => x.Indices.Count))
                {
                    int creadasLote = 0;
                    ultimoErrorLongitudinalMYG = string.Empty;

                    using (SubTransaction sub = new SubTransaction(doc))
                    {
                        sub.Start();

                        try
                        {
                            creadasLote = CrearLoteGrupoEstacionesMYG(
                                doc,
                                datos,
                                diseno,
                                grupo,
                                definiciones,
                                lote,
                                recubrimiento,
                                diametroEstribo,
                                ganchoInicio,
                                longitudGanchoInicio,
                                ganchoFin,
                                longitudGanchoFin,
                                desarrolloInicioHabilitado,
                                longitudDesarrolloInicio,
                                desarrolloFinHabilitado,
                                longitudDesarrolloFin,
                                crearEmpalmes,
                                longitudEmpalmeSuperior,
                                longitudEmpalmeInferior,
                                longitudEmpalmeCentral,
                                longitudBarra,
                                limiteInicioGlobal,
                                limiteFinGlobal);
                        }
                        catch (Exception ex)
                        {
                            MarcarUltimoErrorLongitudinalMYG(
                                "Modo por estaciones",
                                "Falló el lote del grupo " + grupo.Id +
                                " en X=" + FormatearLongitudDiagnosticoMYG(lote.Inicio) +
                                " -> " + FormatearLongitudDiagnosticoMYG(lote.Fin) +
                                "; barras=" + lote.Indices.Count + ".",
                                ex);
                            creadasLote = 0;
                        }

                        if (creadasLote > 0)
                            sub.Commit();
                        else
                            sub.RollBack();
                    }

                    if (creadasLote > 0)
                    {
                        contador += creadasLote;
                    }
                    else
                    {
                        List<AceroVigaBarraLongitudinal2D> defsFallo =
                            lote.Indices
                                .Where(i => i >= 0 && i < definiciones.Count)
                                .Select(i => definiciones[i])
                                .ToList();

                        RegistrarFalloGrupoLongitudinalMYG(
                            grupo,
                            defsFallo,
                            datos,
                            crearEmpalmes,
                            longitudEmpalmeSuperior,
                            longitudEmpalmeInferior,
                            longitudEmpalmeCentral,
                            longitudBarra);
                    }
                }

                // =====================================================
                // V11.38 - CREACIÓN DE BASTONES / BALANCINES
                // =====================================================
                // Se crean DESPUÉS del acero normal porque sus posiciones fueron
                // retiradas de las regiones normales. Cada lote sigue usando el
                // mismo motor de sets. V11.48: para BASTÓN/BALANCÍN se exige
                // conjunto; NO se permite degradación a Individual.
                foreach (LoteIntervaloEstacionMYG loteEspecial in
                    lotesEspeciales)
                {
                    if (loteEspecial == null ||
                        loteEspecial.Indices == null ||
                        loteEspecial.Indices.Count == 0 ||
                        loteEspecial.Fin <= loteEspecial.Inicio + Tol)
                    {
                        continue;
                    }

                    int creadasEspecial = 0;
                    ultimoErrorLongitudinalMYG = string.Empty;

                    using (SubTransaction subEspecial =
                        new SubTransaction(doc))
                    {
                        subEspecial.Start();

                        try
                        {
                            creadasEspecial =
                                CrearLoteGrupoEstacionesMYG(
                                    doc,
                                    datos,
                                    diseno,
                                    grupo,
                                    definiciones,
                                    loteEspecial,
                                    recubrimiento,
                                    diametroEstribo,

                                    // V11.41 - los bastones de los extremos
                                    // físicos obedecen EXACTAMENTE los inputs
                                    // generales Desarrollo/AUTO/GANCHO. Los lotes
                                    // interiores no tocan los límites especiales y
                                    // por tanto no reciben desarrollo ni gancho.
                                    ganchoInicio,
                                    longitudGanchoInicio,
                                    ganchoFin,
                                    longitudGanchoFin,
                                    desarrolloInicioHabilitado,
                                    longitudDesarrolloInicio,
                                    desarrolloFinHabilitado,
                                    longitudDesarrolloFin,

                                    // Bastones/balancines son piezas locales:
                                    // no se les introduce empalme comercial.
                                    false,
                                    longitudEmpalmeSuperior,
                                    longitudEmpalmeInferior,
                                    longitudEmpalmeCentral,
                                    longitudBarra,

                                    // Cara de primera/última viga: activa el
                                    // desarrollo/gancho solo en el extremo exterior.
                                    limiteInicioEspecial,
                                    limiteFinEspecial);
                        }
                        catch (Exception ex)
                        {
                            MarcarUltimoErrorLongitudinalMYG(
                                "Bastón / Balancín",
                                "Falló el refuerzo especial del grupo " +
                                grupo.Id +
                                " en X=" +
                                FormatearLongitudDiagnosticoMYG(
                                    loteEspecial.Inicio) +
                                " -> " +
                                FormatearLongitudDiagnosticoMYG(
                                    loteEspecial.Fin) +
                                "; barras=" +
                                loteEspecial.Indices.Count + ".",
                                ex);
                            creadasEspecial = 0;
                        }

                        if (creadasEspecial > 0)
                            subEspecial.Commit();
                        else
                            subEspecial.RollBack();
                    }

                    if (creadasEspecial > 0)
                    {
                        contador += creadasEspecial;
                    }
                    else
                    {
                        List<AceroVigaBarraLongitudinal2D> defsFalloEspecial =
                            loteEspecial.Indices
                                .Where(i => i >= 0 && i < definiciones.Count)
                                .Select(i => definiciones[i])
                                .Where(d => d != null)
                                .ToList();

                        RegistrarFalloGrupoLongitudinalMYG(
                            grupo,
                            defsFalloEspecial,
                            datos,
                            false,
                            longitudEmpalmeSuperior,
                            longitudEmpalmeInferior,
                            longitudEmpalmeCentral,
                            longitudBarra);
                    }
                }

                gruposProcesados.Add(grupo.Id);
            }
        }

        // V11.23:
        // Las barras dibujadas con AGREGAR BARRA también pueden activarse o
        // desactivarse por tramo/zona. Así la sección principal funciona como
        // el catálogo completo de acero posible y el configurador alterno solo
        // decide qué posiciones existen realmente en cada tramo.
        foreach (AceroVigaBarraLongitudinal2D definicion in diseno.Longitudinales)
        {
            if (definicion == null || definicion.TipoBarra == null ||
                definicion.Punto == null || definicion.OcultaPorSuperposicion)
            {
                continue;
            }

            if (!string.IsNullOrWhiteSpace(definicion.GrupoDistribucionId) &&
                gruposProcesados.Contains(definicion.GrupoDistribucionId))
            {
                continue;
            }

            bool esIndividual =
                string.IsNullOrWhiteSpace(
                    definicion.GrupoDistribucionId);

            if (esIndividual)
            {
                AceroLongitudinalVigasForm.FilaConfiguracionEstacionMYG
                    filaIndividual =
                        filas.FirstOrDefault(x =>
                            x != null &&
                            !string.IsNullOrWhiteSpace(
                                x.BarraIndividualId) &&
                            string.Equals(
                                x.BarraIndividualId,
                                definicion.Id,
                                StringComparison.Ordinal));

                if (filaIndividual != null &&
                    !string.IsNullOrWhiteSpace(
                        filaIndividual.GrupoId))
                {
                    // V11.39 - una barra individual también puede ser especial
                    // POR TRAMO. Se crean primero sus lotes especiales, pero NO
                    // se abandona el recorrido normal de los demás tramos.
                    List<LoteIntervaloEstacionMYG> lotesEspecialesIndividual =
                        ConstruirLotesEspecialesBastonBalancinMYG(
                            datos,
                            filas,
                            filaIndividual.GrupoId,
                            new List<AceroVigaBarraLongitudinal2D>
                            {
                                definicion
                            },
                            modo);

                    foreach (LoteIntervaloEstacionMYG loteEspecial in
                        lotesEspecialesIndividual)
                    {
                        if (loteEspecial == null ||
                            loteEspecial.Fin <= loteEspecial.Inicio + Tol)
                        {
                            continue;
                        }

                        int creadasEspecialIndividual = 0;

                        using (SubTransaction subEspecialIndividual =
                            new SubTransaction(doc))
                        {
                            subEspecialIndividual.Start();

                            try
                            {
                                creadasEspecialIndividual =
                                    CrearBarraIndividualIntervaloEstacionesMYG(
                                        doc,
                                        datos,
                                        diseno,
                                        definicion,
                                        loteEspecial.Inicio,
                                        loteEspecial.Fin,
                                        recubrimiento,
                                        diametroEstribo,
                                        ganchoInicio,
                                        longitudGanchoInicio,
                                        ganchoFin,
                                        longitudGanchoFin,
                                        desarrolloInicioHabilitado,
                                        longitudDesarrolloInicio,
                                        desarrolloFinHabilitado,
                                        longitudDesarrolloFin,
                                        false,
                                        longitudEmpalmeSuperior,
                                        longitudEmpalmeInferior,
                                        longitudEmpalmeCentral,
                                        longitudBarra,
                                        limiteInicioEspecial,
                                        limiteFinEspecial,
                                        null,
                                        ObtenerTextoTipoEspecialLoteMYG(
                                            loteEspecial,
                                            definicion));
                            }
                            catch (Exception ex)
                            {
                                MarcarUltimoErrorLongitudinalMYG(
                                    "Bastón / Balancín - barra individual",
                                    "Falló la barra especial " +
                                    (definicion.Id ?? string.Empty) +
                                    " en X=" +
                                    FormatearLongitudDiagnosticoMYG(
                                        loteEspecial.Inicio) +
                                    " -> " +
                                    FormatearLongitudDiagnosticoMYG(
                                        loteEspecial.Fin) +
                                    ".",
                                    ex);
                                creadasEspecialIndividual = 0;
                            }

                            if (creadasEspecialIndividual > 0)
                                subEspecialIndividual.Commit();
                            else
                                subEspecialIndividual.RollBack();
                        }

                        contador += Math.Max(
                            0,
                            creadasEspecialIndividual);
                    }

                    List<RegionCantidadEstacionMYG> regionesIndividual =
                        ConstruirRegionesCantidadGrupoEstacionesMYG(
                            datos,
                            filas,
                            filaIndividual.GrupoId,
                            1,
                            modo);

                    double desarrolloIndividual = extension;
                    if (Form != null)
                    {
                        double desarrolloCm =
                            Form.ObtenerDesarrolloCortePorDiametroCmMYG(
                                definicion.TipoBarra);
                        desarrolloIndividual = UnitUtils.ConvertToInternalUnits(
                            Math.Max(0.0, desarrolloCm),
                            UnitTypeId.Centimeters);
                    }

                    List<IntervaloActivoBarraEstacionMYG>
                        intervalosIndividual =
                            ConstruirIntervalosActivosBarraEstacionesMYG(
                                regionesIndividual,
                                0,
                                0,
                                extension,
                                desarrolloIndividual,
                                limiteInicioGlobal,
                                limiteFinGlobal);

                    intervalosIndividual =
                        RestarTramosBastonDeIntervalosNormalesMYG(
                            intervalosIndividual,
                            datos,
                            filas,
                            filaIndividual.GrupoId,
                            0,
                            1,
                            modo);

                    intervalosIndividual =
                        RestarLotesEspecialesDeIntervalosNormalesMYG(
                            intervalosIndividual,
                            lotesEspecialesIndividual,
                            0);

                    // V11.44 - también las barras individuales mantienen
                    // el contador comercial acumulado entre tramos continuos.
                    List<LoteIntervaloEstacionMYG> lotesPlanIndividual =
                        intervalosIndividual
                            .Where(iv =>
                                iv != null &&
                                iv.Fin > iv.Inicio + Tol)
                            .Select(iv =>
                                new LoteIntervaloEstacionMYG
                                {
                                    Inicio = iv.Inicio,
                                    Fin = iv.Fin,
                                    Indices = new List<int> { 0 }
                                })
                            .ToList();

                    PrepararEmpalmesAcumuladosLotesEstacionesMYG(
                        datos,
                        lotesPlanIndividual,
                        new List<AceroVigaBarraLongitudinal2D>
                        {
                            definicion
                        },
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra,
                        desarrolloInicioHabilitado,
                        longitudDesarrolloInicio,
                        desarrolloFinHabilitado,
                        longitudDesarrolloFin,
                        limiteInicioGlobal,
                        limiteFinGlobal);

                    foreach (IntervaloActivoBarraEstacionMYG intervalo in
                        intervalosIndividual)
                    {
                        if (intervalo == null ||
                            intervalo.Fin <= intervalo.Inicio + Tol)
                        {
                            continue;
                        }

                        LoteIntervaloEstacionMYG lotePlanIndividual =
                            lotesPlanIndividual.FirstOrDefault(lp =>
                                lp != null &&
                                Math.Abs(lp.Inicio - intervalo.Inicio) <= Tol &&
                                Math.Abs(lp.Fin - intervalo.Fin) <= Tol);

                        int creadasIndividual = 0;
                        ultimoErrorLongitudinalMYG = string.Empty;

                        using (SubTransaction sub =
                            new SubTransaction(doc))
                        {
                            sub.Start();

                            try
                            {
                                creadasIndividual =
                                    CrearBarraIndividualIntervaloEstacionesMYG(
                                        doc,
                                        datos,
                                        diseno,
                                        definicion,
                                        intervalo.Inicio,
                                        intervalo.Fin,
                                        recubrimiento,
                                        diametroEstribo,
                                        ganchoInicio,
                                        longitudGanchoInicio,
                                        ganchoFin,
                                        longitudGanchoFin,
                                        desarrolloInicioHabilitado,
                                        longitudDesarrolloInicio,
                                        desarrolloFinHabilitado,
                                        longitudDesarrolloFin,
                                        crearEmpalmes,
                                        longitudEmpalmeSuperior,
                                        longitudEmpalmeInferior,
                                        longitudEmpalmeCentral,
                                        longitudBarra,
                                        limiteInicioGlobal,
                                        limiteFinGlobal,
                                        lotePlanIndividual != null
                                            ? lotePlanIndividual.SegmentosEmpalmeAcumulados
                                            : null,
                                        null);
                            }
                            catch (Exception ex)
                            {
                                MarcarUltimoErrorLongitudinalMYG(
                                    "Modo por estaciones - barra individual",
                                    "Falló la barra " +
                                    (definicion.Id ?? string.Empty) +
                                    " en X=" +
                                    FormatearLongitudDiagnosticoMYG(
                                        intervalo.Inicio) +
                                    " -> " +
                                    FormatearLongitudDiagnosticoMYG(
                                        intervalo.Fin) +
                                    ".",
                                    ex);
                                creadasIndividual = 0;
                            }

                            if (creadasIndividual > 0)
                                sub.Commit();
                            else
                                sub.RollBack();
                        }

                        contador += Math.Max(
                            0,
                            creadasIndividual);
                    }

                    continue;
                }
            }

            // Respaldo compatible para data antigua o grupos huérfanos que no
            // tengan una fila de configuración por estaciones.
            contador += CrearBarraLongitudinalManualIndividualMYG(
                doc,
                datos,
                diseno,
                definicion,
                recubrimiento,
                diametroEstribo,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                desarrolloInicioHabilitado,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudEmpalmeInferior,
                longitudEmpalmeCentral,
                longitudBarra);
        }

        return contador;
    }

    private int CrearAceroLongitudinalManualEnSerieMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        double recubrimiento,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        if (doc == null || datos == null || datos.Host == null ||
            diseno == null || diseno.Longitudinales == null)
        {
            return 0;
        }

        int contador = 0;
        double diametroEstribo =
            ObtenerDiametroEstriboReferenciaDisenoManualMYG(diseno);

        HashSet<string> gruposMaterializados =
            new HashSet<string>(StringComparer.Ordinal);

        // V11.7:
        // Un grupo con empalmes jamás debe degradarse a N barras individuales
        // si falla su set. De lo contrario el quiebre puede parecer un elemento
        // separado y el metrado deja de representar el conjunto original.
        HashSet<string> gruposEmpalmadosNoFragmentar =
            new HashSet<string>(StringComparer.Ordinal);

        // ---------------------------------------------------------
        // 1. GRUPOS PARAMÉTRICOS REALES DE REVIT
        // ---------------------------------------------------------
        // Cuando las posiciones del grupo pertenecen a una misma recta en la
        // sección, se crea una sola armadura shape-driven y se conserva la regla
        // real de Revit: NÚMERO FIJO o ESPACIADO MÁXIMO.
        // Si la guía es quebrada o Revit no admite la forma como conjunto, la
        // subtransacción se revierte y las barras se crean individualmente más
        // abajo, sin dejar elementos duplicados.
        if (diseno.GruposLongitudinales != null)
        {
            foreach (AceroVigaGrupoLongitudinal2D grupo in
                diseno.GruposLongitudinales)
            {
                if (grupo == null ||
                    string.IsNullOrWhiteSpace(grupo.Id))
                {
                    continue;
                }

                List<AceroVigaBarraLongitudinal2D> definicionesGrupo =
                    diseno.Longitudinales
                        .Where(x =>
                            x != null &&
                            x.Punto != null &&
                            x.TipoBarra != null &&
                            string.Equals(
                                x.GrupoDistribucionId,
                                grupo.Id,
                                StringComparison.Ordinal))
                        .ToList();

                if (definicionesGrupo.Count < 2)
                    continue;

                bool grupoCreado = false;
                int barrasGrupo = 0;

                // El error de intentos anteriores no debe contaminar este grupo.
                ultimoErrorLongitudinalMYG = string.Empty;

                using (SubTransaction subGrupo = new SubTransaction(doc))
                {
                    subGrupo.Start();

                    try
                    {
                        barrasGrupo =
                            CrearGrupoLongitudinalParametricoManualMYG(
                                doc,
                                datos,
                                diseno,
                                grupo,
                                definicionesGrupo,
                                recubrimiento,
                                diametroEstribo,
                                ganchoInicio,
                                longitudGanchoInicio,
                                ganchoFin,
                                longitudGanchoFin,
                                desarrolloInicioHabilitado,
                                longitudDesarrolloInicio,
                                desarrolloFinHabilitado,
                                longitudDesarrolloFin,
                                crearEmpalmes,
                                longitudEmpalmeSuperior,
                                longitudEmpalmeInferior,
                                longitudEmpalmeCentral,
                                longitudBarra);

                        grupoCreado = barrasGrupo > 0;
                    }
                    catch (Exception ex)
                    {
                        barrasGrupo = 0;
                        grupoCreado = false;
                        MarcarUltimoErrorLongitudinalMYG(
                            "Excepción general al materializar el grupo",
                            "La rutina del grupo lanzó una excepción antes de devolver un resultado.",
                            ex);
                    }

                    if (grupoCreado)
                        subGrupo.Commit();
                    else
                        subGrupo.RollBack();
                }

                if (grupoCreado)
                {
                    gruposMaterializados.Add(grupo.Id);
                    contador += barrasGrupo;
                }
                else
                {
                    RegistrarFalloGrupoLongitudinalMYG(
                        grupo,
                        definicionesGrupo,
                        datos,
                        crearEmpalmes,
                        longitudEmpalmeSuperior,
                        longitudEmpalmeInferior,
                        longitudEmpalmeCentral,
                        longitudBarra);

                    if (crearEmpalmes)
                    {
                        // Si no pudo resolverse como un único set por pieza,
                        // NO se permite caer al foreach de barras individuales.
                        gruposEmpalmadosNoFragmentar.Add(grupo.Id);
                    }
                }
            }
        }

        // ---------------------------------------------------------
        // 2. BARRAS INDIVIDUALES Y RESPALDO DE GUÍAS QUEBRADAS
        // ---------------------------------------------------------
        foreach (AceroVigaBarraLongitudinal2D definicion in
            diseno.Longitudinales)
        {
            if (definicion == null || definicion.TipoBarra == null ||
                definicion.Punto == null ||
                definicion.OcultaPorSuperposicion)
            {
                continue;
            }

            if (!string.IsNullOrWhiteSpace(
                    definicion.GrupoDistribucionId) &&
                (gruposMaterializados.Contains(
                    definicion.GrupoDistribucionId) ||
                 gruposEmpalmadosNoFragmentar.Contains(
                    definicion.GrupoDistribucionId)))
            {
                continue;
            }

            contador += CrearBarraLongitudinalManualIndividualMYG(
                doc,
                datos,
                diseno,
                definicion,
                recubrimiento,
                diametroEstribo,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                desarrolloInicioHabilitado,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudEmpalmeInferior,
                longitudEmpalmeCentral,
                longitudBarra);
        }

        return contador;
    }

    private int CrearGrupoLongitudinalParametricoManualMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaGrupoLongitudinal2D grupo,
        List<AceroVigaBarraLongitudinal2D> definiciones,
        double recubrimiento,
        double diametroEstribo,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra,
        List<SegmentoAceroLongitudinal> segmentosAcumuladosEstacionesMYG = null,
        string textoTipoForzadoMYG = null)
    {
        if (doc == null || datos == null || grupo == null ||
            definiciones == null || definiciones.Count < 2)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Validación inicial del grupo",
                "Faltan datos, grupo o hay menos de 2 definiciones de barra.");
            return 0;
        }

        RebarBarType tipo = grupo.TipoBarra ??
            definiciones[0].TipoBarra;
        if (tipo == null)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Tipo de barra del grupo",
                "No se pudo resolver RebarBarType para el conjunto.");
            return 0;
        }

        double diametro = ObtenerDiametroBarra(tipo);
        double offset = recubrimiento + diametroEstribo +
            diametro * 0.5;

        List<PosicionGrupoLongitudinalManualMYG> posiciones =
            new List<PosicionGrupoLongitudinalManualMYG>();

        foreach (AceroVigaBarraLongitudinal2D definicion in definiciones)
        {
            if (definicion == null || definicion.Punto == null)
                continue;

            double y = 0.0;
            double z = 0.0;

            // V11.1: para grupos creados mediante dos puntos, la coordenada
            // exacta mostrada en la ventana tiene prioridad absoluta. La guía
            // solo clasifica la capa y nunca vuelve a reposicionar el acero.
            bool posicionObtenida = false;
            if (definicion.UsarPosicionExactaSeccion &&
                definicion.PuntoSeccionReal != null)
            {
                posicionObtenida =
                    TryObtenerPosicionLongitudinalManualEnSeccionRealMYG(
                        datos,
                        definicion,
                        offset,
                        out y,
                        out z);
            }

            if (!posicionObtenida)
            {
                posicionObtenida =
                    TryObtenerPosicionLongitudinalDesdeGuiaRealMYG(
                        datos,
                        diseno,
                        definicion,
                        offset,
                        out y,
                        out z);
            }

            if (!posicionObtenida)
            {
                posicionObtenida =
                    TryObtenerPosicionLongitudinalManualEnSeccionRealMYG(
                        datos,
                        definicion,
                        offset,
                        out y,
                        out z);
            }

            if (!posicionObtenida)
                continue;

            if (!definicion.UsarPosicionExactaSeccion)
            {
                AjustarPrimeraCapaTangenteAEstriboMYG(
                    datos,
                    diseno,
                    definicion,
                    diametro,
                    diametroEstribo,
                    recubrimiento,
                    ref y,
                    ref z);
            }

            posiciones.Add(new PosicionGrupoLongitudinalManualMYG
            {
                Definicion = definicion,
                Y = y,
                Z = z
            });
        }

        if (posiciones.Count < 2)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Reconstrucción de posiciones Y-Z",
                "Solo se pudieron reconstruir " + posiciones.Count +
                " posiciones de " + definiciones.Count + " definiciones.");
            return 0;
        }

        // El parámetro sobre guía conserva el sentido definido por el usuario.
        // Para data antigua se mantiene el orden con el que están almacenadas las
        // barras en el diseño.
        if (posiciones.All(x =>
                x.Definicion != null &&
                x.Definicion.ParametroSobreGuia >= 0.0))
        {
            bool ascendente = grupo.ParametroFinGuia >=
                grupo.ParametroInicioGuia;
            posiciones = ascendente
                ? posiciones.OrderBy(x =>
                    x.Definicion.ParametroSobreGuia).ToList()
                : posiciones.OrderByDescending(x =>
                    x.Definicion.ParametroSobreGuia).ToList();
        }

        // Una sección transversal inclinada o trapezoidal NO impide usar una
        // regla shape-driven. Si los centros del grupo son colineales, una barra
        // base puede distribuirse exactamente en la dirección Y-Z definida por
        // el usuario. Por eso no se convierte automáticamente el grupo en barras
        // individuales: primero se intenta conservar NÚMERO FIJO o ESPACIADO
        // MÁXIMO como regla nativa de Revit.

        // V10.9: aun cuando la sección transversal sea inclinada, primero se
        // intenta un conjunto SHAPE-DRIVEN usando la normal Y-Z real.
        // Si la trayectoria longitudinal es recta y todas las posiciones
        // transversales son colineales, Revit puede conservar una regla nativa
        // editable (Número fijo o Espaciado máximo), incluso en una sección
        // trapezoidal o con cara superior inclinada.
        bool requiereTrayectoriaExacta =
            RequiereTrayectoriaExactaManualMYG(datos);

        PosicionGrupoLongitudinalManualMYG primera = posiciones[0];
        PosicionGrupoLongitudinalManualMYG ultima =
            posiciones[posiciones.Count - 1];

        double deltaY = ultima.Y - primera.Y;
        double deltaZ = ultima.Z - primera.Z;
        double longitudDistribucion = Math.Sqrt(
            deltaY * deltaY + deltaZ * deltaZ);

        if (longitudDistribucion <= Tol)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Longitud transversal del set",
                "El primer y último centro del grupo coinciden o la longitud es casi cero.");
            return 0;
        }

        // V10.9:
        // Las capas adaptativas superiores 2, 3 y 4 pueden acumular pequeñas
        // diferencias numéricas al reconstruirse desde una guía normalizada.
        // Si la guía declarada por el usuario es recta, la definición paramétrica
        // del grupo prevalece y se usa la cuerda entre el primer y último centro.
        // Esto evita que un error de pocos milímetros convierta el grupo completo
        // en barras individuales y desordene las posiciones en Revit.
        bool guiaDeclaradaRecta =
            EsGuiaGrupoLongitudinalRectaMYG(diseno, grupo);

        double toleranciaColineal = UnitUtils.ConvertToInternalUnits(
            guiaDeclaradaRecta ? 0.50 : 0.10,
            UnitTypeId.Centimeters);

        double desviacionMaxima = 0.0;
        foreach (PosicionGrupoLongitudinalManualMYG posicion in posiciones)
        {
            double distanciaLinea = Math.Abs(
                (posicion.Y - primera.Y) * deltaZ -
                (posicion.Z - primera.Z) * deltaY) /
                longitudDistribucion;

            desviacionMaxima = Math.Max(
                desviacionMaxima,
                distanciaLinea);
        }

        if (!guiaDeclaradaRecta &&
            desviacionMaxima > toleranciaColineal)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Colinealidad transversal del grupo",
                "Desviación máxima = " + FormatearLongitudDiagnosticoMYG(desviacionMaxima) +
                "; tolerancia = " + FormatearLongitudDiagnosticoMYG(toleranciaColineal) + ".");
            return 0;
        }

        XYZ direccionDistribucion =
            datos.YAxis.Multiply(deltaY).Add(
                datos.ZAxis.Multiply(deltaZ));

        if (direccionDistribucion.GetLength() <= Tol)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Dirección de distribución",
                "La dirección Y-Z calculada para el set tiene longitud cero.");
            return 0;
        }

        direccionDistribucion = direccionDistribucion.Normalize();

        AceroVigaBarraLongitudinal2D definicionBase =
            primera.Definicion;

        int tipoRuta;
        string textoTipo;
        ObtenerClasificacionCapaManualMYG(
            definicionBase,
            out tipoRuta,
            out textoTipo);

        if (!string.IsNullOrWhiteSpace(textoTipoForzadoMYG))
            textoTipo = textoTipoForzadoMYG;

        // =========================================================
        // V11.48 - BASTÓN / BALANCÍN: GEOMETRÍA SIEMPRE COLINEAL
        // =========================================================
        // Un refuerzo especial que atraviesa un nodo NO debe heredar las
        // transiciones proyectadas de las caras locales de cada host. En un
        // cambio de anfitrión esas caras pueden tener ejes Y invertidos y la
        // misma posición termina saltando de un lado al otro, generando el
        // cruce/fan reportado en planta.
        //
        // Para BASTÓN/BALANCÍN se usa una única recta global de la serie.
        // El cambio de host NO cambia Y/Z, por lo que las barras permanecen
        // continuas, paralelas y colineales en todo el nodo.
        bool esRefuerzoEspecialColinealMYG =
            EsTextoTipoEspecialColinealMYG(textoTipo);

        double longitudEmpalme = tipoRuta > 0
            ? longitudEmpalmeSuperior
            : (tipoRuta < 0
                ? longitudEmpalmeInferior
                : longitudEmpalmeCentral);

        double xInicioManual;
        double xFinManual;

        ObtenerIntervaloLongitudinalManualConDesarrollosMYG(
            datos,
            desarrolloInicioHabilitado,
            longitudDesarrolloInicio,
            desarrolloFinHabilitado,
            longitudDesarrolloFin,
            out xInicioManual,
            out xFinManual);

        if (xFinManual <= xInicioManual + Tol)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Intervalo longitudinal",
                "X inicio = " + FormatearLongitudDiagnosticoMYG(xInicioManual) +
                "; X fin = " + FormatearLongitudDiagnosticoMYG(xFinManual) + ".");
            return 0;
        }

        List<SegmentoAceroLongitudinal> segmentos;

        if (segmentosAcumuladosEstacionesMYG != null &&
            segmentosAcumuladosEstacionesMYG.Count > 0)
        {
            // V11.44 - el plan comercial ya fue calculado sobre la CADENA
            // continua completa. Aquí solo se recorta al Rebar físico de este
            // tramo/lote; el cambio de host no reinicia los 9 m.
            segmentos = RecortarSegmentosAcumuladosAlLoteMYG(
                segmentosAcumuladosEstacionesMYG,
                xInicioManual,
                xFinManual);
        }
        else
        {
            segmentos =
                ConstruirSegmentosLongitudinales(
                    datos,
                    tipoRuta,
                    xInicioManual,
                    xFinManual,
                    crearEmpalmes,
                    longitudBarra,
                    longitudEmpalme,
                    0.0,
                    0.0,
                    diametro,
                    tipo);
        }

        if (segmentos == null || segmentos.Count == 0)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Segmentación comercial / empalmes",
                "ConstruirSegmentosLongitudinales devolvió 0 segmentos. " +
                "Intervalo = " + FormatearLongitudDiagnosticoMYG(xInicioManual) +
                " -> " + FormatearLongitudDiagnosticoMYG(xFinManual) +
                "; longitud comercial = " + FormatearLongitudDiagnosticoMYG(longitudBarra) +
                "; empalme = " + FormatearLongitudDiagnosticoMYG(longitudEmpalme) + ".");
            // V11.9: un empalme solicitado nunca se sustituye silenciosamente
            // por una barra continua.
            return 0;
        }

        double desfaseEmpalme =
            ObtenerDesfaseEmpalmeCaraACara(diametro);

        // V11.3 - el quiebre debe estar en el MISMO plano de la barra base
        // para que Revit pueda conservar Número fijo / Espaciado máximo como
        // una regla shape-driven. Por eso la dirección del quiebre se obtiene
        // perpendicular a la dirección de distribución transversal del grupo.
        //
        // Para una capa horizontal:
        //   distribución = Y  -> quiebre superior/inferior = Z.
        // Para una capa inclinada:
        //   el quiebre gira automáticamente y sigue siendo perpendicular a la
        //   guía de la capa, evitando convertir el grupo en barras individuales.
        XYZ direccionLongitudinal =
            datos.XAxis != null && datos.XAxis.GetLength() > Tol
                ? datos.XAxis.Normalize()
                : XYZ.BasisX;

        XYZ direccionDesfase =
            direccionLongitudinal.CrossProduct(direccionDistribucion);

        if (direccionDesfase == null || direccionDesfase.GetLength() <= Tol)
        {
            direccionDesfase = tipoRuta > 0
                ? datos.ZAxis.Multiply(-1.0)
                : (tipoRuta < 0 ? datos.ZAxis : datos.ZAxis.Multiply(-1.0));
        }
        else
        {
            direccionDesfase = direccionDesfase.Normalize();

            // Conserva el sentido intuitivo del módulo anterior:
            // superior hacia abajo e inferior hacia arriba.
            XYZ direccionPreferida = tipoRuta > 0
                ? datos.ZAxis.Multiply(-1.0)
                : (tipoRuta < 0 ? datos.ZAxis : direccionDesfase);

            if (direccionPreferida != null &&
                direccionPreferida.GetLength() > Tol &&
                direccionDesfase.DotProduct(direccionPreferida.Normalize()) < 0.0)
            {
                direccionDesfase = direccionDesfase.Multiply(-1.0);
            }
        }

        XYZ direccionGancho = direccionDesfase;

        int totalGrupo = 0;

        foreach (SegmentoAceroLongitudinal seg in segmentos)
        {
            if (seg == null || seg.XFin <= seg.XInicio + Tol)
                continue;

            // V11.6:
            // Cada SegmentoAceroLongitudinal representa UNA PIEZA FÍSICA.
            // No se fragmenta por viga. El host se elige solo como anfitrión
            // de referencia para Revit, pero los puntos conservan el recorrido
            // completo de la pieza, incluido el vacío/apoyo entre vigas.
            bool usarGanchoInicio = ganchoInicio && seg.EsPrimero;
            bool usarGanchoFin = ganchoFin && seg.EsUltimo;

            // V11.3:
            // Para una sola viga recta y de sección constante, la inclinación
            // TRANSVERSAL de la sección no debe convertir la trayectoria
            // longitudinal en una polilínea por caras. Todas las barras del
            // grupo son traslaciones exactas de una misma recta a lo largo del
            // eje de la viga, por lo que se fuerza una base de dos puntos.
            // Esta es la condición necesaria para que Revit conserve Número
            // fijo o Espaciado máximo como regla shape-driven editable.
            bool usarTrayectoriaRectaNativa =
                PuedeUsarTrayectoriaRectaNativaGrupoMYG(
                    datos,
                    seg,
                    crearEmpalmes,
                    usarGanchoInicio,
                    usarGanchoFin);

            bool serieMultiHostRecta =
                EsSerieMultiHostRectaContinuaMYG(datos);

            List<XYZ> puntos;

            if (esRefuerzoEspecialColinealMYG)
            {
                // V11.48:
                // BASTÓN/BALANCÍN nunca usa puntos de transición por host.
                // Se conserva una sola línea física en el sistema global de
                // la serie, incluso cuando el Rebar atraviesa dos o más vigas.
                puntos =
                    ConstruirPuntosBarraEspecialColinealMYG(
                        datos,
                        seg,
                        primera.Y,
                        primera.Z);
            }
            else if (usarTrayectoriaRectaNativa)
            {
                puntos = ConstruirPuntosBarraRectaNativaGrupoMYG(
                    datos,
                    seg,
                    primera.Y,
                    primera.Z);
            }
            else if (serieMultiHostRecta)
            {
                // V11.49:
                // En una serie recta de varios hosts NO se reconstruye la posición
                // transversal con los ejes locales de cada viga. Ese cambio de base
                // podía invertir izquierda/derecha entre tramos y producir el
                // abanico/cruce reportado en planta.
                //
                // Se usa una única referencia transversal de la serie para TODA la
                // pieza física, conservando únicamente el quiebre real de empalme.
                puntos = ConstruirPuntosBarraMultiHostRectaColinealMYG(
                    datos,
                    seg,
                    primera.Y,
                    primera.Z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfase,
                    desfaseEmpalme);
            }
            else
            {
                puntos = ConstruirPuntosBarraConEmpalme(
                    datos,
                    seg,
                    primera.Y,
                    primera.Z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfase,
                    desfaseEmpalme,
                    offset,
                    true);
            }

            if (puntos == null || puntos.Count < 2)
            {
                puntos = esRefuerzoEspecialColinealMYG
                    ? ConstruirPuntosBarraEspecialColinealMYG(
                        datos,
                        seg,
                        primera.Y,
                        primera.Z)
                    : (serieMultiHostRecta
                        ? ConstruirPuntosBarraMultiHostRectaColinealMYG(
                            datos,
                            seg,
                            primera.Y,
                            primera.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme)
                        : ConstruirPuntosBarraConEmpalmeOriginal(
                            datos,
                            seg,
                            primera.Y,
                            primera.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme));
            }

            if (puntos == null || puntos.Count < 2)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "Geometría de la pieza comercial",
                    "No se obtuvieron al menos 2 puntos para el segmento " +
                    FormatearLongitudDiagnosticoMYG(seg.XInicio) + " -> " +
                    FormatearLongitudDiagnosticoMYG(seg.XFin) +
                    ". EmpalmeInicio=" + seg.TieneEmpalmeInicio +
                    ", EmpalmeFin=" + seg.TieneEmpalmeFin + ".");
                return 0;
            }

            int cantidadRegla =
                grupo.Regla == AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo
                    ? Math.Max(2, posiciones.Count)
                    : Math.Max(1, Math.Min(1002, grupo.Cantidad));

            // =========================================================
            // V11.36 - PRIORIDAD REAL: CONSERVAR EL SET CORRECTO Y NO CREAR
            // UN SEGUNDO JUEGO INDIVIDUAL ENCIMA.
            //
            // Cada pieza comercial se intenta primero como SHAPE-DRIVEN SET.
            // Ese intento vive en una SubTransaction propia para que, si Revit
            // alcanza a crear algo pero luego rechaza la regla, se limpie SOLO
            // esa pieza. Los sets correctos de piezas anteriores se conservan.
            // =========================================================
            int creadas = 0;

            using (SubTransaction subShapeSegmento = new SubTransaction(doc))
            {
                subShapeSegmento.Start();

                try
                {
                    creadas =
                        CrearRebarLongitudinalConReglaGrupoPiezaContinuaMYG(
                            doc,
                            datos,
                            seg,
                            tipo,
                            direccionDistribucion,
                            puntos,
                            usarGanchoInicio,
                            longitudGanchoInicio,
                            usarGanchoFin,
                            longitudGanchoFin,
                            direccionGancho,
                            grupo.Regla,
                            cantidadRegla,
                            UnitUtils.ConvertToInternalUnits(
                                Math.Max(0.10, grupo.EspaciadoCm),
                                UnitTypeId.Centimeters),
                            longitudDistribucion,
                            textoTipo,
                            !grupo.OmitirPrimeraBarra,
                            !grupo.OmitirUltimaBarra);
                }
                catch
                {
                    creadas = 0;
                }

                if (creadas > 0)
                    subShapeSegmento.Commit();
                else
                    subShapeSegmento.RollBack();
            }

            if (creadas <= 0)
            {
                // El respaldo ya NO recrea el grupo completo. Ese era el origen
                // de los dobles: una pieza anterior quedaba como Número fijo y
                // luego el respaldo volvía a materializar todo el recorrido.
                // Ahora se crea únicamente ESTA pieza comercial como FreeForm SET,
                // manteniendo la misma regla y las mismas posiciones del maestro.
                int creadasExactasSegmento = 0;

                using (SubTransaction subFreeFormSegmento = new SubTransaction(doc))
                {
                    subFreeFormSegmento.Start();

                    try
                    {
                        creadasExactasSegmento =
                            CrearGrupoLongitudinalFreeFormExactoSegmentoMYG(
                                doc,
                                datos,
                                grupo,
                                posiciones,
                                tipo,
                                offset,
                                seg,
                                crearEmpalmes,
                                longitudEmpalme,
                                direccionDesfase,
                                desfaseEmpalme,
                                usarGanchoInicio,
                                longitudGanchoInicio,
                                usarGanchoFin,
                                longitudGanchoFin,
                                direccionGancho,
                                textoTipo);
                    }
                    catch
                    {
                        creadasExactasSegmento = 0;
                    }

                    if (creadasExactasSegmento > 0)
                        subFreeFormSegmento.Commit();
                    else
                        subFreeFormSegmento.RollBack();
                }

                if (creadasExactasSegmento > 0)
                {
                    totalGrupo += creadasExactasSegmento;
                    continue;
                }

                // V11.48 - LOS REFUERZOS ESPECIALES NO SE DEGRADAN A INDIVIDUAL.
                // Si Revit no admite el set Shape-Driven ni el FreeForm SET,
                // se revierte el lote completo. Es preferible reportar el fallo
                // antes que crear barras individuales o geometrías cruzadas.
                if (esRefuerzoEspecialColinealMYG || serieMultiHostRecta)
                {
                    string detallePrevioEspecial = ultimoErrorLongitudinalMYG;
                    MarcarUltimoErrorLongitudinalMYG(
                        "SERIE MULTIHOST - set continuo obligatorio V11.50",
                        "No se pudo conservar la armadura como conjunto continuo. " +
                        "Segmento X=" + FormatearLongitudDiagnosticoMYG(seg.XInicio) +
                        " -> " + FormatearLongitudDiagnosticoMYG(seg.XFin) +
                        "; regla=" + grupo.Regla +
                        "; cantidad=" + cantidadRegla +
                        ". En una serie recta entre tramos NO se permite respaldo Individual, " +
                        "porque produciría cruces o barras superpuestas." +
                        (string.IsNullOrWhiteSpace(detallePrevioEspecial)
                            ? string.Empty
                            : "\r\nDetalle previo: " + detallePrevioEspecial));
                    return 0;
                }

                // V11.37 - ÚLTIMO RECURSO SOLO PARA UNA PIEZA NORMAL QUE FALLÓ.
                // Los BASTONES/BALANCINES ya fueron excluidos arriba.
                int creadasIndividualesSegmento =
                    CrearGrupoLongitudinalIndividualExactoSegmentoMYG(
                        doc,
                        datos,
                        grupo,
                        posiciones,
                        tipo,
                        offset,
                        seg,
                        crearEmpalmes,
                        longitudEmpalme,
                        direccionDesfase,
                        desfaseEmpalme,
                        usarGanchoInicio,
                        longitudGanchoInicio,
                        usarGanchoFin,
                        longitudGanchoFin,
                        direccionGancho,
                        direccionDistribucion,
                        textoTipo);

                if (creadasIndividualesSegmento > 0)
                {
                    totalGrupo += creadasIndividualesSegmento;
                    continue;
                }

                string errorInternoAnterior = ultimoErrorLongitudinalMYG;
                MarcarUltimoErrorLongitudinalMYG(
                    "Fallo definitivo de pieza / set V11.37",
                    "Segmento X=" + FormatearLongitudDiagnosticoMYG(seg.XInicio) +
                    " -> " + FormatearLongitudDiagnosticoMYG(seg.XFin) +
                    "; longitud=" + FormatearLongitudDiagnosticoMYG(seg.XFin - seg.XInicio) +
                    "; EmpalmeInicio=" + seg.TieneEmpalmeInicio +
                    "; EmpalmeFin=" + seg.TieneEmpalmeFin +
                    "; EsPrimero=" + seg.EsPrimero +
                    "; EsUltimo=" + seg.EsUltimo +
                    "; puntos=" + (puntos != null ? puntos.Count : 0) +
                    "; set=" + cantidadRegla +
                    "; regla=" + grupo.Regla +
                    (string.IsNullOrWhiteSpace(errorInternoAnterior)
                        ? string.Empty
                        : "\r\nDetalle interno previo: " + errorInternoAnterior));

                return 0;
            }

            totalGrupo += creadas;
        }

        return totalGrupo;
    }

    // =========================================================
    // V10.9 - GUÍA RECTA Y TRAYECTORIA NATIVA DE DOS PUNTOS
    // =========================================================
    private bool EsGuiaGrupoLongitudinalRectaMYG(
        AceroVigaDisenoSeccion diseno,
        AceroVigaGrupoLongitudinal2D grupo)
    {
        if (diseno == null || grupo == null ||
            string.IsNullOrWhiteSpace(grupo.GuiaCapaId) ||
            diseno.GuiasCapasLongitudinales == null)
        {
            return false;
        }

        AceroVigaGuiaCapaLongitudinal2D guia =
            diseno.GuiasCapasLongitudinales.FirstOrDefault(x =>
                x != null && string.Equals(
                    x.Id,
                    grupo.GuiaCapaId,
                    StringComparison.Ordinal));

        if (guia == null)
            return false;

        IList<AceroVigaPuntoNormalizado> puntos =
            guia.PuntosGuiaSeccionReal != null &&
            guia.PuntosGuiaSeccionReal.Count >= 2
                ? (IList<AceroVigaPuntoNormalizado>)
                    guia.PuntosGuiaSeccionReal
                : guia.PuntosGuia;

        if (puntos == null || puntos.Count < 2)
            return false;

        AceroVigaPuntoNormalizado primero = puntos[0];
        AceroVigaPuntoNormalizado ultimo =
            puntos[puntos.Count - 1];

        if (primero == null || ultimo == null)
            return false;

        double du = ultimo.U - primero.U;
        double dv = ultimo.V - primero.V;
        double longitud = Math.Sqrt(du * du + dv * dv);
        if (longitud <= 1e-9)
            return false;

        // La tolerancia se expresa en coordenada normalizada. Es suficiente
        // para absorber subdivisiones del mismo segmento, pero no convierte
        // una guía realmente quebrada en una recta.
        const double toleranciaNormalizada = 0.0025;

        foreach (AceroVigaPuntoNormalizado punto in puntos)
        {
            if (punto == null)
                continue;

            double distancia = Math.Abs(
                (punto.U - primero.U) * dv -
                (punto.V - primero.V) * du) / longitud;

            if (distancia > toleranciaNormalizada)
                return false;
        }

        return true;
    }

    private bool PuedeUsarTrayectoriaRectaNativaGrupoMYG(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento,
        bool crearEmpalmes,
        bool ganchoInicio,
        bool ganchoFin)
    {
        if (datos == null || segmento == null ||
            datos.XAxis == null ||
            datos.XAxis.GetLength() <= Tol)
        {
            return false;
        }

        // Los ganchos agregan curvas adicionales.
        if (ganchoInicio || ganchoFin)
            return false;

        // V11.3: una pieza que ARRANCA en un empalme debe dibujar el quiebre
        // local del traslape. No se fuerza la trayectoria recta de dos puntos;
        // se deja que ConstruirPuntosBarraConEmpalme genere:
        // tramo desplazado + diagonal de retorno + continuación alineada.
        if (crearEmpalmes &&
            segmento.TieneEmpalmeInicio)
        {
            // V11.8:
            // Una pieza que nace en un empalme NUNCA puede ser sustituida por
            // una barra recta colineal. Debe contener en el mismo Rebar:
            // tramo desplazado + diagonal + continuación alineada.
            return false;
        }

        if (SerieTieneQuiebreEntreTramosLongitudinal(datos))
            return false;

        if (datos.Vigas == null || datos.Vigas.Count == 0)
            return false;

        // V11.6:
        // Una pieza comercial NO se divide por cambio de anfitrión. Si la serie
        // contiene varias vigas pero todas pertenecen al mismo recorrido recto,
        // se conserva una sola barra continua entre XInicio y XFin.
        //
        // Solo se desactiva la ruta nativa de dos puntos cuando existe una
        // variación longitudinal real de la sección que obligue a seguir caras.
        foreach (DatosViga viga in datos.Vigas)
        {
            if (viga == null)
                continue;

            if (viga.TienePerfilSeccionVariable)
                return false;
        }

        if (SerieTieneCaraLongitudinalInclinadaXZ(datos, true) ||
            SerieTieneCaraLongitudinalInclinadaXZ(datos, false))
        {
            return false;
        }

        // Una cara inclinada dentro de la sección Y-Z NO invalida el set.
        // Tampoco lo invalida que haya 2, 3 o más hosts consecutivos.
        return segmento.XFin > segmento.XInicio + Tol;
    }

    // =========================================================
    // V11.48 - RUTA ESPECIAL COLINEAL SIN TRANSICIONES DE HOST
    // =========================================================
    private bool EsTextoTipoEspecialColinealMYG(string textoTipo)
    {
        if (string.IsNullOrWhiteSpace(textoTipo))
            return false;

        string valor = textoTipo.Trim();

        return
            valor.IndexOf("Balancin", StringComparison.OrdinalIgnoreCase) >= 0 ||
            valor.IndexOf("Balancín", StringComparison.OrdinalIgnoreCase) >= 0 ||
            valor.IndexOf("Bastidor", StringComparison.OrdinalIgnoreCase) >= 0 ||
            valor.IndexOf("Baston", StringComparison.OrdinalIgnoreCase) >= 0 ||
            valor.IndexOf("Bastón", StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private List<XYZ> ConstruirPuntosBarraEspecialColinealMYG(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento,
        double y,
        double z)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (datos == null ||
            segmento == null ||
            segmento.XFin <= segmento.XInicio + Tol ||
            datos.PInicio == null ||
            datos.XAxis == null ||
            datos.YAxis == null ||
            datos.ZAxis == null ||
            datos.XAxis.GetLength() <= Tol ||
            datos.YAxis.GetLength() <= Tol ||
            datos.ZAxis.GetLength() <= Tol)
        {
            return puntos;
        }

        // IMPORTANTE:
        // NO usar PuntoLocal(), PuntoEnTramoRecorrido(),
        // ObtenerTransicionesProyectadas() ni CalcularPuntoQuiebreProyectado().
        // Esos métodos adaptan la barra al sistema local de cada viga y son
        // justamente los que pueden intercambiar el lado transversal en un nodo.
        //
        // Para el refuerzo especial se conserva el mismo Y/Z global desde el
        // inicio hasta el fin de la pieza.
        XYZ ejeX = datos.XAxis.Normalize();
        XYZ ejeY = datos.YAxis.Normalize();
        XYZ ejeZ = datos.ZAxis.Normalize();

        XYZ baseSeccion =
            datos.PInicio
                .Add(ejeY.Multiply(y))
                .Add(ejeZ.Multiply(z));

        XYZ inicio =
            baseSeccion.Add(
                ejeX.Multiply(segmento.XInicio));

        XYZ fin =
            baseSeccion.Add(
                ejeX.Multiply(segmento.XFin));

        if (inicio == null ||
            fin == null ||
            (fin - inicio).GetLength() <= Tol)
        {
            return puntos;
        }

        puntos.Add(inicio);
        puntos.Add(fin);

        return puntos;
    }


    // =========================================================
    // V11.49 - RUTA MULTIHOST RECTA SIN CRUCES
    // =========================================================
    // Para una serie de vigas colineales la posición transversal de una barra
    // es UNA coordenada física única. Nunca debe recalcularse con YAxis local
    // de cada host, porque dos vigas pueden tener sus ejes locales invertidos.
    //
    // Este método mantiene Y/Z constantes en el sistema global de la serie y
    // solo introduce el quiebre que pertenece realmente al EMPALME.
    private List<XYZ> ConstruirPuntosBarraMultiHostRectaColinealMYG(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento,
        double y,
        double z,
        bool crearEmpalmes,
        double longitudEmpalme,
        XYZ direccionDesfaseEmpalme,
        double desfaseEmpalme)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (datos == null ||
            segmento == null ||
            segmento.XFin <= segmento.XInicio + Tol ||
            datos.PInicio == null ||
            datos.XAxis == null ||
            datos.YAxis == null ||
            datos.ZAxis == null ||
            datos.XAxis.GetLength() <= Tol ||
            datos.YAxis.GetLength() <= Tol ||
            datos.ZAxis.GetLength() <= Tol)
        {
            return puntos;
        }

        XYZ ejeX = datos.XAxis.Normalize();
        XYZ ejeY = datos.YAxis.Normalize();
        XYZ ejeZ = datos.ZAxis.Normalize();

        XYZ baseSeccion =
            datos.PInicio
                .Add(ejeY.Multiply(y))
                .Add(ejeZ.Multiply(z));

        Func<double, XYZ> puntoBase = estacion =>
            baseSeccion.Add(ejeX.Multiply(estacion));

        bool tieneQuiebreEmpalme =
            crearEmpalmes &&
            segmento.TieneEmpalmeInicio &&
            longitudEmpalme > Tol &&
            direccionDesfaseEmpalme != null &&
            direccionDesfaseEmpalme.GetLength() > Tol &&
            desfaseEmpalme > Tol;

        if (!tieneQuiebreEmpalme)
        {
            AgregarPuntoSiValido(
                puntos,
                puntoBase(segmento.XInicio));

            AgregarPuntoSiValido(
                puntos,
                puntoBase(segmento.XFin));

            return LimpiarPuntosConsecutivos(puntos);
        }

        XYZ offset =
            direccionDesfaseEmpalme
                .Normalize()
                .Multiply(desfaseEmpalme);

        double xEmpalmeFin =
            Math.Min(
                segmento.XInicio + longitudEmpalme,
                segmento.XFin);

        double espacioDespuesEmpalme =
            segmento.XFin - xEmpalmeFin;

        double longitudDiagonal;

        if (!TryObtenerLongitudDiagonalQuiebreSeguraMYG(
                espacioDespuesEmpalme,
                desfaseEmpalme,
                out longitudDiagonal))
        {
            return new List<XYZ>();
        }

        double xDiagonalFin =
            Math.Min(
                xEmpalmeFin + longitudDiagonal,
                segmento.XFin);

        // Traslape desplazado: sigue siendo perfectamente paralelo a la barra.
        AgregarPuntoSiValido(
            puntos,
            puntoBase(segmento.XInicio).Add(offset));

        AgregarPuntoSiValido(
            puntos,
            puntoBase(xEmpalmeFin).Add(offset));

        // ÚNICA diagonal permitida: la diagonal propia del empalme.
        if (xDiagonalFin > xEmpalmeFin + Tol)
        {
            AgregarPuntoSiValido(
                puntos,
                puntoBase(xDiagonalFin));
        }

        if (segmento.XFin > xDiagonalFin + Tol)
        {
            AgregarPuntoSiValido(
                puntos,
                puntoBase(segmento.XFin));
        }

        return LimpiarPuntosConsecutivos(puntos);
    }


    private List<XYZ> ConstruirPuntosBarraRectaNativaGrupoMYG(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento,
        double y,
        double z)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (datos == null || segmento == null ||
            segmento.XFin <= segmento.XInicio + Tol)
        {
            return puntos;
        }

        XYZ inicio = PuntoLocal(
            datos,
            segmento.XInicio,
            y,
            z);
        XYZ fin = PuntoLocal(
            datos,
            segmento.XFin,
            y,
            z);

        if (inicio == null || fin == null ||
            (fin - inicio).GetLength() <= Tol)
        {
            return puntos;
        }

        puntos.Add(inicio);
        puntos.Add(fin);
        return puntos;
    }

    private bool RequiereTrayectoriaExactaManualMYG(
        DatosSerieVigas datos)
    {
        if (datos == null)
            return false;

        // La inclinación transversal Y-Z por sí sola no obliga a crear barras
        // individuales. Un conjunto recto puede conservar su regla nativa usando
        // como normal la dirección real de distribución dentro de la sección.
        if (SerieTieneQuiebreEntreTramosLongitudinal(datos))
            return true;

        if (SerieTieneCaraLongitudinalInclinadaXZ(datos, true) ||
            SerieTieneCaraLongitudinalInclinadaXZ(datos, false))
        {
            return true;
        }

        if (datos.Vigas != null &&
            datos.Vigas.Any(x =>
                x != null &&
                x.TienePerfilSeccionVariable))
        {
            return true;
        }

        return false;
    }

    // =========================================================
    // V11.37 - INDIVIDUALES SOLO PARA UNA PIEZA COMERCIAL FALLIDA
    // =========================================================
    // Este es el ÚLTIMO recurso. Trabaja con el mismo segmento comercial que
    // falló como set, por lo que conserva el quiebre/empalme de esa pieza.
    // Nunca reconstruye el recorrido completo del grupo y, por tanto, no puede
    // volver a colocar una barra Individual encima de un Número fijo ya válido.
    private int CrearGrupoLongitudinalIndividualExactoSegmentoMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaGrupoLongitudinal2D grupo,
        List<PosicionGrupoLongitudinalManualMYG> posiciones,
        RebarBarType tipo,
        double offset,
        SegmentoAceroLongitudinal segmento,
        bool crearEmpalmes,
        double longitudEmpalme,
        XYZ direccionDesfase,
        double desfaseEmpalme,
        bool usarGanchoInicio,
        double longitudGanchoInicio,
        bool usarGanchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho,
        XYZ direccionDistribucion,
        string textoTipo)
    {
        if (doc == null || datos == null || grupo == null ||
            posiciones == null || posiciones.Count == 0 ||
            tipo == null || segmento == null ||
            segmento.XFin <= segmento.XInicio + Tol)
        {
            return 0;
        }

        List<PosicionGrupoLongitudinalManualMYG> visibles =
            posiciones
                .Where(p =>
                    p != null &&
                    p.Definicion != null &&
                    !p.Definicion.OcultaPorSuperposicion)
                .ToList();

        if (grupo.OmitirPrimeraBarra && visibles.Count > 0)
            visibles.RemoveAt(0);

        if (grupo.OmitirUltimaBarra && visibles.Count > 0)
            visibles.RemoveAt(visibles.Count - 1);

        if (visibles.Count == 0)
            return 0;

        XYZ normalIndividual = direccionDistribucion;
        if (normalIndividual == null || normalIndividual.GetLength() <= Tol)
            normalIndividual = datos.YAxis;
        if (normalIndividual == null || normalIndividual.GetLength() <= Tol)
            normalIndividual = XYZ.BasisY;
        normalIndividual = normalIndividual.Normalize();

        int total = 0;
        bool fallo = false;

        using (SubTransaction subIndividuales = new SubTransaction(doc))
        {
            subIndividuales.Start();

            foreach (PosicionGrupoLongitudinalManualMYG posicion in visibles)
            {
                List<XYZ> puntosIndividual;

                if (EsSerieMultiHostRectaContinuaMYG(datos))
                {
                    puntosIndividual =
                        ConstruirPuntosBarraConEmpalmeOriginal(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme);
                }
                else
                {
                    puntosIndividual =
                        ConstruirPuntosBarraConEmpalme(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme,
                            offset,
                            true);
                }

                if (puntosIndividual == null || puntosIndividual.Count < 2)
                {
                    puntosIndividual =
                        ConstruirPuntosBarraConEmpalmeOriginal(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme);
                }

                if (puntosIndividual == null || puntosIndividual.Count < 2)
                {
                    fallo = true;
                    break;
                }

                int creada =
                    CrearRebarLongitudinalConNumeroFijoPiezaContinuaMYG(
                        doc,
                        datos,
                        segmento,
                        tipo,
                        normalIndividual,
                        puntosIndividual,
                        usarGanchoInicio,
                        longitudGanchoInicio,
                        usarGanchoFin,
                        longitudGanchoFin,
                        direccionGancho,
                        1,
                        0.0,
                        textoTipo);

                if (creada <= 0)
                {
                    fallo = true;
                    break;
                }

                total += creada;
            }

            if (!fallo && total == visibles.Count)
                subIndividuales.Commit();
            else
                subIndividuales.RollBack();
        }

        if (fallo || total != visibles.Count)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Individual exacto por segmento V11.37",
                "No se pudieron crear todas las posiciones de la pieza X=" +
                FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) +
                "; esperadas=" + visibles.Count +
                "; creadas=" + total + ".");
            return 0;
        }

        return total;
    }

    // =========================================================
    // V11.36 - FREEFORM SET EXACTO PARA UNA SOLA PIEZA COMERCIAL
    // =========================================================
    // Este método es deliberadamente por SEGMENTO. Nunca vuelve a crear las
    // piezas anteriores del mismo grupo, por lo que permite mezclar de forma
    // limpia piezas Shape-Driven y FreeForm sin duplicar geometría.
    private int CrearGrupoLongitudinalFreeFormExactoSegmentoMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaGrupoLongitudinal2D grupo,
        List<PosicionGrupoLongitudinalManualMYG> posiciones,
        RebarBarType tipo,
        double offset,
        SegmentoAceroLongitudinal segmento,
        bool crearEmpalmes,
        double longitudEmpalme,
        XYZ direccionDesfase,
        double desfaseEmpalme,
        bool usarGanchoInicio,
        double longitudGanchoInicio,
        bool usarGanchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho,
        string textoTipo)
    {
        if (doc == null || datos == null || datos.Host == null ||
            grupo == null || posiciones == null || posiciones.Count < 2 ||
            tipo == null || segmento == null ||
            segmento.XFin <= segmento.XInicio + Tol)
        {
            return 0;
        }

        List<PosicionGrupoLongitudinalManualMYG> visibles =
            posiciones
                .Where(p =>
                    p != null &&
                    p.Definicion != null &&
                    !p.Definicion.OcultaPorSuperposicion)
                .ToList();

        if (grupo.OmitirPrimeraBarra && visibles.Count > 0)
            visibles.RemoveAt(0);

        if (grupo.OmitirUltimaBarra && visibles.Count > 0)
            visibles.RemoveAt(visibles.Count - 1);

        if (visibles.Count < 2)
            return 0;

        bool esRefuerzoEspecialColinealMYG =
            EsTextoTipoEspecialColinealMYG(textoTipo);

        IList<IList<Curve>> curvasPorBarra =
            new List<IList<Curve>>();

        foreach (PosicionGrupoLongitudinalManualMYG posicion in visibles)
        {
            if (posicion == null || posicion.Definicion == null)
                continue;

            List<XYZ> puntos;

            if (esRefuerzoEspecialColinealMYG)
            {
                // V11.48:
                // Todas las posiciones de un mismo set especial usan la misma
                // recta longitudinal global. Solo cambia su offset transversal.
                puntos =
                    ConstruirPuntosBarraEspecialColinealMYG(
                        datos,
                        segmento,
                        posicion.Y,
                        posicion.Z);
            }
            else if (EsSerieMultiHostRectaContinuaMYG(datos))
            {
                // V11.49: mismo eje transversal estable que el intento Shape-Driven.
                // El respaldo FreeForm NO puede volver a invertir las posiciones.
                puntos =
                    ConstruirPuntosBarraMultiHostRectaColinealMYG(
                        datos,
                        segmento,
                        posicion.Y,
                        posicion.Z,
                        crearEmpalmes,
                        longitudEmpalme,
                        direccionDesfase,
                        desfaseEmpalme);
            }
            else
            {
                puntos =
                    ConstruirPuntosBarraConEmpalme(
                        datos,
                        segmento,
                        posicion.Y,
                        posicion.Z,
                        crearEmpalmes,
                        longitudEmpalme,
                        direccionDesfase,
                        desfaseEmpalme,
                        offset,
                        true);
            }

            if (puntos == null || puntos.Count < 2)
            {
                bool serieMultiHostRectaFallback =
                    EsSerieMultiHostRectaContinuaMYG(datos);

                puntos =
                    esRefuerzoEspecialColinealMYG
                        ? ConstruirPuntosBarraEspecialColinealMYG(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z)
                        : (serieMultiHostRectaFallback
                            ? ConstruirPuntosBarraMultiHostRectaColinealMYG(
                                datos,
                                segmento,
                                posicion.Y,
                                posicion.Z,
                                crearEmpalmes,
                                longitudEmpalme,
                                direccionDesfase,
                                desfaseEmpalme)
                            : ConstruirPuntosBarraConEmpalmeOriginal(
                                datos,
                                segmento,
                                posicion.Y,
                                posicion.Z,
                                crearEmpalmes,
                                longitudEmpalme,
                                direccionDesfase,
                                desfaseEmpalme));
            }

            if (puntos == null || puntos.Count < 2)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "FreeForm por segmento V11.36",
                    "No se obtuvieron puntos para X=" +
                    FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                    " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) + ".");
                return 0;
            }

            List<XYZ> puntosGeometricos =
                ConstruirPuntosGeometricosLongitudinalMYG(
                    puntos,
                    usarGanchoInicio,
                    longitudGanchoInicio,
                    usarGanchoFin,
                    longitudGanchoFin,
                    direccionGancho);

            if (puntosGeometricos == null || puntosGeometricos.Count < 2)
                return 0;

            IList<Curve> curvas =
                ConstruirCurvasDesdePuntosLongitudinalMYG(
                    puntosGeometricos);

            if (curvas == null || curvas.Count == 0)
                return 0;

            curvasPorBarra.Add(curvas);
        }

        if (curvasPorBarra.Count < 2)
            return 0;

        List<Element> hosts =
            ObtenerHostsCandidatosPiezaContinuaLongitudinalMYG(
                datos,
                segmento);

        if (hosts == null || hosts.Count == 0)
        {
            hosts = new List<Element>();
            if (datos.Host != null)
                hosts.Add(datos.Host);
        }

        Rebar rebarPieza = null;
        Element hostUsado = null;

        foreach (Element hostCandidato in hosts)
        {
            if (hostCandidato == null)
                continue;

            try
            {
                object resultado =
                    Rebar.CreateFreeForm(
                        doc,
                        tipo,
                        hostCandidato,
                        curvasPorBarra,
                        RebarStyle.Standard);

                if (resultado == null)
                    continue;

                System.Reflection.PropertyInfo propiedadRebar =
                    resultado.GetType().GetProperty(
                        "Rebar",
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.Instance);

                if (propiedadRebar == null)
                    continue;

                Rebar candidato =
                    propiedadRebar.GetValue(resultado, null) as Rebar;

                if (candidato == null)
                    continue;

                rebarPieza = candidato;
                hostUsado = hostCandidato;
                break;
            }
            catch (Exception ex)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "Rebar.CreateFreeForm por segmento V11.36",
                    "Host=" + hostCandidato.Id +
                    "; segmento=" +
                    FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                    " -> " +
                    FormatearLongitudDiagnosticoMYG(segmento.XFin) +
                    "; barras=" + curvasPorBarra.Count + ".",
                    ex);

                rebarPieza = null;
                hostUsado = null;
            }
        }

        if (rebarPieza == null)
            return 0;

        if (!AplicarReglaGrupoAFreeFormMYG(
                rebarPieza,
                grupo.Regla,
                curvasPorBarra.Count,
                UnitUtils.ConvertToInternalUnits(
                    Math.Max(0.10, grupo.EspaciadoCm),
                    UnitTypeId.Centimeters)))
        {
            try
            {
                doc.Delete(rebarPieza.Id);
            }
            catch
            {
            }

            return 0;
        }

        AplicarParametrosInstanciaAceroLongitudinal(
            doc,
            rebarPieza,
            hostUsado ?? datos.Host,
            textoTipo);

        return curvasPorBarra.Count;
    }

    private int CrearGrupoLongitudinalFreeFormExactoManualMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaGrupoLongitudinal2D grupo,
        List<PosicionGrupoLongitudinalManualMYG> posiciones,
        RebarBarType tipo,
        double diametro,
        double offset,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        if (doc == null || datos == null || datos.Host == null ||
            grupo == null || posiciones == null || posiciones.Count < 2 ||
            tipo == null)
        {
            return 0;
        }

        double xInicioManual;
        double xFinManual;

        ObtenerIntervaloLongitudinalManualConDesarrollosMYG(
            datos,
            desarrolloInicioHabilitado,
            longitudDesarrolloInicio,
            desarrolloFinHabilitado,
            longitudDesarrolloFin,
            out xInicioManual,
            out xFinManual);

        if (xFinManual <= xInicioManual + Tol)
            return 0;

        List<PosicionGrupoLongitudinalManualMYG> visibles =
            posiciones
                .Where(x =>
                    x != null &&
                    x.Definicion != null &&
                    !x.Definicion.OcultaPorSuperposicion)
                .ToList();

        if (grupo.OmitirPrimeraBarra && visibles.Count > 0)
            visibles.RemoveAt(0);

        if (grupo.OmitirUltimaBarra && visibles.Count > 0)
            visibles.RemoveAt(visibles.Count - 1);

        if (visibles.Count <= 0)
            return 0;

        PosicionGrupoLongitudinalManualMYG primera =
            visibles.FirstOrDefault();

        PosicionGrupoLongitudinalManualMYG ultima =
            visibles.LastOrDefault();

        if (primera == null || ultima == null ||
            primera.Definicion == null)
        {
            return 0;
        }

        int tipoRuta;
        string textoTipo;

        ObtenerClasificacionCapaManualMYG(
            primera.Definicion,
            out tipoRuta,
            out textoTipo);

        double longitudEmpalme =
            tipoRuta > 0
                ? longitudEmpalmeSuperior
                : (tipoRuta < 0
                    ? longitudEmpalmeInferior
                    : longitudEmpalmeCentral);

        // ---------------------------------------------------------
        // Dirección REAL de distribución del grupo en la sección Y-Z.
        // El quiebre se hace perpendicular a esta dirección, de manera que
        // el conjunto completo conserva el mismo plano.
        // ---------------------------------------------------------
        double deltaY = ultima.Y - primera.Y;
        double deltaZ = ultima.Z - primera.Z;

        XYZ direccionDistribucion =
            datos.YAxis.Multiply(deltaY).Add(
                datos.ZAxis.Multiply(deltaZ));

        if (direccionDistribucion == null ||
            direccionDistribucion.GetLength() <= Tol)
        {
            direccionDistribucion =
                datos.YAxis != null &&
                datos.YAxis.GetLength() > Tol
                    ? datos.YAxis.Normalize()
                    : XYZ.BasisY;
        }
        else
        {
            direccionDistribucion =
                direccionDistribucion.Normalize();
        }

        XYZ direccionLongitudinal =
            datos.XAxis != null &&
            datos.XAxis.GetLength() > Tol
                ? datos.XAxis.Normalize()
                : XYZ.BasisX;

        XYZ direccionDesfase =
            direccionLongitudinal.CrossProduct(
                direccionDistribucion);

        if (direccionDesfase == null ||
            direccionDesfase.GetLength() <= Tol)
        {
            direccionDesfase =
                tipoRuta > 0
                    ? datos.ZAxis.Multiply(-1.0)
                    : (tipoRuta < 0
                        ? datos.ZAxis
                        : datos.ZAxis.Multiply(-1.0));
        }
        else
        {
            direccionDesfase =
                direccionDesfase.Normalize();

            XYZ direccionPreferida =
                tipoRuta > 0
                    ? datos.ZAxis.Multiply(-1.0)
                    : (tipoRuta < 0
                        ? datos.ZAxis
                        : direccionDesfase);

            if (direccionPreferida != null &&
                direccionPreferida.GetLength() > Tol &&
                direccionDesfase.DotProduct(
                    direccionPreferida.Normalize()) < 0.0)
            {
                direccionDesfase =
                    direccionDesfase.Multiply(-1.0);
            }
        }

        XYZ direccionGancho = direccionDesfase;

        double desfaseEmpalme =
            ObtenerDesfaseEmpalmeCaraACara(
                diametro);

        // ---------------------------------------------------------
        // Las piezas comerciales se calculan UNA sola vez.
        //
        // SIN EMPALME:
        //   1 segmento = 1 Rebar SET continuo.
        //
        // CON EMPALME:
        //   cada SegmentoAceroLongitudinal = 1 pieza física comercial =
        //   1 Rebar SET. El quiebre NO es otro Rebar: forma parte de todas
        //   las cadenas de curvas de esa pieza.
        // ---------------------------------------------------------
        List<SegmentoAceroLongitudinal> segmentos =
            ConstruirSegmentosLongitudinales(
                datos,
                tipoRuta,
                xInicioManual,
                xFinManual,
                crearEmpalmes,
                longitudBarra,
                longitudEmpalme,
                0.0,
                0.0,
                diametro,
                tipo);

        if (segmentos == null || segmentos.Count == 0)
        {
            // V11.9: no degradar un empalme solicitado a una sola pieza.
            return 0;
        }

        int totalBarrasFisicas = 0;

        foreach (SegmentoAceroLongitudinal segmento in segmentos)
        {
            if (segmento == null ||
                segmento.XFin <= segmento.XInicio + Tol)
            {
                continue;
            }

            IList<IList<Curve>> curvasPorBarra =
                new List<IList<Curve>>();

            bool usarGanchoInicio =
                ganchoInicio && segmento.EsPrimero;

            bool usarGanchoFin =
                ganchoFin && segmento.EsUltimo;

            foreach (PosicionGrupoLongitudinalManualMYG posicion in visibles)
            {
                if (posicion == null ||
                    posicion.Definicion == null)
                {
                    continue;
                }

                List<XYZ> puntos;

                if (EsSerieMultiHostRectaContinuaMYG(datos))
                {
                    // V11.7:
                    // Todo el empalme se construye como una sola polilínea:
                    //
                    //   tramo traslapado desplazado
                    //            +
                    //   diagonal de retorno
                    //            +
                    //   continuación alineada
                    //
                    // No se crea ningún "conector" o quiebre independiente.
                    puntos =
                        ConstruirPuntosBarraConEmpalmeOriginal(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme);
                }
                else
                {
                    puntos =
                        ConstruirPuntosBarraConEmpalme(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme,
                            offset,
                            true);
                }

                if (puntos == null ||
                    puntos.Count < 2)
                {
                    puntos =
                        ConstruirPuntosBarraConEmpalmeOriginal(
                            datos,
                            segmento,
                            posicion.Y,
                            posicion.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfase,
                            desfaseEmpalme);
                }

                if (puntos == null ||
                    puntos.Count < 2)
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "Geometría FreeForm exacta",
                        "La pieza no produjo al menos 2 puntos. Segmento=" +
                        FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                        " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) +
                        "; EmpalmeInicio=" + segmento.TieneEmpalmeInicio +
                        "; EmpalmeFin=" + segmento.TieneEmpalmeFin + ".");
                    return 0;
                }

                List<XYZ> puntosGeometricos =
                    ConstruirPuntosGeometricosLongitudinalMYG(
                        puntos,
                        usarGanchoInicio,
                        longitudGanchoInicio,
                        usarGanchoFin,
                        longitudGanchoFin,
                        direccionGancho);

                if (puntosGeometricos == null ||
                    puntosGeometricos.Count < 2)
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "Geometría FreeForm exacta",
                        "ConstruirPuntosGeometricosLongitudinalMYG devolvió menos de 2 puntos. " +
                        "Segmento=" + FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                        " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) + ".");
                    return 0;
                }

                IList<Curve> curvas =
                    ConstruirCurvasDesdePuntosLongitudinalMYG(
                        puntosGeometricos);

                if (curvas == null ||
                    curvas.Count == 0)
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "Geometría FreeForm exacta",
                        "No se pudieron construir curvas desde los puntos. Segmento=" +
                        FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                        " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) + ".");
                    return 0;
                }

                // Una entrada de curvasPorBarra representa UNA barra física
                // completa. Aunque tenga 3 curvas (traslape, diagonal, tramo
                // recto), Revit la recibe como UNA sola cadena y por tanto no
                // genera un recuento adicional por el quiebre.
                curvasPorBarra.Add(curvas);
            }

            if (curvasPorBarra.Count == 0)
                continue;

            List<Element> hosts =
                ObtenerHostsCandidatosPiezaContinuaLongitudinalMYG(
                    datos,
                    segmento);

            if (hosts == null ||
                hosts.Count == 0)
            {
                hosts = new List<Element>();

                if (datos.Host != null)
                    hosts.Add(datos.Host);
            }

            Rebar rebarPieza = null;
            Element hostUsado = null;

            foreach (Element hostCandidato in hosts)
            {
                if (hostCandidato == null)
                    continue;

                try
                {
                    object resultado =
                        Rebar.CreateFreeForm(
                            doc,
                            tipo,
                            hostCandidato,
                            curvasPorBarra,
                            RebarStyle.Standard);

                    if (resultado == null)
                    {
                        MarcarUltimoErrorLongitudinalMYG(
                            "Rebar.CreateFreeForm del respaldo exacto",
                            "CreateFreeForm devolvió null para host " + hostCandidato.Id +
                            "; segmento " + FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                            " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) + ".");
                        continue;
                    }

                    System.Reflection.PropertyInfo propiedadRebar =
                        resultado.GetType().GetProperty(
                            "Rebar",
                            System.Reflection.BindingFlags.Public |
                            System.Reflection.BindingFlags.Instance);

                    if (propiedadRebar == null)
                    {
                        MarcarUltimoErrorLongitudinalMYG(
                            "Resultado de Rebar.CreateFreeForm",
                            "El resultado no expuso la propiedad Rebar.");
                        continue;
                    }

                    Rebar candidato =
                        propiedadRebar.GetValue(
                            resultado,
                            null) as Rebar;

                    if (candidato == null)
                    {
                        MarcarUltimoErrorLongitudinalMYG(
                            "Resultado de Rebar.CreateFreeForm",
                            "La propiedad Rebar devolvió null.");
                        continue;
                    }

                    rebarPieza = candidato;
                    hostUsado = hostCandidato;
                    break;
                }
                catch (Exception ex)
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "Rebar.CreateFreeForm del respaldo exacto",
                        "Host=" + hostCandidato.Id +
                        "; nombre=" + hostCandidato.Name +
                        "; segmento=" + FormatearLongitudDiagnosticoMYG(segmento.XInicio) +
                        " -> " + FormatearLongitudDiagnosticoMYG(segmento.XFin) +
                        "; barras del set=" + curvasPorBarra.Count + ".",
                        ex);

                    rebarPieza = null;
                    hostUsado = null;
                }
            }

            if (rebarPieza == null)
            {
                if (string.IsNullOrWhiteSpace(ultimoErrorLongitudinalMYG))
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "Respaldo FreeForm del grupo",
                        "Ningún host candidato aceptó la pieza. Segmento=" +
                        FormatearLongitudDiagnosticoMYG(segmento.XInicio) + " -> " +
                        FormatearLongitudDiagnosticoMYG(segmento.XFin) +
                        "; barras del set=" + curvasPorBarra.Count + ".");
                }

                // No se crean barras independientes ni un Rebar adicional
                // para la diagonal. Si la pieza completa no puede resolverse,
                // se devuelve cero para que la subtransacción del grupo haga
                // rollback y no deje recuentos duplicados.
                return 0;
            }

            // =========================================================
            // V11.10 - EL RESPALDO FREE FORM DE UN GRUPO DEBE CONSERVAR
            // LA REGLA REAL DEL GRUPO EN REVIT.
            //
            // Rebar.CreateFreeForm recibe una cadena completa por cada barra,
            // pero Revit puede dejar inicialmente Layout Rule = Individual.
            // Eso NO representa lo definido en DISTRIBUIR 2 PUNTOS.
            // Por eso, inmediatamente después de crear el set, se fuerza la
            // regla mediante RebarFreeFormAccessor. Si Revit no acepta la regla,
            // se elimina el elemento y se devuelve 0: nunca se deja un grupo
            // convertido silenciosamente en barras Individuales.
            // =========================================================
            if (!AplicarReglaGrupoAFreeFormMYG(
                    rebarPieza,
                    grupo.Regla,
                    curvasPorBarra.Count,
                    UnitUtils.ConvertToInternalUnits(
                        Math.Max(0.10, grupo.EspaciadoCm),
                        UnitTypeId.Centimeters)))
            {
                try
                {
                    doc.Delete(rebarPieza.Id);
                }
                catch
                {
                }

                return 0;
            }

            AplicarParametrosInstanciaAceroLongitudinal(
                doc,
                rebarPieza,
                hostUsado ?? datos.Host,
                textoTipo);

            totalBarrasFisicas +=
                curvasPorBarra.Count;
        }

        return totalBarrasFisicas;
    }

    // =========================================================
    // V11.10 - REGLA NATIVA PARA FREE FORM SET
    // =========================================================
    private bool AplicarReglaGrupoAFreeFormMYG(
        Rebar rebar,
        AceroVigaReglaGrupoLongitudinal regla,
        int cantidad,
        double espaciado)
    {
        if (rebar == null)
            return false;

        int numero = Math.Max(1, Math.Min(1002, cantidad));
        double separacion = Math.Max(Tol, espaciado);

        try
        {
            RebarFreeFormAccessor accessor =
                rebar.GetFreeFormAccessor();

            if (accessor == null)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "RebarFreeFormAccessor",
                    "GetFreeFormAccessor devolvió null. RebarId=" + rebar.Id + ".");
                return false;
            }

            // =========================================================
            // V11.50 - FREEFORM CREADO DIRECTAMENTE NO TIENE SERVER GUID
            // =========================================================
            // Rebar.CreateFreeForm(doc, type, host, curvasPorBarra, ...) ya
            // recibe UNA cadena completa por cada posición de barra que debe
            // existir. Por tanto el conjunto geométrico ya está completamente
            // definido y NO necesita SetLayoutAsFixedNumber/MaximumSpacing.
            //
            // En Revit 2027 esos métodos del RebarFreeFormAccessor exigen que
            // el Rebar esté conectado a un Free Form Rebar Server válido. Los
            // FreeForm creados directamente por esta herramienta no tienen ese
            // Server GUID; intentar aplicar la regla lanza:
            //   "This RebarFreeFormAccessor Rebar doesn't contain a valid server GUID"
            // y la versión V11.49 terminaba borrando un Rebar que YA estaba
            // correctamente creado. Como además se prohibió el fallback
            // Individual para series multihost, el resultado era que faltaban
            // grupos completos.
            //
            // Si NO hay servidor válido, se conserva el único Rebar FreeForm
            // que ya contiene exactamente curvasPorBarra.Count posiciones.
            // Esto NO crea barras individuales adicionales y evita perder el
            // conjunto por una operación de layout que la API no permite.
            bool tieneServidorValido = false;

            try
            {
                tieneServidorValido = accessor.HasValidServer();
            }
            catch
            {
                tieneServidorValido = false;
            }

            if (!tieneServidorValido)
            {
                return true;
            }

            if (regla ==
                AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
            {
                accessor.SetLayoutAsMaximumSpacing(
                    separacion);
            }
            else
            {
                accessor.SetLayoutAsFixedNumber(
                    numero);
            }

            return true;
        }
        catch (Exception ex)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Aplicar regla al FreeForm SET",
                "RebarId=" + rebar.Id +
                "; regla=" + regla +
                "; cantidad=" + numero +
                "; espaciado=" + FormatearLongitudDiagnosticoMYG(separacion) + ".",
                ex);
            return false;
        }
    }


    private int CrearBarraLongitudinalManualIndividualMYG(
        Document doc,
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaBarraLongitudinal2D definicion,
        double recubrimiento,
        double diametroEstribo,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra,
        List<SegmentoAceroLongitudinal> segmentosAcumuladosEstacionesMYG = null,
        string textoTipoForzadoMYG = null)
    {
        if (definicion == null || definicion.TipoBarra == null ||
            definicion.Punto == null)
        {
            return 0;
        }

        RebarBarType tipo = definicion.TipoBarra;
        double diametro = ObtenerDiametroBarra(tipo);
        double offset = recubrimiento + diametroEstribo +
            diametro * 0.5;

        double y = 0.0;
        double z = 0.0;

        bool posicionObtenida = false;
        if (definicion.UsarPosicionExactaSeccion &&
            definicion.PuntoSeccionReal != null)
        {
            posicionObtenida =
                TryObtenerPosicionLongitudinalManualEnSeccionRealMYG(
                    datos,
                    definicion,
                    offset,
                    out y,
                    out z);
        }

        if (!posicionObtenida)
        {
            posicionObtenida =
                TryObtenerPosicionLongitudinalDesdeGuiaRealMYG(
                    datos,
                    diseno,
                    definicion,
                    offset,
                    out y,
                    out z);
        }

        if (!posicionObtenida)
        {
            posicionObtenida =
                TryObtenerPosicionLongitudinalManualEnSeccionRealMYG(
                    datos,
                    definicion,
                    offset,
                    out y,
                    out z);
        }

        if (!posicionObtenida)
            return 0;

        if (!definicion.UsarPosicionExactaSeccion)
        {
            AjustarPrimeraCapaTangenteAEstriboMYG(
                datos,
                diseno,
                definicion,
                diametro,
                diametroEstribo,
                recubrimiento,
                ref y,
                ref z);
        }

        int tipoRuta;
        string textoTipo;
        ObtenerClasificacionCapaManualMYG(
            definicion,
            out tipoRuta,
            out textoTipo);

        if (!string.IsNullOrWhiteSpace(textoTipoForzadoMYG))
            textoTipo = textoTipoForzadoMYG;

        double longitudEmpalme = tipoRuta > 0
            ? longitudEmpalmeSuperior
            : (tipoRuta < 0
                ? longitudEmpalmeInferior
                : longitudEmpalmeCentral);

        double xInicioManual;
        double xFinManual;

        ObtenerIntervaloLongitudinalManualConDesarrollosMYG(
            datos,
            desarrolloInicioHabilitado,
            longitudDesarrolloInicio,
            desarrolloFinHabilitado,
            longitudDesarrolloFin,
            out xInicioManual,
            out xFinManual);

        if (xFinManual <= xInicioManual + Tol)
            return 0;

        List<SegmentoAceroLongitudinal> segmentos;

        if (segmentosAcumuladosEstacionesMYG != null &&
            segmentosAcumuladosEstacionesMYG.Count > 0)
        {
            segmentos = RecortarSegmentosAcumuladosAlLoteMYG(
                segmentosAcumuladosEstacionesMYG,
                xInicioManual,
                xFinManual);
        }
        else
        {
            segmentos =
                ConstruirSegmentosLongitudinales(
                    datos,
                    tipoRuta,
                    xInicioManual,
                    xFinManual,
                    crearEmpalmes,
                    longitudBarra,
                    longitudEmpalme,
                    0.0,
                    0.0,
                    diametro,
                    tipo);
        }

        if (segmentos == null || segmentos.Count == 0)
        {
            // V11.9: si no existe un empalme válido, no crear una barra
            // continua que contradiga la configuración del usuario.
            return 0;
        }

        double desfaseEmpalme =
            ObtenerDesfaseEmpalmeCaraACara(diametro);
        XYZ direccionDesfase = tipoRuta > 0
            ? datos.ZAxis.Multiply(-1.0)
            : (tipoRuta < 0 ? datos.ZAxis : datos.YAxis);
        XYZ direccionGancho = direccionDesfase;
        int contador = 0;

        foreach (SegmentoAceroLongitudinal seg in segmentos)
        {
            if (seg == null || seg.XFin <= seg.XInicio + Tol)
                continue;

            List<XYZ> puntos;

            if (EsSerieMultiHostRectaContinuaMYG(datos))
            {
                puntos = ConstruirPuntosBarraConEmpalmeOriginal(
                    datos,
                    seg,
                    y,
                    z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfase,
                    desfaseEmpalme);
            }
            else
            {
                puntos = ConstruirPuntosBarraConEmpalme(
                    datos,
                    seg,
                    y,
                    z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfase,
                    desfaseEmpalme,
                    offset,
                    true);
            }

            if (puntos == null || puntos.Count < 2)
            {
                puntos = ConstruirPuntosBarraConEmpalmeOriginal(
                    datos,
                    seg,
                    y,
                    z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfase,
                    desfaseEmpalme);
            }

            bool usarGanchoInicio = ganchoInicio && seg.EsPrimero;
            bool usarGanchoFin = ganchoFin && seg.EsUltimo;

            int creadas =
                CrearRebarLongitudinalConNumeroFijoPiezaContinuaMYG(
                    doc,
                    datos,
                    seg,
                    tipo,
                    datos.YAxis,
                    puntos,
                    usarGanchoInicio,
                    longitudGanchoInicio,
                    usarGanchoFin,
                    longitudGanchoFin,
                    direccionGancho,
                    1,
                    0.0,
                    textoTipo);

            if (creadas == 0)
            {
                creadas =
                    CrearRebarLongitudinalConNumeroFijoPiezaContinuaMYG(
                        doc,
                        datos,
                        seg,
                        tipo,
                        datos.YAxis.Multiply(-1.0),
                        puntos,
                        usarGanchoInicio,
                        longitudGanchoInicio,
                        usarGanchoFin,
                        longitudGanchoFin,
                        direccionGancho,
                        1,
                        0.0,
                        textoTipo);
            }

            contador += creadas;
        }

        return contador;
    }


    // =========================================================
    // V10.4 - RECONSTRUCCIÓN POR GUÍA + DESFASE NORMAL
    // =========================================================
    private bool TryObtenerPosicionLongitudinalDesdeGuiaRealMYG(
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaBarraLongitudinal2D definicion,
        double offsetCentroDesdeConcreto,
        out double y,
        out double z)
    {
        y = 0.0;
        z = 0.0;

        if (datos == null || diseno == null || definicion == null ||
            string.IsNullOrWhiteSpace(definicion.GuiaCapaId) ||
            definicion.ParametroSobreGuia < 0.0 ||
            diseno.GuiasCapasLongitudinales == null)
        {
            return false;
        }

        AceroVigaGuiaCapaLongitudinal2D guia =
            diseno.GuiasCapasLongitudinales.FirstOrDefault(x =>
                x != null && string.Equals(
                    x.Id,
                    definicion.GuiaCapaId,
                    StringComparison.Ordinal));

        if (guia == null || guia.PuntosGuia == null ||
            guia.PuntosGuia.Count < 2)
        {
            return false;
        }

        List<PuntoSeccionYZ> contornoConcreto =
            ObtenerPoligonoSeccionRealYZ(datos);
        if (contornoConcreto == null || contornoConcreto.Count < 3)
            return false;

        List<PuntoSeccionYZ> contornoUtil =
            ObtenerPoligonoOffsetInteriorYZ(
                contornoConcreto,
                Math.Max(0.0, offsetCentroDesdeConcreto));
        if (contornoUtil == null || contornoUtil.Count < 3)
            return false;

        List<PuntoSeccionYZ> puntosGuia = new List<PuntoSeccionYZ>();

        // V10.6: la guía estable se reconstruye desde la caja del concreto,
        // no desde una caja útil que cambia con el diámetro longitudinal.
        IList<AceroVigaPuntoNormalizado> puntosNormalizados =
            guia.PuntosGuiaSeccionReal != null &&
            guia.PuntosGuiaSeccionReal.Count >= 2
                ? (IList<AceroVigaPuntoNormalizado>)
                    guia.PuntosGuiaSeccionReal
                : guia.PuntosGuia;

        List<PuntoSeccionYZ> cajaReferencia =
            guia.PuntosGuiaSeccionReal != null &&
            guia.PuntosGuiaSeccionReal.Count >= 2
                ? contornoConcreto
                : contornoUtil;

        double yMin = cajaReferencia.Min(x => x.Y);
        double yMax = cajaReferencia.Max(x => x.Y);
        double zMin = cajaReferencia.Min(x => x.Z);
        double zMax = cajaReferencia.Max(x => x.Z);
        if (yMax <= yMin + Tol || zMax <= zMin + Tol)
            return false;

        foreach (AceroVigaPuntoNormalizado p in puntosNormalizados)
        {
            if (p == null)
                continue;

            double u = Math.Max(0.0, Math.Min(1.0, p.U));
            double v = Math.Max(0.0, Math.Min(1.0, p.V));
            PuntoSeccionYZ nuevo = new PuntoSeccionYZ(
                yMin + (yMax - yMin) * u,
                zMin + (zMax - zMin) * v);

            if (puntosGuia.Count == 0 ||
                DistanciaYZMYG(
                    puntosGuia[puntosGuia.Count - 1],
                    nuevo) > Tol)
            {
                puntosGuia.Add(nuevo);
            }
        }

        if (puntosGuia.Count < 2)
            return false;

        PuntoSeccionYZ puntoGuia;
        double normalY;
        double normalZ;
        if (!TryPuntoYNormalInteriorEnCadenaGuiaMYG(
                puntosGuia,
                contornoConcreto,
                definicion.ParametroSobreGuia,
                out puntoGuia,
                out normalY,
                out normalZ))
        {
            return false;
        }

        double desfase = UnitUtils.ConvertToInternalUnits(
            definicion.DesfaseNormalGuiaMm,
            UnitTypeId.Millimeters);

        double yDeseado = puntoGuia.Y + normalY * desfase;
        double zDeseado = puntoGuia.Z + normalZ * desfase;

        AjustarPuntoExactoAlContornoUtilMYG(
            contornoUtil,
            yDeseado,
            zDeseado,
            out y,
            out z);

        return true;
    }

    private bool TryPuntoYNormalInteriorEnCadenaGuiaMYG(
        List<PuntoSeccionYZ> puntos,
        List<PuntoSeccionYZ> poligonoInterior,
        double parametro,
        out PuntoSeccionYZ punto,
        out double normalY,
        out double normalZ)
    {
        punto = null;
        normalY = 0.0;
        normalZ = 0.0;

        if (puntos == null || puntos.Count < 2 ||
            poligonoInterior == null || poligonoInterior.Count < 3)
        {
            return false;
        }

        parametro = Math.Max(0.0, Math.Min(1.0, parametro));
        double longitudTotal = 0.0;
        for (int i = 1; i < puntos.Count; i++)
            longitudTotal += DistanciaYZMYG(puntos[i - 1], puntos[i]);
        if (longitudTotal <= Tol)
            return false;

        double objetivo = longitudTotal * parametro;
        double acumulado = 0.0;
        double centroY = poligonoInterior.Average(x => x.Y);
        double centroZ = poligonoInterior.Average(x => x.Z);

        for (int i = 1; i < puntos.Count; i++)
        {
            PuntoSeccionYZ a = puntos[i - 1];
            PuntoSeccionYZ b = puntos[i];
            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longitud = Math.Sqrt(dy * dy + dz * dz);
            if (longitud <= Tol)
                continue;

            if (acumulado + longitud >= objetivo || i == puntos.Count - 1)
            {
                double t = (objetivo - acumulado) / longitud;
                t = Math.Max(0.0, Math.Min(1.0, t));
                punto = new PuntoSeccionYZ(
                    a.Y + dy * t,
                    a.Z + dz * t);

                normalY = -dz / longitud;
                normalZ = dy / longitud;
                double medioY = (a.Y + b.Y) * 0.5;
                double medioZ = (a.Z + b.Z) * 0.5;
                double haciaCentro =
                    (centroY - medioY) * normalY +
                    (centroZ - medioZ) * normalZ;
                if (haciaCentro < 0.0)
                {
                    normalY = -normalY;
                    normalZ = -normalZ;
                }
                return true;
            }

            acumulado += longitud;
        }

        return false;
    }

    private double DistanciaYZMYG(PuntoSeccionYZ a, PuntoSeccionYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;
        double dy = b.Y - a.Y;
        double dz = b.Z - a.Z;
        return Math.Sqrt(dy * dy + dz * dz);
    }

    // =========================================================
    // V10.3 - TANGENCIA REAL ENTRE LONGITUDINAL Y ESTRIBO
    // =========================================================
    // Para la primera capa superior/inferior no se usa únicamente un offset
    // independiente del concreto. Se reconstruye el eje del estribo realmente
    // configurado y el centro longitudinal se coloca hacia el interior a una
    // distancia igual a: radio estribo + radio longitudinal.
    // Esto garantiza contacto geométrico aun cuando la cara sea inclinada.
    private void AjustarPrimeraCapaTangenteAEstriboMYG(
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        AceroVigaBarraLongitudinal2D definicion,
        double diametroLongitudinal,
        double diametroEstriboRespaldo,
        double recubrimientoLongitudinal,
        ref double y,
        ref double z)
    {
        if (datos == null || definicion == null || diseno == null)
            return;

        bool superior =
            definicion.TipoCapa == AceroVigaTipoCapaLongitudinal.Superior &&
            definicion.NumeroCapa == 1;
        bool inferior =
            definicion.TipoCapa == AceroVigaTipoCapaLongitudinal.Inferior &&
            definicion.NumeroCapa == 1;

        // Solo la capa 1 debe quedar tangente al estribo. Las capas 2 a 4
        // conservan la separación libre definida por el usuario.
        if (!superior && !inferior)
            return;

        double diametroEstriboReal;
        List<PuntoSeccionYZ> recorridoEstribo =
            ObtenerRecorridoEstriboReferenciaRealYZMYG(
                datos,
                diseno,
                diametroEstriboRespaldo,
                out diametroEstriboReal);

        if (recorridoEstribo == null || recorridoEstribo.Count < 2)
            return;

        if (diametroEstriboReal <= Tol)
            diametroEstriboReal = Math.Max(0.0, diametroEstriboRespaldo);

        double distanciaTangencia =
            Math.Max(0.0, diametroLongitudinal) * 0.5 +
            Math.Max(0.0, diametroEstriboReal) * 0.5;

        if (distanciaTangencia <= Tol)
            return;

        List<PuntoSeccionYZ> contornoConcreto =
            ObtenerPoligonoSeccionRealYZ(datos);
        if (contornoConcreto == null || contornoConcreto.Count < 3)
            return;

        PuntoSeccionYZ puntoPie;
        double normalY;
        double normalZ;

        if (!TryObtenerPieYNormalInteriorEstriboMYG(
                recorridoEstribo,
                contornoConcreto,
                y,
                z,
                superior,
                inferior,
                out puntoPie,
                out normalY,
                out normalZ))
        {
            return;
        }

        double yCandidato = puntoPie.Y + normalY * distanciaTangencia;
        double zCandidato = puntoPie.Z + normalZ * distanciaTangencia;

        // V10.6: el punto ya fue obtenido desde el eje real del estribo y
        // la suma de radios. Volver a proyectarlo contra un segundo polígono
        // offset introducía exactamente la separación visible en las caras
        // inclinadas. Solo se corrige si por tolerancia quedó fuera del concreto.
        if (!PuntoDentroOEnBordePoligonoYZMYG(
                contornoConcreto,
                yCandidato,
                zCandidato,
                UnitUtils.ConvertToInternalUnits(
                    0.10,
                    UnitTypeId.Millimeters)))
        {
            double yAjustado;
            double zAjustado;
            AjustarPuntoExactoAlContornoUtilMYG(
                contornoConcreto,
                yCandidato,
                zCandidato,
                out yAjustado,
                out zAjustado);
            yCandidato = yAjustado;
            zCandidato = zAjustado;
        }

        y = yCandidato;
        z = zCandidato;
    }

    private List<PuntoSeccionYZ> ObtenerRecorridoEstriboReferenciaRealYZMYG(
        DatosSerieVigas datos,
        AceroVigaDisenoSeccion diseno,
        double diametroEstriboRespaldo,
        out double diametroEstriboReal)
    {
        diametroEstriboReal = Math.Max(0.0, diametroEstriboRespaldo);
        List<PuntoSeccionYZ> vacio = new List<PuntoSeccionYZ>();

        if (datos == null || diseno == null)
            return vacio;

        List<PuntoSeccionYZ> contornoConcreto =
            ObtenerPoligonoSeccionRealYZ(datos);
        if (contornoConcreto == null || contornoConcreto.Count < 3)
            return vacio;

        AceroVigaEstribo2D referencia = null;
        if (diseno.Estribos != null)
        {
            referencia = diseno.Estribos
                .Where(x =>
                    x != null &&
                    x.Cerrado &&
                    (x.TipoBarra != null || x.DiametroMm > 0.0))
                .OrderByDescending(x => x.UsarContornoOffsetAutomatico)
                .ThenByDescending(x => x.Puntos != null ? x.Puntos.Count : 0)
                .FirstOrDefault();
        }

        if (referencia != null)
        {
            if (referencia.TipoBarra != null)
            {
                double d = ObtenerDiametroBarra(referencia.TipoBarra);
                if (d > Tol)
                    diametroEstriboReal = d;
            }
            else if (referencia.DiametroMm > 0.0)
            {
                diametroEstriboReal = UnitUtils.ConvertToInternalUnits(
                    referencia.DiametroMm,
                    UnitTypeId.Millimeters);
            }
        }

        double recubrimientoEstribosCm =
            diseno.RecubrimientoEstribosCm > 0.0
                ? diseno.RecubrimientoEstribosCm
                : diseno.RecubrimientoCm;
        double recubrimientoEstribos = UnitUtils.ConvertToInternalUnits(
            Math.Max(0.0, recubrimientoEstribosCm),
            UnitTypeId.Centimeters);
        double offsetEjeEstribo = recubrimientoEstribos +
            Math.Max(0.0, diametroEstriboReal) * 0.5;

        List<PuntoSeccionYZ> contornoEje =
            ObtenerPoligonoOffsetInteriorYZ(
                contornoConcreto,
                offsetEjeEstribo);

        if (contornoEje == null || contornoEje.Count < 3)
            return vacio;

        if (referencia == null ||
            referencia.UsarContornoOffsetAutomatico ||
            referencia.Puntos == null ||
            referencia.Puntos.Count < 3)
        {
            return contornoEje;
        }

        double yMin = contornoEje.Min(x => x.Y);
        double yMax = contornoEje.Max(x => x.Y);
        double zMin = contornoEje.Min(x => x.Z);
        double zMax = contornoEje.Max(x => x.Z);

        if (yMax <= yMin + Tol || zMax <= zMin + Tol)
            return contornoEje;

        List<PuntoSeccionYZ> manual = new List<PuntoSeccionYZ>();
        foreach (AceroVigaPuntoNormalizado p in referencia.Puntos)
        {
            if (p == null)
                continue;

            double u = Math.Max(0.0, Math.Min(1.0, p.U));
            double v = Math.Max(0.0, Math.Min(1.0, p.V));
            manual.Add(new PuntoSeccionYZ(
                yMin + (yMax - yMin) * u,
                zMin + (zMax - zMin) * v));
        }

        return manual.Count >= 3 ? manual : contornoEje;
    }

    private bool TryObtenerPieYNormalInteriorEstriboMYG(
        List<PuntoSeccionYZ> recorrido,
        List<PuntoSeccionYZ> contornoConcreto,
        double yObjetivo,
        double zObjetivo,
        bool superior,
        bool inferior,
        out PuntoSeccionYZ pie,
        out double normalY,
        out double normalZ)
    {
        pie = null;
        normalY = 0.0;
        normalZ = 0.0;

        if (recorrido == null || recorrido.Count < 2 ||
            contornoConcreto == null || contornoConcreto.Count < 3)
        {
            return false;
        }

        double mejor = double.MaxValue;
        double yCentro = contornoConcreto.Average(x => x.Y);
        double zCentro = contornoConcreto.Average(x => x.Z);

        int cantidadSegmentos = recorrido.Count;
        for (int i = 0; i < cantidadSegmentos; i++)
        {
            PuntoSeccionYZ a = recorrido[i];
            PuntoSeccionYZ b = recorrido[(i + 1) % cantidadSegmentos];
            if (a == null || b == null)
                continue;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double l2 = dy * dy + dz * dz;
            if (l2 <= Tol * Tol)
                continue;

            double longitud = Math.Sqrt(l2);
            double n1Y = -dz / longitud;
            double n1Z = dy / longitud;
            double n2Y = -n1Y;
            double n2Z = -n1Z;

            double yMed = (a.Y + b.Y) * 0.5;
            double zMed = (a.Z + b.Z) * 0.5;
            double dot1 = (yCentro - yMed) * n1Y +
                (zCentro - zMed) * n1Z;
            double dot2 = (yCentro - yMed) * n2Y +
                (zCentro - zMed) * n2Z;

            double nY = dot1 >= dot2 ? n1Y : n2Y;
            double nZ = dot1 >= dot2 ? n1Z : n2Z;

            // Para Superior se priorizan segmentos cuya normal interior baja;
            // para Inferior, segmentos cuya normal interior sube. Esto evita que
            // una barra cercana a una esquina se pegue al lateral equivocado.
            if (superior && nZ > -0.10)
                continue;
            if (inferior && nZ < 0.10)
                continue;

            double t = ((yObjetivo - a.Y) * dy +
                (zObjetivo - a.Z) * dz) / l2;
            t = Math.Max(0.0, Math.Min(1.0, t));
            double py = a.Y + dy * t;
            double pz = a.Z + dz * t;

            double ddy = yObjetivo - py;
            double ddz = zObjetivo - pz;
            double d2 = ddy * ddy + ddz * ddz;

            if (d2 < mejor)
            {
                mejor = d2;
                pie = new PuntoSeccionYZ(py, pz);
                normalY = nY;
                normalZ = nZ;
            }
        }

        return pie != null;
    }

    private bool PuntoDentroOEnBordePoligonoYZMYG(
        List<PuntoSeccionYZ> poligono,
        double y,
        double z,
        double tolerancia)
    {
        if (poligono == null || poligono.Count < 3)
            return false;

        if (PuntoDentroPoligonoYZ(poligono, y, z))
            return true;

        double tol2 = Math.Max(Tol, tolerancia);
        tol2 *= tol2;

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoSeccionYZ a = poligono[i];
            PuntoSeccionYZ b = poligono[(i + 1) % poligono.Count];
            if (a == null || b == null)
                continue;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double l2 = dy * dy + dz * dz;
            double t = 0.0;
            if (l2 > Tol * Tol)
            {
                t = ((y - a.Y) * dy + (z - a.Z) * dz) / l2;
                t = Math.Max(0.0, Math.Min(1.0, t));
            }

            double py = a.Y + dy * t;
            double pz = a.Z + dz * t;
            double ddy = y - py;
            double ddz = z - pz;
            if (ddy * ddy + ddz * ddz <= tol2)
                return true;
        }

        return false;
    }

    private bool TryObtenerPosicionLongitudinalManualEnSeccionRealMYG(
        DatosSerieVigas datos,
        AceroVigaBarraLongitudinal2D definicion,
        double offsetCentroDesdeConcreto,
        out double y,
        out double z)
    {
        y = 0.0;
        z = 0.0;

        if (datos == null || definicion == null || definicion.Punto == null)
            return false;

        List<PuntoSeccionYZ> contornoConcreto =
            ObtenerPoligonoSeccionRealYZ(datos);

        if (contornoConcreto == null || contornoConcreto.Count < 3)
            return false;

        List<PuntoSeccionYZ> contornoUtil =
            ObtenerPoligonoOffsetInteriorYZ(
                contornoConcreto,
                Math.Max(0.0, offsetCentroDesdeConcreto));

        if (contornoUtil == null || contornoUtil.Count < 3)
        {
            double yMinRespaldo = -Math.Max(datos.Ancho, Tol) * 0.5 +
                Math.Max(0.0, offsetCentroDesdeConcreto);
            double yMaxRespaldo = Math.Max(datos.Ancho, Tol) * 0.5 -
                Math.Max(0.0, offsetCentroDesdeConcreto);
            double zMinRespaldo = -Math.Max(datos.Alto, Tol) * 0.5 +
                Math.Max(0.0, offsetCentroDesdeConcreto);
            double zMaxRespaldo = Math.Max(datos.Alto, Tol) * 0.5 -
                Math.Max(0.0, offsetCentroDesdeConcreto);

            if (yMaxRespaldo <= yMinRespaldo + Tol ||
                zMaxRespaldo <= zMinRespaldo + Tol)
            {
                return false;
            }

            contornoUtil = new List<PuntoSeccionYZ>()
            {
                new PuntoSeccionYZ(yMinRespaldo, zMinRespaldo),
                new PuntoSeccionYZ(yMaxRespaldo, zMinRespaldo),
                new PuntoSeccionYZ(yMaxRespaldo, zMaxRespaldo),
                new PuntoSeccionYZ(yMinRespaldo, zMaxRespaldo)
            };
        }

        double yDeseado;
        double zDeseado;

        // V10.2: la referencia estable se toma de la caja del CONCRETO.
        // Así se reproduce exactamente el centro visto en el editor, incluso
        // sobre una cara superior inclinada. No se vuelve a aplicar el offset
        // mediante una segunda normalización que bajaba los aceros superiores.
        if (definicion.PuntoSeccionReal != null)
        {
            double yMinConcreto = contornoConcreto.Min(x => x.Y);
            double yMaxConcreto = contornoConcreto.Max(x => x.Y);
            double zMinConcreto = contornoConcreto.Min(x => x.Z);
            double zMaxConcreto = contornoConcreto.Max(x => x.Z);

            if (yMaxConcreto <= yMinConcreto + Tol ||
                zMaxConcreto <= zMinConcreto + Tol)
            {
                return false;
            }

            double uSeccion = Math.Max(
                0.0,
                Math.Min(1.0, definicion.PuntoSeccionReal.U));
            double vSeccion = Math.Max(
                0.0,
                Math.Min(1.0, definicion.PuntoSeccionReal.V));

            yDeseado = yMinConcreto +
                (yMaxConcreto - yMinConcreto) * uSeccion;
            zDeseado = zMinConcreto +
                (zMaxConcreto - zMinConcreto) * vSeccion;
        }
        else
        {
            // Respaldo para diseños anteriores a V10.2.
            double yMin = contornoUtil.Min(x => x.Y);
            double yMax = contornoUtil.Max(x => x.Y);
            double zMin = contornoUtil.Min(x => x.Z);
            double zMax = contornoUtil.Max(x => x.Z);

            if (yMax <= yMin + Tol || zMax <= zMin + Tol)
                return false;

            double u = Math.Max(0.0, Math.Min(1.0, definicion.Punto.U));
            double v = Math.Max(0.0, Math.Min(1.0, definicion.Punto.V));

            yDeseado = yMin + (yMax - yMin) * u;
            zDeseado = zMin + (zMax - zMin) * v;
        }

        AjustarPuntoExactoAlContornoUtilMYG(
            contornoUtil,
            yDeseado,
            zDeseado,
            out y,
            out z);

        return true;
    }

    private void AjustarPuntoExactoAlContornoUtilMYG(
        List<PuntoSeccionYZ> contorno,
        double yDeseado,
        double zDeseado,
        out double y,
        out double z)
    {
        y = yDeseado;
        z = zDeseado;

        if (contorno == null || contorno.Count < 3)
            return;

        if (PuntoDentroPoligonoYZ(contorno, yDeseado, zDeseado))
            return;

        PuntoSeccionYZ masCercano = null;
        double mejorDistancia2 = double.MaxValue;

        for (int i = 0; i < contorno.Count; i++)
        {
            PuntoSeccionYZ a = contorno[i];
            PuntoSeccionYZ b = contorno[(i + 1) % contorno.Count];

            if (a == null || b == null)
                continue;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longitud2 = (dy * dy) + (dz * dz);
            double t = 0.0;

            if (longitud2 > Tol * Tol)
            {
                t = ((yDeseado - a.Y) * dy +
                     (zDeseado - a.Z) * dz) / longitud2;
                t = Math.Max(0.0, Math.Min(1.0, t));
            }

            double py = a.Y + dy * t;
            double pz = a.Z + dz * t;
            double ddy = yDeseado - py;
            double ddz = zDeseado - pz;
            double distancia2 = (ddy * ddy) + (ddz * ddz);

            if (distancia2 < mejorDistancia2)
            {
                mejorDistancia2 = distancia2;
                masCercano = new PuntoSeccionYZ(py, pz);
            }
        }

        if (masCercano == null)
        {
            AjustarPuntoManualDentroDeContornoMYG(
                contorno,
                yDeseado,
                zDeseado,
                out y,
                out z);
            return;
        }

        // Se introduce solo una tolerancia microscópica hacia el interior para
        // evitar que Revit considere el centro exactamente fuera por redondeo.
        double yCentro = contorno.Average(x => x.Y);
        double zCentro = contorno.Average(x => x.Z);
        double vy = yCentro - masCercano.Y;
        double vz = zCentro - masCercano.Z;
        double longitud = Math.Sqrt((vy * vy) + (vz * vz));
        double entrada = UnitUtils.ConvertToInternalUnits(
            0.05,
            UnitTypeId.Millimeters);

        if (longitud > Tol)
        {
            y = masCercano.Y + (vy / longitud) * entrada;
            z = masCercano.Z + (vz / longitud) * entrada;
        }
        else
        {
            y = masCercano.Y;
            z = masCercano.Z;
        }
    }

    private void AjustarPuntoManualDentroDeContornoMYG(
        List<PuntoSeccionYZ> contorno,
        double yDeseado,
        double zDeseado,
        out double y,
        out double z)
    {
        y = yDeseado;
        z = zDeseado;

        if (contorno == null || contorno.Count < 3)
            return;

        if (PuntoDentroPoligonoYZ(contorno, yDeseado, zDeseado))
            return;

        double yCentro = contorno.Average(x => x.Y);
        double zCentro = contorno.Average(x => x.Z);

        if (!PuntoDentroPoligonoYZ(contorno, yCentro, zCentro))
        {
            yCentro = (contorno.Min(x => x.Y) + contorno.Max(x => x.Y)) * 0.5;
            zCentro = (contorno.Min(x => x.Z) + contorno.Max(x => x.Z)) * 0.5;
        }

        double inferior = 0.0;
        double superior = 1.0;

        for (int i = 0; i < 48; i++)
        {
            double factor = (inferior + superior) * 0.5;
            double yPrueba = yCentro + (yDeseado - yCentro) * factor;
            double zPrueba = zCentro + (zDeseado - zCentro) * factor;

            if (PuntoDentroPoligonoYZ(contorno, yPrueba, zPrueba))
                inferior = factor;
            else
                superior = factor;
        }

        double factorSeguro = Math.Max(0.0, inferior - 1e-5);
        y = yCentro + (yDeseado - yCentro) * factorSeguro;
        z = zCentro + (zDeseado - zCentro) * factorSeguro;
    }

    private int CrearAceroLongitudinalManualEnVigasCurvasMYG(
        Document doc,
        List<Element> vigas,
        AceroVigaDisenoSeccion diseno,
        double recubrimiento,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        if (doc == null || vigas == null || diseno == null ||
            diseno.Longitudinales == null)
        {
            return 0;
        }

        int contador = 0;
        double diametroEstribo = ObtenerDiametroEstriboReferenciaDisenoManualMYG(diseno);

        foreach (Element host in vigas)
        {
            if (host == null)
                continue;

            if (!EsElementoVigaCurvaMYG(host))
            {
                DatosSerieVigas recta = ObtenerDatosSerieVigas(
                    doc,
                    new List<Element>() { host });
                contador += CrearAceroLongitudinalManualEnSerieMYG(
                    doc,
                    recta,
                    diseno,
                    recubrimiento,
                    false,
                    0.0,
                    false,
                    0.0,
                    desarrolloInicioHabilitado,
                    longitudDesarrolloInicio,
                    desarrolloFinHabilitado,
                    longitudDesarrolloFin,
                    crearEmpalmes,
                    longitudEmpalmeSuperior,
                    longitudEmpalmeInferior,
                    longitudEmpalmeCentral,
                    longitudBarra);
                continue;
            }

            DatosVigaCurvaLongitudinalMYG datos =
                ObtenerDatosVigaCurvaLongitudinalMYG(doc, host);
            if (datos == null)
                continue;

            DatosSerieVigas serie = CrearDatosSerieParaCurvaLongitudinalMYG(datos);
            if (serie == null)
                continue;

            foreach (AceroVigaBarraLongitudinal2D definicion in diseno.Longitudinales)
            {
                if (definicion == null || definicion.TipoBarra == null ||
                    definicion.Punto == null)
                {
                    continue;
                }

                RebarBarType tipo = definicion.TipoBarra;
                double diametro = ObtenerDiametroBarra(tipo);
                double offset = recubrimiento + diametroEstribo + diametro * 0.5;

                double y;
                double z;

                if (!TryObtenerPosicionLongitudinalManualEnSeccionRealMYG(
                    serie,
                    definicion,
                    offset,
                    out y,
                    out z))
                {
                    continue;
                }

                AjustarPrimeraCapaTangenteAEstriboMYG(
                    serie,
                    diseno,
                    definicion,
                    diametro,
                    diametroEstribo,
                    recubrimiento,
                    ref y,
                    ref z);

                int tipoRuta;
                string textoTipo;
                ObtenerClasificacionCapaManualMYG(
                    definicion,
                    out tipoRuta,
                    out textoTipo);
                double lap = tipoRuta > 0
                    ? longitudEmpalmeSuperior
                    : (tipoRuta < 0 ? longitudEmpalmeInferior : longitudEmpalmeCentral);

                double xInicioManual;
                double xFinManual;

                ObtenerIntervaloLongitudinalManualConDesarrollosMYG(
                    serie,
                    desarrolloInicioHabilitado,
                    longitudDesarrolloInicio,
                    desarrolloFinHabilitado,
                    longitudDesarrolloFin,
                    out xInicioManual,
                    out xFinManual);

                if (xFinManual <= xInicioManual + Tol)
                    continue;

                List<SegmentoAceroLongitudinal> segmentos =
                    ConstruirSegmentosLongitudinales(
                        serie,
                        tipoRuta,
                        xInicioManual,
                        xFinManual,
                        crearEmpalmes,
                        longitudBarra,
                        lap,
                        0.0,
                        0.0,
                        diametro,
                        tipo);

                if (segmentos == null || segmentos.Count == 0)
                {
                    // V11.9: mantener coherencia con la rama recta.
                    continue;
                }

                contador += CrearBarraCurvaPorSegmentosMYG(
                    doc,
                    datos,
                    tipo,
                    y,
                    z,
                    segmentos,
                    textoTipo);
            }
        }

        return contador;
    }

    private int CrearAceroLongitudinalEnSerie(
        Document doc,
        DatosSerieVigas datos,
        RebarBarType tipoSuperior,
        int cantidadSuperior,
        RebarBarType tipoInferior,
        int cantidadInferior,
        bool crearAceroCentral,
        RebarBarType tipoCentral,
        double recubrimiento,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalmeSuperior,
        double longitudEmpalmeInferior,
        double longitudEmpalmeCentral,
        double longitudBarra)
    {
        if (datos == null)
            return 0;

        if (datos.Host == null)
            return 0;

        if (datos.LongitudTotal <= Tol)
            return 0;

        if (datos.Ancho <= Tol || datos.Alto <= Tol)
            return 0;

        RebarHostData hostData = RebarHostData.GetRebarHostData(datos.Host);

        if (hostData == null)
            return 0;

        double diametroSuperior = ObtenerDiametroBarra(tipoSuperior);
        double diametroInferior = ObtenerDiametroBarra(tipoInferior);
        double diametroCentral = ObtenerDiametroBarra(tipoCentral);

        int contador = 0;

        List<ConfiguracionCapaLongitudinal> capasSuperiores = ConstruirConfiguracionCapasLongitudinales(
            true,
            tipoSuperior,
            cantidadSuperior,
            recubrimiento,
            crearEmpalmes);

        List<ConfiguracionCapaLongitudinal> capasInferiores = ConstruirConfiguracionCapasLongitudinales(
            false,
            tipoInferior,
            cantidadInferior,
            recubrimiento,
            crearEmpalmes);

        double inicioUtilPaquete = 0.0;
        double finUtilPaquete = datos.LongitudTotal;

        CalcularIntervaloUtilPaqueteLongitudinalMYG(
            datos,
            capasSuperiores,
            capasInferiores,
            crearAceroCentral,
            tipoCentral,
            recubrimiento,
            out inicioUtilPaquete,
            out finUtilPaquete);

        datos.InicioUtilArmaduraSerie = Math.Max(0.0, inicioUtilPaquete);
        datos.FinUtilArmaduraSerie = Math.Min(datos.LongitudTotal, finUtilPaquete);

        if (datos.FinUtilArmaduraSerie <= datos.InicioUtilArmaduraSerie + Tol)
            return 0;

        foreach (ConfiguracionCapaLongitudinal capaSuperior in capasSuperiores)
        {
            if (capaSuperior == null)
                continue;

            contador += CrearGrupoBarrasLongitudinalesConNumeroFijo(
                doc,
                datos,
                capaSuperior.TipoBarra,
                capaSuperior.Cantidad,
                recubrimiento,
                capaSuperior.Diametro,
                true,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                desarrolloInicioHabilitado,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeSuperior,
                longitudBarra,
                capaSuperior.OffsetCentroDesdeCara,
                capaSuperior.TipoElementoTexto);
        }

        foreach (ConfiguracionCapaLongitudinal capaInferior in capasInferiores)
        {
            if (capaInferior == null)
                continue;

            contador += CrearGrupoBarrasLongitudinalesConNumeroFijo(
                doc,
                datos,
                capaInferior.TipoBarra,
                capaInferior.Cantidad,
                recubrimiento,
                capaInferior.Diametro,
                false,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                desarrolloInicioHabilitado,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeInferior,
                longitudBarra,
                capaInferior.OffsetCentroDesdeCara,
                capaInferior.TipoElementoTexto);
        }

        if (crearAceroCentral)
        {
            contador += CrearGrupoBarrasCentralesConNumeroFijo(
                doc,
                datos,
                tipoCentral,
                recubrimiento,
                diametroCentral,
                desarrolloInicioHabilitado,
                longitudDesarrolloInicio,
                desarrolloFinHabilitado,
                longitudDesarrolloFin,
                crearEmpalmes,
                longitudEmpalmeCentral,
                longitudBarra);
        }

        return contador;
    }

    private List<ConfiguracionCapaLongitudinal> ConstruirConfiguracionCapasLongitudinales(
        bool superior,
        RebarBarType tipoCapa1,
        int cantidadCapa1,
        double recubrimiento,
        bool crearEmpalmes)
    {
        List<ConfiguracionCapaLongitudinal> capas = new List<ConfiguracionCapaLongitudinal>();

        int numeroCapas = 1;

        if (Form != null)
            numeroCapas = superior ? Form.CapasSuperiores : Form.CapasInferiores;

        numeroCapas = Math.Max(1, Math.Min(4, numeroCapas));

        RebarBarType tipoCapa2 = null;
        RebarBarType tipoCapa3 = null;
        RebarBarType tipoCapa4 = null;
        int cantidadCapa2 = 0;
        int cantidadCapa3 = 0;
        int cantidadCapa4 = 0;

        if (Form != null)
        {
            if (superior)
            {
                tipoCapa2 = Form.TipoSuperiorCapa2Seleccionado;
                tipoCapa3 = Form.TipoSuperiorCapa3Seleccionado;
                tipoCapa4 = Form.TipoSuperiorCapa4Seleccionado;
                TryLeerEntero(Form.CantidadSuperiorCapa2Texto, out cantidadCapa2);
                TryLeerEntero(Form.CantidadSuperiorCapa3Texto, out cantidadCapa3);
                TryLeerEntero(Form.CantidadSuperiorCapa4Texto, out cantidadCapa4);
            }
            else
            {
                tipoCapa2 = Form.TipoInferiorCapa2Seleccionado;
                tipoCapa3 = Form.TipoInferiorCapa3Seleccionado;
                tipoCapa4 = Form.TipoInferiorCapa4Seleccionado;
                TryLeerEntero(Form.CantidadInferiorCapa2Texto, out cantidadCapa2);
                TryLeerEntero(Form.CantidadInferiorCapa3Texto, out cantidadCapa3);
                TryLeerEntero(Form.CantidadInferiorCapa4Texto, out cantidadCapa4);
            }
        }

        double separacionLibreCapas = Math.Max(
            separacionLibreCapasActualMYG,
            UnitUtils.ConvertToInternalUnits(0.1, UnitTypeId.Millimeters));

        double diametroEstriboReferencia = ObtenerDiametroEstriboReferenciaDesdeForm();

        RebarBarType[] tipos = new RebarBarType[]
        {
            tipoCapa1,
            tipoCapa2,
            tipoCapa3,
            tipoCapa4
        };

        int[] cantidades = new int[]
        {
            cantidadCapa1,
            cantidadCapa2,
            cantidadCapa3,
            cantidadCapa4
        };

        double offsetCentroAnterior = 0.0;
        double diametroAnterior = 0.0;

        for (int i = 0; i < numeroCapas; i++)
        {
            RebarBarType tipo = tipos[i];
            int cantidad = cantidades[i];

            if (tipo == null || cantidad <= 0)
                continue;

            double diametro = ObtenerDiametroBarra(tipo);
            double radio = diametro / 2.0;
            double offsetCentro;

            if (i == 0)
            {
                offsetCentro = recubrimiento + diametroEstriboReferencia + radio;
            }
            else
            {
                // Un único input controla la separación libre cara a cara
                // tanto en capas superiores como inferiores, con o sin empalmes.
                double separacionLibreCaraACara =
                    separacionLibreCapas;

                // Revit ubica barras por el eje, por eso el offset entre centros es:
                // radio capa anterior + separación libre cara a cara + radio capa actual.
                offsetCentro = offsetCentroAnterior +
                               diametroAnterior / 2.0 +
                               separacionLibreCaraACara +
                               radio;
            }

            capas.Add(new ConfiguracionCapaLongitudinal()
            {
                NumeroCapa = i + 1,
                TipoBarra = tipo,
                Cantidad = cantidad,
                Diametro = diametro,
                OffsetCentroDesdeCara = offsetCentro,
                Superior = superior,
                TipoElementoTexto = superior
                    ? "Acero longitudinal - Superior Capa " + (i + 1).ToString("00")
                    : "Acero longitudinal - Inferior Capa " + (i + 1).ToString("00")
            });

            offsetCentroAnterior = offsetCentro;
            diametroAnterior = diametro;
        }

        return capas;
    }

    private int CrearGrupoBarrasLongitudinalesConNumeroFijo(
        Document doc,
        DatosSerieVigas datos,
        RebarBarType barType,
        int cantidad,
        double recubrimiento,
        double diametro,
        bool superior,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalme,
        double longitudBarra,
        double offsetCentroDesdeCaraPersonalizado = -1.0,
        string tipoElementoLongitudinal = "")
    {
        if (doc == null || datos == null || datos.Host == null)
            return 0;

        if (cantidad <= 0)
            return 0;

        if (barType == null)
            return 0;

        if (datos.LongitudTotal <= Tol)
            return 0;

        // =========================================================
        // OFFSET REAL DEL ACERO LONGITUDINAL RESPECTO AL CONCRETO
        // =========================================================
        // Lo solicitado ahora es que:
        //      recubrimiento + diámetro del estribo
        // se mida desde la CARA del acero longitudinal hasta la CARA
        // de la sección de concreto.
        //
        // Como Revit dibuja la armadura por su eje, el eje del longitudinal
        // debe colocarse a:
        //      recubrimiento + diámetro del estribo + radio longitudinal.
        //
        // Este valor se usa como offset perpendicular para todas las caras
        // que definen la posición del acero.
        double diametroEstriboReferencia = ObtenerDiametroEstriboReferenciaDesdeForm();
        double radioBarraLongitudinal = diametro / 2.0;
        double recubrimientoSeccionLateral = recubrimiento + diametroEstriboReferencia + radioBarraLongitudinal;
        double recubrimientoSeccionVertical = offsetCentroDesdeCaraPersonalizado > Tol
            ? offsetCentroDesdeCaraPersonalizado
            : recubrimientoSeccionLateral;

        // Compatibilidad con la lógica original: para la primera capa, ambos offsets son iguales.
        // Para capas 2 y 3, solo aumenta el offset vertical para conservar la separación
        // cara a cara de 3 cm entre barras, sin cerrar innecesariamente el ancho del set.
        double recubrimientoSeccion = recubrimientoSeccionLateral;
        bool forzarRespaldoRectangularPorCapa =
            offsetCentroDesdeCaraPersonalizado > Tol &&
            Math.Abs(recubrimientoSeccionVertical - recubrimientoSeccionLateral) > Tol;

        // Para capas 2 y 3, la distribución lateral mantiene el recubrimiento de la primera capa,
        // pero el recorrido longitudinal debe proyectarse a la cara superior/inferior con el
        // margen vertical real de esa capa. Así las capas adicionales también toman los quiebres
        // de vigas inclinadas, secciones variables o tramos quebrados.
        double margenCaraProyeccionLongitudinal = recubrimientoSeccionVertical;

        // CORRECCIÓN - DESARROLLO AUTOMÁTICO A CARA REAL DEL ACERO:
        // El Auto debe dejar el recubrimiento medido desde la cara exterior de la
        // columna hasta la CARA del acero, no hasta el eje. En vigas inclinadas,
        // además, el offset perpendicular a la cara superior/inferior desplaza el
        // eje de la barra en X; por eso se calcula una longitud específica para
        // cada extremo y cada capa sin modificar la lógica de quiebres.
        double longitudDesarrolloInicioParaEje = longitudDesarrolloInicio;
        double longitudDesarrolloFinParaEje = longitudDesarrolloFin;

        if (desarrolloInicioHabilitado &&
            Form != null &&
            Form.DesarrolloAutomaticoInicio &&
            longitudDesarrolloInicioParaEje > Tol)
        {
            double longitudAutoInicio = CalcularDesarrolloAutomaticoExtremoParaEjeCaraAcero(
                datos,
                true,
                superior,
                recubrimiento,
                radioBarraLongitudinal,
                margenCaraProyeccionLongitudinal);

            if (longitudAutoInicio >= 0.0)
            {
                longitudDesarrolloInicioParaEje = longitudAutoInicio;
            }
            else
            {
                double factorInicio = ObtenerFactorProyeccionDesarrolloAutomatico(datos, true);
                if (factorInicio <= 0.10) factorInicio = 1.0;
                double ajusteRadioInicio = radioBarraLongitudinal / factorInicio;
                longitudDesarrolloInicioParaEje = Math.Max(0.0, longitudDesarrolloInicioParaEje - ajusteRadioInicio);
            }
        }

        if (desarrolloFinHabilitado &&
            Form != null &&
            Form.DesarrolloAutomaticoFin &&
            longitudDesarrolloFinParaEje > Tol)
        {
            double longitudAutoFin = CalcularDesarrolloAutomaticoExtremoParaEjeCaraAcero(
                datos,
                false,
                superior,
                recubrimiento,
                radioBarraLongitudinal,
                margenCaraProyeccionLongitudinal);

            if (longitudAutoFin >= 0.0)
            {
                longitudDesarrolloFinParaEje = longitudAutoFin;
            }
            else
            {
                double factorFin = ObtenerFactorProyeccionDesarrolloAutomatico(datos, false);
                if (factorFin <= 0.10) factorFin = 1.0;
                double ajusteRadioFin = radioBarraLongitudinal / factorFin;
                longitudDesarrolloFinParaEje = Math.Max(0.0, longitudDesarrolloFinParaEje - ajusteRadioFin);
            }
        }

        double inicioUtil = Math.Max(0.0, datos.InicioUtilArmaduraSerie);
        double finUtil = datos.FinUtilArmaduraSerie > inicioUtil + Tol
            ? Math.Min(datos.LongitudTotal, datos.FinUtilArmaduraSerie)
            : datos.LongitudTotal;

        // =========================================================
        // DESARROLLO REAL FUERA DE LA CARA DE LA VIGA
        // =========================================================
        // inicioUtil/finUtil delimitan dónde el paquete completo cabe dentro
        // del sólido de la viga. Cuando se solicita desarrollo, la barra debe
        // prolongarse desde esas caras hacia la columna o apoyo exterior.
        // La versión anterior volvía a clampear contra inicioUtil/finUtil y,
        // por eso, los 60 cm ingresados nunca aparecían en el modelo.
        double xInicio = desarrolloInicioHabilitado
            ? inicioUtil - Math.Max(0.0, longitudDesarrolloInicioParaEje)
            : inicioUtil + recubrimiento;

        double xFin = desarrolloFinHabilitado
            ? finUtil + Math.Max(0.0, longitudDesarrolloFinParaEje)
            : finUtil - recubrimiento;

        if (xFin <= xInicio)
            return 0;

        double desfaseEmpalme = ObtenerDesfaseEmpalmeCaraACara(diametro);

        List<SegmentoAceroLongitudinal> segmentos =
            ConstruirSegmentosLongitudinales(
                datos,
                superior ? 1 : -1,
                xInicio,
                xFin,
                crearEmpalmes,
                longitudBarra,
                longitudEmpalme,
                ganchoInicio ? longitudGanchoInicio : 0.0,
                ganchoFin ? longitudGanchoFin : 0.0,
                diametro,
                barType);

        if (segmentos == null || segmentos.Count == 0)
            return 0;

        List<SegmentoAceroLongitudinal>
            segmentosPendientesRespaldoMYG =
                new List<SegmentoAceroLongitudinal>(
                    segmentos);

        int creadasPreviasSeccionRealMYG = 0;

        // =========================================================
        // SEPARACIÓN DE LÓGICAS
        // =========================================================
        // Si la serie es ortogonal/rectangular, se conserva la ruta original
        // que ya generaba bien los empalmes y las barras.
        // Si existe al menos una cara inclinada o no ortogonal, se activa la
        // ruta por caras reales para respetar los quiebres y el offset.
        bool usarRutaPorCarasInclinadas = SerieTieneGeometriaNoOrtogonalParaLongitudinal(
            datos,
            superior);

        // =========================================================
        // POSICIONES REALES EN SECCIÓN Y-Z
        // =========================================================
        // Se calculan con intersección de líneas offseteadas:
        // - cara superior/inferior con offset = recubrimiento + diámetro estribo
        // - cara lateral izquierda con el mismo offset
        // - cara lateral derecha con el mismo offset
        //
        // El punto extremo debe quedar pegado al estribo, como en la vista de sección:
        // no se contrae lateralmente el primer/último punto del set, porque eso genera
        // un desfase adicional respecto a la rama lateral del estribo.
        double offsetCentroBarra = recubrimientoSeccion;

        List<PosicionBarraYZ> posiciones = ObtenerPosicionesBarrasPorCaraRealYZ(
            datos,
            cantidad,
            offsetCentroBarra,
            superior ? 1 : -1);

        if (posiciones == null || posiciones.Count != cantidad)
        {
            posiciones = ObtenerPosicionesBarrasPorSeccionReal(
                datos,
                cantidad,
                offsetCentroBarra,
                superior ? 1 : -1);
        }

        if (!forzarRespaldoRectangularPorCapa && posiciones != null && posiciones.Count == cantidad)
        {
            PosicionBarraYZ posInicial = posiciones[0];
            PosicionBarraYZ posFinal = posiciones[posiciones.Count - 1];

            if (posInicial != null && posFinal != null)
            {
                // IMPORTANTE:
                // Antes se contraían los extremos del set para separar las barras de las ramas
                // laterales del estribo. Eso provocaba que los aceros superiores/inferiores
                // quedaran demasiado metidos hacia el centro de la viga. Se deja la posición
                // real calculada por el polígono offseteado para que la barra quede pegada al
                // estribo, sin cambiar la lógica de quiebres ni empalmes.

                XYZ vectorDistribucion = datos.YAxis.Multiply(posFinal.Y - posInicial.Y)
                    .Add(datos.ZAxis.Multiply(posFinal.Z - posInicial.Z));

                // Seguridad: el vector del set debe vivir solo en el plano Y-Z de la sección.
                if (datos.XAxis != null && datos.XAxis.GetLength() > Tol)
                {
                    double dotX = vectorDistribucion.DotProduct(datos.XAxis);
                    vectorDistribucion = vectorDistribucion.Subtract(datos.XAxis.Multiply(dotX));
                }

                double longitudDistribucionReal = vectorDistribucion.GetLength();

                if (cantidad <= 1 || longitudDistribucionReal <= Tol)
                    longitudDistribucionReal = 0.0;

                XYZ normalDistribucion = longitudDistribucionReal > Tol
                    ? vectorDistribucion.Normalize()
                    : datos.YAxis;

                int cantidadSet = longitudDistribucionReal > Tol
                    ? cantidad
                    : 1;

                XYZ direccionInteriorSet = ObtenerDireccionInteriorSetLongitudinal(
                    datos,
                    normalDistribucion,
                    superior);

                // IMPORTANTE - EMPALME:
                // El quiebre del empalme NO debe mover el acero en el ancho Y
                // ni debe cambiar la línea de offset respecto a la cara.
                // Solo se desplaza en Z para que en planta se vea un solo acero,
                // y luego retorna al mismo nivel de la barra principal.
                XYZ direccionEmpalmeZ = ObtenerDireccionEmpalmeVerticalZ(
                    datos,
                    superior);

                int creadasSeccionReal = 0;

                List<SegmentoAceroLongitudinal>
                    segmentosFallidosSeccionRealMYG =
                        new List<SegmentoAceroLongitudinal>();

                foreach (SegmentoAceroLongitudinal seg in segmentos)
                {
                    if (seg == null)
                        continue;

                    if (seg.XFin <= seg.XInicio + Tol)
                        continue;

                    // Cada tramo generado por empalme debe alojarse en la viga
                    // que realmente contiene la mayor parte de su recorrido.
                    Element hostSegmentoMYG =
                        ObtenerHostParaSegmentoLongitudinalMYG(datos, seg);

                    if (hostSegmentoMYG == null)
                        continue;

                    double yInicialHostMYG;
                    double yFinalHostMYG;
                    double longitudDistribucionHostMYG;
                    XYZ normalDistribucionHostMYG;

                    ObtenerDistribucionLocalHostLongitudinalMYG(
                        datos,
                        hostSegmentoMYG,
                        recubrimientoSeccionLateral,
                        posInicial.Y,
                        posFinal.Y,
                        normalDistribucion,
                        out yInicialHostMYG,
                        out yFinalHostMYG,
                        out longitudDistribucionHostMYG,
                        out normalDistribucionHostMYG);

                    int cantidadSetHostMYG =
                        cantidad > 1 &&
                        longitudDistribucionHostMYG > Tol
                            ? cantidad
                            : 1;

                    XYZ direccionInteriorSetHostMYG =
                        ObtenerDireccionInteriorSetLongitudinal(
                            datos,
                            normalDistribucionHostMYG,
                            superior);

                    // LÓGICA INDEPENDIENTE:
                    // - Viga ortogonal/rectangular: usa el empalme original, que ya funcionaba.
                    // - Viga con una o más caras inclinadas: usa recorrido por caras reales.
                    List<XYZ> puntosBarra = usarRutaPorCarasInclinadas
                        ? ConstruirPuntosBarraConEmpalme(
                            datos,
                            seg,
                            yInicialHostMYG,
                            posInicial.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionEmpalmeZ,
                            desfaseEmpalme,
                            margenCaraProyeccionLongitudinal)
                        : ConstruirPuntosBarraConEmpalmeOriginal(
                            datos,
                            seg,
                            yInicialHostMYG,
                            posInicial.Z,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionEmpalmeZ,
                            desfaseEmpalme);

                    if (puntosBarra == null || puntosBarra.Count < 2)
                        continue;

                    bool usarGanchoInicio = ganchoInicio && seg.EsPrimero;
                    bool usarGanchoFin = ganchoFin && seg.EsUltimo;

                    int creadas = CrearRebarLongitudinalConNumeroFijo(
                        doc,
                        hostSegmentoMYG,
                        barType,
                        normalDistribucionHostMYG,
                        puntosBarra,
                        usarGanchoInicio,
                        longitudGanchoInicio,
                        usarGanchoFin,
                        longitudGanchoFin,
                        direccionInteriorSetHostMYG,
                        cantidadSetHostMYG,
                        longitudDistribucionHostMYG,
                        tipoElementoLongitudinal);

                    if (creadas == 0)
                    {
                        XYZ normalContraria =
                            normalDistribucionHostMYG.Multiply(-1.0);

                        XYZ direccionInteriorSetContraria = ObtenerDireccionInteriorSetLongitudinal(
                            datos,
                            normalContraria,
                            superior);

                        // Mismo criterio en el intento con normal contraria.
                        List<XYZ> puntosBarraDesdeFinal = usarRutaPorCarasInclinadas
                            ? ConstruirPuntosBarraConEmpalme(
                                datos,
                                seg,
                                yFinalHostMYG,
                                posFinal.Z,
                                crearEmpalmes,
                                longitudEmpalme,
                                direccionEmpalmeZ,
                                desfaseEmpalme,
                                margenCaraProyeccionLongitudinal)
                            : ConstruirPuntosBarraConEmpalmeOriginal(
                                datos,
                                seg,
                                yFinalHostMYG,
                                posFinal.Z,
                                crearEmpalmes,
                                longitudEmpalme,
                                direccionEmpalmeZ,
                                desfaseEmpalme);

                        creadas = CrearRebarLongitudinalConNumeroFijo(
                            doc,
                            hostSegmentoMYG,
                            barType,
                            normalContraria,
                            puntosBarraDesdeFinal,
                            usarGanchoInicio,
                            longitudGanchoInicio,
                            usarGanchoFin,
                            longitudGanchoFin,
                            direccionInteriorSetContraria,
                            cantidadSetHostMYG,
                            longitudDistribucionHostMYG,
                            tipoElementoLongitudinal);
                    }

                    if (creadas <= 0)
                    {
                        segmentosFallidosSeccionRealMYG.Add(seg);
                    }

                    creadasSeccionReal += creadas;
                }

                if (segmentosFallidosSeccionRealMYG.Count == 0 &&
                    creadasSeccionReal > 0)
                {
                    return creadasSeccionReal;
                }

                if (creadasSeccionReal > 0)
                {
                    creadasPreviasSeccionRealMYG =
                        creadasSeccionReal;

                    segmentosPendientesRespaldoMYG =
                        segmentosFallidosSeccionRealMYG;
                }
            }
        }

        // =========================================================
        // RESPALDO ORIGINAL RECTANGULAR
        // =========================================================
        double yMin = -datos.Ancho / 2.0 + recubrimientoSeccionLateral;
        double yMax = datos.Ancho / 2.0 - recubrimientoSeccionLateral;

        if (yMax < yMin)
            return 0;

        double z;

        if (superior)
            z = datos.Alto / 2.0 - recubrimientoSeccionVertical;
        else
            z = -datos.Alto / 2.0 + recubrimientoSeccionVertical;

        if (Math.Abs(z) > datos.Alto)
            return 0;

        double yInicial = yMin;
        double longitudDistribucion = yMax - yMin;

        XYZ direccionGanchoRespaldo = superior
            ? datos.ZAxis.Multiply(-1.0)
            : datos.ZAxis;

        XYZ direccionDesfaseEmpalmeRespaldo = superior
            ? datos.ZAxis.Multiply(-1.0)
            : datos.ZAxis;

        int contador = 0;

        foreach (SegmentoAceroLongitudinal seg in segmentosPendientesRespaldoMYG)
        {
            if (seg == null)
                continue;

            if (seg.XFin <= seg.XInicio + Tol)
                continue;

            // Cada tramo generado por empalme debe alojarse en la viga
            // que realmente contiene la mayor parte de su recorrido.
            Element hostSegmentoMYG =
                ObtenerHostParaSegmentoLongitudinalMYG(datos, seg);

            if (hostSegmentoMYG == null)
                continue;

            double yInicialHostMYG;
            double yFinalHostMYG;
            double longitudDistribucionHostMYG;
            XYZ normalDistribucionHostMYG;

            ObtenerDistribucionLocalHostLongitudinalMYG(
                datos,
                hostSegmentoMYG,
                recubrimientoSeccionLateral,
                yInicial,
                yMax,
                datos.YAxis,
                out yInicialHostMYG,
                out yFinalHostMYG,
                out longitudDistribucionHostMYG,
                out normalDistribucionHostMYG);

            int cantidadHostMYG =
                cantidad > 1 &&
                longitudDistribucionHostMYG > Tol
                    ? cantidad
                    : 1;

            List<XYZ> puntosBarra = usarRutaPorCarasInclinadas
                ? ConstruirPuntosBarraConEmpalme(
                    datos,
                    seg,
                    yInicialHostMYG,
                    z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfaseEmpalmeRespaldo,
                    desfaseEmpalme,
                    margenCaraProyeccionLongitudinal)
                : ConstruirPuntosBarraConEmpalmeOriginal(
                    datos,
                    seg,
                    yInicialHostMYG,
                    z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfaseEmpalmeRespaldo,
                    desfaseEmpalme);

            bool usarGanchoInicio = ganchoInicio && seg.EsPrimero;
            bool usarGanchoFin = ganchoFin && seg.EsUltimo;

            int creadas = CrearRebarLongitudinalConNumeroFijo(
                doc,
                hostSegmentoMYG,
                barType,
                normalDistribucionHostMYG,
                puntosBarra,
                usarGanchoInicio,
                longitudGanchoInicio,
                usarGanchoFin,
                longitudGanchoFin,
                direccionGanchoRespaldo,
                cantidadHostMYG,
                longitudDistribucionHostMYG,
                tipoElementoLongitudinal);

            if (creadas == 0)
            {
                creadas = CrearRebarLongitudinalConNumeroFijo(
                    doc,
                    hostSegmentoMYG,
                    barType,
                    normalDistribucionHostMYG.Multiply(-1.0),
                    puntosBarra,
                    usarGanchoInicio,
                    longitudGanchoInicio,
                    usarGanchoFin,
                    longitudGanchoFin,
                    direccionGanchoRespaldo,
                    cantidadHostMYG,
                    longitudDistribucionHostMYG,
                    tipoElementoLongitudinal);
            }

            if (creadas == 0)
            {
                List<XYZ> puntosOriginal = ConstruirPuntosBarraConEmpalmeOriginal(
                    datos,
                    seg,
                    yInicialHostMYG,
                    z,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfaseEmpalmeRespaldo,
                    desfaseEmpalme);

                creadas = CrearRebarLongitudinalConNumeroFijo(
                    doc,
                    hostSegmentoMYG,
                    barType,
                    normalDistribucionHostMYG,
                    puntosOriginal,
                    usarGanchoInicio,
                    longitudGanchoInicio,
                    usarGanchoFin,
                    longitudGanchoFin,
                    direccionGanchoRespaldo,
                    cantidadHostMYG,
                    longitudDistribucionHostMYG,
                    tipoElementoLongitudinal);

                if (creadas == 0)
                {
                    creadas = CrearRebarLongitudinalConNumeroFijo(
                        doc,
                        hostSegmentoMYG,
                        barType,
                        normalDistribucionHostMYG.Multiply(-1.0),
                        puntosOriginal,
                        usarGanchoInicio,
                        longitudGanchoInicio,
                        usarGanchoFin,
                        longitudGanchoFin,
                        direccionGanchoRespaldo,
                        cantidad,
                        longitudDistribucion,
                tipoElementoLongitudinal);
                }
            }

            contador += creadas;
        }

        return creadasPreviasSeccionRealMYG + contador;
    }

    private void ContraerExtremosDistribucionYZ(
        ref PosicionBarraYZ posInicial,
        ref PosicionBarraYZ posFinal,
        double recorte)
    {
        if (posInicial == null || posFinal == null)
            return;

        if (recorte <= Tol)
            return;

        double dy = posFinal.Y - posInicial.Y;
        double dz = posFinal.Z - posInicial.Z;
        double longitud = Math.Sqrt((dy * dy) + (dz * dz));

        if (longitud <= (2.0 * recorte) + Tol)
            return;

        double dirY = dy / longitud;
        double dirZ = dz / longitud;

        posInicial = new PosicionBarraYZ(
            posInicial.Y + dirY * recorte,
            posInicial.Z + dirZ * recorte);

        posFinal = new PosicionBarraYZ(
            posFinal.Y - dirY * recorte,
            posFinal.Z - dirZ * recorte);
    }

    private bool ObtenerRangoYEnZOffsetInterior(
        List<PuntoSeccionYZ> poligonoOriginal,
        double offsetInterior,
        double zConsulta,
        out double yIzquierda,
        out double yDerecha)
    {
        yIzquierda = 0.0;
        yDerecha = 0.0;

        if (poligonoOriginal == null || poligonoOriginal.Count < 3)
            return false;

        if (offsetInterior <= Tol)
            return ObtenerRangoYEnZ(
                poligonoOriginal,
                zConsulta,
                out yIzquierda,
                out yDerecha);

        List<PuntoSeccionYZ> poligonoOffset = ObtenerPoligonoOffsetInteriorYZ(
            poligonoOriginal,
            offsetInterior);

        if (poligonoOffset == null || poligonoOffset.Count < 3)
        {
            double yIzq;
            double yDer;

            if (!ObtenerRangoYEnZ(poligonoOriginal, zConsulta, out yIzq, out yDer))
                return false;

            yIzquierda = yIzq + offsetInterior;
            yDerecha = yDer - offsetInterior;
            return yDerecha > yIzquierda + Tol;
        }

        return ObtenerRangoYEnZ(
            poligonoOffset,
            zConsulta,
            out yIzquierda,
            out yDerecha);
    }

    private List<PuntoSeccionYZ> ObtenerPoligonoOffsetInteriorYZ(
        List<PuntoSeccionYZ> poligonoOriginal,
        double offsetInterior)
    {
        List<PuntoSeccionYZ> resultado = new List<PuntoSeccionYZ>();

        if (poligonoOriginal == null || poligonoOriginal.Count < 3)
            return resultado;

        List<LineaOffsetSeccionYZ> lineasOffset = ConstruirLineasOffsetInteriorYZ(
            poligonoOriginal,
            offsetInterior);

        if (lineasOffset == null || lineasOffset.Count != poligonoOriginal.Count)
            return resultado;

        int n = lineasOffset.Count;

        for (int i = 0; i < n; i++)
        {
            LineaOffsetSeccionYZ lineaAnterior = lineasOffset[(i - 1 + n) % n];
            LineaOffsetSeccionYZ lineaActual = lineasOffset[i];

            PuntoSeccionYZ p;

            if (TryIntersecarLineasOffsetYZ(lineaAnterior, lineaActual, out p) && p != null)
                resultado.Add(p);
        }

        if (resultado.Count < 3)
            return new List<PuntoSeccionYZ>();

        return resultado;
    }

    private XYZ ObtenerDireccionInteriorSetLongitudinal(
        DatosSerieVigas datos,
        XYZ normalDistribucion,
        bool superior)
    {
        if (datos == null || normalDistribucion == null)
            return XYZ.BasisZ;

        if (normalDistribucion.GetLength() <= Tol)
        {
            return superior
                ? datos.ZAxis.Multiply(-1.0)
                : datos.ZAxis;
        }

        XYZ normalSet = normalDistribucion.Normalize();

        // El set se distribuye en normalSet y la barra corre en X.
        // Esta dirección queda perpendicular a la distribución, dentro del plano del set.
        XYZ dir = normalSet.CrossProduct(datos.XAxis);

        if (dir == null || dir.GetLength() <= Tol)
            dir = datos.XAxis.CrossProduct(normalSet);

        if (dir == null || dir.GetLength() <= Tol)
        {
            return superior
                ? datos.ZAxis.Multiply(-1.0)
                : datos.ZAxis;
        }

        dir = dir.Normalize();

        XYZ objetivo = superior
            ? datos.ZAxis.Multiply(-1.0)
            : datos.ZAxis;

        if (dir.DotProduct(objetivo) < 0.0)
            dir = dir.Multiply(-1.0);

        return dir;
    }


    private XYZ ObtenerDireccionEmpalmeVerticalZ(
        DatosSerieVigas datos,
        bool superior)
    {
        if (datos == null || datos.ZAxis == null || datos.ZAxis.GetLength() <= Tol)
            return superior ? XYZ.BasisZ.Multiply(-1.0) : XYZ.BasisZ;

        // Superior: baja el tramo inicial del empalme y luego retorna
        // a la línea principal. Inferior: sube el tramo inicial del empalme.
        // El desplazamiento es solo en Z, por eso en planta no se separa.
        return superior
            ? datos.ZAxis.Normalize().Multiply(-1.0)
            : datos.ZAxis.Normalize();
    }



    private bool SerieTieneGeometriaNoOrtogonalParaLongitudinal(
        DatosSerieVigas datos,
        bool superior)
    {
        if (datos == null)
            return false;

        // 1) Revisión longitudinal X-Z: detecta caras superiores/inferiores
        // con pendiente a lo largo de la viga. Este es el caso que altera el
        // empalme si se trata como una viga rectangular normal.
        if (SerieTieneCaraLongitudinalInclinadaXZ(datos, superior))
            return true;

        // 2) Revisión de continuidad entre tramos:
        // cuando la serie tiene vigas rectangulares pero con cambio de dirección
        // o tramos inclinados respecto al eje general, también se debe usar el
        // recorrido por caras. Si no se activa esto, Revit une el inicio y fin
        // con una sola línea recta y desaparecen los quiebres.
        if (SerieTieneQuiebreEntreTramosLongitudinal(datos))
            return true;

        // 3) Revisión transversal Y-Z: detecta secciones trapezoidales o con
        // algún lado no ortogonal. Si la sección es rectangular pura, devuelve false.
        if (SerieTieneSeccionTransversalNoOrtogonalYZ(datos))
            return true;

        return false;
    }

    private bool SerieTieneQuiebreEntreTramosLongitudinal(
        DatosSerieVigas datos)
    {
        if (datos == null || datos.TramosRecorrido == null)
            return false;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Viga != null)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        if (tramos.Count <= 1)
            return false;

        double cosTol = Math.Cos(0.25 * Math.PI / 180.0);
        XYZ dirAnterior = null;

        foreach (TramoRecorridoSerie tramo in tramos)
        {
            XYZ dir = null;

            if (tramo.Direccion != null && tramo.Direccion.GetLength() > Tol)
                dir = tramo.Direccion.Normalize();
            else if (tramo.Viga != null && tramo.Viga.XAxis != null && tramo.Viga.XAxis.GetLength() > Tol)
                dir = tramo.Viga.XAxis.Normalize();

            if (dir == null || dir.GetLength() <= Tol)
                continue;

            if (dirAnterior != null && dirAnterior.GetLength() > Tol)
            {
                double dot = Math.Abs(dirAnterior.DotProduct(dir));
                if (dot > 1.0) dot = 1.0;

                if (dot < cosTol)
                    return true;
            }

            if (datos.XAxis != null && datos.XAxis.GetLength() > Tol)
            {
                XYZ ejeSerie = datos.XAxis.Normalize();
                double dotSerie = Math.Abs(ejeSerie.DotProduct(dir));
                if (dotSerie > 1.0) dotSerie = 1.0;

                if (dotSerie < cosTol)
                    return true;
            }

            dirAnterior = dir;
        }

        return false;
    }

    private bool SerieTieneCaraLongitudinalInclinadaXZ(
        DatosSerieVigas datos,
        bool superior)
    {
        if (datos == null || datos.TramosRecorrido == null)
            return false;

        double tolZ = UnitUtils.ConvertToInternalUnits(
            0.2,
            UnitTypeId.Centimeters);

        double tolX = UnitUtils.ConvertToInternalUnits(
            2.0,
            UnitTypeId.Centimeters);

        foreach (TramoRecorridoSerie tramo in datos.TramosRecorrido)
        {
            if (tramo == null || tramo.Viga == null)
                continue;

            DatosViga v = tramo.Viga;

            List<SegmentoPerfilCara> perfil = superior
                ? v.PerfilSuperiorDetallado
                : v.PerfilInferiorDetallado;

            if (perfil == null || perfil.Count == 0)
                perfil = CrearPerfilSimpleCara(v, superior);

            if (perfil == null || perfil.Count == 0)
                continue;

            foreach (SegmentoPerfilCara s in perfil)
            {
                if (s == null)
                    continue;

                double dx = Math.Abs(s.X1 - s.X0);
                double dz = Math.Abs(s.Z1 - s.Z0);

                if (dx > tolX && dz > tolZ)
                    return true;
            }
        }

        return false;
    }

    private bool SerieTieneSeccionTransversalNoOrtogonalYZ(
        DatosSerieVigas datos)
    {
        if (datos == null)
            return false;

        List<PuntoSeccionYZ> poligono = ObtenerPoligonoSeccionRealYZ(datos);

        if (poligono == null || poligono.Count < 3)
            return false;

        double tol = UnitUtils.ConvertToInternalUnits(
            0.2,
            UnitTypeId.Centimeters);

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoSeccionYZ a = poligono[i];
            PuntoSeccionYZ b = poligono[(i + 1) % poligono.Count];

            if (a == null || b == null)
                continue;

            double dy = Math.Abs(b.Y - a.Y);
            double dz = Math.Abs(b.Z - a.Z);

            // Si un lado tiene componente Y y Z a la vez, no es ortogonal.
            if (dy > tol && dz > tol)
                return true;
        }

        return false;
    }

    private int CrearGrupoBarrasCentralesConNumeroFijo(
        Document doc,
        DatosSerieVigas datos,
        RebarBarType barType,
        double recubrimiento,
        double diametro,
        bool desarrolloInicioHabilitado,
        double longitudDesarrolloInicio,
        bool desarrolloFinHabilitado,
        double longitudDesarrolloFin,
        bool crearEmpalmes,
        double longitudEmpalme,
        double longitudBarra)
    {
        if (barType == null)
            return 0;

        if (datos == null || datos.Host == null)
            return 0;

        double radioBarra = diametro / 2.0;
        double diametroEstriboReferencia = ObtenerDiametroEstriboReferenciaDesdeForm();

        // Igual que en superior/inferior:
        // el valor ingresado de recubrimiento + diámetro de estribo
        // debe llegar hasta la CARA del acero longitudinal.
        // Por eso el eje de la barra central se separa adicionalmente
        // por su radio.
        double recubrimientoSeccion = recubrimiento + diametroEstriboReferencia + radioBarra;

        // Misma corrección que en superiores/inferiores:
        // cuando el desarrollo es automático, el recubrimiento de extremo
        // debe quedar medido hasta la CARA del acero, no hasta su eje.
        double longitudDesarrolloInicioParaEje = longitudDesarrolloInicio;
        double longitudDesarrolloFinParaEje = longitudDesarrolloFin;

        if (desarrolloInicioHabilitado &&
            Form != null &&
            Form.DesarrolloAutomaticoInicio &&
            longitudDesarrolloInicioParaEje > Tol)
        {
            // CENTRAL: mismo criterio corregido de superiores/inferiores,
            // pero sin desplazamiento vertical de capa.
            // El central va por el plano medio; por eso margenCara = 0.0.
            double longitudAutoInicio = CalcularDesarrolloAutomaticoExtremoParaEjeCaraAcero(
                datos,
                true,
                true,
                recubrimiento,
                radioBarra,
                0.0);

            if (longitudAutoInicio >= 0.0)
            {
                longitudDesarrolloInicioParaEje = longitudAutoInicio;
            }
            else
            {
                double factorInicio = ObtenerFactorProyeccionDesarrolloAutomatico(datos, true);
                if (factorInicio <= 0.10) factorInicio = 1.0;
                double ajusteRadioInicio = radioBarra / factorInicio;
                longitudDesarrolloInicioParaEje = Math.Max(0.0, longitudDesarrolloInicioParaEje - ajusteRadioInicio);
            }
        }

        if (desarrolloFinHabilitado &&
            Form != null &&
            Form.DesarrolloAutomaticoFin &&
            longitudDesarrolloFinParaEje > Tol)
        {
            // CENTRAL: mismo criterio corregido de superiores/inferiores,
            // pero sin desplazamiento vertical de capa.
            double longitudAutoFin = CalcularDesarrolloAutomaticoExtremoParaEjeCaraAcero(
                datos,
                false,
                true,
                recubrimiento,
                radioBarra,
                0.0);

            if (longitudAutoFin >= 0.0)
            {
                longitudDesarrolloFinParaEje = longitudAutoFin;
            }
            else
            {
                double factorFin = ObtenerFactorProyeccionDesarrolloAutomatico(datos, false);
                if (factorFin <= 0.10) factorFin = 1.0;
                double ajusteRadioFin = radioBarra / factorFin;
                longitudDesarrolloFinParaEje = Math.Max(0.0, longitudDesarrolloFinParaEje - ajusteRadioFin);
            }
        }

        double inicioUtil = Math.Max(0.0, datos.InicioUtilArmaduraSerie);
        double finUtil = datos.FinUtilArmaduraSerie > inicioUtil + Tol
            ? Math.Min(datos.LongitudTotal, datos.FinUtilArmaduraSerie)
            : datos.LongitudTotal;

        // =========================================================
        // DESARROLLO REAL FUERA DE LA CARA DE LA VIGA
        // =========================================================
        // inicioUtil/finUtil delimitan dónde el paquete completo cabe dentro
        // del sólido de la viga. Cuando se solicita desarrollo, la barra debe
        // prolongarse desde esas caras hacia la columna o apoyo exterior.
        // La versión anterior volvía a clampear contra inicioUtil/finUtil y,
        // por eso, los 60 cm ingresados nunca aparecían en el modelo.
        double xInicio = desarrolloInicioHabilitado
            ? inicioUtil - Math.Max(0.0, longitudDesarrolloInicioParaEje)
            : inicioUtil + recubrimiento;

        double xFin = desarrolloFinHabilitado
            ? finUtil + Math.Max(0.0, longitudDesarrolloFinParaEje)
            : finUtil - recubrimiento;

        if (xFin <= xInicio)
            return 0;

        XYZ direccionDesfaseEmpalme = datos.ZAxis;
        double desfaseEmpalme = ObtenerDesfaseEmpalmeCaraACara(diametro);

        List<SegmentoAceroLongitudinal> segmentos =
            ConstruirSegmentosLongitudinales(
                datos,
                0,
                xInicio,
                xFin,
                crearEmpalmes,
                longitudBarra,
                longitudEmpalme,
                0.0,
                0.0,
                diametro,
                barType);

        if (segmentos == null || segmentos.Count == 0)
            return 0;

        List<SegmentoAceroLongitudinal>
            segmentosPendientesCentralMYG =
                new List<SegmentoAceroLongitudinal>(
                    segmentos);

        int creadasPreviasCentralMYG = 0;

        // =========================================================
        // ACERO CENTRAL HORIZONTAL + REGLA DE NÚMERO FIJO
        // =========================================================
        // El acero central siempre se mantiene horizontal en la sección Y-Z.
        // No se crean barras individuales: se crea un solo set de 2 barras con
        // SetLayoutAsFixedNumber, distribuido en dirección Y.
        double offsetCentroBarra = recubrimientoSeccion;

        bool centralCreadoPorSeccionReal = false;
        List<PuntoSeccionYZ> poligonoCentral = ObtenerPoligonoSeccionRealYZ(datos);

        if (poligonoCentral != null && poligonoCentral.Count >= 3)
        {
            double zMinPol = poligonoCentral.Min(p => p.Z);
            double zMaxPol = poligonoCentral.Max(p => p.Z);
            double zCentral = (zMinPol + zMaxPol) / 2.0;

            double yInicialReal;
            double yFinalReal;

            // Para los aceros centrales, el offset lateral también debe
            // medirse desde la CARA de la barra longitudinal hasta la CARA
            // lateral de concreto. Por eso se corta la línea central contra
            // el polígono interior offseteado, en lugar de usar solo
            // yIzq + offset / yDer - offset.
            if (ObtenerRangoYEnZOffsetInterior(
                poligonoCentral,
                offsetCentroBarra,
                zCentral,
                out yInicialReal,
                out yFinalReal))
            {

                if (yFinalReal > yInicialReal + Tol)
                {
                    double longitudDistribucionReal = yFinalReal - yInicialReal;
                    int creadasSeccionReal = 0;

                    List<SegmentoAceroLongitudinal>
                        segmentosFallidosCentralMYG =
                            new List<SegmentoAceroLongitudinal>();

                    foreach (SegmentoAceroLongitudinal seg in segmentos)
                    {
                        if (seg == null)
                            continue;

                        if (seg.XFin <= seg.XInicio + Tol)
                            continue;

                        // Cada tramo generado por empalme debe alojarse en la viga
                        // que realmente contiene la mayor parte de su recorrido.
                        Element hostSegmentoMYG =
                            ObtenerHostParaSegmentoLongitudinalMYG(datos, seg);

                        if (hostSegmentoMYG == null)
                            continue;

                        double yInicialHostMYG;
                        double yFinalHostMYG;
                        double longitudDistribucionHostMYG;
                        XYZ normalDistribucionHostMYG;

                        ObtenerDistribucionLocalHostLongitudinalMYG(
                            datos,
                            hostSegmentoMYG,
                            recubrimientoSeccion,
                            yInicialReal,
                            yFinalReal,
                            datos.YAxis,
                            out yInicialHostMYG,
                            out yFinalHostMYG,
                            out longitudDistribucionHostMYG,
                            out normalDistribucionHostMYG);

                        // CLAVE - ACERO CENTRAL:
                        // Antes este primer intento usaba ConstruirPuntosBarraConEmpalmeOriginal(),
                        // por eso el acero central quedaba como una línea directa/horizontal en los cambios
                        // de sección. Ahora usa el mismo recorrido real por caras centrales:
                        // líneas paralelas a cada cara central + intersección proyectada en el quiebre.
                        List<XYZ> puntosBarra = ConstruirPuntosBarraCentralConEmpalme(
                            datos,
                            seg,
                            yInicialHostMYG,
                            crearEmpalmes,
                            longitudEmpalme,
                            direccionDesfaseEmpalme,
                            desfaseEmpalme);

                        int creadas = CrearRebarLongitudinalConNumeroFijo(
                            doc,
                            hostSegmentoMYG,
                            barType,
                            normalDistribucionHostMYG,
                            puntosBarra,
                            false,
                            0.0,
                            false,
                            0.0,
                            datos.ZAxis,
                            2,
                            longitudDistribucionHostMYG,
                            "Acero longitudinal - Central");

                        if (creadas == 0)
                        {
                            creadas = CrearRebarLongitudinalConNumeroFijo(
                                doc,
                                hostSegmentoMYG,
                                barType,
                                normalDistribucionHostMYG.Multiply(-1.0),
                                puntosBarra,
                                false,
                                0.0,
                                false,
                                0.0,
                                datos.ZAxis,
                                2,
                                longitudDistribucionHostMYG,
                                "Acero longitudinal - Central");
                        }

                        if (creadas <= 0)
                        {
                            segmentosFallidosCentralMYG.Add(seg);
                        }

                        creadasSeccionReal += creadas;
                    }

                    if (segmentosFallidosCentralMYG.Count == 0 &&
                        creadasSeccionReal > 0)
                    {
                        centralCreadoPorSeccionReal = true;
                        return creadasSeccionReal;
                    }

                    if (creadasSeccionReal > 0)
                    {
                        creadasPreviasCentralMYG =
                            creadasSeccionReal;

                        segmentosPendientesCentralMYG =
                            segmentosFallidosCentralMYG;
                    }
                }
            }
        }

        // Respaldo original, pero con offset de sección incluyendo estribo.
        double yMin = -datos.Ancho / 2.0 + recubrimientoSeccion;
        double yMax = datos.Ancho / 2.0 - recubrimientoSeccion;

        if (yMax < yMin)
            return 0;

        double yInicial = yMin;
        double longitudDistribucion = yMax - yMin;

        int contador = 0;

        foreach (SegmentoAceroLongitudinal seg in segmentosPendientesCentralMYG)
        {
            if (seg == null)
                continue;

            if (seg.XFin <= seg.XInicio + Tol)
                continue;

            // Cada tramo generado por empalme debe alojarse en la viga
            // que realmente contiene la mayor parte de su recorrido.
            Element hostSegmentoMYG =
                ObtenerHostParaSegmentoLongitudinalMYG(datos, seg);

            if (hostSegmentoMYG == null)
                continue;

            double yInicialHostMYG;
            double yFinalHostMYG;
            double longitudDistribucionHostMYG;
            XYZ normalDistribucionHostMYG;

            ObtenerDistribucionLocalHostLongitudinalMYG(
                datos,
                hostSegmentoMYG,
                recubrimientoSeccion,
                yInicial,
                yMax,
                datos.YAxis,
                out yInicialHostMYG,
                out yFinalHostMYG,
                out longitudDistribucionHostMYG,
                out normalDistribucionHostMYG);

            List<XYZ> puntosBarra =
                ConstruirPuntosBarraCentralConEmpalme(
                    datos,
                    seg,
                    yInicialHostMYG,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfaseEmpalme,
                    desfaseEmpalme);

            int creadas = CrearRebarLongitudinalConNumeroFijo(
                doc,
                hostSegmentoMYG,
                barType,
                normalDistribucionHostMYG,
                puntosBarra,
                false,
                0.0,
                false,
                0.0,
                datos.ZAxis,
                2,
                longitudDistribucionHostMYG,
                "Acero longitudinal - Central");

            if (creadas == 0)
            {
                creadas = CrearRebarLongitudinalConNumeroFijo(
                    doc,
                    hostSegmentoMYG,
                    barType,
                    normalDistribucionHostMYG.Multiply(-1.0),
                    puntosBarra,
                    false,
                    0.0,
                    false,
                    0.0,
                    datos.ZAxis,
                    2,
                    longitudDistribucionHostMYG,
                "Acero longitudinal - Central");
            }

            if (creadas == 0)
            {
                List<XYZ> puntosOriginal = ConstruirPuntosBarraConEmpalmeOriginal(
                    datos,
                    seg,
                    yInicialHostMYG,
                    0.0,
                    crearEmpalmes,
                    longitudEmpalme,
                    direccionDesfaseEmpalme,
                    desfaseEmpalme);

                creadas = CrearRebarLongitudinalConNumeroFijo(
                    doc,
                    hostSegmentoMYG,
                    barType,
                    normalDistribucionHostMYG,
                    puntosOriginal,
                    false,
                    0.0,
                    false,
                    0.0,
                    datos.ZAxis,
                    2,
                    longitudDistribucionHostMYG,
                "Acero longitudinal - Central");

                if (creadas == 0)
                {
                    creadas = CrearRebarLongitudinalConNumeroFijo(
                        doc,
                        hostSegmentoMYG,
                        barType,
                        normalDistribucionHostMYG.Multiply(-1.0),
                        puntosOriginal,
                        false,
                        0.0,
                        false,
                        0.0,
                        datos.ZAxis,
                        2,
                        longitudDistribucionHostMYG,
                "Acero longitudinal - Central");
                }
            }

            contador += creadas;
        }

        return creadasPreviasCentralMYG + contador;
    }



    private List<XYZ> ConstruirPuntosBarraCentralConEmpalme(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal seg,
        double y,
        bool crearEmpalmes,
        double longitudEmpalme,
        XYZ direccionDesfaseEmpalme,
        double desfaseEmpalme,
        double margenCaraForzado = -1.0)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (datos == null || seg == null)
            return puntos;

        // =========================================================
        // V11 - ACERO CENTRAL POR PLANO MEDIO REAL DE CADA TRAMO
        // =========================================================
        // No usa z = 0 global como una línea recta única.
        // Para cada viga/tramo se calcula la línea central real como:
        // Zcentral = (ZcaraSuperior + ZcaraInferior) / 2.
        // Luego se proyectan/intersecan esas líneas centrales para generar
        // los puntos de quiebre igual que en el acero superior e inferior.
        bool usarCentralPorCarasInclinadas =
            SerieTieneGeometriaNoOrtogonalParaLongitudinal(datos, true) ||
            SerieTieneGeometriaNoOrtogonalParaLongitudinal(datos, false);

        if (usarCentralPorCarasInclinadas && PuedeUsarRecorridoCentralPorCaras(datos))
        {
            if (!crearEmpalmes ||
                !seg.TieneEmpalmeInicio ||
                longitudEmpalme <= Tol ||
                direccionDesfaseEmpalme == null ||
                direccionDesfaseEmpalme.GetLength() <= Tol ||
                desfaseEmpalme <= Tol)
            {
                bool okCentral = AgregarPuntosRecorridoCentralPorCaras(
                    puntos,
                    datos,
                    seg.XInicio,
                    seg.XFin,
                    y,
                    null);

                if (okCentral && puntos.Count >= 2)
                    return LimpiarPuntosConsecutivos(puntos);

                puntos.Clear();
            }
            else
            {
                XYZ offset = direccionDesfaseEmpalme.Normalize().Multiply(desfaseEmpalme);

                double xEmpalmeFin = Math.Min(
                    seg.XInicio + longitudEmpalme,
                    seg.XFin);

                double espacioDespuesEmpalme = seg.XFin - xEmpalmeFin;

                double longitudDiagonal;

                if (!TryObtenerLongitudDiagonalQuiebreSeguraMYG(
                        espacioDespuesEmpalme,
                        desfaseEmpalme,
                        out longitudDiagonal))
                {
                    // V11.8: nunca crear empalme central colineal.
                    return new List<XYZ>();
                }

                double xDiagonalFin = Math.Min(
                    xEmpalmeFin + longitudDiagonal,
                    seg.XFin);

                bool okEmpalme = AgregarPuntosRecorridoCentralPorCaras(
                    puntos,
                    datos,
                    seg.XInicio,
                    xEmpalmeFin,
                    y,
                    offset);

                if (okEmpalme && puntos.Count >= 2)
                {
                    if (xDiagonalFin > xEmpalmeFin + Tol)
                    {
                        XYZ p2 = PuntoEnRecorridoCentralPorCaras(
                            datos,
                            xDiagonalFin,
                            y);

                        if (p2 == null)
                            p2 = PuntoLocal(datos, xDiagonalFin, y, 0.0);

                        AgregarPuntoSiValido(puntos, p2);

                        if (seg.XFin > xDiagonalFin + Tol)
                        {
                            AgregarPuntosRecorridoCentralPorCaras(
                                puntos,
                                datos,
                                xDiagonalFin,
                                seg.XFin,
                                y,
                                null);
                        }
                    }
                    else
                    {
                        XYZ pFinCentral = PuntoEnRecorridoCentralPorCaras(
                            datos,
                            seg.XFin,
                            y);

                        if (pFinCentral == null)
                            pFinCentral = PuntoLocal(datos, seg.XFin, y, 0.0);

                        AgregarPuntoSiValido(puntos, pFinCentral);
                    }

                    if (puntos.Count >= 2)
                        return LimpiarPuntosConsecutivos(puntos);
                }

                puntos.Clear();
            }
        }

        // Respaldo original: conserva el comportamiento anterior si el perfil central
        // no se puede resolver por caras en alguna geometría puntual.
        return ConstruirPuntosBarraConEmpalmeOriginal(
            datos,
            seg,
            y,
            0.0,
            crearEmpalmes,
            longitudEmpalme,
            direccionDesfaseEmpalme,
            desfaseEmpalme);
    }

    private bool PuedeUsarRecorridoCentralPorCaras(
        DatosSerieVigas datos)
    {
        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return false;

        foreach (TramoRecorridoSerie tramo in datos.TramosRecorrido)
        {
            if (tramo == null || tramo.Viga == null)
                continue;

            List<SegmentoPerfilCara> perfil = CrearPerfilCentralDesdeCaras(tramo.Viga);

            if (perfil != null && perfil.Count > 0)
                return true;
        }

        return false;
    }

    private bool AgregarPuntosRecorridoCentralPorCaras(
        List<XYZ> puntos,
        DatosSerieVigas datos,
        double xInicio,
        double xFin,
        double y,
        XYZ offset)
    {
        if (puntos == null || datos == null)
            return false;

        List<SegmentoCaraSerie> segmentos = ConstruirSegmentosCentralesSerie(
            datos,
            xInicio,
            xFin,
            y);

        if (segmentos == null || segmentos.Count == 0)
            return false;

        if (offset != null && offset.GetLength() > Tol)
        {
            XYZ off = offset;

            foreach (SegmentoCaraSerie s in segmentos)
            {
                if (s == null)
                    continue;

                s.P0 = s.P0.Add(off);
                s.P1 = s.P1.Add(off);

                if (s.P0 != null && s.P1 != null && (s.P1 - s.P0).GetLength() > Tol)
                    s.Direccion = (s.P1 - s.P0).Normalize();
            }
        }

        AgregarPuntoSiValido(puntos, segmentos[0].P0);

        for (int i = 0; i < segmentos.Count - 1; i++)
        {
            SegmentoCaraSerie actual = segmentos[i];
            SegmentoCaraSerie siguiente = segmentos[i + 1];

            if (actual == null || siguiente == null)
                continue;

            if (actual.P0 == null || actual.P1 == null ||
                siguiente.P0 == null || siguiente.P1 == null)
            {
                continue;
            }

            XYZ dirActual = actual.Direccion;
            XYZ dirSiguiente = siguiente.Direccion;

            if (dirActual == null || dirActual.GetLength() <= Tol)
                dirActual = actual.P1 - actual.P0;

            if (dirSiguiente == null || dirSiguiente.GetLength() <= Tol)
                dirSiguiente = siguiente.P1 - siguiente.P0;

            if (dirActual == null || dirSiguiente == null ||
                dirActual.GetLength() <= Tol || dirSiguiente.GetLength() <= Tol)
            {
                continue;
            }

            dirActual = dirActual.Normalize();
            dirSiguiente = dirSiguiente.Normalize();

            double dotAbs = Math.Abs(dirActual.DotProduct(dirSiguiente));
            if (dotAbs > 1.0) dotAbs = 1.0;

            double angulo = Math.Acos(dotAbs) * 180.0 / Math.PI;

            if (angulo <= 0.10)
                continue;

            XYZ puntoQuiebre = null;
            bool quiebreAgregado = false;

            if (TryIntersecarLineasProyectadas(
                actual.P0,
                dirActual,
                siguiente.P0,
                dirSiguiente,
                out puntoQuiebre) &&
                PuntoQuiebreEsRazonableParaUnion(actual, siguiente, puntoQuiebre, datos))
            {
                AgregarPuntoSiValido(puntos, puntoQuiebre);
                quiebreAgregado = true;
            }

            if (!quiebreAgregado)
            {
                AgregarQuiebreSeguroPorUnionReal(
                    puntos,
                    actual,
                    siguiente,
                    datos);
            }
        }

        AgregarPuntoSiValido(puntos, segmentos[segmentos.Count - 1].P1);

        return puntos.Count >= 2;
    }

    private XYZ PuntoEnRecorridoCentralPorCaras(
        DatosSerieVigas datos,
        double x,
        double y)
    {
        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return null;

        TramoRecorridoSerie tramo = ObtenerTramoParaEstacion(datos, x);

        if (tramo == null || tramo.Viga == null)
            return null;

        DatosViga viga = tramo.Viga;
        double estacion = ObtenerEstacionVigaDesdeXSerie(tramo, x);

        List<SegmentoPerfilCara> perfil = CrearPerfilCentralDesdeCaras(viga);

        if (perfil == null || perfil.Count == 0)
            return null;

        SegmentoPerfilCara segCentral = perfil
            .Where(s => s != null)
            .OrderBy(s => DistanciaEstacionASegmentoPerfil(estacion, s))
            .FirstOrDefault();

        if (segCentral == null)
            return null;

        return PuntoEnSegmentoCentral(
            viga,
            segCentral,
            estacion,
            y);
    }

    private List<SegmentoCaraSerie> ConstruirSegmentosCentralesSerie(
        DatosSerieVigas datos,
        double xInicio,
        double xFin,
        double y)
    {
        List<SegmentoCaraSerie> resultado = new List<SegmentoCaraSerie>();

        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return resultado;

        bool invertir = xFin < xInicio;
        double a = Math.Min(xInicio, xFin);
        double b = Math.Max(xInicio, xFin);

        if (Math.Abs(b - a) <= Tol)
        {
            double delta = UnitUtils.ConvertToInternalUnits(0.1, UnitTypeId.Centimeters);
            a -= delta;
            b += delta;
        }

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Viga != null)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        foreach (TramoRecorridoSerie tramo in tramos)
        {
            DatosViga viga = tramo.Viga;

            List<SegmentoPerfilCara> perfilCentral = CrearPerfilCentralDesdeCaras(viga);

            if (perfilCentral == null || perfilCentral.Count == 0)
                continue;

            foreach (SegmentoPerfilCara segCentral in perfilCentral)
            {
                if (segCentral == null)
                    continue;

                double s0 = SerieDesdeEstacionViga(tramo, segCentral.X0);
                double s1 = SerieDesdeEstacionViga(tramo, segCentral.X1);

                double sMin = Math.Min(s0, s1);
                double sMax = Math.Max(s0, s1);

                double ov0 = Math.Max(a, sMin);
                double ov1 = Math.Min(b, sMax);

                if (ov1 < ov0 - Tol)
                    continue;

                if (Math.Abs(ov1 - ov0) <= Tol && Math.Abs(xFin - xInicio) > Tol)
                    continue;

                double serieIni = ov0;
                double serieFin = ov1;

                double estacionIni = ObtenerEstacionVigaDesdeXSerie(tramo, serieIni);
                double estacionFin = ObtenerEstacionVigaDesdeXSerie(tramo, serieFin);

                XYZ p0 = PuntoEnSegmentoCentral(
                    viga,
                    segCentral,
                    estacionIni,
                    y);

                XYZ p1 = PuntoEnSegmentoCentral(
                    viga,
                    segCentral,
                    estacionFin,
                    y);

                if (p0 == null || p1 == null)
                    continue;

                if (serieFin >= serieIni)
                    resultado.Add(new SegmentoCaraSerie(serieIni, serieFin, p0, p1));
                else
                    resultado.Add(new SegmentoCaraSerie(serieFin, serieIni, p1, p0));
            }
        }

        resultado = resultado
            .Where(s => s != null && s.P0 != null && s.P1 != null && (s.P1 - s.P0).GetLength() > Tol)
            .OrderBy(s => Math.Min(s.XSerie0, s.XSerie1))
            .ToList();

        resultado = FusionarSegmentosCaraColineales(resultado);

        // Mantiene la lectura de L. desarrollo: si el primer o último punto queda
        // fuera del sólido real, se prolonga siguiendo la misma dirección central.
        resultado = ExtenderSegmentosCaraHastaRango(resultado, a, b);

        if (invertir)
        {
            resultado.Reverse();

            foreach (SegmentoCaraSerie s in resultado)
            {
                XYZ tmp = s.P0;
                s.P0 = s.P1;
                s.P1 = tmp;

                if (s.P0 != null && s.P1 != null && (s.P1 - s.P0).GetLength() > Tol)
                    s.Direccion = (s.P1 - s.P0).Normalize();
            }
        }

        return resultado;
    }

    private XYZ PuntoEnSegmentoCentral(
        DatosViga viga,
        SegmentoPerfilCara seg,
        double estacion,
        double y)
    {
        if (viga == null || seg == null)
            return null;

        double dx = seg.X1 - seg.X0;
        double dz = seg.Z1 - seg.Z0;

        if (Math.Abs(dx) <= Tol && Math.Abs(dz) <= Tol)
            return null;

        double t = 0.0;

        if (Math.Abs(dx) > Tol)
            t = (estacion - seg.X0) / dx;

        if (t < -0.001) t = -0.001;
        if (t > 1.001) t = 1.001;

        double x = seg.X0 + dx * t;
        double z = seg.Z0 + dz * t;

        double centroYLocal = (viga.YMin + viga.YMax) / 2.0;

        return viga.P0
            .Add(viga.XAxis.Multiply(x))
            .Add(viga.YAxis.Multiply(centroYLocal + y))
            .Add(viga.ZAxis.Multiply(z));
    }

    private List<SegmentoPerfilCara> CrearPerfilCentralDesdeCaras(
        DatosViga viga)
    {
        List<SegmentoPerfilCara> perfilCentral = new List<SegmentoPerfilCara>();

        if (viga == null)
            return perfilCentral;

        List<SegmentoPerfilCara> superior = viga.PerfilSuperiorDetallado;
        List<SegmentoPerfilCara> inferior = viga.PerfilInferiorDetallado;

        if (superior == null || superior.Count == 0)
            superior = CrearPerfilSimpleCara(viga, true);

        if (inferior == null || inferior.Count == 0)
            inferior = CrearPerfilSimpleCara(viga, false);

        if (superior == null || superior.Count == 0 || inferior == null || inferior.Count == 0)
            return perfilCentral;

        double xMin = viga.SolidoMin;
        double xMax = viga.SolidoMax;

        if (xMax <= xMin + Tol)
            return perfilCentral;

        List<double> estaciones = new List<double>();
        estaciones.Add(xMin);
        estaciones.Add(xMax);

        foreach (SegmentoPerfilCara s in superior)
        {
            if (s == null)
                continue;

            AgregarEstacionCentral(estaciones, s.X0, xMin, xMax);
            AgregarEstacionCentral(estaciones, s.X1, xMin, xMax);
        }

        foreach (SegmentoPerfilCara s in inferior)
        {
            if (s == null)
                continue;

            AgregarEstacionCentral(estaciones, s.X0, xMin, xMax);
            AgregarEstacionCentral(estaciones, s.X1, xMin, xMax);
        }

        estaciones = estaciones
            .Where(x => x >= xMin - Tol && x <= xMax + Tol)
            .OrderBy(x => x)
            .ToList();

        List<double> estacionesUnicas = new List<double>();
        double toleranciaEstacion = UnitUtils.ConvertToInternalUnits(0.5, UnitTypeId.Centimeters);

        foreach (double x in estaciones)
        {
            double xc = x;
            if (xc < xMin) xc = xMin;
            if (xc > xMax) xc = xMax;

            if (estacionesUnicas.Count == 0 || Math.Abs(xc - estacionesUnicas[estacionesUnicas.Count - 1]) > toleranciaEstacion)
                estacionesUnicas.Add(xc);
        }

        if (estacionesUnicas.Count < 2)
            return perfilCentral;

        double longitudMinima = UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters);

        for (int i = 0; i < estacionesUnicas.Count - 1; i++)
        {
            double a = estacionesUnicas[i];
            double b = estacionesUnicas[i + 1];

            if (b <= a + longitudMinima)
                continue;

            double zSupA = ObtenerZDesdePerfilCara(superior, a, viga.ZMax);
            double zInfA = ObtenerZDesdePerfilCara(inferior, a, viga.ZMin);
            double zSupB = ObtenerZDesdePerfilCara(superior, b, viga.ZMax);
            double zInfB = ObtenerZDesdePerfilCara(inferior, b, viga.ZMin);

            double zCA = (zSupA + zInfA) / 2.0;
            double zCB = (zSupB + zInfB) / 2.0;

            perfilCentral.Add(new SegmentoPerfilCara(
                a,
                zCA,
                b,
                zCB));
        }

        perfilCentral = FusionarSegmentosPerfilColineales(perfilCentral);

        return perfilCentral;
    }

    private void AgregarEstacionCentral(
        List<double> estaciones,
        double x,
        double xMin,
        double xMax)
    {
        if (estaciones == null)
            return;

        if (x < xMin - Tol || x > xMax + Tol)
            return;

        if (x < xMin) x = xMin;
        if (x > xMax) x = xMax;

        estaciones.Add(x);
    }

    private double ObtenerZDesdePerfilCara(
        List<SegmentoPerfilCara> perfil,
        double estacion,
        double respaldo)
    {
        if (perfil == null || perfil.Count == 0)
            return respaldo;

        SegmentoPerfilCara seg = perfil
            .Where(s => s != null)
            .OrderBy(s => DistanciaEstacionASegmentoPerfil(estacion, s))
            .FirstOrDefault();

        if (seg == null)
            return respaldo;

        double dx = seg.X1 - seg.X0;

        if (Math.Abs(dx) <= Tol)
            return (seg.Z0 + seg.Z1) / 2.0;

        double t = (estacion - seg.X0) / dx;

        if (t < -0.001) t = -0.001;
        if (t > 1.001) t = 1.001;

        return seg.Z0 + (seg.Z1 - seg.Z0) * t;
    }


    // =========================================================
    // V11.6 - PIEZA CONTINUA ENTRE VARIOS HOSTS
    // =========================================================
    // Una pieza comercial es UNA sola armadura aunque atraviese varias vigas.
    // El host de Revit se usa únicamente como anfitrión de referencia; nunca
    // se utiliza para recortar la geometría de la pieza.
    private bool EsSerieMultiHostRectaContinuaMYG(
        DatosSerieVigas datos)
    {
        if (datos == null ||
            datos.TramosRecorrido == null)
        {
            return false;
        }

        List<TramoRecorridoSerie> tramos =
            datos.TramosRecorrido
                .Where(t =>
                    t != null &&
                    t.Viga != null &&
                    t.Viga.Elemento != null)
                .OrderBy(t =>
                    Math.Min(
                        t.XInicioSerie,
                        t.XFinSerie))
                .ToList();

        if (tramos.Count <= 1)
            return false;

        // Si existe un cambio real de dirección entre vigas, la pieza puede
        // seguir siendo continua, pero necesita la lógica proyectada existente.
        // Este helper se reserva al caso recto para simplificar los puntos
        // intermedios del vacío y mantener el shape-driven.
        if (SerieTieneQuiebreEntreTramosLongitudinal(datos))
            return false;

        return true;
    }


    private bool EsHostValidoParaArmaduraMYG(
        Element elemento)
    {
        if (elemento == null)
            return false;

        try
        {
            return RebarHostData.GetRebarHostData(
                elemento) != null;
        }
        catch
        {
            return false;
        }
    }


    private void AgregarHostCandidatoPiezaContinuaMYG(
        List<Element> resultado,
        HashSet<ElementId> ids,
        Element host)
    {
        if (resultado == null ||
            ids == null ||
            host == null ||
            !EsHostValidoParaArmaduraMYG(host))
        {
            return;
        }

        ElementId id = host.Id;

        if (id == null || ids.Contains(id))
            return;

        ids.Add(id);
        resultado.Add(host);
    }


    private List<Element>
        ObtenerHostsCandidatosPiezaContinuaLongitudinalMYG(
            DatosSerieVigas datos,
            SegmentoAceroLongitudinal segmento)
    {
        List<Element> resultado =
            new List<Element>();

        HashSet<ElementId> ids =
            new HashSet<ElementId>();

        if (datos == null)
            return resultado;

        if (segmento == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0)
        {
            AgregarHostCandidatoPiezaContinuaMYG(
                resultado,
                ids,
                datos.Host);

            return resultado;
        }

        List<TramoRecorridoSerie> tramos =
            datos.TramosRecorrido
                .Where(t =>
                    t != null &&
                    t.Viga != null &&
                    t.Viga.Elemento != null)
                .OrderBy(t =>
                    Math.Min(
                        t.XInicioSerie,
                        t.XFinSerie))
                .ToList();

        if (tramos.Count == 0)
        {
            AgregarHostCandidatoPiezaContinuaMYG(
                resultado,
                ids,
                datos.Host);

            return resultado;
        }

        double xInicio = segmento.XInicio;
        double xFin = segmento.XFin;
        double xMin = Math.Min(xInicio, xFin);
        double xMax = Math.Max(xInicio, xFin);

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Centimeters);

        // 1) Prioridad absoluta: host que contiene el INICIO físico de la pieza.
        // Esto permite que la barra salga de ese host y continúe a través del
        // apoyo/vacío sin convertirse en varios Rebar.
        foreach (TramoRecorridoSerie tramo in tramos)
        {
            double a = Math.Min(
                tramo.XInicioSerie,
                tramo.XFinSerie);
            double b = Math.Max(
                tramo.XInicioSerie,
                tramo.XFinSerie);

            if (xInicio >= a - tolerancia &&
                xInicio <= b + tolerancia)
            {
                AgregarHostCandidatoPiezaContinuaMYG(
                    resultado,
                    ids,
                    tramo.Viga.Elemento);
            }
        }

        // 2) Si el inicio cae en un vacío, se prioriza el host inmediatamente
        // anterior y luego el siguiente.
        if (resultado.Count == 0)
        {
            TramoRecorridoSerie anterior =
                tramos
                    .Where(t =>
                        Math.Max(
                            t.XInicioSerie,
                            t.XFinSerie) <=
                        xInicio + tolerancia)
                    .OrderByDescending(t =>
                        Math.Max(
                            t.XInicioSerie,
                            t.XFinSerie))
                    .FirstOrDefault();

            if (anterior != null)
            {
                AgregarHostCandidatoPiezaContinuaMYG(
                    resultado,
                    ids,
                    anterior.Viga.Elemento);
            }

            TramoRecorridoSerie siguiente =
                tramos
                    .Where(t =>
                        Math.Min(
                            t.XInicioSerie,
                            t.XFinSerie) >=
                        xInicio - tolerancia)
                    .OrderBy(t =>
                        Math.Min(
                            t.XInicioSerie,
                            t.XFinSerie))
                    .FirstOrDefault();

            if (siguiente != null)
            {
                AgregarHostCandidatoPiezaContinuaMYG(
                    resultado,
                    ids,
                    siguiente.Viga.Elemento);
            }
        }

        // 3) Host que contiene el final.
        foreach (TramoRecorridoSerie tramo in tramos)
        {
            double a = Math.Min(
                tramo.XInicioSerie,
                tramo.XFinSerie);
            double b = Math.Max(
                tramo.XInicioSerie,
                tramo.XFinSerie);

            if (xFin >= a - tolerancia &&
                xFin <= b + tolerancia)
            {
                AgregarHostCandidatoPiezaContinuaMYG(
                    resultado,
                    ids,
                    tramo.Viga.Elemento);
            }
        }

        // 4) Resto de hosts realmente atravesados por la pieza,
        // ordenados por longitud coincidente.
        foreach (TramoRecorridoSerie tramo in tramos
            .OrderByDescending(t =>
            {
                double a = Math.Min(
                    t.XInicioSerie,
                    t.XFinSerie);
                double b = Math.Max(
                    t.XInicioSerie,
                    t.XFinSerie);

                return Math.Max(
                    0.0,
                    Math.Min(xMax, b) -
                    Math.Max(xMin, a));
            }))
        {
            double a = Math.Min(
                tramo.XInicioSerie,
                tramo.XFinSerie);
            double b = Math.Max(
                tramo.XInicioSerie,
                tramo.XFinSerie);

            double coincidencia =
                Math.Max(
                    0.0,
                    Math.Min(xMax, b) -
                    Math.Max(xMin, a));

            if (coincidencia > Tol)
            {
                AgregarHostCandidatoPiezaContinuaMYG(
                    resultado,
                    ids,
                    tramo.Viga.Elemento);
            }
        }

        AgregarHostCandidatoPiezaContinuaMYG(
            resultado,
            ids,
            datos.Host);

        return resultado;
    }


    private Element ObtenerHostCanonicoPiezaContinuaLongitudinalMYG(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento)
    {
        return ObtenerHostsCandidatosPiezaContinuaLongitudinalMYG(
                datos,
                segmento)
            .FirstOrDefault();
    }


    private bool EmpalmeYQuiebreDentroMismoTramoConcretoMYG(
        DatosSerieVigas datos,
        double inicioEmpalme,
        double longitudEmpalme,
        double reservaQuiebre)
    {
        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0)
        {
            return true;
        }

        double finNecesario =
            inicioEmpalme +
            Math.Max(0.0, longitudEmpalme) +
            Math.Max(0.0, reservaQuiebre);

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        foreach (TramoRecorridoSerie tramo in
            datos.TramosRecorrido)
        {
            if (tramo == null ||
                tramo.Viga == null ||
                tramo.Viga.Elemento == null)
            {
                continue;
            }

            double a = Math.Min(
                tramo.XInicioSerie,
                tramo.XFinSerie);

            double b = Math.Max(
                tramo.XInicioSerie,
                tramo.XFinSerie);

            if (inicioEmpalme >= a - tolerancia &&
                finNecesario <= b + tolerancia)
            {
                return true;
            }
        }

        return false;
    }


    // =========================================================
    // HOST REAL PARA CADA BARRA GENERADA POR EMPALME
    // =========================================================
    // La serie puede estar formada por varias vigas independientes. Antes se
    // utilizaba datos.Host para todos los segmentos; por eso, cuando un tramo
    // posterior al empalme quedaba totalmente dentro de otra viga, Revit lo
    // rechazaba con el aviso "La armadura se encuentra totalmente fuera de su
    // anfitrión".
    //
    // Se elige la viga cuyo intervalo del recorrido acumulado tiene la mayor
    // coincidencia con el segmento. Si el segmento queda fuera de los límites
    // por un desarrollo extremo, se utiliza la viga más cercana a su punto medio.
    private Element ObtenerHostParaSegmentoLongitudinalMYG(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento)
    {
        if (datos == null)
            return null;

        Element hostRespaldo = datos.Host;

        if (segmento == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0)
        {
            return hostRespaldo;
        }

        double segmentoMin =
            Math.Min(
                segmento.XInicio,
                segmento.XFin);

        double segmentoMax =
            Math.Max(
                segmento.XInicio,
                segmento.XFin);

        double segmentoCentro =
            (segmentoMin + segmentoMax) / 2.0;

        Element mejorHost = null;
        double mayorCoincidencia = -1.0;
        double menorDistanciaCentro = double.MaxValue;

        foreach (TramoRecorridoSerie tramo
            in datos.TramosRecorrido)
        {
            if (tramo == null ||
                tramo.Viga == null ||
                tramo.Viga.Elemento == null)
            {
                continue;
            }

            Element candidato =
                tramo.Viga.Elemento;

            try
            {
                if (RebarHostData.GetRebarHostData(
                    candidato) == null)
                {
                    continue;
                }
            }
            catch
            {
                continue;
            }

            double tramoMin =
                Math.Min(
                    tramo.XInicioSerie,
                    tramo.XFinSerie);

            double tramoMax =
                Math.Max(
                    tramo.XInicioSerie,
                    tramo.XFinSerie);

            if (tramoMax <= tramoMin + Tol)
                continue;

            double coincidencia =
                Math.Max(
                    0.0,
                    Math.Min(
                        segmentoMax,
                        tramoMax) -
                    Math.Max(
                        segmentoMin,
                        tramoMin));

            double distanciaCentro;

            if (segmentoCentro < tramoMin)
            {
                distanciaCentro =
                    tramoMin - segmentoCentro;
            }
            else if (segmentoCentro > tramoMax)
            {
                distanciaCentro =
                    segmentoCentro - tramoMax;
            }
            else
            {
                distanciaCentro = 0.0;
            }

            bool mejoraCoincidencia =
                coincidencia >
                mayorCoincidencia + Tol;

            bool empateCoincidencia =
                Math.Abs(
                    coincidencia -
                    mayorCoincidencia) <= Tol;

            if (mejoraCoincidencia ||
                (empateCoincidencia &&
                 distanciaCentro <
                 menorDistanciaCentro - Tol))
            {
                mejorHost = candidato;
                mayorCoincidencia = coincidencia;
                menorDistanciaCentro = distanciaCentro;
            }
        }

        return mejorHost ?? hostRespaldo;
    }



    // =========================================================
    // DATOS LOCALES DE LA VIGA ANFITRIONA DEL SEGMENTO
    // =========================================================
    // Una serie puede contener vigas con anchos, ejes locales o sentidos
    // distintos. El acero posterior a un empalme debe usar el ancho y la
    // normal de SU propio anfitrión; de lo contrario, la barra semilla puede
    // quedar fuera de la segunda viga y Revit no crea el conjunto.
    private DatosViga ObtenerDatosVigaParaHostLongitudinalMYG(
        DatosSerieVigas datos,
        Element host)
    {
        if (datos == null || host == null || datos.Vigas == null)
            return null;

        foreach (DatosViga viga in datos.Vigas)
        {
            if (viga == null || viga.Elemento == null)
                continue;

            if (viga.Elemento.Id == host.Id)
                return viga;
        }

        return null;
    }

    private void ObtenerDistribucionLocalHostLongitudinalMYG(
        DatosSerieVigas datos,
        Element host,
        double margenLateral,
        double yInicialRespaldo,
        double yFinalRespaldo,
        XYZ normalRespaldo,
        out double yInicial,
        out double yFinal,
        out double longitudDistribucion,
        out XYZ normalDistribucion)
    {
        yInicial = yInicialRespaldo;
        yFinal = yFinalRespaldo;
        longitudDistribucion = Math.Max(0.0, yFinalRespaldo - yInicialRespaldo);
        normalDistribucion = normalRespaldo;

        DatosViga vigaHost =
            ObtenerDatosVigaParaHostLongitudinalMYG(datos, host);

        if (vigaHost == null)
            return;

        double anchoLocal = vigaHost.Ancho;

        if (anchoLocal <= Tol)
            anchoLocal = vigaHost.YMax - vigaHost.YMin;

        if (anchoLocal <= Tol)
            return;

        double localMin = -anchoLocal / 2.0 + margenLateral;
        double localMax = anchoLocal / 2.0 - margenLateral;

        if (localMax <= localMin + Tol)
            return;

        yInicial = localMin;
        yFinal = localMax;
        longitudDistribucion = localMax - localMin;

        if (vigaHost.YAxis != null &&
            vigaHost.YAxis.GetLength() > Tol)
        {
            normalDistribucion = vigaHost.YAxis.Normalize();
        }
    }

    // =========================================================
    // VALIDACIÓN DE PIEZAS COMERCIALES FRENTE A LOS HOSTS
    // =========================================================
    // Una pieza de barra completamente ubicada en el vacío no puede pertenecer
    // a una de las vigas seleccionadas. Antes, una zona RNE temprana podía
    // provocar justamente eso: la primera barra terminaba muy pronto y la
    // siguiente quedaba totalmente dentro del tramo sin viga.
    private bool SegmentoTieneCoincidenciaConAlgunaVigaMYG(
        DatosSerieVigas datos,
        double inicio,
        double fin)
    {
        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count == 0)
        {
            return false;
        }

        double segmentoMin =
            Math.Min(inicio, fin);

        double segmentoMax =
            Math.Max(inicio, fin);

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

        foreach (TramoRecorridoSerie tramo
            in datos.TramosRecorrido)
        {
            if (tramo == null ||
                tramo.Viga == null ||
                tramo.Viga.Elemento == null)
            {
                continue;
            }

            double tramoMin =
                Math.Min(
                    tramo.XInicioSerie,
                    tramo.XFinSerie);

            double tramoMax =
                Math.Max(
                    tramo.XInicioSerie,
                    tramo.XFinSerie);

            double coincidencia =
                Math.Min(
                    segmentoMax,
                    tramoMax) -
                Math.Max(
                    segmentoMin,
                    tramoMin);

            if (coincidencia > tolerancia)
                return true;
        }

        return false;
    }

    private bool EstacionSerieDentroDeAlgunaVigaMYG(
        DatosSerieVigas datos,
        double estacion)
    {
        if (datos == null ||
            datos.TramosRecorrido == null)
        {
            return false;
        }

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

        foreach (TramoRecorridoSerie tramo
            in datos.TramosRecorrido)
        {
            if (tramo == null)
                continue;

            double tramoMin =
                Math.Min(
                    tramo.XInicioSerie,
                    tramo.XFinSerie);

            double tramoMax =
                Math.Max(
                    tramo.XInicioSerie,
                    tramo.XFinSerie);

            if (estacion >= tramoMin - tolerancia &&
                estacion <= tramoMax + tolerancia)
            {
                return true;
            }
        }

        return false;
    }

    private List<SegmentoAceroLongitudinal> ConstruirSegmentosLongitudinales(
        DatosSerieVigas datos,
        int tipoRutaEmpalme,
        double xInicio,
        double xFin,
        bool crearEmpalmes,
        double longitudBarra,
        double longitudEmpalme,
        double longitudGanchoInicio,
        double longitudGanchoFin,
        double diametro,
        RebarBarType barType)
    {
        List<SegmentoAceroLongitudinal> segmentos =
            new List<SegmentoAceroLongitudinal>();

        if (xFin <= xInicio + Tol)
            return segmentos;

        double longitudTotal = xFin - xInicio;

        double descuentoCurvaturaInicio =
            longitudGanchoInicio > Tol
                ? CalcularDescuentoCurvatura90(barType, diametro)
                : 0.0;

        double descuentoCurvaturaFin =
            longitudGanchoFin > Tol
                ? CalcularDescuentoCurvatura90(barType, diametro)
                : 0.0;

        double longitudRealSinEmpalmes =
            longitudTotal +
            longitudGanchoInicio +
            longitudGanchoFin -
            descuentoCurvaturaInicio -
            descuentoCurvaturaFin;

        bool requiereEmpalmePorLongitud =
            longitudBarra > Tol &&
            longitudRealSinEmpalmes > longitudBarra + Tol;

        bool aplicarEmpalmes =
            crearEmpalmes ||
            requiereEmpalmePorLongitud;

        if (!aplicarEmpalmes ||
            longitudBarra <= Tol ||
            longitudEmpalme <= Tol ||
            longitudBarra <= longitudEmpalme + Tol ||
            longitudRealSinEmpalmes <= longitudBarra + Tol)
        {
            segmentos.Add(new SegmentoAceroLongitudinal(xInicio, xFin));
            MarcarPrimerYUltimoSegmento(segmentos);
            return segmentos;
        }

        List<IntervaloColumnaSerie> zonasPermitidas = ConstruirZonasPermitidasEmpalmeRNE(
            datos,
            tipoRutaEmpalme,
            xInicio,
            xFin,
            longitudEmpalme);

        double cursor = xInicio;
        bool primero = true;

        // V11.8:
        // No existe respaldo colineal. Si hay empalme, la pieza siguiente
        // siempre debe resolver su quiebre dentro del mismo elemento Rebar.
        int seguridad = 0;
        int maxSegmentos = 500;

        while (cursor < xFin - Tol && seguridad < maxSegmentos)
        {
            seguridad++;

            double hookInicioSegmento = primero ? longitudGanchoInicio : 0.0;

            double descuentoHookInicio =
                hookInicioSegmento > Tol
                    ? CalcularDescuentoCurvatura90(barType, diametro)
                    : 0.0;

            double compensacionEmpalmeInicio =
                !primero
                    ? CalcularCompensacionEmpalmeInicio(barType, diametro)
                    : 0.0;

            double restanteRecto = xFin - cursor;

            double longitudRealRestante =
                restanteRecto -
                compensacionEmpalmeInicio +
                hookInicioSegmento +
                longitudGanchoFin -
                descuentoHookInicio -
                descuentoCurvaturaFin;

            if (longitudRealRestante <= longitudBarra + Tol)
            {
                SegmentoAceroLongitudinal ultimo =
                    new SegmentoAceroLongitudinal(cursor, xFin);

                ultimo.TieneEmpalmeInicio = !primero;
                ultimo.EmpalmeInicioColinealSeguro = false;

                segmentos.Add(ultimo);
                break;
            }

            double longitudRectaDisponible =
                longitudBarra -
                hookInicioSegmento +
                descuentoHookInicio +
                compensacionEmpalmeInicio;

            if (longitudRectaDisponible <= longitudEmpalme + Tol)
                longitudRectaDisponible = longitudBarra;

            double segInicio = cursor;
            double segFinDeseado = segInicio + longitudRectaDisponible;

            if (segFinDeseado > xFin)
                segFinDeseado = xFin;

            if (segFinDeseado <= segInicio + Tol)
                break;

            // =========================================================
            // V11.8 - EMPALME CON QUIEBRE OBLIGATORIO E INTEGRADO
            // =========================================================
            // Nunca se permite un empalme colineal como respaldo.
            // La pieza siguiente debe tener SIEMPRE:
            //
            //   1) tramo de traslape desplazado,
            //   2) diagonal,
            //   3) continuación sobre el eje original.
            //
            // Todo ello será UNA ÚNICA armadura física.
            double reservaQuiebreObjetivo =
                ObtenerReservaQuiebreEmpalmeDentroTercio(diametro);

            double reservaQuiebreMinima =
                ObtenerReservaMinimaQuiebreEmpalmeMYG(diametro);

            IntervaloColumnaSerie empalmePermitido =
                BuscarEmpalmePermitidoRNE(
                    datos,
                    zonasPermitidas,
                    segInicio,
                    segFinDeseado,
                    xFin,
                    longitudEmpalme,
                    reservaQuiebreObjetivo,
                    longitudEmpalme + reservaQuiebreObjetivo,
                    longitudBarra,
                    tipoRutaEmpalme);

            // Si no entra la diagonal objetivo de 20 cm, se permite reducirla
            // solamente hasta la longitud mínima geométricamente segura.
            if (empalmePermitido == null)
            {
                empalmePermitido =
                    BuscarEmpalmePermitidoRNE(
                        datos,
                        zonasPermitidas,
                        segInicio,
                        segFinDeseado,
                        xFin,
                        longitudEmpalme,
                        reservaQuiebreMinima,
                        longitudEmpalme + reservaQuiebreMinima,
                        longitudBarra,
                        tipoRutaEmpalme);
            }

            // V11.10: último intento dentro de los mismos tercios,
            // usando una reserva geométrica más corta pero todavía con quiebre.
            if (empalmePermitido == null &&
                zonasPermitidas != null &&
                zonasPermitidas.Count > 0)
            {
                double reservaEmergencia =
                    ObtenerReservaEmergenciaQuiebreEmpalmeMYG(
                        diametro);

                empalmePermitido =
                    BuscarEmpalmePermitidoRNE(
                        datos,
                        zonasPermitidas,
                        segInicio,
                        segFinDeseado,
                        xFin,
                        longitudEmpalme,
                        reservaEmergencia,
                        longitudEmpalme + reservaEmergencia,
                        longitudBarra,
                        tipoRutaEmpalme);
            }

            // Solo usar el respaldo comercial cuando no existe información
            // reglamentaria utilizable.
            if (empalmePermitido == null &&
                (zonasPermitidas == null ||
                 zonasPermitidas.Count == 0))
            {
                IntervaloColumnaSerie respaldo =
                    BuscarEmpalmeRespaldoLongitudComercialMYG(
                        datos,
                        segInicio,
                        segFinDeseado,
                        xFin,
                        longitudEmpalme);

                if (respaldo != null &&
                    EmpalmeYQuiebreDentroMismoTramoConcretoMYG(
                        datos,
                        respaldo.Min,
                        longitudEmpalme,
                        reservaQuiebreMinima))
                {
                    empalmePermitido = respaldo;
                }
            }

            // Si no hay espacio para un quiebre real, NO se genera una pieza
            // colineal ni una diagonal independiente. Se detiene la segmentación
            // para que la subtransacción del grupo haga rollback y no deje acero
            // parcial o conteos falsos.
            if (empalmePermitido == null)
            {
                segmentos.Clear();
                return segmentos;
            }

            double cursorSiguiente =
                empalmePermitido.Min;

            double segFin =
                Math.Min(
                    empalmePermitido.Max,
                    xFin);

            if (segFin > xFin)
                segFin = xFin;

            if (segFin <= segInicio + Tol)
                break;

            SegmentoAceroLongitudinal seg =
                new SegmentoAceroLongitudinal(segInicio, segFin);

            seg.TieneEmpalmeInicio = !primero;
            seg.EmpalmeInicioColinealSeguro = false;

            segmentos.Add(seg);

            if (segFin >= xFin - Tol)
                break;

            cursor = cursorSiguiente;

            if (cursor <= segInicio + Tol)
                break;

            primero = false;
        }

        // V11.9:
        // Si se requerían empalmes y la serie no llegó hasta el final,
        // no se devuelve una barra única ni una serie parcial.
        if (segmentos.Count == 0)
            return segmentos;

        SegmentoAceroLongitudinal ultimoGenerado =
            segmentos[segmentos.Count - 1];

        if (ultimoGenerado == null ||
            ultimoGenerado.XFin < xFin - Tol ||
            seguridad >= maxSegmentos)
        {
            segmentos.Clear();
            return segmentos;
        }

        MarcarPrimerYUltimoSegmento(segmentos);

        return segmentos;
    }

    private List<IntervaloColumnaSerie> ConstruirZonasPermitidasEmpalmeRNE(
        DatosSerieVigas datos,
        int tipoRutaEmpalme,
        double xInicio,
        double xFin,
        double longitudEmpalme)
    {
        List<IntervaloColumnaSerie> zonas =
            new List<IntervaloColumnaSerie>();

        if (xFin <= xInicio + Tol)
            return zonas;

        // =========================================================
        // V11.12 - LOS TERCIOS PERTENECEN A CADA TRAMO DE VIGA
        // =========================================================
        // La regla de ubicación del empalme se evalúa TRAMO POR TRAMO:
        //
        //   SUPERIOR Y CENTRAL -> inicio del empalme dentro del TERCIO CENTRAL.
        //   INFERIOR -> inicio del empalme dentro de cualquiera de los
        //               DOS TERCIOS EXTREMOS.
        //
        // Los desarrollos inicial/final pueden salir de la serie de vigas,
        // pero NO cambian la posición de los tercios del tramo.
        //
        // Se prioriza TramosRecorrido porque representa exactamente los
        // cuerpos de viga seleccionados. Las columnas se usan únicamente
        // como respaldo cuando no existe información de tramos.
        if (datos != null &&
            datos.TramosRecorrido != null &&
            datos.TramosRecorrido.Count > 0)
        {
            foreach (TramoRecorridoSerie tramo in
                datos.TramosRecorrido
                    .Where(t => t != null)
                    .OrderBy(t => Math.Min(
                        t.XInicioSerie,
                        t.XFinSerie)))
            {
                double tramoInicio =
                    Math.Min(
                        tramo.XInicioSerie,
                        tramo.XFinSerie);

                double tramoFin =
                    Math.Max(
                        tramo.XInicioSerie,
                        tramo.XFinSerie);

                if (tramoFin <= tramoInicio + Tol)
                    continue;

                AgregarZonasPermitidasPorTercioRNE(
                    zonas,
                    tramoInicio,
                    tramoFin,
                    tipoRutaEmpalme,
                    xInicio,
                    xFin);
            }
        }

        // Respaldo: si por alguna razón no se pudieron construir tercios
        // desde los tramos reales, se usan las luces entre columnas.
        if (zonas.Count == 0 &&
            datos != null &&
            datos.Columnas != null &&
            datos.Columnas.Count >= 2)
        {
            List<IntervaloColumnaSerie> columnas =
                datos.Columnas
                    .Where(c => c != null)
                    .OrderBy(c => c.Min)
                    .ToList();

            for (int i = 0; i < columnas.Count - 1; i++)
            {
                double luzInicio = columnas[i].Max;
                double luzFin = columnas[i + 1].Min;

                AgregarZonasPermitidasPorTercioRNE(
                    zonas,
                    luzInicio,
                    luzFin,
                    tipoRutaEmpalme,
                    xInicio,
                    xFin);
            }
        }

        if (zonas.Count == 0)
        {
            double respaldoInicio = xInicio;
            double respaldoFin = xFin;

            if (datos != null)
            {
                if (datos.LuzLibreFinGlobal >
                    datos.LuzLibreInicioGlobal + Tol)
                {
                    respaldoInicio =
                        datos.LuzLibreInicioGlobal;

                    respaldoFin =
                        datos.LuzLibreFinGlobal;
                }
                else if (datos.SolidoMaxGlobal >
                         datos.SolidoMinGlobal + Tol)
                {
                    respaldoInicio =
                        datos.SolidoMinGlobal;

                    respaldoFin =
                        datos.SolidoMaxGlobal;
                }
            }

            AgregarZonasPermitidasPorTercioRNE(
                zonas,
                respaldoInicio,
                respaldoFin,
                tipoRutaEmpalme,
                xInicio,
                xFin);
        }

        return zonas
            .Where(z =>
                z != null &&
                z.Max > z.Min + Tol)
            .OrderBy(z => z.Min)
            .ToList();
    }

    private void AgregarZonasPermitidasPorTercioRNE(
        List<IntervaloColumnaSerie> zonas,
        double luzInicio,
        double luzFin,
        int tipoRutaEmpalme,
        double limiteInicio,
        double limiteFin)
    {
        if (zonas == null)
            return;

        double longitudLuz = luzFin - luzInicio;

        if (longitudLuz <= Tol)
            return;

        double tercio1Fin = luzInicio + longitudLuz / 3.0;
        double tercio2Inicio = tercio1Fin;
        double tercio2Fin = luzInicio + 2.0 * longitudLuz / 3.0;
        double tercio3Inicio = tercio2Fin;

        if (tipoRutaEmpalme >= 0)
        {
            // Acero SUPERIOR y CENTRAL: empalme solo en el tercio central.
            // tipoRutaEmpalme: Superior = +1 | Central = 0.
            AgregarZonaPermitidaRNE(zonas, tercio2Inicio, tercio2Fin, limiteInicio, limiteFin);
        }
        else
        {
            // Acero INFERIOR: empalme solo en los tercios extremos,
            // cerca de los nodos/apoyos.
            AgregarZonaPermitidaRNE(zonas, luzInicio, tercio1Fin, limiteInicio, limiteFin);
            AgregarZonaPermitidaRNE(zonas, tercio3Inicio, luzFin, limiteInicio, limiteFin);
        }
    }

    private void AgregarZonaPermitidaRNE(
        List<IntervaloColumnaSerie> zonas,
        double inicio,
        double fin,
        double limiteInicio,
        double limiteFin)
    {
        if (zonas == null)
            return;

        double a = Math.Max(inicio, limiteInicio);
        double b = Math.Min(fin, limiteFin);

        if (b > a + Tol)
            zonas.Add(new IntervaloColumnaSerie(a, b));
    }

    private IntervaloColumnaSerie BuscarEmpalmePermitidoRNE(
        DatosSerieVigas datos,
        List<IntervaloColumnaSerie> zonasPermitidas,
        double segInicio,
        double segFinDeseado,
        double xFinTotal,
        double longitudEmpalme,
        double reservaQuiebreDentroTercio,
        double longitudMinimaPiezaSiguiente,
        double longitudBarra,
        int tipoRutaEmpalme)
    {
        if (zonasPermitidas == null ||
            zonasPermitidas.Count == 0 ||
            longitudEmpalme <= Tol)
        {
            return null;
        }

        double reservaQuiebre =
            Math.Max(
                0.0,
                reservaQuiebreDentroTercio);

        double minimoSiguiente =
            Math.Max(
                longitudEmpalme,
                Math.Max(
                    0.0,
                    longitudMinimaPiezaSiguiente));

        double inicioMinimo =
            segInicio + Tol;

        // Posición que usaríamos si solo gobernara la longitud comercial:
        // la pieza siguiente comienza aquí y se traslapa longitudEmpalme.
        double inicioDeseado =
            segFinDeseado -
            longitudEmpalme;

        // La pieza ACTUAL no puede superar su longitud comercial.
        double inicioMaximoPorBarra =
            segFinDeseado -
            longitudEmpalme;

        // Debe quedar longitud suficiente para materializar la pieza siguiente.
        double inicioMaximoPorContinuidad =
            xFinTotal -
            minimoSiguiente;

        IntervaloColumnaSerie mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (IntervaloColumnaSerie zona in zonasPermitidas)
        {
            if (zona == null)
                continue;

            // =====================================================
            // V11.12 - CLAVE DE LA CORRECCIÓN
            // =====================================================
            // El TERCIO controla la POSICIÓN DEL INICIO DEL EMPALME,
            // NO obliga a que TODA la longitud de traslape + diagonal
            // quede contenida dentro de ese tercio.
            //
            // Ejemplo real del diagnóstico:
            // tramo = 3.63 m -> tercio = 1.21 m
            // Ls superior = 1.63 m
            //
            // Es imposible meter 1.63 m completos dentro de un tercio de
            // 1.21 m, aunque el empalme sea perfectamente construible dentro
            // del tramo. Esa era la causa de los 0 segmentos.
            double zonaInicio =
                Math.Max(
                    zona.Min,
                    inicioMinimo);

            // V11.43 - REGLA RÍGIDA PARA ACERO INFERIOR.
            //
            // Para inferiores no basta con que el INICIO del empalme esté en
            // un tercio extremo: TODO el traslape debe quedar fuera del tercio
            // central. Si la longitud comercial llevaría el empalme hacia el
            // centro, se adelanta el corte hasta el último punto posible del
            // tercio extremo anterior. Acortar una pieza es válido; superar la
            // longitud comercial no lo es.
            //
            // Superiores y centrales conservan la regla V11.12: el inicio del
            // empalme debe caer en el tercio central, aunque el traslape pueda
            // sobrepasar la línea 1/3-2/3 cuando la longitud de empalme sea
            // mayor que el propio tercio.
            double limiteZonaPorRegla = zona.Max;

            if (tipoRutaEmpalme < 0)
            {
                limiteZonaPorRegla =
                    zona.Max - longitudEmpalme;
            }

            double zonaFinParaInicio =
                Math.Min(
                    limiteZonaPorRegla,
                    Math.Min(
                        inicioMaximoPorBarra,
                        inicioMaximoPorContinuidad));

            if (zonaFinParaInicio <
                zonaInicio - Tol)
            {
                continue;
            }

            double inicioPrincipal =
                Math.Max(
                    zonaInicio,
                    Math.Min(
                        inicioDeseado,
                        zonaFinParaInicio));

            double[] candidatos =
                new double[]
                {
                    inicioPrincipal,
                    zonaInicio,
                    zonaFinParaInicio,
                    (zonaInicio + zonaFinParaInicio) * 0.5
                };

            foreach (double candidato in candidatos)
            {
                if (candidato <=
                    segInicio + Tol)
                {
                    continue;
                }

                // El INICIO debe pertenecer al tercio permitido.
                if (candidato <
                        zona.Min - Tol ||
                    candidato >
                        zona.Max + Tol)
                {
                    continue;
                }

                // V11.43: para inferiores, TODO el traslape debe permanecer
                // dentro del tercio extremo elegido. Nunca se permite que la
                // parte roja del empalme invada el tercio central.
                if (tipoRutaEmpalme < 0 &&
                    candidato + longitudEmpalme > zona.Max + Tol)
                {
                    continue;
                }

                // El traslape completo sí debe existir dentro del intervalo
                // longitudinal total de la serie.
                if (candidato +
                        longitudEmpalme >
                    xFinTotal + Tol)
                {
                    continue;
                }

                if (datos != null)
                {
                    double longitudRevision =
                        longitudBarra > Tol
                            ? longitudBarra
                            : minimoSiguiente;

                    double siguienteFinTentativo =
                        Math.Min(
                            xFinTotal,
                            candidato +
                            Math.Max(
                                minimoSiguiente,
                                longitudRevision));

                    if (!SegmentoTieneCoincidenciaConAlgunaVigaMYG(
                            datos,
                            candidato,
                            siguienteFinTentativo))
                    {
                        continue;
                    }

                    // El tercio solamente gobierna el INICIO.
                    // La longitud de traslape y el quiebre pueden atravesar
                    // el límite 1/3-2/3, pero deben quedar físicamente dentro
                    // de UN MISMO tramo de concreto.
                    if (!EmpalmeYQuiebreDentroMismoTramoConcretoMYG(
                            datos,
                            candidato,
                            longitudEmpalme,
                            reservaQuiebre))
                    {
                        continue;
                    }
                }

                double distancia =
                    Math.Abs(
                        candidato -
                        inicioDeseado);

                if (distancia <
                    mejorDistancia)
                {
                    mejorDistancia =
                        distancia;

                    mejor =
                        new IntervaloColumnaSerie(
                            candidato,
                            candidato +
                            longitudEmpalme);
                }
            }
        }

        return mejor;
    }


    private IntervaloColumnaSerie
        BuscarEmpalmeRespaldoLongitudComercialMYG(
            DatosSerieVigas datos,
            double segInicio,
            double segFinDeseado,
            double xFinTotal,
            double longitudEmpalme)
    {
        if (segFinDeseado <= segInicio + Tol ||
            longitudEmpalme <= Tol)
        {
            return null;
        }

        double finMaximo =
            Math.Min(
                segFinDeseado,
                xFinTotal);

        double inicioEmpalme =
            finMaximo -
            longitudEmpalme;

        if (inicioEmpalme <= segInicio + Tol)
            return null;

        // No se adelanta el corte hasta un tercio RNE anterior cuando eso genera
        // una barra intermedia totalmente dentro del vacío. Esta posición hace
        // que la pieza actual llegue exactamente al máximo comercial y que la
        // siguiente empiece con el traslape necesario.
        return new IntervaloColumnaSerie(
            inicioEmpalme,
            finMaximo);
    }


    private double ObtenerReservaQuiebreEmpalmeDentroTercio(
        double diametro)
    {
        // V11.5:
        // 20 cm de diagonal objetivo + tramo recto de salida.
        // Para barras grandes se incrementa automáticamente la reserva.
        double diagonalObjetivo =
            UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

        double rectoSalidaMinimo =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        if (diametro > Tol)
        {
            diagonalObjetivo =
                Math.Max(
                    diagonalObjetivo,
                    diametro * 4.0);

            rectoSalidaMinimo =
                Math.Max(
                    rectoSalidaMinimo,
                    diametro * 2.0);
        }

        return diagonalObjetivo + rectoSalidaMinimo;
    }


    private double ObtenerReservaEmergenciaQuiebreEmpalmeMYG(
        double diametro)
    {
        double diagonal =
            UnitUtils.ConvertToInternalUnits(
                3.0,
                UnitTypeId.Centimeters);

        double salida =
            UnitUtils.ConvertToInternalUnits(
                3.0,
                UnitTypeId.Centimeters);

        if (diametro > Tol)
        {
            diagonal = Math.Max(diagonal, diametro * 2.0);
            salida = Math.Max(salida, diametro);
        }

        return diagonal + salida;
    }


    private double ObtenerReservaMinimaQuiebreEmpalmeMYG(
        double diametro)
    {
        // Mínimo permitido para mantener el quiebre como parte del mismo acero.
        // Se reserva una diagonal corta pero resoluble y un tramo recto posterior.
        double diagonalMinima =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        double salidaMinima =
            UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

        if (diametro > Tol)
        {
            diagonalMinima =
                Math.Max(
                    diagonalMinima,
                    diametro * 4.0);

            salidaMinima =
                Math.Max(
                    salidaMinima,
                    diametro * 2.0);
        }

        return diagonalMinima + salidaMinima;
    }


    private bool TryObtenerLongitudDiagonalQuiebreSeguraMYG(
        double espacioDespuesEmpalme,
        double desfaseEmpalme,
        out double longitudDiagonal)
    {
        longitudDiagonal = 0.0;

        if (espacioDespuesEmpalme <= Tol ||
            desfaseEmpalme <= Tol)
        {
            return false;
        }

        double diagonalObjetivo =
            UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

        double diagonalMinima =
            UnitUtils.ConvertToInternalUnits(
                3.0,
                UnitTypeId.Centimeters);

        double rectoSalidaMinimo =
            UnitUtils.ConvertToInternalUnits(
                3.0,
                UnitTypeId.Centimeters);

        diagonalMinima =
            Math.Max(
                diagonalMinima,
                desfaseEmpalme * 2.0);

        rectoSalidaMinimo =
            Math.Max(
                rectoSalidaMinimo,
                desfaseEmpalme);

        double disponibleDiagonal =
            espacioDespuesEmpalme -
            rectoSalidaMinimo;

        if (disponibleDiagonal <
            diagonalMinima - Tol)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Ubicación del quiebre de empalme",
                "No existe espacio suficiente después del traslape para formar " +
                "diagonal + salida recta. Espacio después del empalme=" +
                FormatearLongitudDiagnosticoMYG(espacioDespuesEmpalme) +
                "; desfase=" + FormatearLongitudDiagnosticoMYG(desfaseEmpalme) +
                "; diagonal mínima=" + FormatearLongitudDiagnosticoMYG(diagonalMinima) +
                "; salida recta mínima=" + FormatearLongitudDiagnosticoMYG(rectoSalidaMinimo) + ".");
            return false;
        }

        longitudDiagonal =
            Math.Min(
                diagonalObjetivo,
                disponibleDiagonal);

        return longitudDiagonal >=
               diagonalMinima - Tol;
    }


    private double CalcularDescuentoCurvatura90(
        RebarBarType barType,
        double diametro)
    {
        double radioCentro = ObtenerRadioCentroCurvatura(barType, diametro);

        if (radioCentro <= Tol)
            return 0.0;

        double angulo = Math.PI / 2.0;

        return CalcularDescuentoCurvaturaPorAngulo(
            angulo,
            radioCentro);
    }

    private double CalcularDescuentoCurvaturaPorAngulo(
        double angulo,
        double radioCentro)
    {
        if (angulo <= Tol || radioCentro <= Tol)
            return 0.0;

        double descuento =
            2.0 * radioCentro * Math.Tan(angulo / 2.0) -
            radioCentro * angulo;

        if (descuento < 0.0)
            descuento = 0.0;

        return descuento;
    }

    private double ObtenerDesfaseEmpalmeCaraACara(double diametro)
    {
        // V11.3 - QUIEBRE LOCAL DE EMPALME SIN DESALINEAR LA CONTINUACIÓN.
        // Durante la longitud de traslape la nueva pieza se separa un diámetro
        // respecto del eje original. Al terminar el traslape se genera una
        // diagonal corta de retorno y la pieza CONTINÚA otra vez sobre el mismo
        // eje longitudinal original.
        //
        // La separación libre entre caras se mantiene en 0.0 cm, por lo que la
        // distancia entre ejes durante el traslape es exactamente un diámetro.
        // Si luego se desea una holgura libre, basta con sumarla aquí.
        double separacionLibreCaraACara = UnitUtils.ConvertToInternalUnits(
            0.0,
            UnitTypeId.Centimeters);

        if (diametro <= Tol)
            return separacionLibreCaraACara;

        return diametro + separacionLibreCaraACara;
    }

    private double CalcularCompensacionEmpalmeInicio(
        RebarBarType barType,
        double diametro)
    {
        double desfaseEmpalme = ObtenerDesfaseEmpalmeCaraACara(diametro);

        double longitudDiagonalX =
            UnitUtils.ConvertToInternalUnits(20.0, UnitTypeId.Centimeters);

        if (desfaseEmpalme <= Tol || longitudDiagonalX <= Tol)
            return 0.0;

        double longitudDiagonalReal =
            Math.Sqrt(
                longitudDiagonalX * longitudDiagonalX +
                desfaseEmpalme * desfaseEmpalme);

        double extraDiagonal =
            longitudDiagonalReal - longitudDiagonalX;

        double angulo =
            Math.Atan2(desfaseEmpalme, longitudDiagonalX);

        double radioCentro =
            ObtenerRadioCentroCurvatura(barType, diametro);

        double descuentoPorCurvaturas =
            2.0 * CalcularDescuentoCurvaturaPorAngulo(
                angulo,
                radioCentro);

        return descuentoPorCurvaturas - extraDiagonal;
    }

    private double ObtenerRadioCentroCurvatura(
        RebarBarType barType,
        double diametro)
    {
        if (diametro <= Tol)
            return 0.0;

        double diametroCurvatura = ObtenerParametroDoublePorNombre(
            barType,
            "Diámetro de curvatura estándar",
            "Diámetro de doblado estándar",
            "Diámetro de curvatura",
            "Diámetro de doblado",
            "Standard Bend Diameter",
            "Standard Bar Bend Diameter",
            "Bend Diameter");

        if (diametroCurvatura > Tol)
        {
            return diametroCurvatura / 2.0 + diametro / 2.0;
        }

        return diametro * 5.5;
    }

    private double ObtenerParametroDoublePorNombre(
        Element elem,
        params string[] nombres)
    {
        if (elem == null || nombres == null)
            return 0.0;

        foreach (string nombre in nombres)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                continue;

            Parameter p = elem.LookupParameter(nombre);

            if (p == null)
                continue;

            if (p.StorageType != StorageType.Double)
                continue;

            double valor = p.AsDouble();

            if (valor > Tol)
                return valor;
        }

        return 0.0;
    }

    private void MarcarPrimerYUltimoSegmento(
        List<SegmentoAceroLongitudinal> segmentos)
    {
        if (segmentos == null || segmentos.Count == 0)
            return;

        for (int i = 0; i < segmentos.Count; i++)
        {
            segmentos[i].EsPrimero = false;
            segmentos[i].EsUltimo = false;
            segmentos[i].TieneEmpalmeFin = false;
        }

        segmentos[0].EsPrimero = true;
        segmentos[segmentos.Count - 1].EsUltimo = true;

        for (int i = 0; i < segmentos.Count - 1; i++)
            segmentos[i].TieneEmpalmeFin = true;
    }

    private class TransicionRecorrido
    {
        public double XLocal;
        public XYZ Punto;

        public TransicionRecorrido(double xLocal, XYZ punto)
        {
            XLocal = xLocal;
            Punto = punto;
        }
    }

    private class PuntoPerfilCara
    {
        public double X;
        public double Z;

        public PuntoPerfilCara(double x, double z)
        {
            X = x;
            Z = z;
        }
    }

    private class SegmentoPerfilCara
    {
        public double X0;
        public double Z0;
        public double X1;
        public double Z1;

        public SegmentoPerfilCara(double x0, double z0, double x1, double z1)
        {
            X0 = x0;
            Z0 = z0;
            X1 = x1;
            Z1 = z1;
        }
    }

    private class SegmentoCaraSerie
    {
        public double XSerie0;
        public double XSerie1;
        public XYZ P0;
        public XYZ P1;
        public XYZ Direccion;

        public SegmentoCaraSerie(double xSerie0, double xSerie1, XYZ p0, XYZ p1)
        {
            XSerie0 = xSerie0;
            XSerie1 = xSerie1;
            P0 = p0;
            P1 = p1;

            if (p0 != null && p1 != null && (p1 - p0).GetLength() > Tol)
                Direccion = (p1 - p0).Normalize();
            else
                Direccion = XYZ.BasisX;
        }
    }


    // =========================================================
    // POSICIONES DE ACERO LONGITUDINAL SEGÚN SECCIÓN REAL Y-Z
    // =========================================================
    private class PuntoSeccionYZ
    {
        public double Y;
        public double Z;

        public PuntoSeccionYZ(double y, double z)
        {
            Y = y;
            Z = z;
        }
    }

    private class PosicionBarraYZ
    {
        public double Y;
        public double Z;

        public PosicionBarraYZ(double y, double z)
        {
            Y = y;
            Z = z;
        }
    }


    private List<PosicionBarraYZ> ObtenerPosicionesBarrasPorCaraRealYZ(
        DatosSerieVigas datos,
        int cantidad,
        double offsetCentroBarra,
        int tipoGrupo)
    {
        List<PosicionBarraYZ> posiciones = new List<PosicionBarraYZ>();

        if (datos == null || cantidad <= 0)
            return posiciones;

        // Este método solo aplica para acero superior o inferior.
        // El acero central debe permanecer horizontal y se calcula aparte.
        if (tipoGrupo == 0)
            return posiciones;

        if (offsetCentroBarra <= Tol)
            return posiciones;

        List<PuntoSeccionYZ> poligono = ObtenerPoligonoSeccionRealYZ(datos);

        if (poligono == null || poligono.Count < 3)
            return posiciones;

        double yMin = poligono.Min(p => p.Y);
        double yMax = poligono.Max(p => p.Y);
        double zMin = poligono.Min(p => p.Z);
        double zMax = poligono.Max(p => p.Z);

        double ancho = yMax - yMin;
        double peralte = zMax - zMin;

        if (ancho <= Tol || peralte <= Tol)
            return posiciones;

        int indiceCaraPrincipal;
        PuntoSeccionYZ aCara;
        PuntoSeccionYZ bCara;

        if (!TryObtenerAristaSuperiorInferiorRealConIndice(
            poligono,
            tipoGrupo > 0,
            ancho,
            peralte,
            out indiceCaraPrincipal,
            out aCara,
            out bCara))
        {
            return posiciones;
        }

        List<LineaOffsetSeccionYZ> lineasOffset = ConstruirLineasOffsetInteriorYZ(
            poligono,
            offsetCentroBarra);

        if (lineasOffset == null || lineasOffset.Count != poligono.Count)
            return posiciones;

        int n = poligono.Count;

        LineaOffsetSeccionYZ lineaCara = lineasOffset[indiceCaraPrincipal];
        LineaOffsetSeccionYZ lineaAntes = lineasOffset[(indiceCaraPrincipal - 1 + n) % n];
        LineaOffsetSeccionYZ lineaDespues = lineasOffset[(indiceCaraPrincipal + 1) % n];

        PuntoSeccionYZ p0;
        PuntoSeccionYZ p1;

        if (!TryIntersecarLineasOffsetYZ(lineaCara, lineaAntes, out p0))
            return posiciones;

        if (!TryIntersecarLineasOffsetYZ(lineaCara, lineaDespues, out p1))
            return posiciones;

        if (p0 == null || p1 == null)
            return posiciones;

        // Ordenar siempre de izquierda a derecha según Y.
        if (p0.Y > p1.Y)
        {
            PuntoSeccionYZ tmp = p0;
            p0 = p1;
            p1 = tmp;
        }

        double dy = p1.Y - p0.Y;
        double dz = p1.Z - p0.Z;
        double longitudUtil = Math.Sqrt((dy * dy) + (dz * dz));

        if (longitudUtil <= Tol)
            return posiciones;

        // =====================================================
        // CORRECCIÓN CLAVE:
        // Asegura que la línea de distribución quede exactamente
        // a recubrimiento + diámetro de estribo, medido en forma
        // PERPENDICULAR a la cara superior/inferior real.
        //
        // No cambia el rango a lo largo de la cara; solo traslada
        // toda la línea en la normal interior de la cara.
        // =====================================================
        CorregirOffsetPerpendicularCaraPrincipalYZ(
            poligono,
            aCara,
            bCara,
            offsetCentroBarra,
            ref p0,
            ref p1);

        if (cantidad <= 1)
        {
            posiciones.Add(new PosicionBarraYZ(
                (p0.Y + p1.Y) / 2.0,
                (p0.Z + p1.Z) / 2.0));

            return posiciones;
        }

        for (int i = 0; i < cantidad; i++)
        {
            double t = (double)i / (double)(cantidad - 1);

            double y = p0.Y + (p1.Y - p0.Y) * t;
            double z = p0.Z + (p1.Z - p0.Z) * t;

            posiciones.Add(new PosicionBarraYZ(y, z));
        }

        return posiciones;
    }

    private void CorregirOffsetPerpendicularCaraPrincipalYZ(
        List<PuntoSeccionYZ> poligono,
        PuntoSeccionYZ aCara,
        PuntoSeccionYZ bCara,
        double offsetPerpendicular,
        ref PuntoSeccionYZ p0,
        ref PuntoSeccionYZ p1)
    {
        if (poligono == null || poligono.Count < 3)
            return;

        if (aCara == null || bCara == null || p0 == null || p1 == null)
            return;

        if (offsetPerpendicular <= Tol)
            return;

        double dy = bCara.Y - aCara.Y;
        double dz = bCara.Z - aCara.Z;
        double longitudCara = Math.Sqrt((dy * dy) + (dz * dz));

        if (longitudCara <= Tol)
            return;

        double dirY = dy / longitudCara;
        double dirZ = dz / longitudCara;

        // Dos normales posibles a la cara en el plano Y-Z.
        double n1Y = -dirZ;
        double n1Z = dirY;
        double n2Y = dirZ;
        double n2Z = -dirY;

        double yMed = (aCara.Y + bCara.Y) / 2.0;
        double zMed = (aCara.Z + bCara.Z) / 2.0;

        double yCentro = poligono.Average(p => p.Y);
        double zCentro = poligono.Average(p => p.Z);

        // La normal interior es la que apunta hacia el centroide del polígono.
        double dot1 = ((yCentro - yMed) * n1Y) + ((zCentro - zMed) * n1Z);
        double dot2 = ((yCentro - yMed) * n2Y) + ((zCentro - zMed) * n2Z);

        double nY;
        double nZ;

        if (dot1 >= dot2)
        {
            nY = n1Y;
            nZ = n1Z;
        }
        else
        {
            nY = n2Y;
            nZ = n2Z;
        }

        // Distancia actual de la línea p0-p1 respecto a la cara real,
        // medida en la normal interior. Se usa el promedio para evitar
        // pequeñas desviaciones numéricas en extremos.
        double dist0 = ((p0.Y - aCara.Y) * nY) + ((p0.Z - aCara.Z) * nZ);
        double dist1 = ((p1.Y - aCara.Y) * nY) + ((p1.Z - aCara.Z) * nZ);
        double distanciaActual = (dist0 + dist1) / 2.0;

        double delta = offsetPerpendicular - distanciaActual;

        if (Math.Abs(delta) <= Tol)
            return;

        p0 = new PuntoSeccionYZ(
            p0.Y + nY * delta,
            p0.Z + nZ * delta);

        p1 = new PuntoSeccionYZ(
            p1.Y + nY * delta,
            p1.Z + nZ * delta);
    }

    private class LineaOffsetSeccionYZ
    {
        public double A;
        public double B;
        public double C;

        public double NY;
        public double NZ;

        public int IndiceOriginal;
    }

    private List<LineaOffsetSeccionYZ> ConstruirLineasOffsetInteriorYZ(
        List<PuntoSeccionYZ> poligono,
        double offset)
    {
        List<LineaOffsetSeccionYZ> lineas = new List<LineaOffsetSeccionYZ>();

        if (poligono == null || poligono.Count < 3)
            return lineas;

        for (int i = 0; i < poligono.Count; i++)
        {
            LineaOffsetSeccionYZ linea = CrearLineaOffsetInteriorYZ(
                poligono,
                i,
                offset);

            if (linea == null)
                return new List<LineaOffsetSeccionYZ>();

            lineas.Add(linea);
        }

        return lineas;
    }

    private LineaOffsetSeccionYZ CrearLineaOffsetInteriorYZ(
        List<PuntoSeccionYZ> poligono,
        int indice,
        double offset)
    {
        if (poligono == null || poligono.Count < 3)
            return null;

        int n = poligono.Count;

        PuntoSeccionYZ a = poligono[indice];
        PuntoSeccionYZ b = poligono[(indice + 1) % n];

        if (a == null || b == null)
            return null;

        double dy = b.Y - a.Y;
        double dz = b.Z - a.Z;
        double longitud = Math.Sqrt((dy * dy) + (dz * dz));

        if (longitud <= Tol)
            return null;

        double dirY = dy / longitud;
        double dirZ = dz / longitud;

        double n1Y = -dirZ;
        double n1Z = dirY;

        double n2Y = dirZ;
        double n2Z = -dirY;

        double yMed = (a.Y + b.Y) / 2.0;
        double zMed = (a.Z + b.Z) / 2.0;

        double yCentro = poligono.Average(p => p.Y);
        double zCentro = poligono.Average(p => p.Z);

        double pasoPrueba = Math.Min(
            Math.Max(offset * 0.25, UnitUtils.ConvertToInternalUnits(0.5, UnitTypeId.Centimeters)),
            UnitUtils.ConvertToInternalUnits(3.0, UnitTypeId.Centimeters));

        bool n1Dentro = PuntoDentroPoligonoYZ(
            poligono,
            yMed + n1Y * pasoPrueba,
            zMed + n1Z * pasoPrueba);

        bool n2Dentro = PuntoDentroPoligonoYZ(
            poligono,
            yMed + n2Y * pasoPrueba,
            zMed + n2Z * pasoPrueba);

        double nY;
        double nZ;

        if (n1Dentro && !n2Dentro)
        {
            nY = n1Y;
            nZ = n1Z;
        }
        else if (n2Dentro && !n1Dentro)
        {
            nY = n2Y;
            nZ = n2Z;
        }
        else
        {
            // Respaldo: tomar la normal que apunta hacia el centroide.
            double dot1 = ((yCentro - yMed) * n1Y) + ((zCentro - zMed) * n1Z);
            double dot2 = ((yCentro - yMed) * n2Y) + ((zCentro - zMed) * n2Z);

            if (dot1 >= dot2)
            {
                nY = n1Y;
                nZ = n1Z;
            }
            else
            {
                nY = n2Y;
                nZ = n2Z;
            }
        }

        double y0 = a.Y + nY * offset;
        double z0 = a.Z + nZ * offset;

        double y1 = b.Y + nY * offset;
        double z1 = b.Z + nZ * offset;

        LineaOffsetSeccionYZ linea = CrearLineaYZDesdeDosPuntos(
            y0,
            z0,
            y1,
            z1);

        if (linea == null)
            return null;

        linea.NY = nY;
        linea.NZ = nZ;
        linea.IndiceOriginal = indice;

        return linea;
    }

    private LineaOffsetSeccionYZ CrearLineaYZDesdeDosPuntos(
        double y0,
        double z0,
        double y1,
        double z1)
    {
        double dy = y1 - y0;
        double dz = z1 - z0;
        double longitud = Math.Sqrt((dy * dy) + (dz * dz));

        if (longitud <= Tol)
            return null;

        // Ecuación:
        // A * Y + B * Z + C = 0
        LineaOffsetSeccionYZ linea = new LineaOffsetSeccionYZ();

        linea.A = z0 - z1;
        linea.B = y1 - y0;
        linea.C = (y0 * z1) - (y1 * z0);

        double norma = Math.Sqrt((linea.A * linea.A) + (linea.B * linea.B));

        if (norma <= Tol)
            return null;

        linea.A /= norma;
        linea.B /= norma;
        linea.C /= norma;

        return linea;
    }

    private bool TryIntersecarLineasOffsetYZ(
        LineaOffsetSeccionYZ l1,
        LineaOffsetSeccionYZ l2,
        out PuntoSeccionYZ punto)
    {
        punto = null;

        if (l1 == null || l2 == null)
            return false;

        double det = (l1.A * l2.B) - (l2.A * l1.B);

        if (Math.Abs(det) <= Tol)
            return false;

        double y = ((l1.B * l2.C) - (l2.B * l1.C)) / det;
        double z = ((l1.C * l2.A) - (l2.C * l1.A)) / det;

        if (double.IsNaN(y) || double.IsInfinity(y) ||
            double.IsNaN(z) || double.IsInfinity(z))
        {
            return false;
        }

        punto = new PuntoSeccionYZ(y, z);
        return true;
    }

    private bool TryObtenerAristaSuperiorInferiorRealConIndice(
        List<PuntoSeccionYZ> poligono,
        bool superior,
        double ancho,
        double peralte,
        out int indiceMejor,
        out PuntoSeccionYZ aMejor,
        out PuntoSeccionYZ bMejor)
    {
        indiceMejor = -1;
        aMejor = null;
        bMejor = null;

        if (poligono == null || poligono.Count < 3)
            return false;

        double mejorScore = double.MinValue;

        double minSpanY = Math.Max(
            UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters),
            ancho * 0.10);

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoSeccionYZ a = poligono[i];
            PuntoSeccionYZ b = poligono[(i + 1) % poligono.Count];

            if (a == null || b == null)
                continue;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longArista = Math.Sqrt((dy * dy) + (dz * dz));

            if (longArista <= Tol)
                continue;

            double spanY = Math.Abs(dy);

            // Debe ser una cara que recorra el ancho de la sección,
            // no una cara lateral vertical.
            if (spanY < minSpanY)
                continue;

            double zMed = (a.Z + b.Z) / 2.0;
            double inclinacion = Math.Abs(dz) / Math.Max(spanY, Tol);

            double score = superior
                ? zMed + inclinacion * peralte * 0.05
                : -zMed + inclinacion * peralte * 0.05;

            if (score > mejorScore)
            {
                mejorScore = score;
                indiceMejor = i;
                aMejor = a;
                bMejor = b;
            }
        }

        if (indiceMejor < 0 || aMejor == null || bMejor == null)
            return false;

        return true;
    }


    private bool TryObtenerAristaSuperiorInferiorReal(
        List<PuntoSeccionYZ> poligono,
        bool superior,
        double ancho,
        double peralte,
        out PuntoSeccionYZ aMejor,
        out PuntoSeccionYZ bMejor)
    {
        aMejor = null;
        bMejor = null;

        if (poligono == null || poligono.Count < 3)
            return false;

        double mejorScore = double.MinValue;
        double minSpanY = Math.Max(UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters), ancho * 0.10);

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoSeccionYZ a = poligono[i];
            PuntoSeccionYZ b = poligono[(i + 1) % poligono.Count];

            if (a == null || b == null)
                continue;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longArista = Math.Sqrt((dy * dy) + (dz * dz));

            if (longArista <= Tol)
                continue;

            double spanY = Math.Abs(dy);

            // La arista superior/inferior útil debe recorrer la sección en Y.
            // Esto evita tomar caras laterales verticales.
            if (spanY < minSpanY)
                continue;

            double zMed = (a.Z + b.Z) / 2.0;
            double inclinacion = Math.Abs(dz) / Math.Max(spanY, Tol);

            // Puntaje: arriba busca mayor Z, abajo busca menor Z.
            // Se suma un poco la inclinación para preferir la cara real inclinada
            // cuando existe una sección trapezoidal.
            double score = superior
                ? zMed + inclinacion * peralte * 0.05
                : -zMed + inclinacion * peralte * 0.05;

            if (score > mejorScore)
            {
                mejorScore = score;
                aMejor = a;
                bMejor = b;
            }
        }

        if (aMejor == null || bMejor == null)
            return false;

        // Ordenar siempre de izquierda a derecha en Y.
        if (aMejor.Y > bMejor.Y)
        {
            PuntoSeccionYZ tmp = aMejor;
            aMejor = bMejor;
            bMejor = tmp;
        }

        return true;
    }

    private bool PuntoDentroPoligonoYZ(
        List<PuntoSeccionYZ> poligono,
        double y,
        double z)
    {
        if (poligono == null || poligono.Count < 3)
            return false;

        bool dentro = false;

        for (int i = 0, j = poligono.Count - 1; i < poligono.Count; j = i++)
        {
            PuntoSeccionYZ pi = poligono[i];
            PuntoSeccionYZ pj = poligono[j];

            if (pi == null || pj == null)
                continue;

            bool intersecta = ((pi.Z > z) != (pj.Z > z)) &&
                (y < (pj.Y - pi.Y) * (z - pi.Z) / ((pj.Z - pi.Z) + Tol) + pi.Y);

            if (intersecta)
                dentro = !dentro;
        }

        return dentro;
    }

    private List<PosicionBarraYZ> ObtenerPosicionesBarrasPorSeccionReal(
        DatosSerieVigas datos,
        int cantidad,
        double offsetCentroBarra,
        int tipoGrupo)
    {
        List<PosicionBarraYZ> posiciones = new List<PosicionBarraYZ>();

        if (datos == null || cantidad <= 0)
            return posiciones;

        if (offsetCentroBarra <= Tol)
            return posiciones;

        List<PuntoSeccionYZ> poligono = ObtenerPoligonoSeccionRealYZ(datos);

        if (poligono == null || poligono.Count < 3)
            return posiciones;

        double yMin = poligono.Min(p => p.Y);
        double yMax = poligono.Max(p => p.Y);
        double zMin = poligono.Min(p => p.Z);
        double zMax = poligono.Max(p => p.Z);

        if (yMax <= yMin + Tol || zMax <= zMin + Tol)
            return posiciones;

        // CLAVE:
        // Para secciones trapezoidales o de 4 lados no rectangulares, el Z de cada
        // barra NO puede ser único para todo el grupo. Cada barra se ubica en su Y
        // correspondiente y se calcula su Z contra la cara real superior/inferior.
        // Así las barras superiores siguen la pendiente de la cara superior, y las
        // inferiores/centrales también se mantienen dentro del contorno real.
        double yIzq = yMin + offsetCentroBarra;
        double yDer = yMax - offsetCentroBarra;

        if (yDer < yIzq)
            return posiciones;

        List<double> ys = new List<double>();

        if (tipoGrupo == 0)
        {
            // Acero central: siempre separado. Normalmente son 2 barras,
            // una cercana a cada cara lateral real de la sección.
            if (cantidad <= 1 || Math.Abs(yDer - yIzq) <= Tol)
            {
                ys.Add((yIzq + yDer) / 2.0);
            }
            else
            {
                ys.Add(yIzq);
                ys.Add(yDer);
            }
        }
        else
        {
            if (cantidad == 1 || Math.Abs(yDer - yIzq) <= Tol)
            {
                ys.Add((yIzq + yDer) / 2.0);
            }
            else
            {
                for (int i = 0; i < cantidad; i++)
                {
                    double t = (double)i / (double)(cantidad - 1);
                    ys.Add(yIzq + (yDer - yIzq) * t);
                }
            }
        }

        foreach (double y in ys)
        {
            double zInferior;
            double zSuperior;

            if (!ObtenerZSuperiorInferiorEnY(
                poligono,
                y,
                out zInferior,
                out zSuperior))
            {
                continue;
            }

            double z;

            if (tipoGrupo > 0)
            {
                z = zSuperior - offsetCentroBarra;

                if (z <= zInferior + Tol)
                    z = zInferior + Math.Max((zSuperior - zInferior) * 0.15, Tol);
            }
            else if (tipoGrupo < 0)
            {
                z = zInferior + offsetCentroBarra;

                if (z >= zSuperior - Tol)
                    z = zSuperior - Math.Max((zSuperior - zInferior) * 0.15, Tol);
            }
            else
            {
                z = (zInferior + zSuperior) / 2.0;
            }

            if (z <= zInferior - Tol || z >= zSuperior + Tol)
                continue;

            posiciones.Add(new PosicionBarraYZ(y, z));
        }

        return posiciones;
    }

    private List<PuntoSeccionYZ> ObtenerPoligonoSeccionRealYZ(DatosSerieVigas datos)
    {
        List<PuntoSeccionYZ> puntos = new List<PuntoSeccionYZ>();

        if (datos == null || datos.Vigas == null || datos.Vigas.Count == 0)
            return puntos;

        foreach (DatosViga viga in datos.Vigas)
        {
            if (viga == null || viga.PuntosSolidoGlobal == null || viga.PuntosSolidoGlobal.Count == 0)
                continue;

            foreach (XYZ p in viga.PuntosSolidoGlobal)
            {
                if (p == null)
                    continue;

                double yGlobal = (p - datos.OrigenGlobal).DotProduct(datos.YAxis);
                double zGlobal = (p - datos.OrigenGlobal).DotProduct(datos.ZAxis);

                double y = yGlobal - datos.CentroY;
                double z = zGlobal - datos.CentroZ;

                if (double.IsNaN(y) || double.IsInfinity(y) ||
                    double.IsNaN(z) || double.IsInfinity(z))
                {
                    continue;
                }

                AgregarPuntoSeccionUnico(puntos, new PuntoSeccionYZ(y, z));
            }
        }

        if (puntos.Count < 3)
            return puntos;

        return ObtenerConvexHullYZ(puntos);
    }

    private void AgregarPuntoSeccionUnico(
        List<PuntoSeccionYZ> puntos,
        PuntoSeccionYZ nuevo)
    {
        if (puntos == null || nuevo == null)
            return;

        double tol = UnitUtils.ConvertToInternalUnits(0.2, UnitTypeId.Centimeters);

        foreach (PuntoSeccionYZ p in puntos)
        {
            if (p == null)
                continue;

            if (Math.Abs(p.Y - nuevo.Y) <= tol && Math.Abs(p.Z - nuevo.Z) <= tol)
                return;
        }

        puntos.Add(nuevo);
    }

    private List<PuntoSeccionYZ> ObtenerConvexHullYZ(List<PuntoSeccionYZ> puntos)
    {
        List<PuntoSeccionYZ> pts = puntos
            .Where(p => p != null)
            .OrderBy(p => p.Y)
            .ThenBy(p => p.Z)
            .ToList();

        if (pts.Count <= 3)
            return pts;

        List<PuntoSeccionYZ> lower = new List<PuntoSeccionYZ>();
        foreach (PuntoSeccionYZ p in pts)
        {
            while (lower.Count >= 2 && CrossYZ(lower[lower.Count - 2], lower[lower.Count - 1], p) <= 0.0)
                lower.RemoveAt(lower.Count - 1);
            lower.Add(p);
        }

        List<PuntoSeccionYZ> upper = new List<PuntoSeccionYZ>();
        for (int i = pts.Count - 1; i >= 0; i--)
        {
            PuntoSeccionYZ p = pts[i];
            while (upper.Count >= 2 && CrossYZ(upper[upper.Count - 2], upper[upper.Count - 1], p) <= 0.0)
                upper.RemoveAt(upper.Count - 1);
            upper.Add(p);
        }

        lower.RemoveAt(lower.Count - 1);
        upper.RemoveAt(upper.Count - 1);
        lower.AddRange(upper);

        return lower;
    }

    private double CrossYZ(PuntoSeccionYZ o, PuntoSeccionYZ a, PuntoSeccionYZ b)
    {
        return (a.Y - o.Y) * (b.Z - o.Z) - (a.Z - o.Z) * (b.Y - o.Y);
    }

    private bool ObtenerRangoYEnZ(
        List<PuntoSeccionYZ> poligono,
        double z,
        out double yIzq,
        out double yDer)
    {
        yIzq = 0.0;
        yDer = 0.0;

        if (poligono == null || poligono.Count < 3)
            return false;

        List<double> intersecciones = new List<double>();
        double tol = UnitUtils.ConvertToInternalUnits(0.2, UnitTypeId.Centimeters);

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoSeccionYZ a = poligono[i];
            PuntoSeccionYZ b = poligono[(i + 1) % poligono.Count];

            if (a == null || b == null)
                continue;

            if (Math.Abs(a.Z - b.Z) <= tol)
            {
                if (Math.Abs(z - a.Z) <= tol)
                {
                    intersecciones.Add(a.Y);
                    intersecciones.Add(b.Y);
                }

                continue;
            }

            double zMin = Math.Min(a.Z, b.Z);
            double zMax = Math.Max(a.Z, b.Z);

            if (z < zMin - tol || z > zMax + tol)
                continue;

            double t = (z - a.Z) / (b.Z - a.Z);

            if (t < -0.001 || t > 1.001)
                continue;

            double y = a.Y + (b.Y - a.Y) * t;
            intersecciones.Add(y);
        }

        if (intersecciones.Count < 2)
            return false;

        intersecciones = intersecciones
            .OrderBy(v => v)
            .ToList();

        yIzq = intersecciones.First();
        yDer = intersecciones.Last();

        return yDer > yIzq + Tol;
    }

    private bool ObtenerZSuperiorInferiorEnY(
        List<PuntoSeccionYZ> poligono,
        double y,
        out double zInferior,
        out double zSuperior)
    {
        zInferior = 0.0;
        zSuperior = 0.0;

        if (poligono == null || poligono.Count < 3)
            return false;

        List<double> intersecciones = new List<double>();
        double tol = UnitUtils.ConvertToInternalUnits(0.2, UnitTypeId.Centimeters);

        for (int i = 0; i < poligono.Count; i++)
        {
            PuntoSeccionYZ a = poligono[i];
            PuntoSeccionYZ b = poligono[(i + 1) % poligono.Count];

            if (a == null || b == null)
                continue;

            if (Math.Abs(a.Y - b.Y) <= tol)
            {
                if (Math.Abs(y - a.Y) <= tol)
                {
                    intersecciones.Add(a.Z);
                    intersecciones.Add(b.Z);
                }

                continue;
            }

            double yMin = Math.Min(a.Y, b.Y);
            double yMax = Math.Max(a.Y, b.Y);

            if (y < yMin - tol || y > yMax + tol)
                continue;

            double t = (y - a.Y) / (b.Y - a.Y);

            if (t < -0.001 || t > 1.001)
                continue;

            double z = a.Z + (b.Z - a.Z) * t;
            intersecciones.Add(z);
        }

        if (intersecciones.Count < 2)
            return false;

        intersecciones = intersecciones
            .OrderBy(v => v)
            .ToList();

        zInferior = intersecciones.First();
        zSuperior = intersecciones.Last();

        return zSuperior > zInferior + Tol;
    }

    private List<XYZ> ConstruirPuntosBarraConEmpalme(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal seg,
        double y,
        double z,
        bool crearEmpalmes,
        double longitudEmpalme,
        XYZ direccionDesfaseEmpalme,
        double desfaseEmpalme,
        double margenCaraForzado = -1.0,
        bool preservarPosicionTransversalManual = false)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (datos == null || seg == null)
            return puntos;

        XYZ pInicioBase = PuntoLocal(datos, seg.XInicio, y, z);
        XYZ pFinBase = PuntoLocal(datos, seg.XFin, y, z);

        // =========================================================
        // V7 - RECORRIDO POR CARAS REALES DEL SÓLIDO
        // =========================================================
        // La barra superior/inferior ya no depende del eje de la viga ni del punto
        // donde empieza el tramo inclinado. Se toma cada cara superior/inferior como
        // una línea, se genera su paralela a distancia de recubrimiento + radio,
        // y el punto de quiebre se obtiene de la intersección de esas paralelas.
        // Si por alguna geometría no se logra construir el recorrido por caras,
        // se conserva la lógica original como respaldo.
        bool esAceroDeCara = Math.Abs(z) > Tol;

        double margenCaraEfectivo = margenCaraForzado;

        // Para un diseño manual la distancia a la cara no se obtiene de Alto/2-Z.
        // Esa fórmula solo es válida en secciones rectangulares. Aquí se mide la
        // distancia perpendicular real al plano 3D de la cara en una estación de
        // referencia, conservando además las capas 2, 3 y 4.
        if (preservarPosicionTransversalManual && esAceroDeCara)
        {
            double margenPlano;
            if (TryCalcularMargenNormalCaraSerieMYG(
                    datos,
                    y,
                    z,
                    z > 0.0,
                    out margenPlano))
            {
                margenCaraEfectivo = margenPlano;
            }
        }

        bool requiereRecorridoPorCarasLongitudinal =
            preservarPosicionTransversalManual
                ? (SerieTienePlanoCaraPrincipal3DMYG(datos, z > 0.0) ||
                   SerieTieneCaraLongitudinalInclinadaXZ(datos, z > 0.0) ||
                   SerieTieneQuiebreEntreTramosLongitudinal(datos))
                : SerieTieneGeometriaNoOrtogonalParaLongitudinal(
                    datos,
                    z > 0.0);

        if (esAceroDeCara &&
            PuedeUsarRecorridoPorCaras(datos, z) &&
            requiereRecorridoPorCarasLongitudinal)
        {
            if (!crearEmpalmes ||
                !seg.TieneEmpalmeInicio ||
                longitudEmpalme <= Tol ||
                direccionDesfaseEmpalme == null ||
                direccionDesfaseEmpalme.GetLength() <= Tol ||
                desfaseEmpalme <= Tol)
            {
                bool okCara = AgregarPuntosRecorridoPorCaras(
                    puntos,
                    datos,
                    seg.XInicio,
                    seg.XFin,
                    y,
                    z,
                    null,
                    margenCaraEfectivo);

                if (okCara && puntos.Count >= 2)
                    return LimpiarPuntosConsecutivos(puntos);

                puntos.Clear();
            }
            else
            {
                XYZ offset = direccionDesfaseEmpalme.Normalize().Multiply(desfaseEmpalme);

                double xEmpalmeFin = Math.Min(
                    seg.XInicio + longitudEmpalme,
                    seg.XFin);

                double espacioDespuesEmpalme = seg.XFin - xEmpalmeFin;

                double longitudDiagonal = UnitUtils.ConvertToInternalUnits(
                    20.0,
                    UnitTypeId.Centimeters);

                if (espacioDespuesEmpalme > Tol)
                    longitudDiagonal = Math.Min(longitudDiagonal, espacioDespuesEmpalme * 0.45);
                else
                    longitudDiagonal = 0.0;

                double xDiagonalFin = Math.Min(
                    xEmpalmeFin + longitudDiagonal,
                    seg.XFin);

                bool okEmpalme = AgregarPuntosRecorridoPorCaras(
                    puntos,
                    datos,
                    seg.XInicio,
                    xEmpalmeFin,
                    y,
                    z,
                    offset,
                    margenCaraEfectivo);

                if (okEmpalme && puntos.Count >= 2)
                {
                    if (xDiagonalFin > xEmpalmeFin + Tol)
                    {
                        XYZ p2 = PuntoEnRecorridoPorCaras(
                            datos,
                            xDiagonalFin,
                            y,
                            z,
                            margenCaraEfectivo);

                        if (p2 == null)
                            p2 = PuntoLocal(datos, xDiagonalFin, y, z);

                        AgregarPuntoSiValido(puntos, p2);

                        if (seg.XFin > xDiagonalFin + Tol)
                        {
                            AgregarPuntosRecorridoPorCaras(
                                puntos,
                                datos,
                                xDiagonalFin,
                                seg.XFin,
                                y,
                                z,
                                null,
                                margenCaraEfectivo);
                        }
                    }
                    else
                    {
                        XYZ pFinCara = PuntoEnRecorridoPorCaras(
                            datos,
                            seg.XFin,
                            y,
                            z,
                            margenCaraEfectivo);

                        if (pFinCara == null)
                            pFinCara = pFinBase;

                        AgregarPuntoSiValido(puntos, pFinCara);
                    }

                    if (puntos.Count >= 2)
                        return LimpiarPuntosConsecutivos(puntos);
                }

                puntos.Clear();
            }
        }

        // Respaldo original: mantiene los casos que ya funcionaban si una geometría
        // no puede resolverse por caras.
        return ConstruirPuntosBarraConEmpalmeOriginal(
            datos,
            seg,
            y,
            z,
            crearEmpalmes,
            longitudEmpalme,
            direccionDesfaseEmpalme,
            desfaseEmpalme);
    }

    private bool PuedeUsarRecorridoPorCaras(
        DatosSerieVigas datos,
        double z)
    {
        if (datos == null || Math.Abs(z) <= Tol)
            return false;

        if (datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return false;

        foreach (TramoRecorridoSerie tramo in datos.TramosRecorrido)
        {
            if (tramo == null || tramo.Viga == null)
                continue;

            DatosViga v = tramo.Viga;

            if (z > Tol && v.PerfilSuperiorDetallado != null && v.PerfilSuperiorDetallado.Count > 0)
                return true;

            if (z < -Tol && v.PerfilInferiorDetallado != null && v.PerfilInferiorDetallado.Count > 0)
                return true;
        }

        return false;
    }

    private bool AgregarPuntosRecorridoPorCaras(
        List<XYZ> puntos,
        DatosSerieVigas datos,
        double xInicio,
        double xFin,
        double y,
        double z,
        XYZ offset,
        double margenCaraForzado = -1.0)
    {
        if (puntos == null || datos == null)
            return false;

        List<SegmentoCaraSerie> segmentos = ConstruirSegmentosCaraSerie(
            datos,
            xInicio,
            xFin,
            y,
            z,
            margenCaraForzado);

        if (segmentos == null || segmentos.Count == 0)
            return false;

        if (offset != null && offset.GetLength() > Tol)
        {
            XYZ off = offset;

            foreach (SegmentoCaraSerie s in segmentos)
            {
                if (s == null)
                    continue;

                s.P0 = s.P0.Add(off);
                s.P1 = s.P1.Add(off);

                if (s.P0 != null && s.P1 != null && (s.P1 - s.P0).GetLength() > Tol)
                    s.Direccion = (s.P1 - s.P0).Normalize();
            }
        }

        AgregarPuntoSiValido(puntos, segmentos[0].P0);

        for (int i = 0; i < segmentos.Count - 1; i++)
        {
            SegmentoCaraSerie actual = segmentos[i];
            SegmentoCaraSerie siguiente = segmentos[i + 1];

            if (actual == null || siguiente == null)
                continue;

            if (actual.P0 == null || actual.P1 == null ||
                siguiente.P0 == null || siguiente.P1 == null)
            {
                continue;
            }

            XYZ dirActual = actual.Direccion;
            XYZ dirSiguiente = siguiente.Direccion;

            if (dirActual == null || dirActual.GetLength() <= Tol)
                dirActual = actual.P1 - actual.P0;

            if (dirSiguiente == null || dirSiguiente.GetLength() <= Tol)
                dirSiguiente = siguiente.P1 - siguiente.P0;

            if (dirActual == null || dirSiguiente == null ||
                dirActual.GetLength() <= Tol || dirSiguiente.GetLength() <= Tol)
            {
                continue;
            }

            dirActual = dirActual.Normalize();
            dirSiguiente = dirSiguiente.Normalize();

            double dotAbs = Math.Abs(dirActual.DotProduct(dirSiguiente));
            if (dotAbs > 1.0) dotAbs = 1.0;

            double angulo = Math.Acos(dotAbs) * 180.0 / Math.PI;

            // Si las paralelas son prácticamente colineales, NO se agrega el punto
            // extremo de una cara ni el punto inicial de la siguiente. Agregar esos
            // puntos genera el quiebre falso que se veía en el dibujo.
            if (angulo <= 0.10)
                continue;

            XYZ puntoQuiebre = null;
            bool quiebreAgregado = false;

            // CLAVE:
            // El quiebre se calcula por intersección de las líneas infinitas
            // proyectadas de cada cara offseteada. No se usa el punto final
            // de un tramo ni el punto inicial del otro.
            if (TryIntersecarLineasProyectadas(
                actual.P0,
                dirActual,
                siguiente.P0,
                dirSiguiente,
                out puntoQuiebre) &&
                PuntoQuiebreEsRazonableParaUnion(actual, siguiente, puntoQuiebre, datos))
            {
                AgregarPuntoSiValido(puntos, puntoQuiebre);
                quiebreAgregado = true;
            }

            // Respaldo para vigas rectangulares inclinadas o series con cambio de tramo:
            // si la intersección matemática queda fuera del rango razonable, no se debe
            // unir el primer y último punto con una recta. Se conserva el quiebre real
            // de la unión entre tramos para que el acero siga la cara proyectada.
            if (!quiebreAgregado)
            {
                AgregarQuiebreSeguroPorUnionReal(
                    puntos,
                    actual,
                    siguiente,
                    datos);
            }
        }

        AgregarPuntoSiValido(puntos, segmentos[segmentos.Count - 1].P1);

        return puntos.Count >= 2;
    }

    private XYZ PuntoEnRecorridoPorCaras(
        DatosSerieVigas datos,
        double x,
        double y,
        double z,
        double margenCaraForzado = -1.0)
    {
        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return null;

        bool superior = z > Tol;
        bool inferior = z < -Tol;

        if (!superior && !inferior)
            return null;

        double margenCara;

        if (margenCaraForzado > Tol)
        {
            margenCara = margenCaraForzado;
        }
        else
        {
            margenCara = superior
                ? datos.Alto / 2.0 - z
                : datos.Alto / 2.0 + z;

            if (margenCara < 0.0)
                margenCara = Math.Abs(margenCara);
        }

        TramoRecorridoSerie tramo = ObtenerTramoParaEstacion(datos, x);

        if (tramo == null || tramo.Viga == null)
            return null;

        DatosViga viga = tramo.Viga;
        double estacion = ObtenerEstacionVigaDesdeXSerie(tramo, x);

        List<SegmentoPerfilCara> perfil = superior
            ? viga.PerfilSuperiorDetallado
            : viga.PerfilInferiorDetallado;

        if (perfil == null || perfil.Count == 0)
            perfil = CrearPerfilSimpleCara(viga, superior);

        SegmentoPerfilCara segCara = perfil
            .Where(s => s != null)
            .OrderBy(s => DistanciaEstacionASegmentoPerfil(estacion, s))
            .FirstOrDefault();

        if (segCara == null)
            return null;

        return PuntoOffsetEnSegmentoCara(
            viga,
            segCara,
            estacion,
            y,
            margenCara,
            superior);
    }

    private double DistanciaEstacionASegmentoPerfil(
        double estacion,
        SegmentoPerfilCara seg)
    {
        if (seg == null)
            return double.MaxValue;

        double min = Math.Min(seg.X0, seg.X1);
        double max = Math.Max(seg.X0, seg.X1);

        if (estacion >= min - Tol && estacion <= max + Tol)
            return 0.0;

        return Math.Min(Math.Abs(estacion - min), Math.Abs(estacion - max));
    }

    private List<SegmentoCaraSerie> ConstruirSegmentosCaraSerie(
        DatosSerieVigas datos,
        double xInicio,
        double xFin,
        double y,
        double z,
        double margenCaraForzado = -1.0)
    {
        List<SegmentoCaraSerie> resultado = new List<SegmentoCaraSerie>();

        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return resultado;

        bool superior = z > Tol;
        bool inferior = z < -Tol;

        if (!superior && !inferior)
            return resultado;

        double margenCara;

        if (margenCaraForzado > Tol)
        {
            margenCara = margenCaraForzado;
        }
        else
        {
            margenCara = superior
                ? datos.Alto / 2.0 - z
                : datos.Alto / 2.0 + z;

            if (margenCara < 0.0)
                margenCara = Math.Abs(margenCara);
        }

        if (margenCara <= Tol)
            margenCara = UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters);

        bool invertir = xFin < xInicio;
        double a = Math.Min(xInicio, xFin);
        double b = Math.Max(xInicio, xFin);

        // Para xInicio == xFin se crea una ventana mínima alrededor de la estación
        // y luego se retorna el punto inicial del segmento resultante.
        if (Math.Abs(b - a) <= Tol)
        {
            double delta = UnitUtils.ConvertToInternalUnits(0.1, UnitTypeId.Centimeters);
            a -= delta;
            b += delta;
        }

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Viga != null)
            .OrderBy(t => Math.Min(t.XInicioSerie, t.XFinSerie))
            .ToList();

        foreach (TramoRecorridoSerie tramo in tramos)
        {
            DatosViga viga = tramo.Viga;

            List<SegmentoPerfilCara> perfil = superior
                ? viga.PerfilSuperiorDetallado
                : viga.PerfilInferiorDetallado;

            if (perfil == null || perfil.Count == 0)
                perfil = CrearPerfilSimpleCara(viga, superior);

            if (perfil == null || perfil.Count == 0)
                continue;

            foreach (SegmentoPerfilCara segCara in perfil)
            {
                if (segCara == null)
                    continue;

                double s0 = SerieDesdeEstacionViga(tramo, segCara.X0);
                double s1 = SerieDesdeEstacionViga(tramo, segCara.X1);

                double sMin = Math.Min(s0, s1);
                double sMax = Math.Max(s0, s1);

                double ov0 = Math.Max(a, sMin);
                double ov1 = Math.Min(b, sMax);

                if (ov1 < ov0 - Tol)
                    continue;

                if (Math.Abs(ov1 - ov0) <= Tol && Math.Abs(xFin - xInicio) > Tol)
                    continue;

                double serieIni = ov0;
                double serieFin = ov1;

                double estacionIni = ObtenerEstacionVigaDesdeXSerie(tramo, serieIni);
                double estacionFin = ObtenerEstacionVigaDesdeXSerie(tramo, serieFin);

                XYZ p0 = PuntoOffsetEnSegmentoCara(
                    viga,
                    segCara,
                    estacionIni,
                    y,
                    margenCara,
                    superior);

                XYZ p1 = PuntoOffsetEnSegmentoCara(
                    viga,
                    segCara,
                    estacionFin,
                    y,
                    margenCara,
                    superior);

                if (p0 == null || p1 == null)
                    continue;

                // Asegurar orden creciente de estación de serie.
                if (serieFin >= serieIni)
                    resultado.Add(new SegmentoCaraSerie(serieIni, serieFin, p0, p1));
                else
                    resultado.Add(new SegmentoCaraSerie(serieFin, serieIni, p1, p0));
            }
        }

        resultado = resultado
            .Where(s => s != null && s.P0 != null && s.P1 != null && (s.P1 - s.P0).GetLength() > Tol)
            .OrderBy(s => Math.Min(s.XSerie0, s.XSerie1))
            .ToList();

        resultado = FusionarSegmentosCaraColineales(resultado);

        // V10 - LONGITUDES DE DESARROLLO:
        // Si xInicio o xFin quedan fuera del tramo real de cara por L. desarrollo,
        // NO se cambia la geometría que ya estaba creando bien el acero.
        // Solo se prolonga el primer o último segmento siguiendo su misma dirección.
        resultado = ExtenderSegmentosCaraHastaRango(resultado, a, b);

        if (invertir)
        {
            resultado.Reverse();

            foreach (SegmentoCaraSerie s in resultado)
            {
                XYZ tmp = s.P0;
                s.P0 = s.P1;
                s.P1 = tmp;

                if (s.P0 != null && s.P1 != null && (s.P1 - s.P0).GetLength() > Tol)
                    s.Direccion = (s.P1 - s.P0).Normalize();
            }
        }

        return resultado;
    }

    private List<SegmentoCaraSerie> ExtenderSegmentosCaraHastaRango(
        List<SegmentoCaraSerie> segmentos,
        double xInicioSolicitado,
        double xFinSolicitado)
    {
        if (segmentos == null || segmentos.Count == 0)
            return segmentos ?? new List<SegmentoCaraSerie>();

        segmentos = segmentos
            .Where(s => s != null && s.P0 != null && s.P1 != null)
            .OrderBy(s => Math.Min(s.XSerie0, s.XSerie1))
            .ToList();

        if (segmentos.Count == 0)
            return segmentos;

        double a = Math.Min(xInicioSolicitado, xFinSolicitado);
        double b = Math.Max(xInicioSolicitado, xFinSolicitado);
        double tolerancia = UnitUtils.ConvertToInternalUnits(0.1, UnitTypeId.Centimeters);

        SegmentoCaraSerie primero = segmentos[0];
        SegmentoCaraSerie ultimo = segmentos[segmentos.Count - 1];

        if (primero != null && primero.P0 != null && primero.P1 != null)
        {
            double xPrimero = Math.Min(primero.XSerie0, primero.XSerie1);

            if (a < xPrimero - tolerancia)
            {
                XYZ dir = primero.Direccion;

                if (dir == null || dir.GetLength() <= Tol)
                    dir = primero.P1 - primero.P0;

                if (dir != null && dir.GetLength() > Tol)
                {
                    dir = dir.Normalize();
                    double extension = xPrimero - a;

                    primero.P0 = primero.P0.Subtract(dir.Multiply(extension));
                    primero.XSerie0 = a;

                    if ((primero.P1 - primero.P0).GetLength() > Tol)
                        primero.Direccion = (primero.P1 - primero.P0).Normalize();
                }
            }
        }

        if (ultimo != null && ultimo.P0 != null && ultimo.P1 != null)
        {
            double xUltimo = Math.Max(ultimo.XSerie0, ultimo.XSerie1);

            if (b > xUltimo + tolerancia)
            {
                XYZ dir = ultimo.Direccion;

                if (dir == null || dir.GetLength() <= Tol)
                    dir = ultimo.P1 - ultimo.P0;

                if (dir != null && dir.GetLength() > Tol)
                {
                    dir = dir.Normalize();
                    double extension = b - xUltimo;

                    ultimo.P1 = ultimo.P1.Add(dir.Multiply(extension));
                    ultimo.XSerie1 = b;

                    if ((ultimo.P1 - ultimo.P0).GetLength() > Tol)
                        ultimo.Direccion = (ultimo.P1 - ultimo.P0).Normalize();
                }
            }
        }

        return segmentos;
    }

    private List<SegmentoCaraSerie> FusionarSegmentosCaraColineales(
        List<SegmentoCaraSerie> segmentos)
    {
        List<SegmentoCaraSerie> resultado = new List<SegmentoCaraSerie>();

        if (segmentos == null || segmentos.Count == 0)
            return resultado;

        double toleranciaDistancia = UnitUtils.ConvertToInternalUnits(0.5, UnitTypeId.Centimeters);

        foreach (SegmentoCaraSerie s in segmentos)
        {
            if (s == null)
                continue;

            if (resultado.Count == 0)
            {
                resultado.Add(s);
                continue;
            }

            SegmentoCaraSerie u = resultado[resultado.Count - 1];

            if (u == null || u.Direccion == null || s.Direccion == null)
            {
                resultado.Add(s);
                continue;
            }

            double dot = Math.Abs(u.Direccion.Normalize().DotProduct(s.Direccion.Normalize()));
            double separacion = (s.P0 - u.P1).GetLength();

            if (dot > 0.9995 && separacion <= toleranciaDistancia)
            {
                u.P1 = s.P1;
                u.XSerie1 = s.XSerie1;

                if ((u.P1 - u.P0).GetLength() > Tol)
                    u.Direccion = (u.P1 - u.P0).Normalize();
            }
            else
            {
                resultado.Add(s);
            }
        }

        return resultado;
    }

    private bool DebeCrearQuiebreEntreSegmentos(
        SegmentoCaraSerie a,
        SegmentoCaraSerie b)
    {
        if (a == null || b == null || a.Direccion == null || b.Direccion == null)
            return false;

        if (a.Direccion.GetLength() <= Tol || b.Direccion.GetLength() <= Tol)
            return false;

        double dot = Math.Abs(a.Direccion.Normalize().DotProduct(b.Direccion.Normalize()));

        if (dot > 1.0) dot = 1.0;

        double angulo = Math.Acos(dot) * 180.0 / Math.PI;

        return angulo > 0.10;
    }



    private void AgregarQuiebreSeguroPorUnionReal(
        List<XYZ> puntos,
        SegmentoCaraSerie actual,
        SegmentoCaraSerie siguiente,
        DatosSerieVigas datos)
    {
        if (puntos == null || actual == null || siguiente == null)
            return;

        if (actual.P1 == null || siguiente.P0 == null)
            return;

        double separacion = (siguiente.P0 - actual.P1).GetLength();

        double toleranciaUnion = UnitUtils.ConvertToInternalUnits(
            2.0,
            UnitTypeId.Centimeters);

        if (datos != null && datos.Alto > Tol)
            toleranciaUnion = Math.Max(toleranciaUnion, datos.Alto * 0.15);

        if (separacion <= toleranciaUnion)
        {
            XYZ puntoUnion = actual.P1.Add(siguiente.P0).Multiply(0.5);
            AgregarPuntoSiValido(puntos, puntoUnion);
            return;
        }

        // Si hay una separación real entre las líneas offseteadas, se agregan ambos
        // puntos para que Revit genere un pequeño enlace y no pierda el cambio de tramo.
        AgregarPuntoSiValido(puntos, actual.P1);
        AgregarPuntoSiValido(puntos, siguiente.P0);
    }

    private bool PuntoQuiebreEsRazonableParaUnion(
        SegmentoCaraSerie a,
        SegmentoCaraSerie b,
        XYZ p,
        DatosSerieVigas datos)
    {
        if (a == null || b == null || p == null)
            return false;

        XYZ dirA = a.Direccion;
        XYZ dirB = b.Direccion;

        if (dirA == null || dirA.GetLength() <= Tol)
            dirA = a.P1 - a.P0;

        if (dirB == null || dirB.GetLength() <= Tol)
            dirB = b.P1 - b.P0;

        if (dirA == null || dirB == null ||
            dirA.GetLength() <= Tol || dirB.GetLength() <= Tol)
        {
            return false;
        }

        dirA = dirA.Normalize();
        dirB = dirB.Normalize();

        double tolLinea = UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters);

        double d1 = DistanciaPuntoALineaInfinita(p, a.P0, dirA);
        double d2 = DistanciaPuntoALineaInfinita(p, b.P0, dirB);

        if (d1 > tolLinea || d2 > tolLinea)
            return false;

        double limite = UnitUtils.ConvertToInternalUnits(300.0, UnitTypeId.Centimeters);

        if (datos != null)
        {
            double baseGeom = Math.Max(datos.Alto, datos.LongitudTotal * 0.05);
            if (baseGeom > Tol)
                limite = Math.Max(limite, baseGeom * 3.0);
        }

        XYZ unionBase = a.P1.Add(b.P0).Multiply(0.5);
        double distanciaUnion = (p - unionBase).GetLength();

        return distanciaUnion <= limite;
    }
    private bool PuntoQuiebreEsRazonable(
            SegmentoCaraSerie a,
            SegmentoCaraSerie b,
            XYZ p,
            DatosSerieVigas datos)
    {
        if (a == null || b == null || p == null)
            return false;

        double limite = UnitUtils.ConvertToInternalUnits(500.0, UnitTypeId.Centimeters);

        if (datos != null && datos.Alto > Tol)
            limite = Math.Max(limite, datos.Alto * 8.0);

        double d1 = DistanciaPuntoALineaInfinita(p, a.P0, a.Direccion);
        double d2 = DistanciaPuntoALineaInfinita(p, b.P0, b.Direccion);

        if (d1 > UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters))
            return false;

        if (d2 > UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters))
            return false;

        double distA = Math.Min((p - a.P0).GetLength(), (p - a.P1).GetLength());
        double distB = Math.Min((p - b.P0).GetLength(), (p - b.P1).GetLength());

        return distA <= limite && distB <= limite;
    }

    private double DistanciaPuntoALineaInfinita(
        XYZ p,
        XYZ origen,
        XYZ direccion)
    {
        if (p == null || origen == null || direccion == null || direccion.GetLength() <= Tol)
            return double.MaxValue;

        XYZ d = direccion.Normalize();
        XYZ v = p - origen;
        XYZ proy = origen.Add(d.Multiply(v.DotProduct(d)));

        return (p - proy).GetLength();
    }

    private double SerieDesdeEstacionViga(
        TramoRecorridoSerie tramo,
        double estacionViga)
    {
        if (tramo == null)
            return 0.0;

        double deltaEstacion = tramo.EstacionFinViga - tramo.EstacionInicioViga;
        double deltaSerie = tramo.XFinSerie - tramo.XInicioSerie;

        if (Math.Abs(deltaEstacion) <= Tol)
            return tramo.XInicioSerie;

        double t = (estacionViga - tramo.EstacionInicioViga) / deltaEstacion;

        return tramo.XInicioSerie + deltaSerie * t;
    }

    // =========================================================
    // V10.4 - PLANOS 3D DE CARAS SUPERIOR/INFERIOR
    // =========================================================
    private void CalcularPlanosCarasPrincipales3DMYG(DatosViga datos)
    {
        if (datos == null)
            return;

        datos.PlanosSuperiores3D = new List<PlanoCaraPrincipal3DMYG>();
        datos.PlanosInferiores3D = new List<PlanoCaraPrincipal3DMYG>();

        if (datos.SolidosGlobales == null || datos.SolidosGlobales.Count == 0)
            return;

        double xMinAdmitido = Math.Max(
            UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters),
            datos.Longitud * 0.20);
        double yMinAdmitido = Math.Max(
            UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters),
            datos.Ancho * 0.12);
        double zCentro = (datos.ZMin + datos.ZMax) * 0.5;

        foreach (Solid solid in datos.SolidosGlobales)
        {
            if (solid == null || solid.Faces == null)
                continue;

            foreach (Face face in solid.Faces)
            {
                PlanarFace pf = face as PlanarFace;
                if (pf == null)
                    continue;

                XYZ normal = pf.FaceNormal;
                if (normal == null || normal.GetLength() <= Tol)
                    continue;
                normal = normal.Normalize();

                double nz = normal.DotProduct(datos.ZAxis);
                if (Math.Abs(nz) < 0.08)
                    continue;

                bool superior = nz > 0.0;
                if (superior && nz < 0.0)
                    normal = normal.Multiply(-1.0);
                if (!superior && nz > 0.0)
                    normal = normal.Multiply(-1.0);

                List<XYZ> puntos = ObtenerPuntosPlanarFace(
                    pf,
                    Transform.Identity);
                if (puntos == null || puntos.Count < 3)
                    continue;

                double xMin = double.MaxValue;
                double xMax = double.MinValue;
                double yMin = double.MaxValue;
                double yMax = double.MinValue;
                double sumaZ = 0.0;
                int n = 0;

                foreach (XYZ p in puntos)
                {
                    if (p == null)
                        continue;
                    double x = (p - datos.P0).DotProduct(datos.XAxis);
                    double y = (p - datos.P0).DotProduct(datos.YAxis);
                    double z = (p - datos.P0).DotProduct(datos.ZAxis);
                    xMin = Math.Min(xMin, x);
                    xMax = Math.Max(xMax, x);
                    yMin = Math.Min(yMin, y);
                    yMax = Math.Max(yMax, y);
                    sumaZ += z;
                    n++;
                }

                if (n < 3 || xMax - xMin < xMinAdmitido ||
                    yMax - yMin < yMinAdmitido)
                {
                    continue;
                }

                double zPromedio = sumaZ / n;
                if (superior && zPromedio < zCentro - datos.Alto * 0.05)
                    continue;
                if (!superior && zPromedio > zCentro + datos.Alto * 0.05)
                    continue;

                PlanoCaraPrincipal3DMYG plano =
                    new PlanoCaraPrincipal3DMYG
                    {
                        Origen = pf.Origin,
                        NormalExterior = normal,
                        XMin = xMin,
                        XMax = xMax,
                        YMin = yMin,
                        YMax = yMax,
                        ZPromedio = zPromedio
                    };

                if (superior)
                    datos.PlanosSuperiores3D.Add(plano);
                else
                    datos.PlanosInferiores3D.Add(plano);
            }
        }
    }

    private bool SerieTienePlanoCaraPrincipal3DMYG(
        DatosSerieVigas datos,
        bool superior)
    {
        if (datos == null || datos.Vigas == null)
            return false;

        return datos.Vigas.Any(v =>
            v != null &&
            (superior
                ? v.PlanosSuperiores3D != null && v.PlanosSuperiores3D.Count > 0
                : v.PlanosInferiores3D != null && v.PlanosInferiores3D.Count > 0));
    }

    private bool TrySeleccionarPlanoCaraPrincipal3DMYG(
        DatosViga viga,
        double estacion,
        double yRelativoCentro,
        bool superior,
        out PlanoCaraPrincipal3DMYG plano,
        out double zSuperficie)
    {
        plano = null;
        zSuperficie = 0.0;

        if (viga == null)
            return false;

        List<PlanoCaraPrincipal3DMYG> candidatos = superior
            ? viga.PlanosSuperiores3D
            : viga.PlanosInferiores3D;
        if (candidatos == null || candidatos.Count == 0)
            return false;

        double centroYLocal = (viga.YMin + viga.YMax) * 0.5;
        double yLocal = centroYLocal + yRelativoCentro;
        double toleranciaX = UnitUtils.ConvertToInternalUnits(
            2.0, UnitTypeId.Centimeters);
        double toleranciaY = UnitUtils.ConvertToInternalUnits(
            2.0, UnitTypeId.Centimeters);

        bool encontrado = false;
        double mejorZ = superior ? double.MinValue : double.MaxValue;

        foreach (PlanoCaraPrincipal3DMYG candidato in candidatos)
        {
            if (candidato == null || candidato.Origen == null ||
                candidato.NormalExterior == null)
            {
                continue;
            }

            if (estacion < candidato.XMin - toleranciaX ||
                estacion > candidato.XMax + toleranciaX ||
                yLocal < candidato.YMin - toleranciaY ||
                yLocal > candidato.YMax + toleranciaY)
            {
                continue;
            }

            XYZ baseSinZ = viga.P0
                .Add(viga.XAxis.Multiply(estacion))
                .Add(viga.YAxis.Multiply(yLocal));
            double denominador =
                candidato.NormalExterior.DotProduct(viga.ZAxis);
            if (Math.Abs(denominador) <= 0.02)
                continue;

            double zPlano = candidato.NormalExterior.DotProduct(
                candidato.Origen - baseSinZ) / denominador;

            if (!encontrado ||
                (superior && zPlano > mejorZ) ||
                (!superior && zPlano < mejorZ))
            {
                encontrado = true;
                mejorZ = zPlano;
                plano = candidato;
                zSuperficie = zPlano;
            }
        }

        return encontrado && plano != null;
    }

    private bool TryPuntoOffsetEnPlanoCaraPrincipal3DMYG(
        DatosViga viga,
        double estacion,
        double yRelativoCentro,
        double margenPerpendicular,
        bool superior,
        out XYZ punto)
    {
        punto = null;
        PlanoCaraPrincipal3DMYG plano;
        double zSuperficie;
        if (!TrySeleccionarPlanoCaraPrincipal3DMYG(
                viga,
                estacion,
                yRelativoCentro,
                superior,
                out plano,
                out zSuperficie))
        {
            return false;
        }

        double centroYLocal = (viga.YMin + viga.YMax) * 0.5;
        double yLocal = centroYLocal + yRelativoCentro;
        XYZ baseSinZ = viga.P0
            .Add(viga.XAxis.Multiply(estacion))
            .Add(viga.YAxis.Multiply(yLocal));

        double denominador = plano.NormalExterior.DotProduct(viga.ZAxis);
        if (Math.Abs(denominador) <= 0.02)
            return false;

        // Plano offset hacia el interior: n·(P - Pcara) = -d.
        double zOffset =
            (plano.NormalExterior.DotProduct(plano.Origen - baseSinZ) -
             Math.Max(0.0, margenPerpendicular)) / denominador;

        punto = baseSinZ.Add(viga.ZAxis.Multiply(zOffset));
        return punto != null;
    }

    private bool TryCalcularMargenNormalCaraSerieMYG(
        DatosSerieVigas datos,
        double y,
        double z,
        bool superior,
        out double margen)
    {
        margen = 0.0;
        if (datos == null || datos.TramosRecorrido == null)
            return false;

        TramoRecorridoSerie tramo = datos.TramosRecorrido
            .Where(x => x != null && x.Viga != null)
            .OrderBy(x => x.XInicioSerie)
            .FirstOrDefault();
        if (tramo == null || tramo.Viga == null)
            return false;

        DatosViga viga = tramo.Viga;
        double estacion =
            (tramo.EstacionInicioViga + tramo.EstacionFinViga) * 0.5;
        PlanoCaraPrincipal3DMYG plano;
        double zSuperficie;
        if (!TrySeleccionarPlanoCaraPrincipal3DMYG(
                viga,
                estacion,
                y,
                superior,
                out plano,
                out zSuperficie))
        {
            return false;
        }

        double centroYLocal = (viga.YMin + viga.YMax) * 0.5;
        double centroZLocal = (viga.ZMin + viga.ZMax) * 0.5;
        XYZ puntoBarra = viga.P0
            .Add(viga.XAxis.Multiply(estacion))
            .Add(viga.YAxis.Multiply(centroYLocal + y))
            .Add(viga.ZAxis.Multiply(centroZLocal + z));

        double distanciaFirmada = -plano.NormalExterior.DotProduct(
            puntoBarra - plano.Origen);
        if (double.IsNaN(distanciaFirmada) ||
            double.IsInfinity(distanciaFirmada))
        {
            return false;
        }

        margen = Math.Abs(distanciaFirmada);
        return margen > Tol;
    }

    private XYZ PuntoOffsetEnSegmentoCara(
        DatosViga viga,
        SegmentoPerfilCara seg,
        double estacion,
        double y,
        double margenCara,
        bool superior)
    {
        if (viga == null || seg == null)
            return null;

        XYZ puntoPlano3D;
        if (TryPuntoOffsetEnPlanoCaraPrincipal3DMYG(
                viga,
                estacion,
                y,
                margenCara,
                superior,
                out puntoPlano3D))
        {
            return puntoPlano3D;
        }

        double x0 = seg.X0;
        double x1 = seg.X1;
        double z0 = seg.Z0;
        double z1 = seg.Z1;

        double dx = x1 - x0;
        double dz = z1 - z0;

        if (Math.Abs(dx) <= Tol && Math.Abs(dz) <= Tol)
            return null;

        double t = 0.0;

        if (Math.Abs(dx) > Tol)
            t = (estacion - x0) / dx;

        if (t < -0.001) t = -0.001;
        if (t > 1.001) t = 1.001;

        double x = x0 + dx * t;
        double z = z0 + dz * t;

        double len = Math.Sqrt(dx * dx + dz * dz);

        if (len <= Tol)
            return null;

        // Normal 2D a la cara en el plano local X-Z.
        // Para cara inferior debe apuntar hacia arriba de la sección.
        // Para cara superior debe apuntar hacia abajo de la sección.
        double nx = -dz / len;
        double nz = dx / len;

        if (superior)
        {
            if (nz > 0.0)
            {
                nx = -nx;
                nz = -nz;
            }
        }
        else
        {
            if (nz < 0.0)
            {
                nx = -nx;
                nz = -nz;
            }
        }

        double xOff = x + nx * margenCara;
        double zOff = z + nz * margenCara;

        double centroYLocal = (viga.YMin + viga.YMax) / 2.0;

        return viga.P0
            .Add(viga.XAxis.Multiply(xOff))
            .Add(viga.YAxis.Multiply(centroYLocal + y))
            .Add(viga.ZAxis.Multiply(zOff));
    }

    private List<SegmentoPerfilCara> CrearPerfilSimpleCara(
        DatosViga viga,
        bool superior)
    {
        List<SegmentoPerfilCara> perfil = new List<SegmentoPerfilCara>();

        if (viga == null)
            return perfil;

        double z0 = superior ? viga.ZSuperiorInicio : viga.ZInferiorInicio;
        double z1 = superior ? viga.ZSuperiorFin : viga.ZInferiorFin;

        if (!viga.TienePerfilSeccionVariable)
        {
            z0 = superior ? viga.ZMax : viga.ZMin;
            z1 = z0;
        }

        perfil.Add(new SegmentoPerfilCara(
            viga.SolidoMin,
            z0,
            viga.SolidoMax,
            z1));

        return perfil;
    }

    private bool DebeUsarRecorridoProyectado(
        DatosSerieVigas datos)
    {
        if (datos == null)
            return false;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido;

        if (tramos == null || tramos.Count < 2)
            return false;

        XYZ dirBase = null;

        foreach (TramoRecorridoSerie tramo in tramos)
        {
            if (tramo == null || tramo.Direccion == null)
                continue;

            XYZ dir = tramo.Direccion;

            if (dir.GetLength() <= Tol)
                continue;

            dir = dir.Normalize();

            if (dirBase == null)
            {
                dirBase = dir;
                continue;
            }

            double dot = Math.Abs(dirBase.DotProduct(dir));

            if (dot > 1.0) dot = 1.0;
            if (dot < -1.0) dot = -1.0;

            double angulo = Math.Acos(dot) * 180.0 / Math.PI;

            // Solo se activa cuando hay quiebre real.
            // Horizontales e inclinados colineales se quedan con la lógica original.
            if (angulo > 0.50)
                return true;
        }

        return false;
    }

    private List<XYZ> ConstruirPuntosBarraConEmpalmeOriginal(
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal seg,
        double y,
        double z,
        bool crearEmpalmes,
        double longitudEmpalme,
        XYZ direccionDesfaseEmpalme,
        double desfaseEmpalme)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (datos == null || seg == null)
            return puntos;

        if (seg.XFin <= seg.XInicio + Tol)
            return puntos;

        // V11.7:
        // El quiebre NO es un elemento independiente.
        // Este método devuelve una ÚNICA cadena de puntos perteneciente a la
        // pieza comercial que comienza en el empalme:
        //
        //   tramo traslapado desplazado -> diagonal -> continuación alineada.
        //
        // Todas esas curvas se envían juntas a CreateFromCurves/CreateFreeForm,
        // por lo que el quiebre no genera otro Rebar ni otro recuento.
        bool tieneQuiebreEmpalme =
            crearEmpalmes &&
            seg.TieneEmpalmeInicio &&
            longitudEmpalme > Tol &&
            direccionDesfaseEmpalme != null &&
            direccionDesfaseEmpalme.GetLength() > Tol &&
            desfaseEmpalme > Tol;

        if (!tieneQuiebreEmpalme)
        {
            // Una sola pieza continua, incluyendo:
            // - todos los cuerpos sólidos;
            // - el tramo vacío entre elementos;
            // - los cambios de dirección entre vigas.
            AgregarPuntosRecorridoProyectado(
                puntos,
                datos,
                seg.XInicio,
                seg.XFin,
                y,
                z,
                null);

            return LimpiarPuntosConsecutivos(puntos);
        }

        XYZ offset =
            direccionDesfaseEmpalme
                .Normalize()
                .Multiply(desfaseEmpalme);

        double xEmpalmeFin =
            Math.Min(
                seg.XInicio + longitudEmpalme,
                seg.XFin);

        double espacioDespuesEmpalme =
            seg.XFin - xEmpalmeFin;

        double longitudDiagonal;

        if (!TryObtenerLongitudDiagonalQuiebreSeguraMYG(
                espacioDespuesEmpalme,
                desfaseEmpalme,
                out longitudDiagonal))
        {
            // No se sustituye el empalme por una barra recta colineal.
            // Un resultado vacío obliga al llamador a probar el set FreeForm
            // completo o a hacer rollback de la pieza.
            return new List<XYZ>();
        }

        double xDiagonalFin =
            Math.Min(
                xEmpalmeFin + longitudDiagonal,
                seg.XFin);

        // Parte traslapada desplazada.
        AgregarPuntosRecorridoProyectado(
            puntos,
            datos,
            seg.XInicio,
            xEmpalmeFin,
            y,
            z,
            offset);

        if (xDiagonalFin > xEmpalmeFin + Tol)
        {
            XYZ pDiagonalFin =
                PuntoLocal(
                    datos,
                    xDiagonalFin,
                    y,
                    z);

            AgregarPuntoSiValido(
                puntos,
                pDiagonalFin);

            if (seg.XFin > xDiagonalFin + Tol)
            {
                // Continuación completa después del quiebre.
                // Aquí también se insertan los extremos del vacío.
                AgregarPuntosRecorridoProyectado(
                    puntos,
                    datos,
                    xDiagonalFin,
                    seg.XFin,
                    y,
                    z,
                    null);
            }
        }
        else
        {
            XYZ pFin =
                PuntoLocal(
                    datos,
                    seg.XFin,
                    y,
                    z);

            AgregarPuntoSiValido(
                puntos,
                pFin);
        }

        return LimpiarPuntosConsecutivos(puntos);
    }


    private void AgregarPuntosRecorridoProyectado(
        List<XYZ> puntos,
        DatosSerieVigas datos,
        double xInicio,
        double xFin,
        double y,
        double z,
        XYZ offset)
    {
        if (puntos == null || datos == null)
            return;

        List<TransicionRecorrido> transiciones = ObtenerTransicionesProyectadas(
            datos,
            y,
            z);

        bool invertir = xFin < xInicio;
        double a = Math.Min(xInicio, xFin);
        double b = Math.Max(xInicio, xFin);

        List<TransicionRecorrido> dentro = transiciones
            .Where(t => t != null && t.Punto != null && t.XLocal > a + Tol && t.XLocal < b - Tol)
            .OrderBy(t => t.XLocal)
            .ToList();

        if (invertir)
            dentro.Reverse();

        XYZ pInicio = PuntoLocal(datos, xInicio, y, z);

        if (offset != null && offset.GetLength() > Tol)
            pInicio = pInicio.Add(offset);

        AgregarPuntoSiValido(puntos, pInicio);

        foreach (TransicionRecorrido tr in dentro)
        {
            XYZ p = tr.Punto;

            if (offset != null && offset.GetLength() > Tol)
                p = p.Add(offset);

            AgregarPuntoSiValido(puntos, p);
        }

        XYZ pFin = PuntoLocal(datos, xFin, y, z);

        if (offset != null && offset.GetLength() > Tol)
            pFin = pFin.Add(offset);

        AgregarPuntoSiValido(puntos, pFin);
    }

    private List<TransicionRecorrido> ObtenerTransicionesProyectadas(
        DatosSerieVigas datos,
        double y,
        double z)
    {
        List<TransicionRecorrido> resultado = new List<TransicionRecorrido>();

        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count < 2)
            return resultado;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null && t.Viga != null)
            .OrderBy(t => t.XInicioSerie)
            .ToList();

        for (int i = 0; i < tramos.Count - 1; i++)
        {
            TramoRecorridoSerie tramoAnterior = tramos[i];
            TramoRecorridoSerie tramoSiguiente = tramos[i + 1];

            if (tramoAnterior == null || tramoSiguiente == null)
                continue;

            double separacionSerie =
                tramoSiguiente.XInicioSerie -
                tramoAnterior.XFinSerie;

            double toleranciaVacio =
                UnitUtils.ConvertToInternalUnits(
                    0.2,
                    UnitTypeId.Centimeters);

            if (separacionSerie > toleranciaVacio)
            {
                // Dos ElementId físicamente separados:
                // se conservan los dos extremos del vacío. La línea entre ambos
                // forma parte de la geometría real y de la longitud de la barra.
                XYZ puntoFinAnterior = PuntoEnTramoRecorrido(
                    datos,
                    tramoAnterior,
                    tramoAnterior.EstacionFinViga,
                    y,
                    z);

                XYZ puntoInicioSiguiente = PuntoEnTramoRecorrido(
                    datos,
                    tramoSiguiente,
                    tramoSiguiente.EstacionInicioViga,
                    y,
                    z);

                if (puntoFinAnterior != null)
                {
                    resultado.Add(
                        new TransicionRecorrido(
                            tramoAnterior.XFinSerie,
                            puntoFinAnterior));
                }

                if (puntoInicioSiguiente != null)
                {
                    resultado.Add(
                        new TransicionRecorrido(
                            tramoSiguiente.XInicioSerie,
                            puntoInicioSiguiente));
                }

                continue;
            }

            XYZ puntoProyectado = CalcularPuntoQuiebreProyectado(
                datos,
                tramoAnterior,
                tramoSiguiente,
                y,
                z);

            if (puntoProyectado == null)
                continue;

            // Elementos continuos o unidos: se mantiene el quiebre proyectado.
            resultado.Add(
                new TransicionRecorrido(
                    tramoAnterior.XFinSerie,
                    puntoProyectado));
        }

        return resultado
            .OrderBy(t => t.XLocal)
            .ToList();
    }

    private XYZ CalcularPuntoQuiebreProyectado(
        DatosSerieVigas datos,
        TramoRecorridoSerie tramoAnterior,
        TramoRecorridoSerie tramoSiguiente,
        double y,
        double z)
    {
        if (datos == null || tramoAnterior == null || tramoSiguiente == null)
            return null;

        XYZ pAnterior = PuntoEnTramoRecorrido(
            datos,
            tramoAnterior,
            tramoAnterior.EstacionFinViga,
            y,
            z);

        XYZ pSiguiente = PuntoEnTramoRecorrido(
            datos,
            tramoSiguiente,
            tramoSiguiente.EstacionInicioViga,
            y,
            z);

        if (pAnterior == null || pSiguiente == null)
            return null;

        XYZ dirAnterior = tramoAnterior.Direccion;
        XYZ dirSiguiente = tramoSiguiente.Direccion;

        XYZ interseccion;

        if (TryIntersecarLineasProyectadas(
            pAnterior,
            dirAnterior,
            pSiguiente,
            dirSiguiente,
            out interseccion))
        {
            return interseccion;
        }

        // Si son casi paralelos, no se genera un quiebre extraño.
        return pAnterior.Add(pSiguiente).Multiply(0.5);
    }

    private bool TryIntersecarLineasProyectadas(
        XYZ p1,
        XYZ d1,
        XYZ p2,
        XYZ d2,
        out XYZ punto)
    {
        punto = null;

        if (p1 == null || p2 == null || d1 == null || d2 == null)
            return false;

        if (d1.GetLength() <= Tol || d2.GetLength() <= Tol)
            return false;

        d1 = d1.Normalize();
        d2 = d2.Normalize();

        double a = d1.DotProduct(d1);
        double b = d1.DotProduct(d2);
        double c = d2.DotProduct(d2);
        XYZ w0 = p1 - p2;
        double d = d1.DotProduct(w0);
        double e = d2.DotProduct(w0);
        double denominador = a * c - b * b;

        if (Math.Abs(denominador) <= 1e-9)
            return false;

        double s = (b * e - c * d) / denominador;
        double t = (a * e - b * d) / denominador;

        XYZ q1 = p1.Add(d1.Multiply(s));
        XYZ q2 = p2.Add(d2.Multiply(t));

        punto = q1.Add(q2).Multiply(0.5);

        return true;
    }

    private void AgregarPuntoSiValido(
        List<XYZ> puntos,
        XYZ punto)
    {
        if (puntos == null || punto == null)
            return;

        if (puntos.Count == 0)
        {
            puntos.Add(punto);
            return;
        }

        XYZ ultimo = puntos[puntos.Count - 1];

        if (ultimo == null || (punto - ultimo).GetLength() > Tol)
            puntos.Add(punto);
    }

    private List<XYZ> LimpiarPuntosConsecutivos(
        List<XYZ> puntos)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (puntos == null)
            return resultado;

        foreach (XYZ p in puntos)
            AgregarPuntoSiValido(resultado, p);

        return resultado;
    }

    private XYZ PuntoLocal(
        DatosSerieVigas datos,
        double x,
        double y,
        double z)
    {
        if (datos == null)
            return null;

        XYZ puntoOriginal = datos.PInicio
            .Add(datos.XAxis.Multiply(x))
            .Add(datos.YAxis.Multiply(y))
            .Add(datos.ZAxis.Multiply(z));

        if (datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return puntoOriginal;

        XYZ puntoTransicion;

        if (TryObtenerPuntoTransicionCercana(
            datos,
            x,
            y,
            z,
            out puntoTransicion))
        {
            return puntoTransicion;
        }

        XYZ puntoEnVacio;

        if (TryObtenerPuntoEnVacioEntreTramosMYG(
            datos,
            x,
            y,
            z,
            out puntoEnVacio))
        {
            return puntoEnVacio;
        }

        TramoRecorridoSerie tramo =
            ObtenerTramoParaEstacion(datos, x);

        if (tramo == null)
            return puntoOriginal;

        double estacionViga = ObtenerEstacionVigaDesdeXSerie(tramo, x);

        XYZ puntoTramo = PuntoEnTramoRecorrido(
            datos,
            tramo,
            estacionViga,
            y,
            z);

        return puntoTramo ?? puntoOriginal;
    }

    private bool TryObtenerPuntoTransicionCercana(
        DatosSerieVigas datos,
        double x,
        double y,
        double z,
        out XYZ punto)
    {
        punto = null;

        List<TransicionRecorrido> transiciones = ObtenerTransicionesProyectadas(
            datos,
            y,
            z);

        if (transiciones == null || transiciones.Count == 0)
            return false;

        double tolerancia = UnitUtils.ConvertToInternalUnits(
            1.0,
            UnitTypeId.Centimeters);

        foreach (TransicionRecorrido tr in transiciones)
        {
            if (tr == null || tr.Punto == null)
                continue;

            if (Math.Abs(tr.XLocal - x) <= tolerancia)
            {
                punto = tr.Punto;
                return true;
            }
        }

        return false;
    }

    private bool TryObtenerPuntoEnVacioEntreTramosMYG(
        DatosSerieVigas datos,
        double xSerie,
        double y,
        double z,
        out XYZ punto)
    {
        punto = null;

        if (datos == null ||
            datos.TramosRecorrido == null ||
            datos.TramosRecorrido.Count < 2)
        {
            return false;
        }

        List<TramoRecorridoSerie> tramos =
            datos.TramosRecorrido
                .Where(t => t != null && t.Viga != null)
                .OrderBy(t => t.XInicioSerie)
                .ToList();

        double tolerancia =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        for (int i = 0; i < tramos.Count - 1; i++)
        {
            TramoRecorridoSerie anterior = tramos[i];
            TramoRecorridoSerie siguiente = tramos[i + 1];

            double vacioInicio = anterior.XFinSerie;
            double vacioFin = siguiente.XInicioSerie;

            if (vacioFin <= vacioInicio + tolerancia)
                continue;

            if (xSerie <= vacioInicio + tolerancia ||
                xSerie >= vacioFin - tolerancia)
            {
                continue;
            }

            XYZ p0 = PuntoEnTramoRecorrido(
                datos,
                anterior,
                anterior.EstacionFinViga,
                y,
                z);

            XYZ p1 = PuntoEnTramoRecorrido(
                datos,
                siguiente,
                siguiente.EstacionInicioViga,
                y,
                z);

            if (p0 == null || p1 == null)
                return false;

            double factor =
                (xSerie - vacioInicio) /
                (vacioFin - vacioInicio);

            factor = Math.Max(0.0, Math.Min(1.0, factor));

            punto = p0.Add(
                p1.Subtract(p0).Multiply(factor));

            return true;
        }

        return false;
    }

    private TramoRecorridoSerie ObtenerTramoParaEstacion(
        DatosSerieVigas datos,
        double xSerie)
    {
        if (datos == null || datos.TramosRecorrido == null || datos.TramosRecorrido.Count == 0)
            return null;

        List<TramoRecorridoSerie> tramos = datos.TramosRecorrido
            .Where(t => t != null)
            .OrderBy(t => t.XInicioSerie)
            .ToList();

        double tolerancia = UnitUtils.ConvertToInternalUnits(
            1.0,
            UnitTypeId.Centimeters);

        foreach (TramoRecorridoSerie tramo in tramos)
        {
            if (xSerie >= tramo.XInicioSerie - tolerancia &&
                xSerie <= tramo.XFinSerie + tolerancia)
            {
                return tramo;
            }
        }

        if (xSerie < tramos[0].XInicioSerie)
            return tramos[0];

        if (xSerie > tramos[tramos.Count - 1].XFinSerie)
            return tramos[tramos.Count - 1];

        TramoRecorridoSerie cercano = null;
        double distanciaMin = double.MaxValue;

        foreach (TramoRecorridoSerie tramo in tramos)
        {
            double dist = 0.0;

            if (xSerie < tramo.XInicioSerie)
                dist = tramo.XInicioSerie - xSerie;
            else if (xSerie > tramo.XFinSerie)
                dist = xSerie - tramo.XFinSerie;

            if (dist < distanciaMin)
            {
                distanciaMin = dist;
                cercano = tramo;
            }
        }

        return cercano ?? tramos[0];
    }

    private double ObtenerEstacionVigaDesdeXSerie(
        TramoRecorridoSerie tramo,
        double xSerie)
    {
        if (tramo == null)
            return 0.0;

        double longitudSerie = tramo.XFinSerie - tramo.XInicioSerie;
        double deltaEstacion = tramo.EstacionFinViga - tramo.EstacionInicioViga;

        if (Math.Abs(longitudSerie) <= Tol)
            return tramo.EstacionInicioViga;

        double factor = (xSerie - tramo.XInicioSerie) / longitudSerie;

        // No se clampa el factor: así la longitud de desarrollo sigue saliendo
        // del extremo inicial/final cuando el usuario ingresa desarrollo > 0.
        return tramo.EstacionInicioViga + deltaEstacion * factor;
    }

    private XYZ PuntoEnTramoRecorrido(
        DatosSerieVigas datos,
        TramoRecorridoSerie tramo,
        double estacionViga,
        double y,
        double z)
    {
        if (datos == null || tramo == null || tramo.Viga == null)
            return null;

        DatosViga viga = tramo.Viga;

        XYZ puntoEje = viga.P0.Add(viga.XAxis.Multiply(estacionViga));

        double centroYLocal = (viga.YMin + viga.YMax) / 2.0;

        double zSuperior = ObtenerZSuperiorEnEstacion(viga, estacionViga);
        double zInferior = ObtenerZInferiorEnEstacion(viga, estacionViga);

        if (zSuperior <= zInferior + Tol)
        {
            zSuperior = viga.ZMax;
            zInferior = viga.ZMin;
        }

        double centroZLocal = (zSuperior + zInferior) / 2.0;

        XYZ centroSeccion = puntoEje
            .Add(viga.YAxis.Multiply(centroYLocal))
            .Add(viga.ZAxis.Multiply(centroZLocal));

        double zLocal;

        if (z > Tol)
        {
            // z llega desde la lógica original como:
            // datos.Alto/2 - recubrimiento - radio.
            // Por eso el margen real respecto a la cara superior es:
            double margenSuperior = datos.Alto / 2.0 - z;
            zLocal = (zSuperior - margenSuperior) - centroZLocal;
        }
        else if (z < -Tol)
        {
            // z llega desde la lógica original como:
            // -datos.Alto/2 + recubrimiento + radio.
            // Por eso el margen real respecto a la cara inferior es:
            double margenInferior = datos.Alto / 2.0 + z;
            zLocal = (zInferior + margenInferior) - centroZLocal;
        }
        else
        {
            // Acero central: sigue el eje medio real entre cara superior e inferior.
            zLocal = 0.0;
        }

        // V11.49:
        // Mantener el MISMO lado transversal en todos los tramos de una serie.
        // Revit puede entregar XAxis/YAxis locales invertidos entre dos vigas
        // colineales. Si se usa viga.YAxis directamente, una barra situada a la
        // izquierda en T1 puede pasar a la derecha en T2 y formar una X.
        XYZ ejeYContinuo = viga.YAxis;

        if (ejeYContinuo != null &&
            ejeYContinuo.GetLength() > Tol &&
            datos.YAxis != null &&
            datos.YAxis.GetLength() > Tol)
        {
            ejeYContinuo = ejeYContinuo.Normalize();

            if (ejeYContinuo.DotProduct(datos.YAxis.Normalize()) < 0.0)
                ejeYContinuo = ejeYContinuo.Multiply(-1.0);
        }
        else
        {
            ejeYContinuo =
                datos.YAxis != null && datos.YAxis.GetLength() > Tol
                    ? datos.YAxis.Normalize()
                    : XYZ.BasisY;
        }

        return centroSeccion
            .Add(ejeYContinuo.Multiply(y))
            .Add(viga.ZAxis.Multiply(zLocal));
    }

    private double ObtenerZSuperiorEnEstacion(
        DatosViga viga,
        double estacionViga)
    {
        if (viga == null)
            return 0.0;

        if (!viga.TienePerfilSeccionVariable ||
            Math.Abs(viga.SolidoMax - viga.SolidoMin) <= Tol)
        {
            return viga.ZMax;
        }

        double t = (estacionViga - viga.SolidoMin) /
            (viga.SolidoMax - viga.SolidoMin);

        return viga.ZSuperiorInicio +
            (viga.ZSuperiorFin - viga.ZSuperiorInicio) * t;
    }

    private double ObtenerZInferiorEnEstacion(
        DatosViga viga,
        double estacionViga)
    {
        if (viga == null)
            return 0.0;

        if (!viga.TienePerfilSeccionVariable ||
            Math.Abs(viga.SolidoMax - viga.SolidoMin) <= Tol)
        {
            return viga.ZMin;
        }

        double t = (estacionViga - viga.SolidoMin) /
            (viga.SolidoMax - viga.SolidoMin);

        return viga.ZInferiorInicio +
            (viga.ZInferiorFin - viga.ZInferiorInicio) * t;
    }


    private double ObtenerEstacionGlobal(
        DatosSerieVigas datos,
        XYZ punto)
    {
        if (datos == null || punto == null || datos.OrigenGlobal == null || datos.XAxis == null)
            return 0.0;

        return (punto - datos.OrigenGlobal).DotProduct(datos.XAxis);
    }



    private Element ObtenerHostRealRebarLongitudinalMYG(
        Document doc,
        Rebar rebar,
        Element hostRespaldo)
    {
        if (doc == null || rebar == null)
            return hostRespaldo;

        try
        {
            ElementId hostId = rebar.GetHostId();

            if (hostId != null &&
                hostId != ElementId.InvalidElementId)
            {
                Element hostReal = doc.GetElement(hostId);

                if (hostReal != null)
                    return hostReal;
            }
        }
        catch
        {
        }

        return hostRespaldo;
    }


    // =========================================================
    // PARÁMETROS DE INSTANCIA PARA ACEROS LONGITUDINALES
    // =========================================================
    // Se aplican al elemento Rebar creado, sin intervenir la geometría,
    // quiebres, empalmes ni reglas de desarrollo.
    private void AplicarParametrosInstanciaAceroLongitudinal(
        Document doc,
        Rebar rebar,
        Element host,
        string tipoElementoLongitudinal)
    {
        if (rebar == null)
            return;

        string descripcionHost = ObtenerDescripcionTipoHost(host);
        string ubicacionHost = ObtenerValorParametroInstanciaComoTexto(
            host,
            "STR_Ubicación",
            "STR_Ubicacion",
            "STR Ubicación",
            "STR Ubicacion");

        string nivelHost = ObtenerValorParametroInstanciaComoTexto(
            host,
            "GEN_Nivel",
            "GEN Nivel");

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "STR_AnfitriónAcero",
                "STR_AnfitrionAcero",
                "STR_Anfitrión Acero",
                "STR_Anfitrion Acero"
            },
            descripcionHost,
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "STR_Materialidad",
                "STR Materialidad"
            },
            "Acero de refuerzo corrugado",
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "STR_Resistencia",
                "STR Resistencia"
            },
            "F'y=4200 kg/cm²",
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "STR_TipoDeElemento (V/H)",
                "STR_TipoDeElemento",
                "STR TipoDeElemento (V/H)",
                "STR TipoDeElemento"
            },
            tipoElementoLongitudinal,
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "STR_Ubicación",
                "STR_Ubicacion",
                "STR Ubicación",
                "STR Ubicacion"
            },
            ubicacionHost,
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "GEN_Disciplina",
                "GEN Disciplina"
            },
            "Estructuras",
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "GEN_ID Elemento",
                "GEN_IDElemento",
                "GEN ID Elemento"
            },
            ObtenerIdElementoComoTexto(rebar),
            true);

        AsignarParametroTextoSiExiste(
            rebar,
            new string[]
            {
                "GEN_Nivel",
                "GEN Nivel"
            },
            nivelHost,
            true);
    }

    private string ObtenerDescripcionTipoHost(Element host)
    {
        if (host == null)
            return "";

        try
        {
            Document doc = host.Document;

            if (doc == null)
                return "";

            ElementId tipoId = host.GetTypeId();

            if (tipoId == null || tipoId == ElementId.InvalidElementId)
                return "";

            Element tipo = doc.GetElement(tipoId);

            string valor = ObtenerValorParametroInstanciaComoTexto(
                tipo,
                "Descripción de la cimentación",
                "Descripcion de la cimentacion",
                "Descripción cimentación",
                "Descripcion cimentacion",
                "Descripción",
                "Descripcion",
                "Description");

            if (!string.IsNullOrWhiteSpace(valor))
                return valor.Trim();

            try
            {
                return tipo.Name ?? "";
            }
            catch
            {
                return "";
            }
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerValorParametroInstanciaComoTexto(
        Element elemento,
        params string[] nombres)
    {
        if (elemento == null || nombres == null)
            return "";

        foreach (string nombre in nombres)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                continue;

            try
            {
                IList<Parameter> parametros =
                    elemento.GetParameters(nombre);

                if (parametros == null || parametros.Count == 0)
                    continue;

                foreach (Parameter p in parametros)
                {
                    if (p == null)
                        continue;

                    string valor =
                        ObtenerValorParametroComoTexto(p);

                    if (!string.IsNullOrWhiteSpace(valor))
                        return valor.Trim();
                }
            }
            catch
            {
            }
        }

        return "";
    }

    private string ObtenerValorParametroComoTexto(Parameter p)
    {
        if (p == null)
            return "";

        try
        {
            if (p.StorageType == StorageType.String)
                return p.AsString() ?? "";

            string valorTexto = p.AsValueString();

            if (!string.IsNullOrWhiteSpace(valorTexto))
                return valorTexto;

            if (p.StorageType == StorageType.Integer)
                return p.AsInteger().ToString(System.Globalization.CultureInfo.InvariantCulture);

            if (p.StorageType == StorageType.Double)
                return p.AsDouble().ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);

            if (p.StorageType == StorageType.ElementId)
            {
                ElementId id = p.AsElementId();

                if (id == null || id == ElementId.InvalidElementId)
                    return "";

                return id.Value.ToString(System.Globalization.CultureInfo.InvariantCulture);
            }
        }
        catch
        {
        }

        return "";
    }

    private string ObtenerIdElementoComoTexto(Element elemento)
    {
        if (elemento == null)
            return "";

        try
        {
            return elemento.Id.Value.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        catch
        {
            try
            {
                return elemento.Id.Value.ToString(System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                return "";
            }
        }
    }

    private void AsignarParametroTextoSiExiste(
        Element elemento,
        string[] nombres,
        string valor,
        bool permitirVacio)
    {
        if (elemento == null || nombres == null)
            return;

        if (valor == null)
            valor = "";

        if (!permitirVacio &&
            string.IsNullOrWhiteSpace(valor))
        {
            return;
        }

        foreach (string nombre in nombres)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                continue;

            IList<Parameter> parametros = null;

            try
            {
                parametros = elemento.GetParameters(nombre);
            }
            catch
            {
                parametros = null;
            }

            if (parametros == null || parametros.Count == 0)
                continue;

            foreach (Parameter p in parametros)
            {
                if (p == null || p.IsReadOnly)
                    continue;

                try
                {
                    if (p.StorageType == StorageType.String)
                    {
                        p.Set(valor);
                        continue;
                    }

                    if (p.StorageType == StorageType.Integer)
                    {
                        int valorEntero;

                        if (int.TryParse(
                            valor,
                            System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out valorEntero))
                        {
                            p.Set(valorEntero);
                        }

                        continue;
                    }

                    if (p.StorageType == StorageType.Double)
                    {
                        double valorDouble;

                        if (double.TryParse(
                            valor,
                            System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out valorDouble))
                        {
                            p.Set(valorDouble);
                        }
                    }
                }
                catch
                {
                    // Un parámetro incompatible no bloquea los demás
                    // parámetros que comparten el mismo nombre.
                }
            }
        }
    }

    // =========================================================
    // V11.6 - CREACIÓN SIN FRAGMENTAR POR HOST
    // =========================================================
    private int CrearRebarLongitudinalConReglaGrupoPiezaContinuaMYG(
        Document doc,
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento,
        RebarBarType barType,
        XYZ normalDistribucion,
        List<XYZ> puntosBarra,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho,
        AceroVigaReglaGrupoLongitudinal regla,
        int cantidad,
        double espaciado,
        double longitudDistribucion,
        string tipoElementoLongitudinal,
        bool incluirPrimeraBarra,
        bool incluirUltimaBarra)
    {
        List<Element> hosts =
            ObtenerHostsCandidatosPiezaContinuaLongitudinalMYG(
                datos,
                segmento);

        foreach (Element host in hosts)
        {
            if (host == null)
                continue;

            int creadas =
                CrearRebarLongitudinalConReglaGrupoMYG(
                    doc,
                    host,
                    barType,
                    normalDistribucion,
                    puntosBarra,
                    ganchoInicio,
                    longitudGanchoInicio,
                    ganchoFin,
                    longitudGanchoFin,
                    direccionGancho,
                    regla,
                    cantidad,
                    espaciado,
                    longitudDistribucion,
                    tipoElementoLongitudinal,
                    incluirPrimeraBarra,
                    incluirUltimaBarra);

            if (creadas > 0)
                return creadas;
        }

        return 0;
    }


    private int CrearRebarLongitudinalConNumeroFijoPiezaContinuaMYG(
        Document doc,
        DatosSerieVigas datos,
        SegmentoAceroLongitudinal segmento,
        RebarBarType barType,
        XYZ normal,
        List<XYZ> puntosBarra,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho,
        int cantidad,
        double longitudDistribucion,
        string tipoElementoLongitudinal)
    {
        List<Element> hosts =
            ObtenerHostsCandidatosPiezaContinuaLongitudinalMYG(
                datos,
                segmento);

        foreach (Element host in hosts)
        {
            if (host == null)
                continue;

            int creadas =
                CrearRebarLongitudinalConNumeroFijo(
                    doc,
                    host,
                    barType,
                    normal,
                    puntosBarra,
                    ganchoInicio,
                    longitudGanchoInicio,
                    ganchoFin,
                    longitudGanchoFin,
                    direccionGancho,
                    cantidad,
                    longitudDistribucion,
                    tipoElementoLongitudinal);

            if (creadas > 0)
                return creadas;
        }

        return 0;
    }


    private int CrearRebarLongitudinalConReglaGrupoMYG(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normalDistribucion,
        List<XYZ> puntosBarra,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho,
        AceroVigaReglaGrupoLongitudinal regla,
        int cantidad,
        double espaciado,
        double longitudDistribucion,
        string tipoElementoLongitudinal = "",
        bool incluirPrimeraBarra = true,
        bool incluirUltimaBarra = true)
    {
        if (doc == null || host == null || barType == null ||
            puntosBarra == null || puntosBarra.Count < 2 ||
            normalDistribucion == null ||
            normalDistribucion.GetLength() <= Tol)
        {
            return 0;
        }

        int numero = Math.Max(1, Math.Min(1002, cantidad));
        double separacion = Math.Max(Tol, espaciado);
        double longitud = Math.Max(0.0, longitudDistribucion);

        // NÚMERO FIJO utiliza la regla real Fixed Number de Revit y conserva
        // la cantidad indicada en la ventana. El método de respaldo también
        // soporta conjuntos Free Form cuando la barra longitudinal tiene
        // quiebres o empalmes.
        if (regla !=
            AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
        {
            return CrearRebarLongitudinalConNumeroFijo(
                doc,
                host,
                barType,
                normalDistribucion,
                puntosBarra,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                direccionGancho,
                numero,
                longitud,
                tipoElementoLongitudinal,
                incluirPrimeraBarra,
                incluirUltimaBarra,
                false);
        }

        if (numero <= 1 || longitud <= Tol)
        {
            return CrearRebarLongitudinalConNumeroFijo(
                doc,
                host,
                barType,
                normalDistribucion,
                puntosBarra,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                direccionGancho,
                1,
                0.0,
                tipoElementoLongitudinal,
                incluirPrimeraBarra,
                incluirUltimaBarra,
                false);
        }

        List<XYZ> puntosBase = ConstruirPuntosGeometricosLongitudinalMYG(
            puntosBarra,
            ganchoInicio,
            longitudGanchoInicio,
            ganchoFin,
            longitudGanchoFin,
            direccionGancho);

        // V11.3: una barra con un ÚNICO quiebre local de empalme sigue siendo
        // una forma plana shape-driven válida. Ya no se exige que tenga solo
        // dos puntos. Se admiten hasta 4 puntos (tramo desplazado, diagonal y
        // continuación), siempre que todos permanezcan en un mismo plano cuya
        // normal sea la dirección de distribución del set.
        if (puntosBase == null || puntosBase.Count < 2)
            return 0;

        if (!EsTrayectoriaSimpleShapeDrivenEmpalmeMYG(
                puntosBase,
                normalDistribucion))
        {
            return 0;
        }

        List<XYZ> normales =
            ConstruirNormalesPlanoParaDistribucionMYG(
                puntosBase,
                normalDistribucion);

        foreach (XYZ normal in normales)
        {
            Rebar rebar = CrearRebarLongitudinalDesdePuntos(
                doc,
                host,
                barType,
                normal,
                puntosBarra,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                direccionGancho);

            if (rebar == null)
                continue;

            try
            {
                // Asegura que Revit haya resuelto la forma antes de solicitar
                // el accessor de distribución nativo.
                doc.Regenerate();
                RebarShapeDrivenAccessor accessor =
                    rebar.GetShapeDrivenAccessor();

                if (regla ==
                    AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
                {
                    accessor.SetLayoutAsMaximumSpacing(
                        separacion,
                        longitud,
                        true,
                        incluirPrimeraBarra,
                        incluirUltimaBarra);
                }
                else
                {
                    accessor.SetLayoutAsFixedNumber(
                        numero,
                        longitud,
                        true,
                        incluirPrimeraBarra,
                        incluirUltimaBarra);
                }

                AplicarParametrosInstanciaAceroLongitudinal(
                    doc,
                    rebar,
                    host,
                    tipoElementoLongitudinal);

                if (regla ==
                    AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
                {
                    int cantidadCalculada = Math.Max(
                        2,
                        (int)Math.Ceiling(longitud / separacion) + 1);
                    if (!incluirPrimeraBarra) cantidadCalculada--;
                    if (!incluirUltimaBarra) cantidadCalculada--;
                    return Math.Max(0, cantidadCalculada);
                }

                int visibles = numero;
                if (!incluirPrimeraBarra) visibles--;
                if (!incluirUltimaBarra) visibles--;
                return Math.Max(0, visibles);
            }
            catch
            {
                try
                {
                    doc.Delete(rebar.Id);
                }
                catch
                {
                }
            }
        }

        return 0;
    }

    // =========================================================
    // NORMAL DEL PLANO PARA UNA DISTRIBUCIÓN TRANSVERSAL REAL
    // =========================================================
    // Rebar.CreateFromCurves solicita la normal del PLANO de la barra, no la
    // dirección en la que se distribuyen las copias. Para una barra longitudinal
    // recta, la normal correcta es:
    //      dirección longitudinal × dirección transversal de distribución.
    // Con esto, el accessor distribuye el set a lo largo de la guía inclinada y
    // ocupa exactamente la longitud definida entre el primer y el último centro.
    // =========================================================
    // NORMAL DEL PLANO PARA UN SET LONGITUDINAL
    // =========================================================
    // Para una barra longitudinal recta, la dirección de distribución Y-Z es
    // también la normal del plano que contiene la barra base. Revit traslada
    // las posiciones del set a lo largo de esa normal. La versión anterior
    // usaba direcciónBarra x direcciónSet, rotando 90 grados la normal y
    // provocando que CreateFromCurves/ShapeDrivenAccessor fallara y terminara
    // en Forma libre.
    private List<XYZ> ConstruirNormalesPlanoParaDistribucionMYG(
        List<XYZ> puntosBase,
        XYZ direccionDistribucion)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (puntosBase == null || puntosBase.Count < 2)
            return resultado;

        XYZ primero = puntosBase[0];
        XYZ ultimo = puntosBase[puntosBase.Count - 1];
        if (primero == null || ultimo == null)
            return resultado;

        XYZ direccionBarra = ultimo - primero;
        if (direccionBarra.GetLength() <= Tol)
            return resultado;
        direccionBarra = direccionBarra.Normalize();

        XYZ normalPlano = direccionDistribucion;
        if (normalPlano == null || normalPlano.GetLength() <= Tol)
            return resultado;

        // Elimina cualquier componente numérica paralela a la barra.
        normalPlano = normalPlano.Subtract(
            direccionBarra.Multiply(
                normalPlano.DotProduct(direccionBarra)));

        if (normalPlano.GetLength() <= Tol)
            return resultado;

        normalPlano = normalPlano.Normalize();
        resultado.Add(normalPlano);
        resultado.Add(normalPlano.Multiply(-1.0));
        return resultado;
    }

    // =========================================================
    // V11.3 - VALIDACIÓN DE FORMA NATIVA PARA QUIEBRE DE EMPALME
    // =========================================================
    // Acepta:
    //   2 puntos -> barra recta.
    //   3/4 puntos -> quiebre local de empalme.
    // Rechaza recorridos complejos, fuera de plano o con retrocesos que puedan
    // provocar el diálogo de Revit "No se puede resolver forma de armadura".
    private bool EsTrayectoriaSimpleShapeDrivenEmpalmeMYG(
        List<XYZ> puntos,
        XYZ normalPlanoPreferida)
    {
        if (puntos == null || puntos.Count < 2 || puntos.Count > 4)
            return false;

        List<XYZ> limpios =
            SimplificarPuntosColinealesLongitudinalMYG(
                LimpiarPuntosConsecutivos(puntos));

        if (limpios == null || limpios.Count < 2 || limpios.Count > 4)
            return false;

        XYZ normal = normalPlanoPreferida;
        if (normal == null || normal.GetLength() <= Tol)
        {
            if (limpios.Count == 2)
                return true;

            XYZ v1 = limpios[1] - limpios[0];
            XYZ v2 = limpios[2] - limpios[1];
            XYZ cruz = v1.CrossProduct(v2);
            if (cruz.GetLength() <= Tol)
                return true;
            normal = cruz.Normalize();
        }
        else
        {
            normal = normal.Normalize();
        }

        XYZ origen = limpios[0];
        double toleranciaPlano = UnitUtils.ConvertToInternalUnits(
            0.5,
            UnitTypeId.Millimeters);

        foreach (XYZ p in limpios)
        {
            if (p == null)
                return false;

            double distanciaPlano = Math.Abs(
                p.Subtract(origen).DotProduct(normal));

            if (distanciaPlano > toleranciaPlano)
                return false;
        }

        // Evita segmentos nulos y giros prácticamente de 180 grados.
        for (int i = 0; i < limpios.Count - 1; i++)
        {
            XYZ vi = limpios[i + 1] - limpios[i];
            if (vi.GetLength() <= Tol)
                return false;

            if (i > 0)
            {
                XYZ va = limpios[i] - limpios[i - 1];
                if (va.GetLength() > Tol)
                {
                    double dot = va.Normalize().DotProduct(vi.Normalize());
                    if (dot < -0.9999)
                        return false;
                }
            }
        }

        return true;
    }

    private int CrearRebarLongitudinalConNumeroFijo(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        List<XYZ> puntosBarra,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho,
        int cantidad,
        double longitudDistribucion,
        string tipoElementoLongitudinal = "",
        bool incluirPrimeraBarra = true,
        bool incluirUltimaBarra = true,
        bool permitirFreeForm = true)
    {
        if (doc == null ||
            host == null ||
            barType == null ||
            puntosBarra == null ||
            puntosBarra.Count < 2)
        {
            return 0;
        }

        List<XYZ> puntosBase =
            ConstruirPuntosGeometricosLongitudinalMYG(
                puntosBarra,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                direccionGancho);

        if (puntosBase == null || puntosBase.Count < 2)
            return 0;

        // V11.3: no todo recorrido con más de dos puntos requiere Free Form.
        // El quiebre local del empalme es una polilínea plana simple y Revit
        // puede resolverla como shape-driven, conservando la regla editable.
        // Solo los recorridos realmente complejos siguen usando Free Form.
        bool puedeShapeDriven =
            EsTrayectoriaSimpleShapeDrivenEmpalmeMYG(
                puntosBase,
                normal);

        bool requiereFreeForm = !puedeShapeDriven;

        Rebar rebar = null;
        int cantidadCreada = 0;

        if (puedeShapeDriven)
        {
            List<XYZ> normalesPrueba =
                ConstruirNormalesPlanoParaDistribucionMYG(
                    puntosBase,
                    normal);

            foreach (XYZ normalPrueba in normalesPrueba)
            {
                rebar = CrearRebarLongitudinalDesdePuntos(
                    doc,
                    host,
                    barType,
                    normalPrueba,
                    puntosBarra,
                    ganchoInicio,
                    longitudGanchoInicio,
                    ganchoFin,
                    longitudGanchoFin,
                    direccionGancho);

                if (rebar == null)
                    continue;

                AplicarParametrosInstanciaAceroLongitudinal(
                    doc,
                    rebar,
                    host,
                    tipoElementoLongitudinal);

                if (cantidad <= 1 || longitudDistribucion <= Tol)
                {
                    if (!incluirPrimeraBarra || !incluirUltimaBarra)
                    {
                        try { doc.Delete(rebar.Id); } catch { }
                        rebar = null;
                        continue;
                    }
                    return 1;
                }

                try
                {
                    // Asegura que la forma recta quede resuelta antes de aplicar
                    // Número fijo.
                    doc.Regenerate();
                    RebarShapeDrivenAccessor accessor =
                        rebar.GetShapeDrivenAccessor();

                    accessor.SetLayoutAsFixedNumber(
                        cantidad,
                        longitudDistribucion,
                        true,
                        incluirPrimeraBarra,
                        incluirUltimaBarra);

                    int visibles = cantidad;
                    if (!incluirPrimeraBarra) visibles--;
                    if (!incluirUltimaBarra) visibles--;
                    return Math.Max(0, visibles);
                }
                catch (Exception ex)
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "SetLayoutAsFixedNumber / ShapeDriven",
                        "Host=" + host.Id +
                        "; tipo=" + barType.Name +
                        "; cantidad=" + cantidad +
                        "; longitud distribución=" +
                        FormatearLongitudDiagnosticoMYG(longitudDistribucion) +
                        "; puntos base=" + puntosBase.Count +
                        "; normal=" + FormatearXYZDiagnosticoMYG(normalPrueba) + ".",
                        ex);

                    // La orientación de la normal puede ser determinante en
                    // secciones inclinadas. Se elimina este intento y se prueba
                    // la orientación opuesta antes de abandonar la regla nativa.
                    try
                    {
                        doc.Delete(rebar.Id);
                    }
                    catch
                    {
                    }

                    rebar = null;
                }
            }
        }

        // Los grupos creados desde la ventana deben conservar una regla
        // shape-driven editable. Si Revit no acepta el conjunto nativo, se
        // devuelve cero al llamador para que decida el respaldo adecuado; no se
        // transforma silenciosamente en Forma libre.
        if (!permitirFreeForm)
            return 0;

        int cantidadVisibleFreeForm = cantidad;
        double longitudVisibleFreeForm = longitudDistribucion;
        List<XYZ> puntosBaseVisibles = puntosBase;

        if (cantidad > 1 && longitudDistribucion > Tol &&
            (!incluirPrimeraBarra || !incluirUltimaBarra))
        {
            double paso = longitudDistribucion / (cantidad - 1);
            double desplazamientoInicio =
                incluirPrimeraBarra ? 0.0 : paso;
            double descuentoFin =
                incluirUltimaBarra ? 0.0 : paso;

            cantidadVisibleFreeForm = cantidad -
                (incluirPrimeraBarra ? 0 : 1) -
                (incluirUltimaBarra ? 0 : 1);
            longitudVisibleFreeForm = Math.Max(
                0.0,
                longitudDistribucion -
                desplazamientoInicio -
                descuentoFin);

            if (cantidadVisibleFreeForm <= 0)
                return 0;

            if (desplazamientoInicio > Tol)
            {
                XYZ vector = normal.Normalize().Multiply(
                    desplazamientoInicio);
                puntosBaseVisibles = puntosBase.Select(x =>
                    x.Add(vector)).ToList();
            }
        }

        rebar = CrearRebarLongitudinalFreeFormSetMYG(
            doc,
            host,
            barType,
            normal,
            puntosBaseVisibles,
            cantidadVisibleFreeForm,
            longitudVisibleFreeForm,
            out cantidadCreada);

        if (rebar == null)
            return 0;

        AplicarParametrosInstanciaAceroLongitudinal(
            doc,
            rebar,
            host,
            tipoElementoLongitudinal);

        return Math.Max(1, cantidadCreada);
    }

    // =========================================================
    // GEOMETRÍA LONGITUDINAL DEPURADA
    // =========================================================
    // El preview inserta puntos en las caras de cada sólido para conservar el
    // vacío. Si todos esos puntos pertenecen a una misma recta, se eliminan los
    // puntos intermedios y Revit recibe una sola línea continua de extremo a
    // extremo. Esto conserva la longitud del tramo vacío sin crear segmentos
    // colineales redundantes.
    private List<XYZ> ConstruirPuntosGeometricosLongitudinalMYG(
        List<XYZ> puntosBarra,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho)
    {
        List<XYZ> puntos =
            LimpiarPuntosConsecutivos(puntosBarra);

        if (puntos == null || puntos.Count < 2)
            return new List<XYZ>();

        puntos = SimplificarPuntosColinealesLongitudinalMYG(
            puntos);

        if (puntos.Count < 2)
            return puntos;

        XYZ primero = puntos[0];
        XYZ ultimo = puntos[puntos.Count - 1];

        if (ganchoInicio &&
            longitudGanchoInicio > Tol &&
            direccionGancho != null &&
            direccionGancho.GetLength() > Tol)
        {
            XYZ pGancho = primero.Add(
                direccionGancho.Normalize().Multiply(
                    longitudGanchoInicio));

            if (pGancho.DistanceTo(primero) > Tol)
                puntos.Insert(0, pGancho);
        }

        if (ganchoFin &&
            longitudGanchoFin > Tol &&
            direccionGancho != null &&
            direccionGancho.GetLength() > Tol)
        {
            XYZ pGancho = ultimo.Add(
                direccionGancho.Normalize().Multiply(
                    longitudGanchoFin));

            if (ultimo.DistanceTo(pGancho) > Tol)
                puntos.Add(pGancho);
        }

        return SimplificarPuntosColinealesLongitudinalMYG(
            LimpiarPuntosConsecutivos(puntos));
    }

    private List<XYZ> SimplificarPuntosColinealesLongitudinalMYG(
        List<XYZ> puntos)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (puntos == null || puntos.Count == 0)
            return resultado;

        double toleranciaDistancia =
            UnitUtils.ConvertToInternalUnits(
                0.10,
                UnitTypeId.Centimeters);

        foreach (XYZ punto in puntos)
        {
            if (punto == null)
                continue;

            if (resultado.Count == 0 ||
                resultado[resultado.Count - 1].DistanceTo(punto) > Tol)
            {
                resultado.Add(punto);
            }
        }

        bool cambio = true;
        int seguridad = 0;

        while (cambio &&
               resultado.Count > 2 &&
               seguridad < 10000)
        {
            cambio = false;
            seguridad++;

            for (int i = 1; i < resultado.Count - 1; i++)
            {
                XYZ a = resultado[i - 1];
                XYZ b = resultado[i];
                XYZ c = resultado[i + 1];

                XYZ ac = c - a;
                XYZ ab = b - a;

                double longitudAC = ac.GetLength();

                if (longitudAC <= Tol)
                    continue;

                XYZ direccionAC = ac.Normalize();
                double proyeccion = ab.DotProduct(direccionAC);

                if (proyeccion < -toleranciaDistancia ||
                    proyeccion > longitudAC + toleranciaDistancia)
                {
                    continue;
                }

                XYZ puntoProyectado =
                    a.Add(direccionAC.Multiply(proyeccion));

                double distancia =
                    b.DistanceTo(puntoProyectado);

                XYZ dirAB = b - a;
                XYZ dirBC = c - b;

                bool mismoSentido =
                    dirAB.GetLength() <= Tol ||
                    dirBC.GetLength() <= Tol ||
                    dirAB.Normalize().DotProduct(
                        dirBC.Normalize()) > 0.9999;

                if (distancia <= toleranciaDistancia &&
                    mismoSentido)
                {
                    resultado.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        return resultado;
    }

    private IList<Curve> ConstruirCurvasDesdePuntosLongitudinalMYG(
        List<XYZ> puntos)
    {
        IList<Curve> curvas = new List<Curve>();

        if (puntos == null || puntos.Count < 2)
            return curvas;

        for (int i = 0; i < puntos.Count - 1; i++)
        {
            XYZ a = puntos[i];
            XYZ b = puntos[i + 1];

            if (a == null || b == null)
                continue;

            if (a.DistanceTo(b) <= Tol)
                continue;

            curvas.Add(Line.CreateBound(a, b));
        }

        return curvas;
    }

    // =========================================================
    // CONJUNTO FREE FORM PARA RECORRIDOS CON VACÍOS / QUIEBRES
    // =========================================================
    // Rebar.CreateFreeForm recibe una cadena completa por cada barra del set.
    // No intenta resolver una RebarShape, por lo que evita el cuadro de error
    // que obliga a pulsar "Suprimir armadura".
    private Rebar CrearRebarLongitudinalFreeFormSetMYG(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normalDistribucion,
        List<XYZ> puntosBase,
        int cantidad,
        double longitudDistribucion,
        out int cantidadCreada)
    {
        cantidadCreada = 0;

        if (doc == null ||
            host == null ||
            barType == null ||
            puntosBase == null ||
            puntosBase.Count < 2)
        {
            return null;
        }

        int numeroBarras = Math.Max(1, cantidad);

        XYZ direccionDistribucion = normalDistribucion;

        if (direccionDistribucion == null ||
            direccionDistribucion.GetLength() <= Tol)
        {
            direccionDistribucion = XYZ.BasisY;
        }

        direccionDistribucion =
            direccionDistribucion.Normalize();

        double recorridoDistribucion =
            numeroBarras > 1
                ? Math.Max(0.0, longitudDistribucion)
                : 0.0;

        IList<IList<Curve>> curvasPorBarra =
            new List<IList<Curve>>();

        for (int i = 0; i < numeroBarras; i++)
        {
            double distancia =
                numeroBarras <= 1
                    ? 0.0
                    : recorridoDistribucion *
                      ((double)i / (double)(numeroBarras - 1));

            XYZ desplazamiento =
                direccionDistribucion.Multiply(distancia);

            List<XYZ> puntosTrasladados =
                new List<XYZ>();

            foreach (XYZ punto in puntosBase)
            {
                if (punto != null)
                    puntosTrasladados.Add(
                        punto.Add(desplazamiento));
            }

            puntosTrasladados =
                SimplificarPuntosColinealesLongitudinalMYG(
                    LimpiarPuntosConsecutivos(
                        puntosTrasladados));

            IList<Curve> curvasBarra =
                ConstruirCurvasDesdePuntosLongitudinalMYG(
                    puntosTrasladados);

            if (curvasBarra == null || curvasBarra.Count == 0)
                return null;

            curvasPorBarra.Add(curvasBarra);
        }

        try
        {
            object resultado = Rebar.CreateFreeForm(
                doc,
                barType,
                host,
                curvasPorBarra,
                RebarStyle.Standard);

            if (resultado == null)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "CrearRebarLongitudinalFreeFormSetMYG",
                    "Rebar.CreateFreeForm devolvió null. Host=" + host.Id +
                    "; cantidad=" + numeroBarras +
                    "; puntos base=" + puntosBase.Count + ".");
                return null;
            }

            System.Reflection.PropertyInfo propiedadRebar =
                resultado.GetType().GetProperty(
                    "Rebar",
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

            if (propiedadRebar == null)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "CrearRebarLongitudinalFreeFormSetMYG",
                    "El resultado de CreateFreeForm no contiene la propiedad Rebar.");
                return null;
            }

            Rebar rebar =
                propiedadRebar.GetValue(
                    resultado,
                    null) as Rebar;

            if (rebar == null)
            {
                MarcarUltimoErrorLongitudinalMYG(
                    "CrearRebarLongitudinalFreeFormSetMYG",
                    "La propiedad Rebar del resultado devolvió null.");
                return null;
            }

            cantidadCreada = numeroBarras;
            return rebar;
        }
        catch (Exception ex)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "CrearRebarLongitudinalFreeFormSetMYG",
                "Host=" + host.Id +
                "; tipo=" + barType.Name +
                "; cantidad=" + numeroBarras +
                "; longitud distribución=" +
                FormatearLongitudDiagnosticoMYG(recorridoDistribucion) +
                "; puntos base=" + puntosBase.Count + ".",
                ex);
            return null;
        }
    }


    private Rebar CrearRebarLongitudinalDesdePuntos(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        List<XYZ> puntosBarra,
        bool ganchoInicio,
        double longitudGanchoInicio,
        bool ganchoFin,
        double longitudGanchoFin,
        XYZ direccionGancho)
    {
        if (doc == null || host == null || barType == null)
            return null;

        List<XYZ> puntosGeometricos =
            ConstruirPuntosGeometricosLongitudinalMYG(
                puntosBarra,
                ganchoInicio,
                longitudGanchoInicio,
                ganchoFin,
                longitudGanchoFin,
                direccionGancho);

        if (puntosGeometricos == null ||
            puntosGeometricos.Count < 2)
        {
            return null;
        }

        IList<Curve> curvas =
            ConstruirCurvasDesdePuntosLongitudinalMYG(
                puntosGeometricos);

        if (curvas == null || curvas.Count == 0)
            return null;

        List<XYZ> normales =
            ConstruirNormalesCandidatasLongitudinalMYG(
                curvas,
                normal);

        foreach (XYZ normalCandidata in normales)
        {
            // Para un recorrido recto se busca primero una forma ya existente.
            // Solo si no existe se permite crear una nueva forma recta.
            Rebar creado = IntentarCrearRebarLongitudinalMYG(
                doc,
                host,
                barType,
                normalCandidata,
                curvas,
                true,
                false);

            if (creado != null)
                return creado;

            creado = IntentarCrearRebarLongitudinalMYG(
                doc,
                host,
                barType,
                normalCandidata,
                curvas,
                true,
                true);

            if (creado != null)
                return creado;
        }

        return null;
    }


    private List<XYZ> ConstruirNormalesCandidatasLongitudinalMYG(
        IList<Curve> curvas,
        XYZ normalPreferida)
    {
        List<XYZ> resultado = new List<XYZ>();

        XYZ direccionPrincipal = null;

        if (curvas != null)
        {
            foreach (Curve curva in curvas)
            {
                if (curva == null)
                    continue;

                XYZ vector = curva.GetEndPoint(1) - curva.GetEndPoint(0);

                if (vector.GetLength() > Tol)
                {
                    direccionPrincipal = vector.Normalize();
                    break;
                }
            }
        }

        if (normalPreferida != null &&
            normalPreferida.GetLength() > Tol)
        {
            XYZ n = normalPreferida.Normalize();

            if (direccionPrincipal != null)
            {
                n = n.Subtract(
                    direccionPrincipal.Multiply(
                        n.DotProduct(direccionPrincipal)));
            }

            AgregarNormalCandidataLongitudinalMYG(resultado, n);
            AgregarNormalCandidataLongitudinalMYG(
                resultado,
                n != null ? n.Multiply(-1.0) : null);
        }

        XYZ normalPlano = null;

        if (curvas != null)
        {
            for (int i = 0; i < curvas.Count && normalPlano == null; i++)
            {
                Curve c1 = curvas[i];

                if (c1 == null)
                    continue;

                XYZ v1 = c1.GetEndPoint(1) - c1.GetEndPoint(0);

                if (v1.GetLength() <= Tol)
                    continue;

                v1 = v1.Normalize();

                for (int j = i + 1; j < curvas.Count; j++)
                {
                    Curve c2 = curvas[j];

                    if (c2 == null)
                        continue;

                    XYZ v2 = c2.GetEndPoint(1) - c2.GetEndPoint(0);

                    if (v2.GetLength() <= Tol)
                        continue;

                    v2 = v2.Normalize();

                    XYZ cruz = v1.CrossProduct(v2);

                    if (cruz.GetLength() > 1e-5)
                    {
                        normalPlano = cruz.Normalize();
                        break;
                    }
                }
            }
        }

        AgregarNormalCandidataLongitudinalMYG(
            resultado,
            normalPlano);

        AgregarNormalCandidataLongitudinalMYG(
            resultado,
            normalPlano != null
                ? normalPlano.Multiply(-1.0)
                : null);

        if (resultado.Count == 0 && direccionPrincipal != null)
        {
            XYZ n = direccionPrincipal.CrossProduct(XYZ.BasisZ);

            if (n.GetLength() <= Tol)
                n = direccionPrincipal.CrossProduct(XYZ.BasisX);

            AgregarNormalCandidataLongitudinalMYG(resultado, n);
            AgregarNormalCandidataLongitudinalMYG(
                resultado,
                n != null ? n.Multiply(-1.0) : null);
        }

        return resultado;
    }

    private void AgregarNormalCandidataLongitudinalMYG(
        List<XYZ> lista,
        XYZ normal)
    {
        if (lista == null || normal == null)
            return;

        if (normal.GetLength() <= Tol)
            return;

        XYZ n = normal.Normalize();

        foreach (XYZ existente in lista)
        {
            if (existente == null)
                continue;

            if (Math.Abs(existente.DotProduct(n)) > 0.999999)
                return;
        }

        lista.Add(n);
    }

    private Rebar IntentarCrearRebarLongitudinalMYG(
        Document doc,
        Element host,
        RebarBarType barType,
        XYZ normal,
        IList<Curve> curvas,
        bool usarFormaExistente,
        bool crearNuevaForma)
    {
        if (doc == null ||
            host == null ||
            barType == null ||
            normal == null ||
            normal.GetLength() <= Tol ||
            curvas == null ||
            curvas.Count == 0)
        {
            return null;
        }

        try
        {
            using (BarTerminationsData terminaciones =
                new BarTerminationsData(doc))
            {
                terminaciones.HookTypeIdAtStart =
                    ElementId.InvalidElementId;

                terminaciones.HookTypeIdAtEnd =
                    ElementId.InvalidElementId;

                terminaciones.CrankTypeIdAtStart =
                    ElementId.InvalidElementId;

                terminaciones.CrankTypeIdAtEnd =
                    ElementId.InvalidElementId;

                terminaciones.EndTreatmentTypeIdAtStart =
                    ElementId.InvalidElementId;

                terminaciones.EndTreatmentTypeIdAtEnd =
                    ElementId.InvalidElementId;

                terminaciones.TerminationOrientationAtStart =
                    RebarTerminationOrientation.Left;

                terminaciones.TerminationOrientationAtEnd =
                    RebarTerminationOrientation.Right;

                Rebar creado = Rebar.CreateFromCurves(
                    doc,
                    RebarStyle.Standard,
                    barType,
                    host,
                    normal.Normalize(),
                    curvas,
                    terminaciones,
                    usarFormaExistente,
                    crearNuevaForma);

                if (creado == null)
                {
                    MarcarUltimoErrorLongitudinalMYG(
                        "Rebar.CreateFromCurves",
                        "Revit devolvió null sin excepción. Host=" + host.Id +
                        "; tipo=" + barType.Name +
                        "; curvas=" + curvas.Count +
                        "; usarFormaExistente=" + usarFormaExistente +
                        "; crearNuevaForma=" + crearNuevaForma +
                        "; normal=" + FormatearXYZDiagnosticoMYG(normal) + ".");
                }

                return creado;
            }
        }
        catch (Exception ex)
        {
            MarcarUltimoErrorLongitudinalMYG(
                "Rebar.CreateFromCurves",
                "Host=" + host.Id +
                "; tipo=" + barType.Name +
                "; curvas=" + curvas.Count +
                "; usarFormaExistente=" + usarFormaExistente +
                "; crearNuevaForma=" + crearNuevaForma +
                "; normal=" + FormatearXYZDiagnosticoMYG(normal) + ".",
                ex);
            return null;
        }
    }



    // =========================================================
    // INTERVALO ÚTIL DEL PAQUETE LONGITUDINAL SEGÚN EL SÓLIDO REAL
    // =========================================================
    private class PuntoControlPaqueteLongitudinalMYG
    {
        public double Y;
        public double Z;

        public PuntoControlPaqueteLongitudinalMYG(double y, double z)
        {
            Y = y;
            Z = z;
        }
    }

    private void CalcularIntervaloUtilPaqueteLongitudinalMYG(
        DatosSerieVigas datos,
        List<ConfiguracionCapaLongitudinal> capasSuperiores,
        List<ConfiguracionCapaLongitudinal> capasInferiores,
        bool crearAceroCentral,
        RebarBarType tipoCentral,
        double recubrimiento,
        out double inicioUtil,
        out double finUtil)
    {
        inicioUtil = 0.0;
        finUtil = datos != null ? datos.LongitudTotal : 0.0;

        if (datos == null || datos.LongitudTotal <= Tol)
            return;

        List<PuntoControlPaqueteLongitudinalMYG> controles =
            ConstruirPuntosControlPaqueteLongitudinalMYG(
                datos,
                capasSuperiores,
                capasInferiores,
                crearAceroCentral,
                tipoCentral,
                recubrimiento);

        if (controles == null || controles.Count == 0)
            return;

        bool existenSolidos = datos.Vigas != null &&
            datos.Vigas.Any(v => v != null && v.SolidosGlobales != null && v.SolidosGlobales.Count > 0);

        if (!existenSolidos)
            return;

        double longitud = datos.LongitudTotal;
        double pasoMin = UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters);
        double pasoMax = UnitUtils.ConvertToInternalUnits(10.0, UnitTypeId.Centimeters);
        double paso = Math.Max(pasoMin, Math.Min(pasoMax, longitud / 120.0));

        double primerValido = double.NaN;
        double anterior = 0.0;

        for (double x = 0.0; x <= longitud + Tol; x += paso)
        {
            double estacion = Math.Min(longitud, x);

            if (CabePaqueteLongitudinalEnEstacionMYG(datos, estacion, controles))
            {
                primerValido = RefinarLimiteUtilPaqueteMYG(
                    datos,
                    controles,
                    Math.Max(0.0, anterior),
                    estacion,
                    true);
                break;
            }

            anterior = estacion;
        }

        if (double.IsNaN(primerValido))
            return;

        double ultimoValido = double.NaN;
        anterior = longitud;

        for (double x = longitud; x >= -Tol; x -= paso)
        {
            double estacion = Math.Max(0.0, x);

            if (CabePaqueteLongitudinalEnEstacionMYG(datos, estacion, controles))
            {
                ultimoValido = RefinarLimiteUtilPaqueteMYG(
                    datos,
                    controles,
                    estacion,
                    Math.Min(longitud, anterior),
                    false);
                break;
            }

            anterior = estacion;
        }

        if (double.IsNaN(ultimoValido) || ultimoValido <= primerValido + Tol)
            return;

        inicioUtil = Math.Max(0.0, primerValido);
        finUtil = Math.Min(longitud, ultimoValido);
    }

    private double RefinarLimiteUtilPaqueteMYG(
        DatosSerieVigas datos,
        List<PuntoControlPaqueteLongitudinalMYG> controles,
        double a,
        double b,
        bool buscandoInicio)
    {
        a = Math.Max(0.0, Math.Min(datos.LongitudTotal, a));
        b = Math.Max(0.0, Math.Min(datos.LongitudTotal, b));

        if (b < a)
        {
            double t = a;
            a = b;
            b = t;
        }

        for (int i = 0; i < 14; i++)
        {
            double m = (a + b) / 2.0;
            bool cabe = CabePaqueteLongitudinalEnEstacionMYG(datos, m, controles);

            if (buscandoInicio)
            {
                if (cabe) b = m;
                else a = m;
            }
            else
            {
                if (cabe) a = m;
                else b = m;
            }
        }

        return buscandoInicio ? b : a;
    }

    private List<PuntoControlPaqueteLongitudinalMYG> ConstruirPuntosControlPaqueteLongitudinalMYG(
        DatosSerieVigas datos,
        List<ConfiguracionCapaLongitudinal> capasSuperiores,
        List<ConfiguracionCapaLongitudinal> capasInferiores,
        bool crearAceroCentral,
        RebarBarType tipoCentral,
        double recubrimiento)
    {
        List<PuntoControlPaqueteLongitudinalMYG> resultado =
            new List<PuntoControlPaqueteLongitudinalMYG>();

        if (datos == null)
            return resultado;

        List<PuntoSeccionYZ> poligono = ObtenerPoligonoSeccionRealYZ(datos);

        if (poligono == null || poligono.Count < 3)
            return resultado;

        double yMin = poligono.Min(p => p.Y);
        double yMax = poligono.Max(p => p.Y);

        if (yMax <= yMin + Tol)
            return resultado;

        double diametroEstribo = ObtenerDiametroEstriboReferenciaDesdeForm();

        Action<List<ConfiguracionCapaLongitudinal>, bool> agregarCapas = (capas, superior) =>
        {
            if (capas == null)
                return;

            foreach (ConfiguracionCapaLongitudinal capa in capas)
            {
                if (capa == null || capa.TipoBarra == null || capa.Cantidad <= 0)
                    continue;

                double radio = Math.Max(0.0, capa.Diametro) / 2.0;
                double offsetLateral = recubrimiento + diametroEstribo + radio;
                double offsetVertical = capa.OffsetCentroDesdeCara > Tol
                    ? capa.OffsetCentroDesdeCara
                    : offsetLateral;

                double yi = yMin + offsetLateral;
                double yf = yMax - offsetLateral;

                if (yf < yi - Tol)
                    continue;

                int cantidad = Math.Max(1, capa.Cantidad);

                for (int i = 0; i < cantidad; i++)
                {
                    double y = cantidad == 1
                        ? (yi + yf) / 2.0
                        : yi + (yf - yi) * ((double)i / (double)(cantidad - 1));

                    double zInf;
                    double zSup;

                    if (!ObtenerZSuperiorInferiorEnY(poligono, y, out zInf, out zSup))
                        continue;

                    double z = superior
                        ? zSup - offsetVertical
                        : zInf + offsetVertical;

                    if (z <= zInf + Tol || z >= zSup - Tol)
                        continue;

                    resultado.Add(new PuntoControlPaqueteLongitudinalMYG(y, z));
                }
            }
        };

        agregarCapas(capasSuperiores, true);
        agregarCapas(capasInferiores, false);

        if (crearAceroCentral && tipoCentral != null)
        {
            double diametroCentral = ObtenerDiametroBarra(tipoCentral);
            double offset = recubrimiento + diametroEstribo + diametroCentral / 2.0;
            double yi = yMin + offset;
            double yf = yMax - offset;

            if (yf >= yi - Tol)
            {
                List<double> ys = new List<double>();

                if (Math.Abs(yf - yi) <= Tol)
                    ys.Add((yi + yf) / 2.0);
                else
                {
                    ys.Add(yi);
                    ys.Add(yf);
                }

                foreach (double y in ys)
                {
                    double zInf;
                    double zSup;

                    if (!ObtenerZSuperiorInferiorEnY(poligono, y, out zInf, out zSup))
                        continue;

                    resultado.Add(new PuntoControlPaqueteLongitudinalMYG(
                        y,
                        (zInf + zSup) / 2.0));
                }
            }
        }

        return resultado;
    }

    private bool CabePaqueteLongitudinalEnEstacionMYG(
        DatosSerieVigas datos,
        double xSerie,
        List<PuntoControlPaqueteLongitudinalMYG> controles)
    {
        if (datos == null || controles == null || controles.Count == 0)
            return false;

        TramoRecorridoSerie tramo = ObtenerTramoParaEstacion(datos, xSerie);

        if (tramo == null || tramo.Viga == null)
            return false;

        DatosViga viga = tramo.Viga;

        if (viga.SolidosGlobales == null || viga.SolidosGlobales.Count == 0)
            return false;

        XYZ direccionSonda = viga.XAxis != null && viga.XAxis.GetLength() > Tol
            ? viga.XAxis.Normalize()
            : datos.XAxis.Normalize();

        foreach (PuntoControlPaqueteLongitudinalMYG control in controles)
        {
            if (control == null)
                continue;

            // Se usa la posición de la sección completa, no una posición adaptada
            // a la mordida. Por eso el paquete comienza recién donde todas las
            // barras caben con su recubrimiento normal.
            XYZ punto = PuntoLocal(datos, xSerie, control.Y, control.Z);

            if (punto == null ||
                !PuntoDentroDeSolidosMYG(viga.SolidosGlobales, punto, direccionSonda))
            {
                return false;
            }
        }

        return true;
    }

    private bool PuntoDentroDeSolidosMYG(
        List<Solid> solidos,
        XYZ punto,
        XYZ direccion)
    {
        if (solidos == null || solidos.Count == 0 || punto == null)
            return false;

        if (direccion == null || direccion.GetLength() <= Tol)
            direccion = XYZ.BasisX;

        direccion = direccion.Normalize();

        double semilongitud = UnitUtils.ConvertToInternalUnits(
            0.20,
            UnitTypeId.Centimeters);

        double tolerancia = UnitUtils.ConvertToInternalUnits(
            0.05,
            UnitTypeId.Centimeters);

        Line sonda = Line.CreateBound(
            punto.Subtract(direccion.Multiply(semilongitud)),
            punto.Add(direccion.Multiply(semilongitud)));

        foreach (Solid solid in solidos)
        {
            if (solid == null)
                continue;

            try
            {
                using (SolidCurveIntersectionOptions opciones =
                    new SolidCurveIntersectionOptions())
                {
                    opciones.ResultType = SolidCurveIntersectionMode.CurveSegmentsInside;

                    using (SolidCurveIntersection interseccion =
                        solid.IntersectWithCurve(sonda, opciones))
                    {
                        for (int i = 0; i < interseccion.SegmentCount; i++)
                        {
                            Curve segmento = interseccion.GetCurveSegment(i);

                            if (segmento == null || segmento.Length <= Tol)
                                continue;

                            XYZ a = segmento.GetEndPoint(0);
                            XYZ b = segmento.GetEndPoint(1);
                            double error = Math.Abs(
                                punto.DistanceTo(a) + punto.DistanceTo(b) - segmento.Length);

                            if (error <= tolerancia)
                                return true;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        return false;
    }

    private List<Solid> ObtenerSolidosElementoParaValidacionMYG(Element elemento)
    {
        List<Solid> resultado = new List<Solid>();

        if (elemento == null)
            return resultado;

        Options opciones = new Options();
        opciones.DetailLevel = ViewDetailLevel.Fine;
        opciones.IncludeNonVisibleObjects = false;
        opciones.ComputeReferences = false;

        GeometryElement geometria = null;

        try
        {
            geometria = elemento.get_Geometry(opciones);
        }
        catch
        {
            geometria = null;
        }

        RecolectarSolidosParaValidacionMYG(
            geometria,
            Transform.Identity,
            resultado);

        return resultado;
    }

    private void RecolectarSolidosParaValidacionMYG(
        GeometryElement geometria,
        Transform transformacion,
        List<Solid> destino)
    {
        if (geometria == null || destino == null)
            return;

        foreach (GeometryObject objeto in geometria)
        {
            if (objeto == null)
                continue;

            Solid solid = objeto as Solid;

            if (solid != null)
            {
                try
                {
                    if (solid.Volume <= Tol || solid.Faces == null || solid.Faces.Size == 0)
                        continue;

                    Solid copia = solid;

                    if (transformacion != null && !transformacion.IsIdentity)
                        copia = SolidUtils.CreateTransformed(solid, transformacion);

                    if (copia != null && copia.Volume > Tol)
                        destino.Add(copia);
                }
                catch
                {
                }

                continue;
            }

            GeometryInstance instancia = objeto as GeometryInstance;

            if (instancia == null)
                continue;

            bool instanciaProcesada = false;

            try
            {
                GeometryElement geometriaInstancia = instancia.GetInstanceGeometry();

                if (geometriaInstancia != null)
                {
                    RecolectarSolidosParaValidacionMYG(
                        geometriaInstancia,
                        Transform.Identity,
                        destino);

                    instanciaProcesada = true;
                }
            }
            catch
            {
                instanciaProcesada = false;
            }

            if (instanciaProcesada)
                continue;

            try
            {
                GeometryElement geometriaSimbolo = instancia.GetSymbolGeometry();

                if (geometriaSimbolo != null)
                {
                    Transform t = transformacion == null
                        ? instancia.Transform
                        : transformacion.Multiply(instancia.Transform);

                    RecolectarSolidosParaValidacionMYG(
                        geometriaSimbolo,
                        t,
                        destino);
                }
            }
            catch
            {
            }
        }
    }

    // =====================================
    // CONSTRUIR SERIE USANDO EL SÓLIDO REAL
    // =====================================
    private DatosSerieVigas ObtenerDatosSerieVigas(
        Document doc,
        List<Element> vigas)
    {
        if (doc == null)
            return null;

        if (vigas == null || vigas.Count == 0)
            return null;

        List<DatosViga> datosVigas = new List<DatosViga>();

        foreach (Element viga in vigas)
        {
            DatosViga datos = ObtenerDatosViga(viga);

            if (datos != null)
                datosVigas.Add(datos);
        }

        if (datosVigas.Count == 0)
            return null;

        DatosViga baseDatos = datosVigas[0];

        XYZ origen = baseDatos.P0;
        XYZ eje = baseDatos.XAxis;
        XYZ yAxis = baseDatos.YAxis;
        XYZ zAxis = baseDatos.ZAxis;

        if (eje == null || eje.GetLength() <= Tol)
            return null;

        eje = eje.Normalize();

        datosVigas = datosVigas
            .OrderBy(d =>
            {
                XYZ centro = (d.P0 + d.P1).Multiply(0.5);
                return (centro - origen).DotProduct(eje);
            })
            .ToList();

        double minX = double.MaxValue;
        double maxX = double.MinValue;

        double minY = double.MaxValue;
        double maxY = double.MinValue;

        double minZ = double.MaxValue;
        double maxZ = double.MinValue;

        foreach (DatosViga d in datosVigas)
        {
            List<XYZ> puntos = ObtenerPuntosSolidoElemento(d.Elemento);

            if (puntos == null || puntos.Count == 0)
                puntos = ObtenerPuntosBoundingBoxElemento(d.Elemento);

            foreach (XYZ p in puntos)
            {
                double px = (p - origen).DotProduct(eje);
                double py = (p - origen).DotProduct(yAxis);
                double pz = (p - origen).DotProduct(zAxis);

                if (px < minX) minX = px;
                if (px > maxX) maxX = px;

                if (py < minY) minY = py;
                if (py > maxY) maxY = py;

                if (pz < minZ) minZ = pz;
                if (pz > maxZ) maxZ = pz;
            }
        }

        if (maxX <= minX)
            return null;

        if (maxY <= minY)
            return null;

        if (maxZ <= minZ)
            return null;

        Element host = datosVigas
            .Select(x => x.Elemento)
            .FirstOrDefault(e => e != null && RebarHostData.GetRebarHostData(e) != null);

        if (host == null)
            return null;

        // SOLO SE USA LA GEOMETRÍA DE LAS VIGAS SELECCIONADAS.
        // No se consultan columnas, zapatas, muros, vigas transversales
        // ni ninguna otra categoría del modelo.
        List<IntervaloColumnaSerie> columnas =
            new List<IntervaloColumnaSerie>();

        double inicioLibre = minX;
        double finLibre = maxX;

        List<TramoRecorridoSerie> tramosRecorrido = ConstruirTramosRecorridoSerie(
            datosVigas,
            origen,
            eje,
            inicioLibre,
            finLibre);

        // La estación acumulada de cada tramo ya incluye la separación física
        // entre ElementId distintos. Por eso la longitud de la serie se obtiene
        // del último XFinSerie y no de la suma exclusiva de los sólidos.
        // XFinSerie ya contiene sólidos + vacíos físicos.
        double longitudTotal =
            tramosRecorrido != null &&
            tramosRecorrido.Count > 0
                ? tramosRecorrido.Max(
                    tr => Math.Max(
                        tr.XInicioSerie,
                        tr.XFinSerie))
                : finLibre - inicioLibre;

        if (longitudTotal <= Tol)
            return null;

        double centroY = (minY + maxY) / 2.0;
        double centroZ = (minZ + maxZ) / 2.0;

        double ancho = maxY - minY;
        double alto = maxZ - minZ;

        if (ancho <= Tol || alto <= Tol)
            return null;

        XYZ pInicio = origen
            .Add(eje.Multiply(inicioLibre))
            .Add(yAxis.Multiply(centroY))
            .Add(zAxis.Multiply(centroZ));

        XYZ pFin = origen
            .Add(eje.Multiply(finLibre))
            .Add(yAxis.Multiply(centroY))
            .Add(zAxis.Multiply(centroZ));

        DatosSerieVigas datosSerie = new DatosSerieVigas();

        datosSerie.Host = host;
        datosSerie.PInicio = pInicio;
        datosSerie.PFin = pFin;

        datosSerie.XAxis = eje;
        datosSerie.YAxis = yAxis;
        datosSerie.ZAxis = zAxis;

        datosSerie.LongitudTotal = longitudTotal;
        datosSerie.Ancho = ancho;
        datosSerie.Alto = alto;
        datosSerie.CentroY = centroY;
        datosSerie.CentroZ = centroZ;

        // Desde este punto estos valores trabajan en coordenadas acumuladas
        // de la serie, no en coordenadas proyectadas globales. Así los empalmes,
        // la longitud comercial y los desarrollos usan el mismo eje que incluye
        // los vacíos físicos entre vigas seleccionadas.
        datosSerie.SolidoMinGlobal = 0.0;
        datosSerie.SolidoMaxGlobal = longitudTotal;
        datosSerie.LuzLibreInicioGlobal = 0.0;
        datosSerie.LuzLibreFinGlobal = longitudTotal;

        // NUEVO: guardar tramos reales para proyectar quiebres de acero
        // en vigas inclinadas con dos o más tramos.
        datosSerie.OrigenGlobal = origen;
        datosSerie.Vigas = datosVigas;
        datosSerie.TramosRecorrido = tramosRecorrido;
        datosSerie.Columnas = columnas;
        datosSerie.InicioUtilArmaduraSerie = 0.0;
        datosSerie.FinUtilArmaduraSerie = longitudTotal;

        return datosSerie;
    }

    private class IntervaloSolidoRecorridoMYG
    {
        public DatosViga Viga;
        public double EstacionInicioViga;
        public double EstacionFinViga;
        public XYZ PuntoInicio;
        public XYZ PuntoFin;
        public double ProyeccionInicioGlobal;
        public double ProyeccionFinGlobal;
    }

    private List<TramoRecorridoSerie> ConstruirTramosRecorridoSerie(
        List<DatosViga> datosVigas,
        XYZ origen,
        XYZ ejeGlobal,
        double inicioLibreGlobal,
        double finLibreGlobal)
    {
        List<TramoRecorridoSerie> resultado =
            new List<TramoRecorridoSerie>();

        if (datosVigas == null || datosVigas.Count == 0)
            return resultado;

        if (origen == null ||
            ejeGlobal == null ||
            ejeGlobal.GetLength() <= Tol)
        {
            return resultado;
        }

        ejeGlobal = ejeGlobal.Normalize();

        List<IntervaloSolidoRecorridoMYG> partes =
            new List<IntervaloSolidoRecorridoMYG>();

        foreach (DatosViga viga in datosVigas)
        {
            if (viga == null ||
                viga.P0 == null ||
                viga.XAxis == null ||
                viga.XAxis.GetLength() <= Tol)
            {
                continue;
            }

            List<IntervaloColumnaSerie> intervalosSolido =
                ObtenerIntervalosSolidosRealesVigaMYG(viga);

            foreach (IntervaloColumnaSerie intervalo
                in intervalosSolido)
            {
                if (intervalo == null)
                    continue;

                double estacion0 = intervalo.Min;
                double estacion1 = intervalo.Max;

                if (estacion1 <= estacion0 + Tol)
                    continue;

                XYZ punto0 =
                    ObtenerPuntoEjeVigaEnEstacionMYG(
                        viga,
                        estacion0);

                XYZ punto1 =
                    ObtenerPuntoEjeVigaEnEstacionMYG(
                        viga,
                        estacion1);

                if (punto0 == null || punto1 == null)
                    continue;

                double proy0 =
                    (punto0 - origen).DotProduct(ejeGlobal);

                double proy1 =
                    (punto1 - origen).DotProduct(ejeGlobal);

                // Se orienta cada parte según el orden general de la serie.
                if (proy1 < proy0)
                {
                    double estacionTemporal = estacion0;
                    estacion0 = estacion1;
                    estacion1 = estacionTemporal;

                    XYZ puntoTemporal = punto0;
                    punto0 = punto1;
                    punto1 = puntoTemporal;

                    double proyTemporal = proy0;
                    proy0 = proy1;
                    proy1 = proyTemporal;
                }

                partes.Add(
                    new IntervaloSolidoRecorridoMYG()
                    {
                        Viga = viga,
                        EstacionInicioViga = estacion0,
                        EstacionFinViga = estacion1,
                        PuntoInicio = punto0,
                        PuntoFin = punto1,
                        ProyeccionInicioGlobal = proy0,
                        ProyeccionFinGlobal = proy1
                    });
            }
        }

        partes = partes
            .Where(p =>
                p != null &&
                p.Viga != null &&
                p.PuntoInicio != null &&
                p.PuntoFin != null)
            .OrderBy(p => p.ProyeccionInicioGlobal)
            .ThenBy(p => p.ProyeccionFinGlobal)
            .ToList();

        if (partes.Count == 0)
            return resultado;

        double cursorSerie = 0.0;
        XYZ puntoFinAnterior = null;

        double toleranciaUnion =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        foreach (IntervaloSolidoRecorridoMYG parte in partes)
        {
            double longitudParte =
                parte.PuntoInicio.DistanceTo(
                    parte.PuntoFin);

            if (longitudParte <= Tol)
                continue;

            if (puntoFinAnterior != null)
            {
                double separacionFisica =
                    puntoFinAnterior.DistanceTo(
                        parte.PuntoInicio);

                if (separacionFisica > toleranciaUnion)
                {
                    // El vacío se suma a la estación acumulada.
                    // No se crea un tramo de concreto en esta zona:
                    // PuntoLocal interpolará una línea continua entre
                    // ambas caras cuando una barra atraviese el vacío.
                    cursorSerie += separacionFisica;
                }
            }

            double xInicioSerie = cursorSerie;
            double xFinSerie = xInicioSerie + longitudParte;

            resultado.Add(
                new TramoRecorridoSerie(
                    parte.Viga,
                    xInicioSerie,
                    xFinSerie,
                    parte.EstacionInicioViga,
                    parte.EstacionFinViga));

            cursorSerie = xFinSerie;
            puntoFinAnterior = parte.PuntoFin;
        }

        return resultado;
    }

    private List<IntervaloColumnaSerie>
        ObtenerIntervalosSolidosRealesVigaMYG(
            DatosViga viga)
    {
        List<IntervaloColumnaSerie> intervalos =
            new List<IntervaloColumnaSerie>();

        if (viga == null ||
            viga.P0 == null ||
            viga.XAxis == null ||
            viga.XAxis.GetLength() <= Tol)
        {
            return intervalos;
        }

        XYZ eje = viga.XAxis.Normalize();

        if (viga.SolidosGlobales != null)
        {
            foreach (Solid solido in viga.SolidosGlobales)
            {
                if (solido == null ||
                    solido.Volume <= Tol ||
                    solido.Edges == null ||
                    solido.Edges.Size == 0)
                {
                    continue;
                }

                double minimo = double.MaxValue;
                double maximo = double.MinValue;

                foreach (Edge arista in solido.Edges)
                {
                    if (arista == null)
                        continue;

                    Curve curva = null;

                    try
                    {
                        curva = arista.AsCurve();
                    }
                    catch
                    {
                        curva = null;
                    }

                    if (curva == null)
                        continue;

                    for (int extremo = 0; extremo <= 1; extremo++)
                    {
                        XYZ punto = null;

                        try
                        {
                            punto = curva.GetEndPoint(extremo);
                        }
                        catch
                        {
                            punto = null;
                        }

                        if (punto == null)
                            continue;

                        double estacion =
                            (punto - viga.P0).DotProduct(eje);

                        minimo = Math.Min(minimo, estacion);
                        maximo = Math.Max(maximo, estacion);
                    }
                }

                if (minimo != double.MaxValue &&
                    maximo != double.MinValue &&
                    maximo > minimo + Tol)
                {
                    intervalos.Add(
                        new IntervaloColumnaSerie(
                            minimo,
                            maximo));
                }
            }
        }

        if (intervalos.Count == 0 &&
            viga.SolidoMax > viga.SolidoMin + Tol)
        {
            intervalos.Add(
                new IntervaloColumnaSerie(
                    viga.SolidoMin,
                    viga.SolidoMax));
        }

        if (intervalos.Count == 0 &&
            viga.Longitud > Tol)
        {
            intervalos.Add(
                new IntervaloColumnaSerie(
                    0.0,
                    viga.Longitud));
        }

        intervalos = intervalos
            .Where(i =>
                i != null &&
                i.Max > i.Min + Tol)
            .OrderBy(i => i.Min)
            .ThenBy(i => i.Max)
            .ToList();

        List<IntervaloColumnaSerie> fusionados =
            new List<IntervaloColumnaSerie>();

        double toleranciaFusion =
            UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

        foreach (IntervaloColumnaSerie intervalo
            in intervalos)
        {
            if (fusionados.Count == 0)
            {
                fusionados.Add(
                    new IntervaloColumnaSerie(
                        intervalo.Min,
                        intervalo.Max));

                continue;
            }

            IntervaloColumnaSerie ultimo =
                fusionados[fusionados.Count - 1];

            if (intervalo.Min <= ultimo.Max + toleranciaFusion)
            {
                ultimo.Min =
                    Math.Min(
                        ultimo.Min,
                        intervalo.Min);

                ultimo.Max =
                    Math.Max(
                        ultimo.Max,
                        intervalo.Max);
            }
            else
            {
                fusionados.Add(
                    new IntervaloColumnaSerie(
                        intervalo.Min,
                        intervalo.Max));
            }
        }

        return fusionados;
    }


    private XYZ ObtenerPuntoEjeVigaEnEstacionMYG(
        DatosViga viga,
        double estacion)
    {
        if (viga == null ||
            viga.P0 == null ||
            viga.XAxis == null ||
            viga.XAxis.GetLength() <= Tol)
        {
            return null;
        }

        return viga.P0.Add(
            viga.XAxis.Normalize().Multiply(estacion));
    }


    private double CalcularEstacionVigaDesdeGlobal(
        DatosViga viga,
        XYZ origen,
        XYZ ejeGlobal,
        double estacionGlobal)
    {
        if (viga == null || origen == null || ejeGlobal == null || ejeGlobal.GetLength() <= Tol)
            return 0.0;

        double g0 = (viga.P0 - origen).DotProduct(ejeGlobal.Normalize());
        double g1 = (viga.P1 - origen).DotProduct(ejeGlobal.Normalize());
        double delta = g1 - g0;

        if (Math.Abs(delta) <= Tol)
            return 0.0;

        double factor = (estacionGlobal - g0) / delta;

        // No se clampa: si más adelante se usa desarrollo fuera del extremo,
        // la extrapolación sigue la dirección del tramo correspondiente.
        return factor * viga.Longitud;
    }

    private void CalcularExtremosLuzLibre(
        List<IntervaloColumnaSerie> columnas,
        double minSolido,
        double maxSolido,
        out double inicioLibre,
        out double finLibre)
    {
        inicioLibre = minSolido;
        finLibre = maxSolido;

        if (columnas == null || columnas.Count == 0)
            return;

        double toleranciaExtremo = UnitUtils.ConvertToInternalUnits(
            80.0,
            UnitTypeId.Centimeters);

        List<IntervaloColumnaSerie> ordenadas = columnas
            .Where(c => c != null && c.Max > c.Min)
            .OrderBy(c => c.Min)
            .ToList();

        IntervaloColumnaSerie colInicio = ordenadas
            .Where(c =>
                c.Min <= minSolido + toleranciaExtremo &&
                c.Max >= minSolido - toleranciaExtremo)
            .OrderBy(c => Math.Abs(c.Center - minSolido))
            .FirstOrDefault();

        if (colInicio != null && colInicio.Max > minSolido)
        {
            inicioLibre = Math.Min(
                Math.Max(colInicio.Max, minSolido),
                maxSolido);
        }

        IntervaloColumnaSerie colFin = ordenadas
            .Where(c =>
                c.Max >= maxSolido - toleranciaExtremo &&
                c.Min <= maxSolido + toleranciaExtremo)
            .OrderBy(c => Math.Abs(c.Center - maxSolido))
            .FirstOrDefault();

        if (colFin != null && colFin.Min < maxSolido)
        {
            finLibre = Math.Max(
                Math.Min(colFin.Min, maxSolido),
                minSolido);
        }
    }

    private List<IntervaloColumnaSerie> FusionarIntervalosColumnas(
        List<IntervaloColumnaSerie> columnas)
    {
        List<IntervaloColumnaSerie> resultado =
            new List<IntervaloColumnaSerie>();

        if (columnas == null || columnas.Count == 0)
            return resultado;

        double toleranciaUnion = UnitUtils.ConvertToInternalUnits(
            2.0,
            UnitTypeId.Centimeters);

        foreach (IntervaloColumnaSerie col in columnas.OrderBy(x => x.Min))
        {
            if (col == null)
                continue;

            if (resultado.Count == 0)
            {
                resultado.Add(new IntervaloColumnaSerie(col.Min, col.Max));
                continue;
            }

            IntervaloColumnaSerie ultima = resultado[resultado.Count - 1];

            if (col.Min <= ultima.Max + toleranciaUnion)
            {
                ultima.Min = Math.Min(ultima.Min, col.Min);
                ultima.Max = Math.Max(ultima.Max, col.Max);
            }
            else
            {
                resultado.Add(new IntervaloColumnaSerie(col.Min, col.Max));
            }
        }

        return resultado;
    }

    private DatosViga ObtenerDatosViga(Element viga)
    {
        if (viga == null)
            return null;

        Curve curva = ObtenerCurvaElemento(viga);

        if (curva == null)
            return null;

        XYZ p0 = curva.GetEndPoint(0);
        XYZ p1 = curva.GetEndPoint(1);

        XYZ xAxis = p1 - p0;
        double longitud = xAxis.GetLength();

        if (longitud <= Tol)
            return null;

        xAxis = xAxis.Normalize();

        XYZ yAxis = XYZ.BasisZ.CrossProduct(xAxis);

        if (yAxis.GetLength() <= Tol)
            yAxis = XYZ.BasisX.CrossProduct(xAxis);

        if (yAxis.GetLength() <= Tol)
            yAxis = XYZ.BasisY;

        yAxis = yAxis.Normalize();

        XYZ zAxis = xAxis.CrossProduct(yAxis);

        if (zAxis.GetLength() <= Tol)
            zAxis = XYZ.BasisZ;

        zAxis = zAxis.Normalize();

        if (zAxis.DotProduct(XYZ.BasisZ) < 0)
        {
            zAxis = zAxis.Multiply(-1.0);
            yAxis = zAxis.CrossProduct(xAxis);

            if (yAxis.GetLength() <= Tol)
                yAxis = XYZ.BasisY;

            yAxis = yAxis.Normalize();
        }

        List<XYZ> puntos = ObtenerPuntosSolidoElemento(viga);

        if (puntos == null || puntos.Count == 0)
            puntos = ObtenerPuntosBoundingBoxElemento(viga);

        if (puntos == null || puntos.Count == 0)
            return null;

        double minX = double.MaxValue;
        double maxX = double.MinValue;

        double minY = double.MaxValue;
        double maxY = double.MinValue;

        double minZ = double.MaxValue;
        double maxZ = double.MinValue;

        foreach (XYZ p in puntos)
        {
            double px = (p - p0).DotProduct(xAxis);
            double py = (p - p0).DotProduct(yAxis);
            double pz = (p - p0).DotProduct(zAxis);

            if (px < minX) minX = px;
            if (px > maxX) maxX = px;

            if (py < minY) minY = py;
            if (py > maxY) maxY = py;

            if (pz < minZ) minZ = pz;
            if (pz > maxZ) maxZ = pz;
        }

        if (maxX <= minX)
        {
            minX = 0.0;
            maxX = longitud;
        }

        if (maxY <= minY || maxZ <= minZ)
            return null;

        DatosViga datos = new DatosViga();

        datos.Elemento = viga;

        datos.P0 = p0;
        datos.P1 = p1;

        datos.XAxis = xAxis;
        datos.YAxis = yAxis;
        datos.ZAxis = zAxis;

        datos.Longitud = longitud;

        datos.SolidoMin = minX;
        datos.SolidoMax = maxX;

        datos.YMin = minY;
        datos.YMax = maxY;

        datos.ZMin = minZ;
        datos.ZMax = maxZ;

        datos.Ancho = maxY - minY;
        datos.Alto = maxZ - minZ;
        datos.PuntosSolidoGlobal = puntos;
        datos.SolidosGlobales = ObtenerSolidosElementoParaValidacionMYG(viga);
        CalcularPlanosCarasPrincipales3DMYG(datos);

        CalcularPerfilSeccionVariableViga(
            datos,
            puntos);

        return datos;
    }

    private void CalcularPerfilSeccionVariableViga(
        DatosViga datos,
        List<XYZ> puntos)
    {
        if (datos == null)
            return;

        datos.TienePerfilSeccionVariable = false;
        datos.ZSuperiorInicio = datos.ZMax;
        datos.ZSuperiorFin = datos.ZMax;
        datos.ZInferiorInicio = datos.ZMin;
        datos.ZInferiorFin = datos.ZMin;
        datos.PerfilSuperiorDetallado = new List<SegmentoPerfilCara>();
        datos.PerfilInferiorDetallado = new List<SegmentoPerfilCara>();

        if (puntos == null || puntos.Count == 0)
            return;

        if (datos.SolidoMax <= datos.SolidoMin + Tol)
            return;

        double zSupIni = 0.0;
        double zInfIni = 0.0;
        double zSupFin = 0.0;
        double zInfFin = 0.0;

        bool okInicio = ObtenerPerfilZEnExtremoViga(
            datos,
            puntos,
            datos.SolidoMin,
            out zSupIni,
            out zInfIni);

        bool okFin = ObtenerPerfilZEnExtremoViga(
            datos,
            puntos,
            datos.SolidoMax,
            out zSupFin,
            out zInfFin);

        if (!okInicio || !okFin)
            return;

        datos.ZSuperiorInicio = zSupIni;
        datos.ZSuperiorFin = zSupFin;
        datos.ZInferiorInicio = zInfIni;
        datos.ZInferiorFin = zInfFin;

        // Se activa siempre que el perfil sea válido.
        // En secciones constantes, los valores inicio/fin serán iguales y no cambia el resultado.
        datos.TienePerfilSeccionVariable = true;

        CalcularPerfilesDetalladosDeCaras(
            datos,
            puntos);
    }

    private void CalcularPerfilesDetalladosDeCaras(
        DatosViga datos,
        List<XYZ> puntos)
    {
        if (datos == null)
            return;

        datos.PerfilSuperiorDetallado = new List<SegmentoPerfilCara>();
        datos.PerfilInferiorDetallado = new List<SegmentoPerfilCara>();

        if (datos.SolidoMax <= datos.SolidoMin + Tol)
            return;

        // V9:
        // Ya no se arma el perfil tomando máximos/mínimos de todos los vértices.
        // Eso tomaba vértices de uniones, cortes y microcaras y generaba los picos.
        // Ahora se leen únicamente las PlanarFace principales superior e inferior.
        datos.PerfilSuperiorDetallado = ObtenerPerfilPrincipalDesdeCarasPlanar(datos, true);
        datos.PerfilInferiorDetallado = ObtenerPerfilPrincipalDesdeCarasPlanar(datos, false);

        if (datos.PerfilSuperiorDetallado == null || datos.PerfilSuperiorDetallado.Count == 0)
            datos.PerfilSuperiorDetallado = CrearPerfilSimpleCara(datos, true);

        if (datos.PerfilInferiorDetallado == null || datos.PerfilInferiorDetallado.Count == 0)
            datos.PerfilInferiorDetallado = CrearPerfilSimpleCara(datos, false);

        datos.PerfilSuperiorDetallado = NormalizarYCubrirPerfilCara(datos, datos.PerfilSuperiorDetallado, true);
        datos.PerfilInferiorDetallado = NormalizarYCubrirPerfilCara(datos, datos.PerfilInferiorDetallado, false);

        if (datos.PerfilSuperiorDetallado != null && datos.PerfilSuperiorDetallado.Count > 0)
        {
            datos.ZSuperiorInicio = ZEnSegmentoPerfil(datos.PerfilSuperiorDetallado[0], datos.SolidoMin);
            datos.ZSuperiorFin = ZEnSegmentoPerfil(datos.PerfilSuperiorDetallado[datos.PerfilSuperiorDetallado.Count - 1], datos.SolidoMax);
        }

        if (datos.PerfilInferiorDetallado != null && datos.PerfilInferiorDetallado.Count > 0)
        {
            datos.ZInferiorInicio = ZEnSegmentoPerfil(datos.PerfilInferiorDetallado[0], datos.SolidoMin);
            datos.ZInferiorFin = ZEnSegmentoPerfil(datos.PerfilInferiorDetallado[datos.PerfilInferiorDetallado.Count - 1], datos.SolidoMax);
        }
    }

    private List<SegmentoPerfilCara> ObtenerPerfilPrincipalDesdeCarasPlanar(
        DatosViga datos,
        bool superior)
    {
        List<SegmentoPerfilCara> segmentos = new List<SegmentoPerfilCara>();

        if (datos == null || datos.Elemento == null)
            return segmentos;

        Options opt = new Options();
        opt.DetailLevel = ViewDetailLevel.Fine;
        opt.IncludeNonVisibleObjects = false;
        opt.ComputeReferences = false;

        GeometryElement geo = null;

        try
        {
            geo = datos.Elemento.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return segmentos;

        RecolectarSegmentosPerfilDesdeGeometria(
            geo,
            Transform.Identity,
            datos,
            superior,
            segmentos);

        return NormalizarYCubrirPerfilCara(datos, segmentos, superior);
    }

    private void RecolectarSegmentosPerfilDesdeGeometria(
        GeometryElement geo,
        Transform transform,
        DatosViga datos,
        bool superior,
        List<SegmentoPerfilCara> segmentos)
    {
        if (geo == null || datos == null || segmentos == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                RecolectarSegmentosPerfilDesdeSolido(solid, transform, datos, superior, segmentos);
                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                try
                {
                    GeometryElement geoInst = gi.GetInstanceGeometry();

                    if (geoInst != null)
                    {
                        RecolectarSegmentosPerfilDesdeGeometria(
                            geoInst,
                            Transform.Identity,
                            datos,
                            superior,
                            segmentos);

                        continue;
                    }
                }
                catch
                {
                    // Se prueba con geometría de símbolo.
                }

                try
                {
                    GeometryElement geoSym = gi.GetSymbolGeometry();

                    if (geoSym != null)
                    {
                        Transform t2 = transform == null
                            ? gi.Transform
                            : transform.Multiply(gi.Transform);

                        RecolectarSegmentosPerfilDesdeGeometria(
                            geoSym,
                            t2,
                            datos,
                            superior,
                            segmentos);
                    }
                }
                catch
                {
                    // Ignorar geometría inválida.
                }
            }
        }
    }

    private void RecolectarSegmentosPerfilDesdeSolido(
        Solid solid,
        Transform transform,
        DatosViga datos,
        bool superior,
        List<SegmentoPerfilCara> segmentos)
    {
        if (solid == null || datos == null || segmentos == null)
            return;

        try
        {
            if (solid.Volume <= Tol)
                return;
        }
        catch
        {
            // Se intenta de todos modos.
        }

        if (solid.Faces == null || solid.Faces.Size == 0)
            return;

        foreach (Face face in solid.Faces)
        {
            PlanarFace pf = face as PlanarFace;

            if (pf == null)
                continue;

            SegmentoPerfilCara seg = CrearSegmentoPerfilDesdePlanarFace(
                pf,
                transform,
                datos,
                superior);

            if (seg != null)
                segmentos.Add(seg);
        }
    }

    private SegmentoPerfilCara CrearSegmentoPerfilDesdePlanarFace(
        PlanarFace pf,
        Transform transform,
        DatosViga datos,
        bool superior)
    {
        if (pf == null || datos == null)
            return null;

        XYZ normal = pf.FaceNormal;

        if (normal == null || normal.GetLength() <= Tol)
            return null;

        if (transform != null && !transform.IsIdentity)
            normal = transform.OfVector(normal);

        if (normal.GetLength() <= Tol)
            return null;

        normal = normal.Normalize();

        double nz = normal.DotProduct(datos.ZAxis);
        double ny = Math.Abs(normal.DotProduct(datos.YAxis));

        // Caras laterales tienen normal casi paralela a Y. Esas no se usan para el perfil.
        if (ny > 0.70)
            return null;

        // Caras principales superior/inferior. Se descartan caras verticales, remates y microcortes.
        if (superior)
        {
            if (nz < 0.12)
                return null;
        }
        else
        {
            if (nz > -0.12)
                return null;
        }

        List<XYZ> puntos = ObtenerPuntosPlanarFace(pf, transform);

        if (puntos == null || puntos.Count < 2)
            return null;

        double minX = double.MaxValue;
        double maxX = double.MinValue;
        double minY = double.MaxValue;
        double maxY = double.MinValue;
        double sumaX = 0.0;
        double sumaZ = 0.0;
        int n = 0;

        List<Tuple<double, double>> xz = new List<Tuple<double, double>>();

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double x = (p - datos.P0).DotProduct(datos.XAxis);
            double y = (p - datos.P0).DotProduct(datos.YAxis);
            double z = (p - datos.P0).DotProduct(datos.ZAxis);

            double margenX = UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters);

            if (x < datos.SolidoMin - margenX || x > datos.SolidoMax + margenX)
                continue;

            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;

            sumaX += x;
            sumaZ += z;
            n++;
            xz.Add(new Tuple<double, double>(x, z));
        }

        if (n < 2 || maxX <= minX + Tol)
            return null;

        double longitud = datos.SolidoMax - datos.SolidoMin;
        double xSpan = maxX - minX;
        double ySpan = maxY - minY;
        double zProm = sumaZ / n;
        double zMedio = (datos.ZMin + datos.ZMax) / 2.0;

        double minSpanX = Math.Max(
            UnitUtils.ConvertToInternalUnits(8.0, UnitTypeId.Centimeters),
            longitud * 0.012);

        if (xSpan < minSpanX)
            return null;

        double minSpanY = Math.Max(
            UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters),
            datos.Ancho * 0.20);

        if (ySpan < minSpanY)
            return null;

        if (superior && zProm < zMedio)
            return null;

        if (!superior && zProm > zMedio)
            return null;

        double xMean = sumaX / n;
        double zMean = sumaZ / n;
        double varX = 0.0;
        double covXZ = 0.0;

        foreach (Tuple<double, double> par in xz)
        {
            double dx = par.Item1 - xMean;
            double dz = par.Item2 - zMean;
            varX += dx * dx;
            covXZ += dx * dz;
        }

        if (Math.Abs(varX) <= Tol)
            return null;

        double a = covXZ / varX;
        double b = zMean - a * xMean;

        if (Math.Abs(a) > 1.50)
            return null;

        double x0 = Math.Max(datos.SolidoMin, minX);
        double x1 = Math.Min(datos.SolidoMax, maxX);

        if (x1 <= x0 + Tol)
            return null;

        return new SegmentoPerfilCara(
            x0,
            a * x0 + b,
            x1,
            a * x1 + b);
    }

    private List<XYZ> ObtenerPuntosPlanarFace(
        PlanarFace pf,
        Transform transform)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (pf == null)
            return puntos;

        try
        {
            EdgeArrayArray loops = pf.EdgeLoops;

            if (loops == null)
                return puntos;

            foreach (EdgeArray loop in loops)
            {
                if (loop == null)
                    continue;

                foreach (Edge edge in loop)
                {
                    if (edge == null)
                        continue;

                    Curve c = null;

                    try
                    {
                        c = edge.AsCurve();
                    }
                    catch
                    {
                        c = null;
                    }

                    if (c == null)
                        continue;

                    try
                    {
                        XYZ a = c.GetEndPoint(0);
                        XYZ b = c.GetEndPoint(1);

                        if (transform != null && !transform.IsIdentity)
                        {
                            a = transform.OfPoint(a);
                            b = transform.OfPoint(b);
                        }

                        puntos.Add(a);
                        puntos.Add(b);
                    }
                    catch
                    {
                        // Ignorar aristas inválidas.
                    }
                }
            }
        }
        catch
        {
            // Ignorar caras que no se puedan recorrer.
        }

        return puntos;
    }

    private List<SegmentoPerfilCara> NormalizarYCubrirPerfilCara(
        DatosViga datos,
        List<SegmentoPerfilCara> segmentos,
        bool superior)
    {
        List<SegmentoPerfilCara> resultado = new List<SegmentoPerfilCara>();

        if (datos == null || segmentos == null || segmentos.Count == 0)
            return resultado;

        double longitud = datos.SolidoMax - datos.SolidoMin;

        if (longitud <= Tol)
            return resultado;

        double tolX = UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters);
        double minSegmento = Math.Max(UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters), longitud * 0.005);

        List<SegmentoPerfilCara> normalizados = new List<SegmentoPerfilCara>();

        foreach (SegmentoPerfilCara s in segmentos)
        {
            if (s == null)
                continue;

            double x0 = Math.Max(datos.SolidoMin, Math.Min(s.X0, s.X1));
            double x1 = Math.Min(datos.SolidoMax, Math.Max(s.X0, s.X1));

            if (x1 <= x0 + minSegmento)
                continue;

            normalizados.Add(new SegmentoPerfilCara(
                x0,
                ZEnSegmentoPerfil(s, x0),
                x1,
                ZEnSegmentoPerfil(s, x1)));
        }

        if (normalizados.Count == 0)
            return resultado;

        List<double> cortes = new List<double>();
        cortes.Add(datos.SolidoMin);
        cortes.Add(datos.SolidoMax);

        foreach (SegmentoPerfilCara s in normalizados)
        {
            cortes.Add(s.X0);
            cortes.Add(s.X1);
        }

        cortes = cortes
            .Where(x => x >= datos.SolidoMin - tolX && x <= datos.SolidoMax + tolX)
            .Select(x => Math.Max(datos.SolidoMin, Math.Min(datos.SolidoMax, x)))
            .OrderBy(x => x)
            .ToList();

        List<double> cortesUnicos = new List<double>();

        foreach (double x in cortes)
        {
            if (cortesUnicos.Count == 0 || Math.Abs(x - cortesUnicos[cortesUnicos.Count - 1]) > tolX)
                cortesUnicos.Add(x);
        }

        for (int i = 0; i < cortesUnicos.Count - 1; i++)
        {
            double x0 = cortesUnicos[i];
            double x1 = cortesUnicos[i + 1];

            if (x1 <= x0 + minSegmento)
                continue;

            double xm = (x0 + x1) / 2.0;

            List<SegmentoPerfilCara> candidatos = normalizados
                .Where(s => s != null && xm >= s.X0 - tolX && xm <= s.X1 + tolX)
                .ToList();

            if (candidatos.Count == 0)
                continue;

            SegmentoPerfilCara elegido = candidatos[0];
            double zElegido = ZEnSegmentoPerfil(elegido, xm);

            foreach (SegmentoPerfilCara c in candidatos.Skip(1))
            {
                double zc = ZEnSegmentoPerfil(c, xm);

                if (superior)
                {
                    if (zc > zElegido)
                    {
                        elegido = c;
                        zElegido = zc;
                    }
                }
                else
                {
                    if (zc < zElegido)
                    {
                        elegido = c;
                        zElegido = zc;
                    }
                }
            }

            resultado.Add(new SegmentoPerfilCara(
                x0,
                ZEnSegmentoPerfil(elegido, x0),
                x1,
                ZEnSegmentoPerfil(elegido, x1)));
        }

        if (resultado.Count == 0)
            resultado.AddRange(normalizados);

        resultado = FusionarSegmentosPerfilColineales(resultado);
        resultado = CubrirGapsPerfil(datos, resultado, superior);
        resultado = FusionarSegmentosPerfilColineales(resultado);

        return resultado;
    }

    private List<SegmentoPerfilCara> CubrirGapsPerfil(
        DatosViga datos,
        List<SegmentoPerfilCara> segmentos,
        bool superior)
    {
        List<SegmentoPerfilCara> resultado = new List<SegmentoPerfilCara>();

        if (datos == null || segmentos == null || segmentos.Count == 0)
            return resultado;

        segmentos = segmentos
            .Where(s => s != null)
            .OrderBy(s => s.X0)
            .ToList();

        double tolGap = UnitUtils.ConvertToInternalUnits(3.0, UnitTypeId.Centimeters);

        SegmentoPerfilCara primero = segmentos[0];

        if (primero.X0 > datos.SolidoMin + tolGap)
        {
            resultado.Add(new SegmentoPerfilCara(
                datos.SolidoMin,
                ZEnSegmentoPerfil(primero, datos.SolidoMin),
                primero.X0,
                primero.Z0));
        }

        resultado.Add(primero);

        for (int i = 0; i < segmentos.Count - 1; i++)
        {
            SegmentoPerfilCara a = segmentos[i];
            SegmentoPerfilCara b = segmentos[i + 1];

            if (a == null || b == null)
                continue;

            if (b.X0 > a.X1 + tolGap)
            {
                double xi;
                double zi;

                if (TryIntersecarSegmentosPerfil2D(a, b, out xi, out zi) &&
                    xi >= a.X1 - datos.Alto * 4.0 &&
                    xi <= b.X0 + datos.Alto * 4.0)
                {
                    resultado.Add(new SegmentoPerfilCara(a.X1, a.Z1, xi, zi));
                    resultado.Add(new SegmentoPerfilCara(xi, zi, b.X0, b.Z0));
                }
                else
                {
                    resultado.Add(new SegmentoPerfilCara(a.X1, a.Z1, b.X0, b.Z0));
                }
            }

            resultado.Add(b);
        }

        SegmentoPerfilCara ultimo = segmentos[segmentos.Count - 1];

        if (ultimo.X1 < datos.SolidoMax - tolGap)
        {
            resultado.Add(new SegmentoPerfilCara(
                ultimo.X1,
                ultimo.Z1,
                datos.SolidoMax,
                ZEnSegmentoPerfil(ultimo, datos.SolidoMax)));
        }

        return resultado;
    }

    private List<SegmentoPerfilCara> FusionarSegmentosPerfilColineales(
        List<SegmentoPerfilCara> segmentos)
    {
        List<SegmentoPerfilCara> resultado = new List<SegmentoPerfilCara>();

        if (segmentos == null || segmentos.Count == 0)
            return resultado;

        double toleranciaZ = UnitUtils.ConvertToInternalUnits(0.40, UnitTypeId.Centimeters);
        double toleranciaGap = UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters);

        foreach (SegmentoPerfilCara s in segmentos.Where(x => x != null).OrderBy(x => x.X0))
        {
            if (resultado.Count == 0)
            {
                resultado.Add(s);
                continue;
            }

            SegmentoPerfilCara u = resultado[resultado.Count - 1];

            bool toca = Math.Abs(s.X0 - u.X1) <= toleranciaGap;
            double pendienteU = PendienteSegmentoPerfil(u);
            double pendienteS = PendienteSegmentoPerfil(s);

            if (toca && Math.Abs(pendienteU - pendienteS) <= 0.003)
            {
                double zNuevo = ZEnSegmentoPerfil(u, s.X1);

                if (Math.Abs(zNuevo - s.Z1) <= toleranciaZ)
                {
                    u.X1 = s.X1;
                    u.Z1 = s.Z1;
                    continue;
                }
            }

            resultado.Add(s);
        }

        return resultado;
    }

    private double ZEnSegmentoPerfil(
        SegmentoPerfilCara s,
        double x)
    {
        if (s == null)
            return 0.0;

        double dx = s.X1 - s.X0;

        if (Math.Abs(dx) <= Tol)
            return (s.Z0 + s.Z1) / 2.0;

        double t = (x - s.X0) / dx;
        return s.Z0 + (s.Z1 - s.Z0) * t;
    }

    private double PendienteSegmentoPerfil(
        SegmentoPerfilCara s)
    {
        if (s == null)
            return 0.0;

        double dx = s.X1 - s.X0;

        if (Math.Abs(dx) <= Tol)
            return 0.0;

        return (s.Z1 - s.Z0) / dx;
    }

    private bool TryIntersecarSegmentosPerfil2D(
        SegmentoPerfilCara a,
        SegmentoPerfilCara b,
        out double x,
        out double z)
    {
        x = 0.0;
        z = 0.0;

        if (a == null || b == null)
            return false;

        double ma = PendienteSegmentoPerfil(a);
        double mb = PendienteSegmentoPerfil(b);

        if (Math.Abs(ma - mb) <= 1e-9)
            return false;

        double ba = a.Z0 - ma * a.X0;
        double bb = b.Z0 - mb * b.X0;

        x = (bb - ba) / (ma - mb);
        z = ma * x + ba;

        return true;
    }

    private List<PuntoPerfilCara> SimplificarPuntosPerfilCara(
        List<PuntoPerfilCara> puntos)
    {
        List<PuntoPerfilCara> resultado = new List<PuntoPerfilCara>();

        if (puntos == null || puntos.Count == 0)
            return resultado;

        List<PuntoPerfilCara> ordenados = puntos
            .Where(p => p != null)
            .OrderBy(p => p.X)
            .ToList();

        if (ordenados.Count == 0)
            return resultado;

        // Limpieza fuerte del perfil leído del sólido:
        // - elimina microsegmentos de uniones/copes de Revit;
        // - conserva solo cambios de cara con longitud real;
        // - aplana tramos casi horizontales para que el acero quede paralelo a la cara.
        double toleranciaZHorizontal = UnitUtils.ConvertToInternalUnits(0.80, UnitTypeId.Centimeters);
        double toleranciaColineal = UnitUtils.ConvertToInternalUnits(0.50, UnitTypeId.Centimeters);
        double longitudMinimaCara = UnitUtils.ConvertToInternalUnits(18.0, UnitTypeId.Centimeters);
        double toleranciaXDuplicado = UnitUtils.ConvertToInternalUnits(0.50, UnitTypeId.Centimeters);

        // 1) Fusionar estaciones X casi duplicadas.
        List<PuntoPerfilCara> fusionados = new List<PuntoPerfilCara>();

        foreach (PuntoPerfilCara p in ordenados)
        {
            if (p == null)
                continue;

            if (fusionados.Count == 0)
            {
                fusionados.Add(new PuntoPerfilCara(p.X, p.Z));
                continue;
            }

            PuntoPerfilCara u = fusionados[fusionados.Count - 1];

            if (Math.Abs(p.X - u.X) <= toleranciaXDuplicado)
            {
                // Se promedia para no crear segmentos verticales falsos en el perfil.
                u.X = (u.X + p.X) / 2.0;
                u.Z = (u.Z + p.Z) / 2.0;
            }
            else
            {
                fusionados.Add(new PuntoPerfilCara(p.X, p.Z));
            }
        }

        if (fusionados.Count <= 2)
            return fusionados;

        // 2) Aplanar grupos casi horizontales consecutivos.
        for (int i = 0; i < fusionados.Count - 1; i++)
        {
            PuntoPerfilCara a = fusionados[i];
            PuntoPerfilCara b = fusionados[i + 1];

            if (a == null || b == null)
                continue;

            if (Math.Abs(b.Z - a.Z) <= toleranciaZHorizontal)
            {
                double zProm = (a.Z + b.Z) / 2.0;
                a.Z = zProm;
                b.Z = zProm;
            }
        }

        // 3) Simplificación por colinealidad.
        resultado.Add(fusionados[0]);

        for (int i = 1; i < fusionados.Count - 1; i++)
        {
            PuntoPerfilCara a = resultado[resultado.Count - 1];
            PuntoPerfilCara b = fusionados[i];
            PuntoPerfilCara c = fusionados[i + 1];

            if (!EsPuntoPerfilColineal(a, b, c, toleranciaColineal))
                resultado.Add(b);
        }

        resultado.Add(fusionados[fusionados.Count - 1]);

        // 4) Eliminar caras demasiado cortas que vienen de uniones o cortes pequeños.
        bool cambio = true;
        int seguridad = 0;

        while (cambio && resultado.Count > 2 && seguridad < 100)
        {
            seguridad++;
            cambio = false;

            for (int i = 0; i < resultado.Count - 1; i++)
            {
                PuntoPerfilCara a = resultado[i];
                PuntoPerfilCara b = resultado[i + 1];

                if (a == null || b == null)
                    continue;

                double longitud = Math.Sqrt((b.X - a.X) * (b.X - a.X) + (b.Z - a.Z) * (b.Z - a.Z));

                if (longitud >= longitudMinimaCara)
                    continue;

                // Mantener los extremos globales cuando sea posible y eliminar el punto interior.
                if (i == 0)
                    resultado.RemoveAt(1);
                else if (i + 1 == resultado.Count - 1)
                    resultado.RemoveAt(i);
                else
                    resultado.RemoveAt(i + 1);

                cambio = true;
                break;
            }
        }

        // 5) Última pasada de colinealidad después de borrar microsegmentos.
        if (resultado.Count <= 2)
            return resultado;

        List<PuntoPerfilCara> final = new List<PuntoPerfilCara>();
        final.Add(resultado[0]);

        for (int i = 1; i < resultado.Count - 1; i++)
        {
            PuntoPerfilCara a = final[final.Count - 1];
            PuntoPerfilCara b = resultado[i];
            PuntoPerfilCara c = resultado[i + 1];

            if (!EsPuntoPerfilColineal(a, b, c, toleranciaColineal))
                final.Add(b);
        }

        final.Add(resultado[resultado.Count - 1]);

        return final;
    }

    private bool EsPuntoPerfilColineal(
        PuntoPerfilCara a,
        PuntoPerfilCara b,
        PuntoPerfilCara c,
        double toleranciaZ)
    {
        if (a == null || b == null || c == null)
            return false;

        double dx = c.X - a.X;

        if (Math.Abs(dx) <= Tol)
            return false;

        double t = (b.X - a.X) / dx;
        double zInterpolado = a.Z + (c.Z - a.Z) * t;

        return Math.Abs(zInterpolado - b.Z) <= toleranciaZ;
    }

    private List<SegmentoPerfilCara> CrearSegmentosDesdePuntosPerfil(
        List<PuntoPerfilCara> puntos)
    {
        List<SegmentoPerfilCara> segmentos = new List<SegmentoPerfilCara>();

        if (puntos == null || puntos.Count < 2)
            return segmentos;

        double toleranciaX = UnitUtils.ConvertToInternalUnits(0.50, UnitTypeId.Centimeters);
        double longitudMinima = UnitUtils.ConvertToInternalUnits(18.0, UnitTypeId.Centimeters);

        for (int i = 0; i < puntos.Count - 1; i++)
        {
            PuntoPerfilCara a = puntos[i];
            PuntoPerfilCara b = puntos[i + 1];

            if (a == null || b == null)
                continue;

            double dx = b.X - a.X;
            double dz = b.Z - a.Z;
            double longitud = Math.Sqrt(dx * dx + dz * dz);

            // No se aceptan segmentos verticales del perfil: esos eran picos/cortes de unión.
            if (Math.Abs(dx) <= toleranciaX)
                continue;

            if (longitud <= Tol)
                continue;

            if (longitud < longitudMinima && puntos.Count > 2)
                continue;

            segmentos.Add(new SegmentoPerfilCara(a.X, a.Z, b.X, b.Z));
        }

        return segmentos;
    }

    private bool ObtenerPerfilZEnExtremoViga(
        DatosViga datos,
        List<XYZ> puntos,
        double estacionObjetivo,
        out double zSuperior,
        out double zInferior)
    {
        zSuperior = 0.0;
        zInferior = 0.0;

        if (datos == null || puntos == null || puntos.Count == 0)
            return false;

        double longitud = datos.SolidoMax - datos.SolidoMin;

        if (longitud <= Tol)
            return false;

        double anchoFranja = Math.Max(
            UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters),
            longitud * 0.08);

        List<Tuple<double, double>> candidatos =
            new List<Tuple<double, double>>();

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double x = (p - datos.P0).DotProduct(datos.XAxis);
            double z = (p - datos.P0).DotProduct(datos.ZAxis);
            double dist = Math.Abs(x - estacionObjetivo);

            candidatos.Add(new Tuple<double, double>(dist, z));
        }

        if (candidatos.Count == 0)
            return false;

        double distanciaMinima = candidatos.Min(c => c.Item1);
        double limite = Math.Max(
            anchoFranja,
            distanciaMinima + UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters));

        List<double> valoresZ = candidatos
            .Where(c => c.Item1 <= limite)
            .Select(c => c.Item2)
            .ToList();

        if (valoresZ.Count < 2)
        {
            valoresZ = candidatos
                .OrderBy(c => c.Item1)
                .Take(12)
                .Select(c => c.Item2)
                .ToList();
        }

        if (valoresZ.Count < 2)
            return false;

        zSuperior = valoresZ.Max();
        zInferior = valoresZ.Min();

        return zSuperior > zInferior + Tol;
    }


    private List<XYZ> ObtenerPuntosSolidoElemento(Element elem)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elem == null)
            return puntos;

        Options opt = new Options();
        opt.DetailLevel = ViewDetailLevel.Fine;
        opt.IncludeNonVisibleObjects = false;
        opt.ComputeReferences = false;

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return puntos;

        RecolectarPuntosGeometria(
            geo,
            Transform.Identity,
            puntos);

        return puntos;
    }

    private void RecolectarPuntosGeometria(
        GeometryElement geo,
        Transform transform,
        List<XYZ> puntos)
    {
        if (geo == null || puntos == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                RecolectarPuntosSolido(
                    solid,
                    transform,
                    puntos);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                try
                {
                    GeometryElement geoInst = gi.GetInstanceGeometry();

                    if (geoInst != null)
                    {
                        RecolectarPuntosGeometria(
                            geoInst,
                            Transform.Identity,
                            puntos);
                    }
                }
                catch
                {
                    try
                    {
                        GeometryElement geoSym = gi.GetSymbolGeometry();

                        if (geoSym != null)
                        {
                            Transform t2 = transform.Multiply(gi.Transform);

                            RecolectarPuntosGeometria(
                                geoSym,
                                t2,
                                puntos);
                        }
                    }
                    catch
                    {
                        // Ignorar geometría que no pueda leerse.
                    }
                }
            }
        }
    }

    private void RecolectarPuntosSolido(
        Solid solid,
        Transform transform,
        List<XYZ> puntos)
    {
        if (solid == null || puntos == null)
            return;

        if (solid.Edges == null || solid.Edges.Size == 0)
            return;

        try
        {
            if (solid.Volume <= Tol)
                return;
        }
        catch
        {
            // Si no se puede leer volumen, igual se intenta con aristas.
        }

        foreach (Edge edge in solid.Edges)
        {
            if (edge == null)
                continue;

            Curve c = null;

            try
            {
                c = edge.AsCurve();
            }
            catch
            {
                c = null;
            }

            if (c == null)
                continue;

            try
            {
                XYZ a = c.GetEndPoint(0);
                XYZ b = c.GetEndPoint(1);

                if (transform != null && !transform.IsIdentity)
                {
                    a = transform.OfPoint(a);
                    b = transform.OfPoint(b);
                }

                puntos.Add(a);
                puntos.Add(b);
            }
            catch
            {
                // Ignorar aristas inválidas.
            }
        }
    }

    private List<XYZ> ObtenerPuntosBoundingBoxElemento(Element elem)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elem == null)
            return puntos;

        BoundingBoxXYZ bb = elem.get_BoundingBox(null);

        if (bb == null)
            return puntos;

        return ObtenerPuntosBoundingBox(bb);
    }

    private List<Element> ObtenerVigasOrdenadas(
        Document doc,
        List<ElementId> ids)
    {
        List<Element> vigas = new List<Element>();

        if (doc == null || ids == null || ids.Count == 0)
            return vigas;

        foreach (ElementId id in ids)
        {
            Element e = doc.GetElement(id);

            if (e != null)
                vigas.Add(e);
        }

        if (vigas.Count <= 1)
            return vigas;

        Curve curvaBase = ObtenerCurvaElemento(vigas[0]);

        if (curvaBase == null)
            return vigas;

        XYZ origen = curvaBase.GetEndPoint(0);
        XYZ eje = curvaBase.GetEndPoint(1) - curvaBase.GetEndPoint(0);

        if (eje.GetLength() <= Tol)
            return vigas;

        eje = eje.Normalize();

        vigas = vigas
            .OrderBy(e =>
            {
                Curve c = ObtenerCurvaElemento(e);

                if (c == null)
                    return 0.0;

                XYZ p0 = c.GetEndPoint(0);
                XYZ p1 = c.GetEndPoint(1);
                XYZ centro = (p0 + p1).Multiply(0.5);

                return (centro - origen).DotProduct(eje);
            })
            .ToList();

        return vigas;
    }

    private double ObtenerDistanciaHorizontalMinimaAlEje(
        BoundingBoxXYZ bb,
        XYZ origen,
        XYZ eje,
        double longitudEje)
    {
        if (bb == null)
            return double.MaxValue;

        if (origen == null || eje == null || eje.GetLength() <= Tol)
            return double.MaxValue;

        eje = eje.Normalize();

        List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

        XYZ centro = new XYZ(
            (bb.Min.X + bb.Max.X) / 2.0,
            (bb.Min.Y + bb.Max.Y) / 2.0,
            (bb.Min.Z + bb.Max.Z) / 2.0);

        puntos.Add(centro);

        double minDist = double.MaxValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double t = (p - origen).DotProduct(eje);

            if (t < 0.0)
                t = 0.0;

            if (t > longitudEje)
                t = longitudEje;

            XYZ puntoEje = origen + eje.Multiply(t);

            double dist = DistanciaHorizontal(p, puntoEje);

            if (dist < minDist)
                minDist = dist;
        }

        return minDist;
    }

    private double DistanciaHorizontal(XYZ a, XYZ b)
    {
        double dx = a.X - b.X;
        double dy = a.Y - b.Y;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    private List<XYZ> ObtenerPuntosBoundingBox(BoundingBoxXYZ bb)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (bb == null)
            return puntos;

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        puntos.Add(new XYZ(min.X, min.Y, min.Z));
        puntos.Add(new XYZ(max.X, min.Y, min.Z));
        puntos.Add(new XYZ(min.X, max.Y, min.Z));
        puntos.Add(new XYZ(max.X, max.Y, min.Z));

        puntos.Add(new XYZ(min.X, min.Y, max.Z));
        puntos.Add(new XYZ(max.X, min.Y, max.Z));
        puntos.Add(new XYZ(min.X, max.Y, max.Z));
        puntos.Add(new XYZ(max.X, max.Y, max.Z));

        return puntos;
    }

    private Curve ObtenerCurvaElemento(Element elem)
    {
        LocationCurve lc = elem.Location as LocationCurve;

        if (lc == null)
            return null;

        return lc.Curve;
    }

    private double ObtenerDiametroBarra(RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        Parameter p = tipo.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER);

        if (p != null && p.StorageType == StorageType.Double)
            return p.AsDouble();

        Parameter p2 = tipo.LookupParameter("Diámetro de barra");

        if (p2 != null && p2.StorageType == StorageType.Double)
            return p2.AsDouble();

        Parameter p3 = tipo.LookupParameter("Diámetro de barra de modelo");

        if (p3 != null && p3.StorageType == StorageType.Double)
            return p3.AsDouble();

        return 0.0;
    }

    private bool TryLeerEntero(string texto, out int valor)
    {
        valor = 0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        return int.TryParse(texto.Trim(), out valor);
    }

    private bool TryLeerLongitudConUnidadesRevitMYG(
        Document doc,
        string texto,
        out double valorInternoFt)
    {
        valorInternoFt = 0.0;

        if (doc == null || string.IsNullOrWhiteSpace(texto))
            return false;

        string original = texto.Trim();

        try
        {
            Units unidades = doc.GetUnits();

            if (UnitFormatUtils.TryParse(
                unidades,
                SpecTypeId.Length,
                original,
                out valorInternoFt) &&
                valorInternoFt > 0.0)
            {
                return true;
            }
        }
        catch
        {
        }

        // Respaldo para abreviaturas habituales que pueden variar según
        // el idioma/configuración regional del proyecto.
        string t = original
            .ToLowerInvariant()
            .Replace(",", ".")
            .Replace("pulgadas", "in")
            .Replace("pulgada", "in")
            .Replace("pulg", "in")
            .Replace("inches", "in")
            .Replace("inch", "in");

        ForgeTypeId unidad = UnitTypeId.Meters;
        string numero = t;

        if (t.EndsWith("mm"))
        {
            unidad = UnitTypeId.Millimeters;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("cm"))
        {
            unidad = UnitTypeId.Centimeters;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("in"))
        {
            unidad = UnitTypeId.Inches;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("\""))
        {
            unidad = UnitTypeId.Inches;
            numero = t.Substring(0, t.Length - 1);
        }
        else if (t.EndsWith("ft"))
        {
            unidad = UnitTypeId.Feet;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("'"))
        {
            unidad = UnitTypeId.Feet;
            numero = t.Substring(0, t.Length - 1);
        }
        else if (t.EndsWith("m"))
        {
            unidad = UnitTypeId.Meters;
            numero = t.Substring(0, t.Length - 1);
        }

        double valor;

        if (!double.TryParse(
            numero.Trim(),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor) ||
            valor <= 0.0)
        {
            return false;
        }

        try
        {
            valorInternoFt = UnitUtils.ConvertToInternalUnits(
                valor,
                unidad);

            return valorInternoFt > 0.0;
        }
        catch
        {
            valorInternoFt = 0.0;
            return false;
        }
    }

    private bool TryLeerDouble(string texto, out double valor)
    {
        valor = 0.0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string t = texto.Trim().Replace(",", ".");

        return double.TryParse(
            t,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor);
    }
}
