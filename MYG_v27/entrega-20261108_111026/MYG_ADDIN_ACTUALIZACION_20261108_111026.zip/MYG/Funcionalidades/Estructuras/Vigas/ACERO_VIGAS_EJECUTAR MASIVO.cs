﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace MYG_Addin
{
    // =========================================================
    // V11.51 - EJECUTAR ESTRIBOS + LONGITUDINALES / MODO MASIVO
    // =========================================================
    public class EjecutarAceroVigasMasivoHandler : IExternalEventHandler
    {
        public UIDocument UiDoc;
        public AceroVigasMainForm MainForm;
        public SeleccionarVigasForm FormSeleccion;
        public AceroLongitudinalVigasForm FormLongitudinal;
        public AceroEstribosVigasForm FormEstribos;
        public SeleccionarVigasAceroLongitudinalHandler SeleccionHandler;
        public EjecutarAceroLongitudinalVigasHandler HandlerLongitudinal;
        public EjecutarEstribosVigasHandler HandlerEstribos;

        private const double Tol = 1e-8;
        private const double ToleranciaAnguloGrados = 1.0;
        private const double ToleranciaColinealM = 0.05; // 5 cm transversal / desnivel

        private sealed class EjeVigaMasivaMYG
        {
            public ElementId Id;
            public XYZ P0;
            public XYZ P1;
            public XYZ Dir;
            public XYZ Medio;
            public double Longitud;
            public bool EsRecta;
        }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;
            if (uidoc == null || SeleccionHandler == null)
                return;

            Document doc = uidoc.Document;
            if (doc == null)
                return;

            List<ElementId> seleccionOriginal = SeleccionHandler.VigasSeleccionadas != null
                ? SeleccionHandler.VigasSeleccionadas
                    .Where(x => x != null && x != ElementId.InvalidElementId)
                    .GroupBy(x => x.Value)
                    .Select(g => g.First())
                    .ToList()
                : new List<ElementId>();

            if (seleccionOriginal.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Acero en Vigas",
                    "Primero seleccione una o más vigas/armazones estructurales.");
                return;
            }

            SeleccionarVigasForm seleccionForm = FormSeleccion;
            bool masivo = seleccionForm != null && seleccionForm.EjecutarMasivamenteMYG;
            double margenM = seleccionForm != null
                ? Math.Max(0.0, seleccionForm.MargenContinuidadMasivaM)
                : 0.50;

            bool ejecutarEstribos = LeerCheckPrivadoMYG(
                FormEstribos,
                "chkCrearEstribosV8",
                true);

            bool ejecutarLongitudinales = LeerCheckPrivadoMYG(
                FormLongitudinal,
                "chkCrearLongitudinalesV8",
                true);

            if (!ejecutarEstribos && !ejecutarLongitudinales)
            {
                TaskDialog.Show(
                    "MYG - Acero en Vigas",
                    "No hay ningún acero activado.\n\nActive Crear estribos y/o Crear acero longitudinal.");
                return;
            }

            if (!masivo)
            {
                EjecutarSerieMYG(
                    app,
                    doc,
                    seleccionOriginal,
                    ejecutarEstribos,
                    ejecutarLongitudinales,
                    false,
                    out string errorNormal);

                if (!string.IsNullOrWhiteSpace(errorNormal))
                {
                    TaskDialog.Show(
                        "MYG - Ejecutar todo",
                        errorNormal);
                }

                return;
            }

            double margenFt = UnitUtils.ConvertToInternalUnits(
                margenM,
                UnitTypeId.Meters);

            List<List<ElementId>> series = ConstruirSeriesMasivasMYG(
                doc,
                seleccionOriginal,
                margenFt);

            if (series.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Ejecución masiva",
                    "No se detectaron series de vigas válidas dentro de la selección.");
                return;
            }

            int seriesOk = 0;
            List<string> errores = new List<string>();

            try
            {
                for (int i = 0; i < series.Count; i++)
                {
                    List<ElementId> serie = series[i];
                    if (serie == null || serie.Count == 0)
                        continue;

                    try
                    {
                        bool ok = EjecutarSerieMYG(
                            app,
                            doc,
                            serie,
                            ejecutarEstribos,
                            ejecutarLongitudinales,
                            true,
                            out string errorSerie);

                        if (ok)
                            seriesOk++;
                        else
                            errores.Add(
                                "Serie " + (i + 1).ToString() +
                                " (" + serie.Count.ToString() + " vigas): " +
                                (string.IsNullOrWhiteSpace(errorSerie)
                                    ? "no pudo ejecutarse."
                                    : errorSerie));
                    }
                    catch (Exception ex)
                    {
                        errores.Add(
                            "Serie " + (i + 1).ToString() +
                            " (" + serie.Count.ToString() + " vigas): " + ex.Message);
                    }
                }
            }
            finally
            {
                // Recupera la selección inicial y el preview original.
                try
                {
                    SeleccionHandler.EstablecerSeleccionProgramaticaMYG(
                        doc,
                        seleccionOriginal,
                        true);

                    if (FormEstribos != null &&
                        !FormEstribos.IsDisposed &&
                        FormLongitudinal != null &&
                        !FormLongitudinal.IsDisposed)
                    {
                        FormEstribos.ActualizarDesdeVentanaLongitudinal(
                            FormLongitudinal);
                    }
                }
                catch
                {
                }
            }

            string resumen =
                "Ejecución masiva finalizada.\n\n" +
                "Vigas seleccionadas: " + seleccionOriginal.Count.ToString() + "\n" +
                "Series detectadas: " + series.Count.ToString() + "\n" +
                "Series ejecutadas: " + seriesOk.ToString() + "\n" +
                "Margen máximo de continuidad: " + margenM.ToString("0.00") + " m";

            if (errores.Count > 0)
            {
                resumen += "\n\nSeries con observaciones:\n" +
                           string.Join("\n", errores.Take(15));
            }

            TaskDialog.Show("MYG - Ejecución masiva", resumen);
        }

        private bool EjecutarSerieMYG(
            UIApplication app,
            Document doc,
            IList<ElementId> ids,
            bool ejecutarEstribos,
            bool ejecutarLongitudinales,
            bool cambiarSeleccionProgramatica,
            out string error)
        {
            error = string.Empty;

            if (ids == null || ids.Count == 0)
            {
                error = "Serie vacía.";
                return false;
            }

            if (cambiarSeleccionProgramatica)
            {
                if (!SeleccionHandler.EstablecerSeleccionProgramaticaMYG(
                    doc,
                    ids,
                    false))
                {
                    error = "No se pudo cargar la serie en el motor de selección.";
                    return false;
                }
            }

            bool hizoAlgo = false;

            // 1) ESTRIBOS
            if (ejecutarEstribos)
            {
                if (FormEstribos == null || FormEstribos.IsDisposed || HandlerEstribos == null)
                {
                    error = "No está conectado el módulo de estribos.";
                    return false;
                }

                if (FormLongitudinal != null && !FormLongitudinal.IsDisposed)
                {
                    FormEstribos.ActualizarDesdeVentanaLongitudinal(
                        FormLongitudinal);
                }

                if (!FormEstribos.PrepararModeloEjecucionCombinadaMYG(
                    out string errorEstribos))
                {
                    error = "Estribos: " + errorEstribos;
                    return false;
                }

                HandlerEstribos.Execute(app);
                hizoAlgo = true;
            }

            // 2) LONGITUDINALES
            if (ejecutarLongitudinales)
            {
                if (FormLongitudinal == null ||
                    FormLongitudinal.IsDisposed ||
                    HandlerLongitudinal == null)
                {
                    error = "No está conectado el módulo longitudinal.";
                    return false;
                }

                // El handler longitudinal usa exactamente la selección activa
                // cargada arriba y conserva TODA su lógica actual.
                HandlerLongitudinal.Execute(app);
                hizoAlgo = true;
            }

            return hizoAlgo;
        }

        // =========================================================
        // AGRUPACIÓN MASIVA
        // =========================================================
        private List<List<ElementId>> ConstruirSeriesMasivasMYG(
            Document doc,
            IList<ElementId> ids,
            double margenMaxFt)
        {
            List<EjeVigaMasivaMYG> datos = new List<EjeVigaMasivaMYG>();

            foreach (ElementId id in ids)
            {
                Element e = doc.GetElement(id);
                if (e == null)
                    continue;

                LocationCurve lc = e.Location as LocationCurve;
                Curve c = lc != null ? lc.Curve : null;

                if (c == null || !c.IsBound || c.Length <= Tol)
                    continue;

                Line linea = c as Line;

                if (linea == null)
                {
                    // Una curva se mantiene como serie independiente.
                    XYZ a = c.GetEndPoint(0);
                    XYZ b = c.GetEndPoint(1);
                    XYZ d = b.Subtract(a);

                    datos.Add(new EjeVigaMasivaMYG()
                    {
                        Id = id,
                        P0 = a,
                        P1 = b,
                        Dir = d.GetLength() > Tol ? d.Normalize() : XYZ.BasisX,
                        Medio = a.Add(b).Multiply(0.5),
                        Longitud = c.Length,
                        EsRecta = false
                    });

                    continue;
                }

                XYZ p0 = linea.GetEndPoint(0);
                XYZ p1 = linea.GetEndPoint(1);
                XYZ dir = p1.Subtract(p0);

                if (dir.GetLength() <= Tol)
                    continue;

                dir = CanonizarDireccionMYG(dir.Normalize());

                datos.Add(new EjeVigaMasivaMYG()
                {
                    Id = id,
                    P0 = p0,
                    P1 = p1,
                    Dir = dir,
                    Medio = p0.Add(p1).Multiply(0.5),
                    Longitud = linea.Length,
                    EsRecta = true
                });
            }

            if (datos.Count == 0)
                return new List<List<ElementId>>();

            int n = datos.Count;
            int[] parent = Enumerable.Range(0, n).ToArray();

            double cosTol = Math.Cos(
                ToleranciaAnguloGrados * Math.PI / 180.0);

            double tolColinealFt = UnitUtils.ConvertToInternalUnits(
                ToleranciaColinealM,
                UnitTypeId.Meters);

            for (int i = 0; i < n; i++)
            {
                if (!datos[i].EsRecta)
                    continue;

                for (int j = i + 1; j < n; j++)
                {
                    if (!datos[j].EsRecta)
                        continue;

                    double paralelo = Math.Abs(
                        datos[i].Dir.DotProduct(datos[j].Dir));

                    if (paralelo < cosTol)
                        continue;

                    // Distancia perpendicular entre los dos ejes 3D.
                    XYZ r = datos[j].Medio.Subtract(datos[i].Medio);
                    XYZ paraleloVec = datos[i].Dir.Multiply(
                        r.DotProduct(datos[i].Dir));
                    double distanciaPerp = r.Subtract(paraleloVec).GetLength();

                    if (distanciaPerp > tolColinealFt)
                        continue;

                    double gap = ObtenerGapLongitudinalMYG(
                        datos[i],
                        datos[j]);

                    // REGLA SOLICITADA:
                    // gap <= input (ej. 0.50 m) => misma serie continua.
                    // gap > input (ej. puerta 1.20 m) => series separadas.
                    if (gap <= margenMaxFt + Tol)
                        Union(parent, i, j);
                }
            }

            Dictionary<int, List<EjeVigaMasivaMYG>> componentes =
                new Dictionary<int, List<EjeVigaMasivaMYG>>();

            for (int i = 0; i < n; i++)
            {
                int root = Find(parent, i);
                if (!componentes.ContainsKey(root))
                    componentes[root] = new List<EjeVigaMasivaMYG>();
                componentes[root].Add(datos[i]);
            }

            List<List<ElementId>> resultado = new List<List<ElementId>>();

            foreach (List<EjeVigaMasivaMYG> comp in componentes.Values)
            {
                if (comp == null || comp.Count == 0)
                    continue;

                if (comp.Count == 1 || !comp[0].EsRecta)
                {
                    resultado.Add(comp.Select(x => x.Id).ToList());
                    continue;
                }

                XYZ dir = CanonizarDireccionMYG(comp[0].Dir);

                List<ElementId> ordenados = comp
                    .OrderBy(x => x.Medio.DotProduct(dir))
                    .Select(x => x.Id)
                    .ToList();

                resultado.Add(ordenados);
            }

            // Orden estable para que la ejecución sea predecible.
            return resultado
                .OrderBy(g =>
                {
                    Element e = g.Count > 0 ? doc.GetElement(g[0]) : null;
                    BoundingBoxXYZ bb = e != null ? e.get_BoundingBox(null) : null;
                    return bb != null ? (bb.Min.Z + bb.Max.Z) * 0.5 : 0.0;
                })
                .ThenBy(g =>
                {
                    Element e = g.Count > 0 ? doc.GetElement(g[0]) : null;
                    LocationCurve lc = e != null ? e.Location as LocationCurve : null;
                    Curve c = lc != null ? lc.Curve : null;
                    return c != null ? c.GetEndPoint(0).X : 0.0;
                })
                .ThenBy(g =>
                {
                    Element e = g.Count > 0 ? doc.GetElement(g[0]) : null;
                    LocationCurve lc = e != null ? e.Location as LocationCurve : null;
                    Curve c = lc != null ? lc.Curve : null;
                    return c != null ? c.GetEndPoint(0).Y : 0.0;
                })
                .ToList();
        }

        private double ObtenerGapLongitudinalMYG(
            EjeVigaMasivaMYG a,
            EjeVigaMasivaMYG b)
        {
            XYZ dir = CanonizarDireccionMYG(a.Dir);
            XYZ origen = a.P0;

            double a0 = a.P0.Subtract(origen).DotProduct(dir);
            double a1 = a.P1.Subtract(origen).DotProduct(dir);
            double b0 = b.P0.Subtract(origen).DotProduct(dir);
            double b1 = b.P1.Subtract(origen).DotProduct(dir);

            double amin = Math.Min(a0, a1);
            double amax = Math.Max(a0, a1);
            double bmin = Math.Min(b0, b1);
            double bmax = Math.Max(b0, b1);

            if (bmin > amax)
                return bmin - amax;

            if (amin > bmax)
                return amin - bmax;

            return 0.0;
        }

        private XYZ CanonizarDireccionMYG(XYZ d)
        {
            if (d == null || d.GetLength() <= Tol)
                return XYZ.BasisX;

            XYZ n = d.Normalize();

            if (Math.Abs(n.X) > 1e-7)
                return n.X >= 0.0 ? n : n.Multiply(-1.0);

            if (Math.Abs(n.Y) > 1e-7)
                return n.Y >= 0.0 ? n : n.Multiply(-1.0);

            return n.Z >= 0.0 ? n : n.Multiply(-1.0);
        }

        private int Find(int[] parent, int x)
        {
            while (parent[x] != x)
            {
                parent[x] = parent[parent[x]];
                x = parent[x];
            }
            return x;
        }

        private void Union(int[] parent, int a, int b)
        {
            int ra = Find(parent, a);
            int rb = Find(parent, b);
            if (ra != rb)
                parent[rb] = ra;
        }

        private bool LeerCheckPrivadoMYG(
            object formulario,
            string nombreCampo,
            bool respaldo)
        {
            if (formulario == null || string.IsNullOrWhiteSpace(nombreCampo))
                return respaldo;

            try
            {
                FieldInfo campo = formulario.GetType().GetField(
                    nombreCampo,
                    BindingFlags.Instance |
                    BindingFlags.Public |
                    BindingFlags.NonPublic);

                if (campo == null)
                    return respaldo;

                System.Windows.Forms.CheckBox chk =
                    campo.GetValue(formulario) as System.Windows.Forms.CheckBox;

                return chk != null ? chk.Checked : respaldo;
            }
            catch
            {
                return respaldo;
            }
        }

        public string GetName()
        {
            return "MYG - Ejecutar acero en vigas (todo / masivo)";
        }
    }
}
